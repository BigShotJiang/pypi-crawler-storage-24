//! Connection-level state machine and session manager.

use std::collections::{HashMap, HashSet};

use bytes::Bytes;
use tracing::{debug, error, warn};

use crate::common::constants::{
    DRAIN_WEBTRANSPORT_SESSION_TYPE, ERR_H3_REQUEST_REJECTED, ERR_LIB_CONNECTION_STATE_ERROR,
    ERR_LIB_INTERNAL_ERROR, ERR_LIB_SESSION_STATE_ERROR, ERR_WT_ALPN_ERROR,
    ERR_WT_BUFFERED_STREAM_REJECTED, SETTINGS_WT_INITIAL_MAX_DATA,
    SETTINGS_WT_INITIAL_MAX_STREAMS_BIDI, SETTINGS_WT_INITIAL_MAX_STREAMS_UNI,
    UPGRADE_TOKEN_WEBTRANSPORT, WT_AVAILABLE_PROTOCOLS, WT_PROTOCOL,
};
use crate::common::types::{
    ConnectionId, ConnectionState, ErrorCode, ErrorSource, EventType, Headers, RequestId,
    SessionId, SessionState, StreamDirection, StreamId,
};
use crate::protocol::events::{Effect, ProtocolEvent, RequestResult};
use crate::protocol::session::Session;
use crate::protocol::utils::{
    encode_subprotocol_list, find_header, find_header_str, is_unidirectional_stream,
    parse_subprotocol_list, parse_subprotocol_string, stream_dir_from_id,
};

// Representation of a WebTransport connection state machine.
pub(super) struct Connection {
    pub(super) id: String,
    pub(super) is_client: bool,
    pub(super) state: ConnectionState,
    pub(super) max_datagram_size: u64,
    pub(super) remote_max_datagram_frame_size: Option<u64>,
    pub(super) handshake_complete: bool,
    pub(super) peer_settings_received: bool,
    pub(super) local_goaway_sent: bool,
    pub(super) sessions: HashMap<SessionId, Session>,
    pub(super) stream_map: HashMap<StreamId, SessionId>,
    pub(super) pending_requests: HashMap<StreamId, RequestId>,
    pub(super) pending_session_configs: HashMap<RequestId, SessionInitData>,
    pub(super) early_event_buffer: HashMap<StreamId, Vec<(f64, ProtocolEvent)>>,
    pub(super) early_event_count: usize,
    pub(super) peer_initial_max_data: u64,
    pub(super) peer_initial_max_streams_bidi: u64,
    pub(super) peer_initial_max_streams_uni: u64,
    pub(super) connected_at: Option<f64>,
    pub(super) closed_at: Option<f64>,
    flow_control_window_auto_scale: bool,
    initial_max_data: u64,
    initial_max_streams_bidi: u64,
    initial_max_streams_uni: u64,
    flow_control_window_size: u64,
    max_sessions: u64,
    stream_read_buffer_size: u64,
    stream_write_buffer_size: u64,
    max_pending_events_per_session: u64,
    max_total_pending_events: u64,
    early_event_ttl: f64,
}

impl Connection {
    // Connection entity initialization.
    #[allow(
        clippy::too_many_arguments,
        reason = "Complex internal state initialization."
    )]
    pub(super) fn new(
        id: ConnectionId,
        is_client: bool,
        max_datagram_size: u64,
        flow_control_window_size: u64,
        max_sessions: u64,
        initial_max_data: u64,
        initial_max_streams_bidi: u64,
        initial_max_streams_uni: u64,
        stream_read_buffer_size: u64,
        stream_write_buffer_size: u64,
        flow_control_window_auto_scale: bool,
        max_pending_events_per_session: u64,
        max_total_pending_events: u64,
        early_event_ttl: f64,
    ) -> Self {
        Self {
            id,
            is_client,
            state: ConnectionState::Idle,
            max_datagram_size,
            remote_max_datagram_frame_size: None,
            handshake_complete: false,
            peer_settings_received: false,
            local_goaway_sent: false,
            sessions: HashMap::new(),
            stream_map: HashMap::new(),
            pending_requests: HashMap::new(),
            pending_session_configs: HashMap::new(),
            early_event_buffer: HashMap::new(),
            early_event_count: 0,
            peer_initial_max_data: 0,
            peer_initial_max_streams_bidi: 0,
            peer_initial_max_streams_uni: 0,
            connected_at: None,
            closed_at: None,
            flow_control_window_auto_scale,
            initial_max_data,
            initial_max_streams_bidi,
            initial_max_streams_uni,
            flow_control_window_size,
            max_sessions,
            stream_read_buffer_size,
            stream_write_buffer_size,
            max_pending_events_per_session,
            max_total_pending_events,
            early_event_ttl,
        }
    }

    // User session acceptance handling (delegated).
    pub(super) fn accept_session(
        &mut self,
        session_id: SessionId,
        request_id: RequestId,
        subprotocol: Option<String>,
        now: f64,
    ) -> Vec<Effect> {
        if let Some(session) = self.sessions.get_mut(&session_id) {
            return session.accept(request_id, subprotocol, now);
        }
        vec![Effect::NotifyRequestFailed {
            request_id,
            source: ErrorSource::Session,
            error_code: Some(ERR_LIB_SESSION_STATE_ERROR),
            reason: "Session not found".to_owned(),
        }]
    }

    // H3 session binding.
    pub(super) fn bind_session(
        &mut self,
        stream_id: StreamId,
        request_id: RequestId,
    ) -> Vec<Effect> {
        self.pending_requests.insert(stream_id, request_id);
        Vec::new()
    }

    // QUIC stream binding (delegated).
    pub(super) fn bind_stream(
        &mut self,
        session_id: SessionId,
        stream_id: StreamId,
        request_id: RequestId,
        is_unidirectional: bool,
        now: f64,
    ) -> Vec<Effect> {
        if let Some(session) = self.sessions.get_mut(&session_id) {
            let effects = session.bind_stream(stream_id, request_id, is_unidirectional, now);
            self.stream_map.insert(stream_id, session_id);
            return effects;
        }
        vec![Effect::NotifyRequestFailed {
            request_id,
            source: ErrorSource::Session,
            error_code: None,
            reason: format!("Session {session_id} not found during stream bind"),
        }]
    }

    // Connection closure handling.
    pub(super) fn close(
        &mut self,
        request_id: RequestId,
        error_code: ErrorCode,
        reason: Option<String>,
        now: f64,
    ) -> Vec<Effect> {
        let mut effects = Vec::new();
        if self.state != ConnectionState::Closed && self.state != ConnectionState::Closing {
            self.state = ConnectionState::Closing;
            self.closed_at = Some(now);
            effects.push(Effect::CloseQuicConnection { error_code, reason });
        }
        effects.push(Effect::NotifyRequestDone {
            request_id,
            result: RequestResult::None,
        });
        effects
    }

    // User session closure handling (delegated).
    pub(super) fn close_session(
        &mut self,
        session_id: SessionId,
        request_id: RequestId,
        code: ErrorCode,
        reason: Option<String>,
        now: f64,
    ) -> Vec<Effect> {
        if let Some(session) = self.sessions.get_mut(&session_id) {
            return session.close(request_id, code, reason, now);
        }
        vec![Effect::NotifyRequestDone {
            request_id,
            result: RequestResult::None,
        }]
    }

    // User session creation request handling.
    pub(super) fn create_session(
        &mut self,
        request_id: RequestId,
        path: String,
        mut headers: Headers,
        subprotocols: Option<Vec<String>>,
        now: f64,
    ) -> Vec<Effect> {
        if !self.is_client {
            return vec![Effect::NotifyRequestFailed {
                request_id,
                source: ErrorSource::Connection,
                error_code: None,
                reason: "Server cannot create sessions using this method".to_owned(),
            }];
        }

        if self.state != ConnectionState::Connected {
            return vec![Effect::NotifyRequestFailed {
                request_id,
                source: ErrorSource::Connection,
                error_code: Some(ERR_LIB_CONNECTION_STATE_ERROR),
                reason: format!(
                    "Cannot create session, connection state is {:?}",
                    self.state
                ),
            }];
        }

        let active_limit = if self.has_flow_control() {
            self.max_sessions
        } else {
            1
        };

        let current_total = (self.sessions.len() + self.pending_session_configs.len()) as u64;

        if active_limit > 0 && current_total >= active_limit {
            return vec![Effect::NotifyRequestFailed {
                request_id,
                source: ErrorSource::Connection,
                error_code: Some(ERR_LIB_CONNECTION_STATE_ERROR),
                reason: "Session limit reached".to_owned(),
            }];
        }

        if let Some(ref protos) = subprotocols {
            let encoded = encode_subprotocol_list(protos);
            headers.push((Bytes::from_static(WT_AVAILABLE_PROTOCOLS), encoded));
        }

        self.pending_session_configs.insert(
            request_id,
            SessionInitData {
                path: path.clone(),
                headers: headers.clone(),
                subprotocols,
                created_at: now,
            },
        );

        vec![Effect::CreateH3Session {
            request_id,
            path,
            headers,
        }]
    }

    // User stream creation request handling (delegated).
    pub(super) fn create_stream(
        &mut self,
        session_id: SessionId,
        request_id: RequestId,
        is_uni: bool,
    ) -> Vec<Effect> {
        if let Some(session) = self.sessions.get_mut(&session_id) {
            return session.create_stream(request_id, is_uni);
        }
        vec![Effect::NotifyRequestFailed {
            request_id,
            source: ErrorSource::Session,
            error_code: Some(ERR_LIB_SESSION_STATE_ERROR),
            reason: "Session not found".to_owned(),
        }]
    }

    // Connection diagnostics event handling.
    pub(super) fn diagnose(&self, request_id: RequestId) -> Vec<Effect> {
        let diag = self.diagnostics_snapshot();
        vec![Effect::NotifyRequestDone {
            request_id,
            result: RequestResult::ConnectionDiagnostics(Box::new(diag)),
        }]
    }

    // TLS keying material export handling (delegated).
    pub(super) fn export_keying_material(
        &self,
        session_id: SessionId,
        request_id: RequestId,
        label: String,
        context: &[u8],
        length: u32,
    ) -> Vec<Effect> {
        if let Some(session) = self.sessions.get(&session_id) {
            return session.export_keying_material(request_id, label, context, length);
        }
        vec![Effect::NotifyRequestFailed {
            request_id,
            source: ErrorSource::Session,
            error_code: Some(ERR_LIB_SESSION_STATE_ERROR),
            reason: "Session not found".to_owned(),
        }]
    }

    // H3 session creation failure handling.
    pub(super) fn fail_session(
        &mut self,
        request_id: RequestId,
        error_code: Option<ErrorCode>,
        reason: String,
    ) -> Vec<Effect> {
        error!("H3 Session creation failed for request {request_id}: {reason}");
        self.pending_session_configs.remove(&request_id);
        vec![Effect::NotifyRequestFailed {
            request_id,
            source: ErrorSource::Session,
            error_code,
            reason,
        }]
    }

    // QUIC stream creation failure handling (delegated).
    pub(super) fn fail_stream(
        &mut self,
        session_id: SessionId,
        request_id: RequestId,
        is_unidirectional: bool,
        error_code: Option<ErrorCode>,
        reason: String,
    ) -> Vec<Effect> {
        if let Some(session) = self.sessions.get_mut(&session_id) {
            return session.fail_stream(request_id, is_unidirectional, error_code, reason);
        }
        vec![Effect::NotifyRequestFailed {
            request_id,
            source: ErrorSource::Stream,
            error_code,
            reason,
        }]
    }

    // Graceful connection shutdown handling.
    pub(super) fn graceful_close(&mut self, request_id: RequestId, now: f64) -> Vec<Effect> {
        let mut effects = Vec::new();

        if !self.local_goaway_sent {
            self.local_goaway_sent = true;
            effects.push(Effect::SendH3Goaway);

            if self.state != ConnectionState::Closing && self.state != ConnectionState::Closed {
                self.state = ConnectionState::Closing;
                self.closed_at = Some(now);
            }
        }

        effects.push(Effect::NotifyRequestDone {
            request_id,
            result: RequestResult::None,
        });
        effects
    }

    // Manual data credit grant handling (delegated).
    pub(super) fn grant_data_credit(
        &mut self,
        session_id: SessionId,
        request_id: RequestId,
        max_data: u64,
    ) -> Vec<Effect> {
        if let Some(session) = self.sessions.get_mut(&session_id) {
            return session.grant_data_credit(request_id, max_data);
        }
        vec![Effect::NotifyRequestFailed {
            request_id,
            source: ErrorSource::Session,
            error_code: Some(ERR_LIB_SESSION_STATE_ERROR),
            reason: "Session not found".to_owned(),
        }]
    }

    // Manual streams credit grant handling (delegated).
    pub(super) fn grant_streams_credit(
        &mut self,
        session_id: SessionId,
        request_id: RequestId,
        is_uni: bool,
        max_streams: u64,
    ) -> Vec<Effect> {
        if let Some(session) = self.sessions.get_mut(&session_id) {
            return session.grant_streams_credit(request_id, is_uni, max_streams);
        }
        vec![Effect::NotifyRequestFailed {
            request_id,
            source: ErrorSource::Session,
            error_code: Some(ERR_LIB_SESSION_STATE_ERROR),
            reason: "Session not found".to_owned(),
        }]
    }

    // Handshake completion handling.
    pub(super) fn handshake_completed(&mut self, now: f64) -> Vec<Effect> {
        let mut effects = Vec::new();
        self.handshake_complete = true;

        if let Some((client_effects, _)) = self.check_connection_ready(now) {
            effects.extend(client_effects);
        }
        effects
    }

    // Flow control negotiation status verification.
    pub(super) fn has_flow_control(&self) -> bool {
        let local_intent = self.initial_max_data > 0
            || self.initial_max_streams_bidi > 0
            || self.initial_max_streams_uni > 0;
        let peer_intent = self.peer_initial_max_data > 0
            || self.peer_initial_max_streams_bidi > 0
            || self.peer_initial_max_streams_uni > 0;

        local_intent && peer_intent
    }

    // Early events pruning.
    pub(super) fn prune_early_events(&mut self, now: f64) -> Vec<Effect> {
        let mut effects = Vec::new();
        let mut streams_to_remove = Vec::new();
        let mut terminated_child_streams = HashSet::new();

        let mut stream_ids: Vec<StreamId> = self.early_event_buffer.keys().copied().collect();
        stream_ids.sort_unstable();

        for stream_id in stream_ids {
            if let Some(events) = self.early_event_buffer.get_mut(&stream_id) {
                let mut valid_events = Vec::new();

                for (timestamp, evt) in events.drain(..) {
                    if now - timestamp < self.early_event_ttl {
                        valid_events.push((timestamp, evt));
                    } else {
                        self.early_event_count -= 1;

                        if let ProtocolEvent::TransportStreamDataReceived {
                            stream_id: child_id,
                            ..
                        } = evt
                            && terminated_child_streams.insert(child_id)
                        {
                            let dir = stream_dir_from_id(child_id, self.is_client);
                            let can_send = matches!(
                                dir,
                                StreamDirection::Bidirectional | StreamDirection::SendOnly
                            );
                            let can_receive = matches!(
                                dir,
                                StreamDirection::Bidirectional | StreamDirection::ReceiveOnly
                            );

                            if can_send {
                                effects.push(Effect::ResetQuicStream {
                                    stream_id: child_id,
                                    error_code: ERR_WT_BUFFERED_STREAM_REJECTED,
                                });
                            }
                            if can_receive {
                                effects.push(Effect::StopQuicStream {
                                    stream_id: child_id,
                                    error_code: ERR_WT_BUFFERED_STREAM_REJECTED,
                                });
                            }
                        }
                    }
                }

                if valid_events.is_empty() {
                    streams_to_remove.push(stream_id);
                } else {
                    *events = valid_events;
                }
            }
        }

        for stream_id in streams_to_remove {
            self.early_event_buffer.remove(&stream_id);
            if !self.sessions.contains_key(&stream_id) {
                debug!("Early event buffer timed out for stream {stream_id}, resetting");

                if is_unidirectional_stream(stream_id) {
                    effects.push(Effect::StopQuicStream {
                        stream_id,
                        error_code: ERR_WT_BUFFERED_STREAM_REJECTED,
                    });
                } else {
                    effects.push(Effect::ResetQuicStream {
                        stream_id,
                        error_code: ERR_WT_BUFFERED_STREAM_REJECTED,
                    });
                    effects.push(Effect::StopQuicStream {
                        stream_id,
                        error_code: ERR_WT_BUFFERED_STREAM_REJECTED,
                    });
                }
            }
        }

        effects
    }

    // Closed resources pruning.
    pub(super) fn prune_resources(&mut self) -> Vec<Effect> {
        let mut effects = Vec::new();

        let mut closed_session_ids: Vec<SessionId> = self
            .sessions
            .iter()
            .filter(|(_, s)| s.state == SessionState::Closed)
            .map(|(id, _)| *id)
            .collect();

        closed_session_ids.sort_unstable();
        let closed_session_set: HashSet<SessionId> = closed_session_ids.iter().copied().collect();

        for sid in closed_session_ids {
            debug!("Cleaning up closed session {sid} from state");
            self.sessions.remove(&sid);
            effects.push(Effect::CleanupH3Stream { stream_id: sid });
        }

        if !closed_session_set.is_empty() {
            self.stream_map
                .retain(|_, sess_id| !closed_session_set.contains(sess_id));
        }

        let mut active_session_ids: Vec<SessionId> = self.sessions.keys().copied().collect();
        active_session_ids.sort_unstable();

        for session_id in active_session_ids {
            if let Some(session) = self.sessions.get_mut(&session_id) {
                let session_effects = session.prune_closed_streams();
                for effect in &session_effects {
                    if let Effect::CleanupH3Stream { stream_id } = effect {
                        self.stream_map.remove(stream_id);
                    }
                }
                effects.extend(session_effects);
            }
        }

        effects
    }

    // Capsule reception handling (delegated).
    pub(super) fn recv_capsule(
        &mut self,
        session_id: SessionId,
        capsule_type: u64,
        data: &[u8],
        now: f64,
    ) -> Vec<Effect> {
        if let Some(session) = self.sessions.get_mut(&session_id) {
            return session.recv_capsule(capsule_type, data, now);
        }
        Vec::new()
    }

    // CONNECT stream closure reception handling (delegated).
    pub(super) fn recv_connect_close(&mut self, session_id: SessionId, now: f64) -> Vec<Effect> {
        if let Some(session) = self.sessions.get_mut(&session_id) {
            return session.recv_connect_close(now);
        }
        Vec::new()
    }

    // Datagram reception handling (delegated).
    pub(super) fn recv_datagram(
        &mut self,
        session_id: SessionId,
        data: Bytes,
        now: f64,
    ) -> Vec<Effect> {
        if let Some(session) = self.sessions.get_mut(&session_id) {
            return session.recv_datagram(data);
        }

        let event = ProtocolEvent::TransportDatagramFrameReceived { data };

        if !self.buffer_early_event(session_id, event, now) {
            warn!("Early event buffer full, dropping datagram for session {session_id}");
        }

        Vec::new()
    }

    // GOAWAY frame reception handling.
    pub(super) fn recv_goaway(&mut self, now: f64) -> Vec<Effect> {
        let mut effects = Vec::new();

        if self.state != ConnectionState::Closing && self.state != ConnectionState::Closed {
            self.state = ConnectionState::Closing;
            self.closed_at = Some(now);
        }

        let mut session_ids: Vec<SessionId> = self.sessions.keys().copied().collect();
        session_ids.sort_unstable();

        for session_id in session_ids {
            if let Some(session) = self
                .sessions
                .get_mut(&session_id)
                .filter(|s| s.state == SessionState::Connected)
            {
                session.state = SessionState::Draining;
                effects.push(Effect::SendH3Capsule {
                    stream_id: session_id,
                    capsule_type: DRAIN_WEBTRANSPORT_SESSION_TYPE,
                    capsule_data: Bytes::new(),
                    end_stream: false,
                });
                effects.push(Effect::EmitSessionEvent {
                    session_id,
                    event_type: EventType::SessionDraining,
                    path: None,
                    headers: None,
                    subprotocols: None,
                    subprotocol: None,
                    data: None,
                    is_unidirectional: None,
                    max_data: None,
                    max_streams: None,
                    ready_at: None,
                    error_code: None,
                    reason: None,
                });
            }
        }
        effects
    }

    // HEADERS frame reception handling.
    pub(super) fn recv_headers(
        &mut self,
        stream_id: StreamId,
        headers: Headers,
        stream_ended: bool,
        now: f64,
    ) -> Vec<Effect> {
        let mut effects = Vec::new();

        if self.is_client {
            let Some(request_id) = self.pending_requests.remove(&stream_id) else {
                warn!("Received headers on unknown client stream {stream_id} (no pending request)");
                if stream_ended {
                    effects.extend(self.recv_connect_close(stream_id, now));
                }
                return effects;
            };

            let Some(init_data) = self.pending_session_configs.remove(&request_id) else {
                error!("Internal State Error: Missing init data for request {request_id:?}");
                if stream_ended {
                    effects.extend(self.recv_connect_close(stream_id, now));
                }
                effects.push(Effect::NotifyRequestFailed {
                    request_id,
                    source: ErrorSource::Unspecified,
                    error_code: Some(ERR_LIB_INTERNAL_ERROR),
                    reason: "Internal state inconsistency: Session init data missing".to_owned(),
                });
                return effects;
            };

            let status_str = find_header_str(&headers, ":status");
            let status_ok = status_str.as_deref() == Some("200");

            if status_ok {
                let subprotocol = std::str::from_utf8(WT_PROTOCOL)
                    .ok()
                    .and_then(|key| find_header(&headers, key))
                    .and_then(|val| parse_subprotocol_string(&val));

                if let Some(ref requested_protos) = init_data.subprotocols {
                    let is_valid = match subprotocol {
                        Some(ref negotiated) => requested_protos.contains(negotiated),
                        None => false,
                    };

                    if !is_valid {
                        let reason = match subprotocol {
                            Some(ref negotiated) => {
                                format!("Server negotiated unrequested subprotocol: {negotiated}")
                            }
                            None => "Server failed to negotiate a required subprotocol".to_owned(),
                        };

                        error!("{reason}");

                        if stream_ended {
                            effects.extend(self.recv_connect_close(stream_id, now));
                        }
                        effects.push(Effect::NotifyRequestFailed {
                            request_id,
                            source: ErrorSource::Session,
                            error_code: Some(ERR_WT_ALPN_ERROR),
                            reason,
                        });
                        effects.push(Effect::StopQuicStream {
                            stream_id,
                            error_code: ERR_WT_ALPN_ERROR,
                        });
                        effects.push(Effect::ResetQuicStream {
                            stream_id,
                            error_code: ERR_WT_ALPN_ERROR,
                        });
                        return effects;
                    }
                }

                let session = Session::new(
                    stream_id,
                    init_data.path.clone(),
                    init_data.headers.clone(),
                    subprotocol.clone(),
                    init_data.created_at,
                    self.config_initial_max_data(),
                    self.config_initial_max_streams_bidi(),
                    self.config_initial_max_streams_uni(),
                    self.peer_initial_max_data,
                    self.peer_initial_max_streams_bidi,
                    self.peer_initial_max_streams_uni,
                    self.flow_control_window_size,
                    self.stream_read_buffer_size,
                    self.stream_write_buffer_size,
                    self.has_flow_control(),
                    self.flow_control_window_auto_scale,
                    self.is_client,
                    SessionState::Connected,
                );
                self.sessions.insert(stream_id, session);

                effects.push(Effect::EmitSessionEvent {
                    session_id: stream_id,
                    event_type: EventType::SessionReady,
                    path: Some(init_data.path),
                    headers: Some(init_data.headers),
                    subprotocols: None,
                    subprotocol,
                    data: None,
                    is_unidirectional: None,
                    max_data: None,
                    max_streams: None,
                    ready_at: Some(now),
                    error_code: None,
                    reason: None,
                });
                effects.push(Effect::NotifyRequestDone {
                    request_id,
                    result: RequestResult::SessionId(stream_id),
                });

                if let Some(events) = self.early_event_buffer.remove(&stream_id) {
                    if self.early_event_count >= events.len() {
                        self.early_event_count -= events.len();
                    }
                    for (_, evt) in events {
                        effects.push(Effect::ProcessProtocolEvent {
                            event: Box::new(evt),
                        });
                    }
                }
            } else {
                let status_val = status_str.unwrap_or_else(|| "Unknown".to_owned());
                let reason = format!("Session creation failed with status {status_val:?}");
                effects.push(Effect::NotifyRequestFailed {
                    request_id,
                    source: ErrorSource::Session,
                    error_code: Some(ERR_H3_REQUEST_REJECTED),
                    reason,
                });
            }
        } else {
            if self.sessions.contains_key(&stream_id) {
                debug!("Received trailers on existing session stream {stream_id}, ignoring.");
                if stream_ended {
                    effects.extend(self.recv_connect_close(stream_id, now));
                }
                return effects;
            }

            if self.state != ConnectionState::Connected {
                debug!(
                    "Rejecting new session on stream {stream_id}: connection state is {:?}",
                    self.state
                );
                effects.push(Effect::SendH3Headers {
                    stream_id,
                    headers: vec![(Bytes::from_static(b":status"), Bytes::from("429"))],
                    end_stream: true,
                });
                effects.push(Effect::StopQuicStream {
                    stream_id,
                    error_code: ERR_H3_REQUEST_REJECTED,
                });
                return effects;
            }

            let active_limit = if self.has_flow_control() {
                self.max_sessions
            } else {
                1
            };

            if active_limit > 0 && self.sessions.len() as u64 >= active_limit {
                warn!(
                    "Session limit ({active_limit}) reached, rejecting new session on stream {stream_id}"
                );
                effects.push(Effect::SendH3Headers {
                    stream_id,
                    headers: vec![(Bytes::from_static(b":status"), Bytes::from("429"))],
                    end_stream: true,
                });
                effects.push(Effect::StopQuicStream {
                    stream_id,
                    error_code: ERR_H3_REQUEST_REJECTED,
                });
                return effects;
            }

            let method = find_header_str(&headers, ":method");
            let protocol = find_header_str(&headers, ":protocol");

            let method_connect = method.as_deref() == Some("CONNECT");
            let proto_wt =
                protocol.as_deref().map(str::as_bytes) == Some(UPGRADE_TOKEN_WEBTRANSPORT);

            if !method_connect || !proto_wt {
                debug!("Rejecting non-WebTransport request on stream {stream_id}");
                effects.push(Effect::SendH3Headers {
                    stream_id,
                    headers: vec![(Bytes::from_static(b":status"), Bytes::from("400"))],
                    end_stream: true,
                });
                effects.push(Effect::StopQuicStream {
                    stream_id,
                    error_code: ERR_H3_REQUEST_REJECTED,
                });
                return effects;
            }

            let path_header = find_header_str(&headers, ":path");
            let path = path_header.unwrap_or_else(|| "/".to_owned());

            let subprotocols = std::str::from_utf8(WT_AVAILABLE_PROTOCOLS)
                .ok()
                .and_then(|key| find_header(&headers, key))
                .and_then(|val| parse_subprotocol_list(&val));

            let session = Session::new(
                stream_id,
                path.clone(),
                headers.clone(),
                None,
                now,
                self.config_initial_max_data(),
                self.config_initial_max_streams_bidi(),
                self.config_initial_max_streams_uni(),
                self.peer_initial_max_data,
                self.peer_initial_max_streams_bidi,
                self.peer_initial_max_streams_uni,
                self.flow_control_window_size,
                self.stream_read_buffer_size,
                self.stream_write_buffer_size,
                self.has_flow_control(),
                self.flow_control_window_auto_scale,
                self.is_client,
                SessionState::Connecting,
            );
            self.sessions.insert(stream_id, session);

            effects.push(Effect::EmitSessionEvent {
                session_id: stream_id,
                event_type: EventType::SessionRequest,
                path: Some(path),
                headers: Some(headers),
                subprotocols,
                subprotocol: None,
                data: None,
                is_unidirectional: None,
                max_data: None,
                max_streams: None,
                ready_at: None,
                error_code: None,
                reason: None,
            });

            if let Some(events) = self.early_event_buffer.remove(&stream_id) {
                if self.early_event_count >= events.len() {
                    self.early_event_count -= events.len();
                }
                for (_, evt) in events {
                    effects.push(Effect::ProcessProtocolEvent {
                        event: Box::new(evt),
                    });
                }
            }
        }

        if stream_ended {
            effects.extend(self.recv_connect_close(stream_id, now));
        }

        effects
    }

    // SETTINGS frame reception handling.
    pub(super) fn recv_settings(&mut self, settings: &HashMap<u64, u64>, now: f64) -> Vec<Effect> {
        let mut effects = Vec::new();
        self.peer_settings_received = true;

        if let Some(val) = settings.get(&SETTINGS_WT_INITIAL_MAX_DATA) {
            self.peer_initial_max_data = *val;
        }
        if let Some(val) = settings.get(&SETTINGS_WT_INITIAL_MAX_STREAMS_BIDI) {
            self.peer_initial_max_streams_bidi = *val;
        }
        if let Some(val) = settings.get(&SETTINGS_WT_INITIAL_MAX_STREAMS_UNI) {
            self.peer_initial_max_streams_uni = *val;
        }

        if let Some((client_effects, _)) = self.check_connection_ready(now) {
            effects.extend(client_effects);
        }

        effects
    }

    // Stream data reception handling (delegated).
    pub(super) fn recv_stream_data(
        &mut self,
        session_id: SessionId,
        stream_id: StreamId,
        data: Bytes,
        fin: bool,
        now: f64,
    ) -> Vec<Effect> {
        self.stream_map.entry(stream_id).or_insert(session_id);

        if let Some(session) = self.sessions.get_mut(&session_id) {
            return session.recv_stream_data(stream_id, data, fin, now);
        }

        let event = ProtocolEvent::TransportStreamDataReceived {
            stream_id,
            data,
            end_stream: fin,
        };

        if !self.buffer_early_event(session_id, event, now) {
            warn!("Early event buffer full, rejecting stream {stream_id} for session {session_id}");

            let mut effects = Vec::new();

            if is_unidirectional_stream(stream_id) {
                effects.push(Effect::StopQuicStream {
                    stream_id,
                    error_code: ERR_WT_BUFFERED_STREAM_REJECTED,
                });
            } else {
                effects.push(Effect::ResetQuicStream {
                    stream_id,
                    error_code: ERR_WT_BUFFERED_STREAM_REJECTED,
                });
                effects.push(Effect::StopQuicStream {
                    stream_id,
                    error_code: ERR_WT_BUFFERED_STREAM_REJECTED,
                });
            }

            return effects;
        }

        Vec::new()
    }

    // Transport stream reset reception handling (delegated).
    pub(super) fn recv_stream_reset(
        &mut self,
        stream_id: StreamId,
        error_code: ErrorCode,
        now: f64,
    ) -> Vec<Effect> {
        if let Some(session) = self
            .stream_map
            .get(&stream_id)
            .and_then(|sid| self.sessions.get_mut(sid))
        {
            return session.recv_stream_reset(stream_id, error_code, now);
        }
        Vec::new()
    }

    // Transport stream stop_sending reception handling (delegated).
    pub(super) fn recv_stop_sending(
        &mut self,
        stream_id: StreamId,
        error_code: ErrorCode,
    ) -> Vec<Effect> {
        if let Some(session) = self
            .stream_map
            .get(&stream_id)
            .and_then(|sid| self.sessions.get_mut(sid))
        {
            return session.recv_stop_sending(stream_id, error_code);
        }
        Vec::new()
    }

    // Transport parameters reception handling.
    pub(super) fn recv_transport_parameters(
        &mut self,
        remote_max_datagram_frame_size: u64,
    ) -> Vec<Effect> {
        debug!(
            "Received transport parameters: remote_max_datagram_frame_size={remote_max_datagram_frame_size}"
        );
        self.remote_max_datagram_frame_size = Some(remote_max_datagram_frame_size);
        Vec::new()
    }

    // User session rejection handling (delegated).
    pub(super) fn reject_session(
        &mut self,
        session_id: SessionId,
        request_id: RequestId,
        code: u16,
        now: f64,
    ) -> Vec<Effect> {
        if let Some(session) = self.sessions.get_mut(&session_id) {
            return session.reject(request_id, code, now);
        }
        vec![Effect::NotifyRequestFailed {
            request_id,
            source: ErrorSource::Session,
            error_code: Some(ERR_LIB_SESSION_STATE_ERROR),
            reason: "Session not found".to_owned(),
        }]
    }

    // User stream reset command handling (delegated).
    pub(super) fn reset_stream(
        &mut self,
        session_id: SessionId,
        stream_id: StreamId,
        request_id: RequestId,
        code: ErrorCode,
    ) -> Vec<Effect> {
        let now = 0.0;
        if let Some(session) = self.sessions.get_mut(&session_id) {
            return session.reset_stream(stream_id, request_id, code, now);
        }
        vec![Effect::NotifyRequestFailed {
            request_id,
            source: ErrorSource::Stream,
            error_code: Some(ERR_LIB_SESSION_STATE_ERROR),
            reason: "Session not found".to_owned(),
        }]
    }

    // User datagram send command handling (delegated).
    pub(super) fn send_datagram(
        &mut self,
        session_id: SessionId,
        request_id: RequestId,
        data: Bytes,
    ) -> Vec<Effect> {
        if let Some(session) = self.sessions.get_mut(&session_id) {
            let max = self.remote_max_datagram_frame_size.unwrap_or(0);
            return session.send_datagram(request_id, data, max);
        }
        vec![Effect::NotifyRequestFailed {
            request_id,
            source: ErrorSource::Session,
            error_code: Some(ERR_LIB_SESSION_STATE_ERROR),
            reason: "Session not found".to_owned(),
        }]
    }

    // User stream data send handling (delegated).
    pub(super) fn send_stream_data(
        &mut self,
        session_id: SessionId,
        stream_id: StreamId,
        request_id: RequestId,
        data: Bytes,
        fin: bool,
    ) -> Vec<Effect> {
        if let Some(session) = self.sessions.get_mut(&session_id) {
            return session.send_stream_data(stream_id, request_id, data, fin);
        }
        vec![Effect::NotifyRequestFailed {
            request_id,
            source: ErrorSource::Stream,
            error_code: Some(ERR_LIB_SESSION_STATE_ERROR),
            reason: "Session not found".to_owned(),
        }]
    }

    // Session diagnostics delegation.
    pub(super) fn session_diagnostics(
        &self,
        session_id: SessionId,
        request_id: RequestId,
    ) -> Vec<Effect> {
        if let Some(session) = self.sessions.get(&session_id) {
            return session.diagnose(request_id);
        }
        vec![Effect::NotifyRequestFailed {
            request_id,
            source: ErrorSource::Session,
            error_code: Some(ERR_LIB_SESSION_STATE_ERROR),
            reason: "Session not found".to_owned(),
        }]
    }

    // User stream stop command handling (delegated).
    pub(super) fn stop_stream(
        &mut self,
        session_id: SessionId,
        stream_id: StreamId,
        request_id: RequestId,
        code: ErrorCode,
    ) -> Vec<Effect> {
        let now = 0.0;
        if let Some(session) = self.sessions.get_mut(&session_id) {
            return session.stop_stream(stream_id, request_id, code, now);
        }
        vec![Effect::NotifyRequestFailed {
            request_id,
            source: ErrorSource::Stream,
            error_code: Some(ERR_LIB_SESSION_STATE_ERROR),
            reason: "Session not found".to_owned(),
        }]
    }

    // Stream diagnostics delegation.
    pub(super) fn stream_diagnostics(
        &self,
        session_id: SessionId,
        stream_id: StreamId,
        request_id: RequestId,
    ) -> Vec<Effect> {
        if let Some(session) = self.sessions.get(&session_id) {
            return session.stream_diagnostics(stream_id, request_id);
        }
        vec![Effect::NotifyRequestFailed {
            request_id,
            source: ErrorSource::Stream,
            error_code: Some(ERR_LIB_SESSION_STATE_ERROR),
            reason: "Session not found".to_owned(),
        }]
    }

    // User stream read request handling (delegated).
    pub(super) fn stream_read(
        &mut self,
        session_id: SessionId,
        stream_id: StreamId,
        request_id: RequestId,
        max_bytes: u64,
    ) -> Vec<Effect> {
        if let Some(session) = self.sessions.get_mut(&session_id) {
            return session.stream_read(stream_id, request_id, max_bytes);
        }
        vec![Effect::NotifyRequestFailed {
            request_id,
            source: ErrorSource::Stream,
            error_code: Some(ERR_LIB_SESSION_STATE_ERROR),
            reason: "Session not found".to_owned(),
        }]
    }

    // Connection termination handling.
    pub(super) fn terminated(
        &mut self,
        error_code: ErrorCode,
        reason_phrase: String,
        now: f64,
    ) -> Vec<Effect> {
        if self.state == ConnectionState::Closed {
            return Vec::new();
        }

        self.state = ConnectionState::Closed;
        self.closed_at = Some(now);

        let mut effects = Vec::new();
        let reason_msg = format!("Connection terminated: {reason_phrase}");

        self.pending_session_configs.clear();
        self.pending_requests.clear();

        let mut session_ids: Vec<SessionId> = self.sessions.keys().copied().collect();
        session_ids.sort_unstable();

        for session_id in session_ids {
            if let Some(session) = self.sessions.get_mut(&session_id) {
                effects.extend(session.close(0, error_code, Some(reason_msg.clone()), now));
            }
        }

        effects.push(Effect::EmitConnectionEvent {
            connection_id: self.id.clone(),
            event_type: EventType::ConnectionClosed,
            error_code: Some(error_code),
            reason: Some(reason_phrase),
        });

        effects
    }

    // Early protocol event buffering with capacity checks.
    fn buffer_early_event(
        &mut self,
        session_id: SessionId,
        event: ProtocolEvent,
        now: f64,
    ) -> bool {
        if (self.early_event_count as u64) >= self.max_total_pending_events {
            return false;
        }

        let session_buffer = self.early_event_buffer.entry(session_id).or_default();

        if (session_buffer.len() as u64) >= self.max_pending_events_per_session {
            return false;
        }

        session_buffer.push((now, event));
        self.early_event_count += 1;

        true
    }

    // Connection readiness state verification.
    fn check_connection_ready(&mut self, now: f64) -> Option<(Vec<Effect>, bool)> {
        if self.state == ConnectionState::Connecting
            && self.handshake_complete
            && self.peer_settings_received
        {
            debug!("Client connection fully ready (QUIC + H3 SETTINGS).");
            self.state = ConnectionState::Connected;
            self.connected_at = Some(now);

            let effects = vec![Effect::EmitConnectionEvent {
                connection_id: self.id.clone(),
                event_type: EventType::ConnectionEstablished,
                error_code: None,
                reason: None,
            }];
            return Some((effects, true));
        }
        None
    }

    // Initial max data configuration accessor.
    fn config_initial_max_data(&self) -> u64 {
        self.initial_max_data
    }

    // Initial max bidirectional streams accessor.
    fn config_initial_max_streams_bidi(&self) -> u64 {
        self.initial_max_streams_bidi
    }

    // Initial max unidirectional streams accessor.
    fn config_initial_max_streams_uni(&self) -> u64 {
        self.initial_max_streams_uni
    }

    // Connection diagnostics snapshot retrieval.
    fn diagnostics_snapshot(&self) -> ConnectionDiagnostics {
        ConnectionDiagnostics {
            connection_id: self.id.clone(),
            is_client: self.is_client,
            state: self.state,
            max_datagram_size: self.max_datagram_size,
            remote_max_datagram_frame_size: self.remote_max_datagram_frame_size,
            handshake_complete: self.handshake_complete,
            peer_settings_received: self.peer_settings_received,
            local_goaway_sent: self.local_goaway_sent,
            session_count: self.sessions.len(),
            stream_count: self.stream_map.len(),
            pending_request_count: self.pending_requests.len(),
            early_event_count: self.early_event_count,
            connected_at: self.connected_at,
            closed_at: self.closed_at,
        }
    }
}

// Diagnostic information snapshot for a connection.
#[derive(Clone, Debug)]
pub(crate) struct ConnectionDiagnostics {
    pub(crate) connection_id: String,
    pub(crate) is_client: bool,
    pub(crate) state: ConnectionState,
    pub(crate) max_datagram_size: u64,
    pub(crate) remote_max_datagram_frame_size: Option<u64>,
    pub(crate) handshake_complete: bool,
    pub(crate) peer_settings_received: bool,
    pub(crate) local_goaway_sent: bool,
    pub(crate) session_count: usize,
    pub(crate) stream_count: usize,
    pub(crate) pending_request_count: usize,
    pub(crate) early_event_count: usize,
    pub(crate) connected_at: Option<f64>,
    pub(crate) closed_at: Option<f64>,
}

// Data required to initialize a pending session.
#[derive(Clone, Debug)]
pub(super) struct SessionInitData {
    pub(super) path: String,
    pub(super) headers: Headers,
    pub(super) subprotocols: Option<Vec<String>>,
    pub(super) created_at: f64,
}

#[cfg(test)]
mod tests;
