#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "Aidge::quantization" for configuration "Release"
set_property(TARGET Aidge::quantization APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(Aidge::quantization PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/lib_aidge_quantization.a"
  )

list(APPEND _cmake_import_check_targets Aidge::quantization )
list(APPEND _cmake_import_check_files_for_Aidge::quantization "${_IMPORT_PREFIX}/lib/lib_aidge_quantization.a" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
