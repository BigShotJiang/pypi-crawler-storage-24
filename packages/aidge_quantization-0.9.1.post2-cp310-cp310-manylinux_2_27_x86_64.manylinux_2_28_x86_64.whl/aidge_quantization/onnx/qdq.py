import aidge_core

import aidge_quantization

AFFINE_OPS = {
    "FC",
    "Mul",
    "Gemm",
    "Conv1D",
    "Conv2D",
    "Conv3D",
    "ConvDepthWise1D",
    "ConvDepthWise2D",
    "ConvDepthWise3D",
    "PaddedConv1D",
    "PaddedConv2D",
    "PaddedConv3D",
    "PaddedConvDepthWise1D",
    "PaddedConvDepthWise2D",
    "PaddedConvDepthWise3D",
}

TRANSPARENT_OPS = {
    "ReLU",
    "MaxPooling2D",
    "PaddedMaxPooling2D",
    "Identity",
    "Pad",
    "Resize",
    "Transpose",
    "Tile",
    "Gather",
    "Flatten",
}


def fold_bias(graph_view):

    def _is_int32_quant(node):
        is_int32 = False
        for n in node.get_operator().get_micro_graph().get_nodes():
            if (
                n.type() == "Cast"
                and n.get_operator().attr.target_type == aidge_core.dtype.int32
            ):
                is_int32 = True
                break
        return is_int32

    spgm = aidge_core.SinglePassGraphMatching(graph_view)
    spgm.add_node_lambda("int32", _is_int32_quant)
    matches = spgm.match("Producer#0->Quantizer#1[int32];")
    for match in matches:
        matched_graph = match.graph.clone()
        for n in matched_graph.get_nodes():
            if n.type() == "Producer":
                n.get_operator().attr.constant = True
        aidge_core.constant_folding(matched_graph)
        if not aidge_core.GraphView.replace(match.graph, matched_graph):
            raise RuntimeError("Failed to constant fold bias.")


def set_to_qdq(graph_view):
    """
    Transform a freshly quantized model to QDQ format.

    This function is only guaranteed to work on quantized graph that hasn't been modified!
    """
    ### Create a topologically ordered list of nodes
    ordered_nodes = graph_view.get_ordered_nodes()
    output_nodes = graph_view.get_output_nodes()

    nodes_to_rescale = {}

    for node in ordered_nodes:
        if node.type() in ["Producer", "Quantizer", "Dequantizer"]:
            continue

        if node.type() in {"Add", "Sub"}:
            scales = []
            # 1. Add Dequantize layer to inputs
            parents = node.get_parents()
            for in_id, parent_node in enumerate(parents):
                if parent_node is None:
                    raise RuntimeError(
                        f"Node {node.name()} was expected to have a Quantizer at input {in_id} but no parent was found."
                    )

                if parent_node.type() != "Quantizer":
                    raise RuntimeError(
                        f"Node {node.name()} was expected to have a Quantizer as a parent, got {parent_node.name()}[{parent_node.type()}] instead."
                    )

                scale = aidge_quantization.get_scaling_factor(parent_node)
                scales.append(scale)
            new_dq_scale = 1 / (scales[0] * scales[1])

            for in_id, parent_node in enumerate(parents):
                # Insert Dequantizer Node
                dequantizer = aidge_core.Dequantizer(
                    1 / scales[in_id],
                    f"{node.name()}_{in_id}_dq",
                    to_type=aidge_core.dtype.float32,
                    internal_type=aidge_core.dtype.float32,
                )
                dequantizer.get_operator().set_backend(node.get_operator().backend())
                nodes_to_rescale[dequantizer.id()] = new_dq_scale

                graph_view.insert_parent(node, dequantizer, in_id, 0, 0)

            children = node.get_children()
            if len(children) != 1:
                raise RuntimeError(
                    f"{node.name()}[{node.type()}] should have 1 output, found {len(children)} instead"
                )

            # 2. Compensate outputs
            # 2.1 Compensate output scaling
            child_node = list(children)[0]
            if child_node.type() != "Quantizer":
                raise RuntimeError(
                    f"Node {node.name()} was expected to have a Quantizer as a child, got {child_node.name()}[{child_node.type()}] instead."
                )

            output_scale = aidge_quantization.get_scaling_factor(child_node)
            # Multiply by input and weight scale
            aidge_quantization.set_scaling_factor(
                child_node, output_scale * scales[0] * scales[1]
            )

        elif node.type() in AFFINE_OPS:
            if node.get_operator().backend() == "":
                raise RuntimeError(
                    f" Node {node.name()}[{node.type()}] must have a backend specified."
                )
            scales = []
            # 1. Add Dequantize layer to inputs
            parents = node.get_parents()
            for in_id, parent_node in enumerate(parents):
                if in_id >= 3:
                    break
                if parent_node is None:
                    if in_id == 2:
                        scales.append(None)
                        continue
                    else:
                        raise RuntimeError(
                            f"Node {node.name()} was expected to have a Quantizer at input {in_id} but no parent was found."
                        )

                if parent_node.type() != "Quantizer":
                    raise RuntimeError(
                        f"Node {node.name()} was expected to have a Quantizer as a parent, got {parent_node.name()}[{parent_node.type()}] instead."
                    )

                scale = aidge_quantization.get_scaling_factor(parent_node)
                scales.append(scale)

                # Insert Dequantizer Node
                dequantizer = aidge_core.Dequantizer(
                    1 / scale,
                    f"{node.name()}_{in_id}_dq",
                    to_type=aidge_core.dtype.float32,
                    internal_type=aidge_core.dtype.float32,
                )
                dequantizer.get_operator().set_backend(node.get_operator().backend())

                graph_view.insert_parent(node, dequantizer, in_id, 0, 0)
            children = node.get_children()
            if len(children) != 1:
                raise RuntimeError(
                    f"{node.name()}[{node.type()}] should have 1 output, found {len(children)} instead"
                )

            # 2. Compensate outputs + bias (if any)
            # 2.1 Compensate output scaling
            child_node = list(children)[0]
            if child_node.type() != "Quantizer":
                raise RuntimeError(
                    f"Node {node.name()} was expected to have a Quantizer as a child, got {child_node.name()}[{child_node.type()}] instead."
                )

            output_scale = aidge_quantization.get_scaling_factor(child_node)
            # Multiply by input and weight scale
            aidge_quantization.set_scaling_factor(
                child_node, output_scale * scales[0] * scales[1]
            )

            # 2.2 Compensate bias scaling
            if len(scales) < 3 or scales[2] is None:
                # No scaling, skip
                continue
            # Update bias scale.
            nodes_to_rescale[parents[2].id()] = (scales[2] ** 2) / (
                scales[0] * scales[1]
            )

        elif node.type() in TRANSPARENT_OPS:
            node_backend = aidge_quantization.determine_backend(node)

            parents = node.get_parents()

            if len(parents) != 1:
                aidge_core.Log.warn(
                    f"Node {node.name()}[{node.type()}] has multiple inputs, only input#1 will be used"
                )

            parent_node = parents[0]

            if parent_node.type() != "Quantizer":
                raise RuntimeError(
                    f"Node {node.name()} was expected to have a Quantizer as a parent, got {parent_node.name()}[{parent_node.type()}] instead."
                )

            scale = aidge_quantization.get_scaling_factor(parent_node)

            # 1. Insert Dequantizer Node

            dequantizer = aidge_core.Dequantizer(
                1 / scale,
                f"{node.name()}_dq",
                to_type=aidge_core.dtype.float32,
                internal_type=aidge_core.dtype.float32,
            )
            dequantizer.get_operator().set_backend(node_backend)

            graph_view.insert_parent(
                node,
                dequantizer,
                0,  # child in idx
                0,  # New parent in idx
                0,  # New parent out idx
            )

            # 2. Insert compensation Quantizer Node
            if node.get_nb_outputs() != 1:
                aidge_core.Log.notice(
                    f"Node {node.name()}[{node.type()}] has multiple outputs, Quantizer node will be inserted in output 0"
                )

            quantizer_node = aidge_core.Quantizer(
                scaling_factor=scale,
                name=f"{node.name()}_quantizer",
                round=True,
                clip_min=-128,
                clip_max=127,
                to_type=aidge_core.dtype.int8,
                internal_type=aidge_core.dtype.float32,
            )

            quantizer_node.get_operator().set_backend(node_backend)
            quantizer_node.get_operator().set_datatype(aidge_core.dtype.float32)

            for output_node, out_in_id in node.output(0):
                if (
                    output_node.type() == "Quantizer"
                    and not output_node.attributes().has_attr(
                        "quantization.ptq.isResidual"
                    )
                ):
                    continue

                if output_node.attributes().has_attr("quantization.ptq.isResidual"):
                    compensation_scale = aidge_quantization.get_scaling_factor(
                        output_node
                    )
                    nodes_to_rescale[output_node.id()] = scale * compensation_scale
                else:
                    graph_view.insert_parent(
                        output_node, quantizer_node, out_in_id, 0, 0
                    )
                    quantizer_node = quantizer_node.clone()
            if node in output_nodes:
                graph_view.add(quantizer_node)
                node.add_child(quantizer_node, 0, 0)
        else:
            raise RuntimeError(f"Cannot treat operator of type {node.type()}")

    for node in graph_view.get_nodes():
        if node.id() in nodes_to_rescale.keys():
            aidge_quantization.set_scaling_factor(node, nodes_to_rescale[node.id()])
    fold_bias(graph_view)


def remove_node(node):
    if not aidge_core.GraphView.replace({node}, set()):
        raise RuntimeError(
            f"Failed to remove node {node.name()}[{node.type()}] from graph"
        )


def get_diverging_pair(merg_node):
    if merg_node.type() not in {"Mul", "Add", "Sub", "Concat", "MatMul"}:
        return None
    branches_to_explore = merg_node.get_parents()

    if len(branches_to_explore) < 2:
        # single input, cannot be merging
        return None

    visited_parents = set()

    for input_node in branches_to_explore:
        if input_node is None:
            continue

        branch_visited_parents = set()

        to_explore_nodes = input_node.get_parents()
        if input_node.id() in visited_parents:
            # common parent of differing branches
            return (input_node.id(), merg_node.id())
        branch_visited_parents.add(input_node.id())

        for branch_node in to_explore_nodes:
            while (
                branch_node is not None
                and branch_node.type() != "Producer"
                and branch_node.get_parent(0) is not None
            ):
                if branch_node.id() in visited_parents:
                    # common parent of differing branches
                    return (branch_node.id(), merg_node.id())
                branch_visited_parents.add(branch_node.id())
                parents = branch_node.get_parents()

                to_explore_nodes.extend(parents[1:])
                branch_node = parents[0]

        visited_parents.update(branch_visited_parents)
    return None


def diverging_branches(model):

    diverging_nodes = []
    merging_nodes = []

    for merg_node in model.get_nodes():
        p = get_diverging_pair(merg_node)
        if p is not None:
            diverging_nodes.append(p[0])
            merging_nodes.append(p[1])
    return diverging_nodes, merging_nodes


def from_qdq(graph_view):
    nodes_to_rescale = {}
    nodes_to_remove = set()

    # Retrieve list of ids of nodes that start a multibranch and their merge
    diverging_nodes, merging_nodes = diverging_branches(graph_view)

    for node in graph_view.get_ordered_nodes():
        aidge_core.Log.debug(f"Treating node {node.name()}[{node.type()}]")

        if node.type() in {"Producer", "Quantizer"} or node.id() in merging_nodes:
            continue

        elif node.type() == "Dequantizer":
            # if it is the last node
            if len(node.get_children()) == 0:
                nodes_to_remove.add(node.id())
            continue

        elif node.type() in AFFINE_OPS:
            scales = []
            # 1. Remove Dequantize layer to inputs
            parents = node.get_parents()

            # Variable used in case the bias is folded, will be used to indicate if it is folded or not
            bias_dequantizer = None

            for in_id, parent_node in enumerate(parents):
                # Variable used to see if the input operator is diverging, and if yes, which node
                diverging_node = None

                if in_id >= 3:
                    break

                if parent_node is not None and parent_node.type() != "Dequantizer":
                    raise RuntimeError(
                        f"Node {node.name()} was expected to have a Dequantizer as a parent, got {parent_node.name()}[{parent_node.type()}] instead."
                    )

                if in_id == 2:
                    if parent_node is None:
                        # Means no bias
                        scales.append(None)
                    elif parent_node.get_parent(0).type() != "Quantizer":
                        parent_quantizer = parent_node.get_parent(0)
                        if parent_quantizer.type() == "Producer":
                            # if the folded producer is the bias, then the bias dequantizer is saved to be able to use it later
                            bias_dequantizer = parent_node.clone()
                        else:
                            raise RuntimeError(
                                f"Node {parent_node.name()} was expected to have a Producer or Quantizer as a parent, got {parent_quantizer.name()}[{parent_quantizer.type()}] instead. "
                                "Bias without this information cannot be treated"
                            )
                elif parent_node is None:
                    raise RuntimeError(
                        f"Node {node.name()} was expected to have a Dequantizer at input {in_id} but no parent was found."
                    )

                # Scaling factor is taken from the dequantizer node unless it is input#0 (it can be detached!)
                if in_id == 0:
                    aff_quant = parent_node
                    while aff_quant.get_parent(0) is not None and (
                        aff_quant.id() not in nodes_to_remove
                        or aff_quant.type() != "Quantizer"
                    ):
                        if (
                            aff_quant.type() == "Dequantizer"
                            and aff_quant.id() in diverging_nodes
                        ):
                            diverging_node = aff_quant
                        aff_quant = aff_quant.get_parent(0)
                    if aff_quant.type() != "Quantizer":
                        raise RuntimeError(
                            f"Could not find {node.name()}'s input#0 Quantizer, is the graph really qdq?"
                        )
                    scale = aidge_quantization.get_scaling_factor(aff_quant)
                else:
                    scale = 1 / (aidge_quantization.get_scaling_factor(parent_node))

                scales.append(scale)

                # If diverging, connect to the quantized parent and not the dequantizer
                if diverging_node is not None:
                    graph_view.add_parent(
                        diverging_node.get_parent(0), node, 0, node.input(0)[1]
                    )
                    if len(diverging_node.get_children()) > 0:
                        # Do not remove the dequantizer if it still has children
                        continue

                # Remove Dequantizer Node
                nodes_to_remove.add(parent_node.id())

            # Output treatment

            children = node.get_children()
            if len(children) != 1:
                raise RuntimeError(
                    f"{node.name()}[{node.type()}] should have 1 output, found {len(children)} instead"
                )

            # 2. Compensate outputs + bias (if any)
            # 2.1 Compensate output scaling
            child_node = list(children)[0]
            if child_node.type() != "Quantizer":
                raise RuntimeError(
                    f"Node {node.name()} was expected to have a Quantizer as a child, got {child_node.name()}[{child_node.type()}] instead."
                )

            output_scale = aidge_quantization.get_scaling_factor(child_node)
            # Divide by the multiplication of input and weight scale
            nodes_to_rescale[child_node.id()] = output_scale / (scales[0] * scales[1])

            # 2.2 Compensate bias scaling
            # Case 1: no bias, no scaling; skip
            if len(scales) < 3 or scales[2] is None:
                continue

            new_bias_scale = scales[0] * scales[1]

            # Case 2: bias exists but is folded
            if bias_dequantizer is not None:
                # Build graph with folded quantized bias and dequantizer
                # To fold again and get the original bias value

                quantized_b_prod = parents[2].get_parent(0)

                cloned_q_bias = quantized_b_prod.clone()
                cloned_q_bias.get_operator().attr.constant = True

                q_node = aidge_core.Quantizer(
                    scaling_factor=new_bias_scale,
                    name=f"{node.name()}_2_q",
                    round=True,
                    clip_min=-2147483648,  # int32 dtype ranges
                    clip_max=2147483647,
                    to_type=aidge_core.dtype.int32,
                    internal_type=aidge_core.dtype.float32,
                )

                # set all producers to be constant to be able to fold
                for q_and_dq_prod in (
                    bias_dequantizer.get_operator().get_micro_graph().get_nodes()
                ):
                    if q_and_dq_prod.type() == "Producer":
                        q_and_dq_prod.get_operator().attr.constant = True

                graph_new_b = aidge_core.sequential([cloned_q_bias, bias_dequantizer])

                if node.get_operator().backend() == "":
                    raise RuntimeError(
                        f" Node {node.name()}[{node.type()}] must have a backend specified."
                    )
                graph_new_b.set_backend(node.get_operator().backend())

                graph_new_b.forward_dtype()
                graph_new_b.forward_dims()

                # Forward to propagate values before folding
                sch_new_b = aidge_core.SequentialScheduler(graph_new_b)
                sch_new_b.forward()

                if not aidge_core.constant_folding(graph_new_b):
                    raise RuntimeError(
                        f"Failed to modify bias value for node {node.name()}[{node.type()}]: constant folding step."
                    )

                graph_new_b.add_child(q_node, list(graph_new_b.get_nodes())[0])
                graph_replaced = aidge_core.GraphView()
                graph_replaced.add(quantized_b_prod)

                if not aidge_core.GraphView.replace(graph_replaced, graph_new_b):
                    raise RuntimeError(
                        f"Failed to modify bias value for node {node.name()}[{node.type()}]: replacing bias step."
                    )
            else:
                # Case 3: bias exists and quantizer present; update bias scale
                aidge_quantization.set_scaling_factor(
                    parents[2].get_parent(0), new_bias_scale
                )
        elif node.type() in TRANSPARENT_OPS:
            parents = node.get_parents()

            # transparents nodes should/usually have only one input, more is an anomaly
            # in that case only the first input is considered
            if len(parents) != 1:
                aidge_core.Log.notice(
                    f"Node {node.name()}[{node.type()}] has multiple inputs, only input#0 will be taken into account"
                )

            parent_node = parents[0]

            if parent_node.type() != "Dequantizer":
                raise RuntimeError(
                    f"Node {node.name()} was expected to have a Dequantizer as a parent, got {parent_node.name()}[{parent_node.type()}] instead."
                )

            # 1. Remove Dequantizer Node
            nodes_to_remove.add(parent_node.id())

            if node.get_nb_outputs() != 1:
                aidge_core.Log.notice(
                    f"Node {node.name()}[{node.type()}] has multiple outputs, only output#0 will be taken into account"
                )

            output_node = node.output(0)[0][0]
            if output_node.type() != "Quantizer":
                raise RuntimeError(
                    f"Node {node.name()} was expected to have a Quantizer as a child, got {output_node.name()}[{output_node.type()}] instead."
                )

            nodes_to_remove.add(output_node.id())
        else:
            # Only the operators listed can be treated, others may work but its best to be careful
            raise RuntimeError(
                f"Cannot treat operator {node.name()} of type [{node.type()}]"
            )

    for node in graph_view.get_nodes():
        if node.id() in nodes_to_remove:
            remove_node(node)
        elif node.id() in nodes_to_rescale.keys():
            aidge_quantization.set_scaling_factor(node, nodes_to_rescale[node.id()])
