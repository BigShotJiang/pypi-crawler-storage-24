import aidge_core
import aidge_quantization

qop_to_opregex = {
    "QGemm": "FC#|Gemm#",
    "QLinearConv": "Conv1D#|Conv2D#|Conv3D#|ConvDepthWise1D#|ConvDepthWise2D#|ConvDepthWise3D#|PaddedConv1D#|PaddedConv2D#|PaddedConv3D#|PaddedConvDepthWise2D#|PaddedConvDepthWise3D#",
    "QLinearMatMul": "MatMul#",
}

operators_to_qop = {
    "FC": "QGemm",
    "Gemm": "QGemm",
    "MatMul": "QLinearMatMul",
    "Conv1D": "QLinearConv",
    "Conv2D": "QLinearConv",
    "Conv3D": "QLinearConv",
    "ConvDepthWise1D": "QLinearConv",
    "ConvDepthWise2D": "QLinearConv",
    "ConvDepthWise3D": "QLinearConv",
    "PaddedConv1D": "QLinearConv",
    "PaddedConv2D": "QLinearConv",
    "PaddedConv3D": "QLinearConv",
    "PaddedConvDepthWise1D": "QLinearConv",
    "PaddedConvDepthWise2D": "QLinearConv",
    "PaddedConvDepthWise3D": "QLinearConv",
}


def get_dequantizer_scale(dequant_node):
    current_scale = None
    for node in dequant_node.get_operator().get_micro_graph().get_nodes():
        if node.type() == "Mul":
            current_scale = node.get_parent(1).get_operator().get_output(0).clone()
            # Dtype is changed to conform to approx_EQ function and ONNX scaling dtypes
            current_scale.set_datatype(aidge_core.dtype.float32)
            break
    if current_scale is None:
        raise RuntimeError(
            f"Could not determine the scaling factor for {dequant_node.name()}[{dequant_node.type()}]."
        )
    return current_scale


def set_to_qop(graph, qops_selected=[], qdq_needed=False):
    # set_to_qdq if needed
    if qdq_needed:
        aidge_quantization.set_to_qdq(graph_view=graph)
        graph.forward_dtype()
    else:
        aidge_core.Log.notice(
            "'set_to_qop' function needs the graph to be in qdq format, result of onnx import or 'set_to_qdq' function. If this is not the case please set the 'qdq_needed' argument to true."
        )

    qop_list = qop_to_opregex.keys()
    if qops_selected != []:
        for s_qop in qops_selected:
            if s_qop not in qop_list:
                raise ValueError(
                    f"Qoperator type [{s_qop}] could not be identified, please verify if it is supported or spelled correctly."
                )
        qop_list = qops_selected

    # define regular expression to match
    node_type_strings = "("
    for idx, qop in enumerate(qop_list):
        if idx > 0:
            node_type_strings += "|"
        node_type_strings += qop_to_opregex[qop]
    node_type_strings += ")"

    def is_b_dq(node):
        # bias scaling must equal input_scale * weight scale

        main_node = node.output(0)[0][0]

        scales = []
        for parent in main_node.get_parents():
            if parent.type() != "Dequantizer":
                raise RuntimeError(
                    f"Node {main_node.name()} was expected to have a Dequantizer as a parent, got {parent.name()}[{parent.type()}] instead."
                )
            scales.append(get_dequantizer_scale(parent))

        # Tolerance values taken from other unit tests present in aidge, values may need to be adjusted
        if len(scales) == 3 and aidge_core.approx_eq(
            scales[2], scales[0] * scales[1], 1e-5, 1e-8
        ):
            return True
        aidge_core.Log.notice(
            f"Node {main_node.name()} does not meet QOP criteria; incorrect bias scale value or wrong connections."
        )
        return False

    regex_string = f"{node_type_strings}<0-Dequantizer;{node_type_strings}<1-Dequantizer;{node_type_strings}<2-($|Dequantizer[qop_bscale]);{node_type_strings}->Quantizer#1"

    spgm = aidge_core.SinglePassGraphMatching(graph)

    spgm.add_node_lambda("qop_bscale", is_b_dq)
    qop_matches = spgm.match(regex_string, True)

    if qop_matches == []:
        aidge_core.Log.warn("None of the nodes in the graph fitted Qoperator criteria.")
    for match in qop_matches:
        # clone and get into graph
        matched_graph = match.graph.clone()
        for node in matched_graph.get_nodes():
            if node.type() in operators_to_qop.keys():
                main_node = node
                break

        # replace original graph by metaoperator
        metaop_qop = aidge_core.meta_operator(
            operators_to_qop[main_node.type()], matched_graph
        )

        if node.get_operator().backend() != "":
            metaop_qop.get_operator().set_backend(node.get_operator().backend())
        metaop_graph = aidge_core.GraphView()
        metaop_graph.add(metaop_qop)

        if not aidge_core.GraphView.replace(match.graph, metaop_graph):
            raise RuntimeError(
                f"Unexpected error, could not add Qoperator for {main_node.name()}[{main_node.type()}] ; could not replace original nodes by Qoperator"
            )


def from_qop(graph_view, qops_to_expand=[], to_qdq=False):
    qop_list = qop_to_opregex.keys()
    if qops_to_expand != []:
        for qop in qops_to_expand:
            if qop not in qop_list:
                raise ValueError(
                    f"Qoperator type [{qop}] could not be identified, please verify if it is supported or spelled correctly."
                )
        qop_list = qops_to_expand

    for node in graph_view.get_ordered_nodes():
        if node.type() in qop_list:
            if not aidge_core.expand_metaop(node):
                aidge_core.Log.warn(
                    f"Node {node.name()}[{node.type()}] could not be expanded."
                )

    if not to_qdq:
        aidge_quantization.from_qdq(graph_view)
