/********************************************************************************
 * Copyright (c) 2024 CEA-List
 *
 * This program and the accompanying materials are made available under the
 * terms of the Eclipse Public License 2.0 which is available at
 * http://www.eclipse.org/legal/epl-2.0.
 *
 * SPDX-License-Identifier: EPL-2.0
 *
 ********************************************************************************/

#ifndef AIDGE_CUDA_OPERATOR_SCALEADJUSTIMPL_KERNELS_H_
#define AIDGE_CUDA_OPERATOR_SCALEADJUSTIMPL_KERNELS_H_

#include "aidge/data/Data.hpp"

#include "aidge/backend/cuda/operator/SAT/ScaleAdjustImpl.hpp"
#include "aidge/backend/cuda/utils/CudaUtils.hpp"

namespace Aidge {

template <class I, class O>
void ScaleAdjustImpl_cuda_forward_kernel(std::size_t inputLength,
                                         size_t nbNeurons,
                                         const void *input_,
                                         void *scale_,
                                         void *output_);

template <class I, class GI, class GO>
void ScaleAdjustImpl_cuda_backward_kernel(const std::size_t inputLength,
                                          size_t /*nbNeurons*/,
                                          const void *scale_,
                                          const void *grad_output_,
                                          void *grad_input_);

// Kernels registration to implementation entry point

REGISTRAR(ScaleAdjustImpl_cuda,
          {{DataType::Float16, DataFormat::NCHW},
           {DataType::Float16, DataFormat::NCHW}},
          {ProdConso::defaultModel,
           Aidge::ScaleAdjustImpl_cuda_forward_kernel<half_float::half,
                                                      half_float::half>,
           Aidge::ScaleAdjustImpl_cuda_backward_kernel<half_float::half,
                                                       half_float::half,
                                                       half_float::half>});
REGISTRAR(ScaleAdjustImpl_cuda,
          {{DataType::Float32, DataFormat::NCHW},
           {DataType::Float32, DataFormat::NCHW}},
          {ProdConso::defaultModel,
           Aidge::ScaleAdjustImpl_cuda_forward_kernel<float, float>,
           Aidge::ScaleAdjustImpl_cuda_backward_kernel<float, float, float>});
REGISTRAR(
    ScaleAdjustImpl_cuda,
    {{DataType::Float64, DataFormat::NCHW},
     {DataType::Float64, DataFormat::NCHW}},
    {ProdConso::defaultModel,
     Aidge::ScaleAdjustImpl_cuda_forward_kernel<double, double>,
     Aidge::ScaleAdjustImpl_cuda_backward_kernel<double, double, double>});

} // namespace Aidge

#endif /* AIDGE_CUDA_OPERATOR_SCALEADJUSTIMPL_KERNELS_H_ */
