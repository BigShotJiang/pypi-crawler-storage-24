/********************************************************************************
 * Copyright (c) 2023 CEA-List
 *
 * This program and the accompanying materials are made available under the
 * terms of the Eclipse Public License 2.0 which is available at
 * http://www.eclipse.org/legal/epl-2.0.
 *
 * SPDX-License-Identifier: EPL-2.0
 *
 ********************************************************************************/

#ifndef AIDGE_CPU_OPERATOR_SCALEADJUSTIMPL_KERNELS_H_
#define AIDGE_CPU_OPERATOR_SCALEADJUSTIMPL_KERNELS_H_

#include "aidge/utils/Registrar.hpp"

#include "aidge/backend/cpu/operator/SAT/ScaleAdjustImpl.hpp"

namespace Aidge {

template <class T, class I>
std::pair<T, T> meanStdDev(I first, I last, bool unbiased = true)
{
    AIDGE_ASSERT(last != first,
                 "meanStdDev(): number of elements must be > 0.");
    const size_t size = std::distance(first, last);
    AIDGE_ASSERT(!(size == 1 && unbiased),
                 "meanStdDev(): number of elements must be > 1 for unbiased.");

    // Use Welford's method to compute std. dev. in one pass
    T mean = T(0.0);
    T M2 = T(0.0);

    for (size_t k = 1; first != last; ++first, ++k) {
        const T delta = ((*first) - mean);
        mean += delta / k;
        const T delta2 = ((*first) - mean);
        M2 += delta * delta2;
    }

    const T stdDev =
        (unbiased) ? T(std::sqrt(M2 / (size - 1))) : T(std::sqrt(M2 / size));
    return std::make_pair(mean, stdDev);
}

template <class I, class O = I>
void ScaleAdjustImpl_cpu_forward_kernel(std::size_t inputLength,
                                        std::size_t nbNeurons,
                                        const void *input_,
                                        void *scale_,
                                        void *output_)
{
    const I *input = static_cast<const I *>(input_);
    I scale = *static_cast<I *>(scale_);
    O *output = static_cast<O *>(output_);

    // Apply Scale Adjust Training method
    const auto m = meanStdDev<I>(input, input + inputLength);
    scale = I(m.second * std::sqrt(nbNeurons));

    // XXX Log::notice(" kernel call | scale = {} ", m.second);

#pragma omp parallel for if (inputLength > 1024)
    for (int i = 0; i < static_cast<int>(inputLength); ++i) {
        output[i] = input[i] / scale;
    }

    // Set the scale output ...
    *(static_cast<I *>(scale_)) = scale;
}

template <class I, class GI = I, class GO = I>
void ScaleAdjustImpl_cpu_backward_kernel(const std::size_t inputLength,
                                         std::size_t /*nbNeurons*/,
                                         const void *scale_,
                                         const void *grad_output_,
                                         void *grad_input_)
{
    const I scale = *static_cast<const I *>(scale_);
    const GO *grad_output = static_cast<const GO *>(grad_output_);
    GI *grad_input = static_cast<GI *>(grad_input_);

    // #pragma omp parallel for if (inputLength > 1024)
    for (unsigned int i = 0; i < inputLength; ++i) {
        grad_input[i] = grad_output[i] * GO(1 / scale);
    }
}

// Kernels registration to implementation entry point
REGISTRAR(ScaleAdjustImpl_cpu,
          {DataType::Float32},
          {ProdConso::defaultModel,
           Aidge::ScaleAdjustImpl_cpu_forward_kernel<float>,
           Aidge::ScaleAdjustImpl_cpu_backward_kernel<float>});
REGISTRAR(ScaleAdjustImpl_cpu,
          {DataType::Float64},
          {ProdConso::defaultModel,
           Aidge::ScaleAdjustImpl_cpu_forward_kernel<double>,
           Aidge::ScaleAdjustImpl_cpu_backward_kernel<double>});

} // namespace Aidge

#endif /* AIDGE_CPU_OPERATOR_SCALEADJUSTIMPL_KERNELS_H_ */
