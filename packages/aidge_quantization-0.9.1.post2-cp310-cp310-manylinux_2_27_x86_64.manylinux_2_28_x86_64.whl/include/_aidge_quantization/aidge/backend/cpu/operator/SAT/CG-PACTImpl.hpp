/********************************************************************************
 * Copyright (c) 2023 CEA-List
 *
 * This program and the accompanying materials are made available under the
 * terms of the Eclipse Public License 2.0 which is available at
 * http://www.eclipse.org/legal/epl-2.0.
 *
 * SPDX-License-Identifier: EPL-2.0
 *
 ********************************************************************************/

#ifndef AIDGE_CPU_OPERATOR_CGPACTIMPL_H_
#define AIDGE_CPU_OPERATOR_CGPACTIMPL_H_

#include <cstddef> // std::size_t
#include <memory>
#include <tuple> // std::tuple
#include <vector>

#include "aidge/backend/cpu/operator/OperatorImpl.hpp"
#include "aidge/operator/SAT/CG-PACT.hpp"
#include "aidge/utils/Registrar.hpp"
#include "aidge/utils/Types.h"

namespace Aidge {

// compute kernel registry for forward and backward
using CGPACTImpl_cpu = OperatorImpl_cpu<
    CGPACT_Op,
    void(const std::size_t, std::size_t, const void *, const void *, void *),
    void(const std::size_t,
         std::size_t,
         const void *,
         const void *,
         const void *,
         void *,
         void *)>;

// Implementation entry point registration to Operator
REGISTRAR(CGPACT_Op, "cpu", Aidge::CGPACTImpl_cpu::create);
} // namespace Aidge

#endif /* AIDGE_CPU_OPERATOR_CGPACTIMPL_H_ */
