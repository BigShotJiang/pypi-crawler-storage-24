/********************************************************************************
 * Copyright (c) 2023 CEA-List
 *
 * This program and the accompanying materials are made available under the
 * terms of the Eclipse Public License 2.0 which is available at
 * http://www.eclipse.org/legal/epl-2.0.
 *
 * SPDX-License-Identifier: EPL-2.0
 *
 ********************************************************************************/

#ifndef AIDGE_CPU_OPERATOR_CGPACTIMPL_KERNELS_H_
#define AIDGE_CPU_OPERATOR_CGPACTIMPL_KERNELS_H_

#include "aidge/utils/Registrar.hpp"

#include "aidge/backend/cpu/operator/SAT/CG-PACTImpl.hpp"

namespace Aidge {
template <class I, class O>
void CGPACTImpl_cpu_forward_kernel(std::size_t inputLength,
                                   size_t range,
                                   const void *input_,
                                   const void *alpha_,
                                   void *output_)
{
    const I *input = static_cast<const I *>(input_);
    const I *alpha = static_cast<const I *>(alpha_);
    O *output = static_cast<O *>(output_);

    const I absAlpha = I(std::abs(alpha[0]));

    // #pragma omp parallel for if (inputLength > 1024)
    for (unsigned int i = 0; i < inputLength; ++i) {
        const auto x = input[i];
        const auto x_clip = (x < I(0.0))     ? I(0.0)
                            : (x < absAlpha) ? x
                                             : absAlpha;
        auto q = O(x_clip / absAlpha);

        // Test if q is in [0;1] before rounding
        assert(q >= O(0.0) && q <= O(1.0));

        q = std::round(O(range) * q) / O(range);

        // Test if q is in [0;1] after rounding
        assert(q >= O(0.0) && q <= O(1.0));

        output[i] = q * absAlpha;
    }
}

template <class I, class GI, class GO>
void CGPACTImpl_cpu_backward_kernel(const std::size_t inputLength,
                                    size_t range,
                                    const void *input_,
                                    const void *alpha_,
                                    const void *grad_output_,
                                    void *grad_input_,
                                    void *grad_alpha_)
{
    const I *input = static_cast<const I *>(input_);
    const I *alpha = static_cast<const I *>(alpha_);
    const GO *grad_output = static_cast<const GO *>(grad_output_);
    GI *grad_input = static_cast<GI *>(grad_input_);
    GO *grad_alpha = static_cast<GO *>(grad_alpha_);

    const auto absAlpha = I(std::abs(alpha[0]));

    // #pragma omp parallel for if (inputLength > 1024)
    for (unsigned int i = 0; i < inputLength; ++i) {
        const auto x = input[i];

        // --- Alpha gradient computation ---
        const auto x_clip = (x < I(0.0))     ? I(0.0)
                            : (x < absAlpha) ? x
                                             : absAlpha;
        const auto q = x_clip / absAlpha;

        // Test if q is in [0;1] before rounding
        assert(q >= GO(0.0) && q <= GO(1.0));

        auto qData = std::round(GO(range) * q) / GO(range);

        // Test if qData is in [0;1] after rounding
        assert(qData >= GO(0.0) && qData <= GO(1.0));

        const auto dQAlpha = (x >= absAlpha) ? GO(1.0) : (qData - q);

        // grad_alpha[i] = dQAlpha * grad_output[i];
        grad_alpha[0] += dQAlpha * grad_output[i];

        // --- Activation gradient computation ---
        // STE
        const auto dQAct = (x <= GO(0.0))   ? GO(0.0)
                           : (x > absAlpha) ? GO(0.0)
                                            : GO(1.0);
        // ACCUMULATE the grad !
        grad_input[i] += dQAct * grad_output[i];
    }
}

// Kernels registration to implementation entry point
REGISTRAR(
    CGPACTImpl_cpu,
    {{DataType::Float16, DataFormat::NCHW},
     {DataType::Float16, DataFormat::NCHW}},
    {ProdConso::inPlaceModel,
     Aidge::CGPACTImpl_cpu_forward_kernel<half_float::half, half_float::half>,
     Aidge::CGPACTImpl_cpu_backward_kernel<half_float::half,
                                           half_float::half,
                                           half_float::half>});
REGISTRAR(CGPACTImpl_cpu,
          {{DataType::Float32, DataFormat::NCHW},
           {DataType::Float32, DataFormat::NCHW}},
          {ProdConso::inPlaceModel,
           Aidge::CGPACTImpl_cpu_forward_kernel<float, float>,
           Aidge::CGPACTImpl_cpu_backward_kernel<float, float, float>});
REGISTRAR(CGPACTImpl_cpu,
          {{DataType::Float64, DataFormat::NCHW},
           {DataType::Float64, DataFormat::NCHW}},
          {ProdConso::inPlaceModel,
           Aidge::CGPACTImpl_cpu_forward_kernel<double, double>,
           Aidge::CGPACTImpl_cpu_backward_kernel<double, double, double>});

} // namespace Aidge

#endif /* AIDGE_CPU_OPERATOR_CGPACTIMPL_KERNELS_H_ */
