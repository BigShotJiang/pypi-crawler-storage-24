#ifndef AIDGE_UTILS_SYS_INFO_OPENCV_VERSION_INFO_H
#define AIDGE_UTILS_SYS_INFO_OPENCV_VERSION_INFO_H

#include "aidge/quantization/version.hpp"
#include "aidge/utils/Log.hpp"

namespace Aidge {

constexpr inline const char *getQuantizationProjectVersion()
{
    return Aidge::quantization::Version::full;
}

constexpr inline const char *getQuantizationGitHash()
{
    return Aidge::quantization::Version::git_hash;
}

inline void showQuantizationVersion()
{
    Log::println("Aidge quantization: {} ({}), {} {}",
                 getQuantizationProjectVersion(),
                 getQuantizationGitHash(),
                 __DATE__,
                 __TIME__);
    // Compiler version
#if defined(__clang__)
    /* Clang/LLVM. ---------------------------------------------- */
    Log::println("Clang/LLVM compiler version: {}.{}.{}\n",
                 __clang_major__,
                 __clang_minor__,
                 __clang_patchlevel__);
#elif defined(__ICC) || defined(__INTEL_COMPILER)
    /* Intel ICC/ICPC. ------------------------------------------ */
    Log::println("Intel ICC/ICPC compiler version: {}\n", __INTEL_COMPILER);
#elif defined(__GNUC__) || defined(__GNUG__)
    /* GNU GCC/G++. --------------------------------------------- */
    Log::println("GNU GCC/G++ compiler version: {}.{}.{}",
                 __GNUC__,
                 __GNUC_MINOR__,
                 __GNUC_PATCHLEVEL__);
#elif defined(_MSC_VER)
    /* Microsoft Visual Studio. --------------------------------- */
    Log::println("Microsoft Visual Studio compiler version: {}\n", _MSC_VER);
#else
    Log::println("Unknown compiler\n");
#endif
}
} // namespace Aidge
#endif // AIDGE_UTILS_SYS_INFO_OPENCV_VERSION_INFO_H
