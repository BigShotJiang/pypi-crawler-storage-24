/********************************************************************************
 * Copyright (c) 2023 CEA-List
 *
 * This program and the accompanying materials are made available under the
 * terms of the Eclipse Public License 2.0 which is available at
 * http://www.eclipse.org/legal/epl-2.0.
 *
 * SPDX-License-Identifier: EPL-2.0
 *
 ********************************************************************************/

#ifndef AIDGE_QUANTIZATION_QUANTIZATION_PTQ_PTQ_H_
#define AIDGE_QUANTIZATION_QUANTIZATION_PTQ_PTQ_H_

#include <cstdint> // std::uint8_t
#include <memory>
#include <set>
#include <string>
#include <unordered_map>
#include <utility> // std::pair
#include <vector>

#include "aidge/data/Tensor.hpp"
#include "aidge/graph/GraphView.hpp"
#include "aidge/quantization/PTQ/Clipping.hpp"

namespace Aidge {

/**
 * @brief Set of node types which contain affine transforms
 * (that is Y = A.X + B)
 */
static const std::set<std::string> affineNodeTypes({"FC",
                                                    "Conv1D",
                                                    "Conv2D",
                                                    "ConvDepthWise1D",
                                                    "ConvDepthWise2D",
                                                    "PaddedConv1D",
                                                    "PaddedConv2D",
                                                    "PaddedConvDepthWise1D",
                                                    "PaddedConvDepthWise2D"});

/**
 * @brief Set of node types that do not affect the PTQ process.
 */
static const std::set<std::string> seamlessNodeTypes({"Identity",
                                                      "Tile",
                                                      "ReLU",
                                                      "LeakyReLU",
                                                      "Pad",
                                                      "MaxPooling2D",
                                                      "AvgPooling2D",
                                                      "PaddedMaxPooling2D",
                                                      "PaddedAvgPooling2D",
                                                      "GlobalAveragePooling",
                                                      "Reshape",
                                                      "Transpose",
                                                      "Gather",
                                                      "Resize",
                                                      "Squeeze"});

/**
 * @brief The set of node types that merge multiple branches into one.
 */
static const std::set<std::string> mergingNodeTypes({"Add", "Concat", "Sub"});

/**
 * @brief Set of node types that won't be quantized.
 */
static const std::set<std::string> notQuantizedNodeTypes({"Sigmoid", "Tanh"});

/**
 * @brief Print a report on whether or not the graph is supported by the PTQ.
 */
void quantizabilityReport(const std::shared_ptr<GraphView> &graphView);

/**
 * @brief Determine if a node contains an affine transform (that is Y = A.X + B)
 * @param node The node to be checked
 * @return True if the node is affine, else false.
 */
bool isAffine(std::shared_ptr<Node> node);

/**
 * @brief Determine if a node contains an operator that does not affect the PTQ
 * process
 * @param node The node to be checked
 * @return True if the node is seamless, else false.
 */
bool isSeamless(std::shared_ptr<Node> node);

/**
 * @brief Determine if a node contains an operator that merges multiple branches
 * into one
 * @param node The node to be checked
 * @return True if the node is merging, else false.
 */
bool isMerging(std::shared_ptr<Node> node);

/**
 * @brief Determine if a node contains an operator that won't be quantized
 * @param node The node to be checked
 * @return True if the node is not quantized, else false.
 */
bool isNotQuantized(std::shared_ptr<Node> node);

/**
 * @brief Compute the absolute max of a tensor
 * @param tensor The Tensor to process
 */
float getTensorAbsoluteMax(std::shared_ptr<Tensor> tensor);

/**
 * @brief Retrieve the scheduled vector of node of a graphView, without the
 * Producer nodes.
 * @param graphView The graphView containing the nodes
 * @param verbose Whether to print the node vector or not
 * @return The scheduled vector of nodes
 */
std::vector<std::shared_ptr<Node>>
retrieveNodeVector(std::shared_ptr<GraphView> graphView, bool verbose = false);

/**
 * @brief Inserts a scaling node below the given producer node in the graphView.
 * @param node A shared pointer to the producer node where the scaling node will
 * be inserted (below).
 * @param graphView A shared pointer to the graph view in which the nodes are
 * located.
 * @return True if the scaling node was successfully inserted or the scaling
 * factor was accumulated; False otherwise.
 */
void insertScalingBelowProducer(std::shared_ptr<Node> node,
                                std::shared_ptr<GraphView> graphView);

/**
 * @brief Determine whether an input GraphView can be quantized or not.
 * @param graphView The GraphView to be checked.
 * @return True if the GraphView can be quantized, else false.
 */
bool checkArchitecture(std::shared_ptr<GraphView> graphView);

/**
 * @brief Determine the backend of the node taking into account node that do not
 * have a backend (Transpose, Squeeze...)
 */
std::string determineBackend(std::shared_ptr<Aidge::Node> node);

/**
 * @brief Auto assign a isWeighted attribute to each affine node of the graph so
 * that they are caught by the isAffine() function
 * @param graphView the graphView containing the affine nodes
 */
void tagWeightedNodes(std::shared_ptr<GraphView> graphView);

/**
 * @brief Inserts a Quantizer node before all non-optional inputs of the graph.
 *
 * This function ensures that the normalized inputs to the graph are quantized
 * according to the specified precision. For each non-optional input of the
 * graph, a Quantizer node is created and inserted just before the input node.
 * The Quantizer scales, rounds, and casts the input tensor to the target data
 * type, allowing the user to provide normalized data directly.
 *
 * @param graphView A shared pointer to the GraphView representing the
 * computational graph.
 * @param precision The target data type for the Quantizer (e.g., INT8, INT16,
 * etc.).
 *
 * @note Optional inputs of nodes are skipped.
 * @note The Quantizer clamps the values to the min/max range corresponding to
 * the chosen precision.
 * @note After insertion, the data type of the original input node is updated
 * (forwardDType).
 *
 * Example usage:
 * @code
 * auto graphView = std::make_shared<GraphView>(...);
 * insertScalingBeforeInput(graphView, Aidge::DataType::INT8);
 * @endcode
 */
void insertScalingBeforeInput(std::shared_ptr<GraphView> graphView,
                              Aidge::DataType precision);

/**
 * @brief Clears all precision-related attributes from every node in the graph.
 *
 * This function iterates through all nodes in the provided graph and removes
 * any attributes related to quantization precision, specifically:
 * - `"quantization.ptq.precision"`
 * - `"quantization.ptq.accumulationprecision"`
 *
 * It is typically used to reset or reinitialize the graph before running
 * a new quantization or precision assignment pass.
 *
 * @param graphView Shared pointer to a GraphView instance representing the
 * graph to modify.
 *
 * @note Only nodes that have these attributes will be modified; other nodes
 * remain unchanged.
 *
 * @see GraphView
 * @see DataType
 */
void clearAllNodePrecision(std::shared_ptr<GraphView> graphView);

/**
 * @brief Displays precision information for each node in a graph for PTQ
 * debugging.
 *
 * This function iterates over all nodes in the given graph and logs the
 * precision attributes associated with each node (`precision` and
 * `accumulationprecision`) if available. If a node is missing both attributes,
 * a warning is emitted indicating that the node may be invalid for
 * quantization.
 *
 * The main purpose is to help diagnose configuration issues related to
 * precision in Post-Training Quantization (PTQ) workflows.
 *
 * @param graphView Shared pointer to a GraphView instance representing the
 * graph to inspect.
 *
 * @note The attributes checked for each node are:
 *  - `"quantization.ptq.precision"`
 *  - `"quantization.ptq.accumulationprecision"`
 *
 * @warning If a node lacks both precision attributes, a warning message is
 * logged.
 *
 * @see GraphView
 * @see Log
 * @see DataType
 */
void displayPrecisionTag(std::shared_ptr<GraphView> graphView);

/**
 * @brief Automatically assigns precision attributes to nodes in a computation
 * graph.
 *
 * This function traverses all nodes in the given graph and tags each one with
 * precision-related attributes used for quantization (e.g., INT8, FLOAT32,
 * etc.). The function distinguishes between activation, weight, and bias
 * precisions, and automatically sets the correct precision depending on the
 * node type (affine, merging, or producer).
 *
 * - Nodes that already have a `"quantization.ptq.precision"` attribute are
 * skipped.
 * - "Producer" nodes (e.g., graph inputs) are not modified.
 * - For affine nodes, the corresponding parent nodes (weights and biases)
 *   are also tagged with their respective precisions.
 * - Each node receives both `"quantization.ptq.precision"` and, when
 * applicable,
 *   `"quantization.ptq.accumulationprecision"` attributes.
 *
 * @param graphView Shared pointer to the computation graph to annotate.
 * @param ActPrecision  Data type representing the precision of activations
 * (e.g., INT8, FLOAT32).
 * @param WeightPrecision Data type representing the precision of weights.
 * @param BiasPrecision Data type representing the precision of biases and
 * accumulation.
 *
 * @note This function only assigns metadata tags — it does not perform actual
 * quantization or data casting. It **must** be called before invoking the main
 * quantization pipeline, unless the user prefers to manually tag every node
 * with the required precision attributes. In that case, the user is fully
 * responsible for ensuring the consistency and correctness of these manually
 * assigned tags.
 *
 */
void autoAssignNodePrecision(std::shared_ptr<GraphView> graphView,
                             DataType ActPrecision,
                             DataType WeightPrecision,
                             DataType BiasPrecision);

/**
 * @brief Ensure that all nodes in the graph are correctly tagged with valid
 * precision attributes.
 *
 * This function verifies that every node within the provided graph has proper
 * precision tags required for post-training quantization (PTQ). Specifically,
 * it checks that:
 * - Each node has the attribute `"quantization.ptq.precision"`.
 * - The associated precision type is integer (floating-point types are not
 * allowed).
 * - If the node is affine (e.g., a linear operation), it also has the attribute
 *   `"quantization.ptq.accumulationprecision"`, which must also be of integer
 * type.
 *
 * If `verbose` is set to `true`, the function will first call
 * `displayPrecisionTag()` to print the current precision configuration of all
 * nodes in the graph.
 *
 * Any node missing required attributes or incorrectly tagged with
 * floating-point types will trigger an `AIDGE_ASSERT` failure, aborting the
 * quantization process. To automatically assign missing precision tags, use
 * `auto_assign_node_precision()`.
 *
 * @param graphView Shared pointer to the graph view (`GraphView`) whose nodes
 * will be checked.
 * @param verbose If `true`, display current precision tags before performing
 * validation.
 *
 * @throws AIDGE_ASSERT if:
 * - a node lacks the `"quantization.ptq.precision"` attribute,
 * - a node is tagged with a floating-point precision,
 * - an affine node lacks the `"quantization.ptq.accumulationprecision"`
 * attribute,
 * - or that accumulation precision is floating-point.
 *
 * @note This function does not modify the graph; it only validates tag
 * consistency.
 * @see displayPrecisionTag(), auto_assign_node_precision()
 */
void checkPrecisionTag(std::shared_ptr<GraphView> graphView, bool verbose);

/**
 * @brief Prepare a network before the quantization is applied to it, by
 * removing, replacing or fusing the nodes that are not supported by the PTQ
 * pipeline.
 * @param graphView The network to prepare for the quantization
 */
void prepareNetwork(std::shared_ptr<GraphView> graphView);

/**
 * @brief Insert a scaling node after each affine node of the GraphView.
 * Also insert a scaling node in every purely residual branches.
 * @param graphView The GraphView containing the affine nodes.
 */
void insertScalingNodes(std::shared_ptr<GraphView> graphView);

/**
 * @brief Normalize the parameters of each parametrized node, so that they fit
 * in the [-1:1] range.
 * @param graphView The GraphView containing the parametrized nodes.
 */
void normalizeParameters(std::shared_ptr<GraphView> graphView);

/**
 * @brief Compute the activation ranges of every affine node, given an input
 * dataset.
 * @param graphView The GraphView containing the affine nodes, on which the
 * inferences are performed.
 * @param calibrationSet The calibration dataset, consisting of a vector of
 * input samples.
 * @param scalingNodesOnly Whether to restrain the retrieval of the ranges to
 * scaling nodes only or not.
 * @return A map associating each affine node name to it's corresponding output
 * range.
 */
std::unordered_map<std::shared_ptr<Node>, float>
computeRanges(std::shared_ptr<GraphView> graphView,
              const std::vector<std::shared_ptr<Tensor>> &calibrationSet,
              bool scalingNodesOnly);

/**
 * @brief Normalize the activations of each affine node so that they fit in the
 * [-1:1] range. This is done by reconfiguring the scaling nodes, as well as
 * rescaling the weights and biases tensors.
 * @param graphView The GraphView containing the affine nodes.
 * @param valueRanges The node output value ranges computed over the calibration
 * dataset.
 */
void normalizeActivations(
    std::shared_ptr<GraphView> graphView,
    std::unordered_map<std::shared_ptr<Node>, float> valueRanges);

/**
 * @brief For each node, compute the sign of its input and output values.
 * The goal of the routine is to maximize the number of unsigned IOs in order to
 * float the value resolution when possible.
 * @param graphView The GraphView to analyze.
 * @param verbose Whether to print the sign map or not.
 * @return A map associating a pair of sign to each node of the GraphView (a
 * sign for the input and one for the output).
 */
std::unordered_map<std::shared_ptr<Node>, std::pair<bool, bool>>
computeSignMap(std::shared_ptr<GraphView> graphView, bool verbose);

/**
 * @brief Quantize an already normalized (in term of parameters and activations)
 * network.
 * @param graphView The GraphView to be quantized.
 * @param noQuant Whether to apply the rounding operations or not.
 * @param optimizeSigns Whether to take account of the IO signs of the operators
 * or not.
 * @param verbose Whether to print the sign map or not.
 */
void quantizeNormalizedNetwork(std::shared_ptr<GraphView> graphView,
                               bool noQuant,
                               bool optimizeSigns,
                               bool verbose);

/**
 * @brief Given a quantized network, compute the dequantization ratios by
 * iterating through the graph and append a multiplier node at each network
 * output in order to revert the global scaling constants induced by all the
 * quantizers. Note that this operation must be performed before the graph
 * folding.
 * @param graphView The GraphView to be dequantized.
 * @param fakeQuantize Whether we use fake quantization or not
 */
void performDequantization(std::shared_ptr<GraphView> graphView,
                           bool fakeQuantize);

/**
 * @brief Inserts compensation multiplier nodes before quantizers when needed.
 *
 * This function traverses the given computation graph and inserts a
 * compensation node (i.e., a multiplicative node with a constant factor) before
 * quantizer nodes when certain conditions are met.
 *
 * @param graphView The graph on which to operate.
 */
void insertCompensationNodes(std::shared_ptr<GraphView> graphView,
                             bool noQuant);

/**
 * @brief Apply single-shift scaling factor approximation to quantizers.
 *
 * Replace each quantizer’s scaling factor with the nearest power-of-two
 * and compensate the ratio on its affine parent’s weights (and bias if
 * present).
 *
 * @param graphView Graph on which to apply the approximation.
 */
void performSingleShiftApproximation(std::shared_ptr<GraphView> graphView);

/**
 * @brief Take a quantized GraphView represented in floating precision and cast
 * it to the desired target precision. If single-shift option is set to True,
 * the scaling nodes contained in the activation quantizers are replaced with
 * bit-shifts.
 * @param graphView The GraphView to modify.
 * @param singleShift If set to True, replace the scaling-factors by bit-shifts.
 * @param dequantize Whether to dequantize the outputs of the network or not.
 */
void castQuantizedNetwork(std::shared_ptr<GraphView> graphView,
                          bool singleShift,
                          bool dequantize);

/**
 * @brief Main quantization routine. Performs every step of the quantization
 * pipeline.
 * @param graphView The GraphView to be quantized.
 * @param calibrationSet The calibration dataset used for the activations
 * calibration.
 * @param clippingMode: Type of the clipping optimization. Can be either 'MAX',
 * 'MSE', 'AA' or 'KL'.
 * @param noQuant Whether to apply the rounding operations or not.
 * @param optimizeSigns Whether to take account of the IO signs of the operators
 * or not.
 * @param singleShift Whether to convert the scaling factors into powers of two.
 * If true the approximations are compensated using the previous nodes
 * parameters.
 * @param foldGraph Whether to fold the parameter quantizers after the
 * quantization or not.
 * @param fakeQuantize Whether apply the cast function to achieve true
 * quantization or not.
 * @param dequantize Whether to dequantize the outputs of the network or not.
 * @param verbose Whether to print internal information about the quantization
 * process or not.
 */
void quantizeNetwork(std::shared_ptr<GraphView> graphView,
                     std::vector<std::shared_ptr<Tensor>> calibrationSet,
                     Clipping clippingMode,
                     bool noQuant,
                     bool optimizeSigns,
                     bool singleShift,
                     bool foldGraph,
                     bool fakeQuantize,
                     bool dequantize,
                     bool verbose);

/**
 * @brief Fold producer quantizers by marking their producers as constant.
 *
 * Set all producer quantizers and their internal producers to constant,
 * then trigger constant folding on the graph.
 *
 * @param graphView Graph to process.
 */
void foldProducerQuantizers(std::shared_ptr<GraphView> graphView);

/**
 * @brief Compute the weight ranges of every affine node. Provided for debugging
 * purposes.
 * @param graphView The GraphView containing the affine nodes.
 * @return A map associating each affine node name to it's corresponding weight
 * range.
 */
std::unordered_map<std::string, float>
getWeightRanges(std::shared_ptr<GraphView> graphView);

/**
 * @brief Clear the affine nodes biases. Provided form debugging purposes.
 * @param graphView The GraphView containing the affine nodes.
 */
void clearBiases(std::shared_ptr<GraphView> graphView);

/**
 * @brief Development and test routine.
 * @param graphView The GraphView under test.
 */
void devPTQ(std::shared_ptr<GraphView> graphView);

} // namespace Aidge

#endif /* AIDGE_QUANTIZATION_QUANTIZATION_PTQ_PTQ_H_ */
