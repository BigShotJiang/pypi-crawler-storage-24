/********************************************************************************
 * Copyright (c) 2023 CEA-List
 *
 * This program and the accompanying materials are made available under the
 * terms of the Eclipse Public License 2.0 which is available at
 * http://www.eclipse.org/legal/epl-2.0.
 *
 * SPDX-License-Identifier: EPL-2.0
 *
 ********************************************************************************/

#ifndef AIDGE_QUANTIZATION_QUANTIZATION_PTQ_CLIP_H_
#define AIDGE_QUANTIZATION_QUANTIZATION_PTQ_CLIP_H_

#include <cstdint> // std::uint8_t
#include <memory>
#include <string>
#include <unordered_map>
#include <vector>

#include "aidge/data/Tensor.hpp"
#include "aidge/graph/GraphView.hpp"

namespace Aidge {
/**
 * @brief Kind of clipping policy to apply during the activation quantization
 */
enum class Clipping { MAX = 1, MSE, AA, KL, SIGMA3, SIGMA4, SIGMA5 };

/**
 * @brief Compute the histograms of the activations of each node in the GV
 * @param valueRange The corresponding output range of each node in the map.
 * @param graphView The GraphView containing the considered nodes.
 * @param calibrationSet The calibration dataset, consisting of a vector of
 * input samples.
 * @return A map associating each node name to it's corresponding activation
 * histogram and NbBits;
 */

std::unordered_map<Aidge::NodePtr, std::tuple<std::vector<std::uint64_t>, int>>
computeHistograms(
    const std::unordered_map<std::shared_ptr<Node>, float> &valueRanges,
    std::shared_ptr<GraphView> graphView,
    const std::vector<std::shared_ptr<Tensor>> &calibrationSet);

/**
 * @brief Given an input activation histogram, compute the optimal clipping
 * value in the sense of the Lp norm.
 * @param histogram: The provided activation histogram.
 * @param nbBits: The quantization number of bits.
 * @param exponent: The exponent of the Lp norm (e.g. 2 for the MSE).
 * @return The optimal clipping value.
 */
float computeMEClipping(const std::vector<std::uint64_t> &histogram,
                        std::uint8_t nbBits,
                        float exponent);

/**
 * @brief Given an input activation histogram, compute the optimal clipping
 * value in the sense of the KL divergence.
 * @param histogram: The provided activation histogram.
 * @param nbBits: The quantization number of bits.
 * @return The optimal clipping value.
 */
float computeKLClipping(const std::vector<std::uint64_t> &histogram,
                        std::uint8_t nbBits);

/**
 * @brief Given an input activation histogram, compute the clipping
 *        value using N-sigma clipping on a normalized [0, 1] range.
 *
 * The function interprets the histogram as a distribution over
 * equally spaced bins in [0, 1], computes the second moment, and
 * returns nSigma * sqrt(mu2).
 *
 * @param histogram The provided activation histogram.
 * @param nSigma    The number of standard deviations (sigma) used
 *                  to determine the clipping threshold.
 * @return          The clipping value.
 */
float computeNSigmaClipping(const std::vector<std::uint64_t> &histogram,
                            float nSigma);

/**
 * @brief Return a corrected map of the provided activation ranges.
 * To do so compute the optimal clipping values for every node and multiply the
 * input ranges by those values. The method used to compute the clippings can be
 * either 'MSE', 'AA', 'KL', 'SIGMA3', 'SIGMA4', or 'MAX'.
 * @param clippingMode The method used to compute the optimal clippings.
 * @param valueRanges The map associating each affine node to its output range.
 * @param nbBits The quantization number of bits.
 * @param graphView The GraphView containing the considered nodes.
 * @param calibrationSet The calibration dataset, consisting of a vector of
 * input samples.
 * @param verbose Whether to print the clipping values or not.
 * @return The corrected map associating each provided node to its clipped
 * range.
 */
std::unordered_map<std::shared_ptr<Node>, float>
adjustRanges(Clipping clippingMode,
             std::unordered_map<std::shared_ptr<Node>, float> valueRanges,
             std::shared_ptr<GraphView> graphView,
             const std::vector<std::shared_ptr<Tensor>> &calibrationSet,
             bool verbose);

} // namespace Aidge

#endif /* AIDGE_QUANTIZATION_QUANTIZATION_PTQ_CLIP_H_ */
