/********************************************************************************
 * Copyright (c) 2023 CEA-List
 *
 * This program and the accompanying materials are made available under the
 * terms of the Eclipse Public License 2.0 which is available at
 * http://www.eclipse.org/legal/epl-2.0.
 *
 * SPDX-License-Identifier: EPL-2.0
 *
 ********************************************************************************/

#ifndef AIDGE_QUANTIZATION_QUANTIZATION_QAT_LSQ_H_
#define AIDGE_QUANTIZATION_QUANTIZATION_QAT_LSQ_H_

#include <cstddef> // std::size_t
#include <memory>

#include "aidge/data/Tensor.hpp"
#include "aidge/graph/GraphView.hpp"

namespace Aidge {
namespace QuantLSQ {

/**
 * @brief Insert the LSQ quantizers in the network and add a the initialization
 * call to the forward stack.
 * @param graphView The GraphView to be trained.
 * @param nbBits The desired number of bits of the LSQ quantization.
 */
void setupQuantizers(std::shared_ptr<GraphView> graphView, size_t nbBits);

/**
 * @brief Clean up a GraphView trained using the LSQ method.
 * All the LSQ nodes are replaced with classical Quantizers, and the output
 * multiplier nodes are absorbed when possible. Hence, the quantization scales
 * are no longer made of floating point values, but of integer ones.
 * @param graphView The GraphView trained using the LSQ method.
 * @param trueIntegers If True, insert Cast nodes so that the kernels are called
 * in integer precision. the quantized operators, so that the kernels used are
 * integer ones.
 */
void postTrainingTransform(std::shared_ptr<GraphView> graphView,
                           bool trueIntegers);

} // namespace QuantLSQ
} // namespace Aidge

#endif /* AIDGE_QUANTIZATION_QUANTIZATION_QAT_LSQ_H_ */
