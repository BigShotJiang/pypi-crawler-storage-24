/********************************************************************************
 * Copyright (c) 2023 CEA-List
 *
 * This program and the accompanying materials are made available under the
 * terms of the Eclipse Public License 2.0 which is available at
 * http://www.eclipse.org/legal/epl-2.0.
 *
 * SPDX-License-Identifier: EPL-2.0
 *
 ********************************************************************************/

#ifndef AIDGE_QUANTIZATION_QUANTIZATION_QAT_SAT_H_
#define AIDGE_QUANTIZATION_QUANTIZATION_QAT_SAT_H_

#include "aidge/graph/GraphView.hpp"
#include "aidge/graph/Node.hpp"
#include "aidge/operator/SAT/DoReFa.hpp"

namespace Aidge {
namespace QuantSAT {

/**
 * @brief Insert a TanhClamp node after every weight producer of the input
 * GraphView.
 * @param graphView The GraphView to be trained.
 */
void insertParamClamping(std::shared_ptr<GraphView> graphView);

/**
 * @brief Insert the ScaleAdjust nodes in the input GraphView.
 * Optionally skip the insertion when the linear node is followed by a batchnorm
 * (as normalization can be handled by it).
 * @param graphView The GraphView to be trained.
 * @param useBatchNorms If True, skip the insertion each time a batchnorm
 * follows the linear node.
 */
void insertParamScalingAdjust(std::shared_ptr<GraphView> graphView,
                              bool useBatchNorms);

/**
 * @brief Insert the TanhClamp and ScaleAdjust nodes for the first phase
 * (pretraining) of the SAT method. Optionally skip the ScaleAdjust insertion
 * when the linear nodes are followed by batchnorm nodes.
 * @param graphView The GraphView to be trained.
 * @param useBatchNorms If True, skip the ScaleAdjust insertion each time a
 * batchnorm follows the linear node.
 */
void insertSATNodes(std::shared_ptr<GraphView> graphView, bool useBatchNorms);

/**
 * @brief Insert the DoReFa parameter quantizers for the second phase
 * (fine-tuning) of the SAT method.
 * @param graphView The GraphView to be trained.
 * @param nbBits The number of bits of the DoRefa scales.
 * @param mode The mode of the DoReFa quantization scheme.
 */
void insertParamQuantizers(std::shared_ptr<GraphView> graphView,
                           size_t nbBits,
                           DoReFaMode mode = DoReFaMode::Symmetric);

/**
 * @brief Insert the CG-PACT activation quantizers for the second phase
 * (fine-tuning) of the SAT method.
 * @param graphView The GraphView to be trained.
 * @param nbBits The number of bits of the CG-PACT scales.
 * @param initAlpha The initial scaling factor of the CG-PACT scales.
 */
void insertActivQuantizers(std::shared_ptr<GraphView> graphView,
                           size_t nbBits,
                           float initAlpha = 1.0);

/**
 * @brief Clean up a GraphView trained using the SAT method.
 * The TanhClamp nodes are folded, the DoReFa and CG-PACT nodes are replaced
 * with classical quantizers, and the ScaleAdjust are absorbed. Hence, the
 * quantization scales are no longer made of floating point values, but of
 * integer ones. Also, the output multiplier nodes are fused when possible.
 * @param graphView The GraphView trained using the SAT method
 * @param trueIntegers If True, insert Cast nodes so that the kernels are called
 * in integer precision.
 */
void postTrainingTransform(std::shared_ptr<GraphView> graphView,
                           bool trueIntegers);

} // namespace QuantSAT
} // namespace Aidge

#endif /* AIDGE_QUANTIZATION_QUANTIZATION_QAT_SAT_H_ */
