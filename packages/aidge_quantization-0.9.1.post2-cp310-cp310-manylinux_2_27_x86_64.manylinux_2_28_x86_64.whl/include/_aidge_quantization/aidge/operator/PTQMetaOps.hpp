/********************************************************************************
 * Copyright (c) 2023 CEA-List
 *
 * This program and the accompanying materials are made available under the
 * terms of the Eclipse Public License 2.0 which is available at
 * http://www.eclipse.org/legal/epl-2.0.
 *
 * SPDX-License-Identifier: EPL-2.0
 *
 ********************************************************************************/
#ifndef AIDGE_QUANTIZATION_QUANTIZATION_PTQ_PTQMETAOPS_H_
#define AIDGE_QUANTIZATION_QUANTIZATION_PTQ_PTQMETAOPS_H_

#include <memory>
#include <string>

#include "aidge/data/Data.hpp"
#include "aidge/graph/GraphView.hpp"
#include "aidge/graph/Node.hpp"

namespace Aidge {

/**
 * @brief Given a Quantizer, multiply it's internal multiplicative coefficient
 * by a value.
 * @param coeff The value of the multiplicative coefficient.
 */
void multiplyScalingFactor(std::shared_ptr<Aidge::Node> quantizer, float coeff);

/**
 * @brief Given a Quantizer, create a copy of it that has a Round node and a
 * Clip node added at its endpoint, and replace the given Quantizer by it (a
 * swap is also done by reference).
 * @param quantizer The quantizer to modify and replace.
 * @param clipMin the min value of the clip node.
 * @param clipMax the max value of the clip node.
 */
void appendRoundClip(std::shared_ptr<Node> quantizer,
                     float clipMin,
                     float clipMax);

/**
 * @brief Given a Quantizer, create a copy of it that has the Round node
 * removed, and replace the given Quantizer by it (a swap is also done by
 * reference).
 * @param quantizer The quantizer to modify and replace.
 */
void removeRound(std::shared_ptr<Node> quantizer);

/**
 * @brief Given a Quantizer, create a copy of it where the Mul node is replaced
 * by a Bit-Shift node, and replace the given Quantizer by it (a swap is also
 * done by reference).
 * @param quantizer The quantizer to modify and replace.
 */
void replaceScalingWithBitShift(std::shared_ptr<Node> quantizer);

/**
 * @brief Change the datatype of the scaling factor of the given quantizer.
 * If a cast node is at the beginning of the micro-graph change its
 * `target_type` attribute. If the Quantizer doesn't have a Aidge::Mul_Op
 * operator this function will be skipped and log a warning.
 * @param quantizer The quantizer to modify.
 * @param newType New data type of the scaling factor.
 */
void setScalingFactorDtype(std::shared_ptr<Node> quantizer,
                           Aidge::DataType newType);

/**
 * @brief Given a Quantizer, set the coefficient of it's Mul node.
 * @param quantizer The quantizer containing the multiplicative node.
 * @param value The new value of the multiplicative coefficient.
 */
void setScalingFactor(std::shared_ptr<Aidge::Node> quantizer, float value);

/**
 * @brief Given a Quantizer, retrieve the coefficient of it's Mul node.
 * @param quantizer The quantizer containing the multiplicative coefficient.
 */
float getScalingFactor(const std::shared_ptr<const Aidge::Node> quantizer);

/**
 * @brief Given a Quantizer containing a Clip node, replace its clipping values.
 * @param quantizer The quantizer containing the Clip node.
 * @param min The min clipping value.
 * @param max The max clipping value.
 */
void setClipRange(std::shared_ptr<Aidge::Node> quantizer, float min, float max);

/**
 * @brief Given a Quantizer, add a Cast node at the beginning of it's
 * micrograph.
 * @param quantizer The quantizer to modify.
 * @param castingType The type we want the cast node to convert data to.
 */
void prependCast(std::shared_ptr<Node> quantizer, Aidge::DataType castingType);

/**
 * @brief Given a Quantizer, add a Cast node at the end of it's micrograph.
 * @param quantizer The Quantizer to modify.
 * @param castingType The type we want the cast node to convert data to.
 */
void appendCast(std::shared_ptr<Node> quantizer, Aidge::DataType castingType);

/**
 * @brief Given a Quantizer, create a copy of it that has Cast nodes inserted at
 * it's IOs, and replace the given Quantizer by it (a swap is also done by
 * reference). The input cast node convert the input data to the internal type,
 * while the output cast convert it back to the external type.
 * @param quantizer The Quantizer to modify and replace.
 * @param externalType The external data type used for the casts.
 */
void castQuantizerIOs(std::shared_ptr<Node> quantizer,
                      Aidge::DataType externalType);

/**
 * @brief Given a Quantizer, add a multiplicative node at the input of it's
 * micrograph to compensate for the Single-Shift Approximation
 * @param quantizer The Quantizer to modify.
 * @param ratio The compensation scaling factor.
 */
void insertCompensation(std::shared_ptr<Node> quantizer, float scaling);

/**
 * @brief Determine whether a Quantizer contains a Compensation node.
 * @param quantizer The Quantizer considered.
 */
bool containsCompensation(std::shared_ptr<Node> quantizer);

/**
 * @brief Given a Quantizer containing a Compensation node, multiply its
 * compensation coefficient by a ratio.
 * @param coeff The multiplicative ratio applied.
 */
void multiplyCompensationFactor(std::shared_ptr<Node> quantizer, float ratio);

} // namespace Aidge

#endif /* AIDGE_QUANTIZATION_QUANTIZATION_PTQ_PTQMETAOPS_H_ */
