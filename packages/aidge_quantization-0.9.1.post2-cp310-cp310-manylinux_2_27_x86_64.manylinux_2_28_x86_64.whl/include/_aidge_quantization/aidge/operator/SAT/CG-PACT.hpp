/********************************************************************************
 * Copyright (c) 2023 CEA-List
 *
 * This program and the accompanying materials are made available under the
 * terms of the Eclipse Public License 2.0 which is available at
 * http://www.eclipse.org/legal/epl-2.0.
 *
 * SPDX-License-Identifier: EPL-2.0
 *
 ********************************************************************************/

#ifndef AIDGE_QUANTIZATION_OPERATOR_CGPACT_H_
#define AIDGE_QUANTIZATION_OPERATOR_CGPACT_H_

#include <cassert>
#include <memory>
#include <vector>

#include "aidge/backend/OperatorImpl.hpp"
#include "aidge/graph/Node.hpp"
#include "aidge/operator/OperatorTensor.hpp"
#include "aidge/operator/Producer.hpp"
#include "aidge/utils/ErrorHandling.hpp"
#include "aidge/utils/Registrar.hpp"
#include "aidge/utils/StaticAttributes.hpp"
#include "aidge/utils/Types.h"

namespace Aidge {

enum class CGPACTAttr { Range };

/**
 * CG-PACT is the activations quantizer for the 2nd training phase
 * (quantization) of the SAT method.
 */
class CGPACT_Op : public OperatorTensorWithImpl<CGPACT_Op> {

  public:
    static constexpr const char *const Type = "CGPACT";
    static constexpr const char *const InputsName[] = {"data_input", "alpha"};
    static constexpr const char *const OutputsName[] = {"data_output"};

  private:
    using Attributes_ = StaticAttributes<CGPACTAttr, size_t>;
    template <CGPACTAttr e> using attr = typename Attributes_::template attr<e>;
    const std::shared_ptr<Attributes_> mAttributes;

  public:
    CGPACT_Op(size_t range = 255)
        : OperatorTensorWithImpl(
              Type, {InputCategory::Data, InputCategory::Param}, 1),
          mAttributes(
              std::make_shared<Attributes_>(attr<CGPACTAttr::Range>(range)))
    {
    }

    /**
     * @brief Copy-constructor. Copy the operator attributes and its output
     * tensor(s), but not its input tensors (the new operator has no input
     * associated).
     * @param op Operator to copy.
     */
    CGPACT_Op(const CGPACT_Op &op)
        : OperatorTensorWithImpl(op),
          mAttributes(std::make_shared<Attributes_>(*op.mAttributes))
    {
    }

    bool forwardDims(bool allowDataDependency = false) override final;

    inline std::shared_ptr<Attributes> attributes() const override
    {
        return mAttributes;
    }
    inline size_t &range() const noexcept
    {
        return mAttributes->getAttr<CGPACTAttr::Range>();
    }
};

inline std::shared_ptr<Node> CGPACT(size_t range = 255,
                                    const std::string &name = "")
{
    auto cgPact =
        std::make_shared<Node>(std::make_shared<CGPACT_Op>(range), name);
    addProducer<1>(cgPact, 1, {1}, "a");
    return cgPact;
}
} // namespace Aidge

namespace {
template <>
const char *const EnumStrings<Aidge::CGPACTAttr>::data[] = {"range"};
}

#endif /* AIDGE_QUANTIZATION_OPERATOR_CGPACT_H_ */
