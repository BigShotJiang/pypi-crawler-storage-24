/********************************************************************************
 * Copyright (c) 2023 CEA-List
 *
 * This program and the accompanying materials are made available under the
 * terms of the Eclipse Public License 2.0 which is available at
 * http://www.eclipse.org/legal/epl-2.0.
 *
 * SPDX-License-Identifier: EPL-2.0
 *
 ********************************************************************************/

#ifndef AIDGE_QUANTIZATION_OPERATOR_SAT_TANHCLAMP_H_
#define AIDGE_QUANTIZATION_OPERATOR_SAT_TANHCLAMP_H_

#include <memory>
#include <set>
#include <string>
#include <vector>

#include "aidge/backend/OperatorImpl.hpp"
#include "aidge/graph/Node.hpp"
#include "aidge/operator/OperatorTensor.hpp"
#include "aidge/utils/Registrar.hpp"
#include "aidge/utils/Types.h"

namespace Aidge {

/**
 * TanhClamp is the weights clamping for the 1st training phase (clamping) of
 * the SAT method.
 */
class TanhClamp_Op : public OperatorTensorWithImpl<TanhClamp_Op> {
  public:
    static constexpr const char *const Type = "TanhClamp";
    static constexpr const char *const InputsName[] = {"data_input"};
    static constexpr const char *const OutputsName[] = {"data_output",
                                                        "scaling"};

    TanhClamp_Op() : OperatorTensorWithImpl(Type, {InputCategory::Data}, 2) {}

    bool forwardDims(bool allowDataDependency = false) override final;
    void setBackend(const std::string &name,
                    DeviceIdx_t device = 0) override final;
};

std::shared_ptr<Node> TanhClamp(const std::string &name = "");

} // namespace Aidge

#endif /* AIDGE_QUANTIZATION_OPERATOR_SAT_TANHCLAMP_H_ */
