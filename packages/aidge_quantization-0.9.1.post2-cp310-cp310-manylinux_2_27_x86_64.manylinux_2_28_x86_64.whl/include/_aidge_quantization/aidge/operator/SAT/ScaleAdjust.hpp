/********************************************************************************
 * Copyright (c) 2023 CEA-List
 *
 * This program and the accompanying materials are made available under the
 * terms of the Eclipse Public License 2.0 which is available at
 * http://www.eclipse.org/legal/epl-2.0.
 *
 * SPDX-License-Identifier: EPL-2.0
 *
 ********************************************************************************/

#ifndef AIDGE_CORE_OPERATOR_SCALEADJUST_H_
#define AIDGE_CORE_OPERATOR_SCALEADJUST_H_

#include <cassert>
#include <memory>
#include <vector>

#include "aidge/backend/OperatorImpl.hpp"
#include "aidge/graph/Node.hpp"
#include "aidge/operator/OperatorTensor.hpp"
#include "aidge/operator/Producer.hpp"
#include "aidge/utils/ErrorHandling.hpp"
#include "aidge/utils/Registrar.hpp"
#include "aidge/utils/StaticAttributes.hpp"
#include "aidge/utils/Types.h"

namespace Aidge {

/**
 * ScaleAdjust (SAT) is the weights scaling for the 1st training phase
 * (clamping) of the SAT method. Since the whole method is called SAT in Aidge,
 * we use ScaleAdjust for the SAT operator.
 *
 * From SAT paper ("Towards Efficient Training for Neural Network
 * Quantization"): For MobileNet-V2, we only need to apply SAT to the last
 * fully-connected layer. For other models where convolution is not directly
 * followed by BN such as full pre-activation ResNet, we need to apply SAT to
 * all such convolution layers.
 */
class ScaleAdjust_Op : public OperatorTensorWithImpl<ScaleAdjust_Op> {
  public:
    static constexpr const char *Type = "ScaleAdjust";
    static constexpr const char *const InputsName[] = {"data_input"};
    static constexpr const char *const OutputsName[] = {"data_output",
                                                        "scaling"};

    ScaleAdjust_Op() : OperatorTensorWithImpl(Type, {InputCategory::Data}, 2) {}

    /**
     * @brief Copy-constructor. Copy the operator attributes and its output
     * tensor(s), but not its input tensors (the new operator has no input
     * associated).
     * @param op Operator to copy.
     */
    ScaleAdjust_Op(const ScaleAdjust_Op &op) : OperatorTensorWithImpl(op) {}

    // XXX
    bool forwardDims(bool allowDataDependency = false) override final;
    void setBackend(const std::string &name,
                    DeviceIdx_t device = 0) override final;
};

inline std::shared_ptr<Node> ScaleAdjust(const std::string &name = "")
{
    return std::make_shared<Node>(std::make_shared<ScaleAdjust_Op>(), name);
}
} // namespace Aidge

#endif /* AIDGE_CORE_OPERATOR_SCALEADJUST_H_ */
