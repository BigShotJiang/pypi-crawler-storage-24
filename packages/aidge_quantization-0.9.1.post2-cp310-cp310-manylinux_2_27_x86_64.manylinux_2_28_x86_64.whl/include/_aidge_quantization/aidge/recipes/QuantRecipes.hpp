/********************************************************************************
 * Copyright (c) 2023 CEA-List
 *
 * This program and the accompanying materials are made available under the
 * terms of the Eclipse Public License 2.0 which is available at
 * http://www.eclipse.org/legal/epl-2.0.
 *
 * SPDX-License-Identifier: EPL-2.0
 *
 ********************************************************************************/

#ifndef AIDGE_QUANTIZATION_QUANTRECIPES_H_
#define AIDGE_QUANTIZATION_QUANTRECIPES_H_

#include "aidge/data/Tensor.hpp"
#include "aidge/graph/GraphView.hpp"

namespace Aidge {
/**
 * @brief Remove all the SoftMax leaf nodes of a GraphView.
 * @param graphView The GraphView to process.
 */
void popSoftMax(std::shared_ptr<GraphView> graphView);

/**
 * @brief Given a producer, perform a single step of constant folding over it
 * @param producer The producer to fold.
 * @param graphView The GraphView to process.
 */
void foldSingleProducer(std::shared_ptr<Node> producer,
                        std::shared_ptr<GraphView> graphView);

/**
 * @brief Allow the Quantizers to absorb the scalar multiplications arising
 * before them
 * @param graphView The GraphView to process.
 */
void fuseScalingsAndQuantizers(std::shared_ptr<GraphView> graphView);
} // namespace Aidge

#endif /* AIDGE_QUANTIZATION_QUANTRECIPES_H_ */
