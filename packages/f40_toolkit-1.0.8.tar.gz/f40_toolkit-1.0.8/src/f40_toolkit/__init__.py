"""
f40_toolkit: shared low-level tooling for the 40F Python stack.
"""

from importlib.metadata import PackageNotFoundError, version
import importlib
from typing import Any

try:
    __version__ = version("f40-toolkit")
except PackageNotFoundError:
    __version__ = "0.0.0"


# Keep top-level imports side-effect free.
# Access subpackages via lazy attribute loading:
#   import f40_toolkit
#   f40_toolkit.cache.CacheManager
_LAZY_SUBMODULES = {"common", "config", "logging", "cache"}


def __getattr__(name: str) -> Any:  # PEP 562
    if name in _LAZY_SUBMODULES:
        return importlib.import_module(f"f40_toolkit.{name}")
    raise AttributeError(f"module 'f40_toolkit' has no attribute {name!r}")


__all__ = ["__version__"]
