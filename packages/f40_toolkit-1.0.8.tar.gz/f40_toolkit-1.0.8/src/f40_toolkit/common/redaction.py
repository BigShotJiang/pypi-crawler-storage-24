from __future__ import annotations

from typing import Any, Dict, Iterable, Mapping, Sequence, Set

import re
from .dicts import walk_items

REDACT_SUBSTRINGS = (
    "password",
    "passwd",
    "pwd",
    "secret",
    "token",
    "access_token",
    "refresh_token",
    "id_token",
    "apikey",
    "api_key",
    "client_secret",
    "private_key",
    "ssh_key",
    "certificate",
    "cookie",
    "authorization",
    "bearer",
    "credential",
    "credentials",
)

_TOKEN_SPLIT_RE = re.compile(r"[^a-z0-9]+")

_SENSITIVE_KEY_RE = re.compile(
    r"(^|[_\-\.])("
    r"pass(word)?|passwd|pwd|secret|token|api[_\-]?key|apikey|client[_\-]?secret|"
    r"private[_\-]?key|ssh[_\-]?key|access[_\-]?token|refresh[_\-]?token|id[_\-]?token|"
    r"auth(orization)?|bearer|cookie|cred(ential)?s?"
    r")($|[_\-\.])",
    re.IGNORECASE,
)


def is_sensitive_key(key: str) -> bool:
    lk = key.lower()
    if _SENSITIVE_KEY_RE.search(lk):
        return True

    tokens = [t for t in _TOKEN_SPLIT_RE.split(lk) if t]
    if not tokens:
        return False

    sensitive = set(REDACT_SUBSTRINGS)
    if sensitive.intersection(tokens):
        return True

    # only treat "key" as sensitive when paired with high-signal tokens
    if "key" in tokens and {
        "api",
        "private",
        "ssh",
        "access",
        "signing",
        "encryption",
    }.intersection(tokens):
        return True

    return False


def redact_value(value: Any) -> Any:
    if isinstance(value, str):
        return "*****" if value else value
    if isinstance(value, (dict, list, tuple)):
        return "*****"
    return "*****"


def mask_for_log(d: Dict[str, Any]) -> Dict[str, Any]:
    masked = {}
    for k, v in walk_items(d):
        last = k.split(".")[-1]
        masked[k] = redact_value(v) if is_sensitive_key(last) else v

    out: Dict[str, Any] = {}
    for dotted, v in masked.items():
        parts = dotted.split(".") if dotted else []
        if not parts:
            continue
        cur: Any = out
        for i, p in enumerate(parts):
            is_last = i == len(parts) - 1
            if is_last:
                if isinstance(cur, dict):
                    cur[p] = v
            else:
                nxt = cur.get(p) if isinstance(cur, dict) else None
                if not isinstance(nxt, dict):
                    nxt = {}
                    if isinstance(cur, dict):
                        cur[p] = nxt
                cur = nxt
    return out


def sanitize_config(
    obj: Any,
    *,
    sensitive_substrings: Iterable[str] = REDACT_SUBSTRINGS,
) -> Any:
    """
    Recursively walk a nested structure (dicts/lists) and replace values whose
    *key* name contains a sensitive substring with "***".
    """
    sensitive = set(sensitive_substrings)

    if isinstance(obj, Mapping):
        out = {}
        for k, v in obj.items():
            kl = str(k).lower()
            if any(sub in kl for sub in sensitive) or is_sensitive_key(kl):
                out[k] = "***"
            else:
                out[k] = sanitize_config(v, sensitive_substrings=sensitive)
        return out

    if isinstance(obj, Sequence) and not isinstance(obj, (str, bytes, bytearray)):
        return [sanitize_config(v, sensitive_substrings=sensitive) for v in obj]

    return obj
