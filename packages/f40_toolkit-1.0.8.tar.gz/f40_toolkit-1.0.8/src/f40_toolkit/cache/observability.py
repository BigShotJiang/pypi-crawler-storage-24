from __future__ import annotations

from typing import Any, TYPE_CHECKING
import logging

# Keep this module dependency-free w.r.t. CacheManager to avoid circular imports.
if TYPE_CHECKING:  # pragma: no cover
    from .manager import CacheManager

# IMPORTANT: never trigger logging configuration at import time.
cache_log = logging.getLogger("f40.cache")
health_log = logging.getLogger("f40.cache.health")


def log_get(key: str, hit: bool) -> None:
    cache_log.debug("GET %s hit=%s", key, hit)


def log_set(key: str, ttl: int | None) -> None:
    cache_log.debug("SET %s ttl=%s", key, ttl)


def log_del(key: str) -> None:
    cache_log.debug("DEL %s", key)


def check_cache_health(
    cache: "CacheManager", *, key: str = "__health__", timeout: int = 5
) -> bool:
    """
    Simple healthcheck for the cache subsystem.

    Returns True if everything works, False otherwise.
    """
    try:
        sentinel_value = "ok"
        cache.set(key, sentinel_value, timeout)
        value: Any = cache.get(key)
        if value != sentinel_value:
            health_log.warning(
                "Cache healthcheck mismatch: %r != %r", value, sentinel_value
            )
            return False
        try:
            cache.invalidate(key)
        except Exception:
            pass
        return True
    except Exception as e:
        health_log.warning("Cache healthcheck failed: %s", e)
        return False
