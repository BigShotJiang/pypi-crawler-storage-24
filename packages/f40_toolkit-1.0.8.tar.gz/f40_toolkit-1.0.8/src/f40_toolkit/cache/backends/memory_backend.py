from __future__ import annotations

import threading
import time
from fnmatch import fnmatchcase
from typing import Any, Dict, Optional

from f40_toolkit.cache.interfaces import CacheBackend


class MemoryCacheBackend(CacheBackend):
    """
    In-process cache with TTL. Thread-safe (RLock).
    Values are stored directly (no serialization).

    TTL is an effective ttl from CacheManager:
        None  -> no expiry
        <=0   -> do not cache
        >0    -> expire in ttl seconds
    """

    def __init__(self):
        self._lock = threading.RLock()
        self._data: Dict[str, tuple[float | None, Any]] = {}
        self._MISSING = object()

    @staticmethod
    def _now() -> float:
        return time.time()

    def get(self, key: str) -> Any:
        with self._lock:
            exp, val = self._data.get(key, (None, self._MISSING))
            if val is self._MISSING:
                raise KeyError(key)
            if exp is not None and self._now() > exp:
                self._data.pop(key, None)
                raise KeyError(key)
            return val

    def set(self, key: str, value: Any, ttl: Optional[int]) -> None:
        if ttl is not None:
            ttl = int(ttl)

        if ttl is not None and ttl <= 0:
            self.invalidate(key)
            return

        exp = None if ttl is None else self._now() + ttl
        with self._lock:
            self._data[key] = (exp, value)

    def invalidate(self, key: str) -> None:
        with self._lock:
            self._data.pop(key, None)

    def clear(self) -> None:
        with self._lock:
            self._data.clear()

    def keys(self, pattern: Optional[str] = None) -> list[str]:
        with self._lock:
            now = self._now()

            # purge expired
            expired = [
                k
                for k, (exp, _val) in self._data.items()
                if exp is not None and now > exp
            ]
            for k in expired:
                self._data.pop(k, None)

            keys = list(self._data.keys())
            if pattern:
                keys = [k for k in keys if fnmatchcase(k, pattern)]
            return keys
