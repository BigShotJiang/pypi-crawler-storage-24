from __future__ import annotations

from typing import Any, Callable, Dict, List, Optional

from .interfaces import CacheBackend
from .timeouts import Timeout, DEFAULT_TIMEOUT, resolve_timeout
from .errors import InvalidCacheValue

from .observability import log_get, log_set, log_del


class CacheManager:
    """
    Thin facade over a backend. Adds:
      - default timeout (resolved here; backends receive an effective ttl)
      - get_or_set helper
      - observability logging (GET/SET/DEL)

    Error semantics:
      - Missing keys raise KeyError
      - Corrupt/unusable cached values raise InvalidCacheValue in the backend,
        but by default CacheManager treats them as a miss (invalidate + KeyError).
        Set strict_cache_values=True to surface InvalidCacheValue to callers.
    """

    def __init__(
        self,
        backend: CacheBackend,
        default_timeout: Optional[int] = 300,
        *,
        strict_cache_values: bool = False,
    ):
        self.backend = backend
        self.default_timeout = default_timeout
        self.strict_cache_values = strict_cache_values

    def get(self, key: str) -> Any:
        try:
            value = self.backend.get(key)
            log_get(key, hit=True)
            return value
        except KeyError:
            log_get(key, hit=False)
            raise
        except InvalidCacheValue as e:
            # Corrupt entry: invalidate and treat as miss by default.
            # Even in strict mode, we still invalidate to avoid repeated failures.
            try:
                self.backend.invalidate(key)
                log_del(key)
            except Exception:
                # Best-effort invalidation; don't hide the original error.
                pass

            log_get(key, hit=False)

            if self.strict_cache_values:
                raise
            raise KeyError(key) from e

    def set(self, key: str, value: Any, timeout: Timeout = DEFAULT_TIMEOUT) -> None:
        ttl = resolve_timeout(timeout, self.default_timeout)

        # normalize ints if provided
        if ttl is not None:
            ttl = int(ttl)

        # ttl semantics:
        #   None  -> no expiry
        #   <=0   -> do not cache (delete existing and return)
        #   >0    -> cache for ttl seconds
        if ttl is not None and ttl <= 0:
            log_set(key, ttl)
            self.backend.invalidate(key)
            log_del(key)
            return

        log_set(key, ttl)
        self.backend.set(key, value, ttl)

    def invalidate(self, key: str) -> None:
        log_del(key)
        self.backend.invalidate(key)

    def clear(self) -> None:
        self.backend.clear()

    def get_or_set(
        self,
        key: str,
        func: Callable[..., Any],
        f_args: Optional[List[Any]] = None,
        f_kwargs: Optional[Dict[str, Any]] = None,
        timeout: Timeout = DEFAULT_TIMEOUT,
        default: Any = None,
        use_default_instead_of_compute: bool = False,
    ) -> Any:
        f_args = f_args or []
        f_kwargs = f_kwargs or {}

        try:
            return self.get(key)
        except KeyError:
            if use_default_instead_of_compute and default is not None:
                return default

            result = func(*f_args, **f_kwargs)
            self.set(key, result, timeout)
            return result

    def keys(self, pattern: Optional[str] = None) -> list[str]:
        """
        List currently stored keys for this cache backend.

        `pattern` uses glob syntax: *, ?, [seq]
        Examples:
          - keys("user:*")
          - keys("ns:project:?")
        """
        return self.backend.keys(pattern=pattern)
