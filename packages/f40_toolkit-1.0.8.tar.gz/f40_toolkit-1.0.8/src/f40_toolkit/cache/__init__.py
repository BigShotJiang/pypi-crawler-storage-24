"""f40_toolkit.cache

Public cache API.

The implementation is split across multiple submodules, but we keep a small,
convenient import surface here and load submodules lazily to avoid import-time
side effects.
"""

from __future__ import annotations

import importlib
from typing import Any


__all__ = [
    # main facade
    "CacheManager",
    "create_cache_from_config",

    # backends
    "MemoryCacheBackend",
    "FileCacheBackend",
    "RedisCacheBackend",

    # key utilities
    "KeyBuilder",
    "default_builder",

    # timeouts
    "DEFAULT_TIMEOUT",
    "Timeout",

    # observability
    "check_cache_health",

    # errors
    "CacheError",
    "CacheConfigurationError",
    "CachePrefixError",
    "InvalidCacheValue",
]


_LAZY: dict[str, str] = {
    # facade
    "CacheManager": "f40_toolkit.cache.manager",
    "create_cache_from_config": "f40_toolkit.cache.factory",

    # backends
    "MemoryCacheBackend": "f40_toolkit.cache.backends.memory_backend",
    "FileCacheBackend": "f40_toolkit.cache.backends.file_backend",
    "RedisCacheBackend": "f40_toolkit.cache.backends.redis_backend",

    # key utilities
    "KeyBuilder": "f40_toolkit.cache.keys",
    "default_builder": "f40_toolkit.cache.keys",

    # timeouts
    "DEFAULT_TIMEOUT": "f40_toolkit.cache.timeouts",
    "Timeout": "f40_toolkit.cache.timeouts",

    # observability
    "check_cache_health": "f40_toolkit.cache.observability",

    # errors
    "CacheError": "f40_toolkit.cache.errors",
    "CacheConfigurationError": "f40_toolkit.cache.errors",
    "CachePrefixError": "f40_toolkit.cache.errors",
    "InvalidCacheValue": "f40_toolkit.cache.errors",
}


def __getattr__(name: str) -> Any:
    mod = _LAZY.get(name)
    if not mod:
        raise AttributeError(name)
    module = importlib.import_module(mod)
    return getattr(module, name)
