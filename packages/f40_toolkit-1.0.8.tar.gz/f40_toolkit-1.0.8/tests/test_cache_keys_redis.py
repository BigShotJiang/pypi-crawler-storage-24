from __future__ import annotations

import os
import uuid

import pytest

redis = pytest.importorskip("redis")  # skips if redis-py isn't installed

from f40_toolkit.cache.backends.redis_backend import RedisCacheBackend
from f40_toolkit.cache.serializers import JsonSerializer


def _get_redis_client():
    url = os.getenv("REDIS_URL")
    if not url:
        pytest.skip("REDIS_URL not set (e.g. redis://localhost:6379/0)")

    try:
        # keep bytes (decode_responses=False) because your backend uses bytes serializer
        client = redis.Redis.from_url(url, decode_responses=False)
        client.ping()
        return client
    except Exception as e:
        pytest.skip(f"Cannot connect to Redis at REDIS_URL={url!r}: {e}")


def test_redis_backend_keys_lists_only_own_keys_and_strips_prefix():
    r = _get_redis_client()

    # unique prefix per test run to avoid collisions
    prefix = f"pytest-f40:{uuid.uuid4().hex}:"
    backend = RedisCacheBackend(
        r,
        prefix=prefix,
        serializer=JsonSerializer(),
        test_connection=True,
    )

    # Ensure a clean slate for this prefix
    backend.clear()

    # Add a key outside the prefix (must survive backend.clear())
    other_key = f"otherprefix:{uuid.uuid4().hex}"
    r.set(other_key, b"outside")

    # Add keys in our backend
    backend.set("a", {"n": 1}, ttl=60)
    backend.set("b", "v", ttl=60)

    got = set(backend.keys())
    assert got == {"a", "b"}

    # Ensure keys are returned WITHOUT prefix
    assert all(not k.startswith(prefix) for k in got)

    # Ensure actual stored keys exist WITH prefix
    assert r.exists(f"{prefix}a") == 1
    assert r.exists(f"{prefix}b") == 1

    # Clear only our prefix keys; other_key must remain
    backend.clear()
    assert backend.keys() == []
    assert r.exists(other_key) == 1

    backend.set("ns:a", 1, ttl=60)
    backend.set("ns:b", 2, ttl=60)
    backend.set("other:x", 3, ttl=60)

    assert set(backend.keys("ns:*")) == {"ns:a", "ns:b"}
    assert set(backend.keys("other:*")) == {"other:x"}
    assert set(backend.keys("ns:a")) == {"ns:a"}

    # cleanup
    r.delete(other_key)
