"""Public package surface for ShogiArena."""

__version__ = "0.3.1"

__all__ = ["__version__"]
