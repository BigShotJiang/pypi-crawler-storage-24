"""Game runtime orchestration adapter implementations."""

__all__: list[str] = []
