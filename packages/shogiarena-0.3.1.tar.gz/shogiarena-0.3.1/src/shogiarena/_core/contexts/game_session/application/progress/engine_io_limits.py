"""Shared limits for engine I/O tail retention in progress snapshots."""

from __future__ import annotations

ENGINE_IO_TAIL_LIMIT = 200

__all__ = ["ENGINE_IO_TAIL_LIMIT"]
