"""Game runtime application services."""

__all__: list[str] = []
