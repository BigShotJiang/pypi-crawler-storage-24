## contexts

Bounded context containers. Each context follows the structure:

- `domain`
- `application`
- `ports`
- `adapters`

