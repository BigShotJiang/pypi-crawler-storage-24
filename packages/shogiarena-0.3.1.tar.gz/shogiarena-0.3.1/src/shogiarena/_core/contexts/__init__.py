"""Bounded contexts for ShogiArena domain decomposition."""

__all__: list[str] = []
