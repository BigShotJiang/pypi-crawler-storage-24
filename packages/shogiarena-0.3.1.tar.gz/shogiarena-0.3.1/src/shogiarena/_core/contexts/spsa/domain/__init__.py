"""SPSA domain models."""

__all__: list[str] = []
