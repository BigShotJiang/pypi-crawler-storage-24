"""Match context adapters."""

__all__: list[str] = []
