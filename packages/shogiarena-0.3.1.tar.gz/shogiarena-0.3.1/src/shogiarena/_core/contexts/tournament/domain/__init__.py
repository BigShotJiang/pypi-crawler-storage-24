"""Tournament domain models and invariants."""

__all__: list[str] = []
