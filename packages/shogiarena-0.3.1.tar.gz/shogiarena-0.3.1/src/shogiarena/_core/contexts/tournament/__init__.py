"""Tournament bounded context entrypoint."""

__all__: list[str] = []
