"""Tournament ports (driven/driving and driven/outer) API contracts."""

__all__: list[str] = []
