"""External interface adapters for CLI and dashboard entrypoints."""

__all__: list[str] = []
