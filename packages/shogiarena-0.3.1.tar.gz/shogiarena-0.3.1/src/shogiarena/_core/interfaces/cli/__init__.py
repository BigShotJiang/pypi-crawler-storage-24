"""CLI interface adapters."""

__all__: list[str] = []
