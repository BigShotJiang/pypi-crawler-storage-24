"""Interface boundary adapters."""
