"""Boundary parsers for interface/adapters."""
