## interfaces

This layer owns inbound/outbound adapters for user and external interfaces.

- `cli`: command interfaces and argument wiring
- `dashboard`: API server and UI-facing handlers

