"""Shogi Arena core package.

This package provides the N-engine tournament components under
`shogiarena.arena` and the dashboard utilities under
`shogiarena._core.interfaces.dashboard`.
"""

__version__ = "0.3.1"

__all__: list[str] = []
