"""Public runtime wiring helpers."""

from shogiarena._core.interfaces.composition_root.default_root import DefaultRoot, build_default_root

__all__ = ["DefaultRoot", "build_default_root"]
