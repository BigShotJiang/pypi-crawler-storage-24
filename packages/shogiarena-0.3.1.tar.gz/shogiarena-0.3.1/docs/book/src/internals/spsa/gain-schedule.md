# ゲインスケジュール

> **前提知識**: [SPSA](./index.md)、[勾配推定と摂動](./gradient.md)

## このページの要点

- ゲインスケジュールは SPSA の収束速度と安定性を制御する **2 つの減衰系列** \\(a_k\\) と \\(c_k\\) で構成される
- \\(a_k\\) はステップサイズ（学習率）を、\\(c_k\\) は摂動の大きさを制御する
- Spall の推奨値（\\(\alpha = 0.602, \gamma = 0.101\\)）は漸近的最適だが、ShogiArena では固定ゲイン（\\(\alpha = \gamma = 0\\)）をデフォルトとする
- \\(A\\) パラメータは初期の不安定性を緩和する「ウォームアップ」として機能する

## 2 つのゲイン系列

SPSA の更新式には 2 つの系列パラメータが登場します。

### ステップサイズゲイン \\(a_k\\)

\\[
a_k = \frac{a_0}{(A + k)^\alpha}
\\]

パラメータ更新の「幅」を決めます。大きいと早く収束しますが不安定になります。

### 摂動スケール \\(c_k\\)

\\[
c_k = \frac{c_0}{k^\gamma}
\\]

勾配推定のための摂動の「大きさ」を決めます。小さいとバイアスが減りますが分散が増えます。

### パラメータの意味

| パラメータ | 意味 | ShogiArena デフォルト | Spall 推奨 |
|:---:|:---|:---:|:---:|
| \\(a_0\\) | 初期ステップサイズ（`mobility` に相当） | 1.0 | 問題依存 |
| \\(A\\) | ウォームアップ定数 | max(1, 0.1·N) | 0.1·N |
| \\(\alpha\\) | ステップサイズ減衰指数 | 0.0 | 0.602 |
| \\(c_0\\) | 初期摂動スケール（`scale` に相当） | 1.0 | 問題依存 |
| \\(\gamma\\) | 摂動スケール減衰指数 | 0.0 | 0.101 |

ここで \\(N\\) は総更新回数（`num_updates`）です。

## 実装

```python
k = int(update_idx)  # 1-based 反復番号
a0 = float(getattr(self.config, "a0", self.config.mobility))
A = float(self.config.A or max(1.0, 0.1 * float(self.config.num_updates)))
alpha = float(self.config.alpha)
gamma = float(self.config.gamma)

a_k = a0 / ((A + k) ** alpha)      # ステップサイズゲイン
c_k_raw = c0 / (k ** gamma)         # 摂動スケール

# Integer パラメータの下限を適用
if any(p.type == "int" and not p.not_used for p in params):
    c_k = max(c_k_raw, self.config.int_ck_floor)
else:
    c_k = c_k_raw
```

## 固定ゲイン vs 減衰ゲイン

### 固定ゲイン（\\(\alpha = \gamma = 0\\)）

\\[
a_k = \frac{a_0}{A + k} \cdot (A + k) = a_0 \qquad c_k = c_0
\\]

- \\(\alpha = 0\\) のとき \\(a_k = a_0 / (A + k)^0 = a_0\\)（定数）
- \\(\gamma = 0\\) のとき \\(c_k = c_0 / k^0 = c_0\\)（定数）

```text
ゲイン
  │
  │ ━━━━━━━━━━━━━━━━━━━━━━━━  a_k = a_0（固定）
  │
  │ ━━━━━━━━━━━━━━━━━━━━━━━━  c_k = c_0（固定）
  │
  └──────────────────────────→ 反復 k
```

**利点**: パラメータが少なく調整が容易。非定常環境（目的関数が変化する場合）に適応できる

**欠点**: 厳密な意味での収束は保証されない（振動が残る可能性）

### 減衰ゲイン（Spall 推奨値）

\\(\alpha = 0.602, \gamma = 0.101\\) の場合：

```text
ゲイン
  │╲
  │  ╲
  │    ╲                        a_k: α=0.602 で急速に減衰
  │      ╲╲
  │         ╲╲╲╲
  │ ─────────────────────────   c_k: γ=0.101 でゆっくり減衰
  │                ─ ─ ─ ─ ─
  └──────────────────────────→ 反復 k
```

**利点**: 漸近的に最適な収束率を達成する（Spall の理論保証）

**欠点**: パラメータ \\(a_0, A\\) の調整が難しい。初期値が不適切だと収束が遅くなる

### ShogiArena でのデフォルト選択

ShogiArena は **固定ゲイン**（\\(\alpha = \gamma = 0\\)）をデフォルトとしています。理由:

1. **エンジンテストのノイズが大きい**: 対局結果の分散が大きく、減衰ゲインの理論的な利点が発揮されにくい
2. **更新回数が限られる**: 数百〜数千回の更新では、漸近的な性質よりも有限サンプルでの性能が重要
3. **実践的な調整の容易さ**: `mobility` と `scale` の 2 パラメータだけで制御でき、設定ミスのリスクが低い

## \\(A\\) パラメータの役割

\\(A\\) は初期の不安定性を緩和するウォームアップ定数です。

\\[
a_k = \frac{a_0}{(A + k)^\alpha}
\\]

- \\(A = 0\\): \\(k = 1\\) から完全なゲインで開始
- \\(A = 100\\): \\(k = 1\\) での実効ゲインは \\(a_0 / 101^\alpha\\)

```text
a_k の推移（α=0.602 固定、A を変化）

ゲイン
  │╲  A=0（急速に減衰）
  │  ╲╲
  │  │ ╲╲
  │  │    ╲╲╲╲
  │  ╲       ─────
  │    ╲  A=100（緩やかに減衰）
  │      ╲╲
  │         ╲╲╲╲
  │               ─────
  └──────────────────────────→ 反復 k
```

Spall の推奨は \\(A \approx 0.1 \cdot N\\)（総更新回数の 10%）です。

```python
A = float(self.config.A or max(1.0, 0.1 * float(self.config.num_updates)))
```

## 設定ガイド

### 基本方針

1. **まず固定ゲインで開始**: \\(\alpha = \gamma = 0\\)
2. **mobility を調整**: 1 回の更新でパラメータが大きく変動しないか確認
3. **必要に応じて減衰を導入**: 収束近くで振動する場合に \\(\alpha > 0\\)

### 推奨設定パターン

| ケース | \\(a_0\\) | \\(A\\) | \\(\alpha\\) | \\(\gamma\\) | 説明 |
|:---|:---:|:---:|:---:|:---:|:---|
| 探索的チューニング | 1.0 | 0 | 0.0 | 0.0 | パラメータ空間を広く探索 |
| 安定チューニング | 0.5 | 100 | 0.0 | 0.0 | 既知の良い値の近くで微調整 |
| 理論的最適 | 0.5 | 0.1N | 0.602 | 0.101 | 漸近的に最適な収束率 |
| 保守的 | 0.1 | 0.1N | 0.602 | 0.101 | 安全だが収束は遅い |

### mobility（全体学習率）の目安

`mobility` はすべてのパラメータに共通のスケーリング係数です。

- **mobility = 1.0**: 標準。`delta` パラメータのみで個別調整
- **mobility = 0.5**: 保守的。振動が気になる場合に
- **mobility = 2.0**: 積極的。収束が遅い場合に

### delta（パラメータ固有スケール）の目安

各パラメータの `delta` は、そのパラメータの「感度」に応じて設定します。

```text
高感度パラメータ（小さな変化で勝率に大きく影響）:
  → delta を小さく（0.001〜0.002）

低感度パラメータ（大きな変化でも勝率への影響が小さい）:
  → delta を大きく（0.005〜0.01）
```

## ゲインスケジュールの収束条件

SPSA が確率的に収束するための十分条件（Robbins-Monro 条件）:

\\[
\sum_{k=1}^{\infty} a_k = \infty \qquad \sum_{k=1}^{\infty} a_k^2 < \infty
\\]

\\[
c_k \to 0 \qquad \sum_{k=1}^{\infty} \frac{a_k^2}{c_k^2} < \infty
\\]

\\(\alpha = 0.602, \gamma = 0.101\\) はこれらの条件を満たす最も効率的な値として Spall が導出しました。

> **注**: 固定ゲイン（\\(\alpha = 0\\)）ではこれらの条件は満たされません。
> しかし実用上は、有限回の更新で十分な近似解が得られれば問題ありません。

## 実装リファレンス

| ファイル | 設定キー | 役割 |
|---------|---------|------|
| `_core/contexts/game_session/adapters/orchestration/config_spsa_models.py` | `a0` | 初期ステップサイズ |
| `_core/contexts/game_session/adapters/orchestration/config_spsa_models.py` | `A` | ウォームアップ定数 |
| `_core/contexts/game_session/adapters/orchestration/config_spsa_models.py` | `alpha` | ステップサイズ減衰指数 |
| `_core/contexts/game_session/adapters/orchestration/config_spsa_models.py` | `gamma` | 摂動スケール減衰指数 |
| `_core/contexts/game_session/adapters/orchestration/config_spsa_models.py` | `mobility` | 全体学習率スケール |
| `_core/contexts/game_session/adapters/orchestration/config_spsa_models.py` | `scale` | 摂動スケール |

## 次に読む

→ **[ノイズと高次手法の限界](./noise-and-higher-order.md)**: なぜ二次手法（2SPSA、Newton 法、BFGS）がエンジンチューニングで使えないのか。Fishtest コミュニティの実践的な知見と理論的根拠を解説します。
