# mcpzoo-roman

> 罗马数字 — 阿拉伯数字与罗马数字互转

## Installation

```bash
uvx mcpzoo-roman
```

## uvx JSON

```json
{
  "mcpServers": {
    "roman": {
      "args": ["mcpzoo-roman"],
      "command": "uvx"
    }
  }
}
```
