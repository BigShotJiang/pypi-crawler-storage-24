from mcp.server.fastmcp import FastMCP

mcp = FastMCP("roman")

val = [
    1000, 900, 500, 400,
    100, 90, 50, 40,
    10, 9, 5, 4,
    1
]
syb = [
    "M", "CM", "D", "CD",
    "C", "XC", "L", "XL",
    "X", "IX", "V", "IV",
    "I"
]

@mcp.tool()
def to_roman(number: int) -> str:
    """将阿拉伯数字（1-3999）转换为罗马数字。"""
    if not 0 < number < 4000:
        return "错误：罗马数字转换支持范围为 1 到 3999"
        
    roman_num = ''
    i = 0
    n = number
    while n > 0:
        for _ in range(n // val[i]):
            roman_num += syb[i]
            n -= val[i]
        i += 1
    return roman_num

@mcp.tool()
def to_arabic(roman: str) -> str:
    """将罗马数字转为阿拉伯数字。"""
    roman = roman.upper().strip()
    roman_dict = {'I': 1, 'V': 5, 'X': 10, 'L': 50, 'C': 100, 'D': 500, 'M': 1000}
    res = 0
    for i in range(len(roman)):
        if i > 0 and roman_dict.get(roman[i], 0) > roman_dict.get(roman[i - 1], 0):
            res += roman_dict.get(roman[i], 0) - 2 * roman_dict.get(roman[i - 1], 0)
        else:
            res += roman_dict.get(roman[i], 0)
    return str(res)

def main():
    mcp.run()

if __name__ == "__main__":
    main()
