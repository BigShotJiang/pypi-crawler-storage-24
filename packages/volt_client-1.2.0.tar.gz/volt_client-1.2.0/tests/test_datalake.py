"""Tests for the /data/lake endpoint."""

import os
from unittest.mock import patch

import pytest


class TestDataLakeEndpoint:
    """Tests for the /data/lake endpoint using Azurite."""

    def test_lake_returns_files(self, client, azurite_datalake):
        """Basic call returns files with correct structure."""
        response = client.get("/data/lake")
        assert response.status_code == 200
        data = response.json()
        assert "files" in data
        assert "total_files" in data
        assert "total_size_bytes" in data
        assert data["total_files"] == len(data["files"])
        assert data["total_files"] == 3

        for f in data["files"]:
            assert "group" in f
            assert "area" in f
            assert "as_of" in f
            assert "file_type" in f
            assert "size_bytes" in f
            assert "url" in f

    def test_lake_filter_by_group(self, client, azurite_datalake):
        """?group=mid-term only returns mid-term files."""
        response = client.get("/data/lake?group=mid-term")
        assert response.status_code == 200
        data = response.json()
        assert data["total_files"] == 2
        for f in data["files"]:
            assert f["group"] == "mid-term"

    def test_lake_filter_by_area(self, client, azurite_datalake):
        """?area=NO1 only returns NO1 files."""
        response = client.get("/data/lake?area=NO1")
        assert response.status_code == 200
        data = response.json()
        assert data["total_files"] == 2
        for f in data["files"]:
            assert f["area"] == "NO1"

    def test_lake_filter_by_file_type(self, client, azurite_datalake):
        """?file_type=hourly filters correctly."""
        response = client.get("/data/lake?file_type=hourly")
        assert response.status_code == 200
        data = response.json()
        assert data["total_files"] == 2
        for f in data["files"]:
            assert f["file_type"] == "hourly"

    def test_lake_filter_by_date_range(self, client, azurite_datalake):
        """date_from/date_to filtering works."""
        # All test blobs have as_of=20260301 (2026-03-01)
        response = client.get("/data/lake?date_from=2026-03-01&date_to=2026-03-01")
        assert response.status_code == 200
        data = response.json()
        assert data["total_files"] == 3

        # Range that excludes all test data
        response = client.get("/data/lake?date_from=2026-04-01&date_to=2026-04-30")
        assert response.status_code == 200
        data = response.json()
        assert data["total_files"] == 0

    def test_lake_invalid_group(self, client, azurite_datalake):
        """Returns 400 for invalid group name."""
        response = client.get("/data/lake?group=invalid-group")
        assert response.status_code == 400
        assert "Invalid group" in response.json()["detail"]

    def test_lake_invalid_date_format(self, client, azurite_datalake):
        """Returns 400 for bad date format."""
        response = client.get("/data/lake?date_from=not-a-date")
        assert response.status_code == 400

    def test_lake_date_from_after_date_to(self, client, azurite_datalake):
        """Returns 400 when date_from > date_to."""
        response = client.get("/data/lake?date_from=2026-03-15&date_to=2026-03-01")
        assert response.status_code == 400
        assert "date_from" in response.json()["detail"]

    def test_lake_response_has_signed_urls(self, client, azurite_datalake):
        """URLs contain SAS token parameters."""
        response = client.get("/data/lake")
        assert response.status_code == 200
        data = response.json()
        assert data["total_files"] > 0
        for f in data["files"]:
            assert "?" in f["url"]
            # SAS tokens contain sig parameter
            assert "sig=" in f["url"]

    def test_lake_returns_503_without_storage_key(self, client, azurite_datalake):
        """Returns 503 when DATALAKE_STORAGE_KEY is empty."""
        with patch.dict(os.environ, {"DATALAKE_STORAGE_KEY": ""}):
            # The module-level constant is already read, so we also patch it
            with patch("volt_api.main.DATALAKE_STORAGE_KEY", ""):
                response = client.get("/data/lake")
                assert response.status_code == 503
                assert "not configured" in response.json()["detail"]
