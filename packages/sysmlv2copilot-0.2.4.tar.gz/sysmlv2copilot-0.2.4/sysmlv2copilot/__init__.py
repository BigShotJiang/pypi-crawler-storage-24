from importlib.metadata import PackageNotFoundError, version

from .client import SysMLCopilot
from .convenience import generate, repair
from .exceptions import (
    APIConnectionError,
    APIResponseValidationError,
    APIStatusError,
    AuthenticationError,
    RateLimitError,
    SysMLCopilotError,
)
from .types import (
    ArtifactReference,
    DependencyStatus,
    ErrorPayload,
    HealthResponse,
    RepairCreateParams,
    RepairObject,
    RequestDetail,
    ResponseCreateParams,
    ResponseMetadata,
    ResponseObject,
)

try:
    __version__ = version("sysmlv2copilot")
except PackageNotFoundError:
    __version__ = "0.2.4"

__all__ = [
    "APIConnectionError",
    "APIResponseValidationError",
    "APIStatusError",
    "ArtifactReference",
    "AuthenticationError",
    "DependencyStatus",
    "ErrorPayload",
    "generate",
    "HealthResponse",
    "RateLimitError",
    "repair",
    "RepairCreateParams",
    "RepairObject",
    "RequestDetail",
    "ResponseCreateParams",
    "ResponseMetadata",
    "ResponseObject",
    "SysMLCopilot",
    "SysMLCopilotError",
    "__version__",
]
