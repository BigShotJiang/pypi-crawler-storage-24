from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
from typing import Any

from . import __version__
from .client import DEFAULT_BASE_URL, SysMLCopilot
from .exceptions import SysMLCopilotError
from .input_utils import ALLOWED_INPUT_SUFFIXES, coerce_input_text


def _add_operation_arguments(
    parser: argparse.ArgumentParser,
    *,
    inline_help: str,
) -> None:
    create_group = parser.add_mutually_exclusive_group(required=True)
    create_group.add_argument("--input", help=inline_help)
    create_group.add_argument(
        "--input-file",
        type=Path,
        help=f"Path to a {', '.join(sorted(ALLOWED_INPUT_SUFFIXES))} file containing the input.",
    )
    parser.add_argument("--model", default="refine-sysml-v1")
    parser.add_argument("--provider", choices=["openai", "anthropic"])
    parser.add_argument("--upstream-model")
    parser.add_argument("--max-iters", type=int, default=10)
    parser.add_argument("--max-total-tokens", type=int, default=40_000)
    parser.add_argument("--temperature", type=float)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="sysmlv2copilot",
        description="CLI client for the SysML refinement API.",
    )
    parser.add_argument("--version", action="version", version=f"%(prog)s {__version__}")
    parser.add_argument(
        "--base-url",
        default=os.getenv("SYSMLV2COPILOT_BASE_URL", DEFAULT_BASE_URL),
        help="API base URL.",
    )
    parser.add_argument(
        "--api-key",
        default=os.getenv("SYSMLV2COPILOT_API_KEY"),
        help="Bearer API key. Defaults to SYSMLV2COPILOT_API_KEY.",
    )

    subparsers = parser.add_subparsers(dest="command", required=True)

    generate_parser = subparsers.add_parser("generate", help="Generate SysML from text or a file.")
    _add_operation_arguments(
        generate_parser,
        inline_help="Inline natural-language input text.",
    )
    generate_parser.set_defaults(operation="generate")

    repair_parser = subparsers.add_parser("repair", help="Repair SysML from text or a file.")
    _add_operation_arguments(
        repair_parser,
        inline_help="Inline SysML input text.",
    )
    repair_parser.set_defaults(operation="repair")

    responses_parser = subparsers.add_parser("responses", help=argparse.SUPPRESS)
    responses_subparsers = responses_parser.add_subparsers(dest="responses_command", required=True)
    create_parser = responses_subparsers.add_parser("create", help=argparse.SUPPRESS)
    _add_operation_arguments(
        create_parser,
        inline_help="Inline natural-language input text.",
    )
    create_parser.set_defaults(operation="generate")

    repairs_parser = subparsers.add_parser("repairs", help=argparse.SUPPRESS)
    repairs_subparsers = repairs_parser.add_subparsers(dest="repairs_command", required=True)
    repair_create_parser = repairs_subparsers.add_parser("create", help=argparse.SUPPRESS)
    _add_operation_arguments(
        repair_create_parser,
        inline_help="Inline SysML input text.",
    )
    repair_create_parser.set_defaults(operation="repair")

    requests_parser = subparsers.add_parser("requests", help="Fetch a stored request.")
    requests_subparsers = requests_parser.add_subparsers(dest="requests_command", required=True)
    retrieve_parser = requests_subparsers.add_parser("retrieve", help="Retrieve a request by id.")
    retrieve_parser.add_argument("request_id")

    health_parser = subparsers.add_parser("health", help="Check service health.")
    health_subparsers = health_parser.add_subparsers(dest="health_command", required=True)
    health_subparsers.add_parser("check", help="Get /healthz.")
    return parser


def _read_input_text(args: argparse.Namespace) -> str:
    if args.input is not None:
        return args.input
    return coerce_input_text(args.input_file)


def _print_json(data: Any) -> None:
    print(json.dumps(data, indent=2, sort_keys=True))


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    try:
        with SysMLCopilot(api_key=args.api_key, base_url=args.base_url) as client:
            if getattr(args, "operation", None) == "generate":
                response = client.responses.create(
                    input=_read_input_text(args),
                    model=args.model,
                    provider=args.provider,
                    upstream_model=args.upstream_model,
                    max_iters=args.max_iters,
                    max_total_tokens=args.max_total_tokens,
                    temperature=args.temperature,
                )
                _print_json(response.model_dump())
                return 0
            if getattr(args, "operation", None) == "repair":
                response = client.repairs.create(
                    input=_read_input_text(args),
                    model=args.model,
                    provider=args.provider,
                    upstream_model=args.upstream_model,
                    max_iters=args.max_iters,
                    max_total_tokens=args.max_total_tokens,
                    temperature=args.temperature,
                )
                _print_json(response.model_dump())
                return 0
            if args.command == "requests" and args.requests_command == "retrieve":
                detail = client.requests.retrieve(args.request_id)
                _print_json(detail.model_dump())
                return 0
            if args.command == "health" and args.health_command == "check":
                health = client.health.check()
                _print_json(health.model_dump())
                return 0
    except SysMLCopilotError as exc:
        print(f"error: {exc}")
        return 1
    except ValueError as exc:
        parser.error(str(exc))
    parser.error("Unsupported command.")
    return 2
