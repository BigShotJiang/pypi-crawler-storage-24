"""Stream handler implementations for Email integration."""
