"""Flowire Email (SMTP/IMAP) nodes package."""

__version__ = "0.0.1a1"
