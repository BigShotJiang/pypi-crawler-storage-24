"""Shared credential schemas for Email nodes."""

from typing import ClassVar

from pydantic import BaseModel, Field


class SMTPCredentialSchema(BaseModel):
    """Credential schema for SMTP email sending.

    Shared across nodes that send emails via SMTP.
    """

    credential_name: ClassVar[str] = "SMTP"
    credential_description: ClassVar[str] = "SMTP server credentials for sending emails"
    credential_icon: ClassVar[str | None] = "📧"

    host: str = Field(
        ...,
        description="SMTP server hostname (e.g., smtp.gmail.com)",
    )
    port: int = Field(
        default=587,
        description="SMTP server port (587 for STARTTLS, 465 for SSL)",
    )
    username: str = Field(
        ...,
        description="SMTP username (often your email address)",
    )
    password: str = Field(
        ...,
        description="SMTP password or app-specific password",
    )
    use_tls: bool = Field(
        default=True,
        description="Use STARTTLS encryption (recommended for port 587)",
    )
    use_ssl: bool = Field(
        default=False,
        description="Use implicit SSL/TLS (for port 465)",
    )


class IMAPCredentialSchema(BaseModel):
    """Credential schema for IMAP email reading.

    Shared across nodes that read emails via IMAP.
    """

    credential_name: ClassVar[str] = "IMAP"
    credential_description: ClassVar[str] = "IMAP server credentials for reading emails"
    credential_icon: ClassVar[str | None] = "📬"

    host: str = Field(
        ...,
        description="IMAP server hostname (e.g., imap.gmail.com)",
    )
    port: int = Field(
        default=993,
        description="IMAP server port (993 for SSL, 143 for STARTTLS)",
    )
    username: str = Field(
        ...,
        description="IMAP username (often your email address)",
    )
    password: str = Field(
        ...,
        description="IMAP password or app-specific password",
    )
    use_ssl: bool = Field(
        default=True,
        description="Use SSL/TLS encryption (recommended for port 993)",
    )
    readonly: bool = Field(
        default=False,
        description="Open mailbox as read-only (required for API keys without write permissions)",
    )
