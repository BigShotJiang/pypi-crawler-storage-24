"""Node implementations for Email integration."""
