"""Tests for Email Trigger node."""

import pytest

from fw_nodes_email.nodes.email_trigger import EmailTriggerNode


@pytest.fixture
def email_trigger_node():
    return EmailTriggerNode()


@pytest.fixture
def mock_context_with_imap(mock_context):
    """Mock context with IMAP credentials."""
    mock_context._credentials = {
        "cred_imap_123": {
            "host": "imap.example.com",
            "port": 993,
            "username": "user@example.com",
            "password": "imap_password_xyz",
            "use_ssl": True,
        }
    }
    return mock_context


@pytest.mark.asyncio
async def test_email_trigger_new_email(email_trigger_node, mock_context_with_imap):
    """Test trigger output from a new email event."""
    inputs = {
        "credential_id": "cred_imap_123",
        "folder": "INBOX",
        "_trigger_data": {
            "event_type": "new_email",
            "event_data": {
                "message_id": "<msg123@example.com>",
                "from": "alice@example.com",
                "to": "bob@example.com",
                "cc": "",
                "subject": "Hello from Alice",
                "date": "2025-01-15T10:30:00+00:00",
                "body_plain": "Hi Bob, how are you?",
                "body_html": "",
                "attachments": [],
            },
        },
    }

    result = await email_trigger_node.execute(inputs, mock_context_with_imap)

    assert result.event_type == "new_email"
    assert result.message_id == "<msg123@example.com>"
    assert result.from_address == "alice@example.com"
    assert result.to == "bob@example.com"
    assert result.subject == "Hello from Alice"
    assert result.body_plain == "Hi Bob, how are you?"
    assert result.raw_event["event_type"] == "new_email"


@pytest.mark.asyncio
async def test_email_trigger_with_attachments(email_trigger_node, mock_context_with_imap):
    """Test trigger output includes attachment metadata."""
    inputs = {
        "credential_id": "cred_imap_123",
        "folder": "INBOX",
        "_trigger_data": {
            "event_type": "new_email",
            "event_data": {
                "message_id": "<att456@example.com>",
                "from": "sender@example.com",
                "to": "recipient@example.com",
                "subject": "File attached",
                "date": "2025-01-15T11:00:00+00:00",
                "body_plain": "See attached.",
                "body_html": "",
                "attachments": [
                    {"filename": "report.pdf", "content_type": "application/pdf", "size": 12345},
                ],
            },
        },
    }

    result = await email_trigger_node.execute(inputs, mock_context_with_imap)

    assert result.event_type == "new_email"
    assert len(result.attachments) == 1
    assert result.attachments[0]["filename"] == "report.pdf"


@pytest.mark.asyncio
async def test_email_trigger_empty_trigger_data(email_trigger_node, mock_context_with_imap):
    """Test trigger with missing _trigger_data defaults gracefully."""
    inputs = {
        "credential_id": "cred_imap_123",
        "folder": "INBOX",
    }

    result = await email_trigger_node.execute(inputs, mock_context_with_imap)

    assert result.event_type == "new_email"
    assert result.message_id == ""
    assert result.from_address == ""
    assert result.subject == ""


@pytest.mark.asyncio
async def test_email_trigger_metadata():
    """Test trigger node metadata is correctly configured."""
    node = EmailTriggerNode()

    assert node.metadata.is_entry_point is True
    assert node.metadata.is_stream_trigger is True
    assert node.metadata.stream_type == "imap_idle"
    assert node.metadata.handles.inputs == []
    assert len(node.metadata.handles.outputs) == 1
