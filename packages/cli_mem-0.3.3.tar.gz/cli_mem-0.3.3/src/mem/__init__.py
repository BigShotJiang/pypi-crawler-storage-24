"""mem — your shell history, understood."""

__version__ = "0.3.3"
