"""General-purpose Python agent framework with pystator integration."""

from __future__ import annotations

try:
    from importlib.metadata import version as _get_version

    __version__ = _get_version("pygubernator")
except Exception:
    __version__ = "0.0.1.dev0"

# Core types
from pygubernator._protocols import LLMProvider, Tool, Transport
from pygubernator._types import AgentResult, Message, StepResult, ToolResult

# Agents
from pygubernator.agents import (
    BaseAgent,
    LLMAgent,
    PipelineAgent,
    PipelineStep,
    StateMachineAgent,
)

# Config
from pygubernator.config import AgentSettings

# Errors
from pygubernator.errors import (
    AgentError,
    ConfigError,
    ErrorCode,
    GubernatorError,
    LLMError,
    PipelineStepError,
    ToolError,
    TransportError,
)

# LLM
from pygubernator.llm import ChatMessage, ChatRole, LLMResponse, ToolCall

# Runners
from pygubernator.runners import run_batch, run_stream

# Tools
from pygubernator.tools import ToolRegistry, tool

# Transport
from pygubernator.transport import InMemoryTransport

__all__ = [
    # Agents
    "BaseAgent",
    "LLMAgent",
    "PipelineAgent",
    "PipelineStep",
    "StateMachineAgent",
    # Config
    "AgentSettings",
    # Errors
    "AgentError",
    "ConfigError",
    "ErrorCode",
    "GubernatorError",
    "LLMError",
    "PipelineStepError",
    "ToolError",
    "TransportError",
    # LLM
    "ChatMessage",
    "ChatRole",
    "LLMResponse",
    "ToolCall",
    # Protocols
    "LLMProvider",
    "Tool",
    "Transport",
    # Runners
    "run_batch",
    "run_stream",
    # Tools
    "ToolRegistry",
    "tool",
    # Transport
    "InMemoryTransport",
    # Types
    "AgentResult",
    "Message",
    "StepResult",
    "ToolResult",
]
