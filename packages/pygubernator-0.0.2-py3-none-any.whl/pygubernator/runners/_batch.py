"""Batch runner: consume N messages, process, exit."""

from __future__ import annotations

import logging

from pygubernator._protocols import Transport
from pygubernator._types import AgentResult
from pygubernator.agents._base import BaseAgent

logger = logging.getLogger(__name__)


async def run_batch(
    agent: BaseAgent,
    transport: Transport,
    topic: str,
    max_messages: int = 100,
) -> AgentResult:
    """Run an agent in batch mode.

    Consumes up to max_messages from the topic, processes each
    through the agent, then stops. Suitable for Airflow tasks.

    Args:
        agent: Agent implementing BaseAgent protocol.
        transport: Transport implementing Transport protocol.
        topic: Topic to consume from.
        max_messages: Maximum messages to process.

    Returns:
        Aggregate result of all processed messages.
    """
    agent.start()
    total_processed = 0
    all_errors: list[str] = []

    try:
        messages = await transport.consume(topic, max_messages)
        logger.info(
            "Batch run: consuming %d messages from %s",
            len(messages),
            topic,
        )

        for msg in messages:
            result = await agent.process(msg)
            total_processed += result.messages_processed
            all_errors.extend(result.errors)

        await transport.commit()

    except Exception as exc:
        logger.error("Batch run failed: %s", exc)
        all_errors.append(str(exc))
    finally:
        agent.stop()
        await transport.close()

    success = len(all_errors) == 0
    return AgentResult(
        agent_id=agent.agent_id,
        success=success,
        messages_processed=total_processed,
        errors=all_errors,
        metadata={"mode": "batch", "topic": topic},
    )
