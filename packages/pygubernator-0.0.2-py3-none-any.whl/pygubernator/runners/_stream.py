"""Stream runner: consume forever until shutdown."""

from __future__ import annotations

import asyncio
import logging

from pygubernator._protocols import Transport
from pygubernator._types import AgentResult
from pygubernator.agents._base import BaseAgent

logger = logging.getLogger(__name__)


async def run_stream(
    agent: BaseAgent,
    transport: Transport,
    topic: str,
    shutdown_event: asyncio.Event | None = None,
    batch_size: int = 10,
    commit_interval: int = 100,
) -> AgentResult:
    """Run an agent in streaming mode.

    Continuously consumes messages until the shutdown event is set.
    Suitable for long-running K8s deployments.

    Args:
        agent: Agent implementing BaseAgent protocol.
        transport: Transport implementing Transport protocol.
        topic: Topic to consume from.
        shutdown_event: Event to signal shutdown. If None, creates one.
        batch_size: Messages to consume per poll.
        commit_interval: Commit offsets every N messages.

    Returns:
        Aggregate result when shutdown completes.
    """
    if shutdown_event is None:
        shutdown_event = asyncio.Event()

    agent.start()
    total_processed = 0
    all_errors: list[str] = []
    since_commit = 0

    try:
        logger.info(
            "Stream run: consuming from %s (batch_size=%d)",
            topic,
            batch_size,
        )

        while not shutdown_event.is_set():
            messages = await transport.consume(topic, batch_size)

            if not messages:
                try:
                    await asyncio.wait_for(shutdown_event.wait(), timeout=1.0)
                except TimeoutError:
                    continue

            for msg in messages:
                if shutdown_event.is_set():
                    break

                result = await agent.process(msg)
                total_processed += result.messages_processed
                all_errors.extend(result.errors)
                since_commit += 1

                if since_commit >= commit_interval:
                    await transport.commit()
                    since_commit = 0

        # Final commit
        if since_commit > 0:
            await transport.commit()

    except Exception as exc:
        logger.error("Stream run failed: %s", exc)
        all_errors.append(str(exc))
    finally:
        agent.stop()
        await transport.close()

    success = len(all_errors) == 0
    return AgentResult(
        agent_id=agent.agent_id,
        success=success,
        messages_processed=total_processed,
        errors=all_errors,
        metadata={"mode": "stream", "topic": topic},
    )
