"""Pipeline agent: sequential extract-transform-load steps."""

from __future__ import annotations

import abc
import contextlib
import logging
import time
from typing import Any

from pystator import StateMachine

from pygubernator._types import AgentResult, Message, StepResult
from pygubernator.agents._base import BaseAgent
from pygubernator.agents._machines import pipeline_lifecycle_config

logger = logging.getLogger(__name__)


class PipelineStep(abc.ABC):
    """A single step in a pipeline.

    Attributes:
        name: Step identifier.
    """

    def __init__(self, name: str) -> None:
        self._name = name

    @property
    def name(self) -> str:
        """Step name."""
        return self._name

    @abc.abstractmethod
    async def execute(self, data: Any) -> StepResult:
        """Execute this step.

        Args:
            data: Input data from previous step.

        Returns:
            Step result with output data.
        """


class PipelineAgent(BaseAgent):
    """Agent that runs sequential pipeline steps.

    Each step is a PipelineStep object that executes and returns
    a StepResult. Steps run in order: extract -> transform -> load.
    Optional pycharter contract validation between steps.

    Args:
        agent_id: Unique identifier.
        steps: Ordered list of pipeline steps.
        validate_between_steps: Whether to validate data between steps.
        lifecycle_machine: Optional lifecycle machine override.
        context: Optional initial context.
    """

    def __init__(
        self,
        agent_id: str,
        steps: list[PipelineStep],
        validate_between_steps: bool = False,
        lifecycle_machine: StateMachine | None = None,
        context: dict[str, Any] | None = None,
    ) -> None:
        super().__init__(
            agent_id=agent_id,
            machine=lifecycle_machine,
            context=context,
        )
        self._steps = steps
        self._validate = validate_between_steps
        self._pipeline_machine = StateMachine.from_dict(pipeline_lifecycle_config())
        self._pipeline_session = self._pipeline_machine.create()

    async def process(self, message: Message) -> AgentResult:
        """Process a message through the pipeline steps.

        Args:
            message: The input message.

        Returns:
            Result with step metadata.
        """
        step_results: list[dict[str, Any]] = []
        data: Any = message.payload
        errors: list[str] = []

        self._pipeline_session = self._pipeline_machine.create()
        self._pipeline_session.send("start_extract")

        step_events = ["extract_done", "transform_done", "load_done"]

        for i, step in enumerate(self._steps):
            start_time = time.perf_counter()
            try:
                if self._validate and i > 0:
                    data = self._validate_data(step.name, data)

                result = await step.execute(data)
                step_results.append(result.to_dict())

                if not result.success:
                    errors.append(f"Step '{step.name}' failed: {result.error}")
                    self._pipeline_session.send("fail")
                    break

                data = result.data

                if i < len(step_events):
                    self._pipeline_session.send(step_events[i])

            except Exception as exc:
                elapsed = (time.perf_counter() - start_time) * 1000
                errors.append(f"Step '{step.name}' error: {exc}")
                step_results.append(
                    StepResult(
                        step_name=step.name,
                        success=False,
                        data=None,
                        error=str(exc),
                        duration_ms=elapsed,
                    ).to_dict()
                )
                self._pipeline_session.send("fail")
                break

        success = len(errors) == 0
        return AgentResult(
            agent_id=self._agent_id,
            success=success,
            messages_processed=1 if success else 0,
            errors=errors,
            metadata={
                "steps": step_results,
                "pipeline_state": self._pipeline_session.current_state,
            },
        )

    @staticmethod
    def _validate_data(step_name: str, data: Any) -> Any:
        """Validate data between steps using pycharter if available.

        Args:
            step_name: Name of the next step (for error context).
            data: Data to validate.

        Returns:
            The validated data.

        Raises:
            PipelineStepError: If validation fails.
        """
        with contextlib.suppress(ImportError):
            import pycharter  # noqa: F401

            # Validation integration point: users extend this
            # by subclassing PipelineAgent and overriding _validate_data
        return data
