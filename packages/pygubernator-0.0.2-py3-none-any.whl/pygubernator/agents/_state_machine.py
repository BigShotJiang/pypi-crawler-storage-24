"""State machine agent with custom pystator machine."""

from __future__ import annotations

import logging
from collections.abc import Callable
from typing import Any

from pystator import StateMachine

from pygubernator._types import AgentResult, Message
from pygubernator.agents._base import BaseAgent

logger = logging.getLogger(__name__)

# Handler signature: (message, session_context) -> dict with results
HandlerFunc = Callable[[Message, dict[str, Any]], dict[str, Any]]


class StateMachineAgent(BaseAgent):
    """Agent driven by a custom pystator state machine.

    The most flexible agent type. Users provide a custom StateMachine
    and a handler function. The handler processes messages and returns
    data that informs state transitions.

    Args:
        agent_id: Unique identifier for this agent.
        workflow_machine: Custom state machine defining the workflow.
        handler: Function called to process each message.
        lifecycle_machine: Optional lifecycle machine override.
        context: Optional initial context.
    """

    def __init__(
        self,
        agent_id: str,
        workflow_machine: StateMachine,
        handler: HandlerFunc,
        lifecycle_machine: StateMachine | None = None,
        context: dict[str, Any] | None = None,
    ) -> None:
        super().__init__(
            agent_id=agent_id,
            machine=lifecycle_machine,
            context=context,
        )
        self._workflow_machine = workflow_machine
        self._handler = handler
        self._workflow_session = workflow_machine.create(context=context or {})

    @property
    def workflow_state(self) -> str:
        """Current workflow state."""
        return self._workflow_session.current_state

    async def process(self, message: Message) -> AgentResult:
        """Process a message through the custom workflow.

        Calls the handler function with the message and current
        workflow context. The handler returns a dict that may include
        an ``event`` key to trigger a workflow transition.

        Args:
            message: The message to process.

        Returns:
            Result of processing.
        """
        try:
            ctx = dict(self._workflow_session.context)
            ctx["message"] = message.to_dict()

            result_data = self._handler(message, ctx)

            event = result_data.get("event")
            if event:
                transition = self._workflow_session.send(
                    event, **result_data.get("payload", {})
                )
                if not transition.success:
                    logger.warning(
                        "Workflow transition failed for event %s: %s",
                        event,
                        transition.error,
                    )

            return AgentResult(
                agent_id=self._agent_id,
                success=True,
                messages_processed=1,
                errors=[],
                metadata={
                    "workflow_state": self.workflow_state,
                    **result_data.get("metadata", {}),
                },
            )
        except Exception as exc:
            logger.error(
                "StateMachineAgent %s failed: %s",
                self._agent_id,
                exc,
            )
            return AgentResult(
                agent_id=self._agent_id,
                success=False,
                messages_processed=0,
                errors=[str(exc)],
                metadata={"workflow_state": self.workflow_state},
            )
