"""LLM agent: think-act-observe-decide loop."""

from __future__ import annotations

import contextlib
import logging
from typing import Any

from pystator import StateMachine

from pygubernator._protocols import LLMProvider
from pygubernator._types import AgentResult, Message, ToolResult
from pygubernator.agents._base import BaseAgent
from pygubernator.agents._machines import llm_lifecycle_config
from pygubernator.llm._messages import LLMResponse
from pygubernator.tools._registry import ToolRegistry

logger = logging.getLogger(__name__)


class LLMAgent(BaseAgent):
    """Agent that uses an LLM with tool calling.

    Implements the think -> act -> observe -> decide loop. The LLM
    generates responses, optionally calling tools. Tool results are
    fed back to the LLM until it produces a final response.

    Args:
        agent_id: Unique identifier.
        llm_provider: LLM provider implementing the LLMProvider protocol.
        tool_registry: Registry of available tools.
        system_prompt: System prompt for the LLM.
        max_iterations: Maximum think-act-observe iterations.
        lifecycle_machine: Optional lifecycle machine override.
        context: Optional initial context.
    """

    def __init__(
        self,
        agent_id: str,
        llm_provider: LLMProvider,
        tool_registry: ToolRegistry | None = None,
        system_prompt: str = "",
        max_iterations: int = 10,
        lifecycle_machine: StateMachine | None = None,
        context: dict[str, Any] | None = None,
    ) -> None:
        super().__init__(
            agent_id=agent_id,
            machine=lifecycle_machine,
            context=context,
        )
        self._llm = llm_provider
        self._tools = tool_registry
        self._system_prompt = system_prompt
        self._max_iterations = max_iterations
        self._llm_machine = StateMachine.from_dict(llm_lifecycle_config(max_iterations))

    async def process(self, message: Message) -> AgentResult:
        """Process a message through the LLM loop.

        Args:
            message: The input message.

        Returns:
            Result with LLM response and tool call details.
        """
        llm_session = self._llm_machine.create()
        llm_session.send("start")

        messages: list[dict[str, Any]] = []
        if self._system_prompt:
            messages.append(
                {
                    "role": "system",
                    "content": self._system_prompt,
                }
            )
        messages.append(
            {
                "role": "user",
                "content": str(message.payload.get("content", message.payload)),
            }
        )

        tool_schemas = self._tools.get_schemas() if self._tools else None
        iterations = 0
        all_tool_results: list[dict[str, Any]] = []
        final_content = ""

        try:
            for iteration in range(self._max_iterations):
                iterations = iteration + 1

                # Think: call LLM
                response: LLMResponse = await self._llm.chat(
                    messages, tools=tool_schemas
                )

                if not response.has_tool_calls:
                    # No tools needed — done
                    llm_session.send("no_tools")
                    final_content = response.content
                    break

                # Act: execute tool calls
                llm_session.send("thought")
                messages.append(
                    {
                        "role": "assistant",
                        "content": response.content,
                        "tool_calls": [
                            {
                                "id": tc.id,
                                "type": "function",
                                "function": {
                                    "name": tc.name,
                                    "arguments": tc.arguments,
                                },
                            }
                            for tc in response.tool_calls
                        ],
                    }
                )

                for tc in response.tool_calls:
                    if self._tools and self._tools.has(tc.name):
                        result = await self._tools.execute(tc.name, tc.arguments)
                    else:
                        result = ToolResult(
                            tool_name=tc.name,
                            success=False,
                            output=None,
                            error=f"Tool '{tc.name}' not found",
                        )
                    all_tool_results.append(result.to_dict())
                    messages.append(
                        {
                            "role": "tool",
                            "tool_call_id": tc.id,
                            "content": str(result.output)
                            if result.success
                            else str(result.error),
                        }
                    )

                # Observe + Decide
                llm_session.send("acted")
                llm_session.send("observed")
                llm_session.send("continue")

            else:
                # Max iterations reached
                final_content = response.content  # type: ignore[possibly-undefined]
                llm_session.send("finish")

        except Exception as exc:
            logger.error("LLMAgent %s failed: %s", self._agent_id, exc)
            with contextlib.suppress(Exception):
                llm_session.send("fail")
            return AgentResult(
                agent_id=self._agent_id,
                success=False,
                messages_processed=0,
                errors=[str(exc)],
                metadata={
                    "iterations": iterations,
                    "llm_state": llm_session.current_state,
                },
            )

        return AgentResult(
            agent_id=self._agent_id,
            success=True,
            messages_processed=1,
            errors=[],
            metadata={
                "iterations": iterations,
                "response": final_content,
                "tool_results": all_tool_results,
                "llm_state": llm_session.current_state,
            },
        )
