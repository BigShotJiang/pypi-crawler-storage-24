"""LLM provider implementations."""

from __future__ import annotations

import logging
from typing import Any

from pygubernator.errors import LLMError
from pygubernator.llm._messages import (
    LLMResponse,
    ToolCall,
)

logger = logging.getLogger(__name__)


class LiteLLMProvider:
    """LLM provider using litellm for provider-agnostic access.

    Supports OpenAI, Anthropic, Google, and other providers through
    litellm's unified interface. Just change the model string.

    Args:
        model: Model identifier (e.g. "gpt-4", "claude-3-opus-20240229").
        max_tokens: Maximum tokens per response.
        temperature: Sampling temperature.
        api_key: Optional API key override.
    """

    def __init__(
        self,
        model: str = "gpt-4",
        max_tokens: int = 4096,
        temperature: float = 0.0,
        api_key: str | None = None,
    ) -> None:
        self._model = model
        self._max_tokens = max_tokens
        self._temperature = temperature
        self._api_key = api_key

    async def chat(
        self,
        messages: list[dict[str, Any]],
        tools: list[dict[str, Any]] | None = None,
    ) -> LLMResponse:
        """Send a chat completion request.

        Args:
            messages: List of message dicts with role and content.
            tools: Optional list of tool schemas for function calling.

        Returns:
            LLM response with content and/or tool calls.

        Raises:
            LLMError: If the LLM call fails.
        """
        try:
            import litellm
        except ImportError as exc:
            raise LLMError(
                "litellm is required for LiteLLMProvider. "
                "Install with: pip install pygubernator[llm]",
                provider="litellm",
            ) from exc

        kwargs: dict[str, Any] = {
            "model": self._model,
            "messages": messages,
            "max_tokens": self._max_tokens,
            "temperature": self._temperature,
        }
        if self._api_key:
            kwargs["api_key"] = self._api_key
        if tools:
            kwargs["tools"] = self._format_tools(tools)

        try:
            response = await litellm.acompletion(**kwargs)
        except Exception as exc:
            raise LLMError(
                f"LLM call failed: {exc}",
                provider="litellm",
                context={"model": self._model},
            ) from exc

        return self._parse_response(response)

    @staticmethod
    def _format_tools(
        tools: list[dict[str, Any]],
    ) -> list[dict[str, Any]]:
        """Convert tool schemas to LLM-compatible format."""
        formatted: list[dict[str, Any]] = []
        for t in tools:
            formatted.append(
                {
                    "type": "function",
                    "function": {
                        "name": t["name"],
                        "description": t.get("description", ""),
                        "parameters": t.get("parameters", {}),
                    },
                }
            )
        return formatted

    @staticmethod
    def _parse_response(response: Any) -> LLMResponse:
        """Parse litellm response into LLMResponse."""
        choice = response.choices[0]
        message = choice.message

        tool_calls: list[ToolCall] = []
        if hasattr(message, "tool_calls") and message.tool_calls:
            import json

            for tc in message.tool_calls:
                args = tc.function.arguments
                if isinstance(args, str):
                    try:
                        args = json.loads(args)
                    except json.JSONDecodeError:
                        args = {"raw": args}
                tool_calls.append(
                    ToolCall(
                        id=tc.id,
                        name=tc.function.name,
                        arguments=args,
                    )
                )

        usage: dict[str, int] = {}
        if hasattr(response, "usage") and response.usage:
            usage = {
                "prompt_tokens": response.usage.prompt_tokens,
                "completion_tokens": response.usage.completion_tokens,
                "total_tokens": response.usage.total_tokens,
            }

        return LLMResponse(
            content=message.content or "",
            tool_calls=tuple(tool_calls),
            finish_reason=choice.finish_reason or "stop",
            usage=usage,
            model=response.model or "",
        )
