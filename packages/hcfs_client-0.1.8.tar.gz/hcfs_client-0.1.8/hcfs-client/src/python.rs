//! PyO3 module registration for HCFS client.

use pyo3::prelude::*;

#[pymodule]
fn hcfs_client(m: &Bound<'_, PyModule>) -> PyResult<()> {
    m.add_class::<crate::client::HcfsClientConfig>()?;
    m.add_class::<crate::client::HcfsClient>()?;
    m.add_class::<crate::drive::Drive>()?;
    m.add_class::<crate::sync::SyncOutcome>()?;
    m.add_class::<crate::sync::SyncPlan>()?;
    m.add_class::<crate::sync::SyncConflictInfo>()?;
    m.add_class::<crate::sync::SyncConflictType>()?;
    m.add_class::<crate::sync::SyncConflictResolution>()?;
    m.add_class::<crate::sync::SyncUploadConflict>()?;
    m.add_class::<crate::sync::SyncPlanConflict>()?;
    m.add_class::<crate::sync::PySyncConflict>()?;
    m.add_class::<hcfs_shared::network::UploadResult>()?;
    m.add_class::<hcfs_shared::network::RemoteFileEntry>()?;
    m.add_class::<hcfs_shared::network::DownloadResult>()?;
    Ok(())
}
