//! HCFS Client Library
//!
//! Client-side implementation for the Hippius Confidential File System.
//! Handles encryption, signing, and sync operations using the three-tree model.

pub mod auth;
pub mod client;
pub mod crypto;
pub mod drive;
#[cfg(feature = "python")]
pub mod python;
pub mod sync;
