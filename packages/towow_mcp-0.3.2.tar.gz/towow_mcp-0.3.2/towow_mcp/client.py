"""REST client for the Towow Product API (V2)."""

from __future__ import annotations

import logging
import uuid
from typing import Any
from urllib.parse import urlparse

import httpx

from .config import get_backend_url, get_session_token

logger = logging.getLogger(__name__)

_ALLOWED_SCHEMES = {"https", "http"}
_PROTOCOL_ACCEPT = "application/vnd.towow.v1+json"


class AuthError(Exception):
    """Raised when authentication fails or session token is missing."""


class APIError(Exception):
    """Raised on non-success HTTP responses (excluding auth errors)."""

    def __init__(self, status_code: int, detail: str) -> None:
        self.status_code = status_code
        self.detail = detail
        super().__init__(f"HTTP {status_code}: {detail}")


def _validate_url(url: str) -> str:
    """Validate backend URL scheme (D-5 M-4 security).

    Only https:// and http://localhost are allowed.
    """
    parsed = urlparse(url)
    if parsed.scheme not in _ALLOWED_SCHEMES:
        raise ValueError(f"Unsupported URL scheme: {parsed.scheme}. Only https and http are allowed.")
    if not parsed.hostname:
        raise ValueError(f"Invalid URL: missing hostname in {url}")
    if parsed.scheme == "http" and parsed.hostname not in ("localhost", "127.0.0.1") and not parsed.hostname.replace(".", "").isdigit():
        raise ValueError(f"HTTP is only allowed for localhost, got: {parsed.hostname}")
    return url


class TowowClient:
    """Async REST client for Towow Product API endpoints.

    All authenticated endpoints attach the session token from local config
    as an Authorization: Bearer header.
    """

    def __init__(
        self,
        backend_url: str | None = None,
        session_token: str | None = None,
        timeout: float = 30.0,
        transport: httpx.AsyncBaseTransport | None = None,
    ) -> None:
        raw_url = backend_url or get_backend_url()
        self.base = _validate_url(raw_url.rstrip("/"))
        self._token = session_token
        self._http = httpx.AsyncClient(
            timeout=httpx.Timeout(connect=timeout, read=300.0, write=timeout, pool=timeout),
            transport=transport,
        )

    async def _request(self, method: str, url: str, **kwargs: Any) -> httpx.Response:
        """Send HTTP request, converting transport errors to APIError."""
        try:
            return await self._http.request(method, url, **kwargs)
        except httpx.TransportError as exc:
            raise APIError(0, f"Cannot reach backend at {self.base}: {exc}") from exc

    def _url(self, path: str) -> str:
        return f"{self.base}/api{path}"

    def _protocol_url(self, path: str) -> str:
        return f"{self.base}/protocol{path}"

    def _auth_headers(self) -> dict[str, str]:
        token = self._token or get_session_token()
        if not token:
            raise AuthError("Not logged in. Use register or login first.")
        return {"Authorization": f"Bearer {token}"}

    def _protocol_headers(self) -> dict[str, str]:
        headers = self._auth_headers()
        headers["Accept"] = _PROTOCOL_ACCEPT
        return headers

    def _handle_response(self, resp: httpx.Response) -> dict[str, Any]:
        if resp.status_code == 401:
            raise AuthError("Authentication failed (401). Please login again.")
        if resp.status_code >= 400:
            try:
                body = resp.json()
                if isinstance(body, dict) and "error" in body:
                    detail = body["error"].get("message", resp.text[:200])
                else:
                    detail = body.get("detail", resp.text[:200])
            except Exception:
                detail = resp.text[:200]
            raise APIError(resp.status_code, detail)
        return resp.json()

    # --- Public (no auth) ---

    async def register(
        self,
        invite_code: str,
        email: str,
        password: str,
        name: str,
        profile_text: str,
    ) -> dict[str, Any]:
        """POST /protocol/auth/register → account bootstrap payload."""
        resp = await self._request("POST",
            self._protocol_url("/auth/register"),
            headers={"Accept": _PROTOCOL_ACCEPT},
            json={
                "invite_code": invite_code,
                "email": email,
                "password": password,
                "name": name,
                "profile_text": profile_text,
            },
        )
        return self._handle_response(resp)

    async def login(self, email: str, password: str) -> dict[str, Any]:
        """POST /protocol/auth/login → account bootstrap payload."""
        resp = await self._request("POST",
            self._protocol_url("/auth/login"),
            headers={"Accept": _PROTOCOL_ACCEPT},
            json={"email": email, "password": password},
        )
        return self._handle_response(resp)

    async def create_consumer_auth_session(
        self,
        *,
        lane: str,
        scene_id: str,
        entry_surface: str,
        consumer_kind: str,
    ) -> dict[str, Any]:
        resp = await self._request(
            "POST",
            self._protocol_url("/auth/consumer-sessions"),
            headers={"Accept": _PROTOCOL_ACCEPT},
            json={
                "lane": lane,
                "scene_id": scene_id,
                "entry_surface": entry_surface,
                "consumer_kind": consumer_kind,
            },
        )
        return self._handle_response(resp)

    async def get_consumer_auth_session_status(self, auth_session_id: str) -> dict[str, Any]:
        resp = await self._request(
            "GET",
            self._protocol_url(f"/auth/consumer-sessions/{auth_session_id}"),
            headers={"Accept": _PROTOCOL_ACCEPT},
        )
        return self._handle_response(resp)

    async def exchange_consumer_auth_session(self, auth_session_id: str) -> dict[str, Any]:
        resp = await self._request(
            "POST",
            self._protocol_url(f"/auth/consumer-sessions/{auth_session_id}/exchange"),
            headers={"Accept": _PROTOCOL_ACCEPT},
        )
        return self._handle_response(resp)

    async def logout(self) -> dict[str, Any]:
        """POST /protocol/auth/logout."""
        resp = await self._request("POST",
            self._protocol_url("/auth/logout"),
            headers=self._protocol_headers(),
        )
        return self._handle_response(resp)

    async def list_scenes(self) -> dict[str, Any]:
        resp = await self._request(
            "GET",
            self._protocol_url("/scenes"),
        )
        return self._handle_response(resp)

    async def get_scene(self, scene_id: str) -> dict[str, Any]:
        resp = await self._request(
            "GET",
            self._protocol_url(f"/scenes/{scene_id}"),
        )
        return self._handle_response(resp)

    async def get_protocol_metadata(self) -> dict[str, Any]:
        """GET /protocol — protocol metadata + encoding package summary."""
        resp = await self._request("GET", self._protocol_url(""))
        return self._handle_response(resp)

    async def get_encoding_package(self) -> dict[str, Any]:
        """GET /protocol/encoding-package — full encoding package."""
        resp = await self._request("GET", self._protocol_url("/encoding-package"))
        return self._handle_response(resp)

    async def get_nomination(self, nomination_id: str) -> dict[str, Any]:
        """GET /protocol/nominations/{nomination_id} — nomination detail."""
        resp = await self._request(
            "GET",
            self._protocol_url(f"/nominations/{nomination_id}"),
            headers=self._protocol_headers(),
        )
        return self._handle_response(resp)

    async def get_agent_federation(self, agent_id: str) -> dict[str, Any]:
        """GET /protocol/agents/{agent_id}/federation — federation metadata."""
        resp = await self._request(
            "GET",
            self._protocol_url(f"/agents/{agent_id}/federation"),
        )
        return self._handle_response(resp)

    async def get_agent_did(self, agent_id: str) -> dict[str, Any]:
        """GET /protocol/agents/{agent_id}/did.json — DID document."""
        resp = await self._request(
            "GET",
            self._protocol_url(f"/agents/{agent_id}/did.json"),
        )
        return self._handle_response(resp)

    async def rerun_discovery(
        self,
        query_id: str,
        *,
        scope_tags: list[str] | None = None,
        max_candidates: int = 10,
        start_negotiation: bool = False,
        k: int | None = None,
    ) -> dict[str, Any]:
        """POST /protocol/discover/{query_id}/rerun — re-run discovery with adjusted params."""
        payload: dict[str, Any] = {
            "scope_tags": list(scope_tags or []),
            "max_candidates": max_candidates,
            "start_negotiation": start_negotiation,
        }
        if k is not None:
            payload["k"] = k
        resp = await self._request(
            "POST",
            self._protocol_url(f"/discover/{query_id}/rerun"),
            headers=self._protocol_headers(),
            json=payload,
        )
        return self._handle_response(resp)

    async def mark_conversation_read(self, conversation_id: str) -> dict[str, Any]:
        """POST /protocol/conversations/{conversation_id}/read — mark conversation read."""
        resp = await self._request(
            "POST",
            self._protocol_url(f"/conversations/{conversation_id}/read"),
            headers=self._protocol_headers(),
        )
        return self._handle_response(resp)

    # --- Authenticated ---

    async def get_profile(self) -> dict[str, Any]:
        """Legacy V1 helper for `/api/profile`; retained only for transitional tooling."""
        resp = await self._request("GET",
            self._url("/profile"),
            headers=self._auth_headers(),
        )
        return self._handle_response(resp)

    async def get_account(self) -> dict[str, Any]:
        resp = await self._request("GET",
            self._protocol_url("/account"),
            headers=self._protocol_headers(),
        )
        return self._handle_response(resp)

    async def request_email_verification(self) -> dict[str, Any]:
        resp = await self._request("POST",
            self._protocol_url("/account/email/verification"),
            headers=self._protocol_headers(),
        )
        return self._handle_response(resp)

    async def list_inbox(self) -> dict[str, Any]:
        resp = await self._request("GET",
            self._protocol_url("/inbox"),
            headers=self._protocol_headers(),
        )
        return self._handle_response(resp)

    async def get_inbox_item(self, item_id: str) -> dict[str, Any]:
        resp = await self._request("GET",
            self._protocol_url(f"/inbox/{item_id}"),
            headers=self._protocol_headers(),
        )
        return self._handle_response(resp)

    async def mark_inbox_item_read(self, item_id: str) -> dict[str, Any]:
        resp = await self._request("POST",
            self._protocol_url(f"/inbox/{item_id}/read"),
            headers=self._protocol_headers(),
        )
        return self._handle_response(resp)

    async def list_agents(self) -> dict[str, Any]:
        resp = await self._request("GET",
            self._protocol_url("/agents"),
            headers=self._protocol_headers(),
        )
        return self._handle_response(resp)

    async def create_agent(
        self,
        *,
        display_name: str,
        profile_text: str,
        visibility: str = "scoped",
        scoped_tags: list[str] | None = None,
        capability_manifest: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        resp = await self._request("POST",
            self._protocol_url("/agents"),
            headers=self._protocol_headers(),
            json={
                "display_name": display_name,
                "profile_source": "plaintext",
                "profile_text": profile_text,
                "visibility": visibility,
                "scoped_tags": list(scoped_tags or []),
                "capability_manifest": capability_manifest,
            },
        )
        return self._handle_response(resp)

    async def get_agent(self, agent_id: str) -> dict[str, Any]:
        resp = await self._request("GET",
            self._protocol_url(f"/agents/{agent_id}"),
            headers=self._protocol_headers(),
        )
        return self._handle_response(resp)

    async def update_agent(
        self,
        agent_id: str,
        *,
        display_name: str | None = None,
        profile_text: str | None = None,
        scoped_tags: list[str] | None = None,
        capability_manifest: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        payload: dict[str, Any] = {}
        if display_name is not None:
            payload["display_name"] = display_name
        if profile_text is not None:
            payload["profile_text"] = profile_text
        if scoped_tags is not None:
            payload["scoped_tags"] = list(scoped_tags)
        if capability_manifest is not None:
            payload["capability_manifest"] = capability_manifest
        resp = await self._request("PUT",
            self._protocol_url(f"/agents/{agent_id}"),
            headers=self._protocol_headers(),
            json=payload,
        )
        return self._handle_response(resp)

    async def set_agent_visibility(self, agent_id: str, visibility: str) -> dict[str, Any]:
        resp = await self._request("PATCH",
            self._protocol_url(f"/agents/{agent_id}/visibility"),
            headers=self._protocol_headers(),
            json={"visibility": visibility},
        )
        return self._handle_response(resp)

    async def create_formulation(self, *, agent_id: str, raw_intent: str, scene_context: str | None = None) -> dict[str, Any]:
        payload: dict[str, Any] = {
            "agent_id": agent_id,
            "raw_intent": raw_intent,
        }
        if scene_context:
            payload["scene_context"] = scene_context
        resp = await self._request("POST",
            self._protocol_url("/formulations"),
            json=payload,
            headers=self._protocol_headers(),
        )
        return self._handle_response(resp)

    async def get_formulation(self, session_id: str) -> dict[str, Any]:
        resp = await self._request("GET",
            self._protocol_url(f"/formulations/{session_id}"),
            headers=self._protocol_headers(),
        )
        return self._handle_response(resp)

    async def formulation_reply_stream(self, session_id: str, user_message: str) -> httpx.Response:
        req = self._http.build_request(
            "POST",
            self._protocol_url(f"/formulations/{session_id}/reply"),
            json={"user_message": user_message},
            headers=self._protocol_headers(),
        )
        try:
            resp = await self._http.send(req, stream=True)
        except httpx.TransportError as exc:
            raise APIError(0, f"Cannot reach backend at {self.base}: {exc}") from exc
        if resp.status_code >= 400:
            await resp.aread()
            self._handle_response(resp)
        return resp

    async def confirm_formulation(
        self,
        *,
        session_id: str,
        scope_tags: list[str] | None = None,
        max_candidates: int = 10,
        start_negotiation: bool = False,
        k: int | None = None,
    ) -> dict[str, Any]:
        payload: dict[str, Any] = {
            "scope_tags": list(scope_tags or []),
            "max_candidates": max_candidates,
            "start_negotiation": start_negotiation,
        }
        if k is not None:
            payload["k"] = k
        resp = await self._request("POST",
            self._protocol_url(f"/formulations/{session_id}/confirm"),
            json=payload,
            headers=self._protocol_headers(),
        )
        return self._handle_response(resp)

    async def get_discovery_query(self, query_id: str) -> dict[str, Any]:
        resp = await self._request("GET",
            self._protocol_url(f"/discover/{query_id}"),
            headers=self._protocol_headers(),
        )
        return self._handle_response(resp)

    async def discover(
        self,
        *,
        requester: str,
        demand_text: str,
        scope_tags: list[str] | None = None,
        scene_context: str | None = None,
        max_candidates: int = 10,
        start_negotiation: bool = False,
        k: int | None = None,
    ) -> dict[str, Any]:
        payload: dict[str, Any] = {
            "requester": requester,
            "demand_source": "plaintext",
            "demand_text": demand_text,
            "scope_tags": list(scope_tags or []),
            "max_candidates": max_candidates,
            "start_negotiation": start_negotiation,
        }
        if k is not None:
            payload["k"] = k
        if scene_context:
            payload["scene_context"] = scene_context
        resp = await self._request("POST",
            self._protocol_url("/discover"),
            headers=self._protocol_headers(),
            json=payload,
        )
        return self._handle_response(resp)

    async def create_invitation(
        self,
        *,
        inviter: str,
        nomination_id: str | None = None,
        invitee: str | None = None,
        expires_in_hours: int = 24,
    ) -> dict[str, Any]:
        payload: dict[str, Any] = {
            "inviter": inviter,
            "expires_in_hours": expires_in_hours,
        }
        if nomination_id is not None:
            payload["nomination_id"] = nomination_id
        if invitee is not None:
            payload["invitee"] = invitee
        resp = await self._request("POST",
            self._protocol_url("/invitations"),
            headers=self._protocol_headers(),
            json=payload,
        )
        return self._handle_response(resp)

    async def list_invitations(self, *, agent_id: str | None = None) -> dict[str, Any]:
        params = {"agent_id": agent_id} if agent_id else None
        resp = await self._request("GET",
            self._protocol_url("/invitations"),
            headers=self._protocol_headers(),
            params=params,
        )
        return self._handle_response(resp)

    async def respond_invitation(self, invitation_id: str, *, agent_id: str, action: str) -> dict[str, Any]:
        resp = await self._request("PATCH",
            self._protocol_url(f"/invitations/{invitation_id}"),
            headers=self._protocol_headers(),
            json={"agent_id": agent_id, "action": action},
        )
        return self._handle_response(resp)

    async def create_run(
        self,
        *,
        initiator: str,
        invitation_ids: list[str],
        max_rounds: int = 4,
    ) -> dict[str, Any]:
        headers = self._protocol_headers()
        headers["Idempotency-Key"] = uuid.uuid4().hex
        resp = await self._request("POST",
            self._protocol_url("/runs"),
            headers=headers,
            json={
                "initiator": initiator,
                "invitation_ids": invitation_ids,
                "max_rounds": max_rounds,
            },
        )
        return self._handle_response(resp)

    async def get_run(self, run_id: str) -> dict[str, Any]:
        resp = await self._request("GET",
            self._protocol_url(f"/runs/{run_id}"),
            headers=self._protocol_headers(),
        )
        return self._handle_response(resp)

    async def get_run_prompt(self, run_id: str, *, agent_id: str) -> dict[str, Any]:
        resp = await self._request("GET",
            self._protocol_url(f"/runs/{run_id}/prompt"),
            headers=self._protocol_headers(),
            params={"agent_id": agent_id},
        )
        return self._handle_response(resp)

    async def respond_run(
        self,
        run_id: str,
        *,
        agent_id: str,
        round_number: int,
        content: str,
        metadata: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        resp = await self._request("POST",
            self._protocol_url(f"/runs/{run_id}/respond"),
            headers=self._protocol_headers(),
            json={
                "agent_id": agent_id,
                "round": round_number,
                "content": content,
                "metadata": metadata,
            },
        )
        return self._handle_response(resp)

    async def get_run_result(self, run_id: str, *, agent_id: str) -> dict[str, Any]:
        resp = await self._request("GET",
            self._protocol_url(f"/runs/{run_id}/result"),
            headers=self._protocol_headers(),
            params={"agent_id": agent_id},
        )
        return self._handle_response(resp)

    async def submit_feedback(
        self,
        *,
        agent_id: str,
        target_type: str,
        target_id: str,
        exposure_event_id: str,
        rating: int,
        comment: str | None = None,
    ) -> dict[str, Any]:
        resp = await self._request("POST",
            self._protocol_url("/feedback"),
            headers=self._protocol_headers(),
            json={
                "agent_id": agent_id,
                "target_type": target_type,
                "target_id": target_id,
                "exposure_event_id": exposure_event_id,
                "rating": rating,
                "comment": comment,
            },
        )
        return self._handle_response(resp)

    async def get_usage(self, *, period: str = "month", agent_id: str | None = None) -> dict[str, Any]:
        params: dict[str, Any] = {"period": period}
        if agent_id is not None:
            params["agent_id"] = agent_id
        resp = await self._request("GET",
            self._protocol_url("/usage"),
            headers=self._protocol_headers(),
            params=params,
        )
        return self._handle_response(resp)

    async def update_profile(self, agent_id: str, profile_text: str) -> dict[str, Any]:
        """Update the currently selected agent profile through canonical protocol."""
        resp = await self._request("PUT",
            self._protocol_url(f"/agents/{agent_id}"),
            json={"profile_text": profile_text},
            headers=self._protocol_headers(),
        )
        return self._handle_response(resp)

    async def delete_agent(self, agent_id: str) -> None:
        """DELETE /protocol/agents/{agent_id}."""
        resp = await self._request("DELETE",
            self._protocol_url(f"/agents/{agent_id}"),
            headers=self._protocol_headers(),
        )
        if resp.status_code == 204:
            return
        self._handle_response(resp)

    async def refresh_token(self) -> dict[str, Any]:
        """POST /protocol/auth/token — refresh session token."""
        resp = await self._request("POST",
            self._protocol_url("/auth/token"),
            headers=self._protocol_headers(),
        )
        return self._handle_response(resp)

    async def bind_byok(self, api_key: str, provider: str = "anthropic") -> dict[str, Any]:
        """POST /protocol/auth/byok-session — bind user's own API key."""
        resp = await self._request("POST",
            self._protocol_url("/auth/byok-session"),
            headers=self._protocol_headers(),
            json={"api_key": api_key, "provider": provider},
        )
        return self._handle_response(resp)

    async def get_byok(self) -> dict[str, Any]:
        """GET /protocol/auth/byok-session — check BYOK status."""
        resp = await self._request("GET",
            self._protocol_url("/auth/byok-session"),
            headers=self._protocol_headers(),
        )
        return self._handle_response(resp)

    async def clear_byok(self) -> dict[str, Any]:
        """DELETE /protocol/auth/byok-session — remove BYOK binding."""
        resp = await self._request("DELETE",
            self._protocol_url("/auth/byok-session"),
            headers=self._protocol_headers(),
        )
        return self._handle_response(resp)

    async def get_invitation(self, invitation_id: str) -> dict[str, Any]:
        """GET /protocol/invitations/{invitation_id}."""
        resp = await self._request("GET",
            self._protocol_url(f"/invitations/{invitation_id}"),
            headers=self._protocol_headers(),
        )
        return self._handle_response(resp)

    async def send_message(
        self,
        *,
        sender_agent_id: str,
        receiver_agent_id: str,
        source_run_id: str,
        content: str,
        source_delivery_id: str | None = None,
        client_msg_id: str | None = None,
    ) -> dict[str, Any]:
        payload: dict[str, Any] = {
            "sender_agent_id": sender_agent_id,
            "receiver_agent_id": receiver_agent_id,
            "source_run_id": source_run_id,
            "content": content,
            "client_msg_id": client_msg_id or str(uuid.uuid4()),
        }
        if source_delivery_id is not None:
            payload["source_delivery_id"] = source_delivery_id
        resp = await self._request("POST",
            self._protocol_url("/conversations"),
            headers=self._protocol_headers(),
            json=payload,
        )
        return self._handle_response(resp)

    async def list_conversations(self, *, limit: int = 20, offset: int = 0) -> dict[str, Any]:
        resp = await self._request("GET",
            self._protocol_url("/conversations"),
            headers=self._protocol_headers(),
            params={"limit": limit, "offset": offset},
        )
        return self._handle_response(resp)

    async def get_conversation_messages(
        self,
        conversation_id: str,
        *,
        since_seq: int = 0,
        limit: int = 50,
    ) -> dict[str, Any]:
        resp = await self._request("GET",
            self._protocol_url(f"/conversations/{conversation_id}/messages"),
            headers=self._protocol_headers(),
            params={"since_seq": since_seq, "limit": limit},
        )
        return self._handle_response(resp)

    async def close(self) -> None:
        """Close the underlying HTTP client."""
        await self._http.aclose()
