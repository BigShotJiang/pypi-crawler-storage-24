from dc_sdk.errors import Error
from dc_sdk.src.mapping import Mapping
import traceback

def get_action_name(action: int) -> str:
    return {
        0: "authenticating",
        1: "retrieving fields",
        2: "retrieving 5 row preview",
        3: "testing connection",
        4: "starting the connector"
    }[action]

def handler(event, context):
    """Lambda Handler"""
    action_name = None
    internal_error = False
    message = None
    results = None
    error = None
    mapping = None
    action = int(event['action']) if 'action' in event else 4
    get_objects = event.get('get_objects', True)
    credentials_dict = event['credentials'] if 'credentials' in event else None
    object_id = event['object_id'] if 'object_id' in event else None
    field_ids = event['mapping'] if 'mapping' in event else None
    options = event['options'] if 'options' in event else dict()

    try:
        action_name = get_action_name(action)
        mapping = Mapping(credentials_dict)

        if action == 0:
            if get_objects:
                results, message = mapping.connect_get_objects()
            else:
                results, message = mapping.authenticate()
        elif action == 1:
            results, message = mapping.get_fields(object_id, options)
        elif action == 2:
            results, message = mapping.get_five_row_preview(
                object_id, field_ids, options)
        elif action == 3:
            results, message = mapping.test_connection()
        else:
            raise Error("Invalid action", "InvalidActionError")
    except Error as e:
        message = e.message
        internal_error = e.internal
        error_trace = traceback.format_exc()
        error = error_trace

    except Exception as e:
        error_trace = traceback.format_exc()
        error = error_trace
        internal_error = True

    if error:
        print(error)

    return {
        'message': message if not internal_error else f"Something went wrong with {action_name}",
        'results': results,
        'credentials': mapping.connector.credentials if mapping else None,
        'error': error,
        'internal_error': internal_error
    }
