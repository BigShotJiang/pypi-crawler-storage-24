import os, sys
from typing import ClassVar
import requests

class PipelineEnvironment:
    server_endpoint: ClassVar[str] = os.getenv("SERVER_ENDPOINT") or ""
    server_api_key: ClassVar[str] = os.getenv("SERVER_API_KEY") or ""
    pipeline_id: ClassVar[str] = os.getenv("PIPELINE_ID") or ""
    pipeline_run_history_id =os.getenv("PIPELINE_RUN_HISTORY_ID") or None
    app_env: ClassVar[str] = os.getenv("APP_ENV") or ""
    master_hash: ClassVar[str] = os.getenv("MASTER_HASH") or ""
    task: ClassVar[str] = os.getenv("TASK") or ""
    platform: ClassVar[str] = os.getenv("PLATFORM") or "aws"
    storage_account_name: ClassVar[str] = os.getenv("AZURE_STORAGE_ACCOUNT_NAME") or "dcstoragesbx001"
    storage_container_name: ClassVar[str] = "transfers"
    azure_subscription_id: ClassVar[str] = os.getenv("AZURE_SUBSCRIPTION_ID") or ""
    azure_resource_group_name: ClassVar[str] = os.getenv("AZURE_RESOURCE_GROUP_NAME") or "dataconnector-sbx-reg"
    azure_managed_identity_client_id: ClassVar[str] = os.getenv("AZURE_MANAGED_IDENTITY_CLIENT_ID") or ""
    aws_access_key_id: ClassVar[str] = os.getenv("AWS_ACCESS_KEY_ID") or ""
    aws_secret_access_key: ClassVar[str] = os.getenv("AWS_SECRET_ACCESS_KEY") or ""
    aws_region: ClassVar[str] = os.getenv("AWS_DEFAULT_REGION") or "us-east-2"
    aws_s3_bucket: ClassVar[str] = os.getenv("AWS_S3_BUCKET") or f'dataconnector-transfers-{os.getenv("APP_ENV")}'
    batch_start: ClassVar[int] = int(os.getenv("BATCH_START") or 1)
    source_connector: ClassVar[str] = os.getenv("SOURCE_CONNECTOR") or ""
    destination_connector: ClassVar[str] = os.getenv("DESTINATION_CONNECTOR") or ""
    connected_container: ClassVar[bool] = os.getenv("CONNECTED_CONTAINER") == "TRUE" or False
    task_id: ClassVar[str] = None
    source_endpoint: ClassVar[str] = os.getenv("SOURCE_ENDPOINT") or "http://localhost:5000"
    destination_endpoint: ClassVar[str] = os.getenv("DESTINATION_ENDPOINT") or "http://localhost:5001"

    @staticmethod
    def validate_environment():
        if not PipelineEnvironment.server_endpoint:
            print("SERVER_ENDPOINT is not set in the .env file")
            sys.exit(1)

        if not PipelineEnvironment.server_api_key:
            print("SERVER_API_KEY is not set in the .env file")
            sys.exit(1)

        if not PipelineEnvironment.pipeline_id:
            print("PIPELINE_ID is not set in the .env file")
            sys.exit(1)

        if not PipelineEnvironment.app_env:
            print("APP_ENV is not set in the .env file")
            sys.exit(1)

        if not PipelineEnvironment.task:
            print("TASK is not set in the .env file")
            sys.exit(1)

        if not PipelineEnvironment.azure_subscription_id and PipelineEnvironment.platform == "azure":
            print("AZURE_SUBSCRIPTION_ID is not set in the .env file")
            sys.exit(1)

        if not PipelineEnvironment.azure_managed_identity_client_id and PipelineEnvironment.platform == "azure":
            print("AZURE_MANAGED_IDENTITY_CLIENT_ID is not set in the .env file")
            sys.exit(1)

        if not PipelineEnvironment.aws_access_key_id and PipelineEnvironment.platform == "azure":
            print("AWS_ACCESS_KEY_ID is not set in the .env file")
            sys.exit(1)

        if not PipelineEnvironment.aws_secret_access_key and PipelineEnvironment.platform == "azure":
            print("AWS_SECRET_ACCESS_KEY is not set in the .env file")
            sys.exit(1)

        # set task id
        if PipelineEnvironment.platform == "aws":
            PipelineEnvironment.task_id = PipelineEnvironment.get_task_id()

    @staticmethod
    def set_pipeline_run_history_id(pipeline_run_history_id):
        os.environ["PIPELINE_RUN_HISTORY_ID"] = pipeline_run_history_id
        PipelineEnvironment.pipeline_run_history_id = pipeline_run_history_id

    @staticmethod
    def get_task_id():
        metadata_uri = os.getenv("ECS_CONTAINER_METADATA_URI_V4")

        # Not running in ECS
        if not metadata_uri:
            return None

        try:
            response = requests.get(
                f"{metadata_uri}/task",
                timeout=2
            )
            response.raise_for_status()

            task_metadata = response.json()
            return task_metadata["TaskARN"].split("/")[-1]

        except Exception as e:
            print(f"Failed to retrieve ECS task id: {e}")
            return None

class TestRunnerEnvironment:
    app_env: ClassVar[str] = os.getenv("APP_ENV") or ""
    orchestrator_base_url: ClassVar[str] = os.getenv("ORCHESTRATOR_BASE_URL") or ""
    connector_id: ClassVar[str] = os.getenv("CONNECTOR_ID") or ""
    connector_code_repo_id: ClassVar[str] = os.getenv("CONNECTOR_CODE_REPOSITORY_ID") or ""
    api_username: ClassVar[str] = os.getenv("API_USERNAME") or ""
    api_password: ClassVar[str] = os.getenv("API_PASSWORD") or ""
    github_token: ClassVar[str] = os.getenv("GITHUB_TOKEN") or ""
    ai_token: ClassVar[str] = os.getenv("AI_TOKEN") or ""
    test_mode: ClassVar[bool] = os.getenv("APP_ENV") == "local" or False

    @staticmethod
    def validate_environment():
        if not TestRunnerEnvironment.connector_id:
            print("CONNECTOR_ID is not set in the .env file!")
            sys.exit(1)
        if not TestRunnerEnvironment.connector_code_repo_id:
            print("CONNECTOR_CODE_REPOSITORY_ID is not set in the .env file")
            sys.exit(1)
        if not TestRunnerEnvironment.orchestrator_base_url:
            print("ORCHESTRATOR_BASE_URL is not set in the .env file")
            sys.exit(1)
        if not TestRunnerEnvironment.api_username:
            print("API_USERNAME is not set in the .env file")
            sys.exit(1)
        if not TestRunnerEnvironment.api_password:
            print("API_PASSWORD is not set in the .env file")
            sys.exit(1)
        if not TestRunnerEnvironment.github_token:
            print("GITHUB_TOKEN is not set in the .env file")
            sys.exit(1)
        if not TestRunnerEnvironment.ai_token:
            print("AI_TOKEN is not set in the .env file")
            sys.exit(1)
        if not TestRunnerEnvironment.app_env:
            print("APP_ENV is not set in the .env file")
            sys.exit(1)

