import logging
import json
import threading
from datetime import datetime, timezone

class PipelineLogger(logging.Handler):
    def __init__(self, api):
        super().__init__()
        self.api = api

    def emit(self, record):
        try:
            if record.levelno == logging.DEBUG or not getattr(record, "api", False):
                return

            log_entry = self.format(record)
            if record.exc_info:
                error = record.exc_info[1]
                stacktrace = self.formatException(record.exc_info)
            else:
                error = getattr(record, "error", None)
                stacktrace = getattr(record, "stacktrace", None)

            payload = {
                "level": record.levelname,
                "message": record.getMessage(),
                "timestamp": datetime.now(timezone.utc).isoformat(),
                "logger": record.name,
                "file": record.pathname,
                "line": record.lineno,
                "stage": getattr(record, "stage", None),
                "task": getattr(record, "task", None),
                "internal": getattr(record, "internal", False),
                "unhandled": getattr(record, "unhandled", False),
                "error": str(error) if error else None,
                "stacktrace": stacktrace
            }

            # Send async so logging doesn't block your app
            threading.Thread(
                target=self.send_log,
                args=(payload,),
                daemon=True
            ).start()

        except Exception:
            pass  # never crash app because of logging

    def send_log(self, payload):
        self.api.logv2(payload)


def setup_logging(api):
    root_logger = logging.getLogger()
    root_logger.setLevel(logging.INFO)

    root_logger.handlers = []

    console = logging.StreamHandler()
    console.setLevel(logging.INFO)
    root_logger.addHandler(console)

    api_handler = PipelineLogger(api)
    api_handler.setLevel(logging.INFO)
    root_logger.addHandler(api_handler)