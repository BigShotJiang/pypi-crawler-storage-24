import os
import boto3
import json
from typing import Dict
from base64 import b64decode

APP_ENV = os.environ.get("APP_ENV")

s3_client = boto3.client('s3')
s3_resource = boto3.resource('s3')
ecs_resource = boto3.client('ecs')
kms_client = boto3.client('kms')

class AwsService:
    def __init__(self, s3_bucket) -> None:
        self.s3_bucket = s3_bucket
        self._ecs_cluster_name = APP_ENV if APP_ENV != "local" else "development"

    def get_keys(self, pipeline_run_history_id):
        keys = []
        response = s3_client.list_objects(Bucket=self.s3_bucket, Prefix=f"transfers/e{pipeline_run_history_id}")
        if 'Contents' in response:
            for key in response['Contents']:
                keys.append(key['Key'])
        return keys

    def get_dev_keys(self, prefix):
        keys = []
        response = s3_client.list_objects(Bucket=self.s3_bucket, Prefix=f"devTransfers/e{prefix}")
        if 'Contents' in response:
            for key in response['Contents']:
                keys.append(key['Key'])
        return keys

    def download_object(self, key_name):
        file = s3_resource.Object(self.s3_bucket, key_name)
        return file.get()['Body']

    def upload_object(self, key_name, json_buffer=None, file_path=None):
        if json_buffer is not None:
            s3_resource.Object(
                self.s3_bucket, key_name).put(Body=json_buffer.getvalue())
        elif file_path is not None:
            s3_client.upload_file(file_path, self.s3_bucket, key_name)
        else:
            raise ValueError("Either json_buffer or file_path must be provided")

    def get_object_size(self, key_name):
        response = s3_client.head_object(
            Bucket=self.s3_bucket, Key=key_name)
        return float(response['ContentLength'])

    def delete_object(self, key_name):
        s3_client.delete_object(
            Bucket=self.s3_bucket,
            Key=key_name,
        )

    def start_ecs_task(self, task_name:str, task_version:str, pipeline_id: str, pipeline_run_history_id: str):
        response = ecs_resource.run_task(
            cluster=self._ecs_cluster_name,
            count=1,
            enableECSManagedTags=False,
            enableExecuteCommand=False,
            launchType='FARGATE',
            networkConfiguration={
                'awsvpcConfiguration': {
                    'subnets': [
                        'subnet-095c3230c890e0841',
                    ],
                    'securityGroups': [
                        'sg-08d46d487577cbdf9',
                    ],
                    'assignPublicIp': 'ENABLED'
                }
            },
            overrides={
                'containerOverrides': [
                    {
                        'name': task_name,
                        'command': ['app.py'],
                        'environment': [
                            {
                                'name': 'PIPELINE_ID',
                                'value': pipeline_id
                            },
                            {
                                'name': 'PIPELINE_RUN_HISTORY_ID',
                                'value': pipeline_run_history_id
                            },
                            {
                                'name': 'TASK',
                                'value': 'DESTINATION'
                            },
                            {
                                'name': 'APP_ENV',
                                'value': os.environ.get("APP_ENV")
                            },
                            {
                                'name': 'SERVER_ENDPOINT',
                                'value': os.environ.get("SERVER_ENDPOINT")
                            },
                            {
                                'name': 'SERVER_API_KEY',
                                'value': os.environ.get("SERVER_API_KEY")
                            },
                            {
                                'name': 'AWS_DEFAULT_REGION',
                                'value': os.environ.get("AWS_DEFAULT_REGION")
                            }
                        ],
                    },
                ],
            },
            platformVersion='LATEST',
            taskDefinition=f"{task_name}:{task_version}"
        )

        if len(response['tasks']) == 0:
            raise Exception("Failed to start next connector")

        return response['tasks'][0]['taskArn'].split("/")[-1]

    def decrypt_customer_data(self, encrypted_data: str, customer_id: str) -> str:
        """Decrypt data with customer context"""
        try:
            response = kms_client.decrypt(
                CiphertextBlob=b64decode(encrypted_data.encode('utf-8')),
                EncryptionContext={'CustomerId': customer_id}
            )
            if 'Plaintext' not in response:
                raise Exception('Decryption failed')
            
            return response['Plaintext'].decode('utf-8')
        except Exception as e:
            raise Exception(f'Decryption failed: {str(e)}')

    def decrypt_customer_data_object(self, encrypted_data: str, customer_id: str) -> Dict:
        """Decrypt JSON data with customer context"""
        data = self.decrypt_customer_data(encrypted_data, customer_id)
        return json.loads(data)