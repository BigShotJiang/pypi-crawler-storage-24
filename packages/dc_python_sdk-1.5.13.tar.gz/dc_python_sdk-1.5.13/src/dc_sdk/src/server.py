from fastapi import FastAPI
from pydantic import BaseModel
from typing import Optional, Dict, Any
import traceback
import os
from .services.loader import load_connector
from dc_sdk.errors import Error
from .services.session import create_session, get_session

app = FastAPI()


class InvokeRequest(BaseModel):
    method: str
    session_id: Optional[str] = None
    credentials: Optional[Dict[str, Any]] = None
    params: Optional[Dict[str, Any]] = {}

@app.get("/health")
def health():
    return {"status": "healthy"}

@app.post("/invoke")
def invoke(req: InvokeRequest):
    connector = None
    result = None
    message = None
    error = None
    error_dict = {}
    internal_error = False
    session_id = req.session_id

    try:
        # 🔥 get or create connector
        if session_id:
            connector = get_session(session_id)
            if not connector:
                raise Error("Invalid session", "SessionError")

        else:
            if not req.credentials:
                raise Error("Credentials required", "CredentialError")

            Connector = load_connector()
            connector = Connector(req.credentials)

            # 👇 optional auto-auth on first call
            if hasattr(connector, "authenticate"):
                connector.authenticate()

            session_id = create_session(connector)

        # 🔥 dynamic method call
        if not hasattr(connector, req.method):
            raise Error(f"Method '{req.method}' not found on connector", "MethodError")

        method = getattr(connector, req.method)

        if not callable(method):
            raise Error(f"Attribute '{req.method}' is not callable", "MethodError")

        # 👇 THIS is the magic
        result = method(**(req.params or {}))

        message = f"{req.method} executed successfully"

    except Error as e:
        message = e.message
        internal_error = e.internal
        error = traceback.format_exc()
        error_dict = e.to_dict()

    except Exception:
        error = traceback.format_exc()
        internal_error = True

    if error:
        print(error)

    return {
        "message": message if not internal_error else "Something went wrong",
        "results": result,
        "session_id": session_id,
        **error_dict
    }


def start_server():
    import uvicorn
    uvicorn.run(
        "dc_sdk.src.server:app",
        host="0.0.0.0",
        port=int(os.getenv("PORT", 5000))
    )