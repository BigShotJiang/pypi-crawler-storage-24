"""lapq/algorithms/dynamics.py — Dynamics, Lattice Models & Metrology algorithms."""

from __future__ import annotations
import math
from typing import TYPE_CHECKING, List, Optional

if TYPE_CHECKING:
    from lapq.client import QPU1
    from lapq.circuit import Circuit


def schrodinger_evolution(qpu: "QPU1", n: int, time: float = 1.0,
                           steps: int = 4) -> "Circuit":
    """
    Trotterized Schrödinger time evolution for a chain (ZZ + X Hamiltonian).

    Example::

        result = schrodinger_evolution(qpu, n=4, time=1.0).run()
    """
    c = qpu.circuit(n)
    for q in range(n): c.h(q)
    dt = time / steps
    for _ in range(steps):
        for i in range(n - 1):
            c.rzz(i, i + 1, dt)
        for q in range(n):
            c.rx(q, dt)
    return c.measure()


def uhrig_dynamical_decoupling(qpu: "QPU1", n: int, n_pulses: int = 4) -> "Circuit":
    """
    Uhrig Dynamical Decoupling (UDD) sequence for n qubits.

    Applies X pulses at Uhrig-optimal times to suppress decoherence.

    Example::

        result = uhrig_dynamical_decoupling(qpu, 1, n_pulses=4).run()
    """
    c = qpu.circuit(n)
    for q in range(n): c.h(q)
    for k in range(1, n_pulses + 1):
        angle = math.pi * math.sin(math.pi * k / (2 * n_pulses + 2))**2
        for q in range(n):
            c.rz(q, angle)
            c.x(q)
    return c.measure()


def carr_purcell_meiboom_gill(qpu: "QPU1", n: int, n_echoes: int = 4) -> "Circuit":
    """
    CPMG spin-echo sequence for dynamical decoupling.

    Example::

        result = carr_purcell_meiboom_gill(qpu, 1, n_echoes=4).run()
    """
    c = qpu.circuit(n)
    for q in range(n): c.h(q)
    interval = math.pi / (2 * n_echoes)
    for _ in range(n_echoes):
        for q in range(n):
            c.rz(q, interval)
            c.x(q)
            c.rz(q, interval)
    return c.measure()


def xy_decoupling(qpu: "QPU1", n: int, seq_len: int = 4) -> "Circuit":
    """
    XY-4 / XY-8 dynamical decoupling sequence.

    Example::

        result = xy_decoupling(qpu, 2, seq_len=4).run()
    """
    c = qpu.circuit(n)
    for q in range(n): c.h(q)
    interval = math.pi / (2 * seq_len)
    for i in range(seq_len):
        for q in range(n):
            c.rz(q, interval)
            if i % 2 == 0: c.x(q)
            else: c.y(q)
    return c.measure()


def heisenberg_model(qpu: "QPU1", n: int, J: float = 1.0, time: float = 1.0,
                      steps: int = 4) -> "Circuit":
    """
    Isotropic Heisenberg model: H = J Σ (XX+YY+ZZ).

    Example::

        result = heisenberg_model(qpu, 4, J=1.0, time=1.0).run()
    """
    c = qpu.circuit(n)
    for q in range(n): c.h(q)
    dt = time / steps
    for _ in range(steps):
        for i in range(n - 1):
            c.rxx(i, i + 1, J * dt)
            c.ryy(i, i + 1, J * dt)
            c.rzz(i, i + 1, J * dt)
    return c.measure()


def transverse_ising_model(qpu: "QPU1", n: int, J: float = 1.0, h: float = 0.5,
                            time: float = 1.0, steps: int = 4) -> "Circuit":
    """
    Transverse-field Ising model: H = -J Σ ZZ - h Σ X.

    Example::

        result = transverse_ising_model(qpu, 4).run()
    """
    c = qpu.circuit(n)
    for q in range(n): c.h(q)
    dt = time / steps
    for _ in range(steps):
        for i in range(n - 1):
            c.rzz(i, i + 1, 2 * J * dt)
        for q in range(n):
            c.rx(q, 2 * h * dt)
    return c.measure()


def xy_model(qpu: "QPU1", n: int, J: float = 1.0, h: float = 0.5,
              time: float = 1.0, steps: int = 4) -> "Circuit":
    """XY Model: H = J Σ (XX + YY) - h Σ Z."""
    c = qpu.circuit(n)
    for q in range(n): c.h(q)
    dt = time / steps
    for _ in range(steps):
        for i in range(n - 1):
            c.rxx(i, i + 1, J * dt)
            c.ryy(i, i + 1, J * dt)
        for q in range(n):
            c.rz(q, h * dt)
    return c.measure()


def ramsey_interferometry(qpu: "QPU1", n: int = 1, wait_time: float = 0.5) -> "Circuit":
    """
    Ramsey interferometry for quantum sensing.
    H → free evolution → H → measure.

    Example::

        result = ramsey_interferometry(qpu, n=1, wait_time=0.5).run()
    """
    c = qpu.circuit(n)
    for q in range(n):
        c.h(q)
        c.rz(q, 2 * math.pi * wait_time)
        c.h(q)
    return c.measure()


def spin_echo_sensing(qpu: "QPU1", n: int = 1, interrogation_time: float = 0.5) -> "Circuit":
    """
    Spin-echo (Hahn echo) quantum sensing circuit.

    Example::

        result = spin_echo_sensing(qpu, n=1).run()
    """
    c = qpu.circuit(n)
    for q in range(n):
        c.h(q)
        c.rz(q, math.pi * interrogation_time)
        c.x(q)
        c.rz(q, math.pi * interrogation_time)
        c.x(q)
        c.h(q)
    return c.measure()


def quantum_magnetometry(qpu: "QPU1", n: int = 1, field_strength: float = 0.1) -> "Circuit":
    """
    Quantum magnetometry sensor circuit using Ramsey protocol.

    Example::

        result = quantum_magnetometry(qpu, n=2, field_strength=0.05).run()
    """
    return ramsey_interferometry(qpu, n, wait_time=field_strength)


def heisenberg_limited_sensing(qpu: "QPU1", n_probes: int = 4,
                                parameter: float = 0.1) -> "Circuit":
    """
    Heisenberg-limited phase estimation using GHZ probe state.

    Example::

        result = heisenberg_limited_sensing(qpu, n_probes=4).run()
    """
    c = qpu.circuit(n_probes)
    c.ghz()
    for q in range(n_probes):
        c.rz(q, parameter * n_probes)
    # Inverse GHZ for readout
    for q in range(1, n_probes):
        c.cx(0, q)
    c.h(0)
    return c.measure()
