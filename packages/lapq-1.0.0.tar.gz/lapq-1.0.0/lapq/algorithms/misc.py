"""lapq/algorithms/misc.py — Miscellaneous advanced quantum algorithms."""

from __future__ import annotations
import math
from typing import TYPE_CHECKING, List, Optional

if TYPE_CHECKING:
    from lapq.client import QPU1
    from lapq.circuit import Circuit


def haar_random_state(qpu: "QPU1", n: int) -> "Circuit":
    """
    Approximate Haar-random state using random Ry/Rz + entanglement layers.

    Example::

        result = haar_random_state(qpu, 4).run()
    """
    c = qpu.circuit(n)
    for q in range(n):
        c.ry(q, math.pi * (q + 1) / n)
        c.rz(q, math.pi * (q + 2) / (n + 1))
    for i in range(n - 1):
        c.cx(i, i + 1)
    for q in range(n):
        c.ry(q, math.pi * (q + 3) / (n + 2))
    return c.measure()


def random_circuit(qpu: "QPU1", n: int, depth: int = 10) -> "Circuit":
    """
    Random quantum circuit of given depth for benchmarking.

    Example::

        result = random_circuit(qpu, 4, depth=10).run()
    """
    c = qpu.circuit(n)
    for d in range(depth):
        for q in range(n):
            angle = math.pi * ((d * n + q + 1) % 8 + 1) / 8
            if (d + q) % 3 == 0: c.rx(q, angle)
            elif (d + q) % 3 == 1: c.ry(q, angle)
            else: c.rz(q, angle)
        for q in range(d % 2, n - 1, 2):
            c.cx(q, q + 1)
    return c.measure()


def quantum_monte_carlo(qpu: "QPU1", n: int = 4, samples: int = 4) -> "Circuit":
    """
    Quantum Monte Carlo amplitude estimation circuit.

    Example::

        result = quantum_monte_carlo(qpu, n=4).run()
    """
    c = qpu.circuit(n + 1)  # n state + 1 ancilla
    for q in range(n): c.ry(q, math.pi / 4)
    for _ in range(samples):
        c.h(n)
        for q in range(n):
            c.cp(q, n, math.pi / (2 ** (q + 1)))
        c.h(n)
    return c.measure()


def option_pricing_quantum(qpu: "QPU1", n_bits: int = 4, volatility: float = 0.2,
                            time: float = 1.0) -> "Circuit":
    """
    Quantum option pricing via amplitude estimation (Black-Scholes approximation).

    Example::

        result = option_pricing_quantum(qpu, n_bits=4).run()
    """
    c = qpu.circuit(n_bits + 1)
    # Log-normal distribution encoding
    sigma = volatility * math.sqrt(time)
    for q in range(n_bits):
        c.ry(q, sigma * math.pi / (q + 1))
    c.qft(list(range(n_bits)))
    # Payoff oracle (mark in-the-money states)
    c.h(n_bits)
    for q in range(n_bits):
        c.cp(q, n_bits, math.pi / (2 ** (q + 1)))
    c.h(n_bits)
    return c.measure()


def quantum_minimum_finding(qpu: "QPU1", n: int = 3) -> "Circuit":
    """
    Quantum minimum finding via Grover-based search (Dürr-Høyer algorithm skeleton).

    Example::

        result = quantum_minimum_finding(qpu, n=3).run()
    """
    c = qpu.circuit(n)
    for q in range(n): c.h(q)
    c.grover_diffusion()
    return c.measure()


def quantum_ram(qpu: "QPU1", n_address: int = 2, data: Optional[List[int]] = None) -> "Circuit":
    """
    Quantum RAM (QRAM) — fanout tree architecture.
    Addresses n_address qubits → retrieves superposed data in ancillas.

    Example::

        result = quantum_ram(qpu, n_address=2, data=[0,1,1,0]).run()
    """
    if data is None:
        data = [1, 0] * (2 ** n_address // 2)
    n_data = 1
    n = n_address + n_data
    c = qpu.circuit(n)
    for q in range(n_address): c.h(q)  # Address superposition
    # Fan-out: encode data bits
    for idx, bit in enumerate(data[:2**n_address]):
        if bit:
            bits = format(idx, f"0{n_address}b")
            for q, b in enumerate(reversed(bits)):
                if b == '0': c.x(q)
            if n_address == 1:
                c.cx(0, n_address)
            elif n_address == 2:
                c.ccnot(0, 1, n_address)
            for q, b in enumerate(reversed(bits)):
                if b == '0': c.x(q)
    return c.measure()


def harrow_hassidim_lloyd(qpu: "QPU1", n_b: int = 2, n_clock: int = 3) -> "Circuit":
    """
    HHL algorithm skeleton: quantum linear system solver Ax = b.

    Parameters
    ----------
    n_b:     Qubits for the b-vector register.
    n_clock: QPE precision bits.

    Example::

        result = harrow_hassidim_lloyd(qpu, n_b=2, n_clock=3).run()
    """
    n = 1 + n_clock + n_b  # 1 ancilla + clock + b-register
    c = qpu.circuit(n)
    # Load b
    c.h(1 + n_clock)
    # QPE
    for q in range(n_clock): c.h(1 + q)
    for k in range(n_clock):
        angle = 2 * math.pi / (2 ** (k + 1))
        c.crz(1 + k, 1 + n_clock, angle * (2**k))
    c.iqft(list(range(1, 1 + n_clock)))
    # Eigenvalue inversion (rotation of ancilla proportional to 1/λ)
    for k in range(n_clock):
        angle = math.pi / (2 ** k + 1)
        c.cry(1 + k, 0, angle)
    # Uncompute QPE
    c.qft(list(range(1, 1 + n_clock)))
    return c.measure()


def variational_quantum_linear_solver(qpu: "QPU1", n: int = 2, layers: int = 2) -> "Circuit":
    """
    VQLS: variational quantum linear systems solver ansatz.

    Example::

        result = variational_quantum_linear_solver(qpu, n=3).run()
    """
    c = qpu.circuit(n)
    for q in range(n): c.h(q)
    for _ in range(layers):
        for i in range(n - 1):
            c.cx(i, i + 1)
        for q in range(n):
            c.ry(q, math.pi / (layers + 1))
    return c.measure()


def quantum_singular_value_estimation(qpu: "QPU1", n: int = 3,
                                       n_precision: int = 3) -> "Circuit":
    """
    Quantum Singular Value Estimation via block-encoding and QPE.

    Example::

        result = quantum_singular_value_estimation(qpu, n=3, n_precision=3).run()
    """
    total = n_precision + n
    c = qpu.circuit(total)
    for q in range(n_precision): c.h(q)
    for q in range(n): c.ry(n_precision + q, math.pi / 4)
    for k in range(n_precision):
        angle = math.pi / (2 ** (k + 1))
        c.cp(k, n_precision, angle)
    c.iqft(list(range(n_precision)))
    return c.measure()


def quantum_leader_election(qpu: "QPU1", n_parties: int = 3) -> "Circuit":
    """
    Quantum leader election protocol using W-state measurement.

    Example::

        result = quantum_leader_election(qpu, 3).run()
    """
    c = qpu.circuit(n_parties)
    c.w_state()
    return c.measure()


def quantum_voting(qpu: "QPU1", n_voters: int = 4, n_options: int = 2) -> "Circuit":
    """
    Anonymous quantum voting using entanglement.

    Example::

        result = quantum_voting(qpu, n_voters=4, n_options=2).run()
    """
    n = n_voters
    c = qpu.circuit(n)
    c.ghz()
    for q in range(n):
        if q % n_options == 0: c.z(q)
    return c.measure()


def quantum_prisoners_dilemma(qpu: "QPU1", entanglement: float = math.pi/2) -> "Circuit":
    """
    Eisert-Wilkens-Lewenstein quantum prisoner's dilemma.

    Example::

        result = quantum_prisoners_dilemma(qpu, entanglement=math.pi/2).run()
    """
    c = qpu.circuit(2)
    # Entangle with J operator
    c.h(0)
    c.cx(0, 1)
    c.rz(0, entanglement)
    c.rz(1, entanglement)
    # Strategies (default: cooperate = no flip)
    # Measure
    c.cx(0, 1)
    c.h(0)
    return c.measure()


def quantum_auction(qpu: "QPU1", n_bidders: int = 3) -> "Circuit":
    """
    Quantum auction protocol using W-state winner selection.

    Example::

        result = quantum_auction(qpu, n_bidders=3).run()
    """
    c = qpu.circuit(n_bidders)
    c.w_state()
    return c.measure()
