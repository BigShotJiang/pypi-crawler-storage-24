"""
lapq.algorithms — 150+ quantum algorithms across 12 categories.

All functions return a :class:`~lapq.Circuit` ready to ``.run()`` on QPU-1.

Get your API key at: https://qpu-1.lovable.app/api-access

Categories
----------
- **Search & Optimization** — Grover, QAOA, Amplitude Amplification
- **Chemistry & Simulation** — VQE, QPE, Trotter, Hubbard
- **Machine Learning** — QNN, QSVM, QGAN, QBM
- **Cryptography** — BB84, E91, Shor's, HSP
- **Oracle & Boolean** — Deutsch-Jozsa, Bernstein-Vazirani, Simon's
- **Transforms & Arithmetic** — QFT, Adder, Multiplier, Comparator
- **States & Communication** — Bell, GHZ, W, Teleportation, Superdense
- **Quantum Walks** — Discrete, Continuous, Coined
- **Benchmarking** — RB, XEB, Quantum Volume, Tomography
- **Dynamics & Lattice** — Spin models, Dynamical Decoupling
- **Metrology** — Ramsey, Spin-echo, Heisenberg-limited sensing
- **Miscellaneous** — HHL, VQLS, QRAM, Finance, Games, Elections
"""

# Search & Optimization
from lapq.algorithms.search import (
    grover,
    grover_multi_target,
    grover_adaptive,
    amplitude_amplification,
    fixed_point_amplitude_amplification,
    qaoa_maxcut,
    qaoa_max_independent_set,
    qaoa_tsp,
    qaoa_portfolio_optimization,
    qaoa_vertex_cover,
    qaoa_3sat,
    simulated_quantum_annealing,
    adiabatic_grover,
)

# Chemistry & Simulation
from lapq.algorithms.chemistry import (
    vqe_molecular,
    vqe_hydrogen_chain,
    vqe_lattice_model,
    vqe_custom_hamiltonian,
    phase_estimation,
    iterative_phase_estimation,
    phase_estimation_kitaev,
    trotter_suzuki_simulation,
    quantum_walk_simulation,
    ising_model_evolution,
    hubbard_model_simulation,
    ucc_ansatz,
)

# Machine Learning
from lapq.algorithms.ml import (
    qnn_classifier,
    qnn_regression,
    variational_quantum_classifier,
    quantum_autoencoder,
    quantum_kernel_estimation,
    qsvm,
    qgan_generator,
    qgan_discriminator,
    quantum_vae,
    qbm_train,
    quantum_reservoir_computing,
    quantum_extreme_learning_machine,
)

# Cryptography & Security
from lapq.algorithms.crypto import (
    bb84_protocol,
    e91_protocol,
    quantum_coin_flipping,
    quantum_secret_sharing,
    shors_period_finding,
    shors_factorization,
    shors_discrete_log,
    hidden_subgroup_problem,
    subset_sum_quantum,
)

# Oracle & Boolean Function Analysis
from lapq.algorithms.oracle import (
    deutsch_jozsa,
    deutsch_jozsa_multi_oracle,
    bernstein_vazirani,
    bernstein_vazirani_recursive,
    simons_algorithm,
    simons_generalized,
    walsh_hadamard_transform,
    bent_function_test,
    linear_independence_test,
)

# Transforms & Arithmetic
from lapq.algorithms.transforms import (
    qft,
    inverse_qft,
    approximate_qft,
    semi_classical_qft,
    quantum_adder,
    quantum_subtractor,
    quantum_multiplier,
    modular_addition,
    modular_exponentiation,
    quantum_comparator,
    quantum_sorting,
)

# States & Communication
from lapq.algorithms.states import (
    bell_state,
    ghz_state,
    w_state,
    dicke_state,
    cluster_state,
    graph_state,
    arbitrary_state_preparation,
    amplitude_encoding,
    angle_encoding,
    quantum_teleportation,
    entanglement_swapping,
    teleportation_chain,
    superdense_coding,
)

# Quantum Walks
from lapq.algorithms.walks import (
    discrete_quantum_walk_line,
    discrete_quantum_walk_cycle,
    discrete_quantum_walk_graph,
    continuous_quantum_walk,
    ctqw_search,
    coined_walk_1d,
    coined_walk_2d,
)

# Benchmarking & Characterization
from lapq.algorithms.benchmarking import (
    randomized_benchmarking,
    interleaved_randomized_benchmarking,
    cross_entropy_benchmarking,
    linear_xeb,
    quantum_volume_circuit,
    quantum_state_tomography,
    quantum_process_tomography,
    heavy_output_generation,
)

# Dynamics, Lattice Models & Metrology
from lapq.algorithms.dynamics import (
    schrodinger_evolution,
    uhrig_dynamical_decoupling,
    carr_purcell_meiboom_gill,
    xy_decoupling,
    heisenberg_model,
    transverse_ising_model,
    xy_model,
    ramsey_interferometry,
    spin_echo_sensing,
    quantum_magnetometry,
    heisenberg_limited_sensing,
)

# Miscellaneous Advanced Algorithms
from lapq.algorithms.misc import (
    haar_random_state,
    random_circuit,
    quantum_monte_carlo,
    option_pricing_quantum,
    quantum_minimum_finding,
    quantum_ram,
    harrow_hassidim_lloyd,
    variational_quantum_linear_solver,
    quantum_singular_value_estimation,
    quantum_leader_election,
    quantum_voting,
    quantum_prisoners_dilemma,
    quantum_auction,
)

__all__ = [
    # Search & Optimization
    "grover", "grover_multi_target", "grover_adaptive",
    "amplitude_amplification", "fixed_point_amplitude_amplification",
    "qaoa_maxcut", "qaoa_max_independent_set", "qaoa_tsp",
    "qaoa_portfolio_optimization", "qaoa_vertex_cover", "qaoa_3sat",
    "simulated_quantum_annealing", "adiabatic_grover",
    # Chemistry
    "vqe_molecular", "vqe_hydrogen_chain", "vqe_lattice_model",
    "vqe_custom_hamiltonian", "phase_estimation", "iterative_phase_estimation",
    "phase_estimation_kitaev", "trotter_suzuki_simulation",
    "quantum_walk_simulation", "ising_model_evolution",
    "hubbard_model_simulation", "ucc_ansatz",
    # ML
    "qnn_classifier", "qnn_regression", "variational_quantum_classifier",
    "quantum_autoencoder", "quantum_kernel_estimation", "qsvm",
    "qgan_generator", "qgan_discriminator", "quantum_vae", "qbm_train",
    "quantum_reservoir_computing", "quantum_extreme_learning_machine",
    # Crypto
    "bb84_protocol", "e91_protocol", "quantum_coin_flipping",
    "quantum_secret_sharing", "shors_period_finding", "shors_factorization",
    "shors_discrete_log", "hidden_subgroup_problem", "subset_sum_quantum",
    # Oracle
    "deutsch_jozsa", "deutsch_jozsa_multi_oracle", "bernstein_vazirani",
    "bernstein_vazirani_recursive", "simons_algorithm", "simons_generalized",
    "walsh_hadamard_transform", "bent_function_test", "linear_independence_test",
    # Transforms
    "qft", "inverse_qft", "approximate_qft", "semi_classical_qft",
    "quantum_adder", "quantum_subtractor", "quantum_multiplier",
    "modular_addition", "modular_exponentiation", "quantum_comparator",
    "quantum_sorting",
    # States
    "bell_state", "ghz_state", "w_state", "dicke_state", "cluster_state",
    "graph_state", "arbitrary_state_preparation", "amplitude_encoding",
    "angle_encoding", "quantum_teleportation", "entanglement_swapping",
    "teleportation_chain", "superdense_coding",
    # Walks
    "discrete_quantum_walk_line", "discrete_quantum_walk_cycle",
    "discrete_quantum_walk_graph", "continuous_quantum_walk",
    "ctqw_search", "coined_walk_1d", "coined_walk_2d",
    # Benchmarking
    "randomized_benchmarking", "interleaved_randomized_benchmarking",
    "cross_entropy_benchmarking", "linear_xeb", "quantum_volume_circuit",
    "quantum_state_tomography", "quantum_process_tomography",
    "heavy_output_generation",
    # Dynamics
    "schrodinger_evolution", "uhrig_dynamical_decoupling",
    "carr_purcell_meiboom_gill", "xy_decoupling", "heisenberg_model",
    "transverse_ising_model", "xy_model", "ramsey_interferometry",
    "spin_echo_sensing", "quantum_magnetometry", "heisenberg_limited_sensing",
    # Misc
    "haar_random_state", "random_circuit", "quantum_monte_carlo",
    "option_pricing_quantum", "quantum_minimum_finding", "quantum_ram",
    "harrow_hassidim_lloyd", "variational_quantum_linear_solver",
    "quantum_singular_value_estimation", "quantum_leader_election",
    "quantum_voting", "quantum_prisoners_dilemma", "quantum_auction",
]
