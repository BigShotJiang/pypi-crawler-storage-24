"""lapq/algorithms/benchmarking.py — Benchmarking & Characterization circuits."""

from __future__ import annotations
import math
from typing import TYPE_CHECKING, List, Optional

if TYPE_CHECKING:
    from lapq.client import QPU1
    from lapq.circuit import Circuit


def randomized_benchmarking(qpu: "QPU1", n_qubits: int = 1, depth: int = 10) -> "Circuit":
    """
    Randomized Benchmarking: random Clifford sequence then inverse.
    Measures decay of fidelity vs. depth to estimate gate error rate.

    Example::

        result = randomized_benchmarking(qpu, n_qubits=1, depth=10).run()
    """
    c = qpu.circuit(n_qubits)
    # Interleave random single-qubit Cliffords (H, S, X rotations)
    cliffords = [
        lambda c, q: c.h(q),
        lambda c, q: c.s(q),
        lambda c, q: c.x(q),
        lambda c, q: (c.h(q), c.s(q)),
    ]
    for d in range(depth):
        gate_idx = d % len(cliffords)
        for q in range(n_qubits):
            cliffords[gate_idx](c, q)
    # Invert: apply the same sequence reversed
    for d in range(depth - 1, -1, -1):
        gate_idx = d % len(cliffords)
        for q in range(n_qubits):
            cliffords[gate_idx](c, q)
    return c.measure()


def interleaved_randomized_benchmarking(qpu: "QPU1", n_qubits: int = 1,
                                         depth: int = 10) -> "Circuit":
    """
    Interleaved RB: interleave a reference gate (H) between Clifford layers.

    Example::

        result = interleaved_randomized_benchmarking(qpu, depth=10).run()
    """
    c = qpu.circuit(n_qubits)
    for d in range(depth):
        for q in range(n_qubits):
            if d % 2 == 0: c.h(q)
            else: c.s(q)
            c.h(q)  # Reference gate
    return c.measure()


def cross_entropy_benchmarking(qpu: "QPU1", n: int = 4, depth: int = 10) -> "Circuit":
    """
    Cross-Entropy Benchmarking (XEB): random single-qubit + 2-qubit layers.
    Used to certify quantum advantage.

    Example::

        result = cross_entropy_benchmarking(qpu, n=4, depth=10).run()
    """
    c = qpu.circuit(n)
    for d in range(depth):
        for q in range(n):
            angle = math.pi * ((d * n + q + 1) % 7 + 1) / 7
            c.ry(q, angle)
        for q in range(0, n - 1, 2):
            c.cz(q, q + 1)
        for q in range(1, n - 1, 2):
            c.cz(q, q + 1)
    return c.measure()


def linear_xeb(qpu: "QPU1", n: int = 4, depth: int = 10) -> "Circuit":
    """Linear XEB — simplified version with linear connectivity only."""
    return cross_entropy_benchmarking(qpu, n, depth)


def quantum_volume_circuit(qpu: "QPU1", n: int = 3) -> "Circuit":
    """
    Quantum Volume circuit of width and depth *n*.
    Random permutations + SU(4) blocks on random qubit pairs.

    Example::

        result = quantum_volume_circuit(qpu, n=3).run()
    """
    c = qpu.circuit(n)
    for layer in range(n):
        for q in range(0, n - 1, 2):
            c.h(q)
            c.cx(q, q + 1)
            c.rz(q, math.pi * (layer + 1) / n)
            c.ry(q + 1, math.pi * (layer + 2) / n)
            c.cx(q, q + 1)
        if layer < n - 1:
            for q in range(1, n - 1, 2):
                c.cz(q, q + 1)
    return c.measure()


def quantum_state_tomography(qpu: "QPU1", n_qubits: int = 1) -> "Circuit":
    """
    Quantum State Tomography basis circuit (Pauli X basis preparation).
    Run three variants with H / Sdg+H / I to extract ρ.

    Example::

        result = quantum_state_tomography(qpu, 1).run()
    """
    c = qpu.circuit(n_qubits)
    for q in range(n_qubits): c.h(q)   # Prepare |+⟩
    for q in range(n_qubits): c.h(q)   # Rotate to Z basis for tomography
    return c.measure()


def quantum_process_tomography(qpu: "QPU1", n_qubits: int = 1) -> "Circuit":
    """
    Quantum Process Tomography skeleton: prepare input states and measure.

    Example::

        result = quantum_process_tomography(qpu, 1).run()
    """
    c = qpu.circuit(n_qubits)
    # Standard input: |+⟩ on each qubit
    for q in range(n_qubits): c.h(q)
    # Process (identity here — user replaces)
    # Measure in X basis
    for q in range(n_qubits): c.h(q)
    return c.measure()


def heavy_output_generation(qpu: "QPU1", n: int = 4, depth: int = 8) -> "Circuit":
    """
    Heavy Output Generation (HOG) test — measures heavy output probability.

    Example::

        result = heavy_output_generation(qpu, n=4, depth=8).run()
    """
    return cross_entropy_benchmarking(qpu, n, depth)
