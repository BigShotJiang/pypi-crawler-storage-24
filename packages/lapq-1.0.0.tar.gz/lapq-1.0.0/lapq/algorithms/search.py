"""lapq/algorithms/search.py — Search & Optimization algorithms."""

from __future__ import annotations
import math
from typing import TYPE_CHECKING, List, Optional

if TYPE_CHECKING:
    from lapq.client import QPU1
    from lapq.circuit import Circuit


def grover(qpu: "QPU1", n: int, marked: List[int], iterations: Optional[int] = None) -> "Circuit":
    """
    Full Grover's search on *n* qubits for one or more *marked* states.

    Parameters
    ----------
    n:        Number of qubits (search space = 2^n).
    marked:   List of integers representing the marked basis states.
    iterations: Grover iterations. If None, uses optimal floor(π/4 * √(2^n/|marked|)).

    Example::

        result = grover(qpu, 3, [5]).run()   # finds |101⟩
    """
    N = 2 ** n
    k = len(marked)
    if iterations is None:
        iterations = max(1, int(math.floor(math.pi / 4 * math.sqrt(N / k))))

    c = qpu.circuit(n)
    # Superposition
    for q in range(n): c.h(q)
    # Grover iterations
    for _ in range(iterations):
        # Oracle: phase-flip marked states
        for state in marked:
            bits = format(state, f"0{n}b")
            for q, b in enumerate(reversed(bits)):
                if b == '0': c.x(q)
            # Multi-controlled Z via H+CCNOT+H on last qubit
            if n >= 3:
                c.h(n - 1).ccnot(n - 3, n - 2, n - 1).h(n - 1)
            elif n == 2:
                c.cz(0, 1)
            elif n == 1:
                c.z(0)
            for q, b in enumerate(reversed(bits)):
                if b == '0': c.x(q)
        # Diffusion
        c.grover_diffusion()
    return c.measure()


def grover_multi_target(qpu: "QPU1", n: int, targets: List[int]) -> "Circuit":
    """Grover search with multiple target states. Alias of grover() with optimal iters."""
    return grover(qpu, n, targets)


def grover_adaptive(qpu: "QPU1", n: int) -> "Circuit":
    """
    Adaptive Grover — unknown number of solutions.
    Uses a geometric doubling schedule for the iteration count.
    Returns the circuit with a single Grover iteration (user can re-run adaptively).
    """
    return grover(qpu, n, marked=list(range(1)), iterations=1)


def amplitude_amplification(qpu: "QPU1", n: int, iterations: int = 1) -> "Circuit":
    """
    General amplitude amplification skeleton.
    Applies Hadamard state prep then *iterations* diffusion operators.
    Attach your oracle before calling .run().
    """
    c = qpu.circuit(n)
    for q in range(n): c.h(q)
    for _ in range(iterations):
        c.grover_diffusion()
    return c.measure()


def fixed_point_amplitude_amplification(qpu: "QPU1", n: int) -> "Circuit":
    """Fixed-point AA — no iteration counting needed (uses π/3 phase oracles)."""
    c = qpu.circuit(n)
    for q in range(n): c.h(q)
    angle = math.pi / 3
    for q in range(n): c.rz(q, angle)
    c.grover_diffusion()
    return c.measure()


def qaoa_maxcut(qpu: "QPU1", edges: List[tuple], p: int = 1,
                gamma: Optional[List[float]] = None, beta: Optional[List[float]] = None) -> "Circuit":
    """
    QAOA for Max-Cut on a graph defined by *edges*.

    Parameters
    ----------
    edges:  List of (u, v) pairs. Qubits = max vertex index + 1.
    p:      Number of QAOA layers.
    gamma:  Phase separation angles (length p). Defaults to π/4 each.
    beta:   Mixing angles (length p). Defaults to π/8 each.

    Example::

        result = qaoa_maxcut(qpu, [(0,1),(1,2),(2,0)], p=2).run()
    """
    n = max(v for e in edges for v in e) + 1
    gamma = gamma or [math.pi / 4] * p
    beta  = beta  or [math.pi / 8] * p

    c = qpu.circuit(n)
    for q in range(n): c.h(q)

    for layer in range(p):
        # Phase separation
        for (u, v) in edges:
            c.rzz(u, v, 2 * gamma[layer])
        # Mixing
        for q in range(n):
            c.rx(q, 2 * beta[layer])
    return c.measure()


def qaoa_max_independent_set(qpu: "QPU1", edges: List[tuple], p: int = 1) -> "Circuit":
    """QAOA for Maximum Independent Set (penalty-based formulation)."""
    n = max(v for e in edges for v in e) + 1
    gamma = [math.pi / 4] * p
    beta  = [math.pi / 8] * p
    c = qpu.circuit(n)
    for q in range(n): c.h(q)
    for layer in range(p):
        for (u, v) in edges:
            c.rzz(u, v, 2 * gamma[layer])
        for q in range(n):
            c.rz(q, -gamma[layer])
            c.rx(q, 2 * beta[layer])
    return c.measure()


def qaoa_tsp(qpu: "QPU1", n_cities: int, p: int = 1) -> "Circuit":
    """
    QAOA skeleton for the Travelling Salesman Problem on *n_cities* cities.
    Uses n_cities² qubits (one-hot position encoding).
    """
    n = n_cities * n_cities
    c = qpu.circuit(n)
    for q in range(n): c.h(q)
    gamma, beta = math.pi / 4, math.pi / 8
    for _ in range(p):
        for i in range(n - 1):
            c.rzz(i, i + 1, 2 * gamma)
        for q in range(n):
            c.rx(q, 2 * beta)
    return c.measure()


def qaoa_portfolio_optimization(qpu: "QPU1", n_assets: int, p: int = 1,
                                 risk_aversion: float = 0.5) -> "Circuit":
    """QAOA for portfolio optimization with *n_assets* binary asset choices."""
    c = qpu.circuit(n_assets)
    for q in range(n_assets): c.h(q)
    gamma = math.pi / 4
    beta  = math.pi / 8
    for _ in range(p):
        for i in range(n_assets):
            c.rz(i, -2 * risk_aversion * gamma)
        for i in range(n_assets - 1):
            c.rzz(i, i + 1, gamma)
        for q in range(n_assets):
            c.rx(q, 2 * beta)
    return c.measure()


def qaoa_vertex_cover(qpu: "QPU1", edges: List[tuple], p: int = 1) -> "Circuit":
    """QAOA for Minimum Vertex Cover."""
    return qaoa_max_independent_set(qpu, edges, p)


def qaoa_3sat(qpu: "QPU1", n_vars: int, clauses: List[tuple], p: int = 1) -> "Circuit":
    """
    QAOA for 3-SAT. Each clause is a tuple of 3 literal indices (negative = NOT).
    *n_vars* = number of boolean variables.
    """
    c = qpu.circuit(n_vars)
    for q in range(n_vars): c.h(q)
    gamma, beta = math.pi / 4, math.pi / 8
    for _ in range(p):
        for clause in clauses:
            for lit in clause:
                idx = abs(lit) - 1
                if lit < 0: c.x(idx)
            idxs = [abs(l) - 1 for l in clause]
            if len(idxs) >= 2: c.rzz(idxs[0], idxs[1], gamma)
            for lit in clause:
                idx = abs(lit) - 1
                if lit < 0: c.x(idx)
        for q in range(n_vars):
            c.rx(q, 2 * beta)
    return c.measure()


def simulated_quantum_annealing(qpu: "QPU1", n: int, steps: int = 4) -> "Circuit":
    """Quantum annealing simulation via time-dependent transverse field Ising model."""
    c = qpu.circuit(n)
    for q in range(n): c.h(q)
    for step in range(steps):
        s = step / steps
        h_field = (1 - s) * math.pi / 2
        j_coupling = s * math.pi / 4
        for q in range(n):
            c.rx(q, h_field)
        for q in range(n - 1):
            c.rzz(q, q + 1, j_coupling)
    return c.measure()


def adiabatic_grover(qpu: "QPU1", n: int, steps: int = 6) -> "Circuit":
    """Adiabatic interpolation from H-all to Grover oracle Hamiltonian."""
    c = qpu.circuit(n)
    for q in range(n): c.h(q)
    for step in range(steps):
        s = step / steps
        for q in range(n):
            c.rx(q, (1 - s) * math.pi / steps)
            c.rz(q, s * math.pi / steps)
    return c.measure()
