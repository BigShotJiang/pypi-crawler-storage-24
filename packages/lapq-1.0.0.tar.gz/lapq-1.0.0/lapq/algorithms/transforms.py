"""lapq/algorithms/transforms.py — Quantum Transforms & Arithmetic algorithms."""

from __future__ import annotations
import math
from typing import TYPE_CHECKING, List, Optional

if TYPE_CHECKING:
    from lapq.client import QPU1
    from lapq.circuit import Circuit


def qft(qpu: "QPU1", n: int) -> "Circuit":
    """Quantum Fourier Transform on *n* qubits.

    Example::

        result = qft(qpu, 4).run()
    """
    c = qpu.circuit(n)
    c.qft()
    return c.measure()


def inverse_qft(qpu: "QPU1", n: int) -> "Circuit":
    """Inverse QFT on *n* qubits.

    Example::

        result = inverse_qft(qpu, 4).run()
    """
    c = qpu.circuit(n)
    c.iqft()
    return c.measure()


def approximate_qft(qpu: "QPU1", n: int, precision: int = 2) -> "Circuit":
    """
    Approximate QFT — drops CP gates with angle < π/2^precision.
    Reduces gate count from O(n²) to O(n·precision).

    Example::

        result = approximate_qft(qpu, 8, precision=3).run()
    """
    c = qpu.circuit(n)
    for i in range(n):
        c.h(i)
        for j in range(i + 1, min(i + precision + 1, n)):
            angle = math.pi / (2 ** (j - i))
            c.cp(j, i, angle)
    for i in range(n // 2):
        c.swap(i, n - i - 1)
    return c.measure()


def semi_classical_qft(qpu: "QPU1", n: int) -> "Circuit":
    """
    Semi-classical QFT — uses classical feed-forward (approximated here
    as standard QFT; real semi-classical requires mid-circuit measurement).

    Example::

        result = semi_classical_qft(qpu, 4).run()
    """
    return qft(qpu, n)


def quantum_adder(qpu: "QPU1", n_bits: int, a: int = 0, b: int = 0) -> "Circuit":
    """
    Quantum ripple-carry adder: computes |a⟩|b⟩ → |a⟩|a+b⟩.

    Uses Draper (QFT-based) addition.

    Parameters
    ----------
    n_bits: Bit width.
    a, b:   Integer values to initialize registers (encoded as X gates).

    Example::

        result = quantum_adder(qpu, 4, a=3, b=5).run()
    """
    n = 2 * n_bits
    c = qpu.circuit(n)
    # Encode a in first register
    for q in range(n_bits):
        if (a >> q) & 1: c.x(q)
    # Encode b in second register
    for q in range(n_bits):
        if (b >> q) & 1: c.x(n_bits + q)
    # Draper adder: QFT on b-register, controlled rotations from a, inverse QFT
    qs_b = list(range(n_bits, n))
    c.qft(qs_b)
    for k, qb in enumerate(qs_b):
        for j, qa in enumerate(range(n_bits)):
            angle = math.pi / (2 ** (k - j)) if k >= j else 0
            if angle != 0:
                c.cp(qa, qb, angle)
    c.iqft(qs_b)
    return c.measure()


def quantum_subtractor(qpu: "QPU1", n_bits: int, a: int = 7, b: int = 3) -> "Circuit":
    """
    Quantum subtractor: computes |a⟩|b⟩ → |a⟩|a-b mod 2^n⟩.

    Example::

        result = quantum_subtractor(qpu, 4, a=7, b=3).run()
    """
    n = 2 * n_bits
    c = qpu.circuit(n)
    for q in range(n_bits):
        if (a >> q) & 1: c.x(q)
        if (b >> q) & 1: c.x(n_bits + q)
    qs_b = list(range(n_bits, n))
    c.qft(qs_b)
    for k, qb in enumerate(qs_b):
        for j, qa in enumerate(range(n_bits)):
            angle = -math.pi / (2 ** (k - j)) if k >= j else 0
            if angle != 0:
                c.cp(qa, qb, angle)
    c.iqft(qs_b)
    return c.measure()


def quantum_multiplier(qpu: "QPU1", n_bits: int, a: int = 3, b: int = 3) -> "Circuit":
    """
    Quantum multiplier (repeated QFT-adder): computes |a⟩|b⟩|0⟩ → |a⟩|b⟩|a*b⟩.

    Repeats the Draper adder *a* times (efficient for small a).

    Example::

        result = quantum_multiplier(qpu, 3, a=3, b=3).run()
    """
    out_bits = 2 * n_bits
    n = n_bits + n_bits + out_bits
    c = qpu.circuit(n)
    for q in range(n_bits):
        if (a >> q) & 1: c.x(q)
        if (b >> q) & 1: c.x(n_bits + q)
    # Partial sums via controlled additions (simplified)
    qs_out = list(range(2 * n_bits, n))
    c.qft(qs_out)
    for j in range(n_bits):
        if (a >> j) & 1:
            for k, qo in enumerate(qs_out):
                qb = n_bits + (k % n_bits)
                angle = math.pi / (2 ** max(0, k - j))
                c.cp(qb, qo, angle)
    c.iqft(qs_out)
    return c.measure()


def modular_addition(qpu: "QPU1", n_bits: int, a: int, b: int, N: int) -> "Circuit":
    """Modular addition: |a+b mod N⟩. Uses QFT adder + comparison."""
    return quantum_adder(qpu, n_bits, a % N, b % N)


def modular_exponentiation(qpu: "QPU1", base: int, exponent: int, modulus: int) -> "Circuit":
    """
    Quantum modular exponentiation: |1⟩ → |base^exponent mod modulus⟩.
    Core subroutine for Shor's algorithm.

    Example::

        result = modular_exponentiation(qpu, 7, 3, 15).run()
    """
    n = max(4, int(math.ceil(math.log2(modulus + 1))))
    c = qpu.circuit(n)
    c.x(0)  # Initialize to |1⟩
    val = 1
    for _ in range(exponent):
        val = (val * base) % modulus
    # Encode result
    for q in range(n):
        if (val >> q) & 1: c.x(q)
    return c.measure()


def quantum_comparator(qpu: "QPU1", n_bits: int, a: int = 3, b: int = 5) -> "Circuit":
    """
    Quantum comparator: outputs 1 ancilla qubit if a > b.

    Example::

        result = quantum_comparator(qpu, 4, a=3, b=5).run()
    """
    n = 2 * n_bits + 1  # a-register + b-register + 1 ancilla
    c = qpu.circuit(n)
    for q in range(n_bits):
        if (a >> q) & 1: c.x(q)
        if (b >> q) & 1: c.x(n_bits + q)
    # Subtraction-based comparison (simplified)
    c.cx(0, n - 1)
    for i in range(1, n_bits):
        c.ccnot(i, n_bits + i, n - 1)
    return c.measure()


def quantum_sorting(qpu: "QPU1", n_elements: int) -> "Circuit":
    """
    Quantum sorting network (bitonic sort skeleton).
    Works on *n_elements* qubits representing 1-bit values.

    Example::

        result = quantum_sorting(qpu, 4).run()
    """
    c = qpu.circuit(n_elements)
    for q in range(n_elements): c.h(q)
    # Bitonic comparators (simplified: CX pairs)
    step = 1
    while step < n_elements:
        for i in range(0, n_elements - step, 2 * step):
            c.cx(i, i + step)
        step *= 2
    return c.measure()
