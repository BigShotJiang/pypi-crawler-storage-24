"""lapq/algorithms/crypto.py — Cryptography & Security algorithms."""

from __future__ import annotations
import math
from typing import TYPE_CHECKING, List, Optional

if TYPE_CHECKING:
    from lapq.client import QPU1
    from lapq.circuit import Circuit


def bb84_protocol(qpu: "QPU1", n_bits: int = 8) -> "Circuit":
    """
    BB84 Quantum Key Distribution — Alice's preparation circuit.

    Prepares *n_bits* qubits in random BB84 states {|0⟩,|1⟩,|+⟩,|-⟩}.
    Alternates between Z-basis and X-basis encoding for demonstration.

    Example::

        result = bb84_protocol(qpu, 8).run()
    """
    c = qpu.circuit(n_bits)
    for q in range(n_bits):
        if q % 4 == 1:   c.x(q)            # |1⟩
        elif q % 4 == 2: c.h(q)            # |+⟩
        elif q % 4 == 3: c.x(q); c.h(q)   # |-⟩
        # q % 4 == 0 stays |0⟩
    return c.measure()


def e91_protocol(qpu: "QPU1", n_pairs: int = 4) -> "Circuit":
    """
    Ekert (E91) entanglement-based QKD.
    Prepares *n_pairs* Bell pairs and measures in chosen bases.

    Example::

        result = e91_protocol(qpu, 4).run()
    """
    n = 2 * n_pairs
    c = qpu.circuit(n)
    for i in range(n_pairs):
        c.h(2*i)
        c.cx(2*i, 2*i+1)
    # Measure in alternating {Z, X} bases
    for i in range(n_pairs):
        if i % 2 == 1:
            c.h(2*i)
            c.h(2*i+1)
    return c.measure()


def quantum_coin_flipping(qpu: "QPU1") -> "Circuit":
    """
    Quantum coin flipping protocol — 2 qubits, provably fair.

    Example::

        result = quantum_coin_flipping(qpu).run()
    """
    c = qpu.circuit(2)
    c.h(0)
    c.cx(0, 1)
    c.h(0)
    return c.measure()


def quantum_secret_sharing(qpu: "QPU1", n_parties: int = 3) -> "Circuit":
    """
    Quantum secret sharing using GHZ-based protocol.

    Example::

        result = quantum_secret_sharing(qpu, 3).run()
    """
    c = qpu.circuit(n_parties)
    c.ghz()
    # Each party applies a random phase
    for q in range(1, n_parties):
        c.rz(q, math.pi / n_parties)
    return c.measure()


def shors_period_finding(qpu: "QPU1", a: int, N: int) -> "Circuit":
    """
    Shor's period finding: finds the order r of a mod N.

    Uses QPE on the modular multiplication unitary U|y⟩ = |ay mod N⟩.

    Parameters
    ----------
    a: The base (2 ≤ a < N, gcd(a,N)=1).
    N: The integer to factor.

    Example::

        result = shors_period_finding(qpu, 7, 15).run()
    """
    n_count = max(4, 2 * int(math.ceil(math.log2(N + 1))))
    n_target = int(math.ceil(math.log2(N)))
    n = n_count + n_target
    c = qpu.circuit(n)
    # Superpose counting register
    for q in range(n_count): c.h(q)
    # Initialize target to |1⟩
    c.x(n - 1)
    # Controlled modular exponentiation (approximated via CRz phases)
    for k in range(n_count):
        angle = 2 * math.pi * (a ** (2**k) % N) / N
        c.crz(k, n - 1, angle)
    # Inverse QFT on counting register
    c.iqft(list(range(n_count)))
    return c.measure()


def shors_factorization(qpu: "QPU1", N: int) -> "Circuit":
    """
    Full Shor's algorithm for factoring integer *N*.

    The quantum part is Shor's period finding. Classical pre/post-processing
    (GCD, checking) should be done by the caller.

    Example::

        result = shors_factorization(qpu, 15).run()
    """
    a = 2  # Default base; caller should try multiple a values classically
    return shors_period_finding(qpu, a, N)


def shors_discrete_log(qpu: "QPU1", base: int, target: int, modulus: int) -> "Circuit":
    """
    Shor's algorithm for discrete logarithm: find x s.t. base^x = target mod modulus.

    Example::

        result = shors_discrete_log(qpu, 2, 8, 15).run()
    """
    n = max(4, int(math.ceil(math.log2(modulus + 1))))
    c = qpu.circuit(2 * n + 1)
    for q in range(2 * n): c.h(q)
    c.x(2 * n)
    for k in range(n):
        angle = 2 * math.pi * (base ** (2**k) % modulus) / modulus
        c.crz(k, 2*n, angle)
    c.iqft(list(range(n)))
    return c.measure()


def hidden_subgroup_problem(qpu: "QPU1", n: int) -> "Circuit":
    """
    Hidden Subgroup Problem (Abelian) — general skeleton.

    Applies H^⊗n, oracle (identity), then QFT measurement.

    Example::

        result = hidden_subgroup_problem(qpu, 4).run()
    """
    c = qpu.circuit(n)
    for q in range(n): c.h(q)
    # Oracle: identity / user-provided (wired externally)
    c.qft()
    return c.measure()


def subset_sum_quantum(qpu: "QPU1", n_items: int, target: int = 0) -> "Circuit":
    """
    Quantum subset-sum solver skeleton (Grover-based oracle approach).

    Example::

        result = subset_sum_quantum(qpu, 5, target=10).run()
    """
    c = qpu.circuit(n_items)
    for q in range(n_items): c.h(q)
    # Oracle approximated by phase kick on target encoding
    c.rz(0, 2 * math.pi * target / (2**n_items))
    c.grover_diffusion()
    return c.measure()
