"""lapq/algorithms/oracle.py — Oracle & Boolean Function Analysis algorithms."""

from __future__ import annotations
import math
from typing import TYPE_CHECKING, List, Optional

if TYPE_CHECKING:
    from lapq.client import QPU1
    from lapq.circuit import Circuit


def deutsch_jozsa(qpu: "QPU1", n: int, constant: bool = True) -> "Circuit":
    """
    Deutsch-Jozsa algorithm: determines if oracle is constant or balanced.

    Parameters
    ----------
    n:        Number of input qubits (1 ancilla added automatically).
    constant: If True, implements constant oracle (|0⟩); else balanced (parity).

    Example::

        result = deutsch_jozsa(qpu, 4, constant=False).run()
        # All-zeros → constant; any-one → balanced
    """
    c = qpu.circuit(n + 1)
    c.x(n)  # ancilla to |1⟩
    for q in range(n + 1): c.h(q)
    # Oracle
    if not constant:
        for q in range(n):
            c.cx(q, n)  # balanced: parity function
    for q in range(n): c.h(q)
    return c.measure()


def deutsch_jozsa_multi_oracle(qpu: "QPU1", n: int, n_oracles: int = 2) -> "Circuit":
    """
    Test multiple function oracles in superposition using *n_oracles* extra qubits.

    Example::

        result = deutsch_jozsa_multi_oracle(qpu, 3, n_oracles=2).run()
    """
    total = n + n_oracles + 1
    c = qpu.circuit(total)
    c.x(total - 1)
    for q in range(total): c.h(q)
    for k in range(n_oracles):
        c.cx(n + k, total - 1)
    for q in range(n): c.h(q)
    return c.measure()


def bernstein_vazirani(qpu: "QPU1", n: int, secret: Optional[int] = None) -> "Circuit":
    """
    Bernstein-Vazirani algorithm: recovers secret bit-string *s* in one query.

    Parameters
    ----------
    n:      Number of input qubits.
    secret: Integer representing secret bits (default = 2^n - 1 = all ones).

    Example::

        result = bernstein_vazirani(qpu, 4, secret=0b1011).run()
        # Output bits = secret bit-string
    """
    if secret is None:
        secret = (1 << n) - 1
    c = qpu.circuit(n + 1)
    c.x(n)
    for q in range(n + 1): c.h(q)
    # Oracle: CX for each set bit of secret
    bits = format(secret, f"0{n}b")
    for q, b in enumerate(reversed(bits)):
        if b == '1':
            c.cx(q, n)
    for q in range(n): c.h(q)
    return c.measure()


def bernstein_vazirani_recursive(qpu: "QPU1", n: int, depth: int = 2) -> "Circuit":
    """
    Recursive Bernstein-Vazirani for learning bit-strings of length n*depth.

    Example::

        result = bernstein_vazirani_recursive(qpu, 3, depth=2).run()
    """
    c = qpu.circuit(n + 1)
    c.x(n)
    for _ in range(depth):
        for q in range(n + 1): c.h(q)
        for q in range(n): c.cx(q, n)
        for q in range(n): c.h(q)
    return c.measure()


def simons_algorithm(qpu: "QPU1", n: int) -> "Circuit":
    """
    Simon's algorithm: finds period s of a 2-to-1 function f.

    Returns one bit-string orthogonal to *s* per run. Classical post-processing
    (Gaussian elimination over GF(2)) reconstructs *s*.

    Example::

        result = simons_algorithm(qpu, 3).run()
    """
    c = qpu.circuit(2 * n)
    for q in range(n): c.h(q)
    # Oracle: copy input to output register
    for q in range(n):
        c.cx(q, n + q)
    for q in range(n): c.h(q)
    return c.measure()


def simons_generalized(qpu: "QPU1", n: int) -> "Circuit":
    """
    Generalized Simon's algorithm with a controlled oracle phase-flip.

    Example::

        result = simons_generalized(qpu, 3).run()
    """
    c = qpu.circuit(2 * n)
    for q in range(n): c.h(q)
    for q in range(n):
        c.cx(q, n + q)
        c.cz(q, n + q)
    for q in range(n): c.h(q)
    return c.measure()


def walsh_hadamard_transform(qpu: "QPU1", n: int) -> "Circuit":
    """
    Quantum Walsh-Hadamard Transform: H^⊗n on all qubits.

    Example::

        result = walsh_hadamard_transform(qpu, 4).run()
    """
    c = qpu.circuit(n)
    for q in range(n): c.h(q)
    return c.measure()


def bent_function_test(qpu: "QPU1", n: int) -> "Circuit":
    """
    Bent function test: checks if a Boolean function achieves max nonlinearity.
    Uses the Hadamard spectrum (Walsh-Hadamard + oracle evaluation).

    Example::

        result = bent_function_test(qpu, 4).run()
    """
    c = qpu.circuit(n + 1)
    c.x(n)
    for q in range(n + 1): c.h(q)
    # Generic oracle (user should replace with specific function)
    for q in range(n): c.cx(q, n)
    for q in range(n): c.h(q)
    return c.measure()


def linear_independence_test(qpu: "QPU1", n: int, n_funcs: int = 2) -> "Circuit":
    """
    Test linear independence of *n_funcs* Boolean functions over n variables
    using simultaneous Hadamard evaluation.

    Example::

        result = linear_independence_test(qpu, 3, n_funcs=2).run()
    """
    total = n + n_funcs
    c = qpu.circuit(total)
    for q in range(n): c.h(q)
    for f in range(n_funcs):
        c.cx(f % n, n + f)
    for q in range(n): c.h(q)
    return c.measure()
