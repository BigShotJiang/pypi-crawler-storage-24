"""lapq/algorithms/ml.py — Quantum Machine Learning algorithms."""

from __future__ import annotations
import math
from typing import TYPE_CHECKING, List, Optional

if TYPE_CHECKING:
    from lapq.client import QPU1
    from lapq.circuit import Circuit


def _zz_feature_map(c: "Circuit", data: List[float], reps: int = 2) -> None:
    """ZZFeatureMap data encoding onto the circuit."""
    n = len(data)
    for _ in range(reps):
        for q, x in enumerate(data[:n]):
            c.h(q).rz(q, x)
        for i in range(n - 1):
            c.cx(i, i + 1)
            c.rz(i + 1, (math.pi - data[i]) * (math.pi - data[i + 1]))
            c.cx(i, i + 1)


def qnn_classifier(qpu: "QPU1", n_features: int = 2, n_classes: int = 2,
                    layers: int = 3) -> "Circuit":
    """
    Quantum Neural Network classifier.

    Parameters
    ----------
    n_features: Input dimension (number of qubits).
    n_classes:  Output classes (must be ≤ n_features).
    layers:     Variational depth.

    Example::

        result = qnn_classifier(qpu, n_features=4, layers=3).run()
    """
    n = n_features
    c = qpu.circuit(n)
    for q in range(n): c.h(q)
    for _ in range(layers):
        for q in range(n):
            c.ry(q, math.pi / 4)
            c.rz(q, math.pi / 8)
        for i in range(n - 1):
            c.cx(i, i + 1)
    return c.measure()


def qnn_regression(qpu: "QPU1", n_features: int = 2, depth: int = 4) -> "Circuit":
    """
    Quantum Neural Network for regression tasks.

    Example::

        result = qnn_regression(qpu, n_features=3, depth=4).run()
    """
    c = qpu.circuit(n_features)
    for q in range(n_features): c.ry(q, math.pi / 6)
    for _ in range(depth):
        for i in range(n_features - 1):
            c.rzz(i, i + 1, math.pi / 4)
        for q in range(n_features):
            c.ry(q, math.pi / 8)
    return c.measure()


def variational_quantum_classifier(qpu: "QPU1", n_qubits: int,
                                    feature_reps: int = 2,
                                    ansatz_layers: int = 2) -> "Circuit":
    """
    Full VQC: ZZFeatureMap + hardware-efficient ansatz.

    Example::

        result = variational_quantum_classifier(qpu, 4).run()
    """
    c = qpu.circuit(n_qubits)
    # Feature map (uniform initialization)
    data = [math.pi / 4] * n_qubits
    _zz_feature_map(c, data, reps=feature_reps)
    # Ansatz
    for _ in range(ansatz_layers):
        for q in range(n_qubits):
            c.ry(q, math.pi / 4)
        for i in range(n_qubits - 1):
            c.cx(i, i + 1)
    return c.measure()


def quantum_autoencoder(qpu: "QPU1", n_qubits: int, latent_dim: int) -> "Circuit":
    """
    Quantum Autoencoder: encode n_qubits → latent_dim qubits.

    Example::

        result = quantum_autoencoder(qpu, 6, 2).run()
    """
    c = qpu.circuit(n_qubits)
    for q in range(n_qubits): c.h(q)
    # Encoder: entangle all into latent qubits
    for i in range(latent_dim):
        for j in range(latent_dim, n_qubits):
            c.cx(i, j)
    for q in range(latent_dim): c.ry(q, math.pi / 4)
    # Decoder
    for i in range(latent_dim):
        for j in range(latent_dim, n_qubits):
            c.cx(i, j)
    return c.measure()


def quantum_kernel_estimation(qpu: "QPU1", n_features: int,
                               x1: Optional[List[float]] = None,
                               x2: Optional[List[float]] = None) -> "Circuit":
    """
    Quantum kernel K(x1, x2) = |⟨ψ(x2)|ψ(x1)⟩|².
    Uses a SWAP test to estimate the overlap.

    Example::

        result = quantum_kernel_estimation(qpu, 2).run()
    """
    x1 = x1 or [math.pi / 4] * n_features
    x2 = x2 or [math.pi / 5] * n_features
    n = 1 + 2 * n_features  # 1 ancilla + two data registers
    c = qpu.circuit(n)
    # Encode x1
    for i, v in enumerate(x1):
        c.ry(1 + i, v)
    # Encode x2
    for i, v in enumerate(x2):
        c.ry(1 + n_features + i, v)
    # SWAP test
    c.h(0)
    for i in range(n_features):
        c.cswap(0, 1 + i, 1 + n_features + i)
    c.h(0)
    return c.measure()


def qsvm(qpu: "QPU1", n_features: int, kernel_reps: int = 2) -> "Circuit":
    """
    Quantum Support Vector Machine kernel circuit (ZZFeatureMap).

    Example::

        result = qsvm(qpu, 4).run()
    """
    c = qpu.circuit(n_features)
    data = [math.pi / 4] * n_features
    _zz_feature_map(c, data, reps=kernel_reps)
    return c.measure()


def qgan_generator(qpu: "QPU1", n_qubits: int, latent_dim: int = 2,
                    layers: int = 2) -> "Circuit":
    """
    Quantum GAN generator network.

    Example::

        result = qgan_generator(qpu, 4, latent_dim=2).run()
    """
    c = qpu.circuit(n_qubits)
    # Latent space preparation
    for q in range(latent_dim):
        c.ry(q, math.pi / 3)
    for _ in range(layers):
        for i in range(n_qubits - 1):
            c.cx(i, i + 1)
        for q in range(n_qubits):
            c.ry(q, math.pi / 4)
    return c.measure()


def qgan_discriminator(qpu: "QPU1", n_qubits: int, layers: int = 2) -> "Circuit":
    """
    Quantum GAN discriminator network.

    Example::

        result = qgan_discriminator(qpu, 4).run()
    """
    c = qpu.circuit(n_qubits)
    for q in range(n_qubits): c.h(q)
    for _ in range(layers):
        for i in range(n_qubits - 1):
            c.cx(i, i + 1)
        for q in range(n_qubits):
            c.ry(q, math.pi / 5)
    return c.measure()


def quantum_vae(qpu: "QPU1", n_qubits: int, latent_dim: int = 2) -> "Circuit":
    """
    Quantum Variational Autoencoder.

    Example::

        result = quantum_vae(qpu, 6, latent_dim=2).run()
    """
    return quantum_autoencoder(qpu, n_qubits, latent_dim)


def qbm_train(qpu: "QPU1", visible: int, hidden: int) -> "Circuit":
    """
    Quantum Boltzmann Machine — training ansatz (visible + hidden qubits).

    Example::

        result = qbm_train(qpu, 4, 2).run()
    """
    n = visible + hidden
    c = qpu.circuit(n)
    for q in range(n): c.ry(q, math.pi / 4)
    for v in range(visible):
        for h in range(visible, n):
            c.rzz(v, h, math.pi / 8)
    return c.measure()


def quantum_reservoir_computing(qpu: "QPU1", n_qubits: int,
                                 input_steps: int = 4) -> "Circuit":
    """
    Quantum Reservoir Computing circuit — random dynamics as feature extractor.

    Example::

        result = quantum_reservoir_computing(qpu, 6, input_steps=4).run()
    """
    c = qpu.circuit(n_qubits)
    for q in range(n_qubits): c.h(q)
    for step in range(input_steps):
        angle = math.pi * (step + 1) / (2 * input_steps)
        for i in range(n_qubits - 1):
            c.rzz(i, i + 1, angle)
        for q in range(n_qubits):
            c.ry(q, angle / 2)
    return c.measure()


def quantum_extreme_learning_machine(qpu: "QPU1", n_hidden: int) -> "Circuit":
    """Quantum Extreme Learning Machine — random fixed reservoir."""
    c = qpu.circuit(n_hidden)
    for q in range(n_hidden): c.h(q)
    for i in range(n_hidden - 1):
        c.cz(i, i + 1)
    for q in range(n_hidden):
        c.ry(q, math.pi * (q + 1) / n_hidden)
    return c.measure()
