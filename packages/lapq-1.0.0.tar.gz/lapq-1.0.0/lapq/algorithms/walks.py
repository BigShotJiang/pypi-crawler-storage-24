"""lapq/algorithms/walks.py — Quantum Walks algorithms."""

from __future__ import annotations
import math
from typing import TYPE_CHECKING, List, Optional

if TYPE_CHECKING:
    from lapq.client import QPU1
    from lapq.circuit import Circuit


def discrete_quantum_walk_line(qpu: "QPU1", n_steps: int = 4) -> "Circuit":
    """
    Discrete-time quantum walk on an infinite line.

    Uses 1 coin qubit + ceil(log2(2*n_steps+1)) position qubits.

    Example::

        result = discrete_quantum_walk_line(qpu, n_steps=4).run()
    """
    n_pos = max(2, int(math.ceil(math.log2(2 * n_steps + 2))))
    n = 1 + n_pos
    c = qpu.circuit(n)
    c.h(0)  # coin
    for _ in range(n_steps):
        c.h(0)
        c.cx(0, 1)
        if n_pos > 1: c.ccnot(0, 1, 2)
    return c.measure()


def discrete_quantum_walk_cycle(qpu: "QPU1", n_nodes: int = 4, steps: int = 4) -> "Circuit":
    """
    Discrete quantum walk on a cycle graph with *n_nodes* nodes.

    Uses ceil(log2(n_nodes)) position qubits + 1 coin qubit.

    Example::

        result = discrete_quantum_walk_cycle(qpu, n_nodes=4, steps=4).run()
    """
    n_pos = max(2, int(math.ceil(math.log2(n_nodes + 1))))
    n = 1 + n_pos
    c = qpu.circuit(n)
    c.h(0)
    for step in range(steps):
        c.h(0)
        for p in range(1, n):
            c.cx(0, p)
    return c.measure()


def discrete_quantum_walk_graph(qpu: "QPU1", adjacency: List[List[int]],
                                 steps: int = 3) -> "Circuit":
    """
    Discrete quantum walk on a graph given by its adjacency matrix.

    Example::

        adj = [[0,1,1],[1,0,1],[1,1,0]]   # K3
        result = discrete_quantum_walk_graph(qpu, adj, steps=3).run()
    """
    n_nodes = len(adjacency)
    n_pos = max(2, int(math.ceil(math.log2(n_nodes + 1))))
    n = 1 + n_pos
    c = qpu.circuit(n)
    c.h(0)
    for _ in range(steps):
        c.h(0)
        for i in range(n_nodes):
            for j in range(i + 1, n_nodes):
                if adjacency[i][j]:
                    c.cx(0, 1 + (j % n_pos))
    return c.measure()


def continuous_quantum_walk(qpu: "QPU1", n: int, time: float = 1.0,
                             steps: int = 4) -> "Circuit":
    """
    Continuous-time quantum walk via Trotterized Hamiltonian evolution.

    The walk Hamiltonian is H = adjacency matrix (uniform connections).

    Example::

        result = continuous_quantum_walk(qpu, 4, time=1.0).run()
    """
    c = qpu.circuit(n)
    for q in range(n): c.h(q)
    dt = time / steps
    for _ in range(steps):
        for i in range(n - 1):
            c.rxx(i, i + 1, dt)
            c.ryy(i, i + 1, dt)
    return c.measure()


def ctqw_search(qpu: "QPU1", n: int, marked_node: int = 0,
                time: float = math.pi / 2) -> "Circuit":
    """
    Continuous-time quantum walk search on a complete graph.

    Parameters
    ----------
    n:           Number of nodes (qubits).
    marked_node: Index of the target node.
    time:        Evolution time (optimal ≈ π/2 √N).

    Example::

        result = ctqw_search(qpu, 4, marked_node=2).run()
    """
    c = qpu.circuit(n)
    for q in range(n): c.h(q)
    # Oracle: mark node
    c.rz(marked_node, -2 * time)
    # Walk evolution
    dt = time / 4
    for _ in range(4):
        for i in range(n - 1):
            c.rzz(i, i + 1, dt)
        for q in range(n):
            c.rx(q, dt)
    return c.measure()


def coined_walk_1d(qpu: "QPU1", steps: int = 4, coin: str = "H") -> "Circuit":
    """
    1D coined quantum walk with Hadamard or Grover coin.

    Parameters
    ----------
    steps: Walk steps.
    coin:  "H" (Hadamard) or "G" (Grover).

    Example::

        result = coined_walk_1d(qpu, steps=5, coin="H").run()
    """
    n_pos = max(2, int(math.ceil(math.log2(2 * steps + 2))))
    n = 1 + n_pos
    c = qpu.circuit(n)
    c.h(0)
    for _ in range(steps):
        if coin == "G":
            c.h(0); c.z(0); c.h(0)
        else:
            c.h(0)
        c.cx(0, 1)
    return c.measure()


def coined_walk_2d(qpu: "QPU1", steps: int = 3) -> "Circuit":
    """
    2D coined quantum walk with 2-coin qubits + 2 position registers.

    Example::

        result = coined_walk_2d(qpu, steps=3).run()
    """
    n = 4 + 2  # 2 coin + 2 pos-x + 2 pos-y (simplified)
    c = qpu.circuit(n)
    c.h(0); c.h(1)
    for _ in range(steps):
        c.h(0); c.h(1)
        c.cx(0, 2); c.cx(1, 4)
    return c.measure()
