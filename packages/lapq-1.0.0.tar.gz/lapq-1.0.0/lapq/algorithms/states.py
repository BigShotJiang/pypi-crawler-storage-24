"""lapq/algorithms/states.py — Entanglement & State Preparation algorithms."""

from __future__ import annotations
import math
from typing import TYPE_CHECKING, List, Optional

if TYPE_CHECKING:
    from lapq.client import QPU1
    from lapq.circuit import Circuit


def bell_state(qpu: "QPU1", pair: int = 0) -> "Circuit":
    """
    Prepare one of the four Bell states.

    Parameters
    ----------
    pair: 0→|Φ+⟩, 1→|Φ-⟩, 2→|Ψ+⟩, 3→|Ψ-⟩.

    Example::

        result = bell_state(qpu, pair=0).run()   # → "00" or "11"
    """
    c = qpu.circuit(2)
    c.h(0).cx(0, 1)
    if pair == 1: c.z(0)
    elif pair == 2: c.x(0)
    elif pair == 3: c.x(0); c.z(0)
    return c.measure()


def ghz_state(qpu: "QPU1", n: int = 3) -> "Circuit":
    """
    n-qubit GHZ state: (|0⟩^n + |1⟩^n)/√2.

    Example::

        result = ghz_state(qpu, 5).run()   # → "00000" or "11111"
    """
    c = qpu.circuit(n)
    c.ghz()
    return c.measure()


def w_state(qpu: "QPU1", n: int = 3) -> "Circuit":
    """
    n-qubit W state: (|100⟩ + |010⟩ + |001⟩)/√3 generalised.

    Example::

        result = w_state(qpu, 4).run()
    """
    c = qpu.circuit(n)
    c.w_state()
    return c.measure()


def dicke_state(qpu: "QPU1", n: int, k: int) -> "Circuit":
    """
    Dicke state |D^n_k⟩ — equal superposition of all n-bit strings with exactly k ones.

    Parameters
    ----------
    n: Total qubits.
    k: Number of excitations.

    Example::

        result = dicke_state(qpu, 4, 2).run()
    """
    c = qpu.circuit(n)
    # Initialize k ones
    for q in range(k): c.x(q)
    # Spread using Ry rotations
    for i in range(k - 1, n - 1):
        remaining = n - i
        angle = 2 * math.acos(math.sqrt((n - k - (i - k + 1)) / remaining)) if remaining > 0 else 0
        c.cry(i, i + 1, angle)
        c.cx(i + 1, i)
    return c.measure()


def cluster_state(qpu: "QPU1", n: int = 4) -> "Circuit":
    """
    Linear cluster state: H all qubits, then CZ between neighbours.

    Example::

        result = cluster_state(qpu, 5).run()
    """
    c = qpu.circuit(n)
    c.cluster_state()
    return c.measure()


def graph_state(qpu: "QPU1", adjacency: List[List[int]]) -> "Circuit":
    """
    Graph state for a given adjacency matrix.

    Parameters
    ----------
    adjacency: Square binary matrix; adjacency[i][j]=1 means edge i-j.

    Example::

        result = graph_state(qpu, [[0,1,1],[1,0,0],[1,0,0]]).run()
    """
    n = len(adjacency)
    c = qpu.circuit(n)
    for q in range(n): c.h(q)
    for i in range(n):
        for j in range(i + 1, n):
            if adjacency[i][j]:
                c.cz(i, j)
    return c.measure()


def arbitrary_state_preparation(qpu: "QPU1", statevector: List[complex]) -> "Circuit":
    """
    Prepare an arbitrary statevector using angle encoding (Ry + phase gates).

    Parameters
    ----------
    statevector: List of 2^n complex amplitudes (need not be normalized — auto-normalized).

    Example::

        result = arbitrary_state_preparation(qpu, [0.5, 0.5, 0.5, 0.5]).run()
    """
    import math
    n = int(math.log2(len(statevector)))
    norm = math.sqrt(sum(abs(a)**2 for a in statevector))
    sv = [a / norm for a in statevector]
    c = qpu.circuit(n)
    for q in range(n):
        chunk = 2 ** (q + 1)
        half = chunk // 2
        total_mag = sum(abs(sv[i])**2 for i in range(min(half, len(sv))))
        angle = 2 * math.acos(math.sqrt(total_mag)) if 0 < total_mag < 1 else 0
        c.ry(q, angle)
    return c.measure()


def amplitude_encoding(qpu: "QPU1", data: List[float]) -> "Circuit":
    """
    Encode classical data into quantum amplitudes via Ry rotations.

    Parameters
    ----------
    data: List of floats (auto-normalized). Uses ceil(log2(len(data))) qubits.

    Example::

        result = amplitude_encoding(qpu, [1.0, 2.0, 3.0, 4.0]).run()
    """
    n = max(1, int(math.ceil(math.log2(max(1, len(data))))))
    norm = math.sqrt(sum(x**2 for x in data) or 1)
    c = qpu.circuit(n)
    for q, x in zip(range(n), data):
        c.ry(q, 2 * math.asin(min(1.0, abs(x) / norm)))
    return c.measure()


def angle_encoding(qpu: "QPU1", angles: List[float]) -> "Circuit":
    """
    Angle encoding: each data point φ_i → Ry(φ_i) on qubit i.

    Example::

        import math
        result = angle_encoding(qpu, [math.pi/4, math.pi/3, math.pi/6]).run()
    """
    n = len(angles)
    c = qpu.circuit(n)
    for q, a in enumerate(angles):
        c.ry(q, a)
    return c.measure()


def quantum_teleportation(qpu: "QPU1") -> "Circuit":
    """
    Full 3-qubit quantum teleportation circuit.

    Qubit 0: state to teleport (prepared in |+⟩).
    Qubit 1: Alice's half of Bell pair.
    Qubit 2: Bob's half (output).

    Example::

        result = quantum_teleportation(qpu).run()
    """
    c = qpu.circuit(3)
    c.h(0)             # state to teleport: |+⟩
    c.teleport(0, 1, 2)
    return c.measure()


def entanglement_swapping(qpu: "QPU1") -> "Circuit":
    """
    4-qubit entanglement swapping: two independent Bell pairs → swapped entanglement.

    Example::

        result = entanglement_swapping(qpu).run()
    """
    c = qpu.circuit(4)
    c.h(0); c.cx(0, 1)   # Bell pair 1
    c.h(2); c.cx(2, 3)   # Bell pair 2
    # Bell measurement on qubits 1,2
    c.cx(1, 2); c.h(1)
    # Corrections
    c.cx(2, 3); c.cz(1, 3)
    return c.measure()


def teleportation_chain(qpu: "QPU1", n_nodes: int = 3) -> "Circuit":
    """
    Quantum teleportation chain through *n_nodes* repeater nodes.

    Example::

        result = teleportation_chain(qpu, n_nodes=3).run()
    """
    n = 2 * n_nodes + 1
    c = qpu.circuit(n)
    c.h(0)
    for i in range(n_nodes):
        src = 2 * i
        anc = 2 * i + 1
        dst = 2 * i + 2
        c.h(anc); c.cx(anc, dst)
        c.cx(src, anc); c.h(src)
        c.cx(anc, dst); c.cz(src, dst)
    return c.measure()


def superdense_coding(qpu: "QPU1", message: str = "10") -> "Circuit":
    """
    Superdense coding: send 2 classical bits with 1 qubit.

    Parameters
    ----------
    message: 2-bit string ("00", "01", "10", or "11").

    Example::

        result = superdense_coding(qpu, "11").run()
    """
    c = qpu.circuit(2)
    c.h(0); c.cx(0, 1)
    c.superdense_encode(0, 1, message)
    return c.measure()
