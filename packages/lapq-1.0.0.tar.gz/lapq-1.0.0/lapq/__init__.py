"""
lapq — LAP Technologies Python SDK for QPU-1
=============================================

**Made by SK Mahammad Saad Amin | LAP Technologies**

Get your API key at: https://qpu-1.lovable.app/api-access

Three levels of access
-----------------------
1. **High-level algorithms** — ready-to-run quantum algorithms (150+)::

    from lapq.algorithms import bell_state, grover, vqe_molecular, shors_factorization
    result = bell_state(qpu).run()

2. **Mid-level circuit builder** — fluent API with full extended gate set::

    qpu.circuit(3).h(0).crx(0, 1, 0.5).cswap(0, 1, 2).ccz(0, 1, 2).run()

3. **Low-level raw access** — submit raw Qreg / Qiskit / OpenQASM directly::

    qpu.run_qreg("q = Qreg(2)\\nq.H(0)\\nq.CNOT(0,1)\\nprint(q.measure())")

Quick start
-----------
::

    from lapq import QPU1
    qpu = QPU1("your_api_key")          # get key: https://qpu-1.lovable.app/api-access

    # Bell state
    result = qpu.circuit(2).bell_pair(0, 1).run()
    print(result.bits)   # "00" or "11"

    # GHZ state via algorithm factory
    from lapq.algorithms import ghz_state
    result = ghz_state(qpu, n=5).run()
    print(result.bits)   # "00000" or "11111"

    # Grover's search
    from lapq.algorithms import grover
    result = grover(qpu, n=4, marked=[7]).run()
    print(result.bits)   # likely "0111" (= 7)
"""

__version__ = "1.0.0"
__author__ = "SK Mahammad Saad Amin"
__organization__ = "LAP Technologies"
__license__ = "MIT"
__api_key_url__ = "https://qpu-1.lovable.app/api-access"

from lapq.client import QPU1
from lapq.circuit import Circuit
from lapq.models import (
    BatchResult,
    JobResult,
    QuotaInfo,
    TranspileResult,
    ValidateResult,
)

__all__ = [
    "QPU1",
    "Circuit",
    "JobResult",
    "BatchResult",
    "TranspileResult",
    "ValidateResult",
    "QuotaInfo",
]
