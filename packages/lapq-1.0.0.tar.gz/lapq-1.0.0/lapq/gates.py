"""
lapq.gates — Comprehensive gate decomposition engine for QPU-1.
"""

import math
from typing import List, Tuple, Any

class GateDecomposer:
    """
    Decomposes high-level gates into QPU-1 primitives:
    H, X, Y, Z, S, T, Rx, Ry, Rz, CNOT, CCNOT, SWAP.
    """

    @staticmethod
    def decompose(gate_name: str, qubits: List[int], *params: Any) -> List[Tuple[str, List[int], List[Any]]]:
        """
        Returns a list of (op_name, qubit_indices, parameters) tuples.
        """
        name = gate_name.lower()
        
        # ─────────────────────────────────────────────────────────────────
        # Single-qubit extensions
        # ─────────────────────────────────────────────────────────────────
        
        if name == "sdg":
            return [("S", [qubits[0]], []), ("S", [qubits[0]], []), ("S", [qubits[0]], [])]
        
        if name == "tdg":
            return [("Rz", [qubits[0]], [-math.pi / 4])]
        
        if name in ("sx", "v"):
            return [("Rx", [qubits[0]], [math.pi / 2])]
        
        if name == "sxdg":
            return [("Rx", [qubits[0]], [-math.pi / 2])]
        
        if name == "p":
            return [("Rz", [qubits[0]], [params[0]])]
            
        if name == "u1":
            return [("Rz", [qubits[0]], [params[0]])]
            
        if name == "u2":
            phi, lam = params
            return [
                ("Rz", [qubits[0]], [lam]),
                ("Rx", [qubits[0]], [math.pi / 2]),
                ("Rz", [qubits[0]], [phi])
            ]
            
        if name == "u3":
            theta, phi, lam = params
            return [
                ("Rz", [qubits[0]], [lam]),
                ("Ry", [qubits[0]], [theta]),
                ("Rz", [qubits[0]], [phi])
            ]

        # ─────────────────────────────────────────────────────────────────
        # Two-qubit extensions
        # ─────────────────────────────────────────────────────────────────
        
        if name == "cz":
            c, t = qubits
            return [
                ("H", [t], []),
                ("CNOT", [c, t], []),
                ("H", [t], [])
            ]
            
        if name == "cy":
            c, t = qubits
            return [
                ("Sdg", [t], []), # Recursive call helper needed or flat? Let's use string but handle in circuit.
                ("CNOT", [c, t], []),
                ("S", [t], [])
            ]
            
        if name == "ch":
            c, t = qubits
            return [
                ("Ry", [t], [-math.pi / 4]),
                ("CNOT", [c, t], []),
                ("Ry", [t], [math.pi / 4]),
                ("H", [t], [])
            ]
            
        if name == "crx":
            c, t = qubits
            theta = params[0]
            return [
                ("Ry", [t], [theta / 2]),
                ("CNOT", [c, t], []),
                ("Ry", [t], [-theta / 2]),
                ("CNOT", [c, t], [])
            ]
            
        if name == "cry":
            c, t = qubits
            theta = params[0]
            return [
                ("Ry", [t], [theta / 2]),
                ("CNOT", [c, t], []),
                ("Ry", [t], [-theta / 2]),
                ("CNOT", [c, t], [])
            ]
            
        if name == "crz":
            c, t = qubits
            theta = params[0]
            return [
                ("Rz", [t], [theta / 2]),
                ("CNOT", [c, t], []),
                ("Rz", [t], [-theta / 2]),
                ("CNOT", [c, t], [])
            ]
            
        if name == "cp":
            c, t = qubits
            theta = params[0]
            return [
                ("Rz", [c], [theta / 2]),
                ("Rz", [t], [theta / 2]),
                ("CNOT", [c, t], []),
                ("Rz", [t], [-theta / 2]),
                ("CNOT", [c, t], [])
            ]

        if name == "rxx":
            q1, q2 = qubits
            theta = params[0]
            return [
                ("H", [q1], []), ("H", [q2], []),
                ("CNOT", [q1, q2], []),
                ("Rz", [q2], [theta]),
                ("CNOT", [q1, q2], []),
                ("H", [q1], []), ("H", [q2], [])
            ]
            
        if name == "ryy":
            q1, q2 = qubits
            theta = params[0]
            return [
                ("Rx", [q1], [math.pi/2]), ("Rx", [q2], [math.pi/2]),
                ("CNOT", [q1, q2], []),
                ("Rz", [q2], [theta]),
                ("CNOT", [q1, q2], []),
                ("Rx", [q1], [-math.pi/2]), ("Rx", [q2], [-math.pi/2])
            ]

        if name == "rzz":
            q1, q2 = qubits
            theta = params[0]
            return [
                ("CNOT", [q1, q2], []),
                ("Rz", [q2], [theta]),
                ("CNOT", [q1, q2], [])
            ]

        # ─────────────────────────────────────────────────────────────────
        # Three-qubit extensions
        # ─────────────────────────────────────────────────────────────────
        
        if name in ("cswap", "fredkin"):
            c, t1, t2 = qubits
            return [
                ("CNOT", [t2, t1], []),
                ("CCNOT", [c, t1, t2], []),
                ("CNOT", [t2, t1], [])
            ]
            
        if name == "ccz":
            c1, c2, t = qubits
            return [
                ("H", [t], []),
                ("CCNOT", [c1, c2, t], []),
                ("H", [t], [])
            ]

        # ─────────────────────────────────────────────────────────────────
        # Specialized
        # ─────────────────────────────────────────────────────────────────
        
        if name == "ecr":
            q1, q2 = qubits
            return [
                ("Rx", [q1], [math.pi/4]),
                ("CNOT", [q1, q2], []),
                ("X", [q1], [])
            ]

        # Fallback or unknown
        return [(gate_name, qubits, list(params))]
