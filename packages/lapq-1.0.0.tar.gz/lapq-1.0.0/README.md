# lapq — LAP Technologies SDK for QPU-1

[![PyPI version](https://img.shields.io/pypi/v/lapq.svg)](https://pypi.org/project/lapq/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

**lapq** is a powerful Python SDK for the QPU-1 quantum processor, designed for both beginners and experts. It features a library of over 150+ algorithms and an automatic gate decomposition engine.

**Made by SK Mahammad Saad Amin | LAP Technologies**

---

## 🔑 API Access
To use this library, you need a QPU-1 API key.
**Get your key here:** [https://qpu-1.lovable.app/api-access](https://qpu-1.lovable.app/api-access)

---

## 🚀 Quick Start

### Installation
```bash
pip install lapq
```

### Basic Usage
```python
from lapq import QPU1

# Initialize client
qpu = QPU1("your_api_key_here")

# Run a Bell State circuit
result = qpu.circuit(2).h(0).cnot(0, 1).run()
print(f"Result: {result.bits}") # e.g. "00" or "11"
```

### High-Level Algorithms
```python
from lapq.algorithms import grover, shors_factorization

# Run Grover's search for state |5> on 3 qubits
result = grover(qpu, n=3, marked=[5]).run()
print(result.bits) # "101"
```

## 🛠 Features
- **150+ Algorithms**: Including Grover, Shor's, VQE, QAOA, QFT, and more.
- **Auto-Decomposition**: Use high-level gates (CZ, CSWAP, CCZ...) and we handle the math.
- **Multi-Format Support**: Run raw Qreg, Qiskit, or OpenQASM 2.0.

## 📄 License
Distributed under the MIT License. See `LICENSE` for more information.
