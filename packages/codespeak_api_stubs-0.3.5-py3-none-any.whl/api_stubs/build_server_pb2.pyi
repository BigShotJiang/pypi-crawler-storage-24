import os_environment_pb2 as _os_environment_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar as _ClassVar, Iterable as _Iterable, Mapping as _Mapping, Optional as _Optional, Union as _Union
DESCRIPTOR: _descriptor.FileDescriptor

class BuildStartErrorType(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    BUILD_START_ERROR_TYPE_UNSPECIFIED: _ClassVar[BuildStartErrorType]
    BUILD_START_ERROR_TYPE_USER_TOKEN_MISSING: _ClassVar[BuildStartErrorType]
    BUILD_START_ERROR_TYPE_USER_NOT_ALLOWLISTED: _ClassVar[BuildStartErrorType]
    BUILD_START_ERROR_TYPE_USER_BLOCKED: _ClassVar[BuildStartErrorType]
    BUILD_START_ERROR_TYPE_UNSUPPORTED_PROTOCOL_VERSION: _ClassVar[BuildStartErrorType]
    BUILD_START_ERROR_TYPE_SERVER_OVERLOADED: _ClassVar[BuildStartErrorType]

class BuildResultType(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    BUILD_RESULT_UNSPECIFIED: _ClassVar[BuildResultType]
    BUILD_RESULT_SUCCEEDED: _ClassVar[BuildResultType]
    BUILD_RESULT_FAILED: _ClassVar[BuildResultType]
    BUILD_RESULT_CANCELLED: _ClassVar[BuildResultType]
    BUILD_RESULT_SKIPPED: _ClassVar[BuildResultType]

class ProgressItemStatus(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    PROGRESS_ITEM_STATUS_UNSPECIFIED: _ClassVar[ProgressItemStatus]
    PROGRESS_ITEM_STATUS_PENDING: _ClassVar[ProgressItemStatus]
    PROGRESS_ITEM_STATUS_IN_PROGRESS: _ClassVar[ProgressItemStatus]
    PROGRESS_ITEM_STATUS_SKIPPED: _ClassVar[ProgressItemStatus]
    PROGRESS_ITEM_STATUS_DONE: _ClassVar[ProgressItemStatus]
    PROGRESS_ITEM_STATUS_FAILED: _ClassVar[ProgressItemStatus]
BUILD_START_ERROR_TYPE_UNSPECIFIED: BuildStartErrorType
BUILD_START_ERROR_TYPE_USER_TOKEN_MISSING: BuildStartErrorType
BUILD_START_ERROR_TYPE_USER_NOT_ALLOWLISTED: BuildStartErrorType
BUILD_START_ERROR_TYPE_USER_BLOCKED: BuildStartErrorType
BUILD_START_ERROR_TYPE_UNSUPPORTED_PROTOCOL_VERSION: BuildStartErrorType
BUILD_START_ERROR_TYPE_SERVER_OVERLOADED: BuildStartErrorType
BUILD_RESULT_UNSPECIFIED: BuildResultType
BUILD_RESULT_SUCCEEDED: BuildResultType
BUILD_RESULT_FAILED: BuildResultType
BUILD_RESULT_CANCELLED: BuildResultType
BUILD_RESULT_SKIPPED: BuildResultType
PROGRESS_ITEM_STATUS_UNSPECIFIED: ProgressItemStatus
PROGRESS_ITEM_STATUS_PENDING: ProgressItemStatus
PROGRESS_ITEM_STATUS_IN_PROGRESS: ProgressItemStatus
PROGRESS_ITEM_STATUS_SKIPPED: ProgressItemStatus
PROGRESS_ITEM_STATUS_DONE: ProgressItemStatus
PROGRESS_ITEM_STATUS_FAILED: ProgressItemStatus

class ClientMessage(_message.Message):
    __slots__ = ('start_build', 'cancel_build', 'os_env_response')
    START_BUILD_FIELD_NUMBER: _ClassVar[int]
    CANCEL_BUILD_FIELD_NUMBER: _ClassVar[int]
    OS_ENV_RESPONSE_FIELD_NUMBER: _ClassVar[int]
    start_build: StartBuildRequest
    cancel_build: CancelBuildRequest
    os_env_response: _os_environment_pb2.OperationResponse

    def __init__(self, start_build: _Optional[_Union[StartBuildRequest, _Mapping]]=..., cancel_build: _Optional[_Union[CancelBuildRequest, _Mapping]]=..., os_env_response: _Optional[_Union[_os_environment_pb2.OperationResponse, _Mapping]]=...) -> None:
        ...

class StartBuildRequest(_message.Message):
    __slots__ = ('project_root', 'settings_json', 'args_raw', 'client_feature_flags', 'env_vars', 'user_token', 'client_protocol_version', 'client_cwd')

    class ClientFeatureFlagsEntry(_message.Message):
        __slots__ = ('key', 'value')
        KEY_FIELD_NUMBER: _ClassVar[int]
        VALUE_FIELD_NUMBER: _ClassVar[int]
        key: str
        value: str

        def __init__(self, key: _Optional[str]=..., value: _Optional[str]=...) -> None:
            ...

    class EnvVarsEntry(_message.Message):
        __slots__ = ('key', 'value')
        KEY_FIELD_NUMBER: _ClassVar[int]
        VALUE_FIELD_NUMBER: _ClassVar[int]
        key: str
        value: str

        def __init__(self, key: _Optional[str]=..., value: _Optional[str]=...) -> None:
            ...
    PROJECT_ROOT_FIELD_NUMBER: _ClassVar[int]
    SETTINGS_JSON_FIELD_NUMBER: _ClassVar[int]
    ARGS_RAW_FIELD_NUMBER: _ClassVar[int]
    CLIENT_FEATURE_FLAGS_FIELD_NUMBER: _ClassVar[int]
    ENV_VARS_FIELD_NUMBER: _ClassVar[int]
    USER_TOKEN_FIELD_NUMBER: _ClassVar[int]
    CLIENT_PROTOCOL_VERSION_FIELD_NUMBER: _ClassVar[int]
    CLIENT_CWD_FIELD_NUMBER: _ClassVar[int]
    project_root: str
    settings_json: str
    args_raw: _containers.RepeatedScalarFieldContainer[str]
    client_feature_flags: _containers.ScalarMap[str, str]
    env_vars: _containers.ScalarMap[str, str]
    user_token: str
    client_protocol_version: int
    client_cwd: str

    def __init__(self, project_root: _Optional[str]=..., settings_json: _Optional[str]=..., args_raw: _Optional[_Iterable[str]]=..., client_feature_flags: _Optional[_Mapping[str, str]]=..., env_vars: _Optional[_Mapping[str, str]]=..., user_token: _Optional[str]=..., client_protocol_version: _Optional[int]=..., client_cwd: _Optional[str]=...) -> None:
        ...

class CancelBuildRequest(_message.Message):
    __slots__ = ()

    def __init__(self) -> None:
        ...

class ServerMessage(_message.Message):
    __slots__ = ('build_started', 'progress_update', 'build_finished', 'os_env_request', 'build_insight_event')
    BUILD_STARTED_FIELD_NUMBER: _ClassVar[int]
    PROGRESS_UPDATE_FIELD_NUMBER: _ClassVar[int]
    BUILD_FINISHED_FIELD_NUMBER: _ClassVar[int]
    OS_ENV_REQUEST_FIELD_NUMBER: _ClassVar[int]
    BUILD_INSIGHT_EVENT_FIELD_NUMBER: _ClassVar[int]
    build_started: BuildStartedResponse
    progress_update: BuildProgressUpdate
    build_finished: BuildFinished
    os_env_request: _os_environment_pb2.OperationRequest
    build_insight_event: BuildInsightEvent

    def __init__(self, build_started: _Optional[_Union[BuildStartedResponse, _Mapping]]=..., progress_update: _Optional[_Union[BuildProgressUpdate, _Mapping]]=..., build_finished: _Optional[_Union[BuildFinished, _Mapping]]=..., os_env_request: _Optional[_Union[_os_environment_pb2.OperationRequest, _Mapping]]=..., build_insight_event: _Optional[_Union[BuildInsightEvent, _Mapping]]=...) -> None:
        ...

class BuildStartFailure(_message.Message):
    __slots__ = ('type', 'message')
    TYPE_FIELD_NUMBER: _ClassVar[int]
    MESSAGE_FIELD_NUMBER: _ClassVar[int]
    type: BuildStartErrorType
    message: str

    def __init__(self, type: _Optional[_Union[BuildStartErrorType, str]]=..., message: _Optional[str]=...) -> None:
        ...

class BuildStartSuccess(_message.Message):
    __slots__ = ('build_id', 'server_protocol_version')
    BUILD_ID_FIELD_NUMBER: _ClassVar[int]
    SERVER_PROTOCOL_VERSION_FIELD_NUMBER: _ClassVar[int]
    build_id: str
    server_protocol_version: int

    def __init__(self, build_id: _Optional[str]=..., server_protocol_version: _Optional[int]=...) -> None:
        ...

class BuildStartedResponse(_message.Message):
    __slots__ = ('success', 'failure')
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    FAILURE_FIELD_NUMBER: _ClassVar[int]
    success: BuildStartSuccess
    failure: BuildStartFailure

    def __init__(self, success: _Optional[_Union[BuildStartSuccess, _Mapping]]=..., failure: _Optional[_Union[BuildStartFailure, _Mapping]]=...) -> None:
        ...

class BuildProgressUpdate(_message.Message):
    __slots__ = ('message', 'color')
    MESSAGE_FIELD_NUMBER: _ClassVar[int]
    COLOR_FIELD_NUMBER: _ClassVar[int]
    message: str
    color: str

    def __init__(self, message: _Optional[str]=..., color: _Optional[str]=...) -> None:
        ...

class CodespeakUserError(_message.Message):
    __slots__ = ('exception_class', 'user_visible_message')
    EXCEPTION_CLASS_FIELD_NUMBER: _ClassVar[int]
    USER_VISIBLE_MESSAGE_FIELD_NUMBER: _ClassVar[int]
    exception_class: str
    user_visible_message: str

    def __init__(self, exception_class: _Optional[str]=..., user_visible_message: _Optional[str]=...) -> None:
        ...

class CodespeakInternalError(_message.Message):
    __slots__ = ('exception_class', 'internal_message', 'stack_trace')
    EXCEPTION_CLASS_FIELD_NUMBER: _ClassVar[int]
    INTERNAL_MESSAGE_FIELD_NUMBER: _ClassVar[int]
    STACK_TRACE_FIELD_NUMBER: _ClassVar[int]
    exception_class: str
    internal_message: str
    stack_trace: str

    def __init__(self, exception_class: _Optional[str]=..., internal_message: _Optional[str]=..., stack_trace: _Optional[str]=...) -> None:
        ...

class BuildError(_message.Message):
    __slots__ = ('user_error', 'internal_error')
    USER_ERROR_FIELD_NUMBER: _ClassVar[int]
    INTERNAL_ERROR_FIELD_NUMBER: _ClassVar[int]
    user_error: CodespeakUserError
    internal_error: CodespeakInternalError

    def __init__(self, user_error: _Optional[_Union[CodespeakUserError, _Mapping]]=..., internal_error: _Optional[_Union[CodespeakInternalError, _Mapping]]=...) -> None:
        ...

class BuildFinished(_message.Message):
    __slots__ = ('command', 'result_type', 'build_error', 'build_stats')
    COMMAND_FIELD_NUMBER: _ClassVar[int]
    RESULT_TYPE_FIELD_NUMBER: _ClassVar[int]
    BUILD_ERROR_FIELD_NUMBER: _ClassVar[int]
    BUILD_STATS_FIELD_NUMBER: _ClassVar[int]
    command: str
    result_type: BuildResultType
    build_error: BuildError
    build_stats: BuildStatistics

    def __init__(self, command: _Optional[str]=..., result_type: _Optional[_Union[BuildResultType, str]]=..., build_error: _Optional[_Union[BuildError, _Mapping]]=..., build_stats: _Optional[_Union[BuildStatistics, _Mapping]]=...) -> None:
        ...

class BuildStatistics(_message.Message):
    __slots__ = ('cache_enabled', 'cache_hits', 'cache_misses', 'cost_usd')
    CACHE_ENABLED_FIELD_NUMBER: _ClassVar[int]
    CACHE_HITS_FIELD_NUMBER: _ClassVar[int]
    CACHE_MISSES_FIELD_NUMBER: _ClassVar[int]
    COST_USD_FIELD_NUMBER: _ClassVar[int]
    cache_enabled: bool
    cache_hits: int
    cache_misses: int
    cost_usd: float

    def __init__(self, cache_enabled: bool=..., cache_hits: _Optional[int]=..., cache_misses: _Optional[int]=..., cost_usd: _Optional[float]=...) -> None:
        ...

class BuildInsightEvent(_message.Message):
    __slots__ = ('timestamp', 'sequence_number', 'progress_item_create', 'progress_item_update', 'text_output', 'tool_call', 'user_visible_model_output', 'span_open', 'span_close', 'tests_run', 'stop_interactive_progress', 'spec_change_summary', 'reset_progress')
    TIMESTAMP_FIELD_NUMBER: _ClassVar[int]
    SEQUENCE_NUMBER_FIELD_NUMBER: _ClassVar[int]
    PROGRESS_ITEM_CREATE_FIELD_NUMBER: _ClassVar[int]
    PROGRESS_ITEM_UPDATE_FIELD_NUMBER: _ClassVar[int]
    TEXT_OUTPUT_FIELD_NUMBER: _ClassVar[int]
    TOOL_CALL_FIELD_NUMBER: _ClassVar[int]
    USER_VISIBLE_MODEL_OUTPUT_FIELD_NUMBER: _ClassVar[int]
    SPAN_OPEN_FIELD_NUMBER: _ClassVar[int]
    SPAN_CLOSE_FIELD_NUMBER: _ClassVar[int]
    TESTS_RUN_FIELD_NUMBER: _ClassVar[int]
    STOP_INTERACTIVE_PROGRESS_FIELD_NUMBER: _ClassVar[int]
    SPEC_CHANGE_SUMMARY_FIELD_NUMBER: _ClassVar[int]
    RESET_PROGRESS_FIELD_NUMBER: _ClassVar[int]
    timestamp: float
    sequence_number: int
    progress_item_create: ProgressItemCreateEvent
    progress_item_update: ProgressItemUpdateEvent
    text_output: TextOutputEvent
    tool_call: ToolCallEvent
    user_visible_model_output: UserVisibleModelOutputEvent
    span_open: SpanOpenEvent
    span_close: SpanCloseEvent
    tests_run: TestsRunEvent
    stop_interactive_progress: StopInteractiveProgressEvent
    spec_change_summary: SpecChangeSummaryEvent
    reset_progress: ResetProgressEvent

    def __init__(self, timestamp: _Optional[float]=..., sequence_number: _Optional[int]=..., progress_item_create: _Optional[_Union[ProgressItemCreateEvent, _Mapping]]=..., progress_item_update: _Optional[_Union[ProgressItemUpdateEvent, _Mapping]]=..., text_output: _Optional[_Union[TextOutputEvent, _Mapping]]=..., tool_call: _Optional[_Union[ToolCallEvent, _Mapping]]=..., user_visible_model_output: _Optional[_Union[UserVisibleModelOutputEvent, _Mapping]]=..., span_open: _Optional[_Union[SpanOpenEvent, _Mapping]]=..., span_close: _Optional[_Union[SpanCloseEvent, _Mapping]]=..., tests_run: _Optional[_Union[TestsRunEvent, _Mapping]]=..., stop_interactive_progress: _Optional[_Union[StopInteractiveProgressEvent, _Mapping]]=..., spec_change_summary: _Optional[_Union[SpecChangeSummaryEvent, _Mapping]]=..., reset_progress: _Optional[_Union[ResetProgressEvent, _Mapping]]=...) -> None:
        ...

class ProgressItemCreateEvent(_message.Message):
    __slots__ = ('progress_item_id', 'status', 'title', 'description', 'parent_item_id', 'status_text')
    PROGRESS_ITEM_ID_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    TITLE_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    PARENT_ITEM_ID_FIELD_NUMBER: _ClassVar[int]
    STATUS_TEXT_FIELD_NUMBER: _ClassVar[int]
    progress_item_id: str
    status: ProgressItemStatus
    title: str
    description: str
    parent_item_id: str
    status_text: str

    def __init__(self, progress_item_id: _Optional[str]=..., status: _Optional[_Union[ProgressItemStatus, str]]=..., title: _Optional[str]=..., description: _Optional[str]=..., parent_item_id: _Optional[str]=..., status_text: _Optional[str]=...) -> None:
        ...

class ProgressItemUpdateEvent(_message.Message):
    __slots__ = ('progress_item_id', 'status', 'status_text')
    PROGRESS_ITEM_ID_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    STATUS_TEXT_FIELD_NUMBER: _ClassVar[int]
    progress_item_id: str
    status: ProgressItemStatus
    status_text: str

    def __init__(self, progress_item_id: _Optional[str]=..., status: _Optional[_Union[ProgressItemStatus, str]]=..., status_text: _Optional[str]=...) -> None:
        ...

class TextOutputEvent(_message.Message):
    __slots__ = ('text', 'parent_progress_item_id')
    TEXT_FIELD_NUMBER: _ClassVar[int]
    PARENT_PROGRESS_ITEM_ID_FIELD_NUMBER: _ClassVar[int]
    text: str
    parent_progress_item_id: str

    def __init__(self, text: _Optional[str]=..., parent_progress_item_id: _Optional[str]=...) -> None:
        ...

class ToolCallEvent(_message.Message):
    __slots__ = ('title', 'details', 'parent_progress_item_id')
    TITLE_FIELD_NUMBER: _ClassVar[int]
    DETAILS_FIELD_NUMBER: _ClassVar[int]
    PARENT_PROGRESS_ITEM_ID_FIELD_NUMBER: _ClassVar[int]
    title: str
    details: str
    parent_progress_item_id: str

    def __init__(self, title: _Optional[str]=..., details: _Optional[str]=..., parent_progress_item_id: _Optional[str]=...) -> None:
        ...

class UserVisibleModelOutputEvent(_message.Message):
    __slots__ = ('text', 'parent_progress_item_id')
    TEXT_FIELD_NUMBER: _ClassVar[int]
    PARENT_PROGRESS_ITEM_ID_FIELD_NUMBER: _ClassVar[int]
    text: str
    parent_progress_item_id: str

    def __init__(self, text: _Optional[str]=..., parent_progress_item_id: _Optional[str]=...) -> None:
        ...

class SpanOpenEvent(_message.Message):
    __slots__ = ('span_id', 'title', 'description')
    SPAN_ID_FIELD_NUMBER: _ClassVar[int]
    TITLE_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    span_id: str
    title: str
    description: str

    def __init__(self, span_id: _Optional[str]=..., title: _Optional[str]=..., description: _Optional[str]=...) -> None:
        ...

class SpanCloseEvent(_message.Message):
    __slots__ = ('span_id',)
    SPAN_ID_FIELD_NUMBER: _ClassVar[int]
    span_id: str

    def __init__(self, span_id: _Optional[str]=...) -> None:
        ...

class TestsRunEvent(_message.Message):
    __slots__ = ('test_results_json',)
    TEST_RESULTS_JSON_FIELD_NUMBER: _ClassVar[int]
    test_results_json: str

    def __init__(self, test_results_json: _Optional[str]=...) -> None:
        ...

class SpecChangeSummaryEvent(_message.Message):
    __slots__ = ('summary',)
    SUMMARY_FIELD_NUMBER: _ClassVar[int]
    summary: str

    def __init__(self, summary: _Optional[str]=...) -> None:
        ...

class StopInteractiveProgressEvent(_message.Message):
    __slots__ = ()

    def __init__(self) -> None:
        ...

class ResetProgressEvent(_message.Message):
    __slots__ = ()

    def __init__(self) -> None:
        ...