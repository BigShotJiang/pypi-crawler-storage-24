"""Client and server classes corresponding to protobuf-defined services."""
import grpc
import warnings
from . import build_server_pb2 as build__server__pb2
GRPC_GENERATED_VERSION = '1.71.2'
GRPC_VERSION = grpc.__version__
_version_not_supported = False
try:
    from grpc._utilities import first_version_is_lower
    _version_not_supported = first_version_is_lower(GRPC_VERSION, GRPC_GENERATED_VERSION)
except ImportError:
    _version_not_supported = True
if _version_not_supported:
    raise RuntimeError(f'The grpc package installed is at version {GRPC_VERSION},' + f' but the generated code in build_server_pb2_grpc.py depends on' + f' grpcio>={GRPC_GENERATED_VERSION}.' + f' Please upgrade your grpc module to grpcio>={GRPC_GENERATED_VERSION}' + f' or downgrade your generated code using grpcio-tools<={GRPC_VERSION}.')

class BuildServiceStub(object):
    """Service definition
    """

    def __init__(self, channel):
        """Constructor.

        Args:
            channel: A grpc.Channel.
        """
        self.Build = channel.stream_stream('/codespeak.build_server.BuildService/Build', request_serializer=build__server__pb2.ClientMessage.SerializeToString, response_deserializer=build__server__pb2.ServerMessage.FromString, _registered_method=True)

class BuildServiceServicer(object):
    """Service definition
    """

    def Build(self, request_iterator, context):
        """Missing associated documentation comment in .proto file."""
        context.set_code(grpc.StatusCode.UNIMPLEMENTED)
        context.set_details('Method not implemented!')
        raise NotImplementedError('Method not implemented!')

def add_BuildServiceServicer_to_server(servicer, server):
    rpc_method_handlers = {'Build': grpc.stream_stream_rpc_method_handler(servicer.Build, request_deserializer=build__server__pb2.ClientMessage.FromString, response_serializer=build__server__pb2.ServerMessage.SerializeToString)}
    generic_handler = grpc.method_handlers_generic_handler('codespeak.build_server.BuildService', rpc_method_handlers)
    server.add_generic_rpc_handlers((generic_handler,))
    server.add_registered_method_handlers('codespeak.build_server.BuildService', rpc_method_handlers)

class BuildService(object):
    """Service definition
    """

    @staticmethod
    def Build(request_iterator, target, options=(), channel_credentials=None, call_credentials=None, insecure=False, compression=None, wait_for_ready=None, timeout=None, metadata=None):
        return grpc.experimental.stream_stream(request_iterator, target, '/codespeak.build_server.BuildService/Build', build__server__pb2.ClientMessage.SerializeToString, build__server__pb2.ServerMessage.FromString, options, channel_credentials, insecure, call_credentials, compression, wait_for_ready, timeout, metadata, _registered_method=True)