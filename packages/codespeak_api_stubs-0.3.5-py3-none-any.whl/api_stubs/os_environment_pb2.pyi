from google.protobuf.internal import containers as _containers
from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar as _ClassVar, Iterable as _Iterable, Mapping as _Mapping, Optional as _Optional, Union as _Union
DESCRIPTOR: _descriptor.FileDescriptor

class ChildProcessOutcome(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    PROCESS_FINISHED: _ClassVar[ChildProcessOutcome]
    FAILED_TO_START_PROCESS: _ClassVar[ChildProcessOutcome]
    PROCESS_TIMED_OUT: _ClassVar[ChildProcessOutcome]
    UNKNOWN: _ClassVar[ChildProcessOutcome]

class ErrorType(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    ERROR_TYPE_UNSPECIFIED: _ClassVar[ErrorType]
    FILE_NOT_FOUND: _ClassVar[ErrorType]
    MAX_FILE_SIZE_EXCEEDED: _ClassVar[ErrorType]
    FILE_STATE_EXPECTATION_NOT_MET: _ClassVar[ErrorType]
    CLIENT_RESPONSE_TOO_BIG: _ClassVar[ErrorType]
    OS_ENV_CLOSED: _ClassVar[ErrorType]

class DjangoServerRunMode(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    DJANGO_SERVER_RUN_MODE_UNSPECIFIED: _ClassVar[DjangoServerRunMode]
    DJANGO_SERVER_RUN_MODE_INTERACTIVE: _ClassVar[DjangoServerRunMode]
    DJANGO_SERVER_RUN_MODE_SHUTDOWN_WHEN_READY: _ClassVar[DjangoServerRunMode]

class GrepOutputMode(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    GREP_OUTPUT_MODE_UNSPECIFIED: _ClassVar[GrepOutputMode]
    GREP_OUTPUT_MODE_FILES_WITH_MATCHES: _ClassVar[GrepOutputMode]
    GREP_OUTPUT_MODE_CONTENT: _ClassVar[GrepOutputMode]
    GREP_OUTPUT_MODE_COUNT: _ClassVar[GrepOutputMode]
PROCESS_FINISHED: ChildProcessOutcome
FAILED_TO_START_PROCESS: ChildProcessOutcome
PROCESS_TIMED_OUT: ChildProcessOutcome
UNKNOWN: ChildProcessOutcome
ERROR_TYPE_UNSPECIFIED: ErrorType
FILE_NOT_FOUND: ErrorType
MAX_FILE_SIZE_EXCEEDED: ErrorType
FILE_STATE_EXPECTATION_NOT_MET: ErrorType
CLIENT_RESPONSE_TOO_BIG: ErrorType
OS_ENV_CLOSED: ErrorType
DJANGO_SERVER_RUN_MODE_UNSPECIFIED: DjangoServerRunMode
DJANGO_SERVER_RUN_MODE_INTERACTIVE: DjangoServerRunMode
DJANGO_SERVER_RUN_MODE_SHUTDOWN_WHEN_READY: DjangoServerRunMode
GREP_OUTPUT_MODE_UNSPECIFIED: GrepOutputMode
GREP_OUTPUT_MODE_FILES_WITH_MATCHES: GrepOutputMode
GREP_OUTPUT_MODE_CONTENT: GrepOutputMode
GREP_OUTPUT_MODE_COUNT: GrepOutputMode

class EntryAttributes(_message.Message):
    __slots__ = ('last_modified', 'size', 'mode', 'nlink', 'user_name', 'group_name')
    LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    SIZE_FIELD_NUMBER: _ClassVar[int]
    MODE_FIELD_NUMBER: _ClassVar[int]
    NLINK_FIELD_NUMBER: _ClassVar[int]
    USER_NAME_FIELD_NUMBER: _ClassVar[int]
    GROUP_NAME_FIELD_NUMBER: _ClassVar[int]
    last_modified: float
    size: int
    mode: int
    nlink: int
    user_name: str
    group_name: str

    def __init__(self, last_modified: _Optional[float]=..., size: _Optional[int]=..., mode: _Optional[int]=..., nlink: _Optional[int]=..., user_name: _Optional[str]=..., group_name: _Optional[str]=...) -> None:
        ...

class Missing(_message.Message):
    __slots__ = ()

    def __init__(self) -> None:
        ...

class ExistsWithLastModifiedTimestamp(_message.Message):
    __slots__ = ('timestamp',)
    TIMESTAMP_FIELD_NUMBER: _ClassVar[int]
    timestamp: float

    def __init__(self, timestamp: _Optional[float]=...) -> None:
        ...

class FileState(_message.Message):
    __slots__ = ('missing', 'exists_with_last_modified_timestamp')
    MISSING_FIELD_NUMBER: _ClassVar[int]
    EXISTS_WITH_LAST_MODIFIED_TIMESTAMP_FIELD_NUMBER: _ClassVar[int]
    missing: Missing
    exists_with_last_modified_timestamp: ExistsWithLastModifiedTimestamp

    def __init__(self, missing: _Optional[_Union[Missing, _Mapping]]=..., exists_with_last_modified_timestamp: _Optional[_Union[ExistsWithLastModifiedTimestamp, _Mapping]]=...) -> None:
        ...

class ErrorInfo(_message.Message):
    __slots__ = ('message', 'type')
    MESSAGE_FIELD_NUMBER: _ClassVar[int]
    TYPE_FIELD_NUMBER: _ClassVar[int]
    message: str
    type: ErrorType

    def __init__(self, message: _Optional[str]=..., type: _Optional[_Union[ErrorType, str]]=...) -> None:
        ...

class ChildProcessResult(_message.Message):
    __slots__ = ('exit_code', 'stdout', 'stderr')
    EXIT_CODE_FIELD_NUMBER: _ClassVar[int]
    STDOUT_FIELD_NUMBER: _ClassVar[int]
    STDERR_FIELD_NUMBER: _ClassVar[int]
    exit_code: int
    stdout: str
    stderr: str

    def __init__(self, exit_code: _Optional[int]=..., stdout: _Optional[str]=..., stderr: _Optional[str]=...) -> None:
        ...

class GetAttributesRequest(_message.Message):
    __slots__ = ('path',)
    PATH_FIELD_NUMBER: _ClassVar[int]
    path: str

    def __init__(self, path: _Optional[str]=...) -> None:
        ...

class GetAttributesResponse(_message.Message):
    __slots__ = ('attributes', 'error')
    ATTRIBUTES_FIELD_NUMBER: _ClassVar[int]
    ERROR_FIELD_NUMBER: _ClassVar[int]
    attributes: EntryAttributes
    error: ErrorInfo

    def __init__(self, attributes: _Optional[_Union[EntryAttributes, _Mapping]]=..., error: _Optional[_Union[ErrorInfo, _Mapping]]=...) -> None:
        ...

class ReadFileRequest(_message.Message):
    __slots__ = ('path', 'max_allowed_file_size_bytes', 'offset_line', 'limit_lines')
    PATH_FIELD_NUMBER: _ClassVar[int]
    MAX_ALLOWED_FILE_SIZE_BYTES_FIELD_NUMBER: _ClassVar[int]
    OFFSET_LINE_FIELD_NUMBER: _ClassVar[int]
    LIMIT_LINES_FIELD_NUMBER: _ClassVar[int]
    path: str
    max_allowed_file_size_bytes: int
    offset_line: int
    limit_lines: int

    def __init__(self, path: _Optional[str]=..., max_allowed_file_size_bytes: _Optional[int]=..., offset_line: _Optional[int]=..., limit_lines: _Optional[int]=...) -> None:
        ...

class ReadFileResponse(_message.Message):
    __slots__ = ('content', 'attributes', 'error', 'truncated')
    CONTENT_FIELD_NUMBER: _ClassVar[int]
    ATTRIBUTES_FIELD_NUMBER: _ClassVar[int]
    ERROR_FIELD_NUMBER: _ClassVar[int]
    TRUNCATED_FIELD_NUMBER: _ClassVar[int]
    content: str
    attributes: EntryAttributes
    error: ErrorInfo
    truncated: bool

    def __init__(self, content: _Optional[str]=..., attributes: _Optional[_Union[EntryAttributes, _Mapping]]=..., error: _Optional[_Union[ErrorInfo, _Mapping]]=..., truncated: bool=...) -> None:
        ...

class WriteFileRequest(_message.Message):
    __slots__ = ('path', 'content', 'expected_state')
    PATH_FIELD_NUMBER: _ClassVar[int]
    CONTENT_FIELD_NUMBER: _ClassVar[int]
    EXPECTED_STATE_FIELD_NUMBER: _ClassVar[int]
    path: str
    content: str
    expected_state: FileState

    def __init__(self, path: _Optional[str]=..., content: _Optional[str]=..., expected_state: _Optional[_Union[FileState, _Mapping]]=...) -> None:
        ...

class WriteFileResponse(_message.Message):
    __slots__ = ('error', 'new_last_modified')
    ERROR_FIELD_NUMBER: _ClassVar[int]
    NEW_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    error: ErrorInfo
    new_last_modified: float

    def __init__(self, error: _Optional[_Union[ErrorInfo, _Mapping]]=..., new_last_modified: _Optional[float]=...) -> None:
        ...

class AppendToFileRequest(_message.Message):
    __slots__ = ('path', 'content', 'expected_state')
    PATH_FIELD_NUMBER: _ClassVar[int]
    CONTENT_FIELD_NUMBER: _ClassVar[int]
    EXPECTED_STATE_FIELD_NUMBER: _ClassVar[int]
    path: str
    content: str
    expected_state: FileState

    def __init__(self, path: _Optional[str]=..., content: _Optional[str]=..., expected_state: _Optional[_Union[FileState, _Mapping]]=...) -> None:
        ...

class AppendToFileResponse(_message.Message):
    __slots__ = ('error', 'new_last_modified')
    ERROR_FIELD_NUMBER: _ClassVar[int]
    NEW_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    error: ErrorInfo
    new_last_modified: float

    def __init__(self, error: _Optional[_Union[ErrorInfo, _Mapping]]=..., new_last_modified: _Optional[float]=...) -> None:
        ...

class MkdirsRequest(_message.Message):
    __slots__ = ('path',)
    PATH_FIELD_NUMBER: _ClassVar[int]
    path: str

    def __init__(self, path: _Optional[str]=...) -> None:
        ...

class MkdirsResponse(_message.Message):
    __slots__ = ('error',)
    ERROR_FIELD_NUMBER: _ClassVar[int]
    error: ErrorInfo

    def __init__(self, error: _Optional[_Union[ErrorInfo, _Mapping]]=...) -> None:
        ...

class IsFileRequest(_message.Message):
    __slots__ = ('path',)
    PATH_FIELD_NUMBER: _ClassVar[int]
    path: str

    def __init__(self, path: _Optional[str]=...) -> None:
        ...

class IsFileResponse(_message.Message):
    __slots__ = ('result', 'error')
    RESULT_FIELD_NUMBER: _ClassVar[int]
    ERROR_FIELD_NUMBER: _ClassVar[int]
    result: bool
    error: ErrorInfo

    def __init__(self, result: bool=..., error: _Optional[_Union[ErrorInfo, _Mapping]]=...) -> None:
        ...

class IsDirectoryRequest(_message.Message):
    __slots__ = ('path',)
    PATH_FIELD_NUMBER: _ClassVar[int]
    path: str

    def __init__(self, path: _Optional[str]=...) -> None:
        ...

class IsDirectoryResponse(_message.Message):
    __slots__ = ('result', 'error')
    RESULT_FIELD_NUMBER: _ClassVar[int]
    ERROR_FIELD_NUMBER: _ClassVar[int]
    result: bool
    error: ErrorInfo

    def __init__(self, result: bool=..., error: _Optional[_Union[ErrorInfo, _Mapping]]=...) -> None:
        ...

class ExistsRequest(_message.Message):
    __slots__ = ('path',)
    PATH_FIELD_NUMBER: _ClassVar[int]
    path: str

    def __init__(self, path: _Optional[str]=...) -> None:
        ...

class ExistsResponse(_message.Message):
    __slots__ = ('result', 'error')
    RESULT_FIELD_NUMBER: _ClassVar[int]
    ERROR_FIELD_NUMBER: _ClassVar[int]
    result: bool
    error: ErrorInfo

    def __init__(self, result: bool=..., error: _Optional[_Union[ErrorInfo, _Mapping]]=...) -> None:
        ...

class CopyRequest(_message.Message):
    __slots__ = ('source_path', 'dest_path')
    SOURCE_PATH_FIELD_NUMBER: _ClassVar[int]
    DEST_PATH_FIELD_NUMBER: _ClassVar[int]
    source_path: str
    dest_path: str

    def __init__(self, source_path: _Optional[str]=..., dest_path: _Optional[str]=...) -> None:
        ...

class CopyResponse(_message.Message):
    __slots__ = ('error',)
    ERROR_FIELD_NUMBER: _ClassVar[int]
    error: ErrorInfo

    def __init__(self, error: _Optional[_Union[ErrorInfo, _Mapping]]=...) -> None:
        ...

class DeleteRecursivelyRequest(_message.Message):
    __slots__ = ('path',)
    PATH_FIELD_NUMBER: _ClassVar[int]
    path: str

    def __init__(self, path: _Optional[str]=...) -> None:
        ...

class DeleteRecursivelyResponse(_message.Message):
    __slots__ = ('error',)
    ERROR_FIELD_NUMBER: _ClassVar[int]
    error: ErrorInfo

    def __init__(self, error: _Optional[_Union[ErrorInfo, _Mapping]]=...) -> None:
        ...

class DeleteFileRequest(_message.Message):
    __slots__ = ('path',)
    PATH_FIELD_NUMBER: _ClassVar[int]
    path: str

    def __init__(self, path: _Optional[str]=...) -> None:
        ...

class DeleteFileResponse(_message.Message):
    __slots__ = ('error',)
    ERROR_FIELD_NUMBER: _ClassVar[int]
    error: ErrorInfo

    def __init__(self, error: _Optional[_Union[ErrorInfo, _Mapping]]=...) -> None:
        ...

class ListDirectoryRequest(_message.Message):
    __slots__ = ('path',)
    PATH_FIELD_NUMBER: _ClassVar[int]
    path: str

    def __init__(self, path: _Optional[str]=...) -> None:
        ...

class ListDirectoryResponse(_message.Message):
    __slots__ = ('entries', 'error')
    ENTRIES_FIELD_NUMBER: _ClassVar[int]
    ERROR_FIELD_NUMBER: _ClassVar[int]
    entries: _containers.RepeatedScalarFieldContainer[str]
    error: ErrorInfo

    def __init__(self, entries: _Optional[_Iterable[str]]=..., error: _Optional[_Union[ErrorInfo, _Mapping]]=...) -> None:
        ...

class GlobRequest(_message.Message):
    __slots__ = ('pattern', 'path')
    PATTERN_FIELD_NUMBER: _ClassVar[int]
    PATH_FIELD_NUMBER: _ClassVar[int]
    pattern: str
    path: str

    def __init__(self, pattern: _Optional[str]=..., path: _Optional[str]=...) -> None:
        ...

class GlobResponse(_message.Message):
    __slots__ = ('paths', 'error')
    PATHS_FIELD_NUMBER: _ClassVar[int]
    ERROR_FIELD_NUMBER: _ClassVar[int]
    paths: _containers.RepeatedScalarFieldContainer[str]
    error: ErrorInfo

    def __init__(self, paths: _Optional[_Iterable[str]]=..., error: _Optional[_Union[ErrorInfo, _Mapping]]=...) -> None:
        ...

class ResolveUserNameRequest(_message.Message):
    __slots__ = ()

    def __init__(self) -> None:
        ...

class ResolveUserNameResponse(_message.Message):
    __slots__ = ('username', 'error')
    USERNAME_FIELD_NUMBER: _ClassVar[int]
    ERROR_FIELD_NUMBER: _ClassVar[int]
    username: str
    error: ErrorInfo

    def __init__(self, username: _Optional[str]=..., error: _Optional[_Union[ErrorInfo, _Mapping]]=...) -> None:
        ...

class RunChildProcessRequest(_message.Message):
    __slots__ = ('args', 'cwd_relative', 'timeout', 'check', 'redirected_output_path', 'shell', 'output_limit_chars', 'interactive_mode', 'add_distribution_bin')
    ARGS_FIELD_NUMBER: _ClassVar[int]
    CWD_RELATIVE_FIELD_NUMBER: _ClassVar[int]
    TIMEOUT_FIELD_NUMBER: _ClassVar[int]
    CHECK_FIELD_NUMBER: _ClassVar[int]
    REDIRECTED_OUTPUT_PATH_FIELD_NUMBER: _ClassVar[int]
    SHELL_FIELD_NUMBER: _ClassVar[int]
    OUTPUT_LIMIT_CHARS_FIELD_NUMBER: _ClassVar[int]
    INTERACTIVE_MODE_FIELD_NUMBER: _ClassVar[int]
    ADD_DISTRIBUTION_BIN_FIELD_NUMBER: _ClassVar[int]
    args: _containers.RepeatedScalarFieldContainer[str]
    cwd_relative: str
    timeout: float
    check: bool
    redirected_output_path: str
    shell: bool
    output_limit_chars: int
    interactive_mode: bool
    add_distribution_bin: bool

    def __init__(self, args: _Optional[_Iterable[str]]=..., cwd_relative: _Optional[str]=..., timeout: _Optional[float]=..., check: bool=..., redirected_output_path: _Optional[str]=..., shell: bool=..., output_limit_chars: _Optional[int]=..., interactive_mode: bool=..., add_distribution_bin: bool=...) -> None:
        ...

class RunChildProcessResponse(_message.Message):
    __slots__ = ('result', 'error', 'outcome')
    RESULT_FIELD_NUMBER: _ClassVar[int]
    ERROR_FIELD_NUMBER: _ClassVar[int]
    OUTCOME_FIELD_NUMBER: _ClassVar[int]
    result: ChildProcessResult
    error: ErrorInfo
    outcome: ChildProcessOutcome

    def __init__(self, result: _Optional[_Union[ChildProcessResult, _Mapping]]=..., error: _Optional[_Union[ErrorInfo, _Mapping]]=..., outcome: _Optional[_Union[ChildProcessOutcome, str]]=...) -> None:
        ...

class ResolvePathRequest(_message.Message):
    __slots__ = ('path',)
    PATH_FIELD_NUMBER: _ClassVar[int]
    path: str

    def __init__(self, path: _Optional[str]=...) -> None:
        ...

class ResolvePathResponse(_message.Message):
    __slots__ = ('resolved_path', 'error')
    RESOLVED_PATH_FIELD_NUMBER: _ClassVar[int]
    ERROR_FIELD_NUMBER: _ClassVar[int]
    resolved_path: str
    error: ErrorInfo

    def __init__(self, resolved_path: _Optional[str]=..., error: _Optional[_Union[ErrorInfo, _Mapping]]=...) -> None:
        ...

class TraverseRequest(_message.Message):
    __slots__ = ('prune_dirnames', 'skip_file_basenames', 'required_extension')
    PRUNE_DIRNAMES_FIELD_NUMBER: _ClassVar[int]
    SKIP_FILE_BASENAMES_FIELD_NUMBER: _ClassVar[int]
    REQUIRED_EXTENSION_FIELD_NUMBER: _ClassVar[int]
    prune_dirnames: _containers.RepeatedScalarFieldContainer[str]
    skip_file_basenames: _containers.RepeatedScalarFieldContainer[str]
    required_extension: str

    def __init__(self, prune_dirnames: _Optional[_Iterable[str]]=..., skip_file_basenames: _Optional[_Iterable[str]]=..., required_extension: _Optional[str]=...) -> None:
        ...

class TraverseResponse(_message.Message):
    __slots__ = ('paths', 'error')
    PATHS_FIELD_NUMBER: _ClassVar[int]
    ERROR_FIELD_NUMBER: _ClassVar[int]
    paths: _containers.RepeatedScalarFieldContainer[str]
    error: ErrorInfo

    def __init__(self, paths: _Optional[_Iterable[str]]=..., error: _Optional[_Union[ErrorInfo, _Mapping]]=...) -> None:
        ...

class RunDjangoDevServerRequest(_message.Message):
    __slots__ = ('server_readiness_timeout_sec', 'run_mode')
    SERVER_READINESS_TIMEOUT_SEC_FIELD_NUMBER: _ClassVar[int]
    RUN_MODE_FIELD_NUMBER: _ClassVar[int]
    server_readiness_timeout_sec: int
    run_mode: DjangoServerRunMode

    def __init__(self, server_readiness_timeout_sec: _Optional[int]=..., run_mode: _Optional[_Union[DjangoServerRunMode, str]]=...) -> None:
        ...

class RunDjangoDevServerResponse(_message.Message):
    __slots__ = ('success', 'error_output', 'error')
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    ERROR_OUTPUT_FIELD_NUMBER: _ClassVar[int]
    ERROR_FIELD_NUMBER: _ClassVar[int]
    success: bool
    error_output: str
    error: ErrorInfo

    def __init__(self, success: bool=..., error_output: _Optional[str]=..., error: _Optional[_Union[ErrorInfo, _Mapping]]=...) -> None:
        ...

class GrepRequest(_message.Message):
    __slots__ = ('pattern', 'path', 'glob', 'output_mode', 'context_before', 'context_after', 'context_both', 'show_line_numbers', 'case_insensitive', 'file_type', 'head_limit', 'offset', 'multiline')
    PATTERN_FIELD_NUMBER: _ClassVar[int]
    PATH_FIELD_NUMBER: _ClassVar[int]
    GLOB_FIELD_NUMBER: _ClassVar[int]
    OUTPUT_MODE_FIELD_NUMBER: _ClassVar[int]
    CONTEXT_BEFORE_FIELD_NUMBER: _ClassVar[int]
    CONTEXT_AFTER_FIELD_NUMBER: _ClassVar[int]
    CONTEXT_BOTH_FIELD_NUMBER: _ClassVar[int]
    SHOW_LINE_NUMBERS_FIELD_NUMBER: _ClassVar[int]
    CASE_INSENSITIVE_FIELD_NUMBER: _ClassVar[int]
    FILE_TYPE_FIELD_NUMBER: _ClassVar[int]
    HEAD_LIMIT_FIELD_NUMBER: _ClassVar[int]
    OFFSET_FIELD_NUMBER: _ClassVar[int]
    MULTILINE_FIELD_NUMBER: _ClassVar[int]
    pattern: str
    path: str
    glob: str
    output_mode: GrepOutputMode
    context_before: int
    context_after: int
    context_both: int
    show_line_numbers: bool
    case_insensitive: bool
    file_type: str
    head_limit: int
    offset: int
    multiline: bool

    def __init__(self, pattern: _Optional[str]=..., path: _Optional[str]=..., glob: _Optional[str]=..., output_mode: _Optional[_Union[GrepOutputMode, str]]=..., context_before: _Optional[int]=..., context_after: _Optional[int]=..., context_both: _Optional[int]=..., show_line_numbers: bool=..., case_insensitive: bool=..., file_type: _Optional[str]=..., head_limit: _Optional[int]=..., offset: _Optional[int]=..., multiline: bool=...) -> None:
        ...

class GrepMatch(_message.Message):
    __slots__ = ('file_path', 'line_number', 'line_content')
    FILE_PATH_FIELD_NUMBER: _ClassVar[int]
    LINE_NUMBER_FIELD_NUMBER: _ClassVar[int]
    LINE_CONTENT_FIELD_NUMBER: _ClassVar[int]
    file_path: str
    line_number: int
    line_content: str

    def __init__(self, file_path: _Optional[str]=..., line_number: _Optional[int]=..., line_content: _Optional[str]=...) -> None:
        ...

class GrepFileCount(_message.Message):
    __slots__ = ('file_path', 'match_count')
    FILE_PATH_FIELD_NUMBER: _ClassVar[int]
    MATCH_COUNT_FIELD_NUMBER: _ClassVar[int]
    file_path: str
    match_count: int

    def __init__(self, file_path: _Optional[str]=..., match_count: _Optional[int]=...) -> None:
        ...

class GrepResponse(_message.Message):
    __slots__ = ('matching_files', 'matches', 'file_counts', 'error')
    MATCHING_FILES_FIELD_NUMBER: _ClassVar[int]
    MATCHES_FIELD_NUMBER: _ClassVar[int]
    FILE_COUNTS_FIELD_NUMBER: _ClassVar[int]
    ERROR_FIELD_NUMBER: _ClassVar[int]
    matching_files: _containers.RepeatedScalarFieldContainer[str]
    matches: _containers.RepeatedCompositeFieldContainer[GrepMatch]
    file_counts: _containers.RepeatedCompositeFieldContainer[GrepFileCount]
    error: ErrorInfo

    def __init__(self, matching_files: _Optional[_Iterable[str]]=..., matches: _Optional[_Iterable[_Union[GrepMatch, _Mapping]]]=..., file_counts: _Optional[_Iterable[_Union[GrepFileCount, _Mapping]]]=..., error: _Optional[_Union[ErrorInfo, _Mapping]]=...) -> None:
        ...

class TreeEntry(_message.Message):
    __slots__ = ('path', 'is_directory')
    PATH_FIELD_NUMBER: _ClassVar[int]
    IS_DIRECTORY_FIELD_NUMBER: _ClassVar[int]
    path: str
    is_directory: bool

    def __init__(self, path: _Optional[str]=..., is_directory: bool=...) -> None:
        ...

class ListTreeRequest(_message.Message):
    __slots__ = ('path', 'max_depth', 'max_entries')
    PATH_FIELD_NUMBER: _ClassVar[int]
    MAX_DEPTH_FIELD_NUMBER: _ClassVar[int]
    MAX_ENTRIES_FIELD_NUMBER: _ClassVar[int]
    path: str
    max_depth: int
    max_entries: int

    def __init__(self, path: _Optional[str]=..., max_depth: _Optional[int]=..., max_entries: _Optional[int]=...) -> None:
        ...

class ListTreeResponse(_message.Message):
    __slots__ = ('entries', 'error', 'truncated')
    ENTRIES_FIELD_NUMBER: _ClassVar[int]
    ERROR_FIELD_NUMBER: _ClassVar[int]
    TRUNCATED_FIELD_NUMBER: _ClassVar[int]
    entries: _containers.RepeatedCompositeFieldContainer[TreeEntry]
    error: ErrorInfo
    truncated: bool

    def __init__(self, entries: _Optional[_Iterable[_Union[TreeEntry, _Mapping]]]=..., error: _Optional[_Union[ErrorInfo, _Mapping]]=..., truncated: bool=...) -> None:
        ...

class OperationRequest(_message.Message):
    __slots__ = ('request_id', 'get_attributes', 'read_file', 'write_file', 'append_to_file', 'mkdirs', 'is_file', 'is_directory', 'exists', 'copy', 'delete_recursively', 'delete_file', 'list_directory', 'glob', 'resolve_user_name', 'run_child_process', 'resolve_path', 'traverse', 'run_django_dev_server', 'grep', 'list_tree', 'is_cleanup', 'request_timeout')
    REQUEST_ID_FIELD_NUMBER: _ClassVar[int]
    GET_ATTRIBUTES_FIELD_NUMBER: _ClassVar[int]
    READ_FILE_FIELD_NUMBER: _ClassVar[int]
    WRITE_FILE_FIELD_NUMBER: _ClassVar[int]
    APPEND_TO_FILE_FIELD_NUMBER: _ClassVar[int]
    MKDIRS_FIELD_NUMBER: _ClassVar[int]
    IS_FILE_FIELD_NUMBER: _ClassVar[int]
    IS_DIRECTORY_FIELD_NUMBER: _ClassVar[int]
    EXISTS_FIELD_NUMBER: _ClassVar[int]
    COPY_FIELD_NUMBER: _ClassVar[int]
    DELETE_RECURSIVELY_FIELD_NUMBER: _ClassVar[int]
    DELETE_FILE_FIELD_NUMBER: _ClassVar[int]
    LIST_DIRECTORY_FIELD_NUMBER: _ClassVar[int]
    GLOB_FIELD_NUMBER: _ClassVar[int]
    RESOLVE_USER_NAME_FIELD_NUMBER: _ClassVar[int]
    RUN_CHILD_PROCESS_FIELD_NUMBER: _ClassVar[int]
    RESOLVE_PATH_FIELD_NUMBER: _ClassVar[int]
    TRAVERSE_FIELD_NUMBER: _ClassVar[int]
    RUN_DJANGO_DEV_SERVER_FIELD_NUMBER: _ClassVar[int]
    GREP_FIELD_NUMBER: _ClassVar[int]
    LIST_TREE_FIELD_NUMBER: _ClassVar[int]
    IS_CLEANUP_FIELD_NUMBER: _ClassVar[int]
    REQUEST_TIMEOUT_FIELD_NUMBER: _ClassVar[int]
    request_id: str
    get_attributes: GetAttributesRequest
    read_file: ReadFileRequest
    write_file: WriteFileRequest
    append_to_file: AppendToFileRequest
    mkdirs: MkdirsRequest
    is_file: IsFileRequest
    is_directory: IsDirectoryRequest
    exists: ExistsRequest
    copy: CopyRequest
    delete_recursively: DeleteRecursivelyRequest
    delete_file: DeleteFileRequest
    list_directory: ListDirectoryRequest
    glob: GlobRequest
    resolve_user_name: ResolveUserNameRequest
    run_child_process: RunChildProcessRequest
    resolve_path: ResolvePathRequest
    traverse: TraverseRequest
    run_django_dev_server: RunDjangoDevServerRequest
    grep: GrepRequest
    list_tree: ListTreeRequest
    is_cleanup: bool
    request_timeout: float

    def __init__(self, request_id: _Optional[str]=..., get_attributes: _Optional[_Union[GetAttributesRequest, _Mapping]]=..., read_file: _Optional[_Union[ReadFileRequest, _Mapping]]=..., write_file: _Optional[_Union[WriteFileRequest, _Mapping]]=..., append_to_file: _Optional[_Union[AppendToFileRequest, _Mapping]]=..., mkdirs: _Optional[_Union[MkdirsRequest, _Mapping]]=..., is_file: _Optional[_Union[IsFileRequest, _Mapping]]=..., is_directory: _Optional[_Union[IsDirectoryRequest, _Mapping]]=..., exists: _Optional[_Union[ExistsRequest, _Mapping]]=..., copy: _Optional[_Union[CopyRequest, _Mapping]]=..., delete_recursively: _Optional[_Union[DeleteRecursivelyRequest, _Mapping]]=..., delete_file: _Optional[_Union[DeleteFileRequest, _Mapping]]=..., list_directory: _Optional[_Union[ListDirectoryRequest, _Mapping]]=..., glob: _Optional[_Union[GlobRequest, _Mapping]]=..., resolve_user_name: _Optional[_Union[ResolveUserNameRequest, _Mapping]]=..., run_child_process: _Optional[_Union[RunChildProcessRequest, _Mapping]]=..., resolve_path: _Optional[_Union[ResolvePathRequest, _Mapping]]=..., traverse: _Optional[_Union[TraverseRequest, _Mapping]]=..., run_django_dev_server: _Optional[_Union[RunDjangoDevServerRequest, _Mapping]]=..., grep: _Optional[_Union[GrepRequest, _Mapping]]=..., list_tree: _Optional[_Union[ListTreeRequest, _Mapping]]=..., is_cleanup: bool=..., request_timeout: _Optional[float]=...) -> None:
        ...

class OperationResponse(_message.Message):
    __slots__ = ('request_id', 'client_internal_error', 'get_attributes', 'read_file', 'write_file', 'append_to_file', 'mkdirs', 'is_file', 'is_directory', 'exists', 'copy', 'delete_recursively', 'delete_file', 'list_directory', 'glob', 'resolve_user_name', 'run_child_process', 'resolve_path', 'traverse', 'run_django_dev_server', 'grep', 'list_tree', 'is_cleanup')
    REQUEST_ID_FIELD_NUMBER: _ClassVar[int]
    CLIENT_INTERNAL_ERROR_FIELD_NUMBER: _ClassVar[int]
    GET_ATTRIBUTES_FIELD_NUMBER: _ClassVar[int]
    READ_FILE_FIELD_NUMBER: _ClassVar[int]
    WRITE_FILE_FIELD_NUMBER: _ClassVar[int]
    APPEND_TO_FILE_FIELD_NUMBER: _ClassVar[int]
    MKDIRS_FIELD_NUMBER: _ClassVar[int]
    IS_FILE_FIELD_NUMBER: _ClassVar[int]
    IS_DIRECTORY_FIELD_NUMBER: _ClassVar[int]
    EXISTS_FIELD_NUMBER: _ClassVar[int]
    COPY_FIELD_NUMBER: _ClassVar[int]
    DELETE_RECURSIVELY_FIELD_NUMBER: _ClassVar[int]
    DELETE_FILE_FIELD_NUMBER: _ClassVar[int]
    LIST_DIRECTORY_FIELD_NUMBER: _ClassVar[int]
    GLOB_FIELD_NUMBER: _ClassVar[int]
    RESOLVE_USER_NAME_FIELD_NUMBER: _ClassVar[int]
    RUN_CHILD_PROCESS_FIELD_NUMBER: _ClassVar[int]
    RESOLVE_PATH_FIELD_NUMBER: _ClassVar[int]
    TRAVERSE_FIELD_NUMBER: _ClassVar[int]
    RUN_DJANGO_DEV_SERVER_FIELD_NUMBER: _ClassVar[int]
    GREP_FIELD_NUMBER: _ClassVar[int]
    LIST_TREE_FIELD_NUMBER: _ClassVar[int]
    IS_CLEANUP_FIELD_NUMBER: _ClassVar[int]
    request_id: str
    client_internal_error: ErrorInfo
    get_attributes: GetAttributesResponse
    read_file: ReadFileResponse
    write_file: WriteFileResponse
    append_to_file: AppendToFileResponse
    mkdirs: MkdirsResponse
    is_file: IsFileResponse
    is_directory: IsDirectoryResponse
    exists: ExistsResponse
    copy: CopyResponse
    delete_recursively: DeleteRecursivelyResponse
    delete_file: DeleteFileResponse
    list_directory: ListDirectoryResponse
    glob: GlobResponse
    resolve_user_name: ResolveUserNameResponse
    run_child_process: RunChildProcessResponse
    resolve_path: ResolvePathResponse
    traverse: TraverseResponse
    run_django_dev_server: RunDjangoDevServerResponse
    grep: GrepResponse
    list_tree: ListTreeResponse
    is_cleanup: bool

    def __init__(self, request_id: _Optional[str]=..., client_internal_error: _Optional[_Union[ErrorInfo, _Mapping]]=..., get_attributes: _Optional[_Union[GetAttributesResponse, _Mapping]]=..., read_file: _Optional[_Union[ReadFileResponse, _Mapping]]=..., write_file: _Optional[_Union[WriteFileResponse, _Mapping]]=..., append_to_file: _Optional[_Union[AppendToFileResponse, _Mapping]]=..., mkdirs: _Optional[_Union[MkdirsResponse, _Mapping]]=..., is_file: _Optional[_Union[IsFileResponse, _Mapping]]=..., is_directory: _Optional[_Union[IsDirectoryResponse, _Mapping]]=..., exists: _Optional[_Union[ExistsResponse, _Mapping]]=..., copy: _Optional[_Union[CopyResponse, _Mapping]]=..., delete_recursively: _Optional[_Union[DeleteRecursivelyResponse, _Mapping]]=..., delete_file: _Optional[_Union[DeleteFileResponse, _Mapping]]=..., list_directory: _Optional[_Union[ListDirectoryResponse, _Mapping]]=..., glob: _Optional[_Union[GlobResponse, _Mapping]]=..., resolve_user_name: _Optional[_Union[ResolveUserNameResponse, _Mapping]]=..., run_child_process: _Optional[_Union[RunChildProcessResponse, _Mapping]]=..., resolve_path: _Optional[_Union[ResolvePathResponse, _Mapping]]=..., traverse: _Optional[_Union[TraverseResponse, _Mapping]]=..., run_django_dev_server: _Optional[_Union[RunDjangoDevServerResponse, _Mapping]]=..., grep: _Optional[_Union[GrepResponse, _Mapping]]=..., list_tree: _Optional[_Union[ListTreeResponse, _Mapping]]=..., is_cleanup: bool=...) -> None:
        ...