<p align="center">
  <img src="https://img.shields.io/badge/python-3.10+-blue.svg" alt="Python 3.10+">
  <img src="https://img.shields.io/pypi/v/crowdmind.svg" alt="PyPI">
  <img src="https://img.shields.io/badge/license-MIT-green.svg" alt="MIT License">
</p>

<h1 align="center">CrowdMind</h1>

<p align="center">
<strong>Scrape Reddit & HN for user pain points. Automatically.</strong><br>
Find what real users complain about → Generate feature ideas → Score them with diverse AI personas
</p>

<p align="center">
<em>Inspired by <a href="https://github.com/karpathy/autoresearch">Karpathy's Autoresearch</a> — autonomous experimentation for product research</em>
</p>

<p align="center">
  <a href="#try-it-now">Try It</a> •
  <a href="#aha-moments">Use Cases</a> •
  <a href="#quick-start">Quick Start</a> •
  <a href="#commands">Commands</a> •
  <a href="#faq">FAQ</a>
</p>

---

## Try It Now

```bash
pip install crowdmind
export ANTHROPIC_API_KEY="sk-ant-..."  # or OPENAI_API_KEY
crowdmind validate "Your startup idea here"
```

```
$ crowdmind validate "A CLI tool for managing AI coding agents"

Score: 78/100 | Would Star: 70% | Would Pay: 55%

Feedback from 10 AI personas:
  ✓ "Solves a real pain point" - Senior Developer (9/10)
  ✓ "Would use this daily" - Indie Hacker (8/10)
  △ "Need team features for enterprise" - Tech Lead (7/10)
  ✗ "Skeptical, but research data looks useful" - Skeptic (5/10)
```

## What It Does

1. **Scrapes Reddit, HN, GitHub** for what users actually complain about
2. **Generates feature ideas** that solve real pain points (not imagined ones)
3. **Validates before you build** — test with 5 to 100+ AI personas in seconds
4. **Kills bad ideas early** — save weeks of building things nobody wants

**Validate features before deploying. Test positioning before launching. Know what users want before asking them.**

## Quick Start

```bash
# Install
pip install crowdmind
export ANTHROPIC_API_KEY="sk-ant-..."  # or OPENAI_API_KEY

# Validate an idea (60 seconds)
crowdmind validate "An app that tracks AI API spending"

# Find what users complain about (2 minutes)
crowdmind research --topics "AI coding tools" --sources reddit hackernews

# Full analysis on your project (5 minutes)
crowdmind analyze ./my-project --personas 15
```

## What It Finds

```bash
$ crowdmind research --topics "developer tools" --sources reddit hackernews

🔥 TOP FRUSTRATIONS (from 47 discussions):
   1. "Rate limits kill my flow state" (23 mentions)
   2. "No way to track spending" (18 mentions)
   3. "Context fills up too fast" (15 mentions)

💡 OPPORTUNITIES:
   → Rate limit predictor (solves #1)
   → Cost tracking dashboard (solves #2)
   → Smart context compression (solves #3)
```

## Commands

| Command | What it does | Time |
|---------|--------------|------|
| `crowdmind validate "idea"` | Test idea with AI personas | ~1 min |
| `crowdmind research` | Find pain points from Reddit/HN/GitHub | ~2 min |
| `crowdmind analyze ./path` | Full pipeline: research → ideate → validate | ~5 min |
| `crowdmind market ./path` | Pricing & go-to-market analysis | ~3 min |

## Persona Packs

```bash
# Choose your audience (default: 10 personas, use any number you want)
crowdmind validate "idea" --pack developers --personas 50   # 50 dev personas
crowdmind validate "idea" --pack indie --personas 100       # 100 indie hackers  
crowdmind validate "idea" --pack enterprise --personas 30   # 30 enterprise buyers
crowdmind validate "idea" --pack skeptics --personas 20     # 20 tough critics

# More personas = more signal, slightly more cost (~$0.01 per persona)
```

## Pro Tips: Get Better Results

### 1. Use Real Data to Build Better Personas

Don't guess who your users are. Find them first:

```bash
# Step 1: Research who's complaining and what they say
crowdmind research --topics "your niche" --sources reddit hackernews

# Output shows real user profiles:
#   → "Senior devs frustrated with slow builds" (34 mentions)
#   → "Indie hackers can't afford $50/mo tools" (28 mentions)
#   → "Enterprise teams blocked by security reviews" (19 mentions)

# Step 2: Now validate with personas that match real users
crowdmind validate "your idea" --pack developers --personas 30
crowdmind validate "your idea" --pack indie --personas 30
crowdmind validate "your idea" --pack enterprise --personas 30
```

### 2. Create Custom Personas from Your Actual Users

Have real user data? Create personas that match:

```yaml
# my-personas.yaml
personas:
  - "Senior engineer at a startup, mass $100+/mo on AI tools, frustrated by rate limits"
  - "Solo founder bootstrapping, budget under $20/mo, needs fast ROI"
  - "Tech lead evaluating for 10-person team, needs SSO and audit logs"
  - "Skeptical developer who tried 5 similar tools and was disappointed"
```

```bash
crowdmind validate "your idea" --pack ./my-personas.yaml --personas 50
```

### 3. Iterate Based on Score Breakdown

Don't just look at the total score. Dig into segments:

```bash
# Test same idea with different audiences
crowdmind validate "your feature" --pack developers   # → 72/100
crowdmind validate "your feature" --pack enterprise   # → 84/100
crowdmind validate "your feature" --pack indie        # → 45/100

# Insight: Enterprise loves it, indie hackers don't.
# Decision: Price for enterprise, not indie.
```

### 4. Combine Research + Validation Loop

The power move: let research inform your validation.

```bash
# 1. Find real pain points
crowdmind research --topics "CI/CD pipelines" --sources reddit
# → Top pain: "GitHub Actions minutes are expensive" (52 mentions)

# 2. Generate a solution
# Idea: "Self-hosted GitHub Actions runner with cost tracking"

# 3. Validate with personas who have this pain
crowdmind validate "Self-hosted GitHub Actions runner with cost tracking" --personas 50
# → 81/100 | "Would switch immediately" 

# 4. Iterate on positioning until you hit 80%+
```

### 5. Use Skeptics to Stress-Test

Before launch, run the skeptics gauntlet:

```bash
crowdmind validate "your final pitch" --pack skeptics --personas 30
# If skeptics score 60%+, you're ready.
# If below 50%, address their objections first.
```

---

## Python API

```python
import crowdmind

# Validate
result = crowdmind.validate("My product idea")
print(f"Score: {result['total_score']}/100")

# Research
research = crowdmind.research(topics=["AI tools"], sources=["reddit"])
print(research['frustrations'])

# Full workflow: Research → Validate with custom personas
pains = crowdmind.research(topics=["your niche"])
for pain in pains['frustrations'][:3]:
    score = crowdmind.validate(f"Solution for: {pain}", personas=30)
    print(f"{pain}: {score['total_score']}/100")
```

## Aha Moments

### 💡 "Don't deploy to prod to validate a feature"

You're about to spend 2 weeks building "AI-powered search". Before you write a line of code:

```bash
crowdmind validate "AI-powered semantic search for documentation"
# → 54/100 | "Most users just want faster Cmd+F, not AI magic"
# → Saved 2 weeks. Built better search filters instead.
```

### 💡 "Find out why users churn before they tell you"

```bash
crowdmind research --topics "why I stopped using [competitor]" --sources reddit
# → "Pricing jumped 3x after Series A" (47 mentions)
# → "Mobile app is abandonware" (31 mentions)  
# → Now you know exactly where to compete.
```

### 💡 "Test 5 positioning angles in 5 minutes"

```bash
crowdmind validate "The open-source Notion alternative"
# → 61/100 | "Crowded space, what's different?"

crowdmind validate "Notion but your data never leaves your machine"  
# → 78/100 | "Privacy angle is compelling. Would switch."
# → Found your positioning without A/B testing for weeks.
```

### 💡 "Know if enterprise will pay before building SSO"

```bash
crowdmind validate "Add SSO and audit logs" --pack enterprise --personas 50
# → 82/100 | 50 enterprise personas agree: "Table stakes. Won't evaluate without it."
# → Worth the 3 weeks. Ship it.

crowdmind validate "Add dark mode" --pack enterprise --personas 50
# → 41/100 | "Nice to have. Won't affect purchase decision."
# → Skip it. Focus on what closes deals.
```

### 💡 "Discover the feature nobody asked for but everyone wants"

```bash
crowdmind research --topics "developer productivity" --sources hackernews
# → Hidden gem: "I waste 20 min/day context-switching between projects" (28 mentions)
# → Nobody requested "workspace snapshots" but it's a top pain point.
```

### 💡 "Pre-validate your pivot"

```bash
crowdmind validate "Pivoting from B2C to B2B developer tools"
# → B2C score: 52/100 | "Too many free alternatives"
# → B2B score: 74/100 | "Would expense this. Saves 5hrs/week."
# → Data-backed pivot decision, not gut feeling.
```

## FAQ

<details>
<summary><strong>Is AI feedback accurate?</strong></summary>

It's a filter, not truth. Think spell-check for product ideas. Catches obvious misses before you spend months building. Use it to narrow 10 ideas to 2-3, then validate those with real users.
</details>

<details>
<summary><strong>How much does it cost?</strong></summary>

~$0.05-0.20 per validation. Research is mostly free (public APIs). Less than a coffee for a full analysis.
</details>

<details>
<summary><strong>What LLMs work?</strong></summary>

Anthropic, OpenAI, Google, Groq, Ollama (local/free). Use `--provider ollama` for completely free, offline validation.
</details>

<details>
<summary><strong>How is this different from asking ChatGPT?</strong></summary>

ChatGPT = 1 opinion. CrowdMind = 10-30 diverse personas that disagree with each other. Skeptics find flaws. Power users want features. Indie hackers complain about price. That diversity is the value.
</details>

## Credits

- **[EDSL](https://github.com/expectedparrot/edsl)** - AI agent framework powering persona simulation
- **[Karpathy's Autoresearch](https://github.com/karpathy/autoresearch)** - Inspiration for autonomous research loops

## License

MIT © [yasintoy](https://github.com/yasintoy)

---

<p align="center">
<strong>Stop guessing. Start validating.</strong><br>
<code>pip install crowdmind</code>
</p>
