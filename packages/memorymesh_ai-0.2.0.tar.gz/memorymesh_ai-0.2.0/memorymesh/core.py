"""
memorymesh/core.py

Local, private, model-agnostic shared memory for AI tools.
Zero cloud. Zero dependencies beyond Python stdlib.
SQLite + FTS5 under the hood.

API surface:
  remember(content, tags, source, importance) → id
  recall(query, limit, tags, source) → list[dict]
  as_context(query, limit, prefix) → str
  smart_context(query, ...) → str  (v0.2: prune + decay + filter)
"""

from __future__ import annotations

import hashlib
import json
import math
import os
import re
import sqlite3
import time
from datetime import datetime
from pathlib import Path
from typing import Any, Optional

DEFAULT_DB = Path.home() / ".memorymesh" / "memory.db"


def _fts_query(text: str) -> str:
    """Convert natural language to FTS5 prefix query."""
    clean = re.sub(r"[^\w\s]", " ", text)
    words = [w for w in clean.split() if len(w) > 1]
    if not words:
        return '""'
    return " OR ".join(w + "*" for w in words)


class MemoryMesh:
    """
    Shared memory for AI tools. Local. Private. Model-agnostic.

    Any tool that can call Python can read and write memories.
    The SQLite file lives at ~/.memorymesh/memory.db by default.
    Open it with any SQLite viewer. It is yours forever.

        mm = MemoryMesh()
        mm.remember("user prefers TypeScript")
        mm.recall("typescript")
        mm.as_context("current project")  # inject into any prompt
    """

    def __init__(
        self,
        db_path: Optional[str] = None,
        namespace: str = "default",
        default_ttl_days: Optional[int] = None,
    ) -> None:
        self.db_path = Path(db_path) if db_path else DEFAULT_DB
        self.namespace = namespace
        self.default_ttl_days = default_ttl_days
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._conn = sqlite3.connect(
            str(self.db_path), check_same_thread=False
        )
        self._conn.row_factory = sqlite3.Row
        self._conn.execute("PRAGMA journal_mode=WAL")
        self._init_schema()

    def _init_schema(self) -> None:
        self._conn.executescript("""
            CREATE TABLE IF NOT EXISTS memories (
                id           TEXT PRIMARY KEY,
                namespace    TEXT NOT NULL,
                content      TEXT NOT NULL,
                tags         TEXT DEFAULT '[]',
                source       TEXT DEFAULT 'user',
                importance   REAL DEFAULT 0.5,
                created_at   REAL NOT NULL,
                accessed_at  REAL NOT NULL,
                access_count INTEGER DEFAULT 0
            );
            CREATE INDEX IF NOT EXISTS idx_ns
                ON memories(namespace);
            CREATE INDEX IF NOT EXISTS idx_importance
                ON memories(importance DESC);
            CREATE VIRTUAL TABLE IF NOT EXISTS memories_fts
                USING fts5(id UNINDEXED, content, tags,
                           namespace UNINDEXED);
            CREATE TRIGGER IF NOT EXISTS trg_insert
                AFTER INSERT ON memories BEGIN
                    INSERT INTO memories_fts
                        (id, content, tags, namespace)
                    VALUES
                        (NEW.id, NEW.content,
                         NEW.tags, NEW.namespace);
                END;
            CREATE TRIGGER IF NOT EXISTS trg_delete
                AFTER DELETE ON memories BEGIN
                    DELETE FROM memories_fts
                    WHERE id = OLD.id;
                END;
        """)
        self._conn.commit()

    def _new_id(self, content: str) -> str:
        """
        Collision-safe ID generation.
        Uses os.urandom to prevent duplicate IDs on rapid inserts.
        """
        return hashlib.sha256(
            f"{self.namespace}:{content}:{time.time()}:"
            f"{os.urandom(8).hex()}".encode()
        ).hexdigest()[:16]

    def remember(
        self,
        content: str,
        tags: Optional[list[str]] = None,
        source: str = "user",
        importance: float = 0.5,
    ) -> str:
        """
        Store a memory. Returns memory ID.

        importance: 0.0–1.0. Higher = recalled first.

        Note: keyword search only.
          recall("FastAPI") works.
          recall("what framework does user prefer?") does not.
        """
        mid = self._new_id(content)
        now = time.time()
        self._conn.execute(
            "INSERT OR REPLACE INTO memories "
            "(id, namespace, content, tags, source, "
            "importance, created_at, accessed_at, access_count) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?, 0)",
            (
                mid, self.namespace, content,
                json.dumps(tags or []), source,
                importance, now, now,
            ),
        )
        self._conn.commit()
        return mid

    def recall(
        self,
        query: str,
        limit: int = 10,
        tags: Optional[list[str]] = None,
        source: Optional[str] = None,
        min_importance: float = 0.0,
    ) -> list[dict[str, Any]]:
        """
        Search memories using FTS5 full-text search.
        Falls back to LIKE if FTS fails.
        Returns results ranked by importance then recency.

        Tip: use exact keywords, not natural language questions.
        """
        try:
            rows = self._conn.execute(
                "SELECT m.* FROM memories m "
                "JOIN memories_fts fts ON m.id = fts.id "
                "WHERE fts.content MATCH ? "
                "  AND fts.namespace = ? "
                "  AND m.importance >= ? "
                "ORDER BY m.importance DESC, "
                "         m.accessed_at DESC "
                "LIMIT ?",
                (
                    _fts_query(query),
                    self.namespace,
                    min_importance,
                    limit * 2,
                ),
            ).fetchall()
        except Exception:
            rows = self._conn.execute(
                "SELECT * FROM memories "
                "WHERE namespace = ? "
                "  AND content LIKE ? "
                "  AND importance >= ? "
                "ORDER BY importance DESC LIMIT ?",
                (
                    self.namespace,
                    f"%{query}%",
                    min_importance,
                    limit * 2,
                ),
            ).fetchall()

        results = []
        for row in rows:
            d = dict(row)
            d["tags"] = json.loads(d["tags"])
            if tags and not any(t in d["tags"] for t in tags):
                continue
            if source and d["source"] != source:
                continue
            self._conn.execute(
                "UPDATE memories "
                "SET accessed_at = ?, "
                "    access_count = access_count + 1 "
                "WHERE id = ?",
                (time.time(), d["id"]),
            )
            results.append(d)

        self._conn.commit()
        return results[:limit]

    def recall_all(
        self,
        source: Optional[str] = None,
    ) -> list[dict[str, Any]]:
        """Return all memories in this namespace."""
        q = "SELECT * FROM memories WHERE namespace = ?"
        params: list[Any] = [self.namespace]
        if source:
            q += " AND source = ?"
            params.append(source)
        q += " ORDER BY importance DESC, accessed_at DESC"
        result = []
        for row in self._conn.execute(q, params).fetchall():
            d = dict(row)
            d["tags"] = json.loads(d["tags"])
            result.append(d)
        return result

    def forget(self, memory_id: str) -> bool:
        """Delete one memory by ID. Returns True if deleted."""
        cur = self._conn.execute(
            "DELETE FROM memories "
            "WHERE id = ? AND namespace = ?",
            (memory_id, self.namespace),
        )
        self._conn.commit()
        return cur.rowcount > 0

    def forget_all(self) -> int:
        """Delete all memories in namespace. Returns count."""
        cur = self._conn.execute(
            "DELETE FROM memories WHERE namespace = ?",
            (self.namespace,),
        )
        self._conn.commit()
        return cur.rowcount

    def update_importance(
        self, memory_id: str, importance: float
    ) -> bool:
        """Update importance score. Clamped to 0.0–1.0."""
        cur = self._conn.execute(
            "UPDATE memories SET importance = ? "
            "WHERE id = ? AND namespace = ?",
            (
                max(0.0, min(1.0, importance)),
                memory_id,
                self.namespace,
            ),
        )
        self._conn.commit()
        return cur.rowcount > 0

    def stats(self) -> dict[str, Any]:
        """Return memory store statistics."""
        total = self._conn.execute(
            "SELECT COUNT(*) FROM memories WHERE namespace = ?",
            (self.namespace,),
        ).fetchone()[0]

        by_source: dict[str, int] = {}
        for row in self._conn.execute(
            "SELECT source, COUNT(*) as n FROM memories "
            "WHERE namespace = ? GROUP BY source",
            (self.namespace,),
        ).fetchall():
            by_source[row["source"]] = row["n"]

        return {
            "namespace": self.namespace,
            "total_memories": total,
            "by_source": by_source,
            "db_path": str(self.db_path),
            "db_size_kb": round(
                self.db_path.stat().st_size / 1024, 1
            ) if self.db_path.exists() else 0,
        }

    def prune_expired(self, ttl_days: Optional[int] = None) -> int:
        """Delete memories older than ttl_days. Returns count deleted."""
        days = ttl_days if ttl_days is not None else self.default_ttl_days
        if days is None:
            return 0
        cutoff = time.time() - (days * 86400)
        cur = self._conn.execute(
            "DELETE FROM memories "
            "WHERE namespace = ? AND created_at < ?",
            (self.namespace, cutoff),
        )
        self._conn.commit()
        return cur.rowcount

    def decay_importance(self, half_life_days: float = 30.0) -> int:
        """
        Decay importance scores based on last access time.
        importance *= 0.5^(days_since_access / half_life)
        Returns count of memories updated.
        """
        now = time.time()
        rows = self._conn.execute(
            "SELECT id, importance, accessed_at FROM memories "
            "WHERE namespace = ?",
            (self.namespace,),
        ).fetchall()

        updated = 0
        for row in rows:
            days_since = (now - row["accessed_at"]) / 86400.0
            if days_since <= 0:
                continue
            decayed = row["importance"] * math.pow(
                0.5, days_since / half_life_days
            )
            decayed = max(0.0, min(1.0, decayed))
            if abs(decayed - row["importance"]) < 1e-9:
                continue
            self._conn.execute(
                "UPDATE memories SET importance = ? WHERE id = ?",
                (decayed, row["id"]),
            )
            updated += 1

        if updated:
            self._conn.commit()
        return updated

    @staticmethod
    def _relevance_score(query: str, content: str) -> float:
        """Simple TF-IDF proxy: query word matches / content length."""
        query_words = set(
            w.lower() for w in re.sub(r"[^\w\s]", " ", query).split()
            if len(w) > 1
        )
        if not query_words:
            return 0.0
        content_lower = content.lower()
        content_words = re.sub(r"[^\w\s]", " ", content_lower).split()
        if not content_words:
            return 0.0
        matches = sum(1 for w in content_words if w in query_words)
        return matches / len(content_words)

    def as_context(
        self,
        query: str,
        limit: int = 5,
        prefix: str = "Relevant memory context:",
        min_relevance: float = 0.0,
        auto_prune: bool = False,
    ) -> str:
        """
        Search memories and format as prompt context string.

        min_relevance: filter out memories scoring below this threshold.
        auto_prune: run prune_expired() and decay_importance() first.
        """
        if auto_prune:
            self.prune_expired()
            self.decay_importance()

        memories = self.recall(query, limit=limit)

        if min_relevance > 0:
            memories = [
                m for m in memories
                if self._relevance_score(query, m["content"]) >= min_relevance
            ]

        if not memories:
            return ""
        lines = [prefix]
        for m in memories:
            ts = datetime.fromtimestamp(
                m["created_at"]
            ).strftime("%Y-%m-%d")
            tag_str = (
                f" [{', '.join(m['tags'])}]"
                if m["tags"] else ""
            )
            lines.append(
                f"- [{m['source']} | {ts}{tag_str}] "
                f"{m['content']}"
            )
        return "\n".join(lines)

    def smart_context(
        self,
        query: str,
        limit: int = 5,
        min_relevance: float = 0.3,
        ttl_days: int = 30,
        prefix: str = "Relevant memory context:",
    ) -> str:
        """
        The smarter as_context().

        1. Prunes expired memories (older than ttl_days)
        2. Decays importance scores
        3. Searches with FTS5
        4. Filters by relevance score (min_relevance)
        5. Returns only what is actually relevant

        Use this instead of as_context() for production.
        as_context() still works for simple cases.
        """
        self.prune_expired(ttl_days=ttl_days)
        self.decay_importance()
        return self.as_context(
            query,
            limit=limit,
            prefix=prefix,
            min_relevance=min_relevance,
        )

    def close(self) -> None:
        self._conn.close()

    def __enter__(self) -> "MemoryMesh":
        return self

    def __exit__(self, *_: Any) -> None:
        self.close()


# ── Module-level convenience API ─────────────────────────────────
# import memorymesh as mm
# mm.remember(...)  mm.recall(...)  mm.as_context(...)

_default: Optional[MemoryMesh] = None


def _get() -> MemoryMesh:
    global _default
    if _default is None:
        _default = MemoryMesh()
    return _default


def remember(
    content: str,
    tags: Optional[list[str]] = None,
    source: str = "user",
    importance: float = 0.5,
) -> str:
    return _get().remember(content, tags, source, importance)


def recall(
    query: str,
    limit: int = 10,
    tags: Optional[list[str]] = None,
    source: Optional[str] = None,
) -> list[dict[str, Any]]:
    return _get().recall(query, limit, tags, source)


def recall_all(
    source: Optional[str] = None,
) -> list[dict[str, Any]]:
    return _get().recall_all(source)


def as_context(
    query: str,
    limit: int = 5,
    prefix: str = "Relevant memory context:",
) -> str:
    return _get().as_context(query, limit, prefix)


def forget(memory_id: str) -> bool:
    return _get().forget(memory_id)


def forget_all() -> int:
    return _get().forget_all()


def stats() -> dict[str, Any]:
    return _get().stats()


def smart_context(
    query: str,
    limit: int = 5,
    min_relevance: float = 0.3,
    ttl_days: int = 30,
    prefix: str = "Relevant memory context:",
) -> str:
    return _get().smart_context(
        query, limit, min_relevance, ttl_days, prefix
    )
