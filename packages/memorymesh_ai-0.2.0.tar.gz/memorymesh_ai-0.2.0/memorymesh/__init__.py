"""
MemoryMesh — shared memory for AI tools.

    import memorymesh as mm
    mm.remember("user prefers TypeScript")
    mm.recall("typescript")
    mm.as_context("current project")
"""

from memorymesh.core import (
    MemoryMesh,
    as_context,
    forget,
    forget_all,
    recall,
    recall_all,
    remember,
    smart_context,
    stats,
)

__version__ = "0.2.0"
__all__ = [
    "MemoryMesh",
    "remember",
    "recall",
    "recall_all",
    "as_context",
    "smart_context",
    "forget",
    "forget_all",
    "stats",
]
