"""
memorymesh/connectors/claude.py

Claude connector — automatic memory injection.

    from memorymesh.connectors.claude import ClaudeWithMemory
    client = ClaudeWithMemory()
    response = client.chat("What stack should I use?")
    # Memory context injected automatically
"""

from __future__ import annotations

import os
from typing import Any, Optional

from memorymesh.core import MemoryMesh


class ClaudeWithMemory:
    """Claude API wrapper with automatic memory injection."""

    def __init__(
        self,
        api_key: Optional[str] = None,
        model: str = "claude-sonnet-4-20250514",
        memory: Optional[MemoryMesh] = None,
        namespace: str = "default",
        auto_remember: bool = False,
    ) -> None:
        try:
            import anthropic
        except ImportError:
            raise ImportError(
                "anthropic package required. "
                "Install with: pip install memorymesh[claude]"
            )

        self._client = anthropic.Anthropic(
            api_key=api_key or os.environ.get("ANTHROPIC_API_KEY"),
        )
        self.model = model
        self.mm = memory or MemoryMesh(namespace=namespace)
        self.auto_remember = auto_remember

    def chat(
        self,
        message: str,
        system: str = "",
        memory_query: Optional[str] = None,
        remember_response: bool = False,
        max_tokens: int = 1024,
    ) -> str:
        """Send a message to Claude with automatic memory context injection."""
        query = memory_query or message
        context = self.mm.as_context(query)

        system_parts = []
        if system:
            system_parts.append(system)
        if context:
            system_parts.append(context)
        full_system = "\n\n".join(system_parts)

        kwargs: dict[str, Any] = {
            "model": self.model,
            "max_tokens": max_tokens,
            "messages": [{"role": "user", "content": message}],
        }
        if full_system:
            kwargs["system"] = full_system

        response = self._client.messages.create(**kwargs)
        reply = response.content[0].text

        if remember_response or self.auto_remember:
            self.mm.remember(reply, source="claude", importance=0.6)

        return reply

    def remember(
        self,
        content: str,
        tags: Optional[list[str]] = None,
        importance: float = 0.6,
    ) -> str:
        """Store a memory with source='claude'."""
        return self.mm.remember(
            content, tags=tags, source="claude", importance=importance
        )

    def recall(self, query: str, limit: int = 5) -> list[dict[str, Any]]:
        """Search memories."""
        return self.mm.recall(query, limit=limit)

    @property
    def memory(self) -> MemoryMesh:
        return self.mm
