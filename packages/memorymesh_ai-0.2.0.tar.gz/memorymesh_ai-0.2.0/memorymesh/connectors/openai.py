"""
memorymesh/connectors/openai.py

OpenAI connector — automatic memory injection.

    from memorymesh.connectors.openai import OpenAIWithMemory
    client = OpenAIWithMemory()
    response = client.chat("What stack should I use?")
    # Same shared memory as Claude and Ollama

Requires: pip install memorymesh[openai]
"""

from __future__ import annotations

import os
from typing import Any, Optional

from memorymesh.core import MemoryMesh


class OpenAIWithMemory:
    """OpenAI API wrapper with automatic memory injection."""

    def __init__(
        self,
        api_key: Optional[str] = None,
        model: str = "gpt-4o",
        memory: Optional[MemoryMesh] = None,
        namespace: str = "default",
        auto_remember: bool = False,
    ) -> None:
        try:
            import openai
        except ImportError:
            raise ImportError(
                "openai package required. "
                "Install with: pip install memorymesh[openai]"
            )

        self._client = openai.OpenAI(
            api_key=api_key or os.environ.get("OPENAI_API_KEY"),
        )
        self.model = model
        self.mm = memory or MemoryMesh(namespace=namespace)
        self.auto_remember = auto_remember

    def chat(
        self,
        message: str,
        system: str = "",
        memory_query: Optional[str] = None,
        remember_response: bool = False,
        max_tokens: int = 1024,
    ) -> str:
        """Send a message to OpenAI with automatic memory context injection."""
        query = memory_query or message
        context = self.mm.as_context(query)

        system_parts = []
        if system:
            system_parts.append(system)
        if context:
            system_parts.append(context)
        full_system = "\n\n".join(system_parts)

        messages: list[dict[str, str]] = []
        if full_system:
            messages.append({"role": "system", "content": full_system})
        messages.append({"role": "user", "content": message})

        response = self._client.chat.completions.create(
            model=self.model,
            messages=messages,
            max_tokens=max_tokens,
        )
        reply = response.choices[0].message.content or ""

        if remember_response or self.auto_remember:
            self.mm.remember(reply, source="openai", importance=0.6)

        return reply

    def remember(
        self,
        content: str,
        tags: Optional[list[str]] = None,
        importance: float = 0.6,
    ) -> str:
        """Store a memory with source='openai'."""
        return self.mm.remember(
            content, tags=tags, source="openai", importance=importance
        )

    def recall(self, query: str, limit: int = 5) -> list[dict[str, Any]]:
        """Search memories."""
        return self.mm.recall(query, limit=limit)

    @property
    def memory(self) -> MemoryMesh:
        return self.mm
