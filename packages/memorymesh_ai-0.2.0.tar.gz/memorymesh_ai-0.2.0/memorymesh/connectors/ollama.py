"""
memorymesh/connectors/ollama.py

Ollama connector — zero extra dependencies.
Uses stdlib urllib only.

    from memorymesh.connectors.ollama import OllamaWithMemory
    client = OllamaWithMemory(model="llama3.2")
    response = client.chat("Help me with the billing module")
    # Gets same memory Claude wrote. Zero setup.

Requires: ollama serve && ollama pull llama3.2
"""

from __future__ import annotations

import json
import urllib.error
import urllib.request
from typing import Any, Optional

from memorymesh.core import MemoryMesh


class OllamaWithMemory:
    """Ollama wrapper with automatic memory injection. Zero extra dependencies."""

    def __init__(
        self,
        model: str = "llama3.2",
        base_url: str = "http://localhost:11434",
        memory: Optional[MemoryMesh] = None,
        namespace: str = "default",
    ) -> None:
        self.model = model
        self.base_url = base_url.rstrip("/")
        self.mm = memory or MemoryMesh(namespace=namespace)

    def chat(
        self,
        message: str,
        memory_query: Optional[str] = None,
    ) -> str:
        """Send a message to Ollama with automatic memory context injection."""
        query = memory_query or message
        context = self.mm.as_context(query)

        prompt = message
        if context:
            prompt = f"{context}\n\n{message}"

        payload = json.dumps({
            "model": self.model,
            "prompt": prompt,
            "stream": False,
        }).encode()

        req = urllib.request.Request(
            f"{self.base_url}/api/generate",
            data=payload,
            headers={"Content-Type": "application/json"},
        )

        try:
            with urllib.request.urlopen(req, timeout=60) as resp:
                data = json.loads(resp.read().decode())
                return data.get("response", "")
        except urllib.error.URLError as e:
            raise ConnectionError(
                f"Cannot connect to Ollama at {self.base_url}. "
                f"Make sure Ollama is running: ollama serve\n"
                f"Then pull a model: ollama pull {self.model}\n"
                f"Error: {e}"
            )

    def remember(
        self,
        content: str,
        tags: Optional[list[str]] = None,
        importance: float = 0.5,
    ) -> str:
        """Store a memory with source='ollama'."""
        return self.mm.remember(
            content, tags=tags, source="ollama", importance=importance
        )

    def available_models(self) -> list[str]:
        """List available Ollama models."""
        try:
            req = urllib.request.Request(f"{self.base_url}/api/tags")
            with urllib.request.urlopen(req, timeout=5) as resp:
                data = json.loads(resp.read().decode())
                return [m["name"] for m in data.get("models", [])]
        except Exception:
            return []

    @property
    def memory(self) -> MemoryMesh:
        return self.mm
