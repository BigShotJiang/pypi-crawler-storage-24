"""
memorymesh/mcp_server.py

MCP server for MemoryMesh.
Exposes memory tools to Claude Code and any MCP client.
Implements JSON-RPC 2.0 over stdio.

Add to Claude Code settings:
{
  "mcpServers": {
    "memorymesh": {
      "command": "memorymesh",
      "args": ["serve"]
    }
  }
}

Tools exposed:
  remember_memory   store a memory
  recall_memory     search memories
  get_context       get formatted context string
  forget_memory     delete a memory
  memory_stats      show statistics
"""

from __future__ import annotations

import argparse
import json
import sys
from typing import Any, Optional

from memorymesh.core import MemoryMesh

TOOLS = [
    {
        "name": "remember_memory",
        "description": "Store a memory. Returns the memory ID.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "content": {
                    "type": "string",
                    "description": "The memory content to store.",
                },
                "tags": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Optional tags for categorization.",
                },
                "importance": {
                    "type": "number",
                    "description": "Importance score 0.0-1.0. Default 0.5.",
                },
            },
            "required": ["content"],
        },
    },
    {
        "name": "recall_memory",
        "description": "Search memories by keyword query. Use exact keywords, not natural language questions.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "query": {
                    "type": "string",
                    "description": "Search query (keywords work best).",
                },
                "limit": {
                    "type": "integer",
                    "description": "Max results to return. Default 10.",
                },
            },
            "required": ["query"],
        },
    },
    {
        "name": "get_context",
        "description": "Get formatted memory context string for injection into prompts.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "query": {
                    "type": "string",
                    "description": "Search query for relevant memories.",
                },
                "limit": {
                    "type": "integer",
                    "description": "Max memories to include. Default 5.",
                },
            },
            "required": ["query"],
        },
    },
    {
        "name": "forget_memory",
        "description": "Delete a memory by its ID.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "memory_id": {
                    "type": "string",
                    "description": "The ID of the memory to delete.",
                },
            },
            "required": ["memory_id"],
        },
    },
    {
        "name": "memory_stats",
        "description": "Show memory store statistics.",
        "inputSchema": {
            "type": "object",
            "properties": {},
        },
    },
]


class MCPServer:
    """MCP server implementing JSON-RPC 2.0 over stdio."""

    def __init__(self, namespace: str = "default") -> None:
        self.mm = MemoryMesh(namespace=namespace)

    def handle(self, request: dict[str, Any]) -> Optional[dict[str, Any]]:
        """Route an MCP JSON-RPC request and return a response."""
        method = request.get("method", "")
        rid = request.get("id")
        params = request.get("params", {})

        if method == "initialize":
            return self._ok(rid, {
                "protocolVersion": "2024-11-05",
                "capabilities": {
                    "tools": {},
                },
                "serverInfo": {
                    "name": "memorymesh",
                    "version": "0.1.0",
                },
            })

        if method in ("initialized", "notifications/initialized"):
            return None

        if method == "ping":
            return self._ok(rid, {})

        if method == "tools/list":
            return self._ok(rid, {"tools": TOOLS})

        if method == "tools/call":
            tool_name = params.get("name", "")
            tool_args = params.get("arguments", {})
            return self._ok(rid, self._call_tool(tool_name, tool_args))

        return self._error(rid, -32601, f"Method not found: {method}")

    def _call_tool(self, name: str, args: dict[str, Any]) -> dict[str, Any]:
        """Dispatch a tool call and return MCP tool result."""
        try:
            if name == "remember_memory":
                mid = self.mm.remember(
                    content=args["content"],
                    tags=args.get("tags"),
                    source="claude",
                    importance=args.get("importance", 0.5),
                )
                return {
                    "content": [{"type": "text", "text": f"Stored memory: {mid}"}],
                }

            if name == "recall_memory":
                memories = self.mm.recall(
                    query=args["query"],
                    limit=args.get("limit", 10),
                )
                if not memories:
                    text = "No memories found."
                else:
                    lines = []
                    for m in memories:
                        tags = f" [{', '.join(m['tags'])}]" if m["tags"] else ""
                        lines.append(f"[{m['id']}] {m['content']}{tags} (importance: {m['importance']})")
                    text = "\n".join(lines)
                return {"content": [{"type": "text", "text": text}]}

            if name == "get_context":
                ctx = self.mm.as_context(
                    query=args["query"],
                    limit=args.get("limit", 5),
                )
                return {
                    "content": [{"type": "text", "text": ctx or "No relevant memories found."}],
                }

            if name == "forget_memory":
                deleted = self.mm.forget(args["memory_id"])
                msg = "Memory deleted." if deleted else "Memory not found."
                return {"content": [{"type": "text", "text": msg}]}

            if name == "memory_stats":
                s = self.mm.stats()
                return {"content": [{"type": "text", "text": json.dumps(s, indent=2)}]}

            return {
                "content": [{"type": "text", "text": f"Unknown tool: {name}"}],
                "isError": True,
            }
        except Exception as e:
            return {
                "content": [{"type": "text", "text": f"Error: {e}"}],
                "isError": True,
            }

    def _ok(self, rid: Any, result: Any) -> dict[str, Any]:
        return {"jsonrpc": "2.0", "id": rid, "result": result}

    def _error(self, rid: Any, code: int, message: str) -> dict[str, Any]:
        return {"jsonrpc": "2.0", "id": rid, "error": {"code": code, "message": message}}

    def run(self) -> None:
        """Read JSON-RPC requests from stdin, write responses to stdout."""
        sys.stderr.write("memorymesh MCP server started\n")
        sys.stderr.flush()

        for line in sys.stdin:
            line = line.strip()
            if not line:
                continue

            try:
                request = json.loads(line)
            except json.JSONDecodeError:
                resp = self._error(None, -32700, "Parse error")
                sys.stdout.write(json.dumps(resp) + "\n")
                sys.stdout.flush()
                continue

            response = self.handle(request)
            if response is not None:
                sys.stdout.write(json.dumps(response) + "\n")
                sys.stdout.flush()

        sys.stderr.write("memorymesh MCP server stopped\n")
        sys.stderr.flush()


def main() -> None:
    parser = argparse.ArgumentParser(description="MemoryMesh MCP Server")
    parser.add_argument(
        "--namespace",
        default="default",
        help="Memory namespace (default: default)",
    )
    args = parser.parse_args()
    server = MCPServer(namespace=args.namespace)
    server.run()


if __name__ == "__main__":
    main()
