"""
memorymesh/cli.py

CLI for MemoryMesh.

Commands:
  memorymesh serve                   start MCP server
  memorymesh remember "TEXT"         store a memory
  memorymesh recall "QUERY"          search memories
  memorymesh list                    list all memories
  memorymesh stats                   show statistics
  memorymesh forget ID               delete a memory
  memorymesh clear [--yes]           clear all memories
"""

from __future__ import annotations

import argparse
import json
import sys
from datetime import datetime
from typing import Any


def _format_table(memories: list[dict[str, Any]]) -> str:
    """Format memories as a readable table."""
    if not memories:
        return "No memories found."

    lines = []
    lines.append(f"{'ID':<18} {'Source':<10} {'Imp':>5} {'Tags':<20} Content")
    lines.append("-" * 90)
    for m in memories:
        tags = ", ".join(m["tags"]) if m["tags"] else ""
        content = m["content"][:50] + ("..." if len(m["content"]) > 50 else "")
        lines.append(
            f"{m['id']:<18} {m['source']:<10} {m['importance']:>5.2f} "
            f"{tags:<20} {content}"
        )
    return "\n".join(lines)


def cmd_serve(args: argparse.Namespace) -> None:
    from memorymesh.mcp_server import MCPServer

    server = MCPServer(namespace=args.namespace)
    server.run()


def cmd_remember(args: argparse.Namespace) -> None:
    from memorymesh.core import MemoryMesh

    mm = MemoryMesh(namespace=args.namespace)
    tags = args.tags.split(",") if args.tags else None
    mid = mm.remember(
        content=args.text,
        tags=tags,
        source="cli",
        importance=args.importance,
    )
    print(f"Stored: {mid}")
    mm.close()


def cmd_recall(args: argparse.Namespace) -> None:
    from memorymesh.core import MemoryMesh

    mm = MemoryMesh(namespace=args.namespace)
    results = mm.recall(args.query, limit=args.limit)
    if not results:
        print("No memories found.")
    else:
        print(_format_table(results))
    mm.close()


def cmd_list(args: argparse.Namespace) -> None:
    from memorymesh.core import MemoryMesh

    mm = MemoryMesh(namespace=args.namespace)
    results = mm.recall_all()
    if not results:
        print("No memories stored yet.")
    else:
        print(f"Total: {len(results)} memories\n")
        print(_format_table(results))
    mm.close()


def cmd_stats(args: argparse.Namespace) -> None:
    from memorymesh.core import MemoryMesh

    mm = MemoryMesh(namespace=args.namespace)
    s = mm.stats()
    print(f"Namespace:  {s['namespace']}")
    print(f"Memories:   {s['total_memories']}")
    print(f"DB path:    {s['db_path']}")
    print(f"DB size:    {s['db_size_kb']} KB")
    if s["by_source"]:
        print("By source:")
        for src, count in s["by_source"].items():
            print(f"  {src}: {count}")
    mm.close()


def cmd_forget(args: argparse.Namespace) -> None:
    from memorymesh.core import MemoryMesh

    mm = MemoryMesh(namespace=args.namespace)
    if mm.forget(args.id):
        print(f"Deleted: {args.id}")
    else:
        print(f"Not found: {args.id}")
    mm.close()


def cmd_prune(args: argparse.Namespace) -> None:
    from memorymesh.core import MemoryMesh

    mm = MemoryMesh(namespace=args.namespace, default_ttl_days=args.ttl)
    count = mm.prune_expired()
    print(f"Pruned {count} expired memories (TTL: {args.ttl} days).")
    mm.close()


def cmd_decay(args: argparse.Namespace) -> None:
    from memorymesh.core import MemoryMesh

    mm = MemoryMesh(namespace=args.namespace)
    count = mm.decay_importance(half_life_days=args.half_life)
    print(f"Decayed importance on {count} memories (half-life: {args.half_life} days).")
    mm.close()


def cmd_smart_recall(args: argparse.Namespace) -> None:
    from memorymesh.core import MemoryMesh

    mm = MemoryMesh(namespace=args.namespace)
    ctx = mm.smart_context(
        args.query,
        limit=args.limit,
        min_relevance=args.min_relevance,
        ttl_days=args.ttl,
    )
    if ctx:
        print(ctx)
    else:
        print("No relevant memories found.")
    mm.close()


def cmd_clear(args: argparse.Namespace) -> None:
    from memorymesh.core import MemoryMesh

    if not args.yes:
        confirm = input("Delete ALL memories? [y/N] ")
        if confirm.lower() != "y":
            print("Cancelled.")
            return

    mm = MemoryMesh(namespace=args.namespace)
    count = mm.forget_all()
    print(f"Deleted {count} memories.")
    mm.close()


def main() -> None:
    parser = argparse.ArgumentParser(
        prog="memorymesh",
        description="MemoryMesh — shared memory for AI tools",
    )
    parser.add_argument(
        "--namespace", default="default",
        help="Memory namespace (default: default)",
    )
    sub = parser.add_subparsers(dest="command")

    # serve
    sub.add_parser("serve", help="Start MCP server")

    # remember
    p_rem = sub.add_parser("remember", help="Store a memory")
    p_rem.add_argument("text", help="Memory content")
    p_rem.add_argument("--tags", help="Comma-separated tags")
    p_rem.add_argument(
        "--importance", type=float, default=0.5,
        help="Importance 0.0-1.0 (default: 0.5)",
    )

    # recall
    p_rec = sub.add_parser("recall", help="Search memories")
    p_rec.add_argument("query", help="Search query")
    p_rec.add_argument(
        "--limit", type=int, default=10,
        help="Max results (default: 10)",
    )

    # list
    sub.add_parser("list", help="List all memories")

    # stats
    sub.add_parser("stats", help="Show statistics")

    # forget
    p_forget = sub.add_parser("forget", help="Delete a memory")
    p_forget.add_argument("id", help="Memory ID to delete")

    # prune
    p_prune = sub.add_parser("prune", help="Remove expired memories")
    p_prune.add_argument(
        "--ttl", type=int, default=30,
        help="TTL in days (default: 30)",
    )

    # decay
    p_decay = sub.add_parser("decay", help="Apply importance decay")
    p_decay.add_argument(
        "--half-life", type=float, default=30.0,
        help="Half-life in days (default: 30)",
    )

    # smart-recall
    p_smart = sub.add_parser("smart-recall", help="Search with relevance filter")
    p_smart.add_argument("query", help="Search query")
    p_smart.add_argument(
        "--limit", type=int, default=5,
        help="Max results (default: 5)",
    )
    p_smart.add_argument(
        "--min-relevance", type=float, default=0.3,
        help="Minimum relevance score (default: 0.3)",
    )
    p_smart.add_argument(
        "--ttl", type=int, default=30,
        help="TTL in days (default: 30)",
    )

    # clear
    p_clear = sub.add_parser("clear", help="Clear all memories")
    p_clear.add_argument(
        "--yes", action="store_true",
        help="Skip confirmation prompt",
    )

    args = parser.parse_args()

    if args.command is None:
        parser.print_help()
        sys.exit(1)

    dispatch = {
        "serve": cmd_serve,
        "remember": cmd_remember,
        "recall": cmd_recall,
        "list": cmd_list,
        "stats": cmd_stats,
        "forget": cmd_forget,
        "prune": cmd_prune,
        "decay": cmd_decay,
        "smart-recall": cmd_smart_recall,
        "clear": cmd_clear,
    }
    dispatch[args.command](args)


if __name__ == "__main__":
    main()
