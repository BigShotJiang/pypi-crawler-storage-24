# MemoryMesh

> Claude figured it out. Ollama forgot it. MemoryMesh fixes that.

One shared memory for all your AI tools. Local. Private. Zero cloud. Works in 60 seconds.

## Install

```bash
pip install memorymesh
```

## The problem

You spend 5 minutes explaining your stack, your preferences, your project context to Claude. It gets it. Then you switch to Ollama for a quick local task — and it knows nothing. You switch to GPT for a second opinion — nothing. Every tool starts from zero. Every single time.

## The fix — three lines

```python
import memorymesh as mm

mm.remember("user builds in FastAPI + PostgreSQL, hates ORMs")
mm.recall("tech stack")
```

## Claude + Ollama — one shared brain

```python
from memorymesh.connectors.claude import ClaudeWithMemory
from memorymesh.connectors.ollama import OllamaWithMemory

# Claude saves context
claude = ClaudeWithMemory()
claude.remember("Backend is FastAPI, DB is PostgreSQL, no ORMs")
response = claude.chat("How should I structure the billing module?")

# Ollama reads the SAME memory — zero setup
# Requires: ollama serve && ollama pull llama3.2
ollama = OllamaWithMemory(model="llama3.2")
response = ollama.chat("Help me with the billing queries")
# Ollama already knows: FastAPI, PostgreSQL, no ORMs
```

## OpenAI

```python
from memorymesh.connectors.openai import OpenAIWithMemory

gpt = OpenAIWithMemory()
response = gpt.chat("Review my database schema")
# Same shared memory as Claude and Ollama
```

## Claude Code — MCP server

Add to your Claude Code MCP settings:

```json
{
  "mcpServers": {
    "memorymesh": {
      "command": "memorymesh",
      "args": ["serve"]
    }
  }
}
```

Claude gets 5 tools:

- `remember_memory` — store a memory
- `recall_memory` — search memories
- `get_context` — get formatted context string
- `forget_memory` — delete a memory
- `memory_stats` — show statistics

```bash
pip install memorymesh
memorymesh serve
```

## Smart Context (v0.2)

v0.1 `as_context()` returns everything matching the query.
Over time, this causes context bloat.

v0.2 adds `smart_context()` which prunes, decays, and filters:

```python
# Instead of:
ctx = mm.as_context("current project")

# Use:
ctx = mm.smart_context("current project")
# Automatically removes old/irrelevant memories
# Keeps your prompts clean as memory grows

# Configure:
ctx = mm.smart_context(
    "current project",
    min_relevance=0.3,  # filter below 30% relevance
    ttl_days=30,        # forget after 30 days
)
```

## CLI

```bash
memorymesh remember "user prefers dark mode"
memorymesh recall "preferences"
memorymesh smart-recall "preferences"   # relevance-filtered
memorymesh prune                        # remove expired memories
memorymesh decay                        # apply importance decay
memorymesh list
memorymesh stats
memorymesh serve
```

## Why local?

- Data stays at `~/.memorymesh/memory.db` — plain SQLite
- No API keys for core functionality
- Works offline
- Open the DB with any SQLite viewer — it is yours forever

## Limitations

- Relevance scoring is keyword-based, not semantic (semantic search with embeddings planned for v0.3)
- TTL is based on creation date, not last meaningful use
- Decay requires manual call or `auto_prune=True`
- FTS5 is keyword search, not semantic — `recall("FastAPI")` works, `recall("what framework?")` does not
- No sync across machines (by design — your data stays on your machine)
- Ollama connector requires `ollama serve` running locally

## Roadmap

- [x] Core: remember / recall / as_context
- [x] Connectors: Claude / Ollama / OpenAI
- [x] MCP server (Claude Code integration)
- [x] CLI
- [ ] Semantic search with local embeddings
- [ ] Auto-learn from conversation history
- [ ] LangChain / LlamaIndex connectors

MIT - [github.com/originaonxi/memorymesh](https://github.com/originaonxi/memorymesh)
