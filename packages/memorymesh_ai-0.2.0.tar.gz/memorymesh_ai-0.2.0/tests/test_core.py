"""Tests for memorymesh core."""

import math
import os
import time

import pytest

from memorymesh.core import MemoryMesh


@pytest.fixture
def mm(tmp_path):
    """Create a fresh MemoryMesh instance with temp DB."""
    db = str(tmp_path / "test.db")
    m = MemoryMesh(db_path=db)
    yield m
    m.close()


def test_remember_returns_16char_id(mm):
    mid = mm.remember("hello world")
    assert isinstance(mid, str)
    assert len(mid) == 16


def test_recall_finds_exact_content(mm):
    mm.remember("FastAPI is the best framework")
    results = mm.recall("FastAPI")
    assert len(results) >= 1
    assert "FastAPI" in results[0]["content"]


def test_recall_returns_empty_list_on_miss(mm):
    mm.remember("something about Python")
    results = mm.recall("xyznonexistent")
    assert results == []


def test_forget_deletes_and_returns_true(mm):
    mid = mm.remember("temporary memory")
    assert mm.forget(mid) is True
    results = mm.recall("temporary")
    assert results == []


def test_forget_missing_returns_false(mm):
    assert mm.forget("nonexistent_id_12") is False


def test_forget_all_returns_count(mm):
    mm.remember("one")
    mm.remember("two")
    mm.remember("three")
    count = mm.forget_all()
    assert count == 3


def test_as_context_starts_with_prefix(mm):
    mm.remember("Python is great")
    ctx = mm.as_context("Python", prefix="Context:")
    assert ctx.startswith("Context:")


def test_as_context_empty_on_no_match(mm):
    mm.remember("something about Java")
    ctx = mm.as_context("xyznonexistent")
    assert ctx == ""


def test_namespace_isolation(tmp_path):
    db = str(tmp_path / "ns.db")
    mm1 = MemoryMesh(db_path=db, namespace="ns1")
    mm2 = MemoryMesh(db_path=db, namespace="ns2")

    mm1.remember("only in namespace one")
    assert len(mm1.recall("namespace")) >= 1
    assert len(mm2.recall("namespace")) == 0

    mm1.close()
    mm2.close()


def test_stats_total_and_by_source(mm):
    mm.remember("a", source="claude")
    mm.remember("b", source="claude")
    mm.remember("c", source="ollama")
    s = mm.stats()
    assert s["total_memories"] == 3
    assert s["by_source"]["claude"] == 2
    assert s["by_source"]["ollama"] == 1


def test_importance_ranking(mm):
    mm.remember("low importance", importance=0.1)
    mm.remember("high importance", importance=0.9)
    results = mm.recall("importance")
    assert len(results) == 2
    assert results[0]["importance"] >= results[1]["importance"]


def test_tags_filter(mm):
    mm.remember("tagged memory", tags=["python", "web"])
    mm.remember("other memory", tags=["rust"])
    results = mm.recall("memory", tags=["python"])
    assert len(results) == 1
    assert "python" in results[0]["tags"]


def test_context_manager(tmp_path):
    db = str(tmp_path / "ctx.db")
    with MemoryMesh(db_path=db) as mm:
        mid = mm.remember("context manager test")
        assert len(mid) == 16


def test_module_level_api(tmp_path):
    """Test module-level convenience functions."""
    import memorymesh.core as core

    db = str(tmp_path / "module.db")
    core._default = MemoryMesh(db_path=db)
    try:
        mid = core.remember("module level test")
        assert len(mid) == 16
        results = core.recall("module")
        assert len(results) >= 1
        s = core.stats()
        assert s["total_memories"] >= 1
        core.forget(mid)
        assert core.recall("module") == []
    finally:
        core._default.close()
        core._default = None


def test_collision_safe_ids(mm):
    """Rapid inserts must produce unique IDs."""
    ids = set()
    for i in range(100):
        mid = mm.remember(f"collision test {i}")
        ids.add(mid)
    assert len(ids) == 100


def test_update_importance(mm):
    mid = mm.remember("updatable", importance=0.3)
    assert mm.update_importance(mid, 0.9) is True
    results = mm.recall("updatable")
    assert results[0]["importance"] == pytest.approx(0.9)

    # Clamping
    mm.update_importance(mid, 1.5)
    results = mm.recall("updatable")
    assert results[0]["importance"] == pytest.approx(1.0)

    # Non-existent
    assert mm.update_importance("nonexistent_00000", 0.5) is False


def test_prune_expired_removes_old_memories(tmp_path):
    db = str(tmp_path / "prune.db")
    mm = MemoryMesh(db_path=db, default_ttl_days=7)

    # Insert a memory and backdate it to 10 days ago
    mid = mm.remember("old memory about pruning")
    old_time = time.time() - (10 * 86400)
    mm._conn.execute(
        "UPDATE memories SET created_at = ? WHERE id = ?",
        (old_time, mid),
    )
    mm._conn.commit()

    # Insert a fresh memory
    mm.remember("fresh memory about pruning")

    count = mm.prune_expired()
    assert count == 1
    remaining = mm.recall_all()
    assert len(remaining) == 1
    assert "fresh" in remaining[0]["content"]
    mm.close()


def test_decay_reduces_importance(tmp_path):
    db = str(tmp_path / "decay.db")
    mm = MemoryMesh(db_path=db)

    mid = mm.remember("decaying memory", importance=0.8)

    # Backdate accessed_at to 30 days ago (one half-life)
    old_time = time.time() - (30 * 86400)
    mm._conn.execute(
        "UPDATE memories SET accessed_at = ? WHERE id = ?",
        (old_time, mid),
    )
    mm._conn.commit()

    updated = mm.decay_importance(half_life_days=30.0)
    assert updated == 1

    results = mm.recall("decaying")
    # After one half-life, importance should be ~0.4
    assert results[0]["importance"] == pytest.approx(0.4, abs=0.05)
    mm.close()


def test_smart_context_filters_irrelevant(tmp_path):
    db = str(tmp_path / "smart.db")
    mm = MemoryMesh(db_path=db)

    mm.remember("FastAPI backend with async endpoints", tags=["backend"])
    mm.remember("PostgreSQL database with raw SQL", tags=["database"])
    mm.remember("React frontend with TypeScript", tags=["frontend"])

    # smart_context for "FastAPI backend" should filter out unrelated
    ctx = mm.smart_context("FastAPI backend", min_relevance=0.3)
    assert "FastAPI" in ctx
    # React/TypeScript shouldn't match "FastAPI backend" at high relevance
    # (may or may not appear depending on scoring — key is filtering works)
    mm.close()


def test_smart_context_respects_ttl(tmp_path):
    db = str(tmp_path / "ttl.db")
    mm = MemoryMesh(db_path=db)

    mid = mm.remember("ancient memory about Python")
    # Backdate to 60 days ago
    old_time = time.time() - (60 * 86400)
    mm._conn.execute(
        "UPDATE memories SET created_at = ? WHERE id = ?",
        (old_time, mid),
    )
    mm._conn.commit()

    mm.remember("recent memory about Python")

    ctx = mm.smart_context("Python", ttl_days=30, min_relevance=0.1)
    assert "recent" in ctx
    assert "ancient" not in ctx
    mm.close()


def test_min_relevance_filters_low_scores(tmp_path):
    db = str(tmp_path / "relevance.db")
    mm = MemoryMesh(db_path=db)

    mm.remember("FastAPI is the best backend framework for Python APIs")
    mm.remember("User likes dark mode and large fonts")

    # With high min_relevance, only closely matching content passes
    ctx = mm.as_context(
        "FastAPI Python backend",
        min_relevance=0.3,
    )
    if ctx:
        assert "FastAPI" in ctx
        assert "dark mode" not in ctx
    mm.close()
