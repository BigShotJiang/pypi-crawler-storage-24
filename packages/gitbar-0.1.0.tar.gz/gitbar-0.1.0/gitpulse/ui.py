"""Native macOS UI helpers using PyObjC — replaces rumps."""

import subprocess
from typing import Optional

from AppKit import (
    NSAlert,
    NSAlertFirstButtonReturn,
    NSTextField,
    NSSecureTextField,
    NSApplication,
)
from Foundation import NSMakeRect


def alert(title: str, message: str, ok: str = "OK", cancel: Optional[str] = None) -> int:
    """Show a modal alert. Returns 1 if OK clicked, 0 if Cancel."""
    app = NSApplication.sharedApplication()
    app.activateIgnoringOtherApps_(True)

    a = NSAlert.alloc().init()
    a.setMessageText_(title)
    a.setInformativeText_(message)
    a.addButtonWithTitle_(ok)
    if cancel:
        a.addButtonWithTitle_(cancel)
    result = a.runModal()
    return 1 if result == NSAlertFirstButtonReturn else 0


def prompt(title: str, message: str, ok: str = "OK", cancel: str = "Cancel",
           default_text: str = "", secure: bool = False) -> Optional[str]:
    """Show a text input dialog. Returns text or None if cancelled."""
    app = NSApplication.sharedApplication()
    app.activateIgnoringOtherApps_(True)

    a = NSAlert.alloc().init()
    a.setMessageText_(title)
    a.setInformativeText_(message)
    a.addButtonWithTitle_(ok)
    a.addButtonWithTitle_(cancel)

    if secure:
        field = NSSecureTextField.alloc().initWithFrame_(NSMakeRect(0, 0, 320, 24))
    else:
        field = NSTextField.alloc().initWithFrame_(NSMakeRect(0, 0, 320, 24))
    field.setStringValue_(default_text)
    field.setEditable_(True)
    field.setSelectable_(True)
    field.setBezeled_(True)
    a.setAccessoryView_(field)
    a.window().setInitialFirstResponder_(field)

    result = a.runModal()
    if result == NSAlertFirstButtonReturn:
        text = field.stringValue()
        if text and text.strip():
            return text.strip()
    return None


def notify(title: str, subtitle: str = "", message: str = "", sound: bool = True):
    """Send a macOS notification via osascript (reliable across all macOS versions)."""
    # Build AppleScript — most reliable notification method
    parts = [f'display notification "{_escape(message)}"']
    parts.append(f'with title "{_escape(title)}"')
    if subtitle:
        parts.append(f'subtitle "{_escape(subtitle)}"')
    if sound:
        parts.append('sound name "default"')
    script = " ".join(parts)
    try:
        subprocess.Popen(
            ["osascript", "-e", script],
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
        )
    except Exception:
        pass


def _escape(s: str) -> str:
    """Escape string for AppleScript."""
    return s.replace("\\", "\\\\").replace('"', '\\"')
