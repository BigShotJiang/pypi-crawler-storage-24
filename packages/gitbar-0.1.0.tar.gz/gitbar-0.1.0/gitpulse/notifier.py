from gitpulse.config import NotifyConfig
from gitpulse.models import Activity, PullRequest
from gitpulse.state import StateStore
from gitpulse.ui import notify


class Notifier:
    def __init__(self, state_store: StateStore, notify_config: NotifyConfig, sound: bool = True):
        self.state = state_store
        self.config = notify_config
        self.sound = sound

    def maybe_notify_activity(self, activity: Activity):
        if self.state.has_seen(activity.id):
            return
        self.state.mark_seen(activity.id)

        config_map = {
            "pr_opened": "new_pr",
            "pr_merged": "pr_merged",
            "review_requested": "review_requested",
            "ci_failed": "ci_failure",
        }
        config_key = config_map.get(activity.event_type)
        if config_key and not getattr(self.config, config_key, True):
            return

        title_map = {
            "pr_opened": "New PR",
            "review_requested": "Review Requested",
            "ci_failed": "CI Failed",
            "pr_merged": "PR Merged",
            "push": "Push",
        }

        notify(
            title=title_map.get(activity.event_type, "GitPulse"),
            subtitle=activity.repo_slug,
            message=activity.title[:100],
            sound=self.sound,
        )

    def maybe_notify_new_pr(self, pr: PullRequest):
        event_id = f"new_pr:{pr.id}"
        if self.state.has_seen(event_id):
            return
        self.state.mark_seen(event_id)

        if pr.is_review_requested:
            if not self.config.review_requested:
                return
            title = "Review Requested"
        else:
            if not self.config.new_pr:
                return
            title = "New Pull Request"

        subtitle = pr.repo_slug
        if pr.is_review_requested:
            subtitle += " (your review)"

        notify(
            title=title,
            subtitle=subtitle,
            message=f"#{pr.number}: {pr.title} by {pr.author}",
            sound=self.sound,
        )
