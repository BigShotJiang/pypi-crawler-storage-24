import logging
import subprocess
import threading
import webbrowser
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, List, Optional

import objc
from AppKit import (
    NSApplication,
    NSAttributedString,
    NSColor,
    NSFont,
    NSFontAttributeName,
    NSForegroundColorAttributeName,
    NSImage,
    NSMenu,
    NSMenuItem,
    NSObject,
    NSStatusBar,
    NSTimer,
    NSVariableStatusItemLength,
)
from Foundation import NSDictionary, NSMakeRect, NSRunLoop, NSDefaultRunLoopMode

from gitpulse.auth import (
    bitbucket_discover_repos,
    github_auth_gh_cli,
    github_discover_repos,
    gitlab_discover_repos,
    keychain_store,
    validate_bitbucket,
    validate_github_token,
    validate_gitlab_token,
)
from gitpulse.config import (
    Config,
    ProviderConfig,
    add_provider,
    load_config,
    save_config,
)
from gitpulse.localrepo import LocalRepoChecker
from gitpulse.models import (
    CIRun,
    CIStatus,
    Issue,
    LocalRepoStatus,
    Notification,
    PollResult,
    PullRequest,
    PRState,
)
from gitpulse.notifier import Notifier
from gitpulse.poller import Poller
from gitpulse.providers.base import BaseProvider
from gitpulse.providers.bitbucket import BitbucketProvider
from gitpulse.providers.github import GitHubProvider
from gitpulse.providers.gitlab import GitLabProvider
from gitpulse.state import StateStore
from gitpulse.ui import alert, prompt, notify

logger = logging.getLogger(__name__)


# ─── Styled text helpers ───

def _bold(text, size=13):
    font = NSFont.boldSystemFontOfSize_(size)
    attrs = NSDictionary.dictionaryWithObjects_forKeys_(
        [font], [NSFontAttributeName]
    )
    return NSAttributedString.alloc().initWithString_attributes_(text, attrs)


def _styled(text, size=12, color=None, font_name=None):
    font = NSFont.systemFontOfSize_(size) if not font_name else NSFont.fontWithName_size_(font_name, size)
    keys = [NSFontAttributeName]
    vals = [font]
    if color:
        keys.append(NSForegroundColorAttributeName)
        vals.append(color)
    attrs = NSDictionary.dictionaryWithObjects_forKeys_(vals, keys)
    return NSAttributedString.alloc().initWithString_attributes_(text, attrs)


def _mono(text, size=11):
    font = NSFont.monospacedSystemFontOfSize_weight_(size, 0.0)
    attrs = NSDictionary.dictionaryWithObjects_forKeys_(
        [font], [NSFontAttributeName]
    )
    return NSAttributedString.alloc().initWithString_attributes_(text, attrs)


def _dimmed(text, size=11):
    return _styled(text, size=size, color=NSColor.secondaryLabelColor())


class GitPulseDelegate(NSObject):
    """macOS menubar app using native PyObjC."""

    def init(self):
        self = objc.super(GitPulseDelegate, self).init()
        if self is None:
            return None
        self.config = load_config()
        self.state_store = StateStore()
        self.notifier = Notifier(self.state_store, self.config.notify, self.config.notification_sound)
        self.local_checker = LocalRepoChecker(self.config.local_repos)

        self._current_prs: List[PullRequest] = []
        self._current_issues: List[Issue] = []
        self._current_ci_runs: List[CIRun] = []
        self._current_notifications: List[Notification] = []
        self._local_statuses: List[LocalRepoStatus] = []
        self._errors: Dict[str, List[str]] = {}
        self._rate_remaining: Dict[str, Optional[int]] = {}
        self._last_poll_time: Optional[datetime] = None
        self._lock = threading.Lock()
        self._gh_cli_token = None
        return self

    def applicationDidFinishLaunching_(self, notification):
        self.status_item = NSStatusBar.systemStatusBar().statusItemWithLength_(
            NSVariableStatusItemLength
        )
        self.status_item.setTitle_("  GP  ")
        self.status_item.setHighlightMode_(True)

        menu = NSMenu.alloc().init()
        menu.setDelegate_(self)
        menu.setMinimumWidth_(340)
        self.status_item.setMenu_(menu)

        self.providers = self._init_providers()
        self.poller = Poller(self.providers, self.config, self.state_store, self._handle_results)

        threading.Thread(target=self._detect_gh_cli, daemon=True).start()

        if self.providers or self.config.local_repos:
            self._start_polling()

    # ─── Menu building ───

    def menuNeedsUpdate_(self, menu):
        menu.removeAllItems()

        with self._lock:
            prs = list(self._current_prs)
            local = list(self._local_statuses)
            issues = list(self._current_issues)
            ci_runs = list(self._current_ci_runs)
            notifications = list(self._current_notifications)

        has_data = prs or issues or ci_runs or notifications

        # ── App header ──
        header = NSMenuItem.alloc().initWithTitle_action_keyEquivalent_("", None, "")
        header.setAttributedTitle_(_bold("  GitPulse", 14))
        header.setEnabled_(False)
        menu.addItem_(header)
        menu.addItem_(NSMenuItem.separatorItem())

        # ── Review Requested ──
        review_prs = [pr for pr in prs if pr.is_review_requested]
        if review_prs:
            self._section_header(menu, f"  \U0001F440  NEEDS YOUR REVIEW  ({len(review_prs)})")
            for pr in review_prs[:8]:
                self._pr_row(menu, pr)
            menu.addItem_(NSMenuItem.separatorItem())

        # ── Open PRs ──
        other_prs = [pr for pr in prs if not pr.is_review_requested]
        if other_prs:
            self._section_header(menu, f"  \U0001F501  OPEN PULL REQUESTS  ({len(other_prs)})")
            for pr in other_prs[:15]:
                self._pr_row(menu, pr)
            if len(other_prs) > 15:
                self._dimmed_row(menu, f"    + {len(other_prs) - 15} more")
            menu.addItem_(NSMenuItem.separatorItem())
        elif self.providers and not review_prs:
            self._section_header(menu, "  \U0001F501  PULL REQUESTS")
            self._dimmed_row(menu, "    No open PRs \u2014 all clear!")
            menu.addItem_(NSMenuItem.separatorItem())

        # ── My Issues ──
        if issues:
            self._section_header(menu, f"  \U0001F4CB  MY ISSUES  ({len(issues)})")
            for iss in issues[:8]:
                repo = iss.repo_slug.split("/")[-1]
                label_str = ""
                if iss.labels:
                    label_str = f"  \u2022 {', '.join(iss.labels[:2])}"
                self._clickable_row(menu, f"    #{iss.number}  {iss.title[:38]}{label_str}", repo, iss.url)
            if len(issues) > 8:
                self._dimmed_row(menu, f"    + {len(issues) - 8} more")
            menu.addItem_(NSMenuItem.separatorItem())

        # ── CI Failures ──
        if ci_runs:
            self._section_header(menu, f"  \u274C  CI FAILURES  ({len(ci_runs)})")
            for run in ci_runs[:5]:
                repo = run.repo_slug.split("/")[-1]
                self._clickable_row(
                    menu,
                    f"    \u25CF  {run.name[:28]}  \u2192  {run.branch}",
                    repo,
                    run.url,
                    color=NSColor.systemRedColor(),
                )
            menu.addItem_(NSMenuItem.separatorItem())

        # ── Local Repos ──
        if local:
            self._section_header(menu, "  \U0001F4BB  LOCAL REPOS")
            for s in local:
                if s.error:
                    self._dimmed_row(menu, f"    \u26A0  {self._short_path(s.path)}")
                    continue
                indicators = []
                if s.is_dirty:
                    indicators.append("\u25CF modified")
                if s.ahead:
                    indicators.append(f"\u2191{s.ahead}")
                if s.behind:
                    indicators.append(f"\u2193{s.behind}")
                status_str = "  \u2022  ".join(indicators) if indicators else "\u2713 clean"
                name = Path(s.path).name
                self._local_repo_row(menu, name, s.branch, status_str)
            menu.addItem_(NSMenuItem.separatorItem())

        # ── Errors ──
        if self._errors:
            for provider, errs in self._errors.items():
                for e in errs[:2]:
                    self._dimmed_row(menu, f"  \u26A0  {provider}: {e[:50]}")
            menu.addItem_(NSMenuItem.separatorItem())

        # ── Accounts ──
        self._section_header(menu, "  \U0001F513  ACCOUNTS")
        for name, label in [("github", "GitHub"), ("gitlab", "GitLab"), ("bitbucket", "Bitbucket")]:
            if name in self.config.providers:
                item = NSMenuItem.alloc().initWithTitle_action_keyEquivalent_("", None, "")
                item.setAttributedTitle_(_styled(f"    \u2705  {label} connected", 12))
                item.setEnabled_(False)
                menu.addItem_(item)
            else:
                action_map = {"github": "onConnectGitHub:", "gitlab": "onConnectGitLab:", "bitbucket": "onConnectBitbucket:"}
                item = NSMenuItem.alloc().initWithTitle_action_keyEquivalent_(
                    f"    Connect {label}...", action_map[name], ""
                )
                item.setTarget_(self)
                menu.addItem_(item)

        menu.addItem_(NSMenuItem.separatorItem())

        # ── Footer ──
        if self._last_poll_time:
            ago = int((datetime.now(timezone.utc) - self._last_poll_time).total_seconds())
            time_str = f"{ago}s ago" if ago < 60 else f"{ago // 60}m ago"
            self._dimmed_row(menu, f"  Updated {time_str}")

        self._action_row(menu, "  \u21BB  Refresh Now", "onRefresh:", "r")
        self._action_row(menu, "  \u2699  Open Config", "onOpenConfig:", ",")
        menu.addItem_(NSMenuItem.separatorItem())
        self._action_row(menu, "  Quit GitPulse", "onQuit:", "q")

    # ─── Menu item builders ───

    def _section_header(self, menu, text):
        item = NSMenuItem.alloc().initWithTitle_action_keyEquivalent_("", None, "")
        item.setAttributedTitle_(_bold(text, 11))
        item.setEnabled_(False)
        menu.addItem_(item)

    def _dimmed_row(self, menu, text):
        item = NSMenuItem.alloc().initWithTitle_action_keyEquivalent_("", None, "")
        item.setAttributedTitle_(_dimmed(text))
        item.setEnabled_(False)
        menu.addItem_(item)

    def _clickable_row(self, menu, text, subtitle="", url="", color=None):
        display = f"{text}  {subtitle}" if subtitle else text
        item = NSMenuItem.alloc().initWithTitle_action_keyEquivalent_(
            display, "onURLClick:", ""
        )
        if color:
            item.setAttributedTitle_(_styled(display, 12, color=color))
        item.setTarget_(self)
        item.setRepresentedObject_(url)
        menu.addItem_(item)

    def _pr_row(self, menu, pr: PullRequest):
        ci_map = {
            CIStatus.PASSING: "\u2705",
            CIStatus.FAILING: "\u274C",
            CIStatus.PENDING: "\u23F3",
            CIStatus.UNKNOWN: "\u2022",
        }
        ci = ci_map.get(pr.ci_status, "\u2022")
        draft = "\U0001F4DD " if pr.draft else ""
        repo = pr.repo_slug.split("/")[-1]
        title = f"    {ci}  {draft}#{pr.number}  {pr.title[:38]}"
        subtitle = f"{pr.author} \u2022 {repo}"
        display = f"{title}   {subtitle}"

        item = NSMenuItem.alloc().initWithTitle_action_keyEquivalent_(
            display, "onPRClick:", ""
        )
        item.setTarget_(self)
        item.setRepresentedObject_(pr.url)
        menu.addItem_(item)

    def _local_repo_row(self, menu, name, branch, status_str):
        display = f"    {name}  [{branch}]  {status_str}"
        item = NSMenuItem.alloc().initWithTitle_action_keyEquivalent_("", None, "")
        item.setAttributedTitle_(_mono(display))
        item.setEnabled_(False)
        menu.addItem_(item)

    def _action_row(self, menu, title, action, key=""):
        item = NSMenuItem.alloc().initWithTitle_action_keyEquivalent_(
            title, action, key
        )
        item.setTarget_(self)
        menu.addItem_(item)

    def _short_path(self, path: str) -> str:
        home = str(Path.home())
        if path.startswith(home):
            return "~" + path[len(home):]
        return path

    # ─── Menu actions ───

    def onPRClick_(self, sender):
        url = sender.representedObject()
        if url:
            webbrowser.open(url)

    def onURLClick_(self, sender):
        url = sender.representedObject()
        if url:
            webbrowser.open(url)

    def onConnectGitHub_(self, sender):
        if self._gh_cli_token:
            token, username = self._gh_cli_token
            resp = alert(
                "GitHub CLI Detected",
                f"Found GitHub CLI logged in as '{username}'.\nUse this account?",
                ok="Yes, Connect", cancel="Enter Token Manually",
            )
            if resp == 1:
                notify("GitPulse", "GitHub", f"Connecting as {username}...")
                threading.Thread(target=self._github_bg, args=(token, username), daemon=True).start()
                return

        resp = alert(
            "Connect GitHub",
            "GitPulse needs a Personal Access Token.\n\nClick OK to open GitHub.\nSelect 'repo' scope, then copy the token.",
            ok="Open GitHub", cancel="Cancel",
        )
        if resp != 1:
            return

        webbrowser.open("https://github.com/settings/tokens/new?scopes=repo&description=GitPulse")

        token = prompt(
            "GitPulse \u2014 GitHub Token",
            "Paste your GitHub token here:",
            ok="Connect", cancel="Cancel",
        )
        if not token:
            return

        notify("GitPulse", "GitHub", "Validating token...")
        threading.Thread(target=self._github_bg, args=(token, None), daemon=True).start()

    def onConnectGitLab_(self, sender):
        resp = alert(
            "Connect GitLab",
            "GitPulse needs a PAT with read_api scope.\n\nClick OK to open GitLab.",
            ok="Open GitLab", cancel="Cancel",
        )
        if resp != 1:
            return

        webbrowser.open("https://gitlab.com/-/user_settings/personal_access_tokens?name=GitPulse&scopes=read_api")

        token = prompt(
            "GitPulse \u2014 GitLab Token",
            "Paste your GitLab token here:",
            ok="Connect", cancel="Cancel",
        )
        if not token:
            return

        notify("GitPulse", "GitLab", "Validating token...")
        threading.Thread(target=self._gitlab_bg, args=(token,), daemon=True).start()

    def onConnectBitbucket_(self, sender):
        resp = alert(
            "Connect Bitbucket",
            "GitPulse needs an App Password.\n\nClick OK to open Bitbucket.\nGrant: Repositories (Read), Pull Requests (Read).",
            ok="Open Bitbucket", cancel="Cancel",
        )
        if resp != 1:
            return

        webbrowser.open("https://bitbucket.org/account/settings/app-passwords/")

        username = prompt("Bitbucket", "Bitbucket username:", ok="Next", cancel="Cancel")
        if not username:
            return

        app_pw = prompt("Bitbucket", "Bitbucket App Password:", ok="Connect", cancel="Cancel")
        if not app_pw:
            return

        notify("GitPulse", "Bitbucket", "Validating...")
        threading.Thread(target=self._bb_bg, args=(username, app_pw), daemon=True).start()

    def onRefresh_(self, sender):
        notify("GitPulse", "", "Refreshing...")
        threading.Thread(target=self._do_poll, daemon=True).start()

    def onOpenConfig_(self, sender):
        if not self.config.config_path.exists():
            save_config(self.config)
        subprocess.Popen(["open", str(self.config.config_path)])

    def onQuit_(self, sender):
        self.state_store.flush()
        self.poller.shutdown()
        NSApplication.sharedApplication().terminate_(self)

    # ─── Startup background tasks ───

    def _detect_gh_cli(self):
        try:
            result = github_auth_gh_cli()
            if result:
                self._gh_cli_token = result
        except Exception:
            pass

    # ─── Background work ───

    def _github_bg(self, token, username=None):
        if not username:
            username = validate_github_token(token)
            if not username:
                notify("GitPulse", "GitHub", "Invalid token. Please try again.")
                return

        repos = github_discover_repos(token)
        keychain_store("github", username, token)
        add_provider(self.config, "github", "keychain", repos)
        self._reinit_providers()
        self._update_title()
        notify("GitPulse", "GitHub Connected", f"Logged in as {username}. Monitoring {len(repos)} repos.")

    def _gitlab_bg(self, token):
        username = validate_gitlab_token(token)
        if not username:
            notify("GitPulse", "GitLab", "Invalid token. Please try again.")
            return

        repos = gitlab_discover_repos(token)
        keychain_store("gitlab", username, token)
        add_provider(self.config, "gitlab", "keychain", repos)
        self._reinit_providers()
        self._update_title()
        notify("GitPulse", "GitLab Connected", f"Logged in as {username}. Monitoring {len(repos)} repos.")

    def _bb_bg(self, username, app_pw):
        if not validate_bitbucket(username, app_pw):
            notify("GitPulse", "Bitbucket", "Invalid credentials.")
            return

        repos = bitbucket_discover_repos(username, app_pw)
        keychain_store("bitbucket", username, app_pw)
        add_provider(self.config, "bitbucket", "keychain", repos, username=username)
        self._reinit_providers()
        self._update_title()
        notify("GitPulse", "Bitbucket Connected", f"Logged in as {username}. Monitoring {len(repos)} repos.")

    # ─── Polling ───

    def _start_polling(self):
        if not hasattr(self, '_poll_timer_ref'):
            interval = self.config.poll_interval
            self._poll_timer_ref = NSTimer.scheduledTimerWithTimeInterval_target_selector_userInfo_repeats_(
                interval, self, "onPollTimer:", None, True
            )
        threading.Thread(target=self._do_poll, daemon=True).start()

    def onPollTimer_(self, timer):
        threading.Thread(target=self._do_poll, daemon=True).start()

    def _init_providers(self) -> Dict[str, BaseProvider]:
        providers = {}
        for name, pconf in self.config.providers.items():
            try:
                provider = self._create_provider(name, pconf)
                provider.init_repos()
                providers[name] = provider
            except Exception as e:
                logger.error(f"Failed to init {name}: {e}")
                self._errors[name] = [f"Init: {e}"]
        return providers

    def _create_provider(self, name: str, pconf: ProviderConfig) -> BaseProvider:
        if name == "github":
            return GitHubProvider(token=pconf.token, api_url=pconf.api_url, repos=pconf.repos)
        elif name == "gitlab":
            return GitLabProvider(token=pconf.token, api_url=pconf.api_url, repos=pconf.repos)
        elif name == "bitbucket":
            return BitbucketProvider(token=pconf.token, api_url=pconf.api_url, repos=pconf.repos, username=pconf.username)
        raise ValueError(f"Unknown provider: {name}")

    def _do_poll(self):
        if self.providers:
            try:
                self.poller.poll_once()
            except Exception as e:
                logger.error(f"Poll error: {e}")

        try:
            statuses = self.local_checker.check_all()
            with self._lock:
                self._local_statuses = statuses
        except Exception as e:
            logger.error(f"Local check error: {e}")

        self._last_poll_time = datetime.now(timezone.utc)
        self._update_title()

    def _handle_results(self, results: List[PollResult]):
        with self._lock:
            old_ids = {pr.id for pr in self._current_prs}
            all_prs, all_issues, all_ci, all_notifs = [], [], [], []
            for result in results:
                all_prs.extend(result.pull_requests)
                all_issues.extend(result.issues)
                all_ci.extend(result.ci_runs)
                all_notifs.extend(result.notifications)
                self._rate_remaining[result.provider.value] = result.rate_remaining
                if result.errors:
                    self._errors[result.provider.value] = result.errors
                for activity in result.activities:
                    self.notifier.maybe_notify_activity(activity)
            new_prs = [pr for pr in all_prs if pr.id not in old_ids]
            for pr in new_prs:
                self.notifier.maybe_notify_new_pr(pr)
            self._current_prs = all_prs
            self._current_issues = all_issues
            self._current_ci_runs = all_ci
            self._current_notifications = all_notifs
        self._update_title()

    def _update_title(self):
        with self._lock:
            n_prs = len(self._current_prs)
            n_review = sum(1 for pr in self._current_prs if pr.is_review_requested)
            n_notifs = sum(1 for n in self._current_notifications if n.unread)
            n_ci_fail = len(self._current_ci_runs)

        # Compact badge in menubar
        badges = []
        if n_review:
            badges.append(f"{n_review}\u2757")
        if n_ci_fail:
            badges.append(f"{n_ci_fail}\u2716")
        if n_notifs:
            badges.append(f"{n_notifs}")

        if badges:
            self.status_item.setTitle_(f"  GP  {' \u2022 '.join(badges)}  ")
        else:
            self.status_item.setTitle_("  GP  ")

    def _reinit_providers(self):
        self.providers = self._init_providers()
        self.poller = Poller(self.providers, self.config, self.state_store, self._handle_results)
        self._start_polling()


def run_app(config: Optional[Config] = None):
    app = NSApplication.sharedApplication()
    delegate = GitPulseDelegate.alloc().init()
    if config:
        delegate.config = config
    app.setDelegate_(delegate)
    app.setActivationPolicy_(1)  # NSApplicationActivationPolicyAccessory
    from PyObjCTools import AppHelper
    AppHelper.runEventLoop()
