import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional

import yaml


DEFAULT_CONFIG_DIR = Path("~/.gitpulse").expanduser()
DEFAULT_CONFIG_PATH = DEFAULT_CONFIG_DIR / "config.yaml"


@dataclass
class ProviderConfig:
    token: str
    repos: List[str] = field(default_factory=list)
    api_url: str = ""
    username: str = ""  # required for Bitbucket


@dataclass
class NotifyConfig:
    new_pr: bool = True
    review_requested: bool = True
    ci_failure: bool = True
    pr_merged: bool = True


@dataclass
class Config:
    poll_interval: int = 300
    notification_sound: bool = True
    providers: Dict[str, ProviderConfig] = field(default_factory=dict)
    local_repos: List[str] = field(default_factory=list)
    notify: NotifyConfig = field(default_factory=NotifyConfig)
    config_path: Path = DEFAULT_CONFIG_PATH


PROVIDER_API_DEFAULTS = {
    "github": "https://api.github.com",
    "gitlab": "https://gitlab.com",
    "bitbucket": "https://api.bitbucket.org/2.0",
}


def save_config(config: Config):
    """Write config back to YAML file."""
    config.config_path.parent.mkdir(parents=True, exist_ok=True)

    providers_dict = {}
    for name, pconf in config.providers.items():
        entry = {"token": pconf.token}
        if pconf.repos:
            entry["repos"] = pconf.repos
        if pconf.api_url and pconf.api_url != PROVIDER_API_DEFAULTS.get(name, ""):
            entry["api_url"] = pconf.api_url
        if pconf.username:
            entry["username"] = pconf.username
        providers_dict[name] = entry

    data = {
        "poll_interval": config.poll_interval,
        "notification_sound": config.notification_sound,
        "providers": providers_dict,
        "local_repos": config.local_repos,
        "notify": {
            "new_pr": config.notify.new_pr,
            "review_requested": config.notify.review_requested,
            "ci_failure": config.notify.ci_failure,
            "pr_merged": config.notify.pr_merged,
        },
    }
    config.config_path.write_text(yaml.dump(data, default_flow_style=False, sort_keys=False))


def add_provider(config: Config, name: str, token: str, repos: List[str],
                 api_url: str = "", username: str = "") -> Config:
    """Add a provider to config and save."""
    if not api_url:
        api_url = PROVIDER_API_DEFAULTS.get(name, "")
    config.providers[name] = ProviderConfig(
        token=token, repos=repos, api_url=api_url, username=username,
    )
    save_config(config)
    return config


def remove_provider(config: Config, name: str) -> Config:
    """Remove a provider from config and save."""
    config.providers.pop(name, None)
    save_config(config)
    return config


def load_config(path: Optional[Path] = None) -> Config:
    config_path = path or Path(os.environ.get("GITPULSE_CONFIG", str(DEFAULT_CONFIG_PATH)))
    config_path = config_path.expanduser()

    if not config_path.exists():
        return Config(config_path=config_path)

    raw = yaml.safe_load(config_path.read_text()) or {}

    providers = {}
    for name, pconf in raw.get("providers", {}).items():
        if not pconf or not pconf.get("token"):
            continue
        providers[name] = ProviderConfig(
            token=pconf["token"],
            repos=pconf.get("repos", []),
            api_url=pconf.get("api_url", PROVIDER_API_DEFAULTS.get(name, "")),
            username=pconf.get("username", ""),
        )

    notify_raw = raw.get("notify", {})
    notify = NotifyConfig(
        new_pr=notify_raw.get("new_pr", True),
        review_requested=notify_raw.get("review_requested", True),
        ci_failure=notify_raw.get("ci_failure", True),
        pr_merged=notify_raw.get("pr_merged", True),
    )

    poll_interval = max(60, raw.get("poll_interval", 300))

    return Config(
        poll_interval=poll_interval,
        notification_sound=raw.get("notification_sound", True),
        providers=providers,
        local_repos=raw.get("local_repos", []),
        notify=notify,
        config_path=config_path,
    )
