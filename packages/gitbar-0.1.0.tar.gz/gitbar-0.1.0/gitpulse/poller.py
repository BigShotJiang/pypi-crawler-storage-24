import logging
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timedelta, timezone
from typing import Callable, Dict, List

from gitpulse.config import Config
from gitpulse.models import PollResult, Provider
from gitpulse.providers.base import BaseProvider
from gitpulse.state import StateStore

logger = logging.getLogger(__name__)


class Poller:
    def __init__(
        self,
        providers: Dict[str, BaseProvider],
        config: Config,
        state_store: StateStore,
        on_results: Callable[[List[PollResult]], None],
    ):
        self.providers = providers
        self.interval = config.poll_interval
        self.state = state_store
        self.on_results = on_results
        self._executor = ThreadPoolExecutor(max_workers=3)

    def poll_once(self):
        futures = {}
        for name, provider in self.providers.items():
            if self._should_skip(provider):
                logger.info(f"Skipping {name}: rate limit low ({provider.rate_remaining})")
                continue
            futures[self._executor.submit(self._poll_provider, provider)] = name

        results = []
        for future in as_completed(futures, timeout=60):
            name = futures[future]
            try:
                result = future.result()
                results.append(result)
            except Exception as e:
                logger.error(f"Poll failed for {name}: {e}")
                results.append(
                    PollResult(
                        provider=Provider(name),
                        errors=[str(e)],
                    )
                )

        self.on_results(results)

    def _poll_provider(self, provider: BaseProvider) -> PollResult:
        prs, statuses, activities, errors = [], [], [], []
        issues, ci_runs = [], []
        last_poll = self.state.get_last_poll(provider.name)
        since = last_poll or (datetime.now(timezone.utc) - timedelta(hours=1))

        for repo in provider.repos:
            try:
                prs.extend(provider.fetch_open_prs(repo))
            except Exception as e:
                errors.append(f"{repo} PRs: {e}")

            try:
                statuses.append(provider.fetch_repo_status(repo))
            except Exception as e:
                errors.append(f"{repo} status: {e}")

            try:
                activities.extend(provider.fetch_recent_activity(repo, since))
            except Exception as e:
                errors.append(f"{repo} activity: {e}")

            try:
                issues.extend(provider.fetch_assigned_issues(repo))
            except Exception as e:
                errors.append(f"{repo} issues: {e}")

            try:
                ci_runs.extend(provider.fetch_ci_runs(repo))
            except Exception as e:
                errors.append(f"{repo} CI: {e}")

        # Notifications are account-wide, not per-repo
        notifications = []
        try:
            notifications = provider.fetch_notifications()
        except Exception as e:
            errors.append(f"notifications: {e}")

        self.state.set_last_poll(provider.name, datetime.now(timezone.utc))

        return PollResult(
            provider=Provider(provider.name),
            pull_requests=prs,
            repo_statuses=statuses,
            activities=activities,
            issues=issues,
            ci_runs=ci_runs,
            notifications=notifications,
            errors=errors,
            rate_remaining=provider.rate_remaining,
        )

    def _should_skip(self, provider: BaseProvider) -> bool:
        if provider.rate_remaining is not None and provider.rate_remaining < 10:
            if provider.rate_reset and time.time() < provider.rate_reset:
                return True
        return False

    def shutdown(self):
        self._executor.shutdown(wait=False)
