"""Authentication flows for GitHub, GitLab, and Bitbucket."""

import logging
import subprocess
from typing import List, Optional, Tuple

import requests

logger = logging.getLogger(__name__)

KEYCHAIN_SERVICE_PREFIX = "gitpulse"


# --- macOS Keychain ---

def keychain_store(service: str, account: str, password: str) -> bool:
    label = f"{KEYCHAIN_SERVICE_PREFIX}-{service}"
    subprocess.run(
        ["security", "delete-generic-password", "-s", label, "-a", account],
        capture_output=True,
    )
    result = subprocess.run(
        ["security", "add-generic-password", "-s", label, "-a", account, "-w", password],
        capture_output=True, text=True,
    )
    if result.returncode != 0:
        logger.warning(f"Keychain store failed: {result.stderr}")
        return False
    return True


def keychain_retrieve(service: str, account: str) -> Optional[str]:
    label = f"{KEYCHAIN_SERVICE_PREFIX}-{service}"
    result = subprocess.run(
        ["security", "find-generic-password", "-s", label, "-a", account, "-w"],
        capture_output=True, text=True,
    )
    if result.returncode == 0:
        return result.stdout.strip()
    return None


def keychain_delete(service: str, account: str) -> bool:
    label = f"{KEYCHAIN_SERVICE_PREFIX}-{service}"
    result = subprocess.run(
        ["security", "delete-generic-password", "-s", label, "-a", account],
        capture_output=True,
    )
    return result.returncode == 0


def resolve_token(provider_name: str, token: str) -> str:
    if token == "keychain":
        # Try service-only lookup (any account)
        real = keychain_retrieve_by_service(provider_name)
        if real:
            return real
        logger.warning(f"Keychain lookup failed for {provider_name}, using sentinel")
    return token


def keychain_retrieve_by_service(service: str) -> Optional[str]:
    """Retrieve password by service name only (any account)."""
    label = f"{KEYCHAIN_SERVICE_PREFIX}-{service}"
    result = subprocess.run(
        ["security", "find-generic-password", "-s", label, "-w"],
        capture_output=True, text=True,
    )
    if result.returncode == 0:
        return result.stdout.strip()
    return None


# --- GitHub Auth ---

def github_auth_gh_cli() -> Optional[Tuple[str, str]]:
    """Try to get GitHub token from gh CLI, then validate via API. Returns (token, username) or None."""
    try:
        result = subprocess.run(
            ["gh", "auth", "token"], capture_output=True, text=True, timeout=5,
        )
        if result.returncode != 0:
            return None
        token = result.stdout.strip()
        if not token:
            return None

        # Validate via API directly (not gh api, which may fail if gh isn't fully logged in)
        username = validate_github_token(token)
        if not username:
            return None
        return token, username
    except (FileNotFoundError, subprocess.TimeoutExpired):
        return None


def validate_github_token(token: str) -> Optional[str]:
    """Validate a GitHub token via API. Returns username or None."""
    try:
        resp = requests.get(
            "https://api.github.com/user",
            headers={"Authorization": f"Bearer {token}"},
            timeout=10,
        )
        if resp.status_code == 200:
            return resp.json().get("login")
    except Exception as e:
        logger.error(f"GitHub token validation failed: {e}")
    return None


def github_discover_repos(token: str) -> List[str]:
    repos = []
    page = 1
    headers = {"Authorization": f"Bearer {token}"}
    while True:
        try:
            resp = requests.get(
                "https://api.github.com/user/repos",
                headers=headers,
                params={"per_page": 100, "page": page, "sort": "pushed"},
                timeout=10,
            )
            if resp.status_code != 200:
                break
            data = resp.json()
            if not data:
                break
            repos.extend(r["full_name"] for r in data)
            page += 1
            if len(data) < 100:
                break
        except Exception:
            break
    return repos


# --- GitLab Auth ---

def validate_gitlab_token(token: str) -> Optional[str]:
    try:
        resp = requests.get(
            "https://gitlab.com/api/v4/user",
            headers={"PRIVATE-TOKEN": token},
            timeout=10,
        )
        if resp.status_code == 200:
            return resp.json().get("username")
    except Exception as e:
        logger.error(f"GitLab token validation failed: {e}")
    return None


def gitlab_discover_repos(token: str) -> List[str]:
    repos = []
    page = 1
    while True:
        try:
            resp = requests.get(
                "https://gitlab.com/api/v4/projects",
                headers={"PRIVATE-TOKEN": token},
                params={"membership": True, "per_page": 100, "page": page, "order_by": "last_activity_at"},
                timeout=10,
            )
            if resp.status_code != 200:
                break
            data = resp.json()
            if not data:
                break
            repos.extend(p["path_with_namespace"] for p in data)
            page += 1
            if len(data) < 100:
                break
        except Exception:
            break
    return repos


# --- Bitbucket Auth ---

def validate_bitbucket(username: str, app_password: str) -> bool:
    try:
        resp = requests.get(
            "https://api.bitbucket.org/2.0/user",
            auth=(username, app_password),
            timeout=10,
        )
        return resp.status_code == 200
    except Exception:
        return False


def bitbucket_discover_repos(username: str, app_password: str) -> List[str]:
    repos = []
    url = f"https://api.bitbucket.org/2.0/repositories/{username}"
    while url:
        try:
            resp = requests.get(url, auth=(username, app_password), params={"pagelen": 100}, timeout=10)
            if resp.status_code != 200:
                break
            data = resp.json()
            repos.extend(r["full_name"] for r in data.get("values", []))
            url = data.get("next")
        except Exception:
            break
    return repos
