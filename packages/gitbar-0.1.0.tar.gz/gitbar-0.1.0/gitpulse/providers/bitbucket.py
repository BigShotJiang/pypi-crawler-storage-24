from datetime import datetime, timezone
from typing import List

from gitpulse.models import (
    Activity,
    CIStatus,
    PRState,
    Provider,
    PullRequest,
    RepoStatus,
)
from .base import BaseProvider


class BitbucketProvider(BaseProvider):
    def __init__(self, token: str, api_url: str, repos: List[str], username: str = "", **kwargs):
        self.bb_username = username
        super().__init__(token, api_url, repos, **kwargs)

    def _setup_auth(self):
        if self.bb_username:
            self.session.auth = (self.bb_username, self.token)

    def get_username(self) -> str:
        if self.bb_username:
            return self.bb_username
        resp = self._request("GET", f"{self.api_url}/user")
        self.bb_username = resp.json().get("username", "")
        return self.bb_username

    def _update_rate_limits(self, resp):
        # Bitbucket has no standard rate-limit headers; track conservatively
        if self.rate_remaining is None:
            self.rate_remaining = 900
        else:
            self.rate_remaining = max(0, self.rate_remaining - 1)

    def resolve_wildcards_for(self, workspace: str) -> List[str]:
        repos = []
        url = f"{self.api_url}/repositories/{workspace}"
        params = {"pagelen": 100}
        while url:
            resp = self._request("GET", url, params=params)
            data = resp.json()
            for r in data.get("values", []):
                repos.append(r["full_name"])
            url = data.get("next")
            params = {}  # next URL includes params
        return repos

    def resolve_wildcards(self) -> List[str]:
        return []

    def fetch_open_prs(self, repo_slug: str) -> List[PullRequest]:
        username = self.get_username()
        resp = self._request(
            "GET",
            f"{self.api_url}/repositories/{repo_slug}/pullrequests",
            params={"state": "OPEN", "pagelen": 50},
        )
        prs = []
        for pr in resp.json().get("values", []):
            reviewers = [
                r.get("username", r.get("nickname", ""))
                for r in pr.get("reviewers", [])
            ]
            prs.append(
                PullRequest(
                    id=f"bitbucket:{repo_slug}:{pr['id']}",
                    provider=Provider.BITBUCKET,
                    repo_slug=repo_slug,
                    number=pr["id"],
                    title=pr["title"],
                    author=pr.get("author", {}).get("nickname", "unknown"),
                    url=pr["links"]["html"]["href"],
                    state=PRState.OPEN,
                    created_at=_parse_dt(pr.get("created_on", "")),
                    updated_at=_parse_dt(pr.get("updated_on", "")),
                    is_review_requested=username in reviewers,
                    ci_status=CIStatus.UNKNOWN,
                    draft=False,  # Bitbucket Cloud doesn't have draft PRs
                )
            )
        return prs

    def fetch_repo_status(self, repo_slug: str) -> RepoStatus:
        resp = self._request("GET", f"{self.api_url}/repositories/{repo_slug}")
        repo = resp.json()
        mainbranch = repo.get("mainbranch", {}).get("name", "main")
        pushed = repo.get("updated_on")
        return RepoStatus(
            provider=Provider.BITBUCKET,
            repo_slug=repo_slug,
            default_branch=mainbranch,
            open_pr_count=0,  # requires separate call
            ci_status=CIStatus.UNKNOWN,
            last_push_at=_parse_dt(pushed) if pushed else None,
        )

    def fetch_recent_activity(self, repo_slug: str, since: datetime) -> List[Activity]:
        # Bitbucket doesn't have a convenient events endpoint like GitHub/GitLab
        # We can check for recently updated PRs as a proxy
        try:
            resp = self._request(
                "GET",
                f"{self.api_url}/repositories/{repo_slug}/pullrequests",
                params={"state": "MERGED", "pagelen": 10, "sort": "-updated_on"},
            )
        except Exception:
            return []

        activities = []
        for pr in resp.json().get("values", []):
            ts = _parse_dt(pr.get("updated_on", ""))
            if ts < since:
                continue
            activities.append(
                Activity(
                    id=f"bitbucket:{repo_slug}:merged:{pr['id']}",
                    provider=Provider.BITBUCKET,
                    repo_slug=repo_slug,
                    event_type="pr_merged",
                    title=f"PR #{pr['id']} merged: {pr['title']}",
                    url=pr["links"]["html"]["href"],
                    timestamp=ts,
                    actor=pr.get("author", {}).get("nickname", "unknown"),
                )
            )
        return activities


def _parse_dt(s: str) -> datetime:
    if not s:
        return datetime.min.replace(tzinfo=timezone.utc)
    s = s.replace("Z", "+00:00")
    try:
        return datetime.fromisoformat(s)
    except ValueError:
        return datetime.min.replace(tzinfo=timezone.utc)
