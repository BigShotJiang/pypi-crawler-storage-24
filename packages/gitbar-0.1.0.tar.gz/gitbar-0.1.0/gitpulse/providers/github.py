from datetime import datetime, timezone
from typing import List
from urllib.parse import urljoin

from gitpulse.models import (
    Activity,
    CIRun,
    CIStatus,
    Issue,
    Notification,
    PRState,
    Provider,
    PullRequest,
    RepoStatus,
)
from .base import BaseProvider


class GitHubProvider(BaseProvider):
    def _setup_auth(self):
        self.session.headers["Authorization"] = f"Bearer {self.token}"
        self._username = None

    def get_username(self) -> str:
        if not self._username:
            resp = self._request("GET", f"{self.api_url}/user")
            self._username = resp.json()["login"]
        return self._username

    def _update_rate_limits(self, resp):
        remaining = resp.headers.get("X-RateLimit-Remaining")
        reset = resp.headers.get("X-RateLimit-Reset")
        if remaining is not None:
            self.rate_remaining = int(remaining)
        if reset is not None:
            self.rate_reset = float(reset)

    def resolve_wildcards_for(self, org: str) -> List[str]:
        repos = []
        page = 1
        while True:
            resp = self._request(
                "GET",
                f"{self.api_url}/orgs/{org}/repos",
                params={"per_page": 100, "page": page},
            )
            data = resp.json()
            if not data:
                break
            repos.extend(r["full_name"] for r in data)
            page += 1
        return repos

    def resolve_wildcards(self) -> List[str]:
        return []

    def fetch_open_prs(self, repo_slug: str) -> List[PullRequest]:
        username = self.get_username()
        resp = self._request(
            "GET",
            f"{self.api_url}/repos/{repo_slug}/pulls",
            params={"state": "open", "per_page": 100},
        )
        prs = []
        for pr in resp.json():
            reviewers = [r["login"] for r in pr.get("requested_reviewers", [])]
            ci = self._get_ci_status(repo_slug, pr["head"]["sha"])
            prs.append(
                PullRequest(
                    id=f"github:{repo_slug}:{pr['number']}",
                    provider=Provider.GITHUB,
                    repo_slug=repo_slug,
                    number=pr["number"],
                    title=pr["title"],
                    author=pr["user"]["login"],
                    url=pr["html_url"],
                    state=PRState.OPEN,
                    created_at=_parse_dt(pr["created_at"]),
                    updated_at=_parse_dt(pr["updated_at"]),
                    is_review_requested=username in reviewers,
                    ci_status=ci,
                    draft=pr.get("draft", False),
                    labels=tuple(l["name"] for l in pr.get("labels", [])),
                )
            )
        return prs

    def _get_ci_status(self, repo_slug: str, sha: str) -> CIStatus:
        try:
            resp = self._request(
                "GET",
                f"{self.api_url}/repos/{repo_slug}/commits/{sha}/status",
            )
            state = resp.json().get("state", "")
            return {
                "success": CIStatus.PASSING,
                "failure": CIStatus.FAILING,
                "error": CIStatus.FAILING,
                "pending": CIStatus.PENDING,
            }.get(state, CIStatus.UNKNOWN)
        except Exception:
            return CIStatus.UNKNOWN

    def fetch_repo_status(self, repo_slug: str) -> RepoStatus:
        resp = self._request("GET", f"{self.api_url}/repos/{repo_slug}")
        repo = resp.json()
        pushed = repo.get("pushed_at")
        return RepoStatus(
            provider=Provider.GITHUB,
            repo_slug=repo_slug,
            default_branch=repo.get("default_branch", "main"),
            open_pr_count=repo.get("open_issues_count", 0),
            ci_status=CIStatus.UNKNOWN,
            last_push_at=_parse_dt(pushed) if pushed else None,
        )

    def fetch_assigned_issues(self, repo_slug: str) -> List[Issue]:
        username = self.get_username()
        try:
            resp = self._request(
                "GET",
                f"{self.api_url}/repos/{repo_slug}/issues",
                params={"assignee": username, "state": "open", "per_page": 25},
            )
        except Exception:
            return []
        issues = []
        for iss in resp.json():
            if iss.get("pull_request"):
                continue  # skip PRs (GitHub lists PRs as issues too)
            issues.append(
                Issue(
                    id=f"github:{repo_slug}:{iss['number']}",
                    provider=Provider.GITHUB,
                    repo_slug=repo_slug,
                    number=iss["number"],
                    title=iss["title"],
                    url=iss["html_url"],
                    labels=tuple(l["name"] for l in iss.get("labels", [])),
                    created_at=_parse_dt(iss.get("created_at", "")),
                )
            )
        return issues

    def fetch_ci_runs(self, repo_slug: str) -> List[CIRun]:
        """Fetch recent workflow runs (failed/in-progress only)."""
        try:
            resp = self._request(
                "GET",
                f"{self.api_url}/repos/{repo_slug}/actions/runs",
                params={"per_page": 10, "status": "failure"},
            )
        except Exception:
            return []
        runs = []
        for run in resp.json().get("workflow_runs", [])[:5]:
            runs.append(
                CIRun(
                    id=f"github:{repo_slug}:run:{run['id']}",
                    provider=Provider.GITHUB,
                    repo_slug=repo_slug,
                    branch=run.get("head_branch", ""),
                    status=CIStatus.FAILING,
                    url=run["html_url"],
                    name=run.get("name", ""),
                    updated_at=_parse_dt(run.get("updated_at", "")),
                )
            )
        return runs

    def fetch_notifications(self) -> List[Notification]:
        """Fetch unread GitHub notifications."""
        try:
            resp = self._request(
                "GET",
                f"{self.api_url}/notifications",
                params={"per_page": 25},
            )
        except Exception:
            return []
        notifs = []
        for n in resp.json():
            subject = n.get("subject", {})
            repo = n.get("repository", {}).get("full_name", "")
            # Build a web URL from the API URL
            url = subject.get("url", "")
            web_url = _api_to_web_url(url, repo)
            notifs.append(
                Notification(
                    id=f"github:notif:{n['id']}",
                    title=subject.get("title", ""),
                    url=web_url,
                    reason=n.get("reason", ""),
                    repo_slug=repo,
                    updated_at=_parse_dt(n.get("updated_at", "")),
                    unread=n.get("unread", True),
                )
            )
        return notifs

    def fetch_recent_activity(self, repo_slug: str, since: datetime) -> List[Activity]:
        try:
            resp = self._request(
                "GET",
                f"{self.api_url}/repos/{repo_slug}/events",
                params={"per_page": 30},
            )
        except Exception:
            return []

        activities = []
        for event in resp.json():
            ts = _parse_dt(event.get("created_at", ""))
            if ts < since:
                continue
            etype = event["type"]
            mapped = _map_github_event(etype)
            if not mapped:
                continue
            activities.append(
                Activity(
                    id=f"github:{repo_slug}:{event['id']}",
                    provider=Provider.GITHUB,
                    repo_slug=repo_slug,
                    event_type=mapped,
                    title=_github_event_title(event),
                    url=f"https://github.com/{repo_slug}",
                    timestamp=ts,
                    actor=event.get("actor", {}).get("login", "unknown"),
                )
            )
        return activities


def _parse_dt(s: str) -> datetime:
    if not s:
        return datetime.min.replace(tzinfo=timezone.utc)
    s = s.replace("Z", "+00:00")
    return datetime.fromisoformat(s)


def _map_github_event(etype: str) -> str:
    return {
        "PullRequestEvent": "pr_opened",
        "PullRequestReviewEvent": "review_requested",
        "PushEvent": "push",
        "StatusEvent": "ci_failed",
    }.get(etype, "")


def _github_event_title(event: dict) -> str:
    etype = event["type"]
    payload = event.get("payload", {})
    if etype == "PullRequestEvent":
        pr = payload.get("pull_request", {})
        action = payload.get("action", "")
        return f"PR #{pr.get('number', '?')} {action}: {pr.get('title', '')}"
    if etype == "PushEvent":
        count = payload.get("size", 0)
        ref = payload.get("ref", "").split("/")[-1]
        return f"{count} commit(s) pushed to {ref}"
    return etype


def _api_to_web_url(api_url: str, repo_slug: str) -> str:
    """Convert GitHub API URL to web URL."""
    if not api_url:
        return f"https://github.com/{repo_slug}"
    # https://api.github.com/repos/owner/repo/pulls/123 -> https://github.com/owner/repo/pull/123
    url = api_url.replace("https://api.github.com/repos/", "https://github.com/")
    url = url.replace("/pulls/", "/pull/")
    url = url.replace("/issues/", "/issues/")
    return url
