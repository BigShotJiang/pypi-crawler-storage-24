from datetime import datetime, timezone
from typing import List
from urllib.parse import quote

from gitpulse.models import (
    Activity,
    CIStatus,
    PRState,
    Provider,
    PullRequest,
    RepoStatus,
)
from .base import BaseProvider


class GitLabProvider(BaseProvider):
    def _setup_auth(self):
        self.session.headers["PRIVATE-TOKEN"] = self.token
        self._username = None

    def get_username(self) -> str:
        if not self._username:
            resp = self._request("GET", f"{self.api_url}/api/v4/user")
            self._username = resp.json()["username"]
        return self._username

    def _update_rate_limits(self, resp):
        remaining = resp.headers.get("RateLimit-Remaining")
        reset = resp.headers.get("RateLimit-Reset")
        if remaining is not None:
            self.rate_remaining = int(remaining)
        if reset is not None:
            self.rate_reset = float(reset)

    def _project_id(self, slug: str) -> str:
        return quote(slug, safe="")

    def resolve_wildcards_for(self, group: str) -> List[str]:
        repos = []
        page = 1
        while True:
            resp = self._request(
                "GET",
                f"{self.api_url}/api/v4/groups/{quote(group, safe='')}/projects",
                params={"per_page": 100, "page": page, "include_subgroups": True},
            )
            data = resp.json()
            if not data:
                break
            repos.extend(p["path_with_namespace"] for p in data)
            page += 1
        return repos

    def resolve_wildcards(self) -> List[str]:
        return []

    def fetch_open_prs(self, repo_slug: str) -> List[PullRequest]:
        username = self.get_username()
        pid = self._project_id(repo_slug)
        resp = self._request(
            "GET",
            f"{self.api_url}/api/v4/projects/{pid}/merge_requests",
            params={"state": "opened", "per_page": 100},
        )
        prs = []
        for mr in resp.json():
            reviewers = [r["username"] for r in mr.get("reviewers", [])]
            ci = _map_gl_pipeline(mr.get("head_pipeline", {}))
            prs.append(
                PullRequest(
                    id=f"gitlab:{repo_slug}:{mr['iid']}",
                    provider=Provider.GITLAB,
                    repo_slug=repo_slug,
                    number=mr["iid"],
                    title=mr["title"],
                    author=mr["author"]["username"],
                    url=mr["web_url"],
                    state=PRState.OPEN,
                    created_at=_parse_dt(mr["created_at"]),
                    updated_at=_parse_dt(mr["updated_at"]),
                    is_review_requested=username in reviewers,
                    ci_status=ci,
                    draft=mr.get("draft", False) or mr.get("work_in_progress", False),
                    labels=tuple(mr.get("labels", [])),
                )
            )
        return prs

    def fetch_repo_status(self, repo_slug: str) -> RepoStatus:
        pid = self._project_id(repo_slug)
        resp = self._request("GET", f"{self.api_url}/api/v4/projects/{pid}")
        proj = resp.json()
        pushed = proj.get("last_activity_at")
        return RepoStatus(
            provider=Provider.GITLAB,
            repo_slug=repo_slug,
            default_branch=proj.get("default_branch", "main"),
            open_pr_count=proj.get("open_issues_count", 0),
            ci_status=CIStatus.UNKNOWN,
            last_push_at=_parse_dt(pushed) if pushed else None,
        )

    def fetch_recent_activity(self, repo_slug: str, since: datetime) -> List[Activity]:
        pid = self._project_id(repo_slug)
        try:
            resp = self._request(
                "GET",
                f"{self.api_url}/api/v4/projects/{pid}/events",
                params={"per_page": 30, "after": since.strftime("%Y-%m-%d")},
            )
        except Exception:
            return []

        activities = []
        for event in resp.json():
            ts = _parse_dt(event.get("created_at", ""))
            if ts < since:
                continue
            mapped = _map_gl_event(event.get("action_name", ""), event.get("target_type", ""))
            if not mapped:
                continue
            title = event.get("target_title", "") or event.get("action_name", "")
            activities.append(
                Activity(
                    id=f"gitlab:{repo_slug}:{event['id'] if 'id' in event else ts.isoformat()}",
                    provider=Provider.GITLAB,
                    repo_slug=repo_slug,
                    event_type=mapped,
                    title=title,
                    url=f"https://gitlab.com/{repo_slug}",
                    timestamp=ts,
                    actor=event.get("author", {}).get("username", "unknown")
                    if isinstance(event.get("author"), dict)
                    else event.get("author_username", "unknown"),
                )
            )
        return activities


def _parse_dt(s: str) -> datetime:
    if not s:
        return datetime.min.replace(tzinfo=timezone.utc)
    s = s.replace("Z", "+00:00")
    try:
        return datetime.fromisoformat(s)
    except ValueError:
        return datetime.min.replace(tzinfo=timezone.utc)


def _map_gl_pipeline(pipeline: dict) -> CIStatus:
    if not pipeline:
        return CIStatus.UNKNOWN
    status = pipeline.get("status", "")
    return {
        "success": CIStatus.PASSING,
        "failed": CIStatus.FAILING,
        "running": CIStatus.PENDING,
        "pending": CIStatus.PENDING,
        "canceled": CIStatus.UNKNOWN,
    }.get(status, CIStatus.UNKNOWN)


def _map_gl_event(action: str, target_type: str) -> str:
    if target_type == "MergeRequest":
        if action in ("opened", "created"):
            return "pr_opened"
        if action == "merged":
            return "pr_merged"
    if action == "pushed to" or action == "pushed new":
        return "push"
    return ""
