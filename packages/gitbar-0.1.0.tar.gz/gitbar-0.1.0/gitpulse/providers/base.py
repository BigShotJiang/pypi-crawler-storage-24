import time
from abc import ABC, abstractmethod
from typing import List, Optional

import requests

from gitpulse.models import Activity, CIRun, Issue, Notification, PollResult, PullRequest, RepoStatus


class BaseProvider(ABC):
    def __init__(self, token: str, api_url: str, repos: List[str], **kwargs):
        from gitpulse.auth import resolve_token
        self.token = resolve_token(self.__class__.__name__.replace("Provider", "").lower(), token)
        self.api_url = api_url.rstrip("/")
        self.repos = list(repos)
        self.session = requests.Session()
        self.session.headers["Accept"] = "application/json"
        self.rate_remaining: Optional[int] = None
        self.rate_reset: Optional[float] = None
        self._setup_auth()

    @abstractmethod
    def _setup_auth(self):
        ...

    @abstractmethod
    def resolve_wildcards(self) -> List[str]:
        """Expand 'org/*' patterns into concrete repo slugs."""
        ...

    @abstractmethod
    def get_username(self) -> str:
        """Return the authenticated user's username."""
        ...

    @abstractmethod
    def fetch_open_prs(self, repo_slug: str) -> List[PullRequest]:
        ...

    @abstractmethod
    def fetch_repo_status(self, repo_slug: str) -> RepoStatus:
        ...

    @abstractmethod
    def fetch_recent_activity(self, repo_slug: str, since) -> List[Activity]:
        ...

    def fetch_assigned_issues(self, repo_slug: str) -> List[Issue]:
        return []

    def fetch_ci_runs(self, repo_slug: str) -> List[CIRun]:
        return []

    def fetch_notifications(self) -> List[Notification]:
        return []

    def _request(self, method: str, url: str, **kwargs) -> requests.Response:
        kwargs.setdefault("timeout", 10)
        resp = self.session.request(method, url, **kwargs)
        self._update_rate_limits(resp)
        if resp.status_code >= 500:
            time.sleep(2)
            resp = self.session.request(method, url, **kwargs)
            self._update_rate_limits(resp)
        resp.raise_for_status()
        return resp

    def _update_rate_limits(self, resp: requests.Response):
        pass

    @property
    def name(self) -> str:
        return self.__class__.__name__.replace("Provider", "").lower()

    def init_repos(self):
        """Resolve wildcards and populate self.repos with concrete slugs."""
        wildcards = [r for r in self.repos if r.endswith("/*")]
        concrete = [r for r in self.repos if not r.endswith("/*")]
        for wc in wildcards:
            prefix = wc[:-2]  # strip "/*"
            concrete.extend(self.resolve_wildcards_for(prefix))
        self.repos = list(dict.fromkeys(concrete))  # dedupe, preserve order

    def resolve_wildcards_for(self, org_or_group: str) -> List[str]:
        return self.resolve_wildcards()
