import subprocess
from datetime import datetime, timezone
from pathlib import Path
from typing import List

from gitpulse.models import LocalRepoStatus


class LocalRepoChecker:
    def __init__(self, paths: List[str]):
        self.paths = [Path(p).expanduser() for p in (paths or [])]

    def check_all(self) -> List[LocalRepoStatus]:
        return [self._check_one(p) for p in self.paths]

    def _check_one(self, path: Path) -> LocalRepoStatus:
        try:
            branch = self._git(path, "rev-parse", "--abbrev-ref", "HEAD")
            porcelain = self._git(path, "status", "--porcelain")
            dirty_count = len([l for l in porcelain.splitlines() if l.strip()])

            try:
                counts = self._git(path, "rev-list", "--left-right", "--count", "HEAD...@{upstream}")
                ahead, behind = (int(x) for x in counts.split())
            except subprocess.CalledProcessError:
                ahead, behind = 0, 0

            last_log = self._git(path, "log", "-1", "--format=%s|||%aI")
            if "|||" in last_log:
                msg, time_str = last_log.split("|||", 1)
                commit_time = datetime.fromisoformat(time_str)
            else:
                msg = last_log
                commit_time = datetime.min.replace(tzinfo=timezone.utc)

            return LocalRepoStatus(
                path=str(path),
                branch=branch,
                is_dirty=dirty_count > 0,
                ahead=ahead,
                behind=behind,
                last_commit_msg=msg[:80],
                last_commit_time=commit_time,
            )
        except Exception as e:
            return LocalRepoStatus(
                path=str(path),
                branch="???",
                is_dirty=False,
                ahead=0,
                behind=0,
                last_commit_msg="",
                last_commit_time=datetime.min.replace(tzinfo=timezone.utc),
                error=str(e),
            )

    def _git(self, path: Path, *args) -> str:
        result = subprocess.run(
            ["git", *args],
            capture_output=True,
            text=True,
            cwd=str(path),
            timeout=5,
        )
        result.check_returncode()
        return result.stdout.strip()
