from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Optional, List


class Provider(Enum):
    GITHUB = "github"
    GITLAB = "gitlab"
    BITBUCKET = "bitbucket"


class PRState(Enum):
    OPEN = "open"
    MERGED = "merged"
    CLOSED = "closed"


class CIStatus(Enum):
    PASSING = "passing"
    FAILING = "failing"
    PENDING = "pending"
    UNKNOWN = "unknown"


@dataclass(frozen=True)
class PullRequest:
    id: str  # "{provider}:{repo}:{number}"
    provider: Provider
    repo_slug: str
    number: int
    title: str
    author: str
    url: str
    state: PRState
    created_at: datetime
    updated_at: datetime
    is_review_requested: bool
    ci_status: CIStatus
    draft: bool = False
    labels: tuple = ()


@dataclass(frozen=True)
class RepoStatus:
    provider: Provider
    repo_slug: str
    default_branch: str
    open_pr_count: int
    ci_status: CIStatus
    last_push_at: Optional[datetime]


@dataclass
class LocalRepoStatus:
    path: str
    branch: str
    is_dirty: bool
    ahead: int
    behind: int
    last_commit_msg: str
    last_commit_time: datetime
    error: Optional[str] = None


@dataclass(frozen=True)
class Issue:
    id: str  # "{provider}:{repo}:{number}"
    provider: Provider
    repo_slug: str
    number: int
    title: str
    url: str
    labels: tuple = ()
    created_at: Optional[datetime] = None


@dataclass(frozen=True)
class CIRun:
    id: str
    provider: Provider
    repo_slug: str
    branch: str
    status: CIStatus
    url: str
    name: str = ""  # workflow/pipeline name
    updated_at: Optional[datetime] = None


@dataclass(frozen=True)
class Notification:
    id: str
    title: str
    url: str
    reason: str  # "review_requested", "mention", "ci_activity", "assign", etc.
    repo_slug: str
    updated_at: Optional[datetime] = None
    unread: bool = True


@dataclass
class Activity:
    id: str  # unique event ID
    provider: Provider
    repo_slug: str
    event_type: str  # "pr_opened", "pr_merged", "ci_failed", "review_requested", "push"
    title: str
    url: str
    timestamp: datetime
    actor: str


@dataclass
class PollResult:
    provider: Provider
    pull_requests: List[PullRequest] = field(default_factory=list)
    repo_statuses: List[RepoStatus] = field(default_factory=list)
    activities: List[Activity] = field(default_factory=list)
    issues: List[Issue] = field(default_factory=list)
    ci_runs: List[CIRun] = field(default_factory=list)
    notifications: List[Notification] = field(default_factory=list)
    errors: List[str] = field(default_factory=list)
    rate_remaining: Optional[int] = None
