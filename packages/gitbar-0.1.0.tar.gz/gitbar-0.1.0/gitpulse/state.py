import json
import time
from collections import OrderedDict
from datetime import datetime
from pathlib import Path
from threading import Lock
from typing import Optional

STATE_DIR = Path("~/.gitpulse").expanduser()
STATE_FILE = STATE_DIR / "state.json"
MAX_SEEN = 5000


class StateStore:
    def __init__(self):
        self._lock = Lock()
        self._seen_events: OrderedDict = OrderedDict()
        self._last_polls: dict = {}
        self._last_flush = 0.0
        self._load()

    def has_seen(self, event_id: str) -> bool:
        with self._lock:
            return event_id in self._seen_events

    def mark_seen(self, event_id: str):
        with self._lock:
            self._seen_events[event_id] = time.time()
            if len(self._seen_events) > MAX_SEEN:
                to_remove = list(self._seen_events.keys())[: MAX_SEEN // 2]
                for k in to_remove:
                    del self._seen_events[k]
            self._maybe_flush()

    def set_last_poll(self, provider: str, timestamp: datetime):
        with self._lock:
            self._last_polls[provider] = timestamp.isoformat()
            self._maybe_flush()

    def get_last_poll(self, provider: str) -> Optional[datetime]:
        with self._lock:
            ts = self._last_polls.get(provider)
            if ts:
                return datetime.fromisoformat(ts)
            return None

    def _maybe_flush(self):
        now = time.time()
        if now - self._last_flush < 5.0:
            return
        self._last_flush = now
        self._save()

    def _save(self):
        STATE_DIR.mkdir(parents=True, exist_ok=True)
        data = {
            "seen_events": dict(self._seen_events),
            "last_polls": self._last_polls,
        }
        STATE_FILE.write_text(json.dumps(data, indent=2))

    def _load(self):
        if STATE_FILE.exists():
            try:
                data = json.loads(STATE_FILE.read_text())
                self._seen_events = OrderedDict(data.get("seen_events", {}))
                self._last_polls = data.get("last_polls", {})
            except (json.JSONDecodeError, KeyError):
                pass

    def flush(self):
        with self._lock:
            self._save()
