# confluence - add_file_to_page

**Toolkit**: `confluence`
**Method**: `add_file_to_page`
**Source File**: `api_wrapper.py`
**Class**: `ConfluenceAPIWrapper`

---

## Method Implementation

```python
    def add_file_to_page(
        self,
        page_id: str,
        filepath: str,
        filename: Optional[str] = None,
        caption: Optional[str] = None,
        position: Literal["append", "prepend"] = "append"
    ) -> str:
        """Upload file from artifact and add to Confluence page content. Images display inline with optional visible caption, other files as attachment links."""
        try:
            # Upload file to Confluence
            upload_info = self._upload_file_from_artifact(page_id, filepath, filename)
            uploaded_filename = upload_info['filename']
            mime_type = upload_info['mime_type']
            
            # Get current page content
            page = self.client.get_page_by_id(page_id, expand='body.storage,version')
            current_body = page.get('body', {}).get('storage', {}).get('value', '')
            
            # Create appropriate markup based on file type
            if mime_type.startswith('image/') or mime_type.startswith('video/'):
                file_markup = self._get_confluence_image_markup(uploaded_filename, caption)
            else:
                file_markup = self._get_confluence_file_link(uploaded_filename)
            
            # Add the file markup to page content
            if position == "prepend":
                new_body = f"{file_markup}<p></p>{current_body}"
            else:
                new_body = f"{current_body}<p></p>{file_markup}"
            
            # Update the page
            self.client.update_page(
                page_id=page_id,
                title=page['title'],
                body=new_body,
                parent_id=None,
                type='page',
                representation='storage',
                minor_edit=False,
                version_comment=f"Added file: {uploaded_filename}",
                full_width=False
            )
            
            # Return success message
            page_url = self._build_page_url(page['_links']['webui'])
            file_type = "image" if mime_type.startswith('image/') else "video" if mime_type.startswith('video/') else "file"
            return (
                f"File '{uploaded_filename}' uploaded and added to page {page_id} as {file_type}. "
                f"View at: {page_url}"
            )
            
        except ToolException:
            raise
        except (HTTPError, ApiError) as e:
            error_details = self._extract_http_error_details(e)
            logger.error(f"Error adding file to page: {format_exc()}")
            raise ToolException(f"Failed to add file to page {page_id}: {error_details}")
        except Exception as e:
            logger.error(f"Error adding file to page: {format_exc()}")
            raise ToolException(f"Failed to add file to page {page_id}: {str(e)}")
```
