<div align="center">

# 🥝 KiwiLog

### A **beautiful, colorful logging utility** for Python

![Python](https://img.shields.io/badge/Python-3.x-blue?style=for-the-badge&logo=python)
![Status](https://img.shields.io/badge/status-active-success?style=for-the-badge)
![License](https://img.shields.io/badge/license-MIT-green?style=for-the-badge)

Elegant • Minimal • Readable • Colorful

</div>

---

# Overview

**KiwiLog** is a lightweight Python logging utility designed to make terminal output **clean, colorful, and easy to read**.

Instead of dealing with complex logging frameworks, KiwiLog provides **simple functions** for common log types.

Perfect for:

- CLI tools  
- Scripts  
- Debugging  
- Automation  
- Bots  
- Development utilities  

---

# Available Commands / How to Use

KiwiLog provides simple, color-coded logging functions:

| Command | Description | Example |
|---------|------------|---------|
| `trace(msg)` | Very low-level tracing | `kiwilog.trace("Step 1 check")` |
| `debug(msg)` | Debugging details | `kiwilog.debug("Loading configuration")` |
| `info(msg)` | General information | `kiwilog.info("Server started")` |
| `notice(msg)` | Important notices | `kiwilog.notice("Update available")` |
| `success(msg)` | Success messages | `kiwilog.success("Build completed")` |
| `waiting(msg)` | Waiting for action | `kiwilog.waiting("Awaiting input")` |
| `warn(msg)` | Warnings | `kiwilog.warn("Low disk space")` |
| `error(msg)` | Errors | `kiwilog.error("Failed to connect")` |
| `critical(msg)` | Fatal or critical errors | `kiwilog.critical("Database unavailable")` |

---

# 🌀 Loading Animation

Show a beautiful loading animation for long-running tasks:

```python
# Default dots animation
with kiwilog.loading("Processing data"):
    time.sleep(3)

# Rotating spinner
with kiwilog.loading("Uploading", animation_type="spinner"):
    time.sleep(3)
```


# 🎡 Spinners (Manual Control)

If you prefer manual control over spinners:

```python
spinner = kiwilog.Spinner("Connecting to database", animation_type="spinner")
spinner.start()
time.sleep(2)
spinner.stop("Connected!")
```

# ✨ Pretty Printing

KiwiLog automatically pretty-prints dictionaries and lists:

```python
config = {"debug": True, "timeout": 30, "users": ["Alice", "Bob"]}
kiwilog.debug(config)
```

# ⚙️ Configuration

You can configure KiwiLog via `configure()` or **Environment Variables**:

| ENV Variable | Description | Default |
|--------------|-------------|---------|
| `KIWILOG_LEVEL` | Minimum log level | `INFO` |
| `KIWILOG_LOG_FILE` | Path to log file | `logs/bot.log` |
| `KIWILOG_FILE_LOGGING`| Enable file logging | `true` |
| `KIWILOG_SHOW_TIMESTAMP`| Show timestamp | `true` |
| `KIWILOG_SHOW_FILENAME`| Show filename | `true` |
| `KIWILOG_PRETTY` | Enable pretty printing | `true` |