import os
import sys
import time

# Add the current directory to sys.path so we can import kiwilog
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

import kiwilog

def test_basic_logging():
    print("--- Testing Basic Logging (Default INFO Level) ---")
    kiwilog.info("This should show up (INFO)")
    kiwilog.debug("This should NOT show up (DEBUG)")
    kiwilog.error("This should show up (ERROR)")

def test_configuration():
    print("\n--- Testing Configuration (Level=DEBUG) ---")
    kiwilog.configure(level="DEBUG")
    kiwilog.debug("This should NOW show up (DEBUG)")
    
    print("\n--- Testing Custom Log File ---")
    custom_log = "logs/test_custom.log"
    if os.path.exists(custom_log):
        os.remove(custom_log)
    
    kiwilog.configure(log_file=custom_log)
    kiwilog.success("This message goes to a custom log file")
    
    if os.path.exists(custom_log):
        print(f"Success: {custom_log} created!")
        with open(custom_log, "r") as f:
            content = f.read()
            print(f"File content snippet: {content.strip()}")
    else:
        print(f"Failure: {custom_log} was not created!")

def test_formatting():
    print("\n--- Testing Formatting Options ---")
    kiwilog.configure(show_timestamp=False, show_filename=False)
    kiwilog.info("This should have no timestamp and no filename")
    
    kiwilog.configure(show_timestamp=True, show_filename=True)
    kiwilog.info("This should have both again")

def test_new_types():
    print("\n--- Testing New Log Types ---")
    kiwilog.configure(level="TRACE")
    kiwilog.trace("Tracing something deep...")
    kiwilog.notice("Note: The system is running in test mode")
    kiwilog.waiting("Waiting for a moment...")

def test_loading():
    print("\n--- Testing Loading Animation ---")
    with kiwilog.loading("Connecting to server (dots)"):
        time.sleep(1.5)
    
    with kiwilog.loading("Uploading files (spinner)", animation_type="spinner"):
        time.sleep(1.5)
    kiwilog.success("Done!")


def test_manual_spinner():
    print("\n--- Testing Manual Spinner ---")
    s = kiwilog.Spinner("Manual spinner", animation_type="spinner")
    s.start()
    time.sleep(1.5)
    s.stop("Manual spinner stopped!")


def test_pretty_printing():
    print("\n--- Testing Pretty Printing ---")
    data = {
        "status": "awesome",
        "nested": {"key": "value"},
        "list": [1, 2, 3]
    }
    kiwilog.info(data)

if __name__ == "__main__":
    if not os.path.exists("logs"):
        os.makedirs("logs")
    test_basic_logging()
    test_configuration()
    test_formatting()
    test_new_types()
    test_loading()
    test_pretty_printing()
    test_manual_spinner()
