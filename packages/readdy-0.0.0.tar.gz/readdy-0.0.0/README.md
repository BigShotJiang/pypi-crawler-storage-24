# ReaDDy

ReaDDy is a particle-based reaction-diffusion simulator written in C++, with Python bindings.

This is a placeholder release. Please install readdy via conda for full functionality.
