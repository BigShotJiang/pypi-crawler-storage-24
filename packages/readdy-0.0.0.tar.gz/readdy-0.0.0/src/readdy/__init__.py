raise ImportError(
    "readdy requires compiled C++ extensions. "
    "Please install via conda: conda install -c conda-forge readdy"
)
