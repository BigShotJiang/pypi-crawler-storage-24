import logging
import reflex as rx
import asyncio
import threading
import time
import atexit
from typing import List, Dict, Any, Optional
from plexmix.ui.states.app_state import AppState

logger = logging.getLogger(__name__)

# Per-client cancel events for tagging operations
_tagging_cancel_events: Dict[str, threading.Event] = {}


def _cleanup_tagging_state(client_token: str) -> None:
    """Clean up any state associated with a disconnected client."""
    if client_token in _tagging_cancel_events:
        _tagging_cancel_events[client_token].set()
        del _tagging_cancel_events[client_token]


def _cleanup_all_tagging_state() -> None:
    """Clean up all tagging state on process exit."""
    for token in list(_tagging_cancel_events.keys()):
        _tagging_cancel_events[token].set()
    _tagging_cancel_events.clear()


# Register cleanup on process exit
atexit.register(_cleanup_all_tagging_state)


class TaggingState(AppState):
    # Filter criteria
    genre_filter: str = ""
    year_min: Optional[int] = None
    year_max: Optional[int] = None
    artist_filter: str = ""
    has_no_tags: bool = False

    # Preview and progress
    preview_count: int = 0
    is_tagging: bool = False
    tagging_progress: int = 0
    current_batch: int = 0
    total_batches: int = 0
    tags_generated_count: int = 0
    estimated_time_remaining: int = 0
    tagging_message: str = ""

    # Confirmation dialog
    show_tag_all_confirm: bool = False
    untagged_track_count: int = 0

    # Recently tagged tracks
    recently_tagged_tracks: List[Dict[str, Any]] = []

    # For inline editing
    editing_track_id: Optional[int] = None
    edit_tags: str = ""
    edit_environments: str = ""
    edit_instruments: str = ""

    def on_load(self):
        if not self.check_auth():
            self.is_page_loading = False
            return
        super().on_load()
        self.load_recently_tagged()
        self.is_page_loading = False

    def load_recently_tagged(self):
        try:
            from plexmix.config.settings import Settings
            from plexmix.database.sqlite_manager import SQLiteManager

            settings = Settings.load_from_file()
            db_path = settings.database.get_db_path()

            if db_path.exists():
                db = SQLiteManager(str(db_path))
                db.connect()
                self.recently_tagged_tracks = db.get_recently_tagged_tracks(limit=100)
                db.close()
        except Exception as e:
            logger.error("Error loading recently tagged tracks: %s", e)

    def set_genre_filter(self, value: str):
        self.genre_filter = value

    def set_year_range(self, year_min: Optional[int], year_max: Optional[int]):
        self.year_min = year_min
        self.year_max = year_max

    def set_year_min(self, value: str):
        self.year_min = int(value) if value else None

    def set_year_max(self, value: str):
        self.year_max = int(value) if value else None

    def set_artist_filter(self, value: str):
        self.artist_filter = value

    def toggle_has_no_tags(self):
        self.has_no_tags = not self.has_no_tags

    @rx.event(background=True)
    async def preview_selection(self):
        async with self:
            self.preview_count = 0
            self.tagging_message = "Counting matching tracks..."

        try:
            from plexmix.config.settings import Settings
            from plexmix.database.sqlite_manager import SQLiteManager

            settings = Settings.load_from_file()
            db_path = settings.database.get_db_path()

            if not db_path.exists():
                async with self:
                    self.tagging_message = "Database not found. Please sync your library first."
                return

            db = SQLiteManager(str(db_path))
            db.connect()

            # Get matching tracks
            tracks = db.get_tracks_by_filter(
                genre=self.genre_filter if self.genre_filter else None,
                year_min=self.year_min,
                year_max=self.year_max,
                artist=self.artist_filter if self.artist_filter else None,
                has_no_tags=self.has_no_tags
            )

            db.close()

            async with self:
                self.preview_count = len(tracks)
                self.tagging_message = f"{len(tracks)} tracks match your filters"

        except Exception as e:
            async with self:
                self.tagging_message = f"Error: {str(e)}"

    @rx.event(background=True)
    async def start_tagging(self):
        token = self.router.session.client_token
        async with self:
            if self.preview_count == 0:
                self.tagging_message = "No tracks to tag. Preview selection first."
                return

            self.is_tagging = True
            self.tagging_progress = 0
            self.current_batch = 0
            self.tags_generated_count = 0
            self.tagging_message = "Starting tag generation..."

        _tagging_cancel_events[token] = threading.Event()

        try:
            from plexmix.config.settings import Settings
            from plexmix.database.sqlite_manager import SQLiteManager
            from plexmix.ai.tag_generator import TagGenerator

            settings = Settings.load_from_file()
            db_path = settings.database.get_db_path()

            if not db_path.exists():
                async with self:
                    self.tagging_message = "Database not found."
                    self.is_tagging = False
                return

            db = SQLiteManager(str(db_path))
            db.connect()

            # Get tracks to tag
            tracks = db.get_tracks_by_filter(
                genre=self.genre_filter if self.genre_filter else None,
                year_min=self.year_min,
                year_max=self.year_max,
                artist=self.artist_filter if self.artist_filter else None,
                has_no_tags=self.has_no_tags
            )

            if not tracks:
                async with self:
                    self.tagging_message = "No tracks found matching filters."
                    self.is_tagging = False
                db.close()
                return

            # Set up AI provider
            from plexmix.ai import get_ai_provider
            from plexmix.config.credentials import get_google_api_key, get_openai_api_key, get_anthropic_api_key, get_cohere_api_key
            
            ai_provider_name = settings.ai.default_provider or "gemini"
            api_key = None

            provider_alias = "claude" if ai_provider_name == "anthropic" else ai_provider_name

            if provider_alias == "gemini":
                api_key = get_google_api_key()
            elif provider_alias == "openai":
                api_key = get_openai_api_key()
            elif provider_alias == "claude":
                api_key = get_anthropic_api_key()
            elif provider_alias == "cohere":
                api_key = get_cohere_api_key()

            try:
                ai_provider = get_ai_provider(
                    provider_name=ai_provider_name,
                    api_key=api_key,
                    model=settings.ai.model,
                    temperature=settings.ai.temperature,
                    local_mode=settings.ai.local_mode,
                    local_endpoint=settings.ai.local_endpoint,
                    local_auth_token=settings.ai.local_auth_token,
                    local_max_output_tokens=settings.ai.local_max_output_tokens,
                )
            except Exception as e:
                async with self:
                    self.tagging_message = f"Error initializing AI provider: {str(e)}"
                    self.is_tagging = False
                db.close()
                return

            tag_generator = TagGenerator(ai_provider)

            # Calculate batches
            batch_size = 20
            total_batches = (len(tracks) + batch_size - 1) // batch_size

            async with self:
                self.total_batches = total_batches
                self.tagging_message = f"Tagging {len(tracks)} tracks in {total_batches} batches..."

            # Progress callback
            start_time = time.time()

            def progress_callback(batch_num: int, total: int, tracks_tagged: int):
                elapsed = time.time() - start_time
                if tracks_tagged > 0:
                    time_per_track = elapsed / tracks_tagged
                    remaining_tracks = len(tracks) - tracks_tagged
                    estimated_remaining = int(time_per_track * remaining_tracks)
                else:
                    estimated_remaining = 0

                async def update_progress():
                    async with self:
                        self.current_batch = batch_num
                        self.tags_generated_count = tracks_tagged
                        self.tagging_progress = int((tracks_tagged / len(tracks) * 100)) if tracks else 0
                        self.estimated_time_remaining = estimated_remaining
                        self.tagging_message = f"Processing batch {batch_num}/{total} - {tracks_tagged} tracks tagged"

                asyncio.create_task(update_progress())

            # Generate tags
            results = tag_generator.generate_tags_batch(
                tracks,
                batch_size=batch_size,
                progress_callback=progress_callback,
                cancel_event=_tagging_cancel_events.get(token)
            )

            # Save tags to database
            for track_id, tag_data in results.items():
                if tag_data['tags'] or tag_data['environments'] or tag_data['instruments']:
                    db.update_track_tags(
                        track_id,
                        tags=','.join(tag_data['tags']),
                        environments=','.join(tag_data['environments']),
                        instruments=','.join(tag_data['instruments'])
                    )

            db.close()

            # Reload recently tagged tracks
            self.load_recently_tagged()

            # Clean up cancel event
            if token in _tagging_cancel_events:
                del _tagging_cancel_events[token]

            async with self:
                self.is_tagging = False
                self.tagging_progress = 100
                self.tagging_message = ""

            yield rx.toast.success(f"Successfully tagged {self.tags_generated_count} tracks!")

        except Exception as e:
            # Clean up cancel event on error
            if token in _tagging_cancel_events:
                del _tagging_cancel_events[token]
            async with self:
                self.is_tagging = False
                self.tagging_message = ""

            yield rx.toast.error(f"Error during tagging: {str(e)}")

    def cancel_tagging(self):
        token = self.router.session.client_token
        if token in _tagging_cancel_events:
            _tagging_cancel_events[token].set()
            self.tagging_message = "Cancelling tagging..."

    def start_edit_tag(self, track: Dict[str, Any]):
        self.editing_track_id = track['id']
        self.edit_tags = track.get('tags', '')
        self.edit_environments = track.get('environments', '')
        self.edit_instruments = track.get('instruments', '')

    def cancel_edit(self):
        self.editing_track_id = None
        self.edit_tags = ""
        self.edit_environments = ""
        self.edit_instruments = ""

    def set_edit_tags(self, value: str):
        self.edit_tags = value

    def set_edit_environments(self, value: str):
        self.edit_environments = value

    def set_edit_instruments(self, value: str):
        self.edit_instruments = value

    @rx.event(background=True)
    async def save_tag_edit(self):
        async with self:
            if self.editing_track_id is None:
                return

            track_id = self.editing_track_id

        try:
            from plexmix.config.settings import Settings
            from plexmix.database.sqlite_manager import SQLiteManager

            settings = Settings.load_from_file()
            db_path = settings.database.get_db_path()

            db = SQLiteManager(str(db_path))
            db.connect()

            db.update_track_tags(
                track_id,
                tags=self.edit_tags,
                environments=self.edit_environments,
                instruments=self.edit_instruments
            )

            db.close()

            # Reload recently tagged tracks
            self.load_recently_tagged()

            async with self:
                self.editing_track_id = None
                self.edit_tags = ""
                self.edit_environments = ""
                self.edit_instruments = ""

            yield rx.toast.success("Tags updated successfully!")

        except Exception as e:
            yield rx.toast.error(f"Error saving tags: {str(e)}")

    def show_tag_all_confirmation(self):
        try:
            from plexmix.config.settings import Settings
            from plexmix.database.sqlite_manager import SQLiteManager

            settings = Settings.load_from_file()
            db_path = settings.database.get_db_path()

            if db_path.exists():
                with SQLiteManager(str(db_path)) as db:
                    self.untagged_track_count = db.count_untagged_tracks()
            else:
                self.untagged_track_count = 0
        except Exception as e:
            logger.error("Error counting untagged tracks: %s", e)
            self.untagged_track_count = 0

        self.show_tag_all_confirm = True

    def cancel_tag_all_confirm(self):
        self.show_tag_all_confirm = False

    def set_tag_all_confirm_open(self, is_open: bool):
        """Handle dialog open/close via on_open_change."""
        if not is_open:
            self.show_tag_all_confirm = False

    @rx.event(background=True)
    async def tag_all_untagged(self):
        async with self:
            self.show_tag_all_confirm = False
            self.genre_filter = ""
            self.year_min = None
            self.year_max = None
            self.artist_filter = ""
            self.has_no_tags = True

        await self.preview_selection()

        # Give UI time to update
        await asyncio.sleep(0.5)

        if self.preview_count > 0:
            await self.start_tagging()
