# Changelog

## [2.3.75] - 2026-02-20
### Added
- Upgraded core schema to MTProto Layer 222.
- Added native support for Bot API 9.4 colored inline buttons.

## [2.3.77] - 2026-03-13
### Changed
- Rebranded core framework to Srigram.
- Made the `signature` parameter in Client initialization optional (defaults to "Sri").
