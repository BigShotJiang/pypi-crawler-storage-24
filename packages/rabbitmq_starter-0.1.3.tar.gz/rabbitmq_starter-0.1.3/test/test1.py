from config import MQConfig
from connection import MQConnection
from producer import MQProducer

config = MQConfig(
    host="192.168.0.177",
    username="admin",
    password="LdeZYqzS809VbQfV"
)

conn = MQConnection(config)

producer = MQProducer(conn, config)

producer.send(
    "order_queue",
    {"order_id": 1}
)