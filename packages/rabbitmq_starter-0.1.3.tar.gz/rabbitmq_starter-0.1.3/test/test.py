from config import MQConfig
from decorator import mq_listener
from starter import MQStarter


@mq_listener("order_queue")
def handle_order(data):
    raise Exception("handle_order_delay")
    # logging.info("process order_queue1:", data)


config = MQConfig(
    host="192.168.0.177",
    username="admin",
    password="LdeZYqzS809VbQfV",
    redis_url=None
)

starter = MQStarter(config)

starter.start()