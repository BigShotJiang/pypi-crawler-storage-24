## 一、消费者示例

```python

import logging
import sys
import os

# 添加项目根目录到Python路径
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '../..')))

from src.config import MQConfig
from src.decorator import mq_listener
from src.starter import MQStarter

logging.basicConfig(level=logging.INFO,
                    format='%(asctime)s - %(levelname)s - %(message)s')


@mq_listener("order_queue")
def handle_order(data):
    raise Exception("handle_order_delay")
    # logging.info("process order_queue1:", data)


@mq_listener("order_queue_delay")
def handle_order_delay(data):
    logging.info(f"process order_queue_delay:{data}")


config = MQConfig(
    host="192.168.0.177",
    username="admin",
    password="LdeZYqzS809VbQfV",
    redis_url=None
)

starter = MQStarter(config)

starter.start()

```


## 二、生产者示例

````python
import sys
import os

# 添加项目根目录到Python路径
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '../..')))

from src.config import MQConfig
from src.connection import MQConnection
from src.producer import MQProducer

config = MQConfig(
    host="192.168.0.177",
    username="admin",
    password="LdeZYqzS809VbQfV"
)

conn = MQConnection(config)

producer = MQProducer(conn, config)

producer.send(
    "order_queue",
    {"order_id": 1}
)

producer.send_delay(
    "order_queue_delay",
    {"order_id": 1},
    2000
)
producer.send_delay(
    "order_queue_delay",
    {"order_id": 2},
    6000
)
producer.send_delay(
    "order_queue_delay",
    {"order_id": 3},
    10000
)
````