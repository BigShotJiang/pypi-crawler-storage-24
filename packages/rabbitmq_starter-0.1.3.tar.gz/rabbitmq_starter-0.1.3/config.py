from dataclasses import dataclass

@dataclass
class MQConfig:
    """RabbitMQ配置类
    
    用于存储RabbitMQ连接和消息处理的配置信息
    """
    
    # RabbitMQ服务器配置
    host: str = "localhost"  # RabbitMQ服务器主机地址
    port: int = 5672  # RabbitMQ服务器端口
    username: str = "admin"  # RabbitMQ用户名
    password: str = "admin"  # RabbitMQ密码
    vhost: str = "/"  # RabbitMQ虚拟主机

    # 连接重试与心跳配置
    connection_attempts: int | None = None  # 最大重试次数，None 表示无限重试
    retry_interval: int = 5  # 重试间隔秒数
    heartbeat: int = 60  # 心跳间隔秒数

    # Redis配置（用于幂等性处理）
    redis_url: str | None = None  # Redis连接URL，为None时不使用幂等性

    # 消费者配置
    prefetch: int = 10  # 每个消费者的预取数量
    workers: int = 5  # 消费者线程池大小

    # 交换机配置
    delay_exchange: str = "delay_exchange"  # 延迟交换机名称
    dlx_exchange: str = "dlx_exchange"  # 死信交换机名称