_listener_registry = []  # 监听器注册表


def mq_listener(queue):
    """消息监听器装饰器
    
    用于注册消息处理函数到指定的队列
    
    Args:
        queue: 队列名称
        
    Returns:
        function: 装饰器函数
    """


    def wrapper(func):
        """装饰器包装函数
        
        Args:
            func: 消息处理函数
            
        Returns:
            function: 原函数
        """
        # 将队列和处理函数添加到注册表
        _listener_registry.append((queue, func))

        return func

    return wrapper