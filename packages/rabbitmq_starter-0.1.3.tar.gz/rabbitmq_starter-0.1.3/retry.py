class RetryPolicy:
    """重试策略类
    
    定义消息处理失败时的重试延迟策略
    """

    # 重试延迟序列（秒）
    RETRY = [
        10,    # 10秒
        30,    # 30秒
        60,    # 1分钟
        300,   # 5分钟
        600,   # 10分钟
        1800   # 30分钟
    ]

    def get_delay(self, retry):
        """获取重试延迟
        
        Args:
            retry: 重试次数
            
        Returns:
            int or None: 延迟时间（毫秒），如果达到最大重试次数则返回None
        """
        if retry >= len(self.RETRY):
            return None  # 达到最大重试次数

        return self.RETRY[retry] * 1000  # 转换为毫秒