"""Shared adapter registration for CLI commands (run, start, replay)."""

from __future__ import annotations

from binex.adapters.local import LocalPythonAdapter
from binex.models.artifact import Artifact, Lineage
from binex.models.task import TaskNode
from binex.models.workflow import WorkflowSpec
from binex.runtime.dispatcher import Dispatcher


async def _default_handler(task: TaskNode, inputs: list[Artifact]) -> list[Artifact]:
    """Default local handler that echoes input artifacts."""
    content = {a.id: a.content for a in inputs} if inputs else {"msg": "no input"}
    return [
        Artifact(
            id=f"art_{task.node_id}",
            run_id=task.run_id,
            type="result",
            content=content,
            lineage=Lineage(
                produced_by=task.node_id,
                derived_from=[a.id for a in inputs],
            ),
        )
    ]


def register_workflow_adapters(
    dispatcher: Dispatcher,
    spec: WorkflowSpec,
    *,
    agent_swaps: dict[str, str] | None = None,
    workflow_dir: str | None = None,
) -> None:
    """Register adapters for all agents in a workflow spec.

    Handles local://, llm://, human://, and a2a:// prefixes.
    Skips agents already registered in the dispatcher.
    """
    for node in spec.nodes.values():
        if agent_swaps:
            agent = agent_swaps.get(node.id, node.agent)
        else:
            agent = node.agent

        if agent in dispatcher._adapters:
            continue

        if agent.startswith("local://"):
            dispatcher.register_adapter(
                agent, LocalPythonAdapter(handler=_default_handler),
            )
        elif agent.startswith("llm://"):
            from binex.adapters.llm import LLMAdapter

            model = agent.removeprefix("llm://")
            config = node.config
            dispatcher.register_adapter(
                agent,
                LLMAdapter(
                    model=model,
                    api_base=config.get("api_base"),
                    api_key=config.get("api_key"),
                    temperature=config.get("temperature"),
                    max_tokens=config.get("max_tokens"),
                    workflow_dir=workflow_dir,
                ),
            )
        elif agent == "human://input":
            from binex.adapters.human import HumanInputAdapter

            dispatcher.register_adapter(agent, HumanInputAdapter())
        elif agent.startswith("human://"):
            from binex.adapters.human import HumanApprovalAdapter

            dispatcher.register_adapter(agent, HumanApprovalAdapter())
        elif agent.startswith("a2a://"):
            from binex.adapters.a2a import A2AAgentAdapter

            endpoint = agent.removeprefix("a2a://")
            dispatcher.register_adapter(agent, A2AAgentAdapter(endpoint=endpoint))
