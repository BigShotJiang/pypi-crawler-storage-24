"""stych - AI-powered solution builder. Coming soon."""
__version__ = "0.0.1"
