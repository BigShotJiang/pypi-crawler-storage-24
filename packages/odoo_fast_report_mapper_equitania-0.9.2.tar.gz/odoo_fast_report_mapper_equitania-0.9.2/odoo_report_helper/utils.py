# Copyright 2014-now Equitania Software GmbH - Pforzheim - Germany
# License AGPL-3.0 or later (http://www.gnu.org/licenses/agpl).

import logging
import os

import yaml
from odoorpc_toolbox import ODOO

logger = logging.getLogger(__name__)


def prepare_connection(url, port):
    """
    Build the OdooRPC connection object
    :param url: Odoo URL
    :param port: Port number
    """
    port = int(port)
    _protocol = "jsonrpc+ssl"
    if url.startswith("https"):
        url = url.replace("https:", "")
        if port <= 0:
            port = 443

    elif url.startswith("http:"):
        url = url.replace("http:", "")
        _protocol = "jsonrpc"

    while url and url.startswith("/"):
        url = url[1:]

    while url and url.endswith("/"):
        url = url[:-1]

    while url and url.endswith("\\"):
        url = url[:-1]

    connection = ODOO(url, port=port, protocol=_protocol)
    return connection


def fire_all_functions(function_list: list):
    """
    Execute each function in a list
    :param function_list: List of functions
    """
    for func in function_list:
        func()


def self_clean(input_dictionary: dict) -> dict:
    """
    Remove duplicates in dictionary
    :param: input_dictionary
    :return: return_dict
    """
    return_dict = input_dictionary.copy()
    for key, value in input_dictionary.items():
        return_dict[key] = list(dict.fromkeys(value))
    return return_dict


def parse_yaml(yaml_file):
    """
    Parse yaml file to object and return it
    :param: yaml_file: path to yaml file
    :return: yaml_object
    """
    with open(yaml_file, encoding="utf-8") as stream:
        try:
            return yaml.safe_load(stream)
        except yaml.YAMLError as exc:
            logger.error(f"YAML parsing error in file: {yaml_file}")
            logger.exception(exc)
            return False


def parse_yaml_folder_with_filenames(path):
    """
    Parse multiple yaml files and return them with their filenames.
    :param: path: path to yaml files directory
    :return: list of (filename, yaml_object) tuples, sorted by filename
    """
    resolved_path = os.path.realpath(path)
    if not os.path.isdir(resolved_path):
        raise FileNotFoundError(f"Directory not found: {path}")

    yaml_objects = []
    for file in sorted(os.listdir(resolved_path)):
        if file.endswith(".yaml"):
            file_path = os.path.realpath(os.path.join(resolved_path, file))
            # Ensure resolved file path stays within target directory
            if not file_path.startswith(resolved_path + os.sep):
                logger.warning(f"Skipping file outside target directory: {file}")
                continue
            yaml_object = parse_yaml(file_path)
            if yaml_object:
                yaml_objects.append((file, yaml_object))
    return yaml_objects


def parse_yaml_folder(path):
    """
    Parse multiple yaml files to list of objects and return them
    :param: path: path to yaml files directory
    :return: yaml_objects
    """
    return [obj for _, obj in parse_yaml_folder_with_filenames(path)]
