"""NEWT-based PBS queue adapter used for remote job submission and status."""

from __future__ import annotations

import getpass
import os

from fireworks.queue.queue_adapter import QueueAdapterBase
from fireworks.utilities.fw_utilities import get_fw_logger

try:
    from requests import Session
except ImportError:
    Session = None
    msg = "install the fireworks[newt] extra or the requests package to use PBSAdapterNEWT"
    get_fw_logger(__name__).warning(msg)

__author__ = "Shreyas Cholia, Anubhav Jain"
__copyright__ = "Copyright 2013, The Materials Project"
__maintainer__ = "Anubhav Jain"
__email__ = "ajain@lbl.gov"
__date__ = "Nov 21, 2013"


class PBSAdapterNEWT(QueueAdapterBase):
    """A special PBS adapter that works via the NEWT interface (https://newt.nersc.gov)
    Only intended for job submission via the RESTful NEWT web interface.
    """

    _fw_name = "PBSAdapter (NEWT)"
    template_file = os.path.join(os.path.dirname(__file__), "PBS_template.txt")
    submit_cmd = ""
    q_name = "pbs_newt"
    defaults = {}
    resource = "carver"  # 'carver' or 'hopper'
    _session = None

    def submit_to_queue(self, script_file: str) -> int:
        self._init_auth_session()
        jobfile = os.path.join(os.getcwd(), script_file)
        resp = PBSAdapterNEWT._session.post(f"https://newt.nersc.gov/newt/queue/{self.resource}/", {"jobfile": jobfile})
        return int(resp.json()["jobid"].split(".")[0])

    def get_njobs_in_queue(self, username: str | None = None) -> int:
        if username is None:
            username = getpass.getuser()

        resp = Session().get(f"https://newt.nersc.gov/newt/queue/{self.resource}/?user={username}")
        return len(resp.json())

    @staticmethod
    def _init_auth_session(max_pw_requests: int = 3) -> None:
        """Initialize the _session class var with an authorized session. Asks for a /
        password in new sessions, skips PW check for previously authenticated sessions.
        """
        username = getpass.getuser()
        if not PBSAdapterNEWT._session:
            PBSAdapterNEWT._session = Session()  # create new session
        else:
            # are we already authenticated?
            resp = PBSAdapterNEWT._session.get("https://newt.nersc.gov/newt/auth")
            if resp.json()["auth"] and resp.json()["username"] == username:
                return
        # assert: not already authenticated, ask for a PW and authenticate
        pw_iterations = 0
        while pw_iterations < max_pw_requests:
            password = getpass.getpass()
            resp = PBSAdapterNEWT._session.post(
                "https://newt.nersc.gov/newt/auth", {"username": username, "password": password}
            )
            if resp.json()["auth"] and resp.json()["username"] == username:
                return
            pw_iterations += 1
        raise ValueError("Could not get authorized connection to NEWT!")
