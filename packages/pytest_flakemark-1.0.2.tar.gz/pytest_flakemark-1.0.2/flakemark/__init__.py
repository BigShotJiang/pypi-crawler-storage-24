# flakemark/__init__.py
# FLAKEMARK — Differential Execution Tracer for Flaky Test Root Cause Diagnosis
# Copyright: Khushdeep Sharma, Chitkara University, 2026

from flakemark.engine import FlakeMark
from flakemark.differ.divergence import DivergenceReport, DivergenceType

__version__ = "1.0.0"
__author__  = "Khushdeep Sharma — Chitkara University 2026"
__email__   = "itskhushsharma@gmail.com"
__all__     = ["FlakeMark", "DivergenceReport", "DivergenceType"]
