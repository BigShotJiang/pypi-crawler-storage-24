"""
flakemark/engine.py

FLAKEMARK — Main Engine.

Usage:
    from flakemark import FlakeMark

    # From a source string
    report = FlakeMark.diagnose_source(source, "test_func", runs=6)
    print(report)

    # From a real test file
    report = FlakeMark.diagnose_file("tests/test_api.py", "test_login")
    print(report)

    # Batch scan entire folder
    results = FlakeMark.diagnose_batch("tests/")
    for name, report in results.items():
        if report.is_found():
            print(name, report.primary.line, report.primary.fix)

Copyright: Khushdeep Sharma, Chitkara University, 2026
"""

import os
import ast
import glob
import threading
from pathlib import Path

from flakemark.tracer.instrument import ExecutionTrace, run_instrumented
from flakemark.differ.divergence import DifferentialAnalyser, DivergenceReport


class FlakeMark:
    """
    FLAKEMARK main engine.

    Runs a test function N times concurrently, collects ExecutionTraces,
    separates passing and failing runs, and passes them to
    DifferentialAnalyser to find the exact divergence point.

    Copyright: Khushdeep Sharma, Chitkara University, 2026
    """

    def __init__(
        self,
        runs:         int = 4,
        timeout:      int = 30,
        project_root: str | None = None,
    ) -> None:
        self.runs         = max(runs, 2)
        self.timeout      = timeout
        self.project_root = project_root or os.getcwd()
        self.analyser     = DifferentialAnalyser()

    # ─────────────────────────────────────────────────────────
    # PUBLIC API
    # ─────────────────────────────────────────────────────────

    @classmethod
    def diagnose_source(
        cls,
        source:         str,
        test_func_name: str,
        runs:           int = 4,
        project_root:   str | None = None,
    ) -> DivergenceReport:
        """
        Diagnose a flaky test from a source code string.

        Args:
            source:         Python source containing the test function.
            test_func_name: Name of the test function to diagnose.
            runs:           How many times to run (more = better for rare flakes).
            project_root:   Root of your project for correct imports.

        Returns:
            DivergenceReport — print it to see the full diagnosis.

        Example:
            from flakemark import FlakeMark

            source = '''
            import random
            def test_flaky():
                result = random.randint(0, 1)
                assert result == 1
            '''
            report = FlakeMark.diagnose_source(source, "test_flaky", runs=10)
            print(report)
        """
        root = project_root or os.getcwd()
        fm   = cls(runs=runs, project_root=root)
        return fm._diagnose(source, "<string>", test_func_name)

    @classmethod
    def diagnose_file(
        cls,
        filepath:       str,
        test_func_name: str,
        runs:           int = 4,
        project_root:   str | None = None,
    ) -> DivergenceReport:
        """
        Diagnose a flaky test from a .py file.

        Args:
            filepath:       Path to the test file.
            test_func_name: Name of the test function inside the file.
            runs:           How many times to run.
            project_root:   Root of your project. Auto-detected if None.

        Returns:
            DivergenceReport — print it to see the full diagnosis.

        Example:
            from flakemark import FlakeMark

            report = FlakeMark.diagnose_file(
                filepath       = "tests/test_api.py",
                test_func_name = "test_user_session",
                runs           = 6,
                project_root   = "/path/to/myproject",
            )
            print(report)
        """
        source = Path(filepath).read_text(encoding="utf-8")
        root   = project_root or str(Path(filepath).parent.parent)
        fm     = cls(runs=runs, project_root=root)
        return fm._diagnose(source, filepath, test_func_name)

    @classmethod
    def diagnose_batch(
        cls,
        test_dir: str,
        pattern:  str = "test_*.py",
        runs:     int = 4,
    ) -> dict[str, DivergenceReport]:
        """
        Diagnose every test function in every matching file in a directory.

        Args:
            test_dir: Directory to scan (searches recursively).
            pattern:  Glob pattern for test files (default: test_*.py).
            runs:     How many times to run each test.

        Returns:
            Dict mapping "filepath::test_name" to DivergenceReport.

        Example:
            from flakemark import FlakeMark

            results = FlakeMark.diagnose_batch("tests/", runs=4)

            flaky = {k: v for k, v in results.items() if v.is_found()}
            print(f"FLAKEMARK found {len(flaky)} flaky tests:")
            for name, report in flaky.items():
                print(f"  {name}")
                print(f"  Line {report.primary.line} — {report.primary.divergence_type.value}")
                print(f"  Fix: {report.primary.fix[:60]}")
        """
        results:      dict[str, DivergenceReport] = {}
        project_root: str = str(Path(test_dir).parent)
        files = glob.glob(
            os.path.join(test_dir, "**", pattern),
            recursive=True,
        )

        for filepath in sorted(files):
            source = Path(filepath).read_text(encoding="utf-8")
            try:
                tree = ast.parse(source)
            except SyntaxError:
                continue

            for node in ast.walk(tree):
                if (isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))
                        and node.name.startswith("test_")):
                    key = f"{filepath}::{node.name}"
                    try:
                        fm     = cls(runs=runs, project_root=project_root)
                        report = fm._diagnose(source, filepath, node.name)
                        results[key] = report
                    except Exception:
                        pass  # skip silently — do not crash the batch

        return results

    # ─────────────────────────────────────────────────────────
    # INTERNAL
    # ─────────────────────────────────────────────────────────

    def _diagnose(
        self,
        source:    str,
        filepath:  str,
        func_name: str,
    ) -> DivergenceReport:
        """
        Collect N execution traces concurrently, then analyse.

        Strategy:
          - If we have at least one pass and one fail, compare those two.
            This is the ideal case — maximum signal.
          - If all runs have the same outcome, compare fastest vs slowest.
            Weaker signal but still useful for timing-related flakes.
          - If fewer than 2 traces collected, return empty report.
        """
        traces = self._collect_traces(source, filepath, func_name)

        passing = [t for t in traces if t.outcome == "pass"]
        failing = [t for t in traces if t.outcome == "fail"]

        if passing and failing:
            # Best case — real pass vs real fail
            trace_a = passing[0]
            trace_b = failing[0]
        elif len(traces) >= 2:
            # All same outcome — compare fastest vs slowest
            by_duration = sorted(traces, key=lambda t: t.duration_ms)
            trace_a = by_duration[0]   # fastest
            trace_b = by_duration[-1]  # slowest
        else:
            empty = ExecutionTrace(run_id=99, outcome="unknown")
            return DivergenceReport(
                trace_a=traces[0] if traces else empty,
                trace_b=empty,
                summary=(
                    "FLAKEMARK: Need at least 2 completed runs. "
                    "Try increasing the timeout parameter."
                ),
            )

        return self.analyser.analyse(trace_a, trace_b)

    def _collect_traces(
        self,
        source:    str,
        filepath:  str,
        func_name: str,
    ) -> list[ExecutionTrace]:
        """
        Run the test self.runs times concurrently using threads.

        All runs start simultaneously to maximise chance of exposing
        race conditions and timing-dependent flakiness.
        """
        traces: list[ExecutionTrace | None] = [None] * self.runs
        threads: list[threading.Thread]     = []

        def run_one(run_id: int) -> None:
            traces[run_id] = run_instrumented(
                source        = source,
                filename      = filepath,
                test_func_name= func_name,
                run_id        = run_id,
                project_root  = self.project_root,
                timeout       = self.timeout,
            )

        for i in range(self.runs):
            t = threading.Thread(target=run_one, args=(i,), daemon=True)
            threads.append(t)

        # Start all threads simultaneously
        for t in threads:
            t.start()

        # Wait for all to complete
        for t in threads:
            t.join(timeout=self.timeout + 5)

        return [t for t in traces if t is not None]
