"""
flakemark/pytest_plugin.py

FLAKEMARK — pytest plugin integration.

Registers FLAKEMARK as a pytest plugin via entry_points in setup.py.
Adds --flakemark-diagnose CLI flag.
When enabled, automatically diagnoses any failing test.

Usage:
    pytest --flakemark-diagnose tests/

Copyright: Khushdeep Sharma, Chitkara University, 2026
"""

import inspect
import textwrap
import pytest

from flakemark.engine import FlakeMark


def pytest_addoption(parser) -> None:
    """Add FLAKEMARK CLI options to pytest."""
    group = parser.getgroup("flakemark")
    group.addoption(
        "--flakemark-diagnose",
        action="store_true",
        default=False,
        help="FLAKEMARK: Automatically diagnose failing tests for flakiness root cause.",
    )
    group.addoption(
        "--flakemark-runs",
        type=int,
        default=4,
        help="FLAKEMARK: Number of diagnostic runs per test (default: 4).",
    )


@pytest.hookimpl(hookwrapper=True)
def pytest_runtest_makereport(item, call):
    """
    Hook: after each test call, if FLAKEMARK is enabled and test failed,
    run diagnosis and attach the report to the pytest failure output.
    """
    # Execute all other hooks to obtain the final report object
    outcome = yield
    rep = outcome.get_result()

    # Only diagnose actual test execution failures (not setup/teardown)
    if rep.when != "call" or not rep.failed:
        return

    config = item.config
    if not config.getoption("--flakemark-diagnose", default=False):
        return

    try:
        test_func = item.function
        source    = textwrap.dedent(inspect.getsource(test_func))
        filepath  = inspect.getfile(test_func)
        func_name = test_func.__name__
        runs      = config.getoption("--flakemark-runs", default=4)

        fm     = FlakeMark(runs=runs)
        report = fm._diagnose(source, filepath, func_name)

        if report.is_found():
            rep.sections.append(("FLAKEMARK ROOT CAUSE DIAGNOSIS", str(report)))
        else:
            rep.sections.append((
                "FLAKEMARK", 
                "No divergence detected on this run. Try --flakemark-runs=10 for low-frequency flakes."
            ))

    except Exception as e:
        rep.sections.append(("FLAKEMARK ERROR", f"Diagnosis failed: {e}"))


@pytest.fixture
def flakemark_diagnose(request):
    """
    Pytest fixture for on-demand FLAKEMARK diagnosis inside tests.

    Usage:
        def test_something(flakemark_diagnose):
            from myapp import my_flaky_function
            report = flakemark_diagnose(my_flaky_function_source, "my_flaky_function")
            assert not report.is_found(), str(report)
    """
    def _diagnose(source: str, func_name: str, runs: int = 4):
        return FlakeMark.diagnose_source(source, func_name, runs=runs)
    return _diagnose
