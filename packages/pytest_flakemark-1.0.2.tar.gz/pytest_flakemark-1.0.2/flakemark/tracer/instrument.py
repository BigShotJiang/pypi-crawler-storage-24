"""
flakemark/tracer/instrument.py

FLAKEMARK — AST-level execution tracer with subprocess isolation.

ORIGINAL CONTRIBUTION:
  Instruments a Python test function at the AST level by injecting
  __fm_record__() calls at every assignment, function call, and return.
  Runs the instrumented test as a subprocess so real project imports
  work correctly. Records every operation as a TraceEvent.
  Two runs produce two ExecutionTraces that the DifferentialAnalyser compares.

Copyright: Khushdeep Sharma, Chitkara University, 2026
"""

import ast
import sys
import os
import time
import json
import tempfile
import subprocess
import textwrap
from dataclasses import dataclass, field
from typing import Any


# ─────────────────────────────────────────────────────────────
# DATA STRUCTURES
# ─────────────────────────────────────────────────────────────

@dataclass
class TraceEvent:
    """
    One recorded operation during test execution.

    kind:       call / return / assign / exception
    file:       source file path
    line:       line number
    func:       enclosing function name
    elapsed_ms: milliseconds since trace start
    value:      assigned value, return value, or None
    thread_id:  always 0 in subprocess mode
    """
    kind:       str
    file:       str
    line:       int
    func:       str
    elapsed_ms: float
    value:      Any = None
    thread_id:  int = 0

    def to_dict(self) -> dict:
        return {
            "kind":       self.kind,
            "file":       self.file,
            "line":       self.line,
            "func":       self.func,
            "elapsed_ms": self.elapsed_ms,
            "value":      str(self.value)[:80] if self.value is not None else None,
            "thread_id":  self.thread_id,
        }

    @classmethod
    def from_dict(cls, d: dict) -> "TraceEvent":
        return cls(**d)

    def __repr__(self) -> str:
        v = f" → {self.value}" if self.value else ""
        return f"[{self.elapsed_ms:.1f}ms] {self.kind:8s} {self.file}:{self.line}{v}"


@dataclass
class ExecutionTrace:
    """
    Complete record of one test execution.

    Contains an ordered list of TraceEvents plus the final outcome.
    Two ExecutionTraces are passed to DifferentialAnalyser to find
    the divergence point.
    """
    run_id:      int
    outcome:     str              # "pass" or "fail"
    error:       str | None = None
    events:      list[TraceEvent] = field(default_factory=list)
    duration_ms: float = 0.0

    def add(self, event: TraceEvent) -> None:
        self.events.append(event)

    def __len__(self) -> int:
        return len(self.events)

    def to_dict(self) -> dict:
        return {
            "run_id":      self.run_id,
            "outcome":     self.outcome,
            "error":       self.error,
            "duration_ms": self.duration_ms,
            "events":      [e.to_dict() for e in self.events],
        }

    @classmethod
    def from_dict(cls, d: dict) -> "ExecutionTrace":
        t = cls(
            run_id=d["run_id"],
            outcome=d["outcome"],
            error=d.get("error"),
            duration_ms=d.get("duration_ms", 0.0),
        )
        t.events = [TraceEvent.from_dict(e) for e in d.get("events", [])]
        return t

    def __repr__(self) -> str:
        return (
            f"ExecutionTrace(run={self.run_id}, "
            f"outcome={self.outcome}, "
            f"events={len(self.events)}, "
            f"duration={self.duration_ms:.1f}ms)"
        )


# ─────────────────────────────────────────────────────────────
# AST TRANSFORMER
# ─────────────────────────────────────────────────────────────

class TraceInserter(ast.NodeTransformer):
    """
    ORIGINAL: AST NodeTransformer that injects __fm_record__() calls
    into test source code before execution.

    Instruments:
      - Function/async function entry  → kind="call"
      - Simple variable assignments    → kind="assign"
      - Return statements              → kind="return"

    This is the white-box approach. Every existing flaky test tool
    reruns and observes outcomes. FLAKEMARK instruments and traces
    the execution itself.

    Copyright: Khushdeep Sharma, Chitkara University, 2026
    """

    def __init__(self, filename: str) -> None:
        self.filename = filename
        self.is_async = False

    def _rec(self, kind: str, line: int, func: str,
             value_expr=None) -> ast.Call:
        """Build the AST node for a __fm_record__() call."""
        args = [
            ast.Constant(value=kind),
            ast.Constant(value=self.filename),
            ast.Constant(value=line),
            ast.Constant(value=func),
        ]
        keywords = []
        if value_expr is not None:
            keywords.append(ast.keyword(arg="value", value=value_expr))
        return ast.Call(
            func=ast.Name(id="__fm_record__", ctx=ast.Load()),
            args=args,
            keywords=keywords,
        )

    def visit_AsyncFunctionDef(self, node: ast.AsyncFunctionDef):
        """Handle async def test functions."""
        self.is_async = True
        return self.visit_FunctionDef(node)

    def visit_FunctionDef(self, node: ast.FunctionDef):
        """Instrument function entry with a call event."""
        self.generic_visit(node)
        entry = ast.Expr(value=self._rec("call", node.lineno, node.name))
        node.body.insert(0, entry)
        ast.fix_missing_locations(entry)
        return node

    def visit_Assign(self, node: ast.Assign):
        """Instrument simple name assignments to capture assigned value."""
        self.generic_visit(node)
        if (len(node.targets) == 1
                and isinstance(node.targets[0], ast.Name)):
            name = node.targets[0].id
            rec = ast.Expr(value=self._rec(
                "assign", node.lineno, "",
                ast.Name(id=name, ctx=ast.Load()),
            ))
            ast.fix_missing_locations(rec)
            return [node, rec]
        return node

    def visit_Return(self, node: ast.Return):
        """Instrument return statements to capture return value."""
        self.generic_visit(node)
        if node.value is not None:
            tmp = "__fm_ret__"
            assign = ast.Assign(
                targets=[ast.Name(id=tmp, ctx=ast.Store())],
                value=node.value,
            )
            rec = ast.Expr(value=self._rec(
                "return", node.lineno, "",
                ast.Name(id=tmp, ctx=ast.Load()),
            ))
            new_ret = ast.Return(
                value=ast.Name(id=tmp, ctx=ast.Load())
            )
            for n in [assign, rec, new_ret]:
                ast.copy_location(n, node)
                ast.fix_missing_locations(n)
            return [assign, rec, new_ret]
        return node


# ─────────────────────────────────────────────────────────────
# SUBPROCESS RUNNER TEMPLATE
# ─────────────────────────────────────────────────────────────

_FM_RUNNER_TEMPLATE = '''\
import sys, json, time, threading, asyncio

{source}

_fm_events = []
_fm_start  = time.perf_counter()

def __fm_record__(kind, file, line, func, value=None):
    """Injected by FLAKEMARK TraceInserter — records each operation."""
    elapsed = (time.perf_counter() - _fm_start) * 1000.0
    _fm_events.append({{
        "kind":       kind,
        "file":       file,
        "line":       line,
        "func":       func,
        "elapsed_ms": round(elapsed, 3),
        "value":      str(value)[:80] if value is not None else None,
        "thread_id":  0,
    }})

_fm_outcome  = "pass"
_fm_error    = None
_fm_t0       = time.perf_counter()

try:
    _fm_fn = {func_name}
    if asyncio.iscoroutinefunction(_fm_fn):
        asyncio.run(_fm_fn())
    else:
        _fm_fn()
except AssertionError as _e:
    _fm_outcome = "fail"
    _fm_error   = f"AssertionError: {{_e}}"
except Exception as _e:
    _fm_outcome = "fail"
    _fm_error   = f"{{type(_e).__name__}}: {{_e}}"

_fm_duration = (time.perf_counter() - _fm_t0) * 1000.0

print("__FM_RESULT__:" + json.dumps({{
    "run_id":      {run_id},
    "outcome":     _fm_outcome,
    "error":       _fm_error,
    "duration_ms": round(_fm_duration, 3),
    "events":      _fm_events,
}}))
'''


# ─────────────────────────────────────────────────────────────
# PUBLIC FUNCTIONS
# ─────────────────────────────────────────────────────────────

def instrument_source(source: str, filename: str) -> tuple[str, bool]:
    """
    Parse source → transform with TraceInserter → unparse back to source.

    Returns:
        (instrumented_source, is_async)

    Copyright: Khushdeep Sharma, Chitkara University, 2026
    """
    tree = ast.parse(textwrap.dedent(source))
    inserter = TraceInserter(filename)
    new_tree = inserter.visit(tree)
    ast.fix_missing_locations(new_tree)
    return ast.unparse(new_tree), inserter.is_async


def run_instrumented(
    source:         str,
    filename:       str,
    test_func_name: str,
    run_id:         int,
    project_root:   str | None = None,
    timeout:        int = 30,
) -> ExecutionTrace:
    """
    ORIGINAL: Runs an instrumented test as a subprocess.

    The subprocess inherits sys.path, the Python interpreter, and all
    environment variables — so real project imports work correctly.

    v1 used exec() which broke on project imports.
    v2 writes a temp .py file and runs it as a real subprocess.

    The subprocess prints one line: __FM_RESULT__:{json}
    FLAKEMARK reads and deserialises this line into an ExecutionTrace.

    Copyright: Khushdeep Sharma, Chitkara University, 2026
    """
    try:
        instrumented, _ = instrument_source(source, filename)
    except SyntaxError as e:
        return ExecutionTrace(
            run_id=run_id,
            outcome="fail",
            error=f"FLAKEMARK SyntaxError during instrumentation: {e}",
        )

    runner_code = _FM_RUNNER_TEMPLATE.format(
        source=instrumented,
        func_name=test_func_name,
        run_id=run_id,
    )

    cwd = project_root or os.getcwd()
    env = os.environ.copy()

    tmp_path = None
    try:
        with tempfile.NamedTemporaryFile(
            mode="w", suffix=".py",
            delete=False, encoding="utf-8",
            prefix="flakemark_run_",
        ) as f:
            f.write(runner_code)
            tmp_path = f.name

        proc = subprocess.run(
            [sys.executable, tmp_path],
            capture_output=True,
            text=True,
            timeout=timeout,
            cwd=cwd,
            env=env,
        )

        # Parse the __FM_RESULT__ line from stdout
        for line in proc.stdout.splitlines():
            if line.startswith("__FM_RESULT__:"):
                data = json.loads(line[len("__FM_RESULT__:"):])
                return ExecutionTrace.from_dict(data)

        # No result line found — subprocess crashed
        stderr_tail = proc.stderr[-500:] if proc.stderr else "no stderr"
        return ExecutionTrace(
            run_id=run_id,
            outcome="fail",
            error=(
                f"FLAKEMARK: subprocess exited with code {proc.returncode}. "
                f"stderr: {stderr_tail}"
            ),
        )

    except subprocess.TimeoutExpired:
        return ExecutionTrace(
            run_id=run_id,
            outcome="fail",
            error=f"FLAKEMARK: subprocess timed out after {timeout}s",
        )
    except Exception as e:
        return ExecutionTrace(
            run_id=run_id,
            outcome="fail",
            error=f"FLAKEMARK: runner error: {e}",
        )
    finally:
        if tmp_path:
            try:
                os.unlink(tmp_path)
            except OSError:
                pass
