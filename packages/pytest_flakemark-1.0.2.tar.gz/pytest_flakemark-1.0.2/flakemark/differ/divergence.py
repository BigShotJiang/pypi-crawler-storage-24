"""
flakemark/differ/divergence.py

FLAKEMARK — Differential Execution Graph Analyser.

ORIGINAL ALGORITHM:
  Takes two ExecutionTrace objects (one passing, one failing).
  Walks both simultaneously using a two-pointer approach.
  At each matching operation pair, checks for:
    - timing delta (one run 3x+ slower)
    - value mismatch (same line, different value)
    - thread race (same op, different thread)
  At non-matching pairs, detects:
    - sequence break (completely different execution path)
    - missing event (one run skipped an operation)
  Before walking, detects:
    - early termination (one trace much shorter than other)

  Each divergence is classified into a DivergenceType and scored.
  The highest-confidence divergence becomes report.primary.
  report.primary tells you the file, line, cause, and fix.

Copyright: Khushdeep Sharma, Chitkara University, 2026
"""

from dataclasses import dataclass, field
from enum import Enum
from typing import Optional

from flakemark.tracer.instrument import ExecutionTrace, TraceEvent


# ─────────────────────────────────────────────────────────────
# DIVERGENCE CLASSIFICATION
# ─────────────────────────────────────────────────────────────

class DivergenceType(Enum):
    """
    ORIGINAL: Six-category classification of how two execution traces diverged.

    Each type maps to a deterministic root cause and a concrete fix.
    This taxonomy is an original contribution of FLAKEMARK.

    Copyright: Khushdeep Sharma, Chitkara University, 2026
    """
    VALUE_MISMATCH    = "value_mismatch"
    TIMING_DELTA      = "timing_delta"
    THREAD_RACE       = "thread_race"
    SEQUENCE_BREAK    = "sequence_break"
    MISSING_EVENT     = "missing_event"
    EARLY_TERMINATION = "early_termination"
    UNKNOWN           = "unknown"


# FLAKEMARK cause + fix map per divergence type
# Copyright: Khushdeep Sharma, Chitkara University, 2026
FM_EXPLANATIONS: dict[DivergenceType, dict[str, str]] = {
    DivergenceType.VALUE_MISMATCH: {
        "cause": "Non-deterministic value — shared mutable state or random source",
        "fix":   (
            "Use unittest.mock.patch() to mock the non-deterministic dependency. "
            "Ensure each test run starts with the same state."
        ),
    },
    DivergenceType.TIMING_DELTA: {
        "cause": "Race condition or timing dependency",
        "fix":   (
            "Replace time.sleep(N) with threading.Event().wait() "
            "or asyncio.wait_for(). Never hardcode sleep durations in tests."
        ),
    },
    DivergenceType.THREAD_RACE: {
        "cause": "Concurrency race — threads interleaved differently between runs",
        "fix":   (
            "Add threading.Lock() around shared resources. "
            "Use thread-safe queues or restructure with async/await."
        ),
    },
    DivergenceType.SEQUENCE_BREAK: {
        "cause": "Test order dependency — dirty state left by another test",
        "fix":   (
            "Add pytest fixtures or setUp/tearDown to reset all shared state "
            "before each test run."
        ),
    },
    DivergenceType.MISSING_EVENT: {
        "cause": "Conditional execution — branch depends on non-deterministic external state",
        "fix":   (
            "Mock the external dependency that controls the conditional "
            "so it behaves the same on every run."
        ),
    },
    DivergenceType.EARLY_TERMINATION: {
        "cause": "One run terminated early — timeout, crash, or unhandled exception",
        "fix":   (
            "Check the error field of the shorter trace. "
            "Add explicit timeouts and handle specific exception types."
        ),
    },
    DivergenceType.UNKNOWN: {
        "cause": "Unknown divergence",
        "fix":   "Investigate manually. Add assertions to narrow down the cause.",
    },
}

# Algorithm constants
FM_TIMING_RATIO         = 3.0   # one run must be 3x+ slower
FM_TIMING_MIN_MS        = 50.0  # AND at least 50ms different (avoids false positives)
FM_EARLY_TERM_RATIO     = 0.5   # if len_b / len_a < 0.5 → early termination
FM_LOOKAHEAD            = 5     # events to scan ahead for missing-event detection
FM_MAX_DIVERGENCES      = 5     # stop collecting after 5 divergences
FM_VALUE_KINDS          = {"assign", "return"}

# Confidence base scores per type (ORIGINAL scoring formula)
FM_CONFIDENCE_SCORES: dict[DivergenceType, float] = {
    DivergenceType.THREAD_RACE:       0.95,
    DivergenceType.TIMING_DELTA:      0.85,
    DivergenceType.VALUE_MISMATCH:    0.80,
    DivergenceType.SEQUENCE_BREAK:    0.70,
    DivergenceType.MISSING_EVENT:     0.60,
    DivergenceType.EARLY_TERMINATION: 0.55,
    DivergenceType.UNKNOWN:           0.20,
}


# ─────────────────────────────────────────────────────────────
# DIVERGENCE REPORT
# ─────────────────────────────────────────────────────────────

@dataclass
class DivergencePoint:
    """
    A single point where two execution traces diverged.
    Auto-populated with cause and fix from FM_EXPLANATIONS.
    """
    position:        int
    divergence_type: DivergenceType
    event_a:         Optional[TraceEvent]    # event from passing run
    event_b:         Optional[TraceEvent]    # event from failing run
    detail:          str = ""
    file:            str = ""
    line:            int = 0
    func:            str = ""
    cause:           str = ""
    fix:             str = ""

    def __post_init__(self) -> None:
        # Auto-populate file/line/func from the reference event
        ref = self.event_a or self.event_b
        if ref:
            self.file = ref.file
            self.line = ref.line
            self.func = ref.func
        # Auto-populate cause and fix from FLAKEMARK explanation map
        expl = FM_EXPLANATIONS.get(
            self.divergence_type,
            FM_EXPLANATIONS[DivergenceType.UNKNOWN]
        )
        self.cause = expl["cause"]
        self.fix   = expl["fix"]


@dataclass
class DivergenceReport:
    """
    Complete FLAKEMARK diagnosis report.

    primary:         The highest-confidence divergence — this is your bug.
    all_divergences: All divergences found (up to FM_MAX_DIVERGENCES).
    confidence:      Score of primary divergence (0.0 to 1.0).
    summary:         One-line summary string.

    Usage:
        report = FlakeMark.diagnose_source(source, "test_func")
        if report.is_found():
            print(report)          # full formatted output
            print(report.primary.line)   # just the line number
            print(report.primary.fix)    # just the fix
    """
    trace_a:         ExecutionTrace
    trace_b:         ExecutionTrace
    primary:         Optional[DivergencePoint]  = None
    all_divergences: list[DivergencePoint]      = field(default_factory=list)
    summary:         str   = ""
    confidence:      float = 0.0

    def is_found(self) -> bool:
        """Returns True if a divergence was found."""
        return self.primary is not None

    def __str__(self) -> str:
        sep = "-" * 56
        if not self.is_found():
            return "\n".join([
                sep,
                "FLAKEMARK - No divergence found",
                sep,
                self.summary,
                "Both traces are identical — test may not be reproducibly flaky.",
                "Try increasing runs= parameter for low-frequency flakes.",
                sep,
            ])
        p = self.primary
        return "\n".join([
            sep,
            "FLAKEMARK - Flaky Test Root Cause Found",
            sep,
            f"File:       {p.file}",
            f"Line:       {p.line}",
            f"Function:   {p.func}",
            f"Type:       {p.divergence_type.value}",
            f"Cause:      {p.cause}",
            "",
            f"Detail:     {p.detail}",
            "",
            f"Fix:        {p.fix}",
            "",
            f"Confidence: {self.confidence:.0%}  |  "
            f"Total divergences: {len(self.all_divergences)}",
            sep,
        ])


# ─────────────────────────────────────────────────────────────
# CORE DIFFERENTIAL ALGORITHM
# ─────────────────────────────────────────────────────────────

class DifferentialAnalyser:
    """
    ORIGINAL CORE ALGORITHM — FLAKEMARK DifferentialAnalyser.

    Compares two ExecutionTraces to find where they diverged.

    Steps:
      1. Check early termination (one trace much shorter).
      2. Walk both traces with two-pointer alignment.
      3. At matching ops: check timing, value, thread.
      4. At non-matching ops: detect sequence break or missing event.
      5. Rank all divergences by confidence score.
      6. Return DivergenceReport with primary = highest confidence.

    Copyright: Khushdeep Sharma, Chitkara University, 2026
    """

    def analyse(
        self,
        trace_a: ExecutionTrace,
        trace_b: ExecutionTrace,
    ) -> DivergenceReport:
        """
        Main entry point.
        trace_a = passing run.
        trace_b = failing run.
        Returns DivergenceReport.
        """
        report = DivergenceReport(trace_a=trace_a, trace_b=trace_b)

        # Edge: both empty
        if not trace_a.events and not trace_b.events:
            report.summary = "FLAKEMARK: Both traces empty — instrumentation may have failed."
            return report

        # Step 1 — Early termination check
        if trace_a.events and trace_b.events:
            len_a, len_b = len(trace_a), len(trace_b)
            len_min, len_max = min(len_a, len_b), max(len_a, len_b)
            if len_max > 0 and (len_min / len_max) < FM_EARLY_TERM_RATIO:
                shorter = trace_b if len_b < len_a else trace_a
                longer  = trace_a if len_b < len_a else trace_b
                dp = DivergencePoint(
                    position=len(shorter.events),
                    divergence_type=DivergenceType.EARLY_TERMINATION,
                    event_a=trace_a.events[-1] if trace_a.events else None,
                    event_b=trace_b.events[-1] if trace_b.events else None,
                    detail=(
                        f"Pass run: {len(longer.events)} events, "
                        f"{longer.duration_ms:.0f}ms. "
                        f"Fail run: {len(shorter.events)} events, "
                        f"{shorter.duration_ms:.0f}ms. "
                        f"Fail error: {shorter.error}"
                    ),
                )
                report.all_divergences.append(dp)

        # Step 2 — Two-pointer walk
        walk_divs = self._walk(trace_a.events, trace_b.events)
        report.all_divergences.extend(walk_divs)

        # Step 3 — No divergences found
        if not report.all_divergences:
            report.summary = (
                "FLAKEMARK: Traces match. Flakiness may originate in "
                "external I/O not captured by instrumentation."
            )
            return report

        # Step 4 — Rank and pick primary
        ranked = sorted(
            report.all_divergences,
            key=lambda d: self._score(d),
            reverse=True,
        )
        report.primary    = ranked[0]
        report.confidence = self._score(ranked[0])
        report.summary    = (
            f"FLAKEMARK: {len(ranked)} divergence(s). "
            f"Primary: {report.primary.divergence_type.value} "
            f"at {report.primary.file}:{report.primary.line} "
            f"({report.confidence:.0%} confidence)"
        )
        return report

    # ── Private methods ────────────────────────────────────────

    def _walk(
        self,
        events_a: list[TraceEvent],
        events_b: list[TraceEvent],
    ) -> list[DivergencePoint]:
        """
        ORIGINAL: Two-pointer aligned walk of two event lists.

        An "operation identity" is the tuple (kind, file, line).
        When both pointers point to the same identity → same_op check.
        When they differ → sequence or missing event.

        Copyright: Khushdeep Sharma, Chitkara University, 2026
        """
        divs: list[DivergencePoint] = []
        i = j = pos = 0

        while i < len(events_a) and j < len(events_b):
            a, b = events_a[i], events_b[j]
            ka   = (a.kind, a.file, a.line)
            kb   = (b.kind, b.file, b.line)

            if ka == kb:
                # Same operation — check timing / value / thread
                dp = self._same_op_check(pos, a, b)
                if dp:
                    divs.append(dp)
                i += 1
                j += 1

            else:
                # Different operation at same position
                if self._key_ahead(ka, events_b, j):
                    # b skipped something that a had
                    divs.append(DivergencePoint(
                        position=pos,
                        divergence_type=DivergenceType.MISSING_EVENT,
                        event_a=a,
                        event_b=b,
                        detail=(
                            f"Pass run executed {a.kind} at line {a.line}, "
                            f"fail run skipped to {b.kind} at line {b.line}."
                        ),
                    ))
                    j += 1
                else:
                    # Genuine sequence break — different execution path
                    divs.append(DivergencePoint(
                        position=pos,
                        divergence_type=DivergenceType.SEQUENCE_BREAK,
                        event_a=a,
                        event_b=b,
                        detail=(
                            f"Pass: {a.kind} at line {a.line}  |  "
                            f"Fail: {b.kind} at line {b.line}. "
                            "Execution paths diverged — test order dependency likely."
                        ),
                    ))
                    i += 1
                    j += 1

            pos += 1
            if len(divs) >= FM_MAX_DIVERGENCES:
                break  # enough evidence collected

        return divs

    def _same_op_check(
        self,
        pos: int,
        a:   TraceEvent,
        b:   TraceEvent,
    ) -> Optional[DivergencePoint]:
        """
        ORIGINAL: Three checks on a matching event pair.

        Check 1 — Thread race (thread_id > 1 means explicitly set, not default)
        Check 2 — Timing delta (ratio AND absolute minimum)
        Check 3 — Value mismatch (assign/return with different value)

        Copyright: Khushdeep Sharma, Chitkara University, 2026
        """

        # Check 1 — Thread race
        # Only flag when thread IDs are explicitly > 1 (synthetic mode).
        # In subprocess mode all events have thread_id=0 to avoid
        # false positives from cross-process thread ID differences.
        if a.thread_id > 1 and b.thread_id > 1 and a.thread_id != b.thread_id:
            return DivergencePoint(
                position=pos,
                divergence_type=DivergenceType.THREAD_RACE,
                event_a=a,
                event_b=b,
                detail=(
                    f"Line {a.line}: pass run used thread {a.thread_id}, "
                    f"fail run used thread {b.thread_id}."
                ),
            )

        # Check 2 — Timing delta
        # Requires BOTH a high ratio AND a minimum absolute difference
        # to avoid false positives on stable tests with minor timing noise.
        if a.elapsed_ms > 0 and b.elapsed_ms > 0:
            lo, hi = sorted([a.elapsed_ms, b.elapsed_ms])
            if (lo > 0
                    and hi / lo >= FM_TIMING_RATIO
                    and (hi - lo) >= FM_TIMING_MIN_MS):
                return DivergencePoint(
                    position=pos,
                    divergence_type=DivergenceType.TIMING_DELTA,
                    event_a=a,
                    event_b=b,
                    detail=(
                        f"Line {a.line}: {a.elapsed_ms:.1f}ms (pass) vs "
                        f"{b.elapsed_ms:.1f}ms (fail) — "
                        f"{hi / lo:.0f}x timing difference."
                    ),
                )

        # Check 3 — Value mismatch
        if (a.kind in FM_VALUE_KINDS
                and a.value is not None
                and b.value is not None
                and a.value != b.value):
            return DivergencePoint(
                position=pos,
                divergence_type=DivergenceType.VALUE_MISMATCH,
                event_a=a,
                event_b=b,
                detail=(
                    f"Line {a.line}: pass run got {a.value!r}, "
                    f"fail run got {b.value!r}."
                ),
            )

        return None

    def _key_ahead(
        self,
        key:      tuple,
        events:   list[TraceEvent],
        from_idx: int,
    ) -> bool:
        """Look ahead FM_LOOKAHEAD events to detect a missing operation."""
        end = min(from_idx + FM_LOOKAHEAD, len(events))
        for i in range(from_idx, end):
            if (events[i].kind, events[i].file, events[i].line) == key:
                return True
        return False

    def _score(self, dp: DivergencePoint) -> float:
        """
        ORIGINAL: Confidence scoring formula for a DivergencePoint.

        Base score per divergence type minus a small position penalty.
        Earlier divergences are more likely root causes (not symptoms).

        Copyright: Khushdeep Sharma, Chitkara University, 2026
        """
        base    = FM_CONFIDENCE_SCORES.get(dp.divergence_type, 0.20)
        penalty = dp.position * 0.02
        return round(max(0.10, base - penalty), 3)
