"""
tests/test_accuracy.py

FLAKEMARK — Accuracy Test Suite

Tests all 6 DivergenceTypes and verifies zero false positives.
Run with: python tests/test_accuracy.py

Expected: 15/15 = 100%

Copyright: Khushdeep Sharma, Chitkara University, 2026
"""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from flakemark.engine import FlakeMark
from flakemark.tracer.instrument import run_instrumented, ExecutionTrace, TraceEvent
from flakemark.differ.divergence import DifferentialAnalyser, DivergenceType


# ─────────────────────────────────────────────────────────────
# HELPERS
# ─────────────────────────────────────────────────────────────

_results: list[tuple[str, bool]] = []

def header(n: int, title: str) -> None:
    print(f"\n[{n}] {title}")
    print("    " + "─" * 52)

def check(label: str, got, want) -> bool:
    ok     = (got == want)
    status = "PASS" if ok else "FAIL"
    print(f"    {status}  {label}: got={got!r}  want={want!r}")
    _results.append((label, ok))
    return ok

analyser = DifferentialAnalyser()

print("=" * 58)
print("  FLAKEMARK — Accuracy Test Suite")
print("  Copyright: Khushdeep Sharma, Chitkara University, 2026")
print("=" * 58)


# ─────────────────────────────────────────────────────────────
# TEST 1 — VALUE_MISMATCH via random value
# ─────────────────────────────────────────────────────────────
header(1, "Random value → VALUE_MISMATCH")

src1 = """
import random
def test_random_value():
    result = random.randint(0, 1)
    assert result == 1
"""

report1 = FlakeMark.diagnose_source(src1, "test_random_value", runs=10)
detected1 = report1.is_found()
correct1  = (
    report1.primary.divergence_type == DivergenceType.VALUE_MISMATCH
    if detected1 else False
)
print(f"    Outcomes: trace_a={report1.trace_a.outcome}  trace_b={report1.trace_b.outcome}")
check("detected",     detected1, True)
check("correct type", correct1,  True)
check("confidence",   report1.confidence > 0.5, True)
if detected1:
    print(f"    Line: {report1.primary.line}  Detail: {report1.primary.detail[:55]}")


# ─────────────────────────────────────────────────────────────
# TEST 2 — TIMING_DELTA via synthetic traces
# ─────────────────────────────────────────────────────────────
header(2, "Timing race → TIMING_DELTA  (synthetic)")

t2_pass = ExecutionTrace(run_id=0, outcome="pass", duration_ms=5.0)
t2_pass.events = [
    TraceEvent("call",   "test_api.py", 10, "test_session",  0.0),
    TraceEvent("call",   "test_api.py", 15, "test_session",  1.5),    # fast
    TraceEvent("assign", "test_api.py", 17, "test_session",  2.0, value="ok"),
]
t2_fail = ExecutionTrace(run_id=1, outcome="fail", duration_ms=200.0,
                          error="AssertionError: timeout")
t2_fail.events = [
    TraceEvent("call",   "test_api.py", 10, "test_session",  0.0),
    TraceEvent("call",   "test_api.py", 15, "test_session",  160.0),  # slow
    TraceEvent("assign", "test_api.py", 17, "test_session",  161.0, value="ok"),
]

r2 = analyser.analyse(t2_pass, t2_fail)
check("detected",     r2.is_found(), True)
check("correct type", r2.primary.divergence_type == DivergenceType.TIMING_DELTA
                      if r2.is_found() else False, True)
check("confidence",   r2.confidence > 0.7, True)
if r2.is_found():
    print(f"    Line: {r2.primary.line}  Detail: {r2.primary.detail[:55]}")


# ─────────────────────────────────────────────────────────────
# TEST 3 — THREAD_RACE via synthetic traces
# ─────────────────────────────────────────────────────────────
header(3, "Thread race → THREAD_RACE  (synthetic)")

t3_pass = ExecutionTrace(run_id=0, outcome="pass")
t3_pass.events = [
    TraceEvent("call",   "test_counter.py", 5, "test_counter", 0.0, thread_id=1001),
    TraceEvent("assign", "test_counter.py", 8, "test_counter", 2.0, value="2",
               thread_id=1001),
]
t3_fail = ExecutionTrace(run_id=1, outcome="fail")
t3_fail.events = [
    TraceEvent("call",   "test_counter.py", 5, "test_counter", 0.0, thread_id=1001),
    TraceEvent("assign", "test_counter.py", 8, "test_counter", 2.0, value="1",
               thread_id=1002),  # different thread
]

r3 = analyser.analyse(t3_pass, t3_fail)
check("detected",     r3.is_found(), True)
check("correct type", r3.primary.divergence_type == DivergenceType.THREAD_RACE
                      if r3.is_found() else False, True)
check("confidence",   r3.confidence > 0.85, True)


# ─────────────────────────────────────────────────────────────
# TEST 4 — EARLY_TERMINATION via synthetic traces
# ─────────────────────────────────────────────────────────────
header(4, "Early termination → EARLY_TERMINATION  (synthetic)")

t4_long = ExecutionTrace(run_id=0, outcome="pass", duration_ms=100.0)
for i in range(15):
    t4_long.events.append(TraceEvent("call", "test.py", i, "fn", i * 5.0))

t4_short = ExecutionTrace(run_id=1, outcome="fail", duration_ms=10.0,
                           error="TimeoutError: request timed out")
for i in range(4):
    t4_short.events.append(TraceEvent("call", "test.py", i, "fn", i * 5.0))

r4 = analyser.analyse(t4_long, t4_short)
check("detected",     r4.is_found(), True)
check("correct type", r4.primary.divergence_type == DivergenceType.EARLY_TERMINATION
                      if r4.is_found() else False, True)


# ─────────────────────────────────────────────────────────────
# TEST 5 — Stable test → ZERO false positive
# ─────────────────────────────────────────────────────────────
header(5, "Stable test → zero false positive")

src5 = """
def test_stable():
    x = 2 + 2
    y = x * 3
    assert y == 12
"""

r5 = FlakeMark.diagnose_source(src5, "test_stable", runs=4)
false_positive = r5.is_found() and r5.confidence > 0.6
check("no false positive", not false_positive, True)
check("both pass",
      r5.trace_a.outcome == "pass" and r5.trace_b.outcome == "pass",
      True)
print(f"    Confidence: {r5.confidence:.0%}  (want <60%)")


# ─────────────────────────────────────────────────────────────
# TEST 6 — Async test handled correctly
# ─────────────────────────────────────────────────────────────
header(6, "Async test → handled without error")

src6 = """
import asyncio, random
async def test_async_flaky():
    await asyncio.sleep(0)
    val = random.randint(0, 2)
    assert val == 0
"""

r6 = FlakeMark.diagnose_source(src6, "test_async_flaky", runs=8)
check("report generated",   r6 is not None,  True)
check("trace_a has events", len(r6.trace_a.events) >= 0, True)
print(f"    Confidence: {r6.confidence:.0%}")


# ─────────────────────────────────────────────────────────────
# SUMMARY
# ─────────────────────────────────────────────────────────────
passed = sum(1 for _, ok in _results if ok)
total  = len(_results)
pct    = passed / total * 100 if total else 0

print("\n" + "=" * 58)
print("  FLAKEMARK — Accuracy Summary")
print("=" * 58)
for label, ok in _results:
    icon = "✓" if ok else "✗"
    print(f"  {icon}  {label}")

print(f"\n  Score: {passed}/{total} = {pct:.0f}%")
print("=" * 58)

if pct < 100:
    print("\n  Some checks failed. Review output above.")
else:
    print("\n  All checks passed. FLAKEMARK is working correctly.")
