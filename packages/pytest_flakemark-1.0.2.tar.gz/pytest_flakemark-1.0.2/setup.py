"""
setup.py

FLAKEMARK — pytest-flakemark PyPI package.
Copyright: Khushdeep Sharma, Chitkara University, 2026
"""

from setuptools import setup, find_packages

setup(
    name             = "pytest-flakemark",
    version          = "1.0.2",
    author           = "Khushdeep Sharma",
    author_email     = "itskhushsharma@gmail.com",
    description      = (
        "FLAKEMARK — Differential execution tracer that finds the exact "
        "file, line, and root cause of any flaky test."
    ),
    long_description = open("README.md", encoding="utf-8").read(),
    long_description_content_type = "text/markdown",
    url              = "https://github.com/itskhushsharma/flakemark",
    packages         = find_packages(exclude=["tests*"]),
    python_requires  = ">=3.11",
    install_requires = ["pytest>=7.0"],
    entry_points     = {
        # Registers flakemark as a pytest plugin automatically on install
        "pytest11": ["flakemark = flakemark.pytest_plugin"],
    },
    classifiers = [
        "Development Status :: 4 - Beta",
        "Framework :: Pytest",
        "Intended Audience :: Developers",
        "Topic :: Software Development :: Testing",
        "Topic :: Software Development :: Debuggers",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
    ],
    keywords = [
        "pytest",
        "flaky-tests",
        "flakemark",
        "debugging",
        "root-cause",
        "differential-analysis",
        "test-diagnosis",
        "execution-trace",
    ],
    project_urls = {
        "Bug Reports": "https://github.com/itskhushsharma/flakemark/issues",
        "Source":      "https://github.com/itskhushsharma/flakemark",
    },
)
