# Kept for compatibility with older pip / tooling.
# The authoritative config is pyproject.toml.
from setuptools import setup
setup()
