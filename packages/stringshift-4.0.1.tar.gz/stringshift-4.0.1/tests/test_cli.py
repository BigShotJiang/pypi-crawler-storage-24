"""
Tests for stringshift.cli
"""

import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import pytest
from stringshift.cli import main


def run(args):
    """Helper — returns (stdout_lines, exit_code)."""
    import io
    from contextlib import redirect_stdout
    buf = io.StringIO()
    code = 0
    try:
        with redirect_stdout(buf):
            main(args)
    except SystemExit as exc:
        code = exc.code or 0
    return buf.getvalue().strip(), code


def test_cli_version():
    out, code = run(["--version"])
    assert "4.0.1" in out
    assert code == 0

def test_cli_list():
    out, code = run(["--list"])
    assert "base64" in out
    assert "morse" in out
    assert code == 0

def test_cli_encode_base64():
    out, code = run(["Hello", "-e", "base64"])
    assert out == "SGVsbG8="
    assert code == 0

def test_cli_decode_base64():
    out, code = run(["SGVsbG8=", "-d", "base64"])
    assert out == "Hello"
    assert code == 0

def test_cli_encode_hex():
    out, code = run(["Hi", "-e", "hex"])
    assert out == "4869"
    assert code == 0

def test_cli_auto_detect():
    out, code = run(["SGVsbG8="])
    assert out == "Hello"
    assert code == 0

def test_cli_magic():
    out, code = run(["SGVsbG8=", "--magic"])
    assert "base64" in out
    assert "Hello" in out
    assert code == 0

def test_cli_deep():
    import stringshift
    inner = stringshift.encode("Hi", "base64")
    outer = stringshift.encode(inner, "url")
    out, code = run([outer, "--deep"])
    assert "Hi" in out
    assert code == 0

def test_cli_pipeline():
    out, code = run(["hello", "--pipeline", "base64_encode", "url_encode"])
    assert "%" in out or "=" in out
    assert code == 0

def test_cli_caesar():
    out, code = run(["Hello", "-e", "caesar", "--shift", "3"])
    assert out == "Khoor"
    assert code == 0

def test_cli_unknown_format_exits_1():
    _, code = run(["hello", "-e", "notaformat"])
    assert code != 0

def test_cli_benchmark_flag():
    # Just ensure --benchmark doesn't crash
    out, code = run(["Hello", "-e", "base64", "--benchmark"])
    assert code == 0
