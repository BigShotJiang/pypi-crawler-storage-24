"""
Tests for stringshift.core
Run with: python -m pytest tests/ -v
"""

import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import pytest
import stringshift
from stringshift import (
    encode, decode,
    detect_format, magic_decode, smart_decode,
    deep_decode, pipeline,
    register_codec, codec, list_formats,
    batch_process, batch_decode,
    decode_all, normalize_text,
    DecodeError, EncodeError, UnknownFormatError, PipelineError,
)

# ---------------------------------------------------------------------------
# Round-trip: encode → decode must return the original string
# ---------------------------------------------------------------------------

ROUND_TRIP = [
    ("base64",           "Hello, World!"),
    ("base32",           "Hello, World!"),
    ("base16",           "Hello, World!"),
    ("base85",           "Hello, World!"),
    ("base58",           "Hello"),
    ("ascii85",          "Hello, World!"),
    ("hex",              "Hello, World!"),
    ("binary",           "Hi"),
    ("url",              "hello world/test?q=1"),
    ("html",             "<b>Hello & World</b>"),
    ("rot13",            "Hello World"),
    ("rot47",            "Hello World"),
    ("atbash",           "Hello World"),
    ("reverse",          "Hello World"),
    ("unicode_escape",   "Hello \u00e9\u4e2d"),
    ("quoted_printable", "Hello World"),
]

@pytest.mark.parametrize("fmt,text", ROUND_TRIP)
def test_round_trip(fmt, text):
    assert decode(encode(text, fmt), fmt) == text


def test_caesar_various_shifts():
    for shift in (1, 3, 13, 25):
        original = "Hello World"
        assert decode(encode(original, "caesar", shift=shift), "caesar", shift=shift) == original


def test_vigenere_various_keys():
    for key in ("secret", "abc", "z", "python"):
        original = "Hello World"
        assert decode(encode(original, "vigenere", key=key), "vigenere", key=key) == original


def test_xor_round_trip():
    for key in (1, 42, 127, 255):
        assert decode(encode("Hello", "xor", key=key), "xor", key=key) == "Hello"


# ---------------------------------------------------------------------------
# Known values
# ---------------------------------------------------------------------------

def test_base64_known():
    assert encode("Hello", "base64") == "SGVsbG8="
    assert decode("SGVsbG8=", "base64") == "Hello"

def test_hex_known():
    assert encode("Hello", "hex") == "48656c6c6f"
    assert decode("48656c6c6f", "hex") == "Hello"

def test_morse_known():
    assert encode("SOS", "morse") == "... --- ..."
    assert decode("... --- ...", "morse") == "SOS"

def test_nato_known():
    assert encode("ABC", "nato") == "Alpha Bravo Charlie"
    assert decode("Alpha Bravo Charlie", "nato") == "ABC"

def test_rot13_known():
    assert encode("hello", "rot13") == "uryyb"
    assert decode("uryyb", "rot13") == "hello"

def test_atbash_known():
    assert encode("abc", "atbash") == "zyx"
    assert decode("zyx", "atbash") == "abc"

def test_rot47_self_inverse():
    enc = encode("Hello World!", "rot47")
    assert decode(enc, "rot47") == "Hello World!"

def test_braille_round_trip():
    assert decode(encode("hello", "braille"), "braille") == "hello"


# ---------------------------------------------------------------------------
# Error handling
# ---------------------------------------------------------------------------

def test_unknown_format_encode():
    with pytest.raises(UnknownFormatError):
        encode("hello", "does_not_exist")

def test_unknown_format_decode():
    with pytest.raises(UnknownFormatError):
        decode("hello", "does_not_exist")

def test_bad_base64():
    with pytest.raises((DecodeError, Exception)):
        decode("!!!NOT_VALID_BASE64!!!", "base64")

def test_bad_hex():
    with pytest.raises((DecodeError, Exception)):
        decode("ZZZZ", "hex")

def test_unknown_format_message():
    try:
        encode("x", "totally_fake")
    except UnknownFormatError as exc:
        assert "totally_fake" in str(exc)
        assert "base64" in str(exc)


# ---------------------------------------------------------------------------
# Auto-detection
# ---------------------------------------------------------------------------

def test_detect_base64():
    results = detect_format("SGVsbG8=")
    assert any(r["format"] == "base64" for r in results)

def test_detect_url():
    results = detect_format("hello%20world%21")
    assert any(r["format"] == "url" for r in results)

def test_detect_binary():
    # Each space-separated token must be exactly 8 bits for the detector to match
    results = detect_format("01001000 01101001")  # "Hi" in binary
    assert any(r["format"] == "binary" for r in results)

def test_detect_morse():
    results = detect_format(".... . .-.. .-.. ---")
    assert any(r["format"] == "morse" for r in results)

def test_detect_html():
    results = detect_format("&lt;b&gt;Hello&lt;/b&gt;")
    assert any(r["format"] == "html" for r in results)

def test_detect_unicode_escape():
    results = detect_format(r"\u0048\u0065\u006c\u006c\u006f")
    assert any(r["format"] == "unicode_escape" for r in results)

def test_detect_returns_sorted_by_confidence():
    results = detect_format("SGVsbG8=")
    if len(results) >= 2:
        assert results[0]["confidence"] >= results[1]["confidence"]

def test_smart_decode_base64():
    assert smart_decode("SGVsbG8=") == "Hello"

def test_smart_decode_url():
    assert smart_decode("hello%20world") == "hello world"

def test_smart_decode_unknown_raises():
    with pytest.raises(DecodeError):
        smart_decode("!@#$%^&*()")

def test_magic_decode_structure():
    results = magic_decode("SGVsbG8=")
    assert isinstance(results, list)
    assert len(results) > 0
    for r in results:
        assert "format" in r
        assert "decoded" in r
        assert "confidence" in r
        assert 0.0 <= r["confidence"] <= 1.0


# ---------------------------------------------------------------------------
# Deep decode
# ---------------------------------------------------------------------------

def test_deep_decode_single_layer():
    info = deep_decode(encode("Hello", "base64"))
    assert info["result"] == "Hello"
    assert info["total_layers"] == 1

def test_deep_decode_two_layers():
    inner = encode("Hello", "base64")
    outer = encode(inner, "url")
    info = deep_decode(outer)
    assert info["result"] == "Hello"
    assert info["total_layers"] == 2

def test_deep_decode_three_layers():
    text = encode(encode(encode("Hi", "hex"), "base64"), "url")
    info = deep_decode(text)
    assert info["result"] == "Hi"
    assert info["total_layers"] == 3

def test_deep_decode_no_layers():
    info = deep_decode("plaintext nothing to decode here")
    assert info["total_layers"] == 0
    assert info["result"] == "plaintext nothing to decode here"

def test_deep_decode_structure():
    info = deep_decode(encode("Hi", "base64"))
    assert "layers" in info
    assert "total_layers" in info
    assert "result" in info
    assert info["layers"][0]["layer"] == 1
    assert info["layers"][0]["format"] == "base64"

def test_deep_decode_does_not_over_decode():
    # After decoding "Hello", confidence should drop — rot13 should NOT be applied
    info = deep_decode(encode("Hello", "base64"))
    assert info["result"] == "Hello"
    assert info["total_layers"] == 1


# ---------------------------------------------------------------------------
# Pipeline
# ---------------------------------------------------------------------------

def test_pipeline_single_step():
    assert pipeline("hello", ["base64_encode"]) == encode("hello", "base64")

def test_pipeline_encode_decode_inverse():
    steps_enc = ["base64_encode", "url_encode"]
    steps_dec = ["url_decode", "base64_decode"]
    assert pipeline(pipeline("hello", steps_enc), steps_dec) == "hello"

def test_pipeline_with_kwargs():
    result = pipeline("hello", [("caesar_encode", {"shift": 5}), "base64_encode"])
    expected = encode(encode("hello", "caesar", shift=5), "base64")
    assert result == expected

def test_pipeline_multiple_formats():
    result = pipeline("hello", [
        "reverse_encode",
        "hex_encode",
        "base64_encode",
    ])
    back = pipeline(result, [
        "base64_decode",
        "hex_decode",
        "reverse_decode",
    ])
    assert back == "hello"

def test_pipeline_invalid_step_raises():
    with pytest.raises(PipelineError):
        pipeline("hello", ["base64"])  # missing _encode/_decode

def test_pipeline_unknown_format_raises():
    with pytest.raises(PipelineError):
        pipeline("hello", ["fakefmt_encode"])

def test_pipeline_error_reports_step_name():
    try:
        pipeline("hello", ["nope_encode"])
    except PipelineError as exc:
        assert "nope" in str(exc)


# ---------------------------------------------------------------------------
# Plugin system
# ---------------------------------------------------------------------------

def test_register_codec():
    register_codec("test_shout", encoder=str.upper, decoder=str.lower)
    assert encode("hello", "test_shout") == "HELLO"
    assert decode("HELLO", "test_shout") == "hello"

def test_codec_decorator():
    @codec("test_whisper")
    class Whisper:
        def encode(self, text: str) -> str:
            return text.lower() + "..."
        def decode(self, text: str) -> str:
            return text.rstrip(".")

    assert encode("HELLO", "test_whisper") == "hello..."
    assert decode("hello...", "test_whisper") == "hello"

def test_plugin_appears_in_list_formats():
    register_codec("test_visible", encoder=lambda t: t, decoder=lambda t: t)
    fmts = list_formats()
    assert "test_visible" in fmts["plugins"]

def test_list_formats_builtin_completeness():
    fmts = list_formats()
    for expected in ["base64", "base32", "hex", "binary", "url", "html",
                     "morse", "caesar", "vigenere", "atbash", "rot13",
                     "rot47", "braille", "nato", "xor", "reverse"]:
        assert expected in fmts["builtin"], f"Missing: {expected}"


# ---------------------------------------------------------------------------
# Batch processing
# ---------------------------------------------------------------------------

def test_batch_process_encode():
    texts = ["hello", "world", "foo"]
    results = batch_process(texts, operation="encode", fmt="base64")
    assert results == [encode(t, "base64") for t in texts]

def test_batch_process_decode():
    encoded = [encode(t, "hex") for t in ["hello", "world"]]
    results = batch_process(encoded, operation="decode", fmt="hex")
    assert results == ["hello", "world"]

def test_batch_process_auto():
    encoded = [encode("hello", "base64"), encode("world", "base64")]
    results = batch_process(encoded)
    assert results == ["hello", "world"]

def test_batch_decode_legacy():
    texts = ["hello%20world", "foo%20bar"]
    results = batch_decode(texts)
    assert results == ["hello world", "foo bar"]


# ---------------------------------------------------------------------------
# Legacy helpers
# ---------------------------------------------------------------------------

def test_decode_all_url():
    assert decode_all("hello%20world") == "hello world"

def test_decode_all_html():
    assert decode_all("&lt;b&gt;hi&lt;/b&gt;") == "<b>hi</b>"

def test_decode_all_fallback():
    # An incomplete \x escape sequence forces decode_escapes to throw,
    # which triggers the fallback path in decode_all
    result = decode_all("\\x", fallback="[error]")
    assert result == "[error]"

def test_normalize_text():
    assert normalize_text("caf\u00e9", "NFC") == "caf\u00e9"

def test_normalize_text_nfd():
    nfd = normalize_text("café", "NFD")
    assert len(nfd) > len("café")  # NFD splits the é


# ---------------------------------------------------------------------------
# Version
# ---------------------------------------------------------------------------

def test_version_is_string():
    assert isinstance(stringshift.__version__, str)

def test_version_format():
    parts = stringshift.__version__.split(".")
    assert len(parts) == 3
    assert all(p.isdigit() for p in parts)
