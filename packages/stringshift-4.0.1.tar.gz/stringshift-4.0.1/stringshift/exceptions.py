"""
stringshift.exceptions
~~~~~~~~~~~~~~~~~~~~~~
Exception hierarchy for stringshift.
"""


class StringShiftError(Exception):
    """Base exception for all stringshift errors."""
    pass


class DecodeError(StringShiftError):
    """Raised when a decoding operation fails."""
    def __init__(self, original: str, error: Exception):
        self.original = original
        self.error = error
        super().__init__(
            f"Failed to decode '{original[:60]}{'...' if len(original) > 60 else ''}' "
            f"— {type(error).__name__}: {error}"
        )


class EncodeError(StringShiftError):
    """Raised when an encoding operation fails."""
    def __init__(self, original: str, error: Exception):
        self.original = original
        self.error = error
        super().__init__(
            f"Failed to encode '{original[:60]}{'...' if len(original) > 60 else ''}' "
            f"— {type(error).__name__}: {error}"
        )


class UnknownFormatError(StringShiftError):
    """Raised when an unsupported format is requested."""
    def __init__(self, fmt: str, available: list):
        self.fmt = fmt
        self.available = available
        super().__init__(
            f"Unknown format '{fmt}'. "
            f"Available: {', '.join(sorted(available))}"
        )


class PipelineError(StringShiftError):
    """Raised when a pipeline step fails."""
    def __init__(self, step: str, index: int, error: Exception):
        self.step = step
        self.index = index
        self.error = error
        super().__init__(
            f"Pipeline failed at step {index + 1} ('{step}') "
            f"— {type(error).__name__}: {error}"
        )
