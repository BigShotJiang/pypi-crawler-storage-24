"""
stringshift.core
~~~~~~~~~~~~~~~~
All encoding, decoding, detection, pipeline, and plugin logic.
"""

import base64
import codecs
import html
import os
import re
import unicodedata
import urllib.parse
from concurrent.futures import ThreadPoolExecutor
from functools import lru_cache
from typing import Any, Callable, Dict, List, Optional, Tuple, Union, Literal

from .exceptions import DecodeError, EncodeError, UnknownFormatError, PipelineError

try:
    import chardet
    HAS_CHARDET = True
except ImportError:
    HAS_CHARDET = False

NormalizationForm = Literal["NFC", "NFD", "NFKC", "NFKD"]

# ---------------------------------------------------------------------------
# Lookup tables
# ---------------------------------------------------------------------------

MORSE_ENCODE_MAP: Dict[str, str] = {
    "A": ".-",    "B": "-...",  "C": "-.-.",  "D": "-..",   "E": ".",
    "F": "..-.",  "G": "--.",   "H": "....",  "I": "..",    "J": ".---",
    "K": "-.-",   "L": ".-..",  "M": "--",    "N": "-.",    "O": "---",
    "P": ".--.",  "Q": "--.-",  "R": ".-.",   "S": "...",   "T": "-",
    "U": "..-",   "V": "...-",  "W": ".--",   "X": "-..-",  "Y": "-.--",
    "Z": "--..",  "0": "-----", "1": ".----", "2": "..---", "3": "...--",
    "4": "....-", "5": ".....", "6": "-....", "7": "--...",  "8": "---..",
    "9": "----.", ",": "--..--","." : ".-.-.-","?": "..--..","/": "-..-.",
    "-": "-....-","(": "-.--.", ")": "-.--.-", " ": "/",
}
MORSE_DECODE_MAP: Dict[str, str] = {v: k for k, v in MORSE_ENCODE_MAP.items()}

NATO_ENCODE_MAP: Dict[str, str] = {
    "A": "Alpha",   "B": "Bravo",    "C": "Charlie", "D": "Delta",
    "E": "Echo",    "F": "Foxtrot",  "G": "Golf",    "H": "Hotel",
    "I": "India",   "J": "Juliet",   "K": "Kilo",    "L": "Lima",
    "M": "Mike",    "N": "November", "O": "Oscar",   "P": "Papa",
    "Q": "Quebec",  "R": "Romeo",    "S": "Sierra",  "T": "Tango",
    "U": "Uniform", "V": "Victor",   "W": "Whiskey", "X": "X-ray",
    "Y": "Yankee",  "Z": "Zulu",     "0": "Zero",    "1": "One",
    "2": "Two",     "3": "Three",    "4": "Four",    "5": "Five",
    "6": "Six",     "7": "Seven",    "8": "Eight",   "9": "Nine",
}
NATO_DECODE_MAP: Dict[str, str] = {v.lower(): k for k, v in NATO_ENCODE_MAP.items()}

BASE58_ALPHABET = b"123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz"

BRAILLE_MAP: Dict[str, str] = {
    "a": "⠁", "b": "⠃", "c": "⠉", "d": "⠙", "e": "⠑",
    "f": "⠋", "g": "⠛", "h": "⠓", "i": "⠊", "j": "⠚",
    "k": "⠅", "l": "⠇", "m": "⠍", "n": "⠝", "o": "⠕",
    "p": "⠏", "q": "⠟", "r": "⠗", "s": "⠎", "t": "⠞",
    "u": "⠥", "v": "⠧", "w": "⠺", "x": "⠭", "y": "⠽",
    "z": "⠵", " ": "⠀", "1": "⠂", "2": "⠆", "3": "⠒",
    "4": "⠲", "5": "⠢", "6": "⠖", "7": "⠶", "8": "⠦",
    "9": "⠔", "0": "⠴",
}
BRAILLE_DECODE_MAP: Dict[str, str] = {v: k for k, v in BRAILLE_MAP.items()}

# ---------------------------------------------------------------------------
# Base58 helpers
# ---------------------------------------------------------------------------

def _b58_encode(data: bytes) -> str:
    leading = len(data) - len(data.lstrip(b"\x00"))
    num = int.from_bytes(data, "big")
    chars: List[str] = []
    while num:
        num, rem = divmod(num, 58)
        chars.append(BASE58_ALPHABET[rem:rem + 1].decode())
    return "1" * leading + "".join(reversed(chars))


def _b58_decode(text: str) -> bytes:
    leading = len(text) - len(text.lstrip("1"))
    num = 0
    for ch in text:
        idx = BASE58_ALPHABET.find(ch.encode())
        if idx == -1:
            raise ValueError(f"Invalid Base58 character: {ch!r}")
        num = num * 58 + idx
    result: List[int] = []
    while num:
        num, rem = divmod(num, 256)
        result.append(rem)
    return bytes([0] * leading + list(reversed(result)))


# ---------------------------------------------------------------------------
# Encoders
# ---------------------------------------------------------------------------

def encode_base64(text: str) -> str:
    return base64.b64encode(text.encode("utf-8")).decode()

def encode_base32(text: str) -> str:
    return base64.b32encode(text.encode("utf-8")).decode()

def encode_base16(text: str) -> str:
    return base64.b16encode(text.encode("utf-8")).decode()

def encode_base85(text: str) -> str:
    return base64.b85encode(text.encode("utf-8")).decode()

def encode_base58(text: str) -> str:
    return _b58_encode(text.encode("utf-8"))

def encode_hex(text: str) -> str:
    return text.encode("utf-8").hex()

def encode_binary(text: str) -> str:
    return " ".join(format(ord(c), "08b") for c in text)

def encode_url(text: str) -> str:
    return urllib.parse.quote(text, safe="")

def encode_html(text: str) -> str:
    return html.escape(text)

def encode_rot13(text: str) -> str:
    return codecs.encode(text, "rot_13")

def encode_rot47(text: str) -> str:
    return "".join(
        chr(33 + (ord(c) - 33 + 47) % 94) if 33 <= ord(c) <= 126 else c
        for c in text
    )

def encode_morse(text: str) -> str:
    return " ".join(MORSE_ENCODE_MAP.get(c.upper(), "?") for c in text)

def encode_nato(text: str) -> str:
    return " ".join(NATO_ENCODE_MAP.get(c.upper(), c) for c in text)

def encode_braille(text: str) -> str:
    return "".join(BRAILLE_MAP.get(c.lower(), c) for c in text)

def encode_caesar(text: str, shift: int = 13) -> str:
    result = []
    for c in text:
        if c.isalpha():
            base = ord("A") if c.isupper() else ord("a")
            result.append(chr((ord(c) - base + shift) % 26 + base))
        else:
            result.append(c)
    return "".join(result)

def encode_atbash(text: str) -> str:
    result = []
    for c in text:
        if c.isalpha():
            base = ord("A") if c.isupper() else ord("a")
            result.append(chr(base + 25 - (ord(c) - base)))
        else:
            result.append(c)
    return "".join(result)

def encode_vigenere(text: str, key: str = "key") -> str:
    if not key:
        raise ValueError("Vigenère key cannot be empty")
    key_upper = key.upper()
    result, ki = [], 0
    for c in text:
        if c.isalpha():
            base = ord("A") if c.isupper() else ord("a")
            shift = ord(key_upper[ki % len(key_upper)]) - ord("A")
            result.append(chr((ord(c) - base + shift) % 26 + base))
            ki += 1
        else:
            result.append(c)
    return "".join(result)

def encode_xor(text: str, key: int = 42) -> str:
    return " ".join(format(ord(c) ^ key, "02x") for c in text)

def encode_reverse(text: str) -> str:
    return text[::-1]

def encode_unicode_escape(text: str) -> str:
    return text.encode("unicode_escape").decode("ascii")

def encode_ascii85(text: str) -> str:
    import base64 as _b64
    return _b64.a85encode(text.encode("utf-8")).decode()

def encode_punycode(text: str) -> str:
    return text.encode("punycode").decode("ascii")

def encode_quoted_printable(text: str) -> str:
    import quopri
    return quopri.encodestring(text.encode("utf-8")).decode("ascii")

def encode_uuencode(text: str) -> str:
    import binascii
    return binascii.b2a_uu(text.encode("utf-8")).decode("ascii").strip()


# ---------------------------------------------------------------------------
# Decoders
# ---------------------------------------------------------------------------

def decode_base64(text: str) -> str:
    t = text.strip()
    padded = t + "=" * (-len(t) % 4)
    return base64.b64decode(padded).decode("utf-8")

def decode_base32(text: str) -> str:
    t = text.strip().upper()
    padded = t + "=" * (-len(t) % 8)
    return base64.b32decode(padded).decode("utf-8")

def decode_base16(text: str) -> str:
    return base64.b16decode(text.strip().upper()).decode("utf-8")

def decode_base85(text: str) -> str:
    return base64.b85decode(text.strip()).decode("utf-8")

def decode_base58(text: str) -> str:
    return _b58_decode(text.strip()).decode("utf-8")

def decode_hex(text: str) -> str:
    clean = text.strip().replace("0x", "").replace(" ", "").replace(":", "")
    return bytes.fromhex(clean).decode("utf-8")

def decode_binary(text: str) -> str:
    return "".join(chr(int(b, 2)) for b in text.strip().split())

@lru_cache(maxsize=2048)
def _cached_url_decode(text: str) -> str:
    return urllib.parse.unquote(text)

def decode_url(text: str) -> str:
    if len(text) > 4096:
        return urllib.parse.unquote(text)
    return _cached_url_decode(text)

def decode_html(text: str) -> str:
    return html.unescape(text)

def decode_rot13(text: str) -> str:
    return codecs.encode(text, "rot_13")

def decode_rot47(text: str) -> str:
    return encode_rot47(text)

def decode_morse(text: str) -> str:
    return "".join(MORSE_DECODE_MAP.get(tok, "?") for tok in text.strip().split())

def decode_nato(text: str) -> str:
    return "".join(NATO_DECODE_MAP.get(w.lower(), w) for w in text.split())

def decode_braille(text: str) -> str:
    return "".join(BRAILLE_DECODE_MAP.get(c, c) for c in text)

def decode_caesar(text: str, shift: int = 13) -> str:
    return encode_caesar(text, -shift)

def decode_atbash(text: str) -> str:
    return encode_atbash(text)

def decode_vigenere(text: str, key: str = "key") -> str:
    if not key:
        raise ValueError("Vigenère key cannot be empty")
    key_upper = key.upper()
    result, ki = [], 0
    for c in text:
        if c.isalpha():
            base = ord("A") if c.isupper() else ord("a")
            shift = ord(key_upper[ki % len(key_upper)]) - ord("A")
            result.append(chr((ord(c) - base - shift) % 26 + base))
            ki += 1
        else:
            result.append(c)
    return "".join(result)

def decode_xor(text: str, key: int = 42) -> str:
    return "".join(chr(int(h, 16) ^ key) for h in text.strip().split())

def decode_reverse(text: str) -> str:
    return text[::-1]

def decode_unicode_escape(text: str) -> str:
    return text.encode("ascii").decode("unicode_escape")

def decode_ascii85(text: str) -> str:
    import base64 as _b64
    return _b64.a85decode(text.strip()).decode("utf-8")

def decode_punycode(text: str) -> str:
    return text.strip().encode("ascii").decode("punycode")

def decode_quoted_printable(text: str) -> str:
    import quopri
    return quopri.decodestring(text.encode("ascii")).decode("utf-8")

def decode_uuencode(text: str) -> str:
    import binascii
    return binascii.a2b_uu(text.strip() + "\n").decode("utf-8")

def decode_escapes(text: str) -> str:
    """Decode raw \\x41 / \\u0041 escape sequences."""
    try:
        return codecs.escape_decode(text.encode("latin-1"))[0].decode("utf-8")
    except Exception as exc:
        raise DecodeError(text, exc) from exc


# ---------------------------------------------------------------------------
# Registries
# ---------------------------------------------------------------------------

ENCODE_REGISTRY: Dict[str, Callable] = {
    "base64":           encode_base64,
    "base32":           encode_base32,
    "base16":           encode_base16,
    "base58":           encode_base58,
    "base85":           encode_base85,
    "ascii85":          encode_ascii85,
    "hex":              encode_hex,
    "binary":           encode_binary,
    "url":              encode_url,
    "html":             encode_html,
    "rot13":            encode_rot13,
    "rot47":            encode_rot47,
    "morse":            encode_morse,
    "nato":             encode_nato,
    "braille":          encode_braille,
    "caesar":           encode_caesar,
    "atbash":           encode_atbash,
    "vigenere":         encode_vigenere,
    "xor":              encode_xor,
    "reverse":          encode_reverse,
    "unicode_escape":   encode_unicode_escape,
    "punycode":         encode_punycode,
    "quoted_printable": encode_quoted_printable,
    "uuencode":         encode_uuencode,
}

DECODE_REGISTRY: Dict[str, Callable] = {
    "base64":           decode_base64,
    "base32":           decode_base32,
    "base16":           decode_base16,
    "base58":           decode_base58,
    "base85":           decode_base85,
    "ascii85":          decode_ascii85,
    "hex":              decode_hex,
    "binary":           decode_binary,
    "url":              decode_url,
    "html":             decode_html,
    "rot13":            decode_rot13,
    "rot47":            decode_rot47,
    "morse":            decode_morse,
    "nato":             decode_nato,
    "braille":          decode_braille,
    "caesar":           decode_caesar,
    "atbash":           decode_atbash,
    "vigenere":         decode_vigenere,
    "xor":              decode_xor,
    "reverse":          decode_reverse,
    "unicode_escape":   decode_unicode_escape,
    "punycode":         decode_punycode,
    "quoted_printable": decode_quoted_printable,
    "uuencode":         decode_uuencode,
}

# User plugin registries
_PLUGIN_ENCODE: Dict[str, Callable] = {}
_PLUGIN_DECODE: Dict[str, Callable] = {}


# ---------------------------------------------------------------------------
# Core API
# ---------------------------------------------------------------------------

def encode(text: str, fmt: str, **kwargs: Any) -> str:
    """
    Encode *text* into *fmt*.

    >>> encode("hello", "base64")
    'aGVsbG8='
    >>> encode("hello", "caesar", shift=3)
    'khoor'
    """
    key = fmt.lower().replace("-", "_")
    fn = _PLUGIN_ENCODE.get(key) or ENCODE_REGISTRY.get(key)
    if fn is None:
        raise UnknownFormatError(fmt, list(ENCODE_REGISTRY) + list(_PLUGIN_ENCODE))
    try:
        return fn(text, **kwargs) if kwargs else fn(text)
    except (UnknownFormatError, ValueError):
        raise
    except Exception as exc:
        raise EncodeError(text, exc) from exc


def decode(text: str, fmt: str, **kwargs: Any) -> str:
    """
    Decode *text* from *fmt*.

    >>> decode("aGVsbG8=", "base64")
    'hello'
    """
    key = fmt.lower().replace("-", "_")
    fn = _PLUGIN_DECODE.get(key) or DECODE_REGISTRY.get(key)
    if fn is None:
        raise UnknownFormatError(fmt, list(DECODE_REGISTRY) + list(_PLUGIN_DECODE))
    try:
        return fn(text, **kwargs) if kwargs else fn(text)
    except (UnknownFormatError, ValueError):
        raise
    except Exception as exc:
        raise DecodeError(text, exc) from exc


# ---------------------------------------------------------------------------
# Detection engine
# ---------------------------------------------------------------------------

# (format, pattern_check, decode_fn, base_confidence)
# High-specificity patterns get high base confidence.
# Low-specificity (rot13 / atbash) are NOT auto-detected to avoid false positives.
_DETECTORS: List[Tuple[str, Callable[[str], bool], Callable, float]] = [
    ("binary",
     lambda t: bool(re.fullmatch(r"[01]+( [01]+)+", t)) and all(len(b) == 8 for b in t.split()),
     decode_binary, 0.97),
    ("morse",
     lambda t: bool(re.fullmatch(r"[.\-]+([ /][.\-]+)*", t.strip())) and len(t) > 3,
     decode_morse, 0.95),
    ("url",
     lambda t: "%" in t and bool(re.search(r"%[0-9a-fA-F]{2}", t)),
     decode_url, 0.94),
    ("html",
     lambda t: bool(re.search(r"&[a-zA-Z]{2,8};|&#\d{1,5};|&#x[0-9a-fA-F]{1,6};", t)),
     decode_html, 0.93),
    ("unicode_escape",
     lambda t: bool(re.search(r"\\u[0-9a-fA-F]{4}|\\x[0-9a-fA-F]{2}", t)),
     decode_unicode_escape, 0.92),
    ("base32",
     lambda t: bool(re.fullmatch(r"[A-Z2-7]+=*", t.strip())) and len(t.strip().rstrip("=")) % 8 <= 7,
     decode_base32, 0.91),
    ("base64",
     lambda t: bool(re.fullmatch(r"[A-Za-z0-9+/]+=*", t.strip())) and len(t.strip()) % 4 == 0 and len(t.strip()) >= 4,
     decode_base64, 0.89),
    ("base16",
     lambda t: bool(re.fullmatch(r"[0-9A-F]+", t.strip().upper())) and len(t.strip()) % 2 == 0 and len(t.strip()) >= 4,
     decode_base16, 0.87),
    ("hex",
     lambda t: bool(re.fullmatch(r"([0-9a-fA-F]{2}[: ]?)+", t.strip())) and len(t.strip().replace(":", "").replace(" ", "")) % 2 == 0,
     decode_hex, 0.85),
    ("quoted_printable",
     lambda t: bool(re.search(r"=[0-9A-F]{2}", t)),
     decode_quoted_printable, 0.83),
]


def detect_format(text: str, min_confidence: float = 0.60) -> List[Dict[str, Any]]:
    """
    Analyse *text* and return a ranked list of probable encodings.

    Each result dict has keys: ``format``, ``confidence``, ``decoded``.

    Only results at or above *min_confidence* are returned.

    >>> detect_format("SGVsbG8=")[0]['format']
    'base64'
    """
    text = text.strip()
    results: List[Dict[str, Any]] = []

    for fmt, pattern_fn, decode_fn, base_conf in _DETECTORS:
        try:
            if not pattern_fn(text):
                continue
            decoded = decode_fn(text)
            if not decoded or decoded == text:
                continue
            printable_ratio = sum(c.isprintable() for c in decoded) / max(len(decoded), 1)
            confidence = round(base_conf * printable_ratio, 3)
            if confidence >= min_confidence:
                results.append({"format": fmt, "confidence": confidence, "decoded": decoded})
        except Exception:
            pass

    return sorted(results, key=lambda r: r["confidence"], reverse=True)


def magic_decode(text: str) -> List[Dict[str, Any]]:
    """
    Try every known decoder and return all plausible results, ranked.
    Perfect for CTF challenges, forensics, and mystery strings.

    >>> magic_decode("SGVsbG8=")[0]['decoded']
    'Hello'
    """
    return detect_format(text)


def smart_decode(text: str) -> str:
    """
    Auto-detect encoding and return the best decoded result.

    >>> smart_decode("SGVsbG8=")
    'Hello'
    """
    results = detect_format(text)
    if not results:
        raise DecodeError(text, ValueError("Unable to determine encoding"))
    return results[0]["decoded"]


# ---------------------------------------------------------------------------
# Deep / multi-layer decode
# ---------------------------------------------------------------------------

def deep_decode(
    text: str,
    max_layers: int = 10,
    min_confidence: float = 0.75,
) -> Dict[str, Any]:
    """
    Recursively unwrap multi-layer encodings.

    Returns::

        {
            "result":       str,
            "total_layers": int,
            "layers":       [{"layer": N, "format": str, "value": str}, ...]
        }

    Example::

        deep_decode("SGVsbG8%3D")
        # layers: url → base64 → "Hello"

    *min_confidence* prevents low-confidence guesses (e.g. rot13 on plain text)
    from being treated as real layers.
    """
    layers: List[Dict[str, Any]] = []
    current = text.strip()
    seen: set = {current}

    for _ in range(max_layers):
        results = detect_format(current, min_confidence=min_confidence)
        if not results:
            break
        best = results[0]
        decoded = best["decoded"]
        if decoded in seen:
            break
        layers.append({
            "layer":  len(layers) + 1,
            "format": best["format"],
            "value":  decoded,
        })
        seen.add(decoded)
        current = decoded

    return {"result": current, "total_layers": len(layers), "layers": layers}


# ---------------------------------------------------------------------------
# Pipeline
# ---------------------------------------------------------------------------

def pipeline(
    text: str,
    steps: List[Union[str, Tuple[str, Dict[str, Any]]]],
) -> str:
    """
    Chain encode/decode operations in sequence.

    Each step is either:

    * ``"base64_encode"``  — a plain string ending with ``_encode`` or ``_decode``
    * ``("caesar_encode", {"shift": 5})``  — a tuple with extra kwargs

    >>> pipeline("hello", ["base64_encode", "url_encode"])
    'aGVsbG8%3D'
    >>> pipeline("hello", [("caesar_encode", {"shift": 3}), "base64_encode"])
    'a2hvb3I='
    """
    result = text
    for i, step in enumerate(steps):
        kwargs: Dict[str, Any] = {}
        if isinstance(step, tuple):
            step, kwargs = step[0], step[1]

        step_lower = step.lower()
        try:
            if step_lower.endswith("_encode"):
                result = encode(result, step_lower[:-7], **kwargs)
            elif step_lower.endswith("_decode"):
                result = decode(result, step_lower[:-7], **kwargs)
            else:
                raise ValueError(
                    f"Step must end with '_encode' or '_decode', got '{step}'"
                )
        except (EncodeError, DecodeError, UnknownFormatError, ValueError) as exc:
            raise PipelineError(step, i, exc) from exc

    return result


# ---------------------------------------------------------------------------
# Plugin system
# ---------------------------------------------------------------------------

def register_codec(
    name: str,
    encoder: Optional[Callable] = None,
    decoder: Optional[Callable] = None,
) -> None:
    """
    Register a custom codec under *name* at runtime.

    >>> register_codec("shout", encoder=str.upper, decoder=str.lower)
    >>> encode("hello", "shout")
    'HELLO'
    """
    key = name.lower()
    if encoder:
        _PLUGIN_ENCODE[key] = encoder
    if decoder:
        _PLUGIN_DECODE[key] = decoder


def codec(name: str) -> Callable:
    """
    Class decorator — registers ``encode`` / ``decode`` methods as a codec.

    Usage::

        @codec("pigpen")
        class PigpenCodec:
            def encode(self, text: str) -> str: ...
            def decode(self, text: str) -> str: ...
    """
    def decorator(cls: type) -> type:
        instance = cls()
        register_codec(
            name,
            encoder=getattr(instance, "encode", None),
            decoder=getattr(instance, "decode", None),
        )
        return cls
    return decorator


def list_formats() -> Dict[str, List[str]]:
    """Return all available format names grouped by source."""
    return {
        "builtin": sorted(ENCODE_REGISTRY.keys()),
        "plugins": sorted(_PLUGIN_ENCODE.keys()),
    }


# ---------------------------------------------------------------------------
# Legacy / convenience helpers  (backward-compatible with v1)
# ---------------------------------------------------------------------------

def normalize_text(text: str, form: NormalizationForm = "NFC") -> str:
    """Apply Unicode normalization."""
    return unicodedata.normalize(form, text)


def detect_encoding(data: bytes) -> str:
    """Detect the character encoding of raw bytes."""
    if HAS_CHARDET:
        result = chardet.detect(data)
        return result["encoding"] or "utf-8"
    for enc in ("utf-8", "latin-1", "ascii"):
        try:
            data.decode(enc)
            return enc
        except UnicodeDecodeError:
            continue
    return "utf-8"


def auto_decode_bytes(data: bytes) -> str:
    """Convert raw bytes → str using auto-detected encoding."""
    enc = detect_encoding(data)
    try:
        return data.decode(enc)
    except UnicodeDecodeError:
        return data.decode("utf-8", errors="replace")


def decode_all(
    text: Union[str, bytes],
    normalization: Optional[NormalizationForm] = None,
    fallback: Optional[str] = None,
) -> str:
    """
    Apply URL + HTML + escape-sequence decoding in one pass.

    Kept for backward compatibility. For full auto-detection use
    :func:`magic_decode` or :func:`smart_decode` instead.
    """
    try:
        if isinstance(text, bytes):
            text = auto_decode_bytes(text)
        result = decode_escapes(text)
        result = decode_url(result)
        result = decode_html(result)
        if normalization:
            result = normalize_text(result, form=normalization)
        return result
    except Exception as exc:
        if fallback is not None:
            return fallback
        raise DecodeError(
            text if isinstance(text, str) else text.decode("ascii", errors="replace"),
            exc,
        ) from exc


def batch_decode(
    texts: List[Union[str, bytes]],
    workers: Optional[int] = None,
    **kwargs: Any,
) -> List[str]:
    """Parallel :func:`decode_all` over a list of strings."""
    workers = workers or min(32, (os.cpu_count() or 1) + 4)
    with ThreadPoolExecutor(max_workers=workers) as ex:
        return list(ex.map(lambda t: decode_all(t, **kwargs), texts))


def batch_process(
    texts: List[str],
    operation: str = "decode",
    fmt: Optional[str] = None,
    workers: Optional[int] = None,
) -> List[str]:
    """
    Parallel encode *or* decode of a list of strings.

    If *fmt* is omitted during decode, :func:`smart_decode` is used per item.
    """
    workers = workers or min(32, (os.cpu_count() or 1) + 4)
    with ThreadPoolExecutor(max_workers=workers) as ex:
        if operation == "encode" and fmt:
            return list(ex.map(lambda t: encode(t, fmt), texts))
        if fmt:
            return list(ex.map(lambda t: decode(t, fmt), texts))
        return list(ex.map(smart_decode, texts))
