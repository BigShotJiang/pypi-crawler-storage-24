"""
stringshift.cli
~~~~~~~~~~~~~~~
Command-line interface for stringshift.
"""

import argparse
import sys
import time
from typing import List, Optional

from . import (
    __version__,
    encode, decode,
    smart_decode, magic_decode, deep_decode,
    pipeline, batch_process, list_formats,
    UnknownFormatError, DecodeError, EncodeError, PipelineError,
)

ALL_FORMATS = list_formats()["builtin"]


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="stringshift",
        description="Advanced String Encoding / Decoding Toolkit — 24 formats",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=r"""
Examples:
  Auto-detect & decode:       stringshift "SGVsbG8="
  Encode to base64:           stringshift "Hello" -e base64
  Decode from hex:            stringshift "48656c6c6f" -d hex
  Show all candidates:        stringshift "SGVsbG8=" --magic
  Unwrap layered encoding:    stringshift "SGVsbG8%3D" --deep
  Pipeline (chained ops):     stringshift "hello" --pipeline base64_encode url_encode
  Caesar cipher:              stringshift "Hello" -e caesar --shift 3
  Vigenère cipher:            stringshift "Hello" -e vigenere --key secret
  Batch from stdin:           echo -e "aGVsbG8=\nd29ybGQ=" | stringshift --batch -d base64
  Batch from file:            stringshift -i encoded.txt -d base64
  List all formats:           stringshift --list
""",
    )

    # Input
    inp = parser.add_mutually_exclusive_group()
    inp.add_argument("input", nargs="?", help="Text to process")
    inp.add_argument("-i", "--input-file", metavar="FILE", help="Read from FILE")

    # Operations
    ops = parser.add_mutually_exclusive_group()
    ops.add_argument("-e", "--encode", choices=ALL_FORMATS, metavar="FORMAT",
                     help=f"Encode — choices: {', '.join(ALL_FORMATS)}")
    ops.add_argument("-d", "--decode", choices=ALL_FORMATS, metavar="FORMAT",
                     help="Decode — same choices as --encode")
    ops.add_argument("--magic", action="store_true",
                     help="Try all decoders, print ranked candidates")
    ops.add_argument("--deep", action="store_true",
                     help="Recursively unwrap multi-layer encodings")
    ops.add_argument("--pipeline", nargs="+", metavar="STEP",
                     help="Chain steps e.g. base64_encode url_encode")

    # Cipher options
    cipher = parser.add_argument_group("Cipher options")
    cipher.add_argument("--shift", type=int, default=13,
                        help="Caesar shift offset (default: 13 = ROT13)")
    cipher.add_argument("--key", default="key",
                        help="Vigenère key (default: 'key')")
    cipher.add_argument("--xor-key", type=int, default=42, metavar="N",
                        help="XOR key byte 0-255 (default: 42)")

    # Batch
    batch = parser.add_argument_group("Batch options")
    batch.add_argument("--batch", action="store_true",
                       help="Process each line from stdin separately")
    batch.add_argument("--workers", type=int, default=0,
                       help="Parallel worker threads (0=auto)")

    # Meta
    parser.add_argument("--benchmark", action="store_true",
                        help="Print processing time to stderr")
    parser.add_argument("--list", action="store_true",
                        help="List all supported formats and exit")
    parser.add_argument("-v", "--version", action="store_true",
                        help="Show version and exit")

    return parser


def _get_input(parsed: argparse.Namespace) -> str:
    if parsed.input_file:
        with open(parsed.input_file) as fh:
            return fh.read()
    if parsed.input:
        return parsed.input
    if not sys.stdin.isatty():
        return sys.stdin.read()
    return ""


def _cipher_kwargs(parsed: argparse.Namespace, fmt: str) -> dict:
    kwargs: dict = {}
    if fmt == "caesar":
        kwargs["shift"] = parsed.shift
    elif fmt == "vigenere":
        kwargs["key"] = parsed.key
    elif fmt == "xor":
        kwargs["key"] = parsed.xor_key
    return kwargs


def _interactive() -> None:
    print(f"stringshift {__version__}  —  interactive mode")
    print("Commands:  encode <fmt> <text>")
    print("           decode <fmt> <text>")
    print("           magic  <text>")
    print("           deep   <text>")
    print("           list")
    print(f"Formats:   {', '.join(ALL_FORMATS)}")
    print("Type 'exit' to quit.\n")

    while True:
        try:
            line = input("stringshift> ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\nGoodbye!")
            break

        if not line:
            continue
        if line.lower() in ("exit", "quit"):
            print("Goodbye!")
            break

        parts = line.split(maxsplit=2)
        cmd = parts[0].lower()

        try:
            if cmd == "list":
                fmts = list_formats()
                print("Built-in:", ", ".join(fmts["builtin"]))
                if fmts["plugins"]:
                    print("Plugins: ", ", ".join(fmts["plugins"]))

            elif cmd == "encode" and len(parts) == 3:
                print(encode(parts[2], parts[1]))

            elif cmd == "decode" and len(parts) == 3:
                print(decode(parts[2], parts[1]))

            elif cmd == "magic" and len(parts) >= 2:
                text = " ".join(parts[1:])
                results = magic_decode(text)
                if not results:
                    print("  No encoding detected.")
                else:
                    print(f"  {'Confidence':<12} {'Format':<18} Decoded")
                    print("  " + "-" * 52)
                    for r in results:
                        print(f"  {r['confidence']:.0%:<12} {r['format']:<18} {r['decoded']}")

            elif cmd == "deep" and len(parts) >= 2:
                text = " ".join(parts[1:])
                info = deep_decode(text)
                if not info["layers"]:
                    print("  No layers detected.")
                else:
                    for layer in info["layers"]:
                        print(f"  Layer {layer['layer']:2d}  [{layer['format']:<16}]  {layer['value']}")
                    print(f"  Result: {info['result']}")

            else:
                print("  Usage: encode|decode <fmt> <text>  |  magic <text>  |  deep <text>  |  list")

        except Exception as exc:
            print(f"  Error: {exc}")


def main(argv: Optional[List[str]] = None) -> None:
    t0 = time.perf_counter()
    parser = _build_parser()
    parsed = parser.parse_args(argv)

    if parsed.version:
        print(f"stringshift {__version__}")
        return

    if parsed.list:
        fmts = list_formats()
        print("Built-in formats:")
        for fmt in fmts["builtin"]:
            print(f"  {fmt}")
        if fmts["plugins"]:
            print("Plugin formats:")
            for fmt in fmts["plugins"]:
                print(f"  {fmt}")
        return

    text = _get_input(parsed)

    if not text and not parsed.batch:
        _interactive()
        return

    try:
        # ── Batch ─────────────────────────────────────────────────────────
        if parsed.batch:
            lines = [l for l in text.splitlines() if l.strip()]
            workers = parsed.workers or None
            if parsed.encode:
                results = batch_process(lines, operation="encode",
                                        fmt=parsed.encode, workers=workers)
            elif parsed.decode:
                results = batch_process(lines, operation="decode",
                                        fmt=parsed.decode, workers=workers)
            else:
                results = batch_process(lines, workers=workers)
            print("\n".join(results))

        # ── Magic ──────────────────────────────────────────────────────────
        elif parsed.magic:
            results = magic_decode(text.strip())
            if not results:
                print("No encoding detected.", file=sys.stderr)
                sys.exit(1)
            print(f"{'Confidence':<12} {'Format':<18} Decoded")
            print("-" * 54)
            for r in results:
                print(f"{r['confidence']:.0%:<12} {r['format']:<18} {r['decoded']}")

        # ── Deep ───────────────────────────────────────────────────────────
        elif parsed.deep:
            info = deep_decode(text.strip())
            if not info["layers"]:
                print("No layers detected.")
            else:
                for layer in info["layers"]:
                    print(f"Layer {layer['layer']:2d}  [{layer['format']:<16}]  {layer['value']}")
                print(f"\nFinal result: {info['result']}")

        # ── Pipeline ───────────────────────────────────────────────────────
        elif parsed.pipeline:
            print(pipeline(text.strip(), parsed.pipeline))

        # ── Encode ────────────────────────────────────────────────────────
        elif parsed.encode:
            kwargs = _cipher_kwargs(parsed, parsed.encode)
            print(encode(text.strip(), parsed.encode, **kwargs))

        # ── Decode ────────────────────────────────────────────────────────
        elif parsed.decode:
            kwargs = _cipher_kwargs(parsed, parsed.decode)
            print(decode(text.strip(), parsed.decode, **kwargs))

        # ── Auto ──────────────────────────────────────────────────────────
        else:
            print(smart_decode(text.strip()))

    except (UnknownFormatError, DecodeError, EncodeError, PipelineError) as exc:
        print(f"Error: {exc}", file=sys.stderr)
        sys.exit(1)
    except FileNotFoundError as exc:
        print(f"File not found: {exc}", file=sys.stderr)
        sys.exit(1)
    except KeyboardInterrupt:
        print("\nCancelled.", file=sys.stderr)
        sys.exit(130)
    except Exception as exc:
        print(f"Unexpected error: {exc}", file=sys.stderr)
        sys.exit(1)
    finally:
        if parsed.benchmark:
            elapsed = (time.perf_counter() - t0) * 1000
            print(f"\nTime: {elapsed:.2f}ms", file=sys.stderr)


if __name__ == "__main__":
    main()
