"""
stringshift
~~~~~~~~~~~
Advanced string encoding / decoding toolkit.

Quick start::

    import stringshift

    # Encode & decode any format
    stringshift.encode("hello", "base64")        # 'aGVsbG8='
    stringshift.decode("aGVsbG8=", "base64")     # 'hello'

    # Auto-detect what something is
    stringshift.magic_decode("SGVsbG8=")
    # [{'format': 'base64', 'confidence': 0.89, 'decoded': 'Hello'}]

    stringshift.smart_decode("SGVsbG8=")         # 'Hello'

    # Unwrap multi-layered encodings
    stringshift.deep_decode("SGVsbG8%3D")
    # {'result': 'Hello', 'total_layers': 2, 'layers': [...]}

    # Chain operations
    stringshift.pipeline("hello", ["base64_encode", "url_encode"])

    # Register your own codec
    @stringshift.codec("shout")
    class Shout:
        def encode(self, t): return t.upper()
        def decode(self, t): return t.lower()

    stringshift.encode("hello", "shout")         # 'HELLO'

Supported formats (24 built-in):
    base64, base32, base16, base58, base85, ascii85,
    hex, binary, url, html,
    rot13, rot47, morse, nato, braille,
    caesar, atbash, vigenere, xor,
    reverse, unicode_escape,
    punycode, quoted_printable, uuencode
"""

__version__ = "4.0.1"
__author__ = "DevBullions"
__license__ = "MIT"
__all__ = [
    # Core API
    "encode", "decode",
    # Auto-detection
    "detect_format", "magic_decode", "smart_decode",
    # Advanced
    "deep_decode", "pipeline",
    # Batch
    "batch_decode", "batch_process",
    # Individual encoders
    "encode_base64", "encode_base32", "encode_base16", "encode_base58", "encode_base85",
    "encode_ascii85", "encode_hex", "encode_binary", "encode_url", "encode_html",
    "encode_rot13", "encode_rot47", "encode_morse", "encode_nato", "encode_braille",
    "encode_caesar", "encode_atbash", "encode_vigenere", "encode_xor",
    "encode_reverse", "encode_unicode_escape",
    "encode_punycode", "encode_quoted_printable", "encode_uuencode",
    # Individual decoders
    "decode_base64", "decode_base32", "decode_base16", "decode_base58", "decode_base85",
    "decode_ascii85", "decode_hex", "decode_binary", "decode_url", "decode_html",
    "decode_rot13", "decode_rot47", "decode_morse", "decode_nato", "decode_braille",
    "decode_caesar", "decode_atbash", "decode_vigenere", "decode_xor",
    "decode_reverse", "decode_unicode_escape",
    "decode_punycode", "decode_quoted_printable", "decode_uuencode",
    # Legacy helpers (v1 compatible)
    "decode_all", "decode_escapes", "normalize_text", "detect_encoding",
    # Plugin system
    "register_codec", "codec", "list_formats",
    # Exceptions
    "StringShiftError", "DecodeError", "EncodeError", "UnknownFormatError", "PipelineError",
]

from .core import (
    encode, decode,
    detect_format, magic_decode, smart_decode,
    deep_decode, pipeline,
    batch_decode, batch_process,
    encode_base64, encode_base32, encode_base16, encode_base58, encode_base85,
    encode_ascii85, encode_hex, encode_binary, encode_url, encode_html,
    encode_rot13, encode_rot47, encode_morse, encode_nato, encode_braille,
    encode_caesar, encode_atbash, encode_vigenere, encode_xor,
    encode_reverse, encode_unicode_escape,
    encode_punycode, encode_quoted_printable, encode_uuencode,
    decode_base64, decode_base32, decode_base16, decode_base58, decode_base85,
    decode_ascii85, decode_hex, decode_binary, decode_url, decode_html,
    decode_rot13, decode_rot47, decode_morse, decode_nato, decode_braille,
    decode_caesar, decode_atbash, decode_vigenere, decode_xor,
    decode_reverse, decode_unicode_escape,
    decode_punycode, decode_quoted_printable, decode_uuencode,
    decode_all, decode_escapes, normalize_text, detect_encoding,
    register_codec, codec, list_formats,
)

from .exceptions import (
    StringShiftError, DecodeError, EncodeError, UnknownFormatError, PipelineError,
)
