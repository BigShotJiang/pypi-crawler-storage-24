"""Allow `python -m stringshift` to invoke the CLI."""
from .cli import main
main()
