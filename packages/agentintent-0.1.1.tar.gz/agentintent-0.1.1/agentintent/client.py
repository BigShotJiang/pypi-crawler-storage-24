"""
Cloud Client - Async, non-blocking communication with AgentIntent cloud.

All operations are async and batched to minimize latency impact.
"""

import json
import gzip
import time
import threading
import logging
from collections import deque
from typing import Dict, List, Any, Optional
from dataclasses import dataclass, field
from importlib.metadata import version, PackageNotFoundError

# Use requests if available, otherwise use urllib
try:
    import requests
    HAS_REQUESTS = True
except ImportError:
    import urllib.request
    import urllib.error
    HAS_REQUESTS = False

try:
    sdk_version = version("agentintent")
except PackageNotFoundError:
    sdk_version = "dev"



logger = logging.getLogger("agentintent")


@dataclass
class CloudConfig:
    """Configuration for cloud connection."""
    api_key: str
    base_url: str = "https://api.agentintent.ai/v1"
    batch_size: int = 100
    batch_interval_seconds: float = 5.0
    timeout_seconds: float = 10.0
    retry_attempts: int = 3
    compress: bool = False  # Disabled by default - API doesn't handle gzip properly yet


class CloudClient:
    """
    Async client for AgentIntent cloud.
    
    Features:
    - Non-blocking: All operations are async
    - Batched: Logs are batched and sent periodically
    - Resilient: Failures don't affect the agent
    - Compressed: Payloads are gzipped for efficiency
    """
    
    def __init__(self, config: CloudConfig):
        self.config = config
        
        # Log queue (thread-safe deque)
        self._log_queue: deque = deque(maxlen=10000)
        
        # Background thread for sending logs
        self._running = True
        self._thread = threading.Thread(target=self._background_loop, daemon=True)
        self._thread.start()
        
        # Session info
        self._session_id: Optional[str] = None
        self._agent_id: Optional[str] = None
        
        # Metrics
        self._metrics = {
            "logs_queued": 0,
            "logs_sent": 0,
            "logs_failed": 0,
            "batches_sent": 0,
            "bytes_sent": 0,
        }
    
    def set_session(self, session_id: str, agent_id: str = None):
        """Set the current session ID."""
        self._session_id = session_id
        self._agent_id = agent_id
    
    def log_action(
        self,
        action_dict: Dict[str, Any],
        blocked: bool = False,
        reason: str = None,
        error: bool = False
    ):
        """
        Queue an action for logging.
        
        This is non-blocking and returns immediately.
        """
        log_entry = {
            "action": action_dict,
            "session_id": self._session_id,
            "agent_id": self._agent_id,
            "blocked": blocked,
            "reason": reason,
            "error": error,
            "queued_at": time.time(),
        }
        
        self._log_queue.append(log_entry)
        self._metrics["logs_queued"] += 1
    
    def log_batch(self, actions: List[Dict[str, Any]]):
        """Queue multiple actions for logging."""
        for action in actions:
            self.log_action(action)
    
    def flush(self):
        """Force flush all pending logs."""
        self._send_logs()
    
    def _background_loop(self):
        """Background loop for sending logs."""
        while self._running:
            time.sleep(self.config.batch_interval_seconds)
            try:
                self._send_logs()
            except Exception as e:
                logger.warning(f"Error in background log sender: {e}")
    
    def _send_logs(self):
        """Send all queued logs to cloud."""
        if not self._log_queue:
            return
        
        # Drain queue
        batch = []
        while self._log_queue and len(batch) < self.config.batch_size:
            try:
                batch.append(self._log_queue.popleft())
            except IndexError:
                break
        
        if not batch:
            return
        
        # Send batch
        try:
            self._send_batch(batch)
            self._metrics["logs_sent"] += len(batch)
            self._metrics["batches_sent"] += 1
        except Exception as e:
            logger.warning(f"Failed to send logs: {e}")
            self._metrics["logs_failed"] += len(batch)
            # Re-queue failed logs (at the front)
            for item in reversed(batch):
                self._log_queue.appendleft(item)
    
    def _send_batch(self, batch: List[Dict]):
        """Send a batch of logs to the API."""
        # Transform to match backend expected format (LogBatch model)
        formatted_logs = []
        for log in batch:
            action_data = log.get("action", {})

            # Extract metadata from action if it's in Action.to_dict() format
            # The API expects simple action dict with tool names and params,
            # not the full Action structure with id, type, timestamp, etc.
            if isinstance(action_data, dict) and "metadata" in action_data:
                # This is from Action.to_dict(), extract the metadata
                simple_action = action_data.get("metadata", {})
                # Add type info if it's a tool call
                if action_data.get("type") == "tool_call" and "tool_name" in simple_action:
                    simple_action["tool"] = simple_action.pop("tool_name")
            else:
                # This is already in simple format
                simple_action = action_data

            formatted_logs.append({
                "action": simple_action,
                "session_id": log.get("session_id"),
                "agent_id": log.get("agent_id"),
                "blocked": log.get("blocked", False),
                "reason": log.get("reason"),
                "error": log.get("error", False),
                "queued_at": log.get("queued_at", time.time())
            })

        payload = json.dumps({
            "logs": formatted_logs,
            "sdk_version": sdk_version,
            "timestamp": time.time(),
        })

        # Compress if enabled
        if self.config.compress:
            payload_bytes = gzip.compress(payload.encode())
            content_encoding = "gzip"
        else:
            payload_bytes = payload.encode()
            content_encoding = None
        
        self._metrics["bytes_sent"] += len(payload_bytes)
        
        # Send request
        url = f"{self.config.base_url}/logs"
        headers = {
            "Authorization": self.config.api_key,  # AgentIntent uses direct API key (no Bearer prefix)
            "Content-Type": "application/json",
        }
        if content_encoding:
            headers["Content-Encoding"] = content_encoding
        
        if HAS_REQUESTS:
            response = requests.post(
                url,
                data=payload_bytes,
                headers=headers,
                timeout=self.config.timeout_seconds
            )
            response.raise_for_status()
        else:
            req = urllib.request.Request(
                url,
                data=payload_bytes,
                headers=headers,
                method="POST"
            )
            with urllib.request.urlopen(req, timeout=self.config.timeout_seconds) as response:
                if response.status >= 400:
                    raise Exception(f"HTTP {response.status}")
    
    def get_trust_score(self, agent_id: str) -> Optional[Dict]:
        """
        Get trust score for an agent.
        
        This is a synchronous call (blocking).
        """
        url = f"{self.config.base_url}/trust-score/{agent_id}"
        headers = {
            "Authorization": f"Bearer {self.config.api_key}",
        }
        
        try:
            if HAS_REQUESTS:
                response = requests.get(
                    url,
                    headers=headers,
                    timeout=self.config.timeout_seconds
                )
                response.raise_for_status()
                return response.json()
            else:
                req = urllib.request.Request(url, headers=headers)
                with urllib.request.urlopen(req, timeout=self.config.timeout_seconds) as response:
                    return json.loads(response.read().decode())
        except Exception as e:
            logger.warning(f"Failed to get trust score: {e}")
            return None
    
    def register_agent(self, manifest_dict: Dict) -> Optional[str]:
        """
        Register an agent with AgentIntent.
        
        Returns the agent ID if successful.
        """
        url = f"{self.config.base_url}/agents"
        headers = {
            "Authorization": f"Bearer {self.config.api_key}",
            "Content-Type": "application/json",
        }
        payload = json.dumps({"manifest": manifest_dict})
        
        try:
            if HAS_REQUESTS:
                response = requests.post(
                    url,
                    data=payload,
                    headers=headers,
                    timeout=self.config.timeout_seconds
                )
                response.raise_for_status()
                return response.json().get("agent_id")
            else:
                req = urllib.request.Request(
                    url,
                    data=payload.encode(),
                    headers=headers,
                    method="POST"
                )
                with urllib.request.urlopen(req, timeout=self.config.timeout_seconds) as response:
                    return json.loads(response.read().decode()).get("agent_id")
        except Exception as e:
            logger.warning(f"Failed to register agent: {e}")
            return None
    
    def get_metrics(self) -> Dict[str, int]:
        """Get client metrics."""
        return {
            **self._metrics,
            "queue_size": len(self._log_queue),
        }
    
    def close(self):
        """Shutdown the client."""
        self._running = False
        self.flush()
        self._thread.join(timeout=5.0)


class MockCloudClient(CloudClient):
    """
    Mock client for testing without network calls.
    
    Stores all logs in memory for inspection.
    """
    
    def __init__(self, config: CloudConfig = None):
        if config is None:
            config = CloudConfig(api_key="test_key", base_url="http://localhost")
        
        self.config = config
        self._log_queue = deque(maxlen=10000)
        self._sent_logs: List[Dict] = []
        self._session_id = None
        self._agent_id = None
        self._metrics = {
            "logs_queued": 0,
            "logs_sent": 0,
            "logs_failed": 0,
            "batches_sent": 0,
            "bytes_sent": 0,
        }
        
        # Don't start background thread
        self._running = False
        self._thread = None
    
    def _send_batch(self, batch: List[Dict]):
        """Store batch in memory instead of sending."""
        self._sent_logs.extend(batch)
    
    def get_sent_logs(self) -> List[Dict]:
        """Get all sent logs (for testing)."""
        return self._sent_logs
    
    def clear_logs(self):
        """Clear sent logs (for testing)."""
        self._sent_logs.clear()
    
    def close(self):
        """No-op for mock client."""
        pass
