"""
Local Enforcer - Fast, local-only enforcement of intent manifests.

This runs in <1ms and doesn't require network calls.
"""

from dataclasses import dataclass
from typing import Optional, Dict, Any
from collections import defaultdict
import time
import threading

from .manifest import IntentManifest
from .actions import Action, ActionType, ActionResult


@dataclass
class RateLimitState:
    """Tracks rate limits per action type."""
    counts: Dict[str, int]
    window_start: float
    window_size: float = 60.0  # 1 minute windows
    
    def __init__(self, window_size: float = 60.0):
        self.counts = defaultdict(int)
        self.window_start = time.time()
        self.window_size = window_size
        self._lock = threading.Lock()
    
    def increment(self, action_type: str) -> int:
        """Increment count for action type, return current count."""
        with self._lock:
            now = time.time()
            
            # Reset if window has passed
            if now - self.window_start >= self.window_size:
                self.counts.clear()
                self.window_start = now
            
            self.counts[action_type] += 1
            return self.counts[action_type]
    
    def get_count(self, action_type: str) -> int:
        """Get current count for action type."""
        with self._lock:
            now = time.time()
            if now - self.window_start >= self.window_size:
                return 0
            return self.counts.get(action_type, 0)


class LocalEnforcer:
    """
    Fast, local enforcement of intent manifests.
    
    All checks happen in-memory with no network calls.
    Target latency: <1ms per check.
    """
    
    def __init__(self, manifest: IntentManifest):
        self.manifest = manifest
        self._rate_limits = RateLimitState()
        
        # Pre-compute sets for O(1) lookups
        self._forbidden_tools_set = set(
            t.lower() for t in manifest.forbidden_tools
        )
        self._allowed_tools_set = set(
            t.lower() for t in manifest.allowed_tools
        ) if manifest.allowed_tools else None
        
        self._forbidden_actions_set = set(
            a.lower() for a in manifest.forbidden_actions
        )
        self._allowed_actions_set = set(
            a.lower() for a in manifest.allowed_actions
        ) if manifest.allowed_actions else None
    
    def check(self, action: Action) -> ActionResult:
        """
        Check if an action is allowed.
        
        This is the main entry point for enforcement.
        Returns ActionResult with allowed/blocked status.
        """
        # Check based on action type
        if action.type == ActionType.TOOL_CALL:
            tool_name = action.metadata.get("tool_name", "")
            return self.check_tool(tool_name)
        
        elif action.type == ActionType.API_REQUEST:
            url = action.metadata.get("url", action.metadata.get("endpoint", ""))
            return self.check_api(url)
        
        elif action.type in (ActionType.DATA_READ, ActionType.DATA_WRITE):
            source = action.metadata.get("source", action.metadata.get("table", ""))
            return self.check_data_access(source)
        
        elif action.type == ActionType.LLM_REQUEST:
            return self.check_llm_call()
        
        # Default: check rate limits only
        return self._check_rate_limit(action.type.value)
    
    def check_tool(self, tool_name: str) -> ActionResult:
        """Check if a tool is allowed."""
        if not tool_name:
            return ActionResult(allowed=True)
        
        tool_lower = tool_name.lower()
        
        # Check forbidden list (O(1))
        if tool_lower in self._forbidden_tools_set:
            return ActionResult(
                allowed=False,
                reason=f"Tool '{tool_name}' is forbidden by manifest"
            )
        
        # Check allowed list if it exists (O(1))
        if self._allowed_tools_set is not None:
            if tool_lower not in self._allowed_tools_set:
                return ActionResult(
                    allowed=False,
                    reason=f"Tool '{tool_name}' is not in allowed list"
                )
        
        # Check rate limit
        rate_result = self._check_rate_limit("tool_calls")
        if not rate_result.allowed:
            return rate_result
        
        return ActionResult(allowed=True)
    
    def check_api(self, url: str) -> ActionResult:
        """Check if an API call is allowed."""
        if not url:
            return ActionResult(allowed=True)
        
        allowed, reason = self.manifest.is_api_allowed(url)
        
        if not allowed:
            return ActionResult(allowed=False, reason=reason)
        
        # Check rate limit
        rate_result = self._check_rate_limit("api_calls")
        if not rate_result.allowed:
            return rate_result
        
        return ActionResult(allowed=True)
    
    def check_data_access(self, source: str) -> ActionResult:
        """Check if data access is allowed."""
        if not source:
            return ActionResult(allowed=True)
        
        allowed, reason = self.manifest.is_data_source_allowed(source)
        
        if not allowed:
            return ActionResult(allowed=False, reason=reason)
        
        return ActionResult(allowed=True)
    
    def check_llm_call(self) -> ActionResult:
        """Check if LLM call is allowed (mainly rate limiting)."""
        return self._check_rate_limit("llm_calls")
    
    def check_action_name(self, action_name: str) -> ActionResult:
        """Check if a named action is allowed."""
        if not action_name:
            return ActionResult(allowed=True)
        
        action_lower = action_name.lower()
        
        # Check forbidden
        if action_lower in self._forbidden_actions_set:
            return ActionResult(
                allowed=False,
                reason=f"Action '{action_name}' is forbidden"
            )
        
        # Check allowed list if exists
        if self._allowed_actions_set is not None:
            if action_lower not in self._allowed_actions_set:
                return ActionResult(
                    allowed=False,
                    reason=f"Action '{action_name}' is not in allowed list"
                )
        
        return ActionResult(allowed=True)
    
    def _check_rate_limit(self, action_type: str) -> ActionResult:
        """Check and update rate limit."""
        current = self._rate_limits.increment(action_type)
        allowed, reason = self.manifest.check_rate_limit(action_type, current)
        
        if not allowed:
            return ActionResult(allowed=False, reason=reason)
        
        return ActionResult(allowed=True)
    
    def get_enforcement_mode(self) -> str:
        """Get the enforcement mode from manifest."""
        return self.manifest.enforcement_mode
    
    def should_block(self) -> bool:
        """Check if we should block on violations."""
        return self.manifest.enforcement_mode == "block"
    
    def should_warn(self) -> bool:
        """Check if we should warn on violations."""
        return self.manifest.enforcement_mode in ("block", "warn")


class EnforcementError(Exception):
    """Raised when an action is blocked by enforcement."""
    
    def __init__(self, message: str, action: Action = None, result: ActionResult = None):
        super().__init__(message)
        self.action = action
        self.result = result
