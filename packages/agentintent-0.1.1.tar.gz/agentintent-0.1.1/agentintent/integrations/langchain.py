"""
LangChain Integration for AgentIntent.

This provides a callback handler that plugs into LangChain's callback system.
Just add it to your agent and all actions are automatically monitored.

Usage:
    from agentintent import AgentIntent
    from langchain.agents import AgentExecutor
    
    ai = AgentIntent(api_key="ai_xxx", manifest=manifest)
    callback = ai.langchain_callback()
    
    agent = AgentExecutor(..., callbacks=[callback])
"""

from typing import Any, Dict, List, Optional, Union
from uuid import UUID
import time
import logging

# LangChain imports - these are optional
try:
    from langchain_core.callbacks import BaseCallbackHandler
    from langchain_core.outputs import LLMResult
    from langchain_core.agents import AgentAction, AgentFinish
    from langchain_core.messages import BaseMessage
    LANGCHAIN_AVAILABLE = True
except ImportError:
    try:
        # Fallback to older import paths
        from langchain.callbacks.base import BaseCallbackHandler
        from langchain.schema import LLMResult, AgentAction, AgentFinish
        from langchain.schema.messages import BaseMessage
        LANGCHAIN_AVAILABLE = True
    except ImportError:
        LANGCHAIN_AVAILABLE = False
        BaseCallbackHandler = object  # Placeholder

from ..actions import Action, ActionType
from ..enforcer import LocalEnforcer, EnforcementError


logger = logging.getLogger("agentintent.langchain")


class AgentIntentCallbackHandler(BaseCallbackHandler):
    """
    LangChain callback handler for AgentIntent.
    
    Automatically monitors all LLM calls, tool usage, and agent decisions.
    
    Usage:
        # Method 1: Quick setup
        from agentintent import AgentIntentCallback
        agent = AgentExecutor(..., callbacks=[AgentIntentCallback("ai_xxx")])
        
        # Method 2: With manifest
        from agentintent import AgentIntent, IntentManifest
        manifest = IntentManifest(name="MyAgent", forbidden_tools=["dangerous"])
        ai = AgentIntent(api_key="ai_xxx", manifest=manifest)
        callback = ai.langchain_callback()
        agent = AgentExecutor(..., callbacks=[callback])
    """
    
    def __init__(
        self,
        api_key: str = None,
        manifest = None,
        # Internal use - passed from AgentIntent.langchain_callback()
        core = None,
        enforcer: LocalEnforcer = None,
        client = None,
        session_id: str = None,
        block_on_violation: bool = True,
    ):
        """
        Initialize callback handler.
        
        Args:
            api_key: AgentIntent API key (if not using core)
            manifest: Intent manifest (if not using core)
            core: AgentIntent core instance (internal)
            enforcer: LocalEnforcer instance (internal)
            client: CloudClient instance (internal)
            session_id: Session ID (internal)
            block_on_violation: Whether to raise exception on violations
        """
        if not LANGCHAIN_AVAILABLE:
            raise ImportError(
                "LangChain is not installed. Install it with: pip install langchain"
            )
        
        super().__init__()
        
        # If api_key provided, create our own core
        if api_key and not core:
            from ..core import AgentIntent
            from ..manifest import IntentManifest
            core = AgentIntent(
                api_key=api_key,
                manifest=manifest or IntentManifest.default()
            )
            enforcer = core._enforcer
            client = core._client
            session_id = core._session_id
        
        self._core = core
        self._enforcer = enforcer
        self._client = client
        self._session_id = session_id
        self._block_on_violation = block_on_violation
        
        # Track active actions for duration calculation
        self._action_stack: Dict[str, Dict] = {}
        
        # Metrics
        self._metrics = {
            "llm_calls": 0,
            "tool_calls": 0,
            "agent_actions": 0,
            "chains": 0,
            "retrievals": 0,
            "blocked": 0,
            "total_tokens": 0,
        }
    
    # =========================================================================
    # LLM CALLBACKS
    # =========================================================================
    
    def on_llm_start(
        self,
        serialized: Dict[str, Any],
        prompts: List[str],
        *,
        run_id: UUID,
        parent_run_id: Optional[UUID] = None,
        tags: Optional[List[str]] = None,
        metadata: Optional[Dict[str, Any]] = None,
        **kwargs: Any,
    ) -> None:
        """Called when LLM starts."""
        
        model_name = self._extract_model_name(serialized)
        
        action = Action(
            id=str(run_id),
            type=ActionType.LLM_REQUEST,
            metadata={
                "model": model_name,
                "prompt_count": len(prompts),
                "prompt_chars": sum(len(p) for p in prompts),
                "tags": tags or [],
            }
        )
        
        # Check enforcement
        result = self._enforcer.check(action)
        
        if result.blocked:
            self._metrics["blocked"] += 1
            self._log_action(action, blocked=True, reason=result.reason)
            
            if self._block_on_violation and self._enforcer.should_block():
                raise EnforcementError(
                    f"LLM call blocked: {result.reason}",
                    action=action,
                    result=result
                )
        
        # Track for duration
        self._action_stack[str(run_id)] = {
            "action": action,
            "start_time": time.perf_counter()
        }
        
        self._metrics["llm_calls"] += 1
    
    def on_llm_end(
        self,
        response: "LLMResult",
        *,
        run_id: UUID,
        parent_run_id: Optional[UUID] = None,
        **kwargs: Any,
    ) -> None:
        """Called when LLM finishes."""
        
        action_data = self._pop_action(str(run_id))
        if not action_data:
            return
        
        duration = time.perf_counter() - action_data["start_time"]
        action = action_data["action"]
        
        # Extract token usage
        token_usage = self._extract_token_usage(response)
        
        action.duration_ms = duration * 1000
        action.metadata.update({
            "success": True,
            "prompt_tokens": token_usage.get("prompt_tokens", 0),
            "completion_tokens": token_usage.get("completion_tokens", 0),
            "total_tokens": token_usage.get("total_tokens", 0),
        })
        
        self._metrics["total_tokens"] += token_usage.get("total_tokens", 0)
        self._log_action(action)
    
    def on_llm_error(
        self,
        error: Union[Exception, KeyboardInterrupt],
        *,
        run_id: UUID,
        parent_run_id: Optional[UUID] = None,
        **kwargs: Any,
    ) -> None:
        """Called on LLM error."""
        
        action_data = self._pop_action(str(run_id))
        if not action_data:
            return
        
        duration = time.perf_counter() - action_data["start_time"]
        action = action_data["action"]
        
        action.duration_ms = duration * 1000
        action.metadata.update({
            "success": False,
            "error_type": type(error).__name__,
            "error_message": str(error)[:500],
        })
        
        self._log_action(action, error=True)
    
    # =========================================================================
    # TOOL CALLBACKS
    # =========================================================================
    
    def on_tool_start(
        self,
        serialized: Dict[str, Any],
        input_str: str,
        *,
        run_id: UUID,
        parent_run_id: Optional[UUID] = None,
        tags: Optional[List[str]] = None,
        metadata: Optional[Dict[str, Any]] = None,
        **kwargs: Any,
    ) -> None:
        """Called when a tool starts."""
        
        tool_name = serialized.get("name", "unknown")
        
        action = Action(
            id=str(run_id),
            type=ActionType.TOOL_CALL,
            metadata={
                "tool_name": tool_name,
                "tool_description": serialized.get("description", "")[:200],
                "input_length": len(input_str),
                "tags": tags or [],
            }
        )
        
        # Check enforcement - tools are important!
        result = self._enforcer.check_tool(tool_name)
        
        if result.blocked:
            self._metrics["blocked"] += 1
            self._log_action(action, blocked=True, reason=result.reason)
            
            if self._block_on_violation and self._enforcer.should_block():
                raise EnforcementError(
                    f"Tool '{tool_name}' blocked: {result.reason}",
                    action=action,
                    result=result
                )
        
        self._action_stack[str(run_id)] = {
            "action": action,
            "start_time": time.perf_counter()
        }
        
        self._metrics["tool_calls"] += 1
    
    def on_tool_end(
        self,
        output: str,
        *,
        run_id: UUID,
        parent_run_id: Optional[UUID] = None,
        **kwargs: Any,
    ) -> None:
        """Called when a tool finishes."""
        
        action_data = self._pop_action(str(run_id))
        if not action_data:
            return
        
        duration = time.perf_counter() - action_data["start_time"]
        action = action_data["action"]
        
        action.duration_ms = duration * 1000
        action.metadata.update({
            "success": True,
            "output_length": len(str(output)),
        })
        
        self._log_action(action)
    
    def on_tool_error(
        self,
        error: Union[Exception, KeyboardInterrupt],
        *,
        run_id: UUID,
        parent_run_id: Optional[UUID] = None,
        **kwargs: Any,
    ) -> None:
        """Called on tool error."""
        
        action_data = self._pop_action(str(run_id))
        if not action_data:
            return
        
        duration = time.perf_counter() - action_data["start_time"]
        action = action_data["action"]
        
        action.duration_ms = duration * 1000
        action.metadata.update({
            "success": False,
            "error_type": type(error).__name__,
            "error_message": str(error)[:500],
        })
        
        self._log_action(action, error=True)
    
    # =========================================================================
    # AGENT CALLBACKS
    # =========================================================================
    
    def on_agent_action(
        self,
        action: "AgentAction",
        *,
        run_id: UUID,
        parent_run_id: Optional[UUID] = None,
        **kwargs: Any,
    ) -> None:
        """Called when agent decides on an action."""
        
        ai_action = Action(
            id=str(run_id),
            type=ActionType.AGENT_DECISION,
            metadata={
                "tool_selected": action.tool,
                "reasoning_length": len(action.log) if action.log else 0,
            }
        )
        
        # Check if selected tool is allowed
        result = self._enforcer.check_tool(action.tool)
        
        if result.blocked:
            self._metrics["blocked"] += 1
            ai_action.blocked = True
            ai_action.block_reason = result.reason
            
            if self._block_on_violation and self._enforcer.should_block():
                raise EnforcementError(
                    f"Agent selected forbidden tool '{action.tool}': {result.reason}",
                    action=ai_action,
                    result=result
                )
        
        self._log_action(ai_action, blocked=result.blocked, reason=result.reason)
        self._metrics["agent_actions"] += 1
    
    def on_agent_finish(
        self,
        finish: "AgentFinish",
        *,
        run_id: UUID,
        parent_run_id: Optional[UUID] = None,
        **kwargs: Any,
    ) -> None:
        """Called when agent completes."""
        
        action = Action(
            id=str(run_id),
            type=ActionType.AGENT_FINISH,
            metadata={
                "output_keys": list(finish.return_values.keys()),
                "output_length": sum(
                    len(str(v)) for v in finish.return_values.values()
                ),
            }
        )
        
        self._log_action(action)
    
    # =========================================================================
    # CHAIN CALLBACKS
    # =========================================================================
    
    def on_chain_start(
        self,
        serialized: Dict[str, Any],
        inputs: Dict[str, Any],
        *,
        run_id: UUID,
        parent_run_id: Optional[UUID] = None,
        tags: Optional[List[str]] = None,
        metadata: Optional[Dict[str, Any]] = None,
        **kwargs: Any,
    ) -> None:
        """Called when a chain starts."""
        
        chain_name = self._extract_chain_name(serialized)
        
        action = Action(
            id=str(run_id),
            type=ActionType.CHAIN_START,
            metadata={
                "chain_name": chain_name,
                "input_keys": list(inputs.keys()),
                "parent_run_id": str(parent_run_id) if parent_run_id else None,
            }
        )
        
        self._action_stack[str(run_id)] = {
            "action": action,
            "start_time": time.perf_counter()
        }
        
        self._metrics["chains"] += 1
    
    def on_chain_end(
        self,
        outputs: Dict[str, Any],
        *,
        run_id: UUID,
        parent_run_id: Optional[UUID] = None,
        **kwargs: Any,
    ) -> None:
        """Called when a chain ends."""
        
        action_data = self._pop_action(str(run_id))
        if not action_data:
            return
        
        duration = time.perf_counter() - action_data["start_time"]
        action = action_data["action"]
        
        action.duration_ms = duration * 1000
        action.metadata.update({
            "success": True,
            "output_keys": list(outputs.keys()),
        })
        
        self._log_action(action)
    
    def on_chain_error(
        self,
        error: Union[Exception, KeyboardInterrupt],
        *,
        run_id: UUID,
        parent_run_id: Optional[UUID] = None,
        **kwargs: Any,
    ) -> None:
        """Called on chain error."""
        
        action_data = self._pop_action(str(run_id))
        if not action_data:
            return
        
        duration = time.perf_counter() - action_data["start_time"]
        action = action_data["action"]
        
        action.duration_ms = duration * 1000
        action.metadata.update({
            "success": False,
            "error_type": type(error).__name__,
            "error_message": str(error)[:500],
        })
        
        self._log_action(action, error=True)
    
    # =========================================================================
    # RETRIEVAL CALLBACKS
    # =========================================================================
    
    def on_retriever_start(
        self,
        serialized: Dict[str, Any],
        query: str,
        *,
        run_id: UUID,
        parent_run_id: Optional[UUID] = None,
        tags: Optional[List[str]] = None,
        metadata: Optional[Dict[str, Any]] = None,
        **kwargs: Any,
    ) -> None:
        """Called when retriever starts."""
        
        action = Action(
            id=str(run_id),
            type=ActionType.RETRIEVAL_START,
            metadata={
                "retriever_type": serialized.get("name", "unknown"),
                "query_length": len(query),
            }
        )
        
        self._action_stack[str(run_id)] = {
            "action": action,
            "start_time": time.perf_counter()
        }
        
        self._metrics["retrievals"] += 1
    
    def on_retriever_end(
        self,
        documents,
        *,
        run_id: UUID,
        parent_run_id: Optional[UUID] = None,
        **kwargs: Any,
    ) -> None:
        """Called when retriever ends."""
        
        action_data = self._pop_action(str(run_id))
        if not action_data:
            return
        
        duration = time.perf_counter() - action_data["start_time"]
        action = action_data["action"]
        
        action.duration_ms = duration * 1000
        action.metadata.update({
            "success": True,
            "documents_retrieved": len(documents) if documents else 0,
        })
        
        self._log_action(action)
    
    def on_retriever_error(
        self,
        error: Union[Exception, KeyboardInterrupt],
        *,
        run_id: UUID,
        parent_run_id: Optional[UUID] = None,
        **kwargs: Any,
    ) -> None:
        """Called on retriever error."""
        
        action_data = self._pop_action(str(run_id))
        if not action_data:
            return
        
        duration = time.perf_counter() - action_data["start_time"]
        action = action_data["action"]
        
        action.duration_ms = duration * 1000
        action.metadata.update({
            "success": False,
            "error_type": type(error).__name__,
            "error_message": str(error)[:500],
        })
        
        self._log_action(action, error=True)
    
    # =========================================================================
    # HELPER METHODS
    # =========================================================================
    
    def _pop_action(self, run_id: str) -> Optional[Dict]:
        """Pop action from stack."""
        return self._action_stack.pop(run_id, None)
    
    def _log_action(
        self,
        action: Action,
        blocked: bool = False,
        reason: str = None,
        error: bool = False
    ):
        """Log action to cloud."""
        if self._client:
            self._client.log_action(
                action.to_dict(),
                blocked=blocked,
                reason=reason,
                error=error
            )
    
    def _extract_model_name(self, serialized: Dict) -> str:
        """Extract model name from serialized data."""
        # Try different locations
        if "name" in serialized:
            return serialized["name"]
        if "id" in serialized:
            id_parts = serialized["id"]
            if isinstance(id_parts, list) and id_parts:
                return id_parts[-1]
        if "model" in serialized:
            return serialized["model"]
        if "model_name" in serialized:
            return serialized["model_name"]
        return "unknown"
    
    def _extract_chain_name(self, serialized: Dict) -> str:
        """Extract chain name from serialized data."""
        if "name" in serialized:
            return serialized["name"]
        if "id" in serialized:
            id_parts = serialized["id"]
            if isinstance(id_parts, list) and id_parts:
                return id_parts[-1]
        return "unknown_chain"
    
    def _extract_token_usage(self, response) -> Dict[str, int]:
        """Extract token usage from LLM response."""
        usage = {}
        
        if hasattr(response, "llm_output") and response.llm_output:
            token_usage = response.llm_output.get("token_usage", {})
            usage = {
                "prompt_tokens": token_usage.get("prompt_tokens", 0),
                "completion_tokens": token_usage.get("completion_tokens", 0),
                "total_tokens": token_usage.get("total_tokens", 0),
            }
        
        return usage
    
    def get_metrics(self) -> Dict[str, int]:
        """Get callback metrics."""
        return self._metrics.copy()


# Convenience alias
AgentIntentCallback = AgentIntentCallbackHandler
