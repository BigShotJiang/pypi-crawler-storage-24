"""
Universal wrapper functions for AgentIntent.

These provide framework-agnostic monitoring for any Python code.
"""

from typing import Callable, TypeVar, Any, Optional
from functools import wraps
import time
from contextlib import contextmanager

from .manifest import IntentManifest
from .actions import Action, ActionType


T = TypeVar('T')


def monitor(
    agent_or_func,
    api_key: str = None,
    manifest: IntentManifest = None,
    **kwargs
):
    """
    Universal monitor that auto-detects the agent type.
    
    Usage:
        from agentintent import monitor
        
        # Auto-detect and wrap any agent
        monitored = monitor(my_agent, api_key="ai_xxx")
        
        # Or use as decorator
        @monitor(api_key="ai_xxx")
        def my_function():
            pass
    """
    # If called with just api_key (decorator with args)
    if agent_or_func is None or isinstance(agent_or_func, str):
        if isinstance(agent_or_func, str):
            api_key = agent_or_func
        def decorator(func):
            return _wrap_callable(func, api_key, manifest)
        return decorator
    
    # Auto-detect agent type
    agent = agent_or_func
    
    # Check for LangChain
    if _is_langchain_agent(agent):
        return _wrap_langchain(agent, api_key, manifest)
    
    # Check for CrewAI
    if _is_crewai_agent(agent):
        return _wrap_crewai(agent, api_key, manifest)
    
    # Check for AutoGen
    if _is_autogen_agent(agent):
        return _wrap_autogen(agent, api_key, manifest)
    
    # Fallback: wrap as callable
    if callable(agent):
        return _wrap_callable(agent, api_key, manifest)
    
    raise TypeError(f"Cannot monitor object of type {type(agent)}")


def track(api_key: str, operation_name: str, manifest: IntentManifest = None):
    """
    Context manager for tracking a code block.
    
    Usage:
        from agentintent import track
        
        with track("ai_xxx", "my_operation"):
            # Your code here
            pass
    """
    return _TrackContext(api_key, operation_name, manifest)


class _TrackContext:
    """Context manager for tracking operations."""
    
    def __init__(self, api_key: str, operation_name: str, manifest: IntentManifest = None):
        self.api_key = api_key
        self.operation_name = operation_name
        self.manifest = manifest
        self._core = None
        self._start_time = None
    
    def __enter__(self):
        from .core import AgentIntent
        self._core = AgentIntent(
            api_key=self.api_key,
            manifest=self.manifest
        )
        self._start_time = time.perf_counter()
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        duration = (time.perf_counter() - self._start_time) * 1000
        
        self._core.log_action(
            action_type="tracked_operation",
            metadata={
                "operation": self.operation_name,
                "duration_ms": duration,
                "success": exc_type is None,
                "error": str(exc_val)[:500] if exc_val else None,
            },
            error=exc_type is not None
        )
        
        self._core.close()
        return False  # Don't suppress exceptions


def _wrap_callable(func: Callable, api_key: str, manifest: IntentManifest = None) -> Callable:
    """Wrap a callable with monitoring."""
    from .core import AgentIntent
    
    ai = AgentIntent(api_key=api_key, manifest=manifest)
    
    @wraps(func)
    def wrapper(*args, **kwargs):
        action = Action(
            type=ActionType.UNKNOWN,
            metadata={
                "function": func.__name__,
                "module": getattr(func, "__module__", "unknown"),
            }
        )
        
        start = time.perf_counter()
        try:
            result = func(*args, **kwargs)
            action.duration_ms = (time.perf_counter() - start) * 1000
            action.metadata["success"] = True
            ai._client.log_action(action.to_dict())
            return result
        except Exception as e:
            action.duration_ms = (time.perf_counter() - start) * 1000
            action.metadata["success"] = False
            action.metadata["error"] = str(e)[:500]
            ai._client.log_action(action.to_dict(), error=True)
            raise
    
    # Attach ai instance for cleanup
    wrapper._agentintent = ai
    
    return wrapper


def _is_langchain_agent(obj) -> bool:
    """Check if object is a LangChain agent."""
    # Check for AgentExecutor
    if hasattr(obj, 'invoke') and hasattr(obj, 'callbacks'):
        return True
    # Check class name
    class_name = obj.__class__.__name__
    if 'Agent' in class_name or 'Executor' in class_name:
        module = getattr(obj.__class__, '__module__', '')
        if 'langchain' in module:
            return True
    return False


def _is_crewai_agent(obj) -> bool:
    """Check if object is a CrewAI agent."""
    class_name = obj.__class__.__name__
    module = getattr(obj.__class__, '__module__', '')
    return 'crewai' in module.lower()


def _is_autogen_agent(obj) -> bool:
    """Check if object is an AutoGen agent."""
    if hasattr(obj, 'receive') and hasattr(obj, 'generate_reply'):
        module = getattr(obj.__class__, '__module__', '')
        if 'autogen' in module.lower():
            return True
    return False


def _wrap_langchain(agent, api_key: str, manifest: IntentManifest = None):
    """Wrap a LangChain agent."""
    from .core import AgentIntent
    
    ai = AgentIntent(api_key=api_key, manifest=manifest)
    callback = ai.langchain_callback()
    
    # Add our callback to existing callbacks
    if hasattr(agent, 'callbacks'):
        if agent.callbacks is None:
            agent.callbacks = []
        agent.callbacks.append(callback)
    
    # Attach for cleanup
    agent._agentintent = ai
    
    return agent


def _wrap_crewai(agent, api_key: str, manifest: IntentManifest = None):
    """Wrap a CrewAI agent."""
    # TODO: Implement CrewAI wrapper
    raise NotImplementedError("CrewAI wrapper coming soon")


def _wrap_autogen(agent, api_key: str, manifest: IntentManifest = None):
    """Wrap an AutoGen agent."""
    # TODO: Implement AutoGen wrapper
    raise NotImplementedError("AutoGen wrapper coming soon")
