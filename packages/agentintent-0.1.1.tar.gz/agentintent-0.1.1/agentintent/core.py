"""
AgentIntent Core - Main entry point for the SDK.

This is the primary interface developers interact with.
"""

import uuid
import time
import logging
from typing import Optional, Dict, Any, Callable

from .manifest import IntentManifest
from .actions import Action, ActionType, ActionResult
from .enforcer import LocalEnforcer, EnforcementError
from .client import CloudClient, CloudConfig, MockCloudClient


logger = logging.getLogger("agentintent")


class AgentIntent:
    """
    Main AgentIntent SDK class.
    
    Usage:
        from agentintent import AgentIntent, IntentManifest
        
        # Create manifest
        manifest = IntentManifest(
            name="MyAgent",
            allowed_tools=["search", "calculator"],
            forbidden_tools=["code_execute"]
        )
        
        # Initialize AgentIntent
        ai = AgentIntent(api_key="ai_xxx", manifest=manifest)
        
        # Get LangChain callback
        callback = ai.langchain_callback()
        
        # Or wrap any function
        @ai.monitor
        def my_function():
            pass
    """
    
    def __init__(
        self,
        api_key: str,
        manifest: IntentManifest = None,
        enforcement_mode: str = None,  # Override manifest setting
        cloud_enabled: bool = True,
        base_url: str = "https://api.agentintent.ai/v1",
    ):
        """
        Initialize AgentIntent.
        
        Args:
            api_key: Your AgentIntent API key
            manifest: Intent manifest (optional, will use permissive default)
            enforcement_mode: Override enforcement mode ("block", "warn", "log")
            cloud_enabled: Whether to send logs to cloud
            base_url: API base URL (for testing)
        """
        self.api_key = api_key
        self.manifest = manifest or IntentManifest.default()
        
        # Override enforcement mode if specified
        if enforcement_mode:
            self.manifest.enforcement_mode = enforcement_mode
        
        # Initialize enforcer
        self._enforcer = LocalEnforcer(self.manifest)
        
        # Initialize cloud client
        if cloud_enabled:
            config = CloudConfig(api_key=api_key, base_url=base_url)
            self._client = CloudClient(config)
        else:
            self._client = MockCloudClient()
        
        # Session tracking
        self._session_id = self._generate_session_id()
        self._agent_id = None
        
        # Set session on client
        self._client.set_session(self._session_id, self._agent_id)
        
        # Metrics
        self._metrics = {
            "actions_total": 0,
            "actions_allowed": 0,
            "actions_blocked": 0,
            "actions_warned": 0,
        }
    
    def check(self, action: Action) -> ActionResult:
        """
        Check if an action is allowed.
        
        This is the core enforcement method. Called internally by wrappers.
        """
        result = self._enforcer.check(action)
        
        # Update metrics
        self._metrics["actions_total"] += 1
        if result.allowed:
            self._metrics["actions_allowed"] += 1
        else:
            if self._enforcer.should_block():
                self._metrics["actions_blocked"] += 1
            else:
                self._metrics["actions_warned"] += 1
        
        # Log to cloud
        self._client.log_action(
            action.to_dict(),
            blocked=result.blocked,
            reason=result.reason
        )
        
        return result
    
    def check_tool(self, tool_name: str) -> ActionResult:
        """Check if a tool is allowed."""
        action = Action(
            type=ActionType.TOOL_CALL,
            metadata={"tool_name": tool_name}
        )
        return self.check(action)
    
    def check_api(self, url: str) -> ActionResult:
        """Check if an API call is allowed."""
        action = Action(
            type=ActionType.API_REQUEST,
            metadata={"url": url}
        )
        return self.check(action)
    
    def log_action(
        self,
        action_type: str,
        metadata: Dict[str, Any] = None,
        duration_ms: float = None,
        error: bool = False
    ):
        """
        Manually log an action.
        
        Use this for custom integrations.
        """
        try:
            atype = ActionType(action_type)
        except ValueError:
            atype = ActionType.UNKNOWN
        
        action = Action(
            type=atype,
            metadata=metadata or {},
            duration_ms=duration_ms
        )
        
        self._client.log_action(action.to_dict(), error=error)
        self._metrics["actions_total"] += 1
    
    def monitor(self, func: Callable) -> Callable:
        """
        Decorator to monitor a function.
        
        Usage:
            @ai.monitor
            def my_agent_function(input):
                return result
        """
        from functools import wraps
        
        @wraps(func)
        def wrapper(*args, **kwargs):
            action = Action(
                type=self._infer_action_type(func),
                metadata={
                    "function": func.__name__,
                    "module": getattr(func, "__module__", "unknown"),
                }
            )
            
            # Check enforcement
            result = self.check(action)
            
            if result.blocked and self._enforcer.should_block():
                raise EnforcementError(
                    f"Action blocked: {result.reason}",
                    action=action,
                    result=result
                )
            
            # Execute function
            start = time.perf_counter()
            try:
                output = func(*args, **kwargs)
                action.duration_ms = (time.perf_counter() - start) * 1000
                action.metadata["success"] = True
                self._client.log_action(action.to_dict())
                return output
            except Exception as e:
                action.duration_ms = (time.perf_counter() - start) * 1000
                action.metadata["success"] = False
                action.metadata["error"] = str(e)[:500]
                self._client.log_action(action.to_dict(), error=True)
                raise
        
        return wrapper
    
    def langchain_callback(self):
        """
        Get a LangChain callback handler.
        
        Usage:
            from langchain.agents import AgentExecutor
            
            callback = ai.langchain_callback()
            agent = AgentExecutor(..., callbacks=[callback])
        """
        from .integrations.langchain import AgentIntentCallbackHandler
        return AgentIntentCallbackHandler(
            core=self,
            enforcer=self._enforcer,
            client=self._client,
            session_id=self._session_id
        )
    
    def crewai_wrapper(self):
        """
        Get a CrewAI wrapper.
        
        Usage:
            wrapper = ai.crewai_wrapper()
            monitored_agent = wrapper.wrap(my_agent)
        """
        from .integrations.crewai import AgentIntentCrewAI
        return AgentIntentCrewAI(
            core=self,
            enforcer=self._enforcer,
            client=self._client,
            session_id=self._session_id
        )
    
    def get_trust_score(self, agent_id: str = None) -> Optional[Dict]:
        """Get trust score for this agent (or another agent)."""
        target_id = agent_id or self._agent_id
        if not target_id:
            logger.warning("No agent ID set, cannot get trust score")
            return None
        return self._client.get_trust_score(target_id)
    
    def register_agent(self) -> Optional[str]:
        """Register this agent with AgentIntent."""
        agent_id = self._client.register_agent(self.manifest.to_dict())
        if agent_id:
            self._agent_id = agent_id
            self._client.set_session(self._session_id, agent_id)
        return agent_id
    
    def get_metrics(self) -> Dict[str, Any]:
        """Get current metrics."""
        return {
            **self._metrics,
            "session_id": self._session_id,
            "agent_id": self._agent_id,
            "client_metrics": self._client.get_metrics(),
        }
    
    def flush(self):
        """Force flush all pending logs to cloud."""
        self._client.flush()
    
    def close(self):
        """Shutdown the SDK."""
        self.flush()
        self._client.close()
    
    def _infer_action_type(self, func: Callable) -> ActionType:
        """Infer action type from function name."""
        name = func.__name__.lower()
        
        if any(x in name for x in ["llm", "complete", "generate", "chat", "invoke"]):
            return ActionType.LLM_REQUEST
        if any(x in name for x in ["search", "query", "retrieve", "fetch"]):
            return ActionType.DATA_READ
        if any(x in name for x in ["tool", "call", "execute", "run"]):
            return ActionType.TOOL_CALL
        if any(x in name for x in ["api", "request", "post", "get"]):
            return ActionType.API_REQUEST
        
        return ActionType.UNKNOWN
    
    def _generate_session_id(self) -> str:
        """Generate unique session ID."""
        return f"sess_{uuid.uuid4().hex[:12]}"
    
    def __enter__(self):
        """Context manager entry."""
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit."""
        self.close()
        return False
