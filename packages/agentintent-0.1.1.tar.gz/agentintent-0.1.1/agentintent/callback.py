"""
Simple callback wrapper for AgentIntent.

This provides the simplest possible integration:
    from agentintent import AgentIntentCallback
    agent = AgentExecutor(..., callbacks=[AgentIntentCallback("ai_xxx")])
"""

from .integrations.langchain import AgentIntentCallbackHandler


class AgentIntentCallback(AgentIntentCallbackHandler):
    """
    Simple callback for quick LangChain integration.
    
    Usage:
        from agentintent import AgentIntentCallback
        
        agent = AgentExecutor(
            agent=my_agent,
            tools=my_tools,
            callbacks=[AgentIntentCallback("ai_xxx")]
        )
    
    With manifest:
        from agentintent import AgentIntentCallback, IntentManifest
        
        manifest = IntentManifest(
            name="MyAgent",
            forbidden_tools=["dangerous_tool"]
        )
        
        agent = AgentExecutor(
            agent=my_agent,
            tools=my_tools,
            callbacks=[AgentIntentCallback("ai_xxx", manifest=manifest)]
        )
    """
    
    def __init__(self, api_key: str, manifest=None, block_on_violation: bool = True):
        """
        Initialize simple callback.
        
        Args:
            api_key: Your AgentIntent API key
            manifest: Optional IntentManifest
            block_on_violation: Whether to raise exception on violations
        """
        super().__init__(
            api_key=api_key,
            manifest=manifest,
            block_on_violation=block_on_violation
        )
