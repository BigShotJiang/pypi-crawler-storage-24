"""
Intent Manifest - Declares what an agent is supposed to do.

The manifest is the source of truth for agent behavior validation.
"""

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Any, Set
import yaml
import json
import re


@dataclass
class IntentManifest:
    """
    Defines the declared intent of an AI agent.
    
    This is what the agent SHOULD do. We compare actual behavior against this.
    
    Usage:
        manifest = IntentManifest(
            name="ExpenseBot",
            description="Processes expense reports",
            allowed_tools=["email_read", "ocr", "form_submit"],
            forbidden_tools=["code_execute", "file_delete"],
            allowed_actions=["read_receipts", "create_reports"],
            forbidden_actions=["access_payroll", "modify_permissions"],
        )
    """
    
    # Identity
    name: str
    version: str = "1.0.0"
    description: str = ""
    
    # Developer info
    developer_name: Optional[str] = None
    developer_email: Optional[str] = None
    
    # Tool permissions
    allowed_tools: List[str] = field(default_factory=list)
    forbidden_tools: List[str] = field(default_factory=list)
    
    # Action permissions
    allowed_actions: List[str] = field(default_factory=list)
    forbidden_actions: List[str] = field(default_factory=list)
    
    # API permissions (patterns)
    allowed_api_patterns: List[str] = field(default_factory=list)
    forbidden_api_patterns: List[str] = field(default_factory=list)
    
    # Data permissions
    allowed_data_sources: List[str] = field(default_factory=list)
    forbidden_data_sources: List[str] = field(default_factory=list)
    
    # Rate limits
    limits: Dict[str, Any] = field(default_factory=lambda: {
        "max_llm_calls_per_minute": 60,
        "max_tool_calls_per_minute": 120,
        "max_api_calls_per_minute": 300,
        "max_data_rows_per_query": 10000,
    })
    
    # Behavioral expectations
    expected_behavior: Dict[str, Any] = field(default_factory=dict)
    
    # Enforcement settings
    enforcement_mode: str = "warn"  # "block", "warn", "log"
    
    def __post_init__(self):
        """Compile patterns for fast matching."""
        self._compiled_forbidden_tools: Set[str] = set(
            t.lower() for t in self.forbidden_tools
        )
        self._compiled_allowed_tools: Set[str] = set(
            t.lower() for t in self.allowed_tools
        )
        self._compiled_forbidden_api_patterns = [
            re.compile(p) for p in self.forbidden_api_patterns
        ]
        self._compiled_allowed_api_patterns = [
            re.compile(p) for p in self.allowed_api_patterns
        ]
    
    def is_tool_allowed(self, tool_name: str) -> tuple[bool, Optional[str]]:
        """
        Check if a tool is allowed.
        
        Returns: (is_allowed, reason)
        """
        tool_lower = tool_name.lower()
        
        # Check forbidden first (explicit deny takes precedence)
        if tool_lower in self._compiled_forbidden_tools:
            return False, f"Tool '{tool_name}' is explicitly forbidden"
        
        # If we have an allowed list, tool must be in it
        if self._compiled_allowed_tools:
            if tool_lower not in self._compiled_allowed_tools:
                return False, f"Tool '{tool_name}' is not in allowed list"
        
        return True, None
    
    def is_api_allowed(self, url: str) -> tuple[bool, Optional[str]]:
        """
        Check if an API call is allowed.
        
        Returns: (is_allowed, reason)
        """
        # Check forbidden patterns first
        for pattern in self._compiled_forbidden_api_patterns:
            if pattern.search(url):
                return False, f"API '{url}' matches forbidden pattern"
        
        # If we have allowed patterns, URL must match one
        if self._compiled_allowed_api_patterns:
            for pattern in self._compiled_allowed_api_patterns:
                if pattern.search(url):
                    return True, None
            return False, f"API '{url}' does not match any allowed pattern"
        
        return True, None
    
    def is_data_source_allowed(self, source: str) -> tuple[bool, Optional[str]]:
        """
        Check if a data source is allowed.
        
        Returns: (is_allowed, reason)
        """
        source_lower = source.lower()
        
        # Check forbidden
        for forbidden in self.forbidden_data_sources:
            if forbidden.lower() in source_lower:
                return False, f"Data source '{source}' is forbidden"
        
        # If we have allowed list, must match
        if self.allowed_data_sources:
            for allowed in self.allowed_data_sources:
                if allowed.lower() in source_lower:
                    return True, None
            return False, f"Data source '{source}' is not allowed"
        
        return True, None
    
    def check_rate_limit(self, action_type: str, current_count: int) -> tuple[bool, Optional[str]]:
        """
        Check if rate limit is exceeded.
        
        Returns: (is_within_limit, reason)
        """
        limit_key = f"max_{action_type}_per_minute"
        limit = self.limits.get(limit_key)
        
        if limit and current_count > limit:
            return False, f"Rate limit exceeded: {current_count}/{limit} {action_type} per minute"
        
        return True, None
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert manifest to dictionary."""
        return {
            "name": self.name,
            "version": self.version,
            "description": self.description,
            "developer_name": self.developer_name,
            "developer_email": self.developer_email,
            "allowed_tools": self.allowed_tools,
            "forbidden_tools": self.forbidden_tools,
            "allowed_actions": self.allowed_actions,
            "forbidden_actions": self.forbidden_actions,
            "allowed_api_patterns": self.allowed_api_patterns,
            "forbidden_api_patterns": self.forbidden_api_patterns,
            "allowed_data_sources": self.allowed_data_sources,
            "forbidden_data_sources": self.forbidden_data_sources,
            "limits": self.limits,
            "expected_behavior": self.expected_behavior,
            "enforcement_mode": self.enforcement_mode,
        }
    
    def to_yaml(self) -> str:
        """Convert manifest to YAML string."""
        return yaml.dump(self.to_dict(), default_flow_style=False)
    
    def to_json(self) -> str:
        """Convert manifest to JSON string."""
        return json.dumps(self.to_dict(), indent=2)
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "IntentManifest":
        """Create manifest from dictionary."""
        return cls(**data)
    
    @classmethod
    def from_yaml(cls, yaml_str: str) -> "IntentManifest":
        """Create manifest from YAML string."""
        data = yaml.safe_load(yaml_str)
        return cls.from_dict(data)
    
    @classmethod
    def from_json(cls, json_str: str) -> "IntentManifest":
        """Create manifest from JSON string."""
        data = json.loads(json_str)
        return cls.from_dict(data)
    
    @classmethod
    def from_file(cls, path: str) -> "IntentManifest":
        """Load manifest from file (YAML or JSON)."""
        with open(path, 'r') as f:
            content = f.read()
        
        if path.endswith('.yaml') or path.endswith('.yml'):
            return cls.from_yaml(content)
        elif path.endswith('.json'):
            return cls.from_json(content)
        else:
            # Try YAML first, then JSON
            try:
                return cls.from_yaml(content)
            except:
                return cls.from_json(content)
    
    @classmethod
    def default(cls, name: str = "DefaultAgent") -> "IntentManifest":
        """Create a permissive default manifest."""
        return cls(
            name=name,
            description="Default permissive manifest",
            enforcement_mode="log",  # Log only, don't block
        )


# Convenience function for quick manifest creation
def create_manifest(
    name: str,
    allowed_tools: List[str] = None,
    forbidden_tools: List[str] = None,
    **kwargs
) -> IntentManifest:
    """
    Quick way to create a manifest.
    
    Usage:
        manifest = create_manifest(
            "MyAgent",
            allowed_tools=["search", "calculator"],
            forbidden_tools=["code_execute"]
        )
    """
    return IntentManifest(
        name=name,
        allowed_tools=allowed_tools or [],
        forbidden_tools=forbidden_tools or [],
        **kwargs
    )
