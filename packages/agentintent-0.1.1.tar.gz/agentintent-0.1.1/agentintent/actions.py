"""
Action types and definitions for AgentIntent.
"""

from enum import Enum
from dataclasses import dataclass, field
from typing import Dict, Any, Optional
import time
import uuid


class ActionType(Enum):
    """Types of actions an agent can perform."""
    
    # LLM Operations
    LLM_REQUEST = "llm_request"
    LLM_RESPONSE = "llm_response"
    
    # Tool Operations
    TOOL_CALL = "tool_call"
    TOOL_RESULT = "tool_result"
    
    # Data Operations
    DATA_READ = "data_read"
    DATA_WRITE = "data_write"
    
    # API Operations
    API_REQUEST = "api_request"
    API_RESPONSE = "api_response"
    
    # Agent Operations
    AGENT_START = "agent_start"
    AGENT_DECISION = "agent_decision"
    AGENT_FINISH = "agent_finish"
    AGENT_ERROR = "agent_error"
    
    # Chain/Workflow Operations
    CHAIN_START = "chain_start"
    CHAIN_END = "chain_end"
    
    # Retrieval Operations
    RETRIEVAL_START = "retrieval_start"
    RETRIEVAL_END = "retrieval_end"
    
    # Code Execution
    CODE_EXECUTION = "code_execution"
    
    # Multi-agent
    AGENT_DELEGATION = "agent_delegation"
    MESSAGE_SEND = "message_send"
    MESSAGE_RECEIVE = "message_receive"
    
    # Generic
    UNKNOWN = "unknown"


@dataclass
class Action:
    """Represents a single action performed by an agent."""
    
    type: ActionType
    id: str = field(default_factory=lambda: f"act_{uuid.uuid4().hex[:12]}")
    timestamp: float = field(default_factory=time.time)
    duration_ms: Optional[float] = None
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    # Intent alignment
    intent_aligned: Optional[bool] = None
    intent_category: Optional[str] = None
    
    # Enforcement
    blocked: bool = False
    block_reason: Optional[str] = None
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert action to dictionary for serialization."""
        return {
            "id": self.id,
            "type": self.type.value,
            "timestamp": self.timestamp,
            "duration_ms": self.duration_ms,
            "metadata": self.metadata,
            "intent_aligned": self.intent_aligned,
            "intent_category": self.intent_category,
            "blocked": self.blocked,
            "block_reason": self.block_reason,
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "Action":
        """Create action from dictionary."""
        return cls(
            id=data.get("id", f"act_{uuid.uuid4().hex[:12]}"),
            type=ActionType(data.get("type", "unknown")),
            timestamp=data.get("timestamp", time.time()),
            duration_ms=data.get("duration_ms"),
            metadata=data.get("metadata", {}),
            intent_aligned=data.get("intent_aligned"),
            intent_category=data.get("intent_category"),
            blocked=data.get("blocked", False),
            block_reason=data.get("block_reason"),
        )


@dataclass
class ActionResult:
    """Result of an action check."""
    
    allowed: bool
    reason: Optional[str] = None
    warnings: list = field(default_factory=list)
    
    @property
    def blocked(self) -> bool:
        return not self.allowed
