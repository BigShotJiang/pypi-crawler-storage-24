"""
Tests for AgentIntent SDK.
"""

import pytest
import time
import sys
import os

# Add parent directory to path for imports
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from agentintent import AgentIntent, IntentManifest, Action, ActionType
from agentintent.enforcer import LocalEnforcer, EnforcementError
from agentintent.client import MockCloudClient, CloudConfig


class TestIntentManifest:
    """Tests for IntentManifest."""
    
    def test_create_basic_manifest(self):
        """Test creating a basic manifest."""
        manifest = IntentManifest(
            name="TestAgent",
            description="A test agent"
        )
        assert manifest.name == "TestAgent"
        assert manifest.description == "A test agent"
    
    def test_tool_permissions(self):
        """Test tool permission checking."""
        manifest = IntentManifest(
            name="TestAgent",
            allowed_tools=["search", "calculator"],
            forbidden_tools=["code_execute", "file_delete"]
        )
        
        # Allowed tools
        allowed, reason = manifest.is_tool_allowed("search")
        assert allowed is True
        assert reason is None
        
        allowed, reason = manifest.is_tool_allowed("calculator")
        assert allowed is True
        
        # Forbidden tools
        allowed, reason = manifest.is_tool_allowed("code_execute")
        assert allowed is False
        assert "forbidden" in reason.lower()
        
        # Not in allowed list
        allowed, reason = manifest.is_tool_allowed("unknown_tool")
        assert allowed is False
        assert "not in allowed" in reason.lower()
    
    def test_tool_permissions_case_insensitive(self):
        """Test that tool checking is case insensitive."""
        manifest = IntentManifest(
            name="TestAgent",
            forbidden_tools=["DangerousTool"]
        )
        
        allowed, _ = manifest.is_tool_allowed("dangeroustool")
        assert allowed is False
        
        allowed, _ = manifest.is_tool_allowed("DANGEROUSTOOL")
        assert allowed is False
    
    def test_api_patterns(self):
        """Test API pattern matching."""
        manifest = IntentManifest(
            name="TestAgent",
            allowed_api_patterns=[r"api\.safe\.com/.*"],
            forbidden_api_patterns=[r".*\.dangerous\.com/.*"]
        )
        
        # Allowed
        allowed, _ = manifest.is_api_allowed("https://api.safe.com/v1/users")
        assert allowed is True
        
        # Forbidden
        allowed, reason = manifest.is_api_allowed("https://api.dangerous.com/hack")
        assert allowed is False
    
    def test_manifest_to_yaml(self):
        """Test manifest YAML serialization."""
        manifest = IntentManifest(
            name="TestAgent",
            allowed_tools=["search"],
            forbidden_tools=["delete"]
        )
        
        yaml_str = manifest.to_yaml()
        assert "TestAgent" in yaml_str
        assert "search" in yaml_str
        assert "delete" in yaml_str
    
    def test_manifest_from_yaml(self):
        """Test manifest YAML deserialization."""
        yaml_str = """
name: YamlAgent
version: "2.0.0"
allowed_tools:
  - tool1
  - tool2
forbidden_tools:
  - bad_tool
"""
        manifest = IntentManifest.from_yaml(yaml_str)
        assert manifest.name == "YamlAgent"
        assert manifest.version == "2.0.0"
        assert "tool1" in manifest.allowed_tools
        assert "bad_tool" in manifest.forbidden_tools
    
    def test_default_manifest(self):
        """Test default permissive manifest."""
        manifest = IntentManifest.default("DefaultAgent")
        assert manifest.name == "DefaultAgent"
        assert manifest.enforcement_mode == "log"


class TestLocalEnforcer:
    """Tests for LocalEnforcer."""
    
    def test_check_allowed_tool(self):
        """Test checking allowed tools."""
        manifest = IntentManifest(
            name="TestAgent",
            allowed_tools=["search", "calculator"]
        )
        enforcer = LocalEnforcer(manifest)
        
        result = enforcer.check_tool("search")
        assert result.allowed is True
    
    def test_check_forbidden_tool(self):
        """Test checking forbidden tools."""
        manifest = IntentManifest(
            name="TestAgent",
            forbidden_tools=["dangerous"]
        )
        enforcer = LocalEnforcer(manifest)
        
        result = enforcer.check_tool("dangerous")
        assert result.allowed is False
        assert result.blocked is True
        assert "forbidden" in result.reason.lower()
    
    def test_rate_limiting(self):
        """Test rate limiting."""
        manifest = IntentManifest(
            name="TestAgent",
            limits={"max_llm_calls_per_minute": 5}
        )
        enforcer = LocalEnforcer(manifest)
        
        # Should allow first 5
        for i in range(5):
            result = enforcer.check_llm_call()
            assert result.allowed is True
        
        # Should block 6th
        result = enforcer.check_llm_call()
        assert result.allowed is False
        assert "rate limit" in result.reason.lower()
    
    def test_enforcement_mode_block(self):
        """Test block enforcement mode."""
        manifest = IntentManifest(
            name="TestAgent",
            enforcement_mode="block"
        )
        enforcer = LocalEnforcer(manifest)
        
        assert enforcer.should_block() is True
        assert enforcer.should_warn() is True
    
    def test_enforcement_mode_warn(self):
        """Test warn enforcement mode."""
        manifest = IntentManifest(
            name="TestAgent",
            enforcement_mode="warn"
        )
        enforcer = LocalEnforcer(manifest)
        
        assert enforcer.should_block() is False
        assert enforcer.should_warn() is True
    
    def test_enforcement_mode_log(self):
        """Test log-only enforcement mode."""
        manifest = IntentManifest(
            name="TestAgent",
            enforcement_mode="log"
        )
        enforcer = LocalEnforcer(manifest)
        
        assert enforcer.should_block() is False
        assert enforcer.should_warn() is False


class TestAction:
    """Tests for Action dataclass."""
    
    def test_create_action(self):
        """Test creating an action."""
        action = Action(
            type=ActionType.TOOL_CALL,
            metadata={"tool_name": "search"}
        )
        
        assert action.type == ActionType.TOOL_CALL
        assert action.metadata["tool_name"] == "search"
        assert action.id.startswith("act_")
    
    def test_action_to_dict(self):
        """Test action serialization."""
        action = Action(
            type=ActionType.LLM_REQUEST,
            metadata={"model": "gpt-4"},
            duration_ms=100.5
        )
        
        data = action.to_dict()
        assert data["type"] == "llm_request"
        assert data["metadata"]["model"] == "gpt-4"
        assert data["duration_ms"] == 100.5
    
    def test_action_from_dict(self):
        """Test action deserialization."""
        data = {
            "id": "act_test123",
            "type": "tool_call",
            "metadata": {"tool_name": "calc"},
            "blocked": True,
            "block_reason": "Forbidden"
        }
        
        action = Action.from_dict(data)
        assert action.id == "act_test123"
        assert action.type == ActionType.TOOL_CALL
        assert action.blocked is True


class TestMockCloudClient:
    """Tests for MockCloudClient."""
    
    def test_log_action(self):
        """Test logging actions to mock client."""
        client = MockCloudClient()
        client.set_session("sess_test", "agent_test")
        
        client.log_action({"type": "test", "data": "value"})
        client.flush()
        
        logs = client.get_sent_logs()
        assert len(logs) == 1
        assert logs[0]["action"]["type"] == "test"
    
    def test_log_blocked_action(self):
        """Test logging blocked actions."""
        client = MockCloudClient()
        client.set_session("sess_test", "agent_test")
        
        client.log_action(
            {"type": "blocked_action"},
            blocked=True,
            reason="Tool forbidden"
        )
        client.flush()
        
        logs = client.get_sent_logs()
        assert logs[0]["blocked"] is True
        assert logs[0]["reason"] == "Tool forbidden"


class TestAgentIntent:
    """Tests for main AgentIntent class."""
    
    def test_create_with_default_manifest(self):
        """Test creating AgentIntent with default manifest."""
        ai = AgentIntent(
            api_key="test_key",
            cloud_enabled=False
        )
        
        assert ai.manifest is not None
        assert ai._session_id.startswith("sess_")
        ai.close()
    
    def test_create_with_manifest(self):
        """Test creating AgentIntent with custom manifest."""
        manifest = IntentManifest(
            name="CustomAgent",
            forbidden_tools=["dangerous"]
        )
        
        ai = AgentIntent(
            api_key="test_key",
            manifest=manifest,
            cloud_enabled=False
        )
        
        assert ai.manifest.name == "CustomAgent"
        ai.close()
    
    def test_check_tool(self):
        """Test checking tools through AgentIntent."""
        manifest = IntentManifest(
            name="TestAgent",
            forbidden_tools=["dangerous"]
        )
        
        ai = AgentIntent(
            api_key="test_key",
            manifest=manifest,
            cloud_enabled=False
        )
        
        result = ai.check_tool("safe_tool")
        assert result.allowed is True
        
        result = ai.check_tool("dangerous")
        assert result.blocked is True
        
        ai.close()
    
    def test_monitor_decorator(self):
        """Test the monitor decorator."""
        ai = AgentIntent(
            api_key="test_key",
            cloud_enabled=False
        )
        
        @ai.monitor
        def my_function(x):
            return x * 2
        
        result = my_function(5)
        assert result == 10
        
        # Check metrics
        metrics = ai.get_metrics()
        assert metrics["actions_total"] >= 1
        
        ai.close()
    
    def test_context_manager(self):
        """Test using AgentIntent as context manager."""
        with AgentIntent(api_key="test_key", cloud_enabled=False) as ai:
            result = ai.check_tool("any_tool")
            assert result.allowed is True


class TestIntegration:
    """Integration tests (without actual LangChain)."""
    
    def test_full_workflow(self):
        """Test a full monitoring workflow."""
        # Create manifest
        manifest = IntentManifest(
            name="IntegrationTestAgent",
            allowed_tools=["search", "calculator"],
            forbidden_tools=["file_delete"],
            enforcement_mode="warn"
        )
        
        # Initialize
        ai = AgentIntent(
            api_key="test_key",
            manifest=manifest,
            cloud_enabled=False
        )
        
        # Simulate agent actions
        
        # 1. Allowed tool
        result = ai.check_tool("search")
        assert result.allowed is True
        
        # 2. Another allowed tool
        result = ai.check_tool("calculator")
        assert result.allowed is True
        
        # 3. Forbidden tool
        result = ai.check_tool("file_delete")
        assert result.blocked is True
        
        # 4. Check metrics
        metrics = ai.get_metrics()
        assert metrics["actions_total"] == 3
        assert metrics["actions_allowed"] == 2
        assert metrics["actions_warned"] == 1  # warn mode, not block
        
        ai.close()
    
    def test_enforcement_blocks_on_block_mode(self):
        """Test that block mode actually blocks."""
        manifest = IntentManifest(
            name="BlockingAgent",
            forbidden_tools=["dangerous"],
            enforcement_mode="block"
        )
        
        ai = AgentIntent(
            api_key="test_key",
            manifest=manifest,
            cloud_enabled=False
        )
        
        # Should not raise for allowed tool
        @ai.monitor
        def safe_action():
            return "ok"
        
        result = safe_action()
        assert result == "ok"
        
        ai.close()


class TestPerformance:
    """Performance tests to ensure low overhead."""
    
    def test_enforcement_speed(self):
        """Test that enforcement is fast (<1ms)."""
        manifest = IntentManifest(
            name="SpeedTest",
            allowed_tools=["t1", "t2", "t3"],
            forbidden_tools=["f1", "f2", "f3"],
        )
        enforcer = LocalEnforcer(manifest)
        
        # Warm up
        for _ in range(100):
            enforcer.check_tool("t1")
        
        # Measure
        start = time.perf_counter()
        iterations = 10000
        
        for _ in range(iterations):
            enforcer.check_tool("t1")
        
        elapsed = time.perf_counter() - start
        per_check_ms = (elapsed / iterations) * 1000
        
        # Should be well under 1ms
        assert per_check_ms < 1.0, f"Enforcement took {per_check_ms:.3f}ms per check"
        print(f"\nEnforcement speed: {per_check_ms:.4f}ms per check")


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
