"""Synthetic benchmarks for laxate."""
