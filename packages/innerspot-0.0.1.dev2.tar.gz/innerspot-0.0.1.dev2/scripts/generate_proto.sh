#!/usr/bin/env bash
# Generate Python protobuf code from .proto definitions.
# Run from project root: ./scripts/generate_proto.sh
set -euo pipefail

PROTO_DIR="innerspot/proto/definitions"
OUT_DIR="innerspot/proto/generated"

if [ ! -d "$PROTO_DIR" ]; then
    echo "Error: $PROTO_DIR not found. Run this script from the project root." >&2
    exit 1
fi

if ! command -v protoc &>/dev/null; then
    echo "Error: protoc not found. Install with: apt install protobuf-compiler" >&2
    exit 1
fi

echo "protoc version: $(protoc --version)"

# Find protoc's well-known protos (google/protobuf/any.proto etc.)
WELL_KNOWN=""
for dir in /usr/local/include /usr/include; do
    if [ -f "$dir/google/protobuf/any.proto" ]; then
        WELL_KNOWN="--proto_path=$dir"
        break
    fi
done

if [ -z "$WELL_KNOWN" ]; then
    echo "Error: google/protobuf/any.proto not found. Install protobuf include files." >&2
    exit 1
fi

rm -f "$OUT_DIR"/*_pb2.py

protoc \
    --proto_path="$PROTO_DIR" \
    $WELL_KNOWN \
    --python_out="$OUT_DIR" \
    "$PROTO_DIR"/*.proto

# protoc generates absolute imports (e.g. "import foo_pb2")
# which don't work inside a Python package — convert to relative
sed -i 's/^import \([a-z_]*_pb2\)/from . import \1/' "$OUT_DIR"/*_pb2.py

COUNT=$(ls "$OUT_DIR"/*_pb2.py 2>/dev/null | wc -l)
echo "Generated $COUNT protobuf files in $OUT_DIR/"
ls -1 "$OUT_DIR"/*_pb2.py
