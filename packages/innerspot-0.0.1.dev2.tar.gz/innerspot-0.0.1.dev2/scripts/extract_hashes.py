"""Extract GraphQL hashes, spclient paths, and TOTP secrets from Spotify's web player JS bundle.

Usage (from project root):
    uv run python scripts/extract_hashes.py          # print all extracted data
    uv run python scripts/extract_hashes.py --update  # update source files in-place

Extracts three things from the web player JS bundle:

1. GraphQL persisted query hashes (used by innerspot/providers/partner.py _HASHES):
   Pattern: new X.l("operationName", "query|mutation", "sha256Hash", ...)

2. spclient service paths (used by innerspot/providers/spclient.py _SPCLIENT_PATHS):
   Pattern: `${i}/service-name/vN` where i = SPCLIENT_WG_URL

3. TOTP secrets (used by innerspot/_constants.py TOTP_SECRETS):
   Pattern: inline e4 array with {secret: "...", version: N} entries
"""

import re
import sys
from pathlib import Path

import httpx

_BOT_UA = "Mozilla/5.0 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)"
_TRACK_PAGE = "https://open.spotify.com/track/4cOdK2wGLETKBW3PvgPWqT"
_BUNDLE_PATTERN = re.compile(
    r"(https://open\.spotifycdn\.com/cdn/build/web-player/web-player\.[a-f0-9]+\.js)"
)
_HASH_PATTERN = re.compile(r'new \w+\.l\("(\w+)","(query|mutation)","([a-f0-9]{64})"')
_SPCLIENT_PATH_PATTERN = re.compile(r"\{i\}(/[a-zA-Z0-9._/-]+)")
_TOTP_SECRETS_PATTERN = re.compile(
    r"""\{secret:(?:"([^"]+)"|'([^']+)'),version:(\d+)\}"""
)

_PROVIDERS_DIR = Path("innerspot/providers")
_PARTNER_PY = _PROVIDERS_DIR / "partner.py"
_SPCLIENT_PY = _PROVIDERS_DIR / "spclient.py"
_CONSTANTS_PY = Path("innerspot/_constants.py")


def _fetch_bundle() -> str:
    """Fetch the web player JS bundle and return its contents."""
    http = httpx.Client(follow_redirects=True, timeout=30)
    try:
        page = http.get(_TRACK_PAGE, headers={"User-Agent": _BOT_UA})
        page.raise_for_status()
        match = _BUNDLE_PATTERN.search(page.text)
        if not match:
            raise RuntimeError("Could not find web-player JS bundle URL")
        bundle_url = match.group(1)
        print(f"Bundle: {bundle_url.split('/')[-1]}")
        return http.get(bundle_url).text
    finally:
        http.close()


def extract_graphql_hashes(js: str) -> dict[str, dict[str, str]]:
    """Extract all GraphQL operation name -> {type, hash} from the JS bundle."""
    hashes: dict[str, dict[str, str]] = {}
    for name, type_, hash_ in _HASH_PATTERN.findall(js):
        hashes[name] = {"type": type_, "hash": hash_}
    return hashes


def extract_spclient_paths(js: str) -> dict[str, str]:
    """Extract spclient service paths from the JS bundle.

    Returns a dict mapping service name to its versioned path,
    e.g. {"metadata": "/metadata/4", "color-lyrics": "/color-lyrics/v2"}.
    """
    raw_paths = sorted(set(_SPCLIENT_PATH_PATTERN.findall(js)))
    paths: dict[str, str] = {}
    for path in raw_paths:
        parts = path.strip("/").split("/")
        service = parts[0]
        paths[service] = path
    return paths


def extract_totp_secrets(js: str) -> list[dict]:
    """Extract TOTP secrets from the JS bundle.

    Returns a list of {"secret": str, "version": int} dicts,
    sorted by version descending.
    """
    entries = []
    for double_quoted, single_quoted, version in _TOTP_SECRETS_PATTERN.findall(js):
        secret = double_quoted or single_quoted
        # Unescape JS string (handle \\)
        secret = secret.replace("\\\\", "\\")
        entries.append({"secret": secret, "version": int(version)})
    return sorted(entries, key=lambda e: e["version"], reverse=True)


def _read_dict_from_file(file_path: Path, dict_name: str) -> dict[str, str]:
    """Read a dict constant from a Python source file."""
    source = file_path.read_text()
    pattern = rf"{re.escape(dict_name)} = \{{[^}}]+\}}"
    match = re.search(pattern, source, re.DOTALL)
    if not match:
        return {}
    return dict(re.findall(r'"([^"]+)":\s*"([^"]+)"', match.group(0)))


def _update_dict_in_file(
    file_path: Path,
    dict_name: str,
    new_values: dict[str, str],
) -> bool:
    """Update a dict constant in a Python source file. Returns True if changed."""
    source = file_path.read_text()

    pattern = rf"({re.escape(dict_name)} = \{{[^}}]+\}})"
    match = re.search(pattern, source, re.DOTALL)
    if not match:
        print(
            f"  ERROR: Could not find {dict_name} in {file_path.name}", file=sys.stderr
        )
        return False

    old_block = match.group(1)
    current_keys = re.findall(r'"([^"]+)":', old_block)

    changed = False
    new_lines = [f"{dict_name} = {{"]
    for key in current_keys:
        old_val_match = re.search(rf'"{re.escape(key)}":\s*"([^"]+)"', old_block)
        old_val = old_val_match.group(1) if old_val_match else None

        if key in new_values:
            new_val = new_values[key]
            if old_val != new_val:
                changed = True
                print(f"  UPDATED {key}")
                print(f"    old: {old_val}")
                print(f"    new: {new_val}")
            new_lines.append(f'    "{key}": "{new_val}",')
        else:
            print(
                f"  WARNING: '{key}' not found in bundle, keeping old value",
                file=sys.stderr,
            )
            new_lines.append(f'    "{key}": "{old_val}",')

    new_lines.append("}")
    new_block = "\n".join(new_lines)

    if not changed:
        return False

    source = source.replace(old_block, new_block)
    file_path.write_text(source)
    print(f"  Written to {file_path}")
    return True


def _update_totp_secrets(file_path: Path, new_secrets: list[dict]) -> bool:
    """Update TOTP_SECRETS list in _constants.py. Returns True if changed."""
    source = file_path.read_text()

    pattern = r"(TOTP_SECRETS = \[.*?^\])"
    match = re.search(pattern, source, re.DOTALL | re.MULTILINE)
    if not match:
        print(
            f"  ERROR: Could not find TOTP_SECRETS in {file_path.name}", file=sys.stderr
        )
        return False

    old_block = match.group(1)

    # Build new block
    lines = ["TOTP_SECRETS = ["]
    for entry in new_secrets:
        secret = entry["secret"].replace("\\", "\\\\").replace("'", "\\'")
        lines.append(f'    {{"secret": \'{secret}\', "version": {entry["version"]}}},')
    lines.append("]")
    new_block = "\n".join(lines)

    if old_block.strip() == new_block.strip():
        return False

    # Check what changed
    old_versions = set(re.findall(r'"version":\s*(\d+)', old_block))
    new_versions = {str(e["version"]) for e in new_secrets}
    added = new_versions - old_versions
    removed = old_versions - new_versions

    if added:
        print(f"  NEW versions: {', '.join(sorted(added))}")
    if removed:
        print(f"  REMOVED versions: {', '.join(sorted(removed))}")

    source = source.replace(old_block, new_block)
    file_path.write_text(source)
    print(f"  Written to {file_path}")
    return True


def _print_status(
    file_path: Path, dict_name: str, bundle_values: dict[str, str]
) -> None:
    """Print OK/STALE/MISS status for each key in a dict constant."""
    current = _read_dict_from_file(file_path, dict_name)
    if not current:
        print("  (not found)")
        return
    for key, old_val in current.items():
        new_val = bundle_values.get(key)
        if new_val is None:
            print(f"  MISS  {key}: {old_val} (not in bundle)")
        elif old_val == new_val:
            print(f"  OK    {key}: {old_val}")
        else:
            print(f"  STALE {key}: {old_val} -> {new_val}")


def main() -> None:
    if not _PROVIDERS_DIR.exists():
        print(
            "Error: innerspot/providers not found. Run this script from the project root.",
            file=sys.stderr,
        )
        sys.exit(1)

    update = "--update" in sys.argv

    print("Fetching web player JS bundle...")
    js = _fetch_bundle()

    hashes = extract_graphql_hashes(js)
    paths = extract_spclient_paths(js)
    totp_secrets = extract_totp_secrets(js)
    print(
        f"Found {len(hashes)} GraphQL operations, "
        f"{len(paths)} spclient paths, "
        f"{len(totp_secrets)} TOTP secrets\n"
    )

    if update:
        print("=== partner.py _HASHES ===")
        flat = {k: v["hash"] for k, v in hashes.items()}
        if not _update_dict_in_file(_PARTNER_PY, "_HASHES", flat):
            print("  All hashes up to date.")

        print("\n=== spclient.py _SPCLIENT_PATHS ===")
        if not _update_dict_in_file(_SPCLIENT_PY, "_SPCLIENT_PATHS", paths):
            print("  All paths up to date.")

        print("\n=== _constants.py TOTP_SECRETS ===")
        if totp_secrets:
            if not _update_totp_secrets(_CONSTANTS_PY, totp_secrets):
                print("  All TOTP secrets up to date.")
        else:
            print("  WARNING: No TOTP secrets found in bundle", file=sys.stderr)
    else:
        print("=== GraphQL operations ===")
        for name in sorted(hashes):
            h = hashes[name]
            print(f"  {h['type']:8s} {name}: {h['hash']}")

        print("\n=== spclient service paths ===")
        for service, path in sorted(paths.items()):
            print(f"  {service}: {path}")

        print("\n=== TOTP secrets ===")
        for entry in totp_secrets:
            print(f"  version {entry['version']}: {entry['secret'][:20]}...")

        # Status checks
        flat = {k: v["hash"] for k, v in hashes.items()}
        print("\n--- partner.py _HASHES ---")
        _print_status(_PARTNER_PY, "_HASHES", flat)

        print("\n--- spclient.py _SPCLIENT_PATHS ---")
        _print_status(_SPCLIENT_PY, "_SPCLIENT_PATHS", paths)

        print("\n--- _constants.py TOTP_SECRETS ---")
        if _CONSTANTS_PY.exists():
            source = _CONSTANTS_PY.read_text()
            current_versions = set(re.findall(r'"version":\s*(\d+)', source))
            bundle_versions = {str(e["version"]) for e in totp_secrets}
            for v in sorted(current_versions | bundle_versions, reverse=True):
                if v in current_versions and v in bundle_versions:
                    print(f"  OK    version {v}")
                elif v in current_versions:
                    print(f"  MISS  version {v} (not in bundle)")
                else:
                    print(f"  NEW   version {v} (not in constants)")


if __name__ == "__main__":
    main()
