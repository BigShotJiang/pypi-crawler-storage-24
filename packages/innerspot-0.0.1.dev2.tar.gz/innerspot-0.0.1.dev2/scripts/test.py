from innerspot import SpotifyClient, SpotifyPKCE

auth = SpotifyPKCE()  # opens browser, waits for callback on :5588
client = SpotifyClient(auth=auth)
track = client.get_track("4PTG3Z6ehGkBFwjybzWkR8")
print(track.name)
