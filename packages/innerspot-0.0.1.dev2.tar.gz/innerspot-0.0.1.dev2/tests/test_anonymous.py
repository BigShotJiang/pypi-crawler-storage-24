"""Integration tests using anonymous auth (no sp_dc needed).

All tests in this module are marked with @pytest.mark.anonymous automatically
via conftest.py. They hit Spotify's live API.
"""

from innerspot import SpotifyClient
from innerspot.models import (
    Album,
    AlbumStub,
    Artist,
    ArtistWithAlbums,
    Copyright,
    ExternalIDs,
    ExternalURLs,
    Followers,
    HomeItem,
    HomeSection,
    PaginatedResult,
    Playlist,
    PlaylistOwner,
    PlaylistTrack,
    SearchResults,
    SimplifiedAlbum,
    SimplifiedArtist,
    SpotifyImage,
    Track,
    TrackStub,
    User,
)

from .conftest import (
    ALBUM_ID,
    ALBUM_NAME,
    ARTIST_ID,
    ARTIST_NAME,
    PLAYLIST_ID,
    TRACK_ARTIST,
    TRACK_ID,
    TRACK_NAME,
    USER_ID,
)

# ── Helpers ──


def assert_simplified_artist(artist: SimplifiedArtist):
    """Assert a SimplifiedArtist has valid fields."""
    assert isinstance(artist, SimplifiedArtist)
    assert isinstance(artist.id, str)
    assert len(artist.id) > 0
    assert isinstance(artist.uri, str)
    assert artist.uri.startswith("spotify:artist:")
    assert isinstance(artist.name, str)
    assert len(artist.name) > 0
    assert artist.type == "artist"


def assert_spotify_image(image: SpotifyImage):
    """Assert a SpotifyImage has valid fields."""
    assert isinstance(image, SpotifyImage)
    assert isinstance(image.url, str)
    assert image.url.startswith("http")


def assert_external_urls(urls: ExternalURLs, expected_type: str | None = None):
    """Assert ExternalURLs has valid spotify URL."""
    assert isinstance(urls, ExternalURLs)
    if urls.spotify:
        assert isinstance(urls.spotify, str)
        assert "open.spotify.com" in urls.spotify
        if expected_type:
            assert f"/{expected_type}/" in urls.spotify


def assert_track_stub(track: TrackStub):
    """Assert a TrackStub has minimal valid fields."""
    assert isinstance(track, TrackStub)
    assert isinstance(track.id, str)
    assert len(track.id) > 0
    assert track.type == "track"


# ── Track tests ──


class TestGetTrack:
    def test_returns_track(self, anon_client: SpotifyClient):
        track = anon_client.get_track(TRACK_ID)
        assert isinstance(track, Track)

    def test_track_id(self, anon_client: SpotifyClient):
        track = anon_client.get_track(TRACK_ID)
        assert track.id == TRACK_ID

    def test_track_name(self, anon_client: SpotifyClient):
        track = anon_client.get_track(TRACK_ID)
        assert track.name == TRACK_NAME

    def test_track_uri(self, anon_client: SpotifyClient):
        track = anon_client.get_track(TRACK_ID)
        assert isinstance(track.uri, str)
        assert track.uri == f"spotify:track:{TRACK_ID}"

    def test_track_type(self, anon_client: SpotifyClient):
        track = anon_client.get_track(TRACK_ID)
        assert track.type == "track"

    def test_track_duration(self, anon_client: SpotifyClient):
        track = anon_client.get_track(TRACK_ID)
        assert isinstance(track.duration_ms, int)
        assert track.duration_ms > 0

    def test_track_number(self, anon_client: SpotifyClient):
        track = anon_client.get_track(TRACK_ID)
        assert isinstance(track.track_number, int)
        assert track.track_number >= 1

    def test_track_disc_number(self, anon_client: SpotifyClient):
        track = anon_client.get_track(TRACK_ID)
        assert isinstance(track.disc_number, int)
        assert track.disc_number >= 1

    def test_track_explicit(self, anon_client: SpotifyClient):
        track = anon_client.get_track(TRACK_ID)
        assert isinstance(track.explicit, bool)

    def test_track_artists(self, anon_client: SpotifyClient):
        track = anon_client.get_track(TRACK_ID)
        assert isinstance(track.artists, list)
        assert len(track.artists) >= 1
        assert_simplified_artist(track.artists[0])
        assert track.artists[0].name == TRACK_ARTIST

    def test_track_album(self, anon_client: SpotifyClient):
        track = anon_client.get_track(TRACK_ID)
        assert track.album is not None
        assert isinstance(track.album, (SimplifiedAlbum, Album, AlbumStub))
        assert isinstance(track.album.id, str)
        assert isinstance(track.album.name, str)

    def test_track_album_images(self, anon_client: SpotifyClient):
        track = anon_client.get_track(TRACK_ID)
        if track.album.images:
            assert_spotify_image(track.album.images[0])

    def test_track_external_urls(self, anon_client: SpotifyClient):
        track = anon_client.get_track(TRACK_ID)
        assert_external_urls(track.external_urls, "track")

    def test_track_external_ids(self, anon_client: SpotifyClient):
        track = anon_client.get_track(TRACK_ID)
        assert isinstance(track.external_ids, ExternalIDs)

    def test_track_href(self, anon_client: SpotifyClient):
        track = anon_client.get_track(TRACK_ID)
        if track.href:
            assert "api.spotify.com" in track.href


# ── Album tests ──


class TestGetAlbum:
    def test_returns_album(self, anon_client: SpotifyClient):
        album = anon_client.get_album(ALBUM_ID)
        assert isinstance(album, Album)

    def test_album_id(self, anon_client: SpotifyClient):
        album = anon_client.get_album(ALBUM_ID)
        assert album.id == ALBUM_ID

    def test_album_name(self, anon_client: SpotifyClient):
        album = anon_client.get_album(ALBUM_ID)
        assert album.name == ALBUM_NAME

    def test_album_uri(self, anon_client: SpotifyClient):
        album = anon_client.get_album(ALBUM_ID)
        assert album.uri == f"spotify:album:{ALBUM_ID}"

    def test_album_type_field(self, anon_client: SpotifyClient):
        album = anon_client.get_album(ALBUM_ID)
        assert album.type == "album"

    def test_album_images(self, anon_client: SpotifyClient):
        album = anon_client.get_album(ALBUM_ID)
        assert isinstance(album.images, list)
        assert len(album.images) >= 1
        assert_spotify_image(album.images[0])

    def test_album_artists(self, anon_client: SpotifyClient):
        album = anon_client.get_album(ALBUM_ID)
        assert isinstance(album.artists, list)
        assert len(album.artists) >= 1
        assert_simplified_artist(album.artists[0])

    def test_album_release_date(self, anon_client: SpotifyClient):
        album = anon_client.get_album(ALBUM_ID)
        assert isinstance(album.release_date, str)
        assert len(album.release_date) >= 4  # at least YYYY

    def test_album_tracks(self, anon_client: SpotifyClient):
        album = anon_client.get_album(ALBUM_ID)
        assert isinstance(album.tracks, list)
        assert len(album.tracks) >= 1
        assert_track_stub(album.tracks[0])

    def test_album_total_tracks(self, anon_client: SpotifyClient):
        album = anon_client.get_album(ALBUM_ID)
        assert isinstance(album.total_tracks, int)
        assert album.total_tracks >= 1

    def test_album_copyrights(self, anon_client: SpotifyClient):
        album = anon_client.get_album(ALBUM_ID)
        assert isinstance(album.copyrights, list)
        for c in album.copyrights:
            assert isinstance(c, Copyright)

    def test_album_external_urls(self, anon_client: SpotifyClient):
        album = anon_client.get_album(ALBUM_ID)
        assert_external_urls(album.external_urls, "album")

    def test_album_external_ids(self, anon_client: SpotifyClient):
        album = anon_client.get_album(ALBUM_ID)
        assert isinstance(album.external_ids, ExternalIDs)


# ── Artist tests ──


class TestGetArtist:
    def test_returns_artist(self, anon_client: SpotifyClient):
        artist = anon_client.get_artist(ARTIST_ID)
        assert isinstance(artist, Artist)

    def test_artist_id(self, anon_client: SpotifyClient):
        artist = anon_client.get_artist(ARTIST_ID)
        assert artist.id == ARTIST_ID

    def test_artist_name(self, anon_client: SpotifyClient):
        artist = anon_client.get_artist(ARTIST_ID)
        assert artist.name == ARTIST_NAME

    def test_artist_uri(self, anon_client: SpotifyClient):
        artist = anon_client.get_artist(ARTIST_ID)
        assert artist.uri == f"spotify:artist:{ARTIST_ID}"

    def test_artist_images(self, anon_client: SpotifyClient):
        artist = anon_client.get_artist(ARTIST_ID)
        assert isinstance(artist.images, list)
        if artist.images:
            assert_spotify_image(artist.images[0])

    def test_artist_external_urls(self, anon_client: SpotifyClient):
        artist = anon_client.get_artist(ARTIST_ID)
        assert_external_urls(artist.external_urls, "artist")

    def test_artist_followers(self, anon_client: SpotifyClient):
        artist = anon_client.get_artist(ARTIST_ID)
        assert isinstance(artist.followers, Followers)


class TestGetArtists:
    def test_returns_dict(self, anon_client: SpotifyClient):
        result = anon_client.get_artists([ARTIST_ID])
        assert isinstance(result, dict)

    def test_contains_artist(self, anon_client: SpotifyClient):
        result = anon_client.get_artists([ARTIST_ID])
        assert ARTIST_ID in result
        assert isinstance(result[ARTIST_ID], Artist)
        assert result[ARTIST_ID].name == ARTIST_NAME

    def test_multiple_artists(self, anon_client: SpotifyClient):
        # Ed Sheeran + Rick Astley
        ids = [ARTIST_ID, "6eUKZXaKkcviH0Ku9w2n3V"]
        result = anon_client.get_artists(ids)
        assert len(result) >= 1
        for aid, artist in result.items():
            assert isinstance(aid, str)
            assert isinstance(artist, Artist)


class TestGetArtistDiscography:
    def test_returns_artist_with_albums(self, anon_client: SpotifyClient):
        result = anon_client.get_artist_discography(ARTIST_ID)
        assert isinstance(result, ArtistWithAlbums)

    def test_has_artist_fields(self, anon_client: SpotifyClient):
        result = anon_client.get_artist_discography(ARTIST_ID)
        assert result.name == ARTIST_NAME
        assert result.id == ARTIST_ID

    def test_has_albums(self, anon_client: SpotifyClient):
        result = anon_client.get_artist_discography(ARTIST_ID)
        assert isinstance(result.albums, list)
        assert len(result.albums) >= 1
        for album in result.albums[:3]:
            assert isinstance(album, Album)
            assert isinstance(album.id, str)
            assert isinstance(album.name, str)


# ── Playlist tests ──


class TestGetPlaylist:
    def test_returns_playlist(self, anon_client: SpotifyClient):
        playlist = anon_client.get_playlist(PLAYLIST_ID)
        assert isinstance(playlist, Playlist)

    def test_playlist_id(self, anon_client: SpotifyClient):
        playlist = anon_client.get_playlist(PLAYLIST_ID)
        assert playlist.id == PLAYLIST_ID

    def test_playlist_name(self, anon_client: SpotifyClient):
        playlist = anon_client.get_playlist(PLAYLIST_ID)
        assert isinstance(playlist.name, str)
        assert len(playlist.name) > 0

    def test_playlist_uri(self, anon_client: SpotifyClient):
        playlist = anon_client.get_playlist(PLAYLIST_ID)
        assert isinstance(playlist.uri, str)

    def test_playlist_type(self, anon_client: SpotifyClient):
        playlist = anon_client.get_playlist(PLAYLIST_ID)
        assert playlist.type == "playlist"

    def test_playlist_owner(self, anon_client: SpotifyClient):
        playlist = anon_client.get_playlist(PLAYLIST_ID)
        assert isinstance(playlist.owner, PlaylistOwner)

    def test_playlist_images(self, anon_client: SpotifyClient):
        playlist = anon_client.get_playlist(PLAYLIST_ID)
        assert isinstance(playlist.images, list)
        if playlist.images:
            assert_spotify_image(playlist.images[0])

    def test_playlist_tracks(self, anon_client: SpotifyClient):
        playlist = anon_client.get_playlist(PLAYLIST_ID)
        assert isinstance(playlist.tracks, list)
        assert len(playlist.tracks) >= 1
        for pt in playlist.tracks[:5]:
            assert isinstance(pt, PlaylistTrack)
            if pt.track:
                assert_track_stub(pt.track)


# ── User tests ──


class TestGetUser:
    def test_returns_user(self, anon_client: SpotifyClient):
        user = anon_client.get_user(USER_ID)
        assert isinstance(user, User)

    def test_user_id(self, anon_client: SpotifyClient):
        user = anon_client.get_user(USER_ID)
        assert user.id == USER_ID

    def test_user_display_name(self, anon_client: SpotifyClient):
        user = anon_client.get_user(USER_ID)
        assert isinstance(user.display_name, str)

    def test_user_type(self, anon_client: SpotifyClient):
        user = anon_client.get_user(USER_ID)
        assert user.type == "user"


# ── Search tests ──


class TestSearch:
    def test_returns_search_results(self, anon_client: SpotifyClient):
        results = anon_client.search("Never Gonna Give You Up")
        assert isinstance(results, SearchResults)

    def test_search_has_tracks(self, anon_client: SpotifyClient):
        results = anon_client.search("Never Gonna Give You Up")
        assert isinstance(results.tracks, PaginatedResult)
        assert isinstance(results.tracks.items, list)
        assert len(results.tracks.items) >= 1

    def test_search_has_artists(self, anon_client: SpotifyClient):
        results = anon_client.search("Rick Astley")
        assert isinstance(results.artists, PaginatedResult)

    def test_search_has_albums(self, anon_client: SpotifyClient):
        results = anon_client.search("Whenever You Need Somebody")
        assert isinstance(results.albums, PaginatedResult)

    def test_search_limit(self, anon_client: SpotifyClient):
        results = anon_client.search("pop", limit=5)
        assert isinstance(results, SearchResults)


# ── Pagination tests ──


class TestAlbumPagination:
    def test_album_with_limit(self, anon_client: SpotifyClient):
        album = anon_client.partner.get_album(ALBUM_ID, offset=0, limit=3)
        assert isinstance(album, Album)
        assert len(album.tracks) == 3
        assert album.total_tracks >= 3

    def test_album_offset(self, anon_client: SpotifyClient):
        full = anon_client.partner.get_album(ALBUM_ID, offset=0, limit=300)
        page = anon_client.partner.get_album(ALBUM_ID, offset=2, limit=3)
        assert page.tracks[0].name == full.tracks[2].name


class TestPlaylistPagination:
    def test_playlist_with_limit(self, anon_client: SpotifyClient):
        pl = anon_client.partner.get_playlist(PLAYLIST_ID, offset=0, limit=5)
        assert isinstance(pl, Playlist)
        assert len(pl.tracks) == 5
        assert pl.total_tracks >= 5

    def test_playlist_offset(self, anon_client: SpotifyClient):
        page1 = anon_client.partner.get_playlist(PLAYLIST_ID, offset=0, limit=3)
        page2 = anon_client.partner.get_playlist(PLAYLIST_ID, offset=3, limit=3)
        assert page1.tracks[0].track.name != page2.tracks[0].track.name


# ── Artist top tracks / albums ──


class TestArtistTopTracks:
    def test_returns_list(self, anon_client: SpotifyClient):
        tracks = anon_client.get_artist_top_tracks(ARTIST_ID)
        assert isinstance(tracks, list)
        assert len(tracks) >= 1

    def test_track_fields(self, anon_client: SpotifyClient):
        tracks = anon_client.get_artist_top_tracks(ARTIST_ID)
        for t in tracks[:3]:
            assert isinstance(t, TrackStub)
            assert isinstance(t.id, str)
            assert isinstance(t.name, str)
            assert t.playcount is None or isinstance(t.playcount, int)

    def test_known_track(self, anon_client: SpotifyClient):
        tracks = anon_client.get_artist_top_tracks(ARTIST_ID)
        names = [t.name for t in tracks]
        assert any("Never Gonna Give You Up" in n for n in names)


class TestArtistAlbums:
    def test_returns_list(self, anon_client: SpotifyClient):
        albums = anon_client.get_artist_albums(ARTIST_ID, limit=5)
        assert isinstance(albums, list)
        assert len(albums) >= 1

    def test_album_fields(self, anon_client: SpotifyClient):
        albums = anon_client.get_artist_albums(ARTIST_ID, limit=3)
        for a in albums:
            assert isinstance(a, AlbumStub)
            assert isinstance(a.id, str)
            assert isinstance(a.name, str)
            assert a.album_type in ("album", "single", "compilation", "ep", None)

    def test_pagination(self, anon_client: SpotifyClient):
        page1 = anon_client.get_artist_albums(ARTIST_ID, offset=0, limit=3)
        page2 = anon_client.get_artist_albums(ARTIST_ID, offset=3, limit=3)
        assert len(page1) == 3
        assert len(page2) == 3
        assert page1[0].name != page2[0].name


# ── Home / Browse tests ──


class TestGetHomeSections:
    def test_returns_list(self, anon_client: SpotifyClient):
        sections = anon_client.get_home_sections(limit=5)
        assert isinstance(sections, list)

    def test_section_types(self, anon_client: SpotifyClient):
        sections = anon_client.get_home_sections(limit=5)
        if sections:
            for section in sections[:3]:
                assert isinstance(section, HomeSection)
                assert isinstance(section.items, list)
                if section.items:
                    assert isinstance(section.items[0], HomeItem)


# ── parse_id tests ──


class TestParseId:
    def test_track_uri(self, anon_client: SpotifyClient):
        sid, stype = anon_client.parse_id(f"spotify:track:{TRACK_ID}")
        assert sid == TRACK_ID
        assert stype == "track"

    def test_album_url(self, anon_client: SpotifyClient):
        sid, stype = anon_client.parse_id(f"https://open.spotify.com/album/{ALBUM_ID}")
        assert sid == ALBUM_ID
        assert stype == "album"

    def test_raw_id(self, anon_client: SpotifyClient):
        sid, stype = anon_client.parse_id(TRACK_ID)
        assert sid == TRACK_ID
