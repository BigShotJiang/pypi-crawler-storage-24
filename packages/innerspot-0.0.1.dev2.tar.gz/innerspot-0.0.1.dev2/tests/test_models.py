"""Unit tests for innerspot.models."""

from innerspot.models import (
    Album,
    AlbumStub,
    Artist,
    ArtistWithAlbums,
    ExternalIDs,
    ExternalURLs,
    HomeItem,
    HomeSection,
    Lyrics,
    LyricsLine,
    PaginatedResult,
    Playlist,
    PlaylistOwner,
    PlaylistTrack,
    RadioStation,
    RadioTrack,
    SearchResults,
    SimplifiedAlbum,
    SimplifiedArtist,
    SpotifyImage,
    Track,
    TrackStub,
    User,
)


class TestBaseModelBehavior:
    """Test the dict-like access on _BaseModel."""

    def test_getitem(self):
        img = SpotifyImage(url="https://example.com/img.jpg", height=300, width=300)
        assert img["url"] == "https://example.com/img.jpg"
        assert img["height"] == 300

    def test_contains(self):
        img = SpotifyImage(url="https://example.com/img.jpg", height=300, width=300)
        assert "url" in img
        assert "height" in img

    def test_contains_none_field(self):
        img = SpotifyImage(url="https://example.com/img.jpg")
        assert "height" not in img  # None fields return False

    def test_get(self):
        img = SpotifyImage(url="https://example.com/img.jpg")
        assert img.get("url") == "https://example.com/img.jpg"
        assert img.get("missing", "default") == "default"

    def test_raw_excluded_from_dict(self):
        img = SpotifyImage(url="https://example.com/img.jpg", raw={"extra": "data"})
        dumped = img.model_dump()
        assert "raw" not in dumped


class TestExternalURLs:
    def test_defaults(self):
        urls = ExternalURLs()
        assert urls.spotify is None

    def test_with_value(self):
        urls = ExternalURLs(spotify="https://open.spotify.com/track/123")
        assert urls.spotify == "https://open.spotify.com/track/123"


class TestExternalIDs:
    def test_defaults(self):
        ids = ExternalIDs()
        assert ids.isrc is None
        assert ids.ean is None
        assert ids.upc is None

    def test_with_isrc(self):
        ids = ExternalIDs(isrc="USAT29900609")
        assert ids.isrc == "USAT29900609"


class TestSpotifyImage:
    def test_required_url(self):
        img = SpotifyImage(url="https://i.scdn.co/image/abc")
        assert img.url == "https://i.scdn.co/image/abc"
        assert img.height is None
        assert img.width is None

    def test_with_dimensions(self):
        img = SpotifyImage(url="https://i.scdn.co/image/abc", height=640, width=640)
        assert img.height == 640
        assert img.width == 640


class TestSimplifiedArtist:
    def test_construction(self):
        a = SimplifiedArtist(id="abc", uri="spotify:artist:abc", name="Test")
        assert a.id == "abc"
        assert a.name == "Test"
        assert a.type == "artist"
        assert a.external_urls.spotify is None

    def test_type_default(self):
        a = SimplifiedArtist(id="abc", uri="spotify:artist:abc", name="Test")
        assert a.type == "artist"


class TestArtist:
    def test_extends_simplified(self):
        a = Artist(
            id="abc",
            uri="spotify:artist:abc",
            name="Test",
            popularity=80,
            genres=["pop", "rock"],
        )
        assert isinstance(a, SimplifiedArtist)
        assert a.popularity == 80
        assert a.genres == ["pop", "rock"]
        assert a.followers.total == 0
        assert a.images == []


class TestArtistWithAlbums:
    def test_extends_artist(self):
        a = ArtistWithAlbums(id="abc", uri="spotify:artist:abc", name="Test")
        assert isinstance(a, Artist)
        assert a.albums == []


class TestAlbumStub:
    def test_minimal(self):
        a = AlbumStub(id="abc")
        assert a.id == "abc"
        assert a.name is None
        assert a.type == "album"
        assert a.artists == []
        assert a.images == []

    def test_display_name_with_name(self):
        a = AlbumStub(id="abc", name="My Album")
        assert a.display_name == "My Album"

    def test_display_name_fallback(self):
        a = AlbumStub(id="abc")
        assert a.display_name == "abc"


class TestSimplifiedAlbum:
    def test_required_fields(self):
        a = SimplifiedAlbum(
            id="abc",
            uri="spotify:album:abc",
            name="Test Album",
            images=[SpotifyImage(url="https://example.com/img.jpg")],
            release_date="2023-01-01",
            artists=[SimplifiedArtist(id="a1", uri="spotify:artist:a1", name="Artist")],
        )
        assert a.id == "abc"
        assert a.name == "Test Album"
        assert a.display_name == "Test Album"
        assert len(a.images) == 1
        assert len(a.artists) == 1


class TestAlbum:
    def test_extends_simplified(self):
        a = Album(
            id="abc",
            uri="spotify:album:abc",
            name="Test",
            images=[],
            release_date="2023",
            artists=[],
        )
        assert isinstance(a, SimplifiedAlbum)
        assert a.copyrights == []
        assert a.tracks == []
        assert a.popularity == 0


class TestTrackStub:
    def test_minimal(self):
        t = TrackStub(id="abc")
        assert t.id == "abc"
        assert t.name is None
        assert t.explicit is False
        assert t.type == "track"
        assert t.artists == []
        assert t.album is None


class TestTrack:
    def test_required_fields(self):
        album = SimplifiedAlbum(
            id="alb",
            uri="spotify:album:alb",
            name="Album",
            images=[],
            release_date="2023",
            artists=[],
        )
        artist = SimplifiedArtist(id="art", uri="spotify:artist:art", name="Artist")
        t = Track(
            id="trk",
            uri="spotify:track:trk",
            name="Song",
            artists=[artist],
            album=album,
            track_number=1,
            disc_number=1,
            duration_ms=200000,
        )
        assert t.id == "trk"
        assert t.name == "Song"
        assert t.type == "track"
        assert t.duration_ms == 200000
        assert len(t.artists) == 1
        assert isinstance(t.album, SimplifiedAlbum)


class TestPlaylist:
    def test_defaults(self):
        p = Playlist()
        assert p.id is None
        assert p.tracks == []
        assert p.type == "playlist"
        assert isinstance(p.owner, PlaylistOwner)

    def test_with_tracks(self):
        pt = PlaylistTrack(track=TrackStub(id="t1"), added_at="2023-01-01T00:00:00Z")
        p = Playlist(id="pl1", tracks=[pt])
        assert len(p.tracks) == 1
        assert p.tracks[0].track.id == "t1"


class TestUser:
    def test_defaults(self):
        u = User()
        assert u.type == "user"
        assert u.images == []
        assert u.followers.total == 0


class TestRadioTrack:
    def test_id_property(self):
        rt = RadioTrack(uri="spotify:track:abc123")
        assert rt.id == "abc123"

    def test_id_no_colon(self):
        rt = RadioTrack(uri="abc123")
        assert rt.id == "abc123"


class TestRadioStation:
    def test_defaults(self):
        rs = RadioStation()
        assert rs.tracks == []
        assert rs.seeds == []
        assert rs.related_artists == []


class TestLyricsLine:
    def test_alias_fields(self):
        line = LyricsLine(startTimeMs=1000, words="Hello", endTimeMs=2000)
        assert line.start_time_ms == 1000
        assert line.words == "Hello"
        assert line.end_time_ms == 2000

    def test_defaults(self):
        line = LyricsLine(startTimeMs=0)
        assert line.words == ""
        assert line.end_time_ms == 0
        assert line.syllables == []


class TestLyrics:
    def test_alias_fields(self):
        lyrics = Lyrics(
            syncType="LINE_SYNCED",
            providerDisplayName="Musixmatch",
            providerLyricsId="123",
            isRtlLanguage=False,
            hasVocalRemoval=False,
        )
        assert lyrics.sync_type == "LINE_SYNCED"
        assert lyrics.provider_display_name == "Musixmatch"
        assert lyrics.provider_lyrics_id == "123"
        assert lyrics.is_rtl_language is False
        assert lyrics.has_vocal_removal is False

    def test_defaults(self):
        lyrics = Lyrics()
        assert lyrics.sync_type is None
        assert lyrics.lines == []
        assert lyrics.provider is None
        assert lyrics.language is None

    def test_with_lines(self):
        lyrics = Lyrics(
            syncType="LINE_SYNCED",
            lines=[
                LyricsLine(startTimeMs=0, words="First line"),
                LyricsLine(startTimeMs=5000, words="Second line"),
            ],
        )
        assert len(lyrics.lines) == 2
        assert lyrics.lines[0].words == "First line"


class TestPaginatedResult:
    def test_defaults(self):
        pr = PaginatedResult()
        assert pr.items == []
        assert pr.total == 0


class TestSearchResults:
    def test_defaults(self):
        sr = SearchResults()
        assert isinstance(sr.tracks, PaginatedResult)
        assert isinstance(sr.albums, PaginatedResult)
        assert isinstance(sr.artists, PaginatedResult)
        assert isinstance(sr.playlists, PaginatedResult)


class TestHomeSection:
    def test_defaults(self):
        hs = HomeSection()
        assert hs.items == []
        assert hs.title is None

    def test_with_items(self):
        item = HomeItem(uri="spotify:playlist:abc", name="Test")
        hs = HomeSection(title="Featured", items=[item])
        assert len(hs.items) == 1
        assert hs.items[0].name == "Test"


class TestAlbumModelRebuild:
    """Album.tracks references TrackStub which is defined after Album — model_rebuild() must work."""

    def test_album_with_track_stubs(self):
        album = Album(
            id="abc",
            uri="spotify:album:abc",
            name="Test",
            images=[],
            release_date="2023",
            artists=[],
            tracks=[TrackStub(id="t1", name="Track 1")],
        )
        assert len(album.tracks) == 1
        assert isinstance(album.tracks[0], TrackStub)
