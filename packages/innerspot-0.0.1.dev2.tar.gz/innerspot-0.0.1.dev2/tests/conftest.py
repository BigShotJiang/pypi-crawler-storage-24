import os

import pytest

from innerspot import MemoryCacheHandler, SpotifyClient, SpotifyWeb

# ── Known test entities ──
# These are stable, well-known Spotify entities for integration tests.

TRACK_ID = "4PTG3Z6ehGkBFwjybzWkR8"  # Never Gonna Give You Up
TRACK_NAME = "Never Gonna Give You Up"
TRACK_ARTIST = "Rick Astley"

ALBUM_ID = "6eUW0wxWtzkFdaEFsTJto6"  # Whenever You Need Somebody
ALBUM_NAME = "Whenever You Need Somebody"

ARTIST_ID = "0gxyHStUsqpMadRV0Di1Qt"  # Rick Astley
ARTIST_NAME = "Rick Astley"

PLAYLIST_ID = "37i9dQZF1DXcBWIGoYBM5M"  # Today's Top Hits
USER_ID = "spotify"


# ── Fixtures ──


@pytest.fixture(scope="session")
def anon_client():
    """Anonymous SpotifyClient (SpotifyWeb, no sp_dc). Session-scoped."""
    client = SpotifyClient(auth=SpotifyWeb(cache_handler=MemoryCacheHandler()))
    yield client
    client.close()


@pytest.fixture(scope="session")
def sp_dc_cookie():
    """Raw sp_dc cookie value from env, or skip."""
    val = os.environ.get("INNERSPOT_AUTH_SP_DC")
    if not val:
        pytest.skip("INNERSPOT_AUTH_SP_DC not set")
    return val


@pytest.fixture(scope="session")
def cookie_client(sp_dc_cookie):
    """Authenticated SpotifyClient (SpotifyWeb with sp_dc). Session-scoped."""
    auth = SpotifyWeb(sp_dc=sp_dc_cookie, cache_handler=MemoryCacheHandler())
    client = SpotifyClient(auth=auth)
    yield client
    client.close()


# ── Auto-apply markers based on module name ──


def pytest_collection_modifyitems(config, items):
    for item in items:
        if "test_anonymous" in item.nodeid:
            item.add_marker(pytest.mark.anonymous)
        elif "test_cookie" in item.nodeid:
            item.add_marker(pytest.mark.cookie)
