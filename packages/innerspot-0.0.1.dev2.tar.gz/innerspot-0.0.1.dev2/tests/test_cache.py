"""Unit tests for innerspot._cache."""

import json
import time

from innerspot._cache import CacheFileHandler, MemoryCacheHandler, TokenInfo


class TestTokenInfo:
    def test_not_expired(self):
        token = TokenInfo(
            access_token="test_token",
            expires_at=time.time() + 3600,
        )
        assert not token.is_expired

    def test_expired(self):
        token = TokenInfo(
            access_token="test_token",
            expires_at=time.time() - 100,
        )
        assert token.is_expired

    def test_expired_within_buffer(self):
        """Token is considered expired 60s before actual expiry."""
        token = TokenInfo(
            access_token="test_token",
            expires_at=time.time() + 30,  # 30s left, but 60s buffer
        )
        assert token.is_expired

    def test_defaults(self):
        token = TokenInfo(access_token="test", expires_at=0)
        assert token.token_type == "Bearer"
        assert token.refresh_token is None
        assert token.scopes == []

    def test_serialization(self):
        token = TokenInfo(
            access_token="test",
            expires_at=1234567890.0,
            refresh_token="refresh",
            token_type="Bearer",
            scopes=["streaming"],
        )
        data = json.loads(token.model_dump_json())
        assert data["access_token"] == "test"
        assert data["refresh_token"] == "refresh"
        assert data["scopes"] == ["streaming"]


class TestMemoryCacheHandler:
    def test_empty_cache(self):
        handler = MemoryCacheHandler()
        assert handler.get_cached_token() is None

    def test_save_and_retrieve(self):
        handler = MemoryCacheHandler()
        token = TokenInfo(access_token="test", expires_at=time.time() + 3600)
        handler.save_token_to_cache(token)
        cached = handler.get_cached_token()
        assert cached is not None
        assert cached.access_token == "test"

    def test_init_with_token(self):
        token = TokenInfo(access_token="test", expires_at=time.time() + 3600)
        handler = MemoryCacheHandler(token_info=token)
        cached = handler.get_cached_token()
        assert cached.access_token == "test"


class TestCacheFileHandler:
    def test_save_and_load(self, tmp_path):
        cache_path = tmp_path / ".innerspot.cache"
        handler = CacheFileHandler(cache_path=cache_path)

        token = TokenInfo(
            access_token="file_token",
            expires_at=time.time() + 3600,
            refresh_token="file_refresh",
        )
        handler.save_token_to_cache(token)

        # File should exist
        assert cache_path.exists()

        # Load it back
        loaded = handler.get_cached_token()
        assert loaded is not None
        assert loaded.access_token == "file_token"
        assert loaded.refresh_token == "file_refresh"

    def test_missing_file(self, tmp_path):
        handler = CacheFileHandler(cache_path=tmp_path / "nonexistent")
        assert handler.get_cached_token() is None

    def test_corrupt_file(self, tmp_path):
        cache_path = tmp_path / ".innerspot.cache"
        cache_path.write_text("not json")
        handler = CacheFileHandler(cache_path=cache_path)
        assert handler.get_cached_token() is None

    def test_file_permissions(self, tmp_path):
        """Cache file should be created with 600 permissions."""
        cache_path = tmp_path / ".innerspot.cache"
        handler = CacheFileHandler(cache_path=cache_path)
        token = TokenInfo(access_token="test", expires_at=time.time() + 3600)
        handler.save_token_to_cache(token)
        assert oct(cache_path.stat().st_mode & 0o777) == "0o600"
