"""Unit tests for innerspot._auth."""

import pytest

from innerspot._auth import (
    SpotifyPKCE,
    _decode_totp_secret,
    _generate_totp,
    _get_totp_secret,
)


class TestTotpSecret:
    def test_get_totp_secret(self):
        secret, version = _get_totp_secret()
        assert isinstance(secret, bytes)
        assert len(secret) > 0
        assert isinstance(version, int)
        assert version >= 59

    def test_decode_totp_secret(self):
        result = _decode_totp_secret("test")
        assert isinstance(result, bytes)
        assert len(result) > 0

    def test_decode_deterministic(self):
        a = _decode_totp_secret("hello")
        b = _decode_totp_secret("hello")
        assert a == b


class TestGenerateTotp:
    def test_returns_6_digit_string(self):
        secret = b"testsecretkey1234567890"
        totp = _generate_totp(secret, 1700000000000)
        assert isinstance(totp, str)
        assert len(totp) == 6
        assert totp.isdigit()

    def test_deterministic(self):
        secret = b"testsecretkey1234567890"
        ts = 1700000000000
        assert _generate_totp(secret, ts) == _generate_totp(secret, ts)

    def test_different_timestamps(self):
        secret = b"testsecretkey1234567890"
        totp1 = _generate_totp(secret, 1700000000000)
        totp2 = _generate_totp(secret, 1700000060000)
        assert len(totp1) == 6
        assert len(totp2) == 6


class TestSpotifyPKCE:
    def test_pkce_handshake_parameters(self):
        auth = SpotifyPKCE()
        verifier, challenge = auth.get_pkce_handshake_parameters()
        assert isinstance(verifier, str)
        assert isinstance(challenge, str)
        assert len(verifier) <= 128
        assert len(challenge) > 0
        assert "=" not in challenge

    def test_pkce_different_each_time(self):
        auth = SpotifyPKCE()
        v1, c1 = auth.get_pkce_handshake_parameters()
        v2, c2 = auth.get_pkce_handshake_parameters()
        assert v1 != v2
        assert c1 != c2

    def test_parse_response_code_valid(self):
        url = "http://127.0.0.1:5588/login?code=AQBtest123&state=xyz"
        code = SpotifyPKCE.parse_response_code(url)
        assert code == "AQBtest123"

    def test_parse_response_code_error(self):
        url = "http://127.0.0.1:5588/login?error=access_denied"
        with pytest.raises(RuntimeError, match="OAuth error"):
            SpotifyPKCE.parse_response_code(url)

    def test_parse_response_code_missing(self):
        url = "http://127.0.0.1:5588/login"
        with pytest.raises(ValueError, match="No authorization code"):
            SpotifyPKCE.parse_response_code(url)

    def test_default_scopes(self):
        auth = SpotifyPKCE()
        assert len(auth._scopes) > 10
        assert "streaming" in auth._scopes

    def test_custom_scopes_string(self):
        auth = SpotifyPKCE(scope="streaming,user-read-email")
        assert auth._scopes == ["streaming", "user-read-email"]

    def test_custom_scopes_list(self):
        auth = SpotifyPKCE(scope=["streaming", "user-read-email"])
        assert auth._scopes == ["streaming", "user-read-email"]

    def test_authorize_url(self):
        auth = SpotifyPKCE(client_id="test_client")
        url = auth.get_authorize_url(state="test_state")
        assert "accounts.spotify.com/authorize" in url
        assert "client_id=test_client" in url
        assert "response_type=code" in url
        assert "code_challenge=" in url
        assert "code_challenge_method=S256" in url
        assert "state=test_state" in url
