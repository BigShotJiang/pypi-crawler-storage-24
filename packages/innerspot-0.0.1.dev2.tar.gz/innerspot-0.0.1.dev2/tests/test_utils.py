"""Unit tests for innerspot._utils."""

import pytest

from innerspot._utils import (
    api_href,
    base62_to_hex,
    date_precision,
    derive_image_sizes,
    first,
    format_date,
    hex_to_base62,
    id_from_uri,
    id_from_url,
    image_cdn_url,
    parse_spotify_id,
    web_url,
)
from innerspot.models import SpotifyImage


class TestBase62HexConversion:
    """base62 <-> hex round-trip and known values."""

    KNOWN_PAIRS = [
        ("4PTG3Z6ehGkBFwjybzWkR8", "9eee45bc2afa4414a78eadd8bdde5b2e"),
        ("0gxyHStUsqpMadRV0Di1Qt", "08c41b6999304e0595e03913a1566059"),
    ]

    @pytest.mark.parametrize("b62,hex_id", KNOWN_PAIRS)
    def test_base62_to_hex(self, b62, hex_id):
        assert base62_to_hex(b62) == hex_id

    @pytest.mark.parametrize("b62,hex_id", KNOWN_PAIRS)
    def test_hex_to_base62(self, b62, hex_id):
        assert hex_to_base62(hex_id) == b62

    @pytest.mark.parametrize("b62,hex_id", KNOWN_PAIRS)
    def test_round_trip(self, b62, hex_id):
        assert hex_to_base62(base62_to_hex(b62)) == b62

    def test_hex_to_base62_empty(self):
        assert hex_to_base62("") is None

    def test_hex_to_base62_zero(self):
        result = hex_to_base62("0" * 32)
        assert result == "0"


class TestParseSpotifyId:
    """parse_spotify_id with URIs, URLs, and raw IDs."""

    def test_track_uri(self):
        sid, stype = parse_spotify_id("spotify:track:4PTG3Z6ehGkBFwjybzWkR8")
        assert sid == "4PTG3Z6ehGkBFwjybzWkR8"
        assert stype == "track"

    def test_album_uri(self):
        sid, stype = parse_spotify_id("spotify:album:6eUW0wxWtzkFdaEFsTJto6")
        assert sid == "6eUW0wxWtzkFdaEFsTJto6"
        assert stype == "album"

    def test_artist_uri(self):
        sid, stype = parse_spotify_id("spotify:artist:0gxyHStUsqpMadRV0Di1Qt")
        assert sid == "0gxyHStUsqpMadRV0Di1Qt"
        assert stype == "artist"

    def test_playlist_uri(self):
        sid, stype = parse_spotify_id("spotify:playlist:37i9dQZF1DXcBWIGoYBM5M")
        assert sid == "37i9dQZF1DXcBWIGoYBM5M"
        assert stype == "playlist"

    def test_track_url(self):
        sid, stype = parse_spotify_id(
            "https://open.spotify.com/track/4PTG3Z6ehGkBFwjybzWkR8"
        )
        assert sid == "4PTG3Z6ehGkBFwjybzWkR8"
        assert stype == "track"

    def test_intl_url(self):
        sid, stype = parse_spotify_id(
            "https://open.spotify.com/intl-en/track/4PTG3Z6ehGkBFwjybzWkR8"
        )
        assert sid == "4PTG3Z6ehGkBFwjybzWkR8"
        assert stype == "track"

    def test_raw_base62_id(self):
        sid, stype = parse_spotify_id("4PTG3Z6ehGkBFwjybzWkR8")
        assert sid == "4PTG3Z6ehGkBFwjybzWkR8"
        assert stype == "track"  # defaults to track

    def test_invalid_raises(self):
        with pytest.raises(ValueError, match="Invalid Spotify identifier"):
            parse_spotify_id("not-a-valid-id")


class TestIdExtraction:
    def test_id_from_uri(self):
        assert id_from_uri("spotify:track:abc123") == "abc123"

    def test_id_from_uri_no_colon(self):
        assert id_from_uri("abc123") == "abc123"

    def test_id_from_url(self):
        assert id_from_url("https://open.spotify.com/track/abc123") == "abc123"

    def test_id_from_url_trailing_slash(self):
        assert id_from_url("https://open.spotify.com/track/abc123/") == "abc123"

    def test_id_from_url_none(self):
        assert id_from_url(None) is None


class TestFormatDate:
    def test_full_date(self):
        assert format_date({"year": 2023, "month": 7, "day": 15}) == "2023-07-15"

    def test_year_month(self):
        assert format_date({"year": 2023, "month": 7}) == "2023-07"

    def test_year_only(self):
        assert format_date({"year": 2023}) == "2023"

    def test_empty(self):
        assert format_date({}) is None

    def test_zero_year(self):
        assert format_date({"year": 0}) is None


class TestDatePrecision:
    def test_day(self):
        assert date_precision({"year": 2023, "month": 7, "day": 15}) == "day"

    def test_month(self):
        assert date_precision({"year": 2023, "month": 7}) == "month"

    def test_year(self):
        assert date_precision({"year": 2023}) == "year"

    def test_empty(self):
        assert date_precision({}) is None


class TestUrlBuilders:
    def test_api_href(self):
        assert (
            api_href("tracks", "abc123") == "https://api.spotify.com/v1/tracks/abc123"
        )

    def test_api_href_none(self):
        assert api_href("tracks", None) is None

    def test_web_url(self):
        assert web_url("track", "abc123") == "https://open.spotify.com/track/abc123"

    def test_web_url_none(self):
        assert web_url("track", None) is None

    def test_image_cdn_url(self):
        result = image_cdn_url("abcdef1234")
        assert result == "https://i.scdn.co/image/abcdef1234"


class TestFirst:
    def test_nonempty(self):
        assert first(["a", "b"]) == "a"

    def test_empty(self):
        assert first([]) is None

    def test_none(self):
        assert first(None) is None


class TestDeriveImageSizes:
    def test_known_prefix(self):
        url = "https://i.scdn.co/image/ab67616d0000b273abc123"
        images = derive_image_sizes(url)
        assert len(images) == 3
        assert all(isinstance(img, SpotifyImage) for img in images)
        sizes = {img.width for img in images}
        assert sizes == {640, 300, 64}

    def test_unknown_prefix(self):
        url = "https://example.com/image.jpg"
        images = derive_image_sizes(url)
        assert len(images) == 1
        assert images[0].url == url
        assert images[0].width == 640
