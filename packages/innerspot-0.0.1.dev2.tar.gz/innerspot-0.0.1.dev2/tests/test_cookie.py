"""Integration tests using SpotifyWeb auth (sp_dc).

All tests in this module are marked with @pytest.mark.cookie automatically
via conftest.py. They require INNERSPOT_AUTH_SP_DC env var.

Covers all endpoints (including search, radio, lyrics that need auth)
and re-verifies the anonymous-capable endpoints with the authenticated token.
"""

import pytest

from innerspot import SpotifyClient
from innerspot.models import (
    Album,
    AlbumStub,
    Artist,
    ArtistWithAlbums,
    Copyright,
    ExternalIDs,
    Followers,
    HomeItem,
    HomeSection,
    Lyrics,
    LyricsLine,
    PaginatedResult,
    Playlist,
    PlaylistOwner,
    PlaylistTrack,
    RadioStation,
    RadioTrack,
    SearchResults,
    SimplifiedAlbum,
    Track,
    TrackStub,
    User,
)

from .conftest import (
    ALBUM_ID,
    ALBUM_NAME,
    ARTIST_ID,
    ARTIST_NAME,
    PLAYLIST_ID,
    TRACK_ARTIST,
    TRACK_ID,
    TRACK_NAME,
    USER_ID,
)
from .test_anonymous import (
    assert_external_urls,
    assert_simplified_artist,
    assert_spotify_image,
    assert_track_stub,
)

# ── Re-run all anonymous tests with sp_dc client ──
# These verify that the TOTP-authenticated token works for all endpoints.


class TestCookieGetTrack:
    def test_returns_track(self, cookie_client: SpotifyClient):
        track = cookie_client.get_track(TRACK_ID)
        assert isinstance(track, Track)
        assert track.id == TRACK_ID
        assert track.name == TRACK_NAME

    def test_track_fields(self, cookie_client: SpotifyClient):
        track = cookie_client.get_track(TRACK_ID)
        assert isinstance(track.duration_ms, int) and track.duration_ms > 0
        assert isinstance(track.track_number, int) and track.track_number >= 1
        assert isinstance(track.disc_number, int) and track.disc_number >= 1
        assert isinstance(track.explicit, bool)
        assert isinstance(track.artists, list) and len(track.artists) >= 1
        assert_simplified_artist(track.artists[0])
        assert track.artists[0].name == TRACK_ARTIST

    def test_track_album(self, cookie_client: SpotifyClient):
        track = cookie_client.get_track(TRACK_ID)
        assert isinstance(track.album, (SimplifiedAlbum, Album, AlbumStub))
        assert isinstance(track.album.id, str)
        assert isinstance(track.album.name, str)

    def test_track_external_ids(self, cookie_client: SpotifyClient):
        track = cookie_client.get_track(TRACK_ID)
        assert isinstance(track.external_ids, ExternalIDs)
        assert_external_urls(track.external_urls, "track")


class TestCookieGetAlbum:
    def test_returns_album(self, cookie_client: SpotifyClient):
        album = cookie_client.get_album(ALBUM_ID)
        assert isinstance(album, Album)
        assert album.id == ALBUM_ID
        assert album.name == ALBUM_NAME

    def test_album_fields(self, cookie_client: SpotifyClient):
        album = cookie_client.get_album(ALBUM_ID)
        assert isinstance(album.images, list) and len(album.images) >= 1
        assert_spotify_image(album.images[0])
        assert isinstance(album.artists, list) and len(album.artists) >= 1
        assert_simplified_artist(album.artists[0])
        assert isinstance(album.release_date, str) and len(album.release_date) >= 4
        assert isinstance(album.total_tracks, int) and album.total_tracks >= 1

    def test_album_tracks(self, cookie_client: SpotifyClient):
        album = cookie_client.get_album(ALBUM_ID)
        assert isinstance(album.tracks, list) and len(album.tracks) >= 1
        assert_track_stub(album.tracks[0])

    def test_album_copyrights(self, cookie_client: SpotifyClient):
        album = cookie_client.get_album(ALBUM_ID)
        assert isinstance(album.copyrights, list)
        for c in album.copyrights:
            assert isinstance(c, Copyright)


class TestCookieGetArtist:
    def test_returns_artist(self, cookie_client: SpotifyClient):
        artist = cookie_client.get_artist(ARTIST_ID)
        assert isinstance(artist, Artist)
        assert artist.id == ARTIST_ID
        assert artist.name == ARTIST_NAME

    def test_artist_fields(self, cookie_client: SpotifyClient):
        artist = cookie_client.get_artist(ARTIST_ID)
        assert isinstance(artist.followers, Followers)
        assert isinstance(artist.images, list)
        assert_external_urls(artist.external_urls, "artist")


class TestCookieGetArtists:
    def test_multiple(self, cookie_client: SpotifyClient):
        ids = [ARTIST_ID, "6eUKZXaKkcviH0Ku9w2n3V"]
        result = cookie_client.get_artists(ids)
        assert isinstance(result, dict)
        assert ARTIST_ID in result
        assert isinstance(result[ARTIST_ID], Artist)


class TestCookieGetArtistDiscography:
    def test_returns_artist_with_albums(self, cookie_client: SpotifyClient):
        result = cookie_client.get_artist_discography(ARTIST_ID)
        assert isinstance(result, ArtistWithAlbums)
        assert result.name == ARTIST_NAME
        assert isinstance(result.albums, list) and len(result.albums) >= 1
        assert isinstance(result.albums[0], Album)


class TestCookieGetPlaylist:
    def test_returns_playlist(self, cookie_client: SpotifyClient):
        playlist = cookie_client.get_playlist(PLAYLIST_ID)
        assert isinstance(playlist, Playlist)
        assert playlist.id == PLAYLIST_ID
        assert isinstance(playlist.name, str)

    def test_playlist_fields(self, cookie_client: SpotifyClient):
        playlist = cookie_client.get_playlist(PLAYLIST_ID)
        assert isinstance(playlist.owner, PlaylistOwner)
        assert isinstance(playlist.tracks, list) and len(playlist.tracks) >= 1
        for pt in playlist.tracks[:5]:
            assert isinstance(pt, PlaylistTrack)
            if pt.track:
                assert_track_stub(pt.track)


class TestCookieGetUser:
    def test_returns_user(self, cookie_client: SpotifyClient):
        user = cookie_client.get_user(USER_ID)
        assert isinstance(user, User)
        assert user.id == USER_ID
        assert isinstance(user.display_name, str)


class TestCookieSearch:
    def test_returns_search_results(self, cookie_client: SpotifyClient):
        results = cookie_client.search("Never Gonna Give You Up")
        assert isinstance(results, SearchResults)
        assert isinstance(results.tracks, PaginatedResult)
        assert len(results.tracks.items) >= 1

    def test_search_genre(self, cookie_client: SpotifyClient):
        results = cookie_client.search_genre("pop", limit=5)
        assert isinstance(results, SearchResults)


class TestCookieGetRadio:
    def test_returns_station(self, cookie_client: SpotifyClient):
        station = cookie_client.get_radio(f"spotify:track:{TRACK_ID}", count=5)
        assert isinstance(station, RadioStation)
        assert isinstance(station.tracks, list) and len(station.tracks) >= 1
        for rt in station.tracks[:3]:
            assert isinstance(rt, RadioTrack)
            assert rt.uri.startswith("spotify:track:")


class TestCookieArtistTopTracks:
    def test_returns_tracks(self, cookie_client: SpotifyClient):
        tracks = cookie_client.get_artist_top_tracks(ARTIST_ID)
        assert isinstance(tracks, list)
        assert len(tracks) >= 1
        assert isinstance(tracks[0], TrackStub)
        assert tracks[0].playcount is None or isinstance(tracks[0].playcount, int)


class TestCookieArtistAlbums:
    def test_returns_albums(self, cookie_client: SpotifyClient):
        albums = cookie_client.get_artist_albums(ARTIST_ID, limit=5)
        assert isinstance(albums, list)
        assert len(albums) == 5
        assert isinstance(albums[0], AlbumStub)


class TestCookieHomeSections:
    def test_returns_sections(self, cookie_client: SpotifyClient):
        sections = cookie_client.get_home_sections(limit=5)
        assert isinstance(sections, list)
        if sections:
            assert isinstance(sections[0], HomeSection)
            if sections[0].items:
                assert isinstance(sections[0].items[0], HomeItem)


class TestCookieNewReleases:
    def test_returns_releases(self, cookie_client: SpotifyClient):
        releases = cookie_client.get_new_releases()
        assert isinstance(releases, list)
        if releases:
            assert isinstance(releases[0], AlbumStub)


# ── Lyrics tests (sp_dc only) ──


class TestGetLyrics:
    def test_returns_lyrics(self, cookie_client: SpotifyClient):
        lyrics = cookie_client.get_lyrics(TRACK_ID)
        assert isinstance(lyrics, Lyrics)

    def test_lyrics_sync_type(self, cookie_client: SpotifyClient):
        lyrics = cookie_client.get_lyrics(TRACK_ID)
        assert isinstance(lyrics.sync_type, str)
        assert lyrics.sync_type in ("LINE_SYNCED", "UNSYNCED", "SYLLABLE_SYNCED")

    def test_lyrics_has_lines(self, cookie_client: SpotifyClient):
        lyrics = cookie_client.get_lyrics(TRACK_ID)
        assert isinstance(lyrics.lines, list)
        assert len(lyrics.lines) >= 1

    def test_lyrics_line_fields(self, cookie_client: SpotifyClient):
        lyrics = cookie_client.get_lyrics(TRACK_ID)
        for line in lyrics.lines[:5]:
            assert isinstance(line, LyricsLine)
            assert isinstance(line.start_time_ms, int)
            assert isinstance(line.words, str)
            assert isinstance(line.end_time_ms, int)

    def test_lyrics_line_timestamps_ascending(self, cookie_client: SpotifyClient):
        lyrics = cookie_client.get_lyrics(TRACK_ID)
        if lyrics.sync_type == "LINE_SYNCED":
            timestamps = [line.start_time_ms for line in lyrics.lines if line.words]
            assert timestamps == sorted(timestamps)

    def test_lyrics_provider(self, cookie_client: SpotifyClient):
        lyrics = cookie_client.get_lyrics(TRACK_ID)
        assert isinstance(lyrics.provider_display_name, str)
        assert len(lyrics.provider_display_name) > 0

    def test_lyrics_language(self, cookie_client: SpotifyClient):
        lyrics = cookie_client.get_lyrics(TRACK_ID)
        assert isinstance(lyrics.language, str)

    def test_lyrics_boolean_fields(self, cookie_client: SpotifyClient):
        lyrics = cookie_client.get_lyrics(TRACK_ID)
        assert isinstance(lyrics.is_rtl_language, bool)
        assert isinstance(lyrics.has_vocal_removal, bool)

    def test_lyrics_known_content(self, cookie_client: SpotifyClient):
        """Rick Astley lyrics should contain known text."""
        lyrics = cookie_client.get_lyrics(TRACK_ID)
        all_words = " ".join(line.words for line in lyrics.lines)
        assert "never gonna give you up" in all_words.lower()

    def test_lyrics_no_lyrics_track(self, cookie_client: SpotifyClient):
        """Instrumental tracks should raise ValueError."""
        # Beethoven - Moonlight Sonata (instrumental, unlikely to have lyrics)
        with pytest.raises((ValueError, Exception)):
            cookie_client.get_lyrics("3BmHMCX5xWwtKdgxyUJfHD")


class TestCookieParseId:
    def test_track_uri(self, cookie_client: SpotifyClient):
        sid, stype = cookie_client.parse_id(f"spotify:track:{TRACK_ID}")
        assert sid == TRACK_ID
        assert stype == "track"
