"""Custom exception types for innerspot."""

import httpx


class InnerSpotError(Exception):
    """Base exception for innerspot."""


class AuthError(InnerSpotError):
    """Authentication failed — token is invalid or expired."""

    def __init__(self, response: httpx.Response) -> None:
        self.response = response
        www_auth = response.headers.get("www-authenticate", "")
        if "invalid_token" in www_auth:
            msg = "Invalid or expired access token. Re-authenticate or provide a valid sp_dc cookie."
        else:
            msg = f"Authentication failed ({response.status_code})."
        super().__init__(msg)


class AccessDeniedError(InnerSpotError):
    """Token lacks required permissions for this endpoint."""

    def __init__(self, response: httpx.Response, endpoint: str = "") -> None:
        self.response = response
        body = response.text.strip()
        if body == "RBAC: access denied":
            msg = f"Access denied (RBAC) for {endpoint}. Your token lacks the required permissions."
        else:
            msg = (
                f"Permission denied ({response.status_code}) for {endpoint}. "
                "This endpoint may require an authenticated token — "
                "use SpotifyWeb(sp_dc=...) or SpotifyPKCE()."
            )
        super().__init__(msg)


class NotFoundError(InnerSpotError):
    """Requested resource was not found."""

    def __init__(self, resource_type: str, resource_id: str) -> None:
        self.resource_type = resource_type
        self.resource_id = resource_id
        super().__init__(f"{resource_type} not found: {resource_id}")


class GraphQLError(InnerSpotError):
    """GraphQL partner API returned an error."""

    def __init__(self, errors: list[dict]) -> None:
        self.errors = errors
        msg = errors[0].get("message", "GraphQL error") if errors else "GraphQL error"
        super().__init__(msg)
