"""Spotify data models.

Two tiers of types:
- Full types (Track, Album, Artist): required fields guaranteed by spclient/partner.
  Returned by get_track(), get_album(), get_artist().
- Reference types (TrackStub, AlbumStub): all fields optional.
  Returned by playlists, charts, radio, album track listings.

Track does NOT inherit from TrackStub — they are independent types.
"""

from typing import Any

from pydantic import BaseModel, ConfigDict, Field


class _BaseModel(BaseModel):
    model_config = ConfigDict(populate_by_name=True)

    raw: dict[str, Any] = Field(default_factory=dict, exclude=True, repr=False)

    def __getitem__(self, key: str) -> Any:
        return getattr(self, key)

    def __contains__(self, key: str) -> bool:
        return hasattr(self, key) and getattr(self, key) is not None

    def get(self, key: str, default: Any = None) -> Any:
        return getattr(self, key, default)


# ── Shared value types ──


class ExternalURLs(_BaseModel):
    spotify: str | None = None


class ExternalIDs(_BaseModel):
    isrc: str | None = None
    ean: str | None = None
    upc: str | None = None


class SpotifyImage(_BaseModel):
    url: str
    height: int | None = None
    width: int | None = None


class Followers(_BaseModel):
    href: str | None = None
    total: int = 0


class Copyright(_BaseModel):
    text: str | None = None
    type: str | None = None


# ── Artist ──


class SimplifiedArtist(_BaseModel):
    id: str
    uri: str
    name: str
    href: str | None = None
    external_urls: ExternalURLs = Field(default_factory=ExternalURLs)
    type: str = "artist"


class Artist(SimplifiedArtist):
    followers: Followers = Field(default_factory=Followers)
    genres: list[str] = Field(default_factory=list)
    images: list[SpotifyImage] = Field(default_factory=list)
    popularity: int | None = None


class ArtistWithAlbums(Artist):
    albums: list["Album"] = Field(default_factory=list)


# ── Album ──


class AlbumStub(_BaseModel):
    id: str
    uri: str | None = None
    name: str | None = None
    images: list[SpotifyImage] = Field(default_factory=list)
    release_date: str | None = None
    release_date_precision: str | None = None
    total_tracks: int | None = None
    artists: list[SimplifiedArtist] = Field(default_factory=list)
    album_type: str | None = None
    external_urls: ExternalURLs = Field(default_factory=ExternalURLs)
    href: str | None = None
    label: str | None = None
    type: str = "album"

    @property
    def display_name(self) -> str:
        return self.name or self.id


class SimplifiedAlbum(_BaseModel):
    id: str
    uri: str
    name: str
    images: list[SpotifyImage]
    release_date: str
    release_date_precision: str | None = None
    total_tracks: int | None = None
    artists: list[SimplifiedArtist]
    album_type: str | None = None
    available_markets: list[str] = Field(default_factory=list)
    external_urls: ExternalURLs = Field(default_factory=ExternalURLs)
    href: str | None = None
    label: str | None = None
    type: str = "album"

    @property
    def display_name(self) -> str:
        return self.name


class Album(SimplifiedAlbum):
    copyrights: list[Copyright] = Field(default_factory=list)
    external_ids: ExternalIDs = Field(default_factory=ExternalIDs)
    genres: list[str] = Field(default_factory=list)
    popularity: int = 0
    tracks: list["TrackStub"] = Field(default_factory=list)


# ── Track ──


class TrackStub(_BaseModel):
    id: str
    uri: str | None = None
    name: str | None = None
    album: AlbumStub | None = None
    artists: list[SimplifiedArtist] = Field(default_factory=list)
    disc_number: int | None = None
    duration_ms: int | None = None
    explicit: bool = False
    external_ids: ExternalIDs = Field(default_factory=ExternalIDs)
    external_urls: ExternalURLs = Field(default_factory=ExternalURLs)
    href: str | None = None
    is_playable: bool | None = None
    popularity: int | None = None
    preview_url: str | None = None
    track_number: int | None = None
    type: str = "track"
    playcount: int | None = None


class Track(_BaseModel):
    id: str
    uri: str
    name: str
    artists: list[SimplifiedArtist]
    album: SimplifiedAlbum | Album
    track_number: int
    disc_number: int
    duration_ms: int
    explicit: bool = False
    external_ids: ExternalIDs = Field(default_factory=ExternalIDs)
    external_urls: ExternalURLs = Field(default_factory=ExternalURLs)
    href: str | None = None
    is_playable: bool | None = None
    popularity: int | None = None
    preview_url: str | None = None
    type: str = "track"
    playcount: int | None = None


# ── Playlist ──


class PlaylistOwner(_BaseModel):
    id: str | None = None
    uri: str | None = None
    display_name: str | None = None
    external_urls: ExternalURLs = Field(default_factory=ExternalURLs)
    href: str | None = None
    type: str = "user"


class PlaylistTrack(_BaseModel):
    added_at: str | None = None
    track: TrackStub | None = None


class Playlist(_BaseModel):
    id: str | None = None
    uri: str | None = None
    name: str | None = None
    description: str | None = None
    collaborative: bool = False
    external_urls: ExternalURLs = Field(default_factory=ExternalURLs)
    href: str | None = None
    images: list[SpotifyImage] = Field(default_factory=list)
    owner: PlaylistOwner = Field(default_factory=PlaylistOwner)
    public: bool | None = None
    snapshot_id: str | None = None
    tracks: list[PlaylistTrack] = Field(default_factory=list)
    total_tracks: int | None = None
    type: str = "playlist"


# ── User ──


class User(_BaseModel):
    id: str | None = None
    uri: str | None = None
    display_name: str | None = None
    external_urls: ExternalURLs = Field(default_factory=ExternalURLs)
    followers: Followers = Field(default_factory=Followers)
    href: str | None = None
    images: list[SpotifyImage] = Field(default_factory=list)
    type: str = "user"


# ── Radio (internal API) ──


class RadioTrack(_BaseModel):
    uri: str
    uid: str | None = None
    original_gid: str | None = None
    artist_uri: str | None = None
    album_uri: str | None = None
    name: str | None = None
    metadata: dict[str, str] = Field(default_factory=dict)

    @property
    def id(self) -> str:
        return self.uri.split(":")[-1] if ":" in self.uri else self.uri


class RelatedArtist(_BaseModel):
    artist_name: str | None = Field(None, alias="artistName")
    image_uri: str | None = Field(None, alias="imageUri")
    artist_uri: str = Field(alias="artistUri")


class RadioStation(_BaseModel):
    uri: str | None = None
    title: str | None = None
    title_uri: str | None = Field(None, alias="titleUri")
    subtitles: list[str] = Field(default_factory=list)
    image_uri: str | None = Field(None, alias="imageUri")
    seeds: list[str] = Field(default_factory=list)
    tracks: list[RadioTrack] = Field(default_factory=list)
    related_artists: list[RelatedArtist] = Field(default_factory=list)
    correlation_id: str | None = None


# ── Lyrics ──


class LyricsLine(_BaseModel):
    start_time_ms: int = Field(alias="startTimeMs")
    words: str = ""
    end_time_ms: int = Field(0, alias="endTimeMs")
    syllables: list[dict] = Field(default_factory=list)


class Lyrics(_BaseModel):
    sync_type: str | None = Field(None, alias="syncType")
    lines: list[LyricsLine] = Field(default_factory=list)
    provider: str | None = None
    provider_lyrics_id: str | None = Field(None, alias="providerLyricsId")
    provider_display_name: str | None = Field(None, alias="providerDisplayName")
    language: str | None = None
    is_rtl_language: bool = Field(False, alias="isRtlLanguage")
    has_vocal_removal: bool = Field(False, alias="hasVocalRemoval")


# ── Search / Browse ──


class PaginatedResult(_BaseModel):
    href: str | None = None
    items: list = Field(default_factory=list)
    limit: int | None = None
    next: str | None = None
    offset: int | None = None
    previous: str | None = None
    total: int = 0


class SearchResults(_BaseModel):
    tracks: PaginatedResult = Field(default_factory=PaginatedResult)
    albums: PaginatedResult = Field(default_factory=PaginatedResult)
    artists: PaginatedResult = Field(default_factory=PaginatedResult)
    playlists: PaginatedResult = Field(default_factory=PaginatedResult)


class HomeItemOwner(_BaseModel):
    name: str | None = None
    uri: str | None = None


class HomeItem(_BaseModel):
    typename: str | None = None
    uri: str | None = None
    name: str | None = None
    description: str | None = None
    format: str | None = None
    images: list[SpotifyImage] = Field(default_factory=list)
    owner: HomeItemOwner | None = None
    total_tracks: int | None = None
    content_rating: str | None = None
    color: str | None = None
    attributes: dict[str, str] = Field(default_factory=dict)


class HomeSection(_BaseModel):
    title: str | None = None
    subtitle: str | None = None
    typename: str | None = None
    uri: str | None = None
    total_count: int | None = None
    items: list[HomeItem] = Field(default_factory=list)


Album.model_rebuild()
