import base64
import hashlib
import hmac
import http.server
import json
import logging
import math
import re
import secrets
import time
from abc import ABC, abstractmethod
from urllib.parse import parse_qs, urlencode, urlparse

import httpx

from ._cache import CacheFileHandler, CacheHandler, TokenInfo
from ._constants import TOTP_SECRETS

logger = logging.getLogger(__name__)

_EMBED_URL = "https://open.spotify.com/embed/track/4cOdK2wGLETKBW3PvgPWqT"
_TOKEN_URL = "https://open.spotify.com/api/token"
_SERVER_TIME_URL = "https://open.spotify.com/api/server-time"
_KEYMASTER_CLIENT_ID = "65b708073fc0480ea92a077233ca87bd"
_OAUTH_SCOPES = [
    "app-remote-control",
    "playlist-modify",
    "playlist-modify-private",
    "playlist-modify-public",
    "playlist-read",
    "playlist-read-collaborative",
    "playlist-read-private",
    "streaming",
    "ugc-image-upload",
    "user-follow-modify",
    "user-follow-read",
    "user-library-modify",
    "user-library-read",
    "user-modify",
    "user-modify-playback-state",
    "user-modify-private",
    "user-personalized",
    "user-read-birthdate",
    "user-read-currently-playing",
    "user-read-email",
    "user-read-play-history",
    "user-read-playback-position",
    "user-read-playback-state",
    "user-read-private",
    "user-read-recently-played",
    "user-top-read",
]


# ── TOTP helpers ──


def _decode_totp_secret(raw_secret: str) -> bytes:
    """Decode a TOTP secret string using the XOR transform from the web player."""
    transformed = [ord(c) ^ ((i % 33) + 9) for i, c in enumerate(raw_secret)]
    hex_str = "".join(str(num) for num in transformed)
    return hex_str.encode()


def _get_totp_secret() -> tuple[bytes, int]:
    """Get the latest TOTP secret and version from constants."""
    return _TOTP_SECRET


_entry = max(TOTP_SECRETS, key=lambda e: e["version"])
_TOTP_SECRET = (_decode_totp_secret(_entry["secret"]), _entry["version"])


def _generate_totp(secret: bytes, timestamp_ms: int) -> str:
    """Generate a 6-digit TOTP value."""
    counter = math.floor(timestamp_ms / 1000 / 30)
    counter_bytes = counter.to_bytes(8, byteorder="big")
    h = hmac.new(secret, counter_bytes, hashlib.sha1)
    hmac_result = h.digest()
    offset = hmac_result[-1] & 0x0F
    binary = (
        (hmac_result[offset] & 0x7F) << 24
        | (hmac_result[offset + 1] & 0xFF) << 16
        | (hmac_result[offset + 2] & 0xFF) << 8
        | (hmac_result[offset + 3] & 0xFF)
    )
    return str(binary % (10**6)).zfill(6)


# ── Base class ──


class SpotifyAuthBase(ABC):
    """Base class for Spotify authentication managers."""

    OAUTH_TOKEN_URL = "https://accounts.spotify.com/api/token"

    def __init__(
        self,
        http: httpx.Client | None = None,
        cache_handler: CacheHandler | None = None,
    ) -> None:
        self._session = http or httpx.Client(follow_redirects=True, timeout=15)
        self.cache_handler = cache_handler or CacheFileHandler()
        self._token_info: TokenInfo | None = None

    def get_access_token(self) -> str:
        """Return a valid access token, refreshing or fetching as needed."""
        if self._token_info and not self._token_info.is_expired:
            return self._token_info.access_token

        cached = self.cache_handler.get_cached_token()
        if cached and not cached.is_expired:
            self._token_info = cached
            logger.debug(
                "Loaded token from cache (expires in %.0fs)",
                cached.expires_at - time.time(),
            )
            return self._token_info.access_token

        self._request_access_token()
        return self._token_info.access_token

    @abstractmethod
    def _request_access_token(self) -> None:
        """Fetch a new token. Must set self._token_info."""

    def invalidate(self) -> None:
        """Force a token refresh on next get_access_token() call."""
        self._token_info = None

    def _save_token_info(self, token_info: TokenInfo) -> None:
        self.cache_handler.save_token_to_cache(token_info)


# ── SpotifyWeb (TOTP-based /api/token) ──


class SpotifyWeb(SpotifyAuthBase):
    """Auth manager using the web player's /api/token endpoint with TOTP.

    This is the same auth flow used by open.spotify.com. Works both
    anonymously and with an sp_dc cookie for authenticated access.

    Anonymous tokens support: metadata, partner search, home sections.
    Authenticated tokens additionally support: spclient search, radio, lyrics.
    """

    def __init__(
        self,
        sp_dc: str | None = None,
        cache_handler: CacheHandler | None = None,
        http: httpx.Client | None = None,
    ) -> None:
        super().__init__(http=http, cache_handler=cache_handler)
        self._sp_dc = sp_dc

    def _request_access_token(self) -> None:
        secret, version = _get_totp_secret()

        # Get server time for TOTP sync
        resp = self._session.get(_SERVER_TIME_URL)
        resp.raise_for_status()
        server_time_s = resp.json().get("serverTime", int(time.time()))
        server_time_ms = server_time_s * 1000

        # Generate both client and server TOTPs (matches web player behavior)
        client_totp = _generate_totp(secret, int(time.time() * 1000))
        server_totp = _generate_totp(secret, server_time_ms)

        headers = {"Cookie": f"sp_dc={self._sp_dc}"} if self._sp_dc else {}
        resp = self._session.get(
            _TOKEN_URL,
            params={
                "reason": "init",
                "productType": "web_player",
                "totp": client_totp,
                "totpServer": server_totp,
                "totpVer": version,
            },
            headers=headers,
        )
        resp.raise_for_status()
        data = resp.json()

        expires_ms = data.get("accessTokenExpirationTimestampMs", 0)
        self._token_info = TokenInfo(
            access_token=data["accessToken"],
            expires_at=expires_ms / 1000 if expires_ms else time.time() + 3600,
        )
        self._save_token_info(self._token_info)
        logger.debug(
            "Fetched web token (anonymous=%s, expires in %.0fs)",
            data.get("isAnonymous", True),
            self._token_info.expires_at - time.time(),
        )


# ── SpotifyEmbed (embed page scraping) ──


class SpotifyEmbed(SpotifyAuthBase):
    """Auth manager using the embed page to extract tokens.

    Scrapes a token from Spotify's embed page HTML. Simpler than SpotifyWeb
    (no TOTP computation) but the token has fewer permissions.

    Anonymous tokens support: metadata, partner search, home sections.
    Authenticated tokens (with sp_dc): same as anonymous (embed tokens
    have limited scopes regardless of authentication).
    """

    def __init__(
        self,
        sp_dc: str | None = None,
        cache_handler: CacheHandler | None = None,
        http: httpx.Client | None = None,
    ) -> None:
        super().__init__(http=http, cache_handler=cache_handler)
        self._sp_dc = sp_dc

    def _request_access_token(self) -> None:
        headers = {"Cookie": f"sp_dc={self._sp_dc}"} if self._sp_dc else {}
        resp = self._session.get(_EMBED_URL, headers=headers)
        resp.raise_for_status()
        match = re.search(r'<script id="__NEXT_DATA__"[^>]*>(.*?)</script>', resp.text)
        if not match:
            raise ValueError("No __NEXT_DATA__ found in embed page")
        next_data = json.loads(match.group(1))
        session = next_data["props"]["pageProps"]["state"]["settings"]["session"]
        expires_ms = session.get("accessTokenExpirationTimestampMs", 0)
        self._token_info = TokenInfo(
            access_token=session["accessToken"],
            expires_at=expires_ms / 1000 if expires_ms else time.time() + 3600,
        )
        self._save_token_info(self._token_info)
        logger.debug(
            "Fetched embed token (anonymous=%s, expires in %.0fs)",
            session.get("isAnonymous", True),
            self._token_info.expires_at - time.time(),
        )


# ── SpotifyPKCE (OAuth) ──


class SpotifyPKCE(SpotifyAuthBase):
    """Auth manager using OAuth Authorization Code + PKCE flow.

    Uses librespot's client ID by default. Works with spclient and
    official Web API. Does NOT work with GraphQL partner API.

    First call to get_access_token() triggers the OAuth flow
    unless a cached token with refresh_token is available.
    """

    OAUTH_AUTHORIZE_URL = "https://accounts.spotify.com/authorize"

    def __init__(
        self,
        client_id: str = _KEYMASTER_CLIENT_ID,
        redirect_uri: str | None = None,
        scope: str | list[str] | None = None,
        cache_handler: CacheHandler | None = None,
        redirect_port: int = 5588,
        http: httpx.Client | None = None,
    ) -> None:
        super().__init__(http=http, cache_handler=cache_handler)
        self._client_id = client_id
        self._redirect_uri = redirect_uri or f"http://127.0.0.1:{redirect_port}/login"
        self._redirect_port = redirect_port

        if isinstance(scope, str):
            self._scopes = scope.split(",")
        elif scope is not None:
            self._scopes = list(scope)
        else:
            self._scopes = list(_OAUTH_SCOPES)

    def get_access_token(self, code: str | None = None) -> str:
        if self._token_info and not self._token_info.is_expired:
            return self._token_info.access_token

        cached = self.cache_handler.get_cached_token()
        if cached:
            if not cached.is_expired:
                self._token_info = cached
                logger.debug(
                    "Loaded OAuth token from cache (expires in %.0fs)",
                    cached.expires_at - time.time(),
                )
                return self._token_info.access_token
            if cached.refresh_token:
                self._token_info = self._refresh_access_token(cached.refresh_token)
                return self._token_info.access_token

        if code:
            self._token_info = self._exchange_code(code)
        else:
            code = self.get_auth_response()
            self._token_info = self._exchange_code(code)

        return self._token_info.access_token

    def _request_access_token(self) -> None:
        """Not used — SpotifyPKCE overrides get_access_token directly."""
        raise NotImplementedError

    def invalidate(self) -> None:
        if self._token_info and self._token_info.refresh_token:
            self._token_info = self._refresh_access_token(
                self._token_info.refresh_token
            )
        else:
            self._token_info = None

    def get_authorize_url(self, state: str | None = None) -> str:
        """Return the URL to authorize this app."""
        verifier, challenge = self.get_pkce_handshake_parameters()
        self._code_verifier = verifier

        params = {
            "client_id": self._client_id,
            "response_type": "code",
            "redirect_uri": self._redirect_uri,
            "code_challenge": challenge,
            "code_challenge_method": "S256",
            "scope": " ".join(self._scopes),
        }
        if state:
            params["state"] = state
        return f"{self.OAUTH_AUTHORIZE_URL}?{urlencode(params)}"

    def get_auth_response(self) -> str:
        """Get the authorization code interactively."""
        auth_url = self.get_authorize_url()
        print(f"\nOpen this URL in your browser:\n\n{auth_url}\n")

        local = (
            input("Are you on a local machine with browser access? [y/N]: ")
            .strip()
            .lower()
        )
        if local in ("y", "yes"):
            print(f"Waiting for callback on {self._redirect_uri} ...")
            return self._get_auth_response_local_server()
        else:
            print(
                f"\nAfter login, you'll be redirected to {self._redirect_uri}?code=..."
            )
            print(
                "The page won't load — that's expected. Copy the full URL from the address bar.\n"
            )
            url = input("Paste the redirected URL: ").strip()
            return self.parse_response_code(url)

    def get_authorization_code(self, response: str | None = None) -> str:
        """Parse the authorization code from a redirect URL."""
        if response:
            return self.parse_response_code(response)
        return self.get_auth_response()

    def _exchange_code(self, code: str) -> TokenInfo:
        """Exchange authorization code for access token."""
        resp = self._session.post(
            self.OAUTH_TOKEN_URL,
            data={
                "grant_type": "authorization_code",
                "code": code,
                "redirect_uri": self._redirect_uri,
                "client_id": self._client_id,
                "code_verifier": self._code_verifier,
            },
            headers={"Content-Type": "application/x-www-form-urlencoded"},
        )
        resp.raise_for_status()
        data = resp.json()

        token_info = TokenInfo(
            access_token=data["access_token"],
            refresh_token=data.get("refresh_token"),
            expires_at=time.time() + data.get("expires_in", 3600),
            token_type=data.get("token_type", "Bearer"),
            scopes=data.get("scope", "").split(),
        )
        self._save_token_info(token_info)
        logger.debug(
            "OAuth authorization complete (expires in %.0fs)",
            token_info.expires_at - time.time(),
        )
        return token_info

    def _refresh_access_token(self, refresh_token: str) -> TokenInfo:
        """Refresh an expired access token."""
        logger.debug("Refreshing OAuth token...")
        resp = self._session.post(
            self.OAUTH_TOKEN_URL,
            data={
                "grant_type": "refresh_token",
                "refresh_token": refresh_token,
                "client_id": self._client_id,
            },
            headers={"Content-Type": "application/x-www-form-urlencoded"},
        )
        resp.raise_for_status()
        data = resp.json()

        token_info = TokenInfo(
            access_token=data["access_token"],
            refresh_token=data.get("refresh_token", refresh_token),
            expires_at=time.time() + data.get("expires_in", 3600),
            token_type=data.get("token_type", "Bearer"),
            scopes=data.get("scope", "").split() if "scope" in data else self._scopes,
        )
        self._save_token_info(token_info)
        logger.debug(
            "Refreshed OAuth token (expires in %.0fs)",
            token_info.expires_at - time.time(),
        )
        return token_info

    def get_pkce_handshake_parameters(self) -> tuple[str, str]:
        """Generate PKCE code verifier and challenge."""
        verifier = secrets.token_urlsafe(64)[:128]
        digest = hashlib.sha256(verifier.encode("ascii")).digest()
        challenge = base64.urlsafe_b64encode(digest).rstrip(b"=").decode("ascii")
        return verifier, challenge

    @staticmethod
    def parse_response_code(url: str) -> str:
        """Extract the authorization code from a redirect URL."""
        query = parse_qs(urlparse(url).query)
        if "error" in query:
            raise RuntimeError(f"OAuth error: {query['error'][0]}")
        if "code" not in query:
            raise ValueError("No authorization code found in URL")
        return query["code"][0]

    def _get_auth_response_local_server(self) -> str:
        """Wait for OAuth callback on local HTTP server."""
        auth_code = None

        class Handler(http.server.BaseHTTPRequestHandler):
            def do_GET(self):
                nonlocal auth_code
                params = parse_qs(urlparse(self.path).query)
                auth_code = params.get("code", [None])[0]
                self.send_response(200)
                self.end_headers()
                msg = (
                    b"Authentication successful! You can close this tab."
                    if auth_code
                    else b"Authentication failed."
                )
                self.wfile.write(msg)

            def log_message(self, *args):
                pass

        server = http.server.HTTPServer(("127.0.0.1", self._redirect_port), Handler)
        server.timeout = 120
        server.handle_request()
        server.server_close()

        if not auth_code:
            raise RuntimeError("No authorization code received")
        return auth_code
