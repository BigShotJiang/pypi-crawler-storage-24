import json
import logging

import httpx

from .._auth import SpotifyAuthBase
from .._utils import api_href, id_from_uri, web_url
from ..errors import AuthError, GraphQLError
from ..models import (
    Album,
    AlbumStub,
    Artist,
    Copyright,
    ExternalURLs,
    Followers,
    HomeItem,
    HomeItemOwner,
    HomeSection,
    PaginatedResult,
    Playlist,
    PlaylistOwner,
    PlaylistTrack,
    SearchResults,
    SimplifiedAlbum,
    SimplifiedArtist,
    SpotifyImage,
    Track,
    TrackStub,
)

logger = logging.getLogger(__name__)

_PARTNER_API = "https://api-partner.spotify.com/pathfinder/v1/query"

# Persisted query hashes extracted from web player JS bundle.
# Run `python scripts/extract_hashes.py --update` to refresh.
_HASHES = {
    "getTrack": "612585ae06ba435ad26369870deaae23b5c8800a256cd8a57e08eddc25a37294",
    "getAlbum": "b9bfabef66ed756e5e13f68a942deb60bd4125ec1f1be8cc42769dc0259b4b10",
    "queryArtistOverview": "5b9e64f43843fa3a9b6a98543600299b0a2cbbbccfdcdcef2402eb9c1017ca4c",
    "fetchPlaylist": "346811f856fb0b7e4f6c59f8ebea78dd081c6e2fb01b77c954b26259d5fc6763",
    "home": "3e8e118c033b10353783ec0404451de66ed44e5cb5e0caefc65e4fab7b9e0aef",
    "searchDesktop": "d9f785900f0710b31c07818d617f4f7600c1e21217e80f5b043d1e78d74e6026",
    "queryArtistDiscographyAll": "5e07d323febb57b4a56a42abbf781490e58764aa45feb6e3dc0591564fc56599",
}


class PartnerProvider:
    """Provider using Spotify's GraphQL partner API (api-partner.spotify.com)."""

    def __init__(self, http: httpx.Client, auth: SpotifyAuthBase) -> None:
        self._http = http
        self._tm = auth

    def get_track(self, track_id: str) -> Track:
        data = self.query("getTrack", {"uri": f"spotify:track:{track_id}"})
        tu = data["data"]["trackUnion"]
        # albumOfTrack in getTrack already has name, type, date, images, totalCount
        # so no separate getAlbum call needed
        return self._build_track(track_id, tu, album_detail={})

    def get_album(
        self, album_id: str, offset: int = 0, limit: int = 300, **kwargs
    ) -> Album:
        """Fetch album via getAlbum GraphQL. Tracks are paginated.

        Args:
            album_id: Spotify album ID.
            offset: Track pagination offset.
            limit: Track pagination limit (max 300).
            **kwargs: Additional GraphQL variables (e.g. locale).
        """
        variables = {
            "uri": f"spotify:album:{album_id}",
            "locale": "en",
            "offset": offset,
            "limit": limit,
            **kwargs,
        }
        data = self.query("getAlbum", variables)
        au = data["data"]["albumUnion"]
        return self._build_album(album_id, au)

    def get_artist(self, artist_id: str, **kwargs) -> Artist:
        """Fetch artist via queryArtistOverview GraphQL.

        Returns Artist with top tracks and stats available in `.raw`.

        Args:
            artist_id: Spotify artist ID.
            **kwargs: Additional GraphQL variables (e.g. locale).
        """
        variables = {"uri": f"spotify:artist:{artist_id}", "locale": "en", **kwargs}
        data = self.query("queryArtistOverview", variables)
        ao = data["data"]["artistUnion"]
        return self._build_artist_full(artist_id, ao)

    def get_artist_top_tracks(self, artist_id: str, **kwargs) -> list[TrackStub]:
        """Fetch artist's top tracks from queryArtistOverview.

        Args:
            artist_id: Spotify artist ID.
            **kwargs: Additional GraphQL variables (e.g. locale).
        """
        variables = {"uri": f"spotify:artist:{artist_id}", "locale": "en", **kwargs}
        data = self.query("queryArtistOverview", variables)
        ao = data["data"]["artistUnion"]
        return self._build_artist_top_tracks(ao)

    def get_artist_albums(
        self, artist_id: str, offset: int = 0, limit: int = 50, **kwargs
    ) -> list[AlbumStub]:
        """Fetch artist's discography via queryArtistDiscographyAll GraphQL. Paginated.

        Args:
            artist_id: Spotify artist ID.
            offset: Pagination offset.
            limit: Pagination limit (max 50).
            **kwargs: Additional GraphQL variables.
        """
        variables = {
            "uri": f"spotify:artist:{artist_id}",
            "offset": offset,
            "limit": limit,
            **kwargs,
        }
        data = self.query("queryArtistDiscographyAll", variables)
        disco = data["data"]["artistUnion"]["discography"]["all"]
        return self._build_artist_albums(disco)

    def get_playlist(
        self, playlist_id: str, offset: int = 0, limit: int = 400, **kwargs
    ) -> Playlist:
        """Fetch playlist via fetchPlaylist GraphQL. Tracks are paginated.

        Args:
            playlist_id: Spotify playlist ID.
            offset: Track pagination offset.
            limit: Track pagination limit (max 400).
            **kwargs: Additional GraphQL variables.
        """
        variables = {
            "uri": f"spotify:playlist:{playlist_id}",
            "offset": offset,
            "limit": limit,
            "enableWatchFeedEntrypoint": False,
            **kwargs,
        }
        data = self.query("fetchPlaylist", variables)
        pu = data["data"].get("playlistV2", {})
        return self._build_playlist(playlist_id, pu)

    def search(
        self,
        query: str,
        limit: int = 20,
        offset: int = 0,
        number_of_top_results: int = 5,
        include_audiobooks: bool = True,
        include_pre_releases: bool = False,
        **kwargs,
    ) -> SearchResults:
        """Search via searchDesktop GraphQL operation. Works with anonymous tokens.

        Args:
            query: Search term.
            limit: Max results per category.
            offset: Pagination offset.
            number_of_top_results: Number of top results to include.
            include_audiobooks: Include audiobooks in results.
            include_pre_releases: Include pre-release content.
            **kwargs: Additional GraphQL variables.
        """
        variables = {
            "searchTerm": query,
            "offset": offset,
            "limit": limit,
            "numberOfTopResults": number_of_top_results,
            "includeAudiobooks": include_audiobooks,
            "includePreReleases": include_pre_releases,
            **kwargs,
        }
        data = self.query("searchDesktop", variables)
        return self._build_search_results(data.get("data", {}).get("searchV2", {}))

    def get_home_sections(self, limit: int = 20) -> list[HomeSection]:

        data = self.query(
            "home",
            {
                "timeZone": "UTC",
                "sp_t": "",
                "facet": "",
                "sectionItemsLimit": limit,
                "homeEndUserIntegration": "INTEGRATION_WEB_PLAYER",
            },
        )
        raw_sections = (
            data.get("data", {})
            .get("home", {})
            .get("sectionContainer", {})
            .get("sections", {})
            .get("items", [])
        )
        sections: list[HomeSection] = []
        for s in raw_sections:
            section_data = s.get("data", {})
            section_items_data = s.get("sectionItems", {})
            items: list[HomeItem] = []
            for item in section_items_data.get("items", []):
                content = item.get("content", {}).get("data", {})
                if not content.get("uri"):
                    continue

                owner_raw = content.get("ownerV2", {}).get("data", {})
                owner = (
                    HomeItemOwner(
                        name=owner_raw.get("name"),
                        uri=owner_raw.get("uri"),
                    )
                    if owner_raw
                    else None
                )

                images_data = content.get("images", {}).get("items", [])
                images: list[SpotifyImage] = []
                for img_item in images_data:
                    for src in img_item.get("sources", []):
                        images.append(
                            SpotifyImage(
                                url=src.get("url", ""),
                                height=src.get("height"),
                                width=src.get("width"),
                            )
                        )
                if not images:
                    cover = content.get("coverArt", {})
                    for src in cover.get("sources", []):
                        images.append(
                            SpotifyImage(
                                url=src.get("url", ""),
                                height=src.get("height"),
                                width=src.get("width"),
                            )
                        )

                attrs_list = content.get("attributes", [])
                attributes = {
                    a["key"]: a["value"]
                    for a in attrs_list
                    if "key" in a and "value" in a
                }

                color_hex = None
                if images_data:
                    color_hex = (
                        images_data[0]
                        .get("extractedColors", {})
                        .get("colorDark", {})
                        .get("hex")
                    )
                if not color_hex:
                    color_hex = (
                        content.get("coverArt", {})
                        .get("extractedColors", {})
                        .get("colorDark", {})
                        .get("hex")
                    )

                content_rating = content.get("contentRating", {}).get("label")

                items.append(
                    HomeItem(
                        typename=content.get("__typename"),
                        uri=content.get("uri"),
                        name=content.get("name"),
                        description=content.get("description"),
                        format=content.get("format"),
                        images=images,
                        owner=owner,
                        total_tracks=content.get("content", {}).get("totalCount"),
                        content_rating=content_rating,
                        color=color_hex,
                        attributes=attributes,
                        raw=content,
                    )
                )

            if items:
                title_data = section_data.get("title", {})
                subtitle_data = section_data.get("subtitle", {})
                sections.append(
                    HomeSection(
                        title=title_data.get("transformedLabel")
                        or title_data.get("text"),
                        subtitle=(
                            subtitle_data.get("transformedLabel")
                            if subtitle_data
                            else None
                        ),
                        typename=section_data.get("__typename"),
                        uri=s.get("uri"),
                        total_count=section_items_data.get("totalCount"),
                        items=items,
                        raw=section_data,
                    )
                )

        return sections

    def query(self, operation: str, variables: dict) -> dict:
        resp = self._request(operation, variables)
        if resp.status_code == 401:
            self._tm.invalidate()
            resp = self._request(operation, variables)
        if resp.status_code == 401:
            raise AuthError(resp)
        resp.raise_for_status()
        data = resp.json()
        if "errors" in data:
            raise GraphQLError(data["errors"])
        return data

    def _request(self, operation: str, variables: dict) -> httpx.Response:
        token = self._tm.get_access_token()
        return self._http.get(
            _PARTNER_API,
            params={
                "operationName": operation,
                "variables": json.dumps(variables),
                "extensions": json.dumps(
                    {
                        "persistedQuery": {
                            "version": 1,
                            "sha256Hash": _HASHES[operation],
                        }
                    }
                ),
            },
            headers={
                "Authorization": f"Bearer {token}",
                "Accept": "application/json",
            },
        )

    def _parse_playcount(self, value: str | None) -> int | None:
        return int(value) if value else None

    def _is_explicit(self, data: dict) -> bool:
        return data.get("contentRating", {}).get("label", "") == "EXPLICIT"

    def _gql_artist(self, a: dict) -> SimplifiedArtist:
        uri = a.get("uri", "")
        artist_id = a.get("id") or (uri.split(":")[-1] if uri else "")
        name = a.get("profile", {}).get("name") or a.get("name", "")
        return SimplifiedArtist(
            id=artist_id,
            uri=uri,
            name=name,
            href=api_href("artists", artist_id),
            external_urls=ExternalURLs(spotify=web_url("artist", artist_id)),
        )

    def _gql_images(self, cover_art: dict) -> list[SpotifyImage]:
        return [
            SpotifyImage(url=s["url"], height=s.get("height"), width=s.get("width"))
            for s in sorted(
                cover_art.get("sources", []),
                key=lambda x: x.get("width", 0),
                reverse=True,
            )
        ]

    def _gql_date(self, date_info: dict) -> tuple[str | None, str | None]:
        iso = date_info.get("isoString", "")
        release_date = iso[:10] if iso else None
        precision = (date_info.get("precision") or "").lower() or None
        return release_date, precision

    def _build_track(self, track_id: str, tu: dict, album_detail: dict) -> Track:
        """Build Track from GraphQL trackUnion + albumUnion."""
        first_artists = tu.get("firstArtist", {}).get("items", [])
        other_artists = tu.get("otherArtists", {}).get("items", [])
        artists = [self._gql_artist(a) for a in first_artists + other_artists]

        album_data = tu.get("albumOfTrack", {})
        album_id = album_data.get("id")
        images = self._gql_images(album_data.get("coverArt", {}))

        album_type = (
            album_detail.get("type") or album_data.get("type") or ""
        ).lower() or None
        total_tracks = album_detail.get("tracksV2", album_detail.get("tracks", {})).get(
            "totalCount"
        ) or album_data.get("tracks", {}).get("totalCount")

        date_info = album_detail.get("date") or album_data.get("date", {})
        release_date, precision = self._gql_date(date_info)

        album_artists_raw = album_detail.get("artists", {}).get("items", [])
        album_artists = (
            [self._gql_artist(a) for a in album_artists_raw]
            if album_artists_raw
            else artists
        )

        album = SimplifiedAlbum(
            id=album_id,
            name=album_data.get("name"),
            album_type=album_type,
            total_tracks=total_tracks,
            uri=album_data.get("uri"),
            href=api_href("albums", album_id),
            external_urls=ExternalURLs(spotify=web_url("album", album_id)),
            images=images,
            release_date=release_date,
            release_date_precision=precision,
            artists=album_artists,
        )

        playcount_str = tu.get("playcount")
        return Track(
            id=track_id,
            name=tu["name"],
            uri=tu.get("uri") or f"spotify:track:{track_id}",
            href=api_href("tracks", track_id),
            external_urls=ExternalURLs(spotify=web_url("track", track_id)),
            duration_ms=tu["duration"]["totalMilliseconds"],
            playcount=self._parse_playcount(playcount_str),
            explicit=self._is_explicit(tu),
            is_playable=tu.get("playability", {}).get("playable"),
            track_number=tu["trackNumber"],
            disc_number=tu.get("discNumber") or 1,
            album=album,
            artists=artists,
            raw=tu,
        )

    def _build_album(self, album_id: str, au: dict) -> Album:
        """Build Album from GraphQL albumUnion."""
        artists = [self._gql_artist(a) for a in au.get("artists", {}).get("items", [])]
        images = self._gql_images(au.get("coverArt", {}))
        date_info = au.get("date", {})
        release_date, precision = self._gql_date(date_info)

        # Tracks
        tracks: list[TrackStub] = []
        tracks_data = au.get("tracksV2", au.get("tracks", {}))
        for item in tracks_data.get("items", []):
            t = item.get("track", {})
            if not t:
                continue
            tid = id_from_uri(t.get("uri", "")) if t.get("uri") else None
            t_artists = [
                self._gql_artist(a) for a in t.get("artists", {}).get("items", [])
            ]
            playcount_str = t.get("playcount")
            tracks.append(
                TrackStub(
                    id=tid,
                    name=t.get("name"),
                    uri=t.get("uri"),
                    href=api_href("tracks", tid),
                    external_urls=ExternalURLs(spotify=web_url("track", tid)),
                    duration_ms=t.get("duration", {}).get("totalMilliseconds"),
                    track_number=t.get("trackNumber"),
                    disc_number=t.get("discNumber"),
                    playcount=self._parse_playcount(playcount_str),
                    explicit=self._is_explicit(t),
                    artists=t_artists,
                )
            )

        copyrights = [
            Copyright(text=c.get("text"), type=c.get("type"))
            for c in au.get("copyright", {}).get("items", [])
        ]

        return Album(
            id=album_id,
            name=au["name"],
            album_type=(au.get("type") or "").lower() or None,
            # GraphQL getAlbum returns totalCount as None; fall back to counted tracks
            total_tracks=tracks_data.get("totalCount") or len(tracks),
            uri=au.get("uri") or f"spotify:album:{album_id}",
            href=api_href("albums", album_id),
            external_urls=ExternalURLs(spotify=web_url("album", album_id)),
            images=images,
            release_date=release_date,
            release_date_precision=precision,
            artists=artists,
            copyrights=copyrights,
            tracks=tracks,
            raw=au,
        )

    def _build_artist_full(self, artist_id: str, ao: dict) -> Artist:
        """Build Artist from GraphQL queryArtistOverview."""
        profile = ao.get("profile", {})
        stats = ao.get("stats", {})
        visuals = ao.get("visuals", {})

        images: list[SpotifyImage] = []
        for img_container in [visuals.get("avatarImage"), visuals.get("headerImage")]:
            if img_container:
                images.extend(self._gql_images(img_container))

        return Artist(
            id=artist_id,
            name=profile["name"],
            uri=ao.get("uri") or f"spotify:artist:{artist_id}",
            href=api_href("artists", artist_id),
            external_urls=ExternalURLs(spotify=web_url("artist", artist_id)),
            popularity=None,  # not in GraphQL
            followers=Followers(total=stats.get("followers")),
            images=images,
            raw=ao,
        )

    def _build_artist_top_tracks(self, ao: dict) -> list[TrackStub]:
        """Extract top tracks from queryArtistOverview response."""
        disco = ao.get("discography", {})
        top_tracks_data = disco.get("topTracks", {}).get("items", [])
        tracks: list[TrackStub] = []
        for item in top_tracks_data:
            t = item.get("track", {})
            if not t:
                continue
            tid = id_from_uri(t.get("uri", "")) if t.get("uri") else None
            t_artists = [
                self._gql_artist(a) for a in t.get("artists", {}).get("items", [])
            ]
            album_data = t.get("albumOfTrack", {})
            album_id = (
                id_from_uri(album_data.get("uri", ""))
                if album_data.get("uri")
                else None
            )
            tracks.append(
                TrackStub(
                    id=tid,
                    name=t.get("name"),
                    uri=t.get("uri"),
                    href=api_href("tracks", tid),
                    external_urls=ExternalURLs(spotify=web_url("track", tid)),
                    duration_ms=t.get("duration", {}).get("totalMilliseconds"),
                    playcount=self._parse_playcount(t.get("playcount")),
                    explicit=self._is_explicit(t),
                    artists=t_artists,
                    album=AlbumStub(
                        id=album_id,
                        name=album_data.get("name"),
                        uri=album_data.get("uri"),
                        images=(
                            self._gql_images(album_data.get("coverArt", {}))
                            if album_data.get("coverArt")
                            else []
                        ),
                    ),
                    raw=t,
                )
            )
        return tracks

    def _build_artist_albums(self, disco_all: dict) -> list[AlbumStub]:
        """Extract albums from queryArtistDiscographyAll response."""
        albums: list[AlbumStub] = []
        for item in disco_all.get("items", []):
            releases = item.get("releases", {}).get("items", [])
            if not releases:
                continue
            r = releases[0]  # primary release
            album_id = id_from_uri(r.get("uri", "")) if r.get("uri") else None
            release_date, precision = self._gql_date(r.get("date", {}))
            cover_art = r.get("coverArt", {})
            artists = [
                self._gql_artist(a) for a in r.get("artists", {}).get("items", [])
            ]
            albums.append(
                AlbumStub(
                    id=album_id,
                    name=r.get("name"),
                    uri=r.get("uri"),
                    href=api_href("albums", album_id),
                    external_urls=ExternalURLs(spotify=web_url("album", album_id)),
                    images=self._gql_images(cover_art) if cover_art else [],
                    release_date=release_date,
                    release_date_precision=precision,
                    total_tracks=r.get("tracks", {}).get("totalCount"),
                    album_type=(r.get("type") or "").lower() or None,
                    artists=artists,
                    raw=r,
                )
            )
        return albums

    def _build_playlist(self, playlist_id: str, pu: dict) -> Playlist:
        """Build Playlist from GraphQL fetchPlaylist."""
        owner_data = pu.get("ownerV2", {}).get("data", {})
        owner = PlaylistOwner(
            display_name=owner_data.get("name"),
            id=owner_data.get("username"),
            uri=owner_data.get("uri"),
        )

        images: list[SpotifyImage] = []
        for img in pu.get("images", {}).get("items", []):
            for src in img.get("sources", []):
                images.append(
                    SpotifyImage(
                        url=src["url"], height=src.get("height"), width=src.get("width")
                    )
                )

        content = pu.get("content", {})
        tracks: list[PlaylistTrack] = []
        for item in content.get("items", []):
            td = item.get("itemV2", {}).get("data", {})
            if td.get("__typename") != "Track":
                continue
            if not td.get("name") and not td.get("uri"):
                continue

            tid = id_from_uri(td.get("uri", "")) if td.get("uri") else None
            t_artists = [
                self._gql_artist(a) for a in td.get("artists", {}).get("items", [])
            ]
            album_data = td.get("albumOfTrack", {})
            album_id = (
                id_from_uri(album_data.get("uri", ""))
                if album_data.get("uri")
                else None
            )

            duration = td.get("trackDuration") or td.get("duration", {})
            duration_ms = (
                duration.get("totalMilliseconds")
                if isinstance(duration, dict)
                else None
            )

            playcount_str = td.get("playcount")
            track = TrackStub(
                id=tid,
                name=td.get("name"),
                uri=td.get("uri"),
                href=api_href("tracks", tid),
                external_urls=ExternalURLs(spotify=web_url("track", tid)),
                duration_ms=duration_ms,
                track_number=td.get("trackNumber"),
                disc_number=td.get("discNumber"),
                playcount=self._parse_playcount(playcount_str),
                explicit=self._is_explicit(td),
                artists=t_artists,
                album=AlbumStub(
                    id=album_id,
                    name=album_data.get("name"),
                    uri=album_data.get("uri"),
                    images=(
                        self._gql_images(album_data.get("coverArt", {}))
                        if album_data.get("coverArt")
                        else []
                    ),
                ),
            )
            added_at = item.get("addedAt", {})
            tracks.append(
                PlaylistTrack(
                    added_at=(
                        added_at.get("isoString")
                        if isinstance(added_at, dict)
                        else added_at
                    ),
                    track=track,
                )
            )

        return Playlist(
            id=playlist_id,
            name=pu.get("name"),
            description=pu.get("description"),
            uri=pu.get("uri") or f"spotify:playlist:{playlist_id}",
            href=api_href("playlists", playlist_id),
            external_urls=ExternalURLs(spotify=web_url("playlist", playlist_id)),
            owner=owner,
            images=images,
            tracks=tracks,
            total_tracks=content.get("totalCount"),
            raw=pu,
        )

    def _build_search_results(self, sv2: dict) -> SearchResults:
        """Build SearchResults from searchDesktop's searchV2 response."""

        def _extract_items(section: dict | None) -> list:
            if not section:
                return []
            items = section.get("items", [])
            return [
                item.get("item", {}).get("data", {})
                for item in items
                if item.get("item", {}).get("data")
            ]

        tracks_raw = sv2.get("tracksV2", {})
        albums_raw = sv2.get("albumsV2", {})
        artists_raw = sv2.get("artists", {})
        playlists_raw = sv2.get("playlists", {})

        return SearchResults(
            tracks=PaginatedResult(
                items=_extract_items(tracks_raw),
                total=tracks_raw.get("totalCount", 0) if tracks_raw else 0,
            ),
            albums=PaginatedResult(
                items=_extract_items(albums_raw),
                total=albums_raw.get("totalCount", 0) if albums_raw else 0,
            ),
            artists=PaginatedResult(
                items=_extract_items(artists_raw),
                total=artists_raw.get("totalCount", 0) if artists_raw else 0,
            ),
            playlists=PaginatedResult(
                items=_extract_items(playlists_raw),
                total=playlists_raw.get("totalCount", 0) if playlists_raw else 0,
            ),
            raw=sv2,
        )
