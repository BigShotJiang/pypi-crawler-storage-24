import base64
import json
import logging
from html.parser import HTMLParser

import httpx

from .._auth import SpotifyAuthBase
from .._utils import api_href, derive_image_sizes, first, id_from_url, web_url
from ..models import ExternalIDs, ExternalURLs, SimplifiedAlbum, SimplifiedArtist, Track

logger = logging.getLogger(__name__)

_TRACK_URL = "https://open.spotify.com/track/{track_id}"
_ALBUM_URL = "https://open.spotify.com/album/{album_id}"


class MetaExtractor(HTMLParser):
    """Extract <meta> properties and base64 <script> blocks from Spotify SSR HTML."""

    def __init__(self) -> None:
        super().__init__()
        self.meta: dict[str, list[str]] = {}
        self.json_ld: list[dict] = []
        self.base64_blocks: dict[str, dict] = {}
        self._capture: bool = False
        self._script_id: str | None = None
        self._script_type: str | None = None
        self._buf: str = ""

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        attr = dict(attrs)
        if tag == "meta":
            key = attr.get("property") or attr.get("name")
            value = attr.get("content")
            if key and value:
                self.meta.setdefault(key, []).append(value)
        elif tag == "script":
            self._script_id = attr.get("id")
            self._script_type = attr.get("type")
            if self._script_id or self._script_type == "application/ld+json":
                self._capture = True
                self._buf = ""

    def handle_data(self, data: str) -> None:
        if self._capture:
            self._buf += data

    def handle_endtag(self, tag: str) -> None:
        if tag != "script" or not self._capture:
            return
        self._capture = False
        raw = self._buf.strip()
        if self._script_type == "application/ld+json":
            try:
                self.json_ld.append(json.loads(raw))
            except (json.JSONDecodeError, ValueError):
                pass
        elif self._script_id and self._script_type == "text/plain":
            try:
                self.base64_blocks[self._script_id] = json.loads(base64.b64decode(raw))
            except Exception:
                pass
        self._script_id = None
        self._script_type = None


class ScrapingProvider:
    """Fallback provider: HTML page scraping with bot UA."""

    def __init__(self, http: httpx.Client, auth: SpotifyAuthBase) -> None:
        self._http = http
        self._tm = auth

    def get_track(self, track_id: str) -> Track:
        # Track page
        resp = self._http.get(_TRACK_URL.format(track_id=track_id))
        resp.raise_for_status()
        parser = MetaExtractor()
        parser.feed(resp.text)

        # Album page
        album_info = self._fetch_album_info(parser.meta)

        # ISRC via spclient (best-effort)
        isrc = self._try_fetch_isrc(track_id)

        return self._build_track_from_scrape(
            track_id, parser.meta, parser.json_ld, album_info, isrc
        )

    def _fetch_album_info(self, meta: dict[str, list[str]]) -> dict:
        album_urls = meta.get("music:album", [])
        if not album_urls:
            return {}
        album_id = id_from_url(album_urls[0])
        try:
            resp = self._http.get(_ALBUM_URL.format(album_id=album_id))
            resp.raise_for_status()
            ap = MetaExtractor()
            ap.feed(resp.text)
            total_tracks = len(ap.meta.get("music:song", []))
            album_type = None
            if ap.json_ld:
                desc = ap.json_ld[0].get("description", "")
                for t in ("EP", "Single", "Album", "Compilation"):
                    if f"\u00b7 {t} \u00b7" in desc:
                        album_type = t.lower()
                        break
            return {"total_tracks": total_tracks or None, "album_type": album_type}
        except Exception as exc:
            logger.warning("Album scrape failed (%s)", exc)
            return {}

    def _try_fetch_isrc(self, track_id: str) -> str | None:
        from .spclient import SpClientProvider

        try:
            provider = SpClientProvider(self._http, self._tm)
            track = provider.get_track(track_id)
            return track.external_ids.isrc
        except Exception:
            pass
        return None

    def _build_track_from_scrape(
        self,
        track_id: str,
        meta: dict[str, list[str]],
        json_ld: list[dict],
        album_info: dict,
        isrc: str | None,
    ) -> Track:
        og_desc = first(meta.get("og:description")) or ""
        desc_parts = [p.strip() for p in og_desc.split("\u00b7")]

        artist_name = first(meta.get("music:musician_description")) or (
            desc_parts[0] if desc_parts else None
        )
        artist_url = first(meta.get("music:musician"))
        artist_id = id_from_url(artist_url)
        artists = (
            [
                SimplifiedArtist(
                    id=artist_id or "",
                    uri=f"spotify:artist:{artist_id}" if artist_id else "",
                    name=artist_name,
                    href=api_href("artists", artist_id),
                    external_urls=ExternalURLs(spotify=artist_url),
                )
            ]
            if artist_name and artist_id
            else []
        )

        album_url = first(meta.get("music:album"))
        a_id = id_from_url(album_url)
        album_name = desc_parts[1] if len(desc_parts) >= 2 else None
        og_image = first(meta.get("og:image"))
        images = derive_image_sizes(og_image) if og_image else []
        release_date = first(meta.get("music:release_date"))
        ld = json_ld[0] if json_ld else {}
        release_date = release_date or ld.get("datePublished")
        duration_str = first(meta.get("music:duration"))
        duration_ms = int(duration_str) * 1000 if duration_str else None
        track_num_str = first(meta.get("music:album:track"))
        track_number = int(track_num_str) if track_num_str else None
        preview_url = first(meta.get("og:audio"))

        track_name = first(meta.get("og:title"))
        if not track_name:
            raise ValueError(f"Could not extract track name for {track_id}")

        album = SimplifiedAlbum(
            id=a_id or track_id,
            name=album_name or track_name,
            album_type=album_info.get("album_type"),
            total_tracks=album_info.get("total_tracks"),
            uri=f"spotify:album:{a_id}" if a_id else f"spotify:album:{track_id}",
            href=api_href("albums", a_id or track_id),
            external_urls=ExternalURLs(spotify=album_url),
            images=images,
            release_date=release_date or "",
            release_date_precision=(
                "day" if release_date and len(release_date) == 10 else None
            ),
            artists=artists,
        )

        return Track(
            id=track_id,
            name=track_name,
            uri=f"spotify:track:{track_id}",
            href=api_href("tracks", track_id),
            external_urls=ExternalURLs(spotify=web_url("track", track_id)),
            external_ids=ExternalIDs(isrc=isrc),
            duration_ms=duration_ms or 0,
            preview_url=preview_url,
            track_number=track_number or 1,
            disc_number=1,
            album=album,
            artists=artists,
        )
