import logging

import httpx
from google.protobuf.json_format import MessageToDict

from .._auth import SpotifyAuthBase
from .._base import (
    artist_from_gid,
    images_from_cover_group,
    images_from_portrait_group,
)
from .._utils import (
    api_href,
    base62_to_hex,
    date_precision,
    format_date,
    hex_to_base62,
    web_url,
)
from ..errors import AccessDeniedError, AuthError
from ..models import (
    Album,
    AlbumStub,
    Artist,
    ArtistWithAlbums,
    Copyright,
    ExternalIDs,
    ExternalURLs,
    Followers,
    Lyrics,
    RadioStation,
    SpotifyImage,
    Track,
    TrackStub,
    User,
)
from ..proto.generated import extended_metadata_pb2, extension_kind_pb2, metadata_pb2

logger = logging.getLogger(__name__)

_SPCLIENT_BASE = "https://spclient.wg.spotify.com"

# Service paths extracted from web player JS bundle.
# Run `python scripts/extract_hashes.py --update` to refresh.
_SPCLIENT_PATHS = {
    "metadata": "/metadata/4",
    "track-credits-view": "/track-credits-view",
    "color-lyrics": "/color-lyrics/v2",
    "user-profile-view": "/user-profile-view/v3",
    "recently-played": "/recently-played/v3",
    "socialgraph": "/socialgraph/v2",
    "playlist": "/playlist/v2",
}

# Paths not in the JS config block (discovered via testing/research).
# These are NOT auto-updated by extract_hashes.
_SPCLIENT_EXTRA_PATHS = {
    "extended-metadata": "/extended-metadata/v0/extended-metadata",
    "searchview": "/searchview/km/v4/search",
    "radio-apollo": "/radio-apollo/v3/stations",
    "context-resolve": "/context-resolve/v1",
}


class SpClientProvider:
    """Spotify internal metadata API (spclient).

    Low-level 1:1 API methods (extended_metadata, metadata_json, search,
    color_lyrics, radio, context_resolve, user_profile, inspired_playlist)
    map directly to spclient endpoints.

    Higher-level methods (get_track, get_album, get_artist, etc.) are thin
    wrappers that call the 1:1 methods and return parsed models.
    """

    def __init__(self, http: httpx.Client, auth: SpotifyAuthBase) -> None:
        self._http = http
        self._tm = auth

    # ── Higher-level model methods ──

    def get_track(self, track_id: str) -> Track:
        try:
            return self._get_track_extended(track_id)
        except Exception as exc:
            logger.warning("Extended metadata failed (%s), falling back to legacy", exc)
            return self._get_track_legacy(track_id)

    def get_album(self, album_id: str) -> Album:
        try:
            return self._get_album_extended(album_id)
        except Exception as exc:
            logger.warning("Extended metadata failed (%s), falling back to legacy", exc)
            return self._get_album_legacy(album_id)

    def get_artist(self, artist_id: str) -> Artist:
        try:
            return self._get_artist_extended(artist_id)
        except Exception as exc:
            logger.warning("Extended metadata failed (%s), falling back to legacy", exc)
            return self._get_artist_legacy(artist_id)

    def get_artists(self, artist_ids: list[str]) -> dict[str, Artist]:
        """Fetch multiple artists in a single protobuf call."""
        entities = [
            (f"spotify:artist:{aid}", extension_kind_pb2.ARTIST_V4, metadata_pb2.Artist)
            for aid in artist_ids
        ]
        results = self.extended_metadata(entities)
        return {
            aid: self._build_artist_from_proto(aid, results[f"spotify:artist:{aid}"])
            for aid in artist_ids
            if f"spotify:artist:{aid}" in results
        }

    def get_artist_discography(
        self, artist_id: str, include_groups: str = "album,single"
    ) -> ArtistWithAlbums:
        """Get artist with full discography in 2 protobuf calls."""
        artist_uri = f"spotify:artist:{artist_id}"
        results = self.extended_metadata(
            [(artist_uri, extension_kind_pb2.ARTIST_V4, metadata_pb2.Artist)]
        )
        ap = results.get(artist_uri)
        if not ap:
            raise ValueError(f"No artist metadata for {artist_uri}")

        artist = self._build_artist_from_proto(artist_id, ap)

        groups = include_groups.split(",")
        group_map = {
            "album": ap.album_group,
            "single": ap.single_group,
            "compilation": ap.compilation_group,
        }

        album_uris = []
        for group_type, group_list in group_map.items():
            if group_type not in groups:
                continue
            for ag in group_list:
                for album in ag.album:
                    if album.gid:
                        aid = hex_to_base62(album.gid.hex())
                        album_uris.append(f"spotify:album:{aid}")

        albums = []
        if album_uris:
            album_results = self.extended_metadata(
                [
                    (uri, extension_kind_pb2.ALBUM_V4, metadata_pb2.Album)
                    for uri in album_uris
                ]
            )
            albums = [
                self._build_album_from_proto(uri.split(":")[-1], alb)
                for uri, alb in album_results.items()
            ]

        return ArtistWithAlbums(**artist.model_dump(), albums=albums)

    # ── 1:1 API methods ──

    def extended_metadata(
        self, entities: list[tuple[str, int, type]]
    ) -> dict[str, object]:
        """Fetch multiple entities in a single extended-metadata call.

        Args:
            entities: list of (entity_uri, ExtensionKind, protobuf_message_class)

        Returns:
            dict mapping entity_uri to parsed protobuf message
        """
        req = extended_metadata_pb2.BatchedEntityRequest()
        kind_map: dict[str, tuple[int, type]] = {}
        for uri, kind, msg_class in entities:
            er = req.entity_request.add()
            er.entity_uri = uri
            er.query.add().extension_kind = kind
            kind_map[uri] = (kind, msg_class)

        resp = self._api_post_proto(
            self._url_extra("extended-metadata"),
            req.SerializeToString(),
        )

        batch_resp = extended_metadata_pb2.BatchedExtensionResponse()
        batch_resp.ParseFromString(resp)

        results: dict[str, object] = {}
        for ext_array in batch_resp.extended_metadata:
            for ext_data in ext_array.extension_data:
                uri = ext_data.entity_uri
                if uri not in kind_map:
                    continue
                expected_kind, msg_class = kind_map[uri]
                if ext_array.extension_kind != expected_kind:
                    continue
                if ext_data.header.status_code != 200:
                    logger.warning(
                        "Extended metadata %s returned status %d",
                        uri,
                        ext_data.header.status_code,
                    )
                    continue
                result = msg_class()
                ext_data.extension_data.Unpack(result)
                results[uri] = result

        return results

    def metadata_json(self, entity_type: str, hex_id: str) -> dict:
        """Fetch entity metadata via legacy JSON endpoint (metadata/4).

        Args:
            entity_type: "track", "album", or "artist"
            hex_id: 32-char hex entity ID (use base62_to_hex to convert)
        """
        return self._api_get(self._url("metadata", f"/{entity_type}/{hex_id}"))

    def search(self, query: str, limit: int = 20) -> dict:
        """Search via searchview/km/v4."""
        return self._api_get(
            self._url_extra("searchview", f"/{query}"),
            params={
                "limit": limit,
                "entityVersion": 2,
                "catalogue": "",
                "locale": "en",
            },
        )

    def color_lyrics(self, track_id: str) -> Lyrics:
        """Fetch lyrics via color-lyrics/v2. Requires authenticated token."""
        data = self._api_get(
            self._url("color-lyrics", f"/track/{track_id}"),
            headers={"app-platform": "WebPlayer"},
        )
        lyrics_data = data.get("lyrics")
        if not lyrics_data:
            raise ValueError(f"No lyrics available for track {track_id}")
        return Lyrics(**lyrics_data, raw=data)

    def radio(
        self, seed_uri: str, count: int = 200, prev_tracks: str | None = None
    ) -> RadioStation:
        """Fetch radio station via radio-apollo/v3."""
        params: dict = {"autoplay": "true", "count": min(count, 200)}
        if prev_tracks:
            params["prev_tracks"] = prev_tracks
        data = self._api_get(
            self._url_extra("radio-apollo", f"/{seed_uri}"), params=params
        )
        return RadioStation(**data)

    def context_resolve(self, uri: str) -> dict:
        """Fetch context data via context-resolve/v1."""
        return self._api_get(self._url_extra("context-resolve", f"/{uri}"))

    def user_profile(self, user_id: str) -> User:
        """Fetch user profile via user-profile-view/v3."""
        data = self._api_get(self._url("user-profile-view", f"/profile/{user_id}"))
        return User(
            id=user_id,
            display_name=data.get("name"),
            uri=data.get("uri") or f"spotify:user:{user_id}",
            followers=Followers(total=data.get("followers_count", 0)),
        )

    def inspired_playlist(self, seed_uri: str) -> list[str]:
        """Fetch inspired playlist URIs via inspiredby-mix/v2."""
        data = self._api_get(
            f"{_SPCLIENT_BASE}/inspiredby-mix/v2/seed_to_playlist/{seed_uri}",
            params={"response-format": "json"},
        )
        return [item["uri"] for item in data.get("mediaItems", []) if item.get("uri")]

    # ── Internal: extended metadata builders ──

    def _get_track_extended(self, track_id: str) -> Track:
        track_uri = f"spotify:track:{track_id}"
        entities: list[tuple[str, int, type]] = [
            (track_uri, extension_kind_pb2.TRACK_V4, metadata_pb2.Track)
        ]

        # Prefetch: we need the track first to know the album gid, but we can
        # batch track + album into one call if the caller already knows the
        # album URI.  Since we don't, we do a single call for the track, then
        # batch the album in.  However, spclient supports fetching mixed entity
        # types, so we do a speculative two-step: first get the track, derive
        # the album URI, then batch both in a single call.
        #
        # Actually, we need the track proto to read album.gid, so we fetch the
        # track first, then batch track + album together in one call.
        results = self.extended_metadata(entities)
        track_proto = results.get(track_uri)
        if not track_proto:
            raise ValueError(f"No track metadata for {track_uri}")

        album_proto = None
        if track_proto.album.gid:
            album_b62 = hex_to_base62(track_proto.album.gid.hex())
            album_uri = f"spotify:album:{album_b62}"
            try:
                # Batch both track and album in a single call
                batch_results = self.extended_metadata(
                    [
                        (track_uri, extension_kind_pb2.TRACK_V4, metadata_pb2.Track),
                        (album_uri, extension_kind_pb2.ALBUM_V4, metadata_pb2.Album),
                    ]
                )
                # Use the fresh track proto from the batch if available
                track_proto = batch_results.get(track_uri, track_proto)
                album_proto = batch_results.get(album_uri)
            except Exception as exc:
                logger.warning("Extended album metadata failed (%s)", exc)

        return self._build_track_from_proto(track_id, track_proto, album_proto)

    def _get_album_extended(self, album_id: str) -> Album:
        album_uri = f"spotify:album:{album_id}"
        results = self.extended_metadata(
            [(album_uri, extension_kind_pb2.ALBUM_V4, metadata_pb2.Album)]
        )
        album_proto = results.get(album_uri)
        if not album_proto:
            raise ValueError(f"No album metadata for {album_uri}")
        return self._build_album_from_proto(album_id, album_proto)

    def _get_artist_extended(self, artist_id: str) -> Artist:
        artist_uri = f"spotify:artist:{artist_id}"
        results = self.extended_metadata(
            [(artist_uri, extension_kind_pb2.ARTIST_V4, metadata_pb2.Artist)]
        )
        artist_proto = results.get(artist_uri)
        if not artist_proto:
            raise ValueError(f"No artist metadata for {artist_uri}")
        return self._build_artist_from_proto(artist_id, artist_proto)

    # ── Internal: legacy JSON builders ──

    def _get_track_legacy(self, track_id: str) -> Track:
        hex_id = base62_to_hex(track_id)
        raw = self.metadata_json("track", hex_id)

        album_detail: dict = {}
        album_hex = raw.get("album", {}).get("gid")
        if album_hex:
            try:
                album_detail = self.metadata_json("album", album_hex)
            except Exception as exc:
                logger.warning("Album API failed (%s)", exc)

        return self._build_track_from_json(track_id, raw, album_detail)

    def _get_album_legacy(self, album_id: str) -> Album:
        hex_id = base62_to_hex(album_id)
        raw = self.metadata_json("album", hex_id)
        return self._build_album_from_json(album_id, raw)

    def _get_artist_legacy(self, artist_id: str) -> Artist:
        hex_id = base62_to_hex(artist_id)
        raw = self.metadata_json("artist", hex_id)
        return self._build_artist_from_json(artist_id, raw)

    # ── Proto model builders ──

    def _proto_images(self, image_list) -> list[SpotifyImage]:
        return [
            SpotifyImage(
                url=f"https://i.scdn.co/image/{img.file_id.hex()}"
                if img.file_id
                else "",
                height=img.height if img.height else None,
                width=img.width if img.width else None,
            )
            for img in image_list
        ]

    def _proto_date(self, date) -> tuple[str | None, str | None]:
        d = {"year": date.year, "month": date.month, "day": date.day}
        return format_date(d), date_precision(d)

    def _build_track_from_proto(self, track_id: str, tp, album_proto) -> Track:
        artists = [artist_from_gid(a.gid.hex(), a.name) for a in tp.artist]

        if album_proto:
            album = self._build_album_from_proto(
                hex_to_base62(tp.album.gid.hex()) if tp.album.gid else "", album_proto
            )
        else:
            album_id = hex_to_base62(tp.album.gid.hex()) if tp.album.gid else None
            album_artists = [
                artist_from_gid(a.gid.hex(), a.name) for a in tp.album.artist
            ]
            release_date, precision = self._proto_date(tp.album.date)
            album = AlbumStub(
                id=album_id,
                name=tp.album.name,
                uri=f"spotify:album:{album_id}" if album_id else None,
                href=api_href("albums", album_id),
                external_urls=ExternalURLs(spotify=web_url("album", album_id)),
                images=self._proto_images(tp.album.cover_group.image),
                release_date=release_date,
                release_date_precision=precision,
                artists=album_artists,
                label=tp.album.label if tp.album.label else None,
            )

        isrc = None
        for eid in tp.external_id:
            if eid.type == "isrc":
                isrc = eid.id

        return Track(
            id=track_id,
            name=tp.name,
            uri=tp.canonical_uri or f"spotify:track:{track_id}",
            href=api_href("tracks", track_id),
            external_urls=ExternalURLs(spotify=web_url("track", track_id)),
            external_ids=ExternalIDs(isrc=isrc),
            duration_ms=tp.duration,
            popularity=tp.popularity,
            track_number=tp.number,
            disc_number=tp.disc_number,
            explicit=tp.explicit,
            album=album,
            artists=artists,
            raw=MessageToDict(tp),
        )

    def _build_album_from_proto(self, album_id: str, ap) -> Album:
        artists = [artist_from_gid(a.gid.hex(), a.name) for a in ap.artist]
        images = self._proto_images(ap.cover_group.image)
        release_date, precision = self._proto_date(ap.date)

        tracks: list[TrackStub] = []
        for disc in ap.disc:
            disc_num = disc.number
            for i, t in enumerate(disc.track, 1):
                tid = hex_to_base62(t.gid.hex()) if t.gid else None
                t_artists = (
                    [artist_from_gid(a.gid.hex(), a.name) for a in t.artist]
                    if t.artist
                    else artists
                )
                tracks.append(
                    TrackStub(
                        id=tid,
                        name=t.name if t.name else None,
                        uri=f"spotify:track:{tid}" if tid else None,
                        href=api_href("tracks", tid),
                        external_urls=ExternalURLs(spotify=web_url("track", tid)),
                        track_number=t.number or i,
                        disc_number=disc_num,
                        duration_ms=t.duration if t.duration else None,
                        artists=t_artists,
                    )
                )

        copyrights = [Copyright(text=c.text, type=str(c.type)) for c in ap.copyright]

        upc = None
        for eid in ap.external_id:
            if eid.type == "upc":
                upc = eid.id

        album_type = None
        if ap.type:
            album_type = metadata_pb2.Album.Type.Name(ap.type).lower()

        return Album(
            id=album_id,
            name=ap.name,
            album_type=album_type,
            total_tracks=sum(len(d.track) for d in ap.disc),
            uri=f"spotify:album:{album_id}",
            href=api_href("albums", album_id),
            external_urls=ExternalURLs(spotify=web_url("album", album_id)),
            images=images,
            release_date=release_date,
            release_date_precision=precision,
            artists=artists,
            copyrights=copyrights,
            label=ap.label if ap.label else None,
            popularity=ap.popularity,
            external_ids=ExternalIDs(upc=upc),
            tracks=tracks,
            raw=MessageToDict(ap),
        )

    def _build_artist_from_proto(self, artist_id: str, ap) -> Artist:
        images = []
        if ap.portrait_group and ap.portrait_group.image:
            images = self._proto_images(ap.portrait_group.image)
        elif ap.portrait:
            images = self._proto_images(ap.portrait)

        return Artist(
            id=artist_id,
            name=ap.name,
            uri=f"spotify:artist:{artist_id}",
            href=api_href("artists", artist_id),
            external_urls=ExternalURLs(spotify=web_url("artist", artist_id)),
            popularity=ap.popularity,
            images=images,
            raw=MessageToDict(ap),
        )

    # ── JSON model builders ──

    def _build_track_from_json(
        self, track_id: str, raw: dict, album_detail: dict
    ) -> Track:
        artists = [artist_from_gid(a["gid"], a["name"]) for a in raw.get("artist", [])]

        album_raw = raw.get("album", {})
        album_id = hex_to_base62(album_raw.get("gid", ""))

        if album_detail:
            album = self._build_album_from_json(album_id, album_detail)
        else:
            cover_src = album_raw.get("cover_group", {})
            album_artists = [
                artist_from_gid(a["gid"], a["name"])
                for a in album_raw.get("artist", [])
            ]
            date_obj = album_raw.get("date", {})
            album = AlbumStub(
                id=album_id,
                name=album_raw.get("name"),
                uri=f"spotify:album:{album_id}" if album_id else None,
                href=api_href("albums", album_id),
                external_urls=ExternalURLs(spotify=web_url("album", album_id)),
                images=images_from_cover_group(cover_src),
                release_date=format_date(date_obj),
                release_date_precision=date_precision(date_obj),
                artists=album_artists,
            )

        isrc = None
        for ext in raw.get("external_id", []):
            if ext.get("type") == "isrc":
                isrc = ext["id"]

        return Track(
            id=track_id,
            name=raw["name"],
            uri=raw.get("canonical_uri") or f"spotify:track:{track_id}",
            href=api_href("tracks", track_id),
            external_urls=ExternalURLs(spotify=web_url("track", track_id)),
            external_ids=ExternalIDs(isrc=isrc),
            duration_ms=raw["duration"],
            popularity=raw.get("popularity"),
            track_number=raw["number"],
            disc_number=raw.get("disc_number", 1),
            album=album,
            artists=artists,
            raw=raw,
        )

    def _build_album_from_json(self, album_id: str, raw: dict) -> Album:
        artists = [artist_from_gid(a["gid"], a["name"]) for a in raw.get("artist", [])]
        images = images_from_cover_group(raw.get("cover_group", {}))
        date_obj = raw.get("date", {})

        tracks: list[TrackStub] = []
        for disc in raw.get("disc", []):
            disc_num = disc.get("number", 1)
            for i, t in enumerate(disc.get("track", []), 1):
                tid = hex_to_base62(t.get("gid", ""))
                t_artists = [
                    artist_from_gid(a["gid"], a["name"])
                    for a in t.get("artist", [])
                    if a.get("gid") and a.get("name")
                ]
                tracks.append(
                    TrackStub(
                        id=tid,
                        name=t.get("name"),
                        uri=f"spotify:track:{tid}" if tid else None,
                        href=api_href("tracks", tid),
                        external_urls=ExternalURLs(spotify=web_url("track", tid)),
                        track_number=t.get("number", i),
                        disc_number=disc_num,
                        duration_ms=t.get("duration"),
                        artists=t_artists or artists,
                    )
                )

        copyrights = [
            Copyright(text=c.get("text"), type=c.get("type"))
            for c in raw.get("copyright", [])
        ]
        upc = None
        for ext in raw.get("external_id", []):
            if ext.get("type") == "upc":
                upc = ext["id"]

        return Album(
            id=album_id,
            name=raw["name"],
            album_type=(raw.get("type") or "").lower() or None,
            total_tracks=sum(len(d.get("track", [])) for d in raw.get("disc", [])),
            uri=f"spotify:album:{album_id}",
            href=api_href("albums", album_id),
            external_urls=ExternalURLs(spotify=web_url("album", album_id)),
            images=images,
            release_date=format_date(date_obj),
            release_date_precision=date_precision(date_obj),
            artists=artists,
            copyrights=copyrights,
            label=raw.get("label"),
            popularity=raw.get("popularity"),
            external_ids=ExternalIDs(upc=upc),
            tracks=tracks,
            raw=raw,
        )

    def _build_artist_from_json(self, artist_id: str, raw: dict) -> Artist:
        images = images_from_portrait_group(raw.get("portrait_group", {}))
        return Artist(
            id=artist_id,
            name=raw.get("name", ""),
            uri=raw.get("canonical_uri") or f"spotify:artist:{artist_id}",
            href=api_href("artists", artist_id),
            external_urls=ExternalURLs(spotify=web_url("artist", artist_id)),
            popularity=raw.get("popularity"),
            images=images,
            raw=raw,
        )

    # ── HTTP helpers ──

    def _api_get(
        self, url: str, params: dict | None = None, headers: dict | None = None
    ) -> dict:
        resp = self._request_get(url, params, headers)
        if resp.status_code == 401:
            self._tm.invalidate()
            resp = self._request_get(url, params, headers)
        self._raise_for_status(resp)
        return resp.json()

    def _api_post_proto(self, url: str, data: bytes) -> bytes:
        resp = self._request_post(url, data)
        if resp.status_code == 401:
            self._tm.invalidate()
            resp = self._request_post(url, data)
        self._raise_for_status(resp)
        return resp.content

    @staticmethod
    def _raise_for_status(resp: httpx.Response) -> None:
        if resp.is_success:
            return
        endpoint = resp.request.url.path
        if resp.status_code == 401:
            raise AuthError(resp)
        if resp.status_code == 403 and b"RBAC: access denied" in resp.content:
            raise AccessDeniedError(resp, endpoint)
        resp.raise_for_status()

    def _request_get(
        self, url: str, params: dict | None = None, extra_headers: dict | None = None
    ) -> httpx.Response:
        token = self._tm.get_access_token()
        headers = {"Authorization": f"Bearer {token}", "Accept": "application/json"}
        if extra_headers:
            headers.update(extra_headers)
        return self._http.get(url, params=params, headers=headers)

    def _request_post(self, url: str, data: bytes) -> httpx.Response:
        token = self._tm.get_access_token()
        return self._http.post(
            url,
            content=data,
            headers={
                "Authorization": f"Bearer {token}",
                "Content-Type": "application/x-protobuf",
            },
        )

    @staticmethod
    def _url(service: str, suffix: str = "") -> str:
        return f"{_SPCLIENT_BASE}{_SPCLIENT_PATHS[service]}{suffix}"

    @staticmethod
    def _url_extra(service: str, suffix: str = "") -> str:
        return f"{_SPCLIENT_BASE}{_SPCLIENT_EXTRA_PATHS[service]}{suffix}"
