from ._utils import api_href, hex_to_base62, image_cdn_url, web_url
from .models import ExternalURLs, SimplifiedArtist, SpotifyImage


def artist_from_gid(gid: str, name: str) -> SimplifiedArtist:
    """Build SimplifiedArtist from spclient hex gid + name."""
    aid = hex_to_base62(gid)
    return SimplifiedArtist(
        name=name,
        id=aid,
        uri=f"spotify:artist:{aid}" if aid else None,
        href=api_href("artists", aid),
        external_urls=ExternalURLs(spotify=web_url("artist", aid)),
    )


def images_from_cover_group(cover_group: dict) -> list[SpotifyImage]:
    """Build image list from spclient cover_group dict."""
    return [
        SpotifyImage(
            url=image_cdn_url(img["file_id"]),
            height=img.get("height"),
            width=img.get("width"),
        )
        for img in sorted(
            cover_group.get("image", []),
            key=lambda x: x.get("width", 0),
            reverse=True,
        )
    ]


def images_from_portrait_group(portrait_group: dict | list) -> list[SpotifyImage]:
    """Build image list from spclient portrait_group (dict or list)."""
    if isinstance(portrait_group, dict):
        portrait_group = [portrait_group]
    images = [
        SpotifyImage(
            url=image_cdn_url(img.get("file_id", "")),
            height=img.get("height"),
            width=img.get("width"),
        )
        for group in portrait_group
        for img in group.get("image", [])
    ]
    # Deduplicate by URL, largest first
    return list(
        {
            img.url: img
            for img in sorted(images, key=lambda x: x.width or 0, reverse=True)
        }.values()
    )
