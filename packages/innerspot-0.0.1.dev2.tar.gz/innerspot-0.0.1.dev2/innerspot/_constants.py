"""Constants extracted from Spotify's web player JS bundle.

Run `python scripts/extract_hashes.py --update` to refresh from the latest bundle.
"""

# TOTP secrets for /api/token authentication.
# Extracted from the web player JS bundle's inline e4 array.
# The latest (highest version) entry is used.
# Run `python scripts/extract_hashes.py --update` to refresh.
TOTP_SECRETS = [
    {"secret": ',7/*F("rLJ2oxaKL^f+E1xvP@N', "version": 61},
    {"secret": 'OmE{ZA.J^":0FG\\Uz?[@WW', "version": 60},
    {"secret": "{iOFn;4}<1PFYKPV?5{%u14]M>/V0hDH", "version": 59},
]
