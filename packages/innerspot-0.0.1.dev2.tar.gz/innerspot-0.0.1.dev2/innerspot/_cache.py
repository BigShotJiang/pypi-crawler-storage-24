import json
import logging
import os
import time
from pathlib import Path

from pydantic import BaseModel

logger = logging.getLogger(__name__)


class TokenInfo(BaseModel):
    """Token data stored in cache."""

    access_token: str
    expires_at: float
    refresh_token: str | None = None
    token_type: str = "Bearer"
    scopes: list[str] = []

    @property
    def is_expired(self) -> bool:
        return time.time() >= self.expires_at - 60


class CacheHandler:
    """Base class for token cache handlers.

    Custom implementations must implement get_cached_token and save_token_to_cache.
    """

    def get_cached_token(self) -> TokenInfo | None:
        """Return cached token info, or None if not available."""
        raise NotImplementedError

    def save_token_to_cache(self, token_info: TokenInfo) -> None:
        """Save token info to cache."""
        raise NotImplementedError


class CacheFileHandler(CacheHandler):
    """Stores token info as a JSON file on disk."""

    def __init__(self, cache_path: str | Path = ".innerspot.cache") -> None:
        self.cache_path = Path(cache_path)

    def get_cached_token(self) -> TokenInfo | None:
        try:
            data = json.loads(self.cache_path.read_text())
            return TokenInfo(**data)
        except FileNotFoundError:
            logger.debug("Cache does not exist at: %s", self.cache_path)
        except (json.JSONDecodeError, ValueError):
            logger.warning("Couldn't decode cache at: %s", self.cache_path)
        return None

    def save_token_to_cache(self, token_info: TokenInfo) -> None:
        try:
            self.cache_path.write_text(token_info.model_dump_json(indent=2))
            os.chmod(self.cache_path, 0o600)
        except OSError:
            logger.warning("Couldn't write token to cache at: %s", self.cache_path)


class MemoryCacheHandler(CacheHandler):
    """Stores token info in memory. Lost when the instance is freed."""

    def __init__(self, token_info: TokenInfo | None = None) -> None:
        self.token_info = token_info

    def get_cached_token(self) -> TokenInfo | None:
        return self.token_info

    def save_token_to_cache(self, token_info: TokenInfo) -> None:
        self.token_info = token_info
