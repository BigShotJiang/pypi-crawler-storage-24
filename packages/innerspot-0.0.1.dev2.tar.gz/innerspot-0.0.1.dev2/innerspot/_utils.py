import re

from .models import SpotifyImage

_BASE62_CHARS = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"
_BASE62_INDEX = {c: i for i, c in enumerate(_BASE62_CHARS)}
_BASE62_RE = re.compile(r"^[0-9a-zA-Z]{22}$")
_SPOTIFY_URI_RE = re.compile(r"spotify:(?P<type>\w+):(?P<id>[0-9a-zA-Z]{22})")
_SPOTIFY_URL_RE = re.compile(
    r"https?://open\.spotify\.com/(?:intl-\w+/)?(?P<type>track|album|artist|playlist|user|episode|show)/(?P<id>[0-9a-zA-Z]+)"
)

_IMAGE_CDN = "https://i.scdn.co/image/{file_id}"

_IMAGE_SIZE_PREFIXES = {
    "ab67616d0000b273": 640,
    "ab67616d00001e02": 300,
    "ab67616d00004851": 64,
}


def base62_to_hex(spotify_id: str) -> str:
    """Convert a base62 Spotify ID to a 32-char hex string."""
    n = 0
    for c in spotify_id:
        n = n * 62 + _BASE62_INDEX[c]
    return format(n, "032x")


def hex_to_base62(hex_id: str) -> str | None:
    """Convert a 32-char hex string back to a base62 Spotify ID."""
    if not hex_id:
        return None
    n = int(hex_id, 16)
    if n == 0:
        return _BASE62_CHARS[0]
    result = []
    while n:
        n, r = divmod(n, 62)
        result.append(_BASE62_CHARS[r])
    return "".join(reversed(result)).zfill(22)


def format_date(date_obj: dict) -> str | None:
    y = date_obj.get("year")
    if not y:
        return None
    m = date_obj.get("month")
    d = date_obj.get("day")
    if m and d:
        return f"{y:04d}-{m:02d}-{d:02d}"
    if m:
        return f"{y:04d}-{m:02d}"
    return f"{y:04d}"


def date_precision(date_obj: dict) -> str | None:
    if date_obj.get("day"):
        return "day"
    if date_obj.get("month"):
        return "month"
    if date_obj.get("year"):
        return "year"
    return None


def first(lst: list[str] | None) -> str | None:
    return lst[0] if lst else None


def id_from_uri(uri: str) -> str:
    """Extract the Spotify ID from a URI like 'spotify:track:xxx'."""
    return uri.split(":")[-1] if ":" in uri else uri


def id_from_url(url: str | None) -> str | None:
    if not url:
        return None
    return url.rstrip("/").split("/")[-1]


def api_href(resource: str, spotify_id: str | None) -> str | None:
    return f"https://api.spotify.com/v1/{resource}/{spotify_id}" if spotify_id else None


def web_url(resource: str, spotify_id: str | None) -> str | None:
    return f"https://open.spotify.com/{resource}/{spotify_id}" if spotify_id else None


def image_cdn_url(file_id: str) -> str:
    return _IMAGE_CDN.format(file_id=file_id)


def resolve_image_url(url: str) -> str:
    """Convert a spotify:image: URI to a CDN URL, or return as-is."""
    if url.startswith("spotify:image:"):
        return image_cdn_url(url.split(":")[-1])
    return url


def parse_spotify_id(value: str) -> tuple[str, str]:
    """Parse a Spotify URI, URL, or raw ID into (id, type).

    Returns (spotify_id, resource_type) where resource_type is one of:
    track, album, artist, playlist, user, episode, show.
    """
    m = _SPOTIFY_URI_RE.match(value)
    if m:
        return m.group("id"), m.group("type")
    m = _SPOTIFY_URL_RE.search(value)
    if m:
        return m.group("id"), m.group("type")
    if _BASE62_RE.match(value):
        return value, "track"
    raise ValueError(f"Invalid Spotify identifier: {value}")


def derive_image_sizes(og_image_url: str) -> list[SpotifyImage]:
    """Derive 640/300/64 image variants from a single Spotify og:image URL."""
    for prefix in _IMAGE_SIZE_PREFIXES:
        if prefix in og_image_url:
            hash_suffix = og_image_url.split(prefix)[-1]
            return [
                SpotifyImage(
                    url=og_image_url.replace(prefix + hash_suffix, p + hash_suffix),
                    height=s,
                    width=s,
                )
                for p, s in sorted(
                    _IMAGE_SIZE_PREFIXES.items(), key=lambda x: x[1], reverse=True
                )
            ]
    return [SpotifyImage(url=og_image_url, height=640, width=640)]
