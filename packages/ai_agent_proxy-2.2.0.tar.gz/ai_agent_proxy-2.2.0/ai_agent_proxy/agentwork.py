import fcntl
import argparse
import hashlib
import os
import socket
import subprocess
import sys
import uuid
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path

PACKAGE_DIR = Path(__file__).resolve().parent
DEFAULT_WORKSPACE = Path.home() / ".openclaw" / "workspace"

INIT_PROMPT_TEMPLATE = """
You are online in the workspace.
State: init

Workspace:
- Go to the workspace.
- Load context and initialize your working state.
- Only load the first-level Markdown files in the workspace.

Skills:
- First load and follow {ai_proxy_skill_path}.
- {context_cache_skill_path}
- {openclaw_message_cli_skill_path}

Goal:
- Build your context before doing work.
""".strip()

WORK_PROMPT_TEMPLATE = """
You are online in the workspace.
State: work

Project Skill:
- First load and follow {openclaw_message_cli_skill_path}.

Inbox:
- Check your inbox folder at {inbox_path} for pending inbox files.
- Read each inbox file as JSON.
- Read each inbox message carefully.
- Follow the instructions inside the inbox content.
- Update your memory and notes if the inbox content asks for it.
- Figure out from the inbox content what the task is.
- For messages from the same `channel` and `target`, you may batch them together in time order and reply together.
- When batching related messages, give the latest content the most weight.
- When batching related messages, you may also reply multiple times if that better reflects the flow of multiple incoming messages in a natural, professional way.
- Break the complex or longtime run task into step by step.
- Decide by yourself how to reply based on the inbox content and the current project context.
- You may choose to reply after each step finished.
- When you need to send the reply, use {openclaw_message_cli_skill_path}.
- If the inbox content does not specify a note format, maintain a daily notes file and an important memory notes file.
- If the inbox content asks you to send messages to other people, you still need to reply to the original user about the status as well.

Context:
- Before you write context content to the LLM backend, load and follow {context_cache_skill_path}.

Loop:
- After finishing one inbox item, immediately check the inbox again before doing any long wait.
- If you are still thinking and an interim update would be useful to the user, you may send multiple replies over time in a natural, professional way.
- If you are working on a long task and a new inbox message arrives asking about status, you may reply that you are still working on it, that you need more time, or report your current status and say you will update the user again soon.
- While waiting, keep checking the inbox files as well.
- Only when the inbox is empty should you wait up to {waiting_seconds} seconds for a new inbox file.
- If no new inbox file arrives during that waiting period, exit.
""".strip()

@dataclass(frozen=True)
class WorkerPaths:
    script_dir: Path
    skills_dir: Path
    context_cache_skill_path: Path
    openclaw_message_cli_skill_path: Path
    ai_proxy_skill_path: Path
    workspace: Path
    agent_root: Path
    agent_id_file: Path
    agent_id: str
    inbox_path: Path
    log_dir: Path
    lock_file: Path


class AgentWorker:
    def __init__(
        self,
        *,
        waiting_seconds: int = 300,
        agent_init_cli: str | None = None,
        agent_cli: str | None = None,
        package_dir: Path = PACKAGE_DIR,
    ) -> None:
        self.waiting_seconds = waiting_seconds
        self.agent_init_cli = agent_init_cli or os.environ.get(
            "AGENT_INIT_CLI",
            "codex exec --skip-git-repo-check --dangerously-bypass-approvals-and-sandbox",
        )
        self.agent_cli = agent_cli or os.environ.get(
            "AGENT_CLI",
            "codex exec --dangerously-bypass-approvals-and-sandbox",
        )
        self.package_dir = package_dir
        self.paths: WorkerPaths | None = None
        self._lock_handle: object | None = None

    @property
    def init_prompt(self) -> str:
        assert self.paths is not None
        return INIT_PROMPT_TEMPLATE.format(
            inbox_path=self.paths.inbox_path,
            ai_proxy_skill_path=self.paths.ai_proxy_skill_path,
            context_cache_skill_path=self.paths.context_cache_skill_path,
            openclaw_message_cli_skill_path=self.paths.openclaw_message_cli_skill_path,
        )

    @property
    def work_prompt(self) -> str:
        assert self.paths is not None
        return WORK_PROMPT_TEMPLATE.format(
            inbox_path=self.paths.inbox_path,
            ai_proxy_skill_path=self.paths.ai_proxy_skill_path,
            context_cache_skill_path=self.paths.context_cache_skill_path,
            openclaw_message_cli_skill_path=self.paths.openclaw_message_cli_skill_path,
            waiting_seconds=self.waiting_seconds,
        )

    def warn(self, message: str) -> None:
        print(message, file=sys.stderr)

    def configure_workspace(self, workspace: Path | str) -> None:
        workspace_path = Path(workspace).expanduser()
        script_dir = self.package_dir
        skills_dir = script_dir / "skills"
        agent_root = workspace_path / ".ai-agent-proxy"
        agent_root.mkdir(parents=True, exist_ok=True)
        agent_id_file = agent_root / "agent_id"
        agent_id = self.load_or_create_agent_id(agent_id_file, workspace_path)
        inbox_path = agent_root / "inbox"
        inbox_path.mkdir(parents=True, exist_ok=True)
        log_dir = agent_root / "logs"
        self.paths = WorkerPaths(
            script_dir=script_dir,
            skills_dir=skills_dir,
            context_cache_skill_path=skills_dir / "context-cache-skill" / "SKILL.md",
            openclaw_message_cli_skill_path=skills_dir / "openclaw-message-cli-skill" / "SKILL.md",
            ai_proxy_skill_path=skills_dir / "ai_proxy_skill" / "SKILL.md",
            workspace=workspace_path,
            agent_root=agent_root,
            agent_id_file=agent_id_file,
            agent_id=agent_id,
            inbox_path=inbox_path,
            log_dir=log_dir,
            lock_file=agent_root / "LOCK",
        )

    def require_paths(self) -> WorkerPaths:
        if self.paths is None:
            raise RuntimeError("workspace is not initialized; call init(workspace=...) first")
        return self.paths

    def inbox(self) -> Path:
        return self.require_paths().inbox_path

    def primary_mac_address(self) -> str:
        route_file = Path("/proc/net/route")
        try:
            lines = route_file.read_text(encoding="utf-8").splitlines()[1:]
        except OSError:
            lines = []

        for line in lines:
            fields = line.split()
            if len(fields) < 2:
                continue
            interface_name, destination = fields[0], fields[1]
            if destination != "00000000":
                continue
            address_file = Path("/sys/class/net") / interface_name / "address"
            try:
                mac_address = address_file.read_text(encoding="utf-8").strip().lower()
            except OSError:
                continue
            if mac_address and mac_address != "00:00:00:00:00:00":
                return mac_address

        fallback_mac = uuid.getnode()
        return ":".join(f"{(fallback_mac >> shift) & 0xff:02x}" for shift in range(40, -1, -8))

    def calculate_agent_id(self, workspace: Path) -> str:
        workspace_path = workspace.resolve()
        fingerprint = "\n".join(
            [
                socket.gethostname(),
                str(workspace_path),
                self.primary_mac_address(),
            ]
        )
        return hashlib.sha256(fingerprint.encode("utf-8")).hexdigest()[:6]

    def load_or_create_agent_id(self, agent_id_file: Path, workspace: Path) -> str:
        agent_id = self.calculate_agent_id(workspace)
        try:
            agent_id_file.write_text(f"{agent_id}\n", encoding="utf-8")
        except OSError as exc:
            raise RuntimeError(f"failed to write agent id file {agent_id_file}: {exc}") from exc
        return agent_id

    def print_env(self) -> None:
        paths = self.require_paths()
        print(f"AGENT_WORK_SCRIPT_DIR={paths.script_dir}")
        print(f"AGENT_WORK_SKILLS_DIR={paths.skills_dir}")
        print(f"AGENT_WORK_CONTEXT_CACHE_SKILL_PATH={paths.context_cache_skill_path}")
        print(f"AGENT_WORK_OPENCLAW_MESSAGE_CLI_SKILL_PATH={paths.openclaw_message_cli_skill_path}")
        print(f"AGENT_WORK_AI_PROXY_SKILL_PATH={paths.ai_proxy_skill_path}")
        print(f"AGENT_WORK_WORKSPACE={paths.workspace}")
        print(f"AGENT_WORK_AGENT_ROOT={paths.agent_root}")
        print(f"AGENT_WORK_AGENT_ID_FILE={paths.agent_id_file}")
        print(f"AGENT_WORK_AGENT_ID={paths.agent_id}")
        print(f"AGENT_WORK_INBOX_PATH={paths.inbox_path}")
        print(f"AGENT_WORK_LOG_DIR={paths.log_dir}")
        print(f"AGENT_WORK_INIT_CLI={self.agent_init_cli}")
        print(f"AGENT_WORK_CLI={self.agent_cli}")
        print(f"AGENT_WORK_PWD={Path.cwd()}")

    def log_file_path(self) -> Path:
        return self.require_paths().log_dir / f"{datetime.now(timezone.utc).date().isoformat()}.log"

    def ensure_workspace(self) -> bool:
        paths = self.require_paths()
        try:
            paths.workspace.mkdir(parents=True, exist_ok=True)
            self.inbox().mkdir(parents=True, exist_ok=True)
            paths.log_dir.mkdir(parents=True, exist_ok=True)
        except OSError as exc:
            self.warn(f"agent_work.py: failed to prepare workspace {paths.workspace}: {exc}")
            return False
        return True

    def acquire_lock(self) -> bool:
        paths = self.require_paths()
        try:
            handle = paths.lock_file.open("w")
        except OSError as exc:
            self.warn(f"agent_work.py: failed to open lock file {paths.lock_file}: {exc}")
            return False

        try:
            fcntl.flock(handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except OSError:
            handle.close()
            self.warn(f"agent_work.sh is already running for {paths.workspace}")
            return False

        self._lock_handle = handle
        return True

    def run_agent_to_log(self, *, action: str, cli: str, prompt: str) -> int:
        paths = self.require_paths()
        log_file = self.log_file_path()
        timestamp = datetime.now(timezone.utc).astimezone().isoformat()
        with log_file.open("a", encoding="utf-8") as handle:
            handle.write(f"[{timestamp}] action={action} workspace={paths.workspace} cli={cli}\n")
            result = subprocess.run(
                ["/bin/bash", "-lc", f'{cli} "$AGENT_PROMPT"'],
                cwd=paths.workspace,
                env={**os.environ, "AGENT_PROMPT": prompt},
                stdout=handle,
                stderr=subprocess.STDOUT,
                text=True,
                check=False,
            )
            end_timestamp = datetime.now(timezone.utc).astimezone().isoformat()
            handle.write(f"[{end_timestamp}] action={action} exit_code={result.returncode}\n")
        if result.returncode != 0:
            self.warn(f"agent_work.py: agent command failed for action={action} workspace={paths.workspace}")
        return result.returncode

    def run_agent(self, *, action: str, cli: str, prompt: str, stream_to_console: bool = False) -> int:
        paths = self.require_paths()
        if stream_to_console:
            process = subprocess.Popen(
                ["/bin/bash", "-lc", f'{cli} "$AGENT_PROMPT"'],
                cwd=paths.workspace,
                env={**os.environ, "AGENT_PROMPT": prompt},
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
            )
            assert process.stdout is not None
            for line in process.stdout:
                print(line, end="", flush=True)
            result_code = process.wait()
        else:
            result = subprocess.run(
                ["/bin/bash", "-lc", f'{cli} "$AGENT_PROMPT"'],
                cwd=paths.workspace,
                env={**os.environ, "AGENT_PROMPT": prompt},
                check=False,
            )
            result_code = result.returncode

        if result_code != 0:
            self.warn(f"agent_work.py: agent command failed for action={action} workspace={paths.workspace}")
        return result_code

    def init(self, *, workspace: Path | str = DEFAULT_WORKSPACE) -> Path:
        self.configure_workspace(workspace)
        if not self.ensure_workspace():
            return self.inbox()
        paths = self.require_paths()
        try:
            os.chdir(paths.workspace)
        except OSError as exc:
            self.warn(f"agent_work.py: failed to enter workspace {paths.workspace}: {exc}")
            return self.inbox()

        self.print_env()
        self.run_agent(action="init", cli=self.agent_init_cli, prompt=self.init_prompt, stream_to_console=True)
        return self.inbox()

    def work(self) -> int:
        paths = self.require_paths()
        if not self.ensure_workspace():
            return 0
        if not self.acquire_lock():
            return 0

        try:
            os.chdir(paths.workspace)
        except OSError as exc:
            self.warn(f"agent_work.py: failed to enter workspace {paths.workspace}: {exc}")
            return 0

        self.print_env()
        self.run_agent_to_log(action="work", cli=self.agent_cli, prompt=self.work_prompt)
        return 0


__all__ = ["AgentWorker", "DEFAULT_WORKSPACE", "PACKAGE_DIR", "WorkerPaths"]


def main() -> int:
    parser = argparse.ArgumentParser(prog="python -m ai_agent_proxy.agentwork")
    parser.add_argument("action", choices=["init", "work"])
    parser.add_argument("--workspace", type=Path, default=DEFAULT_WORKSPACE)
    parser.add_argument("--waiting-seconds", type=int, default=300)
    args = parser.parse_args()

    worker = AgentWorker(waiting_seconds=args.waiting_seconds)
    if args.action == "init":
        worker.init(workspace=args.workspace)
        return 0

    worker.configure_workspace(args.workspace)
    return worker.work()


if __name__ == "__main__":
    raise SystemExit(main())
