# -*- coding:utf-8 -*-

from fastapi import APIRouter, Request

from odoo_api.core.config import get_settings
from odoo_api.core.limiter import limiter, route_limit
from odoo_api.dependencies.auth import authenticate
from odoo_api.dependencies.token import Token, AuthenticationBody
from odoo_api.exceptions import UnauthorizedException

router = APIRouter(tags=["Authentication"])


@router.post('/api/login', response_model=Token, summary="Login", description="Authenticate with Odoo credentials and receive a JWT access token.")
@limiter.limit(route_limit("/api/login"))
async def login(request: Request, info: AuthenticationBody):
    db = info.db or get_settings().odoo_db
    token = await authenticate(db, info.username, info.password)
    if not token:
        raise UnauthorizedException(message="Incorrect login information")
    return {"access_token": token, "token_type": "bearer"}
