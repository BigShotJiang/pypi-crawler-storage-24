"""
DVGateway AI Adapters

Pre-built adapters for popular AI services.
Import only what you need.

Adapter overview:
  STT  (Speech-to-Text)    — Deepgram Nova-3, Google Chirp3
  TTS  (Text-to-Speech)    — ElevenLabs Flash v2.5, OpenAI TTS, Gemini TTS, CosyVoice
  LLM  (Language Model)    — Anthropic Claude, OpenAI GPT
  Realtime (Speech-to-Speech) — OpenAI Realtime API (audio 1.5)

Example (standard cascaded pipeline: STT → LLM → TTS):
    from dvgateway.adapters.stt import DeepgramAdapter
    from dvgateway.adapters.tts import ElevenLabsAdapter
    from dvgateway.adapters.llm import AnthropicAdapter

Example (direct speech-to-speech — lower latency):
    from dvgateway.adapters.realtime import OpenAIRealtimeAdapter
"""
