import hashlib
from enum import Enum, StrEnum


class Color(StrEnum):
    RED = "\033[0;31m"
    GREEN = "\033[0;32m"
    BROWN = "\033[0;33m"
    BLUE = "\033[0;34m"
    PURPLE = "\033[0;35m"
    CYAN = "\033[0;36m"
    YELLOW = "\033[1;33m"
    RESET = "\x1b[0m"

    @staticmethod
    def from_str(s: str):
        colors = [color for color in Color._member_map_ if color != "RESET"]
        hash_s = int(hashlib.md5(s.encode("utf-8")).hexdigest(), 16)
        color_name = colors[hash_s % (len(colors))]
        return Color._member_map_[color_name]


def colorize(s: str, color: Enum) -> str:
    return f"{color}{s}{Color.RESET}"
