class BaseBrakeException(Exception):
    def __eq__(self, other) -> bool:
        return type(self) is type(other) and self.args == other.args


class CyclicGraph(BaseBrakeException):
    pass


class InvalidDependency(BaseBrakeException):
    pass


class DuplicatedTarget(BaseBrakeException):
    pass


class MultipleDefaultTargets(BaseBrakeException):
    pass


class UndefinedVariable(BaseBrakeException):
    pass


class CircularVariable(BaseBrakeException):
    pass
