from parsimonious.grammar import Grammar
from parsimonious.nodes import Node, NodeVisitor

from brake.model import ParserOutput, Target, TargetDecorator, Variable

grammar = Grammar("""
    start         = (target/variable)+
    target        = target_decorator name ":" NEWLINE command_block NEWLINE*
    target_decorator     = "@" ("task"/"file") target_args* NEWLINE
    target_args   = "(" kv* ")"
    kv            =  name "=" (list / string / bool) ","? " "? NEWLINE?
    command_block = command*
    command       = INDENT LINE NEWLINE
    variable      = var " "* "=" " "* LINE NEWLINE*

    NEWLINE = ~r"\\n"
    string = ~'"[^\"]*"'
    list   =  "[" list_member* "]"
    list_member = (" "* name " "* ","?)
    bool   = ("true"/"false")
    LINE   = ~"[^\\n]+"  # Match any line not containing a newline
    name   = ~r"[a-zA-Z*][a-zA-Z0-9_\\-./*]*"
    var    = ~r"[a-zA-Z][a-zA-Z0-9_]*"
    INDENT = ~r"\\s{4}"  # 4 spaces for indentation
    DEDENT = ~r"\\s{0,3}"  # Allow variable indentation sizes after a block

""")


class TargetVisitor(NodeVisitor):
    def visit(self, node: Node) -> ParserOutput:
        return super().visit(node)

    def visit_start(self, node: Node, visited_children) -> ParserOutput:
        targets, variables = [], []
        for (child,) in visited_children:
            if isinstance(child, Target):
                targets.append(child)
            elif isinstance(child, Variable):
                variables.append(child)
        return ParserOutput(variables=variables, targets=targets)

    def visit_target(self, node: Node, visited_children) -> Target:
        decorator, target_name, *_, command_block, _ = visited_children
        kwargs = decorator.args.copy()
        if kwargs.get("default"):
            kwargs["default"] = True
        return Target(
            name=target_name,
            type=decorator.type,
            commands=command_block,
            **kwargs,
        )

    def visit_variable(self, node: Node, visited_children) -> Variable:
        var, _, _, _, value, _ = visited_children
        return Variable(name=var.text, value=value.text)

    def visit_target_decorator(self, node: Node, visited_children) -> TargetDecorator:
        _, target_type, task_args, _ = visited_children
        task_args = task_args[0] if (isinstance(task_args, list) and task_args) else {}
        return TargetDecorator(type=target_type[0].text, args=task_args)

    def visit_target_args(self, node: Node, visited_children) -> dict[str, str]:
        args = {}
        openinig_bracket, kvs, closing_bracket = visited_children
        for kv in kvs:
            args.update(kv)
        return args

    def visit_kv(self, node: Node, visited_children) -> dict[str, str]:
        kv = {}
        key, _, val, *_ = visited_children
        kv[key] = val[0]  # not sure why I have to index here
        return kv

    def visit_command_block(self, node: Node, visited_children):
        return visited_children

    def visit_command(self, node: Node, visited_children) -> str:
        indent, cmd, newline = node.children
        return cmd.text

    def visit_list(self, node: Node, visited_children) -> list:
        opening_bracket, members, closing_bracket = visited_children
        if isinstance(members, list):
            return members
        return members.children

    def visit_string(self, node: Node, visited_children) -> str:
        return node.text.strip('"')

    def visit_bool(self, node: Node, visited_children) -> bool:
        return eval(node.text.capitalize())

    def visit_list_member(self, node: Node, visited_children) -> list:
        _, member, *_ = visited_children
        return member

    def visit_name(self, node: Node, visited_children) -> str:
        return node.text

    def generic_visit(self, node: Node, visited_children):
        # For any node we don't explicitly handle
        return visited_children or node
