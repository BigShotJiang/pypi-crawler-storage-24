"""Authentication CLI commands."""

import sys
from typing import Optional

import typer
from rich.console import Console

from opensees_cli import api, config

console = Console()


def _ask_password(label: str = "Password") -> str:
    """Prompt for a password showing * for each keystroke."""
    if sys.platform == "win32":
        import msvcrt
        console.print(f"{label}: ", end="")
        chars = []
        while True:
            ch = msvcrt.getwch()
            if ch in ("\r", "\n"):
                console.print()
                break
            if ch == "\x03":
                raise KeyboardInterrupt
            if ch in ("\x08", "\x7f"):
                if chars:
                    chars.pop()
                    sys.stdout.write("\b \b")
                    sys.stdout.flush()
                continue
            chars.append(ch)
            sys.stdout.write("*")
            sys.stdout.flush()
        return "".join(chars)
    else:
        import tty
        import termios
        console.print(f"{label}: ", end="")
        fd = sys.stdin.fileno()
        old = termios.tcgetattr(fd)
        chars = []
        try:
            tty.setraw(fd)
            while True:
                ch = sys.stdin.read(1)
                if ch in ("\r", "\n"):
                    sys.stdout.write("\n")
                    sys.stdout.flush()
                    break
                if ch == "\x03":
                    raise KeyboardInterrupt
                if ch in ("\x08", "\x7f"):
                    if chars:
                        chars.pop()
                        sys.stdout.write("\b \b")
                        sys.stdout.flush()
                    continue
                chars.append(ch)
                sys.stdout.write("*")
                sys.stdout.flush()
        finally:
            termios.tcsetattr(fd, termios.TCSADRAIN, old)
        return "".join(chars)


def _to_local(iso_str: str) -> str:
    """Convert an ISO 8601 UTC timestamp to a local time string."""
    from datetime import datetime, timezone
    try:
        dt = datetime.fromisoformat(iso_str)
        local_dt = dt.astimezone()
        return local_dt.strftime("%Y-%m-%d %H:%M:%S")
    except (ValueError, TypeError):
        return iso_str


def _fmt_duration(seconds: float) -> str:
    """Format seconds as human-readable duration."""
    s = max(0, round(seconds))
    if s < 60:
        return f"{s}s"
    m, s = divmod(s, 60)
    if m < 60:
        return f"{m}m {s}s"
    h, m = divmod(m, 60)
    return f"{h}h {m}m"


def _fmt_bytes(n: float) -> str:
    """Format bytes as a human-readable size."""
    n = max(0, n)
    if n < 1024:
        return f"{n:.0f} B"
    n /= 1024
    if n < 1024:
        return f"{n:.1f} KB"
    n /= 1024
    if n < 1024:
        return f"{n:.1f} MB"
    n /= 1024
    return f"{n:.1f} GB"


def _fmt_bytes_precise(n: float) -> str:
    """Format bytes with extra precision to distinguish from a rounded neighbor."""
    n = max(0, n)
    if n < 1024:
        return f"{n:.0f} B"
    n /= 1024
    if n < 1024:
        return f"{n:.2f} KB"
    n /= 1024
    if n < 1024:
        return f"{n:.2f} MB"
    n /= 1024
    return f"{n:.2f} GB"


def print_quota(q: dict) -> None:
    """Print quota info to the console."""
    max_rt = q.get("max_monthly_runtime", 0)
    used = q.get("monthly_runtime_used", 0)
    remaining = q.get("monthly_runtime_remaining", 0)
    pct = (used / max_rt * 100) if max_rt else 0
    rt_color = "green" if pct < 75 else ("yellow" if pct < 90 else "red")

    max_st = q.get("max_monthly_storage", 0)
    st_used = q.get("storage_used", 0)
    st_remaining = max(0, max_st - st_used)
    st_pct = (st_used / max_st * 100) if max_st else 0
    st_color = "green" if st_pct < 75 else ("yellow" if st_pct < 90 else "red")

    console.print(f"  Concurrent tasks: {q.get('max_concurrent_runs', '-')}")
    console.print(f"  Tasks/analysis:   {q.get('max_tasks_per_analysis', '-')}")
    console.print(f"  Monthly runtime:  [{rt_color}]{_fmt_duration(used)}[/{rt_color}] / {_fmt_duration(max_rt)} ({pct:.0f}% used)")
    console.print(f"  Runtime left:     {_fmt_duration(remaining)}")
    console.print(f"  Storage:          [{st_color}]{_fmt_bytes(st_used)}[/{st_color}] / {_fmt_bytes(max_st)} ({st_pct:.0f}% used)")
    st_left_str = _fmt_bytes(st_remaining)
    if st_left_str == _fmt_bytes(max_st) and st_remaining < max_st:
        st_left_str = _fmt_bytes_precise(st_remaining)
    console.print(f"  Storage left:     {st_left_str}")


app = typer.Typer(
    help="Account management.",
)


def _is_logged_in() -> bool:
    creds = config.load_credentials()
    return bool(creds and creds.get("access_token"))


def _print_auth_help() -> None:
    logged_in = _is_logged_in()
    console.print("[bold]ops auth[/bold] — Account management\n")

    if logged_in:
        creds = config.load_credentials() or {}
        console.print(f"  Logged in as [green]{creds.get('email', '')}[/green]\n")
        console.print("[bold]Commands:[/bold]\n")
        console.print("  [bold]ops auth whoami[/bold]            Show account details")
        console.print("  [bold]ops auth change-password[/bold]   Change your password")
        console.print("  [bold]ops auth logout[/bold]            Log out")
    else:
        console.print("  Not logged in.\n")
        console.print("[bold]Commands:[/bold]\n")
        console.print("  [bold]ops auth signup[/bold]            Create a new account")
        console.print("  [bold]ops auth login[/bold]             Log in")
        console.print("  [bold]ops auth confirm[/bold]           Verify your email")
        console.print("  [bold]ops auth resend-code[/bold]       Resend verification code")
        console.print("  [bold]ops auth forgot-password[/bold]   Request a password reset")
        console.print("  [bold]ops auth reset-password[/bold]    Reset password with code")

    console.print()
    console.print("[dim]Run any command with --help for more details.[/dim]")


@app.callback(invoke_without_command=True)
def _auth_callback(ctx: typer.Context) -> None:
    if ctx.invoked_subcommand is None:
        _print_auth_help()
        raise typer.Exit(0)


@app.command()
def signup(email: Optional[str] = typer.Option(None, "--email", "-e")):
    """Create a new account."""
    api.require_no_login()
    if not email:
        email = typer.prompt("Email")
    password = _ask_password()
    confirm_pw = _ask_password("Confirm password")
    if password != confirm_pw:
        console.print("[red]Passwords do not match.[/red]")
        raise typer.Exit(1)

    try:
        r = api.post("/auth/signup", {"email": email, "password": password}, auth=False)
        console.print(f"[green]{r.get('message', 'Account created.')}[/green]")
        if r.get("destination"):
            console.print(f"Code sent to [bold]{r['destination']}[/bold]")
    except api.ApiError as e:
        console.print(f"[red]{e.message}[/red]")
        raise typer.Exit(1)


@app.command()
def confirm(
    email: Optional[str] = typer.Option(None, "--email", "-e"),
    code: Optional[str] = typer.Option(None, "--code", "-c"),
):
    """Verify your email with the code sent to your inbox."""
    api.require_no_login()
    if not email:
        email = typer.prompt("Email")
    if not code:
        code = typer.prompt("Verification code")

    try:
        r = api.post("/auth/confirm", {"email": email, "code": code}, auth=False)
        console.print(f"[green]{r.get('message', 'Email verified.')}[/green]")
    except api.ApiError as e:
        console.print(f"[red]{e.message}[/red]")
        raise typer.Exit(1)


@app.command("resend-code")
def resend_code(email: Optional[str] = typer.Option(None, "--email", "-e")):
    """Resend the email verification code."""
    api.require_no_login()
    if not email:
        email = typer.prompt("Email")

    try:
        r = api.post("/auth/resend-code", {"email": email}, auth=False)
        console.print(f"[green]{r.get('message', 'Code resent.')}[/green]")
    except api.ApiError as e:
        console.print(f"[red]{e.message}[/red]")
        raise typer.Exit(1)


@app.command()
def login(email: Optional[str] = typer.Option(None, "--email", "-e")):
    """Log in to your account."""
    if not email:
        email = typer.prompt("Email")
    password = _ask_password()

    try:
        from opensees_cli import __version__
        r = api.post(
            "/auth/login",
            {"email": email, "password": password, "cli_version": __version__},
            auth=False,
        )
        config.save_credentials(
            access_token=r["access_token"],
            refresh_token=r["refresh_token"],
            id_token=r.get("id_token"),
            email=email,
            is_admin=r.get("is_admin", False),
        )
        console.print(f"[green]Logged in as [bold]{email}[/bold][/green]")
    except api.ApiError as e:
        console.print(f"[red]{e.message}[/red]")
        raise typer.Exit(1)


@app.command()
def logout():
    """Log out of your account."""
    api.require_login()
    token = config.get_access_token()
    if token:
        try:
            api.post("/auth/logout", {"access_token": token}, auth=False)
        except Exception:
            pass
    config.clear_credentials()
    console.print("[green]Logged out.[/green]")


@app.command()
def status():
    """Show current login status."""
    creds = config.load_credentials()
    if not creds or not creds.get("access_token"):
        console.print("Not logged in. Run [bold]ops auth login[/bold]")
        raise typer.Exit(0)
    console.print(f"Logged in as [bold]{creds.get('email', 'unknown')}[/bold]")


@app.command()
def whoami():
    """Show your account details."""
    api.require_login()
    try:
        r = api.get("/auth/me")
    except api.ApiError as e:
        console.print(f"[red]{e.message}[/red]")
        raise typer.Exit(1)

    console.print(f"  Email:        [bold]{r.get('email', '')}[/bold]")
    console.print(f"  Admin:        {'[yellow]yes[/yellow]' if r.get('is_admin') else 'no'}")
    console.print(f"  Enabled:      {'[green]yes[/green]' if r.get('is_enabled') else '[red]no[/red]'}")
    if r.get("created_at"):
        console.print(f"  Member since: {_to_local(r['created_at'])}")
    if r.get("last_login_at"):
        console.print(f"  Last login:   {_to_local(r['last_login_at'])}")
    if r.get("last_activity_at"):
        console.print(f"  Last active:  {_to_local(r['last_activity_at'])}")
    if r.get("last_cli_version"):
        console.print(f"  CLI version:  {r['last_cli_version']}")

    q = r.get("quota")
    if q:
        console.print()
        print_quota(q)


@app.command("forgot-password")
def forgot_password(email: Optional[str] = typer.Option(None, "--email", "-e")):
    """Request a password reset code."""
    if not email:
        email = typer.prompt("Email")

    try:
        r = api.post("/auth/forgot-password", {"email": email}, auth=False)
        console.print(f"[green]{r.get('message', 'Reset code sent.')}[/green]")
    except api.ApiError as e:
        console.print(f"[red]{e.message}[/red]")
        raise typer.Exit(1)


@app.command("reset-password")
def reset_password(
    email: Optional[str] = typer.Option(None, "--email", "-e"),
    code: Optional[str] = typer.Option(None, "--code", "-c"),
):
    """Reset your password using the emailed code."""
    if not email:
        email = typer.prompt("Email")
    if not code:
        code = typer.prompt("Reset code")
    new_password = _ask_password("New password")
    confirm_pw = _ask_password("Confirm new password")
    if new_password != confirm_pw:
        console.print("[red]Passwords do not match.[/red]")
        raise typer.Exit(1)

    try:
        r = api.post(
            "/auth/reset-password",
            {"email": email, "code": code, "new_password": new_password},
            auth=False,
        )
        console.print(f"[green]{r.get('message', 'Password reset.')}[/green]")
    except api.ApiError as e:
        console.print(f"[red]{e.message}[/red]")
        raise typer.Exit(1)


@app.command("change-password")
def change_password():
    """Change your password (must be logged in)."""
    api.require_login()
    old_password = _ask_password("Current password")
    new_password = _ask_password("New password")
    confirm_pw = _ask_password("Confirm new password")
    if new_password != confirm_pw:
        console.print("[red]Passwords do not match.[/red]")
        raise typer.Exit(1)

    try:
        r = api.post("/auth/change-password", {
            "old_password": old_password,
            "new_password": new_password,
        })
        console.print(f"[green]{r.get('message', 'Password changed.')}[/green]")
    except api.ApiError as e:
        console.print(f"[red]{e.message}[/red]")
        raise typer.Exit(1)
