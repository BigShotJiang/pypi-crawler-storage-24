"""File management CLI commands."""

from pathlib import Path
from typing import List, Optional, Tuple

import typer
from rich.console import Console
from rich.progress import Progress, BarColumn, DownloadColumn, TransferSpeedColumn
from rich.table import Table

from opensees_cli import api
from opensees_cli.auth import _to_local, _fmt_bytes

console = Console()
app = typer.Typer(
    help="Manage files in your cloud file system.",
)


@app.callback(invoke_without_command=True)
def _files_callback(ctx: typer.Context) -> None:
    api.require_login()
    if ctx.invoked_subcommand is None:
        typer.echo(ctx.get_help())
        raise typer.Exit(0)


@app.command("list")
def list_files():
    """List all files in your file system."""
    try:
        r = api.get("/files/list")
    except api.ApiError as e:
        console.print(f"[red]{e.message}[/red]")
        raise typer.Exit(1)

    items = r.get("files", [])
    if not items:
        console.print("[dim]No files. Use 'ops files upload <file>' to add one.[/dim]")
        return

    table = Table(show_header=True)
    table.add_column("Path")
    table.add_column("Size", justify="right")
    table.add_column("Modified")

    for f in items:
        table.add_row(
            f["path"],
            _fmt_bytes(f["size"]),
            _to_local(f["last_modified"]) if f.get("last_modified") else "",
        )

    console.print(table)

    total = sum(f["size"] for f in items)
    console.print(f"\n  [bold]{len(items)}[/bold] files, [bold]{_fmt_bytes(total)}[/bold] total")


def _collect_upload_targets(local_path: Path, remote_prefix: Optional[str]) -> List[Tuple[Path, str]]:
    """Collect (local_file, remote_path) pairs for upload."""
    if local_path.is_file():
        target = remote_prefix or local_path.name
        return [(local_path, target)]

    if local_path.is_dir():
        prefix = remote_prefix or local_path.name
        targets: List[Tuple[Path, str]] = []
        for f in sorted(local_path.rglob("*")):
            if f.is_file():
                rel = f.relative_to(local_path)
                targets.append((f, f"{prefix}/{rel}"))
        return targets

    return []


def _upload_one(local: Path, remote: str) -> int:
    """Upload a single file. Returns bytes uploaded."""
    import httpx
    content_type = "text/x-python" if remote.endswith(".py") else "application/octet-stream"
    try:
        r = api.post("/files/upload", {"path": remote, "content_type": content_type})
    except api.ApiError as e:
        console.print(f"[red]{e.message}[/red]")
        raise

    file_bytes = local.read_bytes()
    resp = httpx.put(
        r["upload_url"],
        content=file_bytes,
        headers={"Content-Type": content_type},
        timeout=60.0,
        follow_redirects=True,
    )
    if not (200 <= resp.status_code < 300):
        raise api.ApiError(f"Upload failed (HTTP {resp.status_code})", resp.status_code)
    return len(file_bytes)


def _resolve_download_targets(files: List[dict], pattern: str) -> List[dict]:
    """Resolve file/folder pattern for downloads.

    Exact file match > folder prefix match > unique substring match.
    """
    exact = [f for f in files if f.get("path") == pattern]
    if exact:
        return exact
    folder = pattern.rstrip("/") + "/"
    folder_matches = [f for f in files if str(f.get("path", "")).startswith(folder)]
    if folder_matches:
        return folder_matches
    partial = [f for f in files if pattern in str(f.get("path", ""))]
    if len(partial) == 1:
        return partial
    if len(partial) > 1:
        console.print(f"[red]Ambiguous match for '{pattern}':[/red]")
        for f in partial:
            console.print(f"  {f.get('path', '')}")
        raise typer.Exit(1)
    return []


@app.command()
def upload(
    local_path: Path = typer.Argument(..., help="Local file or folder to upload"),
    remote_path: Optional[str] = typer.Option(None, "--as", "-a", help="Remote path or prefix (defaults to local name)"),
):
    """Upload a file or folder to your cloud file system."""
    if not local_path.exists():
        console.print(f"[red]Not found: {local_path}[/red]")
        raise typer.Exit(1)

    targets = _collect_upload_targets(local_path, remote_path)
    if not targets:
        console.print("[red]Nothing to upload.[/red]")
        raise typer.Exit(1)

    try:
        listed = api.get("/files/list")
        existing = {f["path"] for f in listed.get("files", [])}
    except api.ApiError:
        existing = set()

    conflicts = [remote for _, remote in targets if remote in existing]
    if conflicts:
        if len(conflicts) == 1:
            console.print(f"[yellow]File already exists: {conflicts[0]}[/yellow]")
        else:
            console.print(f"[yellow]{len(conflicts)} file(s) already exist:[/yellow]")
            for c in conflicts:
                console.print(f"  {c}")
        if not typer.confirm("Overwrite?"):
            console.print("[dim]Cancelled.[/dim]")
            raise typer.Exit(0)

    total_bytes = sum(f.stat().st_size for f, _ in targets)
    multi = len(targets) > 1

    with Progress(
        "[progress.description]{task.description}",
        BarColumn(),
        DownloadColumn(),
        TransferSpeedColumn(),
        console=console,
        disable=(total_bytes < 100 * 1024 and not multi),
    ) as progress:
        overall = progress.add_task("Total", total=total_bytes) if multi else None
        for local, remote in targets:
            fsize = local.stat().st_size
            task = progress.add_task(remote, total=fsize)
            try:
                _upload_one(local, remote)
                progress.advance(task, fsize)
                if overall is not None:
                    progress.advance(overall, fsize)
            except Exception as e:
                console.print(f"[red]Failed to upload {remote}: {e}[/red]")
                if not multi:
                    raise typer.Exit(1)
                continue

    if multi:
        console.print(f"[green]Uploaded {len(targets)} files ({_fmt_bytes(total_bytes)})[/green]")
    else:
        console.print(f"[green]Uploaded {targets[0][1]} ({_fmt_bytes(total_bytes)})[/green]")


@app.command()
def download(
    remote_path: str = typer.Argument(..., help="Remote file path to download"),
    output: Optional[Path] = typer.Option(None, "--output", "-o", help="Local output path (defaults to filename)"),
):
    """Download a file or folder from your cloud file system."""
    try:
        listed = api.get("/files/list")
    except api.ApiError as e:
        console.print(f"[red]{e.message}[/red]")
        raise typer.Exit(1)

    files = listed.get("files", [])
    targets = _resolve_download_targets(files, remote_path)
    if not targets:
        console.print(f"[red]File not found: {remote_path}[/red]")
        raise typer.Exit(1)

    import httpx
    multi = len(targets) > 1
    total_bytes = sum(int(f.get("size", 0)) for f in targets)

    # For folder/multi downloads, output is treated as a directory root.
    if multi:
        out_root = output or Path(".")
    else:
        if output is None:
            out_root = Path(Path(targets[0]["path"]).name)
        elif output.exists() and output.is_dir():
            out_root = output / Path(targets[0]["path"]).name
        else:
            out_root = output

    try:
        with Progress(
            "[progress.description]{task.description}",
            BarColumn(),
            DownloadColumn(),
            TransferSpeedColumn(),
            console=console,
            disable=(total_bytes < 100 * 1024 and not multi),
        ) as progress:
            overall = progress.add_task("Total", total=total_bytes) if multi else None
            for f in targets:
                fpath = str(f.get("path", ""))
                size = int(f.get("size", 0))
                try:
                    dl = api.get("/files/download", {"path": fpath})
                except api.ApiError as e:
                    console.print(f"[red]Failed to get download URL for {fpath}: {e.message}[/red]")
                    continue

                if multi:
                    local = out_root / fpath
                else:
                    local = out_root
                local.parent.mkdir(parents=True, exist_ok=True)

                task = progress.add_task(fpath, total=size or None)
                try:
                    with httpx.stream("GET", dl["download_url"], timeout=60.0, follow_redirects=True) as stream:
                        stream.raise_for_status()
                        with open(local, "wb") as out:
                            for chunk in stream.iter_bytes(chunk_size=8192):
                                out.write(chunk)
                                progress.advance(task, len(chunk))
                                if overall is not None:
                                    progress.advance(overall, len(chunk))
                except Exception as e:
                    console.print(f"[red]Download failed for {fpath}: {e}[/red]")
                    continue
    except Exception as e:
        console.print(f"[red]Download failed: {e}[/red]")
        raise typer.Exit(1)

    if multi:
        console.print(f"[green]Downloaded {len(targets)} files to {out_root}[/green]")
    else:
        console.print(f"[green]Downloaded {targets[0]['path']} -> {out_root} ({_fmt_bytes(out_root.stat().st_size)})[/green]")


@app.command()
def delete(
    remote_path: str = typer.Argument(..., help="Remote file or folder path to delete"),
):
    """Delete a file or folder from your cloud file system."""
    try:
        listed = api.get("/files/list")
    except api.ApiError as e:
        console.print(f"[red]{e.message}[/red]")
        raise typer.Exit(1)

    files = listed.get("files", [])
    targets = _resolve_download_targets(files, remote_path)
    if not targets:
        console.print(f"[red]File not found: {remote_path}[/red]")
        raise typer.Exit(1)

    total = len(targets)
    if total > 1:
        confirm = typer.confirm(f"Delete {total} files under '{remote_path}'?")
        if not confirm:
            console.print("[dim]Cancelled.[/dim]")
            raise typer.Exit(0)

    deleted = 0
    with Progress(
        "[progress.description]{task.description}",
        BarColumn(),
        console=console,
        disable=(total == 1),
    ) as progress:
        task = progress.add_task("Deleting", total=total)
        for f in targets:
            fpath = str(f.get("path", ""))
            try:
                api.post("/files/delete", {"path": fpath})
                deleted += 1
            except api.ApiError as e:
                console.print(f"[red]Failed to delete {fpath}: {e.message}[/red]")
            finally:
                progress.advance(task, 1)

    if total == 1 and deleted == 1:
        console.print(f"[green]Deleted {targets[0]['path']}[/green]")
    else:
        console.print(f"[green]Deleted {deleted}/{total} file(s)[/green]")
