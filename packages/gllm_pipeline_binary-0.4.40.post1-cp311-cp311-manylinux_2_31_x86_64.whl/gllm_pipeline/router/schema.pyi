from enum import StrEnum

class ContentType(StrEnum):
    """Enumeration of supported content types for router utterances."""
    BASE64: str
    URL: str
    PLAINTEXT: str
