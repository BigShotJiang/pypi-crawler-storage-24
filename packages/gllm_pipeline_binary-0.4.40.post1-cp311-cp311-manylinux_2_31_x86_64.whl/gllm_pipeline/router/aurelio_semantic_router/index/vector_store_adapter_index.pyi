import numpy as np
from gllm_core.schema.chunk import Chunk as Chunk
from gllm_datastore.vector_data_store.vector_data_store import BaseVectorDataStore
from gllm_pipeline.router.aurelio_semantic_router.index.aurelio_index import BaseAurelioIndex as BaseAurelioIndex
from gllm_pipeline.router.schema import ContentType as ContentType
from semantic_router import Route
from typing import Any, TypeVar

ROUTE_PAYLOAD_KEY: str
UTTERANCE_PAYLOAD_KEY: str
CONTENT_TYPE_KEY: str
DEFAULT_FETCH_LIMIT: int
T = TypeVar('T')

class VectorStoreAdapterIndex(BaseAurelioIndex):
    """A vector store-backed implementation of BaseAurelioIndex for use with AurelioSemanticRouter.

    This index performs similarity search over a backend vector store to retrieve relevant
    route payloads. The vector store must implement the BaseVectorDataStore interface and support
    async methods for querying by vector and filtering by metadata.

    Attributes:
        index (BaseVectorDataStore): The vector store instance used for retrieval.
    """
    index: BaseVectorDataStore
    def __init__(self, index: BaseVectorDataStore, **kwargs: Any) -> None:
        """Initialize the VectorStoreAdapterIndex.

        Args:
            index (BaseVectorDataStore): The vector store instance used for retrieval.
            **kwargs (Any): Additional keyword arguments forwarded to the BaseAurelioIndex.
        """
    def __len__(self) -> int:
        """Returns the total number of vectors in the index.

        Returns:
            int: The total number of vectors stored in the underlying index.
        """
    def add(self, embeddings: list[list[float]], routes: list[str], utterances: list[str | bytes], function_schemas: list[dict[str, Any]] | None = None, metadata_list: list[dict[str, Any]] | None = None) -> None:
        """Add embeddings to the index.

        Args:
            embeddings (list[list[float]]): Embeddings of the utterances.
            routes (list[str]): List of route names.
            utterances (list[str | bytes]): List of utterances (text, URLs, or bytes).
            function_schemas (list[dict[str, Any]] | None): List of function schemas to add to the index.
                Kept for interface compatibility but not used.
            metadata_list (list[dict[str, Any]] | None): List of metadata to add to the index.
                Kept for interface compatibility but not used.

        Raises:
            AssertionError: If routes, utterances, and embeddings have different lengths.
        """
    def get_routes(self, retrieval_params: dict[str, Any] | None = None) -> list[Route]:
        """Retrieves all routes and their corresponding utterances from the vector store.

        Returns the original utterances (e.g., URLs) for proper comparison during auto-sync.
        If a routes cache is set, returns the cached version instead of querying the store.

        Args:
            retrieval_params (dict[str, Any] | None): Parameters for the retrieval query. Defaults to None

        Returns:
            list[Route]: A list of Aurelio Route objects.
        """
    def query(self, vector: np.ndarray, top_k: int = 5, route_filter: list[str] | None = None, retrieval_params: dict | None = None, min_similarity: float = 0.0) -> tuple[np.ndarray, list[str]]:
        """Performs a similarity query using the provided vector, optionally filtering by route.

        Args:
            vector (np.ndarray): Query vector to search against stored vectors.
            top_k (int, optional): Maximum number of top matching results to return. Defaults to 5.
            route_filter (list[str] | None, optional): List of route names to filter
                the search results by. If None, all routes are considered. Defaults to None.
            retrieval_params (dict | None, optional): Filter parameters to narrow the search. Defaults to None.
            min_similarity (float, optional): Minimum similarity score threshold for results. Defaults to 0.0.

        Returns:
            tuple[np.ndarray, list[str]]: A tuple containing a NumPy array of similarity scores
                and a list of corresponding route names for each match.
        """
    def set_local_routes(self, routes: list[Route]) -> None:
        """Sets the routes cache to avoid async queries during sync operations.

        Args:
            routes (list[Route]): A list of Route objects.
        """
    def is_ready(self) -> bool:
        """Checks if the index is ready to be used.

        This is a mandatory method to be implemented from `BaseAurelioIndex`.

        Returns:
            bool: True if the index has one or more vectors; False otherwise.
        """
    async def ais_ready(self) -> bool:
        """Checks if the index is ready to be used in async.

        Returns:
            bool: True if the index has one or more vectors; False otherwise.
        """
