# runtime inspector
## tools
- get process stack
- get cuda kernel function name

# debugger
## ideology
- gather information from info provider
- if possible, try to figure out workable version and compare with it
- simplify
  - use simple code to reproduce it, and figure out way to reproduce quicker
  - disable optimization components to see if it is related to optimization
- 怀疑谁，就disable谁

# info provider
- where can get info:
    - code repo: test, example, code, git history, readme
    - web search: blog, paper, stackoverflow, github
