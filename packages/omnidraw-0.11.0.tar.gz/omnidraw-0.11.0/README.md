# OmniDraw

**The drawing engine built for AI.** OmniDraw lets your AI assistant create, edit, and export images — right from the chat.

[![PyPI](https://img.shields.io/pypi/v/omnidraw)](https://pypi.org/project/omnidraw/)
[![License: MIT](https://img.shields.io/badge/license-MIT-blue.svg)](https://github.com/timtiger/omnidraw/blob/main/LICENSE)

## Install

```bash
pip install omnidraw
```

**Supported platforms:** Windows (x64), macOS (Apple Silicon), Linux (x64).

## Quick start

1. Install OmniDraw:

```bash
pip install omnidraw
```

2. Add to your MCP client config (Cursor, Claude Desktop, etc.):

```json
{
  "mcpServers": {
    "omnidraw": {
      "command": "omnidraw"
    }
  }
}
```

3. Reload your MCP client — done! Ask your AI to draw something.

## What it does

OmniDraw is an MCP (Model Context Protocol) server that gives AI assistants a full drawing toolkit:

- **Shapes & text** — rectangles, ellipses, lines, arrows, polygons, text boxes
- **Brush engine** — strokes, fills, erasing, scatter, smudge, wet brush mixing
- **Effects** — gradients, shadows, blur, clipping masks, ink diffusion, paper grain
- **Layers** — create, select, set opacity, toggle visibility
- **Projects** — save/load `.omnidraw` project files with full undo history
- **Assets** — import images once, reuse across compositions (Pro)
- **Export** — PNG, JPEG, WebP with optional supersampling (Pro)

## Free vs Pro

The free tier covers the core drawing workflow. [Upgrade to Pro](https://omnidraw.vercel.app/pricing) for:

- Unlimited compositions (free: 2)
- Reusable image assets
- Project save/open
- High-resolution supersampling export

## Links

- **Website:** [omnidraw.vercel.app](https://omnidraw.vercel.app)
- **Pricing:** [omnidraw.vercel.app/pricing](https://omnidraw.vercel.app/pricing)
- **Install guide:** [omnidraw.vercel.app/docs/install](https://omnidraw.vercel.app/docs/install)
- **Examples:** [omnidraw.vercel.app/examples](https://omnidraw.vercel.app/examples)
- **Source:** [github.com/timtiger/omnidraw](https://github.com/timtiger/omnidraw)

## How it works

This Python package is a thin launcher that bundles a prebuilt Rust binary. When you run `omnidraw`, it starts the Rust MCP server which communicates with your AI client over stdio.

### Diagnostics

```bash
omnidraw --print-binary-path
omnidraw --launcher-diagnostics
```

### Environment variables

| Variable | Description |
|----------|-------------|
| `OMNIDRAW_BIN` | Override the bundled binary path at runtime |
| `OMNIDRAW_LICENSE_KEY` | Pro license key (from [omnidraw.vercel.app/pricing](https://omnidraw.vercel.app/pricing)) |

## License

MIT
