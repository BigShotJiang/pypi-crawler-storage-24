"""
Top-level package exports.

Important: keep this module lightweight. Some environments may want to import
submodules (e.g. `libre_alpha.proto.data_entry_pb2`) without having the full
crypto stack installed (dependencies like coincurve/pycryptodome, etc). We therefore lazily import the heavy
client on attribute access.
"""

from __future__ import annotations

from typing import Any

__all__ = ["LibreAlphaClient", "initialize", "libre", "upload_data"]


def __getattr__(name: str) -> Any:  # pragma: no cover
    if name in ("LibreAlphaClient", "initialize", "libre"):
        from .client import LibreAlphaClient, initialize, libre

        return {"LibreAlphaClient": LibreAlphaClient, "initialize": initialize, "libre": libre}[name]
    if name == "upload_data":
        from .history_upload import upload_data

        return upload_data
    raise AttributeError(name)

