# setup.py

from setuptools import setup, find_packages

setup(
    name="libre-alpha",  # PyPI distribution name
    version="0.1.9",    # Package version
    author="capybaralabs",
    author_email="donny@capybaralabs.xyz",
    description="Libre Alpha Python SDK for interacting with gRPC-based backend",
    long_description=open("README.md", encoding="utf-8").read(),  # Read README.md as PyPI description
    long_description_content_type="text/markdown",
    url="https://github.com/capybaralabs-xyz/Liberal_Alpha",  # Repository URL
    packages=find_packages(exclude=["tests", "tests.*"]),
    include_package_data=True,                                   # Include non-py files like proto/*.proto
    install_requires=[
        # service_pb2_grpc.py is kept compatible with grpcio 1.70.0+ for Python 3.8 support.
        "grpcio>=1.70.0,<2",
        # service_pb2.py is kept compatible with protobuf 5.29.x for Python 3.8 support.
        "protobuf>=5.29.0,<6",
        "requests>=2.20.0",
        "coincurve>=13.0.0",
        "pycryptodome>=3.9.0",
        "websockets>=8.0.0",
    ],

    entry_points={
        "console_scripts": [
            "libre_alpha=libre_alpha.client:main",  # CLI command 'libre_alpha' calls libre_alpha/client.py:main()
        ],
    },
    classifiers=[
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.7",  # Add Python 3.7 support
        "Programming Language :: Python :: 3.8",  # Add Python 3.8 support
        "Programming Language :: Python :: 3.9",  # Add Python 3.9 support
        "Programming Language :: Python :: 3.10",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.8",  # Lower Python requirement to 3.7
)
