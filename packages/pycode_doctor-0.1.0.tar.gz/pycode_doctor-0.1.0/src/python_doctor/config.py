"""Configuration loading from pyproject.toml."""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path

import tomllib

from python_doctor.models import Category

DEFAULT_WEIGHTS: dict[str, int] = {
    "quality": 25,
    "types": 20,
    "security": 20,
    "complexity": 15,
    "dead_code": 10,
    "dependencies": 10,
}

DEFAULT_THRESHOLDS: dict[str, int] = {
    "healthy": 75,
    "needs_work": 50,
}

# Map config weight keys to Category enum
WEIGHT_KEY_TO_CATEGORY: dict[str, Category] = {
    "quality": Category.QUALITY,
    "types": Category.TYPE_SAFETY,
    "security": Category.SECURITY,
    "complexity": Category.COMPLEXITY,
    "dead_code": Category.DEAD_CODE,
    "dependencies": Category.DEPENDENCIES,
}


@dataclass
class DoctorConfig:
    """Resolved configuration for a python-doctor run."""

    weights: dict[str, int] = field(default_factory=lambda: dict(DEFAULT_WEIGHTS))
    thresholds: dict[str, int] = field(default_factory=lambda: dict(DEFAULT_THRESHOLDS))
    ignore_rules: list[str] = field(default_factory=list)
    ignore_files: list[str] = field(default_factory=list)
    timeout: int = 60  # seconds, per analyzer
    min_confidence: int = 80  # Vulture confidence threshold


def load_config(project_root: Path) -> DoctorConfig:
    """Load [tool.python-doctor] from pyproject.toml, with defaults.

    Config discovery: looks for pyproject.toml in project_root,
    then walks up parent directories (matching Ruff/mypy behavior).
    """
    config_path = _find_pyproject(project_root)
    if config_path is None:
        return DoctorConfig()

    try:
        with open(config_path, "rb") as f:
            data = tomllib.load(f)
    except (OSError, tomllib.TOMLDecodeError):
        return DoctorConfig()

    user_config = data.get("tool", {}).get("python-doctor", {})
    if not user_config:
        return DoctorConfig()

    return DoctorConfig(
        weights=user_config.get("weights", dict(DEFAULT_WEIGHTS)),
        thresholds=user_config.get("thresholds", dict(DEFAULT_THRESHOLDS)),
        ignore_rules=user_config.get("ignore", {}).get("rules", []),
        ignore_files=user_config.get("ignore", {}).get("files", []),
        timeout=user_config.get("timeout", 60),
        min_confidence=user_config.get("min_confidence", 80),
    )


def _find_pyproject(start: Path) -> Path | None:
    """Walk up from start directory to find pyproject.toml."""
    current = start.resolve()
    while True:
        candidate = current / "pyproject.toml"
        if candidate.is_file():
            return candidate
        parent = current.parent
        if parent == current:
            return None
        current = parent
