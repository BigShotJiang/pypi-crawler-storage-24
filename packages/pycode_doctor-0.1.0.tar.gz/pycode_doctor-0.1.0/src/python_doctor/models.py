"""Core data models for python-doctor.

Every analyzer produces list[Diagnostic]. The scoring engine, CLI formatter,
JSON serializer, and MCP server all consume these types.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path


class Severity(Enum):
    """Diagnostic severity levels."""

    ERROR = "error"
    WARNING = "warning"
    INFO = "info"


class Category(Enum):
    """Analysis categories that map to scored dimensions."""

    QUALITY = "quality"
    TYPE_SAFETY = "type_safety"
    SECURITY = "security"
    COMPLEXITY = "complexity"
    DEAD_CODE = "dead_code"
    DEPENDENCIES = "dependencies"


@dataclass(frozen=True)
class Diagnostic:
    """A single finding from an analyzer.

    This is the universal exchange type. Every analyzer produces these,
    every consumer (scoring, formatting, MCP) reads them.
    """

    file_path: Path
    line: int
    column: int
    severity: Severity
    rule_id: str  # e.g., "S101", "E501", "C901", "mypy-return-value"
    tool: str  # e.g., "ruff", "mypy", "bandit", "radon", "vulture"
    category: Category
    message: str
    fix: str | None = None  # Suggested remediation text
    help_url: str | None = None  # URL to rule documentation
    end_line: int | None = None
    end_column: int | None = None


@dataclass
class CategoryScore:
    """Score for a single analysis category."""

    category: Category
    score: float  # 0.0 - 100.0
    weight: int  # Configured weight (0-100)
    issue_count: int
    error_count: int = 0
    warning_count: int = 0
    details: str = ""  # Human-readable summary, e.g. "8 errors, 15 warnings"
    status: str = "scored"  # scored, partial
    coverage_note: str = ""


@dataclass
class CategoryCoverage:
    """Coverage metadata for a single category."""

    category: Category
    status: str  # scored, partial, unavailable, skipped_by_user
    analyzers: list[str] = field(default_factory=list)
    reason: str = ""


@dataclass
class CoverageInfo:
    """Explains how complete an analysis run was."""

    profile: str
    confidence: str  # full, partial, limited
    requested_categories: list[Category] = field(default_factory=list)
    scored_categories: list[Category] = field(default_factory=list)
    category_coverage: list[CategoryCoverage] = field(default_factory=list)
    analyzers_used: list[str] = field(default_factory=list)
    analyzers_missing: list[str] = field(default_factory=list)
    analyzers_optional_unavailable: list[str] = field(default_factory=list)
    partial_reasons: list[str] = field(default_factory=list)
    provenance: list[str] = field(default_factory=list)


@dataclass
class ProjectInfo:
    """Metadata about the analyzed project."""

    python_version: str | None
    framework: str | None  # "django-5.1", "fastapi-0.115", "flask-3.1", None
    total_files: int
    total_lines: int
    packages: list[str] = field(default_factory=list)


@dataclass
class HealthReport:
    """Complete analysis result -- the top-level return type."""

    score: float  # 0.0 - 100.0 weighted overall
    label: str  # "Healthy", "Needs work", "Critical"
    category_scores: list[CategoryScore]
    diagnostics: list[Diagnostic]
    project: ProjectInfo
    duration_ms: int
    analyzers_used: list[str] = field(default_factory=list)
    analyzers_skipped: list[str] = field(default_factory=list)
    cache_stats: dict[str, int] | None = None  # hits, misses, hit_rate_pct
    coverage: CoverageInfo | None = None
