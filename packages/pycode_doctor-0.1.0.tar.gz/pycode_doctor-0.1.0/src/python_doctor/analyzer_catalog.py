"""Analyzer metadata and category mapping."""

from __future__ import annotations

from dataclasses import dataclass, field

from python_doctor.models import Category


@dataclass(frozen=True)
class AnalyzerInfo:
    """Static metadata about a known analyzer."""

    name: str
    categories: frozenset[Category]
    default_enabled: bool = True
    optional: bool = False
    requires_network: bool = False
    project_wide: bool = False
    profiles: frozenset[str] = field(
        default_factory=lambda: frozenset({"quick", "default", "full"})
    )


ANALYZER_CATALOG: dict[str, AnalyzerInfo] = {
    "ruff": AnalyzerInfo(
        name="ruff",
        categories=frozenset(
            {
                Category.QUALITY,
                Category.SECURITY,
                Category.COMPLEXITY,
                Category.DEAD_CODE,
            }
        ),
        profiles=frozenset({"quick", "default", "full"}),
    ),
    "mypy": AnalyzerInfo(
        name="mypy",
        categories=frozenset({Category.TYPE_SAFETY}),
        profiles=frozenset({"default", "full"}),
        project_wide=True,
    ),
    "bandit": AnalyzerInfo(
        name="bandit",
        categories=frozenset({Category.SECURITY}),
        profiles=frozenset({"default", "full"}),
    ),
    "radon": AnalyzerInfo(
        name="radon",
        categories=frozenset({Category.COMPLEXITY}),
        profiles=frozenset({"default", "full"}),
    ),
    "vulture": AnalyzerInfo(
        name="vulture",
        categories=frozenset({Category.DEAD_CODE}),
        profiles=frozenset({"default", "full"}),
        project_wide=True,
    ),
    "deptry": AnalyzerInfo(
        name="deptry",
        categories=frozenset({Category.DEPENDENCIES}),
        profiles=frozenset({"quick", "default", "full"}),
        project_wide=True,
    ),
    "dependency-vulns": AnalyzerInfo(
        name="dependency-vulns",
        categories=frozenset({Category.DEPENDENCIES}),
        default_enabled=False,
        optional=True,
        requires_network=True,
        project_wide=True,
        profiles=frozenset({"full"}),
    ),
    "detect-secrets": AnalyzerInfo(
        name="detect-secrets",
        categories=frozenset({Category.SECURITY}),
        default_enabled=False,
        optional=True,
        profiles=frozenset({"full"}),
    ),
    "basedpyright": AnalyzerInfo(
        name="basedpyright",
        categories=frozenset({Category.TYPE_SAFETY}),
        default_enabled=False,
        optional=True,
        project_wide=True,
        profiles=frozenset({"full"}),
    ),
    "typos": AnalyzerInfo(
        name="typos",
        categories=frozenset({Category.QUALITY}),
        default_enabled=False,
        optional=True,
        profiles=frozenset({"full"}),
    ),
}


def get_analyzer_info(name: str) -> AnalyzerInfo | None:
    """Return catalog metadata for an analyzer name."""
    return ANALYZER_CATALOG.get(name)
