"""CLI entry point for python-doctor.

Uses Click with invoke_without_command=True so that `python-doctor .`
runs the default scan, while `python-doctor mcp install` and
`python-doctor install-skill` work as subcommands.
"""

from __future__ import annotations

import asyncio
import sys
from pathlib import Path

import click
from rich.console import Console

from python_doctor import __version__
from python_doctor.models import Category
from python_doctor.plan import (
    PROFILE_DEFAULT,
    PROFILE_FULL,
    PROFILE_QUICK,
    TYPE_BACKEND_AUTO,
    TYPE_BACKEND_BASEDPYRIGHT,
    TYPE_BACKEND_MYPY,
    build_scan_plan,
    parse_categories,
)

err_console = Console(stderr=True)


class _SubcommandFirstGroup(click.Group):
    """Click group that recognises subcommands before consuming PATH.

    Without this, ``python-doctor install-skill`` would feed
    ``install-skill`` to the positional PATH argument and never
    dispatch the subcommand.  We override :meth:`parse_args` to
    peek at the first non-option token and, if it matches a known
    command name, strip any default PATH value so Click routes
    correctly.
    """

    def parse_args(self, ctx: click.Context, args: list[str]) -> list[str]:
        """Rewrite args so subcommand names aren't swallowed by PATH."""
        # Find the first non-option token
        for token in args:
            if token.startswith("-"):
                continue
            if token in self.commands:
                # Insert an explicit default for PATH so the arg
                # isn't consumed by the subcommand name.
                args = [".", *args]
                break
            # First non-option is NOT a command → let Click handle normally
            break
        return super().parse_args(ctx, args)


@click.group(
    cls=_SubcommandFirstGroup,
    invoke_without_command=True,
    context_settings={"allow_interspersed_args": True},
)
@click.argument(
    "path",
    default=".",
    required=False,
    type=click.Path(),
)
@click.option(
    "--json",
    "json_output",
    is_flag=True,
    help="Output full results as JSON.",
)
@click.option(
    "--score",
    "score_only",
    is_flag=True,
    help="Output only the numeric score.",
)
@click.option(
    "--verbose",
    "-v",
    is_flag=True,
    help="Show all issues with file:line.",
)
@click.option(
    "--diff",
    "diff_base",
    default=None,
    is_eager=False,
    flag_value="main",
    is_flag=False,
    help="Only analyze files changed vs BASE (default: main).",
)
@click.option(
    "--fail-under",
    type=float,
    default=None,
    help="Exit 1 if score is below SCORE.",
)
@click.option(
    "--profile",
    type=click.Choice([PROFILE_QUICK, PROFILE_DEFAULT, PROFILE_FULL]),
    default=PROFILE_DEFAULT,
    help="Scan profile: quick, default, or full.",
)
@click.option(
    "--only",
    "only_categories",
    default=None,
    help="Only run these categories (comma-separated).",
)
@click.option(
    "--skip",
    "skip_categories",
    default=None,
    help="Skip these categories (comma-separated).",
)
@click.option(
    "--quick",
    is_flag=True,
    help="Compatibility alias for --profile quick.",
)
@click.option(
    "--no-lint",
    is_flag=True,
    help="Skip linting (Ruff).",
)
@click.option(
    "--no-typecheck",
    is_flag=True,
    help="Skip type checking (mypy).",
)
@click.option(
    "--no-security",
    is_flag=True,
    help="Skip security scanning (Bandit).",
)
@click.option(
    "--no-complexity",
    is_flag=True,
    help="Skip complexity analysis (Radon).",
)
@click.option(
    "--no-dead-code",
    is_flag=True,
    help="Skip dead code detection (Vulture).",
)
@click.option(
    "--type-backend",
    type=click.Choice(
        [TYPE_BACKEND_AUTO, TYPE_BACKEND_MYPY, TYPE_BACKEND_BASEDPYRIGHT]
    ),
    default=TYPE_BACKEND_AUTO,
    help="Type checking backend: auto (default), mypy, or basedpyright.",
)
@click.option(
    "--fix",
    is_flag=True,
    help="Apply safe Ruff fixes before rescanning.",
)
@click.option(
    "--show-fixes",
    is_flag=True,
    help="Show fix suggestions inline.",
)
@click.option(
    "--config",
    "config_path",
    type=click.Path(exists=True),
    default=None,
    help="Path to pyproject.toml.",
)
@click.option(
    "--no-cache",
    "no_cache",
    is_flag=True,
    help="Skip the cache and force a fresh analysis.",
)
@click.option(
    "--clear-cache",
    "clear_cache",
    is_flag=True,
    help="Delete all cached results and exit.",
)
@click.option(
    "--badge",
    is_flag=True,
    help="Output a shields.io badge URL for the score.",
)
@click.option(
    "--mcp",
    is_flag=True,
    help="Start as MCP server (stdio transport).",
)
@click.version_option(version=__version__, prog_name="python-doctor")
@click.pass_context
def main(
    ctx: click.Context,
    path: str,
    json_output: bool,
    score_only: bool,
    verbose: bool,
    diff_base: str | None,
    fail_under: float | None,
    profile: str,
    only_categories: str | None,
    skip_categories: str | None,
    quick: bool,
    no_lint: bool,
    no_typecheck: bool,
    no_security: bool,
    no_complexity: bool,
    no_dead_code: bool,
    type_backend: str,
    fix: bool,
    show_fixes: bool,
    config_path: str | None,
    no_cache: bool,
    clear_cache: bool,
    badge: bool,
    mcp: bool,
) -> None:
    """Python Doctor -- fast, local-first Python code health checker.

    Analyzes a Python project and produces a 0-100 health score with
    categorized diagnostics covering code quality, type safety,
    security, complexity, and dead code.

    \b
    Examples:
        python-doctor .                   # Scan current directory
        python-doctor src/ --verbose      # Scan src/ with all issues
        python-doctor . --score           # Just the number (for CI)
        python-doctor . --diff develop    # Only changed files
        python-doctor . --fail-under 70   # Exit 1 if score < 70
        python-doctor . --profile quick   # Fast feedback
    """
    ctx.ensure_object(dict)

    # MCP server mode -- hand off immediately
    if mcp:
        from python_doctor.mcp.server import start_mcp_server

        start_mcp_server()
        return  # Server runs until killed

    # Clear cache mode -- delete all cached results and exit
    if clear_cache:
        from python_doctor.cache import AnalysisCache

        resolved = Path(path).resolve()
        cache = AnalysisCache(resolved, enabled=True)
        count = cache.clear()
        err_console.print(f"[green]Cleared {count} cached entries.[/green]")
        return

    # If a subcommand was invoked, let it handle things
    if ctx.invoked_subcommand is not None:
        return

    # Validate that PATH exists (we can't use click.Path(exists=True)
    # because it would reject subcommand names like "mcp" and "install-skill")
    resolved = Path(path).resolve()
    if not resolved.exists():
        raise click.BadParameter(
            f"Path '{path}' does not exist.",
            param_hint="'PATH'",
        )

    # --score wins over --json (simpler request)
    if score_only:
        json_output = False

    only_set = parse_categories(only_categories)
    skip_set = set(parse_categories(skip_categories) or set())

    # Compatibility aliases for the old --no-* flags
    if no_lint:
        skip_set.add(Category.QUALITY)
    if no_typecheck:
        skip_set.add(Category.TYPE_SAFETY)
    if no_security:
        skip_set.add(Category.SECURITY)
    if no_complexity:
        skip_set.add(Category.COMPLEXITY)
    if no_dead_code:
        skip_set.add(Category.DEAD_CODE)

    plan = build_scan_plan(
        profile=profile,
        only_categories=only_set,
        skip_categories=frozenset(skip_set),
        quick=quick,
        include_optional=profile == PROFILE_FULL,
        apply_fixes=fix,
        show_fix_suggestions=show_fixes,
        diff_mode=diff_base is not None,
        type_backend=type_backend,
    )

    # Build analyzer skip set from the selected categories/profile
    skip_analyzers: set[str] = set()
    if Category.QUALITY not in plan.categories:
        skip_analyzers.add("typos")
    if Category.TYPE_SAFETY not in plan.categories:
        skip_analyzers.update({"mypy", "basedpyright"})
    else:
        # Enforce type backend mutual exclusion
        if plan.type_backend == TYPE_BACKEND_MYPY:
            skip_analyzers.add("basedpyright")
        elif plan.type_backend == TYPE_BACKEND_BASEDPYRIGHT:
            skip_analyzers.add("mypy")
    if Category.SECURITY not in plan.categories:
        skip_analyzers.update({"bandit", "detect-secrets"})
    if Category.COMPLEXITY not in plan.categories:
        skip_analyzers.add("radon")
    if Category.DEAD_CODE not in plan.categories:
        skip_analyzers.add("vulture")
    if Category.DEPENDENCIES not in plan.categories:
        skip_analyzers.update({"deptry", "dependency-vulns", "pip-audit"})
    if (
        Category.QUALITY not in plan.categories
        and Category.SECURITY not in plan.categories
        and Category.COMPLEXITY not in plan.categories
        and Category.DEAD_CODE not in plan.categories
    ):
        skip_analyzers.add("ruff")
    if plan.profile == PROFILE_QUICK:
        skip_analyzers.update({"mypy", "bandit", "radon", "vulture"})

    # Load config
    from python_doctor.config import load_config

    project_root = Path(path).resolve()
    if config_path:
        config = load_config(Path(config_path).parent)
    else:
        config = load_config(project_root)

    if fix:
        _apply_safe_ruff_fixes(project_root)

    # Discover files
    files: list[Path]
    total_project_files: int

    if diff_base is not None:
        from python_doctor.diff import get_changed_files

        files = get_changed_files(project_root, base=diff_base)
        from python_doctor.discovery import discover_python_files

        total_project_files = len(
            discover_python_files(project_root, config.ignore_files)
        )
        # Skip Vulture in diff mode -- dead code detection
        # on a subset is misleading
        skip_analyzers.add("vulture")
    else:
        from python_doctor.discovery import discover_python_files

        files = discover_python_files(project_root, config.ignore_files)
        total_project_files = len(files)

    # Suppress progress for --score, --json, and --badge
    quiet = score_only or json_output or badge

    # Run analysis
    from python_doctor.runner import run_analysis

    report = asyncio.run(
        run_analysis(
            project_root=project_root,
            config=config,
            files=files,
            skip_analyzers=skip_analyzers,
            quiet=quiet,
            no_cache=no_cache,
            plan=plan,
            diff_base=diff_base,
        )
    )

    # Output
    if score_only:
        click.echo(f"{report.score:.0f}")
    elif badge:
        from python_doctor.formatters.badge import generate_badge_url

        click.echo(generate_badge_url(report.score))
    elif json_output:
        from python_doctor.formatters.json_fmt import format_json

        click.echo(format_json(report))
    else:
        from python_doctor.formatters.human import print_report

        print_report(
            report,
            verbose=verbose,
            show_fix=show_fixes,
            diff_mode=diff_base is not None,
            changed_file_count=len(files) if diff_base else None,
            total_file_count=total_project_files,
        )

    # Exit code
    if fail_under is not None and report.score < fail_under:
        sys.exit(1)


def _apply_safe_ruff_fixes(project_root: Path) -> None:
    """Apply safe Ruff fixes before rescanning."""
    import subprocess

    try:
        ruff_bin = "ruff"
        subprocess.run(  # noqa: S603
            [ruff_bin, "check", "--fix", "--no-unsafe-fixes", str(project_root)],
            check=False,
            cwd=project_root,
            capture_output=True,
            text=True,
        )
    except FileNotFoundError:
        err_console.print(
            "[yellow]Ruff is not installed, so no fixes were applied.[/yellow]"
        )


@main.group("mcp")
def mcp_cmd() -> None:
    """MCP server management commands."""


@mcp_cmd.command("install")
@click.option(
    "--editor",
    type=click.Choice(["auto", "claude-code", "cursor", "vscode"]),
    default="auto",
    help="Target editor (default: auto-detect).",
)
def mcp_install(editor: str) -> None:
    """Install python-doctor as an MCP server for your AI coding agent."""
    from python_doctor.mcp.installer import install_mcp_config

    err_console.print("[bold]Installing python-doctor MCP server...[/bold]")
    installed = install_mcp_config()
    if installed:
        err_console.print(
            f"\n[green]Installed to {len(installed)} location(s).[/green]"
        )
        err_console.print("[dim]Restart your editor to activate.[/dim]")
    else:
        err_console.print(
            "[yellow]No editor configs found. "
            "Created .mcp.json for Claude Code.[/yellow]"
        )


@main.command("install-skill")
@click.option(
    "--agent",
    "-a",
    multiple=True,
    help="Specific agent(s) to install for (e.g., claude-code, cursor).",
)
@click.option(
    "--project",
    "-p",
    is_flag=True,
    help="Also install to .agents/python-doctor/ in current directory.",
)
@click.option(
    "--force",
    "-f",
    is_flag=True,
    help="Overwrite existing skill files.",
)
@click.option(
    "--list-agents",
    is_flag=True,
    help="List all supported agents and their directories.",
)
def install_skill_cmd(
    agent: tuple[str, ...],
    project: bool,
    force: bool,
    list_agents: bool,
) -> None:
    """Install python-doctor skill files for AI coding agents."""
    from rich.table import Table

    from python_doctor.skills.agents import detect_installed_agents, get_agent_targets

    if list_agents:
        table = Table(title="Supported AI Coding Agents", show_header=True)
        table.add_column("Agent", style="cyan")
        table.add_column("Directory", style="dim")
        table.add_column("Detected", justify="center")

        all_targets = get_agent_targets()
        detected = {t.name for t in detect_installed_agents()}

        for target in all_targets:
            is_detected = "\u2713" if target.name in detected else ""
            if target.is_append and target.global_rules_file:
                dir_str = f"{target.global_rules_file} (append)"
            else:
                dir_str = str(target.skill_dir)
            table.add_row(target.display_name, dir_str, is_detected)

        err_console.print(table)
        return

    from python_doctor.skills.installer import install_skill

    agents_list = list(agent) if agent else None
    install_skill(agents=agents_list, project_level=project, force=force)


@main.command("uninstall-skill")
@click.option(
    "--agent",
    "-a",
    multiple=True,
    help="Specific agent(s) to uninstall from.",
)
def uninstall_skill_cmd(agent: tuple[str, ...]) -> None:
    """Remove installed python-doctor skill files."""
    from python_doctor.skills.installer import uninstall_skill

    agents_list = list(agent) if agent else None
    uninstall_skill(agents=agents_list)
