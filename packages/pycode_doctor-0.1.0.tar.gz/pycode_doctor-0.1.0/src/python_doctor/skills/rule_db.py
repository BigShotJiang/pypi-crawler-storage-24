"""Rule documentation database.

Lookup table mapping rule IDs to documentation, examples, and fix patterns.
Powers the MCP explain_rule tool, SKILL.md generation, and verbose CLI output.
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class RuleDoc:
    """Documentation for a single rule."""

    rule_id: str
    name: str
    tool: str  # "ruff", "mypy", "bandit", "radon", "vulture", "deptry"
    category: str  # quality, security, complexity, type_safety, dead_code, dependencies
    severity: str  # error, warning, info
    description: str
    example_bad: str
    example_good: str
    fix: str
    help_url: str | None = None


# ---------------------------------------------------------------------------
# Top 40+ rules covering all 6 categories
# ---------------------------------------------------------------------------

RULE_DATABASE: dict[str, RuleDoc] = {
    # ── Code Quality (Ruff / Pyflakes) ──────────────────────────────
    "F401": RuleDoc(
        rule_id="F401",
        name="unused-import",
        tool="ruff",
        category="quality",
        severity="error",
        description=(
            "An imported module or name is not used anywhere in the file. "
            "Unused imports add clutter, increase load time, and can mask "
            "circular import issues."
        ),
        example_bad="import os\nimport sys\n\ndef main():\n    print(sys.argv)",
        example_good="import sys\n\ndef main():\n    print(sys.argv)",
        fix="Remove the unused import. Auto-fixable: `ruff check --select F401 --fix`.",
        help_url="https://docs.astral.sh/ruff/rules/unused-import",
    ),
    "F811": RuleDoc(
        rule_id="F811",
        name="redefined-unused-name",
        tool="ruff",
        category="quality",
        severity="error",
        description=(
            "A name is defined twice in the same scope, "
            "and the first definition is unused."
        ),
        example_bad="import os\n\ndef os():\n    pass",
        example_good="def list_files():\n    pass",
        fix="Rename the function/variable or remove the shadowed import.",
        help_url="https://docs.astral.sh/ruff/rules/redefined-while-unused",
    ),
    "F821": RuleDoc(
        rule_id="F821",
        name="undefined-name",
        tool="ruff",
        category="quality",
        severity="error",
        description=(
            "A name is used but not defined in the current scope. "
            "This will cause a NameError at runtime."
        ),
        example_bad="def greet():\n    return mesage  # typo",
        example_good='def greet():\n    message = "hello"\n    return message',
        fix="Define the variable, fix the typo, or add the missing import.",
        help_url="https://docs.astral.sh/ruff/rules/undefined-name",
    ),
    "F841": RuleDoc(
        rule_id="F841",
        name="unused-variable",
        tool="ruff",
        category="quality",
        severity="error",
        description="A local variable is assigned but never used in the function.",
        example_bad="def process():\n    result = compute()\n    return True",
        example_good=(
            "def process():\n    compute()  # if side effects needed\n    return True"
        ),
        fix=(
            "Remove the assignment or use the variable. "
            "Prefix with `_` if intentional."
        ),
        help_url="https://docs.astral.sh/ruff/rules/unused-variable",
    ),
    "E501": RuleDoc(
        rule_id="E501",
        name="line-too-long",
        tool="ruff",
        category="quality",
        severity="warning",
        description=(
            "A line exceeds the configured maximum length (default 88 characters)."
        ),
        example_bad=(
            "result = some_function(very_long_argument_name, "
            "another_long_argument, yet_another_one, final_arg)"
        ),
        example_good=(
            "result = some_function(\n"
            "    very_long_argument_name,\n"
            "    another_long_argument,\n"
            "    yet_another_one,\n"
            "    final_arg,\n)"
        ),
        fix=(
            "Break the line at logical points. "
            "Use parentheses for implicit line continuation."
        ),
        help_url="https://docs.astral.sh/ruff/rules/line-too-long",
    ),
    "E711": RuleDoc(
        rule_id="E711",
        name="none-comparison",
        tool="ruff",
        category="quality",
        severity="warning",
        description=(
            "Comparison to None should use `is` or `is not`, not `==` or `!=`."
        ),
        example_bad="if result == None:\n    handle_missing()",
        example_good="if result is None:\n    handle_missing()",
        fix="Replace `== None` with `is None` and `!= None` with `is not None`.",
        help_url="https://docs.astral.sh/ruff/rules/none-comparison",
    ),
    "E712": RuleDoc(
        rule_id="E712",
        name="true-false-comparison",
        tool="ruff",
        category="quality",
        severity="warning",
        description=(
            "Comparison to True/False should use `is` or implicit boolean test."
        ),
        example_bad="if active == True:\n    process()",
        example_good="if active:\n    process()",
        fix=(
            "Use `if value:` instead of `if value == True:`. "
            "Use `if not value:` instead of `if value == False:`."
        ),
        help_url="https://docs.astral.sh/ruff/rules/true-false-comparison",
    ),
    "W291": RuleDoc(
        rule_id="W291",
        name="trailing-whitespace",
        tool="ruff",
        category="quality",
        severity="info",
        description="Trailing whitespace at the end of a line.",
        example_bad='def greet():   \n    return "hello"',
        example_good='def greet():\n    return "hello"',
        fix="Remove trailing whitespace. Auto-fixable with `ruff format`.",
        help_url="https://docs.astral.sh/ruff/rules/trailing-whitespace",
    ),
    "I001": RuleDoc(
        rule_id="I001",
        name="unsorted-imports",
        tool="ruff",
        category="quality",
        severity="info",
        description=(
            "Import statements are not sorted according to isort conventions."
        ),
        example_bad="import sys\nimport os\nfrom pathlib import Path\nimport json",
        example_good="import json\nimport os\nimport sys\nfrom pathlib import Path",
        fix="Sort imports. Auto-fixable: `ruff check --select I --fix`.",
        help_url="https://docs.astral.sh/ruff/rules/unsorted-imports",
    ),
    "N801": RuleDoc(
        rule_id="N801",
        name="invalid-class-name",
        tool="ruff",
        category="quality",
        severity="warning",
        description=("Class name does not follow CapWords (PascalCase) convention."),
        example_bad="class my_processor:\n    pass",
        example_good="class MyProcessor:\n    pass",
        fix="Rename the class to use CapWords convention.",
        help_url="https://docs.astral.sh/ruff/rules/invalid-class-name",
    ),
    "N802": RuleDoc(
        rule_id="N802",
        name="invalid-function-name",
        tool="ruff",
        category="quality",
        severity="warning",
        description="Function name does not follow snake_case convention.",
        example_bad="def ProcessData():\n    pass",
        example_good="def process_data():\n    pass",
        fix="Rename the function to use snake_case.",
        help_url="https://docs.astral.sh/ruff/rules/invalid-function-name",
    ),
    "UP035": RuleDoc(
        rule_id="UP035",
        name="deprecated-import",
        tool="ruff",
        category="quality",
        severity="warning",
        description=(
            "Import from `typing` that has been superseded by a built-in "
            "equivalent in Python 3.9+/3.10+."
        ),
        example_bad="from typing import Dict, List, Optional",
        example_good=(
            "# Use built-in generics and X | Y union syntax\n"
            "def process(items: list[str], data: dict[str, int], "
            "value: str | None) -> None:\n    pass"
        ),
        fix=(
            "Replace `typing.List` with `list`, `typing.Dict` with `dict`, "
            "`typing.Optional[X]` with `X | None`. Auto-fixable: "
            "`ruff check --select UP035 --fix`."
        ),
        help_url="https://docs.astral.sh/ruff/rules/deprecated-import",
    ),
    "B006": RuleDoc(
        rule_id="B006",
        name="mutable-argument-default",
        tool="ruff",
        category="quality",
        severity="error",
        description=(
            "A mutable value (list, dict, set) is used as a default argument. "
            "This is shared across all calls and causes subtle bugs."
        ),
        example_bad=(
            "def add_item(item, items=[]):\n"
            "    items.append(item)\n"
            "    return items"
        ),
        example_good=(
            "def add_item(item, items=None):\n"
            "    if items is None:\n"
            "        items = []\n"
            "    items.append(item)\n"
            "    return items"
        ),
        fix="Use `None` as default and initialize inside the function body.",
        help_url="https://docs.astral.sh/ruff/rules/mutable-argument-default",
    ),
    "B007": RuleDoc(
        rule_id="B007",
        name="unused-loop-control-variable",
        tool="ruff",
        category="quality",
        severity="warning",
        description="A `for` loop variable is not used inside the loop body.",
        example_bad="for item in range(10):\n    do_something()",
        example_good="for _item in range(10):\n    do_something()",
        fix=("Prefix the variable with `_` to indicate it's intentionally unused."),
        help_url="https://docs.astral.sh/ruff/rules/unused-loop-control-variable",
    ),
    "SIM108": RuleDoc(
        rule_id="SIM108",
        name="if-else-block-instead-of-if-exp",
        tool="ruff",
        category="quality",
        severity="info",
        description=(
            "An if/else block that assigns to the same variable "
            "can be simplified to a ternary expression."
        ),
        example_bad="if condition:\n    x = a\nelse:\n    x = b",
        example_good="x = a if condition else b",
        fix="Use a ternary expression. Auto-fixable.",
        help_url="https://docs.astral.sh/ruff/rules/if-else-block-instead-of-if-exp",
    ),
    "ERA001": RuleDoc(
        rule_id="ERA001",
        name="commented-out-code",
        tool="ruff",
        category="dead_code",
        severity="warning",
        description=(
            "Found commented-out Python code. This clutters the codebase "
            "and should be removed (it's in version control history)."
        ),
        example_bad=(
            "# result = old_function(data)\n"
            "# if result:\n"
            "#     process(result)\n"
            "new_result = new_function(data)"
        ),
        example_good="new_result = new_function(data)",
        fix=(
            "Remove commented-out code. "
            "Use version control to recover old code if needed."
        ),
        help_url="https://docs.astral.sh/ruff/rules/commented-out-code",
    ),
    # ── Security (Ruff flake8-bandit / Bandit) ──────────────────────
    "S101": RuleDoc(
        rule_id="S101",
        name="assert-used",
        tool="ruff/bandit",
        category="security",
        severity="error",
        description=(
            "Use of `assert` detected. Assert statements are removed when Python "
            "runs with the -O (optimize) flag, making them unreliable for security "
            "checks, input validation, or access control."
        ),
        example_bad='assert user.is_admin, "Not authorized"',
        example_good=(
            "if not user.is_admin:\n" '    raise PermissionError("Not authorized")'
        ),
        fix="Replace `assert` with an explicit `if`/`raise` statement.",
        help_url="https://docs.astral.sh/ruff/rules/assert",
    ),
    "S102": RuleDoc(
        rule_id="S102",
        name="exec-used",
        tool="ruff/bandit",
        category="security",
        severity="error",
        description=(
            "Use of `exec()` detected. This can execute arbitrary code "
            "and is a common injection vector."
        ),
        example_bad="exec(user_input)",
        example_good=(
            "import ast\n"
            'tree = ast.parse(code, mode="eval")\n'
            "# Validate AST before use"
        ),
        fix=(
            "Avoid `exec()`. Use `ast.parse()` with validation "
            "if dynamic code execution is needed."
        ),
        help_url="https://docs.astral.sh/ruff/rules/exec-builtin",
    ),
    "S105": RuleDoc(
        rule_id="S105",
        name="hardcoded-password-string",
        tool="ruff/bandit",
        category="security",
        severity="error",
        description=(
            "A string that appears to be a password is hardcoded in source code."
        ),
        example_bad='DB_PASSWORD = "super_secret_123"',
        example_good='import os\nDB_PASSWORD = os.environ["DB_PASSWORD"]',
        fix="Load secrets from environment variables or a secrets manager.",
        help_url="https://docs.astral.sh/ruff/rules/hardcoded-password-string",
    ),
    "S108": RuleDoc(
        rule_id="S108",
        name="hardcoded-temp-file",
        tool="ruff/bandit",
        category="security",
        severity="warning",
        description=(
            "Use of a hardcoded temporary file path (e.g., `/tmp/`). "
            "These can be subject to race conditions and symlink attacks."
        ),
        example_bad='f = open("/tmp/myapp_data.txt", "w")',
        example_good=(
            "import tempfile\n"
            'with tempfile.NamedTemporaryFile(mode="w") as f:\n'
            "    f.write(data)"
        ),
        fix="Use the `tempfile` module for secure temporary file creation.",
        help_url="https://docs.astral.sh/ruff/rules/hardcoded-temp-file",
    ),
    "S110": RuleDoc(
        rule_id="S110",
        name="try-except-pass",
        tool="ruff/bandit",
        category="security",
        severity="warning",
        description=(
            "A bare `except: pass` silently swallows all exceptions, "
            "hiding errors and potential security issues."
        ),
        example_bad="try:\n    do_something()\nexcept:\n    pass",
        example_good=(
            "try:\n    do_something()\n"
            "except SpecificError as e:\n"
            '    logger.warning("Operation failed: %s", e)'
        ),
        fix=("Catch specific exceptions and handle or log them appropriately."),
        help_url="https://docs.astral.sh/ruff/rules/try-except-pass",
    ),
    "S301": RuleDoc(
        rule_id="S301",
        name="suspicious-pickle-usage",
        tool="ruff/bandit",
        category="security",
        severity="error",
        description=(
            "Use of `pickle.load()` or `pickle.loads()`. "
            "Pickle can execute arbitrary code during deserialization."
        ),
        example_bad='import pickle\ndata = pickle.load(open("data.pkl", "rb"))',
        example_good=(
            'import json\nwith open("data.json") as f:\n' "    data = json.load(f)"
        ),
        fix=(
            "Use `json`, `msgpack`, or other safe serialization formats. "
            "Only unpickle from fully trusted sources."
        ),
        help_url="https://docs.astral.sh/ruff/rules/suspicious-pickle-usage",
    ),
    "S602": RuleDoc(
        rule_id="S602",
        name="subprocess-popen-with-shell-equals-true",
        tool="ruff/bandit",
        category="security",
        severity="error",
        description=(
            "Subprocess called with `shell=True`. This passes the command "
            "through the system shell, enabling injection attacks."
        ),
        example_bad=(
            'subprocess.call(f"grep {user_input} /var/log/app.log", shell=True)'
        ),
        example_good=(
            'subprocess.run(["grep", user_input, "/var/log/app.log"], check=True)'
        ),
        fix=(
            "Use a list of arguments instead of a shell string. "
            "Never interpolate user input into shell commands."
        ),
        help_url=(
            "https://docs.astral.sh/ruff/rules/"
            "subprocess-popen-with-shell-equals-true"
        ),
    ),
    "S608": RuleDoc(
        rule_id="S608",
        name="hardcoded-sql-expression",
        tool="ruff/bandit",
        category="security",
        severity="error",
        description=(
            "SQL query constructed with string formatting. "
            "This is a SQL injection vulnerability."
        ),
        example_bad="query = f\"SELECT * FROM users WHERE name = '{name}'\"",
        example_good=('cursor.execute("SELECT * FROM users WHERE name = %s", (name,))'),
        fix="Use parameterized queries with placeholders.",
        help_url="https://docs.astral.sh/ruff/rules/hardcoded-sql-expression",
    ),
    # ── Complexity (Radon) ──────────────────────────────────────────
    "C901": RuleDoc(
        rule_id="C901",
        name="complex-structure",
        tool="ruff/radon",
        category="complexity",
        severity="warning",
        description=(
            "Function has a cyclomatic complexity exceeding the threshold "
            "(default: 10). High complexity correlates with more bugs "
            "and harder maintenance."
        ),
        example_bad=(
            "def process(data, mode, flags):\n"
            '    if mode == "a":\n'
            '        if flags.get("x"):\n'
            "            for item in data:\n"
            "                if item.valid:\n"
            "                    if item.type == 1:\n"
            "                        ..."
        ),
        example_good=(
            "def process(data, mode, flags):\n"
            "    handler = HANDLERS[mode]\n"
            "    return handler(data, flags)\n\n"
            "def _handle_mode_a(data, flags):\n"
            "    items = [i for i in data if i.valid]\n"
            "    return _process_items(items, flags)"
        ),
        fix=(
            "Extract helper functions, use early returns, "
            "replace nested conditions with guard clauses or dispatch tables."
        ),
        help_url="https://docs.astral.sh/ruff/rules/complex-structure",
    ),
    # ── Type Safety (mypy) ──────────────────────────────────────────
    "mypy-return-value": RuleDoc(
        rule_id="mypy-return-value",
        name="incompatible-return-value",
        tool="mypy",
        category="type_safety",
        severity="error",
        description=(
            "Function returns a value incompatible with its declared return type."
        ),
        example_bad="def get_name() -> str:\n    return 42",
        example_good='def get_name() -> str:\n    return "hello"',
        fix="Ensure the returned value matches the declared return type.",
    ),
    "mypy-assignment": RuleDoc(
        rule_id="mypy-assignment",
        name="incompatible-assignment",
        tool="mypy",
        category="type_safety",
        severity="error",
        description=(
            "A value is assigned to a variable with an incompatible " "type annotation."
        ),
        example_bad="name: str = 42",
        example_good='name: str = "hello"\ncount: int = 42',
        fix="Ensure the assigned value matches the variable's type annotation.",
    ),
    "mypy-arg-type": RuleDoc(
        rule_id="mypy-arg-type",
        name="incompatible-argument-type",
        tool="mypy",
        category="type_safety",
        severity="error",
        description=("An argument passed to a function has an incompatible type."),
        example_bad=("def greet(name: str) -> None:\n    print(name)\n\ngreet(42)"),
        example_good='greet("world")',
        fix=(
            "Pass a value of the correct type, "
            "or update the function's type annotations."
        ),
    ),
    "mypy-name-defined": RuleDoc(
        rule_id="mypy-name-defined",
        name="name-not-defined",
        tool="mypy",
        category="type_safety",
        severity="error",
        description=(
            "A name is used that mypy cannot resolve "
            "(undefined variable, missing import, or type stub)."
        ),
        example_bad=("def process(data: DataFrame) -> None:  # Missing import"),
        example_good=(
            "from pandas import DataFrame\n\n" "def process(data: DataFrame) -> None:"
        ),
        fix=(
            "Add the missing import or install type stubs "
            "(e.g., `pip install pandas-stubs`)."
        ),
    ),
    "mypy-override": RuleDoc(
        rule_id="mypy-override",
        name="incompatible-override",
        tool="mypy",
        category="type_safety",
        severity="error",
        description=(
            "A method override has a signature incompatible "
            "with the base class method."
        ),
        example_bad=(
            "class Base:\n"
            "    def process(self, data: str) -> None: ...\n\n"
            "class Sub(Base):\n"
            "    def process(self, data: int) -> None: ..."
        ),
        example_good=(
            "class Sub(Base):\n"
            "    def process(self, data: str) -> None:\n"
            "        ..."
        ),
        fix=(
            "Ensure the overriding method's signature "
            "is compatible with the base class."
        ),
    ),
    # ── Dead Code (Vulture) ─────────────────────────────────────────
    "vulture-unused-function": RuleDoc(
        rule_id="vulture-unused-function",
        name="unused-function",
        tool="vulture",
        category="dead_code",
        severity="warning",
        description=(
            "A function is defined but never called anywhere "
            "in the analyzed codebase."
        ),
        example_bad=(
            "def old_handler(request):\n"
            '    return render(request, "old.html")\n\n'
            "# Never called"
        ),
        example_good=(
            "# Remove the function, or add to vulture whitelist " "if used dynamically"
        ),
        fix=(
            "Remove the function. If it's used dynamically "
            "(signal handlers, decorators), add to whitelist."
        ),
    ),
    "vulture-unused-variable": RuleDoc(
        rule_id="vulture-unused-variable",
        name="unused-variable",
        tool="vulture",
        category="dead_code",
        severity="warning",
        description="A variable is assigned but never read.",
        example_bad=(
            "def process():\n"
            "    temp = compute_intermediate()\n"
            "    return final_result()"
        ),
        example_good=(
            "def process():\n"
            "    _temp = compute_intermediate()  "
            "# _ prefix if side effects needed\n"
            "    return final_result()"
        ),
        fix=(
            "Remove the variable, or prefix with `_` "
            "if the assignment has intentional side effects."
        ),
    ),
    "vulture-unused-class": RuleDoc(
        rule_id="vulture-unused-class",
        name="unused-class",
        tool="vulture",
        category="dead_code",
        severity="warning",
        description=("A class is defined but never instantiated or referenced."),
        example_bad=(
            "class LegacyProcessor:\n"
            '    """No longer used since v2 migration."""\n'
            "    pass"
        ),
        example_good=("# Remove the class or keep in a separate legacy module"),
        fix=(
            "Remove the class if it's truly unused. "
            "Check for dynamic usage (metaclasses, registries) before removing."
        ),
    ),
    # ── Dependencies ────────────────────────────────────────────────
    "DEP001": RuleDoc(
        rule_id="DEP001",
        name="missing-dependency",
        tool="deptry",
        category="dependencies",
        severity="error",
        description=(
            "A module is imported in source code but not declared "
            "as a dependency in pyproject.toml or requirements."
        ),
        example_bad=("# pyproject.toml lists: requests\n# Code has: import httpx"),
        example_good="# Add httpx to pyproject.toml dependencies",
        fix=(
            "Add the package to your project's `[project.dependencies]` "
            "in pyproject.toml."
        ),
    ),
    "DEP002": RuleDoc(
        rule_id="DEP002",
        name="unused-dependency",
        tool="deptry",
        category="dependencies",
        severity="warning",
        description=(
            "A package is declared as a dependency but never imported "
            "in the source code."
        ),
        example_bad=(
            '# pyproject.toml: dependencies = ["requests", "httpx"]\n'
            "# Code only imports requests"
        ),
        example_good=(
            "# Remove httpx from dependencies, "
            "or move to optional-dependencies if used in extras"
        ),
        fix=(
            "Remove the package from dependencies, "
            "or move to dev/optional dependencies."
        ),
    ),
    "DEP003": RuleDoc(
        rule_id="DEP003",
        name="transitive-dependency",
        tool="deptry",
        category="dependencies",
        severity="warning",
        description=(
            "A module is imported that's only available as a transitive "
            "(indirect) dependency. If the parent package removes it, "
            "your code breaks."
        ),
        example_bad=(
            '# You depend on "requests" which depends on "urllib3"\n'
            "# Code has: import urllib3  # transitive!"
        ),
        example_good="# Add urllib3 to your direct dependencies",
        fix="Add the package as a direct dependency in pyproject.toml.",
    ),
    "DEP004": RuleDoc(
        rule_id="DEP004",
        name="misplaced-dev-dependency",
        tool="deptry",
        category="dependencies",
        severity="warning",
        description=("A dev dependency is imported in non-test source code."),
        example_bad=(
            "# pytest is in dev dependencies\n"
            "# src/app.py: import pytest  # shouldn't be here"
        ),
        example_good="# Only import dev dependencies in tests/ directory",
        fix=(
            "Move the import to test files, or move the package "
            "to runtime dependencies if needed in production."
        ),
    ),
}


def get_rule_doc(rule_id: str) -> RuleDoc | None:
    """Look up documentation for a rule ID.

    Handles both exact matches and Bandit B-prefix aliases.
    """
    # Direct lookup
    if rule_id in RULE_DATABASE:
        return RULE_DATABASE[rule_id]

    # Bandit B-prefix -> Ruff S-prefix mapping
    if rule_id.startswith("B") and rule_id[1:].isdigit():
        ruff_id = "S" + rule_id[1:]
        if ruff_id in RULE_DATABASE:
            return RULE_DATABASE[ruff_id]

    # Mypy bracket-style -> our prefix-style mapping
    # e.g., [return-value] -> mypy-return-value
    if rule_id.startswith("[") and rule_id.endswith("]"):
        mypy_id = "mypy-" + rule_id[1:-1]
        if mypy_id in RULE_DATABASE:
            return RULE_DATABASE[mypy_id]

    return None


def explain_rule(rule_id: str) -> str:
    """Generate a human-readable explanation for a rule.

    Used by the `python_doctor_explain_rule` MCP tool.
    """
    doc = get_rule_doc(rule_id)
    if doc is None:
        return (
            f"Unknown rule: {rule_id}. "
            "This rule may not be in the documentation database yet."
        )

    lines = [
        f"## {doc.rule_id}: {doc.name}",
        "",
        f"**Tool**: {doc.tool}  ",
        f"**Category**: {doc.category}  ",
        f"**Severity**: {doc.severity}",
        "",
        doc.description,
        "",
        "### Bad (violation)",
        "```python",
        doc.example_bad,
        "```",
        "",
        "### Good (fixed)",
        "```python",
        doc.example_good,
        "```",
        "",
        "### How to fix",
        doc.fix,
    ]
    if doc.help_url:
        lines.extend(["", f"**Reference**: {doc.help_url}"])

    return "\n".join(lines)


def generate_skill_content() -> str:
    """Generate SKILL.md content from the rule database.

    This is the fallback when the bundled SKILL.md template is not available.
    Generates a complete skill file dynamically from the rule database.
    """
    sections: dict[str, list[RuleDoc]] = {}
    for doc in RULE_DATABASE.values():
        sections.setdefault(doc.category, []).append(doc)

    lines = [
        "# python-doctor Skill",
        "",
        "Python code health analyzer with 0-100 scoring.",
        "",
        "## Rules Reference",
        "",
    ]

    category_titles = {
        "quality": "Code Quality",
        "security": "Security",
        "complexity": "Complexity",
        "type_safety": "Type Safety",
        "dead_code": "Dead Code",
        "dependencies": "Dependencies",
    }

    for cat_key, title in category_titles.items():
        rules = sections.get(cat_key, [])
        if not rules:
            continue
        lines.append(f"### {title}")
        lines.append("")
        for rule in rules:
            lines.append(f"**{rule.rule_id} -- {rule.name}**: {rule.description}")
            lines.append(f"Fix: {rule.fix}")
            lines.append("")

    return "\n".join(lines)
