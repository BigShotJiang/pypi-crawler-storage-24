"""Skill system for AI coding agent integration."""
