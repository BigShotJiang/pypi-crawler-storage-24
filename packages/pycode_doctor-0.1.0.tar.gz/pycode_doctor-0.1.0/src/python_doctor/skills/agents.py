"""AI agent skill installation targets."""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path


@dataclass
class AgentTarget:
    """An AI agent's skill installation target."""

    name: str
    display_name: str
    skill_dir: Path  # Where to write SKILL.md
    agents_dir: Path | None  # Where to write AGENTS.md (if different)
    detection_dirs: list[Path] = field(default_factory=list)
    is_append: bool = False  # True for agents that append to a global file
    global_rules_file: Path | None = None  # For append-mode agents


def get_agent_targets(home: Path | None = None) -> list[AgentTarget]:
    """Return all known agent targets with resolved paths.

    Args:
        home: Override home directory (for testing). Defaults to Path.home().
    """
    if home is None:
        home = Path.home()

    return [
        AgentTarget(
            name="claude-code",
            display_name="Claude Code",
            skill_dir=home / ".claude" / "skills" / "python-doctor",
            agents_dir=None,
            detection_dirs=[home / ".claude"],
        ),
        AgentTarget(
            name="cursor",
            display_name="Cursor",
            skill_dir=home / ".cursor" / "skills" / "python-doctor",
            agents_dir=None,
            detection_dirs=[home / ".cursor"],
        ),
        AgentTarget(
            name="amp-code",
            display_name="Amp Code",
            skill_dir=home / ".config" / "amp" / "skills" / "python-doctor",
            agents_dir=None,
            detection_dirs=[home / ".config" / "amp"],
        ),
        AgentTarget(
            name="windsurf",
            display_name="Windsurf",
            skill_dir=home / ".codeium" / "windsurf" / "memories",
            agents_dir=None,
            detection_dirs=[home / ".codeium" / "windsurf"],
            is_append=True,
            global_rules_file=(
                home / ".codeium" / "windsurf" / "memories" / "global_rules.md"
            ),
        ),
        AgentTarget(
            name="gemini-cli",
            display_name="Gemini CLI",
            skill_dir=home / ".gemini" / "skills" / "python-doctor",
            agents_dir=None,
            detection_dirs=[home / ".gemini"],
        ),
        AgentTarget(
            name="codex",
            display_name="Codex",
            skill_dir=home / ".codex" / "skills" / "python-doctor",
            agents_dir=None,
            detection_dirs=[home / ".codex"],
        ),
        AgentTarget(
            name="project-level",
            display_name="Project-level (.agents/)",
            skill_dir=Path(".agents") / "python-doctor",
            agents_dir=None,
            detection_dirs=[],  # Always offered as an option, never auto-detected
        ),
    ]


def detect_installed_agents(home: Path | None = None) -> list[AgentTarget]:
    """Return agent targets where the agent appears to be installed.

    Detection: checks if any of the agent's detection_dirs exist.
    """
    targets = get_agent_targets(home)
    installed = []
    for target in targets:
        if not target.detection_dirs:
            continue  # Skip project-level (no auto-detection)
        if any(d.exists() for d in target.detection_dirs):
            installed.append(target)
    return installed
