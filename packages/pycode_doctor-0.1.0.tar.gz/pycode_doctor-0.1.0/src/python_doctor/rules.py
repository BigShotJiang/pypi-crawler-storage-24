"""Rule documentation database for python_doctor_explain_rule.

Maps common rule IDs to structured documentation including name,
tool, category, description, examples, and fix suggestions.
"""

from __future__ import annotations

# Top 50 most common rules. Expand over time.
RULE_DOCS: dict[str, dict[str, str]] = {
    # --- Quality (Ruff / Pyflakes / pycodestyle) ---
    "F401": {
        "name": "Unused import",
        "tool": "ruff (Pyflakes)",
        "category": "quality",
        "description": (
            "A module was imported but never used in the file. "
            "Unused imports add clutter, slow down startup, and can "
            "mask circular import bugs."
        ),
        "example_bad": "import os\nimport sys\n\nprint('hello')",
        "example_good": "print('hello')",
        "fix": (
            "Remove the unused import. If it's needed for re-export, "
            "add it to __all__ or use a `# noqa: F401` comment."
        ),
    },
    "F841": {
        "name": "Unused variable",
        "tool": "ruff (Pyflakes)",
        "category": "quality",
        "description": (
            "A local variable is assigned but never used. This often "
            "indicates leftover debugging code or an incomplete refactoring."
        ),
        "example_bad": "def process():\n    result = compute()\n    return 42",
        "example_good": "def process():\n    return 42",
        "fix": (
            "Remove the variable assignment, or prefix with _ to indicate "
            "intentional disuse: `_result = compute()`"
        ),
    },
    "E501": {
        "name": "Line too long",
        "tool": "ruff (pycodestyle)",
        "category": "quality",
        "description": (
            "A line exceeds the configured maximum length (default 88 "
            "characters for Ruff). Long lines hurt readability."
        ),
        "example_bad": (
            "result = some_function(argument_one, argument_two, "
            "argument_three, argument_four, argument_five, argument_six)"
        ),
        "example_good": (
            "result = some_function(\n"
            "    argument_one, argument_two, argument_three,\n"
            "    argument_four, argument_five, argument_six,\n"
            ")"
        ),
        "fix": (
            "Break the line using parentheses, backslash continuation, "
            "or refactor into intermediate variables."
        ),
    },
    "I001": {
        "name": "Unsorted imports",
        "tool": "ruff (isort)",
        "category": "quality",
        "description": (
            "Import statements are not sorted or formatted according "
            "to the isort standard. Consistent import ordering improves "
            "readability and reduces merge conflicts."
        ),
        "example_bad": "from os import path\nimport sys\nimport os",
        "example_good": "import os\nimport sys\nfrom os import path",
        "fix": "Run `ruff check --fix` to auto-sort imports.",
    },
    "E711": {
        "name": "Comparison to None",
        "tool": "ruff (pycodestyle)",
        "category": "quality",
        "description": (
            "Comparison to None should use `is` or `is not` instead of "
            "`==` or `!=`. None is a singleton, so identity checks are "
            "faster and more correct."
        ),
        "example_bad": "if x == None:\n    pass",
        "example_good": "if x is None:\n    pass",
        "fix": "Replace `== None` with `is None` and `!= None` with `is not None`.",
    },
    "UP035": {
        "name": "Deprecated import",
        "tool": "ruff (pyupgrade)",
        "category": "quality",
        "description": (
            "Importing from a deprecated module when a modern "
            "alternative exists. Keeps code compatible with future "
            "Python versions."
        ),
        "example_bad": "from typing import List, Dict",
        "example_good": "list[int]  # or dict[str, int] in Python 3.9+",
        "fix": (
            "Use built-in generic types (list, dict, set, tuple) "
            "instead of typing module."
        ),
    },
    # --- Security (Ruff flake8-bandit / Bandit) ---
    "S101": {
        "name": "Use of assert",
        "tool": "ruff (flake8-bandit) / Bandit B101",
        "category": "security",
        "description": (
            "Assert statements are removed when Python runs with the "
            "-O (optimize) flag. Never use assert for security checks, "
            "input validation, or access control."
        ),
        "example_bad": "assert user.is_admin, 'Not authorized'",
        "example_good": (
            "if not user.is_admin:\n" "    raise PermissionError('Not authorized')"
        ),
        "fix": (
            "Replace assert with an explicit if/raise statement using "
            "a specific exception type."
        ),
    },
    "S301": {
        "name": "Pickle usage",
        "tool": "ruff (flake8-bandit) / Bandit B301",
        "category": "security",
        "description": (
            "pickle.load() can execute arbitrary code during "
            "deserialization. Never load pickled data from untrusted sources."
        ),
        "example_bad": "import pickle\ndata = pickle.load(open('data.pkl', 'rb'))",
        "example_good": "import json\ndata = json.load(open('data.json'))",
        "fix": (
            "Use JSON, MessagePack, or Protocol Buffers instead of pickle. "
            "If pickle is unavoidable, use RestrictedUnpickler."
        ),
    },
    "S307": {
        "name": "Suspicious eval usage",
        "tool": "ruff (flake8-bandit) / Bandit B307",
        "category": "security",
        "description": (
            "eval() executes arbitrary Python code. If user input "
            "reaches eval(), it enables remote code execution."
        ),
        "example_bad": "result = eval(user_input)",
        "example_good": "import ast\nresult = ast.literal_eval(user_input)",
        "fix": (
            "Use ast.literal_eval() for safe evaluation of literals, "
            "or parse input explicitly."
        ),
    },
    "S602": {
        "name": "subprocess with shell=True",
        "tool": "ruff (flake8-bandit) / Bandit B602",
        "category": "security",
        "description": (
            "Using subprocess with shell=True and variable input "
            "enables shell injection attacks. An attacker could inject "
            "commands via the input."
        ),
        "example_bad": "subprocess.call(f'ls {user_input}', shell=True)",
        "example_good": "subprocess.call(['ls', user_input], shell=False)",
        "fix": (
            "Pass commands as a list (not a string) and set shell=False. "
            "Use shlex.quote() if shell=True is unavoidable."
        ),
    },
    "S608": {
        "name": "Hardcoded SQL expression",
        "tool": "ruff (flake8-bandit) / Bandit B608",
        "category": "security",
        "description": (
            "SQL query built using string formatting or concatenation. "
            "This creates SQL injection vulnerabilities when user input "
            "is included."
        ),
        "example_bad": "query = f\"SELECT * FROM users WHERE name = '{name}'\"",
        "example_good": (
            "cursor.execute(" "'SELECT * FROM users WHERE name = %s', (name,))"
        ),
        "fix": (
            "Use parameterized queries (placeholders) instead of string "
            "formatting. For ORMs, use query builder methods."
        ),
    },
    "S603": {
        "name": "subprocess call without shell",
        "tool": "ruff (flake8-bandit) / Bandit B603",
        "category": "security",
        "description": (
            "subprocess call with check for execution of untrusted input. "
            "Even without shell=True, passing unsanitized input to "
            "subprocess can be dangerous."
        ),
        "example_bad": "subprocess.run(['cmd', user_input])",
        "example_good": "subprocess.run(['cmd', validated_input], check=True)",
        "fix": (
            "Validate and sanitize all inputs before passing to subprocess. "
            "Use allowlists for accepted command arguments."
        ),
    },
    # --- Complexity ---
    "C901": {
        "name": "Function too complex",
        "tool": "ruff (mccabe)",
        "category": "complexity",
        "description": (
            "The function's cyclomatic complexity exceeds the threshold "
            "(default 10). High complexity correlates with bugs and "
            "makes code hard to test."
        ),
        "example_bad": (
            "def process(data):\n"
            "    if data.type == 'a':\n"
            "        if data.status == 1:\n"
            "            ...\n"
            "        elif data.status == 2:\n"
            "            ...\n"
            "    elif data.type == 'b':\n"
            "        ..."
        ),
        "example_good": (
            "def process(data):\n"
            "    handler = HANDLERS.get(data.type)\n"
            "    if handler:\n"
            "        return handler(data)\n"
            "    raise ValueError(f'Unknown type: {data.type}')"
        ),
        "fix": (
            "Extract conditions into helper functions, use dictionaries "
            "for dispatch, or apply the Strategy pattern."
        ),
    },
    # --- Type Safety (mypy) ---
    "arg-type": {
        "name": "Argument type mismatch",
        "tool": "mypy",
        "category": "type_safety",
        "description": (
            "A function was called with an argument of the wrong type. "
            "The actual type does not match the expected parameter type."
        ),
        "example_bad": "def greet(name: str) -> None: ...\ngreet(42)",
        "example_good": "def greet(name: str) -> None: ...\ngreet('world')",
        "fix": (
            "Pass an argument of the correct type, or update the "
            "function signature to accept the broader type."
        ),
    },
    "return-value": {
        "name": "Incompatible return value",
        "tool": "mypy",
        "category": "type_safety",
        "description": (
            "The return statement returns a value whose type is "
            "incompatible with the function's declared return type."
        ),
        "example_bad": "def get_name() -> str:\n    return None",
        "example_good": "def get_name() -> str | None:\n    return None",
        "fix": (
            "Either fix the return value to match the declared type, "
            "or broaden the return type annotation."
        ),
    },
    "assignment": {
        "name": "Incompatible assignment",
        "tool": "mypy",
        "category": "type_safety",
        "description": (
            "A value of an incompatible type is being assigned to a "
            "variable with a declared type."
        ),
        "example_bad": "x: int = 'hello'",
        "example_good": "x: int = 42",
        "fix": (
            "Assign a value of the correct type, or change the "
            "variable's type annotation."
        ),
    },
    "no-untyped-def": {
        "name": "Missing type annotation",
        "tool": "mypy",
        "category": "type_safety",
        "description": (
            "A function is defined without type annotations. In strict "
            "mode, mypy requires all functions to have type hints."
        ),
        "example_bad": "def add(a, b):\n    return a + b",
        "example_good": "def add(a: int, b: int) -> int:\n    return a + b",
        "fix": "Add type annotations to all function parameters and the return type.",
    },
    "import": {
        "name": "Cannot find module",
        "tool": "mypy",
        "category": "type_safety",
        "description": (
            "mypy cannot find the imported module. The module may not "
            "have type stubs, or the import path may be incorrect."
        ),
        "example_bad": "import nonexistent_module",
        "example_good": "import os",
        "fix": (
            "Install type stubs (e.g., `pip install types-requests`), "
            "add the module to mypy's `ignore_missing_imports`, or fix "
            "the import path."
        ),
    },
}


def get_rule_docs(rule_id: str) -> dict[str, str] | None:
    """Look up documentation for a rule ID.

    Supports direct lookup, case-insensitive matching, and
    cross-referencing between Ruff S-prefix and Bandit B-prefix rules.
    """
    # Direct lookup
    if rule_id in RULE_DOCS:
        return RULE_DOCS[rule_id]

    # Normalize: try uppercase
    upper = rule_id.upper()
    if upper in RULE_DOCS:
        return RULE_DOCS[upper]

    # Try lowercase (for mypy error codes like "arg-type")
    lower = rule_id.lower()
    if lower in RULE_DOCS:
        return RULE_DOCS[lower]

    # Cross-reference: S101 <-> B101
    if upper.startswith("S"):
        bandit_id = "B" + upper[1:]
        if bandit_id in RULE_DOCS:
            return RULE_DOCS[bandit_id]
    elif upper.startswith("B"):
        ruff_id = "S" + upper[1:]
        if ruff_id in RULE_DOCS:
            return RULE_DOCS[ruff_id]

    # Strip mypy- prefix (diagnostics use "mypy-arg-type" but docs use "arg-type")
    if rule_id.startswith("mypy-"):
        stripped = rule_id[5:]
        if stripped in RULE_DOCS:
            return RULE_DOCS[stripped]

    return None
