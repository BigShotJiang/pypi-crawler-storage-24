"""Deduplication engine for overlapping tool findings.

Primary overlap: Ruff S-prefix rules <-> Bandit B-prefix rules.
Ruff always wins because it's faster and always available.
"""

from __future__ import annotations

from pathlib import Path

from python_doctor.models import Diagnostic

# Mapping of Ruff S-prefix rules to their Bandit B-prefix equivalents.
RUFF_TO_BANDIT: dict[str, str] = {
    "S101": "B101",
    "S102": "B102",
    "S103": "B103",
    "S104": "B104",
    "S105": "B105",
    "S106": "B106",
    "S107": "B107",
    "S108": "B108",
    "S110": "B110",
    "S112": "B112",
    "S113": "B113",
    "S301": "B301",
    "S302": "B302",
    "S303": "B303",
    "S304": "B304",
    "S305": "B305",
    "S306": "B306",
    "S307": "B307",
    "S308": "B308",
    "S310": "B310",
    "S311": "B311",
    "S312": "B312",
    "S313": "B313",
    "S314": "B314",
    "S315": "B315",
    "S316": "B316",
    "S317": "B317",
    "S318": "B318",
    "S319": "B319",
    "S320": "B320",
    "S321": "B321",
    "S323": "B323",
    "S324": "B324",
    "S501": "B501",
    "S502": "B502",
    "S503": "B503",
    "S504": "B504",
    "S505": "B505",
    "S506": "B506",
    "S507": "B507",
    "S508": "B508",
    "S509": "B509",
    "S601": "B601",
    "S602": "B602",
    "S603": "B603",
    "S604": "B604",
    "S605": "B605",
    "S606": "B606",
    "S607": "B607",
    "S608": "B608",
    "S609": "B609",
    "S610": "B610",
    "S611": "B611",
    "S612": "B612",
    "S701": "B701",
    "S702": "B702",
}

# Reverse mapping for lookups
BANDIT_TO_RUFF: dict[str, str] = {v: k for k, v in RUFF_TO_BANDIT.items()}

# Tool priority order: lower index = higher priority
TOOL_PRIORITY: dict[str, int] = {
    "ruff": 0,
    "bandit": 1,
    "mypy": 2,
    "radon": 3,
    "vulture": 4,
}


def deduplicate(diagnostics: list[Diagnostic]) -> list[Diagnostic]:
    """Remove duplicate findings from overlapping tools.

    Rules:
    1. Ruff takes priority over Bandit for overlapping rules
    2. Same tool, same file, same line, same rule = deduplicate
    3. Bandit-unique rules (not in BANDIT_TO_RUFF) are never deduplicated

    Dedup key: (file_path, line, normalized_rule_id)
    """
    # Sort by tool priority -- Ruff findings are processed first
    prioritized = sorted(
        diagnostics,
        key=lambda d: TOOL_PRIORITY.get(d.tool, 99),
    )

    seen: set[tuple[Path, int, str]] = set()
    result: list[Diagnostic] = []

    for d in prioritized:
        # Normalize the rule ID so S101 and B101 map to the same key
        normalized = _normalize_rule(d.tool, d.rule_id)
        key = (d.file_path, d.line, normalized)

        if key not in seen:
            seen.add(key)
            result.append(d)

    return result


def _normalize_rule(tool: str, rule_id: str) -> str:
    """Normalize a rule ID for deduplication.

    Maps Bandit B-prefix rules to their Ruff S-prefix equivalents
    so that S101 and B101 produce the same dedup key.
    Bandit-unique rules keep their original ID.
    """
    if tool == "bandit" and rule_id in BANDIT_TO_RUFF:
        return BANDIT_TO_RUFF[rule_id]
    return rule_id
