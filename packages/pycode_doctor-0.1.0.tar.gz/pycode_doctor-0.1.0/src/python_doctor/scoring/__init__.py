"""Scoring engine -- computes health scores from diagnostics."""
