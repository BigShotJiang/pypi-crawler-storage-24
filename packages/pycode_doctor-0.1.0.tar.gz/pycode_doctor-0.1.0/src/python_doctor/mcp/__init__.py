"""MCP server for python-doctor.

Exposes python-doctor analysis tools via the Model Context Protocol
(MCP) so AI coding agents can check code quality, lint, type-check,
scan for security issues, and explain lint rules.
"""

from python_doctor.mcp.server import start_mcp_server

__all__ = ["start_mcp_server"]
