"""Framework detection using multiple confidence signals.

Detects Django, FastAPI, and Flask projects by combining several signals:
installed packages, config files, import patterns, and dependency declarations.
Each signal has a weight; a total confidence >= 0.5 activates framework-specific rules.
"""

from __future__ import annotations

import importlib.metadata
import logging
from collections.abc import Callable
from dataclasses import dataclass
from pathlib import Path

logger = logging.getLogger("python_doctor")


@dataclass
class FrameworkInfo:
    """Detected framework with version and confidence."""

    name: str  # "django", "fastapi", "flask"
    version: str | None
    confidence: float  # 0.0 - 1.0


# Directories to skip during file sampling and detection scans.
_EXCLUDED_DIRS = frozenset(
    {
        ".venv",
        "venv",
        ".env",
        "__pycache__",
        ".git",
        "node_modules",
        ".tox",
        ".mypy_cache",
        ".ruff_cache",
        "site-packages",
        ".eggs",
        "dist",
        "build",
    }
)

# Confidence threshold — below this we don't activate framework rules.
_CONFIDENCE_THRESHOLD = 0.5


def detect_framework(project_root: Path) -> FrameworkInfo | None:
    """Detect the primary web framework using multiple signals.

    Signals are weighted by reliability:
    - Installed package (strongest): +0.5
    - Config files/patterns: +0.2-0.3
    - Import analysis: +0.1
    - Dependency declarations: +0.3

    Returns None if no framework has confidence >= 0.5.
    """
    candidates: dict[str, float] = {}
    versions: dict[str, str | None] = {}

    for name, detector in _FRAMEWORK_DETECTORS.items():
        score, version = detector(project_root)
        if score > 0:
            candidates[name] = score
            versions[name] = version

    if not candidates:
        return None

    # Pick the highest-confidence framework
    best = max(candidates, key=lambda k: candidates[k])
    if candidates[best] < _CONFIDENCE_THRESHOLD:
        return None

    version = versions.get(best)
    version_str = f"{best}-{version}" if version else best
    logger.info(
        "Detected framework: %s (confidence: %.1f)", version_str, candidates[best]
    )

    return FrameworkInfo(name=best, version=version, confidence=candidates[best])


# ---------------------------------------------------------------------------
# Individual framework detectors
# ---------------------------------------------------------------------------


def _detect_django(root: Path) -> tuple[float, str | None]:
    """Detect Django project."""
    score = 0.0
    version: str | None = None

    # Signal 1: Installed package (strongest — 0.5)
    try:
        version = importlib.metadata.version("django")
        score += 0.5
    except importlib.metadata.PackageNotFoundError:
        pass

    # Signal 2: manage.py exists (0.3)
    if (root / "manage.py").exists():
        score += 0.3

    # Signal 3: settings.py pattern (0.1)
    settings_files = [f for f in root.rglob("settings.py") if not _is_excluded(f, root)]
    if settings_files:
        score += 0.1

    # Signal 4: DJANGO_SETTINGS_MODULE in any Python file (0.2)
    for py_file in _sample_py_files(root, limit=20):
        try:
            content = py_file.read_text(errors="ignore")
            if "DJANGO_SETTINGS_MODULE" in content:
                score += 0.2
                break
        except OSError:
            continue

    # Signal 5: In requirements/pyproject dependencies (0.3)
    if _in_dependency_files(root, "django"):
        score += 0.3

    # Signal 6: Import analysis (sample files) (0.1)
    if _has_imports(root, ["from django", "import django"]):
        score += 0.1

    return score, version


def _detect_fastapi(root: Path) -> tuple[float, str | None]:
    """Detect FastAPI project."""
    score = 0.0
    version: str | None = None

    # Signal 1: Installed package (0.5)
    try:
        version = importlib.metadata.version("fastapi")
        score += 0.5
    except importlib.metadata.PackageNotFoundError:
        pass

    # Signal 2: uvicorn installed (common companion) (0.2)
    try:
        importlib.metadata.version("uvicorn")
        score += 0.2
    except importlib.metadata.PackageNotFoundError:
        pass

    # Signal 3: main.py/app.py with FastAPI() (0.3)
    for name in ("main.py", "app.py", "api.py"):
        f = root / name
        if f.exists():
            try:
                content = f.read_text(errors="ignore")
                if "FastAPI()" in content or "from fastapi" in content:
                    score += 0.3
                    break
            except OSError:
                continue

    # Signal 4: In dependency files (0.3)
    if _in_dependency_files(root, "fastapi"):
        score += 0.3

    # Signal 5: Import analysis (0.1)
    if _has_imports(root, ["from fastapi", "import fastapi"]):
        score += 0.1

    return score, version


def _detect_flask(root: Path) -> tuple[float, str | None]:
    """Detect Flask project."""
    score = 0.0
    version: str | None = None

    # Signal 1: Installed package (0.5)
    try:
        version = importlib.metadata.version("flask")
        score += 0.5
    except importlib.metadata.PackageNotFoundError:
        pass

    # Signal 2: .flaskenv or .env with FLASK_APP (0.3)
    for env_file in (".flaskenv", ".env"):
        path = root / env_file
        if path.exists():
            try:
                content = path.read_text(errors="ignore")
                if "FLASK_APP" in content:
                    score += 0.3
                    break
            except OSError:
                continue

    # Signal 3: app.py with Flask(__name__) (0.3)
    for name in ("app.py", "application.py", "wsgi.py"):
        f = root / name
        if f.exists():
            try:
                content = f.read_text(errors="ignore")
                if "Flask(__name__)" in content or "from flask" in content:
                    score += 0.3
                    break
            except OSError:
                continue

    # Signal 4: In dependency files (0.3)
    if _in_dependency_files(root, "flask"):
        score += 0.3

    # Signal 5: Import analysis (0.1)
    if _has_imports(root, ["from flask", "import flask"]):
        score += 0.1

    return score, version


# ---------------------------------------------------------------------------
# Detector registry
# ---------------------------------------------------------------------------

_FRAMEWORK_DETECTORS: dict[str, Callable[[Path], tuple[float, str | None]]] = {
    "django": _detect_django,
    "fastapi": _detect_fastapi,
    "flask": _detect_flask,
}


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _is_excluded(path: Path, root: Path) -> bool:
    """Check if a path is inside an excluded directory."""
    try:
        parts = path.relative_to(root).parts
    except ValueError:
        return True
    return any(part in _EXCLUDED_DIRS for part in parts)


def _sample_py_files(root: Path, limit: int = 20) -> list[Path]:
    """Get a sample of Python files for fast analysis."""
    files: list[Path] = []
    for py_file in root.rglob("*.py"):
        if _is_excluded(py_file, root):
            continue
        files.append(py_file)
        if len(files) >= limit:
            break
    return files


def _in_dependency_files(root: Path, package: str) -> bool:
    """Check if package appears in requirements.txt or pyproject.toml."""
    pkg_lower = package.lower()

    # requirements.txt variants
    for req_name in (
        "requirements.txt",
        "requirements/base.txt",
        "requirements/main.txt",
        "requirements/prod.txt",
    ):
        req_path = root / req_name
        if req_path.exists():
            try:
                content = req_path.read_text(errors="ignore").lower()
                if pkg_lower in content:
                    return True
            except OSError:
                continue

    # pyproject.toml
    pyproject = root / "pyproject.toml"
    if pyproject.exists():
        try:
            content = pyproject.read_text(errors="ignore").lower()
            if f'"{pkg_lower}' in content or f"'{pkg_lower}" in content:
                return True
        except OSError:
            pass

    # Pipfile
    pipfile = root / "Pipfile"
    if pipfile.exists():
        try:
            content = pipfile.read_text(errors="ignore").lower()
            if pkg_lower in content:
                return True
        except OSError:
            pass

    return False


def _has_imports(root: Path, patterns: list[str]) -> bool:
    """Check if any sampled Python file imports matching patterns."""
    for py_file in _sample_py_files(root, limit=20):
        try:
            content = py_file.read_text(errors="ignore")
            for pattern in patterns:
                if pattern in content:
                    return True
        except OSError:
            continue
    return False
