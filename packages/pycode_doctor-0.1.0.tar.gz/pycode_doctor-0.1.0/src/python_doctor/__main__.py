"""Allow running as `python -m python_doctor`."""

from python_doctor.cli import main

main()
