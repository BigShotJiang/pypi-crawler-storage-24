"""Dependency source discovery and parsing."""

from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path

import tomllib


@dataclass(frozen=True)
class LockedPackage:
    """A concrete package version found in a dependency source."""

    name: str
    version: str


@dataclass(frozen=True)
class DependencySource:
    """A project dependency source, preferably lockfile-backed."""

    kind: str
    path: Path
    is_locked: bool
    packages: list[LockedPackage]


def discover_dependency_source(project_root: Path) -> DependencySource | None:
    """Discover the strongest available dependency source for a project.

    Priority: uv.lock > poetry.lock > Pipfile.lock > requirements.txt > pyproject.toml
    """
    uv_lock = project_root / "uv.lock"
    if uv_lock.is_file():
        packages = _parse_uv_lock(uv_lock)
        return DependencySource("uv-lock", uv_lock, True, packages)

    poetry_lock = project_root / "poetry.lock"
    if poetry_lock.is_file():
        packages = _parse_poetry_lock(poetry_lock)
        if packages:
            return DependencySource("poetry-lock", poetry_lock, True, packages)

    pipfile_lock = project_root / "Pipfile.lock"
    if pipfile_lock.is_file():
        packages = _parse_pipfile_lock(pipfile_lock)
        if packages:
            return DependencySource("pipfile-lock", pipfile_lock, True, packages)

    requirements = project_root / "requirements.txt"
    if requirements.is_file():
        packages = _parse_requirements(requirements)
        if packages:
            return DependencySource("requirements", requirements, True, packages)

    pyproject = project_root / "pyproject.toml"
    if pyproject.is_file():
        packages = _parse_pyproject_dependencies(pyproject)
        if packages:
            return DependencySource("pyproject", pyproject, False, packages)

    return None


def _parse_uv_lock(path: Path) -> list[LockedPackage]:
    """Parse packages from a uv.lock file."""
    with path.open("rb") as handle:
        data = tomllib.load(handle)

    packages: list[LockedPackage] = []
    raw = data.get("package", [])
    if not isinstance(raw, list):
        return packages

    for item in raw:
        if not isinstance(item, dict):
            continue
        source = item.get("source")
        if isinstance(source, dict) and source.get("virtual") == ".":
            continue

        name = item.get("name")
        version = item.get("version")
        if isinstance(name, str) and isinstance(version, str):
            packages.append(LockedPackage(name=name, version=version))

    return packages


def _parse_requirements(path: Path) -> list[LockedPackage]:
    """Parse pinned packages from requirements.txt."""
    packages: list[LockedPackage] = []
    for line in path.read_text(errors="ignore").splitlines():
        stripped = line.strip()
        if not stripped or stripped.startswith("#"):
            continue
        if "==" not in stripped:
            continue
        name, version = stripped.split("==", 1)
        name = name.strip()
        version = version.strip()
        if name and version:
            packages.append(LockedPackage(name=name, version=version))
    return packages


def _parse_pyproject_dependencies(path: Path) -> list[LockedPackage]:
    """Parse direct dependencies from pyproject.toml when no lockfile exists."""
    with path.open("rb") as handle:
        data = tomllib.load(handle)

    project = data.get("project", {})
    if not isinstance(project, dict):
        return []

    raw_dependencies = project.get("dependencies", [])
    if not isinstance(raw_dependencies, list):
        return []

    packages: list[LockedPackage] = []
    for item in raw_dependencies:
        if not isinstance(item, str):
            continue
        name = item.split(";", 1)[0].strip()
        for separator in ("==", ">=", "<=", "~=", "!=", ">", "<"):
            if separator in name:
                pkg, version = name.split(separator, 1)
                packages.append(
                    LockedPackage(name=pkg.strip(), version=version.strip())
                )
                break
        else:
            packages.append(LockedPackage(name=name, version=""))

    return packages


def _parse_poetry_lock(path: Path) -> list[LockedPackage]:
    """Parse packages from a poetry.lock file.

    poetry.lock is TOML with ``[[package]]`` entries, each having
    ``name`` and ``version`` string fields.
    """
    with path.open("rb") as handle:
        data = tomllib.load(handle)

    packages: list[LockedPackage] = []
    raw = data.get("package", [])
    if not isinstance(raw, list):
        return packages

    for item in raw:
        if not isinstance(item, dict):
            continue
        name = item.get("name")
        version = item.get("version")
        if isinstance(name, str) and isinstance(version, str):
            packages.append(LockedPackage(name=name, version=version))

    return packages


def _parse_pipfile_lock(path: Path) -> list[LockedPackage]:
    """Parse packages from a Pipfile.lock file.

    Pipfile.lock is JSON with ``"default"`` and optional ``"develop"``
    sections.  Each key is a package name and the value contains a
    ``"version"`` field like ``"==2.31.0"``.
    """
    try:
        data = json.loads(path.read_text(errors="ignore"))
    except (json.JSONDecodeError, OSError):
        return []

    if not isinstance(data, dict):
        return []

    packages: list[LockedPackage] = []
    for section in ("default", "develop"):
        deps = data.get(section)
        if not isinstance(deps, dict):
            continue
        for name, info in deps.items():
            if not isinstance(info, dict):
                continue
            version_str = info.get("version", "")
            if isinstance(version_str, str) and version_str.startswith("=="):
                version = version_str[2:]
            else:
                version = str(version_str) if version_str else ""
            if name and version:
                packages.append(LockedPackage(name=name, version=version))

    return packages
