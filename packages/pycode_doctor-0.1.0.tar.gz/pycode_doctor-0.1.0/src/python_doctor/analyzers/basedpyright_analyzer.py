"""basedpyright integration for optional type checking.

basedpyright is an optional alternative type backend with fast JSON output and
stronger defaults than upstream pyright.
"""

from __future__ import annotations

import asyncio
import json
import shutil
from pathlib import Path

from python_doctor.analysis_request import AnalysisRequest
from python_doctor.models import Category, Diagnostic, Severity


class BasedPyrightAnalyzer:
    """Type checking via basedpyright."""

    @property
    def name(self) -> str:
        return "basedpyright"

    @property
    def category(self) -> Category:
        return Category.TYPE_SAFETY

    async def is_available(self) -> bool:
        return shutil.which("basedpyright") is not None

    async def analyze(self, request: AnalysisRequest) -> list[Diagnostic]:
        if not request.files:
            return []

        cmd = [
            "basedpyright",
            "--outputjson",
            "--project",
            str(request.project_root),
            *[str(path) for path in request.files],
        ]

        timeout = request.config.timeout
        proc = await asyncio.create_subprocess_exec(
            *cmd,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        stdout, _stderr = await asyncio.wait_for(proc.communicate(), timeout=timeout)

        if proc.returncode not in (0, 1):
            return []

        output = stdout.decode().strip()
        if not output:
            return []

        try:
            data = json.loads(output)
        except json.JSONDecodeError:
            return []

        diagnostics: list[Diagnostic] = []
        raw_diags = data.get("generalDiagnostics", [])
        if not isinstance(raw_diags, list):
            return []

        for raw in raw_diags:
            if not isinstance(raw, dict):
                continue

            severity_raw = str(raw.get("severity", "warning"))
            severity = Severity.ERROR if severity_raw == "error" else Severity.WARNING
            file_path = Path(str(raw.get("file", "unknown")))
            rule = str(raw.get("rule", "basedpyright"))
            message = str(raw.get("message", ""))

            line = 0
            column = 0
            end_line: int | None = None
            end_column: int | None = None
            range_data = raw.get("range")
            if isinstance(range_data, dict):
                start = range_data.get("start")
                end = range_data.get("end")
                if isinstance(start, dict):
                    line = int(start.get("line", 0)) + 1
                    column = int(start.get("character", 0)) + 1
                if isinstance(end, dict):
                    end_line = int(end.get("line", 0)) + 1
                    end_column = int(end.get("character", 0)) + 1

            diagnostics.append(
                Diagnostic(
                    file_path=file_path,
                    line=line,
                    column=column,
                    severity=severity,
                    rule_id=f"basedpyright-{rule}",
                    tool="basedpyright",
                    category=Category.TYPE_SAFETY,
                    message=message,
                    end_line=end_line,
                    end_column=end_column,
                )
            )

        return diagnostics
