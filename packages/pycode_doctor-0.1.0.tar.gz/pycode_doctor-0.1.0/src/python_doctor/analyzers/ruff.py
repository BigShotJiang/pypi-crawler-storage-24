"""Ruff linter integration.

Ruff is invoked as a subprocess with --output-format json.
It produces an array of diagnostic objects that we map to our Diagnostic model.
"""

from __future__ import annotations

import asyncio
import json
import logging
import shutil
from pathlib import Path

from python_doctor.analysis_request import AnalysisRequest
from python_doctor.models import Category, Diagnostic, Severity

logger = logging.getLogger("python_doctor")


# Map Ruff rule prefixes to python-doctor categories
RULE_PREFIX_TO_CATEGORY: dict[str, Category] = {
    # Security (flake8-bandit)
    "S": Category.SECURITY,
    # Complexity (mccabe)
    "C9": Category.COMPLEXITY,
    # Dead code (eradicate)
    "ERA": Category.DEAD_CODE,
    # Framework-specific rules map to quality
    "DJ": Category.QUALITY,
    "FAST": Category.QUALITY,
    "ASYNC": Category.QUALITY,
}

# Ruff rules that are errors (not warnings)
# E9xx are syntax errors, F-prefixed are important
ERROR_PREFIXES = {"E9", "F"}


class RuffAnalyzer:
    """Linting via Ruff."""

    @property
    def name(self) -> str:
        return "ruff"

    @property
    def category(self) -> Category:
        return Category.QUALITY

    async def is_available(self) -> bool:
        """Check if ruff is on PATH."""
        return shutil.which("ruff") is not None

    async def analyze(
        self,
        request: AnalysisRequest,
    ) -> list[Diagnostic]:
        """Run ruff check with JSON output and parse results.

        We respect the project's existing ruff.toml / [tool.ruff] config.
        We do NOT override rule selection -- the user's config is authoritative.
        We only add --output-format json for machine-readable output.

        When a framework is detected (config["framework"]), we extend the
        rule selection with framework-specific rules (DJ for Django, FAST/ASYNC
        for FastAPI, S201 for Flask).

        Diagnostics whose categories are not in ``request.categories`` are
        filtered out so that ``--skip security`` (for example) suppresses
        Ruff's S-prefixed rules alongside Bandit and detect-secrets.
        """
        files = request.files
        config = request.config_dict()

        if not files:
            return []

        cmd = [
            "ruff",
            "check",
            "--output-format",
            "json",
            "--no-cache",  # Ensure fresh results (we have our own cache layer)
        ]

        # Add framework-specific rules
        framework = config.get("framework")
        extend_rules: list[str] = []

        if framework == "django":
            extend_rules.extend(["DJ", "S610", "S611"])
        elif framework == "fastapi":
            extend_rules.extend(["FAST", "ASYNC"])
        elif framework == "flask":
            extend_rules.extend(["S201"])

        if extend_rules:
            cmd.extend(["--extend-select", ",".join(extend_rules)])

        # Pass file paths
        str_paths = [str(f) for f in files]
        cmd.extend(str_paths)

        timeout: int = 60
        if "timeout" in config and isinstance(config["timeout"], (int, float)):
            timeout = int(config["timeout"])

        try:
            proc = await asyncio.create_subprocess_exec(
                *cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
            stdout, stderr = await asyncio.wait_for(
                proc.communicate(),
                timeout=timeout,
            )
        except asyncio.TimeoutError:
            logger.warning("Ruff timed out")
            return []
        except FileNotFoundError:
            logger.warning("Ruff binary not found")
            return []

        # Exit codes: 0 = no violations, 1 = violations found, 2 = error
        if proc.returncode == 2:
            logger.error("Ruff error: %s", stderr.decode())
            return []

        output = stdout.decode()
        if not output.strip():
            return []

        try:
            raw_diagnostics = json.loads(output)
        except json.JSONDecodeError:
            logger.error("Failed to parse Ruff JSON output")
            return []

        diagnostics = [_map_diagnostic(d) for d in raw_diagnostics]

        # Filter out diagnostics whose category is not in the active set.
        # This ensures that ``--skip security`` suppresses Ruff S rules,
        # ``--skip complexity`` suppresses C9 rules, etc.
        active_categories = request.categories
        if active_categories:
            diagnostics = [d for d in diagnostics if d.category in active_categories]

        return diagnostics


def _map_diagnostic(raw: dict[str, object]) -> Diagnostic:
    """Map a single Ruff JSON diagnostic to our Diagnostic model.

    Ruff JSON output per item:
    {
        "code": "F401",
        "message": "`os` imported but unused",
        "filename": "/path/to/file.py",
        "location": {"row": 1, "column": 8},
        "end_location": {"row": 1, "column": 10},
        "fix": {
            "message": "Remove unused import: `os`",
            "applicability": "safe",
            "edits": [...]
        },
        "url": "https://docs.astral.sh/ruff/rules/unused-import",
        "noqa_row": 1,
        "cell": null
    }
    """
    code = str(raw.get("code", "UNKNOWN"))
    category = _categorize_rule(code)
    severity = _severity_for_rule(code)

    fix_info = raw.get("fix")
    fix_message: str | None = None
    if isinstance(fix_info, dict):
        fix_message = str(fix_info["message"]) if fix_info.get("message") else None

    location = raw.get("location")
    end_location = raw.get("end_location")

    row = 0
    col = 0
    if isinstance(location, dict):
        row = int(location.get("row") or 0)
        col = int(location.get("column") or 0)

    end_row: int | None = None
    end_col: int | None = None
    if isinstance(end_location, dict):
        end_row = int(end_location.get("row") or 0)
        end_col = int(end_location.get("column") or 0)

    return Diagnostic(
        file_path=Path(str(raw.get("filename", "unknown"))),
        line=row,
        column=col,
        severity=severity,
        rule_id=code,
        tool="ruff",
        category=category,
        message=str(raw.get("message", "")),
        fix=fix_message,
        help_url=str(raw["url"]) if raw.get("url") else None,
        end_line=end_row,
        end_column=end_col,
    )


def _categorize_rule(code: str) -> Category:
    """Map a Ruff rule code to a python-doctor category.

    Rule prefix conventions:
    - S*    -> Security (flake8-bandit)
    - C9*   -> Complexity (mccabe)
    - ERA*  -> Dead code (eradicate)
    - Everything else -> Quality
    """
    for prefix, category in RULE_PREFIX_TO_CATEGORY.items():
        if code.startswith(prefix):
            return category
    return Category.QUALITY


def _severity_for_rule(code: str) -> Severity:
    """Determine severity based on rule code.

    - E9xx (syntax errors) and F-prefixed (Pyflakes) -> ERROR
    - S-prefixed (security) -> ERROR
    - Style rules (W, D, I) -> INFO
    - Everything else -> WARNING
    """
    # Syntax errors are always errors
    if code.startswith("E9"):
        return Severity.ERROR

    # Pyflakes rules are errors (unused imports, undefined names, etc.)
    if code.startswith("F"):
        return Severity.ERROR

    # Security rules are errors
    if code.startswith("S"):
        return Severity.ERROR

    # Style/formatting are info
    if code.startswith(("W", "D", "I")):
        return Severity.INFO

    # Default to warning
    return Severity.WARNING
