"""Mypy type checker integration.

Uses mypy.api.run() with --output json for structured output.
Falls back to line-based parsing for mypy < 1.7 (no JSON support).
"""

from __future__ import annotations

import asyncio
import json
import logging
import re
from pathlib import Path

from python_doctor.analysis_request import AnalysisRequest
from python_doctor.models import Category, Diagnostic, Severity

logger = logging.getLogger("python_doctor")

# Fallback regex for mypy < 1.7 (no JSON output support)
MYPY_LINE_RE = re.compile(
    r"^(.+?):(\d+):(?:(\d+):)?\s*(error|warning|note):\s*(.+?)(?:\s+\[(.+)\])?$"
)


class MypyAnalyzer:
    """Type checking via mypy."""

    @property
    def name(self) -> str:
        return "mypy"

    @property
    def category(self) -> Category:
        return Category.TYPE_SAFETY

    async def is_available(self) -> bool:
        """Check if mypy is importable."""
        try:
            import mypy.api  # noqa: F401

            return True
        except ImportError:
            return False

    async def analyze(
        self,
        request: AnalysisRequest,
    ) -> list[Diagnostic]:
        """Run mypy on the given files.

        Strategy:
        1. Try --output json first (mypy 1.7+)
        2. If that flag is unrecognized, fall back to text parsing
        3. Run in a thread pool since mypy.api.run() is blocking
        """
        files = request.files
        config = request.config_dict()

        if not files:
            return []

        timeout: int = 60
        if "timeout" in config and isinstance(config["timeout"], (int, float)):
            timeout = int(config["timeout"])

        # Build args for mypy.api.run()
        args = self._build_args(files, use_json=True)

        loop = asyncio.get_running_loop()

        try:
            stdout, stderr, exit_code = await asyncio.wait_for(
                loop.run_in_executor(None, self._run_mypy, args),
                timeout=timeout,
            )
        except asyncio.TimeoutError:
            logger.warning("mypy timed out after %ds", timeout)
            return []

        # Exit code 2 = fatal error (bad args, can't find files, etc.)
        if exit_code == 2:
            # Check if it's because --output json isn't supported
            if "unrecognized" in stderr.lower() or "error: argument" in stderr.lower():
                logger.debug(
                    "mypy doesn't support --output json, "
                    "falling back to text parsing"
                )
                args = self._build_args(files, use_json=False)
                try:
                    stdout, stderr, exit_code = await asyncio.wait_for(
                        loop.run_in_executor(None, self._run_mypy, args),
                        timeout=timeout,
                    )
                except asyncio.TimeoutError:
                    logger.warning("mypy timed out after %ds (fallback)", timeout)
                    return []

                if exit_code == 2:
                    logger.error("mypy fatal error: %s", stderr)
                    return []
                return self._parse_text_output(stdout)
            else:
                logger.error("mypy fatal error: %s", stderr)
                return []

        # Exit code 0 = clean, 1 = type errors found
        if not stdout.strip():
            return []

        return self._parse_json_output(stdout)

    def _build_args(
        self,
        files: list[Path],
        use_json: bool,
    ) -> list[str]:
        """Build mypy CLI arguments."""
        args: list[str] = []

        if use_json:
            args.extend(["--output", "json"])

        args.extend(
            [
                "--no-color-output",
                "--no-error-summary",
                "--show-absolute-path",
                "--incremental",  # Use .mypy_cache/ for speed
            ]
        )

        # Pass file paths
        args.extend(str(f) for f in files)

        return args

    @staticmethod
    def _run_mypy(args: list[str]) -> tuple[str, str, int]:
        """Call mypy.api.run() -- must run in thread pool (blocking)."""
        from mypy.api import run

        return run(args)

    def _parse_json_output(self, stdout: str) -> list[Diagnostic]:
        """Parse mypy JSON Lines output (one JSON object per line)."""
        diagnostics: list[Diagnostic] = []

        for line in stdout.strip().splitlines():
            line = line.strip()
            if not line:
                continue

            try:
                item = json.loads(line)
            except json.JSONDecodeError:
                logger.debug("Skipping non-JSON mypy output line: %s", line[:80])
                continue

            severity = _map_mypy_severity(item.get("severity", "error"))
            code = item.get("code", "misc")

            diagnostics.append(
                Diagnostic(
                    file_path=Path(item["file"]),
                    line=item.get("line", 0),
                    column=item.get("column", 0),
                    severity=severity,
                    rule_id=f"mypy-{code}",
                    tool="mypy",
                    category=Category.TYPE_SAFETY,
                    message=item.get("message", ""),
                    fix=item.get("hint"),
                    end_line=item.get("end_line"),
                    end_column=item.get("end_column"),
                )
            )

        return diagnostics

    def _parse_text_output(self, stdout: str) -> list[Diagnostic]:
        """Fallback: parse mypy's traditional text output.

        Format: file.py:10:5: error: message [error-code]
        """
        diagnostics: list[Diagnostic] = []

        for line in stdout.strip().splitlines():
            match = MYPY_LINE_RE.match(line)
            if not match:
                continue

            filepath, lineno, colno, level, message, code = match.groups()

            # Skip notes -- they're supplementary info, not actionable findings
            if level == "note":
                continue

            severity = _map_mypy_severity(level)
            code = code or "misc"

            diagnostics.append(
                Diagnostic(
                    file_path=Path(filepath),
                    line=int(lineno),
                    column=int(colno) if colno else 0,
                    severity=severity,
                    rule_id=f"mypy-{code}",
                    tool="mypy",
                    category=Category.TYPE_SAFETY,
                    message=message.strip(),
                )
            )

        return diagnostics


def _map_mypy_severity(level: str) -> Severity:
    """Map mypy severity to our Severity enum."""
    match level:
        case "error":
            return Severity.ERROR
        case "warning":
            return Severity.WARNING
        case _:
            return Severity.INFO
