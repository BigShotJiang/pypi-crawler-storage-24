"""Radon complexity metrics integration.

Uses Radon's library API directly -- no subprocess needed.
Computes both cyclomatic complexity (per-function) and
maintainability index (per-file, 0-100 scale).
"""

from __future__ import annotations

import asyncio
import logging
from pathlib import Path
from typing import Any

from python_doctor.analysis_request import AnalysisRequest
from python_doctor.models import Category, Diagnostic, Severity

logger = logging.getLogger("python_doctor")

# Only report functions at or above this grade as diagnostics
DIAGNOSTIC_THRESHOLD = "C"  # CC >= 11

# Map CC grades to severity
CC_GRADE_SEVERITY: dict[str, Severity] = {
    "C": Severity.WARNING,  # 11-20: moderate complexity
    "D": Severity.ERROR,  # 21-30: complex
    "E": Severity.ERROR,  # 31-40: very complex
    "F": Severity.ERROR,  # 41+: unmaintainable
}


class RadonAnalyzer:
    """Complexity analysis via Radon."""

    @property
    def name(self) -> str:
        return "radon"

    @property
    def category(self) -> Category:
        return Category.COMPLEXITY

    async def is_available(self) -> bool:
        """Check if radon is importable."""
        try:
            import radon.complexity  # noqa: F401
            import radon.metrics  # noqa: F401

            return True
        except ImportError:
            return False

    async def analyze(
        self,
        request: AnalysisRequest,
    ) -> list[Diagnostic]:
        """Analyze complexity for all files."""
        files = request.files
        if not files:
            return []

        # Run in thread pool -- Radon is CPU-bound Python code
        loop = asyncio.get_running_loop()
        return await loop.run_in_executor(
            None,
            self._analyze_sync,
            files,
            request.metadata,
        )

    def _analyze_sync(
        self,
        files: list[Path],
        metadata: dict[str, object],
    ) -> list[Diagnostic]:
        """Synchronous analysis -- runs in thread pool."""
        from radon.complexity import cc_rank, cc_visit
        from radon.metrics import mi_visit

        diagnostics: list[Diagnostic] = []
        mi_scores: list[float] = []

        for file_path in files:
            try:
                source = file_path.read_text(errors="ignore")
            except OSError as e:
                logger.debug("Cannot read %s: %s", file_path, e)
                continue

            if not source.strip():
                continue

            # 1. Cyclomatic complexity per function/method
            try:
                cc_results = cc_visit(source)
                for block in cc_results:
                    grade = cc_rank(block.complexity)
                    if grade >= DIAGNOSTIC_THRESHOLD:
                        severity = CC_GRADE_SEVERITY.get(grade, Severity.WARNING)
                        block_type = _block_type_label(block)
                        diagnostics.append(
                            Diagnostic(
                                file_path=file_path,
                                line=block.lineno,
                                column=0,
                                severity=severity,
                                rule_id=f"CC-{grade}",
                                tool="radon",
                                category=Category.COMPLEXITY,
                                message=(
                                    f"{block_type} '{block.name}' has cyclomatic "
                                    f"complexity of {block.complexity} (grade {grade})"
                                ),
                                fix=_cc_fix_suggestion(block.complexity, grade),
                                end_line=(
                                    block.endline if hasattr(block, "endline") else None
                                ),
                            )
                        )
            except Exception as e:
                logger.debug("Radon CC failed on %s: %s", file_path, e)

            # 2. Maintainability Index per file
            try:
                mi: float = mi_visit(source, multi=True)
                mi_scores.append(mi)
            except Exception as e:
                logger.debug("Radon MI failed on %s: %s", file_path, e)

        # Store MI scores in config for the scoring engine
        metadata["_radon_mi_scores"] = mi_scores

        return diagnostics


def _block_type_label(block: Any) -> str:
    """Get a human-readable label for a Radon complexity block."""
    if hasattr(block, "is_method") and block.is_method:
        return f"Method ({block.classname})"
    elif hasattr(block, "is_method"):
        return "Function"
    else:
        return "Class"


def _cc_fix_suggestion(complexity: int, grade: str) -> str:
    """Generate actionable fix text for high-complexity functions."""
    if grade == "F":
        return (
            f"Complexity {complexity} is dangerously high. "
            "Extract helper functions, replace conditional chains with "
            "a dispatch dict or Strategy pattern, and eliminate nested loops."
        )
    elif grade in ("D", "E"):
        return (
            f"Complexity {complexity} makes this hard to test and maintain. "
            "Consider extracting helper functions or using early returns "
            "to reduce nesting."
        )
    else:  # C
        return (
            f"Complexity {complexity} is moderate but could be simplified. "
            "Look for opportunities to extract a helper function or "
            "simplify conditional logic."
        )
