"""Bandit security scanner integration.

Bandit is invoked as a subprocess with -f json.
Results are deduplicated against Ruff's S-prefix findings in the dedup engine.
"""

from __future__ import annotations

import asyncio
import json
import logging
import shutil
from pathlib import Path

from python_doctor.analysis_request import AnalysisRequest
from python_doctor.models import Category, Diagnostic, Severity

logger = logging.getLogger("python_doctor")

# Bandit severity -> python-doctor Severity
BANDIT_SEVERITY_MAP: dict[str, Severity] = {
    "HIGH": Severity.ERROR,
    "MEDIUM": Severity.WARNING,
    "LOW": Severity.INFO,
}


class BanditAnalyzer:
    """Security scanning via Bandit."""

    @property
    def name(self) -> str:
        return "bandit"

    @property
    def category(self) -> Category:
        return Category.SECURITY

    async def is_available(self) -> bool:
        """Check if bandit is on PATH."""
        return shutil.which("bandit") is not None

    async def analyze(
        self,
        request: AnalysisRequest,
    ) -> list[Diagnostic]:
        """Run bandit with JSON output and parse results."""
        files = request.files
        config = request.config_dict()
        if not files:
            return []

        cmd = ["bandit", "-f", "json", "--quiet"]

        str_paths = [str(f) for f in files]
        cmd.extend(str_paths)

        timeout: int = 60
        if "timeout" in config and isinstance(config["timeout"], (int, float)):
            timeout = int(config["timeout"])

        try:
            proc = await asyncio.create_subprocess_exec(
                *cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
            stdout, stderr = await asyncio.wait_for(
                proc.communicate(),
                timeout=timeout,
            )
        except asyncio.TimeoutError:
            logger.warning("Bandit timed out")
            return []
        except FileNotFoundError:
            logger.warning("Bandit binary not found")
            return []

        # Exit codes: 0 = clean, 1 = issues found, 2 = error
        if proc.returncode == 2:
            logger.error("Bandit error: %s", stderr.decode())
            return []

        output = stdout.decode()
        if not output.strip():
            return []

        try:
            data = json.loads(output)
        except json.JSONDecodeError:
            logger.error("Failed to parse Bandit JSON output")
            return []

        results = data.get("results", [])
        if not isinstance(results, list):
            return []
        return [_map_bandit_result(r) for r in results]


def _safe_int(val: object, default: int = 0) -> int:
    """Safely convert a value from JSON to int."""
    if val is None:
        return default
    if isinstance(val, int):
        return val
    try:
        return int(str(val))
    except (TypeError, ValueError):
        return default


def _map_bandit_result(raw: dict[str, object]) -> Diagnostic:
    """Map a single Bandit JSON result to our Diagnostic model."""
    severity = BANDIT_SEVERITY_MAP.get(
        str(raw.get("issue_severity", "LOW")),
        Severity.INFO,
    )

    test_id = str(raw.get("test_id", "B000"))

    # Build fix suggestion from CWE
    cwe = raw.get("issue_cwe")
    fix_text: str | None = None
    if isinstance(cwe, dict) and cwe.get("id"):
        fix_text = f"CWE-{cwe['id']}"

    help_url = raw.get("more_info")

    end_col = raw.get("end_col_offset")

    return Diagnostic(
        file_path=Path(str(raw.get("filename", "unknown"))),
        line=_safe_int(raw.get("line_number")),
        column=_safe_int(raw.get("col_offset")),
        severity=severity,
        rule_id=test_id,
        tool="bandit",
        category=Category.SECURITY,
        message=str(raw.get("issue_text", "")),
        fix=fix_text,
        help_url=str(help_url) if help_url else None,
        end_column=_safe_int(end_col) if end_col else None,
    )
