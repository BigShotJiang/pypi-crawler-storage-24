"""Cache-aware wrapper for any Analyzer.

Wraps an existing analyzer with per-file cache lookups.
For each file: check cache -> return cached diagnostics, or
run the analyzer on cache-miss files -> cache results -> return all.
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any

from python_doctor.analysis_request import AnalysisRequest
from python_doctor.cache import AnalysisCache
from python_doctor.models import Category, Diagnostic

logger = logging.getLogger("python_doctor")


class CachedAnalyzer:
    """Wraps any Analyzer with per-file caching.

    This is transparent to consumers -- it has the same interface
    as the underlying analyzer. The cache lookup happens per-file,
    so editing one file in a 1000-file project only re-analyzes
    that single file.
    """

    def __init__(self, analyzer: Any, cache: AnalysisCache) -> None:
        self._analyzer = analyzer
        self._cache = cache

    @property
    def name(self) -> str:
        return self._analyzer.name  # type: ignore[no-any-return]

    @property
    def category(self) -> Category:
        return self._analyzer.category  # type: ignore[no-any-return]

    async def is_available(self) -> bool:
        return await self._analyzer.is_available()  # type: ignore[no-any-return]

    async def analyze(
        self,
        request: AnalysisRequest,
    ) -> list[Diagnostic]:
        """Analyze files, using cache for unchanged files.

        1. For each file, check if we have cached results
        2. Collect all cache misses into a batch
        3. Run the underlying analyzer only on missed files
        4. Cache the new results per-file
        5. Return all results (cached + fresh)
        """
        files = request.files
        cached_results: list[Diagnostic] = []
        uncached_files = []

        for f in files:
            cached = self._cache.get(self._analyzer.name, f)
            if cached is not None:
                cached_results.extend(cached)
            else:
                uncached_files.append(f)

        if not uncached_files:
            logger.debug(
                "%s: all %d files cached",
                self._analyzer.name,
                len(files),
            )
            return cached_results

        logger.debug(
            "%s: %d/%d files need analysis",
            self._analyzer.name,
            len(uncached_files),
            len(files),
        )

        # Run analyzer only on uncached files
        uncached_request = AnalysisRequest(
            project_root=request.project_root,
            files=uncached_files,
            config=request.config,
            categories=set(request.categories),
            profile=request.profile,
            framework=request.framework,
            diff_base=request.diff_base,
            quiet=request.quiet,
            no_cache=request.no_cache,
            metadata=dict(request.metadata),
        )
        new_results: list[Diagnostic] = await self._analyzer.analyze(uncached_request)

        # Group results by file for per-file caching
        results_by_file: dict[Path, list[Diagnostic]] = {f: [] for f in uncached_files}
        for d in new_results:
            if d.file_path in results_by_file:
                results_by_file[d.file_path].append(d)

        # Cache each file's results (including empty lists for clean files)
        for file_path, file_diagnostics in results_by_file.items():
            self._cache.set(
                self._analyzer.name,
                file_path,
                file_diagnostics,
            )

        cached_results.extend(new_results)
        return cached_results
