"""Vulture dead code detection integration.

Uses Vulture's library API directly. Creates a fresh Vulture instance
per analysis run (Vulture accumulates state across scavenge() calls).
"""

from __future__ import annotations

import asyncio
import logging
from pathlib import Path
from typing import Any

from python_doctor.analysis_request import AnalysisRequest
from python_doctor.models import Category, Diagnostic, Severity

logger = logging.getLogger("python_doctor")

# Vulture item types and their human-readable labels
ITEM_TYPE_LABELS: dict[str, str] = {
    "attribute": "Unused attribute",
    "class": "Unused class",
    "function": "Unused function",
    "import": "Unused import",
    "method": "Unused method",
    "property": "Unused property",
    "variable": "Unused variable",
    "unreachable_code": "Unreachable code",
}

# Map item types to severity
ITEM_TYPE_SEVERITY: dict[str, Severity] = {
    "unreachable_code": Severity.ERROR,  # Definitely dead
    "import": Severity.WARNING,  # Likely dead
    "function": Severity.WARNING,  # Likely dead
    "method": Severity.WARNING,  # Likely dead
    "class": Severity.WARNING,  # Likely dead
    "variable": Severity.INFO,  # Might be dynamic access
    "attribute": Severity.INFO,  # Might be dynamic access
    "property": Severity.INFO,  # Might be dynamic access
}


class VultureAnalyzer:
    """Dead code detection via Vulture."""

    @property
    def name(self) -> str:
        return "vulture"

    @property
    def category(self) -> Category:
        return Category.DEAD_CODE

    async def is_available(self) -> bool:
        """Check if vulture is importable."""
        try:
            import vulture  # noqa: F401

            return True
        except ImportError:
            return False

    async def analyze(
        self,
        request: AnalysisRequest,
    ) -> list[Diagnostic]:
        """Run Vulture dead code detection.

        IMPORTANT: Vulture accumulates state across scavenge() calls.
        A fresh Vulture() instance MUST be created for each analysis run.
        """
        files = request.files
        config = request.config_dict()
        if not files:
            return []

        min_confidence: int = 80
        raw_conf = config.get("min_confidence", 80)
        if isinstance(raw_conf, (int, float)):
            min_confidence = int(raw_conf)

        # Run in thread pool -- Vulture's AST parsing is CPU-bound
        loop = asyncio.get_running_loop()
        return await loop.run_in_executor(
            None, self._analyze_sync, files, min_confidence
        )

    def _analyze_sync(
        self,
        files: list[Path],
        min_confidence: int,
    ) -> list[Diagnostic]:
        """Synchronous analysis -- runs in thread pool."""
        from vulture.core import Vulture

        # CRITICAL: Fresh instance every time.
        v = Vulture()

        try:
            v.scavenge([str(f) for f in files])
        except Exception as e:
            logger.error("Vulture scavenge failed: %s", e)
            return []

        unused_code = v.get_unused_code(min_confidence=min_confidence)

        diagnostics: list[Diagnostic] = []
        for item in unused_code:
            severity = ITEM_TYPE_SEVERITY.get(item.typ, Severity.INFO)
            type_label = ITEM_TYPE_LABELS.get(item.typ, f"Unused {item.typ}")

            diagnostics.append(
                Diagnostic(
                    file_path=Path(item.filename),
                    line=item.first_lineno,
                    column=0,
                    severity=severity,
                    rule_id=f"V-{item.typ}",
                    tool="vulture",
                    category=Category.DEAD_CODE,
                    message=(
                        f"{type_label}: '{item.name}' "
                        f"({item.confidence}% confidence)"
                    ),
                    fix=_dead_code_fix(item),
                    end_line=item.last_lineno,
                )
            )

        return diagnostics


def _dead_code_fix(item: Any) -> str:
    """Generate actionable fix text for dead code items."""
    match item.typ:
        case "import":
            return f"Remove unused import '{item.name}'"
        case "function":
            return (
                f"Remove unused function '{item.name}' or add it to a "
                "whitelist if it's used via dynamic dispatch"
            )
        case "method":
            return (
                f"Remove unused method '{item.name}' or mark it with "
                "@typing.override if it implements an interface"
            )
        case "class":
            return (
                f"Remove unused class '{item.name}' or add it to __all__ "
                "if it's part of the public API"
            )
        case "variable":
            return f"Remove unused variable '{item.name}' or prefix with underscore"
        case "unreachable_code":
            return "Remove unreachable code after return/raise/continue/break"
        case _:
            return f"Remove unused {item.typ} '{item.name}'"
