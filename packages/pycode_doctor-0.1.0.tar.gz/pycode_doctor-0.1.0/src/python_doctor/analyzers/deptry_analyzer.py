"""deptry integration for dependency hygiene checking.

deptry (MIT, Rust core since v0.14) detects unused, missing, and
transitive dependencies in Python projects.
"""

from __future__ import annotations

import asyncio
import json
import logging
import shutil
from pathlib import Path

from python_doctor.analysis_request import AnalysisRequest
from python_doctor.models import Category, Diagnostic, Severity

logger = logging.getLogger("python_doctor")

# Error code descriptions and severity mappings
DEPTRY_CODES: dict[str, tuple[str, Severity]] = {
    "DEP001": ("Missing dependency", Severity.ERROR),
    "DEP002": ("Unused dependency", Severity.WARNING),
    "DEP003": ("Transitive dependency", Severity.WARNING),
    "DEP004": ("Misplaced dev dependency", Severity.WARNING),
}


class DeptryAnalyzer:
    """Check for unused, missing, and transitive dependencies."""

    @property
    def name(self) -> str:
        return "deptry"

    @property
    def category(self) -> Category:
        return Category.DEPENDENCIES

    async def is_available(self) -> bool:
        """Check if deptry is on PATH."""
        return shutil.which("deptry") is not None

    async def analyze(
        self,
        request: AnalysisRequest,
    ) -> list[Diagnostic]:
        """Run deptry with JSON output.

        deptry analyzes the project root, not individual files.
        """
        config = request.config_dict()
        project_root = str(request.project_root)

        cmd = ["deptry", project_root, "--json-output", "-"]

        timeout: int = 30
        if "timeout" in config and isinstance(config["timeout"], (int, float)):
            timeout = int(config["timeout"])

        try:
            proc = await asyncio.create_subprocess_exec(
                *cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
            stdout, stderr = await asyncio.wait_for(
                proc.communicate(),
                timeout=timeout,
            )
        except asyncio.TimeoutError:
            logger.warning("deptry timed out")
            return []
        except FileNotFoundError:
            logger.warning("deptry not found")
            return []

        # deptry writes JSON to stdout when --json-output - is used
        output = stdout.decode()
        if not output.strip():
            return []

        try:
            issues: list[dict[str, object]] = json.loads(output)
        except json.JSONDecodeError:
            logger.error("Failed to parse deptry JSON")
            return []

        diagnostics: list[Diagnostic] = []
        for issue in issues:
            if not isinstance(issue, dict):
                continue

            error = issue.get("error", {})
            if not isinstance(error, dict):
                error = {}
            code = str(error.get("code", "DEP000"))

            location = issue.get("location", {})
            if not isinstance(location, dict):
                location = {}
            module = str(issue.get("module", "unknown"))

            desc, severity = DEPTRY_CODES.get(
                code, ("Dependency issue", Severity.WARNING)
            )

            file_path = str(location.get("file", "pyproject.toml"))
            line_val = location.get("line")
            col_val = location.get("column")

            diagnostics.append(
                Diagnostic(
                    file_path=Path(file_path),
                    line=int(line_val) if isinstance(line_val, (int, float)) else 0,
                    column=int(col_val) if isinstance(col_val, (int, float)) else 0,
                    severity=severity,
                    rule_id=code,
                    tool="deptry",
                    category=Category.DEPENDENCIES,
                    message=f"{desc}: {module}",
                    fix=_fix_suggestion(code, module),
                )
            )

        return diagnostics


def _fix_suggestion(code: str, module: str) -> str:
    """Generate a human-readable fix suggestion for a deptry issue."""
    match code:
        case "DEP001":
            return f"Add '{module}' to your project dependencies in pyproject.toml"
        case "DEP002":
            return (
                f"Remove '{module}' from your project dependencies "
                "(it's not imported)"
            )
        case "DEP003":
            return (
                f"Add '{module}' as a direct dependency instead of "
                "relying on it transitively"
            )
        case "DEP004":
            return (
                f"Move '{module}' from dev dependencies to main dependencies "
                "(it's imported in non-dev code)"
            )
        case _:
            return f"Review the dependency '{module}'"
