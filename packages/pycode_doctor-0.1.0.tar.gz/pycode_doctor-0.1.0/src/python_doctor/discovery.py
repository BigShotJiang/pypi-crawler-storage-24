"""Python file discovery with .gitignore and config-based filtering.

Replaces the naive rglob from Phase 2 with proper ignore handling.
Strategy: use `git ls-files` when in a git repo (respects .gitignore),
fall back to rglob with default ignores otherwise.
"""

from __future__ import annotations

import logging
import subprocess
from fnmatch import fnmatch
from pathlib import Path

logger = logging.getLogger("python_doctor")

# Directories always ignored, regardless of config.
DEFAULT_IGNORE_DIRS: frozenset[str] = frozenset(
    {
        ".venv",
        "venv",
        ".env",
        "env",
        "__pycache__",
        ".git",
        "node_modules",
        ".tox",
        ".nox",
        ".mypy_cache",
        ".ruff_cache",
        ".pytest_cache",
        ".eggs",
        "build",
        "dist",
        ".hatch",
        ".pixi",
    }
)


def discover_python_files(
    root: Path,
    ignore_patterns: list[str] | None = None,
) -> list[Path]:
    """Find all Python files in root, respecting .gitignore and config.

    Strategy:
    1. If inside a git repo, use `git ls-files` -- this automatically
       respects .gitignore, .git/info/exclude, and global gitignore.
    2. If not in a git repo, fall back to rglob with default ignores.

    In both cases, apply user-configured ignore patterns on top.
    """
    ignore_patterns = ignore_patterns or []

    # Try git-based discovery first
    files = _git_ls_files(root)
    if files is None:
        # Not a git repo -- fall back to rglob
        files = _rglob_discovery(root)

    # Apply user ignore patterns
    if ignore_patterns:
        files = _apply_ignore_patterns(files, root, ignore_patterns)

    return sorted(files)


def _git_ls_files(root: Path) -> list[Path] | None:
    """Use git ls-files to find tracked + untracked Python files.

    Returns None if not in a git repo.

    git ls-files --cached --others --exclude-standard gives us:
    - All tracked files (--cached)
    - Untracked files that aren't gitignored (--others --exclude-standard)
    """
    try:
        subprocess.run(
            ["git", "rev-parse", "--git-dir"],
            cwd=root,
            capture_output=True,
            check=True,
            timeout=5,
        )
    except (
        subprocess.CalledProcessError,
        FileNotFoundError,
        subprocess.TimeoutExpired,
    ):
        return None

    try:
        result = subprocess.run(
            [
                "git",
                "ls-files",
                "--cached",
                "--others",
                "--exclude-standard",
                "-z",
                "*.py",
            ],
            cwd=root,
            capture_output=True,
            text=True,
            timeout=10,
        )
    except (subprocess.CalledProcessError, subprocess.TimeoutExpired):
        return None

    if result.returncode != 0:
        return None

    files: list[Path] = []
    for entry in result.stdout.split("\0"):
        entry = entry.strip()
        if not entry:
            continue
        full_path = (root / entry).resolve()
        if full_path.is_file():
            files.append(full_path)

    logger.debug("git ls-files found %d Python files", len(files))
    return files


def _rglob_discovery(root: Path) -> list[Path]:
    """Fallback file discovery using rglob with default ignores."""
    files: list[Path] = []
    for py_file in root.rglob("*.py"):
        try:
            relative = py_file.relative_to(root)
        except ValueError:
            continue

        parts = relative.parts
        if any(part in DEFAULT_IGNORE_DIRS for part in parts):
            continue

        # Skip egg-info directories
        if any(part.endswith(".egg-info") for part in parts):
            continue

        files.append(py_file)

    logger.debug("rglob found %d Python files", len(files))
    return files


def _apply_ignore_patterns(
    files: list[Path],
    root: Path,
    patterns: list[str],
) -> list[Path]:
    """Apply user-configured ignore patterns.

    Supports simple glob patterns:
    - "tests/**" -- ignore everything under tests/
    - "*.generated.py" -- ignore files matching pattern
    - "migrations/" -- ignore directory by name
    """
    filtered: list[Path] = []
    for f in files:
        try:
            relative = str(f.relative_to(root))
        except ValueError:
            relative = str(f)

        if any(fnmatch(relative, pat) for pat in patterns):
            continue

        # Also check directory components
        try:
            parts = f.relative_to(root).parts
        except ValueError:
            parts = ()

        if any(fnmatch(part, pat.rstrip("/")) for part in parts for pat in patterns):
            continue

        filtered.append(f)

    skipped = len(files) - len(filtered)
    if skipped > 0:
        logger.debug("Ignore patterns filtered out %d files", skipped)

    return filtered
