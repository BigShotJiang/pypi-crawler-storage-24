"""Structured analysis request passed to analyzers."""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path

from python_doctor.config import DoctorConfig
from python_doctor.models import Category


@dataclass
class AnalysisRequest:
    """Input contract shared by all analyzers."""

    project_root: Path
    files: list[Path]
    config: DoctorConfig
    categories: set[Category]
    profile: str
    framework: str | None = None
    diff_base: str | None = None
    quiet: bool = False
    no_cache: bool = False
    metadata: dict[str, object] = field(default_factory=dict)

    def config_dict(self) -> dict[str, object]:
        """Return a mutable dict representation for legacy integrations."""
        data = self.config.__dict__.copy()
        data["framework"] = self.framework
        data["profile"] = self.profile
        data["categories"] = [
            category.value
            for category in sorted(self.categories, key=lambda c: c.value)
        ]
        data.update(self.metadata)
        return data
