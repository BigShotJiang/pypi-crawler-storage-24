"""Analysis orchestration -- runs analyzers in parallel and collects results."""

from __future__ import annotations

import asyncio
import logging
import sys
import time
from pathlib import Path
from typing import TYPE_CHECKING

from python_doctor.analysis_request import AnalysisRequest
from python_doctor.analyzer_catalog import ANALYZER_CATALOG, get_analyzer_info
from python_doctor.analyzers.cached import CachedAnalyzer
from python_doctor.analyzers.registry import discover_analyzers
from python_doctor.cache import AnalysisCache
from python_doctor.config import DoctorConfig
from python_doctor.dedup import deduplicate
from python_doctor.detection import detect_framework
from python_doctor.discovery import discover_python_files
from python_doctor.models import (
    Category,
    CategoryCoverage,
    CoverageInfo,
    Diagnostic,
    HealthReport,
    ProjectInfo,
)
from python_doctor.plan import PROFILE_DEFAULT, ScanPlan, build_scan_plan
from python_doctor.progress import analysis_progress
from python_doctor.scoring.engine import compute_health_report

if TYPE_CHECKING:
    from python_doctor.analyzers import Analyzer

logger = logging.getLogger("python_doctor")

# Analyzers that benefit from per-file caching.
# mypy is excluded because it needs project-wide context
# (it relies on its own .mypy_cache/ instead).
CACHEABLE_ANALYZERS = {"ruff", "bandit", "radon", "vulture"}


async def run_analysis(
    project_root: Path,
    config: DoctorConfig,
    files: list[Path] | None = None,
    skip_analyzers: set[str] | None = None,
    quiet: bool = False,
    no_cache: bool = False,
    plan: ScanPlan | None = None,
    diff_base: str | None = None,
) -> HealthReport:
    """Run all available analyzers with progress feedback.

    Args:
        project_root: Root directory to analyze.
        config: Resolved configuration.
        files: Specific files to analyze. If None, discovers all.
        skip_analyzers: Set of analyzer names to skip.
        quiet: Suppress progress output (for --score and --json).
        no_cache: If True, skip the cache entirely (fresh run).
    """
    start = time.monotonic()
    skip_analyzers = skip_analyzers or set()
    plan = plan or build_scan_plan(profile=PROFILE_DEFAULT)

    # Discover files if not provided
    if files is None:
        files = discover_python_files(project_root, config.ignore_files)

    if not files:
        return _empty_report(start)

    # Initialize cache
    cache = AnalysisCache(project_root, enabled=not no_cache)

    # Detect framework (Django, FastAPI, Flask)
    framework_info = detect_framework(project_root)
    framework_name: str | None = None
    framework_label: str | None = None
    if framework_info:
        framework_name = framework_info.name
        framework_label = (
            f"{framework_info.name}-{framework_info.version}"
            if framework_info.version
            else framework_info.name
        )

    # Discover available analyzers, filter out skipped ones,
    # and wrap cacheable ones with CachedAnalyzer
    all_analyzers = await discover_analyzers()
    active: list[Analyzer | CachedAnalyzer] = []
    skipped_names = [a.name for a in all_analyzers if a.name in skip_analyzers]
    optional_unavailable: list[str] = []

    for a in all_analyzers:
        info = get_analyzer_info(a.name)
        if a.name in skip_analyzers:
            continue
        if info is not None:
            if not info.categories.intersection(plan.categories):
                skipped_names.append(a.name)
                continue
            if plan.profile not in info.profiles:
                skipped_names.append(a.name)
                continue
            if info.optional and not plan.include_optional:
                optional_unavailable.append(a.name)
                skipped_names.append(a.name)
                continue
        if a.name in CACHEABLE_ANALYZERS and cache.enabled:
            active.append(CachedAnalyzer(a, cache))
        else:
            active.append(a)

    if not active:
        logger.warning("No analyzers available after filtering")
        return _empty_report(start)

    # Run with progress tracking
    all_diagnostics: list[Diagnostic] = []
    analyzers_used: list[str] = []
    mi_scores: list[float] = []

    with analysis_progress([a.name for a in active], quiet=quiet) as tracker:

        async def run_one(
            analyzer: Analyzer | CachedAnalyzer,
            request: AnalysisRequest,
        ) -> tuple[str, list[Diagnostic] | None, dict[str, object]]:
            tracker.start(analyzer.name)
            try:
                result = await analyzer.analyze(request)
                tracker.complete(analyzer.name, len(result))
                return analyzer.name, result, request.metadata
            except asyncio.TimeoutError:
                tracker.fail(analyzer.name, "timed out")
                logger.warning("%s timed out", analyzer.name)
                return analyzer.name, None, request.metadata
            except Exception as e:
                error_str = str(e)[:50]
                tracker.fail(analyzer.name, error_str)
                logger.warning(
                    "%s failed: %s: %s",
                    analyzer.name,
                    type(e).__name__,
                    e,
                )
                return analyzer.name, None, request.metadata

        # Each analyzer gets its own config dict copy so radon
        # can store MI scores without interfering with others.
        # Include framework info so Ruff can extend rule selection.
        tasks = []
        for a in active:
            request = AnalysisRequest(
                project_root=project_root,
                files=files,
                config=config,
                categories=set(plan.categories),
                profile=plan.profile,
                framework=framework_name,
                diff_base=diff_base,
                quiet=quiet,
                no_cache=no_cache,
                metadata={},
            )
            tasks.append(run_one(a, request))
        results = await asyncio.gather(*tasks)

    for name, result, cfg in results:
        if result is not None:
            all_diagnostics.extend(result)
            analyzers_used.append(name)
            # Extract MI scores from radon analyzer
            if name == "radon" and "_radon_mi_scores" in cfg:
                raw_mi = cfg["_radon_mi_scores"]
                if isinstance(raw_mi, list):
                    mi_scores = raw_mi
        else:
            skipped_names.append(name)

    # Collect cache stats before cleanup
    cache_stats: dict[str, int] | None = None
    if cache.enabled:
        cache_stats = cache.get_stats()
        logger.info(
            "Cache: %d hits, %d misses (%d%% hit rate)",
            cache_stats["hits"],
            cache_stats["misses"],
            cache_stats["hit_rate_pct"],
        )
        # Periodic cleanup (non-blocking, best-effort)
        cache.cleanup()

    # Deduplicate (Ruff/Bandit overlap)
    all_diagnostics = deduplicate(all_diagnostics)

    # Filter ignored rules
    if config.ignore_rules:
        all_diagnostics = [
            d for d in all_diagnostics if d.rule_id not in config.ignore_rules
        ]

    # Count project stats
    total_lines = sum(_count_lines(f) for f in files)
    project = ProjectInfo(
        python_version=_detect_python_version(),
        framework=framework_label,
        total_files=len(files),
        total_lines=total_lines,
    )

    duration_ms = int((time.monotonic() - start) * 1000)

    coverage = _build_coverage(
        plan=plan,
        analyzers_used=analyzers_used,
        analyzers_skipped=skipped_names,
        optional_unavailable=optional_unavailable,
        request_metadata={
            key: value
            for _name, _result, metadata in results
            for key, value in metadata.items()
        },
    )

    return compute_health_report(
        diagnostics=all_diagnostics,
        project=project,
        config=config,
        duration_ms=duration_ms,
        analyzers_used=analyzers_used,
        analyzers_skipped=skipped_names,
        mi_scores=mi_scores if mi_scores else None,
        cache_stats=cache_stats,
        coverage=coverage,
    )


def _count_lines(path: Path) -> int:
    """Count lines in a file, handling encoding errors."""
    try:
        return len(path.read_text(errors="ignore").splitlines())
    except OSError:
        return 0


def _detect_python_version() -> str:
    """Detect the Python version being used."""
    return f"{sys.version_info.major}.{sys.version_info.minor}"


def _empty_report(start: float) -> HealthReport:
    """Return a report for an empty/no-file project."""
    return HealthReport(
        score=100.0,
        label="Healthy",
        category_scores=[],
        diagnostics=[],
        project=ProjectInfo(
            python_version=_detect_python_version(),
            framework=None,
            total_files=0,
            total_lines=0,
        ),
        duration_ms=int((time.monotonic() - start) * 1000),
        coverage=CoverageInfo(profile=PROFILE_DEFAULT, confidence="limited"),
    )


def _build_coverage(
    *,
    plan: ScanPlan,
    analyzers_used: list[str],
    analyzers_skipped: list[str],
    optional_unavailable: list[str],
    request_metadata: dict[str, object] | None = None,
) -> CoverageInfo:
    """Build coverage metadata for a completed analysis run."""
    scored_categories: set[Category] = set()
    category_coverage: list[CategoryCoverage] = []
    partial_reasons: list[str] = []

    used_set = set(analyzers_used)
    request_metadata = request_metadata or {}

    for category in sorted(plan.categories, key=lambda c: c.value):
        category_analyzers = [
            info.name
            for info in ANALYZER_CATALOG.values()
            if category in info.categories
            and plan.profile in info.profiles
            and (plan.include_optional or not info.optional)
        ]
        used_for_category = [name for name in category_analyzers if name in used_set]
        if used_for_category:
            status = "scored"
            reason = ""
            if (
                category == Category.SECURITY
                and "detect-secrets" in optional_unavailable
            ):
                status = "partial"
                reason = "optional secret scan not installed"
            elif (
                category == Category.DEPENDENCIES
                and "dependency-vulns" in optional_unavailable
            ):
                status = "partial"
                reason = "optional dependency vulnerability scan not installed"
            category_coverage.append(
                CategoryCoverage(
                    category=category,
                    status=status,
                    analyzers=used_for_category,
                    reason=reason,
                )
            )
            scored_categories.add(category)
            if reason:
                partial_reasons.append(f"{category.value}: {reason}")
        else:
            category_coverage.append(
                CategoryCoverage(
                    category=category,
                    status="unavailable",
                    analyzers=[],
                    reason="no analyzer ran for this category",
                )
            )

    # Add entries for categories explicitly skipped by the user
    for category in sorted(plan.skipped_categories, key=lambda c: c.value):
        category_coverage.append(
            CategoryCoverage(
                category=category,
                status="skipped_by_user",
                analyzers=[],
                reason="excluded via --skip",
            )
        )

    confidence = "full"
    if partial_reasons:
        confidence = "partial"
    if len(scored_categories) < len(plan.categories):
        confidence = "limited"

    # Build provenance notes for the output (e.g. "scanned from uv.lock (42 packages)")
    provenance: list[str] = []
    dep_source = request_metadata.get("dependency_vulns_source")
    dep_count = request_metadata.get("dependency_vulns_package_count")
    dep_note = request_metadata.get("dependency_vulns_note")
    if isinstance(dep_source, str) and isinstance(dep_count, int):
        provenance.append(
            f"Dependency vulnerabilities: scanned from {dep_source} "
            f"({dep_count} packages)"
        )
    elif isinstance(dep_note, str):
        provenance.append(f"Dependency vulnerabilities: skipped ({dep_note})")

    return CoverageInfo(
        profile=plan.profile,
        confidence=confidence,
        requested_categories=sorted(plan.categories, key=lambda c: c.value),
        scored_categories=sorted(scored_categories, key=lambda c: c.value),
        category_coverage=category_coverage,
        analyzers_used=analyzers_used,
        analyzers_missing=[],
        analyzers_optional_unavailable=optional_unavailable,
        partial_reasons=partial_reasons,
        provenance=provenance,
    )
