"""JSON output formatter."""

from __future__ import annotations

import json
from dataclasses import asdict
from pathlib import Path
from typing import Any

from python_doctor.models import HealthReport


def format_json(report: HealthReport) -> str:
    """Serialize a HealthReport to JSON."""
    data = asdict(report)
    return json.dumps(data, indent=2, default=_json_serializer)


def _json_serializer(obj: Any) -> Any:
    """Handle non-serializable types."""
    if isinstance(obj, Path):
        return str(obj)
    if hasattr(obj, "value"):  # Enum
        return obj.value
    msg = f"Object of type {type(obj)} is not JSON serializable"
    raise TypeError(msg)
