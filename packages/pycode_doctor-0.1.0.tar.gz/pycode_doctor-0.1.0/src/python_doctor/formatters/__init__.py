"""Output formatters for python-doctor results."""
