"""Badge URL generation for README.md.

Generates shields.io badge URLs and markdown snippets
that display the python-doctor health score.
"""

from __future__ import annotations

from urllib.parse import quote


def generate_badge_url(score: float) -> str:
    """Generate a shields.io badge URL for the given score.

    Example output:
        https://img.shields.io/badge/python--doctor-87%2F100-brightgreen
    """
    score_int = round(score)
    color = _badge_color(score_int)
    label = quote("python-doctor")
    value = quote(f"{score_int}/100")
    return f"https://img.shields.io/badge/{label}-{value}-{color}"


def generate_badge_markdown(score: float, repo_url: str = "") -> str:
    """Generate complete markdown for a README badge.

    If repo_url is provided, the badge links to it.
    """
    url = generate_badge_url(score)
    alt = f"python-doctor: {round(score)}/100"
    if repo_url:
        return f"[![{alt}]({url})]({repo_url})"
    return f"![{alt}]({url})"


def _badge_color(score: int) -> str:
    """Map a score to a shields.io color name."""
    if score >= 75:
        return "brightgreen"
    elif score >= 50:
        return "yellow"
    else:
        return "red"
