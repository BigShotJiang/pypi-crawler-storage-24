"""python-doctor: Fast, local-first Python code health checker."""

from importlib.metadata import PackageNotFoundError, version

try:
    __version__ = version("pycode-doctor")
except PackageNotFoundError:
    __version__ = "0.1.0"
