"""Tests for the typos analyzer."""

from __future__ import annotations

import json
from pathlib import Path
from unittest.mock import AsyncMock, patch

from python_doctor.analysis_request import AnalysisRequest
from python_doctor.analyzers.typos_analyzer import TyposAnalyzer
from python_doctor.config import DoctorConfig
from python_doctor.models import Category, Severity


def _request(tmp_path: Path) -> AnalysisRequest:
    file_path = tmp_path / "app.py"
    file_path.write_text("teh = 1\n")
    return AnalysisRequest(
        project_root=tmp_path,
        files=[file_path],
        config=DoctorConfig(),
        categories={Category.QUALITY},
        profile="full",
    )


class TestTyposAnalyzer:
    def test_name_and_category(self) -> None:
        analyzer = TyposAnalyzer()
        assert analyzer.name == "typos"
        assert analyzer.category == Category.QUALITY

    @patch("shutil.which", return_value="/usr/bin/typos")
    async def test_is_available_true(self, mock_which: AsyncMock) -> None:
        analyzer = TyposAnalyzer()
        assert await analyzer.is_available() is True

    @patch("asyncio.create_subprocess_exec")
    async def test_parses_json_lines(
        self, mock_exec: AsyncMock, tmp_path: Path
    ) -> None:
        output = json.dumps(
            {
                "path": str(tmp_path / "app.py"),
                "line_num": 1,
                "byte_offset": 1,
                "typo": "teh",
                "corrections": ["the"],
            }
        )
        mock_proc = AsyncMock()
        mock_proc.communicate.return_value = (output.encode(), b"")
        mock_proc.returncode = 2
        mock_exec.return_value = mock_proc

        analyzer = TyposAnalyzer()
        results = await analyzer.analyze(_request(tmp_path))
        assert len(results) == 1
        assert results[0].severity == Severity.INFO
        assert results[0].rule_id == "TYPOS"
        assert "the" in (results[0].fix or "")
