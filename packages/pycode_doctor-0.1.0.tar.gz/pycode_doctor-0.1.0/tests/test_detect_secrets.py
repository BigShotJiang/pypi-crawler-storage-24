"""Tests for the detect-secrets analyzer."""

from __future__ import annotations

from pathlib import Path
from unittest.mock import MagicMock, patch

from python_doctor.analysis_request import AnalysisRequest
from python_doctor.analyzers.detect_secrets_analyzer import DetectSecretsAnalyzer
from python_doctor.config import DoctorConfig
from python_doctor.models import Category, Severity


def _request(files: list[Path]) -> AnalysisRequest:
    root = files[0].parent if files else Path(".")
    return AnalysisRequest(
        project_root=root,
        files=files,
        config=DoctorConfig(),
        categories={Category.SECURITY},
        profile="full",
    )


class TestDetectSecretsAnalyzer:
    def test_name_and_category(self) -> None:
        analyzer = DetectSecretsAnalyzer()
        assert analyzer.name == "detect-secrets"
        assert analyzer.category == Category.SECURITY

    @patch.dict("sys.modules", {"detect_secrets": MagicMock()})
    async def test_is_available_when_installed(self) -> None:
        analyzer = DetectSecretsAnalyzer()
        result = await analyzer.is_available()
        assert result is True

    async def test_empty_files(self) -> None:
        analyzer = DetectSecretsAnalyzer()
        results = await analyzer.analyze(_request([]))
        assert results == []

    def test_analyze_sync_with_secrets(self) -> None:
        """Test the synchronous analysis path with mocked detect-secrets."""
        mock_secrets_collection = MagicMock()
        mock_secrets_collection.json.return_value = {
            "src/config.py": [
                {
                    "type": "AWS Access Key",
                    "line_number": 5,
                    "hashed_secret": "abc123",
                },
                {
                    "type": "High Entropy String",
                    "line_number": 12,
                    "hashed_secret": "def456",
                },
            ],
            "src/auth.py": [
                {
                    "type": "Private Key",
                    "line_number": 1,
                    "hashed_secret": "ghi789",
                },
            ],
        }

        mock_module = MagicMock()
        mock_module.SecretsCollection.return_value = mock_secrets_collection

        mock_settings = MagicMock()
        mock_settings.default_settings.return_value.__enter__ = MagicMock()
        mock_settings.default_settings.return_value.__exit__ = MagicMock(
            return_value=False
        )

        with (
            patch.dict(
                "sys.modules",
                {
                    "detect_secrets": mock_module,
                    "detect_secrets.settings": mock_settings,
                },
            ),
        ):
            analyzer = DetectSecretsAnalyzer()
            results = analyzer._analyze_sync(
                [Path("src/config.py"), Path("src/auth.py")]
            )

        assert len(results) == 3

        # First secret: AWS Access Key
        assert results[0].rule_id == "SECRET-AWS-ACCESS-KEY"
        assert results[0].severity == Severity.ERROR
        assert results[0].category == Category.SECURITY
        assert results[0].line == 5
        assert results[0].tool == "detect-secrets"
        assert "AWS Access Key" in results[0].message
        assert "environment variable" in (results[0].fix or "")

        # Second secret: High Entropy String
        assert results[1].rule_id == "SECRET-HIGH-ENTROPY-STRING"
        assert results[1].line == 12

        # Third secret: Private Key
        assert results[2].rule_id == "SECRET-PRIVATE-KEY"
        assert results[2].file_path == Path("src/auth.py")

    def test_analyze_sync_clean_project(self) -> None:
        """Test sync analysis with no secrets found."""
        mock_secrets_collection = MagicMock()
        mock_secrets_collection.json.return_value = {}

        mock_module = MagicMock()
        mock_module.SecretsCollection.return_value = mock_secrets_collection

        mock_settings = MagicMock()
        mock_settings.default_settings.return_value.__enter__ = MagicMock()
        mock_settings.default_settings.return_value.__exit__ = MagicMock(
            return_value=False
        )

        with patch.dict(
            "sys.modules",
            {
                "detect_secrets": mock_module,
                "detect_secrets.settings": mock_settings,
            },
        ):
            analyzer = DetectSecretsAnalyzer()
            results = analyzer._analyze_sync([Path("src/app.py")])

        assert results == []

    def test_analyze_sync_import_error(self) -> None:
        """Gracefully handle missing detect-secrets."""
        # Remove detect_secrets from sys.modules if present
        with patch.dict("sys.modules", {"detect_secrets": None}):
            analyzer = DetectSecretsAnalyzer()
            # _analyze_sync catches ImportError
            results = analyzer._analyze_sync([Path("src/app.py")])
        assert results == []

    def test_analyze_sync_scan_error(self) -> None:
        """Handle file scan errors gracefully."""
        mock_secrets_collection = MagicMock()
        mock_secrets_collection.scan_file.side_effect = Exception("permission denied")
        mock_secrets_collection.json.return_value = {}

        mock_module = MagicMock()
        mock_module.SecretsCollection.return_value = mock_secrets_collection

        mock_settings = MagicMock()
        mock_settings.default_settings.return_value.__enter__ = MagicMock()
        mock_settings.default_settings.return_value.__exit__ = MagicMock(
            return_value=False
        )

        with patch.dict(
            "sys.modules",
            {
                "detect_secrets": mock_module,
                "detect_secrets.settings": mock_settings,
            },
        ):
            analyzer = DetectSecretsAnalyzer()
            results = analyzer._analyze_sync([Path("unreadable.py")])

        assert results == []
