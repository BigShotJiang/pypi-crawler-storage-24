"""Tests for the deduplication engine."""

from __future__ import annotations

from pathlib import Path

from python_doctor.dedup import _normalize_rule, deduplicate
from python_doctor.models import Category, Diagnostic, Severity


def _make_diag(
    tool: str,
    rule_id: str,
    file: str = "test.py",
    line: int = 10,
    category: Category = Category.SECURITY,
) -> Diagnostic:
    return Diagnostic(
        file_path=Path(file),
        line=line,
        column=0,
        severity=Severity.ERROR,
        rule_id=rule_id,
        tool=tool,
        category=category,
        message=f"test {rule_id}",
    )


class TestDeduplication:
    def test_ruff_wins_over_bandit(self) -> None:
        """Ruff S101 takes priority over Bandit B101 on the same line."""
        diags = [
            _make_diag("ruff", "S101", line=10),
            _make_diag("bandit", "B101", line=10),
        ]
        result = deduplicate(diags)
        assert len(result) == 1
        assert result[0].tool == "ruff"
        assert result[0].rule_id == "S101"

    def test_bandit_unique_rules_survive(self) -> None:
        """Bandit-only rules (B614, B615) are never deduplicated."""
        diags = [
            _make_diag("ruff", "S101", line=10),
            _make_diag("bandit", "B614", line=15),
        ]
        result = deduplicate(diags)
        assert len(result) == 2

    def test_different_lines_not_deduped(self) -> None:
        """Same rule on different lines should both survive."""
        diags = [
            _make_diag("ruff", "S101", line=10),
            _make_diag("bandit", "B101", line=20),
        ]
        result = deduplicate(diags)
        assert len(result) == 2

    def test_different_files_not_deduped(self) -> None:
        """Same rule in different files should both survive."""
        diags = [
            _make_diag("ruff", "S101", file="a.py", line=10),
            _make_diag("bandit", "B101", file="b.py", line=10),
        ]
        result = deduplicate(diags)
        assert len(result) == 2

    def test_non_overlapping_tools_unaffected(self) -> None:
        """Diagnostics from non-overlapping tools pass through."""
        diags = [
            _make_diag("ruff", "F401", category=Category.QUALITY),
            _make_diag("mypy", "mypy-return-value", category=Category.TYPE_SAFETY),
            _make_diag("radon", "CC-D", category=Category.COMPLEXITY),
            _make_diag("vulture", "V-function", category=Category.DEAD_CODE),
        ]
        result = deduplicate(diags)
        assert len(result) == 4

    def test_empty_input(self) -> None:
        assert deduplicate([]) == []

    def test_order_preserved_for_non_overlapping(self) -> None:
        """Non-overlapping diagnostics maintain stable order by tool priority."""
        diags = [
            _make_diag("vulture", "V-import", line=1, category=Category.DEAD_CODE),
            _make_diag("ruff", "F401", line=2, category=Category.QUALITY),
        ]
        result = deduplicate(diags)
        assert len(result) == 2
        # Ruff should come first due to priority sorting
        assert result[0].tool == "ruff"
        assert result[1].tool == "vulture"


class TestNormalizeRule:
    def test_bandit_to_ruff(self) -> None:
        assert _normalize_rule("bandit", "B101") == "S101"
        assert _normalize_rule("bandit", "B608") == "S608"

    def test_bandit_unique_unchanged(self) -> None:
        assert _normalize_rule("bandit", "B614") == "B614"
        assert _normalize_rule("bandit", "B615") == "B615"

    def test_ruff_unchanged(self) -> None:
        assert _normalize_rule("ruff", "S101") == "S101"
        assert _normalize_rule("ruff", "F401") == "F401"

    def test_other_tools_unchanged(self) -> None:
        assert _normalize_rule("mypy", "mypy-return-value") == "mypy-return-value"
        assert _normalize_rule("radon", "CC-D") == "CC-D"
