"""Tests for the Radon analyzer."""

from __future__ import annotations

from pathlib import Path

import pytest

from python_doctor.analysis_request import AnalysisRequest
from python_doctor.analyzers.radon_analyzer import RadonAnalyzer
from python_doctor.config import DoctorConfig
from python_doctor.models import Category


def _request(files: list[Path]) -> AnalysisRequest:
    root = files[0].parent if files else Path(".")
    return AnalysisRequest(
        project_root=root,
        files=files,
        config=DoctorConfig(),
        categories={Category.COMPLEXITY},
        profile="default",
        metadata={},
    )


class TestRadonAnalyzer:
    async def test_name_and_category(self) -> None:
        analyzer = RadonAnalyzer()
        assert analyzer.name == "radon"
        assert analyzer.category == Category.COMPLEXITY

    async def test_analyze_high_complexity(self, tmp_path: Path) -> None:
        analyzer = RadonAnalyzer()
        if not await analyzer.is_available():
            pytest.skip("Radon not available")

        # Write a deliberately complex function
        complex_file = tmp_path / "complex.py"
        complex_file.write_text(
            "def tangled(a, b, c, d, e, f):\n"
            "    if a:\n"
            "        if b:\n"
            "            if c:\n"
            "                if d:\n"
            "                    if e:\n"
            "                        if f:\n"
            "                            return 1\n"
            "                        else:\n"
            "                            return 2\n"
            "                    else:\n"
            "                        return 3\n"
            "                else:\n"
            "                    return 4\n"
            "            else:\n"
            "                return 5\n"
            "        else:\n"
            "            return 6\n"
            "    elif b:\n"
            "        if c:\n"
            "            return 7\n"
            "        else:\n"
            "            return 8\n"
            "    elif c:\n"
            "        return 9\n"
            "    elif d:\n"
            "        return 10\n"
            "    else:\n"
            "        return 11\n"
        )

        request = _request([complex_file])
        results = await analyzer.analyze(request)

        assert len(results) > 0
        assert results[0].tool == "radon"
        assert results[0].category == Category.COMPLEXITY
        assert "tangled" in results[0].message
        assert results[0].rule_id.startswith("CC-")

        # Check MI scores were stored
        assert "_radon_mi_scores" in request.metadata
        mi_scores = request.metadata["_radon_mi_scores"]
        assert isinstance(mi_scores, list)
        assert len(mi_scores) > 0

    async def test_analyze_simple_function(self, tmp_path: Path) -> None:
        analyzer = RadonAnalyzer()
        if not await analyzer.is_available():
            pytest.skip("Radon not available")

        simple_file = tmp_path / "simple.py"
        simple_file.write_text("def add(a: int, b: int) -> int:\n" "    return a + b\n")

        request = _request([simple_file])
        results = await analyzer.analyze(request)

        # Simple function (CC=1, grade A) should not produce diagnostics
        assert len(results) == 0

        # But MI score should still be computed
        assert "_radon_mi_scores" in request.metadata
        mi_scores = request.metadata["_radon_mi_scores"]
        assert isinstance(mi_scores, list)
        assert mi_scores[0] > 50  # Simple code = high MI

    async def test_analyze_empty_files(self) -> None:
        analyzer = RadonAnalyzer()
        results = await analyzer.analyze(_request([]))
        assert results == []
