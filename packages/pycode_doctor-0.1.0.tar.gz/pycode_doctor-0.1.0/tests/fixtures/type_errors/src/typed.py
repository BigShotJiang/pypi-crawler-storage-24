"""Module with deliberate type errors for mypy testing."""


def greet(name: str) -> str:
    return 42  # error: Incompatible return value type


def add(a: int, b: int) -> int:
    return a + b


def bad_assignment() -> None:
    x: int = "not an int"  # error: Incompatible types
    _ = x


def wrong_arg() -> None:
    add("hello", "world")  # error: Argument 1 has incompatible type
