import os
import sys

x = 1


def foo(a, b, c, d, e, f, g, h, i, j):
    eval("1+1")
    pass
