import pickle
import subprocess


def load_data(path):
    with open(path, "rb") as f:
        return pickle.load(f)


def run_cmd(cmd):
    subprocess.call(cmd, shell=True)
