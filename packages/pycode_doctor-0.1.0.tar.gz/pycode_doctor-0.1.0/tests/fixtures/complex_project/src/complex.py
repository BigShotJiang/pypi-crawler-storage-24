"""Module with high-complexity functions for Radon testing."""


def process_data(data, mode, options, flags, context):
    """This function has deliberately high cyclomatic complexity."""
    result = []
    if mode == "fast":
        if options.get("parallel"):
            if flags & 0x01:
                for item in data:
                    if item.get("type") == "A":
                        if item.get("status") == "active":
                            result.append(item["value"] * 2)
                        elif item.get("status") == "pending":
                            result.append(item["value"])
                        else:
                            result.append(0)
                    elif item.get("type") == "B":
                        if context.get("strict"):
                            result.append(item["value"] * 3)
                        else:
                            result.append(item["value"] * 2)
                    else:
                        result.append(item.get("value", 0))
            else:
                for item in data:
                    result.append(item.get("value", 0))
        else:
            for item in data:
                if item.get("type") == "A":
                    result.append(item["value"])
                else:
                    result.append(0)
    elif mode == "safe":
        for item in data:
            try:
                result.append(int(item.get("value", 0)))
            except (ValueError, TypeError):
                result.append(0)
    else:
        result = [item.get("value") for item in data]
    return result


def simple_function(x: int) -> int:
    """Grade A complexity -- should NOT produce a diagnostic."""
    return x * 2
