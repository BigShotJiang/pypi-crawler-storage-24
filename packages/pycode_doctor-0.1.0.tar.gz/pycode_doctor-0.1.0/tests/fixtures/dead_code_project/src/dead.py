"""Module with dead code for Vulture testing."""

import os  # unused import
import json  # used below


def used_function() -> str:
    return json.dumps({"status": "ok"})


def unused_function() -> str:
    """This function is never called."""
    return "I am dead code"


class UnusedClass:
    """This class is never instantiated."""

    def method(self) -> None:
        pass


def _helper() -> int:
    """Private helper that nothing calls."""
    return 42


UNUSED_CONSTANT = "this is never referenced"

active_constant = "this IS used"


def uses_active() -> str:
    return active_constant
