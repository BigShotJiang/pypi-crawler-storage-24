"""Tests for the scoring engine."""

from pathlib import Path

from python_doctor.config import DEFAULT_WEIGHTS, DoctorConfig
from python_doctor.models import (
    Category,
    Diagnostic,
    ProjectInfo,
    Severity,
)
from python_doctor.scoring.engine import (
    CRITICAL_RULES,
    _score_complexity,
    _score_dead_code,
    _score_dependencies,
    _score_quality,
    _score_security,
    _score_type_safety,
    compute_health_report,
    redistribute_weights,
)


def _diag(
    rule_id: str = "F401",
    severity: Severity = Severity.ERROR,
    category: Category = Category.QUALITY,
    file_path: str = "test.py",
    line: int = 1,
    end_line: int | None = None,
) -> Diagnostic:
    return Diagnostic(
        file_path=Path(file_path),
        line=line,
        column=0,
        severity=severity,
        rule_id=rule_id,
        tool="test",
        category=category,
        message="test",
        end_line=end_line,
    )


class TestScoreQuality:
    def test_perfect_score(self) -> None:
        assert _score_quality([], 10.0) == 100.0

    def test_errors_penalized_more(self) -> None:
        diags = [_diag(severity=Severity.ERROR)] * 10
        score_errors = _score_quality(diags, 1.0)
        diags_warn = [_diag(severity=Severity.WARNING)] * 10
        score_warnings = _score_quality(diags_warn, 1.0)
        assert score_errors < score_warnings

    def test_normalized_by_kloc(self) -> None:
        diags = [_diag()] * 10
        small = _score_quality(diags, 1.0)
        large = _score_quality(diags, 10.0)
        assert large > small

    def test_floors_at_zero(self) -> None:
        diags = [_diag()] * 1000
        assert _score_quality(diags, 1.0) == 0.0

    def test_info_not_penalized(self) -> None:
        diags = [_diag(severity=Severity.INFO)] * 100
        assert _score_quality(diags, 1.0) == 100.0

    def test_mixed_severities(self) -> None:
        diags = [
            _diag(severity=Severity.ERROR),
            _diag(severity=Severity.WARNING),
            _diag(severity=Severity.INFO),
        ]
        score = _score_quality(diags, 1.0)
        # 100 - (3*1/1) - (1*1/1) = 96
        assert score == 96.0


class TestScoreTypeSafety:
    def test_perfect_score(self) -> None:
        assert _score_type_safety([], 100) == 100.0

    def test_all_files_with_errors(self) -> None:
        diags = [
            _diag(
                category=Category.TYPE_SAFETY,
                file_path=f"f{i}.py",
            )
            for i in range(10)
        ]
        assert _score_type_safety(diags, 10) == 0.0

    def test_partial_typing(self) -> None:
        diags = [
            _diag(
                category=Category.TYPE_SAFETY,
                file_path=f"f{i}.py",
            )
            for i in range(2)
        ]
        score = _score_type_safety(diags, 10)
        assert score == 80.0

    def test_no_files(self) -> None:
        assert _score_type_safety([], 0) == 100.0

    def test_warnings_dont_count(self) -> None:
        """Only errors count against file pass rate."""
        diags = [
            _diag(
                severity=Severity.WARNING,
                category=Category.TYPE_SAFETY,
                file_path="f1.py",
            )
        ]
        assert _score_type_safety(diags, 10) == 100.0

    def test_multiple_errors_same_file(self) -> None:
        """Multiple errors in one file only count once."""
        diags = [
            _diag(
                category=Category.TYPE_SAFETY,
                file_path="f1.py",
                line=i,
            )
            for i in range(5)
        ]
        score = _score_type_safety(diags, 10)
        assert score == 90.0  # Only 1 file fails out of 10


class TestScoreSecurity:
    def test_perfect_score(self) -> None:
        assert _score_security([]) == 100.0

    def test_high_severity(self) -> None:
        diags = [
            _diag(
                severity=Severity.ERROR,
                category=Category.SECURITY,
            )
        ]
        score = _score_security(diags)
        assert score == 85.0

    def test_critical_cap(self) -> None:
        diags = [
            _diag(
                rule_id="S608",
                severity=Severity.ERROR,
                category=Category.SECURITY,
            )
        ]
        score = _score_security(diags)
        assert score == 25.0

    def test_many_low_severity(self) -> None:
        diags = [
            _diag(
                severity=Severity.INFO,
                category=Category.SECURITY,
            )
        ] * 5
        score = _score_security(diags)
        assert score == 95.0

    def test_critical_cap_overrides_penalty(self) -> None:
        """Critical cap at 25 even if penalty-based score higher."""
        diags = [
            _diag(
                rule_id="B301",
                severity=Severity.WARNING,
                category=Category.SECURITY,
            )
        ]
        # Penalty: 100 - 5 = 95, but capped at 25
        score = _score_security(diags)
        assert score == 25.0

    def test_critical_plus_other_issues(self) -> None:
        """Critical + many other issues can go below 25."""
        diags = [
            _diag(
                rule_id="S608",
                severity=Severity.ERROR,
                category=Category.SECURITY,
            )
        ] + [
            _diag(
                severity=Severity.ERROR,
                category=Category.SECURITY,
            )
        ] * 10
        score = _score_security(diags)
        # 100 - 11*15 = -65, capped at 0
        assert score == 0.0

    def test_floors_at_zero(self) -> None:
        diags = [
            _diag(
                severity=Severity.ERROR,
                category=Category.SECURITY,
            )
        ] * 20
        assert _score_security(diags) == 0.0


class TestScoreComplexity:
    def test_from_mi_scores(self) -> None:
        assert _score_complexity([80.0, 70.0, 90.0], []) == 80.0

    def test_fallback_to_diagnostics(self) -> None:
        diags = [_diag(category=Category.COMPLEXITY)] * 5
        score = _score_complexity([], diags)
        assert score == 75.0

    def test_no_data(self) -> None:
        assert _score_complexity([], []) == 100.0

    def test_mi_takes_precedence(self) -> None:
        """MI scores are used even if diagnostics exist."""
        diags = [_diag(category=Category.COMPLEXITY)] * 10
        score = _score_complexity([90.0], diags)
        assert score == 90.0

    def test_mi_clamped(self) -> None:
        """MI scores above 100 clamped."""
        assert _score_complexity([120.0], []) == 100.0


class TestScoreDeadCode:
    def test_no_dead_code(self) -> None:
        assert _score_dead_code([], 1000) == 100.0

    def test_ten_percent_dead(self) -> None:
        diags = [
            _diag(
                category=Category.DEAD_CODE,
                line=1,
                end_line=100,
            )
        ]
        score = _score_dead_code(diags, 1000)
        assert score == 80.0

    def test_fifty_percent_dead(self) -> None:
        diags = [
            _diag(
                category=Category.DEAD_CODE,
                line=1,
                end_line=500,
            )
        ]
        score = _score_dead_code(diags, 1000)
        assert score == 0.0

    def test_no_files(self) -> None:
        assert _score_dead_code([], 0) == 100.0

    def test_single_line_dead_code(self) -> None:
        """Diagnostics without end_line count as 1 line."""
        diags = [_diag(category=Category.DEAD_CODE, line=5)] * 10
        score = _score_dead_code(diags, 1000)
        # 10/1000 = 1%, penalty = 2% -> score = 98
        assert score == 98.0


class TestScoreDependencies:
    def test_no_issues(self) -> None:
        assert _score_dependencies([]) == 100.0

    def test_vulnerability(self) -> None:
        diags = [
            _diag(
                rule_id="CVE-2024-1234",
                category=Category.DEPENDENCIES,
            )
        ]
        assert _score_dependencies(diags) == 90.0

    def test_unused_dep(self) -> None:
        diags = [
            _diag(
                rule_id="DEP002",
                category=Category.DEPENDENCIES,
            )
        ]
        assert _score_dependencies(diags) == 95.0

    def test_missing_dep(self) -> None:
        diags = [
            _diag(
                rule_id="DEP001",
                category=Category.DEPENDENCIES,
            )
        ]
        assert _score_dependencies(diags) == 97.0

    def test_transitive_dep(self) -> None:
        diags = [
            _diag(
                rule_id="DEP003",
                category=Category.DEPENDENCIES,
            )
        ]
        assert _score_dependencies(diags) == 98.0

    def test_ghsa_vulnerability(self) -> None:
        diags = [
            _diag(
                rule_id="GHSA-xxxx-yyyy",
                category=Category.DEPENDENCIES,
            )
        ]
        assert _score_dependencies(diags) == 90.0

    def test_floors_at_zero(self) -> None:
        diags = [
            _diag(
                rule_id="CVE-2024-0001",
                category=Category.DEPENDENCIES,
            )
        ] * 20
        assert _score_dependencies(diags) == 0.0


class TestRedistributeWeights:
    def test_all_categories(self) -> None:
        result = redistribute_weights(
            DEFAULT_WEIGHTS,
            {
                Category.QUALITY,
                Category.TYPE_SAFETY,
                Category.SECURITY,
                Category.COMPLEXITY,
                Category.DEAD_CODE,
                Category.DEPENDENCIES,
            },
        )
        assert sum(result.values()) == 100

    def test_single_category(self) -> None:
        result = redistribute_weights(DEFAULT_WEIGHTS, {Category.QUALITY})
        assert result[Category.QUALITY] == 100

    def test_two_categories(self) -> None:
        result = redistribute_weights(
            DEFAULT_WEIGHTS,
            {Category.QUALITY, Category.SECURITY},
        )
        assert sum(result.values()) == 100
        assert result[Category.QUALITY] > result[Category.SECURITY]

    def test_empty(self) -> None:
        result = redistribute_weights(DEFAULT_WEIGHTS, set())
        assert result == {}

    def test_weights_proportional(self) -> None:
        """Removed categories redistribute proportionally."""
        result = redistribute_weights(
            DEFAULT_WEIGHTS,
            {Category.QUALITY, Category.TYPE_SAFETY},
        )
        # quality=25, types=20, total=45
        # quality: 25/45*100 = 55.6 -> 56
        # types: 20/45*100 = 44.4 -> 44
        assert result[Category.QUALITY] + result[Category.TYPE_SAFETY] == 100
        assert result[Category.QUALITY] > result[Category.TYPE_SAFETY]


class TestComputeHealthReport:
    def _project(self, total_files: int = 50, total_lines: int = 5000) -> ProjectInfo:
        return ProjectInfo("3.12", None, total_files, total_lines)

    def test_empty_project(self) -> None:
        report = compute_health_report(
            diagnostics=[],
            project=ProjectInfo("3.12", None, 0, 0),
            config=DoctorConfig(),
            duration_ms=100,
            analyzers_used=["ruff"],
            analyzers_skipped=[],
        )
        assert report.score == 100.0
        assert report.label == "Healthy"

    def test_deterministic(self) -> None:
        diags = [_diag()] * 10
        project = self._project()
        r1 = compute_health_report(diags, project, DoctorConfig(), 100, ["ruff"], [])
        r2 = compute_health_report(diags, project, DoctorConfig(), 200, ["ruff"], [])
        assert r1.score == r2.score

    def test_label_healthy(self) -> None:
        config = DoctorConfig(thresholds={"healthy": 80, "needs_work": 60})
        r = compute_health_report(
            [],
            self._project(),
            config,
            100,
            ["ruff"],
            [],
        )
        assert r.label == "Healthy"

    def test_label_needs_work(self) -> None:
        """Many errors should produce 'Needs work' label."""
        config = DoctorConfig(thresholds={"healthy": 80, "needs_work": 60})
        # Create enough errors to drop quality below 80
        # With 5 KLOC, need many errors to drop below 80
        diags = [_diag()] * 200
        r = compute_health_report(
            diags,
            self._project(),
            config,
            100,
            ["ruff"],
            [],
        )
        assert r.label == "Needs work" or r.label == "Critical"

    def test_label_critical(self) -> None:
        config = DoctorConfig(thresholds={"healthy": 80, "needs_work": 60})
        diags = [_diag()] * 10000
        r = compute_health_report(
            diags,
            self._project(),
            config,
            100,
            ["ruff"],
            [],
        )
        assert r.label == "Critical"

    def test_scores_sorted_by_weight(self) -> None:
        """Category scores are sorted by weight, descending."""
        r = compute_health_report(
            [],
            self._project(),
            DoctorConfig(),
            100,
            ["ruff", "mypy", "bandit", "radon", "vulture"],
            [],
        )
        weights = [cs.weight for cs in r.category_scores]
        assert weights == sorted(weights, reverse=True)

    def test_mi_scores_used(self) -> None:
        """MI scores affect complexity scoring."""
        project = self._project()
        r_no_mi = compute_health_report(
            [],
            project,
            DoctorConfig(),
            100,
            ["radon"],
            [],
            mi_scores=None,
        )
        r_low_mi = compute_health_report(
            [],
            project,
            DoctorConfig(),
            100,
            ["radon"],
            [],
            mi_scores=[30.0, 40.0],
        )
        # Without MI: complexity defaults to 100 (no diagnostics)
        # With low MI: complexity around 35
        cs_no_mi = next(
            cs for cs in r_no_mi.category_scores if cs.category == Category.COMPLEXITY
        )
        cs_low_mi = next(
            cs for cs in r_low_mi.category_scores if cs.category == Category.COMPLEXITY
        )
        assert cs_no_mi.score > cs_low_mi.score

    def test_analyzers_in_report(self) -> None:
        r = compute_health_report(
            [],
            self._project(),
            DoctorConfig(),
            100,
            ["ruff", "mypy"],
            ["bandit"],
        )
        assert r.analyzers_used == ["ruff", "mypy"]
        assert r.analyzers_skipped == ["bandit"]

    def test_custom_thresholds(self) -> None:
        """Custom thresholds from config are respected."""
        config = DoctorConfig(thresholds={"healthy": 95, "needs_work": 90})
        r = compute_health_report(
            [_diag()],
            self._project(),
            config,
            100,
            ["ruff"],
            [],
        )
        # With a stricter threshold, even a small penalty
        # can drop below "Healthy"
        assert r.score < 100.0


class TestCriticalRules:
    def test_critical_rules_exist(self) -> None:
        """Critical rules set is populated."""
        assert len(CRITICAL_RULES) > 0

    def test_sql_injection_is_critical(self) -> None:
        assert "S608" in CRITICAL_RULES
        assert "B608" in CRITICAL_RULES

    def test_pickle_is_critical(self) -> None:
        assert "S301" in CRITICAL_RULES
        assert "B301" in CRITICAL_RULES
