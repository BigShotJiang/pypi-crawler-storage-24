"""Tests for the Vulture analyzer."""

from __future__ import annotations

from pathlib import Path

import pytest

from python_doctor.analysis_request import AnalysisRequest
from python_doctor.analyzers.vulture_analyzer import VultureAnalyzer
from python_doctor.config import DoctorConfig
from python_doctor.models import Category


def _request(files: list[Path], *, min_confidence: int = 80) -> AnalysisRequest:
    root = files[0].parent if files else Path(".")
    config = DoctorConfig(min_confidence=min_confidence)
    return AnalysisRequest(
        project_root=root,
        files=files,
        config=config,
        categories={Category.DEAD_CODE},
        profile="default",
    )


class TestVultureAnalyzer:
    async def test_name_and_category(self) -> None:
        analyzer = VultureAnalyzer()
        assert analyzer.name == "vulture"
        assert analyzer.category == Category.DEAD_CODE

    async def test_analyze_dead_code(self, tmp_path: Path) -> None:
        analyzer = VultureAnalyzer()
        if not await analyzer.is_available():
            pytest.skip("Vulture not available")

        dead_file = tmp_path / "dead.py"
        dead_file.write_text(
            "import os\n"
            "\n"
            "def used_function():\n"
            '    return "hello"\n'
            "\n"
            "def unused_function():\n"
            '    return "dead code"\n'
            "\n"
            "result = used_function()\n"
        )

        results = await analyzer.analyze(_request([dead_file], min_confidence=60))

        assert len(results) > 0
        # Should detect unused import 'os' and unused_function
        names = [d.message for d in results]
        assert any("os" in name for name in names) or any(
            "unused_function" in name for name in names
        )
        assert all(d.category == Category.DEAD_CODE for d in results)

    async def test_analyze_clean_code(self, tmp_path: Path) -> None:
        analyzer = VultureAnalyzer()
        if not await analyzer.is_available():
            pytest.skip("Vulture not available")

        clean_file = tmp_path / "clean.py"
        clean_file.write_text(
            "def greet(name: str) -> str:\n"
            '    return f"Hello, {name}"\n'
            "\n"
            "result = greet('world')\n"
        )

        results = await analyzer.analyze(_request([clean_file], min_confidence=80))
        # Clean code with no dead code should produce minimal/no results
        high_confidence = [
            d for d in results if "100%" in d.message or "90%" in d.message
        ]
        assert len(high_confidence) == 0

    async def test_fresh_instance_per_run(self, tmp_path: Path) -> None:
        """Verify that each analyze() call uses a fresh Vulture instance."""
        analyzer = VultureAnalyzer()
        if not await analyzer.is_available():
            pytest.skip("Vulture not available")

        file1 = tmp_path / "file1.py"
        file1.write_text("import os\n")  # unused import

        file2 = tmp_path / "file2.py"
        file2.write_text("import json\nprint(json.dumps({}))\n")  # used

        results1 = await analyzer.analyze(_request([file1], min_confidence=60))
        results2 = await analyzer.analyze(_request([file2], min_confidence=60))

        # First run should find dead code (unused os import)
        assert len(results1) > 0
        # Second run should not carry over findings from first run
        dead_os = [d for d in results2 if "os" in d.message]
        assert len(dead_os) == 0

    async def test_analyze_empty_files(self) -> None:
        analyzer = VultureAnalyzer()
        results = await analyzer.analyze(_request([]))
        assert results == []
