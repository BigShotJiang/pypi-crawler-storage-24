"""Tests for CLI flags and output modes."""

from __future__ import annotations

import json
from contextlib import AbstractContextManager
from pathlib import Path
from typing import Any, cast
from unittest.mock import patch

from click.testing import CliRunner

from python_doctor.cli import main
from python_doctor.config import DoctorConfig
from python_doctor.models import (
    Category,
    CategoryScore,
    HealthReport,
    ProjectInfo,
)


def _make_report(score: float = 73.0, label: str = "Needs work") -> HealthReport:
    """Create a test report."""
    return HealthReport(
        score=score,
        label=label,
        category_scores=[
            CategoryScore(
                category=Category.QUALITY,
                score=78.0,
                weight=25,
                issue_count=23,
                error_count=8,
                warning_count=15,
                details="8 errors, 15 warnings",
            ),
        ],
        diagnostics=[],
        project=ProjectInfo(
            python_version="3.12",
            framework=None,
            total_files=42,
            total_lines=8500,
        ),
        duration_ms=2300,
        analyzers_used=["ruff", "mypy"],
    )


def _patch_analysis(
    report: HealthReport | None = None,
) -> tuple[
    AbstractContextManager[object],
    AbstractContextManager[object],
    AbstractContextManager[object],
]:
    """Return context managers that patch the analysis pipeline.

    The CLI uses lazy imports inside the main() function body,
    so we need to patch at the source module level.
    """
    r = report or _make_report()

    async def mock_run(**kwargs):  # type: ignore[no-untyped-def]
        return r

    return (
        patch(
            "python_doctor.config.load_config",
            return_value=DoctorConfig(),
        ),
        patch(
            "python_doctor.discovery.discover_python_files",
            return_value=[Path("test.py")],
        ),
        patch(
            "python_doctor.runner.run_analysis",
            side_effect=mock_run,
        ),
    )


class TestScoreFlag:
    """Test --score outputs only the number."""

    def setup_method(self) -> None:
        self.runner = CliRunner()

    def test_score_only_output(self) -> None:
        p1, p2, p3 = _patch_analysis(_make_report(score=73.0))
        with p1, p2, p3:
            result = self.runner.invoke(main, [".", "--score"])
        assert result.exit_code == 0
        assert result.output.strip() == "73"

    def test_score_for_ci_piping(self) -> None:
        p1, p2, p3 = _patch_analysis(_make_report(score=85.0))
        with p1, p2, p3:
            result = self.runner.invoke(main, [".", "--score"])
        score = int(result.output.strip())
        assert score == 85


class TestFailUnder:
    """Test --fail-under exit codes."""

    def setup_method(self) -> None:
        self.runner = CliRunner()

    def test_passes_when_above(self) -> None:
        p1, p2, p3 = _patch_analysis(_make_report(score=80.0))
        with p1, p2, p3:
            result = self.runner.invoke(main, [".", "--fail-under", "70", "--score"])
        assert result.exit_code == 0

    def test_fails_when_below(self) -> None:
        p1, p2, p3 = _patch_analysis(_make_report(score=65.0))
        with p1, p2, p3:
            result = self.runner.invoke(main, [".", "--fail-under", "70", "--score"])
        assert result.exit_code == 1

    def test_exact_threshold_passes(self) -> None:
        """Score exactly equal to threshold should pass."""
        p1, p2, p3 = _patch_analysis(_make_report(score=70.0))
        with p1, p2, p3:
            result = self.runner.invoke(main, [".", "--fail-under", "70", "--score"])
        assert result.exit_code == 0


class TestJsonOutput:
    """Test --json produces valid structured JSON."""

    def setup_method(self) -> None:
        self.runner = CliRunner()

    def test_valid_json(self) -> None:
        p1, p2, p3 = _patch_analysis()
        with p1, p2, p3:
            result = self.runner.invoke(main, [".", "--json"])
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert "score" in data
        assert "label" in data
        assert "category_scores" in data
        assert data["score"] == 73.0

    def test_json_with_fail_under(self) -> None:
        """--json and --fail-under should both work."""
        p1, p2, p3 = _patch_analysis(_make_report(score=60.0))
        with p1, p2, p3:
            result = self.runner.invoke(main, [".", "--json", "--fail-under", "70"])
        assert result.exit_code == 1
        data = json.loads(result.output)
        assert data["score"] == 60.0


class TestQuickFlag:
    """Test --quick skips slow analyzers."""

    def setup_method(self) -> None:
        self.runner = CliRunner()

    def test_quick_skips_mypy(self) -> None:
        p1, p2, p3 = _patch_analysis()
        with p1, p2, p3 as mock_run:
            result = self.runner.invoke(main, [".", "--quick", "--score"])
        assert result.exit_code == 0
        call_kwargs = cast(Any, mock_run).call_args[1]
        assert "mypy" in call_kwargs["skip_analyzers"]
        assert call_kwargs["plan"].profile == "quick"


class TestVersionAndHelp:
    """Test --version and --help."""

    def setup_method(self) -> None:
        self.runner = CliRunner()

    def test_version(self) -> None:
        result = self.runner.invoke(main, ["--version"])
        assert result.exit_code == 0
        assert "python-doctor" in result.output

    def test_help(self) -> None:
        result = self.runner.invoke(main, ["--help"])
        assert result.exit_code == 0
        assert "Python Doctor" in result.output
        assert "--json" in result.output
        assert "--score" in result.output
        assert "--fail-under" in result.output
        assert "--profile" in result.output
        assert "--only" in result.output
        assert "--skip" in result.output

    def test_help_shows_fix_flag(self) -> None:
        result = self.runner.invoke(main, ["--help"])
        assert "--fix" in result.output
        assert "--show-fixes" in result.output

    def test_help_shows_diff_flag(self) -> None:
        result = self.runner.invoke(main, ["--help"])
        assert "--diff" in result.output


class TestNoFlags:
    """Test --no-* flags skip categories."""

    def setup_method(self) -> None:
        self.runner = CliRunner()

    def test_no_security(self) -> None:
        p1, p2, p3 = _patch_analysis()
        with p1, p2, p3 as mock_run:
            result = self.runner.invoke(main, [".", "--no-security", "--score"])
        assert result.exit_code == 0
        call_kwargs = cast(Any, mock_run).call_args[1]
        assert "bandit" in call_kwargs["skip_analyzers"]
        assert "detect-secrets" in call_kwargs["skip_analyzers"]

    def test_no_lint(self) -> None:
        p1, p2, p3 = _patch_analysis()
        with p1, p2, p3 as mock_run:
            result = self.runner.invoke(main, [".", "--no-lint", "--score"])
        assert result.exit_code == 0
        call_kwargs = cast(Any, mock_run).call_args[1]
        assert "typos" in call_kwargs["skip_analyzers"]


class TestProfilesAndCategories:
    def setup_method(self) -> None:
        self.runner = CliRunner()

    def test_profile_full_enables_optional(self) -> None:
        p1, p2, p3 = _patch_analysis()
        with p1, p2, p3 as mock_run:
            result = self.runner.invoke(main, [".", "--profile", "full", "--score"])
        assert result.exit_code == 0
        assert cast(Any, mock_run).call_args[1]["plan"].include_optional is True

    def test_only_categories(self) -> None:
        p1, p2, p3 = _patch_analysis()
        with p1, p2, p3 as mock_run:
            result = self.runner.invoke(
                main, [".", "--only", "quality,types", "--score"]
            )
        assert result.exit_code == 0
        plan = cast(Any, mock_run).call_args[1]["plan"]
        assert len(plan.categories) == 2

    def test_skip_categories(self) -> None:
        p1, p2, p3 = _patch_analysis()
        with p1, p2, p3 as mock_run:
            result = self.runner.invoke(
                main, [".", "--skip", "security,dead_code", "--score"]
            )
        assert result.exit_code == 0
        plan = cast(Any, mock_run).call_args[1]["plan"]
        assert all(
            category.value not in {"security", "dead_code"}
            for category in plan.categories
        )


class TestTypeBackend:
    """Test --type-backend mutual exclusion."""

    def setup_method(self) -> None:
        self.runner = CliRunner()

    def test_type_backend_mypy_skips_basedpyright(self) -> None:
        p1, p2, p3 = _patch_analysis()
        with p1, p2, p3 as mock_run:
            result = self.runner.invoke(
                main, [".", "--type-backend", "mypy", "--score"]
            )
        assert result.exit_code == 0
        call_kwargs = cast(Any, mock_run).call_args[1]
        assert "basedpyright" in call_kwargs["skip_analyzers"]
        assert "mypy" not in call_kwargs["skip_analyzers"]

    def test_type_backend_basedpyright_skips_mypy(self) -> None:
        p1, p2, p3 = _patch_analysis()
        with p1, p2, p3 as mock_run:
            result = self.runner.invoke(
                main, [".", "--type-backend", "basedpyright", "--score"]
            )
        assert result.exit_code == 0
        call_kwargs = cast(Any, mock_run).call_args[1]
        assert "mypy" in call_kwargs["skip_analyzers"]
        assert "basedpyright" not in call_kwargs["skip_analyzers"]

    def test_type_backend_auto_is_default(self) -> None:
        p1, p2, p3 = _patch_analysis()
        with p1, p2, p3 as mock_run:
            result = self.runner.invoke(main, [".", "--score"])
        assert result.exit_code == 0
        plan = cast(Any, mock_run).call_args[1]["plan"]
        assert plan.type_backend == "auto"

    def test_type_backend_shown_in_help(self) -> None:
        result = self.runner.invoke(main, ["--help"])
        assert "--type-backend" in result.output
