"""Tests for configuration loading."""

from pathlib import Path

from python_doctor.config import DEFAULT_WEIGHTS, load_config


class TestLoadConfig:
    def test_defaults_when_no_pyproject(self, tmp_path: Path) -> None:
        config = load_config(tmp_path)
        assert config.weights == DEFAULT_WEIGHTS
        assert config.timeout == 60

    def test_loads_from_pyproject(self, tmp_path: Path) -> None:
        pyproject = tmp_path / "pyproject.toml"
        pyproject.write_text("""
[tool.python-doctor]
timeout = 120

[tool.python-doctor.weights]
quality = 30
types = 25
security = 20
complexity = 10
dead_code = 10
dependencies = 5

[tool.python-doctor.ignore]
rules = ["S101"]
files = ["tests/**"]
""")
        config = load_config(tmp_path)
        assert config.weights["quality"] == 30
        assert config.timeout == 120
        assert "S101" in config.ignore_rules
        assert "tests/**" in config.ignore_files

    def test_walks_up_directories(self, tmp_path: Path) -> None:
        pyproject = tmp_path / "pyproject.toml"
        pyproject.write_text("[tool.python-doctor]\ntimeout = 99\n")

        subdir = tmp_path / "src" / "deep" / "nested"
        subdir.mkdir(parents=True)

        config = load_config(subdir)
        assert config.timeout == 99

    def test_malformed_toml(self, tmp_path: Path) -> None:
        pyproject = tmp_path / "pyproject.toml"
        pyproject.write_text("this is not valid toml {{{")

        config = load_config(tmp_path)
        # Falls back to defaults
        assert config.weights == DEFAULT_WEIGHTS
