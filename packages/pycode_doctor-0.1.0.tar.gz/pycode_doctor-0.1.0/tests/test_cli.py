"""Tests for CLI interface."""

from click.testing import CliRunner

from python_doctor.cli import main


class TestCLI:
    def setup_method(self) -> None:
        self.runner = CliRunner()

    def test_version(self) -> None:
        result = self.runner.invoke(main, ["--version"])
        assert result.exit_code == 0
        assert "0.1.0" in result.output

    def test_help(self) -> None:
        result = self.runner.invoke(main, ["--help"])
        assert result.exit_code == 0
        assert "Python Doctor" in result.output

    def test_default_invocation(self) -> None:
        result = self.runner.invoke(main, ["."])
        assert result.exit_code == 0
