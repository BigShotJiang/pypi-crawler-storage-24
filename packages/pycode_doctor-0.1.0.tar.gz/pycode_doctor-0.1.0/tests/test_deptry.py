"""Tests for the deptry analyzer."""

from __future__ import annotations

import json
from pathlib import Path
from unittest.mock import AsyncMock, patch

from python_doctor.analysis_request import AnalysisRequest
from python_doctor.analyzers.deptry_analyzer import (
    DeptryAnalyzer,
    _fix_suggestion,
)
from python_doctor.config import DoctorConfig
from python_doctor.models import Category, Severity


def _request(project_root: Path, files: list[Path]) -> AnalysisRequest:
    return AnalysisRequest(
        project_root=project_root,
        files=files,
        config=DoctorConfig(),
        categories={Category.DEPENDENCIES},
        profile="default",
    )


MOCK_DEPTRY_OUTPUT = json.dumps(
    [
        {
            "error": {"code": "DEP001", "message": "Missing dependency"},
            "module": "matplotlib",
            "location": {"file": "src/plot.py", "line": 2, "column": 0},
        },
        {
            "error": {"code": "DEP002", "message": "Unused dependency"},
            "module": "pandas",
            "location": {"file": "pyproject.toml", "line": None, "column": None},
        },
    ]
)


class TestDeptryAnalyzer:
    def test_name_and_category(self) -> None:
        analyzer = DeptryAnalyzer()
        assert analyzer.name == "deptry"
        assert analyzer.category == Category.DEPENDENCIES

    @patch("shutil.which", return_value="/usr/bin/deptry")
    async def test_is_available_true(self, mock_which: AsyncMock) -> None:
        analyzer = DeptryAnalyzer()
        assert await analyzer.is_available() is True

    @patch("shutil.which", return_value=None)
    async def test_is_available_false(self, mock_which: AsyncMock) -> None:
        analyzer = DeptryAnalyzer()
        assert await analyzer.is_available() is False

    @patch("asyncio.create_subprocess_exec")
    async def test_finds_issues(self, mock_exec: AsyncMock) -> None:
        mock_proc = AsyncMock()
        mock_proc.communicate.return_value = (MOCK_DEPTRY_OUTPUT.encode(), b"")
        mock_proc.returncode = 1
        mock_exec.return_value = mock_proc

        analyzer = DeptryAnalyzer()
        results = await analyzer.analyze(_request(Path("."), [Path("src/plot.py")]))

        assert len(results) == 2

        # DEP001: missing dependency
        assert results[0].rule_id == "DEP001"
        assert results[0].severity == Severity.ERROR
        assert results[0].category == Category.DEPENDENCIES
        assert results[0].tool == "deptry"
        assert "matplotlib" in results[0].message
        assert results[0].line == 2
        assert results[0].file_path == Path("src/plot.py")

        # DEP002: unused dependency
        assert results[1].rule_id == "DEP002"
        assert results[1].severity == Severity.WARNING
        assert "pandas" in results[1].message
        assert results[1].line == 0  # None -> 0

    @patch("asyncio.create_subprocess_exec")
    async def test_clean_project(self, mock_exec: AsyncMock) -> None:
        mock_proc = AsyncMock()
        mock_proc.communicate.return_value = (b"[]", b"")
        mock_proc.returncode = 0
        mock_exec.return_value = mock_proc

        analyzer = DeptryAnalyzer()
        results = await analyzer.analyze(_request(Path("."), [Path(".")]))
        assert results == []

    @patch("asyncio.create_subprocess_exec")
    async def test_empty_output(self, mock_exec: AsyncMock) -> None:
        mock_proc = AsyncMock()
        mock_proc.communicate.return_value = (b"", b"")
        mock_proc.returncode = 0
        mock_exec.return_value = mock_proc

        analyzer = DeptryAnalyzer()
        results = await analyzer.analyze(_request(Path("."), [Path(".")]))
        assert results == []

    @patch("asyncio.create_subprocess_exec")
    async def test_invalid_json(self, mock_exec: AsyncMock) -> None:
        mock_proc = AsyncMock()
        mock_proc.communicate.return_value = (b"not json{", b"")
        mock_proc.returncode = 0
        mock_exec.return_value = mock_proc

        analyzer = DeptryAnalyzer()
        results = await analyzer.analyze(_request(Path("."), [Path(".")]))
        assert results == []

    @patch("asyncio.create_subprocess_exec")
    async def test_timeout_handling(self, mock_exec: AsyncMock) -> None:
        mock_exec.side_effect = FileNotFoundError("deptry")

        analyzer = DeptryAnalyzer()
        results = await analyzer.analyze(_request(Path("."), [Path(".")]))
        assert results == []

    @patch("asyncio.create_subprocess_exec")
    async def test_transitive_and_misplaced(self, mock_exec: AsyncMock) -> None:
        output = json.dumps(
            [
                {
                    "error": {"code": "DEP003", "message": "Transitive dependency"},
                    "module": "six",
                    "location": {
                        "file": "src/app.py",
                        "line": 3,
                        "column": 0,
                    },
                },
                {
                    "error": {"code": "DEP004", "message": "Misplaced dev dep"},
                    "module": "pytest",
                    "location": {
                        "file": "src/main.py",
                        "line": 1,
                        "column": 0,
                    },
                },
            ]
        )
        mock_proc = AsyncMock()
        mock_proc.communicate.return_value = (output.encode(), b"")
        mock_proc.returncode = 1
        mock_exec.return_value = mock_proc

        analyzer = DeptryAnalyzer()
        results = await analyzer.analyze(_request(Path("."), [Path("src/app.py")]))

        assert len(results) == 2
        assert results[0].rule_id == "DEP003"
        assert results[0].severity == Severity.WARNING
        assert results[1].rule_id == "DEP004"
        assert results[1].severity == Severity.WARNING

    @patch("asyncio.create_subprocess_exec")
    async def test_project_root_from_pyproject(
        self, mock_exec: AsyncMock, tmp_path: Path
    ) -> None:
        """Verify deptry walks up to find pyproject.toml."""
        (tmp_path / "pyproject.toml").write_text("[project]")
        src = tmp_path / "src"
        src.mkdir()
        app = src / "app.py"
        app.write_text("x = 1")

        mock_proc = AsyncMock()
        mock_proc.communicate.return_value = (b"[]", b"")
        mock_proc.returncode = 0
        mock_exec.return_value = mock_proc

        analyzer = DeptryAnalyzer()
        await analyzer.analyze(_request(tmp_path, [app]))

        # Verify deptry was called with the project root, not the file's dir
        call_args = mock_exec.call_args[0]
        assert str(tmp_path) in call_args


class TestFixSuggestion:
    def test_dep001(self) -> None:
        result = _fix_suggestion("DEP001", "numpy")
        assert "Add" in result
        assert "numpy" in result

    def test_dep002(self) -> None:
        result = _fix_suggestion("DEP002", "pandas")
        assert "Remove" in result
        assert "pandas" in result

    def test_dep003(self) -> None:
        result = _fix_suggestion("DEP003", "six")
        assert "direct dependency" in result
        assert "six" in result

    def test_dep004(self) -> None:
        result = _fix_suggestion("DEP004", "pytest")
        assert "Move" in result
        assert "pytest" in result

    def test_unknown_code(self) -> None:
        result = _fix_suggestion("DEP999", "unknown")
        assert "Review" in result
        assert "unknown" in result
