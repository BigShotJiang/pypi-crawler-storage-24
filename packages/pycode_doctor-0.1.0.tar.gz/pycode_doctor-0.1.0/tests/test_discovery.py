"""Tests for file discovery."""

from __future__ import annotations

import subprocess
from pathlib import Path

from python_doctor.discovery import (
    DEFAULT_IGNORE_DIRS,
    _rglob_discovery,
    discover_python_files,
)


class TestDiscovery:
    def test_finds_python_files(self, tmp_path: Path) -> None:
        """Basic discovery finds .py files."""
        (tmp_path / "app.py").write_text("x = 1")
        (tmp_path / "utils.py").write_text("y = 2")
        (tmp_path / "README.md").write_text("# readme")

        files = _rglob_discovery(tmp_path)
        names = {f.name for f in files}
        assert "app.py" in names
        assert "utils.py" in names
        assert "README.md" not in names

    def test_ignores_default_dirs(self, tmp_path: Path) -> None:
        """Default ignore directories are skipped."""
        src = tmp_path / "src"
        src.mkdir()
        (src / "app.py").write_text("x = 1")

        venv = tmp_path / ".venv" / "lib"
        venv.mkdir(parents=True)
        (venv / "something.py").write_text("y = 2")

        cache = tmp_path / "__pycache__"
        cache.mkdir()
        (cache / "app.cpython-312.pyc").write_text("")

        files = _rglob_discovery(tmp_path)
        paths = {str(f) for f in files}
        assert any("src/app.py" in p for p in paths)
        assert not any(".venv" in p for p in paths)
        assert not any("__pycache__" in p for p in paths)

    def test_user_ignore_patterns(self, tmp_path: Path) -> None:
        """User-configured ignore patterns are applied."""
        (tmp_path / "app.py").write_text("x = 1")
        tests_dir = tmp_path / "tests"
        tests_dir.mkdir()
        (tests_dir / "test_app.py").write_text("y = 2")

        files = discover_python_files(tmp_path, ignore_patterns=["tests/*"])
        names = {f.name for f in files}
        assert "app.py" in names
        assert "test_app.py" not in names

    def test_git_ls_files_integration(self, tmp_path: Path) -> None:
        """Test git-based discovery respects .gitignore."""
        subprocess.run(
            ["git", "init"],
            cwd=tmp_path,
            capture_output=True,
        )

        # Create .gitignore
        (tmp_path / ".gitignore").write_text("ignored/\n")

        # Create files
        (tmp_path / "tracked.py").write_text("x = 1")
        ignored_dir = tmp_path / "ignored"
        ignored_dir.mkdir()
        (ignored_dir / "secret.py").write_text("password = '123'")

        # Track files
        subprocess.run(
            ["git", "add", "."],
            cwd=tmp_path,
            capture_output=True,
        )

        files = discover_python_files(tmp_path)
        names = {f.name for f in files}
        assert "tracked.py" in names
        assert "secret.py" not in names

    def test_default_ignore_dirs_populated(self) -> None:
        """DEFAULT_IGNORE_DIRS contains expected entries."""
        assert ".venv" in DEFAULT_IGNORE_DIRS
        assert "__pycache__" in DEFAULT_IGNORE_DIRS
        assert ".git" in DEFAULT_IGNORE_DIRS
        assert "node_modules" in DEFAULT_IGNORE_DIRS
