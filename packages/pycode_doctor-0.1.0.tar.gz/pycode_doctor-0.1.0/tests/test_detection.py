"""Tests for framework detection."""

from __future__ import annotations

import time
from pathlib import Path

from python_doctor.detection import (
    FrameworkInfo,
    _has_imports,
    _in_dependency_files,
    _is_excluded,
    _sample_py_files,
    detect_framework,
)

# ---------------------------------------------------------------------------
# Django detection
# ---------------------------------------------------------------------------


class TestDjangoDetection:
    def test_detects_manage_py_plus_requirements(self, tmp_path: Path) -> None:
        """manage.py(0.3) + requirements(0.3) = 0.6 >= 0.5 → detected."""
        (tmp_path / "manage.py").write_text("#!/usr/bin/env python\nimport django\n")
        (tmp_path / "requirements.txt").write_text("django>=4.2\n")

        result = detect_framework(tmp_path)
        assert result is not None
        assert result.name == "django"
        assert result.confidence >= 0.5

    def test_detects_from_imports_and_manage_py(self, tmp_path: Path) -> None:
        """manage.py(0.3) + requirements(0.3) + imports(0.1) = 0.7."""
        src = tmp_path / "src"
        src.mkdir()
        (src / "views.py").write_text("from django.http import HttpResponse\n")
        (tmp_path / "manage.py").write_text("import django\n")
        (tmp_path / "requirements.txt").write_text("django>=4.2\n")

        result = detect_framework(tmp_path)
        assert result is not None
        assert result.name == "django"
        assert result.confidence >= 0.7

    def test_detects_settings_module(self, tmp_path: Path) -> None:
        """DJANGO_SETTINGS_MODULE(0.2) + manage.py(0.3) + requirements(0.3) = 0.8."""
        (tmp_path / "manage.py").write_text(
            'import os\nos.environ["DJANGO_SETTINGS_MODULE"] = "myapp.settings"\n'
        )
        (tmp_path / "requirements.txt").write_text("django>=4.2\n")

        result = detect_framework(tmp_path)
        assert result is not None
        assert result.name == "django"
        assert result.confidence >= 0.8

    def test_manage_py_alone_not_enough(self, tmp_path: Path) -> None:
        """manage.py(0.3) alone is below threshold."""
        (tmp_path / "manage.py").write_text("print('hello')\n")

        result = detect_framework(tmp_path)
        assert result is None

    def test_no_detection_empty_project(self, tmp_path: Path) -> None:
        (tmp_path / "app.py").write_text("print('hello')\n")
        result = detect_framework(tmp_path)
        assert result is None


# ---------------------------------------------------------------------------
# FastAPI detection
# ---------------------------------------------------------------------------


class TestFastAPIDetection:
    def test_detects_from_main_py_and_requirements(self, tmp_path: Path) -> None:
        """main.py pattern(0.3) + requirements(0.3) = 0.6 >= 0.5."""
        (tmp_path / "main.py").write_text(
            "from fastapi import FastAPI\napp = FastAPI()\n"
        )
        (tmp_path / "requirements.txt").write_text("fastapi>=0.100\nuvicorn\n")

        result = detect_framework(tmp_path)
        assert result is not None
        assert result.name == "fastapi"
        assert result.confidence >= 0.6

    def test_detects_from_app_py(self, tmp_path: Path) -> None:
        """app.py pattern(0.3) + requirements(0.3) + imports(0.1) = 0.7."""
        (tmp_path / "app.py").write_text(
            "from fastapi import FastAPI\napp = FastAPI()\n"
        )
        (tmp_path / "requirements.txt").write_text("fastapi\n")

        result = detect_framework(tmp_path)
        assert result is not None
        assert result.name == "fastapi"

    def test_api_py_detected(self, tmp_path: Path) -> None:
        """api.py with FastAPI() + requirements."""
        (tmp_path / "api.py").write_text(
            "from fastapi import FastAPI\napp = FastAPI()\n"
        )
        (tmp_path / "requirements.txt").write_text("fastapi\n")

        result = detect_framework(tmp_path)
        assert result is not None
        assert result.name == "fastapi"


# ---------------------------------------------------------------------------
# Flask detection
# ---------------------------------------------------------------------------


class TestFlaskDetection:
    def test_detects_from_app_py(self, tmp_path: Path) -> None:
        """app.py pattern(0.3) + requirements(0.3) = 0.6."""
        (tmp_path / "app.py").write_text(
            "from flask import Flask\napp = Flask(__name__)\n"
        )
        (tmp_path / "requirements.txt").write_text("flask>=3.0\n")

        result = detect_framework(tmp_path)
        assert result is not None
        assert result.name == "flask"

    def test_detects_flaskenv(self, tmp_path: Path) -> None:
        """.flaskenv(0.3) + requirements(0.3) = 0.6 >= 0.5."""
        (tmp_path / ".flaskenv").write_text("FLASK_APP=app.py\n")
        (tmp_path / "requirements.txt").write_text("flask\n")

        result = detect_framework(tmp_path)
        assert result is not None
        assert result.name == "flask"
        assert result.confidence >= 0.6

    def test_detects_wsgi_py(self, tmp_path: Path) -> None:
        """wsgi.py with Flask() + requirements."""
        (tmp_path / "wsgi.py").write_text(
            "from flask import Flask\napp = Flask(__name__)\n"
        )
        (tmp_path / "requirements.txt").write_text("flask\n")

        result = detect_framework(tmp_path)
        assert result is not None
        assert result.name == "flask"


# ---------------------------------------------------------------------------
# Framework priority
# ---------------------------------------------------------------------------


class TestFrameworkPriority:
    def test_django_over_flask_when_both_present(self, tmp_path: Path) -> None:
        """When both signals are present, highest confidence wins."""
        (tmp_path / "manage.py").write_text("import django\n")
        (tmp_path / "requirements.txt").write_text("django>=4.2\nflask>=3.0\n")

        result = detect_framework(tmp_path)
        # Django: manage.py(0.3) + requirements(0.3) = 0.6
        # Flask: requirements(0.3) -- below threshold
        assert result is not None
        assert result.name == "django"

    def test_no_framework_when_only_generic_deps(self, tmp_path: Path) -> None:
        """Generic deps like requests should not trigger detection."""
        (tmp_path / "requirements.txt").write_text("requests\nnumpy\n")
        (tmp_path / "app.py").write_text("import requests\n")

        result = detect_framework(tmp_path)
        assert result is None


# ---------------------------------------------------------------------------
# FrameworkInfo dataclass
# ---------------------------------------------------------------------------


class TestFrameworkInfo:
    def test_fields(self) -> None:
        info = FrameworkInfo(name="django", version="5.1", confidence=0.8)
        assert info.name == "django"
        assert info.version == "5.1"
        assert info.confidence == 0.8

    def test_no_version(self) -> None:
        info = FrameworkInfo(name="flask", version=None, confidence=0.6)
        assert info.version is None


# ---------------------------------------------------------------------------
# Helper functions
# ---------------------------------------------------------------------------


class TestHelpers:
    def test_is_excluded_venv(self, tmp_path: Path) -> None:
        venv_file = tmp_path / ".venv" / "lib" / "module.py"
        assert _is_excluded(venv_file, tmp_path) is True

    def test_is_excluded_normal(self, tmp_path: Path) -> None:
        normal = tmp_path / "src" / "app.py"
        assert _is_excluded(normal, tmp_path) is False

    def test_is_excluded_pycache(self, tmp_path: Path) -> None:
        cached = tmp_path / "src" / "__pycache__" / "module.cpython-314.pyc"
        assert _is_excluded(cached, tmp_path) is True

    def test_sample_py_files_limit(self, tmp_path: Path) -> None:
        src = tmp_path / "src"
        src.mkdir()
        for i in range(30):
            (src / f"mod_{i}.py").write_text(f"x = {i}\n")

        files = _sample_py_files(tmp_path, limit=10)
        assert len(files) == 10

    def test_sample_py_files_excludes_venv(self, tmp_path: Path) -> None:
        (tmp_path / "app.py").write_text("x = 1\n")
        venv = tmp_path / ".venv" / "lib"
        venv.mkdir(parents=True)
        (venv / "hidden.py").write_text("x = 2\n")

        files = _sample_py_files(tmp_path, limit=100)
        assert all(".venv" not in str(f) for f in files)

    def test_in_dependency_files_requirements(self, tmp_path: Path) -> None:
        (tmp_path / "requirements.txt").write_text("django>=4.2\nrequests\n")
        assert _in_dependency_files(tmp_path, "django") is True
        assert _in_dependency_files(tmp_path, "flask") is False

    def test_in_dependency_files_pyproject(self, tmp_path: Path) -> None:
        (tmp_path / "pyproject.toml").write_text(
            '[project]\ndependencies = ["django>=4.2"]\n'
        )
        assert _in_dependency_files(tmp_path, "django") is True

    def test_in_dependency_files_pipfile(self, tmp_path: Path) -> None:
        (tmp_path / "Pipfile").write_text('[packages]\nflask = "*"\n')
        assert _in_dependency_files(tmp_path, "flask") is True

    def test_has_imports(self, tmp_path: Path) -> None:
        (tmp_path / "views.py").write_text("from django.http import HttpResponse\n")
        assert _has_imports(tmp_path, ["from django"]) is True
        assert _has_imports(tmp_path, ["from flask"]) is False


# ---------------------------------------------------------------------------
# Performance
# ---------------------------------------------------------------------------


class TestPerformance:
    def test_detection_is_fast(self, tmp_path: Path) -> None:
        """Detection should complete in < 500ms even with many files."""
        src = tmp_path / "src"
        src.mkdir()
        for i in range(100):
            (src / f"module_{i}.py").write_text(f"x_{i} = {i}\n")

        start = time.monotonic()
        detect_framework(tmp_path)
        elapsed_ms = (time.monotonic() - start) * 1000
        assert elapsed_ms < 500  # Generous limit for CI
