"""Tests for core data models."""

import dataclasses
from pathlib import Path

import pytest

from python_doctor.models import (
    Category,
    CategoryScore,
    Diagnostic,
    HealthReport,
    ProjectInfo,
    Severity,
)


class TestDiagnostic:
    def test_creation(self) -> None:
        d = Diagnostic(
            file_path=Path("src/app.py"),
            line=10,
            column=5,
            severity=Severity.ERROR,
            rule_id="F401",
            tool="ruff",
            category=Category.QUALITY,
            message="'os' imported but unused",
            fix="Remove unused import: `os`",
            help_url="https://docs.astral.sh/ruff/rules/unused-import",
        )
        assert d.severity == Severity.ERROR
        assert d.rule_id == "F401"
        assert d.tool == "ruff"

    def test_frozen(self) -> None:
        d = Diagnostic(
            file_path=Path("test.py"),
            line=1,
            column=0,
            severity=Severity.WARNING,
            rule_id="W001",
            tool="test",
            category=Category.QUALITY,
            message="test",
        )
        # Frozen dataclass should raise on mutation
        with pytest.raises(dataclasses.FrozenInstanceError):
            d.line = 2  # type: ignore[misc]

    def test_optional_fields(self) -> None:
        d = Diagnostic(
            file_path=Path("test.py"),
            line=1,
            column=0,
            severity=Severity.INFO,
            rule_id="I001",
            tool="test",
            category=Category.QUALITY,
            message="info",
        )
        assert d.fix is None
        assert d.help_url is None
        assert d.end_line is None


class TestCategoryScore:
    def test_creation(self) -> None:
        cs = CategoryScore(
            category=Category.QUALITY,
            score=85.0,
            weight=25,
            issue_count=5,
            error_count=2,
            warning_count=3,
            details="2 errors, 3 warnings",
        )
        assert cs.score == 85.0
        assert cs.weight == 25


class TestHealthReport:
    def test_creation(self) -> None:
        report = HealthReport(
            score=78.5,
            label="Healthy",
            category_scores=[],
            diagnostics=[],
            project=ProjectInfo(
                python_version="3.12",
                framework=None,
                total_files=42,
                total_lines=5000,
            ),
            duration_ms=1234,
        )
        assert report.score == 78.5
        assert report.label == "Healthy"
