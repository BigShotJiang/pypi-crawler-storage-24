"""Tests for the dependency vulnerability analyzer."""

from __future__ import annotations

import json
import time
from pathlib import Path
from unittest.mock import AsyncMock, patch

from python_doctor.analysis_request import AnalysisRequest
from python_doctor.analyzers.dependency_vulns import (
    ADVISORY_CACHE_TTL_SECONDS,
    AdvisoryCache,
    DependencyVulnerabilityAnalyzer,
    _extract_fix_versions,
)
from python_doctor.config import DoctorConfig
from python_doctor.models import Category, Severity


def _request(project_root: Path, *, no_cache: bool = False) -> AnalysisRequest:
    return AnalysisRequest(
        project_root=project_root,
        files=[project_root / "app.py"],
        config=DoctorConfig(),
        categories={Category.DEPENDENCIES},
        profile="full",
        no_cache=no_cache,
    )


class TestDependencyVulnerabilityAnalyzer:
    def test_name_and_category(self) -> None:
        analyzer = DependencyVulnerabilityAnalyzer()
        assert analyzer.name == "dependency-vulns"
        assert analyzer.category == Category.DEPENDENCIES

    async def test_no_source(self, tmp_path: Path) -> None:
        analyzer = DependencyVulnerabilityAnalyzer()
        results = await analyzer.analyze(_request(tmp_path))
        assert results == []

    @patch("httpx.AsyncClient.post")
    async def test_uv_lock_scan(self, mock_post: AsyncMock, tmp_path: Path) -> None:
        (tmp_path / "uv.lock").write_text(
            "version = 1\n\n"
            '[[package]]\nname = "requests"\nversion = "2.31.0"\n'
            'source = { registry = "https://pypi.org/simple" }\n'
        )
        mock_response = AsyncMock()
        mock_response.raise_for_status = lambda: None
        mock_response.json = lambda: {
            "results": [{"vulns": [{"id": "GHSA-test-1234"}]}]
        }
        mock_post.return_value = mock_response

        analyzer = DependencyVulnerabilityAnalyzer()
        results = await analyzer.analyze(_request(tmp_path))

        assert len(results) == 1
        assert results[0].rule_id == "GHSA-test-1234"
        assert results[0].severity == Severity.ERROR
        assert results[0].file_path == tmp_path / "uv.lock"

    @patch("httpx.AsyncClient.post")
    async def test_pyproject_with_unpinned_dependencies_is_partial(
        self, mock_post: AsyncMock, tmp_path: Path
    ) -> None:
        (tmp_path / "pyproject.toml").write_text(
            '[project]\nname = "demo"\nversion = "0.1.0"\ndependencies = ["requests"]\n'
        )
        analyzer = DependencyVulnerabilityAnalyzer()
        request = _request(tmp_path)
        results = await analyzer.analyze(request)

        assert results == []
        assert "not pinned" in str(request.metadata.get("dependency_vulns_note", ""))


class TestAdvisoryCache:
    """Tests for the local advisory cache."""

    def test_set_and_get(self, tmp_path: Path) -> None:
        cache = AdvisoryCache(tmp_path)
        vulns = [{"id": "GHSA-1234", "summary": "bad"}]
        cache.set("requests", "2.31.0", vulns)
        result = cache.get("requests", "2.31.0")
        assert result == vulns

    def test_miss_returns_none(self, tmp_path: Path) -> None:
        cache = AdvisoryCache(tmp_path)
        assert cache.get("requests", "2.31.0") is None

    def test_stale_entry_treated_as_miss(self, tmp_path: Path) -> None:
        cache = AdvisoryCache(tmp_path)
        vulns = [{"id": "GHSA-1234"}]
        cache.set("requests", "2.31.0", vulns)
        # Backdate the entry beyond TTL
        path = cache._path("requests", "2.31.0")
        data = json.loads(path.read_text())
        data["ts"] = time.time() - ADVISORY_CACHE_TTL_SECONDS - 1
        path.write_text(json.dumps(data))
        assert cache.get("requests", "2.31.0") is None

    def test_disabled_cache_always_misses(self, tmp_path: Path) -> None:
        cache = AdvisoryCache(tmp_path, enabled=False)
        cache.set("requests", "2.31.0", [{"id": "GHSA-1234"}])
        assert cache.get("requests", "2.31.0") is None

    def test_stats_tracking(self, tmp_path: Path) -> None:
        cache = AdvisoryCache(tmp_path)
        cache.set("requests", "2.31.0", [])
        cache.get("requests", "2.31.0")  # hit
        cache.get("flask", "3.0.0")  # miss
        stats = cache.stats()
        assert stats["hits"] == 1
        assert stats["misses"] == 1
        assert stats["hit_rate_pct"] == 50

    def test_empty_vulns_are_cached(self, tmp_path: Path) -> None:
        """Clean packages (no vulns) should be cached too."""
        cache = AdvisoryCache(tmp_path)
        cache.set("safe-pkg", "1.0.0", [])
        result = cache.get("safe-pkg", "1.0.0")
        assert result == []

    def test_corrupted_entry_returns_none(self, tmp_path: Path) -> None:
        cache = AdvisoryCache(tmp_path)
        path = cache._path("requests", "2.31.0")
        path.write_text("not json at all {{{")
        assert cache.get("requests", "2.31.0") is None

    @patch("httpx.AsyncClient.post")
    async def test_cached_packages_skip_http(
        self, mock_post: AsyncMock, tmp_path: Path
    ) -> None:
        """Fully cached scans should not hit the network at all."""
        (tmp_path / "uv.lock").write_text(
            "version = 1\n\n"
            '[[package]]\nname = "requests"\nversion = "2.31.0"\n'
            'source = { registry = "https://pypi.org/simple" }\n'
        )
        # Pre-populate cache
        cache = AdvisoryCache(tmp_path)
        cache.set("requests", "2.31.0", [{"id": "GHSA-test-cached"}])

        analyzer = DependencyVulnerabilityAnalyzer()
        results = await analyzer.analyze(_request(tmp_path))

        # Should NOT have called the HTTP endpoint
        mock_post.assert_not_called()
        assert len(results) == 1
        assert results[0].rule_id == "GHSA-test-cached"

    @patch("httpx.AsyncClient.post")
    async def test_no_cache_flag_bypasses_cache(
        self, mock_post: AsyncMock, tmp_path: Path
    ) -> None:
        """--no-cache should bypass the advisory cache."""
        (tmp_path / "uv.lock").write_text(
            "version = 1\n\n"
            '[[package]]\nname = "requests"\nversion = "2.31.0"\n'
            'source = { registry = "https://pypi.org/simple" }\n'
        )
        # Pre-populate cache
        cache = AdvisoryCache(tmp_path)
        cache.set("requests", "2.31.0", [{"id": "GHSA-test-stale"}])

        mock_response = AsyncMock()
        mock_response.raise_for_status = lambda: None
        mock_response.json = lambda: {
            "results": [{"vulns": [{"id": "GHSA-test-fresh"}]}]
        }
        mock_post.return_value = mock_response

        analyzer = DependencyVulnerabilityAnalyzer()
        results = await analyzer.analyze(_request(tmp_path, no_cache=True))

        mock_post.assert_called_once()
        assert len(results) == 1
        assert results[0].rule_id == "GHSA-test-fresh"


class TestExtractFixVersions:
    """Tests for _extract_fix_versions helper."""

    def test_single_fix_version(self) -> None:
        vuln = {
            "id": "GHSA-1234",
            "affected": [
                {
                    "ranges": [
                        {
                            "type": "ECOSYSTEM",
                            "events": [
                                {"introduced": "0"},
                                {"fixed": "2.32.0"},
                            ],
                        }
                    ]
                }
            ],
        }
        assert _extract_fix_versions(vuln) == ["2.32.0"]

    def test_multiple_fix_versions(self) -> None:
        vuln = {
            "id": "GHSA-5678",
            "affected": [
                {
                    "ranges": [
                        {
                            "type": "ECOSYSTEM",
                            "events": [
                                {"introduced": "0"},
                                {"fixed": "1.5.1"},
                            ],
                        }
                    ]
                },
                {
                    "ranges": [
                        {
                            "type": "ECOSYSTEM",
                            "events": [
                                {"introduced": "2.0.0"},
                                {"fixed": "2.3.1"},
                            ],
                        }
                    ]
                },
            ],
        }
        assert _extract_fix_versions(vuln) == ["1.5.1", "2.3.1"]

    def test_no_fix_versions(self) -> None:
        vuln = {
            "id": "GHSA-nope",
            "affected": [
                {
                    "ranges": [
                        {
                            "type": "ECOSYSTEM",
                            "events": [{"introduced": "0"}],
                        }
                    ]
                }
            ],
        }
        assert _extract_fix_versions(vuln) == []

    def test_no_affected_key(self) -> None:
        assert _extract_fix_versions({"id": "GHSA-empty"}) == []

    def test_deduplicates_fix_versions(self) -> None:
        vuln = {
            "affected": [
                {
                    "ranges": [
                        {"events": [{"fixed": "1.0.1"}]},
                        {"events": [{"fixed": "1.0.1"}]},
                    ]
                }
            ]
        }
        assert _extract_fix_versions(vuln) == ["1.0.1"]

    @patch("httpx.AsyncClient.post")
    async def test_diagnostic_fix_contains_version(
        self, mock_post: AsyncMock, tmp_path: Path
    ) -> None:
        """When OSV includes fix versions, the diagnostic.fix field should name them."""
        (tmp_path / "uv.lock").write_text(
            "version = 1\n\n"
            '[[package]]\nname = "requests"\nversion = "2.31.0"\n'
            'source = { registry = "https://pypi.org/simple" }\n'
        )
        mock_response = AsyncMock()
        mock_response.raise_for_status = lambda: None
        mock_response.json = lambda: {
            "results": [
                {
                    "vulns": [
                        {
                            "id": "GHSA-fix-1234",
                            "affected": [
                                {
                                    "ranges": [
                                        {
                                            "type": "ECOSYSTEM",
                                            "events": [
                                                {"introduced": "0"},
                                                {"fixed": "2.32.0"},
                                            ],
                                        }
                                    ]
                                }
                            ],
                        }
                    ]
                }
            ]
        }
        mock_post.return_value = mock_response

        analyzer = DependencyVulnerabilityAnalyzer()
        results = await analyzer.analyze(_request(tmp_path))

        assert len(results) == 1
        assert "2.32.0" in results[0].fix
        assert "requests" in results[0].fix

    @patch("httpx.AsyncClient.post")
    async def test_diagnostic_fix_generic_when_no_version(
        self, mock_post: AsyncMock, tmp_path: Path
    ) -> None:
        """When OSV has no fix versions, fall back to generic text."""
        (tmp_path / "uv.lock").write_text(
            "version = 1\n\n"
            '[[package]]\nname = "requests"\nversion = "2.31.0"\n'
            'source = { registry = "https://pypi.org/simple" }\n'
        )
        mock_response = AsyncMock()
        mock_response.raise_for_status = lambda: None
        mock_response.json = lambda: {
            "results": [
                {
                    "vulns": [
                        {
                            "id": "GHSA-nofix",
                            "affected": [
                                {
                                    "ranges": [
                                        {
                                            "type": "ECOSYSTEM",
                                            "events": [{"introduced": "0"}],
                                        }
                                    ]
                                }
                            ],
                        }
                    ]
                }
            ]
        }
        mock_post.return_value = mock_response

        analyzer = DependencyVulnerabilityAnalyzer()
        results = await analyzer.analyze(_request(tmp_path))

        assert len(results) == 1
        assert "non-vulnerable version" in results[0].fix
