"""Tests for the MCP server tool handlers.

Tests call the handler functions directly (without MCP protocol)
to verify they return correct results.
"""

from __future__ import annotations

import json
from pathlib import Path

import pytest


class TestMCPToolHandlers:
    """Test the tool handler functions directly (without MCP protocol)."""

    @pytest.mark.asyncio
    async def test_diagnose_nonexistent_path(self) -> None:
        from python_doctor.mcp.server import python_doctor_diagnose

        result = await python_doctor_diagnose("/nonexistent/path/xyz")
        assert "Error" in result

    @pytest.mark.asyncio
    async def test_diagnose_single_file(self, tmp_path: Path) -> None:
        bad_file = tmp_path / "bad.py"
        bad_file.write_text("import os\nimport sys\nprint('hello')\n")

        from python_doctor.mcp.server import python_doctor_diagnose

        result = await python_doctor_diagnose(str(bad_file))
        data = json.loads(result)
        assert "score" in data
        assert "categoryScores" in data
        assert isinstance(data["score"], (int, float))

    @pytest.mark.asyncio
    async def test_diagnose_directory(self, tmp_path: Path) -> None:
        # Create a minimal project
        (tmp_path / "pyproject.toml").write_text(
            '[project]\nname = "test"\nversion = "0.1.0"\n'
        )
        src = tmp_path / "app.py"
        src.write_text("x: int = 1\n")

        from python_doctor.mcp.server import python_doctor_diagnose

        result = await python_doctor_diagnose(str(tmp_path))
        data = json.loads(result)
        assert "score" in data
        assert data["score"] >= 0

    @pytest.mark.asyncio
    async def test_diagnose_quick_mode(self, tmp_path: Path) -> None:
        src = tmp_path / "app.py"
        src.write_text("x: int = 1\n")

        from python_doctor.mcp.server import python_doctor_diagnose

        result = await python_doctor_diagnose(str(tmp_path), quick=True)
        data = json.loads(result)
        # Quick mode should skip mypy
        assert "score" in data

    @pytest.mark.asyncio
    async def test_lint_returns_json(self, tmp_path: Path) -> None:
        bad_file = tmp_path / "bad.py"
        bad_file.write_text("import os\nimport sys\nprint('hello')\n")

        from python_doctor.mcp.server import python_doctor_lint

        result = await python_doctor_lint([str(bad_file)])
        data = json.loads(result)
        assert "totalIssues" in data
        assert data["totalIssues"] > 0

    @pytest.mark.asyncio
    async def test_lint_clean_file(self, tmp_path: Path) -> None:
        clean_file = tmp_path / "clean.py"
        clean_file.write_text("x: int = 1\n")

        from python_doctor.mcp.server import python_doctor_lint

        result = await python_doctor_lint([str(clean_file)])
        assert "clean" in result.lower() or "no lint" in result.lower()

    @pytest.mark.asyncio
    async def test_lint_nonexistent_file(self) -> None:
        from python_doctor.mcp.server import python_doctor_lint

        result = await python_doctor_lint(["/nonexistent/file.py"])
        assert "Error" in result or "not found" in result.lower()

    @pytest.mark.asyncio
    async def test_typecheck_nonexistent_file(self) -> None:
        from python_doctor.mcp.server import python_doctor_typecheck

        result = await python_doctor_typecheck(["/nonexistent/file.py"])
        assert "Error" in result or "not found" in result.lower()

    @pytest.mark.asyncio
    async def test_security_clean_file(self, tmp_path: Path) -> None:
        clean_file = tmp_path / "clean.py"
        clean_file.write_text("x: int = 1\n")

        from python_doctor.mcp.server import python_doctor_security

        result = await python_doctor_security([str(clean_file)])
        assert "secure" in result.lower() or "no security" in result.lower()

    @pytest.mark.asyncio
    async def test_security_nonexistent_file(self) -> None:
        from python_doctor.mcp.server import python_doctor_security

        result = await python_doctor_security(["/nonexistent/file.py"])
        assert "Error" in result or "not found" in result.lower()

    @pytest.mark.asyncio
    async def test_explain_known_rule(self) -> None:
        from python_doctor.mcp.server import python_doctor_explain_rule

        result = await python_doctor_explain_rule("F401")
        assert "Unused import" in result
        assert "import" in result.lower()

    @pytest.mark.asyncio
    async def test_explain_unknown_rule(self) -> None:
        from python_doctor.mcp.server import python_doctor_explain_rule

        result = await python_doctor_explain_rule("ZZZZZ999")
        assert "unknown rule" in result.lower()

    @pytest.mark.asyncio
    async def test_explain_cross_reference(self) -> None:
        from python_doctor.mcp.server import python_doctor_explain_rule

        # S101 should cross-reference to B101 or vice versa
        result = await python_doctor_explain_rule("S101")
        assert "assert" in result.lower()

    @pytest.mark.asyncio
    async def test_explain_includes_examples(self) -> None:
        from python_doctor.mcp.server import python_doctor_explain_rule

        result = await python_doctor_explain_rule("F401")
        assert "Bad" in result
        assert "Good" in result or "fix" in result.lower()


class TestMCPFormatting:
    """Test the output formatting helpers."""

    @pytest.mark.asyncio
    async def test_report_format_has_required_fields(self, tmp_path: Path) -> None:
        src = tmp_path / "app.py"
        src.write_text("import os\nprint('hello')\n")

        from python_doctor.mcp.server import python_doctor_diagnose

        result = await python_doctor_diagnose(str(src))
        data = json.loads(result)

        assert "score" in data
        assert "label" in data
        assert "categoryScores" in data
        assert "project" in data
        assert "analyzersUsed" in data
        assert "totalIssues" in data
        assert "durationMs" in data

    @pytest.mark.asyncio
    async def test_diagnostics_format_has_required_fields(self, tmp_path: Path) -> None:
        bad_file = tmp_path / "bad.py"
        bad_file.write_text("import os\nimport sys\nprint('hello')\n")

        from python_doctor.mcp.server import python_doctor_lint

        result = await python_doctor_lint([str(bad_file)])
        data = json.loads(result)

        assert "totalIssues" in data
        assert "showing" in data
        assert "issues" in data
        for issue in data["issues"]:
            assert "file" in issue
            assert "line" in issue
            assert "ruleId" in issue
            assert "severity" in issue
            assert "message" in issue
