"""Tests for badge URL and markdown generation."""

from __future__ import annotations

from python_doctor.formatters.badge import (
    generate_badge_markdown,
    generate_badge_url,
)


class TestGenerateBadgeUrl:
    def test_high_score_brightgreen(self) -> None:
        url = generate_badge_url(87.0)
        assert "brightgreen" in url
        assert "87" in url
        assert "100" in url

    def test_medium_score_yellow(self) -> None:
        url = generate_badge_url(55.0)
        assert "yellow" in url
        assert "55" in url

    def test_low_score_red(self) -> None:
        url = generate_badge_url(30.0)
        assert "red" in url
        assert "30" in url

    def test_perfect_score(self) -> None:
        url = generate_badge_url(100.0)
        assert "brightgreen" in url
        assert "100" in url

    def test_zero_score(self) -> None:
        url = generate_badge_url(0.0)
        assert "red" in url
        assert "0" in url

    def test_boundary_75_is_green(self) -> None:
        url = generate_badge_url(75.0)
        assert "brightgreen" in url

    def test_boundary_50_is_yellow(self) -> None:
        url = generate_badge_url(50.0)
        assert "yellow" in url

    def test_boundary_49_is_red(self) -> None:
        url = generate_badge_url(49.0)
        assert "red" in url

    def test_url_starts_with_shields_io(self) -> None:
        url = generate_badge_url(80.0)
        assert url.startswith("https://img.shields.io/badge/")

    def test_url_contains_python_doctor_label(self) -> None:
        url = generate_badge_url(80.0)
        assert "python" in url
        assert "doctor" in url

    def test_score_is_rounded(self) -> None:
        url = generate_badge_url(87.6)
        assert "88" in url

    def test_url_is_properly_encoded(self) -> None:
        url = generate_badge_url(80.0)
        # Should not contain raw spaces or special chars
        assert " " not in url


class TestGenerateBadgeMarkdown:
    def test_basic_markdown_image(self) -> None:
        md = generate_badge_markdown(85.0)
        assert md.startswith("![")
        assert "python-doctor: 85/100" in md
        assert "https://img.shields.io/badge/" in md

    def test_linked_markdown(self) -> None:
        md = generate_badge_markdown(85.0, repo_url="https://github.com/org/repo")
        assert md.startswith("[![")
        assert "https://github.com/org/repo" in md
        assert md.endswith(")")

    def test_no_link_when_empty_repo_url(self) -> None:
        md = generate_badge_markdown(85.0, repo_url="")
        assert md.startswith("![")
        assert not md.startswith("[![")
