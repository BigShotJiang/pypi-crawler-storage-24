"""Tests for parallel execution and graceful degradation."""

from __future__ import annotations

import asyncio
from pathlib import Path
from unittest.mock import patch

from python_doctor.analysis_request import AnalysisRequest
from python_doctor.config import DoctorConfig
from python_doctor.models import Category, Diagnostic, Severity
from python_doctor.plan import build_scan_plan
from python_doctor.runner import _build_coverage, run_analysis


class FakeAnalyzer:
    """A configurable fake analyzer for testing."""

    def __init__(
        self,
        name: str,
        category: Category,
        result: list[Diagnostic] | None = None,
        error: Exception | None = None,
    ) -> None:
        self._name = name
        self._category = category
        self._result = result or []
        self._error = error

    @property
    def name(self) -> str:
        return self._name

    @property
    def category(self) -> Category:
        return self._category

    async def is_available(self) -> bool:
        return True

    async def analyze(
        self,
        request: AnalysisRequest,
    ) -> list[Diagnostic]:
        if self._error:
            raise self._error
        return self._result


class TestRunAnalysis:
    async def test_successful_run(self, tmp_path: Path) -> None:
        """Successful analyzers contribute diagnostics."""
        diag = Diagnostic(
            file_path=Path("test.py"),
            line=1,
            column=0,
            severity=Severity.WARNING,
            rule_id="TEST001",
            tool="test",
            category=Category.QUALITY,
            message="test",
        )
        analyzer = FakeAnalyzer("test", Category.QUALITY, result=[diag])

        # Create a test file so discovery doesn't return empty
        (tmp_path / "test.py").write_text("x = 1\n")

        with patch(
            "python_doctor.runner.discover_analyzers",
            return_value=[analyzer],
        ):
            report = await run_analysis(
                project_root=tmp_path,
                config=DoctorConfig(),
                files=[tmp_path / "test.py"],
                quiet=True,
            )

        assert len(report.diagnostics) == 1
        assert "test" in report.analyzers_used

    async def test_exception_handling(self, tmp_path: Path) -> None:
        """Failed analyzers are skipped gracefully."""
        analyzer = FakeAnalyzer(
            "broken",
            Category.QUALITY,
            error=RuntimeError("something broke"),
        )
        (tmp_path / "test.py").write_text("x = 1\n")

        with patch(
            "python_doctor.runner.discover_analyzers",
            return_value=[analyzer],
        ):
            report = await run_analysis(
                project_root=tmp_path,
                config=DoctorConfig(),
                files=[tmp_path / "test.py"],
                quiet=True,
            )

        assert report.diagnostics == []
        assert "broken" in report.analyzers_skipped

    async def test_timeout_handling(self, tmp_path: Path) -> None:
        """Timed-out analyzers are skipped gracefully."""

        class SlowAnalyzer(FakeAnalyzer):
            async def analyze(
                self,
                request: AnalysisRequest,
            ) -> list[Diagnostic]:
                raise asyncio.TimeoutError

        analyzer = SlowAnalyzer("slow", Category.QUALITY)
        (tmp_path / "test.py").write_text("x = 1\n")

        with patch(
            "python_doctor.runner.discover_analyzers",
            return_value=[analyzer],
        ):
            report = await run_analysis(
                project_root=tmp_path,
                config=DoctorConfig(),
                files=[tmp_path / "test.py"],
                quiet=True,
            )

        assert report.diagnostics == []
        assert "slow" in report.analyzers_skipped


class TestBuildCoverage:
    """Tests for _build_coverage and skipped_by_user state."""

    def test_skipped_category_appears_as_skipped_by_user(self) -> None:
        """Categories excluded via --skip should have status 'skipped_by_user'."""
        plan = build_scan_plan(
            skip_categories=frozenset({Category.SECURITY}),
        )
        coverage = _build_coverage(
            plan=plan,
            analyzers_used=["ruff"],
            analyzers_skipped=[],
            optional_unavailable=[],
        )
        security_entries = [
            cc for cc in coverage.category_coverage if cc.category == Category.SECURITY
        ]
        assert len(security_entries) == 1
        assert security_entries[0].status == "skipped_by_user"
        assert security_entries[0].reason == "excluded via --skip"

    def test_skipped_category_not_in_scored(self) -> None:
        """Skipped categories should not appear in scored_categories."""
        plan = build_scan_plan(
            skip_categories=frozenset({Category.SECURITY, Category.DEAD_CODE}),
        )
        coverage = _build_coverage(
            plan=plan,
            analyzers_used=["ruff"],
            analyzers_skipped=[],
            optional_unavailable=[],
        )
        assert Category.SECURITY not in coverage.scored_categories
        assert Category.DEAD_CODE not in coverage.scored_categories

    def test_no_skipped_categories_produces_no_skipped_entries(self) -> None:
        """Without --skip, no skipped_by_user entries should appear."""
        plan = build_scan_plan()
        coverage = _build_coverage(
            plan=plan,
            analyzers_used=["ruff"],
            analyzers_skipped=[],
            optional_unavailable=[],
        )
        skipped_entries = [
            cc for cc in coverage.category_coverage if cc.status == "skipped_by_user"
        ]
        assert skipped_entries == []

    def test_plan_tracks_skipped_categories(self) -> None:
        """ScanPlan should record which categories were explicitly skipped."""
        plan = build_scan_plan(
            skip_categories=frozenset({Category.SECURITY, Category.COMPLEXITY}),
        )
        assert plan.skipped_categories == frozenset(
            {Category.SECURITY, Category.COMPLEXITY}
        )
        assert Category.SECURITY not in plan.categories
        assert Category.COMPLEXITY not in plan.categories

    def test_provenance_with_dependency_source(self) -> None:
        """Provenance should include dependency scan source and package count."""
        plan = build_scan_plan()
        coverage = _build_coverage(
            plan=plan,
            analyzers_used=["ruff", "dependency-vulns"],
            analyzers_skipped=[],
            optional_unavailable=[],
            request_metadata={
                "dependency_vulns_source": "uv-lock",
                "dependency_vulns_locked": True,
                "dependency_vulns_package_count": 42,
            },
        )
        assert len(coverage.provenance) == 1
        assert "uv-lock" in coverage.provenance[0]
        assert "42 packages" in coverage.provenance[0]

    def test_provenance_with_skipped_dependency_scan(self) -> None:
        """Provenance should note when dep scan was skipped."""
        plan = build_scan_plan()
        coverage = _build_coverage(
            plan=plan,
            analyzers_used=["ruff"],
            analyzers_skipped=[],
            optional_unavailable=[],
            request_metadata={
                "dependency_vulns_note": "no lockfile or dependency manifest with version data",
            },
        )
        assert len(coverage.provenance) == 1
        assert "skipped" in coverage.provenance[0]
        assert "no lockfile" in coverage.provenance[0]

    def test_provenance_empty_when_no_dep_metadata(self) -> None:
        """No provenance notes when no dependency metadata exists."""
        plan = build_scan_plan()
        coverage = _build_coverage(
            plan=plan,
            analyzers_used=["ruff"],
            analyzers_skipped=[],
            optional_unavailable=[],
        )
        assert coverage.provenance == []
