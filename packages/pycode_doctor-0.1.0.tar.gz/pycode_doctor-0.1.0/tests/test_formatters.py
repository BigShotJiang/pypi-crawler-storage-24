"""Tests for Rich terminal output formatting."""

from __future__ import annotations

from pathlib import Path

from python_doctor.formatters.human import (
    ANALYZER_EXTRA,
    _format_duration,
    _score_color,
    _select_high_impact,
    _sort_issues,
    print_report,
)
from python_doctor.models import (
    Category,
    CategoryScore,
    Diagnostic,
    HealthReport,
    ProjectInfo,
    Severity,
)


class TestScoreColor:
    def test_green_for_high_scores(self) -> None:
        assert _score_color(75) == "green"
        assert _score_color(100) == "green"

    def test_yellow_for_medium_scores(self) -> None:
        assert _score_color(50) == "yellow"
        assert _score_color(74.9) == "yellow"

    def test_red_for_low_scores(self) -> None:
        assert _score_color(0) == "red"
        assert _score_color(49.9) == "red"


class TestFormatDuration:
    def test_milliseconds(self) -> None:
        assert _format_duration(500) == "500ms"

    def test_seconds(self) -> None:
        assert _format_duration(2300) == "2.3s"

    def test_minutes(self) -> None:
        assert _format_duration(90000) == "1m 30s"


class TestSortIssues:
    def test_errors_before_warnings(self) -> None:
        issues = [
            Diagnostic(
                file_path=Path("a.py"),
                line=1,
                column=0,
                severity=Severity.WARNING,
                rule_id="W001",
                tool="test",
                category=Category.QUALITY,
                message="warning",
            ),
            Diagnostic(
                file_path=Path("a.py"),
                line=2,
                column=0,
                severity=Severity.ERROR,
                rule_id="E001",
                tool="test",
                category=Category.QUALITY,
                message="error",
            ),
        ]
        sorted_issues = _sort_issues(issues)
        assert sorted_issues[0].severity == Severity.ERROR
        assert sorted_issues[1].severity == Severity.WARNING

    def test_same_severity_sorted_by_file(self) -> None:
        issues = [
            Diagnostic(
                file_path=Path("z.py"),
                line=1,
                column=0,
                severity=Severity.ERROR,
                rule_id="E001",
                tool="test",
                category=Category.QUALITY,
                message="error",
            ),
            Diagnostic(
                file_path=Path("a.py"),
                line=1,
                column=0,
                severity=Severity.ERROR,
                rule_id="E002",
                tool="test",
                category=Category.QUALITY,
                message="error",
            ),
        ]
        sorted_issues = _sort_issues(issues)
        assert str(sorted_issues[0].file_path) == "a.py"


class TestHighImpact:
    def test_selects_from_worst_category(self) -> None:
        category_scores = [
            CategoryScore(
                category=Category.SECURITY,
                score=40.0,
                weight=20,
                issue_count=5,
            ),
            CategoryScore(
                category=Category.QUALITY,
                score=90.0,
                weight=25,
                issue_count=2,
            ),
        ]
        issues = [
            Diagnostic(
                file_path=Path("a.py"),
                line=1,
                column=0,
                severity=Severity.ERROR,
                rule_id="S105",
                tool="bandit",
                category=Category.SECURITY,
                message="Hardcoded password",
            ),
            Diagnostic(
                file_path=Path("b.py"),
                line=1,
                column=0,
                severity=Severity.ERROR,
                rule_id="F401",
                tool="ruff",
                category=Category.QUALITY,
                message="Unused import",
            ),
        ]
        selected = _select_high_impact(issues, category_scores)
        # Security issue should come first (worst category)
        assert selected[0].rule_id == "S105"

    def test_returns_max_three(self) -> None:
        issues = [
            Diagnostic(
                file_path=Path(f"f{i}.py"),
                line=1,
                column=0,
                severity=Severity.ERROR,
                rule_id=f"E{i:03d}",
                tool="test",
                category=Category.QUALITY,
                message=f"Issue {i}",
            )
            for i in range(10)
        ]
        selected = _select_high_impact(issues, [])
        assert len(selected) <= 3


class TestPrintReport:
    def test_does_not_crash_on_empty_report(self) -> None:
        """Empty report should render without errors."""
        report = HealthReport(
            score=100.0,
            label="Healthy",
            category_scores=[],
            diagnostics=[],
            project=ProjectInfo(
                python_version="3.12",
                framework=None,
                total_files=0,
                total_lines=0,
            ),
            duration_ms=50,
        )
        # Should not raise
        print_report(report)

    def test_verbose_does_not_crash(self) -> None:
        """Verbose mode should not crash with many issues."""
        diagnostics = [
            Diagnostic(
                file_path=Path(f"file{i}.py"),
                line=i,
                column=0,
                severity=Severity.WARNING,
                rule_id=f"W{i:03d}",
                tool="test",
                category=Category.QUALITY,
                message=f"Issue {i}",
            )
            for i in range(50)
        ]
        report = HealthReport(
            score=50.0,
            label="Needs work",
            category_scores=[],
            diagnostics=diagnostics,
            project=ProjectInfo(
                python_version="3.12",
                framework=None,
                total_files=50,
                total_lines=5000,
            ),
            duration_ms=100,
        )
        # Should not raise
        print_report(report, verbose=True)

    def test_show_fix_does_not_crash(self) -> None:
        """--fix mode should not crash."""
        diagnostics = [
            Diagnostic(
                file_path=Path("app.py"),
                line=1,
                column=0,
                severity=Severity.ERROR,
                rule_id="F401",
                tool="ruff",
                category=Category.QUALITY,
                message="Unused import",
                fix="Remove the import",
            ),
        ]
        report = HealthReport(
            score=80.0,
            label="Healthy",
            category_scores=[
                CategoryScore(
                    category=Category.QUALITY,
                    score=80.0,
                    weight=100,
                    issue_count=1,
                    error_count=1,
                    details="1 error",
                ),
            ],
            diagnostics=diagnostics,
            project=ProjectInfo(
                python_version="3.12",
                framework=None,
                total_files=1,
                total_lines=100,
            ),
            duration_ms=100,
        )
        print_report(report, show_fix=True)

    def test_diff_mode_does_not_crash(self) -> None:
        """Diff mode should show file count info."""
        report = HealthReport(
            score=90.0,
            label="Healthy",
            category_scores=[],
            diagnostics=[],
            project=ProjectInfo(
                python_version="3.12",
                framework=None,
                total_files=5,
                total_lines=500,
            ),
            duration_ms=100,
        )
        print_report(
            report,
            diff_mode=True,
            changed_file_count=5,
            total_file_count=100,
        )


class TestCoverageInstallHints:
    """Test that optional analyzer hints print uvx install commands."""

    def test_coverage_prints_uvx_hints(self, capsys: object) -> None:
        """Coverage section should show uvx --from hint for missing extras."""
        from python_doctor.models import CoverageInfo

        coverage = CoverageInfo(
            profile="full",
            confidence="partial",
            analyzers_optional_unavailable=["detect-secrets", "dependency-vulns"],
        )
        report = HealthReport(
            score=85.0,
            label="Healthy",
            category_scores=[],
            diagnostics=[],
            project=ProjectInfo(
                python_version="3.12",
                framework=None,
                total_files=10,
                total_lines=500,
            ),
            duration_ms=100,
            coverage=coverage,
        )
        # Should not crash and should include the uvx hint
        print_report(report)

    def test_analyzer_extra_mapping_complete(self) -> None:
        """All optional analyzers should have an extra mapping."""
        expected = {"dependency-vulns", "detect-secrets", "basedpyright", "typos"}
        assert set(ANALYZER_EXTRA.keys()) == expected


class TestWeightRedistributionExplanation:
    """Test that the human formatter explains weight redistribution."""

    def test_redistribution_note_for_unavailable_category(self, capsys: object) -> None:
        """When a category is unavailable, the output should note redistribution."""
        from python_doctor.models import CategoryCoverage, CoverageInfo

        coverage = CoverageInfo(
            profile="default",
            confidence="partial",
            category_coverage=[
                CategoryCoverage(
                    category=Category.TYPE_SAFETY,
                    status="unavailable",
                    reason="no type checker installed",
                ),
                CategoryCoverage(
                    category=Category.QUALITY,
                    status="scored",
                    analyzers=["ruff"],
                ),
            ],
        )
        report = HealthReport(
            score=85.0,
            label="Healthy",
            category_scores=[],
            diagnostics=[],
            project=ProjectInfo(
                python_version="3.12",
                framework=None,
                total_files=10,
                total_lines=500,
            ),
            duration_ms=100,
            coverage=coverage,
        )
        # Should not crash
        print_report(report)

    def test_redistribution_note_for_skipped_category(self, capsys: object) -> None:
        """When a category is skipped_by_user, output should note redistribution."""
        from python_doctor.models import CategoryCoverage, CoverageInfo

        coverage = CoverageInfo(
            profile="default",
            confidence="partial",
            category_coverage=[
                CategoryCoverage(
                    category=Category.DEAD_CODE,
                    status="skipped_by_user",
                ),
                CategoryCoverage(
                    category=Category.DEPENDENCIES,
                    status="unavailable",
                    reason="no lockfile",
                ),
            ],
        )
        report = HealthReport(
            score=90.0,
            label="Healthy",
            category_scores=[],
            diagnostics=[],
            project=ProjectInfo(
                python_version="3.12",
                framework=None,
                total_files=5,
                total_lines=200,
            ),
            duration_ms=50,
            coverage=coverage,
        )
        # Should not crash
        print_report(report)

    def test_no_redistribution_note_when_all_scored(self, capsys: object) -> None:
        """When all categories are scored, no redistribution note should appear."""
        from python_doctor.models import CategoryCoverage, CoverageInfo

        coverage = CoverageInfo(
            profile="default",
            confidence="full",
            category_coverage=[
                CategoryCoverage(
                    category=Category.QUALITY,
                    status="scored",
                    analyzers=["ruff"],
                ),
                CategoryCoverage(
                    category=Category.SECURITY,
                    status="scored",
                    analyzers=["bandit"],
                ),
            ],
        )
        report = HealthReport(
            score=95.0,
            label="Healthy",
            category_scores=[],
            diagnostics=[],
            project=ProjectInfo(
                python_version="3.12",
                framework=None,
                total_files=5,
                total_lines=200,
            ),
            duration_ms=50,
            coverage=coverage,
        )
        # Should not crash
        print_report(report)
