"""Tests for the rule documentation database."""

from __future__ import annotations

from python_doctor.rules import RULE_DOCS, get_rule_docs


class TestRuleDocs:
    """Test the rules database and lookup logic."""

    def test_direct_lookup(self) -> None:
        """Known rule IDs return documentation."""
        docs = get_rule_docs("F401")
        assert docs is not None
        assert docs["name"] == "Unused import"
        assert docs["tool"] == "ruff (Pyflakes)"

    def test_case_insensitive_uppercase(self) -> None:
        """Lowercase rule IDs should match uppercase entries."""
        docs = get_rule_docs("f401")
        assert docs is not None
        assert docs["name"] == "Unused import"

    def test_case_insensitive_lowercase(self) -> None:
        """Mypy rules stored as lowercase should match."""
        docs = get_rule_docs("ARG-TYPE")
        assert docs is not None
        assert docs["name"] == "Argument type mismatch"

    def test_s_to_b_cross_reference(self) -> None:
        """S-prefix rules should cross-reference to B-prefix entries."""
        # S101 is in RULE_DOCS directly, but test the mechanism
        # with a B-prefix lookup that maps to S-prefix
        docs_s = get_rule_docs("S101")
        docs_b = get_rule_docs("B101")
        assert docs_s is not None
        assert docs_b is not None
        # Both should return the same rule
        assert docs_s["name"] == docs_b["name"]

    def test_b_to_s_cross_reference(self) -> None:
        """B608 should cross-reference to S608."""
        docs = get_rule_docs("B608")
        assert docs is not None
        assert "SQL" in docs["name"]

    def test_mypy_prefix_stripping(self) -> None:
        """mypy-arg-type should strip prefix and find arg-type."""
        docs = get_rule_docs("mypy-arg-type")
        assert docs is not None
        assert docs["name"] == "Argument type mismatch"

    def test_unknown_rule_returns_none(self) -> None:
        """Unknown rule IDs return None."""
        assert get_rule_docs("ZZZZZ999") is None
        assert get_rule_docs("") is None
        assert get_rule_docs("nonexistent") is None

    def test_all_rules_have_required_fields(self) -> None:
        """Every rule doc should have name, tool, category, description."""
        required = {"name", "tool", "category", "description"}
        for rule_id, docs in RULE_DOCS.items():
            missing = required - set(docs.keys())
            assert not missing, f"Rule {rule_id} missing fields: {missing}"

    def test_all_rules_have_fix(self) -> None:
        """Every rule doc should have a fix suggestion."""
        for rule_id, docs in RULE_DOCS.items():
            assert "fix" in docs, f"Rule {rule_id} missing 'fix' field"

    def test_security_rules_cross_reference(self) -> None:
        """All S-prefix security rules should be reachable via B-prefix."""
        for rule_id in RULE_DOCS:
            if rule_id.startswith("S") and rule_id[1:].isdigit():
                b_id = "B" + rule_id[1:]
                docs = get_rule_docs(b_id)
                assert docs is not None, f"{b_id} should cross-ref to {rule_id}"

    def test_complexity_rule(self) -> None:
        """C901 should be findable."""
        docs = get_rule_docs("C901")
        assert docs is not None
        assert "complex" in docs["name"].lower()
        assert docs["category"] == "complexity"
