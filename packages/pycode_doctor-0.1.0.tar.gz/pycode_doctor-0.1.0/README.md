# python-doctor

Fast, local-first Python code health checks with a single command.

`python-doctor` combines Ruff, mypy, Bandit, Radon, Vulture, and deptry into a
single 0-100 score with clear category breakdowns. It is designed to feel good
with `uvx` first.

## Quickstart

Run it with no install step:

```bash
uvx python-doctor .
```

Use the latest published version explicitly:

```bash
uvx python-doctor@latest .
```

For deeper optional scans:

```bash
uvx --from 'python-doctor[full]' python-doctor .
```

Persistent install:

```bash
uv tool install python-doctor
```

## What The Default Scan Includes

- Ruff for quality, security, complexity, and dead-code rule families
- mypy for type checking
- Bandit for security checks
- Radon for complexity metrics
- Vulture for dead code
- deptry for dependency hygiene

Optional extras add:

- `dependency-vulns` for OSV-backed dependency vulnerability scanning
- `detect-secrets` for secret scanning
- `basedpyright` as an optional type backend
- `typos` for spelling checks in source code
- MCP support

## Common Commands

```bash
# fast feedback
python-doctor . --profile quick

# full default scan
python-doctor .

# include optional analyzers if installed
python-doctor . --profile full

# only score output
python-doctor . --score

# machine-readable output
python-doctor . --json

# analyze only selected categories
python-doctor . --only quality,types

# skip categories
python-doctor . --skip security,dead_code

# safe Ruff autofix, then rescan
python-doctor . --fix

# show remediation text inline
python-doctor . --show-fixes
```

## Why `src/python_doctor/`?

The package is intentionally laid out as `src/python_doctor/`.

- `python-doctor` is the distribution and CLI name
- `python_doctor` is the Python import package name

The `src/` layout prevents packaging and test mistakes where imports succeed
from the checkout but fail from the built wheel.

## Configuration

Zero-config by default. Customize in `pyproject.toml`:

```toml
[tool.python-doctor]
timeout = 60

[tool.python-doctor.weights]
quality = 25
types = 20
security = 20
complexity = 15
dead_code = 10
dependencies = 10

[tool.python-doctor.ignore]
rules = ["S101"]
files = ["tests/**", "migrations/**"]
```

See `docs/configuration.md` for the full reference.

## MCP Server

Expose health data to AI coding agents (Claude Code, Cursor, VS Code):

```bash
python-doctor install-mcp cursor
```

This registers python-doctor as an MCP server. Your AI agent can then call
tools like `analyze_code`, `explain_rule`, `get_score`, `suggest_fixes`, and
`check_diff`.

See `docs/mcp-server.md` for details.

## Plugins

Extend python-doctor with custom analyzers via entry points:

```toml
[project.entry-points."python_doctor.analyzers"]
my-analyzer = "my_package:MyAnalyzer"
```

See `docs/plugins.md` for the full guide.

## Output Model

The score covers six categories:

- quality
- type safety
- security
- complexity
- dead code
- dependencies

V1 also reports coverage, so a score can tell you whether the scan was full,
partial, or limited.

## Docs

Kept intentionally small:

- `docs/configuration.md` -- weights, thresholds, ignore rules
- `docs/scoring.md` -- scoring methodology
- `docs/mcp-server.md` -- MCP server setup
- `docs/plugins.md` -- custom analyzer development
- `docs/development.md` -- contributing to python-doctor

## Development

```bash
uv sync --all-extras
uv run pytest
uv run ruff check src tests
uv run mypy src
```

See `docs/development.md` for the full guide.

## License

MIT
