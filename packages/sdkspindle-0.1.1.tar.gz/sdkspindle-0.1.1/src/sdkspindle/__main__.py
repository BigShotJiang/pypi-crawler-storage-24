"""Allow running as `python -m sdkspindle`."""
from sdkspindle.cli import main

if __name__ == "__main__":
    main()
