"""sdkspindle — SDK-aware linter, query engine & auto-fixer for com.google.genai."""

__version__ = "0.1.1"
