# sdkspindle trial proxy

Vercel serverless function that proxies Gemini API calls for `sdkspindle query`.
Your API key stays server-side. Users get rate-limited trial access.

## Deploy

```bash
cd proxy/
vercel deploy
```

Then set `GOOGLE_API_KEY` in the Vercel dashboard (Settings > Environment Variables).

## How it works

```
User CLI ──→ POST /api/query ──→ Gemini API
               │                      (your key)
               ├─ Rate limit: 20/day/IP
               ├─ Context cap: 50KB
               ├─ Model whitelist: flash only
               └─ Question cap: 500 chars

Response: {"answer": "...", "remaining": 18, "model": "gemini-2.0-flash"}
```

## Rate limiting

In-memory store (resets on cold start). For production:
- Swap to Vercel KV (`@vercel/kv`)
- Or Upstash Redis (free tier = 10K commands/day)

## Custom proxy URL

Users can override:
```bash
export SDKSPINDLE_PROXY=https://your-instance.vercel.app/api/query
```

## Security

- API key never leaves the server
- Model whitelist prevents expensive model abuse  
- Context capped at 50KB (SDK subset, not full reference)
- Question capped at 500 chars
- Body capped at 100KB
- IP hashed with SHA-256 (never stored raw)
