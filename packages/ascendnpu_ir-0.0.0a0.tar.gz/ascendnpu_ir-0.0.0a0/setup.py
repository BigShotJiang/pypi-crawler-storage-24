from setuptools import setup, find_packages

setup(
    name="ascendnpu-ir",
    version="0.0.0a0",
    packages=find_packages(),
    python_requires=">=3.9",
    license="Apache-2.0",
)
