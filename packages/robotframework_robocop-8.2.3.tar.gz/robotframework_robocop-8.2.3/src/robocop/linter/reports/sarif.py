from __future__ import annotations

from typing import TYPE_CHECKING, Any

import robocop.linter.reports
from robocop import __version__
from robocop.files import get_relative_path

if TYPE_CHECKING:
    from pathlib import Path

    from robocop.config.manager import ConfigManager
    from robocop.config.schema import Config
    from robocop.linter.diagnostics import Diagnostics
    from robocop.linter.rules import Rule, RuleSeverity
    from robocop.runtime.resolved_config import ResolvedConfig


class SarifReport(robocop.linter.reports.JsonFileReport):
    """
    **Report name**: ``sarif``

    Report that generates SARIF output file.

    This report is not included in the default reports. The ``--reports all`` option will not enable this report.
    You can still enable it using the report name directly: ``--reports sarif`` or ``--reports all,sarif``.

    All fields required by GitHub Code Scanning are supported. The output file will be generated
    in the current working directory with the ``.sarif.json`` name.

    You can configure an output path. It's a relative path to the file that will be produced by the report:

        robocop check --configure sarif.output_path=output/robocop_sarif.json

    The default path is ``.sarif.json``.

    """

    NO_ALL = False
    SCHEMA_VERSION = "2.1.0"
    SCHEMA = f"https://json.schemastore.org/sarif-{SCHEMA_VERSION}.json"

    def __init__(self, config: Config) -> None:
        self.name = "sarif"
        self.description = "Generate SARIF output file"
        super().__init__(output_path=".sarif.json", config=config)

    @staticmethod
    def map_severity_to_level(severity: RuleSeverity) -> str:
        return {"WARNING": "warning", "ERROR": "error", "INFO": "note"}[severity.name]

    def get_rule_desc(self, rule: Rule) -> dict[str, Any]:
        return {
            "id": rule.rule_id,
            "name": rule.name,
            "helpUri": f"{rule.docs_url}",
            "shortDescription": {"text": rule.message},
            "fullDescription": {"text": rule.docs},
            "defaultConfiguration": {"level": self.map_severity_to_level(rule.default_severity)},
            "help": {"text": rule.docs, "markdown": rule.docs},
        }

    def generate_sarif_issues(self, diagnostics: Diagnostics, root: Path) -> list[dict[str, Any]]:
        sarif_issues: list[dict[str, Any]] = []
        for diagnostic in diagnostics:
            relative_uri = get_relative_path(diagnostic.source.path, root).as_posix()
            sarif_issue = {
                "ruleId": diagnostic.rule.rule_id,
                "level": self.map_severity_to_level(diagnostic.severity),
                "message": {"text": diagnostic.message},
                "locations": [
                    {
                        "physicalLocation": {
                            "artifactLocation": {"uri": relative_uri, "uriBaseId": "%SRCROOT%"},
                            "region": {
                                "startLine": diagnostic.range.start.line,
                                "endLine": diagnostic.range.end.line,
                                "startColumn": diagnostic.range.start.character,
                                "endColumn": diagnostic.range.end.character,
                            },
                        }
                    }
                ],
            }
            sarif_issues.append(sarif_issue)
        return sarif_issues

    def generate_rules_config(self, rules: dict[str, Rule]) -> list[dict[str, Any]]:
        unique_enabled_rules = {rule.rule_id: rule for rule in rules.values() if rule.enabled}
        sorted_rules = sorted(unique_enabled_rules.values(), key=lambda x: x.rule_id)
        return [self.get_rule_desc(rule) for rule in sorted_rules]

    def generate_sarif_report(self, diagnostics: Diagnostics, root: Path, rules: dict[str, Rule]) -> dict[str, Any]:
        return {
            "$schema": self.SCHEMA,
            "version": self.SCHEMA_VERSION,
            "runs": [
                {
                    "tool": {
                        "driver": {
                            "name": "Robocop",
                            "semanticVersion": __version__,
                            "informationUri": "https://robocop.dev/",
                            "rules": self.generate_rules_config(rules),
                        }
                    },
                    "automationDetails": {"id": "robocop/"},
                    "results": self.generate_sarif_issues(diagnostics, root),
                }
            ],
        }

    def generate_report(  # type: ignore[override]
        self,
        diagnostics: Diagnostics,
        config_manager: ConfigManager,
        resolved_config: ResolvedConfig,
        **kwargs: object,  # noqa: ARG002
    ) -> None:
        # TODO: In case of several configs we may not have all rules in default config
        # instead, we could use diagnostic.rule and aggregate them
        report = self.generate_sarif_report(diagnostics, config_manager.root, resolved_config.rules)
        super().generate_report_with_type(report, "SARIF")
