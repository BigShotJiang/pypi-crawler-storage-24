"""Tests for compaction ping logic in Bot."""
import asyncio
import pytest
from unittest.mock import AsyncMock, MagicMock, patch


# ── Helpers ──────────────────────────────────────────────────────────────────

def make_config(owner_user_id="276141255266926602", threshold=80):
    cfg = MagicMock()
    cfg.owner_user_id = owner_user_id
    cfg.compaction_threshold = threshold
    return cfg


# ── Config field tests ────────────────────────────────────────────────────────

def test_config_defaults():
    """Config dataclass should have owner_user_id and compaction_threshold defaults."""
    from antarisbot.core.config import Config
    cfg = Config()
    assert hasattr(cfg, 'owner_user_id')
    assert hasattr(cfg, 'compaction_threshold')
    assert cfg.owner_user_id == ""
    assert cfg.compaction_threshold == 80


def test_config_load_compaction_fields(tmp_path):
    """Config.load() should read ownerUserId and compactionThreshold from JSON."""
    import json
    from antarisbot.core.config import Config

    cfg_data = {
        "bot": {"name": "TestBot", "ownerUserId": "12345", "compactionThreshold": 50},
        "provider": {"name": "ollama", "apiKey": "ollama", "model": "qwen3:8b", "fallbackModel": "qwen3:8b"},
        "channels": {},
        "memory": {},
        "guard": {},
        "security": {},
    }
    cfg_path = tmp_path / "config.json"
    cfg_path.write_text(json.dumps(cfg_data))

    cfg = Config.load(str(cfg_path))
    assert cfg is not None
    assert cfg.owner_user_id == "12345"
    assert cfg.compaction_threshold == 50


def test_config_save_compaction_fields(tmp_path):
    """Config.save() should write ownerUserId and compactionThreshold."""
    import json
    from antarisbot.core.config import Config

    cfg = Config()
    cfg.provider_name = "ollama"
    cfg.api_key = "ollama"
    cfg.owner_user_id = "999"
    cfg.compaction_threshold = 40
    cfg_path = tmp_path / "config.json"
    cfg.config_path = str(cfg_path)
    cfg.save()

    data = json.loads(cfg_path.read_text())
    assert data["bot"]["ownerUserId"] == "999"
    assert data["bot"]["compactionThreshold"] == 40


# ── Compaction threshold logic tests ─────────────────────────────────────────

@pytest.mark.asyncio
async def test_compaction_ping_fires_at_threshold():
    """_send_compaction_ping should be triggered when message count hits threshold."""
    from antarisbot.core.bot import Bot

    # We test the threshold check logic in isolation without a real Bot
    # by checking the branching conditions directly.
    message_count = 80
    threshold = 80
    notified = False
    owner_id = "276141255266926602"

    # Replicate the condition from _make_handler
    should_ping = (
        message_count >= threshold
        and not notified
        and bool(owner_id)
    )
    assert should_ping is True


@pytest.mark.asyncio
async def test_compaction_ping_does_not_fire_below_threshold():
    """Should not trigger compaction ping below the threshold."""
    message_count = 79
    threshold = 80
    notified = False
    owner_id = "276141255266926602"

    should_ping = (
        message_count >= threshold
        and not notified
        and bool(owner_id)
    )
    assert should_ping is False


@pytest.mark.asyncio
async def test_compaction_ping_does_not_repeat():
    """Second message at/above threshold should not re-trigger (notified=True)."""
    message_count = 100
    threshold = 80
    notified = True  # already sent
    owner_id = "276141255266926602"

    should_ping = (
        message_count >= threshold
        and not notified
        and bool(owner_id)
    )
    assert should_ping is False


@pytest.mark.asyncio
async def test_compaction_ping_skips_when_no_owner_id():
    """No ping when owner_user_id is empty string."""
    message_count = 100
    threshold = 80
    notified = False
    owner_id = ""  # not configured

    should_ping = (
        message_count >= threshold
        and not notified
        and bool(owner_id)
    )
    assert should_ping is False


@pytest.mark.asyncio
async def test_send_compaction_ping_logs_fallback_when_no_discord():
    """_send_compaction_ping falls back to logging when adapter is not Discord."""
    from antarisbot.core.bot import Bot

    # Mock a minimal Bot instance without invoking __init__
    bot = object.__new__(Bot)
    bot._message_count = 80
    bot.config = make_config()

    # Non-Discord adapter
    adapter = MagicMock()
    adapter.__class__.__name__ = "TerminalAdapter"

    with patch("antarisbot.core.bot.logger") as mock_logger:
        await bot._send_compaction_ping(adapter)
        # Should log a warning (fallback path)
        mock_logger.warning.assert_called()


@pytest.mark.asyncio
async def test_send_compaction_ping_no_owner_id_returns_early():
    """_send_compaction_ping returns early when owner_user_id is empty."""
    from antarisbot.core.bot import Bot

    bot = object.__new__(Bot)
    bot._message_count = 80
    bot.config = make_config(owner_user_id="")

    adapter = MagicMock()
    # Should not raise, just return early
    await bot._send_compaction_ping(adapter)


@pytest.mark.asyncio
async def test_send_compaction_ping_discord_adapter_sends_dm():
    """_send_compaction_ping sends a DM via Discord when adapter is DiscordAdapter."""
    from antarisbot.core.bot import Bot
    from antarisbot.channels.discord import DiscordAdapter

    bot = object.__new__(Bot)
    bot._message_count = 80
    bot.config = make_config(owner_user_id="276141255266926602")

    mock_user = AsyncMock()
    mock_client = AsyncMock()
    mock_client.fetch_user = AsyncMock(return_value=mock_user)

    adapter = MagicMock(spec=DiscordAdapter)
    adapter._client = mock_client

    with patch("antarisbot.core.bot.logger"):
        await bot._send_compaction_ping(adapter)

    mock_client.fetch_user.assert_awaited_once_with(276141255266926602)
    mock_user.send.assert_awaited_once()
    # Message should mention context / messages
    sent_msg = mock_user.send.call_args.args[0]
    assert "80" in sent_msg or "messages" in sent_msg.lower()
