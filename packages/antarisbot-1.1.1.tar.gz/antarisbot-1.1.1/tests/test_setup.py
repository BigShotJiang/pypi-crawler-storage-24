"""
Tests for antarisbot.setup — SetupServer and SetupWizard.

At least 20 tests covering:
  - is_needed() logic
  - SetupServer lifecycle (start/stop)
  - /api/status endpoint
  - /api/validate-token endpoint (mocked HTTP calls)
  - POST /api/setup saves config correctly
  - Wizard HTML validity
  - SetupWizard.run() integration
"""

import json
import socket
import threading
import time
import urllib.request
import urllib.error
from pathlib import Path
from unittest import TestCase, mock
from unittest.mock import MagicMock, patch, call

from antarisbot.core.config import Config
from antarisbot.setup.server import (
    SetupServer,
    WIZARD_HTML,
    _validate_token,
    _validate_telegram,
    _validate_discord,
    _validate_anthropic,
    _validate_openai,
)
from antarisbot.setup.wizard import SetupWizard


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _get(url: str, timeout: int = 5):
    """Simple GET helper, returns (status, body_str)."""
    try:
        with urllib.request.urlopen(url, timeout=timeout) as resp:
            return resp.status, resp.read().decode()
    except urllib.error.HTTPError as e:
        return e.code, e.read().decode()


def _post_json(url: str, data: dict, timeout: int = 5):
    """Simple POST-JSON helper, returns (status, body_str)."""
    payload = json.dumps(data).encode()
    req = urllib.request.Request(
        url, data=payload,
        headers={"Content-Type": "application/json"},
        method="POST"
    )
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return resp.status, resp.read().decode()
    except urllib.error.HTTPError as e:
        return e.code, e.read().decode()


def _free_port() -> int:
    """Return a free localhost port."""
    with socket.socket() as s:
        s.bind(("localhost", 0))
        return s.getsockname()[1]


def _make_server(tmp_path: Path) -> SetupServer:
    """Create a SetupServer patched to use a temp config path and a free port."""
    server = SetupServer()
    server.PORT = _free_port()
    return server


# ---------------------------------------------------------------------------
# 1–4: SetupWizard.is_needed()
# ---------------------------------------------------------------------------

class TestIsNeeded(TestCase):
    def test_is_needed_missing_config(self, tmp_path=None):
        """is_needed() returns True when config file doesn't exist."""
        with patch("antarisbot.setup.wizard.Config.load", return_value=None):
            wizard = SetupWizard()
            self.assertTrue(wizard.is_needed())

    def test_is_needed_empty_api_key(self):
        """is_needed() returns True when config exists but api_key is empty."""
        cfg = Config()
        cfg.api_key = ""
        with patch("antarisbot.setup.wizard.Config.load", return_value=cfg):
            wizard = SetupWizard()
            self.assertTrue(wizard.is_needed())

    def test_is_needed_valid_config(self):
        """is_needed() returns False when config exists and api_key is set."""
        cfg = Config()
        cfg.api_key = "sk-valid-key"
        with patch("antarisbot.setup.wizard.Config.load", return_value=cfg):
            wizard = SetupWizard()
            self.assertFalse(wizard.is_needed())

    def test_is_needed_with_real_missing_path(self, tmp_path=None):
        """is_needed() returns True when config file doesn't exist on disk."""
        # Point Config.load at a non-existent path
        import tempfile, os
        with tempfile.TemporaryDirectory() as td:
            fake_path = os.path.join(td, "no_config.json")
            with patch("antarisbot.setup.wizard.DEFAULT_CONFIG_PATH", fake_path):
                with patch("antarisbot.setup.wizard.Config.load", return_value=None):
                    wizard = SetupWizard()
                    self.assertTrue(wizard.is_needed())


# ---------------------------------------------------------------------------
# 5–7: Server start / stop / port
# ---------------------------------------------------------------------------

class TestServerLifecycle(TestCase):
    def _start_server(self) -> SetupServer:
        server = SetupServer()
        server.PORT = _free_port()
        server.start(open_browser=False)
        time.sleep(0.15)
        return server

    def test_server_starts(self):
        """Server should start without raising."""
        server = self._start_server()
        try:
            self.assertIsNotNone(server._httpd)
            self.assertIsNotNone(server._thread)
            self.assertTrue(server._thread.is_alive())
        finally:
            server.stop()

    def test_server_stops(self):
        """Server should stop cleanly and thread should not be alive."""
        server = self._start_server()
        server.stop()
        time.sleep(0.1)
        self.assertIsNone(server._httpd)

    def test_server_serves_html(self):
        """GET / should return 200 with HTML content."""
        server = self._start_server()
        try:
            status, body = _get(f"http://localhost:{server.PORT}/")
            self.assertEqual(status, 200)
            self.assertIn("<!DOCTYPE html>", body)
            self.assertIn("AntarisBot", body)
        finally:
            server.stop()


# ---------------------------------------------------------------------------
# 8–11: /api/status endpoint
# ---------------------------------------------------------------------------

class TestStatusEndpoint(TestCase):
    def _start_server(self) -> SetupServer:
        server = SetupServer()
        server.PORT = _free_port()
        server.start(open_browser=False)
        time.sleep(0.15)
        return server

    def test_status_unconfigured(self):
        """GET /api/status returns configured=false when no config exists."""
        server = self._start_server()
        try:
            with patch("antarisbot.setup.server.Config.load", return_value=None):
                status, body = _get(f"http://localhost:{server.PORT}/api/status")
            self.assertEqual(status, 200)
            data = json.loads(body)
            self.assertFalse(data["configured"])
            self.assertEqual(data["channels"], [])
        finally:
            server.stop()

    def test_status_configured_no_channels(self):
        """GET /api/status returns configured=true when api_key set, no channels enabled."""
        cfg = Config()
        cfg.api_key = "sk-test"
        cfg.discord_enabled = False
        cfg.telegram_enabled = False
        server = self._start_server()
        try:
            with patch("antarisbot.setup.server.Config.load", return_value=cfg):
                status, body = _get(f"http://localhost:{server.PORT}/api/status")
            data = json.loads(body)
            self.assertTrue(data["configured"])
            self.assertEqual(data["channels"], [])
        finally:
            server.stop()

    def test_status_configured_with_discord(self):
        """GET /api/status includes 'discord' in channels when Discord is enabled."""
        cfg = Config()
        cfg.api_key = "sk-test"
        cfg.discord_enabled = True
        cfg.telegram_enabled = False
        server = self._start_server()
        try:
            with patch("antarisbot.setup.server.Config.load", return_value=cfg):
                status, body = _get(f"http://localhost:{server.PORT}/api/status")
            data = json.loads(body)
            self.assertTrue(data["configured"])
            self.assertIn("discord", data["channels"])
        finally:
            server.stop()

    def test_status_configured_both_channels(self):
        """GET /api/status includes both channels when both are enabled."""
        cfg = Config()
        cfg.api_key = "sk-test"
        cfg.discord_enabled = True
        cfg.telegram_enabled = True
        server = self._start_server()
        try:
            with patch("antarisbot.setup.server.Config.load", return_value=cfg):
                status, body = _get(f"http://localhost:{server.PORT}/api/status")
            data = json.loads(body)
            self.assertIn("discord", data["channels"])
            self.assertIn("telegram", data["channels"])
        finally:
            server.stop()


# ---------------------------------------------------------------------------
# 12–16: /api/validate-token (mocked HTTP)
# ---------------------------------------------------------------------------

class TestValidateToken(TestCase):
    """
    Tests for the _validate_token helpers.
    We mock urllib.request.urlopen so no real HTTP is made.
    """

    def _mock_response(self, body: bytes, status: int = 200):
        """Create a mock context-manager response for urlopen."""
        resp = MagicMock()
        resp.status = status
        resp.read.return_value = body
        resp.__enter__ = lambda s: s
        resp.__exit__ = MagicMock(return_value=False)
        return resp

    def test_telegram_valid_token(self):
        """_validate_telegram returns (True, None) for a valid token."""
        resp = self._mock_response(json.dumps({"ok": True, "result": {"username": "TestBot"}}).encode())
        with patch("antarisbot.setup.server.urlopen", return_value=resp):
            valid, err = _validate_telegram("123456:ABC")
        self.assertTrue(valid)
        self.assertIsNone(err)

    def test_telegram_invalid_token(self):
        """_validate_telegram returns (False, msg) for an invalid token."""
        resp = self._mock_response(json.dumps({"ok": False, "description": "Unauthorized"}).encode())
        with patch("antarisbot.setup.server.urlopen", return_value=resp):
            valid, err = _validate_telegram("bad-token")
        self.assertFalse(valid)
        self.assertIn("Unauthorized", err)

    def test_telegram_http_error(self):
        """_validate_telegram returns (False, msg) on HTTP 401."""
        http_err = urllib.error.HTTPError(
            url="", code=401, msg="Unauthorized", hdrs=None, fp=None
        )
        with patch("antarisbot.setup.server.urlopen", side_effect=http_err):
            valid, err = _validate_telegram("bad-token")
        self.assertFalse(valid)
        self.assertIn("401", err)

    def test_discord_valid_token(self):
        """_validate_discord returns (True, None) for a valid bot token."""
        resp = self._mock_response(json.dumps({"id": "1234", "username": "TestBot"}).encode())
        with patch("antarisbot.setup.server.urlopen", return_value=resp):
            valid, err = _validate_discord("Bot MTI3...")
        self.assertTrue(valid)
        self.assertIsNone(err)

    def test_discord_unauthorized(self):
        """_validate_discord returns (False, msg) on 401."""
        http_err = urllib.error.HTTPError(
            url="", code=401, msg="Unauthorized", hdrs=None, fp=None
        )
        with patch("antarisbot.setup.server.urlopen", side_effect=http_err):
            valid, err = _validate_discord("bad-token")
        self.assertFalse(valid)
        self.assertIn("Unauthorized", err)

    def test_anthropic_valid_key(self):
        """_validate_anthropic returns (True, None) for a valid API key (200 response)."""
        resp = self._mock_response(json.dumps({"id": "msg_01", "content": []}).encode())
        with patch("antarisbot.setup.server.urlopen", return_value=resp):
            valid, err = _validate_anthropic("sk-ant-valid")
        self.assertTrue(valid)
        self.assertIsNone(err)

    def test_anthropic_auth_error(self):
        """_validate_anthropic returns (False, msg) on 401 (bad API key)."""
        http_err = urllib.error.HTTPError(
            url="", code=401, msg="Unauthorized", hdrs=None, fp=None
        )
        with patch("antarisbot.setup.server.urlopen", side_effect=http_err):
            valid, err = _validate_anthropic("sk-bad-key")
        self.assertFalse(valid)
        self.assertIn("Unauthorized", err)

    def test_anthropic_400_treated_as_valid(self):
        """_validate_anthropic returns (True, None) for 400 (auth OK, bad request body)."""
        http_err = urllib.error.HTTPError(
            url="", code=400, msg="Bad Request", hdrs=None, fp=None
        )
        with patch("antarisbot.setup.server.urlopen", side_effect=http_err):
            valid, err = _validate_anthropic("sk-valid")
        self.assertTrue(valid)

    def test_openai_valid_key(self):
        """_validate_openai returns (True, None) for a valid API key."""
        resp = self._mock_response(json.dumps({"object": "list", "data": []}).encode())
        with patch("antarisbot.setup.server.urlopen", return_value=resp):
            valid, err = _validate_openai("sk-proj-valid")
        self.assertTrue(valid)
        self.assertIsNone(err)

    def test_openai_invalid_key(self):
        """_validate_openai returns (False, msg) on 401."""
        http_err = urllib.error.HTTPError(
            url="", code=401, msg="Unauthorized", hdrs=None, fp=None
        )
        with patch("antarisbot.setup.server.urlopen", side_effect=http_err):
            valid, err = _validate_openai("sk-bad")
        self.assertFalse(valid)

    def test_unknown_provider(self):
        """_validate_token returns (False, msg) for an unknown provider."""
        valid, err = _validate_token("unknown-provider", "some-token")
        self.assertFalse(valid)
        self.assertIn("Unknown provider", err)

    def test_empty_token(self):
        """Validate-token endpoint returns valid=False for an empty token."""
        server = SetupServer()
        server.PORT = _free_port()
        server.start(open_browser=False)
        time.sleep(0.15)
        try:
            status, body = _post_json(
                f"http://localhost:{server.PORT}/api/validate-token",
                {"provider": "telegram", "token": ""}
            )
            data = json.loads(body)
            self.assertFalse(data["valid"])
        finally:
            server.stop()


# ---------------------------------------------------------------------------
# 17–19: POST /api/setup saves config correctly
# ---------------------------------------------------------------------------

class TestSetupEndpoint(TestCase):
    def _start_server(self) -> SetupServer:
        server = SetupServer()
        server.PORT = _free_port()
        server.start(open_browser=False)
        time.sleep(0.15)
        return server

    def test_setup_saves_config(self, tmp_path=None):
        """POST /api/setup should save config and return ok=true."""
        import tempfile, os
        with tempfile.TemporaryDirectory() as td:
            config_path = os.path.join(td, "config.json")
            saved_cfg = {}

            def fake_save(self, path=None):
                saved_cfg["bot_name"] = self.bot_name
                saved_cfg["provider"] = self.provider_name
                saved_cfg["api_key"] = self.api_key
                saved_cfg["telegram_enabled"] = self.telegram_enabled
                saved_cfg["telegram_token"] = self.telegram_token
                # write to disk too for completeness
                import json
                Path(path or self.config_path).parent.mkdir(parents=True, exist_ok=True)
                with open(path or self.config_path, "w") as f:
                    json.dump({}, f)

            server = self._start_server()
            try:
                with patch.object(Config, "save", fake_save):
                    with patch("antarisbot.setup.server.Config.load", return_value=None):
                        status, body = _post_json(
                            f"http://localhost:{server.PORT}/api/setup",
                            {
                                "bot_name": "TestWizardBot",
                                "provider": "anthropic",
                                "api_key": "sk-wizard-test",
                                "channel": "telegram",
                                "telegram_token": "tg-token-123",
                                "discord_token": "",
                            }
                        )
                data = json.loads(body)
                self.assertTrue(data.get("ok"))
                self.assertEqual(saved_cfg.get("bot_name"), "TestWizardBot")
                self.assertEqual(saved_cfg.get("provider"), "anthropic")
                self.assertTrue(saved_cfg.get("telegram_enabled"))
                self.assertEqual(saved_cfg.get("telegram_token"), "tg-token-123")
            finally:
                server.stop()

    def test_setup_marks_complete(self):
        """After POST /api/setup, server.setup_complete should be True."""
        server = self._start_server()
        try:
            self.assertFalse(server.setup_complete)

            def fake_save(self, path=None):
                pass

            with patch.object(Config, "save", fake_save):
                with patch("antarisbot.setup.server.Config.load", return_value=None):
                    _post_json(
                        f"http://localhost:{server.PORT}/api/setup",
                        {
                            "bot_name": "Bot",
                            "provider": "openai",
                            "api_key": "sk-x",
                            "channel": "terminal",
                            "telegram_token": "",
                            "discord_token": "",
                        }
                    )
            time.sleep(0.1)
            self.assertTrue(server.setup_complete)
        finally:
            server.stop()

    def test_setup_openai_sets_correct_model(self):
        """POST /api/setup with openai provider sets gpt-4o-mini as the model."""
        server = self._start_server()
        captured = {}

        def fake_save(self, path=None):
            captured["model"] = self.model
            captured["provider"] = self.provider_name

        try:
            with patch.object(Config, "save", fake_save):
                with patch("antarisbot.setup.server.Config.load", return_value=None):
                    _post_json(
                        f"http://localhost:{server.PORT}/api/setup",
                        {
                            "bot_name": "GPTBot",
                            "provider": "openai",
                            "api_key": "sk-openai",
                            "channel": "terminal",
                            "telegram_token": "",
                            "discord_token": "",
                        }
                    )
            self.assertEqual(captured.get("provider"), "openai")
            self.assertEqual(captured.get("model"), "gpt-5.2")
        finally:
            server.stop()


# ---------------------------------------------------------------------------
# 20–23: Wizard HTML validity
# ---------------------------------------------------------------------------

class TestWizardHTML(TestCase):
    def test_html_doctype(self):
        """Wizard HTML should start with a DOCTYPE declaration."""
        self.assertTrue(WIZARD_HTML.strip().startswith("<!DOCTYPE html>"))

    def test_html_contains_progress_bar(self):
        """Wizard HTML should contain the progress bar element."""
        self.assertIn("progress-fill", WIZARD_HTML)
        self.assertIn("progress-track", WIZARD_HTML)

    def test_html_contains_all_steps(self):
        """Wizard HTML JS should reference all 6 steps."""
        for step_fn in ("stepWelcome", "stepProvider", "stepChannel",
                        "stepChannelSetup", "stepBotName", "stepDone"):
            self.assertIn(step_fn, WIZARD_HTML), f"Missing step function: {step_fn}"

    def test_html_contains_validate_token_call(self):
        """Wizard HTML should call /api/validate-token."""
        self.assertIn("/api/validate-token", WIZARD_HTML)

    def test_html_contains_setup_call(self):
        """Wizard HTML should POST to /api/setup on Launch."""
        self.assertIn("/api/setup", WIZARD_HTML)

    def test_html_no_external_deps(self):
        """Wizard HTML should not reference CDN or external stylesheets."""
        self.assertNotIn("cdn.jsdelivr.net", WIZARD_HTML)
        self.assertNotIn("unpkg.com", WIZARD_HTML)
        self.assertNotIn("googleapis.com/css", WIZARD_HTML)
        self.assertNotIn('<link rel="stylesheet"', WIZARD_HTML)

    def test_html_indigo_accent(self):
        """Wizard HTML should use the specified indigo accent colour."""
        self.assertIn("#6366f1", WIZARD_HTML)

    def test_html_responsive_meta(self):
        """Wizard HTML should have a viewport meta tag for mobile."""
        self.assertIn('name="viewport"', WIZARD_HTML)

    def test_html_botfather_instruction(self):
        """Wizard HTML should include @BotFather instructions for Telegram."""
        self.assertIn("BotFather", WIZARD_HTML)

    def test_html_discord_instruction(self):
        """Wizard HTML should include discord.com/developers instructions."""
        self.assertIn("discord.com/developers", WIZARD_HTML)

    def test_html_no_step_numbers(self):
        """No 'Question X of 6' or 'Step X of 6' text (just a progress bar)."""
        import re
        self.assertIsNone(re.search(r"Question\s+\d+\s+of\s+\d+", WIZARD_HTML))
        self.assertIsNone(re.search(r"Step\s+\d+\s+of\s+\d+", WIZARD_HTML))
