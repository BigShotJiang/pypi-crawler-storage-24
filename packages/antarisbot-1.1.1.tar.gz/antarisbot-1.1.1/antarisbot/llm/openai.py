"""OpenAI provider — Phase 4 (direct HTTP, no SDK)."""

import httpx
from typing import Optional
from .base import LLMProvider, Message, LLMResponse

# Pricing per million tokens (approximate, for cost tracking)
MODEL_PRICING = {
    "gpt-5.4": {"input": 5.00, "output": 15.00},
    "gpt-5.2": {"input": 3.00, "output": 12.00},
    "gpt-4o": {"input": 2.50, "output": 10.00},
    "gpt-4o-mini": {"input": 0.15, "output": 0.60},
    "o1": {"input": 15.00, "output": 60.00},
    "o3-mini": {"input": 1.10, "output": 4.40},
}


class OpenAIProvider(LLMProvider):
    """OpenAI provider — direct HTTP to api.openai.com, no SDK."""

    BASE_URL = "https://api.openai.com/v1"

    async def complete(
        self,
        messages: list[Message],
        system: str,
        model: Optional[str] = None,
        max_tokens: int = 4096,
        temperature: float = 0.7
    ) -> LLMResponse:
        use_model = model or self.model

        # Build messages array: system first, then conversation messages (skip any role=system)
        openai_messages = []
        if system:
            openai_messages.append({"role": "system", "content": system})
        openai_messages.extend(
            {"role": m.role, "content": m.content}
            for m in messages
            if m.role != "system"
        )

        # GPT-5.x and newer models use max_completion_tokens instead of max_tokens
        _new_api_models = ("gpt-5", "o1", "o3")
        _use_new_param = any(use_model.startswith(p) for p in _new_api_models)

        payload = {
            "model": use_model,
            "messages": openai_messages,
            "temperature": temperature,
        }
        if _use_new_param:
            payload["max_completion_tokens"] = max_tokens
        else:
            payload["max_tokens"] = max_tokens

        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
        }

        async with httpx.AsyncClient(timeout=60.0) as client:
            try:
                response = await client.post(
                    f"{self.BASE_URL}/chat/completions",
                    json=payload,
                    headers=headers,
                )

                if response.status_code == 401:
                    raise ValueError("Invalid OpenAI API key")
                if response.status_code == 400:
                    body = response.text
                    if "model_not_found" in body:
                        raise ValueError(f"Model not found: {use_model}")
                    raise ValueError(f"OpenAI bad request: {body}")
                if response.status_code == 429:
                    retry_after = response.headers.get("retry-after", "5")
                    try:
                        wait = int(float(retry_after))
                    except (ValueError, TypeError):
                        wait = 5
                    raise RuntimeError(f"rate_limit:{wait}")
                if response.status_code in (500, 503):
                    raise RuntimeError(f"server_error:{response.status_code}")

                response.raise_for_status()
                data = response.json()

                raw_content = data["choices"][0]["message"].get("content") or ""
                if not raw_content.strip():
                    raise RuntimeError("OpenAI returned empty content")
                content = raw_content
                usage = data.get("usage", {})
                input_tokens = usage.get("prompt_tokens", 0)
                output_tokens = usage.get("completion_tokens", 0)

                # Calculate cost
                pricing = MODEL_PRICING.get(use_model, {"input": 2.50, "output": 10.00})
                cost = (input_tokens * pricing["input"] + output_tokens * pricing["output"]) / 1_000_000

                return LLMResponse(
                    content=content,
                    model=use_model,
                    input_tokens=input_tokens,
                    output_tokens=output_tokens,
                    cost_usd=cost,
                )

            except (ValueError, RuntimeError):
                raise
            except httpx.TimeoutException:
                raise RuntimeError("OpenAI API request timed out")
            except httpx.HTTPStatusError as e:
                raise RuntimeError(f"OpenAI API error {e.response.status_code}: {e.response.text}")

    def estimate_tokens(self, text: str) -> int:
        return max(1, len(text) // 4)
