import httpx
import asyncio
from typing import Optional
from .base import LLMProvider, Message, LLMResponse

# Pricing per million tokens (approximate, for cost tracking)
MODEL_PRICING = {
    "claude-opus-4-6": {"input": 15.0, "output": 75.0},
    "claude-sonnet-4-6": {"input": 3.0, "output": 15.0},
    "claude-sonnet-6": {"input": 3.0, "output": 15.0},
    "claude-sonnet-4-20250514": {"input": 3.0, "output": 15.0},
    "claude-haiku-4-5-20251001": {"input": 0.80, "output": 4.0},
}


class AnthropicProvider(LLMProvider):
    BASE_URL = "https://api.anthropic.com/v1"
    API_VERSION = "2023-06-01"

    async def complete(
        self,
        messages: list[Message],
        system: str,
        model: Optional[str] = None,
        max_tokens: int = 4096,
        temperature: float = 0.7
    ) -> LLMResponse:
        use_model = model or self.model

        payload = {
            "model": use_model,
            "max_tokens": max_tokens,
            "temperature": temperature,
            "system": system,
            "messages": [{"role": m.role, "content": m.content} for m in messages if m.role != "system"]
        }

        # oat01 = OAuth token → needs Bearer auth + beta header; standard keys use x-api-key
        if self.api_key.startswith("sk-ant-oat"):
            headers = {
                "Authorization": f"Bearer {self.api_key}",
                "anthropic-version": self.API_VERSION,
                "anthropic-beta": "oauth-2025-04-20",
                "content-type": "application/json"
            }
        else:
            headers = {
                "x-api-key": self.api_key,
                "anthropic-version": self.API_VERSION,
                "content-type": "application/json"
            }

        async with httpx.AsyncClient(timeout=60.0) as client:
            try:
                response = await client.post(
                    f"{self.BASE_URL}/messages",
                    json=payload,
                    headers=headers
                )
                response.raise_for_status()
                data = response.json()

                content_blocks = data.get("content", [])
                if not content_blocks or not content_blocks[0].get("text"):
                    raise RuntimeError("Anthropic returned empty content")
                content = content_blocks[0]["text"]
                usage = data.get("usage", {})
                input_tokens = usage.get("input_tokens", 0)
                output_tokens = usage.get("output_tokens", 0)

                # Calculate cost
                pricing = MODEL_PRICING.get(use_model, {"input": 3.0, "output": 15.0})
                cost = (input_tokens * pricing["input"] + output_tokens * pricing["output"]) / 1_000_000

                return LLMResponse(
                    content=content,
                    model=use_model,
                    input_tokens=input_tokens,
                    output_tokens=output_tokens,
                    cost_usd=cost
                )

            except httpx.HTTPStatusError as e:
                status = e.response.status_code
                response_text = e.response.text
                if status == 401:
                    raise ValueError("Invalid Anthropic API key")
                elif status == 400:
                    raise ValueError(f"Anthropic bad request: {response_text}")
                elif status == 429:
                    retry_after = e.response.headers.get("retry-after", "5")
                    try:
                        wait = int(float(retry_after))
                    except (ValueError, TypeError):
                        wait = 5
                    raise RuntimeError(f"rate_limit:{wait}")
                elif status in (500, 503):
                    raise RuntimeError(f"server_error:{status}")
                else:
                    raise RuntimeError(f"Anthropic API error {status}: {response_text}")
            except httpx.TimeoutException:
                raise RuntimeError("Anthropic API request timed out")

    def estimate_tokens(self, text: str) -> int:
        return max(1, len(text) // 4)
