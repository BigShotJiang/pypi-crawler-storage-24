"""Daily memory log writer - distills BM25 memories into YYYY-MM-DD.md files."""
import logging
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

logger = logging.getLogger(__name__)


class DailyLog:
    """Writes daily memory logs to memory/YYYY-MM-DD.md."""

    def __init__(self, memory_dir: str | Path):
        self.memory_dir = Path(memory_dir)
        self.memory_dir.mkdir(parents=True, exist_ok=True)
        self._last_write_date: Optional[str] = None
        self._entries_since_write: int = 0
        self._write_interval: int = 20  # write after every N new memories

    def record(self, user_id: str, user_message: str, bot_response: str) -> None:
        """Record a conversation turn. Writes to log after write_interval turns."""
        self._entries_since_write += 1
        today = datetime.now(timezone.utc).strftime("%Y-%m-%d")

        if self._entries_since_write >= self._write_interval or self._last_write_date != today:
            self._flush(today)
            self._last_write_date = today
            self._entries_since_write = 0

    def _flush(self, date: str) -> None:
        """Append a session marker to today's log."""
        log_path = self.memory_dir / f"{date}.md"
        timestamp = datetime.now(timezone.utc).strftime("%H:%M UTC")
        try:
            with open(log_path, "a") as f:
                f.write(f"\n## Session checkpoint - {timestamp}\n")
                f.write(f"_(auto-written by DailyLog after {self._write_interval} conversation turns)_\n")
            logger.debug("Daily log written: %s", log_path)
        except Exception as e:
            logger.warning("Failed to write daily log: %s", e)

    def write_shutdown_marker(self) -> None:
        """Write a shutdown marker to today's log."""
        today = datetime.now(timezone.utc).strftime("%Y-%m-%d")
        log_path = self.memory_dir / f"{today}.md"
        timestamp = datetime.now(timezone.utc).strftime("%H:%M UTC")
        try:
            with open(log_path, "a") as f:
                f.write(f"\n## Session ended - {timestamp}\n")
        except Exception as e:
            logger.warning("Failed to write shutdown marker: %s", e)
