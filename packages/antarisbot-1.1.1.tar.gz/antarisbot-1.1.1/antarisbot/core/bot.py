"""
AntarisBot — Main Bot class.

Wires all components together:
  Config → Memory → Guard → Persona → LLM → Pipeline → Channels
"""

import asyncio
import logging
import os
import signal
import sys
from pathlib import Path
from typing import Optional

from antarisbot.core.config import Config, DEFAULT_CONFIG_PATH
from antarisbot.core.logger import setup_logging
from antarisbot.core.memory import BotMemory
from antarisbot.core.guard import BotGuard
from antarisbot.core.updater import Updater
from antarisbot.core.pipeline import Pipeline
from antarisbot.persona.loader import PersonaLoader
from antarisbot.persona.awakening import Awakening
from antarisbot.llm.anthropic import AnthropicProvider
from antarisbot.channels.base import InboundMessage, OutboundMessage, ChannelAdapter
from antarisbot.channels.terminal import TerminalAdapter
from antarisbot.channels.discord import DiscordAdapter
from antarisbot.channels.telegram import TelegramAdapter
from antarisbot.channels.slack import SlackAdapter

logger = logging.getLogger(__name__)


class Bot:
    """
    Main AntarisBot class. Loads config, initializes all components, runs channels.

    Usage:
        Bot().start()                      # all configured channels
        Bot().start(terminal_only=True)    # terminal only
        Bot().chat()                       # alias for terminal mode
    """

    def __init__(self, config_path: Optional[str] = None):
        self.config = Config.load_with_fallback(config_path)
        if not self.config:
            logger.error("Bot not initialized. Run 'antarisbot init' first.")
            sys.exit(1)

        # ── Structured logging — set up before anything else ─────────────
        config_dir = str(Path(self.config.config_path).parent)
        setup_logging(config_dir)
        logger.info("Bot.__init__: config loaded from %s", self.config.config_path)

        errors = self.config.validate()
        if errors:
            logger.error("Configuration errors:")
            print("❌ Configuration errors:")
            for e in errors:
                logger.error("  - %s", e)
            sys.exit(1)

        # ── Components ────────────────────────────────────────────────────
        self._update_notification: Optional[str] = None
        self._first_message_sent: bool = False
        self._message_count: int = 0
        self._compaction_notified: bool = False

        if getattr(self.config, "auto_update", False):
            logger.info("Auto-update enabled — checking for updates...")
        elif getattr(self.config, "notify_updates", True):
            notify_msg = Updater().check_and_notify()
            if notify_msg:
                logger.info("Update available: %s", notify_msg)

        # ── Initialize components ─────────────────────────────────────────
        # Guard: skip if config not yet loaded (setup wizard will run in start())
        self.memory = None
        self.guard = None
        self.persona = None
        self.awakening = None
        self.llm = None
        self.pipeline = None
        self.tool_middleware = None
        self._channels: list[ChannelAdapter] = []

        if not self.config:
            return  # start() will run setup wizard and call _init_components()

        self._init_components()

    def _init_components(self) -> None:
        """Initialise bot components from self.config. Called after config is confirmed loaded."""
        # ── Security setup (must run first — audit hook is irremovable once set) ──
        security_mode = getattr(self.config, "security_mode", "sandboxed")

        # 1. Register audit hook
        from antarisbot.core.guard import register_audit_hook
        # Use the config directory as workspace root (not just memory subdir)
        # so the audit hook allows access to config.json, SOUL.md, etc.
        _config_dir = str(Path(self.config.config_path).parent)
        register_audit_hook(
            security_mode=security_mode,
            workspace_path=_config_dir,
        )

        # 2. Load encryption key for locked mode
        self._encryption_key: Optional[bytes] = None
        if security_mode == "locked":
            try:
                from antarisbot.security.encrypted_store import load_or_create_key
                self._encryption_key = load_or_create_key()
            except Exception as e:
                logger.warning("Could not load encryption key: %s — locked mode memory unencrypted", e)

        self.memory = BotMemory(
            store_path=self.config.memory_store,
            search_limit=self.config.memory_search_limit,
            min_relevance=self.config.memory_min_relevance,
            security_mode=security_mode,
            encryption_key=self._encryption_key,
            agent_name=self.config.bot_name or "AntarisBot",
        )
        from antarisbot.core.daily_log import DailyLog
        self.daily_log = DailyLog(self.config.memory_store)
        self.guard = BotGuard(mode=self.config.guard_mode)

        # ── Tool middleware ────────────────────────────────────────────────
        from antarisbot.security.tool_middleware import ToolMiddleware
        _audit_log_path = str(Path.home() / ".antarisbot" / "audit.log")
        self.tool_middleware = ToolMiddleware(
            mode=security_mode,
            audit_log_path=_audit_log_path,
        )

        self.persona = PersonaLoader()
        self.awakening = Awakening(self.persona)

        if self.config.provider_name == "ollama":
            from antarisbot.llm.ollama import OllamaProvider
            base_url = getattr(self.config, "ollama_base_url", "http://localhost:11434/v1")
            self.llm = OllamaProvider(model=self.config.model, base_url=base_url)
        elif self.config.provider_name == "openai":
            from antarisbot.llm.openai import OpenAIProvider
            self.llm = OpenAIProvider(api_key=self.config.api_key, model=self.config.model)
        elif self.config.provider_name == "google":
            from antarisbot.llm.google import GoogleProvider
            self.llm = GoogleProvider(api_key=self.config.api_key, model=self.config.model)
        else:
            self.llm = AnthropicProvider(api_key=self.config.api_key, model=self.config.model)

        # ── Multi-provider dispatcher for routing ─────────────────────────
        from antarisbot.llm.dispatcher import LLMDispatcher
        self.dispatcher = LLMDispatcher()

        # Register the primary provider
        self.dispatcher.register(self.config.provider_name, self.llm)

        # Register additional providers if API keys are available in config
        _extra_providers = {
            "anthropic": ("antarisbot.llm.anthropic", "AnthropicProvider"),
            "openai": ("antarisbot.llm.openai", "OpenAIProvider"),
            "google": ("antarisbot.llm.google", "GoogleProvider"),
            "ollama": ("antarisbot.llm.ollama", "OllamaProvider"),
        }
        for _pname, (_mod, _cls) in _extra_providers.items():
            if _pname == self.config.provider_name:
                continue  # already registered as primary
            try:
                import importlib
                _m = importlib.import_module(_mod)
                _provider_cls = getattr(_m, _cls)
                if _pname == "ollama":
                    # Ollama uses baseUrl, not api_key
                    _base_url = getattr(self.config, "ollama_base_url", "http://localhost:11434/v1")
                    _extra_llm = _provider_cls(base_url=_base_url)
                    self.dispatcher.register(_pname, _extra_llm)
                    logger.info("Registered extra provider: ollama (%s)", _base_url)
                else:
                    _key = getattr(self.config, f"{_pname}_api_key", None)
                    if _key:
                        _extra_llm = _provider_cls(api_key=_key, model=self.config.model)
                        self.dispatcher.register(_pname, _extra_llm)
                        logger.info("Registered extra provider: %s", _pname)
            except Exception as _e:
                logger.warning("Could not register extra provider %s: %s", _pname, _e)

        # ── Router (antaris-router) ────────────────────────────────────────
        self.router = None
        _router_config = getattr(self.config, "router_config_path", None)
        if _router_config:
            try:
                from antaris_router import Router
                self.router = Router(config_path=_router_config)
                logger.info("Router initialized from config: %s", _router_config)
            except Exception as _e:
                logger.warning("Could not initialize router: %s", _e)

        # ── User profiles ─────────────────────────────────────────────────
        from antarisbot.core.profiles import ProfileManager
        _profiles_path = Path(self.config.config_path).parent / "profiles"
        self.profiles = ProfileManager(profiles_dir=_profiles_path)

        # ── Teaching store ────────────────────────────────────────────────
        from antarisbot.core.teachings import TeachingStore
        _teachings_path = Path(self.config.config_path).parent / "teachings"
        self.teachings = TeachingStore(store_dir=_teachings_path)

        # ── Focus manager ─────────────────────────────────────────────────
        from antarisbot.core.focus import FocusManager
        self.focus = FocusManager()

        # ── Thread manager ────────────────────────────────────────────────
        from antarisbot.core.threads import ThreadManager
        _threads_path = Path(self.config.config_path).parent / "threads"
        self.threads = ThreadManager(_threads_path)

        # ── Shortcut learner ──────────────────────────────────────────────
        from antarisbot.core.shortcuts import ShortcutLearner
        _shortcuts_path = Path(self.config.config_path).parent / "shortcuts"
        self.shortcuts = ShortcutLearner(_shortcuts_path)

        # ── Conversation exporter ─────────────────────────────────────────
        from antarisbot.core.exporter import ConversationExporter
        _exports_path = Path(self.config.config_path).parent / "exports"
        self.exporter = ConversationExporter(self.memory, _exports_path)

        # ── Proactive memory ──────────────────────────────────────────────
        from antarisbot.core.proactive import ProactiveMemory
        _proactive_path = Path(self.config.config_path).parent / "proactive"
        self.proactive = ProactiveMemory(_proactive_path)

        # ── Mood detector ─────────────────────────────────────────────────
        from antarisbot.core.mood import MoodDetector
        self.mood = MoodDetector(window_size=10)

        # ── Feedback tracker ──────────────────────────────────────────────
        from antarisbot.core.feedback import FeedbackTracker
        _feedback_path = Path(self.config.config_path).parent / "feedback"
        self.feedback = FeedbackTracker(store_dir=str(_feedback_path))

        self.pipeline = Pipeline(
            config=self.config,
            memory=self.memory,
            guard=self.guard,
            persona=self.persona,
            llm=self.llm,
            awakening=self.awakening,
            tool_middleware=self.tool_middleware,
            router=self.router,
            dispatcher=self.dispatcher,
            profiles=self.profiles,
            teachings=self.teachings,
            focus=self.focus,
            threads=self.threads,
            shortcuts=self.shortcuts,
            proactive=self.proactive,
            mood=self.mood,
            feedback=self.feedback,
        )

        # ── Cron scheduler ────────────────────────────────────────────────
        from antarisbot.core.cron import CronScheduler
        _jobs_path = Path(self.config.config_path).parent / "cron" / "jobs.json"
        self.cron = CronScheduler(jobs_path=_jobs_path, on_fire=self._on_cron_fire)

        # ── Command dispatcher ────────────────────────────────────────────
        from antarisbot.core.commands import CommandDispatcher
        self.commands = CommandDispatcher(self)
        self.pipeline.commands = self.commands

        self._accepting_messages = True

    async def _on_cron_fire(self, job) -> None:
        """Handle a fired cron job."""
        from antarisbot.channels.base import InboundMessage
        logger.info("Cron job fired: %s (%s)", job.id, job.name)
        if job.payload_kind == "agentTurn":
            # Fire as a synthetic message through the pipeline
            inbound = InboundMessage(
                id=f"cron_{job.id}",
                user_id="system_cron",
                user_name="system_cron",
                channel_id=job.channel_id or "",
                platform="internal",
                text=job.payload_text,
            )
            # Find the right adapter for this channel
            adapter = None
            for ch in self._channels:
                if hasattr(ch, 'channel_id') and ch.channel_id == job.channel_id:
                    adapter = ch
                    break
            if not adapter and self._channels:
                adapter = self._channels[0]
            if adapter:
                result = await self.pipeline.process(inbound, adapter)
                if result.response_text:
                    from antarisbot.channels.base import OutboundMessage
                    await adapter.send(OutboundMessage(
                        channel_id=job.channel_id or "",
                        text=result.response_text,
                    ))
        elif job.payload_kind == "systemEvent":
            logger.info("Cron systemEvent: %s", job.payload_text[:100])

    def start(self, terminal_only: bool = False):
        """Launch the bot. Blocks until stopped."""
        # Run setup wizard if the bot has not been configured yet
        from antarisbot.setup.wizard import SetupWizard
        if SetupWizard().is_needed():
            cfg = SetupWizard().run()
            if cfg:
                self.config = cfg
                self._init_components()
            else:
                logger.error("Setup was cancelled. Run 'antaris setup' to configure.")
                return

        if not self.config:
            logger.error("Bot not initialized. Run 'antaris setup' or 'antaris init' first.")
            sys.exit(1)

        signal.signal(signal.SIGINT, self._handle_shutdown)
        signal.signal(signal.SIGTERM, self._handle_shutdown)

        try:
            asyncio.run(self._run(terminal_only=terminal_only))
        except KeyboardInterrupt:
            logger.info("KeyboardInterrupt received, shutting down.")
            print("\n👋 Stopped.")

    def chat(self):
        """Alias for terminal-only mode."""
        self.start(terminal_only=True)

    # ── Graceful shutdown ─────────────────────────────────────────────────

    def _handle_shutdown(self, sig, frame):
        """Flush memory, set shutdown flag, exit cleanly."""
        logger.info("Shutdown signal received (sig=%s), flushing memory...", sig)
        self._accepting_messages = False

        # Flush memory store
        try:
            if self.memory:
                for user_id, store in self.memory._stores.items():
                    try:
                        store.save()
                    except Exception:
                        pass
                logger.info("Memory stores flushed.")
        except Exception as e:
            logger.warning("Memory save failed during shutdown: %s", e)

        # Remove PID file
        pid_file = Path.home() / ".antarisbot" / "bot.pid"
        try:
            pid_file.unlink(missing_ok=True)
        except Exception:
            pass

        # Write daily log shutdown marker
        if hasattr(self, 'daily_log'):
            try:
                self.daily_log.write_shutdown_marker()
            except Exception as _e:
                logger.warning("DailyLog shutdown marker failed: %s", _e)

        # Stop cron scheduler
        if hasattr(self, 'cron') and self.cron:
            try:
                import asyncio as _asyncio
                _asyncio.get_event_loop().run_until_complete(self.cron.stop())
            except Exception as _e:
                logger.warning("Cron stop failed: %s", _e)

        logger.info("Bot shut down cleanly.")
        sys.exit(0)

    # ── Internal ──────────────────────────────────────────────────────────

    def _setup_channels(self, terminal_only: bool):
        self._channels = []

        if terminal_only:
            self._channels.append(TerminalAdapter(bot_name=self.config.bot_name))
            return

        if self.config.discord_enabled and self.config.discord_token:
            self._channels.append(
                DiscordAdapter(
                    token=self.config.discord_token,
                    bot_name=self.config.bot_name,
                    open_channels=self.config.discord_open_channels or [],
                    bot_memory=self.memory,
                    bot_llm=self.llm,
                    feedback_tracker=getattr(self, "feedback", None),
                )
            )

        if self.config.telegram_enabled and self.config.telegram_token:
            self._channels.append(
                TelegramAdapter(
                    token=self.config.telegram_token,
                    bot_name=self.config.bot_name,
                    open_chats=getattr(self.config, "telegram_open_chats", None) or [],
                )
            )

        if (
            getattr(self.config, "slack_enabled", False)
            and getattr(self.config, "slack_bot_token", "")
            and getattr(self.config, "slack_app_token", "")
        ):
            self._channels.append(
                SlackAdapter(
                    bot_token=self.config.slack_bot_token,
                    app_token=self.config.slack_app_token,
                    open_channels=getattr(self.config, "slack_open_channels", None) or [],
                )
            )

        if not self._channels:
            logger.warning("No channels configured — falling back to terminal mode.")
            logger.info("Tip: Run 'antarisbot init' to add Discord or Telegram.")
            print("   ⚠️  No channels configured. Starting in terminal mode.")
            print("   Tip: Run 'antarisbot init' to add Discord or Telegram.")
            self._channels.append(TerminalAdapter(bot_name=self.config.bot_name))
    async def _run(self, terminal_only: bool = False):
        self._setup_channels(terminal_only=terminal_only)
        if hasattr(self, 'cron') and self.cron:
            await self.cron.start()
        self._print_banner()
        for adapter in self._channels:
            adapter.on_message(self._make_handler(adapter))
        results = await asyncio.gather(
            *[adapter.connect() for adapter in self._channels],
            return_exceptions=True,
        )
        for adapter, result in zip(self._channels, results):
            if isinstance(result, Exception):
                name = type(adapter).__name__
                logger.error("Channel %s failed to connect: %s", name, result)
                print(f"   ❌ {name} failed: {result}")

    def _make_handler(self, adapter: ChannelAdapter):
        async def handle(inbound: InboundMessage):
            if not self._accepting_messages:
                logger.debug("Ignoring message during shutdown from user=%s", inbound.user_id)
                return
            if not self._first_message_sent and self._update_notification:
                self._first_message_sent = True
                try:
                    await adapter.send(
                        OutboundMessage(
                            channel_id=inbound.channel_id,
                            text=self._update_notification,
                            reply_to=None,
                        )
                    )
                except Exception as exc:
                    logger.warning("Could not send update notification: %s", exc)
            elif not self._first_message_sent:
                self._first_message_sent = True

            result = await self.pipeline.process(inbound, adapter)

            # Track message count for compaction detection
            self._message_count += 1
            _threshold = getattr(self.config, 'compaction_threshold', 80)
            if (self._message_count >= _threshold
                    and not self._compaction_notified
                    and getattr(self.config, 'owner_user_id', '')):
                self._compaction_notified = True
                asyncio.create_task(self._send_compaction_ping(adapter))

            if result.success and result.response_text:
                if hasattr(self, 'daily_log'):
                    try:
                        self.daily_log.record(inbound.user_id, inbound.text, result.response_text)
                    except Exception as _dl_err:
                        logger.warning("DailyLog record failed: %s", _dl_err)

            if result.response_text:
                await adapter.send(
                    OutboundMessage(
                        channel_id=inbound.channel_id,
                        text=result.response_text,
                        reply_to=inbound.id,
                    )
                )
            if result.error:
                logger.error("Pipeline error for user=%s: %s", inbound.user_id, result.error)
            if result.failed_stages:
                logger.debug("Failed stages for user=%s: %s", inbound.user_id, result.failed_stages)
        return handle

    def _print_banner(self):
        """Log startup info."""
        memory_count = self._memory_count()
        channel_names = [type(c).__name__.replace("Adapter", "") for c in self._channels]

        logger.info(
            "Starting %s | memory=%d | guard=%s | model=%s via %s | channels=%s",
            self.config.bot_name, memory_count, self.config.guard_mode,
            self.config.model, self.config.provider_name, ", ".join(channel_names),
        )

        security_mode = getattr(self.config, "security_mode", "sandboxed")
        print(f"\n🤖 {self.config.bot_name} starting...")
        print(f"   Memory: {memory_count} entries")
        print(f"   Security: {security_mode} mode")
        print(f"   Guard: {self.config.guard_mode} mode")
        print(f"   Model: {self.config.model} via {self.config.provider_name}")
        print(f"   Channels: {', '.join(channel_names)}")
        if self.awakening.is_needed():
            logger.info("Identity: Awakening needed")
        else:
            logger.info("Identity: SOUL.md loaded")

    def _memory_count(self) -> int:
        try:
            return self.memory.stats().get("total", 0)
        except Exception:
            return 0

    async def _send_compaction_ping(self, adapter) -> None:
        """DM the owner when message count hits compaction threshold."""
        owner_id = getattr(self.config, 'owner_user_id', '')
        if not owner_id:
            return
        msg = (
            f"Context is getting long ({self._message_count} messages). "
            "Consider starting a fresh session."
        )
        try:
            from antarisbot.channels.discord import DiscordAdapter
            if isinstance(adapter, DiscordAdapter) and hasattr(adapter, '_client') and adapter._client:
                user = await adapter._client.fetch_user(int(owner_id))
                if user:
                    await user.send(msg)
                    logger.info("Sent compaction ping to owner %s", owner_id)
                    return
        except Exception as e:
            logger.warning("Could not send compaction DM: %s", e)
        # Fallback: log only
        logger.warning("COMPACTION PING (no DM sent): %s", msg)
