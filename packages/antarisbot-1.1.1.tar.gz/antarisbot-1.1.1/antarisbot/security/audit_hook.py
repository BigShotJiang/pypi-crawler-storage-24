"""AntarisBot audit hook — filesystem, subprocess, network enforcement via sys.addaudithook()."""
from __future__ import annotations

import site
import sys
from pathlib import Path

# ---------------------------------------------------------------------------
# Module-level state (mutated once by install())
# ---------------------------------------------------------------------------
_MODE: str = "open"
_WORKSPACE: str = ""
_ALLOWED_PATHS: set[str] = set()

# Hosts always permitted in locked mode
ALLOWED_HOSTS: set[str] = {
    "api.anthropic.com",
    "api.openai.com",
    "generativelanguage.googleapis.com",
    "localhost",
    "127.0.0.1",
}


def _build_allowed_paths() -> set[str]:
    """Collect Python stdlib and site-packages roots that are always safe."""
    candidates: list[str] = [
        sys.prefix,
        sys.base_prefix,
        sys.exec_prefix,
        getattr(sys, "base_exec_prefix", sys.exec_prefix),
    ]
    # site-packages directories
    try:
        candidates.extend(site.getsitepackages())
    except AttributeError:
        pass
    try:
        candidates.append(site.getusersitepackages())
    except AttributeError:
        pass
    # Standard lib location (CPython)
    try:
        import sysconfig
        stdlib = sysconfig.get_path("stdlib")
        platstdlib = sysconfig.get_path("platstdlib")
        if stdlib:
            candidates.append(stdlib)
        if platstdlib:
            candidates.append(platstdlib)
    except Exception:
        pass

    allowed: set[str] = set()
    for p in candidates:
        if p:
            try:
                allowed.add(str(Path(p).resolve()))
            except Exception:
                pass
    return allowed


def install(security_mode: str, workspace_path: str) -> None:
    """Register the AntarisBot audit hook for the given security mode.

    This calls ``sys.addaudithook`` which is **irremovable** for the lifetime
    of the interpreter — call it exactly once, at bot startup.

    Args:
        security_mode: One of ``"open"``, ``"sandboxed"``, ``"locked"``.
        workspace_path: Absolute path to the bot's workspace root.
    """
    global _MODE, _WORKSPACE, _ALLOWED_PATHS

    _MODE = security_mode
    _WORKSPACE = str(Path(workspace_path).resolve())
    _ALLOWED_PATHS = _build_allowed_paths()

    # Always allow the bot's own package directory (needed to import its own modules)
    _bot_pkg_dir = str(Path(__file__).resolve().parent.parent)
    _ALLOWED_PATHS.add(_bot_pkg_dir)

    # Allow antaris-suite package directories (may be editable installs outside site-packages)
    for _mod_name in ("antaris_memory", "antaris_guard", "antaris_context", "antaris_router", "antaris_pipeline"):
        try:
            _mod = __import__(_mod_name)
            _mod_dir = str(Path(_mod.__file__).resolve().parent)
            _ALLOWED_PATHS.add(_mod_dir)
        except Exception:
            pass

    # Also allow the workspace path itself
    _ALLOWED_PATHS.add(_WORKSPACE)

    sys.addaudithook(_antaris_hook)


# ---------------------------------------------------------------------------
# The audit hook
# ---------------------------------------------------------------------------

def _antaris_hook(event: str, args: tuple) -> None:  # noqa: C901
    """sys.audit hook — enforces sandboxed/locked restrictions."""
    # Fast path: no restrictions in open mode
    if _MODE == "open":
        return

    try:
        # ------------------------------------------------------------------ #
        # File access
        # ------------------------------------------------------------------ #
        if event == "open":
            # args: (path, mode, flags)
            raw_path = args[0] if args else None
            if raw_path is None:
                return

            try:
                resolved = str(Path(str(raw_path)).resolve())
            except Exception:
                return  # can't resolve → allow (best effort)

            # Allow anything inside the workspace
            if resolved.startswith(_WORKSPACE):
                return

            # Allow /tmp
            if resolved.startswith("/tmp"):
                return

            # Allow Python's own paths (stdlib, site-packages, venv, …)
            for allowed in _ALLOWED_PATHS:
                if resolved.startswith(allowed):
                    return

            raise PermissionError(
                f"[AntarisBot/sandboxed] File access blocked: {resolved}"
            )

        # ------------------------------------------------------------------ #
        # Subprocess
        # ------------------------------------------------------------------ #
        elif event == "subprocess.Popen":
            raise PermissionError(
                "[AntarisBot] Subprocess execution blocked in sandboxed/locked mode"
            )

        # ------------------------------------------------------------------ #
        # exec() — locked only
        # ------------------------------------------------------------------ #
        elif event == "exec":
            if _MODE == "locked":
                raise PermissionError(
                    "[AntarisBot/locked] Code execution blocked"
                )

        # ------------------------------------------------------------------ #
        # Network — locked only
        # ------------------------------------------------------------------ #
        elif event == "socket.connect":
            if _MODE == "locked":
                # args varies by address family; try to extract host
                addr = args[1] if len(args) > 1 else None
                if addr is None:
                    return
                if isinstance(addr, (list, tuple)) and len(addr) >= 1:
                    host = str(addr[0])
                elif isinstance(addr, str):
                    # Unix socket path — allow
                    return
                else:
                    return

                if host not in ALLOWED_HOSTS:
                    raise PermissionError(
                        f"[AntarisBot/locked] Network access blocked: {host}"
                    )

    except PermissionError:
        # Always propagate PermissionError — that's how we block things
        raise
    except Exception:
        # Swallow everything else; we must never crash the bot
        pass
