"""Context cadence system — controls which .md files inject into the system prompt and when.

Configuration via ~/.antarisbot/context.json:

    {
        "SOUL.md": "every",
        "TOOLS.md": "startup",
        "RULES.md": "every",
        "SPECS.md": "manual"
    }

Cadences:
    every   — inject on every message (like SOUL.md always has)
    startup — inject on first message only, skip after that
    manual  — never auto-inject, only when explicitly requested
    
Files NOT in context.json default to "manual" (not injected).
USER.md is handled separately by the persona loader — not controlled here.
"""

import json
import logging
from pathlib import Path
from typing import Optional

logger = logging.getLogger(__name__)

VALID_CADENCES = {"every", "startup", "manual"}
DEFAULT_CONTEXT = {"SOUL.md": "every"}


class ContextCadence:
    """Manages which .md files inject into the system prompt and when."""

    def __init__(self, config_dir: str | Path):
        self.config_dir = Path(config_dir)
        self.context_path = self.config_dir / "context.json"
        self._config = self._load()
        self._startup_done: set[str] = set()  # tracks which startup files have fired

    def _load(self) -> dict[str, str]:
        """Load context.json or return defaults."""
        if self.context_path.exists():
            try:
                data = json.loads(self.context_path.read_text())
                # Validate cadences
                validated = {}
                for name, cadence in data.items():
                    if cadence in VALID_CADENCES:
                        validated[name] = cadence
                    else:
                        logger.warning("context.json: invalid cadence '%s' for %s, using 'manual'", cadence, name)
                        validated[name] = "manual"
                return validated
            except Exception as e:
                logger.warning("Failed to load context.json: %s", e)
        return dict(DEFAULT_CONTEXT)

    def get_files_for_turn(self) -> list[tuple[str, str]]:
        """Get (filename, content) pairs that should inject this turn.
        
        Returns files whose cadence allows injection right now.
        """
        result = []
        for name, cadence in self._config.items():
            if cadence == "manual":
                continue
            if cadence == "startup" and name in self._startup_done:
                continue

            path = self.config_dir / name
            if not path.exists():
                continue

            content = path.read_text().strip()
            if not content:
                continue

            result.append((name, content))

            if cadence == "startup":
                self._startup_done.add(name)

        return result

    def get_file(self, name: str) -> Optional[str]:
        """Get a specific file's content (for manual injection)."""
        path = self.config_dir / name
        if path.exists():
            return path.read_text().strip() or None
        return None

    def reload(self):
        """Reload context.json (for hot-reload)."""
        self._config = self._load()

    @property
    def config(self) -> dict[str, str]:
        return dict(self._config)
