"""Metadata for markpickle."""

__all__ = [
    "__title__",
    "__version__",
    "__description__",
    "__credits__",
    "__readme__",
    "__requires_python__",
    "__keywords__",
    "__status__",
]

__title__ = "markpickle"
__version__ = "1.6.4"
__description__ = "Lossy python to markdown serializer"
__credits__ = [{"name": "Matthew Martin", "email": "matthewdeanmartin@gmail.com"}]
__readme__ = "README.md"
__requires_python__ = ">=3.8,<4.0"
__keywords__ = ["serializer", "deserializer", "markdown"]
__status__ = "3 - Alpha"
