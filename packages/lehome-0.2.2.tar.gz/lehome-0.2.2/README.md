# LeHome CLI

`lehome` 是一个面向 LeHome Challenge 的可分发 uv CLI。

它把 `/root/data/lehome_cli` 里的源脚本打包成 runtime bundle，在目标机器上自动解包到稳定目录，再提供：

- 一个超级菜单入口
- 原版 `all.sh` 的直达入口
- `step1 / step2 / step3 / ai / git / diff / vpn` 这些老脚本的直达入口

## 用户用法

推荐直接运行：

```bash
uvx lehome
```

如果你想在 PyPI 发布前先从 GitHub 直接跑：

```bash
uvx --from git+https://github.com/sudo-yf/lehome.git lehome
```

常用命令：

```bash
uvx lehome --help
uvx lehome all --list
uvx lehome step1
uvx lehome step2
uvx lehome step3
uvx lehome ai
uvx lehome git 1
uvx lehome diff
uvx lehome vpn
uvx lehome doctor
uvx lehome version
uv tool run --from git+https://github.com/sudo-yf/lehome.git lehome --help
uv tool run --from git+https://github.com/sudo-yf/lehome.git lehome all --list
uv tool run --from git+https://github.com/sudo-yf/lehome.git lehome step1
uv tool run --from git+https://github.com/sudo-yf/lehome.git lehome step2
uv tool run --from git+https://github.com/sudo-yf/lehome.git lehome step3
uv tool run --from git+https://github.com/sudo-yf/lehome.git lehome ai
uv tool run --from git+https://github.com/sudo-yf/lehome.git lehome git 1
uv tool run --from git+https://github.com/sudo-yf/lehome.git lehome diff
uv tool run --from git+https://github.com/sudo-yf/lehome.git lehome vpn
uv tool run --from git+https://github.com/sudo-yf/lehome.git lehome doctor
uv tool run --from git+https://github.com/sudo-yf/lehome.git lehome version
```

如果你已经在本地 clone 了仓库，也可以这样调试：

```bash
uv tool run --from . lehome
```

## 环境变量

默认值：

- `DATA_ROOT=/root/data`
- `LEHOME_REPO_URL=https://github.com/sudo-yf/lehome-challenge.git`
- `LEHOME_DEFAULT_DIRNAME=lehome-challenge`

示例：

```bash
DATA_ROOT=/tmp/lehome-data \
LEHOME_REPO_URL=https://github.com/sudo-yf/lehome-challenge.git \
uv tool run --from git+https://github.com/sudo-yf/lehome.git lehome doctor
```

## 维护说明

`/root/data/lehome_cli` 是源真相，`/root/data/lehome` 是分发仓库。

当源脚本更新后，在本仓库运行：

```bash
python tools/import_runtime.py --source /root/data/lehome_cli
```

这个脚本会：

- 校验源文件存在
- 复制到 `src/lehome_cli/bundle/`
- 生成 `manifest.json`

平台约束：

- 仅支持 Linux / Ubuntu / bash
- 不承诺 Windows / macOS 可用
