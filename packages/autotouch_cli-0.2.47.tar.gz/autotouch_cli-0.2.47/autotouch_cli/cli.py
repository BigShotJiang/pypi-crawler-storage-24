#!/usr/bin/env python3
"""
Smart Table CLI

Agent-friendly command-line helper for Smart Table API automation.

Features:
- Capabilities discovery
- Table and column management
- Row creation and cell patching
- Column run + estimate
- Sequence management + enrollment helpers
- Table webhook token + ingest helpers
- Bulk-job polling
- Optional Mongo-backed status/watch helpers

Environment variables:
- SMARTTABLE_API_URL   (default: https://app.autotouch.ai)
- SMARTTABLE_TOKEN     (developer key or JWT bearer, or pass --token)
- MONGODB_URI          (for status when using direct DB aggregation)
- MONGODB_DB_NAME      (default: autotouch)
"""

from __future__ import annotations

import argparse
import csv
import getpass
import importlib.resources as importlib_resources
import json
import os
import sys
import time
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import requests
from autotouch_cli.cli_contracts import (
    build_cli_manifest as build_cli_manifest_payload,
    build_cli_reference_markdown,
)
from autotouch_cli.commands.columns import (
    ColumnCommandRuntime as ColumnCommandHandlerRuntime,
    cmd_columns_create as cmd_columns_create_impl,
    cmd_columns_delete as cmd_columns_delete_impl,
    cmd_columns_estimate as cmd_columns_estimate_impl,
    cmd_columns_list as cmd_columns_list_impl,
    cmd_columns_projections as cmd_columns_projections_impl,
    cmd_columns_run as cmd_columns_run_impl,
    cmd_columns_run_next as cmd_columns_run_next_impl,
    cmd_columns_stop as cmd_columns_stop_impl,
    cmd_columns_test_http_request as cmd_columns_test_http_request_impl,
    cmd_columns_update as cmd_columns_update_impl,
    register_columns_subcommands,
)
from autotouch_cli.commands.cells import (
    CellCommandRuntime as CellCommandHandlerRuntime,
    cmd_cells_get as cmd_cells_get_impl,
    cmd_cells_patch as cmd_cells_patch_impl,
    cmd_cells_schema as cmd_cells_schema_impl,
    register_cells_subcommands,
)
from autotouch_cli.commands.auth import (
    AuthCommandRuntime as AuthCommandHandlerRuntime,
    cmd_auth_bootstrap as cmd_auth_bootstrap_impl,
    cmd_auth_check as cmd_auth_check_impl,
    cmd_auth_clear as cmd_auth_clear_impl,
    cmd_auth_login as cmd_auth_login_impl,
    cmd_auth_set_key as cmd_auth_set_key_impl,
    cmd_auth_show as cmd_auth_show_impl,
    cmd_auth_whoami as cmd_auth_whoami_impl,
    register_auth_subcommands,
)
from autotouch_cli.commands.jobs import (
    JobCommandRuntime as JobCommandHandlerRuntime,
    cmd_jobs_get as cmd_jobs_get_impl,
    cmd_jobs_list as cmd_jobs_list_impl,
    cmd_jobs_watch as cmd_jobs_watch_impl,
    register_jobs_subcommands,
)
from autotouch_cli.commands.leads import (
    LeadCommandRuntime as LeadCommandHandlerRuntime,
    cmd_leads_count as cmd_leads_count_impl,
    cmd_leads_create as cmd_leads_create_impl,
    cmd_leads_filters_metadata as cmd_leads_filters_metadata_impl,
    cmd_leads_get as cmd_leads_get_impl,
    cmd_leads_query as cmd_leads_query_impl,
    cmd_leads_reassign_owner as cmd_leads_reassign_owner_impl,
    cmd_leads_research as cmd_leads_research_impl,
    cmd_leads_research_tables as cmd_leads_research_tables_impl,
    cmd_leads_stats as cmd_leads_stats_impl,
    cmd_leads_update as cmd_leads_update_impl,
    cmd_leads_update_status as cmd_leads_update_status_impl,
    cmd_leads_upsert_contact_channels as cmd_leads_upsert_contact_channels_impl,
    register_leads_subcommands,
)
from autotouch_cli.commands.linkedin import (
    LinkedInCommandRuntime as LinkedInCommandHandlerRuntime,
    cmd_linkedin_comments as cmd_linkedin_comments_impl,
    cmd_linkedin_limits as cmd_linkedin_limits_impl,
    cmd_linkedin_post as cmd_linkedin_post_impl,
    cmd_linkedin_posts as cmd_linkedin_posts_impl,
    cmd_linkedin_reactions as cmd_linkedin_reactions_impl,
    cmd_linkedin_recipe as cmd_linkedin_recipe_impl,
    cmd_linkedin_search as cmd_linkedin_search_impl,
    cmd_linkedin_search_params as cmd_linkedin_search_params_impl,
    cmd_linkedin_status as cmd_linkedin_status_impl,
    register_linkedin_subcommands,
)
from autotouch_cli.commands.rows import (
    RowCommandRuntime as RowCommandHandlerRuntime,
    cmd_rows_add as cmd_rows_add_impl,
    cmd_rows_delete as cmd_rows_delete_impl,
    cmd_rows_get as cmd_rows_get_impl,
    cmd_rows_import_csv as cmd_rows_import_csv_impl,
    cmd_rows_import_rollback as cmd_rows_import_rollback_impl,
    cmd_rows_import_status as cmd_rows_import_status_impl,
    cmd_rows_import_verify as cmd_rows_import_verify_impl,
    cmd_rows_list as cmd_rows_list_impl,
    register_rows_subcommands,
)
from autotouch_cli.commands.search import (
    SearchCommandRuntime as SearchCommandHandlerRuntime,
    cmd_search_companies as cmd_search_companies_impl,
    cmd_search_filings as cmd_search_filings_impl,
    cmd_search_local_businesses as cmd_search_local_businesses_impl,
    cmd_search_news as cmd_search_news_impl,
    cmd_search_people as cmd_search_people_impl,
    cmd_search_recipe as cmd_search_recipe_impl,
    cmd_search_reviews as cmd_search_reviews_impl,
    cmd_search_similar_companies as cmd_search_similar_companies_impl,
    register_search_subcommands,
)
from autotouch_cli.commands.sequences import (
    SequenceCommandRuntime as SequenceCommandHandlerRuntime,
    cmd_sequences_clone as cmd_sequences_clone_impl,
    cmd_sequences_create as cmd_sequences_create_impl,
    cmd_sequences_delete as cmd_sequences_delete_impl,
    cmd_sequences_delivery_status as cmd_sequences_delivery_status_impl,
    cmd_sequences_enroll as cmd_sequences_enroll_impl,
    cmd_sequences_get as cmd_sequences_get_impl,
    cmd_sequences_list as cmd_sequences_list_impl,
    cmd_sequences_pause_enrollment as cmd_sequences_pause_enrollment_impl,
    cmd_sequences_stats as cmd_sequences_stats_impl,
    cmd_sequences_status as cmd_sequences_status_impl,
    cmd_sequences_update as cmd_sequences_update_impl,
    register_sequences_subcommands,
)
from autotouch_cli.commands.tables import (
    TableCommandRuntime as TableCommandHandlerRuntime,
    cmd_tables_create as cmd_tables_create_impl,
    cmd_tables_list as cmd_tables_list_impl,
    register_tables_subcommands,
)
from autotouch_cli.commands.tasks import (
    TaskCommandRuntime as TaskCommandHandlerRuntime,
    cmd_tasks_assignee_counts as cmd_tasks_assignee_counts_impl,
    cmd_tasks_bulk_delete as cmd_tasks_bulk_delete_impl,
    cmd_tasks_bulk_update as cmd_tasks_bulk_update_impl,
    cmd_tasks_count as cmd_tasks_count_impl,
    cmd_tasks_create as cmd_tasks_create_impl,
    cmd_tasks_delete as cmd_tasks_delete_impl,
    cmd_tasks_draft as cmd_tasks_draft_impl,
    cmd_tasks_get as cmd_tasks_get_impl,
    cmd_tasks_query as cmd_tasks_query_impl,
    cmd_tasks_recipe as cmd_tasks_recipe_impl,
    cmd_tasks_schedule_email as cmd_tasks_schedule_email_impl,
    cmd_tasks_stats as cmd_tasks_stats_impl,
    cmd_tasks_update as cmd_tasks_update_impl,
)
from autotouch_cli.commands.webhooks import (
    WebhookCommandRuntime as WebhookCommandHandlerRuntime,
    cmd_webhooks_deliveries_attempts as cmd_webhooks_deliveries_attempts_impl,
    cmd_webhooks_deliveries_list as cmd_webhooks_deliveries_list_impl,
    cmd_webhooks_get as cmd_webhooks_get_impl,
    cmd_webhooks_ingest as cmd_webhooks_ingest_impl,
    cmd_webhooks_recipe as cmd_webhooks_recipe_impl,
    cmd_webhooks_rotate as cmd_webhooks_rotate_impl,
    cmd_webhooks_subscriptions_create as cmd_webhooks_subscriptions_create_impl,
    cmd_webhooks_subscriptions_delete as cmd_webhooks_subscriptions_delete_impl,
    cmd_webhooks_subscriptions_get as cmd_webhooks_subscriptions_get_impl,
    cmd_webhooks_subscriptions_list as cmd_webhooks_subscriptions_list_impl,
    cmd_webhooks_subscriptions_pause as cmd_webhooks_subscriptions_pause_impl,
    cmd_webhooks_subscriptions_resume as cmd_webhooks_subscriptions_resume_impl,
    cmd_webhooks_subscriptions_rotate_secret as cmd_webhooks_subscriptions_rotate_secret_impl,
    cmd_webhooks_subscriptions_test as cmd_webhooks_subscriptions_test_impl,
    cmd_webhooks_subscriptions_update as cmd_webhooks_subscriptions_update_impl,
)
from autotouch_cli.commands.prompts import (
    PromptCommandRuntime as PromptCommandHandlerRuntime,
    cmd_prompts_create as cmd_prompts_create_impl,
    cmd_prompts_delete as cmd_prompts_delete_impl,
    cmd_prompts_get as cmd_prompts_get_impl,
    cmd_prompts_list as cmd_prompts_list_impl,
    cmd_prompts_update as cmd_prompts_update_impl,
    register_prompts_subcommands,
)
from autotouch_cli.commands.workspace_secrets import (
    WorkspaceSecretCommandRuntime as WorkspaceSecretCommandHandlerRuntime,
    cmd_workspace_secrets_delete as cmd_workspace_secrets_delete_impl,
    cmd_workspace_secrets_list as cmd_workspace_secrets_list_impl,
    cmd_workspace_secrets_set as cmd_workspace_secrets_set_impl,
    register_workspace_secrets_subcommands,
)
from autotouch_cli.core.auth import (
    auth_headers as auth_headers_impl,
    env_api_key as env_api_key_impl,
    env_user_token as env_user_token_impl,
    looks_like_api_key as looks_like_api_key_impl,
    looks_like_jwt as looks_like_jwt_impl,
    mask_api_key as mask_api_key_impl,
    mask_secret as mask_secret_impl,
    print_missing_developer_auth_help as print_missing_developer_auth_help_impl,
    print_missing_user_session_help as print_missing_user_session_help_impl,
    resolve_token as resolve_token_impl,
    resolve_user_session_token as resolve_user_session_token_impl,
)
from autotouch_cli.core.config import (
    DEFAULT_API_URL,
    api_url as api_url_impl,
    config_path as config_path_impl,
    load_config as load_config_impl,
    load_env_files as load_env_files_impl,
    package_version as package_version_impl,
    save_config as save_config_impl,
)
from autotouch_cli.core.http import (
    request_api as request_api_impl,
    request_multipart_api as request_multipart_api_impl,
)
from autotouch_cli.core.io import (
    chunk_list as chunk_list_impl,
    dedupe_keep_order as dedupe_keep_order_impl,
    load_emails_from_file as load_emails_from_file_impl,
    load_json_input as load_json_input_impl,
    load_required_object_payload as load_required_object_payload_impl,
    load_string_values_from_file as load_string_values_from_file_impl,
    normalize_email_value as normalize_email_value_impl,
    normalize_string_value as normalize_string_value_impl,
    parse_email_payload as parse_email_payload_impl,
    parse_json_string as parse_json_string_impl,
    parse_string_list_payload as parse_string_list_payload_impl,
    split_cli_email_values as split_cli_email_values_impl,
    split_cli_string_values as split_cli_string_values_impl,
)
from autotouch_cli.core.output import (
    OUTPUT_MODES as OUTPUT_MODES_IMPL,
    apply_output_projection as apply_output_projection_impl,
    as_display as as_display_impl,
    emit_text as emit_text_impl,
    normalize_output_mode as normalize_output_mode_impl,
    normalize_output_projection as normalize_output_projection_impl,
    print_human as print_human_impl,
    print_json as print_json_impl,
    resolve_json_pointer_value as resolve_json_pointer_value_impl,
    resolve_output_select_path as resolve_output_select_path_impl,
    supports_color as supports_color_impl,
)
from autotouch_cli.core.polling import (
    poll_import_until_terminal as poll_import_until_terminal_impl,
    poll_job_until_terminal as poll_job_until_terminal_impl,
)
from autotouch_cli.mongo_status import mongo_client as _mongo_client
from autotouch_cli.mongo_status import status_counts as _status_counts
from autotouch_cli.parser_groups import add_tasks_subcommands, add_webhooks_subcommands
from autotouch_cli.sequence_support import (
    SequenceCommandInputError,
    SequenceRuntime,
    build_sequence_enroll_payload as build_sequence_enroll_payload_impl,
    collect_sequence_lead_ids as collect_sequence_lead_ids_impl,
    sequence_mutation_params as sequence_mutation_params_impl,
)
from autotouch_cli.templates import (
    AUTH_SCHEMA_TYPES,
    CELL_SCHEMA_TYPES,
    COLUMN_CREATE_RECIPES,
    COLUMN_RECIPE_NOTES,
    COLUMN_RECIPE_TYPES,
    LEAD_RECIPE_TYPES,
    ONBOARDING_SCHEMA_TYPES,
    ORG_CONTEXT_SCHEMA_TYPES,
    PERSONAL_CONTEXT_SCHEMA_TYPES,
    PROMPT_TEMPLATE_SCHEMA_TYPES,
    WORKSPACE_SECRET_SCHEMA_TYPES,
    ROW_SCHEMA_TYPES,
    SEQUENCE_RECIPE_TYPES,
    SHARED_SCHEMA_TYPES,
    TABLE_SCHEMA_TYPES,
    TASK_RECIPE_TYPES,
    WEBHOOK_RECIPE_TYPES,
    WORKFLOW_BLUEPRINTS,
    WORKFLOW_BLUEPRINT_TYPES,
    TemplateRuntime,
    emit_auth_schema,
    emit_cells_schema,
    emit_columns_recipe,
    emit_leads_recipe,
    emit_onboarding_schema,
    emit_org_context_schema,
    emit_personal_context_schema,
    emit_prompt_templates_schema,
    emit_workspace_secrets_schema,
    emit_rows_schema,
    emit_schema,
    emit_sequences_recipe,
    emit_tables_schema,
    emit_tasks_recipe,
    emit_webhooks_recipe,
    emit_workflows_list,
    emit_workflows_recipe,
)
from autotouch_shared.linkedin_contract import (
    linkedin_recipe_entries,
    linkedin_recipe_types,
)
from autotouch_shared.search_contract import (
    search_recipe_entries,
    search_recipe_types,
)
from autotouch_shared.provider_registry import (
    ProviderContractValidationError,
    validate_column_provider_contract,
)

try:
    from dotenv import load_dotenv  # type: ignore
except Exception:  # pragma: no cover
    load_dotenv = None  # type: ignore

# Global CLI state and bundled contract data.
DEFAULT_TIMEOUT_SECONDS = 30
ASSERTION_FAILURE_EXIT_CODE = 3
TERMINAL_JOB_STATUSES = {
    "completed",
    "partial",
    "error",
    "timed_out",
    "cancelled",
    "failed",
    "completed_with_errors",
}
NON_TERMINAL_JOB_STATUSES = {
    "queued",
    "distributing",
    "processing",
    "running",
    "pending",
}
PROJECTION_READINESS_SAMPLE_SIZE = 50
OUTPUT_MODE = "json"
OUTPUT_MODES = OUTPUT_MODES_IMPL
OUTPUT_SELECT: Optional[str] = None
OUTPUT_JSON_POINTER: Optional[str] = None
ANSI_PURPLE = "\033[38;5;141m"
ANSI_RESET = "\033[0m"
SETUP_BANNER = r"""
 █████  ██    ██ ████████  ██████  ████████  ██████  ██    ██  ██████ ██   ██
██   ██ ██    ██    ██    ██    ██    ██    ██    ██ ██    ██ ██      ██   ██
███████ ██    ██    ██    ██    ██    ██    ██    ██ ██    ██ ██      ███████
██   ██ ██    ██    ██    ██    ██    ██    ██    ██ ██    ██ ██      ██   ██
██   ██  ██████     ██     ██████     ██     ██████   ██████   ██████ ██   ██

                         AI CLI SETUP
"""

SEARCH_RECIPE_TYPES = list(search_recipe_types())
SEARCH_RECIPES: Dict[str, Any] = search_recipe_entries()


def _package_version() -> str:
    return package_version_impl()


CLI_VERSION = _package_version()


RUN_SOP_GUIDE: Dict[str, Any] = {
    "title": "Credit-safe enrichment SOP",
    "rules": [
        "Use --output json for automation; avoid parsing human-format output.",
        "Filter first before running billable columns.",
        "Estimate first with the same payload you plan to run.",
        "Start with a small firstN pilot before scaling.",
        "For exact bounded batches, prefer run-next with a small count.",
        "For add_to_crm, generate payload from columns recipe before create/update.",
        "Keep unprocessedOnly enabled unless you intentionally reprocess rows.",
        "Treat bulk job state as source of truth: queued/distributing/processing are non-terminal; completed/partial/error/cancelled are terminal.",
        "For JSON enrichment columns, run with --wait and verify terminal status before creating projection splits.",
        "Always inspect raw outputs before summary counts; parse by column dataType (json vs scalar).",
        "When summarizing enrichment outputs, parse by key precedence (phone: mobile_number -> phone_numbers[0].number -> primary_phone; email: response -> email -> work_email).",
    ],
    "clarifications": [
        "Email/phone enrichment does not require add_to_crm.",
        "add_to_crm is an optional export action to Leads CRM (non-billable).",
        "Projection columns backfill existing rows automatically after creation; no separate projection run is required.",
        "For custom LLM schemas, use strict field-map shape (no root type/properties wrapper; arrays must use {type:\"array\",items:...}).",
        "Do not report not_found from a single missing key when fallback keys exist.",
    ],
    "default_run_payload": {
        "scope": "filtered",
        "filters": {
            "mode": "and",
            "filters": [
                {"columnKey": "company_domain", "operator": "isNotEmpty"},
                {"columnKey": "country", "operator": "equals", "value": "United States"},
            ],
        },
        "unprocessedOnly": True,
        "firstN": 25,
    },
}


def _extract_add_to_crm_field_mappings(payload: Any) -> Optional[Dict[str, Any]]:
    if not isinstance(payload, dict):
        return None
    config = payload.get("config")
    if not isinstance(config, dict):
        return None
    provider = str(config.get("provider") or "").strip().lower()
    if provider != "add_to_crm":
        return None
    field_mappings = config.get("fieldMappings")
    if isinstance(field_mappings, dict):
        return field_mappings
    return {}


def _inspect_add_to_crm_field_mappings(field_mappings: Dict[str, Any]) -> Dict[str, Any]:
    mode = "multi" if str(field_mappings.get("mode") or "").strip().lower() == "multi" else "single"
    required_missing: List[str] = []
    optional_missing: List[str] = []

    def _has_identity_mapping(lead_mapping: Dict[str, Any]) -> bool:
        if str(lead_mapping.get("linkedinUrl") or "").strip():
            return True
        if isinstance(lead_mapping.get("emailAddresses"), list) and any(
            isinstance(item, dict) and str(item.get("column") or "").strip()
            for item in (lead_mapping.get("emailAddresses") or [])
        ):
            return True
        if isinstance(lead_mapping.get("phoneNumbers"), list) and any(
            isinstance(item, dict) and str(item.get("column") or "").strip()
            for item in (lead_mapping.get("phoneNumbers") or [])
        ):
            return True
        return False

    if mode == "multi":
        common = field_mappings.get("common") if isinstance(field_mappings.get("common"), dict) else {}
        leads = field_mappings.get("leads") if isinstance(field_mappings.get("leads"), list) else []

        common_domain = str((common or {}).get("companyDomain") or field_mappings.get("companyDomain") or "").strip()
        if not common_domain:
            required_missing.append("common.companyDomain")

        has_lead_identity = False
        optional_lead_slots = ["firstName", "lastName", "title", "companyName"]
        for idx, lead in enumerate(leads):
            if not isinstance(lead, dict):
                continue
            if _has_identity_mapping(lead):
                has_lead_identity = True
            for slot in optional_lead_slots:
                if not str(lead.get(slot) or "").strip():
                    optional_missing.append(f"leads[{idx}].{slot}")
        if not has_lead_identity:
            required_missing.append("leads[].identityFields")
    else:
        company_domain_key = str(field_mappings.get("companyDomain") or "").strip()
        if not company_domain_key:
            required_missing.append("companyDomain")
        if not _has_identity_mapping(field_mappings):
            required_missing.append("identityFields")
        for slot in ["firstName", "lastName", "title", "companyName"]:
            if not str(field_mappings.get(slot) or "").strip():
                optional_missing.append(slot)

    return {
        "mode": mode,
        "required_missing": required_missing,
        "optional_missing": optional_missing,
    }


def _validate_add_to_crm_create_payload(payload: Dict[str, Any]) -> None:
    field_mappings = _extract_add_to_crm_field_mappings(payload)
    if field_mappings is None:
        return

    kind_value = str(payload.get("kind") or "").strip().lower()
    if kind_value != "enrichment":
        print(
            "ERROR: add_to_crm column payload must use kind='enrichment'. "
            "Tip: run `autotouch columns recipe --type add_to_crm`.",
            file=sys.stderr,
        )
        sys.exit(2)

    if not field_mappings:
        print(
            "ERROR: add_to_crm requires config.fieldMappings. "
            "Tip: run `autotouch columns recipe --type add_to_crm`.",
            file=sys.stderr,
        )
        sys.exit(2)

    issues = _inspect_add_to_crm_field_mappings(field_mappings)
    required_missing = issues.get("required_missing") or []
    optional_missing = issues.get("optional_missing") or []
    if required_missing:
        missing = ", ".join(str(v) for v in required_missing)
        print(
            f"ERROR: add_to_crm fieldMappings missing required keys: {missing}. "
            "Tip: run `autotouch columns recipe --type add_to_crm`.",
            file=sys.stderr,
        )
        sys.exit(2)
    if optional_missing:
        missing = ", ".join(str(v) for v in optional_missing)
        print(
            f"WARN: add_to_crm optional mappings missing: {missing}. "
            "Leads can still be created but profile fields may be sparse.",
            file=sys.stderr,
        )


def _validate_column_contract_payload_or_exit(payload: Dict[str, Any]) -> None:
    config = payload.get("config") if isinstance(payload.get("config"), dict) else {}
    try:
        validate_column_provider_contract(payload, config)
    except ProviderContractValidationError as exc:
        print(f"ERROR: {exc.message}", file=sys.stderr)
        if exc.hint:
            print(f"TIP: {exc.hint}", file=sys.stderr)
        sys.exit(2)


def _load_column_for_run_precheck(
    *,
    table_id: str,
    column_id: str,
    base_url: Optional[str],
    token: str,
    use_x_api_key: bool,
    timeout: int,
    verbose: bool,
) -> Optional[Dict[str, Any]]:
    columns = _load_columns_for_table_precheck(
        table_id=table_id,
        base_url=base_url,
        token=token,
        use_x_api_key=use_x_api_key,
        timeout=timeout,
        verbose=verbose,
    )
    if not isinstance(columns, list):
        return None
    for column in columns:
        if not isinstance(column, dict):
            continue
        if str(column.get("id") or "") == str(column_id):
            return column
    return None


def _load_columns_for_table_precheck(
    *,
    table_id: str,
    base_url: Optional[str],
    token: str,
    use_x_api_key: bool,
    timeout: int,
    verbose: bool,
) -> Optional[List[Dict[str, Any]]]:
    columns = _request_api(
        "GET",
        f"/api/tables/{table_id}/columns",
        base_url=base_url,
        token=token,
        use_x_api_key=use_x_api_key,
        timeout=timeout,
        verbose=verbose,
    )
    return columns if isinstance(columns, list) else None


def _find_add_to_crm_structured_mapping_issues(
    field_mappings: Dict[str, Any],
    columns: List[Dict[str, Any]],
) -> List[str]:
    columns_by_key = {
        str(column.get("key") or "").strip(): column
        for column in columns
        if isinstance(column, dict)
    }
    issues: List[str] = []

    def inspect_contact_array(label: str, values: Any) -> None:
        if not isinstance(values, list):
            return
        for idx, item in enumerate(values):
            if not isinstance(item, dict):
                continue
            column_key = str(item.get("column") or "").strip()
            if not column_key:
                continue
            source_column = columns_by_key.get(column_key)
            source_type = str((source_column or {}).get("dataType") or "").strip().lower()
            path = str(item.get("path") or "").strip()
            if source_type == "json" and not path:
                issues.append(f"{label}[{idx}] -> {column_key}")

    mode = "multi" if str(field_mappings.get("mode") or "").strip().lower() == "multi" else "single"
    if mode == "multi":
        leads = field_mappings.get("leads")
        if isinstance(leads, list):
            for idx, lead in enumerate(leads):
                if not isinstance(lead, dict):
                    continue
                inspect_contact_array(f"leads[{idx}].emailAddresses", lead.get("emailAddresses"))
                inspect_contact_array(f"leads[{idx}].phoneNumbers", lead.get("phoneNumbers"))
    else:
        inspect_contact_array("emailAddresses", field_mappings.get("emailAddresses"))
        inspect_contact_array("phoneNumbers", field_mappings.get("phoneNumbers"))

    return issues


def _run_precheck_for_add_to_crm(
    *,
    args: argparse.Namespace,
    token: str,
    payload: Dict[str, Any],
) -> None:
    try:
        column = _load_column_for_run_precheck(
            table_id=args.table_id,
            column_id=args.column_id,
            base_url=args.base_url,
            token=token,
            use_x_api_key=bool(args.use_x_api_key),
            timeout=int(args.timeout or DEFAULT_TIMEOUT_SECONDS),
            verbose=bool(args.verbose),
        )
    except Exception as exc:
        print(f"WARN: add_to_crm precheck skipped (failed to load column): {exc}", file=sys.stderr)
        return

    if not isinstance(column, dict):
        return

    try:
        table_columns = _load_columns_for_table_precheck(
            table_id=args.table_id,
            base_url=args.base_url,
            token=token,
            use_x_api_key=bool(args.use_x_api_key),
            timeout=int(args.timeout or DEFAULT_TIMEOUT_SECONDS),
            verbose=bool(args.verbose),
        )
    except Exception:
        table_columns = None

    field_mappings = _extract_add_to_crm_field_mappings(column)
    if field_mappings is None:
        return

    issues = _inspect_add_to_crm_field_mappings(field_mappings)
    required_missing = issues.get("required_missing") or []
    optional_missing = issues.get("optional_missing") or []

    if required_missing:
        missing = ", ".join(str(v) for v in required_missing)
        print(
            f"ERROR: add_to_crm column is misconfigured (missing required mappings: {missing}). "
            "Recreate/update from `autotouch columns recipe --type add_to_crm` before running.",
            file=sys.stderr,
        )
        sys.exit(2)

    if optional_missing:
        missing = ", ".join(str(v) for v in optional_missing)
        print(
            f"WARN: add_to_crm optional mappings missing: {missing}. "
            "Run will work, but created Leads records may miss profile fields.",
            file=sys.stderr,
        )

    if isinstance(table_columns, list):
        structured_mapping_issues = _find_add_to_crm_structured_mapping_issues(field_mappings, table_columns)
        if structured_mapping_issues:
            missing = ", ".join(structured_mapping_issues)
            print(
                f"ERROR: add_to_crm structured source mappings require explicit path values: {missing}. "
                "Example: work_email.response or mobile_phone.mobile_number.",
                file=sys.stderr,
            )
            sys.exit(2)

    scope = str(payload.get("scope") or "").strip()
    has_filters = isinstance(payload.get("filters"), dict)
    if scope in {"all", "firstN"} and not has_filters:
        print(
            "WARN: add_to_crm run is broad (scope without filters). "
            "Prefer `run-next --count N` or `scope=filtered` to avoid unintended large exports.",
            file=sys.stderr,
        )

# Compatibility shims over extracted `core/*` helpers.
def _load_env_files() -> None:
    load_env_files_impl(load_dotenv)


_load_env_files()


def _config_path() -> Path:
    return config_path_impl()


def _load_config() -> Dict[str, Any]:
    return load_config_impl()


def _save_config(data: Dict[str, Any]) -> Path:
    return save_config_impl(data)


def _mask_api_key(value: Optional[str]) -> str:
    return mask_api_key_impl(value)


def _mask_secret(value: Optional[str]) -> str:
    return mask_secret_impl(value)


def _api_url(value: Optional[str] = None) -> str:
    return api_url_impl(value, load_config_fn=_load_config, default_api_url=DEFAULT_API_URL)


def _looks_like_api_key(value: Optional[str]) -> bool:
    return looks_like_api_key_impl(value)


def _looks_like_jwt(value: Optional[str]) -> bool:
    return looks_like_jwt_impl(value)


def _env_user_token() -> Optional[str]:
    return env_user_token_impl()


def _env_api_key() -> Optional[str]:
    return env_api_key_impl()


def _print_missing_developer_auth_help() -> None:
    print_missing_developer_auth_help_impl()


def _print_missing_user_session_help() -> None:
    print_missing_user_session_help_impl()


def _resolve_token(explicit_token: Optional[str], required: bool = True) -> Optional[str]:
    return resolve_token_impl(
        explicit_token,
        required=required,
        load_config_fn=_load_config,
        env_user_token_fn=_env_user_token,
        env_api_key_fn=_env_api_key,
        print_missing_help_fn=_print_missing_developer_auth_help,
    )


def _resolve_user_session_token(explicit_token: Optional[str], required: bool = True) -> Optional[str]:
    return resolve_user_session_token_impl(
        explicit_token,
        required=required,
        load_config_fn=_load_config,
        looks_like_api_key_fn=_looks_like_api_key,
        env_user_token_fn=_env_user_token,
        print_missing_help_fn=_print_missing_user_session_help,
    )


def _auth_headers(token: Optional[str], use_x_api_key: bool = False) -> Dict[str, str]:
    return auth_headers_impl(token, use_x_api_key=use_x_api_key)


def _set_output_mode(mode: Optional[str]) -> None:
    global OUTPUT_MODE
    OUTPUT_MODE = normalize_output_mode_impl(mode, default="json")


def _set_output_projection(select_expr: Optional[str], json_pointer: Optional[str]) -> None:
    global OUTPUT_SELECT, OUTPUT_JSON_POINTER
    OUTPUT_SELECT, OUTPUT_JSON_POINTER = normalize_output_projection_impl(select_expr, json_pointer)


def _supports_color() -> bool:
    return supports_color_impl(isatty=bool(sys.stdout.isatty()), environ=os.environ)


def _as_display(value: Any) -> str:
    return as_display_impl(value)


def _resolve_output_select_path(value: Any, select_expr: str) -> Any:
    return resolve_output_select_path_impl(value, select_expr)


def _resolve_json_pointer_value(value: Any, pointer: str) -> Any:
    return resolve_json_pointer_value_impl(value, pointer)


def _apply_output_projection(data: Any) -> Any:
    return apply_output_projection_impl(
        data,
        output_select=OUTPUT_SELECT,
        output_json_pointer=OUTPUT_JSON_POINTER,
    )


def _emit_text(text: str = "", *, file: Any = None) -> None:
    emit_text_impl(text, file=file)


def _print_human(data: Any, *, file: Any = None) -> None:
    print_human_impl(data, file=file)


def _print_json(data: Any, compact: bool = False, *, file: Any = None, apply_projection: bool = True) -> None:
    print_json_impl(
        data,
        compact=compact,
        file=file,
        apply_projection=apply_projection,
        output_mode=OUTPUT_MODE,
        output_select=OUTPUT_SELECT,
        output_json_pointer=OUTPUT_JSON_POINTER,
    )


def _emit_progress_event(data: Any, *, compact: bool = False) -> None:
    if OUTPUT_MODE == "json":
        return
    _print_json(data, compact=compact, apply_projection=False)


def _parse_json_string(raw: str, context: str) -> Any:
    return parse_json_string_impl(raw, context)


def _load_json_input(
    *,
    inline_json: Optional[str],
    file_path: Optional[str],
    context: str,
    default: Any = None,
) -> Any:
    return load_json_input_impl(
        inline_json=inline_json,
        file_path=file_path,
        context=context,
        default=default,
    )


def _load_required_object_payload(args: argparse.Namespace, *, noun: str) -> Dict[str, Any]:
    return load_required_object_payload_impl(args, noun=noun)


def _normalize_email_value(value: Any) -> Optional[str]:
    return normalize_email_value_impl(value)


def _split_cli_email_values(raw_values: Optional[List[str]]) -> List[str]:
    return split_cli_email_values_impl(raw_values)


def _parse_email_payload(payload: Any, *, context: str) -> List[str]:
    return parse_email_payload_impl(payload, context=context)


def _load_emails_from_file(file_path: str, *, csv_column: Optional[str]) -> List[str]:
    return load_emails_from_file_impl(file_path, csv_column=csv_column)


def _dedupe_keep_order(values: List[str]) -> List[str]:
    return dedupe_keep_order_impl(values)


def _collect_blacklist_emails(args: argparse.Namespace) -> List[str]:
    emails: List[str] = []
    emails.extend(_split_cli_email_values(getattr(args, "email", None)))

    raw_emails_json = getattr(args, "emails_json", None)
    if raw_emails_json:
        payload = _parse_json_string(str(raw_emails_json), "emails")
        emails.extend(_parse_email_payload(payload, context="--emails-json"))

    emails_file = getattr(args, "emails_file", None)
    if emails_file:
        emails.extend(
            _load_emails_from_file(
                str(emails_file),
                csv_column=getattr(args, "emails_column", None),
            )
        )

    deduped = _dedupe_keep_order([email for email in emails if email])
    if not deduped:
        print(
            "ERROR: provide emails via --email, --emails-json, or --emails-file",
            file=sys.stderr,
        )
        sys.exit(2)
    return deduped


def _chunk_list(values: List[str], size: int) -> List[List[str]]:
    return chunk_list_impl(values, size)


def _request_api(
    method: str,
    path: str,
    *,
    base_url: str,
    token: Optional[str],
    use_x_api_key: bool = False,
    params: Optional[Dict[str, Any]] = None,
    payload: Optional[Any] = None,
    form_payload: Optional[Dict[str, Any]] = None,
    files: Optional[Any] = None,
    extra_headers: Optional[Dict[str, str]] = None,
    timeout: int = DEFAULT_TIMEOUT_SECONDS,
    verbose: bool = False,
) -> Any:
    return request_api_impl(
        method,
        path,
        base_url=base_url,
        token=token,
        api_url_fn=_api_url,
        auth_headers_fn=_auth_headers,
        requests_module=requests,
        use_x_api_key=use_x_api_key,
        params=params,
        payload=payload,
        form_payload=form_payload,
        files=files,
        extra_headers=extra_headers,
        timeout=timeout,
        default_timeout_seconds=DEFAULT_TIMEOUT_SECONDS,
        verbose=verbose,
        error_body_writer=lambda body: _print_json(
            body,
            compact=False,
            file=sys.stderr,
            apply_projection=False,
        ),
    )


def _normalize_string_value(value: Any) -> Optional[str]:
    return normalize_string_value_impl(value)


def _split_cli_string_values(raw_values: Optional[List[str]]) -> List[str]:
    return split_cli_string_values_impl(raw_values)


def _parse_string_list_payload(
    payload: Any,
    *,
    context: str,
    array_key: Optional[str] = None,
    key: Optional[str] = None,
) -> List[str]:
    return parse_string_list_payload_impl(
        payload,
        context=context,
        array_key=array_key,
        key=key,
    )


def _load_string_values_from_file(
    file_path: str,
    *,
    context: str,
    array_key: str,
    csv_column: Optional[str] = None,
) -> List[str]:
    return load_string_values_from_file_impl(
        file_path,
        context=context,
        array_key=array_key,
        csv_column=csv_column,
    )


def _request_multipart_api(
    method: str,
    path: str,
    *,
    base_url: str,
    token: Optional[str],
    file_path: str,
    file_field: str = "file",
    form_fields: Optional[Dict[str, Any]] = None,
    params: Optional[Dict[str, Any]] = None,
    use_x_api_key: bool = False,
    timeout: int = DEFAULT_TIMEOUT_SECONDS,
    verbose: bool = False,
) -> Any:
    return request_multipart_api_impl(
        method,
        path,
        base_url=base_url,
        token=token,
        file_path=file_path,
        api_url_fn=_api_url,
        auth_headers_fn=_auth_headers,
        requests_module=requests,
        file_field=file_field,
        form_fields=form_fields,
        params=params,
        use_x_api_key=use_x_api_key,
        timeout=timeout,
        default_timeout_seconds=DEFAULT_TIMEOUT_SECONDS,
        verbose=verbose,
        error_body_writer=lambda body: _print_json(
            body,
            compact=False,
            file=sys.stderr,
            apply_projection=False,
        ),
    )


def _normalize_run_payload(args: argparse.Namespace) -> Dict[str, Any]:
    # If an explicit payload was provided, use it verbatim.
    explicit_payload = _load_json_input(
        inline_json=getattr(args, "data_json", None),
        file_path=getattr(args, "data_file", None),
        context="data",
        default=None,
    )
    if explicit_payload is not None:
        if not isinstance(explicit_payload, dict):
            print("ERROR: run payload must be a JSON object", file=sys.stderr)
            sys.exit(2)
        return explicit_payload

    scope = str(getattr(args, "scope", "all") or "all")
    payload: Dict[str, Any] = {"scope": scope}
    row_ids = [r.strip() for r in (getattr(args, "row_ids", None) or []) if r and str(r).strip()]

    if scope == "row":
        if getattr(args, "row_id", None):
            payload["rowIds"] = [str(args.row_id)]
        elif row_ids:
            payload["rowIds"] = [str(row_ids[0])]
        else:
            print("ERROR: --row-id or --row-ids is required for scope=row", file=sys.stderr)
            sys.exit(2)

    if scope == "subset":
        if not row_ids:
            print("ERROR: --row-ids required for scope=subset", file=sys.stderr)
            sys.exit(2)
        payload["rowIds"] = row_ids

    if scope == "firstN":
        first_n = getattr(args, "first_n", None)
        if not first_n or int(first_n) <= 0:
            print("ERROR: --first-n must be > 0 for scope=firstN", file=sys.stderr)
            sys.exit(2)
        payload["firstN"] = int(first_n)

    filters = _load_json_input(
        inline_json=getattr(args, "filters_json", None),
        file_path=getattr(args, "filters_file", None),
        context="filters",
        default=None,
    )
    if filters is not None:
        payload["filters"] = filters

    payload["unprocessedOnly"] = bool(getattr(args, "unprocessed_only", True))

    return payload


def _resolve_column_key(
    *,
    table_id: str,
    column_id: str,
    base_url: str,
    token: str,
    use_x_api_key: bool,
    timeout: int,
    verbose: bool,
) -> str:
    columns_raw = _request_api(
        "GET",
        f"/api/tables/{table_id}/columns",
        base_url=base_url,
        token=token,
        use_x_api_key=use_x_api_key,
        timeout=timeout,
        verbose=verbose,
    )
    if isinstance(columns_raw, list):
        columns = columns_raw
    elif isinstance(columns_raw, dict):
        columns = columns_raw.get("columns") or columns_raw.get("items") or columns_raw.get("data") or []
    else:
        columns = []

    target = str(column_id)
    for col in columns:
        if not isinstance(col, dict):
            continue
        cid = str(col.get("id") or col.get("_id") or "")
        if cid != target:
            continue
        key = str(col.get("key") or "").strip()
        if key:
            return key
        break

    print(f"ERROR: failed to resolve column key for column_id={column_id}", file=sys.stderr)
    sys.exit(1)


def _extract_columns_list(columns_raw: Any) -> List[Dict[str, Any]]:
    if isinstance(columns_raw, list):
        return [col for col in columns_raw if isinstance(col, dict)]
    if isinstance(columns_raw, dict):
        candidates = columns_raw.get("columns") or columns_raw.get("items") or columns_raw.get("data") or []
        if isinstance(candidates, list):
            return [col for col in candidates if isinstance(col, dict)]
    return []


def _extract_jobs_list(jobs_raw: Any) -> List[Dict[str, Any]]:
    if isinstance(jobs_raw, list):
        return [job for job in jobs_raw if isinstance(job, dict)]
    if isinstance(jobs_raw, dict):
        candidates = jobs_raw.get("jobs") or jobs_raw.get("items") or jobs_raw.get("data") or []
        if isinstance(candidates, list):
            return [job for job in candidates if isinstance(job, dict)]
    return []


def _is_json_enrichment_column(column: Dict[str, Any]) -> bool:
    kind = str(column.get("kind") or "").strip().lower()
    data_type = str(column.get("dataType") or column.get("data_type") or "").strip().lower()
    return kind == "enrichment" and data_type == "json"


def _projection_recommended_run_command(table_id: str, column_id: str) -> str:
    return (
        f"autotouch columns run --table-id {table_id} --column-id {column_id} "
        "--scope all --show-estimate --wait --output json"
    )


def _projection_preflight_warn(
    *,
    code: str,
    column: Dict[str, Any],
    reason: str,
    recommended_next_command: str,
    latest_job_status: Optional[str] = None,
    column_status: Optional[str] = None,
    sample_rows_scanned: Optional[int] = None,
    sample_non_empty_values: Optional[int] = None,
) -> Dict[str, Any]:
    warning: Dict[str, Any] = {
        "code": code,
        "severity": "warning",
        "source_column_id": str(column.get("id") or column.get("_id") or ""),
        "source_column_key": str(column.get("key") or ""),
        "source_column_label": str(column.get("label") or column.get("key") or ""),
        "reason": reason,
        "recommended_next_command": recommended_next_command,
    }
    if latest_job_status:
        warning["latest_job_status"] = latest_job_status
    if column_status:
        warning["column_status"] = column_status
    if sample_rows_scanned is not None:
        warning["sample_rows_scanned"] = int(sample_rows_scanned)
    if sample_non_empty_values is not None:
        warning["sample_non_empty_values"] = int(sample_non_empty_values)
    return warning


def _print_projection_preflight_warnings(warnings: List[Dict[str, Any]]) -> None:
    if not warnings:
        return
    print(
        f"WARNING: projection preflight found {len(warnings)} source column(s) that may not be ready yet.",
        file=sys.stderr,
    )
    for warning in warnings:
        col_label = warning.get("source_column_label") or warning.get("source_column_key") or warning.get("source_column_id")
        col_id = warning.get("source_column_id") or "unknown"
        reason = warning.get("reason") or "source may be unprocessed"
        print(f"WARNING: [{warning.get('code')}] {col_label} ({col_id}): {reason}", file=sys.stderr)
        cmd = warning.get("recommended_next_command")
        if cmd:
            print(f"         Recommended: {cmd}", file=sys.stderr)


def _build_projection_preflight_warnings(
    *,
    table_id: str,
    payload: Dict[str, Any],
    base_url: str,
    token: str,
    use_x_api_key: bool,
    timeout: int,
    verbose: bool,
) -> List[Dict[str, Any]]:
    items = payload.get("items")
    if not isinstance(items, list) or not items:
        return []

    source_ids: List[str] = []
    seen: set[str] = set()
    for item in items:
        if not isinstance(item, dict):
            continue
        raw_source = item.get("sourceColumnId") or item.get("source_column_id")
        source_id = str(raw_source or "").strip()
        if not source_id or source_id in seen:
            continue
        seen.add(source_id)
        source_ids.append(source_id)
    if not source_ids:
        return []

    columns_raw = _request_api(
        "GET",
        f"/api/tables/{table_id}/columns",
        base_url=base_url,
        token=token,
        use_x_api_key=use_x_api_key,
        timeout=timeout,
        verbose=verbose,
    )
    columns = _extract_columns_list(columns_raw)
    by_id: Dict[str, Dict[str, Any]] = {}
    for col in columns:
        cid = str(col.get("id") or col.get("_id") or "").strip()
        if cid:
            by_id[cid] = col

    warnings: List[Dict[str, Any]] = []
    rows_sample: Optional[List[Dict[str, Any]]] = None
    jobs_cache: Dict[str, Optional[Dict[str, Any]]] = {}

    for source_id in source_ids:
        source_col = by_id.get(source_id)
        if not source_col or not _is_json_enrichment_column(source_col):
            continue

        source_col_id = str(source_col.get("id") or source_col.get("_id") or source_id)
        source_key = str(source_col.get("key") or "").strip()
        recommended_next = _projection_recommended_run_command(table_id, source_col_id)

        latest_job = jobs_cache.get(source_col_id)
        if source_col_id not in jobs_cache:
            jobs_raw = _request_api(
                "GET",
                "/api/bulk-jobs",
                base_url=base_url,
                token=token,
                use_x_api_key=use_x_api_key,
                params={"table_id": table_id, "column_id": source_col_id, "limit": 1},
                timeout=timeout,
                verbose=verbose,
            )
            jobs = _extract_jobs_list(jobs_raw)
            latest_job = jobs[0] if jobs else None
            jobs_cache[source_col_id] = latest_job

        latest_job_status = str((latest_job or {}).get("status") or "").strip().lower()
        if latest_job_status in NON_TERMINAL_JOB_STATUSES:
            warnings.append(
                _projection_preflight_warn(
                    code="source_job_not_terminal",
                    column=source_col,
                    reason=f"latest run status is '{latest_job_status}' (not terminal)",
                    recommended_next_command=recommended_next,
                    latest_job_status=latest_job_status,
                    column_status=str(source_col.get("status") or "").strip().lower() or None,
                )
            )
            continue
        if latest_job_status in TERMINAL_JOB_STATUSES:
            continue

        has_run_metadata = bool(
            source_col.get("lastRunAt")
            or source_col.get("last_run_at")
            or source_col.get("lastJobId")
            or source_col.get("last_job_id")
        )
        if has_run_metadata:
            continue

        if rows_sample is None:
            rows_page_raw = _request_api(
                "GET",
                f"/api/tables/{table_id}/rows",
                base_url=base_url,
                token=token,
                use_x_api_key=use_x_api_key,
                params={"page_size": PROJECTION_READINESS_SAMPLE_SIZE},
                timeout=timeout,
                verbose=verbose,
            )
            if not isinstance(rows_page_raw, dict):
                rows_sample = []
            else:
                candidate_rows = rows_page_raw.get("rows") or []
                rows_sample = [row for row in candidate_rows if isinstance(row, dict)] if isinstance(candidate_rows, list) else []

        sample_count = 0
        if source_key:
            sample_count = sum(1 for row in (rows_sample or []) if _is_processed_cell_value(row.get(source_key)))
        if sample_count > 0:
            continue

        warnings.append(
            _projection_preflight_warn(
                code="source_unrun_or_empty",
                column=source_col,
                reason="source JSON enrichment has no terminal run evidence and sampled values are empty",
                recommended_next_command=recommended_next,
                latest_job_status=latest_job_status or None,
                column_status=str(source_col.get("status") or "").strip().lower() or None,
                sample_rows_scanned=len(rows_sample or []),
                sample_non_empty_values=sample_count,
            )
        )

    return warnings


def _is_processed_cell_value(value: Any) -> bool:
    if value is None:
        return False
    if isinstance(value, str):
        return value.strip() != ""
    if isinstance(value, (list, tuple, set, dict)):
        return len(value) > 0
    return True


def _select_next_row_ids(
    *,
    table_id: str,
    column_id: str,
    count: int,
    filters: Optional[Dict[str, Any]],
    unprocessed_only: bool,
    page_size: int,
    base_url: str,
    token: str,
    use_x_api_key: bool,
    timeout: int,
    verbose: bool,
) -> Dict[str, Any]:
    if count <= 0:
        return {"row_ids": [], "requested": 0, "selected": 0, "scanned_rows": 0}

    column_key = _resolve_column_key(
        table_id=table_id,
        column_id=column_id,
        base_url=base_url,
        token=token,
        use_x_api_key=use_x_api_key,
        timeout=timeout,
        verbose=verbose,
    )

    selected: List[str] = []
    seen: set[str] = set()
    scanned_rows = 0
    page_count = 0
    cursor: Optional[str] = None

    effective_page_size = max(1, min(int(page_size or 200), 1000))
    filters_payload = filters if isinstance(filters, dict) else None

    while len(selected) < count:
        page_count += 1
        params: Dict[str, Any] = {"page_size": effective_page_size}
        if cursor:
            params["cursor"] = cursor
        if filters_payload:
            params["filters"] = json.dumps(filters_payload, separators=(",", ":"))

        page = _request_api(
            "GET",
            f"/api/tables/{table_id}/rows",
            base_url=base_url,
            token=token,
            use_x_api_key=use_x_api_key,
            params=params,
            timeout=timeout,
            verbose=verbose,
        )
        if not isinstance(page, dict):
            print(f"ERROR: unexpected rows response: {page}", file=sys.stderr)
            sys.exit(1)

        rows = page.get("rows") or []
        if not isinstance(rows, list):
            print(f"ERROR: rows payload is not a list: {type(rows).__name__}", file=sys.stderr)
            sys.exit(1)

        for row in rows:
            if not isinstance(row, dict):
                continue
            scanned_rows += 1
            row_id = str(row.get("_id") or row.get("id") or row.get("rowId") or "").strip()
            if not row_id or row_id in seen:
                continue
            seen.add(row_id)

            if unprocessed_only and _is_processed_cell_value(row.get(column_key)):
                continue

            selected.append(row_id)
            if len(selected) >= count:
                break

        has_more = bool(page.get("hasMore") if "hasMore" in page else page.get("has_more"))
        next_cursor = page.get("nextCursor") if page.get("nextCursor") is not None else page.get("next_cursor")
        if len(selected) >= count:
            break
        if not has_more or not next_cursor:
            break
        cursor = str(next_cursor)

    return {
        "row_ids": selected,
        "requested": int(count),
        "selected": len(selected),
        "scanned_rows": scanned_rows,
        "pages_scanned": page_count,
        "column_key": column_key,
        "used_filters": bool(filters_payload),
        "unprocessed_only": bool(unprocessed_only),
    }


def _execute_run_flow(
    *,
    args: argparse.Namespace,
    token: str,
    payload: Dict[str, Any],
    context: Optional[Dict[str, Any]] = None,
) -> None:
    estimate_data: Optional[Dict[str, Any]] = None
    should_estimate = bool(args.show_estimate or args.max_credits is not None or args.dry_run)
    if should_estimate:
        estimate_raw = _request_api(
            "POST",
            f"/api/tables/{args.table_id}/columns/{args.column_id}/estimate",
            base_url=args.base_url,
            token=token,
            use_x_api_key=args.use_x_api_key,
            payload=payload,
            timeout=args.timeout,
            verbose=args.verbose,
        )
        if not isinstance(estimate_raw, dict):
            print(f"ERROR: unexpected estimate response: {estimate_raw}", file=sys.stderr)
            sys.exit(1)
        estimate_data = estimate_raw

    if args.max_credits is not None:
        if estimate_data is None:
            print("ERROR: failed to compute estimate for --max-credits guard", file=sys.stderr)
            sys.exit(1)
        limit = float(args.max_credits)
        estimated_max = estimate_data.get("estimated_credits_max")
        estimated_min = float(estimate_data.get("estimated_credits_min") or 0.0)

        if estimated_max is None and not bool(args.allow_unknown_max):
            output = {
                "blocked": True,
                "reason": "estimated_credits_max is unknown; pass --allow-unknown-max to proceed",
                "max_credits_limit": limit,
                "estimate": estimate_data,
            }
            if context is not None:
                output["context"] = context
            _print_json(output, compact=args.compact)
            sys.exit(3)

        compare_value = float(estimated_max if estimated_max is not None else estimated_min)
        if compare_value > limit:
            output = {
                "blocked": True,
                "reason": "estimated credits exceed max-credits limit",
                "max_credits_limit": limit,
                "estimate_compare_value": compare_value,
                "estimate": estimate_data,
            }
            if context is not None:
                output["context"] = context
            _print_json(output, compact=args.compact)
            sys.exit(3)

    if args.dry_run:
        output = {
            "dry_run": True,
            "run_payload": payload,
            "estimate": estimate_data,
        }
        if context is not None:
            output["context"] = context
        _print_json(output, compact=args.compact)
        return

    run_data = _request_api(
        "POST",
        f"/api/tables/{args.table_id}/columns/{args.column_id}/run",
        base_url=args.base_url,
        token=token,
        use_x_api_key=args.use_x_api_key,
        payload=payload,
        timeout=args.timeout,
        verbose=args.verbose,
    )
    if not isinstance(run_data, dict):
        output_non_dict: Any = run_data
        if context is not None:
            output_non_dict = {"context": context, "run": run_data}
        _print_json(output_non_dict, compact=args.compact)
        return

    if args.wait:
        job_id = run_data.get("job_id") or run_data.get("jobId")
        if not job_id:
            print("ERROR: run response missing job_id; cannot wait", file=sys.stderr)
            output = run_data if context is None else {"context": context, "run": run_data}
            _print_json(output, compact=args.compact)
            sys.exit(1)
        job_id = str(job_id)
        status_url = f"{_api_url(args.base_url)}/api/bulk-jobs/{job_id}"
        watch_command = f"autotouch jobs watch --job-id {job_id}"
        if not args.quiet_wait:
            _emit_progress_event(
                {
                    "event": "run.wait_started",
                    "job_id": job_id,
                    "status": "polling_started",
                    "status_url": status_url,
                    "watch_command": watch_command,
                    "hint": "polling /api/bulk-jobs/{job_id}",
                },
                compact=args.compact,
            )

        poll_result = _poll_job(
            job_id=job_id,
            base_url=args.base_url,
            token=token,
            use_x_api_key=args.use_x_api_key,
            interval_seconds=int(args.poll_interval or 2),
            wait_timeout_seconds=int(args.wait_timeout or 0),
            request_timeout_seconds=int(args.timeout or DEFAULT_TIMEOUT_SECONDS),
            verbose=args.verbose,
            compact=args.compact,
            once=False,
            print_updates=not args.quiet_wait,
        )
        final_job = poll_result.get("job") or {}
        timed_out = bool(poll_result.get("timed_out"))
        final_status = str((final_job or {}).get("status") or "").lower()
        output = {
            "event": "run.timed_out" if timed_out else "run.completed",
            "run": run_data,
            "estimate": estimate_data if args.show_estimate or args.max_credits is not None else None,
            "job": final_job,
            "final_job": final_job,
            "job_id": job_id,
            "job_status_url": status_url,
            "watch_command": watch_command,
            "status": final_status,
            "timed_out": timed_out,
            "polls": int(poll_result.get("polls") or 0),
        }
        if context is not None:
            output["context"] = context
        _print_json(output, compact=args.compact)

        if timed_out:
            sys.exit(4)
        if final_status in {"not_found", "unknown_not_found"}:
            print(
                f"ERROR: job {job_id} disappeared before terminal status; verify row state and rerun if needed",
                file=sys.stderr,
            )
            sys.exit(1)
        if args.fail_on_error and final_status in {"error", "cancelled"}:
            sys.exit(1)
        if args.fail_on_partial and final_status == "partial":
            sys.exit(1)
        return

    job_id = run_data.get("job_id") or run_data.get("jobId")
    status_url = None
    watch_command = None
    if job_id:
        status_url = f"{_api_url(args.base_url)}/api/bulk-jobs/{job_id}"
        watch_command = f"autotouch jobs watch --job-id {job_id}"

    output_any: Any = run_data
    if estimate_data is not None and args.show_estimate:
        output_any = {"estimate": estimate_data, "run": run_data}
    if context is not None:
        output_any = {"context": context, "result": output_any}
    if isinstance(output_any, dict):
        output_any = dict(output_any)
        output_any.setdefault("event", "run.queued")
        if job_id:
            output_any.setdefault("job_id", str(job_id))
            output_any["job_status_url"] = status_url
            output_any["watch_command"] = watch_command
    elif job_id:
        output_any = {
            "event": "run.queued",
            "job_id": str(job_id),
            "job_status_url": status_url,
            "watch_command": watch_command,
            "result": output_any,
        }
    _print_json(output_any, compact=args.compact)


def _create_rows_and_patch_records(
    *,
    table_id: str,
    records: Optional[List[Dict[str, Any]]],
    blank_count: int,
    base_url: str,
    token: str,
    use_x_api_key: bool,
    timeout: int,
    verbose: bool,
    detect_types: bool,
) -> Dict[str, Any]:
    created_row_ids: List[str] = []
    patch_updates: List[Dict[str, Any]] = []

    if records is not None:
        for idx, record in enumerate(records):
            if not isinstance(record, dict):
                print(f"ERROR: record at index {idx} is not a JSON object", file=sys.stderr)
                sys.exit(2)
            row_result = _request_api(
                "POST",
                f"/api/tables/{table_id}/rows",
                base_url=base_url,
                token=token,
                use_x_api_key=use_x_api_key,
                timeout=timeout,
                verbose=verbose,
            )
            row_id = (row_result or {}).get("rowId") if isinstance(row_result, dict) else None
            if not row_id:
                print(f"ERROR: row create response missing rowId: {row_result}", file=sys.stderr)
                sys.exit(1)
            row_id = str(row_id)
            created_row_ids.append(row_id)
            for key, value in record.items():
                patch_updates.append({"rowId": row_id, "key": str(key), "value": value})
    else:
        count = max(0, int(blank_count or 0))
        if count <= 0:
            print("ERROR: --count must be > 0", file=sys.stderr)
            sys.exit(2)
        for _ in range(count):
            row_result = _request_api(
                "POST",
                f"/api/tables/{table_id}/rows",
                base_url=base_url,
                token=token,
                use_x_api_key=use_x_api_key,
                timeout=timeout,
                verbose=verbose,
            )
            row_id = (row_result or {}).get("rowId") if isinstance(row_result, dict) else None
            if not row_id:
                print(f"ERROR: row create response missing rowId: {row_result}", file=sys.stderr)
                sys.exit(1)
            created_row_ids.append(str(row_id))

    patch_result: Optional[Any] = None
    if patch_updates:
        params = {"detect_types": "true"} if detect_types else None
        patch_result = _request_api(
            "PATCH",
            f"/api/tables/{table_id}/cells",
            base_url=base_url,
            token=token,
            use_x_api_key=use_x_api_key,
            payload={"updates": patch_updates},
            params=params,
            timeout=timeout,
            verbose=verbose,
        )

    return {
        "created": len(created_row_ids),
        "rowIds": created_row_ids,
        "updatedCells": len(patch_updates),
        "patchResult": patch_result,
    }


def _read_records_from_csv(
    file_path: str,
    *,
    delimiter: str = ",",
    encoding: str = "utf-8",
    trim_headers: bool = True,
    trim_values: bool = False,
    empty_as_null: bool = True,
    skip_empty_rows: bool = True,
    limit: Optional[int] = None,
) -> List[Dict[str, Any]]:
    records: List[Dict[str, Any]] = []
    try:
        with open(file_path, "r", encoding=encoding, newline="") as f:
            reader = csv.DictReader(f, delimiter=delimiter)
            if not reader.fieldnames:
                print("ERROR: CSV file has no header row", file=sys.stderr)
                sys.exit(2)

            normalized_headers = []
            for header in reader.fieldnames:
                key = (header or "")
                key = key.strip() if trim_headers else key
                normalized_headers.append(key)
            reader.fieldnames = normalized_headers

            for raw_row in reader:
                row_obj: Dict[str, Any] = {}
                for key, value in (raw_row or {}).items():
                    col_key = str(key or "").strip() if trim_headers else str(key or "")
                    if not col_key:
                        continue
                    cell_value: Any = value
                    if isinstance(cell_value, str) and trim_values:
                        cell_value = cell_value.strip()
                    if empty_as_null and (cell_value is None or (isinstance(cell_value, str) and cell_value.strip() == "")):
                        cell_value = None
                    row_obj[col_key] = cell_value

                if skip_empty_rows:
                    has_value = any(
                        value is not None and (not isinstance(value, str) or value.strip() != "")
                        for value in row_obj.values()
                    )
                    if not has_value:
                        continue

                records.append(row_obj)
                if limit is not None and limit > 0 and len(records) >= limit:
                    break
    except FileNotFoundError:
        print(f"ERROR: CSV file not found: {file_path}", file=sys.stderr)
        sys.exit(2)
    except Exception as exc:
        print(f"ERROR: failed to read CSV '{file_path}': {exc}", file=sys.stderr)
        sys.exit(2)
    return records


def _parse_csv_flag_values(values: Optional[List[str]]) -> List[str]:
    items: List[str] = []
    seen = set()
    for raw in values or []:
        for part in str(raw or "").split(","):
            token = str(part or "").strip()
            if not token or token in seen:
                continue
            seen.add(token)
            items.append(token)
    return items


def _parse_non_empty_requirements(values: Optional[List[str]]) -> Dict[str, float]:
    requirements: Dict[str, float] = {}
    for raw in values or []:
        for part in str(raw or "").split(","):
            token = str(part or "").strip()
            if not token:
                continue
            if ":" not in token:
                print(
                    f"ERROR: invalid --require-non-empty token '{token}'. Use key:ratio (for example post_content:0.95).",
                    file=sys.stderr,
                )
                sys.exit(2)
            key, ratio_raw = token.split(":", 1)
            column_key = str(key or "").strip()
            if not column_key:
                print(f"ERROR: invalid --require-non-empty token '{token}' (missing key)", file=sys.stderr)
                sys.exit(2)
            try:
                ratio = float(ratio_raw)
            except ValueError:
                print(f"ERROR: invalid --require-non-empty ratio in token '{token}'", file=sys.stderr)
                sys.exit(2)
            if ratio < 0 or ratio > 1:
                print(f"ERROR: invalid --require-non-empty ratio in token '{token}' (expected 0..1)", file=sys.stderr)
                sys.exit(2)
            requirements[column_key] = ratio
    return requirements


def _is_non_empty_cell_value(value: Any) -> bool:
    if value is None:
        return False
    if isinstance(value, str):
        return bool(value.strip())
    if isinstance(value, (list, tuple, set, dict)):
        return len(value) > 0
    return True


def _collect_import_assertions(args: argparse.Namespace) -> Dict[str, Any]:
    expected_rows_raw = getattr(args, "expected_rows", None)
    expected_rows: Optional[int] = None
    if expected_rows_raw is not None:
        try:
            expected_rows = int(expected_rows_raw)
        except (TypeError, ValueError):
            print("ERROR: --expected-rows must be an integer", file=sys.stderr)
            sys.exit(2)
        if expected_rows < 0:
            print("ERROR: --expected-rows must be >= 0", file=sys.stderr)
            sys.exit(2)

    return {
        "expected_rows": expected_rows,
        "required_columns": _parse_csv_flag_values(getattr(args, "require_columns", None)),
        "duplicate_key": _parse_csv_flag_values(getattr(args, "duplicate_key", None)),
        "require_non_empty": _parse_non_empty_requirements(getattr(args, "require_non_empty", None)),
    }


def _has_import_assertions(assertions: Dict[str, Any]) -> bool:
    return bool(
        assertions.get("expected_rows") is not None
        or assertions.get("required_columns")
        or assertions.get("duplicate_key")
        or assertions.get("require_non_empty")
    )


def _evaluate_import_assertions_on_records(
    *,
    records: List[Dict[str, Any]],
    assertions: Dict[str, Any],
    source: str,
) -> Dict[str, Any]:
    expected_rows = assertions.get("expected_rows")
    required_columns = list(assertions.get("required_columns") or [])
    duplicate_key = list(assertions.get("duplicate_key") or [])
    require_non_empty = dict(assertions.get("require_non_empty") or {})

    headers: List[str] = []
    header_seen = set()
    for record in records:
        if not isinstance(record, dict):
            continue
        for key in record.keys():
            key_str = str(key or "").strip()
            if not key_str or key_str in header_seen:
                continue
            header_seen.add(key_str)
            headers.append(key_str)

    checks: Dict[str, Any] = {}
    failures: List[Dict[str, Any]] = []
    row_count = len(records)

    if expected_rows is not None:
        passed = int(row_count) == int(expected_rows)
        checks["expected_rows"] = {
            "expected": int(expected_rows),
            "actual": int(row_count),
            "passed": passed,
        }
        if not passed:
            failures.append(
                {
                    "check": "expected_rows",
                    "message": f"Expected {expected_rows} rows but parsed {row_count}.",
                }
            )

    if required_columns:
        missing = [key for key in required_columns if key not in header_seen]
        passed = len(missing) == 0
        checks["required_columns"] = {
            "required": required_columns,
            "missing": missing,
            "passed": passed,
        }
        if not passed:
            failures.append(
                {
                    "check": "required_columns",
                    "message": f"Missing required columns: {', '.join(missing)}",
                }
            )

    if duplicate_key:
        missing_duplicate_columns = [key for key in duplicate_key if key not in header_seen]
        duplicate_count = 0
        sample_groups: List[Dict[str, Any]] = []
        passed = True
        if missing_duplicate_columns:
            passed = False
            failures.append(
                {
                    "check": "duplicate_key",
                    "message": f"Duplicate-key columns missing in CSV: {', '.join(missing_duplicate_columns)}",
                }
            )
        else:
            grouped: Dict[Tuple[str, ...], List[int]] = {}
            for idx, record in enumerate(records):
                if not isinstance(record, dict):
                    continue
                parts: List[str] = []
                has_value = False
                for key in duplicate_key:
                    value = record.get(key)
                    normalized = str(value or "").strip().lower()
                    if normalized:
                        has_value = True
                    parts.append(normalized)
                if not has_value:
                    continue
                signature = tuple(parts)
                grouped.setdefault(signature, []).append(idx + 1)

            duplicates = [indices for indices in grouped.values() if len(indices) > 1]
            if duplicates:
                passed = False
                duplicate_count = sum(max(0, len(indices) - 1) for indices in duplicates)
                sample_groups = [{"size": len(indices), "row_numbers": indices[:5]} for indices in duplicates[:5]]
                failures.append(
                    {
                        "check": "duplicate_key",
                        "message": f"Found {duplicate_count} duplicate rows using key {duplicate_key}.",
                    }
                )
        checks["duplicate_key"] = {
            "keys": duplicate_key,
            "duplicates": int(duplicate_count),
            "sample_groups": sample_groups,
            "passed": passed,
        }

    if require_non_empty:
        non_empty_checks: Dict[str, Any] = {}
        for key, threshold in require_non_empty.items():
            if key not in header_seen:
                non_empty_checks[key] = {
                    "threshold": threshold,
                    "ratio": 0.0,
                    "non_empty_rows": 0,
                    "total_rows": row_count,
                    "passed": False,
                    "reason": "column_missing",
                }
                failures.append(
                    {
                        "check": "require_non_empty",
                        "message": f"Column '{key}' missing for non-empty requirement.",
                    }
                )
                continue

            non_empty_rows = 0
            for record in records:
                value = record.get(key) if isinstance(record, dict) else None
                if _is_non_empty_cell_value(value):
                    non_empty_rows += 1
            ratio = (non_empty_rows / row_count) if row_count else 0.0
            passed = ratio >= threshold
            non_empty_checks[key] = {
                "threshold": threshold,
                "ratio": ratio,
                "non_empty_rows": non_empty_rows,
                "total_rows": row_count,
                "passed": passed,
            }
            if not passed:
                failures.append(
                    {
                        "check": "require_non_empty",
                        "message": (
                            f"Column '{key}' non-empty ratio {ratio:.4f} "
                            f"is below threshold {threshold:.4f}."
                        ),
                    }
                )
        checks["require_non_empty"] = non_empty_checks

    return {
        "source": source,
        "rows": row_count,
        "headers": headers,
        "checks": checks,
        "passed": len(failures) == 0,
        "failures": failures,
    }


def _build_import_verify_query_params(assertions: Dict[str, Any]) -> Dict[str, Any]:
    params: Dict[str, Any] = {}
    expected_rows = assertions.get("expected_rows")
    if expected_rows is not None:
        params["expected_rows"] = int(expected_rows)
    required_columns = list(assertions.get("required_columns") or [])
    if required_columns:
        params["required_columns"] = ",".join(required_columns)
    duplicate_key = list(assertions.get("duplicate_key") or [])
    if duplicate_key:
        params["duplicate_key"] = ",".join(duplicate_key)
    require_non_empty = dict(assertions.get("require_non_empty") or {})
    if require_non_empty:
        parts = [f"{key}:{ratio:g}" for key, ratio in require_non_empty.items()]
        params["require_non_empty"] = ",".join(parts)
    return params


def _job_snapshot(job_doc: Dict[str, Any]) -> Dict[str, Any]:
    return {
        "job_id": job_doc.get("job_id") or job_doc.get("jobId"),
        "status": job_doc.get("status"),
        "provider": job_doc.get("provider"),
        "processed_rows": int(job_doc.get("processed_rows") or 0),
        "total_rows": int(job_doc.get("total_rows") or 0),
        "error_rows": int(job_doc.get("error_rows") or 0),
        "credits_used": float(job_doc.get("credits_used") or 0.0),
        "billable": bool(job_doc.get("billable", False)),
        "updated_at": job_doc.get("updated_at"),
    }


def _poll_job(
    *,
    job_id: str,
    base_url: str,
    token: str,
    use_x_api_key: bool,
    interval_seconds: int,
    wait_timeout_seconds: int,
    request_timeout_seconds: int,
    verbose: bool,
    compact: bool,
    once: bool = False,
    print_updates: bool = True,
) -> Dict[str, Any]:
    url = f"{_api_url(base_url)}/api/bulk-jobs/{job_id}"
    headers = _auth_headers(token, use_x_api_key=use_x_api_key)
    return poll_job_until_terminal_impl(
        job_id=job_id,
        url=url,
        headers=headers,
        interval_seconds=interval_seconds,
        wait_timeout_seconds=wait_timeout_seconds,
        request_timeout_seconds=request_timeout_seconds,
        verbose=verbose,
        compact=compact,
        once=once,
        print_updates=print_updates,
        terminal_statuses=TERMINAL_JOB_STATUSES,
        job_snapshot_fn=_job_snapshot,
        emit_progress_fn=lambda data, compact_value: _emit_progress_event(data, compact=compact_value),
        error_body_writer=lambda body: _print_json(
            body,
            compact=False,
            file=sys.stderr,
            apply_projection=False,
        )
        if isinstance(body, (dict, list))
        else print(str(body), file=sys.stderr),
        requests_get=requests.get,
    )


def _poll_import_status(
    *,
    table_id: str,
    task_id: str,
    base_url: str,
    token: str,
    use_x_api_key: bool,
    interval_seconds: int,
    wait_timeout_seconds: int,
    request_timeout_seconds: int,
    verbose: bool,
    compact: bool,
) -> Dict[str, Any]:
    return poll_import_until_terminal_impl(
        table_id=table_id,
        task_id=task_id,
        base_url=base_url,
        token=token,
        use_x_api_key=use_x_api_key,
        interval_seconds=interval_seconds,
        wait_timeout_seconds=wait_timeout_seconds,
        request_timeout_seconds=request_timeout_seconds,
        verbose=verbose,
        compact=compact,
        output_mode=OUTPUT_MODE,
        emit_progress_fn=lambda data, compact_value: _emit_progress_event(data, compact=compact_value),
        request_api_fn=_request_api,
    )

# Standalone inline command helpers and payload builders.
def _print_setup_banner() -> None:
    banner = SETUP_BANNER.rstrip()
    if _supports_color():
        for line in banner.splitlines():
            if line.strip():
                print(f"{ANSI_PURPLE}{line}{ANSI_RESET}")
            else:
                print("")
    else:
        print(banner)
    print("Preview: configure your key once, then drive Smart Table from CLI or agents.")
    print("")


def _resolve_setup_api_key(args: argparse.Namespace) -> str:
    explicit = str(getattr(args, "api_key", "") or "").strip()
    if explicit:
        return explicit
    env_token = (
        os.environ.get("SMARTTABLE_TOKEN")
        or os.environ.get("AUTOTOUCH_API_KEY")
        or os.environ.get("AUTOTOUCH_TOKEN")
    )
    if env_token:
        return str(env_token).strip()

    cfg = _load_config()
    existing = str(cfg.get("api_key") or "").strip()
    if existing:
        return existing

    if sys.stdin.isatty():
        entered = getpass.getpass("Paste developer API key (stk_...): ").strip()
        if entered:
            return entered

    print(
        "ERROR: missing api key. Pass --api-key, set AUTOTOUCH_API_KEY, or run interactively.",
        file=sys.stderr,
    )
    sys.exit(2)


def cmd_setup(args: argparse.Namespace) -> None:
    if OUTPUT_MODE == "human" and not args.no_banner:
        _print_setup_banner()

    cfg = _load_config()
    existing_key = str(cfg.get("api_key") or "").strip()
    api_key = _resolve_setup_api_key(args)
    base_url = str(args.base_url or cfg.get("base_url") or _api_url()).rstrip("/")

    if existing_key and existing_key != api_key and not args.overwrite:
        print(
            "ERROR: config already has an API key. Pass --overwrite to replace it.",
            file=sys.stderr,
        )
        sys.exit(2)

    capabilities = _request_api(
        "GET",
        "/api/capabilities",
        base_url=base_url,
        token=api_key,
        use_x_api_key=bool(args.use_x_api_key),
        timeout=int(args.timeout or DEFAULT_TIMEOUT_SECONDS),
        verbose=bool(args.verbose),
    )

    cfg["api_key"] = api_key
    cfg["base_url"] = base_url
    cfg["updated_at_epoch"] = int(time.time())
    path = _save_config(cfg)

    output = {
        "setup_complete": True,
        "base_url": base_url,
        "auth_header_mode": "x-api-key" if args.use_x_api_key else "authorization",
        "config_path": str(path),
        "api_key_masked": _mask_api_key(api_key),
        "api_version": capabilities.get("api_version") if isinstance(capabilities, dict) else None,
        "recommended_next_steps": [
            "autotouch capabilities --output human",
            "autotouch tables create --name \"CLI Contacts\" --output human",
            "autotouch rows import-csv --table-id <TABLE_ID> --confirm-table-id <TABLE_ID> --file contacts.csv --checkpoint-file .autotouch-import.json --wait",
            "autotouch columns run-next --table-id <TABLE_ID> --column-id <COLUMN_ID> --count 5 --show-estimate --wait",
        ],
    }

    if OUTPUT_MODE == "human":
        print("✓ Key validated")
        print(f"✓ Config saved: {path}")
        print(f"✓ Base URL: {base_url}")
        print("")
        print("Next steps:")
        for line in output["recommended_next_steps"]:
            print(f"  {line}")
        return

    _print_json(output, compact=args.compact)


def cmd_auth_check(args: argparse.Namespace) -> None:
    cmd_auth_check_impl(args, runtime=_auth_command_runtime())


def cmd_auth_set_key(args: argparse.Namespace) -> None:
    cmd_auth_set_key_impl(args, runtime=_auth_command_runtime())


def cmd_auth_bootstrap(args: argparse.Namespace) -> None:
    cmd_auth_bootstrap_impl(args, runtime=_auth_command_runtime())


def cmd_auth_login(args: argparse.Namespace) -> None:
    cmd_auth_login_impl(args, runtime=_auth_command_runtime())


def cmd_auth_show(args: argparse.Namespace) -> None:
    cmd_auth_show_impl(args, runtime=_auth_command_runtime())


def cmd_auth_whoami(args: argparse.Namespace) -> None:
    cmd_auth_whoami_impl(args, runtime=_auth_command_runtime())


def cmd_auth_clear(args: argparse.Namespace) -> None:
    cmd_auth_clear_impl(args, runtime=_auth_command_runtime())


def cmd_prompts_list(args: argparse.Namespace) -> None:
    cmd_prompts_list_impl(args, runtime=_prompt_command_runtime())


def cmd_prompts_get(args: argparse.Namespace) -> None:
    cmd_prompts_get_impl(args, runtime=_prompt_command_runtime())


def cmd_prompts_create(args: argparse.Namespace) -> None:
    cmd_prompts_create_impl(args, runtime=_prompt_command_runtime())


def cmd_prompts_update(args: argparse.Namespace) -> None:
    cmd_prompts_update_impl(args, runtime=_prompt_command_runtime())


def cmd_prompts_delete(args: argparse.Namespace) -> None:
    cmd_prompts_delete_impl(args, runtime=_prompt_command_runtime())


def cmd_workspace_secrets_list(args: argparse.Namespace) -> None:
    cmd_workspace_secrets_list_impl(args, runtime=_workspace_secret_command_runtime())


def cmd_workspace_secrets_set(args: argparse.Namespace) -> None:
    cmd_workspace_secrets_set_impl(args, runtime=_workspace_secret_command_runtime())


def cmd_workspace_secrets_delete(args: argparse.Namespace) -> None:
    cmd_workspace_secrets_delete_impl(args, runtime=_workspace_secret_command_runtime())


def _coerce_string_list(values: Any) -> List[str]:
    if values is None:
        return []
    if isinstance(values, list):
        normalized: List[str] = []
        for item in values:
            for piece in str(item or "").split(","):
                stripped = piece.strip()
                if stripped:
                    normalized.append(stripped)
        return normalized
    if isinstance(values, str):
        stripped = values.strip()
        if not stripped:
            return []
        try:
            parsed = json.loads(stripped)
        except Exception:
            parsed = None
        if isinstance(parsed, list):
            return [str(item).strip() for item in parsed if str(item or "").strip()]
        return [piece.strip() for piece in stripped.split(",") if piece.strip()]
    return []


def _build_org_context_payload(args: argparse.Namespace) -> Dict[str, Any]:
    payload = _load_json_input(
        inline_json=getattr(args, "data_json", None),
        file_path=getattr(args, "data_file", None),
        context="data",
        default=None,
    )
    if payload is not None:
        if not isinstance(payload, dict):
            print("ERROR: org-context payload must be a JSON object", file=sys.stderr)
            sys.exit(2)
        return payload

    payload = {"source": getattr(args, "source", None) or "cli"}
    if getattr(args, "value_proposition", None) is not None:
        payload["value_proposition"] = args.value_proposition
    ideal_titles = _coerce_string_list(getattr(args, "ideal_title", None))
    if ideal_titles:
        payload["ideal_titles"] = ideal_titles
    if getattr(args, "buyer_persona", None) is not None:
        payload["buyer_persona"] = args.buyer_persona
    if getattr(args, "user_persona", None) is not None:
        payload["user_persona"] = args.user_persona
    if getattr(args, "voice_profile", None) is not None:
        payload["voice_profile"] = args.voice_profile
    case_study_urls = _coerce_string_list(getattr(args, "case_study_url", None))
    if case_study_urls:
        payload["case_study_urls"] = case_study_urls
    return payload


def _org_context_form_payload(payload: Dict[str, Any]) -> Dict[str, Any]:
    form_payload: Dict[str, Any] = {
        "source": str(payload.get("source") or "cli"),
        "value_proposition": str(payload.get("value_proposition") or ""),
        "ideal_titles": json.dumps(_coerce_string_list(payload.get("ideal_titles"))),
        "icp_buyer": str(payload.get("icp_buyer") or payload.get("buyer_persona") or ""),
        "icp_users": str(payload.get("icp_users") or payload.get("user_persona") or ""),
        "case_study_urls": json.dumps(_coerce_string_list(payload.get("case_study_urls"))),
        "voice_profile": str(payload.get("voice_profile") or ""),
    }
    return form_payload


def _build_personal_context_payload(args: argparse.Namespace) -> Dict[str, Any]:
    payload = _load_json_input(
        inline_json=getattr(args, "data_json", None),
        file_path=getattr(args, "data_file", None),
        context="data",
        default=None,
    )
    if payload is not None:
        if not isinstance(payload, dict):
            print("ERROR: personal-context payload must be a JSON object", file=sys.stderr)
            sys.exit(2)
        return payload

    payload = {}
    for arg_name, payload_key in {
        "title": "title",
        "linkedin_url": "linkedin_url",
        "personal_value_proposition": "personal_value_proposition",
        "voice_profile": "voice_profile",
    }.items():
        value = getattr(args, arg_name, None)
        if value is not None:
            payload[payload_key] = value

    territories = _coerce_string_list(getattr(args, "territory", None))
    if territories:
        payload["territories"] = territories

    if getattr(args, "use_personal_value_proposition", False):
        payload["use_personal_value_proposition"] = True
    if getattr(args, "use_personal_voice_profile", False):
        payload["use_personal_voice_profile"] = True
    return payload


def cmd_onboarding_submit_domain(args: argparse.Namespace) -> None:
    token = _resolve_user_session_token(args.token, required=True)
    payload = _load_json_input(
        inline_json=getattr(args, "data_json", None),
        file_path=getattr(args, "data_file", None),
        context="data",
        default=None,
    )
    if payload is None:
        target = _normalize_string_value(getattr(args, "website", None) or getattr(args, "domain", None))
        if not target:
            print("ERROR: pass --website/--domain or --data-json/--data-file", file=sys.stderr)
            sys.exit(2)
        payload = {"website": target}
    if not isinstance(payload, dict):
        print("ERROR: onboarding submit-domain payload must be a JSON object", file=sys.stderr)
        sys.exit(2)

    data = _request_api(
        "POST",
        "/api/onboarding/submit-domain",
        base_url=args.base_url,
        token=token,
        use_x_api_key=False,
        form_payload={
            "website": str(payload.get("website") or payload.get("domain") or "").strip(),
            "domain": str(payload.get("domain") or "").strip(),
        },
        timeout=args.timeout,
        verbose=args.verbose,
    )
    _print_json(data, compact=args.compact)


def cmd_org_context_get(args: argparse.Namespace) -> None:
    token = _resolve_user_session_token(args.token, required=True)
    data = _request_api(
        "GET",
        "/api/org/context",
        base_url=args.base_url,
        token=token,
        use_x_api_key=False,
        timeout=args.timeout,
        verbose=args.verbose,
    )
    _print_json(data, compact=args.compact)


def cmd_org_context_set(args: argparse.Namespace) -> None:
    token = _resolve_user_session_token(args.token, required=True)
    payload = _build_org_context_payload(args)
    data = _request_api(
        "POST",
        "/api/org/context",
        base_url=args.base_url,
        token=token,
        use_x_api_key=False,
        form_payload=_org_context_form_payload(payload),
        timeout=args.timeout,
        verbose=args.verbose,
    )
    _print_json(data, compact=args.compact)


def cmd_personal_context_get(args: argparse.Namespace) -> None:
    token = _resolve_user_session_token(args.token, required=True)
    data = _request_api(
        "GET",
        "/api/onboarding/personal-context",
        base_url=args.base_url,
        token=token,
        use_x_api_key=False,
        timeout=args.timeout,
        verbose=args.verbose,
    )
    _print_json(data, compact=args.compact)


def cmd_personal_context_set(args: argparse.Namespace) -> None:
    token = _resolve_user_session_token(args.token, required=True)
    payload = _build_personal_context_payload(args)
    data = _request_api(
        "POST",
        "/api/onboarding/personal-context",
        base_url=args.base_url,
        token=token,
        use_x_api_key=False,
        payload=payload,
        timeout=args.timeout,
        verbose=args.verbose,
    )
    _print_json(data, compact=args.compact)


def cmd_context_resolved(args: argparse.Namespace) -> None:
    token = _resolve_user_session_token(args.token, required=True)
    data = _request_api(
        "GET",
        "/api/llm/company-context",
        base_url=args.base_url,
        token=token,
        use_x_api_key=False,
        timeout=args.timeout,
        verbose=args.verbose,
    )
    _print_json(data, compact=args.compact)


def cmd_capabilities(args: argparse.Namespace) -> None:
    token = _resolve_token(args.token, required=False)
    data = _request_api(
        "GET",
        "/api/capabilities",
        base_url=args.base_url,
        token=token,
        use_x_api_key=args.use_x_api_key,
        timeout=args.timeout,
        verbose=args.verbose,
    )
    if OUTPUT_MODE == "human" and isinstance(data, dict):
        execution = data.get("execution_policies") if isinstance(data.get("execution_policies"), dict) else {}
        llm = execution.get("llm") if isinstance(execution.get("llm"), dict) else {}
        output_contract = llm.get("output_contract") if isinstance(llm.get("output_contract"), dict) else {}
        agent_contract = output_contract.get("agent") if isinstance(output_contract.get("agent"), dict) else {}
        basic_contract = output_contract.get("basic") if isinstance(output_contract.get("basic"), dict) else {}
        automation = data.get("automation") if isinstance(data.get("automation"), dict) else {}
        providers = automation.get("providers") if isinstance(automation.get("providers"), dict) else {}

        print(f"API version : {_as_display(data.get('api_version'))}")
        print(f"Base URL    : {_as_display(data.get('base_url'))}")

        auth = data.get("authentication") if isinstance(data.get("authentication"), dict) else {}
        scopes = auth.get("scopes")
        if isinstance(scopes, list):
            print(f"Scopes      : {', '.join(str(s) for s in scopes)}")

        print("")
        print("LLM output modes")
        print("----------------")
        print(
            "agent : JSON-oriented structured output"
            + (
                f" (default_data_type={agent_contract.get('default_data_type')})"
                if agent_contract.get("default_data_type")
                else ""
            )
        )
        basic_types = basic_contract.get("supported_data_types")
        basic_types_str = ", ".join(str(t) for t in basic_types) if isinstance(basic_types, list) else "text/json"
        print(f"basic : {basic_types_str} (JSON requires dataType=json)")
        if providers:
            print("")
            print("Provider setup")
            print("--------------")
            print(", ".join(sorted(str(name) for name in providers.keys())))
        linkedin = data.get("linkedin") if isinstance(data.get("linkedin"), dict) else None
        search = data.get("search") if isinstance(data.get("search"), dict) else None
        if isinstance(linkedin, dict):
            print("")
            print("LinkedIn list building")
            print("---------------------")
            modes = linkedin.get("api_modes", [])
            print(f"API modes       : {', '.join(str(m) for m in modes)}")
            print(f"Access gate     : {linkedin.get('access_gate', 'linkedin_access flag')}")
            caps = linkedin.get("rate_limits", {}).get("search_daily_caps", {})
            if caps:
                for mode, cap in caps.items():
                    print(f"  {mode:20s}: {cap}")
            best_for = linkedin.get("best_for")
            if isinstance(best_for, list) and best_for:
                print("Best for        :")
                for item in best_for:
                    print(f"  - {item}")
            not_for = linkedin.get("not_for")
            if isinstance(not_for, list) and not_for:
                print("Not for         :")
                for item in not_for:
                    print(f"  - {item}")
            print("Tip: run `autotouch linkedin recipe` for example payloads.")
        if isinstance(search, dict):
            print("")
            print("Provider-hidden search")
            print("----------------------")
            pricing = search.get("pricing", {}).get("families", {})
            if isinstance(pricing, dict) and pricing:
                print("Pricing")
                for family, entry in pricing.items():
                    if isinstance(entry, dict):
                        print(f"  {family:20s}: {entry.get('rule', '-')}")
            chooser = search.get("chooser_guidance") if isinstance(search.get("chooser_guidance"), dict) else {}
            company_first = chooser.get("use_company_search_when")
            if isinstance(company_first, list) and company_first:
                print("Use company search when:")
                for item in company_first:
                    print(f"  - {item}")
            people_first = chooser.get("use_people_search_when")
            if isinstance(people_first, list) and people_first:
                print("Use people search when:")
                for item in people_first:
                    print(f"  - {item}")
            linkedin_instead = chooser.get("use_linkedin_instead_when")
            if isinstance(linkedin_instead, list) and linkedin_instead:
                print("Use LinkedIn instead when:")
                for item in linkedin_instead:
                    print(f"  - {item}")
            print("Tip: run `autotouch search recipe` for example payloads.")
        print("")
        print("Tip: inspect automation.providers in JSON output for provider-specific setup contracts.")
        print("Tip: for JSON enrichment columns, run with `--wait` and verify terminal status before `autotouch columns projections`.")
        return

    _print_json(data, compact=args.compact)

# Template/schema emitters and runtime factories.
def _template_runtime() -> TemplateRuntime:
    return TemplateRuntime(
        output_mode=OUTPUT_MODE,
        print_json=lambda data, compact=False: _print_json(data, compact=compact),
        emit_text=_emit_text,
    )


def cmd_workflows_list(args: argparse.Namespace) -> None:
    emit_workflows_list(args, _template_runtime())


def cmd_workflows_recipe(args: argparse.Namespace) -> None:
    emit_workflows_recipe(args, _template_runtime())


def cmd_columns_recipe(args: argparse.Namespace) -> None:
    emit_columns_recipe(args, _template_runtime())


def cmd_sequences_recipe(args: argparse.Namespace) -> None:
    emit_sequences_recipe(args, _template_runtime())


def cmd_leads_recipe(args: argparse.Namespace) -> None:
    emit_leads_recipe(args, _template_runtime())


def cmd_tasks_recipe(args: argparse.Namespace) -> None:
    cmd_tasks_recipe_impl(args, runtime=_task_command_runtime())


def cmd_webhooks_recipe(args: argparse.Namespace) -> None:
    cmd_webhooks_recipe_impl(args, runtime=_webhook_command_runtime())


def cmd_schema(args: argparse.Namespace) -> None:
    emit_schema(args, _template_runtime())


def cmd_auth_schema(args: argparse.Namespace) -> None:
    emit_auth_schema(args, _template_runtime())


def cmd_onboarding_schema(args: argparse.Namespace) -> None:
    emit_onboarding_schema(args, _template_runtime())


def cmd_org_context_schema(args: argparse.Namespace) -> None:
    emit_org_context_schema(args, _template_runtime())


def cmd_personal_context_schema(args: argparse.Namespace) -> None:
    emit_personal_context_schema(args, _template_runtime())


def cmd_prompts_schema(args: argparse.Namespace) -> None:
    emit_prompt_templates_schema(args, _template_runtime())


def cmd_workspace_secrets_schema(args: argparse.Namespace) -> None:
    emit_workspace_secrets_schema(args, _template_runtime())


def cmd_tables_schema(args: argparse.Namespace) -> None:
    emit_tables_schema(args, _template_runtime())


def cmd_rows_schema(args: argparse.Namespace) -> None:
    emit_rows_schema(args, _template_runtime())


def cmd_cells_schema(args: argparse.Namespace) -> None:
    cmd_cells_schema_impl(args, runtime=_cell_command_runtime())


def _sequence_runtime() -> SequenceRuntime:
    return SequenceRuntime(
        load_json_input=_load_json_input,
        split_cli_string_values=_split_cli_string_values,
        parse_json_string=_parse_json_string,
        parse_string_list_payload=_parse_string_list_payload,
        load_string_values_from_file=_load_string_values_from_file,
        dedupe_keep_order=_dedupe_keep_order,
    )


def _sequence_mutation_params(args: argparse.Namespace) -> Optional[Dict[str, Any]]:
    return sequence_mutation_params_impl(args)


def _collect_sequence_lead_ids(args: argparse.Namespace) -> List[str]:
    return collect_sequence_lead_ids_impl(args, runtime=_sequence_runtime())


def _build_sequence_enroll_payload(args: argparse.Namespace) -> Dict[str, Any]:
    return build_sequence_enroll_payload_impl(args, runtime=_sequence_runtime())


def _sequence_command_runtime() -> SequenceCommandHandlerRuntime:
    return SequenceCommandHandlerRuntime(
        resolve_token=_resolve_token,
        request_api=_request_api,
        print_json=lambda data, compact=False: _print_json(data, compact=compact),
        load_json_input=_load_json_input,
        api_url=_api_url,
        emit_progress_event=lambda data, compact=False: _emit_progress_event(data, compact=compact),
        poll_job=_poll_job,
        default_timeout_seconds=DEFAULT_TIMEOUT_SECONDS,
        sequence_runtime_factory=_sequence_runtime,
    )


def _column_command_runtime() -> ColumnCommandHandlerRuntime:
    return ColumnCommandHandlerRuntime(
        resolve_token=_resolve_token,
        request_api=_request_api,
        print_json=lambda data, compact=False: _print_json(data, compact=compact),
        load_json_input=_load_json_input,
        validate_column_contract_payload_or_exit=_validate_column_contract_payload_or_exit,
        validate_add_to_crm_create_payload=_validate_add_to_crm_create_payload,
        build_projection_preflight_warnings=_build_projection_preflight_warnings,
        print_projection_preflight_warnings=_print_projection_preflight_warnings,
        normalize_run_payload=_normalize_run_payload,
        run_precheck_for_add_to_crm=_run_precheck_for_add_to_crm,
        execute_run_flow=_execute_run_flow,
        select_next_row_ids=_select_next_row_ids,
    )


def _cell_command_runtime() -> CellCommandHandlerRuntime:
    return CellCommandHandlerRuntime(
        resolve_token=_resolve_token,
        request_api=_request_api,
        print_json=lambda data, compact=False: _print_json(data, compact=compact),
        load_json_input=_load_json_input,
        emit_cells_schema=emit_cells_schema,
        template_runtime_factory=_template_runtime,
    )


def _row_command_runtime() -> RowCommandHandlerRuntime:
    return RowCommandHandlerRuntime(
        resolve_token=_resolve_token,
        request_api=_request_api,
        request_multipart_api=_request_multipart_api,
        print_json=lambda data, compact=False: _print_json(data, compact=compact),
        load_json_input=_load_json_input,
        api_url=_api_url,
        create_rows_and_patch_records=_create_rows_and_patch_records,
        read_records_from_csv=_read_records_from_csv,
        collect_import_assertions=_collect_import_assertions,
        has_import_assertions=_has_import_assertions,
        evaluate_import_assertions_on_records=_evaluate_import_assertions_on_records,
        build_import_verify_query_params=_build_import_verify_query_params,
        poll_import_status=_poll_import_status,
        assertion_failure_exit_code=ASSERTION_FAILURE_EXIT_CODE,
        default_timeout_seconds=DEFAULT_TIMEOUT_SECONDS,
    )


def _table_command_runtime() -> TableCommandHandlerRuntime:
    return TableCommandHandlerRuntime(
        resolve_token=_resolve_token,
        request_api=_request_api,
        print_json=lambda data, compact=False: _print_json(data, compact=compact),
        load_json_input=_load_json_input,
    )


def _task_command_runtime() -> TaskCommandHandlerRuntime:
    return TaskCommandHandlerRuntime(
        resolve_token=_resolve_token,
        request_api=_request_api,
        print_json=lambda data, compact=False: _print_json(data, compact=compact),
        load_required_object_payload=_load_required_object_payload,
        load_json_input=_load_json_input,
        emit_tasks_recipe=emit_tasks_recipe,
        template_runtime_factory=_template_runtime,
    )


def _webhook_command_runtime() -> WebhookCommandHandlerRuntime:
    return WebhookCommandHandlerRuntime(
        resolve_token=_resolve_token,
        request_api=_request_api,
        print_json=lambda data, compact=False: _print_json(data, compact=compact),
        load_json_input=_load_json_input,
        emit_webhooks_recipe=emit_webhooks_recipe,
        template_runtime_factory=_template_runtime,
    )


def _auth_command_runtime() -> AuthCommandHandlerRuntime:
    return AuthCommandHandlerRuntime(
        resolve_token=_resolve_token,
        resolve_user_session_token=_resolve_user_session_token,
        request_api=_request_api,
        print_json=lambda data, compact=False: _print_json(data, compact=compact),
        load_json_input=_load_json_input,
        api_url=_api_url,
        load_config=_load_config,
        save_config=_save_config,
        config_path=_config_path,
        mask_api_key=_mask_api_key,
        mask_secret=_mask_secret,
        normalize_string_value=_normalize_string_value,
        env_api_key=_env_api_key,
        env_user_token=_env_user_token,
    )


def _prompt_command_runtime() -> PromptCommandHandlerRuntime:
    return PromptCommandHandlerRuntime(
        resolve_token=_resolve_token,
        request_api=_request_api,
        print_json=lambda data, compact=False: _print_json(data, compact=compact),
        load_json_input=_load_json_input,
    )


def _workspace_secret_command_runtime() -> WorkspaceSecretCommandHandlerRuntime:
    return WorkspaceSecretCommandHandlerRuntime(
        resolve_token=_resolve_token,
        request_api=_request_api,
        print_json=lambda data, compact=False: _print_json(data, compact=compact),
        load_json_input=_load_json_input,
        normalize_string_value=_normalize_string_value,
    )


def _job_command_runtime() -> JobCommandHandlerRuntime:
    return JobCommandHandlerRuntime(
        resolve_token=_resolve_token,
        request_api=_request_api,
        print_json=lambda data, compact=False: _print_json(data, compact=compact),
        poll_job=_poll_job,
        api_url=_api_url,
        default_timeout_seconds=DEFAULT_TIMEOUT_SECONDS,
    )


def _lead_command_runtime() -> LeadCommandHandlerRuntime:
    return LeadCommandHandlerRuntime(
        resolve_token=_resolve_token,
        request_api=_request_api,
        print_json=lambda data, compact=False: _print_json(data, compact=compact),
        load_required_object_payload=_load_required_object_payload,
        load_json_input=_load_json_input,
        split_cli_string_values=_split_cli_string_values,
        parse_string_list_payload=_parse_string_list_payload,
        dedupe_keep_order=_dedupe_keep_order,
        normalize_string_value=_normalize_string_value,
    )


def _search_command_runtime() -> SearchCommandHandlerRuntime:
    return SearchCommandHandlerRuntime(
        resolve_token=_resolve_token,
        request_api=_request_api,
        print_json=lambda data, compact=False: _print_json(data, compact=compact),
        load_json_input=_load_json_input,
    )


def _linkedin_command_runtime() -> LinkedInCommandHandlerRuntime:
    return LinkedInCommandHandlerRuntime(
        resolve_token=_resolve_token,
        request_api=_request_api,
        print_json=lambda data, compact=False: _print_json(data, compact=compact),
        load_json_input=_load_json_input,
    )

# Thin compatibility wrappers for extracted command modules.
def cmd_rows_list(args: argparse.Namespace) -> None:
    cmd_rows_list_impl(args, runtime=_row_command_runtime())


def cmd_rows_get(args: argparse.Namespace) -> None:
    cmd_rows_get_impl(args, runtime=_row_command_runtime())


def cmd_sequences_list(args: argparse.Namespace) -> None:
    cmd_sequences_list_impl(args, runtime=_sequence_command_runtime())


def cmd_sequences_get(args: argparse.Namespace) -> None:
    cmd_sequences_get_impl(args, runtime=_sequence_command_runtime())


def cmd_sequences_stats(args: argparse.Namespace) -> None:
    cmd_sequences_stats_impl(args, runtime=_sequence_command_runtime())


def cmd_sequences_delivery_status(args: argparse.Namespace) -> None:
    cmd_sequences_delivery_status_impl(args, runtime=_sequence_command_runtime())


def cmd_sequences_create(args: argparse.Namespace) -> None:
    cmd_sequences_create_impl(args, runtime=_sequence_command_runtime())


def cmd_sequences_update(args: argparse.Namespace) -> None:
    cmd_sequences_update_impl(args, runtime=_sequence_command_runtime())


def cmd_sequences_delete(args: argparse.Namespace) -> None:
    cmd_sequences_delete_impl(args, runtime=_sequence_command_runtime())


def cmd_sequences_clone(args: argparse.Namespace) -> None:
    cmd_sequences_clone_impl(args, runtime=_sequence_command_runtime())


def cmd_sequences_status(args: argparse.Namespace) -> None:
    cmd_sequences_status_impl(args, runtime=_sequence_command_runtime())


def cmd_sequences_enroll(args: argparse.Namespace) -> None:
    cmd_sequences_enroll_impl(args, runtime=_sequence_command_runtime())


def cmd_sequences_pause_enrollment(args: argparse.Namespace) -> None:
    cmd_sequences_pause_enrollment_impl(args, runtime=_sequence_command_runtime())


def cmd_sop(args: argparse.Namespace) -> None:
    if args.out_file:
        with open(args.out_file, "w", encoding="utf-8") as f:
            json.dump(RUN_SOP_GUIDE, f, indent=2)

    if OUTPUT_MODE == "human":
        print(RUN_SOP_GUIDE["title"])
        print("-" * len(RUN_SOP_GUIDE["title"]))
        print("Rules:")
        for idx, rule in enumerate(RUN_SOP_GUIDE["rules"], start=1):
            print(f"{idx}. {rule}")
        print("\nClarifications:")
        for note in RUN_SOP_GUIDE["clarifications"]:
            print(f"- {note}")
        print("\nDefault run payload:")
        print(json.dumps(RUN_SOP_GUIDE["default_run_payload"], indent=2))
        if args.out_file:
            print(f"\nSaved: {args.out_file}")
        return

    _print_json(RUN_SOP_GUIDE, compact=args.compact)


def build_cli_manifest(parser: Optional[argparse.ArgumentParser] = None) -> Dict[str, Any]:
    manifest_parser = parser or build_parser()
    return build_cli_manifest_payload(CLI_VERSION, manifest_parser)


def _load_bundled_cli_manifest() -> Optional[Dict[str, Any]]:
    try:
        resource = importlib_resources.files("autotouch_cli").joinpath("data/cli-manifest.json")
        return json.loads(resource.read_text(encoding="utf-8"))
    except Exception:
        return None


def cmd_cli_manifest(args: argparse.Namespace) -> None:
    output = _load_bundled_cli_manifest() if getattr(args, "source", "live") == "bundled" else None
    if not isinstance(output, dict):
        output = build_cli_manifest()
    if args.out_file:
        with open(args.out_file, "w", encoding="utf-8") as f:
            json.dump(output, f, indent=2)
    _print_json(output, compact=args.compact)


def _load_bundled_cli_reference() -> Optional[str]:
    try:
        resource = importlib_resources.files("autotouch_cli").joinpath("data/CLI_REFERENCE.md")
        return resource.read_text(encoding="utf-8")
    except Exception:
        return None


def cmd_cli_reference(args: argparse.Namespace) -> None:
    output = _load_bundled_cli_reference() if getattr(args, "source", "live") == "bundled" else None
    if not output:
        output = build_cli_reference_markdown(build_cli_manifest())
    if args.out_file:
        with open(args.out_file, "w", encoding="utf-8") as f:
            f.write(output)
    if OUTPUT_MODE == "human":
        _emit_text(output.rstrip())
        return
    _print_json(
        {
            "version": CLI_VERSION,
            "reference_markdown": output,
        },
        compact=args.compact,
    )


def cmd_tables_list(args: argparse.Namespace) -> None:
    cmd_tables_list_impl(args, runtime=_table_command_runtime())


def cmd_tables_create(args: argparse.Namespace) -> None:
    cmd_tables_create_impl(args, runtime=_table_command_runtime())


def cmd_blacklist_list(args: argparse.Namespace) -> None:
    token = _resolve_token(args.token, required=True)
    params: Dict[str, Any] = {
        "type_filter": str(getattr(args, "type_filter", "all") or "all"),
        "page": max(1, int(getattr(args, "page", 1) or 1)),
        "limit": max(1, int(getattr(args, "limit", 100) or 100)),
    }
    search = str(getattr(args, "search", "") or "").strip()
    if search:
        params["search"] = search

    data = _request_api(
        "GET",
        "/api/blacklist",
        base_url=args.base_url,
        token=token,
        use_x_api_key=args.use_x_api_key,
        params=params,
        timeout=args.timeout,
        verbose=args.verbose,
    )
    _print_json(data, compact=args.compact)


def cmd_blacklist_add(args: argparse.Namespace) -> None:
    token = _resolve_token(args.token, required=True)
    entry_type = str(args.type).strip().lower()
    value = str(args.value or "").strip().lower()

    if entry_type == "domain":
        value = value.replace("https://", "").replace("http://", "")
        value = value.lstrip("@")
        value = value.split("/", 1)[0]

    payload = {
        "type": entry_type,
        "value": value,
        "reason": str(getattr(args, "reason", "") or ""),
        "notes": str(getattr(args, "notes", "") or ""),
    }
    data = _request_api(
        "POST",
        "/api/blacklist",
        base_url=args.base_url,
        token=token,
        use_x_api_key=args.use_x_api_key,
        payload=payload,
        timeout=args.timeout,
        verbose=args.verbose,
    )
    _print_json(data, compact=args.compact)


def cmd_blacklist_remove(args: argparse.Namespace) -> None:
    token = _resolve_token(args.token, required=True)
    data = _request_api(
        "DELETE",
        f"/api/blacklist/{args.entry_id}",
        base_url=args.base_url,
        token=token,
        use_x_api_key=args.use_x_api_key,
        timeout=args.timeout,
        verbose=args.verbose,
    )
    _print_json(data, compact=args.compact)


def cmd_blacklist_import(args: argparse.Namespace) -> None:
    token = _resolve_token(args.token, required=True)
    source_path = os.path.abspath(os.path.expanduser(str(args.file)))
    data = _request_multipart_api(
        "POST",
        "/api/blacklist/import",
        base_url=args.base_url,
        token=token,
        use_x_api_key=args.use_x_api_key,
        file_path=source_path,
        file_field="file",
        timeout=args.timeout,
        verbose=args.verbose,
    )
    if isinstance(data, dict):
        data.setdefault("source", source_path)
    _print_json(data, compact=args.compact)


def cmd_blacklist_check(args: argparse.Namespace) -> None:
    token = _resolve_token(args.token, required=True)
    emails = _collect_blacklist_emails(args)
    chunk_size = max(1, min(int(getattr(args, "chunk_size", 1000) or 1000), 1000))

    all_results: List[Dict[str, Any]] = []
    chunk_summaries: List[Dict[str, Any]] = []
    for chunk_index, chunk in enumerate(_chunk_list(emails, chunk_size), start=1):
        response = _request_api(
            "POST",
            "/api/blacklist/check",
            base_url=args.base_url,
            token=token,
            use_x_api_key=args.use_x_api_key,
            payload={"emails": chunk},
            timeout=args.timeout,
            verbose=args.verbose,
        )
        if not isinstance(response, dict):
            print("ERROR: unexpected response from /api/blacklist/check", file=sys.stderr)
            sys.exit(1)

        chunk_results = response.get("results") if isinstance(response.get("results"), list) else []
        chunk_summary = response.get("summary") if isinstance(response.get("summary"), dict) else {}
        all_results.extend([result for result in chunk_results if isinstance(result, dict)])
        chunk_summaries.append(
            {
                "chunk": chunk_index,
                "size": len(chunk),
                "summary": chunk_summary,
            }
        )

    total_blacklisted = sum(
        1
        for result in all_results
        if bool(result.get("is_blacklisted"))
    )
    output: Dict[str, Any] = {
        "input_count": len(emails),
        "chunks": len(chunk_summaries),
        "chunk_size": chunk_size,
        "summary": {
            "total_checked": len(all_results),
            "total_blacklisted": total_blacklisted,
            "total_clean": max(0, len(all_results) - total_blacklisted),
        },
    }
    if not bool(getattr(args, "summary_only", False)):
        output["results"] = all_results
        if len(chunk_summaries) > 1:
            output["chunk_summaries"] = chunk_summaries
    _print_json(output, compact=args.compact)


def cmd_blacklist_filter(args: argparse.Namespace) -> None:
    token = _resolve_token(args.token, required=True)
    emails = _collect_blacklist_emails(args)
    chunk_size = max(1, min(int(getattr(args, "chunk_size", 10000) or 10000), 10000))

    clean_emails: List[str] = []
    blacklisted_emails: List[Dict[str, Any]] = []
    chunk_summaries: List[Dict[str, Any]] = []
    for chunk_index, chunk in enumerate(_chunk_list(emails, chunk_size), start=1):
        response = _request_api(
            "POST",
            "/api/blacklist/filter",
            base_url=args.base_url,
            token=token,
            use_x_api_key=args.use_x_api_key,
            payload={"emails": chunk},
            timeout=args.timeout,
            verbose=args.verbose,
        )
        if not isinstance(response, dict):
            print("ERROR: unexpected response from /api/blacklist/filter", file=sys.stderr)
            sys.exit(1)

        chunk_clean = response.get("clean_emails") if isinstance(response.get("clean_emails"), list) else []
        chunk_blocked = (
            response.get("blacklisted_emails")
            if isinstance(response.get("blacklisted_emails"), list)
            else []
        )
        chunk_summary = response.get("summary") if isinstance(response.get("summary"), dict) else {}
        clean_emails.extend(
            [
                normalized
                for normalized in (_normalize_email_value(item) for item in chunk_clean)
                if normalized
            ]
        )
        blacklisted_emails.extend([item for item in chunk_blocked if isinstance(item, dict)])
        chunk_summaries.append(
            {
                "chunk": chunk_index,
                "size": len(chunk),
                "summary": chunk_summary,
            }
        )

    output: Dict[str, Any] = {
        "input_count": len(emails),
        "chunks": len(chunk_summaries),
        "chunk_size": chunk_size,
        "summary": {
            "total_provided": len(emails),
            "total_clean": len(clean_emails),
            "total_blacklisted": len(blacklisted_emails),
        },
    }
    if not bool(getattr(args, "summary_only", False)):
        output["clean_emails"] = clean_emails
        output["blacklisted_emails"] = blacklisted_emails
        if len(chunk_summaries) > 1:
            output["chunk_summaries"] = chunk_summaries
    _print_json(output, compact=args.compact)


def cmd_rows_add(args: argparse.Namespace) -> None:
    cmd_rows_add_impl(args, runtime=_row_command_runtime())


def cmd_rows_delete(args: argparse.Namespace) -> None:
    cmd_rows_delete_impl(args, runtime=_row_command_runtime())


def cmd_rows_import_csv(args: argparse.Namespace) -> None:
    cmd_rows_import_csv_impl(args, runtime=_row_command_runtime())


def cmd_rows_import_status(args: argparse.Namespace) -> None:
    cmd_rows_import_status_impl(args, runtime=_row_command_runtime())


def cmd_rows_import_verify(args: argparse.Namespace) -> None:
    cmd_rows_import_verify_impl(args, runtime=_row_command_runtime())


def cmd_rows_import_rollback(args: argparse.Namespace) -> None:
    cmd_rows_import_rollback_impl(args, runtime=_row_command_runtime())


def cmd_cells_patch(args: argparse.Namespace) -> None:
    cmd_cells_patch_impl(args, runtime=_cell_command_runtime())


def cmd_cells_get(args: argparse.Namespace) -> None:
    cmd_cells_get_impl(args, runtime=_cell_command_runtime())


def cmd_columns_list(args: argparse.Namespace) -> None:
    cmd_columns_list_impl(args, runtime=_column_command_runtime())


def cmd_columns_create(args: argparse.Namespace) -> None:
    cmd_columns_create_impl(args, runtime=_column_command_runtime())


def cmd_columns_stop(args: argparse.Namespace) -> None:
    cmd_columns_stop_impl(args, runtime=_column_command_runtime())


def cmd_columns_update(args: argparse.Namespace) -> None:
    cmd_columns_update_impl(args, runtime=_column_command_runtime())


def cmd_columns_delete(args: argparse.Namespace) -> None:
    cmd_columns_delete_impl(args, runtime=_column_command_runtime())


def cmd_columns_projections(args: argparse.Namespace) -> None:
    cmd_columns_projections_impl(args, runtime=_column_command_runtime())


def cmd_columns_test_http_request(args: argparse.Namespace) -> None:
    cmd_columns_test_http_request_impl(args, runtime=_column_command_runtime())


def cmd_columns_run(args: argparse.Namespace) -> None:
    cmd_columns_run_impl(args, runtime=_column_command_runtime())


def cmd_columns_run_next(args: argparse.Namespace) -> None:
    cmd_columns_run_next_impl(args, runtime=_column_command_runtime())


def cmd_columns_estimate(args: argparse.Namespace) -> None:
    cmd_columns_estimate_impl(args, runtime=_column_command_runtime())


def cmd_jobs_get(args: argparse.Namespace) -> None:
    cmd_jobs_get_impl(args, runtime=_job_command_runtime())


def cmd_jobs_list(args: argparse.Namespace) -> None:
    cmd_jobs_list_impl(args, runtime=_job_command_runtime())


def cmd_jobs_watch(args: argparse.Namespace) -> None:
    cmd_jobs_watch_impl(args, runtime=_job_command_runtime())


def cmd_leads_query(args: argparse.Namespace) -> None:
    cmd_leads_query_impl(args, runtime=_lead_command_runtime())


def cmd_leads_get(args: argparse.Namespace) -> None:
    cmd_leads_get_impl(args, runtime=_lead_command_runtime())


def cmd_leads_create(args: argparse.Namespace) -> None:
    cmd_leads_create_impl(args, runtime=_lead_command_runtime())


def cmd_leads_update(args: argparse.Namespace) -> None:
    cmd_leads_update_impl(args, runtime=_lead_command_runtime())


def cmd_leads_upsert_contact_channels(args: argparse.Namespace) -> None:
    cmd_leads_upsert_contact_channels_impl(args, runtime=_lead_command_runtime())


def cmd_leads_count(args: argparse.Namespace) -> None:
    cmd_leads_count_impl(args, runtime=_lead_command_runtime())


def cmd_leads_stats(args: argparse.Namespace) -> None:
    cmd_leads_stats_impl(args, runtime=_lead_command_runtime())


def cmd_leads_research(args: argparse.Namespace) -> None:
    cmd_leads_research_impl(args, runtime=_lead_command_runtime())


def cmd_leads_filters_metadata(args: argparse.Namespace) -> None:
    cmd_leads_filters_metadata_impl(args, runtime=_lead_command_runtime())


def cmd_leads_research_tables(args: argparse.Namespace) -> None:
    cmd_leads_research_tables_impl(args, runtime=_lead_command_runtime())


def cmd_leads_update_status(args: argparse.Namespace) -> None:
    cmd_leads_update_status_impl(args, runtime=_lead_command_runtime())


def cmd_leads_reassign_owner(args: argparse.Namespace) -> None:
    cmd_leads_reassign_owner_impl(args, runtime=_lead_command_runtime())


def cmd_tasks_query(args: argparse.Namespace) -> None:
    cmd_tasks_query_impl(args, runtime=_task_command_runtime())


def cmd_tasks_count(args: argparse.Namespace) -> None:
    cmd_tasks_count_impl(args, runtime=_task_command_runtime())


def cmd_tasks_assignee_counts(args: argparse.Namespace) -> None:
    cmd_tasks_assignee_counts_impl(args, runtime=_task_command_runtime())


def cmd_tasks_get(args: argparse.Namespace) -> None:
    cmd_tasks_get_impl(args, runtime=_task_command_runtime())


def cmd_tasks_stats(args: argparse.Namespace) -> None:
    cmd_tasks_stats_impl(args, runtime=_task_command_runtime())


def cmd_tasks_create(args: argparse.Namespace) -> None:
    cmd_tasks_create_impl(args, runtime=_task_command_runtime())


def cmd_tasks_update(args: argparse.Namespace) -> None:
    cmd_tasks_update_impl(args, runtime=_task_command_runtime())


def cmd_tasks_delete(args: argparse.Namespace) -> None:
    cmd_tasks_delete_impl(args, runtime=_task_command_runtime())


def cmd_tasks_bulk_update(args: argparse.Namespace) -> None:
    cmd_tasks_bulk_update_impl(args, runtime=_task_command_runtime())


def cmd_tasks_bulk_delete(args: argparse.Namespace) -> None:
    cmd_tasks_bulk_delete_impl(args, runtime=_task_command_runtime())


def cmd_tasks_draft(args: argparse.Namespace) -> None:
    cmd_tasks_draft_impl(args, runtime=_task_command_runtime())


def cmd_tasks_schedule_email(args: argparse.Namespace) -> None:
    cmd_tasks_schedule_email_impl(args, runtime=_task_command_runtime())


def cmd_webhooks_get(args: argparse.Namespace) -> None:
    cmd_webhooks_get_impl(args, runtime=_webhook_command_runtime())


def cmd_webhooks_rotate(args: argparse.Namespace) -> None:
    cmd_webhooks_rotate_impl(args, runtime=_webhook_command_runtime())


def cmd_webhooks_ingest(args: argparse.Namespace) -> None:
    cmd_webhooks_ingest_impl(args, runtime=_webhook_command_runtime())


def cmd_webhooks_subscriptions_list(args: argparse.Namespace) -> None:
    cmd_webhooks_subscriptions_list_impl(args, runtime=_webhook_command_runtime())


def cmd_webhooks_subscriptions_create(args: argparse.Namespace) -> None:
    cmd_webhooks_subscriptions_create_impl(args, runtime=_webhook_command_runtime())


def cmd_webhooks_subscriptions_get(args: argparse.Namespace) -> None:
    cmd_webhooks_subscriptions_get_impl(args, runtime=_webhook_command_runtime())


def cmd_webhooks_subscriptions_update(args: argparse.Namespace) -> None:
    cmd_webhooks_subscriptions_update_impl(args, runtime=_webhook_command_runtime())


def cmd_webhooks_subscriptions_delete(args: argparse.Namespace) -> None:
    cmd_webhooks_subscriptions_delete_impl(args, runtime=_webhook_command_runtime())


def cmd_webhooks_subscriptions_pause(args: argparse.Namespace) -> None:
    cmd_webhooks_subscriptions_pause_impl(args, runtime=_webhook_command_runtime())


def cmd_webhooks_subscriptions_resume(args: argparse.Namespace) -> None:
    cmd_webhooks_subscriptions_resume_impl(args, runtime=_webhook_command_runtime())


def cmd_webhooks_subscriptions_rotate_secret(args: argparse.Namespace) -> None:
    cmd_webhooks_subscriptions_rotate_secret_impl(args, runtime=_webhook_command_runtime())


def cmd_webhooks_subscriptions_test(args: argparse.Namespace) -> None:
    cmd_webhooks_subscriptions_test_impl(args, runtime=_webhook_command_runtime())


def cmd_webhooks_deliveries_list(args: argparse.Namespace) -> None:
    cmd_webhooks_deliveries_list_impl(args, runtime=_webhook_command_runtime())


def cmd_webhooks_deliveries_attempts(args: argparse.Namespace) -> None:
    cmd_webhooks_deliveries_attempts_impl(args, runtime=_webhook_command_runtime())


def cmd_status(args: argparse.Namespace) -> None:
    db = _mongo_client(args.mongo_uri, args.db_name)
    counts = _status_counts(db, args.table_id, args.column_id)
    total = sum(counts.values())
    _print_json(
        {"pending": counts["pending"], "done": counts["done"], "error": counts["error"], "totalCells": total},
        compact=bool(getattr(args, "compact", False)),
    )


def cmd_watch(args: argparse.Namespace) -> None:
    if OUTPUT_MODE == "json" and not bool(getattr(args, "once", False)):
        print("ERROR: watch with --output json requires --once. Use --output ndjson or --output human for streaming.", file=sys.stderr)
        sys.exit(2)
    db = _mongo_client(args.mongo_uri, args.db_name)
    interval = max(1, int(args.interval or 5))
    compact = bool(getattr(args, "compact", False))

    def _snapshot() -> Dict[str, int]:
        counts = _status_counts(db, args.table_id, args.column_id)
        total = sum(counts.values())
        return {
            "pending": counts["pending"],
            "done": counts["done"],
            "error": counts["error"],
            "totalCells": total,
        }

    if bool(getattr(args, "once", False)):
        snapshot = _snapshot()
        if OUTPUT_MODE == "human" and not (OUTPUT_SELECT or OUTPUT_JSON_POINTER):
            _emit_text(
                f"pending={snapshot['pending']} done={snapshot['done']} error={snapshot['error']} total={snapshot['totalCells']}"
            )
            return
        _print_json(snapshot, compact=compact)
        return

    try:
        while True:
            snapshot = _snapshot()
            if OUTPUT_MODE == "human" and not (OUTPUT_SELECT or OUTPUT_JSON_POINTER):
                _emit_text(
                    f"pending={snapshot['pending']} done={snapshot['done']} error={snapshot['error']} total={snapshot['totalCells']}"
                )
            else:
                _print_json(snapshot, compact=compact)
            time.sleep(interval)
    except KeyboardInterrupt:
        pass

# Parser assembly helpers and argparse wiring.
def _add_api_common_arguments(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("--base-url", default=_api_url(), help=f"API base URL (default: {DEFAULT_API_URL})")
    parser.add_argument("--token", help="Developer API key / JWT token")
    parser.add_argument("--use-x-api-key", action="store_true", help="Send token via X-API-Key header")
    parser.add_argument("--timeout", type=int, default=DEFAULT_TIMEOUT_SECONDS, help="HTTP timeout in seconds")
    _add_output_formatting_arguments(parser)
    parser.add_argument("--verbose", action="store_true", help="Print request metadata to stderr")


def _add_output_formatting_arguments(
    parser: argparse.ArgumentParser,
    *,
    default_output: str = "json",
    compact_help: str = "Print compact JSON",
) -> None:
    parser.add_argument("--output", choices=list(OUTPUT_MODES), default=default_output, help="Output mode")
    parser.add_argument("--compact", action="store_true", help=compact_help)
    projection_group = parser.add_mutually_exclusive_group()
    projection_group.add_argument("--select", help="Extract a dotted field path from the final result (for example: id or items.0.id)")
    projection_group.add_argument("--json-pointer", help="Extract a JSON pointer from the final result (for example: /id)")


def _add_run_scope_arguments(parser: argparse.ArgumentParser) -> None:
    parser.add_argument(
        "--scope",
        choices=["all", "subset", "row", "firstN", "filtered"],
        default="all",
        help="Run scope: row=one explicit ID, subset=explicit many IDs, filtered=current filters, firstN=first N rows, all=entire table",
    )
    parser.add_argument("--row-id", help="Single row ID for scope=row")
    parser.add_argument("--row-ids", nargs="*", help="Row IDs for subset scope (or a single row when scope=row)")
    parser.add_argument(
        "--first-n",
        type=int,
        help="First N rows (for scope=firstN). Use with --unprocessed-only to process the next rows without reruns",
    )
    run_mode = parser.add_mutually_exclusive_group()
    run_mode.add_argument(
        "--unprocessed-only",
        dest="unprocessed_only",
        action="store_true",
        help="Only process rows without values (default)",
    )
    run_mode.add_argument(
        "--include-processed",
        dest="unprocessed_only",
        action="store_false",
        help="Include rows that already have output",
    )
    parser.set_defaults(unprocessed_only=True)
    parser.add_argument("--filters-json", help="JSON object for scope=filtered")
    parser.add_argument("--filters-file", help="Path to JSON file for scope=filtered")
    parser.add_argument("--data-json", help="Explicit RunRequest payload JSON (overrides scope flags)")
    parser.add_argument("--data-file", help="Path to RunRequest payload JSON file (overrides scope flags)")


def _add_run_execution_arguments(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("--show-estimate", action="store_true", help="Include estimate response in output")
    parser.add_argument("--dry-run", action="store_true", help="Only estimate; do not execute run")
    parser.add_argument("--max-credits", type=float, help="Block run when estimate exceeds this value")
    parser.add_argument(
        "--allow-unknown-max",
        action="store_true",
        help="Allow run when estimated_credits_max is null (max-credits guard uses min estimate)",
    )
    parser.add_argument(
        "--wait",
        action="store_true",
        help="Wait for bulk job terminal status by polling /api/bulk-jobs/{job_id}",
    )
    parser.add_argument("--quiet-wait", action="store_true", help="Suppress per-poll output in --wait mode")
    parser.add_argument("--poll-interval", type=int, default=2, help="Polling interval seconds for --wait")
    parser.add_argument("--wait-timeout", type=int, default=0, help="Max seconds to wait (0 = no timeout)")
    parser.add_argument("--fail-on-error", action="store_true", help="Exit non-zero when final status is error/cancelled")
    parser.add_argument("--fail-on-partial", action="store_true", help="Exit non-zero when final status is partial")


def _add_leads_query_arguments(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("--data-json", help="Explicit leads query payload JSON")
    parser.add_argument("--data-file", help="Path to leads query payload JSON file")
    parser.add_argument("--filter-json", help="Filter descriptor JSON object")
    parser.add_argument("--filter-file", help="Path to filter descriptor JSON file")
    parser.add_argument("--sort-json", help="Sort spec JSON object/array")
    parser.add_argument("--sort-file", help="Path to sort spec JSON file")
    parser.add_argument("--search", help="Free-text lead search")
    parser.add_argument("--limit", type=int, help="Pagination limit")
    parser.add_argument("--cursor", help="Pagination cursor")
    parser.add_argument("--scope", choices=["org", "user"], help="Lead scope")
    parser.add_argument("--source-table-id", help="Research table id used for scope/research context")
    parser.add_argument(
        "--source-table-scope",
        choices=["company", "lead"],
        help="Research scope resolution mode",
    )
    parser.add_argument(
        "--related-tables-mode",
        choices=["linked", "direct", "none"],
        help="How related_tables should be populated",
    )
    parser.add_argument(
        "--include-research-data",
        action="store_true",
        help="Inline research_data when --source-table-id is provided",
    )
    parser.add_argument(
        "--include-placeholder-leads",
        action="store_true",
        help="Include placeholder/incomplete lead records",
    )


def _add_leads_research_arguments(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("--data-json", help="Explicit leads research payload JSON")
    parser.add_argument("--data-file", help="Path to leads research payload JSON file")
    parser.add_argument(
        "--lead-id",
        action="append",
        help="Lead id (repeatable; comma-separated also supported)",
    )
    parser.add_argument("--lead-ids-json", help="JSON array or object with lead_ids[]")
    parser.add_argument("--lead-ids-file", help="Path to JSON file with lead_ids[]")
    parser.add_argument("--source-table-id", help="Research table id")
    parser.add_argument(
        "--field-id",
        action="append",
        help="Research field/column id to include (repeatable; comma-separated also supported)",
    )
    parser.add_argument("--field-ids-json", help="JSON array or object with field_ids[]")
    parser.add_argument("--field-ids-file", help="Path to JSON file with field_ids[]")


def _add_leads_selection_arguments(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("--data-json", help="Explicit bulk lead action payload JSON")
    parser.add_argument("--data-file", help="Path to bulk lead action payload JSON file")
    parser.add_argument(
        "--lead-id",
        action="append",
        help="Lead id (repeatable; comma-separated also supported)",
    )
    parser.add_argument("--lead-ids-json", help="JSON array or object with lead_ids[]")
    parser.add_argument("--lead-ids-file", help="Path to JSON/TXT/CSV file with lead_ids[]")
    parser.add_argument("--lead-ids-column", default="lead_id", help="CSV column for lead ids (default: lead_id)")
    parser.add_argument("--filter-json", help="Filter descriptor JSON object")
    parser.add_argument("--filter-file", help="Path to filter descriptor JSON file")
    parser.add_argument("--sort-json", help="Sort spec JSON object/array")
    parser.add_argument("--sort-file", help="Path to sort spec JSON file")
    parser.add_argument("--search", help="Free-text lead search")
    parser.add_argument("--limit", type=int, help="Optional descriptor selection limit")
    parser.add_argument("--scope", choices=["org", "user"], help="Lead scope")
    parser.add_argument("--source-table-id", help="Optional research table id for descriptor selection")
    parser.add_argument(
        "--source-table-scope",
        choices=["company", "lead"],
        help="Optional research scope resolution mode",
    )


def cmd_search_recipe(args: argparse.Namespace) -> None:
    cmd_search_recipe_impl(args, runtime=_search_command_runtime(), recipes=SEARCH_RECIPES)


def cmd_search_companies(args: argparse.Namespace) -> None:
    cmd_search_companies_impl(args, runtime=_search_command_runtime())


def cmd_search_people(args: argparse.Namespace) -> None:
    cmd_search_people_impl(args, runtime=_search_command_runtime())


def cmd_search_similar_companies(args: argparse.Namespace) -> None:
    cmd_search_similar_companies_impl(args, runtime=_search_command_runtime())


def cmd_search_news(args: argparse.Namespace) -> None:
    cmd_search_news_impl(args, runtime=_search_command_runtime())


def cmd_search_local_businesses(args: argparse.Namespace) -> None:
    cmd_search_local_businesses_impl(args, runtime=_search_command_runtime())


def cmd_search_reviews(args: argparse.Namespace) -> None:
    cmd_search_reviews_impl(args, runtime=_search_command_runtime())


def cmd_search_filings(args: argparse.Namespace) -> None:
    cmd_search_filings_impl(args, runtime=_search_command_runtime())


def cmd_linkedin_status(args: argparse.Namespace) -> None:
    cmd_linkedin_status_impl(args, runtime=_linkedin_command_runtime())


def cmd_linkedin_limits(args: argparse.Namespace) -> None:
    cmd_linkedin_limits_impl(args, runtime=_linkedin_command_runtime())


def cmd_linkedin_search(args: argparse.Namespace) -> None:
    cmd_linkedin_search_impl(args, runtime=_linkedin_command_runtime())


def cmd_linkedin_search_params(args: argparse.Namespace) -> None:
    cmd_linkedin_search_params_impl(args, runtime=_linkedin_command_runtime())


LINKEDIN_RECIPE_TYPES = list(linkedin_recipe_types())

_LINKEDIN_RECIPES: Dict[str, Any] = linkedin_recipe_entries()


def cmd_linkedin_recipe(args: argparse.Namespace) -> None:
    cmd_linkedin_recipe_impl(args, runtime=_linkedin_command_runtime(), recipes=_LINKEDIN_RECIPES)


def cmd_linkedin_posts(args: argparse.Namespace) -> None:
    cmd_linkedin_posts_impl(args, runtime=_linkedin_command_runtime())


def cmd_linkedin_post(args: argparse.Namespace) -> None:
    cmd_linkedin_post_impl(args, runtime=_linkedin_command_runtime())


def cmd_linkedin_comments(args: argparse.Namespace) -> None:
    cmd_linkedin_comments_impl(args, runtime=_linkedin_command_runtime())


def cmd_linkedin_reactions(args: argparse.Namespace) -> None:
    cmd_linkedin_reactions_impl(args, runtime=_linkedin_command_runtime())


def _add_actor_override_argument(parser: argparse.ArgumentParser) -> None:
    parser.add_argument(
        "--actor-user-id",
        help="Optional actor override; must resolve to an active user in the same organization",
    )


# Parser assembly entrypoint.
def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="autotouch", description="Smart Table CLI", allow_abbrev=False)
    p.add_argument("--version", action="version", version=f"%(prog)s {CLI_VERSION}")
    sub = p.add_subparsers(dest="cmd", required=True)

    pcm = sub.add_parser("cli-manifest", help="Print the machine-readable CLI command manifest")
    pcm.add_argument("--source", choices=["live", "bundled"], default="live", help="Manifest source")
    pcm.add_argument("--out-file", help="Write manifest JSON to file")
    _add_output_formatting_arguments(pcm)
    pcm.set_defaults(func=cmd_cli_manifest)

    pcr = sub.add_parser("cli-reference", help="Print the generated CLI reference")
    pcr.add_argument("--source", choices=["live", "bundled"], default="live", help="Reference source")
    pcr.add_argument("--out-file", help="Write reference markdown to file")
    _add_output_formatting_arguments(pcr, default_output="human", compact_help="Print compact JSON when using JSON output")
    pcr.set_defaults(func=cmd_cli_reference)

    pshared = sub.add_parser("schema", help="Print shared descriptor schemas used across commands")
    pshared.add_argument("--type", choices=["all", *SHARED_SCHEMA_TYPES], default="all")
    pshared.add_argument("--out-file", help="Write schema JSON to file")
    _add_output_formatting_arguments(pshared)
    pshared.set_defaults(func=cmd_schema)

    # setup
    psetup = sub.add_parser("setup", help="First-run setup with key validation")
    psetup.add_argument("--api-key", help="Developer API key (stk_...)")
    psetup.add_argument("--base-url", default=_api_url(), help=f"API base URL (default: {DEFAULT_API_URL})")
    psetup.add_argument("--overwrite", action="store_true", help="Replace existing stored API key")
    psetup.add_argument("--use-x-api-key", action="store_true", help="Validate using X-API-Key header")
    psetup.add_argument("--timeout", type=int, default=DEFAULT_TIMEOUT_SECONDS, help="HTTP timeout in seconds")
    _add_output_formatting_arguments(psetup, default_output="human")
    psetup.add_argument("--verbose", action="store_true", help="Print request metadata to stderr")
    psetup.add_argument("--no-banner", action="store_true", help="Skip banner in human mode")
    psetup.set_defaults(func=cmd_setup)

    register_auth_subcommands(
        sub,
        add_api_common_arguments=_add_api_common_arguments,
        add_output_formatting_arguments=_add_output_formatting_arguments,
        handlers={
            "check": cmd_auth_check,
            "bootstrap": cmd_auth_bootstrap,
            "login": cmd_auth_login,
            "set_key": cmd_auth_set_key,
            "show": cmd_auth_show,
            "whoami": cmd_auth_whoami,
            "clear": cmd_auth_clear,
            "schema": cmd_auth_schema,
        },
        auth_schema_types=AUTH_SCHEMA_TYPES,
        default_api_url=_api_url(),
        default_timeout_seconds=DEFAULT_TIMEOUT_SECONDS,
    )

    # onboarding
    ponboard = sub.add_parser("onboarding", help="Onboarding helpers")
    onboarding_sub = ponboard.add_subparsers(dest="onboarding_cmd", required=True)

    posubmit = onboarding_sub.add_parser("submit-domain", help="Analyze company website and seed org context")
    posubmit.add_argument("--website", help="Company website/domain")
    posubmit.add_argument("--domain", help="Alias for --website")
    posubmit.add_argument("--data-json", help="Explicit submit-domain payload JSON")
    posubmit.add_argument("--data-file", help="Path to submit-domain payload JSON file")
    _add_api_common_arguments(posubmit)
    posubmit.set_defaults(func=cmd_onboarding_submit_domain)

    poschema = onboarding_sub.add_parser("schema", help="Print onboarding payload schemas")
    poschema.add_argument("--type", choices=["all", *ONBOARDING_SCHEMA_TYPES], default="all")
    poschema.add_argument("--out-file", help="Write schema JSON to file")
    _add_output_formatting_arguments(poschema)
    poschema.set_defaults(func=cmd_onboarding_schema)

    # org context
    porg = sub.add_parser("org-context", help="Organization value prop / ICP context")
    org_sub = porg.add_subparsers(dest="org_context_cmd", required=True)

    porgg = org_sub.add_parser("get", help="Fetch organization context")
    _add_api_common_arguments(porgg)
    porgg.set_defaults(func=cmd_org_context_get)

    porgs = org_sub.add_parser("set", help="Save organization context")
    porgs.add_argument("--source", default="cli", help="Context source label (default: cli)")
    porgs.add_argument("--value-proposition", help="Organization value proposition")
    porgs.add_argument("--ideal-title", action="append", help="Ideal title (repeatable; comma-separated also supported)")
    porgs.add_argument("--buyer-persona", help="Buyer persona / ICP buyer")
    porgs.add_argument("--user-persona", help="User persona / ICP users")
    porgs.add_argument("--voice-profile", help="Voice profile guidance")
    porgs.add_argument("--case-study-url", action="append", help="Case-study URL (repeatable)")
    porgs.add_argument("--data-json", help="Explicit org context payload JSON")
    porgs.add_argument("--data-file", help="Path to org context payload JSON file")
    _add_api_common_arguments(porgs)
    porgs.set_defaults(func=cmd_org_context_set)

    porgschema = org_sub.add_parser("schema", help="Print org-context payload schemas")
    porgschema.add_argument("--type", choices=["all", *ORG_CONTEXT_SCHEMA_TYPES], default="all")
    porgschema.add_argument("--out-file", help="Write schema JSON to file")
    _add_output_formatting_arguments(porgschema)
    porgschema.set_defaults(func=cmd_org_context_schema)

    # personal context
    ppersonal = sub.add_parser("personal-context", help="Personal sender / rep context")
    personal_sub = ppersonal.add_subparsers(dest="personal_context_cmd", required=True)

    ppersonalg = personal_sub.add_parser("get", help="Fetch personal context")
    _add_api_common_arguments(ppersonalg)
    ppersonalg.set_defaults(func=cmd_personal_context_get)

    ppersonals = personal_sub.add_parser("set", help="Save personal context")
    ppersonals.add_argument("--title", help="User title")
    ppersonals.add_argument("--linkedin-url", help="User LinkedIn URL")
    ppersonals.add_argument("--territory", action="append", help="Territory or region (repeatable)")
    ppersonals.add_argument("--use-personal-value-proposition", action="store_true", help="Prefer the personal value proposition over org default")
    ppersonals.add_argument("--personal-value-proposition", help="Personal value proposition")
    ppersonals.add_argument("--voice-profile", help="Personal voice profile guidance")
    ppersonals.add_argument("--use-personal-voice-profile", action="store_true", help="Prefer the personal voice profile over org default")
    ppersonals.add_argument("--data-json", help="Explicit personal context payload JSON")
    ppersonals.add_argument("--data-file", help="Path to personal context payload JSON file")
    _add_api_common_arguments(ppersonals)
    ppersonals.set_defaults(func=cmd_personal_context_set)

    ppersonalschema = personal_sub.add_parser("schema", help="Print personal-context payload schemas")
    ppersonalschema.add_argument("--type", choices=["all", *PERSONAL_CONTEXT_SCHEMA_TYPES], default="all")
    ppersonalschema.add_argument("--out-file", help="Write schema JSON to file")
    _add_output_formatting_arguments(ppersonalschema)
    ppersonalschema.set_defaults(func=cmd_personal_context_schema)

    register_workspace_secrets_subcommands(
        sub,
        add_api_common_arguments=_add_api_common_arguments,
        add_output_formatting_arguments=_add_output_formatting_arguments,
        handlers={
            "list": cmd_workspace_secrets_list,
            "set": cmd_workspace_secrets_set,
            "delete": cmd_workspace_secrets_delete,
            "schema": cmd_workspace_secrets_schema,
        },
        workspace_secret_schema_types=WORKSPACE_SECRET_SCHEMA_TYPES,
    )

    register_prompts_subcommands(
        sub,
        add_api_common_arguments=_add_api_common_arguments,
        add_output_formatting_arguments=_add_output_formatting_arguments,
        handlers={
            "list": cmd_prompts_list,
            "get": cmd_prompts_get,
            "create": cmd_prompts_create,
            "update": cmd_prompts_update,
            "delete": cmd_prompts_delete,
            "schema": cmd_prompts_schema,
        },
        prompt_template_schema_types=PROMPT_TEMPLATE_SCHEMA_TYPES,
    )

    # resolved context
    pctx = sub.add_parser("context", help="Resolved requester context used by enrichment/runtime")
    ctx_sub = pctx.add_subparsers(dest="context_cmd", required=True)
    pctxr = ctx_sub.add_parser("resolved", help="Show effective requester context after org/personal overrides")
    _add_api_common_arguments(pctxr)
    pctxr.set_defaults(func=cmd_context_resolved)

    # capabilities
    pc = sub.add_parser("capabilities", help="Get machine-readable API capabilities")
    _add_api_common_arguments(pc)
    pc.set_defaults(func=cmd_capabilities)

    register_search_subcommands(
        sub,
        add_api_common_arguments=_add_api_common_arguments,
        handlers={
            "recipe": cmd_search_recipe,
            "companies": cmd_search_companies,
            "people": cmd_search_people,
            "similar_companies": cmd_search_similar_companies,
            "news": cmd_search_news,
            "local_businesses": cmd_search_local_businesses,
            "reviews": cmd_search_reviews,
            "filings": cmd_search_filings,
        },
        recipe_types=SEARCH_RECIPE_TYPES,
    )

    # workflows
    pw = sub.add_parser("workflows", help="Common multi-step workflow blueprints")
    workflows_sub = pw.add_subparsers(dest="workflows_cmd", required=True)

    pwl = workflows_sub.add_parser("list", help="List common workflow blueprints")
    pwl.add_argument("--out-file", help="Save JSON payload to file")
    _add_output_formatting_arguments(pwl)
    pwl.set_defaults(func=cmd_workflows_list)

    pwr = workflows_sub.add_parser("recipe", help="Emit one workflow blueprint payload")
    pwr.add_argument("--type", required=True, choices=WORKFLOW_BLUEPRINT_TYPES, help="Workflow blueprint type")
    pwr.add_argument("--out-file", help="Save raw workflow payload to file")
    _add_output_formatting_arguments(pwr)
    pwr.set_defaults(func=cmd_workflows_recipe)

    register_tables_subcommands(
        sub,
        add_api_common_arguments=_add_api_common_arguments,
        add_output_formatting_arguments=_add_output_formatting_arguments,
        handlers={
            "list": cmd_tables_list,
            "create": cmd_tables_create,
            "schema": cmd_tables_schema,
        },
        table_schema_types=TABLE_SCHEMA_TYPES,
    )

    # blacklist
    pbl = sub.add_parser("blacklist", help="Organization blacklist operations (admin)")
    blacklist_sub = pbl.add_subparsers(dest="blacklist_cmd", required=True)

    pbll = blacklist_sub.add_parser("list", help="List blacklist entries")
    pbll.add_argument("--type-filter", choices=["all", "email", "domain"], default="all")
    pbll.add_argument("--search", help="Filter by value/reason/notes")
    pbll.add_argument("--page", type=int, default=1, help="Page number (default: 1)")
    pbll.add_argument("--limit", type=int, default=100, help="Entries per page (default: 100)")
    _add_api_common_arguments(pbll)
    pbll.set_defaults(func=cmd_blacklist_list)

    pbla = blacklist_sub.add_parser("add", help="Add a blacklist entry")
    pbla.add_argument("--type", choices=["email", "domain"], required=True, help="Entry type")
    pbla.add_argument("--value", required=True, help="Email or domain value")
    pbla.add_argument("--reason", default="", help="Optional reason")
    pbla.add_argument("--notes", default="", help="Optional notes")
    _add_api_common_arguments(pbla)
    pbla.set_defaults(func=cmd_blacklist_add)

    pblr = blacklist_sub.add_parser("remove", help="Remove a blacklist entry by id")
    pblr.add_argument("--entry-id", required=True)
    _add_api_common_arguments(pblr)
    pblr.set_defaults(func=cmd_blacklist_remove)

    pbli = blacklist_sub.add_parser("import", help="Import blacklist entries from CSV/TXT")
    pbli.add_argument("--file", required=True, help="Path to CSV/TXT file")
    _add_api_common_arguments(pbli)
    pbli.set_defaults(func=cmd_blacklist_import)

    pblc = blacklist_sub.add_parser("check", help="Check whether emails are blacklisted")
    pblc.add_argument(
        "--email",
        action="append",
        help="Email value (repeatable; comma-separated also supported)",
    )
    pblc.add_argument("--emails-json", help="JSON array or object with emails[]")
    pblc.add_argument("--emails-file", help="Path to .txt/.csv/.json email list")
    pblc.add_argument("--emails-column", default="email", help="CSV column for emails (default: email)")
    pblc.add_argument(
        "--chunk-size",
        type=int,
        default=1000,
        help="Request chunk size (max 1000, default: 1000)",
    )
    pblc.add_argument("--summary-only", action="store_true", help="Omit per-email results")
    _add_api_common_arguments(pblc)
    pblc.set_defaults(func=cmd_blacklist_check)

    pblf = blacklist_sub.add_parser("filter", help="Filter blacklisted emails from a list")
    pblf.add_argument(
        "--email",
        action="append",
        help="Email value (repeatable; comma-separated also supported)",
    )
    pblf.add_argument("--emails-json", help="JSON array or object with emails[]")
    pblf.add_argument("--emails-file", help="Path to .txt/.csv/.json email list")
    pblf.add_argument("--emails-column", default="email", help="CSV column for emails (default: email)")
    pblf.add_argument(
        "--chunk-size",
        type=int,
        default=10000,
        help="Request chunk size (max 10000, default: 10000)",
    )
    pblf.add_argument("--summary-only", action="store_true", help="Omit full clean/blocked lists")
    _add_api_common_arguments(pblf)
    pblf.set_defaults(func=cmd_blacklist_filter)

    register_rows_subcommands(
        sub,
        add_api_common_arguments=_add_api_common_arguments,
        add_output_formatting_arguments=_add_output_formatting_arguments,
        handlers={
            "list": cmd_rows_list,
            "get": cmd_rows_get,
            "add": cmd_rows_add,
            "import_csv": cmd_rows_import_csv,
            "schema": cmd_rows_schema,
            "import_status": cmd_rows_import_status,
            "import_verify": cmd_rows_import_verify,
            "import_rollback": cmd_rows_import_rollback,
            "delete": cmd_rows_delete,
        },
        row_schema_types=ROW_SCHEMA_TYPES,
    )

    register_cells_subcommands(
        sub,
        add_api_common_arguments=_add_api_common_arguments,
        add_output_formatting_arguments=_add_output_formatting_arguments,
        handlers={
            "get": cmd_cells_get,
            "patch": cmd_cells_patch,
            "schema": cmd_cells_schema,
        },
        schema_types=CELL_SCHEMA_TYPES,
    )

    register_columns_subcommands(
        sub,
        add_api_common_arguments=_add_api_common_arguments,
        add_output_formatting_arguments=_add_output_formatting_arguments,
        add_run_scope_arguments=_add_run_scope_arguments,
        add_run_execution_arguments=_add_run_execution_arguments,
        handlers={
            "list": cmd_columns_list,
            "create": cmd_columns_create,
            "update": cmd_columns_update,
            "delete": cmd_columns_delete,
            "projections": cmd_columns_projections,
            "test_http_request": cmd_columns_test_http_request,
            "run": cmd_columns_run,
            "stop": cmd_columns_stop,
            "run_next": cmd_columns_run_next,
            "estimate": cmd_columns_estimate,
            "recipe": cmd_columns_recipe,
        },
        column_recipe_types=COLUMN_RECIPE_TYPES,
    )

    register_sequences_subcommands(
        sub,
        add_api_common_arguments=_add_api_common_arguments,
        add_output_formatting_arguments=_add_output_formatting_arguments,
        add_actor_override_argument=_add_actor_override_argument,
        handlers={
            "list": cmd_sequences_list,
            "get": cmd_sequences_get,
            "stats": cmd_sequences_stats,
            "delivery_status": cmd_sequences_delivery_status,
            "recipe": cmd_sequences_recipe,
            "create": cmd_sequences_create,
            "update": cmd_sequences_update,
            "delete": cmd_sequences_delete,
            "clone": cmd_sequences_clone,
            "status": cmd_sequences_status,
            "enroll": cmd_sequences_enroll,
            "pause_enrollment": cmd_sequences_pause_enrollment,
        },
        sequence_recipe_types=SEQUENCE_RECIPE_TYPES,
    )

    register_leads_subcommands(
        sub,
        add_api_common_arguments=_add_api_common_arguments,
        add_leads_selection_arguments=_add_leads_selection_arguments,
        add_leads_query_arguments=_add_leads_query_arguments,
        add_leads_research_arguments=_add_leads_research_arguments,
        handlers={
            "recipe": cmd_leads_recipe,
            "get": cmd_leads_get,
            "create": cmd_leads_create,
            "update": cmd_leads_update,
            "upsert_contact_channels": cmd_leads_upsert_contact_channels,
            "update_status": cmd_leads_update_status,
            "reassign_owner": cmd_leads_reassign_owner,
            "query": cmd_leads_query,
            "count": cmd_leads_count,
            "stats": cmd_leads_stats,
            "research": cmd_leads_research,
            "filters_metadata": cmd_leads_filters_metadata,
            "research_tables": cmd_leads_research_tables,
        },
        lead_recipe_types=LEAD_RECIPE_TYPES,
    )

    # tasks
    ptask = sub.add_parser("tasks", help="Task queue operations")
    tasks_sub = ptask.add_subparsers(dest="tasks_cmd", required=True)
    add_tasks_subcommands(
        tasks_sub,
        add_api_common_arguments=_add_api_common_arguments,
        add_actor_override_argument=_add_actor_override_argument,
        task_recipe_types=TASK_RECIPE_TYPES,
        handlers={
            "recipe": cmd_tasks_recipe,
            "query": cmd_tasks_query,
            "count": cmd_tasks_count,
            "assignee_counts": cmd_tasks_assignee_counts,
            "get": cmd_tasks_get,
            "stats": cmd_tasks_stats,
            "create": cmd_tasks_create,
            "update": cmd_tasks_update,
            "delete": cmd_tasks_delete,
            "bulk_update": cmd_tasks_bulk_update,
            "bulk_delete": cmd_tasks_bulk_delete,
            "draft": cmd_tasks_draft,
            "schedule_email": cmd_tasks_schedule_email,
        },
    )

    register_jobs_subcommands(
        sub,
        add_api_common_arguments=_add_api_common_arguments,
        handlers={
            "get": cmd_jobs_get,
            "list": cmd_jobs_list,
            "watch": cmd_jobs_watch,
        },
    )

    # webhooks
    pwh = sub.add_parser("webhooks", help="Table webhook operations")
    wh_sub = pwh.add_subparsers(dest="webhooks_cmd", required=True)
    add_webhooks_subcommands(
        wh_sub,
        add_api_common_arguments=_add_api_common_arguments,
        webhook_recipe_types=WEBHOOK_RECIPE_TYPES,
        handlers={
            "recipe": cmd_webhooks_recipe,
            "get": cmd_webhooks_get,
            "rotate": cmd_webhooks_rotate,
            "ingest": cmd_webhooks_ingest,
            "subscriptions_list": cmd_webhooks_subscriptions_list,
            "subscriptions_create": cmd_webhooks_subscriptions_create,
            "subscriptions_get": cmd_webhooks_subscriptions_get,
            "subscriptions_update": cmd_webhooks_subscriptions_update,
            "subscriptions_delete": cmd_webhooks_subscriptions_delete,
            "subscriptions_pause": cmd_webhooks_subscriptions_pause,
            "subscriptions_resume": cmd_webhooks_subscriptions_resume,
            "subscriptions_rotate_secret": cmd_webhooks_subscriptions_rotate_secret,
            "subscriptions_test": cmd_webhooks_subscriptions_test,
            "deliveries_list": cmd_webhooks_deliveries_list,
            "deliveries_attempts": cmd_webhooks_deliveries_attempts,
        },
    )

    register_linkedin_subcommands(
        sub,
        add_api_common_arguments=_add_api_common_arguments,
        handlers={
            "recipe": cmd_linkedin_recipe,
            "status": cmd_linkedin_status,
            "limits": cmd_linkedin_limits,
            "search": cmd_linkedin_search,
            "search_params": cmd_linkedin_search_params,
            "posts": cmd_linkedin_posts,
            "post": cmd_linkedin_post,
            "comments": cmd_linkedin_comments,
            "reactions": cmd_linkedin_reactions,
        },
        recipe_types=LINKEDIN_RECIPE_TYPES,
    )

    # Backward-compatible aliases
    # run
    palias_run = sub.add_parser("run", help="Alias for: columns run")
    palias_run.add_argument("--table-id", required=True)
    palias_run.add_argument("--column-id", required=True)
    _add_run_scope_arguments(palias_run)
    _add_run_execution_arguments(palias_run)
    _add_api_common_arguments(palias_run)
    palias_run.set_defaults(func=cmd_columns_run)

    palias_run_next = sub.add_parser("run-next", help="Alias for: columns run-next")
    palias_run_next.add_argument("--table-id", required=True)
    palias_run_next.add_argument("--column-id", required=True)
    palias_run_next.add_argument("--count", type=int, required=True, help="Maximum number of rows to queue")
    palias_run_next.add_argument("--filters-json", help="Optional JSON object to select from filtered rows")
    palias_run_next.add_argument("--filters-file", help="Optional JSON file to select from filtered rows")
    palias_run_next.add_argument("--page-size", type=int, default=200, help="Rows page size while selecting candidates (max 1000)")
    palias_run_next.add_argument(
        "--include-processed",
        dest="unprocessed_only",
        action="store_false",
        help="Include rows that already have output in candidate selection",
    )
    palias_run_next.add_argument("--fail-if-empty", action="store_true", help="Exit non-zero when no eligible rows are selected")
    palias_run_next.set_defaults(unprocessed_only=True)
    _add_run_execution_arguments(palias_run_next)
    _add_api_common_arguments(palias_run_next)
    palias_run_next.set_defaults(func=cmd_columns_run_next)

    # status
    ps = sub.add_parser("status", help="Show pending/done/error counts for a table/column (requires pymongo + MONGODB_URI)")
    ps.add_argument("--table-id", required=True)
    ps.add_argument("--column-id", required=True)
    ps.add_argument("--mongo-uri", help="Override MONGODB_URI")
    ps.add_argument("--db-name", help="Override MONGODB_DB_NAME")
    _add_output_formatting_arguments(ps)
    ps.set_defaults(func=cmd_status)

    # watch
    pw = sub.add_parser("watch", help="Watch status periodically (requires pymongo + MONGODB_URI)")
    pw.add_argument("--table-id", required=True)
    pw.add_argument("--column-id", required=True)
    pw.add_argument("--interval", type=int, default=5)
    pw.add_argument("--once", action="store_true", help="Fetch one snapshot and exit")
    pw.add_argument("--mongo-uri", help="Override MONGODB_URI")
    pw.add_argument("--db-name", help="Override MONGODB_DB_NAME")
    _add_output_formatting_arguments(pw, default_output="human")
    pw.set_defaults(func=cmd_watch)

    # SOP guidance for agents/users (packaged with CLI)
    psop = sub.add_parser("sop", help="Print credit-safe execution SOP + default filtered run payload")
    psop.add_argument("--out-file", help="Write SOP JSON to file")
    _add_output_formatting_arguments(psop)
    psop.set_defaults(func=cmd_sop)

    return p


def main(argv: Optional[List[str]] = None) -> None:
    parser = build_parser()
    args = parser.parse_args(argv)
    _set_output_mode(getattr(args, "output", "json"))
    _set_output_projection(getattr(args, "select", None), getattr(args, "json_pointer", None))
    args.func(args)


if __name__ == "__main__":
    main()
