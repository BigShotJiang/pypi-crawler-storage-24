"""
AI LLS Library - Core business logic for Landline Scrubber.

This library provides phone verification and DNC checking capabilities.

Version 2.0.0 establishes clean semantic versioning baseline.
All version management now controlled by Python Semantic Release.

Dependencies optimized for Lambda deployment (removed unused pandas/pyarrow).
"""

from ai_lls_lib.apikeys import (
    KeyNotFoundError,
    LimitExceededError,
    ManagedApiKeyService,
    RevokedKeyError,
)
from ai_lls_lib.common import DecimalEncoder, extract_area_code
from ai_lls_lib.core.cache import DynamoDBCache
from ai_lls_lib.core.models import (
    BulkJob,
    BulkJobStatus,
    JobStatus,
    LineType,
    PhoneVerification,
    VerificationSource,
)
from ai_lls_lib.core.processor import BulkProcessor
from ai_lls_lib.core.verifier import PhoneVerifier
from ai_lls_lib.files import FileService
from ai_lls_lib.key_management import (
    compute_key_hash,
    generate_key_id,
    generate_managed_key,
    validate_expiration_days,
)

__version__ = "3.9.0"

__all__ = [
    "PhoneVerification",
    "BulkJob",
    "BulkJobStatus",
    "LineType",
    "VerificationSource",
    "JobStatus",
    "PhoneVerifier",
    "BulkProcessor",
    "DynamoDBCache",
    "compute_key_hash",
    "generate_key_id",
    "generate_managed_key",
    "validate_expiration_days",
    "DecimalEncoder",
    "extract_area_code",
    "ManagedApiKeyService",
    "KeyNotFoundError",
    "RevokedKeyError",
    "LimitExceededError",
    "FileService",
]
