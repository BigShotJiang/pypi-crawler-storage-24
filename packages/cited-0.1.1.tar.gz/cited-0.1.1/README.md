# cited

Python CLI for running science-backed AI agents. Discover peer-reviewed agents and run them with a single command.

## Installation

```bash
pip install cited
```

## Quick Start

```bash
# Find an agent
cited search "failure mode analysis"

# See what it expects
cited info dfmea-agent

# Run it
cited run dfmea-agent --input input.json

# Validate input before running
cited validate dfmea-agent --input input.json
```

## Commands

| Command | Description |
|---------|-------------|
| `cited run <agent>` | Run an agent with JSON input |
| `cited search <query>` | Search the agent catalog |
| `cited info <agent>` | Show agent details and schema |
| `cited validate <agent>` | Validate input without running |
| `cited cache list` | List cached agents |
| `cited cache clear` | Clear the local cache |
| `cited config show` | Show current configuration |
| `cited config set <key> <value>` | Update a config value |
| `cited version` | Show CLI version |

### Agent references

Agents can be referenced by slug or with a pinned version:

```bash
cited run dfmea-agent              # latest
cited run dfmea-agent@1.0.0       # pinned version
```

### Input / output

Input is read from a file (`--input`) or stdin:

```bash
cited run dfmea-agent --input input.json
cat input.json | cited run dfmea-agent
```

Output is JSON written to stdout, making it easy to pipe:

```bash
cited run dfmea-agent --input input.json | jq '.results'
```

## Configuration

| Env var | Default | Description |
|---------|---------|-------------|
| `CITED_API_URL` | `https://citedagents.com` | Platform API base URL |
| `CITED_CACHE_DIR` | OS cache dir | Where agent blueprints are cached |

Or use `cited config set`:

```bash
cited config set api-url https://citedagents.com
cited config set cache-dir /tmp/cited-cache
```

## License

MIT
