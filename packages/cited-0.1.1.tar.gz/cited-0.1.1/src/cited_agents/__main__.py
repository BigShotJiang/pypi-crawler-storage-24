"""Allow running as `python -m cited_agents`."""

from .cli import app

app()
