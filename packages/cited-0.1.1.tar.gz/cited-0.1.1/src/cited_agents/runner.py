"""Agent execution: installation and running — language-agnostic.

Supports Python agents (via venv + pip), Node.js agents (via npm),
and any other language whose install/run commands are self-contained
in the spawn_protocol.
"""

from __future__ import annotations

import json
import os
import subprocess
import sys
import venv
from pathlib import Path
from typing import Any

from rich.console import Console

from . import cache, client
from .validator import validate_input, validate_output, ValidationError

err_console = Console(stderr=True)


class RunError(Exception):
    """Raised when agent execution fails."""
    pass


def run_agent(
    slug: str,
    version: str | None,
    input_data: dict[str, Any],
    blueprint: dict[str, Any],
    *,
    skip_validation: bool = False,
    output_mode: str | None = None,
) -> dict[str, Any]:
    """Run an agent end-to-end: install (if needed) → validate input → execute → validate output.

    Returns the parsed output JSON.
    """
    spawn = blueprint.get("spawn_protocol", {})
    runtime = blueprint.get("runtime", {})
    resolved_version = blueprint.get("version", version or "latest")
    content_hash = spawn.get("content_hash")

    # Step 1: Check required env vars
    _check_env_vars(runtime.get("env", []))

    # Step 2: Validate input
    if not skip_validation:
        try:
            validate_input(input_data, blueprint.get("input_schema", {}))
        except ValidationError as e:
            raise RunError(f"Input validation failed:\n{e}") from e

    # Step 2b: Inject _output_mode (platform-managed field)
    if output_mode is not None:
        input_data["_output_mode"] = output_mode
    elif "_output_mode" not in input_data:
        input_data["_output_mode"] = "data"

    # Step 3: Ensure agent is installed (cache hit or install)
    cache_dir = _ensure_installed(slug, resolved_version, content_hash, spawn, blueprint)

    # Step 4: Execute
    run_cmd = spawn.get("run", "")
    if not run_cmd:
        raise RunError("Blueprint has no spawn_protocol.run command")

    output = _execute(cache_dir, run_cmd, input_data)

    # Step 5: Validate output
    if not skip_validation:
        try:
            validate_output(output, blueprint.get("output_schema", {}))
        except ValidationError as e:
            err_console.print(f"[yellow]Warning: Output validation failed:[/yellow]\n{e}")
            # Don't fail on output validation — the agent produced output, let the caller decide

    return output


def _check_env_vars(env_vars: list[dict[str, Any]]) -> None:
    """Check that all required environment variables are set."""
    missing = []
    for var in env_vars:
        if var.get("required") and not os.environ.get(var["name"]):
            desc = var.get("description", "")
            missing.append(f"  {var['name']}: {desc}" if desc else f"  {var['name']}")

    if missing:
        raise RunError(
            "Missing required environment variables:\n" + "\n".join(missing) +
            "\n\nSet them before running:\n  export " + " ".join(
                f'{v.split(":")[0].strip()}=...' for v in missing
            )
        )


# ── Installation ─────────────────────────────────────────────────────────────


def _ensure_installed(
    slug: str,
    version: str,
    content_hash: str | None,
    spawn: dict[str, Any],
    blueprint: dict[str, Any],
) -> Path:
    """Ensure the agent is installed. Returns the cache directory path.

    Two installation strategies:
    - Wheel (package_url exists): Python venv + pip install  (Python-only)
    - Fallback (git clone): Run the install command directly  (any language)
    """
    # Check cache
    if cache.is_cached(slug, version, content_hash):
        err_console.print(f"[dim]Using cached {slug}@{version}[/dim]")
        return cache.get_cache_dir(slug, version, content_hash)

    err_console.print(f"[blue]Installing {slug}@{version}...[/blue]")

    # Save blueprint
    cache_dir = cache.save_blueprint(slug, version, content_hash, blueprint)

    package_url = spawn.get("package_url")
    package_hash = (spawn.get("content_hash") or "").replace("sha256:", "")

    if package_url:
        # ── Wheel path: Python venv + pip install ────────────────────────────
        venv_dir = cache.get_venv_dir(slug, version, content_hash)

        err_console.print("[dim]  Creating virtual environment...[/dim]")
        venv.create(str(venv_dir), with_pip=True, clear=True)

        if sys.platform == "win32":
            pip_path = venv_dir / "Scripts" / "pip"
        else:
            pip_path = venv_dir / "bin" / "pip"

        # Download wheel
        err_console.print("[dim]  Downloading package...[/dim]")
        wheel_dir = cache.get_wheel_dir(slug, version, content_hash)
        wheel_filename = package_url.split("/")[-1]
        wheel_path = wheel_dir / wheel_filename
        client.download_wheel(package_url, str(wheel_path))

        # Verify hash
        if package_hash and not cache.verify_hash(wheel_path, package_hash):
            raise RunError(
                f"SHA256 hash mismatch for {wheel_filename}. "
                "The package may have been tampered with."
            )

        # Install wheel
        err_console.print("[dim]  Installing package...[/dim]")
        _run_pip(pip_path, ["install", str(wheel_path)])
    else:
        # ── Fallback path: run install command directly (any language) ────────
        fallback = spawn.get("fallback", {})
        install_cmd = spawn.get("install") or fallback.get("install", "")
        if not install_cmd:
            raise RunError("No install method available in blueprint")

        err_console.print("[dim]  Installing via fallback...[/dim]")
        _run_shell_in_dir(install_cmd, cwd=cache_dir)

    err_console.print(f"[green]Installed {slug}@{version}[/green]")
    (cache_dir / ".installed").touch()
    return cache_dir


# ── Execution ────────────────────────────────────────────────────────────────


def _find_source_dir(cache_dir: Path) -> Path | None:
    """Find the cloned agent source directory within the cache dir.

    Returns the first directory that isn't a known cache subdirectory
    (venv/, wheel/). This works regardless of the clone target name.
    """
    known_dirs = {"venv", "wheel"}
    for entry in cache_dir.iterdir():
        if entry.is_dir() and entry.name not in known_dirs:
            return entry
    return None


def _execute(cache_dir: Path, run_cmd: str, input_data: dict[str, Any]) -> dict[str, Any]:
    """Execute the agent command, piping JSON via stdin, capturing stdout.

    Automatically detects the runtime environment:
    - If cache_dir/venv exists → activate Python venv
    - If source_dir/node_modules/.bin exists → add Node.js binaries to PATH
    - Otherwise → run with system PATH (Go binary, compiled agent, etc.)
    """
    env = os.environ.copy()

    # Conditionally activate Python venv (wheel-installed agents)
    venv_dir = cache_dir / "venv"
    if venv_dir.exists():
        bin_dir = venv_dir / ("Scripts" if sys.platform == "win32" else "bin")
        env["VIRTUAL_ENV"] = str(venv_dir)
        env["PATH"] = str(bin_dir) + os.pathsep + env.get("PATH", "")
        env.pop("PYTHONHOME", None)

    # Find the agent source directory (cloned repo)
    source_dir = _find_source_dir(cache_dir)

    if source_dir and source_dir.exists():
        # Add Node.js bin to PATH if present (npm-installed agents)
        node_bin = source_dir / "node_modules" / ".bin"
        if node_bin.exists():
            env["PATH"] = str(node_bin) + os.pathsep + env.get("PATH", "")

    # Set cwd to source dir for relative path resolution in run_cmd
    cwd = str(source_dir) if source_dir and source_dir.exists() else None

    input_json = json.dumps(input_data)

    err_console.print(f"[blue]Running: {run_cmd}[/blue]")

    try:
        result = subprocess.run(
            run_cmd,
            input=input_json,
            capture_output=True,
            text=True,
            env=env,
            shell=True,
            cwd=cwd,
            timeout=600,  # 10 minute timeout
        )
    except subprocess.TimeoutExpired:
        raise RunError("Agent execution timed out after 10 minutes")
    except FileNotFoundError:
        raise RunError(f"Command not found: {run_cmd}")

    # Stream stderr to user (agent logs/progress)
    if result.stderr:
        for line in result.stderr.strip().splitlines():
            err_console.print(f"[dim]{line}[/dim]")

    if result.returncode != 0:
        raise RunError(
            f"Agent exited with code {result.returncode}\n"
            f"stderr: {result.stderr[:500] if result.stderr else '(empty)'}"
        )

    # Parse stdout as JSON
    stdout = result.stdout.strip()
    if not stdout:
        raise RunError("Agent produced no output on stdout")

    try:
        return json.loads(stdout)
    except json.JSONDecodeError as e:
        # Show first 200 chars of output for debugging
        preview = stdout[:200] + ("..." if len(stdout) > 200 else "")
        raise RunError(f"Agent output is not valid JSON: {e}\nOutput preview: {preview}") from e


# ── Shell helpers ────────────────────────────────────────────────────────────


def _run_pip(pip_path: Path, args: list[str]) -> None:
    """Run pip in the venv."""
    result = subprocess.run(
        [str(pip_path)] + args,
        capture_output=True,
        text=True,
        timeout=300,
    )
    if result.returncode != 0:
        raise RunError(f"pip failed:\n{result.stderr[:500]}")


def _run_shell_in_dir(cmd: str, cwd: Path | None = None) -> None:
    """Run a shell command in a directory. No venv activation — the command
    itself handles environment setup (pip install, npm install, etc.)."""
    result = subprocess.run(
        cmd,
        shell=True,
        capture_output=True,
        text=True,
        cwd=str(cwd) if cwd else None,
        timeout=300,
    )
    if result.returncode != 0:
        raise RunError(f"Install command failed:\n{result.stderr[-1000:]}")
