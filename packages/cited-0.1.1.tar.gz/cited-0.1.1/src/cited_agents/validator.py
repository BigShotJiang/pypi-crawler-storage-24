"""JSON Schema validation for agent input/output."""

from __future__ import annotations

from typing import Any

import jsonschema


class ValidationError(Exception):
    """Raised when input or output fails schema validation."""

    def __init__(self, errors: list[str]) -> None:
        self.errors = errors
        msg = f"{len(errors)} validation error(s):\n" + "\n".join(f"  - {e}" for e in errors)
        super().__init__(msg)


def validate_input(data: Any, schema: dict[str, Any]) -> None:
    """Validate input data against the agent's input_schema.

    Raises ValidationError if validation fails.
    """
    _validate(data, schema, "input")


def validate_output(data: Any, schema: dict[str, Any]) -> None:
    """Validate output data against the agent's output_schema.

    Raises ValidationError if validation fails.
    """
    _validate(data, schema, "output")


def _validate(data: Any, schema: dict[str, Any], label: str) -> None:
    """Run JSON Schema validation and collect all errors."""
    if not schema:
        return  # No schema to validate against

    validator = jsonschema.Draft7Validator(schema)
    errors = sorted(validator.iter_errors(data), key=lambda e: list(e.path))

    if errors:
        messages = []
        for error in errors:
            path = ".".join(str(p) for p in error.absolute_path) or "(root)"
            messages.append(f"{label}.{path}: {error.message}")
        raise ValidationError(messages)
