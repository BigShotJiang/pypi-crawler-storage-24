"""HTTP client for the Cited Agents platform API."""

from __future__ import annotations

from typing import Any

import httpx

from .config import get_config


class PlatformError(Exception):
    """Raised when the platform API returns an error."""

    def __init__(self, status_code: int, message: str) -> None:
        self.status_code = status_code
        self.message = message
        super().__init__(f"Platform API error ({status_code}): {message}")


class AgentNotFoundError(PlatformError):
    pass


def fetch_blueprint(slug: str, version: str | None = None) -> dict[str, Any]:
    """Fetch the agent blueprint from the platform API.

    Returns the full blueprint JSON including spawn_protocol, runtime, examples,
    input_schema, output_schema, etc.
    """
    config = get_config()
    url = config.blueprint_url(slug, version)

    with httpx.Client(timeout=30.0, follow_redirects=True) as client:
        resp = client.get(url)

    if resp.status_code == 404:
        version_str = f"@{version}" if version else ""
        raise AgentNotFoundError(404, f"Agent '{slug}{version_str}' not found")

    if resp.status_code != 200:
        raise PlatformError(resp.status_code, resp.text)

    return resp.json()


def search_agents(
    query: str | None = None,
    tag: str | None = None,
    limit: int = 10,
) -> dict[str, Any]:
    """Search the agent catalog."""
    config = get_config()
    url = config.search_url()

    params: dict[str, str | int] = {"limit": limit}
    if query:
        params["q"] = query
    if tag:
        params["tag"] = tag

    with httpx.Client(timeout=30.0, follow_redirects=True) as client:
        resp = client.get(url, params=params)

    if resp.status_code != 200:
        raise PlatformError(resp.status_code, resp.text)

    return resp.json()


def download_wheel(url: str, dest: str) -> None:
    """Download a wheel file from a URL to a local path."""
    with httpx.Client(timeout=120.0, follow_redirects=True) as client:
        with client.stream("GET", url) as resp:
            resp.raise_for_status()
            with open(dest, "wb") as f:
                for chunk in resp.iter_bytes(chunk_size=8192):
                    f.write(chunk)
