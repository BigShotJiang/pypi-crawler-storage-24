"""Configuration management for cited CLI."""

from __future__ import annotations

import os
from pathlib import Path
from dataclasses import dataclass, field


DEFAULT_API_URL = "https://www.citedagents.com"
DEFAULT_CACHE_DIR = Path.home() / ".cited-agents"


@dataclass
class Config:
    """CLI configuration, loaded from env vars and config file."""

    api_url: str = field(default_factory=lambda: os.environ.get("CITED_API_URL", DEFAULT_API_URL))
    cache_dir: Path = field(default_factory=lambda: Path(os.environ.get("CITED_CACHE_DIR", str(DEFAULT_CACHE_DIR))))

    def __post_init__(self) -> None:
        self.cache_dir = Path(self.cache_dir)

    @property
    def cache_path(self) -> Path:
        return self.cache_dir / "cache"

    @property
    def logs_path(self) -> Path:
        return self.cache_dir / "logs"

    def ensure_dirs(self) -> None:
        """Create cache directory structure if it doesn't exist."""
        self.cache_path.mkdir(parents=True, exist_ok=True)
        self.logs_path.mkdir(parents=True, exist_ok=True)

    def blueprint_url(self, slug: str, version: str | None = None) -> str:
        """Build the blueprint API URL for an agent."""
        url = f"{self.api_url}/api/v1/agents/{slug}/blueprint"
        if version:
            url += f"?version={version}"
        return url

    def search_url(self) -> str:
        return f"{self.api_url}/api/agents"


# Global config instance
_config: Config | None = None


def get_config() -> Config:
    global _config
    if _config is None:
        _config = Config()
    return _config
