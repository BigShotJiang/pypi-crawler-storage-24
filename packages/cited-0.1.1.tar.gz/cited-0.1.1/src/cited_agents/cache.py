"""Cache management for downloaded agent packages.

Cache structure:
    ~/.science-agents/
    ├── cache/
    │   └── dfmea-agent-1.0.0-sha256abcdef/
    │       ├── blueprint.json        # cached blueprint (always present)
    │       ├── venv/                 # Python venv (wheel-installed agents only)
    │       ├── wheel/                # downloaded .whl file (wheel path only)
    │       └── <slug>/               # cloned agent source (fallback path)
    └── logs/
"""

from __future__ import annotations

import json
import hashlib
import os
import shutil
import stat
from pathlib import Path
from typing import Any

from .config import get_config


def cache_key(slug: str, version: str, content_hash: str | None) -> str:
    """Generate a cache directory name for an agent version."""
    if content_hash:
        # Use content hash for immutable cache (hash already prefixed with sha256:)
        short_hash = content_hash.replace("sha256:", "")[:12]
        return f"{slug}-{version}-{short_hash}"
    # Without content hash, use slug-version (mutable, will be overwritten)
    return f"{slug}-{version}"


def get_cache_dir(slug: str, version: str, content_hash: str | None) -> Path:
    """Get the cache directory path for an agent."""
    config = get_config()
    config.ensure_dirs()
    return config.cache_path / cache_key(slug, version, content_hash)


def is_cached(slug: str, version: str, content_hash: str | None) -> bool:
    """Check if an agent is already cached and ready to run.

    Checks for the .installed marker, which is only written after a
    successful install (pip install or fallback command).
    """
    cache_dir = get_cache_dir(slug, version, content_hash)
    return (cache_dir / ".installed").exists()


def get_cached_blueprint(slug: str, version: str, content_hash: str | None) -> dict[str, Any] | None:
    """Load the cached blueprint JSON, if it exists."""
    cache_dir = get_cache_dir(slug, version, content_hash)
    blueprint_file = cache_dir / "blueprint.json"
    if not blueprint_file.exists():
        return None
    return json.loads(blueprint_file.read_text())


def save_blueprint(slug: str, version: str, content_hash: str | None, blueprint: dict[str, Any]) -> Path:
    """Save a blueprint to the cache."""
    cache_dir = get_cache_dir(slug, version, content_hash)
    cache_dir.mkdir(parents=True, exist_ok=True)
    blueprint_file = cache_dir / "blueprint.json"
    blueprint_file.write_text(json.dumps(blueprint, indent=2))
    return cache_dir


def get_wheel_dir(slug: str, version: str, content_hash: str | None) -> Path:
    """Get/create the wheel subdirectory in the cache."""
    wheel_dir = get_cache_dir(slug, version, content_hash) / "wheel"
    wheel_dir.mkdir(parents=True, exist_ok=True)
    return wheel_dir


def get_venv_dir(slug: str, version: str, content_hash: str | None) -> Path:
    """Get the venv directory path in the cache."""
    return get_cache_dir(slug, version, content_hash) / "venv"


def verify_hash(file_path: Path, expected_hash: str) -> bool:
    """Verify SHA256 hash of a downloaded file."""
    sha256 = hashlib.sha256()
    with open(file_path, "rb") as f:
        for chunk in iter(lambda: f.read(8192), b""):
            sha256.update(chunk)
    actual = sha256.hexdigest()
    return actual == expected_hash


def list_cached() -> list[dict[str, str]]:
    """List all cached agents."""
    config = get_config()
    cache_path = config.cache_path
    if not cache_path.exists():
        return []

    entries = []
    for entry in sorted(cache_path.iterdir()):
        if entry.is_dir():
            blueprint_file = entry / "blueprint.json"
            if blueprint_file.exists():
                try:
                    bp = json.loads(blueprint_file.read_text())
                    entries.append({
                        "slug": bp.get("slug", "unknown"),
                        "version": bp.get("version", "unknown"),
                        "path": str(entry),
                        "size": _dir_size_human(entry),
                    })
                except (json.JSONDecodeError, KeyError):
                    entries.append({
                        "slug": entry.name,
                        "version": "?",
                        "path": str(entry),
                        "size": _dir_size_human(entry),
                    })
    return entries


def clear_cache(slug: str | None = None) -> int:
    """Clear cached agents. Returns number of entries removed."""
    config = get_config()
    cache_path = config.cache_path
    if not cache_path.exists():
        return 0

    removed = 0
    for entry in list(cache_path.iterdir()):
        if not entry.is_dir():
            continue
        if slug and not entry.name.startswith(slug):
            continue
        shutil.rmtree(entry, onexc=_force_remove_readonly)
        removed += 1
    return removed


def _force_remove_readonly(func, path, exc_info):
    """Handle read-only files (e.g. .git pack files on Windows)."""
    os.chmod(path, stat.S_IWRITE)
    func(path)


def _dir_size_human(path: Path) -> str:
    """Get human-readable directory size."""
    total = sum(f.stat().st_size for f in path.rglob("*") if f.is_file())
    for unit in ("B", "KB", "MB", "GB"):
        if total < 1024:
            return f"{total:.1f} {unit}"
        total /= 1024
    return f"{total:.1f} TB"
