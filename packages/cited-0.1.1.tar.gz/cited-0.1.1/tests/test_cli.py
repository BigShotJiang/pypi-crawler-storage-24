"""Tests for cited_agents.cli module."""

from unittest.mock import patch, MagicMock
from typer.testing import CliRunner

from cited_agents.cli import app, _parse_agent_ref

runner = CliRunner()


class TestParseAgentRef:
    def test_with_version(self):
        slug, version = _parse_agent_ref("dfmea-agent@1.0.0")
        assert slug == "dfmea-agent"
        assert version == "1.0.0"

    def test_without_version(self):
        slug, version = _parse_agent_ref("dfmea-agent")
        assert slug == "dfmea-agent"
        assert version is None

    def test_strips_whitespace(self):
        slug, version = _parse_agent_ref("  dfmea-agent @ 1.0.0 ")
        assert slug == "dfmea-agent"
        assert version == "1.0.0"


class TestCLICommands:
    def test_version(self):
        result = runner.invoke(app, ["version"])
        assert result.exit_code == 0
        assert "cited v" in result.output

    def test_config_show(self):
        result = runner.invoke(app, ["config", "show"])
        assert result.exit_code == 0
        assert "API URL" in result.output
        assert "Cache dir" in result.output

    def test_cache_list_empty(self):
        result = runner.invoke(app, ["cache", "list"])
        assert result.exit_code == 0

    def test_help(self):
        result = runner.invoke(app, ["--help"])
        assert result.exit_code == 0
        assert "Run cited AI agents" in result.output


class TestOutputModeFlag:
    def test_output_mode_flag_passed_to_runner(self):
        """--output-mode full is forwarded to run_agent."""
        mock_blueprint = {
            "spawn_protocol": {"run": "test-cmd", "content_hash": None},
            "runtime": {"env": []},
            "version": "1.0.0",
            "input_schema": {},
            "output_schema": {},
        }
        with (
            patch("cited_agents.cli.fetch_blueprint", return_value=mock_blueprint),
            patch("cited_agents.cli.run_agent", return_value={"ok": True}) as mock_run,
        ):
            result = runner.invoke(app, [
                "run", "test-agent@1.0.0",
                "--output-mode", "full",
            ], input='{"name": "test"}')

        # Verify output_mode was passed
        mock_run.assert_called_once()
        call_kwargs = mock_run.call_args
        assert call_kwargs.kwargs.get("output_mode") == "full"

    def test_output_mode_defaults_to_none(self):
        """Without --output-mode flag, output_mode is not passed (None)."""
        mock_blueprint = {
            "spawn_protocol": {"run": "test-cmd", "content_hash": None},
            "runtime": {"env": []},
            "version": "1.0.0",
            "input_schema": {},
            "output_schema": {},
        }
        with (
            patch("cited_agents.cli.fetch_blueprint", return_value=mock_blueprint),
            patch("cited_agents.cli.run_agent", return_value={"ok": True}) as mock_run,
        ):
            result = runner.invoke(app, [
                "run", "test-agent@1.0.0",
            ], input='{"name": "test"}')

        mock_run.assert_called_once()
        call_kwargs = mock_run.call_args
        assert call_kwargs.kwargs.get("output_mode") is None
