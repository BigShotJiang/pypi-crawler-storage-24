"""Tests for cited_agents.runner module."""

from __future__ import annotations

import json
import subprocess
from pathlib import Path
from unittest.mock import MagicMock, patch, PropertyMock

import pytest

from cited_agents.runner import (
    run_agent,
    _check_env_vars,
    _execute,
    _ensure_installed,
    RunError,
)


# --- _check_env_vars ---

class TestCheckEnvVars:
    def test_no_vars_passes(self):
        """No env vars defined → no error."""
        _check_env_vars([])

    def test_optional_vars_ignored(self, monkeypatch):
        """Optional (required=False) vars don't raise even if absent."""
        monkeypatch.delenv("SOME_OPTIONAL_VAR", raising=False)
        _check_env_vars([{"name": "SOME_OPTIONAL_VAR", "required": False}])

    def test_required_var_present_passes(self, monkeypatch):
        """Required var that IS set → no error."""
        monkeypatch.setenv("MY_KEY", "value123")
        _check_env_vars([{"name": "MY_KEY", "required": True}])

    def test_required_var_missing_raises(self, monkeypatch):
        """Required var that is NOT set → RunError."""
        monkeypatch.delenv("MISSING_KEY", raising=False)
        with pytest.raises(RunError, match="Missing required environment variables"):
            _check_env_vars([{"name": "MISSING_KEY", "required": True}])

    def test_missing_var_message_includes_name(self, monkeypatch):
        """Error message includes the variable name."""
        monkeypatch.delenv("ANTHROPIC_API_KEY", raising=False)
        with pytest.raises(RunError, match="ANTHROPIC_API_KEY"):
            _check_env_vars([
                {"name": "ANTHROPIC_API_KEY", "required": True, "description": "API key"},
            ])

    def test_multiple_missing_vars(self, monkeypatch):
        """All missing required vars are listed."""
        monkeypatch.delenv("KEY_A", raising=False)
        monkeypatch.delenv("KEY_B", raising=False)
        with pytest.raises(RunError) as exc_info:
            _check_env_vars([
                {"name": "KEY_A", "required": True},
                {"name": "KEY_B", "required": True},
            ])
        assert "KEY_A" in str(exc_info.value)
        assert "KEY_B" in str(exc_info.value)

    def test_mixed_required_optional(self, monkeypatch):
        """Only required vars that are missing cause errors."""
        monkeypatch.setenv("PRESENT_KEY", "ok")
        monkeypatch.delenv("ABSENT_KEY", raising=False)
        # optional absent → fine, required present → fine
        _check_env_vars([
            {"name": "ABSENT_KEY", "required": False},
            {"name": "PRESENT_KEY", "required": True},
        ])


# --- _execute ---

class TestExecute:
    def _make_cache_dir(self, tmp_path: Path, with_venv: bool = True) -> Path:
        """Create a fake cache directory structure.

        _execute now receives cache_dir and auto-detects venv/source dirs.
        """
        import sys
        cache_dir = tmp_path / "cache"
        cache_dir.mkdir(parents=True)
        if with_venv:
            venv_dir = cache_dir / "venv"
            if sys.platform == "win32":
                bin_dir = venv_dir / "Scripts"
            else:
                bin_dir = venv_dir / "bin"
            bin_dir.mkdir(parents=True)
        return cache_dir

    def test_success_returns_parsed_json(self, tmp_path):
        """Successful agent run returns parsed JSON from stdout."""
        cache_dir = self._make_cache_dir(tmp_path)
        output_data = {"result": "ok", "score": 42}
        mock_result = subprocess.CompletedProcess(
            args="test-cmd",
            returncode=0,
            stdout=json.dumps(output_data),
            stderr="",
        )
        with patch("cited_agents.runner.subprocess.run", return_value=mock_result):
            result = _execute(cache_dir, "test-cmd", {"input": "data"})
        assert result == output_data

    def test_timeout_raises(self, tmp_path):
        """TimeoutExpired → RunError with timeout message."""
        cache_dir = self._make_cache_dir(tmp_path)
        with patch(
            "cited_agents.runner.subprocess.run",
            side_effect=subprocess.TimeoutExpired(cmd="test-cmd", timeout=600),
        ):
            with pytest.raises(RunError, match="timed out"):
                _execute(cache_dir, "test-cmd", {"input": "data"})

    def test_nonzero_exit_raises(self, tmp_path):
        """Non-zero exit code → RunError."""
        cache_dir = self._make_cache_dir(tmp_path)
        mock_result = subprocess.CompletedProcess(
            args="test-cmd",
            returncode=1,
            stdout="",
            stderr="something went wrong",
        )
        with patch("cited_agents.runner.subprocess.run", return_value=mock_result):
            with pytest.raises(RunError, match="exited with code 1"):
                _execute(cache_dir, "test-cmd", {})

    def test_empty_stdout_raises(self, tmp_path):
        """Empty stdout → RunError."""
        cache_dir = self._make_cache_dir(tmp_path)
        mock_result = subprocess.CompletedProcess(
            args="test-cmd",
            returncode=0,
            stdout="",
            stderr="",
        )
        with patch("cited_agents.runner.subprocess.run", return_value=mock_result):
            with pytest.raises(RunError, match="no output"):
                _execute(cache_dir, "test-cmd", {})

    def test_invalid_json_stdout_raises(self, tmp_path):
        """Non-JSON stdout → RunError with preview."""
        cache_dir = self._make_cache_dir(tmp_path)
        mock_result = subprocess.CompletedProcess(
            args="test-cmd",
            returncode=0,
            stdout="this is not json {{{",
            stderr="",
        )
        with patch("cited_agents.runner.subprocess.run", return_value=mock_result):
            with pytest.raises(RunError, match="not valid JSON"):
                _execute(cache_dir, "test-cmd", {})

    def test_input_data_sent_as_json_stdin(self, tmp_path):
        """Verify input_data is serialized to JSON and passed as stdin."""
        cache_dir = self._make_cache_dir(tmp_path)
        input_data = {"system_name": "Brake System"}
        captured_input = {}

        def mock_run(cmd, *, input=None, **kwargs):
            captured_input["stdin"] = input
            return subprocess.CompletedProcess(
                args=cmd, returncode=0, stdout='{"ok": true}', stderr=""
            )

        with patch("cited_agents.runner.subprocess.run", side_effect=mock_run):
            _execute(cache_dir, "test-cmd", input_data)
        assert json.loads(captured_input["stdin"]) == input_data


# --- _ensure_installed ---

class TestEnsureInstalled:
    def test_uses_cache_when_available(self, tmp_path):
        """When is_cached returns True, returns cached cache_dir without downloading."""
        cache_dir = tmp_path / "cached"
        with (
            patch("cited_agents.runner.cache.is_cached", return_value=True),
            patch("cited_agents.runner.cache.get_cache_dir", return_value=cache_dir),
        ):
            result = _ensure_installed(
                "test-agent", "1.0.0", "sha256:abc123",
                {"run": "test-agent", "package_url": "https://example.com/a.whl"},
                {},
            )
        assert result == cache_dir

    def test_downloads_wheel_when_package_url(self, tmp_path):
        """When not cached and package_url exists, downloads and installs wheel."""
        cache_dir = tmp_path / "bp"
        cache_dir.mkdir(parents=True)
        venv_dir = tmp_path / "new-venv"
        wheel_dir = tmp_path / "wheels"
        wheel_dir.mkdir(parents=True)

        spawn = {
            "package_url": "https://example.com/agent-1.0.0.whl",
            "content_hash": "sha256:abcdef",
            "run": "test-agent",
        }

        with (
            patch("cited_agents.runner.cache.is_cached", return_value=False),
            patch("cited_agents.runner.cache.get_venv_dir", return_value=venv_dir),
            patch("cited_agents.runner.cache.save_blueprint", return_value=cache_dir),
            patch("cited_agents.runner.cache.get_wheel_dir", return_value=wheel_dir),
            patch("cited_agents.runner.cache.verify_hash", return_value=True),
            patch("cited_agents.runner.client.download_wheel") as mock_dl,
            patch("cited_agents.runner.venv.create"),
            patch("cited_agents.runner._run_pip") as mock_pip,
        ):
            result = _ensure_installed("test-agent", "1.0.0", "sha256:abcdef", spawn, {})

        assert result == cache_dir
        mock_dl.assert_called_once()
        mock_pip.assert_called_once()
        assert (cache_dir / ".installed").exists()

    def test_hash_mismatch_raises(self, tmp_path):
        """When wheel hash doesn't match → RunError."""
        venv_dir = tmp_path / "new-venv"
        wheel_dir = tmp_path / "wheels"
        wheel_dir.mkdir(parents=True)

        spawn = {
            "package_url": "https://example.com/agent.whl",
            "content_hash": "sha256:expected_hash",
            "run": "test-agent",
        }

        with (
            patch("cited_agents.runner.cache.is_cached", return_value=False),
            patch("cited_agents.runner.cache.get_venv_dir", return_value=venv_dir),
            patch("cited_agents.runner.cache.save_blueprint", return_value=tmp_path / "bp"),
            patch("cited_agents.runner.cache.get_wheel_dir", return_value=wheel_dir),
            patch("cited_agents.runner.cache.verify_hash", return_value=False),
            patch("cited_agents.runner.client.download_wheel"),
            patch("cited_agents.runner.venv.create"),
        ):
            with pytest.raises(RunError, match="hash mismatch"):
                _ensure_installed("test-agent", "1.0.0", "sha256:expected_hash", spawn, {})

    def test_no_package_url_uses_fallback(self, tmp_path):
        """When no package_url, uses fallback install command directly (no venv)."""
        cache_dir = tmp_path / "bp"
        cache_dir.mkdir(parents=True)

        spawn = {
            "install": "",
            "run": "python src/main.py",
            "fallback": {
                "install": "git clone https://github.com/test/repo agent && cd agent && pip install -r requirements.txt",
                "run": "python src/main.py",
            },
        }

        with (
            patch("cited_agents.runner.cache.is_cached", return_value=False),
            patch("cited_agents.runner.cache.save_blueprint", return_value=cache_dir),
            patch("cited_agents.runner._run_shell_in_dir") as mock_shell,
        ):
            result = _ensure_installed("test-agent", "1.0.0", None, spawn, {})

        assert result == cache_dir
        mock_shell.assert_called_once()
        assert (cache_dir / ".installed").exists()

    def test_no_install_method_raises(self, tmp_path):
        """When no package_url AND no install command → RunError."""
        cache_dir = tmp_path / "bp"
        spawn = {"run": "test-agent"}

        with (
            patch("cited_agents.runner.cache.is_cached", return_value=False),
            patch("cited_agents.runner.cache.save_blueprint", return_value=cache_dir),
        ):
            with pytest.raises(RunError, match="No install method"):
                _ensure_installed("test-agent", "1.0.0", None, spawn, {})


# --- run_agent (integration) ---

class TestRunAgent:
    def test_skip_validation_bypasses_checks(self, monkeypatch):
        """skip_validation=True skips both input and output validation."""
        monkeypatch.setenv("ANTHROPIC_API_KEY", "test-key")
        blueprint = {
            "spawn_protocol": {"run": "test-agent", "content_hash": None},
            "runtime": {"env": [{"name": "ANTHROPIC_API_KEY", "required": True}]},
            "version": "1.0.0",
            "input_schema": {"type": "object", "required": ["missing_field"]},
            "output_schema": {"type": "object", "required": ["also_missing"]},
        }
        mock_cache_dir = Path("/fake/cache")
        output_data = {"unexpected": "output"}

        with (
            patch("cited_agents.runner._ensure_installed", return_value=mock_cache_dir),
            patch("cited_agents.runner._execute", return_value=output_data),
        ):
            # With skip_validation, input missing 'missing_field' should still work
            result = run_agent("test", None, {}, blueprint, skip_validation=True)
        assert result == output_data

    def test_missing_env_var_fails_before_install(self, monkeypatch):
        """Missing required env var raises RunError before anything else."""
        monkeypatch.delenv("REQUIRED_VAR", raising=False)
        blueprint = {
            "spawn_protocol": {"run": "test-agent"},
            "runtime": {"env": [{"name": "REQUIRED_VAR", "required": True}]},
        }
        with pytest.raises(RunError, match="Missing required"):
            run_agent("test", None, {}, blueprint)

    def test_invalid_input_fails_before_install(self, monkeypatch):
        """Invalid input raises RunError before installation."""
        monkeypatch.setenv("ANTHROPIC_API_KEY", "key")
        blueprint = {
            "spawn_protocol": {"run": "test-agent", "content_hash": None},
            "runtime": {"env": [{"name": "ANTHROPIC_API_KEY", "required": True}]},
            "version": "1.0.0",
            "input_schema": {
                "type": "object",
                "properties": {"name": {"type": "string"}},
                "required": ["name"],
            },
        }
        with pytest.raises(RunError, match="Input validation failed"):
            run_agent("test", None, {}, blueprint)  # empty input, 'name' required

    def test_no_run_command_raises(self, monkeypatch):
        """Empty spawn_protocol.run raises RunError."""
        monkeypatch.setenv("ANTHROPIC_API_KEY", "key")
        blueprint = {
            "spawn_protocol": {"run": "", "content_hash": None},
            "runtime": {"env": [{"name": "ANTHROPIC_API_KEY", "required": True}]},
            "version": "1.0.0",
            "input_schema": {},
        }
        mock_cache_dir = Path("/fake/cache")
        with patch("cited_agents.runner._ensure_installed", return_value=mock_cache_dir):
            with pytest.raises(RunError, match="no spawn_protocol.run"):
                run_agent("test", None, {}, blueprint, skip_validation=True)


class TestOutputModeInjection:
    def test_default_output_mode_is_data(self, monkeypatch):
        """run_agent injects _output_mode='data' by default."""
        monkeypatch.setenv("ANTHROPIC_API_KEY", "test-key")
        blueprint = {
            "spawn_protocol": {"run": "test-cmd", "content_hash": None},
            "runtime": {"env": [{"name": "ANTHROPIC_API_KEY", "required": True}]},
            "version": "1.0.0",
            "input_schema": {},
            "output_schema": {},
        }
        captured = {}

        def mock_execute(cache_dir, run_cmd, input_data):
            captured["input"] = input_data.copy()
            return {"ok": True}

        with (
            patch("cited_agents.runner._ensure_installed", return_value=Path("/fake")),
            patch("cited_agents.runner._execute", side_effect=mock_execute),
        ):
            run_agent("test", None, {"name": "x"}, blueprint, skip_validation=True)

        assert captured["input"]["_output_mode"] == "data"

    def test_output_mode_full_when_specified(self, monkeypatch):
        """run_agent injects _output_mode='full' when output_mode='full'."""
        monkeypatch.setenv("ANTHROPIC_API_KEY", "test-key")
        blueprint = {
            "spawn_protocol": {"run": "test-cmd", "content_hash": None},
            "runtime": {"env": [{"name": "ANTHROPIC_API_KEY", "required": True}]},
            "version": "1.0.0",
            "input_schema": {},
            "output_schema": {},
        }
        captured = {}

        def mock_execute(cache_dir, run_cmd, input_data):
            captured["input"] = input_data.copy()
            return {"ok": True}

        with (
            patch("cited_agents.runner._ensure_installed", return_value=Path("/fake")),
            patch("cited_agents.runner._execute", side_effect=mock_execute),
        ):
            run_agent("test", None, {"name": "x"}, blueprint, skip_validation=True, output_mode="full")

        assert captured["input"]["_output_mode"] == "full"

    def test_user_output_mode_respected_when_no_override(self, monkeypatch):
        """If input already has _output_mode and no explicit override, user value is kept."""
        monkeypatch.setenv("ANTHROPIC_API_KEY", "test-key")
        blueprint = {
            "spawn_protocol": {"run": "test-cmd", "content_hash": None},
            "runtime": {"env": [{"name": "ANTHROPIC_API_KEY", "required": True}]},
            "version": "1.0.0",
            "input_schema": {},
            "output_schema": {},
        }
        captured = {}

        def mock_execute(cache_dir, run_cmd, input_data):
            captured["input"] = input_data.copy()
            return {"ok": True}

        with (
            patch("cited_agents.runner._ensure_installed", return_value=Path("/fake")),
            patch("cited_agents.runner._execute", side_effect=mock_execute),
        ):
            # User explicitly set _output_mode in their input, no CLI override
            run_agent("test", None, {"name": "x", "_output_mode": "full"}, blueprint, skip_validation=True)

        assert captured["input"]["_output_mode"] == "full"
