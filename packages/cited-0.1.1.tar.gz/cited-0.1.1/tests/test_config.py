"""Tests for cited_agents.config module."""

from pathlib import Path

from cited_agents.config import Config


class TestConfig:
    def test_default_api_url(self, monkeypatch):
        monkeypatch.delenv("CITED_API_URL", raising=False)
        config = Config()
        assert config.api_url == "https://www.citedagents.com"

    def test_custom_api_url(self, monkeypatch):
        monkeypatch.setenv("CITED_API_URL", "https://custom.example.com")
        config = Config()
        assert config.api_url == "https://custom.example.com"

    def test_custom_cache_dir(self, monkeypatch):
        monkeypatch.setenv("CITED_CACHE_DIR", "/tmp/custom-cache")
        config = Config()
        assert config.cache_dir == Path("/tmp/custom-cache")

    def test_cache_path(self, tmp_path):
        config = Config(cache_dir=tmp_path)
        assert config.cache_path == tmp_path / "cache"

    def test_logs_path(self, tmp_path):
        config = Config(cache_dir=tmp_path)
        assert config.logs_path == tmp_path / "logs"

    def test_blueprint_url_without_version(self):
        config = Config(api_url="https://example.com")
        url = config.blueprint_url("dfmea-agent")
        assert url == "https://example.com/api/v1/agents/dfmea-agent/blueprint"

    def test_blueprint_url_with_version(self):
        config = Config(api_url="https://example.com")
        url = config.blueprint_url("dfmea-agent", "1.0.0")
        assert url == "https://example.com/api/v1/agents/dfmea-agent/blueprint?version=1.0.0"

    def test_search_url(self):
        config = Config(api_url="https://example.com")
        assert config.search_url() == "https://example.com/api/agents"

    def test_ensure_dirs(self, tmp_path):
        config = Config(cache_dir=tmp_path / "new-dir")
        config.ensure_dirs()
        assert config.cache_path.exists()
        assert config.logs_path.exists()
