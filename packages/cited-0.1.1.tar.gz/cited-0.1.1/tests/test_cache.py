"""Tests for cited_agents.cache module."""

import json
import hashlib
from pathlib import Path

import pytest

from cited_agents import cache


class TestCacheKey:
    def test_with_content_hash(self):
        key = cache.cache_key("dfmea-agent", "1.0.0", "sha256:abcdef123456789")
        assert key == "dfmea-agent-1.0.0-abcdef123456"

    def test_without_content_hash(self):
        key = cache.cache_key("dfmea-agent", "1.0.0", None)
        assert key == "dfmea-agent-1.0.0"

    def test_truncates_hash_to_12_chars(self):
        key = cache.cache_key("agent", "1.0.0", "sha256:aabbccddeeff00112233")
        assert key == "agent-1.0.0-aabbccddeeff"


class TestIsCached:
    def test_false_when_dir_missing(self, mock_config):
        assert cache.is_cached("nonexistent", "1.0.0", None) is False

    def test_false_when_no_marker(self, mock_config):
        """Cache dir exists but no .installed marker → not cached."""
        cache_dir = cache.get_cache_dir("test", "1.0.0", None)
        cache_dir.mkdir(parents=True)
        (cache_dir / "blueprint.json").write_text("{}")
        (cache_dir / "venv").mkdir()
        assert cache.is_cached("test", "1.0.0", None) is False

    def test_false_when_source_dir_but_no_marker(self, mock_config):
        """Source dir created by git clone but install failed → not cached."""
        cache_dir = cache.get_cache_dir("test", "1.0.0", None)
        cache_dir.mkdir(parents=True)
        (cache_dir / "test-agent").mkdir()
        (cache_dir / "blueprint.json").write_text("{}")
        assert cache.is_cached("test", "1.0.0", None) is False

    def test_true_when_marker_exists(self, mock_config):
        """Successful install leaves .installed marker → cached."""
        cache_dir = cache.get_cache_dir("test", "1.0.0", None)
        cache_dir.mkdir(parents=True)
        (cache_dir / ".installed").touch()
        assert cache.is_cached("test", "1.0.0", None) is True


class TestSaveAndGetBlueprint:
    def test_save_creates_file(self, mock_config):
        bp = {"slug": "test", "version": "1.0.0"}
        cache.save_blueprint("test", "1.0.0", None, bp)
        result = cache.get_cached_blueprint("test", "1.0.0", None)
        assert result == bp

    def test_get_returns_none_when_missing(self, mock_config):
        result = cache.get_cached_blueprint("nonexistent", "1.0.0", None)
        assert result is None


class TestVerifyHash:
    def test_matching_hash(self, tmp_path):
        content = b"hello world"
        file = tmp_path / "test.whl"
        file.write_bytes(content)
        expected = hashlib.sha256(content).hexdigest()
        assert cache.verify_hash(file, expected) is True

    def test_mismatching_hash(self, tmp_path):
        file = tmp_path / "test.whl"
        file.write_bytes(b"hello world")
        assert cache.verify_hash(file, "0000000000") is False


class TestListCached:
    def test_empty_when_no_cache(self, mock_config):
        entries = cache.list_cached()
        assert entries == []

    def test_lists_cached_entries(self, mock_config):
        bp = {"slug": "test-agent", "version": "1.0.0"}
        cache.save_blueprint("test-agent", "1.0.0", None, bp)
        entries = cache.list_cached()
        assert len(entries) == 1
        assert entries[0]["slug"] == "test-agent"
        assert entries[0]["version"] == "1.0.0"


class TestClearCache:
    def test_clear_all(self, mock_config):
        cache.save_blueprint("agent-a", "1.0.0", None, {"slug": "agent-a"})
        cache.save_blueprint("agent-b", "2.0.0", None, {"slug": "agent-b"})
        removed = cache.clear_cache()
        assert removed == 2
        assert cache.list_cached() == []

    def test_clear_by_slug(self, mock_config):
        cache.save_blueprint("agent-a", "1.0.0", None, {"slug": "agent-a"})
        cache.save_blueprint("agent-b", "2.0.0", None, {"slug": "agent-b"})
        removed = cache.clear_cache("agent-a")
        assert removed == 1
        entries = cache.list_cached()
        assert len(entries) == 1
        assert entries[0]["slug"] == "agent-b"
