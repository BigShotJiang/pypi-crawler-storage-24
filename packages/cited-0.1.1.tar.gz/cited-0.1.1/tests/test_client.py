"""Tests for cited_agents.client module."""

import pytest
import respx
import httpx

from cited_agents.client import fetch_blueprint, search_agents, download_wheel, AgentNotFoundError, PlatformError


@respx.mock
def test_fetch_blueprint_success(monkeypatch):
    monkeypatch.setenv("CITED_API_URL", "https://test.example.com")
    # Reset config cache
    import cited_agents.config
    cited_agents.config._config = None

    respx.get("https://test.example.com/api/v1/agents/dfmea-agent/blueprint").mock(
        return_value=httpx.Response(200, json={"slug": "dfmea-agent", "version": "1.0.0"})
    )
    result = fetch_blueprint("dfmea-agent")
    assert result["slug"] == "dfmea-agent"
    cited_agents.config._config = None


@respx.mock
def test_fetch_blueprint_with_version(monkeypatch):
    monkeypatch.setenv("CITED_API_URL", "https://test.example.com")
    import cited_agents.config
    cited_agents.config._config = None

    respx.get("https://test.example.com/api/v1/agents/dfmea-agent/blueprint", params={"version": "1.0.0"}).mock(
        return_value=httpx.Response(200, json={"slug": "dfmea-agent"})
    )
    result = fetch_blueprint("dfmea-agent", "1.0.0")
    assert result["slug"] == "dfmea-agent"
    cited_agents.config._config = None


@respx.mock
def test_fetch_blueprint_404(monkeypatch):
    monkeypatch.setenv("CITED_API_URL", "https://test.example.com")
    import cited_agents.config
    cited_agents.config._config = None

    respx.get("https://test.example.com/api/v1/agents/nonexistent/blueprint").mock(
        return_value=httpx.Response(404, json={"error": "not found"})
    )
    with pytest.raises(AgentNotFoundError):
        fetch_blueprint("nonexistent")
    cited_agents.config._config = None


@respx.mock
def test_fetch_blueprint_500(monkeypatch):
    monkeypatch.setenv("CITED_API_URL", "https://test.example.com")
    import cited_agents.config
    cited_agents.config._config = None

    respx.get("https://test.example.com/api/v1/agents/broken/blueprint").mock(
        return_value=httpx.Response(500, text="Internal Server Error")
    )
    with pytest.raises(PlatformError) as exc_info:
        fetch_blueprint("broken")
    assert exc_info.value.status_code == 500
    cited_agents.config._config = None


@respx.mock
def test_search_agents_with_query(monkeypatch):
    monkeypatch.setenv("CITED_API_URL", "https://test.example.com")
    import cited_agents.config
    cited_agents.config._config = None

    respx.get("https://test.example.com/api/agents").mock(
        return_value=httpx.Response(200, json={"data": [{"slug": "dfmea-agent"}], "total": 1})
    )
    result = search_agents(query="fmea", limit=5)
    assert result["total"] == 1
    cited_agents.config._config = None


@respx.mock
def test_download_wheel(tmp_path, monkeypatch):
    dest = str(tmp_path / "agent.whl")
    content = b"fake wheel content"

    respx.get("https://example.com/agent.whl").mock(
        return_value=httpx.Response(200, content=content)
    )
    download_wheel("https://example.com/agent.whl", dest)

    with open(dest, "rb") as f:
        assert f.read() == content
