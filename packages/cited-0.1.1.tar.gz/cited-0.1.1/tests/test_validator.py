"""Tests for cited_agents.validator module."""

import pytest

from cited_agents.validator import validate_input, validate_output, ValidationError


class TestValidateInput:
    def test_valid_data_passes(self, sample_input_schema):
        data = {"system_name": "Brake System"}
        validate_input(data, sample_input_schema)  # Should not raise

    def test_missing_required_field_fails(self, sample_input_schema):
        data = {}  # missing system_name
        with pytest.raises(ValidationError) as exc_info:
            validate_input(data, sample_input_schema)
        assert any("system_name" in e for e in exc_info.value.errors)

    def test_wrong_type_fails(self, sample_input_schema):
        data = {"system_name": 123}  # should be string
        with pytest.raises(ValidationError) as exc_info:
            validate_input(data, sample_input_schema)
        assert len(exc_info.value.errors) > 0

    def test_empty_schema_passes(self):
        validate_input({"anything": "goes"}, {})  # Should not raise

    def test_collects_all_errors(self):
        schema = {
            "type": "object",
            "properties": {
                "a": {"type": "string"},
                "b": {"type": "number"},
            },
            "required": ["a", "b"],
        }
        with pytest.raises(ValidationError) as exc_info:
            validate_input({}, schema)
        assert len(exc_info.value.errors) == 2


class TestValidateOutput:
    def test_error_messages_use_output_prefix(self):
        schema = {
            "type": "object",
            "properties": {"result": {"type": "string"}},
            "required": ["result"],
        }
        with pytest.raises(ValidationError) as exc_info:
            validate_output({}, schema)
        assert any("output." in e for e in exc_info.value.errors)

    def test_nested_path_in_errors(self):
        schema = {
            "type": "object",
            "properties": {
                "entries": {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {"name": {"type": "string"}},
                        "required": ["name"],
                    },
                },
            },
        }
        data = {"entries": [{"name": 123}]}  # name should be string
        with pytest.raises(ValidationError) as exc_info:
            validate_output(data, schema)
        assert any("entries" in e for e in exc_info.value.errors)
