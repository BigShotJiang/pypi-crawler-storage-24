"""Configuration for Jira Service Desk MCP server."""

from __future__ import annotations

import base64
import logging
import os
from dataclasses import dataclass

logger = logging.getLogger(__name__)

_CLOUD_DOMAINS = (".atlassian.net", ".jira.com")


def _is_cloud_url(url: str) -> bool:
    """Heuristic: Atlassian Cloud URLs contain known domain suffixes."""
    lower = url.lower().rstrip("/")
    return any(lower.endswith(d) or f"{d}/" in lower for d in _CLOUD_DOMAINS)


def _try_decode_basic_token(token: str) -> tuple[str, str] | None:
    """Try to decode a base64-encoded ``username:password`` token.

    Returns ``(username, password)`` on success, ``None`` otherwise.
    """
    try:
        decoded = base64.b64decode(token, validate=True).decode("utf-8")
    except Exception:
        return None
    if ":" not in decoded:
        return None
    username, password = decoded.split(":", 1)
    if username and password:
        return username, password
    return None


def _normalize_bearer_token(token: str) -> tuple[str, bool]:
    """Strip an optional ``Bearer`` prefix from a raw PAT value."""
    stripped = token.strip()
    prefix = "bearer "
    if stripped.lower().startswith(prefix):
        return stripped[len(prefix):].strip(), True
    return stripped, False


@dataclass(frozen=True)
class ServiceDeskConfig:
    """Configuration loaded from environment variables."""

    url: str
    auth_type: str  # "token", "pat", "basic"
    username: str | None = None
    api_token: str | None = None
    personal_token: str | None = None
    password: str | None = None
    is_cloud: bool = True
    ssl_verify: bool = True
    read_only: bool = False

    @classmethod
    def from_env(cls) -> ServiceDeskConfig:
        url = os.environ.get("JIRA_URL", "").rstrip("/")
        if not url:
            raise ValueError(
                "JIRA_URL environment variable is required. "
                "Set it to your Jira instance URL (e.g. https://your-instance.atlassian.net)"
            )

        username = os.environ.get("JIRA_USERNAME")
        api_token = os.environ.get("JIRA_API_TOKEN")
        personal_token = os.environ.get("JIRA_PERSONAL_TOKEN")
        password = os.environ.get("JIRA_PASSWORD")
        ssl_verify = os.environ.get("JIRA_SSL_VERIFY", "true").lower() in ("true", "1", "yes")
        read_only = os.environ.get("READ_ONLY_MODE", "false").lower() in ("true", "1", "yes")

        is_cloud_env = os.environ.get("JIRA_IS_CLOUD")
        if is_cloud_env is not None:
            is_cloud = is_cloud_env.lower() in ("true", "1", "yes")
        else:
            is_cloud = _is_cloud_url(url)
            logger.debug(
                "JIRA_IS_CLOUD not set, auto-detected %s for %s",
                is_cloud, url,
            )

        if personal_token:
            normalized_token, had_bearer_prefix = _normalize_bearer_token(personal_token)
            if had_bearer_prefix:
                auth_type = "pat"
                personal_token = normalized_token
            else:
                decoded = _try_decode_basic_token(normalized_token)
                if decoded is not None:
                    logger.debug("JIRA_PERSONAL_TOKEN decoded as base64 basic auth credentials")
                    username, password = decoded
                    auth_type = "basic"
                else:
                    auth_type = "pat"
                    personal_token = normalized_token
        elif username and api_token:
            auth_type = "token"
        elif username and password:
            auth_type = "basic"
        else:
            raise ValueError(
                "Authentication not configured. Provide one of:\n"
                "  - JIRA_USERNAME + JIRA_API_TOKEN (Cloud)\n"
                "  - JIRA_PERSONAL_TOKEN (recommended shared MCP config — raw PAT or base64 username:token)\n"
                "  - JIRA_USERNAME + JIRA_PASSWORD (basic auth)"
            )

        return cls(
            url=url,
            auth_type=auth_type,
            username=username,
            api_token=api_token,
            personal_token=personal_token if auth_type == "pat" else None,
            password=password if auth_type == "basic" else None,
            is_cloud=is_cloud,
            ssl_verify=ssl_verify,
            read_only=read_only,
        )
