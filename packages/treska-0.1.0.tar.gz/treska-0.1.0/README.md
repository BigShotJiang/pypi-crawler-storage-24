# Treska — CTF Parser

Part of the Megdan CTF Line.

Treska is a fast forensic parser for zipped logical extractions in CTF competitions.

> Placeholder release — full build coming soon.

## Megdan CTF Line

| Package | Role |
|---|---|
| **Phalanx** | CTF dashboard |
| **Treska** | CTF parser |
| **Poligon** | Practice simulator |

## Author

GitHub: [ShadowStrike-CTF](https://github.com/ShadowStrike-CTF)
