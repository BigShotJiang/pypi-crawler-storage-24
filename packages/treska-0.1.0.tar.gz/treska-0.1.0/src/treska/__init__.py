# Treska — CTF Parser
# ShadowStrike — Part of the Megdan CTF Line.
# Placeholder release — full build coming soon.
__version__ = "0.1.0"
