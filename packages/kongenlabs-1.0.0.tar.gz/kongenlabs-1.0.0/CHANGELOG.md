# Changelog

All notable changes to the Kongen SDK will be documented in this file.

## [1.0.0] - 2026-03-14

### Added

- `KongenClient` — main client with API key auth and token tracking
- `ChiryuAnalyzer` — LLM reasoning regime detection via `chiryu.score()`
  - 5 regimes: reflexive, procedural, analytical, synthesis, metacognitive
  - Local heuristic pre-scoring + remote API scoring
  - Cross-domain boost factor from UAF pattern corpus
- `TransferScorer` — cross-domain structural pattern scoring
  - `transfer.score_signal()` — single signature scoring (50 KT)
  - `transfer.score_batch()` — batch scoring at 40 KT/signal
  - Structural classification into 7 universal pattern types
- `MCP` integration via `mcp.list_tools()` and `mcp.call_tool()`
- Token usage tracking via `client.token_usage`
- Error hierarchy: `KongenError`, `APIError`, `AuthenticationError`, `TokensExhaustedError`, `RateLimitError`
- Type-safe Pydantic response models
- Environment-based config: `KONGEN_API_KEY`, `KONGEN_API_BASE_URL`
