"""Kongen Labs SCI Pattern Intelligence SDK.

Cross-domain pattern transfer and LLM reasoning regime detection
powered by Turing's reaction-diffusion morphogenetic framework.

Usage::

    from kongen import KongenClient

    client = KongenClient(api_key="kl_live_...")
    result = client.chiryu.score("Prove sqrt(2) is irrational")
    print(result.regime, result.boost_factor)
"""

from kongen.chiryu import ChiryuAnalyzer
from kongen.client import KongenClient
from kongen.exceptions import (
    APIError,
    AuthenticationError,
    KongenError,
    RateLimitError,
    TokensExhaustedError,
)
from kongen.transfer import TransferScorer
from kongen.types import (
    BatchTransferResult,
    ChiryuResult,
    StructuralSignature,
    TokenUsage,
    TransferResult,
)

__version__ = "1.0.0"
__all__ = [
    # Core client
    "KongenClient",
    # Sub-clients
    "ChiryuAnalyzer",
    "TransferScorer",
    # Types
    "ChiryuResult",
    "TransferResult",
    "BatchTransferResult",
    "StructuralSignature",
    "TokenUsage",
    # Exceptions
    "KongenError",
    "AuthenticationError",
    "RateLimitError",
    "TokensExhaustedError",
    "APIError",
]
