"""Pydantic models for Kongen API request and response types."""

from __future__ import annotations

from pydantic import BaseModel, Field


class StructuralSignature(BaseModel):
    """UAF structural signature representing a domain-agnostic pattern.

    All fields are normalized floats derived from Turing's reaction-diffusion
    equations. The activator/inhibitor ratio (a_i_ratio) is the primary
    discriminator for pattern classification.
    """

    activator_strength: float = Field(
        ..., description="Strength of the activating force (growth, expansion)."
    )
    inhibitor_strength: float = Field(
        ..., description="Strength of the inhibiting force (boundaries, suppression)."
    )
    boundary_strength: float = Field(
        ..., description="Sharpness of boundary formation between regions."
    )
    scale_coherence: float = Field(
        ..., description="Consistency of pattern across multiple scales."
    )
    field_magnitude: float = Field(
        ..., description="Overall magnitude of the morphogenetic field."
    )
    a_i_ratio: float = Field(
        ..., description="Activator-to-inhibitor ratio. Goldilocks zone: 0.55-0.70."
    )
    gradient_strength: float = Field(
        ..., description="Strength of spatial/temporal gradient in the field."
    )


class ChiryuResult(BaseModel):
    """Result from Chiryu LLM reasoning regime detection.

    The regime indicates the reasoning complexity class, and the boost_factor
    provides a confidence adjustment for downstream scoring.
    """

    regime: str = Field(
        ...,
        description=(
            "Detected reasoning regime: "
            "'trivial', 'fast', 'moderate', 'deep', or 'exhaustive'."
        ),
    )
    boost_factor: float = Field(
        ..., description="Confidence adjustment factor in [-0.2, +0.3]."
    )
    activator_strength: float = Field(
        default=0.0, description="Activator strength from token analysis."
    )
    inhibitor_strength: float = Field(
        default=0.0, description="Inhibitor strength from token analysis."
    )
    a_i_ratio: float = Field(
        default=0.0, description="Activator-to-inhibitor ratio."
    )
    recommended_tokens: int = Field(
        default=0, description="Recommended max_tokens for this prompt's complexity."
    )
    tokens_used: int = Field(..., description="Kongen Tokens consumed by this call.")
    tokens_remaining: int = Field(
        ..., description="Kongen Tokens remaining in current billing period."
    )
    request_id: str = Field(
        default="", description="Unique request identifier."
    )
    watermark: str = Field(
        default="", description="Response watermark for provenance tracking."
    )


class TransferResult(BaseModel):
    """Result from cross-domain pattern transfer scoring.

    Classification follows the 7 Universal Pattern Types defined by the
    SCI framework (e.g., BOUNDARY_FORMATION, OVEREXTENSION_VULNERABILITY).
    """

    classification: str = Field(
        ...,
        description=(
            "Universal pattern classification: "
            "'OVEREXTENSION_VULNERABILITY', 'BOUNDARY_FORMATION', "
            "'ACTIVATOR_DOMINANCE', 'INHIBITOR_CONSOLIDATION', "
            "'SCALE_COHERENCE', 'COMPETITIVE_SELECTION', or 'MIXED_FLEXIBILITY'."
        ),
    )
    confidence: float = Field(
        ..., ge=0.0, le=1.0, description="Classification confidence in [0.0, 1.0]."
    )
    boost_factor: float = Field(
        ..., description="Cross-domain confidence adjustment in [-0.2, +0.3]."
    )
    cross_domain_evidence: list[dict[str, object]] = Field(
        default_factory=list,
        description="Supporting evidence from other organism domains.",
    )
    tokens_used: int = Field(..., description="Kongen Tokens consumed by this call.")
    tokens_remaining: int = Field(
        ..., description="Kongen Tokens remaining in current billing period."
    )
    request_id: str = Field(
        default="", description="Unique request identifier."
    )
    watermark: str = Field(
        default="", description="Response watermark for provenance tracking."
    )

    @property
    def evidence(self) -> list[dict[str, object]]:
        """Alias for cross_domain_evidence."""
        return self.cross_domain_evidence


class BatchTransferResult(BaseModel):
    """Result from batch cross-domain pattern transfer scoring."""

    results: list[TransferResult] = Field(
        ..., description="Individual transfer results for each input signature."
    )
    total_tokens_used: int = Field(
        ..., description="Total Kongen Tokens consumed by the batch."
    )
    tokens_remaining: int = Field(
        ..., description="Kongen Tokens remaining in current billing period."
    )


class TokenUsage(BaseModel):
    """Current token usage and plan information."""

    used: int = Field(..., description="Kongen Tokens used in current billing period.")
    remaining: int = Field(
        ..., description="Kongen Tokens remaining in current billing period."
    )
    plan: str = Field(..., description="Active billing plan name.")
