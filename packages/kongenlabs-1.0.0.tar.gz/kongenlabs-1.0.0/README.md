# Kongen SDK

[![PyPI version](https://img.shields.io/pypi/v/kongen.svg)](https://pypi.org/project/kongen/)
[![Python versions](https://img.shields.io/pypi/pyversions/kongen.svg)](https://pypi.org/project/kongen/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

Python SDK for the [Kongen Labs](https://kongenlabs.life) Pattern Intelligence API -- cross-domain pattern transfer and LLM reasoning regime detection powered by morphogenetic reaction-diffusion dynamics.

## Install

```bash
pip install kongen
```

## Quick Start

```python
from kongen import KongenClient

client = KongenClient(api_key="kl_live_...")

# Chiryu: LLM reasoning regime detection (1 KT)
result = client.chiryu.score("Prove that sqrt(2) is irrational")
print(result.regime, result.boost_factor)

# Transfer: Cross-domain pattern scoring (50 KT)
result = client.transfer.score_signal({
    "activator_strength": 0.7,
    "inhibitor_strength": 0.3,
    "boundary_strength": 0.8,
    "scale_coherence": 0.6,
    "field_magnitude": 1.5,
    "a_i_ratio": 2.33,
    "gradient_strength": 0.5,
})
print(result.classification, result.confidence)
```

## Authentication

Get your API key at [garden.kongenlabs.life](https://garden.kongenlabs.life).

```python
# Pass directly
client = KongenClient(api_key="kl_live_...")

# Or set environment variable
# export KONGEN_API_KEY=kl_live_...
client = KongenClient()
```

## Batch Scoring

Score multiple signals at a discount (40 KT/signal instead of 50):

```python
signals = [
    {"activator_strength": 0.7, "inhibitor_strength": 0.3, ...},
    {"activator_strength": 0.5, "inhibitor_strength": 0.6, ...},
    {"activator_strength": 0.9, "inhibitor_strength": 0.1, ...},
]

results = client.transfer.score_batch(signals)
for r in results:
    print(f"{r.classification}: boost={r.boost_factor:.3f}")
```

## MCP Integration

Use the Kongen MCP server with LLM agents:

```python
# List available tools
tools = client.mcp.list_tools()
# Returns: chiryu_score, transfer_score, pattern_classify

# Call a tool
result = client.mcp.call_tool("chiryu_score", {
    "text": "Explain quantum entanglement"
})
```

## Error Handling

```python
from kongen import TokensExhaustedError, APIError

try:
    result = client.chiryu.score("...")
except TokensExhaustedError:
    print("Out of tokens -- add a payment method")
except APIError as e:
    print(f"API error {e.status_code}: {e.message}")
```

## Token Usage

Every API call consumes Kongen Tokens (KT). Check your balance:

```python
usage = client.token_usage
print(f"{usage.remaining} KT remaining")
```

| Endpoint | Cost |
|----------|------|
| `chiryu.score()` | 1 KT ($0.0007) |
| `transfer.score_signal()` | 50 KT ($0.035) |
| `transfer.score_batch()` | 40 KT per signal ($0.028) |
| `mcp.call_tool()` | same as REST |

## Pricing

**Pay-as-you-go.** Every account gets 5,000 free credits on signup. After that, each Kongen Token costs **$0.0007**. No subscriptions, no commitments. Billed monthly based on actual usage.

Enterprise customers can negotiate custom volume pricing -- contact sales@kongenlabs.life.

## Documentation

- [API Documentation](https://kongenlabs.life/docs)
- [Dashboard & API Keys](https://garden.kongenlabs.life)
- [Website](https://kongenlabs.life)
- [Changelog](https://github.com/kongenlabs/kongen-python/blob/main/CHANGELOG.md)

## License

MIT -- see [LICENSE](LICENSE) for details.
