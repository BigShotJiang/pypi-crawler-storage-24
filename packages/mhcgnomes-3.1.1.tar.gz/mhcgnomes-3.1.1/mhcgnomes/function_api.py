# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#       http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from typing import Optional

from .common import cache
from .parser import (
    COLLAPSE_SINGLETON_HAPLOTYPES,
    COLLAPSE_SINGLETON_SEROTYPES,
    DEFAULT_SPECIES_PREFIX,
    GENE_SEPS,
    INFER_CLASS2_PAIRING,
    USE_ALLELE_ALIASES,
    Parser,
)
from .result import Result


@cache
def cached_parser(
    use_allele_aliases: bool = USE_ALLELE_ALIASES,
    gene_seps=GENE_SEPS,
    collapse_singleton_haplotypes: bool = COLLAPSE_SINGLETON_HAPLOTYPES,
    collapse_singleton_serotypes: bool = COLLAPSE_SINGLETON_SEROTYPES,
    verbose: bool = False,
) -> Parser:
    """
    Get or create a cached Parser instance.

    Construct a Parser instance if this combination of arguments hasn't
    been used before, otherwise retrieve an existing parser from cache.

    Parameters
    ----------
    use_allele_aliases : bool
        Whether to use allele alias mappings for parsing.
    gene_seps : tuple of str
        Separator characters between gene name and allele fields.
    collapse_singleton_haplotypes : bool
        If a Haplotype contains only a single allele, return the allele
        instead of a haplotype.
    collapse_singleton_serotypes : bool
        If a Serotype contains only a single allele, return the allele
        instead of a serotype.
    verbose : bool
        Print intermediate parsing steps for debugging.

    Returns
    -------
    Parser
        A Parser instance configured with the given options.

    Examples
    --------
    >>> parser = cached_parser()
    >>> result = parser.parse("HLA-A*02:01")
    >>> result.gene_name
    'A'
    """
    return Parser(
        use_allele_aliases=use_allele_aliases,
        gene_seps=gene_seps,
        collapse_singleton_haplotypes=collapse_singleton_haplotypes,
        collapse_singleton_serotypes=collapse_singleton_serotypes,
        verbose=verbose,
    )


def parse(
    raw_string: str,
    default_species=DEFAULT_SPECIES_PREFIX,
    use_allele_aliases: bool = USE_ALLELE_ALIASES,
    infer_class2_pairing: bool = INFER_CLASS2_PAIRING,
    collapse_singleton_haplotypes: bool = COLLAPSE_SINGLETON_HAPLOTYPES,
    collapse_singleton_serotypes: bool = COLLAPSE_SINGLETON_SEROTYPES,
    max_allele_fields=None,
    required_result_types=None,
    preferred_result_types=None,
    only_class1: bool = False,
    only_class2: bool = False,
    verbose: bool = False,
    raise_on_error: bool = True,
) -> Optional[Result]:
    """
    Parse MHC alleles into a structured representation.

    Parameters
    ----------
    raw_string : str
       String corresponding to allele, locus, or other MHC-related name

    default_species : str
       By default, parse alleles like "A*02:01" as human but it's possible
       to change this to some other species.

    use_allele_aliases : bool

    infer_class2_pairing : bool
       If given only the alpha or beta chain of a Class II allele,
       try to infer the most likely pairing from population frequencies.

    collapse_singleton_haplotypes : bool
        If a Haplotype contains only a single allele or Class II allele pair,
        then return the allele instead of a haplotype.

    collapse_singleton_serotypes : bool
        If a Serotype contains only a single allele or Class II allele pair,
        then return the allele instead of a serotype.

    max_allele_fields : int
        If not None, restrict number of allele fields to given value.

    required_result_types : list of type
        Strict filter. Only return results of the given classes.

    preferred_result_types : list of type
        Prefer returning one of these classes when available.
        If none match, return the best non-preferred parse.

    only_class1 : bool
        Only return MHC Class I results

    only_class2 : bool
        Only return MHC Class II results

    verbose : bool
        Print intermediate parsing steps

    raise_on_error : bool
        Raise an exception if string can't be parsed. If False, return None
        instead.

    Returns
    -------
    Result
        A parsed MHC object, which may be an Allele, AlleleWithoutGene, Gene,
        Species, Haplotype, Serotype, Supertype, Pair, Class2Locus, or MhcClass
        depending on the input string. Returns None if parsing fails and
        raise_on_error is False.

    Raises
    ------
    ParseError
        If the string cannot be parsed and raise_on_error is True.

    Examples
    --------
    >>> from mhcgnomes import parse
    >>> allele = parse("HLA-A*02:01")
    >>> allele.gene_name
    'A'
    >>> allele.allele_fields
    ('02', '01')
    >>> allele.to_string()
    'HLA-A*02:01'
    """
    if preferred_result_types is None:
        preferred_result_types = []
    if required_result_types is None:
        required_result_types = []
    parser = cached_parser(
        use_allele_aliases=use_allele_aliases,
        collapse_singleton_haplotypes=collapse_singleton_haplotypes,
        collapse_singleton_serotypes=collapse_singleton_serotypes,
        verbose=verbose,
    )

    return parser.parse(
        raw_string,
        default_species=default_species,
        infer_class2_pairing=infer_class2_pairing,
        raise_on_error=raise_on_error,
        required_result_types=required_result_types,
        preferred_result_types=preferred_result_types,
        only_class1=only_class1,
        only_class2=only_class2,
        max_allele_fields=max_allele_fields,
    )
