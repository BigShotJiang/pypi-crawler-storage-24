#ifndef SRC_OPACITY_NITROGEN_CIA_HPP_
#define SRC_OPACITY_NITROGEN_CIA_HPP_

// C/C++
#include <string>
#include <vector>

// opacity
#include "absorber.hpp"

class N2N2CIA : public Absorber {
 public:
  N2N2CIA() : Absorber("N2-N2") {}

  virtual ~N2N2CIA() {}

  void LoadCoefficient(std::string fname, int bid) override;

  Real GetAttenuation(Real wave1, Real wave2,
                      AirParcel const& var) const override {
    Real k1 = getAttenuation1(wave1, var);
    Real k2 = getAttenuation1(wave2, var);
    return (k1 + k2) / 2.;
  }

 protected:
  Real getAttenuation1(Real wave, AirParcel const& var) const;

  size_t rt_len_[2];
  size_t fd1_len_[2];
  size_t fd2_len_[2];

  std::vector<Real> rt_axis_;
  std::vector<Real> fd1_axis_;
  std::vector<Real> fd2_axis_;
  std::vector<Real> rt_;
  std::vector<Real> fd1_;
  std::vector<Real> fd2_;
};

#endif  // SRC_OPACITY_NITROGEN_CIA_HPP_
