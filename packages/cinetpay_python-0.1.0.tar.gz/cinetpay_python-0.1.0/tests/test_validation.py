"""Tests for cinetpay.validation — payment and transfer request validation."""

from __future__ import annotations

import pytest

from cinetpay.types.payment import PaymentRequest
from cinetpay.types.transfer import TransferRequest
from cinetpay.validation import (
    ValidationError,
    validate_payment_request,
    validate_transfer_request,
)


# ---------------------------------------------------------------------------
# Helpers — valid request factories
# ---------------------------------------------------------------------------

def _valid_payment_request(**overrides) -> PaymentRequest:
    defaults = dict(
        currency="XOF",
        merchant_transaction_id="txn_001",
        amount=1000,
        lang="fr",
        designation="Achat test",
        client_email="user@example.com",
        client_first_name="Jean",
        client_last_name="Dupont",
        success_url="https://example.com/success",
        failed_url="https://example.com/failed",
        notify_url="https://example.com/notify",
        channel="PUSH",
        payment_method=None,
        client_phone_number=None,
        direct_pay=None,
        otp_code=None,
    )
    defaults.update(overrides)
    return PaymentRequest(**defaults)


def _valid_transfer_request(**overrides) -> TransferRequest:
    defaults = dict(
        currency="XOF",
        merchant_transaction_id="transfer_001",
        phone_number="+2250707000001",
        amount=5000,
        payment_method="OM_CI",
        reason="Remboursement",
        notify_url="https://example.com/notify",
    )
    defaults.update(overrides)
    return TransferRequest(**defaults)


# ---------------------------------------------------------------------------
# validate_payment_request
# ---------------------------------------------------------------------------

class TestValidatePaymentRequestValid:
    """Valid payment requests should not raise."""

    def test_minimal_valid_request(self):
        validate_payment_request(_valid_payment_request())

    def test_with_payment_method(self):
        validate_payment_request(_valid_payment_request(payment_method="OM_CI"))

    def test_with_phone_number(self):
        validate_payment_request(_valid_payment_request(client_phone_number="+2250707000001"))

    def test_with_otp_code_four_digits(self):
        validate_payment_request(_valid_payment_request(otp_code="1234"))

    def test_with_otp_code_six_digits(self):
        validate_payment_request(_valid_payment_request(otp_code="123456"))

    def test_direct_pay_with_required_fields(self):
        validate_payment_request(_valid_payment_request(
            direct_pay=True,
            client_phone_number="+2250707000001",
            payment_method="OM_CI",
        ))

    def test_all_currencies(self):
        for currency in ("XOF", "XAF", "GNF", "CDF", "USD"):
            validate_payment_request(_valid_payment_request(currency=currency))

    def test_all_channels(self):
        for channel in ("PUSH", "OTP", "QRCODE"):
            validate_payment_request(_valid_payment_request(channel=channel))

    def test_lang_en(self):
        validate_payment_request(_valid_payment_request(lang="en"))

    def test_amount_minimum(self):
        validate_payment_request(_valid_payment_request(amount=100))

    def test_amount_maximum(self):
        validate_payment_request(_valid_payment_request(amount=2_500_000))


class TestValidatePaymentCurrency:
    def test_invalid_currency(self):
        with pytest.raises(ValidationError, match="currency"):
            validate_payment_request(_valid_payment_request(currency="EUR"))

    def test_empty_currency(self):
        with pytest.raises(ValidationError, match="currency"):
            validate_payment_request(_valid_payment_request(currency=""))


class TestValidatePaymentAmount:
    def test_amount_below_minimum(self):
        with pytest.raises(ValidationError, match="amount"):
            validate_payment_request(_valid_payment_request(amount=99))

    def test_amount_above_maximum(self):
        with pytest.raises(ValidationError, match="amount"):
            validate_payment_request(_valid_payment_request(amount=2_500_001))

    def test_amount_zero(self):
        with pytest.raises(ValidationError, match="amount"):
            validate_payment_request(_valid_payment_request(amount=0))

    def test_amount_negative(self):
        with pytest.raises(ValidationError, match="amount"):
            validate_payment_request(_valid_payment_request(amount=-100))

    def test_amount_float_rejected(self):
        with pytest.raises(ValidationError, match="amount"):
            validate_payment_request(_valid_payment_request(amount=100.5))  # type: ignore[arg-type]


class TestValidatePaymentMerchantTransactionId:
    def test_empty_id(self):
        with pytest.raises(ValidationError, match="merchant_transaction_id"):
            validate_payment_request(_valid_payment_request(merchant_transaction_id=""))

    def test_too_long_id(self):
        with pytest.raises(ValidationError, match="merchant_transaction_id"):
            validate_payment_request(_valid_payment_request(merchant_transaction_id="x" * 31))

    def test_max_length_ok(self):
        validate_payment_request(_valid_payment_request(merchant_transaction_id="x" * 30))


class TestValidatePaymentEmail:
    def test_invalid_email_no_at(self):
        with pytest.raises(ValidationError, match="client_email"):
            validate_payment_request(_valid_payment_request(client_email="invalid"))

    def test_invalid_email_no_domain(self):
        with pytest.raises(ValidationError, match="client_email"):
            validate_payment_request(_valid_payment_request(client_email="user@"))

    def test_invalid_email_spaces(self):
        with pytest.raises(ValidationError, match="client_email"):
            validate_payment_request(_valid_payment_request(client_email="user @example.com"))

    def test_empty_email(self):
        with pytest.raises(ValidationError, match="client_email"):
            validate_payment_request(_valid_payment_request(client_email=""))


class TestValidatePaymentUrls:
    def test_success_url_not_http(self):
        with pytest.raises(ValidationError, match="success_url"):
            validate_payment_request(_valid_payment_request(success_url="ftp://example.com"))

    def test_failed_url_too_long(self):
        with pytest.raises(ValidationError, match="failed_url"):
            validate_payment_request(_valid_payment_request(failed_url="https://example.com/" + "x" * 120))

    def test_notify_url_empty(self):
        with pytest.raises(ValidationError, match="notify_url"):
            validate_payment_request(_valid_payment_request(notify_url=""))

    def test_success_url_http_is_ok(self):
        validate_payment_request(_valid_payment_request(success_url="http://localhost/ok"))


class TestValidatePaymentPhone:
    def test_invalid_phone_no_plus(self):
        with pytest.raises(ValidationError, match="client_phone_number"):
            validate_payment_request(_valid_payment_request(client_phone_number="2250707000001"))

    def test_invalid_phone_too_short(self):
        with pytest.raises(ValidationError, match="client_phone_number"):
            validate_payment_request(_valid_payment_request(client_phone_number="+123"))

    def test_invalid_phone_letters(self):
        with pytest.raises(ValidationError, match="client_phone_number"):
            validate_payment_request(_valid_payment_request(client_phone_number="+abc12345678"))

    def test_none_phone_is_ok(self):
        validate_payment_request(_valid_payment_request(client_phone_number=None))


class TestValidatePaymentOtp:
    def test_otp_too_short(self):
        with pytest.raises(ValidationError, match="otp_code"):
            validate_payment_request(_valid_payment_request(otp_code="123"))

    def test_otp_too_long(self):
        with pytest.raises(ValidationError, match="otp_code"):
            validate_payment_request(_valid_payment_request(otp_code="1234567"))

    def test_otp_with_letters(self):
        with pytest.raises(ValidationError, match="otp_code"):
            validate_payment_request(_valid_payment_request(otp_code="12ab"))

    def test_otp_five_digits_ok(self):
        validate_payment_request(_valid_payment_request(otp_code="12345"))


class TestValidatePaymentDirectPay:
    def test_direct_pay_without_phone(self):
        with pytest.raises(ValidationError, match="client_phone_number"):
            validate_payment_request(_valid_payment_request(
                direct_pay=True,
                payment_method="OM_CI",
                client_phone_number=None,
            ))

    def test_direct_pay_without_payment_method(self):
        with pytest.raises(ValidationError, match="payment_method"):
            validate_payment_request(_valid_payment_request(
                direct_pay=True,
                client_phone_number="+2250707000001",
                payment_method=None,
            ))

    def test_direct_pay_false_no_requirements(self):
        validate_payment_request(_valid_payment_request(direct_pay=False))


class TestValidatePaymentChannel:
    def test_invalid_channel(self):
        with pytest.raises(ValidationError, match="channel"):
            validate_payment_request(_valid_payment_request(channel="SMS"))


class TestValidatePaymentNames:
    def test_first_name_too_short(self):
        with pytest.raises(ValidationError, match="client_first_name"):
            validate_payment_request(_valid_payment_request(client_first_name="J"))

    def test_last_name_too_short(self):
        with pytest.raises(ValidationError, match="client_last_name"):
            validate_payment_request(_valid_payment_request(client_last_name="D"))

    def test_designation_empty(self):
        with pytest.raises(ValidationError, match="designation"):
            validate_payment_request(_valid_payment_request(designation=""))


class TestValidatePaymentMethod:
    def test_invalid_payment_method(self):
        with pytest.raises(ValidationError, match="payment_method"):
            validate_payment_request(_valid_payment_request(payment_method="INVALID_OPERATOR"))


# ---------------------------------------------------------------------------
# validate_transfer_request
# ---------------------------------------------------------------------------

class TestValidateTransferRequestValid:
    def test_minimal_valid_request(self):
        validate_transfer_request(_valid_transfer_request())

    def test_max_amount(self):
        validate_transfer_request(_valid_transfer_request(amount=1_500_000))

    def test_min_amount(self):
        validate_transfer_request(_valid_transfer_request(amount=100))


class TestValidateTransferCurrency:
    def test_invalid_currency(self):
        with pytest.raises(ValidationError, match="currency"):
            validate_transfer_request(_valid_transfer_request(currency="EUR"))


class TestValidateTransferAmount:
    def test_below_minimum(self):
        with pytest.raises(ValidationError, match="amount"):
            validate_transfer_request(_valid_transfer_request(amount=99))

    def test_above_maximum(self):
        with pytest.raises(ValidationError, match="amount"):
            validate_transfer_request(_valid_transfer_request(amount=1_500_001))

    def test_float_rejected(self):
        with pytest.raises(ValidationError, match="amount"):
            validate_transfer_request(_valid_transfer_request(amount=500.5))  # type: ignore[arg-type]


class TestValidateTransferMerchantTransactionId:
    def test_empty_id(self):
        with pytest.raises(ValidationError, match="merchant_transaction_id"):
            validate_transfer_request(_valid_transfer_request(merchant_transaction_id=""))

    def test_too_long_id(self):
        with pytest.raises(ValidationError, match="merchant_transaction_id"):
            validate_transfer_request(_valid_transfer_request(merchant_transaction_id="x" * 31))


class TestValidateTransferPaymentMethod:
    def test_invalid_method(self):
        with pytest.raises(ValidationError, match="payment_method"):
            validate_transfer_request(_valid_transfer_request(payment_method="INVALID"))


class TestValidateTransferPhoneNumber:
    def test_no_plus_sign(self):
        with pytest.raises(ValidationError, match="phone_number"):
            validate_transfer_request(_valid_transfer_request(phone_number="2250707000001"))

    def test_too_short(self):
        with pytest.raises(ValidationError, match="phone_number"):
            validate_transfer_request(_valid_transfer_request(phone_number="+123"))


class TestValidateTransferReason:
    def test_empty_reason(self):
        with pytest.raises(ValidationError, match="reason"):
            validate_transfer_request(_valid_transfer_request(reason=""))

    def test_too_long_reason(self):
        with pytest.raises(ValidationError, match="reason"):
            validate_transfer_request(_valid_transfer_request(reason="x" * 256))


class TestValidateTransferNotifyUrl:
    def test_not_http(self):
        with pytest.raises(ValidationError, match="notify_url"):
            validate_transfer_request(_valid_transfer_request(notify_url="ftp://example.com/hook"))

    def test_empty(self):
        with pytest.raises(ValidationError, match="notify_url"):
            validate_transfer_request(_valid_transfer_request(notify_url=""))


# ---------------------------------------------------------------------------
# ValidationError
# ---------------------------------------------------------------------------

class TestValidationError:
    def test_inherits_value_error(self):
        err = ValidationError("amount", "must be positive")
        assert isinstance(err, ValueError)

    def test_field_attribute(self):
        err = ValidationError("currency", "invalid")
        assert err.field == "currency"

    def test_message_contains_field(self):
        err = ValidationError("email", "must be valid")
        assert "[email]" in str(err)
