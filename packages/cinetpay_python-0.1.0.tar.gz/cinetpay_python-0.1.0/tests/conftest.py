"""Shared fixtures for CinetPay SDK tests."""

from __future__ import annotations

import pytest
import respx
import httpx

from cinetpay.types.config import CountryCredentials


# ---------------------------------------------------------------------------
# Mock credentials
# ---------------------------------------------------------------------------

MOCK_API_KEY = "sk_test_abc123def456"
MOCK_API_PASSWORD = "password_secret_789"
MOCK_COUNTRY = "CI"
MOCK_BASE_URL = "https://api.cinetpay.net"

MOCK_JWT_TOKEN = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.mock_token_payload.signature"
MOCK_JWT_TOKEN_2 = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.refreshed_token.signature"


@pytest.fixture()
def mock_credentials() -> CountryCredentials:
    return CountryCredentials(api_key=MOCK_API_KEY, api_password=MOCK_API_PASSWORD)


@pytest.fixture()
def mock_credentials_dict(mock_credentials: CountryCredentials) -> dict[str, CountryCredentials]:
    return {MOCK_COUNTRY: mock_credentials}


# ---------------------------------------------------------------------------
# Mock API responses
# ---------------------------------------------------------------------------

MOCK_AUTH_RESPONSE = {
    "code": 200,
    "status": "OK",
    "access_token": MOCK_JWT_TOKEN,
}

MOCK_PAYMENT_INIT_RESPONSE = {
    "code": 200,
    "status": "OK",
    "payment_token": "pt_abc123",
    "notify_token": "nt_def456",
    "transaction_id": "txn_789",
    "merchant_transaction_id": "merchant_001",
    "payment_url": "https://checkout.cinetpay.net/pay/pt_abc123",
    "details": {
        "code": 2001,
        "status": "INITIATED",
        "message": "Payment initiated",
        "must_be_redirected": True,
    },
}

MOCK_PAYMENT_STATUS_RESPONSE = {
    "code": 100,
    "status": "SUCCESS",
    "merchant_transaction_id": "merchant_001",
    "transaction_id": "txn_789",
    "user": {
        "name": "Jean Dupont",
        "email": "jean@example.com",
        "phone_number": "+2250707000001",
    },
}

MOCK_TRANSFER_CREATE_RESPONSE = {
    "code": 200,
    "status": "PENDING",
    "merchant_transaction_id": "transfer_001",
    "transaction_id": "txn_transfer_789",
    "notify_token": "nt_transfer_456",
    "amount": "5000",
    "fee_amount": "100",
    "phone_number": "+2250707000002",
    "currency": "XOF",
}

MOCK_TRANSFER_STATUS_RESPONSE = {
    "code": 100,
    "status": "SUCCESS",
    "merchant_transaction_id": "transfer_001",
    "transaction_id": "txn_transfer_789",
    "amount": "5000",
    "fee_amount": "100",
    "phone_number": "+2250707000002",
    "currency": "XOF",
    "user": {
        "name": "Aminata Koné",
        "email": "aminata@example.com",
        "phone_number": "+2250707000002",
    },
}

MOCK_BALANCE_RESPONSE = {
    "code": 200,
    "status": "OK",
    "available_balance": "249711.74",
    "currency": "XOF",
}

MOCK_EXPIRED_TOKEN_RESPONSE = {
    "code": 1003,
    "status": "EXPIRED_TOKEN",
    "description": "Token has expired",
}


@pytest.fixture()
def mock_auth_response() -> dict:
    return dict(MOCK_AUTH_RESPONSE)


@pytest.fixture()
def mock_payment_response() -> dict:
    return dict(MOCK_PAYMENT_INIT_RESPONSE)


@pytest.fixture()
def mock_transfer_response() -> dict:
    return dict(MOCK_TRANSFER_CREATE_RESPONSE)


@pytest.fixture()
def mock_balance_response() -> dict:
    return dict(MOCK_BALANCE_RESPONSE)


# ---------------------------------------------------------------------------
# respx router setup
# ---------------------------------------------------------------------------

@pytest.fixture()
def respx_mock():
    """Provide a respx mock router for httpx calls."""
    with respx.mock(base_url=MOCK_BASE_URL, assert_all_called=False) as router:
        yield router


@pytest.fixture()
def mock_auth_route(respx_mock):
    """Pre-configure the auth endpoint to return a valid token."""
    route = respx_mock.post("/v1/oauth/login").mock(
        return_value=httpx.Response(200, json=MOCK_AUTH_RESPONSE)
    )
    return route
