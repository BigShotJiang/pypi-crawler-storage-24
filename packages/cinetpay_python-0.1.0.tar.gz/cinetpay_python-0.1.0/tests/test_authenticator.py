"""Tests for cinetpay.auth.authenticator — sync JWT authenticator."""

from __future__ import annotations

import threading
from unittest.mock import MagicMock, patch

import httpx
import pytest
import respx

from cinetpay.auth.authenticator import Authenticator
from cinetpay.auth.token_store import MemoryTokenStore
from cinetpay.errors import AuthenticationError
from cinetpay.http.http_client import HttpClient
from cinetpay.logger import NoopLogger
from cinetpay.types.config import CountryCredentials

from .conftest import (
    MOCK_API_KEY,
    MOCK_API_PASSWORD,
    MOCK_AUTH_RESPONSE,
    MOCK_BASE_URL,
    MOCK_JWT_TOKEN,
)


def _make_authenticator(
    token_store: MemoryTokenStore | None = None,
    http_client: HttpClient | None = None,
) -> Authenticator:
    store = token_store or MemoryTokenStore()
    logger = NoopLogger()
    if http_client is None:
        http_client = HttpClient(MOCK_BASE_URL, 30.0, logger)
    creds = CountryCredentials(api_key=MOCK_API_KEY, api_password=MOCK_API_PASSWORD)
    return Authenticator(http_client, "CI", creds, 82800, store, logger)


# ---------------------------------------------------------------------------
# Cache hit
# ---------------------------------------------------------------------------

class TestAuthenticatorCacheHit:
    def test_returns_cached_token_without_http_call(self):
        store = MemoryTokenStore()
        store.set("cinetpay_token_ci", "cached_token_123", 3600)

        with respx.mock(base_url=MOCK_BASE_URL, assert_all_called=False) as router:
            auth_route = router.post("/v1/oauth/login").mock(
                return_value=httpx.Response(200, json=MOCK_AUTH_RESPONSE)
            )
            auth = _make_authenticator(token_store=store)
            token = auth.get_token()

        assert token == "cached_token_123"
        assert auth_route.call_count == 0


# ---------------------------------------------------------------------------
# Cache miss
# ---------------------------------------------------------------------------

class TestAuthenticatorCacheMiss:
    def test_authenticates_and_caches_on_miss(self):
        store = MemoryTokenStore()

        with respx.mock(base_url=MOCK_BASE_URL) as router:
            auth_route = router.post("/v1/oauth/login").mock(
                return_value=httpx.Response(200, json=MOCK_AUTH_RESPONSE)
            )
            auth = _make_authenticator(token_store=store)
            token = auth.get_token()

        assert token == MOCK_JWT_TOKEN
        assert auth_route.call_count == 1
        # Token should now be cached
        assert store.get("cinetpay_token_ci") == MOCK_JWT_TOKEN

    def test_no_access_token_in_response_raises(self):
        with respx.mock(base_url=MOCK_BASE_URL) as router:
            router.post("/v1/oauth/login").mock(
                return_value=httpx.Response(200, json={"code": 200, "status": "OK"})
            )
            auth = _make_authenticator()
            with pytest.raises(AuthenticationError, match="no access_token"):
                auth.get_token()

    def test_empty_access_token_raises(self):
        with respx.mock(base_url=MOCK_BASE_URL) as router:
            router.post("/v1/oauth/login").mock(
                return_value=httpx.Response(200, json={"code": 200, "access_token": ""})
            )
            auth = _make_authenticator()
            with pytest.raises(AuthenticationError, match="no access_token"):
                auth.get_token()


# ---------------------------------------------------------------------------
# Force refresh
# ---------------------------------------------------------------------------

class TestAuthenticatorForceRefresh:
    def test_force_refresh_clears_cache_and_reauthenticates(self):
        store = MemoryTokenStore()
        store.set("cinetpay_token_ci", "old_token", 3600)

        refreshed_response = {**MOCK_AUTH_RESPONSE, "access_token": "new_token_xyz"}

        with respx.mock(base_url=MOCK_BASE_URL) as router:
            router.post("/v1/oauth/login").mock(
                return_value=httpx.Response(200, json=refreshed_response)
            )
            auth = _make_authenticator(token_store=store)
            token = auth.force_refresh()

        assert token == "new_token_xyz"
        assert store.get("cinetpay_token_ci") == "new_token_xyz"


# ---------------------------------------------------------------------------
# Sanitized error message (no credential leakage)
# ---------------------------------------------------------------------------

class TestAuthenticatorSanitizedError:
    def test_network_error_does_not_leak_credentials(self):
        with respx.mock(base_url=MOCK_BASE_URL) as router:
            router.post("/v1/oauth/login").mock(side_effect=httpx.ConnectError("Connection refused"))
            auth = _make_authenticator()

            with pytest.raises(AuthenticationError) as exc_info:
                auth.get_token()

            error_msg = str(exc_info.value)
            assert MOCK_API_KEY not in error_msg
            assert MOCK_API_PASSWORD not in error_msg
            assert "Authentication failed for country CI" in error_msg

    def test_repr_does_not_leak_credentials(self):
        auth = _make_authenticator()
        repr_str = repr(auth)
        assert MOCK_API_KEY not in repr_str
        assert MOCK_API_PASSWORD not in repr_str
        assert "CI" in repr_str


# ---------------------------------------------------------------------------
# Stampede guard
# ---------------------------------------------------------------------------

class TestAuthenticatorStampedeGuard:
    def test_concurrent_access_only_one_http_call(self):
        """Use a threading.Barrier to force concurrent get_token() calls.

        Only one HTTP call should be made despite multiple threads hitting
        get_token() with an empty cache simultaneously.
        """
        num_threads = 5
        barrier = threading.Barrier(num_threads)
        store = MemoryTokenStore()
        results: list[str] = []
        errors: list[Exception] = []

        with respx.mock(base_url=MOCK_BASE_URL) as router:
            auth_route = router.post("/v1/oauth/login").mock(
                return_value=httpx.Response(200, json=MOCK_AUTH_RESPONSE)
            )
            auth = _make_authenticator(token_store=store)

            def worker():
                try:
                    barrier.wait(timeout=5)
                    token = auth.get_token()
                    results.append(token)
                except Exception as e:
                    errors.append(e)

            threads = [threading.Thread(target=worker) for _ in range(num_threads)]
            for t in threads:
                t.start()
            for t in threads:
                t.join(timeout=10)

        assert not errors, f"Threads raised errors: {errors}"
        assert len(results) == num_threads
        assert all(token == MOCK_JWT_TOKEN for token in results)
        # The stampede guard may allow 1-2 calls (one cache miss + one after lock),
        # but should not allow num_threads calls
        assert auth_route.call_count <= 2, (
            f"Expected at most 2 HTTP calls, got {auth_route.call_count}"
        )


# ---------------------------------------------------------------------------
# clear_cache
# ---------------------------------------------------------------------------

class TestAuthenticatorClearCache:
    def test_clear_cache_removes_token(self):
        store = MemoryTokenStore()
        store.set("cinetpay_token_ci", "token_to_clear", 3600)

        auth = _make_authenticator(token_store=store)
        auth.clear_cache()

        assert store.get("cinetpay_token_ci") is None
