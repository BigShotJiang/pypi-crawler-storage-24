"""Tests for cinetpay.webhooks.notification — verify and parse webhooks."""

from __future__ import annotations

import json

import pytest

from cinetpay.webhooks.notification import parse_notification, verify_notification


# ---------------------------------------------------------------------------
# verify_notification
# ---------------------------------------------------------------------------

class TestVerifyNotification:
    def test_matching_tokens(self):
        assert verify_notification("abc123", "abc123") is True

    def test_different_tokens(self):
        assert verify_notification("abc123", "xyz789") is False

    def test_different_length_tokens(self):
        assert verify_notification("short", "much_longer_token") is False

    def test_empty_tokens_match(self):
        assert verify_notification("", "") is True

    def test_one_empty_one_not(self):
        assert verify_notification("", "token") is False

    def test_one_not_one_empty(self):
        assert verify_notification("token", "") is False

    def test_subtle_difference(self):
        assert verify_notification("token_abc", "token_abd") is False

    def test_timing_safe(self):
        """verify_notification uses hmac.compare_digest (timing-safe)."""
        # We just verify the function works correctly; timing safety is in hmac
        assert verify_notification("a" * 100, "a" * 100) is True


# ---------------------------------------------------------------------------
# parse_notification — valid dict
# ---------------------------------------------------------------------------

class TestParseNotificationDict:
    def test_valid_minimal_dict(self):
        data = {
            "notify_token": "nt_abc",
            "transaction_id": "txn_123",
            "merchant_transaction_id": "m_001",
        }
        payload = parse_notification(data)
        assert payload.notify_token == "nt_abc"
        assert payload.transaction_id == "txn_123"
        assert payload.merchant_transaction_id == "m_001"
        assert payload.user is None

    def test_valid_dict_with_user(self):
        data = {
            "notify_token": "nt_abc",
            "transaction_id": "txn_123",
            "merchant_transaction_id": "m_001",
            "user": {
                "name": "Jean Dupont",
                "email": "jean@example.com",
                "phone_number": "+2250707000001",
            },
        }
        payload = parse_notification(data)
        assert payload.user is not None
        assert payload.user.name == "Jean Dupont"
        assert payload.user.email == "jean@example.com"
        assert payload.user.phone_number == "+2250707000001"


# ---------------------------------------------------------------------------
# parse_notification — valid JSON string
# ---------------------------------------------------------------------------

class TestParseNotificationJsonString:
    def test_valid_json_string(self):
        data = json.dumps({
            "notify_token": "nt_abc",
            "transaction_id": "txn_123",
            "merchant_transaction_id": "m_001",
        })
        payload = parse_notification(data)
        assert payload.notify_token == "nt_abc"
        assert payload.transaction_id == "txn_123"

    def test_valid_json_string_with_user(self):
        data = json.dumps({
            "notify_token": "nt_abc",
            "transaction_id": "txn_123",
            "merchant_transaction_id": "m_001",
            "user": {
                "name": "Aminata",
                "email": "aminata@example.com",
                "phone_number": "+221770000000",
            },
        })
        payload = parse_notification(data)
        assert payload.user is not None
        assert payload.user.name == "Aminata"


# ---------------------------------------------------------------------------
# parse_notification — missing fields
# ---------------------------------------------------------------------------

class TestParseNotificationMissingFields:
    def test_missing_notify_token(self):
        with pytest.raises(TypeError, match="missing notify_token"):
            parse_notification({"transaction_id": "txn_123"})

    def test_missing_transaction_id(self):
        with pytest.raises(TypeError, match="missing.*transaction_id"):
            parse_notification({"notify_token": "nt_abc"})

    def test_empty_notify_token(self):
        with pytest.raises(TypeError, match="missing"):
            parse_notification({"notify_token": "", "transaction_id": "txn_123"})

    def test_empty_transaction_id(self):
        with pytest.raises(TypeError, match="missing"):
            parse_notification({"notify_token": "nt_abc", "transaction_id": ""})

    def test_empty_dict(self):
        with pytest.raises(TypeError):
            parse_notification({})

    def test_invalid_json_string(self):
        with pytest.raises(json.JSONDecodeError):
            parse_notification("not valid json")

    def test_both_fields_missing(self):
        with pytest.raises(TypeError):
            parse_notification({"other_field": "value"})
