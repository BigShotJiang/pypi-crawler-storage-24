"""Tests for cinetpay.constants — currencies, channels, payment methods, statuses."""

from __future__ import annotations

from cinetpay.constants import (
    API_CODES,
    CHANNELS,
    COUNTRY_CODES,
    CURRENCIES,
    PAYMENT_METHODS,
    PAYMENT_METHODS_BY_COUNTRY,
    TRANSACTION_STATUSES,
    is_final_status,
)


# ---------------------------------------------------------------------------
# Currencies
# ---------------------------------------------------------------------------

class TestCurrencies:
    def test_contains_xof(self):
        assert "XOF" in CURRENCIES

    def test_contains_xaf(self):
        assert "XAF" in CURRENCIES

    def test_contains_gnf(self):
        assert "GNF" in CURRENCIES

    def test_contains_cdf(self):
        assert "CDF" in CURRENCIES

    def test_contains_usd(self):
        assert "USD" in CURRENCIES

    def test_count(self):
        assert len(CURRENCIES) == 5

    def test_values_match_keys(self):
        for key, value in CURRENCIES.items():
            assert key == value


# ---------------------------------------------------------------------------
# Channels
# ---------------------------------------------------------------------------

class TestChannels:
    def test_contains_push(self):
        assert "PUSH" in CHANNELS

    def test_contains_otp(self):
        assert "OTP" in CHANNELS

    def test_contains_qrcode(self):
        assert "QRCODE" in CHANNELS

    def test_count(self):
        assert len(CHANNELS) == 3

    def test_values_match_keys(self):
        for key, value in CHANNELS.items():
            assert key == value


# ---------------------------------------------------------------------------
# Payment methods
# ---------------------------------------------------------------------------

class TestPaymentMethods:
    def test_contains_om_ci(self):
        assert "OM_CI" in PAYMENT_METHODS

    def test_contains_wave_sn(self):
        assert "WAVE_SN" in PAYMENT_METHODS

    def test_contains_mtn_cm(self):
        assert "MTN_CM" in PAYMENT_METHODS

    def test_all_values_match_keys(self):
        for key, value in PAYMENT_METHODS.items():
            assert key == value

    def test_not_empty(self):
        assert len(PAYMENT_METHODS) > 20


class TestPaymentMethodsByCountry:
    def test_ci_has_four_methods(self):
        assert len(PAYMENT_METHODS_BY_COUNTRY["CI"]) == 4

    def test_ci_contains_om_ci(self):
        assert "OM_CI" in PAYMENT_METHODS_BY_COUNTRY["CI"]

    def test_sn_contains_wave_sn(self):
        assert "WAVE_SN" in PAYMENT_METHODS_BY_COUNTRY["SN"]

    def test_all_country_codes_present(self):
        for code in COUNTRY_CODES:
            assert code in PAYMENT_METHODS_BY_COUNTRY

    def test_all_methods_are_in_payment_methods(self):
        for country, methods in PAYMENT_METHODS_BY_COUNTRY.items():
            for method in methods:
                assert method in PAYMENT_METHODS, f"{method} not in PAYMENT_METHODS"

    def test_values_are_tuples(self):
        for country, methods in PAYMENT_METHODS_BY_COUNTRY.items():
            assert isinstance(methods, tuple), f"{country} methods should be a tuple"


# ---------------------------------------------------------------------------
# Transaction statuses
# ---------------------------------------------------------------------------

class TestTransactionStatuses:
    def test_contains_ok(self):
        assert "OK" in TRANSACTION_STATUSES

    def test_contains_success(self):
        assert "SUCCESS" in TRANSACTION_STATUSES

    def test_contains_failed(self):
        assert "FAILED" in TRANSACTION_STATUSES

    def test_contains_pending(self):
        assert "PENDING" in TRANSACTION_STATUSES

    def test_contains_expired_token(self):
        assert "EXPIRED_TOKEN" in TRANSACTION_STATUSES

    def test_values_match_keys(self):
        for key, value in TRANSACTION_STATUSES.items():
            assert key == value


class TestIsFinalStatus:
    def test_success_is_final(self):
        assert is_final_status("SUCCESS") is True

    def test_failed_is_final(self):
        assert is_final_status("FAILED") is True

    def test_transaction_exist_is_final(self):
        assert is_final_status("TRANSACTION_EXIST") is True

    def test_insufficient_balance_is_final(self):
        assert is_final_status("INSUFFICIENT_BALANCE") is True

    def test_pending_is_not_final(self):
        assert is_final_status("PENDING") is False

    def test_initiated_is_not_final(self):
        assert is_final_status("INITIATED") is False

    def test_ok_is_not_final(self):
        assert is_final_status("OK") is False

    def test_expired_is_not_final(self):
        assert is_final_status("EXPIRED") is False

    def test_unknown_string_is_not_final(self):
        assert is_final_status("UNKNOWN") is False

    def test_empty_string_is_not_final(self):
        assert is_final_status("") is False


# ---------------------------------------------------------------------------
# API codes
# ---------------------------------------------------------------------------

class TestApiCodes:
    def test_200_is_ok(self):
        assert API_CODES[200] == "OK"

    def test_100_is_success(self):
        assert API_CODES[100] == "SUCCESS"

    def test_1003_is_expired_token(self):
        assert API_CODES[1003] == "EXPIRED_TOKEN"

    def test_1005_is_invalid_credentials(self):
        assert API_CODES[1005] == "INVALID_CREDENTIALS"

    def test_404_is_not_found(self):
        assert API_CODES[404] == "NOT_FOUND"

    def test_negative_one_is_operation_error(self):
        assert API_CODES[-1] == "OPERATION_ERROR"

    def test_2001_is_initiated(self):
        assert API_CODES[2001] == "INITIATED"

    def test_2010_is_failed(self):
        assert API_CODES[2010] == "FAILED"

    def test_all_values_are_valid_statuses(self):
        for code, status in API_CODES.items():
            assert status in TRANSACTION_STATUSES, f"API code {code} -> {status} not in TRANSACTION_STATUSES"


# ---------------------------------------------------------------------------
# Country codes
# ---------------------------------------------------------------------------

class TestCountryCodes:
    def test_is_tuple(self):
        assert isinstance(COUNTRY_CODES, tuple)

    def test_contains_ci(self):
        assert "CI" in COUNTRY_CODES

    def test_contains_sn(self):
        assert "SN" in COUNTRY_CODES

    def test_contains_cm(self):
        assert "CM" in COUNTRY_CODES

    def test_count_is_ten(self):
        assert len(COUNTRY_CODES) == 10

    def test_all_codes_are_two_letters(self):
        for code in COUNTRY_CODES:
            assert len(code) == 2
            assert code.isupper()
