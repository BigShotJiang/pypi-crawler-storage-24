"""Tests for cinetpay.api.transfer — TransferApi."""

from __future__ import annotations

import httpx
import pytest
import respx

from cinetpay.api.transfer import TransferApi
from cinetpay.auth.authenticator import Authenticator
from cinetpay.auth.token_store import MemoryTokenStore
from cinetpay.errors import ApiError
from cinetpay.http.http_client import HttpClient
from cinetpay.logger import NoopLogger
from cinetpay.types.config import CountryCredentials
from cinetpay.types.transfer import TransferRequest

from .conftest import (
    MOCK_API_KEY,
    MOCK_API_PASSWORD,
    MOCK_AUTH_RESPONSE,
    MOCK_BASE_URL,
    MOCK_EXPIRED_TOKEN_RESPONSE,
    MOCK_JWT_TOKEN,
    MOCK_TRANSFER_CREATE_RESPONSE,
    MOCK_TRANSFER_STATUS_RESPONSE,
)


def _valid_transfer_request() -> TransferRequest:
    return TransferRequest(
        currency="XOF",
        merchant_transaction_id="transfer_001",
        phone_number="+2250707000002",
        amount=5000,
        payment_method="OM_CI",
        reason="Remboursement client",
        notify_url="https://example.com/transfer-notify",
    )


def _build_transfer_api(router, store=None):
    logger = NoopLogger()
    store = store or MemoryTokenStore()
    http_client = HttpClient(MOCK_BASE_URL, 30.0, logger)
    creds = CountryCredentials(api_key=MOCK_API_KEY, api_password=MOCK_API_PASSWORD)
    auth = Authenticator(http_client, "CI", creds, 82800, store, logger)
    return TransferApi(http_client, {"CI": auth})


# ---------------------------------------------------------------------------
# create — success
# ---------------------------------------------------------------------------

class TestTransferCreate:
    def test_create_success(self):
        with respx.mock(base_url=MOCK_BASE_URL) as router:
            router.post("/v1/oauth/login").mock(
                return_value=httpx.Response(200, json=MOCK_AUTH_RESPONSE)
            )
            router.post("/v1/transfer").mock(
                return_value=httpx.Response(200, json=MOCK_TRANSFER_CREATE_RESPONSE)
            )
            api = _build_transfer_api(router)
            result = api.create(_valid_transfer_request(), "CI")

        assert result.transaction_id == "txn_transfer_789"
        assert result.status == "PENDING"
        assert result.amount == "5000"
        assert result.fee_amount == "100"
        assert result.phone_number == "+2250707000002"
        assert result.currency == "XOF"
        assert result.notify_token == "nt_transfer_456"

    def test_create_uses_cached_token(self):
        store = MemoryTokenStore()
        store.set("cinetpay_token_ci", MOCK_JWT_TOKEN, 3600)

        with respx.mock(base_url=MOCK_BASE_URL, assert_all_called=False) as router:
            auth_route = router.post("/v1/oauth/login").mock(
                return_value=httpx.Response(200, json=MOCK_AUTH_RESPONSE)
            )
            router.post("/v1/transfer").mock(
                return_value=httpx.Response(200, json=MOCK_TRANSFER_CREATE_RESPONSE)
            )
            api = _build_transfer_api(router, store=store)
            api.create(_valid_transfer_request(), "CI")

        assert auth_route.call_count == 0


# ---------------------------------------------------------------------------
# get_status — success
# ---------------------------------------------------------------------------

class TestTransferGetStatus:
    def test_get_status_success(self):
        store = MemoryTokenStore()
        store.set("cinetpay_token_ci", MOCK_JWT_TOKEN, 3600)

        with respx.mock(base_url=MOCK_BASE_URL) as router:
            router.get("/v1/transfer/txn_transfer_789").mock(
                return_value=httpx.Response(200, json=MOCK_TRANSFER_STATUS_RESPONSE)
            )
            api = _build_transfer_api(router, store=store)
            status = api.get_status("txn_transfer_789", "CI")

        assert status.status == "SUCCESS"
        assert status.code == 100
        assert status.amount == "5000"
        assert status.user is not None
        assert status.user.name == "Aminata Koné"
        assert status.phone_number == "+2250707000002"
        assert status.currency == "XOF"


# ---------------------------------------------------------------------------
# Retry on expired token
# ---------------------------------------------------------------------------

class TestTransferRetryOnExpiredToken:
    def test_create_retries_on_expired_token(self):
        call_count = {"transfer": 0}

        def transfer_side_effect(request):
            call_count["transfer"] += 1
            if call_count["transfer"] == 1:
                return httpx.Response(401, json=MOCK_EXPIRED_TOKEN_RESPONSE)
            return httpx.Response(200, json=MOCK_TRANSFER_CREATE_RESPONSE)

        with respx.mock(base_url=MOCK_BASE_URL) as router:
            router.post("/v1/oauth/login").mock(
                return_value=httpx.Response(200, json=MOCK_AUTH_RESPONSE)
            )
            router.post("/v1/transfer").mock(side_effect=transfer_side_effect)

            api = _build_transfer_api(router)
            result = api.create(_valid_transfer_request(), "CI")

        assert result.transaction_id == "txn_transfer_789"
        assert call_count["transfer"] == 2

    def test_get_status_retries_on_expired_token(self):
        call_count = {"status": 0}

        def status_side_effect(request):
            call_count["status"] += 1
            if call_count["status"] == 1:
                return httpx.Response(401, json=MOCK_EXPIRED_TOKEN_RESPONSE)
            return httpx.Response(200, json=MOCK_TRANSFER_STATUS_RESPONSE)

        with respx.mock(base_url=MOCK_BASE_URL) as router:
            router.post("/v1/oauth/login").mock(
                return_value=httpx.Response(200, json=MOCK_AUTH_RESPONSE)
            )
            router.get("/v1/transfer/txn_transfer_789").mock(side_effect=status_side_effect)

            api = _build_transfer_api(router)
            status = api.get_status("txn_transfer_789", "CI")

        assert status.status == "SUCCESS"
        assert call_count["status"] == 2


# ---------------------------------------------------------------------------
# Unknown country
# ---------------------------------------------------------------------------

class TestTransferUnknownCountry:
    def test_create_unknown_country_raises(self):
        with respx.mock(base_url=MOCK_BASE_URL) as router:
            api = _build_transfer_api(router)
            with pytest.raises(TypeError, match="No credentials.*SN"):
                api.create(_valid_transfer_request(), "SN")

    def test_get_status_unknown_country_raises(self):
        with respx.mock(base_url=MOCK_BASE_URL) as router:
            api = _build_transfer_api(router)
            with pytest.raises(TypeError, match="No credentials.*GH"):
                api.get_status("txn_123", "GH")


# ---------------------------------------------------------------------------
# API error propagation
# ---------------------------------------------------------------------------

class TestTransferApiError:
    def test_non_expired_api_error_propagates(self):
        error_response = {
            "code": 2005,
            "status": "INSUFFICIENT_BALANCE",
            "description": "Solde insuffisant",
        }
        store = MemoryTokenStore()
        store.set("cinetpay_token_ci", MOCK_JWT_TOKEN, 3600)

        with respx.mock(base_url=MOCK_BASE_URL) as router:
            router.post("/v1/transfer").mock(
                return_value=httpx.Response(400, json=error_response)
            )
            api = _build_transfer_api(router, store=store)

            with pytest.raises(ApiError) as exc_info:
                api.create(_valid_transfer_request(), "CI")

            assert exc_info.value.api_code == 2005
            assert exc_info.value.api_status == "INSUFFICIENT_BALANCE"
