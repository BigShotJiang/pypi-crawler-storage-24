"""Tests for cinetpay.auth.token_store — MemoryTokenStore."""

from __future__ import annotations

import time
from unittest.mock import patch

from cinetpay.auth.token_store import MemoryTokenStore


class TestMemoryTokenStoreGetSetDelete:
    def test_get_returns_none_for_unknown_key(self):
        store = MemoryTokenStore()
        assert store.get("nonexistent") is None

    def test_set_then_get_returns_value(self):
        store = MemoryTokenStore()
        store.set("key1", "token_abc", 3600)
        assert store.get("key1") == "token_abc"

    def test_delete_removes_key(self):
        store = MemoryTokenStore()
        store.set("key1", "token_abc", 3600)
        store.delete("key1")
        assert store.get("key1") is None

    def test_delete_nonexistent_key_does_not_raise(self):
        store = MemoryTokenStore()
        store.delete("nonexistent")  # should not raise

    def test_set_overwrites_existing_value(self):
        store = MemoryTokenStore()
        store.set("key1", "old_token", 3600)
        store.set("key1", "new_token", 3600)
        assert store.get("key1") == "new_token"


class TestMemoryTokenStoreTTL:
    def test_expired_token_returns_none(self):
        store = MemoryTokenStore()
        # Mock time.monotonic to simulate TTL expiration
        initial_time = 1000.0
        with patch("cinetpay.auth.token_store.time.monotonic", return_value=initial_time):
            store.set("key1", "token_abc", 60)  # TTL: 60 seconds

        # Fast-forward past expiration
        with patch("cinetpay.auth.token_store.time.monotonic", return_value=initial_time + 61):
            assert store.get("key1") is None

    def test_token_within_ttl_returns_value(self):
        store = MemoryTokenStore()
        initial_time = 1000.0
        with patch("cinetpay.auth.token_store.time.monotonic", return_value=initial_time):
            store.set("key1", "token_abc", 60)

        with patch("cinetpay.auth.token_store.time.monotonic", return_value=initial_time + 59):
            assert store.get("key1") == "token_abc"

    def test_token_at_exact_ttl_is_expired(self):
        store = MemoryTokenStore()
        initial_time = 1000.0
        with patch("cinetpay.auth.token_store.time.monotonic", return_value=initial_time):
            store.set("key1", "token_abc", 60)

        # At exactly expires_at, it should be expired (>= check)
        with patch("cinetpay.auth.token_store.time.monotonic", return_value=initial_time + 60):
            assert store.get("key1") is None

    def test_expired_token_is_removed_from_cache(self):
        store = MemoryTokenStore()
        initial_time = 1000.0
        with patch("cinetpay.auth.token_store.time.monotonic", return_value=initial_time):
            store.set("key1", "token_abc", 60)

        with patch("cinetpay.auth.token_store.time.monotonic", return_value=initial_time + 61):
            store.get("key1")  # triggers lazy eviction
            assert "key1" not in store._cache


class TestMemoryTokenStoreIsolation:
    def test_different_keys_are_independent(self):
        store = MemoryTokenStore()
        store.set("key1", "token_a", 3600)
        store.set("key2", "token_b", 3600)
        assert store.get("key1") == "token_a"
        assert store.get("key2") == "token_b"

    def test_delete_one_key_does_not_affect_other(self):
        store = MemoryTokenStore()
        store.set("key1", "token_a", 3600)
        store.set("key2", "token_b", 3600)
        store.delete("key1")
        assert store.get("key1") is None
        assert store.get("key2") == "token_b"

    def test_different_stores_are_independent(self):
        store1 = MemoryTokenStore()
        store2 = MemoryTokenStore()
        store1.set("key1", "token_a", 3600)
        assert store2.get("key1") is None

    def test_different_ttls_per_key(self):
        store = MemoryTokenStore()
        initial_time = 1000.0
        with patch("cinetpay.auth.token_store.time.monotonic", return_value=initial_time):
            store.set("short", "token_short", 10)
            store.set("long", "token_long", 3600)

        with patch("cinetpay.auth.token_store.time.monotonic", return_value=initial_time + 15):
            assert store.get("short") is None
            assert store.get("long") == "token_long"
