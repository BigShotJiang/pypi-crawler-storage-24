"""Tests for cinetpay.api.payment — PaymentApi."""

from __future__ import annotations

import httpx
import pytest
import respx

from cinetpay.api.payment import PaymentApi
from cinetpay.auth.authenticator import Authenticator
from cinetpay.auth.token_store import MemoryTokenStore
from cinetpay.errors import ApiError
from cinetpay.http.http_client import HttpClient
from cinetpay.logger import NoopLogger
from cinetpay.types.config import CountryCredentials
from cinetpay.types.payment import PaymentRequest

from .conftest import (
    MOCK_API_KEY,
    MOCK_API_PASSWORD,
    MOCK_AUTH_RESPONSE,
    MOCK_BASE_URL,
    MOCK_EXPIRED_TOKEN_RESPONSE,
    MOCK_JWT_TOKEN,
    MOCK_PAYMENT_INIT_RESPONSE,
    MOCK_PAYMENT_STATUS_RESPONSE,
)


def _valid_payment_request() -> PaymentRequest:
    return PaymentRequest(
        currency="XOF",
        merchant_transaction_id="txn_001",
        amount=1000,
        lang="fr",
        designation="Achat test",
        client_email="user@example.com",
        client_first_name="Jean",
        client_last_name="Dupont",
        success_url="https://example.com/success",
        failed_url="https://example.com/failed",
        notify_url="https://example.com/notify",
        channel="PUSH",
    )


def _build_payment_api(router, store=None):
    """Build a PaymentApi backed by the given respx router."""
    logger = NoopLogger()
    store = store or MemoryTokenStore()
    http_client = HttpClient(MOCK_BASE_URL, 30.0, logger)
    creds = CountryCredentials(api_key=MOCK_API_KEY, api_password=MOCK_API_PASSWORD)
    auth = Authenticator(http_client, "CI", creds, 82800, store, logger)
    return PaymentApi(http_client, {"CI": auth})


# ---------------------------------------------------------------------------
# initialize — success
# ---------------------------------------------------------------------------

class TestPaymentInitialize:
    def test_initialize_success(self):
        with respx.mock(base_url=MOCK_BASE_URL) as router:
            router.post("/v1/oauth/login").mock(
                return_value=httpx.Response(200, json=MOCK_AUTH_RESPONSE)
            )
            router.post("/v1/payment").mock(
                return_value=httpx.Response(200, json=MOCK_PAYMENT_INIT_RESPONSE)
            )
            api = _build_payment_api(router)
            result = api.initialize(_valid_payment_request(), "CI")

        assert result.payment_token == "pt_abc123"
        assert result.notify_token == "nt_def456"
        assert result.transaction_id == "txn_789"
        assert result.payment_url.startswith("https://")
        assert result.details.status == "INITIATED"
        assert result.details.must_be_redirected is True

    def test_initialize_uses_cached_token(self):
        store = MemoryTokenStore()
        store.set("cinetpay_token_ci", MOCK_JWT_TOKEN, 3600)

        with respx.mock(base_url=MOCK_BASE_URL, assert_all_called=False) as router:
            auth_route = router.post("/v1/oauth/login").mock(
                return_value=httpx.Response(200, json=MOCK_AUTH_RESPONSE)
            )
            router.post("/v1/payment").mock(
                return_value=httpx.Response(200, json=MOCK_PAYMENT_INIT_RESPONSE)
            )
            api = _build_payment_api(router, store=store)
            api.initialize(_valid_payment_request(), "CI")

        assert auth_route.call_count == 0


# ---------------------------------------------------------------------------
# get_status — success
# ---------------------------------------------------------------------------

class TestPaymentGetStatus:
    def test_get_status_success(self):
        store = MemoryTokenStore()
        store.set("cinetpay_token_ci", MOCK_JWT_TOKEN, 3600)

        with respx.mock(base_url=MOCK_BASE_URL) as router:
            router.get("/v1/payment/pt_abc123").mock(
                return_value=httpx.Response(200, json=MOCK_PAYMENT_STATUS_RESPONSE)
            )
            api = _build_payment_api(router, store=store)
            status = api.get_status("pt_abc123", "CI")

        assert status.status == "SUCCESS"
        assert status.code == 100
        assert status.transaction_id == "txn_789"
        assert status.user.name == "Jean Dupont"
        assert status.user.email == "jean@example.com"


# ---------------------------------------------------------------------------
# Retry on expired token (1003)
# ---------------------------------------------------------------------------

class TestPaymentRetryOnExpiredToken:
    def test_initialize_retries_on_expired_token(self):
        call_count = {"auth": 0, "payment": 0}

        def auth_side_effect(request):
            call_count["auth"] += 1
            return httpx.Response(200, json=MOCK_AUTH_RESPONSE)

        def payment_side_effect(request):
            call_count["payment"] += 1
            if call_count["payment"] == 1:
                return httpx.Response(401, json=MOCK_EXPIRED_TOKEN_RESPONSE)
            return httpx.Response(200, json=MOCK_PAYMENT_INIT_RESPONSE)

        with respx.mock(base_url=MOCK_BASE_URL) as router:
            router.post("/v1/oauth/login").mock(side_effect=auth_side_effect)
            router.post("/v1/payment").mock(side_effect=payment_side_effect)

            api = _build_payment_api(router)
            result = api.initialize(_valid_payment_request(), "CI")

        assert result.payment_token == "pt_abc123"
        assert call_count["payment"] == 2  # first failed, second succeeded
        assert call_count["auth"] >= 2  # initial auth + force refresh

    def test_get_status_retries_on_expired_token(self):
        call_count = {"status": 0}

        def status_side_effect(request):
            call_count["status"] += 1
            if call_count["status"] == 1:
                return httpx.Response(401, json=MOCK_EXPIRED_TOKEN_RESPONSE)
            return httpx.Response(200, json=MOCK_PAYMENT_STATUS_RESPONSE)

        with respx.mock(base_url=MOCK_BASE_URL) as router:
            router.post("/v1/oauth/login").mock(
                return_value=httpx.Response(200, json=MOCK_AUTH_RESPONSE)
            )
            router.get("/v1/payment/pt_abc123").mock(side_effect=status_side_effect)

            api = _build_payment_api(router)
            status = api.get_status("pt_abc123", "CI")

        assert status.status == "SUCCESS"
        assert call_count["status"] == 2


# ---------------------------------------------------------------------------
# Unknown country error
# ---------------------------------------------------------------------------

class TestPaymentUnknownCountry:
    def test_initialize_unknown_country_raises(self):
        with respx.mock(base_url=MOCK_BASE_URL) as router:
            api = _build_payment_api(router)
            with pytest.raises(TypeError, match="No credentials.*GH"):
                api.initialize(_valid_payment_request(), "GH")

    def test_get_status_unknown_country_raises(self):
        with respx.mock(base_url=MOCK_BASE_URL) as router:
            api = _build_payment_api(router)
            with pytest.raises(TypeError, match="No credentials.*ML"):
                api.get_status("token", "ML")


# ---------------------------------------------------------------------------
# API error propagation
# ---------------------------------------------------------------------------

class TestPaymentApiError:
    def test_non_expired_api_error_propagates(self):
        error_response = {
            "code": 1200,
            "status": "TRANSACTION_EXIST",
            "description": "La transaction existe deja",
        }
        store = MemoryTokenStore()
        store.set("cinetpay_token_ci", MOCK_JWT_TOKEN, 3600)

        with respx.mock(base_url=MOCK_BASE_URL) as router:
            router.post("/v1/payment").mock(
                return_value=httpx.Response(400, json=error_response)
            )
            api = _build_payment_api(router, store=store)

            with pytest.raises(ApiError) as exc_info:
                api.initialize(_valid_payment_request(), "CI")

            assert exc_info.value.api_code == 1200
            assert exc_info.value.api_status == "TRANSACTION_EXIST"
