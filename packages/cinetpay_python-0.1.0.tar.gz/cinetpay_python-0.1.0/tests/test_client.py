"""Tests for cinetpay.client — CinetPayClient."""

from __future__ import annotations

import httpx
import pytest
import respx

from cinetpay.client import CinetPayClient
from cinetpay.logger import NoopLogger
from cinetpay.types.config import (
    ClientConfig,
    CountryCredentials,
    DEFAULT_BASE_URL,
    PRODUCTION_BASE_URL,
)

from .conftest import (
    MOCK_API_KEY,
    MOCK_API_PASSWORD,
    MOCK_AUTH_RESPONSE,
    MOCK_BASE_URL,
)


def _creds(api_key: str = MOCK_API_KEY) -> CountryCredentials:
    return CountryCredentials(api_key=api_key, api_password=MOCK_API_PASSWORD)


# ---------------------------------------------------------------------------
# Empty credentials error
# ---------------------------------------------------------------------------

class TestClientEmptyCredentials:
    def test_empty_dict_raises(self):
        with pytest.raises(TypeError, match="At least one country credential"):
            CinetPayClient(ClientConfig(credentials={}))

    def test_none_credentials_raises(self):
        # An empty dict evaluates as falsy
        with pytest.raises(TypeError, match="At least one country credential"):
            CinetPayClient(ClientConfig(credentials={}))


# ---------------------------------------------------------------------------
# HTTPS enforcement
# ---------------------------------------------------------------------------

class TestClientHttpsEnforcement:
    def test_http_url_raises(self):
        with pytest.raises(TypeError, match="HTTPS"):
            CinetPayClient(ClientConfig(
                credentials={"CI": _creds()},
                base_url="http://api.cinetpay.net",
            ))

    def test_https_url_accepted(self):
        with respx.mock(base_url=MOCK_BASE_URL):
            client = CinetPayClient(ClientConfig(
                credentials={"CI": _creds()},
                base_url="https://api.cinetpay.net",
            ))
            client.close()

    def test_localhost_http_allowed(self):
        """HTTP is allowed for localhost (dev environments)."""
        client = CinetPayClient(ClientConfig(
            credentials={"CI": _creds()},
            base_url="http://localhost:8000",
        ))
        client.close()

    def test_127_0_0_1_http_allowed(self):
        client = CinetPayClient(ClientConfig(
            credentials={"CI": _creds()},
            base_url="http://127.0.0.1:8000",
        ))
        client.close()


# ---------------------------------------------------------------------------
# Environment auto-detection
# ---------------------------------------------------------------------------

class TestClientEnvAutoDetection:
    def test_sk_test_prefix_selects_sandbox(self):
        """sk_test_ keys should auto-select the sandbox base URL."""
        client = CinetPayClient(ClientConfig(
            credentials={"CI": _creds("sk_test_abc123")},
        ))
        # The sandbox URL is the default
        assert client._http_client._base_url == DEFAULT_BASE_URL
        client.close()

    def test_sk_live_prefix_selects_production(self):
        """sk_live_ keys should auto-select the production base URL."""
        client = CinetPayClient(ClientConfig(
            credentials={"CI": _creds("sk_live_abc123")},
        ))
        assert client._http_client._base_url == PRODUCTION_BASE_URL
        client.close()


# ---------------------------------------------------------------------------
# Environment mismatch warning
# ---------------------------------------------------------------------------

class TestClientEnvMismatch:
    def test_live_key_with_sandbox_url_logs_error(self):
        """Using sk_live_ with sandbox URL should log an error."""

        class CapturingLogger(NoopLogger):
            def __init__(self):
                self.errors: list[str] = []

            def error(self, message, data=None):
                self.errors.append(message)

        logger = CapturingLogger()
        client = CinetPayClient(ClientConfig(
            credentials={"CI": _creds("sk_live_abc123")},
            base_url="https://api.cinetpay.net",  # sandbox URL with live key
            logger=logger,
        ))
        client.close()

        assert any("MISMATCH" in e for e in logger.errors)

    def test_test_key_with_production_url_logs_error(self):
        class CapturingLogger(NoopLogger):
            def __init__(self):
                self.errors: list[str] = []

            def error(self, message, data=None):
                self.errors.append(message)

        logger = CapturingLogger()
        client = CinetPayClient(ClientConfig(
            credentials={"CI": _creds("sk_test_abc123")},
            base_url="https://api.cinetpay.co",  # production URL with test key
            logger=logger,
        ))
        client.close()

        assert any("MISMATCH" in e for e in logger.errors)


# ---------------------------------------------------------------------------
# Mixed environment error
# ---------------------------------------------------------------------------

class TestClientMixedEnv:
    def test_mixed_test_and_live_keys_logs_error(self):
        class CapturingLogger(NoopLogger):
            def __init__(self):
                self.errors: list[str] = []

            def error(self, message, data=None):
                self.errors.append(message)

        logger = CapturingLogger()
        client = CinetPayClient(ClientConfig(
            credentials={
                "CI": _creds("sk_test_abc123"),
                "SN": _creds("sk_live_xyz789"),
            },
            logger=logger,
        ))
        client.close()

        assert any("MIXED" in e for e in logger.errors)


# ---------------------------------------------------------------------------
# countries()
# ---------------------------------------------------------------------------

class TestClientCountries:
    def test_returns_configured_countries(self):
        client = CinetPayClient(ClientConfig(
            credentials={
                "CI": _creds(),
                "SN": _creds(),
            },
        ))
        countries = client.countries()
        assert sorted(countries) == ["CI", "SN"]
        client.close()

    def test_countries_uppercased(self):
        client = CinetPayClient(ClientConfig(
            credentials={"ci": _creds()},
        ))
        assert client.countries() == ["CI"]
        client.close()


# ---------------------------------------------------------------------------
# revoke_token / revoke_all_tokens
# ---------------------------------------------------------------------------

class TestClientRevokeToken:
    def test_revoke_token_for_configured_country(self):
        client = CinetPayClient(ClientConfig(
            credentials={"CI": _creds()},
        ))
        # Should not raise
        client.revoke_token("CI")
        client.close()

    def test_revoke_token_unconfigured_country_raises(self):
        client = CinetPayClient(ClientConfig(
            credentials={"CI": _creds()},
        ))
        with pytest.raises(TypeError, match="No credentials.*SN"):
            client.revoke_token("SN")
        client.close()

    def test_revoke_token_case_insensitive(self):
        client = CinetPayClient(ClientConfig(
            credentials={"CI": _creds()},
        ))
        client.revoke_token("ci")  # lowercase should work
        client.close()

    def test_revoke_all_tokens(self):
        client = CinetPayClient(ClientConfig(
            credentials={
                "CI": _creds(),
                "SN": _creds(),
            },
        ))
        client.revoke_all_tokens()  # should not raise
        client.close()


# ---------------------------------------------------------------------------
# repr masking
# ---------------------------------------------------------------------------

class TestClientRepr:
    def test_repr_does_not_leak_credentials(self):
        client = CinetPayClient(ClientConfig(
            credentials={"CI": _creds()},
        ))
        repr_str = repr(client)
        assert MOCK_API_KEY not in repr_str
        assert MOCK_API_PASSWORD not in repr_str
        assert "CinetPayClient" in repr_str
        assert "CI" in repr_str
        client.close()

    def test_repr_shows_countries(self):
        client = CinetPayClient(ClientConfig(
            credentials={
                "CI": _creds(),
                "SN": _creds(),
            },
        ))
        repr_str = repr(client)
        assert "CI" in repr_str
        assert "SN" in repr_str
        client.close()


# ---------------------------------------------------------------------------
# SSRF warning
# ---------------------------------------------------------------------------

class TestClientSsrfWarning:
    def test_unknown_host_logs_warning(self):
        class CapturingLogger(NoopLogger):
            def __init__(self):
                self.warnings: list[str] = []

            def warn(self, message, data=None):
                self.warnings.append(message)

        logger = CapturingLogger()
        client = CinetPayClient(ClientConfig(
            credentials={"CI": _creds()},
            base_url="https://evil.example.com",
            logger=logger,
        ))
        client.close()

        assert any("not a known CinetPay domain" in w for w in logger.warnings)

    def test_known_host_no_warning(self):
        class CapturingLogger(NoopLogger):
            def __init__(self):
                self.warnings: list[str] = []

            def warn(self, message, data=None):
                self.warnings.append(message)

        logger = CapturingLogger()
        client = CinetPayClient(ClientConfig(
            credentials={"CI": _creds()},
            base_url="https://api.cinetpay.net",
            logger=logger,
        ))
        client.close()

        ssrf_warnings = [w for w in logger.warnings if "not a known CinetPay domain" in w]
        assert len(ssrf_warnings) == 0


# ---------------------------------------------------------------------------
# Context manager
# ---------------------------------------------------------------------------

class TestClientContextManager:
    def test_context_manager(self):
        with CinetPayClient(ClientConfig(
            credentials={"CI": _creds()},
        )) as client:
            assert client.countries() == ["CI"]
