"""Tests for cinetpay.errors — error hierarchy."""

from __future__ import annotations

from cinetpay.errors import (
    ApiError,
    AuthenticationError,
    CinetPayError,
    NetworkError,
    TimeoutError,
)


# ---------------------------------------------------------------------------
# CinetPayError (base)
# ---------------------------------------------------------------------------

class TestCinetPayError:
    def test_constructor(self):
        err = CinetPayError("something went wrong")
        assert str(err) == "something went wrong"

    def test_is_exception(self):
        assert issubclass(CinetPayError, Exception)


# ---------------------------------------------------------------------------
# ApiError
# ---------------------------------------------------------------------------

class TestApiError:
    def test_constructor(self):
        err = ApiError(1200, "TRANSACTION_EXIST", "La transaction existe deja")
        assert err.api_code == 1200
        assert err.api_status == "TRANSACTION_EXIST"
        assert err.description == "La transaction existe deja"
        assert "[1200]" in str(err)
        assert "TRANSACTION_EXIST" in str(err)

    def test_inherits_cinetpay_error(self):
        err = ApiError(404, "NOT_FOUND", "")
        assert isinstance(err, CinetPayError)

    def test_from_response_with_description(self):
        data = {"code": 1005, "status": "INVALID_CREDENTIALS", "description": "Bad creds"}
        err = ApiError.from_response(data)
        assert err.api_code == 1005
        assert err.api_status == "INVALID_CREDENTIALS"
        assert err.description == "Bad creds"

    def test_from_response_with_message_fallback(self):
        data = {"code": 404, "status": "NOT_FOUND", "message": "Not found msg"}
        err = ApiError.from_response(data)
        assert err.description == "Not found msg"

    def test_from_response_missing_fields(self):
        data = {}
        err = ApiError.from_response(data)
        assert err.api_code == 0
        assert err.api_status == "UNKNOWN"
        assert err.description == ""

    def test_from_response_prefers_description_over_message(self):
        data = {"code": 100, "status": "OK", "description": "desc", "message": "msg"}
        err = ApiError.from_response(data)
        assert err.description == "desc"

    def test_from_response_code_as_string(self):
        data = {"code": "500", "status": "ERROR", "description": "Server error"}
        err = ApiError.from_response(data)
        assert err.api_code == 500


# ---------------------------------------------------------------------------
# AuthenticationError
# ---------------------------------------------------------------------------

class TestAuthenticationError:
    def test_default_message(self):
        err = AuthenticationError()
        assert str(err) == "Authentication failed"

    def test_custom_message(self):
        err = AuthenticationError("Invalid credentials for CI")
        assert "Invalid credentials for CI" in str(err)

    def test_inherits_cinetpay_error(self):
        err = AuthenticationError()
        assert isinstance(err, CinetPayError)


# ---------------------------------------------------------------------------
# NetworkError
# ---------------------------------------------------------------------------

class TestNetworkError:
    def test_constructor(self):
        err = NetworkError("Connection refused")
        assert str(err) == "Connection refused"
        assert err.cause is None

    def test_with_cause(self):
        original = ConnectionError("DNS resolution failed")
        err = NetworkError("Request failed", cause=original)
        assert err.cause is original
        assert isinstance(err.cause, ConnectionError)

    def test_inherits_cinetpay_error(self):
        err = NetworkError("fail")
        assert isinstance(err, CinetPayError)


# ---------------------------------------------------------------------------
# TimeoutError
# ---------------------------------------------------------------------------

class TestTimeoutError:
    def test_constructor(self):
        err = TimeoutError(30.0)
        assert err.timeout_seconds == 30.0
        assert "30.0s" in str(err)

    def test_inherits_cinetpay_error(self):
        err = TimeoutError(10.0)
        assert isinstance(err, CinetPayError)

    def test_does_not_inherit_builtin_timeout(self):
        # It shadows builtins.TimeoutError but inherits CinetPayError
        err = TimeoutError(5.0)
        assert not isinstance(err, builtins_timeout_error())


# ---------------------------------------------------------------------------
# Hierarchy tests
# ---------------------------------------------------------------------------

class TestErrorHierarchy:
    def test_all_errors_caught_by_cinetpay_error(self):
        errors = [
            ApiError(0, "", ""),
            AuthenticationError(),
            NetworkError(""),
            TimeoutError(1.0),
        ]
        for err in errors:
            assert isinstance(err, CinetPayError), f"{type(err).__name__} not caught by CinetPayError"

    def test_api_error_not_network_error(self):
        assert not isinstance(ApiError(0, "", ""), NetworkError)

    def test_auth_error_not_api_error(self):
        assert not isinstance(AuthenticationError(), ApiError)

    def test_timeout_error_not_network_error(self):
        # TimeoutError and NetworkError are separate branches
        assert not isinstance(TimeoutError(1.0), NetworkError)

    def test_catch_all_pattern(self):
        """Demonstrate catch-all pattern works."""
        caught = False
        try:
            raise ApiError(1200, "TRANSACTION_EXIST", "dup")
        except CinetPayError:
            caught = True
        assert caught


def builtins_timeout_error():
    """Return the built-in TimeoutError to avoid name clash."""
    import builtins
    return builtins.TimeoutError
