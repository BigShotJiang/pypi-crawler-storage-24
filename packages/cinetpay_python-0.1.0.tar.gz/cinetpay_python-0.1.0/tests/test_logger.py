"""Tests for cinetpay.logger — NoopLogger and StandardLibLogger."""

from __future__ import annotations

import logging

from cinetpay.logger import LoggerProtocol, NoopLogger, StandardLibLogger


# ---------------------------------------------------------------------------
# NoopLogger
# ---------------------------------------------------------------------------

class TestNoopLogger:
    def test_debug_does_nothing(self):
        logger = NoopLogger()
        # Should not raise or produce any output
        logger.debug("test message")
        logger.debug("test message", {"key": "value"})

    def test_warn_does_nothing(self):
        logger = NoopLogger()
        logger.warn("warning message")
        logger.warn("warning message", {"key": "value"})

    def test_error_does_nothing(self):
        logger = NoopLogger()
        logger.error("error message")
        logger.error("error message", {"key": "value"})

    def test_implements_protocol(self):
        logger = NoopLogger()
        assert isinstance(logger, LoggerProtocol)

    def test_all_methods_accept_no_data(self):
        logger = NoopLogger()
        logger.debug()
        logger.warn()
        logger.error()


# ---------------------------------------------------------------------------
# StandardLibLogger
# ---------------------------------------------------------------------------

class TestStandardLibLogger:
    def test_debug_logs_with_prefix(self, caplog):
        logger = StandardLibLogger("test_cinetpay")
        with caplog.at_level(logging.DEBUG, logger="test_cinetpay"):
            logger.debug("hello world")
        assert "[cinetpay]" in caplog.text
        assert "hello world" in caplog.text

    def test_warn_logs_with_prefix(self, caplog):
        logger = StandardLibLogger("test_cinetpay_warn")
        with caplog.at_level(logging.WARNING, logger="test_cinetpay_warn"):
            logger.warn("warning msg")
        assert "[cinetpay]" in caplog.text
        assert "warning msg" in caplog.text

    def test_error_logs_with_prefix(self, caplog):
        logger = StandardLibLogger("test_cinetpay_error")
        with caplog.at_level(logging.ERROR, logger="test_cinetpay_error"):
            logger.error("error msg")
        assert "[cinetpay]" in caplog.text
        assert "error msg" in caplog.text

    def test_debug_with_data(self, caplog):
        logger = StandardLibLogger("test_cinetpay_data")
        with caplog.at_level(logging.DEBUG, logger="test_cinetpay_data"):
            logger.debug("event", {"key": "value"})
        assert "key" in caplog.text
        assert "value" in caplog.text

    def test_debug_without_data(self, caplog):
        logger = StandardLibLogger("test_cinetpay_nodata")
        with caplog.at_level(logging.DEBUG, logger="test_cinetpay_nodata"):
            logger.debug("no data event")
        assert "no data event" in caplog.text

    def test_default_name_is_cinetpay(self):
        logger = StandardLibLogger()
        assert logger._logger.name == "cinetpay"

    def test_custom_name(self):
        logger = StandardLibLogger("custom_name")
        assert logger._logger.name == "custom_name"

    def test_implements_protocol(self):
        logger = StandardLibLogger()
        assert isinstance(logger, LoggerProtocol)
