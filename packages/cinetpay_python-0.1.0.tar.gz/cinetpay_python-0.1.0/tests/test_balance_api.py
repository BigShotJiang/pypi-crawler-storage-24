"""Tests for cinetpay.api.balance — BalanceApi."""

from __future__ import annotations

import httpx
import pytest
import respx

from cinetpay.api.balance import BalanceApi
from cinetpay.auth.authenticator import Authenticator
from cinetpay.auth.token_store import MemoryTokenStore
from cinetpay.errors import ApiError
from cinetpay.http.http_client import HttpClient
from cinetpay.logger import NoopLogger
from cinetpay.types.config import CountryCredentials

from .conftest import (
    MOCK_API_KEY,
    MOCK_API_PASSWORD,
    MOCK_AUTH_RESPONSE,
    MOCK_BALANCE_RESPONSE,
    MOCK_BASE_URL,
    MOCK_EXPIRED_TOKEN_RESPONSE,
    MOCK_JWT_TOKEN,
)


def _build_balance_api(router, store=None):
    logger = NoopLogger()
    store = store or MemoryTokenStore()
    http_client = HttpClient(MOCK_BASE_URL, 30.0, logger)
    creds = CountryCredentials(api_key=MOCK_API_KEY, api_password=MOCK_API_PASSWORD)
    auth = Authenticator(http_client, "CI", creds, 82800, store, logger)
    return BalanceApi(http_client, {"CI": auth})


# ---------------------------------------------------------------------------
# get — success
# ---------------------------------------------------------------------------

class TestBalanceGet:
    def test_get_success(self):
        store = MemoryTokenStore()
        store.set("cinetpay_token_ci", MOCK_JWT_TOKEN, 3600)

        with respx.mock(base_url=MOCK_BASE_URL) as router:
            router.get("/v1/balances").mock(
                return_value=httpx.Response(200, json=MOCK_BALANCE_RESPONSE)
            )
            api = _build_balance_api(router, store=store)
            balance = api.get("CI")

        assert balance.available_balance == "249711.74"
        assert balance.currency == "XOF"
        assert balance.code == 200
        assert balance.status == "OK"

    def test_get_authenticates_on_cache_miss(self):
        with respx.mock(base_url=MOCK_BASE_URL) as router:
            auth_route = router.post("/v1/oauth/login").mock(
                return_value=httpx.Response(200, json=MOCK_AUTH_RESPONSE)
            )
            router.get("/v1/balances").mock(
                return_value=httpx.Response(200, json=MOCK_BALANCE_RESPONSE)
            )
            api = _build_balance_api(router)
            balance = api.get("CI")

        assert balance.available_balance == "249711.74"
        assert auth_route.call_count == 1


# ---------------------------------------------------------------------------
# Retry on expired token
# ---------------------------------------------------------------------------

class TestBalanceRetryOnExpiredToken:
    def test_get_retries_on_expired_token(self):
        call_count = {"balance": 0}

        def balance_side_effect(request):
            call_count["balance"] += 1
            if call_count["balance"] == 1:
                return httpx.Response(401, json=MOCK_EXPIRED_TOKEN_RESPONSE)
            return httpx.Response(200, json=MOCK_BALANCE_RESPONSE)

        with respx.mock(base_url=MOCK_BASE_URL) as router:
            router.post("/v1/oauth/login").mock(
                return_value=httpx.Response(200, json=MOCK_AUTH_RESPONSE)
            )
            router.get("/v1/balances").mock(side_effect=balance_side_effect)

            api = _build_balance_api(router)
            balance = api.get("CI")

        assert balance.available_balance == "249711.74"
        assert call_count["balance"] == 2


# ---------------------------------------------------------------------------
# Unknown country
# ---------------------------------------------------------------------------

class TestBalanceUnknownCountry:
    def test_get_unknown_country_raises(self):
        with respx.mock(base_url=MOCK_BASE_URL) as router:
            api = _build_balance_api(router)
            with pytest.raises(TypeError, match="No credentials.*SN"):
                api.get("SN")


# ---------------------------------------------------------------------------
# API error propagation
# ---------------------------------------------------------------------------

class TestBalanceApiError:
    def test_non_expired_api_error_propagates(self):
        error_response = {
            "code": 1005,
            "status": "INVALID_CREDENTIALS",
            "description": "Invalid API credentials",
        }
        store = MemoryTokenStore()
        store.set("cinetpay_token_ci", MOCK_JWT_TOKEN, 3600)

        with respx.mock(base_url=MOCK_BASE_URL) as router:
            router.get("/v1/balances").mock(
                return_value=httpx.Response(401, json=error_response)
            )
            api = _build_balance_api(router, store=store)

            with pytest.raises(ApiError) as exc_info:
                api.get("CI")

            assert exc_info.value.api_code == 1005
