"""CinetPay Python SDK — payments and mobile money transfers in Africa.

Usage::

    from cinetpay import CinetPayClient, ClientConfig, CountryCredentials

    client = CinetPayClient(ClientConfig(
        credentials={
            "CI": CountryCredentials(api_key="sk_test_...", api_password="..."),
        },
    ))

    # Initialize a payment
    payment = client.payment.initialize(request, "CI")

    # Check payment status
    status = client.payment.get_status(payment.payment_token, "CI")
"""

from __future__ import annotations

__version__ = "0.1.0"

# ---------------------------------------------------------------------------
# Main clients
# ---------------------------------------------------------------------------
from cinetpay.async_client import AsyncCinetPayClient
from cinetpay.client import CinetPayClient

# ---------------------------------------------------------------------------
# Configuration types
# ---------------------------------------------------------------------------
from cinetpay.types.config import (
    API_KEY_PREFIX_LIVE,
    API_KEY_PREFIX_TEST,
    AsyncTokenStoreProtocol,
    ClientConfig,
    CountryCredentials,
    DEFAULT_BASE_URL,
    DEFAULT_TIMEOUT,
    DEFAULT_TOKEN_TTL,
    PRODUCTION_BASE_URL,
    TokenStoreProtocol,
)

# ---------------------------------------------------------------------------
# Domain types
# ---------------------------------------------------------------------------
from cinetpay.types.balance import Balance
from cinetpay.types.payment import (
    PaymentDetails,
    PaymentRequest,
    PaymentResponse,
    PaymentStatus,
    PaymentStatusUser,
)
from cinetpay.types.transfer import (
    TransferRequest,
    TransferResponse,
    TransferStatus,
    TransferStatusUser,
)
from cinetpay.types.webhook import WebhookPayload, WebhookUser

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------
from cinetpay.constants import (
    API_CODES,
    CHANNELS,
    COUNTRY_CODES,
    CURRENCIES,
    PAYMENT_METHODS,
    PAYMENT_METHODS_BY_COUNTRY,
    TRANSACTION_STATUSES,
    Channel,
    CountryCode,
    Currency,
    PaymentMethod,
    TransactionStatus,
    is_final_status,
)

# ---------------------------------------------------------------------------
# Errors
# ---------------------------------------------------------------------------
from cinetpay.errors import (
    ApiError,
    AuthenticationError,
    CinetPayError,
    NetworkError,
    TimeoutError,
)

# ---------------------------------------------------------------------------
# Validation
# ---------------------------------------------------------------------------
from cinetpay.validation import ValidationError

# ---------------------------------------------------------------------------
# Webhooks
# ---------------------------------------------------------------------------
from cinetpay.webhooks.notification import parse_notification, verify_notification

# ---------------------------------------------------------------------------
# Logger
# ---------------------------------------------------------------------------
from cinetpay.logger import LoggerProtocol, NoopLogger, StandardLibLogger

# ---------------------------------------------------------------------------
# Token store
# ---------------------------------------------------------------------------
from cinetpay.auth.token_store import MemoryTokenStore

__all__ = [
    # Version
    "__version__",
    # Clients
    "AsyncCinetPayClient",
    "CinetPayClient",
    # Config types
    "API_KEY_PREFIX_LIVE",
    "API_KEY_PREFIX_TEST",
    "AsyncTokenStoreProtocol",
    "ClientConfig",
    "CountryCredentials",
    "DEFAULT_BASE_URL",
    "DEFAULT_TIMEOUT",
    "DEFAULT_TOKEN_TTL",
    "PRODUCTION_BASE_URL",
    "TokenStoreProtocol",
    # Domain types
    "Balance",
    "PaymentDetails",
    "PaymentRequest",
    "PaymentResponse",
    "PaymentStatus",
    "PaymentStatusUser",
    "TransferRequest",
    "TransferResponse",
    "TransferStatus",
    "TransferStatusUser",
    "WebhookPayload",
    "WebhookUser",
    # Constants
    "API_CODES",
    "CHANNELS",
    "COUNTRY_CODES",
    "CURRENCIES",
    "Channel",
    "CountryCode",
    "Currency",
    "PAYMENT_METHODS",
    "PAYMENT_METHODS_BY_COUNTRY",
    "PaymentMethod",
    "TRANSACTION_STATUSES",
    "TransactionStatus",
    "is_final_status",
    # Errors
    "ApiError",
    "AuthenticationError",
    "CinetPayError",
    "NetworkError",
    "TimeoutError",
    "ValidationError",
    # Webhooks
    "parse_notification",
    "verify_notification",
    # Logger
    "LoggerProtocol",
    "NoopLogger",
    "StandardLibLogger",
    # Token store
    "MemoryTokenStore",
]
