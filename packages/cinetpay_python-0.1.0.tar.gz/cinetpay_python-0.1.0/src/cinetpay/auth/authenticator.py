"""Synchronous JWT authenticator with stampede guard."""

from __future__ import annotations

import threading
from typing import Any

from cinetpay.errors.auth_error import AuthenticationError
from cinetpay.http.http_client import HttpClient
from cinetpay.logger import LoggerProtocol
from cinetpay.types.config import CountryCredentials, TokenStoreProtocol


class Authenticator:
    """Manages JWT authentication for a single country.

    Each CinetPay country has its own credentials (``api_key`` / ``api_password``).
    The Authenticator obtains a JWT via ``POST /v1/oauth/login``, caches it in the
    :class:`~cinetpay.types.config.TokenStoreProtocol`, and auto-renews on expiry.

    Credentials are stored in name-mangled attributes and never exposed via
    ``repr()``, ``str()``, or ``vars()``.

    .. note::
        Internal — used by :class:`~cinetpay.client.CinetPayClient`.
        Do not instantiate directly.
    """

    def __init__(
        self,
        http_client: HttpClient,
        country: str,
        credentials: CountryCredentials,
        token_ttl: int,
        token_store: TokenStoreProtocol,
        logger: LoggerProtocol,
    ) -> None:
        self._http_client = http_client
        self._country = country
        self._token_ttl = token_ttl
        self._token_store = token_store
        self._logger = logger
        self._cache_key = f"cinetpay_token_{country.lower()}"

        # Name-mangled to prevent accidental leakage
        self.__api_key = credentials.api_key
        self.__api_password = credentials.api_password

        # Stampede guard: only one thread authenticates at a time
        self._lock = threading.Lock()

    def get_token(self) -> str:
        """Return a valid JWT token (from cache or freshly obtained).

        Uses a :class:`threading.Lock` to prevent token stampede: if multiple
        threads call this concurrently with an empty cache, only one HTTP call
        is made.

        Returns:
            JWT Bearer token.

        Raises:
            AuthenticationError: If the API does not return a token.
        """
        cached = self._token_store.get(self._cache_key)
        if cached is not None:
            self._logger.debug(f"Token cache hit for {self._country}")
            return cached

        self._logger.debug(f"Token cache miss for {self._country}, authenticating...")

        with self._lock:
            # Double-check after acquiring the lock (another thread may have filled the cache)
            cached = self._token_store.get(self._cache_key)
            if cached is not None:
                self._logger.debug(f"Token cache hit for {self._country} (after lock)")
                return cached
            return self._authenticate()

    def force_refresh(self) -> str:
        """Force token renewal by clearing the cache then re-authenticating.

        Called automatically by API classes when the API returns
        ``EXPIRED_TOKEN`` (code 1003).

        Returns:
            New JWT token.

        Raises:
            AuthenticationError: If the API does not return a token.
        """
        self._logger.warn(f"Force refreshing token for {self._country} (expired or invalid)")
        self._token_store.delete(self._cache_key)
        return self._authenticate()

    def clear_cache(self) -> None:
        """Delete the cached token for this country.

        Useful to force re-authentication on the next API call.
        """
        self._token_store.delete(self._cache_key)

    def __repr__(self) -> str:
        """Prevent credential leakage in logs and stack traces."""
        return f"Authenticator(country={self._country!r}, cache_key={self._cache_key!r})"

    def _authenticate(self) -> str:
        """Call ``POST /v1/oauth/login`` and cache the returned token.

        Returns:
            JWT token.

        Raises:
            AuthenticationError: If the response is missing ``access_token``
                or the HTTP call fails.
        """
        try:
            data: dict[str, Any] = self._http_client.post(
                "/v1/oauth/login",
                {
                    "api_key": self.__api_key,
                    "api_password": self.__api_password,
                },
            )
        except Exception:
            # Sanitize to prevent credential leakage in stack traces
            raise AuthenticationError(
                f"Authentication failed for country {self._country}"
            ) from None

        access_token = data.get("access_token")
        if not access_token:
            raise AuthenticationError(
                f"Authentication failed for country {self._country}: "
                "no access_token in response"
            )

        self._token_store.set(self._cache_key, access_token, self._token_ttl)
        self._logger.debug(f"Token cached for {self._country} (TTL: {self._token_ttl}s)")
        return access_token
