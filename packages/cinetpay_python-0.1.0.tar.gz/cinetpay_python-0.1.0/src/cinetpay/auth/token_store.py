"""In-memory token store (default implementation)."""

from __future__ import annotations

import time
from dataclasses import dataclass, field


@dataclass
class _CacheEntry:
    """Internal cache entry with monotonic expiration timestamp."""

    value: str
    expires_at: float


class MemoryTokenStore:
    """In-memory JWT token store with lazy expiration.

    Expired tokens are automatically evicted on read. Suitable for a single
    process. For multi-instance production deployments, implement
    :class:`~cinetpay.types.config.TokenStoreProtocol` with Redis or another
    shared backend.

    Example::

        from cinetpay.auth.token_store import MemoryTokenStore
        store = MemoryTokenStore()
    """

    def __init__(self) -> None:
        self._cache: dict[str, _CacheEntry] = {}

    def get(self, key: str) -> str | None:
        """Retrieve a token from the cache.

        If the token is expired, it is deleted and ``None`` is returned.

        Args:
            key: Cache key (e.g. ``cinetpay_token_ci``).

        Returns:
            The token string, or ``None`` if absent/expired.
        """
        entry = self._cache.get(key)
        if entry is None:
            return None
        if time.monotonic() >= entry.expires_at:
            del self._cache[key]
            return None
        return entry.value

    def set(self, key: str, value: str, ttl_seconds: int) -> None:
        """Store a token with a time-to-live.

        Args:
            key: Cache key.
            value: JWT token string.
            ttl_seconds: Time-to-live in seconds.
        """
        self._cache[key] = _CacheEntry(
            value=value,
            expires_at=time.monotonic() + ttl_seconds,
        )

    def delete(self, key: str) -> None:
        """Remove a token from the cache.

        Args:
            key: Cache key to delete.
        """
        self._cache.pop(key, None)
