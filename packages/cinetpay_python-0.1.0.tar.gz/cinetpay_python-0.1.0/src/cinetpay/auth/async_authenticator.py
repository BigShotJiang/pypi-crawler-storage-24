"""Asynchronous JWT authenticator with asyncio.Lock stampede guard."""

from __future__ import annotations

import asyncio
from typing import Any

from cinetpay.errors.auth_error import AuthenticationError
from cinetpay.http.async_http_client import AsyncHttpClient
from cinetpay.logger import LoggerProtocol
from cinetpay.types.config import AsyncTokenStoreProtocol, CountryCredentials


class AsyncAuthenticator:
    """Async JWT authenticator for a single country.

    Equivalent of :class:`~cinetpay.auth.authenticator.Authenticator` but uses
    :class:`asyncio.Lock` for the stampede guard and ``await`` for all I/O.

    .. note::
        Internal — used by :class:`~cinetpay.async_client.AsyncCinetPayClient`.
        Do not instantiate directly.
    """

    def __init__(
        self,
        http_client: AsyncHttpClient,
        country: str,
        credentials: CountryCredentials,
        token_ttl: int,
        token_store: AsyncTokenStoreProtocol,
        logger: LoggerProtocol,
    ) -> None:
        self._http_client = http_client
        self._country = country
        self._token_ttl = token_ttl
        self._token_store = token_store
        self._logger = logger
        self._cache_key = f"cinetpay_token_{country.lower()}"

        # Name-mangled to prevent accidental leakage
        self.__api_key = credentials.api_key
        self.__api_password = credentials.api_password

        # Stampede guard
        self._lock = asyncio.Lock()

    async def get_token(self) -> str:
        """Return a valid JWT token (from cache or freshly obtained).

        Uses an :class:`asyncio.Lock` to prevent token stampede.

        Returns:
            JWT Bearer token.

        Raises:
            AuthenticationError: If the API does not return a token.
        """
        cached = await self._token_store.get(self._cache_key)
        if cached is not None:
            self._logger.debug(f"Token cache hit for {self._country}")
            return cached

        self._logger.debug(f"Token cache miss for {self._country}, authenticating...")

        async with self._lock:
            # Double-check after acquiring the lock
            cached = await self._token_store.get(self._cache_key)
            if cached is not None:
                self._logger.debug(f"Token cache hit for {self._country} (after lock)")
                return cached
            return await self._authenticate()

    async def force_refresh(self) -> str:
        """Force token renewal by clearing cache then re-authenticating.

        Returns:
            New JWT token.

        Raises:
            AuthenticationError: If the API does not return a token.
        """
        self._logger.warn(f"Force refreshing token for {self._country} (expired or invalid)")
        await self._token_store.delete(self._cache_key)
        return await self._authenticate()

    async def clear_cache(self) -> None:
        """Delete the cached token for this country."""
        await self._token_store.delete(self._cache_key)

    def __repr__(self) -> str:
        """Prevent credential leakage in logs and stack traces."""
        return f"AsyncAuthenticator(country={self._country!r}, cache_key={self._cache_key!r})"

    async def _authenticate(self) -> str:
        """Call ``POST /v1/oauth/login`` and cache the returned token."""
        try:
            data: dict[str, Any] = await self._http_client.post(
                "/v1/oauth/login",
                {
                    "api_key": self.__api_key,
                    "api_password": self.__api_password,
                },
            )
        except Exception:
            raise AuthenticationError(
                f"Authentication failed for country {self._country}"
            ) from None

        access_token = data.get("access_token")
        if not access_token:
            raise AuthenticationError(
                f"Authentication failed for country {self._country}: "
                "no access_token in response"
            )

        await self._token_store.set(self._cache_key, access_token, self._token_ttl)
        self._logger.debug(f"Token cached for {self._country} (TTL: {self._token_ttl}s)")
        return access_token
