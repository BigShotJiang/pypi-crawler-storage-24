"""Configuration types for the CinetPay SDK."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Protocol, runtime_checkable

from cinetpay.logger import LoggerProtocol

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

DEFAULT_BASE_URL: str = "https://api.cinetpay.net"
"""Base URL for the CinetPay Sandbox API."""

PRODUCTION_BASE_URL: str = "https://api.cinetpay.co"
"""Base URL for the CinetPay Production API."""

API_KEY_PREFIX_TEST: str = "sk_test_"
"""Prefix for sandbox API keys."""

API_KEY_PREFIX_LIVE: str = "sk_live_"
"""Prefix for production API keys."""

DEFAULT_TOKEN_TTL: int = 82_800
"""Default JWT token cache TTL in seconds (23 h — safety margin under the 86 400 s API TTL)."""

DEFAULT_TIMEOUT: float = 30.0
"""Default HTTP request timeout in seconds."""

# ---------------------------------------------------------------------------
# Dataclasses & Protocols
# ---------------------------------------------------------------------------


@dataclass(frozen=True, slots=True)
class CountryCredentials:
    """API credentials for a single country.

    Attributes:
        api_key: API key provided by CinetPay (``sk_test_...`` or ``sk_live_...``).
        api_password: API password provided by CinetPay.
    """

    api_key: str
    api_password: str

    def __repr__(self) -> str:
        """Mask credentials in repr to prevent accidental leakage in logs."""
        masked_key = self.api_key[:8] + "***" if len(self.api_key) > 8 else "***"
        return f"CountryCredentials(api_key='{masked_key}', api_password='***')"


@runtime_checkable
class TokenStoreProtocol(Protocol):
    """Interface for JWT token storage backends.

    Implement this protocol to use Redis, a database, or any other shared store::

        class RedisTokenStore:
            def get(self, key: str) -> str | None:
                return redis.get(key)

            def set(self, key: str, value: str, ttl_seconds: int) -> None:
                redis.setex(key, ttl_seconds, value)

            def delete(self, key: str) -> None:
                redis.delete(key)
    """

    def get(self, key: str) -> str | None:
        """Retrieve a token from the cache. Return ``None`` if absent or expired."""
        ...

    def set(self, key: str, value: str, ttl_seconds: int) -> None:
        """Store a token with a TTL in seconds."""
        ...

    def delete(self, key: str) -> None:
        """Remove a token from the cache."""
        ...


@runtime_checkable
class AsyncTokenStoreProtocol(Protocol):
    """Async interface for JWT token storage backends.

    Implement this protocol for async stores (aioredis, etc.)::

        class AsyncRedisTokenStore:
            async def get(self, key: str) -> str | None: ...
            async def set(self, key: str, value: str, ttl_seconds: int) -> None: ...
            async def delete(self, key: str) -> None: ...
    """

    async def get(self, key: str) -> str | None:
        """Retrieve a token from the cache. Return ``None`` if absent or expired."""
        ...

    async def set(self, key: str, value: str, ttl_seconds: int) -> None:
        """Store a token with a TTL in seconds."""
        ...

    async def delete(self, key: str) -> None:
        """Remove a token from the cache."""
        ...


@dataclass(slots=True)
class ClientConfig:
    """Configuration for the CinetPay client.

    Example::

        config = ClientConfig(
            credentials={
                "CI": CountryCredentials(api_key="sk_test_...", api_password="..."),
                "SN": CountryCredentials(api_key="sk_test_...", api_password="..."),
            },
        )

    Attributes:
        credentials: Credentials keyed by ISO 3166-1 alpha-2 country code.
        base_url: API base URL. Auto-detected from key prefixes if omitted.
        token_ttl: JWT token cache TTL in seconds (default: 82 800 = 23 h).
        token_store: Custom sync token store (default: in-memory).
        timeout: HTTP request timeout in seconds (default: 30).
        debug: Enable logging with the standard library logger.
        logger: Custom logger implementing :class:`~cinetpay.logger.LoggerProtocol`.
    """

    credentials: dict[str, CountryCredentials]
    base_url: str | None = None
    token_ttl: int = field(default=DEFAULT_TOKEN_TTL)
    token_store: TokenStoreProtocol | None = None
    timeout: float = field(default=DEFAULT_TIMEOUT)
    debug: bool = False
    logger: LoggerProtocol | None = None
