"""Payment types — request, response, status, and serialization helpers."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from cinetpay.constants.channels import Channel
from cinetpay.constants.currencies import Currency
from cinetpay.constants.payment_methods import PaymentMethod
from cinetpay.constants.statuses import TransactionStatus


@dataclass(frozen=True, slots=True)
class PaymentRequest:
    """Parameters for initializing a web payment via ``client.payment.initialize()``.

    Attributes:
        currency: Payment currency (XOF, XAF, GNF, CDF, USD).
        merchant_transaction_id: Unique merchant-side transaction ID (max 30 chars).
        amount: Payment amount (min: 100, max: 2 500 000).
        lang: Payment page language (``"fr"`` or ``"en"``).
        designation: Payment label displayed to the customer.
        client_email: Customer e-mail address.
        client_first_name: Customer first name (2-255 chars).
        client_last_name: Customer last name (2-255 chars).
        success_url: Redirect URL after successful payment (max 120 chars).
        failed_url: Redirect URL after failed payment (max 120 chars).
        notify_url: Webhook notification URL (max 120 chars).
        channel: Payment channel (PUSH, OTP, QRCODE).
        payment_method: Specific payment method (e.g. OM_CI, WAVE_SN). Optional.
        client_phone_number: Customer phone in international format. Required if ``direct_pay``.
        direct_pay: Enable direct payment mode (no gateway redirect).
        otp_code: OTP code (4-6 digits, required for Orange Money in direct mode).
    """

    currency: Currency
    merchant_transaction_id: str
    amount: int
    lang: str  # "fr" | "en"
    designation: str
    client_email: str
    client_first_name: str
    client_last_name: str
    success_url: str
    failed_url: str
    notify_url: str
    channel: Channel
    payment_method: PaymentMethod | None = None
    client_phone_number: str | None = None
    direct_pay: bool | None = None
    otp_code: str | None = None


@dataclass(frozen=True, slots=True)
class PaymentDetails:
    """Direct-pay status details returned inside a :class:`PaymentResponse`.

    Attributes:
        code: Numeric status code.
        status: Textual status (SUCCESS, FAILED, INITIATED, PENDING).
        message: Human-readable message.
        must_be_redirected: Whether the user should be redirected to ``payment_url``.
    """

    code: int
    status: TransactionStatus
    message: str
    must_be_redirected: bool


@dataclass(frozen=True, slots=True)
class PaymentResponse:
    """Response returned after initializing a payment.

    Attributes:
        code: HTTP response code.
        status: Textual response status.
        payment_token: Unique payment token (for status checks).
        notify_token: Notification token (to verify webhooks).
        transaction_id: CinetPay transaction ID.
        merchant_transaction_id: Merchant-side transaction ID.
        payment_url: Gateway URL to redirect the customer to.
        details: Direct-pay details.
    """

    code: int
    status: str
    payment_token: str
    notify_token: str
    transaction_id: str
    merchant_transaction_id: str
    payment_url: str
    details: PaymentDetails


@dataclass(frozen=True, slots=True)
class PaymentStatusUser:
    """User information in a payment status response.

    Attributes:
        name: Full name.
        email: E-mail address.
        phone_number: Phone number.
    """

    name: str
    email: str
    phone_number: str


@dataclass(frozen=True, slots=True)
class PaymentStatus:
    """Status of a payment returned by ``client.payment.get_status()``.

    Attributes:
        code: Numeric status code (100 = SUCCESS, 2010 = FAILED, etc.).
        status: Textual transaction status.
        merchant_transaction_id: Merchant-side transaction ID.
        transaction_id: CinetPay transaction ID.
        user: User who made the payment.
    """

    code: int
    status: TransactionStatus
    merchant_transaction_id: str
    transaction_id: str
    user: PaymentStatusUser


# ---------------------------------------------------------------------------
# Serialization helpers
# ---------------------------------------------------------------------------


def serialize_payment_request(req: PaymentRequest) -> dict[str, Any]:
    """Serialize a :class:`PaymentRequest` (snake_case attrs) to the API format (snake_case keys).

    Returns:
        Dict ready to be JSON-encoded and sent to ``POST /v1/payment``.
    """
    body: dict[str, Any] = {
        "currency": req.currency,
        "merchant_transaction_id": req.merchant_transaction_id,
        "amount": req.amount,
        "lang": req.lang,
        "designation": req.designation,
        "client_email": req.client_email,
        "client_first_name": req.client_first_name,
        "client_last_name": req.client_last_name,
        "success_url": req.success_url,
        "failed_url": req.failed_url,
        "notify_url": req.notify_url,
        "channel": req.channel,
    }
    if req.payment_method is not None:
        body["payment_method"] = req.payment_method
    if req.client_phone_number is not None:
        body["client_phone_number"] = req.client_phone_number
    if req.direct_pay is not None:
        body["direct_pay"] = req.direct_pay
    if req.otp_code is not None:
        body["otp_code"] = req.otp_code
    return body


def to_payment_response(raw: dict[str, Any]) -> PaymentResponse:
    """Transform a raw API response dict into a typed :class:`PaymentResponse`."""
    details_raw = raw.get("details")
    if isinstance(details_raw, dict):
        details = PaymentDetails(
            code=int(details_raw.get("code", 0)),
            status=details_raw.get("status", "INITIATED"),
            message=str(details_raw.get("message", "")),
            must_be_redirected=bool(details_raw.get("must_be_redirected", False)),
        )
    else:
        details = PaymentDetails(code=0, status="INITIATED", message="", must_be_redirected=False)

    return PaymentResponse(
        code=int(raw.get("code", 0)),
        status=str(raw.get("status", "")),
        payment_token=str(raw.get("payment_token", "")),
        notify_token=str(raw.get("notify_token", "")),
        transaction_id=str(raw.get("transaction_id", "")),
        merchant_transaction_id=str(raw.get("merchant_transaction_id", "")),
        payment_url=str(raw.get("payment_url", "")),
        details=details,
    )


def to_payment_status(raw: dict[str, Any]) -> PaymentStatus:
    """Transform a raw API response dict into a typed :class:`PaymentStatus`."""
    user_raw = raw.get("user")
    if isinstance(user_raw, dict):
        user = PaymentStatusUser(
            name=str(user_raw.get("name", "")),
            email=str(user_raw.get("email", "")),
            phone_number=str(user_raw.get("phone_number", "")),
        )
    else:
        user = PaymentStatusUser(name="", email="", phone_number="")

    return PaymentStatus(
        code=int(raw.get("code", 0)),
        status=raw.get("status", "INITIATED"),
        merchant_transaction_id=str(raw.get("merchant_transaction_id", "")),
        transaction_id=str(raw.get("transaction_id", "")),
        user=user,
    )
