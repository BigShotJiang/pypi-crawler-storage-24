"""Transfer types — request, response, status, and serialization helpers."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from cinetpay.constants.currencies import Currency
from cinetpay.constants.payment_methods import PaymentMethod
from cinetpay.constants.statuses import TransactionStatus


@dataclass(frozen=True, slots=True)
class TransferRequest:
    """Parameters for creating a money transfer via ``client.transfer.create()``.

    Attributes:
        currency: Transfer currency (must match the merchant account currency).
        merchant_transaction_id: Unique merchant-side transaction ID.
        phone_number: Recipient phone number in international format (e.g. +2250707000001).
        amount: Transfer amount (min: 500, max: 1 500 000).
        payment_method: Payment method / operator (e.g. OM_CI, WAVE_SN).
        reason: Transfer reason / description.
        notify_url: Webhook notification URL for the final status.
    """

    currency: Currency
    merchant_transaction_id: str
    phone_number: str
    amount: int
    payment_method: PaymentMethod
    reason: str
    notify_url: str


@dataclass(frozen=True, slots=True)
class TransferResponse:
    """Response returned after creating a transfer.

    Attributes:
        code: Numeric API response code.
        status: Transaction status (PENDING, SUCCESS, FAILED).
        merchant_transaction_id: Merchant-side transaction ID.
        transaction_id: CinetPay transaction ID.
        notify_token: Notification token (for webhook verification).
        amount: Transfer amount as string.
        fee_amount: Fee amount as string.
        phone_number: Recipient phone number.
        currency: Transfer currency.
    """

    code: int
    status: TransactionStatus
    merchant_transaction_id: str
    transaction_id: str
    notify_token: str
    amount: str
    fee_amount: str
    phone_number: str
    currency: Currency


@dataclass(frozen=True, slots=True)
class TransferStatusUser:
    """User information in a transfer status response.

    Attributes:
        name: Full name.
        email: E-mail address.
        phone_number: Phone number.
    """

    name: str
    email: str
    phone_number: str


@dataclass(frozen=True, slots=True)
class TransferStatus:
    """Status of a transfer returned by ``client.transfer.get_status()``.

    Attributes:
        code: Numeric status code (100 = SUCCESS, 2010 = FAILED, etc.).
        status: Textual transaction status.
        merchant_transaction_id: Merchant-side transaction ID.
        transaction_id: CinetPay transaction ID.
        amount: Transfer amount as string.
        fee_amount: Fee amount as string.
        user: Recipient information (may be ``None``).
        phone_number: Recipient phone number (may be ``None``).
        currency: Transfer currency (may be ``None``).
    """

    code: int
    status: TransactionStatus
    merchant_transaction_id: str
    transaction_id: str
    amount: str
    fee_amount: str
    user: TransferStatusUser | None = None
    phone_number: str | None = None
    currency: Currency | None = None


# ---------------------------------------------------------------------------
# Serialization helpers
# ---------------------------------------------------------------------------


def serialize_transfer_request(req: TransferRequest) -> dict[str, Any]:
    """Serialize a :class:`TransferRequest` to the API format.

    Returns:
        Dict ready to be JSON-encoded and sent to ``POST /v1/transfer``.
    """
    return {
        "currency": req.currency,
        "merchant_transaction_id": req.merchant_transaction_id,
        "phone_number": req.phone_number,
        "amount": req.amount,
        "payment_method": req.payment_method,
        "reason": req.reason,
        "notify_url": req.notify_url,
    }


def to_transfer_response(raw: dict[str, Any]) -> TransferResponse:
    """Transform a raw API response dict into a typed :class:`TransferResponse`."""
    return TransferResponse(
        code=int(raw.get("code", 0)),
        status=raw.get("status", "PENDING"),
        merchant_transaction_id=str(raw.get("merchant_transaction_id", "")),
        transaction_id=str(raw.get("transaction_id", "")),
        notify_token=str(raw.get("notify_token", "")),
        amount=str(raw.get("amount", "")),
        fee_amount=str(raw.get("fee_amount", "")),
        phone_number=str(raw.get("phone_number", "")),
        currency=raw.get("currency", "XOF"),
    )


def to_transfer_status(raw: dict[str, Any]) -> TransferStatus:
    """Transform a raw API response dict into a typed :class:`TransferStatus`."""
    user_raw = raw.get("user")
    user: TransferStatusUser | None = None
    if isinstance(user_raw, dict):
        user = TransferStatusUser(
            name=str(user_raw.get("name", "")),
            email=str(user_raw.get("email", "")),
            phone_number=str(user_raw.get("phone_number", "")),
        )

    return TransferStatus(
        code=int(raw.get("code", 0)),
        status=raw.get("status", "PENDING"),
        merchant_transaction_id=str(raw.get("merchant_transaction_id", "")),
        transaction_id=str(raw.get("transaction_id", "")),
        amount=str(raw.get("amount", "")),
        fee_amount=str(raw.get("fee_amount", "")),
        user=user,
        phone_number=str(raw["phone_number"]) if raw.get("phone_number") else None,
        currency=raw.get("currency"),
    )
