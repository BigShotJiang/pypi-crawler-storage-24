"""Webhook payload types and deserialization helper."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True, slots=True)
class WebhookUser:
    """User information in a webhook notification.

    Attributes:
        name: Full name.
        email: E-mail address.
        phone_number: Phone number.
    """

    name: str
    email: str
    phone_number: str


@dataclass(frozen=True, slots=True)
class WebhookPayload:
    """Parsed webhook notification payload.

    Received via POST on your ``notify_url`` when a transaction reaches a final status.

    Attributes:
        notify_token: Notification token (compare with the one from initialization).
        merchant_transaction_id: Merchant-side transaction ID.
        transaction_id: CinetPay transaction ID.
        user: User information (may be ``None``).
    """

    notify_token: str
    merchant_transaction_id: str
    transaction_id: str
    user: WebhookUser | None = None


def to_webhook_payload(raw: dict[str, Any]) -> WebhookPayload:
    """Transform a raw webhook body dict into a typed :class:`WebhookPayload`."""
    user_raw = raw.get("user")
    user: WebhookUser | None = None
    if isinstance(user_raw, dict):
        user = WebhookUser(
            name=str(user_raw.get("name", "")),
            email=str(user_raw.get("email", "")),
            phone_number=str(user_raw.get("phone_number", "")),
        )

    return WebhookPayload(
        notify_token=str(raw.get("notify_token", "")),
        merchant_transaction_id=str(raw.get("merchant_transaction_id", "")),
        transaction_id=str(raw.get("transaction_id", "")),
        user=user,
    )
