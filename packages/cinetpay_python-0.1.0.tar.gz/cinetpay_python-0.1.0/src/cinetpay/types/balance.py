"""Balance type and deserialization helper."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from cinetpay.constants.currencies import Currency


@dataclass(frozen=True, slots=True)
class Balance:
    """Merchant account balance returned by ``client.balance.get()``.

    Attributes:
        code: HTTP response code.
        status: Textual response status.
        available_balance: Available balance (used for transfers).
        currency: Account currency.
    """

    code: int
    status: str
    available_balance: str
    currency: Currency


def to_balance(raw: dict[str, Any]) -> Balance:
    """Transform a raw API response dict into a typed :class:`Balance`."""
    return Balance(
        code=int(raw.get("code", 0)),
        status=str(raw.get("status", "")),
        available_balance=str(raw.get("available_balance", "")),
        currency=raw.get("currency", "XOF"),
    )
