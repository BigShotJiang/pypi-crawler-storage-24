"""Synchronous payment API — initialize payments and check status."""

from __future__ import annotations

from typing import Any
from urllib.parse import quote

from cinetpay.auth.authenticator import Authenticator
from cinetpay.errors.api_error import ApiError
from cinetpay.http.http_client import HttpClient
from cinetpay.types.payment import (
    PaymentRequest,
    PaymentResponse,
    PaymentStatus,
    serialize_payment_request,
    to_payment_response,
    to_payment_status,
)
from cinetpay.validation import validate_payment_request


class PaymentApi:
    """CinetPay web payment API.

    Accessible via ``client.payment``.

    Example::

        payment = client.payment.initialize(request, "CI")
        status = client.payment.get_status(payment.payment_token, "CI")
    """

    def __init__(
        self,
        http_client: HttpClient,
        authenticators: dict[str, Authenticator],
    ) -> None:
        self._http_client = http_client
        self._authenticators = authenticators

    def initialize(
        self,
        request: PaymentRequest,
        country: str,
    ) -> PaymentResponse:
        """Initialize a web payment transaction.

        Args:
            request: Payment parameters (amount, currency, URLs, customer, etc.).
            country: ISO country code (e.g. ``"CI"``, ``"SN"``).

        Returns:
            Response containing ``payment_url`` (redirect) and ``payment_token`` (status check).

        Raises:
            ApiError: If the API returns an error (e.g. TRANSACTION_EXIST).
            ValidationError: If a request field is invalid.
            TypeError: If the country is not configured.
        """
        validate_payment_request(request)
        auth = self._resolve_authenticator(country)
        body = serialize_payment_request(request)

        try:
            token = auth.get_token()
            raw: dict[str, Any] = self._http_client.post("/v1/payment", body, token)
            return to_payment_response(raw)
        except ApiError as exc:
            if _is_token_expired(exc):
                token = auth.force_refresh()
                raw = self._http_client.post("/v1/payment", body, token)
                return to_payment_response(raw)
            raise

    def get_status(
        self,
        identifier: str,
        country: str,
    ) -> PaymentStatus:
        """Retrieve the current status of a payment.

        Args:
            identifier: ``payment_token``, ``transaction_id``, or ``merchant_transaction_id``.
            country: ISO country code (e.g. ``"CI"``, ``"SN"``).

        Returns:
            Transaction status with user information.

        Raises:
            ApiError: If the transaction is not found (NOT_FOUND).
        """
        auth = self._resolve_authenticator(country)
        path = f"/v1/payment/{quote(identifier, safe='')}"

        try:
            token = auth.get_token()
            raw: dict[str, Any] = self._http_client.get(path, token)
            return to_payment_status(raw)
        except ApiError as exc:
            if _is_token_expired(exc):
                token = auth.force_refresh()
                raw = self._http_client.get(path, token)
                return to_payment_status(raw)
            raise

    def _resolve_authenticator(self, country: str) -> Authenticator:
        key = country.upper()
        auth = self._authenticators.get(key)
        if auth is None:
            available = ", ".join(self._authenticators.keys())
            raise TypeError(
                f'No credentials configured for country "{key}". Available: {available}'
            )
        return auth


def _is_token_expired(error: ApiError) -> bool:
    return error.api_code == 1003 or error.api_status == "EXPIRED_TOKEN"
