"""Synchronous balance API — retrieve merchant account balance."""

from __future__ import annotations

from typing import Any

from cinetpay.auth.authenticator import Authenticator
from cinetpay.errors.api_error import ApiError
from cinetpay.http.http_client import HttpClient
from cinetpay.types.balance import Balance, to_balance


class BalanceApi:
    """CinetPay merchant balance API.

    Accessible via ``client.balance``.

    Example::

        balance = client.balance.get("CI")
        print(balance.available_balance)  # "249711.74"
    """

    def __init__(
        self,
        http_client: HttpClient,
        authenticators: dict[str, Authenticator],
    ) -> None:
        self._http_client = http_client
        self._authenticators = authenticators

    def get(self, country: str) -> Balance:
        """Retrieve the available balance for a merchant account.

        Args:
            country: ISO country code (e.g. ``"CI"``, ``"SN"``).

        Returns:
            Balance with available amount and currency.

        Raises:
            ApiError: If authentication fails.
            TypeError: If the country is not configured.
        """
        auth = self._resolve_authenticator(country)

        try:
            token = auth.get_token()
            raw: dict[str, Any] = self._http_client.get("/v1/balances", token)
            return to_balance(raw)
        except ApiError as exc:
            if _is_token_expired(exc):
                token = auth.force_refresh()
                raw = self._http_client.get("/v1/balances", token)
                return to_balance(raw)
            raise

    def _resolve_authenticator(self, country: str) -> Authenticator:
        key = country.upper()
        auth = self._authenticators.get(key)
        if auth is None:
            available = ", ".join(self._authenticators.keys())
            raise TypeError(
                f'No credentials configured for country "{key}". Available: {available}'
            )
        return auth


def _is_token_expired(error: ApiError) -> bool:
    return error.api_code == 1003 or error.api_status == "EXPIRED_TOKEN"
