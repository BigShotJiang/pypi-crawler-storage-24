"""Asynchronous transfer API — create transfers and check status."""

from __future__ import annotations

from typing import Any
from urllib.parse import quote

from cinetpay.auth.async_authenticator import AsyncAuthenticator
from cinetpay.errors.api_error import ApiError
from cinetpay.http.async_http_client import AsyncHttpClient
from cinetpay.types.transfer import (
    TransferRequest,
    TransferResponse,
    TransferStatus,
    serialize_transfer_request,
    to_transfer_response,
    to_transfer_status,
)
from cinetpay.validation import validate_transfer_request


class AsyncTransferApi:
    """Async CinetPay money transfer API.

    Accessible via ``client.transfer``.

    Example::

        transfer = await client.transfer.create(request, "CI")
        status = await client.transfer.get_status(transfer.transaction_id, "CI")
    """

    def __init__(
        self,
        http_client: AsyncHttpClient,
        authenticators: dict[str, AsyncAuthenticator],
    ) -> None:
        self._http_client = http_client
        self._authenticators = authenticators

    async def create(
        self,
        request: TransferRequest,
        country: str,
    ) -> TransferResponse:
        """Create a money transfer to a mobile money number.

        Args:
            request: Transfer parameters (amount, currency, phone, operator, etc.).
            country: ISO country code (e.g. ``"CI"``, ``"SN"``).

        Returns:
            Response containing initial status and transaction identifiers.

        Raises:
            ApiError: If the API returns an error (e.g. INSUFFICIENT_BALANCE).
            ValidationError: If a request field is invalid.
            TypeError: If the country is not configured.
        """
        validate_transfer_request(request)
        auth = self._resolve_authenticator(country)
        body = serialize_transfer_request(request)

        try:
            token = await auth.get_token()
            raw: dict[str, Any] = await self._http_client.post("/v1/transfer", body, token)
            return to_transfer_response(raw)
        except ApiError as exc:
            if _is_token_expired(exc):
                token = await auth.force_refresh()
                raw = await self._http_client.post("/v1/transfer", body, token)
                return to_transfer_response(raw)
            raise

    async def get_status(
        self,
        transaction_id: str,
        country: str,
    ) -> TransferStatus:
        """Retrieve the current status of a transfer.

        Args:
            transaction_id: CinetPay transaction ID or ``merchant_transaction_id``.
            country: ISO country code (e.g. ``"CI"``, ``"SN"``).

        Returns:
            Transfer status with recipient information.

        Raises:
            ApiError: If the transaction is not found (NOT_FOUND).
        """
        auth = self._resolve_authenticator(country)
        path = f"/v1/transfer/{quote(transaction_id, safe='')}"

        try:
            token = await auth.get_token()
            raw: dict[str, Any] = await self._http_client.get(path, token)
            return to_transfer_status(raw)
        except ApiError as exc:
            if _is_token_expired(exc):
                token = await auth.force_refresh()
                raw = await self._http_client.get(path, token)
                return to_transfer_status(raw)
            raise

    def _resolve_authenticator(self, country: str) -> AsyncAuthenticator:
        key = country.upper()
        auth = self._authenticators.get(key)
        if auth is None:
            available = ", ".join(self._authenticators.keys())
            raise TypeError(
                f'No credentials configured for country "{key}". Available: {available}'
            )
        return auth


def _is_token_expired(error: ApiError) -> bool:
    return error.api_code == 1003 or error.api_status == "EXPIRED_TOKEN"
