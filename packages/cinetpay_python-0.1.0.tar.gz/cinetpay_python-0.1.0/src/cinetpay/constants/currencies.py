"""Supported currencies for CinetPay transactions (XOF, XAF, GNF, CDF, USD)."""

from __future__ import annotations
from typing import Literal

Currency = Literal["XOF", "XAF", "GNF", "CDF", "USD"]

CURRENCIES: dict[str, Currency] = {
    "XOF": "XOF",
    "XAF": "XAF",
    "GNF": "GNF",
    "CDF": "CDF",
    "USD": "USD",
}
