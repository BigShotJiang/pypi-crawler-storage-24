"""Mobile money payment methods by operator and country (e.g. OM_CI, WAVE_SN)."""

from __future__ import annotations
from typing import Literal

PaymentMethod = Literal[
    "OM_CI", "MOOV_CI", "MTN_CI", "WAVE_CI",
    "OM_BF", "MOOV_BF", "WAVE_BF",
    "OM_ML", "MOOV_ML",
    "OM_SN", "FREE_SN", "EXPRESSO_SN", "WAVE_SN",
    "MOOV_TG", "TMONEY_TG",
    "OM_GN", "MTN_GN",
    "OM_CM", "MTN_CM",
    "MOOV_BJ", "MTN_BJ",
    "OM_CD", "AIRTEL_CD", "MPESA_CD", "AFRICELL_CD",
    "AIRTEL_NE", "MOOV_NE", "ZAMANI_NE",
]

PAYMENT_METHODS: dict[str, PaymentMethod] = {
    "OM_CI": "OM_CI", "MOOV_CI": "MOOV_CI", "MTN_CI": "MTN_CI", "WAVE_CI": "WAVE_CI",
    "OM_BF": "OM_BF", "MOOV_BF": "MOOV_BF", "WAVE_BF": "WAVE_BF",
    "OM_ML": "OM_ML", "MOOV_ML": "MOOV_ML",
    "OM_SN": "OM_SN", "FREE_SN": "FREE_SN", "EXPRESSO_SN": "EXPRESSO_SN", "WAVE_SN": "WAVE_SN",
    "MOOV_TG": "MOOV_TG", "TMONEY_TG": "TMONEY_TG",
    "OM_GN": "OM_GN", "MTN_GN": "MTN_GN",
    "OM_CM": "OM_CM", "MTN_CM": "MTN_CM",
    "MOOV_BJ": "MOOV_BJ", "MTN_BJ": "MTN_BJ",
    "OM_CD": "OM_CD", "AIRTEL_CD": "AIRTEL_CD", "MPESA_CD": "MPESA_CD", "AFRICELL_CD": "AFRICELL_CD",
    "AIRTEL_NE": "AIRTEL_NE", "MOOV_NE": "MOOV_NE", "ZAMANI_NE": "ZAMANI_NE",
}

PAYMENT_METHODS_BY_COUNTRY: dict[str, tuple[PaymentMethod, ...]] = {
    "CI": ("OM_CI", "MOOV_CI", "MTN_CI", "WAVE_CI"),
    "BF": ("OM_BF", "MOOV_BF", "WAVE_BF"),
    "ML": ("OM_ML", "MOOV_ML"),
    "SN": ("OM_SN", "FREE_SN", "EXPRESSO_SN", "WAVE_SN"),
    "TG": ("MOOV_TG", "TMONEY_TG"),
    "GN": ("OM_GN", "MTN_GN"),
    "CM": ("OM_CM", "MTN_CM"),
    "BJ": ("MOOV_BJ", "MTN_BJ"),
    "CD": ("OM_CD", "AIRTEL_CD", "MPESA_CD", "AFRICELL_CD"),
    "NE": ("AIRTEL_NE", "MOOV_NE", "ZAMANI_NE"),
}
