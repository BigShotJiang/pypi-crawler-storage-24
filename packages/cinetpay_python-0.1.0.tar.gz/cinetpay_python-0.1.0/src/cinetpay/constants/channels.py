"""Payment channels supported by CinetPay (PUSH, OTP, QRCODE)."""

from __future__ import annotations
from typing import Literal

Channel = Literal["PUSH", "OTP", "QRCODE"]

CHANNELS: dict[str, Channel] = {
    "PUSH": "PUSH",
    "OTP": "OTP",
    "QRCODE": "QRCODE",
}
