"""Asynchronous CinetPay client — async entry point of the SDK."""

from __future__ import annotations

from urllib.parse import urlparse

from cinetpay.api.async_balance import AsyncBalanceApi
from cinetpay.api.async_payment import AsyncPaymentApi
from cinetpay.api.async_transfer import AsyncTransferApi
from cinetpay.auth.async_authenticator import AsyncAuthenticator
from cinetpay.auth.token_store import MemoryTokenStore
from cinetpay.http.async_http_client import AsyncHttpClient
from cinetpay.logger import LoggerProtocol, NoopLogger, StandardLibLogger
from cinetpay.types.config import (
    API_KEY_PREFIX_LIVE,
    API_KEY_PREFIX_TEST,
    AsyncTokenStoreProtocol,
    ClientConfig,
    CountryCredentials,
    DEFAULT_BASE_URL,
    DEFAULT_TIMEOUT,
    DEFAULT_TOKEN_TTL,
    PRODUCTION_BASE_URL,
)

# Hostnames allowed for the base URL (SSRF protection)
_ALLOWED_HOSTS = frozenset({
    "api.cinetpay.net",   # Sandbox
    "api.cinetpay.co",    # Production
    "localhost",
    "127.0.0.1",
})


class _AsyncMemoryTokenStore:
    """Async adapter around the sync :class:`MemoryTokenStore`."""

    def __init__(self) -> None:
        self._store = MemoryTokenStore()

    async def get(self, key: str) -> str | None:
        """Retrieve a token from the in-memory cache.

        Args:
            key: Cache key (e.g. ``cinetpay_token_ci``).

        Returns:
            The token string, or ``None`` if absent or expired.
        """
        return self._store.get(key)

    async def set(self, key: str, value: str, ttl_seconds: int) -> None:
        """Store a token with a time-to-live.

        Args:
            key: Cache key.
            value: JWT token string.
            ttl_seconds: Time-to-live in seconds.
        """
        self._store.set(key, value, ttl_seconds)

    async def delete(self, key: str) -> None:
        """Remove a token from the in-memory cache.

        Args:
            key: Cache key to delete.
        """
        self._store.delete(key)


class AsyncCinetPayClient:
    """Asynchronous CinetPay SDK client.

    Equivalent of :class:`~cinetpay.client.CinetPayClient` for async contexts
    (FastAPI, aiohttp, etc.).

    Example::

        from cinetpay import AsyncCinetPayClient, ClientConfig, CountryCredentials

        async with AsyncCinetPayClient(ClientConfig(
            credentials={
                "CI": CountryCredentials(api_key="sk_test_...", api_password="..."),
            },
        )) as client:
            balance = await client.balance.get("CI")

    Attributes:
        payment: Async web payment API (initialize, get_status).
        transfer: Async money transfer API (create, get_status).
        balance: Async merchant balance API (get).
    """

    payment: AsyncPaymentApi
    """Async web payment API -- initialization and status check."""

    transfer: AsyncTransferApi
    """Async money transfer API -- send and check status."""

    balance: AsyncBalanceApi
    """Async merchant account balance API."""

    def __init__(self, config: ClientConfig) -> None:
        credentials = config.credentials
        if not credentials:
            raise TypeError(
                "At least one country credential must be provided in config.credentials"
            )

        token_ttl = config.token_ttl if config.token_ttl is not None else DEFAULT_TOKEN_TTL
        timeout = config.timeout if config.timeout is not None else DEFAULT_TIMEOUT

        # For async, we need an async-compatible token store
        async_token_store: AsyncTokenStoreProtocol
        if config.token_store is not None and isinstance(config.token_store, AsyncTokenStoreProtocol):
            async_token_store = config.token_store  # type: ignore[assignment]
        else:
            async_token_store = _AsyncMemoryTokenStore()

        # Resolve logger
        logger: LoggerProtocol
        if config.logger is not None:
            logger = config.logger
        elif config.debug:
            logger = StandardLibLogger()
        else:
            logger = NoopLogger()

        # Detect environment
        entries = list(credentials.items())
        detected_env = _detect_environment(entries, logger)

        # Resolve base URL
        if config.base_url is not None:
            base_url = config.base_url
        elif detected_env == "live":
            base_url = PRODUCTION_BASE_URL
        else:
            base_url = DEFAULT_BASE_URL

        # Validate coherence
        _validate_key_url_coherence(detected_env, base_url, logger)

        # Enforce HTTPS
        parsed = urlparse(base_url)
        if parsed.scheme != "https" and parsed.hostname not in ("localhost", "127.0.0.1"):
            raise TypeError(
                "base_url must use HTTPS for security. "
                "Use https:// or localhost for development."
            )

        # SSRF protection
        if parsed.hostname and not any(
            parsed.hostname == h or parsed.hostname.endswith(f".{h}")
            for h in _ALLOWED_HOSTS
        ):
            logger.warn(
                f'base_url hostname "{parsed.hostname}" is not a known CinetPay domain. '
                f"Expected: {', '.join(sorted(_ALLOWED_HOSTS))}. Proceeding anyway."
            )

        if not parsed.scheme or not parsed.hostname:
            raise TypeError(f'base_url "{base_url}" is not a valid URL.')

        # Build async HTTP client and authenticators
        http_client = AsyncHttpClient(base_url, timeout, logger)

        self._authenticators: dict[str, AsyncAuthenticator] = {}
        for country, creds in entries:
            key = country.upper()
            self._authenticators[key] = AsyncAuthenticator(
                http_client, key, creds, token_ttl, async_token_store, logger,
            )

        self.payment = AsyncPaymentApi(http_client, self._authenticators)
        self.transfer = AsyncTransferApi(http_client, self._authenticators)
        self.balance = AsyncBalanceApi(http_client, self._authenticators)

        self._http_client = http_client
        self._logger = logger

        logger.debug("AsyncCinetPayClient initialized", {
            "countries": self.countries(),
            "base_url": base_url,
            "token_ttl": token_ttl,
            "timeout": timeout,
        })

    def countries(self) -> list[str]:
        """Return the list of configured country codes."""
        return list(self._authenticators.keys())

    async def revoke_token(self, country: str) -> None:
        """Revoke the cached JWT token for a country.

        Args:
            country: ISO country code (e.g. ``"CI"``).

        Raises:
            TypeError: If the country is not configured.
        """
        key = country.upper()
        auth = self._authenticators.get(key)
        if auth is None:
            raise TypeError(
                f'No credentials configured for country "{key}". '
                f"Available: {', '.join(self.countries())}"
            )
        await auth.clear_cache()

    async def revoke_all_tokens(self) -> None:
        """Revoke all cached JWT tokens for all configured countries."""
        for auth in self._authenticators.values():
            await auth.clear_cache()

    async def close(self) -> None:
        """Close the underlying async HTTP client and release resources."""
        await self._http_client.close()

    async def __aenter__(self) -> AsyncCinetPayClient:
        return self

    async def __aexit__(self, *args: object) -> None:
        await self.close()

    def __repr__(self) -> str:
        """Prevent credential leakage via repr()."""
        return f"AsyncCinetPayClient(countries={self.countries()!r})"


# ---------------------------------------------------------------------------
# Private helpers (shared logic with sync client)
# ---------------------------------------------------------------------------


def _detect_environment(
    entries: list[tuple[str, CountryCredentials]],
    logger: LoggerProtocol,
) -> str:
    """Detect test/live/mixed/unknown from API key prefixes."""
    envs: set[str] = set()
    for country, creds in entries:
        if creds.api_key.startswith(API_KEY_PREFIX_TEST):
            envs.add("test")
        elif creds.api_key.startswith(API_KEY_PREFIX_LIVE):
            envs.add("live")
        else:
            logger.warn(
                f'API key for country {country.upper()} does not start with '
                f'"{API_KEY_PREFIX_TEST}" or "{API_KEY_PREFIX_LIVE}". '
                f"Expected format: sk_test_... (sandbox) or sk_live_... (production)."
            )
            envs.add("unknown")

    if "test" in envs and "live" in envs:
        logger.error(
            "MIXED ENVIRONMENTS: some credentials use sk_test_ (sandbox) and "
            "others use sk_live_ (production). This will cause authentication "
            "failures. Use the same environment for all countries."
        )
        return "mixed"

    if "live" in envs:
        return "live"
    if "test" in envs:
        return "test"
    return "unknown"


def _validate_key_url_coherence(
    detected_env: str,
    base_url: str,
    logger: LoggerProtocol,
) -> None:
    """Warn if API key type and base URL are mismatched."""
    is_sandbox_url = "cinetpay.net" in base_url
    is_production_url = "cinetpay.co" in base_url

    if detected_env == "live" and is_sandbox_url:
        logger.error(
            f"ENVIRONMENT MISMATCH: production keys (sk_live_) are used with "
            f'sandbox URL ({base_url}). Use base_url="{PRODUCTION_BASE_URL}" '
            f"for production, or remove base_url to auto-detect."
        )
    if detected_env == "test" and is_production_url:
        logger.error(
            f"ENVIRONMENT MISMATCH: sandbox keys (sk_test_) are used with "
            f'production URL ({base_url}). Use base_url="{DEFAULT_BASE_URL}" '
            f"for sandbox, or remove base_url to auto-detect."
        )
