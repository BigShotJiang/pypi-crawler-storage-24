"""Webhook notification verification and parsing.

Provides timing-safe token comparison (via :func:`hmac.compare_digest`) and
a helper to parse raw webhook bodies into typed dataclasses.
"""

from __future__ import annotations

import hmac
import json
from typing import Any

from cinetpay.types.webhook import WebhookPayload, to_webhook_payload


def verify_notification(expected_token: str, received_token: str) -> bool:
    """Verify a webhook notification token using timing-safe comparison.

    Compares the ``notify_token`` stored from payment/transfer initialization
    with the one received in the webhook body.

    **Server-side only.**

    Args:
        expected_token: The ``notify_token`` from the initialization response.
        received_token: The ``notify_token`` from the webhook request body.

    Returns:
        ``True`` if the tokens match.

    Example::

        from cinetpay import verify_notification

        is_valid = verify_notification(stored_notify_token, payload.notify_token)
        if not is_valid:
            return HttpResponse(status=401)
    """
    return hmac.compare_digest(expected_token, received_token)


def parse_notification(body: str | dict[str, Any]) -> WebhookPayload:
    """Parse a raw webhook body into a typed :class:`WebhookPayload`.

    Accepts either a JSON string or an already-parsed dict.

    Args:
        body: Webhook request body (string or dict).

    Returns:
        Typed :class:`WebhookPayload` with ``notify_token``, ``transaction_id``,
        ``merchant_transaction_id``, and optionally ``user``.

    Raises:
        TypeError: If required fields (``notify_token``, ``transaction_id``) are missing.
        json.JSONDecodeError: If a string body is not valid JSON.

    Example::

        from cinetpay import parse_notification

        # Django
        payload = parse_notification(request.body)
        print(payload.transaction_id)

        # Flask
        payload = parse_notification(request.get_json())
    """
    if isinstance(body, str):
        data: dict[str, Any] = json.loads(body)
    else:
        data = body

    if not data.get("notify_token") or not data.get("transaction_id"):
        raise TypeError(
            "Invalid webhook payload: missing notify_token or transaction_id"
        )

    return to_webhook_payload(data)
