"""Input validation for payment and transfer requests."""

from __future__ import annotations

import re

from cinetpay.constants.channels import CHANNELS
from cinetpay.constants.currencies import CURRENCIES
from cinetpay.constants.payment_methods import PAYMENT_METHODS
from cinetpay.types.payment import PaymentRequest
from cinetpay.types.transfer import TransferRequest

# ---------------------------------------------------------------------------
# Compiled regexes
# ---------------------------------------------------------------------------

_EMAIL_RE = re.compile(r"^[^\s@]+@[^\s@]+\.[^\s@]+$")
_PHONE_RE = re.compile(r"^\+\d{8,15}$")
_OTP_RE = re.compile(r"^\d{4,6}$")

# Pre-built sets for fast membership tests
_CURRENCY_VALUES = frozenset(CURRENCIES.values())
_CHANNEL_VALUES = frozenset(CHANNELS.values())
_PAYMENT_METHOD_VALUES = frozenset(PAYMENT_METHODS.values())
_LANG_VALUES = frozenset({"fr", "en"})


# ---------------------------------------------------------------------------
# Exception
# ---------------------------------------------------------------------------


class ValidationError(ValueError):
    """Raised when a request field fails validation.

    Inherits from :class:`ValueError` so that it can be caught with a broad
    ``except ValueError`` if desired.
    """

    def __init__(self, field: str, message: str) -> None:
        super().__init__(f"[{field}] {message}")
        self.field: str = field


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _assert_string(field: str, value: str, min_len: int, max_len: int) -> None:
    if not isinstance(value, str) or not (min_len <= len(value) <= max_len):
        got = len(value) if isinstance(value, str) else type(value).__name__
        raise ValidationError(
            field,
            f"must be a string between {min_len} and {max_len} characters (got {got})",
        )


def _assert_enum(field: str, value: str, allowed: frozenset[str]) -> None:
    if value not in allowed:
        raise ValidationError(
            field,
            f"must be one of: {', '.join(sorted(allowed))} (got \"{value}\")",
        )


def _assert_amount(field: str, value: int, min_val: int, max_val: int) -> None:
    if not isinstance(value, int) or value < min_val or value > max_val:
        raise ValidationError(
            field,
            f"must be an integer between {min_val} and {max_val} (got {value})",
        )


def _assert_url(field: str, value: str, max_length: int) -> None:
    _assert_string(field, value, 1, max_length)
    if not (value.startswith("http://") or value.startswith("https://")):
        raise ValidationError(
            field,
            "must be a valid URL starting with http:// or https://",
        )


def _assert_email(field: str, value: str) -> None:
    if not isinstance(value, str) or not _EMAIL_RE.match(value):
        raise ValidationError(field, f'must be a valid email address (got "{value}")')


def _assert_phone(field: str, value: str) -> None:
    if not _PHONE_RE.match(value):
        raise ValidationError(
            field,
            f'must be in international format +XXXXXXXXXXXX (got "{value}")',
        )


# ---------------------------------------------------------------------------
# Public validators
# ---------------------------------------------------------------------------


def validate_payment_request(req: PaymentRequest) -> None:
    """Validate a :class:`PaymentRequest` before sending it to the API.

    Args:
        req: The payment request to validate.

    Raises:
        ValidationError: If any field is invalid.
    """
    _assert_enum("currency", req.currency, _CURRENCY_VALUES)
    _assert_string("merchant_transaction_id", req.merchant_transaction_id, 1, 30)
    _assert_amount("amount", req.amount, 100, 2_500_000)
    _assert_enum("lang", req.lang, _LANG_VALUES)
    _assert_string("designation", req.designation, 1, 255)
    _assert_email("client_email", req.client_email)
    _assert_string("client_first_name", req.client_first_name, 2, 255)
    _assert_string("client_last_name", req.client_last_name, 2, 255)
    _assert_url("success_url", req.success_url, 120)
    _assert_url("failed_url", req.failed_url, 120)
    _assert_url("notify_url", req.notify_url, 120)
    _assert_enum("channel", req.channel, _CHANNEL_VALUES)

    if req.payment_method is not None:
        _assert_enum("payment_method", req.payment_method, _PAYMENT_METHOD_VALUES)

    if req.client_phone_number is not None:
        _assert_phone("client_phone_number", req.client_phone_number)

    if req.otp_code is not None:
        if not isinstance(req.otp_code, str) or not _OTP_RE.match(req.otp_code):
            raise ValidationError("otp_code", "must be 4 to 6 digits")

    # Direct pay requires phone_number and payment_method
    if req.direct_pay is True:
        if not req.client_phone_number:
            raise ValidationError(
                "client_phone_number",
                "is required when direct_pay is True",
            )
        if not req.payment_method:
            raise ValidationError(
                "payment_method",
                "is required when direct_pay is True",
            )


def validate_transfer_request(req: TransferRequest) -> None:
    """Validate a :class:`TransferRequest` before sending it to the API.

    Args:
        req: The transfer request to validate.

    Raises:
        ValidationError: If any field is invalid.
    """
    _assert_enum("currency", req.currency, _CURRENCY_VALUES)
    _assert_string("merchant_transaction_id", req.merchant_transaction_id, 1, 30)
    _assert_amount("amount", req.amount, 100, 1_500_000)
    _assert_enum("payment_method", req.payment_method, _PAYMENT_METHOD_VALUES)
    _assert_string("reason", req.reason, 1, 255)
    _assert_url("notify_url", req.notify_url, 120)
    _assert_phone("phone_number", req.phone_number)
