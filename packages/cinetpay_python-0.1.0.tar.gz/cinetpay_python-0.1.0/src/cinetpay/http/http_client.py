"""Synchronous HTTP client wrapping :mod:`httpx`."""

from __future__ import annotations

from typing import Any

import httpx

from cinetpay.errors.api_error import ApiError
from cinetpay.errors.network_errors import NetworkError, TimeoutError
from cinetpay.logger import LoggerProtocol

# Fields whose values must be masked in log output
_SENSITIVE_KEYWORDS = frozenset({"password", "secret", "token", "api_key"})


class HttpClient:
    """Internal synchronous HTTP client.

    Wraps :class:`httpx.Client` with JSON defaults, timeout, Bearer auth,
    sensitive field sanitization in logs, and error mapping to SDK exceptions.

    .. note::
        Internal — used by :class:`~cinetpay.client.CinetPayClient`.
    """

    def __init__(
        self,
        base_url: str,
        timeout: float,
        logger: LoggerProtocol,
    ) -> None:
        self._base_url = base_url
        self._timeout = timeout
        self._logger = logger
        self._client = httpx.Client(
            base_url=base_url,
            timeout=httpx.Timeout(timeout),
            headers={
                "Accept": "application/json",
                "Content-Type": "application/json",
            },
        )

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def post(self, path: str, body: Any, token: str | None = None) -> dict[str, Any]:
        """Send a POST request and return the parsed JSON response.

        Args:
            path: API path (e.g. ``/v1/payment``).
            body: Request body (will be JSON-encoded).
            token: Optional JWT Bearer token.

        Returns:
            Parsed JSON response as a dict.

        Raises:
            ApiError: If the API returns an error.
            NetworkError: If the HTTP request fails.
            TimeoutError: If the request exceeds the configured timeout.
        """
        return self._request("POST", path, body=body, token=token)

    def get(self, path: str, token: str | None = None) -> dict[str, Any]:
        """Send a GET request and return the parsed JSON response.

        Args:
            path: API path (e.g. ``/v1/balances``).
            token: Optional JWT Bearer token.

        Returns:
            Parsed JSON response as a dict.

        Raises:
            ApiError: If the API returns an error.
            NetworkError: If the HTTP request fails.
            TimeoutError: If the request exceeds the configured timeout.
        """
        return self._request("GET", path, token=token)

    def close(self) -> None:
        """Close the underlying :class:`httpx.Client`."""
        self._client.close()

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    def _request(
        self,
        method: str,
        path: str,
        body: Any = None,
        token: str | None = None,
    ) -> dict[str, Any]:
        headers: dict[str, str] = {}
        if token:
            headers["Authorization"] = f"Bearer {token}"

        if body is not None:
            self._logger.debug(f"{method} {path}", {"body": _sanitize_body(body)})
        else:
            self._logger.debug(f"{method} {path}")

        try:
            response = self._client.request(
                method,
                path,
                json=body,
                headers=headers,
            )
            data: dict[str, Any] = response.json()

            self._logger.debug(
                f"{method} {path} -> {response.status_code}",
                {"code": data.get("code"), "status": data.get("status")},
            )

            return self._handle_response(data, response.status_code, method, path)

        except ApiError:
            raise
        except httpx.TimeoutException:
            self._logger.error(f"{method} {path} -> timeout ({self._timeout}s)")
            raise TimeoutError(self._timeout) from None
        except httpx.HTTPError as exc:
            self._logger.error(
                f"{method} {path} -> network error",
                {"message": str(exc)},
            )
            raise NetworkError(f"Request to {method} {path} failed", exc) from exc

    def _handle_response(
        self,
        data: dict[str, Any],
        http_status: int,
        method: str,
        path: str,
    ) -> dict[str, Any]:
        code = data.get("code")

        if http_status >= 400 or (
            code is not None
            and code not in (200, 100, 2001, 2002)
        ):
            if data.get("description") or (code is not None and http_status >= 400):
                error = ApiError.from_response(data)
                self._logger.error(
                    f"{method} {path} -> API error",
                    {
                        "api_code": error.api_code,
                        "api_status": error.api_status,
                        "description": error.description,
                    },
                )
                raise error

        return data


def _sanitize_body(body: Any) -> Any:
    """Mask sensitive fields (credentials, tokens) in log output."""
    if not isinstance(body, dict):
        return body
    sanitized = dict(body)
    for key in sanitized:
        lower = key.lower()
        if any(kw in lower for kw in _SENSITIVE_KEYWORDS):
            sanitized[key] = "***"
    return sanitized
