"""Network and timeout errors."""

from __future__ import annotations

from cinetpay.errors.base import CinetPayError


class NetworkError(CinetPayError):
    """Raised when an HTTP request fails (DNS, connection refused, etc.).

    Attributes:
        cause: The original exception that triggered the network failure.
    """

    def __init__(self, message: str, cause: BaseException | None = None) -> None:
        super().__init__(message)
        self.cause: BaseException | None = cause


class TimeoutError(CinetPayError):  # noqa: A001 — intentional shadow of builtins.TimeoutError
    """Raised when an HTTP request exceeds the configured timeout.

    Attributes:
        timeout_seconds: The timeout value in seconds.
    """

    def __init__(self, timeout_seconds: float) -> None:
        super().__init__(f"Request timed out after {timeout_seconds}s")
        self.timeout_seconds: float = timeout_seconds
