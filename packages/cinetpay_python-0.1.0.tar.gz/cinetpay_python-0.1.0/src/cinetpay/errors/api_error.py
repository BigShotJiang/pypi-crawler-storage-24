"""API error returned by the CinetPay backend."""

from __future__ import annotations

from typing import Any

from cinetpay.errors.base import CinetPayError


class ApiError(CinetPayError):
    """Error returned by the CinetPay API (code + status + description).

    Example::

        try:
            client.payment.initialize(request, "CI")
        except ApiError as exc:
            print(exc.api_code)     # 1200
            print(exc.api_status)   # "TRANSACTION_EXIST"
            print(exc.description)  # "La transaction existe deja"
    """

    __slots__ = ("api_code", "api_status", "description")

    def __init__(self, api_code: int, api_status: str, description: str) -> None:
        super().__init__(f"[{api_code}] {api_status}: {description}")
        self.api_code: int = api_code
        self.api_status: str = api_status
        self.description: str = description

    @classmethod
    def from_response(cls, data: dict[str, Any]) -> ApiError:
        """Build an :class:`ApiError` from a raw API response dict.

        Args:
            data: Raw JSON-decoded response body.

        Returns:
            A new :class:`ApiError` instance.
        """
        return cls(
            api_code=int(data.get("code", 0)),
            api_status=str(data.get("status", "UNKNOWN")),
            description=str(data.get("description") or data.get("message") or ""),
        )
