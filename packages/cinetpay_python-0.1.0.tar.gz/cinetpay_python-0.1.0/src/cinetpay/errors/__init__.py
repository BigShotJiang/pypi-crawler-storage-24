"""CinetPay SDK error hierarchy."""

from cinetpay.errors.api_error import ApiError
from cinetpay.errors.auth_error import AuthenticationError
from cinetpay.errors.base import CinetPayError
from cinetpay.errors.network_errors import NetworkError, TimeoutError

__all__ = [
    "ApiError",
    "AuthenticationError",
    "CinetPayError",
    "NetworkError",
    "TimeoutError",
]
