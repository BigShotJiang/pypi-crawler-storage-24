"""Authentication error — invalid credentials or missing JWT token."""

from __future__ import annotations

from cinetpay.errors.base import CinetPayError


class AuthenticationError(CinetPayError):
    """Raised when API credentials are invalid or the API did not return a JWT token."""

    def __init__(self, message: str = "Authentication failed") -> None:
        super().__init__(message)
