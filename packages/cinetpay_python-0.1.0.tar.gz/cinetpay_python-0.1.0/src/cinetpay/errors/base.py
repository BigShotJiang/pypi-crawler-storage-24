"""Base exception for the CinetPay SDK."""

from __future__ import annotations


class CinetPayError(Exception):
    """Base class for all CinetPay SDK errors.

    All SDK errors inherit from this class, allowing a simple catch-all::

        try:
            client.payment.initialize(request, "CI")
        except CinetPayError as exc:
            ...
    """

    def __init__(self, message: str) -> None:
        super().__init__(message)
