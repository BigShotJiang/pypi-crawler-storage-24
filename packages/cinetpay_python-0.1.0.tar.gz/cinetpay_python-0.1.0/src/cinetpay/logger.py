"""Pluggable logging interface for the CinetPay SDK."""

from __future__ import annotations

import logging
from typing import Any, Protocol, runtime_checkable


@runtime_checkable
class LoggerProtocol(Protocol):
    """Interface for injectable loggers.

    Implement this protocol to plug in your own logger (structlog, loguru, etc.)::

        import structlog

        log = structlog.get_logger()
        client = CinetPayClient(
            credentials={...},
            logger=MyStructlogAdapter(log),
        )
    """

    def debug(self, message: str, data: dict[str, Any] | None = None) -> None:
        """Log request/response details, cached tokens, etc."""
        ...

    def warn(self, message: str, data: dict[str, Any] | None = None) -> None:
        """Log token refresh retries, fallbacks."""
        ...

    def error(self, message: str, data: dict[str, Any] | None = None) -> None:
        """Log API errors, network errors, timeouts."""
        ...


class StandardLibLogger:
    """Logger backed by the Python standard library :mod:`logging`.

    Writes messages with a ``[cinetpay]`` prefix. Used when ``debug=True``
    is passed without a custom logger.
    """

    def __init__(self, name: str = "cinetpay") -> None:
        self._logger = logging.getLogger(name)

    def debug(self, message: str, data: dict[str, Any] | None = None) -> None:
        """Log a debug-level message with optional structured data."""
        self._logger.debug("[cinetpay] %s %s", message, data or "")

    def warn(self, message: str, data: dict[str, Any] | None = None) -> None:
        """Log a warning-level message with optional structured data."""
        self._logger.warning("[cinetpay] %s %s", message, data or "")

    def error(self, message: str, data: dict[str, Any] | None = None) -> None:
        """Log an error-level message with optional structured data."""
        self._logger.error("[cinetpay] %s %s", message, data or "")


class NoopLogger:
    """Silent logger — produces no output. Used by default."""

    def debug(self, message: str = "", data: dict[str, Any] | None = None) -> None:
        """Accept and discard a debug-level message (no-op)."""

    def warn(self, message: str = "", data: dict[str, Any] | None = None) -> None:
        """Accept and discard a warning-level message (no-op)."""

    def error(self, message: str = "", data: dict[str, Any] | None = None) -> None:
        """Accept and discard an error-level message (no-op)."""
