from .matrix import Matrix
from .auxiliary import EPSILON, angle_normalize
from .point import Point

class Vector:

    def __init__(self, a: Point, b:Point):
        """
        from a to b

        :param a: Tail of this vector
        :param b: Head of this vector
        """
        self._a = Point(a)
        self._b = Point(b)
        self._z = b - a
        self._norm = self._z.modulus
        self._slope = 0
        if self._norm > EPSILON:
            self._slope = angle_normalize(self._z.argument)


    @property
    def tail(self):
        return Point(self._a)

    @property
    def head(self):
        return Point(self._b)

    @property
    def slope(self):
        return self._slope

    @property
    def z(self)-> Point:
        """converts this vector to Point"""
        return Point(self._z)

    @property
    def dx(self)-> float:
        """dx and dy give the coordinates of the vectors in the reference base"""
        return self._z.re

    @property
    def dy(self)-> float:
        """dx and dy give the coordinates of the vectors in the reference base"""
        return self._z.im

    @property
    def norm(self)-> float:
        """the length of the segment between the two ends"""

        return self._norm

    @property
    def mtx(self):
        r"""
        Column Matrix of complex numbers:

        .. math::

            \begin{pmatrix}
            \text{head.re} + i\cdot\text{head.im} \\
            \text{tail.re} + i\cdot\text{tail.im} \\
            \end{pmatrix}

        :return: Column Matrix of complex numbers
        """
        return Matrix([[self._a],[self._b]])