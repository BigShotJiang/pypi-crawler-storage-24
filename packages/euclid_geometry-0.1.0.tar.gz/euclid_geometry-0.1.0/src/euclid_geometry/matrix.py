class Matrix:
    def __init__(self, value):
        self.rows = len(value)
        self.cols = len(value[0]) if self.rows > 0 else 0
        self.set = value

        # Hinweis: Die Funktion 'determinant' muss separat definiert sein
        self.det = determinant(value)

#####################################
def determinant(value):
    return None