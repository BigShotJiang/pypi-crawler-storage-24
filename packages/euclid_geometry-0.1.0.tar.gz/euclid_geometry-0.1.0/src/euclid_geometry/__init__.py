from .point import Point
from .line import  Line
from .apollonius import Apollonius

from .matrix import Matrix
from .vector import Vector

__classes__ = [
    # Geometry
    Point.__name__,
    Line.__name__,
    Apollonius.__name__,
    # Algebra
    Matrix.__name__,
    Vector.__name__,
]

# Variables must be declared as a string literal
__auxiliary_const__ = [
    "auxiliary.EPSILON",
    "auxiliary.TAU",
    "auxiliary.PHI",
    "auxiliary.INVPHI",
    "auxiliary.DIGITS"
]

__auxiliary_functions__ = [
    "auxiliary.angle_normalize",
    "auxiliary.barycenter",
    # alibi for testing of doc
    "auxiliary.say_hello"
]

__point_const__ = [

]

__point_functions__ = [
    "point.projection",
    "point.is_linear"
]

__all__ = (__classes__
           + __auxiliary_const__
           + __auxiliary_functions__
           + __point_const__
           + __point_functions__
          )
