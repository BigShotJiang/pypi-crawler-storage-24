from .point import Point
from .path import Path


class Apollonius:

    @staticmethod
    def p_p_p(c:Point, a:Point, b:Point)-> tuple[Path, Path, int]:
        """
        calculate the Apollonius Circle in the case point, point, point
        (Work in process, futher reading: https://en.wikipedia.org/wiki/Circles_of_Apollonius)

        :param c:
        :param a:
        :param b:

        :return:
        """
        PA_center = Path()
        PA_through = Path()
        if Point.is_aligned(c, a, b) or c.identity(a) or c.identity(b) or a.identity(b):
            return PA_center, PA_through, 0
        o_coords = Point.circum_center(c, a, b)
        o = Point(o_coords[0], o_coords[1])
        PA_center.add_point(o)
        PA_through.add_point(c)
        return PA_center, PA_through, 1