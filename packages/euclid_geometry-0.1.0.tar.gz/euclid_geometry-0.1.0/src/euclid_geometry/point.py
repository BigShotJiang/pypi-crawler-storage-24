import math
from warnings import deprecated

from . import auxiliary
from .auxiliary import barycenter, EPSILON, angle_normalize
from .matrix import Matrix


class Point:
    """
        Represents a point in 2D-plan. A Point can also be seen as a complex number.
        Since python can handle complex number as a built-in datatype,
        the class ``Point`` is implemented using complex number.
    """
    def __init__(self, re:int|float|complex, im=None):
        """
        Example::

            p1 = Punkt(1, 2)
            p2 = Punkt(1)
            c = i+2j
            p3 = Punkt(c)

        :param re:
        :param im:
        """
        if im is not None and isinstance(re, (int, float)) and isinstance(im, (int, float)):
            self._re = float(re)
            self._im = float(im)
        else:
            if isinstance(re, dict) and 're' in re and 'im' in re and \
                    isinstance(re['re'], (int, float)) and isinstance(re['im'], (int, float)):
                self._re = float(re['re'])
                self._im = float(re['im'])
            elif isinstance(re, complex):
                self._re = re.real
                self._im = re.imag
            elif isinstance(re, (int, float)):
                self._re = re
                self._im = 0
            elif isinstance(re, Point):
                self._re = re.re
                self._im = re.im
            else:
                raise ValueError(
                    f"Invalid point: expected two numbers or a complex {{re,im}}, or a Point "
                    f"got re = {re!r}, im = {im!r}"
                )
        self._argument = math.atan2(self.im, self.re)
        # self._modulus = math.sqrt(self.re**2 + self.im**2)
        self._modulus = math.hypot(self._re, self.im)
        self._mtx = Matrix([[self.re], [self.im]])
        self._complex = complex(self._re, self._im)

    @property
    def re(self)->float|int:
        """The real part (= the x-coordinate) of this point"""
        return self._re

    @property
    def im(self)-> float|int:
        """The imaginary part (= the y-coordinate) of this point"""
        return self._im

    @property
    def argument(self)-> float:
        """The argument of this point(= phi / Phase) of this point"""
        return self._argument

    @property
    def modulus(self) -> float:
        """The modulus of this point(= Distance from Origin to this point)"""
        return self._modulus

    @property
    def complex(self) -> complex:
        """
        the representation of this point in Python complex number i.e. ``x+yi``
        """
        return self._complex

    @property
    def mtx(self)-> Matrix:
        """
        returns the column matrix of this Point. Example::

            p = Point(1, 2)
            m = m.mtx       → Matrix([[1],[3]])

        :return:
        """
        return self._mtx

    def __add__(self, other: any) -> "Point":
        """
        Example::

            p1 = Point(1,2)
            p2 = Point(3,4)
            p3 = p1 + p2    # → Point(4, 6)

        :param other:
        :return:
        """
        p1, p2 = Point.check(self, other)
        return Point(p1.re + p2.re, p1.im + p2.im)

    def __radd__(self, other: "Point")-> "Point":
        """
        allows writing ``0 + Point(2,3)`` to get ``Point(2,3) + Point(0)``::

            p = 0
            p += Point(1, 2)
            p += Point(3, 4) # → Point(4, 6)

        :param other:
        :return:
        """
        return self + other


    def __sub__(self, other: "Point") -> "Point":
        """
        Example::

            p = me.Point(1, 2)
            q = me.Point(3, 4)
            t = q - p          # → me.Point(2, 2)

        :param other: point to subtract to this Point
        :return: new point
        """
        p1, p2 = Point.check(self, other)
        return Point(p1.re - p2.re, p1.im - p2.im)

    def __rsub__(self, other: "Point") -> "Point":
        """
        Example::

            p = me.Point(3, 4)
            q = p - 3            # → Point(0, 4)


        :param other: An object that can be converted to a Point
        :return: a new Point
        """
        return - self + other

    def __neg__(self: "Point") -> "Point":
        """ Calculate the negation of the complex number represented by this point.
        Example::

            p = me.Point(1, 2)
            np = -p            # → Point(-1,-2)

        :return: a new point
        """
        return Point(-self.re, -self.im)

    def __mul__(self, other) -> "Point":
        """Perform complex multiplication::

            p1 = Point(x1, y1)
            p2 = Point(x2, y2)
            p1 * p2 == Point(p1.complex*p2.complex)

        :param other:
        :return: new point
        """
        p1, p2 = Point.check(self, other)
        return Point(p1.complex * p2.complex)

    def __rmul__(self, other)-> "Point":
        return self.__mul__(other)

    def __matmul__(self, other: "Point|any") -> float|int:
        """
        Calculate dot-product of this point with other point::

            p1 = me.Point(1, 2)
            p2 = me.Point(3, 4)
            m = p1 @ p2         # → 11

        :param other:
        :return:
        """
        c1, c2 = Point.check(self, other)
        z = c1 * c2.conj()
        return z.re

    def __pow__(self, other) -> float|int:
        r"""allow to write::

            p1 = me.Point(1, 2)
            p2 = me.Point(3, 4)
            d = p1 ^ p2

        to calculate determinant of two points:

        .. math:

            d = \left (x_1,y_1)^T (x_2,y_2)^T \ \right|

        :param other:
        :return:
        """
        c1, c2 = Point.check(self, other)
        z = c1.conj() * c2
        return z.im

    def __truediv__(self, other) -> "Point":
        p1, p2 = Point.check(self, other)
        den = p2.re ** 2 + p2.im ** 2
        if den == 0:
            raise ArithmeticError("Division by zero in Point.__truediv__")
        return Point(
            (p1.re * p2.re + p1.im * p2.im) / den,
            (p1.im * p2.re - p1.re * p2.im) / den
        )

    def __str__(self)-> str:
        real = self.re
        imag = self.im
        tolerance = EPSILON

        def format_part(r):
            if abs(r - round(r)) < tolerance:
                return str(round(r))
            else:
                fixed_width_str = f"{r:.{auxiliary.DIGITS}f}"
                return fixed_width_str.rstrip('0') if auxiliary.DIGITS > 0 else  fixed_width_str

        if real == 0:
            if imag == 0:
                return "0"
            else:
                if imag == 1:
                    return "i"
                elif imag == -1:
                    return "-i"
                else:
                    return f"{format_part(imag)}i"
        else:
            if imag > 0:
                if imag == 1:
                    return format_part(real) + "+i"
                else:
                    return f"{format_part(real)}+{format_part(imag)}i"
            elif imag < 0:
                if imag == -1:
                    return format_part(real) + "-i"
                else:
                    return f"{format_part(real)}{format_part(imag)}i"
            else:
                return format_part(real)


    def __repr__(self):
        return self.__str__()

    def __float__(self)-> float:
        if abs(self.im) < auxiliary.EPSILON:
            return self.re
        raise TypeError("Cannot convert complex point to float if imaginary part is not zero.")

    def __eq__(self, other: "Point")-> bool:
        """
        Two points are considered to be equal if the Euclidian distance between them is less than :py:const:`auxiliary.EPSILON`.

        :param other:
        :return:
        """
        if not isinstance(other, Point): return False
        return self.identity(other)

    def conj(self)-> "Point":
        return Point(self.re, -self.im)



    def abs(self)-> float:
        r"""
        calculate euclidian distance to ``Point(0, 0)``, can also be used as a static method.
        Example::

            p1 = me.Point(1,1)
            l1 = p1.abs()             # → 1.4142135623730951 ($\sqrt{2}$)
            p2 = me.Point(2, 3)
            l2 = Point.abs(p1 - p2)   # → 2.23606797749979 ($\sqrt{5}$)


        :return: The euclidian distance of this point to ``Point(0,0)``
        """
        return self.modulus

    def norm(self) -> float:
        return self.re ** 2 + self.im ** 2

    def power(self, n)-> "Point":
        m = self.modulus ** n
        a = angle_normalize(self.argument * n)
        return Point.polar(m, a)

    def sqrt(self)-> "point":
        len_val = math.sqrt(self.re ** 2 + self.im ** 2)
        sign = -1 if self.im < 0 else 1
        return Point(math.sqrt((self.re + len_val) / 2), sign * math.sqrt((len_val - self.re) / 2))

    def arg(self)-> float:
        return self.argument

    def get(self)-> tuple[int|float, int|float]:
        """
        convert this point to a tuple of its real part and imaginary part.

        :return: ``(self.re, self.im)``
        """
        return self.re, self.im

    def north(self, d=1)-> "Point":
        return self + Point.polar(d, math.pi / 2)

    def south(self, d=1)-> "Point":
        return self + Point.polar(d, 3 * math.pi / 2)

    def east(self, d=1)-> "Point":
        return self + Point.polar(d, 0)

    def west(self, d=1)-> "Point":
        return self + Point.polar(d, math.pi)

    def length(self, p)-> float:
        return length_(self, p)

    def normalize(self)-> "Point":
        d = self.abs()
        if d < auxiliary.EPSILON:
            raise ValueError("division by zero")
        else:
            return Point(self.re / d, self.im / d)

    def normalize_from(self, p)-> "Point":
        u = (self - p)
        d = Point.abs(u)
        if d < auxiliary.EPSILON:
            raise ValueError("division by zero")
        else:
            return Point(u.re / d, u.im / d) + p

    def identity(self, pt)-> bool:
        return Point.abs(self - pt) < auxiliary.EPSILON

    def orthogonal(self, d=None)-> "Point":
        if d is None:
            return Point(-self.im, self.re)
        else:
            m = Point.mod(self)
            return Point(-self.im * d / m, self.re * d / m)

    def at(self, z)-> "Point":
        return Point(self.re + z.re, self.im + z.im)

    def shift_orthogonal_to(self, B, dist)-> "Point":
        v = B - self
        n = v.orthogonal(dist)
        return n.at(self)

    def shift_collinear_to(self, B, dist)-> "Point":
        v = (B - self).normalize()
        return self + v * dist

    @deprecated("Use Apollonius.p_p_p instead")
    def p_p_p(self, a, b):
        """Deprecated: Use :py:meth:`Apollonius.p_p_p`: instead"""
        raise DeprecationWarning("Use Apollonius.p_p_p")

    def symmetry(self, *args)-> "Point | tuple[Point]":
        if len(args) == 1:
            obj = args[0]
            if isinstance(obj, Point):
                return symmetry_(self, obj)
            else:
                raise TypeError("expected args to be a Point or a list of Point")
        else:
            results = []
            for arg in args:
                results.append(symmetry_(self, arg))
            return tuple(results)

    def set_symmetry(self, *args):
        return set_symmetry_(self, *args)

    @deprecated("Use Point.rotate(self, angle, pt) instead")
    def rotation_pt(self, angle, pt):
        return rotation_(self, angle, pt)

    def rotate(self, angle_rad: float|int, target_object: "Point|any"):
        """
        rotate a point around a center about given angle. Can also be used as a static methode.
        Example::

            # rotate a point around itself
            p1 = Point(1,2)
            q = Point(0, 0)
            p2 = p1.rotate(math.pi/2, p)        # rotate q around p1 about 90°
            # rotate a point about a point
            p3 = Point.rotate(p1, math.pi/2, q) # also rotate q around p1 about 90°

        This method does not check type of ``target_object``, so it is a little bit faster than
        :py:meth:`.rotation`.

        :param center_point:
        :param angle_rad:
        :param target_object:
        :return:
        """
        if isinstance(target_object, Point):
            translated_re = target_object.re - self.re
            translated_im = target_object.im - self.im
            rotated_re = translated_re * math.cos(angle_rad) - translated_im * math.sin(angle_rad)
            rotated_im = translated_re * math.sin(angle_rad) + translated_im * math.cos(angle_rad)
            return Point(rotated_re + self.re, rotated_im + self.im)
        return target_object


    def set_rotation(self, angle, *args):
        return set_rotation_(self, angle, *args)

    def rotation(self, angle, *args):
        """
        rotates a Point or  a List of Points around this point about the given angle.
        Positive angle → CCW, Negative angle → CW

        :param angle:
        :param args:
        :return: new point or a tupel of new points
        """
        if len(args) == 1:
            obj = args[0]
            if isinstance(obj, Point):
                return self.rotate(angle, obj)
            else:
                raise TypeError("expected args to be a Point or a list of Point")
        else:
            results = [self.rotate(angle, arg) for arg in args]
            return tuple(results)

    def homothety(self, coeff:float|int, *args: "list[Point]")-> "Point|tuple[Point]":
        """
        performs a homothety of a point or a list of points.
        This point servers as the center of the transformation.

        :param coeff: the homothety ratio
        :param args: one or more points
        :return: a new point or a tuple of new point
        """
        if len(args) == 1:
            obj = args[0]
            if isinstance(obj, Point):
                return homothety_(self, coeff, obj)
            else:
                raise TypeError("expected args to be a Point or a list of Point")
        else:
            t = []
            for arg in args:
                t.append(homothety_(self, coeff, arg))
            return tuple(t)


    @staticmethod
    def polar(radius, phi)-> "Point":
        """
        Creates a new point with given radius and phi in radian

        :param radius: distance from new created point to plane-Origin
        :param phi: argument of the new created point in radian
        :return: a new point
        """
        return Point(radius * math.cos(phi), radius * math.sin(phi))

    @staticmethod
    def polar_deg(radius, phi_deg)-> "Point":
        """
        Same as py:meth:`Point.polar` but phi is given in degree.

        :param radius: distance from new created point to plane-Origin
        :param phi_deg: argument of the new created point in degree
        :return: a new point
        """
        return Point(radius, phi_deg * math.pi / 180)

    @staticmethod
    def topoint(z: any) -> "Point":
        """Convert an object to an instance of Point. Example::

            topoint(12.5)                # → Point(12.5, 0)
            topoint(12.5, 6)             # → Point(12.5, 6)
            topoint(12.5 + 6i)           # → Point(12.5, 6)
            topoint({re: 12.5, im: 0})   # → Point(12.5, 0) im is obligatory,
                                         # even if the imaginary part of the point is zero


        :param z: any object
        :return: a Point, that is represented by z
        :raise ValueError: when z does not represent a point
        """
        if isinstance(z, Point):
            return z
        elif isinstance(z, (int, float)):
            return Point(z, 0)
        elif (isinstance(z, dict) and 're' in z and 'im' in z
              and isinstance(z['re'], (int, float)) and isinstance(z['im'], (int, float))):
            return Point(z['re'], z['im'])
        elif isinstance(z, complex):
            return Point(z.real, z.imag)
        else:
            raise ValueError("topoint: cannot convert value to point")

    @staticmethod
    def check(z1, z2)-> "tuple[Point,Point]":
        """
        check if `z1` and `z2` are Points using :py:meth:`Point.topoint`

        :param z1:
        :param z2:
        :return: A pair of Points, if both z1 and z2 are point
        :raise ValueError: if z1 or z2 is not a point
        """
        p1 = Point.topoint(z1)
        p2 = Point.topoint(z2)
        if not (isinstance(p1, Point) and isinstance(p2, Point)):
            raise ValueError("check: expected point or number")
        return p1, p2



    @staticmethod
    def mod(pt: "Point|any") -> int | float:
        """
        Calculates Modulus of a possible Point-Object.

        :raise ValueError: when pt is not in a Point convertable
        """
        z = Point.topoint(pt)
        return math.hypot(z.re, z.im)

    @staticmethod
    def is_aligned(p1, p2, p3)-> bool:
        r"""
        checks if three given points are on a line by calculating the area inside them using Gauß-Formular.
        Given :math:`p_1(x_1,y_1), p_2(x_2,y_2), p_3(x_3,y_3)`.
        They are considered to be aligned if this condition hold.

        .. math::

            \frac{x_1(y_2 - y_3) + x_2(y_3 - y_1) + x_3(y_1 - y_2)}{2} \leq \varepsilon


        :param p1:
        :param p2:
        :param p3:
        :return: True if they are on a line, False else
        """
        area = 0.5 * abs(p1.re * (p2.im - p3.im) + p2.re * (p3.im - p1.im) + p3.re * (p1.im - p2.im))
        return area < auxiliary.EPSILON

    @staticmethod
    def circum_center(a, b, c)-> "Point":
        ka = math.sin(2 * Point.get_angle(a, b, c))
        kb = math.sin(2 * Point.get_angle(b, c, a))
        kc = math.sin(2 * Point.get_angle(c, a, b))
        return barycenter([(a, ka), (b, kb), (c, kc)])

    @staticmethod
    def get_angle(a, b, c)-> float:
        """
            Orientierungsbehafteter Winkel ∠BAC, Winkelspit A, in (-Pi, Pi)
        """
        if Point.abs(b - a) < EPSILON or Point.abs(c - a) < EPSILON:
            raise ValueError("Points confused in get_angle")
        # Vector AB = b - a, AC = c - a
        # arg (AC / AB) =
        return Point.arg((c - a) / (b - a))

    @staticmethod
    def is_parallel(a:"Point", b:"Point", c:"Point", d:"Point")-> bool:
        """
        checks if 4 points form two parallel line (a, b) and (c, d).
        This method is idempotenz.

        :param a:
        :param b:
        :param c:
        :param d:
        :return:
        """
        return abs( (b - a)**(d - c) ) < EPSILON # determinant

    @staticmethod
    def is_orthogonal(a:"Point", b:"Point", c:"Point", d:"Point")-> bool:
        """
        checks if two lines (a, b) and (c,d) are orthogonal
        This method is idempotenz.

        :param a:
        :param b:
        :param c:
        :param d:
        :return:
        """
        return abs( (b - a) @ (d - c) ) < EPSILON # @ = dot-product = scalar product

    @staticmethod
    def is_ortho(z1: "Point", z2: "Point", z3: "Point") ->bool:
        """
        returns true if the vectors (z1, z2) and (z1, z3) are orthogonal.

        :param z1:
        :param z2:
        :param z3:
        :return:
        """
        return abs( (z2 - z1)@(z3-z1) ) < EPSILON


    @staticmethod
    def is_equidistant(a: "Point", b: "Point", p:"Point")-> bool:
        """
        checks if point p has the same distance to point a and to point b.
        This method is idempotenz.

        :param a:
        :param b:
        :param p:
        :return:
        """
        return abs( (a-p).modulus - (b-p).modulus ) < EPSILON



def projection(a:Point, b: Point, c: Point)-> Point:
    """
    Project the point c onto the line defined by (a,b)

    :param a:
    :param b:
    :param c:
    :return:
    """
    # if Line.is_linear(a, b, c): return  c
    if is_linear(a, b, c): return  c
    v = b - a
    z = ((c - a) @ v) / (v @ v) # @ ← dot product
    return a + (z * v)


def is_linear(z1: Point, z2: Point, z3: Point) -> bool:
    """
    check if three point on a line

    :param z1:
    :param z2:
    :param z3:
    :return:
    """
    return abs(_det3pt(z1, z2, z3)) < EPSILON


def _det3pt(z1: Point, z2: Point, z3: Point):
    r"""

    performs determinant of 3 points. Useful to calculate turn orientation.

    :param z1:
    :param z2:
    :param z3:
    :return:
    """
    return _oriented_area2_(z1.re, z1.im, z2.re, z2.im, z3.re, z3.im)


def _oriented_area2_(x1: float | int, y1: float | int,
                     x2: float | int, y2: float | int,
                     x3: float | int, y3: float | int) -> float:
    r"""
    Computes the 2D cross product (signed area) of the triangle
    formed by (x1,y1), (x2,y2), and (x3,y3).

    :param x1:
    :param y1:
    :param x2:
    :param y2:
    :param x3:
    :param y3:
    :return:

        * > 0 if counter-clockwise (left turn),
        * < 0 if clockwise (right turn),
        * = 0 if colinear.

    """
    return (x2 - x1) * (y3 - y1) - (x3 - x1) * (y2 - y1)


@deprecated("Use Point.polar instead")
def polar_(radius, angle)-> Point:
    return Point(radius * math.cos(angle), radius * math.sin(angle))

def length_(p1, p2)-> float:
    return math.sqrt((p1.re - p2.re)**2 + (p1.im - p2.im)**2)

def symmetry_(reference_point, target_object):
    if isinstance(target_object, Point):
        return Point(2 * reference_point.re - target_object.re, 2 * reference_point.im - target_object.im)
    return target_object

def set_symmetry_(reference_point, *objects_to_transform):
    results = [symmetry_(reference_point, obj) for obj in objects_to_transform]
    if len(results) == 1: return results[0]
    return results

@deprecated("Use static method Point.rotate instead")
def rotation_(center_point, angle_rad, target_object):
    if isinstance(target_object, Point):
        translated_re = target_object.re - center_point.re
        translated_im = target_object.im - center_point.im
        rotated_re = translated_re * math.cos(angle_rad) - translated_im * math.sin(angle_rad)
        rotated_im = translated_re * math.sin(angle_rad) + translated_im * math.cos(angle_rad)
        return Point(rotated_re + center_point.re, rotated_im + center_point.im)
    return target_object

def set_rotation_(center_point, angle_rad, *objects_to_transform):
    results = [rotation_(center_point, angle_rad, obj) for obj in objects_to_transform]
    if len(results) == 1: return results[0]
    return results

def homothety_(center_point:Point, coeff: float | int, target_object):
    if isinstance(target_object, Point):
        return Point(
            center_point.re + coeff * (target_object.re - center_point.re),
            center_point.im + coeff * (target_object.im - center_point.im)
        )
    return target_object

def set_homothety_(center_point, coeff, *objects_to_transform):
    results = [homothety_(center_point, coeff, obj) for obj in objects_to_transform]
    if len(results) == 1: return results[0]
    return results

@deprecated("use `isinstance(obj, Point)` instead")
def is_point(obj):
    """
    For compatible only, use `isinstance(obj, Point)` instead
    Object to be removed
    :param obj:
    :return:
    """
    return isinstance(obj, Point)


