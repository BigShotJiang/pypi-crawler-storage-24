"""
    collection of auxiliary functions
"""

import math
from warnings import deprecated

#: Used to as tolerant difference by comparison
EPSILON = 1e-10

#: Shortcut for ``2 * math.pi``
TAU = math.tau

#: golden number φ
PHI = (1 + math.sqrt(5)) / 2

#: Inverted phi (inverted golden number φ)
INVPHI = (math.sqrt(5) - 1) / 2

#: Digits count, used by converting float to string
DIGITS = 6


def barycenter(*args) -> any:
    """
    calculates the Barycenter of a list of pairs (value, weight). Example::

        import manim_euclid as me
        import manim_euclid.auxiliary as aux

        pA = me.Punkt(1, 2)
        pB = me.Punkt(3, 4)
        pC = me.Punkt(-2, 1)
        center = aux.barycenter( (pA, 1), (pB, 1.5), (pC, -3) ) # → -23-10i

    :param args: List of pairs ``(value, weight)``. ``value`` must implement ``__add__`` and ``__radd__``.
    :return: the value of barycenter
    :raise ValueError: if sum of weights is zero
    """
    total_sum = 0
    weight = 0
    for e in args:
        total_sum += e[0] * e[1]
        weight += e[1]
    if weight == 0:
        raise ValueError("barycenter: sum of weights is zero")
    return total_sum/weight


# standalone functions
def angle_normalize(angle:float)->float:
    r"""
    normalizes a real angle to the interval :math:`[0, 2\pi)`.

    :param angle: in Radian
    :return: the same angle, reduced module :math:`2pi`
    """
    return angle % (2 * math.pi)





@deprecated("use math.hypot instead")
def pyth(a:float|int, b:float|int)-> float:
    r"""
        performs :math:`\sqrt{a^2 + b^2}` for a and b

    :param a:
    :param b:
    :return:
    """
    if a == 0 and b == 0:
        return 0
    a, b = abs(a), abs(b)
    a, b = max(a, b), min(a, b)
    return a * math.sqrt(1 + (b / a) ** 2)


# scope TKZ
"""
tkz.length(z1, z2)
# tkz.midpoint(z1, z2)                  → Line.midpoint
tkz.midpoints(z1, z2, ..., zn)
# tkz.is_linear(z1, z2, z3)             → Line.is_linear
# tkz.is_ortho(z1, z2, z3)              → Point.is_ortho
tkz.bisector(z1, z2, z3)
tkz.bisector_ext(z1, z2, z3)
tkz.altitude(z1, z2, z3)
tkz.get_angle(z1, z2, z3)               → Point.get_angle
tkz.inner_angle(z1, z2, z3)
tkz.angle_normalize(an)                 → aux.angle_normalize
tkz.get_angle_normalize                 
tkz.angle_between_vectors
# tkz.barycenter ({z1,n1},{z2,n2}, ...) → aux.barycenter
tkz.dot_product(z1, z2, z3)
tkz.parabola(pta, ptb, ptc)
tkz.nodes_from_paths
tkz.fsolve(f, a, b, n [, opts])
tkz.derivative(f, x0 [, accuracy])
# 
tkz.solve(...)
tkz.solve_linear_system
"""


# scope  UTILS
"""
utils.parse_point(str)
utils.format_number(r, n)
utils.format_coord(x, decimals)
utils.format_point(z, decimals)
utils.checknumber(x, decimals)
utils.almost_equal(a, b, eps)
utils.wlog(...) 
"""








































def say_hello(whom):
    """
    Alibi to test Sphinx doc.

    :param whom: name
    :return: greeting words
    """
    return f"hello {whom}"