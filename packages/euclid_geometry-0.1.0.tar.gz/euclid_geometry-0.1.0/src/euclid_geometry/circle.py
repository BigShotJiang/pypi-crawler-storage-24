class Circle:
    def __init__(self, center, through):
        pass