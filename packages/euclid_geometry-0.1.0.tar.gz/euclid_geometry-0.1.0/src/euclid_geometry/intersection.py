import math
import line
from . import auxiliary as aux
from .point import Point


# intersection of lines
def intersection_ll(la, lb, EPS=None):
    return intersection_ll_(la.pa, la.pb, lb.pa, lb.pb, EPS)


def intersection_ll_(a, b, c, d, EPS=None):
    EPS = EPS if EPS is not None else aux.EPSILON

    x1, y1 = a.re, a.im
    x2, y2 = b.re, b.im
    x3, y3 = c.re, c.im
    x4, y4 = d.re, d.im

    # cas dégénérés : une "droite" réduite à un point
    if (abs(x1 - x2) < EPS and abs(y1 - y2) < EPS) or \
            (abs(x3 - x4) < EPS and abs(y3 - y4) < EPS):
        return None

    DN = (x1 - x2) * (y3 - y4) - (y1 - y2) * (x3 - x4)

    # droites parallèles ou quasi-parallèles
    if abs(DN) < EPS:
        return None

    NX = (x1 * y2 - y1 * x2) * (x3 - x4) - (x1 - x2) * (x3 * y4 - y3 * x4)
    NY = (x1 * y2 - y1 * x2) * (y3 - y4) - (y1 - y2) * (x3 * y4 - y3 * x4)

    return Point(NX / DN, NY / DN)


# intersection of a line and a circle
def intersection_lc(D, C, EPS=None):
    return intersection_lc_(D.pa, D.pb, C.center, C.through, EPS)


def intersection_lc_(pa, pb, c, p, EPS=None):
    # pa, pb : deux points définissant la droite
    # c      : centre du cercle
    # p      : point sur le cercle (pour le rayon)
    # Retour :
    #   - None, None si pas d’intersection
    #   - P, P si tangence
    #   - P1, P2 si sécante (ordonnées par angle autour de c)
    EPS = EPS if EPS is not None else aux.EPSILON

    # Rayon du cercle
    r = (c - p).abs()

    # Vecteur directeur de la droite (pa -> pb)
    ab = pb - pa
    abx, aby = ab.re, ab.im
    lab2 = abx * abx + aby * aby

    # Droite dégénérée : pa == pb
    if lab2 < EPS * EPS:
        return None, None

    lab = math.sqrt(lab2)
    ex, ey = abx / lab, aby / lab  # vecteur unitaire sur la droite

    # Projection du centre c sur la droite (pa,pb)
    zh = line.projection(pa, pb, c)
    dh = (c - zh).abs()  # distance centre -> droite

    # Pas d'intersection : la droite est trop loin du cercle
    if dh > r + EPS:
        return None, None

    # Tangence : un seul point (renvoyé deux fois)
    if abs(dh - r) <= EPS:
        return zh, zh

    # Cas général : deux intersections.
    # Longueur le long de la droite à partir du pied de la perpendiculaire.
    h2 = r * r - dh * dh
    R2 = max(r * r, lab2)

    if h2 < -EPS * R2:
        # numériquement négatif => pas de solution réelle
        return None, None
    if h2 < 0:
        h2 = 0

    h = math.sqrt(h2)

    xh, yh = zh.re, zh.im
    x1 = xh + h * ex
    y1 = yh + h * ey
    x2 = xh - h * ex
    y2 = yh - h * ey

    z1 = Point(x1, y1)
    z2 = Point(x2, y2)

    # Tri par angle autour du centre c, comme pour intersection_cc_
    a1 = aux.angle_normalize((z1 - c).arg())
    a2 = aux.angle_normalize((z2 - c).arg())

    if a1 <= a2:
        return z1, z2
    else:
        return z2, z1


# intersection of two circles
def intersection_cc(Ca, Cb, EPS=None):
    return intersection_cc_(Ca.center, Ca.through, Cb.center, Cb.through, EPS)


def intersection_cc_(ca, pa, cb, pb, EPS=None):
    # ca, pa, cb, pb : points (type point/complex)
    # Retour :
    #   - None, None si pas d'intersection
    #   - P, P si tangence
    #   - P1, P2 si sécante (ordre croissant en angle autour de ca)
    EPS = EPS if EPS is not None else aux.EPSILON
    ra = (ca - pa).abs()
    rb = (cb - pb).abs()

    # vecteur entre centres
    dc = cb - ca
    dx, dy = dc.re, dc.im
    d2 = dx * dx + dy * dy
    d = math.sqrt(d2)

    # centres (quasi) confondus
    if d < EPS:
        # mêmes rayons -> cercles confondus : géométriquement infinité de solutions
        # für den Moment geben wir "keine Schnittpunkte" zurück (altes Verhalten: false,false)
        if abs(ra - rb) < EPS:
            return None, None
        else:
            return None, None

    # positions relatives simples : trop loin ou l'un dans l'autre sans contact
    # (ces tests ne sont pas obligatoires mais évitent des racines négatives parasites)
    if d > ra + rb + EPS:
        # trop éloignés
        return None, None
    if d < abs(ra - rb) - EPS:
        # l’un est strictement à l’intérieur de l’autre, sans tangence
        return None, None

    # projection du point d’intersection "médian" sur la droite des centres
    a = (ra * ra - rb * rb + d2) / (2 * d)
    h2 = ra * ra - a * a

    # tolérance relative sur h2
    R2 = max(ra * ra, rb * rb, d2)
    if h2 < -EPS * R2:
        # numériquement négatif -> pas de solution réelle
        return None, None

    if h2 < 0:
        # très léger négatif dû aux erreurs de flottants
        h2 = 0

    # point "milieu" sur la droite (ca -> cb)
    ux, uy = dx / d, dy / d  # vecteur unitaire ca->cb
    mx = ca.re + a * ux
    my = ca.im + a * uy

    h = math.sqrt(h2)

    # si h ~ 0 : tangence
    if h < EPS * d:
        P = Point(mx, my)
        return P, P

    # vecteur unitaire perpendiculaire
    px, py = -uy, ux

    x1 = mx + h * px
    y1 = my + h * py
    x2 = mx - h * px
    y2 = my - h * py

    z1 = Point(x1, y1)
    z2 = Point(x2, y2)

    # ordre croissant en angle autour de ca (comme dein altes Skript)
    c1 = aux.angle_normalize((z1 - ca).arg())
    c2 = aux.angle_normalize((z2 - ca).arg())

    if c1 <= c2:
        return z1, z2
    else:
        return z2, z1


# line ellipse
def intersection_le(L, E, EPS=None):
    EPS = EPS if EPS is not None else aux.EPSILON
    # Transformation der Linie in das Koordinatensystem der Ellipse
    # Lua: A = (L.pa - E.center) * (Point(math.cos(E.slope), -math.sin(E.slope)))
    # Annahme: Point(cos, -sin) repräsentiert die komplexe Zahl e^(-i*E.slope)
    # und die Multiplikation `*` auf `point`-Objekten führt eine komplexe Multiplikation aus.
    rotation_inv = Point(math.cos(-E.slope), math.sin(-E.slope))  # e^(-i*E.slope)
    A = (L.pa - E.center) * rotation_inv
    B = (L.pb - E.center) * rotation_inv

    Rx = E.Rx
    Ry = E.Ry
    Ax = A.re
    Ay = A.im
    Bx = B.re
    By = B.im

    a = Rx ** 2 * (By - Ay) ** 2 + Ry ** 2 * (Bx - Ax) ** 2
    b = 2 * Rx ** 2 * Ay * (By - Ay) + 2 * Ry ** 2 * Ax * (Bx - Ax)
    c = Rx ** 2 * Ay ** 2 + Ry ** 2 * Ax ** 2 - Rx ** 2 * Ry ** 2
    d = b ** 2 - 4 * a * c

    # Rücktransformation der Punkte
    # Lua: z1 * (Point(math.cos(E.slope), math.sin(E.slope))) + E.center
    # Annahme: Point(cos, sin) repräsentiert die komplexe Zahl e^(i*E.slope)
    rotation_fwd = Point(math.cos(E.slope), math.sin(E.slope))  # e^(i*E.slope)

    if d > EPS:
        sd = math.sqrt(d)
        t1 = (-b + sd) / (2 * a)
        t2 = (-b - sd) / (2 * a)
        z1_transformed = Point(Ax + (Bx - Ax) * t1, Ay + (By - Ay) * t1)
        z2_transformed = Point(Ax + (Bx - Ax) * t2, Ay + (By - Ay) * t2)

        z1 = z1_transformed * rotation_fwd + E.center
        z2 = z2_transformed * rotation_fwd + E.center

        if aux.angle_normalize(z1_transformed.arg()) < aux.angle_normalize(z2_transformed.arg()):
            return z1, z2
        else:
            return z2, z1
    elif math.abs(d) < EPS:
        t1 = -b / (2 * a)
        z1_transformed = Point(Ax + (Bx - Ax) * t1, Ay + (By - Ay) * t1)
        z1 = z1_transformed * rotation_fwd + E.center  # rotation_fwd muss hier definiert sein (oder neu berechnet)
        return z1, z1
    else:
        return None, None


def intersection(X, Y, opts=None):
    # Normalisation des arguments
    EPS = None

    if isinstance(opts, (int, float)):
        # Ancien style : intersection(X, Y, EPS)
        EPS = opts
        opts = {}  # Leeres Dict für Optionen
    elif isinstance(opts, dict):
        # Nouveau style : opts.eps (ou opts.EPS)
        EPS = opts.get("EPS") or aux.EPSILON
    elif opts is None:
        EPS = aux.EPSILON
    else:
        # Hier sollte eine Fehlermeldung ausgegeben werden, ähnlich wie tex.error
        raise ValueError("intersection: invalid third argument (expected dict, number, or None).")

    opts = opts if opts is not None else {}

    t = []  # Liste zum Speichern der Schnittpunkte

    # Intersection cercle-cercle, ligne-cercle, ligne-ligne, conique-ligne...
    def add(z1, z2=None):
        if z1 is not None:
            t.append(z1)
        if z2 is not None and z2 is not z1:
            t.append(z2)

    # Cas principaux
    if X.type == "circle":
        if Y.type == "circle":
            p1, p2 = intersection_cc(X, Y, EPS)
            add(p1, p2)
        else:  # Y ist Linie oder Konik (wird in intersection_lc erwartet)
            p1, p2 = intersection_lc(Y, X, EPS)  # intersection_lc erwartet Line, Circle
            add(p1, p2)
    elif X.type == "line":
        if Y.type == "circle":
            p1, p2 = intersection_lc(X, Y, EPS)
            add(p1, p2)
        elif Y.type == "line":
            p = intersection_ll(X, Y, EPS)
            add(p)
        elif Y.type == "conic":
            if Y.subtype == "parabola":
                p1, p2 = Y.inter_Pa_line(X.pa, X.pb)
                add(p1, p2)
            elif Y.subtype == "hyperbola":
                p1, p2 = Y.inter_Hy_line(X.pa, X.pb)
                add(p1, p2)
            elif Y.subtype == "ellipse":
                p1, p2 = intersection_le(X, Y, EPS)
                add(p1, p2)
    elif X.type == "conic":
        # Hier wird angenommen, dass Y.type IMMER "line" ist, wenn X.type "conic" ist (analog Lua-Logik)
        if Y.type == "line":
            if X.subtype == "parabola":
                p1, p2 = X.inter_Pa_line(Y.pa, Y.pb)
                add(p1, p2)
            elif X.subtype == "hyperbola":
                p1, p2 = X.inter_Hy_line(Y.pa, Y.pb)
                add(p1, p2)
            elif X.subtype == "ellipse":
                p1, p2 = intersection_le(Y, X, EPS)  # intersection_le erwartet Line, Ellipse
                add(p1, p2)
        # Andere Fälle wie Conic-Circle müssten hier als eigene Verzweigung behandelt werden,
        # sind aber nicht in der ursprünglichen Lua-Logik explizit vorhanden.

    # Réorganisation selon l'option
    if opts and len(t) == 2:
        z1, z2 = t[0], t[1]
        if "known" in opts and opts["known"] == z1:
            t = [z2, z1]
        elif "known" in opts and opts["known"] == z2:
            # t bleibt [z1, z2] da 'known' an zweiter Stelle ist
            pass
        elif "near" in opts:
            d1 = (z1 - opts["near"]).abs()
            d2 = (z2 - opts["near"]).abs()
            if d2 < d1:
                t = [z2, z1]

    # Lua's table.unpack(t) würde die Elemente als separate Rückgabewerte liefern.
    if not t:
        return None, None  # Keine Schnittpunkte
    elif len(t) == 1:
        return t[0], t[0]  # Tangente (ein Punkt, zweimal zurückgegeben)
    else:
        return t[0], t[1]  # Zwei Schnittpunkte