import math
import random
from warnings import deprecated

from .auxiliary import angle_normalize, EPSILON, barycenter
from . import auxiliary as aux

from .point import Point, projection
from .vector import Vector


class Line:
    def __init__(self, pa: Point, pb:Point):
        self._pa = pa
        self._pb = pb
        self._mid = (pa + pb) / 2
        self._north_pa = pa.rotation( math.pi / 2, pb)
        self._south_pa = pa.rotation(-math.pi / 2, pb)
        self._north_pb = pb.rotation(-math.pi / 2, pa)
        self._south_pb = pb.rotation( math.pi / 2, pa)
        self._west = pa.rotation(math.pi / 2, self._north_pa)
        self._east = pb.rotation(math.pi / 2, self._south_pb)
        diff = pb - pa
        self._slope = angle_normalize(diff.argument)
        self._length = diff.modulus
        self._vec = None # TODO: Vector(pa, pb


    @property
    def pa(self)-> Point:
        return Point(self._pa)

    @property
    def pb(self)-> Point:
        return Point(self._pb)

    @property
    def mid(self):
        return Point(self._mid)

    @property
    def slope(self):
        return self._slope

    @property
    def length(self):
        return self._length

    @property
    def vec(self):
        return Vector(self._pa, self._pb)

    @property
    def north_pa(self):
        return Point(self._north_pa)

    @property
    def north_pb(self):
        return Point(self._north_pb)

    @property
    def south_pa(self):
        return Point(self._south_pa)

    @property
    def south_pb(self):
        return Point(self._south_pb)

    @property
    def east(self):
        return Point(self._east)

    @property
    def west(self):
        return Point(self._west)

    ########## public api
    #==== → real
    def distance(self, pt: Point):
        return Point(projection(self._pa, self._pb, pt) - pt).modulus

    #==== → bool
    def on_line(self, pt: Point)-> bool:
        """
        Checks whether a point is on the (infinite) line
        :param pt:
        :return:
        """
        return _line_on(self._pa, self._pb, pt)

    def on_segment(self, pt: Point) -> bool:
        """ Check whether a point is between the two endpoints of this line.

        :param pt:
        :return: True if the pt is between self.pa and self.pb
        """
        a,b = self._pa, self.pb
        return (pt - a).modulus + (pt - b).modulus - (b - a).modulus <= EPSILON

    def is_parallel(self, l: "Line")-> bool:
        return Point.is_parallel(self._pa, self._pb, l._pa, l._pb)

    def is_orthogonal(self, l: "Line") -> bool:
        return Point.is_orthogonal(self._pa, self._pb, l._pa, l._pb)

    def is_equidistant(self, pt: Point)-> bool:
        return Point.is_equidistant(self._pa, self._pb, pt)

    #==== → str
    @deprecated("Not supported")
    def position(self, obj, epsilon) -> str:
        raise DeprecationWarning("Not supported")

    @deprecated("Not supported")
    def position_segment(self, pt) -> str:
        raise DeprecationWarning("Not supported")

    def where_on_line(self, pt: Point) -> str:
        return None

    #==== → Point
    def get(self)-> tuple[Point,Point]:
        """
        This method retrieves the two points that define the given line.
        :return:
        """
        return Point(self._pa), Point(self._pb)

    def random(self)->Point:
        """
        The method returns a point belonging to the segment.

        .. code-block:: python

            pM = lAB.random()

        :return:
        """
        return self.point(random.random())

    def gold_ratio(self)-> Point:
        r"""
        This method returns a point C on the segment [AB] that divides it according to the golden ratio φ:

        .. math::

            \frac{AC}{CB} = \phi = \frac{1+\sqrt{5}}{2}

        :return:
        """
        return self._pa + (self._pb - self._pa) * aux.INVPHI #tkz.invphi

    def normalize(self)-> Point:
        """
        Normalize line (point at one unit distance) from pa
        :return:
        """
        return self._pa + (self._pb - self._pa) / self.length

    def normalize_inv(self)-> Point:
        return _normalize_(self._pb, self._pa)

    def barycenter(self, ka:float|int, kb:float|int)-> Point:
        return barycenter((self._pa, ka), (self._pb, kb))

    def point(self, r:float)-> Point:
        """
        allows you to place a point on the line, based on a real parameter r.
        Given a line AB defined by two points pa and pb
        :param r:

        * ``r=0`` → ``pa``
        * ``r=1`` → ``pb``
        * ``r=0.5`` →  the midpoint of the segment [AB]
        * any else →  a negative value places the point before ``pa``,
            a value greater than 1 places it beyond ``pb``.


        :return: a Point on the line AB
        """
        return barycenter( (self._pa, 1 - r), (self._pb, r) )

    def harmonic_int(self, pt:Point)-> Point:
        r"""Given a point on the line but located outside the segment [AB],
        this method returns a point on the segment that maintains a harmonic ratio.

        Let AB be a line, and let D be a point such that D ∈ (AB) but D ∉ [AB].
        The method returns a point C ∈ [AB] such that:

        .. math::

            \frac{AC}{BC} = \frac{AD}{BD}

        :param pt: 
        :return: 
        """
        return _div_harmonic_int_(self._pa, self._pb, pt)

    def harmonic_ext(self, pt)-> Point:
        r"""returns a point located outside the segment [AB] that satisfies a harmonic
        relation with a given point on the segment.

        Let AB be a line segment, and let C be a point on [AB] (but not its midpoint).
        The method returns a point D lying on the line (AB) but outside the segment [AB], such that:

        .. math::

            \frac{AC}{BC} = \frac{AD}{BD}

        This is the inverse of the operation performed by the method harmonic_int(pt).

        :param pt:
        :return:
        """
        return _div_harmonic_ext_(self.pa, self.pb, pt)

    def harmonic_both(self, k:float)-> tuple[Point,Point]:
        r"""This method returns two points on the line defined by AB:

        * one point C lying inside the segment [AB],
        * one point D lying outside the segment [AB],

        such that the following harmonic ratio holds:

        .. math::

            \frac{AC}{BC} = \frac{AD}{BD} = k

        The parameter k represents the desired ratio between the distances.
        This method is useful when you want to construct both the internal and external harmonic conjugates of a given segment.

        The method returns the two corresponding points in the order: **internal**, **external**.


        :param k:
        :return:
        """
        return _div_harmonic_both_(self._pa, self._pb, k)

    @deprecated("Not supported")
    def harmonic(self, mode, pt):
        raise DeprecationWarning("Not supported")

    def report(self, d, pt: Point|None = None) -> Point:
        if not self._length or abs(self._length) < EPSILON:
            raise ValueError("Line.length must not be zero")
        t = d / self._length
        result = barycenter((self._pa, 1 - t), (self._pb, t))
        if pt is not None:
            return result + pt - self._pa
        return result

    def collinear_at(self, k):
        return None

    def orthogonal_at(self, r):
        return None

    #==== → Line
    def ll_from(self, pt):
        return None

    def ortho_from(self, pt):
        return None

    def mediator(self):
        return None

    def swap_line(self):
        return None

    @staticmethod
    def midpoint(pa:Point, pb:Point)-> Point:
        """provides a shortcut for computing the midpoint of a segment without creating an object of Line
        """
        return (pa+pb)/2



# Helpers


def _line_on(a, b, pt, epsilon=EPSILON)->bool:
    return abs((b - a) ^ (pt - a)) <= epsilon


def _div_harmonic_int_(a:Point, b:Point, n:Point)-> Point:
    k = Point.abs(a - n) / Point.abs(b - n)
    return barycenter((a, 1), (b, k))

def _div_harmonic_ext_(a:Point, b:Point, n:Point)-> Point:
    k = Point.abs(a - n) / Point.abs(b - n)
    return barycenter( (a, 1), (b, -k))

def _div_harmonic_both_(a:Point, b:Point, k:float)-> tuple[Point,Point]:
    return barycenter( (a, 1), (b, k)), barycenter(( a, 1 ), ( b, -k ))

def _normalize_(a:Point, b:Point)-> Point:
    # TODO: replace Point.mod with  inline of (b-a).mod
    return a + (b - a) / Point.mod(b - a)

