class Path:
    def add_point(self):
        pass

    pass