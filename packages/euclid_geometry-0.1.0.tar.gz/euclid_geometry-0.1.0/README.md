# Euclid Geometry

## Run Unit Test

### To create the snapshot for the first run:

```shell
pytest --snapshot-update
```

### To test changing code

```shell
pytest
```