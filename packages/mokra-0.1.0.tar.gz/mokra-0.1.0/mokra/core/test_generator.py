"""Auto-test code generator from observed behavior."""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from mokra.core.world import WorldState


def generate_tests(world: WorldState, output_path: str | None = None) -> str:
    """Generate pytest tests from observed behavior.

    Args:
        world: The WorldState containing observed interactions.
        output_path: Optional path to write the generated test file.

    Returns:
        The generated test code as a string.
    """
    lines = [
        '"""Auto-generated tests from mokra observations."""',
        "",
        "import pytest",
        "from unittest.mock import patch, MagicMock",
        "",
        "",
    ]

    for service_name, service in world.services.items():
        safe_name = service_name.replace("-", "_").replace(".", "_")
        lines.append(f"class Test{safe_name.title().replace('_', '')}:")
        lines.append(f'    """Tests for {service_name} interactions."""')
        lines.append("")

        for i, (request, response) in enumerate(
            zip(service.requests, service.responses)
        ):
            method = request["method"].lower()
            status = response["status_code"]
            lines.append(f"    def test_{method}_request_{i}(self):")
            lines.append(f'        """Test {method.upper()} to {service_name}."""')
            lines.append(f"        # Request: {request['method']} {request['url']}")
            lines.append(f"        # Expected status: {status}")
            lines.append("        # TODO: Implement test assertions")
            lines.append("        pass")
            lines.append("")

    code = "\n".join(lines)

    if output_path:
        with open(output_path, "w") as f:
            f.write(code)

    return code
