"""HTTP monkey-patching for requests and httpx."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, Callable

if TYPE_CHECKING:
    from mokra.core.world import WorldState


_original_request_send: Callable[..., Any] | None = None
_original_httpx_send: Callable[..., Any] | None = None
_active_world: WorldState | None = None


def install_interceptor(world: WorldState) -> None:
    """Install HTTP interceptors for requests and httpx."""
    global _active_world
    _active_world = world
    _patch_requests()
    _patch_httpx()


def uninstall_interceptor() -> None:
    """Remove HTTP interceptors and restore original behavior."""
    global _active_world
    _active_world = None
    _unpatch_requests()
    _unpatch_httpx()


def _patch_requests() -> None:
    """Patch the requests library."""
    global _original_request_send
    try:
        import requests.adapters

        if _original_request_send is None:
            _original_request_send = requests.adapters.HTTPAdapter.send

        def patched_send(self: Any, request: Any, *args: Any, **kwargs: Any) -> Any:
            if _active_world is not None:
                _active_world.record_request(
                    method=request.method,
                    url=request.url,
                    headers=dict(request.headers),
                    body=request.body,
                )
            response = _original_request_send(self, request, *args, **kwargs)
            if _active_world is not None:
                _active_world.record_response(
                    status_code=response.status_code,
                    headers=dict(response.headers),
                    body=response.text,
                )
            return response

        requests.adapters.HTTPAdapter.send = patched_send  # type: ignore[method-assign]
    except ImportError:
        pass


def _unpatch_requests() -> None:
    """Restore original requests behavior."""
    global _original_request_send
    if _original_request_send is not None:
        try:
            import requests.adapters

            requests.adapters.HTTPAdapter.send = _original_request_send  # type: ignore[method-assign]
        except ImportError:
            pass
        _original_request_send = None


def _patch_httpx() -> None:
    """Patch the httpx library."""
    global _original_httpx_send
    try:
        import httpx

        if _original_httpx_send is None:
            _original_httpx_send = httpx.Client.send

        def patched_send(self: Any, request: Any, *args: Any, **kwargs: Any) -> Any:
            if _active_world is not None:
                _active_world.record_request(
                    method=request.method,
                    url=str(request.url),
                    headers=dict(request.headers),
                    body=request.content.decode() if request.content else None,
                )
            response = _original_httpx_send(self, request, *args, **kwargs)
            if _active_world is not None:
                _active_world.record_response(
                    status_code=response.status_code,
                    headers=dict(response.headers),
                    body=response.text,
                )
            return response

        httpx.Client.send = patched_send  # type: ignore[method-assign]
    except ImportError:
        pass


def _unpatch_httpx() -> None:
    """Restore original httpx behavior."""
    global _original_httpx_send
    if _original_httpx_send is not None:
        try:
            import httpx

            httpx.Client.send = _original_httpx_send  # type: ignore[method-assign]
        except ImportError:
            pass
        _original_httpx_send = None
