"""WorldState and ServiceState classes for tracking observed behavior."""

from __future__ import annotations

from collections.abc import Iterator
from contextlib import contextmanager
from dataclasses import dataclass, field
from typing import Any

from mokra.adapters.classifier import classify_url
from mokra.output.terminal import render_world


@dataclass
class ServiceState:
    """State of a single external service."""

    name: str
    requests: list[dict[str, Any]] = field(default_factory=list)
    responses: list[dict[str, Any]] = field(default_factory=list)

    def add_request(self, request: dict[str, Any]) -> None:
        """Add a request to this service's history."""
        self.requests.append(request)

    def add_response(self, response: dict[str, Any]) -> None:
        """Add a response to this service's history."""
        self.responses.append(response)


@dataclass
class WorldState:
    """Tracks all observed external service interactions."""

    services: dict[str, ServiceState] = field(default_factory=dict)
    _pending_request: dict[str, Any] | None = field(default=None, repr=False)

    def record_request(
        self,
        method: str,
        url: str,
        headers: dict[str, str] | None = None,
        body: Any = None,
    ) -> None:
        """Record an outgoing HTTP request."""
        service_name = classify_url(url)
        if service_name not in self.services:
            self.services[service_name] = ServiceState(name=service_name)

        request = {
            "method": method,
            "url": url,
            "headers": headers or {},
            "body": body,
        }
        self.services[service_name].add_request(request)
        self._pending_request = {"service": service_name, "request": request}

    def record_response(
        self,
        status_code: int,
        headers: dict[str, str] | None = None,
        body: Any = None,
    ) -> None:
        """Record an incoming HTTP response."""
        if self._pending_request is None:
            return

        service_name = self._pending_request["service"]
        response = {
            "status_code": status_code,
            "headers": headers or {},
            "body": body,
        }
        self.services[service_name].add_response(response)
        self._pending_request = None

    def __str__(self) -> str:
        """Render the world state as a string."""
        return render_world(self)


@contextmanager
def observe() -> Iterator[WorldState]:
    """Context manager for observing HTTP interactions.

    Usage:
        with observe() as world:
            # Run your agent code here
            agent.run()

        print(world)  # See what happened
    """
    from mokra.core.interceptor import install_interceptor, uninstall_interceptor

    world = WorldState()
    install_interceptor(world)
    try:
        yield world
    finally:
        uninstall_interceptor()
