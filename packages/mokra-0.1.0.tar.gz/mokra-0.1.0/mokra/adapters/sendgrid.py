"""SendGrid deep adapter for email insights."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass
class SendGridAdapter:
    """Deep adapter for SendGrid API interactions."""

    emails: list[dict[str, Any]] = field(default_factory=list)
    templates: list[dict[str, Any]] = field(default_factory=list)

    def parse_request(self, request: dict[str, Any]) -> dict[str, Any]:
        """Parse a SendGrid API request into structured data.

        Args:
            request: The raw request dictionary.

        Returns:
            Structured data about the SendGrid operation.
        """
        url = request.get("url", "")

        if "/v3/mail/send" in url:
            return self._parse_email(request)
        elif "/v3/templates" in url:
            return self._parse_template(request)

        return {"type": "unknown", "raw": request}

    def _parse_email(self, request: dict[str, Any]) -> dict[str, Any]:
        """Parse an email send request."""
        body = request.get("body", {})
        return {
            "type": "email",
            "method": request.get("method"),
            "url": request.get("url"),
            "body": body,
        }

    def _parse_template(self, request: dict[str, Any]) -> dict[str, Any]:
        """Parse a template request."""
        return {
            "type": "template",
            "method": request.get("method"),
            "url": request.get("url"),
        }

    def summarize(self) -> str:
        """Summarize all SendGrid activity.

        Returns:
            A human-readable summary of SendGrid interactions.
        """
        parts = []
        if self.emails:
            parts.append(f"{len(self.emails)} email(s) sent")
        if self.templates:
            parts.append(f"{len(self.templates)} template operation(s)")

        return ", ".join(parts) if parts else "No SendGrid activity"
