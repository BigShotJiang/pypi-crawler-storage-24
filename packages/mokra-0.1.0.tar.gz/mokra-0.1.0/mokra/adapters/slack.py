"""Slack deep adapter for messaging insights."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass
class SlackAdapter:
    """Deep adapter for Slack API interactions."""

    messages: list[dict[str, Any]] = field(default_factory=list)
    channels: list[dict[str, Any]] = field(default_factory=list)
    reactions: list[dict[str, Any]] = field(default_factory=list)

    def parse_request(self, request: dict[str, Any]) -> dict[str, Any]:
        """Parse a Slack API request into structured data.

        Args:
            request: The raw request dictionary.

        Returns:
            Structured data about the Slack operation.
        """
        url = request.get("url", "")

        if "/chat.postMessage" in url:
            return self._parse_message(request)
        elif "/conversations" in url:
            return self._parse_channel(request)
        elif "/reactions" in url:
            return self._parse_reaction(request)

        return {"type": "unknown", "raw": request}

    def _parse_message(self, request: dict[str, Any]) -> dict[str, Any]:
        """Parse a message request."""
        return {
            "type": "message",
            "method": request.get("method"),
            "url": request.get("url"),
        }

    def _parse_channel(self, request: dict[str, Any]) -> dict[str, Any]:
        """Parse a channel request."""
        return {
            "type": "channel",
            "method": request.get("method"),
            "url": request.get("url"),
        }

    def _parse_reaction(self, request: dict[str, Any]) -> dict[str, Any]:
        """Parse a reaction request."""
        return {
            "type": "reaction",
            "method": request.get("method"),
            "url": request.get("url"),
        }

    def summarize(self) -> str:
        """Summarize all Slack activity.

        Returns:
            A human-readable summary of Slack interactions.
        """
        parts = []
        if self.messages:
            parts.append(f"{len(self.messages)} message(s)")
        if self.channels:
            parts.append(f"{len(self.channels)} channel operation(s)")
        if self.reactions:
            parts.append(f"{len(self.reactions)} reaction(s)")

        return ", ".join(parts) if parts else "No Slack activity"
