"""Email normalization adapter for SES, Mailgun, SendGrid, etc."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass
class EmailAdapter:
    """Unified adapter for email services (SES, Mailgun, SendGrid)."""

    emails_sent: list[dict[str, Any]] = field(default_factory=list)

    def normalize(self, service: str, request: dict[str, Any]) -> dict[str, Any]:
        """Normalize email data from various providers.

        Args:
            service: The email service name (aws-ses, mailgun, sendgrid).
            request: The raw request dictionary.

        Returns:
            Normalized email data structure.
        """
        if service == "aws-ses":
            return self._normalize_ses(request)
        elif service == "mailgun":
            return self._normalize_mailgun(request)
        elif service == "sendgrid":
            return self._normalize_sendgrid(request)

        return {"provider": service, "raw": request}

    def _normalize_ses(self, request: dict[str, Any]) -> dict[str, Any]:
        """Normalize AWS SES email data."""
        return {
            "provider": "aws-ses",
            "method": request.get("method"),
            "url": request.get("url"),
        }

    def _normalize_mailgun(self, request: dict[str, Any]) -> dict[str, Any]:
        """Normalize Mailgun email data."""
        return {
            "provider": "mailgun",
            "method": request.get("method"),
            "url": request.get("url"),
        }

    def _normalize_sendgrid(self, request: dict[str, Any]) -> dict[str, Any]:
        """Normalize SendGrid email data."""
        return {
            "provider": "sendgrid",
            "method": request.get("method"),
            "url": request.get("url"),
        }

    def summarize(self) -> str:
        """Summarize all email activity.

        Returns:
            A human-readable summary of email operations.
        """
        if not self.emails_sent:
            return "No emails sent"

        providers = {}
        for email in self.emails_sent:
            provider = email.get("provider", "unknown")
            providers[provider] = providers.get(provider, 0) + 1

        parts = [f"{count} via {provider}" for provider, count in providers.items()]
        return f"{len(self.emails_sent)} email(s) sent ({', '.join(parts)})"
