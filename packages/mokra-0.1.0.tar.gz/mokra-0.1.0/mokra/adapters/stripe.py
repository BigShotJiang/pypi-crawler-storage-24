"""Stripe deep adapter for rich payment insights."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass
class StripeAdapter:
    """Deep adapter for Stripe API interactions."""

    payment_intents: list[dict[str, Any]] = field(default_factory=list)
    customers: list[dict[str, Any]] = field(default_factory=list)
    subscriptions: list[dict[str, Any]] = field(default_factory=list)
    charges: list[dict[str, Any]] = field(default_factory=list)

    def parse_request(self, request: dict[str, Any]) -> dict[str, Any]:
        """Parse a Stripe API request into structured data.

        Args:
            request: The raw request dictionary.

        Returns:
            Structured data about the Stripe operation.
        """
        url = request.get("url", "")

        if "/v1/payment_intents" in url:
            return self._parse_payment_intent(request)
        elif "/v1/customers" in url:
            return self._parse_customer(request)
        elif "/v1/subscriptions" in url:
            return self._parse_subscription(request)

        return {"type": "unknown", "raw": request}

    def _parse_payment_intent(self, request: dict[str, Any]) -> dict[str, Any]:
        """Parse a payment intent request."""
        return {
            "type": "payment_intent",
            "method": request.get("method"),
            "url": request.get("url"),
        }

    def _parse_customer(self, request: dict[str, Any]) -> dict[str, Any]:
        """Parse a customer request."""
        return {
            "type": "customer",
            "method": request.get("method"),
            "url": request.get("url"),
        }

    def _parse_subscription(self, request: dict[str, Any]) -> dict[str, Any]:
        """Parse a subscription request."""
        return {
            "type": "subscription",
            "method": request.get("method"),
            "url": request.get("url"),
        }

    def summarize(self) -> str:
        """Summarize all Stripe activity.

        Returns:
            A human-readable summary of Stripe interactions.
        """
        parts = []
        if self.payment_intents:
            parts.append(f"{len(self.payment_intents)} payment intent(s)")
        if self.customers:
            parts.append(f"{len(self.customers)} customer(s)")
        if self.subscriptions:
            parts.append(f"{len(self.subscriptions)} subscription(s)")
        if self.charges:
            parts.append(f"{len(self.charges)} charge(s)")

        return ", ".join(parts) if parts else "No Stripe activity"
