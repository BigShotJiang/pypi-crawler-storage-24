"""Service adapters for deep integration with external APIs."""

from mokra.adapters.classifier import classify_url
from mokra.adapters.email import EmailAdapter
from mokra.adapters.sendgrid import SendGridAdapter
from mokra.adapters.slack import SlackAdapter
from mokra.adapters.stripe import StripeAdapter

__all__ = [
    "classify_url",
    "StripeAdapter",
    "SlackAdapter",
    "SendGridAdapter",
    "EmailAdapter",
]
