"""URL to service name mapping."""

from __future__ import annotations

import re
from urllib.parse import urlparse

# Known service patterns
SERVICE_PATTERNS: list[tuple[re.Pattern[str], str]] = [
    (re.compile(r"api\.stripe\.com"), "stripe"),
    (re.compile(r"slack\.com/api"), "slack"),
    (re.compile(r"api\.sendgrid\.com"), "sendgrid"),
    (re.compile(r"email.*\.amazonaws\.com"), "aws-ses"),
    (re.compile(r"api\.mailgun\.net"), "mailgun"),
    (re.compile(r"api\.openai\.com"), "openai"),
    (re.compile(r"api\.anthropic\.com"), "anthropic"),
    (re.compile(r"api\.github\.com"), "github"),
    (re.compile(r"api\.twilio\.com"), "twilio"),
]


def classify_url(url: str) -> str:
    """Classify a URL to a service name.

    Args:
        url: The URL to classify.

    Returns:
        The service name, or the hostname for unknown services.
    """
    parsed = urlparse(url)
    host = parsed.netloc or parsed.path.split("/")[0]

    for pattern, service_name in SERVICE_PATTERNS:
        if pattern.search(url):
            return service_name

    # Fallback to hostname
    return host.replace("www.", "").split(":")[0]
