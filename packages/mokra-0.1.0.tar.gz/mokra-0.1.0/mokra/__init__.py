"""mokra - See what your AI agent actually did. One line. Zero config."""

try:
    from mokra._version import __version__
except ImportError:
    __version__ = "0.0.0.dev0"

from mokra.core.test_generator import generate_tests
from mokra.core.world import WorldState, observe

__all__ = ["observe", "generate_tests", "WorldState", "__version__"]
