"""Rich terminal renderer for WorldState."""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from mokra.core.world import WorldState

try:
    from rich.console import Console
    from rich.table import Table

    RICH_AVAILABLE = True
except ImportError:
    RICH_AVAILABLE = False


def render_world(world: WorldState) -> str:
    """Render the world state as a formatted string.

    Args:
        world: The WorldState to render.

    Returns:
        A formatted string representation of the world state.
    """
    if not world.services:
        return "No external service interactions observed."

    if RICH_AVAILABLE:
        return _render_rich(world)
    return _render_plain(world)


def _render_rich(world: WorldState) -> str:
    """Render using Rich library."""
    console = Console(record=True, width=100)

    for service_name, service in world.services.items():
        table = Table(title=f"Service: {service_name}", show_header=True)
        table.add_column("Method", style="cyan")
        table.add_column("URL", style="green")
        table.add_column("Status", style="yellow")

        for i, request in enumerate(service.requests):
            status = "-"
            if i < len(service.responses):
                status = str(service.responses[i].get("status_code", "-"))

            table.add_row(
                request.get("method", "-"),
                _truncate(request.get("url", "-"), 60),
                status,
            )

        console.print(table)
        console.print()

    return console.export_text()


def _render_plain(world: WorldState) -> str:
    """Render as plain text."""
    lines = []

    for service_name, service in world.services.items():
        lines.append(f"=== {service_name} ===")

        for i, request in enumerate(service.requests):
            status = "-"
            if i < len(service.responses):
                status = str(service.responses[i].get("status_code", "-"))

            method = request.get("method", "-")
            url = _truncate(request.get("url", "-"), 60)
            lines.append(f"  {method} {url} -> {status}")

        lines.append("")

    return "\n".join(lines)


def _truncate(text: str, max_length: int) -> str:
    """Truncate text to max length with ellipsis."""
    if len(text) <= max_length:
        return text
    return text[: max_length - 3] + "..."
