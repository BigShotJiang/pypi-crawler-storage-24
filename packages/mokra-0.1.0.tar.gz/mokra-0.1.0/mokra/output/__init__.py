"""Output rendering for mokra."""

from mokra.output.terminal import render_world

__all__ = ["render_world"]
