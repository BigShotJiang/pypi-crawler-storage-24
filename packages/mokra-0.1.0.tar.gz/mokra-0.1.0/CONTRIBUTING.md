# Contributing to mokra

Thank you for your interest in contributing to mokra!

## Development Setup

1. Clone the repository:
   ```bash
   git clone https://github.com/handled-engineering/mokra-python.git
   cd mokra-python
   ```

2. Create a virtual environment:
   ```bash
   python -m venv venv
   source venv/bin/activate  # On Windows: venv\Scripts\activate
   ```

3. Install development dependencies:
   ```bash
   pip install -e ".[dev]"
   ```

## Running Tests

```bash
pytest
```

With coverage:
```bash
pytest --cov=mokra --cov-report=html
```

## Code Style

We use [ruff](https://github.com/astral-sh/ruff) for linting and formatting:

```bash
# Check linting
ruff check .

# Fix linting issues
ruff check --fix .

# Check formatting
ruff format --check .

# Format code
ruff format .
```

## Type Checking

```bash
mypy mokra
```

## Pull Request Process

1. Create a feature branch from `main`
2. Make your changes
3. Ensure tests pass and code is formatted
4. Submit a PR with a clear description
5. Wait for review and CI checks

## Commit Messages

- Use clear, descriptive commit messages
- Start with a verb (Add, Fix, Update, Remove, etc.)
- Keep the first line under 72 characters

## Reporting Issues

- Use the issue templates provided
- Include reproduction steps for bugs
- Provide context for feature requests
