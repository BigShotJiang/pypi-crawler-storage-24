# mokra

> See what your AI agent actually did. One line. Zero config.

[![PyPI version](https://badge.fury.io/py/mokra.svg)](https://badge.fury.io/py/mokra)
[![Python versions](https://img.shields.io/pypi/pyversions/mokra.svg)](https://pypi.org/project/mokra/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![CI](https://github.com/handled-engineering/mokra-python/actions/workflows/ci.yml/badge.svg)](https://github.com/handled-engineering/mokra-python/actions/workflows/ci.yml)

## Installation

```bash
pip install mokra
```

## Quick Start

```python
from mokra import observe

with observe() as world:
    # Run your AI agent here
    agent.run("Send a welcome email to new users")

# See exactly what happened
print(world)
```

## Features

- **Zero config**: Works out of the box with any HTTP-based service
- **Deep adapters**: Rich insights for Stripe, Slack, SendGrid, and more
- **Framework support**: First-class support for LangChain and CrewAI
- **Test generation**: Automatically generate pytest tests from observed behavior

## Supported Services

| Service | Adapter Type | Features |
|---------|-------------|----------|
| Stripe | Deep | Payment intents, customers, subscriptions |
| Slack | Deep | Messages, channels, reactions |
| SendGrid | Deep | Emails, templates, recipients |
| Any HTTP | Generic | Request/response logging |

## Documentation

- [Testing LangChain Agents in 60 Seconds](docs/testing_langchain_60s.md)
- [What Did My Agent Do?](docs/what_did_my_agent_do.md)

## Releases & Versioning

mokra follows [Semantic Versioning](https://semver.org/) with automatic version detection from git tags:

```
MAJOR.MINOR.PATCH

v0.1.0  →  First release
v0.1.1  →  Bug fix
v0.2.0  →  New feature
v1.0.0  →  Major/breaking change
```

**Pre-release versions:**
- `v0.1.0a1` - Alpha releases
- `v0.1.0b1` - Beta releases
- `v0.1.0rc1` - Release candidates

**Publishing a new version:**

```bash
git tag v0.2.0
git push origin v0.2.0
```

That's it! The version is read automatically from the git tag - no need to edit `pyproject.toml`.

> **Note:** PyPI requires unique version numbers - you cannot overwrite an existing version.

## Contributing

See [CONTRIBUTING.md](CONTRIBUTING.md) for guidelines.

## License

MIT License - see [LICENSE](LICENSE) for details.
