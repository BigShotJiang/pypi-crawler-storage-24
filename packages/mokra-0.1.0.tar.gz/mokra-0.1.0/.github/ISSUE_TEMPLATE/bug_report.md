---
name: Bug Report
about: Report a bug or unexpected behavior
title: '[BUG] '
labels: bug
assignees: ''
---

## Description
A clear and concise description of what the bug is.

## To Reproduce
Steps to reproduce the behavior:
1. ...
2. ...
3. ...

## Expected Behavior
A clear and concise description of what you expected to happen.

## Actual Behavior
What actually happened instead.

## Environment
- mokra version:
- Python version:
- OS:
- Relevant dependencies (requests/httpx version, etc.):

## Code Sample
```python
# Minimal code to reproduce the issue
```

## Error Output
```
# Any error messages or stack traces
```

## Additional Context
Add any other context about the problem here.
