"""Tests for SendGrid adapter."""

from mokra.adapters.sendgrid import SendGridAdapter


class TestSendGridAdapter:
    """Tests for SendGrid deep adapter."""

    def test_create_adapter(self) -> None:
        """Test creating a SendGrid adapter."""
        adapter = SendGridAdapter()
        assert adapter.emails == []
        assert adapter.templates == []

    def test_parse_email_request(self) -> None:
        """Test parsing an email send request."""
        adapter = SendGridAdapter()
        request = {
            "method": "POST",
            "url": "https://api.sendgrid.com/v3/mail/send",
        }
        result = adapter.parse_request(request)
        assert result["type"] == "email"

    def test_parse_template_request(self) -> None:
        """Test parsing a template request."""
        adapter = SendGridAdapter()
        request = {
            "method": "GET",
            "url": "https://api.sendgrid.com/v3/templates",
        }
        result = adapter.parse_request(request)
        assert result["type"] == "template"

    def test_summarize_empty(self) -> None:
        """Test summarizing empty adapter."""
        adapter = SendGridAdapter()
        assert adapter.summarize() == "No SendGrid activity"
