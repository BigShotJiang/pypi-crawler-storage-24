"""Tests for httpx library interception."""

import pytest

from mokra.core.interceptor import install_interceptor, uninstall_interceptor
from mokra.core.world import WorldState


class TestHttpxInterceptor:
    """Tests for httpx library monkey-patching."""

    def test_install_interceptor_handles_missing_httpx(self) -> None:
        """Test that install handles missing httpx gracefully."""
        world = WorldState()
        install_interceptor(world)
        uninstall_interceptor()

    @pytest.mark.skip(reason="Requires httpx to be installed")
    def test_interceptor_captures_httpx_request(self) -> None:
        """Test that interceptor captures httpx requests."""
        pass

    @pytest.mark.skip(reason="Requires httpx to be installed")
    def test_interceptor_captures_httpx_response(self) -> None:
        """Test that interceptor captures httpx responses."""
        pass
