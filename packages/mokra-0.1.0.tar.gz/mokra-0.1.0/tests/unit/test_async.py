"""Tests for async support."""

import pytest


class TestAsyncSupport:
    """Tests for async HTTP interception."""

    @pytest.mark.skip(reason="Async support not yet implemented")
    async def test_async_requests_captured(self) -> None:
        """Test that async requests are captured."""
        pass

    @pytest.mark.skip(reason="Async support not yet implemented")
    async def test_async_httpx_captured(self) -> None:
        """Test that async httpx requests are captured."""
        pass
