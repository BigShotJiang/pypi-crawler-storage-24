"""Tests for test generator."""

import os
import tempfile

from mokra.core.test_generator import generate_tests
from mokra.core.world import WorldState


class TestTestGenerator:
    """Tests for auto-test generation."""

    def test_generate_tests_empty_world(self) -> None:
        """Test generating tests from empty world."""
        world = WorldState()
        result = generate_tests(world)
        assert "import pytest" in result

    def test_generate_tests_with_service(self, world_with_stripe: WorldState) -> None:
        """Test generating tests with service interactions."""
        result = generate_tests(world_with_stripe)
        assert "class TestStripe" in result
        assert "def test_post_request_0" in result

    def test_generate_tests_writes_to_file(self) -> None:
        """Test that generate_tests can write to a file."""
        world = WorldState()
        world.record_request(method="GET", url="https://example.com")
        world.record_response(status_code=200)

        with tempfile.TemporaryDirectory() as tmpdir:
            output_path = os.path.join(tmpdir, "test_generated.py")
            generate_tests(world, output_path=output_path)
            assert os.path.exists(output_path)
            with open(output_path) as f:
                content = f.read()
                assert "import pytest" in content
