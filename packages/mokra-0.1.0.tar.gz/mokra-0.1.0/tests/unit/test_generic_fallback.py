"""Tests for generic fallback behavior."""

from mokra.adapters.classifier import classify_url
from mokra.core.world import WorldState


class TestGenericFallback:
    """Tests for generic fallback when no deep adapter exists."""

    def test_unknown_service_uses_hostname(self) -> None:
        """Test that unknown services fall back to hostname."""
        url = "https://custom-api.mycompany.com/v1/users"
        service = classify_url(url)
        assert service == "custom-api.mycompany.com"

    def test_generic_request_recorded(self) -> None:
        """Test that generic requests are recorded."""
        world = WorldState()
        world.record_request(
            method="POST",
            url="https://custom-api.example.com/endpoint",
        )
        world.record_response(status_code=200)
        assert "custom-api.example.com" in world.services

    def test_multiple_unknown_services(self) -> None:
        """Test multiple unknown services are tracked separately."""
        world = WorldState()
        world.record_request(method="GET", url="https://api1.example.com/a")
        world.record_response(status_code=200)
        world.record_request(method="GET", url="https://api2.example.com/b")
        world.record_response(status_code=200)
        assert len(world.services) == 2
