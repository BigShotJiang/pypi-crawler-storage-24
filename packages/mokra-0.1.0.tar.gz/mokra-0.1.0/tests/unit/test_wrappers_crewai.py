"""Tests for CrewAI wrappers."""

import pytest

from mokra.core.wrappers import wrap_crewai


class TestCrewAIWrapper:
    """Tests for CrewAI crew wrapping."""

    def test_wrap_crewai_returns_crew(self) -> None:
        """Test that wrap_crewai returns the crew."""
        mock_crew = {"type": "crewai_crew"}
        wrapped = wrap_crewai(mock_crew)
        assert wrapped == mock_crew

    @pytest.mark.skip(reason="CrewAI integration not yet implemented")
    def test_wrap_crewai_captures_agent_actions(self) -> None:
        """Test that wrapped crew captures agent actions."""
        pass
