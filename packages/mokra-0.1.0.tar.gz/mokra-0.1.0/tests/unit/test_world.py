"""Tests for WorldState and ServiceState."""

from mokra.core.world import ServiceState, WorldState, observe


class TestServiceState:
    """Tests for ServiceState class."""

    def test_create_service_state(self) -> None:
        """Test creating a ServiceState."""
        service = ServiceState(name="test-service")
        assert service.name == "test-service"
        assert service.requests == []
        assert service.responses == []

    def test_add_request(self) -> None:
        """Test adding a request to ServiceState."""
        service = ServiceState(name="test-service")
        service.add_request({"method": "GET", "url": "https://example.com"})
        assert len(service.requests) == 1

    def test_add_response(self) -> None:
        """Test adding a response to ServiceState."""
        service = ServiceState(name="test-service")
        service.add_response({"status_code": 200})
        assert len(service.responses) == 1


class TestWorldState:
    """Tests for WorldState class."""

    def test_create_world_state(self) -> None:
        """Test creating a WorldState."""
        world = WorldState()
        assert world.services == {}

    def test_record_request_creates_service(self) -> None:
        """Test that recording a request creates a service."""
        world = WorldState()
        world.record_request(
            method="GET",
            url="https://api.stripe.com/v1/customers",
        )
        assert "stripe" in world.services

    def test_record_response(self) -> None:
        """Test recording a response."""
        world = WorldState()
        world.record_request(
            method="GET",
            url="https://api.stripe.com/v1/customers",
        )
        world.record_response(status_code=200)
        assert len(world.services["stripe"].responses) == 1

    def test_record_response_without_request(self) -> None:
        """Test that response without request is ignored."""
        world = WorldState()
        world.record_response(status_code=200)
        assert world.services == {}

    def test_str_empty_world(self) -> None:
        """Test string representation of empty world."""
        world = WorldState()
        result = str(world)
        assert "No external service interactions" in result


class TestObserve:
    """Tests for observe context manager."""

    def test_observe_returns_world_state(self) -> None:
        """Test that observe returns a WorldState."""
        with observe() as world:
            assert isinstance(world, WorldState)

    def test_observe_cleans_up_on_exit(self) -> None:
        """Test that observe cleans up interceptors."""
        with observe() as _world:
            pass
