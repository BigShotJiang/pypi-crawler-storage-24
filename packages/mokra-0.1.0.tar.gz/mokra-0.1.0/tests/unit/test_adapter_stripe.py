"""Tests for Stripe adapter."""

from mokra.adapters.stripe import StripeAdapter


class TestStripeAdapter:
    """Tests for Stripe deep adapter."""

    def test_create_adapter(self) -> None:
        """Test creating a Stripe adapter."""
        adapter = StripeAdapter()
        assert adapter.payment_intents == []
        assert adapter.customers == []

    def test_parse_payment_intent_request(self) -> None:
        """Test parsing a payment intent request."""
        adapter = StripeAdapter()
        request = {
            "method": "POST",
            "url": "https://api.stripe.com/v1/payment_intents",
        }
        result = adapter.parse_request(request)
        assert result["type"] == "payment_intent"

    def test_parse_customer_request(self) -> None:
        """Test parsing a customer request."""
        adapter = StripeAdapter()
        request = {
            "method": "GET",
            "url": "https://api.stripe.com/v1/customers/cus_xxx",
        }
        result = adapter.parse_request(request)
        assert result["type"] == "customer"

    def test_parse_subscription_request(self) -> None:
        """Test parsing a subscription request."""
        adapter = StripeAdapter()
        request = {
            "method": "POST",
            "url": "https://api.stripe.com/v1/subscriptions",
        }
        result = adapter.parse_request(request)
        assert result["type"] == "subscription"

    def test_parse_unknown_request(self) -> None:
        """Test parsing an unknown Stripe request."""
        adapter = StripeAdapter()
        request = {
            "method": "GET",
            "url": "https://api.stripe.com/v1/unknown",
        }
        result = adapter.parse_request(request)
        assert result["type"] == "unknown"

    def test_summarize_empty(self) -> None:
        """Test summarizing empty adapter."""
        adapter = StripeAdapter()
        assert adapter.summarize() == "No Stripe activity"
