"""Tests for Slack adapter."""

from mokra.adapters.slack import SlackAdapter


class TestSlackAdapter:
    """Tests for Slack deep adapter."""

    def test_create_adapter(self) -> None:
        """Test creating a Slack adapter."""
        adapter = SlackAdapter()
        assert adapter.messages == []
        assert adapter.channels == []

    def test_parse_message_request(self) -> None:
        """Test parsing a message request."""
        adapter = SlackAdapter()
        request = {
            "method": "POST",
            "url": "https://slack.com/api/chat.postMessage",
        }
        result = adapter.parse_request(request)
        assert result["type"] == "message"

    def test_parse_channel_request(self) -> None:
        """Test parsing a channel request."""
        adapter = SlackAdapter()
        request = {
            "method": "GET",
            "url": "https://slack.com/api/conversations.list",
        }
        result = adapter.parse_request(request)
        assert result["type"] == "channel"

    def test_parse_reaction_request(self) -> None:
        """Test parsing a reaction request."""
        adapter = SlackAdapter()
        request = {
            "method": "POST",
            "url": "https://slack.com/api/reactions.add",
        }
        result = adapter.parse_request(request)
        assert result["type"] == "reaction"

    def test_summarize_empty(self) -> None:
        """Test summarizing empty adapter."""
        adapter = SlackAdapter()
        assert adapter.summarize() == "No Slack activity"
