"""Tests for URL to service classification."""

from mokra.adapters.classifier import classify_url


class TestClassifier:
    """Tests for URL classification."""

    def test_classify_stripe_url(self) -> None:
        """Test Stripe URL classification."""
        url = "https://api.stripe.com/v1/payment_intents"
        assert classify_url(url) == "stripe"

    def test_classify_slack_url(self) -> None:
        """Test Slack URL classification."""
        url = "https://slack.com/api/chat.postMessage"
        assert classify_url(url) == "slack"

    def test_classify_sendgrid_url(self) -> None:
        """Test SendGrid URL classification."""
        url = "https://api.sendgrid.com/v3/mail/send"
        assert classify_url(url) == "sendgrid"

    def test_classify_openai_url(self) -> None:
        """Test OpenAI URL classification."""
        url = "https://api.openai.com/v1/chat/completions"
        assert classify_url(url) == "openai"

    def test_classify_anthropic_url(self) -> None:
        """Test Anthropic URL classification."""
        url = "https://api.anthropic.com/v1/messages"
        assert classify_url(url) == "anthropic"

    def test_classify_unknown_url_returns_hostname(self) -> None:
        """Test unknown URL returns hostname."""
        url = "https://custom-api.example.com/endpoint"
        assert classify_url(url) == "custom-api.example.com"

    def test_classify_url_strips_www(self) -> None:
        """Test that www. is stripped from hostname."""
        url = "https://www.example.com/api"
        assert classify_url(url) == "example.com"

    def test_classify_aws_ses(self) -> None:
        """Test AWS SES URL classification."""
        url = "https://email.us-east-1.amazonaws.com"
        assert classify_url(url) == "aws-ses"

    def test_classify_mailgun(self) -> None:
        """Test Mailgun URL classification."""
        url = "https://api.mailgun.net/v3/messages"
        assert classify_url(url) == "mailgun"
