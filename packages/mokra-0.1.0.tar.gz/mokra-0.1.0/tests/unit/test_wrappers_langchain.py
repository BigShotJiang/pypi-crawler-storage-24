"""Tests for LangChain wrappers."""

import pytest

from mokra.core.wrappers import wrap_langchain


class TestLangChainWrapper:
    """Tests for LangChain agent wrapping."""

    def test_wrap_langchain_returns_agent(self) -> None:
        """Test that wrap_langchain returns the agent."""
        mock_agent = {"type": "langchain_agent"}
        wrapped = wrap_langchain(mock_agent)
        assert wrapped == mock_agent

    @pytest.mark.skip(reason="LangChain integration not yet implemented")
    def test_wrap_langchain_captures_tool_calls(self) -> None:
        """Test that wrapped agent captures tool calls."""
        pass
