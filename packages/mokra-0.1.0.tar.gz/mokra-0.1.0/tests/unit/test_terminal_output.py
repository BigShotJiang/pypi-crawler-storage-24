"""Tests for terminal output rendering."""

from mokra.core.world import WorldState
from mokra.output.terminal import _truncate, render_world


class TestTerminalOutput:
    """Tests for terminal output rendering."""

    def test_render_empty_world(self) -> None:
        """Test rendering an empty world."""
        world = WorldState()
        result = render_world(world)
        assert "No external service interactions" in result

    def test_render_world_with_service(self, world_with_stripe: WorldState) -> None:
        """Test rendering a world with service interactions."""
        result = render_world(world_with_stripe)
        assert "stripe" in result.lower()

    def test_truncate_short_text(self) -> None:
        """Test truncate with short text."""
        result = _truncate("hello", 10)
        assert result == "hello"

    def test_truncate_long_text(self) -> None:
        """Test truncate with long text."""
        result = _truncate("hello world this is long", 10)
        assert result == "hello w..."
        assert len(result) == 10

    def test_truncate_exact_length(self) -> None:
        """Test truncate with exact length text."""
        result = _truncate("hello", 5)
        assert result == "hello"
