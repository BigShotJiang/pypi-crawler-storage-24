"""Tests for email normalization adapter."""

from mokra.adapters.email import EmailAdapter


class TestEmailAdapter:
    """Tests for email normalization adapter."""

    def test_create_adapter(self) -> None:
        """Test creating an email adapter."""
        adapter = EmailAdapter()
        assert adapter.emails_sent == []

    def test_normalize_ses(self) -> None:
        """Test normalizing SES email."""
        adapter = EmailAdapter()
        request = {
            "method": "POST",
            "url": "https://email.us-east-1.amazonaws.com",
        }
        result = adapter.normalize("aws-ses", request)
        assert result["provider"] == "aws-ses"

    def test_normalize_mailgun(self) -> None:
        """Test normalizing Mailgun email."""
        adapter = EmailAdapter()
        request = {
            "method": "POST",
            "url": "https://api.mailgun.net/v3/messages",
        }
        result = adapter.normalize("mailgun", request)
        assert result["provider"] == "mailgun"

    def test_normalize_sendgrid(self) -> None:
        """Test normalizing SendGrid email."""
        adapter = EmailAdapter()
        request = {
            "method": "POST",
            "url": "https://api.sendgrid.com/v3/mail/send",
        }
        result = adapter.normalize("sendgrid", request)
        assert result["provider"] == "sendgrid"

    def test_normalize_unknown(self) -> None:
        """Test normalizing unknown email provider."""
        adapter = EmailAdapter()
        request = {"method": "POST", "url": "https://unknown.com"}
        result = adapter.normalize("unknown", request)
        assert result["provider"] == "unknown"

    def test_summarize_empty(self) -> None:
        """Test summarizing empty adapter."""
        adapter = EmailAdapter()
        assert adapter.summarize() == "No emails sent"
