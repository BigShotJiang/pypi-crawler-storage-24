"""Shared pytest fixtures for mokra tests."""

import pytest

from mokra.core.world import WorldState


@pytest.fixture
def empty_world() -> WorldState:
    """Create an empty WorldState for testing."""
    return WorldState()


@pytest.fixture
def world_with_stripe() -> WorldState:
    """Create a WorldState with Stripe interactions."""
    world = WorldState()
    world.record_request(
        method="POST",
        url="https://api.stripe.com/v1/payment_intents",
        headers={"Authorization": "Bearer sk_test_xxx"},
        body={"amount": 1000, "currency": "usd"},
    )
    world.record_response(
        status_code=200,
        headers={"Content-Type": "application/json"},
        body='{"id": "pi_xxx", "status": "succeeded"}',
    )
    return world


@pytest.fixture
def world_with_slack() -> WorldState:
    """Create a WorldState with Slack interactions."""
    world = WorldState()
    world.record_request(
        method="POST",
        url="https://slack.com/api/chat.postMessage",
        headers={"Authorization": "Bearer xoxb-xxx"},
        body={"channel": "C123", "text": "Hello!"},
    )
    world.record_response(
        status_code=200,
        headers={"Content-Type": "application/json"},
        body='{"ok": true, "ts": "123.456"}',
    )
    return world


@pytest.fixture
def world_with_multiple_services() -> WorldState:
    """Create a WorldState with multiple service interactions."""
    world = WorldState()

    # Stripe
    world.record_request(
        method="POST",
        url="https://api.stripe.com/v1/customers",
        headers={},
        body={},
    )
    world.record_response(status_code=200, headers={}, body="{}")

    # Slack
    world.record_request(
        method="POST",
        url="https://slack.com/api/chat.postMessage",
        headers={},
        body={},
    )
    world.record_response(status_code=200, headers={}, body="{}")

    # SendGrid
    world.record_request(
        method="POST",
        url="https://api.sendgrid.com/v3/mail/send",
        headers={},
        body={},
    )
    world.record_response(status_code=202, headers={}, body="")

    return world
