"""Integration tests for full SendGrid pipeline."""

import pytest


class TestFullPipelineSendGrid:
    """Integration tests for SendGrid observation pipeline."""

    @pytest.mark.skip(reason="Requires SendGrid API key")
    def test_observe_sendgrid_send_email(self) -> None:
        """Test observing a SendGrid email send."""
        pass

    @pytest.mark.skip(reason="Requires SendGrid API key")
    def test_observe_sendgrid_template_email(self) -> None:
        """Test observing a SendGrid template email."""
        pass
