"""Integration tests for multi-service observation."""

import pytest

from mokra.core.world import WorldState


class TestMultiService:
    """Integration tests for observing multiple services."""

    def test_observe_multiple_services_synthetic(
        self, world_with_multiple_services: WorldState
    ) -> None:
        """Test that multiple services are tracked separately."""
        world = world_with_multiple_services
        assert "stripe" in world.services
        assert "slack" in world.services
        assert "sendgrid" in world.services
        assert len(world.services) == 3

    @pytest.mark.skip(reason="Requires multiple service credentials")
    def test_observe_real_multi_service_agent(self) -> None:
        """Test observing a real agent using multiple services."""
        pass
