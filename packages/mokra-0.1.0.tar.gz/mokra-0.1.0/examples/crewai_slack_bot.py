"""Example: Observing a CrewAI crew that sends Slack messages."""

from mokra import observe


def main() -> None:
    """Run the example."""
    with observe() as world:
        # Your CrewAI crew code here
        # crew = create_slack_crew()
        # crew.kickoff()
        print("Running CrewAI Slack bot...")
        print("(This is a placeholder - add your crew code)")

    print("\n=== What happened ===")
    print(world)


if __name__ == "__main__":
    main()
