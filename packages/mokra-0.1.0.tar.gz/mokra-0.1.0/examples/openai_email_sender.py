"""Example: Observing an OpenAI-powered email sender."""

from mokra import observe


def main() -> None:
    """Run the example."""
    with observe() as world:
        # Your OpenAI + email code here
        # response = openai.chat.completions.create(...)
        # sendgrid.send(Mail(...))
        print("Running OpenAI email sender...")
        print("(This is a placeholder - add your code)")

    print("\n=== What happened ===")
    print(world)


if __name__ == "__main__":
    main()
