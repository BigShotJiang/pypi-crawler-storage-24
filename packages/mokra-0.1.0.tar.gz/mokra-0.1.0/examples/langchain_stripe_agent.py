"""Example: Observing a LangChain agent that uses Stripe."""

from mokra import observe


def main() -> None:
    """Run the example."""
    with observe() as world:
        # Your LangChain agent code here
        # agent = create_stripe_agent()
        # agent.run("Create a payment intent for $50")
        print("Running LangChain Stripe agent...")
        print("(This is a placeholder - add your agent code)")

    print("\n=== What happened ===")
    print(world)


if __name__ == "__main__":
    main()
