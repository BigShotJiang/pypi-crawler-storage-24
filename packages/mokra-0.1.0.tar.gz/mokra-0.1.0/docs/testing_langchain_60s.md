# Testing LangChain Agents in 60 Seconds

This guide shows you how to add observability to your LangChain agents with mokra.

## Quick Start

```python
from mokra import observe
from your_agent import create_agent

# Wrap your agent run in observe()
with observe() as world:
    agent = create_agent()
    agent.run("Process the customer's refund request")

# See what external services were called
print(world)
```

## What You Get

When you print the world state, you'll see:
- Every HTTP request your agent made
- Which services were called (Stripe, Slack, SendGrid, etc.)
- Request/response status codes
- A timeline of all operations

## Generating Tests

mokra can automatically generate pytest tests from observed behavior:

```python
from mokra import observe, generate_tests

with observe() as world:
    agent.run("Send welcome email to new customer")

# Generate test code
test_code = generate_tests(world, output_path="tests/test_welcome_flow.py")
```

## Framework Integration

For deeper LangChain integration:

```python
from mokra.core.wrappers import wrap_langchain

agent = create_agent()
wrapped_agent = wrap_langchain(agent)

with observe() as world:
    wrapped_agent.run("Your prompt here")
```

## Next Steps

- Check out the [examples/](../examples/) directory for complete examples
- Read [What Did My Agent Do?](what_did_my_agent_do.md) for deeper insights
