# What Did My Agent Do?

When working with AI agents, it's often hard to know exactly what external actions they took. Did it actually send that email? What data did it send to Stripe? mokra answers these questions.

## The Problem

AI agents are increasingly autonomous, making decisions and taking actions on your behalf. But:
- How do you know what they actually did?
- How do you test agent behavior?
- How do you debug when something goes wrong?

## The Solution

mokra intercepts all HTTP traffic from your agent and presents it in a human-readable format:

```python
from mokra import observe

with observe() as world:
    agent.run("Onboard the new customer")

print(world)
```

Output:
```
=== stripe ===
  POST https://api.stripe.com/v1/customers -> 200
  POST https://api.stripe.com/v1/subscriptions -> 200

=== sendgrid ===
  POST https://api.sendgrid.com/v3/mail/send -> 202

=== slack ===
  POST https://slack.com/api/chat.postMessage -> 200
```

## Deep Adapters

For popular services, mokra provides "deep adapters" that understand the semantics of each API:

### Stripe
- Tracks payment intents, customers, subscriptions
- Shows amounts and currencies
- Identifies webhook events

### Slack
- Shows channel names and message content
- Tracks reactions and thread replies
- Identifies bot vs user messages

### SendGrid
- Shows recipient email addresses
- Tracks template usage
- Identifies email subjects

## Generic Fallback

For services without a deep adapter, mokra still captures:
- HTTP method and URL
- Status codes
- Request/response timing

## Use Cases

1. **Testing**: Generate regression tests from observed behavior
2. **Debugging**: See exactly what went wrong
3. **Auditing**: Track all external actions for compliance
4. **Development**: Understand agent behavior during development

## Best Practices

1. Always wrap agent runs in `observe()`
2. Use `generate_tests()` to create regression tests
3. Review observed behavior before deploying to production
