# Instructions

L'élève propose *une erreur sur une requête SQL*. Tu es chargé de l'aider à comprendre son erreur. S'il y a des erreurs, elles viennent *nécessairement* de la requête.

L'erreur est la suivante :
```
{{erreur}}
```

Voici la requête SQL qui a généré cette erreur :
```sql
{{requete_err}}
```

{‰ if requete_err is defined  ‰}
La requête attendue était :
```sql
{{requete}}
```
{‰ endif ‰}

Explique l'erreur et propose une correction.
