from querycraft.LLM import manage_ia2, format_ia
from querycraft.tools import clear_line, colorize_sql, cadre,colorize_sql_html,Spinner,markdown_to_html
import colorama

class SQLException(Exception):

    def __init__(self, message):
        super().__init__(message)
        self.message = message

    def __str__(self):
        return self.message

    def __repr__(self):
        return self.message

    def __unicode__(self):
        return self.message


class SQLQueryException(SQLException):
    cfg = None
    ia_on = False

    @classmethod
    def setCfg(cls, cfg):
        SQLQueryException.cfg = cfg
        SQLQueryException.ia_on = cfg['IA']['mode'] == 'on'

    def __init__(self, verbose, message, sqlhs, sqlok, sgbd, bd="", output='txt'):
        super().__init__(message)
        self.sqlhs = sqlhs
        self.sqlok = sqlok
        if sqlok is None:
            self.sqloktxt = ""
        else:
            self.sqloktxt = f"{sqlok}"
        self.sgbd = sgbd
        self.verbose = verbose
        self.output = output
        self.hints = None

        self.err = cadre("Erreur de syntaxe",'=',couleur=colorama.Fore.RED,output=output)

        if output == 'txt' :
            self.err += cadre("Requête proposée",'-',couleur=colorama.Fore.RED,output=output)
            req = colorize_sql(str(self.sqlhs))
            self.err += f"{req}\n\n"
            self.err += cadre(f"Message {self.sgbd}", '-',couleur=colorama.Fore.RED,output=output)
            self.err += f"{colorama.Fore.RED}{self.message}{colorama.Style.RESET_ALL}\n\n"  # Affichage de l'erreur de base
        elif output == 'md' :
            self.err += cadre("Requête proposée", '-', couleur=colorama.Fore.RED, output=output)
            self.err += f"\n```sql\n{colorize_sql(str(self.sqlhs))}\n```\n\n"
            self.err += cadre(f"Message {self.sgbd}", '-',couleur=colorama.Fore.RED,output=output)
            self.err += f"\n{self.message}\n\n"  # Affichage de l'erreur de base
        elif output == 'html' :
            self.err += "<br>"
            self.err += cadre("Requête proposée", '-', couleur=colorama.Fore.RED, output=output)
            req = colorize_sql_html(str(self.sqlhs))
            self.err += f"\n<br><div class='info'>{req}</div><br>\n\n"
            self.err += cadre(f"Message {self.sgbd}", '-',output=output)
            self.err += f"\n<br><div class='error'><pre><code>{self.message}</code></pre></div><br>\n\n"  # Affichage de l'erreur de base

        if verbose and SQLQueryException.ia_on:
            with Spinner("Construction de l'explication avec l'IA générative") :
                self.hints = manage_ia2('error', SQLQueryException.cfg, verbose, f"{self.sqlhs}{self.sqloktxt}", bd,
                                       f"{message}", sqlhs, sqlok, None)
            clear_line()

    def __str__(self):
        return self.err

    def __repr__(self):
        return self.__str__()

    def __unicode__(self):
        return self.__str__()
