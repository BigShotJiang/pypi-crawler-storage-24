from youtubesearchpython.__future__ import *
import asyncio

async def main():
    video = await Video.get('https://www.youtube.com/watch?v=z0GKGpObgPY', get_upload_date=True)
    print(video)
    videoInfo = await Video.getInfo('https://youtu.be/z0GKGpObgPY')
    print(videoInfo)
    videoFormats = await Video.getFormats('z0GKGpObgPY')
    print(videoFormats)


    suggestions = await Suggestions.get('NoCopyrightSounds', language = 'en', region = 'US')
    print(suggestions)


    hashtag = Hashtag('ncs', limit = 1)
    result = await hashtag.next()
    print(result)


    try:
        fetcher = StreamURLFetcher()
        await fetcher.getJavaScript()
        videoA = await Video.get("https://www.youtube.com/watch?v=dQw4w9WgXcQ")
        videoB = await Video.get("https://www.youtube.com/watch?v=9bZkp7q19f0")
        singleUrlA = await fetcher.get(videoA, 18)
        allUrlsB = await fetcher.getAll(videoB)
        print(singleUrlA)
        print(allUrlsB)
    except Exception as e:
        print(f"StreamURLFetcher test skipped: {e}")


    comments = Comments("_ZdsmLgCVdU")
    await comments.getNextComments()
    while len(comments.comments["result"]) < 100:
        print(len(comments.comments["result"]))
        await comments.getNextComments()
    print("Found all comments")

    
    transcript_result = await Transcript.get("https://www.youtube.com/watch?v=L7kF4MXXCoA")
    print(transcript_result)

    url = "https://www.youtube.com/watch?v=-1xu0IP35FI"

    transcript_en = await Transcript.get(url)
    if transcript_en["languages"]:
        transcript_2 = await Transcript.get(url, transcript_en["languages"][-1]["params"])
        print(transcript_2)
    else:
        print("No languages available for translation test")


    print(await Channel.get("UC_aEa8K-EOJ3D6gOs7HcyNg"))

    # Retrieve playlists of a channel
    channel = Channel("UC_aEa8K-EOJ3D6gOs7HcyNg")
    await channel.init()
    print(len(channel.result["playlists"]))
    while channel.has_more_playlists():
        await channel.next()
        print(len(channel.result["playlists"]))


asyncio.run(main())
