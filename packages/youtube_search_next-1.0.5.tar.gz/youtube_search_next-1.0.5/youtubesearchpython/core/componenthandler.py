from typing import Union, List
from urllib.parse import urlparse, parse_qs


def getValue(source: dict, path: List[str]) -> Union[str, int, dict, None]:
    value = source
    for key in path:
        if type(key) is str:
            if key in value.keys():
                value = value[key]
            else:
                value = None
                break
        elif type(key) is int:
            if len(value) != 0:
                value = value[key]
            else:
                value = None
                break
    return value


def getVideoId(videoLink: str) -> str:
    if not videoLink:
        return None
    try:
        parsed = urlparse(videoLink)
    except ValueError:
        return videoLink
    hostname = parsed.hostname or ''
    if hostname in ('youtu.be', 'www.youtu.be'):
        path = parsed.path.rstrip('/')
        return path.split('/')[-1] if path else videoLink
    elif hostname in ('youtube.com', 'www.youtube.com', 'm.youtube.com'):
        qs = parse_qs(parsed.query)
        if 'v' in qs:
            return qs['v'][0]
    return videoLink

