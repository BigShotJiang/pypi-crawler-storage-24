"""
antaris-forge v1.0.1

Memory, safety, and context for Antaris Forge bots.

Packages:
    antaris_memory  -- BM25 + semantic search, audit logging, co-occurrence PPMI
    antaris_guard   -- Prompt safety screening and injection detection
    antaris_context -- Token budget management and context windowing

Install:
    pip install antaris-forge            # core
    pip install antaris-forge[semantic]  # + transformer embeddings
"""

__version__ = "1.0.5"

MEMORY_CAP = 25000


def create_memory(workspace: str = ".", **kwargs):
    """Create a MemorySystem with Forge tier cap (25,000 entries)."""
    from antaris_memory import MemorySystem
    return MemorySystem(workspace, max_entries=MEMORY_CAP, **kwargs)


__all__ = ["__version__", "MEMORY_CAP", "create_memory"]
