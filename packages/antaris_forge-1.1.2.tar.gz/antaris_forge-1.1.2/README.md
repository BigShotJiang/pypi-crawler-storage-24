# antaris-forge

**Memory, safety, and context for Antaris Forge bots.**

`antaris-forge` is the stable runtime package for Forge-powered AI agents. It bundles the three core infrastructure packages in a single install.

## Packages

| Package | Purpose |
|---------|---------|
| [`antaris-memory`](antaris-memory/) | File-based persistent memory — BM25 search, audit logging, semantic re-ranking, PPMI co-occurrence |
| [`antaris-guard`](antaris-guard/) | Prompt safety screening and injection detection |
| [`antaris-context`](antaris-context/) | Token budget management and context window optimization |

## Quick Start

```python
from antaris_memory import MemorySystem
from antaris_guard import PromptGuard
from antaris_context import ContextManager

# Memory
mem = MemorySystem("./workspace")
mem.ingest("Patient: John, 42M, elevated liver enzymes noted on 2024-01-15")
results = mem.search("liver")

# Safety
guard = PromptGuard()
result = guard.analyze("Tell me about liver function tests")

# Context
ctx = ContextManager(total_budget=8000)
ctx.add_turn("system", "You are a helpful medical assistant.")
window = ctx.render()
```

## Design

- **File-based** — JSON/JSONL storage, zero databases
- **Zero mandatory dependencies** — pure Python core
- **Thread-safe** — concurrent reads and writes handled correctly
- **Privacy-first** — HMAC-SHA256 PII anonymization, local-only by default

## Versioning

`antaris-forge` is the stable Forge fork of [`antaris-suite`](https://github.com/Antaris-Analytics/antaris-suite). 

- Bug fixes and security patches land here
- New features and experimental work land in `antaris-suite` first
- Production Forge bots should pin to `antaris-forge~=1.0`

## License

Apache 2.0 — see [LICENSE](LICENSE)
