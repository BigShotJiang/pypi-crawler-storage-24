from typing import Callable, Tuple

import numba
import numpy as np


@numba.njit
def combined_metric(
    x: np.ndarray,
    y: np.ndarray,
    blocks: np.ndarray,
    weights: np.ndarray,
    metrics: Tuple[Callable[[np.ndarray, np.ndarray], float], ...],
):
    d = 0.0
    for i in range(len(blocks)):
        start, end = blocks[i]
        partial_d = metrics[i](x[start:end], y[start:end])
        d += weights[i] * partial_d

    return d


# ensures a consistent Numba type signature for functions passed into jitted functions
# this is used for the metrics argument in combined_metric()
def typed_metric_wrapper(f):
    return numba.jit("f4(f4[:],f4[:])")(f.py_func)


def partial_metric(dist_fn, kwargs: dict):
    args = tuple(kwargs.values())

    @numba.njit("f4(f4[:],f4[:])")
    def d(x, y):
        return dist_fn(x, y, *args)

    return d


@numba.njit
def combined_metric_sparse(
    ind1: np.ndarray,
    data1: np.ndarray,
    ind2: np.ndarray,
    data2: np.ndarray,
    blocks: np.ndarray,
    weights: np.ndarray,
    metrics: Tuple[
        Callable[[np.ndarray, np.ndarray, np.ndarray, np.ndarray, int], float], ...
    ],
):
    d = 0.0
    for i in range(len(blocks)):
        # assuming ind is sorted
        start1, end1 = np.searchsorted(ind1, blocks[i], side="left")
        start2, end2 = np.searchsorted(ind2, blocks[i], side="left")
        block_size = np.int32(blocks[i, 1] - blocks[i, 0])
        partial_d = metrics[i](
            ind1[start1:end1],
            data1[start1:end1],
            ind2[start2:end2],
            data2[start2:end2],
            block_size,
        )
        d += weights[i] * partial_d

    return d


# used for the metrics argument in combined_metric_sparse()
# adds n_features param for a consistent type signature
def typed_metric_wrapper_sparse(f):
    @numba.njit
    def wrapper(ind1, data1, ind2, data2, n_features):
        return f(ind1, data1, ind2, data2)

    return typed_metric_wrapper_sparse_n_features(wrapper)


# used for the metrics argument in combined_metric_sparse()
def typed_metric_wrapper_sparse_n_features(f):
    return numba.jit("f4(i4[::1],f4[::1],i4[::1],f4[::1],i4)")(f.py_func)


def partial_metric_sparse(dist_fn, kwargs: dict):
    args = tuple(kwargs.values())

    @numba.njit("f4(i4[::1],f4[::1],i4[::1],f4[::1])")
    def d(ind1, data1, ind2, data2):
        return dist_fn(ind1, data1, ind2, data2, *args)

    return d


def partial_metric_sparse_n_features(dist_fn, kwargs: dict):
    args = tuple(kwargs.values())

    @numba.njit("f4(i4[::1],f4[::1],i4[::1],f4[::1],i4)")
    def d(ind1, data1, ind2, data2, n_features):
        return dist_fn(ind1, data1, ind2, data2, n_features, *args)

    return d
