# VoxAgent — coming soon
# https://voxagent.dev
__version__ = "0.0.1"