from .plugins.decorator import ObservabilityDecorator

STEP_DECORATORS = [ObservabilityDecorator]
