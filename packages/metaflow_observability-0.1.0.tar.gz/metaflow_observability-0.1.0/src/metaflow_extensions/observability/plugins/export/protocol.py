from typing import Protocol, runtime_checkable

Attributes = dict[str, str]


@runtime_checkable
class MetricsExporter(Protocol):
    """Sink for step observability metrics.

    All methods accept an ``attributes`` dict of string tags that backends
    should attach to every recorded data point (e.g. ``step_name``,
    ``flow_name``, ``run_id``).
    """

    def record_duration(self, name: str, seconds: float, attributes: Attributes) -> None: ...

    def record_gauge(self, name: str, value: float, attributes: Attributes) -> None: ...

    def record_counter(self, name: str, value: int, attributes: Attributes) -> None: ...
