# SnapAPI Python SDK

Official Python SDK for [SnapAPI](https://snapapi.tech) — capture any website as an image.

## Install

```bash
pip install snapapi-python
```

Or install from source:

```bash
pip install .
```

## Quick Start

```python
from snapapi import SnapAPI

snap = SnapAPI("snap_your_key_here")

# Basic screenshot — returns PNG bytes
image = snap.screenshot("example.com")
with open("screenshot.png", "wb") as f:
    f.write(image)
```

## Options

```python
# WebP format with dark mode and full-page capture
webp = snap.screenshot("example.com", format="webp", dark_mode=True, full_page=True)

# Mobile screenshot (iPhone 14)
mobile = snap.screenshot("example.com", device="iphone14")

# Custom viewport
image = snap.screenshot("example.com", width=1920, height=1080)

# Capture a specific element
header = snap.screenshot("example.com", selector="header")

# Add a delay before capture (milliseconds)
image = snap.screenshot("example.com", delay=2000)
```

## Metadata Mode

```python
meta = snap.screenshot("example.com", meta=True)
print(meta["title"], meta["description"])
print(meta["headings"])  # [{"level": 1, "text": "..."}, ...]
print(meta["links"])     # [{"text": "...", "href": "..."}, ...]
print(meta["text"])      # Extracted visible text (first 2000 chars)
```

## Account & Usage

```python
# Check usage
usage = snap.usage()
print(f"Used {usage['usage']} of {usage['limit']}")

# Account info
account = snap.account()

# Update settings
snap.update_settings(name="My App", allowed_domains=["example.com"])
```

## Scheduled Monitors

```python
# Create a monitor — captures every 15 minutes
monitor = snap.create_monitor(
    url="https://example.com",
    interval_minutes=15,
    name="Homepage",
    params={"format": "webp", "full_page": True},
    webhook_url="https://your-app.com/webhook",
)

# List all monitors
monitors = snap.list_monitors()

# Pause / resume
snap.update_monitor(monitor["id"], status="paused")
snap.update_monitor(monitor["id"], status="active")

# Browse snapshots
result = snap.list_snapshots(monitor["id"], limit=10)
for s in result["snapshots"]:
    print(s["taken_at"], s["file_size"])

# Download a snapshot
image = snap.get_snapshot(monitor["id"], result["snapshots"][0]["id"])
with open("snapshot.webp", "wb") as f:
    f.write(image)

# Delete a monitor (cascades to snapshots)
snap.delete_monitor(monitor["id"])
```

> Monitors require **Starter** tier or above. See [pricing](https://snapapi.tech/#pricing) for limits.

## Sign Up

```python
from snapapi import SnapAPI

result = SnapAPI.signup("you@example.com")
print(f"Your API key: {result['key']}")
```

## Error Handling

```python
from snapapi import SnapAPI, SnapAPIError

snap = SnapAPI("snap_your_key_here")

try:
    image = snap.screenshot("example.com")
except SnapAPIError as e:
    print(f"Status: {e.status}, Message: {e.message}")
```

## Requirements

- Python 3.7+
- `requests` >= 2.20.0

## License

MIT
