from setuptools import setup

setup(
    name="snapapi-python",
    version="1.3.0",
    description="Official Python SDK for SnapAPI — screenshot, metadata extraction, and HTML rendering",
    py_modules=["snapapi"],
    python_requires=">=3.7",
    install_requires=["requests>=2.20.0"],
    license="MIT",
    keywords=["screenshot", "api", "webpage-capture", "snapapi"],
)
