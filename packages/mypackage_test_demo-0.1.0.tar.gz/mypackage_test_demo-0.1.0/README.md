# MyPackage

一个示例 Python 包，用于演示打包和测试流程。

## 功能特性

- 基本的项目结构
- 单元测试配置
- 打包配置
- 开发工具集成

## 安装

### 从源码安装

```bash
pip install .
```

### 开发模式安装

```bash
pip install -e ".[dev]"
```

## 使用方法

```python
from mypackage import main_function
from mypackage.utils import format_string

# 使用主函数
message = main_function("World")
print(message)  # 输出：Hello, World!

# 使用工具函数
formatted = format_string("  Hello  ", uppercase=True)
print(formatted)  # 输出：HELLO
```

## 运行测试

```bash
# 运行所有测试
pytest

# 运行测试并生成覆盖率报告
pytest --cov=mypackage --cov-report=html
```

## 打包发布

```bash
# 构建分发包
python -m build

# 上传到 PyPI (需要配置 twine)
python -m twine upload dist/*
```

## 项目结构

```
package-test/
├── mypackage/          # 源代码
├── tests/              # 测试文件
├── docs/               # 文档
├── examples/           # 示例代码
└── 配置文件
```

## 许可证

MIT License
