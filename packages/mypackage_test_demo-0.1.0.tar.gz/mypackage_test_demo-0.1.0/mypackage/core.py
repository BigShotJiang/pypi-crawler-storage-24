"""
核心功能模块
"""

def main_function(name: str = "World") -> str:
    """
    主函数示例
    
    Args:
        name: 要问候的名称
        
    Returns:
        问候消息
    """
    return f"Hello, {name}!"


def calculate(a: int, b: int) -> int:
    """
    计算两个数的和
    
    Args:
        a: 第一个数
        b: 第二个数
        
    Returns:
        两数之和
    """
    return a + b
