"""
MyPackage - 一个示例 Python 包
"""

__version__ = '0.1.0'
__author__ = 'Your Name'

from .core import main_function

__all__ = ['main_function', '__version__']
