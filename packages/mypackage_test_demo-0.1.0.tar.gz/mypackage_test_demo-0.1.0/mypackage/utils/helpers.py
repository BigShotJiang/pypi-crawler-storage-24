"""
辅助工具函数
"""

def format_string(text: str, uppercase: bool = False) -> str:
    """
    格式化字符串
    
    Args:
        text: 要格式化的文本
        uppercase: 是否转换为大写
        
    Returns:
        格式化后的字符串
    """
    if uppercase:
        return text.upper()
    return text.strip()


def validate_input(value: any, expected_type: type) -> bool:
    """
    验证输入类型
    
    Args:
        value: 要验证的值
        expected_type: 期望的类型
        
    Returns:
        验证是否通过
    """
    return isinstance(value, expected_type)
