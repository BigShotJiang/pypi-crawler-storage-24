"""
核心模块的测试
"""

import pytest
from mypackage.core import main_function, calculate


class TestMainFunction:
    """测试主函数"""
    
    def test_default_greeting(self):
        """测试默认问候语"""
        result = main_function()
        assert result == "Hello, World!"
    
    def test_custom_name(self):
        """测试自定义名称"""
        result = main_function("Alice")
        assert result == "Hello, Alice!"
    
    def test_empty_name(self):
        """测试空名称"""
        result = main_function("")
        assert result == "Hello, !"


class TestCalculate:
    """测试计算函数"""
    
    def test_positive_numbers(self):
        """测试正数相加"""
        assert calculate(2, 3) == 5
    
    def test_negative_numbers(self):
        """测试负数相加"""
        assert calculate(-1, -1) == -2
    
    def test_mixed_numbers(self):
        """测试混合数字相加"""
        assert calculate(5, -3) == 2
