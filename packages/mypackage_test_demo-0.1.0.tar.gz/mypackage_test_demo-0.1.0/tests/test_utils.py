"""
工具模块的测试
"""

import pytest
from mypackage.utils import format_string, validate_input


class TestFormatString:
    """测试字符串格式化"""
    
    def test_strip_whitespace(self):
        """测试去除空白"""
        assert format_string("  hello  ") == "hello"
    
    def test_uppercase(self):
        """测试转换为大写"""
        assert format_string("hello", uppercase=True) == "HELLO"
    
    def test_empty_string(self):
        """测试空字符串"""
        assert format_string("") == ""


class TestValidateInput:
    """测试输入验证"""
    
    def test_valid_int(self):
        """测试有效的整数"""
        assert validate_input(42, int) is True
    
    def test_valid_str(self):
        """测试有效的字符串"""
        assert validate_input("text", str) is True
    
    def test_invalid_type(self):
        """测试无效类型"""
        assert validate_input("42", int) is False
