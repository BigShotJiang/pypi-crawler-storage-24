"""
使用示例
"""

from mypackage import main_function
from mypackage.utils import format_string


# 基本使用
message = main_function("Python Developer")
print(message)

# 使用工具函数
formatted = format_string("  Hello World  ", uppercase=True)
print(formatted)
