"""PreviewPane — right pane with two-mode display.

Mode 1 (file): syntax-highlighted text preview using Rich Syntax + Static.
Mode 2 (directory): file listing using DirectoryList (same widget as left panes).

ContentSwitcher toggles between the two modes without mounting/unmounting.
File reads happen in a @work(thread=True, exclusive=True) worker — exclusive=True
cancels in-flight loads when the cursor moves quickly (race-condition safe).

Race-condition guard: _preview_gen is incremented on every show_entry() call.
Workers capture the generation at start and discard results if the generation
has advanced (i.e. the user moved the cursor again before the worker finished).
This prevents a stale file-preview worker from overwriting a directory listing.

Message routing: MainScreen posts PreviewPane.CursorChanged(entry) to this widget.
The handler calls show_entry() which dispatches to the correct worker based on type.
This is identical to the Phase 1 interface — MainScreen.py requires no changes.
"""
from __future__ import annotations

from textual import work
from textual.app import ComposeResult
from textual.widget import Widget
from textual.widgets import ContentSwitcher, Static
from textual.worker import get_current_worker


# Truncation notice appended when file exceeds MAX_PREVIEW_BYTES
_TRUNCATION_NOTICE = "\n\n[dim]--- preview truncated at 512 KB ---[/dim]"


class PreviewPane(Widget):
    """Right pane: shows syntax-highlighted file preview or directory listing."""

    def __init__(self, *args, **kwargs) -> None:
        super().__init__(*args, **kwargs)
        self._preview_gen: int = 0

    def compose(self) -> ComposeResult:
        with ContentSwitcher(initial="preview-file"):
            yield Static("", id="preview-file", markup=True)

    def show_entry(self, entry: dict) -> None:
        """Dispatch preview update based on entry type. Called from CursorChanged handler."""
        self._preview_gen += 1
        entry_type = entry.get("type", "unknown")
        path = entry.get("name", "")
        if entry_type == "directory":
            self._show_dir_preview_sync(path)
        else:
            self._load_file_preview(path, self._preview_gen)

    def _show_dir_preview_sync(self, path: str) -> None:
        """Show directory listing in the Static preview widget."""
        from probefs.rendering.metadata import human_size, format_mtime
        fs = self.screen.core.fs  # type: ignore[attr-defined]
        show_hidden = self.screen.core.show_hidden  # type: ignore[attr-defined]
        try:
            entries = fs.ls(path, detail=True)
        except Exception as exc:
            self._show_file_content(f"[dim]Cannot read directory: {exc}[/dim]", is_markup=True)
            return

        from rich.text import Text
        from rich.console import Group

        lines = []
        dirs  = [e for e in entries if e.get("type") == "directory"]
        files = [e for e in entries if e.get("type") != "directory"]
        for entry in sorted(dirs, key=lambda e: (e.get("name") or "").lower()) + \
                     sorted(files, key=lambda e: (e.get("name") or "").lower()):
            name = entry.get("name", "")
            basename = name.split("/")[-1] if "/" in name else name
            if not show_hidden and basename.startswith("."):
                continue
            is_dir = entry.get("type") == "directory"
            size_str = "     -" if is_dir else f"{human_size(entry.get('size', 0)):>6}"
            color = "bold blue" if is_dir else "default"
            suffix = "/" if is_dir else ""
            line = Text()
            line.append(f"{size_str}  ", style="cyan")
            line.append(f"{basename}{suffix}", style=color)
            lines.append(line)

        if not lines:
            self._show_file_content("[dim](empty directory)[/dim]", is_markup=True)
            return

        switcher = self.query_one(ContentSwitcher)
        switcher.current = "preview-file"
        self.query_one("#preview-file", Static).update(Group(*lines))

    @work(thread=True, exclusive=True, group="preview_load", exit_on_error=False)
    def _load_file_preview(self, path: str, gen: int) -> None:
        """Worker: read file via ProbeFS.read_text(), build Rich Syntax, switch to file mode."""
        from rich.syntax import Syntax
        from probefs.fs.probe_fs import MAX_PREVIEW_BYTES

        worker = get_current_worker()

        # self.screen is the MainScreen this widget is mounted inside.
        # Reading .core.fs is safe from a thread — it's set in on_mount before
        # any worker can run, and is never reassigned after that.
        fs = self.screen.core.fs  # type: ignore[attr-defined]

        import pathlib

        suffix = pathlib.Path(path).suffix.lower()
        suffixes = [s.lower() for s in pathlib.Path(path).suffixes]

        # Archive preview — intercept before read_text() which rejects binary MIME types.
        # Covers .zip, .tar, .tgz, .tbz2, .txz, .tar.gz, .tar.bz2, .tar.xz
        _is_archive = (
            suffix in {".zip", ".tar", ".tgz", ".tbz2", ".txz"}
            or (len(suffixes) >= 2 and suffixes[-2] == ".tar" and suffix in {".gz", ".bz2", ".xz"})
        )
        if _is_archive:
            try:
                text = fs.read_archive_listing(path)
            except ValueError as exc:
                # Not a recognized archive — fall through to text preview below
                pass
            except OSError as exc:
                if worker.is_cancelled:
                    return
                msg = f"[dim]Cannot read archive: {exc}[/dim]"
                self.app.call_from_thread(
                    lambda m=msg: self._show_file_content(m, is_markup=True) if gen == self._preview_gen else None
                )
                return
            else:
                if worker.is_cancelled:
                    return
                syntax = Syntax(text, lexer="text", theme="ansi_dark", line_numbers=False)
                self.app.call_from_thread(
                    lambda s=syntax: self._show_syntax(s, False) if gen == self._preview_gen else None
                )
                return

        # PDF preview via pdftotext (poppler) — intercept before read_text()
        # which would reject PDFs as binary.
        if suffix == ".pdf":
            try:
                text = fs.read_pdf_text(path)
            except RuntimeError as exc:
                if worker.is_cancelled:
                    return
                msg = f"[dim]{exc}[/dim]"
                self.app.call_from_thread(
                    lambda m=msg: self._show_file_content(m, is_markup=False) if gen == self._preview_gen else None
                )
                return
            except OSError as exc:
                if worker.is_cancelled:
                    return
                msg = f"[dim]Cannot read PDF: {exc}[/dim]"
                self.app.call_from_thread(
                    lambda m=msg: self._show_file_content(m, is_markup=True) if gen == self._preview_gen else None
                )
                return
            if worker.is_cancelled:
                return
            from rich.syntax import Syntax
            syntax = Syntax(text, lexer="text", theme="ansi_dark", line_numbers=True)
            self.app.call_from_thread(
                lambda s=syntax: self._show_syntax(s, False) if gen == self._preview_gen else None
            )
            return

        truncated = False
        try:
            text = fs.read_text(path)
        except ValueError as exc:
            # Binary file detected — show informative message
            if worker.is_cancelled:
                return
            msg = f"[dim]{exc}[/dim]"
            self.app.call_from_thread(
                lambda m=msg: self._show_file_content(m, is_markup=True) if gen == self._preview_gen else None
            )
            return
        except (OSError, PermissionError) as exc:
            if worker.is_cancelled:
                return
            msg = f"[dim]Cannot read: {exc}[/dim]"
            self.app.call_from_thread(
                lambda m=msg: self._show_file_content(m, is_markup=True) if gen == self._preview_gen else None
            )
            return

        # Check if content was capped (file larger than max_bytes)
        import os
        try:
            file_size = os.path.getsize(path)
            if file_size > MAX_PREVIEW_BYTES:
                truncated = True
        except OSError:
            pass

        if worker.is_cancelled:
            return

        # Build Rich Syntax renderable
        # Use 'ansi_dark' theme — respects terminal color scheme (no hardcoded 24-bit colors)
        # Syntax auto-detects lexer from path extension via Pygments; falls back to 'default'
        import pathlib
        extension = pathlib.Path(path).suffix.lstrip(".")
        lexer = extension if extension else "text"
        try:
            syntax = Syntax(
                text,
                lexer=lexer,
                theme="ansi_dark",
                line_numbers=True,
                word_wrap=False,
                indent_guides=False,
            )
        except Exception:
            # Unknown lexer — fall back to plain text
            syntax = Syntax(text, lexer="text", theme="ansi_dark", line_numbers=True)

        if worker.is_cancelled:
            return

        t = truncated
        self.app.call_from_thread(
            lambda s=syntax, tr=t: self._show_syntax(s, tr) if gen == self._preview_gen else None
        )

    def _show_syntax(self, syntax: object, truncated: bool) -> None:
        """Main-thread: switch to file mode, update Static with Rich Syntax renderable."""
        switcher = self.query_one(ContentSwitcher)
        switcher.current = "preview-file"
        static = self.query_one("#preview-file", Static)
        static.update(syntax)
        if truncated:
            # Append truncation notice as a second update — appending text after a Syntax
            # renderable is not directly possible, so we compose a Group renderable.
            from rich.console import Group
            from rich.text import Text
            notice = Text("\n--- preview truncated at 512 KB ---", style="dim")
            static.update(Group(syntax, notice))

    def _show_file_content(self, markup_text: str, *, is_markup: bool = True) -> None:
        """Main-thread: switch to file mode, show plain markup text (error/binary messages)."""
        switcher = self.query_one(ContentSwitcher)
        switcher.current = "preview-file"
        self.query_one("#preview-file", Static).update(markup_text)


