"""Tests for pydistill.cli."""

import tomllib
from pathlib import Path

import pytest

import pydistill.cli as pydistill_cli
from pydistill.cli import create_parser, main, validate_config
from pydistill.config import PyDistillConfig


class TestCreateParser:
    def test_parser_creation(self):
        parser = create_parser()
        assert parser is not None

    def test_parse_entries(self):
        parser = create_parser()
        args = parser.parse_args(
            [
                "-e",
                "myapp.models:User",
                "-e",
                "myapp.models:Order",
                "-b",
                "myapp",
                "-p",
                "extracted",
                "-o",
                "./dist",
            ],
        )
        assert args.entries == ["myapp.models:User", "myapp.models:Order"]
        assert args.base_package == "myapp"
        assert args.output_package == "extracted"
        assert args.output_dir == Path("./dist")

    def test_parse_dry_run(self):
        parser = create_parser()
        args = parser.parse_args(
            [
                "-e",
                "myapp:User",
                "-b",
                "myapp",
                "-p",
                "out",
                "-o",
                "./dist",
                "--dry-run",
            ],
        )
        assert args.dry_run is True

    def test_parse_clean(self):
        parser = create_parser()
        args = parser.parse_args(
            [
                "-e",
                "myapp:User",
                "-b",
                "myapp",
                "-p",
                "out",
                "-o",
                "./dist",
                "--clean",
            ],
        )
        assert args.clean is True

    def test_parse_filesystem_only(self):
        parser = create_parser()
        args = parser.parse_args(
            [
                "-e",
                "myapp:User",
                "-b",
                "myapp",
                "-p",
                "out",
                "-o",
                "./dist",
                "--filesystem-only",
            ],
        )
        assert args.filesystem_only is True

    def test_parse_filesystem_only_short_flag(self):
        parser = create_parser()
        args = parser.parse_args(
            [
                "-e",
                "myapp:User",
                "-b",
                "myapp",
                "-p",
                "out",
                "-o",
                "./dist",
                "-f",
            ],
        )
        assert args.filesystem_only is True

    def test_parse_format(self):
        parser = create_parser()
        args = parser.parse_args(
            [
                "-e",
                "myapp:User",
                "-b",
                "myapp",
                "-p",
                "out",
                "-o",
                "./dist",
                "--format",
            ],
        )
        assert args.format is True

    def test_parse_formatter(self):
        parser = create_parser()
        args = parser.parse_args(
            [
                "-e",
                "myapp:User",
                "-b",
                "myapp",
                "-p",
                "out",
                "-o",
                "./dist",
                "--formatter",
                "black",
            ],
        )
        assert args.formatter == "black"

    def test_parse_formatter_with_options(self):
        parser = create_parser()
        args = parser.parse_args(
            [
                "-e",
                "myapp:User",
                "-b",
                "myapp",
                "-p",
                "out",
                "-o",
                "./dist",
                "--formatter",
                "ruff format --line-length 120",
            ],
        )
        assert args.formatter == "ruff format --line-length 120"

    def test_parse_version_strategy(self):
        parser = create_parser()
        args = parser.parse_args(
            [
                "-e",
                "myapp:User",
                "-b",
                "myapp",
                "-p",
                "out",
                "-o",
                "./dist",
                "--version-strategy",
                "manual",
            ],
        )
        assert args.version_strategy == "manual"

    def test_parse_version_strategy_auto_patch(self):
        parser = create_parser()
        args = parser.parse_args(
            [
                "-e",
                "myapp:User",
                "-b",
                "myapp",
                "-p",
                "out",
                "-o",
                "./dist",
                "--version-strategy",
                "auto-patch",
            ],
        )
        assert args.version_strategy == "auto-patch"

    def test_parse_dist_metadata(self):
        parser = create_parser()
        args = parser.parse_args(
            [
                "-e",
                "myapp:User",
                "-b",
                "myapp",
                "-p",
                "out",
                "-o",
                "./dist",
                "--dist-name",
                "my-exported-models",
                "--dist-version",
                "1.2.3",
            ],
        )
        assert args.dist_name == "my-exported-models"
        assert args.dist_version == "1.2.3"

    def test_parse_dependencies(self):
        parser = create_parser()
        args = parser.parse_args(
            [
                "-e",
                "myapp:User",
                "-b",
                "myapp",
                "-p",
                "out",
                "-o",
                "./dist",
                "--dependency",
                "pydantic>=2.0",
                "--dependency",
                "email-validator>=2.0",
            ],
        )
        assert args.dependencies == ["pydantic>=2.0", "email-validator>=2.0"]

    def test_version_uses_distribution_metadata(self, monkeypatch, capsys):
        captured_distribution_name: dict[str, str] = {}

        def fake_version(distribution_name: str) -> str:
            captured_distribution_name["value"] = distribution_name
            return "9.9.9"

        monkeypatch.setattr(
            pydistill_cli.importlib.metadata,
            "version",
            fake_version,
        )

        parser = create_parser()
        with pytest.raises(SystemExit) as exc_info:
            parser.parse_args(["--version"])

        assert exc_info.value.code == 0
        assert captured_distribution_name["value"] == "pydistill"
        version_output = capsys.readouterr().out
        assert version_output == "pydistill 9.9.9\n"

    def test_version_fails_fast_when_distribution_metadata_missing(self, monkeypatch):
        def raise_package_not_found(_: str) -> str:
            raise pydistill_cli.importlib.metadata.PackageNotFoundError()

        monkeypatch.setattr(
            pydistill_cli.importlib.metadata,
            "version",
            raise_package_not_found,
        )

        with pytest.raises(pydistill_cli.importlib.metadata.PackageNotFoundError):
            create_parser()


class TestValidateConfig:
    def test_valid_config(self):
        config = PyDistillConfig(
            entries=["myapp:User"],
            base_package="myapp",
            output_package="extracted",
            output_dir=Path("./dist"),
        )
        errors = validate_config(config)
        assert len(errors) == 0

    def test_missing_entries(self):
        config = PyDistillConfig(
            entries=[],
            base_package="myapp",
            output_package="extracted",
            output_dir=Path("./dist"),
        )
        errors = validate_config(config)
        assert any("entry points" in e.lower() for e in errors)

    def test_missing_base_package(self):
        config = PyDistillConfig(
            entries=["myapp:User"],
            base_package=None,
            output_package="extracted",
            output_dir=Path("./dist"),
        )
        errors = validate_config(config)
        assert any("base package" in e.lower() for e in errors)

    def test_invalid_output_package(self):
        config = PyDistillConfig(
            entries=["myapp:User"],
            base_package="myapp",
            output_package="invalid-package",
            output_dir=Path("./dist"),
        )
        errors = validate_config(config)
        assert any("valid python identifier" in e.lower() for e in errors)

    def test_empty_dist_name(self):
        config = PyDistillConfig(
            entries=["myapp:User"],
            base_package="myapp",
            output_package="extracted",
            output_dir=Path("./dist"),
            dist_name="   ",
        )
        errors = validate_config(config)
        assert any("distribution name cannot be empty" in e.lower() for e in errors)

    def test_empty_dist_version(self):
        config = PyDistillConfig(
            entries=["myapp:User"],
            base_package="myapp",
            output_package="extracted",
            output_dir=Path("./dist"),
            dist_version="",
        )
        errors = validate_config(config)
        assert any("distribution version cannot be empty" in e.lower() for e in errors)

    def test_empty_dependency_specifier(self):
        config = PyDistillConfig(
            entries=["myapp:User"],
            base_package="myapp",
            output_package="extracted",
            output_dir=Path("./dist"),
            dependencies=["pydantic>=2", " "],
        )
        errors = validate_config(config)
        assert any("dependency specifiers cannot be empty" in e.lower() for e in errors)


class TestMain:
    def test_main_with_valid_args(
        self,
        test_project_path: Path,
        output_dir: Path,
        add_test_project_to_path,
    ):
        result = main(
            [
                "-e",
                "project_a.appointments.models:Appointment",
                "-b",
                "project_a",
                "-p",
                "extracted",
                "-o",
                str(output_dir),
                "-s",
                str(test_project_path),
                "--quiet",
            ],
        )
        assert result == 0
        assert output_dir.exists()

    def test_main_dry_run(
        self,
        test_project_path: Path,
        output_dir: Path,
        add_test_project_to_path,
    ):
        result = main(
            [
                "-e",
                "project_a.appointments.models:Appointment",
                "-b",
                "project_a",
                "-p",
                "extracted",
                "-o",
                str(output_dir),
                "-s",
                str(test_project_path),
                "--dry-run",
                "--quiet",
            ],
        )
        assert result == 0
        assert not output_dir.exists()

    def test_main_missing_required_args(self):
        result = main([])
        assert result == 1

    def test_main_invalid_entry_point(self, tmp_path: Path):
        result = main(
            [
                "-e",
                "invalid_format_no_colon",
                "-b",
                "myapp",
                "-p",
                "extracted",
                "-o",
                str(tmp_path / "out"),
            ],
        )
        assert result == 1

    def test_main_filesystem_only(self, test_project_path: Path, output_dir: Path):
        """Test extraction using --filesystem-only without adding to sys.path."""
        # Note: we intentionally do NOT use add_test_project_to_path fixture
        # to verify that --filesystem-only works without importlib
        result = main(
            [
                "-e",
                "project_a.appointments.models:Appointment",
                "-b",
                "project_a",
                "-p",
                "extracted",
                "-o",
                str(output_dir),
                "-s",
                str(test_project_path),
                "--filesystem-only",
                "--quiet",
            ],
        )
        assert result == 0
        assert output_dir.exists()
        assert (output_dir / "extracted" / "appointments" / "models.py").exists()
        assert (output_dir / "extracted" / "common" / "types.py").exists()
        assert (output_dir / "extracted" / "vehicles" / "models.py").exists()

    def test_main_with_distribution_options(
        self,
        test_project_path: Path,
        output_dir: Path,
    ):
        result = main(
            [
                "-e",
                "project_a.appointments.models:Appointment",
                "-b",
                "project_a",
                "-p",
                "extracted",
                "-o",
                str(output_dir),
                "-s",
                str(test_project_path),
                "--filesystem-only",
                "--dist-name",
                "project-a-extract",
                "--dist-version",
                "2.1.0",
                "--dependency",
                "pydantic>=2.0",
                "--quiet",
            ],
        )

        assert result == 0
        pyproject = output_dir / "pyproject.toml"
        assert pyproject.exists()
        data = tomllib.loads(pyproject.read_text(encoding="utf-8"))
        assert data["project"]["name"] == "project-a-extract"
        assert data["project"]["version"] == "2.1.0"

    def test_main_default_version_is_1_0_0(
        self,
        test_project_path: Path,
        output_dir: Path,
    ):
        result = main(
            [
                "-e",
                "project_a.appointments.models:Appointment",
                "-b",
                "project_a",
                "-p",
                "extracted",
                "-o",
                str(output_dir),
                "-s",
                str(test_project_path),
                "--filesystem-only",
                "--quiet",
            ],
        )
        assert result == 0
        data = tomllib.loads(
            (output_dir / "pyproject.toml").read_text(encoding="utf-8")
        )
        assert data["project"]["version"] == "1.0.0"
