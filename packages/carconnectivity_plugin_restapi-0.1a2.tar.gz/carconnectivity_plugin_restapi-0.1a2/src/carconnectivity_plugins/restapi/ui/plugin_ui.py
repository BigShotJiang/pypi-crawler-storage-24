""" User interface for the REST API plugin in the Car Connectivity application. """
from __future__ import annotations
from typing import TYPE_CHECKING

import flask

from carconnectivity_plugins.base.plugin import BasePlugin
from carconnectivity_plugins.base.ui.plugin_ui import BasePluginUI

if TYPE_CHECKING:
    from typing import Optional, List, Dict, Union, Literal


class PluginUI(BasePluginUI):
    """
    A user interface class for the REST API plugin in the Car Connectivity application.
    """
    def __init__(self, plugin: BasePlugin, app: flask.Flask, *args, **kwargs):
        blueprint: Optional[flask.Blueprint] = flask.Blueprint(name=plugin.id, import_name='carconnectivity-plugin-restapi', url_prefix=f'/{plugin.id}')
        super().__init__(plugin, blueprint=blueprint, app=app, *args, **kwargs)

    def get_nav_items(self) -> List[Dict[Literal['text', 'url', 'sublinks', 'divider'], Union[str, List]]]:  # pylint: disable=useless-parent-delegation
        """
        Generates a list of navigation items for the REST API plugin UI.
        """
        return super().get_nav_items()

    def get_title(self) -> str:
        """
        Returns the title of the plugin.

        Returns:
            str: The title of the plugin, which is "REST API".
        """
        return "REST API"
