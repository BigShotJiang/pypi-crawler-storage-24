"""CarConnectivity REST API plugin."""
