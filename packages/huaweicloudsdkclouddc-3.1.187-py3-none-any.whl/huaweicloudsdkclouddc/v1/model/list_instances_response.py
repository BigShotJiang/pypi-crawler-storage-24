# coding: utf-8

from huaweicloudsdkcore.sdk_response import SdkResponse
from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class ListInstancesResponse(SdkResponse):

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'instances': 'list[QueryInstanceResponseBody]',
        'page_info': 'PageInfo',
        'count': 'int'
    }

    attribute_map = {
        'instances': 'instances',
        'page_info': 'page_info',
        'count': 'count'
    }

    def __init__(self, instances=None, page_info=None, count=None):
        r"""ListInstancesResponse

        The model defined in huaweicloud sdk

        :param instances: 实例列表
        :type instances: list[:class:`huaweicloudsdkclouddc.v1.QueryInstanceResponseBody`]
        :param page_info: 
        :type page_info: :class:`huaweicloudsdkclouddc.v1.PageInfo`
        :param count: 实例总数
        :type count: int
        """
        
        super().__init__()

        self._instances = None
        self._page_info = None
        self._count = None
        self.discriminator = None

        if instances is not None:
            self.instances = instances
        if page_info is not None:
            self.page_info = page_info
        if count is not None:
            self.count = count

    @property
    def instances(self):
        r"""Gets the instances of this ListInstancesResponse.

        实例列表

        :return: The instances of this ListInstancesResponse.
        :rtype: list[:class:`huaweicloudsdkclouddc.v1.QueryInstanceResponseBody`]
        """
        return self._instances

    @instances.setter
    def instances(self, instances):
        r"""Sets the instances of this ListInstancesResponse.

        实例列表

        :param instances: The instances of this ListInstancesResponse.
        :type instances: list[:class:`huaweicloudsdkclouddc.v1.QueryInstanceResponseBody`]
        """
        self._instances = instances

    @property
    def page_info(self):
        r"""Gets the page_info of this ListInstancesResponse.

        :return: The page_info of this ListInstancesResponse.
        :rtype: :class:`huaweicloudsdkclouddc.v1.PageInfo`
        """
        return self._page_info

    @page_info.setter
    def page_info(self, page_info):
        r"""Sets the page_info of this ListInstancesResponse.

        :param page_info: The page_info of this ListInstancesResponse.
        :type page_info: :class:`huaweicloudsdkclouddc.v1.PageInfo`
        """
        self._page_info = page_info

    @property
    def count(self):
        r"""Gets the count of this ListInstancesResponse.

        实例总数

        :return: The count of this ListInstancesResponse.
        :rtype: int
        """
        return self._count

    @count.setter
    def count(self, count):
        r"""Sets the count of this ListInstancesResponse.

        实例总数

        :param count: The count of this ListInstancesResponse.
        :type count: int
        """
        self._count = count

    def to_dict(self):
        import warnings
        warnings.warn("ListInstancesResponse.to_dict() is deprecated and no longer maintained, "
                      "use to_json_object() to get the response content.", DeprecationWarning)
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, ListInstancesResponse):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
