#include "daqp_prox.h"
#include "utils.h"

static int gradient_step(DAQPWorkspace* work);

int daqp_prox(DAQPWorkspace *work){
    int i,total_iter=0;
    const int nx=work->n;
    int exitflag;
    c_float *swp_ptr;
    c_float diff,eps=work->settings->eps_prox;
    c_float tol_stat, eta=work->settings->eta_prox;
    int cycle_counter = 0;
    c_float best_fval = DAQP_INF;

    while(total_iter  <  work->settings->iter_limit){
        // ** Perturb problem **
        // Compute v = R'\(f-eps*x) (FWS Skipped if LP since R = I)
        if(work->Rinv== NULL && work->RinvD == NULL){
            eps*= (work->iterations==1) ? 10 : 0.9; // Adapt epsilon TODO: add to settings
            eps = (eps > 1e3) ? 1e3 : eps; // TODO: add saturation option to settings
            for(i = 0; i<nx;i++)
                work->v[i] = work->qp->f[i]*eps-work->x[i];
        }
        else{
            for(i = 0; i<nx;i++)
                work->v[i] = work->qp->f[i]-eps*work->x[i];
            daqp_update_v(work->v,work,0);
        }
        // Perturb RHS of constraints
        daqp_update_d(work, work->qp->bupper,work->qp->blower);

        // xold <-- x
        swp_ptr = work->xold; work->xold = work->x; work->x = swp_ptr;

        // ** Solve least-distance problem **
        work->u = work->x;
        exitflag = daqp_ldp(work);

        total_iter += work->iterations;
        if(exitflag<0) 
            return exitflag; // Could not solve LDP -> return
        else 
            ldp2qp_solution(work); // Get qp solution 

        if(eps==0) break; // No regularization -> no outer iterations

        // ** Check convergence **
        if(work->iterations==1){ // No changes to the working set 
            tol_stat = (work->Rinv == NULL && work->RinvD == NULL) ? eta*eps : eta/eps;
            for(i=0, diff= 0;i<nx;i++){ // ||x_old - x|| > eta  ?
                diff= work->x[i] - work->xold[i];
                if((diff> tol_stat) || (diff< -tol_stat)) break;
            }
            if(i==nx){
                exitflag = DAQP_EXIT_OPTIMAL; // Fix point reached
                break;
            }
            // Take gradient step if LP (and the iterate is not constrained to a vertex)
            if((work->Rinv == NULL && work->RinvD ==NULL )&&(work->n_active != work->n)){
                if(gradient_step(work)==DAQP_EMPTY_IND){
                    exitflag= DAQP_EXIT_UNBOUNDED;
                    break;
                }
            }
        }
        // For LPs, compute objective function value to detect progress
        // TODO: add paramters to settings
        if(work->Rinv == NULL && work->RinvD == NULL){
            for(i=0, diff=best_fval;i<nx;i++)
                diff-=work->qp->f[i]*work->x[i];
            if(diff<1e-10){
                if(cycle_counter++ > 10) return DAQP_EXIT_OPTIMAL; // assume fix point
            }
            else{ // Progress -> update objective function value
                best_fval -=diff ;
                cycle_counter=0;
            }
        }

    }
    // Finalize results
    if(total_iter >= work->settings->iter_limit) exitflag = DAQP_EXIT_ITERLIMIT; 
    if(work->Rinv == NULL && work->RinvD == NULL){
        for(i = 0; i<work->n_active;i++) 
            work->lam_star[i]/=eps;// Rescale dual variables
    }
    work->iterations = total_iter;
    return exitflag;
}
// Gradient step
// TODO: could probably reuse code from daqp
static int gradient_step(DAQPWorkspace* work){
    int j,k,disp,add_ind=DAQP_EMPTY_IND;
    const int nx=work->n;
    const int m=work->m;
    const int ms=work->ms;
    c_float Ax,delta_s, min_alpha=DAQP_INF;
    // Find constraint j to add: j =  argmin_j s_j
    // Simple bounds
    for(j=0, disp=0;j<ms;j++){
        if(work->sense[j]&(DAQP_ACTIVE+DAQP_IMMUTABLE)) continue;
        delta_s = work->x[j]-work->xold[j];
        if(delta_s>0 && //Feasible descent direction
                work->qp->bupper[j]<DAQP_INF && // Not single-sided
                work->qp->bupper[j]-work->x[j]<min_alpha*delta_s){
            add_ind = j;
            min_alpha = (work->qp->bupper[j]-work->x[j])/delta_s;
        }
        else if(delta_s < 0 && //Feasible descent direction
                work->qp->blower[j]>-DAQP_INF && // Not single-sided
                work->qp->blower[j]-work->x[j]>min_alpha*delta_s){
            add_ind = j;
            min_alpha = (work->qp->blower[j]-work->x[j])/delta_s;
        }
    }
    //General bounds
    for(j=ms, disp=0;j<m;j++){
        if(work->sense[j]&(DAQP_ACTIVE+DAQP_IMMUTABLE)){
            disp+=nx;// Skip ahead in A
            continue;
        }
        //delta_s[j] = A[j,:]*delta_x
        for(k=0,delta_s=0,Ax=0;k<nx;k++){ // compute s = A(x-xold) and Ax
            Ax += work->M[disp]*work->x[k];
            delta_s-=work->M[disp++]*work->xold[k];
        }
        delta_s +=Ax;

        if(work->scaling != NULL){
            Ax /= work->scaling[j];
            delta_s /= work->scaling[j];
        }
        if(delta_s>0 && // Feasible descent direction
                work->qp->bupper[j]<DAQP_INF && // Not single-sided
                work->qp->bupper[j]-Ax < delta_s*min_alpha){
            add_ind = j;
            min_alpha=(work->qp->bupper[j]-Ax)/delta_s;
        }
        else if(delta_s<0 && // Feasible descent direction
                work->qp->blower[j]>-DAQP_INF && // Not single-sided
                work->qp->blower[j]-Ax > delta_s*min_alpha){
            add_ind = j;
            min_alpha=(work->qp->blower[j]-Ax)/delta_s;
        }
    }
    // update iterate
    if(add_ind != DAQP_EMPTY_IND)
        for(k=0;k<nx;k++) // x <-- x+alpha deltax
            work->x[k]+=min_alpha*(work->x[k]-work->xold[k]);

    return add_ind;
}
