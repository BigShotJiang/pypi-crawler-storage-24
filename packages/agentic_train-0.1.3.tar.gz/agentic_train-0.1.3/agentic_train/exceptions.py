class MissingContextError(RuntimeError):
    pass


class InvalidRunnerClassError(TypeError):
    pass
