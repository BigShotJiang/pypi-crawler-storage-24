import logging
import re
from datetime import datetime
from typing import Any, Dict

from datasets import Dataset  # type: ignore[import-untyped]
from sentence_transformers import (
    SentenceTransformer,
    SentenceTransformerTrainer,
    models,
)
from sentence_transformers.evaluation import InformationRetrievalEvaluator
from sentence_transformers.trainer import SentenceTransformerTrainer
from sentence_transformers.training_args import SentenceTransformerTrainingArguments
from sentence_transformers.util import mine_hard_negatives

from agentic_train.constants import RANDOM_SEED
from agentic_train.settings import SentenceTransformersTrainerSettings
from agentic_train.train.dataset import TorchDataset
from agentic_train.train.trainers import Trainer
from agentic_train.utils import load_class

_logger = logging.getLogger(__name__)


class SentenceTransformersTrainer(Trainer[SentenceTransformersTrainerSettings]):
    def __init__(self, config: SentenceTransformersTrainerSettings) -> None:
        super().__init__(config)

    def _run_name(self) -> str:
        def _clean(s: str) -> str:
            # filesystem-safe, readable
            s = s.lower()
            s = re.sub(r"[^a-z0-9._-]+", "-", s)
            return s.strip("-")

        model_name = _clean(self.config.model_name_or_path.split("/")[-1])
        bs = self.config.batch_size
        epochs = self.config.num_epochs
        parts = [model_name, f"bs{bs}", f"ep{epochs}"]
        if self.config.hard_negatives:
            hn = self.config.hard_negatives
            parts.append(f"-k{hn.num_negatives}" f"-m{hn.relative_margin}")
        # Optional but useful: timestamp to avoid collisions
        timestamp = datetime.now().strftime("%Y%m%d-%H%M%S")
        return "__".join(parts) + f"__{timestamp}"

    def train(self) -> None:
        st_model = self._load_sentence_transformer()
        hf_ds = self._load_hf_dataset()
        if self.config.hard_negatives:
            hn = self.config.hard_negatives
            _logger.info(
                f"Mining hard negatives | range=[{hn.range_min},{hn.range_max}] max_score={hn.max_score} margin={hn.relative_margin} num_neg={hn.num_negatives}",
            )
            hf_ds = mine_hard_negatives(
                dataset=hf_ds,
                model=st_model,
                range_min=hn.range_min,
                range_max=hn.range_max,
                max_score=hn.max_score,
                relative_margin=hn.relative_margin,
                num_negatives=hn.num_negatives,
                sampling_strategy=hn.sampling_strategy,
                batch_size=hn.batch_size,
                use_faiss=hn.use_faiss,
            )
        splits = hf_ds.train_test_split(
            test_size=1.0 - self.config.train_frac,
            seed=RANDOM_SEED,
            shuffle=True,
        )
        train_dataset = splits["train"]
        val_dataset = splits["test"]
        loss = load_class(self.config.loss.module_path)(model=st_model, **self.config.loss.kwargs)
        val_evaluator = self._hf_dataset_to_ir_evaluator(val_dataset, name="val")
        args = SentenceTransformerTrainingArguments(
            output_dir=str(self.config.checkpoint_dir / self._run_name()),
            per_device_train_batch_size=self.config.batch_size,
            num_train_epochs=self.config.num_epochs,
            learning_rate=self.config.lr,
            warmup_ratio=self.config.warmup_ratio,
            eval_strategy="steps",
            eval_steps=self.config.eval_steps,
            save_steps=self.config.save_steps,
            logging_steps=self.config.logging_steps,
            fp16=self.config.fp16,
        )
        trainer = SentenceTransformerTrainer(
            model=st_model,
            train_dataset=train_dataset,
            eval_dataset=val_dataset,
            loss=loss,
            args=args,
            evaluator=val_evaluator,
        )
        _logger.info("Starting SentenceTransformers training...")
        trainer.train()

    def _load_sentence_transformer(self) -> SentenceTransformer:
        if self.config.resume_from:
            _logger.info(f"Loading SentenceTransformer from checkpoint: {self.config.resume_from}")
            return SentenceTransformer(self.config.resume_from, trust_remote_code=self.config.trust_remote_code)
        transformer = models.Transformer(
            self.config.model_name_or_path,
            max_seq_length=self.config.tokenizer.max_length,
            tokenizer_name_or_path=self.config.tokenizer.name,
            model_args={"trust_remote_code": self.config.trust_remote_code},
            config_args={"trust_remote_code": self.config.trust_remote_code},
            tokenizer_args={"trust_remote_code": self.config.trust_remote_code},
        )
        pooling = models.Pooling(
            transformer.get_word_embedding_dimension(),
            pooling_mode_mean_tokens=self.config.pooling == "mean_tokens",
            pooling_mode_cls_token=self.config.pooling == "cls",
            pooling_mode_max_tokens=self.config.pooling == "max_tokens",
        )
        return SentenceTransformer(modules=[transformer, pooling])

    def _load_hf_dataset(self) -> Dataset:
        torch_dataset: TorchDataset[Any, Any] = load_class(self.config.torch_dataset.module_path).from_config(
            self.config.torch_dataset
        )
        return torch_dataset.to_hf_dataset()

    def _hf_dataset_to_ir_evaluator(self, ds: Dataset, name: str) -> InformationRetrievalEvaluator:
        queries: Dict[str, str] = {}
        corpus: Dict[str, str] = {}
        relevant_docs: Dict[str, set[str]] = {}
        for i, row in enumerate(ds):
            qid = f"q{i}"
            did = f"d{i}"
            queries[qid] = row["query"]
            corpus[did] = row["positive"]
            relevant_docs[qid] = {did}
        return InformationRetrievalEvaluator(
            queries=queries,
            corpus=corpus,
            relevant_docs=relevant_docs,
            name=name,
            precision_recall_at_k=self.config.evaluation.precision_recall_at_k,
            mrr_at_k=self.config.evaluation.mrr_at_k,
            ndcg_at_k=self.config.evaluation.ndcg_at_k,
            batch_size=self.config.evaluation.batch_size,
        )
