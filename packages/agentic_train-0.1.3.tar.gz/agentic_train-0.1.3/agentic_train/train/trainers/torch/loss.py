from abc import ABC, abstractmethod
from typing import Generic, Tuple

import torch
import torch.nn.functional as F
from agentic_base.mixins import FromConfigMixin
from agentic_train.settings import (
    InBatchNegativeContrastiveLossSettings,
    MultiPositiveContrastiveLossSettings,
)
from agentic_train.types import TCLoss


class Loss(FromConfigMixin[TCLoss], ABC, Generic[TCLoss]):  # type: ignore[type-var]
    """
    Base interface for contrastive losses.
    """

    def __init__(self, config: TCLoss) -> None:
        self.config = config

    @abstractmethod
    def _get_loss(
        self,
        q_emb: torch.Tensor,
        c_emb: torch.Tensor,
    ) -> torch.Tensor:
        raise NotImplementedError

    def normalize(
        self,
        q_emb: torch.Tensor,
        c_emb: torch.Tensor,
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        q_emb = F.normalize(q_emb, dim=-1)
        c_emb = F.normalize(c_emb, dim=-1)
        return q_emb, c_emb

    def __call__(
        self,
        q_emb: torch.Tensor,
        c_emb: torch.Tensor,
    ) -> torch.Tensor:
        q_emb, c_emb = self.normalize(q_emb, c_emb)
        q_norms = q_emb.norm(dim=-1)
        c_norms = c_emb.norm(dim=-1)
        assert torch.allclose(
            q_norms,
            torch.ones_like(q_norms),
            atol=1e-6,
        ), f"q_emb not normalized: min={q_norms.min()}, max={q_norms.max()}"
        assert torch.allclose(
            c_norms,
            torch.ones_like(c_norms),
            atol=1e-6,
        ), f"c_emb not normalized: min={c_norms.min()}, max={c_norms.max()}"
        return self._get_loss(q_emb, c_emb)


class MultiPositiveContrastiveLoss(Loss[MultiPositiveContrastiveLossSettings]):
    def __init__(self, config: MultiPositiveContrastiveLossSettings) -> None:
        super().__init__(config)

    def _get_loss(
        self,
        q_emb: torch.Tensor,  # (B, D)
        c_emb: torch.Tensor,  # (B * K, D)
    ) -> torch.Tensor:
        B = q_emb.size(0)
        K = c_emb.size(0) // q_emb.size(0)
        c_emb = c_emb.view(B, K, -1)
        assert c_emb.size(-1) == q_emb.size(-1)
        logits = torch.einsum("bd,bkd->bk", q_emb, c_emb)
        logits = logits / self.config.temperature
        log_probs = torch.log_softmax(logits, dim=-1)
        pos_mask = torch.zeros_like(log_probs)
        pos_mask[:, : self.config.n_pos] = 1.0
        loss = -(log_probs * pos_mask).sum(dim=1) / self.config.n_pos
        return loss.mean()


class InBatchNegativeContrastiveLoss(Loss[InBatchNegativeContrastiveLossSettings]):
    def __init__(self, config: InBatchNegativeContrastiveLossSettings) -> None:
        super().__init__(config)

    def _get_loss(
        self,
        q_emb: torch.Tensor,  # (B, D)
        c_emb: torch.Tensor,  # (B, D)
    ) -> torch.Tensor:
        logits = (q_emb @ c_emb.T) / self.config.temperature  # (B, B)
        labels = torch.arange(
            logits.size(0),
            device=logits.device,
        )
        return F.cross_entropy(logits, labels)
