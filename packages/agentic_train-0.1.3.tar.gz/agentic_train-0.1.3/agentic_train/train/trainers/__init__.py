import logging
from abc import ABC, abstractmethod
from typing import Generic

from agentic_base.mixins import FromConfigMixin
from agentic_train.types import TCTrainer

_logger = logging.getLogger(__name__)


class Trainer(FromConfigMixin[TCTrainer], ABC, Generic[TCTrainer]):  # type: ignore[type-var]

    def __init__(self, config: TCTrainer):
        super().__init__(config)

    @abstractmethod
    def _run_name(self) -> str:
        raise NotImplementedError()

    @abstractmethod
    def train(self) -> None:
        raise NotImplementedError()
