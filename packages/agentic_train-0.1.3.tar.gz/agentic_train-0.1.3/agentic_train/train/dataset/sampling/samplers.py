from typing import Any, Dict, List, Optional, Tuple

from agentic_train.settings import PositiveSamplerSettings
from agentic_train.train.dataset.sampling import Sampler
from agentic_train.utils import load_class


class PositiveSampler(Sampler[PositiveSamplerSettings, Dict[str, Any]]):
    def __init__(self, config: PositiveSamplerSettings, context: Optional[Dict[str, Any]]) -> None:
        super().__init__(config, context)
        self.distance = load_class(self.config.distance.module_path).from_config(self.config.distance)

    def sample(self, item: Dict[str, Any], **kwargs: Any) -> List[str]:
        texts: List[str] = item["page_content"]
        metas: List[Dict[str, Any]] = item["metadata"]
        anchor_meta = metas[kwargs["anchor_idx"]]
        anchor_range: Tuple[int, int] = anchor_meta["step_range"]
        anchor_section = anchor_meta["section"]
        candidates = [
            i
            for i, m in enumerate(metas)
            if (
                m["section"] == anchor_section
                and self.distance(anchor_range, m["step_range"]) <= self.config.max_step_distance
            )
        ]
        candidates = list(set(candidates))
        candidates = list(dict.fromkeys(candidates))
        while len(candidates) < self.config.k:
            candidates.append(kwargs["anchor_idx"])
        positives = self.rng.sample(
            candidates,
            k=self.config.k,
        )
        assert len(positives) == self.config.k
        return [texts[i] for i in positives]
