"""Unit tests for MemoryStore."""

from clavestra_mpp.store import MemoryStore


async def test_put_and_get():
    store = MemoryStore()
    await store.put("key1", "value1")
    result = await store.get("key1")
    assert result == "value1"


async def test_get_missing_key_returns_none():
    store = MemoryStore()
    result = await store.get("nonexistent")
    assert result is None


async def test_delete_existing_key():
    store = MemoryStore()
    await store.put("key1", "value1")
    await store.delete("key1")
    result = await store.get("key1")
    assert result is None


async def test_delete_missing_key_is_idempotent():
    store = MemoryStore()
    await store.delete("nonexistent")  # Should not raise
