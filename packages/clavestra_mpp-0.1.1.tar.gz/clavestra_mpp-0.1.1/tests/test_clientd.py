"""Unit tests for FedimintClientd against httpx mock."""

import httpx
import pytest
from pytest_httpx import HTTPXMock

from clavestra_mpp.clientd import FedimintClientd
from clavestra_mpp.errors import (
    AlreadySpentError,
    FederationMismatchError,
    InvalidNotesError,
    NetworkError,
)

CLIENTD_URL = "http://localhost:5000"


async def test_spend(httpx_mock: HTTPXMock):
    httpx_mock.add_response(
        url=f"{CLIENTD_URL}/fedimint/v2/mint/spend",
        method="POST",
        json={"notes": "mock-notes-5000-op1", "operation_id": "op1"},
    )
    clientd = FedimintClientd(base_url=CLIENTD_URL)
    result = await clientd.spend(5000)
    assert result["notes"] == "mock-notes-5000-op1"
    assert result["operation_id"] == "op1"


async def test_reissue(httpx_mock: HTTPXMock):
    httpx_mock.add_response(
        url=f"{CLIENTD_URL}/fedimint/v2/mint/reissue",
        method="POST",
        json={"amount_msat": 5000, "operation_id": "op2"},
    )
    clientd = FedimintClientd(base_url=CLIENTD_URL)
    result = await clientd.reissue("mock-notes-5000-op1")
    assert result["amount_msat"] == 5000
    assert result["operation_id"] == "op2"


async def test_validate(httpx_mock: HTTPXMock):
    httpx_mock.add_response(
        url=f"{CLIENTD_URL}/fedimint/v2/mint/validate",
        method="POST",
        json={"amount_msat": 5000},
    )
    clientd = FedimintClientd(base_url=CLIENTD_URL)
    result = await clientd.validate("mock-notes-5000-op1")
    assert result["amount_msat"] == 5000


async def test_info(httpx_mock: HTTPXMock):
    httpx_mock.add_response(
        url=f"{CLIENTD_URL}/fedimint/v2/admin/info",
        method="GET",
        json={"federation_id": "fed1test", "total_amount_msat": 100000},
    )
    clientd = FedimintClientd(base_url=CLIENTD_URL)
    result = await clientd.info()
    assert result["federation_id"] == "fed1test"
    assert result["total_amount_msat"] == 100000


async def test_join_federation(httpx_mock: HTTPXMock):
    httpx_mock.add_response(
        url=f"{CLIENTD_URL}/fedimint/v2/admin/join",
        method="POST",
        status_code=200,
    )
    clientd = FedimintClientd(base_url=CLIENTD_URL)
    await clientd.join_federation("fed1invite...")  # Should not raise


async def test_already_spent_error(httpx_mock: HTTPXMock):
    httpx_mock.add_response(
        url=f"{CLIENTD_URL}/fedimint/v2/mint/reissue",
        method="POST",
        status_code=400,
        text="Notes have already been spent",
    )
    clientd = FedimintClientd(base_url=CLIENTD_URL)
    with pytest.raises(AlreadySpentError):
        await clientd.reissue("spent-notes")


async def test_federation_mismatch_error(httpx_mock: HTTPXMock):
    httpx_mock.add_response(
        url=f"{CLIENTD_URL}/fedimint/v2/mint/reissue",
        method="POST",
        status_code=400,
        text="Wrong federation for these notes",
    )
    clientd = FedimintClientd(base_url=CLIENTD_URL)
    with pytest.raises(FederationMismatchError):
        await clientd.reissue("wrong-fed-notes")


async def test_invalid_notes_error(httpx_mock: HTTPXMock):
    httpx_mock.add_response(
        url=f"{CLIENTD_URL}/fedimint/v2/mint/reissue",
        method="POST",
        status_code=400,
        text="Malformed note data",
    )
    clientd = FedimintClientd(base_url=CLIENTD_URL)
    with pytest.raises(InvalidNotesError):
        await clientd.reissue("bad-notes")


async def test_network_error(httpx_mock: HTTPXMock):
    httpx_mock.add_exception(
        httpx.ConnectError("Connection refused"),
        url=f"{CLIENTD_URL}/fedimint/v2/mint/spend",
    )
    clientd = FedimintClientd(base_url=CLIENTD_URL)
    with pytest.raises(NetworkError):
        await clientd.spend(5000)


async def test_password_sets_auth_header(httpx_mock: HTTPXMock):
    httpx_mock.add_response(
        url=f"{CLIENTD_URL}/fedimint/v2/admin/info",
        method="GET",
        json={"federation_id": "fed1test", "total_amount_msat": 0},
    )
    clientd = FedimintClientd(base_url=CLIENTD_URL, password="secret123")
    await clientd.info()
    request = httpx_mock.get_requests()[0]
    assert request.headers["authorization"] == "Bearer secret123"
