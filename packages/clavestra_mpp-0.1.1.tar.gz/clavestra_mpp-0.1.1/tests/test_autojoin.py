"""Unit tests for auto-join federation feature (EXTRA-01).

Tests that FedimintMethod lazily joins a federation on first create_credential
when invite_code is provided.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any
from unittest.mock import AsyncMock

import pytest

from clavestra_mpp.method import FedimintMethod
from clavestra_mpp.client import fedimint_client
from clavestra_mpp.types import FedimintClientConfig


@dataclass
class MockChallenge:
    """Minimal mock matching pympp Challenge structure."""

    id: str = "autojoin-challenge"
    realm: str = "test"
    method: str = "fedimint"
    intent: str = "charge"
    request: dict[str, Any] = field(
        default_factory=lambda: {"amount": "1000", "currency": "msats"}
    )
    request_b64: str = "eyJhbW91bnQiOiIxMDAwIn0="
    expires: str | None = None
    digest: str | None = None


def _make_method(invite_code: str | None = None) -> FedimintMethod:
    """Create a FedimintMethod with a mocked clientd."""
    method = FedimintMethod(
        clientd_url="http://localhost:5000",
        invite_code=invite_code,
    )
    method._clientd = AsyncMock()
    method._clientd.spend.return_value = {
        "notes": "mock-notes-1000-op1",
        "operation_id": "op1",
    }
    return method


async def test_autojoin_calls_join_on_first_create_credential():
    """create_credential with invite_code calls join_federation before spend."""
    method = _make_method(invite_code="fed1invite_test_code")

    await method.create_credential(MockChallenge())

    method._clientd.join_federation.assert_called_once_with("fed1invite_test_code")
    method._clientd.spend.assert_called_once_with(1000)


async def test_autojoin_skips_join_on_second_call():
    """Second create_credential call does NOT call join_federation again."""
    method = _make_method(invite_code="fed1invite_test_code")

    await method.create_credential(MockChallenge(id="c1"))
    await method.create_credential(MockChallenge(id="c2"))

    # join_federation called exactly once despite two create_credential calls
    method._clientd.join_federation.assert_called_once_with("fed1invite_test_code")
    assert method._clientd.spend.call_count == 2


async def test_autojoin_does_not_call_join_without_invite_code():
    """create_credential without invite_code does NOT call join_federation."""
    method = _make_method(invite_code=None)

    await method.create_credential(MockChallenge())

    method._clientd.join_federation.assert_not_called()
    method._clientd.spend.assert_called_once_with(1000)


async def test_autojoin_ignores_already_member_error():
    """join_federation error containing 'already' is silently ignored."""
    method = _make_method(invite_code="fed1invite_test_code")
    method._clientd.join_federation.side_effect = Exception(
        "Already a member of this federation"
    )

    # Should NOT raise -- "already" errors are silently handled
    credential = await method.create_credential(MockChallenge())

    method._clientd.join_federation.assert_called_once()
    method._clientd.spend.assert_called_once_with(1000)
    assert credential.payload["oobNotes"] == "mock-notes-1000-op1"


async def test_autojoin_rethrows_non_member_error():
    """join_federation error NOT containing 'already' or 'member' is re-thrown."""
    method = _make_method(invite_code="fed1invite_test_code")
    method._clientd.join_federation.side_effect = Exception("Internal server error")

    with pytest.raises(Exception, match="Internal server error"):
        await method.create_credential(MockChallenge())

    method._clientd.join_federation.assert_called_once()
    method._clientd.spend.assert_not_called()
