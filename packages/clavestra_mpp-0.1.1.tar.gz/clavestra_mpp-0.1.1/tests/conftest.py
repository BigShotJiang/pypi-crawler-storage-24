"""Shared test fixtures for clavestra-mpp tests."""

import pytest

CLIENTD_URL = "http://localhost:5000"
FEDERATION_ID = "fed1testfederationid"


@pytest.fixture
def clientd_url() -> str:
    return CLIENTD_URL


@pytest.fixture
def federation_id() -> str:
    return FEDERATION_ID
