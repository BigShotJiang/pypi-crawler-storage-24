"""Unit tests for FedimintMethod.create_credential() -- client-side credential creation."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any
from unittest.mock import AsyncMock

from clavestra_mpp import fedimint, fedimint_client
from clavestra_mpp.method import FedimintMethod
from clavestra_mpp.store import MemoryStore
from clavestra_mpp.types import FedimintClientConfig, FedimintServerConfig


@dataclass
class MockChallenge:
    """Minimal mock matching pympp Challenge structure for create_credential."""

    id: str = "challenge-1"
    realm: str = "test"
    method: str = "fedimint"
    intent: str = "charge"
    request: dict[str, Any] = field(
        default_factory=lambda: {"amount": "5000", "currency": "msats"}
    )
    request_b64: str = "eyJhbW91bnQiOiI1MDAwIn0="
    expires: str | None = None
    digest: str | None = None


async def test_create_credential_spends_and_returns():
    """create_credential calls spend and returns Credential with oobNotes in payload."""
    note_store = MemoryStore()
    method = FedimintMethod(
        clientd_url="http://localhost:5000",
        note_store=note_store,
    )
    # Mock the internal clientd
    method._clientd = AsyncMock()
    method._clientd.spend.return_value = {
        "notes": "mock-notes-5000-op1",
        "operation_id": "op1",
    }

    challenge = MockChallenge()
    credential = await method.create_credential(challenge)

    method._clientd.spend.assert_called_once_with(5000)
    assert credential.payload["oobNotes"] == "mock-notes-5000-op1"


async def test_create_credential_persists_before_return():
    """SAFE-01: Notes are persisted to note_store BEFORE credential is returned."""
    call_order: list[tuple[str, str, Any]] = []

    class SpyStore:
        async def get(self, key: str) -> Any:
            return None

        async def put(self, key: str, value: Any) -> None:
            call_order.append(("put", key, value))

        async def delete(self, key: str) -> None:
            pass

    note_store = SpyStore()
    method = FedimintMethod(
        clientd_url="http://localhost:5000",
        note_store=note_store,
    )
    method._clientd = AsyncMock()
    method._clientd.spend.return_value = {
        "notes": "mock-notes-5000-op1",
        "operation_id": "op1",
    }

    challenge = MockChallenge()
    credential = await method.create_credential(challenge)

    # Verify persist happened
    assert len(call_order) == 1
    assert call_order[0] == ("put", "challenge-1", "mock-notes-5000-op1")
    # And credential was returned after persist
    assert credential.payload["oobNotes"] == "mock-notes-5000-op1"


async def test_method_protocol_conformance():
    """FedimintMethod must satisfy pympp Method Protocol."""
    from mpp.server.method import Method

    method = FedimintMethod(clientd_url="http://localhost:5000")
    assert isinstance(method, Method), "FedimintMethod does not satisfy Method Protocol"


async def test_fedimint_factory_returns_method():
    """fedimint() server factory returns FedimintMethod instance."""
    config = FedimintServerConfig(
        clientd_url="http://localhost:5000",
        federation_id="fed1test",
    )
    method = fedimint(config)
    assert isinstance(method, FedimintMethod)
    assert method.name == "fedimint"


async def test_fedimint_client_factory_returns_method():
    """fedimint_client() client factory returns FedimintMethod instance."""
    config = FedimintClientConfig(
        clientd_url="http://localhost:5000",
    )
    method = fedimint_client(config)
    assert isinstance(method, FedimintMethod)
    assert method.name == "fedimint"
