"""Integration test fixtures for clavestra-mpp.

Loads .env.test from repo root and provides real clientd connection fixtures.
"""

import os
from pathlib import Path

import pytest
from dotenv import load_dotenv

# Load .env.test from repo root (4 levels up from tests/integration/)
_env_path = Path(__file__).resolve().parents[4] / ".env.test"
load_dotenv(_env_path)


@pytest.fixture
def clientd_url() -> str:
    return os.environ.get("FEDIMINT_CLIENTD_URL", "http://localhost:5000")


@pytest.fixture
def clientd_password() -> str | None:
    return os.environ.get("FEDIMINT_CLIENTD_PASSWORD", "testpass")


@pytest.fixture
def federation_id() -> str:
    return os.environ.get("FEDERATION_ID", "")
