"""Integration smoke test for clavestra-mpp against real Fedimint federation.

Per CONTEXT.md: Python runs a single happy-path smoke test at one amount
to verify the wrapper works against a real federation. TypeScript handles
the full parameterized suite.
"""

import pytest

from clavestra_mpp.clientd import FedimintClientd


@pytest.mark.integration
async def test_charge_flow_smoke(clientd_url: str, clientd_password: str | None) -> None:
    """E2E charge flow: spend -> reissue at 10,000 msats against real federation."""
    clientd = FedimintClientd(
        base_url=clientd_url,
        password=clientd_password,
        timeout=60.0,  # 60s -- real federation consensus is slow
    )

    amount = 10_000  # 10K msats

    # Step 1: Client spends eCash notes
    spend_result = await clientd.spend(amount)
    assert "notes" in spend_result
    assert isinstance(spend_result["notes"], str)
    assert len(spend_result["notes"]) > 0
    assert "operation_id" in spend_result

    # Step 2: Server reissues notes (atomic verify + settle)
    # amount_msat >= requested due to power-of-2 denomination overpay
    reissue_result = await clientd.reissue(spend_result["notes"])
    assert reissue_result["amount_msat"] >= amount
    assert "operation_id" in reissue_result
