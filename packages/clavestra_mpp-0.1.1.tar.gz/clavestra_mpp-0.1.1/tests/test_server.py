"""Unit tests for FedimintChargeIntent.verify() -- server-side verification."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any
from unittest.mock import AsyncMock

import pytest

from clavestra_mpp.errors import InvalidNotesError
from clavestra_mpp.intent import FedimintChargeIntent
from clavestra_mpp.store import MemoryStore


@dataclass
class MockChallengeEcho:
    """Minimal mock matching pympp ChallengeEcho structure."""

    id: str = "challenge-1"
    realm: str = "test"
    method: str = "fedimint"
    intent: str = "charge"
    request: str = ""
    expires: str | None = None
    digest: str | None = None


@dataclass
class MockCredential:
    """Minimal mock matching pympp Credential structure."""

    challenge: MockChallengeEcho = field(default_factory=MockChallengeEcho)
    payload: dict[str, Any] = field(
        default_factory=lambda: {"oobNotes": "mock-notes-5000-op1"}
    )


async def test_verify_reissues_and_returns_receipt():
    """SAFE-03: verify uses reissue (not validate) for atomic settlement."""
    mock_clientd = AsyncMock()
    mock_clientd.reissue.return_value = {"amount_msat": 5000, "operation_id": "op1"}

    intent = FedimintChargeIntent(clientd=mock_clientd)
    credential = MockCredential()
    request = {"amount": "5000", "currency": "msats", "federationId": "fed1test"}

    receipt = await intent.verify(credential, request)

    mock_clientd.reissue.assert_called_once_with("mock-notes-5000-op1")
    assert receipt.status == "success"
    assert receipt.reference == "op1"
    assert receipt.method == "fedimint"


async def test_verify_idempotent_returns_cached_receipt():
    """SAFE-02: Second verify call returns cached receipt without calling reissue."""
    mock_clientd = AsyncMock()
    mock_clientd.reissue.return_value = {"amount_msat": 5000, "operation_id": "op1"}

    receipt_store = MemoryStore()
    intent = FedimintChargeIntent(clientd=mock_clientd, receipt_store=receipt_store)
    credential = MockCredential()
    request = {"amount": "5000", "currency": "msats", "federationId": "fed1test"}

    # First call -- caches receipt
    receipt1 = await intent.verify(credential, request)
    # Second call -- should return cached receipt
    receipt2 = await intent.verify(credential, request)

    assert receipt1.reference == receipt2.reference
    assert mock_clientd.reissue.call_count == 1  # Only called once


async def test_verify_insufficient_amount_raises():
    """SAFE-04: verify raises InvalidNotesError when notes amount < requested amount."""
    mock_clientd = AsyncMock()
    mock_clientd.reissue.return_value = {"amount_msat": 3000, "operation_id": "op1"}

    intent = FedimintChargeIntent(clientd=mock_clientd)
    credential = MockCredential()
    request = {"amount": "5000", "currency": "msats", "federationId": "fed1test"}

    with pytest.raises(InvalidNotesError, match="Insufficient amount"):
        await intent.verify(credential, request)


async def test_verify_accesses_payload_as_dict():
    """Pitfall 3: credential.payload is dict, accessed via ["oobNotes"] not .oobNotes."""
    mock_clientd = AsyncMock()
    mock_clientd.reissue.return_value = {"amount_msat": 5000, "operation_id": "op1"}

    intent = FedimintChargeIntent(clientd=mock_clientd)
    # Payload as dict -- this is how pympp provides it
    credential = MockCredential(payload={"oobNotes": "test-notes-dict-access"})
    request = {"amount": "5000", "currency": "msats", "federationId": "fed1test"}

    await intent.verify(credential, request)
    mock_clientd.reissue.assert_called_once_with("test-notes-dict-access")


async def test_intent_protocol_conformance():
    """FedimintChargeIntent must satisfy pympp Intent Protocol."""
    from mpp.server.intent import Intent

    mock_clientd = AsyncMock()
    intent = FedimintChargeIntent(clientd=mock_clientd)
    assert isinstance(intent, Intent), "FedimintChargeIntent does not satisfy Intent Protocol"
