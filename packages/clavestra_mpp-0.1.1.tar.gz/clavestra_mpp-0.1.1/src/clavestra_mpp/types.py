from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Protocol, runtime_checkable


@runtime_checkable
class NoteStore(Protocol):
    """Async key-value store for OOBNotes persistence and receipt caching.

    Uses put() (not set()) to match pympp Store convention.
    """

    async def get(self, key: str) -> Any | None: ...
    async def put(self, key: str, value: Any) -> None: ...
    async def delete(self, key: str) -> None: ...


@dataclass(frozen=True)
class FedimintBaseConfig:
    """Shared config for both client and server."""

    clientd_url: str
    password: str | None = None
    timeout: float = 30.0


@dataclass(frozen=True)
class FedimintServerConfig(FedimintBaseConfig):
    """Server-side config. federation_id is REQUIRED."""

    federation_id: str = ""  # Must be provided; empty string = unconfigured
    receipt_store: NoteStore | None = field(default=None, repr=False)


@dataclass(frozen=True)
class FedimintClientConfig(FedimintBaseConfig):
    """Client-side config. federation_id is optional (learned from challenge)."""

    federation_id: str | None = None
    note_store: NoteStore | None = field(default=None, repr=False)
    invite_code: str | None = None  # EXTRA-01: Optional invite code for auto-join
