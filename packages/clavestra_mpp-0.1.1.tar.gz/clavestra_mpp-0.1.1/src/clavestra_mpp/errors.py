from __future__ import annotations

from mpp.errors import PaymentError


class FedimintError(PaymentError):
    """Base class for all Fedimint-specific payment errors."""

    pass


class InvalidNotesError(FedimintError):
    """Payment notes are invalid (malformed, wrong denomination, or insufficient)."""

    type = "urn:mpp:fedimint:invalid-notes"
    title = "Invalid Notes"
    status = 400

    def __init__(self, reason: str | None = None) -> None:
        msg = (
            f"Payment notes are invalid: {reason}."
            if reason
            else "Payment notes are invalid or insufficient."
        )
        super().__init__(msg)


class AlreadySpentError(FedimintError):
    """Double-spend attempt detected by federation."""

    type = "urn:mpp:fedimint:already-spent"
    title = "Already Spent"
    status = 409

    def __init__(self) -> None:
        super().__init__("These notes have already been spent.")


class FederationMismatchError(FedimintError):
    """Notes do not belong to the expected federation."""

    type = "urn:mpp:fedimint:federation-mismatch"
    title = "Federation Mismatch"
    status = 422

    def __init__(self) -> None:
        super().__init__("Notes do not belong to the expected federation.")


class NetworkError(FedimintError):
    """Federation service unavailable (fedimint-clientd unreachable or timeout)."""

    type = "urn:mpp:fedimint:network-error"
    title = "Network Error"
    status = 502

    def __init__(self, reason: str | None = None) -> None:
        msg = (
            f"Federation unavailable: {reason}."
            if reason
            else "Federation service is unavailable."
        )
        super().__init__(msg)
