from __future__ import annotations

from typing import Any

import httpx

from clavestra_mpp.errors import (
    AlreadySpentError,
    FederationMismatchError,
    InvalidNotesError,
    NetworkError,
)


class FedimintClientd:
    """Async HTTP wrapper for the fedimint-clientd REST API.

    Creates a new httpx.AsyncClient per request (no lifecycle management needed).
    Matches the TypeScript FedimintClientd pattern from Phase 1.
    """

    def __init__(
        self,
        base_url: str,
        password: str | None = None,
        timeout: float = 30.0,
    ) -> None:
        self._base_url = base_url.rstrip("/")
        self._timeout = timeout
        self._headers: dict[str, str] = {"Content-Type": "application/json"}
        if password:
            self._headers["Authorization"] = f"Bearer {password}"

    async def spend(self, amount_msat: int) -> dict[str, Any]:
        """POST /fedimint/v2/mint/spend -- spend eCash notes."""
        return await self._post("/fedimint/v2/mint/spend", {"amount_msat": amount_msat})

    async def reissue(self, notes: str) -> dict[str, Any]:
        """POST /fedimint/v2/mint/reissue -- reissue (atomic verify+settle)."""
        return await self._post("/fedimint/v2/mint/reissue", {"notes": notes})

    async def validate(self, notes: str) -> dict[str, Any]:
        """POST /fedimint/v2/mint/validate -- validate notes (read-only, DO NOT use for settlement)."""
        return await self._post("/fedimint/v2/mint/validate", {"notes": notes})

    async def info(self) -> dict[str, Any]:
        """GET /fedimint/v2/admin/info -- federation info."""
        return await self._get("/fedimint/v2/admin/info")

    async def join_federation(self, invite_code: str) -> None:
        """POST /fedimint/v2/admin/join -- join a federation. Returns void."""
        await self._post_void("/fedimint/v2/admin/join", {"invite_code": invite_code})

    async def _post(self, path: str, body: dict[str, Any]) -> dict[str, Any]:
        url = f"{self._base_url}{path}"
        try:
            async with httpx.AsyncClient() as client:
                response = await client.post(
                    url,
                    json=body,
                    headers=self._headers,
                    timeout=self._timeout,
                )
        except httpx.HTTPError as e:
            raise NetworkError(reason=str(e)) from e
        if not response.is_success:
            self._handle_error(response)
        return response.json()

    async def _get(self, path: str) -> dict[str, Any]:
        url = f"{self._base_url}{path}"
        try:
            async with httpx.AsyncClient() as client:
                response = await client.get(
                    url,
                    headers=self._headers,
                    timeout=self._timeout,
                )
        except httpx.HTTPError as e:
            raise NetworkError(reason=str(e)) from e
        if not response.is_success:
            self._handle_error(response)
        return response.json()

    async def _post_void(self, path: str, body: dict[str, Any]) -> None:
        url = f"{self._base_url}{path}"
        try:
            async with httpx.AsyncClient() as client:
                response = await client.post(
                    url,
                    json=body,
                    headers=self._headers,
                    timeout=self._timeout,
                )
        except httpx.HTTPError as e:
            raise NetworkError(reason=str(e)) from e
        if not response.is_success:
            self._handle_error(response)

    def _handle_error(self, response: httpx.Response) -> None:
        """Map HTTP error responses to FedimintError subclasses.

        Same heuristic as TypeScript: body text matching for error classification.
        """
        body = response.text.lower()
        if "already" in body or "spent" in body:
            raise AlreadySpentError()
        if "federation" in body:
            raise FederationMismatchError()
        raise InvalidNotesError(reason=response.text or f"HTTP {response.status_code}")
