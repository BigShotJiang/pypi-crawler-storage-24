"""Fedimint eCash payment method for MPP."""

from clavestra_mpp.client import fedimint_client
from clavestra_mpp.errors import (
    AlreadySpentError,
    FederationMismatchError,
    FedimintError,
    InvalidNotesError,
    NetworkError,
)
from clavestra_mpp.intent import FedimintChargeIntent
from clavestra_mpp.method import FedimintMethod
from clavestra_mpp.store import MemoryStore
from clavestra_mpp.types import (
    FedimintBaseConfig,
    FedimintClientConfig,
    FedimintServerConfig,
    NoteStore,
)


def fedimint(config: FedimintServerConfig) -> FedimintMethod:
    """Convenience factory for server-side FedimintMethod.

    Returns a FedimintMethod configured for server use (verify via intents).
    """
    return FedimintMethod(
        clientd_url=config.clientd_url,
        federation_id=config.federation_id,
        password=config.password,
        timeout=config.timeout,
        receipt_store=config.receipt_store,
    )


__all__ = [
    "fedimint",
    "fedimint_client",
    "FedimintMethod",
    "FedimintChargeIntent",
    "FedimintError",
    "InvalidNotesError",
    "AlreadySpentError",
    "FederationMismatchError",
    "NetworkError",
    "MemoryStore",
    "NoteStore",
    "FedimintBaseConfig",
    "FedimintServerConfig",
    "FedimintClientConfig",
]
