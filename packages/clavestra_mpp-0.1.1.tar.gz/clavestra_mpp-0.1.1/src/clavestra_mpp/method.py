"""Fedimint eCash payment method for MPP.

FedimintMethod satisfies mpp.server.Method Protocol via duck typing (no inheritance).
Handles both server-side (intents property) and client-side (create_credential).
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from mpp import Credential, ChallengeEcho

from clavestra_mpp.clientd import FedimintClientd
from clavestra_mpp.intent import FedimintChargeIntent
from clavestra_mpp.store import MemoryStore
from clavestra_mpp.types import NoteStore

if TYPE_CHECKING:
    from mpp import Challenge
    from mpp.server.intent import Intent


class FedimintMethod:
    """Fedimint eCash payment method for MPP.

    Satisfies mpp.server.Method Protocol via duck typing (no inheritance).
    Handles both server-side (intents property) and client-side (create_credential).
    """

    name = "fedimint"

    def __init__(
        self,
        clientd_url: str,
        federation_id: str = "",
        password: str | None = None,
        timeout: float = 30.0,
        note_store: NoteStore | None = None,
        receipt_store: NoteStore | None = None,
        invite_code: str | None = None,
    ) -> None:
        self._clientd = FedimintClientd(
            base_url=clientd_url,
            password=password,
            timeout=timeout,
        )
        self._note_store: NoteStore = note_store or MemoryStore()
        self._charge_intent = FedimintChargeIntent(
            clientd=self._clientd,
            receipt_store=receipt_store,
        )
        self._federation_id = federation_id
        self._invite_code = invite_code
        self._joined = False

    @property
    def intents(self) -> dict[str, Intent]:
        return {"charge": self._charge_intent}

    async def create_credential(self, challenge: Challenge) -> Credential:
        """Client-side: spend notes, persist, return credential.

        SAFE-01: Notes are persisted to note_store BEFORE the credential is returned.
        """
        # EXTRA-01: Lazy auto-join on first spend
        if self._invite_code and not self._joined:
            try:
                await self._clientd.join_federation(self._invite_code)
            except Exception as e:
                msg = str(e).lower()
                if "already" not in msg and "member" not in msg:
                    raise
            self._joined = True

        amount = int(challenge.request["amount"])

        # Spend eCash notes via fedimint-clientd
        result = await self._clientd.spend(amount)
        notes = result["notes"]

        # SAFE-01: Persist notes BEFORE returning credential
        # If client crashes after this line, notes can be recovered from note_store
        await self._note_store.put(challenge.id, notes)

        # Construct credential with ChallengeEcho
        return Credential(
            challenge=ChallengeEcho(
                id=challenge.id,
                realm=challenge.realm,
                method=challenge.method,
                intent=challenge.intent,
                request=challenge.request_b64,
                expires=challenge.expires,
                digest=challenge.digest,
            ),
            payload={"oobNotes": notes},
        )
