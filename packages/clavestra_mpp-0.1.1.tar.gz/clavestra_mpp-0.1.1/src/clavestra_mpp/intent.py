"""Fedimint charge intent for MPP server-side verification.

FedimintChargeIntent satisfies mpp.server.Intent Protocol via duck typing (no inheritance).
Implements atomic verify+settle via reissue with idempotency and amount validation.
"""

from __future__ import annotations

from typing import Any

from mpp import Credential, Receipt

from clavestra_mpp.clientd import FedimintClientd
from clavestra_mpp.errors import InvalidNotesError
from clavestra_mpp.store import MemoryStore
from clavestra_mpp.types import NoteStore


class FedimintChargeIntent:
    """Charge intent for Fedimint eCash.

    Satisfies mpp.server.Intent Protocol via duck typing (no inheritance).
    Implements atomic verify+settle via reissue with idempotency and amount validation.
    """

    name = "charge"

    def __init__(
        self,
        clientd: FedimintClientd,
        receipt_store: NoteStore | None = None,
    ) -> None:
        self._clientd = clientd
        self._receipt_store: NoteStore = receipt_store or MemoryStore()

    async def verify(
        self,
        credential: Credential,
        request: dict[str, Any],
    ) -> Receipt:
        challenge_id = credential.challenge.id

        # SAFE-02: Idempotency -- return cached receipt if already settled
        cached = await self._receipt_store.get(challenge_id)
        if cached is not None:
            return cached

        # SAFE-03: Atomic verify+settle via reissue -- NEVER validate-only
        oob_notes = credential.payload["oobNotes"]
        result = await self._clientd.reissue(oob_notes)

        # SAFE-04: Amount validation -- notes must cover the requested charge
        # request["amount"] is a string (pympp convention), result["amount_msat"] is int
        if result["amount_msat"] < int(request["amount"]):
            raise InvalidNotesError(reason="Insufficient amount")

        # Create receipt
        receipt = Receipt.success(
            reference=result["operation_id"],
            method="fedimint",
        )

        # Cache receipt for idempotent retries (SAFE-02)
        await self._receipt_store.put(challenge_id, receipt)

        return receipt
