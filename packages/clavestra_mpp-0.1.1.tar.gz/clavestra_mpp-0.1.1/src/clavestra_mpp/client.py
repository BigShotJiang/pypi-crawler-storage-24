"""Client-side factory for Fedimint eCash payment method."""

from __future__ import annotations

from clavestra_mpp.method import FedimintMethod
from clavestra_mpp.types import FedimintClientConfig


def fedimint_client(config: FedimintClientConfig) -> FedimintMethod:
    """Convenience factory for client-side FedimintMethod.

    Returns a FedimintMethod configured for client use (create_credential).
    """
    return FedimintMethod(
        clientd_url=config.clientd_url,
        federation_id=config.federation_id or "",
        password=config.password,
        timeout=config.timeout,
        note_store=config.note_store,
        invite_code=config.invite_code,
    )
