import json
import logging
from typing import Optional, List, Any
from openai import OpenAI
from pydantic import BaseModel
from PIL import Image
from tenacity import retry, stop_after_attempt, retry_if_exception_type
#from watchdog.observers.fsevents2 import message

from polymage.model.model import Model
from polymage.media.media import Media
from polymage.media.image_media import ImageMedia
from polymage.platform.platform import Platform


logger = logging.getLogger(__name__)
logger.addHandler(logging.NullHandler())


class LMStudioPlatform(Platform):
	"""
	Interface for interacting with local models via LM Studio's OpenAI-compatible API.

	This class extends Platform to support text-to-text, structured text-to-data,
	and image-to-text operations using LM Studio as the backend. It automatically
	configures an OpenAI-compatible client pointing to LM Studio's local server
	endpoint (typically localhost:1234). Image generation and image-to-image
	transformations are currently unsupported and will raise NotImplementedError.

	LM Studio must be running locally with the target model loaded and exposed
	through its API server before using this platform.
	"""
	def __init__(self, host: str = "127.0.0.1:1234", **kwargs: Any) -> None:
		super().__init__('lmstudio', **kwargs)
		self._host = host
		self._api_key = "lm-studio"  # Dummy key (LM Studio doesn't require real keys)


	def _text2text(self, model: Model, prompt: str, media: Optional[List[Media]] = None, response_model: Optional[BaseModel] = None, **kwargs: Any) -> str:
		system_prompt: Optional[str] = kwargs.get("system_prompt", "")
		client = OpenAI(
				base_url=f"http://{self._host}/v1",  # LM Studio's default endpoint
				api_key=self._api_key
			)
		response = client.chat.completions.create(
			model=model.internal_name(),
			messages=[
				{"role": "system", "content": system_prompt},
				{"role": "user", "content": prompt}
			],
			temperature=kwargs.get('temperature', 0.2)
		)
		respmess=response.choices[0].message
		if respmess.content != "":
			return respmess.content.strip()
		elif respmess.reasoning_content != "":
			return respmess.reasoning_content.strip()
		else:
			return None


	#
	# using structured data may sometime fail, because the result is not a valid JSON
	# if the JSON is not valid, retry 3 times
	#
	@retry(retry=retry_if_exception_type(json.JSONDecodeError), stop=stop_after_attempt(3))
	def _text2data(self, model: Model, prompt: str, response_model: BaseModel, media: Optional[List[Media]] = None, **kwargs: Any) -> str:
		system_prompt: Optional[str] = kwargs.get("system_prompt", "")
		client = OpenAI(
				base_url=f"http://{self._host}/v1",  # LM Studio's default endpoint
				api_key=self._api_key
		)

		json_schema = response_model.model_json_schema()
		json_schema_name = json_schema['title']

		response = client.chat.completions.create(
			model=model.internal_name(),
			messages=[
				{"role": "system", "content": system_prompt},
				{"role": "user", "content": prompt}
			],
			response_format={
				"type": "json_schema",
				"json_schema": {
					"name": json_schema_name,
					"schema": json_schema,
				},
			},
			temperature=kwargs.get('temperature', 0.2)
		)
		respmess = response.choices[0].message
		json_string = '{}'
		if respmess.content != "":
			json_string = respmess.content.strip()
		elif respmess.reasoning_content != "":
			json_string =  respmess.reasoning_content.strip()

		# return a python Dict
		return json.loads(json_string)


	def _image2text(self, model: Model, prompt: str, media: List[ImageMedia], **kwargs: Any) -> str:
		client = OpenAI(
			base_url=f"http://{self._host}/v1",  # LM Studio's default endpoint
			api_key=self._api_key
		)
		if len(media) == 0:
			return ""
		else:
			image = media[0]
			base64_image = image.to_base64()

		response = client.responses.create(
			model=model.internal_name(),
			input=[
				{
					"role": "user",
					"content": [
						{"type": "input_text", "text": prompt},
						{"type": "input_image", "image_url": f"data:image/png;base64,{base64_image}"},
					],
				}
			],
			temperature=kwargs.get('temperature', 0.2)
		)
		return response.output[0].content[0].text


	def _text2image(self, model: str, prompt: str, **kwargs: Any) -> Image.Image:
		"""Not supported"""
		pass

	def _text2video(self, model: Model, prompt: str, **kwargs: Any):
		"""Not supported"""
		pass

	def _image2image(self, model: str, prompt: str, image: Image.Image, **kwargs: Any) -> Image.Image:
		"""Not supported"""
		pass

	def _image2video(self, model: Model, prompt: str, image: Image.Image, **kwargs: Any):
		"""Not supported"""
		pass

