class CPURenderContext:
    """
    Class to wrap the information we need to
    be able to execute the nodes in CPU.

    This class must be created by the general
    node (located in `yta-editor-nodes` with the
    data from the general `RenderContext`).
    """

    def __init__(
        self,
        output_size: tuple[int, int]
    ):
        self.output_size: tuple[int, int] = output_size
        """
        The expected size for the output.
        """