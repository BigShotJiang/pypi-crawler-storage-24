from yta_editor_nodes_cpu.processor.abstract import _NodeProcessorCPU, _NodeProcessorCoreCPU
from typing import Union

import numpy as np


class PadToSizeNodeProcessorCPU(_NodeProcessorCPU):
    """
    The node to modify the input to center it and
    fill the outside with transparency.

    This class can be instantiated many different
    times with different parameters, but will always
    call the same `Singleton` node processor instance
    to process the `input`.
    """

    mandatory_inputs = ['base_input']
    optional_inputs = []
    
    def __init__(
        self,
        cpu_render_context: 'CPURenderContext'
    ):
        super().__init__(
            node_processor = _PadToSizeNodeProcessorCoreCPU(),
            cpu_render_context = cpu_render_context
        )

    def process(
        self,
        inputs: dict[str, np.ndarray],
        evaluation_context: 'EvaluationContext',
        # TODO: Should we set the 'factor' here to be able
        # to modify it if it is different than None (?)
        **kwargs
    ) -> np.ndarray:
        """
        Process the `input` provided by using the node
        processor instance associated to this node and
        return the output.
        """
        return self.node_processor.process(
            input = inputs['base_input'],
            output_size = self.cpu_render_context.output_size,
            **kwargs
        )
    
class _PadToSizeNodeProcessorCoreCPU(_NodeProcessorCoreCPU):
    """
    *For internal use only*
    
    Node processor that modifies the input to center
    it and fill the outside with transparency.
    """

    def process(
        self,
        input: np.ndarray,
        output_size: Union[tuple[int, int], None],
        **kwargs
    ) -> np.ndarray:
        """
        Process the `input` provided.
        """
        if input.ndim != 3:
            raise Exception('The frame must be HxWxC.')

        src_h, src_w, src_c = input.shape

        if src_c not in (3, 4):
            raise Exception('The input must be RGB or GBA.')

        # Final transparent frame
        dst = np.zeros((output_size[1], output_size[0], 4), dtype = input.dtype)

        # RGBA if necessary
        if src_c == 3:
            src_rgba = np.empty((src_h, src_w, 4), dtype = input.dtype)
            src_rgba[..., :3] = input
            src_rgba[..., 3] = np.iinfo(input.dtype).max
        else:
            src_rgba = input

        # Offsets to center
        offset_x = (output_size[0] - src_w) // 2
        offset_y = (output_size[1] - src_h) // 2

        if (
            offset_x < 0 or
            offset_y < 0
        ):
            # TODO: Do rescale and crop if needed
            raise Exception('Original frame is bigger than the size requested.')

        # Copy it
        dst[
            offset_y:offset_y + src_h,
            offset_x:offset_x + src_w
        ] = src_rgba

        # TODO: I think this shouldn't be done here...
        # Force it to be continuous to avoid PyAv errors
        dst = np.ascontiguousarray(dst)

        return dst
    
