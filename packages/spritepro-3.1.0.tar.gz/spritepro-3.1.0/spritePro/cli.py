from .cli_tools import run_cli


def main() -> None:
    run_cli()


if __name__ == "__main__":
    main()
