"""Core module for LinkedIn analyzer."""

from __future__ import annotations

from linkedin_analyzer.core.cleaner import run_cleaner, validate_columns
from linkedin_analyzer.core.excel import format_excel_output
from linkedin_analyzer.core.text import (
    clean_comments_message,
    clean_connections_date,
    clean_date,
    clean_empty_field,
    clean_messages_content,
    clean_shares_commentary,
    clean_value,
    escape_excel_formula,
    is_missing,
)
from linkedin_analyzer.core.types import (
    CleanerConfig,
    CleanerResult,
    ColumnConfig,
    ColumnWidths,
    TextCleaner,
)

__all__ = [
    "CleanerConfig",
    "CleanerResult",
    "ColumnConfig",
    "ColumnWidths",
    "TextCleaner",
    "clean_comments_message",
    "clean_connections_date",
    "clean_date",
    "clean_empty_field",
    "clean_messages_content",
    "clean_shares_commentary",
    "clean_value",
    "escape_excel_formula",
    "format_excel_output",
    "is_missing",
    "run_cleaner",
    "validate_columns",
]
