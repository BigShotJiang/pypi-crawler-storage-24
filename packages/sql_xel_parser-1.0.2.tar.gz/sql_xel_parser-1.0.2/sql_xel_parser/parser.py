"""
XEL Parser - Core module for parsing SQL Server Extended Events (.xel) files.

This module handles the low-level parsing of XEL binary files and extraction
of event data.
"""

import struct
import sys
import xml.etree.ElementTree as ET
from typing import Iterator, Dict, Any, Optional, BinaryIO
from datetime import datetime
from io import BytesIO


class XELParser:
    """Parser for SQL Server Extended Events (.xel) files."""

    # XEL file format constants
    HEADER_MAGIC = b'XELH'
    EVENT_MAGIC = b'XEVT'

    def __init__(self, file_path: str):
        """
        Initialize the XEL parser.

        Args:
            file_path: Path to the .xel file
        """
        self.file_path = file_path
        self.events_parsed = 0

    def parse(self) -> Iterator[Dict[str, Any]]:
        """
        Parse the XEL file and yield events as dictionaries.

        Yields:
            Dictionary containing event data
        """
        events_found = 0
        try:
            with open(self.file_path, 'rb') as f:
                # Try to parse as XEL binary format
                for event in self._parse_binary_format(f):
                    self.events_parsed += 1
                    events_found += 1
                    yield event

            # If no events found in binary, try XML fallback
            if events_found == 0:
                for event in self._parse_xml_fallback():
                    self.events_parsed += 1
                    yield event
        except Exception as e:
            # If all parsing fails, try XML parsing as last resort
            print(f"Parsing error, attempting XML fallback: {e}", file=sys.stderr)
            try:
                for event in self._parse_xml_fallback():
                    self.events_parsed += 1
                    yield event
            except Exception as xml_error:
                raise Exception(f"Failed to parse XEL file: Error: {e}, XML error: {xml_error}")

    def _parse_binary_format(self, f: BinaryIO) -> Iterator[Dict[str, Any]]:
        """
        Parse XEL file in binary format.

        XEL files contain a header followed by event blocks. SQL Server XEL files
        use a proprietary binary format that requires specialized parsing.
        """
        # Read all data
        f.seek(0)
        data = f.read()

        # Check for XEL magic number
        if len(data) < 4:
            return

        # Check if it's an XML file
        if data[:5] == b'<?xml' or data[:6] == b'<event' or data[:7] == b'<Events':
            # It's XML, don't parse as binary
            return

        magic = data[0:4]
        # Common XEL magic numbers
        if magic not in [b'Z7\xab\xef', b'\x5a\x37\xab\xef']:
            # Unknown format, try XML parsing as fallback
            return

        # For SQL Server XEL files, try to extract structured data
        # These files use a complex binary format with UTF-16 strings
        events_found = 0

        # Look for XML event patterns (some XEL variants have XML)
        xml_start_markers = [b'<event', b'<?xml', b'<\x00e\x00v\x00e\x00n\x00t\x00']

        for marker in xml_start_markers:
            offset = 0
            while True:
                pos = data.find(marker, offset)
                if pos == -1:
                    break

                # Try to extract XML from this position
                try:
                    xml_data = self._extract_xml_from_position(data, pos)
                    if xml_data:
                        event = self._parse_event_xml(xml_data)
                        if event:
                            events_found += 1
                            yield event
                    offset = pos + 1
                except Exception:
                    offset = pos + 1
                    continue

        # If no XML events found, try to extract real audit data from binary
        if events_found == 0:
            try:
                from .real_parser import extract_real_data_from_xel
                real_data = extract_real_data_from_xel(self.file_path)

                # Create events from extracted data
                info = real_data['extracted_info']

                # Create main audit summary event
                yield {
                    'name': 'audit_data_extracted',
                    'timestamp': info.get('timestamps', [''])[0] if info.get('timestamps') else '',
                    'data': {
                        'format': 'SQL Server XEL binary format',
                        'extraction_method': 'Binary data analysis',
                        'server': info['server_names'][0] if info['server_names'] else 'unknown',
                        'databases': info['database_names'],
                        'ip_addresses': info['ip_addresses'],
                        'event_types': info['event_types'],
                        'applications': info['applications'],
                        'users': info['users'],
                        'file_size_bytes': len(data),
                    },
                    'actions': info.get('session_info', {})
                }

                # Create individual events for reconstructed data
                for event in real_data.get('reconstructed_events', [])[:10]:
                    yield {
                        'name': event.get('event_type', 'unknown'),
                        'timestamp': event.get('possible_timestamp', ''),
                        'data': {k: v for k, v in event.items() if k not in ['event_type', 'possible_timestamp']},
                        'actions': {}
                    }

            except ImportError:
                # Fallback to simple string extraction
                strings = self._extract_utf16_strings(data)
                yield {
                    'name': 'binary_data',
                    'timestamp': '',
                    'data': {
                        'format': 'SQL Server XEL binary format',
                        'note': 'Install xel_real_parser for detailed extraction',
                        'extracted_strings_count': len(strings),
                        'extracted_strings_sample': strings[:10] if len(strings) > 10 else strings,
                        'file_size_bytes': len(data),
                        'magic_bytes': magic.hex()
                    },
                    'actions': {}
                }

    def _extract_utf16_strings(self, data: bytes, min_length: int = 8) -> list:
        """
        Extract UTF-16 encoded strings from binary data.

        Args:
            data: Binary data
            min_length: Minimum string length to extract

        Returns:
            List of extracted strings
        """
        strings = []
        seen = set()
        try:
            # Try UTF-16 LE decoding
            decoded = data.decode('utf-16-le', errors='ignore')
            # Split on null characters and filter
            parts = decoded.split('\x00')
            for part in parts:
                part = part.strip()
                # Filter for readable ASCII strings and avoid duplicates
                if (len(part) >= min_length and
                    part.isprintable() and
                    part.isascii() and
                    part not in seen and
                    (' ' in part or '.' in part or '_' in part)):  # Likely meaningful text
                    strings.append(part)
                    seen.add(part)
        except:
            pass

        return list(set(strings))[:100]  # Limit to unique 100 most useful strings

    def _extract_xml_from_position(self, data: bytes, start_pos: int) -> Optional[str]:
        """
        Extract complete XML from a starting position in binary data.

        Args:
            data: Binary data
            start_pos: Starting position of XML

        Returns:
            XML string or None if extraction fails
        """
        # Look for XML end tag
        end_markers = [b'</event>', b'</Event>']

        for end_marker in end_markers:
            end_pos = data.find(end_marker, start_pos)
            if end_pos != -1:
                end_pos += len(end_marker)
                xml_bytes = data[start_pos:end_pos]
                try:
                    # Try to decode as UTF-8 or UTF-16
                    for encoding in ['utf-8', 'utf-16-le', 'utf-16-be', 'latin-1']:
                        try:
                            xml_str = xml_bytes.decode(encoding)
                            # Basic validation
                            if '<event' in xml_str.lower() and '</event>' in xml_str.lower():
                                return xml_str
                        except:
                            continue
                except:
                    pass
        return None

    def _parse_xml_fallback(self) -> Iterator[Dict[str, Any]]:
        """
        Fallback method to parse XEL file as XML.
        Some tools export XEL data as XML.
        """
        try:
            tree = ET.parse(self.file_path)
            root = tree.getroot()

            # Handle different XML structures
            events = root.findall('.//event') or root.findall('.//Event')
            for event_elem in events:
                event = self._parse_event_element(event_elem)
                if event:
                    yield event
        except Exception as e:
            raise Exception(f"XML parsing failed: {e}")

    def _parse_event_xml(self, xml_str: str) -> Optional[Dict[str, Any]]:
        """
        Parse an individual event XML string.

        Args:
            xml_str: XML string containing event data

        Returns:
            Dictionary with event data or None
        """
        try:
            # Clean up XML string
            xml_str = xml_str.strip()

            # Parse XML
            root = ET.fromstring(xml_str)
            return self._parse_event_element(root)
        except Exception:
            return None

    def _parse_event_element(self, elem: ET.Element) -> Dict[str, Any]:
        """
        Parse an event XML element into a dictionary.

        Args:
            elem: XML element representing an event

        Returns:
            Dictionary with event data
        """
        event = {
            'name': elem.get('name', 'unknown'),
            'timestamp': elem.get('timestamp', ''),
            'data': {},
            'actions': {}
        }

        # Parse data fields
        for data_elem in elem.findall('.//data') or elem.findall('.//Data'):
            name = data_elem.get('name', '')
            value = self._extract_value(data_elem)
            if name:
                event['data'][name] = value

        # Parse action fields
        for action_elem in elem.findall('.//action') or elem.findall('.//Action'):
            name = action_elem.get('name', '')
            value = self._extract_value(action_elem)
            if name:
                event['actions'][name] = value

        # Parse any direct text content
        if elem.text and elem.text.strip():
            event['content'] = elem.text.strip()

        return event

    def _extract_value(self, elem: ET.Element) -> Any:
        """
        Extract value from an XML element.

        Args:
            elem: XML element

        Returns:
            Extracted value (string, int, float, etc.)
        """
        # Try 'value' attribute first
        value = elem.get('value')
        if value is not None:
            return self._convert_value(value)

        # Try text content
        if elem.text:
            return self._convert_value(elem.text.strip())

        # Try child elements
        value_elem = elem.find('value') or elem.find('Value')
        if value_elem is not None and value_elem.text:
            return self._convert_value(value_elem.text.strip())

        return None

    def _convert_value(self, value: str) -> Any:
        """
        Convert string value to appropriate type.

        Args:
            value: String value

        Returns:
            Converted value
        """
        if not value:
            return value

        # Try integer
        try:
            return int(value)
        except ValueError:
            pass

        # Try float
        try:
            return float(value)
        except ValueError:
            pass

        # Try boolean
        if value.lower() in ('true', 'false'):
            return value.lower() == 'true'

        # Return as string
        return value

    def get_stats(self) -> Dict[str, Any]:
        """
        Get parsing statistics.

        Returns:
            Dictionary with stats
        """
        return {
            'file_path': self.file_path,
            'events_parsed': self.events_parsed
        }
