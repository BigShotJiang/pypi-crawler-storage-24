"""
XEL Parser - Parse and analyze SQL Server Extended Events files.

A Python package for parsing and analyzing SQL Server Extended Events (.xel) files
without requiring SQL Server.
"""

from .parser import XELParser
from .converter import XELConverter
from .analyzer import XELAnalyzer
from .real_parser import parse_xel_file, extract_real_data_from_xel

# Get version from setuptools_scm
try:
    from ._version import version as __version__
except ImportError:
    # Fallback for development without install
    try:
        from setuptools_scm import get_version
        __version__ = get_version(root='..', relative_to=__file__)
    except (ImportError, LookupError):
        __version__ = "0.0.0.dev0"

__all__ = ['XELParser', 'XELConverter', 'XELAnalyzer', 'parse_xel_file', 'extract_real_data_from_xel']
