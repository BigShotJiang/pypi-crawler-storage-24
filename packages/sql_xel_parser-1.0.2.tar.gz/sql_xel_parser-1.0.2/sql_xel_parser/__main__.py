"""Allow package to be run as python -m xel_parser"""

from .cli import main

if __name__ == '__main__':
    main()
