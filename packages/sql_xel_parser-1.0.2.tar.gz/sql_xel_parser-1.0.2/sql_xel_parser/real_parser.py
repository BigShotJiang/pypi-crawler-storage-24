"""
Real XEL Parser - Extract actual data from SQL Server binary XEL files.

This parser extracts meaningful audit information from SQL Server Extended Events files
without requiring SQL Server.
"""

import struct
import re
from typing import List, Dict, Any
from collections import defaultdict


def extract_real_data_from_xel(file_path: str) -> Dict[str, Any]:
    """
    Extract real audit/event data from a SQL Server XEL binary file.

    Args:
        file_path: Path to .xel file

    Returns:
        Dictionary with extracted event data
    """
    with open(file_path, 'rb') as f:
        data = f.read()

    result = {
        'file_path': file_path,
        'file_size': len(data),
        'magic': data[:4].hex() if len(data) >= 4 else None,
        'extracted_info': {}
    }

    # Decode as UTF-16 to extract strings
    try:
        decoded = data.decode('utf-16-le', errors='ignore')

        # Extract various types of information
        result['extracted_info'] = {
            'server_names': extract_servers(decoded),
            'database_names': extract_databases(decoded),
            'sql_statements': extract_sql(decoded),
            'ip_addresses': extract_ips(decoded),
            'event_types': extract_event_types(decoded),
            'timestamps': extract_timestamps(decoded),
            'session_info': extract_sessions(decoded),
            'users': extract_users(decoded),
            'applications': extract_applications(decoded),
        }

        # Try to reconstruct partial events from the data
        result['reconstructed_events'] = reconstruct_events(decoded, data)

    except Exception as e:
        result['error'] = str(e)

    return result


def extract_servers(text: str) -> List[str]:
    """Extract server names."""
    pattern = r'sql-[a-zA-Z0-9\-]+-[a-z]+\d+'
    servers = re.findall(pattern, text)
    return list(set(servers))


def extract_databases(text: str) -> List[str]:
    """Extract database names."""
    # Look for common database patterns
    databases = set()

    # Pattern 1: database names in context
    patterns = [
        r'(?:database|db)[:\s]+([a-zA-Z][a-zA-Z0-9_]{2,30})',
        r'USE\s+([a-zA-Z][a-zA-Z0-9_]{2,30})',
        r'FROM\s+([a-zA-Z][a-zA-Z0-9_]{2,30})\.',
    ]

    for pattern in patterns:
        matches = re.findall(pattern, text, re.IGNORECASE)
        databases.update(matches)

    # Pattern 2: Look for specific known database names
    # Common patterns in audit logs
    words = text.split()
    for i, word in enumerate(words):
        # Look for DB-like words
        if len(word) > 3 and word.isalnum() and not word.isdigit():
            # Check if it appears in database-related context
            if i > 0 and any(kw in words[i-1].lower() for kw in ['database', 'db', 'use', 'from']):
                databases.add(word)

    # Common system databases
    system_dbs = {'master', 'tempdb', 'model', 'msdb'}
    found_system = [db for db in system_dbs if db in text.lower()]
    databases.update(found_system)

    # Filter out noise
    filtered = {db for db in databases if 2 < len(db) < 50 and not db.isdigit()}
    return sorted(filtered)


def extract_sql(text: str) -> List[str]:
    """Extract SQL statements."""
    statements = []

    # Look for SQL keywords
    sql_pattern = r'(SELECT|INSERT|UPDATE|DELETE|EXECUTE|EXEC|CREATE|ALTER|DROP)[\s\S]{10,200}?(?:;|FROM|WHERE|INTO|SET|VALUES)'
    matches = re.findall(sql_pattern, text, re.IGNORECASE)

    for match in matches:
        stmt = ' '.join(match.split())  # Normalize whitespace
        if len(stmt) > 15:
            statements.append(stmt[:200])  # Limit length

    return list(set(statements))[:20]  # Return up to 20 unique statements


def extract_ips(text: str) -> List[str]:
    """Extract IP addresses."""
    pattern = r'\b(?:\d{1,3}\.){3}\d{1,3}\b'
    ips = re.findall(pattern, text)
    # Filter valid IPs
    valid_ips = []
    for ip in ips:
        parts = ip.split('.')
        if all(0 <= int(p) <= 255 for p in parts):
            valid_ips.append(ip)
    return list(set(valid_ips))


def extract_event_types(text: str) -> List[str]:
    """Extract event types."""
    event_types = set()

    # Known XEL event types
    known_types = [
        'audit_event', 'sql_batch_completed', 'sql_batch_starting',
        'rpc_completed', 'rpc_starting', 'login', 'logout',
        'attention', 'existing_connection', 'session_id',
        'audit_schema_version', 'event_sequence',
    ]

    for event_type in known_types:
        if event_type in text.lower():
            event_types.add(event_type)

    # Look for patterns like "event_*" or "*_event"
    pattern = r'\b\w+_event\b|\bevent_\w+\b'
    matches = re.findall(pattern, text, re.IGNORECASE)
    event_types.update(m.lower() for m in matches)

    return sorted(event_types)


def extract_timestamps(text: str) -> List[str]:
    """Extract timestamps."""
    timestamps = []

    # ISO format timestamps
    pattern = r'\d{4}-\d{2}-\d{2}[T\s]\d{2}:\d{2}:\d{2}(?:\.\d+)?(?:Z|[+-]\d{2}:\d{2})?'
    matches = re.findall(pattern, text)
    timestamps.extend(matches)

    return list(set(timestamps))[:50]  # Limit to 50


def extract_sessions(text: str) -> Dict[str, Any]:
    """Extract session information."""
    session_info = {}

    # Look for session IDs
    pattern = r'session[_\s]*id[:\s]*(\d+)'
    matches = re.findall(pattern, text, re.IGNORECASE)
    if matches:
        session_info['session_ids'] = list(set(matches))[:20]

    # Look for SqlDbAuditing sessions
    pattern = r'SqlDbAuditing[^<>]{0,100}'
    matches = re.findall(pattern, text)
    if matches:
        session_info['audit_sessions'] = list(set(matches))[:10]

    return session_info


def extract_users(text: str) -> List[str]:
    """Extract usernames."""
    users = set()

    # Look for common user patterns
    patterns = [
        r'user[:\s]+([a-zA-Z][a-zA-Z0-9_@\-\.]{2,50})',
        r'login[:\s]+([a-zA-Z][a-zA-Z0-9_@\-\.]{2,50})',
        r'USER_NAME\(\)[:\s]*([a-zA-Z][a-zA-Z0-9_@\-\.]{2,50})',
    ]

    for pattern in patterns:
        matches = re.findall(pattern, text, re.IGNORECASE)
        users.update(matches)

    # Common system users
    if 'sa' in text and 'sa' not in users:
        users.add('sa')
    if 'dbo' in text and 'dbo' not in users:
        users.add('dbo')

    # Filter out noise
    filtered = {u for u in users if 2 < len(u) < 100}
    return sorted(filtered)[:30]


def extract_applications(text: str) -> List[str]:
    """Extract application names."""
    apps = set()

    # Look for common application patterns
    patterns = [
        r'Core Microsoft SqlClient Data Provider',
        r'\.NET [^<>\s]{5,50}',
        r'ODBC Driver \d+',
        r'[A-Z][a-zA-Z0-9\s]{5,50}(?:Application|App|Client|Service)',
    ]

    for pattern in patterns:
        matches = re.findall(pattern, text)
        apps.update(matches)

    return list(apps)[:20]


def reconstruct_events(text: str, binary_data: bytes) -> List[Dict[str, Any]]:
    """
    Attempt to reconstruct event records from extracted data.
    """
    events = []

    # Strategy: Look for combinations of extracted data that likely represent events

    # Extract all the pieces
    servers = extract_servers(text)
    databases = extract_databases(text)
    sql_stmts = extract_sql(text)
    ips = extract_ips(text)
    timestamps = extract_timestamps(text)
    event_types = extract_event_types(text)

    # If we have SQL statements, create events for them
    for i, stmt in enumerate(sql_stmts):
        event = {
            'event_type': 'sql_execution',
            'statement': stmt,
        }

        # Try to associate with other data
        if databases:
            event['possible_database'] = databases[i % len(databases)]
        if servers:
            event['server'] = servers[0]
        if timestamps and i < len(timestamps):
            event['possible_timestamp'] = timestamps[i]

        events.append(event)

    # Create generic audit events for other extracted info
    if event_types:
        for event_type in event_types:
            event = {
                'event_type': event_type,
                'extracted_from': 'audit_metadata'
            }
            if servers:
                event['server'] = servers[0]
            events.append(event)

    return events[:50]  # Limit to 50 events


def parse_xel_file(file_path: str) -> Dict[str, Any]:
    """
    Main entry point to parse a real XEL file.
    """
    return extract_real_data_from_xel(file_path)


if __name__ == '__main__':
    import sys
    import json

    if len(sys.argv) < 2:
        print("Usage: python xel_real_parser.py <xel_file>")
        sys.exit(1)

    result = parse_xel_file(sys.argv[1])
    print(json.dumps(result, indent=2))
