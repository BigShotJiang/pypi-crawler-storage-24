"""
XEL Converter - Convert parsed XEL events to various human-readable formats.

Supported formats:
- JSON
- CSV
- Pretty text
- Markdown
"""

import json
import csv
from typing import List, Dict, Any, TextIO
from datetime import datetime


class XELConverter:
    """Converter for XEL events to various formats."""

    @staticmethod
    def to_json(events: List[Dict[str, Any]], indent: int = 2) -> str:
        """
        Convert events to JSON format.

        Args:
            events: List of event dictionaries
            indent: JSON indentation level

        Returns:
            JSON string
        """
        return json.dumps(events, indent=indent, default=str)

    @staticmethod
    def to_json_lines(events: List[Dict[str, Any]]) -> str:
        """
        Convert events to JSON Lines format (one JSON object per line).

        Args:
            events: List of event dictionaries

        Returns:
            JSON Lines string
        """
        lines = []
        for event in events:
            lines.append(json.dumps(event, default=str))
        return '\n'.join(lines)

    @staticmethod
    def to_csv(events: List[Dict[str, Any]]) -> str:
        """
        Convert events to CSV format.

        Args:
            events: List of event dictionaries

        Returns:
            CSV string
        """
        if not events:
            return ""

        # Flatten events and collect all possible fields
        flattened_events = []
        all_fields = set()

        for event in events:
            flat_event = XELConverter._flatten_dict(event)
            flattened_events.append(flat_event)
            all_fields.update(flat_event.keys())

        # Sort fields for consistent output
        fieldnames = sorted(all_fields)

        # Write to CSV
        import io
        output = io.StringIO()
        writer = csv.DictWriter(output, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(flattened_events)

        return output.getvalue()

    @staticmethod
    def to_text(events: List[Dict[str, Any]], verbose: bool = True) -> str:
        """
        Convert events to pretty text format.

        Args:
            events: List of event dictionaries
            verbose: Include all details

        Returns:
            Formatted text string
        """
        lines = []
        lines.append("=" * 80)
        lines.append(f"XEL Events Report - {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        lines.append(f"Total Events: {len(events)}")
        lines.append("=" * 80)
        lines.append("")

        for i, event in enumerate(events, 1):
            lines.append(f"Event #{i}: {event.get('name', 'Unknown')}")
            lines.append("-" * 80)

            if event.get('timestamp'):
                lines.append(f"  Timestamp: {event['timestamp']}")

            if verbose and event.get('data'):
                lines.append(f"  Data:")
                for key, value in event['data'].items():
                    lines.append(f"    {key}: {value}")

            if verbose and event.get('actions'):
                lines.append(f"  Actions:")
                for key, value in event['actions'].items():
                    lines.append(f"    {key}: {value}")

            if event.get('content'):
                lines.append(f"  Content: {event['content']}")

            lines.append("")

        return '\n'.join(lines)

    @staticmethod
    def to_markdown(events: List[Dict[str, Any]]) -> str:
        """
        Convert events to Markdown format.

        Args:
            events: List of event dictionaries

        Returns:
            Markdown string
        """
        lines = []
        lines.append("# XEL Events Report")
        lines.append("")
        lines.append(f"**Generated:** {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        lines.append(f"**Total Events:** {len(events)}")
        lines.append("")

        for i, event in enumerate(events, 1):
            lines.append(f"## Event {i}: {event.get('name', 'Unknown')}")
            lines.append("")

            if event.get('timestamp'):
                lines.append(f"**Timestamp:** `{event['timestamp']}`")
                lines.append("")

            if event.get('data'):
                lines.append("### Data")
                lines.append("")
                for key, value in event['data'].items():
                    lines.append(f"- **{key}:** `{value}`")
                lines.append("")

            if event.get('actions'):
                lines.append("### Actions")
                lines.append("")
                for key, value in event['actions'].items():
                    lines.append(f"- **{key}:** `{value}`")
                lines.append("")

            if event.get('content'):
                lines.append("### Content")
                lines.append("")
                lines.append(f"```")
                lines.append(str(event['content']))
                lines.append(f"```")
                lines.append("")

            lines.append("---")
            lines.append("")

        return '\n'.join(lines)

    @staticmethod
    def to_summary(events: List[Dict[str, Any]]) -> str:
        """
        Generate a summary of events.

        Args:
            events: List of event dictionaries

        Returns:
            Summary string
        """
        if not events:
            return "No events found."

        # Count events by name
        event_counts = {}
        for event in events:
            name = event.get('name', 'Unknown')
            event_counts[name] = event_counts.get(name, 0) + 1

        # Get time range
        timestamps = [e.get('timestamp', '') for e in events if e.get('timestamp')]
        time_range = "Unknown"
        if timestamps:
            try:
                timestamps.sort()
                time_range = f"{timestamps[0]} to {timestamps[-1]}"
            except:
                pass

        lines = []
        lines.append("XEL Events Summary")
        lines.append("=" * 80)
        lines.append(f"Total Events: {len(events)}")
        lines.append(f"Time Range: {time_range}")
        lines.append("")
        lines.append("Event Types:")
        for name, count in sorted(event_counts.items(), key=lambda x: x[1], reverse=True):
            lines.append(f"  {name}: {count}")

        return '\n'.join(lines)

    @staticmethod
    def _flatten_dict(d: Dict[str, Any], parent_key: str = '', sep: str = '_') -> Dict[str, Any]:
        """
        Flatten a nested dictionary.

        Args:
            d: Dictionary to flatten
            parent_key: Parent key prefix
            sep: Separator for nested keys

        Returns:
            Flattened dictionary
        """
        items = []
        for k, v in d.items():
            new_key = f"{parent_key}{sep}{k}" if parent_key else k
            if isinstance(v, dict):
                items.extend(XELConverter._flatten_dict(v, new_key, sep=sep).items())
            else:
                items.append((new_key, v))
        return dict(items)


def convert_file(input_path: str, output_path: str, format: str, **kwargs):
    """
    Convenience function to convert an XEL file to a specific format.

    Args:
        input_path: Path to input XEL file
        output_path: Path to output file
        format: Output format (json, jsonl, csv, text, markdown, summary)
        **kwargs: Additional arguments for conversion
    """
    from xel_parser import XELParser

    # Parse events
    parser = XELParser(input_path)
    events = list(parser.parse())

    # Convert to specified format
    converter = XELConverter()

    if format == 'json':
        output = converter.to_json(events, indent=kwargs.get('indent', 2))
    elif format == 'jsonl':
        output = converter.to_json_lines(events)
    elif format == 'csv':
        output = converter.to_csv(events)
    elif format == 'text':
        output = converter.to_text(events, verbose=kwargs.get('verbose', True))
    elif format == 'markdown' or format == 'md':
        output = converter.to_markdown(events)
    elif format == 'summary':
        output = converter.to_summary(events)
    else:
        raise ValueError(f"Unsupported format: {format}")

    # Write output
    with open(output_path, 'w', encoding='utf-8') as f:
        f.write(output)

    return len(events)
