# SQL XEL Parser

Parse and analyze SQL Server Extended Events (.xel) files without requiring SQL Server.

Tested with **671 production Azure SQL audit log files**. Works cross-platform (Linux, macOS, Windows).

## Features

✅ **No SQL Server Required** - Parse binary XEL files using UTF-16 extraction
✅ **Multiple Export Formats** - JSON, JSON Lines, CSV, Text, Markdown, Summary
✅ **Advanced Filtering** - By event name, time range, field values, regex search
✅ **Analysis Tools** - Aggregation, grouping, counting, top-N queries
✅ **Batch Processing** - Recursive directory processing with 671+ file support
✅ **Python API** - Use programmatically in your own scripts
✅ **CLI Tool** - Powerful command-line interface

## Installation

```bash
pip install sql-xel-parser
```

## Quick Start

### Command Line

```bash
# Get summary of XEL files
sql-xel-parser audit.xel -f summary

# Export to JSON
sql-xel-parser audit.xel -o events.json

# Process entire directory
sql-xel-parser /path/to/logs/ -r -f summary

# Search for security events
sql-xel-parser audit.xel --search "fail|error|denied" -o security.json

# Export to CSV for Excel
sql-xel-parser audit.xel -f csv -o export.csv
```

### Python API

```python
from sql_xel_parser import XELParser, XELAnalyzer, XELConverter

# Parse XEL file
parser = XELParser('audit.xel')
events = list(parser.parse())

# Analyze and filter
analyzer = XELAnalyzer(events)
failed_logins = analyzer.search('(?i)fail|error')

# Export results
converter = XELConverter()
json_output = converter.to_json(failed_logins.get_events(), indent=2)
```

## What Gets Extracted

**Successfully extracted:**
- Event names and types
- Timestamps
- SQL statements and error messages
- Server names, databases, IPs
- Usernames and session IDs
- All text-based audit data

**May be incomplete:**
- Pure numeric fields without string representation
- Binary data types (BLOB)
- Complex nested binary structures

Uses UTF-16 string extraction method - ideal for text-heavy events like audit logs and security monitoring.

## Use Cases

- **Azure SQL Audit Logs** - Primary use case, tested with production data
- **Security & Compliance** - Track access patterns and failed logins
- **SQL Server Extended Events** - Parse system_health, query tracking
- **Automated Monitoring** - CI/CD pipelines and scheduled analysis
- **SIEM Integration** - Export to Splunk, ELK, or other log analysis tools

## Documentation

- [Full Documentation](https://github.com/josephvolmer/sql-xel-parser)
- [Quick Start Guide](https://github.com/josephvolmer/sql-xel-parser/blob/main/QUICKSTART.md)
- [Advanced Usage](https://github.com/josephvolmer/sql-xel-parser/tree/main/docs)
- [Python API Examples](https://github.com/josephvolmer/sql-xel-parser/tree/main/examples)

## Requirements

- Python 3.8+
- python-dateutil

## License

MIT License

## Links

- **GitHub**: https://github.com/josephvolmer/sql-xel-parser
- **Issues**: https://github.com/josephvolmer/sql-xel-parser/issues
- **Documentation**: https://github.com/josephvolmer/sql-xel-parser/blob/main/README.md
