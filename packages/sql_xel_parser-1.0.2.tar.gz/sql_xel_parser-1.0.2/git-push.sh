#!/bin/bash
# Helper script to push using the stored PAT token
# Usage: ./git-push.sh [branch]

BRANCH="${1:-main}"
TOKEN=$(cat .git/credentials | grep -o 'github_pat_[^@]*')

if [ -z "$TOKEN" ]; then
    echo "Error: No token found in .git/credentials"
    exit 1
fi

# Temporarily set remote URL with token
git remote set-url origin "https://${TOKEN}@github.com/josephvolmer/sql-xel-parser.git"

# Push
git push origin "$BRANCH"
EXIT_CODE=$?

# Clean up: restore remote URL without token
git remote set-url origin "https://github.com/josephvolmer/sql-xel-parser.git"

exit $EXIT_CODE
