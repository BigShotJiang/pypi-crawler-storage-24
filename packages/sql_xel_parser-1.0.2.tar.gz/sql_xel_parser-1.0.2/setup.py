"""Setup script for XEL Parser."""

from setuptools import setup, find_packages
from pathlib import Path

# Read the PyPI README file
readme_file = Path(__file__).parent / 'PYPI.md'
long_description = readme_file.read_text(encoding='utf-8') if readme_file.exists() else ''

# Read requirements
requirements_file = Path(__file__).parent / 'requirements.txt'
if requirements_file.exists():
    requirements = [
        line.strip() for line in requirements_file.read_text().splitlines()
        if line.strip() and not line.startswith('#')
    ]
else:
    requirements = ['python-dateutil>=2.8.0']

setup(
    name='sql-xel-parser',
    use_scm_version=True,
    setup_requires=['setuptools_scm'],
    description='Parse and analyze SQL Server Extended Events (.xel) files',
    long_description=long_description,
    long_description_content_type='text/markdown',
    author='SQL XEL Parser Contributors',
    author_email='',
    url='https://github.com/josephvolmer/sql-xel-parser',
    packages=find_packages(exclude=['tests', 'docs', 'examples']),
    python_requires='>=3.8',
    install_requires=requirements,
    entry_points={
        'console_scripts': [
            'sql-xel-parser=sql_xel_parser.cli:main',
        ],
    },
    classifiers=[
        'Development Status :: 4 - Beta',
        'Intended Audience :: Developers',
        'Intended Audience :: System Administrators',
        'Topic :: Database',
        'Topic :: System :: Logging',
        'Topic :: System :: Monitoring',
        'Programming Language :: Python :: 3',
        'Programming Language :: Python :: 3.8',
        'Programming Language :: Python :: 3.9',
        'Programming Language :: Python :: 3.10',
        'Programming Language :: Python :: 3.11',
        'Programming Language :: Python :: 3.12',
        'License :: OSI Approved :: MIT License',
        'Operating System :: OS Independent',
    ],
    keywords='xel sql-server extended-events audit-logs parser',
    project_urls={
        'Documentation': 'https://github.com/josephvolmer/sql-xel-parser/blob/main/README.md',
        'Source': 'https://github.com/josephvolmer/sql-xel-parser',
        'Bug Reports': 'https://github.com/josephvolmer/sql-xel-parser/issues',
    },
)
