# Quick Start Guide

## Installation

```bash
# Install from source
cd xel-log-parse
pip install -e .

# Or from PyPI
pip install sql-xel-parser

# Verify installation
sql-xel-parser --version
```

## Basic Usage

### Parse a folder of XEL files
```bash
# Get summary of all XEL files in a directory (recursively)
sql-xel-parser data/sql-ptfm-prod-westus3 -r -f summary

# Parse all files and output JSON
sql-xel-parser data/sql-ptfm-prod-westus3 -r -o output.json

# Parse and output as readable text
sql-xel-parser data/sql-ptfm-prod-westus3 -r -f text -o output.txt
```

### Parse a single XEL file
```bash
# Convert to JSON
sql-xel-parser input.xel -o output.json

# Convert to CSV
sql-xel-parser input.xel -f csv -o output.csv

# View summary
sql-xel-parser input.xel -f summary
```

### Common Scenarios

**Get file statistics:**
```bash
sql-xel-parser data/sql-ptfm-prod-westus3 -r --stats
```

**Count events by type:**
```bash
sql-xel-parser data/sql-ptfm-prod-westus3 -r --count-by name
```

**Search for specific content:**
```bash
sql-xel-parser input.xel --search "error" -o errors.json
```

**Filter events:**
```bash
sql-xel-parser input.xel --filter-name "sql_batch_completed" -o filtered.json
```

**Process limited number of events:**
```bash
sql-xel-parser input.xel --limit 100 -f summary
```

## Important Note About SQL Server Binary XEL Files

If your XEL files are from SQL Server (like the ones in `data/sql-ptfm-prod-westus3`), they use a binary format that requires SQL Server to fully parse. This tool can:

✅ Extract metadata and basic information from binary XEL files
✅ Show file structure and configuration
✅ Extract embedded strings (IP addresses, server names, etc.)

❌ Full event parsing requires SQL Server

**This tool parses XEL files directly:**

Works with:
- SQL Server/Azure SQL binary XEL files (tested with Azure SQL audit logs)
- XML-based XEL exports
- Any Extended Events files with text-based data

See [Advanced Documentation](docs/) for technical details on what gets extracted.

## Getting XEL Files

To use this tool, you need real SQL Server Extended Events files:

1. **Azure SQL Database**: Download audit logs from Azure Storage
2. **SQL Server**: Find XEL files in your SQL Server log directory
3. **Extended Events Sessions**: Export from SQL Server Management Studio

## Python API

```python
from sql_xel_parser import XELParser, XELAnalyzer, XELConverter

# Parse file
parser = XELParser('input.xel')
events = list(parser.parse())

# Analyze
analyzer = XELAnalyzer(events)
filtered = analyzer.filter_by_name('error').filter_by_field('severity', 10, 'gt')

# Convert
converter = XELConverter()
json_output = converter.to_json(filtered.get_events())
print(json_output)
```

## Getting Help

```bash
sql-xel-parser --help
```

## Next Steps

- Read `README.md` for full documentation
- See [Advanced Documentation](docs/) for technical details
- Run `python examples/example_usage.py <xel_file>` to see API examples

## Common Issues

**"No events found"**: File may be empty or corrupted. Verify it's a valid XEL file and check file permissions.

**Memory issues with large files**: Use `--limit` to process fewer events at a time.

**Permission errors**: Make sure you have read access to the XEL files.
