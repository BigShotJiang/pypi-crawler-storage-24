# Advanced Documentation

This guide covers advanced usage, technical details, and best practices for the SQL XEL Parser.

## Table of Contents

- [How the Parser Works](#how-the-parser-works)
- [Working with Azure SQL Audit Logs](#working-with-azure-sql-audit-logs)
- [Working with SQL Server Extended Events](#working-with-sql-server-extended-events)
- [Advanced Filtering and Analysis](#advanced-filtering-and-analysis)
- [Python API for Custom Analysis](#python-api-for-custom-analysis)
- [Integration with Other Tools](#integration-with-other-tools)
- [Performance Tips](#performance-tips)
- [Troubleshooting](#troubleshooting)
- [Limitations and Alternatives](#limitations-and-alternatives)

---

## How the Parser Works

This tool parses SQL Server Extended Events (.xel) files **without requiring SQL Server**. It uses UTF-16 string extraction from the binary format to reconstruct event data.

### What Gets Extracted

**✅ Extracted Successfully:**
- Event names and types
- Timestamps
- Text-based field values (SQL statements, error messages, etc.)
- Server names and instance information
- Database names
- IP addresses and client information
- Application names
- Session IDs and connection metadata
- Usernames and authentication details
- String-based audit data

**⚠️ May Be Incomplete:**
- Pure numeric fields without text representation (e.g., raw duration values stored only as binary integers)
- Binary data types (BLOB, binary columns)
- Complex nested structures that don't have string representations
- Some proprietary SQL Server-specific data encodings

**Best for:**
- Azure SQL Database audit logs (tested with 671 production files)
- Security and compliance auditing
- Access pattern analysis
- SQL statement tracking
- Error and event monitoring
- Any XEL files where text data is the primary content

---

## Working with Azure SQL Audit Logs

Azure SQL audit logs are the ideal use case for this tool. They contain primarily text-based data and work excellently with UTF-16 extraction.

### Typical Directory Structure
```
servername/
  database/
    SqlDbAuditing_ServerAudit/
      2024-01-15/
        *.xel
```

### Quick Analysis Workflow

**1. Get Overview:**
```bash
sql-xel-parser /path/to/audit/logs -r -f summary
```

**2. Extract All Events:**
```bash
sql-xel-parser /path/to/audit/logs -r -o audit_events.json
```

**3. Search for Security Events:**
```bash
sql-xel-parser /path/to/audit/logs -r --search "(?i)fail|error|denied" -o security_events.json
```

**4. Analyze by Database:**
```bash
sql-xel-parser /path/to/audit/logs -r --count-by name -f markdown -o report.md
```

**5. Export to CSV for Excel:**
```bash
sql-xel-parser /path/to/audit/logs -r --limit 10000 -f csv -o audit_export.csv
```

---

## Working with SQL Server Extended Events

For SQL Server Extended Events sessions (system_health, query tracking, etc.), the tool works well for events that contain text data.

### Example: Analyzing System Health Events

```bash
# Linux
sql-xel-parser /var/opt/mssql/log/system_health*.xel -r -f summary

# Windows
sql-xel-parser "C:\Program Files\Microsoft SQL Server\MSSQL15.MSSQLSERVER\MSSQL\Log\system_health*.xel" -r -f summary
```

### Example: Query Performance Analysis

```bash
# Extract slow queries
sql-xel-parser queries.xel --search "SELECT.*FROM" --limit 1000 -o slow_queries.json
```

---

## Advanced Filtering and Analysis

### Time-Based Analysis

```bash
# Events within specific time range
sql-xel-parser audit.xel \
  --filter-time-start "2024-01-01 00:00:00" \
  --filter-time-end "2024-01-31 23:59:59" \
  -o january_events.json
```

### Multi-Criteria Filtering

```bash
# Chain multiple filters
sql-xel-parser audit.xel \
  --filter-name ".*login.*" \
  --search "failed" \
  --limit 100 \
  -f text -o failed_logins.txt
```

### Aggregation and Grouping

```bash
# Count events by type
sql-xel-parser audit.xel -r --count-by name

# Group by database
sql-xel-parser audit.xel -r --group-by "data.database_name"

# Top 20 most frequent events
sql-xel-parser audit.xel -r --top-n "name:20"
```

### Large File Processing

For very large XEL files or directories:

```bash
# Process incrementally
sql-xel-parser large_directory/ -r --limit 10000 -f summary

# Export in batches
sql-xel-parser large_file.xel --limit 50000 -o batch1.json
```

---

## Python API for Custom Analysis

For advanced analysis, use the Python API directly:

```python
from sql_xel_parser import XELParser, XELAnalyzer, XELConverter

# Parse XEL file
parser = XELParser('/path/to/audit.xel')
events = list(parser.parse())

# Analyze
analyzer = XELAnalyzer(events)

# Extract unique databases
databases = set()
for event in events:
    if 'database_name' in event.get('data', {}):
        databases.add(event['data']['database_name'])
    if 'database_name' in event.get('actions', {}):
        databases.add(event['actions']['database_name'])

print(f"Found {len(databases)} unique databases: {databases}")

# Search for failed operations
failed = analyzer.search('(?i)fail|error|denied')
print(f"Security events: {len(failed.get_events())}")

# Export results
converter = XELConverter()
json_output = converter.to_json(failed.get_events(), indent=2)
with open('security_report.json', 'w') as f:
    f.write(json_output)
```

See the [`examples/`](../examples/) directory for more comprehensive Python API examples.

---

## Integration with Other Tools

### Export to SIEM or Log Analysis

```bash
# JSON Lines format (one event per line) for log ingestion
sql-xel-parser audit.xel -r -f jsonl -o events.jsonl

# Can then pipe to tools like jq, Splunk, ELK, etc.
cat events.jsonl | jq '.[] | select(.name | contains("login"))'
```

### Automated Monitoring

```bash
#!/bin/bash
# Daily audit log analysis script

DATE=$(date +%Y-%m-%d)
AUDIT_PATH="/mnt/azure-audit-logs/$DATE"

# Extract and analyze
sql-xel-parser "$AUDIT_PATH" -r \
  --search "(?i)fail|error" \
  -o "/reports/security-events-$DATE.json"

# Send alert if security events found
if [ -s "/reports/security-events-$DATE.json" ]; then
    echo "Security events detected on $DATE" | mail -s "Audit Alert" security@company.com
fi
```

---

## Performance Tips

1. **Use Filters Early**: Apply `--filter-name` or `--search` to reduce data volume before processing
2. **Limit Output**: Use `--limit` for initial exploration of large datasets
3. **Recursive Processing**: `-r` flag efficiently processes entire directory trees
4. **Format Choice**: JSON Lines (`-f jsonl`) is faster for very large outputs
5. **Parallel Processing**: Process different date ranges separately and merge results

---

## Troubleshooting

### No Events Found

**Cause**: The XEL file may be empty, corrupted, or in an unexpected format.

**Solutions**:
- Verify the file is not zero bytes: `ls -lh file.xel`
- Check file permissions: `chmod +r file.xel`
- Try with `--verbose` flag for more details
- Verify it's actually an XEL file from SQL Server/Azure SQL

### Incomplete Data Extraction

**Cause**: Some fields contain only binary numeric data without string representations.

**What to do**:
- Text-based fields (statements, names, errors) will extract correctly
- Numeric-only fields may not appear in output
- This is expected behavior with UTF-16 extraction method
- For critical numeric fields, consider the data complete enough for audit purposes

### Memory Issues with Large Files

**Cause**: Loading entire large XEL files into memory.

**Solutions**:
```bash
# Process in chunks
sql-xel-parser large.xel --limit 10000 -o chunk1.json

# Use summary format instead
sql-xel-parser large.xel -f summary

# Filter before parsing
sql-xel-parser large.xel --filter-name "specific_event" -o filtered.json
```

### Parser Performance

**Cause**: Processing many files or very large files.

**Optimization**:
```bash
# Process only recent files
find /audit/logs -name "*.xel" -mtime -7 | xargs sql-xel-parser -r -f summary

# Use specific date ranges
sql-xel-parser /audit/logs/2024-01-15/ -r -o daily_report.json
```

---

## Limitations and Alternatives

### When This Tool Works Best
- Azure SQL Database audit logs
- Text-heavy Extended Events
- Security and compliance auditing
- Environments without SQL Server access
- Automated pipeline processing
- Cross-platform analysis (Linux, macOS, Windows)

### When You Might Need SQL Server
- If you need guaranteed 100% field extraction including all binary data
- If you're analyzing custom Extended Events with complex binary payloads
- If you have SQL Server available and need complete data fidelity

For SQL Server users, the tool still provides value for:
- Quick analysis without database connectivity
- CI/CD pipelines and automation
- Cross-platform compatibility
- Export to various formats not natively supported

---

## Additional Resources

- [Main Documentation](../README.md) - Feature overview and CLI usage
- [Quick Start Guide](../QUICKSTART.md) - Get started quickly
- [Installation Guide](../INSTALL.md) - Detailed installation instructions
- [Python API Examples](../examples/) - Comprehensive code examples
- [SQL Server Extended Events Documentation](https://docs.microsoft.com/en-us/sql/relational-databases/extended-events/extended-events)
- [Azure SQL Auditing](https://docs.microsoft.com/en-us/azure/azure-sql/database/auditing-overview)

## Publishing to PyPI

For maintainers publishing new versions:
- [GitHub Actions Workflow](../.github/workflows/publish-to-pypi.yml) - Automated publishing
- [OIDC Setup Guide](../.github/PYPI_OIDC_SETUP.md) - PyPI trusted publishing configuration
