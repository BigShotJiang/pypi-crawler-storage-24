# Installation Guide

## Quick Install

```bash
# Install from source
pip install -e .

# Or install from PyPI
pip install sql-xel-parser
```

## Usage After Installation

After installation, you can use the `sql-xel-parser` command directly:

```bash
sql-xel-parser --help
sql-xel-parser input.xel -f json -o output.json
```

## Installation Methods

### Method 1: Install from Source (Development)

```bash
# Clone or navigate to the project directory
cd xel-log-parse

# Install in development mode
pip install -e .

# Test installation
sql-xel-parser --version
```

### Method 2: Install from Source (Standard)

```bash
cd xel-log-parse
pip install .
```

### Method 3: Install from PyPI

```bash
pip install sql-xel-parser
```

### Method 4: Install with pipx (Isolated)

```bash
# Install pipx if you don't have it
python3 -m pip install --user pipx
python3 -m pipx ensurepath

# Install sql-xel-parser in isolated environment
pipx install /path/to/xel-log-parse

# Now sql-xel-parser command is globally available
sql-xel-parser --help
```

## Verify Installation

```bash
# Check if package is installed
pip show sql-xel-parser

# Check version
sql-xel-parser --version

# Test with help
sql-xel-parser --help

# Test with real data
sql-xel-parser data/sql-ptfm-prod-westus3 -r --limit 5 -f summary
```

## Command Availability

The `sql-xel-parser` command will be available if your Python's `bin` directory is in your PATH:

```bash
# Check if command is available
which sql-xel-parser

# If not found, you can:
# 1. Use: sql-xel-parser (works everywhere)
# 2. Add Python bin to PATH
# 3. Use the full path: /path/to/python/bin/sql-xel-parser
```

### Adding Python bin to PATH

**macOS/Linux:**
```bash
# Find your Python bin directory
python -c "import sys; import os; print(os.path.dirname(sys.executable))"

# Add to your ~/.bashrc or ~/.zshrc
export PATH="/path/to/python/bin:$PATH"

# Reload shell
source ~/.bashrc  # or source ~/.zshrc
```

**Windows:**
```cmd
# Add to PATH in System Environment Variables
# Or use: sql-xel-parser
```

## Dependencies

- Python 3.8 or higher
- python-dateutil (automatically installed)

## Uninstall

```bash
pip uninstall sql-xel-parser
```

## Development Setup

```bash
# Clone repository
git clone https://github.com/josephvolmer/sql-xel-parser.git
cd sql-xel-parser

# Create virtual environment
python3 -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

# Install in development mode with dependencies
pip install -e .

# Run tests
sql-xel-parser data/test.xel -f summary
```

## Troubleshooting

### Command not found: sql-xel-parser

**Solution**: Use `sql-xel-parser` instead, or add Python's bin directory to your PATH.

### ImportError: No module named 'xel_parser'

**Solution**: Make sure you've installed the package:
```bash
pip install -e .
```

### Permission denied when installing

**Solution**: Use `--user` flag:
```bash
pip install --user -e .
```

Or use a virtual environment:
```bash
python3 -m venv venv
source venv/bin/activate
pip install -e .
```

## Quick Start Examples

```bash
# After installation, try these commands:

# Parse single file
sql-xel-parser data/sql-ptfm-prod-westus3/master/SqlDbAuditing_ServerAudit/2026-03-03/19_00_56_668_0.xel -f summary

# Parse entire directory
sql-xel-parser data/sql-ptfm-prod-westus3 -r -f summary

# Export to JSON
sql-xel-parser data/sql-ptfm-prod-westus3 -r --limit 100 -o audit_data.json

# Search for specific content
sql-xel-parser data/sql-ptfm-prod-westus3 -r --search "Payments"

# Count events by type
sql-xel-parser data/sql-ptfm-prod-westus3 -r --count-by name
```

## Platform-Specific Notes

### macOS
- Uses system Python or Homebrew Python
- Virtual environments recommended
- Use `python3` and `pip3` commands

### Linux
- Usually has Python pre-installed
- May need to install `python3-venv` package
- Use `python3` and `pip3` commands

### Windows
- Install Python from python.org
- Use `python` and `pip` commands
- May need to run as Administrator for system-wide install

## Support

For issues or questions:
- Check the [README.md](README.md) for usage examples
- See [QUICKSTART.md](QUICKSTART.md) for quick start guide
- Report bugs at: https://github.com/josephvolmer/sql-xel-parser/issues
