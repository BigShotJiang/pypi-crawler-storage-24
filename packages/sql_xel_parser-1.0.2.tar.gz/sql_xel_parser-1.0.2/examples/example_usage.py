#!/usr/bin/env python3
"""
Example usage of the SQL XEL Parser library.

This script demonstrates how to use the parser programmatically for real-world
scenarios like analyzing Azure SQL audit logs and SQL Server Extended Events.
"""

import sys
from pathlib import Path
from sql_xel_parser import XELParser, XELAnalyzer, XELConverter


def example_parse_single_file(xel_file_path):
    """Example 1: Parse a single XEL file."""
    print("=" * 80)
    print("Example 1: Parse Single XEL File")
    print("=" * 80)

    parser = XELParser(xel_file_path)
    events = list(parser.parse())

    print(f"\nFile: {xel_file_path}")
    print(f"Total events parsed: {len(events)}")

    if events:
        print("\nFirst event structure:")
        first_event = events[0]
        print(f"  Name: {first_event.get('name')}")
        print(f"  Timestamp: {first_event.get('timestamp')}")
        print(f"  Data keys: {list(first_event.get('data', {}).keys())}")
        if first_event.get('actions'):
            print(f"  Action keys: {list(first_event.get('actions', {}).keys())}")

    return events


def example_parse_directory(directory_path):
    """Example 2: Parse multiple XEL files from a directory."""
    print("\n" + "=" * 80)
    print("Example 2: Parse Directory of XEL Files")
    print("=" * 80)

    all_events = []
    xel_files = list(Path(directory_path).rglob("*.xel"))

    print(f"\nFound {len(xel_files)} XEL files")

    for xel_file in xel_files[:5]:  # Limit to first 5 for demo
        parser = XELParser(str(xel_file))
        events = list(parser.parse())
        all_events.extend(events)
        print(f"  {xel_file.name}: {len(events)} events")

    print(f"\nTotal events from all files: {len(all_events)}")
    return all_events


def example_extract_metadata(events):
    """Example 3: Extract metadata from audit logs."""
    print("\n" + "=" * 80)
    print("Example 3: Extract Metadata")
    print("=" * 80)

    analyzer = XELAnalyzer(events)

    # Get statistics
    stats = analyzer.get_stats()
    print(f"\nTotal events: {stats['total_events']}")
    print(f"Unique event types: {len(stats['event_types'])}")

    # Extract unique values from common fields
    databases = set()
    servers = set()
    applications = set()

    for event in events:
        data = event.get('data', {})
        actions = event.get('actions', {})

        if 'database_name' in data:
            databases.add(data['database_name'])
        if 'database_name' in actions:
            databases.add(actions['database_name'])
        if 'server_name' in data:
            servers.add(data['server_name'])
        if 'application_name' in actions:
            applications.add(actions['application_name'])

    print(f"\nExtracted metadata:")
    print(f"  Databases: {databases or 'None found'}")
    print(f"  Servers: {servers or 'None found'}")
    print(f"  Applications: {applications or 'None found'}")


def example_filter_audit_events(events):
    """Example 4: Filter for specific audit events."""
    print("\n" + "=" * 80)
    print("Example 4: Filter Audit Events")
    print("=" * 80)

    analyzer = XELAnalyzer(events)

    # Count events by type
    event_counts = analyzer.count_by('name')
    print("\nEvent types found:")
    for event_type, count in list(event_counts.items())[:10]:
        print(f"  {event_type}: {count}")

    # Filter for specific event types (common in Azure SQL audit logs)
    audit_events = analyzer.filter_by_name('.*audit.*')
    print(f"\nAudit-related events: {len(audit_events.get_events())}")

    return audit_events


def example_search_patterns(events):
    """Example 5: Search for patterns in events."""
    print("\n" + "=" * 80)
    print("Example 5: Search for Patterns")
    print("=" * 80)

    analyzer = XELAnalyzer(events)

    # Search for SQL operations
    search_terms = ['SELECT', 'INSERT', 'UPDATE', 'DELETE', 'CREATE', 'DROP']

    print("\nSearching for SQL operations:")
    for term in search_terms:
        results = analyzer.search(term)
        count = len(results.get_events())
        if count > 0:
            print(f"  Events with '{term}': {count}")

    # Regex search for IP addresses
    ip_results = analyzer.search(r'\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}')
    print(f"\nEvents with IP addresses: {len(ip_results.get_events())}")


def example_time_based_analysis(events):
    """Example 6: Analyze events by time."""
    print("\n" + "=" * 80)
    print("Example 6: Time-Based Analysis")
    print("=" * 80)

    analyzer = XELAnalyzer(events)
    stats = analyzer.get_stats()

    if stats.get('time_range'):
        print(f"\nTime range of events:")
        print(f"  Start: {stats['time_range']['start']}")
        print(f"  End: {stats['time_range']['end']}")
        print(f"  Duration: {stats['time_range']['duration']}")

    # Group events by hour (if timestamps are available)
    events_by_hour = {}
    for event in events:
        timestamp = event.get('timestamp')
        if timestamp:
            # Extract hour from timestamp
            if isinstance(timestamp, str):
                hour = timestamp.split('T')[1][:2] if 'T' in timestamp else None
                if hour:
                    events_by_hour[hour] = events_by_hour.get(hour, 0) + 1

    if events_by_hour:
        print("\nEvents per hour:")
        for hour in sorted(events_by_hour.keys()):
            print(f"  Hour {hour}: {events_by_hour[hour]} events")


def example_export_formats(events):
    """Example 7: Export to different formats."""
    print("\n" + "=" * 80)
    print("Example 7: Export to Different Formats")
    print("=" * 80)

    converter = XELConverter()
    sample_events = events[:3]  # Use first 3 events for demo

    # JSON format
    json_output = converter.to_json(sample_events, indent=2)
    print(f"\n✓ JSON format: {len(json_output)} characters")

    # JSON Lines format (one event per line)
    jsonl_output = converter.to_json_lines(sample_events)
    print(f"✓ JSON Lines format: {len(jsonl_output.splitlines())} lines")

    # CSV format
    csv_output = converter.to_csv(sample_events)
    print(f"✓ CSV format: {len(csv_output.splitlines())} rows")

    # Text format
    text_output = converter.to_text(sample_events, verbose=True)
    print(f"✓ Text format: {len(text_output)} characters")

    # Markdown format
    md_output = converter.to_markdown(sample_events)
    print(f"✓ Markdown format: {len(md_output)} characters")

    # Summary format
    summary = converter.to_summary(events)
    print(f"\n{summary}")


def example_advanced_filtering(events):
    """Example 8: Advanced filtering techniques."""
    print("\n" + "=" * 80)
    print("Example 8: Advanced Filtering")
    print("=" * 80)

    analyzer = XELAnalyzer(events)

    # Chain multiple filters
    filtered = (analyzer
                .filter_by_name('.*sql.*')  # Events with 'sql' in name
                .custom_filter(lambda e: len(str(e)) > 100))  # Larger events

    print(f"\nChained filters result: {len(filtered.get_events())} events")

    # Group and aggregate
    groups = analyzer.group_by('name')
    print(f"\nGrouped by event name: {len(groups)} groups")

    # Get top N most frequent events
    top_events = analyzer.top_n('name', 5)
    print("\nTop 5 most frequent events:")
    for event_name, count in top_events:
        print(f"  {event_name}: {count}")


def example_real_world_scenario(xel_file_path):
    """Example 9: Real-world scenario - Audit log analysis."""
    print("\n" + "=" * 80)
    print("Example 9: Real-World Scenario - Security Audit")
    print("=" * 80)

    # Parse the file
    parser = XELParser(xel_file_path)
    events = list(parser.parse())

    if not events:
        print("No events found.")
        return

    analyzer = XELAnalyzer(events)

    # Security-focused analysis
    print("\nSecurity Analysis Report:")
    print("-" * 40)

    # 1. Look for failed login attempts
    failed_logins = analyzer.search('(?i)fail|error|denied')
    print(f"Potential security events: {len(failed_logins.get_events())}")

    # 2. Count unique users/connections
    stats = analyzer.get_stats()
    print(f"Total events analyzed: {stats['total_events']}")

    # 3. Export to JSON for further processing
    converter = XELConverter()
    json_output = converter.to_json(events[:10], indent=2)

    print(f"\nSample JSON export (first 10 events):")
    print(json_output[:500] + "..." if len(json_output) > 500 else json_output)


def main():
    """Run examples based on provided file or directory."""

    if len(sys.argv) < 2:
        print("SQL XEL Parser - Usage Examples")
        print("=" * 80)
        print("\nUsage:")
        print("  python example_usage.py <xel_file_or_directory>")
        print("\nExamples:")
        print("  python example_usage.py audit_log.xel")
        print("  python example_usage.py /path/to/xel/files/")
        print("\nThis script demonstrates the full capabilities of the SQL XEL Parser:")
        print("  - Parsing single files and directories")
        print("  - Extracting metadata (servers, databases, IPs)")
        print("  - Filtering and searching events")
        print("  - Time-based analysis")
        print("  - Exporting to multiple formats")
        print("  - Real-world security audit scenarios")
        return

    input_path = sys.argv[1]
    path = Path(input_path)

    try:
        if path.is_file():
            # Single file examples
            print("Running examples with single XEL file...\n")
            events = example_parse_single_file(input_path)

        elif path.is_dir():
            # Directory examples
            print("Running examples with directory of XEL files...\n")
            events = example_parse_directory(input_path)

        else:
            print(f"Error: {input_path} is not a valid file or directory")
            return

        if not events:
            print("\n⚠ No events found. XEL file may be empty or in unsupported format.")
            return

        # Run all analysis examples
        example_extract_metadata(events)
        example_filter_audit_events(events)
        example_search_patterns(events)
        example_time_based_analysis(events)
        example_export_formats(events)
        example_advanced_filtering(events)

        if path.is_file():
            example_real_world_scenario(input_path)

        print("\n" + "=" * 80)
        print("✓ All examples completed successfully!")
        print("=" * 80)
        print("\nNext steps:")
        print("  - Try the CLI: sql-xel-parser --help")
        print("  - Read the docs: README.md")
        print("  - Explore more: ADVANCED_USAGE.md")

    except Exception as e:
        print(f"\n❌ Error: {e}")
        import traceback
        traceback.print_exc()
        print("\nTip: Make sure the XEL file is a valid SQL Server Extended Events file")


if __name__ == '__main__':
    main()
