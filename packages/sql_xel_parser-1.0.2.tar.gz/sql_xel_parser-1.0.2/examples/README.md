# Examples

This directory contains a comprehensive example demonstrating how to use the SQL XEL Parser Python API for real-world scenarios.

## example_usage.py

A complete, production-ready example showing all capabilities of the SQL XEL Parser library.

### Features Demonstrated

1. **Parse Single Files** - Basic XEL file parsing
2. **Parse Directories** - Batch processing multiple XEL files
3. **Extract Metadata** - Extract servers, databases, applications from audit logs
4. **Filter Events** - Filter by event type, fields, patterns
5. **Search Patterns** - Search for SQL operations, IP addresses, keywords
6. **Time-Based Analysis** - Analyze events by time range and hour
7. **Export Formats** - Convert to JSON, JSON Lines, CSV, Text, Markdown
8. **Advanced Filtering** - Chain filters, group by fields, get top N events
9. **Security Audit Scenario** - Real-world security analysis example

### Usage

```bash
# With a single XEL file
python example_usage.py path/to/audit.xel

# With a directory of XEL files
python example_usage.py path/to/xel/directory/

# Show help
python example_usage.py
```

### Example Output

The script will demonstrate:
- Parsing and extracting event data
- Finding unique servers, databases, and applications
- Searching for SQL operations (SELECT, INSERT, UPDATE, etc.)
- Exporting to multiple formats
- Security-focused analysis

### Real-World Use Cases

**Azure SQL Audit Log Analysis:**
```bash
python example_usage.py /path/to/azure/audit/logs/
```

**SQL Server Extended Events:**
```bash
python example_usage.py /var/opt/mssql/log/system_health.xel
```

**Security Audit:**
```bash
python example_usage.py audit_logs/ > security_report.txt
```

### Integration Example

Use this as a starting point for your own scripts:

```python
from sql_xel_parser import XELParser, XELAnalyzer, XELConverter

# Parse XEL file
parser = XELParser('audit.xel')
events = list(parser.parse())

# Analyze
analyzer = XELAnalyzer(events)
failed_logins = analyzer.search('(?i)fail|error|denied')

# Export results
converter = XELConverter()
json_output = converter.to_json(failed_logins.get_events(), indent=2)

# Save to file
with open('security_events.json', 'w') as f:
    f.write(json_output)
```

## Getting XEL Files

To run these examples, you need real SQL Server Extended Events files:

1. **Azure SQL Database** - Download audit logs from Azure Storage
2. **SQL Server** - Find XEL files in your SQL Server log directory:
   - Windows: `C:\Program Files\Microsoft SQL Server\MSSQL*\MSSQL\Log\`
   - Linux: `/var/opt/mssql/log/`
3. **Extended Events Sessions** - Export from SQL Server Management Studio

See the main [README.md](../README.md) and [Advanced Documentation](../docs/) for more details.

## Next Steps

After exploring the example:
- Try the CLI tool: `sql-xel-parser --help`
- Read the full documentation: [../README.md](../README.md)
- Learn advanced techniques: [../docs/](../docs/)
