#!/bin/bash
# Helper script to sync (pull + push) using the stored PAT token
# Usage: ./git-sync.sh

BRANCH=$(git rev-parse --abbrev-ref HEAD)
TOKEN=$(cat .git/credentials | grep -o 'github_pat_[^@]*')

if [ -z "$TOKEN" ]; then
    echo "Error: No token found in .git/credentials"
    exit 1
fi

# Temporarily set remote URL with token
git remote set-url origin "https://${TOKEN}@github.com/josephvolmer/sql-xel-parser.git"

# Pull and push
git pull --rebase origin "$BRANCH"
PULL_EXIT=$?

if [ $PULL_EXIT -ne 0 ]; then
    git remote set-url origin "https://github.com/josephvolmer/sql-xel-parser.git"
    exit $PULL_EXIT
fi

git push origin "$BRANCH"
PUSH_EXIT=$?

# Clean up: restore remote URL without token
git remote set-url origin "https://github.com/josephvolmer/sql-xel-parser.git"

exit $PUSH_EXIT
