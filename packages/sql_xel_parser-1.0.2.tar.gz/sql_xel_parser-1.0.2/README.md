# SQL XEL Parser

A comprehensive Python solution for parsing and analyzing SQL Server Extended Events (.xel) files. This tool converts binary XEL files to human-readable formats and provides powerful filtering, searching, and analysis capabilities.

**Tested primarily with Azure SQL Database audit logs. Should work with any SQL Server Extended Events XEL file - feedback welcome!**

## Features

- **Universal XEL Support**: Works with XML-based XEL files; extracts metadata from SQL Server binary XEL files
- **Multiple Output Formats**: JSON, JSON Lines, CSV, Text, Markdown, Summary
- **Advanced Filtering**: Filter by event name, time range, field values
- **Full-Text Search**: Search across all event data with regex support
- **Analysis Tools**: Aggregation, grouping, counting, statistics
- **Folder Processing**: Recursively process directories of XEL files
- **Python API**: Use as a library in your own scripts
- **CLI Tool**: Powerful command-line interface

## Important Note

**SQL Server Binary XEL Files**: This tool uses UTF-16 string extraction to parse binary XEL files without requiring SQL Server. Tested with 671 Azure SQL audit log files. See [Advanced Documentation](docs/) for technical details and what gets extracted.

## Installation

### From Source (Development)

```bash
# Clone or navigate to the project directory
cd xel-log-parse

# Install the package
pip install -e .

# Verify installation
sql-xel-parser --version
```

### From PyPI

```bash
pip install sql-xel-parser
```

See [INSTALL.md](INSTALL.md) for detailed installation instructions.

## Quick Start

### Command Line Usage

After installation, use the `sql-xel-parser` command:

```bash
# Show help
sql-xel-parser --help

# Convert XEL to JSON
sql-xel-parser input.xel -o output.json

# Convert to readable text format
sql-xel-parser input.xel -o output.txt -f text

# Process entire directory recursively
sql-xel-parser data/sql-ptfm-prod-westus3 -r -f summary

# Get summary statistics
sql-xel-parser input.xel -f summary

# Filter events by name
sql-xel-parser input.xel --filter-name "sql_batch_completed" -o filtered.json

# Search for specific content
sql-xel-parser input.xel --search "SELECT.*FROM users"

# Count events by type
sql-xel-parser input.xel --count-by name

# Get top 10 most frequent values
sql-xel-parser input.xel --top-n "data.query_hash:10"
```

### Python API Usage

```python
from sql_xel_parser import XELParser, XELAnalyzer, XELConverter

# Parse XEL file
parser = XELParser('input.xel')
events = list(parser.parse())

# Create analyzer
analyzer = XELAnalyzer(events)

# Filter events
filtered = analyzer.filter_by_name('sql_batch_completed')
filtered = filtered.filter_by_field('data.duration', 1000, operator='gt')

# Search
results = analyzer.search('SELECT.*FROM')

# Get statistics
stats = analyzer.get_stats()
print(stats)

# Count by field
counts = analyzer.count_by('name')
print(counts)

# Convert to format
converter = XELConverter()
json_output = converter.to_json(filtered.get_events())
text_output = converter.to_text(filtered.get_events())
csv_output = converter.to_csv(filtered.get_events())
```

## Output Formats

### JSON
Standard JSON format with proper indentation:
```bash
sql-xel-parser input.xel -f json -o output.json
```

### JSON Lines
One JSON object per line (great for streaming):
```bash
sql-xel-parser input.xel -f jsonl -o output.jsonl
```

### CSV
Flattened CSV format:
```bash
sql-xel-parser input.xel -f csv -o output.csv
```

### Text
Human-readable text format:
```bash
sql-xel-parser input.xel -f text -o output.txt --verbose
```

### Markdown
Formatted markdown report:
```bash
sql-xel-parser input.xel -f markdown -o report.md
```

### Summary
Quick statistics overview:
```bash
sql-xel-parser input.xel -f summary
```

## Filtering

### By Event Name
```bash
# Exact match
sql-xel-parser input.xel --filter-name "sql_batch_completed"

# Regex pattern
sql-xel-parser input.xel --filter-name "sql_batch_.*"
```

### By Time Range
```bash
sql-xel-parser input.xel \
  --filter-time-start "2024-01-01 00:00:00" \
  --filter-time-end "2024-01-31 23:59:59"
```

### By Field Value
```bash
# Equals
sql-xel-parser input.xel --filter-field "data.duration=1000"

# Greater than
sql-xel-parser input.xel --filter-field "data.duration>1000"

# Less than
sql-xel-parser input.xel --filter-field "data.cpu_time<500"

# Contains (string search)
sql-xel-parser input.xel --filter-field "data.statement~SELECT"

# Field exists
sql-xel-parser input.xel --filter-field "data.query_hash"

# Multiple filters
sql-xel-parser input.xel \
  --filter-field "data.duration>1000" \
  --filter-field "data.cpu_time<5000"
```

### Full-Text Search
```bash
# Simple search
sql-xel-parser input.xel --search "error"

# Regex search
sql-xel-parser input.xel --search "SELECT.*FROM.*WHERE"
```

## Analysis

### Statistics
```bash
sql-xel-parser input.xel --stats
```

### Count Events
```bash
# Count by event name
sql-xel-parser input.xel --count-by name

# Count by any field
sql-xel-parser input.xel --count-by "data.database_name"
```

### Top N Values
```bash
# Top 10 event types
sql-xel-parser input.xel --top-n "name:10"

# Top 20 queries by hash
sql-xel-parser input.xel --top-n "data.query_hash:20"
```

### Aggregation
```bash
# Count
sql-xel-parser input.xel --aggregate "data.duration:count"

# Sum
sql-xel-parser input.xel --aggregate "data.duration:sum"

# Average
sql-xel-parser input.xel --aggregate "data.duration:avg"

# Min/Max
sql-xel-parser input.xel --aggregate "data.duration:min"
sql-xel-parser input.xel --aggregate "data.duration:max"

# Distinct values
sql-xel-parser input.xel --aggregate "data.database_name:distinct"
```

### Grouping
```bash
# Group by field
sql-xel-parser input.xel --group-by "data.database_name"
```

## Advanced Examples

### Find Slow Queries
```bash
sql-xel-parser queries.xel \
  --filter-name "sql_batch_completed" \
  --filter-field "data.duration>5000000" \
  --top-n "data.statement:20" \
  -o slow_queries.json
```

### Analyze Errors
```bash
sql-xel-parser errors.xel \
  --filter-name "error_reported" \
  --count-by "data.error_number" \
  -o error_summary.json
```

### Database Activity Report
```bash
sql-xel-parser activity.xel \
  --filter-time-start "2024-01-01" \
  --filter-time-end "2024-01-31" \
  --count-by "data.database_name" \
  -f markdown -o report.md
```

### Export to CSV for Excel
```bash
sql-xel-parser input.xel \
  --filter-name "sql_batch_completed" \
  --limit 10000 \
  -f csv -o export.csv
```

## Python API Reference

### XELParser
```python
from sql_xel_parser import XELParser

parser = XELParser('file.xel')
events = list(parser.parse())  # Returns iterator of event dicts
stats = parser.get_stats()      # Get parsing statistics
```

### XELAnalyzer
```python
from sql_xel_parser import XELAnalyzer

analyzer = XELAnalyzer(events)

# Filtering
analyzer = analyzer.filter_by_name('sql_batch_completed')
analyzer = analyzer.filter_by_time_range('2024-01-01', '2024-01-31')
analyzer = analyzer.filter_by_field('data.duration', 1000, operator='gt')
analyzer = analyzer.search('SELECT.*FROM')

# Custom filter with lambda
analyzer = analyzer.custom_filter(lambda e: e.get('name') == 'error' and e['data']['severity'] > 10)

# Analysis
counts = analyzer.count_by('name')
groups = analyzer.group_by('data.database_name')
top = analyzer.top_n('name', 10)
agg = analyzer.aggregate('data.duration', 'avg')
stats = analyzer.get_stats()

# Get filtered events
filtered_events = analyzer.get_events()
```

### XELConverter
```python
from sql_xel_parser import XELConverter

converter = XELConverter()

# Convert events
json_str = converter.to_json(events, indent=2)
jsonl_str = converter.to_json_lines(events)
csv_str = converter.to_csv(events)
text_str = converter.to_text(events, verbose=True)
md_str = converter.to_markdown(events)
summary_str = converter.to_summary(events)
```

## Event Structure

Parsed events have the following structure:

```json
{
  "name": "sql_batch_completed",
  "timestamp": "2024-01-15T10:30:45.123Z",
  "data": {
    "duration": 1234567,
    "cpu_time": 500,
    "logical_reads": 100,
    "statement": "SELECT * FROM users WHERE id = 1"
  },
  "actions": {
    "session_id": 52,
    "database_name": "MyDatabase",
    "username": "app_user"
  }
}
```

## How It Works

1. **Binary Parsing**: The tool reads .xel files in their native binary format
2. **XML Extraction**: Extracts embedded XML event data from the binary stream
3. **Event Parsing**: Parses XML into structured Python dictionaries
4. **Fallback Support**: Falls back to direct XML parsing if binary parsing fails
5. **Universal Compatibility**: Works with any XEL file structure

## Limitations

- Very large .xel files (>1GB) may require significant memory
- Use `--limit` to process files incrementally
- Binary format parsing is best-effort; some proprietary structures may not parse perfectly
- Consider using SQL Server's built-in XML export for guaranteed compatibility

## More Examples

See the [`examples/`](examples/) directory for comprehensive Python API examples including:
- Parsing single files and directories
- Extracting metadata (servers, databases, applications)
- Security audit analysis
- Time-based event analysis
- All export formats

Run: `python examples/example_usage.py <xel_file_or_directory>`

## Troubleshooting

### No events found
- The .xel file may be in an unexpected format
- Try using SQL Server Management Studio to verify the file contains events
- Check file permissions

### Parsing errors
- Some XEL files use proprietary binary formats that may not be fully compatible
- Try exporting from SQL Server using XML format for guaranteed compatibility

### Performance issues
- Use `--limit` to process fewer events
- Use filters early to reduce data volume
- Process large files in chunks

## Contributing

Feel free to submit issues, fork the repository, and create pull requests for any improvements.

## License

MIT License - see [LICENSE](LICENSE) file for details.
