"""
@RAG_CONTEXT
{
  "archivo": "src/ocr_indexer/__init__.py",
  "lineas": 0,
  "tokens_estimados": 0,
  "hash_contenido": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
  "creacion": "2026-03-13",
  "modificacion": "2026-03-17",
  "tags": [],
  "descripcion_corta": "Inicializador del paquete OCR Indexer",
  "descripcion_larga": "Archivo __init__.py que define el paquete Python 'src.ocr_indexer' como un módulo importable. Establece la ruta del paquete y puede contener inicializaciones específicas del módulo, como importaciones de sub-módulos o configuración de variables globales necesarias para el funcionamiento del sistema de indexación OCR."
}
"""
