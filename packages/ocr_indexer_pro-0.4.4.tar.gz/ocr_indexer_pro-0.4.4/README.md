<!--
@RAG_CONTEXT
{
  "archivo": "README.md",
  "lineas": 0,
  "tokens_estimados": 0,
  "hash_contenido": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
  "creacion": "2026-03-13",
  "modificacion": "2026-03-17",
  "tags": [],
  "descripcion_corta": "Documentación del proyecto en archivo README.md",
  "descripcion_larga": "El archivo README.md contiene la documentación principal del proyecto, incluyendo descripción, instalación, uso y contribuciones. Es un archivo Markdown estándar que sirve como punto de entrada para desarrolladores y usuarios."
}
-->
