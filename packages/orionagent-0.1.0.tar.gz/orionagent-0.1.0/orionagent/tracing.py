"""TraceManager for OrionAI.

Provides lightweight telemetry for debugging and performance monitoring.
Captures every agent turn, tool call, and decision point into a structured
trace log that can be exported to JSON.
"""

import json
import time
import uuid
from dataclasses import dataclass, field, asdict
from typing import Any, Dict, List, Optional


@dataclass
class TraceEvent:
    event_type: str  # "agent_ask", "tool_call", "plan_step", "handoff"
    name: str
    input_data: Any
    output_data: Any = None
    duration: float = 0.0
    timestamp: float = field(default_factory=time.time)
    metadata: Dict[str, Any] = field(default_factory=dict)
    trace_id: str = field(default_factory=lambda: str(uuid.uuid4()))


class TraceManager:
    """Singleton registry for framework-level telemetry.

    Usage:
        from orionagent.tracing import tracer
        with tracer.trace("agent_ask", "researcher", task):
            ...
    """

    _instance = None

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super(TraceManager, cls).__new__(cls)
            cls._instance.events = []
            cls._instance.active_traces = {}
        return cls._instance

    def log_event(self, event_type: str, name: str, input_data: Any, 
                  output_data: Any = None, duration: float = 0.0, 
                  metadata: Dict[str, Any] = None) -> TraceEvent:
        """Manually log a completed event."""
        event = TraceEvent(
            event_type=event_type,
            name=name,
            input_data=input_data,
            output_data=output_data,
            duration=duration,
            metadata=metadata or {}
        )
        self.events.append(event)
        return event

    def start_trace(self, event_type: str, name: str, input_data: Any, 
                    metadata: Dict[str, Any] = None) -> str:
        """Start a timed trace and return its ID."""
        trace_id = str(uuid.uuid4())
        self.active_traces[trace_id] = {
            "type": event_type,
            "name": name,
            "input": input_data,
            "start": time.time(),
            "metadata": metadata or {}
        }
        return trace_id

    def end_trace(self, trace_id: str, output_data: Any) -> Optional[TraceEvent]:
        """End a timed trace and log the final event."""
        data = self.active_traces.pop(trace_id, None)
        if not data:
            return None

        duration = time.time() - data["start"]
        return self.log_event(
            event_type=data["type"],
            name=data["name"],
            input_data=data["input"],
            output_data=output_data,
            duration=duration,
            metadata=data["metadata"]
        )

    def clear(self):
        """Reset the event history."""
        self.events = []
        self.active_traces = {}

    def export(self, filepath: Optional[str] = None) -> List[Dict[str, Any]]:
        """Export history to a list of dicts, or save to JSON file."""
        data = [asdict(e) for e in self.events]
        if filepath:
            with open(filepath, "w", encoding="utf-8") as f:
                json.dump(data, f, indent=2)
        return data

    def print_summary(self):
        """Print a human-readable summary of the last execution."""
        if not self.events:
            print("\n--- No trace data available ---")
            return

        # Dim/Grey color for trace logs
        DIM = "\033[90m"
        RESET = "\033[0m"

        print(f"\n{DIM}{'='*60}")
        print("🔍 ORIONAI EXECUTION TRACE")
        print(f"{'='*60}{RESET}")
        
        for e in self.events:
            dur = f"({e.duration:.2f}s)" if e.duration > 0 else ""
            print(f"{DIM}[{e.event_type.upper()}] {e.name} {dur}{RESET}")
            
            # Briefly show input/output if they are strings
            if isinstance(e.input_data, str):
                inp = e.input_data[:50] + "..." if len(e.input_data) > 50 else e.input_data
                print(f"{DIM}  In:  {inp}{RESET}")
            
            if isinstance(e.output_data, str):
                out = e.output_data[:50] + "..." if len(e.output_data) > 50 else e.output_data
                print(f"{DIM}  Out: {out}{RESET}")
        
        print(f"{DIM}{'='*60}{RESET}\n")


# Global tracer instance
tracer = TraceManager()
