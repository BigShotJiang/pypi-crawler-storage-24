import json
from unittest.mock import MagicMock

import pytest
from requests import Response, Session

from sharepoint import SharePointListItem


def _mock_response(
    data: dict, status_code: int = 200, headers: dict = None
) -> Response:
    """Create a realistic ``requests.Response`` object with JSON data."""
    if headers is None:
        headers = {"Content-Type": "application/json;odata=verbose"}

    mock_resp = MagicMock(spec=Response)
    mock_resp.status_code = status_code
    mock_resp.headers = headers or {}
    mock_resp.ok = 200 <= status_code < 400
    mock_resp.json.return_value = data
    mock_resp.text = json.dumps(data)
    mock_resp.request = MagicMock()
    mock_resp.request.url = "https://example.com/_api/Web/Lists(guid'list')/items(1)"
    return mock_resp


@pytest.fixture
def mock_session():
    """Provide a mocked ``requests.Session``."""
    return MagicMock(spec=Session)


def test_list_item_properties(mock_session):
    """Validate that ``SharePointListItem`` exposes metadata correctly."""
    item_data = {
        "d": {
            "Id": "1",
            "Title": "Test Item",
            "Created": "2023-04-01T12:00:00Z",
            "Modified": "2023-04-02T15:30:00Z",
            "__metadata": {
                "id": "https://example.com/_api/Web/Lists(guid'list')/items(1)",
                "uri": "https://example.com/_api/Web/Lists(guid'list')/items(1)",
                "type": "SP.ListItem",
                "etag": 'W/"1"',
            },
        }
    }
    mock_session.get.return_value = _mock_response(
        item_data,
        headers={"Content-Type": "application/json;odata=verbose", "ETag": 'W/"1"'},
    )

    item = SharePointListItem(
        url="https://example.com/_api/Web/Lists(guid'list')/items(1)",
        session=mock_session,
    )

    assert item.id == "1"
    assert item.title == "Test Item"
    assert item.etag == 'W/"1"'
    # ``created`` and ``modified`` should be timezone-aware ``datetime`` objects
    assert isinstance(item.created, type(item.created))
    assert isinstance(item.modified, type(item.modified))


def test_update_item_calls_post_and_returns_ok(mock_session):
    """``update_item`` should perform a POST with MERGE and return ``ok``."""
    # Mock POST response for contextinfo (form digest)
    contextinfo_resp = _mock_response(
        {
            "d": {
                "GetContextWebInformation": {
                    "FormDigestValue": "test_digest_value",
                    "FormDigestTimeoutSeconds": 1800,
                }
            }
        },
        status_code=200,
    )

    # Mock GET response for metadata (used during property access)
    metadata_resp = _mock_response(
        {
            "d": {
                "__metadata": {
                    "id": "https://example.com/_api/Web/Lists(guid'list')/items(1)",
                    "uri": "https://example.com/_api/Web/Lists(guid'list')/items(1)",
                    "type": "SP.ListItem",
                    "etag": 'W/"1"',
                }
            }
        },
        headers={"Content-Type": "application/json;odata=verbose", "ETag": 'W/"1"'},
    )

    # Mock POST response for update operation (204 No Content is typical for updates)
    post_resp = MagicMock(spec=Response)
    post_resp.status_code = 204
    post_resp.ok = True
    post_resp.headers = {"Content-Type": "application/json;odata=verbose"}

    # Configure mock to return different responses for different calls
    mock_session.post.side_effect = [contextinfo_resp, post_resp]
    mock_session.get.return_value = metadata_resp

    item = SharePointListItem(
        url="https://example.com/_api/Web/Lists(guid'list')/items(1)",
        session=mock_session,
    )

    result = item.update_item({"Title": "Updated Title"})
    assert result is True

    # Ensure POST was called twice - once for contextinfo and once for update
    assert mock_session.post.call_count == 2

    # Check that the second call (the update operation) was made with the correct URL and form digest
    second_call_args, second_call_kwargs = mock_session.post.call_args
    assert (
        second_call_args[0] == "https://example.com/_api/Web/Lists(guid'list')/items(1)"
    )
    assert "X-RequestDigest" in second_call_kwargs.get("headers", {})
    assert second_call_kwargs["headers"]["X-HTTP-Method"] == "MERGE"


def test_update_item_success_204(mock_session):
    """Test update item with 204 No Content response."""
    # Mock contextinfo response
    contextinfo_resp = _mock_response(
        {
            "d": {
                "GetContextWebInformation": {
                    "FormDigestValue": "test_digest_value",
                    "FormDigestTimeoutSeconds": 1800,
                }
            }
        },
        status_code=200,
    )

    # Mock metadata response
    metadata_resp = _mock_response(
        {
            "d": {
                "__metadata": {
                    "id": "https://example.com/_api/Web/Lists(guid'list')/items(1)",
                    "uri": "https://example.com/_api/Web/Lists(guid'list')/items(1)",
                    "type": "SP.ListItem",
                    "etag": 'W/"1"',
                }
            }
        },
        headers={"Content-Type": "application/json;odata=verbose", "ETag": 'W/"1"'},
    )

    # Mock successful update response (204 No Content)
    update_resp = _mock_response(
        {}, status_code=204, headers={"Content-Type": "application/json;odata=verbose"}
    )

    mock_session.post.side_effect = [contextinfo_resp, update_resp]
    mock_session.get.return_value = metadata_resp

    item = SharePointListItem(
        url="https://example.com/_api/Web/Lists(guid'list')/items(1)",
        session=mock_session,
    )

    result = item.update_item({"Title": "Updated Title"})
    assert result is True


def test_delete_item_success_200(mock_session):
    """Test delete item with 200 OK response."""
    # Mock contextinfo response
    contextinfo_resp = _mock_response(
        {
            "d": {
                "GetContextWebInformation": {
                    "FormDigestValue": "test_digest_value",
                    "FormDigestTimeoutSeconds": 1800,
                }
            }
        },
        status_code=200,
    )

    # Mock metadata response
    metadata_resp = _mock_response(
        {
            "d": {
                "__metadata": {
                    "id": "https://example.com/_api/Web/Lists(guid'list')/items(1)",
                    "uri": "https://example.com/_api/Web/Lists(guid'list')/items(1)",
                    "type": "SP.ListItem",
                    "etag": 'W/"1"',
                }
            }
        },
        headers={"Content-Type": "application/json;odata=verbose", "ETag": 'W/"1"'},
    )

    # Mock successful delete response
    delete_resp = _mock_response(
        {}, status_code=200, headers={"Content-Type": "application/json;odata=verbose"}
    )

    # First call is for contextinfo, second call is for delete
    mock_session.post.side_effect = [contextinfo_resp, delete_resp]
    mock_session.get.return_value = metadata_resp

    item = SharePointListItem(
        url="https://example.com/_api/Web/Lists(guid'list')/items(1)",
        session=mock_session,
    )

    result = item.delete_item()
    assert result is True

    # Ensure POST was called twice - once for contextinfo and once for delete
    assert mock_session.post.call_count == 2

    # Check that the second call (the delete operation) was made with the correct URL and form digest
    second_call_args, second_call_kwargs = mock_session.post.call_args
    assert (
        second_call_args[0] == "https://example.com/_api/Web/Lists(guid'list')/items(1)"
    )
    assert "X-RequestDigest" in second_call_kwargs.get("headers", {})
    assert second_call_kwargs["headers"]["X-HTTP-Method"] == "DELETE"
    # Verify the If-Match header is set to "*" to avoid ETag conflicts
    assert second_call_kwargs["headers"]["If-Match"] == "*"


def test_delete_item_calls_post_with_delete_headers_and_returns_ok(mock_session):
    """``delete_item`` should perform a POST with X-HTTP-Method DELETE and If-Match header and return ``ok``."""
    # Mock contextinfo response
    contextinfo_resp = _mock_response(
        {
            "d": {
                "GetContextWebInformation": {
                    "FormDigestValue": "test_digest_value",
                    "FormDigestTimeoutSeconds": 1800,
                }
            }
        },
        status_code=200,
    )

    # Mock GET for metadata (needed for _ensure_metadata)
    metadata_resp = _mock_response(
        {
            "d": {
                "__metadata": {
                    "id": "https://example.com/_api/Web/Lists(guid'list')/items(1)",
                    "uri": "https://example.com/_api/Web/Lists(guid'list')/items(1)",
                    "type": "SP.ListItem",
                }
            }
        }
    )
    
    # Mock successful delete response
    delete_resp = MagicMock(spec=Response)
    delete_resp.ok = True
    delete_resp.status_code = 200
    delete_resp.headers = {"Content-Type": "application/json;odata=verbose"}
    
    # Configure mock to return different responses for different calls
    mock_session.post.side_effect = [contextinfo_resp, delete_resp]
    mock_session.get.return_value = metadata_resp

    item = SharePointListItem(
        url="https://example.com/_api/Web/Lists(guid'list')/items(1)",
        session=mock_session,
    )

    result = item.delete_item()
    assert result is True
    
    # Ensure POST was called twice - once for contextinfo and once for delete
    assert mock_session.post.call_count == 2

    # Check that the second call (the delete operation) was made with the correct URL and form digest
    second_call_args, second_call_kwargs = mock_session.post.call_args
    assert (
        second_call_args[0] == "https://example.com/_api/Web/Lists(guid'list')/items(1)"
    )
    assert "X-RequestDigest" in second_call_kwargs.get("headers", {})
    assert second_call_kwargs["headers"]["X-HTTP-Method"] == "DELETE"
    # Verify the If-Match header is set to "*" to avoid ETag conflicts
    assert second_call_kwargs["headers"]["If-Match"] == "*"


def test_delete_item_with_form_digest_and_etag_fix(mock_session):
    """Verify that delete_item correctly uses form digest and If-Match header to prevent 412 Precondition Failed errors."""
    # Mock the form digest response
    contextinfo_resp = _mock_response(
        {
            "d": {
                "GetContextWebInformation": {
                    "FormDigestValue": "fixed_digest_value_12345",
                    "FormDigestTimeoutSeconds": 1800,
                }
            }
        },
        status_code=200,
    )
    
    # Mock metadata response (needed for _ensure_metadata)
    metadata_resp = _mock_response(
        {
            "d": {
                "__metadata": {
                    "id": "https://example.com/_api/Web/Lists(guid'list')/items(1)",
                    "uri": "https://example.com/_api/Web/Lists(guid'list')/items(1)",
                    "type": "SP.ListItem",
                }
            }
        }
    )
    
    # Mock successful deletion response
    delete_resp = MagicMock(spec=Response)
    delete_resp.status_code = 204  # No Content is typical for successful deletions
    delete_resp.ok = True
    delete_resp.headers = {"Content-Type": "application/json;odata=verbose"}
    
    # Configure mock to return different responses for different calls
    mock_session.post.side_effect = [contextinfo_resp, delete_resp]
    mock_session.get.return_value = metadata_resp

    # Create SharePointListItem instance
    item = SharePointListItem(
        url="https://example.com/_api/Web/Lists(guid'list')/items(1)",
        session=mock_session,
    )

    # Execute the delete operation
    result = item.delete_item()
    
    # Verify the result
    assert result is True
    
    # Verify that POST was called exactly twice
    assert mock_session.post.call_count == 2
    
    # Verify the first call was to get context info (form digest)
    first_call_args, first_call_kwargs = mock_session.post.call_args_list[0]
    assert first_call_args[0] == "https://example.com/_api/contextinfo"
    
    # Verify the second call was to delete the item with proper headers
    second_call_args, second_call_kwargs = mock_session.post.call_args_list[1]
    assert second_call_args[0] == "https://example.com/_api/Web/Lists(guid'list')/items(1)"
    
    # Verify that the form digest was correctly used in headers
    headers = second_call_kwargs.get("headers", {})
    assert "X-RequestDigest" in headers
    assert headers["X-RequestDigest"] == "fixed_digest_value_12345"
    
    # Verify that X-HTTP-Method DELETE was set
    assert "X-HTTP-Method" in headers
    assert headers["X-HTTP-Method"] == "DELETE"
    
    # Verify that If-Match header is set to "*" to avoid ETag conflicts
    assert "If-Match" in headers
    assert headers["If-Match"] == "*"
    
    # Verify no data was sent (as expected for delete operations)
    assert second_call_kwargs.get("data") is None
