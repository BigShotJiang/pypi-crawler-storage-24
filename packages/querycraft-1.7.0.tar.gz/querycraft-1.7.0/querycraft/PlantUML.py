
import os
import importlib.resources

import plantuml as puml
from querycraft.logger import get_logger
from querycraft.tools import doCacheKey, existFile
from querycraft.Database import Database


class PlantUML:

    def __init__(self, bd):
        self.db = bd

    def createModel(self):
        print(f"Création du modèle PlantUML pour {self.db.dbtype} avec {self.db.db}")
        name = doCacheKey(f"{self.db.dbtype}-{self.db.db}")
        output_file_name = f'{name}.png'
        tmp_file_name = f'{name}.puml'
        try:
            code = self.to_eap()
        except Exception as e:
            print(f"erreur de génération code : {e}")
            return None
        with importlib.resources.path("querycraft.static.images", f"{output_file_name}") as output_file:
            if existFile(output_file):
                return output_file_name
            else:
                # https://plantuml.com/fr/api
                # https://github.com
                try:
                    plantuml = puml.PlantUML(url='http://www.plantuml.com/plantuml/img/')
                    # Traitement du vrai code
                    with importlib.resources.path("querycraft.static", f"{tmp_file_name}") as tmp_file:
                        with open(tmp_file, "w") as fichier:
                            fichier.write(code)
                        ok = plantuml.processes_file(tmp_file, output_file)
                except Exception as e:
                    print(f"erreur de génération image : {e}")
                    return None
                if ok:
                    return output_file_name
                else:
                    return None

    def to_eap(self):
        # Générer le code PlantUML
        plantuml_code = ("@startuml\n"
                         "skinparam BackgroundColor transparent\n"
                         #"left to right direction\n"
                         "top to bottom direction\n"
                         "hide circle\n"
                         "hide methods\n\n")

        for (t, (id_t, att)) in self.db.dbTables.items():
            plantuml_code += f"entity {t} {{\n"
            for column in att:
                if column[1]:
                    plantuml_code += f" {column[0]} {'# ' if column[2] else ''}{'<<PK>>' if column[1] else ''} \n"
            plantuml_code += "---\n"
            for column in att:
                if not column[1]:
                    plantuml_code += f" {column[0]} {'# ' if column[2] else ''}{'<<PK>>' if column[1] else ''} \n"
            plantuml_code += "}\n"

        # gestion des relations
        for (t, (id_t, att)) in self.db.dbTables.items():
            for column in att:
                if column[2]:
                    (pkt,pk) = column[2]
                    plantuml_code += f"{pkt}||--o" + "{" + f"{t}\n"

        plantuml_code += "@enduml"
        return plantuml_code

if __name__ == "__main__":
    db = Database.build("./data/cours.db", "sqlite")
    plm = PlantUML(db)
    code = plm.to_eap()
    print(code)
    print(plm.createModel())
