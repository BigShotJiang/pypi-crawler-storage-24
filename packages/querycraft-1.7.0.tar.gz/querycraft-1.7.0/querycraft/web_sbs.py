#!/usr/bin/env python3
"""
Application web Flask pour QueryCraft
Permet l'exécution pas à pas de requêtes SQL via une interface web

Fichier généré initialement avec l'aide de Claude Code / Claude Sonnet 4.5 - le 2026-02-12

(c) E. Desmontils, Nantes Université, 2026
"""

import getpass
import importlib.resources
import json
import os
import platform

import colorama
from flask import Flask, jsonify, render_template, request, url_for

from querycraft.__init__ import __version__
from querycraft.Database import DBPGSQL, Database, DBMySQL, DBSQLite
from querycraft.LLM import LLM, OllamaLLMBase, format_ia, manage_ia2
from querycraft.logger import get_logger, setup_logger
from querycraft.security import SQLSecurityValidator
from querycraft.SQL import SQL
from querycraft.SQLException import SQLException, SQLQueryException
from querycraft.tools import (
    cadre,
    colorize_sql_html,
    existFile,
    format_table_1,
    format_table_2,
    format_table_3,
    getQuestion,
    loadExos,
    markdown_to_html,
    readConfigFile,
    saveExos,
    truncate_rows,
)
import querycraft.PlantUML as plm


# ==================================================================
# ==================================================================
# ==================================================================

MAX_ROWS = 15
ligne_html = '<hr style="border: none; border-top: 1px solid #dee2e6; margin: 20px 0;">'

app = Flask(__name__)
config_last_modified = 0  # Timestamp de dernière modification du fichier de config

# ==================================================================
# ==================================================================
# ==================================================================


def get_database_from_config(config, debug=False, verbose=False, output="html"):
    """
    Récupère la connexion à la base de données depuis la configuration

    Args:
        debug: Mode debug
        verbose: Mode verbose
        output: Format de sortie ('txt', 'html', 'md')

    Returns:
        Instance de Database (DBSQLite, DBPGSQL ou DBMySQL)
    """
    db_type = config.get("Database", "type")
    database = config.get("Database", "database")
    log = get_logger("querycraft.web.get_database_from_config")
    match db_type:
        case "sqlite":
            # SQLite: db = chemin du fichier
            if not (existFile(database)):
                log.error(f"database file not found : {database}")
                package_files = importlib.resources.files("querycraft.data")
                log.info("trying to search in default databases")
                if not (existFile(package_files / database)):
                    log.error(" default database file not found")
                    exit(1)
                else:
                    database = package_files / database
                    log.info("database exists")
            else:
                log.info("database exists")
            db = str(database)
        case "pgsql":
            # PostgreSQL: db = chaîne de connexion
            username = config.get("Database", "username")
            password = config.get("Database", "password")
            host = config.get("Database", "host", fallback="localhost")
            port = config.get("Database", "port", fallback="5432")
            db = f"dbname={database} user={username} password={password} host={host} port={port}"
        case "mysql":
            # MySQL: db = tuple (user, password, host, database)
            username = config.get("Database", "username")
            password = config.get("Database", "password")
            host = config.get("Database", "host", fallback="localhost")
            # port = config.get('Database', 'port', fallback='3306')
            db = (username, password, host, database)
        case _:
            raise ValueError(f"Type de base de données non supporté : {db_type}")
    inst_db = Database.get(
        dbcon=db, dbtype=db_type, debug=debug, verbose=verbose, output=output
    )
    if inst_db is not None:
        inst_db.verbose = verbose
        if inst_db.isActive():
            log.info(f"Connexion à la base de données {database} réussie.")
        else:
            log.info(f"Échec de la connexion à la base de données : {inst_db}")
        return inst_db
    else:
        return None


# Configuration globale chargée au démarrage
def getConfig():
    global config_last_modified, MAX_ROWS
    config = readConfigFile()

    # Vérifier si les valeurs sont vides et les remplacer par "None"
    for section in config.sections():
        for key, value in config.items(section):
            if value == "":
                config.set(section, key, "None")

    MAX_ROWS = config.getint("Autre", "max-rows", fallback=MAX_ROWS)

    # Initialiser le timestamp de la config
    try:
        with importlib.resources.path(
            "querycraft.config", "config-sbs.cfg"
        ) as config_file:
            config_last_modified = os.path.getmtime(config_file)
    except Exception:
        pass
    return config


def evalBD(dbtype, database, user=None, password=None, host=None, port=None):
    log = get_logger("querycraft.web.evalBD")
    try:
        match dbtype:
            case "sqlite":
                # SQLite: db = chemin du fichier
                if not (existFile(database)):
                    log.error(f"database file not found : {database}")
                    package_files = importlib.resources.files("querycraft.data")
                    log.info("trying to search in default databases")
                    if not (existFile(package_files / database)):
                        log.error(" default database file not found")
                        raise FileNotFoundError(" default database file not found")
                    else:
                        database = package_files / database
                        log.info("database exists")
                else:
                    log.info("database exists")
                db = str(database)
            case "pgsql":
                db = f"dbname={database} user={user} password={password} host={host} port={port}"
            case "mysql":
                db = (username, password, host, database)
            case _:
                raise ValueError(f"Type de base de données non supporté : {dbtype}")
        db = Database.build(dbcon=db, dbtype=dbtype)
        if db and db.isActive():
            log.info(f"Connexion à la base de données {database} réussie.")
            return True
        else:
            log.info(f"Échec de la connexion à la base de données : {db}")
            return False
    except Exception as e:
        log.info(f"Erreur lors de la connexion à la base de données : {e}")
        return False


def getIA(config, db):
    # if config['IA']['mode'] == 'on':
    log = get_logger("querycraft.web.getIA")
    ok = LLM.set(config, db)
    if ok:
        log.info(f"LLM actif : {'cible' if not LLM.defModel else 'par défaut'}")
        if LLM.defModel:
            log.info(f"Modèle par défaut : {LLM.model.getName()}")
    else:
        log.info("Pas de LLM utilisable")
    return LLM.get()
    # else:
    #    return None


def evalIA(service, modele, url="None", api="None"):
    log = get_logger("querycraft.web")
    llm = LLM.build(Database.currentdb, service, modele, url, api)
    if llm:
        ok = llm.is_alive()
        if ok:
            log.info(f"LLM modèle actif : {llm.getName()}")
        else:
            log.info(f"LLM modèle absent : {llm.getName()}")
    else:
        log.info(f"LLM pas utilisable : {service} {modele} {url} {api}")
        ok = False
    defllm = LLM.buildDefault(Database.currentdb) is not None
    return (ok, defllm)


# ==================================================================
# ==================================================================
# ==================================================================

config = getConfig()

level = "INFO"
try:
    username = getpass.getuser()
except Exception:
    username = "unknown"
with importlib.resources.path(
    "querycraft.logs", f"querycraft-{__version__}-{username}.log"
) as log_file:
    logger = setup_logger(
        name="querycraft",
        level=level,
        log_file=log_file,
        verbose=config.getboolean("Autre", "verbose"),
        console=config.getboolean("Autre", "debug"),
    )

db = get_database_from_config(config, debug=False, verbose=False, output="html")
if db:
    llm = getIA(config, db)
else:
    llm = None
logger.info(f"llm : {llm.getName() if llm else 'None'}")

# ==================================================================
# ==================================================================
# ==================================================================


def get_system_info():
    """
    Récupère les informations système (machine, OS, version Python)

    Returns:
        dict: Dictionnaire contenant les informations système
    """
    return {
        "machine": platform.machine(),  # Architecture (x86_64, arm64, etc.)
        "system": platform.system(),  # Système d'exploitation (Darwin, Linux, Windows)
        "release": platform.release(),  # Version du système
        "python_version": platform.python_version(),  # Version Python
        "platform": platform.platform(),  # Plateforme complète
        "node": platform.node(),  # Nom de la machine
    }


def reload_config_if_changed():
    """
    Recharge la configuration si le fichier a été modifié.
    Utile en environnement multi-workers (Gunicorn) pour synchroniser les changements.
    """
    global config, config_last_modified, llm, db
    log = get_logger("querycraft.web.reload_config_if_changed")
    try:
        with importlib.resources.path(
            "querycraft.config", "config-sbs.cfg"
        ) as config_file:
            current_mtime = os.path.getmtime(config_file)

            if current_mtime > config_last_modified:
                config = readConfigFile()
                config_last_modified = current_mtime
                log.info(f"Configuration rechargée (worker PID: {os.getpid()})")

                db = get_database_from_config(
                    config, debug=False, verbose=False, output="html"
                )
                llm = getIA(config, db)
                log.info(f"llm : {llm.getName()}")

    except Exception as e:
        log.error(f"Erreur lors du rechargement de la configuration : {e}")


def get_available_databases():
    """Liste les fichiers de bases de données SQLite disponibles dans querycraft/data/"""
    databases = []

    try:
        with importlib.resources.path("querycraft.data", "") as data_dir:
            if os.path.exists(data_dir):
                for filename in os.listdir(data_dir):
                    if filename.endswith(".db"):
                        databases.append(filename)
    except Exception as e:
        print(f"Erreur lors du chargement des bases de données : {e}")

    databases.sort()
    return databases


def execute_query_sbs(
    sql_query, step_by_step=True, verbose=False, code_ex=None, code_q=None
):
    """
    Exécute une requête SQL en mode pas à pas

    Args:
        sql_query: Requête SQL à exécuter
        step_by_step: Mode pas à pas activé
        verbose: Mode verbose avec aide de l'IA
        code_ex: Code de l'exercice (optionnel)
        code_q: Code de la question (optionnel)

    Returns:
        dict: Résultat contenant 'success', 'output', 'error', 'html_output', 'comparison'
    """
    result = {
        "success": False,
        "output": "",
        "error": "",
        "html_output": "",
        "comparison": None,
    }

    try:
        # Vérifier le mode debug et verbose depuis la config
        debug = config.getboolean("Autre", "debug", fallback=False)

        # Validation de sécurité de la requête SQL
        is_valid, validation_message = SQLSecurityValidator.validate_sql(sql_query)
        if not is_valid:
            result["error"] = (
                f"<strong>Erreur de sécurité :</strong><br>{validation_message}"
            )
            return result

        # Récupérer la connexion à la base de données
        db = get_database_from_config(
            config, debug=debug, verbose=verbose, output="html"
        )
        SQLQueryException.setCfg(config)

        # Créer l'objet SQL
        sql = SQL(
            db.db, db.dbtype, None, None, debug, verbose, step_by_step, output="html"
        )
        sql.setSQL(sql_query, True)
        html_output = []

        # Récupération de la question
        if code_ex is not None and code_q is not None:
            q = getQuestion(code_ex, code_q)
            if q is not None:
                (requete, intention, com, type, inst) = q

                # Validation de sécurité de la requête solution
                is_valid_sol, validation_message_sol = (
                    SQLSecurityValidator.validate_sql(requete)
                )
                if not is_valid_sol:
                    log = get_logger("querycraft.web.execute_query_sbs")
                    log.error(
                        f"La requête solution de l'exercice {code_ex}/{code_q} est invalide: {validation_message_sol}"
                    )
                    sol = None
                else:
                    sol = SQL(
                        db=db.db,
                        dbtype=db.dbtype,
                        debug=debug,
                        verbose=verbose,
                        step_by_step=step_by_step,
                        output="html",
                    )
                    sol.setSQL(requete, True)
                    sol.setExo(intention, code_ex, code_q, com, type, inst)
            else:
                sol = None
        else:
            sol = None

        html_output.append(
            f"<h3>Requête étudiée</h3><div class='info'>{colorize_sql_html(sql_query)} </div> "
        )

        if verbose and config["IA"]["mode"] == "on":
            rep = manage_ia2(
                "explain",
                config,
                verbose,
                f"{sql_query}",
                sql.getDB(),
                None,
                sql,
                None,
                None,
            )
            rep_str = format_ia(rep, "Explication de la requête", "html")
            html_output.append(rep_str)

        if step_by_step:
            # Exécution pas à pas : récupérer les étapes
            from querycraft.tools import format_table_2

            nb_steps, steps = sql.sbs()

            # Affichage des étapes
            for i, s in steps:
                if i < nb_steps - 1:
                    html_output.append(ligne_html)
                    html_output.append(
                        cadre(f"Étape N°{i + 1}/{nb_steps}", "—", "html")
                    )
                else:
                    html_output.append(ligne_html)
                    html_output.append(
                        cadre(f"Étape N°{i + 1}/{nb_steps} (Résultat)", "—", "html")
                    )

                # Affichage des étapes intermédiaires :
                #  - textes : id = 0
                #  - tables : id in [1,3]
                #  - SQL : id = 10
                for j in s:
                    (id, t) = j
                    if id == 0:
                        if t:  # Nombre de lignes de la table
                            html_output.append(f"<p>{t}</p> <br> ")
                        else:
                            html_output.append(f"&nbsp;&nbsp;&nbsp;&nbsp;⬇︎ ")
                    elif id == 10:  # Texte formater de la requête SQL
                        # html_output.append(f"<p><pre><code>{t}</code></pre></p>")
                        html_output.append(
                            f"<div style='background:#e8f4f8;padding:15px;border-radius:5px;border-left:4px solid  # 17a2b8;font-family:monospace;'>{colorize_sql_html(t)} </div> "
                        )
                    else:  # table(s)
                        (col, row, dif) = t
                        if id == 1:
                            html_output.append(
                                f"{format_table_1(col, row, dif, output='html')}"
                            )
                        elif id == 2:
                            html_output.append(
                                f"{format_table_2(col, row, dif, output='html')}"
                            )
                        elif id == 3:
                            html_output.append(
                                f"{format_table_3(col, row, dif, output='html', inter=True)}"
                            )
                        else:
                            pass

        else:
            # Exécution directe
            from querycraft.tools import format_table_2

            headers, rows = sql.getTable()

            html_output.append(f"<br/><h3>Résultat :</h3>")
            if rows:
                table_html = format_table_2(headers, rows, output="html")
                html_output.append(table_html)
                html_output.append(
                    f"<p><strong>{len(rows)} ligne(s) retournée(s)</strong></p> <br> "
                )
            else:
                html_output.append("<p><em>Aucun résultat</em></p> <br> ")

        if sol is not None:
            # Comparaison des résultats
            html_output.append(ligne_html)
            html_output.append(
                cadre("Correction", "=", "html", couleur=colorama.Style.BRIGHT)
            )
            html_output.append("<h3>Comparaison des résultats :</h3><br/>")
            html_output.append(
                sql.buildStdCorrection(
                    config["Autre"]["aide"] == "on", sol, output="html"
                )
            )

            if verbose:
                html_output.append("<br/>")
                # Analyse des requêtes
                if config["IA"]["mode"] == "on":
                    (exo, quest, intention, com, inst) = sol.getExo()
                    rep = manage_ia2(
                        "solution",
                        config,
                        verbose,
                        f"{sql} ; {sol}",
                        sql.getDB(),
                        None,
                        sql,
                        sol,
                        intention,
                    )
                    html_output.append(format_ia(rep, "Commentaire", "html"))

        result["html_output"] = "\n".join(html_output)
        result["success"] = True
    except SQLQueryException as e:
        result["success"] = True
        if e.hints:
            h = format_ia(e.hints, "Explication de l'erreur", output="html")
        else:
            h = ""
        result["html_output"] = e.err + "\n<br>" + h
    except Exception as e:
        result["error"] = f"<strong>Erreur :</strong><br>{str(e)}"
        import traceback

        result["error"] += (
            f"<br><br><pre style='background:#fff3cd;padding:10px;'>{traceback.format_exc()}</pre>"
        )

    return result


@app.before_request
def before_request():
    """Hook Flask exécuté avant chaque requête pour recharger la configuration si modifiée"""
    reload_config_if_changed()


@app.route("/ollama_models")
def ollama_models():
    """Retourne la liste des modèles Ollama disponibles"""
    global db
    l = LLM.build(db, "ollama", "").getModels()
    data = {"models": l}
    return jsonify(data)


@app.route("/config")
def config_page():
    """Page de configuration"""
    # Lire la configuration actuelle
    # reload_config_if_changed()
    log = get_logger("querycraft.web.config")
    global db
    mod = LLM.build(db, "ollama", "")
    if mod is not None:
        l = mod.getModels()
        if l is None:
            l = []
    else:
        l = []
    # log.info(f"Ollama models: {l}")

    config_data = {
        "Database": {
            "type": config.get("Database", "type", fallback="sqlite"),
            "database": config.get("Database", "database", fallback=""),
            "username": config.get("Database", "username", fallback=""),
            "password": config.get("Database", "password", fallback=""),
            "host": config.get("Database", "host", fallback="localhost"),
            "port": config.get("Database", "port", fallback=""),
        },
        "IA": {
            "modele": config.get("IA", "modele", fallback="gemma3:4b"),
            "service": config.get("IA", "service", fallback="ollama"),
            "api-key": config.get("IA", "api-key", fallback="None"),
            "url": config.get("IA", "url", fallback="None"),
            "mode": config.get("IA", "mode", fallback="off"),
        },
        "LRS": {
            "endpoint": config.get("LRS", "endpoint", fallback=""),
            "username": config.get("LRS", "username", fallback=""),
            "password": config.get("LRS", "password", fallback=""),
            "mode": config.get("LRS", "mode", fallback="off"),
        },
        "Autre": {
            "debug": config.get("Autre", "debug", fallback="False"),
            "verbose": config.get("Autre", "verbose", fallback="False"),
            "cache": config.get("Autre", "cache", fallback="on"),
            "duree-cache": config.get("Autre", "duree-cache", fallback="60"),
            "exos": config.get("Autre", "exos", fallback="off"),
            "aide": config.get("Autre", "aide", fallback="off"),
        },
    }

    system_info = get_system_info()
    available_databases = get_available_databases()

    return render_template(
        "config.html",
        config=config_data,
        version=__version__,
        available_databases=available_databases,
        ollama_models=l,
        currentmodel=llm.modele,
        currentservice=llm.service,
    )


@app.route("/config/save", methods=["POST"])
def config_save():
    """Sauvegarde la configuration"""
    global config
    try:
        data = request.get_json()
        print(f"Config reçue: {data}")
        # Synchroniser le mode verbose avec le mode IA
        # Si le mode IA est activé, alors le mode verbose est activé
        # if data['IA']['mode'] == 'on':
        #    data['Autre']['verbose'] = 'on'
        # elif data['IA']['mode'] == 'off':
        #    data['Autre']['verbose'] = 'off'

        # Mettre à jour la configuration en mémoire
        for section, values in data.items():
            if not config.has_section(section):
                config.add_section(section)
            for key, value in values.items():
                config.set(section, key, str(value))

        # Vérifier si les valeurs sont vides et les remplacer par "None"
        for section in config.sections():
            for key, value in config.items(section):
                if value == "":
                    config.set(section, key, "None")

        # Sauvegarder dans le fichier
        import importlib.resources

        with importlib.resources.path(
            "querycraft.config", "config-sbs.cfg"
        ) as config_file:
            with open(config_file, "w") as f:
                config.write(f)

        # Recharger la configuration

        config = readConfigFile()

        return jsonify(
            {"success": True, "message": "Configuration sauvegardée avec succès"}
        )

    except Exception as e:
        import traceback

        return jsonify(
            {
                "success": False,
                "error": f"Erreur lors de la sauvegarde : {str(e)}",
                "traceback": traceback.format_exc(),
            }
        )


@app.route("/credits")
def credits():
    """Page des crédits et informations sur l'application"""
    system_info = get_system_info()
    # reload_config_if_changed()
    return render_template(
        "credits.html",
        version=__version__,
        system_info=system_info,
    )


@app.route("/didapro11")
def didapro11():
    """Page des crédits et informations sur l'application"""
    system_info = get_system_info()
    # reload_config_if_changed()
    return render_template(
        "didapro11.html",
        version=__version__,
        system_info=system_info,
    )


@app.route("/colquery", methods=["POST"])
def colquery():
    data = request.get_json()
    sql_query = data.get("query", "")

    return jsonify({"success": True, "sql": colorize_sql_html(sql_query)})


@app.route("/")
def index():
    """Page d'accueil avec le formulaire de requête"""
    # reload_config_if_changed()
    db_type = config.get("Database", "type")
    db_name = config.get("Database", "database")
    ia_mode = config.get("IA", "mode", fallback="off")
    ia_service = config.get("IA", "service", fallback="")
    ia_model = config.get("IA", "modele", fallback="")
    exos_mode = config.get("Autre", "exos", fallback="off")
    de = " display: none;" if exos_mode == "off" else " display: block;"
    system_info = get_system_info()

    ia_serv = f"{ia_service}/{ia_model}" if ia_service and ia_model else "Absent"

    return render_template(
        "index.html",
        db_type=db_type,
        db_name=db_name,
        ia_mode=ia_mode,
        ia_service=ia_serv,
        version=__version__,
        display_exos=de,
        system_info=system_info,
        exos_mode=exos_mode,
    )


@app.route("/bdactive", methods=["POST"])
def bdalive():
    """Vérifie si la base de données est
    accessible et retourne le résultat"""
    data = request.get_json()
    dbtype = data.get("dbtype", "")
    dbname = data.get("dbname", "")
    dbuser = data.get("dbuser", "")
    dbpass = data.get("dbpass", "")
    dbhost = data.get("dbhost", "")
    dbport = data.get("dbport", "")

    result = evalBD(dbtype, dbname, dbuser, dbpass, dbhost, dbport)
    return jsonify({"success": result})


"""
curl http://localhost:8080/bdactive -H "Content-Type: application/json" -H "Accept: application/json" \
 -d '{"dbtype": "sqlite", "dbname": "cours.db"}'
"""


@app.route("/iaalive", methods=["POST"])
def iaalive():
    """Vérifie si le service IA est accessible et retourne le résultat"""
    # log = get_logger("iaalive")
    data = request.get_json()
    ia_service = data.get("ia_service", "ollama")
    ia_model = data.get("ia_model", "gemma3:4b")
    ia_url = data.get("ia_url", "None")
    ia_api = data.get("ia_api", "None")

    (result, defllm) = evalIA(ia_service, ia_model, ia_url, ia_api)
    return jsonify({"success": result or defllm, "def": result})


"""
curl http://localhost:8080/iaalive -H "Content-Type: application/json" -H "Accept: application/json" \
 -d '{"ia_service": "ollama", "ia_model": "gemma3:4b"}'
"""


@app.route("/execute", methods=["POST"])
def execute():
    """Exécute la requête SQL et retourne le résultat"""
    # reload_config_if_changed()
    data = request.get_json()
    print(f"Requête reçue: {data}")
    sql_query = data.get("query", "").strip()
    step_by_step = data.get("step_by_step", True)
    verbose = data.get("verbose", False) and config.getboolean(
        "Autre", "verbose", fallback=False
    )
    code_ex = data.get("code_ex", None)
    code_q = data.get("code_q", None)

    if not sql_query:
        return jsonify({"success": False, "error": "Veuillez entrer une requête SQL"})

    result = execute_query_sbs(sql_query, step_by_step, verbose, code_ex, code_q)
    return jsonify(result)


@app.route("/schema", methods=["POST"])
def schema():
    """Affiche le schéma de la base de données"""
    # reload_config_if_changed()
    data = request.get_json()
    verbose = data.get("verbose", False) and config.getboolean(
        "Autre", "verbose", fallback=False
    )

    try:
        debug = config.getboolean("Autre", "debug", fallback=False)
        # verbose = verbose or config.getboolean('Autre', 'verbose', fallback=False)
        log = get_logger("describe")
        SQLQueryException.setCfg(config)

        # Présentation du schéma de la base de données
        db = get_database_from_config(
            config, debug=debug, verbose=verbose, output="html"
        )
        puml = plm.PlantUML(db)
        pumlfile = puml.createModel() #{{ url_for('static', filename='models/{pumlfile}') }}
        if pumlfile is None:
            img_url = None
        else:
            img_url = f'/static/images/{pumlfile}' #url_for("static", filename=f"images/{pumlfile}.png")
        (base, ia) = db.describe(config, output="html")

        basehtml=\
f"""
<div class="inline-box">
    <div>
       <h4>Modèle relationnel de la base</h4>
        <img src="{img_url}" alt="{db.name}" style="max-width:85%;">
        <p>Lègende : <ul>
            <li><span class="pk">PK</span> = Clé Primaire, </li>
            <li><span class="fk">#</span> = Clé Étrangère, </li>
        </p>
    </div>
    <div>
        <h4>Description SQL</h4>
       {base} 
    </div>
</div>
{ligne_html}
"""

        schema_html = [
            "<h3>Schéma de la base de données</h3><br/>",
            basehtml,
            ia,
            "<br/>",
            f"<br><h3>Contenu de la base de données</h3><br/><p>Seuls les {MAX_ROWS} premiers enregistrements au maximum sont affichés.</p>",
        ]

        # Exécuter la requête SQL et obtenir les résultats
        for t in db.dbTables:
            sql_query = f"SELECT * FROM {t} ;"
            # Créer l'objet SQL
            sql = SQL(
                db.db,
                db.dbtype,
                None,
                None,
                debug,
                verbose,
                step_by_step=False,
                output="html",
            )
            sql.setSQL(sql_query, True)
            headers, rows = sql.getTable()

            schema_html.append(ligne_html)
            schema_html.append(f'<br><h4>Table "{t}" :</h4>')

            if rows:
                nbr = len(rows)
                (min_rows, msg) = truncate_rows(headers, rows, MAX_ROWS)
                table_html = format_table_2(headers, min_rows, output="html")
                if msg:
                    schema_html.append(f"<p><em>{msg}</em></p>")
                schema_html.append(table_html)
                schema_html.append(
                    f"<p><strong>{nbr} ligne(s) retournée(s)</strong></p>"
                )
            else:
                schema_html.append("<p><em>Aucun résultat</em></p>")

        return jsonify(
            {
                "success": True,
                "html_output": " ".join(schema_html)
                if schema_html
                else "<p><em>Aucun résultat</em></p>",
            }
        )
    except Exception as e:
        import traceback

        return jsonify(
            {
                "success": False,
                "error": f"<strong>Erreur lors de la récupération du schéma :</strong><br>{str(e)}<br><br><pre style='background:#fff3cd;padding:10px;'>{traceback.format_exc()}</pre>",
            }
        )


@app.route("/exercices")
def exercices_page():
    """Page de gestion des exercices"""
    try:
        exercices_list = exos_list()
    except Exception as e:
        print(f"Erreur lors du chargement des exercices : {e}")
        exercices_list = []
    return render_template(
        "exercices.html", exercices=exercices_list, version=__version__
    )


def exos_list():
    # Lister tous les fichiers d'exercices
    exercices_list = []
    with importlib.resources.path("querycraft.exos", "") as exos_dir:
        if os.path.exists(exos_dir):
            for filename in os.listdir(exos_dir):
                if filename.endswith(".json"):
                    code_ex = filename[:-5]  # Retirer .json
                    exercices_list.append(code_ex)
    exercices_list.sort()
    # print(f"Exercices trouvés : {exercices_list}")
    return exercices_list


@app.route("/exercices/list")
def exercices_list_api():
    """API pour lister les exercices"""
    try:
        exercices_list = exos_list()
    except Exception as e:
        return jsonify({"success": False, "error": str(e)})
    return jsonify({"success": True, "exercices": exercices_list})


@app.route("/exercices/<code_ex>")
def exercice_detail(code_ex):
    """API pour obtenir les détails d'un exercice"""
    try:
        exos = loadExos(code_ex)

        # Convertir en format plus lisible
        questions = []
        for code_q, data in exos.items():
            requete, intention, comment, type_q, instructions = data
            questions.append(
                {
                    "code": code_q,
                    "requete": requete,
                    "intention": intention,
                    "comment": comment,
                    "type": type_q,
                    "instructions": instructions,
                }
            )
        return jsonify({"success": True, "code_ex": code_ex, "questions": questions})
    except Exception as e:
        return jsonify({"success": False, "error": str(e)})


@app.route("/exercices/<code_ex>/questions")
def exercice_questions(code_ex):
    """API pour obtenir les questions d'un exercice (sans les requêtes SQL)"""
    try:
        exos = loadExos(code_ex)

        # Vérifier le mode debug et verbose depuis la config
        debug = config.getboolean("Autre", "debug", fallback=False)
        verbose = config.getboolean("Autre", "verbose", fallback=False)

        # Retourner seulement les infos nécessaires (pas la requête SQL)
        questions = []
        for code_q, data in exos.items():
            requete, intention, comment, type_q, instructions = data

            # Récupérer la connexion à la base de données
            db = get_database_from_config(
                config, debug=debug, verbose=verbose, output="html"
            )
            SQLQueryException.setCfg(config)

            # Créer l'objet SQL
            if type_q == "IT->R":
                sql = SQL(
                    db.db, db.dbtype, None, None, debug, verbose, False, output="html"
                )
                sql.setSQL(requete)
                (hd, rows) = sql.getTable()
                table = f"{format_table_2(hd, rows, None, output='html')}\n"
            else:
                table = None

            questions.append(
                {
                    "code": code_q,
                    "intention": intention,
                    "instructions": instructions,
                    "type": type_q,
                    "table_html": table,
                }
            )

        return jsonify({"success": True, "questions": questions})
    except Exception as e:
        return jsonify({"success": False, "error": str(e)})


@app.route("/exercices/<code_ex>/save", methods=["POST"])
def exercice_save(code_ex):
    """Sauvegarde un exercice"""
    try:
        data = request.get_json()
        questions = data.get("questions", [])

        # Convertir en format dict pour saveExos
        exos = {}
        for q in questions:
            exos[q["code"]] = [
                q["requete"],
                q["intention"],
                q["comment"],
                q["type"],
                q["instructions"],
            ]

        saveExos(code_ex, exos)

        # Invalider le cache d'importlib pour que tous les workers voient le nouvel exercice
        importlib.invalidate_caches()
        print(f"[SAVE] Cache invalidé après sauvegarde de {code_ex}")

        return jsonify({"success": True, "message": f"Exercice {code_ex} sauvegardé"})
    except Exception as e:
        import traceback

        return jsonify(
            {"success": False, "error": str(e), "traceback": traceback.format_exc()}
        )


@app.route("/exercices/<code_ex>/delete", methods=["POST"])
def exercice_delete(code_ex):
    """Supprime un exercice"""
    try:
        with importlib.resources.path("querycraft.exos", f"{code_ex}.json") as file:
            if os.path.exists(file):
                os.remove(file)
                # Invalider le cache d'importlib pour que tous les workers voient la suppression
                importlib.invalidate_caches()
                print(f"[DELETE] Cache invalidé après suppression de {code_ex}")
                return jsonify(
                    {"success": True, "message": f"Exercice {code_ex} supprimé"}
                )
            else:
                return jsonify(
                    {"success": False, "error": f"Exercice {code_ex} introuvable"}
                )
    except Exception as e:
        return jsonify({"success": False, "error": str(e)})


@app.route("/exercices/create", methods=["POST"])
def exercice_create():
    """Crée un nouvel exercice"""
    try:
        data = request.get_json()
        code_ex = data.get("code_ex", "").strip()

        if not code_ex:
            return jsonify(
                {"success": False, "error": "Le code de l'exercice est requis"}
            )

        # Vérifier si l'exercice existe déjà
        with importlib.resources.path("querycraft.exos", f"{code_ex}.json") as file:
            if os.path.exists(file):
                return jsonify(
                    {"success": False, "error": f"L'exercice {code_ex} existe déjà"}
                )

        # Créer un exercice vide
        saveExos(code_ex, {})

        return jsonify(
            {"success": True, "message": f"Exercice {code_ex} créé", "code_ex": code_ex}
        )
    except Exception as e:
        return jsonify({"success": False, "error": str(e)})


def main():
    """Point d'entrée principal de l'application web"""
    import argparse

    parser = argparse.ArgumentParser(
        description="Interface web pour QueryCraft (c) E. Desmontils, Nantes Université, 2025"
    )
    # parser.add_argument('--host', default='127.0.0.1', help='Adresse IP du serveur (défaut: 127.0.0.1)')
    parser.add_argument(
        "--host", default="0.0.0.0", help="Adresse IP du serveur (défaut: 0.0.0.0)"
    )
    parser.add_argument(
        "--port", type=int, default=8080, help="Port du serveur (défaut: 8080)"
    )
    parser.add_argument("--debug", action="store_true", help="Mode debug Flask")

    args = parser.parse_args()

    print(f"🚀 QueryCraft {__version__} version Web - Démarrage du serveur...")
    print(
        f"📊 Base de données : {config.get('Database', 'type')} - {config.get('Database', 'database')}"
    )
    print(
        f"🤖 IA : {config.get('IA', 'mode')} ({config.get('IA', 'service')}/{config.get('IA', 'modele')})"
    )
    print(f"🌐 Accès : http://{args.host}:{args.port}")
    print(f"\nAppuyez sur Ctrl+C pour arrêter le serveur")

    app.run(host=args.host, port=args.port, debug=args.debug)


if __name__ == "__main__":
    main()
