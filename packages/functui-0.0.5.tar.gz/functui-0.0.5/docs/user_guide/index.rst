User Guide
==========

.. toctree::
   :maxdepth: 2
   :caption: Contents

   introduction
   glossary
   io
