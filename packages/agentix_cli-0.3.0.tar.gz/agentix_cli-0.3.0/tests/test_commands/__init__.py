"""Tests for agentix commands."""
