"""Tests for Bitbucket integration."""
