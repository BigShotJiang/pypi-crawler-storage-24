"""Comment commands for Jira."""

from agentix.jira.models import normalize_comment
from ._common import _get_client, click, output, success


@click.group("comment")
def comment_group():
    """Manage issue comments."""
    pass


@comment_group.command("list")
@click.argument("issue_key")
@click.pass_context
def comment_list(ctx, issue_key):
    """List comments on an issue."""
    client = _get_client(ctx)
    comments = client.get_comments(issue_key)
    output(ctx, [normalize_comment(c) for c in comments])


@comment_group.command("add")
@click.argument("issue_key")
@click.option("--body", "-b", required=True, help="Comment text.")
@click.pass_context
def comment_add(ctx, issue_key, body):
    """Add a comment to an issue."""
    client = _get_client(ctx)
    result = client.add_comment(issue_key, body)
    success(ctx, 
        f"Added comment to {issue_key}",
        data={"id": result.get("id")},
    )


@comment_group.command("get")
@click.argument("issue_key")
@click.argument("comment_id")
@click.pass_context
def comment_get(ctx, issue_key, comment_id):
    """Get a specific comment."""
    client = _get_client(ctx)
    comment = client.get_comment(issue_key, comment_id)
    output(ctx, normalize_comment(comment))
