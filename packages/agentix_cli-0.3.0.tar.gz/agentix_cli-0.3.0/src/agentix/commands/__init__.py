"""CLI commands for agentix."""
