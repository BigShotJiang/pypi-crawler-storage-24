"""Convert PDF to structured text using Grobid"""

__version__ = "0.6.17"
