from collections import defaultdict
from io import BytesIO
from pathlib import Path
from unittest.mock import patch

import pandas as pd
import pytest
from grobid_client.models import Affiliation, Author, Citation, PersName
from pymultirole_plugins.v1.schema import Document, DocumentList
from starlette.datastructures import Headers, UploadFile

from pyconverters_grobid.grobid import (
    GrobidConverter,
    GrobidParameters,
    InputFormat,
    authors_and_affiliations,
    citation_to_metadata,
)


def test_parameters_defaults():
    params = GrobidParameters()
    assert params.input_format == InputFormat.PDF
    assert params.sourceText is False
    assert params.sentences is False
    assert params.authors_and_affiliations is True
    assert params.figures is False
    assert params.citations is False
    assert params.extract_abstract is False
    assert params.header_regex is None


def test_get_model():
    assert GrobidConverter.get_model() is GrobidParameters


def test_input_format_values():
    assert InputFormat.PDF == "PDF"
    assert InputFormat.URL_List == "URL List"


def test_authors_and_affiliations_full():
    affil = Affiliation(institution="MIT", department="CSAIL", laboratory="AI Lab")
    author = Author(pers_name=PersName(firstname="John", middlename="A", surname="Doe"), affiliations=[affil])
    result = authors_and_affiliations([author])
    assert "John A Doe" in result
    affiliations = result["John A Doe"]
    assert len(affiliations) == 1
    aff_str = next(iter(affiliations))
    assert "MIT" in aff_str
    assert "CSAIL" in aff_str
    assert "AI Lab" in aff_str


def test_authors_and_affiliations_no_affiliation():
    author = Author(pers_name=PersName(firstname="Jane", surname="Smith"))
    result = authors_and_affiliations([author])
    assert "Jane Smith" in result
    assert result["Jane Smith"] == set()


def test_authors_and_affiliations_empty():
    result = authors_and_affiliations([])
    assert result == {}


def test_citation_to_metadata_basic():
    params = GrobidParameters()
    citation = Citation(main_title="Test Paper", publisher="Elsevier")
    meta = citation_to_metadata(citation, params)
    assert meta["main_title"] == "Test Paper"
    assert meta["publisher"] == "Elsevier"


def test_citation_to_metadata_with_authors():
    params = GrobidParameters(authors_and_affiliations=True)
    affil = Affiliation(institution="CNRS")
    author = Author(pers_name=PersName(firstname="Alice", surname="Martin"), affiliations=[affil])
    citation = Citation(main_title="Study", authors=[author])
    meta = citation_to_metadata(citation, params)
    assert "Alice Martin" in meta["authors"]
    assert "CNRS" in meta["affiliations"]
    assert any("Alice Martin" in s for s in meta["authors_and_affiliations"])


def test_citation_to_metadata_without_authors_and_affiliations():
    params = GrobidParameters(authors_and_affiliations=False)
    author = Author(pers_name=PersName(firstname="Bob", surname="Jones"))
    citation = Citation(authors=[author])
    meta = citation_to_metadata(citation, params)
    assert "authors" in meta
    assert "authors_and_affiliations" not in meta


def test_citation_to_metadata_empty():
    params = GrobidParameters()
    citation = Citation()
    meta = citation_to_metadata(citation, params)
    assert meta == {}


def test_convert_error_returns_empty():
    """When Grobid is unreachable, convert() returns [] and logs a warning."""
    converter = GrobidConverter()
    params = GrobidParameters()
    upload = UploadFile(
        file=BytesIO(b"%PDF"),
        filename="test.pdf",
        headers=Headers({"content-type": "application/pdf"}),
    )
    with (
        patch("pyconverters_grobid.grobid.get_client"),
        patch("pyconverters_grobid.grobid.file_to_doc", side_effect=RuntimeError("connection refused")),
    ):
        docs = converter.convert(upload, params)
    assert docs == []


def test_grobid_pdf():
    converter = GrobidConverter()
    parameters = GrobidParameters(sentences=True, citations=True)
    testdir = Path(__file__).parent
    source = Path(testdir, "data/PMC1636350.pdf")
    with source.open("rb") as fin:
        docs: list[Document] = converter.convert(
            UploadFile(file=fin, filename=source.name, headers=Headers({"content-type": "application/pdf"})), parameters
        )
    assert len(docs) == 1
    assert docs[0].identifier
    assert docs[0].text
    assert docs[0].title
    assert "TITLE" in docs[0].boundaries
    assert docs[0].annotations
    assert docs[0].sentences
    assert len(docs[0].annotations[0].terms) == 1
    json_file = source.with_suffix(".json")
    dl = DocumentList(root=docs)
    with json_file.open("w") as fout:
        print(dl.model_dump_json(exclude_none=True, exclude_unset=True, indent=2), file=fout)


def test_grobid_pdf2():
    converter = GrobidConverter()
    parameters = GrobidParameters(sentences=True, citations=True, figures=True, header_regex="(?i)materials .* methods")
    testdir = Path(__file__).parent
    source = Path(testdir, "data/PMC1636350.pdf")
    with source.open("rb") as fin:
        docs: list[Document] = converter.convert(
            UploadFile(file=fin, filename=source.name, headers=Headers({"content-type": "application/pdf"})), parameters
        )
    assert len(docs) == 1
    assert docs[0].identifier
    assert docs[0].text.startswith("MATERIALS")
    assert docs[0].title
    assert "MATERIALS AND METHODS" in docs[0].boundaries
    assert docs[0].annotations
    assert docs[0].sentences
    assert len(docs[0].annotations[0].terms) == 1
    json_file = source.with_suffix(".json")
    dl = DocumentList(root=docs)
    with json_file.open("w") as fout:
        print(dl.model_dump_json(exclude_none=True, exclude_unset=True, indent=2), file=fout)


def test_grobid_list():
    converter = GrobidConverter()
    parameters = GrobidParameters(
        input_format=InputFormat.URL_List, sentences=True, citations=True, extract_abstract=True
    )
    testdir = Path(__file__).parent
    source = Path(testdir, "data/listpdfs.txt")
    with source.open("rb") as fin:
        docs: list[Document] = converter.convert(
            UploadFile(file=fin, filename=source.name, headers=Headers({"content-type": "text/plain"})), parameters
        )
    assert len(docs) == 2
    assert docs[0].altTexts[0].name == "abstract"


@pytest.mark.skip(reason="Not a test")
def test_grobid_bilit():
    converter = GrobidConverter()
    parameters = GrobidParameters(sentences=True, citations=True, extract_abstract=True)
    testdir = Path(__file__).parent
    # source = Path(testdir, "data/6620d1915967133a8253087d_P20-03940.pdf")
    source = Path(testdir, "data/Anthelmintic.Resistance.pdf")
    with source.open("rb") as fin:
        docs: list[Document] = converter.convert(
            UploadFile(file=fin, filename=source.name, headers=Headers({"content-type": "application/pdf"})), parameters
        )
    assert len(docs) == 1
    assert docs[0].identifier
    assert docs[0].text
    assert docs[0].title
    assert "TITLE" in docs[0].boundaries
    assert docs[0].annotations
    assert docs[0].sentences
    json_file = source.with_suffix(".json")
    dl = DocumentList(root=docs)
    with json_file.open("w") as fout:
        print(dl.model_dump_json(exclude_none=True, exclude_unset=True, indent=2), file=fout)


@pytest.mark.skip(reason="Not a test")
def test_ifpen():
    from langdetect import detect

    data = defaultdict(list)
    converter = GrobidConverter()
    parameters = GrobidParameters(sentences=True, citations=True, extract_abstract=True)
    testdir = Path("/media/olivier/DATA/corpora/IFPEN/PublicationGael")
    year = "2020"
    sourcedir = testdir / year
    source = testdir / f"{year}.csv"
    lines = pd.read_csv(source, sep=";", header=0)
    for _index, row in lines.iterrows():
        cptId = row["cptId"]
        filename = row["filename"]
        titre = row["Titre"]
        codeE = row["codeE"]
        codeA = row["codeA"]
        lang = detect(titre)
        pdffile = sourcedir / codeE
        if pdffile.exists():
            with pdffile.open("rb") as fin:
                upload = UploadFile(file=fin, filename=filename, headers=Headers({"content-type": "application/pdf"}))
                docs: list[Document] = converter.convert(upload, parameters)
                if len(docs) == 1:
                    doc = docs[0]
                    doc.title = titre
                    doc.identifier = cptId
                    doc.metadata["codeA"] = codeA
                    doc.metadata["codeE"] = codeE
                    doc.metadata["year"] = year
                    data[lang].append(doc)
                else:
                    print(f"Error with file: {pdffile}")
    for lang, docs in data.items():
        json_file = testdir / f"{year}_{lang}.json"
        dl = DocumentList(root=docs)
        with json_file.open("w") as fout:
            print(dl.model_dump_json(exclude_none=True, exclude_unset=True, indent=2), file=fout)
