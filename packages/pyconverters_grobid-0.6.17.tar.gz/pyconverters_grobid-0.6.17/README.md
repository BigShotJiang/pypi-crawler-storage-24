# pyconverters_grobid

[![license](https://img.shields.io/github/license/oterrier/pyconverters_grobid)](https://github.com/oterrier/pyconverters_grobid/blob/master/LICENSE)
[![tests](https://github.com/oterrier/pyconverters_grobid/workflows/tests/badge.svg)](https://github.com/oterrier/pyconverters_grobid/actions?query=workflow%3Atests)
[![codecov](https://img.shields.io/codecov/c/github/oterrier/pyconverters_grobid)](https://codecov.io/gh/oterrier/pyconverters_grobid)
[![docs](https://img.shields.io/readthedocs/pyconverters_grobid)](https://pyconverters_grobid.readthedocs.io)
[![version](https://img.shields.io/pypi/v/pyconverters_grobid)](https://pypi.org/project/pyconverters_grobid/)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/pyconverters_grobid)](https://pypi.org/project/pyconverters_grobid/)

Convert PDF to structured text using [Grobid](https://github.com/kermitt2/grobid)

## Installation

You can simply `pip install pyconverters_grobid`.

## Developing

### Pre-requisites

You will need to install [uv](https://docs.astral.sh/uv/) (for managing the virtual environment and running tasks):

```
pip install uv
```

Clone the repository:

```
git clone https://github.com/oterrier/pyconverters_grobid
```

Install dependencies (including test extras):

```
uv sync --extra test
```

### Running the test suite

```
uv run pytest
```

### Linting

```
uv run ruff check .
uv run ruff format --check .
```

### Building the documentation

```
uv run --extra docs sphinx-build docs docs/_build
```

The built documentation is available at `docs/_build/index.html`.

## SBOM & vulnerability check

Install the SBOM dependencies:

```
uv sync --extra sbom
```

Generate a CycloneDX SBOM from the current environment:

```
uv run cyclonedx-py environment -o sbom.cdx.json --output-format json
```

Audit dependencies for known vulnerabilities:

```
uv run pip-audit --format json --output audit-report.json
```

To fail on any known vulnerability (useful in CI):

```
uv run pip-audit --strict
```
