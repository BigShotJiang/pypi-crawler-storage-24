# fw-nodes-postgres

PostgreSQL database nodes for Flowire workflow automation.

## Nodes

- **Postgres Raw Query** — Execute raw SQL with a code editor and parameterized values
- **Postgres Select** — Structured query builder for SELECT operations
- **Postgres Insert** — Insert single or bulk rows
- **Postgres Update** — Update rows with required WHERE conditions
- **Postgres Delete** — Delete rows with required WHERE conditions
