"""Tests for the Postgres Select node query builder."""

import pytest

from fw_nodes_postgres.nodes.select import _build_select_query


class TestBuildSelectQuery:
    def test_simple_select_all(self):
        query, params = _build_select_query({"table": "users", "columns": ["*"]})
        assert query == 'SELECT * FROM "users"'
        assert params == []

    def test_select_specific_columns(self):
        query, params = _build_select_query({"table": "users", "columns": ["id", "name", "email"]})
        assert query == 'SELECT "id", "name", "email" FROM "users"'
        assert params == []

    def test_select_with_where_equals(self):
        query, params = _build_select_query({
            "table": "users",
            "columns": ["*"],
            "where": [{"column": "id", "operator": "=", "value": 42}],
        })
        assert query == 'SELECT * FROM "users" WHERE "id" = $1'
        assert params == [42]

    def test_select_with_multiple_where(self):
        query, params = _build_select_query({
            "table": "users",
            "columns": ["*"],
            "where": [
                {"column": "status", "operator": "=", "value": "active"},
                {"column": "age", "operator": ">=", "value": 18},
            ],
        })
        assert query == 'SELECT * FROM "users" WHERE "status" = $1 AND "age" >= $2'
        assert params == ["active", 18]

    def test_select_with_is_null(self):
        query, params = _build_select_query({
            "table": "users",
            "columns": ["*"],
            "where": [{"column": "deleted_at", "operator": "IS NULL"}],
        })
        assert query == 'SELECT * FROM "users" WHERE "deleted_at" IS NULL'
        assert params == []

    def test_select_with_in_operator(self):
        query, params = _build_select_query({
            "table": "users",
            "columns": ["*"],
            "where": [{"column": "role", "operator": "IN", "value": ["admin", "editor"]}],
        })
        assert query == 'SELECT * FROM "users" WHERE "role" IN ($1, $2)'
        assert params == ["admin", "editor"]

    def test_select_with_like(self):
        query, params = _build_select_query({
            "table": "users",
            "columns": ["*"],
            "where": [{"column": "name", "operator": "LIKE", "value": "%john%"}],
        })
        assert query == 'SELECT * FROM "users" WHERE "name" LIKE $1'
        assert params == ["%john%"]

    def test_select_with_order_by(self):
        query, params = _build_select_query({
            "table": "users",
            "columns": ["*"],
            "order_by": [{"column": "created_at", "direction": "DESC"}],
        })
        assert query == 'SELECT * FROM "users" ORDER BY "created_at" DESC'
        assert params == []

    def test_select_with_limit_and_offset(self):
        query, params = _build_select_query({
            "table": "users",
            "columns": ["*"],
            "limit": 10,
            "offset": 20,
        })
        assert query == 'SELECT * FROM "users" LIMIT $1 OFFSET $2'
        assert params == [10, 20]

    def test_full_query(self):
        query, params = _build_select_query({
            "table": "orders",
            "columns": ["id", "total", "status"],
            "where": [
                {"column": "status", "operator": "=", "value": "pending"},
                {"column": "total", "operator": ">", "value": 100},
            ],
            "order_by": [
                {"column": "total", "direction": "DESC"},
                {"column": "id", "direction": "ASC"},
            ],
            "limit": 50,
            "offset": 0,
        })
        assert '"id", "total", "status"' in query
        assert 'FROM "orders"' in query
        assert '"status" = $1 AND "total" > $2' in query
        assert 'ORDER BY "total" DESC, "id" ASC' in query
        assert "LIMIT $3 OFFSET $4" in query
        assert params == ["pending", 100, 50, 0]

    def test_unsupported_operator_raises(self):
        with pytest.raises(ValueError, match="Unsupported operator"):
            _build_select_query({
                "table": "users",
                "columns": ["*"],
                "where": [{"column": "id", "operator": "DROP TABLE", "value": "x"}],
            })
