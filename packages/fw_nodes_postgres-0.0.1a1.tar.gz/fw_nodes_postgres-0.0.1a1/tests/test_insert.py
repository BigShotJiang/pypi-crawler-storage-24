"""Tests for the Postgres Insert node query builder."""

import pytest

from fw_nodes_postgres.nodes.insert import _build_insert_query


class TestBuildInsertQuery:
    def test_single_row_insert(self):
        query, params = _build_insert_query({
            "table": "users",
            "data": {"name": "Alice", "email": "alice@example.com"},
        })
        assert query == 'INSERT INTO "users" ("name", "email") VALUES ($1, $2)'
        assert params == ["Alice", "alice@example.com"]

    def test_bulk_insert(self):
        query, params = _build_insert_query({
            "table": "users",
            "data": [
                {"name": "Alice", "email": "alice@example.com"},
                {"name": "Bob", "email": "bob@example.com"},
            ],
        })
        assert query == 'INSERT INTO "users" ("name", "email") VALUES ($1, $2), ($3, $4)'
        assert params == ["Alice", "alice@example.com", "Bob", "bob@example.com"]

    def test_insert_with_returning(self):
        query, params = _build_insert_query({
            "table": "users",
            "data": {"name": "Alice"},
            "returning": ["id", "created_at"],
        })
        assert query == 'INSERT INTO "users" ("name") VALUES ($1) RETURNING "id", "created_at"'
        assert params == ["Alice"]

    def test_insert_with_none_value(self):
        query, params = _build_insert_query({
            "table": "users",
            "data": {"name": "Alice", "bio": None},
        })
        assert params == ["Alice", None]

    def test_empty_data_raises(self):
        with pytest.raises(ValueError, match="No data provided"):
            _build_insert_query({"table": "users", "data": []})

    def test_empty_row_raises(self):
        with pytest.raises(ValueError, match="No columns provided"):
            _build_insert_query({"table": "users", "data": {}})

    def test_inconsistent_columns_missing(self):
        with pytest.raises(ValueError, match="Row 2 has inconsistent columns.*missing"):
            _build_insert_query({
                "table": "users",
                "data": [
                    {"name": "Alice", "email": "alice@example.com"},
                    {"name": "Bob"},
                ],
            })

    def test_inconsistent_columns_extra(self):
        with pytest.raises(ValueError, match="Row 2 has inconsistent columns.*unexpected"):
            _build_insert_query({
                "table": "users",
                "data": [
                    {"name": "Alice"},
                    {"name": "Bob", "email": "bob@example.com"},
                ],
            })

    def test_consistent_bulk_insert_different_order(self):
        """Same columns in different order should succeed."""
        query, params = _build_insert_query({
            "table": "users",
            "data": [
                {"name": "Alice", "email": "a@test.com"},
                {"email": "b@test.com", "name": "Bob"},
            ],
        })
        # Column order follows first row
        assert '"name", "email"' in query
        assert params == ["Alice", "a@test.com", "Bob", "b@test.com"]
