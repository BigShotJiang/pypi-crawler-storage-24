"""Tests for the Postgres Raw Query node."""

from unittest.mock import AsyncMock, patch

import pytest

from fw_nodes_postgres.nodes.raw_query import RawQueryNode


class TestRawQueryNodeMetadata:
    def test_has_code_editor(self):
        assert RawQueryNode.metadata.code_editor is not None
        assert RawQueryNode.metadata.code_editor.code_field == "query"
        assert RawQueryNode.metadata.code_editor.language_options == ["sql"]

    def test_has_credential_schema(self):
        assert RawQueryNode.credential_schema is not None


class TestRawQueryExecution:
    @pytest.fixture
    def node(self):
        return RawQueryNode()

    @patch("fw_nodes_postgres.nodes.raw_query.execute_query", new_callable=AsyncMock)
    async def test_basic_select(self, mock_execute, node, mock_context_with_credentials):
        mock_execute.return_value = ([{"id": 1, "name": "Alice"}], 1)

        result = await node.execute(
            {"credential_id": "pg-cred-1", "query": "SELECT * FROM users", "params": [], "timeout": 30},
            mock_context_with_credentials,
        )

        assert result.success is True
        assert result.row_count == 1
        assert result.rows == [{"id": 1, "name": "Alice"}]
        assert result.raw_sql == "SELECT * FROM users"
        mock_execute.assert_called_once()

    @patch("fw_nodes_postgres.nodes.raw_query.execute_query", new_callable=AsyncMock)
    async def test_parameterized_query(self, mock_execute, node, mock_context_with_credentials):
        mock_execute.return_value = ([{"id": 5}], 1)

        await node.execute(
            {"credential_id": "pg-cred-1", "query": "SELECT * FROM users WHERE id = $1", "params": [5], "timeout": 30},
            mock_context_with_credentials,
        )

        call_args = mock_execute.call_args
        assert call_args[0][1] == "SELECT * FROM users WHERE id = $1"
        assert call_args[0][2] == [5]

    @patch("fw_nodes_postgres.nodes.raw_query.execute_query", new_callable=AsyncMock)
    async def test_registers_password_as_secret(self, mock_execute, node, mock_context_with_credentials):
        mock_execute.return_value = ([], 0)

        await node.execute(
            {"credential_id": "pg-cred-1", "query": "SELECT 1", "params": [], "timeout": 30},
            mock_context_with_credentials,
        )

        assert "testpass" in mock_context_with_credentials.get_secrets()

    @patch("fw_nodes_postgres.nodes.raw_query.execute_query", new_callable=AsyncMock)
    async def test_passes_timeout(self, mock_execute, node, mock_context_with_credentials):
        mock_execute.return_value = ([], 0)

        await node.execute(
            {"credential_id": "pg-cred-1", "query": "SELECT 1", "params": [], "timeout": 60},
            mock_context_with_credentials,
        )

        call_kwargs = mock_execute.call_args[1]
        assert call_kwargs["timeout"] == 60

    async def test_invalid_credential_raises(self, node, mock_context):
        with pytest.raises(ValueError, match="not found"):
            await node.execute(
                {"credential_id": "nonexistent", "query": "SELECT 1", "params": [], "timeout": 30},
                mock_context,
            )
