"""Shared test fixtures for fw-nodes-postgres tests."""

from typing import Any
from uuid import uuid4

import pytest
from flowire_sdk import NodeExecutionContext


class MockExecutionContext(NodeExecutionContext):
    """Mock execution context for testing nodes."""

    def __init__(
        self,
        workflow_id: str | None = None,
        execution_id: str | None = None,
        node_id: str | None = None,
        project_id: str | None = None,
        user_id: str | None = None,
        node_results: dict[str, dict[str, Any]] | None = None,
        project_variables: dict[str, Any] | None = None,
        credentials: dict[str, dict] | None = None,
    ):
        self.workflow_id = workflow_id or str(uuid4())
        self.execution_id = execution_id or str(uuid4())
        self.node_id = node_id or "test_node"
        self.project_id = project_id or str(uuid4())
        self.user_id = user_id or str(uuid4())
        self.node_results = node_results or {}
        self._secrets: set[str] = set()
        self._project_variables = project_variables or {}
        self._credentials = credentials or {}
        self._data_store: dict[str, str] = {}

    async def resolve_credential(self, credential_id: str, credential_type: str) -> dict:
        if credential_id in self._credentials:
            return self._credentials[credential_id]
        raise ValueError(f"Credential {credential_id} not found")


    async def resolve_credential_by_id(self, credential_id: str) -> dict:
        """Return mock credential by ID or raise if not found."""
        if credential_id in self._credentials:
            return self._credentials[credential_id]
        raise ValueError(f'Credential {credential_id} not found')

    async def resolve_project_variable(self, key: str) -> Any:
        if key in self._project_variables:
            return self._project_variables[key]
        raise ValueError(f"Project variable {key} not found")

    async def resolve_project_variable_by_id(self, variable_id: str) -> Any:
        if variable_id in self._project_variables:
            return self._project_variables[variable_id]
        raise ValueError(f"Project variable {variable_id} not found")

    def register_secret(self, value: str) -> None:
        if value:
            self._secrets.add(value)

    def get_secrets(self) -> set:
        return self._secrets

    async def get_data_store_value(self, key: str) -> str | None:
        return self._data_store.get(key)

    async def set_data_store_value(self, key: str, value: str) -> None:
        self._data_store[key] = value

    async def delete_data_store_value(self, key: str) -> bool:
        if key in self._data_store:
            del self._data_store[key]
            return True
        return False


@pytest.fixture
def mock_context():
    return MockExecutionContext()


@pytest.fixture
def mock_context_with_credentials():
    return MockExecutionContext(
        credentials={
            "pg-cred-1": {
                "host": "localhost",
                "port": 5432,
                "database": "testdb",
                "user": "testuser",
                "password": "testpass",
                "ssl": False,
            }
        }
    )
