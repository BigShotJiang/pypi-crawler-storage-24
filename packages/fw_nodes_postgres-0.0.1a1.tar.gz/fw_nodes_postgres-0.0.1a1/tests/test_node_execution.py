"""Execution-level tests for all Postgres nodes.

Tests the full execute() flow with mocked asyncpg, verifying
credential resolution, secret registration, and output shape.
"""

from unittest.mock import AsyncMock, patch

import pytest

from fw_nodes_postgres.nodes.delete import DeleteNode
from fw_nodes_postgres.nodes.insert import InsertNode
from fw_nodes_postgres.nodes.select import SelectNode
from fw_nodes_postgres.nodes.update import UpdateNode


class TestSelectNodeExecution:
    @pytest.fixture
    def node(self):
        return SelectNode()

    @patch("fw_nodes_postgres.nodes.select.execute_query", new_callable=AsyncMock)
    async def test_basic_select(self, mock_execute, node, mock_context_with_credentials):
        mock_execute.return_value = (
            [{"id": 1, "name": "Alice"}, {"id": 2, "name": "Bob"}],
            2,
        )

        result = await node.execute(
            {"credential_id": "pg-cred-1", "table": "users", "columns": ["*"], "timeout": 30},
            mock_context_with_credentials,
        )

        assert result.success is True
        assert result.row_count == 2
        assert len(result.rows) == 2
        assert 'SELECT * FROM "users"' == result.raw_sql

    @patch("fw_nodes_postgres.nodes.select.execute_query", new_callable=AsyncMock)
    async def test_registers_secret(self, mock_execute, node, mock_context_with_credentials):
        mock_execute.return_value = ([], 0)

        await node.execute(
            {"credential_id": "pg-cred-1", "table": "users", "columns": ["*"], "timeout": 30},
            mock_context_with_credentials,
        )

        assert "testpass" in mock_context_with_credentials.get_secrets()

    @patch("fw_nodes_postgres.nodes.select.execute_query", new_callable=AsyncMock)
    async def test_builds_correct_query(self, mock_execute, node, mock_context_with_credentials):
        mock_execute.return_value = ([], 0)

        await node.execute(
            {
                "credential_id": "pg-cred-1",
                "table": "users",
                "columns": ["id", "name"],
                "where": [{"column": "active", "operator": "=", "value": True}],
                "limit": 10,
                "timeout": 30,
            },
            mock_context_with_credentials,
        )

        query = mock_execute.call_args[0][1]
        assert '"id", "name"' in query
        assert 'FROM "users"' in query
        assert '"active" = $1' in query
        assert "LIMIT $2" in query

    async def test_invalid_credential(self, node, mock_context):
        with pytest.raises(ValueError, match="not found"):
            await node.execute(
                {"credential_id": "bad", "table": "users", "columns": ["*"], "timeout": 30},
                mock_context,
            )


class TestInsertNodeExecution:
    @pytest.fixture
    def node(self):
        return InsertNode()

    @patch("fw_nodes_postgres.nodes.insert.execute_query", new_callable=AsyncMock)
    async def test_single_insert(self, mock_execute, node, mock_context_with_credentials):
        mock_execute.return_value = ([], 1)

        result = await node.execute(
            {
                "credential_id": "pg-cred-1",
                "table": "users",
                "data": {"name": "Alice", "email": "alice@test.com"},
                "timeout": 30,
            },
            mock_context_with_credentials,
        )

        assert result.success is True
        assert result.affected_count == 1
        assert "INSERT INTO" in result.raw_sql

    @patch("fw_nodes_postgres.nodes.insert.execute_query", new_callable=AsyncMock)
    async def test_insert_with_returning(self, mock_execute, node, mock_context_with_credentials):
        mock_execute.return_value = ([{"id": 42}], 1)

        result = await node.execute(
            {
                "credential_id": "pg-cred-1",
                "table": "users",
                "data": {"name": "Alice"},
                "returning": ["id"],
                "timeout": 30,
            },
            mock_context_with_credentials,
        )

        assert result.rows == [{"id": 42}]
        assert "RETURNING" in result.raw_sql


class TestUpdateNodeExecution:
    @pytest.fixture
    def node(self):
        return UpdateNode()

    @patch("fw_nodes_postgres.nodes.update.execute_query", new_callable=AsyncMock)
    async def test_basic_update(self, mock_execute, node, mock_context_with_credentials):
        mock_execute.return_value = ([], 3)

        result = await node.execute(
            {
                "credential_id": "pg-cred-1",
                "table": "users",
                "data": {"status": "inactive"},
                "where": [{"column": "last_login", "operator": "<", "value": "2025-01-01"}],
                "timeout": 30,
            },
            mock_context_with_credentials,
        )

        assert result.success is True
        assert result.affected_count == 3
        assert 'SET "status" = $1' in result.raw_sql
        assert "WHERE" in result.raw_sql

    @patch("fw_nodes_postgres.nodes.update.execute_query", new_callable=AsyncMock)
    async def test_registers_secret(self, mock_execute, node, mock_context_with_credentials):
        mock_execute.return_value = ([], 0)

        await node.execute(
            {
                "credential_id": "pg-cred-1",
                "table": "users",
                "data": {"x": 1},
                "where": [{"column": "id", "operator": "=", "value": 1}],
                "timeout": 30,
            },
            mock_context_with_credentials,
        )

        assert "testpass" in mock_context_with_credentials.get_secrets()


class TestDeleteNodeExecution:
    @pytest.fixture
    def node(self):
        return DeleteNode()

    @patch("fw_nodes_postgres.nodes.delete.execute_query", new_callable=AsyncMock)
    async def test_basic_delete(self, mock_execute, node, mock_context_with_credentials):
        mock_execute.return_value = ([], 5)

        result = await node.execute(
            {
                "credential_id": "pg-cred-1",
                "table": "sessions",
                "where": [{"column": "expired", "operator": "=", "value": True}],
                "timeout": 30,
            },
            mock_context_with_credentials,
        )

        assert result.success is True
        assert result.affected_count == 5
        assert "DELETE FROM" in result.raw_sql
        assert "WHERE" in result.raw_sql

    @patch("fw_nodes_postgres.nodes.delete.execute_query", new_callable=AsyncMock)
    async def test_delete_with_returning(self, mock_execute, node, mock_context_with_credentials):
        mock_execute.return_value = ([{"id": 1}, {"id": 2}], 2)

        result = await node.execute(
            {
                "credential_id": "pg-cred-1",
                "table": "users",
                "where": [{"column": "active", "operator": "=", "value": False}],
                "returning": ["id"],
                "timeout": 30,
            },
            mock_context_with_credentials,
        )

        assert result.rows == [{"id": 1}, {"id": 2}]
        assert result.affected_count == 2
