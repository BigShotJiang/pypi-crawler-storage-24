"""Tests for database utility functions."""

from datetime import datetime
from decimal import Decimal
from uuid import UUID

import pytest

from fw_nodes_postgres.utils.db import (
    _parse_command_tag,
    _serialize_value,
    build_where_clause,
    sanitize_identifier,
    serialize_rows,
)


class TestSanitizeIdentifier:
    def test_simple_name(self):
        assert sanitize_identifier("users") == '"users"'

    def test_name_with_quotes(self):
        assert sanitize_identifier('user"name') == '"user""name"'

    def test_empty_name(self):
        assert sanitize_identifier("") == '""'


class TestBuildWhereClause:
    def test_equals(self):
        sql, params, idx = build_where_clause(
            [{"column": "id", "operator": "=", "value": 42}]
        )
        assert sql == 'WHERE "id" = $1'
        assert params == [42]
        assert idx == 2

    def test_multiple_conditions(self):
        sql, params, idx = build_where_clause([
            {"column": "status", "operator": "=", "value": "active"},
            {"column": "age", "operator": ">=", "value": 18},
        ])
        assert sql == 'WHERE "status" = $1 AND "age" >= $2'
        assert params == ["active", 18]
        assert idx == 3

    def test_is_null(self):
        sql, params, idx = build_where_clause(
            [{"column": "deleted_at", "operator": "IS NULL"}]
        )
        assert sql == 'WHERE "deleted_at" IS NULL'
        assert params == []
        assert idx == 1

    def test_is_not_null(self):
        sql, params, idx = build_where_clause(
            [{"column": "email", "operator": "IS NOT NULL"}]
        )
        assert sql == 'WHERE "email" IS NOT NULL'
        assert params == []

    def test_in_operator_list(self):
        sql, params, idx = build_where_clause(
            [{"column": "role", "operator": "IN", "value": ["admin", "editor"]}]
        )
        assert sql == 'WHERE "role" IN ($1, $2)'
        assert params == ["admin", "editor"]
        assert idx == 3

    def test_in_operator_single_value(self):
        sql, params, idx = build_where_clause(
            [{"column": "id", "operator": "IN", "value": 1}]
        )
        assert sql == 'WHERE "id" IN ($1)'
        assert params == [1]

    def test_like(self):
        sql, params, _ = build_where_clause(
            [{"column": "name", "operator": "LIKE", "value": "%john%"}]
        )
        assert sql == 'WHERE "name" LIKE $1'
        assert params == ["%john%"]

    def test_ilike(self):
        sql, params, _ = build_where_clause(
            [{"column": "name", "operator": "ilike", "value": "%john%"}]
        )
        assert sql == 'WHERE "name" ILIKE $1'
        assert params == ["%john%"]

    def test_custom_start_param_idx(self):
        sql, params, idx = build_where_clause(
            [{"column": "id", "operator": "=", "value": 1}],
            param_idx=5,
        )
        assert sql == 'WHERE "id" = $5'
        assert params == [1]
        assert idx == 6

    def test_unsupported_operator_raises(self):
        with pytest.raises(ValueError, match="Unsupported operator"):
            build_where_clause(
                [{"column": "id", "operator": "DROP TABLE", "value": "x"}]
            )

    def test_default_operator_is_equals(self):
        sql, params, _ = build_where_clause(
            [{"column": "id", "value": 1}]
        )
        assert sql == 'WHERE "id" = $1'
        assert params == [1]


class TestParseCommandTag:
    def test_delete_tag(self):
        assert _parse_command_tag("DELETE 3") == 3

    def test_update_tag(self):
        assert _parse_command_tag("UPDATE 10") == 10

    def test_insert_tag(self):
        assert _parse_command_tag("INSERT 0 1") == 1

    def test_unknown_tag(self):
        assert _parse_command_tag("BEGIN") == 0


class TestSerializeValue:
    def test_none(self):
        assert _serialize_value(None) is None

    def test_primitives(self):
        assert _serialize_value("hello") == "hello"
        assert _serialize_value(42) == 42
        assert _serialize_value(3.14) == 3.14
        assert _serialize_value(True) is True

    def test_uuid(self):
        uid = UUID("12345678-1234-5678-1234-567812345678")
        assert _serialize_value(uid) == "12345678-1234-5678-1234-567812345678"

    def test_datetime(self):
        dt = datetime(2025, 1, 15, 10, 30, 0)
        assert _serialize_value(dt) == "2025-01-15 10:30:00"

    def test_decimal_fractional(self):
        assert _serialize_value(Decimal("19.99")) == 19.99
        assert isinstance(_serialize_value(Decimal("19.99")), float)

    def test_decimal_whole(self):
        assert _serialize_value(Decimal("42")) == 42
        assert isinstance(_serialize_value(Decimal("42")), int)

    def test_bool_not_coerced_to_int(self):
        assert _serialize_value(True) is True
        assert _serialize_value(False) is False
        assert isinstance(_serialize_value(True), bool)

    def test_list(self):
        assert _serialize_value([1, "two", None]) == [1, "two", None]

    def test_nested_dict(self):
        assert _serialize_value({"a": Decimal("1.5")}) == {"a": 1.5}


class TestSerializeRows:
    def test_empty(self):
        assert serialize_rows([]) == []

    def test_basic_rows(self):
        rows = [
            {"id": 1, "name": "Alice", "created": datetime(2025, 1, 1)},
            {"id": 2, "name": "Bob", "created": datetime(2025, 6, 15)},
        ]
        result = serialize_rows(rows)
        assert result[0]["id"] == 1
        assert result[0]["name"] == "Alice"
        assert isinstance(result[0]["created"], str)
