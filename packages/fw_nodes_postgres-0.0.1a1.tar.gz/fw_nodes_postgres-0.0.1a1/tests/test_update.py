"""Tests for the Postgres Update node query builder."""

import pytest

from fw_nodes_postgres.nodes.update import _build_update_query


class TestBuildUpdateQuery:
    def test_simple_update(self):
        query, params = _build_update_query({
            "table": "users",
            "data": {"name": "Bob"},
            "where": [{"column": "id", "operator": "=", "value": 1}],
        })
        assert query == 'UPDATE "users" SET "name" = $1 WHERE "id" = $2'
        assert params == ["Bob", 1]

    def test_update_multiple_columns(self):
        query, params = _build_update_query({
            "table": "users",
            "data": {"name": "Bob", "email": "bob@new.com"},
            "where": [{"column": "id", "operator": "=", "value": 1}],
        })
        assert 'SET "name" = $1, "email" = $2' in query
        assert 'WHERE "id" = $3' in query
        assert params == ["Bob", "bob@new.com", 1]

    def test_update_with_returning(self):
        query, params = _build_update_query({
            "table": "users",
            "data": {"status": "active"},
            "where": [{"column": "id", "operator": "=", "value": 5}],
            "returning": ["id", "status", "updated_at"],
        })
        assert query.endswith('RETURNING "id", "status", "updated_at"')

    def test_update_with_in_where(self):
        query, params = _build_update_query({
            "table": "users",
            "data": {"active": False},
            "where": [{"column": "id", "operator": "IN", "value": [1, 2, 3]}],
        })
        assert '"id" IN ($2, $3, $4)' in query
        assert params == [False, 1, 2, 3]

    def test_empty_data_raises(self):
        with pytest.raises(ValueError, match="No data provided"):
            _build_update_query({
                "table": "users",
                "data": {},
                "where": [{"column": "id", "operator": "=", "value": 1}],
            })
