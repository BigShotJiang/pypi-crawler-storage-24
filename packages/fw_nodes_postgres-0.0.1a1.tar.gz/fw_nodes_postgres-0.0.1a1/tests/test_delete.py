"""Tests for the Postgres Delete node query builder."""

from fw_nodes_postgres.nodes.delete import _build_delete_query


class TestBuildDeleteQuery:
    def test_simple_delete(self):
        query, params = _build_delete_query({
            "table": "users",
            "where": [{"column": "id", "operator": "=", "value": 42}],
        })
        assert query == 'DELETE FROM "users" WHERE "id" = $1'
        assert params == [42]

    def test_delete_with_multiple_conditions(self):
        query, params = _build_delete_query({
            "table": "sessions",
            "where": [
                {"column": "user_id", "operator": "=", "value": 1},
                {"column": "expired_at", "operator": "IS NOT NULL"},
            ],
        })
        assert query == 'DELETE FROM "sessions" WHERE "user_id" = $1 AND "expired_at" IS NOT NULL'
        assert params == [1]

    def test_delete_with_returning(self):
        query, params = _build_delete_query({
            "table": "users",
            "where": [{"column": "id", "operator": "=", "value": 1}],
            "returning": ["id", "email"],
        })
        assert query == 'DELETE FROM "users" WHERE "id" = $1 RETURNING "id", "email"'
        assert params == [1]

    def test_delete_with_in(self):
        query, params = _build_delete_query({
            "table": "logs",
            "where": [{"column": "level", "operator": "IN", "value": ["debug", "trace"]}],
        })
        assert query == 'DELETE FROM "logs" WHERE "level" IN ($1, $2)'
        assert params == ["debug", "trace"]
