"""PostgreSQL nodes for Flowire workflow automation."""
