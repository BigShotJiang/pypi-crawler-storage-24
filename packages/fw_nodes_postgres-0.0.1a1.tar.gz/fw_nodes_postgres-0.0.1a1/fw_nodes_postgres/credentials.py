"""Shared credential schema for PostgreSQL nodes."""

from typing import ClassVar

from pydantic import BaseModel, Field


class PostgresCredentialSchema(BaseModel):
    """Credential schema for PostgreSQL database connections.

    Shared across all PostgreSQL nodes in this package.
    """

    credential_name: ClassVar[str] = "PostgreSQL"
    credential_description: ClassVar[str] = "PostgreSQL database connection details"
    credential_icon: ClassVar[str | None] = "database"

    host: str = Field(..., description="Database host (e.g., localhost or db.example.com)")
    port: int = Field(default=5432, description="Database port")
    database: str = Field(..., description="Database name")
    user: str = Field(..., description="Database user")
    password: str = Field(..., description="Database password")
    ssl: bool = Field(default=False, description="Use SSL/TLS connection")
