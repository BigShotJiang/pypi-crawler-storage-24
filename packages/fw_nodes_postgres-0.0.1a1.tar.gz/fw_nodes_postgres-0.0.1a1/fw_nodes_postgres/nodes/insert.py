"""Structured INSERT node for PostgreSQL."""

from typing import Any

from flowire_sdk import BaseNode, BaseNodeOutput, InputField, NodeExecutionContext, NodeMetadata
from flowire_sdk.node_base import FieldOption
from pydantic import BaseModel, Field

from fw_nodes_postgres.credentials import PostgresCredentialSchema
from fw_nodes_postgres.utils.db import (
    execute_query,
    pg_field_options,
    qualify_table,
    sanitize_identifier,
    serialize_rows,
)


class InsertInput(BaseModel):
    credential_id: str = InputField(..., description="PostgreSQL credential")
    schema: str | None = InputField(
        default=None,
        description="PostgreSQL schema (defaults to search_path, usually 'public')",
        dynamic_options=["credential_id"],
    )
    table: str = InputField(
        ...,
        description="Table to insert into",
        dynamic_options=["credential_id", "schema"],
    )
    data: dict[str, Any] | list[dict[str, Any]] = InputField(
        ...,
        description="Row data as key-value pairs, or a list of rows for bulk insert",
    )
    returning: list[str] = InputField(
        default_factory=list,
        description="Columns to return from inserted rows (e.g., ['id', 'created_at'])",
    )
    timeout: int = InputField(default=30, ge=1, le=300, description="Query timeout in seconds")


class InsertOutput(BaseNodeOutput):
    rows: list[dict[str, Any]] = Field(..., description="Returned rows (if RETURNING was specified)")
    affected_count: int = Field(..., description="Number of rows inserted")
    success: bool = Field(..., description="Whether the insert executed successfully")
    raw_sql: str = Field(..., description="The generated SQL query (with $N placeholders)")


class InsertNode(BaseNode):
    """Insert rows into a PostgreSQL table."""

    input_schema = InsertInput
    output_schema = InsertOutput
    credential_schema = PostgresCredentialSchema

    metadata = NodeMetadata(
        name="Postgres Insert",
        description="Insert rows into a PostgreSQL table",
        category="database",
        icon="database",
        color="#336791",
    )

    async def get_field_options(
        self,
        field_name: str,
        credential_data: dict[str, Any] | None = None,
        field_values: dict[str, Any] | None = None,
    ) -> list[FieldOption]:
        return await pg_field_options(field_name, credential_data, field_values)

    async def execute_logic(
        self,
        validated_inputs: dict[str, Any],
        context: NodeExecutionContext,
    ) -> InsertOutput:
        credential_data = await context.resolve_credential(
            credential_id=validated_inputs["credential_id"],
            credential_type=self.get_credential_type(),
        )
        context.register_secret(credential_data["password"])

        query, params = _build_insert_query(validated_inputs)
        timeout = validated_inputs.get("timeout", 30)

        rows, row_count = await execute_query(credential_data, query, params, timeout=timeout)
        return InsertOutput(
            rows=serialize_rows(rows),
            affected_count=row_count,
            success=True,
            raw_sql=query,
        )


def _build_insert_query(inputs: dict[str, Any]) -> tuple[str, list[Any]]:
    """Build a parameterized INSERT query from structured inputs."""
    table = qualify_table(inputs["table"], inputs.get("schema"))
    data = inputs["data"]

    # Normalize to list of rows
    rows_data = data if isinstance(data, list) else [data]
    if not rows_data:
        raise ValueError("No data provided for insert")

    # Use column order from the first row
    columns = list(rows_data[0].keys())
    if not columns:
        raise ValueError("No columns provided for insert")

    # Validate all rows have the same columns
    expected = set(columns)
    for i, row in enumerate(rows_data[1:], start=2):
        actual = set(row.keys())
        if actual != expected:
            missing = expected - actual
            extra = actual - expected
            parts = []
            if missing:
                parts.append(f"missing {missing}")
            if extra:
                parts.append(f"unexpected {extra}")
            raise ValueError(f"Row {i} has inconsistent columns: {', '.join(parts)}")

    col_str = ", ".join(sanitize_identifier(c) for c in columns)

    params: list[Any] = []
    value_groups: list[str] = []
    param_idx = 1

    for row in rows_data:
        placeholders = []
        for col in columns:
            placeholders.append(f"${param_idx}")
            params.append(row.get(col))
            param_idx += 1
        value_groups.append(f"({', '.join(placeholders)})")

    query = f"INSERT INTO {table} ({col_str}) VALUES {', '.join(value_groups)}"

    # RETURNING
    returning = inputs.get("returning") or []
    if returning:
        ret_str = ", ".join(sanitize_identifier(c) for c in returning)
        query += f" RETURNING {ret_str}"

    return query, params
