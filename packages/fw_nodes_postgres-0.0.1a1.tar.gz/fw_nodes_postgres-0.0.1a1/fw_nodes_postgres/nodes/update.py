"""Structured UPDATE node for PostgreSQL."""

from typing import Any

from flowire_sdk import BaseNode, BaseNodeOutput, InputField, NodeExecutionContext, NodeMetadata
from flowire_sdk.node_base import FieldOption
from pydantic import BaseModel, Field

from fw_nodes_postgres.credentials import PostgresCredentialSchema
from fw_nodes_postgres.utils.db import (
    WhereCondition,
    build_where_clause,
    execute_query,
    pg_field_options,
    qualify_table,
    sanitize_identifier,
    serialize_rows,
)


class UpdateInput(BaseModel):
    credential_id: str = InputField(..., description="PostgreSQL credential")
    schema: str | None = InputField(
        default=None,
        description="PostgreSQL schema (defaults to search_path, usually 'public')",
        dynamic_options=["credential_id"],
    )
    table: str = InputField(
        ...,
        description="Table to update",
        dynamic_options=["credential_id", "schema"],
    )
    data: dict[str, Any] = InputField(..., description="Column values to set (key-value pairs)")
    where: list[WhereCondition] = InputField(
        ...,
        min_length=1,
        description="WHERE conditions (at least one required to prevent accidental full-table updates)",
    )
    returning: list[str] = InputField(
        default_factory=list,
        description="Columns to return from updated rows",
    )
    timeout: int = InputField(default=30, ge=1, le=300, description="Query timeout in seconds")


class UpdateOutput(BaseNodeOutput):
    rows: list[dict[str, Any]] = Field(..., description="Returned rows (if RETURNING was specified)")
    affected_count: int = Field(..., description="Number of rows updated")
    success: bool = Field(..., description="Whether the update executed successfully")
    raw_sql: str = Field(..., description="The generated SQL query (with $N placeholders)")


class UpdateNode(BaseNode):
    """Update rows in a PostgreSQL table."""

    input_schema = UpdateInput
    output_schema = UpdateOutput
    credential_schema = PostgresCredentialSchema

    metadata = NodeMetadata(
        name="Postgres Update",
        description="Update rows in a PostgreSQL table",
        category="database",
        icon="database",
        color="#336791",
    )

    async def get_field_options(
        self,
        field_name: str,
        credential_data: dict[str, Any] | None = None,
        field_values: dict[str, Any] | None = None,
    ) -> list[FieldOption]:
        return await pg_field_options(field_name, credential_data, field_values)

    async def execute_logic(
        self,
        validated_inputs: dict[str, Any],
        context: NodeExecutionContext,
    ) -> UpdateOutput:
        credential_data = await context.resolve_credential(
            credential_id=validated_inputs["credential_id"],
            credential_type=self.get_credential_type(),
        )
        context.register_secret(credential_data["password"])

        query, params = _build_update_query(validated_inputs)
        timeout = validated_inputs.get("timeout", 30)

        rows, row_count = await execute_query(credential_data, query, params, timeout=timeout)
        return UpdateOutput(
            rows=serialize_rows(rows),
            affected_count=row_count,
            success=True,
            raw_sql=query,
        )


def _build_update_query(inputs: dict[str, Any]) -> tuple[str, list[Any]]:
    """Build a parameterized UPDATE query from structured inputs."""
    table = qualify_table(inputs["table"], inputs.get("schema"))
    data = inputs["data"]

    if not data:
        raise ValueError("No data provided for update")

    params: list[Any] = []
    param_idx = 1

    # SET clause
    set_parts = []
    for col, val in data.items():
        set_parts.append(f"{sanitize_identifier(col)} = ${param_idx}")
        params.append(val)
        param_idx += 1

    # WHERE clause (required)
    where_sql, where_params, param_idx = build_where_clause(inputs["where"], param_idx)
    params.extend(where_params)

    query = f"UPDATE {table} SET {', '.join(set_parts)} {where_sql}"

    # RETURNING
    returning = inputs.get("returning") or []
    if returning:
        ret_str = ", ".join(sanitize_identifier(c) for c in returning)
        query += f" RETURNING {ret_str}"

    return query, params
