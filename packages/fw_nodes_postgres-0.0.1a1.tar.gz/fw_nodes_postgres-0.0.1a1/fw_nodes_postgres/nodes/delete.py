"""Structured DELETE node for PostgreSQL."""

from typing import Any

from flowire_sdk import BaseNode, BaseNodeOutput, InputField, NodeExecutionContext, NodeMetadata
from flowire_sdk.node_base import FieldOption
from pydantic import BaseModel, Field

from fw_nodes_postgres.credentials import PostgresCredentialSchema
from fw_nodes_postgres.utils.db import (
    WhereCondition,
    build_where_clause,
    execute_query,
    pg_field_options,
    qualify_table,
    sanitize_identifier,
    serialize_rows,
)


class DeleteInput(BaseModel):
    credential_id: str = InputField(..., description="PostgreSQL credential")
    schema: str | None = InputField(
        default=None,
        description="PostgreSQL schema (defaults to search_path, usually 'public')",
        dynamic_options=["credential_id"],
    )
    table: str = InputField(
        ...,
        description="Table to delete from",
        dynamic_options=["credential_id", "schema"],
    )
    where: list[WhereCondition] = InputField(
        ...,
        min_length=1,
        description="WHERE conditions (at least one required to prevent accidental full-table deletes)",
    )
    returning: list[str] = InputField(
        default_factory=list,
        description="Columns to return from deleted rows",
    )
    timeout: int = InputField(default=30, ge=1, le=300, description="Query timeout in seconds")


class DeleteOutput(BaseNodeOutput):
    rows: list[dict[str, Any]] = Field(..., description="Returned rows (if RETURNING was specified)")
    affected_count: int = Field(..., description="Number of rows deleted")
    success: bool = Field(..., description="Whether the delete executed successfully")
    raw_sql: str = Field(..., description="The generated SQL query (with $N placeholders)")


class DeleteNode(BaseNode):
    """Delete rows from a PostgreSQL table."""

    input_schema = DeleteInput
    output_schema = DeleteOutput
    credential_schema = PostgresCredentialSchema

    metadata = NodeMetadata(
        name="Postgres Delete",
        description="Delete rows from a PostgreSQL table",
        category="database",
        icon="database",
        color="#336791",
    )

    async def get_field_options(
        self,
        field_name: str,
        credential_data: dict[str, Any] | None = None,
        field_values: dict[str, Any] | None = None,
    ) -> list[FieldOption]:
        return await pg_field_options(field_name, credential_data, field_values)

    async def execute_logic(
        self,
        validated_inputs: dict[str, Any],
        context: NodeExecutionContext,
    ) -> DeleteOutput:
        credential_data = await context.resolve_credential(
            credential_id=validated_inputs["credential_id"],
            credential_type=self.get_credential_type(),
        )
        context.register_secret(credential_data["password"])

        query, params = _build_delete_query(validated_inputs)
        timeout = validated_inputs.get("timeout", 30)

        rows, row_count = await execute_query(credential_data, query, params, timeout=timeout)
        return DeleteOutput(
            rows=serialize_rows(rows),
            affected_count=row_count,
            success=True,
            raw_sql=query,
        )


def _build_delete_query(inputs: dict[str, Any]) -> tuple[str, list[Any]]:
    """Build a parameterized DELETE query from structured inputs."""
    table = qualify_table(inputs["table"], inputs.get("schema"))

    # WHERE clause (required)
    where_sql, params, _ = build_where_clause(inputs["where"])

    query = f"DELETE FROM {table} {where_sql}"

    # RETURNING
    returning = inputs.get("returning") or []
    if returning:
        ret_str = ", ".join(sanitize_identifier(c) for c in returning)
        query += f" RETURNING {ret_str}"

    return query, params
