"""Raw SQL query node for executing arbitrary SQL against PostgreSQL."""

from typing import Any

from flowire_sdk import BaseNode, BaseNodeOutput, CodeEditorContract, InputField, NodeExecutionContext, NodeMetadata
from pydantic import BaseModel, Field

from fw_nodes_postgres.credentials import PostgresCredentialSchema
from fw_nodes_postgres.utils.db import execute_query, serialize_rows

SQL_DEFAULT = "SELECT * FROM my_table\nWHERE id = $1\nLIMIT 100;"


class RawQueryInput(BaseModel):
    credential_id: str = InputField(..., description="PostgreSQL credential")
    query: str = InputField(
        default=SQL_DEFAULT,
        description="SQL query to execute. Use $1, $2, etc. for parameterized values.",
        code=True,
    )
    params: list[Any] = InputField(
        default_factory=list,
        description="Query parameters (matched to $1, $2, etc. in the query)",
    )
    timeout: int = InputField(default=30, ge=1, le=300, description="Query timeout in seconds")


class RawQueryOutput(BaseNodeOutput):
    rows: list[dict[str, Any]] = Field(..., description="Query result rows (empty for non-SELECT queries)")
    row_count: int = Field(..., description="Number of rows returned or affected")
    success: bool = Field(..., description="Whether the query executed successfully")
    raw_sql: str = Field(..., description="The SQL query that was executed")


class RawQueryNode(BaseNode):
    """Execute raw SQL queries against a PostgreSQL database."""

    input_schema = RawQueryInput
    output_schema = RawQueryOutput
    credential_schema = PostgresCredentialSchema

    metadata = NodeMetadata(
        name="Postgres Raw Query",
        description="Execute raw SQL queries against PostgreSQL",
        category="database",
        icon="database",
        color="#336791",
        display_component="code",
        code_editor=CodeEditorContract(
            code_field="query",
            language_field=None,
            code_format="code",
            language_defaults={"sql": SQL_DEFAULT},
            language_options=["sql"],
        ),
    )

    async def execute_logic(
        self,
        validated_inputs: dict[str, Any],
        context: NodeExecutionContext,
    ) -> RawQueryOutput:
        credential_data = await context.resolve_credential(
            credential_id=validated_inputs["credential_id"],
            credential_type=self.get_credential_type(),
        )
        context.register_secret(credential_data["password"])

        query = validated_inputs["query"]
        params = validated_inputs.get("params") or []
        timeout = validated_inputs.get("timeout", 30)

        rows, row_count = await execute_query(credential_data, query, params, timeout=timeout)
        return RawQueryOutput(
            rows=serialize_rows(rows),
            row_count=row_count,
            success=True,
            raw_sql=query,
        )
