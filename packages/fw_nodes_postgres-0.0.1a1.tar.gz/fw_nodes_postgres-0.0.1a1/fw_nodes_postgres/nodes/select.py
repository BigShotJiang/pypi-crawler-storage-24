"""Structured SELECT node for PostgreSQL."""

from enum import StrEnum
from typing import Any

from flowire_sdk import BaseNode, BaseNodeOutput, InputField, NodeExecutionContext, NodeMetadata
from flowire_sdk.node_base import FieldOption
from pydantic import BaseModel, Field

from fw_nodes_postgres.credentials import PostgresCredentialSchema
from fw_nodes_postgres.utils.db import (
    WhereCondition,
    build_where_clause,
    execute_query,
    pg_field_options,
    qualify_table,
    sanitize_identifier,
    serialize_rows,
)


class SortDirection(StrEnum):
    ASC = "ASC"
    DESC = "DESC"


class SortClause(BaseModel):
    column: str = InputField(..., description="Column to sort by")
    direction: SortDirection = InputField(default=SortDirection.ASC, description="Sort direction")


class SelectInput(BaseModel):
    credential_id: str = InputField(..., description="PostgreSQL credential")
    schema: str | None = InputField(
        default=None,
        description="PostgreSQL schema (defaults to search_path, usually 'public')",
        dynamic_options=["credential_id"],
    )
    table: str = InputField(
        ...,
        description="Table name to query",
        dynamic_options=["credential_id", "schema"],
    )
    columns: list[str] = InputField(
        default_factory=lambda: ["*"],
        description="Columns to select (defaults to all)",
    )
    where: list[WhereCondition] = InputField(
        default_factory=list,
        description="WHERE conditions (combined with AND)",
    )
    order_by: list[SortClause] = InputField(default_factory=list, description="ORDER BY clauses")
    limit: int | None = InputField(default=None, ge=1, description="Maximum rows to return")
    offset: int | None = InputField(default=None, ge=0, description="Number of rows to skip")
    timeout: int = InputField(default=30, ge=1, le=300, description="Query timeout in seconds")


class SelectOutput(BaseNodeOutput):
    rows: list[dict[str, Any]] = Field(..., description="Query result rows")
    row_count: int = Field(..., description="Number of rows returned")
    success: bool = Field(..., description="Whether the query executed successfully")
    raw_sql: str = Field(..., description="The generated SQL query (with $N placeholders)")


class SelectNode(BaseNode):
    """Query rows from a PostgreSQL table with a structured interface."""

    input_schema = SelectInput
    output_schema = SelectOutput
    credential_schema = PostgresCredentialSchema

    metadata = NodeMetadata(
        name="Postgres Select",
        description="Query rows from a PostgreSQL table",
        category="database",
        icon="database",
        color="#336791",
    )

    async def get_field_options(
        self,
        field_name: str,
        credential_data: dict[str, Any] | None = None,
        field_values: dict[str, Any] | None = None,
    ) -> list[FieldOption]:
        return await pg_field_options(field_name, credential_data, field_values)

    async def execute_logic(
        self,
        validated_inputs: dict[str, Any],
        context: NodeExecutionContext,
    ) -> SelectOutput:
        credential_data = await context.resolve_credential(
            credential_id=validated_inputs["credential_id"],
            credential_type=self.get_credential_type(),
        )
        context.register_secret(credential_data["password"])

        query, params = _build_select_query(validated_inputs)
        timeout = validated_inputs.get("timeout", 30)

        rows, row_count = await execute_query(credential_data, query, params, timeout=timeout)
        return SelectOutput(
            rows=serialize_rows(rows),
            row_count=row_count,
            success=True,
            raw_sql=query,
        )


def _build_select_query(inputs: dict[str, Any]) -> tuple[str, list[Any]]:
    """Build a parameterized SELECT query from structured inputs."""
    table = qualify_table(inputs["table"], inputs.get("schema"))
    columns = inputs.get("columns") or ["*"]
    col_str = ", ".join(sanitize_identifier(c) if c != "*" else "*" for c in columns)

    parts = [f"SELECT {col_str} FROM {table}"]
    params: list[Any] = []
    param_idx = 1

    # WHERE
    where_conditions = inputs.get("where") or []
    if where_conditions:
        where_sql, where_params, param_idx = build_where_clause(where_conditions, param_idx)
        parts.append(where_sql)
        params.extend(where_params)

    # ORDER BY
    order_by = inputs.get("order_by") or []
    if order_by:
        order_parts = []
        for clause in order_by:
            col = sanitize_identifier(clause["column"])
            direction = clause.get("direction", "ASC").upper()
            if direction not in ("ASC", "DESC"):
                direction = "ASC"
            order_parts.append(f"{col} {direction}")
        parts.append("ORDER BY " + ", ".join(order_parts))

    # LIMIT / OFFSET
    if inputs.get("limit") is not None:
        parts.append(f"LIMIT ${param_idx}")
        params.append(inputs["limit"])
        param_idx += 1

    if inputs.get("offset") is not None:
        parts.append(f"OFFSET ${param_idx}")
        params.append(inputs["offset"])
        param_idx += 1

    return " ".join(parts), params
