"""Shared database utilities for PostgreSQL nodes."""

from decimal import Decimal
from typing import Any

import asyncpg
from flowire_sdk import InputField
from flowire_sdk.node_base import FieldOption
from pydantic import BaseModel


class WhereCondition(BaseModel):
    column: str = InputField(..., description="Column name")
    operator: str = InputField(
        default="=",
        description="Comparison operator (=, !=, <, >, <=, >=, LIKE, ILIKE, IN, IS NULL, IS NOT NULL)",
    )
    value: Any = InputField(default=None, description="Comparison value (ignored for IS NULL / IS NOT NULL)")


_ALLOWED_OPERATORS = frozenset({"=", "!=", "<>", "<", ">", "<=", ">=", "LIKE", "ILIKE"})


def sanitize_identifier(name: str) -> str:
    """Quote a SQL identifier to prevent injection."""
    cleaned = name.replace('"', '""')
    return f'"{cleaned}"'


def qualify_table(table: str, schema: str | None = None) -> str:
    """Return a fully-qualified, quoted table reference (e.g. "myschema"."mytable")."""
    qualified = sanitize_identifier(table)
    if schema:
        qualified = f"{sanitize_identifier(schema)}.{qualified}"
    return qualified


def build_where_clause(
    conditions: list[dict[str, Any]],
    param_idx: int = 1,
) -> tuple[str, list[Any], int]:
    """Build a parameterized WHERE clause from a list of conditions.

    Returns (clause_sql, params, next_param_idx).
    clause_sql includes the 'WHERE' keyword.
    """
    clauses: list[str] = []
    params: list[Any] = []

    for cond in conditions:
        col = sanitize_identifier(cond["column"])
        op = cond.get("operator", "=").upper().strip()

        if op in ("IS NULL", "IS NOT NULL"):
            clauses.append(f"{col} {op}")
        elif op == "IN":
            values = cond["value"] if isinstance(cond["value"], list) else [cond["value"]]
            placeholders = ", ".join(f"${param_idx + i}" for i in range(len(values)))
            clauses.append(f"{col} IN ({placeholders})")
            params.extend(values)
            param_idx += len(values)
        else:
            if op not in _ALLOWED_OPERATORS:
                raise ValueError(f"Unsupported operator: {op}")
            clauses.append(f"{col} {op} ${param_idx}")
            params.append(cond["value"])
            param_idx += 1

    return "WHERE " + " AND ".join(clauses), params, param_idx


async def execute_query(
    credential_data: dict[str, Any],
    query: str,
    params: list[Any] | None = None,
    *,
    timeout: float = 30.0,
) -> tuple[list[dict[str, Any]], int]:
    """Execute a query and return (rows, row_count).

    For SELECT queries, rows contains the result set and row_count is len(rows).
    For INSERT/UPDATE/DELETE, rows is empty and row_count is the affected row count.
    Returns with RETURNING clauses return the rows and len(rows) as row_count.
    """
    ssl_config: str | bool = "require" if credential_data.get("ssl") else False

    try:
        conn: asyncpg.Connection = await asyncpg.connect(
            host=credential_data["host"],
            port=credential_data.get("port", 5432),
            database=credential_data["database"],
            user=credential_data["user"],
            password=credential_data["password"],
            ssl=ssl_config,
            timeout=timeout,
        )
    except OSError as e:
        raise ConnectionError(
            f"Cannot connect to PostgreSQL at {credential_data['host']}:{credential_data.get('port', 5432)}: {e}"
        ) from e
    except asyncpg.InvalidPasswordError as e:
        raise ConnectionError("Authentication failed: invalid username or password") from e
    except asyncpg.InvalidCatalogNameError as e:
        raise ConnectionError(f"Database '{credential_data['database']}' does not exist") from e
    except TimeoutError as e:
        raise TimeoutError(
            f"Connection timed out after {timeout}s to {credential_data['host']}:{credential_data.get('port', 5432)}"
        ) from e
    except asyncpg.PostgresError as e:
        raise ConnectionError(f"PostgreSQL connection error: {e}") from e

    try:
        async with conn.transaction():
            stmt = await conn.prepare(query, timeout=timeout)
            if stmt.get_attributes():
                records = await stmt.fetch(*(params or []), timeout=timeout)
                rows = [dict(r) for r in records]
                return rows, len(rows)
            else:
                result = await conn.execute(query, *(params or []), timeout=timeout)
                row_count = _parse_command_tag(result)
                return [], row_count
    except asyncpg.PostgresSyntaxError as e:
        raise ValueError(f"SQL syntax error: {e}") from e
    except asyncpg.UndefinedTableError as e:
        raise ValueError(f"Table not found: {e}") from e
    except asyncpg.UndefinedColumnError as e:
        raise ValueError(f"Column not found: {e}") from e
    except asyncpg.DataError as e:
        raise ValueError(f"Data error: {e}") from e
    except TimeoutError as e:
        raise TimeoutError(f"Query timed out after {timeout}s") from e
    except asyncpg.PostgresError as e:
        raise RuntimeError(f"PostgreSQL error: {e}") from e
    finally:
        await conn.close()


def _parse_command_tag(tag: str) -> int:
    """Parse asyncpg command tag like 'DELETE 3' into affected row count."""
    parts = tag.split()
    if len(parts) >= 2 and parts[-1].isdigit():
        return int(parts[-1])
    return 0


def _serialize_value(value: Any) -> Any:
    """Convert asyncpg types to JSON-serializable Python types.

    Preserves native JSON types (int, float, bool) and converts
    Decimal to int/float so downstream nodes get usable numbers.
    """
    if value is None:
        return None
    if isinstance(value, bool):
        # Check bool before int since bool is a subclass of int
        return value
    if isinstance(value, (int, float)):
        return value
    if isinstance(value, str):
        return value
    if isinstance(value, Decimal):
        # Preserve as int when there's no fractional part
        if value == value.to_integral_value():
            return int(value)
        return float(value)
    if isinstance(value, (list, tuple)):
        return [_serialize_value(v) for v in value]
    if isinstance(value, dict):
        return {k: _serialize_value(v) for k, v in value.items()}
    # datetime, date, time, UUID, etc.
    return str(value)


def serialize_rows(rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Serialize all values in rows to JSON-safe types."""
    return [{k: _serialize_value(v) for k, v in row.items()} for row in rows]


# ---------------------------------------------------------------------------
# Dynamic field options helpers
# ---------------------------------------------------------------------------

# Schemas to hide from the dropdown (PostgreSQL internals)
_HIDDEN_SCHEMAS = frozenset({"pg_catalog", "pg_toast", "information_schema"})


async def _connect(credential_data: dict[str, Any]) -> asyncpg.Connection:
    """Open a short-lived connection for metadata queries."""
    ssl_config: str | bool = "require" if credential_data.get("ssl") else False
    return await asyncpg.connect(
        host=credential_data["host"],
        port=credential_data.get("port", 5432),
        database=credential_data["database"],
        user=credential_data["user"],
        password=credential_data["password"],
        ssl=ssl_config,
        timeout=10,
    )


async def fetch_schemas(credential_data: dict[str, Any]) -> list[FieldOption]:
    """List user-visible schemas from the connected database."""
    conn = await _connect(credential_data)
    try:
        rows = await conn.fetch("SELECT schema_name FROM information_schema.schemata ORDER BY schema_name")
        return [
            FieldOption(id=r["schema_name"], name=r["schema_name"])
            for r in rows
            if r["schema_name"] not in _HIDDEN_SCHEMAS
        ]
    finally:
        await conn.close()


async def fetch_tables(
    credential_data: dict[str, Any],
    schema: str | None = None,
) -> list[FieldOption]:
    """List tables (and views) in a schema. Defaults to 'public'."""
    schema = schema or "public"
    conn = await _connect(credential_data)
    try:
        rows = await conn.fetch(
            "SELECT table_name, table_type FROM information_schema.tables WHERE table_schema = $1 ORDER BY table_name",
            schema,
        )
        return [
            FieldOption(
                id=r["table_name"],
                name=r["table_name"],
                description="view" if r["table_type"] == "VIEW" else None,
            )
            for r in rows
        ]
    finally:
        await conn.close()


async def pg_field_options(
    field_name: str,
    credential_data: dict[str, Any] | None,
    field_values: dict[str, Any] | None = None,
) -> list[FieldOption]:
    """Shared get_field_options implementation for all PostgreSQL CRUD nodes."""
    if credential_data is None:
        return []

    if field_name == "schema":
        return await fetch_schemas(credential_data)
    elif field_name == "table":
        schema = (field_values or {}).get("schema")
        return await fetch_tables(credential_data, schema)

    return []
