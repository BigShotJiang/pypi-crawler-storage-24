# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['py2femm']

package_data = \
{'': ['*']}

setup_kwargs = {
    'name': 'py2femm',
    'version': '0.1.0',
    'description': 'Python interface utilities for FEMM simulations',
    'long_description': '# py2femm\n\nThis library aims to provide a dockerizable, Python-based interface for [FEMM](https://www.femm.info/wiki/HomePage), a\npopular finite element method-based solver. It provides a GUI to solve two-dimensional electromagnetic and thermal\nproblems.\nIt has an officially supported [python interface (pyFEMM)](https://www.femm.info/wiki/pyFEMM). However, it works under\nWindows systems only.  \nIt is possible to run FEMM under Linux operating systems with [Wine](https://www.winehq.org/). However, it does not\nsupport the ActiveX interface, which was used by the original solution.\n\nThis project provides a simplified file-based interface for FEMM, which can be used with Wine and under Linux operating systems.\nThis interface generates a lua file, which the original interpreter of FEMM can use. However, this interface differs\nfrom the original command set in the following points:\n\n- The geometry description is separated from the fields; therefore, if we describe the geometry for a 2D magnetic model,\nwe can use the same description of the part to create the thermal model.\n\n- Some new commands are introduced, which execute the combination of some straightforward commands.\n\n- Provides an Ubuntu-based dockerized environment to execute the simulations consistently.\n\n# Geometry generation commands\n\nThe geometry class contains Node, Line and CircleArc objects. All of the possible modelled geometries should be\ndescribed by using these geometrical objects.\n\n\n',
    'author': 'Tamás Orosz',
    'author_email': 'tamas.orosz@yahoo.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
