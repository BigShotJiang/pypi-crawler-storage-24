use crate::functions::geometry::{DOFS_PER_NODE, ELEMENT_DOFS};
use crate::functions::hinge_and_release_operations::{
    apply_end_releases_to_local_beam_f, apply_end_releases_to_local_beam_k, modes_from_single_ends,
};
use crate::models::fers::fers::FERS;
use crate::models::members::memberhinge::AxisMode;
use crate::models::results::displacement::NodeDisplacement;
use crate::models::results::forces::{NodeForces, SectionForce};
use crate::models::results::memberresult::MemberResult;
use crate::models::results::results::ResultType;
use nalgebra::{DMatrix, DVector};
use std::collections::{BTreeMap, HashSet};

/// Number of intermediate section force points per member (excluding start/end).
/// 3 gives quarter-points + midpoint: positions 0.25, 0.5, 0.75.
const NUM_SECTION_POINTS: usize = 3;

/// Extract local displacements for start and end nodes from a local displacement vector.
fn local_displacements_from_vector(
    u_local: &DVector<f64>,
) -> (NodeDisplacement, NodeDisplacement) {
    let start = NodeDisplacement {
        dx: u_local[0],
        dy: u_local[1],
        dz: u_local[2],
        rx: u_local[3],
        ry: u_local[4],
        rz: u_local[5],
        warp: u_local[6],
    };
    let end = NodeDisplacement {
        dx: u_local[DOFS_PER_NODE + 0],
        dy: u_local[DOFS_PER_NODE + 1],
        dz: u_local[DOFS_PER_NODE + 2],
        rx: u_local[DOFS_PER_NODE + 3],
        ry: u_local[DOFS_PER_NODE + 4],
        rz: u_local[DOFS_PER_NODE + 5],
        warp: u_local[DOFS_PER_NODE + 6],
    };
    (start, end)
}

fn zero_displacement() -> NodeDisplacement {
    NodeDisplacement {
        dx: 0.0, dy: 0.0, dz: 0.0,
        rx: 0.0, ry: 0.0, rz: 0.0,
        warp: 0.0,
    }
}

pub fn compute_component_extrema(
    start_forces: &NodeForces,
    end_forces: &NodeForces,
) -> (NodeForces, NodeForces) {
    let maximums = NodeForces {
        fx: start_forces.fx.max(end_forces.fx),
        fy: start_forces.fy.max(end_forces.fy),
        fz: start_forces.fz.max(end_forces.fz),
        mx: start_forces.mx.max(end_forces.mx),
        my: start_forces.my.max(end_forces.my),
        mz: start_forces.mz.max(end_forces.mz),
        bw: start_forces.bw.max(end_forces.bw),
    };
    let minimums = NodeForces {
        fx: start_forces.fx.min(end_forces.fx),
        fy: start_forces.fy.min(end_forces.fy),
        fz: start_forces.fz.min(end_forces.fz),
        mx: start_forces.mx.min(end_forces.mx),
        my: start_forces.my.min(end_forces.my),
        mz: start_forces.mz.min(end_forces.mz),
        bw: start_forces.bw.min(end_forces.bw),
    };
    (maximums, minimums)
}

/// Compute internal section forces at `NUM_SECTION_POINTS` evenly-spaced fractional positions
/// along a member, given the local start forces and the accumulated distributed loads.
///
/// `member_loads` entries are `(w1, w2, a, b, dx, dy, dz)`:
///   - `w1` / `w2`: load intensity at `a` / `b` (already scaled by combination factor)
///   - `a` / `b`:   fractional start / end positions along the member
///   - `dx/dy/dz`:  load direction in local member axes
///
/// Sign convention (all in local axes):
///   N(t)  = local_start.fx  - L * ∫₀ᵗ wₓ ds
///   Vy(t) = local_start.fy  - L * ∫₀ᵗ w_y ds
///   Vz(t) = local_start.fz  - L * ∫₀ᵗ w_z ds
///   Mx(t) = local_start.mx  (torsion constant for transverse distributed loads)
///   My(t) = local_start.my  + Vz(0)·t·L  - L² * ∫₀ᵗ w_z·(t−s) ds
///   Mz(t) = local_start.mz  − Vy(0)·t·L  + L² * ∫₀ᵗ w_y·(t−s) ds
fn compute_section_forces(
    local_start: &NodeForces,
    member_loads: &[(f64, f64, f64, f64, f64, f64, f64)],
    length: f64,
) -> Vec<SectionForce> {
    // evenly-spaced fractional positions between 0 and 1 (exclusive)
    let step = 1.0 / (NUM_SECTION_POINTS as f64 + 1.0);
    (1..=NUM_SECTION_POINTS)
        .map(|i| {
            let t = step * i as f64;

            let mut n = local_start.fx;
            let mut vy = local_start.fy;
            let mut vz = local_start.fz;
            let mx = local_start.mx;
            // Apply the linear shear-to-moment term for this position
            let mut my = local_start.my + local_start.fz * t * length;
            let mut mz = local_start.mz - local_start.fy * t * length;

            for &(w1, w2, a, b, dx, dy, dz) in member_loads {
                if t <= a {
                    continue;
                }
                let span = b - a;
                if span.abs() < 1e-14 {
                    continue;
                }
                let t_eff = t.min(b);
                let dt = t_eff - a;

                // Force integral: ∫ₐᵗ_eff w(s) ds  (fractional)
                let fi = w1 * dt + (w2 - w1) / span * dt * dt * 0.5;
                n += length * fi * dx;
                vy += length * fi * dy;
                vz += length * fi * dz;

                // Moment integral: ∫ₐᵗ_eff w(s)·(t−s) ds  (fractional)
                let ta = t - a;
                let mi = w1 * (ta * dt - dt * dt * 0.5)
                    + (w2 - w1) / span * (ta * dt * dt * 0.5 - dt * dt * dt / 3.0);
                mz -= length * length * mi * dy;
                my += length * length * mi * dz;
            }

            SectionForce {
                x_frac: t,
                forces: NodeForces {
                    fx: n,
                    fy: vy,
                    fz: vz,
                    mx,
                    my,
                    mz,
                    bw: 0.0,
                },
            }
        })
        .collect()
}

/// Compute f_eq (equivalent nodal forces in local coordinates) for distributed
/// loads on a single member in a given result type (load case or combination).
/// Returns `(f_eq_local, member_loads)` where `member_loads` collects the
/// per-load tuples `(w1, w2, a, b, dx, dy, dz)` needed by `compute_section_forces`.
fn compute_feq_for_member(
    member_id: u32,
    length: f64,
    t_for_global: &DMatrix<f64>,
    fers: &FERS,
    result_type: &ResultType,
) -> (DVector<f64>, Vec<(f64, f64, f64, f64, f64, f64, f64)>) {
    let mut f_eq_local = DVector::<f64>::zeros(ELEMENT_DOFS);
    let mut member_loads: Vec<(f64, f64, f64, f64, f64, f64, f64)> = Vec::new();

    // Closure that processes a single distributed load into f_eq_local and member_loads
    let mut process_dl = |w1: f64, w2: f64, a: f64, b: f64, direction: (f64, f64, f64), factor: f64| {
        let d1 = b - a;
        if d1.abs() < 1e-14 {
            return;
        }
        let d2 = b * b - a * a;
        let d3 = b.powi(3) - a.powi(3);
        let d4 = b.powi(4) - a.powi(4);
        let d5 = b.powi(5) - a.powi(5);

        let int_n1 = d1 - d3 + 0.5 * d4;
        let int_xn1 = 0.5 * d2 - 0.75 * d4 + 0.4 * d5;
        let int_n3 = d3 - 0.5 * d4;
        let int_xn3 = 0.75 * d4 - 0.4 * d5;
        let int_n2 = 0.5 * d2 - (2.0 / 3.0) * d3 + 0.25 * d4;
        let int_xn2 = (1.0 / 3.0) * d3 - 0.5 * d4 + 0.2 * d5;
        let int_n4 = (1.0 / 3.0) * d3 - 0.25 * d4;
        let int_xn4 = 0.25 * d4 - 0.2 * d5;

        let inv_d1 = 1.0 / d1;
        let f_s = length * (w1 * int_n1 + (w2 - w1) * inv_d1 * (int_xn1 - a * int_n1));
        let f_e = length * (w1 * int_n3 + (w2 - w1) * inv_d1 * (int_xn3 - a * int_n3));
        let m_s = length * length * (w1 * int_n2 + (w2 - w1) * inv_d1 * (int_xn2 - a * int_n2));
        let m_e = -length * length * (w1 * int_n4 + (w2 - w1) * inv_d1 * (int_xn4 - a * int_n4));

        let (dx_g, dy_g, dz_g) = direction;
        let dx = t_for_global[(0, 0)] * dx_g + t_for_global[(0, 1)] * dy_g + t_for_global[(0, 2)] * dz_g;
        let dy = t_for_global[(1, 0)] * dx_g + t_for_global[(1, 1)] * dy_g + t_for_global[(1, 2)] * dz_g;
        let dz = t_for_global[(2, 0)] * dx_g + t_for_global[(2, 1)] * dy_g + t_for_global[(2, 2)] * dz_g;

        f_eq_local[0] += factor * f_s * dx;
        f_eq_local[1] += factor * f_s * dy;
        f_eq_local[2] += factor * f_s * dz;
        f_eq_local[5] += factor * m_s * dy;
        f_eq_local[4] -= factor * m_s * dz;
        f_eq_local[DOFS_PER_NODE + 0] += factor * f_e * dx;
        f_eq_local[DOFS_PER_NODE + 1] += factor * f_e * dy;
        f_eq_local[DOFS_PER_NODE + 2] += factor * f_e * dz;
        f_eq_local[DOFS_PER_NODE + 5] += factor * m_e * dy;
        f_eq_local[DOFS_PER_NODE + 4] -= factor * m_e * dz;

        member_loads.push((w1 * factor, w2 * factor, a, b, dx, dy, dz));
    };

    match result_type {
        ResultType::Loadcase(load_case_id) => {
            if let Some(load_case) = fers.load_cases.iter().find(|lc| lc.id == *load_case_id) {
                for dl in &load_case.distributed_loads {
                    if dl.member != member_id || dl.load_case != *load_case_id {
                        continue;
                    }
                    process_dl(dl.magnitude, dl.end_magnitude, dl.start_frac, dl.end_frac, dl.direction, 1.0);
                }
            }
        }
        ResultType::Loadcombination(load_combination_id) => {
            if let Some(lc) = fers.load_combinations.iter().find(|c| c.id == *load_combination_id) {
                for (case_id, factor) in &lc.load_cases_factors {
                    if let Some(load_case) = fers.load_cases.iter().find(|x| x.id == *case_id) {
                        for dl in &load_case.distributed_loads {
                            if dl.member != member_id || dl.load_case != *case_id {
                                continue;
                            }
                            process_dl(dl.magnitude, dl.end_magnitude, dl.start_frac, dl.end_frac, dl.direction, *factor);
                        }
                    }
                }
            }
        }
    }

    (f_eq_local, member_loads)
}

pub fn extract_displacements(
    fers: &FERS,
    global_displacement_vector: &DMatrix<f64>,
) -> BTreeMap<u32, NodeDisplacement> {
    let mut unique_node_identifiers: HashSet<u32> = HashSet::new();

    for member_set in &fers.member_sets {
        for member in &member_set.members {
            unique_node_identifiers.insert(member.start_node.id);
            unique_node_identifiers.insert(member.end_node.id);
        }
    }

    unique_node_identifiers
        .into_iter()
        .map(|node_identifier| {
            let degree_of_freedom_start = (node_identifier as usize - 1) * DOFS_PER_NODE;
            (
                node_identifier,
                NodeDisplacement {
                    dx: global_displacement_vector[(degree_of_freedom_start + 0, 0)],
                    dy: global_displacement_vector[(degree_of_freedom_start + 1, 0)],
                    dz: global_displacement_vector[(degree_of_freedom_start + 2, 0)],
                    rx: global_displacement_vector[(degree_of_freedom_start + 3, 0)],
                    ry: global_displacement_vector[(degree_of_freedom_start + 4, 0)],
                    rz: global_displacement_vector[(degree_of_freedom_start + 5, 0)],
                    warp: global_displacement_vector[(degree_of_freedom_start + 6, 0)],
                },
            )
        })
        .collect()
}

fn build_elimination_from_modes(
    a_trans: &[AxisMode; 3],
    a_rot: &[AxisMode; 3],
    b_trans: &[AxisMode; 3],
    b_rot: &[AxisMode; 3],
    a_warp: &AxisMode,
    b_warp: &AxisMode,
) -> (Vec<usize>, Vec<f64>) {
    let mut elim_idx: Vec<usize> = Vec::new();
    let mut kdiag: Vec<f64> = Vec::new();

    let mut push_mode = |local_index: usize, mode: &AxisMode| {
        match *mode {
            AxisMode::Rigid => { /* retained; nothing to eliminate */ }
            AxisMode::Release => {
                elim_idx.push(local_index);
                kdiag.push(0.0);
            }
            AxisMode::Spring(k) => {
                elim_idx.push(local_index);
                kdiag.push(k.max(0.0));
            }
        }
    };

    // DOF ordering for displacements in local member vector:
    // start: [ux, uy, uz, rx, ry, rz, warp] => indices 0..=6
    // end:   [ux, uy, uz, rx, ry, rz, warp] => indices 7..=13
    for i in 0..3 {
        push_mode(i, &a_trans[i]); // start translations: 0,1,2
        push_mode(3 + i, &a_rot[i]); // start rotations:    3,4,5
        push_mode(DOFS_PER_NODE + i, &b_trans[i]); // end translations
        push_mode(DOFS_PER_NODE + 3 + i, &b_rot[i]); // end rotations
    }
    // Warping DOFs
    push_mode(6, a_warp); // start warping: index 6
    push_mode(DOFS_PER_NODE + 6, b_warp); // end warping:   index 13

    (elim_idx, kdiag)
}

/// Recover member-side end forces with semi-rigid ends (and perfect releases)
/// by re-introducing the eliminated DOFs and solving the small interface system.
///
/// When `include_feq_in_spring_rhs` is true, the fixed-end load vector f_eq is
/// included in the spring recovery RHS.  This is correct when the global system
/// was assembled with CONDENSED equivalent nodal forces (the load assembler
/// applied `apply_end_releases_to_local_beam_f` to F_global).  Without this,
/// the recovered beam-end DOFs would ignore the distributed load contribution,
/// giving wrong member-internal forces.
fn recover_member_end_forces_local(
    k_local_base: &DMatrix<f64>,
    u_local_node: &DVector<f64>,
    f_eq_local: &DVector<f64>,
    a_trans: &[AxisMode; 3],
    a_rot: &[AxisMode; 3],
    b_trans: &[AxisMode; 3],
    b_rot: &[AxisMode; 3],
    a_warp: &AxisMode,
    b_warp: &AxisMode,
    include_feq_in_spring_rhs: bool,
) -> DVector<f64> {
    // Build elimination set and the corresponding spring stiffness diag
    let (elim_idx, kdiag) =
        build_elimination_from_modes(a_trans, a_rot, b_trans, b_rot, a_warp, b_warp);

    // P u := keep retained components from u_node, zero on eliminated positions
    let mut u_p = u_local_node.clone();
    for &idx in &elim_idx {
        u_p[idx] = 0.0;
    }

    if elim_idx.is_empty() {
        // no semi-rigid / release => classic q = K u − f_eq
        return k_local_base * u_p - f_eq_local;
    }

    // Build A = K_rr + diag(k)
    let m = elim_idx.len();
    let mut a_mat = DMatrix::<f64>::zeros(m, m);

    for (ri, &i_idx) in elim_idx.iter().enumerate() {
        for (rj, &j_idx) in elim_idx.iter().enumerate() {
            a_mat[(ri, rj)] = k_local_base[(i_idx, j_idx)];
        }
        a_mat[(ri, ri)] += kdiag[ri];
    }

    // Build RHS: diag(k)*u_J − K_rk * u_k  [+ f_eq_r if condensed global F]
    //
    // When the load assembler condenses f_eq into the global F, including f_r
    // here is CONSISTENT and gives the correct beam-end deformations under
    // distributed loads with spring hinges.
    let mut rhs = DVector::<f64>::zeros(m);
    for (ri, &i_idx) in elim_idx.iter().enumerate() {
        // t1 = K[i_idx, :] * (P u)
        let mut t1 = 0.0;
        for j in 0..ELEMENT_DOFS {
            t1 += k_local_base[(i_idx, j)] * u_p[j];
        }
        rhs[ri] = kdiag[ri] * u_local_node[i_idx] - t1;
        if include_feq_in_spring_rhs {
            rhs[ri] += f_eq_local[i_idx];
        }
    }

    // Solve for r (eliminated member end DoFs)
    let r = match a_mat.lu().solve(&rhs) {
        Some(sol) => sol,
        None => {
            log::warn!("Semi-rigid recovery: (K_rr + diag(k)) is singular. Falling back to r = 0.");
            DVector::<f64>::zeros(m)
        }
    };

    // Assemble full member DoF vector: u_member = P u + S r
    let mut u_member = u_p;
    for (ri, &i_idx) in elim_idx.iter().enumerate() {
        u_member[i_idx] = r[ri];
    }

    // Member-side end forces
    k_local_base * &u_member - f_eq_local
}

pub fn compute_member_results_from_displacement(
    fers: &FERS,
    result_type: &ResultType,
    global_displacement_vector: &DMatrix<f64>,
    active_map: Option<&std::collections::HashMap<u32, bool>>,
    is_second_order: bool,
    use_corot_forces: bool,
) -> BTreeMap<u32, MemberResult> {
    use crate::models::members::enums::MemberType;

    let (material_map, section_map, hinge_map, _support_map) = fers.build_lookup_maps();
    let mut results_by_member_identifier: BTreeMap<u32, MemberResult> = BTreeMap::new();

    for member_set in &fers.member_sets {
        for member in &member_set.members {
            if matches!(member.member_type, MemberType::Rigid) {
                continue;
            }

            let start_node_dof_index = (member.start_node.id as usize - 1) * DOFS_PER_NODE;
            let end_node_dof_index = (member.end_node.id as usize - 1) * DOFS_PER_NODE;

            let mut u_member_global = DVector::<f64>::zeros(ELEMENT_DOFS);
            for dof in 0..DOFS_PER_NODE {
                u_member_global[dof] = global_displacement_vector[(start_node_dof_index + dof, 0)];
                u_member_global[dof + DOFS_PER_NODE] =
                    global_displacement_vector[(end_node_dof_index + dof, 0)];
            }

            if matches!(
                member.member_type,
                MemberType::Truss | MemberType::Tension | MemberType::Compression
            ) {
                // inactive ties/struts → zero forces
                let is_active = active_map
                    .and_then(|m| m.get(&member.id).copied())
                    .unwrap_or(true);

                if matches!(
                    member.member_type,
                    MemberType::Tension | MemberType::Compression
                ) && !is_active
                {
                    let zeros = NodeForces {
                        fx: 0.0,
                        fy: 0.0,
                        fz: 0.0,
                        mx: 0.0,
                        my: 0.0,
                        mz: 0.0,
                        bw: 0.0,
                    };
                    results_by_member_identifier.insert(
                        member.id,
                        MemberResult {
                            start_node_forces: zeros,
                            end_node_forces: zeros,
                            maximums: zeros,
                            minimums: zeros,
                            local_start_forces: zeros,
                            local_end_forces: zeros,
                            local_maximums: zeros,
                            local_minimums: zeros,
                            local_displacement_start_node: zero_displacement(),
                            local_displacement_end_node: zero_displacement(),
                            section_forces: vec![],
                        },
                    );
                    continue;
                }

                // active: compute axial force (tension > 0)
                let n = member.calculate_axial_force_3d(
                    global_displacement_vector,
                    &material_map,
                    &section_map,
                );

                // global unit direction from start → end
                let dx = member.end_node.X - member.start_node.X;
                let dy = member.end_node.Y - member.start_node.Y;
                let dz = member.end_node.Z - member.start_node.Z;
                let l = (dx * dx + dy * dy + dz * dz).sqrt();
                if l == 0.0 {
                    // degenerate; report zeros
                    let zeros = NodeForces {
                        fx: 0.0,
                        fy: 0.0,
                        fz: 0.0,
                        mx: 0.0,
                        my: 0.0,
                        mz: 0.0,
                        bw: 0.0,
                    };
                    results_by_member_identifier.insert(
                        member.id,
                        MemberResult {
                            start_node_forces: zeros,
                            end_node_forces: zeros,
                            maximums: zeros,
                            minimums: zeros,
                            local_start_forces: zeros,
                            local_end_forces: zeros,
                            local_maximums: zeros,
                            local_minimums: zeros,
                            local_displacement_start_node: zero_displacement(),
                            local_displacement_end_node: zero_displacement(),
                            section_forces: vec![],
                        },
                    );
                    continue;
                }

                // In second-order analysis, use (K_e + K_geo) * T * u - f_eq to capture
                // transverse P-Delta forces and distributed load effects.
                if is_second_order {
                    let t_orig = member.calculate_transformation_matrix_3d();
                    let u_local = &t_orig * &u_member_global;

                    // Build local K_e (truss: axial only)
                    let section_id = member.section.unwrap();
                    let section = section_map.get(&section_id).unwrap();
                    let material = material_map.get(&section.material).unwrap();
                    let ea_over_l = material.e_mod * section.area / l;

                    let mut k_local = DMatrix::<f64>::zeros(ELEMENT_DOFS, ELEMENT_DOFS);
                    k_local[(0, 0)] = ea_over_l;
                    k_local[(0, DOFS_PER_NODE)] = -ea_over_l;
                    k_local[(DOFS_PER_NODE, 0)] = -ea_over_l;
                    k_local[(DOFS_PER_NODE, DOFS_PER_NODE)] = ea_over_l;

                    let k_geo_local =
                        member.calculate_geometric_stiffness_matrix_truss_3d(n);

                    let k_rec = &k_local + &k_geo_local;

                    // Include equivalent nodal forces from distributed loads
                    let (f_eq_local, _member_loads) =
                        compute_feq_for_member(member.id, l, &t_orig, fers, result_type);
                    let q_local = &k_rec * &u_local - &f_eq_local;

                    let global_force_vector = t_orig.transpose() * &q_local;

                    let start = NodeForces {
                        fx: global_force_vector[0],
                        fy: global_force_vector[1],
                        fz: global_force_vector[2],
                        mx: 0.0,
                        my: 0.0,
                        mz: 0.0,
                        bw: 0.0,
                    };
                    let end = NodeForces {
                        fx: global_force_vector[DOFS_PER_NODE + 0],
                        fy: global_force_vector[DOFS_PER_NODE + 1],
                        fz: global_force_vector[DOFS_PER_NODE + 2],
                        mx: 0.0,
                        my: 0.0,
                        mz: 0.0,
                        bw: 0.0,
                    };

                    let (maximums, minimums) = compute_component_extrema(&start, &end);

                    let local_start = NodeForces {
                        fx: q_local[0],
                        fy: q_local[1],
                        fz: q_local[2],
                        mx: 0.0,
                        my: 0.0,
                        mz: 0.0,
                        bw: 0.0,
                    };
                    let local_end = NodeForces {
                        fx: q_local[DOFS_PER_NODE + 0],
                        fy: q_local[DOFS_PER_NODE + 1],
                        fz: q_local[DOFS_PER_NODE + 2],
                        mx: 0.0,
                        my: 0.0,
                        mz: 0.0,
                        bw: 0.0,
                    };

                    let (local_maximums, local_minimums) =
                        compute_component_extrema(&local_start, &local_end);

                    let (local_displacement_start_node, local_displacement_end_node) =
                        local_displacements_from_vector(&u_local);

                    results_by_member_identifier.insert(
                        member.id,
                        MemberResult {
                            start_node_forces: start,
                            end_node_forces: end,
                            maximums,
                            minimums,
                            local_start_forces: local_start,
                            local_end_forces: local_end,
                            local_maximums,
                            local_minimums,
                            local_displacement_start_node,
                            local_displacement_end_node,
                            section_forces: vec![],
                        },
                    );
                    continue;
                }

                let ex = dx / l;
                let ey = dy / l;
                let ez = dz / l;

                // Include equivalent nodal forces from distributed loads
                let t_orig = member.calculate_transformation_matrix_3d();
                let (f_eq_local, _member_loads) =
                    compute_feq_for_member(member.id, l, &t_orig, fers, result_type);
                let f_eq_global = t_orig.transpose() * &f_eq_local;

                let start = NodeForces {
                    fx: -n * ex - f_eq_global[0],
                    fy: -n * ey - f_eq_global[1],
                    fz: -n * ez - f_eq_global[2],
                    mx: 0.0,
                    my: 0.0,
                    mz: 0.0,
                    bw: 0.0,
                };
                let end = NodeForces {
                    fx: n * ex - f_eq_global[DOFS_PER_NODE + 0],
                    fy: n * ey - f_eq_global[DOFS_PER_NODE + 1],
                    fz: n * ez - f_eq_global[DOFS_PER_NODE + 2],
                    mx: 0.0,
                    my: 0.0,
                    mz: 0.0,
                    bw: 0.0,
                };

                let (maximums, minimums) = compute_component_extrema(&start, &end);

                let local_start = NodeForces {
                    fx: -n - f_eq_local[0],
                    fy: -f_eq_local[1],
                    fz: -f_eq_local[2],
                    mx: 0.0,
                    my: 0.0,
                    mz: 0.0,
                    bw: 0.0,
                };
                let local_end = NodeForces {
                    fx: n - f_eq_local[DOFS_PER_NODE + 0],
                    fy: -f_eq_local[DOFS_PER_NODE + 1],
                    fz: -f_eq_local[DOFS_PER_NODE + 2],
                    mx: 0.0,
                    my: 0.0,
                    mz: 0.0,
                    bw: 0.0,
                };

                let (local_maximums, local_minimums) =
                    compute_component_extrema(&local_start, &local_end);

                let u_local_truss = &t_orig * &u_member_global;
                let (local_displacement_start_node, local_displacement_end_node) =
                    local_displacements_from_vector(&u_local_truss);

                results_by_member_identifier.insert(
                    member.id,
                    MemberResult {
                        start_node_forces: start,
                        end_node_forces: end,
                        maximums,
                        minimums,
                        local_start_forces: local_start,
                        local_end_forces: local_end,
                        local_maximums,
                        local_minimums,
                        local_displacement_start_node,
                        local_displacement_end_node,
                        section_forces: vec![],
                    },
                );
                continue;
            }

            // === Normal (beam) path with semi-rigid ends ===
            let k_local_base =
                match member.calculate_stiffness_matrix_3d(&material_map, &section_map) {
                    Some(k) => k,
                    None => continue,
                };

            let t_orig = member.calculate_transformation_matrix_3d();

            // Local displacements: always use T_orig to transform global nodal displacements
            // into the member's local coordinate system (independent of force recovery method).
            let u_local_disp = &t_orig * &u_member_global;
            let (local_displacement_start_node, local_displacement_end_node) =
                local_displacements_from_vector(&u_local_disp);

            // Choose force recovery formula based on analysis mode:
            //
            // • Corotational (use_corot_forces=true): u satisfies corotational equilibrium
            //   after the correction loop.  Use K_e × d_local with T_def so that
            //   K_e × d_local = 0 for rigid body motion → no spurious forces.
            //
            // • TL second-order (!use_corot_forces && is_second_order): u satisfies
            //   TL equilibrium (K_e + K_geo) × T_orig × u = F_ext.  Include K_geo in
            //   recovery so that reactions sum exactly to the applied load.
            //
            // • First-order (!use_corot_forces && !is_second_order): K_e × T_orig × u.
            // k_geo_local_opt: kept for the node-force path so that hinged
            // members include the geometric stiffness contribution in reactions.
            let (k_local_for_recovery, u_local_node, t_for_global, k_geo_local_opt) =
                if use_corot_forces {
                    let (d_local, t_def) =
                        member.extract_corotational_deformations(&u_member_global);
                    (k_local_base.clone(), d_local, t_def, None)
                } else if is_second_order {
                    let n_axial = member.calculate_axial_force_3d(
                        global_displacement_vector,
                        &material_map,
                        &section_map,
                    );
                    let wagner_coeff = member
                        .section
                        .and_then(|sid| section_map.get(&sid))
                        .and_then(|sec| sec.wagner_coeff)
                        .unwrap_or(0.0);
                    let k_geo_local =
                        member.calculate_geometric_stiffness_matrix_3d(n_axial, wagner_coeff);
                    let k_rec = &k_local_base + &k_geo_local;
                    let u_loc = &t_orig * &u_member_global;
                    (k_rec, u_loc, t_orig.clone(), Some(k_geo_local))
                } else {
                    let u_loc = &t_orig * &u_member_global;
                    (k_local_base.clone(), u_loc, t_orig.clone(), None)
                };

            let mut f_eq_local = DVector::<f64>::zeros(ELEMENT_DOFS);
            // Collect distributed loads for section force computation: (w1, w2, a, b, dx, dy, dz)
            let mut member_loads: Vec<(f64, f64, f64, f64, f64, f64, f64)> = Vec::new();
            match result_type {
                ResultType::Loadcase(load_case_id) => {
                    if let Some(load_case) =
                        fers.load_cases.iter().find(|lc| lc.id == *load_case_id)
                    {
                        for distributed_load in &load_case.distributed_loads {
                            if distributed_load.member != member.id
                                || distributed_load.load_case != *load_case_id
                            {
                                continue;
                            }

                            let length = member.calculate_length();

                            // end intensities (same convention as in assembler)
                            let w1 = distributed_load.magnitude;
                            let w2 = distributed_load.end_magnitude;

                            let a = distributed_load.start_frac;
                            let b = distributed_load.end_frac;
                            let d1 = b - a;
                            if d1.abs() < 1e-14 {
                                continue;
                            }
                            let d2 = b * b - a * a;
                            let d3 = b.powi(3) - a.powi(3);
                            let d4 = b.powi(4) - a.powi(4);
                            let d5 = b.powi(5) - a.powi(5);

                            let int_n1 = d1 - d3 + 0.5 * d4;
                            let int_xn1 = 0.5 * d2 - 0.75 * d4 + 0.4 * d5;

                            let int_n3 = d3 - 0.5 * d4;
                            let int_xn3 = 0.75 * d4 - 0.4 * d5;

                            let int_n2 = 0.5 * d2 - (2.0 / 3.0) * d3 + 0.25 * d4;
                            let int_xn2 = (1.0 / 3.0) * d3 - 0.5 * d4 + 0.2 * d5;

                            let int_n4 = (1.0 / 3.0) * d3 - 0.25 * d4;
                            let int_xn4 = 0.25 * d4 - 0.2 * d5;

                            let inv_d1 = 1.0 / d1;

                            let f_s = length
                                * (w1 * int_n1 + (w2 - w1) * inv_d1 * (int_xn1 - a * int_n1));
                            let f_e = length
                                * (w1 * int_n3 + (w2 - w1) * inv_d1 * (int_xn3 - a * int_n3));
                            let m_s = length
                                * length
                                * (w1 * int_n2 + (w2 - w1) * inv_d1 * (int_xn2 - a * int_n2));
                            let m_e = -length
                                * length
                                * (w1 * int_n4 + (w2 - w1) * inv_d1 * (int_xn4 - a * int_n4));

                            // Transform global load direction into local member frame using T (3×3 block)
                            let (dx_g, dy_g, dz_g) = distributed_load.direction;
                            let dx = t_for_global[(0, 0)] * dx_g
                                + t_for_global[(0, 1)] * dy_g
                                + t_for_global[(0, 2)] * dz_g;
                            let dy = t_for_global[(1, 0)] * dx_g
                                + t_for_global[(1, 1)] * dy_g
                                + t_for_global[(1, 2)] * dz_g;
                            let dz = t_for_global[(2, 0)] * dx_g
                                + t_for_global[(2, 1)] * dy_g
                                + t_for_global[(2, 2)] * dz_g;
                            f_eq_local[0] += f_s * dx;
                            f_eq_local[1] += f_s * dy;
                            f_eq_local[2] += f_s * dz;
                            // Fixed-end moments act about the axis perpendicular to
                            // both the member axis (local x) and the load direction:
                            //   (1,0,0) × (dx,dy,dz) = (0, -dz, dy)
                            // so Mx = 0 always (no torsion from a distributed force).
                            f_eq_local[5] += m_s * dy; // Mz
                            f_eq_local[4] -= m_s * dz; // My

                            // end node (offset by DOFS_PER_NODE for 7-DOF system)
                            f_eq_local[DOFS_PER_NODE + 0] += f_e * dx;
                            f_eq_local[DOFS_PER_NODE + 1] += f_e * dy;
                            f_eq_local[DOFS_PER_NODE + 2] += f_e * dz;
                            f_eq_local[DOFS_PER_NODE + 5] += m_e * dy; // Mz
                            f_eq_local[DOFS_PER_NODE + 4] -= m_e * dz; // My

                            member_loads.push((w1, w2, a, b, dx, dy, dz));
                        }
                    }
                }
                ResultType::Loadcombination(load_combination_id) => {
                    if let Some(lc) = fers
                        .load_combinations
                        .iter()
                        .find(|c| c.id == *load_combination_id)
                    {
                        for (case_id, factor) in &lc.load_cases_factors {
                            if let Some(load_case) =
                                fers.load_cases.iter().find(|x| x.id == *case_id)
                            {
                                let mut v_case = DVector::<f64>::zeros(ELEMENT_DOFS);
                                for distributed_load in &load_case.distributed_loads {
                                    if distributed_load.member != member.id
                                        || distributed_load.load_case != *case_id
                                    {
                                        continue;
                                    }

                                    let length = member.calculate_length();

                                    let w1 = distributed_load.magnitude;
                                    let w2 = distributed_load.end_magnitude;

                                    let a = distributed_load.start_frac;
                                    let b = distributed_load.end_frac;
                                    let d1 = b - a;
                                    if d1.abs() < 1e-14 {
                                        continue;
                                    }
                                    let d2 = b * b - a * a;
                                    let d3 = b.powi(3) - a.powi(3);
                                    let d4 = b.powi(4) - a.powi(4);
                                    let d5 = b.powi(5) - a.powi(5);

                                    let int_n1 = d1 - d3 + 0.5 * d4;
                                    let int_xn1 = 0.5 * d2 - 0.75 * d4 + 0.4 * d5;

                                    let int_n3 = d3 - 0.5 * d4;
                                    let int_xn3 = 0.75 * d4 - 0.4 * d5;

                                    let int_n2 = 0.5 * d2 - (2.0 / 3.0) * d3 + 0.25 * d4;
                                    let int_xn2 = (1.0 / 3.0) * d3 - 0.5 * d4 + 0.2 * d5;

                                    let int_n4 = (1.0 / 3.0) * d3 - 0.25 * d4;
                                    let int_xn4 = 0.25 * d4 - 0.2 * d5;

                                    let inv_d1 = 1.0 / d1;

                                    let f_s = length
                                        * (w1 * int_n1
                                            + (w2 - w1) * inv_d1 * (int_xn1 - a * int_n1));
                                    let f_e = length
                                        * (w1 * int_n3
                                            + (w2 - w1) * inv_d1 * (int_xn3 - a * int_n3));
                                    let m_s = length
                                        * length
                                        * (w1 * int_n2
                                            + (w2 - w1) * inv_d1 * (int_xn2 - a * int_n2));
                                    let m_e = -length
                                        * length
                                        * (w1 * int_n4
                                            + (w2 - w1) * inv_d1 * (int_xn4 - a * int_n4));

                                    // Transform global load direction into local member frame using T (3×3 block)
                                    let (dx_g, dy_g, dz_g) = distributed_load.direction;
                                    let dx = t_for_global[(0, 0)] * dx_g
                                        + t_for_global[(0, 1)] * dy_g
                                        + t_for_global[(0, 2)] * dz_g;
                                    let dy = t_for_global[(1, 0)] * dx_g
                                        + t_for_global[(1, 1)] * dy_g
                                        + t_for_global[(1, 2)] * dz_g;
                                    let dz = t_for_global[(2, 0)] * dx_g
                                        + t_for_global[(2, 1)] * dy_g
                                        + t_for_global[(2, 2)] * dz_g;

                                    v_case[0] += f_s * dx;
                                    v_case[1] += f_s * dy;
                                    v_case[2] += f_s * dz;
                                    // No torsion: (1,0,0) × (dx,dy,dz) = (0, -dz, dy)
                                    v_case[5] += m_s * dy; // Mz
                                    v_case[4] -= m_s * dz; // My

                                    v_case[DOFS_PER_NODE + 0] += f_e * dx;
                                    v_case[DOFS_PER_NODE + 1] += f_e * dy;
                                    v_case[DOFS_PER_NODE + 2] += f_e * dz;
                                    v_case[DOFS_PER_NODE + 5] += m_e * dy; // Mz
                                    v_case[DOFS_PER_NODE + 4] -= m_e * dz; // My

                                    member_loads.push((w1 * factor, w2 * factor, a, b, dx, dy, dz));
                                }

                                f_eq_local += v_case * (*factor);
                            }
                        }
                    }
                }
            }

            // hinge modes (per end, local axes)
            let a_h = member
                .start_hinge
                .and_then(|id| hinge_map.get(&id).copied());
            let b_h = member.end_hinge.and_then(|id| hinge_map.get(&id).copied());
            let (a_trans, a_rot, b_trans, b_rot, a_warp, b_warp) = modes_from_single_ends(a_h, b_h);

            let has_spring_hinge = member.start_hinge.is_some() || member.end_hinge.is_some();

            // --- BEAM-SIDE forces (for section force integration) ---
            // Include f_eq in spring recovery RHS so the beam-end deformations
            // correctly account for distributed loads through spring hinges.
            // This is consistent with the condensed F_global in the load assembler.
            let q_beam_local = recover_member_end_forces_local(
                &k_local_for_recovery,
                &u_local_node,
                &f_eq_local,
                &a_trans,
                &a_rot,
                &b_trans,
                &b_rot,
                &a_warp,
                &b_warp,
                has_spring_hinge,
            );

            // --- NODE forces (for reactions) ---
            // For members with spring hinges, compute node forces from the
            // condensed element: K_condensed * u_node - f_eq_condensed.
            // In second-order analysis, the assembly condenses K_e and K_geo
            // separately, so the recovery must also include cond(K_geo) * u.
            let q_node_local = if has_spring_hinge {
                let f_eq_mat = DMatrix::from_column_slice(ELEMENT_DOFS, 1, f_eq_local.as_slice());
                let k_condensed_opt = apply_end_releases_to_local_beam_k(
                    &k_local_base,
                    a_trans,
                    a_rot,
                    b_trans,
                    b_rot,
                    a_warp,
                    b_warp,
                );
                let f_eq_condensed_opt = apply_end_releases_to_local_beam_f(
                    &k_local_base,
                    &f_eq_mat,
                    a_trans,
                    a_rot,
                    b_trans,
                    b_rot,
                    a_warp,
                    b_warp,
                );
                match (k_condensed_opt, f_eq_condensed_opt) {
                    (Ok(k_c), Ok(f_c)) => {
                        let f_c_vec = DVector::from_column_slice(f_c.as_slice());
                        let mut q = &k_c * &u_local_node - &f_c_vec;

                        // Add geometric stiffness contribution for second-order
                        if let Some(ref k_geo) = k_geo_local_opt {
                            if let Ok(k_geo_c) = apply_end_releases_to_local_beam_k(
                                k_geo,
                                a_trans,
                                a_rot,
                                b_trans,
                                b_rot,
                                a_warp,
                                b_warp,
                            ) {
                                q += &k_geo_c * &u_local_node;
                            }
                        }

                        q
                    }
                    _ => q_beam_local.clone(),
                }
            } else {
                q_beam_local.clone()
            };

            // Report end forces in GLOBAL (for reactions)
            let global_force_vector = t_for_global.transpose() * &q_node_local;

            // Local member-end forces for section force computation (beam-side).
            let q_orig_local_sections = if use_corot_forces {
                let gfv_sec = t_for_global.transpose() * &q_beam_local;
                &t_orig * &gfv_sec
            } else {
                q_beam_local.clone()
            };
            let local_start_forces = NodeForces {
                fx: q_orig_local_sections[0],
                fy: q_orig_local_sections[1],
                fz: q_orig_local_sections[2],
                mx: q_orig_local_sections[3],
                my: q_orig_local_sections[4],
                mz: q_orig_local_sections[5],
                bw: q_orig_local_sections[6],
            };
            let local_end_forces = NodeForces {
                fx: q_orig_local_sections[DOFS_PER_NODE + 0],
                fy: q_orig_local_sections[DOFS_PER_NODE + 1],
                fz: q_orig_local_sections[DOFS_PER_NODE + 2],
                mx: q_orig_local_sections[DOFS_PER_NODE + 3],
                my: q_orig_local_sections[DOFS_PER_NODE + 4],
                mz: q_orig_local_sections[DOFS_PER_NODE + 5],
                bw: q_orig_local_sections[DOFS_PER_NODE + 6],
            };

            // Section forces at intermediate points (for BMD/SFD plotting)
            let beam_length = member.calculate_length();
            let section_forces =
                compute_section_forces(&local_start_forces, &member_loads, beam_length);

            let start_node_forces = NodeForces {
                fx: global_force_vector[0],
                fy: global_force_vector[1],
                fz: global_force_vector[2],
                mx: global_force_vector[3],
                my: global_force_vector[4],
                mz: global_force_vector[5],
                bw: global_force_vector[6],
            };
            let end_node_forces = NodeForces {
                fx: global_force_vector[DOFS_PER_NODE + 0],
                fy: global_force_vector[DOFS_PER_NODE + 1],
                fz: global_force_vector[DOFS_PER_NODE + 2],
                mx: global_force_vector[DOFS_PER_NODE + 3],
                my: global_force_vector[DOFS_PER_NODE + 4],
                mz: global_force_vector[DOFS_PER_NODE + 5],
                bw: global_force_vector[DOFS_PER_NODE + 6],
            };

            let (mut maximums, mut minimums) =
                compute_component_extrema(&start_node_forces, &end_node_forces);

            // Include intermediate section forces in extrema (they capture
            // midspan peaks from distributed loads / self-weight that the
            // end-forces alone would miss).
            if !section_forces.is_empty() {
                let r00 = t_orig[(0, 0)];
                let r01 = t_orig[(0, 1)];
                let r02 = t_orig[(0, 2)];
                let r10 = t_orig[(1, 0)];
                let r11 = t_orig[(1, 1)];
                let r12 = t_orig[(1, 2)];
                let r20 = t_orig[(2, 0)];
                let r21 = t_orig[(2, 1)];
                let r22 = t_orig[(2, 2)];
                for sf in &section_forces {
                    let lf = &sf.forces;
                    // R^T * local_force (rotation to global)
                    let gfx = r00 * lf.fx + r10 * lf.fy + r20 * lf.fz;
                    let gfy = r01 * lf.fx + r11 * lf.fy + r21 * lf.fz;
                    let gfz = r02 * lf.fx + r12 * lf.fy + r22 * lf.fz;
                    let gmx = r00 * lf.mx + r10 * lf.my + r20 * lf.mz;
                    let gmy = r01 * lf.mx + r11 * lf.my + r21 * lf.mz;
                    let gmz = r02 * lf.mx + r12 * lf.my + r22 * lf.mz;
                    maximums.fx = maximums.fx.max(gfx);
                    maximums.fy = maximums.fy.max(gfy);
                    maximums.fz = maximums.fz.max(gfz);
                    maximums.mx = maximums.mx.max(gmx);
                    maximums.my = maximums.my.max(gmy);
                    maximums.mz = maximums.mz.max(gmz);
                    minimums.fx = minimums.fx.min(gfx);
                    minimums.fy = minimums.fy.min(gfy);
                    minimums.fz = minimums.fz.min(gfz);
                    minimums.mx = minimums.mx.min(gmx);
                    minimums.my = minimums.my.min(gmy);
                    minimums.mz = minimums.mz.min(gmz);
                }
            }
            // Compute local extrema from local start/end forces and section forces
            let (mut local_maximums, mut local_minimums) =
                compute_component_extrema(&local_start_forces, &local_end_forces);
            for sf in &section_forces {
                let lf = &sf.forces;
                local_maximums.fx = local_maximums.fx.max(lf.fx);
                local_maximums.fy = local_maximums.fy.max(lf.fy);
                local_maximums.fz = local_maximums.fz.max(lf.fz);
                local_maximums.mx = local_maximums.mx.max(lf.mx);
                local_maximums.my = local_maximums.my.max(lf.my);
                local_maximums.mz = local_maximums.mz.max(lf.mz);
                local_maximums.bw = local_maximums.bw.max(lf.bw);
                local_minimums.fx = local_minimums.fx.min(lf.fx);
                local_minimums.fy = local_minimums.fy.min(lf.fy);
                local_minimums.fz = local_minimums.fz.min(lf.fz);
                local_minimums.mx = local_minimums.mx.min(lf.mx);
                local_minimums.my = local_minimums.my.min(lf.my);
                local_minimums.mz = local_minimums.mz.min(lf.mz);
                local_minimums.bw = local_minimums.bw.min(lf.bw);
            }
            results_by_member_identifier.insert(
                member.id,
                MemberResult {
                    start_node_forces,
                    end_node_forces,
                    maximums,
                    minimums,
                    local_start_forces,
                    local_end_forces,
                    local_maximums,
                    local_minimums,
                    local_displacement_start_node,
                    local_displacement_end_node,
                    section_forces,
                },
            );
        }
    }

    results_by_member_identifier
}
