#
# This code is auto-generated from CLIc 'cle::tier7.hpp' file, do not edit manually.
#

import importlib
import warnings
from typing import Optional

import numpy as np

from ._array import Image
from ._backend import _get_backend
from ._core import Device
from ._decorators import plugin_function


@plugin_function
def affine_transform(
    input_image: Image,
    output_image: Optional[Image] = None,
    transform_matrix: Optional[list] = None,
    interpolate: bool = False,
    resize: bool = False,
    device: Optional[Device] = None,
) -> Image:
    """Applies an affine transformation matrix to an array and returns the result.  The
    transformation matrix must be 3×3 or 4×4, stored as a 1D array.  The matrix
    should be row-major, i.e., the first 3 elements are the first row of the matrix.
    If no matrix is given, the identity matrix will be used.

    Parameters
    ----------
    input_image: Image
        Input image to be transformed.
    output_image: Optional[Image] (= None)
        Output image.
    transform_matrix: Optional[list] (= None)
        Affine transformation matrix (3×3 or 4×4).
    interpolate: bool (= False)
        If true, bi/trilinear interpolation will be applied, if hardware allows.
    resize: bool (= False)
        Automatically determines the size of the output depending on the rotation angles.
    device: Optional[Device] (= None)
        Device to perform the operation on.

    Returns
    -------
    Image
    """
    return _get_backend()._affine_transform(
        device, input_image, output_image, transform_matrix, interpolate, resize
    )


@plugin_function(categories=["label", "in assistant"])
def eroded_otsu_labeling(
    input_image: Image,
    output_image: Optional[Image] = None,
    number_of_erosions: int = 5,
    outline_sigma: float = 2,
    device: Optional[Device] = None,
) -> Image:
    """Segments and labels an image using blurring, Otsu thresholding, binary erosion,
    and  masked Voronoi labeling.  After blurring and Otsu thresholding the image,
    iterative binary erosion is applied.  Objects in the eroded image are labeled,
    and the labels are extended to fit again into  the initial binary image using
    masked Voronoi labeling.  This function is similar to voronoi_otsu_labeling. It
    is intended to deal better with  cases where labels of objects swap into each
    other when objects are dense. As when using  Voronoi-Otsu labeling, small
    objects may disappear when applying this operation.  This function is inspired
    by a similar implementation in Java by Jan Brocher (Biovoxxel).

    Parameters
    ----------
    input_image: Image
        Input image to be transformed.
    output_image: Optional[Image] (= None)
        Output label image.
    number_of_erosions: int (= 5)
        Number of erosion iterations.
    outline_sigma: float (= 2)
        Gaussian blur sigma applied before Otsu thresholding.
    device: Optional[Device] (= None)
        Device to perform the operation on.

    Returns
    -------
    Image

    References
    ----------
    [1] https://github.com/biovoxxel/bv3dbox
    [2] https://zenodo.org/badge/latestdoi/434949702
    """
    return _get_backend()._eroded_otsu_labeling(
        device, input_image, output_image, int(number_of_erosions), float(outline_sigma)
    )


@plugin_function(categories=["transform", "in assistant"])
def rigid_transform(
    input_image: Image,
    output_image: Optional[Image] = None,
    translate_x: float = 0,
    translate_y: float = 0,
    translate_z: float = 0,
    angle_x: float = 0,
    angle_y: float = 0,
    angle_z: float = 0,
    centered: bool = True,
    interpolate: bool = False,
    resize: bool = False,
    device: Optional[Device] = None,
) -> Image:
    """Translates the image by a given vector and rotates it by given angles. Angles
    are given in radians. To convert degrees to radians, use this formula:
    angle_in_radians = angle_in_degrees × π / 180.0

    Parameters
    ----------
    input_image: Image
        Input image to be transformed.
    output_image: Optional[Image] (= None)
        Output image.
    translate_x: float (= 0)
        Translation along x axis in pixels.
    translate_y: float (= 0)
        Translation along y axis in pixels.
    translate_z: float (= 0)
        Translation along z axis in pixels.
    angle_x: float (= 0)
        Rotation around x axis in radians.
    angle_y: float (= 0)
        Rotation around y axis in radians.
    angle_z: float (= 0)
        Rotation around z axis in radians.
    centered: bool (= True)
        If true, rotate image around center; otherwise, around the origin.
    interpolate: bool (= False)
        If true, bi/trilinear interpolation will be applied, if hardware allows.
    resize: bool (= False)
        Automatically determines the size of the output depending on the rotation angles.
    device: Optional[Device] (= None)
        Device to perform the operation on.

    Returns
    -------
    Image
    """
    return _get_backend()._rigid_transform(
        device,
        input_image,
        output_image,
        float(translate_x),
        float(translate_y),
        float(translate_z),
        float(angle_x),
        float(angle_y),
        float(angle_z),
        centered,
        interpolate,
        resize,
    )


@plugin_function(categories=["transform", "in assistant"])
def rotate(
    input_image: Image,
    output_image: Optional[Image] = None,
    angle_x: float = 0,
    angle_y: float = 0,
    angle_z: float = 0,
    centered: bool = True,
    interpolate: bool = False,
    resize: bool = False,
    device: Optional[Device] = None,
) -> Image:
    """Rotates the image by given angles. Angles are given in degrees. To convert
    radians to degrees, use this formula: angle_in_degrees = angle_in_radians ×
    180.0 / π

    Parameters
    ----------
    input_image: Image
        Input image to be rotated.
    output_image: Optional[Image] (= None)
        Output image.
    angle_x: float (= 0)
        Rotation around x axis in degrees.
    angle_y: float (= 0)
        Rotation around y axis in degrees.
    angle_z: float (= 0)
        Rotation around z axis in degrees.
    centered: bool (= True)
        If true, rotate image around center; otherwise, around the origin.
    interpolate: bool (= False)
        If true, bi/trilinear interpolation will be applied, if hardware allows.
    resize: bool (= False)
        Automatically determines the size of the output depending on the rotation angles.
    device: Optional[Device] (= None)
        Device to perform the operation on.

    Returns
    -------
    Image
    """
    return _get_backend()._rotate(
        device,
        input_image,
        output_image,
        float(angle_x),
        float(angle_y),
        float(angle_z),
        centered,
        interpolate,
        resize,
    )


@plugin_function(categories=["transform", "in assistant"])
def scale(
    input_image: Image,
    output_image: Optional[Image] = None,
    factor_x: float = 1,
    factor_y: float = 1,
    factor_z: float = 1,
    centered: bool = True,
    interpolate: bool = False,
    resize: bool = False,
    device: Optional[Device] = None,
) -> Image:
    """Scales the image by given factors.

    Parameters
    ----------
    input_image: Image
        Input image to be scaled.
    output_image: Optional[Image] (= None)
        Output image.
    factor_x: float (= 1)
        Scaling factor along x axis.
    factor_y: float (= 1)
        Scaling factor along y axis.
    factor_z: float (= 1)
        Scaling factor along z axis.
    centered: bool (= True)
        If true, the image will be scaled around the center of the image.
    interpolate: bool (= False)
        If true, bi/trilinear interpolation will be applied.
    resize: bool (= False)
        Automatically determines the output image size.
    device: Optional[Device] (= None)
        Device to perform the operation on.

    Returns
    -------
    Image
    """
    return _get_backend()._scale(
        device,
        input_image,
        output_image,
        float(factor_x),
        float(factor_y),
        float(factor_z),
        centered,
        interpolate,
        resize,
    )


@plugin_function(categories=["transform", "in assistant"])
def translate(
    input_image: Image,
    output_image: Optional[Image] = None,
    translate_x: float = 0,
    translate_y: float = 0,
    translate_z: float = 0,
    interpolate: bool = False,
    device: Optional[Device] = None,
) -> Image:
    """Translates the image by a given vector.

    Parameters
    ----------
    input_image: Image
        Input image to be translated.
    output_image: Optional[Image] (= None)
        Output image.
    translate_x: float (= 0)
        Translation along x axis in pixels.
    translate_y: float (= 0)
        Translation along y axis in pixels.
    translate_z: float (= 0)
        Translation along z axis in pixels.
    interpolate: bool (= False)
        If true, bi/trilinear interpolation will be applied.
    device: Optional[Device] (= None)
        Device to perform the operation on.

    Returns
    -------
    Image
    """
    return _get_backend()._translate(
        device,
        input_image,
        output_image,
        float(translate_x),
        float(translate_y),
        float(translate_z),
        interpolate,
    )


@plugin_function
def deskew_x(
    input_image: Image,
    output_image: Optional[Image] = None,
    angle: float = 30,
    voxel_size_x: float = 1.0,
    voxel_size_y: float = 1.0,
    voxel_size_z: float = 1.0,
    scale_factor: float = 1.0,
    device: Optional[Device] = None,
) -> Image:
    """Deskews a volume as acquired with oblique plane light-sheet microscopy with skew
    in the x direction.

    Parameters
    ----------
    input_image: Image
        Input image to be deskewed.
    output_image: Optional[Image] (= None)
        Output image.
    angle: float (= 30)
        Angle in degrees.
    voxel_size_x: float (= 1.0)
        Voxel size in x direction.
    voxel_size_y: float (= 1.0)
        Voxel size in y direction.
    voxel_size_z: float (= 1.0)
        Voxel size in z direction.
    scale_factor: float (= 1.0)
        Downscaling factor after deskewing.
    device: Optional[Device] (= None)
        Device to perform the operation on.

    Returns
    -------
    Image
    """
    return _get_backend()._deskew_x(
        device,
        input_image,
        output_image,
        float(angle),
        float(voxel_size_x),
        float(voxel_size_y),
        float(voxel_size_z),
        float(scale_factor),
    )


@plugin_function
def deskew_y(
    input_image: Image,
    output_image: Optional[Image] = None,
    angle: float = 30,
    voxel_size_x: float = 1.0,
    voxel_size_y: float = 1.0,
    voxel_size_z: float = 1.0,
    scale_factor: float = 1.0,
    device: Optional[Device] = None,
) -> Image:
    """Deskews a volume as acquired with oblique plane light-sheet microscopy with skew
    in the y direction.

    Parameters
    ----------
    input_image: Image
        Input image to be deskewed.
    output_image: Optional[Image] (= None)
        Output image.
    angle: float (= 30)
        Angle in degrees.
    voxel_size_x: float (= 1.0)
        Voxel size in x direction.
    voxel_size_y: float (= 1.0)
        Voxel size in y direction.
    voxel_size_z: float (= 1.0)
        Voxel size in z direction.
    scale_factor: float (= 1.0)
        Downscaling factor after deskewing.
    device: Optional[Device] (= None)
        Device to perform the operation on.

    Returns
    -------
    Image
    """
    return _get_backend()._deskew_y(
        device,
        input_image,
        output_image,
        float(angle),
        float(voxel_size_x),
        float(voxel_size_y),
        float(voxel_size_z),
        float(scale_factor),
    )


@plugin_function(categories=["label processing", "in assistant"])
def closing_labels(
    input_image: Image,
    output_image: Optional[Image] = None,
    radius: int = 0,
    device: Optional[Device] = None,
) -> Image:
    """Applies a morphological closing operation to a label image. The operation
    consists of iterative dilation and erosion of the labels. With every iteration,
    box and diamond/sphere structuring elements are used; thus, the operation has an
    octagon as the structuring element. Note: This operation assumes input images
    are isotropic.

    Parameters
    ----------
    input_image: Image
        Input label image.
    output_image: Optional[Image] (= None)
        Output label image.
    radius: int (= 0)
        Radius size for the closing.
    device: Optional[Device] (= None)
        Device to perform the operation on.

    Returns
    -------
    Image
    """
    return _get_backend()._closing_labels(
        device, input_image, output_image, int(radius)
    )


@plugin_function(categories=["label processing", "in assistant"])
def erode_connected_labels(
    input_image: Image,
    output_image: Optional[Image] = None,
    radius: int = 1,
    device: Optional[Device] = None,
) -> Image:
    """Erodes labels to a smaller size. Note: Depending on the label image and the
    radius,  labels may disappear and labels may split into multiple islands. Thus,
    overlapping labels of input and output may  not have the same identifier.

    Parameters
    ----------
    input_image: Image
        Input image to process.
    output_image: Optional[Image] (= None)
        Output label image.
    radius: int (= 1)
        Erosion
    device: Optional[Device] (= None)
        Device to perform the operation on.

    Returns
    -------
    Image
    """
    return _get_backend()._erode_connected_labels(
        device, input_image, output_image, int(radius)
    )


@plugin_function(categories=["label processing", "in assistant"])
def opening_labels(
    input_image: Image,
    output_image: Optional[Image] = None,
    radius: int = 0,
    device: Optional[Device] = None,
) -> Image:
    """Applies a morphological opening operation to a label image. The operation
    consists of iterative erosion and dilation of the labels. With every iteration,
    box and diamond/sphere structuring elements are used; thus, the operation has an
    octagon as the structuring element. Note: This operation assumes input images
    are isotropic.

    Parameters
    ----------
    input_image: Image
        Input label image.
    output_image: Optional[Image] (= None)
        Output label image.
    radius: int (= 0)
        Radius size for the opening.
    device: Optional[Device] (= None)
        Device to perform the operation on.

    Returns
    -------
    Image
    """
    return _get_backend()._opening_labels(
        device, input_image, output_image, int(radius)
    )


@plugin_function(categories=["label", "in assistant", "bia-bob-suggestion"])
def voronoi_otsu_labeling(
    input_image: Image,
    output_image: Optional[Image] = None,
    spot_sigma: float = 2,
    outline_sigma: float = 2,
    device: Optional[Device] = None,
) -> Image:
    """Labels objects directly from gray-value images. The two sigma parameters allow
    tuning the segmentation result. Under the hood, this filter applies two Gaussian
    blurs, spot detection, Otsu thresholding, and Voronoi labeling. The thresholded
    binary image is flooded using the Voronoi tessellation approach starting from
    the found local maxima. Note: This operation assumes input images are isotropic.

    Parameters
    ----------
    input_image: Image
        Input intensity image.
    output_image: Optional[Image] (= None)
        Output label image.
    spot_sigma: float (= 2)
        Controls how close detected cells can be.
    outline_sigma: float (= 2)
        Controls how precisely segmented objects are outlined.
    device: Optional[Device] (= None)
        Device to perform the operation on.

    Returns
    -------
    Image

    References
    ----------
    [1] https://clij.github.io/clij2-docs/reference_voronoiOtsuLabeling
    [2] https://ieeexplore.ieee.org/document/4310076
    [3] https://en.wikipedia.org/wiki/Voronoi_diagram
    """
    return _get_backend()._voronoi_otsu_labeling(
        device, input_image, output_image, float(spot_sigma), float(outline_sigma)
    )


__all__ = [
    "affine_transform",
    "eroded_otsu_labeling",
    "rigid_transform",
    "rotate",
    "scale",
    "translate",
    "deskew_x",
    "deskew_y",
    "closing_labels",
    "erode_connected_labels",
    "opening_labels",
    "voronoi_otsu_labeling",
]
