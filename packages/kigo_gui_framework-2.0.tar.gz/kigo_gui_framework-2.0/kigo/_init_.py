# kigo/__init__.py
__version__ = "1.9.0"

__all__ = ["App", "Window", "Button", "Label", "UILoader"]

from .core.app import App
from .widgets.window import Window
from .widgets.button import Button
from .widgets.label import Label
from .core.ui_loader import UILoader