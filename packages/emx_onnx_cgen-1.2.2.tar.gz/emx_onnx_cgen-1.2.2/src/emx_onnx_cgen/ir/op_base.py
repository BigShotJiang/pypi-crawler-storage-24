from __future__ import annotations

import dataclasses
from abc import ABC, abstractmethod
from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from typing import ClassVar, Protocol

from shared.scalar_functions import ScalarFunction
from shared.scalar_types import ScalarType

from ..errors import ShapeInferenceError, UnsupportedOpError
from .op_context import OpContext


class Emitter(Protocol):
    def emit_generic_op(self, op: "OpBase", ctx: "EmitContext") -> str: ...
    def require_emit_state(self): ...
    def op_function_name(self, model, index: int) -> str: ...
    def with_node_comment(self, model, index: int, rendered: str) -> str: ...
    def shared_param_map(self, items: list[tuple[str, str | None]]): ...
    def ctx_shape(self, name: str) -> tuple[int, ...]: ...
    def ctx_dtype(self, name: str): ...
    def derived(self, op: "OpBase", key: str): ...
    def param_array_suffix(
        self,
        shape: tuple[int, ...],
        dim_names: Mapping[int, str] | None = ...,
        *,
        dtype: "ScalarType | None" = ...,
    ) -> str: ...
    def build_param_decls(self, params): ...
    def accumulation_dtype(self, dtype) -> "ScalarType": ...
    def format_literal(self, dtype, value: float | int | bool) -> str: ...
    def format_floating(self, value: float, dtype) -> str: ...
    def dim_names_for(self, name: str) -> Mapping[int, str]: ...
    def dim_args_str(self) -> str: ...
    def rnn_activation_function_name(
        self, kind: str, alpha: float, beta: float, dtype: "ScalarType"
    ) -> str: ...
    def scalar_registry(self): ...
    @property
    def replicate_ort_bugs(self) -> bool: ...
    def op_output_dtype(self, op: "OpBase") -> "ScalarType": ...
    def unique_param_map(self, items: list[tuple[str, str | None]]): ...
    def optional_input_flag_map(self, model) -> dict[str, str]: ...
    def ctx_sequence_elem_type(self, name: str): ...
    def sequence_storage_shape(self, name: str) -> tuple[int, ...]: ...
    def format_value(self, value: float | int | bool, dtype: "ScalarType") -> str: ...
    def dft_stockham_stage_plan(self, fft_length: int): ...
    def dft_twiddle_table(
        self, fft_length: int, *, inverse: bool, dtype: "ScalarType"
    ): ...
    def format_c_string_literal(self, value: str) -> str: ...
    def format_double(self, value: float) -> str: ...
    def emit_initializer_lines(self, values, shape: tuple[int, ...]) -> list[str]: ...
    def index_expr(self, shape: tuple[int, ...], loop_vars: tuple[str, ...]) -> str: ...
    def format_c_indentation(self, text: str) -> str: ...
    def scalar_fn(
        self,
        function: "ScalarFunction",
        dtype: "ScalarType",
        params: tuple[float, ...] = ...,
    ) -> str | None: ...
    def maybe_derived(self, op: "OpBase", key: str) -> object | None: ...


@dataclass(frozen=True)
class EmitContext:
    op_index: int


@dataclass(frozen=True)
class CodegenDim:
    name: str
    expected_size: int = 10

    def __str__(self) -> str:
        return self.name


class OpBase(ABC):
    """Ops should not mutate themselves; store derived values in OpContext."""

    __io_inputs__: ClassVar[tuple[str, ...] | None] = None
    __io_outputs__: ClassVar[tuple[str, ...] | None] = None

    @property
    def input_names(self) -> tuple[str, ...]:
        input_fields, _ = _io_field_names(type(self))
        return _resolve_io_names(self, input_fields)

    @property
    def output_names(self) -> tuple[str, ...]:
        _, output_fields = _io_field_names(type(self))
        return _resolve_io_names(self, output_fields)

    @property
    def primary_output_name(self) -> str | None:
        """Tensor name of the primary output for dtype/shape queries.

        Returns the value of the first ``__io_outputs__`` field, or ``None``
        for ops that don't have a simple primary output (e.g. sequence ops).
        Subclasses may override to select a different output field.
        """
        _, output_fields = _io_field_names(type(self))
        if not output_fields:
            return None
        value = getattr(self, output_fields[0])
        if isinstance(value, str):
            return value
        if isinstance(value, tuple) and value:
            return value[0]
        return None

    def call_args(self) -> tuple[str, ...]:
        return self.input_names + self.output_names

    def __getattr__(self, name: str) -> str:
        if name == "kind":
            return self.__class__.__name__
        raise AttributeError(
            f"'{self.__class__.__name__}' object has no attribute '{name}'"
        )

    def required_includes(self, ctx: OpContext) -> set[str]:
        """Return C include directives needed by this op (e.g. ``{'#include <math.h>'}``)."""
        return set()

    def extra_model_dtypes(self, ctx: OpContext) -> set[ScalarType]:
        """Return additional dtypes beyond the primary output needed for include resolution."""
        return set()

    def resolved_output_dtype(self, ctx: OpContext) -> "ScalarType":
        """Return the primary output dtype using OpContext (for include resolution)."""
        name = self.primary_output_name
        if name is not None:
            return ctx.dtype(name)
        return self.dtype

    def validate(self, ctx: OpContext) -> None:
        return None

    def infer_types(self, ctx: OpContext) -> None:
        return None

    def infer_shapes(self, ctx: OpContext) -> None:
        return None

    def c_op_inputs(
        self, emitter: "Emitter"
    ) -> tuple[tuple[str, tuple[int, ...]], ...]:
        """Return (name, shape) pairs for C function input parameters."""
        return tuple(
            (name, emitter.ctx_shape(name))
            for name in self.input_names
            if name is not None
        )

    def c_op_outputs(
        self, emitter: "Emitter"
    ) -> "tuple[tuple[str, tuple[int, ...], ScalarType], ...]":
        """Return (name, shape, dtype) triples for C function output parameters."""
        name = self.primary_output_name
        if name is not None:
            return (
                (
                    name,
                    self.computed_output_shape(emitter),
                    self.computed_output_dtype(emitter),
                ),
            )
        raise UnsupportedOpError(f"Cannot determine outputs for {self.kind}")

    def computed_output_shape(self, emitter: "Emitter") -> tuple[int, ...]:
        """Return the output shape for this op. Default: ctx_shape(primary_output_name)."""
        name = self.primary_output_name
        if name is not None:
            return emitter.ctx_shape(name)
        raise UnsupportedOpError(f"Cannot determine output shape for {self.kind}")

    def computed_output_dtype(self, emitter: "Emitter") -> "ScalarType":
        """Return the output dtype for this op. Default: ctx_dtype(primary_output_name)."""
        name = self.primary_output_name
        if name is not None:
            return emitter.ctx_dtype(name)
        return self.dtype

    @abstractmethod
    def emit(self, emitter: Emitter, ctx: EmitContext) -> str:
        raise NotImplementedError

    def remap_names(self, name_map: dict[str, str]) -> OpBase:
        """Return a copy with I/O tensor-name fields remapped via *name_map*.

        Fields declared in ``__io_inputs__`` / ``__io_outputs__`` (and the
        optional ``__io_remap_extra__``) are touched.  Handles ``str``,
        ``str | None`` and ``tuple[str, ...]`` / ``tuple[str | None, ...]``.
        """
        input_fields, output_fields = _io_field_names(type(self))
        io_fields = set(input_fields + output_fields)
        extra = getattr(type(self), "__io_remap_extra__", None)
        if extra:
            io_fields.update(extra)
        changes: dict[str, object] = {}
        for field_name in io_fields:
            value = getattr(self, field_name)
            if value is None:
                continue
            if isinstance(value, str):
                new_value = name_map.get(value, value)
            elif isinstance(value, tuple):
                new_value = tuple(
                    name_map.get(v, v) if v is not None else None for v in value
                )
            else:
                continue
            if new_value is not value and new_value != value:
                changes[field_name] = new_value
        if not changes:
            return self
        return dataclasses.replace(self, **changes)  # type: ignore[type-var]


class RenderableOpBase(OpBase):
    def emit(self, emitter: Emitter, ctx: EmitContext) -> str:
        return emitter.emit_generic_op(self, ctx)


class ElementwiseOpBase(RenderableOpBase):
    """Elementwise ops should validate against OpContext and store no derived state."""

    def emit(self, emitter: Emitter, ctx: EmitContext) -> str:
        return emitter.emit_generic_op(self, ctx)

    __io_outputs__ = ("output",)

    def _elementwise_inputs(self) -> tuple[str, ...]:
        raise NotImplementedError

    def _elementwise_output(self) -> str:
        raise NotImplementedError

    def _elementwise_condition_inputs(self) -> tuple[str, ...]:
        return ()

    def _elementwise_compare(self) -> bool:
        return False

    def _elementwise_data_inputs(self) -> tuple[str, ...]:
        inputs = self._elementwise_inputs()
        condition_inputs = set(self._elementwise_condition_inputs())
        return tuple(name for name in inputs if name not in condition_inputs)

    def validate(self, ctx: OpContext) -> None:
        condition_inputs = self._elementwise_condition_inputs()
        for name in condition_inputs:
            dtype = ctx.dtype(name)
            if dtype != ScalarType.BOOL:
                raise UnsupportedOpError(
                    f"{self.kind} expects bool condition, got {dtype.onnx_name}"
                )
        data_inputs = self._elementwise_data_inputs()
        if not data_inputs:
            return None
        data_dtypes = tuple(ctx.dtype(name) for name in data_inputs)
        if any(dtype != data_dtypes[0] for dtype in data_dtypes[1:]):
            dtype_names = ", ".join(dtype.onnx_name for dtype in data_dtypes)
            raise UnsupportedOpError(
                f"{self.kind} expects matching input dtypes, got {dtype_names}"
            )
        try:
            output_dtype = ctx.dtype(self._elementwise_output())
        except ShapeInferenceError:
            return None
        if self._elementwise_compare():
            if output_dtype != ScalarType.BOOL:
                raise UnsupportedOpError(
                    f"{self.kind} expects bool output, got {output_dtype.onnx_name}"
                )
            return None
        if output_dtype != data_dtypes[0]:
            raise UnsupportedOpError(
                f"{self.kind} expects output dtype {data_dtypes[0].onnx_name}, "
                f"got {output_dtype.onnx_name}"
            )
        return None

    def infer_types(self, ctx: OpContext) -> None:
        input_names = self._elementwise_inputs()
        output_name = self._elementwise_output()
        for name in input_names:
            ctx.dtype(name)
        desired_dtype = ScalarType.BOOL if self._elementwise_compare() else None
        if desired_dtype is None:
            data_inputs = self._elementwise_data_inputs()
            if data_inputs:
                desired_dtype = ctx.dtype(data_inputs[0])
        try:
            output_dtype = ctx.dtype(output_name)
        except ShapeInferenceError:
            if desired_dtype is not None:
                ctx.set_dtype(output_name, desired_dtype)
                return None
            raise
        if desired_dtype is not None and output_dtype != desired_dtype:
            raise UnsupportedOpError(
                f"{self.kind} expects output dtype {desired_dtype.onnx_name}, "
                f"got {output_dtype.onnx_name}"
            )

    def infer_shapes(self, ctx: OpContext) -> None:
        input_names = self._elementwise_inputs()
        output_name = self._elementwise_output()
        input_shapes = tuple(ctx.shape(name) for name in input_names)
        if len(input_shapes) == 1:
            output_shape = input_shapes[0]
        else:
            output_shape = BroadcastingOpBase.broadcast_shapes(*input_shapes)
        ctx.set_shape(output_name, output_shape)
        return None


class GatherLikeOpBase(RenderableOpBase):
    def emit(self, emitter: Emitter, ctx: EmitContext) -> str:
        state = emitter.require_emit_state()
        model = state.model
        op_name = emitter.op_function_name(model, ctx.op_index)
        c_type = emitter.ctx_dtype(self._gather_output()).c_type
        params = emitter.shared_param_map(
            [
                ("data", self._gather_data()),
                ("indices", self._gather_indices()),
                ("output", self._gather_output()),
            ]
        )
        output_shape_raw = emitter.ctx_shape(self._gather_output())
        output_shape = CEmitterCompat.codegen_shape(output_shape_raw)
        loop_vars = CEmitterCompat.loop_vars(output_shape_raw)
        render_output_shape = output_shape if output_shape else (1,)
        render_loop_vars = loop_vars if loop_vars else ("i0",)
        output_loop_vars = loop_vars if output_shape_raw else ()
        indices_shape = emitter.ctx_shape(self._gather_indices())
        indices_rank = len(indices_shape)
        axis = int(emitter.derived(self, "axis"))
        indices_indices = (
            ("0",)
            if indices_rank == 0
            else output_loop_vars[axis : axis + indices_rank]
        )
        data_indices = [
            *output_loop_vars[:axis],
            "gather_index",
            *output_loop_vars[axis + indices_rank :],
        ]
        data_shape = emitter.ctx_shape(self._gather_data())
        data_suffix = emitter.param_array_suffix(data_shape)
        indices_suffix = emitter.param_array_suffix(indices_shape)
        output_suffix = emitter.param_array_suffix(output_shape_raw)
        indices_dtype = emitter.ctx_dtype(self._gather_indices())
        param_decls = emitter.build_param_decls(
            [
                (params["data"], c_type, data_suffix, True),
                (params["indices"], indices_dtype.c_type, indices_suffix, True),
                (params["output"], c_type, output_suffix, False),
            ]
        )
        rendered = (
            state.templates["gather"]
            .render(
                model_name=model.name,
                op_name=op_name,
                data=params["data"],
                indices=params["indices"],
                output=params["output"],
                params=param_decls,
                c_type=c_type,
                indices_c_type=indices_dtype.c_type,
                data_suffix=data_suffix,
                indices_suffix=indices_suffix,
                output_suffix=output_suffix,
                output_shape=render_output_shape,
                loop_vars=render_loop_vars,
                indices_indices=indices_indices,
                data_indices=data_indices,
                axis_dim=data_shape[axis],
            )
            .rstrip()
        )
        return emitter.with_node_comment(model, ctx.op_index, rendered)

    __io_inputs__ = ("data", "indices")
    __io_outputs__ = ("output",)

    def _gather_data(self) -> str:
        raise NotImplementedError

    def _gather_indices(self) -> str:
        raise NotImplementedError

    def _gather_output(self) -> str:
        raise NotImplementedError

    def _gather_axis(self) -> int:
        raise NotImplementedError

    def _gather_mode(self) -> str:
        raise NotImplementedError

    def validate(self, ctx: OpContext) -> None:
        indices_dtype = ctx.dtype(self._gather_indices())
        if indices_dtype not in {ScalarType.I64, ScalarType.I32}:
            raise UnsupportedOpError(
                f"{self.kind} indices must be int32 or int64, "
                f"got {indices_dtype.onnx_name}"
            )
        data_shape = ctx.shape(self._gather_data())
        if self._gather_mode() in {"gather", "gather_elements"}:
            if not data_shape:
                raise ShapeInferenceError(f"{self.kind} does not support scalar inputs")
            axis = self._gather_axis()
            if axis < 0:
                axis += len(data_shape)
            if axis < 0 or axis >= len(data_shape):
                raise ShapeInferenceError(
                    f"{self.kind} axis {axis} is out of range for rank "
                    f"{len(data_shape)}"
                )
        return None

    def infer_types(self, ctx: OpContext) -> None:
        data_dtype = ctx.dtype(self._gather_data())
        try:
            output_dtype = ctx.dtype(self._gather_output())
        except ShapeInferenceError:
            ctx.set_dtype(self._gather_output(), data_dtype)
            output_dtype = data_dtype
        if output_dtype != data_dtype:
            raise UnsupportedOpError(
                f"{self.kind} expects output dtype {data_dtype.onnx_name}, "
                f"got {output_dtype.onnx_name}"
            )

    def infer_shapes(self, ctx: OpContext) -> None:
        data_shape = ctx.shape(self._gather_data())
        indices_shape = ctx.shape(self._gather_indices())
        axis = self._gather_axis()
        if axis < 0:
            axis += len(data_shape)
        if axis < 0 or axis >= len(data_shape):
            raise ShapeInferenceError(
                f"{self.kind} axis {axis} is out of range for rank {len(data_shape)}"
            )
        if self._gather_mode() == "gather":
            output_shape = data_shape[:axis] + indices_shape + data_shape[axis + 1 :]
        else:
            raise UnsupportedOpError(
                f"{self.kind} does not support gather mode {self._gather_mode()}"
            )
        try:
            expected = ctx.shape(self._gather_output())
        except ShapeInferenceError:
            expected = None
        if expected is not None and expected != output_shape:
            raise ShapeInferenceError(
                f"{self.kind} output shape must be {output_shape}, got {expected}"
            )
        ctx.set_shape(self._gather_output(), output_shape)
        ctx.set_derived(self, "axis", axis)


class ShapeLikeOpBase(RenderableOpBase):
    def emit(self, emitter: Emitter, ctx: EmitContext) -> str:
        if self._shape_mode() != "expand":
            return emitter.emit_generic_op(self, ctx)
        state = emitter.require_emit_state()
        model = state.model
        op_name = emitter.op_function_name(model, ctx.op_index)
        c_type = emitter.ctx_dtype(self._shape_output()).c_type
        params = emitter.shared_param_map(
            [("input0", self._shape_data()), ("output", self._shape_output())]
        )
        output_shape_raw = emitter.ctx_shape(self._shape_output())
        output_shape = CEmitterCompat.codegen_shape(output_shape_raw)
        loop_vars = CEmitterCompat.loop_vars(output_shape_raw)
        input_shape = emitter.ctx_shape(self._shape_data())
        input_suffix = emitter.param_array_suffix(input_shape)
        output_suffix = emitter.param_array_suffix(output_shape_raw)
        param_decls = emitter.build_param_decls(
            [
                (params["input0"], c_type, input_suffix, True),
                (params["output"], c_type, output_suffix, False),
            ]
        )
        input_shape_padded = emitter.derived(self, "input_shape_padded")
        input_strides = emitter.derived(self, "input_strides")
        input_index_terms = [
            f"{loop_var} * {stride}"
            for loop_var, input_dim, stride in zip(
                loop_vars, input_shape_padded, input_strides
            )
            if input_dim != 1
        ]
        input_index_expr = " + ".join(input_index_terms) if input_index_terms else "0"
        rendered = (
            state.templates["expand"]
            .render(
                model_name=model.name,
                op_name=op_name,
                input0=params["input0"],
                output=params["output"],
                params=param_decls,
                c_type=c_type,
                input_suffix=input_suffix,
                output_suffix=output_suffix,
                output_shape=output_shape,
                loop_vars=loop_vars,
                input_index_expr=input_index_expr,
            )
            .rstrip()
        )
        return emitter.with_node_comment(model, ctx.op_index, rendered)

    __io_inputs__ = ("input0", "input_shape")
    __io_outputs__ = ("output",)

    def call_args(self) -> tuple[str, ...]:
        return (self._shape_data(), self._shape_output())

    def _shape_data(self) -> str:
        raise NotImplementedError

    def _shape_output(self) -> str:
        raise NotImplementedError

    def _shape_spec(self, ctx: OpContext) -> tuple[int, ...]:
        raise NotImplementedError

    def _shape_mode(self) -> str:
        raise NotImplementedError

    def _shape_derived(
        self,
        ctx: OpContext,
        *,
        data_shape: tuple[int, ...],
        target_shape: tuple[int, ...],
        output_shape: tuple[int, ...],
    ) -> None:
        return None

    @staticmethod
    def _validate_static_dims(shape: tuple[int, ...], kind: str) -> None:
        if any(dim < 0 for dim in shape):
            raise ShapeInferenceError(f"{kind} does not support dynamic dims")

    @staticmethod
    def _broadcast_shape(
        input_shape: tuple[int, ...],
        target_shape: tuple[int, ...],
        *,
        kind: str,
    ) -> tuple[int, ...]:
        ShapeLikeOpBase._validate_static_dims(input_shape, kind)
        ShapeLikeOpBase._validate_static_dims(target_shape, kind)
        output_rank = max(len(input_shape), len(target_shape))
        input_padded = (1,) * (output_rank - len(input_shape)) + input_shape
        target_padded = (1,) * (output_rank - len(target_shape)) + target_shape
        result: list[int] = []
        for input_dim, target_dim in zip(input_padded, target_padded):
            if input_dim == 1:
                result.append(target_dim)
            elif target_dim == 1:
                result.append(input_dim)
            elif input_dim == target_dim:
                result.append(input_dim)
            else:
                raise ShapeInferenceError(
                    f"{kind} input shape {input_shape} is not "
                    f"broadcastable to {target_shape}"
                )
        return tuple(result)

    def validate(self, ctx: OpContext) -> None:
        data_shape = ctx.shape(self._shape_data())
        target_shape = self._shape_spec(ctx)
        if self._shape_mode() == "expand":
            self._broadcast_shape(data_shape, target_shape, kind=self.kind)
        return None

    def infer_types(self, ctx: OpContext) -> None:
        input_dtype = ctx.dtype(self._shape_data())
        try:
            output_dtype = ctx.dtype(self._shape_output())
        except ShapeInferenceError:
            ctx.set_dtype(self._shape_output(), input_dtype)
            output_dtype = input_dtype
        if output_dtype != input_dtype:
            raise UnsupportedOpError(
                f"{self.kind} expects output dtype {input_dtype.onnx_name}, "
                f"got {output_dtype.onnx_name}"
            )

    def infer_shapes(self, ctx: OpContext) -> None:
        data_shape = ctx.shape(self._shape_data())
        target_shape = self._shape_spec(ctx)
        if self._shape_mode() == "expand":
            output_shape = self._broadcast_shape(
                data_shape, target_shape, kind=self.kind
            )
        else:
            output_shape = target_shape
        try:
            expected = ctx.shape(self._shape_output())
        except ShapeInferenceError:
            expected = None
        if expected is not None and expected != output_shape:
            raise ShapeInferenceError(
                f"{self.kind} output shape must be {output_shape}, got {expected}"
            )
        ctx.set_shape(self._shape_output(), output_shape)
        self._shape_derived(
            ctx,
            data_shape=data_shape,
            target_shape=target_shape,
            output_shape=output_shape,
        )


class VariadicLikeOpBase(RenderableOpBase):
    def emit(self, emitter: Emitter, ctx: EmitContext) -> str:
        return emitter.emit_generic_op(self, ctx)

    __io_inputs__ = ("inputs",)
    __io_outputs__ = ("output",)

    def _variadic_inputs(self) -> tuple[str, ...]:
        raise NotImplementedError

    def _variadic_output(self) -> str:
        raise NotImplementedError

    def _variadic_kind(self) -> str:
        return self.kind

    def _variadic_min_inputs(self) -> int:
        return 2

    def _variadic_max_inputs(self) -> int | None:
        return None

    def _variadic_compare(self) -> bool:
        return False

    def _variadic_supports_dtype(self, dtype: ScalarType) -> bool:
        return True

    def validate(self, ctx: OpContext) -> None:
        inputs = self._variadic_inputs()
        if any(not name for name in inputs):
            raise UnsupportedOpError(f"{self._variadic_kind()} input must be provided")
        min_inputs = self._variadic_min_inputs()
        max_inputs = self._variadic_max_inputs()
        if len(inputs) < min_inputs:
            raise UnsupportedOpError(
                f"{self._variadic_kind()} must have at least {min_inputs} inputs"
            )
        if max_inputs is not None and len(inputs) != max_inputs:
            raise UnsupportedOpError(
                f"{self._variadic_kind()} must have exactly {max_inputs} inputs"
            )
        input_dtypes = tuple(ctx.dtype(name) for name in inputs)
        if any(dtype != input_dtypes[0] for dtype in input_dtypes[1:]):
            dtype_names = ", ".join(dtype.onnx_name for dtype in input_dtypes)
            raise UnsupportedOpError(
                f"{self._variadic_kind()} expects matching input dtypes, "
                f"got {dtype_names}"
            )
        try:
            output_dtype = ctx.dtype(self._variadic_output())
        except ShapeInferenceError:
            output_dtype = None
        if output_dtype is not None:
            if self._variadic_compare():
                if output_dtype != ScalarType.BOOL:
                    raise UnsupportedOpError(
                        f"{self._variadic_kind()} expects bool output, "
                        f"got {output_dtype.onnx_name}"
                    )
            elif output_dtype != input_dtypes[0]:
                raise UnsupportedOpError(
                    f"{self._variadic_kind()} expects output dtype "
                    f"{input_dtypes[0].onnx_name}, got {output_dtype.onnx_name}"
                )
        if not self._variadic_supports_dtype(input_dtypes[0]):
            raise UnsupportedOpError(
                f"{self._variadic_kind()} does not support dtype "
                f"{input_dtypes[0].onnx_name}"
            )
        return None

    def infer_types(self, ctx: OpContext) -> None:
        for name in self._variadic_inputs():
            ctx.dtype(name)
        try:
            ctx.dtype(self._variadic_output())
        except ShapeInferenceError:
            ctx.set_dtype(
                self._variadic_output(),
                ctx.dtype(self._variadic_inputs()[0]),
            )

    def infer_shapes(self, ctx: OpContext) -> None:
        input_shapes = tuple(ctx.shape(name) for name in self._variadic_inputs())
        try:
            output_shape = BroadcastingOpBase.broadcast_shapes(*input_shapes)
        except ShapeInferenceError as exc:
            raise UnsupportedOpError(
                f"{self._variadic_kind()} expects broadcastable input shapes"
            ) from exc
        try:
            expected = ctx.shape(self._variadic_output())
        except ShapeInferenceError:
            expected = None
        if expected is not None and expected != output_shape:
            raise UnsupportedOpError(
                f"{self._variadic_kind()} output shape must be {output_shape}, "
                f"got {expected}"
            )
        ctx.set_shape(self._variadic_output(), output_shape)


class ReduceOpBase(RenderableOpBase):
    def emit(self, emitter: Emitter, ctx: EmitContext) -> str:
        return emitter.emit_generic_op(self, ctx)

    __io_inputs__ = ("input0",)
    __io_outputs__ = ("output",)

    @staticmethod
    def normalize_axes(axes: tuple[int, ...] | None, rank: int) -> tuple[int, ...]:
        if axes is None:
            axes = tuple(range(rank))
        normalized: list[int] = []
        for axis in axes:
            if axis < 0:
                axis += rank
            if axis < 0 or axis >= rank:
                raise ShapeInferenceError(
                    f"Reduce axis {axis} is out of bounds for rank {rank}"
                )
            normalized.append(axis)
        return tuple(dict.fromkeys(normalized))

    @staticmethod
    def reduced_shape(
        input_shape: tuple[int, ...],
        axes: tuple[int, ...] | None,
        *,
        keepdims: bool,
    ) -> tuple[int, ...]:
        rank = len(input_shape)
        normalized_axes = ReduceOpBase.normalize_axes(axes, rank)
        if keepdims:
            return tuple(
                1 if axis in normalized_axes else dim
                for axis, dim in enumerate(input_shape)
            )
        return tuple(
            dim for axis, dim in enumerate(input_shape) if axis not in normalized_axes
        )


class BroadcastingOpBase(RenderableOpBase):
    @staticmethod
    def unidirectional_broadcastable(
        source: tuple[int, ...],
        target: tuple[int, ...],
    ) -> bool:
        if len(source) > len(target):
            return False
        padded = (1,) * (len(target) - len(source)) + source
        for source_dim, target_dim in zip(padded, target):
            if source_dim not in {1, target_dim}:
                return False
        return True

    @staticmethod
    def prelu_channel_axis(
        input_shape: tuple[int, ...],
        slope_shape: tuple[int, ...],
    ) -> int | None:
        if len(input_shape) < 2 or len(slope_shape) != 1:
            return None
        if slope_shape[0] != input_shape[1]:
            return None
        return 1

    @staticmethod
    def broadcast_shapes(
        *shapes: tuple[int, ...],
    ) -> tuple[int, ...]:
        if not shapes:
            return ()
        max_rank = max(len(shape) for shape in shapes)
        padded_shapes = [(1,) * (max_rank - len(shape)) + shape for shape in shapes]
        result: list[int] = []
        for dims in zip(*padded_shapes):
            known_dims = {d for d in dims if d > 1}
            unknown_dims = [d for d in dims if d < 0]
            if len(known_dims) > 1:
                raise ShapeInferenceError(
                    "Broadcasting mismatch for shapes: "
                    + ", ".join(str(shape) for shape in shapes)
                )
            if known_dims:
                dim = next(iter(known_dims))
                if any(d not in {1, dim} for d in dims if d >= 0):
                    raise ShapeInferenceError(
                        "Broadcasting mismatch for shapes: "
                        + ", ".join(str(shape) for shape in shapes)
                    )
                if unknown_dims:
                    raise ShapeInferenceError(
                        "Broadcasting mismatch for shapes: "
                        + ", ".join(str(shape) for shape in shapes)
                    )
            elif unknown_dims:
                dim = unknown_dims[0]
                if any(d not in {1, dim} for d in dims):
                    raise ShapeInferenceError(
                        "Broadcasting mismatch for shapes: "
                        + ", ".join(str(shape) for shape in shapes)
                    )
            else:
                dim = 1
            result.append(dim)
        return tuple(result)


class MatMulLikeOpBase(RenderableOpBase):
    __io_inputs__ = ("input0", "input1")
    __io_outputs__ = ("output",)


class GemmLikeOpBase(RenderableOpBase):
    __io_inputs__ = ("input_a", "input_b", "input_c")
    __io_outputs__ = ("output",)


class ConvLikeOpBase(RenderableOpBase):
    __io_inputs__ = ("input0", "weights", "bias")
    __io_outputs__ = ("output",)

    def computed_output_shape(self, emitter: "Emitter") -> tuple[int, ...]:
        return (self.batch, self.out_channels, *self.out_spatial)


class CEmitterCompat:
    @staticmethod
    def codegen_shape(shape: tuple[int, ...]) -> tuple[int | str, ...]:
        if not shape:
            return (1,)
        return tuple(
            dim if dim >= 0 else f"dim_{index}" for index, dim in enumerate(shape)
        )

    @staticmethod
    def loop_vars(shape: tuple[int | str, ...]) -> tuple[str, ...]:
        if not shape:
            shape = (1,)
        return tuple(f"i{idx}" for idx in range(len(shape)))

    @staticmethod
    def element_count(shape: tuple[int, ...]) -> int:
        if not shape:
            return 1
        count = 1
        for dim in shape:
            if dim < 0:
                raise ValueError("Dynamic dims are not supported for element_count")
            if dim == 0:
                return 0
            count *= dim
        return count

    @staticmethod
    def shape_dim_exprs(
        shape: tuple[int, ...],
        dim_names: Mapping[int, str] | None,
    ) -> tuple[str | int, ...]:
        dim_names = dim_names or {}
        if not shape:
            shape = (1,)
        return tuple(dim_names.get(index, dim) for index, dim in enumerate(shape))

    @staticmethod
    def element_count_expr(shape_exprs: Sequence[str | int]) -> str:
        if not shape_exprs:
            return "1"
        return " * ".join(str(dim) for dim in shape_exprs)

    @staticmethod
    def broadcast_index_expr(
        name: str,
        input_shape: tuple[int, ...],
        output_shape: tuple[int, ...],
        loop_vars: tuple[str, ...],
    ) -> str:
        if not input_shape:
            return f"{name}[0]"
        output_shape = CEmitterCompat.codegen_shape(output_shape)
        if len(output_shape) != len(loop_vars):
            raise ValueError("Loop variables must match output shape rank")
        offset = len(output_shape) - len(input_shape)
        indices: list[str] = []
        for input_dim, dim_size in enumerate(input_shape):
            output_dim = input_dim + offset
            if dim_size == 1:
                indices.append("[0]")
            else:
                indices.append(f"[{loop_vars[output_dim]}]")
        return f"{name}{''.join(indices)}"

    @staticmethod
    def matmul_index_exprs(
        batch_vars: tuple[str, ...],
        row_var: str | None,
        col_var: str | None,
        batch_rank: int,
        *,
        input0: str,
        input1: str,
        left_vector: bool,
        right_vector: bool,
        input0_shape: tuple[int, ...],
        input1_shape: tuple[int, ...],
        input0_batch_shape: tuple[int, ...],
        input1_batch_shape: tuple[int, ...],
    ) -> tuple[str, str]:
        def batch_indices(batch_shape: tuple[int, ...], actual_rank: int) -> list[str]:
            if actual_rank == 0:
                return []
            offset = batch_rank - actual_rank
            indices: list[str] = []
            for idx in range(actual_rank):
                dim = batch_shape[offset + idx]
                var = batch_vars[offset + idx]
                indices.append("0" if dim == 1 else var)
            return indices

        if left_vector:
            input0_indices = ["k"]
        else:
            input0_batch_rank = len(input0_shape) - 2
            input0_indices = batch_indices(input0_batch_shape, input0_batch_rank)
            input0_indices.append(row_var if row_var is not None else "0")
            input0_indices.append("k")
        if right_vector:
            input1_indices = ["k"]
        else:
            input1_batch_rank = len(input1_shape) - 2
            input1_indices = batch_indices(input1_batch_shape, input1_batch_rank)
            input1_indices.append("k")
            input1_indices.append(col_var if col_var is not None else "0")
        input0_index_expr = f"{input0}" + "".join(
            f"[{index}]" for index in input0_indices
        )
        input1_index_expr = f"{input1}" + "".join(
            f"[{index}]" for index in input1_indices
        )
        return input0_index_expr, input1_index_expr


def _io_field_names(op_type: type[OpBase]) -> tuple[tuple[str, ...], tuple[str, ...]]:
    input_fields: tuple[str, ...] | None = None
    output_fields: tuple[str, ...] | None = None
    for cls in op_type.__mro__:
        cls_inputs = cls.__dict__.get("__io_inputs__")
        cls_outputs = cls.__dict__.get("__io_outputs__")
        if input_fields is None and cls_inputs is not None:
            input_fields = cls_inputs
        if output_fields is None and cls_outputs is not None:
            output_fields = cls_outputs
        if input_fields is not None and output_fields is not None:
            return input_fields, output_fields
    raise UnsupportedOpError(f"Missing canonical I/O schema for op {op_type.__name__}")


def _resolve_io_names(op: OpBase, field_names: tuple[str, ...]) -> tuple[str, ...]:
    names: list[str] = []
    for field_name in field_names:
        value = getattr(op, field_name)
        if value is None:
            continue
        if isinstance(value, str):
            names.append(value)
            continue
        if isinstance(value, tuple):
            for entry in value:
                if entry is None:
                    continue
                if not isinstance(entry, str):
                    raise UnsupportedOpError(
                        f"{op.kind} {field_name} must be a tuple of tensor names"
                    )
                names.append(entry)
            continue
        raise UnsupportedOpError(
            f"{op.kind} {field_name} must be a tensor name or tuple of names"
        )
    return tuple(names)
