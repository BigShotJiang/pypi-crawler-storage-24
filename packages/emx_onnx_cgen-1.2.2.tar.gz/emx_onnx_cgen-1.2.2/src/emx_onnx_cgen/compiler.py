from __future__ import annotations

from dataclasses import dataclass
import hashlib
from itertools import chain
import os
from pathlib import Path
import time
from typing import Callable, Mapping, Sequence, TypeVar

import numpy as np
import onnx

from shared.scalar_types import ScalarType

from .codegen.c_emitter import (
    CEmitter,
    ConstTensor,
    LoweredModel,
    ModelHeader,
    NodeInfo,
)
from .errors import ShapeInferenceError, UnsupportedOpError
from .invariants import (
    check_graph_integrity,
    check_inferred_shapes,
    check_inferred_types,
    check_lowered_ops,
)
from .ir.context import GraphContext
from .ir.model import (
    Graph,
    Initializer,
    Node,
    SequenceType,
    TensorType,
    Value,
    ValueType,
)
from .ir.op_base import OpBase
from .ir.op_context import OpContext
from .lowering import load_lowering_registry
from .lowering.common import ensure_supported_dtype, shape_product
from .lowering.registry import get_lowering_registry
from .onnx_import import import_onnx, prepare_onnx_model

# Keep this env var near the lowering loop so future shape-debug work can find it fast.
_DEBUG_LOWERING_FAILURES_ENV = "EMX_DEBUG_LOWERING_FAILURES"


def _value_requires_explicit_shape_concretization(
    value: Value,
    *,
    allow_top_level_tensor_dims: bool,
    check_sequence_dims: bool,
    allowed_tensor_dim_params: set[str] | None = None,
) -> str | None:
    value_type = value.type
    if isinstance(value_type, SequenceType):
        if check_sequence_dims and any(
            dim_param is not None for dim_param in value_type.elem.dim_params
        ):
            return (
                f"sequence '{value.name}' has dynamic element dimensions "
                f"{value_type.elem.dim_params}"
            )
        return None
    if allow_top_level_tensor_dims:
        return None
    unresolved_dim_params = tuple(
        dim_param
        for dim_param in value_type.dim_params
        if dim_param is not None
        and (
            allowed_tensor_dim_params is None
            or dim_param not in allowed_tensor_dim_params
        )
    )
    if unresolved_dim_params:
        return f"tensor '{value.name}' has dynamic dimensions {value_type.dim_params}"
    return None


@dataclass(frozen=True)
class CompilerOptions:
    template_dir: Path | None = None
    model_name: str = "model"
    emit_testbench: bool = False
    command_line: str | None = None
    model_checksum: str | None = None
    restrict_arrays: bool = True
    fp32_accumulation_strategy: str = "simple"
    fp16_accumulation_strategy: str = "fp32"
    testbench_inputs: (
        Mapping[str, tuple[float | int | bool, ...] | np.ndarray] | None
    ) = None
    testbench_outputs: Mapping[str, np.ndarray | list[np.ndarray]] | None = None
    testbench_optional_inputs: Mapping[str, bool] | None = None
    testbench_output_format: str = "json"
    truncate_weights_after: int | None = None
    large_temp_threshold_bytes: int = 1024
    large_weight_threshold: int = 100 * 1024
    replicate_ort_bugs: bool = False
    # Developer-only switch: attach the failing lowering node with typed I/O context.
    debug_lowering_failures: bool = False
    timings: dict[str, float] | None = None


_T = TypeVar("_T")


def _onnx_elem_type(dtype: np.dtype) -> int:
    for elem_type, info in onnx._mapping.TENSOR_TYPE_MAP.items():
        if info.np_dtype == dtype:
            return elem_type
    raise UnsupportedOpError(f"Unsupported dtype {dtype} for ONNX output")


def _optional_flag_name(name: str) -> str:
    return f"{name}_present"


class Compiler:
    def __init__(self, options: CompilerOptions | None = None) -> None:
        if options is None:
            options = CompilerOptions()
        self._options = options
        env_debug_lowering = os.environ.get(_DEBUG_LOWERING_FAILURES_ENV)
        self._debug_lowering_failures = options.debug_lowering_failures or (
            env_debug_lowering is not None
            and env_debug_lowering.strip().lower()
            not in {"", "0", "false", "no", "off"}
        )
        self._emitter = CEmitter(
            options.template_dir,
            restrict_arrays=options.restrict_arrays,
            fp32_accumulation_strategy=options.fp32_accumulation_strategy,
            fp16_accumulation_strategy=options.fp16_accumulation_strategy,
            truncate_weights_after=options.truncate_weights_after,
            large_temp_threshold_bytes=options.large_temp_threshold_bytes,
            large_weight_threshold=options.large_weight_threshold,
            replicate_ort_bugs=options.replicate_ort_bugs,
        )
        load_lowering_registry()

    @dataclass(frozen=True)
    class _CompileContext:
        lowered: LoweredModel
        variable_dim_inputs: dict[int, dict[int, str]]
        variable_dim_outputs: dict[int, dict[int, str]]

    def _try_lower_without_shape_concretization(
        self,
        model: onnx.ModelProto,
        graph: Graph,
    ) -> LoweredModel | None:
        try:
            return self._lower_model(model, graph)
        except (ShapeInferenceError, UnsupportedOpError):
            return None

    def _time_step(self, label: str, func: Callable[[], _T]) -> _T:
        timings = self._options.timings
        if timings is None:
            return func()
        started = time.perf_counter()
        result = func()
        timings[label] = time.perf_counter() - started
        return result

    def _build_compile_context(self, model: onnx.ModelProto) -> _CompileContext:
        prepared_model = self._time_step(
            "prepare_onnx_model", lambda: prepare_onnx_model(model)
        )
        graph = self._time_step(
            "import_onnx",
            lambda: import_onnx(prepared_model, _prepared=True),
        )
        missing_shape_reason = self._shape_concretization_requirement_reason(graph)
        if missing_shape_reason is not None:
            lowered = self._time_step(
                "lower_model_without_dynamic_shape_support",
                lambda: self._try_lower_without_shape_concretization(
                    prepared_model, graph
                ),
            )
            if lowered is not None:
                variable_dim_inputs, variable_dim_outputs = self._time_step(
                    "collect_variable_dims", lambda: self._collect_variable_dims(graph)
                )
                return Compiler._CompileContext(
                    lowered=lowered,
                    variable_dim_inputs=variable_dim_inputs,
                    variable_dim_outputs=variable_dim_outputs,
                )
            raise UnsupportedOpError(
                "Code generation requires static shapes. "
                f"Reason: {missing_shape_reason}. "
                "Hint: export the model with static shapes."
            )
        variable_dim_inputs, variable_dim_outputs = self._time_step(
            "collect_variable_dims", lambda: self._collect_variable_dims(graph)
        )
        lowered = self._time_step(
            "lower_model", lambda: self._lower_model(prepared_model, graph)
        )
        return Compiler._CompileContext(
            lowered=lowered,
            variable_dim_inputs=variable_dim_inputs,
            variable_dim_outputs=variable_dim_outputs,
        )

    def compile(self, model: onnx.ModelProto) -> str:
        ctx = self._build_compile_context(model)
        return self._time_step(
            "emit_model",
            lambda: self._emitter.emit_model(
                ctx.lowered,
                emit_testbench=self._options.emit_testbench,
                testbench_optional_inputs=self._options.testbench_optional_inputs,
                testbench_output_format=self._options.testbench_output_format,
                testbench_inputs=self._options.testbench_inputs,
                testbench_outputs=self._options.testbench_outputs,
                variable_dim_inputs=ctx.variable_dim_inputs,
                variable_dim_outputs=ctx.variable_dim_outputs,
            ),
        )

    def compile_testbench(self, model: onnx.ModelProto) -> str:
        ctx = self._build_compile_context(model)
        return self._time_step(
            "emit_testbench",
            lambda: self._emitter.emit_testbench(
                ctx.lowered,
                testbench_inputs=self._options.testbench_inputs,
                testbench_outputs=self._options.testbench_outputs,
                testbench_optional_inputs=self._options.testbench_optional_inputs,
                testbench_output_format=self._options.testbench_output_format,
                variable_dim_inputs=ctx.variable_dim_inputs,
                variable_dim_outputs=ctx.variable_dim_outputs,
            ),
        )

    def compile_testbench_declarations(self, model: onnx.ModelProto) -> str:
        ctx = self._build_compile_context(model)
        return self._time_step(
            "emit_testbench_decls",
            lambda: self._emitter.emit_testbench_declarations(
                ctx.lowered,
                variable_dim_inputs=ctx.variable_dim_inputs,
                variable_dim_outputs=ctx.variable_dim_outputs,
            ),
        )

    def compile_with_data_file(self, model: onnx.ModelProto) -> tuple[str, str]:
        ctx = self._build_compile_context(model)
        return self._time_step(
            "emit_model_with_data_file",
            lambda: self._emitter.emit_model_with_data_file(
                ctx.lowered,
                emit_testbench=self._options.emit_testbench,
                testbench_optional_inputs=self._options.testbench_optional_inputs,
                testbench_output_format=self._options.testbench_output_format,
                testbench_inputs=self._options.testbench_inputs,
                testbench_outputs=self._options.testbench_outputs,
                variable_dim_inputs=ctx.variable_dim_inputs,
                variable_dim_outputs=ctx.variable_dim_outputs,
            ),
        )

    def compile_with_weight_data(
        self, model: onnx.ModelProto
    ) -> tuple[str, bytes | None]:
        ctx = self._build_compile_context(model)
        generated = self._time_step(
            "emit_model",
            lambda: self._emitter.emit_model(
                ctx.lowered,
                emit_testbench=self._options.emit_testbench,
                testbench_optional_inputs=self._options.testbench_optional_inputs,
                testbench_output_format=self._options.testbench_output_format,
                testbench_inputs=self._options.testbench_inputs,
                testbench_outputs=self._options.testbench_outputs,
                variable_dim_inputs=ctx.variable_dim_inputs,
                variable_dim_outputs=ctx.variable_dim_outputs,
            ),
        )
        weight_data = self._time_step(
            "collect_weight_data",
            lambda: self._emitter.collect_weight_data(ctx.lowered.constants),
        )
        return generated, weight_data

    def compile_with_data_file_and_weight_data(
        self, model: onnx.ModelProto
    ) -> tuple[str, str, bytes | None]:
        ctx = self._build_compile_context(model)
        generated, data_source = self._time_step(
            "emit_model_with_data_file",
            lambda: self._emitter.emit_model_with_data_file(
                ctx.lowered,
                emit_testbench=self._options.emit_testbench,
                testbench_optional_inputs=self._options.testbench_optional_inputs,
                testbench_output_format=self._options.testbench_output_format,
                testbench_inputs=self._options.testbench_inputs,
                testbench_outputs=self._options.testbench_outputs,
                variable_dim_inputs=ctx.variable_dim_inputs,
                variable_dim_outputs=ctx.variable_dim_outputs,
            ),
        )
        weight_data = self._time_step(
            "collect_weight_data",
            lambda: self._emitter.collect_weight_data(ctx.lowered.constants),
        )
        return generated, data_source, weight_data

    @staticmethod
    def _shape_concretization_requirement_reason(graph: Graph) -> str | None:
        allowed_internal_dim_params = Compiler._allowed_internal_dim_params(graph)
        concretization_checks: list[tuple[tuple[Value, ...], bool, set[str] | None]] = [
            (graph.inputs, True, None),
            (graph.values, False, allowed_internal_dim_params),
            (graph.outputs, True, None),
        ]
        for values, allow_top_level, allowed_params in concretization_checks:
            for value in values:
                reason = _value_requires_explicit_shape_concretization(
                    value,
                    allow_top_level_tensor_dims=allow_top_level,
                    check_sequence_dims=True,
                    allowed_tensor_dim_params=allowed_params,
                )
                if reason is not None:
                    return reason
        return None

    @staticmethod
    def _allowed_internal_dim_params(graph: Graph) -> set[str]:
        dim_params: set[str] = set()
        for value in chain(graph.inputs, graph.outputs):
            if isinstance(value.type, TensorType):
                dim_params.update(
                    dim_param for dim_param in value.type.dim_params if dim_param
                )
            elif isinstance(value.type, SequenceType):
                dim_params.update(
                    dim_param for dim_param in value.type.elem.dim_params if dim_param
                )
        return dim_params

    @staticmethod
    def _collect_variable_dims(
        graph: Graph,
    ) -> tuple[dict[int, dict[int, str]], dict[int, dict[int, str]]]:
        def tensor_type(value: Value) -> TensorType | None:
            if isinstance(value.type, TensorType):
                return value.type
            if isinstance(value.type, SequenceType):
                return value.type.elem
            return None

        def collect(values: tuple[Value, ...]) -> dict[int, dict[int, str]]:
            dim_map: dict[int, dict[int, str]] = {}
            for index, value in enumerate(values):
                value_tensor_type = tensor_type(value)
                if value_tensor_type is None:
                    continue
                dims = {
                    dim_index: dim_param
                    for dim_index, dim_param in enumerate(value_tensor_type.dim_params)
                    if dim_param
                }
                if dims:
                    dim_map[index] = dims
            return dim_map

        return collect(graph.inputs), collect(graph.outputs)

    def _lower_model(self, model: onnx.ModelProto, graph: Graph) -> LoweredModel:
        graph = self._materialize_initializer_outputs(graph)
        ctx = GraphContext(graph)
        constants = _lowered_constants(ctx)
        self._validate_graph(graph)
        (
            input_names,
            input_optional_names,
            input_shapes,
            input_dtypes,
            input_types,
            output_names,
            output_optional_names,
            output_shapes,
            output_dtypes,
            output_types,
        ) = self._collect_io_specs(graph)
        ops, node_infos = self._lower_nodes(ctx)
        check_lowered_ops(ops)
        op_ctx = OpContext(ctx)
        for op in ops:
            op.validate(op_ctx)
        for op in ops:
            op.infer_types(op_ctx)
        check_inferred_types(ops, op_ctx)
        for op in ops:
            op.infer_shapes(op_ctx)
        check_inferred_shapes(ops, op_ctx)
        ops, node_infos = self._prune_dead_ops(ops, node_infos, output_names)
        refreshed_output_types: list[ValueType] = []
        refreshed_output_shapes: list[tuple[int, ...]] = []
        refreshed_output_dtypes: list[ScalarType] = []
        for value, original_type, original_shape, original_dtype in zip(
            graph.outputs,
            output_types,
            output_shapes,
            output_dtypes,
        ):
            if isinstance(original_type, TensorType):
                inferred_shape = op_ctx.shape(value.name)
                inferred_dtype = op_ctx.dtype(value.name)
                refreshed_output_types.append(
                    TensorType(
                        dtype=inferred_dtype,
                        shape=inferred_shape,
                        dim_params=(None,) * len(inferred_shape),
                        is_optional=original_type.is_optional,
                    )
                )
                refreshed_output_shapes.append(inferred_shape)
                refreshed_output_dtypes.append(inferred_dtype)
                continue
            refreshed_output_types.append(original_type)
            refreshed_output_shapes.append(original_shape)
            refreshed_output_dtypes.append(original_dtype)
        output_types = tuple(refreshed_output_types)
        output_shapes = tuple(refreshed_output_shapes)
        output_dtypes = tuple(refreshed_output_dtypes)
        header = self._build_header(model, graph)
        return LoweredModel(
            name=self._options.model_name,
            input_names=input_names,
            input_optional_names=input_optional_names,
            input_shapes=input_shapes,
            input_dtypes=input_dtypes,
            input_types=input_types,
            output_names=output_names,
            output_optional_names=output_optional_names,
            output_shapes=output_shapes,
            output_dtypes=output_dtypes,
            output_types=output_types,
            constants=constants,
            ops=tuple(ops),
            node_infos=tuple(node_infos),
            header=header,
            op_context=op_ctx,
        )

    def _materialize_initializer_outputs(self, graph: Graph) -> Graph:
        if graph.nodes:
            return graph
        if not graph.outputs:
            return graph

        initializer_by_name = {
            initializer.name: initializer for initializer in graph.initializers
        }
        output_names = {value.name for value in graph.outputs}
        if not all(name in initializer_by_name for name in output_names):
            return graph

        reserved_names = {
            *(value.name for value in graph.inputs),
            *(value.name for value in graph.outputs),
            *(value.name for value in graph.values),
            *(initializer.name for initializer in graph.initializers),
        }
        renamed_initializers: list[Initializer] = []
        initializer_name_map: dict[str, str] = {}
        for initializer in graph.initializers:
            if initializer.name not in output_names:
                renamed_initializers.append(initializer)
                continue
            base_name = f"{initializer.name}__const"
            new_name = base_name
            suffix = 0
            while new_name in reserved_names:
                suffix += 1
                new_name = f"{base_name}_{suffix}"
            reserved_names.add(new_name)
            initializer_name_map[initializer.name] = new_name
            renamed_initializers.append(
                Initializer(
                    name=new_name,
                    type=initializer.type,
                    data=initializer.data,
                )
            )

        identity_nodes = tuple(
            Node(
                op_type="Identity",
                name=f"materialize_output_{index}",
                inputs=(initializer_name_map[output.name],),
                outputs=(output.name,),
                attrs={},
            )
            for index, output in enumerate(graph.outputs)
        )

        return Graph(
            inputs=graph.inputs,
            outputs=graph.outputs,
            nodes=identity_nodes,
            initializers=tuple(renamed_initializers),
            values=graph.values,
            opset_imports=graph.opset_imports,
        )

    def _validate_graph(self, graph: Graph) -> None:
        check_graph_integrity(graph)
        for value in graph.outputs:
            if isinstance(value.type, TensorType):
                if any(value.type.dim_params):
                    continue
                shape_product(value.type.shape)

    def _collect_io_specs(
        self, graph: Graph
    ) -> tuple[
        tuple[str, ...],
        tuple[str | None, ...],
        tuple[tuple[int, ...], ...],
        tuple[ScalarType, ...],
        tuple[ValueType, ...],
        tuple[str, ...],
        tuple[str | None, ...],
        tuple[tuple[int, ...], ...],
        tuple[ScalarType, ...],
        tuple[ValueType, ...],
    ]:
        def tensor_type(value_name: str, value_type: ValueType) -> TensorType:
            if isinstance(value_type, TensorType):
                return value_type
            elem = value_type.elem
            if elem.shape and all(dim_param is None for dim_param in elem.dim_params):
                return elem

            def _split_chunk_size(split_name: str | None, axis_size: int) -> int:
                if split_name is None:
                    return 1
                initializer = next(
                    (item for item in graph.initializers if item.name == split_name),
                    None,
                )
                if initializer is None:
                    # Runtime-provided split can span up to the full axis extent.
                    return axis_size
                values = initializer.data.reshape(-1).tolist()
                if not values:
                    return axis_size
                if initializer.data.ndim == 0:
                    scalar_split = int(values[0])
                    if scalar_split <= 0:
                        return axis_size
                    return min(axis_size, scalar_split)
                chunk_sizes = [int(size) for size in values if int(size) > 0]
                if not chunk_sizes:
                    return axis_size
                return min(axis_size, max(chunk_sizes))

            if isinstance(value_type, SequenceType):
                for node in graph.nodes:
                    if node.op_type != "SplitToSequence":
                        continue
                    if value_name != node.outputs[0]:
                        continue
                    input_name = node.inputs[0]
                    try:
                        input_value = graph.find_value(input_name)
                    except KeyError:
                        continue
                    if not isinstance(input_value.type, TensorType):
                        continue
                    input_shape = input_value.type.shape
                    if not input_shape:
                        continue
                    axis = int(node.attrs.get("axis", 0))
                    if axis < 0:
                        axis += len(input_shape)
                    if axis < 0 or axis >= len(input_shape):
                        continue
                    keepdims = bool(int(node.attrs.get("keepdims", 1)))
                    split_name = None
                    if len(node.inputs) > 1 and node.inputs[1]:
                        split_name = node.inputs[1]
                        keepdims = True
                    if keepdims:
                        output_shape = list(input_shape)
                        output_shape[axis] = _split_chunk_size(
                            split_name, input_shape[axis]
                        )
                    else:
                        output_shape = list(input_shape)
                        del output_shape[axis]
                    return TensorType(
                        dtype=elem.dtype,
                        shape=tuple(output_shape),
                        dim_params=(None,) * len(output_shape),
                        is_optional=elem.is_optional,
                    )

            for node in graph.nodes:
                if node.op_type != "SequenceInsert":
                    continue
                if value_name in {node.inputs[0], node.outputs[0]}:
                    tensor_name = node.inputs[1]
                    try:
                        tensor_value = graph.find_value(tensor_name)
                    except KeyError:
                        continue
                    if isinstance(tensor_value.type, TensorType):
                        return TensorType(
                            dtype=elem.dtype,
                            shape=tensor_value.type.shape,
                            dim_params=tensor_value.type.dim_params,
                            is_optional=elem.is_optional,
                        )
            return elem

        input_names = tuple(value.name for value in graph.inputs)

        def _optional_name(value: Value) -> str | None:
            return (
                _optional_flag_name(value.name)
                if getattr(value.type, "is_optional", False)
                else None
            )

        def _collect_specs(values: tuple[Value, ...]):
            names = tuple(v.name for v in values)
            optional = tuple(_optional_name(v) for v in values)
            types = tuple(v.type for v in values)
            shapes = tuple(tensor_type(v.name, v.type).shape for v in values)
            dtypes = tuple(tensor_type(v.name, v.type).dtype for v in values)
            return names, optional, shapes, dtypes, types

        (
            input_names,
            input_optional_names,
            input_shapes,
            input_dtypes,
            input_types,
        ) = _collect_specs(graph.inputs)
        (
            output_names,
            output_optional_names,
            output_shapes,
            output_dtypes,
            output_types,
        ) = _collect_specs(graph.outputs)
        return (
            input_names,
            input_optional_names,
            input_shapes,
            input_dtypes,
            input_types,
            output_names,
            output_optional_names,
            output_shapes,
            output_dtypes,
            output_types,
        )

    @staticmethod
    def _format_debug_value_type(value_type: ValueType) -> str:
        if isinstance(value_type, TensorType):
            suffix = "?" if value_type.is_optional else ""
            if value_type.dim_params:
                return (
                    f"tensor{suffix}[dtype={value_type.dtype.onnx_name}, "
                    f"shape={value_type.shape}, dim_params={value_type.dim_params}]"
                )
            return f"tensor{suffix}[dtype={value_type.dtype.onnx_name}, shape={value_type.shape}]"
        elem = value_type.elem
        suffix = "?" if value_type.is_optional else ""
        return (
            f"sequence{suffix}[dtype={elem.dtype.onnx_name}, "
            f"elem_shape={elem.shape}, elem_dim_params={elem.dim_params}]"
        )

    def _format_debug_value(self, ctx: GraphContext, name: str) -> str:
        if not name:
            return "<omitted>"
        try:
            value = ctx.find_value(name)
        except KeyError:
            return f"{name}: <missing>"
        return f"{name}: {self._format_debug_value_type(value.type)}"

    def _format_lowering_debug_context(
        self,
        ctx: GraphContext,
        node: Node,
        *,
        node_index: int,
    ) -> str:
        lines = [
            f"node_index: {node_index}",
            f"op_type: {node.op_type}",
            f"name: {node.name or '<unnamed>'}",
            f"attrs: {dict(node.attrs)}",
            "inputs:",
        ]
        for name in node.inputs:
            lines.append(f"  - {self._format_debug_value(ctx, name)}")
        lines.append("outputs:")
        for name in node.outputs:
            lines.append(f"  - {self._format_debug_value(ctx, name)}")
        return "\n".join(lines)

    def _lower_nodes(self, ctx: GraphContext) -> tuple[list[OpBase], list[NodeInfo]]:
        ops: list[OpBase] = []
        node_infos: list[NodeInfo] = []
        registry = get_lowering_registry()
        for node_index, node in enumerate(ctx.nodes):
            lowering = registry.get(node.op_type)
            if lowering is None:
                raise UnsupportedOpError(f"Unsupported op {node.op_type}")
            try:
                ops.append(lowering(ctx, node))
            except (ShapeInferenceError, UnsupportedOpError) as exc:
                if not self._debug_lowering_failures:
                    raise
                debug_context = self._format_lowering_debug_context(
                    ctx,
                    node,
                    node_index=node_index,
                )
                raise type(exc)(
                    f"{exc}\n\nLowering debug context:\n{debug_context}"
                ) from exc
            node_infos.append(
                NodeInfo(
                    op_type=node.op_type,
                    name=node.name,
                    inputs=tuple(node.inputs),
                    outputs=tuple(node.outputs),
                    attrs=dict(node.attrs),
                )
            )
        return ops, node_infos

    @staticmethod
    def _prune_dead_ops(
        ops: Sequence[OpBase],
        node_infos: Sequence[NodeInfo],
        model_output_names: Sequence[str],
    ) -> tuple[list[OpBase], list[NodeInfo]]:
        needed = {name for name in model_output_names if name}
        kept_ops: list[OpBase] = []
        kept_node_infos: list[NodeInfo] = []
        for op, node_info in zip(reversed(ops), reversed(node_infos), strict=True):
            output_names = tuple(name for name in op.output_names if name)
            if not output_names or not any(name in needed for name in output_names):
                continue
            kept_ops.append(op)
            kept_node_infos.append(node_info)
            needed.update(name for name in op.input_names if name)
        kept_ops.reverse()
        kept_node_infos.reverse()
        return kept_ops, kept_node_infos

    def _build_header(self, model: onnx.ModelProto, graph: Graph) -> ModelHeader:
        metadata_props = tuple((prop.key, prop.value) for prop in model.metadata_props)
        opset_imports = tuple(
            (opset.domain, opset.version) for opset in model.opset_import
        )
        checksum = self._options.model_checksum
        if checksum is None:
            checksum = hashlib.sha256(model.SerializeToString()).hexdigest()
        codegen_settings = [
            ("emit_testbench", str(self._options.emit_testbench)),
            ("restrict_arrays", str(self._options.restrict_arrays)),
            (
                "fp32_accumulation_strategy",
                self._options.fp32_accumulation_strategy,
            ),
            (
                "fp16_accumulation_strategy",
                self._options.fp16_accumulation_strategy,
            ),
        ]
        if self._options.truncate_weights_after is not None:
            codegen_settings.append(
                ("truncate_weights_after", str(self._options.truncate_weights_after))
            )
        codegen_settings.extend(
            [
                (
                    "large_temp_threshold",
                    str(self._options.large_temp_threshold_bytes),
                ),
                (
                    "large_weight_threshold",
                    str(self._options.large_weight_threshold),
                ),
            ]
        )
        return ModelHeader(
            generator="Generated by emmtrix ONNX-to-C Code Generator (emx-onnx-cgen)",
            model_checksum=checksum,
            model_name=self._options.model_name,
            graph_name=model.graph.name or None,
            description=model.doc_string or None,
            graph_description=model.graph.doc_string or None,
            producer_name=model.producer_name or None,
            producer_version=model.producer_version or None,
            domain=model.domain or None,
            model_version=model.model_version or None,
            ir_version=model.ir_version or None,
            opset_imports=opset_imports,
            metadata_props=metadata_props,
            input_count=len(graph.inputs),
            output_count=len(graph.outputs),
            node_count=len(graph.nodes),
            initializer_count=len(graph.initializers),
            codegen_settings=tuple(codegen_settings),
        )


def _lowered_constants(graph: Graph | GraphContext) -> tuple[ConstTensor, ...]:
    used_initializers = {value.name for value in graph.outputs}
    for node in graph.nodes:
        used_initializers.update(node.inputs)
    constants: list[ConstTensor] = []
    for initializer in graph.initializers:
        if initializer.name not in used_initializers:
            continue
        dtype = ensure_supported_dtype(initializer.type.dtype)
        data_array = initializer.data.astype(dtype.np_dtype, copy=False)
        data_tuple = tuple(data_array.ravel().tolist())
        constants.append(
            ConstTensor(
                name=initializer.name,
                shape=initializer.type.shape,
                data=data_tuple,
                dtype=dtype,
            )
        )
    return tuple(constants)
