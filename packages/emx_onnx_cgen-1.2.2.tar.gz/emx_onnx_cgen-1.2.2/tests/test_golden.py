from __future__ import annotations

# NOTE: This file contains only golden codegen tests.

from pathlib import Path

import numpy as np
import onnx
import onnxruntime as ort
import pytest
from typing import Callable
from onnx import TensorProto, helper
from onnx.reference import ReferenceEvaluator

from emx_onnx_cgen import Compiler
from emx_onnx_cgen.compiler import CompilerOptions
from golden_utils import assert_golden


def _run_reference(
    model: onnx.ModelProto, inputs: dict[str, np.ndarray]
) -> dict[str, np.ndarray]:
    evaluator = ReferenceEvaluator(model)
    outputs = evaluator.run(None, inputs)
    return {output.name: value for output, value in zip(model.graph.output, outputs)}


def _make_binary_model(op_type: str, shape: list[int]) -> onnx.ModelProto:
    input_a = helper.make_tensor_value_info("a", TensorProto.FLOAT, shape)
    input_b = helper.make_tensor_value_info("b", TensorProto.FLOAT, shape)
    output = helper.make_tensor_value_info("out", TensorProto.FLOAT, shape)
    node = helper.make_node(op_type, inputs=["a", "b"], outputs=["out"])
    graph = helper.make_graph(
        [node], f"{op_type.lower()}_graph", [input_a, input_b], [output]
    )
    model = helper.make_model(
        graph,
        producer_name="emx-onnx-cgen",
        opset_imports=[helper.make_operatorsetid("", 13)],
    )
    model.ir_version = 7
    onnx.checker.check_model(model)
    return model


def _make_prelu_channel_model() -> onnx.ModelProto:
    input_a = helper.make_tensor_value_info("a", TensorProto.FLOAT, [2, 3, 4])
    input_b = helper.make_tensor_value_info("b", TensorProto.FLOAT, [3])
    output = helper.make_tensor_value_info("out", TensorProto.FLOAT, [2, 3, 4])
    node = helper.make_node("PRelu", inputs=["a", "b"], outputs=["out"])
    graph = helper.make_graph(
        [node], "prelu_channel_graph", [input_a, input_b], [output]
    )
    model = helper.make_model(
        graph,
        producer_name="emx-onnx-cgen",
        opset_imports=[helper.make_operatorsetid("", 6)],
    )
    model.ir_version = 7
    onnx.checker.check_model(model)
    return model


def _make_mod_model() -> onnx.ModelProto:
    input_a = helper.make_tensor_value_info("a", TensorProto.FLOAT, [2, 3])
    input_b = helper.make_tensor_value_info("b", TensorProto.FLOAT, [2, 3])
    output = helper.make_tensor_value_info("out", TensorProto.FLOAT, [2, 3])
    node = helper.make_node("Mod", inputs=["a", "b"], outputs=["out"], fmod=1)
    graph = helper.make_graph([node], "mod_graph", [input_a, input_b], [output])
    model = helper.make_model(
        graph,
        producer_name="emx-onnx-cgen",
        opset_imports=[helper.make_operatorsetid("", 13)],
    )
    model.ir_version = 7
    onnx.checker.check_model(model)
    return model


def _make_add_model() -> onnx.ModelProto:
    input_a = helper.make_tensor_value_info("a", TensorProto.FLOAT, [2, 3, 4])
    input_b = helper.make_tensor_value_info("b", TensorProto.FLOAT, [2, 3, 4])
    output = helper.make_tensor_value_info("out", TensorProto.FLOAT, [2, 3, 4])
    node = helper.make_node("Add", inputs=["a", "b"], outputs=["out"])
    graph = helper.make_graph([node], "add_graph", [input_a, input_b], [output])
    model = helper.make_model(
        graph,
        producer_name="emx-onnx-cgen",
        opset_imports=[helper.make_operatorsetid("", 13)],
    )
    model.ir_version = 7
    onnx.checker.check_model(model)
    return model


def _make_mul_model() -> onnx.ModelProto:
    input_a = helper.make_tensor_value_info("a", TensorProto.FLOAT, [2, 3])
    input_b = helper.make_tensor_value_info("b", TensorProto.FLOAT, [2, 3])
    output = helper.make_tensor_value_info("out", TensorProto.FLOAT, [2, 3])
    node = helper.make_node("Mul", inputs=["a", "b"], outputs=["out"])
    graph = helper.make_graph([node], "mul_graph", [input_a, input_b], [output])
    model = helper.make_model(
        graph,
        producer_name="emx-onnx-cgen",
        opset_imports=[helper.make_operatorsetid("", 13)],
    )
    model.ir_version = 7
    onnx.checker.check_model(model)
    return model


def _make_sequence_io_model() -> onnx.ModelProto:
    seq_input = helper.make_tensor_sequence_value_info(
        "seq_in", TensorProto.FLOAT, [2, 3]
    )
    tensor_input = helper.make_tensor_value_info("x", TensorProto.FLOAT, [1])
    seq_output = helper.make_tensor_sequence_value_info(
        "seq_out", TensorProto.FLOAT, [2, 3]
    )
    tensor_output = helper.make_tensor_value_info("y", TensorProto.FLOAT, [1])
    identity_node = helper.make_node("Identity", inputs=["x"], outputs=["y"])
    graph = helper.make_graph(
        [identity_node],
        "sequence_io_graph",
        [seq_input, tensor_input],
        [seq_output, tensor_output],
    )
    model = helper.make_model(
        graph,
        producer_name="emx-onnx-cgen",
        opset_imports=[helper.make_operatorsetid("", 13)],
    )
    model.ir_version = 7
    return model


def _make_mul_add_model() -> onnx.ModelProto:
    input_a = helper.make_tensor_value_info("a", TensorProto.FLOAT, [2, 3])
    input_b = helper.make_tensor_value_info("b", TensorProto.FLOAT, [2, 3])
    input_c = helper.make_tensor_value_info("c", TensorProto.FLOAT, [2, 3])
    output = helper.make_tensor_value_info("out", TensorProto.FLOAT, [2, 3])
    mul_node = helper.make_node("Mul", inputs=["a", "b"], outputs=["mul_out"])
    add_node = helper.make_node("Add", inputs=["mul_out", "c"], outputs=["out"])
    graph = helper.make_graph(
        [mul_node, add_node],
        "mul_add_graph",
        [input_a, input_b, input_c],
        [output],
    )
    model = helper.make_model(
        graph,
        producer_name="emx-onnx-cgen",
        opset_imports=[helper.make_operatorsetid("", 13)],
    )
    model.ir_version = 7
    onnx.checker.check_model(model)
    return model


def _make_mul_add_relu_model() -> onnx.ModelProto:
    input_a = helper.make_tensor_value_info("a", TensorProto.FLOAT, [2, 3])
    input_b = helper.make_tensor_value_info("b", TensorProto.FLOAT, [2, 3])
    input_c = helper.make_tensor_value_info("c", TensorProto.FLOAT, [2, 3])
    output = helper.make_tensor_value_info("out", TensorProto.FLOAT, [2, 3])
    mul_node = helper.make_node("Mul", inputs=["a", "b"], outputs=["mul_out"])
    add_node = helper.make_node("Add", inputs=["mul_out", "c"], outputs=["add_out"])
    relu_node = helper.make_node("Relu", inputs=["add_out"], outputs=["out"])
    graph = helper.make_graph(
        [mul_node, add_node, relu_node],
        "mul_add_relu_graph",
        [input_a, input_b, input_c],
        [output],
    )
    model = helper.make_model(
        graph,
        producer_name="emx-onnx-cgen",
        opset_imports=[helper.make_operatorsetid("", 13)],
    )
    model.ir_version = 7
    onnx.checker.check_model(model)
    return model


def _make_large_temp_model() -> onnx.ModelProto:
    shape = [1, 257]
    input_a = helper.make_tensor_value_info("a", TensorProto.FLOAT, shape)
    input_b = helper.make_tensor_value_info("b", TensorProto.FLOAT, shape)
    output = helper.make_tensor_value_info("out", TensorProto.FLOAT, shape)
    add_node = helper.make_node("Add", inputs=["a", "b"], outputs=["tmp"])
    relu_node = helper.make_node("Relu", inputs=["tmp"], outputs=["out"])
    graph = helper.make_graph(
        [add_node, relu_node],
        "large_temp_graph",
        [input_a, input_b],
        [output],
    )
    model = helper.make_model(
        graph,
        producer_name="emx-onnx-cgen",
        opset_imports=[helper.make_operatorsetid("", 13)],
    )
    model.ir_version = 7
    onnx.checker.check_model(model)
    return model


def _make_tanh_model() -> onnx.ModelProto:
    input_x = helper.make_tensor_value_info("x", TensorProto.FLOAT, [2, 3])
    output = helper.make_tensor_value_info("out", TensorProto.FLOAT, [2, 3])
    node = helper.make_node("Tanh", inputs=["x"], outputs=["out"])
    graph = helper.make_graph([node], "tanh_graph", [input_x], [output])
    model = helper.make_model(
        graph,
        producer_name="emx-onnx-cgen",
        opset_imports=[helper.make_operatorsetid("", 13)],
    )
    model.ir_version = 7
    onnx.checker.check_model(model)
    return model


def _make_relu_model() -> onnx.ModelProto:
    input_x = helper.make_tensor_value_info("x", TensorProto.FLOAT, [2, 3])
    output = helper.make_tensor_value_info("out", TensorProto.FLOAT, [2, 3])
    node = helper.make_node("Relu", inputs=["x"], outputs=["out"])
    graph = helper.make_graph([node], "relu_graph", [input_x], [output])
    model = helper.make_model(
        graph,
        producer_name="emx-onnx-cgen",
        opset_imports=[helper.make_operatorsetid("", 13)],
    )
    model.ir_version = 7
    onnx.checker.check_model(model)
    return model


def _make_identity_string_model() -> onnx.ModelProto:
    input_x = helper.make_tensor_value_info("x", TensorProto.STRING, [2])
    output = helper.make_tensor_value_info("out", TensorProto.STRING, [2])
    node = helper.make_node("Identity", inputs=["x"], outputs=["out"])
    graph = helper.make_graph([node], "identity_string_graph", [input_x], [output])
    model = helper.make_model(
        graph,
        producer_name="emx-onnx-cgen",
        opset_imports=[helper.make_operatorsetid("", 13)],
    )
    model.ir_version = 7
    onnx.checker.check_model(model)
    return model


def _make_string_normalizer_model() -> onnx.ModelProto:
    input_x = helper.make_tensor_value_info("x", TensorProto.STRING, [4])
    output = helper.make_tensor_value_info("out", TensorProto.STRING, [3])
    node = helper.make_node(
        "StringNormalizer",
        inputs=["x"],
        outputs=["out"],
        case_change_action="UPPER",
        is_case_sensitive=1,
        stopwords=["monday"],
    )
    graph = helper.make_graph([node], "string_normalizer_graph", [input_x], [output])
    model = helper.make_model(
        graph,
        producer_name="emx-onnx-cgen",
        opset_imports=[helper.make_operatorsetid("", 10)],
    )
    model.ir_version = 7
    onnx.checker.check_model(model)
    return model


def _make_string_concat_model() -> onnx.ModelProto:
    input_x = helper.make_tensor_value_info("x", TensorProto.STRING, [3])
    input_y = helper.make_tensor_value_info("y", TensorProto.STRING, [1])
    output = helper.make_tensor_value_info("out", TensorProto.STRING, [3])
    node = helper.make_node(
        "StringConcat",
        inputs=["x", "y"],
        outputs=["out"],
    )
    graph = helper.make_graph(
        [node], "string_concat_graph", [input_x, input_y], [output]
    )
    model = helper.make_model(
        graph,
        producer_name="emx-onnx-cgen",
        opset_imports=[helper.make_operatorsetid("", 20)],
    )
    model.ir_version = 9
    onnx.checker.check_model(model)
    return model


def _make_constant_string_model() -> onnx.ModelProto:
    output = helper.make_tensor_value_info("out", TensorProto.STRING, [2])
    constant = helper.make_node(
        "Constant",
        inputs=[],
        outputs=["const_out"],
        value_strings=[b"hello", b"world"],
    )
    identity = helper.make_node("Identity", ["const_out"], ["out"])
    graph = helper.make_graph(
        [constant, identity], "constant_string_graph", [], [output]
    )
    model = helper.make_model(
        graph,
        producer_name="emx-onnx-cgen",
        opset_imports=[helper.make_operatorsetid("", 13)],
    )
    model.ir_version = 7
    onnx.checker.check_model(model)
    return model


def _make_matmul_model() -> onnx.ModelProto:
    input_a = helper.make_tensor_value_info("a", TensorProto.FLOAT, [2, 3])
    input_b = helper.make_tensor_value_info("b", TensorProto.FLOAT, [3, 4])
    output = helper.make_tensor_value_info("out", TensorProto.FLOAT, [2, 4])
    node = helper.make_node("MatMul", inputs=["a", "b"], outputs=["out"])
    graph = helper.make_graph([node], "matmul_graph", [input_a, input_b], [output])
    model = helper.make_model(
        graph,
        producer_name="emx-onnx-cgen",
        opset_imports=[helper.make_operatorsetid("", 13)],
    )
    model.ir_version = 7
    onnx.checker.check_model(model)
    return model


def _make_add_initializer_model() -> onnx.ModelProto:
    input_info = helper.make_tensor_value_info("in0", TensorProto.FLOAT, [2, 3])
    output = helper.make_tensor_value_info("out", TensorProto.FLOAT, [2, 3])
    weight_values = np.linspace(0.1, 0.6, num=6, dtype=np.float32).reshape(2, 3)
    weight_initializer = helper.make_tensor(
        "weight",
        TensorProto.FLOAT,
        dims=[2, 3],
        vals=weight_values.flatten().tolist(),
    )
    weight_info = helper.make_tensor_value_info("weight", TensorProto.FLOAT, [2, 3])
    node = helper.make_node("Add", inputs=["in0", "weight"], outputs=["out"])
    graph = helper.make_graph(
        [node],
        "add_init_graph",
        [input_info, weight_info],
        [output],
        initializer=[weight_initializer],
    )
    model = helper.make_model(
        graph,
        producer_name="emx-onnx-cgen",
        opset_imports=[helper.make_operatorsetid("", 13)],
    )
    model.ir_version = 7
    onnx.checker.check_model(model)
    return model


def _make_large_weight_initializer_model() -> onnx.ModelProto:
    input_info = helper.make_tensor_value_info("in0", TensorProto.FLOAT, [2, 3])
    output = helper.make_tensor_value_info("out", TensorProto.FLOAT, [2, 3])
    weight_values = np.linspace(0.1, 0.6, num=6, dtype=np.float32).reshape(2, 3)
    weight_initializer = helper.make_tensor(
        "weight_large",
        TensorProto.FLOAT,
        dims=[2, 3],
        vals=weight_values.flatten().tolist(),
    )
    weight_info = helper.make_tensor_value_info(
        "weight_large", TensorProto.FLOAT, [2, 3]
    )
    node = helper.make_node("Add", inputs=["in0", "weight_large"], outputs=["out"])
    graph = helper.make_graph(
        [node],
        "add_large_init_graph",
        [input_info, weight_info],
        [output],
        initializer=[weight_initializer],
    )
    model = helper.make_model(
        graph,
        producer_name="emx-onnx-cgen",
        opset_imports=[helper.make_operatorsetid("", 13)],
    )
    model.ir_version = 7
    onnx.checker.check_model(model)
    return model


def _load_official_onnx_model(repo_relative_path: str) -> onnx.ModelProto:
    return onnx.load(Path(__file__).resolve().parent.parent / repo_relative_path)


def _mark_dynamic_dims(
    model: onnx.ModelProto,
    *,
    input_dim_params: list[str],
    output_dim_params: list[str],
) -> onnx.ModelProto:
    for value_info in model.graph.input:
        for dim, dim_param in zip(
            value_info.type.tensor_type.shape.dim, input_dim_params
        ):
            dim.dim_param = dim_param
    for value_info in model.graph.output:
        for dim, dim_param in zip(
            value_info.type.tensor_type.shape.dim, output_dim_params
        ):
            dim.dim_param = dim_param
    return model


def test_codegen_golden_tanh() -> None:
    model = _make_tanh_model()
    compiler = Compiler()
    generated = compiler.compile(model)
    golden_path = Path(__file__).parent / "golden" / "tanh_model.c"
    assert_golden(generated, golden_path)


def test_codegen_golden_relu() -> None:
    model = _make_relu_model()
    compiler = Compiler()
    generated = compiler.compile(model)
    golden_path = Path(__file__).parent / "golden" / "relu_model.c"
    assert_golden(generated, golden_path)


def test_codegen_golden_sequence_io() -> None:
    model = _make_sequence_io_model()
    compiler = Compiler(CompilerOptions(model_name="sequence_io_model"))
    generated = compiler.compile(model)
    golden_path = Path(__file__).parent / "golden" / "sequence_io_model.c"
    assert_golden(generated, golden_path)


def test_codegen_golden_dynamic_dims() -> None:
    model = _mark_dynamic_dims(
        _make_relu_model(),
        input_dim_params=["N", "C"],
        output_dim_params=["N", "C"],
    )
    compiler = Compiler(
        CompilerOptions(
            model_name="dynamic_dims_model",
        )
    )
    generated = compiler.compile(model)
    golden_path = Path(__file__).parent / "golden" / "dynamic_dims_model.c"
    assert_golden(generated, golden_path)


def test_tanh_matches_onnxruntime() -> None:
    model = _make_tanh_model()
    input_x = np.random.rand(2, 3).astype(np.float32)

    sess = ort.InferenceSession(
        model.SerializeToString(), providers=["CPUExecutionProvider"]
    )
    (ort_out,) = sess.run(None, {"x": input_x})

    reference_outputs = _run_reference(model, {"x": input_x})
    np.testing.assert_allclose(reference_outputs["out"], ort_out, rtol=1e-4, atol=1e-5)


def test_relu_matches_onnxruntime() -> None:
    model = _make_relu_model()
    input_x = np.random.randn(2, 3).astype(np.float32)

    sess = ort.InferenceSession(
        model.SerializeToString(), providers=["CPUExecutionProvider"]
    )
    (ort_out,) = sess.run(None, {"x": input_x})

    reference_outputs = _run_reference(model, {"x": input_x})
    np.testing.assert_allclose(reference_outputs["out"], ort_out, rtol=1e-4, atol=1e-5)


def test_codegen_golden_add() -> None:
    model = _make_add_model()
    compiler = Compiler()
    generated = compiler.compile(model)
    golden_path = Path(__file__).parent / "golden" / "add_model.c"
    assert_golden(generated, golden_path)


def test_codegen_golden_add_no_restrict() -> None:
    model = _make_add_model()
    compiler = Compiler(CompilerOptions(restrict_arrays=False))
    generated = compiler.compile(model)
    golden_path = Path(__file__).parent / "golden" / "add_model_no_restrict.c"
    assert_golden(generated, golden_path)


def test_codegen_golden_add_initializer() -> None:
    model = _make_add_initializer_model()
    compiler = Compiler()
    generated = compiler.compile(model)
    golden_path = Path(__file__).parent / "golden" / "add_initializer_model.c"
    assert_golden(generated, golden_path)


def test_codegen_golden_large_weight_loader() -> None:
    model = _make_large_weight_initializer_model()
    compiler = Compiler(
        CompilerOptions(
            model_name="large_weight_model",
            large_weight_threshold=4,
            emit_testbench=True,
        )
    )
    generated = compiler.compile(model)
    golden_path = Path(__file__).parent / "golden" / "large_weight_model_testbench.c"
    assert_golden(generated, golden_path)


def test_add_matches_onnxruntime() -> None:
    model = _make_add_model()
    input_a = np.random.rand(2, 3, 4).astype(np.float32)
    input_b = np.random.rand(2, 3, 4).astype(np.float32)

    sess = ort.InferenceSession(
        model.SerializeToString(), providers=["CPUExecutionProvider"]
    )
    (ort_out,) = sess.run(None, {"a": input_a, "b": input_b})

    reference_outputs = _run_reference(model, {"a": input_a, "b": input_b})
    np.testing.assert_allclose(reference_outputs["out"], ort_out, rtol=1e-4, atol=1e-5)


def test_codegen_golden_mul() -> None:
    model = _make_mul_model()
    compiler = Compiler()
    generated = compiler.compile(model)
    golden_path = Path(__file__).parent / "golden" / "mul_model.c"
    assert_golden(generated, golden_path)


def test_mul_matches_onnxruntime() -> None:
    model = _make_mul_model()
    input_a = np.random.rand(2, 3).astype(np.float32)
    input_b = np.random.rand(2, 3).astype(np.float32)

    sess = ort.InferenceSession(
        model.SerializeToString(), providers=["CPUExecutionProvider"]
    )
    (ort_out,) = sess.run(None, {"a": input_a, "b": input_b})

    reference_outputs = _run_reference(model, {"a": input_a, "b": input_b})
    np.testing.assert_allclose(reference_outputs["out"], ort_out, rtol=1e-4, atol=1e-5)


@pytest.mark.parametrize(
    "op_type, expected_fn",
    [
        ("Sub", lambda left, right: left - right),
        ("Div", lambda left, right: left / right),
        ("Pow", np.power),
        ("Min", np.minimum),
        ("Max", np.maximum),
        ("Mean", lambda left, right: (left + right) * 0.5),
        ("Sum", lambda left, right: left + right),
        ("PRelu", lambda left, right: np.where(left > 0.0, left, right * left)),
    ],
    ids=["Sub", "Div", "Pow", "Min", "Max", "Mean", "Sum", "PRelu"],
)
def test_binary_ops_match_numpy(
    op_type: str, expected_fn: Callable[[np.ndarray, np.ndarray], np.ndarray]
) -> None:
    model = _make_binary_model(op_type, [2, 3])
    left = np.random.uniform(-1.0, 1.0, size=(2, 3)).astype(np.float32)
    right = np.random.uniform(0.1, 2.0, size=(2, 3)).astype(np.float32)
    if op_type in {"Div", "Pow"}:
        left = np.random.uniform(0.1, 2.0, size=(2, 3)).astype(np.float32)
    if op_type == "PRelu":
        left = np.random.uniform(-1.0, 1.0, size=(2, 3)).astype(np.float32)
        right = np.random.uniform(0.1, 1.0, size=(2, 3)).astype(np.float32)
    expected = expected_fn(left, right)
    reference_outputs = _run_reference(model, {"a": left, "b": right})
    np.testing.assert_allclose(reference_outputs["out"], expected, rtol=1e-4, atol=1e-5)


def test_prelu_channel_broadcast_matches_numpy() -> None:
    model = _make_prelu_channel_model()
    left = np.random.uniform(-1.0, 1.0, size=(2, 3, 4)).astype(np.float32)
    slope = np.random.uniform(0.1, 1.0, size=(3,)).astype(np.float32)
    expected = np.where(
        left > 0.0,
        left,
        left * slope.reshape(1, 3, 1),
    )
    reference_outputs = _run_reference(model, {"a": left, "b": slope})
    np.testing.assert_allclose(reference_outputs["out"], expected, rtol=1e-4, atol=1e-5)


def test_mod_matches_numpy() -> None:
    model = _make_mod_model()
    left = np.random.uniform(0.1, 2.0, size=(2, 3)).astype(np.float32)
    right = np.random.uniform(0.1, 2.0, size=(2, 3)).astype(np.float32)
    expected = np.fmod(left, right)
    reference_outputs = _run_reference(model, {"a": left, "b": right})
    np.testing.assert_allclose(reference_outputs["out"], expected, rtol=1e-4, atol=1e-5)


def test_codegen_golden_mul_add() -> None:
    model = _make_mul_add_model()
    compiler = Compiler()
    generated = compiler.compile(model)
    golden_path = Path(__file__).parent / "golden" / "mul_add_model.c"
    assert_golden(generated, golden_path)


def test_codegen_golden_mul_add_relu() -> None:
    model = _make_mul_add_relu_model()
    compiler = Compiler()
    generated = compiler.compile(model)
    golden_path = Path(__file__).parent / "golden" / "mul_add_relu_model.c"
    assert_golden(generated, golden_path)


def test_codegen_golden_large_temp_static() -> None:
    model = _make_large_temp_model()
    compiler = Compiler(
        CompilerOptions(
            model_name="large_temp_static_model",
        )
    )
    generated = compiler.compile(model)
    golden_path = Path(__file__).parent / "golden" / "large_temp_static_model.c"
    assert_golden(generated, golden_path)


def test_mul_add_matches_onnxruntime() -> None:
    model = _make_mul_add_model()
    input_a = np.random.rand(2, 3).astype(np.float32)
    input_b = np.random.rand(2, 3).astype(np.float32)
    input_c = np.random.rand(2, 3).astype(np.float32)

    sess = ort.InferenceSession(
        model.SerializeToString(), providers=["CPUExecutionProvider"]
    )
    (ort_out,) = sess.run(None, {"a": input_a, "b": input_b, "c": input_c})

    reference_outputs = _run_reference(
        model, {"a": input_a, "b": input_b, "c": input_c}
    )
    np.testing.assert_allclose(reference_outputs["out"], ort_out, rtol=1e-4, atol=1e-5)


def test_mul_add_relu_matches_onnxruntime() -> None:
    model = _make_mul_add_relu_model()
    input_a = np.random.rand(2, 3).astype(np.float32)
    input_b = np.random.rand(2, 3).astype(np.float32)
    input_c = np.random.rand(2, 3).astype(np.float32)

    sess = ort.InferenceSession(
        model.SerializeToString(), providers=["CPUExecutionProvider"]
    )
    (ort_out,) = sess.run(None, {"a": input_a, "b": input_b, "c": input_c})

    reference_outputs = _run_reference(
        model, {"a": input_a, "b": input_b, "c": input_c}
    )
    np.testing.assert_allclose(reference_outputs["out"], ort_out, rtol=1e-4, atol=1e-5)


def test_codegen_golden_identity_string() -> None:
    model = _make_identity_string_model()
    compiler = Compiler(CompilerOptions(model_name="identity_string_model"))
    generated = compiler.compile(model)
    golden_path = Path(__file__).parent / "golden" / "identity_string_model.c"
    assert_golden(generated, golden_path)


def test_codegen_golden_string_normalizer() -> None:
    model = _make_string_normalizer_model()
    compiler = Compiler(CompilerOptions(model_name="string_normalizer_model"))
    generated = compiler.compile(model)
    golden_path = Path(__file__).parent / "golden" / "string_normalizer_model.c"
    assert_golden(generated, golden_path)


def test_codegen_golden_string_concat() -> None:
    model = _make_string_concat_model()
    compiler = Compiler(CompilerOptions(model_name="string_concat_model"))
    generated = compiler.compile(model)
    golden_path = Path(__file__).parent / "golden" / "string_concat_model.c"
    assert_golden(generated, golden_path)


def test_codegen_golden_constant_string() -> None:
    model = _make_constant_string_model()
    compiler = Compiler(CompilerOptions(model_name="constant_string_model"))
    generated = compiler.compile(model)
    golden_path = Path(__file__).parent / "golden" / "constant_string_model.c"
    assert_golden(generated, golden_path)


def test_codegen_golden_loop_range_official_model() -> None:
    model = _load_official_onnx_model(
        "onnx-org/onnx/backend/test/data/node/test_range_float_type_positive_delta_expanded/model.onnx"
    )
    compiler = Compiler(CompilerOptions(model_name="loop_range_float_model"))
    generated = compiler.compile(model)
    golden_path = Path(__file__).parent / "golden" / "loop_range_float_model.c"
    assert_golden(generated, golden_path)


def test_codegen_loop11_emits_runtime_loop() -> None:
    model = _load_official_onnx_model(
        "onnx-org/onnx/backend/test/data/node/test_loop11/model.onnx"
    )
    compiler = Compiler(CompilerOptions(model_name="loop11_model"))
    generated = compiler.compile(model)
    assert "for (int64_t idx = 0; idx < trip; ++idx)" in generated
    assert "loop_add_table" in generated


def test_codegen_loop13_seq_emits_runtime_loop() -> None:
    model = _load_official_onnx_model(
        "onnx-org/onnx/backend/test/data/node/test_loop13_seq/model.onnx"
    )
    compiler = Compiler(CompilerOptions(model_name="loop13_seq_model"))
    generated = compiler.compile(model)
    assert "for (int64_t idx = 0; idx < append_count; ++idx)" in generated
    assert "loop_insert_table" in generated


def test_codegen_golden_matmul() -> None:
    model = _make_matmul_model()
    compiler = Compiler()
    generated = compiler.compile(model)
    golden_path = Path(__file__).parent / "golden" / "matmul_model.c"
    assert_golden(generated, golden_path)


def test_codegen_includes_testbench() -> None:
    model = _make_add_model()
    options = CompilerOptions(emit_testbench=True)
    compiler = Compiler(options)
    generated = compiler.compile(model)
    golden_path = Path(__file__).parent / "golden" / "add_model_testbench.c"
    assert_golden(generated, golden_path)


def test_codegen_testbench_output_format_defaults_to_json() -> None:
    model = _make_add_model()
    compiler = Compiler(CompilerOptions(emit_testbench=True))
    generated = compiler.compile(model)

    assert 'printf("{\\n  \\"outputs\\": {\\n");' in generated
    assert "testbench_print_json(out);" in generated


def test_codegen_testbench_output_format_txt() -> None:
    model = _make_add_model()
    options = CompilerOptions(emit_testbench=True, testbench_output_format="txt")
    compiler = Compiler(options)
    generated = compiler.compile(model)
    golden_path = Path(__file__).parent / "golden" / "add_model_testbench_txt.c"
    assert_golden(generated, golden_path)


def test_codegen_testbench_output_format_txt_emmtrix() -> None:
    model = _make_add_model()
    options = CompilerOptions(
        emit_testbench=True, testbench_output_format="txt-emmtrix"
    )
    compiler = Compiler(options)
    generated = compiler.compile(model)
    golden_path = Path(__file__).parent / "golden" / "add_model_testbench_txt_emmtrix.c"
    assert_golden(generated, golden_path)


def test_codegen_testbench_output_format_txt_emmtrix_custom_ulp() -> None:
    model = _make_add_model()
    options = CompilerOptions(
        emit_testbench=True, testbench_output_format="txt-emmtrix:123.5"
    )
    compiler = Compiler(options)
    generated = compiler.compile(model)

    assert "#ULP123.5" in generated


def test_reduce_mean_uses_fp64_accumulator_when_requested() -> None:
    input_info = helper.make_tensor_value_info("input", TensorProto.FLOAT, [2, 3, 4])
    output = helper.make_tensor_value_info("output", TensorProto.FLOAT, [2, 1, 4])
    node = helper.make_node(
        "ReduceMean",
        inputs=["input"],
        outputs=["output"],
        axes=[1],
        keepdims=1,
    )
    graph = helper.make_graph([node], "reduce_mean_fp64_graph", [input_info], [output])
    model = helper.make_model(
        graph,
        producer_name="emx-onnx-cgen",
        opset_imports=[helper.make_operatorsetid("", 13)],
    )
    model.ir_version = 7
    onnx.checker.check_model(model)

    generated = Compiler(CompilerOptions(fp32_accumulation_strategy="fp64")).compile(
        model
    )

    assert "double acc = 0.0;" in generated
    assert "output[i0][i1][i2] = acc / 3.0;" in generated


def test_codegen_testbench_uses_large_temp_threshold_for_io_buffers() -> None:
    model = _make_add_model()

    static_generated = Compiler(
        CompilerOptions(emit_testbench=True, large_temp_threshold_bytes=95)
    ).compile(model)
    stack_generated = Compiler(
        CompilerOptions(emit_testbench=True, large_temp_threshold_bytes=96)
    ).compile(model)

    assert "    static float a[2][3][4];" in static_generated
    assert "    static float b[2][3][4];" in static_generated
    assert "    static float out[2][3][4];" in static_generated
    assert "    static float a[2][3][4];" not in stack_generated
    assert "    static float b[2][3][4];" not in stack_generated
    assert "    static float out[2][3][4];" not in stack_generated
    assert "    float a[2][3][4];" in stack_generated
    assert "    float b[2][3][4];" in stack_generated
    assert "    float out[2][3][4];" in stack_generated


def test_codegen_separate_testbench_source() -> None:
    model = _make_add_model()
    compiler = Compiler(CompilerOptions(emit_testbench=False))
    testbench = compiler.compile_testbench(model)
    decls = compiler.compile_testbench_declarations(model)
    from emx_onnx_cgen.cli import _wrap_separate_testbench_source

    rendered = _wrap_separate_testbench_source(decls, testbench)
    golden_path = Path(__file__).parent / "golden" / "add_model_testbench_separate.c"
    assert_golden(rendered, golden_path)


def test_matmul_matches_onnxruntime() -> None:
    model = _make_matmul_model()
    input_a = np.random.rand(2, 3).astype(np.float32)
    input_b = np.random.rand(3, 4).astype(np.float32)

    sess = ort.InferenceSession(
        model.SerializeToString(), providers=["CPUExecutionProvider"]
    )
    (ort_out,) = sess.run(None, {"a": input_a, "b": input_b})

    reference_outputs = _run_reference(model, {"a": input_a, "b": input_b})
    np.testing.assert_allclose(reference_outputs["out"], ort_out, rtol=1e-4, atol=1e-5)


# -- Float8 golden tests -----------------------------------------------------


def _make_cast_float_to_f8e4m3fn_model() -> onnx.ModelProto:
    x = helper.make_tensor_value_info("x", TensorProto.FLOAT, [2, 3])
    y = helper.make_tensor_value_info("y", TensorProto.FLOAT8E4M3FN, [2, 3])
    node = helper.make_node("Cast", ["x"], ["y"], to=TensorProto.FLOAT8E4M3FN)
    graph = helper.make_graph([node], "cast_f32_to_f8e4m3fn", [x], [y])
    model = helper.make_model(
        graph,
        producer_name="emx-onnx-cgen",
        opset_imports=[helper.make_opsetid("", 25)],
    )
    model.ir_version = 10
    return model


def _make_cast_f8e4m3fn_to_float_model() -> onnx.ModelProto:
    x = helper.make_tensor_value_info("x", TensorProto.FLOAT8E4M3FN, [2, 3])
    y = helper.make_tensor_value_info("y", TensorProto.FLOAT, [2, 3])
    node = helper.make_node("Cast", ["x"], ["y"], to=TensorProto.FLOAT)
    graph = helper.make_graph([node], "cast_f8e4m3fn_to_f32", [x], [y])
    model = helper.make_model(
        graph,
        producer_name="emx-onnx-cgen",
        opset_imports=[helper.make_opsetid("", 25)],
    )
    model.ir_version = 10
    return model


def test_codegen_golden_cast_float_to_f8e4m3fn() -> None:
    model = _make_cast_float_to_f8e4m3fn_model()
    compiler = Compiler()
    generated = compiler.compile(model)
    golden_path = Path(__file__).parent / "golden" / "cast_float_to_f8e4m3fn.c"
    assert_golden(generated, golden_path)


def test_codegen_golden_cast_f8e4m3fn_to_float() -> None:
    model = _make_cast_f8e4m3fn_to_float_model()
    compiler = Compiler()
    generated = compiler.compile(model)
    golden_path = Path(__file__).parent / "golden" / "cast_f8e4m3fn_to_float.c"
    assert_golden(generated, golden_path)
