def pipelineRoll() {

    stage('Checkout') {
        withCredentials([usernamePassword(credentialsId: 'giteauth', usernameVariable: 'GIT_USERNAME', passwordVariable: 'GIT_PASSWORD')]) {
            echo '---------------------GitHub Checkout started!----------------------'
            sh '''
              apt-get update
              apt-get install -y git ca-certificates
            '''
            sh 'rm -rf ${GIT_REPO_NAME}'
            sh 'git clone https://${GIT_USERNAME}:${GIT_PASSWORD}@git.delbank.srv.br/DelbankDev/${GIT_REPO_NAME}.git'

            dir("${GIT_REPO_NAME}") {
                sh 'git fetch --all --tags'
                sh "git checkout ${env.BRANCH_NAME}"

                def tagged = sh(
                    script: 'git tag --points-at HEAD',
                    returnStdout: true
                ).trim()

                // Remove o prefixo 'v' da tag para garantir compatibilidade com PEP 440
                def tag = sh(
                    script: 'git describe --tags --abbrev=0 2>/dev/null | sed "s/^v//" || echo 0.0.0',
                    returnStdout: true
                ).trim()

                if (tagged) {
                    env.VERSION = "${tag}"
                } else {
                    env.VERSION = "${tag}b${TAG}"
                }
            }
            echo "---------------------GitHub Checkout finished! VERSION=${env.VERSION}---------------------"
        }
    }

    stage('Generating Artifact') {
        echo "Python artifact will be generated for version ${env.VERSION}"
        sh 'rm -rf /dist'
        sh 'pip install -U pip setuptools wheel'

        dir("${GIT_REPO_NAME}") {
            sh 'pip install -r requirements.txt'

            // withEnv garante que a variável chegue corretamente ao setuptools_scm
            // evitando que ele tente parsear a tag do git (que vem como 'origin/v0.6.0' e falha)
            withEnv(["SETUPTOOLS_SCM_PRETEND_VERSION=${env.VERSION}"]) {
                sh 'python setup.py sdist bdist_wheel'
            }
        }

        sh 'pip install -U pip twine'
    }

    stage('Publish to Gitea') {
        withCredentials([
            string(credentialsId: 'gitea-package-publisher', variable: 'GITEA_TOKEN')
        ]) {
            dir("${GIT_REPO_NAME}") {
                sh """
                    export TWINE_USERNAME=__token__
                    export TWINE_PASSWORD=${GITEA_TOKEN}

                    twine upload --verbose --repository-url ${GITEA_PYPI_SOURCE} dist/delfinance_api_sdk-${env.VERSION}*
                """
            }
        }
    }

}

return this