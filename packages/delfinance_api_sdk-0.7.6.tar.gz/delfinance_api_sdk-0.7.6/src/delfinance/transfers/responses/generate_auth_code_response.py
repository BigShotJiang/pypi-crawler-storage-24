from typing import Dict, Any

class GenerateAuthCodeResponse:
    """
    Response object for Generate Auth Code operation.
    """
    def __init__(self, data: Dict[str, Any] = None):
        self.auth_id = None
        self.raw_data = data

        if data:
            self.auth_id = data.get('id')
