class DecodeQrCodeResponse:
    """
    Response object for QR Code decoding.
    """
    def __init__(self, data: dict = None):
        self.key = None
        self.end_to_end_id = None
        self.transaction_id = None
        self.expiration_time = None
        self.revision = None
        self.allow_change_amount = None
        self.category_code = None
        self.created_at = None
        self.captured_at = None
        self.type = None
        self.status = None
        self.amount = None
        self.original_amount = None
        self.fine_amount = None
        self.fees_amount = None
        self.discount_amount = None
        self.rebate_amount = None
        self.due_date = None
        self.payment_deadline = None
        self.payer = None
        self.bank_account_recipient = None
        self.beneficiary = None
        self.additional_infos = None
        self.recurrence = None

        if data:
            self.key = data.get('key')
            self.end_to_end_id = data.get('endToEndId')
            self.transaction_id = data.get('transactionId')
            self.expiration_time = data.get('expirationTime')
            self.revision = data.get('revision')
            self.allow_change_amount = data.get('allowChangeAmount')
            self.category_code = data.get('categoryCode')
            self.created_at = data.get('createdAt')
            self.captured_at = data.get('capturedAt')
            self.type = data.get('type')
            self.status = data.get('status')
            self.amount = data.get('amount')
            self.original_amount = data.get('originalAmount')
            self.fine_amount = data.get('fineAmount')
            self.fees_amount = data.get('feesAmount')
            self.discount_amount = data.get('discountAmount')
            self.rebate_amount = data.get('rebateAmount')
            self.due_date = data.get('dueDate')
            self.payment_deadline = data.get('paymentDeadline')
            self.payer = data.get('payer')
            self.bank_account_recipient = data.get('bankAccountRecipient')
            self.beneficiary = data.get('beneficiary')
            self.additional_infos = data.get('additionalInfos')
            self.recurrence = data.get('recurrence')
