from typing import List, Dict, Any

class GetPixKeysResponse:
    """
    Response object for Get Pix Keys operation.
    """
    def __init__(self, data: List[Dict[str, Any]] = None):
        self.keys = data if data else []
