from .create_transfer_response import CreateTransferResponse

class CreateTedTransferResponse(CreateTransferResponse):
    """
    Response object for Create TED Transfer operation.
    Inherits from CreateTransferResponse as the structure is identical.
    """
    def __init__(self, data: dict = None):
        super().__init__(data)
