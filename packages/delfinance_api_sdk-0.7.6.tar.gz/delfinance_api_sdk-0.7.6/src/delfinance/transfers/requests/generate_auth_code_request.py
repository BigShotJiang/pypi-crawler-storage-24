from typing import Optional

class GenerateAuthCodeRequest:
    """
    Request object for generating an Auth Code (for email/phone Pix keys).
    """
    def __init__(
        self,
        sender: str,
        receiver: str,
        payload: str
    ):
        """
        :param sender: Required. EMAIL or SMS
        :param receiver: Required. Phone number (with country code, e.g., +5579901010202) or email.
        :param payload: Required. SMS message or email HTML. Use {{code}} placeholder.
        """
        self.sender = sender
        self.receiver = receiver
        self.payload = payload

    def to_dict(self) -> dict:
        return {
            'sender': self.sender,
            'receiver': self.receiver,
            'payload': self.payload
        }
