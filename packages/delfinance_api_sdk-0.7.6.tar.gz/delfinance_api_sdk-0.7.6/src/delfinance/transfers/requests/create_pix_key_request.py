from typing import Optional

class CreatePixKeyRequest:
    """
    Request object for creating a Pix Key.
    """
    def __init__(
        self,
        entry_type: str,
        key: Optional[str] = None,
        auth_code: Optional[str] = None,
        auth_id: Optional[str] = None
    ):
        """
        :param entry_type: Required. Possible values: DOCUMENT, EVP, PHONE, EMAIL
        :param key: Optional. The key value (required for DOCUMENT, PHONE, EMAIL).
        :param auth_code: Optional. Verification code sent by SMS/Email (required for PHONE/EMAIL).
        :param auth_id: Optional. ID returned from the auth code endpoint (required for PHONE/EMAIL).
        """
        self.entry_type = entry_type
        self.key = key
        self.auth_code = auth_code
        self.auth_id = auth_id

    def to_dict(self) -> dict:
        data = {
            'entryType': self.entry_type
        }
        if self.key:
            data['key'] = self.key
        return data
