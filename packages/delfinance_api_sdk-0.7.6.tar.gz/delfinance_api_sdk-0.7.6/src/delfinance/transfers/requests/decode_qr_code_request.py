class DecodeQrCodeRequest:
    """
    Request payload for initializing a Pix payment via QR Code.
    """
    def __init__(self, payload: str):
        """
        DecodeQrCodeRequest constructor.
        :param payload: The raw QR Code string
        """
        self.payload = payload
