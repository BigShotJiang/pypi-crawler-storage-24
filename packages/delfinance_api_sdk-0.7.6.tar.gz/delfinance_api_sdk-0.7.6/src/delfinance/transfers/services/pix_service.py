import requests
import json
from ...abstractions.startup.delfinance_client import DelfinanceClient
from ..interfaces.ipix_service import IPixService
from ..requests.payment_initialization_request import PaymentInitializationRequest
from ..requests.decode_qr_code_request import DecodeQrCodeRequest
from ..responses.payment_initialization_response import PaymentInitializationResponse
from ..responses.decode_qr_code_response import DecodeQrCodeResponse
from ..requests.create_pix_key_request import CreatePixKeyRequest
from ..requests.delete_pix_key_request import DeletePixKeyRequest
from ..responses.create_pix_key_response import CreatePixKeyResponse
from ..responses.get_pix_keys_response import GetPixKeysResponse
from ..requests.generate_auth_code_request import GenerateAuthCodeRequest
from ..responses.generate_auth_code_response import GenerateAuthCodeResponse

class PixService(IPixService):
    """
    Class PixService
    """
    def __init__(self, client: DelfinanceClient):
        self.client = client

    def payment_initialization(self, request: PaymentInitializationRequest) -> PaymentInitializationResponse:
        """
        Initializes a Pix payment using a DICT key.
        """
        url = f"{self.client.get_base_url()}/baas/api/v2/pix/dict/payment-initialization"
        
        payload = {
            'key': request.key
        }

        if request.holder_document:
            payload['holderDocument'] = request.holder_document

        headers = {
            'Content-Type': 'application/json',
            'Accept': 'application/json',
            'x-delbank-api-key': self.client.get_api_key(),
            'x-delfinance-account-id': self.client.get_account_id(),
        }

        # Setup mTLS if configured
        cert = None
        if self.client.get_certificate_path() and self.client.get_private_key_path():
            cert = (self.client.get_certificate_path(), self.client.get_private_key_path())

        try:
            response = requests.post(
                url, 
                json=payload,
                headers=headers, 
                cert=cert,
                timeout=30
            )
            
            if response.status_code >= 400:
                raise Exception(f"API Error: {response.text}", response.status_code)
            
            data = response.json()
            return PaymentInitializationResponse(data)
            
        except requests.exceptions.RequestException as e:
            raise Exception(f"Request Error: {str(e)}")

    def decode_qr_code(self, request: DecodeQrCodeRequest) -> DecodeQrCodeResponse:
        """
        Initializes a Pix payment using a QR Code payload (decoding the QrCode).
        """
        url = f"{self.client.get_base_url()}/baas/api/v2/pix/qrcode/payment-initialization"
        
        payload = {
            'payload': request.payload
        }

        headers = {
            'Content-Type': 'application/json',
            'Accept': 'application/json',
            'x-delbank-api-key': self.client.get_api_key(),
            'x-delfinance-account-id': self.client.get_account_id(),
        }

        # Setup mTLS if configured
        cert = None
        if self.client.get_certificate_path() and self.client.get_private_key_path():
            cert = (self.client.get_certificate_path(), self.client.get_private_key_path())

        try:
            response = requests.post(
                url, 
                json=payload,
                headers=headers, 
                cert=cert,
                timeout=30
            )
            
            if response.status_code >= 400:
                raise Exception(f"API Error: {response.text}", response.status_code)
            
            data = response.json()
            return DecodeQrCodeResponse(data)
            
        except requests.exceptions.RequestException as e:
            raise Exception(f"Request Error: {str(e)}")

    def create_pix_key(self, request: CreatePixKeyRequest, idempotency_key: str) -> CreatePixKeyResponse:
        """
        Creates a Pix Key.
        """
        url = f"{self.client.get_base_url()}/baas/api/v1/pix/dict/entries"
        
        payload = request.to_dict()

        headers = {
            'Content-Type': 'application/json',
            'Accept': 'application/json',
            'x-delbank-api-key': self.client.get_api_key(),
            'x-delfinance-account-id': self.client.get_account_id(),
            'IdempotencyKey': idempotency_key
        }

        if request.auth_code:
            headers['x-auth-code'] = request.auth_code
        
        if request.auth_id:
            headers['x-auth-id'] = request.auth_id

        # Setup mTLS if configured
        cert = None
        if self.client.get_certificate_path() and self.client.get_private_key_path():
            cert = (self.client.get_certificate_path(), self.client.get_private_key_path())

        try:
            response = requests.post(
                url, 
                json=payload,
                headers=headers, 
                cert=cert,
                timeout=30
            )
            
            if response.status_code >= 400:
                raise Exception(f"API Error: {response.text}", response.status_code)
            
            data = response.json()
            return CreatePixKeyResponse(data)
            
        except requests.exceptions.RequestException as e:
            raise Exception(f"Request Error: {str(e)}")

    def delete_pix_key(self, request: DeletePixKeyRequest, idempotency_key: str) -> None:
        """
        Deletes a Pix Key.
        """
        url = f"{self.client.get_base_url()}/baas/api/v1/pix/dict/entries"
        
        payload = request.to_dict()

        headers = {
            'Content-Type': 'application/json',
            'Accept': 'application/json',
            'x-delbank-api-key': self.client.get_api_key(),
            'x-delfinance-account-id': self.client.get_account_id(),
            'IdempotencyKey': idempotency_key
        }

        # Setup mTLS if configured
        cert = None
        if self.client.get_certificate_path() and self.client.get_private_key_path():
            cert = (self.client.get_certificate_path(), self.client.get_private_key_path())

        try:
            response = requests.delete(
                url, 
                json=payload,
                headers=headers, 
                cert=cert,
                timeout=30
            )
            
            if response.status_code >= 400:
                raise Exception(f"API Error: {response.text}", response.status_code)
            
            return None
            
        except requests.exceptions.RequestException as e:
            raise Exception(f"Request Error: {str(e)}")

    def get_pix_keys(self) -> GetPixKeysResponse:
        """
        List all Pix Keys.
        """
        url = f"{self.client.get_base_url()}/baas/api/v1/pix/dict/entries"
        
        headers = {
            'Content-Type': 'application/json',
            'Accept': 'application/json',
            'x-delbank-api-key': self.client.get_api_key(),
            'x-delfinance-account-id': self.client.get_account_id(),
        }

        # Setup mTLS if configured
        cert = None
        if self.client.get_certificate_path() and self.client.get_private_key_path():
            cert = (self.client.get_certificate_path(), self.client.get_private_key_path())

        try:
            response = requests.get(
                url, 
                headers=headers, 
                cert=cert,
                timeout=30
            )
            
            if response.status_code >= 400:
                raise Exception(f"API Error: {response.text}", response.status_code)
            
            data = response.json()
            return GetPixKeysResponse(data)
            
        except requests.exceptions.RequestException as e:
            raise Exception(f"Request Error: {str(e)}")

    def generate_auth_code(self, request: GenerateAuthCodeRequest) -> GenerateAuthCodeResponse:
        """
        Generates an Auth Code for email/phone Pix keys.
        """
        url = f"{self.client.get_base_url()}/baas/api/v1/pix/dict/auth-code"
        
        payload = request.to_dict()

        headers = {
            'Content-Type': 'application/json',
            'Accept': 'application/json',
            'x-delbank-api-key': self.client.get_api_key(),
            'x-delfinance-account-id': self.client.get_account_id()
        }

        # Setup mTLS if configured
        cert = None
        if self.client.get_certificate_path() and self.client.get_private_key_path():
            cert = (self.client.get_certificate_path(), self.client.get_private_key_path())

        try:
            response = requests.post(
                url, 
                json=payload,
                headers=headers, 
                cert=cert,
                timeout=30
            )
            
            if response.status_code >= 400:
                raise Exception(f"API Error: {response.text}", response.status_code)
            
            data = response.json()
            return GenerateAuthCodeResponse(data)
            
        except requests.exceptions.RequestException as e:
            raise Exception(f"Request Error: {str(e)}")
