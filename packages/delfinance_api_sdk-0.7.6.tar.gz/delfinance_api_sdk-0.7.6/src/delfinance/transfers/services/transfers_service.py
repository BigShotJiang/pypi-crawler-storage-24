import requests
import json
from typing import Optional
from ...abstractions.startup.delfinance_client import DelfinanceClient
from ..interfaces.itransfers_service import ITransfersService
from ..responses.get_transfer_response import GetTransferResponse
from ..responses.create_transfer_response import CreateTransferResponse
from ..responses.create_ted_transfer_response import CreateTedTransferResponse
from ..requests.create_transfer_request import CreateTransferRequest
from ..requests.create_ted_transfer_request import CreateTedTransferRequest


class TransfersService(ITransfersService):
    def __init__(self, client: DelfinanceClient):
        self.client = client

    def _get_headers(self, idempotency_key=None):
        headers = {
            'Content-Type': 'application/json',
            'Accept': 'application/json',
            'x-delbank-api-key': self.client.get_api_key(),
            'x-delfinance-account-id': self.client.get_account_id(),
        }
        if idempotency_key:
            headers['IdempotencyKey'] = idempotency_key
        return headers

    def _get_cert(self):
        if self.client.get_certificate_path() and self.client.get_private_key_path():
            return (self.client.get_certificate_path(), self.client.get_private_key_path())
        return None

    def get_transfer(self, transfer_identifier: str) -> GetTransferResponse:
        url = f"{self.client.get_base_url()}/baas/api/v2/transfers/{transfer_identifier}"

        try:
            response = requests.get(
                url,
                headers=self._get_headers(),
                cert=self._get_cert(),
                timeout=30
            )

            if response.status_code >= 400:
                raise Exception(f"API Error: {response.text}", response.status_code)

            data = response.json()
            return GetTransferResponse(data)

        except requests.exceptions.RequestException as e:
            raise Exception(f"Request Error: {str(e)}")

    def create_transfer(self, request: CreateTransferRequest,
                        idempotency_key: Optional[str] = None) -> CreateTransferResponse:
        url = f"{self.client.get_base_url()}/baas/api/v2/transfers"

        try:
            response = requests.post(
                url,
                json=request.to_body_request(),
                headers=self._get_headers(idempotency_key),
                cert=self._get_cert(),
                timeout=30
            )

            if response.status_code >= 400:
                raise Exception(f"API Error: {response.text}", response.status_code)

            data = response.json()
            return CreateTransferResponse(data)

        except requests.exceptions.RequestException as e:
            raise Exception(f"Request Error: {str(e)}")

    def create_ted_transfer(self, request: CreateTedTransferRequest,
                            idempotency_key: Optional[str] = None) -> CreateTedTransferResponse:
        url = f"{self.client.get_base_url()}/baas/api/v2/transfers/ted"

        try:
            response = requests.post(
                url,
                json=request.to_body_request(),
                headers=self._get_headers(idempotency_key),
                cert=self._get_cert(),
                timeout=30
            )

            if response.status_code >= 400:
                raise Exception(f"API Error: {response.text}", response.status_code)

            data = response.json()
            return CreateTedTransferResponse(data)

        except requests.exceptions.RequestException as e:
            raise Exception(f"Request Error: {str(e)}")