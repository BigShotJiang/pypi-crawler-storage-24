from abc import ABC, abstractmethod
from ..responses.get_transfer_response import GetTransferResponse
from ..responses.create_transfer_response import CreateTransferResponse
from ..responses.create_ted_transfer_response import CreateTedTransferResponse
from ..requests.create_transfer_request import CreateTransferRequest
from ..requests.create_ted_transfer_request import CreateTedTransferRequest

from typing import Optional

class ITransfersService(ABC):
    @abstractmethod
    def get_transfer(self, transfer_identifier: str) -> GetTransferResponse:
        pass

    @abstractmethod
    def create_transfer(self, request: CreateTransferRequest, idempotency_key: Optional[str] = None) -> CreateTransferResponse:
        pass

    @abstractmethod
    def create_ted_transfer(self, request: CreateTedTransferRequest, idempotency_key: Optional[str] = None) -> CreateTedTransferResponse:
        pass