from typing import Dict, Any

class BeneficiaryHolder:
    def __init__(self, name: str, document: str):
        self.name = name
        self.document = document

    def to_body_request(self) -> Dict[str, Any]:
        return {
            'name': self.name,
            'document': self.document
        }

class Beneficiary:
    def __init__(
        self,
        participant_ispb: str,
        branch: str,
        number: str,
        holder: BeneficiaryHolder,
        account_type: str
    ):
        self.participant_ispb = participant_ispb
        self.branch = branch
        self.number = number
        self.holder = holder
        self.account_type = account_type

    def to_body_request(self) -> Dict[str, Any]:
        return {
            'participantIspb': self.participant_ispb,
            'branch': self.branch,
            'number': self.number,
            'holder': self.holder.to_body_request(),
            'type': self.account_type
        }
