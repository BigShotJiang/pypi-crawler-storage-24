from typing import Optional, Dict, Any

class Balance:
    def __init__(self, data: Dict[str, Any]):
        self.balance_previous: Optional[float] = data.get('balancePrevious')
        self.current_balance: Optional[float] = data.get('currentBalance')
        self.low_warning_limit: Optional[float] = data.get('lowWarningLimit')
