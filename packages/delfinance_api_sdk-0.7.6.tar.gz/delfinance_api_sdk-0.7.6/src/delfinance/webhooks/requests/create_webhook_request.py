from typing import Optional

class CreateWebhookRequest:
    """
    Request object for creating or updating a Webhook.
    """
    def __init__(
        self,
        event_type: str,
        url: str,
        authorization_scheme: Optional[str] = None,
        authorization: Optional[str] = None
    ):
        """
        :param event_type: Required. Event type to be monitored (e.g. 'TRANSFER_IN_INTERNAL', 'PIX_CASH_IN').
        :param url: Required. Client API URL to receive the webhook.
        :param authorization_scheme: Optional. BASIC, BEARER, or HEADER.
        :param authorization: Optional. Authorization content (token, user:pass, etc).
        """
        self.event_type = event_type
        self.url = url
        self.authorization_scheme = authorization_scheme
        self.authorization = authorization

    def to_dict(self) -> dict:
        data = {
            'eventType': self.event_type,
            'url': self.url
        }
        if self.authorization_scheme:
            data['authorizationScheme'] = self.authorization_scheme
        if self.authorization:
            data['authorization'] = self.authorization
        return data
