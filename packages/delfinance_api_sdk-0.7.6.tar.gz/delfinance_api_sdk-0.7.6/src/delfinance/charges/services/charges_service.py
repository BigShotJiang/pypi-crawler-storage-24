import requests
from typing import List
from io import BytesIO
from ...abstractions.startup.delfinance_client import DelfinanceClient
from ..interfaces.icharges_service import IChargesService
from ..requests.create_charge_request import CreateChargeRequest
from ..requests.list_charges_by_period_request import ListChargesByPeriodRequest
from ..requests.bill_payments_request import BillPaymentsRequest
from ..responses.charge_response import ChargeResponse
from ..responses.validate_payment_details_response import ValidatePaymentDetailsResponse
from ..responses.bill_payment_response import BillPaymentResponse

class ChargesService(IChargesService):
    """
    Class ChargesService
    """
    def __init__(self, client: DelfinanceClient):
        self.client = client

    def _get_headers(self, idempotency_key: str = None):
        headers = {
            'Content-Type': 'application/json',
            'Accept': 'application/json',
            'x-delbank-api-key': self.client.get_api_key(),
            'x-delfinance-account-id': self.client.get_account_id(),
        }
        if idempotency_key:
            headers['x-idempotency-key'] = idempotency_key
        return headers

    def _get_cert(self):
        if self.client.get_certificate_path() and self.client.get_private_key_path():
            return (self.client.get_certificate_path(), self.client.get_private_key_path())
        return None

    def create_charge(self, request: CreateChargeRequest) -> ChargeResponse:
        url = f"{self.client.get_base_url()}/baas/v1/charges"
        try:
            response = requests.post(
                url,
                json=request.to_body_request(),
                headers=self._get_headers(),
                cert=self._get_cert(),
                timeout=30
            )
            if response.status_code >= 400:
                raise Exception(f"API Error: {response.text}", response.status_code)
            return ChargeResponse(response.json())
        except requests.exceptions.RequestException as e:
            raise Exception(f"Request Error: {str(e)}")

    def get_charge_by_id(self, correlation_id: str) -> ChargeResponse:
        url = f"{self.client.get_base_url()}/baas/v1/charges/{correlation_id}"
        try:
            response = requests.get(
                url,
                headers=self._get_headers(),
                cert=self._get_cert(),
                timeout=30
            )
            if response.status_code >= 400:
                raise Exception(f"API Error: {response.text}", response.status_code)
            return ChargeResponse(response.json())
        except requests.exceptions.RequestException as e:
            raise Exception(f"Request Error: {str(e)}")

    def list_charges_by_period(self, request: ListChargesByPeriodRequest) -> List[ChargeResponse]:
        url = f"{self.client.get_base_url()}/baas/v1/charges"
        try:
            response = requests.get(
                url,
                params=request.to_body_request() if request else None,
                headers=self._get_headers(),
                cert=self._get_cert(),
                timeout=30
            )
            if response.status_code >= 400:
                raise Exception(f"API Error: {response.text}", response.status_code)
            data = response.json()
            return [ChargeResponse(item) for item in data]
        except requests.exceptions.RequestException as e:
            raise Exception(f"Request Error: {str(e)}")

    def download_charge_pdf(self, id: str) -> BytesIO:
        url = f"{self.client.get_base_url()}/baas/v1/charges/{id}/stream"
        try:
            response = requests.get(
                url,
                headers=self._get_headers(),
                cert=self._get_cert(),
                timeout=30,
                stream=True
            )
            if response.status_code >= 400:
                raise Exception(f"API Error: {response.text}", response.status_code)
            return BytesIO(response.content)
        except requests.exceptions.RequestException as e:
            raise Exception(f"Request Error: {str(e)}")

    def update_charge(self, correlation_id: str, request: CreateChargeRequest):
        url = f"{self.client.get_base_url()}/baas/v1/charges/{correlation_id}"
        try:
            response = requests.patch(
                url,
                json=request.to_body_request(),
                headers=self._get_headers(),
                cert=self._get_cert(),
                timeout=30
            )
            if response.status_code >= 400:
                raise Exception(f"API Error: {response.text}", response.status_code)
            return response.json() if response.content else None
        except requests.exceptions.RequestException as e:
            raise Exception(f"Request Error: {str(e)}")

    def void_charge(self, correlation_id: str):
        url = f"{self.client.get_base_url()}/baas/v1/charges/{correlation_id}/void"
        try:
            response = requests.post(
                url,
                headers=self._get_headers(),
                cert=self._get_cert(),
                timeout=30
            )
            if response.status_code >= 400:
                raise Exception(f"API Error: {response.text}", response.status_code)
            return response.json() if response.content else None
        except requests.exceptions.RequestException as e:
            raise Exception(f"Request Error: {str(e)}")

    def validate_payment_details(self, barcode_or_digitable_line: str) -> ValidatePaymentDetailsResponse:
        url = f"{self.client.get_base_url()}/baas/api/v1/bill-payments/{barcode_or_digitable_line}"
        try:
            response = requests.get(
                url,
                headers=self._get_headers(),
                cert=self._get_cert(),
                timeout=30
            )
            if response.status_code >= 400:
                raise Exception(f"API Error: {response.text}", response.status_code)
            return ValidatePaymentDetailsResponse(response.json())
        except requests.exceptions.RequestException as e:
            raise Exception(f"Request Error: {str(e)}")

    def bill_payment(self, request: BillPaymentsRequest, idempotency_key: str) -> BillPaymentResponse:
        url = f"{self.client.get_base_url()}/baas/api/v1/bill-payments"
        try:
            response = requests.post(
                url,
                json=request.to_body_request(),
                headers=self._get_headers(idempotency_key=idempotency_key),
                cert=self._get_cert(),
                timeout=30
            )
            if response.status_code >= 400:
                raise Exception(f"API Error: {response.text}", response.status_code)
            return BillPaymentResponse(response.json())
        except requests.exceptions.RequestException as e:
            raise Exception(f"Request Error: {str(e)}")