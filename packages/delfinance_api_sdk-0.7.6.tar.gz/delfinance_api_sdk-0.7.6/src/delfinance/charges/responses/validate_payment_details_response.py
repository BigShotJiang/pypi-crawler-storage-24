from typing import Optional, Dict, Any, List

class ValidatePaymentDetailsResponse:
    def __init__(self, data: Dict[str, Any]):
        self.identifier_number: Optional[str] = data.get('identifierNumber')
        self.type: Optional[str] = data.get('type')
        self.is_paid: Optional[bool] = data.get('isPaid')
        self.status: Optional[str] = data.get('status')
        self.amount: Optional[float] = data.get('amount')
        self.due_date: Optional[str] = data.get('dueDate')
        self.payment_deadline: Optional[str] = data.get('paymentDeadline')
        self.bar_code: Optional[str] = data.get('barCode')
        self.digitable_line: Optional[str] = data.get('digitableLine')
        self.is_allow_partial_payment: Optional[bool] = data.get('isAllowPartialPayment')
        self.is_payment_blocked: Optional[bool] = data.get('isPaymentBlocked')
        self.payment_calculation: Optional[Dict[str, Any]] = data.get('paymentCalculation')
        self.payer: Optional[Dict[str, Any]] = data.get('payer')
        self.overdue_payment_interest: Optional[Dict[str, Any]] = data.get('overduePaymentInterest')
        self.overdue_payment_fine: Optional[Dict[str, Any]] = data.get('overduePaymentFine')
        self.discounts: Optional[List[Dict[str, Any]]] = data.get('discounts')
        self.beneficiary: Optional[Dict[str, Any]] = data.get('beneficiary')
        self.issuer: Optional[Dict[str, Any]] = data.get('issuer')

