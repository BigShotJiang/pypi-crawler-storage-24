from abc import ABC, abstractmethod
from typing import List
from io import BytesIO
from ..requests.create_charge_request import CreateChargeRequest
from ..requests.bill_payments_request import BillPaymentsRequest
from ..requests.list_charges_by_period_request import ListChargesByPeriodRequest
from ..responses.charge_response import ChargeResponse
from ..responses.bill_payment_response import BillPaymentResponse
from ..responses.validate_payment_details_response import ValidatePaymentDetailsResponse

class IChargesService(ABC):
    """
    Interface IChargesService
    """
    @abstractmethod
    def create_charge(self, request: CreateChargeRequest) -> ChargeResponse:
        pass

    @abstractmethod
    def get_charge_by_id(self, correlation_id: str) -> ChargeResponse:
        pass

    @abstractmethod
    def list_charges_by_period(self, request: ListChargesByPeriodRequest) -> List[ChargeResponse]:
        pass

    @abstractmethod
    def download_charge_pdf(self, id: str) -> BytesIO:
        pass

    @abstractmethod
    def update_charge(self, correlation_id: str, request: CreateChargeRequest):
        pass

    @abstractmethod
    def void_charge(self, correlation_id: str):
        pass

    @abstractmethod
    def validate_payment_details(self, barcode_or_digitable_line: str) -> ValidatePaymentDetailsResponse:
        pass

    @abstractmethod
    def bill_payment(self, request: BillPaymentsRequest, idempotency_key: str) -> BillPaymentResponse:
        pass
