from typing import Dict, Any, Optional

class QrCodePaymentDTO:
    def __init__(
        self,
        end_to_end_id: Optional[str] = None,
        correlation_id: Optional[str] = None,
        amount: Optional[float] = None,
        created_at: Optional[str] = None,
        proof: Optional[Dict[str, Any]] = None
    ):
        self.end_to_end_id = end_to_end_id
        self.correlation_id = correlation_id
        self.amount = amount
        self.created_at = created_at
        self.proof = proof

    def to_dict(self) -> Dict[str, Any]:
        data = {}
        if self.end_to_end_id is not None:
            data['endToEndId'] = self.end_to_end_id
        if self.correlation_id is not None:
            data['correlationId'] = self.correlation_id
        if self.amount is not None:
            data['amount'] = self.amount
        if self.created_at is not None:
            data['createdAt'] = self.created_at
        if self.proof is not None:
            data['proof'] = self.proof
        return data
