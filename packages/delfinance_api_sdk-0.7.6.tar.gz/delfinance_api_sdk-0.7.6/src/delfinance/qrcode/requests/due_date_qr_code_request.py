from typing import Optional, Dict, Any, List, Union
from ..dtos.address_dto import AddressDTO

class DueDateQrCodeRequest:
    def __init__(
        self,
        correlation_id: str = None,
        amount: float = None,
        pix_key: Optional[str] = None,
        payer: Dict[str, Any] = None,
        address: Union[AddressDTO, Dict[str, Any]] = None,
        due_date: str = None,
        format_response: str = None,
        revision: int = None,
        reusable: bool = None,
        max_days_overdue: int = None,
        additional_infos: Optional[List[Dict[str, Any]]] = None,
        taxes: Optional[Dict[str, Any]] = None,
        **kwargs
    ):
        self.correlation_id = correlation_id
        self.amount = amount
        self.pix_key = pix_key
        self.payer = payer
        self.address = address
        self.due_date = due_date
        self.format_response = format_response
        self.revision = revision
        self.reusable = reusable
        self.max_days_overdue = max_days_overdue
        self.additional_infos = additional_infos
        self.taxes = taxes

    def to_body_request(self) -> Dict[str, Any]:
        data = {}
        if self.correlation_id:
            data['correlationId'] = self.correlation_id
        if self.amount:
            data['amount'] = self.amount
        if self.payer:
            data['payer'] = self.payer
        if self.address:
            data['address'] = self.address.to_dict() if hasattr(self.address, 'to_dict') else self.address
        if self.due_date:
            data['dueDate'] = self.due_date
        if self.format_response:
            data['formatResponse'] = self.format_response
        if self.revision is not None:
            data['revision'] = self.revision
        if self.reusable is not None:
            data['reusable'] = self.reusable
        if self.max_days_overdue is not None:
            data['maxDaysOverdue'] = self.max_days_overdue
        if self.pix_key:
            data['pixKey'] = self.pix_key
        if self.taxes:
            data['taxes'] = self.taxes
        if self.additional_infos:
            data['additionalInfos'] = self.additional_infos
        return data
