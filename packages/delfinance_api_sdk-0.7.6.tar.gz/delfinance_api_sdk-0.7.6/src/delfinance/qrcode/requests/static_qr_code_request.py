from typing import Optional, Dict, Any, Union
from ..dtos.address_dto import AddressDTO

class StaticQrCodeRequest:
    def __init__(
        self,
        correlation_id: str = None,
        amount: Optional[float] = None,
        pix_key: Optional[str] = None,
        ispb_pss: Optional[str] = None,
        address: Optional[Union[AddressDTO, Dict[str, Any]]] = None,
        beneficiary_name: Optional[str] = None,
        additional_info: Optional[str] = None,
        source: str = None,
        format_response: str = None,
        **kwargs
    ):
        self.correlation_id = correlation_id
        self.amount = amount
        self.pix_key = pix_key
        self.ispb_pss = ispb_pss
        self.address = address
        self.beneficiary_name = beneficiary_name
        self.additional_info = additional_info
        self.source = source
        self.format_response = format_response

    def to_body_request(self) -> Dict[str, Any]:
        data = {}
        if self.correlation_id:
            data['correlationId'] = self.correlation_id
        if self.source:
            data['source'] = self.source
        if self.format_response:
            data['formatResponse'] = self.format_response
        if self.amount is not None:
            data['amount'] = self.amount
        if self.pix_key:
            data['pixKey'] = self.pix_key
        if self.ispb_pss:
            data['ispbPss'] = self.ispb_pss
        if self.address:
            data['address'] = self.address.to_dict() if hasattr(self.address, 'to_dict') else self.address
        if self.beneficiary_name:
            data['beneficiaryName'] = self.beneficiary_name
        if self.additional_info:
            data['additionalInfo'] = self.additional_info
        return data
