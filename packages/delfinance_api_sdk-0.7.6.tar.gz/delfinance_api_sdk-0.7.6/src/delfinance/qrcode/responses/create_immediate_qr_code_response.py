from typing import Optional, Dict, Any, List

class CreateImmediateQrCodeResponse:
    def __init__(self, data: Dict[str, Any]):
        self.payload_jws: Optional[str] = data.get('payloadJws')
        self.correlation_id: Optional[str] = data.get('correlationId')
        self.transaction_id: Optional[str] = data.get('transactionId')
        self.amount: Optional[float] = data.get('amount')
        self.allow_change_amount: Optional[bool] = data.get('allowChangeAmount')
        self.expires_in: Optional[int] = data.get('expiresIn')
        self.status: Optional[str] = data.get('status')
        self.payer: Optional[Dict[str, Any]] = data.get('payer')
        self.address: Optional[Dict[str, Any]] = data.get('address')
        self.created_at: Optional[str] = data.get('createdAt')
        self.updated_at: Optional[str] = data.get('updatedAt')
        self.expires_at: Optional[str] = data.get('expiresAt')
        self.payload_pix: Optional[str] = data.get('payloadPix')
        self.qr_code_image_base64: Optional[str] = data.get('qrCodeImageBase64')
        self.additional_infos: Optional[List[Any]] = data.get('additionalInfos')
        self.split_instructions: Optional[List[Any]] = data.get('splitInstructions')
