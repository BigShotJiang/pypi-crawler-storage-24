import requests
import json
from typing import List
from ...abstractions.startup.delfinance_client import DelfinanceClient
from ..interfaces.iqr_code_service import IQrCodeService
from ..requests.static_qr_code_request import StaticQrCodeRequest
from ..requests.due_date_qr_code_request import DueDateQrCodeRequest
from ..requests.immediate_qr_code_request import ImmediateQrCodeRequest
from ..responses.create_static_qr_code_response import CreateStaticQrCodeResponse
from ..responses.create_due_date_qr_code_response import CreateDueDateQrCodeResponse
from ..responses.create_immediate_qr_code_response import CreateImmediateQrCodeResponse
from ..responses.get_qr_code_response import GetQrCodeResponse
from ..responses.qr_code_payment_response import QrCodePaymentResponse

class QrCodeService(IQrCodeService):
    """
    Class QrCodeService
    """
    def __init__(self, client: DelfinanceClient):
        self.client = client

    def _get_headers(self):
        return {
            'Content-Type': 'application/json',
            'Accept': 'application/json',
            'x-delbank-api-key': self.client.get_api_key(),
            'x-delfinance-account-id': self.client.get_account_id(),
        }

    def _get_cert(self):
        if self.client.get_certificate_path() and self.client.get_private_key_path():
            return (self.client.get_certificate_path(), self.client.get_private_key_path())
        return None

    def cancel_due_date_qr_code(self, id: str):
        url = f"{self.client.get_base_url()}/baas/api/v2/pix/qrcode/dynamic/due-date/{id}/cancel"
        try:
            response = requests.patch(
                url,
                headers=self._get_headers(),
                cert=self._get_cert(),
                timeout=30
            )
            if response.status_code >= 400:
                raise Exception(f"API Error: {response.text}", response.status_code)
            return response.json() if response.content else None
        except requests.exceptions.RequestException as e:
            raise Exception(f"Request Error: {str(e)}")

    def cancel_immediate_qr_code(self, id: str):
        url = f"{self.client.get_base_url()}/baas/api/v2/pix/qrcode/dynamic/immediate-payment/{id}/cancel"
        try:
            response = requests.patch(
                url,
                headers=self._get_headers(),
                cert=self._get_cert(),
                timeout=30
            )
            if response.status_code >= 400:
                raise Exception(f"API Error: {response.text}", response.status_code)
            return response.json() if response.content else None
        except requests.exceptions.RequestException as e:
            raise Exception(f"Request Error: {str(e)}")

    def cancel_static_qr_code(self, transaction_identifier: str):
        url = f"{self.client.get_base_url()}/baas/api/v2/pix/qrcode/static/{transaction_identifier}/cancel"
        try:
            response = requests.patch(
                url,
                headers=self._get_headers(),
                cert=self._get_cert(),
                timeout=30
            )
            if response.status_code >= 400:
                raise Exception(f"API Error: {response.text}", response.status_code)
            return response.json() if response.content else None
        except requests.exceptions.RequestException as e:
            raise Exception(f"Request Error: {str(e)}")

    def get_static_qr_code_payments(self, identifier: str) -> List[QrCodePaymentResponse]:
        url = f"{self.client.get_base_url()}/baas/api/v2/pix/qrcode/static/{identifier}/payments"
        try:
            response = requests.get(
                url,
                headers=self._get_headers(),
                cert=self._get_cert(),
                timeout=30
            )
            if response.status_code >= 400:
                raise Exception(f"API Error: {response.text}", response.status_code)
            
            data = response.json()
            # Assuming data is a list
            return [QrCodePaymentResponse(item) for item in data]
        except requests.exceptions.RequestException as e:
            raise Exception(f"Request Error: {str(e)}")

    def get_due_date_qr_code(self, id: str) -> GetQrCodeResponse:
        url = f"{self.client.get_base_url()}/baas/api/v2/pix/qrcode/due-date/{id}"
        try:
            response = requests.get(
                url,
                headers=self._get_headers(),
                cert=self._get_cert(),
                timeout=30
            )
            if response.status_code >= 400:
                raise Exception(f"API Error: {response.text}", response.status_code)
            
            data = response.json()
            return GetQrCodeResponse(data)
        except requests.exceptions.RequestException as e:
            raise Exception(f"Request Error: {str(e)}")

    def get_immediate_qr_code(self, id: str) -> GetQrCodeResponse:
        url = f"{self.client.get_base_url()}/baas/api/v2/pix/qrcode/dynamic/{id}"
        try:
            response = requests.get(
                url,
                headers=self._get_headers(),
                cert=self._get_cert(),
                timeout=30
            )
            if response.status_code >= 400:
                raise Exception(f"API Error: {response.text}", response.status_code)
            
            data = response.json()
            return GetQrCodeResponse(data)
        except requests.exceptions.RequestException as e:
            raise Exception(f"Request Error: {str(e)}")

    def get_static_qr_code(self, transaction_identifier: str) -> GetQrCodeResponse:
        url = f"{self.client.get_base_url()}/baas/api/v2/pix/qrcode/static/{transaction_identifier}"
        try:
            response = requests.get(
                url,
                headers=self._get_headers(),
                cert=self._get_cert(),
                timeout=30
            )
            if response.status_code >= 400:
                raise Exception(f"API Error: {response.text}", response.status_code)
            
            data = response.json()
            return GetQrCodeResponse(data)
        except requests.exceptions.RequestException as e:
            raise Exception(f"Request Error: {str(e)}")

    def create_static_qr_code(self, request: StaticQrCodeRequest) -> CreateStaticQrCodeResponse:
        url = f"{self.client.get_base_url()}/baas/api/v2/pix/qrcode/static"
        try:
            response = requests.post(
                url,
                json=request.to_body_request(),
                headers=self._get_headers(),
                cert=self._get_cert(),
                timeout=30
            )
            if response.status_code >= 400:
                raise Exception(f"API Error: {response.text}", response.status_code)
            
            data = response.json()
            return CreateStaticQrCodeResponse(data)
        except requests.exceptions.RequestException as e:
            raise Exception(f"Request Error: {str(e)}")

    def create_due_date_qr_code(self, request: DueDateQrCodeRequest) -> CreateDueDateQrCodeResponse:
        url = f"{self.client.get_base_url()}/baas/api/v2/pix/qrcode/due-date"
        try:
            response = requests.post(
                url,
                json=request.to_body_request(),
                headers=self._get_headers(),
                cert=self._get_cert(),
                timeout=30
            )
            if response.status_code >= 400:
                raise Exception(f"API Error: {response.text}", response.status_code)
            
            data = response.json()
            return CreateDueDateQrCodeResponse(data)
        except requests.exceptions.RequestException as e:
            raise Exception(f"Request Error: {str(e)}")

    def create_immediate_qr_code(self, request: ImmediateQrCodeRequest) -> CreateImmediateQrCodeResponse:
        url = f"{self.client.get_base_url()}/baas/api/v2/pix/qrcode/dynamic"
        try:
            response = requests.post(
                url,
                json=request.to_body_request(),
                headers=self._get_headers(),
                cert=self._get_cert(),
                timeout=30
            )
            if response.status_code >= 400:
                raise Exception(f"API Error: {response.text}", response.status_code)
            
            data = response.json()
            return CreateImmediateQrCodeResponse(data)
        except requests.exceptions.RequestException as e:
            raise Exception(f"Request Error: {str(e)}")
