"""Velar Python SDK - Deploy ML models to GPUs with one command."""

from velar.app import App
from velar.decorators import function, endpoint
from velar.deployment import Deployment
from velar.image import Image
from velar.serialization import serialize, deserialize
from velar.client import RemoteExecutionError
from velar import gpu

__all__ = ["App", "Deployment", "function", "endpoint", "gpu", "Image", "serialize", "deserialize", "RemoteExecutionError"]
__version__ = "0.4.5"
