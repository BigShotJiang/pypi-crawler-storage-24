"""
Interactive Canvas Widget for CustomTkinter

Provides a canvas with built-in support for draggable rectangles, multi-selection,
drag-to-select, panning, and keyboard shortcuts.

Author: Tchicdje Kouojip Joram Smith (DeltaGa)
Created: Tue Aug 6, 2024
"""

import contextlib
from collections.abc import Callable
from tkinter import Canvas as TkCanvas
from tkinter import Event
from typing import Any, cast

import customtkinter as ctk

from .draggable_rectangle import DraggableRectangle


class InteractiveCanvas(ctk.CTkCanvas):
    """
    Extended CTkCanvas with interactive selection and manipulation features.

    Supports:
    - Multi-selection (shift-click, drag-select)
    - Panning (middle mouse or space + drag)
    - Keyboard shortcuts (Delete key)
    - Callbacks for selection events
    - Dynamic callback system via register_callback() / unregister_callback()

    Dynamic Callback System
    -----------------------
    Every public interaction method is a hookable point.  Use
    ``register_callback(hook_name, fn, mode)`` to intercept it:

    * mode="before"   — fires *before* the built-in logic
    * mode="after"    — fires *after* the built-in logic (default)
    * mode="inplace"  — *replaces* the built-in logic entirely

    Rectangle-level hooks (``rect_on_*``) receive the originating
    ``DraggableRectangle`` as their first argument, followed by the
    original event arguments.

    Performance: the registry is a plain ``dict``.  When no callbacks are
    registered for a hook, ``_dispatch`` short-circuits after a single
    O(1) ``dict.__contains__`` check — zero overhead on hot paths such as
    ``rect_on_drag`` / ``rect_on_resize_drag`` (~60 Hz).

    All valid hook names are listed in ``InteractiveCanvas._HOOKABLE_METHODS``.
    """

    _HOOKABLE_METHODS: frozenset[str] = frozenset(
        {
            # Canvas-level hooks
            "on_click",
            "on_drag_select",
            "on_drag_release",
            "on_middle_click",
            "on_middle_drag",
            "on_middle_release",
            "on_space_press",
            "on_space_release",
            "on_delete",
            "update_selection_area",
            "toggle_selection",
            "select_item",
            "select_all",
            "deselect_item",
            "deselect_all",
            "create_draggable_rectangle",
            "copy_draggable_rectangle",
            "delete_draggable_rectangle",
            "zoom_in",
            "zoom_out",
            "on_zoom_wheel",
            "attach_text_to_rectangle",
            "move_attached_items",
            "undo",
            "redo",
            # Rectangle-level hooks (dispatched via _dispatch_rect)
            "rect_on_click",
            "rect_on_drag",
            "rect_on_drag_end",
            "rect_on_resize_click",
            "rect_on_resize_drag",
            "rect_on_resize_end",
        }
    )

    def __init__(
        self,
        master: Any | None = None,
        select_callback: Callable[[], None] | None = None,
        deselect_callback: Callable[[], None] | None = None,
        delete_callback: Callable[..., None] | None = None,
        select_outline_color: str = "#16fff6",
        dpi: int = 300,
        create_bindings: bool = True,
        enable_history: bool = True,
        enable_zoom: bool = True,
        **kwargs: Any,
    ) -> None:
        """
        Initialize an InteractiveCanvas.

        Args:
            master: Parent widget
            select_callback: Called when objects are selected
            deselect_callback: Called when objects are deselected
            delete_callback: Called when Delete key is pressed (overrides default).
                             May accept zero or one (event) argument.
            select_outline_color: Color for selected object outlines
            dpi: Dots per inch for coordinate conversions
            create_bindings: Whether to create default mouse/keyboard bindings
            enable_history: Enable undo/redo functionality (default: True)
            enable_zoom: Enable zoom functionality (default: True)
            **kwargs: Additional arguments passed to CTkCanvas
        """
        super().__init__(master, **kwargs)

        self.select_callback = select_callback if select_callback is not None else lambda: None
        self.deselect_callback = (
            deselect_callback if deselect_callback is not None else lambda: None
        )
        # Store the raw user-provided delete callback (may be None).
        # We always bind <Delete> to our own _on_delete_key handler,
        # which dispatches to this callback or the default on_delete.
        self._user_delete_callback = delete_callback

        self.select_outline_color = select_outline_color
        self.selected_objects: dict[int, DraggableRectangle] = {}
        self.objects: dict[int, DraggableRectangle] = {}
        self.dpi = dpi

        self.start_x: float | None = None
        self.start_y: float | None = None
        self.selection_rect: int | None = None
        self.dragging: bool = False
        self.panning: bool = False

        self.next_item_id: int = 0

        # Internal flags
        self._suppress_registration: bool = False
        self._restoring_state: bool = False
        self._objects_changed: bool = False

        # Dynamic callback registry: {hook_name: {mode: [(callable, suppress_during_restore)]}}
        self._callbacks: dict[str, dict[str, list[tuple[Callable, bool]]]] = {}

        self.enable_history = enable_history
        self.enable_zoom = enable_zoom

        if self.enable_history:
            self.history_states: list[dict] = []
            self.history_index: int = -1
            self.max_history: int = 50
            # Save the initial empty state so undo can return to empty canvas
            self._save_initial_state()

        if self.enable_zoom:
            self.zoom_level: float = 1.0
            self.min_zoom: float = 0.1
            self.max_zoom: float = 10.0
            self._tracked_images: dict[int, dict] = {}
            # Accumulated canvas origin: canvas_coord = zoom_level * logical_coord + origin.
            # Updated on every zoom_in/zoom_out so that save_state() can normalise
            # rectangle coordinates to zoom=1.0 logical space, and _restore_state()
            # can scale them back to the current zoom, regardless of where each
            # zoom operation was centred.
            self._canvas_origin_x: float = 0.0
            self._canvas_origin_y: float = 0.0

        if create_bindings:
            self._create_bindings()

    # -------------------------------------------------------------------------
    # Callback registry
    # -------------------------------------------------------------------------

    def register_callback(
        self,
        hook_name: str,
        callback: Callable,
        mode: str = "after",
        suppress_during_restore: bool = False,
    ) -> None:
        """
        Register a callback for a hookable method.

        Args:
            hook_name: Name of the hook (must be in ``_HOOKABLE_METHODS``).
            callback: Callable to invoke.  Rectangle-level hooks (``rect_on_*``)
                receive the ``DraggableRectangle`` as their first argument.
            mode: One of:
                * ``"before"``  — called *before* the built-in logic.
                * ``"after"``   — called *after* the built-in logic (default).
                * ``"inplace"`` — *replaces* the built-in logic entirely.
                  Only the first registered inplace callback is used.
            suppress_during_restore: If ``True``, this callback is silenced
                while undo/redo state restoration is in progress.

        Raises:
            ValueError: If ``hook_name`` is not a valid hook or ``mode`` is invalid.
        """
        if hook_name not in self._HOOKABLE_METHODS:
            raise ValueError(
                f"Unknown hook: {hook_name!r}. " f"Valid hooks: {sorted(self._HOOKABLE_METHODS)}"
            )
        if mode not in ("before", "after", "inplace"):
            raise ValueError(f"Invalid mode: {mode!r}. Must be 'before', 'after', or 'inplace'.")
        if hook_name not in self._callbacks:
            self._callbacks[hook_name] = {}
        hook_dict = self._callbacks[hook_name]
        if mode not in hook_dict:
            hook_dict[mode] = []
        hook_dict[mode].append((callback, suppress_during_restore))

    def unregister_callback(
        self,
        hook_name: str,
        callback: Callable,
        mode: str = "after",
    ) -> bool:
        """
        Unregister a previously registered callback.

        When the last callback for a hook is removed, the hook entry is
        deleted from the registry so the zero-overhead fast path is restored.

        Args:
            hook_name: Name of the hook.
            callback: The callable to remove (matched by identity, not equality).
            mode: The mode it was registered under (default: ``"after"``).

        Returns:
            ``True`` if the callback was found and removed, ``False`` otherwise.
        """
        if hook_name not in self._callbacks:
            return False
        hook_dict = self._callbacks[hook_name]
        if mode not in hook_dict:
            return False
        entries = hook_dict[mode]
        for i, (cb, _) in enumerate(entries):
            if cb is callback:
                entries.pop(i)
                if not entries:
                    del hook_dict[mode]
                if not hook_dict:
                    del self._callbacks[hook_name]
                return True
        return False

    def _dispatch(self, hook_name: str, builtin_fn: Callable, *args: Any, **kwargs: Any) -> Any:
        """
        Dispatch a canvas-level hookable method through the callback registry.

        Zero-overhead fast path: when ``hook_name`` has no active callbacks the
        dict lookup short-circuits immediately and ``builtin_fn`` is invoked
        directly, adding no measurable overhead to hot paths.

        Args:
            hook_name: Registry key identifying the hook.
            builtin_fn: Bound built-in implementation (``self._builtin_*``).
            *args: Positional arguments forwarded to callbacks and built-in.
            **kwargs: Keyword arguments forwarded to callbacks and built-in.

        Returns:
            Return value of the built-in (or inplace) function.
        """
        if hook_name not in self._callbacks:
            return builtin_fn(*args, **kwargs)

        hooks = self._callbacks[hook_name]
        restoring = self._restoring_state

        for cb, suppress in hooks.get("before", ()):
            if not (suppress and restoring):
                cb(*args, **kwargs)

        inplace_list = hooks.get("inplace")
        if inplace_list:
            cb, suppress = inplace_list[0]
            result = (
                builtin_fn(*args, **kwargs) if (suppress and restoring) else cb(*args, **kwargs)
            )
        else:
            result = builtin_fn(*args, **kwargs)

        for cb, suppress in hooks.get("after", ()):
            if not (suppress and restoring):
                cb(*args, **kwargs)

        return result

    def _dispatch_rect(
        self,
        hook_name: str,
        rect: "DraggableRectangle",
        builtin_fn: Callable,
        *args: Any,
        **kwargs: Any,
    ) -> Any:
        """
        Dispatch a rectangle-level hookable method through the callback registry.

        Identical semantics to ``_dispatch`` but prepends the originating
        ``DraggableRectangle`` instance as the first argument to every callback,
        so callers can identify which rectangle triggered the event.

        Args:
            hook_name: Registry key identifying the hook.
            rect: The DraggableRectangle that originated the event.
            builtin_fn: Bound built-in on the rectangle (``rect._builtin_*``).
            *args: Event arguments forwarded after ``rect``.
            **kwargs: Keyword arguments forwarded.

        Returns:
            Return value of the built-in (or inplace) function.
        """
        if hook_name not in self._callbacks:
            return builtin_fn(*args, **kwargs)

        hooks = self._callbacks[hook_name]
        restoring = self._restoring_state

        for cb, suppress in hooks.get("before", ()):
            if not (suppress and restoring):
                cb(rect, *args, **kwargs)

        inplace_list = hooks.get("inplace")
        if inplace_list:
            cb, suppress = inplace_list[0]
            result = (
                builtin_fn(*args, **kwargs)
                if (suppress and restoring)
                else cb(rect, *args, **kwargs)
            )
        else:
            result = builtin_fn(*args, **kwargs)

        for cb, suppress in hooks.get("after", ()):
            if not (suppress and restoring):
                cb(rect, *args, **kwargs)

        return result

    # -------------------------------------------------------------------------
    # Internal helpers (not hookable)
    # -------------------------------------------------------------------------

    def _save_initial_state(self) -> None:
        """Save the initial empty state as history index 0."""
        self.history_states = [{"objects": {}, "next_item_id": 0, "selected": []}]
        self.history_index = 0

    def get_view_center(self) -> list[float]:
        """
        Get the center of the currently visible canvas area.

        Accounts for panning and scrolling by converting widget-space
        coordinates to canvas-space via canvasx/canvasy.

        Returns:
            [x, y] canvas coordinates of the visible center.
        """
        canvas_width = self.winfo_width() if self.winfo_width() > 1 else self.winfo_reqwidth()
        canvas_height = self.winfo_height() if self.winfo_height() > 1 else self.winfo_reqheight()
        return [self.canvasx(canvas_width / 2), self.canvasy(canvas_height / 2)]

    def get_origin_pos(self, reference_item: int) -> list[float]:
        """
        Get the top-left position of a reference canvas item (e.g. a page boundary).

        This mirrors the pattern used in format_editor._canvas_get_origin_pos()
        and is intended to be used as the relative_pos argument for
        DraggableRectangle position methods.

        Args:
            reference_item: Canvas item ID of the reference rectangle.

        Returns:
            [x, y] canvas coordinates of the item's top-left corner.
        """
        coords = self.coords(reference_item)
        return [coords[0], coords[1]]

    def _create_bindings(self) -> None:
        """Create default mouse and keyboard bindings."""
        self.bind("<Button-1>", self.on_click)
        self.bind("<B1-Motion>", self.on_drag_select)
        self.bind("<ButtonRelease-1>", self.on_drag_release)
        self.bind("<ButtonPress-2>", self.on_middle_click)
        self.bind("<B2-Motion>", self.on_middle_drag)
        self.bind("<ButtonRelease-2>", self.on_middle_release)
        self.bind_all("<KeyPress-space>", self.on_space_press)
        self.bind_all("<KeyRelease-space>", self.on_space_release)

        # Always bind Delete to our internal handler, which properly
        # dispatches to the user's callback (handling event-arg mismatch)
        # or to the default on_delete.
        self.bind_all("<Delete>", self._on_delete_key)

        if self.enable_history:
            self.bind_all("<Control-z>", lambda e: self.undo())
            self.bind_all("<Control-Z>", lambda e: self.undo())
            self.bind_all("<Control-y>", lambda e: self.redo())
            self.bind_all("<Control-Y>", lambda e: self.redo())
            self.bind_all("<Control-Shift-z>", lambda e: self.redo())
            self.bind_all("<Control-Shift-Z>", lambda e: self.redo())

        if self.enable_zoom:
            self.bind_all("<plus>", lambda e: self.zoom_in())
            self.bind_all("<equal>", lambda e: self.zoom_in())
            self.bind_all("<minus>", lambda e: self.zoom_out())
            self.bind("<Alt-MouseWheel>", self.on_zoom_wheel)
            self.bind("<Alt-Button-4>", lambda e: self.zoom_in())
            self.bind("<Alt-Button-5>", lambda e: self.zoom_out())

    def _register_rectangle(self, rect: DraggableRectangle) -> None:
        """
        Register a DraggableRectangle with the canvas.

        Called automatically when a DraggableRectangle is instantiated.
        Ensures all rectangles (including those created via magic methods) are tracked.

        During state restoration, auto-registration is suppressed because
        objects are manually inserted with their original IDs.

        Args:
            rect: The DraggableRectangle instance to register
        """
        if self._suppress_registration:
            return
        if rect not in self.objects.values():
            self.objects[self.next_item_id] = rect
            self.next_item_id += 1

    def coords(self, tag_or_id: Any, *args: Any) -> Any:
        if isinstance(tag_or_id, str) and "ctk_aa_circle_font_element" in self.gettags(tag_or_id):
            coords_id = self.find_withtag(tag_or_id)[0]
            coords = TkCanvas.coords(self, coords_id, *args[:2])
            if len(args) == 3:
                TkCanvas.itemconfigure(
                    self,
                    coords_id,
                    font=("CustomTkinter_shapes_font", -int(args[2]) * 2),
                    text=self._get_char_from_radius(args[2]),
                )
        elif isinstance(tag_or_id, int) and tag_or_id in self._aa_circle_canvas_ids:
            coords = TkCanvas.coords(self, tag_or_id, *args[:2])

            if len(args) == 3:
                TkCanvas.itemconfigure(
                    self,
                    tag_or_id,
                    font=("CustomTkinter_shapes_font", -args[2] * 2),
                    text=self._get_char_from_radius(args[2]),
                )
        else:
            coords = TkCanvas.coords(self, tag_or_id, *args)
            if not coords:
                return [0, 0, 0, 0]
        return coords

    @staticmethod
    def _get_key_by_value(dictionary: dict[Any, Any], value: Any) -> Any | None:
        """
        Find the first key corresponding to a value in a dictionary.

        Args:
            dictionary: The dictionary to search
            value: The value to find

        Returns:
            The corresponding key, or None if not found
        """
        for key, val in dictionary.items():
            if val == value:
                return key
        return None

    # -------------------------------------------------------------------------
    # Rectangle creation / copy / deletion
    # -------------------------------------------------------------------------

    def create_draggable_rectangle(
        self,
        x1: float,
        y1: float,
        x2: float,
        y2: float,
        offset: list[int] | None = None,
        max_repetitions: int = 20,
        center_on_canvas: bool = False,
        **kwargs: Any,
    ) -> DraggableRectangle:
        """
        Create a draggable rectangle on the canvas.

        Automatically offsets position if overlapping with existing rectangles.

        Args:
            x1: Top-left x coordinate
            y1: Top-left y coordinate
            x2: Bottom-right x coordinate
            y2: Bottom-right y coordinate
            offset: [dx, dy] offset for overlap avoidance (default: [21, 21])
            max_repetitions: Maximum attempts to find non-overlapping position
            center_on_canvas: If True, center rectangle on visible canvas area (default: False)
            **kwargs: Additional arguments for DraggableRectangle

        Returns:
            The created DraggableRectangle instance
        """
        return cast(
            DraggableRectangle,
            self._dispatch(
                "create_draggable_rectangle",
                self._builtin_create_draggable_rectangle,
                x1,
                y1,
                x2,
                y2,
                offset=offset,
                max_repetitions=max_repetitions,
                center_on_canvas=center_on_canvas,
                **kwargs,
            ),
        )

    def _builtin_create_draggable_rectangle(
        self,
        x1: float,
        y1: float,
        x2: float,
        y2: float,
        offset: list[int] | None = None,
        max_repetitions: int = 20,
        center_on_canvas: bool = False,
        **kwargs: Any,
    ) -> DraggableRectangle:
        if offset is None:
            offset = [21, 21]

        if center_on_canvas:
            canvas_width = self.winfo_width() if self.winfo_width() > 1 else self.winfo_reqwidth()
            canvas_height = (
                self.winfo_height() if self.winfo_height() > 1 else self.winfo_reqheight()
            )

            rect_width = x2 - x1
            rect_height = y2 - y1

            # Use canvasx/canvasy to get the TRUE visible center,
            # accounting for any panning or scrolling that has occurred.
            center_x = self.canvasx(canvas_width / 2)
            center_y = self.canvasy(canvas_height / 2)

            x1 = center_x - rect_width / 2
            y1 = center_y - rect_height / 2
            x2 = center_x + rect_width / 2
            y2 = center_y + rect_height / 2

        draggable_rect = DraggableRectangle(self, x1, y1, x2, y2, **kwargs)
        repetitions = 0

        while repetitions < max_repetitions:
            topleft_pos = draggable_rect.get_topleft_pos()
            overlap = False
            overlapping_items = self.find_overlapping(
                topleft_pos[0] - 2, topleft_pos[1] - 2, topleft_pos[0] + 2, topleft_pos[1] + 2
            )

            if overlapping_items:
                for obj in self.objects.values():
                    # Exclude the newly created rectangle from overlap detection
                    if obj is draggable_rect:
                        continue
                    if obj.rect in overlapping_items:
                        new_pos = [
                            x1 + offset[0] * (repetitions + 1),
                            y1 + offset[1] * (repetitions + 1),
                        ]
                        draggable_rect.set_topleft_pos(new_pos)
                        overlap = True
                        break

            if not overlap:
                break
            repetitions += 1

        if self.enable_history:
            self.save_state()

        return draggable_rect

    def copy_draggable_rectangle(
        self,
        draggable_rect: DraggableRectangle,
        offset: list[int] | None = None,
        max_repetitions: int = 20,
        **kwargs: Any,
    ) -> DraggableRectangle:
        """
        Create a copy of an existing draggable rectangle.

        Args:
            draggable_rect: Rectangle to copy
            offset: [dx, dy] offset for the copy (default: [21, 21])
            max_repetitions: Maximum attempts to find non-overlapping position
            **kwargs: Override arguments for the copy

        Returns:
            The copied DraggableRectangle instance
        """
        return cast(
            DraggableRectangle,
            self._dispatch(
                "copy_draggable_rectangle",
                self._builtin_copy_draggable_rectangle,
                draggable_rect,
                offset=offset,
                max_repetitions=max_repetitions,
                **kwargs,
            ),
        )

    def _builtin_copy_draggable_rectangle(
        self,
        draggable_rect: DraggableRectangle,
        offset: list[int] | None = None,
        max_repetitions: int = 20,
        **kwargs: Any,
    ) -> DraggableRectangle:
        if offset is None:
            offset = [21, 21]

        new_draggable_rect = draggable_rect.copy_(**kwargs)
        repetitions = 0

        while repetitions < max_repetitions:
            topleft_pos = new_draggable_rect.get_topleft_pos()
            overlap = False
            overlapping_items = self.find_overlapping(
                topleft_pos[0] - 2, topleft_pos[1] - 2, topleft_pos[0] + 2, topleft_pos[1] + 2
            )

            if overlapping_items:
                for obj in self.objects.values():
                    if obj.rect in overlapping_items:
                        new_pos = [
                            topleft_pos[0] + offset[0] * (repetitions + 1),
                            topleft_pos[1] + offset[1] * (repetitions + 1),
                        ]
                        new_draggable_rect.set_topleft_pos(new_pos)
                        overlap = True
                        break

            if not overlap:
                break
            repetitions += 1

        if self.enable_history:
            self.save_state()

        return new_draggable_rect

    def delete_draggable_rectangle(self, item_id: int) -> None:
        """
        Delete a draggable rectangle by its ID.

        Cleans up attached items (text labels, etc.), removes from
        tracking dictionaries, and optionally saves history state.

        Args:
            item_id: The ID of the rectangle to delete
        """
        self._dispatch(
            "delete_draggable_rectangle",
            self._builtin_delete_draggable_rectangle,
            item_id,
        )

    def _builtin_delete_draggable_rectangle(self, item_id: int) -> None:
        if item_id not in self.objects:
            return

        obj = self.objects[item_id]

        # Clean up attached canvas items (text labels, etc.)
        self._delete_attached_items(obj)

        obj.delete()
        del self.objects[item_id]
        if item_id in self.selected_objects:
            del self.selected_objects[item_id]

        # Only fire user callbacks when not restoring state internally
        if not self._restoring_state:
            self.deselect_callback()

    def _delete_attached_items(self, rect: DraggableRectangle) -> None:
        """
        Remove all canvas items attached to a DraggableRectangle.

        Args:
            rect: The rectangle whose attached items should be deleted.
        """
        for attached_id in rect._attached_items:
            self.delete(attached_id)
        rect._attached_items.clear()

    # -------------------------------------------------------------------------
    # Selection
    # -------------------------------------------------------------------------

    def get_selected(self) -> list[DraggableRectangle]:
        """
        Get list of currently selected rectangles.

        Returns:
            List of selected DraggableRectangle instances
        """
        return list(self.selected_objects.values())

    def get_draggable_rectangle(self, item_id: int) -> DraggableRectangle | None:
        """
        Get a draggable rectangle by its ID.

        Args:
            item_id: The ID of the rectangle

        Returns:
            The DraggableRectangle instance or None if not found
        """
        return self.objects.get(item_id)

    def get_item_id(self, draggable_rect: DraggableRectangle) -> int | None:
        """
        Get the ID of a draggable rectangle.

        Args:
            draggable_rect: The rectangle to find

        Returns:
            The item ID or None if not found
        """
        return self._get_key_by_value(self.objects, draggable_rect)

    def update_selection_area(self, x0: float, y0: float, x1: float, y1: float) -> None:
        """
        Update selection based on drag rectangle.

        Args:
            x0: Top-left x of selection rectangle
            y0: Top-left y of selection rectangle
            x1: Bottom-right x of selection rectangle
            y1: Bottom-right y of selection rectangle
        """
        self._dispatch(
            "update_selection_area",
            self._builtin_update_selection_area,
            x0,
            y0,
            x1,
            y1,
        )

    def _builtin_update_selection_area(self, x0: float, y0: float, x1: float, y1: float) -> None:
        selected = self.find_enclosed(x0, y0, x1, y1)
        for item_id, obj in self.objects.items():
            if obj.rect in selected and not obj.get_is_selected():
                self.select_item(item_id)
            elif obj.rect not in selected and obj.get_is_selected():
                self.deselect_item(item_id)

    def toggle_selection(self, item_id: int) -> None:
        """
        Toggle selection state of a rectangle.

        Args:
            item_id: The ID of the rectangle to toggle
        """
        self._dispatch("toggle_selection", self._builtin_toggle_selection, item_id)

    def _builtin_toggle_selection(self, item_id: int) -> None:
        if self.objects[item_id].get_is_selected():
            self.deselect_item(item_id)
        else:
            self.select_item(item_id)

    def select_item(self, item_id: int) -> None:
        """
        Select a rectangle.

        Args:
            item_id: The ID of the rectangle to select
        """
        self._dispatch("select_item", self._builtin_select_item, item_id)

    def _builtin_select_item(self, item_id: int) -> None:
        obj = self.objects[item_id]
        obj.set_is_selected(True)
        self.itemconfig(obj.rect, outline=self.select_outline_color)
        self.selected_objects[item_id] = obj
        self.select_callback()

    def select_all(self) -> None:
        """Select all rectangles on the canvas."""
        self._dispatch("select_all", self._builtin_select_all)

    def _builtin_select_all(self) -> None:
        for item_id in self.objects:
            self.select_item(item_id)

    def deselect_item(self, item_id: int) -> None:
        """
        Deselect a rectangle.

        Args:
            item_id: The ID of the rectangle to deselect
        """
        self._dispatch("deselect_item", self._builtin_deselect_item, item_id)

    def _builtin_deselect_item(self, item_id: int) -> None:
        obj = self.objects[item_id]
        obj.set_is_selected(False)
        self.itemconfig(obj.rect, outline=obj.original_outline)
        if item_id in self.selected_objects:
            del self.selected_objects[item_id]
        self.deselect_callback()

    def deselect_all(self) -> None:
        """Deselect all currently selected rectangles."""
        self._dispatch("deselect_all", self._builtin_deselect_all)

    def _builtin_deselect_all(self) -> None:
        for item_id in list(self.selected_objects):
            self.deselect_item(item_id)

    # -------------------------------------------------------------------------
    # Mouse and keyboard event handlers
    # -------------------------------------------------------------------------

    def on_click(self, event: Event) -> None:
        """Handle left mouse button click."""
        self._dispatch("on_click", self._builtin_on_click, event)

    def _builtin_on_click(self, event: Event) -> None:
        if self.panning:
            self.scan_mark(event.x, event.y)
            return

        shift_pressed = (int(event.state) & 0x0001) != 0
        ctrl_pressed = (int(event.state) & 0x0004) != 0
        canvas_x = self.canvasx(event.x)
        canvas_y = self.canvasy(event.y)
        clicked_items = self.find_overlapping(canvas_x, canvas_y, canvas_x + 1, canvas_y + 1)

        if clicked_items:
            for item_id, obj in self.objects.items():
                if obj.rect in clicked_items:
                    if shift_pressed and not obj.get_is_selected():
                        self.toggle_selection(item_id)
                    elif not shift_pressed and not obj.get_is_selected() or ctrl_pressed:
                        self.deselect_all()
                        self.select_item(item_id)
                    else:
                        if len(self.get_selected()) < 1:
                            self.deselect_all()
                            self.select_item(item_id)
                    return

        self.deselect_all()
        self.dragging = True

    def on_drag_select(self, event: Event) -> None:
        """Handle mouse drag for selection rectangle."""
        self._dispatch("on_drag_select", self._builtin_on_drag_select, event)

    def _builtin_on_drag_select(self, event: Event) -> None:
        if self.panning:
            self.scan_dragto(event.x, event.y, gain=1)
            return

        if not self.dragging:
            return

        canvas_x = self.canvasx(event.x)
        canvas_y = self.canvasy(event.y)

        if self.start_x is None and self.start_y is None:
            clicked_items = self.find_overlapping(canvas_x, canvas_y, canvas_x + 1, canvas_y + 1)
            if any(self.objects[obj_id].rect in clicked_items for obj_id in self.objects):
                return  # Don't start drag selection if clicking on an object

            self.start_x, self.start_y = canvas_x, canvas_y
            self.selection_rect = self.create_rectangle(
                self.start_x,
                self.start_y,
                canvas_x,
                canvas_y,
                outline="black",
                dash=(2, 2),
                fill="",
            )
        else:
            self.coords(self.selection_rect, self.start_x, self.start_y, canvas_x, canvas_y)
            if self.start_x is not None and self.start_y is not None:
                self.update_selection_area(self.start_x, self.start_y, canvas_x, canvas_y)

    def on_drag_release(self, event: Event) -> None:
        """Handle mouse button release after dragging."""
        self._dispatch("on_drag_release", self._builtin_on_drag_release, event)

    def _builtin_on_drag_release(self, event: Event) -> None:
        self.dragging = False
        if self.selection_rect:
            self.delete(self.selection_rect)
            self.selection_rect = None
        self.start_x, self.start_y = None, None

    def on_middle_click(self, event: Event) -> None:
        """Handle middle mouse button press."""
        self._dispatch("on_middle_click", self._builtin_on_middle_click, event)

    def _builtin_on_middle_click(self, event: Event) -> None:
        self.scan_mark(event.x, event.y)

    def on_middle_drag(self, event: Event) -> None:
        """Handle middle mouse button drag."""
        self._dispatch("on_middle_drag", self._builtin_on_middle_drag, event)

    def _builtin_on_middle_drag(self, event: Event) -> None:
        self.scan_dragto(event.x, event.y, gain=1)

    def on_middle_release(self, event: Event) -> None:
        """Handle middle mouse button release."""
        self._dispatch("on_middle_release", self._builtin_on_middle_release, event)

    def _builtin_on_middle_release(self, event: Event) -> None:
        pass

    def on_space_press(self, event: Event) -> None:
        """Handle spacebar press to enable panning mode."""
        self._dispatch("on_space_press", self._builtin_on_space_press, event)

    def _builtin_on_space_press(self, event: Event) -> None:
        self.panning = True

    def on_space_release(self, event: Event) -> None:
        """Handle spacebar release to disable panning mode."""
        self._dispatch("on_space_release", self._builtin_on_space_release, event)

    def _builtin_on_space_release(self, event: Event) -> None:
        self.panning = False

    # -------------------------------------------------------------------------
    # Delete handling (internal dispatcher is not hookable; on_delete is)
    # -------------------------------------------------------------------------

    def _on_delete_key(self, event: Event) -> None:
        """
        Internal handler for the Delete key binding.

        Dispatches to the user-provided delete_callback if set,
        handling the event-argument mismatch gracefully. Falls back
        to the default on_delete if no user callback was provided.

        Args:
            event: The key event from tkinter
        """
        if self._user_delete_callback is not None:
            try:
                self._user_delete_callback(event)
            except TypeError:
                with contextlib.suppress(TypeError):
                    self._user_delete_callback()
        else:
            self.on_delete(event)

    def on_delete(self, event: Event) -> None:
        """
        Default handler for Delete key: remove all selected rectangles.

        Saves history state after deletion so it can be undone.

        Args:
            event: The key event
        """
        self._dispatch("on_delete", self._builtin_on_delete, event)

    def _builtin_on_delete(self, event: Event) -> None:
        selected_items = list(self.selected_objects.keys())
        if not selected_items:
            return

        for item_id in selected_items:
            self.delete_draggable_rectangle(item_id)

        if self.enable_history:
            self.save_state()

    def _on_objects_changed(self) -> None:
        """
        Called by DraggableRectangle on ButtonRelease after a drag or resize.

        If any actual movement or resize occurred (tracked by the
        _objects_changed flag set during on_drag/on_resize_drag),
        saves the current state to history for undo/redo support.
        """
        if self._objects_changed and self.enable_history:
            self.save_state()
        self._objects_changed = False

    # -------------------------------------------------------------------------
    # History
    # -------------------------------------------------------------------------

    def save_state(self) -> None:
        """
        Save current canvas state to history for undo/redo.

        Captures full visual properties of every DraggableRectangle:
        coordinates, DPI, outline color, fill color, line width, handle
        radius, current selection state, and attached item metadata.

        This method is called automatically on:
        - Rectangle creation (create_draggable_rectangle)
        - Rectangle deletion (on_delete)
        - Move end (ButtonRelease after drag)
        - Resize end (ButtonRelease after handle drag)
        - Copy (copy_draggable_rectangle)

        For operations managed by the application layer (e.g. align,
        distribute, rotate), call save_state() explicitly after the
        operation completes.
        """
        if not self.enable_history:
            return

        state: dict = {
            "objects": {},
            "next_item_id": self.next_item_id,
            "selected": list(self.selected_objects.keys()),
        }

        for item_id, obj in self.objects.items():
            state["objects"][item_id] = {
                "coords": self._canvas_to_logical_coords(list(obj)),
                "dpi": obj.dpi,
                "outline": obj.original_outline,
                "fill": obj.fill_color,
                "line_width": obj.line_width,
                "handle_radius": obj.handle_radius,
                # Strong reference keeps the Python object alive in the history
                # stack so that _restore_state can resurrect it in-place instead
                # of creating a new instance (which would break caller references).
                "rect_ref": obj,
                "attached_items": self._snapshot_attached_items(obj),
            }

        # Truncate any future states if we're in the middle of the history
        if self.history_index < len(self.history_states) - 1:
            self.history_states = self.history_states[: self.history_index + 1]

        self.history_states.append(state)

        # Cap history at max_history, shifting the window forward
        if len(self.history_states) > self.max_history:
            self.history_states.pop(0)
        else:
            self.history_index += 1

    def undo(self) -> None:
        """
        Undo the last operation.

        Restores the canvas to the previous state in the history stack.
        The initial empty-canvas state at index 0 is reachable, so
        undoing all operations returns to a blank canvas.
        """
        self._dispatch("undo", self._builtin_undo)

    def _builtin_undo(self) -> None:
        if not self.enable_history:
            return
        if self.history_index > 0:
            self.history_index -= 1
            self._restore_state(self.history_states[self.history_index])

    def redo(self) -> None:
        """
        Redo the previously undone operation.

        Moves forward in the history stack if a future state exists.
        """
        self._dispatch("redo", self._builtin_redo)

    def _builtin_redo(self) -> None:
        if not self.enable_history:
            return
        if self.history_index < len(self.history_states) - 1:
            self.history_index += 1
            self._restore_state(self.history_states[self.history_index])

    def _update_rect_in_place(self, rect: "DraggableRectangle", data: dict) -> None:
        """
        Mutate an existing DraggableRectangle to match a saved state snapshot.

        Updates the underlying canvas item geometry and appearance without
        destroying or recreating the Python object, so all external references
        to this rectangle remain valid after an undo/redo operation.

        Attached items are restored via full reconciliation (delete + recreate
        from snapshot), which handles all cases correctly — items added, removed,
        or repositioned between states.  Falls back to dx/dy movement for
        history states saved before attached-item snapshots were introduced.

        Args:
            rect: The live DraggableRectangle instance to update.
            data: A single object entry from a history state dictionary.
        """
        # Saved coords are in logical (zoom=1.0) space; scale to current canvas space.
        coords = self._logical_to_canvas_coords(data["coords"])
        outline = data.get("outline", "black")
        fill = data.get("fill", "")
        line_width = data.get("line_width", 5)
        dpi = data.get("dpi", self.dpi)

        saved_attached = data.get("attached_items")
        if saved_attached is None:
            # Backward compat: compute delta before updating geometry
            old_coords = self.coords(rect.rect)
            dx = coords[0] - old_coords[0]
            dy = coords[1] - old_coords[1]
        else:
            # Full reconciliation: delete current attached items first
            for attached_id in rect._attached_items:
                self.delete(attached_id)
            rect._attached_items.clear()

        # Update geometry of both canvas items
        self.coords(rect.rect, coords[0], coords[1], coords[2], coords[3])
        self.coords(rect.resize_handle, coords[2], coords[3])

        # Restore attached items
        if saved_attached is not None:
            for snapshot in saved_attached:
                # Attached item coords are also in logical space; scale back.
                canvas_snapshot = {
                    **snapshot,
                    "coords": self._logical_to_canvas_coords(snapshot["coords"]),
                }
                new_id = self._recreate_attached_item(canvas_snapshot)
                if new_id is not None:
                    rect._attached_items.append(new_id)
        elif dx or dy:
            # Backward compat fallback: move existing attached items by delta
            self.move_attached_items(rect, dx, dy)

        # Update visual appearance on the canvas
        self.itemconfig(rect.rect, outline=outline, fill=fill, width=line_width)

        # Sync Python-side state attributes
        rect.original_outline = outline
        rect.fill_color = fill
        rect.line_width = line_width
        rect.dpi = dpi

    def _resurrect_rect(self, rect: "DraggableRectangle", data: dict) -> None:
        """
        Re-attach a previously deleted DraggableRectangle back onto the canvas.

        When a rectangle is removed during undo (surplus step), its Python object
        is kept alive inside the history snapshot via the ``rect_ref`` field.
        On redo, rather than creating a brand-new DraggableRectangle — which
        would silently break every caller-held reference — this method:

        1. Re-creates the two canvas items (rectangle + resize handle) with fresh
           canvas IDs stored directly on ``rect.rect`` / ``rect.resize_handle``.
        2. Re-binds all mouse-event handlers to the new item IDs.
        3. Syncs Python-side visual attributes from the saved snapshot.
        4. Recreates attached items from snapshot.
        5. Re-registers the object in the class-level weakref instance list
           (which was pruned when ``delete()`` was called during undo).

        The net result is a live, fully interactive rectangle that is the *same*
        Python object as before undo, so all external references remain valid.

        Args:
            rect: The DraggableRectangle whose canvas items need to be recreated.
            data: A single object entry from a history state dictionary.
        """
        # Saved coords are in logical (zoom=1.0) space; scale to current canvas space.
        coords = self._logical_to_canvas_coords(data["coords"])
        outline = data.get("outline", "black")
        fill = data.get("fill", "")
        line_width = data.get("line_width", 5)
        handle_radius = data.get("handle_radius", 5)
        dpi = data.get("dpi", self.dpi)

        # Re-create the two underlying canvas items (fresh IDs, same Python object)
        rect.rect = self.create_rectangle(
            coords[0],
            coords[1],
            coords[2],
            coords[3],
            outline=outline,
            fill=fill,
            width=line_width,
        )
        rect.resize_handle = self.create_aa_circle(
            coords[2], coords[3], radius=handle_radius, fill="#00497b"
        )

        # Re-bind all mouse interaction events to the new canvas item IDs
        self.tag_bind(rect.rect, "<Button-1>", rect.on_click)
        self.tag_bind(rect.rect, "<B1-Motion>", rect.on_drag)
        self.tag_bind(rect.rect, "<ButtonRelease-1>", rect._on_drag_end)
        self.tag_bind(rect.resize_handle, "<Button-1>", rect.on_resize_click)
        self.tag_bind(rect.resize_handle, "<B1-Motion>", rect.on_resize_drag)
        self.tag_bind(rect.resize_handle, "<ButtonRelease-1>", rect._on_resize_end)

        # Sync Python-side attribute state from the snapshot
        rect.original_outline = outline
        rect.fill_color = fill
        rect.line_width = line_width
        rect.handle_radius = handle_radius
        rect.dpi = dpi

        # Restore attached items from snapshot
        saved_attached = data.get("attached_items")
        if saved_attached:
            rect._attached_items.clear()
            for snapshot in saved_attached:
                canvas_snapshot = {
                    **snapshot,
                    "coords": self._logical_to_canvas_coords(snapshot["coords"]),
                }
                new_id = self._recreate_attached_item(canvas_snapshot)
                if new_id is not None:
                    rect._attached_items.append(new_id)

        # Re-register in class-level weakref tracking (removed by delete())
        rect_class = type(rect)
        if not any(ref is rect._self_ref for ref in rect_class._instances):
            rect_class._instances.append(rect._self_ref)

    def _restore_state(self, state: dict) -> None:
        """
        Restore canvas to a saved state via in-place reconciliation.

        Rather than a full destroy/rebuild cycle (which invalidates all external
        references to DraggableRectangle objects), this method reconciles the
        live canvas against the saved state in three targeted steps:

        1. Update in-place — items whose item_id exists in both the current
           canvas and the saved state are mutated directly (geometry + visuals).
           The Python object is not replaced, so all caller-held references
           remain valid after undo/redo.

        2. Delete surplus — items present only in the current canvas (not in
           the saved state) are removed, suppressing user callbacks.

        3. Resurrect missing — items present only in the saved state (previously
           deleted by the user) are recreated as new DraggableRectangle instances
           and registered under their original item_id.

        Flags _restoring_state and _suppress_registration prevent side effects
        throughout (no spurious deselect callbacks, no auto-registration
        conflicts from newly created rectangles).

        Args:
            state: A history state dictionary from save_state().
        """
        self._restoring_state = True
        self._suppress_registration = True

        try:
            # Normalise saved keys to int once for all three steps
            saved: dict[int, dict] = {
                (int(k) if isinstance(k, str) else k): v for k, v in state["objects"].items()
            }

            current_ids = set(self.objects.keys())
            saved_ids = set(saved.keys())

            # Step 1 — update surviving items in-place (preserves external references)
            for item_id in current_ids & saved_ids:
                self._update_rect_in_place(self.objects[item_id], saved[item_id])

            # Step 2 — remove items that do not exist in the saved state
            for item_id in list(current_ids - saved_ids):
                self.delete_draggable_rectangle(item_id)

            # Step 3 — resurrect items that exist in saved state but not currently.
            # When rect_ref is present (v0.4.2+), reuse the original Python object
            # so every caller-held reference stays valid after undo/redo.
            for item_id in saved_ids - current_ids:
                obj_data = saved[item_id]
                rect_ref = obj_data.get("rect_ref")
                if rect_ref is not None:
                    # Resurrect the original object — canvas items are recreated,
                    # events are rebound, but the Python identity is preserved.
                    self._resurrect_rect(rect_ref, obj_data)
                    self.objects[item_id] = rect_ref
                else:
                    # Backward-compat fallback for states saved before v0.4.2
                    # (no rect_ref field). Creates a new object as before.
                    coords = obj_data["coords"]
                    rect = DraggableRectangle(
                        self,
                        coords[0],
                        coords[1],
                        coords[2],
                        coords[3],
                        dpi=obj_data.get("dpi", self.dpi),
                        outline=obj_data.get("outline", "black"),
                        fill=obj_data.get("fill", ""),
                        width=obj_data.get("line_width", 5),
                        radius=obj_data.get("handle_radius", 5),
                    )
                    self.objects[item_id] = rect

            # Restore next_item_id
            self.next_item_id = state["next_item_id"]

            # Reset selection state without firing callbacks, then restore from snapshot
            self.selected_objects.clear()
            for obj in self.objects.values():
                if obj.get_is_selected():
                    obj.set_is_selected(False)
                    self.itemconfig(obj.rect, outline=obj.original_outline)

            for item_id in state.get("selected", []):
                if item_id in self.objects:
                    self.select_item(item_id)

        finally:
            self._suppress_registration = False
            self._restoring_state = False

    # -------------------------------------------------------------------------
    # Zoom
    # -------------------------------------------------------------------------

    def zoom_in(self, factor: float = 1.2) -> None:
        """
        Zoom in on the canvas, centered on the current view.

        Scales all canvas items (rectangles, lines, text) via the native
        canvas.scale() call, then performs PIL-based resizing on any
        tracked images since canvas.scale() does not resize bitmaps.

        Args:
            factor: Zoom multiplier (default: 1.2)
        """
        self._dispatch("zoom_in", self._builtin_zoom_in, factor)

    def _builtin_zoom_in(self, factor: float = 1.2) -> None:
        if not self.enable_zoom:
            return
        new_zoom = self.zoom_level * factor
        if new_zoom <= self.max_zoom:
            cx, cy = self.get_view_center()
            # Keep origin in sync: canvas_coord = zoom * logical + origin
            # After scaling by f around cx: new_origin = f*old_origin + cx*(1-f)
            self._canvas_origin_x = factor * self._canvas_origin_x + cx * (1.0 - factor)
            self._canvas_origin_y = factor * self._canvas_origin_y + cy * (1.0 - factor)
            self.zoom_level = new_zoom
            self.scale("all", cx, cy, factor, factor)
            self._rescale_all_tracked_images()

    def zoom_out(self, factor: float = 1.2) -> None:
        """
        Zoom out on the canvas, centered on the current view.

        Args:
            factor: Zoom divisor (default: 1.2)
        """
        self._dispatch("zoom_out", self._builtin_zoom_out, factor)

    def _builtin_zoom_out(self, factor: float = 1.2) -> None:
        if not self.enable_zoom:
            return
        new_zoom = self.zoom_level / factor
        if new_zoom >= self.min_zoom:
            cx, cy = self.get_view_center()
            inv = 1.0 / factor
            self._canvas_origin_x = inv * self._canvas_origin_x + cx * (1.0 - inv)
            self._canvas_origin_y = inv * self._canvas_origin_y + cy * (1.0 - inv)
            self.zoom_level = new_zoom
            self.scale("all", cx, cy, inv, inv)
            self._rescale_all_tracked_images()

    def on_zoom_wheel(self, event: Event) -> None:
        """Handle Alt+MouseWheel zoom."""
        self._dispatch("on_zoom_wheel", self._builtin_on_zoom_wheel, event)

    def _builtin_on_zoom_wheel(self, event: Event) -> None:
        if not self.enable_zoom:
            return
        if event.delta > 0:
            self.zoom_in(1.1)
        else:
            self.zoom_out(1.1)

    # -------------------------------------------------------------------------
    # Image tracking
    # -------------------------------------------------------------------------

    def track_image(
        self,
        image_id: int,
        original_image: Any,
        anchor: str = "center",
    ) -> None:
        """
        Register a canvas image item for automatic rescaling during zoom.

        Tkinter's canvas.scale() does NOT resize images — it only moves their
        anchor point. This method tracks the image so that zoom_in/zoom_out
        can perform proper PIL-based resizing.

        Args:
            image_id: The canvas item ID returned by create_image().
            original_image: The original PIL.Image.Image (NOT ImageTk).
            anchor: The anchor used when the image was placed (default: "center").
        """
        if not self.enable_zoom:
            return

        self._tracked_images[image_id] = {
            "original": original_image,
            "anchor": anchor,
            "tk_ref": None,
        }
        self._rescale_tracked_image(image_id)

    def untrack_image(self, image_id: int) -> None:
        """
        Stop tracking a canvas image for zoom rescaling.

        Args:
            image_id: The canvas item ID to stop tracking.
        """
        self._tracked_images.pop(image_id, None)

    def _rescale_tracked_image(self, image_id: int) -> None:
        """Rescale a single tracked image to the current zoom level."""
        try:
            from PIL import Image as PILImage
            from PIL import ImageTk
        except ImportError:
            return

        info = self._tracked_images.get(image_id)
        if info is None:
            return

        original = info["original"]
        new_width = max(1, int(original.width * self.zoom_level))
        new_height = max(1, int(original.height * self.zoom_level))

        resized = original.resize((new_width, new_height), PILImage.LANCZOS)
        tk_image = ImageTk.PhotoImage(resized)

        # Keep a strong reference so tkinter doesn't garbage-collect it
        info["tk_ref"] = tk_image
        self.itemconfigure(image_id, image=tk_image)

    def _rescale_all_tracked_images(self) -> None:
        """Rescale every tracked image to the current zoom level."""
        dead_ids = []
        for image_id in list(self._tracked_images):
            try:
                self._rescale_tracked_image(image_id)
            except Exception:
                dead_ids.append(image_id)

        for dead_id in dead_ids:
            self._tracked_images.pop(dead_id, None)

    def _canvas_to_logical_coords(self, coords: list[float]) -> list[float]:
        """Convert canvas-space coordinates to zoom=1.0 logical coordinates.

        The affine relationship is:
            canvas_coord = zoom_level * logical_coord + origin

        So the inverse is:
            logical_coord = (canvas_coord - origin) / zoom_level

        X- and Y-components alternate in *coords* (x0, y0, x1, y1, ...).
        """
        z = getattr(self, "zoom_level", 1.0)
        ox = getattr(self, "_canvas_origin_x", 0.0)
        oy = getattr(self, "_canvas_origin_y", 0.0)
        result = []
        for i, c in enumerate(coords):
            result.append((c - (ox if i % 2 == 0 else oy)) / z)
        return result

    def _logical_to_canvas_coords(self, coords: list[float]) -> list[float]:
        """Convert zoom=1.0 logical coordinates to current canvas-space coordinates.

        Inverse of _canvas_to_logical_coords:
            canvas_coord = zoom_level * logical_coord + origin
        """
        z = getattr(self, "zoom_level", 1.0)
        ox = getattr(self, "_canvas_origin_x", 0.0)
        oy = getattr(self, "_canvas_origin_y", 0.0)
        result = []
        for i, c in enumerate(coords):
            result.append(c * z + (ox if i % 2 == 0 else oy))
        return result

    # -------------------------------------------------------------------------
    # Attached items
    # -------------------------------------------------------------------------

    def attach_text_to_rectangle(self, text_id: int, rect: DraggableRectangle) -> None:
        """
        Attach a text item to a rectangle so they move together.

        Args:
            text_id: Canvas text item ID
            rect: DraggableRectangle to attach text to
        """
        self._dispatch(
            "attach_text_to_rectangle",
            self._builtin_attach_text_to_rectangle,
            text_id,
            rect,
        )

    def _builtin_attach_text_to_rectangle(self, text_id: int, rect: DraggableRectangle) -> None:
        rect._attached_items.append(text_id)

    def move_attached_items(self, rect: DraggableRectangle, dx: float, dy: float) -> None:
        """
        Move items attached to a rectangle.

        Args:
            rect: Rectangle whose attached items should move
            dx: X displacement
            dy: Y displacement
        """
        self._dispatch(
            "move_attached_items",
            self._builtin_move_attached_items,
            rect,
            dx,
            dy,
        )

    def _builtin_move_attached_items(self, rect: DraggableRectangle, dx: float, dy: float) -> None:
        for item_id in rect._attached_items:
            self.move(item_id, dx, dy)

    def _snapshot_attached_items(self, rect: DraggableRectangle) -> list[dict[str, Any]]:
        """
        Capture metadata of all canvas items attached to a rectangle.

        Returns a list of serialisable dictionaries — one per attached item —
        containing enough information to recreate the items later via
        ``_recreate_attached_item()``.

        Args:
            rect: The rectangle whose attached items should be snapshotted.

        Returns:
            List of snapshot dicts (empty if the rectangle has no attachments).
        """
        snapshots: list[dict[str, Any]] = []
        for attached_id in rect._attached_items:
            try:
                item_type = self.type(attached_id)
                item_coords = self._canvas_to_logical_coords(list(self.coords(attached_id)))
                snapshot: dict[str, Any] = {
                    "type": item_type,
                    "coords": item_coords,
                }
                if item_type == "text":
                    snapshot["text"] = self.itemcget(attached_id, "text")
                    snapshot["font"] = self.itemcget(attached_id, "font")
                    snapshot["fill"] = self.itemcget(attached_id, "fill")
                    snapshot["anchor"] = self.itemcget(attached_id, "anchor")
                elif item_type in ("line", "rectangle", "oval", "arc", "polygon"):
                    snapshot["fill"] = self.itemcget(attached_id, "fill")
                    snapshot["outline"] = self.itemcget(attached_id, "outline")
                    snapshot["width"] = self.itemcget(attached_id, "width")
                snapshot["tags"] = list(self.gettags(attached_id))
                snapshots.append(snapshot)
            except Exception:
                pass  # Item may have been deleted externally
        return snapshots

    def _recreate_attached_item(self, snapshot: dict[str, Any]) -> int | None:
        """
        Recreate a single canvas item from a snapshot dictionary.

        Args:
            snapshot: A dictionary previously produced by ``_snapshot_attached_items()``.

        Returns:
            The new canvas item ID, or ``None`` if the type is unsupported.
        """
        item_type = snapshot["type"]
        item_coords = snapshot["coords"]
        tags = tuple(snapshot.get("tags", ()))

        if item_type == "text":
            return cast(
                int,
                self.create_text(
                    *item_coords,
                    text=snapshot.get("text", ""),
                    font=snapshot.get("font", ""),
                    fill=snapshot.get("fill", "black"),
                    anchor=snapshot.get("anchor", "center"),
                    tags=tags,
                ),
            )
        elif item_type == "rectangle":
            return cast(
                int,
                self.create_rectangle(
                    *item_coords,
                    fill=snapshot.get("fill", ""),
                    outline=snapshot.get("outline", "black"),
                    width=float(snapshot.get("width", 1)),
                    tags=tags,
                ),
            )
        elif item_type == "line":
            return cast(
                int,
                self.create_line(
                    *item_coords,
                    fill=snapshot.get("fill", "black"),
                    width=float(snapshot.get("width", 1)),
                    tags=tags,
                ),
            )
        elif item_type == "oval":
            return cast(
                int,
                self.create_oval(
                    *item_coords,
                    fill=snapshot.get("fill", ""),
                    outline=snapshot.get("outline", "black"),
                    width=float(snapshot.get("width", 1)),
                    tags=tags,
                ),
            )
        return None
