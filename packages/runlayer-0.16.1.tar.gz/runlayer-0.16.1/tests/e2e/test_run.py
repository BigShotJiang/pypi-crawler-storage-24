import contextlib
import json
import select
import subprocess
import sys
import time

import pytest


def _send_jsonrpc(proc: subprocess.Popen, msg: dict) -> None:
    line = json.dumps(msg) + "\n"
    proc.stdin.write(line)
    proc.stdin.flush()


def _read_jsonrpc(proc: subprocess.Popen, timeout: float = 30) -> dict:
    """Read next JSON-RPC response, auto-replying to server-initiated requests."""
    deadline = time.monotonic() + timeout
    buf = ""
    while time.monotonic() < deadline:
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            break
        ready, _, _ = select.select([proc.stdout], [], [], min(remaining, 0.5))
        if ready:
            chunk = proc.stdout.readline()
            if not chunk:
                break
            buf += chunk
            try:
                msg = json.loads(buf.strip())
            except json.JSONDecodeError:
                continue
            buf = ""
            if "method" in msg and "id" in msg:
                _send_jsonrpc(
                    proc,
                    {
                        "jsonrpc": "2.0",
                        "id": msg["id"],
                        "result": {},
                    },
                )
                continue
            if "method" in msg:
                continue
            return msg
    raise TimeoutError(f"No JSON-RPC response within {timeout}s. Buffer: {buf!r}")


@contextlib.contextmanager
def _run_cli(server_id: str, api_key: str, base_url: str):
    proc = subprocess.Popen(
        [
            sys.executable,
            "-c",
            "from runlayer_cli.main import cli; cli()",
            "run",
            server_id,
            "--secret",
            api_key,
            "--host",
            base_url,
        ],
        stdin=subprocess.PIPE,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        bufsize=1,
    )
    try:
        time.sleep(3)
        assert proc.poll() is None, f"Process exited early: {proc.stderr.read()}"
        yield proc
    finally:
        proc.terminate()
        try:
            proc.wait(timeout=5)
        except subprocess.TimeoutExpired:
            proc.kill()
            proc.wait()


def _assert_mcp_tools(proc: subprocess.Popen) -> set[str]:
    """Initialize MCP session and return tool names."""
    _send_jsonrpc(
        proc,
        {
            "jsonrpc": "2.0",
            "id": 1,
            "method": "initialize",
            "params": {
                "protocolVersion": "2024-11-05",
                "capabilities": {},
                "clientInfo": {"name": "e2e-test", "version": "1.0"},
            },
        },
    )

    resp = _read_jsonrpc(proc)
    assert resp["id"] == 1
    assert "capabilities" in resp["result"]

    _send_jsonrpc(proc, {"jsonrpc": "2.0", "method": "notifications/initialized"})
    time.sleep(0.5)

    _send_jsonrpc(
        proc, {"jsonrpc": "2.0", "id": 2, "method": "tools/list", "params": {}}
    )
    tools_resp = _read_jsonrpc(proc)
    assert tools_resp["id"] == 2
    tools = tools_resp["result"]["tools"]
    assert len(tools) > 0
    return {t["name"] for t in tools}


SERVERS = [
    pytest.param(
        {
            "name": "echo",
            "url": "npx",
            "transport_type": "stdio",
            "transport_config": {"args": ["-y", "mcp-echo-server"]},
        },
        None,
        id="stdio-echo",
    ),
    pytest.param(
        {
            "name": "fs",
            "url": "npx",
            "transport_type": "stdio",
            "transport_config": {
                "args": ["-y", "@modelcontextprotocol/server-filesystem", "/tmp"]
            },
        },
        {"read_file", "list_directory"},
        id="stdio-filesystem",
    ),
    pytest.param(
        {
            "name": "deepwiki",
            "url": "https://mcp.deepwiki.com/mcp",
            "transport_type": "streaming-http",
            "transport_config": {},
        },
        None,
        id="remote-streamable-http",
    ),
]


@pytest.mark.parametrize("server_json, expected_tools", SERVERS)
def test_run(api_key, base_url, create_e2e_server, server_json, expected_tools):
    server = create_e2e_server(server_json)
    with _run_cli(server.id, api_key, base_url) as proc:
        tool_names = _assert_mcp_tools(proc)
        if expected_tools:
            assert tool_names >= expected_tools
