"""Tests for skills command argument validation."""

from pathlib import Path
from unittest.mock import AsyncMock, patch

import pytest
from typer.testing import CliRunner

from runlayer_cli.main import app
from runlayer_cli.skills.installer import InstallResult, LockEntry

runner = CliRunner()


def _entry(name: str) -> LockEntry:
    return LockEntry(name=name, id=f"id-{name}", client="claude_code")


def _resolve_dirs(tmp_path: Path) -> tuple[Path, Path, Path]:
    return (
        tmp_path / "canonical",
        tmp_path / "editor",
        tmp_path / "lock.yml",
    )


def test_add_all_works_without_source(tmp_path: Path):
    install_mock = AsyncMock(return_value=InstallResult(installed=["a"]))
    with (
        patch(
            "runlayer_cli.commands.skills.setup_logging",
            return_value=tmp_path / "log.txt",
        ),
        patch(
            "runlayer_cli.commands.skills.resolve_credentials",
            return_value={"host": "https://example.com", "secret": "rl_test"},
        ),
        patch(
            "runlayer_cli.commands.skills.resolve_dirs",
            return_value=_resolve_dirs(tmp_path),
        ),
        patch("runlayer_cli.commands.skills.RunlayerClient"),
        patch(
            "runlayer_cli.commands.skills.install_skills",
            new=install_mock,
        ),
    ):
        result = runner.invoke(
            app,
            ["skills", "add", "--all"],
        )

    assert result.exit_code == 0
    install_mock.assert_awaited_once()
    kwargs = install_mock.await_args_list[0].kwargs
    assert kwargs["install_all"] is True
    assert kwargs["source"] is None


@pytest.mark.parametrize(
    ("args", "expected_message"),
    [
        (["skills", "add", "org/repo", "--all"], "either SOURCE or --all"),
        (["skills", "add"], "Use SOURCE or --all"),
    ],
)
def test_add_arg_validation(args: list[str], expected_message: str):
    result = runner.invoke(app, args)
    assert result.exit_code == 1
    assert expected_message in result.output


def test_remove_all_prompts_and_aborts_on_no(tmp_path: Path):
    uninstall_mock = AsyncMock()
    with (
        patch(
            "runlayer_cli.commands.skills.setup_logging",
            return_value=tmp_path / "log.txt",
        ),
        patch(
            "runlayer_cli.commands.skills.resolve_dirs",
            return_value=_resolve_dirs(tmp_path),
        ),
        patch(
            "runlayer_cli.commands.skills.read_lockfile",
            return_value=[_entry("a"), _entry("b")],
        ),
        patch("runlayer_cli.commands.skills.typer.confirm", return_value=False),
        patch(
            "runlayer_cli.commands.skills.uninstall_skill",
            new=uninstall_mock,
        ),
    ):
        result = runner.invoke(app, ["skills", "remove", "--all"])

    assert result.exit_code == 0
    assert "Aborted." in result.output
    uninstall_mock.assert_not_called()


def test_remove_all_yes_removes_without_prompt(tmp_path: Path):
    uninstall_mock = AsyncMock()
    with (
        patch(
            "runlayer_cli.commands.skills.setup_logging",
            return_value=tmp_path / "log.txt",
        ),
        patch(
            "runlayer_cli.commands.skills.resolve_dirs",
            return_value=_resolve_dirs(tmp_path),
        ),
        patch(
            "runlayer_cli.commands.skills.read_lockfile",
            return_value=[_entry("a"), _entry("b")],
        ),
        patch("runlayer_cli.commands.skills.typer.confirm") as confirm_mock,
        patch(
            "runlayer_cli.commands.skills.uninstall_skill",
            new=uninstall_mock,
        ),
    ):
        result = runner.invoke(app, ["skills", "remove", "--all", "--yes"])

    assert result.exit_code == 0
    assert "Done: 2 removed" in result.output
    confirm_mock.assert_not_called()
    assert uninstall_mock.await_count == 2


@pytest.mark.parametrize(
    ("args", "expected_message"),
    [
        (["skills", "remove", "my-skill", "--all"], "either SKILL_NAME or --all"),
        (["skills", "remove"], "Use SKILL_NAME or --all"),
    ],
)
def test_remove_arg_validation(args: list[str], expected_message: str):
    result = runner.invoke(app, args)
    assert result.exit_code == 1
    assert expected_message in result.output


def test_remove_all_global_uses_global_scope(tmp_path: Path):
    with (
        patch(
            "runlayer_cli.commands.skills.setup_logging",
            return_value=tmp_path / "log.txt",
        ),
        patch(
            "runlayer_cli.commands.skills.resolve_dirs",
            return_value=_resolve_dirs(tmp_path),
        ) as resolve_dirs_mock,
        patch(
            "runlayer_cli.commands.skills.read_lockfile",
            return_value=[_entry("a")],
        ),
        patch(
            "runlayer_cli.commands.skills.uninstall_skill",
            new=AsyncMock(),
        ),
    ):
        result = runner.invoke(app, ["skills", "remove", "--all", "--yes", "--global"])

    assert result.exit_code == 0
    assert resolve_dirs_mock.call_args is not None
    assert resolve_dirs_mock.call_args.args[1] is True


def test_remove_all_filters_entries_by_selected_client(tmp_path: Path):
    entries = [
        LockEntry(name="a", id="id-a", client="claude_code"),
        LockEntry(name="b", id="id-b", client="cursor"),
    ]
    uninstall_mock = AsyncMock()
    with (
        patch(
            "runlayer_cli.commands.skills.setup_logging",
            return_value=tmp_path / "log.txt",
        ),
        patch(
            "runlayer_cli.commands.skills.resolve_dirs",
            return_value=_resolve_dirs(tmp_path),
        ),
        patch(
            "runlayer_cli.commands.skills.read_lockfile",
            return_value=entries,
        ),
        patch(
            "runlayer_cli.commands.skills.uninstall_skill",
            new=uninstall_mock,
        ),
    ):
        result = runner.invoke(
            app,
            [
                "skills",
                "remove",
                "--all",
                "--yes",
                "--client",
                "cursor",
            ],
        )

    assert result.exit_code == 0
    assert "Done: 1 removed" in result.output
    uninstall_mock.assert_awaited_once()
    args = uninstall_mock.await_args_list[0].args
    assert args[0] == "b"
    assert args[-1] == "cursor"


@pytest.mark.parametrize(
    "command",
    [
        ["skills", "list"],
        ["skills", "remove", "--all", "--yes"],
    ],
)
def test_shows_friendly_error_when_lockfile_invalid(tmp_path: Path, command: list[str]):
    with (
        patch(
            "runlayer_cli.commands.skills.setup_logging",
            return_value=tmp_path / "log.txt",
        ),
        patch(
            "runlayer_cli.commands.skills.resolve_dirs",
            return_value=_resolve_dirs(tmp_path),
        ),
        patch(
            "runlayer_cli.commands.skills.read_lockfile",
            side_effect=ValueError("invalid lockfile YAML"),
        ),
    ):
        result = runner.invoke(app, command)

    assert result.exit_code == 1
    assert "Error: invalid lockfile YAML" in result.output
    assert "See logs for details:" in result.output
