// ─────────────────────────────────────────────────────────────────────
// Director-Class AI — Coherence Scorer (Dual-Entropy Oversight)
// Mirrors: src/director_ai/core/scorer.py
// ─────────────────────────────────────────────────────────────────────
//! Dual-entropy coherence scorer for AI output verification.
//!
//! Computes a composite coherence score from two independent signals:
//! - **Logical divergence** (H_logical): NLI contradiction probability.
//! - **Factual divergence** (H_factual): Ground-truth deviation via RAG.
//!
//! The coherence score is `1 - (w_logic * H_logical + w_fact * H_factual)`.
//! When the score falls below `threshold`, the output is rejected.

use std::collections::VecDeque;
use std::sync::Arc;

use parking_lot::Mutex;

use backfire_types::score::{clamp_score, CoherenceScore};
use backfire_types::BackfireConfig;

use crate::knowledge::GroundTruthStore;
use crate::nli::NliBackend;

/// Dual-entropy coherence scorer.
///
/// Thread-safe: history mutations are guarded by a `parking_lot::Mutex`.
pub struct CoherenceScorer {
    config: BackfireConfig,
    nli: Arc<dyn NliBackend>,
    knowledge: Arc<dyn GroundTruthStore>,
    history: Mutex<VecDeque<String>>,
}

impl CoherenceScorer {
    pub fn new(
        config: BackfireConfig,
        nli: Arc<dyn NliBackend>,
        knowledge: Arc<dyn GroundTruthStore>,
    ) -> Self {
        Self {
            config,
            nli,
            knowledge,
            history: Mutex::new(VecDeque::new()),
        }
    }

    /// Calculate factual divergence against the ground truth store.
    ///
    /// Returns 0.0 (perfect alignment) to 1.0 (total hallucination).
    /// Mirrors `calculate_factual_divergence()` from `scorer.py:52-77`.
    pub fn calculate_factual_divergence(&self, prompt: &str, text_output: &str) -> f64 {
        let context = match self.knowledge.retrieve_context(prompt) {
            Some(ctx) => ctx,
            None => return 0.5, // Neutral when no store / no match
        };

        // Word-overlap heuristic (mirrors Python scorer._heuristic_factual)
        let ctx_lower = context.to_lowercase();
        let out_lower = text_output.to_lowercase();
        let ctx_words: std::collections::HashSet<&str> = ctx_lower.split_whitespace().collect();
        let out_words: std::collections::HashSet<&str> = out_lower.split_whitespace().collect();

        if ctx_words.is_empty() || out_words.is_empty() {
            return 0.5;
        }

        let intersection = ctx_words.intersection(&out_words).count() as f64;
        let union = ctx_words.union(&out_words).count() as f64;
        let similarity = intersection / union;
        (1.0 - similarity).clamp(0.0, 1.0)
    }

    /// Calculate logical divergence via NLI.
    ///
    /// Returns 0.0 (entailment) to 1.0 (contradiction).
    /// Mirrors `calculate_logical_divergence()` from `scorer.py:81-118`.
    pub fn calculate_logical_divergence(&self, prompt: &str, text_output: &str) -> f64 {
        let h = self.nli.score(prompt, text_output);
        if !h.is_finite() {
            log::warn!("NLI returned non-finite score, defaulting to 0.5");
            return 0.5;
        }
        h.clamp(0.0, 1.0)
    }

    /// Compute clamped divergences and heuristic coherence.
    ///
    /// Returns `(h_logic, h_fact, coherence)` with all values in [0, 1].
    /// Mirrors `_heuristic_coherence()` from `scorer.py:127-135`.
    fn compute_coherence(&self, prompt: &str, action: &str) -> (f64, f64, f64) {
        let h_logic = clamp_score(self.calculate_logical_divergence(prompt, action), 0.0, 1.0);
        let h_fact = clamp_score(self.calculate_factual_divergence(prompt, action), 0.0, 1.0);
        let coherence = clamp_score(
            1.0 - (self.config.w_logic * h_logic + self.config.w_fact * h_fact),
            0.0,
            1.0,
        );
        (h_logic, h_fact, coherence)
    }

    /// Score an action and decide whether to approve it.
    ///
    /// Returns `(approved, CoherenceScore)`.
    /// Mirrors `review()` from `scorer.py:181-189`.
    pub fn review(&self, prompt: &str, action: &str) -> (bool, CoherenceScore) {
        let (h_logic, h_fact, coherence) = self.compute_coherence(prompt, action);
        let approved = coherence >= self.config.coherence_threshold;

        if !approved {
            log::error!(
                "COHERENCE FAILURE. Score: {coherence:.4} < Threshold: {}",
                self.config.coherence_threshold
            );
        } else {
            let mut history = self.history.lock();
            history.push_back(action.to_string());
            if history.len() > self.config.history_window {
                history.pop_front();
            }
        }

        let score = CoherenceScore::new(coherence, approved, h_logic, h_fact)
            .with_warning(self.config.soft_limit);
        (approved, score)
    }

    /// Compute composite divergence (lower is better).
    ///
    /// Weighted sum: `0.6 * H_logical + 0.4 * H_factual`.
    /// Mirrors `compute_divergence()` from `scorer.py:165-179`.
    pub fn compute_divergence(&self, prompt: &str, action: &str) -> f64 {
        let h_logic = self.calculate_logical_divergence(prompt, action);
        let h_fact = self.calculate_factual_divergence(prompt, action);
        self.config.w_logic * h_logic + self.config.w_fact * h_fact
    }

    /// Read-only access to config.
    pub fn config(&self) -> &BackfireConfig {
        &self.config
    }

    /// Update coherence threshold at runtime.
    pub fn set_threshold(&mut self, threshold: f64) {
        self.config.coherence_threshold = threshold;
    }

    /// Update soft limit at runtime.
    pub fn set_soft_limit(&mut self, soft_limit: f64) {
        self.config.soft_limit = soft_limit;
    }

    /// Current history length.
    pub fn history_len(&self) -> usize {
        self.history.lock().len()
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::knowledge::InMemoryKnowledge;
    use crate::nli::HeuristicNli;

    fn make_scorer() -> CoherenceScorer {
        CoherenceScorer::new(
            BackfireConfig::default(),
            Arc::new(HeuristicNli),
            Arc::new(InMemoryKnowledge::new()),
        )
    }

    #[test]
    fn test_review_approved() {
        let scorer = make_scorer();
        let (approved, score) = scorer.review(
            "What color is the sky?",
            "The sky is blue, consistent with reality",
        );
        assert!(approved);
        assert!(score.score >= 0.6);
        assert!(score.h_logical < 0.5);
    }

    #[test]
    fn test_review_rejected_contradiction() {
        let scorer = make_scorer();
        let (approved, score) = scorer.review(
            "What color is the sky?",
            "The sky is green and the opposite is true",
        );
        assert!(!approved);
        assert!(score.score < 0.6);
    }

    #[test]
    fn test_factual_divergence_hallucination() {
        let scorer = make_scorer();
        let h = scorer.calculate_factual_divergence(
            "How many SCPN layers?",
            "There are many layers in the system",
        );
        // Word-overlap heuristic: low overlap = high divergence
        assert!(h > 0.5);
    }

    #[test]
    fn test_factual_divergence_correct() {
        let scorer = make_scorer();
        let h = scorer.calculate_factual_divergence("How many SCPN layers?", "There are 16 layers");
        // Word-overlap heuristic: higher overlap = lower divergence
        assert!(h < 1.0);
    }

    #[test]
    fn test_history_grows_and_caps() {
        let scorer = make_scorer();
        for i in 0..10 {
            scorer.review("test", &format!("response {i} consistent with reality"));
        }
        assert!(scorer.history_len() <= scorer.config().history_window);
    }

    #[test]
    fn test_compute_divergence() {
        let scorer = make_scorer();
        let div = scorer.compute_divergence("test", "some text");
        assert!((0.0..=1.0).contains(&div));
    }

    #[test]
    fn test_nan_nli_fallback() {
        use crate::nli::ExternalNli;
        let scorer = CoherenceScorer::new(
            BackfireConfig::default(),
            Arc::new(ExternalNli::new(|_, _| f64::NAN)),
            Arc::new(InMemoryKnowledge::new()),
        );
        let h = scorer.calculate_logical_divergence("a", "b");
        assert_eq!(h, 0.5);
    }

    #[test]
    fn test_coherence_formula() {
        // coherence = 1 - (0.6 * h_logic + 0.4 * h_fact)
        // With h_logic=0.1, h_fact=0.1:
        //   coherence = 1 - (0.06 + 0.04) = 0.9
        use crate::nli::ExternalNli;
        let scorer = CoherenceScorer::new(
            BackfireConfig::default(),
            Arc::new(ExternalNli::new(|_, _| 0.1)),
            Arc::new(InMemoryKnowledge::with_facts(Default::default())),
        );
        let (_, score) = scorer.review("test", "test");
        // h_fact = 0.5 (no facts → neutral), h_logic = 0.1
        // coherence = 1 - (0.6*0.1 + 0.4*0.5) = 1 - 0.26 = 0.74
        assert!((score.score - 0.74).abs() < 1e-9);
    }

    #[test]
    fn test_set_threshold_affects_review() {
        let mut scorer = make_scorer();
        scorer.set_threshold(0.99);
        let (approved, _) = scorer.review("test", "consistent with reality");
        assert!(
            !approved,
            "Raising threshold to 0.99 should reject most outputs"
        );
    }

    #[test]
    fn test_set_soft_limit_affects_warning() {
        let mut scorer = make_scorer();
        scorer.set_soft_limit(0.99);
        let (_, score) = scorer.review(
            "What color is the sky?",
            "The sky is blue, consistent with reality",
        );
        if score.approved {
            assert!(score.warning, "Soft limit at 0.99 should trigger warning");
        }
    }

    #[test]
    fn test_config_returns_reference() {
        let scorer = make_scorer();
        let cfg = scorer.config();
        assert_eq!(cfg.coherence_threshold, 0.6);
        assert_eq!(cfg.hard_limit, 0.5);
    }
}
