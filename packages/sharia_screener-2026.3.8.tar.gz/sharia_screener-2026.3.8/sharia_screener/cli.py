from __future__ import annotations

import argparse
import json
import os
from decimal import Decimal
from typing import Dict

from sharia_screener.exceptions import ConfigurationError, ScreeningError, ValidationError
from sharia_screener.providers.local_json import LocalJsonProvider
from sharia_screener.providers.unified_provider import UnifiedProvider
from sharia_screener.screening import ScreenEngine


def parse_holdings(value: str) -> Dict[str, Decimal]:
    try:
        payload = json.loads(value)
    except json.JSONDecodeError as exc:
        raise ValidationError("Invalid JSON for --holdings") from exc
    return {k.upper(): Decimal(str(v)) for k, v in payload.items()}


def load_json_file(path: str | None) -> dict:
    if not path:
        return {}
    if not os.path.exists(path):
        raise ConfigurationError(f"File not found: {path}")
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except json.JSONDecodeError as exc:
        raise ValidationError(f"Invalid JSON file: {path}") from exc


def main() -> None:
    parser = argparse.ArgumentParser(description="Sharia compliance screening tool")
    parser.add_argument("--ticker", type=str, help="Single ticker")
    parser.add_argument("--tickers", type=str, help="Comma-separated tickers")
    parser.add_argument(
        "--provider",
        type=str,
        default=os.getenv("SHARIA_PROVIDER", "local"),
        choices=["local", "unified"],
        help="Data provider to use",
    )
    parser.add_argument(
        "--data",
        type=str,
        default=os.getenv("SHARIA_DATA_PATH"),
        help="Path to local JSON data (for local provider)",
    )
    parser.add_argument(
        "--json",
        type=str,
        help="Inline JSON payload for local provider (overrides --data)",
    )
    parser.add_argument(
        "--sec-user-agent",
        type=str,
        default=os.getenv("SEC_USER_AGENT"),
        help="SEC requires a descriptive User-Agent (or set SEC_USER_AGENT env var)",
    )
    parser.add_argument(
        "--segment-rules",
        type=str,
        default=os.getenv("SHARIA_SEGMENT_RULES_PATH"),
        help="Path to segment classification rules (SEC provider)",
    )
    parser.add_argument(
        "--holdings",
        type=str,
        help="JSON map of holdings, e.g. '{""AAPL"": 10}'",
    )

    args = parser.parse_args()

    tickers = []
    if args.ticker:
        tickers.append(args.ticker)
    if args.tickers:
        tickers.extend([t.strip() for t in args.tickers.split(",") if t.strip()])
    if not tickers:
        raise SystemExit("Provide --ticker or --tickers")

    try:
        holdings = parse_holdings(args.holdings) if args.holdings else {}
        if args.provider == "local":
            if args.json:
                try:
                    payload = json.loads(args.json)
                except json.JSONDecodeError as exc:
                    raise ValidationError("Invalid JSON for --json payload") from exc
                provider = LocalJsonProvider(payload)
            else:
                if not args.data:
                    raise ConfigurationError("--data is required for local provider")
                provider = LocalJsonProvider(args.data)
        else:
            segment_rules = load_json_file(args.segment_rules)
            provider = UnifiedProvider(sec_user_agent=args.sec_user_agent, segment_rules=segment_rules)

        engine = ScreenEngine(provider=provider)

        results = []
        for ticker in tickers:
            shares = holdings.get(ticker.upper())
            result = engine.screen(ticker, shares_held=shares, fail_on_insufficient_data=True)
            results.append(
                {
                    "ticker": result.ticker,
                    "compliant": result.compliant,
                    "status": result.status,
                    "reason_codes": result.reason_codes,
                    "ratios": {k: (str(v) if v is not None else None) for k, v in result.ratios.items()},
                    "wash_percentage": str(result.wash_percentage)
                    if result.wash_percentage is not None
                    else None,
                    "wash_amount_per_share": str(result.wash_amount_per_share)
                    if result.wash_amount_per_share is not None
                    else None,
                    "investor_wash_amount": str(result.investor_wash_amount)
                    if result.investor_wash_amount is not None
                    else None,
                    "citations": result.citations,
                    "report": result.report,
                    "estimation_notes": result.estimation_notes,
                    "methodologies": result.methodologies,
                }
            )

        print(json.dumps({"results": results}, indent=2))
    except ScreeningError as exc:
        raise SystemExit(f"Screening failed: {exc}") from exc


if __name__ == "__main__":
    main()
