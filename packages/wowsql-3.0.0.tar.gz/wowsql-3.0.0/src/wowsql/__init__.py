"""
WowSQL Python SDK
Official client library for WowSQL REST API v2 (PostgreSQL)
"""

from .auth import (
    ProjectAuthClient,
    AuthResponse,
    AuthSession,
    AuthUser,
    TokenStorage,
    MemoryTokenStorage,
)
from .client import WowSQLClient, WowSQLError
from .table import Table, QueryBuilder
from .types import (
    QueryOptions,
    FilterExpression,
    HavingFilter,
    OrderByItem,
    QueryResponse,
    CreateResponse,
    UpdateResponse,
    DeleteResponse,
    PaginatedResponse,
    TableSchema,
    ColumnInfo,
)
from .storage import (
    WowSQLStorage,
    StorageBucket,
    StorageFile,
    StorageQuota,
    StorageError,
    StorageLimitExceededError,
)
from .schema import (
    WowSQLSchema,
    SchemaPermissionError,
)

__version__ = "2.1.0"
__all__ = [
    # Database Client
    "WowSQLClient",
    "WowSQLError",
    "Table",
    "QueryBuilder",
    # Auth Client
    "ProjectAuthClient",
    "AuthUser",
    "AuthSession",
    "AuthResponse",
    "TokenStorage",
    "MemoryTokenStorage",
    # Types
    "QueryOptions",
    "FilterExpression",
    "HavingFilter",
    "OrderByItem",
    "QueryResponse",
    "CreateResponse",
    "UpdateResponse",
    "DeleteResponse",
    "PaginatedResponse",
    "TableSchema",
    "ColumnInfo",
    # Storage Client
    "WowSQLStorage",
    "StorageBucket",
    "StorageFile",
    "StorageQuota",
    "StorageError",
    "StorageLimitExceededError",
    # Schema Management
    "WowSQLSchema",
    "SchemaPermissionError",
]
