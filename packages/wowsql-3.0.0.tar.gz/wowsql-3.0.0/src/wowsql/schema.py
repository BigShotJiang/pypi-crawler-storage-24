"""
Schema management client for WowSQL (PostgreSQL).
Requires SERVICE ROLE key.
"""

from typing import List, Dict, Any, Optional

import requests

from .client import WowSQLError


class SchemaPermissionError(WowSQLError):
    """Raised when operation requires service role key but anon key was used."""
    pass


class WowSQLSchema:
    """
    Schema management client for PostgreSQL.

    Requires a SERVICE ROLE key (``wowsql_service_...``), not an anonymous key.

    Example::

        schema = WowSQLSchema(
            project_url="myproject",
            service_key="wowsql_service_..."
        )

        schema.create_table("users", [
            {"name": "id", "type": "SERIAL", "auto_increment": True},
            {"name": "email", "type": "VARCHAR(255)", "unique": True, "nullable": False},
            {"name": "name", "type": "VARCHAR(255)"},
            {"name": "metadata", "type": "JSONB", "default": "'{}'"},
            {"name": "tags", "type": "TEXT[]"},
            {"name": "created_at", "type": "TIMESTAMPTZ", "default": "CURRENT_TIMESTAMP"},
        ], primary_key="id", indexes=["email"])
    """

    def __init__(
        self,
        project_url: str,
        service_key: str,
        *,
        base_domain: str = "wowsql.com",
        secure: bool = True,
        timeout: int = 30,
        verify_ssl: bool = True,
    ):
        """
        Args:
            project_url: Project subdomain or full URL.
                Examples: ``"myproject"`` | ``"https://myproject.wowsql.com"``
            service_key: Service role key (``wowsql_service_...``)
            base_domain: Base domain (default: wowsql.com)
            secure: Use HTTPS (default: True)
            timeout: Request timeout in seconds
            verify_ssl: Verify SSL certificates
        """
        if project_url.startswith("http://") or project_url.startswith("https://"):
            base = project_url.rstrip("/")
            if "/api" in base:
                base = base.rsplit("/api", 1)[0]
            self.base_url = base
        else:
            protocol = "https" if secure else "http"
            if f".{base_domain}" in project_url or project_url.endswith(base_domain):
                self.base_url = f"{protocol}://{project_url}"
            else:
                self.base_url = f"{protocol}://{project_url}.{base_domain}"

        self.timeout = timeout
        self.session = requests.Session()
        self.session.headers.update({
            "Authorization": f"Bearer {service_key}",
            "Content-Type": "application/json",
        })
        self.session.verify = verify_ssl

        if not verify_ssl:
            import urllib3
            urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

    # ── Internal ───────────────────────────────────────────────────

    def _request(self, method: str, path: str, **kwargs) -> Dict[str, Any]:
        url = f"{self.base_url}{path}"
        kwargs.setdefault("timeout", self.timeout)

        try:
            resp = self.session.request(method, url, **kwargs)

            if resp.status_code == 403:
                raise SchemaPermissionError(
                    "Schema operations require a SERVICE ROLE key. "
                    "You are using an anonymous key which cannot modify database schema.",
                    status_code=403,
                )

            resp.raise_for_status()
            return resp.json()

        except requests.exceptions.HTTPError as e:
            detail = ""
            try:
                detail = e.response.json().get("detail", "")
            except Exception:
                pass
            raise WowSQLError(
                detail or str(e),
                status_code=e.response.status_code if e.response is not None else None,
            )
        except requests.exceptions.RequestException as e:
            raise WowSQLError(str(e))

    # ── Table operations ───────────────────────────────────────────

    def create_table(
        self,
        table_name: str,
        columns: List[Dict[str, Any]],
        primary_key: Optional[str] = None,
        indexes: Optional[List[str]] = None,
    ) -> Dict[str, Any]:
        """
        Create a new table.

        Supported PostgreSQL types: SERIAL, BIGSERIAL, VARCHAR(n), TEXT, INT,
        BIGINT, BOOLEAN, NUMERIC(p,s), REAL, DOUBLE PRECISION, TIMESTAMPTZ,
        DATE, TIME, UUID, JSONB, TEXT[], INT[], BYTEA, etc.

        Args:
            table_name: Name of the table
            columns: Column definitions — each a dict with keys:
                ``name``, ``type``, and optionally ``auto_increment``,
                ``unique``, ``nullable``, ``default``
            primary_key: Primary key column name
            indexes: Columns to create indexes on
        """
        return self._request(
            "POST",
            "/api/v2/schema/tables",
            json={
                "table_name": table_name,
                "columns": columns,
                "primary_key": primary_key,
                "indexes": indexes,
            },
        )

    def alter_table(
        self,
        table_name: str,
        operation: str,
        column_name: Optional[str] = None,
        column_type: Optional[str] = None,
        new_column_name: Optional[str] = None,
        nullable: bool = True,
        default: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        Alter an existing table.

        Operations:
            - ``add_column``: Add a new column
            - ``drop_column``: Remove a column
            - ``modify_column``: Change column type/constraints
            - ``rename_column``: Rename a column
        """
        return self._request(
            "PATCH",
            f"/api/v2/schema/tables/{table_name}",
            json={
                "table_name": table_name,
                "operation": operation,
                "column_name": column_name,
                "column_type": column_type,
                "new_column_name": new_column_name,
                "nullable": nullable,
                "default": default,
            },
        )

    def drop_table(self, table_name: str, cascade: bool = False) -> Dict[str, Any]:
        """
        Drop a table.  WARNING: This cannot be undone!

        Args:
            table_name: Table to drop
            cascade: Also drop dependent objects (foreign keys, views, etc.)
        """
        return self._request(
            "DELETE",
            f"/api/v2/schema/tables/{table_name}",
            params={"cascade": cascade},
        )

    def execute_sql(self, sql: str) -> Dict[str, Any]:
        """
        Execute raw DDL SQL.

        Only schema statements are allowed: CREATE TABLE, ALTER TABLE,
        DROP TABLE, CREATE INDEX, DROP INDEX, CREATE EXTENSION,
        CREATE TYPE, CREATE SEQUENCE, etc.

        Example::

            schema.execute_sql('''
                CREATE TABLE products (
                    id SERIAL PRIMARY KEY,
                    name VARCHAR(255) NOT NULL,
                    price NUMERIC(10,2),
                    tags TEXT[],
                    metadata JSONB DEFAULT '{}'
                )
            ''')
        """
        return self._request(
            "POST",
            "/api/v2/schema/execute",
            json={"sql": sql},
        )

    # ── Convenience methods ────────────────────────────────────────

    def add_column(
        self,
        table_name: str,
        column_name: str,
        column_type: str,
        nullable: bool = True,
        default: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Add a column to an existing table."""
        return self.alter_table(
            table_name, "add_column",
            column_name=column_name,
            column_type=column_type,
            nullable=nullable,
            default=default,
        )

    def drop_column(self, table_name: str, column_name: str) -> Dict[str, Any]:
        """Drop a column from a table."""
        return self.alter_table(table_name, "drop_column", column_name=column_name)

    def rename_column(self, table_name: str, old_name: str, new_name: str) -> Dict[str, Any]:
        """Rename a column."""
        return self.alter_table(
            table_name, "rename_column",
            column_name=old_name,
            new_column_name=new_name,
        )

    def modify_column(
        self,
        table_name: str,
        column_name: str,
        column_type: Optional[str] = None,
        nullable: Optional[bool] = None,
        default: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Change column type, nullability, or default value."""
        kwargs: Dict[str, Any] = {"column_name": column_name}
        if column_type is not None:
            kwargs["column_type"] = column_type
        if nullable is not None:
            kwargs["nullable"] = nullable
        if default is not None:
            kwargs["default"] = default
        return self.alter_table(table_name, "modify_column", **kwargs)

    def create_index(
        self,
        table_name: str,
        column_names: Any,
        unique: bool = False,
        name: Optional[str] = None,
        using: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        Create an index.

        Args:
            table_name: Table to index
            column_names: Column(s) — string or list of strings
            unique: Create a UNIQUE index
            name: Custom index name
            using: Index method (btree, hash, gin, gist)
        """
        cols = column_names if isinstance(column_names, list) else [column_names]
        idx_name = name or f"idx_{table_name}_{'_'.join(cols)}"
        unique_kw = "UNIQUE " if unique else ""
        using_kw = f" USING {using}" if using else ""
        col_list = ", ".join(f'"{c}"' for c in cols)
        sql = f'CREATE {unique_kw}INDEX IF NOT EXISTS "{idx_name}" ON "{table_name}"{using_kw} ({col_list})'
        return self.execute_sql(sql)

    def list_tables(self) -> List[str]:
        """
        List all tables via the v2 REST API.

        Note: this calls the CRUD endpoint, not the schema endpoint,
        so it works with both anon and service keys.
        """
        resp = self._request("GET", "/api/v2/tables")
        return resp.get("tables", [])

    def get_table_schema(self, table_name: str) -> Dict[str, Any]:
        """Get column-level schema information for a table."""
        return self._request("GET", f"/api/v2/tables/{table_name}/schema")

    def close(self):
        """Close the HTTP session."""
        self.session.close()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()
