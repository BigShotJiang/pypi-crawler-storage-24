"""Type definitions for WOWSQL SDK."""

from typing import Any, Dict, List, Literal, Optional, TypedDict, Union, Tuple
from typing_extensions import NotRequired


# ── Filter / query types ─────────────────────────────────────────

class FilterExpression(TypedDict, total=False):
    """Filter expression for queries."""
    column: str
    operator: Literal[
        "eq", "neq", "gt", "gte", "lt", "lte",
        "like", "is", "in", "not_in",
        "between", "not_between", "is_not",
    ]
    value: Union[str, int, float, bool, None, List[Any], Tuple[Any, Any]]
    logical_op: NotRequired[Literal["AND", "OR"]]


class HavingFilter(TypedDict):
    """HAVING clause filter for aggregated results."""
    column: str
    operator: Literal["eq", "neq", "gt", "gte", "lt", "lte"]
    value: Union[str, int, float, bool, None]


class OrderByItem(TypedDict):
    """Order by item for multiple column sorting."""
    column: str
    direction: Literal["asc", "desc"]


class QueryOptions(TypedDict, total=False):
    """Options for querying records."""
    select: NotRequired[Union[str, List[str]]]
    filter: NotRequired[Union[FilterExpression, List[FilterExpression]]]
    group_by: NotRequired[Union[str, List[str]]]
    having: NotRequired[Union[HavingFilter, List[HavingFilter]]]
    order: NotRequired[Union[str, List[OrderByItem]]]
    order_direction: NotRequired[Literal["asc", "desc"]]
    limit: NotRequired[int]
    offset: NotRequired[int]


# ── Response types ───────────────────────────────────────────────

class QueryResponse(TypedDict):
    """Response from a query operation (GET or POST …/query)."""
    data: List[Dict[str, Any]]
    count: int
    total: int
    limit: int
    offset: int


class CreateResponse(TypedDict):
    """Response from a create (POST) operation."""
    id: Union[int, str]
    message: str


class UpdateResponse(TypedDict):
    """Response from an update (PATCH) operation."""
    message: str
    affected_rows: int


class DeleteResponse(TypedDict):
    """Response from a delete operation."""
    message: str
    affected_rows: int


class PaginatedResponse(TypedDict):
    """Response from the ``paginate()`` helper."""
    data: List[Dict[str, Any]]
    page: int
    per_page: int
    total: int
    total_pages: int


# ── Schema types ─────────────────────────────────────────────────

class ColumnInfo(TypedDict):
    """Column information returned by GET /tables/{table}/schema."""
    name: str
    type: str
    nullable: bool
    key: str       # "PRI" for primary key, "" otherwise
    default: Any
    extra: str


class TableSchema(TypedDict):
    """Table schema information."""
    table: str
    columns: List[ColumnInfo]
    primary_key: Optional[str]
