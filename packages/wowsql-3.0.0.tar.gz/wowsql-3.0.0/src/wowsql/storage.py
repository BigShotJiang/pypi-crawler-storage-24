"""
WowSQL Storage SDK — PostgreSQL-native file storage.

Files are stored as BYTEA inside each project's ``storage`` schema.
No external S3 dependency — everything lives in PostgreSQL.
"""

import os
from typing import Optional, Dict, Any, List, BinaryIO

import requests

from .client import WowSQLError


class StorageBucket:
    """Bucket information."""

    def __init__(self, data: dict):
        self.id: str = data.get("id", "")
        self.name: str = data.get("name", "")
        self.public: bool = data.get("public", False)
        self.file_size_limit: Optional[int] = data.get("file_size_limit")
        self.allowed_mime_types: Optional[List[str]] = data.get("allowed_mime_types")
        self.created_at: Optional[str] = data.get("created_at")
        self.object_count: int = data.get("object_count", 0)
        self.total_size: int = data.get("total_size", 0)

    def __repr__(self) -> str:
        return f"StorageBucket(name={self.name!r}, public={self.public})"


class StorageFile:
    """Storage file/object information."""

    def __init__(self, data: dict):
        self.id: str = data.get("id", "")
        self.bucket_id: str = data.get("bucket_id", "")
        self.name: str = data.get("name", "")
        self.path: str = data.get("path", "")
        self.mime_type: Optional[str] = data.get("mime_type")
        self.size: int = data.get("size", 0)
        self.metadata: dict = data.get("metadata", {})
        self.created_at: Optional[str] = data.get("created_at")
        self.public_url: Optional[str] = data.get("public_url")

    @property
    def size_mb(self) -> float:
        return self.size / (1024 * 1024)

    @property
    def size_gb(self) -> float:
        return self.size / (1024 ** 3)

    def __repr__(self) -> str:
        return f"StorageFile(path={self.path!r}, size={self.size_mb:.2f}MB)"


class StorageQuota:
    """Storage quota / statistics information."""

    def __init__(self, data: dict):
        self.total_files: int = data.get("total_files", 0)
        self.total_size_bytes: int = data.get("total_size_bytes", 0)
        self.total_size_gb: float = data.get("total_size_gb", 0)
        self.file_types: dict = data.get("file_types", {})

    def __repr__(self) -> str:
        return f"StorageQuota(files={self.total_files}, size={self.total_size_gb:.4f}GB)"


class StorageError(WowSQLError):
    """Storage-specific error."""
    pass


class StorageLimitExceededError(StorageError):
    """Error raised when bucket file size limit is exceeded."""
    pass


class WowSQLStorage:
    """
    WowSQL Storage Client — PostgreSQL-native file storage.

    All files are stored directly in the project's PostgreSQL database
    inside the ``storage`` schema (buckets + objects as BYTEA).

    Example::

        storage = WowSQLStorage(
            project_url="https://myproject.wowsql.com",
            api_key="wowsql_anon_..."
        )

        # Create a bucket
        bucket = storage.create_bucket("avatars", public=True)

        # Upload a file
        with open("photo.jpg", "rb") as f:
            result = storage.upload("avatars", f, path="users/profile.jpg")

        # List files
        files = storage.list_files("avatars", prefix="users/")

        # Get public URL
        url = storage.get_public_url("avatars", "users/profile.jpg")
    """

    def __init__(
        self,
        project_url: str = "",
        api_key: str = "",
        *,
        project_slug: str = "",
        base_url: str = "",
        base_domain: str = "wowsql.com",
        secure: bool = True,
        timeout: int = 60,
        verify_ssl: bool = True,
    ):
        """
        Args:
            project_url: Project subdomain or full URL.
                Examples: ``"myproject"`` | ``"https://myproject.wowsql.com"``
            api_key: API key for authentication
            project_slug: Explicit slug (used with ``base_url``)
            base_url: Explicit base URL (used with ``project_slug``)
            base_domain: Base domain (default: wowsql.com)
            secure: Use HTTPS (default: True)
            timeout: Request timeout in seconds (default: 60)
            verify_ssl: Verify SSL certificates (default: True)
        """
        if project_slug and base_url:
            self.base_url = base_url.rstrip("/")
            self.project_slug = project_slug
        elif project_url:
            url = project_url.strip()
            if url.startswith("http://") or url.startswith("https://"):
                self.base_url = url.rstrip("/")
                if "/api" in self.base_url:
                    self.base_url = self.base_url.rsplit("/api", 1)[0]
            else:
                protocol = "https" if secure else "http"
                if f".{base_domain}" in url or url.endswith(base_domain):
                    self.base_url = f"{protocol}://{url}"
                else:
                    self.base_url = f"{protocol}://{url}.{base_domain}"
            self.project_slug = (
                url.split(".")[0]
                .replace("https://", "")
                .replace("http://", "")
            )
        else:
            raise ValueError("Either project_url or (project_slug + base_url) must be provided")

        self.timeout = timeout
        self.verify_ssl = verify_ssl

        self.session = requests.Session()
        self.session.headers.update({"Authorization": f"Bearer {api_key}"})
        self.session.verify = verify_ssl

        if not verify_ssl:
            import urllib3
            urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

    # ── Internal ─────────────────────────────────────────────────

    def _request(
        self,
        method: str,
        path: str,
        *,
        params: Any = None,
        json: Any = None,
        files: Any = None,
        data: Any = None,
        stream: bool = False,
    ) -> Any:
        url = f"{self.base_url}{path}"
        extra_headers: Dict[str, Any] = {}
        if files:
            extra_headers["Content-Type"] = None

        try:
            resp = self.session.request(
                method,
                url,
                params=params,
                json=json,
                files=files,
                data=data,
                headers=extra_headers if files else {},
                timeout=self.timeout,
                stream=stream,
            )
            resp.raise_for_status()
            if stream:
                return resp
            return resp.json()
        except requests.exceptions.HTTPError as e:
            error_data: dict = {}
            try:
                error_data = e.response.json() if e.response.content else {}
            except Exception:
                pass
            msg = error_data.get("detail", str(e))
            code = e.response.status_code if e.response is not None else None
            if code == 413:
                raise StorageLimitExceededError(msg, status_code=code, response=error_data)
            raise StorageError(msg, status_code=code, response=error_data)
        except requests.exceptions.RequestException as e:
            raise StorageError(str(e))

    # ── Buckets ──────────────────────────────────────────────────

    def create_bucket(
        self,
        name: str,
        public: bool = False,
        file_size_limit: Optional[int] = None,
        allowed_mime_types: Optional[List[str]] = None,
    ) -> StorageBucket:
        """Create a new storage bucket."""
        data = self._request(
            "POST",
            f"/api/v1/storage/projects/{self.project_slug}/buckets",
            json={
                "name": name,
                "public": public,
                "file_size_limit": file_size_limit,
                "allowed_mime_types": allowed_mime_types,
            },
        )
        return StorageBucket(data)

    def list_buckets(self) -> List[StorageBucket]:
        """List all buckets in the project."""
        data = self._request(
            "GET", f"/api/v1/storage/projects/{self.project_slug}/buckets"
        )
        return [StorageBucket(b) for b in data]

    def get_bucket(self, name: str) -> StorageBucket:
        """Get a specific bucket by name."""
        data = self._request(
            "GET",
            f"/api/v1/storage/projects/{self.project_slug}/buckets/{name}",
        )
        return StorageBucket(data)

    def update_bucket(self, name: str, **kwargs: Any) -> StorageBucket:
        """Update bucket settings (name, public, file_size_limit, allowed_mime_types)."""
        data = self._request(
            "PATCH",
            f"/api/v1/storage/projects/{self.project_slug}/buckets/{name}",
            json=kwargs,
        )
        return StorageBucket(data)

    def delete_bucket(self, name: str) -> Dict[str, Any]:
        """Delete a bucket and all its files."""
        return self._request(
            "DELETE",
            f"/api/v1/storage/projects/{self.project_slug}/buckets/{name}",
        )

    # ── Files ────────────────────────────────────────────────────

    def upload(
        self,
        bucket_name: str,
        file_data: BinaryIO,
        path: Optional[str] = None,
        file_name: Optional[str] = None,
    ) -> StorageFile:
        """
        Upload a file to a bucket.

        Args:
            bucket_name: Target bucket
            file_data: File-like object (opened in binary mode)
            path: File path within bucket (e.g. ``'users/avatar.png'``)
            file_name: Override filename
        """
        content = file_data.read()
        name = file_name or getattr(file_data, "name", None) or path or "file"
        if "/" in name:
            name = name.rsplit("/", 1)[-1]

        folder = ""
        if path and "/" in path:
            folder = path.rsplit("/", 1)[0]

        params: Dict[str, str] = {}
        if folder:
            params["folder"] = folder

        files = {"file": (name, content, "application/octet-stream")}
        data = self._request(
            "POST",
            f"/api/v1/storage/projects/{self.project_slug}/buckets/{bucket_name}/files",
            params=params,
            files=files,
        )
        return StorageFile(data)

    def upload_file(
        self,
        file_data: BinaryIO,
        file_key: str,
        folder: Optional[str] = None,
        content_type: Optional[str] = None,
        check_quota: Optional[bool] = None,
        bucket_name: str = "default",
    ) -> Dict[str, Any]:
        """Backward-compatible upload method. Delegates to :meth:`upload`."""
        fpath = f"{folder}/{file_key}" if folder else file_key
        result = self.upload(bucket_name, file_data, path=fpath)
        return {
            "success": True,
            "file_key": result.path,
            "file_size": result.size,
            "message": "File uploaded successfully",
        }

    def upload_from_path(
        self,
        file_path: str,
        bucket_name: str = "default",
        path: Optional[str] = None,
    ) -> StorageFile:
        """Upload a file from a local filesystem path."""
        if not os.path.exists(file_path):
            raise FileNotFoundError(f"File not found: {file_path}")
        file_name = os.path.basename(file_path)
        with open(file_path, "rb") as f:
            return self.upload(bucket_name, f, path=path or file_name, file_name=file_name)

    def list_files(
        self,
        bucket_name: str,
        prefix: Optional[str] = None,
        limit: int = 100,
        offset: int = 0,
    ) -> List[StorageFile]:
        """List files in a bucket."""
        params: Dict[str, Any] = {"limit": limit, "offset": offset}
        if prefix:
            params["prefix"] = prefix
        data = self._request(
            "GET",
            f"/api/v1/storage/projects/{self.project_slug}/buckets/{bucket_name}/files",
            params=params,
        )
        items = data if isinstance(data, list) else data.get("files", data.get("data", []))
        return [StorageFile(f) for f in items]

    def download(self, bucket_name: str, file_path: str) -> bytes:
        """Download a file and return its binary contents."""
        resp = self._request(
            "GET",
            f"/api/v1/storage/projects/{self.project_slug}/files/{bucket_name}/{file_path}",
            stream=True,
        )
        return resp.content

    def download_to_file(
        self,
        bucket_name: str,
        file_path: str,
        local_path: str,
    ) -> str:
        """Download a file and save it to a local path. Returns the local path."""
        content = self.download(bucket_name, file_path)
        os.makedirs(os.path.dirname(local_path) or ".", exist_ok=True)
        with open(local_path, "wb") as f:
            f.write(content)
        return local_path

    def delete_file(self, bucket_name: str, file_path: str) -> Dict[str, Any]:
        """Delete a file from a bucket."""
        return self._request(
            "DELETE",
            f"/api/v1/storage/projects/{self.project_slug}/files/{bucket_name}/{file_path}",
        )

    # ── Utilities ────────────────────────────────────────────────

    def get_public_url(self, bucket_name: str, file_path: str) -> str:
        """Get the public URL for a file in a public bucket (no auth required)."""
        return f"{self.base_url}/api/v1/storage/projects/{self.project_slug}/files/{bucket_name}/{file_path}"

    def get_stats(self) -> StorageQuota:
        """Get storage statistics for the project."""
        data = self._request(
            "GET",
            f"/api/v1/storage/projects/{self.project_slug}/stats",
        )
        return StorageQuota(data)

    def get_quota(self, force_refresh: bool = False) -> StorageQuota:
        """Backward-compat alias for :meth:`get_stats`."""
        return self.get_stats()

    # ── Lifecycle ────────────────────────────────────────────────

    def close(self) -> None:
        """Close the HTTP session."""
        self.session.close()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()

    def __repr__(self) -> str:
        return f"WowSQLStorage(project={self.project_slug!r})"
