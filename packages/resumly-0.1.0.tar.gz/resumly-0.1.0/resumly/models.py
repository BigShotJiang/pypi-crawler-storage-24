"""Response models returned by the Resumly SDK."""

from __future__ import annotations

from datetime import datetime
from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field


class BaseResume(BaseModel):
    """Represents the parsed base resume returned by the API."""
    base_resume: Optional[Dict[str, Any]] = None
    base_resume_name: Optional[str] = None
    base_resume_last_updated: Optional[str] = None


class ResumeListItem(BaseModel):
    job_id: str
    status: Optional[str] = None
    date_created: Optional[str] = None
    company: Optional[str] = None
    job_title: Optional[str] = None
    has_download: bool = False


class ResumeListResponse(BaseModel):
    resumes: List[ResumeListItem]
    total: int
    page: int
    page_size: int


class CreatedResume(BaseModel):
    """Returned after creating a tailored resume."""
    job_id: str
    status: Optional[str] = None
    company: Optional[str] = None
    job_title: Optional[str] = None
    download_url: Optional[str] = None


class ATSReport(BaseModel):
    """ATS check analysis report."""
    analysis_id: str
    job_id: str
    report: Optional[Dict[str, Any]] = None
    status: Optional[str] = None


class ApiKeyInfo(BaseModel):
    """Metadata about an API key (full key never returned after creation)."""
    id: str
    key_prefix: str
    name: str
    created_at: str
    last_used_at: Optional[str] = None
    is_active: bool = True
    raw_key: Optional[str] = None
