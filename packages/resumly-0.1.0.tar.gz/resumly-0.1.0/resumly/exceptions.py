"""Exceptions raised by the Resumly SDK."""


class ResumlyError(Exception):
    """Base exception for all Resumly SDK errors."""

    def __init__(self, message: str, status_code: int = None, response: dict = None):
        self.message = message
        self.status_code = status_code
        self.response = response
        super().__init__(self.message)


class AuthenticationError(ResumlyError):
    """Raised when the API key is invalid or missing."""
    pass


class RateLimitError(ResumlyError):
    """Raised when the API rate limit is exceeded."""

    def __init__(self, message: str = "Rate limit exceeded", retry_after: int = None, **kwargs):
        self.retry_after = retry_after
        super().__init__(message, **kwargs)


class InsufficientCreditsError(ResumlyError):
    """Raised when the account does not have enough credits."""
    pass


class NotFoundError(ResumlyError):
    """Raised when the requested resource is not found."""
    pass


class ValidationError(ResumlyError):
    """Raised when the request payload fails validation."""
    pass
