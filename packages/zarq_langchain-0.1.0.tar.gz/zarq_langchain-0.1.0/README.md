# ZARQ LangChain Tool

Add crypto risk intelligence to any LangChain agent. Check if a token is safe before trading.

## Quick Start (3 lines)

```python
from zarq_langchain import ZARQRiskCheck

tools = [ZARQRiskCheck()]
agent = initialize_agent(tools, llm, agent=AgentType.OPENAI_FUNCTIONS)
```

## Installation

```bash
pip install zarq-langchain
```

**Dependencies:** `langchain-core`, `httpx`, `pydantic`

## Usage

### As a standalone tool

```python
from zarq_langchain import ZARQRiskCheck

tool = ZARQRiskCheck()
print(tool.run("bitcoin"))
# ZARQ Risk Check: Bitcoin (BTC)
# Verdict: WARNING
# Trust Score: 74.52/100 (Rating: A2)
# Crash Probability: 0.3177
# Distance to Default: 3.03
# ...
```

### In a LangChain agent

```python
from langchain_openai import ChatOpenAI
from langchain.agents import initialize_agent, AgentType
from zarq_langchain import ZARQRiskCheck

llm = ChatOpenAI(model="gpt-4")
tools = [ZARQRiskCheck()]
agent = initialize_agent(tools, llm, agent=AgentType.OPENAI_FUNCTIONS)

result = agent.run("Is it safe to buy solana right now?")
```

### With LangGraph

```python
from zarq_langchain import ZARQRiskCheck
from langgraph.prebuilt import create_react_agent

tools = [ZARQRiskCheck()]
agent = create_react_agent(model, tools)
```

### Async support

```python
result = await tool.arun("ethereum")
```

### Custom API endpoint

```python
# Point to a local instance or proxy
tool = ZARQRiskCheck(api_base="http://localhost:8000")
```

## What the tool returns

The tool returns a formatted string that any LLM can reason about:

```
ZARQ Risk Check: Bitcoin (BTC)
Verdict: WARNING
Trust Score: 74.52/100 (Rating: A2)
Crash Probability: 0.3177
Distance to Default: 3.03
Structural Weakness: Yes
Price: $70825.0
CAUTION: Elevated risk. Proceed with reduced position size.
```

**Verdicts:**
- `SAFE` — No structural issues detected
- `WARNING` — Elevated risk, structural weakness present
- `CRITICAL` — Structural collapse detected, avoid trading

## API Details

- **Endpoint:** `GET https://zarq.ai/v1/check/{token}`
- **Auth:** None required
- **Rate limit:** 5,000 calls/day per IP (free forever)
- **Coverage:** 205 tokens
- **Latency:** <100ms typical

## Links

- API Docs: https://zarq.ai/docs
- Full API: https://zarq.ai/v1/check/bitcoin
- Track Record: https://zarq.ai/track-record
