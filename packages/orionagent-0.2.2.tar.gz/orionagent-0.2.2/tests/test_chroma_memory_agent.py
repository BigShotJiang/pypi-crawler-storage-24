import os
import shutil
from orionagent import Agent, Gemini, MemoryConfig

# CONFIGURATION
GEMINI_API_KEY = "AIzaSyBEOpHS_vAM8y4juRV_wZzCsnJEcs9ad-U"

def test_chroma_memory_agent():
    print("\n" + "="*50)
    print("TEST: CHROMA MEMORY & SELF-LEARNING (GEMINI FLASH)")
    print("="*50)

    # Clean up previous data for clean test if exists
    if os.path.exists("orion_data"):
        # shutil.rmtree("orion_data") # Keep it to test persistence across runs if needed, but for 'hard' test we might want a fresh start
        pass

    # Initialize Gemini Flash
    llm = Gemini(
        model_name="gemini-2.0-flash",
        api_key=GEMINI_API_KEY,
        token_count=True
    )

    # Agent with persistent Chroma memory and self-learning strategy
    # self_learn strategy will retry if the verdict is not 'passed'
    learner = Agent(
        name="Scholar",
        role="Continuous Learning Specialist",
        description="Builds a persistent knowledge base and refines its own technical understanding.",
        model=llm,
        memory="chroma",  # SQL + VectorDB for long-term semantic retrieval
        strategy="self_learn", # Evaluate result and refine if needed
        max_refinements=2,
        verbose=True,
        debug=True
    )

    # 1. Store complex information
    info_task = """
    Record the following technical information for future reference:
    The Project 'Zephyr' uses a microservices architecture.
    - Service A: Port 8080, Python, handles Authentication.
    - Service B: Port 8081, Node.js, handles Billing.
    - Database: PostgreSQL on Port 5432.
    """
    
    print(f"\n[PHASE 1 - RECORDING]: Recording technical specs...\n")
    learner.ask(f"Please remember these specs: {info_task}", record_memory=True)
    
    # 2. Retrieve information after session 'cleared' (using a different session implicitly or just checking retrieval)
    print(f"\n[PHASE 2 - RETRIEVAL]: Testing semantic retrieval from ChromaDB...\n")
    query = "What port and language does the authentication service in Project Zephyr use?"
    
    try:
        response = learner.ask(query, stream=True)
        
        print(f"\n[{learner.name} Response]: ", end="")
        for chunk in response:
            print(chunk, end="", flush=True)
        print()
        
        llm.print_session_tokens()
        
        # Verify persistence files exist
        if os.path.exists("orion_data/orionagent.db"):
            print("\n[SUCCESS]: persistent SQLite database found.")
        if os.path.exists("orion_data/chroma_db"):
             print("[SUCCESS]: ChromaDB vector directory found.")

    except Exception as e:
        print(f"\n[ERROR]: Memory agent failed: {str(e)}")
        raise

if __name__ == "__main__":
    test_chroma_memory_agent()
