from orionagent import Agent, Manager, OpenAI, HitlConfig, file_manager

# CONFIGURATION
# Using OpenRouter for Nemotron
OPENROUTER_API_KEY = "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"
OPENROUTER_BASE_URL = "https://openrouter.ai/api/v1"
MODEL_ID = "nvidia/nemotron-3-super-120b-a12b:free"

def test_hitl_manager():
    print("\n" + "="*50)
    print("TEST: HUMAN-IN-THE-LOOP (HITL) CONFIGURATION")
    print("="*50)

    # Initialize OpenRouter Model
    llm = OpenAI(
        model_name=MODEL_ID,
        api_key=OPENROUTER_API_KEY,
        base_url=OPENROUTER_BASE_URL,
        token_count=True
    )

    # Agent with destructive potential (File Manager)
    # This agent needs supervision.
    janitor = Agent(
        name="SystemJanitor",
        role="System Maintenance & Cleanup",
        description="Manages system files and performs cleanup operations.",
        model=llm,
        tools=[file_manager],
        verbose=True
    )

    # Manager with High-Risk HITL Configuration
    # In 'high' permission level, it will ask for human approval before critical actions.
    # Note: In a headless test, this might wait for input. 
    # For automation, we typically check if the HITL config is correctly initialized.
    # Here we show how a user WOULD configure it.
    manager = Manager(
        name="ChiefSecurityOfficer",
        model=llm,
        agents=[janitor],
        strategy="planning",
        hitl=HitlConfig(
            permission_level="high", # Ask for permission for risky actions
            ask_once=True,           # Review the whole plan first
            plan_review=True
        ),
        verbose=True
    )

    print("\n[HITL CONFIGURATED]: Permission Level: High | Plan Review: Enabled")
    
    # We won't actually run a destructive command here to avoid blocking the test environment,
    # but we've successfully demonstrated the configuration.
    
    # Simple non-destructive query to verify the manager still works with HITL on.
    task = "List the files in the current directory and suggest which ones are safe to archive."
    
    print(f"\n[TASK]: {task}\n")
    
    try:
        # We use ask() which triggers the planning strategy.
        # If HITL works, it should show its intent to the user if it were interactive.
        response = manager.ask(task, stream=True)
        
        print("\n[MANAGER OUTPUT]: ", end="")
        for chunk in response:
            print(chunk, end="", flush=True)
        print()
        
        print("\n[SUCCESS]: HITL Manager initialized and executed successfully.")
    except Exception as e:
        print(f"\n[ERROR]: HITL test failed: {str(e)}")
        raise

if __name__ == "__main__":
    test_hitl_manager()
