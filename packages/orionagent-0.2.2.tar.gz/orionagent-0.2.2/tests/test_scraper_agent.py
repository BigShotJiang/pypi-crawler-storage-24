import os
from orionagent import Agent, Gemini, web_browser

# CONFIGURATION
GEMINI_API_KEY = "AIzaSyBEOpHS_vAM8y4juRV_wZzCsnJEcs9ad-U"

def test_scraper_agent():
    print("\n" + "="*50)
    print("TEST: SINGLE SCRAPER AGENT (GEMINI FLASH)")
    print("="*50)

    # Initialize Gemini Flash model
    llm = Gemini(
        model_name="gemini-2.0-flash",
        api_key=GEMINI_API_KEY,
        token_count=True,
        verbose=True
    )

    # Scraper Agent with explicit instructions and web_browser tool
    scraper = Agent(
        name="DataMiner",
        role="Web Scraper & Technical Researcher",
        description="Expert at extracting clean, structured data from complex websites.",
        system_instruction="You are DataMiner. Extract precise data. No conversational filler. No emojis. Output only technical data.",
        model=llm,
        tools=[web_browser],
        guards=["straight"], # Enforcement: No emojis/fluff
        verbose=True
    )

    task = "Search for the latest NVIDIA H200 GPU specifications and compare them with H100. Return a markdown table."
    
    print(f"\n[TASK]: {task}\n")
    
    try:
        response = scraper.ask(task, stream=True)
        
        print(f"\n[{scraper.name}]: ", end="")
        for chunk in response:
            print(chunk, end="", flush=True)
        print()
        
        # Verify token count printing
        llm.print_session_tokens()
        
        print("\n[SUCCESS]: Scraper agent completed the task successfully.")
    except Exception as e:
        print(f"\n[ERROR]: Scraper agent failed: {str(e)}")
        raise

if __name__ == "__main__":
    test_scraper_agent()
