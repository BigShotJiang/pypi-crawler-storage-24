import os
from orionagent import Agent, Manager, OpenAI, web_browser

# CONFIGURATION
# Using OpenRouter for Nemotron
OPENROUTER_API_KEY = "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"
OPENROUTER_BASE_URL = "https://openrouter.ai/api/v1"
MODEL_ID = "nvidia/nemotron-3-super-120b-a12b:free"

def test_deep_search_multi():
    print("\n" + "="*50)
    print("TEST: DEEP SEARCH MULTI-AGENT (OPENROUTER - NEMOTRON)")
    print("="*50)

    # Initialize OpenRouter Model
    llm = OpenAI(
        model_name=MODEL_ID,
        api_key=OPENROUTER_API_KEY,
        base_url=OPENROUTER_BASE_URL,
        token_count=True,
        verbose=True
    )

    # 1. Specialist: Technical Researcher (Scraper)
    researcher = Agent(
        name="DeepSearcher",
        role="Technical Research Specialist",
        description="Extracts raw data from technical sources across the web.",
        model=llm,
        tools=[web_browser],
        verbose=True
    )

    # 2. Specialist: Quantitative Analyst
    analyst = Agent(
        name="QuantAnalyst",
        role="Technical Data Analyst",
        description="Processes raw research data, calculates benchmarks, and synthesizes reports.",
        model=llm,
        verbose=True
    )

    # Multi-Agent Manager with Planning Strategy
    manager = Manager(
        name="MissionControl",
        model=llm,
        agents=[researcher, analyst],
        strategy="planning", # Multi-step autonomous decomposition
        verbose=True,
        debug=True
    )

    task = "Find the latest benchmarks for H100 vs B200 GPUs. Calculate the percentage performance gain for deep learning training tasks."
    
    print(f"\n[GOAL]: {task}\n")
    
    try:
        response = manager.ask(task, stream=True)
        
        print("\n[MISSION OUTPUT]: ", end="")
        for chunk in response:
            print(chunk, end="", flush=True)
        print()
        
        llm.print_session_tokens()
        print("\n[SUCCESS]: Deep search multi-agent mission completed.")
    except Exception as e:
        print(f"\n[ERROR]: Mission failed: {str(e)}")
        raise

if __name__ == "__main__":
    test_deep_search_multi()
