import os
from orionagent import Agent, Gemini
from orionagent.knowledge.knowledge_base import KnowledgeBase

# CONFIGURATION
GEMINI_API_KEY = "AIzaSyBEOpHS_vAM8y4juRV_wZzCsnJEcs9ad-U"

def test_rag_knowledge_agent():
    print("\n" + "="*50)
    print("TEST: RAG & KNOWLEDGE BASE INTEGRATION (GEMINI FLASH)")
    print("="*50)

    # Initialize Gemini Flash
    llm = Gemini(
        model_name="gemini-2.0-flash",
        api_key=GEMINI_API_KEY,
        token_count=True
    )

    # 1. Define a Knowledge Base
    # This will create a local vector store in orion_data/rag_tests
    kb = KnowledgeBase(collection_name="rag_tests")

    # 2. Agent with Knowledge Base access
    # Providing a KnowledgeBase object to an Agent auto-injects IngestTool and QueryKnowledgeTool.
    librarian = Agent(
        name="Librarian",
        role="Information & Knowledge Manager",
        description="Manages the corporate knowledge base and retrieves relevant facts.",
        model=llm,
        knowledge=kb,
        strategy="planning", # Planning helps it decide when to query knowledge
        verbose=True
    )

    # 3. Simulate Ingestion of data
    ingest_task = """
    Document the 'Orion Protocol' details:
    - Version: 3.4.1
    - Encryption: AES-512
    - Heartbeat: 30s
    - Primary Node: Orion-Alpha
    """
    
    print(f"\n[PHASE 1 - INGESTION]: Ingesting technical documentation into RAG...\n")
    # Using IngestTool via Librarian.ask
    # FIX: Explicitly tell the agent to use the ingestion tool for this text
    task_ingest = f"Use your ingestion tool to record this raw text into the knowledge base: {ingest_task}"
    for _ in librarian.ask(task_ingest, record_memory=True):
        pass

    # 4. Perform a RAG-based query
    print(f"\n[PHASE 2 - RAG QUERY]: Querying the Librarian about Orion Protocol...\n")
    query = "Search your knowledge base for the Orion Protocol Version 3 encryption standard and heartbeat interval."
    
    try:
        response = librarian.ask(query, stream=True)
        
        print(f"\n[{librarian.name} Answer]: ", end="")
        for chunk in response:
            print(chunk, end="", flush=True)
        print()
        
        llm.print_session_tokens()
        
        if os.path.exists("orion_data/rag_db"):
             print("\n[SUCCESS]: Knowledge base directory 'rag_db' found.")
             
    except Exception as e:
        print(f"\n[ERROR]: RAG agent failed: {str(e)}")
        raise

if __name__ == "__main__":
    test_rag_knowledge_agent()
