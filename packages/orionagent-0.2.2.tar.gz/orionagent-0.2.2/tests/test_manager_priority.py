import unittest
from unittest.mock import MagicMock
from orionagent import Agent, Manager, Gemini
from orionagent.memory.session import Session

class TestManagerPriority(unittest.TestCase):
    def setUp(self):
        # Mocking the Gemini model to avoid real API calls
        self.llm = MagicMock(spec=Gemini)
        self.llm.generate.return_value = "Mocked Response"
        self.llm.token_count = False
        
        self.agent = Agent(name="Finder", role="Search", model=self.llm)
        self.manager = Manager(
            name="Test-Orchestrator",
            model=self.llm,
            agents=[self.agent],
            memory="session"
        )

    def test_manager_ask_with_priority(self):
        """Verify that Manager.ask() accepts the priority argument and updates session."""
        try:
            # We don't care about the result, just that it doesn't raise TypeError
            # and that priority is set.
            res = self.manager.ask("Hello", priority="high", stream=False)
            
            # Verify priority was set on the session
            # We need to find the session. It's stored in _session_manager.
            sid = self.manager._session_manager.auto("default_user", "Manager")
            session = self.manager._session_manager.load("default_user", "Manager", sid)
            
            self.assertEqual(session.priority, "high")
            self.assertEqual(res, "Mocked Response")
            
        except TypeError as e:
            self.fail(f"Manager.ask() raised TypeError: {e}")

if __name__ == "__main__":
    unittest.main()
