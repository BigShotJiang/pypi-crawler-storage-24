import asyncio
import time
from orionagent import Agent, Gemini

# CONFIGURATION
GEMINI_API_KEY = "AIzaSyBEOpHS_vAM8y4juRV_wZzCsnJEcs9ad-U"

async def run_async_test():
    print("\n" + "="*50)
    print("TEST: ASYNC MODE & SESSION MANAGEMENT (GEMINI FLASH)")
    print("="*50)

    # Initialize Gemini Flash
    llm = Gemini(
        model_name="gemini-2.0-flash",
        api_key=GEMINI_API_KEY,
        token_count=True
    )

    # Agent with complex system instruction and async mode enabled
    # Async mode ensures tool execution doesn't block generators where possible
    coordinator = Agent(
        name="SyncMaster",
        role="Concurrency Specialist",
        description="Coordinates multiple parallel streams of thought and execution.",
        system_instruction="""
        You are SyncMaster. You operate in a highly concurrent environment.
        When asked to perform multiple tasks, think about their dependencies.
        Always provide technical timestamps for each 'virtual' step you take.
        Use a formal, efficient tone.
        """,
        model=llm,
        async_mode=True,
        memory="session", # Transient memory for this specific run
        verbose=True
    )
    task = "Analyze the concept of 'Eventual Consistency' in distributed databases. Provide 3 pros and 3 cons."
    
    print(f"\n[TASK]: {task}\n")
    
    start_time = time.time()
    
    # In OrionAgent, ask() returns a generator by default when stream=True.
    # If async_mode is True, internal tool calls are awaited.
    response = coordinator.ask(task, stream=True)
    
    print(f"\n[{coordinator.name}]: ", end="")
    for chunk in response:
        print(chunk, end="", flush=True)
    print()
    
    end_time = time.time()
    print(f"\n[METRICS]: Execution Time: {end_time - start_time:.2f}s")
    
    llm.print_session_tokens()
    print("\n[SUCCESS]: Async & Session test completed.")

if __name__ == "__main__":
    asyncio.run(run_async_test())
