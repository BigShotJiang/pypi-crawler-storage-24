import unittest
from orionagent import Agent, Manager, Gemini
from dotenv import load_dotenv
import os

load_dotenv()

class TestLeadsScraper(unittest.TestCase):
    def setUp(self):
        self.llm = Gemini(model_name="gemini-2.0-flash")
        self.lead_finder = Agent(name="Finder", role="Search", model=self.llm)
        self.detail_scraper = Agent(name="Scraper", role="Extract", model=self.llm)
        self.data_manager = Agent(name="Manager", role="Data", model=self.llm)
        
    def test_manager_initialization(self):
        """Verify that the Manager can be initialized with the scraper agents."""
        manager = Manager(
            name="Test-Orchestrator",
            model=self.llm,
            agents=[self.lead_finder, self.detail_scraper, self.data_manager],
            strategy=["planning", "self_learn"]
        )
        self.assertEqual(len(manager.agents), 3)
        agent_names = [a.name for a in manager.agents]
        self.assertIn("Finder", agent_names)
        self.assertIn("Scraper", agent_names)
        self.assertIn("Manager", agent_names)

    def test_agent_roles(self):
        """Verify agents have correct roles."""
        self.assertEqual(self.lead_finder.role, "Search")
        self.assertEqual(self.detail_scraper.role, "Extract")

if __name__ == "__main__":
    unittest.main()
