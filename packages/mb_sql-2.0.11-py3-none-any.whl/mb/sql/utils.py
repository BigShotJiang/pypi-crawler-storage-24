## file for extra sql functions

import pandas as pd
from .basic import read_sql,engine_execute
import os
from mb.utils.logging import logg

__all__ = ['list_schemas','rename_table','drop_table','drop_schema','create_schema',
           'create_index','clone_db','list_tables','get_table_schema']

def list_schemas(engine,logger=None) -> pd.DataFrame:
    """
    Returns list of schemas in database.
    
    Args:
        engine (sqlalchemy.engine.base.Engine): Engine object. If sqlite, will return 'main' schema using PRAGMA database_list.
        logger (logging.Logger): Logger object. Default: mb_utils.src.logging.logger
    Returns:
        df (pandas.core.frame.DataFrame): DataFrame object.
    """
    try:
        q1 ="SELECT schema_name FROM information_schema.schemata WHERE schema_name NOT IN ('information_schema', 'mysql', 'performance_schema') ORDER BY schema_name;"
        return read_sql(q1,engine,logger=logger)
    except Exception as e:
        logg.error(f'Error listing schemas in database.', logger=logger)
        logg.info(f'Attempting to list schemas with PRAGMA database_list for sqlite.', logger=logger)
        try:
            q1 = "PRAGMA database_list;"
            return read_sql(q1,engine,logger=logger)
        except Exception as e:
            logg.error(f'Error listing schemas in database.', logger=logger)
            raise e

def list_tables(engine,schema=None,logger=None) -> pd.DataFrame:
    """
    Returns list of tables in database.
    
    Args:
        engine (sqlalchemy.engine.base.Engine): Engine object. If sqlite, will return all tables in the database using sqlite_master.
        schema (str): Name of the schema. Default: None
        logger (logging.Logger): Logger object. Default: mb_utils.src.logging.logger
    Returns:
        df (pandas.core.frame.DataFrame): DataFrame object.
    
    """
    try:
        q1 = f"SELECT table_name FROM information_schema.tables WHERE table_schema = '{schema}' ORDER BY table_name;"
        return read_sql(q1,engine,logger=logger)
    except Exception as e:
        logg.error(f'Error listing tables in database.', logger=logger)
        logg.info(f'Attempting to list tables without schema filter and with sqlite_master.', logger=logger)
        try:
            q1 = "select name from sqlite_master where type='table';"
            return read_sql(q1,engine,logger=logger)
        except Exception as e:
            logg.error(f'Error listing tables in database.', logger=logger)
            raise e

def get_table_schema(table_name,engine,schema=None,logger=None) -> pd.DataFrame:
    """
    Returns schema of a table in database.
    
    Args:
        table_name (str): Name of the table.
        engine (sqlalchemy.engine.base.Engine): Engine object. If sqlite, will return schema of the table using PRAGMA table_info.
        schema (str): Name of the schema. Default: None
        logger (logging.Logger): Logger object. Default: mb_utils.src.logging.logger
    Returns:
        df (pandas.core.frame.DataFrame): DataFrame object.
    """
    try:
        q1 = f"SELECT column_name, data_type FROM information_schema.columns WHERE table_name = '{table_name}' AND table_schema = '{schema}';"
        return read_sql(q1,engine,logger=logger)
    except Exception as e:
        logg.error(f'Error getting schema of table {table_name} in database.', logger=logger)
        logg.info(f'Attempting to get schema of table {table_name} with PRAGMA table_info for sqlite.', logger=logger)
        try:
            q1 = f"PRAGMA table_info('{table_name}');"
            return read_sql(q1,engine,logger=logger)
        except Exception as e:
            logg.error(f'Error getting schema of table {table_name} in database.', logger=logger)
            raise e

def rename_table(new_table_name,old_table_name,engine,schema=None,logger=None):
    """
    Rename table in database.
    
    Args:
        new_table_name (str): New name of the table.
        old_table_name (str): Old name of the table.
        engine (sqlalchemy.engine.base.Engine): Engine object.
        schema_name (str): Name of the schema. Default: None
        logger (logging.Logger): Logger object. Default: mb_utils.src.logging.logger
    Returns:
        None
    """
    if schema:
        q1 = f"ALTER TABLE {schema}.{old_table_name} RENAME TO {new_table_name};"
    else:
        q1 = f"ALTER TABLE {old_table_name} RENAME TO {new_table_name};"
    engine_execute(engine,q1)
    logg.info(f'Table {old_table_name} renamed to {new_table_name}.',logger=logger)

def drop_table(table_name,engine,schema=None,logger=None):
    """
    Drop table in database.
    
    Args:
        table_name (str): Name of the table.
        engine (sqlalchemy.engine.base.Engine): Engine object.
        schema (str): Name of the schema. Default: None
        logger (logging.Logger): Logger object. Default: mb_utils.src.logging.logger
    Returns:
        None
    """
    if schema:
        q1 = f"DROP TABLE {schema}.{table_name};"
    else:
        q1 = f"DROP TABLE {table_name};"
    engine_execute(engine,q1)
    logg.info(f'Table {table_name} dropped.',logger=logger)
        
def drop_schema(schema,engine,logger=None):
    """
    Drop schema in database.
    
    Args:
        schema (str): Name of the schema.
        engine (sqlalchemy.engine.base.Engine): Engine object.
        logger (logging.Logger): Logger object. Default: mb_utils.src.logging.logger
    Returns:
        None
    """
    q1 = f"DROP SCHEMA {schema};"
    engine_execute(engine,q1)
    logg.info(f'Schema {schema} dropped.',logger=logger)
        
def create_schema(schema,engine,logger=None):
    """
    Create schema in database.
    
    Args:
        schema (str): Name of the schema.
        engine (sqlalchemy.engine.base.Engine): Engine object.
        logger (logging.Logger): Logger object. Default: mb_utils.src.logging.logger
    Returns:
        None
    """
    q1 = f"CREATE SCHEMA {schema};"
    engine_execute(engine,q1)
    logg.info(f'Schema {schema} created.',logger=logger)

def create_index(table,index_col,engine,logger=None):
    """
    Create an Index for a table in database.
    
    Args:
        table (str): Name of the table.
        index_col (str): Name of the index_col in the table.
        engine (sqlalchemy.engine.base.Engine): Engine object.
        logger (logging.Logger): Logger object. Default: mb_utils.src.logging.logger
    Returns:
        None
    """
    q1 = f"CREATE INDEX {index_col} ON {table};"
    engine_execute(engine,q1)
    logg.info(f'Index {index_col} created for table {table}.',logger=logger)
        
def clone_db(ori_db_location,copy_db_location, logger=None):
    """
    Clone a database.
    
    Args:
        ori_db_location (str): Location of the original database.
        copy_db_location (str): Location for the new database.
        logger (logging.Logger): Logger object. Default: mb_utils.src.logging.logger
    Returns:
        None
    """
    if not os.path.exists(ori_db_location):
        raise FileNotFoundError("The original location does not exist.")

    if os.path.exists(copy_db_location):
        copy_db_location = os.path.join(copy_db_location,'copy_db')
    
    if os.path.exists(copy_db_location)==False:
        os.makedirs(copy_db_location)
    
    cmd = f"pg_dump -U postgres -h localhost -p 5432 {ori_db_location} | psql -U postgres -h localhost -p 5432 {copy_db_location}"
    os.system(cmd)

    logg.info(f'Database cloned from {ori_db_location} to {copy_db_location}.',logger=logger)    
    