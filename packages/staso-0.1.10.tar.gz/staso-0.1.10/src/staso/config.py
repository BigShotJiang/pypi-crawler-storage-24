from __future__ import annotations

from dataclasses import dataclass

_DEFAULT_BASE_URL = "http://localhost:6999"


@dataclass(frozen=True)
class Config:
    """SDK configuration. Immutable after creation."""

    api_key: str
    agent_id: str
    base_url: str = _DEFAULT_BASE_URL
    batch_size: int = 100
    flush_interval: float = 5.0
    max_queue_size: int = 10_000
    enabled: bool = True
    debug: bool = False
    environment: str = "default"
    workspace_slug: str = ""
    capture_messages: bool = True
