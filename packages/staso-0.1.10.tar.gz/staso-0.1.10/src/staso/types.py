"""Typed enums and constants for span data — replaces OI semantic conventions."""
from __future__ import annotations

from enum import StrEnum


class SpanKind(StrEnum):
    """Span type classification, matches backend SpanKindEnum."""

    LLM = "llm"
    TOOL = "tool"
    CHAIN = "chain"
    RETRIEVER = "retriever"
    AGENT = "agent"
    CUSTOM = "custom"


class SpanStatus(StrEnum):
    """Span outcome status, matches backend StatusEnum."""

    OK = "ok"
    ERROR = "error"
    TIMEOUT = "timeout"


# ── Well-known metadata keys ──
# Stored in span.metadata dict -> serialized to "attributes" JSON column in ClickHouse.
# Union of what LangSmith, Braintrust, and Maxim track.

# Identity / context
META_PROVIDER = "provider"
META_TAGS = "tags"
META_TOOL_NAME = "tool_name"

# Response metadata
META_STOP_REASON = "stop_reason"
META_STOP_SEQUENCE = "stop_sequence"
META_RESPONSE_ID = "response_id"

# Request parameters
META_TEMPERATURE = "temperature"
META_MAX_TOKENS = "max_tokens"
META_TOP_P = "top_p"
META_TOP_K = "top_k"
META_STOP_SEQUENCES = "stop_sequences"
META_TOOL_CHOICE = "tool_choice"
META_THINKING = "thinking"
META_SERVICE_TIER = "service_tier"
META_RESPONSE_FORMAT = "response_format"
META_FREQUENCY_PENALTY = "frequency_penalty"
META_PRESENCE_PENALTY = "presence_penalty"
META_SEED = "seed"

# Token breakdown (beyond top-level input/output/total)
META_CACHE_READ_TOKENS = "cache_read_input_tokens"
META_CACHE_CREATION_TOKENS = "cache_creation_input_tokens"
META_REASONING_TOKENS = "reasoning_tokens"
META_AUDIO_INPUT_TOKENS = "audio_input_tokens"
META_AUDIO_OUTPUT_TOKENS = "audio_output_tokens"

# Performance metrics
META_TIME_TO_FIRST_TOKEN = "time_to_first_token"


# ── Decorator input/output keys ──
# Keys used inside span.input / span.output dicts by decorators.

KEY_AGENT_NAME = "agent_name"
KEY_RESULT = "result"


# ── Anthropic wrapper keys ──
# Keys used inside span.input / span.output dicts by the Anthropic integration.

ANTHROPIC_KEY_MODEL = "model"
ANTHROPIC_KEY_SYSTEM = "system"
ANTHROPIC_KEY_TOOLS = "tools"
ANTHROPIC_KEY_MESSAGES = "messages"
ANTHROPIC_KEY_CONTENT = "content"


# ── OpenAI wrapper keys ──
# Keys used inside span.input / span.output dicts by the OpenAI integration.

OPENAI_KEY_MODEL = "model"
OPENAI_KEY_MESSAGES = "messages"
OPENAI_KEY_TOOLS = "tools"
OPENAI_KEY_CONTENT = "content"
OPENAI_KEY_TOOL_CALLS = "tool_calls"
OPENAI_KEY_ROLE = "role"
