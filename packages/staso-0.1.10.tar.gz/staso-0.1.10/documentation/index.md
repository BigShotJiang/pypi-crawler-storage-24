---
title: Python SDK
description: Add observability to your AI agents with Python decorators.
---

# Python SDK

Add observability to your AI agents in under 5 minutes. See every agent run, tool call, and LLM interaction on the Staso dashboard.

```bash
pip install staso
```

## Getting Started

- [Quickstart](/docs/getting-started/quickstart) — Install and trace your first agent
- [Configuration](/docs/configuration/options) — All SDK options
- [Tracing](/docs/guides/tracing) — `@agent`, `@tool`, `@trace`, `st.span()`, annotations
- [Conversations](/docs/guides/conversations) — Group traces into conversations
- [Integrations](/docs/integrations) — Auto-instrument Anthropic, OpenAI
- [Troubleshooting](/docs/troubleshooting) — Common issues and fixes
