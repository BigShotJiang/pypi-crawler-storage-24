import textwrap

class create_file():
    detail_prompt: str = textwrap.dedent("""\
import os.path

from {{JOB_PACKAGE}} import Job
from pilot.job.base.generate.generatePromptBaseJob import GeneratePromptBaseJob
from pilot.job.base.generate.generateTextBaseJob import GenerateTextBaseJob

class {{JOB_NAME}}(GeneratePromptBaseJob):

    def run(self):
        self.template_file_path = ['input','{{SUB_SOURCE_FOLDER}}','{{SUB_SUB_SOURCE_FOLDER_1}}', 'step_010','template.prompt']                                
        self.prompt_file_path = self.file_path + '.prompt'
        self.replace_map = {
            "{{file_content}}": self.get_file_content()
        }
        super().run()
        self.copy_file_and_todo_trg_to_next_step(self.prompt_file_path)
""").strip()
