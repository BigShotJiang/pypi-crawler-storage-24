# ruff: noqa: F403, F405

from .client import RconClient
from .data import *
from .exceptions import *
from .rcon import Rcon
from .responses import *
from .sync import *

__all__ = (
    "CaptureZone",
    "Faction",
    "ForceMode",
    "GameMode",
    "GameModeScale",
    "GetAdminGroupsResponse",
    "GetAdminLogResponse",
    "GetAdminLogResponseEntry",
    "GetAdminUsersResponse",
    "GetAdminUsersResponseEntry",
    "GetAutoBalanceEnabledResponse",
    "GetAutoBalanceThresholdResponse",
    "GetBannedWordsResponse",
    "GetBansResponse",
    "GetBansResponseEntry",
    "GetCommandDetailsResponse",
    "GetCommandDetailsResponseParameter",
    "GetCommandsResponse",
    "GetCommandsResponseEntry",
    "GetHighPingThresholdResponse",
    "GetIdleKickDurationResponse",
    "GetMapRotationResponse",
    "GetMapRotationResponseEntry",
    "GetMapShuffleEnabledResponse",
    "GetPlayerResponse",
    "GetPlayerResponseScoreData",
    "GetPlayerResponseStats",
    "GetPlayerResponseWorldPosition",
    "GetPlayersResponse",
    "GetServerConfigResponse",
    "GetServerSessionResponse",
    "GetTeamSwitchCooldownResponse",
    "GetVipsResponse",
    "GetVipsResponseEntry",
    "GetVoteKickEnabledResponse",
    "GetVoteKickThresholdsResponse",
    "GetVoteKickThresholdsResponseEntry",
    "Grid",
    "HLLAuthError",
    "HLLCommandError",
    "HLLConnectionClosedError",
    "HLLConnectionError",
    "HLLConnectionLostError",
    "HLLConnectionRefusedError",
    "HLLError",
    "HLLMessageError",
    "Layer",
    "Loadout",
    "LoadoutId",
    "LoadoutItem",
    "Map",
    "Orientation",
    "PlayerFactionId",
    "PlayerPlatform",
    "PlayerRoleId",
    "Rcon",
    "RconClient",
    "Response",
    "Role",
    "RoleType",
    "Sector",
    "Strongpoint",
    "SupportedPlatform",
    "SyncRcon",
    "Team",
    "TimeOfDay",
    "Vehicle",
    "VehicleSeat",
    "VehicleSeatType",
    "VehicleType",
    "Weapon",
    "WeaponType",
    "Weather",
    "__version__",
)

# Don't forget to also bump in pyproject.toml
__version__ = "1.2.0.1"

__min_server_version__ = 1088607
"""The minimum supported game server version (build revision). This is the minimum
version that is required for the library to be fully functional. No guarantees can be
made about future versions.

The server's current build revision can be obtained using `Rcon.get_server_config()`.
"""
