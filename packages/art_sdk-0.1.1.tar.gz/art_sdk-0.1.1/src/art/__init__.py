"""
ART — AI Reliability Toolkit
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Runtime observability and reliability for AI agents.

Quick start::

    import art

    # 1. Evaluate any prompt/response pair
    result = art.evaluate(prompt="...", response="...")
    print(result.hallucination_score)

    # 2. Auto-instrument the OpenAI client (call once at startup)
    art.instrument_openai()

    # 3. Group agent steps into a trace
    with art.trace("session-abc"):
        response1 = client.chat.completions.create(...)
        response2 = client.chat.completions.create(...)

    # 4. Enforce a cost budget
    with art.cost_guard(max_usd=0.05):
        response = client.chat.completions.create(...)

"""
from art._config import ARTConfig, get_config, init
from art._context import cost_guard, trace
from art._cost import BudgetExceededError, estimate_cost, estimate_tokens
from art._evaluators import EvaluationResult, evaluate
from art._instrumentation import instrument_anthropic, instrument_openai
from art._langchain import ARTCallbackHandler, instrument_langchain, make_art_callback
from art._quality_gate import QualityGate, QualityGateError
from art._record import EvaluationRecord

__version__ = "0.1.1"
__all__ = [
    # Config
    "init",
    "get_config",
    "ARTConfig",
    # Evaluation
    "evaluate",
    "EvaluationResult",
    # Instrumentation
    "instrument_openai",
    "instrument_anthropic",
    "instrument_langchain",
    "make_art_callback",
    "ARTCallbackHandler",
    # Context managers
    "trace",
    "cost_guard",
    # Cost utilities
    "estimate_cost",
    "estimate_tokens",
    "BudgetExceededError",
    # Quality Gates
    "QualityGate",
    "QualityGateError",
    # Record
    "EvaluationRecord",
]
