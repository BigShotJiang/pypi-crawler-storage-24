from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional

_VALID_EXPORTERS = {"console", "art_cloud", "file", "none"}


@dataclass
class ARTConfig:
    pipeline: str = "default"
    export_to: str = "console"
    art_cloud_url: str = "http://localhost:8000"
    art_cloud_api_key: Optional[str] = None
    file_path: str = "art_evaluations.jsonl"
    max_usd_per_request: Optional[float] = None
    verbose: bool = True

    def __post_init__(self) -> None:
        if self.export_to not in _VALID_EXPORTERS:
            raise ValueError(
                f"export_to must be one of {_VALID_EXPORTERS}, got {self.export_to!r}"
            )


_config: Optional[ARTConfig] = None


def init(
    pipeline: str = "default",
    export_to: str = "console",
    art_cloud_url: str = "http://localhost:8000",
    art_cloud_api_key: Optional[str] = None,
    file_path: str = "art_evaluations.jsonl",
    max_usd_per_request: Optional[float] = None,
    verbose: bool = True,
) -> ARTConfig:
    """Configure the ART SDK. Call once at application startup."""
    global _config
    _config = ARTConfig(
        pipeline=pipeline,
        export_to=export_to,
        art_cloud_url=art_cloud_url,
        art_cloud_api_key=art_cloud_api_key,
        file_path=file_path,
        max_usd_per_request=max_usd_per_request,
        verbose=verbose,
    )
    return _config


def get_config() -> ARTConfig:
    """Return the current config, creating a default one if init() was never called."""
    global _config
    if _config is None:
        _config = ARTConfig()
    return _config
