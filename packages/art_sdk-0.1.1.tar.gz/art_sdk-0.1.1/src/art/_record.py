from __future__ import annotations

import json
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from typing import List, Optional


@dataclass
class EvaluationRecord:
    """A single LLM call + evaluation result, ready to be exported."""

    # Identity
    id: str                    # UUID
    created_at: str            # ISO-8601 UTC

    # Request metadata
    model: str
    pipeline: str
    prompt: str
    response: str
    latency_ms: int
    prompt_tokens: int
    completion_tokens: int
    estimated_cost_usd: float

    # Evaluation scores (0–100)
    confidence_score: float
    hallucination_score: float
    coherence_score: float
    instruction_following_score: float

    # Indicators
    hallucination_indicators: List[str] = field(default_factory=list)
    all_indicators: List[str] = field(default_factory=list)

    # Trace context
    trace_id: Optional[str] = None
    step_index: int = 0
    source: str = "sdk"

    def to_dict(self) -> dict:
        return asdict(self)

    def to_json(self) -> str:
        return json.dumps(self.to_dict())

    @staticmethod
    def now_iso() -> str:
        return datetime.now(timezone.utc).isoformat()
