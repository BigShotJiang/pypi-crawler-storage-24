"""
WZRD Momentum Routing Strategy for LiteLLM.

Adds demand-aware routing to any LiteLLM Router. Models with accelerating
adoption get preferred; models losing traction get deprioritized.

Quick start:
    from litellm import Router
    from wzrd_momentum_strategy import register

    router = Router(model_list=[...])
    register(router)

    # Every subsequent router.completion() call routes via WZRD momentum.
"""

from __future__ import annotations

import re
import sys
import time
import logging
from typing import Any, Dict, List, Optional, Tuple, Union

try:
    from litellm.types.router import CustomRoutingStrategyBase
except ImportError:
    class CustomRoutingStrategyBase:  # type: ignore[no-redef]
        def get_available_deployment(self, *a: Any, **kw: Any) -> Any: ...
        async def async_get_available_deployment(self, *a: Any, **kw: Any) -> Any: ...

logger = logging.getLogger("wzrd_momentum")

WZRD_MOMENTUM_URL = "https://api.twzrd.xyz/v1/signals/momentum"
_CACHE_TTL = 300  # 5 min — momentum updates every 5 min server-side
_cache: Dict[str, Tuple[float, Dict[str, Any]]] = {}

TREND_SCORE: Dict[str, float] = {
    "surging": 3.0,
    "accelerating": 2.0,
    "stable": 0.0,
    "insufficient_history": 0.0,
    "decelerating": -1.0,
    "cooling": -2.0,
}

CONFIDENCE_WEIGHT: Dict[str, float] = {
    "normal": 1.0,
    "low": 0.5,
    "insufficient": 0.0,
}

REQUIRED_MODEL_FIELDS = {
    "model",
    "trend",
    "score",
    "confidence",
}


# ---------------------------------------------------------------------------
# Signal fetching
# ---------------------------------------------------------------------------

def _payload_contract_ok(data: Dict[str, Any]) -> bool:
    """Validate minimum API contract to guard against schema drift."""
    has_version = (
        isinstance(data.get("signal_version"), int)
        or isinstance(data.get("contract_version"), str)
    )
    if not has_version:
        return False
    models = data.get("models")
    if not isinstance(models, list):
        return False
    for model in models:
        if not isinstance(model, dict):
            return False
        if not REQUIRED_MODEL_FIELDS.issubset(model.keys()):
            return False
    return True

def _fetch_momentum(url: str, timeout: float = 5.0) -> Dict[str, Any]:
    """Fetch momentum signals with cache. Never raises."""
    now = time.monotonic()
    cached = _cache.get(url)
    if cached and (now - cached[0]) < _CACHE_TTL:
        return cached[1]

    data: Dict[str, Any] = {}
    try:
        import httpx
        resp = httpx.get(url, timeout=timeout)
        resp.raise_for_status()
        data = resp.json()
    except Exception:
        try:
            import requests as req_lib
            resp = req_lib.get(url, timeout=timeout)  # type: ignore[assignment]
            resp.raise_for_status()
            data = resp.json()
        except Exception as e:
            logger.debug("wzrd: momentum unavailable (%s), using deployment order", e)
            return {}

    if not isinstance(data, dict):
        return {}
    if not _payload_contract_ok(data):
        logger.warning("wzrd: momentum payload contract mismatch, using deployment order fallback")
        return {}
    _cache[url] = (now, data)
    return data


def clear_cache() -> None:
    """Clear the momentum signal cache. Useful for testing."""
    _cache.clear()


# ---------------------------------------------------------------------------
# Model matching
# ---------------------------------------------------------------------------

def _normalize(name: str) -> str:
    """Lowercase, collapse whitespace, strip."""
    return re.sub(r"\s+", " ", name.strip().lower())


# Quant/engine suffixes that local operators append to model names.
# These must be stripped for matching against WZRD's HuggingFace-style names.
_LOCAL_SUFFIXES = re.compile(
    r"[-_]?(q[0-9]+[_-]?k[_-]?[sml]?|gguf|gptq|awq|exl2|fp16|bf16|int[48]|"
    r"local|server|llamacpp|ollama|vllm|mlx|tinygrad|onnx|"
    r"[0-9]+ctx|[0-9]+gpu|ngl[0-9]+)[-_.]?",
    re.IGNORECASE,
)

# Common separators in local aliases that differ from HF naming
_SEP_NORMALIZER = re.compile(r"[-_.\s]+")


def _extract_model_kernel(name: str) -> str:
    """Extract the model family + size kernel from a local alias.

    Strips provider prefixes, quant suffixes, engine tags, and normalizes
    separators so local names like 'qwen3-27b-q4km-local' match against
    HuggingFace names like 'Qwen/Qwen3.5-27B'.

    Examples:
        'openai/qwen3-27b-q4km-local'  → 'qwen3 27b'
        'hermes-3-8b-q4_k_m'           → 'hermes 3 8b'
        'Qwen/Qwen3.5-27B'             → 'qwen3 5 27b'
        'meta-llama/Llama-3.3-70B'      → 'llama 3 3 70b'
    """
    s = name.strip().lower()
    # Strip provider prefix (openai/, openrouter/, ollama/, etc.)
    if "/" in s:
        # Keep last segment, or org/model if only one slash
        parts = s.split("/")
        s = parts[-1] if len(parts) <= 2 else "/".join(parts[-2:])
        # If still has slash, take the last part
        if "/" in s:
            s = s.rsplit("/", 1)[-1]
    # Strip quant/engine suffixes
    s = _LOCAL_SUFFIXES.sub(" ", s)
    # Normalize separators to spaces
    s = _SEP_NORMALIZER.sub(" ", s)
    return s.strip()


def _extract_model_slugs(deployment: Dict[str, Any]) -> List[str]:
    """Extract searchable model name slugs from a LiteLLM deployment dict.

    Tries model_name, litellm_params.model (with provider prefix stripped),
    and the final path segment.
    """
    slugs: List[str] = []

    model_name = deployment.get("model_name", "")
    if model_name:
        slugs.append(_normalize(model_name))

    litellm_model = ""
    params = deployment.get("litellm_params")
    if isinstance(params, dict):
        litellm_model = params.get("model", "")

    if litellm_model:
        slugs.append(_normalize(litellm_model))
        # Strip provider prefix: "openrouter/qwen/qwen-3.5-9b" -> "qwen/qwen-3.5-9b"
        parts = litellm_model.split("/", 1)
        if len(parts) == 2:
            slugs.append(_normalize(parts[1]))
        # Last segment only: "qwen-3.5-9b"
        last = litellm_model.rsplit("/", 1)[-1]
        if last:
            slugs.append(_normalize(last))

    return list(dict.fromkeys(slugs))  # dedupe, preserve order


def _find_signal(
    deployment: Dict[str, Any],
    models: List[Dict[str, Any]],
    alias_map: Dict[str, List[str]],
) -> Optional[Dict[str, Any]]:
    """Find the best matching WZRD signal for a deployment."""
    model_name = deployment.get("model_name", "")

    # 1. Explicit alias map (highest priority)
    wzrd_names = alias_map.get(model_name, [])
    if wzrd_names:
        for wzrd_name in wzrd_names:
            wzrd_lower = _normalize(wzrd_name)
            for m in models:
                if _normalize(m.get("model", "")) == wzrd_lower:
                    return m
        # Substring fallback for alias map entries
        for wzrd_name in wzrd_names:
            wzrd_lower = _normalize(wzrd_name)
            for m in models:
                if wzrd_lower in _normalize(m.get("model", "")):
                    return m

    # 2. Auto-match using deployment slugs (exact)
    slugs = _extract_model_slugs(deployment)
    for slug in slugs:
        for m in models:
            m_norm = _normalize(m.get("model", ""))
            if slug == m_norm:
                return m
    # Substring match (less precise, still useful)
    for slug in slugs:
        if len(slug) < 4:  # skip very short slugs to avoid false positives
            continue
        for m in models:
            m_norm = _normalize(m.get("model", ""))
            if slug in m_norm or m_norm in slug:
                return m

    # 3. Kernel match — strips quant suffixes, engine tags, and normalizes separators.
    # This catches local aliases like 'qwen3-27b-q4km-local' matching 'Qwen/Qwen3.5-27B'.
    dep_kernels = [_extract_model_kernel(s) for s in slugs]
    dep_kernels = [k for k in dep_kernels if len(k) >= 4]  # skip tiny kernels

    if dep_kernels:
        best_match: Optional[Dict[str, Any]] = None
        best_overlap = 0

        for m in models:
            m_kernel = _extract_model_kernel(m.get("model", ""))
            if not m_kernel:
                continue
            m_tokens = set(m_kernel.split())

            for dk in dep_kernels:
                dk_tokens = set(dk.split())
                # Count overlapping tokens (both directions)
                overlap = len(dk_tokens & m_tokens)
                # Require at least 2 matching tokens (family + size) to avoid false positives
                if overlap >= 2 and overlap > best_overlap:
                    best_overlap = overlap
                    best_match = m

        if best_match:
            logger.debug(
                "wzrd: kernel match: %s → %s (overlap=%d tokens)",
                model_name, best_match.get("model", "?"), best_overlap,
            )
            return best_match

    return None


# ---------------------------------------------------------------------------
# Scoring
# ---------------------------------------------------------------------------

def _score_deployment(
    deployment: Dict[str, Any],
    momentum_data: Dict[str, Any],
    alias_map: Dict[str, List[str]],
    index: int,
) -> Tuple[float, Optional[Dict[str, Any]]]:
    """Score a deployment. Returns (score, matched_signal)."""
    models = momentum_data.get("models", [])
    if not models:
        return (-0.001 * index, None)

    signal = _find_signal(deployment, models, alias_map)
    if signal is None:
        return (-0.001 * index, None)

    trend = signal.get("trend", signal.get("velocity_trend", "stable"))
    momentum = signal.get("score", signal.get("momentum_score", 0.0))
    delta_pct = signal.get("velocity_delta_pct", 0.0)
    confidence = signal.get("confidence", signal.get("history_confidence", "insufficient"))

    cw = CONFIDENCE_WEIGHT.get(confidence, 0.0)
    trend_component = TREND_SCORE.get(trend, 0.0) * cw
    momentum_component = min(max(momentum, 0.0), 1.0) * 0.3 * cw
    delta_component = max(-2.0, min(2.0, delta_pct / 100.0)) * 0.25 * cw

    return (trend_component + momentum_component + delta_component, signal)


# ---------------------------------------------------------------------------
# Strategy
# ---------------------------------------------------------------------------

class WZRDMomentumStrategy(CustomRoutingStrategyBase):
    """Routes LiteLLM requests to models with the highest WZRD momentum.

    Fetches attention velocity signals from the WZRD API, scores each
    deployment in the Router's model_list. Models with accelerating
    adoption (surging/accelerating) get preferred. Models losing
    traction (cooling/decelerating) get deprioritized.

    Trust controls:
        fallback_model: Model to use when WZRD is unreachable or no signal matches.
        allowed_models: Only consider these model names. Others are skipped.
        dry_run: Log what WZRD would pick, but return the original model unchanged.
        task: Hint for task-specific routing ("code", "chat", "cheap", "general").

    Falls back to fallback_model (or first deployment) if WZRD is unreachable.
    """

    def __init__(
        self,
        router: Any,
        wzrd_url: str = WZRD_MOMENTUM_URL,
        alias_map: Optional[Dict[str, List[str]]] = None,
        cache_ttl: int = _CACHE_TTL,
        fallback_model: Optional[str] = None,
        allowed_models: Optional[List[str]] = None,
        dry_run: bool = False,
        task: str = "general",
    ):
        self.router = router
        self.wzrd_url = wzrd_url
        self.alias_map = alias_map or {}
        self.fallback_model = fallback_model
        self.allowed_models = set(allowed_models) if allowed_models else None
        self.dry_run = dry_run
        self.task = task
        global _CACHE_TTL
        _CACHE_TTL = cache_ttl

    def _get_fallback(self, candidates: List[Dict]) -> Optional[Dict]:
        """Return the fallback deployment — explicit fallback_model or first candidate."""
        if self.fallback_model:
            for d in candidates:
                if d.get("model_name", "") == self.fallback_model:
                    return d
        return candidates[0] if candidates else None

    def _select_deployment(
        self,
        model: str,
        messages: Optional[List[Dict[str, str]]] = None,
        input: Optional[Union[str, List]] = None,
        specific_deployment: Optional[bool] = False,
        request_kwargs: Optional[Dict] = None,
    ) -> Optional[Dict]:
        model_list = getattr(self.router, "model_list", [])
        if not model_list:
            return None

        candidates = [d for d in model_list if d.get("model_name", "") == model]
        if not candidates:
            candidates = model_list

        # Apply allowlist filter
        if self.allowed_models:
            filtered = [d for d in candidates if d.get("model_name", "") in self.allowed_models]
            if filtered:
                candidates = filtered
            else:
                logger.debug("wzrd: no candidates match allowlist, using all")

        if len(candidates) == 1:
            only = candidates[0]
            logger.info(
                "wzrd: %s (only candidate) | task=%s",
                only.get("model_name", "?"), self.task,
            )
            return only

        # Fetch momentum — append task hint for task-specific ranking
        url = self.wzrd_url
        if self.task and self.task != "general":
            sep = "&" if "?" in url else "?"
            url = f"{url}{sep}task={self.task}"
        momentum = _fetch_momentum(url)

        if not momentum.get("models"):
            fallback = self._get_fallback(candidates)
            fb_name = fallback.get("model_name", "?") if fallback else "none"
            logger.info(
                "wzrd: API unavailable → fallback=%s | task=%s",
                fb_name, self.task,
            )
            return fallback

        scored = []
        for i, deployment in enumerate(candidates):
            score, signal = _score_deployment(deployment, momentum, self.alias_map, i)
            scored.append((score, i, deployment, signal))

        # Warn about unmatched models — this is the #1 adoption blocker for local operators
        unmatched = [s[2].get("model_name", "?") for s in scored if s[3] is None]
        matched = [s[2].get("model_name", "?") for s in scored if s[3] is not None]
        if unmatched:
            if not matched:
                # ALL models unmatched — routing is fake, warn loudly
                logger.warning(
                    "wzrd: NO models matched WZRD signals. Routing is falling back to "
                    "deployment order (first-in-list). Unmatched: [%s]. Fix: add an "
                    "alias_map or use HuggingFace-style names.",
                    ", ".join(unmatched),
                )
            else:
                logger.info(
                    "wzrd: %d/%d models matched signals. Unmatched: [%s]. "
                    "Consider adding alias_map entries for better coverage.",
                    len(matched), len(scored), ", ".join(unmatched),
                )

        scored.sort(key=lambda x: (x[0], -x[1]), reverse=True)
        best = scored[0]
        runner_up = scored[1] if len(scored) > 1 else None

        best_name = best[2].get("model_name", "?")
        best_trend = best[3].get("trend", best[3].get("velocity_trend", "?")) if best[3] else "no-signal"
        best_score = best[0]

        # Structured log line — one per request, shows what was picked and why
        if runner_up:
            ru_name = runner_up[2].get("model_name", "?")
            ru_score = runner_up[0]
            log_msg = (
                "wzrd: picked %s (score=%.2f, %s) over %s (score=%.2f) | "
                "task=%s | candidates=%d | fallback=%s | dry_run=%s"
            )
            log_args = (
                best_name, best_score, best_trend,
                ru_name, ru_score,
                self.task, len(candidates),
                self.fallback_model or "first-in-list",
                self.dry_run,
            )
        else:
            log_msg = (
                "wzrd: picked %s (score=%.2f, %s) | "
                "task=%s | candidates=%d | dry_run=%s"
            )
            log_args = (
                best_name, best_score, best_trend,
                self.task, len(candidates), self.dry_run,
            )

        logger.info(log_msg, *log_args)

        # Dry run: log the pick but return the original/fallback model unchanged
        if self.dry_run:
            fallback = self._get_fallback(candidates)
            fb_name = fallback.get("model_name", "?") if fallback else "none"
            logger.info(
                "wzrd: [DRY RUN] would pick %s, actually using %s",
                best_name, fb_name,
            )
            return fallback

        return best[2]

    def get_available_deployment(
        self,
        model: str,
        messages: Optional[List[Dict[str, str]]] = None,
        input: Optional[Union[str, List]] = None,
        specific_deployment: Optional[bool] = False,
        request_kwargs: Optional[Dict] = None,
    ) -> Optional[Dict]:
        return self._select_deployment(model, messages, input, specific_deployment, request_kwargs)

    async def async_get_available_deployment(
        self,
        model: str,
        messages: Optional[List[Dict[str, str]]] = None,
        input: Optional[Union[str, List]] = None,
        specific_deployment: Optional[bool] = False,
        request_kwargs: Optional[Dict] = None,
    ) -> Optional[Dict]:
        return self._select_deployment(model, messages, input, specific_deployment, request_kwargs)


# ---------------------------------------------------------------------------
# Convenience
# ---------------------------------------------------------------------------

def register(
    router: Any,
    wzrd_url: str = WZRD_MOMENTUM_URL,
    alias_map: Optional[Dict[str, List[str]]] = None,
    cache_ttl: int = 300,
    fallback_model: Optional[str] = None,
    allowed_models: Optional[List[str]] = None,
    dry_run: bool = False,
    task: str = "general",
) -> WZRDMomentumStrategy:
    """One-liner registration. Returns the strategy instance for inspection.

    Usage:
        from wzrd_momentum_strategy import register

        # Basic — just route smarter
        register(router)

        # Safe trial — see what WZRD would pick without changing anything
        register(router, dry_run=True)

        # Constrained — only allow these models, fall back to gpt-4o
        register(router, allowed_models=["gpt-4o", "qwen-9b"], fallback_model="gpt-4o")

        # Task-specific — optimize for code workloads
        register(router, task="code")
    """
    strategy = WZRDMomentumStrategy(
        router,
        wzrd_url=wzrd_url,
        alias_map=alias_map,
        cache_ttl=cache_ttl,
        fallback_model=fallback_model,
        allowed_models=allowed_models,
        dry_run=dry_run,
        task=task,
    )
    router.set_custom_routing_strategy(strategy)
    return strategy
