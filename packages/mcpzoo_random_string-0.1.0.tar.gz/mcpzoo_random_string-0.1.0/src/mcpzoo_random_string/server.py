import random
import string
from mcp.server.fastmcp import FastMCP

mcp = FastMCP("random-string")


@mcp.tool()
def gen_random_string(length: int = 16, charset: str = "alphanumeric") -> str:
    """生成指定长度和字符集的随机字符串。
    
    charset可选: alphanumeric, alpha, numeric, hex, all
    """
    if length < 1 or length > 10000:
        return "长度需要在 1-10000 之间"
        
    if charset == "alphanumeric":
        chars = string.ascii_letters + string.digits
    elif charset == "alpha":
        chars = string.ascii_letters
    elif charset == "numeric":
        chars = string.digits
    elif charset == "hex":
        chars = string.hexdigits.lower()
    elif charset == "all":
        chars = string.ascii_letters + string.digits + string.punctuation
    else:
        # 允许传入自定义字符集
        chars = charset
        
    return "".join(random.choice(chars) for _ in range(length))


def main():
    mcp.run()


if __name__ == "__main__":
    main()
