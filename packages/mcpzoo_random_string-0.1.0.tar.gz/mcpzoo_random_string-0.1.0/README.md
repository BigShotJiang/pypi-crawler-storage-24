# mcpzoo-random-string

> 随机字符串 — 生成指定长度和字符集的随机字符串

## Installation

```bash
uvx mcpzoo-random-string
```

## uvx JSON

```json
{
  "mcpServers": {
    "random-string": {
      "args": ["mcpzoo-random-string"],
      "command": "uvx"
    }
  }
}
```
