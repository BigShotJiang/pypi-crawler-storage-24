"""
ifcfill — Transform tabular data into Integer, Float and Categorical (IFC)
variables and fill/impute missing data.
"""

from ._transformer import IFCTransformer

__version__ = "0.1.0"
__all__ = ["IFCTransformer"]
