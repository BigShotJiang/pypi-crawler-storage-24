# GraphTy

Typed Views over RDF Graph data.
