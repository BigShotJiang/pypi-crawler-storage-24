#include <stdint.h>
// copyright ############################### //
// This file is part of the Xtrack Package.  //
// Copyright (c) CERN, 2021.                 //
// ######################################### //

#ifndef XTRACK_CONSTANTS_H
#define XTRACK_CONSTANTS_H

#if !defined( C_LIGHT )
    #define   C_LIGHT ( 299792458.0 )
#endif /* !defined( C_LIGHT ) */

#if !defined( EPSILON_0 )
    #define   EPSILON_0 (8.854187817620e-12)
#endif /* !defined( EPSILON_0 ) */

#if !defined( PI )
    #define PI (3.1415926535897932384626433832795028841971693993751)
#endif /* !defined( PI ) */

#if !defined( MU_0 )
    #define MU_0 (PI*4.0e-7)
#endif /* !defined( MU_0 ) */

#if !defined( DEG2RAD )
    #define DEG2RAD (0.0174532925199432957692369076848861271344287188854)
#endif /* !defiend( DEG2RAD ) */

#if !defined( RAD2DEG )
    #define RAD2DEG (57.29577951308232087679815481410517033240547246656442)
#endif /* !defiend( RAD2DEG ) */

#if !defined( SQRT_PI )
    #define SQRT_PI (1.7724538509055160272981674833411451827975494561224)
#endif /* !defined( SQRT_PI ) */

#if !defined( QELEM )
    #define QELEM (1.60217662e-19)
#endif /* !defined( QELEM ) */

#if !defined( DBL_MAX )
    #define DBL_MAX (1.7976931348623158e+308)
#endif /* !defined( DBL_MAX ) */

#if !defined( DBL_MIN )
    #define DBL_MIN (2.2250738585072014e-308)
#endif /* !defined( DBL_MIN ) */

#if !defined( DBL_EPSILON )
    #define DBL_EPSILON (2.2204460492503131e-16)
#endif /* !defined( DBL_EPSILON ) */

#if !defined( RADIUS_ELECTRON )
    #define RADIUS_ELECTRON (2.8179403262e-15)
#endif /* !defined( RADIUS_ELECTRON ) */

#if !defined( MASS_ELECTRON )
    #define MASS_ELECTRON (9.1093837e-31)
#endif /* !defined( MASS_ELECTRON ) */

#if !defined( SQRT3 )
    #define SQRT3 1.732050807568877
#endif /* !defined( SQRT3 ) */

#if !defined( SQRT2 )
    #define SQRT2 (1.414213562373095048801688724209698078569671875376948073176679738)
#endif /* !defined( SQRT2 ) */

#if !defined( TWO_OVER_SQRT_PI )
    #define TWO_OVER_SQRT_PI (1.128379167095512573896158903121545171688101258657997713688171443418)
#endif /* !defined( TWO_OVER_SQRT_PI ) */

#if !defined( ALPHA_EM )
    #define ALPHA_EM 0.0072973525693
#endif /* !defined( ALPHA_EM ) */

#endif /* XTRACK_CONSTANTS_H */


#ifndef XSUITE_TRACK_FLAGS_H
#define XSUITE_TRACK_FLAGS_H
#define XS_FLAG_BACKTRACK (0)
#define XS_FLAG_KILL_CAVITY_KICK (2)
#define XS_FLAG_IGNORE_GLOBAL_APERTURE (3)
#define XS_FLAG_IGNORE_LOCAL_APERTURE (4)
#define XS_FLAG_SR_TAPER (5)
#define XS_FLAG_SR_KICK_SAME_AS_FIRST (6)

#endif // XSUITE_TRACK_FLAGS_H

#ifndef XOBJ_TYPEDEF_ArrNInt64
#define XOBJ_TYPEDEF_ArrNInt64
typedef   struct ArrNInt64_s * ArrNInt64;
 static inline ArrNInt64 ArrNInt64_getp(ArrNInt64 restrict  obj){
  int64_t offset=0;
  return (ArrNInt64)(( char*) obj+offset);
}
 static inline int64_t ArrNInt64_len(ArrNInt64 restrict  obj){
  int64_t offset=0;
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  return arr[1];
}
 static inline void ArrNInt64_shape(ArrNInt64 restrict  obj,  int64_t* restrict  out_shape){
  int64_t offset=0;
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  out_shape[0] = arr[1];
}
 static inline uint32_t ArrNInt64_nd(ArrNInt64 restrict  obj){
  return 1;
}
 static inline int64_t ArrNInt64_get(const ArrNInt64 restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=16+i0*8;
  return *( int64_t*)(( char*) obj+offset);
}
 static inline void ArrNInt64_set(ArrNInt64 restrict  obj, int64_t i0, int64_t value){
  int64_t offset=0;
  offset+=16+i0*8;
  *( int64_t*)(( char*) obj+offset)=value;
}
 static inline  int64_t* ArrNInt64_getp1(ArrNInt64 restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=16+i0*8;
  return ( int64_t*)(( char*) obj+offset);
}
#endif
#ifndef XOBJ_TYPEDEF_LongitudinalProfileQGaussianData
#define XOBJ_TYPEDEF_LongitudinalProfileQGaussianData
typedef   struct LongitudinalProfileQGaussianData_s * LongitudinalProfileQGaussianData;
 static inline LongitudinalProfileQGaussianData LongitudinalProfileQGaussianData_getp(LongitudinalProfileQGaussianData restrict  obj){
  int64_t offset=0;
  return (LongitudinalProfileQGaussianData)(( char*) obj+offset);
}
 static inline double LongitudinalProfileQGaussianData_get_number_of_particles(const LongitudinalProfileQGaussianData restrict  obj){
  int64_t offset=0;
  return *( double*)(( char*) obj+offset);
}
 static inline void LongitudinalProfileQGaussianData_set_number_of_particles(LongitudinalProfileQGaussianData restrict  obj, double value){
  int64_t offset=0;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* LongitudinalProfileQGaussianData_getp_number_of_particles(LongitudinalProfileQGaussianData restrict  obj){
  int64_t offset=0;
  return ( double*)(( char*) obj+offset);
}
 static inline double LongitudinalProfileQGaussianData_get__q_tol(const LongitudinalProfileQGaussianData restrict  obj){
  int64_t offset=0;
  offset+=8;
  return *( double*)(( char*) obj+offset);
}
 static inline void LongitudinalProfileQGaussianData_set__q_tol(LongitudinalProfileQGaussianData restrict  obj, double value){
  int64_t offset=0;
  offset+=8;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* LongitudinalProfileQGaussianData_getp__q_tol(LongitudinalProfileQGaussianData restrict  obj){
  int64_t offset=0;
  offset+=8;
  return ( double*)(( char*) obj+offset);
}
 static inline double LongitudinalProfileQGaussianData_get__z0(const LongitudinalProfileQGaussianData restrict  obj){
  int64_t offset=0;
  offset+=16;
  return *( double*)(( char*) obj+offset);
}
 static inline void LongitudinalProfileQGaussianData_set__z0(LongitudinalProfileQGaussianData restrict  obj, double value){
  int64_t offset=0;
  offset+=16;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* LongitudinalProfileQGaussianData_getp__z0(LongitudinalProfileQGaussianData restrict  obj){
  int64_t offset=0;
  offset+=16;
  return ( double*)(( char*) obj+offset);
}
 static inline double LongitudinalProfileQGaussianData_get__sigma_z(const LongitudinalProfileQGaussianData restrict  obj){
  int64_t offset=0;
  offset+=24;
  return *( double*)(( char*) obj+offset);
}
 static inline void LongitudinalProfileQGaussianData_set__sigma_z(LongitudinalProfileQGaussianData restrict  obj, double value){
  int64_t offset=0;
  offset+=24;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* LongitudinalProfileQGaussianData_getp__sigma_z(LongitudinalProfileQGaussianData restrict  obj){
  int64_t offset=0;
  offset+=24;
  return ( double*)(( char*) obj+offset);
}
 static inline double LongitudinalProfileQGaussianData_get__q_param(const LongitudinalProfileQGaussianData restrict  obj){
  int64_t offset=0;
  offset+=32;
  return *( double*)(( char*) obj+offset);
}
 static inline void LongitudinalProfileQGaussianData_set__q_param(LongitudinalProfileQGaussianData restrict  obj, double value){
  int64_t offset=0;
  offset+=32;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* LongitudinalProfileQGaussianData_getp__q_param(LongitudinalProfileQGaussianData restrict  obj){
  int64_t offset=0;
  offset+=32;
  return ( double*)(( char*) obj+offset);
}
 static inline double LongitudinalProfileQGaussianData_get__cq_param(const LongitudinalProfileQGaussianData restrict  obj){
  int64_t offset=0;
  offset+=40;
  return *( double*)(( char*) obj+offset);
}
 static inline void LongitudinalProfileQGaussianData_set__cq_param(LongitudinalProfileQGaussianData restrict  obj, double value){
  int64_t offset=0;
  offset+=40;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* LongitudinalProfileQGaussianData_getp__cq_param(LongitudinalProfileQGaussianData restrict  obj){
  int64_t offset=0;
  offset+=40;
  return ( double*)(( char*) obj+offset);
}
 static inline double LongitudinalProfileQGaussianData_get__beta_param(const LongitudinalProfileQGaussianData restrict  obj){
  int64_t offset=0;
  offset+=48;
  return *( double*)(( char*) obj+offset);
}
 static inline void LongitudinalProfileQGaussianData_set__beta_param(LongitudinalProfileQGaussianData restrict  obj, double value){
  int64_t offset=0;
  offset+=48;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* LongitudinalProfileQGaussianData_getp__beta_param(LongitudinalProfileQGaussianData restrict  obj){
  int64_t offset=0;
  offset+=48;
  return ( double*)(( char*) obj+offset);
}
 static inline double LongitudinalProfileQGaussianData_get__sqrt_beta_param(const LongitudinalProfileQGaussianData restrict  obj){
  int64_t offset=0;
  offset+=56;
  return *( double*)(( char*) obj+offset);
}
 static inline void LongitudinalProfileQGaussianData_set__sqrt_beta_param(LongitudinalProfileQGaussianData restrict  obj, double value){
  int64_t offset=0;
  offset+=56;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* LongitudinalProfileQGaussianData_getp__sqrt_beta_param(LongitudinalProfileQGaussianData restrict  obj){
  int64_t offset=0;
  offset+=56;
  return ( double*)(( char*) obj+offset);
}
 static inline double LongitudinalProfileQGaussianData_get__support_min(const LongitudinalProfileQGaussianData restrict  obj){
  int64_t offset=0;
  offset+=64;
  return *( double*)(( char*) obj+offset);
}
 static inline void LongitudinalProfileQGaussianData_set__support_min(LongitudinalProfileQGaussianData restrict  obj, double value){
  int64_t offset=0;
  offset+=64;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* LongitudinalProfileQGaussianData_getp__support_min(LongitudinalProfileQGaussianData restrict  obj){
  int64_t offset=0;
  offset+=64;
  return ( double*)(( char*) obj+offset);
}
 static inline double LongitudinalProfileQGaussianData_get__support_max(const LongitudinalProfileQGaussianData restrict  obj){
  int64_t offset=0;
  offset+=72;
  return *( double*)(( char*) obj+offset);
}
 static inline void LongitudinalProfileQGaussianData_set__support_max(LongitudinalProfileQGaussianData restrict  obj, double value){
  int64_t offset=0;
  offset+=72;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* LongitudinalProfileQGaussianData_getp__support_max(LongitudinalProfileQGaussianData restrict  obj){
  int64_t offset=0;
  offset+=72;
  return ( double*)(( char*) obj+offset);
}
#endif
#include "xfields/longitudinal_profiles/qgaussian_src/qgaussian.h"
#ifndef XOBJ_TYPEDEF_ArrNFloat64
#define XOBJ_TYPEDEF_ArrNFloat64
typedef   struct ArrNFloat64_s * ArrNFloat64;
 static inline ArrNFloat64 ArrNFloat64_getp(ArrNFloat64 restrict  obj){
  int64_t offset=0;
  return (ArrNFloat64)(( char*) obj+offset);
}
 static inline int64_t ArrNFloat64_len(ArrNFloat64 restrict  obj){
  int64_t offset=0;
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  return arr[1];
}
 static inline void ArrNFloat64_shape(ArrNFloat64 restrict  obj,  int64_t* restrict  out_shape){
  int64_t offset=0;
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  out_shape[0] = arr[1];
}
 static inline uint32_t ArrNFloat64_nd(ArrNFloat64 restrict  obj){
  return 1;
}
 static inline double ArrNFloat64_get(const ArrNFloat64 restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=16+i0*8;
  return *( double*)(( char*) obj+offset);
}
 static inline void ArrNFloat64_set(ArrNFloat64 restrict  obj, int64_t i0, double value){
  int64_t offset=0;
  offset+=16+i0*8;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* ArrNFloat64_getp1(ArrNFloat64 restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=16+i0*8;
  return ( double*)(( char*) obj+offset);
}
#endif
#ifndef XOBJ_TYPEDEF_ArrNxMxOFloat64
#define XOBJ_TYPEDEF_ArrNxMxOFloat64
typedef   struct ArrNxMxOFloat64_s * ArrNxMxOFloat64;
 static inline ArrNxMxOFloat64 ArrNxMxOFloat64_getp(ArrNxMxOFloat64 restrict  obj){
  int64_t offset=0;
  return (ArrNxMxOFloat64)(( char*) obj+offset);
}
 static inline int64_t ArrNxMxOFloat64_len(ArrNxMxOFloat64 restrict  obj){
  int64_t offset=0;
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  return arr[1]*arr[2]*arr[3];
}
 static inline void ArrNxMxOFloat64_shape(ArrNxMxOFloat64 restrict  obj,  int64_t* restrict  out_shape){
  int64_t offset=0;
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  out_shape[0] = arr[1];
  out_shape[1] = arr[2];
  out_shape[2] = arr[3];
}
 static inline uint32_t ArrNxMxOFloat64_nd(ArrNxMxOFloat64 restrict  obj){
  return 3;
}
 static inline double ArrNxMxOFloat64_get(const ArrNxMxOFloat64 restrict  obj, int64_t i0, int64_t i1, int64_t i2){
  int64_t offset=0;
  int64_t ArrNxMxOFloat64_s0=*( int64_t*)(( char*) obj+offset+32);
  int64_t ArrNxMxOFloat64_s1=*( int64_t*)(( char*) obj+offset+40);
  int64_t ArrNxMxOFloat64_s2=*( int64_t*)(( char*) obj+offset+48);
  offset+=56+i0*ArrNxMxOFloat64_s0+i1*ArrNxMxOFloat64_s1+i2*ArrNxMxOFloat64_s2;
  return *( double*)(( char*) obj+offset);
}
 static inline void ArrNxMxOFloat64_set(ArrNxMxOFloat64 restrict  obj, int64_t i0, int64_t i1, int64_t i2, double value){
  int64_t offset=0;
  int64_t ArrNxMxOFloat64_s0=*( int64_t*)(( char*) obj+offset+32);
  int64_t ArrNxMxOFloat64_s1=*( int64_t*)(( char*) obj+offset+40);
  int64_t ArrNxMxOFloat64_s2=*( int64_t*)(( char*) obj+offset+48);
  offset+=56+i0*ArrNxMxOFloat64_s0+i1*ArrNxMxOFloat64_s1+i2*ArrNxMxOFloat64_s2;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* ArrNxMxOFloat64_getp3(ArrNxMxOFloat64 restrict  obj, int64_t i0, int64_t i1, int64_t i2){
  int64_t offset=0;
  int64_t ArrNxMxOFloat64_s0=*( int64_t*)(( char*) obj+offset+32);
  int64_t ArrNxMxOFloat64_s1=*( int64_t*)(( char*) obj+offset+40);
  int64_t ArrNxMxOFloat64_s2=*( int64_t*)(( char*) obj+offset+48);
  offset+=56+i0*ArrNxMxOFloat64_s0+i1*ArrNxMxOFloat64_s1+i2*ArrNxMxOFloat64_s2;
  return ( double*)(( char*) obj+offset);
}
#endif
#ifndef XOBJ_TYPEDEF_ArrNxMxOxPFloat64
#define XOBJ_TYPEDEF_ArrNxMxOxPFloat64
typedef   struct ArrNxMxOxPFloat64_s * ArrNxMxOxPFloat64;
 static inline ArrNxMxOxPFloat64 ArrNxMxOxPFloat64_getp(ArrNxMxOxPFloat64 restrict  obj){
  int64_t offset=0;
  return (ArrNxMxOxPFloat64)(( char*) obj+offset);
}
 static inline int64_t ArrNxMxOxPFloat64_len(ArrNxMxOxPFloat64 restrict  obj){
  int64_t offset=0;
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  return arr[1]*arr[2]*arr[3]*arr[4];
}
 static inline void ArrNxMxOxPFloat64_shape(ArrNxMxOxPFloat64 restrict  obj,  int64_t* restrict  out_shape){
  int64_t offset=0;
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  out_shape[0] = arr[1];
  out_shape[1] = arr[2];
  out_shape[2] = arr[3];
  out_shape[3] = arr[4];
}
 static inline uint32_t ArrNxMxOxPFloat64_nd(ArrNxMxOxPFloat64 restrict  obj){
  return 4;
}
 static inline double ArrNxMxOxPFloat64_get(const ArrNxMxOxPFloat64 restrict  obj, int64_t i0, int64_t i1, int64_t i2, int64_t i3){
  int64_t offset=0;
  int64_t ArrNxMxOxPFloat64_s0=*( int64_t*)(( char*) obj+offset+40);
  int64_t ArrNxMxOxPFloat64_s1=*( int64_t*)(( char*) obj+offset+48);
  int64_t ArrNxMxOxPFloat64_s2=*( int64_t*)(( char*) obj+offset+56);
  int64_t ArrNxMxOxPFloat64_s3=*( int64_t*)(( char*) obj+offset+64);
  offset+=72+i0*ArrNxMxOxPFloat64_s0+i1*ArrNxMxOxPFloat64_s1+i2*ArrNxMxOxPFloat64_s2+i3*ArrNxMxOxPFloat64_s3;
  return *( double*)(( char*) obj+offset);
}
 static inline void ArrNxMxOxPFloat64_set(ArrNxMxOxPFloat64 restrict  obj, int64_t i0, int64_t i1, int64_t i2, int64_t i3, double value){
  int64_t offset=0;
  int64_t ArrNxMxOxPFloat64_s0=*( int64_t*)(( char*) obj+offset+40);
  int64_t ArrNxMxOxPFloat64_s1=*( int64_t*)(( char*) obj+offset+48);
  int64_t ArrNxMxOxPFloat64_s2=*( int64_t*)(( char*) obj+offset+56);
  int64_t ArrNxMxOxPFloat64_s3=*( int64_t*)(( char*) obj+offset+64);
  offset+=72+i0*ArrNxMxOxPFloat64_s0+i1*ArrNxMxOxPFloat64_s1+i2*ArrNxMxOxPFloat64_s2+i3*ArrNxMxOxPFloat64_s3;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* ArrNxMxOxPFloat64_getp4(ArrNxMxOxPFloat64 restrict  obj, int64_t i0, int64_t i1, int64_t i2, int64_t i3){
  int64_t offset=0;
  int64_t ArrNxMxOxPFloat64_s0=*( int64_t*)(( char*) obj+offset+40);
  int64_t ArrNxMxOxPFloat64_s1=*( int64_t*)(( char*) obj+offset+48);
  int64_t ArrNxMxOxPFloat64_s2=*( int64_t*)(( char*) obj+offset+56);
  int64_t ArrNxMxOxPFloat64_s3=*( int64_t*)(( char*) obj+offset+64);
  offset+=72+i0*ArrNxMxOxPFloat64_s0+i1*ArrNxMxOxPFloat64_s1+i2*ArrNxMxOxPFloat64_s2+i3*ArrNxMxOxPFloat64_s3;
  return ( double*)(( char*) obj+offset);
}
#endif
#ifndef XOBJ_TYPEDEF_ArrNUint32
#define XOBJ_TYPEDEF_ArrNUint32
typedef   struct ArrNUint32_s * ArrNUint32;
 static inline ArrNUint32 ArrNUint32_getp(ArrNUint32 restrict  obj){
  int64_t offset=0;
  return (ArrNUint32)(( char*) obj+offset);
}
 static inline int64_t ArrNUint32_len(ArrNUint32 restrict  obj){
  int64_t offset=0;
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  return arr[1];
}
 static inline void ArrNUint32_shape(ArrNUint32 restrict  obj,  int64_t* restrict  out_shape){
  int64_t offset=0;
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  out_shape[0] = arr[1];
}
 static inline uint32_t ArrNUint32_nd(ArrNUint32 restrict  obj){
  return 1;
}
 static inline uint32_t ArrNUint32_get(const ArrNUint32 restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=16+i0*4;
  return *( uint32_t*)(( char*) obj+offset);
}
 static inline void ArrNUint32_set(ArrNUint32 restrict  obj, int64_t i0, uint32_t value){
  int64_t offset=0;
  offset+=16+i0*4;
  *( uint32_t*)(( char*) obj+offset)=value;
}
 static inline  uint32_t* ArrNUint32_getp1(ArrNUint32 restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=16+i0*4;
  return ( uint32_t*)(( char*) obj+offset);
}
#endif
#ifndef XOBJ_TYPEDEF_ArrNString
#define XOBJ_TYPEDEF_ArrNString
typedef   struct ArrNString_s * ArrNString;
 static inline ArrNString ArrNString_getp(ArrNString restrict  obj){
  int64_t offset=0;
  return (ArrNString)(( char*) obj+offset);
}
 static inline int64_t ArrNString_len(ArrNString restrict  obj){
  int64_t offset=0;
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  return arr[1];
}
 static inline void ArrNString_shape(ArrNString restrict  obj,  int64_t* restrict  out_shape){
  int64_t offset=0;
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  out_shape[0] = arr[1];
}
 static inline uint32_t ArrNString_nd(ArrNString restrict  obj){
  return 1;
}
 static inline  char* ArrNString_getp1(ArrNString restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+16+i0*8);
  return ( char*)(( char*) obj+offset);
}
#endif
#ifndef XOBJ_TYPEDEF_MultiSetterData
#define XOBJ_TYPEDEF_MultiSetterData
typedef   struct MultiSetterData_s * MultiSetterData;
 static inline MultiSetterData MultiSetterData_getp(MultiSetterData restrict  obj){
  int64_t offset=0;
  return (MultiSetterData)(( char*) obj+offset);
}
 static inline ArrNInt64 MultiSetterData_getp_offsets(MultiSetterData restrict  obj){
  int64_t offset=0;
  offset+=8;
  return (ArrNInt64)(( char*) obj+offset);
}
 static inline int64_t MultiSetterData_len_offsets(MultiSetterData restrict  obj){
  int64_t offset=0;
  offset+=8;
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  return arr[1];
}
 static inline void MultiSetterData_shape_offsets(MultiSetterData restrict  obj,  int64_t* restrict  out_shape){
  int64_t offset=0;
  offset+=8;
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  out_shape[0] = arr[1];
}
 static inline uint32_t MultiSetterData_nd_offsets(MultiSetterData restrict  obj){
  return 1;
}
 static inline int64_t MultiSetterData_get_offsets(const MultiSetterData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=8;
  offset+=16+i0*8;
  return *( int64_t*)(( char*) obj+offset);
}
 static inline void MultiSetterData_set_offsets(MultiSetterData restrict  obj, int64_t i0, int64_t value){
  int64_t offset=0;
  offset+=8;
  offset+=16+i0*8;
  *( int64_t*)(( char*) obj+offset)=value;
}
 static inline  int64_t* MultiSetterData_getp1_offsets(MultiSetterData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=8;
  offset+=16+i0*8;
  return ( int64_t*)(( char*) obj+offset);
}
#endif
#include "xtrack/multisetter/multisetter.h"
#ifndef XOBJ_TYPEDEF_ParticlesData
#define XOBJ_TYPEDEF_ParticlesData
typedef   struct ParticlesData_s * ParticlesData;
 static inline ParticlesData ParticlesData_getp(ParticlesData restrict  obj){
  int64_t offset=0;
  return (ParticlesData)(( char*) obj+offset);
}
 static inline int64_t ParticlesData_get__capacity(const ParticlesData restrict  obj){
  int64_t offset=0;
  offset+=8;
  return *( int64_t*)(( char*) obj+offset);
}
 static inline void ParticlesData_set__capacity(ParticlesData restrict  obj, int64_t value){
  int64_t offset=0;
  offset+=8;
  *( int64_t*)(( char*) obj+offset)=value;
}
 static inline  int64_t* ParticlesData_getp__capacity(ParticlesData restrict  obj){
  int64_t offset=0;
  offset+=8;
  return ( int64_t*)(( char*) obj+offset);
}
 static inline int64_t ParticlesData_get__num_active_particles(const ParticlesData restrict  obj){
  int64_t offset=0;
  offset+=16;
  return *( int64_t*)(( char*) obj+offset);
}
 static inline void ParticlesData_set__num_active_particles(ParticlesData restrict  obj, int64_t value){
  int64_t offset=0;
  offset+=16;
  *( int64_t*)(( char*) obj+offset)=value;
}
 static inline  int64_t* ParticlesData_getp__num_active_particles(ParticlesData restrict  obj){
  int64_t offset=0;
  offset+=16;
  return ( int64_t*)(( char*) obj+offset);
}
 static inline int64_t ParticlesData_get__num_lost_particles(const ParticlesData restrict  obj){
  int64_t offset=0;
  offset+=24;
  return *( int64_t*)(( char*) obj+offset);
}
 static inline void ParticlesData_set__num_lost_particles(ParticlesData restrict  obj, int64_t value){
  int64_t offset=0;
  offset+=24;
  *( int64_t*)(( char*) obj+offset)=value;
}
 static inline  int64_t* ParticlesData_getp__num_lost_particles(ParticlesData restrict  obj){
  int64_t offset=0;
  offset+=24;
  return ( int64_t*)(( char*) obj+offset);
}
 static inline int64_t ParticlesData_get_start_tracking_at_element(const ParticlesData restrict  obj){
  int64_t offset=0;
  offset+=32;
  return *( int64_t*)(( char*) obj+offset);
}
 static inline void ParticlesData_set_start_tracking_at_element(ParticlesData restrict  obj, int64_t value){
  int64_t offset=0;
  offset+=32;
  *( int64_t*)(( char*) obj+offset)=value;
}
 static inline  int64_t* ParticlesData_getp_start_tracking_at_element(ParticlesData restrict  obj){
  int64_t offset=0;
  offset+=32;
  return ( int64_t*)(( char*) obj+offset);
}
 static inline double ParticlesData_get_q0(const ParticlesData restrict  obj){
  int64_t offset=0;
  offset+=40;
  return *( double*)(( char*) obj+offset);
}
 static inline void ParticlesData_set_q0(ParticlesData restrict  obj, double value){
  int64_t offset=0;
  offset+=40;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* ParticlesData_getp_q0(ParticlesData restrict  obj){
  int64_t offset=0;
  offset+=40;
  return ( double*)(( char*) obj+offset);
}
 static inline double ParticlesData_get_mass0(const ParticlesData restrict  obj){
  int64_t offset=0;
  offset+=48;
  return *( double*)(( char*) obj+offset);
}
 static inline void ParticlesData_set_mass0(ParticlesData restrict  obj, double value){
  int64_t offset=0;
  offset+=48;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* ParticlesData_getp_mass0(ParticlesData restrict  obj){
  int64_t offset=0;
  offset+=48;
  return ( double*)(( char*) obj+offset);
}
 static inline double ParticlesData_get_t_sim(const ParticlesData restrict  obj){
  int64_t offset=0;
  offset+=56;
  return *( double*)(( char*) obj+offset);
}
 static inline void ParticlesData_set_t_sim(ParticlesData restrict  obj, double value){
  int64_t offset=0;
  offset+=56;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* ParticlesData_getp_t_sim(ParticlesData restrict  obj){
  int64_t offset=0;
  offset+=56;
  return ( double*)(( char*) obj+offset);
}
 static inline ArrNFloat64 ParticlesData_getp_p0c(ParticlesData restrict  obj){
  int64_t offset=0;
  offset+=312;
  return (ArrNFloat64)(( char*) obj+offset);
}
 static inline int64_t ParticlesData_len_p0c(ParticlesData restrict  obj){
  int64_t offset=0;
  offset+=312;
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  return arr[1];
}
 static inline void ParticlesData_shape_p0c(ParticlesData restrict  obj,  int64_t* restrict  out_shape){
  int64_t offset=0;
  offset+=312;
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  out_shape[0] = arr[1];
}
 static inline uint32_t ParticlesData_nd_p0c(ParticlesData restrict  obj){
  return 1;
}
 static inline double ParticlesData_get_p0c(const ParticlesData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=312;
  offset+=16+i0*8;
  return *( double*)(( char*) obj+offset);
}
 static inline void ParticlesData_set_p0c(ParticlesData restrict  obj, int64_t i0, double value){
  int64_t offset=0;
  offset+=312;
  offset+=16+i0*8;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* ParticlesData_getp1_p0c(ParticlesData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=312;
  offset+=16+i0*8;
  return ( double*)(( char*) obj+offset);
}
 static inline ArrNFloat64 ParticlesData_getp_gamma0(ParticlesData restrict  obj){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+64);
  return (ArrNFloat64)(( char*) obj+offset);
}
 static inline int64_t ParticlesData_len_gamma0(ParticlesData restrict  obj){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+64);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  return arr[1];
}
 static inline void ParticlesData_shape_gamma0(ParticlesData restrict  obj,  int64_t* restrict  out_shape){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+64);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  out_shape[0] = arr[1];
}
 static inline uint32_t ParticlesData_nd_gamma0(ParticlesData restrict  obj){
  return 1;
}
 static inline double ParticlesData_get_gamma0(const ParticlesData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+64);
  offset+=16+i0*8;
  return *( double*)(( char*) obj+offset);
}
 static inline void ParticlesData_set_gamma0(ParticlesData restrict  obj, int64_t i0, double value){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+64);
  offset+=16+i0*8;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* ParticlesData_getp1_gamma0(ParticlesData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+64);
  offset+=16+i0*8;
  return ( double*)(( char*) obj+offset);
}
 static inline ArrNFloat64 ParticlesData_getp_beta0(ParticlesData restrict  obj){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+72);
  return (ArrNFloat64)(( char*) obj+offset);
}
 static inline int64_t ParticlesData_len_beta0(ParticlesData restrict  obj){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+72);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  return arr[1];
}
 static inline void ParticlesData_shape_beta0(ParticlesData restrict  obj,  int64_t* restrict  out_shape){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+72);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  out_shape[0] = arr[1];
}
 static inline uint32_t ParticlesData_nd_beta0(ParticlesData restrict  obj){
  return 1;
}
 static inline double ParticlesData_get_beta0(const ParticlesData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+72);
  offset+=16+i0*8;
  return *( double*)(( char*) obj+offset);
}
 static inline void ParticlesData_set_beta0(ParticlesData restrict  obj, int64_t i0, double value){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+72);
  offset+=16+i0*8;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* ParticlesData_getp1_beta0(ParticlesData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+72);
  offset+=16+i0*8;
  return ( double*)(( char*) obj+offset);
}
 static inline ArrNFloat64 ParticlesData_getp_s(ParticlesData restrict  obj){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+80);
  return (ArrNFloat64)(( char*) obj+offset);
}
 static inline int64_t ParticlesData_len_s(ParticlesData restrict  obj){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+80);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  return arr[1];
}
 static inline void ParticlesData_shape_s(ParticlesData restrict  obj,  int64_t* restrict  out_shape){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+80);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  out_shape[0] = arr[1];
}
 static inline uint32_t ParticlesData_nd_s(ParticlesData restrict  obj){
  return 1;
}
 static inline double ParticlesData_get_s(const ParticlesData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+80);
  offset+=16+i0*8;
  return *( double*)(( char*) obj+offset);
}
 static inline void ParticlesData_set_s(ParticlesData restrict  obj, int64_t i0, double value){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+80);
  offset+=16+i0*8;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* ParticlesData_getp1_s(ParticlesData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+80);
  offset+=16+i0*8;
  return ( double*)(( char*) obj+offset);
}
 static inline ArrNFloat64 ParticlesData_getp_zeta(ParticlesData restrict  obj){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+88);
  return (ArrNFloat64)(( char*) obj+offset);
}
 static inline int64_t ParticlesData_len_zeta(ParticlesData restrict  obj){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+88);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  return arr[1];
}
 static inline void ParticlesData_shape_zeta(ParticlesData restrict  obj,  int64_t* restrict  out_shape){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+88);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  out_shape[0] = arr[1];
}
 static inline uint32_t ParticlesData_nd_zeta(ParticlesData restrict  obj){
  return 1;
}
 static inline double ParticlesData_get_zeta(const ParticlesData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+88);
  offset+=16+i0*8;
  return *( double*)(( char*) obj+offset);
}
 static inline void ParticlesData_set_zeta(ParticlesData restrict  obj, int64_t i0, double value){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+88);
  offset+=16+i0*8;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* ParticlesData_getp1_zeta(ParticlesData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+88);
  offset+=16+i0*8;
  return ( double*)(( char*) obj+offset);
}
 static inline ArrNFloat64 ParticlesData_getp_x(ParticlesData restrict  obj){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+96);
  return (ArrNFloat64)(( char*) obj+offset);
}
 static inline int64_t ParticlesData_len_x(ParticlesData restrict  obj){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+96);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  return arr[1];
}
 static inline void ParticlesData_shape_x(ParticlesData restrict  obj,  int64_t* restrict  out_shape){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+96);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  out_shape[0] = arr[1];
}
 static inline uint32_t ParticlesData_nd_x(ParticlesData restrict  obj){
  return 1;
}
 static inline double ParticlesData_get_x(const ParticlesData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+96);
  offset+=16+i0*8;
  return *( double*)(( char*) obj+offset);
}
 static inline void ParticlesData_set_x(ParticlesData restrict  obj, int64_t i0, double value){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+96);
  offset+=16+i0*8;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* ParticlesData_getp1_x(ParticlesData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+96);
  offset+=16+i0*8;
  return ( double*)(( char*) obj+offset);
}
 static inline ArrNFloat64 ParticlesData_getp_y(ParticlesData restrict  obj){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+104);
  return (ArrNFloat64)(( char*) obj+offset);
}
 static inline int64_t ParticlesData_len_y(ParticlesData restrict  obj){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+104);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  return arr[1];
}
 static inline void ParticlesData_shape_y(ParticlesData restrict  obj,  int64_t* restrict  out_shape){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+104);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  out_shape[0] = arr[1];
}
 static inline uint32_t ParticlesData_nd_y(ParticlesData restrict  obj){
  return 1;
}
 static inline double ParticlesData_get_y(const ParticlesData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+104);
  offset+=16+i0*8;
  return *( double*)(( char*) obj+offset);
}
 static inline void ParticlesData_set_y(ParticlesData restrict  obj, int64_t i0, double value){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+104);
  offset+=16+i0*8;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* ParticlesData_getp1_y(ParticlesData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+104);
  offset+=16+i0*8;
  return ( double*)(( char*) obj+offset);
}
 static inline ArrNFloat64 ParticlesData_getp_px(ParticlesData restrict  obj){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+112);
  return (ArrNFloat64)(( char*) obj+offset);
}
 static inline int64_t ParticlesData_len_px(ParticlesData restrict  obj){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+112);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  return arr[1];
}
 static inline void ParticlesData_shape_px(ParticlesData restrict  obj,  int64_t* restrict  out_shape){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+112);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  out_shape[0] = arr[1];
}
 static inline uint32_t ParticlesData_nd_px(ParticlesData restrict  obj){
  return 1;
}
 static inline double ParticlesData_get_px(const ParticlesData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+112);
  offset+=16+i0*8;
  return *( double*)(( char*) obj+offset);
}
 static inline void ParticlesData_set_px(ParticlesData restrict  obj, int64_t i0, double value){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+112);
  offset+=16+i0*8;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* ParticlesData_getp1_px(ParticlesData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+112);
  offset+=16+i0*8;
  return ( double*)(( char*) obj+offset);
}
 static inline ArrNFloat64 ParticlesData_getp_py(ParticlesData restrict  obj){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+120);
  return (ArrNFloat64)(( char*) obj+offset);
}
 static inline int64_t ParticlesData_len_py(ParticlesData restrict  obj){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+120);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  return arr[1];
}
 static inline void ParticlesData_shape_py(ParticlesData restrict  obj,  int64_t* restrict  out_shape){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+120);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  out_shape[0] = arr[1];
}
 static inline uint32_t ParticlesData_nd_py(ParticlesData restrict  obj){
  return 1;
}
 static inline double ParticlesData_get_py(const ParticlesData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+120);
  offset+=16+i0*8;
  return *( double*)(( char*) obj+offset);
}
 static inline void ParticlesData_set_py(ParticlesData restrict  obj, int64_t i0, double value){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+120);
  offset+=16+i0*8;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* ParticlesData_getp1_py(ParticlesData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+120);
  offset+=16+i0*8;
  return ( double*)(( char*) obj+offset);
}
 static inline ArrNFloat64 ParticlesData_getp_ptau(ParticlesData restrict  obj){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+128);
  return (ArrNFloat64)(( char*) obj+offset);
}
 static inline int64_t ParticlesData_len_ptau(ParticlesData restrict  obj){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+128);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  return arr[1];
}
 static inline void ParticlesData_shape_ptau(ParticlesData restrict  obj,  int64_t* restrict  out_shape){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+128);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  out_shape[0] = arr[1];
}
 static inline uint32_t ParticlesData_nd_ptau(ParticlesData restrict  obj){
  return 1;
}
 static inline double ParticlesData_get_ptau(const ParticlesData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+128);
  offset+=16+i0*8;
  return *( double*)(( char*) obj+offset);
}
 static inline void ParticlesData_set_ptau(ParticlesData restrict  obj, int64_t i0, double value){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+128);
  offset+=16+i0*8;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* ParticlesData_getp1_ptau(ParticlesData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+128);
  offset+=16+i0*8;
  return ( double*)(( char*) obj+offset);
}
 static inline ArrNFloat64 ParticlesData_getp_delta(ParticlesData restrict  obj){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+136);
  return (ArrNFloat64)(( char*) obj+offset);
}
 static inline int64_t ParticlesData_len_delta(ParticlesData restrict  obj){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+136);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  return arr[1];
}
 static inline void ParticlesData_shape_delta(ParticlesData restrict  obj,  int64_t* restrict  out_shape){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+136);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  out_shape[0] = arr[1];
}
 static inline uint32_t ParticlesData_nd_delta(ParticlesData restrict  obj){
  return 1;
}
 static inline double ParticlesData_get_delta(const ParticlesData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+136);
  offset+=16+i0*8;
  return *( double*)(( char*) obj+offset);
}
 static inline void ParticlesData_set_delta(ParticlesData restrict  obj, int64_t i0, double value){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+136);
  offset+=16+i0*8;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* ParticlesData_getp1_delta(ParticlesData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+136);
  offset+=16+i0*8;
  return ( double*)(( char*) obj+offset);
}
 static inline ArrNFloat64 ParticlesData_getp_rpp(ParticlesData restrict  obj){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+144);
  return (ArrNFloat64)(( char*) obj+offset);
}
 static inline int64_t ParticlesData_len_rpp(ParticlesData restrict  obj){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+144);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  return arr[1];
}
 static inline void ParticlesData_shape_rpp(ParticlesData restrict  obj,  int64_t* restrict  out_shape){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+144);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  out_shape[0] = arr[1];
}
 static inline uint32_t ParticlesData_nd_rpp(ParticlesData restrict  obj){
  return 1;
}
 static inline double ParticlesData_get_rpp(const ParticlesData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+144);
  offset+=16+i0*8;
  return *( double*)(( char*) obj+offset);
}
 static inline void ParticlesData_set_rpp(ParticlesData restrict  obj, int64_t i0, double value){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+144);
  offset+=16+i0*8;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* ParticlesData_getp1_rpp(ParticlesData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+144);
  offset+=16+i0*8;
  return ( double*)(( char*) obj+offset);
}
 static inline ArrNFloat64 ParticlesData_getp_rvv(ParticlesData restrict  obj){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+152);
  return (ArrNFloat64)(( char*) obj+offset);
}
 static inline int64_t ParticlesData_len_rvv(ParticlesData restrict  obj){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+152);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  return arr[1];
}
 static inline void ParticlesData_shape_rvv(ParticlesData restrict  obj,  int64_t* restrict  out_shape){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+152);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  out_shape[0] = arr[1];
}
 static inline uint32_t ParticlesData_nd_rvv(ParticlesData restrict  obj){
  return 1;
}
 static inline double ParticlesData_get_rvv(const ParticlesData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+152);
  offset+=16+i0*8;
  return *( double*)(( char*) obj+offset);
}
 static inline void ParticlesData_set_rvv(ParticlesData restrict  obj, int64_t i0, double value){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+152);
  offset+=16+i0*8;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* ParticlesData_getp1_rvv(ParticlesData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+152);
  offset+=16+i0*8;
  return ( double*)(( char*) obj+offset);
}
 static inline ArrNFloat64 ParticlesData_getp_chi(ParticlesData restrict  obj){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+160);
  return (ArrNFloat64)(( char*) obj+offset);
}
 static inline int64_t ParticlesData_len_chi(ParticlesData restrict  obj){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+160);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  return arr[1];
}
 static inline void ParticlesData_shape_chi(ParticlesData restrict  obj,  int64_t* restrict  out_shape){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+160);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  out_shape[0] = arr[1];
}
 static inline uint32_t ParticlesData_nd_chi(ParticlesData restrict  obj){
  return 1;
}
 static inline double ParticlesData_get_chi(const ParticlesData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+160);
  offset+=16+i0*8;
  return *( double*)(( char*) obj+offset);
}
 static inline void ParticlesData_set_chi(ParticlesData restrict  obj, int64_t i0, double value){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+160);
  offset+=16+i0*8;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* ParticlesData_getp1_chi(ParticlesData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+160);
  offset+=16+i0*8;
  return ( double*)(( char*) obj+offset);
}
 static inline ArrNFloat64 ParticlesData_getp_charge_ratio(ParticlesData restrict  obj){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+168);
  return (ArrNFloat64)(( char*) obj+offset);
}
 static inline int64_t ParticlesData_len_charge_ratio(ParticlesData restrict  obj){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+168);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  return arr[1];
}
 static inline void ParticlesData_shape_charge_ratio(ParticlesData restrict  obj,  int64_t* restrict  out_shape){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+168);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  out_shape[0] = arr[1];
}
 static inline uint32_t ParticlesData_nd_charge_ratio(ParticlesData restrict  obj){
  return 1;
}
 static inline double ParticlesData_get_charge_ratio(const ParticlesData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+168);
  offset+=16+i0*8;
  return *( double*)(( char*) obj+offset);
}
 static inline void ParticlesData_set_charge_ratio(ParticlesData restrict  obj, int64_t i0, double value){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+168);
  offset+=16+i0*8;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* ParticlesData_getp1_charge_ratio(ParticlesData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+168);
  offset+=16+i0*8;
  return ( double*)(( char*) obj+offset);
}
 static inline ArrNFloat64 ParticlesData_getp_weight(ParticlesData restrict  obj){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+176);
  return (ArrNFloat64)(( char*) obj+offset);
}
 static inline int64_t ParticlesData_len_weight(ParticlesData restrict  obj){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+176);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  return arr[1];
}
 static inline void ParticlesData_shape_weight(ParticlesData restrict  obj,  int64_t* restrict  out_shape){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+176);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  out_shape[0] = arr[1];
}
 static inline uint32_t ParticlesData_nd_weight(ParticlesData restrict  obj){
  return 1;
}
 static inline double ParticlesData_get_weight(const ParticlesData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+176);
  offset+=16+i0*8;
  return *( double*)(( char*) obj+offset);
}
 static inline void ParticlesData_set_weight(ParticlesData restrict  obj, int64_t i0, double value){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+176);
  offset+=16+i0*8;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* ParticlesData_getp1_weight(ParticlesData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+176);
  offset+=16+i0*8;
  return ( double*)(( char*) obj+offset);
}
 static inline ArrNFloat64 ParticlesData_getp_ax(ParticlesData restrict  obj){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+184);
  return (ArrNFloat64)(( char*) obj+offset);
}
 static inline int64_t ParticlesData_len_ax(ParticlesData restrict  obj){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+184);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  return arr[1];
}
 static inline void ParticlesData_shape_ax(ParticlesData restrict  obj,  int64_t* restrict  out_shape){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+184);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  out_shape[0] = arr[1];
}
 static inline uint32_t ParticlesData_nd_ax(ParticlesData restrict  obj){
  return 1;
}
 static inline double ParticlesData_get_ax(const ParticlesData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+184);
  offset+=16+i0*8;
  return *( double*)(( char*) obj+offset);
}
 static inline void ParticlesData_set_ax(ParticlesData restrict  obj, int64_t i0, double value){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+184);
  offset+=16+i0*8;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* ParticlesData_getp1_ax(ParticlesData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+184);
  offset+=16+i0*8;
  return ( double*)(( char*) obj+offset);
}
 static inline ArrNFloat64 ParticlesData_getp_ay(ParticlesData restrict  obj){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+192);
  return (ArrNFloat64)(( char*) obj+offset);
}
 static inline int64_t ParticlesData_len_ay(ParticlesData restrict  obj){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+192);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  return arr[1];
}
 static inline void ParticlesData_shape_ay(ParticlesData restrict  obj,  int64_t* restrict  out_shape){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+192);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  out_shape[0] = arr[1];
}
 static inline uint32_t ParticlesData_nd_ay(ParticlesData restrict  obj){
  return 1;
}
 static inline double ParticlesData_get_ay(const ParticlesData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+192);
  offset+=16+i0*8;
  return *( double*)(( char*) obj+offset);
}
 static inline void ParticlesData_set_ay(ParticlesData restrict  obj, int64_t i0, double value){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+192);
  offset+=16+i0*8;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* ParticlesData_getp1_ay(ParticlesData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+192);
  offset+=16+i0*8;
  return ( double*)(( char*) obj+offset);
}
 static inline ArrNFloat64 ParticlesData_getp_spin_x(ParticlesData restrict  obj){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+200);
  return (ArrNFloat64)(( char*) obj+offset);
}
 static inline int64_t ParticlesData_len_spin_x(ParticlesData restrict  obj){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+200);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  return arr[1];
}
 static inline void ParticlesData_shape_spin_x(ParticlesData restrict  obj,  int64_t* restrict  out_shape){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+200);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  out_shape[0] = arr[1];
}
 static inline uint32_t ParticlesData_nd_spin_x(ParticlesData restrict  obj){
  return 1;
}
 static inline double ParticlesData_get_spin_x(const ParticlesData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+200);
  offset+=16+i0*8;
  return *( double*)(( char*) obj+offset);
}
 static inline void ParticlesData_set_spin_x(ParticlesData restrict  obj, int64_t i0, double value){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+200);
  offset+=16+i0*8;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* ParticlesData_getp1_spin_x(ParticlesData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+200);
  offset+=16+i0*8;
  return ( double*)(( char*) obj+offset);
}
 static inline ArrNFloat64 ParticlesData_getp_spin_y(ParticlesData restrict  obj){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+208);
  return (ArrNFloat64)(( char*) obj+offset);
}
 static inline int64_t ParticlesData_len_spin_y(ParticlesData restrict  obj){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+208);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  return arr[1];
}
 static inline void ParticlesData_shape_spin_y(ParticlesData restrict  obj,  int64_t* restrict  out_shape){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+208);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  out_shape[0] = arr[1];
}
 static inline uint32_t ParticlesData_nd_spin_y(ParticlesData restrict  obj){
  return 1;
}
 static inline double ParticlesData_get_spin_y(const ParticlesData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+208);
  offset+=16+i0*8;
  return *( double*)(( char*) obj+offset);
}
 static inline void ParticlesData_set_spin_y(ParticlesData restrict  obj, int64_t i0, double value){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+208);
  offset+=16+i0*8;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* ParticlesData_getp1_spin_y(ParticlesData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+208);
  offset+=16+i0*8;
  return ( double*)(( char*) obj+offset);
}
 static inline ArrNFloat64 ParticlesData_getp_spin_z(ParticlesData restrict  obj){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+216);
  return (ArrNFloat64)(( char*) obj+offset);
}
 static inline int64_t ParticlesData_len_spin_z(ParticlesData restrict  obj){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+216);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  return arr[1];
}
 static inline void ParticlesData_shape_spin_z(ParticlesData restrict  obj,  int64_t* restrict  out_shape){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+216);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  out_shape[0] = arr[1];
}
 static inline uint32_t ParticlesData_nd_spin_z(ParticlesData restrict  obj){
  return 1;
}
 static inline double ParticlesData_get_spin_z(const ParticlesData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+216);
  offset+=16+i0*8;
  return *( double*)(( char*) obj+offset);
}
 static inline void ParticlesData_set_spin_z(ParticlesData restrict  obj, int64_t i0, double value){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+216);
  offset+=16+i0*8;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* ParticlesData_getp1_spin_z(ParticlesData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+216);
  offset+=16+i0*8;
  return ( double*)(( char*) obj+offset);
}
 static inline ArrNFloat64 ParticlesData_getp_anomalous_magnetic_moment(ParticlesData restrict  obj){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+224);
  return (ArrNFloat64)(( char*) obj+offset);
}
 static inline int64_t ParticlesData_len_anomalous_magnetic_moment(ParticlesData restrict  obj){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+224);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  return arr[1];
}
 static inline void ParticlesData_shape_anomalous_magnetic_moment(ParticlesData restrict  obj,  int64_t* restrict  out_shape){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+224);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  out_shape[0] = arr[1];
}
 static inline uint32_t ParticlesData_nd_anomalous_magnetic_moment(ParticlesData restrict  obj){
  return 1;
}
 static inline double ParticlesData_get_anomalous_magnetic_moment(const ParticlesData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+224);
  offset+=16+i0*8;
  return *( double*)(( char*) obj+offset);
}
 static inline void ParticlesData_set_anomalous_magnetic_moment(ParticlesData restrict  obj, int64_t i0, double value){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+224);
  offset+=16+i0*8;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* ParticlesData_getp1_anomalous_magnetic_moment(ParticlesData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+224);
  offset+=16+i0*8;
  return ( double*)(( char*) obj+offset);
}
 static inline ArrNInt64 ParticlesData_getp_pdg_id(ParticlesData restrict  obj){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+232);
  return (ArrNInt64)(( char*) obj+offset);
}
 static inline int64_t ParticlesData_len_pdg_id(ParticlesData restrict  obj){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+232);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  return arr[1];
}
 static inline void ParticlesData_shape_pdg_id(ParticlesData restrict  obj,  int64_t* restrict  out_shape){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+232);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  out_shape[0] = arr[1];
}
 static inline uint32_t ParticlesData_nd_pdg_id(ParticlesData restrict  obj){
  return 1;
}
 static inline int64_t ParticlesData_get_pdg_id(const ParticlesData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+232);
  offset+=16+i0*8;
  return *( int64_t*)(( char*) obj+offset);
}
 static inline void ParticlesData_set_pdg_id(ParticlesData restrict  obj, int64_t i0, int64_t value){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+232);
  offset+=16+i0*8;
  *( int64_t*)(( char*) obj+offset)=value;
}
 static inline  int64_t* ParticlesData_getp1_pdg_id(ParticlesData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+232);
  offset+=16+i0*8;
  return ( int64_t*)(( char*) obj+offset);
}
 static inline ArrNInt64 ParticlesData_getp_particle_id(ParticlesData restrict  obj){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+240);
  return (ArrNInt64)(( char*) obj+offset);
}
 static inline int64_t ParticlesData_len_particle_id(ParticlesData restrict  obj){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+240);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  return arr[1];
}
 static inline void ParticlesData_shape_particle_id(ParticlesData restrict  obj,  int64_t* restrict  out_shape){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+240);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  out_shape[0] = arr[1];
}
 static inline uint32_t ParticlesData_nd_particle_id(ParticlesData restrict  obj){
  return 1;
}
 static inline int64_t ParticlesData_get_particle_id(const ParticlesData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+240);
  offset+=16+i0*8;
  return *( int64_t*)(( char*) obj+offset);
}
 static inline void ParticlesData_set_particle_id(ParticlesData restrict  obj, int64_t i0, int64_t value){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+240);
  offset+=16+i0*8;
  *( int64_t*)(( char*) obj+offset)=value;
}
 static inline  int64_t* ParticlesData_getp1_particle_id(ParticlesData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+240);
  offset+=16+i0*8;
  return ( int64_t*)(( char*) obj+offset);
}
 static inline ArrNInt64 ParticlesData_getp_at_element(ParticlesData restrict  obj){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+248);
  return (ArrNInt64)(( char*) obj+offset);
}
 static inline int64_t ParticlesData_len_at_element(ParticlesData restrict  obj){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+248);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  return arr[1];
}
 static inline void ParticlesData_shape_at_element(ParticlesData restrict  obj,  int64_t* restrict  out_shape){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+248);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  out_shape[0] = arr[1];
}
 static inline uint32_t ParticlesData_nd_at_element(ParticlesData restrict  obj){
  return 1;
}
 static inline int64_t ParticlesData_get_at_element(const ParticlesData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+248);
  offset+=16+i0*8;
  return *( int64_t*)(( char*) obj+offset);
}
 static inline void ParticlesData_set_at_element(ParticlesData restrict  obj, int64_t i0, int64_t value){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+248);
  offset+=16+i0*8;
  *( int64_t*)(( char*) obj+offset)=value;
}
 static inline  int64_t* ParticlesData_getp1_at_element(ParticlesData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+248);
  offset+=16+i0*8;
  return ( int64_t*)(( char*) obj+offset);
}
 static inline ArrNInt64 ParticlesData_getp_at_turn(ParticlesData restrict  obj){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+256);
  return (ArrNInt64)(( char*) obj+offset);
}
 static inline int64_t ParticlesData_len_at_turn(ParticlesData restrict  obj){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+256);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  return arr[1];
}
 static inline void ParticlesData_shape_at_turn(ParticlesData restrict  obj,  int64_t* restrict  out_shape){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+256);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  out_shape[0] = arr[1];
}
 static inline uint32_t ParticlesData_nd_at_turn(ParticlesData restrict  obj){
  return 1;
}
 static inline int64_t ParticlesData_get_at_turn(const ParticlesData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+256);
  offset+=16+i0*8;
  return *( int64_t*)(( char*) obj+offset);
}
 static inline void ParticlesData_set_at_turn(ParticlesData restrict  obj, int64_t i0, int64_t value){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+256);
  offset+=16+i0*8;
  *( int64_t*)(( char*) obj+offset)=value;
}
 static inline  int64_t* ParticlesData_getp1_at_turn(ParticlesData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+256);
  offset+=16+i0*8;
  return ( int64_t*)(( char*) obj+offset);
}
 static inline ArrNInt64 ParticlesData_getp_state(ParticlesData restrict  obj){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+264);
  return (ArrNInt64)(( char*) obj+offset);
}
 static inline int64_t ParticlesData_len_state(ParticlesData restrict  obj){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+264);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  return arr[1];
}
 static inline void ParticlesData_shape_state(ParticlesData restrict  obj,  int64_t* restrict  out_shape){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+264);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  out_shape[0] = arr[1];
}
 static inline uint32_t ParticlesData_nd_state(ParticlesData restrict  obj){
  return 1;
}
 static inline int64_t ParticlesData_get_state(const ParticlesData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+264);
  offset+=16+i0*8;
  return *( int64_t*)(( char*) obj+offset);
}
 static inline void ParticlesData_set_state(ParticlesData restrict  obj, int64_t i0, int64_t value){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+264);
  offset+=16+i0*8;
  *( int64_t*)(( char*) obj+offset)=value;
}
 static inline  int64_t* ParticlesData_getp1_state(ParticlesData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+264);
  offset+=16+i0*8;
  return ( int64_t*)(( char*) obj+offset);
}
 static inline ArrNInt64 ParticlesData_getp_parent_particle_id(ParticlesData restrict  obj){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+272);
  return (ArrNInt64)(( char*) obj+offset);
}
 static inline int64_t ParticlesData_len_parent_particle_id(ParticlesData restrict  obj){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+272);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  return arr[1];
}
 static inline void ParticlesData_shape_parent_particle_id(ParticlesData restrict  obj,  int64_t* restrict  out_shape){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+272);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  out_shape[0] = arr[1];
}
 static inline uint32_t ParticlesData_nd_parent_particle_id(ParticlesData restrict  obj){
  return 1;
}
 static inline int64_t ParticlesData_get_parent_particle_id(const ParticlesData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+272);
  offset+=16+i0*8;
  return *( int64_t*)(( char*) obj+offset);
}
 static inline void ParticlesData_set_parent_particle_id(ParticlesData restrict  obj, int64_t i0, int64_t value){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+272);
  offset+=16+i0*8;
  *( int64_t*)(( char*) obj+offset)=value;
}
 static inline  int64_t* ParticlesData_getp1_parent_particle_id(ParticlesData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+272);
  offset+=16+i0*8;
  return ( int64_t*)(( char*) obj+offset);
}
 static inline ArrNUint32 ParticlesData_getp__rng_s1(ParticlesData restrict  obj){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+280);
  return (ArrNUint32)(( char*) obj+offset);
}
 static inline int64_t ParticlesData_len__rng_s1(ParticlesData restrict  obj){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+280);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  return arr[1];
}
 static inline void ParticlesData_shape__rng_s1(ParticlesData restrict  obj,  int64_t* restrict  out_shape){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+280);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  out_shape[0] = arr[1];
}
 static inline uint32_t ParticlesData_nd__rng_s1(ParticlesData restrict  obj){
  return 1;
}
 static inline uint32_t ParticlesData_get__rng_s1(const ParticlesData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+280);
  offset+=16+i0*4;
  return *( uint32_t*)(( char*) obj+offset);
}
 static inline void ParticlesData_set__rng_s1(ParticlesData restrict  obj, int64_t i0, uint32_t value){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+280);
  offset+=16+i0*4;
  *( uint32_t*)(( char*) obj+offset)=value;
}
 static inline  uint32_t* ParticlesData_getp1__rng_s1(ParticlesData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+280);
  offset+=16+i0*4;
  return ( uint32_t*)(( char*) obj+offset);
}
 static inline ArrNUint32 ParticlesData_getp__rng_s2(ParticlesData restrict  obj){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+288);
  return (ArrNUint32)(( char*) obj+offset);
}
 static inline int64_t ParticlesData_len__rng_s2(ParticlesData restrict  obj){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+288);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  return arr[1];
}
 static inline void ParticlesData_shape__rng_s2(ParticlesData restrict  obj,  int64_t* restrict  out_shape){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+288);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  out_shape[0] = arr[1];
}
 static inline uint32_t ParticlesData_nd__rng_s2(ParticlesData restrict  obj){
  return 1;
}
 static inline uint32_t ParticlesData_get__rng_s2(const ParticlesData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+288);
  offset+=16+i0*4;
  return *( uint32_t*)(( char*) obj+offset);
}
 static inline void ParticlesData_set__rng_s2(ParticlesData restrict  obj, int64_t i0, uint32_t value){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+288);
  offset+=16+i0*4;
  *( uint32_t*)(( char*) obj+offset)=value;
}
 static inline  uint32_t* ParticlesData_getp1__rng_s2(ParticlesData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+288);
  offset+=16+i0*4;
  return ( uint32_t*)(( char*) obj+offset);
}
 static inline ArrNUint32 ParticlesData_getp__rng_s3(ParticlesData restrict  obj){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+296);
  return (ArrNUint32)(( char*) obj+offset);
}
 static inline int64_t ParticlesData_len__rng_s3(ParticlesData restrict  obj){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+296);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  return arr[1];
}
 static inline void ParticlesData_shape__rng_s3(ParticlesData restrict  obj,  int64_t* restrict  out_shape){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+296);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  out_shape[0] = arr[1];
}
 static inline uint32_t ParticlesData_nd__rng_s3(ParticlesData restrict  obj){
  return 1;
}
 static inline uint32_t ParticlesData_get__rng_s3(const ParticlesData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+296);
  offset+=16+i0*4;
  return *( uint32_t*)(( char*) obj+offset);
}
 static inline void ParticlesData_set__rng_s3(ParticlesData restrict  obj, int64_t i0, uint32_t value){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+296);
  offset+=16+i0*4;
  *( uint32_t*)(( char*) obj+offset)=value;
}
 static inline  uint32_t* ParticlesData_getp1__rng_s3(ParticlesData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+296);
  offset+=16+i0*4;
  return ( uint32_t*)(( char*) obj+offset);
}
 static inline ArrNUint32 ParticlesData_getp__rng_s4(ParticlesData restrict  obj){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+304);
  return (ArrNUint32)(( char*) obj+offset);
}
 static inline int64_t ParticlesData_len__rng_s4(ParticlesData restrict  obj){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+304);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  return arr[1];
}
 static inline void ParticlesData_shape__rng_s4(ParticlesData restrict  obj,  int64_t* restrict  out_shape){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+304);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  out_shape[0] = arr[1];
}
 static inline uint32_t ParticlesData_nd__rng_s4(ParticlesData restrict  obj){
  return 1;
}
 static inline uint32_t ParticlesData_get__rng_s4(const ParticlesData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+304);
  offset+=16+i0*4;
  return *( uint32_t*)(( char*) obj+offset);
}
 static inline void ParticlesData_set__rng_s4(ParticlesData restrict  obj, int64_t i0, uint32_t value){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+304);
  offset+=16+i0*4;
  *( uint32_t*)(( char*) obj+offset)=value;
}
 static inline  uint32_t* ParticlesData_getp1__rng_s4(ParticlesData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+304);
  offset+=16+i0*4;
  return ( uint32_t*)(( char*) obj+offset);
}
#endif
#include "xobjects/headers/common.h"
#include "xtrack/particles/rng_src/base_rng.h"
#include "xtrack/particles/rng_src/particles_rng.h"
#define ELECTRON_MASS_EV 510998.95
#define MUON_MASS_EV 105658375.5
#define PION_MASS_EV 139570390.0
#define KAON_MASS_EV 493677000.0
#define PROTON_MASS_EV 938272088.16
#define DEUTERON_MASS_EV 1875612945.0
#define TRITON_MASS_EV 2808921136.68
#define He3_MASS_EV 2808391611.12
#define He4_MASS_EV 3727379411.8
#define U_MASS_EV 931494102.42
#define C10_MASS_EV 9330639707.0
#define C11_MASS_EV 10257084532.0
#define C12_MASS_EV 11177929229.0
#define C13_MASS_EV 12112548340.8
#define C14_MASS_EV 13043937327.9
#define C15_MASS_EV 13982284810.0
#define O14_MASS_EV 13048925215.0
#define O15_MASS_EV 13975267170.0
#define O16_MASS_EV 14899168636.6
#define O17_MASS_EV 15834590977.0
#define O18_MASS_EV 16766111027.3
#define O19_MASS_EV 17701720900.0
#define O20_MASS_EV 18633678340.0
#define Ne19_MASS_EV 17700140000.0
#define Ne20_MASS_EV 18622840116.3
#define Ne21_MASS_EV 19555644383.0
#define Ne22_MASS_EV 20484845538.0
#define Ne23_MASS_EV 21419210320.0
#define Ne24_MASS_EV 22349906830.0
#define Ar35_MASS_EV 32579246300.0
#define Ar36_MASS_EV 33503556145.0
#define Ar37_MASS_EV 34434334110.0
#define Ar38_MASS_EV 35362061070.0
#define Ar39_MASS_EV 36295027800.0
#define Ar40_MASS_EV 37224724197.0
#define Ar41_MASS_EV 38158190689.0
#define Ar42_MASS_EV 39088329600.0
#define Ar43_MASS_EV 40022236600.0
#define Ar44_MASS_EV 40953067200.0
#define Ar45_MASS_EV 41887463810.0
#define Ar46_MASS_EV 42818957400.0
#define Ar47_MASS_EV 43754855500.0
#define Fe52_MASS_EV 48389361230.0
#define Fe53_MASS_EV 49318239900.0
#define Fe54_MASS_EV 50244426920.0
#define Fe55_MASS_EV 51174694210.0
#define Fe56_MASS_EV 52103062570.0
#define Fe57_MASS_EV 53034981820.0
#define Fe58_MASS_EV 53964502670.0
#define Fe59_MASS_EV 54897487080.0
#define Fe60_MASS_EV 55828232900.0
#define Fe61_MASS_EV 56762219700.0
#define Fe62_MASS_EV 57693756300.0
#define Fe63_MASS_EV 58628492800.0
#define Fe64_MASS_EV 59560653000.0
#define Xe112_MASS_EV 104267313200.0
#define Xe113_MASS_EV 105196621000.0
#define Xe114_MASS_EV 106123241000.0
#define Xe115_MASS_EV 107053165000.0
#define Xe116_MASS_EV 107980269000.0
#define Xe117_MASS_EV 108910625000.0
#define Xe118_MASS_EV 109838225000.0
#define Xe119_MASS_EV 110769004000.0
#define Xe120_MASS_EV 111697120000.0
#define Xe121_MASS_EV 112628305000.0
#define Xe122_MASS_EV 113556926000.0
#define Xe123_MASS_EV 114488526100.0
#define Xe124_MASS_EV 115417601300.0
#define Xe125_MASS_EV 116349563400.0
#define Xe126_MASS_EV 117279110518.0
#define Xe127_MASS_EV 118211430100.0
#define Xe128_MASS_EV 119141384575.0
#define Xe129_MASS_EV 120074043142.0
#define Xe130_MASS_EV 121004352839.0
#define Xe131_MASS_EV 121937313842.0
#define Xe132_MASS_EV 122867942545.0
#define Xe133_MASS_EV 123801072000.0
#define Xe134_MASS_EV 124732083890.0
#define Xe135_MASS_EV 125665290400.0
#define Xe136_MASS_EV 126596768759.0
#define Xe137_MASS_EV 127532308620.0
#define Xe138_MASS_EV 128466214000.0
#define Xe139_MASS_EV 129402035700.0
#define Xe140_MASS_EV 130336187900.0
#define Xe141_MASS_EV 131272471200.0
#define Xe142_MASS_EV 132206932900.0
#define Au176_MASS_EV 163924444000.0
#define Au177_MASS_EV 164852911000.0
#define Au178_MASS_EV 165783647000.0
#define Au179_MASS_EV 166712456000.0
#define Au180_MASS_EV 167643312800.0
#define Au181_MASS_EV 168572561000.0
#define Au182_MASS_EV 169503622000.0
#define Au183_MASS_EV 170433229200.0
#define Au184_MASS_EV 171364597000.0
#define Au185_MASS_EV 172294550800.0
#define Au186_MASS_EV 173226188000.0
#define Au187_MASS_EV 174156368000.0
#define Au188_MASS_EV 175088520000.0
#define Au189_MASS_EV 176018803000.0
#define Au190_MASS_EV 176951046200.0
#define Au191_MASS_EV 177881575200.0
#define Au192_MASS_EV 178814096000.0
#define Au193_MASS_EV 179744956500.0
#define Au194_MASS_EV 180677644000.0
#define Au195_MASS_EV 181608782900.0
#define Au196_MASS_EV 182541705200.0
#define Au197_MASS_EV 183473198420.0
#define Au198_MASS_EV 184406251470.0
#define Au199_MASS_EV 185338232650.0
#define Au200_MASS_EV 186271581000.0
#define Au201_MASS_EV 187203914200.0
#define Au202_MASS_EV 188137456000.0
#define Au203_MASS_EV 189070159400.0
#define Au204_MASS_EV 190004410000.0
#define Au205_MASS_EV 190937720000.0
#define Au206_MASS_EV 191873600000.0
#define Au207_MASS_EV 192808640000.0
#define Au208_MASS_EV 193744870000.0
#define Au209_MASS_EV 194680040000.0
#define Au210_MASS_EV 195616440000.0
#define Pb185_MASS_EV 172314868000.0
#define Pb186_MASS_EV 173243222000.0
#define Pb187_MASS_EV 174174410200.0
#define Pb188_MASS_EV 175103080000.0
#define Pb189_MASS_EV 176034542000.0
#define Pb190_MASS_EV 176963463000.0
#define Pb191_MASS_EV 177895082400.0
#define Pb192_MASS_EV 178824315800.0
#define Pb193_MASS_EV 179756133000.0
#define Pb194_MASS_EV 180685648000.0
#define Pb195_MASS_EV 181617612000.0
#define Pb196_MASS_EV 182547495900.0
#define Pb197_MASS_EV 183479592800.0
#define Pb198_MASS_EV 184409764900.0
#define Pb199_MASS_EV 185342094600.0
#define Pb200_MASS_EV 186272570000.0
#define Pb201_MASS_EV 187205043000.0
#define Pb202_MASS_EV 188135868100.0
#define Pb203_MASS_EV 189068516300.0
#define Pb204_MASS_EV 189999687100.0
#define Pb205_MASS_EV 190932520900.0
#define Pb206_MASS_EV 191863999600.0
#define Pb207_MASS_EV 192796827200.0
#define Pb208_MASS_EV 193729024800.0
#define Pb209_MASS_EV 194664652900.0
#define Pb210_MASS_EV 195599033100.0
#define Pb211_MASS_EV 196534762600.0
#define Pb212_MASS_EV 197469200800.0
#define Pb213_MASS_EV 198405040200.0
#define Pb214_MASS_EV 199339554900.0
#define Pb215_MASS_EV 200275575000.0
#define Pb216_MASS_EV 201210230000.0
#define Pb217_MASS_EV 202146480000.0
#define Pb218_MASS_EV 203081340000.0
#define Pb219_MASS_EV 204017830000.0
#define Pb220_MASS_EV 204952840000.0
#define PHOTON_MASS_EV 0.0
#define PION0_MASS_EV 134976800.0
#define KAON0_MASS_EV 497611000.0
#define NEUTRON_MASS_EV 939565420.5
typedef struct {
                 int64_t  _capacity;
                 int64_t  _num_active_particles;
                 int64_t  _num_lost_particles;
                 int64_t  start_tracking_at_element;
                 double  q0;
                 double  mass0;
                 double  t_sim;
    GPUGLMEM double* p0c;
    GPUGLMEM double* gamma0;
    GPUGLMEM double* beta0;
    GPUGLMEM double* s;
    GPUGLMEM double* zeta;
    GPUGLMEM double* x;
    GPUGLMEM double* y;
    GPUGLMEM double* px;
    GPUGLMEM double* py;
    GPUGLMEM double* ptau;
    GPUGLMEM double* delta;
    GPUGLMEM double* rpp;
    GPUGLMEM double* rvv;
    GPUGLMEM double* chi;
    GPUGLMEM double* charge_ratio;
    GPUGLMEM double* weight;
    GPUGLMEM double* ax;
    GPUGLMEM double* ay;
    GPUGLMEM double* spin_x;
    GPUGLMEM double* spin_y;
    GPUGLMEM double* spin_z;
    GPUGLMEM double* anomalous_magnetic_moment;
    GPUGLMEM int64_t* pdg_id;
    GPUGLMEM int64_t* particle_id;
    GPUGLMEM int64_t* at_element;
    GPUGLMEM int64_t* at_turn;
    GPUGLMEM int64_t* state;
    GPUGLMEM int64_t* parent_particle_id;
    GPUGLMEM uint32_t* _rng_s1;
    GPUGLMEM uint32_t* _rng_s2;
    GPUGLMEM uint32_t* _rng_s3;
    GPUGLMEM uint32_t* _rng_s4;
             int64_t ipart;
             int64_t endpart;
             uint64_t track_flags;
             double line_length;
    GPUGLMEM int8_t* io_buffer;
} LocalParticle;


        GPUFUN
        void LocalParticle_add_to_p0c(LocalParticle* part, double value){
#ifndef FREEZE_VAR_p0c
  part->p0c[part->ipart] += value;
#endif
}


        GPUFUN
        void LocalParticle_add_to_gamma0(LocalParticle* part, double value){
#ifndef FREEZE_VAR_gamma0
  part->gamma0[part->ipart] += value;
#endif
}


        GPUFUN
        void LocalParticle_add_to_beta0(LocalParticle* part, double value){
#ifndef FREEZE_VAR_beta0
  part->beta0[part->ipart] += value;
#endif
}


        GPUFUN
        void LocalParticle_add_to_s(LocalParticle* part, double value){
#ifndef FREEZE_VAR_s
  part->s[part->ipart] += value;
#endif
}


        GPUFUN
        void LocalParticle_add_to_zeta(LocalParticle* part, double value){
#ifndef FREEZE_VAR_zeta
  part->zeta[part->ipart] += value;
#endif
}


        GPUFUN
        void LocalParticle_add_to_x(LocalParticle* part, double value){
#ifndef FREEZE_VAR_x
  part->x[part->ipart] += value;
#endif
}


        GPUFUN
        void LocalParticle_add_to_y(LocalParticle* part, double value){
#ifndef FREEZE_VAR_y
  part->y[part->ipart] += value;
#endif
}


        GPUFUN
        void LocalParticle_add_to_px(LocalParticle* part, double value){
#ifndef FREEZE_VAR_px
  part->px[part->ipart] += value;
#endif
}


        GPUFUN
        void LocalParticle_add_to_py(LocalParticle* part, double value){
#ifndef FREEZE_VAR_py
  part->py[part->ipart] += value;
#endif
}


        GPUFUN
        void LocalParticle_add_to_ptau(LocalParticle* part, double value){
#ifndef FREEZE_VAR_ptau
  part->ptau[part->ipart] += value;
#endif
}


        GPUFUN
        void LocalParticle_add_to_delta(LocalParticle* part, double value){
#ifndef FREEZE_VAR_delta
  part->delta[part->ipart] += value;
#endif
}


        GPUFUN
        void LocalParticle_add_to_rpp(LocalParticle* part, double value){
#ifndef FREEZE_VAR_rpp
  part->rpp[part->ipart] += value;
#endif
}


        GPUFUN
        void LocalParticle_add_to_rvv(LocalParticle* part, double value){
#ifndef FREEZE_VAR_rvv
  part->rvv[part->ipart] += value;
#endif
}


        GPUFUN
        void LocalParticle_add_to_chi(LocalParticle* part, double value){
#ifndef FREEZE_VAR_chi
  part->chi[part->ipart] += value;
#endif
}


        GPUFUN
        void LocalParticle_add_to_charge_ratio(LocalParticle* part, double value){
#ifndef FREEZE_VAR_charge_ratio
  part->charge_ratio[part->ipart] += value;
#endif
}


        GPUFUN
        void LocalParticle_add_to_weight(LocalParticle* part, double value){
#ifndef FREEZE_VAR_weight
  part->weight[part->ipart] += value;
#endif
}


        GPUFUN
        void LocalParticle_add_to_ax(LocalParticle* part, double value){
#ifndef FREEZE_VAR_ax
  part->ax[part->ipart] += value;
#endif
}


        GPUFUN
        void LocalParticle_add_to_ay(LocalParticle* part, double value){
#ifndef FREEZE_VAR_ay
  part->ay[part->ipart] += value;
#endif
}


        GPUFUN
        void LocalParticle_add_to_spin_x(LocalParticle* part, double value){
#ifndef FREEZE_VAR_spin_x
  part->spin_x[part->ipart] += value;
#endif
}


        GPUFUN
        void LocalParticle_add_to_spin_y(LocalParticle* part, double value){
#ifndef FREEZE_VAR_spin_y
  part->spin_y[part->ipart] += value;
#endif
}


        GPUFUN
        void LocalParticle_add_to_spin_z(LocalParticle* part, double value){
#ifndef FREEZE_VAR_spin_z
  part->spin_z[part->ipart] += value;
#endif
}


        GPUFUN
        void LocalParticle_add_to_anomalous_magnetic_moment(LocalParticle* part, double value){
#ifndef FREEZE_VAR_anomalous_magnetic_moment
  part->anomalous_magnetic_moment[part->ipart] += value;
#endif
}


        GPUFUN
        void LocalParticle_add_to_pdg_id(LocalParticle* part, int64_t value){
#ifndef FREEZE_VAR_pdg_id
  part->pdg_id[part->ipart] += value;
#endif
}


        GPUFUN
        void LocalParticle_add_to_particle_id(LocalParticle* part, int64_t value){
#ifndef FREEZE_VAR_particle_id
  part->particle_id[part->ipart] += value;
#endif
}


        GPUFUN
        void LocalParticle_add_to_at_element(LocalParticle* part, int64_t value){
#ifndef FREEZE_VAR_at_element
  part->at_element[part->ipart] += value;
#endif
}


        GPUFUN
        void LocalParticle_add_to_at_turn(LocalParticle* part, int64_t value){
#ifndef FREEZE_VAR_at_turn
  part->at_turn[part->ipart] += value;
#endif
}


        GPUFUN
        void LocalParticle_add_to_state(LocalParticle* part, int64_t value){
#ifndef FREEZE_VAR_state
  part->state[part->ipart] += value;
#endif
}


        GPUFUN
        void LocalParticle_add_to_parent_particle_id(LocalParticle* part, int64_t value){
#ifndef FREEZE_VAR_parent_particle_id
  part->parent_particle_id[part->ipart] += value;
#endif
}


        GPUFUN
        void LocalParticle_add_to__rng_s1(LocalParticle* part, uint32_t value){
#ifndef FREEZE_VAR__rng_s1
  part->_rng_s1[part->ipart] += value;
#endif
}


        GPUFUN
        void LocalParticle_add_to__rng_s2(LocalParticle* part, uint32_t value){
#ifndef FREEZE_VAR__rng_s2
  part->_rng_s2[part->ipart] += value;
#endif
}


        GPUFUN
        void LocalParticle_add_to__rng_s3(LocalParticle* part, uint32_t value){
#ifndef FREEZE_VAR__rng_s3
  part->_rng_s3[part->ipart] += value;
#endif
}


        GPUFUN
        void LocalParticle_add_to__rng_s4(LocalParticle* part, uint32_t value){
#ifndef FREEZE_VAR__rng_s4
  part->_rng_s4[part->ipart] += value;
#endif
}


GPUFUN
int64_t LocalParticle_get__capacity(LocalParticle* part){
  return part->_capacity;
}
GPUFUN
int64_t LocalParticle_get__num_active_particles(LocalParticle* part){
  return part->_num_active_particles;
}
GPUFUN
int64_t LocalParticle_get__num_lost_particles(LocalParticle* part){
  return part->_num_lost_particles;
}
GPUFUN
int64_t LocalParticle_get_start_tracking_at_element(LocalParticle* part){
  return part->start_tracking_at_element;
}
GPUFUN
double LocalParticle_get_q0(LocalParticle* part){
  return part->q0;
}
GPUFUN
double LocalParticle_get_mass0(LocalParticle* part){
  return part->mass0;
}
GPUFUN
double LocalParticle_get_t_sim(LocalParticle* part){
  return part->t_sim;
}
GPUFUN
double LocalParticle_get_p0c(LocalParticle* part){
  return part->p0c[part->ipart];
}
GPUFUN
double LocalParticle_get_gamma0(LocalParticle* part){
  return part->gamma0[part->ipart];
}
GPUFUN
double LocalParticle_get_beta0(LocalParticle* part){
  return part->beta0[part->ipart];
}
GPUFUN
double LocalParticle_get_s(LocalParticle* part){
  return part->s[part->ipart];
}
GPUFUN
double LocalParticle_get_zeta(LocalParticle* part){
  return part->zeta[part->ipart];
}
GPUFUN
double LocalParticle_get_x(LocalParticle* part){
  return part->x[part->ipart];
}
GPUFUN
double LocalParticle_get_y(LocalParticle* part){
  return part->y[part->ipart];
}
GPUFUN
double LocalParticle_get_px(LocalParticle* part){
  return part->px[part->ipart];
}
GPUFUN
double LocalParticle_get_py(LocalParticle* part){
  return part->py[part->ipart];
}
GPUFUN
double LocalParticle_get_ptau(LocalParticle* part){
  return part->ptau[part->ipart];
}
GPUFUN
double LocalParticle_get_delta(LocalParticle* part){
  return part->delta[part->ipart];
}
GPUFUN
double LocalParticle_get_rpp(LocalParticle* part){
  return part->rpp[part->ipart];
}
GPUFUN
double LocalParticle_get_rvv(LocalParticle* part){
  return part->rvv[part->ipart];
}
GPUFUN
double LocalParticle_get_chi(LocalParticle* part){
  return part->chi[part->ipart];
}
GPUFUN
double LocalParticle_get_charge_ratio(LocalParticle* part){
  return part->charge_ratio[part->ipart];
}
GPUFUN
double LocalParticle_get_weight(LocalParticle* part){
  return part->weight[part->ipart];
}
GPUFUN
double LocalParticle_get_ax(LocalParticle* part){
  return part->ax[part->ipart];
}
GPUFUN
double LocalParticle_get_ay(LocalParticle* part){
  return part->ay[part->ipart];
}
GPUFUN
double LocalParticle_get_spin_x(LocalParticle* part){
  return part->spin_x[part->ipart];
}
GPUFUN
double LocalParticle_get_spin_y(LocalParticle* part){
  return part->spin_y[part->ipart];
}
GPUFUN
double LocalParticle_get_spin_z(LocalParticle* part){
  return part->spin_z[part->ipart];
}
GPUFUN
double LocalParticle_get_anomalous_magnetic_moment(LocalParticle* part){
  return part->anomalous_magnetic_moment[part->ipart];
}
GPUFUN
int64_t LocalParticle_get_pdg_id(LocalParticle* part){
  return part->pdg_id[part->ipart];
}
GPUFUN
int64_t LocalParticle_get_particle_id(LocalParticle* part){
  return part->particle_id[part->ipart];
}
GPUFUN
int64_t LocalParticle_get_at_element(LocalParticle* part){
  return part->at_element[part->ipart];
}
GPUFUN
int64_t LocalParticle_get_at_turn(LocalParticle* part){
  return part->at_turn[part->ipart];
}
GPUFUN
int64_t LocalParticle_get_state(LocalParticle* part){
  return part->state[part->ipart];
}
GPUFUN
int64_t LocalParticle_get_parent_particle_id(LocalParticle* part){
  return part->parent_particle_id[part->ipart];
}
GPUFUN
uint32_t LocalParticle_get__rng_s1(LocalParticle* part){
  return part->_rng_s1[part->ipart];
}
GPUFUN
uint32_t LocalParticle_get__rng_s2(LocalParticle* part){
  return part->_rng_s2[part->ipart];
}
GPUFUN
uint32_t LocalParticle_get__rng_s3(LocalParticle* part){
  return part->_rng_s3[part->ipart];
}
GPUFUN
uint32_t LocalParticle_get__rng_s4(LocalParticle* part){
  return part->_rng_s4[part->ipart];
}


        GPUFUN
        void LocalParticle_set_p0c(LocalParticle* part, double value){
#ifndef FREEZE_VAR_p0c
  part->p0c[part->ipart] = value;
#endif
}

        GPUFUN
        void LocalParticle_set_gamma0(LocalParticle* part, double value){
#ifndef FREEZE_VAR_gamma0
  part->gamma0[part->ipart] = value;
#endif
}

        GPUFUN
        void LocalParticle_set_beta0(LocalParticle* part, double value){
#ifndef FREEZE_VAR_beta0
  part->beta0[part->ipart] = value;
#endif
}

        GPUFUN
        void LocalParticle_set_s(LocalParticle* part, double value){
#ifndef FREEZE_VAR_s
  part->s[part->ipart] = value;
#endif
}

        GPUFUN
        void LocalParticle_set_zeta(LocalParticle* part, double value){
#ifndef FREEZE_VAR_zeta
  part->zeta[part->ipart] = value;
#endif
}

        GPUFUN
        void LocalParticle_set_x(LocalParticle* part, double value){
#ifndef FREEZE_VAR_x
  part->x[part->ipart] = value;
#endif
}

        GPUFUN
        void LocalParticle_set_y(LocalParticle* part, double value){
#ifndef FREEZE_VAR_y
  part->y[part->ipart] = value;
#endif
}

        GPUFUN
        void LocalParticle_set_px(LocalParticle* part, double value){
#ifndef FREEZE_VAR_px
  part->px[part->ipart] = value;
#endif
}

        GPUFUN
        void LocalParticle_set_py(LocalParticle* part, double value){
#ifndef FREEZE_VAR_py
  part->py[part->ipart] = value;
#endif
}

        GPUFUN
        void LocalParticle_set_ptau(LocalParticle* part, double value){
#ifndef FREEZE_VAR_ptau
  part->ptau[part->ipart] = value;
#endif
}

        GPUFUN
        void LocalParticle_set_delta(LocalParticle* part, double value){
#ifndef FREEZE_VAR_delta
  part->delta[part->ipart] = value;
#endif
}

        GPUFUN
        void LocalParticle_set_rpp(LocalParticle* part, double value){
#ifndef FREEZE_VAR_rpp
  part->rpp[part->ipart] = value;
#endif
}

        GPUFUN
        void LocalParticle_set_rvv(LocalParticle* part, double value){
#ifndef FREEZE_VAR_rvv
  part->rvv[part->ipart] = value;
#endif
}

        GPUFUN
        void LocalParticle_set_chi(LocalParticle* part, double value){
#ifndef FREEZE_VAR_chi
  part->chi[part->ipart] = value;
#endif
}

        GPUFUN
        void LocalParticle_set_charge_ratio(LocalParticle* part, double value){
#ifndef FREEZE_VAR_charge_ratio
  part->charge_ratio[part->ipart] = value;
#endif
}

        GPUFUN
        void LocalParticle_set_weight(LocalParticle* part, double value){
#ifndef FREEZE_VAR_weight
  part->weight[part->ipart] = value;
#endif
}

        GPUFUN
        void LocalParticle_set_ax(LocalParticle* part, double value){
#ifndef FREEZE_VAR_ax
  part->ax[part->ipart] = value;
#endif
}

        GPUFUN
        void LocalParticle_set_ay(LocalParticle* part, double value){
#ifndef FREEZE_VAR_ay
  part->ay[part->ipart] = value;
#endif
}

        GPUFUN
        void LocalParticle_set_spin_x(LocalParticle* part, double value){
#ifndef FREEZE_VAR_spin_x
  part->spin_x[part->ipart] = value;
#endif
}

        GPUFUN
        void LocalParticle_set_spin_y(LocalParticle* part, double value){
#ifndef FREEZE_VAR_spin_y
  part->spin_y[part->ipart] = value;
#endif
}

        GPUFUN
        void LocalParticle_set_spin_z(LocalParticle* part, double value){
#ifndef FREEZE_VAR_spin_z
  part->spin_z[part->ipart] = value;
#endif
}

        GPUFUN
        void LocalParticle_set_anomalous_magnetic_moment(LocalParticle* part, double value){
#ifndef FREEZE_VAR_anomalous_magnetic_moment
  part->anomalous_magnetic_moment[part->ipart] = value;
#endif
}

        GPUFUN
        void LocalParticle_set_pdg_id(LocalParticle* part, int64_t value){
#ifndef FREEZE_VAR_pdg_id
  part->pdg_id[part->ipart] = value;
#endif
}

        GPUFUN
        void LocalParticle_set_particle_id(LocalParticle* part, int64_t value){
#ifndef FREEZE_VAR_particle_id
  part->particle_id[part->ipart] = value;
#endif
}

        GPUFUN
        void LocalParticle_set_at_element(LocalParticle* part, int64_t value){
#ifndef FREEZE_VAR_at_element
  part->at_element[part->ipart] = value;
#endif
}

        GPUFUN
        void LocalParticle_set_at_turn(LocalParticle* part, int64_t value){
#ifndef FREEZE_VAR_at_turn
  part->at_turn[part->ipart] = value;
#endif
}

        GPUFUN
        void LocalParticle_set_state(LocalParticle* part, int64_t value){
#ifndef FREEZE_VAR_state
  part->state[part->ipart] = value;
#endif
}

        GPUFUN
        void LocalParticle_set_parent_particle_id(LocalParticle* part, int64_t value){
#ifndef FREEZE_VAR_parent_particle_id
  part->parent_particle_id[part->ipart] = value;
#endif
}

        GPUFUN
        void LocalParticle_set__rng_s1(LocalParticle* part, uint32_t value){
#ifndef FREEZE_VAR__rng_s1
  part->_rng_s1[part->ipart] = value;
#endif
}

        GPUFUN
        void LocalParticle_set__rng_s2(LocalParticle* part, uint32_t value){
#ifndef FREEZE_VAR__rng_s2
  part->_rng_s2[part->ipart] = value;
#endif
}

        GPUFUN
        void LocalParticle_set__rng_s3(LocalParticle* part, uint32_t value){
#ifndef FREEZE_VAR__rng_s3
  part->_rng_s3[part->ipart] = value;
#endif
}

        GPUFUN
        void LocalParticle_set__rng_s4(LocalParticle* part, uint32_t value){
#ifndef FREEZE_VAR__rng_s4
  part->_rng_s4[part->ipart] = value;
#endif
}


        GPUFUN
        void LocalParticle_scale_p0c(LocalParticle* part, double value){
#ifndef FREEZE_VAR_p0c
  part->p0c[part->ipart] *= value;
#endif
}


        GPUFUN
        void LocalParticle_scale_gamma0(LocalParticle* part, double value){
#ifndef FREEZE_VAR_gamma0
  part->gamma0[part->ipart] *= value;
#endif
}


        GPUFUN
        void LocalParticle_scale_beta0(LocalParticle* part, double value){
#ifndef FREEZE_VAR_beta0
  part->beta0[part->ipart] *= value;
#endif
}


        GPUFUN
        void LocalParticle_scale_s(LocalParticle* part, double value){
#ifndef FREEZE_VAR_s
  part->s[part->ipart] *= value;
#endif
}


        GPUFUN
        void LocalParticle_scale_zeta(LocalParticle* part, double value){
#ifndef FREEZE_VAR_zeta
  part->zeta[part->ipart] *= value;
#endif
}


        GPUFUN
        void LocalParticle_scale_x(LocalParticle* part, double value){
#ifndef FREEZE_VAR_x
  part->x[part->ipart] *= value;
#endif
}


        GPUFUN
        void LocalParticle_scale_y(LocalParticle* part, double value){
#ifndef FREEZE_VAR_y
  part->y[part->ipart] *= value;
#endif
}


        GPUFUN
        void LocalParticle_scale_px(LocalParticle* part, double value){
#ifndef FREEZE_VAR_px
  part->px[part->ipart] *= value;
#endif
}


        GPUFUN
        void LocalParticle_scale_py(LocalParticle* part, double value){
#ifndef FREEZE_VAR_py
  part->py[part->ipart] *= value;
#endif
}


        GPUFUN
        void LocalParticle_scale_ptau(LocalParticle* part, double value){
#ifndef FREEZE_VAR_ptau
  part->ptau[part->ipart] *= value;
#endif
}


        GPUFUN
        void LocalParticle_scale_delta(LocalParticle* part, double value){
#ifndef FREEZE_VAR_delta
  part->delta[part->ipart] *= value;
#endif
}


        GPUFUN
        void LocalParticle_scale_rpp(LocalParticle* part, double value){
#ifndef FREEZE_VAR_rpp
  part->rpp[part->ipart] *= value;
#endif
}


        GPUFUN
        void LocalParticle_scale_rvv(LocalParticle* part, double value){
#ifndef FREEZE_VAR_rvv
  part->rvv[part->ipart] *= value;
#endif
}


        GPUFUN
        void LocalParticle_scale_chi(LocalParticle* part, double value){
#ifndef FREEZE_VAR_chi
  part->chi[part->ipart] *= value;
#endif
}


        GPUFUN
        void LocalParticle_scale_charge_ratio(LocalParticle* part, double value){
#ifndef FREEZE_VAR_charge_ratio
  part->charge_ratio[part->ipart] *= value;
#endif
}


        GPUFUN
        void LocalParticle_scale_weight(LocalParticle* part, double value){
#ifndef FREEZE_VAR_weight
  part->weight[part->ipart] *= value;
#endif
}


        GPUFUN
        void LocalParticle_scale_ax(LocalParticle* part, double value){
#ifndef FREEZE_VAR_ax
  part->ax[part->ipart] *= value;
#endif
}


        GPUFUN
        void LocalParticle_scale_ay(LocalParticle* part, double value){
#ifndef FREEZE_VAR_ay
  part->ay[part->ipart] *= value;
#endif
}


        GPUFUN
        void LocalParticle_scale_spin_x(LocalParticle* part, double value){
#ifndef FREEZE_VAR_spin_x
  part->spin_x[part->ipart] *= value;
#endif
}


        GPUFUN
        void LocalParticle_scale_spin_y(LocalParticle* part, double value){
#ifndef FREEZE_VAR_spin_y
  part->spin_y[part->ipart] *= value;
#endif
}


        GPUFUN
        void LocalParticle_scale_spin_z(LocalParticle* part, double value){
#ifndef FREEZE_VAR_spin_z
  part->spin_z[part->ipart] *= value;
#endif
}


        GPUFUN
        void LocalParticle_scale_anomalous_magnetic_moment(LocalParticle* part, double value){
#ifndef FREEZE_VAR_anomalous_magnetic_moment
  part->anomalous_magnetic_moment[part->ipart] *= value;
#endif
}


        GPUFUN
        void LocalParticle_scale_pdg_id(LocalParticle* part, int64_t value){
#ifndef FREEZE_VAR_pdg_id
  part->pdg_id[part->ipart] *= value;
#endif
}


        GPUFUN
        void LocalParticle_scale_particle_id(LocalParticle* part, int64_t value){
#ifndef FREEZE_VAR_particle_id
  part->particle_id[part->ipart] *= value;
#endif
}


        GPUFUN
        void LocalParticle_scale_at_element(LocalParticle* part, int64_t value){
#ifndef FREEZE_VAR_at_element
  part->at_element[part->ipart] *= value;
#endif
}


        GPUFUN
        void LocalParticle_scale_at_turn(LocalParticle* part, int64_t value){
#ifndef FREEZE_VAR_at_turn
  part->at_turn[part->ipart] *= value;
#endif
}


        GPUFUN
        void LocalParticle_scale_state(LocalParticle* part, int64_t value){
#ifndef FREEZE_VAR_state
  part->state[part->ipart] *= value;
#endif
}


        GPUFUN
        void LocalParticle_scale_parent_particle_id(LocalParticle* part, int64_t value){
#ifndef FREEZE_VAR_parent_particle_id
  part->parent_particle_id[part->ipart] *= value;
#endif
}


        GPUFUN
        void LocalParticle_scale__rng_s1(LocalParticle* part, uint32_t value){
#ifndef FREEZE_VAR__rng_s1
  part->_rng_s1[part->ipart] *= value;
#endif
}


        GPUFUN
        void LocalParticle_scale__rng_s2(LocalParticle* part, uint32_t value){
#ifndef FREEZE_VAR__rng_s2
  part->_rng_s2[part->ipart] *= value;
#endif
}


        GPUFUN
        void LocalParticle_scale__rng_s3(LocalParticle* part, uint32_t value){
#ifndef FREEZE_VAR__rng_s3
  part->_rng_s3[part->ipart] *= value;
#endif
}


        GPUFUN
        void LocalParticle_scale__rng_s4(LocalParticle* part, uint32_t value){
#ifndef FREEZE_VAR__rng_s4
  part->_rng_s4[part->ipart] *= value;
#endif
}



    GPUFUN
    void LocalParticle_exchange(LocalParticle* part, int64_t i1, int64_t i2){
    
    {
    double temp = part->p0c[i2];
    part->p0c[i2] = part->p0c[i1];
    part->p0c[i1] = temp;
     }
    {
    double temp = part->gamma0[i2];
    part->gamma0[i2] = part->gamma0[i1];
    part->gamma0[i1] = temp;
     }
    {
    double temp = part->beta0[i2];
    part->beta0[i2] = part->beta0[i1];
    part->beta0[i1] = temp;
     }
    {
    double temp = part->s[i2];
    part->s[i2] = part->s[i1];
    part->s[i1] = temp;
     }
    {
    double temp = part->zeta[i2];
    part->zeta[i2] = part->zeta[i1];
    part->zeta[i1] = temp;
     }
    {
    double temp = part->x[i2];
    part->x[i2] = part->x[i1];
    part->x[i1] = temp;
     }
    {
    double temp = part->y[i2];
    part->y[i2] = part->y[i1];
    part->y[i1] = temp;
     }
    {
    double temp = part->px[i2];
    part->px[i2] = part->px[i1];
    part->px[i1] = temp;
     }
    {
    double temp = part->py[i2];
    part->py[i2] = part->py[i1];
    part->py[i1] = temp;
     }
    {
    double temp = part->ptau[i2];
    part->ptau[i2] = part->ptau[i1];
    part->ptau[i1] = temp;
     }
    {
    double temp = part->delta[i2];
    part->delta[i2] = part->delta[i1];
    part->delta[i1] = temp;
     }
    {
    double temp = part->rpp[i2];
    part->rpp[i2] = part->rpp[i1];
    part->rpp[i1] = temp;
     }
    {
    double temp = part->rvv[i2];
    part->rvv[i2] = part->rvv[i1];
    part->rvv[i1] = temp;
     }
    {
    double temp = part->chi[i2];
    part->chi[i2] = part->chi[i1];
    part->chi[i1] = temp;
     }
    {
    double temp = part->charge_ratio[i2];
    part->charge_ratio[i2] = part->charge_ratio[i1];
    part->charge_ratio[i1] = temp;
     }
    {
    double temp = part->weight[i2];
    part->weight[i2] = part->weight[i1];
    part->weight[i1] = temp;
     }
    {
    double temp = part->ax[i2];
    part->ax[i2] = part->ax[i1];
    part->ax[i1] = temp;
     }
    {
    double temp = part->ay[i2];
    part->ay[i2] = part->ay[i1];
    part->ay[i1] = temp;
     }
    {
    double temp = part->spin_x[i2];
    part->spin_x[i2] = part->spin_x[i1];
    part->spin_x[i1] = temp;
     }
    {
    double temp = part->spin_y[i2];
    part->spin_y[i2] = part->spin_y[i1];
    part->spin_y[i1] = temp;
     }
    {
    double temp = part->spin_z[i2];
    part->spin_z[i2] = part->spin_z[i1];
    part->spin_z[i1] = temp;
     }
    {
    double temp = part->anomalous_magnetic_moment[i2];
    part->anomalous_magnetic_moment[i2] = part->anomalous_magnetic_moment[i1];
    part->anomalous_magnetic_moment[i1] = temp;
     }
    {
    int64_t temp = part->pdg_id[i2];
    part->pdg_id[i2] = part->pdg_id[i1];
    part->pdg_id[i1] = temp;
     }
    {
    int64_t temp = part->particle_id[i2];
    part->particle_id[i2] = part->particle_id[i1];
    part->particle_id[i1] = temp;
     }
    {
    int64_t temp = part->at_element[i2];
    part->at_element[i2] = part->at_element[i1];
    part->at_element[i1] = temp;
     }
    {
    int64_t temp = part->at_turn[i2];
    part->at_turn[i2] = part->at_turn[i1];
    part->at_turn[i1] = temp;
     }
    {
    int64_t temp = part->state[i2];
    part->state[i2] = part->state[i1];
    part->state[i1] = temp;
     }
    {
    int64_t temp = part->parent_particle_id[i2];
    part->parent_particle_id[i2] = part->parent_particle_id[i1];
    part->parent_particle_id[i1] = temp;
     }
    {
    uint32_t temp = part->_rng_s1[i2];
    part->_rng_s1[i2] = part->_rng_s1[i1];
    part->_rng_s1[i1] = temp;
     }
    {
    uint32_t temp = part->_rng_s2[i2];
    part->_rng_s2[i2] = part->_rng_s2[i1];
    part->_rng_s2[i1] = temp;
     }
    {
    uint32_t temp = part->_rng_s3[i2];
    part->_rng_s3[i2] = part->_rng_s3[i1];
    part->_rng_s3[i1] = temp;
     }
    {
    uint32_t temp = part->_rng_s4[i2];
    part->_rng_s4[i2] = part->_rng_s4[i1];
    part->_rng_s4[i1] = temp;
     }}



        GPUFUN
        GPUGLMEM int8_t* LocalParticle_get_io_buffer(LocalParticle* part){
            return part->io_buffer;
        }

        

        GPUFUN
        uint64_t LocalParticle_check_track_flag(LocalParticle* part, uint8_t index){
            return (part->track_flags >> index) & 1;
        }
    

        GPUFUN
        void Particles_to_LocalParticle(ParticlesData source,
                                        LocalParticle* dest,
                                        int64_t id,
                                        int64_t eid){
  dest->_capacity = ParticlesData_get__capacity(source);
  dest->_num_active_particles = ParticlesData_get__num_active_particles(source);
  dest->_num_lost_particles = ParticlesData_get__num_lost_particles(source);
  dest->start_tracking_at_element = ParticlesData_get_start_tracking_at_element(source);
  dest->q0 = ParticlesData_get_q0(source);
  dest->mass0 = ParticlesData_get_mass0(source);
  dest->t_sim = ParticlesData_get_t_sim(source);
  dest->p0c = ParticlesData_getp1_p0c(source, 0);
  dest->gamma0 = ParticlesData_getp1_gamma0(source, 0);
  dest->beta0 = ParticlesData_getp1_beta0(source, 0);
  dest->s = ParticlesData_getp1_s(source, 0);
  dest->zeta = ParticlesData_getp1_zeta(source, 0);
  dest->x = ParticlesData_getp1_x(source, 0);
  dest->y = ParticlesData_getp1_y(source, 0);
  dest->px = ParticlesData_getp1_px(source, 0);
  dest->py = ParticlesData_getp1_py(source, 0);
  dest->ptau = ParticlesData_getp1_ptau(source, 0);
  dest->delta = ParticlesData_getp1_delta(source, 0);
  dest->rpp = ParticlesData_getp1_rpp(source, 0);
  dest->rvv = ParticlesData_getp1_rvv(source, 0);
  dest->chi = ParticlesData_getp1_chi(source, 0);
  dest->charge_ratio = ParticlesData_getp1_charge_ratio(source, 0);
  dest->weight = ParticlesData_getp1_weight(source, 0);
  dest->ax = ParticlesData_getp1_ax(source, 0);
  dest->ay = ParticlesData_getp1_ay(source, 0);
  dest->spin_x = ParticlesData_getp1_spin_x(source, 0);
  dest->spin_y = ParticlesData_getp1_spin_y(source, 0);
  dest->spin_z = ParticlesData_getp1_spin_z(source, 0);
  dest->anomalous_magnetic_moment = ParticlesData_getp1_anomalous_magnetic_moment(source, 0);
  dest->pdg_id = ParticlesData_getp1_pdg_id(source, 0);
  dest->particle_id = ParticlesData_getp1_particle_id(source, 0);
  dest->at_element = ParticlesData_getp1_at_element(source, 0);
  dest->at_turn = ParticlesData_getp1_at_turn(source, 0);
  dest->state = ParticlesData_getp1_state(source, 0);
  dest->parent_particle_id = ParticlesData_getp1_parent_particle_id(source, 0);
  dest->_rng_s1 = ParticlesData_getp1__rng_s1(source, 0);
  dest->_rng_s2 = ParticlesData_getp1__rng_s2(source, 0);
  dest->_rng_s3 = ParticlesData_getp1__rng_s3(source, 0);
  dest->_rng_s4 = ParticlesData_getp1__rng_s4(source, 0);
  dest->ipart = id;
  dest->endpart = eid;
}


        GPUFUN
        void LocalParticle_to_Particles(LocalParticle* source,
                                        ParticlesData dest,
                                        int64_t id,
                                        int64_t set_scalar){
if (set_scalar){
  ParticlesData_set__capacity(dest,      LocalParticle_get__capacity(source));
  ParticlesData_set__num_active_particles(dest,      LocalParticle_get__num_active_particles(source));
  ParticlesData_set__num_lost_particles(dest,      LocalParticle_get__num_lost_particles(source));
  ParticlesData_set_start_tracking_at_element(dest,      LocalParticle_get_start_tracking_at_element(source));
  ParticlesData_set_q0(dest,      LocalParticle_get_q0(source));
  ParticlesData_set_mass0(dest,      LocalParticle_get_mass0(source));
  ParticlesData_set_t_sim(dest,      LocalParticle_get_t_sim(source));
}
  ParticlesData_set_p0c(dest, id,       LocalParticle_get_p0c(source));
  ParticlesData_set_gamma0(dest, id,       LocalParticle_get_gamma0(source));
  ParticlesData_set_beta0(dest, id,       LocalParticle_get_beta0(source));
  ParticlesData_set_s(dest, id,       LocalParticle_get_s(source));
  ParticlesData_set_zeta(dest, id,       LocalParticle_get_zeta(source));
  ParticlesData_set_x(dest, id,       LocalParticle_get_x(source));
  ParticlesData_set_y(dest, id,       LocalParticle_get_y(source));
  ParticlesData_set_px(dest, id,       LocalParticle_get_px(source));
  ParticlesData_set_py(dest, id,       LocalParticle_get_py(source));
  ParticlesData_set_ptau(dest, id,       LocalParticle_get_ptau(source));
  ParticlesData_set_delta(dest, id,       LocalParticle_get_delta(source));
  ParticlesData_set_rpp(dest, id,       LocalParticle_get_rpp(source));
  ParticlesData_set_rvv(dest, id,       LocalParticle_get_rvv(source));
  ParticlesData_set_chi(dest, id,       LocalParticle_get_chi(source));
  ParticlesData_set_charge_ratio(dest, id,       LocalParticle_get_charge_ratio(source));
  ParticlesData_set_weight(dest, id,       LocalParticle_get_weight(source));
  ParticlesData_set_ax(dest, id,       LocalParticle_get_ax(source));
  ParticlesData_set_ay(dest, id,       LocalParticle_get_ay(source));
  ParticlesData_set_spin_x(dest, id,       LocalParticle_get_spin_x(source));
  ParticlesData_set_spin_y(dest, id,       LocalParticle_get_spin_y(source));
  ParticlesData_set_spin_z(dest, id,       LocalParticle_get_spin_z(source));
  ParticlesData_set_anomalous_magnetic_moment(dest, id,       LocalParticle_get_anomalous_magnetic_moment(source));
  ParticlesData_set_pdg_id(dest, id,       LocalParticle_get_pdg_id(source));
  ParticlesData_set_particle_id(dest, id,       LocalParticle_get_particle_id(source));
  ParticlesData_set_at_element(dest, id,       LocalParticle_get_at_element(source));
  ParticlesData_set_at_turn(dest, id,       LocalParticle_get_at_turn(source));
  ParticlesData_set_state(dest, id,       LocalParticle_get_state(source));
  ParticlesData_set_parent_particle_id(dest, id,       LocalParticle_get_parent_particle_id(source));
  ParticlesData_set__rng_s1(dest, id,       LocalParticle_get__rng_s1(source));
  ParticlesData_set__rng_s2(dest, id,       LocalParticle_get__rng_s2(source));
  ParticlesData_set__rng_s3(dest, id,       LocalParticle_get__rng_s3(source));
  ParticlesData_set__rng_s4(dest, id,       LocalParticle_get__rng_s4(source));
}

GPUFUN
double LocalParticle_get_xp(LocalParticle* part){
    double const px = LocalParticle_get_px(part);
    double const rpp = LocalParticle_get_rpp(part);
    // INFO: this is not the angle, but sin(angle)
    return px*rpp;
}

GPUFUN
double LocalParticle_get_yp(LocalParticle* part){
    double const py = LocalParticle_get_py(part);
    double const rpp = LocalParticle_get_rpp(part);
    // INFO: this is not the angle, but sin(angle)
    return py*rpp;
}

GPUFUN
void LocalParticle_set_xp(LocalParticle* part, double xp){
#ifndef FREEZE_VAR_px
    double rpp = LocalParticle_get_rpp(part);
    // INFO: xp is not the angle, but sin(angle)
    LocalParticle_set_px(part, xp/rpp);
#endif
}

GPUFUN
void LocalParticle_set_yp(LocalParticle* part, double yp){
#ifndef FREEZE_VAR_py
    double rpp = LocalParticle_get_rpp(part);
    // INFO: yp is not the angle, but sin(angle)
    LocalParticle_set_py(part, yp/rpp);
#endif
}

GPUFUN
void LocalParticle_add_to_xp(LocalParticle* part, double xp){
#ifndef FREEZE_VAR_px
    LocalParticle_set_xp(part, LocalParticle_get_xp(part) + xp);
#endif
}

GPUFUN
void LocalParticle_scale_xp(LocalParticle* part, double value){
#ifndef FREEZE_VAR_px
    LocalParticle_set_xp(part, LocalParticle_get_xp(part) * value);
#endif
}

GPUFUN
void LocalParticle_add_to_yp(LocalParticle* part, double yp){
#ifndef FREEZE_VAR_py
    LocalParticle_set_yp(part, LocalParticle_get_yp(part) + yp);
#endif
}

GPUFUN
void LocalParticle_scale_yp(LocalParticle* part, double value){
#ifndef FREEZE_VAR_py
    LocalParticle_set_yp(part, LocalParticle_get_yp(part) * value);
#endif
}

GPUFUN
void LocalParticle_set_xp_yp(LocalParticle* part, double xp, double yp){
    double rpp = LocalParticle_get_rpp(part);
#ifndef FREEZE_VAR_px
    LocalParticle_set_px(part, xp/rpp);
#endif
#ifndef FREEZE_VAR_py
    LocalParticle_set_py(part, yp/rpp);
#endif
}

GPUFUN
void LocalParticle_add_to_xp_yp(LocalParticle* part, double xp, double yp){
    LocalParticle_set_xp_yp(part, LocalParticle_get_xp(part) + xp, LocalParticle_get_yp(part) + yp);
}

GPUFUN
void LocalParticle_scale_xp_yp(LocalParticle* part, double value_x, double value_y){
    LocalParticle_set_xp_yp(part, LocalParticle_get_xp(part) * value_x, LocalParticle_get_yp(part) * value_y);
}
GPUFUN
double LocalParticle_get_exact_xp(LocalParticle* part){
    double const px = LocalParticle_get_px(part);
    double const py = LocalParticle_get_py(part);
    double const one_plus_delta = 1. + LocalParticle_get_delta(part);
    double const rpp = 1./sqrt(one_plus_delta*one_plus_delta - px*px - py*py);
    // INFO: this is not the angle, but sin(angle)
    return px*rpp;
}

GPUFUN
double LocalParticle_get_exact_yp(LocalParticle* part){
    double const py = LocalParticle_get_py(part);
    double const px = LocalParticle_get_px(part);
    double const one_plus_delta = 1. + LocalParticle_get_delta(part);
    double const rpp = 1./sqrt(one_plus_delta*one_plus_delta - px*px - py*py);
    // INFO: this is not the angle, but sin(angle)
    return py*rpp;
}

GPUFUN
void LocalParticle_set_exact_xp(LocalParticle* part, double xp){
#ifndef FREEZE_VAR_px
    double rpp = LocalParticle_get_rpp(part);
    // Careful! If yp also changes, use LocalParticle_set_exact_xp_yp!
    double const yp = LocalParticle_get_exact_yp(part);
    rpp *= sqrt(1 + xp*xp + yp*yp);
    // INFO: xp is not the angle, but sin(angle)
    LocalParticle_set_px(part, xp/rpp);
#endif
}

GPUFUN
void LocalParticle_set_exact_yp(LocalParticle* part, double yp){
#ifndef FREEZE_VAR_py
    double rpp = LocalParticle_get_rpp(part);
    // Careful! If xp also changes, use LocalParticle_set_exact_xp_yp!
    double const xp = LocalParticle_get_exact_xp(part);
    rpp *= sqrt(1 + xp*xp + yp*yp);
    // INFO: yp is not the angle, but sin(angle)
    LocalParticle_set_py(part, yp/rpp);
#endif
}

GPUFUN
void LocalParticle_add_to_exact_xp(LocalParticle* part, double xp){
#ifndef FREEZE_VAR_px
    LocalParticle_set_exact_xp(part, LocalParticle_get_exact_xp(part) + xp);
#endif
}

GPUFUN
void LocalParticle_scale_exact_xp(LocalParticle* part, double value){
#ifndef FREEZE_VAR_px
    LocalParticle_set_exact_xp(part, LocalParticle_get_exact_xp(part) * value);
#endif
}

GPUFUN
void LocalParticle_add_to_exact_yp(LocalParticle* part, double yp){
#ifndef FREEZE_VAR_py
    LocalParticle_set_exact_yp(part, LocalParticle_get_exact_yp(part) + yp);
#endif
}

GPUFUN
void LocalParticle_scale_exact_yp(LocalParticle* part, double value){
#ifndef FREEZE_VAR_py
    LocalParticle_set_exact_yp(part, LocalParticle_get_exact_yp(part) * value);
#endif
}

GPUFUN
void LocalParticle_set_exact_xp_yp(LocalParticle* part, double xp, double yp){
    double rpp = LocalParticle_get_rpp(part);
    rpp *= sqrt(1 + xp*xp + yp*yp);
#ifndef FREEZE_VAR_px
    LocalParticle_set_px(part, xp/rpp);
#endif
#ifndef FREEZE_VAR_py
    LocalParticle_set_py(part, yp/rpp);
#endif
}

GPUFUN
void LocalParticle_add_to_exact_xp_yp(LocalParticle* part, double xp, double yp){
    LocalParticle_set_exact_xp_yp(part, LocalParticle_get_exact_xp(part) + xp, LocalParticle_get_exact_yp(part) + yp);
}

GPUFUN
void LocalParticle_scale_exact_xp_yp(LocalParticle* part, double value_x, double value_y){
    LocalParticle_set_exact_xp_yp(part, LocalParticle_get_exact_xp(part) * value_x, LocalParticle_get_exact_yp(part) * value_y);
}
                #include "xtrack/particles/local_particle_custom_api.h"
    
#ifndef XOBJ_TYPEDEF_ParticlesMonitorData
#define XOBJ_TYPEDEF_ParticlesMonitorData
typedef   struct ParticlesMonitorData_s * ParticlesMonitorData;
 static inline ParticlesMonitorData ParticlesMonitorData_getp(ParticlesMonitorData restrict  obj){
  int64_t offset=0;
  return (ParticlesMonitorData)(( char*) obj+offset);
}
 static inline int64_t ParticlesMonitorData_get_start_at_turn(const ParticlesMonitorData restrict  obj){
  int64_t offset=0;
  offset+=8;
  return *( int64_t*)(( char*) obj+offset);
}
 static inline void ParticlesMonitorData_set_start_at_turn(ParticlesMonitorData restrict  obj, int64_t value){
  int64_t offset=0;
  offset+=8;
  *( int64_t*)(( char*) obj+offset)=value;
}
 static inline  int64_t* ParticlesMonitorData_getp_start_at_turn(ParticlesMonitorData restrict  obj){
  int64_t offset=0;
  offset+=8;
  return ( int64_t*)(( char*) obj+offset);
}
 static inline int64_t ParticlesMonitorData_get_stop_at_turn(const ParticlesMonitorData restrict  obj){
  int64_t offset=0;
  offset+=16;
  return *( int64_t*)(( char*) obj+offset);
}
 static inline void ParticlesMonitorData_set_stop_at_turn(ParticlesMonitorData restrict  obj, int64_t value){
  int64_t offset=0;
  offset+=16;
  *( int64_t*)(( char*) obj+offset)=value;
}
 static inline  int64_t* ParticlesMonitorData_getp_stop_at_turn(ParticlesMonitorData restrict  obj){
  int64_t offset=0;
  offset+=16;
  return ( int64_t*)(( char*) obj+offset);
}
 static inline int64_t ParticlesMonitorData_get_part_id_start(const ParticlesMonitorData restrict  obj){
  int64_t offset=0;
  offset+=24;
  return *( int64_t*)(( char*) obj+offset);
}
 static inline void ParticlesMonitorData_set_part_id_start(ParticlesMonitorData restrict  obj, int64_t value){
  int64_t offset=0;
  offset+=24;
  *( int64_t*)(( char*) obj+offset)=value;
}
 static inline  int64_t* ParticlesMonitorData_getp_part_id_start(ParticlesMonitorData restrict  obj){
  int64_t offset=0;
  offset+=24;
  return ( int64_t*)(( char*) obj+offset);
}
 static inline int64_t ParticlesMonitorData_get_part_id_end(const ParticlesMonitorData restrict  obj){
  int64_t offset=0;
  offset+=32;
  return *( int64_t*)(( char*) obj+offset);
}
 static inline void ParticlesMonitorData_set_part_id_end(ParticlesMonitorData restrict  obj, int64_t value){
  int64_t offset=0;
  offset+=32;
  *( int64_t*)(( char*) obj+offset)=value;
}
 static inline  int64_t* ParticlesMonitorData_getp_part_id_end(ParticlesMonitorData restrict  obj){
  int64_t offset=0;
  offset+=32;
  return ( int64_t*)(( char*) obj+offset);
}
 static inline int64_t ParticlesMonitorData_get_ebe_mode(const ParticlesMonitorData restrict  obj){
  int64_t offset=0;
  offset+=40;
  return *( int64_t*)(( char*) obj+offset);
}
 static inline void ParticlesMonitorData_set_ebe_mode(ParticlesMonitorData restrict  obj, int64_t value){
  int64_t offset=0;
  offset+=40;
  *( int64_t*)(( char*) obj+offset)=value;
}
 static inline  int64_t* ParticlesMonitorData_getp_ebe_mode(ParticlesMonitorData restrict  obj){
  int64_t offset=0;
  offset+=40;
  return ( int64_t*)(( char*) obj+offset);
}
 static inline int64_t ParticlesMonitorData_get_n_records(const ParticlesMonitorData restrict  obj){
  int64_t offset=0;
  offset+=48;
  return *( int64_t*)(( char*) obj+offset);
}
 static inline void ParticlesMonitorData_set_n_records(ParticlesMonitorData restrict  obj, int64_t value){
  int64_t offset=0;
  offset+=48;
  *( int64_t*)(( char*) obj+offset)=value;
}
 static inline  int64_t* ParticlesMonitorData_getp_n_records(ParticlesMonitorData restrict  obj){
  int64_t offset=0;
  offset+=48;
  return ( int64_t*)(( char*) obj+offset);
}
 static inline int64_t ParticlesMonitorData_get_n_repetitions(const ParticlesMonitorData restrict  obj){
  int64_t offset=0;
  offset+=56;
  return *( int64_t*)(( char*) obj+offset);
}
 static inline void ParticlesMonitorData_set_n_repetitions(ParticlesMonitorData restrict  obj, int64_t value){
  int64_t offset=0;
  offset+=56;
  *( int64_t*)(( char*) obj+offset)=value;
}
 static inline  int64_t* ParticlesMonitorData_getp_n_repetitions(ParticlesMonitorData restrict  obj){
  int64_t offset=0;
  offset+=56;
  return ( int64_t*)(( char*) obj+offset);
}
 static inline int64_t ParticlesMonitorData_get_repetition_period(const ParticlesMonitorData restrict  obj){
  int64_t offset=0;
  offset+=64;
  return *( int64_t*)(( char*) obj+offset);
}
 static inline void ParticlesMonitorData_set_repetition_period(ParticlesMonitorData restrict  obj, int64_t value){
  int64_t offset=0;
  offset+=64;
  *( int64_t*)(( char*) obj+offset)=value;
}
 static inline  int64_t* ParticlesMonitorData_getp_repetition_period(ParticlesMonitorData restrict  obj){
  int64_t offset=0;
  offset+=64;
  return ( int64_t*)(( char*) obj+offset);
}
 static inline int64_t ParticlesMonitorData_get_flag_auto_to_numpy(const ParticlesMonitorData restrict  obj){
  int64_t offset=0;
  offset+=72;
  return *( int64_t*)(( char*) obj+offset);
}
 static inline void ParticlesMonitorData_set_flag_auto_to_numpy(ParticlesMonitorData restrict  obj, int64_t value){
  int64_t offset=0;
  offset+=72;
  *( int64_t*)(( char*) obj+offset)=value;
}
 static inline  int64_t* ParticlesMonitorData_getp_flag_auto_to_numpy(ParticlesMonitorData restrict  obj){
  int64_t offset=0;
  offset+=72;
  return ( int64_t*)(( char*) obj+offset);
}
 static inline ParticlesData ParticlesMonitorData_getp_data(ParticlesMonitorData restrict  obj){
  int64_t offset=0;
  offset+=144;
  return (ParticlesData)(( char*) obj+offset);
}
 static inline int64_t ParticlesMonitorData_get_data__capacity(const ParticlesMonitorData restrict  obj){
  int64_t offset=0;
  offset+=152;
  return *( int64_t*)(( char*) obj+offset);
}
 static inline void ParticlesMonitorData_set_data__capacity(ParticlesMonitorData restrict  obj, int64_t value){
  int64_t offset=0;
  offset+=152;
  *( int64_t*)(( char*) obj+offset)=value;
}
 static inline  int64_t* ParticlesMonitorData_getp_data__capacity(ParticlesMonitorData restrict  obj){
  int64_t offset=0;
  offset+=152;
  return ( int64_t*)(( char*) obj+offset);
}
 static inline int64_t ParticlesMonitorData_get_data__num_active_particles(const ParticlesMonitorData restrict  obj){
  int64_t offset=0;
  offset+=160;
  return *( int64_t*)(( char*) obj+offset);
}
 static inline void ParticlesMonitorData_set_data__num_active_particles(ParticlesMonitorData restrict  obj, int64_t value){
  int64_t offset=0;
  offset+=160;
  *( int64_t*)(( char*) obj+offset)=value;
}
 static inline  int64_t* ParticlesMonitorData_getp_data__num_active_particles(ParticlesMonitorData restrict  obj){
  int64_t offset=0;
  offset+=160;
  return ( int64_t*)(( char*) obj+offset);
}
 static inline int64_t ParticlesMonitorData_get_data__num_lost_particles(const ParticlesMonitorData restrict  obj){
  int64_t offset=0;
  offset+=168;
  return *( int64_t*)(( char*) obj+offset);
}
 static inline void ParticlesMonitorData_set_data__num_lost_particles(ParticlesMonitorData restrict  obj, int64_t value){
  int64_t offset=0;
  offset+=168;
  *( int64_t*)(( char*) obj+offset)=value;
}
 static inline  int64_t* ParticlesMonitorData_getp_data__num_lost_particles(ParticlesMonitorData restrict  obj){
  int64_t offset=0;
  offset+=168;
  return ( int64_t*)(( char*) obj+offset);
}
 static inline int64_t ParticlesMonitorData_get_data_start_tracking_at_element(const ParticlesMonitorData restrict  obj){
  int64_t offset=0;
  offset+=176;
  return *( int64_t*)(( char*) obj+offset);
}
 static inline void ParticlesMonitorData_set_data_start_tracking_at_element(ParticlesMonitorData restrict  obj, int64_t value){
  int64_t offset=0;
  offset+=176;
  *( int64_t*)(( char*) obj+offset)=value;
}
 static inline  int64_t* ParticlesMonitorData_getp_data_start_tracking_at_element(ParticlesMonitorData restrict  obj){
  int64_t offset=0;
  offset+=176;
  return ( int64_t*)(( char*) obj+offset);
}
 static inline double ParticlesMonitorData_get_data_q0(const ParticlesMonitorData restrict  obj){
  int64_t offset=0;
  offset+=184;
  return *( double*)(( char*) obj+offset);
}
 static inline void ParticlesMonitorData_set_data_q0(ParticlesMonitorData restrict  obj, double value){
  int64_t offset=0;
  offset+=184;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* ParticlesMonitorData_getp_data_q0(ParticlesMonitorData restrict  obj){
  int64_t offset=0;
  offset+=184;
  return ( double*)(( char*) obj+offset);
}
 static inline double ParticlesMonitorData_get_data_mass0(const ParticlesMonitorData restrict  obj){
  int64_t offset=0;
  offset+=192;
  return *( double*)(( char*) obj+offset);
}
 static inline void ParticlesMonitorData_set_data_mass0(ParticlesMonitorData restrict  obj, double value){
  int64_t offset=0;
  offset+=192;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* ParticlesMonitorData_getp_data_mass0(ParticlesMonitorData restrict  obj){
  int64_t offset=0;
  offset+=192;
  return ( double*)(( char*) obj+offset);
}
 static inline double ParticlesMonitorData_get_data_t_sim(const ParticlesMonitorData restrict  obj){
  int64_t offset=0;
  offset+=200;
  return *( double*)(( char*) obj+offset);
}
 static inline void ParticlesMonitorData_set_data_t_sim(ParticlesMonitorData restrict  obj, double value){
  int64_t offset=0;
  offset+=200;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* ParticlesMonitorData_getp_data_t_sim(ParticlesMonitorData restrict  obj){
  int64_t offset=0;
  offset+=200;
  return ( double*)(( char*) obj+offset);
}
 static inline ArrNFloat64 ParticlesMonitorData_getp_data_p0c(ParticlesMonitorData restrict  obj){
  int64_t offset=0;
  offset+=456;
  return (ArrNFloat64)(( char*) obj+offset);
}
 static inline int64_t ParticlesMonitorData_len_data_p0c(ParticlesMonitorData restrict  obj){
  int64_t offset=0;
  offset+=456;
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  return arr[1];
}
 static inline void ParticlesMonitorData_shape_data_p0c(ParticlesMonitorData restrict  obj,  int64_t* restrict  out_shape){
  int64_t offset=0;
  offset+=456;
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  out_shape[0] = arr[1];
}
 static inline uint32_t ParticlesMonitorData_nd_data_p0c(ParticlesMonitorData restrict  obj){
  return 1;
}
 static inline double ParticlesMonitorData_get_data_p0c(const ParticlesMonitorData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=456;
  offset+=16+i0*8;
  return *( double*)(( char*) obj+offset);
}
 static inline void ParticlesMonitorData_set_data_p0c(ParticlesMonitorData restrict  obj, int64_t i0, double value){
  int64_t offset=0;
  offset+=456;
  offset+=16+i0*8;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* ParticlesMonitorData_getp1_data_p0c(ParticlesMonitorData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=456;
  offset+=16+i0*8;
  return ( double*)(( char*) obj+offset);
}
 static inline ArrNFloat64 ParticlesMonitorData_getp_data_gamma0(ParticlesMonitorData restrict  obj){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+64);
  return (ArrNFloat64)(( char*) obj+offset);
}
 static inline int64_t ParticlesMonitorData_len_data_gamma0(ParticlesMonitorData restrict  obj){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+64);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  return arr[1];
}
 static inline void ParticlesMonitorData_shape_data_gamma0(ParticlesMonitorData restrict  obj,  int64_t* restrict  out_shape){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+64);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  out_shape[0] = arr[1];
}
 static inline uint32_t ParticlesMonitorData_nd_data_gamma0(ParticlesMonitorData restrict  obj){
  return 1;
}
 static inline double ParticlesMonitorData_get_data_gamma0(const ParticlesMonitorData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+64);
  offset+=16+i0*8;
  return *( double*)(( char*) obj+offset);
}
 static inline void ParticlesMonitorData_set_data_gamma0(ParticlesMonitorData restrict  obj, int64_t i0, double value){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+64);
  offset+=16+i0*8;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* ParticlesMonitorData_getp1_data_gamma0(ParticlesMonitorData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+64);
  offset+=16+i0*8;
  return ( double*)(( char*) obj+offset);
}
 static inline ArrNFloat64 ParticlesMonitorData_getp_data_beta0(ParticlesMonitorData restrict  obj){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+72);
  return (ArrNFloat64)(( char*) obj+offset);
}
 static inline int64_t ParticlesMonitorData_len_data_beta0(ParticlesMonitorData restrict  obj){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+72);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  return arr[1];
}
 static inline void ParticlesMonitorData_shape_data_beta0(ParticlesMonitorData restrict  obj,  int64_t* restrict  out_shape){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+72);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  out_shape[0] = arr[1];
}
 static inline uint32_t ParticlesMonitorData_nd_data_beta0(ParticlesMonitorData restrict  obj){
  return 1;
}
 static inline double ParticlesMonitorData_get_data_beta0(const ParticlesMonitorData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+72);
  offset+=16+i0*8;
  return *( double*)(( char*) obj+offset);
}
 static inline void ParticlesMonitorData_set_data_beta0(ParticlesMonitorData restrict  obj, int64_t i0, double value){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+72);
  offset+=16+i0*8;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* ParticlesMonitorData_getp1_data_beta0(ParticlesMonitorData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+72);
  offset+=16+i0*8;
  return ( double*)(( char*) obj+offset);
}
 static inline ArrNFloat64 ParticlesMonitorData_getp_data_s(ParticlesMonitorData restrict  obj){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+80);
  return (ArrNFloat64)(( char*) obj+offset);
}
 static inline int64_t ParticlesMonitorData_len_data_s(ParticlesMonitorData restrict  obj){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+80);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  return arr[1];
}
 static inline void ParticlesMonitorData_shape_data_s(ParticlesMonitorData restrict  obj,  int64_t* restrict  out_shape){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+80);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  out_shape[0] = arr[1];
}
 static inline uint32_t ParticlesMonitorData_nd_data_s(ParticlesMonitorData restrict  obj){
  return 1;
}
 static inline double ParticlesMonitorData_get_data_s(const ParticlesMonitorData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+80);
  offset+=16+i0*8;
  return *( double*)(( char*) obj+offset);
}
 static inline void ParticlesMonitorData_set_data_s(ParticlesMonitorData restrict  obj, int64_t i0, double value){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+80);
  offset+=16+i0*8;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* ParticlesMonitorData_getp1_data_s(ParticlesMonitorData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+80);
  offset+=16+i0*8;
  return ( double*)(( char*) obj+offset);
}
 static inline ArrNFloat64 ParticlesMonitorData_getp_data_zeta(ParticlesMonitorData restrict  obj){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+88);
  return (ArrNFloat64)(( char*) obj+offset);
}
 static inline int64_t ParticlesMonitorData_len_data_zeta(ParticlesMonitorData restrict  obj){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+88);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  return arr[1];
}
 static inline void ParticlesMonitorData_shape_data_zeta(ParticlesMonitorData restrict  obj,  int64_t* restrict  out_shape){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+88);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  out_shape[0] = arr[1];
}
 static inline uint32_t ParticlesMonitorData_nd_data_zeta(ParticlesMonitorData restrict  obj){
  return 1;
}
 static inline double ParticlesMonitorData_get_data_zeta(const ParticlesMonitorData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+88);
  offset+=16+i0*8;
  return *( double*)(( char*) obj+offset);
}
 static inline void ParticlesMonitorData_set_data_zeta(ParticlesMonitorData restrict  obj, int64_t i0, double value){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+88);
  offset+=16+i0*8;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* ParticlesMonitorData_getp1_data_zeta(ParticlesMonitorData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+88);
  offset+=16+i0*8;
  return ( double*)(( char*) obj+offset);
}
 static inline ArrNFloat64 ParticlesMonitorData_getp_data_x(ParticlesMonitorData restrict  obj){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+96);
  return (ArrNFloat64)(( char*) obj+offset);
}
 static inline int64_t ParticlesMonitorData_len_data_x(ParticlesMonitorData restrict  obj){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+96);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  return arr[1];
}
 static inline void ParticlesMonitorData_shape_data_x(ParticlesMonitorData restrict  obj,  int64_t* restrict  out_shape){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+96);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  out_shape[0] = arr[1];
}
 static inline uint32_t ParticlesMonitorData_nd_data_x(ParticlesMonitorData restrict  obj){
  return 1;
}
 static inline double ParticlesMonitorData_get_data_x(const ParticlesMonitorData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+96);
  offset+=16+i0*8;
  return *( double*)(( char*) obj+offset);
}
 static inline void ParticlesMonitorData_set_data_x(ParticlesMonitorData restrict  obj, int64_t i0, double value){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+96);
  offset+=16+i0*8;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* ParticlesMonitorData_getp1_data_x(ParticlesMonitorData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+96);
  offset+=16+i0*8;
  return ( double*)(( char*) obj+offset);
}
 static inline ArrNFloat64 ParticlesMonitorData_getp_data_y(ParticlesMonitorData restrict  obj){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+104);
  return (ArrNFloat64)(( char*) obj+offset);
}
 static inline int64_t ParticlesMonitorData_len_data_y(ParticlesMonitorData restrict  obj){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+104);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  return arr[1];
}
 static inline void ParticlesMonitorData_shape_data_y(ParticlesMonitorData restrict  obj,  int64_t* restrict  out_shape){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+104);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  out_shape[0] = arr[1];
}
 static inline uint32_t ParticlesMonitorData_nd_data_y(ParticlesMonitorData restrict  obj){
  return 1;
}
 static inline double ParticlesMonitorData_get_data_y(const ParticlesMonitorData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+104);
  offset+=16+i0*8;
  return *( double*)(( char*) obj+offset);
}
 static inline void ParticlesMonitorData_set_data_y(ParticlesMonitorData restrict  obj, int64_t i0, double value){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+104);
  offset+=16+i0*8;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* ParticlesMonitorData_getp1_data_y(ParticlesMonitorData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+104);
  offset+=16+i0*8;
  return ( double*)(( char*) obj+offset);
}
 static inline ArrNFloat64 ParticlesMonitorData_getp_data_px(ParticlesMonitorData restrict  obj){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+112);
  return (ArrNFloat64)(( char*) obj+offset);
}
 static inline int64_t ParticlesMonitorData_len_data_px(ParticlesMonitorData restrict  obj){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+112);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  return arr[1];
}
 static inline void ParticlesMonitorData_shape_data_px(ParticlesMonitorData restrict  obj,  int64_t* restrict  out_shape){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+112);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  out_shape[0] = arr[1];
}
 static inline uint32_t ParticlesMonitorData_nd_data_px(ParticlesMonitorData restrict  obj){
  return 1;
}
 static inline double ParticlesMonitorData_get_data_px(const ParticlesMonitorData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+112);
  offset+=16+i0*8;
  return *( double*)(( char*) obj+offset);
}
 static inline void ParticlesMonitorData_set_data_px(ParticlesMonitorData restrict  obj, int64_t i0, double value){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+112);
  offset+=16+i0*8;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* ParticlesMonitorData_getp1_data_px(ParticlesMonitorData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+112);
  offset+=16+i0*8;
  return ( double*)(( char*) obj+offset);
}
 static inline ArrNFloat64 ParticlesMonitorData_getp_data_py(ParticlesMonitorData restrict  obj){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+120);
  return (ArrNFloat64)(( char*) obj+offset);
}
 static inline int64_t ParticlesMonitorData_len_data_py(ParticlesMonitorData restrict  obj){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+120);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  return arr[1];
}
 static inline void ParticlesMonitorData_shape_data_py(ParticlesMonitorData restrict  obj,  int64_t* restrict  out_shape){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+120);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  out_shape[0] = arr[1];
}
 static inline uint32_t ParticlesMonitorData_nd_data_py(ParticlesMonitorData restrict  obj){
  return 1;
}
 static inline double ParticlesMonitorData_get_data_py(const ParticlesMonitorData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+120);
  offset+=16+i0*8;
  return *( double*)(( char*) obj+offset);
}
 static inline void ParticlesMonitorData_set_data_py(ParticlesMonitorData restrict  obj, int64_t i0, double value){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+120);
  offset+=16+i0*8;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* ParticlesMonitorData_getp1_data_py(ParticlesMonitorData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+120);
  offset+=16+i0*8;
  return ( double*)(( char*) obj+offset);
}
 static inline ArrNFloat64 ParticlesMonitorData_getp_data_ptau(ParticlesMonitorData restrict  obj){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+128);
  return (ArrNFloat64)(( char*) obj+offset);
}
 static inline int64_t ParticlesMonitorData_len_data_ptau(ParticlesMonitorData restrict  obj){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+128);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  return arr[1];
}
 static inline void ParticlesMonitorData_shape_data_ptau(ParticlesMonitorData restrict  obj,  int64_t* restrict  out_shape){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+128);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  out_shape[0] = arr[1];
}
 static inline uint32_t ParticlesMonitorData_nd_data_ptau(ParticlesMonitorData restrict  obj){
  return 1;
}
 static inline double ParticlesMonitorData_get_data_ptau(const ParticlesMonitorData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+128);
  offset+=16+i0*8;
  return *( double*)(( char*) obj+offset);
}
 static inline void ParticlesMonitorData_set_data_ptau(ParticlesMonitorData restrict  obj, int64_t i0, double value){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+128);
  offset+=16+i0*8;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* ParticlesMonitorData_getp1_data_ptau(ParticlesMonitorData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+128);
  offset+=16+i0*8;
  return ( double*)(( char*) obj+offset);
}
 static inline ArrNFloat64 ParticlesMonitorData_getp_data_delta(ParticlesMonitorData restrict  obj){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+136);
  return (ArrNFloat64)(( char*) obj+offset);
}
 static inline int64_t ParticlesMonitorData_len_data_delta(ParticlesMonitorData restrict  obj){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+136);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  return arr[1];
}
 static inline void ParticlesMonitorData_shape_data_delta(ParticlesMonitorData restrict  obj,  int64_t* restrict  out_shape){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+136);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  out_shape[0] = arr[1];
}
 static inline uint32_t ParticlesMonitorData_nd_data_delta(ParticlesMonitorData restrict  obj){
  return 1;
}
 static inline double ParticlesMonitorData_get_data_delta(const ParticlesMonitorData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+136);
  offset+=16+i0*8;
  return *( double*)(( char*) obj+offset);
}
 static inline void ParticlesMonitorData_set_data_delta(ParticlesMonitorData restrict  obj, int64_t i0, double value){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+136);
  offset+=16+i0*8;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* ParticlesMonitorData_getp1_data_delta(ParticlesMonitorData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+136);
  offset+=16+i0*8;
  return ( double*)(( char*) obj+offset);
}
 static inline ArrNFloat64 ParticlesMonitorData_getp_data_rpp(ParticlesMonitorData restrict  obj){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+144);
  return (ArrNFloat64)(( char*) obj+offset);
}
 static inline int64_t ParticlesMonitorData_len_data_rpp(ParticlesMonitorData restrict  obj){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+144);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  return arr[1];
}
 static inline void ParticlesMonitorData_shape_data_rpp(ParticlesMonitorData restrict  obj,  int64_t* restrict  out_shape){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+144);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  out_shape[0] = arr[1];
}
 static inline uint32_t ParticlesMonitorData_nd_data_rpp(ParticlesMonitorData restrict  obj){
  return 1;
}
 static inline double ParticlesMonitorData_get_data_rpp(const ParticlesMonitorData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+144);
  offset+=16+i0*8;
  return *( double*)(( char*) obj+offset);
}
 static inline void ParticlesMonitorData_set_data_rpp(ParticlesMonitorData restrict  obj, int64_t i0, double value){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+144);
  offset+=16+i0*8;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* ParticlesMonitorData_getp1_data_rpp(ParticlesMonitorData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+144);
  offset+=16+i0*8;
  return ( double*)(( char*) obj+offset);
}
 static inline ArrNFloat64 ParticlesMonitorData_getp_data_rvv(ParticlesMonitorData restrict  obj){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+152);
  return (ArrNFloat64)(( char*) obj+offset);
}
 static inline int64_t ParticlesMonitorData_len_data_rvv(ParticlesMonitorData restrict  obj){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+152);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  return arr[1];
}
 static inline void ParticlesMonitorData_shape_data_rvv(ParticlesMonitorData restrict  obj,  int64_t* restrict  out_shape){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+152);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  out_shape[0] = arr[1];
}
 static inline uint32_t ParticlesMonitorData_nd_data_rvv(ParticlesMonitorData restrict  obj){
  return 1;
}
 static inline double ParticlesMonitorData_get_data_rvv(const ParticlesMonitorData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+152);
  offset+=16+i0*8;
  return *( double*)(( char*) obj+offset);
}
 static inline void ParticlesMonitorData_set_data_rvv(ParticlesMonitorData restrict  obj, int64_t i0, double value){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+152);
  offset+=16+i0*8;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* ParticlesMonitorData_getp1_data_rvv(ParticlesMonitorData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+152);
  offset+=16+i0*8;
  return ( double*)(( char*) obj+offset);
}
 static inline ArrNFloat64 ParticlesMonitorData_getp_data_chi(ParticlesMonitorData restrict  obj){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+160);
  return (ArrNFloat64)(( char*) obj+offset);
}
 static inline int64_t ParticlesMonitorData_len_data_chi(ParticlesMonitorData restrict  obj){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+160);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  return arr[1];
}
 static inline void ParticlesMonitorData_shape_data_chi(ParticlesMonitorData restrict  obj,  int64_t* restrict  out_shape){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+160);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  out_shape[0] = arr[1];
}
 static inline uint32_t ParticlesMonitorData_nd_data_chi(ParticlesMonitorData restrict  obj){
  return 1;
}
 static inline double ParticlesMonitorData_get_data_chi(const ParticlesMonitorData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+160);
  offset+=16+i0*8;
  return *( double*)(( char*) obj+offset);
}
 static inline void ParticlesMonitorData_set_data_chi(ParticlesMonitorData restrict  obj, int64_t i0, double value){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+160);
  offset+=16+i0*8;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* ParticlesMonitorData_getp1_data_chi(ParticlesMonitorData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+160);
  offset+=16+i0*8;
  return ( double*)(( char*) obj+offset);
}
 static inline ArrNFloat64 ParticlesMonitorData_getp_data_charge_ratio(ParticlesMonitorData restrict  obj){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+168);
  return (ArrNFloat64)(( char*) obj+offset);
}
 static inline int64_t ParticlesMonitorData_len_data_charge_ratio(ParticlesMonitorData restrict  obj){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+168);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  return arr[1];
}
 static inline void ParticlesMonitorData_shape_data_charge_ratio(ParticlesMonitorData restrict  obj,  int64_t* restrict  out_shape){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+168);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  out_shape[0] = arr[1];
}
 static inline uint32_t ParticlesMonitorData_nd_data_charge_ratio(ParticlesMonitorData restrict  obj){
  return 1;
}
 static inline double ParticlesMonitorData_get_data_charge_ratio(const ParticlesMonitorData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+168);
  offset+=16+i0*8;
  return *( double*)(( char*) obj+offset);
}
 static inline void ParticlesMonitorData_set_data_charge_ratio(ParticlesMonitorData restrict  obj, int64_t i0, double value){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+168);
  offset+=16+i0*8;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* ParticlesMonitorData_getp1_data_charge_ratio(ParticlesMonitorData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+168);
  offset+=16+i0*8;
  return ( double*)(( char*) obj+offset);
}
 static inline ArrNFloat64 ParticlesMonitorData_getp_data_weight(ParticlesMonitorData restrict  obj){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+176);
  return (ArrNFloat64)(( char*) obj+offset);
}
 static inline int64_t ParticlesMonitorData_len_data_weight(ParticlesMonitorData restrict  obj){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+176);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  return arr[1];
}
 static inline void ParticlesMonitorData_shape_data_weight(ParticlesMonitorData restrict  obj,  int64_t* restrict  out_shape){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+176);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  out_shape[0] = arr[1];
}
 static inline uint32_t ParticlesMonitorData_nd_data_weight(ParticlesMonitorData restrict  obj){
  return 1;
}
 static inline double ParticlesMonitorData_get_data_weight(const ParticlesMonitorData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+176);
  offset+=16+i0*8;
  return *( double*)(( char*) obj+offset);
}
 static inline void ParticlesMonitorData_set_data_weight(ParticlesMonitorData restrict  obj, int64_t i0, double value){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+176);
  offset+=16+i0*8;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* ParticlesMonitorData_getp1_data_weight(ParticlesMonitorData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+176);
  offset+=16+i0*8;
  return ( double*)(( char*) obj+offset);
}
 static inline ArrNFloat64 ParticlesMonitorData_getp_data_ax(ParticlesMonitorData restrict  obj){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+184);
  return (ArrNFloat64)(( char*) obj+offset);
}
 static inline int64_t ParticlesMonitorData_len_data_ax(ParticlesMonitorData restrict  obj){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+184);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  return arr[1];
}
 static inline void ParticlesMonitorData_shape_data_ax(ParticlesMonitorData restrict  obj,  int64_t* restrict  out_shape){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+184);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  out_shape[0] = arr[1];
}
 static inline uint32_t ParticlesMonitorData_nd_data_ax(ParticlesMonitorData restrict  obj){
  return 1;
}
 static inline double ParticlesMonitorData_get_data_ax(const ParticlesMonitorData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+184);
  offset+=16+i0*8;
  return *( double*)(( char*) obj+offset);
}
 static inline void ParticlesMonitorData_set_data_ax(ParticlesMonitorData restrict  obj, int64_t i0, double value){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+184);
  offset+=16+i0*8;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* ParticlesMonitorData_getp1_data_ax(ParticlesMonitorData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+184);
  offset+=16+i0*8;
  return ( double*)(( char*) obj+offset);
}
 static inline ArrNFloat64 ParticlesMonitorData_getp_data_ay(ParticlesMonitorData restrict  obj){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+192);
  return (ArrNFloat64)(( char*) obj+offset);
}
 static inline int64_t ParticlesMonitorData_len_data_ay(ParticlesMonitorData restrict  obj){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+192);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  return arr[1];
}
 static inline void ParticlesMonitorData_shape_data_ay(ParticlesMonitorData restrict  obj,  int64_t* restrict  out_shape){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+192);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  out_shape[0] = arr[1];
}
 static inline uint32_t ParticlesMonitorData_nd_data_ay(ParticlesMonitorData restrict  obj){
  return 1;
}
 static inline double ParticlesMonitorData_get_data_ay(const ParticlesMonitorData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+192);
  offset+=16+i0*8;
  return *( double*)(( char*) obj+offset);
}
 static inline void ParticlesMonitorData_set_data_ay(ParticlesMonitorData restrict  obj, int64_t i0, double value){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+192);
  offset+=16+i0*8;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* ParticlesMonitorData_getp1_data_ay(ParticlesMonitorData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+192);
  offset+=16+i0*8;
  return ( double*)(( char*) obj+offset);
}
 static inline ArrNFloat64 ParticlesMonitorData_getp_data_spin_x(ParticlesMonitorData restrict  obj){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+200);
  return (ArrNFloat64)(( char*) obj+offset);
}
 static inline int64_t ParticlesMonitorData_len_data_spin_x(ParticlesMonitorData restrict  obj){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+200);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  return arr[1];
}
 static inline void ParticlesMonitorData_shape_data_spin_x(ParticlesMonitorData restrict  obj,  int64_t* restrict  out_shape){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+200);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  out_shape[0] = arr[1];
}
 static inline uint32_t ParticlesMonitorData_nd_data_spin_x(ParticlesMonitorData restrict  obj){
  return 1;
}
 static inline double ParticlesMonitorData_get_data_spin_x(const ParticlesMonitorData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+200);
  offset+=16+i0*8;
  return *( double*)(( char*) obj+offset);
}
 static inline void ParticlesMonitorData_set_data_spin_x(ParticlesMonitorData restrict  obj, int64_t i0, double value){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+200);
  offset+=16+i0*8;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* ParticlesMonitorData_getp1_data_spin_x(ParticlesMonitorData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+200);
  offset+=16+i0*8;
  return ( double*)(( char*) obj+offset);
}
 static inline ArrNFloat64 ParticlesMonitorData_getp_data_spin_y(ParticlesMonitorData restrict  obj){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+208);
  return (ArrNFloat64)(( char*) obj+offset);
}
 static inline int64_t ParticlesMonitorData_len_data_spin_y(ParticlesMonitorData restrict  obj){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+208);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  return arr[1];
}
 static inline void ParticlesMonitorData_shape_data_spin_y(ParticlesMonitorData restrict  obj,  int64_t* restrict  out_shape){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+208);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  out_shape[0] = arr[1];
}
 static inline uint32_t ParticlesMonitorData_nd_data_spin_y(ParticlesMonitorData restrict  obj){
  return 1;
}
 static inline double ParticlesMonitorData_get_data_spin_y(const ParticlesMonitorData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+208);
  offset+=16+i0*8;
  return *( double*)(( char*) obj+offset);
}
 static inline void ParticlesMonitorData_set_data_spin_y(ParticlesMonitorData restrict  obj, int64_t i0, double value){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+208);
  offset+=16+i0*8;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* ParticlesMonitorData_getp1_data_spin_y(ParticlesMonitorData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+208);
  offset+=16+i0*8;
  return ( double*)(( char*) obj+offset);
}
 static inline ArrNFloat64 ParticlesMonitorData_getp_data_spin_z(ParticlesMonitorData restrict  obj){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+216);
  return (ArrNFloat64)(( char*) obj+offset);
}
 static inline int64_t ParticlesMonitorData_len_data_spin_z(ParticlesMonitorData restrict  obj){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+216);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  return arr[1];
}
 static inline void ParticlesMonitorData_shape_data_spin_z(ParticlesMonitorData restrict  obj,  int64_t* restrict  out_shape){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+216);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  out_shape[0] = arr[1];
}
 static inline uint32_t ParticlesMonitorData_nd_data_spin_z(ParticlesMonitorData restrict  obj){
  return 1;
}
 static inline double ParticlesMonitorData_get_data_spin_z(const ParticlesMonitorData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+216);
  offset+=16+i0*8;
  return *( double*)(( char*) obj+offset);
}
 static inline void ParticlesMonitorData_set_data_spin_z(ParticlesMonitorData restrict  obj, int64_t i0, double value){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+216);
  offset+=16+i0*8;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* ParticlesMonitorData_getp1_data_spin_z(ParticlesMonitorData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+216);
  offset+=16+i0*8;
  return ( double*)(( char*) obj+offset);
}
 static inline ArrNFloat64 ParticlesMonitorData_getp_data_anomalous_magnetic_moment(ParticlesMonitorData restrict  obj){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+224);
  return (ArrNFloat64)(( char*) obj+offset);
}
 static inline int64_t ParticlesMonitorData_len_data_anomalous_magnetic_moment(ParticlesMonitorData restrict  obj){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+224);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  return arr[1];
}
 static inline void ParticlesMonitorData_shape_data_anomalous_magnetic_moment(ParticlesMonitorData restrict  obj,  int64_t* restrict  out_shape){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+224);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  out_shape[0] = arr[1];
}
 static inline uint32_t ParticlesMonitorData_nd_data_anomalous_magnetic_moment(ParticlesMonitorData restrict  obj){
  return 1;
}
 static inline double ParticlesMonitorData_get_data_anomalous_magnetic_moment(const ParticlesMonitorData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+224);
  offset+=16+i0*8;
  return *( double*)(( char*) obj+offset);
}
 static inline void ParticlesMonitorData_set_data_anomalous_magnetic_moment(ParticlesMonitorData restrict  obj, int64_t i0, double value){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+224);
  offset+=16+i0*8;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* ParticlesMonitorData_getp1_data_anomalous_magnetic_moment(ParticlesMonitorData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+224);
  offset+=16+i0*8;
  return ( double*)(( char*) obj+offset);
}
 static inline ArrNInt64 ParticlesMonitorData_getp_data_pdg_id(ParticlesMonitorData restrict  obj){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+232);
  return (ArrNInt64)(( char*) obj+offset);
}
 static inline int64_t ParticlesMonitorData_len_data_pdg_id(ParticlesMonitorData restrict  obj){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+232);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  return arr[1];
}
 static inline void ParticlesMonitorData_shape_data_pdg_id(ParticlesMonitorData restrict  obj,  int64_t* restrict  out_shape){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+232);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  out_shape[0] = arr[1];
}
 static inline uint32_t ParticlesMonitorData_nd_data_pdg_id(ParticlesMonitorData restrict  obj){
  return 1;
}
 static inline int64_t ParticlesMonitorData_get_data_pdg_id(const ParticlesMonitorData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+232);
  offset+=16+i0*8;
  return *( int64_t*)(( char*) obj+offset);
}
 static inline void ParticlesMonitorData_set_data_pdg_id(ParticlesMonitorData restrict  obj, int64_t i0, int64_t value){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+232);
  offset+=16+i0*8;
  *( int64_t*)(( char*) obj+offset)=value;
}
 static inline  int64_t* ParticlesMonitorData_getp1_data_pdg_id(ParticlesMonitorData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+232);
  offset+=16+i0*8;
  return ( int64_t*)(( char*) obj+offset);
}
 static inline ArrNInt64 ParticlesMonitorData_getp_data_particle_id(ParticlesMonitorData restrict  obj){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+240);
  return (ArrNInt64)(( char*) obj+offset);
}
 static inline int64_t ParticlesMonitorData_len_data_particle_id(ParticlesMonitorData restrict  obj){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+240);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  return arr[1];
}
 static inline void ParticlesMonitorData_shape_data_particle_id(ParticlesMonitorData restrict  obj,  int64_t* restrict  out_shape){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+240);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  out_shape[0] = arr[1];
}
 static inline uint32_t ParticlesMonitorData_nd_data_particle_id(ParticlesMonitorData restrict  obj){
  return 1;
}
 static inline int64_t ParticlesMonitorData_get_data_particle_id(const ParticlesMonitorData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+240);
  offset+=16+i0*8;
  return *( int64_t*)(( char*) obj+offset);
}
 static inline void ParticlesMonitorData_set_data_particle_id(ParticlesMonitorData restrict  obj, int64_t i0, int64_t value){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+240);
  offset+=16+i0*8;
  *( int64_t*)(( char*) obj+offset)=value;
}
 static inline  int64_t* ParticlesMonitorData_getp1_data_particle_id(ParticlesMonitorData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+240);
  offset+=16+i0*8;
  return ( int64_t*)(( char*) obj+offset);
}
 static inline ArrNInt64 ParticlesMonitorData_getp_data_at_element(ParticlesMonitorData restrict  obj){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+248);
  return (ArrNInt64)(( char*) obj+offset);
}
 static inline int64_t ParticlesMonitorData_len_data_at_element(ParticlesMonitorData restrict  obj){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+248);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  return arr[1];
}
 static inline void ParticlesMonitorData_shape_data_at_element(ParticlesMonitorData restrict  obj,  int64_t* restrict  out_shape){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+248);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  out_shape[0] = arr[1];
}
 static inline uint32_t ParticlesMonitorData_nd_data_at_element(ParticlesMonitorData restrict  obj){
  return 1;
}
 static inline int64_t ParticlesMonitorData_get_data_at_element(const ParticlesMonitorData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+248);
  offset+=16+i0*8;
  return *( int64_t*)(( char*) obj+offset);
}
 static inline void ParticlesMonitorData_set_data_at_element(ParticlesMonitorData restrict  obj, int64_t i0, int64_t value){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+248);
  offset+=16+i0*8;
  *( int64_t*)(( char*) obj+offset)=value;
}
 static inline  int64_t* ParticlesMonitorData_getp1_data_at_element(ParticlesMonitorData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+248);
  offset+=16+i0*8;
  return ( int64_t*)(( char*) obj+offset);
}
 static inline ArrNInt64 ParticlesMonitorData_getp_data_at_turn(ParticlesMonitorData restrict  obj){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+256);
  return (ArrNInt64)(( char*) obj+offset);
}
 static inline int64_t ParticlesMonitorData_len_data_at_turn(ParticlesMonitorData restrict  obj){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+256);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  return arr[1];
}
 static inline void ParticlesMonitorData_shape_data_at_turn(ParticlesMonitorData restrict  obj,  int64_t* restrict  out_shape){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+256);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  out_shape[0] = arr[1];
}
 static inline uint32_t ParticlesMonitorData_nd_data_at_turn(ParticlesMonitorData restrict  obj){
  return 1;
}
 static inline int64_t ParticlesMonitorData_get_data_at_turn(const ParticlesMonitorData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+256);
  offset+=16+i0*8;
  return *( int64_t*)(( char*) obj+offset);
}
 static inline void ParticlesMonitorData_set_data_at_turn(ParticlesMonitorData restrict  obj, int64_t i0, int64_t value){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+256);
  offset+=16+i0*8;
  *( int64_t*)(( char*) obj+offset)=value;
}
 static inline  int64_t* ParticlesMonitorData_getp1_data_at_turn(ParticlesMonitorData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+256);
  offset+=16+i0*8;
  return ( int64_t*)(( char*) obj+offset);
}
 static inline ArrNInt64 ParticlesMonitorData_getp_data_state(ParticlesMonitorData restrict  obj){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+264);
  return (ArrNInt64)(( char*) obj+offset);
}
 static inline int64_t ParticlesMonitorData_len_data_state(ParticlesMonitorData restrict  obj){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+264);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  return arr[1];
}
 static inline void ParticlesMonitorData_shape_data_state(ParticlesMonitorData restrict  obj,  int64_t* restrict  out_shape){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+264);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  out_shape[0] = arr[1];
}
 static inline uint32_t ParticlesMonitorData_nd_data_state(ParticlesMonitorData restrict  obj){
  return 1;
}
 static inline int64_t ParticlesMonitorData_get_data_state(const ParticlesMonitorData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+264);
  offset+=16+i0*8;
  return *( int64_t*)(( char*) obj+offset);
}
 static inline void ParticlesMonitorData_set_data_state(ParticlesMonitorData restrict  obj, int64_t i0, int64_t value){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+264);
  offset+=16+i0*8;
  *( int64_t*)(( char*) obj+offset)=value;
}
 static inline  int64_t* ParticlesMonitorData_getp1_data_state(ParticlesMonitorData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+264);
  offset+=16+i0*8;
  return ( int64_t*)(( char*) obj+offset);
}
 static inline ArrNInt64 ParticlesMonitorData_getp_data_parent_particle_id(ParticlesMonitorData restrict  obj){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+272);
  return (ArrNInt64)(( char*) obj+offset);
}
 static inline int64_t ParticlesMonitorData_len_data_parent_particle_id(ParticlesMonitorData restrict  obj){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+272);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  return arr[1];
}
 static inline void ParticlesMonitorData_shape_data_parent_particle_id(ParticlesMonitorData restrict  obj,  int64_t* restrict  out_shape){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+272);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  out_shape[0] = arr[1];
}
 static inline uint32_t ParticlesMonitorData_nd_data_parent_particle_id(ParticlesMonitorData restrict  obj){
  return 1;
}
 static inline int64_t ParticlesMonitorData_get_data_parent_particle_id(const ParticlesMonitorData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+272);
  offset+=16+i0*8;
  return *( int64_t*)(( char*) obj+offset);
}
 static inline void ParticlesMonitorData_set_data_parent_particle_id(ParticlesMonitorData restrict  obj, int64_t i0, int64_t value){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+272);
  offset+=16+i0*8;
  *( int64_t*)(( char*) obj+offset)=value;
}
 static inline  int64_t* ParticlesMonitorData_getp1_data_parent_particle_id(ParticlesMonitorData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+272);
  offset+=16+i0*8;
  return ( int64_t*)(( char*) obj+offset);
}
 static inline ArrNUint32 ParticlesMonitorData_getp_data__rng_s1(ParticlesMonitorData restrict  obj){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+280);
  return (ArrNUint32)(( char*) obj+offset);
}
 static inline int64_t ParticlesMonitorData_len_data__rng_s1(ParticlesMonitorData restrict  obj){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+280);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  return arr[1];
}
 static inline void ParticlesMonitorData_shape_data__rng_s1(ParticlesMonitorData restrict  obj,  int64_t* restrict  out_shape){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+280);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  out_shape[0] = arr[1];
}
 static inline uint32_t ParticlesMonitorData_nd_data__rng_s1(ParticlesMonitorData restrict  obj){
  return 1;
}
 static inline uint32_t ParticlesMonitorData_get_data__rng_s1(const ParticlesMonitorData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+280);
  offset+=16+i0*4;
  return *( uint32_t*)(( char*) obj+offset);
}
 static inline void ParticlesMonitorData_set_data__rng_s1(ParticlesMonitorData restrict  obj, int64_t i0, uint32_t value){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+280);
  offset+=16+i0*4;
  *( uint32_t*)(( char*) obj+offset)=value;
}
 static inline  uint32_t* ParticlesMonitorData_getp1_data__rng_s1(ParticlesMonitorData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+280);
  offset+=16+i0*4;
  return ( uint32_t*)(( char*) obj+offset);
}
 static inline ArrNUint32 ParticlesMonitorData_getp_data__rng_s2(ParticlesMonitorData restrict  obj){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+288);
  return (ArrNUint32)(( char*) obj+offset);
}
 static inline int64_t ParticlesMonitorData_len_data__rng_s2(ParticlesMonitorData restrict  obj){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+288);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  return arr[1];
}
 static inline void ParticlesMonitorData_shape_data__rng_s2(ParticlesMonitorData restrict  obj,  int64_t* restrict  out_shape){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+288);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  out_shape[0] = arr[1];
}
 static inline uint32_t ParticlesMonitorData_nd_data__rng_s2(ParticlesMonitorData restrict  obj){
  return 1;
}
 static inline uint32_t ParticlesMonitorData_get_data__rng_s2(const ParticlesMonitorData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+288);
  offset+=16+i0*4;
  return *( uint32_t*)(( char*) obj+offset);
}
 static inline void ParticlesMonitorData_set_data__rng_s2(ParticlesMonitorData restrict  obj, int64_t i0, uint32_t value){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+288);
  offset+=16+i0*4;
  *( uint32_t*)(( char*) obj+offset)=value;
}
 static inline  uint32_t* ParticlesMonitorData_getp1_data__rng_s2(ParticlesMonitorData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+288);
  offset+=16+i0*4;
  return ( uint32_t*)(( char*) obj+offset);
}
 static inline ArrNUint32 ParticlesMonitorData_getp_data__rng_s3(ParticlesMonitorData restrict  obj){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+296);
  return (ArrNUint32)(( char*) obj+offset);
}
 static inline int64_t ParticlesMonitorData_len_data__rng_s3(ParticlesMonitorData restrict  obj){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+296);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  return arr[1];
}
 static inline void ParticlesMonitorData_shape_data__rng_s3(ParticlesMonitorData restrict  obj,  int64_t* restrict  out_shape){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+296);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  out_shape[0] = arr[1];
}
 static inline uint32_t ParticlesMonitorData_nd_data__rng_s3(ParticlesMonitorData restrict  obj){
  return 1;
}
 static inline uint32_t ParticlesMonitorData_get_data__rng_s3(const ParticlesMonitorData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+296);
  offset+=16+i0*4;
  return *( uint32_t*)(( char*) obj+offset);
}
 static inline void ParticlesMonitorData_set_data__rng_s3(ParticlesMonitorData restrict  obj, int64_t i0, uint32_t value){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+296);
  offset+=16+i0*4;
  *( uint32_t*)(( char*) obj+offset)=value;
}
 static inline  uint32_t* ParticlesMonitorData_getp1_data__rng_s3(ParticlesMonitorData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+296);
  offset+=16+i0*4;
  return ( uint32_t*)(( char*) obj+offset);
}
 static inline ArrNUint32 ParticlesMonitorData_getp_data__rng_s4(ParticlesMonitorData restrict  obj){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+304);
  return (ArrNUint32)(( char*) obj+offset);
}
 static inline int64_t ParticlesMonitorData_len_data__rng_s4(ParticlesMonitorData restrict  obj){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+304);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  return arr[1];
}
 static inline void ParticlesMonitorData_shape_data__rng_s4(ParticlesMonitorData restrict  obj,  int64_t* restrict  out_shape){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+304);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  out_shape[0] = arr[1];
}
 static inline uint32_t ParticlesMonitorData_nd_data__rng_s4(ParticlesMonitorData restrict  obj){
  return 1;
}
 static inline uint32_t ParticlesMonitorData_get_data__rng_s4(const ParticlesMonitorData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+304);
  offset+=16+i0*4;
  return *( uint32_t*)(( char*) obj+offset);
}
 static inline void ParticlesMonitorData_set_data__rng_s4(ParticlesMonitorData restrict  obj, int64_t i0, uint32_t value){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+304);
  offset+=16+i0*4;
  *( uint32_t*)(( char*) obj+offset)=value;
}
 static inline  uint32_t* ParticlesMonitorData_getp1_data__rng_s4(ParticlesMonitorData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=144;
  offset+=*( int64_t*)(( char*) obj+offset+304);
  offset+=16+i0*4;
  return ( uint32_t*)(( char*) obj+offset);
}
 static inline double ParticlesMonitorData_get_shift_x(const ParticlesMonitorData restrict  obj){
  int64_t offset=0;
  offset+=80;
  return *( double*)(( char*) obj+offset);
}
 static inline void ParticlesMonitorData_set_shift_x(ParticlesMonitorData restrict  obj, double value){
  int64_t offset=0;
  offset+=80;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* ParticlesMonitorData_getp_shift_x(ParticlesMonitorData restrict  obj){
  int64_t offset=0;
  offset+=80;
  return ( double*)(( char*) obj+offset);
}
 static inline double ParticlesMonitorData_get_shift_y(const ParticlesMonitorData restrict  obj){
  int64_t offset=0;
  offset+=88;
  return *( double*)(( char*) obj+offset);
}
 static inline void ParticlesMonitorData_set_shift_y(ParticlesMonitorData restrict  obj, double value){
  int64_t offset=0;
  offset+=88;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* ParticlesMonitorData_getp_shift_y(ParticlesMonitorData restrict  obj){
  int64_t offset=0;
  offset+=88;
  return ( double*)(( char*) obj+offset);
}
 static inline double ParticlesMonitorData_get_shift_s(const ParticlesMonitorData restrict  obj){
  int64_t offset=0;
  offset+=96;
  return *( double*)(( char*) obj+offset);
}
 static inline void ParticlesMonitorData_set_shift_s(ParticlesMonitorData restrict  obj, double value){
  int64_t offset=0;
  offset+=96;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* ParticlesMonitorData_getp_shift_s(ParticlesMonitorData restrict  obj){
  int64_t offset=0;
  offset+=96;
  return ( double*)(( char*) obj+offset);
}
 static inline double ParticlesMonitorData_get_rot_s_rad(const ParticlesMonitorData restrict  obj){
  int64_t offset=0;
  offset+=104;
  return *( double*)(( char*) obj+offset);
}
 static inline void ParticlesMonitorData_set_rot_s_rad(ParticlesMonitorData restrict  obj, double value){
  int64_t offset=0;
  offset+=104;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* ParticlesMonitorData_getp_rot_s_rad(ParticlesMonitorData restrict  obj){
  int64_t offset=0;
  offset+=104;
  return ( double*)(( char*) obj+offset);
}
 static inline double ParticlesMonitorData_get_rot_x_rad(const ParticlesMonitorData restrict  obj){
  int64_t offset=0;
  offset+=112;
  return *( double*)(( char*) obj+offset);
}
 static inline void ParticlesMonitorData_set_rot_x_rad(ParticlesMonitorData restrict  obj, double value){
  int64_t offset=0;
  offset+=112;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* ParticlesMonitorData_getp_rot_x_rad(ParticlesMonitorData restrict  obj){
  int64_t offset=0;
  offset+=112;
  return ( double*)(( char*) obj+offset);
}
 static inline double ParticlesMonitorData_get_rot_y_rad(const ParticlesMonitorData restrict  obj){
  int64_t offset=0;
  offset+=120;
  return *( double*)(( char*) obj+offset);
}
 static inline void ParticlesMonitorData_set_rot_y_rad(ParticlesMonitorData restrict  obj, double value){
  int64_t offset=0;
  offset+=120;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* ParticlesMonitorData_getp_rot_y_rad(ParticlesMonitorData restrict  obj){
  int64_t offset=0;
  offset+=120;
  return ( double*)(( char*) obj+offset);
}
 static inline double ParticlesMonitorData_get_rot_s_rad_no_frame(const ParticlesMonitorData restrict  obj){
  int64_t offset=0;
  offset+=128;
  return *( double*)(( char*) obj+offset);
}
 static inline void ParticlesMonitorData_set_rot_s_rad_no_frame(ParticlesMonitorData restrict  obj, double value){
  int64_t offset=0;
  offset+=128;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* ParticlesMonitorData_getp_rot_s_rad_no_frame(ParticlesMonitorData restrict  obj){
  int64_t offset=0;
  offset+=128;
  return ( double*)(( char*) obj+offset);
}
 static inline double ParticlesMonitorData_get_rot_shift_anchor(const ParticlesMonitorData restrict  obj){
  int64_t offset=0;
  offset+=136;
  return *( double*)(( char*) obj+offset);
}
 static inline void ParticlesMonitorData_set_rot_shift_anchor(ParticlesMonitorData restrict  obj, double value){
  int64_t offset=0;
  offset+=136;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* ParticlesMonitorData_getp_rot_shift_anchor(ParticlesMonitorData restrict  obj){
  int64_t offset=0;
  offset+=136;
  return ( double*)(( char*) obj+offset);
}
#endif
// copyright ############################### //
// This file is part of the Xtrack Package.  //
// Copyright (c) CERN, 2021.                 //
// ######################################### //

#ifndef XTRACK_CONSTANTS_H
#define XTRACK_CONSTANTS_H

#if !defined( C_LIGHT )
    #define   C_LIGHT ( 299792458.0 )
#endif /* !defined( C_LIGHT ) */

#if !defined( EPSILON_0 )
    #define   EPSILON_0 (8.854187817620e-12)
#endif /* !defined( EPSILON_0 ) */

#if !defined( PI )
    #define PI (3.1415926535897932384626433832795028841971693993751)
#endif /* !defined( PI ) */

#if !defined( MU_0 )
    #define MU_0 (PI*4.0e-7)
#endif /* !defined( MU_0 ) */

#if !defined( DEG2RAD )
    #define DEG2RAD (0.0174532925199432957692369076848861271344287188854)
#endif /* !defiend( DEG2RAD ) */

#if !defined( RAD2DEG )
    #define RAD2DEG (57.29577951308232087679815481410517033240547246656442)
#endif /* !defiend( RAD2DEG ) */

#if !defined( SQRT_PI )
    #define SQRT_PI (1.7724538509055160272981674833411451827975494561224)
#endif /* !defined( SQRT_PI ) */

#if !defined( QELEM )
    #define QELEM (1.60217662e-19)
#endif /* !defined( QELEM ) */

#if !defined( DBL_MAX )
    #define DBL_MAX (1.7976931348623158e+308)
#endif /* !defined( DBL_MAX ) */

#if !defined( DBL_MIN )
    #define DBL_MIN (2.2250738585072014e-308)
#endif /* !defined( DBL_MIN ) */

#if !defined( DBL_EPSILON )
    #define DBL_EPSILON (2.2204460492503131e-16)
#endif /* !defined( DBL_EPSILON ) */

#if !defined( RADIUS_ELECTRON )
    #define RADIUS_ELECTRON (2.8179403262e-15)
#endif /* !defined( RADIUS_ELECTRON ) */

#if !defined( MASS_ELECTRON )
    #define MASS_ELECTRON (9.1093837e-31)
#endif /* !defined( MASS_ELECTRON ) */

#if !defined( SQRT3 )
    #define SQRT3 1.732050807568877
#endif /* !defined( SQRT3 ) */

#if !defined( SQRT2 )
    #define SQRT2 (1.414213562373095048801688724209698078569671875376948073176679738)
#endif /* !defined( SQRT2 ) */

#if !defined( TWO_OVER_SQRT_PI )
    #define TWO_OVER_SQRT_PI (1.128379167095512573896158903121545171688101258657997713688171443418)
#endif /* !defined( TWO_OVER_SQRT_PI ) */

#if !defined( ALPHA_EM )
    #define ALPHA_EM 0.0072973525693
#endif /* !defined( ALPHA_EM ) */

#endif /* XTRACK_CONSTANTS_H */

// copyright ############################### //
// This file is part of the Xtrack Package.  //
// Copyright (c) CERN, 2023.                 //
// ######################################### //

#ifndef XTRACK_FUNCTIONS_H
#define XTRACK_FUNCTIONS_H

#include "xtrack/headers/track.h"


GPUFUN
void kill_all_particles(LocalParticle* part0, int64_t kill_state) {
    START_PER_PARTICLE_BLOCK(part0, part);
        LocalParticle_kill_particle(part, kill_state);
    END_PER_PARTICLE_BLOCK;
}


GPUFUN
int8_t assert_tracking(LocalParticle* part, int64_t kill_state){
    // Whenever we are not tracking, e.g. in a twiss, the particle will be at_turn < 0.
    // We test this to distinguish genuine tracking from twiss.
    if (LocalParticle_get_at_turn(part) < 0){
        LocalParticle_kill_particle(part, kill_state);
        return 0;
    }
    return 1;
}

#endif /* XTRACK_FUNCTIONS_H */

// copyright ############################### //
// This file is part of the Xtrack Package.  //
// Copyright (c) CERN, 2023.                 //
// ######################################### //

#ifndef XTRACK_PARTICLE_STATES_H
#define XTRACK_PARTICLE_STATES_H

#define  XT_LOST_ON_APERTURE       0
#define  XT_LOST_ON_LONG_CUT      -2
#define  XT_LOST_ALL_E_IN_SYNRAD -10
#define  RNG_ERR_SEEDS_NOT_SET   -20
#define  RNG_ERR_INVALID_TRACK   -21
#define  RNG_ERR_RUTH_NOT_SET    -22
#define  XT_INVALID_SLICE_TRANSFORM -40
#define  XT_INVALID_CURVED_SLICE_TRANSFORM -41
#define  XT_INVALID_THIN_SLICE_TRANSFORM -42

#endif /* XTRACK_PARTICLE_STATES_H */

// copyright ############################### //
// This file is part of the Xtrack Package.  //
// Copyright (c) CERN, 2025.                 //
// ######################################### //
#ifndef XTRACK_TRACK_SROTATION_H
#define XTRACK_TRACK_SROTATION_H

#include "xtrack/headers/track.h"


GPUFUN
void SRotation_single_particle(LocalParticle* part, double sin_z, double cos_z)
{
    double const x  = LocalParticle_get_x(part);
    double const y  = LocalParticle_get_y(part);
    double const px = LocalParticle_get_px(part);
    double const py = LocalParticle_get_py(part);

    double const x_hat  =  cos_z * x  + sin_z * y;
    double const y_hat  = -sin_z * x  + cos_z * y;
    double const px_hat =  cos_z * px + sin_z * py;
    double const py_hat = -sin_z * px + cos_z * py;

    /* Spin tracking is disabled by the synrad compile flag */
    #ifndef XTRACK_MULTIPOLE_NO_SYNRAD
        // Rotate spin
        double const spin_x_0 = LocalParticle_get_spin_x(part);
        double const spin_y_0 = LocalParticle_get_spin_y(part);
        if ((spin_x_0 != 0) || (spin_y_0 != 0)){
            double const spin_x_1 = cos_z*spin_x_0 + sin_z*spin_y_0;
            double const spin_y_1 = -sin_z*spin_x_0 + cos_z*spin_y_0;
            LocalParticle_set_spin_x(part, spin_x_1);
            LocalParticle_set_spin_y(part, spin_y_1);
        }
    #endif

    LocalParticle_set_x(part, x_hat);
    LocalParticle_set_y(part, y_hat);
    LocalParticle_set_px(part, px_hat);
    LocalParticle_set_py(part, py_hat);
}

#endif
// copyright ############################### //
// This file is part of the Xtrack Package.  //
// Copyright (c) CERN, 2021.                 //
// ######################################### //

#ifndef XTRACK_TRACK_DRIFT_H
#define XTRACK_TRACK_DRIFT_H


GPUFUN
void Drift_single_particle_expanded(LocalParticle* part, double length){
    double const rpp    = LocalParticle_get_rpp(part);
    double const rv0v    = 1./LocalParticle_get_rvv(part);
    double const xp     = LocalParticle_get_px(part) * rpp;
    double const yp     = LocalParticle_get_py(part) * rpp;
    double const dzeta  = 1 - rv0v * ( 1. + ( xp*xp + yp*yp ) / 2. );

    LocalParticle_add_to_x(part, xp * length );
    LocalParticle_add_to_y(part, yp * length );
    LocalParticle_add_to_s(part, length);
    LocalParticle_add_to_zeta(part, length * dzeta );
}


GPUFUN
void Drift_single_particle_exact(LocalParticle* part, double length){
    double const px = LocalParticle_get_px(part);
    double const py = LocalParticle_get_py(part);
    double const rv0v    = 1./LocalParticle_get_rvv(part);
    double const one_plus_delta = 1. + LocalParticle_get_delta(part);

    double const one_over_pz = 1./sqrt(one_plus_delta*one_plus_delta
                                       - px * px - py * py);
    double const dzeta = 1 - rv0v * one_plus_delta * one_over_pz;

    LocalParticle_add_to_x(part, px * one_over_pz * length);
    LocalParticle_add_to_y(part, py * one_over_pz * length);
    LocalParticle_add_to_zeta(part, dzeta * length);
    LocalParticle_add_to_s(part, length);
}


GPUFUN
void Drift_single_particle(LocalParticle* part, double length){
    #ifndef XTRACK_USE_EXACT_DRIFTS
        Drift_single_particle_expanded(part, length);
    #else
        Drift_single_particle_exact(part, length);
    #endif
}


#endif /* XTRACK_TRACK_DRIFT_H */


#ifndef XSUITE_TRACK_FLAGS_H
#define XSUITE_TRACK_FLAGS_H
#define XS_FLAG_BACKTRACK (0)
#define XS_FLAG_KILL_CAVITY_KICK (2)
#define XS_FLAG_IGNORE_GLOBAL_APERTURE (3)
#define XS_FLAG_IGNORE_LOCAL_APERTURE (4)
#define XS_FLAG_SR_TAPER (5)
#define XS_FLAG_SR_KICK_SAME_AS_FIRST (6)

#endif // XSUITE_TRACK_FLAGS_H

// copyright ############################### //
// This file is part of the Xtrack Package.  //
// Copyright (c) CERN, 2021.                 //
// ######################################### //

#ifndef XTRACK_MONITORS_H
#define XTRACK_MONITORS_H

#include "xtrack/headers/track.h"


GPUFUN
void ParticlesMonitor_track_local_particle(ParticlesMonitorData el,
                       LocalParticle* part0){

    int64_t const start_at_turn = ParticlesMonitorData_get_start_at_turn(el);
    int64_t const stop_at_turn = ParticlesMonitorData_get_stop_at_turn(el);
    int64_t const part_id_start = ParticlesMonitorData_get_part_id_start(el);
    int64_t const part_id_end= ParticlesMonitorData_get_part_id_end(el);
    int64_t const ebe_mode = ParticlesMonitorData_get_ebe_mode(el);
    int64_t const n_repetitions = ParticlesMonitorData_get_n_repetitions(el);
    int64_t const repetition_period = ParticlesMonitorData_get_repetition_period(el);
    ParticlesData data = ParticlesMonitorData_getp_data(el);

    int64_t n_turns_record = stop_at_turn - start_at_turn;

    START_PER_PARTICLE_BLOCK(part0, part);
        int64_t at_turn;
        if (ebe_mode){
            at_turn = LocalParticle_get_at_element(part);
        }
        else{
            if (LocalParticle_check_track_flag(part, XS_FLAG_BACKTRACK)) {
                return; // do not log (only ebe monitor supported for now in backtrack)
            }
            at_turn = LocalParticle_get_at_turn(part);
        }
        if (n_repetitions == 1){
            if (at_turn>=start_at_turn && at_turn<stop_at_turn){
                int64_t const particle_id = LocalParticle_get_particle_id(part);
                if (particle_id<part_id_end && particle_id>=part_id_start){
                    int64_t const store_at =
                        n_turns_record * (particle_id - part_id_start)
                        + at_turn - start_at_turn;
                    LocalParticle_to_Particles(part, data, store_at, 0);
                }
            }
        }
        else if (n_repetitions > 1){
            if (at_turn < start_at_turn){
                #ifdef XO_CONTEXT_CPU
                    break;
                #else
                    return;
                #endif
            }
            int64_t const i_frame = (at_turn - start_at_turn) / repetition_period;
            if (i_frame < n_repetitions
                     && at_turn >= start_at_turn + i_frame*repetition_period
                     && at_turn < stop_at_turn + i_frame*repetition_period
                 ){
                int64_t const particle_id = LocalParticle_get_particle_id(part);
                if (particle_id<part_id_end && particle_id>=part_id_start){
                    int64_t const store_at =
                        n_turns_record * (part_id_end  - part_id_start) * i_frame
                        + n_turns_record * (particle_id - part_id_start)
                        + (at_turn - i_frame * repetition_period) - start_at_turn;
                    LocalParticle_to_Particles(part, data, store_at, 0);
                }
            }
        }

        #ifdef XSUITE_RESTORE_LOSS
        LocalParticle_set_state(part, 1);
        #endif
    END_PER_PARTICLE_BLOCK;
}

#endif



#define ELEMENT_NAME ParticlesMonitor
#define ALLOW_ROT_AND_SHIFT 1
#include "xtrack/headers/track_local_particle_with_transformations.h"
#undef ELEMENT_NAME
#undef ALLOW_ROT_AND_SHIFT

             
            void ParticlesMonitor_track_particles(
               ParticlesMonitorData el,

                             ParticlesData particles,

                             int64_t flag_increment_at_element,
                  int8_t* io_buffer){

//            #define CONTEXT_OPENMP  //only_for_context cpu_openmp
            #ifdef CONTEXT_OPENMP
                const int64_t capacity = ParticlesData_get__capacity(particles);
                const int num_threads = omp_get_max_threads();

                #ifndef XT_OMP_SKIP_REORGANIZE
                    const int64_t num_particles_to_track = ParticlesData_get__num_active_particles(particles);

                    {
                        LocalParticle lpart;
                        lpart.io_buffer = io_buffer;
                        Particles_to_LocalParticle(particles, &lpart, 0, capacity);
                        check_is_active(&lpart);
                        count_reorganized_particles(&lpart);
                        LocalParticle_to_Particles(&lpart, particles, 0, capacity);
                    }
                #else // When we skip reorganize, we cannot just batch active particles
                    const int64_t num_particles_to_track = capacity;
                #endif

                const int64_t chunk_size = (num_particles_to_track + num_threads - 1)/num_threads; // ceil division
            #endif // CONTEXT_OPENMP

//            #pragma omp parallel for                                                           //only_for_context cpu_openmp
//            for (int64_t batch_id = 0; batch_id < num_threads; batch_id++) {                   //only_for_context cpu_openmp
                LocalParticle lpart;
                lpart.io_buffer = io_buffer;
                lpart.track_flags = 0;
//                int64_t part_id = batch_id * chunk_size;                                       //only_for_context cpu_openmp
//                int64_t end_id = (batch_id + 1) * chunk_size;                                  //only_for_context cpu_openmp
//                if (end_id > num_particles_to_track) end_id = num_particles_to_track;          //only_for_context cpu_openmp

                int64_t part_id = 0;                    //only_for_context cpu_serial
//                int64_t part_id = blockDim.x * blockIdx.x + threadIdx.x; //only_for_context cuda
//                int64_t part_id = get_global_id(0);                    //only_for_context opencl
                int64_t end_id = 0; // unused outside of openmp  //only_for_context cpu_serial cuda opencl

                int64_t part_capacity = ParticlesData_get__capacity(particles);
                if (part_id<part_capacity){
                    Particles_to_LocalParticle(particles, &lpart, part_id, end_id);
                    if (check_is_active(&lpart)>0){
              ParticlesMonitor_track_local_particle_with_transformations(el, &lpart);

                    }
                    if (check_is_active(&lpart)>0 && flag_increment_at_element){
                            increment_at_element(&lpart, 1);
                    }
                }
//            } //only_for_context cpu_openmp

            // On OpenMP we want to additionally by default reorganize all
            // the particles.
//            #ifndef XT_OMP_SKIP_REORGANIZE                             //only_for_context cpu_openmp
//            LocalParticle lpart;                                       //only_for_context cpu_openmp
//            lpart.io_buffer = io_buffer;                               //only_for_context cpu_openmp
//            Particles_to_LocalParticle(particles, &lpart, 0, capacity);//only_for_context cpu_openmp
//            check_is_active(&lpart);                                   //only_for_context cpu_openmp
//            #endif                                                     //only_for_context cpu_openmp
        }

#ifndef XOBJ_TYPEDEF_TriLinearInterpolatedFieldMapData
#define XOBJ_TYPEDEF_TriLinearInterpolatedFieldMapData
typedef   struct TriLinearInterpolatedFieldMapData_s * TriLinearInterpolatedFieldMapData;
 static inline TriLinearInterpolatedFieldMapData TriLinearInterpolatedFieldMapData_getp(TriLinearInterpolatedFieldMapData restrict  obj){
  int64_t offset=0;
  return (TriLinearInterpolatedFieldMapData)(( char*) obj+offset);
}
 static inline double TriLinearInterpolatedFieldMapData_get_x_min(const TriLinearInterpolatedFieldMapData restrict  obj){
  int64_t offset=0;
  offset+=8;
  return *( double*)(( char*) obj+offset);
}
 static inline void TriLinearInterpolatedFieldMapData_set_x_min(TriLinearInterpolatedFieldMapData restrict  obj, double value){
  int64_t offset=0;
  offset+=8;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* TriLinearInterpolatedFieldMapData_getp_x_min(TriLinearInterpolatedFieldMapData restrict  obj){
  int64_t offset=0;
  offset+=8;
  return ( double*)(( char*) obj+offset);
}
 static inline double TriLinearInterpolatedFieldMapData_get_y_min(const TriLinearInterpolatedFieldMapData restrict  obj){
  int64_t offset=0;
  offset+=16;
  return *( double*)(( char*) obj+offset);
}
 static inline void TriLinearInterpolatedFieldMapData_set_y_min(TriLinearInterpolatedFieldMapData restrict  obj, double value){
  int64_t offset=0;
  offset+=16;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* TriLinearInterpolatedFieldMapData_getp_y_min(TriLinearInterpolatedFieldMapData restrict  obj){
  int64_t offset=0;
  offset+=16;
  return ( double*)(( char*) obj+offset);
}
 static inline double TriLinearInterpolatedFieldMapData_get_z_min(const TriLinearInterpolatedFieldMapData restrict  obj){
  int64_t offset=0;
  offset+=24;
  return *( double*)(( char*) obj+offset);
}
 static inline void TriLinearInterpolatedFieldMapData_set_z_min(TriLinearInterpolatedFieldMapData restrict  obj, double value){
  int64_t offset=0;
  offset+=24;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* TriLinearInterpolatedFieldMapData_getp_z_min(TriLinearInterpolatedFieldMapData restrict  obj){
  int64_t offset=0;
  offset+=24;
  return ( double*)(( char*) obj+offset);
}
 static inline int64_t TriLinearInterpolatedFieldMapData_get_nx(const TriLinearInterpolatedFieldMapData restrict  obj){
  int64_t offset=0;
  offset+=32;
  return *( int64_t*)(( char*) obj+offset);
}
 static inline void TriLinearInterpolatedFieldMapData_set_nx(TriLinearInterpolatedFieldMapData restrict  obj, int64_t value){
  int64_t offset=0;
  offset+=32;
  *( int64_t*)(( char*) obj+offset)=value;
}
 static inline  int64_t* TriLinearInterpolatedFieldMapData_getp_nx(TriLinearInterpolatedFieldMapData restrict  obj){
  int64_t offset=0;
  offset+=32;
  return ( int64_t*)(( char*) obj+offset);
}
 static inline int64_t TriLinearInterpolatedFieldMapData_get_ny(const TriLinearInterpolatedFieldMapData restrict  obj){
  int64_t offset=0;
  offset+=40;
  return *( int64_t*)(( char*) obj+offset);
}
 static inline void TriLinearInterpolatedFieldMapData_set_ny(TriLinearInterpolatedFieldMapData restrict  obj, int64_t value){
  int64_t offset=0;
  offset+=40;
  *( int64_t*)(( char*) obj+offset)=value;
}
 static inline  int64_t* TriLinearInterpolatedFieldMapData_getp_ny(TriLinearInterpolatedFieldMapData restrict  obj){
  int64_t offset=0;
  offset+=40;
  return ( int64_t*)(( char*) obj+offset);
}
 static inline int64_t TriLinearInterpolatedFieldMapData_get_nz(const TriLinearInterpolatedFieldMapData restrict  obj){
  int64_t offset=0;
  offset+=48;
  return *( int64_t*)(( char*) obj+offset);
}
 static inline void TriLinearInterpolatedFieldMapData_set_nz(TriLinearInterpolatedFieldMapData restrict  obj, int64_t value){
  int64_t offset=0;
  offset+=48;
  *( int64_t*)(( char*) obj+offset)=value;
}
 static inline  int64_t* TriLinearInterpolatedFieldMapData_getp_nz(TriLinearInterpolatedFieldMapData restrict  obj){
  int64_t offset=0;
  offset+=48;
  return ( int64_t*)(( char*) obj+offset);
}
 static inline double TriLinearInterpolatedFieldMapData_get_dx(const TriLinearInterpolatedFieldMapData restrict  obj){
  int64_t offset=0;
  offset+=56;
  return *( double*)(( char*) obj+offset);
}
 static inline void TriLinearInterpolatedFieldMapData_set_dx(TriLinearInterpolatedFieldMapData restrict  obj, double value){
  int64_t offset=0;
  offset+=56;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* TriLinearInterpolatedFieldMapData_getp_dx(TriLinearInterpolatedFieldMapData restrict  obj){
  int64_t offset=0;
  offset+=56;
  return ( double*)(( char*) obj+offset);
}
 static inline double TriLinearInterpolatedFieldMapData_get_dy(const TriLinearInterpolatedFieldMapData restrict  obj){
  int64_t offset=0;
  offset+=64;
  return *( double*)(( char*) obj+offset);
}
 static inline void TriLinearInterpolatedFieldMapData_set_dy(TriLinearInterpolatedFieldMapData restrict  obj, double value){
  int64_t offset=0;
  offset+=64;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* TriLinearInterpolatedFieldMapData_getp_dy(TriLinearInterpolatedFieldMapData restrict  obj){
  int64_t offset=0;
  offset+=64;
  return ( double*)(( char*) obj+offset);
}
 static inline double TriLinearInterpolatedFieldMapData_get_dz(const TriLinearInterpolatedFieldMapData restrict  obj){
  int64_t offset=0;
  offset+=72;
  return *( double*)(( char*) obj+offset);
}
 static inline void TriLinearInterpolatedFieldMapData_set_dz(TriLinearInterpolatedFieldMapData restrict  obj, double value){
  int64_t offset=0;
  offset+=72;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* TriLinearInterpolatedFieldMapData_getp_dz(TriLinearInterpolatedFieldMapData restrict  obj){
  int64_t offset=0;
  offset+=72;
  return ( double*)(( char*) obj+offset);
}
 static inline ArrNFloat64 TriLinearInterpolatedFieldMapData_getp_rho(TriLinearInterpolatedFieldMapData restrict  obj){
  int64_t offset=0;
  offset+=112;
  return (ArrNFloat64)(( char*) obj+offset);
}
 static inline int64_t TriLinearInterpolatedFieldMapData_len_rho(TriLinearInterpolatedFieldMapData restrict  obj){
  int64_t offset=0;
  offset+=112;
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  return arr[1];
}
 static inline void TriLinearInterpolatedFieldMapData_shape_rho(TriLinearInterpolatedFieldMapData restrict  obj,  int64_t* restrict  out_shape){
  int64_t offset=0;
  offset+=112;
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  out_shape[0] = arr[1];
}
 static inline uint32_t TriLinearInterpolatedFieldMapData_nd_rho(TriLinearInterpolatedFieldMapData restrict  obj){
  return 1;
}
 static inline double TriLinearInterpolatedFieldMapData_get_rho(const TriLinearInterpolatedFieldMapData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=112;
  offset+=16+i0*8;
  return *( double*)(( char*) obj+offset);
}
 static inline void TriLinearInterpolatedFieldMapData_set_rho(TriLinearInterpolatedFieldMapData restrict  obj, int64_t i0, double value){
  int64_t offset=0;
  offset+=112;
  offset+=16+i0*8;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* TriLinearInterpolatedFieldMapData_getp1_rho(TriLinearInterpolatedFieldMapData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=112;
  offset+=16+i0*8;
  return ( double*)(( char*) obj+offset);
}
 static inline ArrNFloat64 TriLinearInterpolatedFieldMapData_getp_phi(TriLinearInterpolatedFieldMapData restrict  obj){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+80);
  return (ArrNFloat64)(( char*) obj+offset);
}
 static inline int64_t TriLinearInterpolatedFieldMapData_len_phi(TriLinearInterpolatedFieldMapData restrict  obj){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+80);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  return arr[1];
}
 static inline void TriLinearInterpolatedFieldMapData_shape_phi(TriLinearInterpolatedFieldMapData restrict  obj,  int64_t* restrict  out_shape){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+80);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  out_shape[0] = arr[1];
}
 static inline uint32_t TriLinearInterpolatedFieldMapData_nd_phi(TriLinearInterpolatedFieldMapData restrict  obj){
  return 1;
}
 static inline double TriLinearInterpolatedFieldMapData_get_phi(const TriLinearInterpolatedFieldMapData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+80);
  offset+=16+i0*8;
  return *( double*)(( char*) obj+offset);
}
 static inline void TriLinearInterpolatedFieldMapData_set_phi(TriLinearInterpolatedFieldMapData restrict  obj, int64_t i0, double value){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+80);
  offset+=16+i0*8;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* TriLinearInterpolatedFieldMapData_getp1_phi(TriLinearInterpolatedFieldMapData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+80);
  offset+=16+i0*8;
  return ( double*)(( char*) obj+offset);
}
 static inline ArrNFloat64 TriLinearInterpolatedFieldMapData_getp_dphi_dx(TriLinearInterpolatedFieldMapData restrict  obj){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+88);
  return (ArrNFloat64)(( char*) obj+offset);
}
 static inline int64_t TriLinearInterpolatedFieldMapData_len_dphi_dx(TriLinearInterpolatedFieldMapData restrict  obj){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+88);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  return arr[1];
}
 static inline void TriLinearInterpolatedFieldMapData_shape_dphi_dx(TriLinearInterpolatedFieldMapData restrict  obj,  int64_t* restrict  out_shape){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+88);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  out_shape[0] = arr[1];
}
 static inline uint32_t TriLinearInterpolatedFieldMapData_nd_dphi_dx(TriLinearInterpolatedFieldMapData restrict  obj){
  return 1;
}
 static inline double TriLinearInterpolatedFieldMapData_get_dphi_dx(const TriLinearInterpolatedFieldMapData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+88);
  offset+=16+i0*8;
  return *( double*)(( char*) obj+offset);
}
 static inline void TriLinearInterpolatedFieldMapData_set_dphi_dx(TriLinearInterpolatedFieldMapData restrict  obj, int64_t i0, double value){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+88);
  offset+=16+i0*8;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* TriLinearInterpolatedFieldMapData_getp1_dphi_dx(TriLinearInterpolatedFieldMapData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+88);
  offset+=16+i0*8;
  return ( double*)(( char*) obj+offset);
}
 static inline ArrNFloat64 TriLinearInterpolatedFieldMapData_getp_dphi_dy(TriLinearInterpolatedFieldMapData restrict  obj){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+96);
  return (ArrNFloat64)(( char*) obj+offset);
}
 static inline int64_t TriLinearInterpolatedFieldMapData_len_dphi_dy(TriLinearInterpolatedFieldMapData restrict  obj){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+96);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  return arr[1];
}
 static inline void TriLinearInterpolatedFieldMapData_shape_dphi_dy(TriLinearInterpolatedFieldMapData restrict  obj,  int64_t* restrict  out_shape){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+96);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  out_shape[0] = arr[1];
}
 static inline uint32_t TriLinearInterpolatedFieldMapData_nd_dphi_dy(TriLinearInterpolatedFieldMapData restrict  obj){
  return 1;
}
 static inline double TriLinearInterpolatedFieldMapData_get_dphi_dy(const TriLinearInterpolatedFieldMapData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+96);
  offset+=16+i0*8;
  return *( double*)(( char*) obj+offset);
}
 static inline void TriLinearInterpolatedFieldMapData_set_dphi_dy(TriLinearInterpolatedFieldMapData restrict  obj, int64_t i0, double value){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+96);
  offset+=16+i0*8;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* TriLinearInterpolatedFieldMapData_getp1_dphi_dy(TriLinearInterpolatedFieldMapData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+96);
  offset+=16+i0*8;
  return ( double*)(( char*) obj+offset);
}
 static inline ArrNFloat64 TriLinearInterpolatedFieldMapData_getp_dphi_dz(TriLinearInterpolatedFieldMapData restrict  obj){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+104);
  return (ArrNFloat64)(( char*) obj+offset);
}
 static inline int64_t TriLinearInterpolatedFieldMapData_len_dphi_dz(TriLinearInterpolatedFieldMapData restrict  obj){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+104);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  return arr[1];
}
 static inline void TriLinearInterpolatedFieldMapData_shape_dphi_dz(TriLinearInterpolatedFieldMapData restrict  obj,  int64_t* restrict  out_shape){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+104);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  out_shape[0] = arr[1];
}
 static inline uint32_t TriLinearInterpolatedFieldMapData_nd_dphi_dz(TriLinearInterpolatedFieldMapData restrict  obj){
  return 1;
}
 static inline double TriLinearInterpolatedFieldMapData_get_dphi_dz(const TriLinearInterpolatedFieldMapData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+104);
  offset+=16+i0*8;
  return *( double*)(( char*) obj+offset);
}
 static inline void TriLinearInterpolatedFieldMapData_set_dphi_dz(TriLinearInterpolatedFieldMapData restrict  obj, int64_t i0, double value){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+104);
  offset+=16+i0*8;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* TriLinearInterpolatedFieldMapData_getp1_dphi_dz(TriLinearInterpolatedFieldMapData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+104);
  offset+=16+i0*8;
  return ( double*)(( char*) obj+offset);
}
#endif
#include "xfields/fieldmaps/interpolated_src/central_diff.h"
#include "xfields/fieldmaps/interpolated_src/linear_interpolators.h"
#include "xfields/fieldmaps/interpolated_src/charge_deposition.h"
#ifndef XOBJ_TYPEDEF_CompressedProfileData
#define XOBJ_TYPEDEF_CompressedProfileData
typedef   struct CompressedProfileData_s * CompressedProfileData;
 static inline CompressedProfileData CompressedProfileData_getp(CompressedProfileData restrict  obj){
  int64_t offset=0;
  return (CompressedProfileData)(( char*) obj+offset);
}
 static inline int64_t CompressedProfileData_get__N_aux(const CompressedProfileData restrict  obj){
  int64_t offset=0;
  offset+=8;
  return *( int64_t*)(( char*) obj+offset);
}
 static inline void CompressedProfileData_set__N_aux(CompressedProfileData restrict  obj, int64_t value){
  int64_t offset=0;
  offset+=8;
  *( int64_t*)(( char*) obj+offset)=value;
}
 static inline  int64_t* CompressedProfileData_getp__N_aux(CompressedProfileData restrict  obj){
  int64_t offset=0;
  offset+=8;
  return ( int64_t*)(( char*) obj+offset);
}
 static inline int64_t CompressedProfileData_get__N_T(const CompressedProfileData restrict  obj){
  int64_t offset=0;
  offset+=16;
  return *( int64_t*)(( char*) obj+offset);
}
 static inline void CompressedProfileData_set__N_T(CompressedProfileData restrict  obj, int64_t value){
  int64_t offset=0;
  offset+=16;
  *( int64_t*)(( char*) obj+offset)=value;
}
 static inline  int64_t* CompressedProfileData_getp__N_T(CompressedProfileData restrict  obj){
  int64_t offset=0;
  offset+=16;
  return ( int64_t*)(( char*) obj+offset);
}
 static inline int64_t CompressedProfileData_get__first_target_slot(const CompressedProfileData restrict  obj){
  int64_t offset=0;
  offset+=24;
  return *( int64_t*)(( char*) obj+offset);
}
 static inline void CompressedProfileData_set__first_target_slot(CompressedProfileData restrict  obj, int64_t value){
  int64_t offset=0;
  offset+=24;
  *( int64_t*)(( char*) obj+offset)=value;
}
 static inline  int64_t* CompressedProfileData_getp__first_target_slot(CompressedProfileData restrict  obj){
  int64_t offset=0;
  offset+=24;
  return ( int64_t*)(( char*) obj+offset);
}
 static inline int64_t CompressedProfileData_get_num_turns(const CompressedProfileData restrict  obj){
  int64_t offset=0;
  offset+=32;
  return *( int64_t*)(( char*) obj+offset);
}
 static inline void CompressedProfileData_set_num_turns(CompressedProfileData restrict  obj, int64_t value){
  int64_t offset=0;
  offset+=32;
  *( int64_t*)(( char*) obj+offset)=value;
}
 static inline  int64_t* CompressedProfileData_getp_num_turns(CompressedProfileData restrict  obj){
  int64_t offset=0;
  offset+=32;
  return ( int64_t*)(( char*) obj+offset);
}
 static inline ArrNxMxOFloat64 CompressedProfileData_getp_data(CompressedProfileData restrict  obj){
  int64_t offset=0;
  offset+=104;
  return (ArrNxMxOFloat64)(( char*) obj+offset);
}
 static inline int64_t CompressedProfileData_len_data(CompressedProfileData restrict  obj){
  int64_t offset=0;
  offset+=104;
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  return arr[1]*arr[2]*arr[3];
}
 static inline void CompressedProfileData_shape_data(CompressedProfileData restrict  obj,  int64_t* restrict  out_shape){
  int64_t offset=0;
  offset+=104;
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  out_shape[0] = arr[1];
  out_shape[1] = arr[2];
  out_shape[2] = arr[3];
}
 static inline uint32_t CompressedProfileData_nd_data(CompressedProfileData restrict  obj){
  return 3;
}
 static inline double CompressedProfileData_get_data(const CompressedProfileData restrict  obj, int64_t i0, int64_t i1, int64_t i2){
  int64_t offset=0;
  offset+=104;
  int64_t ArrNxMxOFloat64_s0=*( int64_t*)(( char*) obj+offset+32);
  int64_t ArrNxMxOFloat64_s1=*( int64_t*)(( char*) obj+offset+40);
  int64_t ArrNxMxOFloat64_s2=*( int64_t*)(( char*) obj+offset+48);
  offset+=56+i0*ArrNxMxOFloat64_s0+i1*ArrNxMxOFloat64_s1+i2*ArrNxMxOFloat64_s2;
  return *( double*)(( char*) obj+offset);
}
 static inline void CompressedProfileData_set_data(CompressedProfileData restrict  obj, int64_t i0, int64_t i1, int64_t i2, double value){
  int64_t offset=0;
  offset+=104;
  int64_t ArrNxMxOFloat64_s0=*( int64_t*)(( char*) obj+offset+32);
  int64_t ArrNxMxOFloat64_s1=*( int64_t*)(( char*) obj+offset+40);
  int64_t ArrNxMxOFloat64_s2=*( int64_t*)(( char*) obj+offset+48);
  offset+=56+i0*ArrNxMxOFloat64_s0+i1*ArrNxMxOFloat64_s1+i2*ArrNxMxOFloat64_s2;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* CompressedProfileData_getp3_data(CompressedProfileData restrict  obj, int64_t i0, int64_t i1, int64_t i2){
  int64_t offset=0;
  offset+=104;
  int64_t ArrNxMxOFloat64_s0=*( int64_t*)(( char*) obj+offset+32);
  int64_t ArrNxMxOFloat64_s1=*( int64_t*)(( char*) obj+offset+40);
  int64_t ArrNxMxOFloat64_s2=*( int64_t*)(( char*) obj+offset+48);
  offset+=56+i0*ArrNxMxOFloat64_s0+i1*ArrNxMxOFloat64_s1+i2*ArrNxMxOFloat64_s2;
  return ( double*)(( char*) obj+offset);
}
 static inline double CompressedProfileData_get_shift_x(const CompressedProfileData restrict  obj){
  int64_t offset=0;
  offset+=40;
  return *( double*)(( char*) obj+offset);
}
 static inline void CompressedProfileData_set_shift_x(CompressedProfileData restrict  obj, double value){
  int64_t offset=0;
  offset+=40;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* CompressedProfileData_getp_shift_x(CompressedProfileData restrict  obj){
  int64_t offset=0;
  offset+=40;
  return ( double*)(( char*) obj+offset);
}
 static inline double CompressedProfileData_get_shift_y(const CompressedProfileData restrict  obj){
  int64_t offset=0;
  offset+=48;
  return *( double*)(( char*) obj+offset);
}
 static inline void CompressedProfileData_set_shift_y(CompressedProfileData restrict  obj, double value){
  int64_t offset=0;
  offset+=48;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* CompressedProfileData_getp_shift_y(CompressedProfileData restrict  obj){
  int64_t offset=0;
  offset+=48;
  return ( double*)(( char*) obj+offset);
}
 static inline double CompressedProfileData_get_shift_s(const CompressedProfileData restrict  obj){
  int64_t offset=0;
  offset+=56;
  return *( double*)(( char*) obj+offset);
}
 static inline void CompressedProfileData_set_shift_s(CompressedProfileData restrict  obj, double value){
  int64_t offset=0;
  offset+=56;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* CompressedProfileData_getp_shift_s(CompressedProfileData restrict  obj){
  int64_t offset=0;
  offset+=56;
  return ( double*)(( char*) obj+offset);
}
 static inline double CompressedProfileData_get_rot_s_rad(const CompressedProfileData restrict  obj){
  int64_t offset=0;
  offset+=64;
  return *( double*)(( char*) obj+offset);
}
 static inline void CompressedProfileData_set_rot_s_rad(CompressedProfileData restrict  obj, double value){
  int64_t offset=0;
  offset+=64;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* CompressedProfileData_getp_rot_s_rad(CompressedProfileData restrict  obj){
  int64_t offset=0;
  offset+=64;
  return ( double*)(( char*) obj+offset);
}
 static inline double CompressedProfileData_get_rot_x_rad(const CompressedProfileData restrict  obj){
  int64_t offset=0;
  offset+=72;
  return *( double*)(( char*) obj+offset);
}
 static inline void CompressedProfileData_set_rot_x_rad(CompressedProfileData restrict  obj, double value){
  int64_t offset=0;
  offset+=72;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* CompressedProfileData_getp_rot_x_rad(CompressedProfileData restrict  obj){
  int64_t offset=0;
  offset+=72;
  return ( double*)(( char*) obj+offset);
}
 static inline double CompressedProfileData_get_rot_y_rad(const CompressedProfileData restrict  obj){
  int64_t offset=0;
  offset+=80;
  return *( double*)(( char*) obj+offset);
}
 static inline void CompressedProfileData_set_rot_y_rad(CompressedProfileData restrict  obj, double value){
  int64_t offset=0;
  offset+=80;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* CompressedProfileData_getp_rot_y_rad(CompressedProfileData restrict  obj){
  int64_t offset=0;
  offset+=80;
  return ( double*)(( char*) obj+offset);
}
 static inline double CompressedProfileData_get_rot_s_rad_no_frame(const CompressedProfileData restrict  obj){
  int64_t offset=0;
  offset+=88;
  return *( double*)(( char*) obj+offset);
}
 static inline void CompressedProfileData_set_rot_s_rad_no_frame(CompressedProfileData restrict  obj, double value){
  int64_t offset=0;
  offset+=88;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* CompressedProfileData_getp_rot_s_rad_no_frame(CompressedProfileData restrict  obj){
  int64_t offset=0;
  offset+=88;
  return ( double*)(( char*) obj+offset);
}
 static inline double CompressedProfileData_get_rot_shift_anchor(const CompressedProfileData restrict  obj){
  int64_t offset=0;
  offset+=96;
  return *( double*)(( char*) obj+offset);
}
 static inline void CompressedProfileData_set_rot_shift_anchor(CompressedProfileData restrict  obj, double value){
  int64_t offset=0;
  offset+=96;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* CompressedProfileData_getp_rot_shift_anchor(CompressedProfileData restrict  obj){
  int64_t offset=0;
  offset+=96;
  return ( double*)(( char*) obj+offset);
}
#endif
// copyright ############################### //
// This file is part of the Xtrack Package.  //
// Copyright (c) CERN, 2021.                 //
// ######################################### //

#ifndef XTRACK_CONSTANTS_H
#define XTRACK_CONSTANTS_H

#if !defined( C_LIGHT )
    #define   C_LIGHT ( 299792458.0 )
#endif /* !defined( C_LIGHT ) */

#if !defined( EPSILON_0 )
    #define   EPSILON_0 (8.854187817620e-12)
#endif /* !defined( EPSILON_0 ) */

#if !defined( PI )
    #define PI (3.1415926535897932384626433832795028841971693993751)
#endif /* !defined( PI ) */

#if !defined( MU_0 )
    #define MU_0 (PI*4.0e-7)
#endif /* !defined( MU_0 ) */

#if !defined( DEG2RAD )
    #define DEG2RAD (0.0174532925199432957692369076848861271344287188854)
#endif /* !defiend( DEG2RAD ) */

#if !defined( RAD2DEG )
    #define RAD2DEG (57.29577951308232087679815481410517033240547246656442)
#endif /* !defiend( RAD2DEG ) */

#if !defined( SQRT_PI )
    #define SQRT_PI (1.7724538509055160272981674833411451827975494561224)
#endif /* !defined( SQRT_PI ) */

#if !defined( QELEM )
    #define QELEM (1.60217662e-19)
#endif /* !defined( QELEM ) */

#if !defined( DBL_MAX )
    #define DBL_MAX (1.7976931348623158e+308)
#endif /* !defined( DBL_MAX ) */

#if !defined( DBL_MIN )
    #define DBL_MIN (2.2250738585072014e-308)
#endif /* !defined( DBL_MIN ) */

#if !defined( DBL_EPSILON )
    #define DBL_EPSILON (2.2204460492503131e-16)
#endif /* !defined( DBL_EPSILON ) */

#if !defined( RADIUS_ELECTRON )
    #define RADIUS_ELECTRON (2.8179403262e-15)
#endif /* !defined( RADIUS_ELECTRON ) */

#if !defined( MASS_ELECTRON )
    #define MASS_ELECTRON (9.1093837e-31)
#endif /* !defined( MASS_ELECTRON ) */

#if !defined( SQRT3 )
    #define SQRT3 1.732050807568877
#endif /* !defined( SQRT3 ) */

#if !defined( SQRT2 )
    #define SQRT2 (1.414213562373095048801688724209698078569671875376948073176679738)
#endif /* !defined( SQRT2 ) */

#if !defined( TWO_OVER_SQRT_PI )
    #define TWO_OVER_SQRT_PI (1.128379167095512573896158903121545171688101258657997713688171443418)
#endif /* !defined( TWO_OVER_SQRT_PI ) */

#if !defined( ALPHA_EM )
    #define ALPHA_EM 0.0072973525693
#endif /* !defined( ALPHA_EM ) */

#endif /* XTRACK_CONSTANTS_H */

// copyright ############################### //
// This file is part of the Xtrack Package.  //
// Copyright (c) CERN, 2023.                 //
// ######################################### //

#ifndef XTRACK_FUNCTIONS_H
#define XTRACK_FUNCTIONS_H

#include "xtrack/headers/track.h"


GPUFUN
void kill_all_particles(LocalParticle* part0, int64_t kill_state) {
    START_PER_PARTICLE_BLOCK(part0, part);
        LocalParticle_kill_particle(part, kill_state);
    END_PER_PARTICLE_BLOCK;
}


GPUFUN
int8_t assert_tracking(LocalParticle* part, int64_t kill_state){
    // Whenever we are not tracking, e.g. in a twiss, the particle will be at_turn < 0.
    // We test this to distinguish genuine tracking from twiss.
    if (LocalParticle_get_at_turn(part) < 0){
        LocalParticle_kill_particle(part, kill_state);
        return 0;
    }
    return 1;
}

#endif /* XTRACK_FUNCTIONS_H */

// copyright ############################### //
// This file is part of the Xtrack Package.  //
// Copyright (c) CERN, 2023.                 //
// ######################################### //

#ifndef XTRACK_PARTICLE_STATES_H
#define XTRACK_PARTICLE_STATES_H

#define  XT_LOST_ON_APERTURE       0
#define  XT_LOST_ON_LONG_CUT      -2
#define  XT_LOST_ALL_E_IN_SYNRAD -10
#define  RNG_ERR_SEEDS_NOT_SET   -20
#define  RNG_ERR_INVALID_TRACK   -21
#define  RNG_ERR_RUTH_NOT_SET    -22
#define  XT_INVALID_SLICE_TRANSFORM -40
#define  XT_INVALID_CURVED_SLICE_TRANSFORM -41
#define  XT_INVALID_THIN_SLICE_TRANSFORM -42

#endif /* XTRACK_PARTICLE_STATES_H */

// copyright ############################### //
// This file is part of the Xtrack Package.  //
// Copyright (c) CERN, 2025.                 //
// ######################################### //
#ifndef XTRACK_TRACK_SROTATION_H
#define XTRACK_TRACK_SROTATION_H

#include "xtrack/headers/track.h"


GPUFUN
void SRotation_single_particle(LocalParticle* part, double sin_z, double cos_z)
{
    double const x  = LocalParticle_get_x(part);
    double const y  = LocalParticle_get_y(part);
    double const px = LocalParticle_get_px(part);
    double const py = LocalParticle_get_py(part);

    double const x_hat  =  cos_z * x  + sin_z * y;
    double const y_hat  = -sin_z * x  + cos_z * y;
    double const px_hat =  cos_z * px + sin_z * py;
    double const py_hat = -sin_z * px + cos_z * py;

    /* Spin tracking is disabled by the synrad compile flag */
    #ifndef XTRACK_MULTIPOLE_NO_SYNRAD
        // Rotate spin
        double const spin_x_0 = LocalParticle_get_spin_x(part);
        double const spin_y_0 = LocalParticle_get_spin_y(part);
        if ((spin_x_0 != 0) || (spin_y_0 != 0)){
            double const spin_x_1 = cos_z*spin_x_0 + sin_z*spin_y_0;
            double const spin_y_1 = -sin_z*spin_x_0 + cos_z*spin_y_0;
            LocalParticle_set_spin_x(part, spin_x_1);
            LocalParticle_set_spin_y(part, spin_y_1);
        }
    #endif

    LocalParticle_set_x(part, x_hat);
    LocalParticle_set_y(part, y_hat);
    LocalParticle_set_px(part, px_hat);
    LocalParticle_set_py(part, py_hat);
}

#endif
// copyright ############################### //
// This file is part of the Xtrack Package.  //
// Copyright (c) CERN, 2021.                 //
// ######################################### //

#ifndef XTRACK_TRACK_DRIFT_H
#define XTRACK_TRACK_DRIFT_H


GPUFUN
void Drift_single_particle_expanded(LocalParticle* part, double length){
    double const rpp    = LocalParticle_get_rpp(part);
    double const rv0v    = 1./LocalParticle_get_rvv(part);
    double const xp     = LocalParticle_get_px(part) * rpp;
    double const yp     = LocalParticle_get_py(part) * rpp;
    double const dzeta  = 1 - rv0v * ( 1. + ( xp*xp + yp*yp ) / 2. );

    LocalParticle_add_to_x(part, xp * length );
    LocalParticle_add_to_y(part, yp * length );
    LocalParticle_add_to_s(part, length);
    LocalParticle_add_to_zeta(part, length * dzeta );
}


GPUFUN
void Drift_single_particle_exact(LocalParticle* part, double length){
    double const px = LocalParticle_get_px(part);
    double const py = LocalParticle_get_py(part);
    double const rv0v    = 1./LocalParticle_get_rvv(part);
    double const one_plus_delta = 1. + LocalParticle_get_delta(part);

    double const one_over_pz = 1./sqrt(one_plus_delta*one_plus_delta
                                       - px * px - py * py);
    double const dzeta = 1 - rv0v * one_plus_delta * one_over_pz;

    LocalParticle_add_to_x(part, px * one_over_pz * length);
    LocalParticle_add_to_y(part, py * one_over_pz * length);
    LocalParticle_add_to_zeta(part, dzeta * length);
    LocalParticle_add_to_s(part, length);
}


GPUFUN
void Drift_single_particle(LocalParticle* part, double length){
    #ifndef XTRACK_USE_EXACT_DRIFTS
        Drift_single_particle_expanded(part, length);
    #else
        Drift_single_particle_exact(part, length);
    #endif
}


#endif /* XTRACK_TRACK_DRIFT_H */


#ifndef XSUITE_TRACK_FLAGS_H
#define XSUITE_TRACK_FLAGS_H
#define XS_FLAG_BACKTRACK (0)
#define XS_FLAG_KILL_CAVITY_KICK (2)
#define XS_FLAG_IGNORE_GLOBAL_APERTURE (3)
#define XS_FLAG_IGNORE_LOCAL_APERTURE (4)
#define XS_FLAG_SR_TAPER (5)
#define XS_FLAG_SR_KICK_SAME_AS_FIRST (6)

#endif // XSUITE_TRACK_FLAGS_H

#include "xfields/slicers/slicers_src/compressed_profile.h"
#define ELEMENT_NAME CompressedProfile
#define ALLOW_ROT_AND_SHIFT 1
#include "xtrack/headers/track_local_particle_with_transformations.h"
#undef ELEMENT_NAME
#undef ALLOW_ROT_AND_SHIFT

             
            void CompressedProfile_track_particles(
               CompressedProfileData el,

                             ParticlesData particles,

                             int64_t flag_increment_at_element,
                  int8_t* io_buffer){

//            #define CONTEXT_OPENMP  //only_for_context cpu_openmp
            #ifdef CONTEXT_OPENMP
                const int64_t capacity = ParticlesData_get__capacity(particles);
                const int num_threads = omp_get_max_threads();

                #ifndef XT_OMP_SKIP_REORGANIZE
                    const int64_t num_particles_to_track = ParticlesData_get__num_active_particles(particles);

                    {
                        LocalParticle lpart;
                        lpart.io_buffer = io_buffer;
                        Particles_to_LocalParticle(particles, &lpart, 0, capacity);
                        check_is_active(&lpart);
                        count_reorganized_particles(&lpart);
                        LocalParticle_to_Particles(&lpart, particles, 0, capacity);
                    }
                #else // When we skip reorganize, we cannot just batch active particles
                    const int64_t num_particles_to_track = capacity;
                #endif

                const int64_t chunk_size = (num_particles_to_track + num_threads - 1)/num_threads; // ceil division
            #endif // CONTEXT_OPENMP

//            #pragma omp parallel for                                                           //only_for_context cpu_openmp
//            for (int64_t batch_id = 0; batch_id < num_threads; batch_id++) {                   //only_for_context cpu_openmp
                LocalParticle lpart;
                lpart.io_buffer = io_buffer;
                lpart.track_flags = 0;
//                int64_t part_id = batch_id * chunk_size;                                       //only_for_context cpu_openmp
//                int64_t end_id = (batch_id + 1) * chunk_size;                                  //only_for_context cpu_openmp
//                if (end_id > num_particles_to_track) end_id = num_particles_to_track;          //only_for_context cpu_openmp

                int64_t part_id = 0;                    //only_for_context cpu_serial
//                int64_t part_id = blockDim.x * blockIdx.x + threadIdx.x; //only_for_context cuda
//                int64_t part_id = get_global_id(0);                    //only_for_context opencl
                int64_t end_id = 0; // unused outside of openmp  //only_for_context cpu_serial cuda opencl

                int64_t part_capacity = ParticlesData_get__capacity(particles);
                if (part_id<part_capacity){
                    Particles_to_LocalParticle(particles, &lpart, part_id, end_id);
                    if (check_is_active(&lpart)>0){
              CompressedProfile_track_local_particle_with_transformations(el, &lpart);

                    }
                    if (check_is_active(&lpart)>0 && flag_increment_at_element){
                            increment_at_element(&lpart, 1);
                    }
                }
//            } //only_for_context cpu_openmp

            // On OpenMP we want to additionally by default reorganize all
            // the particles.
//            #ifndef XT_OMP_SKIP_REORGANIZE                             //only_for_context cpu_openmp
//            LocalParticle lpart;                                       //only_for_context cpu_openmp
//            lpart.io_buffer = io_buffer;                               //only_for_context cpu_openmp
//            Particles_to_LocalParticle(particles, &lpart, 0, capacity);//only_for_context cpu_openmp
//            check_is_active(&lpart);                                   //only_for_context cpu_openmp
//            #endif                                                     //only_for_context cpu_openmp
        }


             
            void _interp_result(
               CompressedProfileData el,

                             ParticlesData particles,
 int64_t data_shape_0,  int64_t data_shape_1,  int64_t data_shape_2,     double* data,     int64_t* i_slot_particles,     int64_t* i_slice_particles,     double* out, 
                             int64_t flag_increment_at_element,
                  int8_t* io_buffer){

//            #define CONTEXT_OPENMP  //only_for_context cpu_openmp
            #ifdef CONTEXT_OPENMP
                const int64_t capacity = ParticlesData_get__capacity(particles);
                const int num_threads = omp_get_max_threads();

                #ifndef XT_OMP_SKIP_REORGANIZE
                    const int64_t num_particles_to_track = ParticlesData_get__num_active_particles(particles);

                    {
                        LocalParticle lpart;
                        lpart.io_buffer = io_buffer;
                        Particles_to_LocalParticle(particles, &lpart, 0, capacity);
                        check_is_active(&lpart);
                        count_reorganized_particles(&lpart);
                        LocalParticle_to_Particles(&lpart, particles, 0, capacity);
                    }
                #else // When we skip reorganize, we cannot just batch active particles
                    const int64_t num_particles_to_track = capacity;
                #endif

                const int64_t chunk_size = (num_particles_to_track + num_threads - 1)/num_threads; // ceil division
            #endif // CONTEXT_OPENMP

//            #pragma omp parallel for                                                           //only_for_context cpu_openmp
//            for (int64_t batch_id = 0; batch_id < num_threads; batch_id++) {                   //only_for_context cpu_openmp
                LocalParticle lpart;
                lpart.io_buffer = io_buffer;
                lpart.track_flags = 0;
//                int64_t part_id = batch_id * chunk_size;                                       //only_for_context cpu_openmp
//                int64_t end_id = (batch_id + 1) * chunk_size;                                  //only_for_context cpu_openmp
//                if (end_id > num_particles_to_track) end_id = num_particles_to_track;          //only_for_context cpu_openmp

                int64_t part_id = 0;                    //only_for_context cpu_serial
//                int64_t part_id = blockDim.x * blockIdx.x + threadIdx.x; //only_for_context cuda
//                int64_t part_id = get_global_id(0);                    //only_for_context opencl
                int64_t end_id = 0; // unused outside of openmp  //only_for_context cpu_serial cuda opencl

                int64_t part_capacity = ParticlesData_get__capacity(particles);
                if (part_id<part_capacity){
                    Particles_to_LocalParticle(particles, &lpart, part_id, end_id);
                    if (check_is_active(&lpart)>0){
              CompressedProfile_interp_result(el, &lpart, data_shape_0, data_shape_1, data_shape_2, data, i_slot_particles, i_slice_particles, out);

                    }
                    if (check_is_active(&lpart)>0 && flag_increment_at_element){
                            increment_at_element(&lpart, 1);
                    }
                }
//            } //only_for_context cpu_openmp

            // On OpenMP we want to additionally by default reorganize all
            // the particles.
//            #ifndef XT_OMP_SKIP_REORGANIZE                             //only_for_context cpu_openmp
//            LocalParticle lpart;                                       //only_for_context cpu_openmp
//            lpart.io_buffer = io_buffer;                               //only_for_context cpu_openmp
//            Particles_to_LocalParticle(particles, &lpart, 0, capacity);//only_for_context cpu_openmp
//            check_is_active(&lpart);                                   //only_for_context cpu_openmp
//            #endif                                                     //only_for_context cpu_openmp
        }

#ifndef XOBJ_TYPEDEF_UniformBinSlicerData
#define XOBJ_TYPEDEF_UniformBinSlicerData
typedef   struct UniformBinSlicerData_s * UniformBinSlicerData;
 static inline UniformBinSlicerData UniformBinSlicerData_getp(UniformBinSlicerData restrict  obj){
  int64_t offset=0;
  return (UniformBinSlicerData)(( char*) obj+offset);
}
 static inline ArrNFloat64 UniformBinSlicerData_getp_zeta_slice_centers(UniformBinSlicerData restrict  obj){
  int64_t offset=0;
  offset+=352;
  return (ArrNFloat64)(( char*) obj+offset);
}
 static inline int64_t UniformBinSlicerData_len_zeta_slice_centers(UniformBinSlicerData restrict  obj){
  int64_t offset=0;
  offset+=352;
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  return arr[1];
}
 static inline void UniformBinSlicerData_shape_zeta_slice_centers(UniformBinSlicerData restrict  obj,  int64_t* restrict  out_shape){
  int64_t offset=0;
  offset+=352;
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  out_shape[0] = arr[1];
}
 static inline uint32_t UniformBinSlicerData_nd_zeta_slice_centers(UniformBinSlicerData restrict  obj){
  return 1;
}
 static inline double UniformBinSlicerData_get_zeta_slice_centers(const UniformBinSlicerData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=352;
  offset+=16+i0*8;
  return *( double*)(( char*) obj+offset);
}
 static inline void UniformBinSlicerData_set_zeta_slice_centers(UniformBinSlicerData restrict  obj, int64_t i0, double value){
  int64_t offset=0;
  offset+=352;
  offset+=16+i0*8;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* UniformBinSlicerData_getp1_zeta_slice_centers(UniformBinSlicerData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=352;
  offset+=16+i0*8;
  return ( double*)(( char*) obj+offset);
}
 static inline double UniformBinSlicerData_get_z_min_edge(const UniformBinSlicerData restrict  obj){
  int64_t offset=0;
  offset+=8;
  return *( double*)(( char*) obj+offset);
}
 static inline void UniformBinSlicerData_set_z_min_edge(UniformBinSlicerData restrict  obj, double value){
  int64_t offset=0;
  offset+=8;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* UniformBinSlicerData_getp_z_min_edge(UniformBinSlicerData restrict  obj){
  int64_t offset=0;
  offset+=8;
  return ( double*)(( char*) obj+offset);
}
 static inline int64_t UniformBinSlicerData_get_num_slices(const UniformBinSlicerData restrict  obj){
  int64_t offset=0;
  offset+=16;
  return *( int64_t*)(( char*) obj+offset);
}
 static inline void UniformBinSlicerData_set_num_slices(UniformBinSlicerData restrict  obj, int64_t value){
  int64_t offset=0;
  offset+=16;
  *( int64_t*)(( char*) obj+offset)=value;
}
 static inline  int64_t* UniformBinSlicerData_getp_num_slices(UniformBinSlicerData restrict  obj){
  int64_t offset=0;
  offset+=16;
  return ( int64_t*)(( char*) obj+offset);
}
 static inline double UniformBinSlicerData_get_dzeta(const UniformBinSlicerData restrict  obj){
  int64_t offset=0;
  offset+=24;
  return *( double*)(( char*) obj+offset);
}
 static inline void UniformBinSlicerData_set_dzeta(UniformBinSlicerData restrict  obj, double value){
  int64_t offset=0;
  offset+=24;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* UniformBinSlicerData_getp_dzeta(UniformBinSlicerData restrict  obj){
  int64_t offset=0;
  offset+=24;
  return ( double*)(( char*) obj+offset);
}
 static inline int64_t UniformBinSlicerData_get_num_bunches(const UniformBinSlicerData restrict  obj){
  int64_t offset=0;
  offset+=32;
  return *( int64_t*)(( char*) obj+offset);
}
 static inline void UniformBinSlicerData_set_num_bunches(UniformBinSlicerData restrict  obj, int64_t value){
  int64_t offset=0;
  offset+=32;
  *( int64_t*)(( char*) obj+offset)=value;
}
 static inline  int64_t* UniformBinSlicerData_getp_num_bunches(UniformBinSlicerData restrict  obj){
  int64_t offset=0;
  offset+=32;
  return ( int64_t*)(( char*) obj+offset);
}
 static inline ArrNInt64 UniformBinSlicerData_getp_filled_slots(UniformBinSlicerData restrict  obj){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+112);
  return (ArrNInt64)(( char*) obj+offset);
}
 static inline int64_t UniformBinSlicerData_len_filled_slots(UniformBinSlicerData restrict  obj){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+112);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  return arr[1];
}
 static inline void UniformBinSlicerData_shape_filled_slots(UniformBinSlicerData restrict  obj,  int64_t* restrict  out_shape){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+112);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  out_shape[0] = arr[1];
}
 static inline uint32_t UniformBinSlicerData_nd_filled_slots(UniformBinSlicerData restrict  obj){
  return 1;
}
 static inline int64_t UniformBinSlicerData_get_filled_slots(const UniformBinSlicerData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+112);
  offset+=16+i0*8;
  return *( int64_t*)(( char*) obj+offset);
}
 static inline void UniformBinSlicerData_set_filled_slots(UniformBinSlicerData restrict  obj, int64_t i0, int64_t value){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+112);
  offset+=16+i0*8;
  *( int64_t*)(( char*) obj+offset)=value;
}
 static inline  int64_t* UniformBinSlicerData_getp1_filled_slots(UniformBinSlicerData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+112);
  offset+=16+i0*8;
  return ( int64_t*)(( char*) obj+offset);
}
 static inline ArrNInt64 UniformBinSlicerData_getp_bunch_selection(UniformBinSlicerData restrict  obj){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+120);
  return (ArrNInt64)(( char*) obj+offset);
}
 static inline int64_t UniformBinSlicerData_len_bunch_selection(UniformBinSlicerData restrict  obj){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+120);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  return arr[1];
}
 static inline void UniformBinSlicerData_shape_bunch_selection(UniformBinSlicerData restrict  obj,  int64_t* restrict  out_shape){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+120);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  out_shape[0] = arr[1];
}
 static inline uint32_t UniformBinSlicerData_nd_bunch_selection(UniformBinSlicerData restrict  obj){
  return 1;
}
 static inline int64_t UniformBinSlicerData_get_bunch_selection(const UniformBinSlicerData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+120);
  offset+=16+i0*8;
  return *( int64_t*)(( char*) obj+offset);
}
 static inline void UniformBinSlicerData_set_bunch_selection(UniformBinSlicerData restrict  obj, int64_t i0, int64_t value){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+120);
  offset+=16+i0*8;
  *( int64_t*)(( char*) obj+offset)=value;
}
 static inline  int64_t* UniformBinSlicerData_getp1_bunch_selection(UniformBinSlicerData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+120);
  offset+=16+i0*8;
  return ( int64_t*)(( char*) obj+offset);
}
 static inline double UniformBinSlicerData_get_bunch_spacing_zeta(const UniformBinSlicerData restrict  obj){
  int64_t offset=0;
  offset+=40;
  return *( double*)(( char*) obj+offset);
}
 static inline void UniformBinSlicerData_set_bunch_spacing_zeta(UniformBinSlicerData restrict  obj, double value){
  int64_t offset=0;
  offset+=40;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* UniformBinSlicerData_getp_bunch_spacing_zeta(UniformBinSlicerData restrict  obj){
  int64_t offset=0;
  offset+=40;
  return ( double*)(( char*) obj+offset);
}
 static inline ArrNFloat64 UniformBinSlicerData_getp_num_particles(UniformBinSlicerData restrict  obj){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+128);
  return (ArrNFloat64)(( char*) obj+offset);
}
 static inline int64_t UniformBinSlicerData_len_num_particles(UniformBinSlicerData restrict  obj){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+128);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  return arr[1];
}
 static inline void UniformBinSlicerData_shape_num_particles(UniformBinSlicerData restrict  obj,  int64_t* restrict  out_shape){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+128);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  out_shape[0] = arr[1];
}
 static inline uint32_t UniformBinSlicerData_nd_num_particles(UniformBinSlicerData restrict  obj){
  return 1;
}
 static inline double UniformBinSlicerData_get_num_particles(const UniformBinSlicerData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+128);
  offset+=16+i0*8;
  return *( double*)(( char*) obj+offset);
}
 static inline void UniformBinSlicerData_set_num_particles(UniformBinSlicerData restrict  obj, int64_t i0, double value){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+128);
  offset+=16+i0*8;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* UniformBinSlicerData_getp1_num_particles(UniformBinSlicerData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+128);
  offset+=16+i0*8;
  return ( double*)(( char*) obj+offset);
}
 static inline ArrNFloat64 UniformBinSlicerData_getp_sum_x(UniformBinSlicerData restrict  obj){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+136);
  return (ArrNFloat64)(( char*) obj+offset);
}
 static inline int64_t UniformBinSlicerData_len_sum_x(UniformBinSlicerData restrict  obj){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+136);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  return arr[1];
}
 static inline void UniformBinSlicerData_shape_sum_x(UniformBinSlicerData restrict  obj,  int64_t* restrict  out_shape){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+136);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  out_shape[0] = arr[1];
}
 static inline uint32_t UniformBinSlicerData_nd_sum_x(UniformBinSlicerData restrict  obj){
  return 1;
}
 static inline double UniformBinSlicerData_get_sum_x(const UniformBinSlicerData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+136);
  offset+=16+i0*8;
  return *( double*)(( char*) obj+offset);
}
 static inline void UniformBinSlicerData_set_sum_x(UniformBinSlicerData restrict  obj, int64_t i0, double value){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+136);
  offset+=16+i0*8;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* UniformBinSlicerData_getp1_sum_x(UniformBinSlicerData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+136);
  offset+=16+i0*8;
  return ( double*)(( char*) obj+offset);
}
 static inline ArrNFloat64 UniformBinSlicerData_getp_sum_px(UniformBinSlicerData restrict  obj){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+144);
  return (ArrNFloat64)(( char*) obj+offset);
}
 static inline int64_t UniformBinSlicerData_len_sum_px(UniformBinSlicerData restrict  obj){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+144);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  return arr[1];
}
 static inline void UniformBinSlicerData_shape_sum_px(UniformBinSlicerData restrict  obj,  int64_t* restrict  out_shape){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+144);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  out_shape[0] = arr[1];
}
 static inline uint32_t UniformBinSlicerData_nd_sum_px(UniformBinSlicerData restrict  obj){
  return 1;
}
 static inline double UniformBinSlicerData_get_sum_px(const UniformBinSlicerData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+144);
  offset+=16+i0*8;
  return *( double*)(( char*) obj+offset);
}
 static inline void UniformBinSlicerData_set_sum_px(UniformBinSlicerData restrict  obj, int64_t i0, double value){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+144);
  offset+=16+i0*8;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* UniformBinSlicerData_getp1_sum_px(UniformBinSlicerData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+144);
  offset+=16+i0*8;
  return ( double*)(( char*) obj+offset);
}
 static inline ArrNFloat64 UniformBinSlicerData_getp_sum_y(UniformBinSlicerData restrict  obj){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+152);
  return (ArrNFloat64)(( char*) obj+offset);
}
 static inline int64_t UniformBinSlicerData_len_sum_y(UniformBinSlicerData restrict  obj){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+152);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  return arr[1];
}
 static inline void UniformBinSlicerData_shape_sum_y(UniformBinSlicerData restrict  obj,  int64_t* restrict  out_shape){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+152);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  out_shape[0] = arr[1];
}
 static inline uint32_t UniformBinSlicerData_nd_sum_y(UniformBinSlicerData restrict  obj){
  return 1;
}
 static inline double UniformBinSlicerData_get_sum_y(const UniformBinSlicerData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+152);
  offset+=16+i0*8;
  return *( double*)(( char*) obj+offset);
}
 static inline void UniformBinSlicerData_set_sum_y(UniformBinSlicerData restrict  obj, int64_t i0, double value){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+152);
  offset+=16+i0*8;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* UniformBinSlicerData_getp1_sum_y(UniformBinSlicerData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+152);
  offset+=16+i0*8;
  return ( double*)(( char*) obj+offset);
}
 static inline ArrNFloat64 UniformBinSlicerData_getp_sum_py(UniformBinSlicerData restrict  obj){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+160);
  return (ArrNFloat64)(( char*) obj+offset);
}
 static inline int64_t UniformBinSlicerData_len_sum_py(UniformBinSlicerData restrict  obj){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+160);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  return arr[1];
}
 static inline void UniformBinSlicerData_shape_sum_py(UniformBinSlicerData restrict  obj,  int64_t* restrict  out_shape){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+160);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  out_shape[0] = arr[1];
}
 static inline uint32_t UniformBinSlicerData_nd_sum_py(UniformBinSlicerData restrict  obj){
  return 1;
}
 static inline double UniformBinSlicerData_get_sum_py(const UniformBinSlicerData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+160);
  offset+=16+i0*8;
  return *( double*)(( char*) obj+offset);
}
 static inline void UniformBinSlicerData_set_sum_py(UniformBinSlicerData restrict  obj, int64_t i0, double value){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+160);
  offset+=16+i0*8;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* UniformBinSlicerData_getp1_sum_py(UniformBinSlicerData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+160);
  offset+=16+i0*8;
  return ( double*)(( char*) obj+offset);
}
 static inline ArrNFloat64 UniformBinSlicerData_getp_sum_zeta(UniformBinSlicerData restrict  obj){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+168);
  return (ArrNFloat64)(( char*) obj+offset);
}
 static inline int64_t UniformBinSlicerData_len_sum_zeta(UniformBinSlicerData restrict  obj){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+168);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  return arr[1];
}
 static inline void UniformBinSlicerData_shape_sum_zeta(UniformBinSlicerData restrict  obj,  int64_t* restrict  out_shape){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+168);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  out_shape[0] = arr[1];
}
 static inline uint32_t UniformBinSlicerData_nd_sum_zeta(UniformBinSlicerData restrict  obj){
  return 1;
}
 static inline double UniformBinSlicerData_get_sum_zeta(const UniformBinSlicerData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+168);
  offset+=16+i0*8;
  return *( double*)(( char*) obj+offset);
}
 static inline void UniformBinSlicerData_set_sum_zeta(UniformBinSlicerData restrict  obj, int64_t i0, double value){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+168);
  offset+=16+i0*8;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* UniformBinSlicerData_getp1_sum_zeta(UniformBinSlicerData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+168);
  offset+=16+i0*8;
  return ( double*)(( char*) obj+offset);
}
 static inline ArrNFloat64 UniformBinSlicerData_getp_sum_delta(UniformBinSlicerData restrict  obj){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+176);
  return (ArrNFloat64)(( char*) obj+offset);
}
 static inline int64_t UniformBinSlicerData_len_sum_delta(UniformBinSlicerData restrict  obj){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+176);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  return arr[1];
}
 static inline void UniformBinSlicerData_shape_sum_delta(UniformBinSlicerData restrict  obj,  int64_t* restrict  out_shape){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+176);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  out_shape[0] = arr[1];
}
 static inline uint32_t UniformBinSlicerData_nd_sum_delta(UniformBinSlicerData restrict  obj){
  return 1;
}
 static inline double UniformBinSlicerData_get_sum_delta(const UniformBinSlicerData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+176);
  offset+=16+i0*8;
  return *( double*)(( char*) obj+offset);
}
 static inline void UniformBinSlicerData_set_sum_delta(UniformBinSlicerData restrict  obj, int64_t i0, double value){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+176);
  offset+=16+i0*8;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* UniformBinSlicerData_getp1_sum_delta(UniformBinSlicerData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+176);
  offset+=16+i0*8;
  return ( double*)(( char*) obj+offset);
}
 static inline ArrNFloat64 UniformBinSlicerData_getp_sum_x_x(UniformBinSlicerData restrict  obj){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+184);
  return (ArrNFloat64)(( char*) obj+offset);
}
 static inline int64_t UniformBinSlicerData_len_sum_x_x(UniformBinSlicerData restrict  obj){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+184);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  return arr[1];
}
 static inline void UniformBinSlicerData_shape_sum_x_x(UniformBinSlicerData restrict  obj,  int64_t* restrict  out_shape){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+184);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  out_shape[0] = arr[1];
}
 static inline uint32_t UniformBinSlicerData_nd_sum_x_x(UniformBinSlicerData restrict  obj){
  return 1;
}
 static inline double UniformBinSlicerData_get_sum_x_x(const UniformBinSlicerData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+184);
  offset+=16+i0*8;
  return *( double*)(( char*) obj+offset);
}
 static inline void UniformBinSlicerData_set_sum_x_x(UniformBinSlicerData restrict  obj, int64_t i0, double value){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+184);
  offset+=16+i0*8;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* UniformBinSlicerData_getp1_sum_x_x(UniformBinSlicerData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+184);
  offset+=16+i0*8;
  return ( double*)(( char*) obj+offset);
}
 static inline ArrNFloat64 UniformBinSlicerData_getp_sum_x_px(UniformBinSlicerData restrict  obj){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+192);
  return (ArrNFloat64)(( char*) obj+offset);
}
 static inline int64_t UniformBinSlicerData_len_sum_x_px(UniformBinSlicerData restrict  obj){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+192);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  return arr[1];
}
 static inline void UniformBinSlicerData_shape_sum_x_px(UniformBinSlicerData restrict  obj,  int64_t* restrict  out_shape){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+192);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  out_shape[0] = arr[1];
}
 static inline uint32_t UniformBinSlicerData_nd_sum_x_px(UniformBinSlicerData restrict  obj){
  return 1;
}
 static inline double UniformBinSlicerData_get_sum_x_px(const UniformBinSlicerData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+192);
  offset+=16+i0*8;
  return *( double*)(( char*) obj+offset);
}
 static inline void UniformBinSlicerData_set_sum_x_px(UniformBinSlicerData restrict  obj, int64_t i0, double value){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+192);
  offset+=16+i0*8;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* UniformBinSlicerData_getp1_sum_x_px(UniformBinSlicerData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+192);
  offset+=16+i0*8;
  return ( double*)(( char*) obj+offset);
}
 static inline ArrNFloat64 UniformBinSlicerData_getp_sum_x_y(UniformBinSlicerData restrict  obj){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+200);
  return (ArrNFloat64)(( char*) obj+offset);
}
 static inline int64_t UniformBinSlicerData_len_sum_x_y(UniformBinSlicerData restrict  obj){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+200);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  return arr[1];
}
 static inline void UniformBinSlicerData_shape_sum_x_y(UniformBinSlicerData restrict  obj,  int64_t* restrict  out_shape){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+200);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  out_shape[0] = arr[1];
}
 static inline uint32_t UniformBinSlicerData_nd_sum_x_y(UniformBinSlicerData restrict  obj){
  return 1;
}
 static inline double UniformBinSlicerData_get_sum_x_y(const UniformBinSlicerData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+200);
  offset+=16+i0*8;
  return *( double*)(( char*) obj+offset);
}
 static inline void UniformBinSlicerData_set_sum_x_y(UniformBinSlicerData restrict  obj, int64_t i0, double value){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+200);
  offset+=16+i0*8;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* UniformBinSlicerData_getp1_sum_x_y(UniformBinSlicerData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+200);
  offset+=16+i0*8;
  return ( double*)(( char*) obj+offset);
}
 static inline ArrNFloat64 UniformBinSlicerData_getp_sum_x_py(UniformBinSlicerData restrict  obj){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+208);
  return (ArrNFloat64)(( char*) obj+offset);
}
 static inline int64_t UniformBinSlicerData_len_sum_x_py(UniformBinSlicerData restrict  obj){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+208);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  return arr[1];
}
 static inline void UniformBinSlicerData_shape_sum_x_py(UniformBinSlicerData restrict  obj,  int64_t* restrict  out_shape){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+208);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  out_shape[0] = arr[1];
}
 static inline uint32_t UniformBinSlicerData_nd_sum_x_py(UniformBinSlicerData restrict  obj){
  return 1;
}
 static inline double UniformBinSlicerData_get_sum_x_py(const UniformBinSlicerData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+208);
  offset+=16+i0*8;
  return *( double*)(( char*) obj+offset);
}
 static inline void UniformBinSlicerData_set_sum_x_py(UniformBinSlicerData restrict  obj, int64_t i0, double value){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+208);
  offset+=16+i0*8;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* UniformBinSlicerData_getp1_sum_x_py(UniformBinSlicerData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+208);
  offset+=16+i0*8;
  return ( double*)(( char*) obj+offset);
}
 static inline ArrNFloat64 UniformBinSlicerData_getp_sum_x_zeta(UniformBinSlicerData restrict  obj){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+216);
  return (ArrNFloat64)(( char*) obj+offset);
}
 static inline int64_t UniformBinSlicerData_len_sum_x_zeta(UniformBinSlicerData restrict  obj){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+216);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  return arr[1];
}
 static inline void UniformBinSlicerData_shape_sum_x_zeta(UniformBinSlicerData restrict  obj,  int64_t* restrict  out_shape){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+216);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  out_shape[0] = arr[1];
}
 static inline uint32_t UniformBinSlicerData_nd_sum_x_zeta(UniformBinSlicerData restrict  obj){
  return 1;
}
 static inline double UniformBinSlicerData_get_sum_x_zeta(const UniformBinSlicerData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+216);
  offset+=16+i0*8;
  return *( double*)(( char*) obj+offset);
}
 static inline void UniformBinSlicerData_set_sum_x_zeta(UniformBinSlicerData restrict  obj, int64_t i0, double value){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+216);
  offset+=16+i0*8;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* UniformBinSlicerData_getp1_sum_x_zeta(UniformBinSlicerData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+216);
  offset+=16+i0*8;
  return ( double*)(( char*) obj+offset);
}
 static inline ArrNFloat64 UniformBinSlicerData_getp_sum_x_delta(UniformBinSlicerData restrict  obj){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+224);
  return (ArrNFloat64)(( char*) obj+offset);
}
 static inline int64_t UniformBinSlicerData_len_sum_x_delta(UniformBinSlicerData restrict  obj){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+224);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  return arr[1];
}
 static inline void UniformBinSlicerData_shape_sum_x_delta(UniformBinSlicerData restrict  obj,  int64_t* restrict  out_shape){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+224);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  out_shape[0] = arr[1];
}
 static inline uint32_t UniformBinSlicerData_nd_sum_x_delta(UniformBinSlicerData restrict  obj){
  return 1;
}
 static inline double UniformBinSlicerData_get_sum_x_delta(const UniformBinSlicerData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+224);
  offset+=16+i0*8;
  return *( double*)(( char*) obj+offset);
}
 static inline void UniformBinSlicerData_set_sum_x_delta(UniformBinSlicerData restrict  obj, int64_t i0, double value){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+224);
  offset+=16+i0*8;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* UniformBinSlicerData_getp1_sum_x_delta(UniformBinSlicerData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+224);
  offset+=16+i0*8;
  return ( double*)(( char*) obj+offset);
}
 static inline ArrNFloat64 UniformBinSlicerData_getp_sum_px_px(UniformBinSlicerData restrict  obj){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+232);
  return (ArrNFloat64)(( char*) obj+offset);
}
 static inline int64_t UniformBinSlicerData_len_sum_px_px(UniformBinSlicerData restrict  obj){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+232);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  return arr[1];
}
 static inline void UniformBinSlicerData_shape_sum_px_px(UniformBinSlicerData restrict  obj,  int64_t* restrict  out_shape){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+232);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  out_shape[0] = arr[1];
}
 static inline uint32_t UniformBinSlicerData_nd_sum_px_px(UniformBinSlicerData restrict  obj){
  return 1;
}
 static inline double UniformBinSlicerData_get_sum_px_px(const UniformBinSlicerData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+232);
  offset+=16+i0*8;
  return *( double*)(( char*) obj+offset);
}
 static inline void UniformBinSlicerData_set_sum_px_px(UniformBinSlicerData restrict  obj, int64_t i0, double value){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+232);
  offset+=16+i0*8;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* UniformBinSlicerData_getp1_sum_px_px(UniformBinSlicerData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+232);
  offset+=16+i0*8;
  return ( double*)(( char*) obj+offset);
}
 static inline ArrNFloat64 UniformBinSlicerData_getp_sum_px_y(UniformBinSlicerData restrict  obj){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+240);
  return (ArrNFloat64)(( char*) obj+offset);
}
 static inline int64_t UniformBinSlicerData_len_sum_px_y(UniformBinSlicerData restrict  obj){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+240);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  return arr[1];
}
 static inline void UniformBinSlicerData_shape_sum_px_y(UniformBinSlicerData restrict  obj,  int64_t* restrict  out_shape){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+240);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  out_shape[0] = arr[1];
}
 static inline uint32_t UniformBinSlicerData_nd_sum_px_y(UniformBinSlicerData restrict  obj){
  return 1;
}
 static inline double UniformBinSlicerData_get_sum_px_y(const UniformBinSlicerData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+240);
  offset+=16+i0*8;
  return *( double*)(( char*) obj+offset);
}
 static inline void UniformBinSlicerData_set_sum_px_y(UniformBinSlicerData restrict  obj, int64_t i0, double value){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+240);
  offset+=16+i0*8;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* UniformBinSlicerData_getp1_sum_px_y(UniformBinSlicerData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+240);
  offset+=16+i0*8;
  return ( double*)(( char*) obj+offset);
}
 static inline ArrNFloat64 UniformBinSlicerData_getp_sum_px_py(UniformBinSlicerData restrict  obj){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+248);
  return (ArrNFloat64)(( char*) obj+offset);
}
 static inline int64_t UniformBinSlicerData_len_sum_px_py(UniformBinSlicerData restrict  obj){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+248);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  return arr[1];
}
 static inline void UniformBinSlicerData_shape_sum_px_py(UniformBinSlicerData restrict  obj,  int64_t* restrict  out_shape){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+248);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  out_shape[0] = arr[1];
}
 static inline uint32_t UniformBinSlicerData_nd_sum_px_py(UniformBinSlicerData restrict  obj){
  return 1;
}
 static inline double UniformBinSlicerData_get_sum_px_py(const UniformBinSlicerData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+248);
  offset+=16+i0*8;
  return *( double*)(( char*) obj+offset);
}
 static inline void UniformBinSlicerData_set_sum_px_py(UniformBinSlicerData restrict  obj, int64_t i0, double value){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+248);
  offset+=16+i0*8;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* UniformBinSlicerData_getp1_sum_px_py(UniformBinSlicerData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+248);
  offset+=16+i0*8;
  return ( double*)(( char*) obj+offset);
}
 static inline ArrNFloat64 UniformBinSlicerData_getp_sum_px_zeta(UniformBinSlicerData restrict  obj){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+256);
  return (ArrNFloat64)(( char*) obj+offset);
}
 static inline int64_t UniformBinSlicerData_len_sum_px_zeta(UniformBinSlicerData restrict  obj){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+256);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  return arr[1];
}
 static inline void UniformBinSlicerData_shape_sum_px_zeta(UniformBinSlicerData restrict  obj,  int64_t* restrict  out_shape){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+256);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  out_shape[0] = arr[1];
}
 static inline uint32_t UniformBinSlicerData_nd_sum_px_zeta(UniformBinSlicerData restrict  obj){
  return 1;
}
 static inline double UniformBinSlicerData_get_sum_px_zeta(const UniformBinSlicerData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+256);
  offset+=16+i0*8;
  return *( double*)(( char*) obj+offset);
}
 static inline void UniformBinSlicerData_set_sum_px_zeta(UniformBinSlicerData restrict  obj, int64_t i0, double value){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+256);
  offset+=16+i0*8;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* UniformBinSlicerData_getp1_sum_px_zeta(UniformBinSlicerData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+256);
  offset+=16+i0*8;
  return ( double*)(( char*) obj+offset);
}
 static inline ArrNFloat64 UniformBinSlicerData_getp_sum_px_delta(UniformBinSlicerData restrict  obj){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+264);
  return (ArrNFloat64)(( char*) obj+offset);
}
 static inline int64_t UniformBinSlicerData_len_sum_px_delta(UniformBinSlicerData restrict  obj){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+264);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  return arr[1];
}
 static inline void UniformBinSlicerData_shape_sum_px_delta(UniformBinSlicerData restrict  obj,  int64_t* restrict  out_shape){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+264);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  out_shape[0] = arr[1];
}
 static inline uint32_t UniformBinSlicerData_nd_sum_px_delta(UniformBinSlicerData restrict  obj){
  return 1;
}
 static inline double UniformBinSlicerData_get_sum_px_delta(const UniformBinSlicerData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+264);
  offset+=16+i0*8;
  return *( double*)(( char*) obj+offset);
}
 static inline void UniformBinSlicerData_set_sum_px_delta(UniformBinSlicerData restrict  obj, int64_t i0, double value){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+264);
  offset+=16+i0*8;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* UniformBinSlicerData_getp1_sum_px_delta(UniformBinSlicerData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+264);
  offset+=16+i0*8;
  return ( double*)(( char*) obj+offset);
}
 static inline ArrNFloat64 UniformBinSlicerData_getp_sum_y_y(UniformBinSlicerData restrict  obj){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+272);
  return (ArrNFloat64)(( char*) obj+offset);
}
 static inline int64_t UniformBinSlicerData_len_sum_y_y(UniformBinSlicerData restrict  obj){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+272);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  return arr[1];
}
 static inline void UniformBinSlicerData_shape_sum_y_y(UniformBinSlicerData restrict  obj,  int64_t* restrict  out_shape){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+272);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  out_shape[0] = arr[1];
}
 static inline uint32_t UniformBinSlicerData_nd_sum_y_y(UniformBinSlicerData restrict  obj){
  return 1;
}
 static inline double UniformBinSlicerData_get_sum_y_y(const UniformBinSlicerData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+272);
  offset+=16+i0*8;
  return *( double*)(( char*) obj+offset);
}
 static inline void UniformBinSlicerData_set_sum_y_y(UniformBinSlicerData restrict  obj, int64_t i0, double value){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+272);
  offset+=16+i0*8;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* UniformBinSlicerData_getp1_sum_y_y(UniformBinSlicerData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+272);
  offset+=16+i0*8;
  return ( double*)(( char*) obj+offset);
}
 static inline ArrNFloat64 UniformBinSlicerData_getp_sum_y_py(UniformBinSlicerData restrict  obj){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+280);
  return (ArrNFloat64)(( char*) obj+offset);
}
 static inline int64_t UniformBinSlicerData_len_sum_y_py(UniformBinSlicerData restrict  obj){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+280);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  return arr[1];
}
 static inline void UniformBinSlicerData_shape_sum_y_py(UniformBinSlicerData restrict  obj,  int64_t* restrict  out_shape){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+280);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  out_shape[0] = arr[1];
}
 static inline uint32_t UniformBinSlicerData_nd_sum_y_py(UniformBinSlicerData restrict  obj){
  return 1;
}
 static inline double UniformBinSlicerData_get_sum_y_py(const UniformBinSlicerData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+280);
  offset+=16+i0*8;
  return *( double*)(( char*) obj+offset);
}
 static inline void UniformBinSlicerData_set_sum_y_py(UniformBinSlicerData restrict  obj, int64_t i0, double value){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+280);
  offset+=16+i0*8;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* UniformBinSlicerData_getp1_sum_y_py(UniformBinSlicerData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+280);
  offset+=16+i0*8;
  return ( double*)(( char*) obj+offset);
}
 static inline ArrNFloat64 UniformBinSlicerData_getp_sum_y_zeta(UniformBinSlicerData restrict  obj){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+288);
  return (ArrNFloat64)(( char*) obj+offset);
}
 static inline int64_t UniformBinSlicerData_len_sum_y_zeta(UniformBinSlicerData restrict  obj){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+288);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  return arr[1];
}
 static inline void UniformBinSlicerData_shape_sum_y_zeta(UniformBinSlicerData restrict  obj,  int64_t* restrict  out_shape){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+288);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  out_shape[0] = arr[1];
}
 static inline uint32_t UniformBinSlicerData_nd_sum_y_zeta(UniformBinSlicerData restrict  obj){
  return 1;
}
 static inline double UniformBinSlicerData_get_sum_y_zeta(const UniformBinSlicerData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+288);
  offset+=16+i0*8;
  return *( double*)(( char*) obj+offset);
}
 static inline void UniformBinSlicerData_set_sum_y_zeta(UniformBinSlicerData restrict  obj, int64_t i0, double value){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+288);
  offset+=16+i0*8;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* UniformBinSlicerData_getp1_sum_y_zeta(UniformBinSlicerData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+288);
  offset+=16+i0*8;
  return ( double*)(( char*) obj+offset);
}
 static inline ArrNFloat64 UniformBinSlicerData_getp_sum_y_delta(UniformBinSlicerData restrict  obj){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+296);
  return (ArrNFloat64)(( char*) obj+offset);
}
 static inline int64_t UniformBinSlicerData_len_sum_y_delta(UniformBinSlicerData restrict  obj){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+296);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  return arr[1];
}
 static inline void UniformBinSlicerData_shape_sum_y_delta(UniformBinSlicerData restrict  obj,  int64_t* restrict  out_shape){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+296);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  out_shape[0] = arr[1];
}
 static inline uint32_t UniformBinSlicerData_nd_sum_y_delta(UniformBinSlicerData restrict  obj){
  return 1;
}
 static inline double UniformBinSlicerData_get_sum_y_delta(const UniformBinSlicerData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+296);
  offset+=16+i0*8;
  return *( double*)(( char*) obj+offset);
}
 static inline void UniformBinSlicerData_set_sum_y_delta(UniformBinSlicerData restrict  obj, int64_t i0, double value){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+296);
  offset+=16+i0*8;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* UniformBinSlicerData_getp1_sum_y_delta(UniformBinSlicerData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+296);
  offset+=16+i0*8;
  return ( double*)(( char*) obj+offset);
}
 static inline ArrNFloat64 UniformBinSlicerData_getp_sum_py_py(UniformBinSlicerData restrict  obj){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+304);
  return (ArrNFloat64)(( char*) obj+offset);
}
 static inline int64_t UniformBinSlicerData_len_sum_py_py(UniformBinSlicerData restrict  obj){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+304);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  return arr[1];
}
 static inline void UniformBinSlicerData_shape_sum_py_py(UniformBinSlicerData restrict  obj,  int64_t* restrict  out_shape){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+304);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  out_shape[0] = arr[1];
}
 static inline uint32_t UniformBinSlicerData_nd_sum_py_py(UniformBinSlicerData restrict  obj){
  return 1;
}
 static inline double UniformBinSlicerData_get_sum_py_py(const UniformBinSlicerData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+304);
  offset+=16+i0*8;
  return *( double*)(( char*) obj+offset);
}
 static inline void UniformBinSlicerData_set_sum_py_py(UniformBinSlicerData restrict  obj, int64_t i0, double value){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+304);
  offset+=16+i0*8;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* UniformBinSlicerData_getp1_sum_py_py(UniformBinSlicerData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+304);
  offset+=16+i0*8;
  return ( double*)(( char*) obj+offset);
}
 static inline ArrNFloat64 UniformBinSlicerData_getp_sum_py_zeta(UniformBinSlicerData restrict  obj){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+312);
  return (ArrNFloat64)(( char*) obj+offset);
}
 static inline int64_t UniformBinSlicerData_len_sum_py_zeta(UniformBinSlicerData restrict  obj){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+312);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  return arr[1];
}
 static inline void UniformBinSlicerData_shape_sum_py_zeta(UniformBinSlicerData restrict  obj,  int64_t* restrict  out_shape){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+312);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  out_shape[0] = arr[1];
}
 static inline uint32_t UniformBinSlicerData_nd_sum_py_zeta(UniformBinSlicerData restrict  obj){
  return 1;
}
 static inline double UniformBinSlicerData_get_sum_py_zeta(const UniformBinSlicerData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+312);
  offset+=16+i0*8;
  return *( double*)(( char*) obj+offset);
}
 static inline void UniformBinSlicerData_set_sum_py_zeta(UniformBinSlicerData restrict  obj, int64_t i0, double value){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+312);
  offset+=16+i0*8;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* UniformBinSlicerData_getp1_sum_py_zeta(UniformBinSlicerData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+312);
  offset+=16+i0*8;
  return ( double*)(( char*) obj+offset);
}
 static inline ArrNFloat64 UniformBinSlicerData_getp_sum_py_delta(UniformBinSlicerData restrict  obj){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+320);
  return (ArrNFloat64)(( char*) obj+offset);
}
 static inline int64_t UniformBinSlicerData_len_sum_py_delta(UniformBinSlicerData restrict  obj){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+320);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  return arr[1];
}
 static inline void UniformBinSlicerData_shape_sum_py_delta(UniformBinSlicerData restrict  obj,  int64_t* restrict  out_shape){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+320);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  out_shape[0] = arr[1];
}
 static inline uint32_t UniformBinSlicerData_nd_sum_py_delta(UniformBinSlicerData restrict  obj){
  return 1;
}
 static inline double UniformBinSlicerData_get_sum_py_delta(const UniformBinSlicerData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+320);
  offset+=16+i0*8;
  return *( double*)(( char*) obj+offset);
}
 static inline void UniformBinSlicerData_set_sum_py_delta(UniformBinSlicerData restrict  obj, int64_t i0, double value){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+320);
  offset+=16+i0*8;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* UniformBinSlicerData_getp1_sum_py_delta(UniformBinSlicerData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+320);
  offset+=16+i0*8;
  return ( double*)(( char*) obj+offset);
}
 static inline ArrNFloat64 UniformBinSlicerData_getp_sum_zeta_zeta(UniformBinSlicerData restrict  obj){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+328);
  return (ArrNFloat64)(( char*) obj+offset);
}
 static inline int64_t UniformBinSlicerData_len_sum_zeta_zeta(UniformBinSlicerData restrict  obj){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+328);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  return arr[1];
}
 static inline void UniformBinSlicerData_shape_sum_zeta_zeta(UniformBinSlicerData restrict  obj,  int64_t* restrict  out_shape){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+328);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  out_shape[0] = arr[1];
}
 static inline uint32_t UniformBinSlicerData_nd_sum_zeta_zeta(UniformBinSlicerData restrict  obj){
  return 1;
}
 static inline double UniformBinSlicerData_get_sum_zeta_zeta(const UniformBinSlicerData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+328);
  offset+=16+i0*8;
  return *( double*)(( char*) obj+offset);
}
 static inline void UniformBinSlicerData_set_sum_zeta_zeta(UniformBinSlicerData restrict  obj, int64_t i0, double value){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+328);
  offset+=16+i0*8;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* UniformBinSlicerData_getp1_sum_zeta_zeta(UniformBinSlicerData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+328);
  offset+=16+i0*8;
  return ( double*)(( char*) obj+offset);
}
 static inline ArrNFloat64 UniformBinSlicerData_getp_sum_zeta_delta(UniformBinSlicerData restrict  obj){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+336);
  return (ArrNFloat64)(( char*) obj+offset);
}
 static inline int64_t UniformBinSlicerData_len_sum_zeta_delta(UniformBinSlicerData restrict  obj){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+336);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  return arr[1];
}
 static inline void UniformBinSlicerData_shape_sum_zeta_delta(UniformBinSlicerData restrict  obj,  int64_t* restrict  out_shape){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+336);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  out_shape[0] = arr[1];
}
 static inline uint32_t UniformBinSlicerData_nd_sum_zeta_delta(UniformBinSlicerData restrict  obj){
  return 1;
}
 static inline double UniformBinSlicerData_get_sum_zeta_delta(const UniformBinSlicerData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+336);
  offset+=16+i0*8;
  return *( double*)(( char*) obj+offset);
}
 static inline void UniformBinSlicerData_set_sum_zeta_delta(UniformBinSlicerData restrict  obj, int64_t i0, double value){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+336);
  offset+=16+i0*8;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* UniformBinSlicerData_getp1_sum_zeta_delta(UniformBinSlicerData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+336);
  offset+=16+i0*8;
  return ( double*)(( char*) obj+offset);
}
 static inline ArrNFloat64 UniformBinSlicerData_getp_sum_delta_delta(UniformBinSlicerData restrict  obj){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+344);
  return (ArrNFloat64)(( char*) obj+offset);
}
 static inline int64_t UniformBinSlicerData_len_sum_delta_delta(UniformBinSlicerData restrict  obj){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+344);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  return arr[1];
}
 static inline void UniformBinSlicerData_shape_sum_delta_delta(UniformBinSlicerData restrict  obj,  int64_t* restrict  out_shape){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+344);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  out_shape[0] = arr[1];
}
 static inline uint32_t UniformBinSlicerData_nd_sum_delta_delta(UniformBinSlicerData restrict  obj){
  return 1;
}
 static inline double UniformBinSlicerData_get_sum_delta_delta(const UniformBinSlicerData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+344);
  offset+=16+i0*8;
  return *( double*)(( char*) obj+offset);
}
 static inline void UniformBinSlicerData_set_sum_delta_delta(UniformBinSlicerData restrict  obj, int64_t i0, double value){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+344);
  offset+=16+i0*8;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* UniformBinSlicerData_getp1_sum_delta_delta(UniformBinSlicerData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+344);
  offset+=16+i0*8;
  return ( double*)(( char*) obj+offset);
}
 static inline double UniformBinSlicerData_get_shift_x(const UniformBinSlicerData restrict  obj){
  int64_t offset=0;
  offset+=48;
  return *( double*)(( char*) obj+offset);
}
 static inline void UniformBinSlicerData_set_shift_x(UniformBinSlicerData restrict  obj, double value){
  int64_t offset=0;
  offset+=48;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* UniformBinSlicerData_getp_shift_x(UniformBinSlicerData restrict  obj){
  int64_t offset=0;
  offset+=48;
  return ( double*)(( char*) obj+offset);
}
 static inline double UniformBinSlicerData_get_shift_y(const UniformBinSlicerData restrict  obj){
  int64_t offset=0;
  offset+=56;
  return *( double*)(( char*) obj+offset);
}
 static inline void UniformBinSlicerData_set_shift_y(UniformBinSlicerData restrict  obj, double value){
  int64_t offset=0;
  offset+=56;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* UniformBinSlicerData_getp_shift_y(UniformBinSlicerData restrict  obj){
  int64_t offset=0;
  offset+=56;
  return ( double*)(( char*) obj+offset);
}
 static inline double UniformBinSlicerData_get_shift_s(const UniformBinSlicerData restrict  obj){
  int64_t offset=0;
  offset+=64;
  return *( double*)(( char*) obj+offset);
}
 static inline void UniformBinSlicerData_set_shift_s(UniformBinSlicerData restrict  obj, double value){
  int64_t offset=0;
  offset+=64;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* UniformBinSlicerData_getp_shift_s(UniformBinSlicerData restrict  obj){
  int64_t offset=0;
  offset+=64;
  return ( double*)(( char*) obj+offset);
}
 static inline double UniformBinSlicerData_get_rot_s_rad(const UniformBinSlicerData restrict  obj){
  int64_t offset=0;
  offset+=72;
  return *( double*)(( char*) obj+offset);
}
 static inline void UniformBinSlicerData_set_rot_s_rad(UniformBinSlicerData restrict  obj, double value){
  int64_t offset=0;
  offset+=72;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* UniformBinSlicerData_getp_rot_s_rad(UniformBinSlicerData restrict  obj){
  int64_t offset=0;
  offset+=72;
  return ( double*)(( char*) obj+offset);
}
 static inline double UniformBinSlicerData_get_rot_x_rad(const UniformBinSlicerData restrict  obj){
  int64_t offset=0;
  offset+=80;
  return *( double*)(( char*) obj+offset);
}
 static inline void UniformBinSlicerData_set_rot_x_rad(UniformBinSlicerData restrict  obj, double value){
  int64_t offset=0;
  offset+=80;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* UniformBinSlicerData_getp_rot_x_rad(UniformBinSlicerData restrict  obj){
  int64_t offset=0;
  offset+=80;
  return ( double*)(( char*) obj+offset);
}
 static inline double UniformBinSlicerData_get_rot_y_rad(const UniformBinSlicerData restrict  obj){
  int64_t offset=0;
  offset+=88;
  return *( double*)(( char*) obj+offset);
}
 static inline void UniformBinSlicerData_set_rot_y_rad(UniformBinSlicerData restrict  obj, double value){
  int64_t offset=0;
  offset+=88;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* UniformBinSlicerData_getp_rot_y_rad(UniformBinSlicerData restrict  obj){
  int64_t offset=0;
  offset+=88;
  return ( double*)(( char*) obj+offset);
}
 static inline double UniformBinSlicerData_get_rot_s_rad_no_frame(const UniformBinSlicerData restrict  obj){
  int64_t offset=0;
  offset+=96;
  return *( double*)(( char*) obj+offset);
}
 static inline void UniformBinSlicerData_set_rot_s_rad_no_frame(UniformBinSlicerData restrict  obj, double value){
  int64_t offset=0;
  offset+=96;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* UniformBinSlicerData_getp_rot_s_rad_no_frame(UniformBinSlicerData restrict  obj){
  int64_t offset=0;
  offset+=96;
  return ( double*)(( char*) obj+offset);
}
 static inline double UniformBinSlicerData_get_rot_shift_anchor(const UniformBinSlicerData restrict  obj){
  int64_t offset=0;
  offset+=104;
  return *( double*)(( char*) obj+offset);
}
 static inline void UniformBinSlicerData_set_rot_shift_anchor(UniformBinSlicerData restrict  obj, double value){
  int64_t offset=0;
  offset+=104;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* UniformBinSlicerData_getp_rot_shift_anchor(UniformBinSlicerData restrict  obj){
  int64_t offset=0;
  offset+=104;
  return ( double*)(( char*) obj+offset);
}
#endif
// copyright ############################### //
// This file is part of the Xtrack Package.  //
// Copyright (c) CERN, 2021.                 //
// ######################################### //

#ifndef XTRACK_CONSTANTS_H
#define XTRACK_CONSTANTS_H

#if !defined( C_LIGHT )
    #define   C_LIGHT ( 299792458.0 )
#endif /* !defined( C_LIGHT ) */

#if !defined( EPSILON_0 )
    #define   EPSILON_0 (8.854187817620e-12)
#endif /* !defined( EPSILON_0 ) */

#if !defined( PI )
    #define PI (3.1415926535897932384626433832795028841971693993751)
#endif /* !defined( PI ) */

#if !defined( MU_0 )
    #define MU_0 (PI*4.0e-7)
#endif /* !defined( MU_0 ) */

#if !defined( DEG2RAD )
    #define DEG2RAD (0.0174532925199432957692369076848861271344287188854)
#endif /* !defiend( DEG2RAD ) */

#if !defined( RAD2DEG )
    #define RAD2DEG (57.29577951308232087679815481410517033240547246656442)
#endif /* !defiend( RAD2DEG ) */

#if !defined( SQRT_PI )
    #define SQRT_PI (1.7724538509055160272981674833411451827975494561224)
#endif /* !defined( SQRT_PI ) */

#if !defined( QELEM )
    #define QELEM (1.60217662e-19)
#endif /* !defined( QELEM ) */

#if !defined( DBL_MAX )
    #define DBL_MAX (1.7976931348623158e+308)
#endif /* !defined( DBL_MAX ) */

#if !defined( DBL_MIN )
    #define DBL_MIN (2.2250738585072014e-308)
#endif /* !defined( DBL_MIN ) */

#if !defined( DBL_EPSILON )
    #define DBL_EPSILON (2.2204460492503131e-16)
#endif /* !defined( DBL_EPSILON ) */

#if !defined( RADIUS_ELECTRON )
    #define RADIUS_ELECTRON (2.8179403262e-15)
#endif /* !defined( RADIUS_ELECTRON ) */

#if !defined( MASS_ELECTRON )
    #define MASS_ELECTRON (9.1093837e-31)
#endif /* !defined( MASS_ELECTRON ) */

#if !defined( SQRT3 )
    #define SQRT3 1.732050807568877
#endif /* !defined( SQRT3 ) */

#if !defined( SQRT2 )
    #define SQRT2 (1.414213562373095048801688724209698078569671875376948073176679738)
#endif /* !defined( SQRT2 ) */

#if !defined( TWO_OVER_SQRT_PI )
    #define TWO_OVER_SQRT_PI (1.128379167095512573896158903121545171688101258657997713688171443418)
#endif /* !defined( TWO_OVER_SQRT_PI ) */

#if !defined( ALPHA_EM )
    #define ALPHA_EM 0.0072973525693
#endif /* !defined( ALPHA_EM ) */

#endif /* XTRACK_CONSTANTS_H */

// copyright ############################### //
// This file is part of the Xtrack Package.  //
// Copyright (c) CERN, 2023.                 //
// ######################################### //

#ifndef XTRACK_FUNCTIONS_H
#define XTRACK_FUNCTIONS_H

#include "xtrack/headers/track.h"


GPUFUN
void kill_all_particles(LocalParticle* part0, int64_t kill_state) {
    START_PER_PARTICLE_BLOCK(part0, part);
        LocalParticle_kill_particle(part, kill_state);
    END_PER_PARTICLE_BLOCK;
}


GPUFUN
int8_t assert_tracking(LocalParticle* part, int64_t kill_state){
    // Whenever we are not tracking, e.g. in a twiss, the particle will be at_turn < 0.
    // We test this to distinguish genuine tracking from twiss.
    if (LocalParticle_get_at_turn(part) < 0){
        LocalParticle_kill_particle(part, kill_state);
        return 0;
    }
    return 1;
}

#endif /* XTRACK_FUNCTIONS_H */

// copyright ############################### //
// This file is part of the Xtrack Package.  //
// Copyright (c) CERN, 2023.                 //
// ######################################### //

#ifndef XTRACK_PARTICLE_STATES_H
#define XTRACK_PARTICLE_STATES_H

#define  XT_LOST_ON_APERTURE       0
#define  XT_LOST_ON_LONG_CUT      -2
#define  XT_LOST_ALL_E_IN_SYNRAD -10
#define  RNG_ERR_SEEDS_NOT_SET   -20
#define  RNG_ERR_INVALID_TRACK   -21
#define  RNG_ERR_RUTH_NOT_SET    -22
#define  XT_INVALID_SLICE_TRANSFORM -40
#define  XT_INVALID_CURVED_SLICE_TRANSFORM -41
#define  XT_INVALID_THIN_SLICE_TRANSFORM -42

#endif /* XTRACK_PARTICLE_STATES_H */

// copyright ############################### //
// This file is part of the Xtrack Package.  //
// Copyright (c) CERN, 2025.                 //
// ######################################### //
#ifndef XTRACK_TRACK_SROTATION_H
#define XTRACK_TRACK_SROTATION_H

#include "xtrack/headers/track.h"


GPUFUN
void SRotation_single_particle(LocalParticle* part, double sin_z, double cos_z)
{
    double const x  = LocalParticle_get_x(part);
    double const y  = LocalParticle_get_y(part);
    double const px = LocalParticle_get_px(part);
    double const py = LocalParticle_get_py(part);

    double const x_hat  =  cos_z * x  + sin_z * y;
    double const y_hat  = -sin_z * x  + cos_z * y;
    double const px_hat =  cos_z * px + sin_z * py;
    double const py_hat = -sin_z * px + cos_z * py;

    /* Spin tracking is disabled by the synrad compile flag */
    #ifndef XTRACK_MULTIPOLE_NO_SYNRAD
        // Rotate spin
        double const spin_x_0 = LocalParticle_get_spin_x(part);
        double const spin_y_0 = LocalParticle_get_spin_y(part);
        if ((spin_x_0 != 0) || (spin_y_0 != 0)){
            double const spin_x_1 = cos_z*spin_x_0 + sin_z*spin_y_0;
            double const spin_y_1 = -sin_z*spin_x_0 + cos_z*spin_y_0;
            LocalParticle_set_spin_x(part, spin_x_1);
            LocalParticle_set_spin_y(part, spin_y_1);
        }
    #endif

    LocalParticle_set_x(part, x_hat);
    LocalParticle_set_y(part, y_hat);
    LocalParticle_set_px(part, px_hat);
    LocalParticle_set_py(part, py_hat);
}

#endif
// copyright ############################### //
// This file is part of the Xtrack Package.  //
// Copyright (c) CERN, 2021.                 //
// ######################################### //

#ifndef XTRACK_TRACK_DRIFT_H
#define XTRACK_TRACK_DRIFT_H


GPUFUN
void Drift_single_particle_expanded(LocalParticle* part, double length){
    double const rpp    = LocalParticle_get_rpp(part);
    double const rv0v    = 1./LocalParticle_get_rvv(part);
    double const xp     = LocalParticle_get_px(part) * rpp;
    double const yp     = LocalParticle_get_py(part) * rpp;
    double const dzeta  = 1 - rv0v * ( 1. + ( xp*xp + yp*yp ) / 2. );

    LocalParticle_add_to_x(part, xp * length );
    LocalParticle_add_to_y(part, yp * length );
    LocalParticle_add_to_s(part, length);
    LocalParticle_add_to_zeta(part, length * dzeta );
}


GPUFUN
void Drift_single_particle_exact(LocalParticle* part, double length){
    double const px = LocalParticle_get_px(part);
    double const py = LocalParticle_get_py(part);
    double const rv0v    = 1./LocalParticle_get_rvv(part);
    double const one_plus_delta = 1. + LocalParticle_get_delta(part);

    double const one_over_pz = 1./sqrt(one_plus_delta*one_plus_delta
                                       - px * px - py * py);
    double const dzeta = 1 - rv0v * one_plus_delta * one_over_pz;

    LocalParticle_add_to_x(part, px * one_over_pz * length);
    LocalParticle_add_to_y(part, py * one_over_pz * length);
    LocalParticle_add_to_zeta(part, dzeta * length);
    LocalParticle_add_to_s(part, length);
}


GPUFUN
void Drift_single_particle(LocalParticle* part, double length){
    #ifndef XTRACK_USE_EXACT_DRIFTS
        Drift_single_particle_expanded(part, length);
    #else
        Drift_single_particle_exact(part, length);
    #endif
}


#endif /* XTRACK_TRACK_DRIFT_H */


#ifndef XSUITE_TRACK_FLAGS_H
#define XSUITE_TRACK_FLAGS_H
#define XS_FLAG_BACKTRACK (0)
#define XS_FLAG_KILL_CAVITY_KICK (2)
#define XS_FLAG_IGNORE_GLOBAL_APERTURE (3)
#define XS_FLAG_IGNORE_LOCAL_APERTURE (4)
#define XS_FLAG_SR_TAPER (5)
#define XS_FLAG_SR_KICK_SAME_AS_FIRST (6)

#endif // XSUITE_TRACK_FLAGS_H

#include "xfields/slicers/slicers_src/uniform_bin_slicer.h"
#define ELEMENT_NAME UniformBinSlicer
#define ALLOW_ROT_AND_SHIFT 1
#include "xtrack/headers/track_local_particle_with_transformations.h"
#undef ELEMENT_NAME
#undef ALLOW_ROT_AND_SHIFT

             
            void UniformBinSlicer_track_particles(
               UniformBinSlicerData el,

                             ParticlesData particles,

                             int64_t flag_increment_at_element,
                  int8_t* io_buffer){

//            #define CONTEXT_OPENMP  //only_for_context cpu_openmp
            #ifdef CONTEXT_OPENMP
                const int64_t capacity = ParticlesData_get__capacity(particles);
                const int num_threads = omp_get_max_threads();

                #ifndef XT_OMP_SKIP_REORGANIZE
                    const int64_t num_particles_to_track = ParticlesData_get__num_active_particles(particles);

                    {
                        LocalParticle lpart;
                        lpart.io_buffer = io_buffer;
                        Particles_to_LocalParticle(particles, &lpart, 0, capacity);
                        check_is_active(&lpart);
                        count_reorganized_particles(&lpart);
                        LocalParticle_to_Particles(&lpart, particles, 0, capacity);
                    }
                #else // When we skip reorganize, we cannot just batch active particles
                    const int64_t num_particles_to_track = capacity;
                #endif

                const int64_t chunk_size = (num_particles_to_track + num_threads - 1)/num_threads; // ceil division
            #endif // CONTEXT_OPENMP

//            #pragma omp parallel for                                                           //only_for_context cpu_openmp
//            for (int64_t batch_id = 0; batch_id < num_threads; batch_id++) {                   //only_for_context cpu_openmp
                LocalParticle lpart;
                lpart.io_buffer = io_buffer;
                lpart.track_flags = 0;
//                int64_t part_id = batch_id * chunk_size;                                       //only_for_context cpu_openmp
//                int64_t end_id = (batch_id + 1) * chunk_size;                                  //only_for_context cpu_openmp
//                if (end_id > num_particles_to_track) end_id = num_particles_to_track;          //only_for_context cpu_openmp

                int64_t part_id = 0;                    //only_for_context cpu_serial
//                int64_t part_id = blockDim.x * blockIdx.x + threadIdx.x; //only_for_context cuda
//                int64_t part_id = get_global_id(0);                    //only_for_context opencl
                int64_t end_id = 0; // unused outside of openmp  //only_for_context cpu_serial cuda opencl

                int64_t part_capacity = ParticlesData_get__capacity(particles);
                if (part_id<part_capacity){
                    Particles_to_LocalParticle(particles, &lpart, part_id, end_id);
                    if (check_is_active(&lpart)>0){
              UniformBinSlicer_track_local_particle_with_transformations(el, &lpart);

                    }
                    if (check_is_active(&lpart)>0 && flag_increment_at_element){
                            increment_at_element(&lpart, 1);
                    }
                }
//            } //only_for_context cpu_openmp

            // On OpenMP we want to additionally by default reorganize all
            // the particles.
//            #ifndef XT_OMP_SKIP_REORGANIZE                             //only_for_context cpu_openmp
//            LocalParticle lpart;                                       //only_for_context cpu_openmp
//            lpart.io_buffer = io_buffer;                               //only_for_context cpu_openmp
//            Particles_to_LocalParticle(particles, &lpart, 0, capacity);//only_for_context cpu_openmp
//            check_is_active(&lpart);                                   //only_for_context cpu_openmp
//            #endif                                                     //only_for_context cpu_openmp
        }


             
            void _slice_kernel(
               UniformBinSlicerData el,

                             ParticlesData particles,
 int64_t use_bunch_index_array,  int64_t use_slice_index_array,     int64_t* i_slice_particles,     int64_t* i_slot_particles, 
                             int64_t flag_increment_at_element,
                  int8_t* io_buffer){

//            #define CONTEXT_OPENMP  //only_for_context cpu_openmp
            #ifdef CONTEXT_OPENMP
                const int64_t capacity = ParticlesData_get__capacity(particles);
                const int num_threads = omp_get_max_threads();

                #ifndef XT_OMP_SKIP_REORGANIZE
                    const int64_t num_particles_to_track = ParticlesData_get__num_active_particles(particles);

                    {
                        LocalParticle lpart;
                        lpart.io_buffer = io_buffer;
                        Particles_to_LocalParticle(particles, &lpart, 0, capacity);
                        check_is_active(&lpart);
                        count_reorganized_particles(&lpart);
                        LocalParticle_to_Particles(&lpart, particles, 0, capacity);
                    }
                #else // When we skip reorganize, we cannot just batch active particles
                    const int64_t num_particles_to_track = capacity;
                #endif

                const int64_t chunk_size = (num_particles_to_track + num_threads - 1)/num_threads; // ceil division
            #endif // CONTEXT_OPENMP

//            #pragma omp parallel for                                                           //only_for_context cpu_openmp
//            for (int64_t batch_id = 0; batch_id < num_threads; batch_id++) {                   //only_for_context cpu_openmp
                LocalParticle lpart;
                lpart.io_buffer = io_buffer;
                lpart.track_flags = 0;
//                int64_t part_id = batch_id * chunk_size;                                       //only_for_context cpu_openmp
//                int64_t end_id = (batch_id + 1) * chunk_size;                                  //only_for_context cpu_openmp
//                if (end_id > num_particles_to_track) end_id = num_particles_to_track;          //only_for_context cpu_openmp

                int64_t part_id = 0;                    //only_for_context cpu_serial
//                int64_t part_id = blockDim.x * blockIdx.x + threadIdx.x; //only_for_context cuda
//                int64_t part_id = get_global_id(0);                    //only_for_context opencl
                int64_t end_id = 0; // unused outside of openmp  //only_for_context cpu_serial cuda opencl

                int64_t part_capacity = ParticlesData_get__capacity(particles);
                if (part_id<part_capacity){
                    Particles_to_LocalParticle(particles, &lpart, part_id, end_id);
                    if (check_is_active(&lpart)>0){
              UniformBinSlicer_slice(el, &lpart, use_bunch_index_array, use_slice_index_array, i_slice_particles, i_slot_particles);

                    }
                    if (check_is_active(&lpart)>0 && flag_increment_at_element){
                            increment_at_element(&lpart, 1);
                    }
                }
//            } //only_for_context cpu_openmp

            // On OpenMP we want to additionally by default reorganize all
            // the particles.
//            #ifndef XT_OMP_SKIP_REORGANIZE                             //only_for_context cpu_openmp
//            LocalParticle lpart;                                       //only_for_context cpu_openmp
//            lpart.io_buffer = io_buffer;                               //only_for_context cpu_openmp
//            Particles_to_LocalParticle(particles, &lpart, 0, capacity);//only_for_context cpu_openmp
//            check_is_active(&lpart);                                   //only_for_context cpu_openmp
//            #endif                                                     //only_for_context cpu_openmp
        }

#ifndef XOBJ_TYPEDEF_RandomUniformData
#define XOBJ_TYPEDEF_RandomUniformData
typedef   struct RandomUniformData_s * RandomUniformData;
 static inline RandomUniformData RandomUniformData_getp(RandomUniformData restrict  obj){
  int64_t offset=0;
  return (RandomUniformData)(( char*) obj+offset);
}
 static inline uint8_t RandomUniformData_get__dummy(const RandomUniformData restrict  obj){
  int64_t offset=0;
  return *(( uint8_t*) obj+offset);
}
 static inline void RandomUniformData_set__dummy(RandomUniformData restrict  obj, uint8_t value){
  int64_t offset=0;
  *(( uint8_t*) obj+offset)=value;
}
 static inline  uint8_t* RandomUniformData_getp__dummy(RandomUniformData restrict  obj){
  int64_t offset=0;
  return ( uint8_t*)(( char*) obj+offset);
}
 static inline double RandomUniformData_get_shift_x(const RandomUniformData restrict  obj){
  int64_t offset=0;
  offset+=8;
  return *( double*)(( char*) obj+offset);
}
 static inline void RandomUniformData_set_shift_x(RandomUniformData restrict  obj, double value){
  int64_t offset=0;
  offset+=8;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* RandomUniformData_getp_shift_x(RandomUniformData restrict  obj){
  int64_t offset=0;
  offset+=8;
  return ( double*)(( char*) obj+offset);
}
 static inline double RandomUniformData_get_shift_y(const RandomUniformData restrict  obj){
  int64_t offset=0;
  offset+=16;
  return *( double*)(( char*) obj+offset);
}
 static inline void RandomUniformData_set_shift_y(RandomUniformData restrict  obj, double value){
  int64_t offset=0;
  offset+=16;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* RandomUniformData_getp_shift_y(RandomUniformData restrict  obj){
  int64_t offset=0;
  offset+=16;
  return ( double*)(( char*) obj+offset);
}
 static inline double RandomUniformData_get_shift_s(const RandomUniformData restrict  obj){
  int64_t offset=0;
  offset+=24;
  return *( double*)(( char*) obj+offset);
}
 static inline void RandomUniformData_set_shift_s(RandomUniformData restrict  obj, double value){
  int64_t offset=0;
  offset+=24;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* RandomUniformData_getp_shift_s(RandomUniformData restrict  obj){
  int64_t offset=0;
  offset+=24;
  return ( double*)(( char*) obj+offset);
}
 static inline double RandomUniformData_get_rot_s_rad(const RandomUniformData restrict  obj){
  int64_t offset=0;
  offset+=32;
  return *( double*)(( char*) obj+offset);
}
 static inline void RandomUniformData_set_rot_s_rad(RandomUniformData restrict  obj, double value){
  int64_t offset=0;
  offset+=32;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* RandomUniformData_getp_rot_s_rad(RandomUniformData restrict  obj){
  int64_t offset=0;
  offset+=32;
  return ( double*)(( char*) obj+offset);
}
 static inline double RandomUniformData_get_rot_x_rad(const RandomUniformData restrict  obj){
  int64_t offset=0;
  offset+=40;
  return *( double*)(( char*) obj+offset);
}
 static inline void RandomUniformData_set_rot_x_rad(RandomUniformData restrict  obj, double value){
  int64_t offset=0;
  offset+=40;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* RandomUniformData_getp_rot_x_rad(RandomUniformData restrict  obj){
  int64_t offset=0;
  offset+=40;
  return ( double*)(( char*) obj+offset);
}
 static inline double RandomUniformData_get_rot_y_rad(const RandomUniformData restrict  obj){
  int64_t offset=0;
  offset+=48;
  return *( double*)(( char*) obj+offset);
}
 static inline void RandomUniformData_set_rot_y_rad(RandomUniformData restrict  obj, double value){
  int64_t offset=0;
  offset+=48;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* RandomUniformData_getp_rot_y_rad(RandomUniformData restrict  obj){
  int64_t offset=0;
  offset+=48;
  return ( double*)(( char*) obj+offset);
}
 static inline double RandomUniformData_get_rot_s_rad_no_frame(const RandomUniformData restrict  obj){
  int64_t offset=0;
  offset+=56;
  return *( double*)(( char*) obj+offset);
}
 static inline void RandomUniformData_set_rot_s_rad_no_frame(RandomUniformData restrict  obj, double value){
  int64_t offset=0;
  offset+=56;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* RandomUniformData_getp_rot_s_rad_no_frame(RandomUniformData restrict  obj){
  int64_t offset=0;
  offset+=56;
  return ( double*)(( char*) obj+offset);
}
 static inline double RandomUniformData_get_rot_shift_anchor(const RandomUniformData restrict  obj){
  int64_t offset=0;
  offset+=64;
  return *( double*)(( char*) obj+offset);
}
 static inline void RandomUniformData_set_rot_shift_anchor(RandomUniformData restrict  obj, double value){
  int64_t offset=0;
  offset+=64;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* RandomUniformData_getp_rot_shift_anchor(RandomUniformData restrict  obj){
  int64_t offset=0;
  offset+=64;
  return ( double*)(( char*) obj+offset);
}
#endif
// copyright ############################### //
// This file is part of the Xtrack Package.  //
// Copyright (c) CERN, 2021.                 //
// ######################################### //

#ifndef XTRACK_CONSTANTS_H
#define XTRACK_CONSTANTS_H

#if !defined( C_LIGHT )
    #define   C_LIGHT ( 299792458.0 )
#endif /* !defined( C_LIGHT ) */

#if !defined( EPSILON_0 )
    #define   EPSILON_0 (8.854187817620e-12)
#endif /* !defined( EPSILON_0 ) */

#if !defined( PI )
    #define PI (3.1415926535897932384626433832795028841971693993751)
#endif /* !defined( PI ) */

#if !defined( MU_0 )
    #define MU_0 (PI*4.0e-7)
#endif /* !defined( MU_0 ) */

#if !defined( DEG2RAD )
    #define DEG2RAD (0.0174532925199432957692369076848861271344287188854)
#endif /* !defiend( DEG2RAD ) */

#if !defined( RAD2DEG )
    #define RAD2DEG (57.29577951308232087679815481410517033240547246656442)
#endif /* !defiend( RAD2DEG ) */

#if !defined( SQRT_PI )
    #define SQRT_PI (1.7724538509055160272981674833411451827975494561224)
#endif /* !defined( SQRT_PI ) */

#if !defined( QELEM )
    #define QELEM (1.60217662e-19)
#endif /* !defined( QELEM ) */

#if !defined( DBL_MAX )
    #define DBL_MAX (1.7976931348623158e+308)
#endif /* !defined( DBL_MAX ) */

#if !defined( DBL_MIN )
    #define DBL_MIN (2.2250738585072014e-308)
#endif /* !defined( DBL_MIN ) */

#if !defined( DBL_EPSILON )
    #define DBL_EPSILON (2.2204460492503131e-16)
#endif /* !defined( DBL_EPSILON ) */

#if !defined( RADIUS_ELECTRON )
    #define RADIUS_ELECTRON (2.8179403262e-15)
#endif /* !defined( RADIUS_ELECTRON ) */

#if !defined( MASS_ELECTRON )
    #define MASS_ELECTRON (9.1093837e-31)
#endif /* !defined( MASS_ELECTRON ) */

#if !defined( SQRT3 )
    #define SQRT3 1.732050807568877
#endif /* !defined( SQRT3 ) */

#if !defined( SQRT2 )
    #define SQRT2 (1.414213562373095048801688724209698078569671875376948073176679738)
#endif /* !defined( SQRT2 ) */

#if !defined( TWO_OVER_SQRT_PI )
    #define TWO_OVER_SQRT_PI (1.128379167095512573896158903121545171688101258657997713688171443418)
#endif /* !defined( TWO_OVER_SQRT_PI ) */

#if !defined( ALPHA_EM )
    #define ALPHA_EM 0.0072973525693
#endif /* !defined( ALPHA_EM ) */

#endif /* XTRACK_CONSTANTS_H */

// copyright ############################### //
// This file is part of the Xtrack Package.  //
// Copyright (c) CERN, 2023.                 //
// ######################################### //

#ifndef XTRACK_FUNCTIONS_H
#define XTRACK_FUNCTIONS_H

#include "xtrack/headers/track.h"


GPUFUN
void kill_all_particles(LocalParticle* part0, int64_t kill_state) {
    START_PER_PARTICLE_BLOCK(part0, part);
        LocalParticle_kill_particle(part, kill_state);
    END_PER_PARTICLE_BLOCK;
}


GPUFUN
int8_t assert_tracking(LocalParticle* part, int64_t kill_state){
    // Whenever we are not tracking, e.g. in a twiss, the particle will be at_turn < 0.
    // We test this to distinguish genuine tracking from twiss.
    if (LocalParticle_get_at_turn(part) < 0){
        LocalParticle_kill_particle(part, kill_state);
        return 0;
    }
    return 1;
}

#endif /* XTRACK_FUNCTIONS_H */

// copyright ############################### //
// This file is part of the Xtrack Package.  //
// Copyright (c) CERN, 2023.                 //
// ######################################### //

#ifndef XTRACK_PARTICLE_STATES_H
#define XTRACK_PARTICLE_STATES_H

#define  XT_LOST_ON_APERTURE       0
#define  XT_LOST_ON_LONG_CUT      -2
#define  XT_LOST_ALL_E_IN_SYNRAD -10
#define  RNG_ERR_SEEDS_NOT_SET   -20
#define  RNG_ERR_INVALID_TRACK   -21
#define  RNG_ERR_RUTH_NOT_SET    -22
#define  XT_INVALID_SLICE_TRANSFORM -40
#define  XT_INVALID_CURVED_SLICE_TRANSFORM -41
#define  XT_INVALID_THIN_SLICE_TRANSFORM -42

#endif /* XTRACK_PARTICLE_STATES_H */

// copyright ############################### //
// This file is part of the Xtrack Package.  //
// Copyright (c) CERN, 2025.                 //
// ######################################### //
#ifndef XTRACK_TRACK_SROTATION_H
#define XTRACK_TRACK_SROTATION_H

#include "xtrack/headers/track.h"


GPUFUN
void SRotation_single_particle(LocalParticle* part, double sin_z, double cos_z)
{
    double const x  = LocalParticle_get_x(part);
    double const y  = LocalParticle_get_y(part);
    double const px = LocalParticle_get_px(part);
    double const py = LocalParticle_get_py(part);

    double const x_hat  =  cos_z * x  + sin_z * y;
    double const y_hat  = -sin_z * x  + cos_z * y;
    double const px_hat =  cos_z * px + sin_z * py;
    double const py_hat = -sin_z * px + cos_z * py;

    /* Spin tracking is disabled by the synrad compile flag */
    #ifndef XTRACK_MULTIPOLE_NO_SYNRAD
        // Rotate spin
        double const spin_x_0 = LocalParticle_get_spin_x(part);
        double const spin_y_0 = LocalParticle_get_spin_y(part);
        if ((spin_x_0 != 0) || (spin_y_0 != 0)){
            double const spin_x_1 = cos_z*spin_x_0 + sin_z*spin_y_0;
            double const spin_y_1 = -sin_z*spin_x_0 + cos_z*spin_y_0;
            LocalParticle_set_spin_x(part, spin_x_1);
            LocalParticle_set_spin_y(part, spin_y_1);
        }
    #endif

    LocalParticle_set_x(part, x_hat);
    LocalParticle_set_y(part, y_hat);
    LocalParticle_set_px(part, px_hat);
    LocalParticle_set_py(part, py_hat);
}

#endif
// copyright ############################### //
// This file is part of the Xtrack Package.  //
// Copyright (c) CERN, 2021.                 //
// ######################################### //

#ifndef XTRACK_TRACK_DRIFT_H
#define XTRACK_TRACK_DRIFT_H


GPUFUN
void Drift_single_particle_expanded(LocalParticle* part, double length){
    double const rpp    = LocalParticle_get_rpp(part);
    double const rv0v    = 1./LocalParticle_get_rvv(part);
    double const xp     = LocalParticle_get_px(part) * rpp;
    double const yp     = LocalParticle_get_py(part) * rpp;
    double const dzeta  = 1 - rv0v * ( 1. + ( xp*xp + yp*yp ) / 2. );

    LocalParticle_add_to_x(part, xp * length );
    LocalParticle_add_to_y(part, yp * length );
    LocalParticle_add_to_s(part, length);
    LocalParticle_add_to_zeta(part, length * dzeta );
}


GPUFUN
void Drift_single_particle_exact(LocalParticle* part, double length){
    double const px = LocalParticle_get_px(part);
    double const py = LocalParticle_get_py(part);
    double const rv0v    = 1./LocalParticle_get_rvv(part);
    double const one_plus_delta = 1. + LocalParticle_get_delta(part);

    double const one_over_pz = 1./sqrt(one_plus_delta*one_plus_delta
                                       - px * px - py * py);
    double const dzeta = 1 - rv0v * one_plus_delta * one_over_pz;

    LocalParticle_add_to_x(part, px * one_over_pz * length);
    LocalParticle_add_to_y(part, py * one_over_pz * length);
    LocalParticle_add_to_zeta(part, dzeta * length);
    LocalParticle_add_to_s(part, length);
}


GPUFUN
void Drift_single_particle(LocalParticle* part, double length){
    #ifndef XTRACK_USE_EXACT_DRIFTS
        Drift_single_particle_expanded(part, length);
    #else
        Drift_single_particle_exact(part, length);
    #endif
}


#endif /* XTRACK_TRACK_DRIFT_H */


#ifndef XSUITE_TRACK_FLAGS_H
#define XSUITE_TRACK_FLAGS_H
#define XS_FLAG_BACKTRACK (0)
#define XS_FLAG_KILL_CAVITY_KICK (2)
#define XS_FLAG_IGNORE_GLOBAL_APERTURE (3)
#define XS_FLAG_IGNORE_LOCAL_APERTURE (4)
#define XS_FLAG_SR_TAPER (5)
#define XS_FLAG_SR_KICK_SAME_AS_FIRST (6)

#endif // XSUITE_TRACK_FLAGS_H

#include "xtrack/random/random_src/uniform.h"

             
            void sample_uniform(
               RandomUniformData el,

                             ParticlesData particles,
    double* samples,  int64_t n_samples_per_seed, 
                             int64_t flag_increment_at_element,
                  int8_t* io_buffer){

//            #define CONTEXT_OPENMP  //only_for_context cpu_openmp
            #ifdef CONTEXT_OPENMP
                const int64_t capacity = ParticlesData_get__capacity(particles);
                const int num_threads = omp_get_max_threads();

                #ifndef XT_OMP_SKIP_REORGANIZE
                    const int64_t num_particles_to_track = ParticlesData_get__num_active_particles(particles);

                    {
                        LocalParticle lpart;
                        lpart.io_buffer = io_buffer;
                        Particles_to_LocalParticle(particles, &lpart, 0, capacity);
                        check_is_active(&lpart);
                        count_reorganized_particles(&lpart);
                        LocalParticle_to_Particles(&lpart, particles, 0, capacity);
                    }
                #else // When we skip reorganize, we cannot just batch active particles
                    const int64_t num_particles_to_track = capacity;
                #endif

                const int64_t chunk_size = (num_particles_to_track + num_threads - 1)/num_threads; // ceil division
            #endif // CONTEXT_OPENMP

//            #pragma omp parallel for                                                           //only_for_context cpu_openmp
//            for (int64_t batch_id = 0; batch_id < num_threads; batch_id++) {                   //only_for_context cpu_openmp
                LocalParticle lpart;
                lpart.io_buffer = io_buffer;
                lpart.track_flags = 0;
//                int64_t part_id = batch_id * chunk_size;                                       //only_for_context cpu_openmp
//                int64_t end_id = (batch_id + 1) * chunk_size;                                  //only_for_context cpu_openmp
//                if (end_id > num_particles_to_track) end_id = num_particles_to_track;          //only_for_context cpu_openmp

                int64_t part_id = 0;                    //only_for_context cpu_serial
//                int64_t part_id = blockDim.x * blockIdx.x + threadIdx.x; //only_for_context cuda
//                int64_t part_id = get_global_id(0);                    //only_for_context opencl
                int64_t end_id = 0; // unused outside of openmp  //only_for_context cpu_serial cuda opencl

                int64_t part_capacity = ParticlesData_get__capacity(particles);
                if (part_id<part_capacity){
                    Particles_to_LocalParticle(particles, &lpart, part_id, end_id);
                    if (check_is_active(&lpart)>0){
              RandomUniform_sample(el, &lpart, samples, n_samples_per_seed);

                    }
                    if (check_is_active(&lpart)>0 && flag_increment_at_element){
                            increment_at_element(&lpart, 1);
                    }
                }
//            } //only_for_context cpu_openmp

            // On OpenMP we want to additionally by default reorganize all
            // the particles.
//            #ifndef XT_OMP_SKIP_REORGANIZE                             //only_for_context cpu_openmp
//            LocalParticle lpart;                                       //only_for_context cpu_openmp
//            lpart.io_buffer = io_buffer;                               //only_for_context cpu_openmp
//            Particles_to_LocalParticle(particles, &lpart, 0, capacity);//only_for_context cpu_openmp
//            check_is_active(&lpart);                                   //only_for_context cpu_openmp
//            #endif                                                     //only_for_context cpu_openmp
        }

#ifndef XOBJ_TYPEDEF_MultiElementMonitorData
#define XOBJ_TYPEDEF_MultiElementMonitorData
typedef   struct MultiElementMonitorData_s * MultiElementMonitorData;
 static inline MultiElementMonitorData MultiElementMonitorData_getp(MultiElementMonitorData restrict  obj){
  int64_t offset=0;
  return (MultiElementMonitorData)(( char*) obj+offset);
}
 static inline int64_t MultiElementMonitorData_get_start_at_turn(const MultiElementMonitorData restrict  obj){
  int64_t offset=0;
  offset+=8;
  return *( int64_t*)(( char*) obj+offset);
}
 static inline void MultiElementMonitorData_set_start_at_turn(MultiElementMonitorData restrict  obj, int64_t value){
  int64_t offset=0;
  offset+=8;
  *( int64_t*)(( char*) obj+offset)=value;
}
 static inline  int64_t* MultiElementMonitorData_getp_start_at_turn(MultiElementMonitorData restrict  obj){
  int64_t offset=0;
  offset+=8;
  return ( int64_t*)(( char*) obj+offset);
}
 static inline int64_t MultiElementMonitorData_get_stop_at_turn(const MultiElementMonitorData restrict  obj){
  int64_t offset=0;
  offset+=16;
  return *( int64_t*)(( char*) obj+offset);
}
 static inline void MultiElementMonitorData_set_stop_at_turn(MultiElementMonitorData restrict  obj, int64_t value){
  int64_t offset=0;
  offset+=16;
  *( int64_t*)(( char*) obj+offset)=value;
}
 static inline  int64_t* MultiElementMonitorData_getp_stop_at_turn(MultiElementMonitorData restrict  obj){
  int64_t offset=0;
  offset+=16;
  return ( int64_t*)(( char*) obj+offset);
}
 static inline int64_t MultiElementMonitorData_get_part_id_start(const MultiElementMonitorData restrict  obj){
  int64_t offset=0;
  offset+=24;
  return *( int64_t*)(( char*) obj+offset);
}
 static inline void MultiElementMonitorData_set_part_id_start(MultiElementMonitorData restrict  obj, int64_t value){
  int64_t offset=0;
  offset+=24;
  *( int64_t*)(( char*) obj+offset)=value;
}
 static inline  int64_t* MultiElementMonitorData_getp_part_id_start(MultiElementMonitorData restrict  obj){
  int64_t offset=0;
  offset+=24;
  return ( int64_t*)(( char*) obj+offset);
}
 static inline int64_t MultiElementMonitorData_get_part_id_end(const MultiElementMonitorData restrict  obj){
  int64_t offset=0;
  offset+=32;
  return *( int64_t*)(( char*) obj+offset);
}
 static inline void MultiElementMonitorData_set_part_id_end(MultiElementMonitorData restrict  obj, int64_t value){
  int64_t offset=0;
  offset+=32;
  *( int64_t*)(( char*) obj+offset)=value;
}
 static inline  int64_t* MultiElementMonitorData_getp_part_id_end(MultiElementMonitorData restrict  obj){
  int64_t offset=0;
  offset+=32;
  return ( int64_t*)(( char*) obj+offset);
}
 static inline ArrNInt64 MultiElementMonitorData_getp_at_element_mapping(MultiElementMonitorData restrict  obj){
  int64_t offset=0;
  offset+=112;
  return (ArrNInt64)(( char*) obj+offset);
}
 static inline int64_t MultiElementMonitorData_len_at_element_mapping(MultiElementMonitorData restrict  obj){
  int64_t offset=0;
  offset+=112;
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  return arr[1];
}
 static inline void MultiElementMonitorData_shape_at_element_mapping(MultiElementMonitorData restrict  obj,  int64_t* restrict  out_shape){
  int64_t offset=0;
  offset+=112;
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  out_shape[0] = arr[1];
}
 static inline uint32_t MultiElementMonitorData_nd_at_element_mapping(MultiElementMonitorData restrict  obj){
  return 1;
}
 static inline int64_t MultiElementMonitorData_get_at_element_mapping(const MultiElementMonitorData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=112;
  offset+=16+i0*8;
  return *( int64_t*)(( char*) obj+offset);
}
 static inline void MultiElementMonitorData_set_at_element_mapping(MultiElementMonitorData restrict  obj, int64_t i0, int64_t value){
  int64_t offset=0;
  offset+=112;
  offset+=16+i0*8;
  *( int64_t*)(( char*) obj+offset)=value;
}
 static inline  int64_t* MultiElementMonitorData_getp1_at_element_mapping(MultiElementMonitorData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=112;
  offset+=16+i0*8;
  return ( int64_t*)(( char*) obj+offset);
}
 static inline ArrNxMxOxPFloat64 MultiElementMonitorData_getp_data(MultiElementMonitorData restrict  obj){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+104);
  return (ArrNxMxOxPFloat64)(( char*) obj+offset);
}
 static inline int64_t MultiElementMonitorData_len_data(MultiElementMonitorData restrict  obj){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+104);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  return arr[1]*arr[2]*arr[3]*arr[4];
}
 static inline void MultiElementMonitorData_shape_data(MultiElementMonitorData restrict  obj,  int64_t* restrict  out_shape){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+104);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  out_shape[0] = arr[1];
  out_shape[1] = arr[2];
  out_shape[2] = arr[3];
  out_shape[3] = arr[4];
}
 static inline uint32_t MultiElementMonitorData_nd_data(MultiElementMonitorData restrict  obj){
  return 4;
}
 static inline double MultiElementMonitorData_get_data(const MultiElementMonitorData restrict  obj, int64_t i0, int64_t i1, int64_t i2, int64_t i3){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+104);
  int64_t ArrNxMxOxPFloat64_s0=*( int64_t*)(( char*) obj+offset+40);
  int64_t ArrNxMxOxPFloat64_s1=*( int64_t*)(( char*) obj+offset+48);
  int64_t ArrNxMxOxPFloat64_s2=*( int64_t*)(( char*) obj+offset+56);
  int64_t ArrNxMxOxPFloat64_s3=*( int64_t*)(( char*) obj+offset+64);
  offset+=72+i0*ArrNxMxOxPFloat64_s0+i1*ArrNxMxOxPFloat64_s1+i2*ArrNxMxOxPFloat64_s2+i3*ArrNxMxOxPFloat64_s3;
  return *( double*)(( char*) obj+offset);
}
 static inline void MultiElementMonitorData_set_data(MultiElementMonitorData restrict  obj, int64_t i0, int64_t i1, int64_t i2, int64_t i3, double value){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+104);
  int64_t ArrNxMxOxPFloat64_s0=*( int64_t*)(( char*) obj+offset+40);
  int64_t ArrNxMxOxPFloat64_s1=*( int64_t*)(( char*) obj+offset+48);
  int64_t ArrNxMxOxPFloat64_s2=*( int64_t*)(( char*) obj+offset+56);
  int64_t ArrNxMxOxPFloat64_s3=*( int64_t*)(( char*) obj+offset+64);
  offset+=72+i0*ArrNxMxOxPFloat64_s0+i1*ArrNxMxOxPFloat64_s1+i2*ArrNxMxOxPFloat64_s2+i3*ArrNxMxOxPFloat64_s3;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* MultiElementMonitorData_getp4_data(MultiElementMonitorData restrict  obj, int64_t i0, int64_t i1, int64_t i2, int64_t i3){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+104);
  int64_t ArrNxMxOxPFloat64_s0=*( int64_t*)(( char*) obj+offset+40);
  int64_t ArrNxMxOxPFloat64_s1=*( int64_t*)(( char*) obj+offset+48);
  int64_t ArrNxMxOxPFloat64_s2=*( int64_t*)(( char*) obj+offset+56);
  int64_t ArrNxMxOxPFloat64_s3=*( int64_t*)(( char*) obj+offset+64);
  offset+=72+i0*ArrNxMxOxPFloat64_s0+i1*ArrNxMxOxPFloat64_s1+i2*ArrNxMxOxPFloat64_s2+i3*ArrNxMxOxPFloat64_s3;
  return ( double*)(( char*) obj+offset);
}
 static inline double MultiElementMonitorData_get_shift_x(const MultiElementMonitorData restrict  obj){
  int64_t offset=0;
  offset+=40;
  return *( double*)(( char*) obj+offset);
}
 static inline void MultiElementMonitorData_set_shift_x(MultiElementMonitorData restrict  obj, double value){
  int64_t offset=0;
  offset+=40;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* MultiElementMonitorData_getp_shift_x(MultiElementMonitorData restrict  obj){
  int64_t offset=0;
  offset+=40;
  return ( double*)(( char*) obj+offset);
}
 static inline double MultiElementMonitorData_get_shift_y(const MultiElementMonitorData restrict  obj){
  int64_t offset=0;
  offset+=48;
  return *( double*)(( char*) obj+offset);
}
 static inline void MultiElementMonitorData_set_shift_y(MultiElementMonitorData restrict  obj, double value){
  int64_t offset=0;
  offset+=48;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* MultiElementMonitorData_getp_shift_y(MultiElementMonitorData restrict  obj){
  int64_t offset=0;
  offset+=48;
  return ( double*)(( char*) obj+offset);
}
 static inline double MultiElementMonitorData_get_shift_s(const MultiElementMonitorData restrict  obj){
  int64_t offset=0;
  offset+=56;
  return *( double*)(( char*) obj+offset);
}
 static inline void MultiElementMonitorData_set_shift_s(MultiElementMonitorData restrict  obj, double value){
  int64_t offset=0;
  offset+=56;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* MultiElementMonitorData_getp_shift_s(MultiElementMonitorData restrict  obj){
  int64_t offset=0;
  offset+=56;
  return ( double*)(( char*) obj+offset);
}
 static inline double MultiElementMonitorData_get_rot_s_rad(const MultiElementMonitorData restrict  obj){
  int64_t offset=0;
  offset+=64;
  return *( double*)(( char*) obj+offset);
}
 static inline void MultiElementMonitorData_set_rot_s_rad(MultiElementMonitorData restrict  obj, double value){
  int64_t offset=0;
  offset+=64;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* MultiElementMonitorData_getp_rot_s_rad(MultiElementMonitorData restrict  obj){
  int64_t offset=0;
  offset+=64;
  return ( double*)(( char*) obj+offset);
}
 static inline double MultiElementMonitorData_get_rot_x_rad(const MultiElementMonitorData restrict  obj){
  int64_t offset=0;
  offset+=72;
  return *( double*)(( char*) obj+offset);
}
 static inline void MultiElementMonitorData_set_rot_x_rad(MultiElementMonitorData restrict  obj, double value){
  int64_t offset=0;
  offset+=72;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* MultiElementMonitorData_getp_rot_x_rad(MultiElementMonitorData restrict  obj){
  int64_t offset=0;
  offset+=72;
  return ( double*)(( char*) obj+offset);
}
 static inline double MultiElementMonitorData_get_rot_y_rad(const MultiElementMonitorData restrict  obj){
  int64_t offset=0;
  offset+=80;
  return *( double*)(( char*) obj+offset);
}
 static inline void MultiElementMonitorData_set_rot_y_rad(MultiElementMonitorData restrict  obj, double value){
  int64_t offset=0;
  offset+=80;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* MultiElementMonitorData_getp_rot_y_rad(MultiElementMonitorData restrict  obj){
  int64_t offset=0;
  offset+=80;
  return ( double*)(( char*) obj+offset);
}
 static inline double MultiElementMonitorData_get_rot_s_rad_no_frame(const MultiElementMonitorData restrict  obj){
  int64_t offset=0;
  offset+=88;
  return *( double*)(( char*) obj+offset);
}
 static inline void MultiElementMonitorData_set_rot_s_rad_no_frame(MultiElementMonitorData restrict  obj, double value){
  int64_t offset=0;
  offset+=88;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* MultiElementMonitorData_getp_rot_s_rad_no_frame(MultiElementMonitorData restrict  obj){
  int64_t offset=0;
  offset+=88;
  return ( double*)(( char*) obj+offset);
}
 static inline double MultiElementMonitorData_get_rot_shift_anchor(const MultiElementMonitorData restrict  obj){
  int64_t offset=0;
  offset+=96;
  return *( double*)(( char*) obj+offset);
}
 static inline void MultiElementMonitorData_set_rot_shift_anchor(MultiElementMonitorData restrict  obj, double value){
  int64_t offset=0;
  offset+=96;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* MultiElementMonitorData_getp_rot_shift_anchor(MultiElementMonitorData restrict  obj){
  int64_t offset=0;
  offset+=96;
  return ( double*)(( char*) obj+offset);
}
#endif
// copyright ############################### //
// This file is part of the Xtrack Package.  //
// Copyright (c) CERN, 2021.                 //
// ######################################### //

#ifndef XTRACK_CONSTANTS_H
#define XTRACK_CONSTANTS_H

#if !defined( C_LIGHT )
    #define   C_LIGHT ( 299792458.0 )
#endif /* !defined( C_LIGHT ) */

#if !defined( EPSILON_0 )
    #define   EPSILON_0 (8.854187817620e-12)
#endif /* !defined( EPSILON_0 ) */

#if !defined( PI )
    #define PI (3.1415926535897932384626433832795028841971693993751)
#endif /* !defined( PI ) */

#if !defined( MU_0 )
    #define MU_0 (PI*4.0e-7)
#endif /* !defined( MU_0 ) */

#if !defined( DEG2RAD )
    #define DEG2RAD (0.0174532925199432957692369076848861271344287188854)
#endif /* !defiend( DEG2RAD ) */

#if !defined( RAD2DEG )
    #define RAD2DEG (57.29577951308232087679815481410517033240547246656442)
#endif /* !defiend( RAD2DEG ) */

#if !defined( SQRT_PI )
    #define SQRT_PI (1.7724538509055160272981674833411451827975494561224)
#endif /* !defined( SQRT_PI ) */

#if !defined( QELEM )
    #define QELEM (1.60217662e-19)
#endif /* !defined( QELEM ) */

#if !defined( DBL_MAX )
    #define DBL_MAX (1.7976931348623158e+308)
#endif /* !defined( DBL_MAX ) */

#if !defined( DBL_MIN )
    #define DBL_MIN (2.2250738585072014e-308)
#endif /* !defined( DBL_MIN ) */

#if !defined( DBL_EPSILON )
    #define DBL_EPSILON (2.2204460492503131e-16)
#endif /* !defined( DBL_EPSILON ) */

#if !defined( RADIUS_ELECTRON )
    #define RADIUS_ELECTRON (2.8179403262e-15)
#endif /* !defined( RADIUS_ELECTRON ) */

#if !defined( MASS_ELECTRON )
    #define MASS_ELECTRON (9.1093837e-31)
#endif /* !defined( MASS_ELECTRON ) */

#if !defined( SQRT3 )
    #define SQRT3 1.732050807568877
#endif /* !defined( SQRT3 ) */

#if !defined( SQRT2 )
    #define SQRT2 (1.414213562373095048801688724209698078569671875376948073176679738)
#endif /* !defined( SQRT2 ) */

#if !defined( TWO_OVER_SQRT_PI )
    #define TWO_OVER_SQRT_PI (1.128379167095512573896158903121545171688101258657997713688171443418)
#endif /* !defined( TWO_OVER_SQRT_PI ) */

#if !defined( ALPHA_EM )
    #define ALPHA_EM 0.0072973525693
#endif /* !defined( ALPHA_EM ) */

#endif /* XTRACK_CONSTANTS_H */

// copyright ############################### //
// This file is part of the Xtrack Package.  //
// Copyright (c) CERN, 2023.                 //
// ######################################### //

#ifndef XTRACK_FUNCTIONS_H
#define XTRACK_FUNCTIONS_H

#include "xtrack/headers/track.h"


GPUFUN
void kill_all_particles(LocalParticle* part0, int64_t kill_state) {
    START_PER_PARTICLE_BLOCK(part0, part);
        LocalParticle_kill_particle(part, kill_state);
    END_PER_PARTICLE_BLOCK;
}


GPUFUN
int8_t assert_tracking(LocalParticle* part, int64_t kill_state){
    // Whenever we are not tracking, e.g. in a twiss, the particle will be at_turn < 0.
    // We test this to distinguish genuine tracking from twiss.
    if (LocalParticle_get_at_turn(part) < 0){
        LocalParticle_kill_particle(part, kill_state);
        return 0;
    }
    return 1;
}

#endif /* XTRACK_FUNCTIONS_H */

// copyright ############################### //
// This file is part of the Xtrack Package.  //
// Copyright (c) CERN, 2023.                 //
// ######################################### //

#ifndef XTRACK_PARTICLE_STATES_H
#define XTRACK_PARTICLE_STATES_H

#define  XT_LOST_ON_APERTURE       0
#define  XT_LOST_ON_LONG_CUT      -2
#define  XT_LOST_ALL_E_IN_SYNRAD -10
#define  RNG_ERR_SEEDS_NOT_SET   -20
#define  RNG_ERR_INVALID_TRACK   -21
#define  RNG_ERR_RUTH_NOT_SET    -22
#define  XT_INVALID_SLICE_TRANSFORM -40
#define  XT_INVALID_CURVED_SLICE_TRANSFORM -41
#define  XT_INVALID_THIN_SLICE_TRANSFORM -42

#endif /* XTRACK_PARTICLE_STATES_H */

// copyright ############################### //
// This file is part of the Xtrack Package.  //
// Copyright (c) CERN, 2025.                 //
// ######################################### //
#ifndef XTRACK_TRACK_SROTATION_H
#define XTRACK_TRACK_SROTATION_H

#include "xtrack/headers/track.h"


GPUFUN
void SRotation_single_particle(LocalParticle* part, double sin_z, double cos_z)
{
    double const x  = LocalParticle_get_x(part);
    double const y  = LocalParticle_get_y(part);
    double const px = LocalParticle_get_px(part);
    double const py = LocalParticle_get_py(part);

    double const x_hat  =  cos_z * x  + sin_z * y;
    double const y_hat  = -sin_z * x  + cos_z * y;
    double const px_hat =  cos_z * px + sin_z * py;
    double const py_hat = -sin_z * px + cos_z * py;

    /* Spin tracking is disabled by the synrad compile flag */
    #ifndef XTRACK_MULTIPOLE_NO_SYNRAD
        // Rotate spin
        double const spin_x_0 = LocalParticle_get_spin_x(part);
        double const spin_y_0 = LocalParticle_get_spin_y(part);
        if ((spin_x_0 != 0) || (spin_y_0 != 0)){
            double const spin_x_1 = cos_z*spin_x_0 + sin_z*spin_y_0;
            double const spin_y_1 = -sin_z*spin_x_0 + cos_z*spin_y_0;
            LocalParticle_set_spin_x(part, spin_x_1);
            LocalParticle_set_spin_y(part, spin_y_1);
        }
    #endif

    LocalParticle_set_x(part, x_hat);
    LocalParticle_set_y(part, y_hat);
    LocalParticle_set_px(part, px_hat);
    LocalParticle_set_py(part, py_hat);
}

#endif
// copyright ############################### //
// This file is part of the Xtrack Package.  //
// Copyright (c) CERN, 2021.                 //
// ######################################### //

#ifndef XTRACK_TRACK_DRIFT_H
#define XTRACK_TRACK_DRIFT_H


GPUFUN
void Drift_single_particle_expanded(LocalParticle* part, double length){
    double const rpp    = LocalParticle_get_rpp(part);
    double const rv0v    = 1./LocalParticle_get_rvv(part);
    double const xp     = LocalParticle_get_px(part) * rpp;
    double const yp     = LocalParticle_get_py(part) * rpp;
    double const dzeta  = 1 - rv0v * ( 1. + ( xp*xp + yp*yp ) / 2. );

    LocalParticle_add_to_x(part, xp * length );
    LocalParticle_add_to_y(part, yp * length );
    LocalParticle_add_to_s(part, length);
    LocalParticle_add_to_zeta(part, length * dzeta );
}


GPUFUN
void Drift_single_particle_exact(LocalParticle* part, double length){
    double const px = LocalParticle_get_px(part);
    double const py = LocalParticle_get_py(part);
    double const rv0v    = 1./LocalParticle_get_rvv(part);
    double const one_plus_delta = 1. + LocalParticle_get_delta(part);

    double const one_over_pz = 1./sqrt(one_plus_delta*one_plus_delta
                                       - px * px - py * py);
    double const dzeta = 1 - rv0v * one_plus_delta * one_over_pz;

    LocalParticle_add_to_x(part, px * one_over_pz * length);
    LocalParticle_add_to_y(part, py * one_over_pz * length);
    LocalParticle_add_to_zeta(part, dzeta * length);
    LocalParticle_add_to_s(part, length);
}


GPUFUN
void Drift_single_particle(LocalParticle* part, double length){
    #ifndef XTRACK_USE_EXACT_DRIFTS
        Drift_single_particle_expanded(part, length);
    #else
        Drift_single_particle_exact(part, length);
    #endif
}


#endif /* XTRACK_TRACK_DRIFT_H */


#ifndef XSUITE_TRACK_FLAGS_H
#define XSUITE_TRACK_FLAGS_H
#define XS_FLAG_BACKTRACK (0)
#define XS_FLAG_KILL_CAVITY_KICK (2)
#define XS_FLAG_IGNORE_GLOBAL_APERTURE (3)
#define XS_FLAG_IGNORE_LOCAL_APERTURE (4)
#define XS_FLAG_SR_TAPER (5)
#define XS_FLAG_SR_KICK_SAME_AS_FIRST (6)

#endif // XSUITE_TRACK_FLAGS_H

#include "xtrack/monitors/multi_element_monitor.h"
#define ELEMENT_NAME MultiElementMonitor
#define ALLOW_ROT_AND_SHIFT 1
#include "xtrack/headers/track_local_particle_with_transformations.h"
#undef ELEMENT_NAME
#undef ALLOW_ROT_AND_SHIFT

             
            void MultiElementMonitor_track_particles(
               MultiElementMonitorData el,

                             ParticlesData particles,

                             int64_t flag_increment_at_element,
                  int8_t* io_buffer){

//            #define CONTEXT_OPENMP  //only_for_context cpu_openmp
            #ifdef CONTEXT_OPENMP
                const int64_t capacity = ParticlesData_get__capacity(particles);
                const int num_threads = omp_get_max_threads();

                #ifndef XT_OMP_SKIP_REORGANIZE
                    const int64_t num_particles_to_track = ParticlesData_get__num_active_particles(particles);

                    {
                        LocalParticle lpart;
                        lpart.io_buffer = io_buffer;
                        Particles_to_LocalParticle(particles, &lpart, 0, capacity);
                        check_is_active(&lpart);
                        count_reorganized_particles(&lpart);
                        LocalParticle_to_Particles(&lpart, particles, 0, capacity);
                    }
                #else // When we skip reorganize, we cannot just batch active particles
                    const int64_t num_particles_to_track = capacity;
                #endif

                const int64_t chunk_size = (num_particles_to_track + num_threads - 1)/num_threads; // ceil division
            #endif // CONTEXT_OPENMP

//            #pragma omp parallel for                                                           //only_for_context cpu_openmp
//            for (int64_t batch_id = 0; batch_id < num_threads; batch_id++) {                   //only_for_context cpu_openmp
                LocalParticle lpart;
                lpart.io_buffer = io_buffer;
                lpart.track_flags = 0;
//                int64_t part_id = batch_id * chunk_size;                                       //only_for_context cpu_openmp
//                int64_t end_id = (batch_id + 1) * chunk_size;                                  //only_for_context cpu_openmp
//                if (end_id > num_particles_to_track) end_id = num_particles_to_track;          //only_for_context cpu_openmp

                int64_t part_id = 0;                    //only_for_context cpu_serial
//                int64_t part_id = blockDim.x * blockIdx.x + threadIdx.x; //only_for_context cuda
//                int64_t part_id = get_global_id(0);                    //only_for_context opencl
                int64_t end_id = 0; // unused outside of openmp  //only_for_context cpu_serial cuda opencl

                int64_t part_capacity = ParticlesData_get__capacity(particles);
                if (part_id<part_capacity){
                    Particles_to_LocalParticle(particles, &lpart, part_id, end_id);
                    if (check_is_active(&lpart)>0){
              MultiElementMonitor_track_local_particle_with_transformations(el, &lpart);

                    }
                    if (check_is_active(&lpart)>0 && flag_increment_at_element){
                            increment_at_element(&lpart, 1);
                    }
                }
//            } //only_for_context cpu_openmp

            // On OpenMP we want to additionally by default reorganize all
            // the particles.
//            #ifndef XT_OMP_SKIP_REORGANIZE                             //only_for_context cpu_openmp
//            LocalParticle lpart;                                       //only_for_context cpu_openmp
//            lpart.io_buffer = io_buffer;                               //only_for_context cpu_openmp
//            Particles_to_LocalParticle(particles, &lpart, 0, capacity);//only_for_context cpu_openmp
//            check_is_active(&lpart);                                   //only_for_context cpu_openmp
//            #endif                                                     //only_for_context cpu_openmp
        }

#ifndef XOBJ_TYPEDEF_TempSlicerData
#define XOBJ_TYPEDEF_TempSlicerData
typedef   struct TempSlicerData_s * TempSlicerData;
 static inline TempSlicerData TempSlicerData_getp(TempSlicerData restrict  obj){
  int64_t offset=0;
  return (TempSlicerData)(( char*) obj+offset);
}
 static inline int64_t TempSlicerData_get__dummy(const TempSlicerData restrict  obj){
  int64_t offset=0;
  return *( int64_t*)(( char*) obj+offset);
}
 static inline void TempSlicerData_set__dummy(TempSlicerData restrict  obj, int64_t value){
  int64_t offset=0;
  *( int64_t*)(( char*) obj+offset)=value;
}
 static inline  int64_t* TempSlicerData_getp__dummy(TempSlicerData restrict  obj){
  int64_t offset=0;
  return ( int64_t*)(( char*) obj+offset);
}
#endif
#include "xfields/headers/compute_slice_moments.h"
#ifndef XOBJ_TYPEDEF_TriCubicInterpolatedFieldMapData
#define XOBJ_TYPEDEF_TriCubicInterpolatedFieldMapData
typedef   struct TriCubicInterpolatedFieldMapData_s * TriCubicInterpolatedFieldMapData;
 static inline TriCubicInterpolatedFieldMapData TriCubicInterpolatedFieldMapData_getp(TriCubicInterpolatedFieldMapData restrict  obj){
  int64_t offset=0;
  return (TriCubicInterpolatedFieldMapData)(( char*) obj+offset);
}
 static inline double TriCubicInterpolatedFieldMapData_get_x_min(const TriCubicInterpolatedFieldMapData restrict  obj){
  int64_t offset=0;
  offset+=8;
  return *( double*)(( char*) obj+offset);
}
 static inline void TriCubicInterpolatedFieldMapData_set_x_min(TriCubicInterpolatedFieldMapData restrict  obj, double value){
  int64_t offset=0;
  offset+=8;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* TriCubicInterpolatedFieldMapData_getp_x_min(TriCubicInterpolatedFieldMapData restrict  obj){
  int64_t offset=0;
  offset+=8;
  return ( double*)(( char*) obj+offset);
}
 static inline double TriCubicInterpolatedFieldMapData_get_y_min(const TriCubicInterpolatedFieldMapData restrict  obj){
  int64_t offset=0;
  offset+=16;
  return *( double*)(( char*) obj+offset);
}
 static inline void TriCubicInterpolatedFieldMapData_set_y_min(TriCubicInterpolatedFieldMapData restrict  obj, double value){
  int64_t offset=0;
  offset+=16;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* TriCubicInterpolatedFieldMapData_getp_y_min(TriCubicInterpolatedFieldMapData restrict  obj){
  int64_t offset=0;
  offset+=16;
  return ( double*)(( char*) obj+offset);
}
 static inline double TriCubicInterpolatedFieldMapData_get_z_min(const TriCubicInterpolatedFieldMapData restrict  obj){
  int64_t offset=0;
  offset+=24;
  return *( double*)(( char*) obj+offset);
}
 static inline void TriCubicInterpolatedFieldMapData_set_z_min(TriCubicInterpolatedFieldMapData restrict  obj, double value){
  int64_t offset=0;
  offset+=24;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* TriCubicInterpolatedFieldMapData_getp_z_min(TriCubicInterpolatedFieldMapData restrict  obj){
  int64_t offset=0;
  offset+=24;
  return ( double*)(( char*) obj+offset);
}
 static inline int64_t TriCubicInterpolatedFieldMapData_get_nx(const TriCubicInterpolatedFieldMapData restrict  obj){
  int64_t offset=0;
  offset+=32;
  return *( int64_t*)(( char*) obj+offset);
}
 static inline void TriCubicInterpolatedFieldMapData_set_nx(TriCubicInterpolatedFieldMapData restrict  obj, int64_t value){
  int64_t offset=0;
  offset+=32;
  *( int64_t*)(( char*) obj+offset)=value;
}
 static inline  int64_t* TriCubicInterpolatedFieldMapData_getp_nx(TriCubicInterpolatedFieldMapData restrict  obj){
  int64_t offset=0;
  offset+=32;
  return ( int64_t*)(( char*) obj+offset);
}
 static inline int64_t TriCubicInterpolatedFieldMapData_get_ny(const TriCubicInterpolatedFieldMapData restrict  obj){
  int64_t offset=0;
  offset+=40;
  return *( int64_t*)(( char*) obj+offset);
}
 static inline void TriCubicInterpolatedFieldMapData_set_ny(TriCubicInterpolatedFieldMapData restrict  obj, int64_t value){
  int64_t offset=0;
  offset+=40;
  *( int64_t*)(( char*) obj+offset)=value;
}
 static inline  int64_t* TriCubicInterpolatedFieldMapData_getp_ny(TriCubicInterpolatedFieldMapData restrict  obj){
  int64_t offset=0;
  offset+=40;
  return ( int64_t*)(( char*) obj+offset);
}
 static inline int64_t TriCubicInterpolatedFieldMapData_get_nz(const TriCubicInterpolatedFieldMapData restrict  obj){
  int64_t offset=0;
  offset+=48;
  return *( int64_t*)(( char*) obj+offset);
}
 static inline void TriCubicInterpolatedFieldMapData_set_nz(TriCubicInterpolatedFieldMapData restrict  obj, int64_t value){
  int64_t offset=0;
  offset+=48;
  *( int64_t*)(( char*) obj+offset)=value;
}
 static inline  int64_t* TriCubicInterpolatedFieldMapData_getp_nz(TriCubicInterpolatedFieldMapData restrict  obj){
  int64_t offset=0;
  offset+=48;
  return ( int64_t*)(( char*) obj+offset);
}
 static inline int64_t TriCubicInterpolatedFieldMapData_get_mirror_x(const TriCubicInterpolatedFieldMapData restrict  obj){
  int64_t offset=0;
  offset+=56;
  return *( int64_t*)(( char*) obj+offset);
}
 static inline void TriCubicInterpolatedFieldMapData_set_mirror_x(TriCubicInterpolatedFieldMapData restrict  obj, int64_t value){
  int64_t offset=0;
  offset+=56;
  *( int64_t*)(( char*) obj+offset)=value;
}
 static inline  int64_t* TriCubicInterpolatedFieldMapData_getp_mirror_x(TriCubicInterpolatedFieldMapData restrict  obj){
  int64_t offset=0;
  offset+=56;
  return ( int64_t*)(( char*) obj+offset);
}
 static inline int64_t TriCubicInterpolatedFieldMapData_get_mirror_y(const TriCubicInterpolatedFieldMapData restrict  obj){
  int64_t offset=0;
  offset+=64;
  return *( int64_t*)(( char*) obj+offset);
}
 static inline void TriCubicInterpolatedFieldMapData_set_mirror_y(TriCubicInterpolatedFieldMapData restrict  obj, int64_t value){
  int64_t offset=0;
  offset+=64;
  *( int64_t*)(( char*) obj+offset)=value;
}
 static inline  int64_t* TriCubicInterpolatedFieldMapData_getp_mirror_y(TriCubicInterpolatedFieldMapData restrict  obj){
  int64_t offset=0;
  offset+=64;
  return ( int64_t*)(( char*) obj+offset);
}
 static inline int64_t TriCubicInterpolatedFieldMapData_get_mirror_z(const TriCubicInterpolatedFieldMapData restrict  obj){
  int64_t offset=0;
  offset+=72;
  return *( int64_t*)(( char*) obj+offset);
}
 static inline void TriCubicInterpolatedFieldMapData_set_mirror_z(TriCubicInterpolatedFieldMapData restrict  obj, int64_t value){
  int64_t offset=0;
  offset+=72;
  *( int64_t*)(( char*) obj+offset)=value;
}
 static inline  int64_t* TriCubicInterpolatedFieldMapData_getp_mirror_z(TriCubicInterpolatedFieldMapData restrict  obj){
  int64_t offset=0;
  offset+=72;
  return ( int64_t*)(( char*) obj+offset);
}
 static inline double TriCubicInterpolatedFieldMapData_get_dx(const TriCubicInterpolatedFieldMapData restrict  obj){
  int64_t offset=0;
  offset+=80;
  return *( double*)(( char*) obj+offset);
}
 static inline void TriCubicInterpolatedFieldMapData_set_dx(TriCubicInterpolatedFieldMapData restrict  obj, double value){
  int64_t offset=0;
  offset+=80;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* TriCubicInterpolatedFieldMapData_getp_dx(TriCubicInterpolatedFieldMapData restrict  obj){
  int64_t offset=0;
  offset+=80;
  return ( double*)(( char*) obj+offset);
}
 static inline double TriCubicInterpolatedFieldMapData_get_dy(const TriCubicInterpolatedFieldMapData restrict  obj){
  int64_t offset=0;
  offset+=88;
  return *( double*)(( char*) obj+offset);
}
 static inline void TriCubicInterpolatedFieldMapData_set_dy(TriCubicInterpolatedFieldMapData restrict  obj, double value){
  int64_t offset=0;
  offset+=88;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* TriCubicInterpolatedFieldMapData_getp_dy(TriCubicInterpolatedFieldMapData restrict  obj){
  int64_t offset=0;
  offset+=88;
  return ( double*)(( char*) obj+offset);
}
 static inline double TriCubicInterpolatedFieldMapData_get_dz(const TriCubicInterpolatedFieldMapData restrict  obj){
  int64_t offset=0;
  offset+=96;
  return *( double*)(( char*) obj+offset);
}
 static inline void TriCubicInterpolatedFieldMapData_set_dz(TriCubicInterpolatedFieldMapData restrict  obj, double value){
  int64_t offset=0;
  offset+=96;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* TriCubicInterpolatedFieldMapData_getp_dz(TriCubicInterpolatedFieldMapData restrict  obj){
  int64_t offset=0;
  offset+=96;
  return ( double*)(( char*) obj+offset);
}
 static inline ArrNFloat64 TriCubicInterpolatedFieldMapData_getp_phi_taylor(TriCubicInterpolatedFieldMapData restrict  obj){
  int64_t offset=0;
  offset+=104;
  return (ArrNFloat64)(( char*) obj+offset);
}
 static inline int64_t TriCubicInterpolatedFieldMapData_len_phi_taylor(TriCubicInterpolatedFieldMapData restrict  obj){
  int64_t offset=0;
  offset+=104;
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  return arr[1];
}
 static inline void TriCubicInterpolatedFieldMapData_shape_phi_taylor(TriCubicInterpolatedFieldMapData restrict  obj,  int64_t* restrict  out_shape){
  int64_t offset=0;
  offset+=104;
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  out_shape[0] = arr[1];
}
 static inline uint32_t TriCubicInterpolatedFieldMapData_nd_phi_taylor(TriCubicInterpolatedFieldMapData restrict  obj){
  return 1;
}
 static inline double TriCubicInterpolatedFieldMapData_get_phi_taylor(const TriCubicInterpolatedFieldMapData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=104;
  offset+=16+i0*8;
  return *( double*)(( char*) obj+offset);
}
 static inline void TriCubicInterpolatedFieldMapData_set_phi_taylor(TriCubicInterpolatedFieldMapData restrict  obj, int64_t i0, double value){
  int64_t offset=0;
  offset+=104;
  offset+=16+i0*8;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* TriCubicInterpolatedFieldMapData_getp1_phi_taylor(TriCubicInterpolatedFieldMapData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=104;
  offset+=16+i0*8;
  return ( double*)(( char*) obj+offset);
}
#endif
#include "xfields/fieldmaps/interpolated_src/tricubic_coefficients.h"
#include "xfields/fieldmaps/interpolated_src/cubic_interpolators.h"
#include "xfields/fieldmaps/interpolated_src/central_diff.h"
#include "xfields/fieldmaps/interpolated_src/charge_deposition.h"
#ifndef XOBJ_TYPEDEF_RandomNormalData
#define XOBJ_TYPEDEF_RandomNormalData
typedef   struct RandomNormalData_s * RandomNormalData;
 static inline RandomNormalData RandomNormalData_getp(RandomNormalData restrict  obj){
  int64_t offset=0;
  return (RandomNormalData)(( char*) obj+offset);
}
 static inline uint8_t RandomNormalData_get__dummy(const RandomNormalData restrict  obj){
  int64_t offset=0;
  return *(( uint8_t*) obj+offset);
}
 static inline void RandomNormalData_set__dummy(RandomNormalData restrict  obj, uint8_t value){
  int64_t offset=0;
  *(( uint8_t*) obj+offset)=value;
}
 static inline  uint8_t* RandomNormalData_getp__dummy(RandomNormalData restrict  obj){
  int64_t offset=0;
  return ( uint8_t*)(( char*) obj+offset);
}
 static inline double RandomNormalData_get_shift_x(const RandomNormalData restrict  obj){
  int64_t offset=0;
  offset+=8;
  return *( double*)(( char*) obj+offset);
}
 static inline void RandomNormalData_set_shift_x(RandomNormalData restrict  obj, double value){
  int64_t offset=0;
  offset+=8;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* RandomNormalData_getp_shift_x(RandomNormalData restrict  obj){
  int64_t offset=0;
  offset+=8;
  return ( double*)(( char*) obj+offset);
}
 static inline double RandomNormalData_get_shift_y(const RandomNormalData restrict  obj){
  int64_t offset=0;
  offset+=16;
  return *( double*)(( char*) obj+offset);
}
 static inline void RandomNormalData_set_shift_y(RandomNormalData restrict  obj, double value){
  int64_t offset=0;
  offset+=16;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* RandomNormalData_getp_shift_y(RandomNormalData restrict  obj){
  int64_t offset=0;
  offset+=16;
  return ( double*)(( char*) obj+offset);
}
 static inline double RandomNormalData_get_shift_s(const RandomNormalData restrict  obj){
  int64_t offset=0;
  offset+=24;
  return *( double*)(( char*) obj+offset);
}
 static inline void RandomNormalData_set_shift_s(RandomNormalData restrict  obj, double value){
  int64_t offset=0;
  offset+=24;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* RandomNormalData_getp_shift_s(RandomNormalData restrict  obj){
  int64_t offset=0;
  offset+=24;
  return ( double*)(( char*) obj+offset);
}
 static inline double RandomNormalData_get_rot_s_rad(const RandomNormalData restrict  obj){
  int64_t offset=0;
  offset+=32;
  return *( double*)(( char*) obj+offset);
}
 static inline void RandomNormalData_set_rot_s_rad(RandomNormalData restrict  obj, double value){
  int64_t offset=0;
  offset+=32;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* RandomNormalData_getp_rot_s_rad(RandomNormalData restrict  obj){
  int64_t offset=0;
  offset+=32;
  return ( double*)(( char*) obj+offset);
}
 static inline double RandomNormalData_get_rot_x_rad(const RandomNormalData restrict  obj){
  int64_t offset=0;
  offset+=40;
  return *( double*)(( char*) obj+offset);
}
 static inline void RandomNormalData_set_rot_x_rad(RandomNormalData restrict  obj, double value){
  int64_t offset=0;
  offset+=40;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* RandomNormalData_getp_rot_x_rad(RandomNormalData restrict  obj){
  int64_t offset=0;
  offset+=40;
  return ( double*)(( char*) obj+offset);
}
 static inline double RandomNormalData_get_rot_y_rad(const RandomNormalData restrict  obj){
  int64_t offset=0;
  offset+=48;
  return *( double*)(( char*) obj+offset);
}
 static inline void RandomNormalData_set_rot_y_rad(RandomNormalData restrict  obj, double value){
  int64_t offset=0;
  offset+=48;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* RandomNormalData_getp_rot_y_rad(RandomNormalData restrict  obj){
  int64_t offset=0;
  offset+=48;
  return ( double*)(( char*) obj+offset);
}
 static inline double RandomNormalData_get_rot_s_rad_no_frame(const RandomNormalData restrict  obj){
  int64_t offset=0;
  offset+=56;
  return *( double*)(( char*) obj+offset);
}
 static inline void RandomNormalData_set_rot_s_rad_no_frame(RandomNormalData restrict  obj, double value){
  int64_t offset=0;
  offset+=56;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* RandomNormalData_getp_rot_s_rad_no_frame(RandomNormalData restrict  obj){
  int64_t offset=0;
  offset+=56;
  return ( double*)(( char*) obj+offset);
}
 static inline double RandomNormalData_get_rot_shift_anchor(const RandomNormalData restrict  obj){
  int64_t offset=0;
  offset+=64;
  return *( double*)(( char*) obj+offset);
}
 static inline void RandomNormalData_set_rot_shift_anchor(RandomNormalData restrict  obj, double value){
  int64_t offset=0;
  offset+=64;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* RandomNormalData_getp_rot_shift_anchor(RandomNormalData restrict  obj){
  int64_t offset=0;
  offset+=64;
  return ( double*)(( char*) obj+offset);
}
#endif
// copyright ############################### //
// This file is part of the Xtrack Package.  //
// Copyright (c) CERN, 2021.                 //
// ######################################### //

#ifndef XTRACK_CONSTANTS_H
#define XTRACK_CONSTANTS_H

#if !defined( C_LIGHT )
    #define   C_LIGHT ( 299792458.0 )
#endif /* !defined( C_LIGHT ) */

#if !defined( EPSILON_0 )
    #define   EPSILON_0 (8.854187817620e-12)
#endif /* !defined( EPSILON_0 ) */

#if !defined( PI )
    #define PI (3.1415926535897932384626433832795028841971693993751)
#endif /* !defined( PI ) */

#if !defined( MU_0 )
    #define MU_0 (PI*4.0e-7)
#endif /* !defined( MU_0 ) */

#if !defined( DEG2RAD )
    #define DEG2RAD (0.0174532925199432957692369076848861271344287188854)
#endif /* !defiend( DEG2RAD ) */

#if !defined( RAD2DEG )
    #define RAD2DEG (57.29577951308232087679815481410517033240547246656442)
#endif /* !defiend( RAD2DEG ) */

#if !defined( SQRT_PI )
    #define SQRT_PI (1.7724538509055160272981674833411451827975494561224)
#endif /* !defined( SQRT_PI ) */

#if !defined( QELEM )
    #define QELEM (1.60217662e-19)
#endif /* !defined( QELEM ) */

#if !defined( DBL_MAX )
    #define DBL_MAX (1.7976931348623158e+308)
#endif /* !defined( DBL_MAX ) */

#if !defined( DBL_MIN )
    #define DBL_MIN (2.2250738585072014e-308)
#endif /* !defined( DBL_MIN ) */

#if !defined( DBL_EPSILON )
    #define DBL_EPSILON (2.2204460492503131e-16)
#endif /* !defined( DBL_EPSILON ) */

#if !defined( RADIUS_ELECTRON )
    #define RADIUS_ELECTRON (2.8179403262e-15)
#endif /* !defined( RADIUS_ELECTRON ) */

#if !defined( MASS_ELECTRON )
    #define MASS_ELECTRON (9.1093837e-31)
#endif /* !defined( MASS_ELECTRON ) */

#if !defined( SQRT3 )
    #define SQRT3 1.732050807568877
#endif /* !defined( SQRT3 ) */

#if !defined( SQRT2 )
    #define SQRT2 (1.414213562373095048801688724209698078569671875376948073176679738)
#endif /* !defined( SQRT2 ) */

#if !defined( TWO_OVER_SQRT_PI )
    #define TWO_OVER_SQRT_PI (1.128379167095512573896158903121545171688101258657997713688171443418)
#endif /* !defined( TWO_OVER_SQRT_PI ) */

#if !defined( ALPHA_EM )
    #define ALPHA_EM 0.0072973525693
#endif /* !defined( ALPHA_EM ) */

#endif /* XTRACK_CONSTANTS_H */

// copyright ############################### //
// This file is part of the Xtrack Package.  //
// Copyright (c) CERN, 2023.                 //
// ######################################### //

#ifndef XTRACK_FUNCTIONS_H
#define XTRACK_FUNCTIONS_H

#include "xtrack/headers/track.h"


GPUFUN
void kill_all_particles(LocalParticle* part0, int64_t kill_state) {
    START_PER_PARTICLE_BLOCK(part0, part);
        LocalParticle_kill_particle(part, kill_state);
    END_PER_PARTICLE_BLOCK;
}


GPUFUN
int8_t assert_tracking(LocalParticle* part, int64_t kill_state){
    // Whenever we are not tracking, e.g. in a twiss, the particle will be at_turn < 0.
    // We test this to distinguish genuine tracking from twiss.
    if (LocalParticle_get_at_turn(part) < 0){
        LocalParticle_kill_particle(part, kill_state);
        return 0;
    }
    return 1;
}

#endif /* XTRACK_FUNCTIONS_H */

// copyright ############################### //
// This file is part of the Xtrack Package.  //
// Copyright (c) CERN, 2023.                 //
// ######################################### //

#ifndef XTRACK_PARTICLE_STATES_H
#define XTRACK_PARTICLE_STATES_H

#define  XT_LOST_ON_APERTURE       0
#define  XT_LOST_ON_LONG_CUT      -2
#define  XT_LOST_ALL_E_IN_SYNRAD -10
#define  RNG_ERR_SEEDS_NOT_SET   -20
#define  RNG_ERR_INVALID_TRACK   -21
#define  RNG_ERR_RUTH_NOT_SET    -22
#define  XT_INVALID_SLICE_TRANSFORM -40
#define  XT_INVALID_CURVED_SLICE_TRANSFORM -41
#define  XT_INVALID_THIN_SLICE_TRANSFORM -42

#endif /* XTRACK_PARTICLE_STATES_H */

// copyright ############################### //
// This file is part of the Xtrack Package.  //
// Copyright (c) CERN, 2025.                 //
// ######################################### //
#ifndef XTRACK_TRACK_SROTATION_H
#define XTRACK_TRACK_SROTATION_H

#include "xtrack/headers/track.h"


GPUFUN
void SRotation_single_particle(LocalParticle* part, double sin_z, double cos_z)
{
    double const x  = LocalParticle_get_x(part);
    double const y  = LocalParticle_get_y(part);
    double const px = LocalParticle_get_px(part);
    double const py = LocalParticle_get_py(part);

    double const x_hat  =  cos_z * x  + sin_z * y;
    double const y_hat  = -sin_z * x  + cos_z * y;
    double const px_hat =  cos_z * px + sin_z * py;
    double const py_hat = -sin_z * px + cos_z * py;

    /* Spin tracking is disabled by the synrad compile flag */
    #ifndef XTRACK_MULTIPOLE_NO_SYNRAD
        // Rotate spin
        double const spin_x_0 = LocalParticle_get_spin_x(part);
        double const spin_y_0 = LocalParticle_get_spin_y(part);
        if ((spin_x_0 != 0) || (spin_y_0 != 0)){
            double const spin_x_1 = cos_z*spin_x_0 + sin_z*spin_y_0;
            double const spin_y_1 = -sin_z*spin_x_0 + cos_z*spin_y_0;
            LocalParticle_set_spin_x(part, spin_x_1);
            LocalParticle_set_spin_y(part, spin_y_1);
        }
    #endif

    LocalParticle_set_x(part, x_hat);
    LocalParticle_set_y(part, y_hat);
    LocalParticle_set_px(part, px_hat);
    LocalParticle_set_py(part, py_hat);
}

#endif
// copyright ############################### //
// This file is part of the Xtrack Package.  //
// Copyright (c) CERN, 2021.                 //
// ######################################### //

#ifndef XTRACK_TRACK_DRIFT_H
#define XTRACK_TRACK_DRIFT_H


GPUFUN
void Drift_single_particle_expanded(LocalParticle* part, double length){
    double const rpp    = LocalParticle_get_rpp(part);
    double const rv0v    = 1./LocalParticle_get_rvv(part);
    double const xp     = LocalParticle_get_px(part) * rpp;
    double const yp     = LocalParticle_get_py(part) * rpp;
    double const dzeta  = 1 - rv0v * ( 1. + ( xp*xp + yp*yp ) / 2. );

    LocalParticle_add_to_x(part, xp * length );
    LocalParticle_add_to_y(part, yp * length );
    LocalParticle_add_to_s(part, length);
    LocalParticle_add_to_zeta(part, length * dzeta );
}


GPUFUN
void Drift_single_particle_exact(LocalParticle* part, double length){
    double const px = LocalParticle_get_px(part);
    double const py = LocalParticle_get_py(part);
    double const rv0v    = 1./LocalParticle_get_rvv(part);
    double const one_plus_delta = 1. + LocalParticle_get_delta(part);

    double const one_over_pz = 1./sqrt(one_plus_delta*one_plus_delta
                                       - px * px - py * py);
    double const dzeta = 1 - rv0v * one_plus_delta * one_over_pz;

    LocalParticle_add_to_x(part, px * one_over_pz * length);
    LocalParticle_add_to_y(part, py * one_over_pz * length);
    LocalParticle_add_to_zeta(part, dzeta * length);
    LocalParticle_add_to_s(part, length);
}


GPUFUN
void Drift_single_particle(LocalParticle* part, double length){
    #ifndef XTRACK_USE_EXACT_DRIFTS
        Drift_single_particle_expanded(part, length);
    #else
        Drift_single_particle_exact(part, length);
    #endif
}


#endif /* XTRACK_TRACK_DRIFT_H */


#ifndef XSUITE_TRACK_FLAGS_H
#define XSUITE_TRACK_FLAGS_H
#define XS_FLAG_BACKTRACK (0)
#define XS_FLAG_KILL_CAVITY_KICK (2)
#define XS_FLAG_IGNORE_GLOBAL_APERTURE (3)
#define XS_FLAG_IGNORE_LOCAL_APERTURE (4)
#define XS_FLAG_SR_TAPER (5)
#define XS_FLAG_SR_KICK_SAME_AS_FIRST (6)

#endif // XSUITE_TRACK_FLAGS_H

#include "xtrack/random/random_src/normal.h"

             
            void sample_gauss(
               RandomNormalData el,

                             ParticlesData particles,
    double* samples,  int64_t n_samples_per_seed, 
                             int64_t flag_increment_at_element,
                  int8_t* io_buffer){

//            #define CONTEXT_OPENMP  //only_for_context cpu_openmp
            #ifdef CONTEXT_OPENMP
                const int64_t capacity = ParticlesData_get__capacity(particles);
                const int num_threads = omp_get_max_threads();

                #ifndef XT_OMP_SKIP_REORGANIZE
                    const int64_t num_particles_to_track = ParticlesData_get__num_active_particles(particles);

                    {
                        LocalParticle lpart;
                        lpart.io_buffer = io_buffer;
                        Particles_to_LocalParticle(particles, &lpart, 0, capacity);
                        check_is_active(&lpart);
                        count_reorganized_particles(&lpart);
                        LocalParticle_to_Particles(&lpart, particles, 0, capacity);
                    }
                #else // When we skip reorganize, we cannot just batch active particles
                    const int64_t num_particles_to_track = capacity;
                #endif

                const int64_t chunk_size = (num_particles_to_track + num_threads - 1)/num_threads; // ceil division
            #endif // CONTEXT_OPENMP

//            #pragma omp parallel for                                                           //only_for_context cpu_openmp
//            for (int64_t batch_id = 0; batch_id < num_threads; batch_id++) {                   //only_for_context cpu_openmp
                LocalParticle lpart;
                lpart.io_buffer = io_buffer;
                lpart.track_flags = 0;
//                int64_t part_id = batch_id * chunk_size;                                       //only_for_context cpu_openmp
//                int64_t end_id = (batch_id + 1) * chunk_size;                                  //only_for_context cpu_openmp
//                if (end_id > num_particles_to_track) end_id = num_particles_to_track;          //only_for_context cpu_openmp

                int64_t part_id = 0;                    //only_for_context cpu_serial
//                int64_t part_id = blockDim.x * blockIdx.x + threadIdx.x; //only_for_context cuda
//                int64_t part_id = get_global_id(0);                    //only_for_context opencl
                int64_t end_id = 0; // unused outside of openmp  //only_for_context cpu_serial cuda opencl

                int64_t part_capacity = ParticlesData_get__capacity(particles);
                if (part_id<part_capacity){
                    Particles_to_LocalParticle(particles, &lpart, part_id, end_id);
                    if (check_is_active(&lpart)>0){
              RandomNormal_sample(el, &lpart, samples, n_samples_per_seed);

                    }
                    if (check_is_active(&lpart)>0 && flag_increment_at_element){
                            increment_at_element(&lpart, 1);
                    }
                }
//            } //only_for_context cpu_openmp

            // On OpenMP we want to additionally by default reorganize all
            // the particles.
//            #ifndef XT_OMP_SKIP_REORGANIZE                             //only_for_context cpu_openmp
//            LocalParticle lpart;                                       //only_for_context cpu_openmp
//            lpart.io_buffer = io_buffer;                               //only_for_context cpu_openmp
//            Particles_to_LocalParticle(particles, &lpart, 0, capacity);//only_for_context cpu_openmp
//            check_is_active(&lpart);                                   //only_for_context cpu_openmp
//            #endif                                                     //only_for_context cpu_openmp
        }

#ifndef XOBJ_TYPEDEF_RandomRutherfordData
#define XOBJ_TYPEDEF_RandomRutherfordData
typedef   struct RandomRutherfordData_s * RandomRutherfordData;
 static inline RandomRutherfordData RandomRutherfordData_getp(RandomRutherfordData restrict  obj){
  int64_t offset=0;
  return (RandomRutherfordData)(( char*) obj+offset);
}
 static inline double RandomRutherfordData_get_lower_val(const RandomRutherfordData restrict  obj){
  int64_t offset=0;
  return *( double*)(( char*) obj+offset);
}
 static inline void RandomRutherfordData_set_lower_val(RandomRutherfordData restrict  obj, double value){
  int64_t offset=0;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* RandomRutherfordData_getp_lower_val(RandomRutherfordData restrict  obj){
  int64_t offset=0;
  return ( double*)(( char*) obj+offset);
}
 static inline double RandomRutherfordData_get_upper_val(const RandomRutherfordData restrict  obj){
  int64_t offset=0;
  offset+=8;
  return *( double*)(( char*) obj+offset);
}
 static inline void RandomRutherfordData_set_upper_val(RandomRutherfordData restrict  obj, double value){
  int64_t offset=0;
  offset+=8;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* RandomRutherfordData_getp_upper_val(RandomRutherfordData restrict  obj){
  int64_t offset=0;
  offset+=8;
  return ( double*)(( char*) obj+offset);
}
 static inline double RandomRutherfordData_get_A(const RandomRutherfordData restrict  obj){
  int64_t offset=0;
  offset+=16;
  return *( double*)(( char*) obj+offset);
}
 static inline void RandomRutherfordData_set_A(RandomRutherfordData restrict  obj, double value){
  int64_t offset=0;
  offset+=16;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* RandomRutherfordData_getp_A(RandomRutherfordData restrict  obj){
  int64_t offset=0;
  offset+=16;
  return ( double*)(( char*) obj+offset);
}
 static inline double RandomRutherfordData_get_B(const RandomRutherfordData restrict  obj){
  int64_t offset=0;
  offset+=24;
  return *( double*)(( char*) obj+offset);
}
 static inline void RandomRutherfordData_set_B(RandomRutherfordData restrict  obj, double value){
  int64_t offset=0;
  offset+=24;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* RandomRutherfordData_getp_B(RandomRutherfordData restrict  obj){
  int64_t offset=0;
  offset+=24;
  return ( double*)(( char*) obj+offset);
}
 static inline int8_t RandomRutherfordData_get_Newton_iterations(const RandomRutherfordData restrict  obj){
  int64_t offset=0;
  offset+=32;
  return *(( int8_t*) obj+offset);
}
 static inline void RandomRutherfordData_set_Newton_iterations(RandomRutherfordData restrict  obj, int8_t value){
  int64_t offset=0;
  offset+=32;
  *(( int8_t*) obj+offset)=value;
}
 static inline  int8_t* RandomRutherfordData_getp_Newton_iterations(RandomRutherfordData restrict  obj){
  int64_t offset=0;
  offset+=32;
  return ( int8_t*)(( char*) obj+offset);
}
 static inline double RandomRutherfordData_get_shift_x(const RandomRutherfordData restrict  obj){
  int64_t offset=0;
  offset+=40;
  return *( double*)(( char*) obj+offset);
}
 static inline void RandomRutherfordData_set_shift_x(RandomRutherfordData restrict  obj, double value){
  int64_t offset=0;
  offset+=40;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* RandomRutherfordData_getp_shift_x(RandomRutherfordData restrict  obj){
  int64_t offset=0;
  offset+=40;
  return ( double*)(( char*) obj+offset);
}
 static inline double RandomRutherfordData_get_shift_y(const RandomRutherfordData restrict  obj){
  int64_t offset=0;
  offset+=48;
  return *( double*)(( char*) obj+offset);
}
 static inline void RandomRutherfordData_set_shift_y(RandomRutherfordData restrict  obj, double value){
  int64_t offset=0;
  offset+=48;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* RandomRutherfordData_getp_shift_y(RandomRutherfordData restrict  obj){
  int64_t offset=0;
  offset+=48;
  return ( double*)(( char*) obj+offset);
}
 static inline double RandomRutherfordData_get_shift_s(const RandomRutherfordData restrict  obj){
  int64_t offset=0;
  offset+=56;
  return *( double*)(( char*) obj+offset);
}
 static inline void RandomRutherfordData_set_shift_s(RandomRutherfordData restrict  obj, double value){
  int64_t offset=0;
  offset+=56;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* RandomRutherfordData_getp_shift_s(RandomRutherfordData restrict  obj){
  int64_t offset=0;
  offset+=56;
  return ( double*)(( char*) obj+offset);
}
 static inline double RandomRutherfordData_get_rot_s_rad(const RandomRutherfordData restrict  obj){
  int64_t offset=0;
  offset+=64;
  return *( double*)(( char*) obj+offset);
}
 static inline void RandomRutherfordData_set_rot_s_rad(RandomRutherfordData restrict  obj, double value){
  int64_t offset=0;
  offset+=64;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* RandomRutherfordData_getp_rot_s_rad(RandomRutherfordData restrict  obj){
  int64_t offset=0;
  offset+=64;
  return ( double*)(( char*) obj+offset);
}
 static inline double RandomRutherfordData_get_rot_x_rad(const RandomRutherfordData restrict  obj){
  int64_t offset=0;
  offset+=72;
  return *( double*)(( char*) obj+offset);
}
 static inline void RandomRutherfordData_set_rot_x_rad(RandomRutherfordData restrict  obj, double value){
  int64_t offset=0;
  offset+=72;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* RandomRutherfordData_getp_rot_x_rad(RandomRutherfordData restrict  obj){
  int64_t offset=0;
  offset+=72;
  return ( double*)(( char*) obj+offset);
}
 static inline double RandomRutherfordData_get_rot_y_rad(const RandomRutherfordData restrict  obj){
  int64_t offset=0;
  offset+=80;
  return *( double*)(( char*) obj+offset);
}
 static inline void RandomRutherfordData_set_rot_y_rad(RandomRutherfordData restrict  obj, double value){
  int64_t offset=0;
  offset+=80;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* RandomRutherfordData_getp_rot_y_rad(RandomRutherfordData restrict  obj){
  int64_t offset=0;
  offset+=80;
  return ( double*)(( char*) obj+offset);
}
 static inline double RandomRutherfordData_get_rot_s_rad_no_frame(const RandomRutherfordData restrict  obj){
  int64_t offset=0;
  offset+=88;
  return *( double*)(( char*) obj+offset);
}
 static inline void RandomRutherfordData_set_rot_s_rad_no_frame(RandomRutherfordData restrict  obj, double value){
  int64_t offset=0;
  offset+=88;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* RandomRutherfordData_getp_rot_s_rad_no_frame(RandomRutherfordData restrict  obj){
  int64_t offset=0;
  offset+=88;
  return ( double*)(( char*) obj+offset);
}
 static inline double RandomRutherfordData_get_rot_shift_anchor(const RandomRutherfordData restrict  obj){
  int64_t offset=0;
  offset+=96;
  return *( double*)(( char*) obj+offset);
}
 static inline void RandomRutherfordData_set_rot_shift_anchor(RandomRutherfordData restrict  obj, double value){
  int64_t offset=0;
  offset+=96;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* RandomRutherfordData_getp_rot_shift_anchor(RandomRutherfordData restrict  obj){
  int64_t offset=0;
  offset+=96;
  return ( double*)(( char*) obj+offset);
}
#endif
// copyright ############################### //
// This file is part of the Xtrack Package.  //
// Copyright (c) CERN, 2021.                 //
// ######################################### //

#ifndef XTRACK_CONSTANTS_H
#define XTRACK_CONSTANTS_H

#if !defined( C_LIGHT )
    #define   C_LIGHT ( 299792458.0 )
#endif /* !defined( C_LIGHT ) */

#if !defined( EPSILON_0 )
    #define   EPSILON_0 (8.854187817620e-12)
#endif /* !defined( EPSILON_0 ) */

#if !defined( PI )
    #define PI (3.1415926535897932384626433832795028841971693993751)
#endif /* !defined( PI ) */

#if !defined( MU_0 )
    #define MU_0 (PI*4.0e-7)
#endif /* !defined( MU_0 ) */

#if !defined( DEG2RAD )
    #define DEG2RAD (0.0174532925199432957692369076848861271344287188854)
#endif /* !defiend( DEG2RAD ) */

#if !defined( RAD2DEG )
    #define RAD2DEG (57.29577951308232087679815481410517033240547246656442)
#endif /* !defiend( RAD2DEG ) */

#if !defined( SQRT_PI )
    #define SQRT_PI (1.7724538509055160272981674833411451827975494561224)
#endif /* !defined( SQRT_PI ) */

#if !defined( QELEM )
    #define QELEM (1.60217662e-19)
#endif /* !defined( QELEM ) */

#if !defined( DBL_MAX )
    #define DBL_MAX (1.7976931348623158e+308)
#endif /* !defined( DBL_MAX ) */

#if !defined( DBL_MIN )
    #define DBL_MIN (2.2250738585072014e-308)
#endif /* !defined( DBL_MIN ) */

#if !defined( DBL_EPSILON )
    #define DBL_EPSILON (2.2204460492503131e-16)
#endif /* !defined( DBL_EPSILON ) */

#if !defined( RADIUS_ELECTRON )
    #define RADIUS_ELECTRON (2.8179403262e-15)
#endif /* !defined( RADIUS_ELECTRON ) */

#if !defined( MASS_ELECTRON )
    #define MASS_ELECTRON (9.1093837e-31)
#endif /* !defined( MASS_ELECTRON ) */

#if !defined( SQRT3 )
    #define SQRT3 1.732050807568877
#endif /* !defined( SQRT3 ) */

#if !defined( SQRT2 )
    #define SQRT2 (1.414213562373095048801688724209698078569671875376948073176679738)
#endif /* !defined( SQRT2 ) */

#if !defined( TWO_OVER_SQRT_PI )
    #define TWO_OVER_SQRT_PI (1.128379167095512573896158903121545171688101258657997713688171443418)
#endif /* !defined( TWO_OVER_SQRT_PI ) */

#if !defined( ALPHA_EM )
    #define ALPHA_EM 0.0072973525693
#endif /* !defined( ALPHA_EM ) */

#endif /* XTRACK_CONSTANTS_H */

// copyright ############################### //
// This file is part of the Xtrack Package.  //
// Copyright (c) CERN, 2023.                 //
// ######################################### //

#ifndef XTRACK_FUNCTIONS_H
#define XTRACK_FUNCTIONS_H

#include "xtrack/headers/track.h"


GPUFUN
void kill_all_particles(LocalParticle* part0, int64_t kill_state) {
    START_PER_PARTICLE_BLOCK(part0, part);
        LocalParticle_kill_particle(part, kill_state);
    END_PER_PARTICLE_BLOCK;
}


GPUFUN
int8_t assert_tracking(LocalParticle* part, int64_t kill_state){
    // Whenever we are not tracking, e.g. in a twiss, the particle will be at_turn < 0.
    // We test this to distinguish genuine tracking from twiss.
    if (LocalParticle_get_at_turn(part) < 0){
        LocalParticle_kill_particle(part, kill_state);
        return 0;
    }
    return 1;
}

#endif /* XTRACK_FUNCTIONS_H */

// copyright ############################### //
// This file is part of the Xtrack Package.  //
// Copyright (c) CERN, 2023.                 //
// ######################################### //

#ifndef XTRACK_PARTICLE_STATES_H
#define XTRACK_PARTICLE_STATES_H

#define  XT_LOST_ON_APERTURE       0
#define  XT_LOST_ON_LONG_CUT      -2
#define  XT_LOST_ALL_E_IN_SYNRAD -10
#define  RNG_ERR_SEEDS_NOT_SET   -20
#define  RNG_ERR_INVALID_TRACK   -21
#define  RNG_ERR_RUTH_NOT_SET    -22
#define  XT_INVALID_SLICE_TRANSFORM -40
#define  XT_INVALID_CURVED_SLICE_TRANSFORM -41
#define  XT_INVALID_THIN_SLICE_TRANSFORM -42

#endif /* XTRACK_PARTICLE_STATES_H */

// copyright ############################### //
// This file is part of the Xtrack Package.  //
// Copyright (c) CERN, 2025.                 //
// ######################################### //
#ifndef XTRACK_TRACK_SROTATION_H
#define XTRACK_TRACK_SROTATION_H

#include "xtrack/headers/track.h"


GPUFUN
void SRotation_single_particle(LocalParticle* part, double sin_z, double cos_z)
{
    double const x  = LocalParticle_get_x(part);
    double const y  = LocalParticle_get_y(part);
    double const px = LocalParticle_get_px(part);
    double const py = LocalParticle_get_py(part);

    double const x_hat  =  cos_z * x  + sin_z * y;
    double const y_hat  = -sin_z * x  + cos_z * y;
    double const px_hat =  cos_z * px + sin_z * py;
    double const py_hat = -sin_z * px + cos_z * py;

    /* Spin tracking is disabled by the synrad compile flag */
    #ifndef XTRACK_MULTIPOLE_NO_SYNRAD
        // Rotate spin
        double const spin_x_0 = LocalParticle_get_spin_x(part);
        double const spin_y_0 = LocalParticle_get_spin_y(part);
        if ((spin_x_0 != 0) || (spin_y_0 != 0)){
            double const spin_x_1 = cos_z*spin_x_0 + sin_z*spin_y_0;
            double const spin_y_1 = -sin_z*spin_x_0 + cos_z*spin_y_0;
            LocalParticle_set_spin_x(part, spin_x_1);
            LocalParticle_set_spin_y(part, spin_y_1);
        }
    #endif

    LocalParticle_set_x(part, x_hat);
    LocalParticle_set_y(part, y_hat);
    LocalParticle_set_px(part, px_hat);
    LocalParticle_set_py(part, py_hat);
}

#endif
// copyright ############################### //
// This file is part of the Xtrack Package.  //
// Copyright (c) CERN, 2021.                 //
// ######################################### //

#ifndef XTRACK_TRACK_DRIFT_H
#define XTRACK_TRACK_DRIFT_H


GPUFUN
void Drift_single_particle_expanded(LocalParticle* part, double length){
    double const rpp    = LocalParticle_get_rpp(part);
    double const rv0v    = 1./LocalParticle_get_rvv(part);
    double const xp     = LocalParticle_get_px(part) * rpp;
    double const yp     = LocalParticle_get_py(part) * rpp;
    double const dzeta  = 1 - rv0v * ( 1. + ( xp*xp + yp*yp ) / 2. );

    LocalParticle_add_to_x(part, xp * length );
    LocalParticle_add_to_y(part, yp * length );
    LocalParticle_add_to_s(part, length);
    LocalParticle_add_to_zeta(part, length * dzeta );
}


GPUFUN
void Drift_single_particle_exact(LocalParticle* part, double length){
    double const px = LocalParticle_get_px(part);
    double const py = LocalParticle_get_py(part);
    double const rv0v    = 1./LocalParticle_get_rvv(part);
    double const one_plus_delta = 1. + LocalParticle_get_delta(part);

    double const one_over_pz = 1./sqrt(one_plus_delta*one_plus_delta
                                       - px * px - py * py);
    double const dzeta = 1 - rv0v * one_plus_delta * one_over_pz;

    LocalParticle_add_to_x(part, px * one_over_pz * length);
    LocalParticle_add_to_y(part, py * one_over_pz * length);
    LocalParticle_add_to_zeta(part, dzeta * length);
    LocalParticle_add_to_s(part, length);
}


GPUFUN
void Drift_single_particle(LocalParticle* part, double length){
    #ifndef XTRACK_USE_EXACT_DRIFTS
        Drift_single_particle_expanded(part, length);
    #else
        Drift_single_particle_exact(part, length);
    #endif
}


#endif /* XTRACK_TRACK_DRIFT_H */


#ifndef XSUITE_TRACK_FLAGS_H
#define XSUITE_TRACK_FLAGS_H
#define XS_FLAG_BACKTRACK (0)
#define XS_FLAG_KILL_CAVITY_KICK (2)
#define XS_FLAG_IGNORE_GLOBAL_APERTURE (3)
#define XS_FLAG_IGNORE_LOCAL_APERTURE (4)
#define XS_FLAG_SR_TAPER (5)
#define XS_FLAG_SR_KICK_SAME_AS_FIRST (6)

#endif // XSUITE_TRACK_FLAGS_H

#include "xtrack/random/random_src/rutherford.h"

             
            void sample_ruth(
               RandomRutherfordData el,

                             ParticlesData particles,
    double* samples,  int64_t n_samples_per_seed, 
                             int64_t flag_increment_at_element,
                  int8_t* io_buffer){

//            #define CONTEXT_OPENMP  //only_for_context cpu_openmp
            #ifdef CONTEXT_OPENMP
                const int64_t capacity = ParticlesData_get__capacity(particles);
                const int num_threads = omp_get_max_threads();

                #ifndef XT_OMP_SKIP_REORGANIZE
                    const int64_t num_particles_to_track = ParticlesData_get__num_active_particles(particles);

                    {
                        LocalParticle lpart;
                        lpart.io_buffer = io_buffer;
                        Particles_to_LocalParticle(particles, &lpart, 0, capacity);
                        check_is_active(&lpart);
                        count_reorganized_particles(&lpart);
                        LocalParticle_to_Particles(&lpart, particles, 0, capacity);
                    }
                #else // When we skip reorganize, we cannot just batch active particles
                    const int64_t num_particles_to_track = capacity;
                #endif

                const int64_t chunk_size = (num_particles_to_track + num_threads - 1)/num_threads; // ceil division
            #endif // CONTEXT_OPENMP

//            #pragma omp parallel for                                                           //only_for_context cpu_openmp
//            for (int64_t batch_id = 0; batch_id < num_threads; batch_id++) {                   //only_for_context cpu_openmp
                LocalParticle lpart;
                lpart.io_buffer = io_buffer;
                lpart.track_flags = 0;
//                int64_t part_id = batch_id * chunk_size;                                       //only_for_context cpu_openmp
//                int64_t end_id = (batch_id + 1) * chunk_size;                                  //only_for_context cpu_openmp
//                if (end_id > num_particles_to_track) end_id = num_particles_to_track;          //only_for_context cpu_openmp

                int64_t part_id = 0;                    //only_for_context cpu_serial
//                int64_t part_id = blockDim.x * blockIdx.x + threadIdx.x; //only_for_context cuda
//                int64_t part_id = get_global_id(0);                    //only_for_context opencl
                int64_t end_id = 0; // unused outside of openmp  //only_for_context cpu_serial cuda opencl

                int64_t part_capacity = ParticlesData_get__capacity(particles);
                if (part_id<part_capacity){
                    Particles_to_LocalParticle(particles, &lpart, part_id, end_id);
                    if (check_is_active(&lpart)>0){
              RandomRutherford_sample(el, &lpart, samples, n_samples_per_seed);

                    }
                    if (check_is_active(&lpart)>0 && flag_increment_at_element){
                            increment_at_element(&lpart, 1);
                    }
                }
//            } //only_for_context cpu_openmp

            // On OpenMP we want to additionally by default reorganize all
            // the particles.
//            #ifndef XT_OMP_SKIP_REORGANIZE                             //only_for_context cpu_openmp
//            LocalParticle lpart;                                       //only_for_context cpu_openmp
//            lpart.io_buffer = io_buffer;                               //only_for_context cpu_openmp
//            Particles_to_LocalParticle(particles, &lpart, 0, capacity);//only_for_context cpu_openmp
//            check_is_active(&lpart);                                   //only_for_context cpu_openmp
//            #endif                                                     //only_for_context cpu_openmp
        }

#ifndef XOBJ_TYPEDEF_RandomExponentialData
#define XOBJ_TYPEDEF_RandomExponentialData
typedef   struct RandomExponentialData_s * RandomExponentialData;
 static inline RandomExponentialData RandomExponentialData_getp(RandomExponentialData restrict  obj){
  int64_t offset=0;
  return (RandomExponentialData)(( char*) obj+offset);
}
 static inline uint8_t RandomExponentialData_get__dummy(const RandomExponentialData restrict  obj){
  int64_t offset=0;
  return *(( uint8_t*) obj+offset);
}
 static inline void RandomExponentialData_set__dummy(RandomExponentialData restrict  obj, uint8_t value){
  int64_t offset=0;
  *(( uint8_t*) obj+offset)=value;
}
 static inline  uint8_t* RandomExponentialData_getp__dummy(RandomExponentialData restrict  obj){
  int64_t offset=0;
  return ( uint8_t*)(( char*) obj+offset);
}
 static inline double RandomExponentialData_get_shift_x(const RandomExponentialData restrict  obj){
  int64_t offset=0;
  offset+=8;
  return *( double*)(( char*) obj+offset);
}
 static inline void RandomExponentialData_set_shift_x(RandomExponentialData restrict  obj, double value){
  int64_t offset=0;
  offset+=8;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* RandomExponentialData_getp_shift_x(RandomExponentialData restrict  obj){
  int64_t offset=0;
  offset+=8;
  return ( double*)(( char*) obj+offset);
}
 static inline double RandomExponentialData_get_shift_y(const RandomExponentialData restrict  obj){
  int64_t offset=0;
  offset+=16;
  return *( double*)(( char*) obj+offset);
}
 static inline void RandomExponentialData_set_shift_y(RandomExponentialData restrict  obj, double value){
  int64_t offset=0;
  offset+=16;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* RandomExponentialData_getp_shift_y(RandomExponentialData restrict  obj){
  int64_t offset=0;
  offset+=16;
  return ( double*)(( char*) obj+offset);
}
 static inline double RandomExponentialData_get_shift_s(const RandomExponentialData restrict  obj){
  int64_t offset=0;
  offset+=24;
  return *( double*)(( char*) obj+offset);
}
 static inline void RandomExponentialData_set_shift_s(RandomExponentialData restrict  obj, double value){
  int64_t offset=0;
  offset+=24;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* RandomExponentialData_getp_shift_s(RandomExponentialData restrict  obj){
  int64_t offset=0;
  offset+=24;
  return ( double*)(( char*) obj+offset);
}
 static inline double RandomExponentialData_get_rot_s_rad(const RandomExponentialData restrict  obj){
  int64_t offset=0;
  offset+=32;
  return *( double*)(( char*) obj+offset);
}
 static inline void RandomExponentialData_set_rot_s_rad(RandomExponentialData restrict  obj, double value){
  int64_t offset=0;
  offset+=32;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* RandomExponentialData_getp_rot_s_rad(RandomExponentialData restrict  obj){
  int64_t offset=0;
  offset+=32;
  return ( double*)(( char*) obj+offset);
}
 static inline double RandomExponentialData_get_rot_x_rad(const RandomExponentialData restrict  obj){
  int64_t offset=0;
  offset+=40;
  return *( double*)(( char*) obj+offset);
}
 static inline void RandomExponentialData_set_rot_x_rad(RandomExponentialData restrict  obj, double value){
  int64_t offset=0;
  offset+=40;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* RandomExponentialData_getp_rot_x_rad(RandomExponentialData restrict  obj){
  int64_t offset=0;
  offset+=40;
  return ( double*)(( char*) obj+offset);
}
 static inline double RandomExponentialData_get_rot_y_rad(const RandomExponentialData restrict  obj){
  int64_t offset=0;
  offset+=48;
  return *( double*)(( char*) obj+offset);
}
 static inline void RandomExponentialData_set_rot_y_rad(RandomExponentialData restrict  obj, double value){
  int64_t offset=0;
  offset+=48;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* RandomExponentialData_getp_rot_y_rad(RandomExponentialData restrict  obj){
  int64_t offset=0;
  offset+=48;
  return ( double*)(( char*) obj+offset);
}
 static inline double RandomExponentialData_get_rot_s_rad_no_frame(const RandomExponentialData restrict  obj){
  int64_t offset=0;
  offset+=56;
  return *( double*)(( char*) obj+offset);
}
 static inline void RandomExponentialData_set_rot_s_rad_no_frame(RandomExponentialData restrict  obj, double value){
  int64_t offset=0;
  offset+=56;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* RandomExponentialData_getp_rot_s_rad_no_frame(RandomExponentialData restrict  obj){
  int64_t offset=0;
  offset+=56;
  return ( double*)(( char*) obj+offset);
}
 static inline double RandomExponentialData_get_rot_shift_anchor(const RandomExponentialData restrict  obj){
  int64_t offset=0;
  offset+=64;
  return *( double*)(( char*) obj+offset);
}
 static inline void RandomExponentialData_set_rot_shift_anchor(RandomExponentialData restrict  obj, double value){
  int64_t offset=0;
  offset+=64;
  *( double*)(( char*) obj+offset)=value;
}
 static inline  double* RandomExponentialData_getp_rot_shift_anchor(RandomExponentialData restrict  obj){
  int64_t offset=0;
  offset+=64;
  return ( double*)(( char*) obj+offset);
}
#endif
// copyright ############################### //
// This file is part of the Xtrack Package.  //
// Copyright (c) CERN, 2021.                 //
// ######################################### //

#ifndef XTRACK_CONSTANTS_H
#define XTRACK_CONSTANTS_H

#if !defined( C_LIGHT )
    #define   C_LIGHT ( 299792458.0 )
#endif /* !defined( C_LIGHT ) */

#if !defined( EPSILON_0 )
    #define   EPSILON_0 (8.854187817620e-12)
#endif /* !defined( EPSILON_0 ) */

#if !defined( PI )
    #define PI (3.1415926535897932384626433832795028841971693993751)
#endif /* !defined( PI ) */

#if !defined( MU_0 )
    #define MU_0 (PI*4.0e-7)
#endif /* !defined( MU_0 ) */

#if !defined( DEG2RAD )
    #define DEG2RAD (0.0174532925199432957692369076848861271344287188854)
#endif /* !defiend( DEG2RAD ) */

#if !defined( RAD2DEG )
    #define RAD2DEG (57.29577951308232087679815481410517033240547246656442)
#endif /* !defiend( RAD2DEG ) */

#if !defined( SQRT_PI )
    #define SQRT_PI (1.7724538509055160272981674833411451827975494561224)
#endif /* !defined( SQRT_PI ) */

#if !defined( QELEM )
    #define QELEM (1.60217662e-19)
#endif /* !defined( QELEM ) */

#if !defined( DBL_MAX )
    #define DBL_MAX (1.7976931348623158e+308)
#endif /* !defined( DBL_MAX ) */

#if !defined( DBL_MIN )
    #define DBL_MIN (2.2250738585072014e-308)
#endif /* !defined( DBL_MIN ) */

#if !defined( DBL_EPSILON )
    #define DBL_EPSILON (2.2204460492503131e-16)
#endif /* !defined( DBL_EPSILON ) */

#if !defined( RADIUS_ELECTRON )
    #define RADIUS_ELECTRON (2.8179403262e-15)
#endif /* !defined( RADIUS_ELECTRON ) */

#if !defined( MASS_ELECTRON )
    #define MASS_ELECTRON (9.1093837e-31)
#endif /* !defined( MASS_ELECTRON ) */

#if !defined( SQRT3 )
    #define SQRT3 1.732050807568877
#endif /* !defined( SQRT3 ) */

#if !defined( SQRT2 )
    #define SQRT2 (1.414213562373095048801688724209698078569671875376948073176679738)
#endif /* !defined( SQRT2 ) */

#if !defined( TWO_OVER_SQRT_PI )
    #define TWO_OVER_SQRT_PI (1.128379167095512573896158903121545171688101258657997713688171443418)
#endif /* !defined( TWO_OVER_SQRT_PI ) */

#if !defined( ALPHA_EM )
    #define ALPHA_EM 0.0072973525693
#endif /* !defined( ALPHA_EM ) */

#endif /* XTRACK_CONSTANTS_H */

// copyright ############################### //
// This file is part of the Xtrack Package.  //
// Copyright (c) CERN, 2023.                 //
// ######################################### //

#ifndef XTRACK_FUNCTIONS_H
#define XTRACK_FUNCTIONS_H

#include "xtrack/headers/track.h"


GPUFUN
void kill_all_particles(LocalParticle* part0, int64_t kill_state) {
    START_PER_PARTICLE_BLOCK(part0, part);
        LocalParticle_kill_particle(part, kill_state);
    END_PER_PARTICLE_BLOCK;
}


GPUFUN
int8_t assert_tracking(LocalParticle* part, int64_t kill_state){
    // Whenever we are not tracking, e.g. in a twiss, the particle will be at_turn < 0.
    // We test this to distinguish genuine tracking from twiss.
    if (LocalParticle_get_at_turn(part) < 0){
        LocalParticle_kill_particle(part, kill_state);
        return 0;
    }
    return 1;
}

#endif /* XTRACK_FUNCTIONS_H */

// copyright ############################### //
// This file is part of the Xtrack Package.  //
// Copyright (c) CERN, 2023.                 //
// ######################################### //

#ifndef XTRACK_PARTICLE_STATES_H
#define XTRACK_PARTICLE_STATES_H

#define  XT_LOST_ON_APERTURE       0
#define  XT_LOST_ON_LONG_CUT      -2
#define  XT_LOST_ALL_E_IN_SYNRAD -10
#define  RNG_ERR_SEEDS_NOT_SET   -20
#define  RNG_ERR_INVALID_TRACK   -21
#define  RNG_ERR_RUTH_NOT_SET    -22
#define  XT_INVALID_SLICE_TRANSFORM -40
#define  XT_INVALID_CURVED_SLICE_TRANSFORM -41
#define  XT_INVALID_THIN_SLICE_TRANSFORM -42

#endif /* XTRACK_PARTICLE_STATES_H */

// copyright ############################### //
// This file is part of the Xtrack Package.  //
// Copyright (c) CERN, 2025.                 //
// ######################################### //
#ifndef XTRACK_TRACK_SROTATION_H
#define XTRACK_TRACK_SROTATION_H

#include "xtrack/headers/track.h"


GPUFUN
void SRotation_single_particle(LocalParticle* part, double sin_z, double cos_z)
{
    double const x  = LocalParticle_get_x(part);
    double const y  = LocalParticle_get_y(part);
    double const px = LocalParticle_get_px(part);
    double const py = LocalParticle_get_py(part);

    double const x_hat  =  cos_z * x  + sin_z * y;
    double const y_hat  = -sin_z * x  + cos_z * y;
    double const px_hat =  cos_z * px + sin_z * py;
    double const py_hat = -sin_z * px + cos_z * py;

    /* Spin tracking is disabled by the synrad compile flag */
    #ifndef XTRACK_MULTIPOLE_NO_SYNRAD
        // Rotate spin
        double const spin_x_0 = LocalParticle_get_spin_x(part);
        double const spin_y_0 = LocalParticle_get_spin_y(part);
        if ((spin_x_0 != 0) || (spin_y_0 != 0)){
            double const spin_x_1 = cos_z*spin_x_0 + sin_z*spin_y_0;
            double const spin_y_1 = -sin_z*spin_x_0 + cos_z*spin_y_0;
            LocalParticle_set_spin_x(part, spin_x_1);
            LocalParticle_set_spin_y(part, spin_y_1);
        }
    #endif

    LocalParticle_set_x(part, x_hat);
    LocalParticle_set_y(part, y_hat);
    LocalParticle_set_px(part, px_hat);
    LocalParticle_set_py(part, py_hat);
}

#endif
// copyright ############################### //
// This file is part of the Xtrack Package.  //
// Copyright (c) CERN, 2021.                 //
// ######################################### //

#ifndef XTRACK_TRACK_DRIFT_H
#define XTRACK_TRACK_DRIFT_H


GPUFUN
void Drift_single_particle_expanded(LocalParticle* part, double length){
    double const rpp    = LocalParticle_get_rpp(part);
    double const rv0v    = 1./LocalParticle_get_rvv(part);
    double const xp     = LocalParticle_get_px(part) * rpp;
    double const yp     = LocalParticle_get_py(part) * rpp;
    double const dzeta  = 1 - rv0v * ( 1. + ( xp*xp + yp*yp ) / 2. );

    LocalParticle_add_to_x(part, xp * length );
    LocalParticle_add_to_y(part, yp * length );
    LocalParticle_add_to_s(part, length);
    LocalParticle_add_to_zeta(part, length * dzeta );
}


GPUFUN
void Drift_single_particle_exact(LocalParticle* part, double length){
    double const px = LocalParticle_get_px(part);
    double const py = LocalParticle_get_py(part);
    double const rv0v    = 1./LocalParticle_get_rvv(part);
    double const one_plus_delta = 1. + LocalParticle_get_delta(part);

    double const one_over_pz = 1./sqrt(one_plus_delta*one_plus_delta
                                       - px * px - py * py);
    double const dzeta = 1 - rv0v * one_plus_delta * one_over_pz;

    LocalParticle_add_to_x(part, px * one_over_pz * length);
    LocalParticle_add_to_y(part, py * one_over_pz * length);
    LocalParticle_add_to_zeta(part, dzeta * length);
    LocalParticle_add_to_s(part, length);
}


GPUFUN
void Drift_single_particle(LocalParticle* part, double length){
    #ifndef XTRACK_USE_EXACT_DRIFTS
        Drift_single_particle_expanded(part, length);
    #else
        Drift_single_particle_exact(part, length);
    #endif
}


#endif /* XTRACK_TRACK_DRIFT_H */


#ifndef XSUITE_TRACK_FLAGS_H
#define XSUITE_TRACK_FLAGS_H
#define XS_FLAG_BACKTRACK (0)
#define XS_FLAG_KILL_CAVITY_KICK (2)
#define XS_FLAG_IGNORE_GLOBAL_APERTURE (3)
#define XS_FLAG_IGNORE_LOCAL_APERTURE (4)
#define XS_FLAG_SR_TAPER (5)
#define XS_FLAG_SR_KICK_SAME_AS_FIRST (6)

#endif // XSUITE_TRACK_FLAGS_H

#include "xtrack/random/random_src/exponential.h"

             
            void sample_exp(
               RandomExponentialData el,

                             ParticlesData particles,
    double* samples,  int64_t n_samples_per_seed, 
                             int64_t flag_increment_at_element,
                  int8_t* io_buffer){

//            #define CONTEXT_OPENMP  //only_for_context cpu_openmp
            #ifdef CONTEXT_OPENMP
                const int64_t capacity = ParticlesData_get__capacity(particles);
                const int num_threads = omp_get_max_threads();

                #ifndef XT_OMP_SKIP_REORGANIZE
                    const int64_t num_particles_to_track = ParticlesData_get__num_active_particles(particles);

                    {
                        LocalParticle lpart;
                        lpart.io_buffer = io_buffer;
                        Particles_to_LocalParticle(particles, &lpart, 0, capacity);
                        check_is_active(&lpart);
                        count_reorganized_particles(&lpart);
                        LocalParticle_to_Particles(&lpart, particles, 0, capacity);
                    }
                #else // When we skip reorganize, we cannot just batch active particles
                    const int64_t num_particles_to_track = capacity;
                #endif

                const int64_t chunk_size = (num_particles_to_track + num_threads - 1)/num_threads; // ceil division
            #endif // CONTEXT_OPENMP

//            #pragma omp parallel for                                                           //only_for_context cpu_openmp
//            for (int64_t batch_id = 0; batch_id < num_threads; batch_id++) {                   //only_for_context cpu_openmp
                LocalParticle lpart;
                lpart.io_buffer = io_buffer;
                lpart.track_flags = 0;
//                int64_t part_id = batch_id * chunk_size;                                       //only_for_context cpu_openmp
//                int64_t end_id = (batch_id + 1) * chunk_size;                                  //only_for_context cpu_openmp
//                if (end_id > num_particles_to_track) end_id = num_particles_to_track;          //only_for_context cpu_openmp

                int64_t part_id = 0;                    //only_for_context cpu_serial
//                int64_t part_id = blockDim.x * blockIdx.x + threadIdx.x; //only_for_context cuda
//                int64_t part_id = get_global_id(0);                    //only_for_context opencl
                int64_t end_id = 0; // unused outside of openmp  //only_for_context cpu_serial cuda opencl

                int64_t part_capacity = ParticlesData_get__capacity(particles);
                if (part_id<part_capacity){
                    Particles_to_LocalParticle(particles, &lpart, part_id, end_id);
                    if (check_is_active(&lpart)>0){
              RandomExponential_sample(el, &lpart, samples, n_samples_per_seed);

                    }
                    if (check_is_active(&lpart)>0 && flag_increment_at_element){
                            increment_at_element(&lpart, 1);
                    }
                }
//            } //only_for_context cpu_openmp

            // On OpenMP we want to additionally by default reorganize all
            // the particles.
//            #ifndef XT_OMP_SKIP_REORGANIZE                             //only_for_context cpu_openmp
//            LocalParticle lpart;                                       //only_for_context cpu_openmp
//            lpart.io_buffer = io_buffer;                               //only_for_context cpu_openmp
//            Particles_to_LocalParticle(particles, &lpart, 0, capacity);//only_for_context cpu_openmp
//            check_is_active(&lpart);                                   //only_for_context cpu_openmp
//            #endif                                                     //only_for_context cpu_openmp
        }

#ifndef XOBJ_TYPEDEF_ElementRefClass
#define XOBJ_TYPEDEF_ElementRefClass
typedef   struct ElementRefClass_s * ElementRefClass;
enum ElementRefClass_e{ElementRefClass_MultiElementMonitorData_t,ElementRefClass_ParticlesMonitorData_t};
 static inline ElementRefClass ElementRefClass_getp(ElementRefClass restrict  obj){
  int64_t offset=0;
  return (ElementRefClass)(( char*) obj+offset);
}
 static inline int64_t ElementRefClass_typeid(const ElementRefClass restrict  obj){
  int64_t offset=0;
  offset+=8;
  return *( int64_t*)(( char*) obj+offset);
}
 static inline  void* ElementRefClass_member(const ElementRefClass restrict  obj){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset);
 return ( void*)(( char*) obj+offset);
}
#endif
#ifndef XOBJ_TYPEDEF_ArrNElementRefClass
#define XOBJ_TYPEDEF_ArrNElementRefClass
typedef   struct ArrNElementRefClass_s * ArrNElementRefClass;
 static inline ArrNElementRefClass ArrNElementRefClass_getp(ArrNElementRefClass restrict  obj){
  int64_t offset=0;
  return (ArrNElementRefClass)(( char*) obj+offset);
}
 static inline int64_t ArrNElementRefClass_len(ArrNElementRefClass restrict  obj){
  int64_t offset=0;
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  return arr[1];
}
 static inline void ArrNElementRefClass_shape(ArrNElementRefClass restrict  obj,  int64_t* restrict  out_shape){
  int64_t offset=0;
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  out_shape[0] = arr[1];
}
 static inline uint32_t ArrNElementRefClass_nd(ArrNElementRefClass restrict  obj){
  return 1;
}
 static inline ElementRefClass ArrNElementRefClass_getp1(ArrNElementRefClass restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=16+i0*16;
  return (ElementRefClass)(( char*) obj+offset);
}
 static inline int64_t ArrNElementRefClass_typeid(const ArrNElementRefClass restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=16+i0*16;
  offset+=8;
  return *( int64_t*)(( char*) obj+offset);
}
 static inline  void* ArrNElementRefClass_member(const ArrNElementRefClass restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=16+i0*16;
  offset+=*( int64_t*)(( char*) obj+offset);
 return ( void*)(( char*) obj+offset);
}
#endif
#ifndef XOBJ_TYPEDEF_ElementRefData
#define XOBJ_TYPEDEF_ElementRefData
typedef   struct ElementRefData_s * ElementRefData;
 static inline ElementRefData ElementRefData_getp(ElementRefData restrict  obj){
  int64_t offset=0;
  return (ElementRefData)(( char*) obj+offset);
}
 static inline ArrNElementRefClass ElementRefData_getp_elements(ElementRefData restrict  obj){
  int64_t offset=0;
  offset+=16;
  return (ArrNElementRefClass)(( char*) obj+offset);
}
 static inline int64_t ElementRefData_len_elements(ElementRefData restrict  obj){
  int64_t offset=0;
  offset+=16;
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  return arr[1];
}
 static inline void ElementRefData_shape_elements(ElementRefData restrict  obj,  int64_t* restrict  out_shape){
  int64_t offset=0;
  offset+=16;
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  out_shape[0] = arr[1];
}
 static inline uint32_t ElementRefData_nd_elements(ElementRefData restrict  obj){
  return 1;
}
 static inline ElementRefClass ElementRefData_getp1_elements(ElementRefData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=16;
  offset+=16+i0*16;
  return (ElementRefClass)(( char*) obj+offset);
}
 static inline int64_t ElementRefData_typeid_elements(const ElementRefData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=16;
  offset+=16+i0*16;
  offset+=8;
  return *( int64_t*)(( char*) obj+offset);
}
 static inline  void* ElementRefData_member_elements(const ElementRefData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=16;
  offset+=16+i0*16;
  offset+=*( int64_t*)(( char*) obj+offset);
 return ( void*)(( char*) obj+offset);
}
 static inline ArrNString ElementRefData_getp_names(ElementRefData restrict  obj){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+8);
  return (ArrNString)(( char*) obj+offset);
}
 static inline int64_t ElementRefData_len_names(ElementRefData restrict  obj){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+8);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  return arr[1];
}
 static inline void ElementRefData_shape_names(ElementRefData restrict  obj,  int64_t* restrict  out_shape){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+8);
   int64_t* arr = ( int64_t*)(( char*) obj+offset);
  out_shape[0] = arr[1];
}
 static inline uint32_t ElementRefData_nd_names(ElementRefData restrict  obj){
  return 1;
}
 static inline  char* ElementRefData_getp1_names(ElementRefData restrict  obj, int64_t i0){
  int64_t offset=0;
  offset+=*( int64_t*)(( char*) obj+offset+8);
  offset+=*( int64_t*)(( char*) obj+offset+16+i0*8);
  return ( char*)(( char*) obj+offset);
}
#endif

             
            void track_line(
                  int8_t* buffer,
                             ElementRefData elem_ref_data,
                             ParticlesData particles,
                             int num_turns,
                             int ele_start,
                             int num_ele_track,
                             int flag_end_turn_actions,
                             int flag_reset_s_at_end_turn,
                             int flag_monitor,
                             int num_ele_line,
                             double line_length,
                  int8_t* buffer_tbt_monitor,
                             int64_t offset_tbt_monitor,
                  int8_t* buffer_multi_element_monitor,
                             int64_t offset_multi_element_monitor,
                  int8_t* io_buffer,
                             uint64_t track_flags
                             ){

//            #define CONTEXT_OPENMP  //only_for_context cpu_openmp
            #ifdef CONTEXT_OPENMP
                const int64_t capacity = ParticlesData_get__capacity(particles);
                const int num_threads = omp_get_max_threads();

                #ifndef XT_OMP_SKIP_REORGANIZE
                    const int64_t num_particles_to_track = ParticlesData_get__num_active_particles(particles);

                    {
                        LocalParticle lpart;
                        lpart.io_buffer = io_buffer;
                        Particles_to_LocalParticle(particles, &lpart, 0, capacity);
                        check_is_active(&lpart);
                        count_reorganized_particles(&lpart);
                        LocalParticle_to_Particles(&lpart, particles, 0, capacity);
                    }
                #else // When we skip reorganize, we cannot just batch active particles
                    const int64_t num_particles_to_track = capacity;
                #endif

                const int64_t chunk_size = (num_particles_to_track + num_threads - 1)/num_threads; // ceil division
            #endif // CONTEXT_OPENMP

//            #pragma omp parallel for                                                           //only_for_context cpu_openmp
//            for (int chunk = 0; chunk < num_threads; chunk++) {                                //only_for_context cpu_openmp
//            int64_t part_id = chunk * chunk_size;                                              //only_for_context cpu_openmp
//            int64_t end_id = (chunk + 1) * chunk_size;                                         //only_for_context cpu_openmp
//            if (end_id > num_particles_to_track) end_id = num_particles_to_track;              //only_for_context cpu_openmp

            int64_t part_id = 0;                                      //only_for_context cpu_serial
//            int64_t part_id = blockDim.x * blockIdx.x + threadIdx.x;  //only_for_context cuda
//            int64_t part_id = get_global_id(0);                       //only_for_context opencl
            int64_t end_id = 0; // unused outside of openmp           //only_for_context cpu_serial cuda opencl

            LocalParticle lpart;
            lpart.io_buffer = io_buffer;
            lpart.track_flags = track_flags;
            lpart.line_length = line_length;

              int8_t* tbt_mon_pointer =
                            buffer_tbt_monitor + offset_tbt_monitor;
            ParticlesMonitorData tbt_monitor =
                            (ParticlesMonitorData) tbt_mon_pointer;

              int8_t* multi_elem_mon_pointer =
                    buffer_multi_element_monitor + offset_multi_element_monitor;
            MultiElementMonitorData tbt_multi_elem_monitor =
                    (MultiElementMonitorData) multi_elem_mon_pointer;

            int64_t part_capacity = ParticlesData_get__capacity(particles);
            if (part_id<part_capacity){
            Particles_to_LocalParticle(particles, &lpart, part_id, end_id);

            int64_t isactive = check_is_active(&lpart);

            for (int64_t iturn=0; iturn<num_turns; iturn++){

                if (!isactive){
                    break;
                }

                int64_t const ele_stop = ele_start + num_ele_track;

                int64_t elem_idx, increm;
                if (LocalParticle_check_track_flag(&lpart, XS_FLAG_BACKTRACK)) {
                    elem_idx = ele_stop - 1;
                    increm = -1;
                    if (flag_end_turn_actions>0){
                        increment_at_turn_backtrack(&lpart, flag_reset_s_at_end_turn,
                                                    line_length, num_ele_line);
                    }
                }
                else{
                    if (flag_monitor==1){
                        ParticlesMonitor_track_local_particle(tbt_monitor, &lpart);
                    }
                    elem_idx = ele_start;
                    increm = 1;
                }

                for (; ((elem_idx >= ele_start) && (elem_idx < ele_stop)); elem_idx+=increm){
                        if (flag_monitor==2){
                            ParticlesMonitor_track_local_particle(tbt_monitor, &lpart);
                        }
                        if (offset_multi_element_monitor >= 0){
                            MultiElementMonitor_track_local_particle(
                                tbt_multi_elem_monitor, &lpart);
                        }

                        // Get the pointer to and the type id of the `elem_idx`th
                        // element in `element_ref_data.elements`:
                          void* el = ElementRefData_member_elements(elem_ref_data, elem_idx);
                        int64_t elem_type = ElementRefData_typeid_elements(elem_ref_data, elem_idx);

                        switch(elem_type){
        

                        case 0:


                            MultiElementMonitor_track_local_particle_with_transformations((MultiElementMonitorData) el, &lpart);
                            break;

                        case 1:


                            ParticlesMonitor_track_local_particle_with_transformations((ParticlesMonitorData) el, &lpart);
                            break;

                        } //switch

                    // Setting the below flag will break particle losses
                    #ifndef DANGER_SKIP_ACTIVE_CHECK_AND_SWAPS

                    isactive = check_is_active(&lpart);
                    if (!isactive){
                        break;
                    }

                    if (LocalParticle_check_track_flag(&lpart, XS_FLAG_BACKTRACK)) {
                        increment_at_element(&lpart, -1);
                    } else {
                        increment_at_element(&lpart, 1);
                    }

                    #endif //DANGER_SKIP_ACTIVE_CHECK_AND_SWAPS

                } // for elements

                if (flag_monitor==2){
                    // End of turn (element-by-element mode)
                    ParticlesMonitor_track_local_particle(tbt_monitor, &lpart);
                }

                if (LocalParticle_check_track_flag(&lpart, XS_FLAG_BACKTRACK)) {
                    if (flag_monitor==1){
                        ParticlesMonitor_track_local_particle(tbt_monitor, &lpart);
                    }
                }
                else if (flag_end_turn_actions>0){
                    if (isactive){
                        increment_at_turn(&lpart, flag_reset_s_at_end_turn);
                    }
                }
            } // for turns

            LocalParticle_to_Particles(&lpart, particles, part_id, 1);

            }// if partid
//            } //only_for_context cpu_openmp

            // On OpenMP we want to additionally by default reorganize all
            // the particles.
//            #ifndef XT_OMP_SKIP_REORGANIZE                             //only_for_context cpu_openmp
//            LocalParticle lpart;                                       //only_for_context cpu_openmp
//            lpart.io_buffer = io_buffer;                               //only_for_context cpu_openmp
//            Particles_to_LocalParticle(particles, &lpart, 0, capacity);//only_for_context cpu_openmp
//            check_is_active(&lpart);                                   //only_for_context cpu_openmp
//            count_reorganized_particles(&lpart);                       //only_for_context cpu_openmp
//            LocalParticle_to_Particles(&lpart, particles, 0, capacity);//only_for_context cpu_openmp
//            #endif                                                     //only_for_context cpu_openmp
        }//kernel
        