# ClawTex — Governed Agent with Genetic Memory
# Built by DeVere Cooley / AN2B LLC · an2b.com
# BB4C — Breath Before Code

"""ClawTex channel adapters — Telegram, Slack, and base interface."""

from .base import BaseChannel, InboundMessage, MessageHandler, OutboundMessage
from .telegram import TelegramChannel
from .slack import SlackChannel

__all__ = [
    "BaseChannel",
    "InboundMessage",
    "OutboundMessage",
    "MessageHandler",
    "TelegramChannel",
    "SlackChannel",
]
