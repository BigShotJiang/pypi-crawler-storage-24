# CHANGELOG

<!-- version list -->

## v2.0.1 (2026-03-15)

### Bug Fixes

- Auto-build frontend when `tribal ui` static assets are missing
  ([`d9ecbc2`](https://github.com/zachary-nguyen/TribalMind/commit/d9ecbc2d1c94b84e33cbb308a4e1600aa12b36b8))

- Use shell=True on Windows for subprocess calls to pnpm/npm
  ([`08d96de`](https://github.com/zachary-nguyen/TribalMind/commit/08d96de2e87854b7431dabb673ec7b6546c2018d))


## v2.0.0 (2026-03-15)

### Bug Fixes

- Mock set_credential in test_init_api_error for CI
  ([`44847d0`](https://github.com/zachary-nguyen/TribalMind/commit/44847d06f339b01c2faf4d8f2aaedceee9727693))

### Features

- V2.0 stateless CLI architecture
  ([`1da1cb0`](https://github.com/zachary-nguyen/TribalMind/commit/1da1cb01738fd69d2cfcb7a5db20d6060f8ae54c))

### Breaking Changes

- Removed daemon, graph, hooks, upstream modules and all associated CLI commands. The CLI is now
  stateless — use `tribal remember` / `tribal recall` instead of the background agent.


## v1.6.0 (2026-03-15)

### Features

- V2.0.0 — stateless CLI architecture
  ([`62dcd74`](https://github.com/zachary-nguyen/TribalMind/commit/62dcd74540f3360861190e73474031b1b2908b70))


## v1.5.0 (2026-03-14)

### Features

- Update README and enhance CLI aesthetics
  ([`59507a8`](https://github.com/zachary-nguyen/TribalMind/commit/59507a84e706bfe84c20e06ad4b32fe48cd1aa71))


## v1.4.0 (2026-03-14)

### Features

- Add Backboard dashboard UI with assistants, threads, and memory views
  ([`f37e539`](https://github.com/zachary-nguyen/TribalMind/commit/f37e5390fe6c8b466f59228498646dc1aa3ed384))


## v1.3.0 (2026-03-14)

### Features

- Enhance configuration loading and command handling
  ([`ab5a64a`](https://github.com/zachary-nguyen/TribalMind/commit/ab5a64aa3baf3a88bebb509f30be6618ca625e7a))


## v1.2.0 (2026-03-14)


## v1.1.0 (2026-03-14)


## v1.0.0 (2026-03-14)

- Initial Release
