#################################################################################
# The Institute for the Design of Advanced Energy Systems Integrated Platform
# Framework (IDAES IP) was produced under the DOE Institute for the
# Design of Advanced Energy Systems (IDAES).
#
# Copyright (c) 2018-2026 by the software owners: The Regents of the
# University of California, through Lawrence Berkeley National Laboratory,
# National Technology & Engineering Solutions of Sandia, LLC, Carnegie Mellon
# University, West Virginia University Research Corporation, et al.
# All rights reserved.  Please see the files COPYRIGHT.md and LICENSE.md
# for full copyright and license information.
#################################################################################

# -*- coding: utf-8 -*-
"""
Created on Tue Jun  4 14:56:46 2024

@author: jscelay

Test driver for IDAES-GTEP
"""

from pyomo.environ import ConcreteModel, Var, SolverFactory, value
from pyomo.environ import units as u
from gtep.gtep_model import ExpansionPlanningModel
from gtep.gtep_data import ExpansionPlanningData
from gtep.gtep_solution import ExpansionPlanningSolution
from egret.data.model_data import ModelData
from pyomo.core import TransformationFactory
from pyomo.contrib.appsi.solvers.highs import Highs
from pyomo.contrib.appsi.solvers.gurobi import Gurobi

data_path = "./gtep/data/5bus"
# data_path = "./gtep/data/123_Bus_Coal"
data_object = ExpansionPlanningData()
data_object.load_prescient(data_path)
# mod_object = ExpansionPlanningModel(
#    data=data_object.md, num_reps=2, len_reps=1, stages=2, num_commit=24, num_dispatch=12
# )
mod_object = ExpansionPlanningModel(
    data=data_object, num_reps=1, len_reps=1, stages=3, num_commit=24, num_dispatch=2
)
mod_object.config["scale_texas_loads"] = True
mod_object.config["transmission"] = True
data_object.import_load_scaling("./gtep/data/123_Bus_Coal/ERCOT-Adjusted-Forecast.xlsb")
mod_object.create_model()
TransformationFactory("gdp.bound_pretransformation").apply_to(mod_object.model)
TransformationFactory("gdp.bigm").apply_to(mod_object.model)


# opt = Highs()
# opt = SolverFactory("gurobi", solver_io="python")
opt = Gurobi()
# mod_object.results = opt.solve(mod_object.model, tee=True)
mod_object.results = opt.solve(mod_object.model)


save_numerical_results = True
if save_numerical_results:

    sol_object = ExpansionPlanningSolution()

    sol_object.load_from_model(mod_object)
    sol_object.dump_json()
load_numerical_results = True
if load_numerical_results:
    sol_object.read_json("./gtep_solution_branch_test.json")
    # sol_object.read_json("./gtep_solution.json")
    # sol_object.read_json("./bigger_longer_wigglier_gtep_solution.json")
plot_results = True
if plot_results:
    sol_object.plot_levels(save_dir="./plots/")
