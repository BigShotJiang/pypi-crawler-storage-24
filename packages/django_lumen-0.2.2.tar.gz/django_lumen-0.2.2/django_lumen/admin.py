from django.contrib import admin

from .models import DiagramPreferences


@admin.register(DiagramPreferences)
class DiagramPreferencesAdmin(admin.ModelAdmin):
    list_display = ('user', 'routing_style', 'selected_apps', 'excluded_apps')
    list_filter = ('routing_style',)
    search_fields = ('user__username', 'user__email')
    raw_id_fields = ('user',)
