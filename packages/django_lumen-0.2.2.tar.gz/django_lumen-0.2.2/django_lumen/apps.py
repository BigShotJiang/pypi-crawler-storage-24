from django.apps import AppConfig


class LumenConfig(AppConfig):
    name = "django_lumen"
    verbose_name = "Django Lumen"
