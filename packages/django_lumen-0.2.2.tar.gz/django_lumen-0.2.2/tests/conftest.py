import pytest


@pytest.fixture
def staff_user(django_user_model):
    return django_user_model.objects.create_user(
        username='staff', password='pass', is_staff=True, is_active=True
    )


@pytest.fixture
def regular_user(django_user_model):
    return django_user_model.objects.create_user(
        username='regular', password='pass', is_staff=False, is_active=True
    )


@pytest.fixture
def staff_client(client, staff_user):
    client.force_login(staff_user)
    return client
