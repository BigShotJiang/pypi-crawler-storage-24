# scandar-guard

Runtime security monitoring for AI agents. Drop-in wrapper for Anthropic, OpenAI, LangChain, CrewAI, and AutoGen.

**Zero data leaves your environment.** All inspection runs in-process.

## Install

```bash
pip install scandar-guard
```

## Quick Start

```python
from anthropic import Anthropic
from scandar_guard import guard, GuardConfig

client = guard(Anthropic(), GuardConfig(
    agent_id="my-agent",
    asg_telemetry=True,
    asg_api_key="sk_your_key",
))

# Use as normal — Guard monitors every call
response = client.messages.create(
    model="claude-sonnet-4-20250514",
    max_tokens=1024,
    messages=[{"role": "user", "content": "Hello"}],
)
```

## Context Manager (recommended)

```python
from scandar_guard import guard_session, GuardConfig

with guard_session(Anthropic(), GuardConfig(
    agent_id="my-agent",
    asg_telemetry=True,
    asg_api_key="sk_your_key",
)) as client:
    response = client.messages.create(...)
    # session_end telemetry sent automatically on exit
```

## CrewAI

```python
from crewai import Crew
from scandar_guard.integrations.crewai import ScandarCrewAIMonitor

monitor = ScandarCrewAIMonitor(api_key="sk_xxx")

crew = Crew(
    agents=[...],
    tasks=[...],
    step_callback=monitor.step_callback,
    task_callback=monitor.task_callback,
)
```

## AutoGen

```python
from autogen import ConversableAgent
from scandar_guard.integrations.autogen import register_scandar_hooks

agent = ConversableAgent(name="my-agent", ...)
register_scandar_hooks(agent, api_key="sk_xxx")
```

## What it detects

- Prompt injection (direct, indirect, encoded, multi-turn)
- Tool argument injection and data exfiltration sequences
- Privilege escalation and anomalous tool call patterns
- Behavioral profile deviations with per-agent baselines
- 140+ detection rules mapped to OWASP LLM Top 10

## Scandar Overwatch

When `asg_telemetry=True` and `asg_api_key` are set, Guard sends anonymized telemetry (tool names, finding categories, threat scores — never prompts or content) to the Scandar Overwatch for fleet-wide visibility.

## Links

- [Documentation](https://scandar.ai/docs)
- [Scandar Overwatch](https://scandar.ai/features/agent-security-graph)
- [Scandar](https://scandar.ai)
