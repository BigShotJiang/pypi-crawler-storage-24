"""
scandar-guard — Runtime security monitoring for AI agents.

In-process. No data leaves your environment.
Part of the Scandar AI Security Platform.
"""
from .audit import AuditLogger
from .config import GuardConfig
from .decoder import ContentDecoder
from .findings import InspectionResult, RuntimeFinding, Severity
from .guard import ScandarBlockedError, async_guard_session, guard, guard_session
from .integrations.langchain import ScandarCallback
from .integrations.mcp import GuardedMCPSession
from .multi_turn import MultiTurnTracker
from .profile import AgentProfile
from .scorer import ThreatScore, ThreatScorer

__version__ = "0.2.0"
__all__ = [
    "guard",
    "guard_session",
    "async_guard_session",
    "GuardConfig",
    "ScandarBlockedError",
    "RuntimeFinding",
    "InspectionResult",
    "Severity",
    "AuditLogger",
    "ContentDecoder",
    "MultiTurnTracker",
    "AgentProfile",
    "ThreatScorer",
    "ThreatScore",
    "GuardedMCPSession",
    "ScandarCallback",
]
