"""Runtime finding types for scandar-guard."""
from __future__ import annotations

import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Literal, Optional


Severity = Literal["critical", "high", "medium", "low", "info"]
FindingSource = Literal["message", "tool_call", "tool_result", "response", "session"]


@dataclass
class RuntimeFinding:
    session_id: str
    severity: Severity
    category: str
    title: str
    description: str
    source: FindingSource
    confidence: float
    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    timestamp: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    layer: int = 3
    context: dict = field(default_factory=dict)

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "session_id": self.session_id,
            "timestamp": self.timestamp,
            "severity": self.severity,
            "category": self.category,
            "title": self.title,
            "description": self.description,
            "source": self.source,
            "confidence": self.confidence,
            "layer": self.layer,
            "context": self.context,
        }


@dataclass
class InspectionResult:
    findings: list[RuntimeFinding]
    session_id: str
    event_type: str
    duration_ms: float
    passed: bool = field(init=False)

    def __post_init__(self) -> None:
        self.passed = not any(
            f.severity in ("critical", "high") for f in self.findings
        )
