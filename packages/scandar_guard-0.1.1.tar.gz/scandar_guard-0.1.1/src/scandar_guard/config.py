"""Configuration for scandar-guard."""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Literal, Optional


@dataclass
class GuardConfig:
    mode: Literal["observe", "block"] = "observe"
    log_file: Optional[str] = "./scandar-guard-audit.jsonl"
    telemetry: bool = False
    block_on: list[str] = field(default_factory=lambda: ["critical"])
    redact_pii: bool = False
    session_id: Optional[str] = None
    log_level: Literal["all", "findings_only", "critical_only"] = "findings_only"

    # ── Enhanced detection (v2) ────────────────────────────────────
    # Encoding detection: decode base64, hex, ROT13, unicode before pattern matching
    decode_obfuscation: bool = True

    # Multi-turn tracking: detect injection fragments spread across messages
    multi_turn_detection: bool = True

    # Per-agent behavioral profiles: learn and flag deviations over sessions
    agent_id: Optional[str] = None  # Set to enable profiles
    profile_dir: str = "./scandar-profiles"

    # Pre-deployment scan context: connect with scandar-scan results
    scan_trust_score: Optional[int] = None  # 0-100 from scandar-scan

    # Composite threat scoring: produce a single 0-100 threat score per call
    threat_scoring: bool = True

    # ── Scandar Overwatch (ASG) fleet telemetry ────────────
    # Opt-in: sends anonymized session metadata (tool names, finding
    # categories, threat scores) to the Scandar Overwatch.
    # Requires: asg_telemetry=True AND a valid api_key.
    # Never sends: prompts, responses, tool arguments, or any content.
    asg_telemetry: bool = False
    asg_api_key: Optional[str] = None     # Scandar API key (Pro plan)
    asg_endpoint: str = "https://scandar.ai/api/v1/asg/events"
    asg_parent_agent_id: Optional[str] = None  # Set in child agents for multi-agent graphs
