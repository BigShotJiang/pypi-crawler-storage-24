"""
Legacy setup.py for backward compatibility.

Modern packaging configuration is in pyproject.toml.
This file exists only for compatibility with older tools.
"""
from setuptools import setup

# All configuration moved to pyproject.toml
# This is the modern, recommended approach (PEP 517/518/621)
setup()
