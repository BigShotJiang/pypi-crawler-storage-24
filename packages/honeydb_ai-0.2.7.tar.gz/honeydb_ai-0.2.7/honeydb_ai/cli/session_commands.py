"""
Session Management CLI Commands

Typer commands for session operations.

v2.0: Includes pagination support.
"""

from pathlib import Path

import typer

from honeydb_ai.cli.app import get_console, get_session_service, initialize_logging
from honeydb_ai.controllers.session_controller import SessionController


session_app = typer.Typer(
    name="session",
    help="Manage chat sessions",
    add_completion=False,
)


@session_app.command("list")
def list_sessions(
    limit: int = typer.Option(None, "--limit", "-l", help="Maximum number of sessions to show"),
    offset: int = typer.Option(0, "--offset", "-o", help="Number of sessions to skip"),
    details: bool = typer.Option(False, "--details", "-d", help="Show detailed information"),
) -> None:
    """
    List all sessions.

    v2.0 Major Enhancement #6: Pagination support for large session lists.
    """
    initialize_logging()

    console = get_console()
    session_service = get_session_service()
    session_controller = SessionController(session_service, console)

    try:
        session_controller.list_sessions(limit=limit, offset=offset, show_details=details)
    except Exception as e:
        console.print_error(f"Failed to list sessions: {e}")
        raise typer.Exit(1)


@session_app.command("show")
def show_session(
    session_id: str = typer.Argument(..., help="Session ID to display"),
    messages: bool = typer.Option(False, "--messages", "-m", help="Show message history"),
) -> None:
    """Display session details."""
    initialize_logging()

    console = get_console()
    session_service = get_session_service()
    session_controller = SessionController(session_service, console)

    try:
        session = session_controller.load_session(session_id)
        session_controller.display_session(session, show_messages=messages)
    except Exception as e:
        console.print_error(f"Failed to show session: {e}")
        raise typer.Exit(1)


@session_app.command("delete")
def delete_session(
    session_id: str = typer.Argument(..., help="Session ID to delete"),
    no_confirm: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation"),
) -> None:
    """Delete a session."""
    initialize_logging()

    console = get_console()
    session_service = get_session_service()
    session_controller = SessionController(session_service, console)

    try:
        session_controller.delete_session(session_id, confirm=not no_confirm)
    except Exception as e:
        console.print_error(f"Failed to delete session: {e}")
        raise typer.Exit(1)


@session_app.command("export")
def export_session(
    session_id: str = typer.Argument(..., help="Session ID to export"),
    output: str = typer.Argument(..., help="Output file path"),
    format: str = typer.Option("json", "--format", "-f", help="Export format (json/markdown/text)"),
) -> None:
    """Export a session to a file."""
    initialize_logging()

    console = get_console()
    session_service = get_session_service()
    session_controller = SessionController(session_service, console)

    try:
        session = session_controller.load_session(session_id)
        session_controller.export_session(session, output, format=format)
    except Exception as e:
        console.print_error(f"Failed to export session: {e}")
        raise typer.Exit(1)


@session_app.command("new")
def new_session(
    title: str = typer.Option("New Session", "--title", "-t", help="Session title"),
) -> None:
    """Create a new session."""
    initialize_logging()

    console = get_console()
    session_service = get_session_service()
    session_controller = SessionController(session_service, console)

    try:
        session = session_controller.create_session(title)
        console.print(f"Created session: {session.id}", style="success")
    except Exception as e:
        console.print_error(f"Failed to create session: {e}")
        raise typer.Exit(1)
