"""
HoneyDB MCP CLI - Main Entry Point

v2.0: Complete architectural uplift with all critical fixes.
"""

import typer
from importlib.metadata import version

from honeydb_ai.cli.app import app
from honeydb_ai.cli.session_commands import session_app
from honeydb_ai.cli.config_commands import config_app


# Add subcommands
app.add_typer(session_app, name="session")
app.add_typer(config_app, name="config")


def version_callback(value: bool = False):
    """Show version and exit."""
    if value:
        try:
            ver = version('honeydb-ai')
            typer.echo(f"honeydb-ai version: {ver}")
        except Exception:
            typer.echo("honeydb-ai version: unknown")
        raise typer.Exit()


@app.callback()
def main_callback(
    ctx: typer.Context,
    version_flag: bool = typer.Option(
        None,
        "--version",
        "-v",
        callback=version_callback,
        is_eager=True,
        help="Show version and exit.",
    ),
):
    """
    HoneyDB MCP CLI - Chat with AI models

    v2.0 Features:
    - Enhanced visual experience with markdown rendering
    - Robust error handling and recovery
    - Session management with file locking
    - Real-time tool call visibility
    - Terminal capability detection
    - Privacy-first logging

    Commands:
        chat       Start an interactive chat session
        session    Manage chat sessions
        config     Manage configuration

    Examples:
        honeydb-ai chat                    # Start a new chat
        honeydb-ai chat --session ID       # Resume a session
        honeydb-ai session list            # List all sessions
        honeydb-ai config show             # Show configuration
    """
    if ctx.invoked_subcommand is None:
        typer.echo(ctx.get_help())
        raise typer.Exit()


def main():
    """Main entry point for the CLI application."""
    app()


if __name__ == "__main__":
    main()
