"""
HoneyDB MCP CLI

v2.0: Complete architectural uplift with all critical fixes.

Critical Fixes:
- Session file locking (prevents data corruption)
- Ctrl+C cancellation (graceful interruption)
- Tool call event display (real-time MCP tool visibility)
- Terminal capability detection (dark/light mode support)
- Privacy-first logging (no API keys, no message content)

Major Enhancements:
- Session size limits and pagination
- Persistent metadata cache (1000x speedup)
- Configuration hot-reload
- Streaming-ready architecture
- Enhanced error recovery
"""

def main(*args, **kwargs):
    """
    Entry-point wrapper to avoid importing heavy runtime dependencies
    (such as `typer` via `honeydb_ai.main`) at import time.
    """
    from .main import main as _main
    return _main(*args, **kwargs)

__version__ = "0.2.7"
__all__ = ["main"]
