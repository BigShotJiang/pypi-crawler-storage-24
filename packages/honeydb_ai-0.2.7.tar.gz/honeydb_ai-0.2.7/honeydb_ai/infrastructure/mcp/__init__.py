"""
MCP Client Integration

Provides Model Context Protocol (MCP) client adapters for integrating
LLM providers with the HoneyDB MCP server.

The MCP server exposes HoneyDB threat intelligence tools via Server-Sent Events (SSE).
LLM providers (OpenAI, Anthropic, Gemini) can invoke these tools during conversations.
"""

from honeydb_ai.infrastructure.mcp.base import MCPAdapter
from honeydb_ai.infrastructure.mcp.openai_mcp import OpenAIMCPAdapter
from honeydb_ai.infrastructure.mcp.anthropic_mcp import AnthropicMCPAdapter
from honeydb_ai.infrastructure.mcp.gemini_mcp import GeminiMCPAdapter

__all__ = [
    "MCPAdapter",
    "OpenAIMCPAdapter",
    "AnthropicMCPAdapter",
    "GeminiMCPAdapter",
]
