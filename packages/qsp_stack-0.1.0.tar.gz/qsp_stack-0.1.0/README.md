# qsp-stack

`qsp-stack` is the meta-package for the RQM Technologies Quaternionic Signal Processing ecosystem.

Install everything with:

```bash
pip install qsp-stack
```

This installs:

- [qsp-core](https://pypi.org/project/qsp-core/)
- [qsp-fft](https://pypi.org/project/qsp-fft/)
- [qsp-filter](https://pypi.org/project/qsp-filter/)
- [qsp-modulation](https://pypi.org/project/qsp-modulation/)
- [qsp-orientation](https://pypi.org/project/qsp-orientation/)

## Example

```python
from qsp.fft import magnitude_spectrum
from qsp.filter import smoothing
from qsp.modulation import iq
from qsp.orientation import attitude
```

## License

MIT