###Documentación en https://github.com/lucasbaldezzari/sarapy/blob/main/docs/Docs.md
import logging
from tracemalloc import start
import numpy as np
from sklearn.base import BaseEstimator, TransformerMixin
from sklearn.pipeline import Pipeline
from sarapy.mlProcessors import PlantinFMCreator
import matplotlib.pyplot as plt
import pickle

class PlantinClassifier(BaseEstimator, TransformerMixin):
    """Clase para implementar el pipeline de procesamiento de datos para la clasificación del tipo de operación para plantines."""
    
    def __init__(self, classifier_file = ""):
        """Constructor de la clase PlantinClassifier.
        
        Args:
            - classifier_file: String con el nombre del archivo que contiene el clasificador entrenado. El archivo a cargar es un archivo .pkl.
        """

        self.logger = logging.getLogger("PlantinClassifier")

        self.classifications_probas = None
        self.clasificaciones = None
        self.lagartos = None

        #cargo el clasificador con pickle. Usamos try para capturar el error FileNotFoundError
        try:
            with open(classifier_file, 'rb') as file:
                self._pipeline = pickle.load(file)
            self.logger.info("Clasificador cargado con éxito.")
        except FileNotFoundError:
            self.logger.error("El archivo no se encuentra en el directorio actual.")
            raise

    def classify(self, feature_matrix, dst_pt, inest_pt,
                 proba_threshold = 0.45, use_proba_ma = False, proba_ma_window = 10,
                update_samePlace:bool = True, update_dstpt: bool = True,
                umbral_proba_dstpt = 0.5, umbral_bajo_dstpt = 1.5,
                use_ma = True, dstpt_ma_window = 62,
                use_min_dstpt = False, factor = 0.1,
                fix_lagartos = False, umbrales_lagartos = (1,3), **kwargs):
        """Genera la clasificación de las operaciones para plantines.
        
        - feature_matrix: Es un array con los datos (strings) provenientes de la base de datos histórica.
        La forma de newData debe ser (n,3). Las columnas de newData deben ser,
                - 1: deltaO
                - 2: ratio_dCdP
                - 3: distancias
        - dst_pt: Array con las distorsiones de plantín.
        - inest_pt: Array con flag de inestabilidad de plantín.

        kwargs: Diccionario con los argumentos necesarios para la clasificación.

        NOTA: Estas características son necesarias en base a la última versión del modelo de clasificación.
        """

        group_kwargs = {
                        k: v for k, v in kwargs.items()
                        if k in [
                            # "std_weight",
                            # "useDistancesStats",
                            # "ratio_dcdp_umbral",
                            "dist_umbral",
                        ]}

        if use_ma:
            if dst_pt.shape[0] < dstpt_ma_window:
                self.logger.warning("El tamaño de la serie temporal es menor que la ventana de media móvil. No se aplicará media móvil.")
                dst_pt = self.get_dstpt_MA(dst_pt, window_size=dst_pt.shape[0], mode='same')             
            else:
                dst_pt = self.get_dstpt_MA(dst_pt, window_size=dstpt_ma_window, mode='same')

        self.clasificaciones = self._pipeline.predict(feature_matrix)
        self.classifications_probas = self._pipeline.predict_proba(feature_matrix)

        if use_proba_ma:
            if proba_ma_window >= self.classifications_probas.shape[0]:
                self.logger.warning("El tamaño de la serie temporal es menor que la ventana de media móvil. No se aplicará media móvil a las probabilidades.")
                probas_ma = self.get_probas_MA(self.classifications_probas, window_size=self.classifications_probas.shape[0], mode='same')
            else:
                probas_ma = self.get_probas_MA(self.classifications_probas, window_size=proba_ma_window, mode='same')
            self.clasificaciones[probas_ma[:,1] < proba_threshold] = 0
        else:
            # self.clasificaciones = self._pipeline.classes_[np.argmax(self.classifications_probas, axis=1)]
            self.clasificaciones[self.classifications_probas[:,1] < proba_threshold] = 0

        # if update_samePlace:
        #     self.grouped_ops = self.groupOpsSamePlace(feature_matrix, **group_kwargs)
        #     self.clasificaciones = self.updateLabelsSamePlace(self.clasificaciones, self.grouped_ops)

        if update_dstpt:
            self.clasificaciones = self.updateLabelsFromDSTPT(self.clasificaciones, dst_pt, inest_pt,
                                                             umbral_bajo_dstpt, umbral_proba_dstpt,
                                                             use_min_dstpt, factor)

        if fix_lagartos:
            self.clasificaciones = self.detect_and_fix_lagartos(
                labels=self.clasificaciones,
                dst_pt=dst_pt,
                inest_pt=inest_pt,
                distances=feature_matrix[:, 2],  # columna distances
                probas=self.classifications_probas,
                min_len=kwargs.get("lagarto_min_len", 2),
                max_len=kwargs.get("lagarto_max_len", 5),
                dst_pt_umbral=kwargs.get("lagarto_dstpt_umbral", umbral_bajo_dstpt),
                dist_umbral=kwargs.get("lagarto_dist_umbral", 0.5),
                proba_min=kwargs.get("lagarto_proba_min", 0.35),
                umbrales_lagartos=umbrales_lagartos
            )

        if update_samePlace:
            self.grouped_ops = self.groupOpsSamePlace(feature_matrix, **group_kwargs)
            self.clasificaciones = self.updateLabelsSamePlace(self.clasificaciones, self.grouped_ops)

        return self.clasificaciones, self.classifications_probas

    def groupOpsSamePlace(self, X, dist_umbral=0.5):
        """
        Agrupa operaciones consecutivas cuya distancia sea menor a dist_umbral.
        Solo usa distancias.
        """
        distances = X[:, 2]
        grouped_ops = []

        current_group = [0]

        for i in range(1, len(distances)):

            if distances[i] < dist_umbral:
                current_group.append(i)
            else:
                if len(current_group) > 1:
                    grouped_ops.append(current_group)
                current_group = [i]

        # último grupo
        if len(current_group) > 1:
            grouped_ops.append(current_group)

        return grouped_ops

    def updateLabelsSamePlace(self, labels, ops_grouped):

        new_labels = labels.copy()

        for group in ops_grouped:

            # Obtener probabilidades clase 1
            probs_group = self.classifications_probas[group, 1]

            # índice del mejor candidato dentro del grupo
            best_idx_local = np.argmax(probs_group)
            best_idx = group[best_idx_local]

            # poner todo en 0
            new_labels[group] = 0

            # dejar solo el mejor en 1
            new_labels[best_idx] = 1

        return new_labels

    def updateLabelsFromDSTPT(self, labels, dst_pt, inest_pt,
                              umbral_bajo_dstpt = 4, umbral_proba_dstpt = 0.5,
                              use_min_dstpt = False, factor = 0.1):
        """
        Función para actualizar las etiquetas de las operaciones que tengan distorsiones de plantín.
        """
        new_labels = labels.copy()

        umbral_bajo_dstpt = min(dst_pt)*(1+factor) if use_min_dstpt else umbral_bajo_dstpt
        
        ##filtro
        new_labels[(dst_pt < umbral_bajo_dstpt) & (inest_pt == 0)] = 0

        ##si inest_pt 1 es y las probs son menores a umbral_proba_dstpt, entonces la operación es 0
        new_labels[(inest_pt == 1) & (self.classifications_probas[:,1] < umbral_proba_dstpt)] = 0

        return new_labels

    def get_dstpt_MA(self, dst_pt, window_size=104, mode='same'):
        """
        Función para calcular la media móvil de una serie temporal.
        data: numpy array con los datos de la serie temporal
        window_size: tamaño de la ventana para calcular la media móvil
        """
        padding_start = dst_pt[0:window_size]
        padding_end = dst_pt[-window_size:]
        padded_data = np.concatenate([padding_start, dst_pt, padding_end])
        ma_full = np.convolve(padded_data, np.ones(window_size)/window_size, mode='same')
        return ma_full[window_size: -window_size]
    
    def get_probas_MA(self, probas, window_size=104, mode='same'):
        """
        Función para calcular la media móvil de una serie temporal.
        data: numpy array con los datos de la serie temporal
        window_size: tamaño de la ventana para calcular la media móvil
        """
        padding_start = probas[0:window_size, :]
        padding_end = probas[-window_size:, :]
        padded_data = np.vstack([padding_start, probas, padding_end])
        ma_full = np.apply_along_axis(lambda m: np.convolve(m, np.ones(window_size)/window_size, mode='same'), axis=0, arr=padded_data)
        return ma_full[window_size: -window_size, :]

    def _find_lagartos(self, labels, min_len=2, max_len=5):
        """
        Encuentra runs de ceros y los fragmenta en sub-runs
        de longitud entre min_len y max_len.

        Retorna:
            List[Tuple[int, int]]
        """
        self.lagartos = []
        start = None

        for i, v in enumerate(labels):
            if v == 0 and start is None:
                start = i

            elif v == 1 and start is not None:
                self.lagartos.extend(
                    self._split_run(start, i - 1, min_len, max_len)
                )
                start = None

        # caso borde: termina en cero
        if start is not None:
            self.lagartos.extend(
                self._split_run(start, len(labels) - 1, min_len, max_len)
            )

        return self.lagartos
    
    def _split_run(self, start, end, min_len, max_len):
        """
        Fragmenta un run [start, end] en sub-runs consecutivos
        de tamaño <= max_len y >= min_len.
        """
        fragments = []
        current = start

        while current <= end:
            sub_end = min(current + max_len - 1, end)
            length = sub_end - current + 1

            if length >= min_len:
                fragments.append((current, sub_end))

            current = sub_end + 1

        return fragments

    def _chek_low_dstpt(self, labels:list[float], lagartos:list[list[float]],
                              dst_pt:list[float], inest_pt:list[float], distances:list[float]):
        """
        Función para analizar y encontrar la posible causa de los lagartos.
        """
        flag = False # flag_dstpt

        flatten_indexes = []
        for lagarto in lagartos:
            start, end = lagarto
            indexes = list(range(start, end))
            flatten_indexes.extend(indexes)

        indexes_to_analyze = np.array(flatten_indexes)
        ops_to_analyze = labels[indexes_to_analyze]
        ##me quedo sólo con los indices que correspondan a operaciones clasificadas como 0
        ops_to_analyze = ops_to_analyze[ops_to_analyze == 0]
        dst_pt_to_analyze = dst_pt[indexes_to_analyze]
        ##si la media de dst_pt_to_analyze es menor a 1.5, entonces el flag_dstpt es 1
        if dst_pt_to_analyze.mean() < 1.5:
            flag = True

        return flag
    
    def detect_and_fix_lagartos(
        self,
        labels,
        dst_pt,
        inest_pt,
        distances,
        probas,
        min_len=2,
        max_len=5,
        dst_pt_umbral=1.5,
        dist_umbral=0.5,
        proba_min=0.35,
        umbrales_lagartos=(2,5),
        mode = "short", #shorts o longs
    ):
        """
        Detecta y corrige lagartos evaluando clusters espaciales
        dentro de runs de ceros.
        """

        new_labels = labels.copy()
        min_len, max_len = umbrales_lagartos
        lagartos = self._find_lagartos(labels, min_len, max_len)

        for start, end in lagartos:
            indexes = list(range(start, end + 1))

            for index in indexes:
                #recorro cada cluster y analizo si debe ser puesto a 1 o no
                if dst_pt[index] > dst_pt_umbral and \
                    inest_pt[index] == 0 and \
                        probas[index, 1] >= proba_min:
                            new_labels[index] = 1
                else:
                    new_labels[index] = 0

        match mode:
            case "short": return self._fix_short_lagartos(new_labels, lagartos, dst_pt, dist_umbral)
            case "long": pass #pendiente implementar

        # return new_labels

        ##vuelvo a recorrer los lagartos pero sólo presto atención a los 
        ##que los 0 que están en esta situación [1, 0, 1]

    def _fix_short_lagartos(self, labels, lagartos, distances, dist_umbral):
        """
        Para lagartos cortos del tipo [1, 0, 1]
        """
        for start, end in lagartos:
            indexes = list(range(start-1, end + 2))
            if len(indexes) == 3:
                if labels[indexes[0]] == 1 and labels[indexes[1]] == 0 and labels[indexes[2]] == 1:
                    #si el dst_pt del índice del medio es menor a un umbral, entonces lo pongo a 1
                    if distances[indexes[1]] > dist_umbral:# and probas[indexes[1], 1] >= proba_min:
                        labels[indexes[1]] = 1

        return labels
    
if __name__ == "__main__":
    import os
    import pandas as pd
    import numpy as np
    from sarapy.preprocessing import TransformInputData
    from sarapy.mlProcessors import PlantinFMCreator
    from sarapy.mlProcessors import PlantinClassifier
    import json


    ## argumentos de PlantinFMCreator
    kwargs_fmcreator = {"imputeDistances":True, "distanciaMedia":1.8, "umbral_precision":0.3,
                        "dist_mismo_lugar":0.2, "max_dist":100,
                        "umbral_ratio_dCdP":2, "deltaO_medio":4,
                        "impute_ratiodcdp": True, "umbral_impute_ratiodcdp": -0.5,
                        "deltaO_ma": True, "deltaO_ma_window": 26}
            
    ##argumentos del método PlantinClassifier.clasiffy()
    kwargs_classifier = {"proba_threshold":0.45,
                         "use_proba_ma":False,
                         "proba_ma_window":10,
                         "update_samePlace":True,
                         "update_dstpt":True,
                         "umbral_proba_dstpt":0.5,
                         "umbral_bajo_dstpt":1.5,
                         "use_ma":True,
                         "dstpt_ma_window":62,
                         "use_min_dstpt":False,
                         "factor":0.1,
                         "fix_lagartos": True,
                         "ratio_dcdp_umbral":0.1,
                         "dist_umbral":0.5,
                         }

    historical_data_path = "examples\\2025-08-09\\UPM107N\\historical-data.json"
    with open(historical_data_path, 'r') as file:
        samples = json.load(file)

    fmcreator = PlantinFMCreator(**kwargs_fmcreator)
    tindata = TransformInputData()
    raw_X = tindata.transform(samples)

    X, dst_pt, inest_pt = fmcreator.fit_transform(raw_X)

    rf_clf_wu = PlantinClassifier(classifier_file='modelos\\pipeline_rf.pkl')

    clasificaciones, probas = rf_clf_wu.classify(X, dst_pt, inest_pt, **kwargs_classifier)

    # clasificaciones_lagartos = clasificaciones.copy()
    # clasificaciones_lagartos[50:58] = 0
    # clasificaciones_lagartos[70:86] = 0
    # clasificaciones_lagartos[90:93] = 0
    # lagartos = rf_clf_wu._find_lagartos(clasificaciones_lagartos, 2,3)

    # lagartes_fixed = rf_clf_wu.detect_and_fix_lagartos(
    #     labels=clasificaciones_lagartos,
    #     dst_pt=dst_pt,
    #     inest_pt=inest_pt,
    #     distances=X[:, 2],  # columna distances
    #     probas=probas, min_len=kwargs_classifier.get("lagarto_min_len", 2),
    #     max_len=kwargs_classifier.get("lagarto_max_len", 5),
    #     dst_pt_umbral=kwargs_classifier.get("lagarto_dstpt_umbral", kwargs_classifier["umbral_bajo_dstpt"]),
    #     dist_umbral=kwargs_classifier.get("lagarto_dist_umbral", 0.5    ),
    # )
    
    # print("media de clasificaciones", clasificaciones.mean())
    # print("media de probabilidades", probas.mean(axis=0), probas.std(axis=0), np.median(probas, axis=0))
    # print("primeras clasificaciones", clasificaciones[100:105])
    # print("primeras probabilidades", probas[100:105])
    # print("primeras distorsiones", dst_pt[100:105])
    # print("primeras inestabilidades", inest_pt[100:105])

    print(clasificaciones[50:58], clasificaciones[70:86], clasificaciones[90:93])

    # print(lagartos)
