import pickle
import logging
from sarapy.dataProcessing import TLMSensorDataProcessor

class FertilizerTransformer:
    """
    Clase para tomar los valores de distorsión de fertilizante y transformarlos a gramos
    """

    def __init__(self, regresor_file, poly_features_file):
        """Constructor de la clase FertilizerImputer.

        Args:
            - regresor: Regresor que transforma los valores de distorsión a gramos.
            - poly_features: Grado del polinomio a utilizar en la transformación de los datos.        
        """
        self.logger = logging.getLogger("FertilizerTransformer")
        ##cargo el regresor con pickle. Usamos try para capturar el error FileNotFoundError
        try:
            with open(regresor_file, 'rb') as file:
                self._regresor = pickle.load(file)
            self.logger.info("Regresor cargado con éxito.")
        except FileNotFoundError:
            self.logger.error("El archivo no se encuentra en el directorio actual.")

        ##cargo las características polinómicas con pickle. Usamos try para capturar el error FileNotFoundError
        try:
            with open(poly_features_file, 'rb') as file:
                self._poly_features = pickle.load(file)
            self.logger.info("Características polinómicas cargadas con éxito.")
        except FileNotFoundError:
            self.logger.error("El archivo no se encuentra en el directorio actual.")

        self.fertilizer_grams = None ##cuando no se ha transformado ningún dato, se inicializa en None


    def transform(self, data):
        """Transforma los datos de distorsión de fertilizante a gramos.

        Params:
            - data: Es una lista de diccionarios (como un JSON) con los datos de telemetría.

        Returns:
            - 0: Array con los valores de distorsión de fertilizante transformados a gramos.
        """
        tlmDataProcessor = TLMSensorDataProcessor.TLMSensorDataProcessor(data)
        X = tlmDataProcessor["SC_FT",:]
        X_poly = self._poly_features.fit_transform(X.reshape(-1, 1))
        self.fertilizer_grams = self._regresor.predict(X_poly)

        ##para valores de distorsión de 13+-0.3 y 15+-0.3, pongo los valores en 8 y 9 gramos, respectivamente
        ##uso máscara booleana para encontrar los índices
        mask_13 = (X >= 12.7) & (X <= 13.3)
        mask_15 = (X >= 14.7) & (X <= 15.3)
        self.fertilizer_grams[mask_13] = 8
        self.fertilizer_grams[mask_15] = 9

        ##retorno con shape (n,)
        return self.fertilizer_grams.reshape(-1,)
    
if __name__ == "__main__":
    import pandas as pd
    import numpy as np
    import json
    from sarapy.preprocessing import TransformInputData
    import matplotlib.pyplot as plt
    from collections import Counter

    fecha = "2025-08-09"
    nodo_interes = "UPM095N"

    historical_data_path = f"examples//{fecha}//{nodo_interes}//historical-data.json"
    with open(historical_data_path, 'r') as file:
        historical_data = json.load(file)

    ##cargo en un diccionario sarapy\preprocessing\telemetriaDataPosition.json
    data_positions = json.load(open("sarapy/preprocessing/telemetriaDataPosition.json", 'r'))
    transform_input_data = TransformInputData()
    transformed_data = transform_input_data.transform(historical_data)

    fertransformer = FertilizerTransformer(regresor_file='modelos\\regresor_v2.pkl', poly_features_file='modelos\\poly_features_v2.pkl')
    gramos = fertransformer.transform(transformed_data)
    print(gramos[:10])

    df = pd.DataFrame(transformed_data)
    score_ft = df["SC_FT"].values

    print(score_ft.mean(), gramos.mean())
    print(score_ft.max(), gramos.max())
    print(score_ft.min(), gramos.min())

    puntos = list(zip(score_ft, gramos))
    conteos  = Counter(puntos)
    xs, ys, sizes = zip(*[(x, y, c) for (x, y), c in conteos.items()])

    np.array([s*10 for s in sizes]).shape

    points = np.column_stack((score_ft, gramos))
    unique_points, counts = np.unique(points, axis=0, return_counts=True)

    sizes = np.log1p(counts) * 50

    plt.figure(figsize=(10, 6))
    handles, labels = plt.gca().get_legend_handles_labels()
    order = [2, 0, 1]
    plt.scatter(unique_points[:,0], unique_points[:,1], color="#5612af", label="Regresor 1 - Orden 12",zorder=1,
                s=sizes)
    plt.scatter(score_ft.mean(), gramos.mean(), color="#af121f", label="Punto promedio", marker='X',s=400)
    plt.title(f'Predicciones Regresor 2 de orden 12 para NODO: {nodo_interes}')
    plt.xlabel('Score de Fertilizante (SC_FT)')
    plt.ylabel('Predicciones de Gramos de Fertilizante')
    plt.grid(True)
    plt.legend()
    plt.savefig(f'predicciones_regresor2_orden12_{nodo_interes}.png')
    plt.show()

    nodos = ["UPM075N", "UPM076N", "UPM077N", "UPM078N", "UPM079N", "UPM080N", "UPM081N", "UPM082N", "UPM083N", "UPM084N",
             "UPM085N", "UPM086N", "UPM087N", "UPM088N", "UPM089N", "UPM090N", "UPM091N", "UPM092N", "UPM093N", "UPM094N", "UPM095N",
             "UPM096N", "UPM097N", "UPM098N", "UPM099N"]
    
    ##cargo datos históricos de ejemplo
    
    scores_ft_maximos = {}
    scores_ft_minimos = {}
    gramos_maximos = {}
    gramos_minimos = {}
    for nodo in nodos:
        historical_data_path = f"examples//{fecha}//{nodo}//historical-data.json"
        try:
            with open(historical_data_path, 'r') as file:
                historical_data = json.load(file)
        except FileNotFoundError:
            print(f"El archivo {historical_data_path} no se encuentra en el directorio actual.")
            continue
        transform_input_data = TransformInputData()
        transformed_data = transform_input_data.transform(historical_data)
        fertransformer = FertilizerTransformer(regresor_file='modelos\\regresor_v2.pkl', poly_features_file='modelos\\poly_features_v2.pkl')
        gramos = fertransformer.transform(transformed_data)
        gramos_maximos[nodo] = gramos.max()
        gramos_minimos[nodo] = gramos.min()

        df = pd.DataFrame(transformed_data)
        score_ft = df["SC_FT"].values
        scores_ft_maximos[nodo] = score_ft.max()
        scores_ft_minimos[nodo] = score_ft.min()
        
    data = np.array([[gramos_maximos[nodo] for nodo in nodos],
                       [scores_ft_maximos[nodo] for nodo in nodos],
                        [gramos_minimos[nodo] for nodo in nodos],
                          [scores_ft_minimos[nodo] for nodo in nodos]])  

    data_df = pd.DataFrame(data=data.T, index=nodos, columns=['Gramos_Fertilizante', 'Score_Fertilizante', 'Gramos_Fertilizante_Min', 'Score_Fertilizante_Min'])

    data_df['Gramos_Fertilizante'].plot.bar(figsize=(12, 6), color="#34a853", legend=False)
    #add text labels on top of each bar with the height value
    for i, v in enumerate(data_df['Gramos_Fertilizante']):
        plt.text(i, v + 0.1, f"{v:.1f}", ha='center', va='bottom',color="#34a853")
    plt.title('Máximos de gramos de fertilizante por nodo') 
    plt.xlabel('Nodos')
    plt.ylabel('Gramos de Fertilizante')
    plt.grid(axis='y')
    plt.savefig('maximos_gramos_fertilizante_por_nodo.png')
    plt.show()

    data_df['Gramos_Fertilizante_Min'].plot.bar(figsize=(12, 6), color="#34a853", legend=False)
    #add text labels on top of each bar with the height value
    for i, v in enumerate(data_df['Gramos_Fertilizante_Min']):
        plt.text(i, v + 0.1, f"{v:.1f}", ha='center', va='bottom',color="#34a853")
    plt.title('Mínimos de gramos de fertilizante por nodo') 
    plt.xlabel('Nodos')
    plt.ylabel('Gramos de Fertilizante')
    plt.grid(axis='y')
    plt.savefig('minimos_gramos_fertilizante_por_nodo.png')
    plt.show()

    data_df['Score_Fertilizante'].plot.bar(figsize=(12, 6), color="#3434a8", legend=False)
    #add text labels on top of each bar with the height value
    for i, v in enumerate(data_df['Score_Fertilizante']):
        plt.text(i, v + 0.1, f"{v:.1f}", ha='center', va='bottom',color="#3434a8")
    plt.title('Máximos de score de fertilizante por nodo') 
    plt.xlabel('Nodos')
    plt.ylabel('Score de Fertilizante')
    plt.grid(axis='y')
    plt.savefig('maximos_score_fertilizante_por_nodo.png')
    plt.show()

    data_df['Score_Fertilizante_Min'].plot.bar(figsize=(12, 6), color="#3434a8", legend=False)
    #add text labels on top of each bar with the height value
    for i, v in enumerate(data_df['Score_Fertilizante_Min']):
        plt.text(i, v + 0.1, f"{v:.1f}", ha='center', va='bottom',color="#3434a8")
    plt.title('Mínimos de score de fertilizante por nodo') 
    plt.xlabel('Nodos')
    plt.ylabel('Score de Fertilizante')
    plt.grid(axis='y')
    plt.savefig('minimos_score_fertilizante_por_nodo.png')
    plt.show()

    