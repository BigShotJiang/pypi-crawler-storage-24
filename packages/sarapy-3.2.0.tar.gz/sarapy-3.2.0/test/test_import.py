def test_import():
    import sarapy


test_import()