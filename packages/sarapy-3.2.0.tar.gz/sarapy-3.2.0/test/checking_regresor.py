import pickle
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.preprocessing import PolynomialFeatures
from sklearn.linear_model import LinearRegression
from sklearn.preprocessing import StandardScaler

regresor = "modelos//regresor.pkl"
poly_features = "modelos//poly_features.pkl"

with open(regresor, "rb") as file:
    loaded_regresor = pickle.load(file)

with open(poly_features, "rb") as file:
    loaded_poly_features = pickle.load(file)

coeficientes = loaded_regresor.coef_.flatten()
intercept = loaded_regresor.intercept_
index = np.arange(len(coeficientes)) + 1
distorsiones = np.linspace(0, 15, 1000)
X_poly = loaded_poly_features.transform(distorsiones.reshape(-1, 1))
predicciones = loaded_regresor.predict(X_poly)

##genero un dataframe con los coeficientes
labels = [f"Exponente/Coeficiente {i}" for i in index]
tabla = pd.DataFrame(coeficientes, labels).rename(columns={0:"Valores"})
tabla.loc[len(tabla)+1] = intercept
tabla = tabla.rename(index={len(tabla):"intercepción"})

#grafico de líneas de los coeficientes vs su índice
plt.figure(figsize=(10, 6))
plt.plot(index, coeficientes, marker='o', linestyle='-', color='b')
plt.title('Coeficientes del Regresor Polinómico')
plt.xlabel('Índice del Coeficiente')
plt.ylabel('Valor del Coeficiente')
plt.grid(True)
plt.axhline(0, color='black', linewidth=0.8, linestyle='--')
plt.show()

# gráfico de dispersión de distorsión vs predicciones
plt.figure(figsize=(10, 6))
plt.scatter(distorsiones, predicciones, color='r', alpha=0.6)
plt.title('Score de Fertilizante vs Predicciones en Gramos')
plt.xlabel('Score de Fertilizante (SC_FT)')
plt.ylabel('Predicciones de Gramos de Fertilizante')
plt.grid(True)
plt.show()

inf, sup = 7, 13
distorsiones[int(inf/0.1):int(sup/0.1+1)].mean()
predicciones[int(inf/0.1):int(sup/0.1+1)].mean()


# Definición de tramos: (x1, x2, y1, y2)
segmentos1 = [(0, 4, 0, 0.821),
             (4, 7, 0.821, 5),
             (7, 9.5, 5, 5.41),
             (9.5, 13, 5.41, 8),
             (13, 15, 8, 9)]
segmentos2 = [(0, 4, 0, 0.821),
             (4, 7, 0.821, 5),
            #  (7, 9.5, 5, 5.41),
             (7, 13, 5, 8),
             (13, 15, 8, 9)]

def get_line(x1, x2, y1, y2):
    m = (y2 - y1) / (x2 - x1)
    b = y1 - m * x1
    return m, b

def piecewise_linear(x, segmentos, lines):
    for (x1, x2, _, _), (m, b) in zip(segmentos, lines):
        if x1 <= x <= x2:
            return m * x + b
    raise ValueError("x fuera de rango")

lines1 = [get_line(*seg) for seg in segmentos1]
lines2 = [get_line(*seg) for seg in segmentos2]

# Ejemplo
ys1 = np.array([piecewise_linear(x, segmentos1, lines1) for x in distorsiones])
ys2 = np.array([piecewise_linear(x, segmentos2, lines2) for x in distorsiones])

# gráfico de dispersión de distorsión vs predicciones
plt.figure(figsize=(10, 6))
handles, labels = plt.gca().get_legend_handles_labels()
order = [2, 0, 1]
plt.scatter(distorsiones, predicciones, color='r', alpha=0.5, label="Predicciones actuales",zorder=2)
plt.scatter(distorsiones, ys1, color='g', alpha=0.5, label="Propuesta 1",zorder=1)
plt.scatter(distorsiones, ys2, color='b', alpha=0.5, label="Propuesta 2",zorder=0)
plt.title('Score de Fertilizante vs Predicciones en Gramos')
plt.xlabel('Score de Fertilizante (SC_FT)')
plt.ylabel('Predicciones de Gramos de Fertilizante')
plt.grid(True)
plt.legend()
plt.show()


### ************* Obteniendo nuevos regresores a partir de ys1 y ys2 ************* ###
X = distorsiones.reshape(-1, 1)

poly = PolynomialFeatures(
    degree=12,
    include_bias=True  # incluye el término β0
)

X_poly = poly.fit_transform(X)

modelo1 = LinearRegression(fit_intercept=False)
modelo1.fit(X_poly, ys1)
modelo2 = LinearRegression(fit_intercept=False)
modelo2.fit(X_poly, ys2)

ys1_pred = modelo1.predict(X_poly)
ys2_pred = modelo2.predict(X_poly)

# gráfico de dispersión de distorsión vs predicciones
plt.figure(figsize=(10, 6))
handles, labels = plt.gca().get_legend_handles_labels()
order = [2, 0, 1]
plt.scatter(distorsiones, ys1, color='g', alpha=0.1, label="Función 1 Hardcodeada ",zorder=1)
plt.scatter(distorsiones, ys1_pred, color="#5612af", alpha=0.5, label="Regresor 1 - Orden 12",zorder=2)
plt.title('Comparación Función de Propuesta vs Regresor 1 de orden 12')
plt.xlabel('Score de Fertilizante (SC_FT)')
plt.ylabel('Predicciones de Gramos de Fertilizante')
plt.grid(True)
plt.legend()
plt.show()

# gráfico de dispersión de distorsión vs predicciones
plt.figure(figsize=(10, 6))
handles, labels = plt.gca().get_legend_handles_labels()
order = [2, 0, 1]
plt.scatter(distorsiones, ys2, color='b', alpha=0.1, label="Función 2 Hardcodeada ",zorder=1)
plt.scatter(distorsiones, ys2_pred, color="#12af12", alpha=0.5, label="Regresor 2 - Orden 12",zorder=2)
plt.title('Comparación Función de Propuesta vs Regresor 2 de orden 12')
plt.xlabel('Score de Fertilizante (SC_FT)')
plt.ylabel('Predicciones de Gramos de Fertilizante')
plt.grid(True)
plt.legend()
plt.show()

# gráfico de dispersión de distorsión vs predicciones
plt.figure(figsize=(10, 6))
handles, labels = plt.gca().get_legend_handles_labels()
order = [2, 0, 1]
plt.scatter(distorsiones, ys1_pred, color="#5612af", alpha=0.1, label="Regresor 1 - Orden 12",zorder=1)
plt.scatter(distorsiones, ys2_pred, color="#12af12", alpha=0.5, label="Regresor 2 - Orden 12",zorder=2)
plt.title('Regresor 1 vs Regresor 2 de orden 12')
plt.xlabel('Score de Fertilizante (SC_FT)')
plt.ylabel('Predicciones de Gramos de Fertilizante')
plt.grid(True)
plt.legend()
plt.show()

## Guardo el modelo 2 y las características polinómicas
with open("modelos//regresor_v2.pkl", "wb") as file:
    pickle.dump(modelo2, file)

with open("modelos//poly_features_v2.pkl", "wb") as file:
    pickle.dump(poly, file)
