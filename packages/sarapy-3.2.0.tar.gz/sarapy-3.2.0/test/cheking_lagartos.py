import os
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sarapy.preprocessing import TransformInputData
from sarapy.mlProcessors import PlantinFMCreator
from sarapy.mlProcessors import PlantinClassifier
import json
import plotly.express as px


## argumentos de PlantinFMCreator
kwargs_fmcreator = {"imputeDistances":True, "distanciaMedia":1.8, "umbral_precision":0.3,
                    "dist_mismo_lugar":0.2, "max_dist":100,
                    "umbral_ratio_dCdP":2, "deltaO_medio":4,
                    "impute_ratiodcdp": True, "umbral_impute_ratiodcdp": -0.5,
                    "deltaO_ma": True, "deltaO_ma_window": 26}
        
##argumentos del método PlantinClassifier.classify()
fix_lagartos = True
kwargs_classifier = {"proba_threshold":0.45,
                        "use_proba_ma":False,
                        "proba_ma_window":10,
                        "update_samePlace":True,
                        "update_dstpt":True,
                        "umbral_proba_dstpt":0.5,
                        "umbral_bajo_dstpt":1.5,
                        "use_ma":True,
                        "dstpt_ma_window":62,
                        "use_min_dstpt":False,
                        "factor":0.1,
                        "fix_lagartos": fix_lagartos,
                        "umbrales_lagartos": (1,5),
                        "useRatioStats":False,
                        "std_weight":1.,
                        "useDistancesStats":False,
                        "ratio_dcdp_umbral":0.1,
                        "dist_umbral":1.,
                        }

historical_data_path = "examples\\2026-02-25\\UPM047N\\historical-data.json"
with open(historical_data_path, 'r') as file:
    samples = json.load(file)

fmcreator = PlantinFMCreator(**kwargs_fmcreator)
tindata = TransformInputData()
raw_X = tindata.transform(samples)

X, dst_pt, inest_pt = fmcreator.fit_transform(raw_X)

rf_clf_wu = PlantinClassifier(classifier_file='modelos\\pipeline_rf.pkl')
clasificaciones, probas = rf_clf_wu.classify(X, dst_pt, inest_pt, **kwargs_classifier)
dst_pt_ma = rf_clf_wu.get_dstpt_MA(dst_pt, window_size=kwargs_classifier["dstpt_ma_window"], mode='same')

# fig,ax = plt.subplots(figsize=(12,6))
# ax.plot(dst_pt, label='dst_pt')
# ax.plot(dst_pt_ma, label='dst_pt_ma')
# ax.twinx().plot(clasificaciones, label='clasificaciones', color="#C1C1C1", alpha=0.5)
# ax.set_title(f"dst_pt y dst_pt_ma - Fix Lagartos: {fix_lagartos}")
# ax.set_xlabel("Operación") 
# plt.legend()
# plt.show()

lagartos = rf_clf_wu._find_lagartos(clasificaciones, 1,4)

gps = pd.DataFrame(raw_X)[["latitud", "longitud"]].values
print("media de clasificaciones", clasificaciones.mean())
print("media de probabilidades", probas.mean(axis=0), probas.std(axis=0), np.median(probas, axis=0))

df = pd.DataFrame(raw_X)

latitud, longitud, precision  = df[["latitud","longitud","Precision_N"]].values.T
data = pd.DataFrame({"operacion":df.index.values+1,
                     "labels": clasificaciones,
                     "dst_pt": dst_pt_ma,
                     "latitud": latitud,
                     "longitud": longitud,
                     "distancias": X[:,2],
                     "precision": precision})

data["labels"] = data["labels"].astype(str)

# Crear scatter
fig = px.scatter(
    data,
    x="latitud",
    y="longitud",
    color="labels",
    color_discrete_map={0: "blue", 1: "red"},
)

fig.update_traces(
    customdata=np.stack((data["operacion"], data["dst_pt"], data["precision"], data["distancias"]), axis=-1),
    hovertemplate=
        "<b>Operación:</b> %{customdata[0]}<br>" +
        # "<b>Latitud:</b> %{x}<br>" +
        # "<b>Longitud:</b> %{y}<br>" +
        "<b>Clasificación:</b> %{marker.color}<br>" +
        "<b>dst_pt:</b> %{customdata[1]:.2f}<br>" +
        "<b>Precisión:</b> %{customdata[2]:.2f}<br>" +
        "<b>Distancia:</b> %{customdata[3]:.2f}<br>" +
        "<extra></extra>"
)

fig.update_layout(
    title=f"Clasificación de operaciones - Fix Lagartos: {fix_lagartos}",
    xaxis_title="Latitud",
    yaxis_title="Longitud"
)

fig.show()

filter = data["labels"] == "0.0"
data[filter].describe()

print(data.loc[580:590])
print(clasificaciones.mean())        