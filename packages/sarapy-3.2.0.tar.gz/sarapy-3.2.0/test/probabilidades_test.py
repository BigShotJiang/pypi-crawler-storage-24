from sarapy.utils.plotting import plotTemporalData
import pandas as pd
import numpy as np
import os
import sarapy.utils.getRawOperations as getRawOperations
from sarapy.dataProcessing import OpsProcessor
from sarapy.preprocessing import TransformInputData
from sarapy.dataProcessing import TLMSensorDataProcessor
import sarapy.stats.stats as stats

tlmsde = TLMSensorDataProcessor.TLMSensorDataProcessor()

nodo = "UPM017N"

data_path = os.path.join(os.getcwd(), f"examples\\2025-04-10\\{nodo}\\data.json")
historical_data_path = os.path.join(os.getcwd(), f"examples\\2025-04-10\\{nodo}\\historical-data.json")

raw_data = pd.read_json(data_path, orient="records").to_dict(orient="records")
raw_data2 = pd.read_json(historical_data_path, orient="records").to_dict(orient="records")

transform_input_data = TransformInputData.TransformInputData()

raw_ops = getRawOperations.getRawOperations(raw_data, raw_data2)
datum = transform_input_data.fit_transform(raw_ops)[:,2]
telemetria = tlmsde.fit_transform(datum)
mode = telemetria[:,tlmsde.dataPositions["MODEFlag"]]
dstpt = telemetria[:,tlmsde.dataPositions["DSTRPT"]]

op = OpsProcessor.OpsProcessor(classifier_file='modelos\\pipeline_rf.pkl', imputeDistances = False,
                                regresor_file='modelos\\regresor.pkl', poly_features_file='modelos\\poly_features.pkl')
op.operationsDict
data_processed = op.processOperations(raw_ops)

#paso la lista de operaciones a un dataframe
df = pd.DataFrame(data_processed)
df["mode"] = mode
df["dstpt"] = dstpt
df["nodo"] = nodo
ma = stats.getMA(df["dstpt"].values, window_size=104, mode='same')
df["dstpt_ma"] = ma
##me quedo con los datos donde mode==0
df = df[df["mode"] == 0]

#calculo el resumen del sensor
resumen = stats.resumen_sensor(df, values_col="dstpt_ma", pctbajo_value=1, pctalto_value=14)
print(resumen)
#calculo la probabilidad de saturación
prob_saturacion = stats.calcular_prob_saturacion(ma[2000:], saturation_mode="alto", umbrales=(1, 14),
                                                 alpha=0.2, beta=0.2)
print(f"Probabilidad de saturación: {prob_saturacion}")

# Definimos grilla de alpha y beta
alpha_vals = np.linspace(0, 1, 20)
beta_vals = np.linspace(0, 1, 20)

# Creamos matriz de resultados
Psat_matrix = np.zeros((len(alpha_vals), len(beta_vals)))

for i, alpha in enumerate(alpha_vals):
    for j, beta in enumerate(beta_vals):
        Psat = prob_saturacion = stats.calcular_prob_saturacion(ma, saturation_mode="alto", umbrales=(1, 14),
                                            alpha=alpha, beta=beta)
        Psat_matrix[i, j] = Psat

import matplotlib.pyplot as plt
import seaborn as sns

plt.figure(figsize=(10, 8))
sns.heatmap(Psat_matrix, xticklabels=np.round(beta_vals, 2), yticklabels=np.round(alpha_vals, 2), cmap="coolwarm")
plt.title("Evolución de Psat en función de α (vertical) y β (horizontal)")
plt.xlabel("β (peso de kurtosis)")
plt.ylabel("α (peso de skewness)")
plt.show()

colors = ["#0b3256","#fa0000"]
plotTemporalData(df, nodos = [nodo], columnas = ["dstpt_ma"], title = "DSTPT",sameFig = False, show = True,
                save = False, filename = "dstpt_plot.png", figsize=(15, 10), colors=colors)