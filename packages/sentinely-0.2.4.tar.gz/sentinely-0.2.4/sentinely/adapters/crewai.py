# CrewAI adapter — coming soon.
# Contact support@sentinely.ai to request early access.
#
# In the meantime, use sentinely.protect() directly:
#
#   from sentinely import protect
#   agent = protect(your_crew, task="your task")
