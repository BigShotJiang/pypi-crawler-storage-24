class SentinelyBlockedError(Exception):
    """Raised when risk_score >= 80."""

    def __init__(
        self,
        risk_score: int,
        reason: str,
        attack_type: str,
        action: dict,
        decision: object | None = None,
    ):
        self.risk_score = risk_score
        self.reason = reason
        self.attack_type = attack_type
        self.action = action
        self.decision = decision  # Optional CircuitDecision
        super().__init__(reason)


class SentinelyQuarantineError(Exception):
    """Raised when a memory write is quarantined."""

    def __init__(self, memory_content: str, flag_reason: str):
        self.memory_content = memory_content
        self.flag_reason = flag_reason
        super().__init__(flag_reason)


class SentinelyConfigError(Exception):
    """Raised on bad configuration at init."""
