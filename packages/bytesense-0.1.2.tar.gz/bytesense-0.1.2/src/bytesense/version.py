from __future__ import annotations

__version__: str = "0.1.2"
VERSION: tuple[int, int, int] = (0, 1, 2)
