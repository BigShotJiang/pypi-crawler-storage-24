"""VMware ESXi/vCenter Management MCP Server."""

from .server import main

__all__ = ["main"]
