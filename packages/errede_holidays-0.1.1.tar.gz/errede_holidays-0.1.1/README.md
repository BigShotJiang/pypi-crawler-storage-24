# ErredeHolidays (Python)

A Python library for calculating Dominican Republic holidays, ported from [ErredeHolidays.Net](https://github.com/dangos-dev/ErredeHolidays.Net).

## Installation

```bash
pip install errede-holidays
```

## Usage

```python
from errede_holidays import Holiday, HolidayIdentity
from datetime import date

# Get all holidays for a year
holidays_2026 = Holiday.get_all(2026)
for h in holidays_2026:
    print(f"{h.effective_date}: {h.description}")

# Check if a specific date is a holiday
from errede_holidays.holiday import is_holiday
today = date.today()
if is_holiday(today):
    print("Today is a holiday!")
```

## Features

- Calculates movable holidays according to Dominican Law 139-97.
- Supports historical and future dates.