import unittest
import json
import os
from datetime import date, datetime
from errede_holidays.holiday import Holiday, HolidayIdentity
from errede_holidays.enums import HolidayIdentity as PyHolidayIdentity

IDENTITY_MAP = {
    "NewYear": PyHolidayIdentity.NEW_YEAR,
    "SantosReyes": PyHolidayIdentity.SANTOS_REYES,
    "NuestraSenoraDeLaAltagracia": PyHolidayIdentity.NUESTRA_SENORA_DE_LA_ALTAGRACIA,
    "NatalicioDeJuanPabloDuarte": PyHolidayIdentity.NATALICIO_DE_JUAN_PABLO_DUARTE,
    "DiaDeLaIndependenciaNacional": PyHolidayIdentity.DIA_DE_LA_INDEPENDENCIA_NACIONAL,
    "DiaDelTrabajo": PyHolidayIdentity.DIA_DEL_TRABAJO,
    "ViernesSanto": PyHolidayIdentity.VIERNES_SANTO,
    "CorpusChristi": PyHolidayIdentity.CORPUS_CHRISTI,
    "DiaDeLaRestauracion": PyHolidayIdentity.DIA_DE_LA_RESTAURACION,
    "NuestraSenoraDeLasMercedes": PyHolidayIdentity.NUESTRA_SENORA_DE_LAS_MERCEDES,
    "DiaDeLaConstitucion": PyHolidayIdentity.DIA_DE_LA_CONSTITUCION,
    "DiaDeNavidad": PyHolidayIdentity.DIA_DE_NAVIDAD
}

class TestHolidaysCompliance(unittest.TestCase):
    def setUp(self):
        base_dir = os.path.dirname(__file__)
        possible_paths = [
            os.path.join(base_dir, '../../ErredeHolidays.Net/holidays_dump.json'),
            os.path.join(base_dir, '../holidays_dump.json'),
            'holidays_dump.json'
        ]
        
        json_path = None
        for path in possible_paths:
            if os.path.exists(path):
                json_path = path
                break
        
        if not json_path:
            self.skipTest("Reference data 'holidays_dump.json' not found.")
        
        with open(json_path, 'r', encoding='utf-8') as f:
            self.reference_data = json.load(f)

    def test_all_years_match_reference(self):
        holidays_by_year = {}
        for item in self.reference_data:
            year = item['Year']
            if year not in holidays_by_year:
                holidays_by_year[year] = []
            holidays_by_year[year].append(item)

        for year, expected_holidays in holidays_by_year.items():
            with self.subTest(year=year):
                actual_holidays = Holiday.get_all(year)
                self.assertEqual(len(actual_holidays), len(expected_holidays), f"Mismatch in number of holidays for year {year}")

                actual_holidays.sort(key=lambda x: x.original_date)
                expected_holidays.sort(key=lambda x: x['OriginalDate'])

                for i, expected in enumerate(expected_holidays):
                    actual = actual_holidays[i]
                    
                    expected_identity = IDENTITY_MAP[expected['Title']]
                    self.assertEqual(actual.title, expected_identity, f"Identity mismatch in {year}")

                    expected_orig = datetime.strptime(expected['OriginalDate'], "%Y-%m-%d").date()
                    self.assertEqual(actual.original_date, expected_orig, f"Original Date mismatch for {actual.title} in {year}")

                    expected_eff = datetime.strptime(expected['EffectiveDate'], "%Y-%m-%d").date()
                    self.assertEqual(actual.effective_date, expected_eff, f"Effective Date mismatch for {actual.title} in {year}")

                    self.assertEqual(actual.is_immovable, expected['IsImmovable'], f"IsImmovable mismatch for {actual.title} in {year}")

if __name__ == '__main__':
    unittest.main()
