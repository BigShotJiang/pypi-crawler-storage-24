from enum import Enum

class HolidayIdentity(str, Enum):
    NEW_YEAR = "Año Nuevo"
    SANTOS_REYES = "Santos Reyes"
    NUESTRA_SENORA_DE_LA_ALTAGRACIA = "Nuestra Señora de la Altagracia"
    NATALICIO_DE_JUAN_PABLO_DUARTE = "Natalicio de Juan Pablo Duarte"
    DIA_DE_LA_INDEPENDENCIA_NACIONAL = "Día de la Independencia Nacional"
    DIA_DEL_TRABAJO = "Día del Trabajo"
    VIERNES_SANTO = "Viernes Santo"
    CORPUS_CHRISTI = "Corpus Christi"
    DIA_DE_LA_RESTAURACION = "Día de la Restauración"
    NUESTRA_SENORA_DE_LAS_MERCEDES = "Nuestra Señora de las Mercedes"
    DIA_DE_LA_CONSTITUCION = "Día de la Constitución"
    DIA_DE_NAVIDAD = "Día de Navidad"
