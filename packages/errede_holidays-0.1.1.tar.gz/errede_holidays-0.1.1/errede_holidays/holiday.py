from datetime import date, timedelta
from typing import Optional, List
from .enums import HolidayIdentity

class Holiday:
    def __init__(self, title: HolidayIdentity, original_date: date):
        self.title = title
        self.original_date = original_date
        
        # Calculate if immovable and effective date
        self.is_immovable = self._is_immovable(title, original_date)
        if self.is_immovable:
            self.effective_date = original_date
        else:
            self.effective_date = self._move_to_nearest_monday(title, original_date)

    @property
    def description(self) -> str:
        return self.title.value

    def __repr__(self) -> str:
        return f"<Holiday: {self.title.name} ({self.effective_date})>"

    def __eq__(self, other):
        if not isinstance(other, Holiday):
            return False
        return (
            self.title == other.title and 
            self.original_date == other.original_date and
            self.effective_date == other.effective_date
        )

    @classmethod
    def get_all(cls, year: Optional[int] = None) -> List['Holiday']:
        holiday_year = year if year is not None else date.today().year
        easter_date = cls.get_easter_date(holiday_year)

        return [
            cls(HolidayIdentity.NEW_YEAR, date(holiday_year, 1, 1)),
            cls(HolidayIdentity.SANTOS_REYES, date(holiday_year, 1, 6)),
            cls(HolidayIdentity.NUESTRA_SENORA_DE_LA_ALTAGRACIA, date(holiday_year, 1, 21)),
            cls(HolidayIdentity.NATALICIO_DE_JUAN_PABLO_DUARTE, date(holiday_year, 1, 26)),
            cls(HolidayIdentity.DIA_DE_LA_INDEPENDENCIA_NACIONAL, date(holiday_year, 2, 27)),
            cls(HolidayIdentity.DIA_DEL_TRABAJO, date(holiday_year, 5, 1)),
            cls(HolidayIdentity.VIERNES_SANTO, easter_date - timedelta(days=2)),
            cls(HolidayIdentity.CORPUS_CHRISTI, easter_date + timedelta(days=60)),
            cls(HolidayIdentity.DIA_DE_LA_RESTAURACION, date(holiday_year, 8, 16)),
            cls(HolidayIdentity.NUESTRA_SENORA_DE_LAS_MERCEDES, date(holiday_year, 9, 24)),
            cls(HolidayIdentity.DIA_DE_LA_CONSTITUCION, date(holiday_year, 11, 6)),
            cls(HolidayIdentity.DIA_DE_NAVIDAD, date(holiday_year, 12, 25))
        ]

    @staticmethod
    def get_holiday(identity: HolidayIdentity, year: Optional[int] = None) -> Optional['Holiday']:
        for h in Holiday.get_all(year):
            if h.title == identity:
                return h
        return None

    @staticmethod
    def get_easter_date(year: int) -> date:
        """
        Calculates Easter date using simplified Gauss algorithm.
        """
        a = year % 19
        b = year % 4
        c = year % 7
        d = year // 100
        e = (13 + 8 * d) // 25

        m = d // 4
        n = (15 - e + d - m) % 30

        p = (4 + d - m) % 7
        q = (19 * a + n) % 30
        r = (2 * b + 4 * c + 6 * q + p) % 7

        if q + r > 9:       # April
            month = 4
            day = q + r - 9
        else:               # March
            month = 3
            day = 22 + q + r

        easter_date = date(year, month, day)

        # Exception 1: If Easter is April 26, move to previous week
        # Exception 2: If Easter is April 25, r==6, and a > 10, move to previous week
        if easter_date.month == 4:
            if easter_date.day == 26:
                easter_date -= timedelta(days=7)
            elif easter_date.day == 25 and r == 6 and a > 10:
                easter_date -= timedelta(days=7)

        return easter_date

    @staticmethod
    def _move_to_nearest_monday(holiday: HolidayIdentity, dt: date) -> date:
        # Labor Day exception: if falling on Sunday, move to Monday
        if holiday == HolidayIdentity.DIA_DEL_TRABAJO and dt.weekday() == 6:  # 6 is Sunday
            return dt + timedelta(days=1)

        # If already Monday (0), Saturday (5), or Sunday (6), do not move
        if dt.weekday() in (0, 5, 6):
            return dt

        # Tuesday (1) or Wednesday (2) -> Move to previous Monday
        if dt.weekday() in (1, 2):
            return dt - timedelta(days=dt.weekday())
        
        # Thursday (3) or Friday (4) -> Move to next Monday
        if dt.weekday() in (3, 4):
            return dt + timedelta(days=7 - dt.weekday())

        return dt

    @staticmethod
    def _is_immovable(holiday: HolidayIdentity, dt: date) -> bool:
        if holiday in (
            HolidayIdentity.NEW_YEAR,
            HolidayIdentity.NUESTRA_SENORA_DE_LA_ALTAGRACIA,
            HolidayIdentity.DIA_DE_LA_INDEPENDENCIA_NACIONAL,
            HolidayIdentity.NUESTRA_SENORA_DE_LAS_MERCEDES,
            HolidayIdentity.VIERNES_SANTO,
            HolidayIdentity.CORPUS_CHRISTI,
            HolidayIdentity.DIA_DE_NAVIDAD
        ):
            return True
            
        if holiday == HolidayIdentity.DIA_DE_LA_RESTAURACION:
            # Change of government every 4 years (e.g., 2020, 2024)
            return dt.year % 4 == 0

        return False

def is_holiday(check_date: date) -> bool:
    holidays = Holiday.get_all(check_date.year)
    return any(h.effective_date == check_date for h in holidays)
