"""Boss CLI — A terminal client for Boss Zhipin (BOSS直聘)."""

__version__ = "0.2.0"
