"""Research Plugins — 487 academic research skills, 150 MCP configs & 13 agent tools for AI agents."""

__version__ = "1.2.3"
