"""Tests for FTS search logic."""

from takeseek.db import Database
from takeseek.search import search_clips, _sanitize_fts_query


class TestSanitizeQuery:
    def test_simple_query(self):
        assert _sanitize_fts_query("hello world") == "hello world"

    def test_empty_query(self):
        assert _sanitize_fts_query("") == ""

    def test_whitespace_only(self):
        assert _sanitize_fts_query("   ") == ""

    def test_special_chars_stripped(self):
        result = _sanitize_fts_query("hello! @world#")
        assert "!" not in result
        assert "@" not in result
        assert "#" not in result

    def test_fts5_operators_preserved(self):
        result = _sanitize_fts_query("cat AND dog")
        assert "AND" in result

    def test_hyphen_preserved(self):
        result = _sanitize_fts_query("high-speed")
        assert "high-speed" in result


class TestSearchClips:
    def test_search_transcripts(self, tmp_path):
        db = Database(tmp_path / "search_test.db")
        clip_id = db.upsert_clip(
            file_path="/test/video.mp4", file_name="video.mp4", file_size=100
        )
        db.insert_transcript_segments(clip_id, [
            {"start": 0.0, "end": 5.0, "text": "The elephant walked through the savanna"},
            {"start": 5.0, "end": 10.0, "text": "Birds chirped in the trees"},
        ])

        results = search_clips(db, "elephant")
        assert len(results) == 1
        assert results[0]["source"] == "transcript"
        assert results[0]["clip_id"] == clip_id

        db.close()

    def test_search_frames(self, tmp_path):
        db = Database(tmp_path / "search_test.db")
        clip_id = db.upsert_clip(
            file_path="/test/video.mp4", file_name="video.mp4", file_size=100
        )
        db.insert_frame_descriptions(clip_id, [
            {"timestamp": 0.0, "description": "A red sports car driving on a highway"},
            {"timestamp": 30.0, "description": "A mountain landscape with snow"},
        ])

        results = search_clips(db, "mountain")
        assert len(results) == 1
        assert results[0]["source"] == "frame"

        db.close()

    def test_search_both_sources(self, tmp_path):
        db = Database(tmp_path / "search_test.db")
        clip_id = db.upsert_clip(
            file_path="/test/video.mp4", file_name="video.mp4", file_size=100
        )
        db.insert_transcript_segments(clip_id, [
            {"start": 0.0, "end": 5.0, "text": "Look at that beautiful sunset"},
        ])
        db.insert_frame_descriptions(clip_id, [
            {"timestamp": 10.0, "description": "A beautiful sunset over the ocean"},
        ])

        results = search_clips(db, "sunset")
        assert len(results) == 2
        sources = {r["source"] for r in results}
        assert "transcript" in sources
        assert "frame" in sources

        db.close()

    def test_search_empty_query(self, tmp_path):
        db = Database(tmp_path / "search_test.db")
        results = search_clips(db, "")
        assert results == []
        db.close()

    def test_search_no_results(self, tmp_path):
        db = Database(tmp_path / "search_test.db")
        clip_id = db.upsert_clip(
            file_path="/test/video.mp4", file_name="video.mp4", file_size=100
        )
        db.insert_transcript_segments(clip_id, [
            {"start": 0.0, "end": 5.0, "text": "Hello world"},
        ])

        results = search_clips(db, "xyznonexistent")
        assert results == []

        db.close()
