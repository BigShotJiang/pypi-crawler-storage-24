"""TakeSeek — index and search a local video library."""

__version__ = "0.1.0"

DEFAULT_DB_PATH = "takeseek.db"
