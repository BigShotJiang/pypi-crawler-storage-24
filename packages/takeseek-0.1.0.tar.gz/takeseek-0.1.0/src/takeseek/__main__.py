"""Allow running as: python -m takeseek.server"""

from .server import main

main()
