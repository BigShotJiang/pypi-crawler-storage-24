# Allure Report Summarizer

A Python utility for analyzing and summarizing Allure test reports. This tool extracts detailed test execution statistics, timing information, and test status data from Allure HTML reports, providing comprehensive insights into test suite performance.

## Features

- **Test Execution Statistics**: Extracts total, passed, failed, broken, skipped, and unknown test counts
- **Timing Analysis**: Provides start time, stop time, and duration of test executions
- **Pass Rate Calculation**: Automatically calculates test suite pass rates
- **Unique Test Tracking**: Identifies and counts unique test cases by status
- **JSON Export**: Saves failed and passed test IDs to separate JSON files for further analysis
- **Multiple Output Formats**: Supports both console output and file-based summaries
- **Robust File Handling**: Handles various file encodings (UTF-8, Latin1, CP1252, ISO-8859-1)
- **Environment Configuration**: Configurable via environment variables

## Installation

### Requirements
- Python 3.6+
- Allure HTML report files

### Install from PyPI
```bash
pip install allure-report-analyzer
```

### Set environment variables
```bash
# Set the path for JSON output files (default: c:\reports\json_files)
export JSON_FILE_PATH="path/to/your/json/output"

# Set the Allure report directory path
export ALLURE_REPORT_PATH="path/to/allure/reports"
```

## Usage

### Command Line Usage

The CLI supports three main workflows:

1. Summarize a report from `ALLURE_REPORT_PATH`
2. Parse all matching Allure HTML reports in a directory with `--all`
3. Print runtime analytics from a generated JSON file with `--stats`

Example commands:

```bash
# Use the report directory from the environment variable
export ALLURE_REPORT_PATH="/path/to/allure/reports"
python allure_report_summarizer/report_summarize.py

# Save failed test IDs
python allure_report_summarizer/report_summarize.py --fail

# Save passed test IDs
python allure_report_summarizer/report_summarize.py --pass

# Parse all Allure HTML files under the report directory
python allure_report_summarizer/report_summarize.py --all

# Load runtime statistics from a JSON file
python allure_report_summarizer/report_summarize.py --stats path/to/test_runtime_data.json
```

You can also pass a report directory as the first positional argument. When present, the script first checks `ALLURE_REPORT_PATH`; if that location is not available, it falls back to the supplied path.

The script rejects common typoed flags:

```bash
-all    # use --all
-stat   # use --stats
--stat  # use --stats
```

Default execution does the following:

1. Resolves the report directory from `ALLURE_REPORT_PATH` or the first positional argument
2. Summarizes the report when running in single-report mode
3. Generates aggregated runtime data
4. Removes duplicate test IDs while keeping the most recent execution

### Python API Usage

```python
from report_summarize import summarize_html_report, save_summary_to_file, get_unique_test_count

# Summarize a report
summary = summarize_html_report("path/to/report.html")
print(summary)

# Output:
# {
#     'start_time': '2024-03-01 10:00:00',
#     'stop_time': '2024-03-01 11:00:00',
#     'duration': '1 hours 0 minutes 0 seconds',
#     'total': 100,
#     'passed': 90,
#     'failed': 10,
#     'broken': 0,
#     'skipped': 0,
#     'unknown': 0,
#     'pass_rate': '90.00%'
# }

# Save summary to file
save_summary_to_file(summary, "report_summary.txt")

# Get detailed test statistics
test_stats = get_unique_test_count("path/to/report.html")
print(f"Failed tests: {len(test_stats['failed'])}")
print(f"Passed tests: {len(test_stats['passed'])}")
```

### Advanced Usage

```python
from report_summarize import (
    get_report_path,
    get_summary_message,
    get_file_size_in_mb,
    read_html_file,
    extract_test_data
)

# Get the latest report file path
report_path = get_report_path("/path/to/reports")

# Read HTML content with encoding handling
content = read_html_file(report_path)

# Extract test data
test_data = extract_test_data(content)

# Get file size
size = get_file_size_in_mb(report_path)
print(f"Report size: {size}")

# Generate formatted message
summary = summarize_html_report(report_path)
message = get_summary_message(summary)
print(message)
```

## Configuration

### Environment Variables

| Variable | Description | Default |
|----------|-------------|---------|
| `ALLURE_REPORT_PATH` | Directory containing Allure HTML reports | Required (no default) |
| `JSON_FILE_PATH` | Directory for JSON output files | `c:\reports\json_files` |

### Output Files

The script can generate the following files in the `JSON_FILE_PATH` directory:
- `failed_testscripts.json`: List of failed test case IDs when `--fail` is used
- `passed_testscripts.json`: List of passed test case IDs when `--pass` is used
- `test_runtime_data.json`: Deduplicated runtime data used for runtime analysis

Temporary files created during aggregation are cleaned up automatically:
- `processed_data.json`
- `test_execution.json`

## API Reference

### Core Functions

#### `summarize_html_report(report_path: str) -> Dict[str, Any]`
Summarizes an Allure HTML report and returns statistics.

**Parameters:**
- `report_path`: Path to the Allure HTML report file

**Returns:**
- Dictionary with test execution statistics

#### `get_unique_test_count(html_file_path: str) -> Dict[str, List[str]]`
Analyzes test results and returns unique test counts by status.

**Parameters:**
- `html_file_path`: Path to the HTML report file

**Returns:**
- Dictionary with lists of test IDs by status

#### `save_summary_to_file(summary: Dict[str, Any], file_path: str)`
Saves summary data to a text file.

#### `get_report_path(attachment_path: str) -> str`
Gets the path to the latest report file in a directory.

### Utility Functions

#### `get_filename(directory: str) -> str`
Gets the first HTML file found in a directory.

#### `read_html_file(html_file: str) -> Optional[str]`
Reads an HTML file with multiple encoding fallbacks.

#### `extract_test_data(html_content: str) -> Optional[Dict]`
Extracts test data from embedded JSON in HTML content.

#### `get_file_size_in_mb(file_path: str) -> str`
Returns file size in megabytes.

## Error Handling

The module includes comprehensive error handling for:
- File not found errors
- Invalid JSON data
- Encoding issues
- Missing data fields
- Directory access problems

All errors are logged to console with descriptive messages.

## CLI Options

| Option | Description |
|--------|-------------|
| `--all` | Parse all Allure HTML reports found under the resolved report directory |
| `--stats <json_file_path>` | Load and print runtime statistics from an existing JSON file |
| `--fail` | Export failed test IDs to `failed_testscripts.json` |
| `--pass` | Export passed test IDs to `passed_testscripts.json` |

## Examples

### Basic Report Analysis
```python
from report_summarize import summarize_html_report

# Analyze a single report
summary = summarize_html_report("allure-report/index.html")
for key, value in summary.items():
    print(f"{key}: {value}")
```

### Batch Processing Multiple Reports
```python
import os
from report_summarize import summarize_html_report

reports_dir = "/path/to/reports"
for filename in os.listdir(reports_dir):
    if filename.endswith('.html'):
        report_path = os.path.join(reports_dir, filename)
        summary = summarize_html_report(report_path)
        print(f"Report: {filename}")
        print(f"Pass Rate: {summary['pass_rate']}")
```

### Runtime Statistics From JSON
```bash
python allure_report_summarizer/report_summarize.py --stats path/to/test_runtime_data.json
```

This command prints:
- overall pass, fail, and broken counts
- total and average runtime
- slowest tests
- tests with high scenario counts
- execution statistics grouped by report file

### Custom Output Formatting
```python
from report_summarize import summarize_html_report, get_unique_test_count

report_path = "allure-report/index.html"
summary = summarize_html_report(report_path)
test_stats = get_unique_test_count(report_path)

print("=== TEST EXECUTION SUMMARY ===")
print(f"Duration: {summary['duration']}")
print(f"Total Tests: {len(test_stats['total'])}")
print(f"Passed: {len(test_stats['passed'])}")
print(f"Failed: {len(test_stats['failed'])}")
print(f"Pass Rate: {summary['pass_rate']}")

if test_stats['failed']:
    print("\nFailed Test IDs:")
    for test_id in test_stats['failed'][:10]:  # Show first 10
        print(f"  - {test_id}")
    if len(test_stats['failed']) > 10:
        print(f"  ... and {len(test_stats['failed']) - 10} more")
```

## Dependencies

- Python 3.6+
- Standard library modules: `json`, `os`, `re`, `datetime`, `typing`

## License

MIT License