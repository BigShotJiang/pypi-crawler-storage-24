# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.0.3] - 2025-03-14

### Changed
- **report_parser**: Replaced XLSX/Excel file format with JSON across all modules
  - `bdd_reportparser.py`: Uses `test_cases.json`, `processed_data.json`, `test_runtime_data.json`, `sorted_test_runtime_data.json` instead of `.xlsx` files
  - `automation_run_stats.py`: Loads `sorted_test_runtime_data.json` instead of `sorted_test_runtime_data.xlsx`
  - `arkus_cs_reportparser.py`: Outputs `testcases.json` only (removed Excel conversion)

### Removed
- `openpyxl` dependency from report_parser (no longer required)

## [1.0.0] - 2025-02-04

### Added
- Initial release of Allure Report Summarizer
- Comprehensive Allure HTML report analysis functionality
- Test execution statistics extraction (total, passed, failed, broken, skipped, unknown)
- Timing information processing (start time, stop time, duration)
- Pass rate calculation
- Unique test case identification and counting
- JSON export of failed and passed test IDs
- Multiple file encoding support (UTF-8, Latin1, CP1252, ISO-8859-1)
- Environment variable configuration support
- Command-line interface for batch processing
- Python API for programmatic usage
- Comprehensive error handling and logging
- File size reporting utility
- Summary output in both console and file formats

### Features
- Robust HTML parsing with embedded JSON extraction
- Test status correction based on step-level failures
- Automatic directory creation for output files
- Configurable output paths via environment variables
- Detailed documentation and examples

### Technical Details
- Pure Python implementation using only standard library
- Compatible with Python 3.6+
- Cross-platform support (Windows, Linux, macOS)
- No external dependencies required

---

## Types of changes
- `Added` for new features
- `Changed` for changes in existing functionality
- `Deprecated` for soon-to-be removed features
- `Removed` for now removed features
- `Fixed` for any bug fixes
- `Security` in case of vulnerabilities