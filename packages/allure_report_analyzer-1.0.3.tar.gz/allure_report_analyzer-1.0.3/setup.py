"""
Setup script for Allure Report Analyzer package.

This setup.py is minimal and relies on pyproject.toml for configuration.
"""

from setuptools import setup

# Minimal setup - configuration is in pyproject.toml
setup()
