"""
Allure Report Analyzer - Analyze and summarize Allure test reports.

This package provides functionality to extract detailed test execution statistics,
timing information, and test status data from Allure HTML reports.
"""

from .report_summarize import (
    extract_test_cases_by_uid,
    extract_test_data,
    get_file_size_in_mb,
    get_report_path,
    get_summary_message,
    get_test_ids_by_status,
    get_unique_test_count,
    read_html_file,
    save_summary_to_file,
    summarize_allure_report,
    summarize_html_report,
    write_failed_test_ids_to_file,
    write_passed_test_ids_to_file,
)

__version__ = "1.0.3"
__author__ = "Pandiyaraj Karuppasamy"
__email__ = "pandiyarajk@live.com"
__license__ = "MIT"
__description__ = "Analyze and summarize Allure test reports"

__all__ = [
    "summarize_html_report",
    "get_unique_test_count",
    "save_summary_to_file",
    "get_report_path",
    "get_summary_message",
    "get_file_size_in_mb",
    "read_html_file",
    "extract_test_data",
    "extract_test_cases_by_uid",
    "get_test_ids_by_status",
    "write_failed_test_ids_to_file",
    "write_passed_test_ids_to_file",
    "summarize_allure_report",
]
