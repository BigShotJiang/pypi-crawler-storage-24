"""Integration tests for ProjectHephaestus."""
