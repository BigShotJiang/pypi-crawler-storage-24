"""
fractal-search — Multi-scale document search with φ-weighted decay.

Search meaning, not just text. Documents are indexed at multiple scales
(document → section → paragraph) and results are weighted by the golden
ratio for optimal relevance decay.

Usage:
    from fractal_search import FractalSearchEngine

    engine = FractalSearchEngine()
    engine.add("doc1", "My Paper", "Content about fractals and patterns...")
    engine.add("doc2", "My Notes", "Something about cooking...")

    results = engine.search("fractal patterns")
    for r in results:
        print(f"{r.score:.2f}  {r.title}")
"""

from .engine import FractalSearchEngine, SearchResult
from .cli import main as cli_main

__version__ = "0.1.1"
__all__ = ["FractalSearchEngine", "SearchResult"]
