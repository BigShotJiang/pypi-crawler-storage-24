"""Kandiga: Run 35B AI models in 1.5GB of RAM."""
__version__ = "0.1.0"
