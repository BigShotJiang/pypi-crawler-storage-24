"""Kandiga CLI — Run 35B AI models in 1.5GB of RAM."""

from __future__ import annotations

import argparse
import sys


def main():
    parser = argparse.ArgumentParser(
        prog="kandiga",
        description="Kandiga \u2014 Run 35B AI models in 1.5GB of RAM",
    )
    subparsers = parser.add_subparsers(dest="command")

    # kandiga setup
    setup_parser = subparsers.add_parser(
        "setup", help="Download model and prepare expert files"
    )
    setup_parser.add_argument(
        "--model",
        default="mlx-community/Qwen3.5-35B-A3B-4bit",
        help="HuggingFace model ID (default: Qwen3.5-35B-A3B-4bit)",
    )

    # kandiga chat
    chat_parser = subparsers.add_parser("chat", help="Interactive chat")
    chat_parser.add_argument(
        "--fast", action="store_true", help="K=4 mode (~6.5 tok/s, slightly lower quality)"
    )
    chat_parser.add_argument(
        "--tools", action="store_true", help="Enable web search + file access"
    )
    chat_parser.add_argument(
        "--model",
        default="mlx-community/Qwen3.5-35B-A3B-4bit",
        help="HuggingFace model ID",
    )
    chat_parser.add_argument(
        "--max-tokens",
        type=int,
        default=2048,
        help="Maximum tokens per response (default: 2048)",
    )

    # kandiga serve
    serve_parser = subparsers.add_parser("serve", help="Start OpenAI-compatible HTTP API")
    serve_parser.add_argument(
        "--port", type=int, default=8340, help="Port to listen on (default: 8340)"
    )
    serve_parser.add_argument(
        "--fast", action="store_true", help="K=4 mode"
    )
    serve_parser.add_argument(
        "--model",
        default="mlx-community/Qwen3.5-35B-A3B-4bit",
        help="HuggingFace model ID",
    )

    # kandiga bench
    subparsers.add_parser("bench", help="Run inference benchmarks")

    # Top-level flags for default (chat) mode
    parser.add_argument(
        "--fast", action="store_true", help="K=4 mode"
    )
    parser.add_argument(
        "prompt", nargs="*", help="One-shot prompt (omit to enter interactive chat)"
    )

    args = parser.parse_args()

    if args.command == "setup":
        from kandiga.setup import run_setup

        run_setup(args.model)
    elif args.command == "chat":
        from kandiga.chat import run_chat

        run_chat(
            fast=args.fast,
            tools=args.tools,
            model=args.model,
            max_tokens=args.max_tokens,
        )
    elif args.command == "serve":
        from kandiga.serve import run_serve

        run_serve(port=args.port, fast=args.fast, model=args.model)
    elif args.command == "bench":
        from kandiga.bench import run_bench

        run_bench()
    else:
        # Default: if prompt given, one-shot. Otherwise, interactive chat.
        if args.prompt:
            from kandiga.chat import one_shot

            one_shot(" ".join(args.prompt), fast=args.fast)
        else:
            from kandiga.chat import run_chat

            run_chat(fast=args.fast)


if __name__ == "__main__":
    main()
