from _typeshed import Incomplete
from aip_agents.middleware.backends.protocol import BackendProtocol, EditResult, ExecuteResult, FileInfo, GrepMatch, WriteResult
from aip_agents.sandbox.e2b_runtime import E2BSandboxRuntime
from typing import Any

__all__ = ['SandboxBackend']

class SandboxBackend(BackendProtocol):
    """BackendProtocol implementation backed by E2B sandbox files API."""
    template: Incomplete
    base_dir: Incomplete
    allow_execute: Incomplete
    timeout_seconds: Incomplete
    auto_build_template: Incomplete
    def __init__(self, template: str | None = ..., base_dir: str = '/workspace', allow_execute: bool = True, timeout_seconds: int = 300, auto_build_template: bool = True, runtime: E2BSandboxRuntime | None = None) -> None:
        '''Initialize sandbox backend.

        Args:
            template: E2B template ID. Defaults to ``DEFAULT_SANDBOX_TEMPLATE``
                (``"aip-agents-sandbox-v1"``). If that template fails to create,
                the runtime falls back to E2B\'s default code-interpreter template.
                Pass ``None`` to always use E2B\'s default template directly.
                The template must include a running Jupyter kernel on port 49999;
                otherwise ``execute`` calls will fail with a "port is not open"
                502 error.
            base_dir: Base workspace directory inside sandbox.
            allow_execute: Whether execute is enabled.
            timeout_seconds: Default runtime execution timeout.
            auto_build_template: If True and the requested template returns 404,
                automatically build it before falling back to the default sandbox.
                Building can take several minutes. Defaults to False.
            runtime: Optional injected runtime for testing or sharing.
        '''
    @property
    def runtime(self) -> E2BSandboxRuntime:
        """Get initialized runtime.

        Raises:
            RuntimeError: If runtime was not initialized yet.
        """
    def ls_info(self, path: str) -> list[FileInfo]:
        """List files and subdirectories at *path* (synchronous).

        Synchronous wrapper around :meth:`als_info`.

        Args:
            path: Workspace-relative or absolute path of the directory to list.

        Returns:
            A list of :class:`~aip_agents.middleware.backends.protocol.FileInfo`
            objects describing each entry in the directory.
        """
    async def als_info(self, path: str) -> list[FileInfo]:
        """List files and subdirectories at *path* (async).

        Resolves *path* to an absolute sandbox path, calls the E2B files
        client ``list`` API, and converts the raw entries into
        :class:`~aip_agents.middleware.backends.protocol.FileInfo` objects
        with workspace-relative paths.

        Args:
            path: Workspace-relative or absolute path of the directory to list.

        Returns:
            A list of :class:`~aip_agents.middleware.backends.protocol.FileInfo`
            objects describing each entry in the directory.
        """
    def read(self, file_path: str, offset: int = 0, limit: int = 2000) -> str:
        """Read a file's contents with line numbers (synchronous).

        Synchronous wrapper around :meth:`aread`.

        Args:
            file_path: Workspace-relative or absolute path of the file to read.
            offset: Zero-based index of the first line to return. Defaults to 0.
            limit: Maximum number of lines to return. Defaults to 2000.

        Returns:
            A string of the requested lines prefixed with 1-based line numbers,
            or an empty string if the selected region is empty.
        """
    async def aread(self, file_path: str, offset: int = 0, limit: int = 2000) -> str:
        """Read a file's contents with line numbers (async).

        Reads the full file from the sandbox via the E2B files client, then
        slices the requested line window and delegates formatting to
        :func:`~aip_agents.middleware.backends.utils.format_content_with_line_numbers`.

        Args:
            file_path: Workspace-relative or absolute path of the file to read.
            offset: Zero-based index of the first line to return. Defaults to 0.
            limit: Maximum number of lines to return. Defaults to 2000.

        Returns:
            A string of the requested lines prefixed with 1-based line numbers,
            or an empty string if the selected region is empty.
        """
    async def aread_bytes(self, file_path: str) -> bytes:
        """Read file content as raw bytes (async).

        Attempts to call ``read_bytes`` on the E2B files client when available
        (avoiding a UTF-8 decode/encode round-trip); falls back to the text
        ``read`` API and encodes the result as UTF-8.

        Args:
            file_path: Workspace-relative or absolute path of the file to read.

        Returns:
            The raw byte content of the file.
        """
    def write(self, file_path: str, content: str) -> WriteResult:
        """Write *content* to a file, creating it if necessary (synchronous).

        Synchronous wrapper around :meth:`awrite`.

        Args:
            file_path: Workspace-relative or absolute destination path.
            content: Text content to write.

        Returns:
            A :class:`~aip_agents.middleware.backends.protocol.WriteResult`
            indicating success and the resolved path.
        """
    async def awrite(self, file_path: str, content: str) -> WriteResult:
        """Write *content* to a file, creating it if necessary (async).

        Resolves *file_path* to an absolute sandbox path and delegates to the
        E2B files client ``write`` API.  Parent directories are created
        automatically by the sandbox runtime.

        Args:
            file_path: Workspace-relative or absolute destination path.
            content: Text content to write.

        Returns:
            A :class:`~aip_agents.middleware.backends.protocol.WriteResult`
            indicating success and the resolved path.
        """
    def edit(self, file_path: str, old_string: str, new_string: str, replace_all: bool = False) -> EditResult:
        """Replace a string inside a file (synchronous).

        Synchronous wrapper around :meth:`aedit`.

        Args:
            file_path: Workspace-relative or absolute path of the file to edit.
            old_string: The exact substring to search for.
            new_string: The replacement text.
            replace_all: When ``True``, replace every occurrence of
                *old_string*; when ``False`` (default), replace only the
                first occurrence.

        Returns:
            An :class:`~aip_agents.middleware.backends.protocol.EditResult`
            with ``success=True`` and an occurrence count on success, or
            ``success=False`` and an ``error`` message on failure.
        """
    async def aedit(self, file_path: str, old_string: str, new_string: str, replace_all: bool = False) -> EditResult:
        """Replace a string inside a file (async).

        Reads the current file content from the sandbox, performs the string
        replacement via
        :func:`~aip_agents.middleware.backends.utils.perform_string_replacement`,
        and writes the result back.  Returns an error result if the file does
        not exist or the replacement fails.

        Args:
            file_path: Workspace-relative or absolute path of the file to edit.
            old_string: The exact substring to search for.
            new_string: The replacement text.
            replace_all: When ``True``, replace every occurrence of
                *old_string*; when ``False`` (default), replace only the
                first occurrence.

        Returns:
            An :class:`~aip_agents.middleware.backends.protocol.EditResult`
            with ``success=True`` and an occurrence count on success, or
            ``success=False`` and an ``error`` message on failure.
        """
    def glob_info(self, pattern: str, path: str = '/') -> list[FileInfo]:
        '''Find files matching a glob pattern (synchronous).

        Synchronous wrapper around :meth:`aglob_info`.

        Args:
            pattern: A glob pattern (e.g. ``"**/*.py"``) matched against
                workspace-relative paths and bare file names.
            path: Root directory to search.  Defaults to the workspace root
                (``"/"``).

        Returns:
            A list of :class:`~aip_agents.middleware.backends.protocol.FileInfo`
            objects for all matching entries.
        '''
    async def aglob_info(self, pattern: str, path: str = '/') -> list[FileInfo]:
        '''Find files matching a glob pattern (async).

        Recursively lists all entries under *path* using the E2B files client
        and filters them with :func:`fnmatch.fnmatch` against both the
        workspace-relative path and the bare file name.

        Args:
            pattern: A glob pattern (e.g. ``"**/*.py"``) matched against
                workspace-relative paths and bare file names.
            path: Root directory to search.  Defaults to the workspace root
                (``"/"``).

        Returns:
            A list of :class:`~aip_agents.middleware.backends.protocol.FileInfo`
            objects for all matching entries.
        '''
    def grep_raw(self, pattern: str, path: str | None = None) -> list[GrepMatch] | str:
        """Search for a text pattern across files (synchronous).

        Synchronous wrapper around :meth:`agrep_raw`.

        Args:
            pattern: Literal string to search for (passed to ``rg -F``).
            path: Directory or file to search within.  Defaults to
                ``base_dir`` when ``None``.

        Returns:
            A list of :class:`~aip_agents.middleware.backends.protocol.GrepMatch`
            objects on success, or an error string if ``ripgrep`` returned a
            non-zero exit code other than 1 (no matches).
        """
    async def agrep_raw(self, pattern: str, path: str | None = None) -> list[GrepMatch] | str:
        """Search for a text pattern across files using ripgrep (async).

        Executes ``rg --json -F`` inside the sandbox and parses the
        newline-delimited JSON output to produce structured match records.
        Uses a fixed-string (``-F``) search to avoid regex injection.

        Args:
            pattern: Literal string to search for.
            path: Directory or file to search within.  Defaults to
                ``base_dir`` when ``None``.

        Returns:
            A list of :class:`~aip_agents.middleware.backends.protocol.GrepMatch`
            objects on success.  Returns an empty list when ripgrep exits with
            code 1 (no matches found).  Returns the ``stderr`` string (or a
            generic error message) when ripgrep exits with code ≥ 2.
        """
    def grep(self, pattern: str, path: str | None = None) -> list[GrepMatch]:
        """Search for a text pattern, always returning a list (synchronous).

        Calls :meth:`grep_raw` and suppresses the error-string variant,
        returning an empty list whenever the underlying search fails.

        Args:
            pattern: Literal string to search for.
            path: Directory or file to search within.  Defaults to
                ``base_dir`` when ``None``.

        Returns:
            A (possibly empty) list of
            :class:`~aip_agents.middleware.backends.protocol.GrepMatch` objects.
        """
    def execute(self, command: str, timeout: int = 30) -> ExecuteResult:
        """Execute a shell command inside the sandbox (synchronous).

        Synchronous wrapper around :meth:`aexecute`.

        Args:
            command: Shell command string to run.
            timeout: Maximum number of seconds to wait for the command to
                finish.  Defaults to 30.

        Returns:
            An :class:`~aip_agents.middleware.backends.protocol.ExecuteResult`
            containing ``stdout``, ``stderr``, and ``exit_code``.

        Raises:
            PermissionError: If ``allow_execute`` is ``False``.
        """
    async def aexecute(self, command: str, timeout: int = 30) -> ExecuteResult:
        """Execute a shell command inside the sandbox (async).

        Delegates shell execution to runtime when available. For
        :class:`E2BSandboxRuntime`, this uses its dedicated command path.

        Args:
            command: Shell command string to run.
            timeout: Maximum number of seconds to wait for the command to
                finish.  Defaults to 30.

        Returns:
            An :class:`~aip_agents.middleware.backends.protocol.ExecuteResult`
            containing ``stdout``, ``stderr``, ``exit_code``, and
            ``truncated=False``.

        Raises:
            PermissionError: If ``allow_execute`` is ``False``.
        """
    def set_files(self, files: dict[str, Any], thread_id: str = 'default') -> None:
        '''Write a batch of files into the sandbox workspace (synchronous).

        Synchronous wrapper around :meth:`aset_files`.

        Args:
            files: Mapping of workspace-relative file paths to their text
                content.  Non-string values are coerced with ``str()``.
            thread_id: Logical thread identifier (reserved for future
                partitioned workspace support). Defaults to ``"default"``.
        '''
    async def aset_files(self, files: dict[str, Any], thread_id: str = 'default') -> None:
        '''Write a batch of files into the sandbox workspace (async).

        Iterates over *files* and writes each entry to the sandbox via the E2B
        files client.  Paths are resolved relative to ``base_dir``.

        Args:
            files: Mapping of workspace-relative file paths to their text
                content.  Non-string values are coerced with ``str()``.
            thread_id: Logical thread identifier (reserved for future
                partitioned workspace support). Defaults to ``"default"``.
        '''
    def get_files(self, thread_id: str = 'default') -> dict[str, Any]:
        '''Read all files from the sandbox workspace for checkpointing (synchronous).

        Synchronous wrapper around :meth:`aget_files`.

        Args:
            thread_id: Logical thread identifier (reserved for future
                partitioned workspace support). Defaults to ``"default"``.

        Returns:
            A mapping of workspace-relative file paths to their text content.
        '''
    async def aget_files(self, thread_id: str = 'default') -> dict[str, Any]:
        '''Read all files from the sandbox workspace for checkpointing (async).

        Recursively lists all entries under ``base_dir``, skips directories,
        and reads the text content of each file via the E2B files client.

        Args:
            thread_id: Logical thread identifier (reserved for future
                partitioned workspace support). Defaults to ``"default"``.

        Returns:
            A mapping of workspace-relative file paths to their text content.
        '''
    async def cleanup(self) -> None:
        """Release all sandbox resources and reset internal state."""
