"""This file contains the Sentry and OpenTelemetry configuration for GL Connectors SDK.

Authors:
    Saul Sayers (saul.sayers@gdplabs.id)
"""

import inspect
import os
from typing import Any

from dotenv import load_dotenv
from fastapi import FastAPI
from gl_observability.initializer import FastAPIConfig, SentryBackendConfig, TelemetryConfig, init_telemetry
from gl_observability.traces.instrument.functions import FunctionsInstrumentor
from opentelemetry.sdk.trace.sampling import ParentBased, TraceIdRatioBased

from aip_agents.agent import BaseAgent, LangChainAgent, LangGraphAgent
from aip_agents.utils.logger import get_logger

load_dotenv()


logger = get_logger(__name__)

SENTRY_DSN = os.getenv("SENTRY_DSN")
SENTRY_ENVIRONMENT = os.getenv("SENTRY_ENVIRONMENT", "development")
SENTRY_PROJECT = os.getenv("SENTRY_PROJECT")
VERSION_NUMBER = os.getenv("VERSION_NUMBER", "0.0.0")
BUILD_NUMBER = os.getenv("BUILD_NUMBER", "0")
USE_OPENTELEMETRY = os.getenv("USE_OPENTELEMETRY", "true").lower() == "true"

# Lazy import of GoogleADKAgent to avoid heavy dependencies when not needed.
# This is initialized lazily by _get_classes_to_instrument() and can be
# patched by tests for mocking purposes.
CLASSES_TO_INSTRUMENT: list[type[Any]] | None = None


def _is_optional_google_adk_import_error(error: ImportError) -> bool:
    """Return True when the import failure is due to missing Google ADK extras."""
    cause = error.__cause__
    if isinstance(cause, ModuleNotFoundError) and cause.name and cause.name.startswith("google"):
        return True

    return "aip-agents[google-adk]" in str(error)


def _get_classes_to_instrument() -> list[type[Any]]:
    """Get the list of classes to instrument.

    This lazily imports GoogleADKAgent only when telemetry is being set up,
    avoiding the heavy Google ADK dependencies during module import.

    Returns:
        List of agent classes to instrument.
    """
    global CLASSES_TO_INSTRUMENT
    if CLASSES_TO_INSTRUMENT is None:
        classes_to_instrument = [
            BaseAgent,
            LangGraphAgent,
            LangChainAgent,
        ]

        try:
            from aip_agents.agent import GoogleADKAgent

            classes_to_instrument.append(GoogleADKAgent)
        except ImportError as e:
            if _is_optional_google_adk_import_error(e):
                logger.debug("Google ADK extra is not installed; skipping GoogleADKAgent instrumentation")
            else:
                raise

        CLASSES_TO_INSTRUMENT = classes_to_instrument
    return CLASSES_TO_INSTRUMENT


def get_all_methods(cls: type) -> list:
    """Get all methods from a class.

    Args:
        cls: The class to get methods from.

    Returns:
        list: A list of methods.
    """
    methods = []
    for name, member in inspect.getmembers(cls):
        if name.startswith("_"):
            continue  # skip dunder and private
        if inspect.isfunction(member) or inspect.ismethod(member) or inspect.iscoroutinefunction(member):
            methods.append(member)
    return methods


def instrument_gl_functions() -> None:
    """Instrument GL functions."""
    agent_methods = []
    for cls in _get_classes_to_instrument():
        agent_methods.extend(get_all_methods(cls))
    FunctionsInstrumentor().instrument(methods=agent_methods)


def traces_sampler(*args) -> float:
    """Determine appropriate sampling rate for Sentry transactions.

    Args:
        *args: Additional positional arguments

    Returns:
        float: Sampling rate between 0 and 1
    """
    # TODO: Dont sample healthcheck endpoints (return 0.0)
    return 1.0


def _create_telemetry_config(app: FastAPI | None) -> TelemetryConfig:
    """Build a telemetry configuration for Sentry-backed tracing.

    Args:
        app: Optional FastAPI application instance for instrumentation.

    Returns:
        TelemetryConfig instance for initializing telemetry.
    """
    backend_config = SentryBackendConfig(
        dsn=SENTRY_DSN,
        environment=SENTRY_ENVIRONMENT,
        release=f"{SENTRY_PROJECT}@{VERSION_NUMBER}+{BUILD_NUMBER}",
        send_default_pii=True,
    )

    fastapi_config = FastAPIConfig(app) if app is not None else None

    return TelemetryConfig(
        trace_sampler=ParentBased(TraceIdRatioBased(traces_sampler())),
        fastapi_config=fastapi_config,
        use_langchain=True,
        backend_config=backend_config,
    )


def setup_sentry_with_open_telemetry(app: FastAPI) -> None:
    """Configure telemetry with both Sentry and OpenTelemetry.

    Args:
        app: FastAPI application instance
    """
    try:
        telemetry_config = _create_telemetry_config(app)
        init_telemetry(telemetry_config)
        logger.info(f"Telemetry initialized with OpenTelemetry for environment: {SENTRY_ENVIRONMENT}")
    except Exception as e:
        logger.error(f"Failed to initialize telemetry with OpenTelemetry: {e}")


def setup_sentry_only() -> None:
    """Configure telemetry with Sentry only (no OpenTelemetry)."""
    try:
        telemetry_config = _create_telemetry_config(app=None)
        init_telemetry(telemetry_config)
        logger.info(f"Telemetry initialized with Sentry only for environment: {SENTRY_ENVIRONMENT}")
    except Exception as e:
        logger.error(f"Failed to initialize telemetry with Sentry only: {e}")


def setup_telemetry(app: FastAPI) -> None:
    """Configure and initialize telemetry based on configuration.

    Args:
        app: FastAPI application instance
    """
    if not SENTRY_DSN:
        logger.warning("Warning: SENTRY_DSN not set. Sentry will not be enabled.")
        return
    if USE_OPENTELEMETRY:
        setup_sentry_with_open_telemetry(app)
    else:
        setup_sentry_only()
    instrument_gl_functions()
