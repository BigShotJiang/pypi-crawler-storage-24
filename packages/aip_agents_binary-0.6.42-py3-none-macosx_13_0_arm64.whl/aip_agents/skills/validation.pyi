from aip_agents.skills.errors import SkillValidationError as SkillValidationError
from pathlib import Path

def validate_skill_name(name: str) -> None:
    """Validate a skill name against DeepAgents naming rules.

    Args:
        name (str): Skill directory name.

    Returns:
        None: This function returns None.
    """
def validate_skill_root(skill_root: Path) -> None:
    """Validate a local skill root directory.

    Args:
        skill_root (Path): Local path to the skill directory.

    Returns:
        None: This function returns None.
    """
