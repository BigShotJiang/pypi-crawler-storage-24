class SkillError(Exception):
    """Base error for skill operations."""
class SkillInstallError(SkillError):
    """Raised when a skill cannot be installed (network/auth/archive errors)."""
class SkillValidationError(SkillError):
    """Raised when a local skill path is invalid (naming, missing files, etc.)."""
class SkillMetadataError(SkillError):
    """Raised when SKILL.md metadata is invalid.

    PR-001 does not parse SKILL.md frontmatter, but later milestones will.
    """
