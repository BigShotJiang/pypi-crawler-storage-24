from __future__ import annotations

from typing import Any, Self, NewType, TypedDict, Unpack
import enum
import json
from collections.abc import Iterator

import httpx
from pydantic import BaseModel

Hash = NewType("Hash", str)


class NullClientError(Exception):
    """Base exception for null client errors."""

    pass


class RecordConflictError(NullClientError):
    """Raised when record hash conflict occurs (optimistic locking failure)."""

    def __init__(self, expected: str, current: str, message: str):
        self.expected = expected
        self.current = current
        super().__init__(message)


class RecordAlreadyDeletedError(NullClientError):
    """Raised when record is already deleted."""

    def __init__(self, deleted_at: int):
        self.deleted_at = deleted_at
        super().__init__(f"Record already deleted at {deleted_at}")


class BlobNotFoundError(NullClientError):
    def __init__(self, hash_: Hash):
        self.hash = hash_
        super().__init__(f"blob not found: {hash_}")


class AmbiguousIdError(NullClientError):
    """Raised when a short ID prefix matches multiple records."""

    def __init__(self, prefix: str, count: int):
        self.prefix = prefix
        self.count = count
        super().__init__(f"Ambiguous prefix '{prefix}' matches {count} records")


class RecordNotFoundError(NullClientError):
    """Raised when a short ID prefix matches no records."""

    def __init__(self, prefix: str):
        self.prefix = prefix
        super().__init__(f"No record found matching '{prefix}'")


class TreeNodeType(enum.StrEnum):
    """Blob type of a tree node. Trees can contain data, tree, or record blobs."""

    DATA = "data"
    TREE = "tree"
    RECORD = "record"


class SortOrder(enum.StrEnum):
    ASC = "asc"
    DESC = "desc"


class SortBy:
    """
    Sort field for list_records. Use one of the constants or SortBy.metadata(path).
    """

    CREATED_AT = "created_at"
    ID = "id"
    KIND = "kind"
    NAMESPACE = "namespace"

    @staticmethod
    def metadata(path: str) -> str:
        """Sort by a JSON metadata field. Path uses dot notation. Missing field sorts last."""
        return f"metadata:{path}"


class SortTiebreaker:
    """
    Secondary sort field to break ties in list_records when the primary sort field has equal values.

    Restricted to ``created_at``, ``id``, or a metadata field — ``kind`` and ``namespace`` are not
    accepted. The tiebreaker sorts in the same direction as ``sort_order``.

    Usage::

        list_records(sort_by=SortBy.metadata("time"), sort_tiebreaker=SortTiebreaker.CREATED_AT)
        list_records(sort_by=SortBy.metadata("time"), sort_tiebreaker=SortTiebreaker.ID)
        list_records(sort_by=SortBy.metadata("time"), sort_tiebreaker=SortTiebreaker.metadata("priority"))
    """

    CREATED_AT = "created_at"
    ID = "id"

    @staticmethod
    def metadata(path: str) -> str:
        """Break ties by a JSON metadata field. Path uses dot notation. Missing field sorts last."""
        return f"metadata:{path}"


class TreeNode(BaseModel):
    hash: Hash
    type: TreeNodeType


class TreeResponse(BaseModel):
    hash: Hash
    nodes: list[TreeNode]


class RecordResponse(BaseModel):
    hash: Hash
    id: str | None = None  # None for immutable records
    content: Hash
    content_blob_type: str | None = None  # "data" or "tree"
    prev: Hash | None = None
    kind: str
    namespace: str | None = None
    created_at: int | None = None  # None for immutable records
    deleted_at: int | None = None
    metadata: dict[str, Any] = {}
    # GC policy: keep at most this many versions per record (None = keep all)
    max_versions: int | None = None


class ListRecordVersionsResponse(BaseModel):
    versions: list[RecordResponse]


class ListRecordsResponse(BaseModel):
    records: list[RecordResponse]
    next_cursor: str | None = None
    has_more: bool


class AggregateResponse(BaseModel):
    result: Any
    records_processed: int


class BatchBlobStatus(enum.StrEnum):
    CREATED = "created"
    ALREADY_EXISTS = "already_exists"


class BatchBlobResult(BaseModel):
    hash: Hash
    status: BatchBlobStatus
    size: int


class BatchBlobsResponse(BaseModel):
    results: list[BatchBlobResult]


class CreatedAtFilter:
    """
    Filter for created_at timestamp field.

    Usage:
        from null_client import created_at

        # Records created after a timestamp
        records = client.list_records(
            created_at_filters=[created_at > 1738108800000000000]
        )

        # Records created in a time range
        records = client.list_records(
            created_at_filters=[
                created_at >= 1735908800000000000,
                created_at < 1738108800000000000,
            ]
        )
    """

    def __init__(self) -> None:
        self._op: str | None = None
        self._value: int | None = None

    def __eq__(self, value: int) -> Self:  # type: ignore[override]
        return self._create_filter("eq", value)

    def __ne__(self, value: int) -> Self:  # type: ignore[override]
        return self._create_filter("ne", value)

    def __gt__(self, value: int) -> Self:
        return self._create_filter("gt", value)

    def __lt__(self, value: int) -> Self:
        return self._create_filter("lt", value)

    def __ge__(self, value: int) -> Self:
        return self._create_filter("gte", value)

    def __le__(self, value: int) -> Self:
        return self._create_filter("lte", value)

    def _create_filter(self, op: str, value: int) -> Self:
        f = type(self)()
        f._op = op
        f._value = value
        return f

    def to_query_param(self) -> str:
        if self._op is None or self._value is None:
            raise ValueError("Filter must have an operator (use ==, !=, >, <, >=, <=)")
        return f"{self._op}:{self._value}"


# Singleton instance for building created_at filters
created_at = CreatedAtFilter()


class MetadataFilter:
    """
    Filter for metadata fields.

    Usage:
        from null_client import MetadataFilter as m

        # Filter by metadata field
        records = client.list_records(
            metadata_filters=[m("priority") > 5]
        )

        # String substring (always %%substr%%); for string fields only
        records = client.list_records(
            metadata_filters=[m("summary").contains("meeting")]
        )

        # String LIKE with caller-controlled pattern (% and _)
        records = client.list_records(
            metadata_filters=[m("summary").like("meet%")]
        )

        # Array element membership
        records = client.list_records(
            metadata_filters=[m("tags").has("important")]
        )

        # Field equals any of the given values
        records = client.list_records(
            metadata_filters=[m("status").in_(["active", "pending"])]
        )
    """

    def __init__(self, path: str):
        self.path = path
        self._op: str | None = None
        self._value: Any = None

    def __eq__(self, value: Any) -> Self:  # type: ignore[override]
        return self._create_filter("eq", value)

    def __ne__(self, value: Any) -> Self:  # type: ignore[override]
        return self._create_filter("ne", value)

    def __gt__(self, value: Any) -> Self:
        return self._create_filter("gt", value)

    def __lt__(self, value: Any) -> Self:
        return self._create_filter("lt", value)

    def __ge__(self, value: Any) -> Self:
        return self._create_filter("gte", value)

    def __le__(self, value: Any) -> Self:
        return self._create_filter("lte", value)

    def contains(self, value: str) -> Self:
        """String substring match (always %value%); for string fields only."""
        return self._create_filter("contains", value)

    def like(self, pattern: str) -> Self:
        """String LIKE match; caller controls pattern (e.g. meet%, %ing)."""
        return self._create_filter("like", pattern)

    def has(self, value: Any) -> Self:
        """Array element membership; field must be a JSON array containing value."""
        return self._create_filter("has", value)

    def in_(self, values: list[Any]) -> Self:
        """Match if the metadata field equals any of the given values."""
        return self._create_filter("in", values)

    def exists(self) -> Self:
        return self._create_filter("exists", None)

    def _create_filter(self, op: str, value: Any) -> Self:
        f = type(self)(self.path)
        f._op = op
        f._value = value
        return f

    def to_query_param(self) -> str:
        """Convert to the API query parameter format: path:op:value"""
        if self._op is None:
            raise ValueError(
                "Filter must have an operator (use ==, !=, >, <, >=, <=, contains(), like(), has(), in_(), or exists())"
            )

        if self._op == "exists":
            return f"{self.path}:{self._op}"

        if self._op == "in":
            value_str = json.dumps(self._value)
            return f"{self.path}:{self._op}:{value_str}"

        if self._op in ("has", "like"):
            if isinstance(self._value, bool):
                value_str = "true" if self._value else "false"
            elif self._value is None:
                value_str = "null"
            else:
                value_str = str(self._value)
            return f"{self.path}:{self._op}:{value_str}"

        if isinstance(self._value, bool):
            value_str = "true" if self._value else "false"
        elif self._value is None:
            value_str = "null"
        else:
            value_str = str(self._value)

        return f"{self.path}:{self._op}:{value_str}"

    def _serialize(self) -> dict[str, Any]:
        """Serialize to the filter tree JSON format for POST /records/query."""
        return {"field": self.path, "op": self._op, "value": self._value}

    def __or__(self, other: FilterExpr) -> OrExpr:
        return OrExpr([self, other])

    def __and__(self, other: FilterExpr) -> AndExpr:
        return AndExpr([self, other])

    def __invert__(self) -> NotExpr:
        return NotExpr(self)


class AndExpr:
    """Conjunction (AND) of two or more filter expressions.

    Produced by the ``&`` operator on any FilterExpr:

        (m("priority") > 5) & (m("status") == "open")

    An empty AndExpr is rejected at serialization time.
    """

    def __init__(self, filters: list[FilterExpr]) -> None:
        self.filters = filters

    def _serialize(self) -> dict[str, Any]:
        if not self.filters:
            raise ValueError("AndExpr must have at least one sub-expression")
        return {"and": [f._serialize() for f in self.filters]}

    def __or__(self, other: FilterExpr) -> OrExpr:
        return OrExpr([self, other])

    def __and__(self, other: FilterExpr) -> AndExpr:
        return AndExpr([self, other])

    def __invert__(self) -> NotExpr:
        return NotExpr(self)


class OrExpr:
    """Disjunction (OR) of two or more filter expressions.

    Produced by the ``|`` operator on any FilterExpr:

        m("summary").contains("meeting") | m("location").contains("meeting")

    An empty OrExpr is rejected at serialization time (it would always match nothing).
    """

    def __init__(self, filters: list[FilterExpr]) -> None:
        self.filters = filters

    def _serialize(self) -> dict[str, Any]:
        if not self.filters:
            raise ValueError("OrExpr must have at least one sub-expression")
        return {"or": [f._serialize() for f in self.filters]}

    def __or__(self, other: FilterExpr) -> OrExpr:
        return OrExpr([self, other])

    def __and__(self, other: FilterExpr) -> AndExpr:
        return AndExpr([self, other])

    def __invert__(self) -> NotExpr:
        return NotExpr(self)


class NotExpr:
    """Negation (NOT) of a filter expression.

    Produced by the ``~`` operator on any FilterExpr:

        ~m("archived").exists()   # matches absent OR null

    ``~(~expr)`` returns the inner expression unchanged (double-NOT elimination).
    """

    def __init__(self, filter: FilterExpr) -> None:
        self.filter = filter

    def _serialize(self) -> dict[str, Any]:
        return {"not": self.filter._serialize()}

    def __or__(self, other: FilterExpr) -> OrExpr:
        return OrExpr([self, other])

    def __and__(self, other: FilterExpr) -> AndExpr:
        return AndExpr([self, other])

    def __invert__(self) -> FilterExpr:
        return self.filter


# A filter expression tree node: leaf, AND, OR, or NOT.
type FilterExpr = MetadataFilter | AndExpr | OrExpr | NotExpr


class ListRecordsParams(TypedDict, total=False):
    kind: str | list[str] | None
    namespace: str | None
    metadata_filters: list[MetadataFilter | str] | None
    sort_by: str | None
    sort_order: SortOrder | None
    limit: int | None
    as_of: int | None
    include_deleted: bool


class Client:
    def __init__(
        self,
        base_url: str = "http://localhost:3001",
        timeout: float = 10.0,
    ):
        self.base_url = base_url.rstrip("/")
        self._client = httpx.Client(timeout=timeout)

    def __enter__(self) -> "Client":
        return self

    def __exit__(self, *args: Any) -> None:
        self.close()

    def _check_record_errors(self, resp: httpx.Response) -> None:
        if resp.status_code == 409:
            data = resp.json()
            raise RecordConflictError(
                expected=data.get("expected", ""),
                current=data.get("current", ""),
                message=data.get("message", "Hash conflict"),
            )
        if resp.status_code == 410:
            data = resp.json()
            raise RecordAlreadyDeletedError(deleted_at=data.get("deleted_at", 0))
        resp.raise_for_status()

    def close(self) -> None:
        self._client.close()

    def put_blob(self, data: bytes) -> Hash:
        resp = self._client.post(f"{self.base_url}/blobs", content=data)
        resp.raise_for_status()
        return Hash(resp.text.strip())

    def put_blobs_batch(self, blobs: list[bytes]) -> BatchBlobsResponse:
        """
        Upload multiple blobs in one multipart request.

        Args:
            blobs: List of blob payloads (bytes).

        Returns:
            BatchBlobsResponse with one result per blob (hash, status, size).
            status is "created" for new blobs or "already_exists" for deduplicated.
        """
        if not blobs:
            return BatchBlobsResponse(results=[])
        files = [(f"blob{i}", (None, blob)) for i, blob in enumerate(blobs)]
        resp = self._client.post(
            f"{self.base_url}/blobs/batch",
            files=files,
        )
        resp.raise_for_status()
        return BatchBlobsResponse.model_validate(resp.json())

    def get_blob(self, hash_: Hash) -> bytes:
        resp = self._client.get(f"{self.base_url}/blobs/{hash_}")
        if resp.status_code == 404:
            raise BlobNotFoundError(hash_)

        resp.raise_for_status()
        return resp.content

    def get_blobs_batch(self, hashes: list[Hash]) -> list[bytes]:
        """
        Download multiple blobs in one request.

        Args:
            hashes: List of blob hashes to fetch.

        Returns:
            List of blob contents in the same order as hashes.

        Raises:
            BlobNotFoundError: If any requested blob is missing (server returns 404).
        """
        if not hashes:
            return []
        payload = {"hashes": [h for h in hashes]}
        resp = self._client.post(
            f"{self.base_url}/blobs/batch/get",
            json=payload,
        )
        if resp.status_code == 404:
            raise BlobNotFoundError(hashes[0])  # Server doesn't indicate which
        resp.raise_for_status()
        buf = resp.content
        result: list[bytes] = []
        pos = 0
        while pos < len(buf):
            if pos + 4 > len(buf):
                raise ValueError("Batch response truncated at length prefix")
            length = int.from_bytes(buf[pos : pos + 4], "big")
            pos += 4
            if pos + length > len(buf):
                raise ValueError("Batch response truncated at blob data")
            result.append(bytes(buf[pos : pos + length]))
            pos += length
        if len(result) != len(hashes):
            raise ValueError(
                f"Batch response blob count {len(result)} does not match request {len(hashes)}"
            )
        return result

    def has_blob(self, hash_: Hash) -> bool:
        resp = self._client.head(f"{self.base_url}/blobs/{hash_}")
        return resp.status_code == 200

    def create_tree(self, hashes: list[Hash]) -> TreeResponse:
        resp = self._client.post(
            f"{self.base_url}/trees",
            json={"hashes": hashes},
        )
        resp.raise_for_status()
        return TreeResponse.model_validate(resp.json())

    def get_tree(self, hash_: Hash, flatten: bool = False) -> TreeResponse:
        params = {"flatten": "true"} if flatten else {}
        resp = self._client.get(f"{self.base_url}/trees/{hash_}", params=params)
        resp.raise_for_status()
        return TreeResponse.model_validate(resp.json())

    def create_record(
        self,
        kind: str,
        content: Hash,
        metadata: dict[str, Any] | None = None,
        namespace: str | None = None,
        immutable: bool = False,
        max_versions: int | None = None,
    ) -> RecordResponse:
        """
        Create a new record.

        Args:
            kind: Record type
            content: Content hash
            metadata: Record metadata
            namespace: Optional namespace
            immutable: If True, creates an immutable record (no id/created_at, deterministic hash).
                      If False, creates a versioned record (with id/created_at, queryable).
            max_versions: GC policy: keep at most this many versions (None = keep all). Min 1 if set.

        Returns:
            The created record
        """
        payload: dict[str, Any] = {"kind": kind, "content": content}
        if namespace is not None:
            payload["namespace"] = namespace
        if immutable:
            payload["immutable"] = immutable
        if metadata:
            payload["metadata"] = metadata
        if max_versions is not None:
            payload["max_versions"] = max_versions

        resp = self._client.post(f"{self.base_url}/records", json=payload)
        resp.raise_for_status()
        return RecordResponse.model_validate(resp.json())

    def update_record(
        self,
        id_: str,
        hash_: Hash,
        kind: str,
        content: Hash,
        prev: Hash | None,
        metadata: dict[str, Any] | None = None,
        namespace: str | None = None,
        max_versions: int | None = None,
    ) -> RecordResponse:
        """
        Update an existing record with optimistic locking.

        Args:
            id_: Record ID to update
            hash_: Current hash (for optimistic locking)
            kind: Record type
            content: Content hash
            prev: Optional previous record hash, if unset, the previous record will get GCed
            metadata: Record metadata
            namespace: Optional namespace
            max_versions: GC policy: keep at most this many versions (None = keep all). Min 1 if set.

        Returns:
            The updated record

        Raises:
            RecordConflictError: If hash doesn't match current version
            RecordAlreadyDeletedError: If record is deleted
            httpx.HTTPStatusError: For other HTTP errors (404, 500, etc.)
        """
        payload: dict[str, Any] = {"kind": kind, "content": content, "prev": prev}
        if namespace is not None:
            payload["namespace"] = namespace
        if metadata:
            payload["metadata"] = metadata
        if max_versions is not None:
            payload["max_versions"] = max_versions

        id_ = self._expand_id_if_needed(id_)
        resp = self._client.put(
            f"{self.base_url}/records-by-id/{id_}", params={"hash": hash_}, json=payload
        )

        self._check_record_errors(resp)
        return RecordResponse.model_validate(resp.json())

    def get_record(self, hash_: Hash) -> RecordResponse:
        resp = self._client.get(f"{self.base_url}/records/{hash_}")
        resp.raise_for_status()
        return RecordResponse.model_validate(resp.json())

    def get_record_by_id(self, id_: str) -> RecordResponse:
        id_ = self._expand_id_if_needed(id_)
        resp = self._client.get(f"{self.base_url}/records-by-id/{id_}")
        resp.raise_for_status()
        return RecordResponse.model_validate(resp.json())

    def list_record_versions(self, id_: str) -> ListRecordVersionsResponse:
        """
        List all versions of a record by ID, ordered by created_at descending (newest first).

        Args:
            id_: Record ID (UUID string).

        Returns:
            ListRecordVersionsResponse with versions list.

        Raises:
            httpx.HTTPStatusError: If record not found (404).
        """
        id_ = self._expand_id_if_needed(id_)
        resp = self._client.get(f"{self.base_url}/records-by-id/{id_}/versions")
        resp.raise_for_status()
        return ListRecordVersionsResponse.model_validate(resp.json())

    def list_records(
        self,
        kind: str | list[str] | None = None,
        namespace: str | None = None,
        metadata_filters: list[MetadataFilter | str] | None = None,
        created_at_filters: list[CreatedAtFilter | str] | None = None,
        sort_by: str | None = None,
        sort_order: SortOrder | None = None,
        sort_tiebreaker: str | None = None,
        limit: int | None = None,
        cursor: str | None = None,
        as_of: int | None = None,
        include_deleted: bool = False,
    ) -> ListRecordsResponse:
        """
        List records with optional filtering.

        Args:
            kind: Filter by record type (single kind or list of kinds)
            namespace: Filter by namespace
            metadata_filters: Filter by metadata fields
            created_at_filters: Filter by created_at timestamp (nanoseconds)
            sort_by: Field to sort by: "created_at", "id", "kind", "namespace", or
                "metadata:path" (e.g. SortBy.metadata("priority")). Metadata sort uses nulls last.
            sort_order: Sort order ("asc" or "desc")
            sort_tiebreaker: Secondary sort field for breaking ties. Restricted to "created_at",
                "id", or "metadata:path". Use SortTiebreaker constants. Sorts in the same direction
                as sort_order.
            limit: Maximum number of records to return
            cursor: Pagination cursor
            as_of: Time-travel query (show records as of this timestamp)
            include_deleted: Include soft-deleted records

        Returns:
            ListRecordsResponse with records, next_cursor, and has_more
        """
        params: dict[str, Any] = {}

        if kind is not None:
            params["kind"] = [kind] if isinstance(kind, str) else list(kind)
        if namespace is not None:
            params["namespace"] = namespace
        if sort_by is not None:
            params["sort_by"] = sort_by
        if sort_order is not None:
            params["sort_order"] = sort_order
        if sort_tiebreaker is not None:
            params["sort_tiebreaker"] = sort_tiebreaker
        if limit is not None:
            params["limit"] = limit
        if cursor is not None:
            params["cursor"] = cursor
        if as_of is not None:
            params["as_of"] = as_of
        if include_deleted:
            params["include_deleted"] = "true"

        if metadata_filters:
            params["metadata_filter"] = [
                f.to_query_param() if isinstance(f, MetadataFilter) else f
                for f in metadata_filters
            ]

        if created_at_filters:
            params["created_at_filter"] = [
                f.to_query_param() if isinstance(f, CreatedAtFilter) else f
                for f in created_at_filters
            ]

        resp = self._client.get(f"{self.base_url}/records", params=params)
        resp.raise_for_status()
        return ListRecordsResponse.model_validate(resp.json())

    def query_records(
        self,
        filter: FilterExpr | None = None,
        kind: str | list[str] | None = None,
        namespace: str | None = None,
        ids: list[str] | None = None,
        sort_by: str | None = None,
        sort_order: SortOrder | None = None,
        sort_tiebreaker: str | None = None,
        limit: int | None = None,
        cursor: str | None = None,
        created_at_filters: list[CreatedAtFilter | str] | None = None,
        as_of: int | None = None,
        include_deleted: bool = False,
    ) -> ListRecordsResponse:
        """
        Query records using a composable AND/OR/NOT filter tree via POST /records/query.

        Use this instead of ``list_records`` when you need boolean OR or NOT logic:

            from null_client import MetadataFilter as m

            # OR: summary contains "meeting" OR location contains "meeting"
            results = client.query_records(
                filter=m("summary").contains("meeting") | m("location").contains("meeting"),
                kind="event",
            )

            # NOT: archived field is absent or null
            results = client.query_records(
                filter=~m("archived").exists(),
            )

            # Nested: (priority > 5) AND (status == "open" OR urgent == true)
            results = client.query_records(
                filter=(m("priority") > 5) & (m("status") == "open" | m("urgent") == True),
            )

        Args:
            filter: A FilterExpr built with ``|`` (OR), ``&`` (AND), ``~`` (NOT) operators.
                    A plain MetadataFilter is also accepted as a leaf. Pass ``None`` for no filter.
            kind: Filter by record type (single kind or list of kinds)
            namespace: Filter by namespace
            sort_by: Field to sort by
            sort_order: Sort order ("asc" or "desc")
            sort_tiebreaker: Secondary sort field for breaking ties
            limit: Maximum number of records to return
            cursor: Pagination cursor
            created_at_filters: Filter by created_at timestamp (nanoseconds)
            as_of: Time-travel query (show records as of this timestamp)
            include_deleted: Include soft-deleted records

        Returns:
            ListRecordsResponse with records, next_cursor, and has_more
        """
        body: dict[str, Any] = {}

        if filter is not None:
            body["filter"] = filter._serialize()
        if kind is not None:
            body["kind"] = [kind] if isinstance(kind, str) else list(kind)
        if namespace is not None:
            body["namespace"] = namespace
        if ids is not None:
            body["ids"] = ids
        if sort_by is not None:
            body["sort_by"] = sort_by
        if sort_order is not None:
            body["sort_order"] = sort_order
        if sort_tiebreaker is not None:
            body["sort_tiebreaker"] = sort_tiebreaker
        if limit is not None:
            body["limit"] = limit
        if cursor is not None:
            body["cursor"] = cursor
        if as_of is not None:
            body["as_of"] = as_of
        if include_deleted:
            body["include_deleted"] = True
        if created_at_filters:
            body["created_at_filter"] = [
                f.to_query_param() if isinstance(f, CreatedAtFilter) else f
                for f in created_at_filters
            ]

        resp = self._client.post(f"{self.base_url}/records/query", json=body)
        resp.raise_for_status()
        return ListRecordsResponse.model_validate(resp.json())

    def list_records_by_id_prefix(self, prefix: str) -> ListRecordsResponse:
        """
        List records whose id starts with the given prefix.

        Args:
            prefix: Hex prefix or UUID-style string; must be non-empty and valid hex.

        Returns:
            ListRecordsResponse with matching records (has_more is always false).
        """
        if not prefix or not prefix.replace("-", "").strip():
            raise ValueError("prefix is required")
        resp = self._client.get(
            f"{self.base_url}/records-by-id",
            params={"prefix": prefix},
        )
        if resp.status_code == 400:
            msg = (resp.json() or {}).get("message", resp.text) or "Bad request"
            raise NullClientError(msg)
        resp.raise_for_status()
        return ListRecordsResponse.model_validate(resp.json())

    def _is_full_id(self, id_: str) -> bool:
        """Return True if id_ is a full 32-char hex UUID (with or without dashes)."""
        hex_part = id_.replace("-", "").lower()
        return len(hex_part) == 32 and all(c in "0123456789abcdef" for c in hex_part)

    def expand_id(
        self,
        prefix: str,
        kind: str | list[str] | None = None,
    ) -> str:
        """
        Resolve a short ID prefix to a full record ID.

        If prefix is already a full UUID (32 hex chars), returns it unchanged.
        Otherwise looks up via list_records_by_id_prefix and returns the full ID
        when exactly one record matches. Optionally filter by kind.

        Args:
            prefix: Short hex prefix (e.g. "e16442d9") or full UUID.
            kind: Optional kind or list of kinds to filter matches.

        Returns:
            Full record ID (UUID string).

        Raises:
            RecordNotFoundError: If prefix matches no records.
            AmbiguousIdError: If prefix matches multiple records.
        """
        if self._is_full_id(prefix):
            return prefix
        resp = self.list_records_by_id_prefix(prefix)
        records = resp.records
        if kind is not None:
            kinds = [kind] if isinstance(kind, str) else list(kind)
            records = [r for r in records if r.kind in kinds]
        if not records:
            raise RecordNotFoundError(prefix)
        if len(records) > 1:
            raise AmbiguousIdError(prefix, len(records))
        rid = records[0].id
        if rid is None:
            raise RecordNotFoundError(prefix)
        return rid

    def _expand_id_if_needed(
        self,
        id_: str,
        kind: str | list[str] | None = None,
    ) -> str:
        """Return id_ unchanged if full UUID, else expand via prefix lookup."""
        return id_ if self._is_full_id(id_) else self.expand_id(id_, kind=kind)

    def get_distinct_metadata_values(
        self,
        kind: str,
        fields: list[str],
        namespace: str | None = None,
    ) -> dict[str, list[Any]]:
        """
        Return distinct non-null values for metadata fields and/or namespace, scoped to a record kind.

        Useful for populating filter dropdowns (e.g. topic, level, source) or listing
        namespaces (e.g. calendar collections) without fetching all records.

        Args:
            kind: Record kind to scope the query (e.g. "event", "notification").
            fields: Field names. Use metadata field names (e.g. ["topic", "level"])
                and/or the reserved "namespace" for the record-level namespace column.
            namespace: Optional namespace filter. Supports wildcards: ``*`` matches any
                characters (e.g. ``jot/*``, ``user@example.com/*``).

        Returns:
            Dict mapping each field name to a sorted list of distinct values.
            Fields with no values or that don't exist return an empty list.
        """
        if not kind or not kind.strip():
            raise ValueError("kind is required")
        if not fields:
            raise ValueError("fields is required (at least one field)")
        fields_str = ",".join(f.strip() for f in fields if f.strip())
        if not fields_str:
            raise ValueError("fields must contain at least one non-empty field name")
        params: dict[str, str] = {"kind": kind.strip(), "fields": fields_str}
        if namespace is not None and namespace.strip():
            params["namespace"] = namespace.strip()
        resp = self._client.get(
            f"{self.base_url}/records/distinct",
            params=params,
        )
        if resp.status_code == 400:
            data = resp.json() or {}
            raise NullClientError(
                data.get("message", data.get("error", resp.text)) or "Bad request"
            )
        resp.raise_for_status()
        return resp.json()

    def iter_records(
        self, **kwargs: Unpack[ListRecordsParams]
    ) -> Iterator[RecordResponse]:
        cursor = None
        while True:
            page = self.list_records(**kwargs, cursor=cursor)
            yield from page.records
            if not page.has_more:
                break
            cursor = page.next_cursor

    def delete_record(self, id_: str, hash_: Hash) -> RecordResponse:
        """
        Delete a record (soft delete with optimistic locking).

        Args:
            id_: Record ID to delete (UUID string)
            hash_: Hash of current version (for optimistic locking)

        Returns:
            The deletion record with deleted_at set

        Raises:
            RecordConflictError: If hash doesn't match current version
            RecordAlreadyDeletedError: If record is already deleted
            httpx.HTTPStatusError: For other HTTP errors (404, 500, etc.)
        """
        id_ = self._expand_id_if_needed(id_)
        resp = self._client.delete(
            f"{self.base_url}/records-by-id/{id_}", params={"hash": hash_}
        )
        self._check_record_errors(resp)
        return RecordResponse.model_validate(resp.json())

    def aggregate(
        self,
        script: str,
        kind: str | list[str] | None = None,
        namespace: str | None = None,
        filter: FilterExpr | None = None,
        created_at_filters: list[CreatedAtFilter | str] | None = None,
        params: dict[str, Any] | None = None,
        max_operations: int | None = None,
    ) -> AggregateResponse:
        """
        Run a Rhai script over a filtered set of records server-side.

        The script must define two functions:
            fn map(ctx, record)   - called once per matching record (created_at asc order)
            fn finish(ctx)        - called after all records; return value is the result

        ``ctx`` is a mutable map that persists across all ``map`` calls.
        ``params`` is available as a global constant inside both functions.

        Each ``record`` has: id (str), kind (str), created_at (int, Unix seconds), metadata (map).

        Args:
            script: Rhai script source (max 64 KB).
            kind: Scope to records of this kind.
            namespace: Optional namespace filter. Supports wildcards: ``*`` matches any
                characters (e.g. ``jot/*``, ``user@example.com/*``).
            filter: AND/OR/NOT filter tree built with ``|``, ``&``, ``~`` on MetadataFilter.
                    A plain MetadataFilter is also accepted as a leaf.
            created_at_filters: created_at filters (nanosecond timestamps).
            params: Arbitrary JSON object injected as the ``params`` global in the script.
            max_operations: Rhai operation limit (default 50,000,000; 0 = unlimited).

        Returns:
            AggregateResponse with ``result`` (return value of finish()) and
            ``records_processed`` (number of records passed to map()).

        Raises:
            NullClientError: On 400 (bad script / filter),
                             422 with error "unprocessable entity" (finish not defined),
                             422 with error "operation_limit_exceeded" (max_operations hit),
                             or other server errors.
        """
        body: dict[str, Any] = {"script": script}
        if kind is not None:
            body["kind"] = [kind] if isinstance(kind, str) else list(kind)
        if namespace is not None and namespace.strip():
            body["namespace"] = namespace.strip()
        if filter is not None:
            body["filter"] = filter._serialize()
        if created_at_filters:
            body["created_at_filters"] = [
                f.to_query_param() if isinstance(f, CreatedAtFilter) else f
                for f in created_at_filters
            ]
        if params is not None:
            body["params"] = params
        if max_operations is not None:
            body["max_operations"] = max_operations

        resp = self._client.post(f"{self.base_url}/records/aggregate", json=body)
        if not resp.is_success:
            data = (
                resp.json()
                if resp.headers.get("content-type", "").startswith("application/json")
                else {}
            )
            msg = data.get("message") or data.get("error") or resp.text
            raise NullClientError(f"aggregate failed ({resp.status_code}): {msg}")
        return AggregateResponse.model_validate(resp.json())
