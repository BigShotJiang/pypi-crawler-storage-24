import types
from typing import Any

from valiqor.common.config import DEFAULT_BACKEND_URL as DEFAULT_BACKEND_URL
from valiqor.common.config import get_config as get_config
from valiqor.common.exceptions import AuthenticationError as AuthenticationError
from valiqor.common.exceptions import ValidationError as ValidationError
from valiqor.common.http import HTTPClient as HTTPClient
from valiqor.security.models import AttackVectorInfo as AttackVectorInfo
from valiqor.security.models import AuthInfo as AuthInfo
from valiqor.security.models import RedTeamResult as RedTeamResult
from valiqor.security.models import SecurityAuditResult as SecurityAuditResult
from valiqor.security.models import UsageInfo as UsageInfo
from valiqor.security.models import VulnerabilityInfo as VulnerabilityInfo

class ValiqorSecurityClient:
    API_VERSION: str
    def __init__(
        self,
        api_key: str | None = None,
        project_name: str | None = None,
        base_url: str | None = None,
        timeout: int = 300,
        openai_api_key: str | None = None,
        _config: dict[str, Any] | None = None,
    ) -> None: ...
    def validate_auth(self) -> AuthInfo: ...
    def audit(
        self,
        dataset: list[dict[str, Any]],
        project_name: str | None = None,
        categories: list[str] | None = None,
        config: dict[str, Any] | None = None,
    ) -> SecurityAuditResult: ...
    evaluate_security = audit
    def audit_trace(
        self,
        trace: dict[str, Any],
        project_name: str | None = None,
        categories: list[str] | None = None,
        batch_name: str | None = None,
        config: dict[str, Any] | None = None,
    ) -> SecurityAuditResult: ...
    def red_team(
        self,
        run_name: str | None = None,
        attack_vectors: list[str] | None = None,
        attacks_per_vector: int = 5,
        target_vulnerabilities: list[str] | None = None,
        config: dict[str, Any] | None = None,
    ) -> RedTeamResult: ...
    def get_usage(self) -> UsageInfo: ...
    def list_vulnerabilities(self) -> list[VulnerabilityInfo]: ...
    def list_attack_vectors(self) -> list[AttackVectorInfo]: ...
    list_attack_strategies = list_attack_vectors
    def close(self) -> None: ...
    def __enter__(self): ...
    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: types.TracebackType | None,
    ) -> None: ...
