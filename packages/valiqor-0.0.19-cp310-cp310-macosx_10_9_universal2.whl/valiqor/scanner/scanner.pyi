from typing import Any

from _typeshed import Incomplete

from ..common.config import DEFAULT_BACKEND_URL as DEFAULT_BACKEND_URL
from ..common.config import DEFAULT_SCAN_DIR as DEFAULT_SCAN_DIR
from ..common.config import SCAN_UPLOAD_ENDPOINT as SCAN_UPLOAD_ENDPOINT
from ..common.config import ensure_output_dirs as ensure_output_dirs
from ..common.config import get_config as get_config
from ..common.config import get_intelligence_message as get_intelligence_message
from ..common.config import should_upload as should_upload
from ..common.exceptions import ConfigurationError as ConfigurationError
from ..common.exceptions import ScanError as ScanError
from ..common.exceptions import UploadError as UploadError

class ScanResult:
    status: Incomplete
    project_name: Incomplete
    scan_id: Incomplete
    local_output_dir: Incomplete
    files_generated: Incomplete
    files_uploaded: Incomplete
    upload_response: Incomplete
    error: Incomplete
    timestamp: Incomplete
    def __init__(
        self,
        status: str,
        project_name: str,
        scan_id: str,
        local_output_dir: str,
        files_generated: list[str],
        files_uploaded: list[str],
        upload_response: dict | None = None,
        error: str | None = None,
    ) -> None: ...
    def to_dict(self) -> dict[str, Any]: ...

class ValiqorScanner:
    def __init__(self) -> None: ...
    def configure(
        self,
        api_key: str = None,
        project_name: str = None,
        backend_url: str | None = None,
        local_output_dir: str | None = None,
        valiqor_intelligence: bool = None,
        environment: str = None,
        debug: bool = None,
        verbose: bool = False,
    ) -> ValiqorScanner: ...
    def scan(self, repo_path: str, skip_upload: bool = False) -> ScanResult: ...
    @property
    def is_configured(self) -> bool: ...
    @property
    def project_name(self) -> str | None: ...
    @property
    def backend_url(self) -> str: ...
