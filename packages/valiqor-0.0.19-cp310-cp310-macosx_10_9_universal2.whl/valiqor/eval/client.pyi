import types
from typing import Any

from valiqor.common.config import DEFAULT_BACKEND_URL as DEFAULT_BACKEND_URL
from valiqor.common.config import get_config as get_config
from valiqor.common.exceptions import AuthenticationError as AuthenticationError
from valiqor.common.exceptions import ValidationError as ValidationError
from valiqor.common.http import HTTPClient as HTTPClient
from valiqor.eval.models import AuthInfo as AuthInfo
from valiqor.eval.models import EvaluationResult as EvaluationResult
from valiqor.eval.models import MetricInfo as MetricInfo
from valiqor.eval.models import ProjectInfo as ProjectInfo

class ValiqorEvalClient:
    API_VERSION: str
    def __init__(
        self,
        api_key: str | None = None,
        project_name: str | None = None,
        base_url: str | None = None,
        timeout: int = 300,
        openai_api_key: str | None = None,
        _config: dict[str, Any] | None = None,
    ) -> None: ...
    def validate_auth(self) -> AuthInfo: ...
    def evaluate(
        self,
        dataset: list[dict[str, Any]],
        metrics: list[str],
        project_name: str | None = None,
        run_name: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> EvaluationResult: ...
    def evaluate_trace(
        self,
        trace: dict[str, Any],
        metrics: list[str],
        project_name: str | None = None,
        run_name: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> EvaluationResult: ...
    def get_run(self, run_id: str) -> dict[str, Any]: ...
    def list_projects(self) -> list[ProjectInfo]: ...
    def create_project(
        self, name: str, key: str | None = None, model_name: str | None = None
    ) -> ProjectInfo: ...
    def list_metric_templates(self) -> list[MetricInfo]: ...
    def list_project_metrics(self, project_name: str | None = None) -> list[MetricInfo]: ...
    def add_project_metric(
        self,
        metric_key: str,
        display_name: str,
        project_name: str | None = None,
        template_id: str | None = None,
        value_type: str = "numeric",
        default_weight: float = 1.0,
    ) -> MetricInfo: ...
    def get_project_stats(self, project_name: str | None = None) -> dict[str, Any]: ...
    def close(self) -> None: ...
    def __enter__(self): ...
    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: types.TracebackType | None,
    ) -> None: ...
