import types
from typing import Any

from _typeshed import Incomplete

from .exceptions import APIError as APIError
from .exceptions import AuthenticationError as AuthenticationError
from .exceptions import NetworkError as NetworkError
from .exceptions import QuotaExceededError as QuotaExceededError
from .exceptions import RateLimitError as RateLimitError
from .exceptions import TimeoutError as TimeoutError
from .exceptions import ValidationError as ValidationError
from .exceptions import ValiqorError as ValiqorError

class HTTPClient:
    DEFAULT_TIMEOUT: int
    base_url: Incomplete
    api_key: Incomplete
    timeout: Incomplete
    user_agent: Incomplete
    session: Incomplete
    def __init__(
        self,
        base_url: str,
        api_key: str | None = None,
        timeout: int = ...,
        user_agent: str = "valiqor-sdk/1.0.0",
    ) -> None: ...
    def request(
        self,
        method: str,
        endpoint: str,
        json: dict[str, Any] | None = None,
        params: dict[str, Any] | None = None,
        files: dict[str, Any] | None = None,
        headers: dict[str, str] | None = None,
        timeout: int | None = None,
    ) -> dict[str, Any] | list[Any]: ...
    def get(self, endpoint: str, **kwargs) -> dict[str, Any] | list[Any]: ...
    def post(self, endpoint: str, **kwargs) -> dict[str, Any] | list[Any]: ...
    def put(self, endpoint: str, **kwargs) -> dict[str, Any] | list[Any]: ...
    def delete(self, endpoint: str, **kwargs) -> dict[str, Any] | list[Any]: ...
    def close(self) -> None: ...
    def __enter__(self): ...
    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: types.TracebackType | None,
    ) -> None: ...

def make_request(
    method: str,
    url: str,
    headers: dict[str, str] | None = None,
    json_data: dict[str, Any] | None = None,
    files: dict[str, Any] | None = None,
    timeout: int = 30,
) -> dict[str, Any]: ...
