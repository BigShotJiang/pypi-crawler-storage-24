from pathlib import Path
from typing import Any

__all__ = [
    "CONFIG_FILE",
    "DEFAULT_BACKEND_URL",
    "TRACE_UPLOAD_ENDPOINT",
    "SCAN_UPLOAD_ENDPOINT",
    "VALIQOR_CLOUD_API",
    "VALIQOR_CLOUD_TRACES_API",
    "VALIQOR_SIGNUP_URL",
    "DEFAULT_TRACE_DIR",
    "DEFAULT_SCAN_DIR",
    "find_config_file",
    "load_config_file",
    "get_config",
    "ensure_output_dirs",
    "should_upload",
    "get_intelligence_message",
    "save_config",
]

CONFIG_FILE: str
DEFAULT_BACKEND_URL: str
TRACE_UPLOAD_ENDPOINT: str
SCAN_UPLOAD_ENDPOINT: str
VALIQOR_CLOUD_API: str
VALIQOR_CLOUD_TRACES_API: str
VALIQOR_SIGNUP_URL: str
DEFAULT_TRACE_DIR: str
DEFAULT_SCAN_DIR: str

def find_config_file(start_path: str | None = None) -> Path | None: ...
def load_config_file(config_path: Path | None = None) -> dict[str, Any]: ...
def get_config(config_file: str | None = None, **overrides) -> dict[str, Any]: ...
def ensure_output_dirs(config: dict[str, Any]) -> None: ...
def should_upload(config: dict[str, Any]) -> bool: ...
def get_intelligence_message() -> str: ...
def save_config(config: dict[str, Any], path: Path | None = None) -> bool: ...
