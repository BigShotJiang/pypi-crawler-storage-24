# Author : Bertrand Brelier
# Class to convert Categorical and numeric variables in Weight of Evidence
# missing values do not have to be imputed
import numpy as np
import pandas as pd

class WoeConversion():
    def __init__(self, binarytarget, features, nbins=10, weights=None, id=None):
        self.target = binarytarget
        self.features = features
        self.continuousvariables = []
        self.categoricalvariables = []
        self.categoricalmodel = None
        self.continuousmodel = None
        self.nbins = nbins
        self.weights = weights
        self.id = id
    def fit(self,df):
        #find continuous variables:
        traindf = df.copy(deep=True)
        try:
            traindf[self.target] = traindf[self.target].astype('int')
        except:
            print("ERROR : target variable must be a binary integer column with no missing values")
            return
        for feat in self.features:
            if traindf[feat].dtypes == 'O':
                traindf[feat] = traindf[feat].astype(str)
                self.categoricalvariables.append(feat)
            else:
                try:
                    traindf[feat] = traindf[feat].astype(float)
                    self.continuousvariables.append(feat)
                except:
                    self.categoricalvariables.append(feat)
        self.categoricalmodel = ConvertCategoricalFeatures(
            binarytarget=self.target
            ,CategoricalFeatures=self.categoricalvariables
            ,weights=self.weights
            ,id=self.id)
        self.categoricalmodel.fit(traindf)
        self.continuousmodel = ConvertContinuousFeatures(
            binarytarget=self.target
            ,ContinuousFeatures=self.continuousvariables
            , NBins = self.nbins
            ,weights=self.weights
            ,id=self.id
        )
        self.continuousmodel.fit(traindf)
    def transform(self,testdf):
        tmpdf = testdf.copy(deep=True)
        for feat in self.categoricalvariables:
            tmpdf[feat] = tmpdf[feat].astype(str)
        for feat in self.continuousvariables:
            tmpdf[feat] = tmpdf[feat].astype(float)
        tmpdf = self.categoricalmodel.transform(tmpdf)
        tmpdf = self.continuousmodel.transform(tmpdf)
        return tmpdf

class ConvertCategoricalFeatures():
    #Class to convert categorical features to WOE for binary classification problem (target = 0 or 1)
    def __init__(self,binarytarget,CategoricalFeatures, weights,id):
        self.target = binarytarget
        self.Model = {}
        self.Features = CategoricalFeatures
        self.weights = weights
        self.id = id
    def fit(self,traindf):
        if self.weights is None and self.id is None:
            NPositive=traindf[traindf[self.target]==1].shape[0]
            NNegative=traindf[traindf[self.target]==0].shape[0]
        elif self.weights is not None:
            NPositive=traindf[traindf[self.target]==1][self.weights].sum()
            NNegative=traindf[traindf[self.target]==0][self.weights].sum()
        elif self.id is not None:
            NPositive=traindf[traindf[self.target]==1][self.id].nunique()
            NNegative=traindf[traindf[self.target]==0][self.id].nunique()
        for feature in self.Features:
            if self.weights is None and self.id is None:
                tmptraindf = traindf[[feature,self.target]].copy(deep=True)
            elif self.weights is not None:
                tmptraindf = traindf[[feature,self.target,self.weights]].copy(deep=True)
                tmptraindf[self.weights] = tmptraindf[self.weights].astype(float)
            elif self.id is not None:
                tmptraindf = traindf[[feature,self.target,self.id]].copy(deep=True)
            tmptraindf[self.target] = tmptraindf[self.target].astype(int)
            tmptraindf[feature] = tmptraindf[feature].astype(str)

            if self.weights is None and self.id is None:
                results = tmptraindf[[feature,self.target]].fillna("None").groupby([feature]).agg(['sum','count'])
                results = results.reset_index()
                results.columns=[feature,"Positive","Count"]
            elif self.weights is not None:
                tmptraindf[feature] = tmptraindf[feature].fillna("None")
                tmptraindf["weighted_target"] = tmptraindf[self.target] * tmptraindf[self.weights]
                results = (
                    tmptraindf[[feature,"weighted_target",self.weights]].groupby(feature)
                       .agg(
                           sum=("weighted_target", "sum"),
                           count=(self.weights, "sum")
                       )
                )
            elif self.id is not None:
                tmptraindf[feature] = tmptraindf[feature].fillna("None")
                results = (
                    tmptraindf[[feature,self.target,self.id]].groupby(feature)
                      .agg(
                          count=('user_pseudo_id', 'nunique'),
                          sum=('user_pseudo_id',
                                           lambda x: x[tmptraindf.loc[x.index, self.target] == 1].nunique())
                      )
                      .reset_index()
                )
            results = results.reset_index()
            results.rename(columns={'count':'Count','sum':'Positive'},inplace=True)
            results["Negative"]=results["Count"]-results["Positive"]
            results["CountPositive"] = results["Positive"]
            #Replace 0 with 1 to avoid infinite log
            results.loc[results.Negative == 0, 'Negative'] = 1
            results.loc[results.Positive == 0, 'Positive'] = 1
            #Distribution Positive (Good)
            results["DG"]=results["Positive"]*1./NPositive
            #Distribution Negative (Bad)
            results["DB"]=results["Negative"]*1./NNegative
            #WOE
            results["WOE"]=np.log(results["DG"]/results["DB"])
            results.loc[results.Count < 10, 'WOE'] = 0
            results.loc[results.CountPositive <= 1, 'WOE'] = results["WOE"].min()
            results.loc[results.Count < 10, 'WOE'] = 0
            results = results[[feature,'WOE']]
            self.Model[feature] = dict(zip(results[feature], results.WOE))
    def train(self,traindf):
        self.fit(traindf)
    def transform(self,testdf):
        #In case new values are found, needs to impute 0 for WOE
        for feature in self.Features:
            testdf[feature] = testdf[feature].astype(str)
            transformation = pd.DataFrame(list(self.Model[feature].items()), columns=[feature, 'mywoevalue'])
            transformation[feature] = transformation[feature].astype(str)
            transformation.drop_duplicates(subset=[feature], keep='first', inplace=True)
            testdf = pd.merge(testdf, transformation, on=feature, how='left')
            testdf.drop(feature, axis=1, inplace=True)
            testdf.rename(columns={'mywoevalue': feature}, inplace=True)
            testdf[feature] = testdf[feature].fillna(0)
            testdf[feature] = testdf[feature].astype(float)
        return testdf

class ConvertContinuousFeatures():
    #Class to convert continuous features to WOE for binary classification problem (target = 0 or 1)
    def __init__(self,binarytarget,ContinuousFeatures,NBins, weights, id):
        self.target = binarytarget
        self.Model = {}
        self.Features = ContinuousFeatures
        self.NBins = NBins
        self.BinModel = {}
        self.weights = weights
        self.id = id
    def train(self,traindf):
        self.fit(traindf)
    def fit(self,traindf):
        if self.weights is None and self.id is None:
            NPositive=traindf[traindf[self.target]==1].shape[0]
            NNegative=traindf[traindf[self.target]==0].shape[0]
        elif self.weights is not None:
            NPositive=traindf[traindf[self.target]==1][self.weights].sum()
            NNegative=traindf[traindf[self.target]==0][self.weights].sum()
        elif self.id is not None:
            NPositive=traindf[traindf[self.target]==1][self.id].nunique()
            NNegative=traindf[traindf[self.target]==0][self.id].nunique()
        for feature in self.Features:
            if self.weights is None and self.id is None:
                tmpdf = traindf[[feature,self.target]].copy(deep=True)
            elif self.weights is not None:
                tmpdf = traindf[[feature,self.target,self.weights]].copy(deep=True)
                tmpdf[self.weights] = tmpdf[self.weights].astype(float)
            elif self.id is not None:
                tmpdf = traindf[[feature,self.target,self.id]].copy(deep=True)
            List = sorted(list(filter(lambda x:not np.isnan(x),tmpdf[feature].values)))
            Len = len(List)
            BinsLim = [-np.inf]
            for omega in range(1,self.NBins):
                Value = List[int(omega * Len / self.NBins)]
                if Value not in BinsLim:
                    BinsLim.append( Value )
            BinsLim.append(np.inf)
            self.BinModel[feature] = BinsLim
            tmpdf["bin"] = pd.cut(tmpdf[feature], self.BinModel[feature], labels=range(1,len(self.BinModel[feature])))
            tmpdf["bin"] = tmpdf["bin"].cat.add_categories([-1])
            tmpdf["bin"] = tmpdf["bin"].fillna(-1)

            if self.weights is None and self.id is None:
                results = tmpdf[["bin",self.target]].groupby(["bin"], observed=True).agg(['sum','count'])
            elif self.weights is not None:
                tmpdf["weighted_target"] = tmpdf[self.target] * tmpdf[self.weights]
                results = (
                    tmpdf[["bin","weighted_target",self.weights]].groupby("bin", observed=True)
                       .agg(
                           sum=("weighted_target", "sum"),
                           count=(self.weights, "sum")
                       )
                )
            elif self.id is not None:
                results = (
                    tmpdf[["bin",self.target,self.id]].groupby("bin", observed=True)
                      .agg(
                          count=('user_pseudo_id', 'nunique'),
                          sum=('user_pseudo_id',
                                           lambda x: x[tmpdf.loc[x.index, self.target] == 1].nunique())
                      )
                      .reset_index()
                )

            results = tmpdf[["bin",self.target]].groupby(["bin"], observed=True).agg(['sum','count'])
            results = results.reset_index()
            results.columns=["bin","Positive","Count"]
            results["Negative"]=results["Count"]-results["Positive"]
            results["CountPositive"] = results["Positive"]
            #Replace 0 with 1 to avoid infinite log
            results.loc[results.Negative == 0, 'Negative'] = 1
            results.loc[results.Positive == 0, 'Positive'] = 1
            #Distribution Positive (Good)
            results["DG"]=results["Positive"]*1./NPositive
            #Distribution Negative (Bad)
            results["DB"]=results["Negative"]*1./NNegative
            #WOE
            results["WOE"]=np.log(results["DG"]/results["DB"])
            results.loc[results.Count <= 10, 'WOE'] = 0
            results.loc[results.CountPositive <= 1, 'WOE'] = results["WOE"].min()
            results.loc[results.Count <= 10, 'WOE'] = 0
            results = results[["bin",'WOE']]
            self.Model[feature] = dict(zip(results["bin"], results.WOE))
    def transform(self,testdf):
        tmpdf = testdf.copy(deep=True)
        for feature in self.Features:
            tmpdf[feature] = pd.cut(tmpdf[feature], self.BinModel[feature], labels=range(1,len(self.BinModel[feature])))
            tmpdf[feature] = tmpdf[feature].cat.add_categories([-1])
            tmpdf[feature] = tmpdf[feature].fillna(-1)
            transformation = pd.DataFrame(list(self.Model[feature].items()), columns=[feature, 'mywoevalue'])
            transformation.drop_duplicates(subset=[feature], keep='first', inplace=True)
            tmpdf = pd.merge(tmpdf, transformation, on=feature, how='left')
            tmpdf.drop(feature, axis=1, inplace=True)
            tmpdf.rename(columns={'mywoevalue': feature}, inplace=True)
            tmpdf[feature] = tmpdf[feature].fillna(0)
            tmpdf[feature] = tmpdf[feature].astype(float)
        return tmpdf
