# DWH, Datalake и Datalakehouse
