# Kappa & Lambda архитектуры
