"""
ingest_from_prompt — text-description-driven ingestion for the Nexus pipeline.

Covers two scenarios that ingest_figma_zip cannot:
  A. Scaffold only — "give me a clean nextjs-fullstack starter" (no design yet)
  B. Description-driven — "build a SaaS landing page with hero, pricing, testimonials"

Produces the same manifest format as ingest_figma_zip so the rest of the pipeline
(remap_to_golden_path → agent → validate_output → package_output) is unchanged.
The only difference downstream is source_type: "prompt" in the manifest, which
causes remap_to_golden_path to frame queue files as "design from scratch" rather
than "convert Figma source".
"""

import json
import logging
import pathlib
import shutil

from mcp.server.fastmcp import FastMCP

logger = logging.getLogger(__name__)

_NEXUS_ROOT = pathlib.Path(__file__).parent.parent.parent
_GOLDEN_PATHS_DIR = _NEXUS_ROOT / "golden_paths"

VALID_GOLDEN_PATHS: set[str] = {
    d.name
    for d in _GOLDEN_PATHS_DIR.iterdir()
    if d.is_dir() and (d / "manifest.json").exists()
}

# ── Component type hints ───────────────────────────────────────────────────────
# Used to give the LLM agent meaningful context when creating a component from
# scratch. Keyed by a lowercase keyword that appears in the component stem.

_COMPONENT_HINTS: dict[str, str] = {
    "hero": (
        "Large hero section with a compelling headline, subheadline, "
        "call-to-action button(s), and a visual element (illustration, mockup, or abstract graphic)."
    ),
    "feature": (
        "Features / benefits grid showcasing the product's key capabilities. "
        "Each feature has an icon, title, and short description."
    ),
    "pricing": (
        "Pricing plans displayed as cards or a comparison table. "
        "Each plan shows a name, price, feature list, and a CTA button."
    ),
    "testimonial": (
        "Customer testimonials section with pull-quotes, author names, roles, "
        "and optional avatar images or star ratings."
    ),
    "cta": (
        "Call-to-action section with a bold headline, supporting copy, "
        "and a prominent primary button."
    ),
    "faq": (
        "Frequently asked questions section with accordion-style expandable items. "
        "Each item has a question and a detailed answer."
    ),
    "header": (
        "Site header / top navigation bar with the brand logo on the left, "
        "navigation links in the centre, and an optional CTA button on the right."
    ),
    "footer": (
        "Site footer with grouped navigation links, brand logo, copyright notice, "
        "and social media icon links."
    ),
    "navbar": (
        "Responsive navigation bar with logo, nav links, mobile hamburger menu, "
        "and an optional sign-in / get-started button."
    ),
    "sidebar": (
        "Vertical navigation sidebar with grouped menu items, icons, active-state "
        "highlighting, and a collapse toggle."
    ),
    "dashboard": (
        "Main dashboard view with a stats summary row (cards with KPI numbers), "
        "a recent-activity or data table, and quick-action buttons."
    ),
    "login": (
        "Login form with email and password fields, a submit button, "
        "a 'forgot password' link, and a link to the sign-up page."
    ),
    "signup": (
        "Registration form with name, email, and password fields, "
        "a submit button, and a link back to the login page."
    ),
    "home": (
        "Main landing / home page that combines the hero, features, "
        "and other key marketing sections."
    ),
    "about": (
        "About page with company story, mission statement, and a team grid "
        "showing member photos, names, and roles."
    ),
    "contact": (
        "Contact page with a contact form (name, email, message, submit) "
        "and contact details (address, phone, email)."
    ),
    "team": (
        "Team section or page with member cards showing photos, names, roles, "
        "and optional social links."
    ),
    "banner": (
        "Promotional banner or announcement bar with a short message and "
        "an optional dismiss button or action link."
    ),
}

_DEFAULT_HINT = (
    "A UI component that fits naturally within the described project. "
    "Design it to be visually consistent with the other components."
)


def _hint_for(stem: str) -> str:
    """Return the best-matching component hint for a given stem."""
    lower = stem.lower()
    for keyword, hint in _COMPONENT_HINTS.items():
        if keyword in lower:
            return hint
    return _DEFAULT_HINT


# ── Component inference ────────────────────────────────────────────────────────

# Keywords whose presence in the description suggests a specific component.
_PAGE_SIGNALS: list[tuple[str, str]] = [
    ("landing page",    "HomePage"),
    ("marketing site",  "HomePage"),
    ("home page",       "HomePage"),
    ("homepage",        "HomePage"),
    ("dashboard",       "DashboardPage"),
    ("admin panel",     "DashboardPage"),
    ("login",           "LoginPage"),
    ("sign in",         "LoginPage"),
    ("signup",          "SignupPage"),
    ("sign up",         "SignupPage"),
    ("register",        "SignupPage"),
    ("about page",      "AboutPage"),
    ("about us",        "AboutPage"),
    ("contact page",    "ContactPage"),
    ("pricing page",    "PricingPage"),
]

_SECTION_SIGNALS: list[tuple[str, str]] = [
    ("hero",            "HeroSection"),
    ("features",        "FeaturesSection"),
    ("feature section", "FeaturesSection"),
    ("pricing",         "PricingSection"),
    ("testimonial",     "TestimonialsSection"),
    ("review",          "TestimonialsSection"),
    ("call to action",  "CTASection"),
    ("cta",             "CTASection"),
    ("faq",             "FAQSection"),
    ("team",            "TeamSection"),
    ("banner",          "BannerSection"),
    ("header",          "Header"),
    ("footer",          "Footer"),
    ("navbar",          "Header"),
    ("navigation",      "Header"),
]


def _infer_components(
    description: str,
) -> tuple[list[str], list[str]]:
    """
    Infer page and section/layout component names from a text description.
    Returns (pages, components).  Deduplicates while preserving insertion order.
    """
    lower = description.lower()
    pages: list[str] = []
    components: list[str] = []
    seen: set[str] = set()

    for signal, name in _PAGE_SIGNALS:
        if signal in lower and name not in seen:
            pages.append(name)
            seen.add(name)

    for signal, name in _SECTION_SIGNALS:
        if signal in lower and name not in seen:
            components.append(name)
            seen.add(name)

    # Fallback: nothing inferred → scaffold a root home page
    if not pages and not components:
        pages.append("HomePage")

    return pages, components


# ── Spec builder ──────────────────────────────────────────────────────────────

def _build_spec(stem: str, project_name: str, description: str, golden_path: str) -> str:
    """
    Build a concise design specification string for a single component.
    This becomes `figma_source` in the queue file — the LLM reads it as the
    design brief and creates the component from scratch.
    """
    hint = _hint_for(stem)
    return (
        f"## Project: {project_name}\n\n"
        f"{description.strip()}\n\n"
        f"## Component: {stem}\n\n"
        f"{hint}\n\n"
        f"Design tokens, typography, and colours must be consistent with a modern "
        f"{golden_path} application and with any other components in the same project.\n"
        f"Follow all `.claude/agents/{golden_path}.md` rules.\n"
        f"There is no Figma source — create this component entirely from the spec above."
    )


def _make_entry(stem: str, project_name: str, description: str, golden_path: str) -> dict:
    """Build a manifest component/page entry for a prompt-derived component."""
    spec = _build_spec(stem, project_name, description, golden_path)
    return {
        "filename": f"{stem}.tsx",
        "stem": stem,
        "extension": ".tsx",
        "size_bytes": len(spec.encode()),
        "content": spec,
    }


# ── Tool registration ─────────────────────────────────────────────────────────

def register_prompt_ingest_tool(mcp: FastMCP) -> None:

    @mcp.tool()
    async def ingest_from_prompt(
        description: str,
        golden_path: str,
        project_name: str = "my-app",
        pages: list[str] | None = None,
        components: list[str] | None = None,
    ) -> str:
        """
        Generate a Nexus pipeline manifest from a text description — no Figma file needed.

        Covers two use cases:
          • Scaffold only: pass a short description like "scaffold a nextjs-fullstack starter"
            and leave pages/components empty — you get the golden path boilerplate with no UI.
          • Description-driven: describe what to build and optionally list the pages and
            components you want. The pipeline creates each one from scratch guided by the
            description.

        The manifest produced is identical in format to ingest_figma_zip output, so
        remap_to_golden_path, validate_output, and package_output work unchanged.

        Args:
            description: Natural language description of what to build.
                         E.g. "A SaaS landing page with a hero, features grid, pricing
                         table, testimonials, and a footer. Modern, clean aesthetic."
            golden_path: Target stack. One of the available golden paths.
            project_name: Slug used for the output folder and package.json name.
            pages: Optional explicit list of page component names to create.
                   E.g. ["HomePage", "AboutPage", "PricingPage"].
                   If omitted, inferred from the description.
            components: Optional explicit list of section/UI component names to create.
                        E.g. ["HeroSection", "FeaturesSection", "PricingSection", "Footer"].
                        If omitted, inferred from the description.

        Returns:
            JSON manifest (same shape as ingest_figma_zip) with source_type: "prompt".
            Pass this directly to remap_to_golden_path.
        """
        logger.info(
            f"ingest_from_prompt called — golden_path: '{golden_path}', "
            f"project: '{project_name}', "
            f"explicit pages: {pages}, explicit components: {components}"
        )

        # ── Validate inputs ───────────────────────────────────────────────────
        if not description.strip():
            return json.dumps({"error": "description is required."})

        if not golden_path.strip():
            return json.dumps({
                "error": (
                    "golden_path is required. Available: "
                    f"{', '.join(sorted(VALID_GOLDEN_PATHS))}"
                )
            })

        if golden_path not in VALID_GOLDEN_PATHS:
            return json.dumps({
                "error": (
                    f"Invalid golden_path '{golden_path}'. "
                    f"Must be one of: {', '.join(sorted(VALID_GOLDEN_PATHS))}"
                )
            })

        # ── Resolve pages and components ──────────────────────────────────────
        if pages is None and components is None:
            inferred_pages, inferred_components = _infer_components(description)
        else:
            inferred_pages = list(pages) if pages else []
            inferred_components = list(components) if components else []

        logger.info(
            f"Resolved — pages: {inferred_pages}, components: {inferred_components}"
        )

        # ── Build manifest entries ────────────────────────────────────────────
        page_entries = [
            _make_entry(stem, project_name, description, golden_path)
            for stem in inferred_pages
        ]
        component_entries = [
            _make_entry(stem, project_name, description, golden_path)
            for stem in inferred_components
        ]

        total = len(page_entries) + len(component_entries)

        manifest = {
            "project_name": project_name,
            "golden_path": golden_path,
            "source_type": "prompt",
            "description": description.strip(),
            "total_files": total,
            "summary": {
                "components": len(component_entries),
                "pages": len(page_entries),
                "styles": 0,
                "assets": 0,
                "unknown": 0,
            },
            "components": component_entries,
            "pages": page_entries,
            "styles": [],
            "assets": [],
            "unknown": [],
        }

        # ── Write to disk cache ───────────────────────────────────────────────
        cache_dir = pathlib.Path(f"/tmp/nexus-{project_name}")
        if cache_dir.exists():
            shutil.rmtree(cache_dir)
        cache_dir.mkdir(parents=True)
        (cache_dir / "01_manifest.json").write_text(
            json.dumps(manifest), encoding="utf-8"
        )

        logger.info(
            f"ingest_from_prompt complete — {total} virtual components "
            f"({len(page_entries)} pages, {len(component_entries)} sections/ui)"
        )

        return json.dumps({
            "project_name": project_name,
            "golden_path": golden_path,
            "source_type": "prompt",
            "total_files": total,
            "summary": manifest["summary"],
            "_nexus_cache": str(cache_dir),
        })
