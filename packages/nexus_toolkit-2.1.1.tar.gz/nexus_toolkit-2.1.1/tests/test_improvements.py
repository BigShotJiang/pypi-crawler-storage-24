"""
Regression tests for the six pipeline improvements documented in
figma-make-to-golden-path-journey.md.

Covers:
  2a. lib/utils.ts (and other requiredFiles) now seeded from reference — no MISSING_REQUIRED
  2b. Header/Footer seeded from reference
  2c. Section classifier catches portfolio keywords + manifest signals
  2d. shadcn passthrough tagged → SHADCN_PASSTHROUGH not ORPHAN_FILE; inline-style suppressed
  2e. Radix/Recharts inline styles suppressed for passthrough files
  2f. Pre-flight surfaces missing required files in remap result
"""

import json
import pathlib
from unittest.mock import MagicMock

import pytest

from tools.figma.remap import _classify, register_remap_tool
from tools.figma.validate import _run_checks
from tools.figma.ingest import register_ingest_tool
from tools.figma.codebase_ingest import register_codebase_ingest_tool
from tools.figma.validate import register_validate_tool


# ── helpers ───────────────────────────────────────────────────────────────────

def _extract_tool(register_fn):
    captured = {}
    mock_mcp = MagicMock()
    mock_mcp.tool.return_value = lambda f: captured.setdefault("fn", f) or f
    register_fn(mock_mcp)
    return captured["fn"]


def _file(path: str, content: str) -> dict:
    return {"path": path, "content": content}


def _tree(*files, golden_path="nextjs-static", passthrough_paths=None) -> dict:
    return {
        "golden_path": golden_path,
        "files": list(files),
        "passthrough_paths": passthrough_paths or [],
    }


# ── 2c. Section classifier ─────────────────────────────────────────────────────

class TestSectionClassifier:
    """_classify() should route portfolio section names correctly."""

    # Manifest rules used for most tests (nextjs-static shape)
    RULES = {
        "categories": {
            "layout": {"outputPath": "components/layout/{ComponentName}.tsx",
                        "signals": ["Header", "Footer", "Navbar"]},
            "section": {"outputPath": "components/sections/{ComponentName}.tsx",
                        "signals": ["Hero", "Features", "Pricing"]},
            "ui":      {"outputPath": "components/ui/{ComponentName}.tsx",
                        "signals": ["Button", "Card"]},
        }
    }

    # ── original terms still work ────────────────────────────────────────────
    def test_hero_is_section(self):
        assert _classify("Hero", self.RULES, "nextjs-static") == "section"

    def test_pricing_is_section(self):
        assert _classify("Pricing", self.RULES, "nextjs-static") == "section"

    def test_contact_is_section(self):
        assert _classify("Contact", self.RULES, "nextjs-static") == "section"

    # ── newly added portfolio keywords (suggestion 2c) ───────────────────────
    def test_experience_is_section(self):
        assert _classify("Experience", self.RULES, "nextjs-static") == "section"

    def test_projects_is_section(self):
        assert _classify("Projects", self.RULES, "nextjs-static") == "section"

    def test_skills_is_section(self):
        assert _classify("Skills", self.RULES, "nextjs-static") == "section"

    def test_work_is_section(self):
        assert _classify("Work", self.RULES, "nextjs-static") == "section"

    def test_portfolio_is_section(self):
        assert _classify("Portfolio", self.RULES, "nextjs-static") == "section"

    def test_gallery_is_section(self):
        assert _classify("Gallery", self.RULES, "nextjs-static") == "section"

    def test_services_is_section(self):
        assert _classify("Services", self.RULES, "nextjs-static") == "section"

    def test_timeline_is_section(self):
        assert _classify("Timeline", self.RULES, "nextjs-static") == "section"

    def test_education_is_section(self):
        assert _classify("Education", self.RULES, "nextjs-static") == "section"

    def test_certifications_is_section(self):
        assert _classify("Certifications", self.RULES, "nextjs-static") == "section"

    # ── manifest signals for section also consulted (suggestion 2c) ──────────
    def test_manifest_section_signal_features_is_section(self):
        """'Features' is in manifest section.signals but not SECTION_KEYWORDS."""
        assert _classify("Features", self.RULES, "nextjs-static") == "section"

    # ── compound names containing keywords ───────────────────────────────────
    def test_compound_name_containing_experience(self):
        assert _classify("WorkExperience", self.RULES, "nextjs-static") == "section"

    def test_compound_name_containing_skills(self):
        assert _classify("TechSkills", self.RULES, "nextjs-static") == "section"

    # ── other categories still classified correctly ───────────────────────────
    def test_button_is_ui(self):
        assert _classify("Button", self.RULES, "nextjs-static") == "ui"

    def test_card_is_ui(self):
        assert _classify("Card", self.RULES, "nextjs-static") == "ui"

    def test_header_is_layout(self):
        assert _classify("Header", self.RULES, "nextjs-static") == "layout"

    def test_footer_is_layout(self):
        assert _classify("Footer", self.RULES, "nextjs-static") == "layout"

    def test_app_is_root_page(self):
        assert _classify("app", self.RULES, "nextjs-static") == "root_page"

    def test_utils_is_discarded(self):
        assert _classify("utils", self.RULES, "nextjs-static") == "discard"


# ── 2d. SHADCN_PASSTHROUGH vs ORPHAN_FILE ────────────────────────────────────

class TestPassthroughVsOrphan:
    """Unreachable shadcn files should emit SHADCN_PASSTHROUGH, not ORPHAN_FILE."""

    # Minimal reachable tree: a page that imports nothing from ui/
    PAGE_CONTENT = (
        '"use client";\n'
        'export default function Page() { return <main>Hello</main>; }'
    )

    def test_orphan_shadcn_file_becomes_shadcn_passthrough(self):
        files = [
            _file("app/page.tsx", self.PAGE_CONTENT),
            _file("components/ui/button.tsx", '"use client";\nexport function Button() {}'),
        ]
        tree = _tree(*files, passthrough_paths=["components/ui/button.tsx"])
        errors, warnings = _run_checks(files, "nextjs-static",
                                       passthrough_paths=set(tree["passthrough_paths"]))
        shadcn_warns = [w for w in warnings if w.startswith("SHADCN_PASSTHROUGH")]
        orphan_warns = [w for w in warnings if "ORPHAN_FILE" in w and "button" in w]
        assert len(shadcn_warns) == 1
        assert len(orphan_warns) == 0

    def test_genuinely_orphan_file_stays_orphan(self):
        """A non-passthrough unreachable file still gets ORPHAN_FILE."""
        files = [
            _file("app/page.tsx", self.PAGE_CONTENT),
            _file("components/sections/Unused.tsx", "export function Unused() {}"),
        ]
        tree = _tree(*files, passthrough_paths=[])
        errors, warnings = _run_checks(files, "nextjs-static",
                                       passthrough_paths=set(tree["passthrough_paths"]))
        orphan_warns = [w for w in warnings if "ORPHAN_FILE" in w and "Unused" in w]
        assert len(orphan_warns) == 1

    def test_multiple_passthrough_files_all_downgraded(self):
        """All shadcn primitives in passthrough_paths should become SHADCN_PASSTHROUGH."""
        shadcn_files = [
            "components/ui/button.tsx",
            "components/ui/card.tsx",
            "components/ui/input.tsx",
        ]
        files = [
            _file("app/page.tsx", self.PAGE_CONTENT),
            *[_file(p, '"use client";\nexport function X() {}') for p in shadcn_files],
        ]
        errors, warnings = _run_checks(files, "nextjs-static",
                                       passthrough_paths=set(shadcn_files))
        shadcn_warns = [w for w in warnings if w.startswith("SHADCN_PASSTHROUGH")]
        orphan_warns = [w for w in warnings if "ORPHAN_FILE" in w]
        assert len(shadcn_warns) == 3
        assert len(orphan_warns) == 0


# ── 2e. Inline style suppressed for passthrough files ────────────────────────

class TestInlineStyleSuppressionForPassthrough:
    """Radix/Recharts inline styles in passthrough files must not emit FIGMA_ARTIFACT."""

    PAGE = 'export default function Page() { return <main/>; }'

    # Radix progress bar pattern
    PROGRESS_CONTENT = (
        '"use client";\n'
        'export function Progress({ value }: { value: number }) {\n'
        '  return (\n'
        '    <div>\n'
        '      <div style={{ transform: `translateX(-${100 - (value || 0)}%)` }} />\n'
        '    </div>\n'
        '  );\n'
        '}\n'
    )

    # Recharts chart pattern
    CHART_CONTENT = (
        '"use client";\n'
        'export function Chart({ color }: { color: string }) {\n'
        '  return <div style={{ "--color-bg": color } as React.CSSProperties} />;\n'
        '}\n'
    )

    def test_radix_progress_inline_style_suppressed_for_passthrough(self):
        files = [
            _file("app/page.tsx", self.PAGE),
            _file("components/ui/progress.tsx", self.PROGRESS_CONTENT),
        ]
        errors, warnings = _run_checks(
            files, "nextjs-static",
            passthrough_paths={"components/ui/progress.tsx"},
        )
        figma_warns = [w for w in warnings if "FIGMA_ARTIFACT" in w and "progress" in w]
        assert len(figma_warns) == 0

    def test_recharts_chart_inline_style_suppressed_for_passthrough(self):
        files = [
            _file("app/page.tsx", self.PAGE),
            _file("components/ui/chart.tsx", self.CHART_CONTENT),
        ]
        errors, warnings = _run_checks(
            files, "nextjs-static",
            passthrough_paths={"components/ui/chart.tsx"},
        )
        figma_warns = [w for w in warnings if "FIGMA_ARTIFACT" in w and "chart" in w]
        assert len(figma_warns) == 0

    def test_inline_style_in_non_passthrough_file_still_warned(self):
        """A transformed component with inline styles should still trigger the warning."""
        files = [
            _file("app/page.tsx", self.PAGE),
            _file("components/sections/Hero.tsx",
                  'export function Hero() { return <div style={{color:"red"}}/>; }'),
        ]
        errors, warnings = _run_checks(files, "nextjs-static", passthrough_paths=set())
        figma_warns = [w for w in warnings if "FIGMA_ARTIFACT" in w and "Hero" in w]
        assert len(figma_warns) == 1


# ── 2a + 2b. Golden path reference completeness ───────────────────────────────

class TestGoldenPathReferenceCompleteness:
    """Every file in requiredFiles must exist in the reference/ directory."""

    NEXUS_ROOT = pathlib.Path(__file__).parent.parent
    GOLDEN_PATHS_DIR = NEXUS_ROOT / "golden_paths"

    def _check_golden_path(self, name: str):
        ref_dir = self.GOLDEN_PATHS_DIR / name / "reference"
        manifest_path = self.GOLDEN_PATHS_DIR / name / "manifest.json"
        if not manifest_path.exists():
            pytest.skip(f"No manifest for {name}")
        ref_files = {
            f.relative_to(ref_dir).as_posix()
            for f in ref_dir.rglob("*") if f.is_file()
        }
        manifest = json.loads(manifest_path.read_text())
        required = manifest.get("requiredFiles", [])
        missing = [r for r in required if r not in ref_files]
        assert missing == [], (
            f"{name}: requiredFiles not in reference/: {missing}\n"
            f"Fix: add these files to golden_paths/{name}/reference/"
        )

    def test_nextjs_static_reference_complete(self):
        self._check_golden_path("nextjs-static")

    def test_nextjs_fullstack_reference_complete(self):
        self._check_golden_path("nextjs-fullstack")

    def test_t3_stack_reference_complete(self):
        self._check_golden_path("t3-stack")

    def test_vite_spa_reference_complete(self):
        self._check_golden_path("vite-spa")

    def test_monorepo_reference_complete(self):
        self._check_golden_path("monorepo")

    def test_full_stack_rn_reference_complete(self):
        self._check_golden_path("full-stack-rn")


# ── 2f. Pre-flight check in remap result ─────────────────────────────────────

class TestRemapPreflightCheck:
    """remap_to_golden_path must expose missing_required_preflight in its result."""

    @pytest.fixture(autouse=True)
    def setup(self):
        self.remap = _extract_tool(register_remap_tool)
        self.ingest = _extract_tool(register_ingest_tool)
        self.codebase_ingest = _extract_tool(register_codebase_ingest_tool)

    @pytest.mark.asyncio
    async def test_preflight_key_present_in_result(self, tmp_path):
        (tmp_path / "Hero.tsx").write_text(
            "export function Hero() { return <section>Hello</section>; }"
        )
        manifest = await self.codebase_ingest(
            project_dir=str(tmp_path), golden_path="nextjs-static", project_name="preflight-test"
        )
        result = json.loads(await self.remap(manifest))
        assert "missing_required_preflight" in result

    @pytest.mark.asyncio
    async def test_nextjs_static_preflight_empty_after_reference_fix(self, tmp_path):
        """After adding reference files, remap must seed ALL required files with no gaps."""
        (tmp_path / "Hero.tsx").write_text(
            "export function Hero() { return <section>Hello</section>; }"
        )
        manifest = await self.codebase_ingest(
            project_dir=str(tmp_path), golden_path="nextjs-static", project_name="preflight-empty"
        )
        result = json.loads(await self.remap(manifest))
        missing = result.get("missing_required_preflight", ["MISSING_KEY"])
        assert missing == [], (
            f"nextjs-static still has unseeded required files after reference fix: {missing}"
        )

    @pytest.mark.asyncio
    async def test_passthrough_paths_written_to_file_tree(self):
        """
        shadcn passthrough only fires for source_type='figma' (ZIP ingest).
        The passthrough_paths list in 04_file_tree.json must be populated for
        any @radix-ui component that comes through the ZIP pipeline.
        """
        import base64, io, zipfile as _zipfile

        shadcn_source = (
            '"use client";\n'
            'import * as React from "react";\n'
            'import { Slot } from "@radix-ui/react-slot@1.1.2";\n'
            'import { cn } from "./utils";\n'
            'export function Button({ className, children }) {\n'
            '  return <Slot className={cn("btn", className)}>{children}</Slot>;\n'
            '}\n'
        )
        buf = io.BytesIO()
        with _zipfile.ZipFile(buf, "w") as zf:
            zf.writestr("components/button.tsx", shadcn_source)
        zip_b64 = base64.b64encode(buf.getvalue()).decode()

        manifest = await self.ingest(
            zip_b64, golden_path="nextjs-static", project_name="passthrough-test"
        )
        result = json.loads(await self.remap(manifest))
        cache = pathlib.Path(result["_nexus_cache"])
        file_tree = json.loads((cache / "04_file_tree.json").read_text())

        passthrough = file_tree.get("passthrough_paths", [])
        assert isinstance(passthrough, list)
        assert any("button" in p for p in passthrough), (
            f"Expected button.tsx in passthrough_paths (radix-ui import should trigger passthrough). "
            f"Got: {passthrough}"
        )


# ── Integration: ingest → remap → validate passes clean for nextjs-static ────

class TestEndToEndValidation:
    """
    Full pipeline smoke test: a minimal portfolio ingest should pass validate_output
    with zero errors after our fixes (no MISSING_REQUIRED, no cascading BROKEN_IMPORTs).
    """

    @pytest.fixture(autouse=True)
    def setup(self):
        self.codebase_ingest = _extract_tool(register_codebase_ingest_tool)
        self.remap = _extract_tool(register_remap_tool)
        self.validate = _extract_tool(register_validate_tool)

    @pytest.mark.asyncio
    async def test_no_missing_required_after_remap(self, tmp_path):
        """After remap, all nextjs-static requiredFiles are present in the file tree."""
        (tmp_path / "Hero.tsx").write_text(
            "export function Hero() { return <section>Hero</section>; }"
        )
        manifest = await self.codebase_ingest(
            project_dir=str(tmp_path), golden_path="nextjs-static", project_name="e2e-validate"
        )
        remap_result = json.loads(await self.remap(manifest))
        cache = pathlib.Path(remap_result["_nexus_cache"])
        file_tree = json.loads((cache / "04_file_tree.json").read_text())
        paths = {f["path"] for f in file_tree["files"]}

        manifest_json = json.loads(
            (pathlib.Path(__file__).parent.parent / "golden_paths" / "nextjs-static" / "manifest.json").read_text()
        )
        required = manifest_json["requiredFiles"]
        missing = [r for r in required if r not in paths]
        assert missing == [], f"Required files missing from file tree after remap: {missing}"

    @pytest.mark.asyncio
    async def test_validate_has_no_missing_required_errors(self, tmp_path):
        """validate_output must not return MISSING_REQUIRED errors after our reference fix."""
        # Minimal portfolio-like source
        (tmp_path / "Hero.tsx").write_text(
            "export function Hero() { return <section>Hero</section>; }"
        )
        (tmp_path / "Experience.tsx").write_text(
            "export function Experience() { return <section>Experience</section>; }"
        )
        manifest = await self.codebase_ingest(
            project_dir=str(tmp_path), golden_path="nextjs-static", project_name="e2e-noerror"
        )
        remap_result = json.loads(await self.remap(manifest))
        validate_result = json.loads(
            await self.validate(json.dumps({
                "project_name": "e2e-noerror",
                "golden_path": "nextjs-static",
                "_nexus_cache": remap_result["_nexus_cache"],
            }))
        )
        missing_required_errors = [
            e for e in validate_result.get("errors", [])
            if e.startswith("MISSING_REQUIRED")
        ]
        assert missing_required_errors == [], (
            f"validate_output still has MISSING_REQUIRED errors:\n"
            + "\n".join(missing_required_errors)
        )

    @pytest.mark.asyncio
    async def test_experience_routes_to_sections_not_ui(self, tmp_path):
        """Experience, Projects, Skills should land in components/sections/, not components/ui/."""
        for name in ["Experience", "Projects", "Skills"]:
            (tmp_path / f"{name}.tsx").write_text(
                f"export function {name}() {{ return <section>{name}</section>; }}"
            )
        manifest = await self.codebase_ingest(
            project_dir=str(tmp_path), golden_path="nextjs-static", project_name="e2e-sections"
        )
        remap_result = json.loads(await self.remap(manifest))
        cache = pathlib.Path(remap_result["_nexus_cache"])
        file_tree = json.loads((cache / "04_file_tree.json").read_text())
        paths = [f["path"] for f in file_tree["files"]]

        for name in ["Experience", "Projects", "Skills"]:
            in_sections = any(f"components/sections/{name}.tsx" == p for p in paths)
            in_ui = any(f"components/ui/{name}.tsx" == p for p in paths)
            assert in_sections, f"{name} not found in components/sections/ — paths: {paths}"
            assert not in_ui, f"{name} incorrectly placed in components/ui/"

    @pytest.mark.asyncio
    async def test_shadcn_passthrough_no_broken_import_cascade(self, tmp_path):
        """
        When a shadcn file is auto-passthrough'd, its @/lib/utils import must resolve
        (because lib/utils.ts is now seeded from reference).
        No BROKEN_IMPORT errors should appear.
        """
        (tmp_path / "button.tsx").write_text(
            '"use client";\n'
            'import { cn } from "@/lib/utils";\n'
            'import { Slot } from "@radix-ui/react-slot";\n'
            'export function Button({ className, ...props }) {\n'
            '  return <Slot className={cn("btn", className)} {...props} />;\n'
            '}\n'
        )
        manifest = await self.codebase_ingest(
            project_dir=str(tmp_path), golden_path="nextjs-static", project_name="e2e-broken-import"
        )
        remap_result = json.loads(await self.remap(manifest))
        validate_result = json.loads(
            await self.validate(json.dumps({
                "project_name": "e2e-broken-import",
                "golden_path": "nextjs-static",
                "_nexus_cache": remap_result["_nexus_cache"],
            }))
        )
        broken_import_errors = [
            e for e in validate_result.get("errors", [])
            if e.startswith("BROKEN_IMPORT")
        ]
        assert broken_import_errors == [], (
            f"BROKEN_IMPORT errors found (lib/utils.ts not seeded?):\n"
            + "\n".join(broken_import_errors)
        )
