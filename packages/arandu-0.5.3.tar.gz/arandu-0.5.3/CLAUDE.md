# CLAUDE.md — Arandu SDK

## Post-implementation checklist (OBRIGATÓRIO)

Após QUALQUER feature, fix ou mudança de código — SEMPRE, sem perguntar:

1. **Bump de versão** no `pyproject.toml` (patch para fixes, minor para features, major para breaking changes)
2. **Atualizar docs/en/** — documentação em inglês refletindo a mudança (GitHub Pages)
3. **Atualizar docs/pt-BR/** — documentação em português refletindo a mudança (GitHub Pages)
4. **Atualizar mkdocs.yml** se houver nova página de docs
5. **Avisar o usuário** que a versão foi bumpada (ele precisa disparar release manual no GitHub Actions)

Isso NÃO é opcional. NÃO esperar o usuário pedir. Fazer como parte da implementação.

### O que "atualizar docs" significa

Não é só trocar um comentário numa linha. É revisar TODAS as seções dos docs
que falam sobre o comportamento que mudou e atualizar o texto, exemplos e
descrições. Os docs são a documentação pública do GitHub Pages — se o
comportamento mudou no código, os docs TÊM que refletir isso com o mesmo
nível de detalhe. Pensar: "se um dev ler só os docs, ele vai entender o
comportamento atual?" Se não, tá faltando coisa.

## CI antes de push

Rodar ruff + mypy + pytest ANTES de qualquer commit/push. Já quebrou CI 3+ vezes por pular mypy.

```bash
python -m ruff check src/ tests/ && python -m ruff format --check src/ tests/ && python -m mypy src/arandu/ && python -m pytest tests/ -q
```

## Comunicação

- Ter opinião forte, não flip-flopar
- Explicar simples, sem jargão desnecessário
- Português como idioma padrão de conversa
