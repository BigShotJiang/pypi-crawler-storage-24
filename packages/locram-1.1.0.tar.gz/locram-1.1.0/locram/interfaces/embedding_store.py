from abc import ABC, abstractmethod


class EmbeddingStore(ABC):

    @abstractmethod
    def store(
        self,
        page_id: str,
        field: str,
        embedding: bytes,
        model: str,
        dimension: int,
    ) -> None: ...

    @abstractmethod
    def get(self, page_id: str, field: str = "content") -> dict | None: ...

    @abstractmethod
    def delete(self, page_id: str) -> None: ...

    @abstractmethod
    def find_unembedded(self, limit: int = 100) -> list[str]: ...

    # Phase 2:
    # @abstractmethod
    # def search_similar(self, query_vec: bytes, limit: int, field: str = "content") -> list[dict]: ...
