from ulid import ULID

from locram.interfaces.page_repository import PageRepository
from locram.interfaces.vault_store import VaultStore
from locram.models import Page, PageStatus, PageType
from locram.services.enrichment import enrich_page


class PageService:

    def __init__(self, repo: PageRepository, vault: VaultStore):
        self._repo = repo
        self._vault = vault

    def create_page(
        self,
        title: str,
        content: str = "",
        type: str = "fleeting",
        status: str = "active",
        subject: list[str] | None = None,
        tags: list[str] | None = None,
        parent_id: str | None = None,
        review_interval_days: int = 7,
    ) -> Page:
        page = Page(
            id=str(ULID()),
            title=title,
            content=content,
            type=PageType(type),
            status=PageStatus(status),
            subject=subject or [],
            tags=tags or [],
            parent_id=parent_id,
            review_interval_days=review_interval_days,
        )
        page = self._repo.create(page)
        page = self._enrich(page)
        self._vault.write(page)
        return page

    def get_page(self, page_id: str) -> Page | None:
        page = self._repo.get(page_id)
        if page is None:
            return None
        return self._enrich(page)

    def update_page(self, page_id: str, **fields) -> Page | None:
        page = self._repo.update(page_id, **fields)
        if page is None:
            return None
        page = self._enrich(page)
        self._vault.write(page)
        return page

    def delete_page(self, page_id: str, hard: bool = False) -> bool:
        ok = self._repo.delete(page_id, hard=hard)
        if ok and hard:
            self._vault.remove(page_id)
        elif ok:
            # Soft delete: update .md status field (re-write the file)
            page = self._repo.get(page_id)
            if page:
                page = self._enrich(page)
                self._vault.write(page)
        return ok

    def list_pages(self, **filters) -> list[dict]:
        return self._repo.list_pages(**filters)

    def promote_page(self, page_id: str) -> dict:
        """Maturity promotion: fleeting → note-taking → permanent.
        structure/hub are classification types — use update_page instead.
        Cannot demote."""
        from locram.models import MATURITY_ORDER
        page = self._repo.get(page_id)
        if page is None:
            return {"error": f"Page {page_id} not found"}
        if page.type not in MATURITY_ORDER:
            return {
                "error": (
                    f"Cannot promote: type '{page.type.value}' is a classification type "
                    f"(structure/hub). Use update_page(type=...) to change classification."
                )
            }
        current_index = MATURITY_ORDER.index(page.type)
        if current_index >= len(MATURITY_ORDER) - 1:
            return {"error": f"Already at maximum maturity: '{page.type.value}'"}
        next_type = MATURITY_ORDER[current_index + 1]
        self.update_page(page_id, type=next_type.value)
        return {
            "id": page_id,
            "previous_type": page.type.value,
            "new_type": next_type.value,
        }

    def _enrich(self, page: Page) -> Page:
        return enrich_page(self._repo, page)
