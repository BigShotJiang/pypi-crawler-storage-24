"""Auto-configure Obsidian inside the vault on first run."""
import json
from pathlib import Path


def setup_obsidian(vault: Path) -> None:
    obsidian = vault / ".obsidian"
    obsidian.mkdir(exist_ok=True)
    (vault / "templates").mkdir(exist_ok=True)
    (vault / "attachments").mkdir(exist_ok=True)

    _write_json(obsidian / "app.json", {
        "showInlineTitle": True,
        "attachmentFolderPath": "attachments",
    })

    _write_json(obsidian / "types.json", {
        "types": {
            "type":      "text",
            "subject":   "multitext",
            "tags":      "tags",
            "status":    "text",
            "created":   "datetime",
            "updated":   "datetime",
            "review in": "number",
            "parent":    "text",
            "id":        "text",
        }
    })

    _write_json(obsidian / "templates.json", {"folder": "templates"})

    _write_json(obsidian / "core-plugins.json", [
        "file-explorer", "global-search", "graph", "backlink",
        "outgoing-link", "tag-pane", "properties", "templates",
        "outline", "word-count", "file-recovery",
    ])

    _write_json(obsidian / "graph.json", {
        "collapse-filter": False,
        "search": "",
        "showTags": False,
        "showAttachments": False,
        "hideUnresolved": False,
        "showOrphans": True,
        "collapse-color-groups": False,
        "colorGroups": [],
        "collapse-display": False,
        "showArrow": True,
        "textFadeMultiplier": 0,
        "nodeSizeMultiplier": 1,
        "lineSizeMultiplier": 1,
        "collapse-forces": False,
        "centerStrength": 0.518713248970312,
        "repelStrength": 10,
        "linkStrength": 1,
        "linkDistance": 250,
        "scale": 1,
        "close": False,
    })

    template_path = vault / "templates" / "locram note.md"
    if not template_path.exists():
        template_path.write_text(
            "---\n"
            "type: fleeting\n"
            "subject: []\n"
            "tags: []\n"
            "status: active\n"
            "created: {{date:YYYY-MM-DD}}T{{time:HH:mm}}\n"
            "updated: {{date:YYYY-MM-DD}}T{{time:HH:mm}}\n"
            "review in: 7\n"
            "parent:\n"
            "id:\n"
            "---\n"
            "\n"
            "<!-- type: fleeting | note-taking | permanent | structure | hub -->\n"
            "<!-- status: active | archived | to_delete -->\n",
            encoding="utf-8",
        )


def _write_json(path: Path, data) -> None:
    if not path.exists():
        path.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")
