from locram.adapters.db import get_connection
from locram.config import DB_PATH
from locram.interfaces.embedding_store import EmbeddingStore


class SqliteEmbeddingStore(EmbeddingStore):

    def __init__(self, db_path=DB_PATH):
        self._db_path = db_path

    def store(
        self,
        page_id: str,
        field: str,
        embedding: bytes,
        model: str,
        dimension: int,
    ) -> None:
        with get_connection(self._db_path) as conn:
            conn.execute(
                """INSERT INTO page_embeddings (page_id, field, embedding, model, dimension)
                   VALUES (?, ?, ?, ?, ?)
                   ON CONFLICT(page_id, field) DO UPDATE SET
                       embedding   = excluded.embedding,
                       model       = excluded.model,
                       dimension   = excluded.dimension,
                       embedded_at = strftime('%Y-%m-%dT%H:%M:%SZ','now')""",
                (page_id, field, embedding, model, dimension),
            )

    def get(self, page_id: str, field: str = "content") -> dict | None:
        with get_connection(self._db_path) as conn:
            row = conn.execute(
                "SELECT * FROM page_embeddings WHERE page_id = ? AND field = ?",
                (page_id, field),
            ).fetchone()
            return dict(row) if row else None

    def delete(self, page_id: str) -> None:
        with get_connection(self._db_path) as conn:
            conn.execute(
                "DELETE FROM page_embeddings WHERE page_id = ?", (page_id,)
            )

    def find_unembedded(self, limit: int = 100) -> list[str]:
        with get_connection(self._db_path) as conn:
            rows = conn.execute(
                """SELECT id FROM pages
                   WHERE status = 'active'
                     AND id NOT IN (
                         SELECT page_id FROM page_embeddings WHERE field = 'content'
                     )
                   ORDER BY updated_at DESC
                   LIMIT ?""",
                (limit,),
            ).fetchall()
            return [r["id"] for r in rows]
