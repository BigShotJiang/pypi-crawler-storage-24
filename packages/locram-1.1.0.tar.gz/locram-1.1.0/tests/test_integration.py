"""End-to-end integration: full flow through services."""


def test_full_zettelkasten_flow(pages_svc, links_svc, search_svc, graph_svc, repo, vault):
    # Create notes
    hub = pages_svc.create_page("AI Knowledge Hub", type="hub", subject=["ai"])
    perm = pages_svc.create_page("Transformer Architecture", type="permanent",
                                  content="Self-attention mechanism scales well.")
    fleeting = pages_svc.create_page("Quick thought on embeddings", type="fleeting",
                                      content="Embeddings capture semantic meaning.")

    # Link
    links_svc.link_pages(hub.id, perm.id, "related")
    links_svc.set_parent(perm.id, hub.id)

    # Get with context
    fetched_hub = pages_svc.get_page(hub.id)
    assert any(c["id"] == perm.id for c in fetched_hub.connected_to)
    assert any(s["id"] == perm.id for s in fetched_hub.sub_items)

    # Search
    results = search_svc.search("attention")
    assert any(r["id"] == perm.id for r in results)

    # Promote fleeting → note-taking
    promote_result = pages_svc.promote_page(fleeting.id)
    assert promote_result["new_type"] == "note-taking"

    # Orphaned
    orphans = graph_svc.find_orphaned()
    orphan_ids = [o["id"] for o in orphans]
    # fleeting note has no links, still orphaned (hub→perm linked, fleeting not linked)
    assert fleeting.id in orphan_ids or promote_result["new_type"] == "note-taking"

    # Graph summary
    gs = graph_svc.get_graph_summary()
    assert gs["page_count"] == 3
    assert gs["link_count"] >= 1

    # Vault: 3 .md files
    vault_files = list(vault.vault_path.glob("*.md"))
    assert len(vault_files) == 3

    # Soft delete
    ok = pages_svc.delete_page(fleeting.id)
    assert ok
    refreshed = repo.get(fleeting.id)
    assert refreshed.status.value == "to_delete"

    # Hard delete
    pages_svc.delete_page(perm.id, hard=True)
    assert repo.get(perm.id) is None


def test_inline_mentions_exact_title_lookup(pages_svc, repo):
    """inline_mentions must resolve [[wikilinks]] via exact title match, not FTS."""
    target = pages_svc.create_page("Transformer Architecture", content="About transformers.")
    referrer = pages_svc.create_page(
        "Attention Overview",
        content="See also [[Transformer Architecture]] for details.",
    )

    enriched = pages_svc.get_page(referrer.id)
    assert len(enriched.inline_mentions) == 1
    assert enriched.inline_mentions[0]["id"] == target.id
    assert enriched.inline_mentions[0]["title"] == "Transformer Architecture"


def test_inline_mentions_missing_target(pages_svc, repo):
    """Wikilink to non-existent page must not appear in inline_mentions."""
    page = pages_svc.create_page(
        "Dangling Link",
        content="References [[NonExistent Page]] here.",
    )
    enriched = pages_svc.get_page(page.id)
    assert enriched.inline_mentions == []


def test_inline_mentions_special_chars(pages_svc, repo):
    """Titles with hyphens and other chars that break FTS must still resolve."""
    target = pages_svc.create_page("Note-Taking Notes", content="About note-taking.")
    referrer = pages_svc.create_page(
        "Overview",
        content="See [[Note-Taking Notes]] for methodology.",
    )
    enriched = pages_svc.get_page(referrer.id)
    assert len(enriched.inline_mentions) == 1
    assert enriched.inline_mentions[0]["id"] == target.id


def test_ddd_compliance_models_no_io():
    """models/ must not import from sqlite3, json, pathlib, or locram.*"""
    import locram.models.page as page_mod
    import locram.models.enums as enum_mod
    import locram.models.link as link_mod

    for mod in (page_mod, enum_mod, link_mod):
        src = open(mod.__file__).read()
        assert "import sqlite3" not in src
        assert "import json" not in src
        assert "from locram" not in src


def test_ddd_services_no_concrete_adapters():
    """services/ must not import concrete adapter classes."""
    import locram.services.page_service as ps
    import locram.services.link_service as ls
    import locram.services.search_service as ss
    import locram.services.graph_service as gs

    for mod in (ps, ls, ss, gs):
        src = open(mod.__file__).read()
        assert "SqlitePageRepository" not in src
        assert "ObsidianVaultStore" not in src
