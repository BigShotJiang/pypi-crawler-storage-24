"""SqlitePageRepository — CRUD, links, search, analytics."""

from locram.models import LinkType, PageType, PageStatus


def test_create_and_get(repo):
    from locram.models import Page
    page = Page(id="", title="Test Note", content="Some content")
    created = repo.create(page)
    assert created.id
    assert created.content_hash

    fetched = repo.get(created.id)
    assert fetched is not None
    assert fetched.title == "Test Note"
    assert fetched.type == PageType.FLEETING


def test_update(repo):
    from locram.models import Page
    page = repo.create(Page(id="", title="Original"))
    updated = repo.update(page.id, title="Updated", type="permanent")
    assert updated.title == "Updated"
    assert updated.type == PageType.PERMANENT


def test_soft_delete(repo):
    from locram.models import Page
    page = repo.create(Page(id="", title="Deletable"))
    ok = repo.delete(page.id)
    assert ok
    fetched = repo.get(page.id)
    assert fetched.status == PageStatus.TO_DELETE


def test_hard_delete(repo):
    from locram.models import Page
    page = repo.create(Page(id="", title="Gone"))
    repo.delete(page.id, hard=True)
    assert repo.get(page.id) is None


def test_list_pages_filter(repo):
    from locram.models import Page
    repo.create(Page(id="", title="A", type=PageType.PERMANENT))
    repo.create(Page(id="", title="B", type=PageType.FLEETING))
    results = repo.list_pages(type="permanent")
    assert all(r["type"] == "permanent" for r in results)


def test_fts_search(repo):
    from locram.models import Page
    repo.create(Page(id="", title="Quantum Computing", content="superposition qubits"))
    repo.create(Page(id="", title="Machine Learning", content="neural networks backprop"))
    results = repo.search_fts("quantum")
    assert any("Quantum" in r["title"] for r in results)


def test_create_link_and_get(repo):
    from locram.models import Page
    a = repo.create(Page(id="", title="A"))
    b = repo.create(Page(id="", title="B"))
    repo.create_link(a.id, b.id, LinkType.EXTENDS)
    links = repo.get_links(a.id)
    assert any(lnk.link_type == LinkType.EXTENDS for lnk in links)


def test_delete_link_specific(repo):
    from locram.models import Page
    a = repo.create(Page(id="", title="A"))
    b = repo.create(Page(id="", title="B"))
    repo.create_link(a.id, b.id, LinkType.RELATED)
    repo.delete_link(a.id, b.id, LinkType.RELATED)
    assert repo.get_links(a.id) == []


def test_delete_link_all(repo):
    from locram.models import Page
    a = repo.create(Page(id="", title="A"))
    b = repo.create(Page(id="", title="B"))
    repo.create_link(a.id, b.id, LinkType.RELATED)
    repo.create_link(a.id, b.id, LinkType.EXTENDS)
    repo.delete_link(a.id, b.id, None)
    assert repo.get_links(a.id) == []


def test_find_orphaned(repo):
    from locram.models import Page
    orphan = repo.create(Page(id="", title="Lonely"))
    linked = repo.create(Page(id="", title="Connected"))
    other = repo.create(Page(id="", title="Other"))
    repo.create_link(linked.id, other.id, LinkType.RELATED)
    orphans = repo.find_orphaned()
    ids = [o["id"] for o in orphans]
    assert orphan.id in ids
    assert linked.id not in ids


def test_find_central(repo):
    from locram.models import Page
    hub = repo.create(Page(id="", title="Hub"))
    for i in range(3):
        spoke = repo.create(Page(id="", title=f"Spoke{i}"))
        repo.create_link(hub.id, spoke.id, LinkType.RELATED)
    central = repo.find_central(limit=5)
    assert central[0]["id"] == hub.id
