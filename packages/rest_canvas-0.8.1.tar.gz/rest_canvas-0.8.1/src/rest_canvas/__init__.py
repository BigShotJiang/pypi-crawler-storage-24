"""
REST Canvas - REST API Decorator Library

OpenAPI-driven decorator library for REST API endpoints in Django and Flask.
Provides automatic validation, response formatting, and framework-agnostic views
based on OpenAPI specifications.

Example usage - Flask:
    from flask import Flask
    from rest_canvas import RestCanvas, Request, PagePagination, Config, Sort, Filter

    app = Flask(__name__)

    # Optional: Configure REST Canvas
    config = Config(debug=True)

    api = RestCanvas('openapi.yaml', mount_point='/api/v1', config=config)

    @api.endpoint('GET /users', PagePagination, Fields, Sort, Filter)
    def list_users(request: Request[PagePagination]):
        # All features accessible via request object
        users = User.query.all()

        if request.filter:
            users = apply_filter(users, request.filter)
        if request.sort:
            users = apply_sort(users, request.sort)

        # Pagination automatically populated from query params
        users_page = users[request.pagination.offset:request.pagination.limit]
        request.pagination.total = len(users)

        return [serialize_user(u, request.fields) for u in users_page]

    # Register routes - adapter switches to FlaskAdapter
    api.register_flask_routes(app)

Example usage - Django:
    from rest_canvas import RestCanvas, Request, CursorPagination

    api = RestCanvas('openapi.yaml', mount_point='/api/v1')

    @api.endpoint('GET /users/{userId}')
    def get_user_by_id(request: Request, user_id: int):
        user = User.objects.get(id=user_id)
        return {"id": user.id, "name": user.name}

    # In urls.py
    urlpatterns = api.register_django_urls()
"""

# Configuration
from rest_canvas.core.config.config import Config
from rest_canvas.core.filter.filter_appliers import DjangoFilterApplier, SQLAlchemyFilterApplier

# Filter types
from rest_canvas.core.filter.filter_types import (
    FilterExpression,
    FilterExpressionConnectionOperator,
    FilterOperator,
)
from rest_canvas.core.log.log_processor import LogProcessor, LogToConsole

# Logging
from rest_canvas.core.log.logger import Logger
from rest_canvas.core.log.logger_config import LoggerConfig
from rest_canvas.core.log.logger_types import LogData, LogLevel

# Pagination classes
from rest_canvas.core.pagination.cursor import CursorPagination
from rest_canvas.core.pagination.page import PagePagination

# Request object
from rest_canvas.core.request.request import Request

# ORM appliers (optional utilities)
from rest_canvas.core.sort.sort_appliers import DjangoSortApplier, SQLAlchemySortApplier

# Sort types
from rest_canvas.core.sort.sort_types import SortDirection, SortField

# Exceptions
from rest_canvas.public.exceptions import (
    ConflictError,
    EndpointValidationError,
    ForbiddenError,
    InternalServerError,
    NotFoundError,
    RequestValidationError,
    ResponseValidationError,
    RestCanvasError,
    UnauthorizedError,
    ValidationError,
)

# Feature markers
from rest_canvas.public.features import DetailLevel, Filter, Sort

# Main RestCanvas class
from rest_canvas.public.rest_canvas import RestCanvas

# Testing utilities
from rest_canvas.testing.mocks import MockRequest

__all__ = [
    'Config',
    'ConflictError',
    'CursorPagination',
    'DetailLevel',
    'DjangoFilterApplier',
    'DjangoSortApplier',
    'EndpointValidationError',
    'Filter',
    'FilterExpression',
    'FilterExpressionConnectionOperator',
    'FilterOperator',
    'ForbiddenError',
    'InternalServerError',
    'LogData',
    'LogLevel',
    'LogProcessor',
    'LogToConsole',
    'Logger',
    'LoggerConfig',
    'MockRequest',
    'NotFoundError',
    'PagePagination',
    'Request',
    'RequestValidationError',
    'ResponseValidationError',
    'RestCanvas',
    'RestCanvasError',
    'SQLAlchemyFilterApplier',
    'SQLAlchemySortApplier',
    'Sort',
    'SortDirection',
    'SortField',
    'UnauthorizedError',
    'ValidationError',
]
