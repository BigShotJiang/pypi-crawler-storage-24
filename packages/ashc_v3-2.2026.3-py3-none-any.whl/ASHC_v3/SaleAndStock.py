import polars as pl
import ASHC_v3 as ashc
from ASHC_v3.DateFunctions import makeSaleSeasonIndex
from ASHC_v3.CommonFunction import fnCurrencyConverter, dictMerge, changeFWSeason

# Functions - cummelativeSale, prepareBudgetFiles, prepareKPIFiles, prepareSaleDF, prepareStockDF, removeWarehouseSale, removeWarehouseSaleFromCombined
def cummelativeSale(workingDF):
    '''
    This function is added to calculate overall sale for sellthru calculation, This is applicable for Okaidi, Jacadi, Parfois and Undiz
    I am selecting season sale from December of previous year to June for SS and from May to next year February for FW.
    '''
    sesSelectionDict = {}
    sesSelectDict = {}
    seasonDict_22E = makeSaleSeasonIndex('2021-12-01','2022-06-30','22E')
    seasonDict_22H = makeSaleSeasonIndex('2022-05-01','2023-02-28','22H')
    seasonDict_23E = makeSaleSeasonIndex('2022-12-01','2023-06-30','23E')
    seasonDict_23H = makeSaleSeasonIndex('2023-05-01','2024-02-28','23H')
    seasonDict_24E = makeSaleSeasonIndex('2023-12-01','2024-06-30','24E')
    seasonDict_24H = makeSaleSeasonIndex('2024-05-01','2025-02-28','24H')
    seasonDict_25E = makeSaleSeasonIndex('2024-12-01','2025-06-30','25E')
    seasonDict_25H = makeSaleSeasonIndex('2025-05-01','2026-02-28','25H')
    seasonDict_26E = makeSaleSeasonIndex('2025-12-01','2026-06-30','26E')
    seasonDict_26H = makeSaleSeasonIndex('2026-05-01','2027-02-28','26H')

    seaDict_22E = makeSaleSeasonIndex('2021-12-01','2022-06-30','2022-1')
    seaDict_22H = makeSaleSeasonIndex('2022-05-01','2023-02-28','2022-2')
    seaDict_23E = makeSaleSeasonIndex('2022-12-01','2023-06-30','2023-1')
    seaDict_23H = makeSaleSeasonIndex('2023-05-01','2024-02-28','2023-2')
    seaDict_24E = makeSaleSeasonIndex('2023-12-01','2024-06-30','2024-1')
    seaDict_24H = makeSaleSeasonIndex('2024-05-01','2025-02-28','2024-2')
    seaDict_25E = makeSaleSeasonIndex('2024-12-01','2025-06-30','2025-1')
    seaDict_25H = makeSaleSeasonIndex('2025-05-01','2026-02-28','2025-2')
    seaDict_26E = makeSaleSeasonIndex('2025-12-01','2026-06-30','2026-1')
    seaDict_26H = makeSaleSeasonIndex('2026-05-01','2027-02-28','2026-2')

    sesSelectionDict = dictMerge(sesSelectionDict, seasonDict_22E)
    sesSelectionDict = dictMerge(sesSelectionDict, seasonDict_22H)
    sesSelectionDict = dictMerge(sesSelectionDict, seasonDict_23E)
    sesSelectionDict = dictMerge(sesSelectionDict, seasonDict_23H)
    sesSelectionDict = dictMerge(sesSelectionDict, seasonDict_24E)
    sesSelectionDict = dictMerge(sesSelectionDict, seasonDict_24H)
    sesSelectionDict = dictMerge(sesSelectionDict, seasonDict_25E)
    sesSelectionDict = dictMerge(sesSelectionDict, seasonDict_25H)
    sesSelectionDict = dictMerge(sesSelectionDict, seasonDict_26E)
    sesSelectionDict = dictMerge(sesSelectionDict, seasonDict_26H)
    sesSelectDict = dictMerge(sesSelectDict, seaDict_22E)
    sesSelectDict = dictMerge(sesSelectDict, seaDict_22H)
    sesSelectDict = dictMerge(sesSelectDict, seaDict_23E)
    sesSelectDict = dictMerge(sesSelectDict, seaDict_23H)
    sesSelectDict = dictMerge(sesSelectDict, seaDict_24E)
    sesSelectDict = dictMerge(sesSelectDict, seaDict_24H)
    sesSelectDict = dictMerge(sesSelectDict, seaDict_25E)
    sesSelectDict = dictMerge(sesSelectDict, seaDict_25H)
    sesSelectDict = dictMerge(sesSelectDict, seaDict_26E)
    sesSelectDict = dictMerge(sesSelectDict, seaDict_26H)
    sesSelectionDict = dictMerge(sesSelectionDict, sesSelectDict)
    ses_22E = ["23E","23H","24E","24H","25E","25H","26E","26H","27E","27H","28E","28H","2023-1","2023-2","2024-1","2024-2","2025-1","2025-2","2026-1","2026-2","2027-1","2027-2"]
    ses_22H = ["23H","24E","24H","25E","25H","26E","26H","27E","27H","28E","28H","2023-2","2024-1","2024-2","2025-1","2025-2","2026-1","2026-2","2027-1","2027-2"]
    ses_23E = ["24E","24H","25E","25H","26E","26H","27E","27H","28E","28H","2024-1","2024-2","2025-1","2025-2","2026-1","2026-2","2027-1","2027-2"]
    ses_23H = ["24H","25E","25H","26E","26H","27E","27H","28E","28H","2024-2","2025-1","2025-2","2026-1","2026-2","2027-1","2027-2","2028-1","2028-2"]
    ses_24E = ["25E","25H","26E","26H","27E","27H","28E","28H","2025-1","2025-2","2026-1","2026-2","2027-1","2027-2","2028-1","2028-2"]
    ses_24H = ["25H","26E","26H","27E","27H","28E","28H","2025-2","2026-1","2026-2","2027-1","2027-2","2028-1","2028-2"]
    ses_25E = ["26E","26H","27E","27H","28E","28H","2026-1","2026-2","2027-1","2027-2","2028-1","2028-2"]
    ses_25H = ["26H","27E","27H","28E","28H","2026-2","2027-1","2027-2","2028-1","2028-2"]
    ses_26E = ["27E","27H","28E","28H","2027-1","2027-2","2028-1","2028-2"]
    ses_26H = ["27H","28E","28H","2027-2","2028-1","2028-2"]
    ses_27E = ["28E","28H","2028-1","2028-2"]
    ses_27H = ["28H","2028-1","2028-2"]

    workingDF = workingDF.with_columns(pl.col("Posting Date").replace(sesSelectionDict, return_dtype=pl.String, default=None).alias('Tmp_Season01'))
    workingDF = workingDF.with_columns(pl.col("Season Code").alias('Tmp_Season02'),)

    workingDF = workingDF.with_columns(pl.when((workingDF['Season Code'].is_in(ses_22E)) & (workingDF['Tmp_Season01'] == "22E")).then(pl.lit("22E")).alias('Tmp_Season02'),)
    workingDF = workingDF.with_columns(pl.when((workingDF['Season Code'].is_in(ses_22H)) & (workingDF['Tmp_Season01'] == "22H")).then(pl.lit("22H")).alias('Tmp_Season02'),)
    workingDF = workingDF.with_columns(pl.when((workingDF['Season Code'].is_in(ses_23E)) & (workingDF['Tmp_Season01'] == "23E")).then(pl.lit("23E")).alias('Tmp_Season02'),)
    workingDF = workingDF.with_columns(pl.when((workingDF['Season Code'].is_in(ses_23H)) & (workingDF['Tmp_Season01'] == "23H")).then(pl.lit("23H")).alias('Tmp_Season02'),)
    workingDF = workingDF.with_columns(pl.when((workingDF['Season Code'].is_in(ses_24E)) & (workingDF['Tmp_Season01'] == "24E")).then(pl.lit("24E")).alias('Tmp_Season02'),)
    workingDF = workingDF.with_columns(pl.when((workingDF['Season Code'].is_in(ses_24H)) & (workingDF['Tmp_Season01'] == "24H")).then(pl.lit("24H")).alias('Tmp_Season02'),)
    workingDF = workingDF.with_columns(pl.when((workingDF['Season Code'].is_in(ses_25E)) & (workingDF['Tmp_Season01'] == "25E")).then(pl.lit("25E")).alias('Tmp_Season02'),)
    workingDF = workingDF.with_columns(pl.when((workingDF['Season Code'].is_in(ses_25H)) & (workingDF['Tmp_Season01'] == "25H")).then(pl.lit("25H")).alias('Tmp_Season02'),)
    workingDF = workingDF.with_columns(pl.when((workingDF['Season Code'].is_in(ses_26E)) & (workingDF['Tmp_Season01'] == "26E")).then(pl.lit("26E")).alias('Tmp_Season02'),)
    workingDF = workingDF.with_columns(pl.when((workingDF['Season Code'].is_in(ses_26H)) & (workingDF['Tmp_Season01'] == "26H")).then(pl.lit("26H")).alias('Tmp_Season02'),)
    workingDF = workingDF.with_columns(pl.when((workingDF['Season Code'].is_in(ses_27E)) & (workingDF['Tmp_Season01'] == "27E")).then(pl.lit("27E")).alias('Tmp_Season02'),)
    workingDF = workingDF.with_columns(pl.when((workingDF['Season Code'].is_in(ses_27H)) & (workingDF['Tmp_Season01'] == "27H")).then(pl.lit("27H")).alias('Tmp_Season02'),)

    workingDF = workingDF.with_columns(pl.when((workingDF['Season Code'].is_in(ses_23E)) & (workingDF['Tmp_Season01'] == "2023-1")).then(pl.lit("2023-1")).alias('Tmp_Season02'),)
    workingDF = workingDF.with_columns(pl.when((workingDF['Season Code'].is_in(ses_23H)) & (workingDF['Tmp_Season01'] == "2023-2")).then(pl.lit("2023-2")).alias('Tmp_Season02'),)
    workingDF = workingDF.with_columns(pl.when((workingDF['Season Code'].is_in(ses_24E)) & (workingDF['Tmp_Season01'] == "2024-1")).then(pl.lit("2024-1")).alias('Tmp_Season02'),)
    workingDF = workingDF.with_columns(pl.when((workingDF['Season Code'].is_in(ses_24H)) & (workingDF['Tmp_Season01'] == "2024-2")).then(pl.lit("2024-2")).alias('Tmp_Season02'),)
    workingDF = workingDF.with_columns(pl.when((workingDF['Season Code'].is_in(ses_25E)) & (workingDF['Tmp_Season01'] == "2025-1")).then(pl.lit("2025-1")).alias('Tmp_Season02'),)
    workingDF = workingDF.with_columns(pl.when((workingDF['Season Code'].is_in(ses_25H)) & (workingDF['Tmp_Season01'] == "2025-2")).then(pl.lit("2025-2")).alias('Tmp_Season02'),)
    workingDF = workingDF.with_columns(pl.when((workingDF['Season Code'].is_in(ses_26E)) & (workingDF['Tmp_Season01'] == "2026-1")).then(pl.lit("2026-1")).alias('Tmp_Season02'),)
    workingDF = workingDF.with_columns(pl.when((workingDF['Season Code'].is_in(ses_26H)) & (workingDF['Tmp_Season01'] == "2026-2")).then(pl.lit("2026-2")).alias('Tmp_Season02'),)
    workingDF = workingDF.with_columns(pl.when((workingDF['Season Code'].is_in(ses_27E)) & (workingDF['Tmp_Season01'] == "2027-1")).then(pl.lit("2027-1")).alias('Tmp_Season02'),)
    workingDF = workingDF.with_columns(pl.when((workingDF['Season Code'].is_in(ses_27H)) & (workingDF['Tmp_Season01'] == "2027-2")).then(pl.lit("2027-2")).alias('Tmp_Season02'),)

    pIndex = ["Country","City","Location Code","StoreName","ShortName","Location Type","Year","Month","MerchWeek","Brand Code","Season Code","Tmp_Season02","Style Code","Colour Code","Division","Product Group","Item Category","Item Class","Item Sub Class","Sub Class","Theme"]
    pVal = ["SaleQty","Total Sale Cost(AED)","Total Sale Retail(AED)","Total Sale Org. Retail(AED)"]
    workingDF01 = workingDF.group_by(pIndex).agg(pl.sum(pVal),)
    workingDF01 = workingDF01.fill_null(0)
    workingDF01 = workingDF01.fill_nan(0)
    workingDF01JC = workingDF01.filter(pl.col('Brand Code') == 'JC')
    workingDF01OK = workingDF01.filter(pl.col('Brand Code') == 'OK')
    workingDF01OT = workingDF01.filter(pl.col('Brand Code').is_in(['PA','UZ','VI','YR','LS']))
    workingDF01OK = workingDF01OK.drop(['Season Code'])
    workingDF01OK = workingDF01OK.rename({"Tmp_Season02":"Season Code","SaleQty":"ST_Qty","Total Sale Cost(AED)":"ST_Cost(AED)","Total Sale Retail(AED)":"ST_Retail(AED)","Total Sale Org. Retail(AED)":"Org.Retail(AED)"})
    workingDF01OK = workingDF01OK.with_columns(pl.col("Season Code").map_elements(changeFWSeason, return_dtype=pl.String).alias('Season Code'),)
    workingDF01OK = workingDF01OK.with_columns(pl.col("Division").map_elements(lambda x: x if ((x == "Okaidi") or (x == "Obaibi")) else "Okaidi", return_dtype=pl.String).alias('Division'),)
    workingDF01OK = workingDF01OK.with_columns(pl.col("Product Group").cast(pl.String).str.strip_chars().alias('Product Group'),)
    workingDF01OK = workingDF01OK.with_columns(pl.col("Product Group").map_elements(lambda x: x if ((x == "Fille") or (x == "Garcon")  or (x == "Mixte")) else "Garcon", return_dtype=pl.String).alias('Product Group'),)
    workingDF01OK = workingDF01OK.with_columns(pl.col("Item Category").map_elements(lambda x: "Clothing" if str(x)=="0" else x, return_dtype=pl.String).alias('Item Category'),)
    workingDF01JC = workingDF01JC.drop(['Season Code'])
    workingDF01JC = workingDF01JC.rename({"Tmp_Season02":"Season Code","SaleQty":"ST_Qty","Total Sale Cost(AED)":"ST_Cost(AED)","Total Sale Retail(AED)":"ST_Retail(AED)","Total Sale Org. Retail(AED)":"Org.Retail(AED)"})
    workingDF01JC = workingDF01JC.with_columns(pl.col("Season Code").map_elements(changeFWSeason, return_dtype=pl.String).alias('Season Code'),)
    workingDF01OT = workingDF01OT.drop(['Season Code'])
    workingDF01OT = workingDF01OT.rename({"Tmp_Season02":"Season Code","SaleQty":"ST_Qty","Total Sale Cost(AED)":"ST_Cost(AED)","Total Sale Retail(AED)":"ST_Retail(AED)","Total Sale Org. Retail(AED)":"Org.Retail(AED)"})
    workingDF01OT = workingDF01OT.with_columns(pl.col("Season Code").map_elements(changeFWSeason, return_dtype=pl.String).alias('Season Code'),)
    df_STPivt01 = pl.concat([workingDF01OK,workingDF01JC,workingDF01OT], how="diagonal")
    df_STPivt01 = df_STPivt01.fill_null(0)
    df_STPivt01 = df_STPivt01.fill_nan(0)
    df_STPivt01 = df_STPivt01.with_columns(pl.lit("TY26").alias('Comp'),)
    df_STPivt01 = df_STPivt01.with_columns(pl.lit("2026").alias('Year'),)
    df_STPivt01 = df_STPivt01.with_columns(pl.lit("All").alias('Quarter'),)
    df_STPivt01 = df_STPivt01.with_columns(pl.lit("All").alias('Month'),)
    df_STPivt01 = df_STPivt01.with_columns(pl.lit("All").alias('MerchWeek'),)
    df_STPivt01 = df_STPivt01.with_columns(pl.lit("All").alias('Season Code'),)
    df_STPivt01 = df_STPivt01.with_columns(pl.when(pl.col('Season Code').is_in(ashc.selectSeason)).then(df_STPivt01['Season Code']).otherwise(pl.lit("OSM")).alias('Season_Group'))
    df_STPivt01 = df_STPivt01.with_columns(pl.col("Season_Group").map_elements(changeFWSeason, return_dtype=pl.String).alias('Season_Group'),)
    df_STPivt01 = df_STPivt01.with_columns(pl.lit("1900-01-01T00:00:00.000000",dtype=pl.Datetime).alias('Posting Date'),)
    df_STPivt01 = df_STPivt01.with_columns(pl.lit("999999999999").alias('Item No_'),)
    df_STPivt01 = df_STPivt01.with_columns(pl.lit("NA").alias('Size'),)
    df_STPivt01 = df_STPivt01.with_columns(pl.lit("All").alias('LFL Status'),)
    df_STPivt01 = df_STPivt01.with_columns(pl.lit("All").alias('Remarks'),)
    df_STPivt01 = df_STPivt01.with_columns(pl.lit("All").alias('Disc_Status'),)
    df_STPivt01 = df_STPivt01.with_columns(pl.lit("All").alias('OfferDetail'),)
    df_STPivt01 = df_STPivt01.with_columns(pl.lit("1900-01-01T00:00:00.000000",dtype=pl.Datetime).alias('First Purchase Date'),)
    df_STPivt01 = df_STPivt01.with_columns(pl.lit("1900-01-01T00:00:00.000000",dtype=pl.Datetime).alias('Last Receive Date'),)
    df_STPivt01 = df_STPivt01.with_columns(pl.lit(0.0, dtype=pl.Float32).alias('StoreSize'),)
    df_STPivt01 = df_STPivt01.with_columns(pl.lit(0).alias('Age(Days)'),)
    df_STPivt01 = df_STPivt01.with_columns(pl.lit("All").alias('Age_Group'),)
    df_STPivt01 = df_STPivt01.with_columns(pl.lit("All").alias('YTD'),)
    df_STPivt01 = df_STPivt01.with_columns(pl.lit("All").alias('WTD'),)
    df_STPivt01 = df_STPivt01.with_columns(pl.lit(0.0, dtype=pl.Float32).alias('Unit_Cost'),)
    df_STPivt01 = df_STPivt01.with_columns(pl.lit(0.0, dtype=pl.Float32).alias('Unit_Price'),)
    df_STPivt01 = df_STPivt01.with_columns(pl.lit(0.0, dtype=pl.Float32).alias('Current_Price'),)
    return df_STPivt01

def prepareBudgetFiles(yearDateDict):
    '''
    This function creates Budget DF, to use it, first you have to create a date range dict
        date_index = makeDateIndex("2026-12-01","2027-01-31")
        budgetDF = prepareBudgetFiles(date_index)
    '''
    pIdx = ["Country","City","Location Code","StoreName","ShortName","Location Type","LFL Status","Comp","Year","Quarter","Month","MerchWeek","Posting Date","Brand Code",'Season Code','Remarks','Disc_Status']
    df_bud01 = pl.scan_csv(ashc.budFile, schema_overrides=ashc.dataTypeForAll, infer_schema_length=10000,).fill_null(0).collect()
    df_bud01.fill_nan(0)
    delLoc = ["A01JC00","A01OK00","A02OK00","A03OK00","A04OK00","A05JC00","A05OK00","A06OK00","A01UZ00","A01VI00","A02VI00","A03UZ00","A03VI00","A05VI00","A06VI00"]
    df_bud01 = df_bud01.filter(~pl.col('Profit Centre Code').is_in(delLoc))
    df_bud01 = df_bud01.with_columns(pl.col('Profit Centre Name').str.strip_chars().str.replace('Okaidi Obaibi Avenue (OLD)','Okaidi Obaibi Avenue Mall'))
    df_bud01 = df_bud01.with_columns(pl.col('Profit Centre Name').str.strip_chars().str.replace('Okaidi Obaibi Dubai Fest City - OLD','Okaidi Obaibi Dubai Festival City'))
    df_bud01 = df_bud01.with_columns(pl.col('Profit Centre Name').str.strip_chars().str.replace('Vincci Yas Mall Old','Vincci Yas Mall'))
    df_bud01 = df_bud01.with_columns(pl.col('Profit Centre Name').str.strip_chars().str.replace('Jacadi Palm Jumeirah Mall','Jacadi Nakheel Mall'))
    df_bud01 = df_bud01.rename({'Target Amout':'Target Amount','Target Amout LCY':'Target Amount LCY'})
    df_bud01 = df_bud01[['Type','Brand Code','Country Region Code','Date','Store Size Square Meters','Profit Centre Name','Short Name','Target Amount','Target Amount LCY']]
    df_bud01 = df_bud01.with_columns(pl.col('Date').str.to_datetime(format='%d/%m/%Y').alias('Posting Date'))
    df_bud = df_bud01.with_columns(pl.col("Posting Date").replace_strict(yearDateDict, default=None).alias('Copy_Date'))
    df_bud = df_bud.filter(pl.col('Copy_Date') == 1)
    df_bud = df_bud.filter(pl.col('Type') == "TARGETS")
    df_bud = df_bud.filter(pl.col('Brand Code') != 'DE')
    df_bud = df_bud.with_columns(pl.col('Target Amount').str.strip_chars().str.replace('"',''))
    df_bud = df_bud.with_columns(pl.col('Target Amount').str.strip_chars().str.replace(',','').cast(pl.Float32))
    df_bud = df_bud.filter(pl.col('Target Amount') != 0.0)
    df_bud = df_bud.with_columns(pl.col("Profit Centre Name").replace(ashc.LocCode, return_dtype=pl.String, default=None).alias('Location Code'))
    df_bud = df_bud.with_columns(pl.col("Posting Date").replace_strict(ashc.Week_, return_dtype=pl.String, default=None).alias('MerchWeek'))
    df_bud = df_bud.with_columns(pl.col("Posting Date").replace_strict(ashc.Year_, return_dtype=pl.String, default=None).alias('Year'))
    df_bud = df_bud.with_columns(pl.col("Posting Date").replace_strict(ashc.Month_, return_dtype=pl.String, default=None).alias('Month'))
    df_bud = df_bud.with_columns(pl.col("Posting Date").replace_strict(ashc.Qtr_, return_dtype=pl.String, default=None).alias('Quarter'))
    df_bud = df_bud.with_columns(pl.col("Posting Date").replace_strict(ashc.Lyty_, return_dtype=pl.String, default=None).alias('Comp'))
    df_bud = df_bud.with_columns(pl.col("Location Code").replace_strict(ashc.ShortStoreName, return_dtype=pl.String, default=None).alias('ShortName'))
    df_bud = df_bud.with_columns(pl.col("Location Code").replace_strict(ashc.LocationType, return_dtype=pl.String, default=None).alias('Location Type'))
    df_bud = df_bud.with_columns(pl.col("Location Code").replace_strict(ashc.City, return_dtype=pl.String, default=None).alias('City'))
    df_bud = df_bud.with_columns(pl.col("Location Code").replace_strict(ashc.Country, return_dtype=pl.String, default=None).alias('Country'))
    df_bud = df_bud.with_columns(pl.col("Location Code").replace_strict(ashc.StoreName, return_dtype=pl.String, default=None).alias('StoreName'))
    df_bud = df_bud.with_columns(pl.col("Brand Code").replace_strict(ashc.fcSaleSeason, return_dtype=pl.String, default=None).alias('Sale_Season'))
    df_bud = df_bud.with_columns((pl.col("Location Code") + pl.col("MerchWeek")).alias('Combox'),)
    df_bud = df_bud.with_columns(pl.col("Combox").replace_strict(ashc.Lfl, return_dtype=pl.String, default=None).alias('LFL Status'))
    df_bud = df_bud.with_columns(pl.lit("All").alias('Season Code'),)
    df_bud = df_bud.with_columns(pl.lit("All").alias('Remarks'),)
    df_bud = df_bud.with_columns(pl.lit("All").alias('Disc_Status'),)
    df_ALLBUD = df_bud.group_by(pIdx).agg(pl.sum('Target Amount'),)
    df_ALLBUD = df_ALLBUD.fill_null(0)
    df_ALLBUD = df_ALLBUD.fill_nan(0)
    df_ALLBUD = df_ALLBUD.with_columns(pl.lit("111").alias('Style Code'),)
    df_ALLBUD = df_ALLBUD.with_columns(pl.lit("111").alias('Colour Code'),)
    df_ALLBUD = df_ALLBUD.with_columns(pl.lit("All").alias('Sale_Period'),)
    df_ALLBUD = df_ALLBUD.with_columns(pl.lit("All").alias('Season_Group'),)
    df_ALLBUD = df_ALLBUD.with_columns(pl.lit("All").alias('Division'),)
    df_ALLBUD = df_ALLBUD.with_columns(pl.lit("All").alias('Product Group'),)
    df_ALLBUD = df_ALLBUD.with_columns(pl.lit("All").alias('Item Category'),)
    df_ALLBUD = df_ALLBUD.with_columns(pl.lit("All").alias('Item Class'),)
    df_ALLBUD = df_ALLBUD.with_columns(pl.lit("All").alias('Item Sub Class'),)
    df_ALLBUD = df_ALLBUD.with_columns(pl.lit("All").alias('Sub Class'),)
    df_ALLBUD = df_ALLBUD.with_columns(pl.lit("All").alias('Theme'),)
    df_ALLBUD = df_ALLBUD.with_columns(pl.lit("All").alias('OfferDetail'),)
    df_ALLBUD = df_ALLBUD.with_columns(pl.lit("1900-01-01T00:00:00.000000",dtype=pl.Datetime).alias('First Purchase Date'),)
    df_ALLBUD = df_ALLBUD.with_columns(pl.lit("1900-01-01T00:00:00.000000",dtype=pl.Datetime).alias('Last Receive Date'),)
    df_ALLBUD = df_ALLBUD.with_columns(pl.lit(0.0, dtype=pl.Float32).alias('StoreSize'),)
    df_ALLBUD = df_ALLBUD.with_columns(pl.lit(0).alias('Age(Days)'),)
    df_ALLBUD = df_ALLBUD.with_columns(pl.lit("All").alias('Age_Group'),)
    df_ALLBUD = df_ALLBUD.with_columns(pl.lit("All").alias('YTD'),)
    df_ALLBUD = df_ALLBUD.with_columns(pl.lit("All").alias('WTD'),)
    df_ALLBUD = df_ALLBUD.with_columns(pl.lit(0.0, dtype=pl.Float32).alias('Unit_Cost'),)
    df_ALLBUD = df_ALLBUD.with_columns(pl.lit(0.0, dtype=pl.Float32).alias('Unit_Price'),)
    df_ALLBUD = df_ALLBUD.with_columns(pl.lit(0.0, dtype=pl.Float32).alias('Current_Price'),)
    return df_ALLBUD

def prepareKPIFiles(yearDateDict):
    '''
    This function creates KPI DF, to use it, first you have to create a date range dict
        date_index = makeDateIndex("2026-12-01","2027-01-31")
        kpiDF = prepareKPIFiles(date_index)
    '''
    pIdx = ["Country","City","Location Code","StoreName","ShortName","Location Type","LFL Status","Comp","Year","Quarter","Month","MerchWeek","Posting Date","Brand Code"]
    df_kpi01 = pl.scan_csv(ashc.kpiFile, infer_schema_length=0,).fill_null(0).collect()
    df_kpi01.fill_nan(0)
    df_kpi01 = df_kpi01.with_columns(pl.col("Location Name").replace_strict(ashc.LocCode, return_dtype=pl.String, default=None).alias('Location Code'))
    df_kpi01 = df_kpi01.with_columns(pl.col('Date').str.to_datetime(format='%d/%m/%Y').alias('Posting Date'))
    df_kpi = df_kpi01.with_columns(pl.col("Posting Date").replace_strict(yearDateDict, default=None).alias('Copy_Date'))
    df_kpi = df_kpi.filter(pl.col('Copy_Date') == 1)
    df_kpi = df_kpi.with_columns(pl.col('Visitors').str.strip_chars().str.replace('"',''))
    df_kpi = df_kpi.with_columns(pl.col('Visitors').str.strip_chars().str.replace(',','').cast(pl.Int64))
    df_kpi = df_kpi.with_columns(pl.col('Buyers').str.strip_chars().str.replace('"',''))
    df_kpi = df_kpi.with_columns(pl.col('Buyers').str.strip_chars().str.replace(',','').cast(pl.Int32))
    df_kpi = df_kpi.with_columns(pl.col("Posting Date").replace_strict(ashc.Week_, return_dtype=pl.String, default=None).alias('MerchWeek'))
    df_kpi = df_kpi.with_columns(pl.col("Posting Date").replace_strict(ashc.Year_, return_dtype=pl.String, default=None).alias('Year'))
    df_kpi = df_kpi.with_columns(pl.col("Posting Date").replace_strict(ashc.Month_, return_dtype=pl.String, default=None).alias('Month'))
    df_kpi = df_kpi.with_columns(pl.col("Posting Date").replace_strict(ashc.Qtr_, return_dtype=pl.String, default=None).alias('Quarter'))
    df_kpi = df_kpi.with_columns(pl.col("Posting Date").replace_strict(ashc.Lyty_, return_dtype=pl.String, default=None).alias('Comp'))
    df_kpi = df_kpi.with_columns(pl.col("Location Code").replace_strict(ashc.ShortStoreName, return_dtype=pl.String, default=None).alias('ShortName'))
    df_kpi = df_kpi.with_columns(pl.col("Location Code").replace_strict(ashc.LocationType, return_dtype=pl.String, default=None).alias('Location Type'))
    df_kpi = df_kpi.with_columns(pl.col("Location Code").replace_strict(ashc.City, return_dtype=pl.String, default=None).alias('City'))
    df_kpi = df_kpi.with_columns(pl.col("Location Code").replace_strict(ashc.Country, return_dtype=pl.String, default=None).alias('Country'))
    df_kpi = df_kpi.with_columns(pl.col("Location Code").replace_strict(ashc.BrandName, return_dtype=pl.String, default=None).alias('Brand Code'))
    df_kpi = df_kpi.with_columns(pl.col("Location Code").replace_strict(ashc.StoreName, return_dtype=pl.String, default=None).alias('StoreName'))
    df_kpi = df_kpi.with_columns(pl.col("Brand Code").replace_strict(ashc.fcSaleSeason, return_dtype=pl.String, default=None).alias('Sale_Season'))
    df_kpi = df_kpi.with_columns((pl.col("Location Code") + pl.col("MerchWeek")).alias('Combox'),)
    df_kpi = df_kpi.with_columns(pl.col("Combox").replace_strict(ashc.Lfl, return_dtype=pl.String, default=None).alias('LFL Status'))
    df_kpi = df_kpi.with_columns(pl.lit("NA").alias('Season Code'),)
    df_kpi = df_kpi.with_columns(pl.lit("NA").alias('Remarks'),)
    df_kpi = df_kpi.with_columns(pl.lit("NA").alias('Disc_Status'),)
    df_kpi = df_kpi.filter(pl.col('Country').is_in(['AE','BH','KWT','OM','QA']))
    df_kpi = df_kpi.filter(pl.col('Location Type') == 'Store')
    df_ALLKPI = df_kpi.group_by(pIdx).agg(pl.sum(['Visitors','Buyers']),)
    df_ALLKPI = df_ALLKPI.fill_null(0)
    df_ALLKPI = df_ALLKPI.fill_nan(0)
    df_ALLKPI = df_ALLKPI.with_columns(pl.lit("111").alias('Style Code'),)
    df_ALLKPI = df_ALLKPI.with_columns(pl.lit("111").alias('Colour Code'),)
    df_ALLKPI = df_ALLKPI.with_columns(pl.lit("All").alias('Season Code'),)
    df_ALLKPI = df_ALLKPI.with_columns(pl.lit("All").alias('Sale_Period'),)
    df_ALLKPI = df_ALLKPI.with_columns(pl.lit("All").alias('Season_Group'),)
    df_ALLKPI = df_ALLKPI.with_columns(pl.lit("All").alias('Division'),)
    df_ALLKPI = df_ALLKPI.with_columns(pl.lit("All").alias('Product Group'),)
    df_ALLKPI = df_ALLKPI.with_columns(pl.lit("All").alias('Item Category'),)
    df_ALLKPI = df_ALLKPI.with_columns(pl.lit("All").alias('Item Class'),)
    df_ALLKPI = df_ALLKPI.with_columns(pl.lit("All").alias('Item Sub Class'),)
    df_ALLKPI = df_ALLKPI.with_columns(pl.lit("All").alias('Sub Class'),)
    df_ALLKPI = df_ALLKPI.with_columns(pl.lit("All").alias('Theme'),)
    df_ALLKPI = df_ALLKPI.with_columns(pl.lit("All").alias('Remarks'),)
    df_ALLKPI = df_ALLKPI.with_columns(pl.lit("All").alias('Disc_Status'),)
    df_ALLKPI = df_ALLKPI.with_columns(pl.lit("All").alias('OfferDetail'),)
    df_ALLKPI = df_ALLKPI.with_columns(pl.lit("1900-01-01T00:00:00.000000",dtype=pl.Datetime).alias('First Purchase Date'),)
    df_ALLKPI = df_ALLKPI.with_columns(pl.lit("1900-01-01T00:00:00.000000",dtype=pl.Datetime).alias('Last Receive Date'),)
    df_ALLKPI = df_ALLKPI.with_columns(pl.lit(0.0, dtype=pl.Float32).alias('StoreSize'),)
    df_ALLKPI = df_ALLKPI.with_columns(pl.lit(0).alias('Age(Days)'),)
    df_ALLKPI = df_ALLKPI.with_columns(pl.lit("All").alias('Age_Group'),)
    df_ALLKPI = df_ALLKPI.with_columns(pl.lit("All").alias('YTD'),)
    df_ALLKPI = df_ALLKPI.with_columns(pl.lit("All").alias('WTD'),)
    df_ALLKPI = df_ALLKPI.with_columns(pl.lit(0.0, dtype=pl.Float32).alias('Unit_Cost'),)
    df_ALLKPI = df_ALLKPI.with_columns(pl.lit(0.0, dtype=pl.Float32).alias('Unit_Price'),)
    df_ALLKPI = df_ALLKPI.with_columns(pl.lit(0.0, dtype=pl.Float32).alias('Current_Price'),)
    return df_ALLKPI

def prepareSaleDF(df_Sale):
    """This function do some cleanup in sale data and add following additional data columns,
    ShortName, Location Type, LFL Status, ExchangeRate
    StoreSize, MerchWeek, Year, Month, Qtr, Comp, etc"""
    dummyBarcode = {'1122334455667':1,'1234500006789':1,'1111111103760':1,'7728772877287':1,'100000000001':1,'100000000002':1,'100000000003':1,'10001':1,'10002':1}
    df_Sale = df_Sale.with_columns(pl.col("Item No_").replace(dummyBarcode, return_dtype=pl.String, default=None).alias('DummyBarcode'))
    df_Sale = df_Sale.filter(pl.col('DummyBarcode').is_null())
    try:
        df_Sale = df_Sale.with_columns(pl.col('Posting Date').str.to_datetime())
    except:
        print(" ")

    df_Sale = df_Sale.with_columns(pl.col("Style Code").cast(pl.String).str.replace_all('.0','',literal=True).alias('Style Code'),)
    df_Sale = df_Sale.with_columns(pl.col("Colour Code").cast(pl.String).str.replace_all('.0','',literal=True).alias('Colour Code'),)
    df_Sale = df_Sale.with_columns(pl.col("Location Code").replace_strict(ashc.ShortStoreName, return_dtype=pl.String, default=None).alias('ShortName'))
    df_Sale = df_Sale.with_columns(pl.col("Location Code").replace_strict(ashc.LocationType, return_dtype=pl.String, default=None).alias('Location Type'))
    df_Sale = df_Sale.with_columns(pl.col("Location Code").replace_strict(ashc.Country, return_dtype=pl.String, default=None).alias('Country'))
    df_Sale = df_Sale.with_columns(pl.col("Location Code").replace_strict(ashc.Area, return_dtype=pl.Float32, default=None).alias('StoreSize'))
    df_Sale = df_Sale.with_columns(pl.col("Posting Date").replace_strict(ashc.Week_, return_dtype=pl.String, default=None).alias('MerchWeek'))
    df_Sale = df_Sale.with_columns(pl.col("Posting Date").replace_strict(ashc.Year_, return_dtype=pl.String, default=None).alias('Year'))
    df_Sale = df_Sale.with_columns(pl.col("Posting Date").replace_strict(ashc.Month_, return_dtype=pl.String, default=None).alias('Month'))
    df_Sale = df_Sale.with_columns(pl.col("Posting Date").replace_strict(ashc.Qtr_, return_dtype=pl.String, default=None).alias('Quarter'))
    df_Sale = df_Sale.with_columns(pl.col("Posting Date").replace_strict(ashc.Lyty_, return_dtype=pl.String, default=None).alias('Comp'))
    df_Sale = df_Sale.with_columns((pl.col("Location Code") + pl.col("MerchWeek")).alias('Combox'),)
    df_Sale = df_Sale.with_columns(pl.col("Combox").replace_strict(ashc.Lfl, return_dtype=pl.String, default=None).alias('LFL Status'))
    df_Sale = df_Sale.with_columns(pl.col("Country").map_elements(fnCurrencyConverter, return_dtype=pl.Float64).alias('ExchangeRate(AED)'),)
    df_Sale = df_Sale.with_columns((df_Sale['ExchangeRate(AED)'] * df_Sale['CostValue']).alias('Total Sale Cost(AED)'),)
    df_Sale = df_Sale.with_columns((df_Sale['ExchangeRate(AED)'] * df_Sale['SaleValue']).alias('Total Sale Retail(AED)'),)
    df_Sale = df_Sale.with_columns((df_Sale['ExchangeRate(AED)'] * df_Sale['Unit Price Including VAT']).alias('Unit Price Including VAT(AED)'),)
    df_Sale = df_Sale.with_columns((df_Sale['ExchangeRate(AED)'] * df_Sale['Unit Price Including VAT'] * df_Sale['SaleQty']).alias('Total Sale Org. Retail(AED)'),)
    df_Sale = df_Sale.with_columns((df_Sale['Total Sale Retail(AED)'] - df_Sale['Total Sale Cost(AED)']).alias('GrossMargin Value'),)
    df_Sale = df_Sale.with_columns((df_Sale['Total Sale Org. Retail(AED)'] - df_Sale['Total Sale Retail(AED)']).alias('Discount Value'),)
    df_Sale = df_Sale.with_columns((df_Sale['Discount Value'] / df_Sale['Total Sale Org. Retail(AED)']).alias('Discount Percent'),)
    df_Sale = df_Sale.with_columns(pl.when(df_Sale['Discount Percent'] > 0.10).then(pl.lit("Discounted")).otherwise(pl.lit("Non Discounted")).alias('Discount Status'),)
    df_Sale.fill_null(0)
    df_Sale.fill_nan(0)
    return df_Sale

def prepareStockDF(df_Stock):
    """This function do some cleanup in stock data and add following additional data columns,
    ShortName, Location Type, LFL Status, ExchangeRate
    StoreSize, MerchWeek, Year, Month, Qtr, Comp"""
    try:
        df_Stock = df_Stock.with_columns(pl.col('Posting Date').str.to_datetime())
    except:
        print(" ")

    df_Stock = df_Stock.with_columns(pl.col("Style Code").cast(pl.String).str.replace_all('.0','',literal=True).alias('Style Code'),)
    df_Stock = df_Stock.with_columns(pl.col("Colour Code").cast(pl.String).str.replace_all('.0','',literal=True).alias('Colour Code'),)
    df_Stock = df_Stock.with_columns(pl.lit("").alias('Combo'),)
    df_Stock = df_Stock.with_columns(pl.lit("1900-01-01T00:00:00.000000",dtype=pl.Datetime).alias('First Purchase Date'),)
    df_Stock = df_Stock.with_columns(pl.col("Location Code").replace_strict(ashc.ShortStoreName, return_dtype=pl.String, default=None).alias('ShortName'))
    df_Stock = df_Stock.with_columns(pl.col("Location Code").replace_strict(ashc.LocationType, return_dtype=pl.String, default=None).alias('Location Type'))
    df_Stock = df_Stock.with_columns(pl.col("Location Code").replace_strict(ashc.Country, return_dtype=pl.String, default=None).alias('Country'))
    df_Stock = df_Stock.with_columns(pl.col("Location Code").replace_strict(ashc.Area, return_dtype=pl.Float32, default=None).alias('StoreSize'))
    df_Stock = df_Stock.with_columns(pl.col("Posting Date").replace_strict(ashc.Week_, return_dtype=pl.String, default=None).alias('MerchWeek'))
    df_Stock = df_Stock.with_columns(pl.col("Posting Date").replace_strict(ashc.Year_, return_dtype=pl.String, default=None).alias('Year'))
    df_Stock = df_Stock.with_columns(pl.col("Posting Date").replace_strict(ashc.Month_, return_dtype=pl.String, default=None).alias('Month'))
    df_Stock = df_Stock.with_columns(pl.col("Posting Date").replace_strict(ashc.Qtr_, return_dtype=pl.String, default=None).alias('Quarter'))
    df_Stock = df_Stock.with_columns(pl.col("Posting Date").replace_strict(ashc.Lyty_, return_dtype=pl.String, default=None).alias('Comp'))
    df_Stock = df_Stock.with_columns((pl.col("Location Code") + pl.col("MerchWeek")).alias('Combox'),)
    df_Stock = df_Stock.with_columns(pl.col("Combox").replace_strict(ashc.Lfl, return_dtype=pl.String, default=None).alias('LFL Status'))
    df_Stock = df_Stock.with_columns(pl.col("Country").map_elements(fnCurrencyConverter, return_dtype=pl.Float64).alias('ExchangeRate(AED)'),)
    df_Stock = df_Stock.with_columns((df_Stock['ExchangeRate(AED)'] * df_Stock['Closing Stock'] * df_Stock['Unit Cost']).alias('Total Stock Cost(AED)'),)
    df_Stock = df_Stock.with_columns((df_Stock['ExchangeRate(AED)'] * df_Stock['Closing Stock'] * df_Stock['Unit Price']).alias('Total Stock Retail(AED)'),)
    return df_Stock

def removeWarehouseSale(saleDF):
    """Sets SaleQty, CostValue and SaleValue to zero in warehouse locations in any report data frame
    eg: retDF = removeWarehouseSale(saleDF)"""
    saleDF.fill_nan(0)
    saleDF = saleDF.with_columns(pl.when(pl.col('Location Code').is_in(ashc.delLocation)).then(pl.lit(0)).otherwise('SaleQty').alias('SaleQty'))
    saleDF = saleDF.with_columns(pl.when(pl.col('Location Code').is_in(ashc.delLocation)).then(pl.lit(0)).otherwise('CostValue').alias('CostValue'))
    saleDF = saleDF.with_columns(pl.when(pl.col('Location Code').is_in(ashc.delLocation)).then(pl.lit(0)).otherwise('SaleValue').alias('SaleValue'))
    return saleDF

def removeWarehouseSaleFromCombined(saleDF):
    """Sets SaleQty, CostValue and SaleValue to zero in Warehouse locations in combined report data frame
    eg: retDF = removeWarehouseSaleFromCombined(saleDF)"""
    saleDF.fill_nan(0)
    saleDF = saleDF.with_columns(pl.when(pl.col('Location Code').is_in(ashc.delLocation)).then(pl.lit(0)).otherwise('Cumm. SaleQty').alias('Cumm. SaleQty'))
    saleDF = saleDF.with_columns(pl.when(pl.col('Location Code').is_in(ashc.delLocation)).then(pl.lit(0)).otherwise('Cumm. CostValue').alias('Cumm. CostValue'))
    saleDF = saleDF.with_columns(pl.when(pl.col('Location Code').is_in(ashc.delLocation)).then(pl.lit(0)).otherwise('Cumm. SaleValue').alias('Cumm. SaleValue'))
    saleDF = saleDF.with_columns(pl.when(pl.col('Location Code').is_in(ashc.delLocation)).then(pl.lit(0)).otherwise('MTD SaleQty').alias('MTD SaleQty'))
    saleDF = saleDF.with_columns(pl.when(pl.col('Location Code').is_in(ashc.delLocation)).then(pl.lit(0)).otherwise('MTD CostValue').alias('MTD CostValue'))
    saleDF = saleDF.with_columns(pl.when(pl.col('Location Code').is_in(ashc.delLocation)).then(pl.lit(0)).otherwise('MTD SaleValue').alias('MTD SaleValue'))
    saleDF = saleDF.with_columns(pl.when(pl.col('Location Code').is_in(ashc.delLocation)).then(pl.lit(0)).otherwise('WTD SaleQty').alias('WTD SaleQty'))
    saleDF = saleDF.with_columns(pl.when(pl.col('Location Code').is_in(ashc.delLocation)).then(pl.lit(0)).otherwise('WTD CostValue').alias('WTD CostValue'))
    saleDF = saleDF.with_columns(pl.when(pl.col('Location Code').is_in(ashc.delLocation)).then(pl.lit(0)).otherwise('WTD SaleValue').alias('WTD SaleValue'))
    return saleDF
    