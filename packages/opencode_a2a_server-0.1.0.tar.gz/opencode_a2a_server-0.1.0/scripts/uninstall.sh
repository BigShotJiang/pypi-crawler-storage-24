#!/usr/bin/env bash
# Docs: scripts/uninstall_readme.md
# Preview-first uninstall for one deployed project instance.
set -euo pipefail

PROJECT_NAME=""
DATA_ROOT_INPUT=""
CONFIRM_INPUT=""

for arg in "$@"; do
  if [[ "$arg" == *=* ]]; then
    key="${arg%%=*}"
    value="${arg#*=}"
  else
    echo "Unknown argument format: $arg (expected key=value)" >&2
    exit 1
  fi

  case "${key,,}" in
    project|project_name)
      PROJECT_NAME="$value"
      ;;
    data_root)
      DATA_ROOT_INPUT="$value"
      ;;
    confirm)
      CONFIRM_INPUT="$value"
      ;;
    *)
      echo "Unknown argument: $arg" >&2
      exit 1
      ;;
  esac
done

if [[ -z "$PROJECT_NAME" ]]; then
  echo "Usage: $0 project=<name> [data_root=/data/opencode-a2a] [confirm=UNINSTALL]" >&2
  exit 1
fi

DATA_ROOT="${DATA_ROOT_INPUT:-${DATA_ROOT:-/data/opencode-a2a}}"

# Guardrails for path safety and account-name compatibility.
if [[ "$PROJECT_NAME" == "." || "$PROJECT_NAME" == ".." ]]; then
  echo "Invalid project name: ${PROJECT_NAME}" >&2
  exit 1
fi
if [[ "$PROJECT_NAME" == *"/"* ]]; then
  echo "Invalid project name (must be a single path component): ${PROJECT_NAME}" >&2
  exit 1
fi
if [[ "$PROJECT_NAME" =~ [[:space:]] ]]; then
  echo "Invalid project name (whitespace not allowed): ${PROJECT_NAME}" >&2
  exit 1
fi
if [[ "$DATA_ROOT" != /* || "$DATA_ROOT" == "/" ]]; then
  echo "Invalid DATA_ROOT (must be an absolute path, not /): ${DATA_ROOT}" >&2
  exit 1
fi
if [[ "$DATA_ROOT" =~ [[:space:]] ]]; then
  echo "Invalid DATA_ROOT (whitespace not allowed): ${DATA_ROOT}" >&2
  exit 1
fi

UNIT_OPENCODE="opencode@${PROJECT_NAME}.service"
UNIT_A2A="opencode-a2a-server@${PROJECT_NAME}.service"
OPENCODE_OVERRIDE_DIR="/etc/systemd/system/opencode@${PROJECT_NAME}.service.d"
A2A_OVERRIDE_DIR="/etc/systemd/system/opencode-a2a-server@${PROJECT_NAME}.service.d"

APPLY="false"
if [[ "$CONFIRM_INPUT" == "UNINSTALL" ]]; then
  APPLY="true"
fi

# Canonicalize paths and reject dot-segments in apply mode.
contains_dot_segment() {
  local p="$1"
  [[ "$p" =~ (^|/)\.\.(/|$) || "$p" =~ (^|/)\.(/|$) ]]
}

find_exe() {
  # Avoid caller PATH omissions such as /usr/sbin.
  local name="$1"
  local p=""
  p="$(command -v "$name" 2>/dev/null || true)"
  if [[ -n "$p" && -x "$p" ]]; then
    echo "$p"
    return 0
  fi
  for dir in /usr/sbin /sbin /usr/bin /bin /usr/local/sbin /usr/local/bin; do
    if [[ -x "${dir}/${name}" ]]; then
      echo "${dir}/${name}"
      return 0
    fi
  done
  return 1
}

print_missing_account_tool_hints() {
  # Args: user|group
  local kind="${1:-}"
  local os_id=""
  local os_like=""

  if [[ -r /etc/os-release ]]; then
    # shellcheck disable=SC1091
    . /etc/os-release
    os_id="${ID:-}"
    os_like="${ID_LIKE:-}"
  fi

  echo "Fallback hints:" >&2
  echo "  - PATH for non-root users may omit /usr/sbin and /sbin." >&2
  echo "    Try: export PATH=\"\$PATH:/usr/sbin:/sbin\" && command -v userdel groupdel" >&2

  if [[ "$kind" == "user" ]]; then
    echo "  - If user deletion tools are missing (userdel/deluser):" >&2
    if [[ "$os_id" == "debian" || "$os_id" == "ubuntu" || "$os_like" == *debian* ]]; then
      echo "    - Debian/Ubuntu: sudo apt-get update && sudo apt-get install -y passwd" >&2
    elif [[ "$os_id" == "rhel" || "$os_id" == "fedora" || "$os_like" == *rhel* || "$os_like" == *fedora* ]]; then
      echo "    - RHEL/Fedora: sudo dnf install -y shadow-utils  (or: sudo yum install -y shadow-utils)" >&2
    else
      echo "    - Install the package providing userdel/deluser (distro-specific)." >&2
    fi
    echo "  - Then delete manually: sudo userdel \"${PROJECT_NAME}\"" >&2
  elif [[ "$kind" == "group" ]]; then
    echo "  - If group deletion tools are missing (groupdel/delgroup):" >&2
    if [[ "$os_id" == "debian" || "$os_id" == "ubuntu" || "$os_like" == *debian* ]]; then
      echo "    - Debian/Ubuntu: sudo apt-get update && sudo apt-get install -y passwd" >&2
    elif [[ "$os_id" == "rhel" || "$os_id" == "fedora" || "$os_like" == *rhel* || "$os_like" == *fedora* ]]; then
      echo "    - RHEL/Fedora: sudo dnf install -y shadow-utils  (or: sudo yum install -y shadow-utils)" >&2
    else
      echo "    - Install the package providing groupdel/delgroup (distro-specific)." >&2
    fi
    echo "  - Then delete manually: sudo groupdel \"${PROJECT_NAME}\"" >&2
  fi
}

DATA_ROOT_RAW="$DATA_ROOT"
DATA_ROOT_EFFECTIVE="$DATA_ROOT"
PROJECT_DIR_EFFECTIVE=""

if [[ "$APPLY" == "true" ]]; then
  if contains_dot_segment "$DATA_ROOT_RAW"; then
    echo "Invalid DATA_ROOT for apply mode (contains '.' or '..' segments): ${DATA_ROOT_RAW}" >&2
    exit 1
  fi
fi

if command -v realpath >/dev/null 2>&1; then
  DATA_ROOT_EFFECTIVE="$(realpath -m -- "$DATA_ROOT_RAW")"
else
  if [[ "$APPLY" == "true" ]]; then
    echo "realpath not found; cannot safely apply uninstall. Install coreutils or provide realpath." >&2
    exit 1
  fi
fi

PROJECT_DIR_EFFECTIVE="${DATA_ROOT_EFFECTIVE}/${PROJECT_NAME}"
if command -v realpath >/dev/null 2>&1; then
  PROJECT_DIR_EFFECTIVE="$(realpath -m -- "$PROJECT_DIR_EFFECTIVE")"
fi

DATA_ROOT="$DATA_ROOT_EFFECTIVE"
PROJECT_DIR="$PROJECT_DIR_EFFECTIVE"

run() {
  echo "+ $*"
  if [[ "$APPLY" == "true" ]]; then
    "$@"
  fi
}

warn() {
  echo "WARN: $*" >&2
}

HAD_NONFATAL_FAILURE="false"
run_ignore() {
  echo "+ $*"
  if [[ "$APPLY" == "true" ]]; then
    if ! "$@"; then
      HAD_NONFATAL_FAILURE="true"
      warn "Command failed (ignored): $*"
    fi
  fi
}

run_reset_failed() {
  # Treat missing/not-loaded units as informational.
  echo "+ $*"
  if [[ "$APPLY" != "true" ]]; then
    return 0
  fi

  local out=""
  if out="$("$@" 2>&1)"; then
    if [[ -n "$out" ]]; then
      echo "$out"
    fi
    return 0
  fi

  local rc=$?
  if [[ -n "$out" ]]; then
    echo "$out" >&2
  fi

  if [[ "$out" == *"not loaded"* || "$out" == *"not found"* ]]; then
    echo "INFO: systemctl reset-failed skipped (unit not loaded/not found)." >&2
    return 0
  fi

  HAD_NONFATAL_FAILURE="true"
  warn "Command failed (ignored): $* (exit=$rc)"
  return 0
}

echo "Project: ${PROJECT_NAME}"
echo "DATA_ROOT: ${DATA_ROOT}"
echo "Project dir: ${PROJECT_DIR}"
echo "Note: systemd template units will NOT be removed."
echo "Mode: $([[ "$APPLY" == "true" ]] && echo apply || echo preview)"

# Enforce strict project-name constraints in apply mode.
if [[ "$APPLY" == "true" ]]; then
  if [[ ! "$PROJECT_NAME" =~ ^[a-z_][a-z0-9_-]{0,31}$ ]]; then
    echo "Invalid project name for apply mode (expected: ^[a-z_][a-z0-9_-]{0,31}$): ${PROJECT_NAME}" >&2
    exit 1
  fi
fi

# Apply mode requires sudo; avoid interactive hangs.
if [[ "$APPLY" == "true" ]]; then
  if ! command -v sudo >/dev/null 2>&1; then
    echo "sudo not found; cannot apply uninstall." >&2
    exit 1
  fi
  if [[ -t 0 ]]; then
    # Interactive terminal: refresh credentials.
    sudo -v
  else
    # Non-interactive: require passwordless sudo for this run.
    if ! sudo -n true 2>/dev/null; then
      echo "sudo requires a password or is not permitted (non-interactive). Refusing to apply." >&2
      echo "Run in an interactive shell, or configure NOPASSWD for required commands." >&2
      exit 1
    fi
  fi
fi

# Refuse unexpected target layout (defense in depth).
if [[ "$PROJECT_DIR" != "${DATA_ROOT}/"* ]]; then
  echo "Internal error: project dir is not under DATA_ROOT: ${PROJECT_DIR}" >&2
  exit 1
fi

# If the directory exists, require deploy markers.
if [[ "$APPLY" == "true" && -e "${PROJECT_DIR}" ]]; then
  if ! sudo test -f "${PROJECT_DIR}/config/a2a.env" && ! sudo test -f "${PROJECT_DIR}/config/opencode.env"; then
    echo "Refusing to delete ${PROJECT_DIR}: missing marker env files under config/." >&2
    echo "Expected one of:" >&2
    echo "  ${PROJECT_DIR}/config/a2a.env" >&2
    echo "  ${PROJECT_DIR}/config/opencode.env" >&2
    exit 1
  fi
fi

# Stop/disable instance units (idempotent).
if command -v systemctl >/dev/null 2>&1; then
  run_ignore sudo systemctl disable --now "${UNIT_A2A}" "${UNIT_OPENCODE}"
  run_reset_failed sudo systemctl reset-failed "${UNIT_A2A}" "${UNIT_OPENCODE}"
  run_ignore sudo rm -rf -- "${A2A_OVERRIDE_DIR}" "${OPENCODE_OVERRIDE_DIR}"
  run_ignore sudo systemctl daemon-reload
else
  echo "systemctl not found; skipping systemd unit disable/stop." >&2
fi

# Remove project directory.
if [[ -e "${PROJECT_DIR}" ]]; then
  run sudo rm -rf --one-file-system "${PROJECT_DIR}"
else
  echo "Project dir not found; skipping: ${PROJECT_DIR}"
fi

# Remove project user and group.
if id "${PROJECT_NAME}" &>/dev/null; then
  user_deleted="false"
  user_home="$(getent passwd "${PROJECT_NAME}" | cut -d: -f6 || true)"
  if [[ -n "$user_home" && "$user_home" != "${PROJECT_DIR}" ]]; then
    warn "User ${PROJECT_NAME} home mismatch (expected ${PROJECT_DIR}, got ${user_home}); refusing to delete user automatically."
    HAD_NONFATAL_FAILURE="true"
  else
    userdel_bin="$(find_exe userdel || true)"
    deluser_bin="$(find_exe deluser || true)"
    if [[ -n "$userdel_bin" ]]; then
      run_ignore sudo "$userdel_bin" "${PROJECT_NAME}"
    elif [[ -n "$deluser_bin" ]]; then
      run_ignore sudo "$deluser_bin" "${PROJECT_NAME}"
    else
      echo "Neither userdel nor deluser found; cannot remove user ${PROJECT_NAME} automatically." >&2
      HAD_NONFATAL_FAILURE="true"
      print_missing_account_tool_hints user
    fi
  fi

  # Delete group only after user deletion outcome is known.
  if ! id "${PROJECT_NAME}" &>/dev/null; then
    user_deleted="true"
  fi
else
  echo "User not found; skipping: ${PROJECT_NAME}"
  user_deleted="false"
fi

if getent group "${PROJECT_NAME}" >/dev/null 2>&1; then
  # Refuse automatic group deletion when user still exists or group has members.
  if [[ "$APPLY" == "true" && "$user_deleted" != "true" ]]; then
    warn "Refusing to delete group ${PROJECT_NAME} automatically because user ${PROJECT_NAME} still exists (or was not deleted)."
    HAD_NONFATAL_FAILURE="true"
  else
    if [[ "$APPLY" == "true" ]]; then
      members="$(getent group "${PROJECT_NAME}" | cut -d: -f4 || true)"
      if [[ -n "$members" ]]; then
        warn "Refusing to delete group ${PROJECT_NAME} automatically because it still has members: ${members}"
        HAD_NONFATAL_FAILURE="true"
        # Print command for auditability without execution.
        groupdel_bin="$(find_exe groupdel || true)"
        if [[ -n "$groupdel_bin" ]]; then
          echo "+ sudo ${groupdel_bin} ${PROJECT_NAME}"
        else
          echo "+ sudo groupdel ${PROJECT_NAME}"
        fi
      else
        groupdel_bin="$(find_exe groupdel || true)"
        delgroup_bin="$(find_exe delgroup || true)"
        if [[ -n "$groupdel_bin" ]]; then
          run_ignore sudo "$groupdel_bin" "${PROJECT_NAME}"
        elif [[ -n "$delgroup_bin" ]]; then
          run_ignore sudo "$delgroup_bin" "${PROJECT_NAME}"
        else
          echo "Neither groupdel nor delgroup found; cannot remove group ${PROJECT_NAME} automatically." >&2
          HAD_NONFATAL_FAILURE="true"
          print_missing_account_tool_hints group
        fi
      fi
    else
      # Preview mode: print what would run in apply mode.
      groupdel_bin="$(find_exe groupdel || true)"
      delgroup_bin="$(find_exe delgroup || true)"
      if [[ -n "$groupdel_bin" ]]; then
        run_ignore sudo "$groupdel_bin" "${PROJECT_NAME}"
      elif [[ -n "$delgroup_bin" ]]; then
        run_ignore sudo "$delgroup_bin" "${PROJECT_NAME}"
      else
        echo "Neither groupdel nor delgroup found; cannot remove group ${PROJECT_NAME} automatically." >&2
        print_missing_account_tool_hints group
      fi
    fi
  fi
else
  echo "Group not found; skipping: ${PROJECT_NAME}"
fi

if [[ "$APPLY" == "true" ]]; then
  if [[ "$HAD_NONFATAL_FAILURE" == "true" ]]; then
    warn "Uninstall completed with non-fatal failures. See WARN lines above."
    exit 2
  else
    echo "Uninstall completed."
  fi
else
  echo "Preview completed."
fi
if [[ "$APPLY" != "true" ]]; then
  echo
  echo "Preview only. To apply, re-run with: confirm=UNINSTALL"
fi
