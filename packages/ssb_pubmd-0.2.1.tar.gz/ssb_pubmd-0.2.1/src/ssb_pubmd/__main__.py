import sys

from ssb_pubmd.cli import run_cli


def main() -> None:
    run_cli(sys.argv)


if __name__ == "__main__":
    main()
