import json
from collections.abc import Mapping
from pathlib import Path
from typing import Any
from typing import Protocol


class StorageError(Exception): ...


class Storage(Protocol):
    def update(self, key: str, data: Mapping[str, Any]) -> None: ...
    def get(self, key: str) -> dict[str, Any]: ...


class LocalFileStorage:
    path: Path

    def __init__(self, storage_file: Path) -> None:
        self.path = storage_file
        if not self.path.exists() or self.path.stat().st_size == 0:
            with self.path.open("w") as f:
                json.dump({}, f)

    def _load(self) -> dict[str, dict[str, Any]]:
        with self.path.open() as f:
            return json.load(f)  # type: ignore

    def _save(self, data: dict[str, dict[str, Any]]) -> None:
        with self.path.open("w") as f:
            json.dump(data, f, indent=2)

    def update(self, key: str, data: Mapping[str, Any]) -> None:
        store = self._load()

        current = store.get(key, {})
        current.update(data)
        store[key] = current

        self._save(store)

    def get(self, key: str) -> dict[str, Any]:
        data = self._load().get(key)
        if data is None:
            raise StorageError(f"Content with key '{key}' has not been created yet.")
        return data.copy()
