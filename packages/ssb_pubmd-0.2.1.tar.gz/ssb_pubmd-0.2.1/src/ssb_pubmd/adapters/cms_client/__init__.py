import os
from typing import Protocol

from ssb_pubmd.adapters.cms_client.mimir import MimirCmsClient
from ssb_pubmd.adapters.cms_client.models import CmsRequest
from ssb_pubmd.adapters.cms_client.models import CmsResponse
from ssb_pubmd.adapters.cms_client.token_client import LocalTokenClient


class CmsClient(Protocol):
    def send(self, cms_request: CmsRequest) -> CmsResponse: ...


def get_cms_client(base_url: str, admin_path: str) -> CmsClient:
    cms_client = MimirCmsClient(base_url=base_url, admin_path=admin_path)
    if (local_token := os.environ.get("SSB_PUBMD_LOCAL_TOKEN")) is not None:
        cms_client.token_client = LocalTokenClient(local_token)
    return cms_client
