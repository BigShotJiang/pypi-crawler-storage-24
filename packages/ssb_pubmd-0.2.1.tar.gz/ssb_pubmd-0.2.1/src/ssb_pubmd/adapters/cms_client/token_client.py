from dataclasses import dataclass
from typing import Protocol

from dapla_auth_client import AuthClient


class TokenClient(Protocol):
    def get_token(self) -> str: ...


class DaplaTokenClient:
    def get_token(self) -> str:
        return AuthClient.fetch_personal_token(audiences=["ssbno"])


@dataclass
class LocalTokenClient:
    token: str

    def get_token(self) -> str:
        """Token copied from a Dapla service to the local environment."""
        return self.token
