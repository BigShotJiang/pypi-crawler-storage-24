from dataclasses import dataclass
from typing import Literal

from ssb_pubmd.models import UserData


@dataclass
class CmsRequest:
    """A request to create or modify a content.

    To modify an existing content, `content_id` should be set.
    `target_folder` should be used for new content or as fallback when `content_id` is invalid.
    """

    target_folder: str
    user_data: UserData
    html: str = ""
    status: Literal["draft", "review"] = "draft"
    content_id: str | None = None


@dataclass
class CmsResponse:
    """A parsed response from the CMS."""

    content_path: str
    content_id: str
    preview_url: str
    html_snippet: str
