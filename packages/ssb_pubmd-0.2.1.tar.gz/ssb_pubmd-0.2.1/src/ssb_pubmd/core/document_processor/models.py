from typing import Any
from typing import NamedTuple
from typing import TypedDict


class BlockElement(NamedTuple):
    id: str
    metadata: dict[str, Any]
    inner_html: str


class PandocElement(TypedDict):
    t: str
    c: Any


PandocAst = TypedDict(
    "PandocAst",
    {
        "pandoc-api-version": list[int],
        "meta": dict[str, Any],
        "blocks": list[PandocElement],
    },
)
