import os
from dataclasses import dataclass
from typing import Literal


@dataclass
class CmsEnvironment:
    base_url: str
    admin_path: str
    preview_path: str
    endpoint: str


def get_cms_environment() -> CmsEnvironment:
    """Configures the environment to publish to based on the Dapla environment.

    * Dapla Dev -> ssb.no Test
    * Dapla Test -> ssb.no QA
    * Dapla Prod -> ssb.no Prod
    """
    dapla_environment: Literal["DEV", "TEST", "PROD", None] = os.environ.get(
        "DAPLA_ENVIRONMENT"
    )  # type: ignore

    admin_path = "/xp/admin"
    base_url: str
    match dapla_environment:
        case "DEV":
            base_url = "https://i.test.ssb.no"
        case "TEST":
            base_url = "https://i.qa.ssb.no"
        case "PROD":
            base_url = "https://i.ssb.no"
        case _:
            base_url = "http://localhost:8080"
            admin_path = "/admin"

    return CmsEnvironment(
        base_url=base_url,
        admin_path=admin_path,
        preview_path=f"{admin_path}/site/preview/default/draft",
        endpoint="/webapp/pubmd",
    )


cms_environment = get_cms_environment()
