# Prediction Market Watcher 👀

A high-performance, multi-threaded engine for tracking prediction markets (Polymarket & Kalshi) in real-time. It handles historical backfilling, live websocket streaming, and state management, persisting everything to a normalized local SQLite database (with easy upgrade to any db solution with one class implementation).

## Installation

```bash
pip install prediction-market-watcher

```

## Configuration (The Builder Pattern)

This library uses a **Fluent Builder** pattern to ensure all required API keys are present before the system starts. You do not need to set environment variables manually; the code will guide you.

### Interactive / Programmatic Setup

```python
from prediction_market_watcher import MarketHandler

# 1. Initialize. If keys are missing, you get a "Builder" object.
handler = MarketHandler(db_name="my_data.db")

# 2. The IDE will autocomplete the missing methods based on your requirements.
#    Chain them together to initialize the system.
handler = (
    handler
    .provideKALSHI_PASSWORD("your_kalshi_pw")
    .providePOLYMARKET_API_KEY("your_poly_key")
    .provideDOME_API_KEY("your_dome_key")
)

# 3. Once all keys are provided, you get the real _RealMarketHandler ready to work.
handler.track("polymarket", "...", False)
```

## Usage

### Tracking a Market

You can pass a specific market URL or a Parent Event URL. The system is smart enough to detect the difference.

```python
# A. Track a specific ticker
ids = handler.track(
    platform="polymarket", 
    identifier="https://polymarket.com/event/will-trump-win-2024?tid=123...", 
    collect_l2=True
)

# B. Track a Parent Event (Spawns trackers for ALL child tickers)
ids = handler.track(
    platform="polymarket", 
    identifier="https://polymarket.com/event/us-election-2024"
)

```

### Managing Trackers

```python
# Get status of all running threads
status_list = handler.list_trackers()

# Stop a specific tracker (flushes data and kills thread)
handler.stop_tracker("tracker_id_here")

```

---

## System Architecture

The system is designed for fault tolerance. If one market websocket crashes, it does not affect the others.

### 1. The Orchestrator (`MarketHandler`)

* **Role:** The user interface. It manages a registry of active threads.
* **Recursive Discovery:** If you provide a "Parent Event" URL, the Handler probes the API, discovers all child markets, and recursively calls itself to spawn a thread for each child.

### 2. The Thread Model (`MarketInterface`)

Each market runs in its own **Daemon Thread**. Inside that thread, two things run in parallel:

1. **The Event Loop (Producers):** `asyncio` tasks that connect to Websockets (Trades, L1, L2) and push standardized `MarketEvent` objects into a thread-safe `Queue`.
2. **The DB Worker (Consumer):** A synchronous loop that pulls from the `Queue`, batches records, and writes them to SQLite.

### 3. The Data Lifecycle

When a tracker starts (`run()`), it follows a strict sequence to ensure data integrity:

1. **Metadata Write:**
* Inserts `ParentEvent` row.
* Inserts `TickerInfo` row (State: **Active**, Price: `None`).


2. **Backfill:**
* Blocks execution to fetch historical trades via REST API.
* Writes history to DB.


3. **Live Stream:**
* Opens Websockets for Trades, Quotes (L1), and Orderbook (L2).
* Pushes real-time data to DB.


4. **Resolution:**
* Monitors for the "Market Resolved" event.
* **Upserts** the `TickerInfo` row with the final outcome (State: **Resolved**, Price: `1.0` or `0.0`).
* Triggers a graceful shutdown.

---
## Polymarket Data Fetching

We get historical trades from Dome API.

---
## Kalshi Data Fetching
To pass in an event ticker to track, use its url e.g. https://kalshi.com/markets/kxncaaf/ncaaf-championship/kxncaaf-27.

We get historical trades from the Kalshi API.
... need to write this still


---
## Database Schema

The system uses a **Normalized SQLite Schema**.

### `ticker_info` (The State Table)

Represents the *current* truth of the ticker.

* **Active Market:** `final_price` is `NULL`, `outcome` is `NULL`.
* **Resolved Market:** `final_price` is `1.0` or `0.0`, `outcome` is `"YES"`/`"NO"`.

| Column | Type | Description |
| --- | --- | --- |
| `ticker_id` | PK | The unique slug/ID of the market. |
| `parent_event_id` | FK | Links to the parent event. |
| `ticker_name` | TEXT | The display name of the specific ticker. |
| `platform_id` | TEXT | The source platform (e.g., "Polymarket", "Kalshi"). |
| `outcome_options` | JSON | e.g., `["YES", "NO"]` or `["TRUMP", "HARRIS"]`. |
| `final_price` | REAL | `NULL` if active, `0.0`-`1.0` if resolved. |
| `outcome` | TEXT | The winning outcome string (e.g., "YES") if resolved. |
| `resolution_timestamp` | TEXT | ISO8601 timestamp of when the market resolved. |
| `start_timestamp` | TEXT | When the ticker market opened. |
| `end_timestamp` | TEXT | When the ticker market is scheduled to close. |
| `description` | TEXT | Full description or question of the market. |
| `metadata` | TEXT | Raw JSON metadata for debugging. |

### `trades` (The Event Table)

An append-only log of every trade.

| Column | Type | Description |
| --- | --- | --- |
| `trade_id` | PK | Unique hash of the trade. |
| `parent_event_id` | FK | Links to the parent event. |
| `ticker_id` | FK | Links to the specific ticker. |
| `platform_id` | TEXT | The source platform (e.g., "Polymarket"). |
| `timestamp` | TEXT | ISO8601 timestamp of the trade. |
| `price` | REAL | Execution price. |
| `size` | REAL | Size of trade. |
| `side` | TEXT | "BUY" or "SELL". |
| `outcome` | TEXT | Which outcome was traded (e.g., "YES"). |
| `maker_address` | TEXT | Wallet address of maker (if available). |
| `taker_address` | TEXT | Wallet address of taker (if available). |
| `lag_ms` | REAL | Latency in milliseconds. |
| `metadata` | TEXT | Raw JSON metadata. |

### `l1_data` (Best Bid/Ask)

Tracks the "Top of Book" (best price) over time.

| Column | Type | Description |
| --- | --- | --- |
| `parent_event_id` | FK | Links to the parent event. |
| `ticker_id` | FK | Links to the specific ticker. |
| `platform_id` | TEXT | The source platform. |
| `timestamp` | TEXT | ISO8601 timestamp of the snapshot. |
| `best_bid` | JSON | The highest price a buyer is offering. Format: `{"price": 0.98, "size": 500}`. |
| `best_ask` | JSON | The lowest price a seller is accepting. Format: `{"price": 0.99, "size": 300}`. |
| `outcome` | TEXT | The outcome viewed (e.g., "YES"). Essential for interpreting the price. |
| `spread` | REAL | The difference between best ask and best bid. |
| `metadata` | TEXT | Raw JSON metadata. |

### `l2_data` (Order Book Snapshots)

Tracks the full depth of the order book (if `collect_l2=True`).

| Column | Type | Description |
| --- | --- | --- |
| `parent_event_id` | FK | Links to the parent event. |
| `ticker_id` | FK | Links to the specific ticker. |
| `platform_id` | TEXT | The source platform. |
| `timestamp` | TEXT | ISO8601 timestamp of the snapshot. |
| `bids` | JSON | List of open buy orders. Format: `[{"price": 0.98, "size": 100}, ...]`. |
| `asks` | JSON | List of open sell orders. Format: `[{"price": 0.99, "size": 100}, ...]`. |
| `outcome` | TEXT | The outcome viewed (e.g., "YES"). |
| `metadata` | TEXT | Raw JSON metadata. |

### `parent_events` (Hierarchy Root)

Stores metadata about the overarching event (e.g., "US Election 2024").

| Column | Type | Description |
| --- | --- | --- |
| `id` | PK | The unique identifier for the event group. |
| `slug` | TEXT | The human-readable URL slug. |
| `name` | TEXT | The display name of the event. |
| `has_multiple_tickers` | BOOL | True if this event contains multiple child markets. |
| `start_timestamp` | TEXT | When the event started. |
| `end_timestamp` | TEXT | When the event is scheduled to end. |
| `description` | TEXT | Full description of the event. |
| `platform` | TEXT | The source platform (e.g., "Polymarket"). |
| `metadata` | TEXT | Raw JSON metadata. |

### `comments` (Social Sentiment)

Tracks user comments associated with the ticker.

| Column | Type | Description |
| --- | --- | --- |
| `comment_id` | PK | Unique ID of the comment. |
| `parent_event_id` | FK | Links to the parent event. |
| `ticker_id` | FK | Links to the specific ticker. |
| `platform_id` | TEXT | The source platform. |
| `timestamp` | TEXT | ISO8601 timestamp of the comment. |
| `user_id` | TEXT | ID of the user who posted. |
| `user_name` | TEXT | Display name of the user. |
| `text` | TEXT | The content of the comment. |
| `outcome` | TEXT | The outcome the user's position relates to (if applicable). |
| `user_tags` | TEXT | Tags identifying user behavior (e.g., "Whale", "Holder"). |
| `user_position_size` | REAL | Value of the user's position in this market. |
| `reply_to_id` | TEXT | ID of the comment this is replying to. |
| `metadata` | TEXT | Raw JSON metadata. |

---
## Development

### Generating Type Stubs

Because the configuration builder is dynamic, IDEs (VS Code/PyCharm) cannot see the methods by default. We provide a utility to generate static type stubs (`.pyi`).

If you modify `REQUIRED_KEYS.txt`, run:

```bash
python src/gen_stubs.py

```

This updates `handler.pyi`, enabling full IntelliSense/Autocomplete for the `provideKEY()` methods.