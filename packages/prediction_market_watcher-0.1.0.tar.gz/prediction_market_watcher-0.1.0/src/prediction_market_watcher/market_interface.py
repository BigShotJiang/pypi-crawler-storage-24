import asyncio
import queue
import threading
import time
from abc import ABC, abstractmethod
from typing import Union, Optional, List

# Import data types
from .data_types import (
    TradeData, L1Data, L2Data,
    CommentData, TickerInfo, ParentEvent, ReactionData
)
from .db import BatchWriter, LocalSQLiteClient, AsyncSQLiteClient
from . import config

# The queue ONLY accepts these 6 types.
MarketEvent = Union[
    ParentEvent,
    TradeData,
    L1Data,
    L2Data,
    CommentData,
    ReactionData,
    TickerInfo
]


class MarketInterface(ABC):
    def __init__(self, identifier: str, db_name: str, collect_l2: bool = False,
                 active_streams: Optional[List[str]] = None, category=None):

        # Identity
        self.identifier = identifier
        self.is_parent = True  # Default, updated in verify()
        self.ticker_id = 'PARENT'  # Default to 'PARENT', updated in verify()
        self.ticker_name = 'PARENT'  # "

        # Parent Metadata (Defaults to self if single, updated via set_parent_market)
        self.parent_event_id = identifier  # Default assuming it's a parent market, updated in verify()
        self.parent_event_name = identifier  # "
        self.category = category

        # Config
        self.collect_l2 = collect_l2
        self.is_running = False

        # Stream Configuration
        if active_streams is None:
            self.active_streams = {'trades', 'l1', 'comments', 'resolution', 'parent_info'}
            if collect_l2:
                self.active_streams.add('l2')
        else:
            self.active_streams = set(active_streams)
            # Ensure L2 config consistency
            if collect_l2:
                self.active_streams.add('l2')
            elif 'l2' in self.active_streams and not collect_l2:
                # If explicit stream request conflicts with flag, flag wins (force enable)
                self.collect_l2 = True

        # Data Pipeline
        self.data_queue: queue.Queue[MarketEvent] = queue.Queue()
        self.db_client = LocalSQLiteClient(db_name)

        self.writers = {
            'parent_events': BatchWriter(self.db_client, 'parent_events', batch_size=1),
            'trades': BatchWriter(self.db_client, 'trades', batch_size=1000),
            'l1': BatchWriter(self.db_client, 'l1_data'),
            'l2': BatchWriter(self.db_client, 'l2_data', batch_size=50),
            'comments': BatchWriter(self.db_client, 'comments', batch_size=5),
            'reactions': BatchWriter(self.db_client, 'reactions', batch_size=5),
            'ticker_info': BatchWriter(self.db_client, 'ticker_info', batch_size=1)
        }

    @abstractmethod
    def verify(self) -> bool:
        """
        Connects to the platform API to validate existence and determine hierarchy.

        Responsibilities:
        1. Validate: Returns False if the identifier/URL does not exist.
        2. Classify: Determines if this is a 'Parent Market' or 'Ticker'.
           - Sets self.is_parent (bool).
        3. Identity: Populates self.ticker_id and self.ticker_name.
           - If Parent: Nothing to do as defaults to 'PARENT'.
           - If Ticker: Use Ticker id and name.
        4. Parent Metadata: Populates self.parent_event_id and self.parent_event_name.
           - If Ticker: Must fetch the upstream Event ID from the API.
           - If Parent: Sets these to its own ID/Name.
        5. Discovery: If Parent, fetches and stores list of child markets internally
           so that get_tickers_for_parent() can return them. (this structure can be
           determined in the implementation of the interface to allow for flexibility).
           Crucially, we do the API calls in this function and NOT in get_tickers_for_parent
           to coalesce all errors in verify. If we exit Verify with True we must be
           certain the object is instantiated fully and correctly.

        Returns:
            bool: True if valid and metadata successfully populated.
        """
        pass

    @abstractmethod
    def is_parent_event(self) -> bool:
        """
        Returns True if the identifier points to a Parent Event (e.g. 'Next Fed Chair?')
        that contains multiple tradeable tickers.
        """
        pass

    @abstractmethod
    def get_tickers_for_parent(self) -> list[str]:
        """
        If _is_parent_event() is True, returns a list of identifiers (URLs)
        for all the children tickers.
        """
        pass

    @abstractmethod
    def get_parent_identifier(self) -> str:
        """
        Returns the valid URL/Identifier for this ticker's Parent Event.
        Used by Handler to spawn a parent tracker from a child tracker.
        """
        pass

    def set_parent_event(self, parent_id: str, parent_name: str):
        """
        Sets the metadata for the parent event.
        Used when this tracker is running as a child.
        """
        self.parent_event_id = parent_id
        self.parent_event_name = parent_name

    @abstractmethod
    def add_ticker_info(self) -> None:
        """
        Constructs a TickerInfo object (with missing fields None. e.g. outcome=None) and
        puts it into self.data_queue immediately to log existence.
        """
        pass

    @abstractmethod
    def is_ticker_actively_trading(self) -> bool:
        """Returns True if ticker is currently trading (active & not closed)."""
        pass

    @abstractmethod
    def is_ticker_done_trading(self) -> bool:
        """Returns True if the ticker has already finished trading (all data can be backfilled, except potentially resolution outcome)."""
        pass

    @abstractmethod
    def is_ticker_resolved(self) -> bool:
        """Returns True if there is a final outcome determined."""
        # TODO: ideally, should also read db to make sure that the final outcome has been recorded
        # this function is used to decide if thread should be killed (i.e. no more streaming market updates/resolution)
        pass

    @abstractmethod
    def add_parent_event(self) -> None:
        """
        Constructs a ParentEvent object and
        puts it into self.data_queue.
        """
        pass

    @abstractmethod
    def backfill_all(self) -> None:
        """
        Blocking call to fetch historical data before streaming starts.
        Should push historical events (TradeData, etc.) to self.data_queue.
        """
        pass

    # Streaming Interfaces

    @abstractmethod
    async def _stream_trades(self) -> None:
        """
        Connects to trade stream.
        MUST produce: TradeData objects
        Puts into: self.data_queue
        """
        pass

    @abstractmethod
    async def _stream_l1(self) -> None:
        """
        Connects to Best Bid/Ask stream.
        MUST produce: L1Data objects
        Puts into: self.data_queue
        """
        pass

    @abstractmethod
    async def _stream_l2(self) -> None:
        """
        Connects to full Order Book stream.
        MUST produce: L2Data objects
        Puts into: self.data_queue
        """
        pass

    @abstractmethod
    async def _stream_comments(self) -> None:
        """
        Connects to social/comment stream.
        MUST produce: CommentData objects
        Puts into: self.data_queue
        """
        pass

    @abstractmethod
    async def _monitor_resolution(self) -> None:
        """
        Polls for ticker resolution.
        MUST produce: TickerInfo (Single event)
        Action: Puts into queue, then sets self.is_running = False
        """
        pass

    def _db_worker(self):
        """
        The Consumer Thread.
        Reads 'MarketEvent' items from the Queue and routes to DB.
        """
        platform_disp = self.__class__.__name__.replace("Tracker", "")
        last_stale_check = time.time()
        try:
            while self.is_running or not self.data_queue.empty():
                try:
                    item: MarketEvent = self.data_queue.get(timeout=0.5)

                    if config.is_verbose():
                        q_size = self.data_queue.qsize()
                        buffer_info = []
                        for name, writer in self.writers.items():
                            # Show buffer if it has items
                            if len(writer.buffer) > 0:
                                buffer_info.append(f"{name}: {len(writer.buffer)}/{writer.batch_size}")

                        buffer_str = f" | Buffers: {', '.join(buffer_info)}" if buffer_info else ""

                        ticker_disp = self.ticker_name[:20] if self.ticker_name else "Unknown"

                        print(
                            f"[{platform_disp} | {ticker_disp}] Q: {q_size} | Processing: {type(item).__name__}{buffer_str}")

                    # Route based on type
                    if isinstance(item, TradeData):
                        self.writers['trades'].add(item)
                    elif isinstance(item, L1Data):
                        self.writers['l1'].add(item)
                    elif isinstance(item, L2Data):
                        self.writers['l2'].add(item)
                    elif isinstance(item, CommentData):
                        self.writers['comments'].add(item)
                    elif isinstance(item, ReactionData):
                        self.writers['reactions'].add(item)
                    elif isinstance(item, TickerInfo):
                        self.writers['ticker_info'].add(item)
                        self.writers['ticker_info'].flush()
                    elif isinstance(item, ParentEvent):
                        self.writers['parent_events'].add(item)
                        self.writers['parent_events'].flush()
                    else:
                        print(f"[{self.ticker_name} | {platform_disp}] WARNING: Unknown MarketEvent type received: {type(item)}")
                        print(f"Expected one of: {TradeData}, {L1Data}, etc.")

                    self.data_queue.task_done()
                except queue.Empty:
                    continue
                except Exception as e:
                    print(f"Error in DB Worker: {e}")

                now = time.time()
                if now - last_stale_check > 1.0:
                    for w in self.writers.values():
                        # If data has sat for > 50 seconds, force write it
                        w.flush_if_stale(max_age_seconds=50.0)
                    last_stale_check = now
        finally:
            print(f"[{self.ticker_name} | {platform_disp}] DB Worker stopping. Flushing buffers...")
            for w in self.writers.values():
                w.flush()

    async def _start_streams(self):
        """Launches ONLY requested stream tasks."""
        tasks = []
        if 'trades' in self.active_streams: tasks.append(self._stream_trades())
        if 'l1' in self.active_streams: tasks.append(self._stream_l1())
        if 'comments' in self.active_streams: tasks.append(self._stream_comments())
        if 'resolution' in self.active_streams: tasks.append(self._monitor_resolution())
        if self.collect_l2 and 'l2' in self.active_streams: tasks.append(self._stream_l2())

        if tasks: await asyncio.gather(*tasks)

    def run(self):
        if not self.verify(): raise ValueError("Invalid Market Identifier")

        self.is_running = True
        db_thread = threading.Thread(target=self._db_worker, daemon=True)
        db_thread.start()

        backfill_thread = None

        try:
            # CASE A: Parent Event
            if self.is_parent_event():
                print(f"[{self.identifier}] Starting Parent Event Tracker...")

                if 'parent_info' in self.active_streams:
                    self.add_parent_event()

                # Backfill (Comments only, trades handled by stream flags)
                backfill_thread = threading.Thread(target=self.backfill_all, daemon=True, name=f"bf-parent")
                backfill_thread.start()

                asyncio.run(self._start_streams())
                return

            # CASE B: Child Ticker
            if self.is_ticker_done_trading():
                print(f"[{self.ticker_name}] Market Resolved. Fetching outcome...")
                try:
                    if 'parent_info' in self.active_streams: self.add_parent_event()
                    self.add_ticker_info()
                    self.backfill_all()
                    asyncio.run(self._monitor_resolution())
                except Exception as e:
                    print(f"[{self.ticker_name}] Error in resolved market loop: {e}")
                finally:
                    self.stop()
                    db_thread.join()
                return
            
            while not self.is_ticker_actively_trading(): # ticker hasn't opened for trading yet
                # wait until the market opens for trading to begin collecting data
                time.sleep(60)

            if 'parent_info' in self.active_streams:
                self.add_parent_event()

            self.add_ticker_info()

            backfill_thread = threading.Thread(target=self.backfill_all, daemon=True, name=f"bf-{self.ticker_id}")
            backfill_thread.start()

            asyncio.run(self._start_streams())

        except KeyboardInterrupt:
            pass
        except Exception as e:
            print(f"[{self.ticker_name}] Runtime Error: {e}")
            raise e
        finally:
            self.stop()
            if backfill_thread and backfill_thread.is_alive():
                backfill_thread.join(timeout=5.0)
            db_thread.join()

    def stop(self):
        self.is_running = False

        # Force close the unified client if it exists
        if hasattr(self, 'unified_client') and self.unified_client.ws:
            # We need to run this async method from a sync context
            try:
                loop = asyncio.get_event_loop()
                if loop.is_running():
                    # If loop is running (rare in stop()), schedule the close
                    loop.create_task(self.unified_client.close())
                else:
                    loop.run_until_complete(self.unified_client.close())
            except Exception as e:
                print(f"[{self.ticker_id}] Error closing socket: {e}")

        # Fallback for the old clients if you haven't fully refactored yet
        if hasattr(self, 'market_updates_client') and self.market_updates_client and self.market_updates_client.ws:
            try:
                loop = asyncio.get_event_loop()
                loop.run_until_complete(self.market_updates_client.close())
            except:
                pass
