import asyncio
import hashlib
import json
import threading
import time
from datetime import datetime, timezone
from typing import Any, Callable, List, Optional, Tuple
from urllib.parse import urlparse
from collections import OrderedDict

import certifi
import copy

import requests
from websocket import WebSocketApp, WebSocketConnectionClosedException

from .data_types import L1Data, Outcome, PlatformId, TickerInfo, TradeData, Side, L2Data, ParentEvent, Level, \
    ReactionData, CommentData
from .market_interface import MarketInterface
from .util import (events_to_dfs, unix_ts_to_utc_dt, utc_dt_to_unix_ts_ms,
                  unix_ts_ms_to_utc_dt, save_resp_to_json, convert_iso_zulu_to_datetime)
from .exceptions import *
from . import config

class PolymarketTracker(MarketInterface):
    """Polymarket tracker backed by Gamma API + market websocket."""
    MODES = {"event", "market"}

    def __init__(self, identifier, db_name, collect_l2=False, active_streams=None, category=None):
        # Initialize tracker and API client.
        super().__init__(identifier, db_name, collect_l2, active_streams=active_streams)
        # --- API client / metadata ---
        self.gamma = GammaAPI()
        self.collect_l2 = collect_l2
        self.parent_event_data = None
        self.category = category
        self.ticker_info_object = None  # keeps track of market, updates on market updates
        self.child_data = []  # Child URLS
        self.clob_token_ids = OrderedDict()  # CLOB ids to connect to Websocket.
        # --- Websocket routing ---
        self.ws_event_queues = {
            "trades": asyncio.Queue(),
            "l1": asyncio.Queue(),
            "l2": asyncio.Queue(),
            "comments": asyncio.Queue(),
            "resolution": asyncio.Queue(),
        }

        self._clob_ws: Optional[MarketWebSocket] = None
        self._dome_ws: Optional['DomeTradeWebSocket'] = None
        self._rtds_ws: Optional['CommentsRTDSWebSocket'] = None

        self._ws_threads = []
        self._ws_started = False

    @staticmethod
    def _convert_timestamp_to_datetime(timestamp: int):
        # If timestamp is small (e.g. 1.7 billion), it's seconds.
        # If timestamp is huge (e.g. 1.7 trillion), it's milliseconds.
        if timestamp < 100000000000:  # Threshold: Sat Mar 03 1973 if treated as ms
            return unix_ts_to_utc_dt(timestamp)
        return unix_ts_to_utc_dt(timestamp // 1000)

    def _build_identifier(self, mode: str, slug: str):
        """Build a canonical Polymarket URL from parts."""
        assert mode in self.MODES, f"Mode ({mode}) is not in {self.MODES}"
        return f"https://polymarket.com/{mode}/{slug}"

    def _extract_mode_slug(self, identifier: str) -> Tuple[str, str]:
        """Extract (mode, slug) from a Polymarket URL."""
        if self._is_polymarket(identifier):
            sections = identifier.split("/")
            mode = sections[-2]
            assert mode in {'event', 'market'}, f"Mode ({mode}) must be one of (event, market)"
            slug = sections[-1].split("?tid=")[0]
            return mode, slug
        raise ValueError("Identifier is not Polymarket")

    def dome_header(self):
        dome_api_key = config.get_key("DOME_API_KEY")
        return {"Authorization": f"Bearer {dome_api_key}"}

    def _is_polymarket(self, identifier: str):
        """Quick hostname guard."""
        if "polymarket.com" in identifier:
            return True
        return False

    def _create_trade_id(self, asset_id, timestamp_ms, price_value, size_value, side_value):
        """Creates a Trade ID"""
        return hashlib.sha256(
                f"{asset_id}|{timestamp_ms}|{price_value}|{size_value}|{side_value}".encode("utf-8")
            ).hexdigest()

    def get_parent_identifier(self) -> str:
        """Returns the valid URL for this ticker's Parent Event."""
        if self.is_parent:
            return self.identifier
        if self.parent_event_id:
            return self._build_identifier('event', self.parent_event_id)
        raise ValueError("Parent Event ID not available yet. Call verify() first.")

    def verify(self) -> bool:
        try:
            if not self.identifier:
                raise ValueError("Missing identifier")

            if not self.gamma.online():
                raise ValueError("GammaAPI is offline")

            mode, slug = self._extract_mode_slug(self.identifier)

            if mode == 'event':
                event = self.gamma.get_event_by_slug(slug)
                if event is None:
                    raise ValueError("Event could not be extracted from Gamma API")
                self.is_parent = True

                self.parent_event_data = event

                self.parent_event_id = str(event.get('slug', slug))
                self.parent_event_name = f"{event.get('title', slug)}"
                self.child_data = []
                for m in event.get("markets", []):
                    if not isinstance(m, dict) or 'slug' not in m:
                        continue
                    self.child_data.append(self._build_identifier('market', m["slug"]))

                # A parent event CANNOT have trades/L1/L2. Remove them if present to avoid "PARENT" trades bug.
                if 'trades' in self.active_streams: self.active_streams.remove('trades')
                if 'l1' in self.active_streams: self.active_streams.remove('l1')
                if 'l2' in self.active_streams: self.active_streams.remove('l2')

                return True

            if mode == 'market':
                market = self.gamma.get_market_by_slug(slug)
                if market is None:
                    raise ValueError("Market could not be extracted from Gamma API")
                self.is_parent = False
                self.ticker_id = str(market.get("slug"))
                self.ticker_name = market.get("question", slug)

                parent_event: dict = market.get('events', [{}])[0]
                self.parent_event_id = str(parent_event.get('slug', "NotFoundError"))
                self.parent_event_name = f"{parent_event.get('title', parent_event.get('slug', 'NotFoundError'))}"

                self.parent_event_data = self.gamma.get_event_by_slug(self.parent_event_id)
                self.ticker_info_data = market

                self.clob_token_ids = {}
                if 'clobTokenIds' in market and 'outcomes' in market:
                    self.clob_token_ids = dict(zip(json.loads(market['clobTokenIds']), json.loads(market['outcomes'])))
                if not self.clob_token_ids:
                    raise ValueError("No CLOB token ids found.")
                return True

            raise ValueError("Unsupported Polymarket URL path")
        except (requests.RequestException, ValueError, KeyError, TypeError) as e:
            print("ERROR:", e)
            return False

    def is_parent_event(self) -> bool:
        """True if this tracker represents a parent event."""
        return self.is_parent

    def get_tickers_for_parent(self) -> List[str]:
        """Return child market URLs for a parent event."""
        return self.child_data

    def set_parent_event(self, parent_id: str, parent_name: str):
        """Set parent market identifiers."""
        self.parent_event_id = parent_id
        self.parent_event_name = parent_name

    def add_parent_event(self):
        # Both parent and child can safely call this as long as the data exists.
        if not getattr(self, 'parent_event_data', None):
            print(f"[{self.identifier}] No parent_event_data found, skipping.")
            return

        event = self.parent_event_data

        # Safely parse dates with fallback to now if missing
        start_date = event.get("startDate") or (datetime.now().isoformat() + "Z")
        end_date = event.get("endDate") or (datetime.now().isoformat() + "Z")

        parent_event = ParentEvent(
            slug=self.parent_event_id,
            id=str(event.get("id", self.parent_event_id)),
            name=event.get("title", self.parent_event_name),
            has_multiple_tickers=(len(event.get("markets", [])) > 1),
            start_timestamp=convert_iso_zulu_to_datetime(start_date),
            end_timestamp=convert_iso_zulu_to_datetime(end_date),
            description=event.get("description", ""),
            platform=PlatformId.POLY,
            metadata="" if self.category is None else json.dumps({"category": self.category})
        )
        self.data_queue.put(parent_event)

    def add_ticker_info(self):
        if self.is_parent_event() or not getattr(self, 'ticker_info_data', None):
            return

        market = copy.deepcopy(self.ticker_info_data)

        is_resolved = market["closed"]
        outcomes = json.loads(market["outcomes"])
        start_date = market["startDate"]
        start_timestamp = convert_iso_zulu_to_datetime(start_date)
        end_date = market["endDate"]
        end_timestamp = convert_iso_zulu_to_datetime(end_date)
        updated_at = market["updatedAt"]
        updated_timestamp = convert_iso_zulu_to_datetime(updated_at)
        token_ids = json.loads(market["clobTokenIds"])

        final_outcome = None
        if is_resolved:
            final_outcome_prices = json.loads(market["outcomePrices"])
            outcome_dict = {float(px): outcome for px, outcome in zip(final_outcome_prices, outcomes)}
            final_outcome = outcome_dict.get(1, None)

        ticker_info = TickerInfo(
            parent_event_id=self.parent_event_id,
            ticker_id=self.ticker_id,
            ticker_name=self.ticker_name,
            platform_id=PlatformId.POLY,
            outcome_options=outcomes,
            outcome=final_outcome,
            start_timestamp=start_timestamp,
            end_timestamp=end_timestamp if not is_resolved else updated_timestamp,
            description=market["description"],
            metadata=json.dumps({
                'condition_id': market['conditionId'],
                'id': market['id'],
                'clobTokenIds': {outcomes[0]: token_ids[0], outcomes[1]: token_ids[1]},
                'createdAt': market['createdAt']
            })
        )

        self.ticker_info_object = ticker_info
        self.data_queue.put(ticker_info)

    def is_ticker_actively_trading(self) -> bool:
        """Return True if market is active and not closed."""
        m = self.gamma.get_market_by_slug(self.ticker_id)
        return m.get('active', False) and not m.get('closed', True)

    def is_ticker_done_trading(self) -> bool:
        """Return True if market is closed/resolved."""
        m = self.gamma.get_market_by_slug(self.ticker_id)
        return m.get('closed', True)

    def is_ticker_resolved(self) -> bool: # should not be called for parents..
        m = self.gamma.get_market_by_slug(self.ticker_id)
        return m["closed"] and ("1" in m.get("outcomePrices", []))

    def _get_historical_order_book_for_outcome_page(self, token_id, collect_l2, pagination_key = None, page_num = None):
        url = "https://api.domeapi.io/v1/polymarket/orderbooks"

        metadata = json.loads(self.ticker_info_object.metadata)
        created_at_dt = convert_iso_zulu_to_datetime(metadata["createdAt"])

        start_time_ts = utc_dt_to_unix_ts_ms(created_at_dt) # using createdAt instead of startDate (because startDate might be > today)
        end_time_ts = utc_dt_to_unix_ts_ms(datetime.now(timezone.utc))

        params = {"token_id": token_id,
                  "start_time": start_time_ts,
                  "end_time": end_time_ts,
                  "limit": 200
                  }
        if pagination_key is not None:
            params["pagination_key"] = pagination_key

        time.sleep(1)
        resp = requests.get(
            url=url,
            params=params,
            headers=self.dome_header()
        )
        data = resp.json()


        if resp.ok:
            snapshots = data["snapshots"]
            print((f"Page {page_num}: " if page_num is not None else "") + f"Fetched {len(snapshots)} snapshots of the order book for Polymarket market {self.ticker_id}, outcome {self.clob_token_ids[token_id]}")

            for i, snapshot in enumerate(snapshots):
                # asks, sorted from best ask to worst (low to high)
                sorted_asks = sorted(snapshot["asks"], key = lambda x: x["price"])
                ask_levels = [Level(size=float(level["size"]), price=float(level["price"])) for level in sorted_asks]

                # bids, sorted from best bid to worst (high to low)
                sorted_bids = sorted(snapshot["bids"], key = lambda x: x["price"], reverse=True)
                bid_levels = [Level(size=float(level["size"]), price=float(level["price"])) for level in sorted_bids]

                # for handling empty asks/bids, assume best ask = 1 and best bid = 0, s.t. spread = 1
                best_ask = Level(price=1, size=0)
                best_bid = Level(price=0, size=0)

                if len(ask_levels) > 0:
                    best_ask = ask_levels[0]

                if len(bid_levels) > 0:
                    best_bid = bid_levels[0]
                outcome = self.clob_token_ids[snapshot["assetId"]]

                l1data = L1Data(parent_event_id = self.parent_event_id,
                                ticker_id = self.ticker_id,
                                platform_id = PlatformId.POLY,
                                timestamp = unix_ts_ms_to_utc_dt(snapshot["timestamp"]),
                                best_bid = best_bid,
                                best_ask = best_ask,
                                outcome = outcome,
                                metadata = "",
                                spread = best_ask.price - best_bid.price)
                self.data_queue.put(l1data)

                if collect_l2:
                    l2data = L2Data(parent_event_id = self.parent_event_id,
                                    ticker_id = self.ticker_id,
                                    platform_id = PlatformId.POLY,
                                    timestamp = unix_ts_ms_to_utc_dt(snapshot["timestamp"]),
                                    bids = bid_levels,
                                    asks = ask_levels,
                                    outcome = outcome,
                                    metadata = "")
                    self.data_queue.put(l2data)

            pagination_key = None
            if data["pagination"]["has_more"]:
                pagination_key = data["pagination"]["pagination_key"]

            return pagination_key
        else:
            raise HistoricalOrderBookError(f"Failed to retrieve historical order book data for Polymarket market {self.ticker_id} from Predexon API. Error status code = {resp.status_code}, {resp.text}")

    def get_historical_order_book(self, collect_l2):
        print(f"Querying for Polymarket historical order book for market {self.ticker_id} at {datetime.now()} PST")

        for token_id in self.clob_token_ids.keys():
            page_num = 1
            pagination_key = self._get_historical_order_book_for_outcome_page(token_id, collect_l2 = collect_l2, page_num = page_num)

            while pagination_key:
                page_num += 1
                pagination_key = self._get_historical_order_book_for_outcome_page(token_id, collect_l2 = collect_l2, pagination_key = pagination_key, page_num = page_num)

    def _get_historical_trades_page(self, market_slug: str, parent_event_id: str, pagination_key = None, page_num=None):
        url = "https://api.domeapi.io/v1/polymarket/orders"

        params: dict[str, Any] = {"limit": 1000}
        params["market_slug"] = market_slug

        if pagination_key is not None:
            params["pagination_key"] = pagination_key

        resp = requests.get(url, params=params, headers=self.dome_header())

        all_trades = []
        new_pagination_key = None

        if resp.ok:
            data = resp.json()
            trades = data['orders']
            print((f"Page {page_num}: " if page_num is not None else "") + f"Fetched {len(trades)} trades for Polymarket market {market_slug}")
            if not trades:
                return all_trades, None

            for i, trade in enumerate(trades):
                side = Side.BUY if trade['side'] == 'BUY' else Side.SELL
                size = trade['shares_normalized']
                price = trade['price']
                timestamp = int(trade['timestamp'])
                outcome = trade['token_label']

                td = TradeData(
                    trade_id=self._create_trade_id(trade['token_id'], timestamp, price, size, side),
                    # TODO: agree on convention w john
                    parent_event_id=parent_event_id,
                    ticker_id=trade['market_slug'],
                    platform_id=PlatformId.POLY,
                    timestamp=self._convert_timestamp_to_datetime(timestamp),
                    price=price,
                    size=size,
                    side=side,
                    outcome=outcome,
                    maker_address=trade['user'],
                    taker_address=trade['taker']
                )

                self.data_queue.put(td)
                all_trades.append(td)

            if data["pagination"]["has_more"]:
                new_pagination_key = data["pagination"]["pagination_key"]

        else:
            print("Error:", resp.status_code, resp.text)

        return all_trades, new_pagination_key

    def get_historical_trades(self, ticker_id: str, parent_event_id: str, pagination_key = None, debug_csv=False):
        print(f"Querying for Polymarket historical trades for market {ticker_id} at {datetime.now()} PST")
        i = 1

        all_trades, pagination_key = self._get_historical_trades_page(ticker_id, parent_event_id, page_num=i)
        last_trades = all_trades

        if debug_csv:
            events_to_dfs(all_trades).trades.to_csv(f"poly_trades{i}.csv", index=False)

        while pagination_key:
            i += 1
            time.sleep(1) # to avoid rate limit, but we can also get the dev tier for dome

            last_trades, pagination_key = self._get_historical_trades_page(ticker_id, parent_event_id, pagination_key, page_num=i)

            if debug_csv:
                if i < 4:
                    events_to_dfs(last_trades).trades.to_csv(f"poly_trades{i}.csv", index=False)
        if debug_csv:
            events_to_dfs(last_trades).trades.to_csv(f"poly_trades{i}.csv", index=False)

    def _parse_comment_payload(self, c: dict) -> List[Any]:
        items = []
        positions_snap = c.get('profile', {}).get('positions', [])

        raw_ts = c.get('createdAt')

        comment_ts = convert_iso_zulu_to_datetime(raw_ts)

        comment = CommentData(
            comment_id=str(c['id']),
            parent_event_id=self.parent_event_id,
            ticker_id=None,
            platform_id=PlatformId.POLY,
            timestamp=comment_ts,
            user_id=c.get('profile', {}).get('proxyWallet') or "Unknown",
            user_name=c.get('profile', {}).get('name', 'Anonymous'),
            text=c.get('body', ''),
            reply_to_id=str(c.get('parentCommentID')) if c.get('parentCommentID') else None,
            user_position_snapshot=json.dumps(positions_snap),
            outcome=None,
            metadata=json.dumps({'deleted': False}) #! Not Used
        )
        items.append(comment)

        for r in c.get('reactions', []):
            reaction_ts = comment_ts

            items.append(ReactionData(
                reaction_id=str(r['id']),
                comment_id=str(c['id']),
                user_address=r.get('profile', {}).get('proxyWallet') or r.get('profile', {}).get('baseAddress'),
                reaction_type=r.get('reactionType', 'like'),
                timestamp=reaction_ts,
                platform_id=PlatformId.POLY
            ))

        return items

    def get_all_comments(self):
        """Fetches ALL historical comments via pagination."""
        if 'comments' not in self.active_streams:
            return

        print(f"[{self.ticker_name}] Backfilling Comments...")

        if not self.parent_event_data:
            self.parent_event_data = self.gamma.get_event_by_slug(self.parent_event_id)

        series = self.parent_event_data.get("series", [{}])[0]
        gamma_id = series.get("id") or self.parent_event_data.get("id")

        if not gamma_id:
            print("   [Warning] No Gamma ID found for comments.")
            return

        limit = 100
        offset = 0
        total_fetched = 0

        while True:
            params = {
                "limit": limit,
                "offset": offset,
                "parent_entity_type": "Event" if self.category == "mention-markets" else "Series",
                "parent_entity_id": int(gamma_id),
                "get_positions": "true"
            }

            try:
                resp = self.gamma._get("/comments", params=params)

                if not resp or len(resp) == 0:
                    break

                for c in resp:
                    items = self._parse_comment_payload(c)
                    for item in items:
                        self.data_queue.put(item)

                count = len(resp)
                total_fetched += count
                print(f"   Fetched {count} comments (Total: {total_fetched})")

                if count < limit:
                    break

                offset += limit
                time.sleep(0.2)

            except Exception as e:
                print(f"   [Error] Comment backfill failed at offset {offset}: {e}")
                break

    def backfill_all(self):
        """
        Backfills data based on which streams are active.
        """
        if not self.is_parent_event():
            # 1. Trades (Only if streaming trades)
            if 'trades' in self.active_streams:
                self.get_historical_trades(self.ticker_id, self.parent_event_id)

            # 2. Orderbook (Only if streaming L1 or L2)
            if 'l1' in self.active_streams or 'l2' in self.active_streams:
                self.get_historical_order_book(self.collect_l2)

        # 3. Comments (Only if streaming comments - likely Parent Tracker)
        if 'comments' in self.active_streams:
            self.get_all_comments()

    def _route_ws_event(self, queue_name: str, payload: Any):
        """Standardized router for all websockets."""
        if queue_name in self.active_streams:
            self.ws_event_queues[queue_name].put_nowait(payload)

    def start_dome_listener(self):
        if self._dome_ws: return

        api_key = config.get_key("DOME_API_KEY")
        if not api_key:
            print("[Warning] No DOME_API_KEY found. Trades will lack addresses.")
            return

        def _on_trade(payload):
            self._route_ws_event("trades", payload)

        self._dome_ws = DomeTradeWebSocket(
            api_key=api_key,
            market_slugs=[self.ticker_id],  # Filter by this market
            message_callback=_on_trade,
            verbose=False
        )
        t = threading.Thread(target=self._dome_ws.run, daemon=True)
        t.start()
        self._ws_threads.append(t)

    async def _stream_trades(self):
        """Stream trades from Dome API to get addresses."""
        self.start_dome_listener()
        # Fallback to CLOB listener for trade signal if Dome fails?
        # For now, relying on Dome for trades.
        try:
            while self.is_running:
                try:
                    # [FIX] Added timeout to allow loop to check self.is_running
                    payload = await asyncio.wait_for(self.ws_event_queues["trades"].get(), timeout=1.0)
                except asyncio.TimeoutError:
                    continue

                trade = self._parse_dome_trade(payload)
                if trade:
                    self.data_queue.put(trade)
                    print(f"TRADE PLACED (User: {trade.maker_address[:6]}...)")
        except Exception as e:
            print(f"TRADES STREAM ERROR: {e}")

    def _parse_dome_trade(self, data: dict) -> Optional[TradeData]:
        """Convert Dome WS event to TradeData."""
        try:
            return TradeData(
                trade_id=data.get('id') or hashlib.sha256(str(data).encode()).hexdigest(),
                parent_event_id=self.parent_event_id,
                ticker_id=self.ticker_id,
                platform_id=PlatformId.POLY,
                timestamp=unix_ts_to_utc_dt(data.get('timestamp')),
                price=float(data.get('price')),
                size=float(data.get('size')),
                side=Side(data.get('side').upper()),
                outcome=Outcome(data.get('outcome_label')),
                maker_address=data.get('maker_address'),
                taker_address=data.get('taker_address'),
                metadata=json.dumps(data)
            )
        except Exception:
            return None

    def start_comments_rtds_listener(self):
        if self._rtds_ws: return

        # We need the numeric Gamma ID for the Event/Series
        if not self.parent_event_data:
            self.parent_event_data = self.gamma.get_event_by_slug(self.parent_event_id)

        # Prefer Series ID for comments
        series = self.parent_event_data.get("series", [{}])[0]
        entity_id = int(series.get("id") or self.parent_event_data.get("id"))

        def _on_comment_event(payload):
            self._route_ws_event("comments", payload)

        self._rtds_ws = CommentsRTDSWebSocket(
            parent_entity_id=entity_id,
            message_callback=_on_comment_event
        )
        t = threading.Thread(target=self._rtds_ws.run, daemon=True)
        t.start()
        self._ws_threads.append(t)

    def stop_comments_rtds_listener(self):
        if self._rtds_ws:
            self._rtds_ws.stop()
            self._rtds_ws = None

    async def _stream_comments(self):
        """Stream real-time comments and reactions."""
        self.start_comments_rtds_listener()

        while self.is_running:
            try:
                try:
                    event = await asyncio.wait_for(self.ws_event_queues["comments"].get(), timeout=1.0)
                except asyncio.TimeoutError:
                    continue

                event_type = event.get('type')  # e.g. "comment_created", "reaction_created"
                data = event.get('item', {})  # The actual data payload

                if event_type == "comment_created":
                    # Parse Comment
                    c_obj = CommentData(
                        comment_id=str(data.get('id')),
                        parent_event_id=self.parent_event_id,
                        ticker_id=None,
                        platform_id=PlatformId.POLY,
                        timestamp=convert_iso_zulu_to_datetime(data.get('createdAt')),
                        user_id=data.get('profile', {}).get('proxyWallet') or "Unknown",
                        user_name=data.get('profile', {}).get('name'),
                        text=data.get('body'),
                        reply_to_id=data.get('parentCommentID'),
                        user_position_snapshot=json.dumps(data.get('profile', {}).get('positions', [])),
                        outcome=None,
                        metadata=json.dumps(data)
                    )
                    self.data_queue.put(c_obj)
                    print(f"COMMENT: {c_obj.user_name} says '{c_obj.text[:20]}...'")

                elif event_type == "reaction_created":
                    # Parse Reaction
                    r_obj = ReactionData(
                        reaction_id=str(data.get('id')),
                        comment_id=str(data.get('commentID')),
                        user_address=data.get('profile', {}).get('proxyWallet'),
                        reaction_type=data.get('reactionType'),
                        timestamp=convert_iso_zulu_to_datetime(data.get('createdAt')),
                        platform_id=PlatformId.POLY
                    )
                    self.data_queue.put(r_obj)
                    print(f"REACTION: {r_obj.reaction_type} on comment {r_obj.comment_id}")

            except Exception as e:
                print(f"RTDS ERROR: {e}")

    def start_market_ws_listener(self, url="wss://ws-subscriptions-clob.polymarket.com", verbose=False):
        if self._ws_started: return

        loop = asyncio.get_running_loop()

        def _on_message(payload):
            if isinstance(payload, dict): payload = [payload]
            for p in payload:
                loop.call_soon_threadsafe(self._route_ws_event, p.get("event_type"), p)

        self._clob_ws = MarketWebSocket(
            asset_ids=list(self.clob_token_ids),
            message_callback=_on_message,
            url=url,
            verbose=verbose,
            ping_interval=5,
        )

        t = threading.Thread(target=self._clob_ws.run, daemon=True)
        t.start()
        self._ws_threads.append(t)
        self._ws_started = True

        if 'l1' in self.active_streams or 'l2' in self.active_streams:
            if self._clob_ws.wait_for_connection(timeout=20.0):
                self._clob_ws.subscribe(list(self.clob_token_ids), "book")
            else:
                print("[Error] Failed to connect to CLOB WS for Book subscription")

    def stop_market_ws_listener(self):
        if self._clob_ws: self._clob_ws.stop()
        self._clob_ws = None
        self._ws_started = False

    async def _stream_l1(self):
        """Consume best bid/ask events and enqueue L1Data."""
        self.start_market_ws_listener()
        try:
            bbos: dict[str, dict[str, Level]] = {}
            default: dict[str, Level] = {'best_bid': Level(0, 0), 'best_ask': Level(1.0, 0)}
            while self.is_running:
                try:
                    payload = await asyncio.wait_for(self.ws_event_queues["l1"].get(), timeout=1.0)
                except asyncio.TimeoutError:
                    continue
                # if book, this is an OB snapshot so just pull the existing OB
                if payload.get("event_type") == "book":
                    # Extract Values from payload
                    asset_id = payload.get("asset_id") or payload.get("market", "unknown")
                    buys = payload.get("bids") or []
                    sells = payload.get("asks") or []
                    best_bid_price = float(buys[-1]["price"]) if buys else 0.0
                    best_ask_price = float(sells[-1]["price"]) if sells else 1.0
                    best_bid_size = float(buys[-1]["size"]) if buys else 0.0
                    best_ask_size = float(sells[-1]["size"]) if sells else 0.0
                    spread = best_ask_price - best_bid_price if best_ask_price and best_bid_price else 0.0
                    best_bid = Level(best_bid_price, best_bid_size)
                    best_ask = Level(best_ask_price, best_ask_size)
                    outcome = self.clob_token_ids[asset_id]
                    timestamp = self._convert_timestamp_to_datetime(int(payload.get("timestamp", time.time() * 1000)))

                    # Construct L1 Data
                    l1 = L1Data(
                        parent_event_id=self.parent_event_id,
                        ticker_id=self.ticker_id,
                        platform_id=PlatformId.POLY,
                        timestamp=timestamp,
                        best_bid=best_bid,
                        best_ask=best_ask,
                        outcome=Outcome(outcome),
                        metadata="",
                        spread=spread,
                    )
                    self.data_queue.put(l1)

                    # Update Orderbook
                    bbos[asset_id] = {'best_bid': best_bid, 'best_ask': best_ask}
                    print("L1 PLACED")

                if payload.get("event_type") == 'price_change':

                    # iterate through price change list.
                    pc_list: list = payload.get("price_changes", [])
                    timestamp = self._convert_timestamp_to_datetime(int(payload.get('timestamp', time.time() * 1000)))
                    changed_ids = set()
                    for pc in pc_list:
                        asset_id = pc.get("asset_id")
                        best_bid_px = float(pc.get("best_bid"))
                        best_ask_px = float(pc.get("best_ask"))
                        side = pc.get("side")
                        price = float(pc.get("price"))
                        size = float(pc.get('size', 0))

                        # only care if it is best_bid_px/best_ask_px
                        if price == best_bid_px:
                            changed_ids.add(asset_id)
                            bbos.get(asset_id, default)['best_bid'] = Level(price, size)
                        if price == best_ask_px:
                            changed_ids.add(asset_id)
                            bbos.get(asset_id, default)['best_ask'] = Level(price, size)

                    for asset_id in changed_ids:
                        outcome = self.clob_token_ids[asset_id]
                        best_bid = bbos.get(asset_id, default)['best_bid']
                        best_ask = bbos.get(asset_id, default)['best_ask']
                        spread = best_ask.price - best_bid.price
                        # Construct L1 Data
                        l1 = L1Data(
                            parent_event_id=self.parent_event_id,
                            ticker_id=self.ticker_id,
                            platform_id=PlatformId.POLY,
                            timestamp=timestamp,
                            best_bid=best_bid,
                            best_ask=best_ask,
                            outcome=Outcome(outcome),
                            metadata="",
                            spread=spread,
                        )
                        self.data_queue.put(l1)
                        print("L1 PLACED")
        except Exception as e:
            print(f"L2 THREAD FAILED: ERROR {e}")

    async def _stream_l2(self):
        """Consume full book snapshots (not implemented)."""
        self.start_market_ws_listener()
        try:
            orderbooks: dict[str, dict[str, dict[float, float]]] = {}
            default: dict[str, dict[float, float]] = {'bids': {0: 0}, 'asks': {1.0: 0}}
            while self.is_running:
                try:
                    payload = await asyncio.wait_for(self.ws_event_queues["l2"].get(), timeout=1.0)
                except asyncio.TimeoutError:
                    continue

                # if book, this is an OB snapshot so just pull the existing OB
                if payload.get("event_type") == "book":
                    # Extract Values
                    asset_id = payload.get("asset_id") or payload.get("market", "unknown")
                    bids = [Level(float(i['price']), float(i['size'])) for i in payload.get("bids", [Level(0, 0)])]
                    asks = [Level(float(i['price']), float(i['size'])) for i in payload.get("asks", [Level(1.0, 0)])]
                    bids = bids[::-1]  # reverse the polymarket order
                    asks = asks[::-1]
                    timestamp = self._convert_timestamp_to_datetime(int(payload.get('timestamp', time.time() * 1000)))
                    l2 = L2Data(
                        parent_event_id=self.parent_event_id,
                        ticker_id=self.ticker_id,
                        platform_id=PlatformId.POLY,
                        timestamp=timestamp,
                        bids=bids,
                        asks=asks,
                        outcome=Outcome(self.clob_token_ids[asset_id]),
                        metadata="",
                    )
                    self.data_queue.put(l2)

                    # update orderbooks
                    orderbooks[asset_id] = {'bids': {l.price: l.size for l in bids},
                                            'asks': {l.price: l.size for l in asks}}
                    print("L2 PLACED")

                if isinstance(payload, dict) and payload.get("event_type") == 'price_change':
                    # iterate through price change list.
                    pc_list: list = payload.get("price_changes", [])
                    timestamp = self._convert_timestamp_to_datetime(int(payload.get('timestamp', time.time() * 1000)))
                    changed_ids = set()
                    for pc in pc_list:
                        asset_id = pc.get("asset_id")
                        side = pc.get("side")
                        price = float(pc.get("price"))
                        size = float(pc.get('size', 0))
                        # only care if it is best_bid_px/best_ask_px
                        if side == "BUY":
                            changed_ids.add(asset_id)
                            orderbooks.get(asset_id, default)['bids'][price] = size
                        if side == "SELL":
                            changed_ids.add(asset_id)
                            orderbooks.get(asset_id, default)['asks'][price] = size

                    # Add Changed Asset IDS
                    for asset_id in changed_ids:
                        outcome = self.clob_token_ids[asset_id]
                        bids = sorted([Level(p, s) for p, s in orderbooks.get(asset_id, default)['bids'].items()],
                                      key=lambda x: x.price, reverse=True)
                        asks = sorted([Level(p, s) for p, s in orderbooks.get(asset_id, default)['asks'].items()],
                                      key=lambda x: x.price, reverse=False)
                        # Construct L1 Data
                        l2 = L2Data(
                            parent_event_id=self.parent_event_id,
                            ticker_id=self.ticker_id,
                            platform_id=PlatformId.POLY,
                            timestamp=timestamp,
                            bids=bids,
                            asks=asks,
                            outcome=Outcome(outcome),
                            metadata="",
                        )
                        self.data_queue.put(l2)
                        print("L2 PLACED")
        except Exception as e:
            print(f"L2 THREAD FAILED: ERROR {e}")

    async def _monitor_resolution(self):
        self.start_market_ws_listener()

        while self.is_running:
            try:
                try:
                    payload = self.ws_event_queues["resolution"].get_nowait()
                    event_type = payload.get("event_type")
                    if event_type == "market_resolved":
                        resolution_timestamp = self._convert_timestamp_to_datetime(
                            payload.get("timestamp", time.time() * 1000))
                        winning_outcome = payload.get("winning_outcome")
                        if winning_outcome:
                            self.ticker_info_object.end_timestamp = resolution_timestamp
                            self.ticker_info_object.outcome = Outcome(winning_outcome)
                            self.data_queue.put(self.ticker_info_object)
                            self.is_running = False
                            self.stop_market_ws_listener()
                            return
                except asyncio.QueueEmpty:
                    pass

                # 2. Backup: Poll REST API every 60 seconds
                if int(time.time()) % 60 == 0:
                    market = self.gamma.get_market_by_slug(self.ticker_id)
                    if market and market.get("closed"):
                        outcomes = json.loads(market["outcomes"])
                        prices = json.loads(market["outcomePrices"])
                        winner = None
                        for i, p in enumerate(prices):
                            if float(p) == 1.0:
                                winner = outcomes[i]
                                break

                        if winner:
                            print(f"[{self.ticker_id}] Resolution detected via Polling.")
                            self.ticker_info_object.outcome = Outcome(winner)
                            self.ticker_info_object.end_timestamp = datetime.now()  # Approximate
                            self.data_queue.put(self.ticker_info_object)
                            self.is_running = False
                            return

                await asyncio.sleep(1)  # Prevent busy loop

            except Exception as e:
                print(f"RESOLUTION MONITOR ERROR: {e}")
                await asyncio.sleep(5)


class DomeTradeWebSocket:
    """Connects to wss://ws.domeapi.io for rich trade data."""

    def __init__(self, api_key: str, market_slugs: List[str], message_callback: Callable, verbose=False):
        self.url = f"wss://ws.domeapi.io/{api_key}"
        self.market_slugs = market_slugs
        self.callback = message_callback
        self.verbose = verbose
        self.ws = None

    def on_open(self, ws):
        sub_msg = {
            "action": "subscribe",
            "events": ["trades"],
            "filters": {
                "market_slugs": self.market_slugs
            }
        }
        ws.send(json.dumps(sub_msg))

    def on_message(self, ws, message):
        data = json.loads(message)
        if data.get('event') == 'trade':
            self.callback(data['data'])

    def run(self):
        self.ws = WebSocketApp(
            self.url,
            on_open=self.on_open,
            on_message=self.on_message,
        )
        self.ws.run_forever(sslopt={"ca_certs": certifi.where()})


class CommentsRTDSWebSocket:
    """Connects to Polymarket RTDS for comments."""

    def __init__(self, parent_entity_id: int, message_callback: Callable, verbose=False):
        self.url = "wss://ws-subscriptions-rtds.polymarket.com"
        self.entity_id = parent_entity_id
        self.callback = message_callback
        self.verbose = verbose
        self.ws = None
        self._stop_event = threading.Event()

    def on_open(self, ws):
        sub_msg = {
            "assets_ids": [str(self.entity_id)],
            "type": "comments",
            "parentEntityID": self.entity_id,
            "parentEntityType": "Series"
        }
        ws.send(json.dumps(sub_msg))
        threading.Thread(target=self._ping, args=(ws,), daemon=True).start()

    def _ping(self, ws):
        while not self._stop_event.is_set():
            time.sleep(15)
            try:
                ws.send("PING")
            except:
                break

    def on_message(self, ws, message):
        data = json.loads(message)
        self.callback(data)

    def run(self):
        self.ws = WebSocketApp(
            self.url,
            on_open=self.on_open,
            on_message=self.on_message
        )
        self.ws.run_forever(sslopt={"ca_certs": certifi.where()})

    def stop(self):
        self._stop_event.set()
        if self.ws: self.ws.close()


class MarketWebSocket:
    def __init__(self, asset_ids, message_callback, url="wss://ws-subscriptions-clob.polymarket.com/ws/market",
                 ping_interval=10, verbose=False):
        self.asset_ids = asset_ids
        self.message_callback = message_callback
        self.url = url.rstrip("/")
        self.ping_interval = ping_interval
        self.verbose = verbose
        self._stop = threading.Event()

        self._connected = threading.Event()

        self.ws = WebSocketApp(f"{self.url}/ws/market", on_message=self.on_message, on_error=self.on_error,
                               on_close=self.on_close, on_open=self.on_open)

    def on_message(self, ws, message):
        if self.verbose: print(message)
        try:
            self.message_callback(json.loads(message))
        except:
            pass

    def on_error(self, ws, error):
        if self.verbose: print("Error:", error)

    def on_close(self, ws, close_status_code, close_msg):
        self._connected.clear()
        if self.verbose: print("Closed:", close_status_code, close_msg)

    def on_open(self, ws):
        self._connected.set()
        ws.send(json.dumps({"assets_ids": self.asset_ids, "type": "market"}))
        threading.Thread(target=self._ping, args=(ws,), daemon=True).start()

    def subscribe(self, asset_ids: list[str], channel: str):
        try:
            self.ws.send(json.dumps({"assets_ids": asset_ids, "type": channel}))
        except Exception as e:
            print(f"WS Subscribe Failed: {e}")

    def wait_for_connection(self, timeout=None):
        return self._connected.wait(timeout=timeout)

    def _ping(self, ws):
        while not self._stop.is_set():
            try:
                ws.send("PING")
                time.sleep(self.ping_interval)
            except WebSocketConnectionClosedException:
                pass

    def run(self):
        self.ws.run_forever(sslopt={"ca_certs": certifi.where()})

    def stop(self):
        self._stop.set()
        self.ws.close()


class GammaAPI:
    """Small wrapper for Polymarket Gamma API endpoints. Due to the Read-Only nature, it is public."""

    def __init__(self, api_url: str = "https://gamma-api.polymarket.com"):
        self.api_url = api_url.rstrip("/")

    def online(self):
        status = self._get("/status")
        if isinstance(status, dict):
            return status.get("status") == "OK" or status.get("message") == "OK"
        return str(status).strip() == "OK"

    def construct_full_url(self, endpoint: str) -> str:
        return f"{self.api_url}{endpoint}" if endpoint[0] == '/' else f"{self.api_url}/{endpoint}"

    def _get(self, endpoint: str, params: Optional[dict] = None) -> Any:
        """Shared GET wrapper with basic error handling."""
        resp = requests.get(self.construct_full_url(endpoint), params or {}, timeout=10)
        if resp.status_code != 200:
            return None

        try:
            return resp.json()
        except Exception:
            return resp.text

    def get_event_by_slug(self, slug: str, params: Optional[dict] = None) -> dict:
        """Fetch event by slug."""
        return self._get(f"/events/slug/{slug}", params or {})

    def get_market_by_slug(self, slug: str) -> dict:
        """Fetch market by slug."""
        return self._get(f"/markets/slug/{slug}")

    def get_event_by_id(self, id: str, params: Optional[dict] = None) -> dict:
        """Fetch event by id (Gamma id, not condition id)."""
        return self._get(f"/events/{id}", params or {})

    def get_market_by_id(self, id: str, params: Optional[dict] = None) -> dict:
        """Fetch market by id (Gamma id, not condition id)."""
        return self._get(f"/markets/{id}", params or {})