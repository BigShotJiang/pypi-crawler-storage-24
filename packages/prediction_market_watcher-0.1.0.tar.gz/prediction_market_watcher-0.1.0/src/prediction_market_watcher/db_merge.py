import sqlite3
import glob

if __name__ == "__main__":
    # Find all DB files
    for db_file in glob.glob("output/*.db"):
        print(f"Merging {db_file}...")
        conn = sqlite3.connect(db_file)

        # This forces SQLite to merge the .wal file into the .db file
        conn.execute("PRAGMA wal_checkpoint(TRUNCATE);")

        # Optional: Switch it back to normal mode (turns off WAL entirely)
        # conn.execute("PRAGMA journal_mode=DELETE;")

        conn.close()

    print("Done! You can now safely move just the .db files.")

