from dataclasses import dataclass
from datetime import datetime
from enum import Enum
from typing import List, Optional, Tuple

Outcome = str  # Yes, No, etc..


class Side(str, Enum):
    BUY = "BUY"
    SELL = "SELL"


class PlatformId(str, Enum):
    POLY = "Polymarket"
    KLSH = "Kalshi"


@dataclass
class Level:
    price: float
    size: float


# ParentEvent : e.g. Who will be the next President?
# Ticker: Child of a ParentEvent. e.g. Trump will be the next President. (Outcomes on this could be Yes/No)


@dataclass
class ParentEvent:
    slug: str
    id: str  # Primary Key
    name: str
    has_multiple_tickers: bool
    start_timestamp: datetime # TODO: remove, this concept doesn't exist for kalshi
    end_timestamp: datetime # TODO: remove, this concept doesn't exist for kalshi
    description: str
    platform: PlatformId
    metadata: str  # raw json output for debugging
    # TODO: add category?


@dataclass
class TradeData:
    trade_id: str
    parent_event_id: str  # maps as foreign key to ParentEvent
    ticker_id: str
    platform_id: PlatformId
    timestamp: datetime
    price: float
    size: float
    side: Optional[Side]
    outcome: Optional[Outcome]
    metadata: str = ""  # remove
    maker_address: Optional[str] = None
    taker_address: Optional[str] = None


@dataclass
class L1Data:
    parent_event_id: str
    ticker_id: str
    platform_id: PlatformId
    timestamp: datetime
    best_bid: Level
    best_ask: Level
    outcome: Optional[Outcome]  # outcome to indicated what outcome you are viewing the book from
    metadata: str # TODO: should be optional
    spread: float = 0.0


@dataclass
class L2Data:
    parent_event_id: str
    ticker_id: str
    platform_id: PlatformId
    timestamp: datetime
    bids: List[Level]
    asks: List[Level]
    outcome: Optional[Outcome]  # outcome to indicated what outcome you are viewing the book from
    metadata: str # TODO: should be optional


@dataclass(eq=True, unsafe_hash=True)
class ReactionData:
    reaction_id: str
    comment_id: str
    user_address: str
    reaction_type: str  # "like", "dislike"
    timestamp: datetime
    platform_id: PlatformId


@dataclass(eq=True, unsafe_hash=True)
class CommentData:
    comment_id: str
    parent_event_id: str
    ticker_id: Optional[str]
    platform_id: PlatformId
    timestamp: datetime
    user_id: str
    user_name: str
    text: str
    metadata: str
    outcome: Optional[Outcome]  # outcome to indicated what outcome the users position is in
    user_tags: str = "Unknown"  # e.g. "Minnow", "Whale"

    # Snapshot of the user's positions at the time of the comment (JSON string)
    user_position_snapshot: Optional[str] = None

    reply_to_id: Optional[str] = None


@dataclass
class TickerInfo:
    """
    Tracks the single info and resolution of the market.
    One row per market, inserted initially and upserted once when it closes.
    """
    parent_event_id: str
    ticker_id: str
    ticker_name: str
    platform_id: PlatformId
    outcome_options: Tuple[str, str]  # e.g. ("Yes", "No") or ("Trump", "Harris"), please capitalize
    start_timestamp: Optional[datetime]  # When ticker starts
    end_timestamp: Optional[datetime]  # When ticker has a resolution price
    description: str
    metadata: str  # should store alternative ids, like condition_id and market_id
    outcome: Optional[Outcome] = None  # None while active
