import os

REQUIRED_KEYS_FILE = "REQUIRED_KEYS.txt"

# key storage
_INTERNAL_CONFIG = {}

VERBOSE_LOGGING = False


def set_verbose(enabled: bool):
    global VERBOSE_LOGGING
    VERBOSE_LOGGING = enabled


def is_verbose():
    return VERBOSE_LOGGING


def _read_required_keys():
    if not os.path.exists(REQUIRED_KEYS_FILE):
        return []
    with open(REQUIRED_KEYS_FILE, 'r') as f:
        return [line.strip() for line in f if line.strip()]


def get_missing_keys():
    """Returns keys listed in text file but not yet in _INTERNAL_CONFIG."""
    required = _read_required_keys()
    # Check internal storage first
    return [k for k in required if k not in _INTERNAL_CONFIG]


def set_key(key: str, value: str):
    """Sets the key in our private dictionary."""
    _INTERNAL_CONFIG[key] = str(value)


def get_key(key: str):
    """Accessor for trackers to get their keys."""
    val = _INTERNAL_CONFIG.get(key)
    if not val:
        raise ValueError(f"Configuration Error: '{key}' was accessed but not set.")
    return val
