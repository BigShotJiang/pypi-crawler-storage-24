import threading
import time
import uuid
from dataclasses import dataclass
from typing import Dict, List, Optional
from .polymarket import PolymarketTracker
from .kalshi import KalshiTracker
from .market_interface import MarketInterface
from . import config
from .data_types import PlatformId
from .util import get_polymarket_events


class TrackerStatus:
    def __init__(self, id, ticker_name, platform, is_alive, parent_event_id, is_parent):
        self.id = id
        self.ticker_name = ticker_name
        self.platform = platform
        self.is_alive = is_alive
        self.parent_event_id = parent_event_id
        self.is_parent = is_parent

    def __repr__(self):
        return f"TrackerStatus(id='{self.id}', ticker='{self.ticker_name}', parent='{self.is_parent}', alive={self.is_alive})"


class _RealMarketHandler:
    """
    The fully constructed handler.
    Only accessible once all keys are set in config.py.
    """

    def __init__(self, db_name="market_data.db"):
        self.db_name = db_name
        self.trackers: Dict[str, threading.Thread] = {}
        self.interfaces: Dict[str, MarketInterface] = {}  # Keep ref to stop gracefully
        self.active_parents: Dict[str, str] = {}  # parent_event_id -> tracker_id

    def _create_tracker(self, platform: PlatformId, identifier: str, collect_l2: bool,
                        streams: Optional[List[str]] = None, category=None):
        if platform == PlatformId.POLY:
            return PolymarketTracker(identifier, self.db_name, collect_l2, active_streams=streams, category=category)
        elif platform == PlatformId.KLSH:
            return KalshiTracker(identifier, self.db_name, collect_l2, active_streams=streams, category=category)
        else:
            raise ValueError(f"Unknown platform: {platform}")

    def track(self, platform: PlatformId, identifier: str, collect_l2: bool = False,
              streams: Optional[List[str]] = None, category = None) -> List[str]:
        # Create a temporary probe to inspect the target
        probe = self._create_tracker(platform, identifier, collect_l2, streams=None, category=category)

        if not probe.verify():
            print(f"Verification failed for {identifier}")
            return []

        ids_started = []

        # CASE A: TARGET IS A PARENT EVENT
        if probe.is_parent_event():
            print(f"Detected Parent Market: {probe.parent_event_name}")
            parent_id = probe.parent_event_id

            # 1. Start Parent Tracker (Comments Only) if not exists
            if parent_id not in self.active_parents:
                print(f"   -> Spawning Parent Tracker (Comments/Meta) for {parent_id}")

                # Default Parent Streams: Comments, Resolution, Info
                parent_streams = ['comments', 'parent_info']
                if streams: parent_streams = streams

                p_tracker = self._create_tracker(platform, identifier, collect_l2=False, streams=parent_streams, category=category)
                pid = self._launch_thread(p_tracker, platform)
                self.active_parents[parent_id] = pid
                ids_started.append(pid)
            else:
                print(f"   -> Parent Tracker for {parent_id} already active.")

            # 2. Spawn Children (Data Only)
            children = probe.get_tickers_for_parent()
            print(f"   Found {len(children)} child tickers. Spawning data trackers...")

            for child_url in children:
                # Force Child Streams: Trades, L1, L2, Resolution. Comments EXCLUDED.
                child_streams = ['trades', 'l1', 'l2', 'resolution']
                child_ids = self.track(platform, child_url, collect_l2, streams=child_streams, category=category)
                ids_started.extend(child_ids)

            return ids_started

        # CASE B: TARGET IS A SINGLE TICKER (CHILD)
        else:
            # 1. Start the Child Tracker
            # Default Child Streams: Everything EXCEPT comments
            child_streams = ['trades', 'l1', 'resolution']
            if collect_l2: child_streams.append('l2')
            if streams: child_streams = streams

            print(f"   -> Spawning Child Tracker for {probe.ticker_name}")
            c_tracker = self._create_tracker(platform, identifier, collect_l2, streams=child_streams, category=category)
            c_tracker.set_parent_event(probe.parent_event_id, probe.parent_event_name)

            cid = self._launch_thread(c_tracker, platform)
            ids_started.append(cid)

            # 2. Implicit Parent Check
            # Ensure *someone* is tracking comments for this event.
            parent_id = probe.parent_event_id

            if parent_id not in self.active_parents:
                print(f"   [Implicit] Parent {parent_id} not tracked. Spawning Comment Tracker...")

                try:
                    parent_url = probe.get_parent_identifier()
                    parent_streams = ['comments', 'parent_info']

                    p_tracker = self._create_tracker(platform, parent_url, collect_l2=False, streams=parent_streams, category=category)
                    if p_tracker.verify():
                        pid = self._launch_thread(p_tracker, platform)
                        self.active_parents[parent_id] = pid
                        ids_started.append(pid)
                    else:
                        print(f"   [Warning] Could not verify implicit parent {parent_url}. Comments will be missed.")
                except Exception as e:
                    print(f"   [Error] Failed to spawn implicit parent: {e}")

            return ids_started

    def _launch_thread(self, tracker: MarketInterface, platform: PlatformId) -> str:
        tracker_id = str(uuid.uuid4())[:8]
        t = threading.Thread(target=tracker.run, name=f"{platform}-{tracker_id}")
        t.start()
        self.trackers[tracker_id] = t
        self.interfaces[tracker_id] = tracker
        return tracker_id

    def cleanup_trackers(self):
        """
        1. Removes trackers that have stopped running (resolved/crashed).
        2. Removes Parent trackers that have no active Children.
        """
        to_remove = []
        active_parent_ids = set()

        # Phase 1: Identify Active Children and Dead Trackers
        # [FIX] Iterate over INTERFACES, not TRACKERS (threads)
        for t_id, tracker in self.interfaces.items():
            thread = self.trackers.get(t_id)

            # Check if dead or resolved
            is_alive = thread and thread.is_alive()
            is_resolved = False

            # Only check resolution for Children (Parents don't have ticker_info usually)
            if not tracker.is_parent_event():
                is_resolved = tracker.is_ticker_resolved()

            if not is_alive or is_resolved:
                to_remove.append(t_id)
                status = "RESOLVED" if is_resolved else "DEAD"
                print(f"[{status}] Cleaning up {tracker.identifier}")

            # If it is a valid, running CHILD, record its parent_id
            elif not tracker.is_parent_event():
                active_parent_ids.add(tracker.parent_event_id)

        # Remove Phase 1 candidates
        for t_id in to_remove:
            self.stop_tracker(t_id)

        # Phase 2: Identify Orphaned Parents
        # A parent is orphaned if its ID is NOT in active_parent_ids
        to_remove_parents = []

        # [FIX] Iterate over INTERFACES again
        for t_id, tracker in self.interfaces.items():
            if tracker.is_parent_event():
                # We normalize IDs to strings for comparison just in case
                pid = str(tracker.parent_event_id)

                # Check if this Parent is needed by any active child
                # (We check if the parent ID exists in the set of active children's parents)
                if pid not in active_parent_ids:
                    print(f"[ORPHAN] Parent {tracker.identifier} has no active children. Cleaning up.")
                    to_remove_parents.append(t_id)

        # Remove Phase 2 candidates
        for t_id in to_remove_parents:
            self.stop_tracker(t_id)

    def stop_tracker(self, tracker_id: str):
        if tracker_id in self.interfaces:
            print(f"Stopping {tracker_id}...")
            # Signal the loop to stop
            self.interfaces[tracker_id].stop()
            # Wait for thread to finish
            if tracker_id in self.trackers:
                self.trackers[tracker_id].join(timeout=2.0)
                del self.trackers[tracker_id]

            del self.interfaces[tracker_id]

            # Remove from active_parents index if present
            # We need to find which parent_id mapped to this tracker_id
            parent_id_to_remove = None
            for pid, tid in self.active_parents.items():
                if tid == tracker_id:
                    parent_id_to_remove = pid
                    break
            if parent_id_to_remove:
                del self.active_parents[parent_id_to_remove]

            print(f"Tracker {tracker_id} stopped.")
        else:
            print("Tracker ID not found.")

    def list_trackers(self) -> List[TrackerStatus]:
        """Returns structured status of all active trackers."""
        results = []
        for tid, interface in self.interfaces.items():
            t = self.trackers.get(tid)
            platform_name = interface.__class__.__name__.replace("Tracker", "")

            status = TrackerStatus(
                id=tid,
                ticker_name=interface.identifier,
                platform=platform_name,
                is_alive=t.is_alive() if t else False,
                parent_event_id=interface.parent_event_id,
                is_parent=interface.is_parent_event()
            )
            results.append(status)
        return results


def MarketHandler(db_name="market_data.db"):
    """
    Factory Function (The Entry Point).
    Checks config state and returns either the Real Handler or a Builder Step.
    """
    missing = config.get_missing_keys()

    # If we have everything: return real one
    if not missing:
        return _RealMarketHandler(db_name)

    # Create a builder class for the NEXT missing key
    next_key = missing[0]
    method_name = f"provide{next_key}"

    def dynamic_provide(self, value: str):
        config.set_key(next_key, value)
        return MarketHandler(db_name=self._db_name)

    class_name = f"HandlerBuilder_Needs_{next_key}"  # Dynamic Class Name

    DynamicClass = type(
        class_name,
        (),
        {
            "__init__": lambda self: setattr(self, "_db_name", db_name),
            method_name: dynamic_provide,
            "__repr__": lambda self: f"<{class_name}: Call .{method_name}('value')>",
            "__dir__": lambda self: [method_name]
        }
    )

    return DynamicClass()


if __name__ == "__main__":
    config.set_verbose(False)
    handler = MarketHandler(db_name="test.db")
    print(handler)

    # Provide kalshi key
    handler = handler.provideKALSHI_API_KEY("KALSHI_API_KEY")
    print(handler)


    # Provide predexon key
    handler = handler.providePREDEXON_API_KEY("PREDEXON_API_KEY")
    print(handler)


    # Provide dome api key
    handler = handler.provideDOME_API_KEY("DOME_API_KEY")
    print(handler)

    # POLYMARKET -------
    # tracker_ids = handler.track(
    #     PlatformId.POLY,
    #     "https://polymarket.com/event/btc-updown-15m-1770578100",  # already closed
    #     True
    # )
    #

    # tracker_ids = handler.track(
    #     PlatformId.POLY,
    #     "https://polymarket.com/event/nflx-week-february-13-2026",  # running
    #     True
    # )

    # KALSHI -------
    # closed and determined market
    # tracker_ids = handler.track(
    #     PlatformId.KLSH,
    #     "https://kalshi.com/markets/kxnbagame/professional-basketball-game/kxnbagame-26feb09okclal-lal",
    #     True
    # )

    # active
    tracker_ids=handler.track(
        PlatformId.KLSH,
        "https://kalshi.com/KXBTC15M-26FEB212015-15",
        True
    )


    # keep main thread running
    try:
        while True:
            time.sleep(1)
            # print(handler.list_trackers())
    except KeyboardInterrupt:
        print("\nStopping...")
        for tid in tracker_ids:
            handler.stop_tracker(tid)
