import sqlite3
import requests
import pandas as pd
import time

# --- CONFIGURATION ---
DB_PATH = "output/Polymarket_Markets_15M.db"
# Native Polymarket Profile Endpoint
PROFILE_URL = "https://gamma-api.polymarket.com/public-profile"
HEADERS = {"Accept": "application/json", "Referer": "https://polymarket.com/"}


def get_unique_wallets_from_db():
    conn = sqlite3.connect(DB_PATH)
    query = """
    SELECT user_id FROM comments WHERE user_id IS NOT NULL AND user_id != 'Unknown'
    UNION SELECT user_address FROM reactions WHERE user_address IS NOT NULL AND user_address != 'Unknown'
    UNION SELECT maker_address FROM trades WHERE maker_address IS NOT NULL AND maker_address != 'Unknown'
    UNION SELECT taker_address FROM trades WHERE taker_address IS NOT NULL AND taker_address != 'Unknown'
    """
    wallets = [row[0] for row in conn.execute(query)]
    conn.close()
    return wallets


def fetch_creation_history(wallets):
    results = []
    session = requests.Session()
    session.headers.update(HEADERS)

    total = len(wallets)
    for i, addr in enumerate(wallets):
        try:
            # Single API call per wallet to the authoritative profile source
            r = session.get(PROFILE_URL, params={"address": addr}, timeout=5)

            if r.status_code == 200:
                data = r.json()
                results.append({
                    "address": addr,
                    "name": data.get("name") or data.get("pseudonym"),
                    "created_at": data.get("createdAt"),
                    "proxy": data.get("proxyWallet"),
                    "handle": data.get("handle")
                })
                print(f"[{i + 1}/{total}] Found: {results[-1]['name']} (Created: {results[-1]['created_at']})")
            else:
                print(f"[{i + 1}/{total}] Not found or Error: {addr} ({r.status_code})")

        except Exception as e:
            print(f"[{i + 1}/{total}] Exception for {addr}: {e}")

        # Rate limiting: Polymarket's Gamma API is public but has limits
        time.sleep(0.1)

    return results


if __name__ == "__main__":
    wallets = get_unique_wallets_from_db()
    if wallets:
        data = fetch_creation_history(wallets)
        df = pd.DataFrame(data)
        df.to_csv("wallet_creation_dates.csv", index=False)
        print(f"Success: Saved {len(df)} users to wallet_creation_dates.csv")