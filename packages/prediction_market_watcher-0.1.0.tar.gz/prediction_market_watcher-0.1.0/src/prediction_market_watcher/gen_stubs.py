import os

REQUIRED_KEYS_FILE = "REQUIRED_KEYS.txt"
OUTPUT_FILE = "handler.pyi"


def get_required_keys():
    if not os.path.exists(REQUIRED_KEYS_FILE):
        return []
    with open(REQUIRED_KEYS_FILE, 'r') as f:
        return [line.strip() for line in f if line.strip()]


def generate_stubs():
    keys = get_required_keys()

    if not keys:
        print("No keys found. No stubs generated.")
        return

    print(f"Generating stubs for keys: {keys}")

    with open(OUTPUT_FILE, "w") as f:
        # Imports
        f.write("#! THIS IS AN AUTO-GENERATED FILE TO AID IDE DISCOVERY. DO NOT MODIFY! Built by gen_stubs.py :)\n\n\n")

        f.write("from typing import List, Any\n")
        f.write("from market_interface import MarketInterface\n\n")

        f.write("class _RealMarketHandler:\n")
        f.write("    def track(self, platform: str, identifier: str, collect_l2: bool = False) -> List[str]: ...\n")
        f.write("    def stop_tracker(self, tracker_id: str) -> None: ...\n")
        f.write("    def list_trackers(self) -> Any: ...\n\n")

        next_return_type = "_RealMarketHandler"

        reversed_keys = list(reversed(keys))

        for i, key in enumerate(reversed_keys):
            class_name = f"_BuilderStep_{key}"
            method_name = f"provide{key}"

            f.write(f"class {class_name}:\n")
            f.write(f"    def {method_name}(self, value: str) -> '{next_return_type}': ...\n\n")

            next_return_type = class_name

        first_builder_name = next_return_type
        f.write(f"def MarketHandler(db_name: str = ...) -> {first_builder_name}: ...\n")

    print(f"!!!!!! Generated {OUTPUT_FILE}")
    print("Restart your IDE or Pylance server to see changes.")


if __name__ == "__main__":
    generate_stubs()
