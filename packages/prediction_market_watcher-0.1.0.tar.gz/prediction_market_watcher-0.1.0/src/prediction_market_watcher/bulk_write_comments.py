import time
import requests
import json
from typing import List, Any

from .db import LocalSQLiteClient
from .data_types import CommentData, ReactionData, PlatformId
from dataclasses import asdict
from .util import convert_iso_zulu_to_datetime

BASE_URL = "https://gamma-api.polymarket.com"


db = LocalSQLiteClient("Polymarket_Markets_MentionMarkets.db")

def write_comment_to_db(comment: CommentData) -> bool:
    return db.insert_batch("comments", [asdict(comment)])

def write_reaction_to_db(reaction: ReactionData) -> bool:
    return db.insert_batch("reactions", [asdict(reaction)])

def _parse_comment_payload(c: dict, event_slug) -> List[Any]:

    positions_snap = c.get('profile', {}).get('positions', [])

    raw_ts = c.get('createdAt')

    comment_ts = convert_iso_zulu_to_datetime(raw_ts)

    comment = CommentData(
        comment_id=str(c['id']),
        parent_event_id=event_slug,
        ticker_id=None,
        platform_id=PlatformId.POLY,
        timestamp=comment_ts,
        user_id=c.get('profile', {}).get('proxyWallet') or "Unknown",
        user_name=c.get('profile', {}).get('name', 'Anonymous'),
        text=c.get('body', ''),
        reply_to_id=str(c.get('parentCommentID')) if c.get('parentCommentID') else None,
        user_position_snapshot=json.dumps(positions_snap),
        outcome=None,
        metadata=json.dumps({'deleted': False}) #! Not Used
    )

    reactions = []
    for r in c.get('reactions', []):
        reaction_ts = comment_ts
        rd = ReactionData(
            reaction_id=str(r['id']),
            comment_id=str(c['id']),
            user_address=r.get('profile', {}).get('proxyWallet') or r.get('profile', {}).get('baseAddress'),
            reaction_type=r.get('reactionType', 'like'),
            timestamp=reaction_ts,
            platform_id=PlatformId.POLY
        )
        reactions.append(rd)
    
    return comment, reactions

def get_event_info(slug: str) -> dict:
    url = f"{BASE_URL}/events/slug/{slug}"
    response = requests.get(url)

    response.raise_for_status()

    return response.json()

def save_comments_for_event(event_slug: str, event_num):
    event_info = get_event_info(event_slug)
    event_id = event_info["id"]

    all_comments = set()
    all_reactions = set()


    early_break = False # controls if there are no comments on first try, no need to try different limits

    for limit in [5, 10, 15, 30, 60, 100, 150, 200]:
        if early_break:
            break

        offset = 0
        while True:
            params = {
                "offset": offset,
                "parent_entity_type": "Event",
                "parent_entity_id": event_id,
                "get_positions": True,
            }
            if limit is not None:
                params["limit"] = limit

            response = requests.get(f"{BASE_URL}/comments", params=params)
            response.raise_for_status()

            data = response.json()

            if not data:
                if offset == 0:
                    early_break = True
                break

            for i, comment in enumerate(data):
                comment, reactions = _parse_comment_payload(comment, event_slug)

                all_comments.add(comment)
                for reaction in reactions:
                    all_reactions.add(reaction)


            if len(data) < limit:
                break

            offset += len(data)
            time.sleep(0.2)
    
    print(f"Event {event_num} ({event_slug}): collected {len(all_comments)} comments and {len(all_reactions)} reactions.")

    for comment in all_comments:
        write_comment_to_db(comment)
    
    for reaction in all_reactions:
        write_reaction_to_db(reaction)
    

if __name__ == "__main__":
    # save_comments_for_event("what-will-melania-say-during-ai-talk-on-january-16", 1)

    filename = "../research/Polymarket_Markets_MentionMarkets.json"
    event_slugs = set()

    base_name = filename.split("/")[-1].replace(".json", "")

    platform_name = base_name.split("_Markets")[0]

    with open(filename, "r") as f:
        data = json.load(f)

        for event in data["parent_events"]:
            all_mkts_finalized = True

            for mkt in event["markets"]:
                if platform_name == "Kalshi" and (not mkt["result"] or mkt["status"] == "active"):
                    all_mkts_finalized = False
                    break
                if platform_name == "Polymarket" and (not mkt["closed"] or not mkt["outcomePrices"] or (
                        "0" not in mkt["outcomePrices"] or "1" not in mkt["outcomePrices"])):
                    all_mkts_finalized = False
                    break

            if all_mkts_finalized:
                event_slugs.add(event["slug"])
    
    print(f"Collecting comments for {len(event_slugs)} mention market events on Polymarket")
    for i, event_slug in enumerate(event_slugs):
        save_comments_for_event(event_slug, i+1)