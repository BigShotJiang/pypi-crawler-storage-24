import time
import datetime
import sys
import os
import platform
import traceback
import itertools
from typing import List, Set, Dict
import json

from .db import AsyncSQLiteClient
from .handler import MarketHandler
from .data_types import PlatformId
from . import config

if platform.system() == 'Windows':
    try:
        import ctypes
        ctypes.cdll.msvcrt._setmaxstdio(2048)
        print("Windows file descriptor limit increased to 2048.")
    except Exception as e:
        print(f"Failed to increase file limit: {e}")

HANDLER_THREAD_LIMIT = 100
OUTPUT_DIR = "output"
COMPLETED_LOG_FILE = os.path.join(OUTPUT_DIR, "completed_markets.json")

class DualLogger:
    def __init__(self):
        self.terminal = sys.stdout
        self.log_dir = "logs"
        os.makedirs(self.log_dir, exist_ok=True)
        self.date_str = datetime.datetime.now().strftime("%Y-%m-%d")
        self.file_path = os.path.join(self.log_dir, f"{self.date_str}.log")
        self.log_file = open(self.file_path, "a", encoding="utf-8")

    def write(self, message):
        self.terminal.write(message)
        self.log_file.write(message)
        self.log_file.flush()

    def flush(self):
        self.terminal.flush()
        self.log_file.flush()


def handle_exception(exc_type, exc_value, exc_traceback):
    if issubclass(exc_type, KeyboardInterrupt):
        sys.__excepthook__(exc_type, exc_value, exc_traceback)
        return
    print("\n[CRITICAL ERROR] Unhandled Exception Detected:")
    traceback.print_exception(exc_type, exc_value, exc_traceback)

def load_completed_markets() -> Set[str]:
    """Loads the set of completed URLs from disk."""
    if not os.path.exists(COMPLETED_LOG_FILE):
        return set()
    try:
        with open(COMPLETED_LOG_FILE, "r") as f:
            data = json.load(f)
            return set(data)
    except Exception as e:
        print(f"Error loading completed log: {e}")
        return set()

def save_completed_market(url: str):
    """Appends a single completed URL to the file."""
    current = load_completed_markets()
    if url not in current:
        current.add(url)
        try:
            with open(COMPLETED_LOG_FILE, "w") as f:
                json.dump(list(current), f, indent=2)
        except Exception as e:
            print(f"Error saving completion log: {e}")

def get_handler_backlog(handler: MarketHandler) -> int:
    total = 0
    for interface in list(handler.interfaces.values()):
        if hasattr(interface, 'data_queue'):
            total += interface.data_queue.qsize()
    return total


def cleanup_all(handlers: List[MarketHandler]):
    for h in handlers:
        try:
            h.cleanup_trackers()
        except Exception as e:
            print(f"Error cleaning up handler {h.db_name}: {e}")


def stop_all(handlers: List[MarketHandler]):
    print("\n[Shutdown] Stopping all handlers...")
    for h in handlers:
        active_ids = list(h.trackers.keys())
        for tid in active_ids:
            h.stop_tracker(tid)

    print("[Shutdown] Flushing database writers...")
    AsyncSQLiteClient.stop_all()

    print("Done.")


if __name__ == "__main__":
    sys.stdout = DualLogger()
    sys.stderr = sys.stdout
    sys.excepthook = handle_exception

    config.set_verbose(False)

    print(f"[{datetime.datetime.now()}] Setting up Global API Keys...")

    _setup = MarketHandler(db_name="setup_temp.db")

    if hasattr(_setup, "provideKALSHI_API_KEY"):
        _setup = _setup.provideKALSHI_API_KEY("c015ccd8-85c6-460a-bd76-69064bc53e6e")

    if hasattr(_setup, "providePREDEXON_API_KEY"):
        _setup = _setup.providePREDEXON_API_KEY("Qi1uLwDuYzxUnRO0VaLIkKznPFQ46V9FXsurjP50")

    if hasattr(_setup, "provideDOME_API_KEY"):
        _setup = _setup.provideDOME_API_KEY("ea8e97578f081f779fa21af50fb9f1988651827a")

    print("API Keys Configured.")

    os.makedirs(OUTPUT_DIR, exist_ok=True)

    completed_urls = load_completed_markets()
    print(f"Loaded {len(completed_urls)} previously completed markets.")

    attempted_identifiers: Set[str] = set()
    attempted_identifiers.update(completed_urls)

    filenames = [
       # "../research/Kalshi_Markets_Sports.json",
       # "../research/Kalshi_Markets_Finance.json",
        "../research/Polymarket_Markets_15M.json",
       # "../research/Polymarket_Markets_Daily.json",
       # "../research/Polymarket_Markets_NBA.json",
       # "../research/Polymarket_Markets_Olympics.json"
      #"../research/Polymarket_Markets_MentionMarkets.json",
    ]

    all_file_groups = []
    active_handlers: List[MarketHandler] = []

    # We maintain a set of ALL valid target URLs to ensure we don't save
    # random internal child tickers to the completed list.
    all_target_urls: Set[str] = set()

    print("Loading markets and creating sharded handlers...")

    for filename in filenames:
        try:
            base_name = filename.split("/")[-1].replace(".json", "")
            db_name = os.path.join(OUTPUT_DIR, f"{base_name}.db")

            h = MarketHandler(db_name=db_name)
            active_handlers.append(h)

            current_file_tasks = []
            platform_name = base_name.split("_Markets")[0]

            with open(filename, "r") as f:
                data = json.load(f)

                for event in data["parent_events"][750:]:
                    all_mkts_finalized = True

                    for mkt in event["markets"]:
                        if platform_name == "Kalshi" and (not mkt["result"] or mkt["status"] == "active"):
                            all_mkts_finalized = False
                            break
                        if platform_name == "Polymarket" and (not mkt["closed"] or not mkt["outcomePrices"] or (
                                "0" not in mkt["outcomePrices"] or "1" not in mkt["outcomePrices"])):
                            all_mkts_finalized = False
                            break

                    if all_mkts_finalized:
                        url = event["url"]
                        tag = event["associated_tags"][0]
                        p_enum = PlatformId.KLSH if platform_name == "Kalshi" else PlatformId.POLY

                        all_target_urls.add(url)  # Register valid target

                        if url not in completed_urls:
                            current_file_tasks.append((h, p_enum, url, tag))

            short_db = db_name.split("/")[-1]
            print(f"   -> [{short_db}] Loaded {len(current_file_tasks)} tasks.")
            all_file_groups.append(current_file_tasks)

        except Exception as e:
            print(f"   [Error] Failed to process {filename}: {e}")

    execution_queue = []
    for items in itertools.zip_longest(*all_file_groups):
        for item in items:
            if item is not None:
                execution_queue.append(item)

    print(f"Total Markets Laced & Ready: {len(execution_queue)}")

    # --- OBSERVER STATE ---
    # Tracks when we first saw a URL running: { "url": timestamp }
    tracker_start_times: Dict[str, float] = {}
    # --- DEBUG START ---
    debug_printed_tracker_format = False
    if len(all_target_urls) > 0:
        sample_target = list(all_target_urls)[0]
        print(f"\n[DEBUG] Sample TARGET URL (from JSON): '{sample_target}'")
        print(f"[DEBUG] Total Targets Loaded: {len(all_target_urls)}\n")
    # -------------------
    # --- MAIN LOOP ---
    try:
        while True:
            try:
                now = time.time()

                # ---------------------------------------------------------
                # 1. SPAWN NEW TRACKERS
                # ---------------------------------------------------------
                for handler_ref, platform, url, category in execution_queue:
                    if url in attempted_identifiers:
                        continue

                    if len(handler_ref.trackers) >= HANDLER_THREAD_LIMIT:
                        continue

                    backlog = get_handler_backlog(handler_ref)
                    if backlog > 50:
                        continue

                    short_db = handler_ref.db_name.split("/")[-1]
                    print(
                        f"[{datetime.datetime.now().strftime('%H:%M:%S')}] Spawning {platform.name} -> {short_db}: {url.split('/')[-1]}")

                    try:
                        handler_ref.track(platform, url, True, category=category)
                        attempted_identifiers.add(url)
                        time.sleep(0.1)
                    except Exception as e:
                        print(f"   Error spawning: {e}")

                # ---------------------------------------------------------
                # 2. CLEANUP (Remove dead threads from memory)
                # ---------------------------------------------------------
                cleanup_all(active_handlers)

                # ---------------------------------------------------------
                # 3. OBSERVER LOGIC (Parents Only)
                # ---------------------------------------------------------

                # Snapshot current trackers
                currently_active_ids = set()
                for h in active_handlers:
                    for iface in h.interfaces.values():
                        # We use the identifier (URL)
                        currently_active_ids.add(iface.identifier)

                # A. Register New Arrivals
                for url in currently_active_ids:
                    if url not in tracker_start_times:
                        tracker_start_times[url] = now

                # B. Detect Departures
                active_keys = list(tracker_start_times.keys())
                completed_count_this_loop = 0

                for url in active_keys:
                    if url not in currently_active_ids:
                        # Tracker is gone. How long did it run?
                        duration = now - tracker_start_times[url]

                        # Only mark as complete if it ran for >10 seconds
                        if duration > 10.0:
                            # --- CRITICAL FIX: ID-Based Matching ---
                            # 1. Extract the ID from the tracker URL
                            #    e.g. "https://kalshi.com/markets/KX-123" -> "KX-123"
                            tracker_id = url.rstrip('/').split('/')[-1]

                            # 2. Check if this ID exists in our Target JSON list
                            #    We loop through targets to find the matching Parent URL
                            found_match = False

                            # Optimization: Check exact match first
                            if url in all_target_urls:
                                save_completed_market(url)
                                found_match = True
                            else:
                                # Scan targets for ID match
                                # (This handles the event/ vs markets/ mismatch)
                                for target in all_target_urls:
                                    target_id = target.rstrip('/').split('/')[-1]

                                    if target_id == tracker_id:
                                        save_completed_market(target)  # Save the TARGET URL (from JSON)
                                        found_match = True
                                        # print(f"   [Matched] Tracker {tracker_id} -> Target {target}")
                                        break

                            if found_match:
                                completed_count_this_loop += 1
                            # else:
                            # If no match, it was likely a Child Tracker (outcome) finishing.
                            # We simply ignore it, as we only track Parents in the JSON.
                            # print(f"   [Ignored Child] {tracker_id}")

                        # Stop tracking it
                        del tracker_start_times[url]

                if completed_count_this_loop > 0:
                    print(
                        f"[{datetime.datetime.now().strftime('%H:%M:%S')}] Saved {completed_count_this_loop} completed markets.")

                # ---------------------------------------------------------
                # 4. REPORT STATUS
                # ---------------------------------------------------------
                status_strs = []
                for h in active_handlers:
                    short_name = h.db_name.split("/")[-1]
                    short_name = short_name.replace("Kalshi_Markets_", "K_").replace("Polymarket_Markets_",
                                                                                     "P_").replace(".db", "")
                    status_strs.append(f"{short_name}: {len(h.trackers)}")

                # --- NEW: Progress Calculation ---
                total_targets = len(all_target_urls)
                progress_pct = 0.0
                if total_targets > 0:
                    # attempted_identifiers contains both completed URLs and currently active URLs
                    progress_pct = (len(attempted_identifiers) / total_targets) * 100

                progress_str = f"Progress: {progress_pct:.2f}% ({len(attempted_identifiers)}/{total_targets})"
                # ---------------------------------

                print(f"[{datetime.datetime.now().strftime('%H:%M:%S')}] Active: " + " | ".join(
                    status_strs) + f" | {progress_str}")

                time.sleep(60)

            except Exception as main_loop_error:
                print(f"\n[CRITICAL WARNING] Main Loop Crashed! Restarting loop in 10s...")
                print(f"Error details: {main_loop_error}")
                traceback.print_exc()
                time.sleep(10)

    except KeyboardInterrupt:
        stop_all(active_handlers)