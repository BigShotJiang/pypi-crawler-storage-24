import traceback

from cryptography.hazmat.primitives import serialization
import requests
from tqdm import tqdm
import sys
from datetime import datetime, timezone
import time
import pandas as pd
import numpy as np
import asyncio
import json

from . import config
from .market_interface import MarketInterface
from .exceptions import *
from .kalshi_objects import KalshiHttpClient, KalshiWebSocketClient, Environment
from .data_types import (L1Data, L2Data, PlatformId, TickerInfo,
                        ParentEvent, Level, TradeData)
from .util import events_to_dfs, unix_ts_to_utc_dt, convert_iso_zulu_to_datetime
from dateutil.parser import isoparse


class KalshiTracker(MarketInterface):
    def __init__(
            self,
            identifier: str,
            db_name: str,
            collect_l2: bool = False,
            active_streams=None,
            category = None
    ) -> None:
        super().__init__(identifier, db_name, collect_l2, active_streams)
        # api key and production environment initialization
        try:
            self.api_key = config.get_key("KALSHI_API_KEY")
            self.env = Environment.PROD
            self.update = None
            self.ticker_info_object = None  # keeps track of market, updates on market updates
            self.parent_event_data = None
            self.category = category
            self.ticker_info_data = None
        except Exception as e:
            print(f"unable to get KALSHI_API_KEY, "
                  f"error: {e}, terminating kalshi tracker")
            sys.exit(1)

        # reading predexon API key if provided
        try:
            self.predexon_api_key = config.get_key("PREDEXON_API_KEY")
        except:
            print(f"predexon API key not provided, "
                  f"only real time order book recorded")
            self.predexon_api_key = None

        # reading predexon API key if provided
        try:
            # reading private api key
            with open("kalshi_private_key.pem", "rb") as f:
                self.private_key = serialization.load_pem_private_key(
                    f.read(),
                    password=None
                )

            # initializing kalshi https client
            self.http_client = KalshiHttpClient(
                key_id=self.api_key,
                private_key=self.private_key,
                environment=self.env
            )

            self.l2_client = None
            self.l1_client = None
            self.trades_client = None
            self.market_updates_client = None

            if 'l2' in self.active_streams:
                self.l2_client = KalshiWebSocketClient(
                    key_id=self.api_key,
                    parent=self,
                    private_key=self.private_key,
                    environment=self.env,
                    l2=True
                )

            if 'l1' in self.active_streams:
                self.l1_client = KalshiWebSocketClient(
                    key_id=self.api_key,
                    parent=self,
                    private_key=self.private_key,
                    environment=self.env,
                    l1=True
                )

            if 'trades' in self.active_streams:
                self.trades_client = KalshiWebSocketClient(
                    key_id=self.api_key,
                    parent=self,
                    private_key=self.private_key,
                    environment=self.env,
                    get_trades=True
                )

            if 'resolution' in self.active_streams:
                self.market_updates_client = KalshiWebSocketClient(
                    key_id=self.api_key,
                    parent=self,
                    private_key=self.private_key,
                    environment=self.env,
                    get_market_updates=True
                )

        except Exception as e:
            print(f"kalshi private key not found, "
                  f"error {e}, terminating kalshi tracker")
            sys.exit(1)

        return

    def uppercase_letters_only(
            self,
            s: str
    ) -> str:
        """
        Returns the upper case of a letter (except for special characters and numbers)
        """
        return "".join(c.upper() if c.isalpha() else c for c in s)

    def get_parent_identifier(self) -> str:
        """Returns the URL for the parent event."""
        if self.is_parent:
            return self.identifier

        if self.parent_event_id:
            return f"https://kalshi.com/markets/{self.parent_event_id}"

        raise ValueError("Parent Event ID not available yet. Call verify() first.")

    def verify(self) -> bool:
        """
        Check if the URL is valid. If it is, query Kalshi to determine if it is a single market
        or an event containing multiple markets. Handles 401s gracefully with fallback data.
        """
        if "kalshi.com/" not in self.identifier:
            print(f"https://kalshi.com/ not present in the URL at all please check")
            return False

        try:
            self.event_ticker = self.uppercase_letters_only(self.identifier.split("/")[-1])
        except Exception as e:
            print(f"error while providing kalshi URL: {e}, please enter valid URL")
            return False

        # 1. Check if the ticker is a specific MARKET TICKER (Child)
        try:
            children = self.http_client.get_markets(tickers=self.event_ticker)
            if not children.empty and children.shape[0] == 1:
                # It is a specific market
                self.is_parent = False
                self.parent_event_id = children.iloc[0]["event_ticker"]
                self.ticker_info_data = children

                try:
                    self.parent_event_data = self.http_client.get_event(self.parent_event_id)
                except Exception as e:
                    print(
                        f"Warning: Failed to fetch event data for {self.parent_event_id} (Likely a 15m restricted endpoint): {e}")
                    # Mock parent event to prevent downstream KeyError
                    self.parent_event_data = {
                        "event": {
                            "event_ticker": self.parent_event_id,
                            "title": children.iloc[0].get("title", self.parent_event_id),
                        },
                        "markets": [children.iloc[0].to_dict()]
                    }

                self.ticker_id = self.event_ticker
                self.ticker_name = children.iloc[0]["title"]
                print(f"market_ticker {self.event_ticker} found, spawning tracker")
                return True
        except Exception:
            pass  # Fall through to event check

        # 2. Check if the ticker is an EVENT TICKER (Parent)
        try:
            children = self.http_client.get_markets(event_ticker=self.event_ticker)
            if not children.empty:
                # It is an event containing multiple markets
                self.is_parent = True
                self.parent_event_id = self.event_ticker
                self.parent_event_name = self.event_ticker
                self.child_data = [f"https://kalshi.com/{i}" for i in children["ticker"].unique().tolist()]
                self.ticker_info_data = children

                try:
                    self.parent_event_data = self.http_client.get_event(self.event_ticker)
                except Exception as e:
                    print(
                        f"Warning: Failed to fetch event data for {self.event_ticker} (Likely a 15m restricted endpoint): {e}")
                    # Mock parent event to prevent downstream KeyError
                    self.parent_event_data = {
                        "event": {
                            "event_ticker": self.event_ticker,
                            "title": self.event_ticker,
                        },
                        "markets": children.to_dict('records')
                    }

                print(f"passed URL is event_ticker: {self.event_ticker}, spawning children: {self.child_data}")
                return True
        except Exception as e:
            print(f"Failed to fetch as event: {e}")

        # 3. Handle Fallback / Invalid cases
        if self.event_ticker.count("-") == 0:
            print("passed URL seems to be a series_ticker, please pass an event_ticker or market_ticker")
            return False

        print(f"ticker {self.event_ticker} cannot be found, please try another")
        return False

    def is_parent_event(
            self
    ) -> bool:
        return self.is_parent

    def get_tickers_for_parent(
            self
    ) -> list[str]:
        return self.child_data

    def get_ticker_details_update(self) -> None:
        """
        Fetch most recent update for select ticker from Kalshi
        """
        self.update = self.http_client.get_markets(
            tickers=self.ticker_id
        )
        return

    def is_ticker_actively_trading(self) -> bool:
        """
        Check if the select market ticker is actually open or not
        """
        # get the market data
        self.get_ticker_details_update()

        # if the current time is between open and close time, return True
        now = datetime.now(timezone.utc)
        open_time = pd.to_datetime(self.update.iloc[0]["open_time"], utc=True)
        close_time = pd.to_datetime(self.update.iloc[0]["close_time"], utc=True)
        return (open_time <= now) and (now <= close_time)

    def is_ticker_done_trading(self) -> bool:
        """
        Check if the selected market ticker is resolved or not
        """
        # get the market data
        self.get_ticker_details_update()
        return datetime.now(timezone.utc) > convert_iso_zulu_to_datetime(self.update.iloc[0]["close_time"])

    def is_ticker_resolved(self) -> bool:
        self.get_ticker_details_update()
        return bool(self.update.iloc[0]["result"]) # result can be yes, no, scalar, or ""/None


    def add_ticker_info(self) -> None:
        """
        Get the latest ticker info and save into the data queue
        """
        # run ticker details update
        if self.is_parent_event():
            return

        self.get_ticker_details_update()

        # get all market information required
        outcome = self.update.iloc[0]["result"].capitalize()
        is_resolved = bool(outcome)
        parent_event_id = self.parent_event_id
        ticker_id = self.ticker_id
        ticker_name = self.ticker_name
        platform_id = PlatformId.KLSH
        outcome_options = ("Yes", "No") # NOTE: yes_sub_title and no_sub_title is unreliable
        start_timestamp = isoparse(self.update.iloc[0]["open_time"])

        # in the response, there is no official time field for when the outcome is determined
        # our best effort is, if the market is already resolved, then we just use the close date (settlement_ts might not exist, and update_time is not reliable)
        # if the market isn't yet resolved, we just fill out the expected expiration time if it's available, else leave blank
        end_timestamp = None
        if is_resolved:
            # we use close_time, even if it's inaccurate, because we know that it will not be missing
            end_timestamp = isoparse(self.update.iloc[0]["close_time"])
        else:
            expiration_time = self.update.iloc[0].get("expected_expiration_time", None)
            if expiration_time is not None:
                end_timestamp = isoparse(expiration_time)
        # NOTE: for some markets (e.g. sports), on the website it'll say the market closes after a winner is declared,
        #    else, the close date is ____ date in the future (so there are cases where expected_expiration_time < close date)
        # so close date is also sometimes treated as a placeholder and not an accurate reflection of when the market will finish trading (it might be uncertain, e.g. going overtime)

        description = self.update.iloc[0]["rules_primary"]
        metadata = ""

        # add all information into the TickerInfo format
        ticker_info = TickerInfo(
            parent_event_id=parent_event_id,
            ticker_id=ticker_id,
            ticker_name=ticker_name,
            platform_id=platform_id,
            outcome_options=outcome_options,
            start_timestamp=start_timestamp,
            end_timestamp=end_timestamp,
            description=description,
            metadata=metadata,
            outcome=outcome
        )

        self.ticker_info_object = ticker_info

        # add TickerInfo into the data queue
        self.data_queue.put(ticker_info)

        return

    def add_parent_event(self) -> None:
        """
        Adding in parent data information associated with a market ticker
        """
        if not getattr(self, 'parent_event_data', None):
            return

        event = self.parent_event_data["event"]
        num_markets = len(self.parent_event_data["markets"])
        parent_event = ParentEvent(
            slug=event['event_ticker'],
            id=event['event_ticker'],  # only one unique identifier of event
            name=event['title'],
            has_multiple_tickers=(num_markets > 1),

            # TODO: remove start_ and end_ timestamps, these do not exist for kalshi events and the following timestamps are only "best guess"
            # that being said, markets under an event are not guaranteed to have the same open_time and close_time
            # and the following logic will set the parent's start and end times to be that of the last market processed
            start_timestamp=isoparse(self.ticker_info_data.iloc[0]["open_time"]),
            end_timestamp=isoparse(self.ticker_info_data.iloc[0]["close_time"]),

            description=event['title'],
            platform=PlatformId.KLSH,
            metadata="" if self.category is None else json.dumps({"category": self.category})
        )
        self.data_queue.put(parent_event)

    def _get_historical_trades_page(self, ticker_id: str, parent_event_id: str, pagination_key=None, page_num=None):
        url = "https://api.elections.kalshi.com/trade-api/v2/markets/trades"

        params = {"limit": 1000, "ticker": ticker_id}

        if pagination_key is not None:
            params["cursor"] = pagination_key

        resp = requests.get(url, params=params)

        all_trades = []
        new_pagination_key = None

        if resp.ok:
            data = resp.json()
            trades = data['trades']
            print((f"Page {page_num}: " if page_num is not None else "") + f"Fetched {len(trades)} historical trades for Kalshi market {ticker_id}")

            for i, trade in enumerate(trades):
                taker_side = trade["taker_side"]
                td = TradeData(trade_id=trade['trade_id'],
                               parent_event_id=parent_event_id,
                               ticker_id=trade["ticker"],
                               platform_id=PlatformId.KLSH,
                               timestamp= isoparse(trade['created_time']),
                               price=trade[f'{taker_side}_price'] / 100,  # account for subpennies
                               size=trade['count'],
                               outcome=taker_side.capitalize(),
                               side=None
                               )
                self.data_queue.put(td)
                all_trades.append(td)

            new_pagination_key = data.get("cursor", None)

        else:
            print("Error:", resp.status_code, resp.text)

        return all_trades, new_pagination_key

    def get_historical_trades(self, ticker_id: str, parent_event_id: str, pagination_key=None, debug_csv=False):
        print(f"Querying for Kalshi historical trades for market {ticker_id} at {datetime.now()} PST")
        i = 1

        all_trades, pagination_key = self._get_historical_trades_page(ticker_id, parent_event_id, page_num=i)
        last_trades = all_trades

        if debug_csv:
            events_to_dfs(all_trades).trades.to_csv(f"kalshi_trades{i}.csv", index=False)

        while pagination_key:
            i += 1
            time.sleep(1)  # to avoid rate limit, but we can also get the dev tier for dome

            last_trades, pagination_key = self._get_historical_trades_page(ticker_id, parent_event_id, pagination_key,
                                                                           page_num=i)

            if debug_csv:
                if i < 4:
                    events_to_dfs(last_trades).trades.to_csv(f"kalshi_trades{i}.csv", index=False)
        if debug_csv:
            events_to_dfs(last_trades).trades.to_csv(f"kalshi_trades{i}.csv", index=False)

    def backfill_all(self) -> None:
        """
        Backfilling all the data required before live streaming
        """
        if not self.is_parent_event():
            if 'trades' in self.active_streams:
                # backfill trades
                self.get_historical_trades(self.ticker_id, self.parent_event_id)

            if 'l1' in self.active_streams or 'l2' in self.active_streams:
                df = self.get_historical_order_book()

                if 'l2' in self.active_streams:
                    if self.collect_l2:
                        # backfill l2 order book data from predexon
                        print("backfilling l2 data")
                        self.backfill_l2(
                            df=df
                        )

                if 'l1' in self.active_streams:
                    # backfilling l1 order book data from predexon
                    print("backfilling l1 data")
                    self.backfill_l1(df=df)

        return

    def backfill_l2(
            self,
            df: pd.DataFrame
    ) -> None:
        """
        Backfilling level 2 order book data using the predexon API output dataframe
        """
        # iterating over each row in the predexon dataframe
        for index, row in tqdm(df.iterrows(), total=len(df), desc="pushing historical l2 to queue"):
            # adding rows and adding to database queue
            self._publish_backfill_orderbook_snapshot(
                orderbook=row,
                l2_mode=True,
                l1_mode=False
            )
        return

    def backfill_l1(
            self,
            df: pd.DataFrame
    ) -> None:
        """
        Backfilling level 1 order book data using the predexon API output dataframe
        """
        # iterating over each row in the predexon dataframe
        for index, row in tqdm(df.iterrows(), total=len(df), desc="pushing historical l1 to queue"):
            # adding rows and adding to database queue
            self._publish_backfill_orderbook_snapshot(
                orderbook=row,
                l2_mode=False,
                l1_mode=True
            )
        return

    def get_historical_order_book(
            self,
            limit: int = 200
    ) -> pd.DataFrame:
        """
        Make predexon request for historical order book data
        """

        # if predexon API key not provided, return early
        if not self.predexon_api_key:
            print("no predexon  api key provided, cannot backfill "
                  "orderbook data or L1 data for Kalshi")
            return

        # base url
        url = f"https://api.predexon.com/v1/kalshi/orderbooks"

        # get the start and the current time in ms from child data
        start_time = int(pd.to_datetime(self.ticker_info_data.iloc[0]["open_time"], utc=True).timestamp() * 1000)
        end_time = int(pd.Timestamp.utcnow().timestamp() * 1000)

        # request parameters
        params = {
            "ticker": self.ticker_id,
            "start_time": start_time,
            "end_time": end_time,
            "limit": limit
        }

        # headers for request
        headers = {
            "x-api-key": self.predexon_api_key,
        }

        # compiling all the orderbook snapshots
        self.historical_orderbook = []
        page_num = 1

        # keep parsing requests paginations while there is more data present
        while True:
            # get response
            response = requests.get(
                url=url,
                params=params,
                headers=headers
            )
            data = response.json()

            # output dataframe
            self.historical_orderbook.extend(data["snapshots"])

            # pagination details
            response_len = data["pagination"]["count"]
            has_more = data["pagination"]["has_more"]
            pagination_key = data["pagination"]["pagination_key"]

            print((f"Page {page_num}: " if page_num is not None else "") + f"Fetched {response_len} snapshots of the order book for Kalshi market {self.ticker_id}")

            page_num += 1
            # proceed if more pagination cursors are present
            if has_more and pagination_key:
                # more data present, add pagination cursor in to the query params
                params["pagination_key"] = pagination_key
            else:
                break

        # dataframe viz
        df = pd.DataFrame(self.historical_orderbook)

        return df

    async def _stream_trades(self) -> None:
        while self.is_running and not sys.is_finalizing():
            try:
                print(f"[{self.ticker_id}] Connecting to Kalshi Trades Stream...")
                await self.trades_client.connect([self.ticker_id])
            except Exception as e:
                print(f"[{self.ticker_id}] Trades Stream disconnected: {e}")
                # Wait briefly before reconnecting
                traceback.print_exc()
                await asyncio.sleep(1)

    async def _stream_l1(
            self
    ) -> None:
        """
        Create Level 1 data from level 2 stream
        """
        while self.is_running and not sys.is_finalizing():
            try:
                print(f"[{self.ticker_id}] Connecting to Kalshi L1 Stream...")
                await self.l1_client.connect([self.ticker_id])
            except Exception as e:
                print(f"[{self.ticker_id}] L1 Stream disconnected: {e}")
                # Wait briefly before reconnecting
                traceback.print_exc()
                await asyncio.sleep(1)

    def _publish_backfill_orderbook_snapshot(
            self,
            orderbook: pd.Series,
            l2_mode: bool = True,
            l1_mode: bool = False,
            cent_convert: int = 100
    ) -> None:
        """
        Backfill the order book information and append into the queue
        """
        # convert dataframe into a dict
        orderbook = orderbook.to_dict()

        # convert internal dict {price: size} to List[Level] for Yes side
        yes_levels = [
            Level(price=round(level["price"] / cent_convert, 2), size=level["size"])
            for level in sorted(orderbook["yes_bids"], key=lambda x: x["price"], reverse=True)
        ]

        # convert no bid levels into yes ask levels by computing (1 - price) conversion
        no_levels = [
            Level(price=round(level["price"] / cent_convert, 2), size=level["size"])
            for level in sorted(orderbook["yes_asks"], key=lambda x: x["price"], reverse=False)
        ]

        # use the last delta time or current time if missing
        ts_ms = orderbook["timestamp"]

        # L2 data saving
        if l2_mode == True and l1_mode == False:
            # create L2 data object with Yes order book reference point
            data = L2Data(
                parent_event_id=orderbook.get("market_id", self.parent_event_id),
                ticker_id=orderbook.get("market_ticker", self.ticker_id),
                platform_id=PlatformId.KLSH,
                timestamp=datetime.fromtimestamp(ts_ms / 1000, tz=timezone.utc),
                bids=yes_levels,
                asks=no_levels,
                outcome="Yes",
                metadata=""
            )

        # L1 data saving
        elif l2_mode == False and l1_mode == True:

            # get best bid
            if not yes_levels:
                best_bid = Level(price=np.nan, size=np.nan)
            else:
                best_bid = yes_levels[0]

            # get best ask
            if not no_levels:
                best_ask = Level(price=np.nan, size=np.nan)
            else:
                best_ask = no_levels[0]

            # compute spread
            spread = round(best_ask.price - best_bid.price, 2)

            # create L1 data object with Yes order book reference point
            data = L1Data(
                parent_event_id=orderbook.get("market_id", self.parent_event_id),
                ticker_id=orderbook.get("market_ticker", self.ticker_id),
                platform_id=PlatformId.KLSH,
                timestamp=datetime.fromtimestamp(ts_ms / 1000, tz=timezone.utc),
                best_bid=best_bid,
                best_ask=best_ask,
                outcome="Yes",
                metadata="",
                spread=spread
            )

        else:
            print("snapshot must be L1 or L2 mode. not both or neither, please check")
            return

        # add to data queue
        self.data_queue.put(data)

        return

    def _publish_orderbook_snapshot(
            self,
            l2_mode: bool = True,
            l1_mode: bool = False
    ) -> None:
        """
        Helper: Converts internal orderbook state to L2Data and pushes to queue.
        Called whenever the orderbook changes (init or delta update).
        """
        if not hasattr(self, "orderbook") or not self.orderbook:
            return

        # create a deep copy of the orderbook
        orderbook = self.orderbook.copy()

        # convert internal dict {price: size} to List[Level] for Yes side
        try:
            yes_levels = [
                Level(price=price, size=size)
                for price, size in sorted(orderbook["yes"].items(), reverse=True)
            ]
        except:
            yes_levels = []

        # convert no bid levels into yes ask levels by computing (1 - price) conversion
        try:
            no_levels = [
                Level(price=round(1 - price, 2), size=size)
                for price, size in sorted(orderbook["no"].items(), reverse=True)
            ]
        except:
            no_levels = []

        # use the last delta time or current time if missing
        ts_ms = orderbook.get("last_delta_time_ms", orderbook.get("snapshot_time_ms", time.time() * 1000))

        # L2 data saving
        if l2_mode == True and l1_mode == False:
            # create L2 data object with Yes order book reference point
            data = L2Data(
                parent_event_id=orderbook.get("market_id", self.parent_event_id),
                ticker_id=orderbook.get("market_ticker", self.ticker_id),
                platform_id=PlatformId.KLSH,
                timestamp=datetime.fromtimestamp(ts_ms / 1000, tz=timezone.utc),
                bids=yes_levels,
                asks=no_levels,
                outcome="Yes",
                metadata=""
            )

        # L1 data saving
        elif l2_mode == False and l1_mode == True:

            # get best bid
            if not yes_levels:
                best_bid = Level(price=np.nan, size=np.nan)
            else:
                best_bid = yes_levels[0]

            # get best ask
            if not no_levels:
                best_ask = Level(price=np.nan, size=np.nan)
            else:
                best_ask = no_levels[0]

            # compute spread
            spread = round(best_ask.price - best_bid.price, 2)

            # create L1 data object with Yes order book reference point
            data = L1Data(
                parent_event_id=orderbook.get("market_id", self.parent_event_id),
                ticker_id=orderbook.get("market_ticker", self.ticker_id),
                platform_id=PlatformId.KLSH,
                timestamp=datetime.fromtimestamp(ts_ms / 1000, tz=timezone.utc),
                best_bid=best_bid,
                best_ask=best_ask,
                outcome="Yes",
                metadata="",
                spread=spread
            )

        else:
            print("snapshot must be L1 or L2 mode. not both or neither, please check")
            return

        # add to data queue
        self.data_queue.put(data)

        return

    def init_orderbook_from_snapshot(
            self,
            msg: dict,
            l1: bool = False,
            l2: bool = True
    ) -> None:
        """
        Initialize self.orderbook from an orderbook_snapshot message
        """
        self.orderbook = {"yes": {}, "no": {}}

        for price, size in msg.get("yes_dollars_fp", []):
            price = float(price)
            size = float(size)
            if size > 0:
                self.orderbook["yes"][price] = size

        for price, size in msg.get("no_dollars_fp", []):
            price = float(price)
            size = float(size)
            if size > 0:
                self.orderbook["no"][price] = size

        self.orderbook["snapshot_time_ms"] = int(time.time() * 1000)
        self.orderbook["market_ticker"] = msg["market_ticker"]
        self.orderbook["market_id"] = msg["market_id"]

        # publish changes into the queue
        self._publish_orderbook_snapshot(
            l2_mode=l2,
            l1_mode=l1
        )

        return

    def update_orderbook_with_delta(
            self,
            msg: dict,
            l1: bool = False,
            l2: bool = True
    ) -> None:
        """
        Update self.orderbook in-place using an orderbook_delta message
        """
        # if snapshot hasn't arrived yet, you can't apply deltas
        if not hasattr(self, "orderbook") or self.orderbook is None:
            return

        side = msg["side"]  # "yes" or "no"
        price = float(msg["price_dollars"])  # float dollars
        delta_fp = float(msg["delta_fp"])  # float fixed-point size delta

        current_size = self.orderbook[side].get(price, 0.0)
        new_size = current_size + delta_fp

        # if size hits 0 (or below), remove the level
        if new_size > 0:
            self.orderbook[side][price] = new_size
        else:
            self.orderbook[side].pop(price, None)

        self.orderbook["last_delta_time_ms"] = int(
            pd.to_datetime(msg["ts"], utc=True).timestamp() * 1000
        )

        # publish changes into the queue
        self._publish_orderbook_snapshot(
            l2_mode=l2,
            l1_mode=l1
        )

        return

    def process_market_update(self, update: dict):
        # print(f"Received '{update['event_type']}' market update for {update['market_ticker']}")
        if update["market_ticker"] == self.ticker_id and update["event_type"] == "determined":
            print(f"Processing market update: {update}")
            try:
                self.ticker_info_object.end_timestamp = unix_ts_to_utc_dt(update["determination_ts"])
                self.ticker_info_object.outcome = update["result"].capitalize()
            except Exception as e:
                raise LiveMarketUpdateError(f"Failed to process 'determined' market update for {update['market_ticker']}. Error = {e}")

            self.data_queue.put(self.ticker_info_object)

    def process_live_trade(self, trade: dict):
        taker_side = trade["taker_side"]
        td = TradeData(
            trade_id=trade['trade_id'],
            parent_event_id=self.parent_event_id,
            ticker_id=trade["market_ticker"],
            platform_id=PlatformId.KLSH,
            timestamp=unix_ts_to_utc_dt(trade['ts']),
            price=trade[f'{taker_side}_price'] / 100,  # account for subpennies
            size=trade['count'],
            outcome=taker_side.capitalize(),
            side=None
        )
        self.data_queue.put(td)

    async def _stream_l2(
            self
    ) -> None:
        """
        Streaming level 2 order book data
        """

        while self.is_running and not sys.is_finalizing():
            try:
                print(f"[{self.ticker_id}] Connecting to Kalshi L2 Stream...")
                await self.l2_client.connect([self.ticker_id])
            except Exception as e:
                print(f"[{self.ticker_id}] L2 Stream disconnected: {e}")
                # Wait briefly before reconnecting
                await asyncio.sleep(1)
        return

    async def _stream_comments(self) -> None:
        return

    async def _monitor_resolution(self) -> None:
        """
        Streaming market updates
        """

        while self.is_running and not sys.is_finalizing():
            try:
                print(f"[{self.ticker_id}] Connecting to Kalshi Market Updates Stream...")
                await self.market_updates_client.connect([self.ticker_id])
            except Exception as e:
                print(f"[{self.ticker_id}] Market Updates Stream disconnected: {e}")
                # Wait briefly before reconnecting
                await asyncio.sleep(1)

        return
