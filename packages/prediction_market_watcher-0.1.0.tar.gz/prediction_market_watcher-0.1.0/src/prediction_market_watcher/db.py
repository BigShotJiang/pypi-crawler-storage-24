import os
import queue
import random
import sqlite3
import json
import threading
import time
from abc import ABC, abstractmethod
from dataclasses import asdict
from typing import List, Any, Dict
from datetime import datetime
from enum import Enum, Flag


class DatabaseClient(ABC):
    """
    Abstract interface for any database backend
    """

    def __init__(self, connection_string: str):
        self.connection_string = connection_string

    @abstractmethod
    def insert_batch(self, table: str, data: List[dict]) -> bool:
        """Inserts a list of dictionaries into the specified table."""
        pass

    @abstractmethod
    def close(self): pass


class AsyncSQLiteClient(DatabaseClient):
    """
    Industry Standard: The 'Single Writer' Pattern (Multiton).
    - Ensures only ONE writer thread exists per database file.
    - If you instantiate this class 50 times for the same file,
      you get the SAME shared object 50 times.
    """
    _instances: Dict[str, 'AsyncSQLiteClient'] = {}
    _lock = threading.Lock()

    def __new__(cls, db_path: str):
        """
        Magic method to ensure we return the existing instance for this db_path
        instead of creating a new one every time.
        """
        # Normalize path so "./out.db" and "out.db" match
        abs_path = os.path.abspath(db_path)

        with cls._lock:
            if abs_path not in cls._instances:
                instance = super(AsyncSQLiteClient, cls).__new__(cls)
                instance._initialized = False
                cls._instances[abs_path] = instance
            return cls._instances[abs_path]

    def __init__(self, db_path: str):
        # Prevent re-initialization if we are retrieving an existing instance
        if getattr(self, '_initialized', False):
            return

        self.db_path = os.path.abspath(db_path)
        self.queue = queue.Queue()  # Unlimited size queue
        self.running = True

        # Start the dedicated writer thread
        self.writer_thread = threading.Thread(
            target=self._writer_loop,
            daemon=True,
            name=f"DB-Writer-{os.path.basename(db_path)}"
        )
        self.writer_thread.start()
        self._initialized = True
        print(f"[DB] Started dedicated writer for {os.path.basename(db_path)}")

    def insert_batch(self, table: str, data: List[dict]) -> bool:
        """Producers call this. Returns INSTANTLY."""
        if not data: return True
        self.queue.put((table, data))
        return True

    def _writer_loop(self):
        """The Consumer. Runs in its own thread. Owns the write connection."""
        conn = sqlite3.connect(self.db_path, check_same_thread=False, timeout=30.0)

        # PERFORMANCE SETTINGS
        conn.execute("PRAGMA journal_mode=WAL;")
        conn.execute("PRAGMA synchronous=OFF;")
        conn.execute("PRAGMA mmap_size=30000000000;")

        self._init_schema(conn)

        last_commit = time.time()

        while self.running or not self.queue.empty():
            try:
                # Wait for data
                table, data = self.queue.get(timeout=0.5)

                # Write to OS Cache
                self._write_to_db(conn, table, data)
                self.queue.task_done()

                # Commit to Disk (Batching)
                # Commit every 0.5s OR if queue is getting big
                if time.time() - last_commit > 0.5:
                    conn.commit()
                    last_commit = time.time()

            except queue.Empty:
                if conn.in_transaction:
                    conn.commit()
                continue
            except Exception as e:
                print(f"[DB Error] {os.path.basename(self.db_path)}: {e}")

        conn.commit()
        conn.close()
        print(f"[DB] Writer stopped for {os.path.basename(self.db_path)}")

    def _write_to_db(self, conn, table, data):
        try:
            keys = data[0].keys()
            columns = ', '.join(keys)
            placeholders = ', '.join(['?'] * len(keys))
            values_list = []

            for row in data:
                clean_row = []
                for k in keys:
                    val = row[k]
                    if isinstance(val, (dict, list, tuple)):
                        val = json.dumps(val)
                    elif isinstance(val, datetime):
                        val = val.isoformat()
                    elif isinstance(val, Enum):
                        val = val.value
                    elif isinstance(val, Flag):
                        val = val.name
                    clean_row.append(val)
                values_list.append(tuple(clean_row))

            sql = f"REPLACE INTO {table} ({columns}) VALUES ({placeholders})"
            conn.executemany(sql, values_list)

        except Exception as e:
            print(f"Failed to write batch to {table}: {e}")

    def _init_schema(self, conn):
        # 1. PARENT EVENTS
        conn.execute("""
                   CREATE TABLE IF NOT EXISTS parent_events (
                       id TEXT PRIMARY KEY,
                       slug TEXT,
                       name TEXT,
                       has_multiple_tickers BOOLEAN,
                       start_timestamp TEXT,
                       end_timestamp TEXT,
                       description TEXT,
                       platform TEXT,
                       metadata TEXT
                   )
               """)

        # 2. TRADES
        conn.execute("""
                   CREATE TABLE IF NOT EXISTS trades (
                       trade_id TEXT PRIMARY KEY,
                       parent_event_id TEXT,
                       ticker_id TEXT,
                       platform_id TEXT,
                       timestamp TEXT,
                       price REAL,
                       size REAL,
                       side TEXT,
                       outcome TEXT,
                       metadata TEXT,
                       maker_address TEXT,
                       taker_address TEXT
                   )
               """)

        # 3. L1 DATA (Quotes)
        # best_bid/ask are Level objects, stored as JSON: {"price": x, "size": y}
        conn.execute("""
                   CREATE TABLE IF NOT EXISTS l1_data (
                       parent_event_id TEXT,
                       ticker_id TEXT,
                       platform_id TEXT,
                       timestamp TEXT,
                       best_bid TEXT, 
                       best_ask TEXT,
                       outcome TEXT,
                       metadata TEXT,
                       spread REAL
                   )
               """)

        # 4. L2 DATA (Order Book)
        # bids/asks are List[Level], stored as JSON: [{"price": x, "size": y}, ...]
        conn.execute("""
                   CREATE TABLE IF NOT EXISTS l2_data (
                       parent_event_id TEXT,
                       ticker_id TEXT,
                       platform_id TEXT,
                       timestamp TEXT,
                       bids TEXT, 
                       asks TEXT, 
                       outcome TEXT,
                       metadata TEXT
                   )
               """)

        # 5. COMMENTS
        conn.execute("""
                               CREATE TABLE IF NOT EXISTS comments (
                                   comment_id TEXT PRIMARY KEY,
                                   parent_event_id TEXT,
                                   ticker_id TEXT,
                                   platform_id TEXT,
                                   timestamp TEXT,
                                   user_id TEXT,
                                   user_name TEXT,
                                   text TEXT,
                                   metadata TEXT,
                                   outcome TEXT,
                                   user_tags TEXT,
                                   user_position_snapshot TEXT, -- JSON blob of positions
                                   reply_to_id TEXT
                               )
                           """)

        # 6. REACTIONS
        conn.execute("""
                               CREATE TABLE IF NOT EXISTS reactions (
                                   reaction_id TEXT PRIMARY KEY,
                                   comment_id TEXT,
                                   user_address TEXT,
                                   reaction_type TEXT,
                                   timestamp TEXT,
                                   platform_id TEXT,
                                   FOREIGN KEY(comment_id) REFERENCES comments(comment_id)
                               )
                           """)

        # 6. TICKER INFO
        conn.execute("""
                   CREATE TABLE IF NOT EXISTS ticker_info (
                       ticker_id TEXT PRIMARY KEY,
                       parent_event_id TEXT,
                       ticker_name TEXT,
                       platform_id TEXT,
                       outcome_options TEXT, 
                       start_timestamp TEXT,
                       end_timestamp TEXT,
                       description TEXT,
                       metadata TEXT,
                       outcome TEXT
                   )
               """)

        tables = [
            "CREATE TABLE IF NOT EXISTS parent_events (id TEXT PRIMARY KEY, slug TEXT, name TEXT, has_multiple_tickers BOOLEAN, start_timestamp TEXT, end_timestamp TEXT, description TEXT, platform TEXT, metadata TEXT)",
            "CREATE TABLE IF NOT EXISTS trades (trade_id TEXT PRIMARY KEY, parent_event_id TEXT, ticker_id TEXT, platform_id TEXT, timestamp TEXT, price REAL, size REAL, side TEXT, outcome TEXT, metadata TEXT, maker_address TEXT, taker_address TEXT)",
            "CREATE TABLE IF NOT EXISTS l1_data (parent_event_id TEXT, ticker_id TEXT, platform_id TEXT, timestamp TEXT, best_bid TEXT, best_ask TEXT, outcome TEXT, metadata TEXT, spread REAL)",
            "CREATE TABLE IF NOT EXISTS l2_data (parent_event_id TEXT, ticker_id TEXT, platform_id TEXT, timestamp TEXT, bids TEXT, asks TEXT, outcome TEXT, metadata TEXT)",
            "CREATE TABLE IF NOT EXISTS comments (comment_id TEXT PRIMARY KEY, parent_event_id TEXT, ticker_id TEXT, platform_id TEXT, timestamp TEXT, user_id TEXT, user_name TEXT, text TEXT, metadata TEXT, outcome TEXT, user_tags TEXT, user_position_snapshot TEXT, reply_to_id TEXT)",
            "CREATE TABLE IF NOT EXISTS reactions (reaction_id TEXT PRIMARY KEY, comment_id TEXT, user_address TEXT, reaction_type TEXT, timestamp TEXT, platform_id TEXT, FOREIGN KEY(comment_id) REFERENCES comments(comment_id))",
            "CREATE TABLE IF NOT EXISTS ticker_info (ticker_id TEXT PRIMARY KEY, parent_event_id TEXT, ticker_name TEXT, platform_id TEXT, outcome_options TEXT, start_timestamp TEXT, end_timestamp TEXT, description TEXT, metadata TEXT, outcome TEXT)"
        ]
        for sql in tables:
            conn.execute(sql)
        conn.commit()

    def close(self):
        pass

    @classmethod
    def stop_all(cls):
        """Call this on shutdown to flush everything"""
        for instance in cls._instances.values():
            instance.running = False
            instance.writer_thread.join()

# TODO: if its too slow opening and closing connections every time then try using Thread Local Storage
class LocalSQLiteClient(DatabaseClient):
    def __init__(self, db_path: str = "out.db"):
        super().__init__(db_path)
        self.db_path = db_path
        self._init_schema()

    def _get_conn(self):
        conn = sqlite3.connect(self.db_path, check_same_thread=False, timeout=60.0)
        conn.execute("PRAGMA journal_mode=WAL;")
        conn.execute("PRAGMA synchronous=OFF;")
        conn.execute("PRAGMA mmap_size=30000000000;")
        conn.execute("PRAGMA cache_size=-100000;")
        conn.execute("PRAGMA temp_store=MEMORY;")
        conn.execute("PRAGMA busy_timeout = 5000;")

        return conn

    def _init_schema(self):
        conn = self._get_conn()
        try:
            # 1. PARENT EVENTS
            conn.execute("""
                CREATE TABLE IF NOT EXISTS parent_events (
                    id TEXT PRIMARY KEY,
                    slug TEXT,
                    name TEXT,
                    has_multiple_tickers BOOLEAN,
                    start_timestamp TEXT,
                    end_timestamp TEXT,
                    description TEXT,
                    platform TEXT,
                    metadata TEXT
                )
            """)

            # 2. TRADES
            conn.execute("""
                CREATE TABLE IF NOT EXISTS trades (
                    trade_id TEXT PRIMARY KEY,
                    parent_event_id TEXT,
                    ticker_id TEXT,
                    platform_id TEXT,
                    timestamp TEXT,
                    price REAL,
                    size REAL,
                    side TEXT,
                    outcome TEXT,
                    metadata TEXT,
                    maker_address TEXT,
                    taker_address TEXT
                )
            """)

            # 3. L1 DATA (Quotes)
            # best_bid/ask are Level objects, stored as JSON: {"price": x, "size": y}
            conn.execute("""
                CREATE TABLE IF NOT EXISTS l1_data (
                    parent_event_id TEXT,
                    ticker_id TEXT,
                    platform_id TEXT,
                    timestamp TEXT,
                    best_bid TEXT, 
                    best_ask TEXT,
                    outcome TEXT,
                    metadata TEXT,
                    spread REAL
                )
            """)

            # 4. L2 DATA (Order Book)
            # bids/asks are List[Level], stored as JSON: [{"price": x, "size": y}, ...]
            conn.execute("""
                CREATE TABLE IF NOT EXISTS l2_data (
                    parent_event_id TEXT,
                    ticker_id TEXT,
                    platform_id TEXT,
                    timestamp TEXT,
                    bids TEXT, 
                    asks TEXT, 
                    outcome TEXT,
                    metadata TEXT
                )
            """)

            # 5. COMMENTS
            conn.execute("""
                            CREATE TABLE IF NOT EXISTS comments (
                                comment_id TEXT PRIMARY KEY,
                                parent_event_id TEXT,
                                ticker_id TEXT,
                                platform_id TEXT,
                                timestamp TEXT,
                                user_id TEXT,
                                user_name TEXT,
                                text TEXT,
                                metadata TEXT,
                                outcome TEXT,
                                user_tags TEXT,
                                user_position_snapshot TEXT, -- JSON blob of positions
                                reply_to_id TEXT
                            )
                        """)

            # 6. REACTIONS
            conn.execute("""
                            CREATE TABLE IF NOT EXISTS reactions (
                                reaction_id TEXT PRIMARY KEY,
                                comment_id TEXT,
                                user_address TEXT,
                                reaction_type TEXT,
                                timestamp TEXT,
                                platform_id TEXT,
                                FOREIGN KEY(comment_id) REFERENCES comments(comment_id)
                            )
                        """)

            # 6. TICKER INFO
            conn.execute("""
                CREATE TABLE IF NOT EXISTS ticker_info (
                    ticker_id TEXT PRIMARY KEY,
                    parent_event_id TEXT,
                    ticker_name TEXT,
                    platform_id TEXT,
                    outcome_options TEXT, 
                    start_timestamp TEXT,
                    end_timestamp TEXT,
                    description TEXT,
                    metadata TEXT,
                    outcome TEXT
                )
            """)
            conn.commit()
        finally:
            conn.close()

    def insert_batch(self, table: str, data: List[dict]) -> bool:
        if not data: return True

        # Increase retries, but rely on the capped sleep to keep it moving
        max_retries = 100

        # Pre-process data OUTSIDE the retry loop (Cpu work)
        try:
            keys = data[0].keys()
            columns = ', '.join(keys)
            placeholders = ', '.join(['?'] * len(keys))
            values_list = []

            for row in data:
                clean_row = []
                for k in keys:
                    val = row[k]
                    if isinstance(val, (dict, list, tuple)):
                        val = json.dumps(val)
                    elif isinstance(val, datetime):
                        val = val.isoformat()
                    elif isinstance(val, Enum):
                        val = val.value
                    elif isinstance(val, Flag):
                        val = val.name
                    elif val is None:
                        val = None
                    clean_row.append(val)
                values_list.append(tuple(clean_row))

            sql = f"REPLACE INTO {table} ({columns}) VALUES ({placeholders})"

        except Exception as e:
            print(f"Data Preparation Error {table}: {e}")
            return False

        # Attempt Write
        for attempt in range(max_retries):
            conn = None
            try:
                conn = self._get_conn()
                conn.executemany(sql, values_list)
                conn.commit()
                return True

            except sqlite3.OperationalError as e:
                if "locked" in str(e).lower():
                    # 1. Base Exponential: 0.1, 0.15, 0.22, 0.33... (grows slowly)
                    # 2. Cap: Never wait more than 5.0 seconds
                    base_sleep = min(5.0, 0.1 * (1.5 ** attempt))

                    # 3. High Jitter: Randomize by +/- 50%
                    # This ensures thread A waits 1.2s and thread B waits 0.8s
                    actual_sleep = base_sleep * random.uniform(0.5, 1.5)

                    if attempt > 10:
                        # Only log if it's really struggling
                        print(
                            f"[DB Locked] Retrying {table} (Attempt {attempt + 1}/{max_retries}) Wait: {actual_sleep:.2f}s")

                    time.sleep(actual_sleep)
                    continue
                else:
                    print(f"Write Error {table}: {e}")
                    return False

            except Exception as e:
                print(f"Unexpected DB Error {table}: {e}")
                return False

            finally:
                if conn:
                    try:
                        conn.close()
                    except:
                        pass

        print(f"[DB Failure] Could not write to {table} after {max_retries} attempts.")
        return False

    def close(self):
        pass


# Supabase (or any other db service) can go here
class SupabaseClient(DatabaseClient):
    def __init__(self, url: str, key: str):
        super().__init__(url)
        self.key = key

    def insert_batch(self, table: str, data: List[dict]) -> bool:
        return True

    def close(self):
        pass


class BatchWriter:
    """
    Accumulates records and writes them to ANY implementation of DatabaseClient
    when buffer fills or time elapses. Uses dynamic resizing to aim for a specific flush interval.
    """

    def __init__(self, client: DatabaseClient, table: str, batch_size=100, target_interval=5.0):
        self.client = client
        self.table = table
        self.buffer = []

        # Buffer Configuration
        self.batch_size = batch_size
        self.target_interval = target_interval

        # State tracking: Use perf_counter for high-resolution monotonic timing
        self.last_flush_time = time.perf_counter()
        # Disable dynamic sizing if hardcoded to 1 (strict real-time/critical data)
        self.dynamic = (batch_size > 1)

    def add(self, record: Any):
        self.buffer.append(asdict(record))

        if len(self.buffer) >= self.batch_size:
            self.flush()

    def flush(self):
        if not self.buffer: return

        # Write Data
        self.client.insert_batch(self.table, self.buffer)
        now = time.perf_counter()
        elapsed = now - self.last_flush_time
        self.last_flush_time = now

        # Dynamic Adjustment Logic
        if self.dynamic:
            # Allow adjustment even on microsecond intervals (1e-6 seconds)
            if elapsed > 1e-6:
                # Calculate ideal size based on observed flow rate
                # Logic: We want (new_size / rate) = target_interval
                # Observed Rate = current_size / elapsed
                # Therefore: new_size = current_size * (target_interval / elapsed)

                ratio = self.target_interval / elapsed
                calculated_size = self.batch_size * ratio

                # Apply smoothing (Exponential Moving Average) to prevent jitter
                # New = 50% Old + 50% Calculated
                new_size = int((self.batch_size * 0.5) + (calculated_size * 0.5))

                # Bounds check (never go below 1)
                new_size = max(2, new_size)

                self.batch_size = new_size

        self.buffer = []

    def flush_if_stale(self, max_age_seconds=50.0):
        """
        Force flush if data has been sitting in the buffer longer than max_age_seconds.
        """
        if not self.buffer:
            return

        elapsed = time.perf_counter() - self.last_flush_time
        if elapsed > max_age_seconds:
            # print(f"[{self.table}] Stale buffer ({len(self.buffer)} items, {elapsed:.1f}s). Force flushing.")
            self.flush()
