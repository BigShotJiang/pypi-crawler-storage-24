import unittest
import sqlite3
import os
import threading
import random
import time
from datetime import datetime
from util import events_to_dfs

from .db import LocalSQLiteClient, BatchWriter
from .data_types import (
    TradeData, L1Data, L2Data, CommentData, TickerInfo,
    Side, PlatformId, ParentEvent, Level
)


class TestLocalSQLiteDB(unittest.TestCase):
    TEST_DB_PATH = "test_market_data.db"

    def setUp(self):
        """Runs before every test: Setup a fresh DB."""
        print(f"\n[SETUP] Connecting to DB at: {self.TEST_DB_PATH}")
        if os.path.exists(self.TEST_DB_PATH):
            os.remove(self.TEST_DB_PATH)

        self.client = LocalSQLiteClient(self.TEST_DB_PATH)

    def tearDown(self):
        """Runs after every test: Cleanup."""
        print(f"[TEARDOWN] Closing DB connection.")
        self.client.close()

    def _get_raw_conn(self):
        return sqlite3.connect(self.TEST_DB_PATH)

    def test_insert_all_types(self):
        """
        Validates that every single Data Class (New Schema) can be written and read.
        """
        print("[TEST] Running test_insert_all_types (Schema Validation)...")

        writers = {
            'parent_events': BatchWriter(self.client, 'parent_events', 1),
            'trades': BatchWriter(self.client, 'trades', 1),
            'l1': BatchWriter(self.client, 'l1_data', 1),
            'l2': BatchWriter(self.client, 'l2_data', 1),
            'comments': BatchWriter(self.client, 'comments', 1),
            'ticker_info': BatchWriter(self.client, 'ticker_info', 1)
        }

        # 1. PARENT EVENT (Fixed timestamps to be datetime objects)
        pe = ParentEvent(
            slug="us-election-2024",
            id="p1",
            name="name",
            has_multiple_tickers=True,
            start_timestamp=datetime.now(),  # Now datetime
            end_timestamp=datetime.now(),  # Now datetime
            description="Election",
            platform=PlatformId.POLY,
            metadata="{}"
        )
        writers['parent_events'].add(pe)

        # 2. TRADE (Renamed FK, Added Outcome)
        t = TradeData(
            trade_id="t1",
            parent_event_id="p1",
            ticker_id="tick1",
            platform_id=PlatformId.POLY,
            timestamp=datetime.now(),
            price=0.99,
            size=10.0,
            side=Side.BUY,
            outcome="YES",
            metadata="{}",
            maker_address="0x1",
            taker_address="0x2",
        )
        writers['trades'].add(t)

        # 3. L1 DATA (Uses Level Objects)
        l1 = L1Data(
            parent_event_id="p1",
            ticker_id="tick1",
            platform_id=PlatformId.POLY,
            timestamp=datetime.now(),
            best_bid=Level(price=0.98, size=500),
            best_ask=Level(price=0.99, size=300),
            outcome="Yes",
            spread=0.01,
            metadata="{}"
        )
        writers['l1'].add(l1)

        # 4. L2 DATA (List[Level])
        l2 = L2Data(
            parent_event_id="p1",
            ticker_id="tick1",
            platform_id=PlatformId.POLY,
            timestamp=datetime.now(),
            bids=[Level(0.98, 100), Level(0.97, 200)],
            asks=[Level(0.99, 100), Level(1.00, 200)],
            outcome="Yes",
            metadata="{}"
        )
        writers['l2'].add(l2)

        # 5. COMMENTS
        c = CommentData(
            comment_id="c1",
            parent_event_id="p1",
            ticker_id="tick1",
            platform_id=PlatformId.POLY,
            timestamp=datetime.now(),
            user_id="u1",
            user_name="User1",
            text="HODL",
            metadata="{}",
            user_tags="Whale",
            user_position_size=1000.0,
            outcome="Yes",
        )
        writers['comments'].add(c)

        # 6. TICKER INFO (Initial State)
        ti = TickerInfo(
            parent_event_id="p1",
            ticker_id="tick1",
            ticker_name="T",
            platform_id=PlatformId.POLY,
            outcome_options=("YES", "NO"),
            start_timestamp=datetime.now(),
            end_timestamp=None,
            outcome=None,
            description="Will Trump Win?",
            metadata="{}"
        )
        writers['ticker_info'].add(ti)

        conn = self._get_raw_conn()
        cursor = conn.cursor()

        # Check Tables exist and have 1 row each
        tables = ['parent_events', 'trades', 'l1_data', 'l2_data', 'comments', 'ticker_info']
        for table in tables:
            cursor.execute(f"SELECT count(*) FROM {table}")
            count = cursor.fetchone()[0]
            self.assertEqual(count, 1, f"{table} should have 1 row")
            print(f"   [OK] {table} has 1 row.")

        conn.close()

    def test_ticker_info_upsert(self):
        """
        Verifies that inserting a TickerInfo with an existing ticker_id
        REPLACES the old row instead of duplicating or failing.
        """
        print("\n[TEST] Running test_ticker_info_upsert...")

        writer = BatchWriter(self.client, 'ticker_info', batch_size=1)
        ticker_id = "upsert_test_ticker"

        # 1. First Insert (Active Market State)
        active_info = TickerInfo(
            parent_event_id="p1",
            ticker_id=ticker_id,
            ticker_name="Upsert Test",
            platform_id=PlatformId.POLY,
            outcome_options=("YES", "NO"),
            start_timestamp=datetime.now(),
            end_timestamp=datetime.now(),
            outcome=None,
            description="Active",
            metadata="{}"
        )
        writer.add(active_info)

        # 2. Verify First Insert
        conn = self._get_raw_conn()
        cursor = conn.cursor()
        cursor.execute(f"SELECT outcome FROM ticker_info WHERE ticker_id='{ticker_id}'")
        row = cursor.fetchone()
        self.assertIsNone(row[0])  # outcome should be None
        print("   [OK] Initial insert successful (Active state).")

        # 3. Second Insert (Resolved Market State) - SAME ticker_id
        resolved_info = TickerInfo(
            parent_event_id="p1",
            ticker_id=ticker_id,
            ticker_name="Upsert Test",
            platform_id=PlatformId.POLY,
            outcome_options=("YES", "NO"),
            start_timestamp=datetime.now(),
            end_timestamp=datetime.now(),
            outcome="YES",
            description="Resolved",
            metadata="{}"
        )
        writer.add(resolved_info)

        # 4. Verify Replacement
        cursor.execute(f"SELECT count(*) FROM ticker_info WHERE ticker_id='{ticker_id}'")
        count = cursor.fetchone()[0]
        self.assertEqual(count, 1, "Should still be exactly 1 row after upsert")

        cursor.execute(f"SELECT outcome FROM ticker_info WHERE ticker_id='{ticker_id}'")
        row = cursor.fetchone()
        self.assertEqual(row[0], "YES")  # outcome updated
        print("   [OK] Upsert successful (Resolved state overwritten).")

        conn.close()

    def test_massive_population(self):
        """
        Spawns 200 threads.
        Each thread simulates a distinct Parent + Ticker combo.
        """
        print("\n[TEST] Running test_massive_population (Stress Test)...")

        THREAD_COUNT = 200
        WRITES_PER_THREAD = 50

        results = {"success": 0, "errors": 0}

        def worker(thread_idx):
            # Simulating a unique ticker per thread
            ticker_id = f"ticker_{thread_idx}"
            parent_id = f"parent_{thread_idx % 10}"

            writers = {
                'parent_events': BatchWriter(self.client, 'parent_events', batch_size=1),
                'trades': BatchWriter(self.client, 'trades', batch_size=5),
                'l1': BatchWriter(self.client, 'l1_data', batch_size=5),
                'l2': BatchWriter(self.client, 'l2_data', batch_size=5),
                'comments': BatchWriter(self.client, 'comments', batch_size=1),
                'ticker_info': BatchWriter(self.client, 'ticker_info', batch_size=1)
            }

            try:
                # 1. Write Parent Event (Once per thread/session logic)
                if thread_idx % 10 == 0:
                    pe = ParentEvent(
                        slug=f"event-{parent_id}",
                        id=parent_id,
                        name="name",
                        has_multiple_tickers=True,
                        start_timestamp=datetime.now(),
                        end_timestamp=datetime.now(),
                        description="Stress Test",
                        platform=PlatformId.POLY,
                        metadata="{}"
                    )
                    writers['parent_events'].add(pe)

                # 2. Write Ticker Info (Start of tracking)
                ti = TickerInfo(
                    parent_event_id=parent_id,
                    ticker_id=ticker_id,
                    ticker_name=f"Outcome {ticker_id}",
                    platform_id=PlatformId.POLY,
                    outcome_options=("YES", "NO"),
                    start_timestamp=datetime.now(),
                    end_timestamp=datetime.now(),
                    outcome=None,
                    description="Stress Test Ticker",
                    metadata="{}"
                )
                writers['ticker_info'].add(ti)

                for i in range(WRITES_PER_THREAD):
                    ts = datetime.now()
                    choice = random.random()

                    if choice < 0.5:
                        t = TradeData(
                            trade_id=f"t_{thread_idx}_{i}",
                            parent_event_id=parent_id,
                            ticker_id=ticker_id,
                            platform_id=PlatformId.POLY,
                            timestamp=ts,
                            price=random.uniform(0.01, 0.99),
                            size=random.uniform(10, 1000),
                            side=random.choice([Side.BUY, Side.SELL]),
                            outcome="YES",
                            metadata='{"simulated": true}',
                            maker_address="0xMaker",
                            taker_address="0xTaker"
                        )
                        writers['trades'].add(t)

                    elif choice < 0.8:
                        l1 = L1Data(
                            parent_event_id=parent_id,
                            ticker_id=ticker_id,
                            platform_id=PlatformId.POLY,
                            timestamp=ts,
                            best_bid=Level(0.45, 1000),
                            best_ask=Level(0.55, 2000),
                            outcome="Yes",
                            spread=0.10,
                            metadata="{}"
                        )
                        writers['l1'].add(l1)

                    elif choice < 0.95:
                        l2 = L2Data(
                            parent_event_id=parent_id,
                            ticker_id=ticker_id,
                            platform_id=PlatformId.POLY,
                            timestamp=ts,
                            bids=[Level(0.45, 100), Level(0.44, 200)],
                            asks=[Level(0.55, 100), Level(0.56, 200)],
                            outcome="Yes",
                            metadata="{}"
                        )
                        writers['l2'].add(l2)

                    else:
                        c = CommentData(
                            comment_id=f"c_{thread_idx}_{i}",
                            parent_event_id=parent_id,
                            ticker_id=ticker_id,
                            platform_id=PlatformId.POLY,
                            timestamp=ts,
                            user_id="user_1",
                            user_name="TraderBot",
                            text="Stress test comment",
                            metadata="{}",
                            outcome="Yes",
                        )
                        writers['comments'].add(c)

                for w in writers.values():
                    w.flush()

                results["success"] += 1

            except Exception as e:
                print(f"[Thread-{thread_idx}] ERROR: {e}")
                results["errors"] += 1

        threads = []
        print(f"   Spawning {THREAD_COUNT} threads...")
        start_time = time.time()

        for i in range(THREAD_COUNT):
            t = threading.Thread(target=worker, args=(i,))
            threads.append(t)
            t.start()

        for t in threads:
            t.join()

        duration = time.time() - start_time
        print(f"\n[DONE] Finished in {duration:.2f} seconds.")
        print(f"   Threads Completed: {results['success']}/{THREAD_COUNT}")
        print(f"   Errors: {results['errors']}")

        self.assertEqual(results['errors'], 0, "Stress test encountered errors.")


class TestUtils(unittest.TestCase):
    def test_events_to_dfs_conversion(self):
        """
        Tests that events are correctly converted to DFs.
        """
        print("\n[TEST] Running test_events_to_dfs_conversion...")

        ts = datetime.now()
        events = [
            TradeData(
                trade_id="t1", parent_event_id="p1",
                ticker_id="tick1", platform_id=PlatformId.POLY,
                timestamp=ts, price=0.50, size=100, side=Side.BUY, outcome="YES",
                metadata="{}", maker_address="m", taker_address="t"
            ),
            L1Data(
                parent_event_id="p1", ticker_id="tick1", platform_id=PlatformId.POLY,
                timestamp=ts, best_bid=Level(0.49, 100), best_ask=Level(0.51, 100),
                spread=0.02, metadata="{}", outcome="Yes",
            )
        ]

        package = events_to_dfs(events)

        # Verify Trades
        self.assertEqual(len(package.trades), 1)
        self.assertEqual(package.trades.iloc[0]['trade_id'], "t1")
        self.assertEqual(package.trades.iloc[0]['outcome'], "YES")

        # Verify L1 (Level objects will likely remain dicts/objects in the DF depending on utils implementation)
        self.assertEqual(len(package.l1), 1)
        print("   DataFrames built correctly.")


if __name__ == "__main__":
    unittest.main()
