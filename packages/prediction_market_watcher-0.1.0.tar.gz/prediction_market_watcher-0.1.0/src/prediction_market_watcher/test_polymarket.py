import asyncio

from .polymarket import PolymarketTracker


TEST_URL = "https://polymarket.com/event/nfl-sea-ne-2026-02-08"
MARKET_URL = "https://polymarket.com/market/nfl-sea-ne-2026-02-08"
TIMEOUT_SECONDS = 999





async def _drain_for_seconds(tracker: PolymarketTracker, seconds: int):
    end = asyncio.get_running_loop().time() + seconds
    while asyncio.get_running_loop().time() < end:
        try:
            if tracker.data_queue.empty():
                await asyncio.sleep(0)
                continue
            item = tracker.data_queue.get_nowait()
        except asyncio.TimeoutError:
            continue
        print(f"[{type(item).__name__}] {item}")


async def main():
    event_tracker = PolymarketTracker(TEST_URL, "test_market_data.db")
    if not event_tracker.verify():
        raise SystemExit(f"event.verify() failed for {event_tracker.parent_event_name}")
    print(event_tracker.get_tickers_for_parent())
    tracker = None
    for idx, i in enumerate(event_tracker.get_tickers_for_parent()):
        if i == MARKET_URL:
            tracker = PolymarketTracker(i, "test_market_data.db")
    if tracker is None:
        raise SystemExit(f"Tracker is None.")
    print(tracker.ticker_name)
    print(tracker.clob_token_ids)
    if not tracker.verify():
        raise SystemExit(f"market.verify() failed for {tracker.ticker_name}")

    # force overwrite
    if tracker.is_ticker_actively_trading():
        tracker.is_running = True
    tracker.active_streams = {'trades', 'l1', 'l2', 'comments', 'resolution', 'parent_info'}
    # tracker.start_market_ws_listener(verbose=False)

    tasks = [
        asyncio.create_task(tracker._stream_trades()),
        asyncio.create_task(tracker._stream_l1()),
        asyncio.create_task(tracker._stream_l2()),
        asyncio.create_task(tracker._monitor_resolution()),
    ]
    
    
    

    try:
        await _drain_for_seconds(tracker, TIMEOUT_SECONDS)
    finally:
        tracker.is_running = False
        tracker.stop_market_ws_listener()
        for task in tasks:
            task.cancel()
        await asyncio.gather(*tasks, return_exceptions=True)


if __name__ == "__main__":
    asyncio.run(main())
