class MarketInterfaceError(Exception):
    def __init__(self, message):
        super().__init__(message)

class LiveMarketUpdateError(MarketInterfaceError):
    def __init__(self, message):
        super().__init__("LiveMarketUpdateError: " + message)

class HistoricalOrderBookError(MarketInterfaceError):
    def __init__(self, message):
        super().__init__("HistoricalOrderBookError: " + message)