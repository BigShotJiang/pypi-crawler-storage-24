import pandas as pd
import requests
import base64
import time
from typing import Any, Dict, Optional
from datetime import datetime, timedelta
from enum import Enum
import json
import ssl
import certifi


from cryptography.hazmat.primitives import serialization, hashes
from cryptography.hazmat.primitives.asymmetric import padding, rsa
from cryptography.exceptions import InvalidSignature

import websockets


class Environment(Enum):
    DEMO = "demo"
    PROD = "prod"


class KalshiBaseClient:
    """Base client class for interacting with the Kalshi API."""

    def __init__(
            self,
            key_id: str,
            private_key: rsa.RSAPrivateKey,
            environment: Environment = Environment.DEMO,
    ):
        """Initializes the client with the provided API key and private key.

        Args:
            key_id (str): Your Kalshi API key ID.
            private_key (rsa.RSAPrivateKey): Your RSA private key.
            environment (Environment): The API environment to use (DEMO or PROD).
        """
        self.key_id = key_id
        self.private_key = private_key
        self.environment = environment
        self.last_api_call = datetime.now()

        if self.environment == Environment.DEMO:
            self.HTTP_BASE_URL = "https://demo-api.kalshi.co"
            self.WS_BASE_URL = "wss://demo-api.kalshi.co"
        elif self.environment == Environment.PROD:
            self.HTTP_BASE_URL = "https://api.elections.kalshi.com"
            self.WS_BASE_URL = "wss://api.elections.kalshi.com"
        else:
            raise ValueError("Invalid environment")

    def request_headers(self, method: str, path: str) -> Dict[str, Any]:
        """Generates the required authentication headers for API requests."""
        current_time_milliseconds = int(time.time() * 1000)
        timestamp_str = str(current_time_milliseconds)

        # Remove query params from path
        path_parts = path.split('?')

        msg_string = timestamp_str + method + path_parts[0]
        signature = self.sign_pss_text(msg_string)

        headers = {
            "Content-Type": "application/json",
            "KALSHI-ACCESS-KEY": self.key_id,
            "KALSHI-ACCESS-SIGNATURE": signature,
            "KALSHI-ACCESS-TIMESTAMP": timestamp_str,
        }
        return headers

    def sign_pss_text(self, text: str) -> str:
        """Signs the text using RSA-PSS and returns the base64 encoded signature."""
        message = text.encode('utf-8')
        try:
            signature = self.private_key.sign(
                message,
                padding.PSS(
                    mgf=padding.MGF1(hashes.SHA256()),
                    salt_length=padding.PSS.DIGEST_LENGTH
                ),
                hashes.SHA256()
            )
            return base64.b64encode(signature).decode('utf-8')
        except InvalidSignature as e:
            raise ValueError("RSA sign PSS failed") from e


class KalshiHttpClient(KalshiBaseClient):
    """Client for handling HTTP connections to the Kalshi API."""

    def __init__(
            self,
            key_id: str,
            private_key: rsa.RSAPrivateKey,
            environment: Environment = Environment.DEMO,
    ):
        super().__init__(key_id, private_key, environment)
        self.host = self.HTTP_BASE_URL
        self.exchange_url = "/trade-api/v2/exchange"
        self.markets_url = "/trade-api/v2/markets"
        self.portfolio_url = "/trade-api/v2/portfolio"

    def event_url(self, event_ticker):
        return f"/trade-api/v2/events/{event_ticker}"

    def rate_limit(self) -> None:
        """Built-in rate limiter to prevent exceeding API rate limits."""
        THRESHOLD_IN_MILLISECONDS = 100
        now = datetime.now()
        threshold_in_microseconds = 1000 * THRESHOLD_IN_MILLISECONDS
        threshold_in_seconds = THRESHOLD_IN_MILLISECONDS / 1000
        if now - self.last_api_call < timedelta(microseconds=threshold_in_microseconds):
            time.sleep(threshold_in_seconds)
        self.last_api_call = datetime.now()

    def raise_if_bad_response(self, response: requests.Response) -> None:
        """Raises an HTTPError if the response status code indicates an error."""
        if response.status_code not in range(200, 299):
            response.raise_for_status()

    def post(self, path: str, body: dict) -> Any:
        """Performs an authenticated POST request to the Kalshi API."""
        self.rate_limit()
        response = requests.post(
            self.host + path,
            json=body,
            headers=self.request_headers("POST", path)
        )
        self.raise_if_bad_response(response)
        return response.json()

    def get(self, path: str, params: Dict[str, Any] = {}) -> Any:
        """Performs an authenticated GET request to the Kalshi API."""
        self.rate_limit()
        response = requests.get(
            self.host + path,
            headers=self.request_headers("GET", path),
            params=params
        )
        self.raise_if_bad_response(response)
        return response.json()

    def delete(self, path: str, params: Dict[str, Any] = {}) -> Any:
        """Performs an authenticated DELETE request to the Kalshi API."""
        self.rate_limit()
        response = requests.delete(
            self.host + path,
            headers=self.request_headers("DELETE", path),
            params=params
        )
        self.raise_if_bad_response(response)
        return response.json()

    def get_balance(self) -> Dict[str, Any]:
        """Retrieves the account balance."""
        return self.get(self.portfolio_url + '/balance')

    def get_exchange_status(self) -> Dict[str, Any]:
        """Retrieves the exchange status."""
        return self.get(self.exchange_url + "/status")

    def url_args_handler(
            self,
            base_url: str,
            **kwargs
    ):
        """
        add arguments to the base url
        """
        url = base_url + "?"
        i = 0
        for key, value in kwargs.items():
            if i == 0:
                url += f"{key}={value}"
            else:
                url += f"&{key}={value}"
            i += 1
        return url

    def get_markets(
            self,
            **kwargs
    ) -> pd.DataFrame:
        """
        Retrieves available markets with pagination
        """
        return self.pagination_handler(
            base_url=self.markets_url,
            response_key="markets",
            **kwargs
        )

    def get_event(self, event_ticker: str) -> pd.DataFrame:
        """
        Retrieves event info for a single event
        """
        return self.get(self.event_url(event_ticker))

    def pagination_handler(
            self,
            base_url: str,
            response_key: str,
            **kwargs
    ) -> pd.DataFrame:
        """
        Handling pagination for any response
        """
        cursor = None
        output = []
        # print(f"pulling: {response_key} data")
        while True:
            url = self.url_args_handler(
                base_url=base_url,
                **kwargs
            )
            if cursor:
                url += f"&cursor={cursor}"
            response = self.get(url)
            output.extend(response[response_key])
            cursor = response.get('cursor')
            if not cursor:
                break
            time.sleep(1)
            print(f"response size: {len(response[response_key])}, "
                  f"output size: {len(output)}")

        return pd.DataFrame(output)

    def get_trades(
            self,
            ticker: Optional[str] = None,
            limit: Optional[int] = None,
            cursor: Optional[str] = None,
            max_ts: Optional[int] = None,
            min_ts: Optional[int] = None,
    ) -> Dict[str, Any]:
        """Retrieves trades based on provided filters."""
        params = {
            'ticker': ticker,
            'limit': limit,
            'cursor': cursor,
            'max_ts': max_ts,
            'min_ts': min_ts,
        }
        # Remove None values
        params = {k: v for k, v in params.items() if v is not None}
        return self.get(self.markets_url + '/trades', params=params)


class KalshiWebSocketClient(KalshiBaseClient):
    """Client for handling WebSocket connections to the Kalshi API."""

    # only set one of l1, l2, and get_trades to True
    def __init__(
            self,
            parent,
            key_id: str,
            private_key: rsa.RSAPrivateKey,
            environment: Environment = Environment.DEMO,
            l1: bool = False,
            l2: bool = False,
            get_trades: bool = False,
            get_market_updates: bool = False
    ):
        super().__init__(key_id, private_key, environment)
        self.ws = None
        self.parent = parent
        self.url_suffix = "/trade-api/ws/v2"
        self.message_id = 1  # Add counter for message IDs
        self.l1 = l1
        self.l2 = l2
        self.get_trades = get_trades
        self.get_market_updates = get_market_updates

    async def connect(
            self,
            ticker: list[str]
    ):
        """Establishes a WebSocket connection using authentication."""
        host = self.WS_BASE_URL + self.url_suffix
        auth_headers = self.request_headers("GET", self.url_suffix)

        ssl_context = ssl.create_default_context(cafile=certifi.where())

        print("connecting to: ", host)

        async with websockets.connect(host, additional_headers=auth_headers, ssl=ssl_context,
                                      open_timeout=60) as websocket:
            self.ws = websocket
            await self.on_open(ticker)
            await self.handler()

    async def on_open(
            self,
            ticker: list[str]
    ):
        """Callback when WebSocket connection is opened."""
        print(f"WebSocket connection opened for: "
              f"l1: {self.l1}, l2: {self.l2}, trades: {self.get_trades}, market updates: {self.get_market_updates}")
        if self.l1 or self.l2:
            await self.subscribe_to_market(["orderbook_delta"], ticker)

        if self.get_trades:
            await self.subscribe_to_market(["trade"], ticker)

        if self.get_market_updates:
            await self.subscribe_to_market(["market_lifecycle_v2"], ticker)

    async def subscribe_to_tickers(self):
        """Subscribe to ticker updates for all markets."""
        subscription_message = {
            "id": self.message_id,
            "cmd": "subscribe",
            "params": {
                "channels": ["ticker"]
            }
        }
        await self.ws.send(json.dumps(subscription_message))
        self.message_id += 1

    async def subscribe_to_market(
            self,
            channels: list[str],
            market: list[str]
    ):
        """Subscribe to specific channels and markets"""
        subscription_message = {
            "id": self.message_id,
            "cmd": "subscribe",
            "params": {
                "channels": channels,
                "market_tickers": market
            }
        }
        await self.ws.send(json.dumps(subscription_message))
        self.message_id += 1

    async def handler(self):
        """Handle incoming messages."""
        try:
            async for message in self.ws:
                await self.on_message(message)
        except websockets.ConnectionClosed as e:
            print("Websocket ConnectionClosed: Code = {e.code}, Reason = {e.reason}")
        except Exception as e:
            print(f"Websocket error: {e}")

    async def close(self):
        """Manually close the websocket connection."""
        if self.ws:
            await self.ws.close()
            print("WebSocket connection closed manually.")

    async def on_message(self, message):
        """Callback for handling incoming messages."""
        # parse incoming message as a json
        data = json.loads(message)
        msg_type = data.get("type")
        msg = data.get("msg", {})

        # print("Received message:", message)

        # initial order book snapshot processing
        if msg_type == "orderbook_snapshot":
            self.parent.init_orderbook_from_snapshot(msg, l1=self.l1, l2=self.l2)
            return

        # subsequent order book delta processing
        if msg_type == "orderbook_delta":
            self.parent.update_orderbook_with_delta(msg, l1=self.l1, l2=self.l2)
            return

        if msg_type == "trade":
            self.parent.process_live_trade(msg)
            return

        if msg_type == "market_lifecycle_v2":
            self.parent.process_market_update(msg)
