import asyncio
import logging
import os
import threading
import time
import unittest
from datetime import datetime, timedelta
from unittest.mock import patch

from .data_types import (
    TradeData, L1Data, L2Data, CommentData, TickerInfo,
    ParentEvent, PlatformId, Side, Level
)
from .db import LocalSQLiteClient
from .market_interface import MarketInterface

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')


class UltimateMockTracker(MarketInterface):
    """
    A concrete implementation of MarketInterface designed specifically for testing.

    Capabilities:
    1. Deterministic Data Generation: Generates Trades, L1, L2, and Comments on demand.
    2. High-Performance Streams: 'Firehose' mode (tight loops, no sleep).
    3. State Simulation: Pre-market, Open, and Resolved states.
    4. Concurrency Checks: Events to verify backfill/stream overlap.
    """

    def __init__(self, identifier, db_name, collect_l2=False,
                 initially_resolved=False, initially_open=True,
                 # Volume Configs
                 trade_vol=0, l1_vol=0, l2_vol=0, comment_vol=0,
                 backfill_vol=0,
                 # Behavior Configs
                 simulate_gap_seconds=0.0,
                 check_concurrency=False,
                 active_streams=None):

        super().__init__(identifier, db_name, collect_l2, active_streams=active_streams)

        self.initially_resolved = initially_resolved
        self.initially_open = initially_open
        self.trade_vol = trade_vol
        self.l1_vol = l1_vol
        self.l2_vol = l2_vol
        self.comment_vol = comment_vol
        self.backfill_vol = backfill_vol
        self.simulate_gap_seconds = simulate_gap_seconds
        self.check_concurrency = check_concurrency

        self.time_cursor = datetime.now()

        # Synchronization (Asyncio)
        self.streams_finished = asyncio.Event()

        # Concurrency Test Events (Threading)
        self.ev_stream_started = threading.Event()
        self.ev_backfill_waiting = threading.Event()

    # --- Abstract Method Implementations ---

    def verify(self) -> bool:
        """Sets up dummy IDs."""
        self.ticker_id = f"t-{self.identifier}"
        self.ticker_name = f"Ticker {self.identifier}"
        self.parent_event_id = f"p-{self.identifier}"
        self.parent_event_name = f"Parent {self.identifier}"
        return True

    def is_parent_event(self) -> bool:
        return False

    def get_tickers_for_parent(self) -> list[str]:
        return []

    def get_parent_identifier(self) -> str:
        """Returns dummy parent URL."""
        return f"https://mock-platform.com/event/{self.parent_event_id}"

    def is_ticker_actively_trading(self) -> bool:
        return self.initially_open

    def is_ticker_done_trading(self) -> bool:
        return self.initially_resolved

    def add_ticker_info(self) -> None:
        self.data_queue.put(TickerInfo(
            parent_event_id=self.parent_event_id, ticker_id=self.ticker_id, ticker_name=self.ticker_name,
            platform_id=PlatformId.POLY, outcome_options=("YES", "NO"), start_timestamp=datetime.now(),
            end_timestamp=None, outcome=None, description="Test", metadata="{}"
        ))

    def add_parent_event(self) -> None:
        self.data_queue.put(ParentEvent(
            slug=self.parent_event_id, id=self.parent_event_id, name=self.parent_event_name,
            has_multiple_tickers=False, start_timestamp=datetime.now(), end_timestamp=datetime.now(),
            description="Desc", platform=PlatformId.POLY, metadata="{}"
        ))

    def backfill_all(self) -> None:
        """
        Simulates the backfill process with optional concurrency checks.
        Backfills ALL data types (Trades, L1, L2, Comments).
        """
        # --- CONCURRENCY CHECK ---
        if self.check_concurrency:
            print(f"[{self.ticker_id}] Backfill: Waiting for Stream to start...")
            self.ev_backfill_waiting.set()

            # Wait for signal from _stream_trades (running in main thread/async loop)
            is_set = self.ev_stream_started.wait(timeout=2.0)
            if not is_set:
                print("Concurrency Check Failed: Stream did not start!")
                # raise RuntimeError("Concurrency Check Failed")
            else:
                print(f"[{self.ticker_id}] Backfill: Stream detected! Proceeding.")

        if self.backfill_vol > 0:
            print(f"[{self.ticker_id}] Backfilling {self.backfill_vol} items per type...")

            # 1. Backfill Trades
            for i in range(self.backfill_vol):
                self.time_cursor += timedelta(milliseconds=1)
                self.data_queue.put(self._gen_trade(f"bf-trade-{i}", "backfill"))

            # 2. Backfill L1
            for i in range(self.backfill_vol):
                self.time_cursor += timedelta(milliseconds=1)
                self.data_queue.put(self._gen_l1("backfill"))

            # 3. Backfill L2 (If enabled)
            if self.collect_l2:
                for i in range(self.backfill_vol):
                    self.time_cursor += timedelta(milliseconds=1)
                    self.data_queue.put(self._gen_l2("backfill"))

            # 4. Backfill Comments
            for i in range(self.backfill_vol):
                self.time_cursor += timedelta(milliseconds=1)
                self.data_queue.put(self._gen_comment(f"bf-comm-{i}", "backfill"))

        if self.simulate_gap_seconds > 0:
            self.time_cursor += timedelta(seconds=self.simulate_gap_seconds)

    # --- Data Generators ---
    def _gen_trade(self, tid, meta):
        return TradeData(trade_id=tid, parent_event_id=self.parent_event_id, ticker_id=self.ticker_id,
                         platform_id=PlatformId.POLY, timestamp=self.time_cursor, price=0.50, size=10, side=Side.BUY,
                         outcome="YES", metadata=meta)

    def _gen_l1(self, meta):
        return L1Data(parent_event_id=self.parent_event_id, ticker_id=self.ticker_id, platform_id=PlatformId.POLY,
                      timestamp=self.time_cursor, best_bid=Level(0.49, 100), best_ask=Level(0.51, 100), outcome="YES",
                      metadata=meta)

    def _gen_l2(self, meta):
        return L2Data(parent_event_id=self.parent_event_id, ticker_id=self.ticker_id, platform_id=PlatformId.POLY,
                      timestamp=self.time_cursor, bids=[Level(0.49, 100)], asks=[Level(0.51, 100)], outcome="YES",
                      metadata=meta)

    def _gen_comment(self, cid, meta):
        return CommentData(parent_event_id=self.parent_event_id, ticker_id=self.ticker_id, platform_id=PlatformId.POLY,
                           timestamp=self.time_cursor, user_id="u1", user_name="User", text="msg", comment_id=cid,
                           metadata=meta, outcome="YES")

    # --- Async Streams ---

    async def _run_stream(self, volume, generator_func):
        if volume <= 0: return
        for i in range(volume):
            if not self.is_running: break
            self.time_cursor += timedelta(microseconds=10)
            item = generator_func(i)
            self.data_queue.put(item)
            if i % 1000 == 0: await asyncio.sleep(0)

    async def _stream_trades(self):
        # --- CONCURRENCY CHECK ---
        if self.check_concurrency:
            print(f"[{self.ticker_id}] Stream: Started! Signaling Backfill.")
            self.ev_stream_started.set()

        await self._run_stream(self.trade_vol, lambda i: self._gen_trade(f"live-trade-{i}", "live"))

    async def _stream_l1(self):
        await self._run_stream(self.l1_vol, lambda i: self._gen_l1("live"))

    async def _stream_l2(self):
        await self._run_stream(self.l2_vol, lambda i: self._gen_l2("live"))

    async def _stream_comments(self):
        await self._run_stream(self.comment_vol, lambda i: self._gen_comment(f"c-{i}", "live"))

    async def _start_streams(self):
        """
        Override to implement synchronization and Active Stream Filtering.
        """
        tasks = []

        # Only start configured streams (matches logic added to base class)
        if 'trades' in self.active_streams:
            tasks.append(self._stream_trades())
        if 'l1' in self.active_streams:
            tasks.append(self._stream_l1())
        if 'comments' in self.active_streams:
            tasks.append(self._stream_comments())
        if 'resolution' in self.active_streams:
            tasks.append(self._monitor_resolution())
        if self.collect_l2 and 'l2' in self.active_streams:
            tasks.append(self._stream_l2())

        # Split data tasks from monitor task
        data_tasks = [t for t in tasks if t.__name__ != "_monitor_resolution"]
        monitor_task_list = [t for t in tasks if t.__name__ == "_monitor_resolution"]
        monitor_task = monitor_task_list[0] if monitor_task_list else None

        # Run data streams
        if data_tasks:
            await asyncio.gather(*data_tasks)

        # Signal data done
        self.streams_finished.set()

        # Run monitor if active
        if monitor_task:
            await monitor_task

    async def _monitor_resolution(self) -> None:
        """
        Simulates the market resolving.
        Crucially, it waits for streams to finish BEFORE resolving to avoid race conditions in tests.
        """
        # Only wait for streams if we were actually open/running.
        # If initially_resolved=True, streams never started, so we skip waiting.
        if not self.initially_resolved:
            await self.streams_finished.wait()

        # Log resolution
        res = TickerInfo(
            parent_event_id=self.parent_event_id, ticker_id=self.ticker_id, ticker_name=self.ticker_name,
            platform_id=PlatformId.POLY, outcome_options=("YES", "NO"),
            start_timestamp=datetime.now(), end_timestamp=datetime.now(), outcome="YES",
            description="Resolved", metadata="{}"
        )
        self.data_queue.put(res)
        self.is_running = False


# --------------------------------------------------------------------------------
# Test Suite
# --------------------------------------------------------------------------------
class TestMarketInterfaceSuite(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        cls.test_run_dir = os.path.join(os.getcwd(), "test_runs_suite", f"run_{timestamp}")
        os.makedirs(cls.test_run_dir, exist_ok=True)
        print(f"\n[SUITE] Artifacts: {cls.test_run_dir}")

    def get_db(self, name):
        return os.path.join(self.test_run_dir, f"{name}.db")

    # --- 1. Lifecycle & Continuity Tests ---

    def test_concurrent_backfill_and_stream(self):
        """
        WHAT: Verifies that Live Streams start immediately, even if Backfill is slow.
        WHY: Prevents data gaps if backfilling takes a long time.
        HOW: Backfill waits for Stream to signal "I have started". If they are sequential, this deadlocks.
        """
        print("\n[TEST] Concurrent Backfill & Stream")
        db = self.get_db("concurrent")
        tracker = UltimateMockTracker(
            "concurrent", db,
            backfill_vol=10, trade_vol=10,
            check_concurrency=True
        )
        tracker.run()

        conn = LocalSQLiteClient(db)._get_conn()
        count = conn.execute("SELECT count(*) FROM trades").fetchone()[0]
        conn.close()

        # 10 backfill + 10 live = 20
        self.assertEqual(count, 20)

    def test_continuity_trades(self):
        """Verifies no gap between Backfill and Live trades."""
        db = self.get_db("continuity_trades")
        tracker = UltimateMockTracker("cont-t", db, backfill_vol=50, trade_vol=50)
        tracker.run()

        conn = LocalSQLiteClient(db)._get_conn()
        res = conn.execute("SELECT metadata FROM trades ORDER BY timestamp ASC").fetchall()
        conn.close()

        self.assertEqual(len(res), 100)
        self.assertEqual(res[0][0], "backfill")
        self.assertEqual(res[99][0], "live")

    # --- 2. Active Streams Config Tests ---

    def test_active_streams_filtering(self):
        """
        WHAT: Verifies that only requested streams (e.g., 'trades') generate data.
        WHY: Validates the resource optimization logic.
        """
        print("\n[TEST] Active Streams Filtering")
        db = self.get_db("filtered")
        # Only request 'trades', ignore 'l1' even if vol > 0
        tracker = UltimateMockTracker(
            "filtered", db,
            trade_vol=10, l1_vol=10,
            active_streams=['trades', 'resolution']
        )
        tracker.run()

        conn = LocalSQLiteClient(db)._get_conn()
        trades = conn.execute("SELECT count(*) FROM trades").fetchone()[0]
        l1 = conn.execute("SELECT count(*) FROM l1_data").fetchone()[0]
        conn.close()

        self.assertEqual(trades, 10, "Trades should be present")
        self.assertEqual(l1, 0, "L1 should be 0 because stream was not active")

    # --- 3. State Handling Tests ---

    @patch('time.sleep')
    def test_market_wait_for_open(self, mock_sleep):
        """Test waiting loop for pre-market trackers."""
        db = self.get_db("wait_open")
        tracker = UltimateMockTracker("wait", db, initially_open=False, trade_vol=10)

        def open_market():
            time.sleep(0.01)
            tracker.initially_open = True

        t = threading.Thread(target=open_market)
        t.start()
        tracker.run()
        t.join()

        self.assertTrue(mock_sleep.called)
        conn = LocalSQLiteClient(db)._get_conn()
        count = conn.execute("SELECT count(*) FROM trades").fetchone()[0]
        conn.close()
        self.assertEqual(count, 10)

    def test_market_already_resolved(self):
        """Test tracker that starts on a resolved market (Backfill only)."""
        db = self.get_db("resolved")
        tracker = UltimateMockTracker("res", db, initially_resolved=True, backfill_vol=5, trade_vol=100)
        tracker.run()
        conn = LocalSQLiteClient(db)._get_conn()
        trades = conn.execute("SELECT count(*) FROM trades").fetchone()[0]
        self.assertEqual(trades, 5)

    def test_gap_simulation(self):
        """Test valid timestamp gaps between backfill and live."""
        db = self.get_db("gap")
        GAP = 3600
        tracker = UltimateMockTracker("gap", db, backfill_vol=1, trade_vol=1, simulate_gap_seconds=GAP)
        tracker.run()

        conn = LocalSQLiteClient(db)._get_conn()
        ts1 = datetime.fromisoformat(
            conn.execute("SELECT timestamp FROM trades WHERE metadata='backfill'").fetchone()[0])
        ts2 = datetime.fromisoformat(conn.execute("SELECT timestamp FROM trades WHERE metadata='live'").fetchone()[0])
        conn.close()

        self.assertGreaterEqual((ts2 - ts1).total_seconds(), GAP)

    # --- 4. High Intensity Tests ---

    def test_firehose_trades(self):
        """Blast 10,000 trades."""
        db = self.get_db("fire_t")
        VOL = 10000
        tracker = UltimateMockTracker("fire-t", db, trade_vol=VOL)
        tracker.run()
        conn = LocalSQLiteClient(db)._get_conn()
        count = conn.execute("SELECT count(*) FROM trades").fetchone()[0]
        conn.close()
        self.assertEqual(count, VOL)

    def test_firehose_multi_stream(self):
        """Blast 500k Trades, 500k L1, 500k Comments simultaneously."""
        db = self.get_db("fire_multi")
        VOL = 500000
        tracker = UltimateMockTracker("fire-m", db, trade_vol=VOL, l1_vol=VOL, comment_vol=VOL)
        tracker.run()

        conn = LocalSQLiteClient(db)._get_conn()
        c_t = conn.execute("SELECT count(*) FROM trades").fetchone()[0]
        c_l1 = conn.execute("SELECT count(*) FROM l1_data").fetchone()[0]
        c_c = conn.execute("SELECT count(*) FROM comments").fetchone()[0]
        conn.close()

        self.assertEqual(c_t, VOL)
        self.assertEqual(c_l1, VOL)
        self.assertEqual(c_c, VOL)

    def test_shutdown_mid_backfill(self):
        """Simulate crash during backfill."""
        db = self.get_db("crash_bf")
        tracker = UltimateMockTracker("crash", db, backfill_vol=1000)
        original_put = tracker.data_queue.put

        def exploding_put(item):
            if hasattr(item, 'trade_id') and "bf-trade-500" in item.trade_id:
                raise KeyboardInterrupt("Crash!")
            original_put(item)

        tracker.data_queue.put = exploding_put

        try:
            tracker.run()
        except KeyboardInterrupt:
            pass

        conn = LocalSQLiteClient(db)._get_conn()
        count = conn.execute("SELECT count(*) FROM trades").fetchone()[0]
        conn.close()
        self.assertGreaterEqual(count, 1)

    def test_l2_disabled_flag(self):
        """Ensure L2 data is ignored if collect_l2=False."""
        db = self.get_db("no_l2")
        tracker = UltimateMockTracker("no-l2", db, collect_l2=False, l2_vol=100)
        tracker.run()

        conn = LocalSQLiteClient(db)._get_conn()
        count = conn.execute("SELECT count(*) FROM l2_data").fetchone()[0]
        conn.close()
        self.assertEqual(count, 0)


if __name__ == '__main__':
    unittest.main()