import time
import datetime
import sys
import os
import traceback
from typing import List, Set
import json
from zoneinfo import ZoneInfo

from .db import AsyncSQLiteClient
from .handler import MarketHandler
from .data_types import PlatformId

HANDLER_THREAD_LIMIT = 100
OUTPUT_DIR = "output"
COMPLETED_LOG_FILE = os.path.join(OUTPUT_DIR, "completed_markets.json")


class DualLogger:
    def __init__(self):
        self.terminal = sys.stdout
        self.log_dir = "logs"
        os.makedirs(self.log_dir, exist_ok=True)
        self.date_str = datetime.datetime.now().strftime("%Y-%m-%d")
        self.file_path = os.path.join(self.log_dir, f"{self.date_str}.log")
        self.log_file = open(self.file_path, "a", encoding="utf-8")

    def write(self, message):
        self.terminal.write(message)
        self.log_file.write(message)
        self.log_file.flush()

    def flush(self):
        self.terminal.flush()
        self.log_file.flush()


def handle_exception(exc_type, exc_value, exc_traceback):
    if issubclass(exc_type, KeyboardInterrupt):
        sys.__excepthook__(exc_type, exc_value, exc_traceback)
        return
    print("\n[CRITICAL ERROR] Unhandled Exception Detected:")
    traceback.print_exception(exc_type, exc_value, exc_traceback)


def load_completed_markets() -> Set[str]:
    if not os.path.exists(COMPLETED_LOG_FILE):
        return set()
    try:
        with open(COMPLETED_LOG_FILE, "r") as f:
            return set(json.load(f))
    except Exception as e:
        print(f"Error loading completed log: {e}")
        return set()


def get_handler_backlog(handler: MarketHandler) -> int:
    total = 0
    for interface in list(handler.interfaces.values()):
        if hasattr(interface, 'data_queue'):
            total += interface.data_queue.qsize()
    return total


def cleanup_all(handlers: List[MarketHandler]):
    for h in handlers:
        try:
            h.cleanup_trackers()
        except Exception as e:
            print(f"Error cleaning up handler {h.db_name}: {e}")


def stop_all(handlers: List[MarketHandler]):
    print("\n[Shutdown] Stopping all handlers...")
    for h in handlers:
        active_ids = list(h.trackers.keys())
        for tid in active_ids:
            h.stop_tracker(tid)

    print("[Shutdown] Flushing database writers...")
    AsyncSQLiteClient.stop_all()
    print("Done.")


# --- CONFIGURATION ---
CRYPTO_SERIES = {
    "BTC": "kxbtc15m/bitcoin-price-up-down/kxbtc15m",
    "ETH": "kxeth15m/eth-15m-price-up-down/kxeth15m",
    "SOL": "kxsol15m/solana-15-minutes/kxsol15m",
    "XRP": "kxxrp15m/xrp-15-minute/kxxrp15m"
}


def generate_kalshi_15m_url(series_path: str, target_dt: datetime.datetime) -> str:
    """Constructs a Kalshi URL based on Eastern Time (ET) format."""
    et_dt = target_dt.astimezone(ZoneInfo("America/New_York"))
    date_str = et_dt.strftime("%y%b%d%H%M").upper()
    return f"https://kalshi.com/markets/{series_path}-{date_str}"


def get_upcoming_intervals(count=2) -> List[datetime.datetime]:
    """Calculates the end times for the next 'count' 15-minute interval periods."""
    now = datetime.datetime.now(datetime.timezone.utc)
    base = now.replace(minute=(now.minute // 15) * 15, second=0, microsecond=0)

    intervals = []
    for i in range(1, count + 1):
        intervals.append(base + datetime.timedelta(minutes=15 * i))
    return intervals


if __name__ == "__main__":
    sys.stdout = DualLogger()
    sys.stderr = sys.stdout
    sys.excepthook = handle_exception

    db_name = os.path.join(OUTPUT_DIR, "kalshi_crypto_15m.db")
    _setup = MarketHandler(db_name=db_name)

    if hasattr(_setup, "provideKALSHI_API_KEY"):
        _setup = _setup.provideKALSHI_API_KEY("c015ccd8-85c6-460a-bd76-69064bc53e6e")
    if hasattr(_setup, "providePREDEXON_API_KEY"):
        _setup = _setup.providePREDEXON_API_KEY("Qi1uLwDuYzxUnRO0VaLIkKznPFQ46V9FXsurjP50")
    if hasattr(_setup, "provideDOME_API_KEY"):
        h = _setup.provideDOME_API_KEY("ea8e97578f081f779fa21af50fb9f1988651827a")

    active_handlers = [h]
    attempted_identifiers = set()

    print("--- Kalshi 15m Overlapping Tracker Active ---")

    try:
        while True:
            # Track current block AND next block (8 total active markets)
            target_times = get_upcoming_intervals(2)

            for dt in target_times:
                for coin, path in CRYPTO_SERIES.items():
                    url = generate_kalshi_15m_url(path, dt)

                    if url not in attempted_identifiers:
                        current_backlog = get_handler_backlog(h)

                        # Limit to 50,000 so L2 backfilling doesn't choke the spawner
                        if len(h.trackers) < HANDLER_THREAD_LIMIT and current_backlog < 50000:
                            print(
                                f"[{datetime.datetime.now().strftime('%H:%M:%S')}] Spawning {coin} @ {dt.strftime('%H:%M')} -> {url.split('/')[-1]}")
                            try:
                                h.track(PlatformId.KLSH, url, collect_l2=True)
                                attempted_identifiers.add(url)
                                time.sleep(0.5)
                            except Exception as e:
                                print(f"Error spawning {coin}: {e}")
                        else:
                            print(
                                f"[WARNING] Skipping {coin} {dt.strftime('%H:%M')} | Threads: {len(h.trackers)} | Backlog: {current_backlog}")

            # This will naturally reap the old batch of 4 once Kalshi sends the 'resolved' websocket ping
            cleanup_all(active_handlers)

            print(
                f"[{datetime.datetime.now().strftime('%H:%M:%S')}] Active Trackers: {len(h.trackers)} | DB Backlog: {get_handler_backlog(h)} | Total Logged: {len(attempted_identifiers)}")
            print(h.list_trackers())
            time.sleep(60)

    except KeyboardInterrupt:
        stop_all(active_handlers)
    except Exception as e:
        print(f"Fatal Loop Error: {e}")
        stop_all(active_handlers)