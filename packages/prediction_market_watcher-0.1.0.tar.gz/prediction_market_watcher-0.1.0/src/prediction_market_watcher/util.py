import pandas as pd
from typing import List, Dict, Optional
from dataclasses import dataclass, asdict, is_dataclass
from enum import Enum
from datetime import datetime, timezone
import requests
import os
import json

from .data_types import (
    TradeData, L1Data, L2Data,
    CommentData, TickerInfo, ParentEvent,
)
from .market_interface import MarketEvent


@dataclass
class MarketDataPackage:
    """
    Container for debugging. Holds a DataFrame for each data type found in the stream.
    Access via: package.trades, package.l1, etc.
    """
    parent_events: pd.DataFrame
    trades: pd.DataFrame
    l1: pd.DataFrame
    l2: pd.DataFrame
    comments: pd.DataFrame
    resolutions: pd.DataFrame

    def summary(self):
        print("\n---- Market Data Package Summary ----")
        print(f"Parent Events: {len(self.parent_events)} rows")
        print(f"Trades:        {len(self.trades)} rows")
        print(f"L1 Updates:    {len(self.l1)} rows")
        print(f"L2 Snaps:      {len(self.l2)} rows")
        print(f"Comments:      {len(self.comments)} rows")
        print(f"Resolutions:   {len(self.resolutions)} rows")
        print("---------------------------------------")


def _convert_marketevent_to_dict(record: MarketEvent) -> Dict[str, MarketEvent]:
    if not is_dataclass(record):
        return {}
    data = asdict(record)

    for key, value in data.items():
        if isinstance(value, Enum):
            data[key] = value.value

    return data


def events_to_dfs(events: List[MarketEvent]) -> MarketDataPackage:
    """
    Takes a mixed list of MarketEvents (e.g. from the queue) and sorts them into
    pandas DataFrames.
    """
    buckets = {
        'parent_events': [],
        'trades': [],
        'l1': [],
        'l2': [],
        'comments': [],
        'resolutions': []
    }

    for e in events:
        row = _convert_marketevent_to_dict(e)

        if isinstance(e, TradeData):
            buckets['trades'].append(row)
        elif isinstance(e, ParentEvent):
            buckets['parent_events'].append(row)
        elif isinstance(e, L1Data):
            buckets['l1'].append(row)
        elif isinstance(e, L2Data):
            buckets['l2'].append(row)
        elif isinstance(e, CommentData):
            buckets['comments'].append(row)
        elif isinstance(e, TickerInfo):
            buckets['resolutions'].append(row)

    def to_df(data_list):
        if not data_list:
            return pd.DataFrame()
        return pd.DataFrame(data_list)

    return MarketDataPackage(
        parent_events=to_df(buckets['parent_events']),
        trades=to_df(buckets['trades']),
        l1=to_df(buckets['l1']),
        l2=to_df(buckets['l2']),
        comments=to_df(buckets['comments']),
        resolutions=to_df(buckets['resolutions'])
    )

def unix_ts_to_utc_dt(ts: int):
    return datetime.fromtimestamp(ts, tz=timezone.utc)

def convert_iso_zulu_to_datetime(iso_timestamp: Optional[str]):
    if not iso_timestamp:
        return datetime(1970, 1, 1, tzinfo=timezone.utc)

    s = iso_timestamp.replace("Z", "+00:00")
    try:
        return datetime.fromisoformat(s)
    except ValueError:
        # Fallback for Python <3.11 with variable microsecond precision
        if "." in s:
            dot_idx = s.find(".")
            plus_idx = s.find("+", dot_idx)
            minus_idx = s.find("-", dot_idx)

            if plus_idx != -1:
                tz_idx = plus_idx
            elif minus_idx != -1:
                tz_idx = minus_idx
            else:
                tz_idx = len(s)

            head = s[:dot_idx + 1]
            frac = s[dot_idx + 1:tz_idx]
            tail = s[tz_idx:]

            # Pad or truncate to exactly 6 digits
            frac_fixed = (frac + "000000")[:6]
            return datetime.fromisoformat(f"{head}{frac_fixed}{tail}")
        # If standard parse fails and no dot, fallback to epoch or re-raise
        return datetime(1970, 1, 1, tzinfo=timezone.utc)


def polymarket_endpoint(e, which_api="gamma"):

    url_dict = {
        "gamma": "https://gamma-api.polymarket.com",
        "data": "https://data-api.polymarket.com",
        "clob": "https://clob.polymarket.com",
    }
    base_url = url_dict.get(which_api)
    if base_url is None:
        raise ValueError(f"Unknown API: {which_api}")
    return f"{base_url}/{e}"


_TAGS_CACHE = {
    "all_tags": None,   #list of all tag dicts
    "by_input": {},     #raw user input
    "by_slug": {},      #normalized slug
    "by_label": {},     #normalized label
}


def _get_tag_by_slug(slug, *, timeout=30):
    """
    Internal helper
    Attempt to resolve a tag by exact slug
    Returns tag dict if found, otherwise None.
    """
    if slug is None:
        return None

    slug_norm = str(slug).strip()
    if slug_norm == "":
        return None

    url = polymarket_endpoint(f"tags/slug/{slug_norm}")
    resp = requests.get(url, timeout=timeout)

    if resp.status_code == 404:
        return None
    if not resp.ok:
        raise RuntimeError(
            f"Gamma GET /tags/slug/{{slug}} failed: {resp.status_code} {resp.text}"
        )

    tag_obj = resp.json()
    if not isinstance(tag_obj, dict):
        raise RuntimeError(
            f"Unexpected /tags/slug response type: {type(tag_obj)}"
        )

    return tag_obj


def _list_tags(*, limit=500, offset=0, max_pages=None, timeout=30, use_cache=True):
    """
    Internal helper
    Fetch and cache the full list of tags and building lookup maps for slug and label.
    """
    if use_cache and _TAGS_CACHE["all_tags"] is not None:
        return _TAGS_CACHE["all_tags"]

    url = polymarket_endpoint("tags")
    all_tags = []
    curr_offset = int(offset)
    page_count = 0

    while True:
        if max_pages is not None and page_count >= max_pages:
            break

        params = {"limit": limit, "offset": curr_offset}
        resp = requests.get(url, params=params, timeout=timeout)
        if not resp.ok:
            raise RuntimeError(
                f"Gamma GET /tags failed: {resp.status_code} {resp.text}"
            )

        page = resp.json()
        if not isinstance(page, list):
            raise RuntimeError(
                f"Unexpected /tags response type: {type(page)}"
            )

        all_tags.extend(page)
        page_count += 1

        if len(page) < limit:
            break

        curr_offset += limit

    #build lookup maps
    _TAGS_CACHE["all_tags"] = all_tags
    for t in all_tags:
        try:
            tid = int(t.get("id"))
        except Exception:
            continue

        slug = t.get("slug")
        label = t.get("label")

        if isinstance(slug, str) and slug.strip():
            _TAGS_CACHE["by_slug"][slug.strip().lower()] = tid
        if isinstance(label, str) and label.strip():
            _TAGS_CACHE["by_label"][label.strip().lower()] = tid

    return all_tags


def _resolve_tag_id(tag_or_slug=None, *, tag_id=None, timeout=30):
    """
    Resolve a user-facing tag identifier into a Polymarket tag_id (int).

    Precedence:
      1) tag_id (explicit)
      2) slug (exact match via /tags/slug/<slug>)
      3) label (case-insensitive exact match via /tags)

    Raises on ambiguity or if no match is found
    """
    # first check for explicit tag id from user
    if tag_id is not None:
        try:
            return int(tag_id)
        except Exception as e:
            raise ValueError(
                f"tag_id must be integer-like. Got: {tag_id!r}"
            ) from e

    if tag_or_slug is None:
        raise ValueError("Provide either tag_id or tag_or_slug.")

    raw = str(tag_or_slug).strip()
    if raw == "":
        raise ValueError("tag_or_slug cannot be empty.")

    #cached resolution for exact input
    cached = _TAGS_CACHE["by_input"].get(raw)
    if cached is not None:
        return cached

    #check for slug if not tag id from user
    tag_obj = _get_tag_by_slug(raw, timeout=timeout)
    if tag_obj is not None:
        try:
            resolved_id = int(tag_obj.get("id"))
        except Exception:
            resolved_id = None

        if resolved_id is not None:
            _TAGS_CACHE["by_input"][raw] = resolved_id

            slug = tag_obj.get("slug")
            label = tag_obj.get("label")
            if isinstance(slug, str) and slug.strip():
                _TAGS_CACHE["by_slug"][slug.strip().lower()] = resolved_id
            if isinstance(label, str) and label.strip():
                _TAGS_CACHE["by_label"][label.strip().lower()] = resolved_id

            return resolved_id

    # finally cehck for tag if not tag_id or slug
    _list_tags(timeout=timeout, use_cache=True)
    raw_lower = raw.lower()

    slug_id = _TAGS_CACHE["by_slug"].get(raw_lower)
    label_id = _TAGS_CACHE["by_label"].get(raw_lower)

    if slug_id is not None and label_id is not None and slug_id != label_id:
        raise LookupError(
            "Ambiguous tag identifier. Input matches a tag slug and a different tag label. "
            "Please provide an explicit tag_id or a more specific slug/label."
        )

    resolved = slug_id if slug_id is not None else label_id
    if resolved is not None:
        _TAGS_CACHE["by_input"][raw] = resolved
        return resolved

    #no match case
    suggestions = []
    for t in _TAGS_CACHE.get("all_tags") or []:
        label = t.get("label")
        slug = t.get("slug")

        if isinstance(label, str) and raw_lower in label.lower():
            suggestions.append(label)
        elif isinstance(slug, str) and raw_lower in slug.lower():
            suggestions.append(slug)

        if len(suggestions) >= 8:
            break

    hint = f" Suggestions: {suggestions}" if suggestions else ""
    raise LookupError(f"No Polymarket tag found for '{raw}'." + hint)

def _get_events(
    *,
    #main filters
    event_slug=None,      #for identity mode
    tag_id=None,          #for discovery mode
    closed=False,         #false = active events, true = resolved events

    #pagination stuff
    limit=100,            #page size
    offset=0,             #starting offset
    max_pages=None,   
    max_events=None,   

    timeout=30,
):
    """
    - Applies server-side filters (reduces number of rows).
    - Automatically paginates until exhausted (or hits max_pages / max_events).
    - Returns raw event objects exactly as provided by the API.
    """

    #choose between identity OR discovery, not both... idea is that slugs are unique but tag_ids are not
    if event_slug is not None and tag_id is not None:
        raise ValueError("Provide only one of event_slug or tag_id (not both).")

    url = polymarket_endpoint("events")

    base_params = {
        "closed": "true" if closed else "false",    #clsoed = false:  unresolved, closed = true: resolved
    }

    if event_slug is not None:
        base_params["slug"] = event_slug

    if tag_id is not None:
        base_params["tag_id"] = int(tag_id)

    all_events = []
    page_count = 0
    curr_offset = int(offset)
    page_size = int(limit)

    #for pagination
    while True:
        if max_pages is not None and page_count >= max_pages:
            break

        params = dict(base_params)
        params["limit"] = page_size
        params["offset"] = curr_offset

        resp = requests.get(url, params=params, timeout=timeout)
        if not resp.ok:
            raise RuntimeError(
                f"Gamma GET /events failed: {resp.status_code} {resp.text}"
            )

        page = resp.json()
        if not isinstance(page, list):
            raise RuntimeError(
                f"Unexpected /events response type: {type(page)}"
            )

        all_events.extend(page)
        page_count += 1

        # Stop if we hit the max_events cap
        if max_events is not None and len(all_events) >= max_events:
            all_events = all_events[:max_events]
            break

        # If fewer than page_size results, we've reached the end
        if len(page) < page_size:
            break

        curr_offset += page_size

    print("Fetched", len(all_events), "events")
    return all_events

#add in volumne filtering
def get_polymarket_events(
    *,
    discovery_mode,
    event_slug=None,
    tag_id=None,
    tag=None,        #added for a more user-friendly tag input (slug or label)
    closed=False,

    # Pagination forwarded to get_events
    limit=100,
    offset=0,
    max_pages=None,
    max_events=None,

    # Output controls
    url_base="https://polymarket.com/event",
    timeout=30,
):
    """
    change the following as needed:

    Identity mode (discovery_mode=False):
        - event_slug -> exactly one event
        - returns a single dict

    Discovery mode (discovery_mode=True):
        - tag_id OR tag -> list of events
        - returns a list of dicts (or message + empty list)

    Output fields:
        - event_slug
        - event_url
        - event_id
        - title
    """

    #input validation and normalization
    if discovery_mode:
        if event_slug is not None:
            raise ValueError("Discovery mode does not accept event_slug")       #needed becasue slugs are unique and not wht we want

        #require exactly one of tag_id or tag
        if tag_id is None and tag is None:
            raise ValueError("Discovery mode requires tag_id or tag.")
        if tag_id is not None and tag is not None:
            raise ValueError("Provide only tag_id or tag (not both).")

        #if user gave tag, resolve to tag_id
        if tag_id is None:
            tag_id = _resolve_tag_id(tag_or_slug=tag, timeout=timeout)

    else:
        if event_slug is None:
            raise ValueError("Identity mode requires event_slug.")
        if tag_id is not None or tag is not None:
            raise ValueError("Identity mode does not accept tag_id or tag.")

    #get raw events
    events = _get_events(
        event_slug=event_slug if not discovery_mode else None,
        tag_id=tag_id if discovery_mode else None,
        closed=closed,
        limit=limit,
        offset=offset,
        max_pages=max_pages,
        max_events=max_events,
        timeout=timeout,
    )

    #if no matches in discovery mode
    if discovery_mode and len(events) == 0:
        return {
            "message": "No events matching this criteria.",
            "rows": []
        }

    #identity mode: enforce exactly one match
    if not discovery_mode:
        if len(events) == 0:
            raise LookupError(f"No event found for event_slug='{event_slug}'.")
        if len(events) > 1:
            raise LookupError(
                f"Ambiguous: multiple events returned for event_slug='{event_slug}'."
            )

    # Normalize output
    rows = []
    for ev in events:
        ev_slug = ev.get("slug")
        if not ev_slug:
            continue

        rows.append({
            "event_slug": ev_slug,
            "event_url": f"{url_base}/{ev_slug}",
            "event_id": ev.get("id"),
            "title": ev.get("title"),
        })

    return rows if discovery_mode else rows[0]
def unix_ts_ms_to_utc_dt(ts: int):
    # note: the unix timestamp (ts) must be in milliseconds!
    return datetime.fromtimestamp(ts/ 1000, tz=timezone.utc)

def utc_dt_to_unix_ts_ms(dt: datetime):
    return int(dt.timestamp() * 1000)

def create_dir(newpath):
    if not os.path.exists(newpath):
        print(f"Creating dir {newpath}")
        os.makedirs(newpath)

def save_resp_to_csv(resp, filename):
    df_list = []
    for item in resp:
        new_dict = {}
        for key, value in item.items():
            if isinstance(value, list):
                new_dict[key] = "LIST" # this should probably be saved as another df lmao
            else:
                new_dict[key] = value
        df_list.append(new_dict)
    create_dir("data")
    pd.DataFrame(df_list).to_csv(f"data/{filename}", index=False)
    print(f"Saved df to {filename}")

def save_resp_to_json(resp, filename):
    create_dir("data")
    with open(f"data/{filename}", "w") as f:
        json.dump(resp, f, indent=4)
    print(f"Saved json to {filename}")
