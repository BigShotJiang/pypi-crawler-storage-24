"""Shared test fixtures and helpers."""

from __future__ import annotations

import os
import sys
from pathlib import Path
from unittest.mock import MagicMock

import pytest

from initrunner.agent.schema.autonomy import AutonomyConfig
from initrunner.agent.schema.base import ApiVersion, Kind, Metadata, ModelConfig
from initrunner.agent.schema.guardrails import Guardrails
from initrunner.agent.schema.role import AgentSpec, RoleDefinition
from initrunner.agent.tools._registry import ToolBuildContext

# ---------------------------------------------------------------------------
# zvec stub for CI
# ---------------------------------------------------------------------------
# zvec's native extension uses CPU instructions unavailable on GitHub Actions
# runners (SIGILL).  When SKIP_ZVEC_TESTS=1, inject a lightweight stub into
# sys.modules so that `import zvec` never loads the real native code.  Tests
# that directly exercise zvec stores are skipped via collect_ignore below;
# tests that merely *transit* through zvec (e.g. ingestion pipeline) get the
# stub and won't crash.

_ZVEC_TEST_FILES = [
    "test_incremental_ingest.py",
    "test_memory_store.py",
    "test_store_dimensions.py",
    "test_store_factory.py",
    "test_vectorstore.py",
]

collect_ignore: list[str] = []
if os.environ.get("SKIP_ZVEC_TESTS") == "1":
    collect_ignore.extend(_ZVEC_TEST_FILES)

    # Insert a MagicMock as the zvec package so that any attribute access
    # (zvec.DataType.STRING, zvec.CollectionSchema(...), etc.) succeeds
    # without loading the real native extension.
    _zvec_mock = MagicMock()
    _zvec_mock.__path__ = []  # make importlib treat it as a package
    for _name in ("zvec", "zvec.model", "zvec.model.collection"):
        sys.modules.setdefault(_name, _zvec_mock)


def make_role(
    *,
    name: str = "test-agent",
    system_prompt: str = "You are a test.",
    provider: str = "openai",
    model_name: str = "gpt-5-mini",
    max_iterations: int = 10,
    autonomous_token_budget: int | None = None,
    autonomy: AutonomyConfig | None = None,
    guardrails: Guardrails | None = None,
    **spec_kwargs,
) -> RoleDefinition:
    """Build a minimal RoleDefinition for tests."""
    g = guardrails or Guardrails(
        max_iterations=max_iterations,
        autonomous_token_budget=autonomous_token_budget,
    )
    return RoleDefinition(
        apiVersion=ApiVersion.V1,
        kind=Kind.AGENT,
        metadata=Metadata(name=name),
        spec=AgentSpec(
            role=system_prompt,
            model=ModelConfig(provider=provider, name=model_name),
            guardrails=g,
            autonomy=autonomy,
            **spec_kwargs,
        ),
    )


def make_tool_build_context(
    *,
    role_dir: Path | None = None,
    **role_kwargs,
) -> ToolBuildContext:
    """Build a minimal ToolBuildContext for tool tests."""
    role = make_role(**role_kwargs)
    return ToolBuildContext(role=role, role_dir=role_dir)


def make_mock_agent(
    *,
    output: str = "Hello!",
    tokens_in: int = 10,
    tokens_out: int = 5,
    tool_calls: int = 0,
) -> MagicMock:
    """Build a mock PydanticAI Agent with configurable usage stats."""
    agent = MagicMock()
    result = MagicMock()
    result.output = output

    usage = MagicMock()
    usage.input_tokens = tokens_in
    usage.output_tokens = tokens_out
    usage.total_tokens = tokens_in + tokens_out
    usage.tool_calls = tool_calls
    result.usage.return_value = usage
    result.all_messages.return_value = [{"role": "assistant", "content": output}]

    agent.run_sync.return_value = result
    return agent


@pytest.fixture
def role():
    """Provide a default test RoleDefinition."""
    return make_role()


@pytest.fixture
def tool_ctx():
    """Provide a default ToolBuildContext."""
    return make_tool_build_context()


@pytest.fixture
def mock_agent():
    """Provide a default mock agent."""
    return make_mock_agent()
