"""
Sandai Operator SDK

A Python SDK for building high-performance, asynchronous batch processing operators.
"""

from .channel import FileChannel
from .processor import BatchProcessor
from .supervisor import RestartPolicy, Supervisor
from .types import (
    EOFMarker,
    InputArtifact,
    OptionsType,
    OutputArtifact,
    ProcessingContext,
    ResultsType,
    TaskError,
    TaskInput,
    TaskOutput,
)

__all__ = [
    "BatchProcessor",
    "FileChannel",
    "RestartPolicy",
    "Supervisor",
    "TaskInput",
    "TaskOutput",
    "TaskError",
    "InputArtifact",
    "OutputArtifact",
    "ProcessingContext",
    "OptionsType",
    "ResultsType",
    "EOFMarker",
]
