"""Memory management module."""
