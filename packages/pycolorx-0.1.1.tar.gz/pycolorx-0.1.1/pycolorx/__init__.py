class Color:

    RESET = "\033[0m"

    @staticmethod
    def rgb(r: int, g: int, b: int, text: str) -> str:
        return f"\033[38;2;{r};{g};{b}m{text}\033[0m"
    
    @staticmethod
    def hex(hex_color: str, text: str) -> str:
        hex_color = hex_color.lstrip("#")
        r = int(hex_color[0:2], 16)
        g = int(hex_color[2:4], 16)
        b = int(hex_color[4:6], 16)
        return f"\033[38;2;{r};{g};{b}m{text}\033[0m"

    
    # ---------- Style ----------
    @staticmethod
    def bold(text: str) -> str:
        return f"\033[1m{text}{Color.RESET}"

    @staticmethod
    def underline(text: str) -> str:
        return f"\033[4m{text}{Color.RESET}"

    @staticmethod
    def success(text: str) -> str:
        return f"\033[32m {text}\033[0m"

    @staticmethod
    def error(text: str) -> str:
        return f"\033[31m {text}\033[0m"

    @staticmethod
    def info(text: str) -> str:
        return f"\033[36m {text}\033[0m"
    
    # ---------- Basic Colors ----------

    @staticmethod
    def black(text: str) -> str:
        return f"\033[30m{text}\033[0m"
    
    @staticmethod
    def red(text: str) -> str:
        return f"\033[31m{text}\033[0m"

    @staticmethod
    def green(text: str) -> str:
        return f"\033[32m{text}\033[0m"

    @staticmethod
    def yellow(text: str) -> str:
        return f"\033[33m{text}\033[0m"

    @staticmethod
    def blue(text: str) -> str:
        return f"\033[34m{text}\033[0m"
    
    @staticmethod
    def magenta(text: str) -> str:
        return f"\033[35m{text}\033[0m"
    
    @staticmethod
    def cyan(text: str) -> str:
        return f"\033[36m{text}\033[0m"

    # ---------- Background Colors ----------

    @staticmethod
    def bgBlack(text: str) -> str:
        return f"\033[40m{text}\033[0m"
    
    @staticmethod
    def bgRed(text: str) -> str:
        return f"\033[41m{text}\033[0m"

    @staticmethod
    def bgGreen(text: str) -> str:
        return f"\033[42m{text}\033[0m"

    @staticmethod
    def bgYellow(text: str) -> str:
        return f"\033[43m{text}\033[0m"

    @staticmethod
    def bgBlue(text: str) -> str:
        return f"\033[44m{text}\033[0m"
    
    @staticmethod
    def bgMagenta(text: str) -> str:
        return f"\033[45m{text}\033[0m"
    
    @staticmethod
    def bgCyan(text: str) -> str:
        return f"\033[46m{text}\033[0m"

    @staticmethod
    def rainbow(text: str) -> str:
     colors = [31,33,32,36,34,35]
     result = ""
     for i, ch in enumerate(text):
         c = colors[i % len(colors)]
         result += f"\033[{c}m{ch}\033[0m"
     return result

    @staticmethod
    def gradient(text: str, start_color: tuple =(255,0,0), end_color: tuple =(250,200,0)) -> str:

        n = max(len(text)-1,1)
        result = ""

        for i,ch in enumerate(text):

            r = int(start_color[0] + (end_color[0]-start_color[0]) * i / n)
            g = int(start_color[1] + (end_color[1]-start_color[1]) * i / n)
            b = int(start_color[2] + (end_color[2]-start_color[2]) * i / n)

            result += f"\033[38;2;{r};{g};{b}m{ch}\033[0m"

        return result