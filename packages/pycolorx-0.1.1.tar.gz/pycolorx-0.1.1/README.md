# pycolorx

A Python class for colored terminal text, gradients, rainbow text, and text styles like bold and underline.

## Example

```python
from colorx import Color

print(Color.red("Hello Red"))
print(Color.bgRed("Hello background Red"))
print(Color.gradient("Hello Gradient", (255,0,0), (0,0,255)))
print(Color.bold("Bold Text"))
print(Color.rainbow("Rainbow Text"))
```


---

### **5️⃣ LICENSE**

You can use the MIT License:

```text
MIT License

Copyright (c) 2026 Kenijan

Permission is hereby granted, free of charge, to any person obtaining a copy...
```