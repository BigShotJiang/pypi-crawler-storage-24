from setuptools import setup, find_packages

setup(
    name="pycolorx",
    version="0.1.1",
    author="kenijan",
    author_email="kenijanvip@gmail.com",
    description="A Python class for colored terminal text, gradients, and styles",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    url="https://github.com/kenijan/color",
    packages=find_packages(),
    python_requires=">=3.7",
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
)