import curses
import time
import textwrap
import subprocess
import random
import sys
import os
import threading

from lantern_chat.client.state import Message

# ------ UI class ------
# next time im not using curses lmao - textual??? it seems better but idk 
# TODO - make UI nicer, colors, improve menus, dnd color highlighting, icons etc

def show_ban_screen(stdscr, reason):
    curses.curs_set(0)
    curses.use_default_colors()
    try:
        curses.init_pair(1, curses.COLOR_RED, -1)
    except curses.error:
        pass 

    art = [
        r"▄▄▄▄▄▄▄     ▄▄▄▄   ▄▄▄    ▄▄▄ ▄▄▄    ▄▄▄  ▄▄▄▄▄▄▄ ▄▄▄▄▄▄   ",
        r"███▀▀███▄ ▄██▀▀██▄ ████▄  ███ ████▄  ███ ███▀▀▀▀▀ ███▀▀██▄ ",
        r"███▄▄███▀ ███  ███ ███▀██▄███ ███▀██▄███ ███▄▄    ███  ███ ",
        r"███  ███▄ ███▀▀███ ███  ▀████ ███  ▀████ ███      ███  ███ ",
        r"████████▀ ███  ███ ███    ███ ███    ███ ▀███████ ██████▀  ",
        r"                                                           ",
    ]
    h, w = stdscr.getmaxyx()
    stdscr.erase() 

    art_height = len(art)
    art_width = max(len(line) for line in art)
    start_y = max(1, (h - art_height) // 2 - 2)
    start_x = max(0, (w - art_width) // 2)

    for i, line in enumerate(art):
        try:
            stdscr.addstr(start_y + i, start_x, line[: max(0, w - start_x)], curses.color_pair(1) | curses.A_BOLD)
        except curses.error:
            pass

    reason_text = reason or "You have been banned from this server."
    info_lines = [
        "You have been banned from this server.",
        f"Reason: {reason_text}",
        "",
        "Press any key to quit",
    ]
    y = start_y + art_height + 2
    for line in info_lines:
        try:
            stdscr.addstr(y, max(0, (w - len(line)) // 2), line[: max(0, w - 2)])
        except curses.error:
            pass
        y += 1

    stdscr.refresh()
    stdscr.nodelay(False)
    stdscr.getch()



class UI:

    # command definitions for autocomplete 
    COMMANDS = [
        ("/exit", "Exit the chat"),
        ("/logout", "Log out and close"),
        ("/back", "Return to main channel"),
        ("/dm ", "Open DM with user"),
        ("/panel", "List users to DM"),
        ("/fetch", "Send system info (30s cooldown)"),
        ("/dnd", "Toggle do not disturb"),
        ("/stats", "Show user statistics"),
        ("/img", "Send an image (file picker)"),
        ("/disp <secs> <msg>", "Send a disappearing message"),
        ("/clear ", "Clear messages from main chat for session"),
        ("/mute ", "Mute a user (admin)"),
        ("/unmute ", "Unmute a user (admin)"),
        ("/ban ", "Ban a user (admin)"),
        ("/unban ", "Unban a user (admin)"),
        ("/changeusername ", "Change username (admin)"),
        ("/channel", "Switch to channel view"),
        ("/help", "Show help menu"),
    ]

    def __init__(self, config, state, network, command_handler):
        self.config = config
        self.state = state
        self.network = network
        self.command_handler = command_handler
        self.input_buf = ""
        self.input_cursor = 0
        self.scroll_offset = 0
        self.dm_scroll_offset = 0
        self.autocomplete_active = False 
        self.autocomplete_matches = []
        self.autocomplete_selected = 0
        self.input_history = []
        self.history_idx = -1       # -1 = not browsing history
        self._history_draft = ""    # saves current draft while browsing
        # maps quantized (r,g,b) -> curses color pair number for image rendering
        self._img_color_cache = {}
        self._next_img_slot = 20  # UI uses pairs 1-4 and colors 1,2,3,4,10 — start well clear


    def _get_img_color_pair(self, r, g, b):
        # quantize to reduce number of pairs needed
        qr, qg, qb = (r >> 5) << 5, (g >> 5) << 5, (b >> 5) << 5
        key = (qr, qg, qb)
        if key in self._img_color_cache:
            return self._img_color_cache[key]
        slot = self._next_img_slot
        if slot >= min(curses.COLORS, curses.COLOR_PAIRS):
            self._img_color_cache[key] = 0
            return 0
        try:
            curses.init_color(slot, qr * 1000 // 255, qg * 1000 // 255, qb * 1000 // 255)
            curses.init_pair(slot, slot, -1)
        except curses.error:
            self._img_color_cache[key] = 0
            return 0
        self._next_img_slot += 1
        self._img_color_cache[key] = slot
        return slot

    def get_autocomp_matches(self, text: str):
        if not text.startswith("/"):
            return []

        text_lower = text.lower() 
        matches = []
        for cmd, desc in self.COMMANDS:
            if cmd.lower().startswith(text_lower):
                matches.append((cmd, desc))
            elif text_lower in cmd.lower():
                matches.append((cmd, desc))
        return matches[:8] # max of 8 suggestions, can change later

    
    def draw_autocomplete(self, stdscr, input_y, chat_w, prompt):
        if not self.autocomplete_active or not self.autocomplete_matches:
            return
        
        h, w = stdscr.getmaxyx() 
        max_visible = min(len(self.autocomplete_matches), 10) 
        win_h = max_visible 
        win_w = min(chat_w - 2, 50)

        win_y = input_y - win_h - 1 
        if win_y < 0: 
            win_y = input_y + 1
            win_h = min(max_visible, h - win_y - 2)
            max_visible = win_h 

        win_x = len(prompt)
        win_x = min(win_x, w - win_w - 1)

        for i in range(max_visible):
            y = win_y + i + 1 
            if y >= h: 
                break 

            cmd, desc = self.autocomplete_matches[i]
            is_selected = i == self.autocomplete_selected 

            try: 
                stdscr.addstr(y, win_x, " " * win_w)
            except curses.error:
                pass

            if is_selected:
                display = f" {cmd:<18} {desc}"[:win_w - 2]
                try: 
                    selected_attr = curses.color_pair(2) | curses.A_REVERSE
                    stdscr.addstr(y, win_x, display, selected_attr)
                except curses.error:
                    pass
            else:
                # draw cmd normally
                display = f" {cmd:<18} {desc}"[:win_w - 2]
                try:
                    stdscr.addstr(y, win_x, display, curses.A_NORMAL)
                except curses.error:
                    pass 
                

    def draw_status_bar(self, stdscr, h, w, y):
        now = time.time()
        uptime = int(now - self.state.start_time)
        hrs = uptime // 3600
        mins = (uptime % 3600) // 60
        secs = uptime % 60
        uptime_str = (
            f"{hrs:02d}:{mins:02d}:{secs:02d}" if hrs else f"{mins:02d}:{secs:02d}"
        )
        clock = time.strftime("%H:%M:%S")
        ping_str = (
            f"{self.network.ping_ms}ms" if self.network.ping_ms is not None else "—"
        )

        with self.state.lock:
            user_count = len(self.state.users)
            view = self.state.current_view
            dm_target = self.state.dm_target

        if view == "dm" and dm_target:
            status = f" {clock} │ DM: {dm_target[:20]} │ ping: {ping_str} │ dnd {'on' if self.state.dnd else 'off'}  │ /back "
        else:
            status = f" {clock} │ users: {user_count} │ ping: {ping_str} │ up: {uptime_str} │ dnd: {'on' if self.state.dnd else 'off'}"
        stdscr.addstr(y, 0, status[: w - 1].ljust(w - 1), curses.A_DIM)

    def show_help(self, stdscr):
        h, w = stdscr.getmaxyx()
        if h >= 22 and w >= 70:
            # bloatware
            art1 = [
                r" _          _                  ",
                r" | |__ _ _ _| |_ ___ _ _ _ _    ",
                r" | / _` | ' \  _/ -_) '_| ' \ _ ",
                r" |_\__,_|_||_\__\___|_| |_||_(_)",
                r"     lightweight terminal chat   ",
            ]
            art2 = [
                r"▄▄▌   ▄▄▄·  ▐ ▄ ▄▄▄▄▄▄▄▄ .▄▄▄   ▐ ▄    ",
                r"██•  ▐█ ▀█ •█▌▐█•██  ▀▄.▀·▀▄ █·•█▌▐█   ",
                r"██▪  ▄█▀▀█ ▐█▐▐▌ ▐█.▪▐▀▀▪▄▐▀▀▄ ▐█▐▐▌   ",
                r"▐█▌▐▌▐█ ▪▐▌██▐█▌ ▐█▌·▐█▄▄▌▐█•█▌██▐█▌   ",
                r".▀▀▀  ▀  ▀ ▀▀ █▪ ▀▀▀  ▀▀▀ .▀  ▀▀▀ █▪ ▀",
                r"     lightweight terminal chat  ",
            ]
            art3 = [
                r" _             _                    ",
                r"| | ___ ._ _ _| |_ ___  _ _ ._ _    ",
                r"| |<_> || ' | | | / ._>| '_>| ' | _ ",
                r"|_|<___||_|_| |_| \___.|_|  |_|_|<_>",
                r"       lightweight terminal chat      ",
            ]
            art4 = [
                r"  __             __                       ",
                r" |  .---.-.-----|  |_.-----.----.-----.   ",
                r" |  |  _  |     |   _|  -__|   _|     |__ ",
                r" |__|___._|__|__|____|_____|__| |__|__|__|",
                r"       lightweight terminal chat           ",
            ]
            art5 = [
                r"    __            __                 ",
                r"   / /___ _____  / /____  _________  ",
                r"  / / __ `/ __ \/ __/ _ \/ ___/ __ \ ",
                r" / / /_/ / / / / /_/  __/ /  / / / / ",
                r"/_/\__,_/_/ /_/\__/\___/_/  /_/ /_(_)",
                r"      lightweight terminal chat",
            ]
            art = random.choice([art1, art2, art3, art4, art5])
            art_lines = len(art)
            body = [
                "Commands:",
                "  /exit      Quit chat",
                "  /logout    Log out (next run: login again)",
                "  /back      Back to main channel",
                "  /dm <user> Open DM with user",
                "  /panel     List users, pick one to DM",
                "  /fetch     Send system info (30s cooldown)",
                "  /dnd       Do not disturb (toggle notifications)",
                "  /clear     Clear messages from main chat for session",
                "  /img       Send an image (file picker)",
                "  /disp <s> <msg>  Send a disappearing message",
                "",
                "Keybinds:",
                "  Ctrl+H     Help menu",
                "  Ctrl+K     Show keybinds",
                "  Ctrl+F     Fetch system info",
                "  Ctrl+B     Switch to channel view",
                "  Ctrl+P     Open user panel",
                "  Ctrl+D     Toggle DND",
                "  Ctrl+L     Logout",
                "  Ctrl+W     Exit (with confirm)",
                "  Esc Esc    Exit (immediate)",
                "",
                "Press any key to close",
            ]
            lines = art + body
        else:
            art_lines = 0
            lines = [
                "Lantern Help",
                "",
                "/exit    Quit chat",
                "/logout  Log out (next run: login again)",
                "/help    Show this menu",
                "/back    Back to main channel",
                "/dm <user>  Open DM with user",
                "/panel   List users, pick one to DM",
                "/fetch   Send system info (30s cooldown)",
                "/dnd     Do not disturb (toggle notifications)",
                "/img     Send an image (file picker)",
                "/disp <s> <msg>  Send a disappearing message",
                "",
                "Press any key to close",
            ]
        win_h = len(lines) + 2
        win_w = min(w - 4, max(len(l) for l in lines) + 4)
        y = (h - win_h) // 2
        x = (w - win_w) // 2
        win = curses.newwin(win_h, win_w, y, x)
        win.border()
        try:
            title_attr = curses.color_pair(2) | curses.A_BOLD
            accent_attr = curses.color_pair(4) | curses.A_BOLD
            cmd_attr = curses.color_pair(4) | curses.A_BOLD
        except curses.error:
            title_attr = curses.A_BOLD
            accent_attr = curses.A_BOLD
            cmd_attr = curses.A_BOLD
        for i, line in enumerate(lines, 1):
            if art_lines and i <= art_lines:
                # Color the ASCII art header
                attr = title_attr
            elif art_lines and i == art_lines + 2:
                # "Commands:" header
                attr = accent_attr
            elif art_lines and i == art_lines + 2 + 10:
                # "Keybinds:" header (after ~10 body lines)
                attr = accent_attr
            elif line.startswith("  /") or line.startswith("  Ctrl"):
                # Highlight the command/key token in pastel purple
                try:
                    if line.startswith("  /") or line.startswith("  Ctrl"):
                        prefix = "  "
                        rest_line = line[2:]
                    else:
                        prefix = ""
                        rest_line = line
                    key, rest = rest_line.split(" ", 1)
                    win.addstr(i, 2, prefix)
                    win.addstr(i, 2 + len(prefix), key, cmd_attr)
                    win.addstr(i, 2 + len(prefix) + len(key) + 1, rest)
                    continue
                except ValueError:
                    attr = curses.A_NORMAL
            else:
                attr = curses.A_NORMAL
            win.addstr(i, 2, line[: win_w - 4], attr)
        win.refresh()
        win.getch()
        win.clear()
        stdscr.touchwin()
        stdscr.refresh()

    def show_keybinds(self, stdscr):
        h, w = stdscr.getmaxyx()
        # TODO - add more keybinds to this list cos im adding some new ones later
        lines = [
            "Keybinds",
            "ctrl+h   Help menu",
            "ctrl+k   Show keybinds",
            "ctrl+f   Fetch system info",
            "ctrl+p   Open user panel (DM picker)",
            "ctrl+d   Toggle Do Not Disturb",
            "ctrl+v   Paste image from clipboard",
            "ctrl+l   Logout",
            "ctrl+w   Exit (with confirm)",
            "Esc x2   Exit (immediate)",
            "Press any key to close",
        ]
        win_h = len(lines) + 2
        win_w = max(len(l) for l in lines) + 4
        y = (h - win_h) // 2
        x = (w - win_w) // 2
        win = curses.newwin(win_h, win_w, y, x)
        win.border()
        try:
            header_attr = curses.color_pair(2) | curses.A_BOLD
            key_attr = curses.color_pair(4) | curses.A_BOLD
        except curses.error:
            header_attr = curses.A_BOLD
            key_attr = curses.A_BOLD
        for i, line in enumerate(lines, 1):
            if i == 1:
                attr = header_attr
            else:
                # highlight the "ctrl+X" part if present
                try:
                    key, rest = line.split(" ", 1)
                    win.addstr(i, 2, key, key_attr)
                    win.addstr(i, 2 + len(key) + 1, rest)
                    continue
                except ValueError:
                    attr = curses.A_NORMAL
            win.addstr(i, 2, line, attr)
        win.refresh()
        win.getch()
        win.clear()
        stdscr.touchwin()
        stdscr.refresh()

    def show_user_panel(self, stdscr):
        self.network.request_users_detailed()
        time.sleep(0.15)
        for _ in range(20):
            with self.state.lock:
                ul = list(self.state.users_detailed)
            if ul:
                break
            time.sleep(0.1)
        with self.state.lock:
            ul = list(self.state.users_detailed)
        if not ul:
            ul = [(u, "?", 0) for u in sorted(self.state.users)]
        if not ul:
            return
        # filter out current user from the list
        ul = [u for u in ul if u[0] != self.config.USERNAME]
        h, w = stdscr.getmaxyx()
        win_h = min(len(ul) + 4, h - 4)
        win_w = min(52, w - 4)
        y = (h - win_h) // 2
        x = (w - win_w) // 2
        win = curses.newwin(win_h, win_w, y, x)
        win.border()
        win.keypad(True)
        win.nodelay(False)
        try:
            header_attr = curses.color_pair(2) | curses.A_BOLD
            win.addstr(0, 3, " Select user to DM ", header_attr)
        except curses.error:
            pass
        # Column headers
        try:
            win.addstr(1, 2, "User              Status   Last seen", curses.A_DIM)
        except curses.error:
            pass
        sel = 0
        while True:
            for i, (u, status, ts) in enumerate(ul[: win_h - 4]):
                try:

                    display_name = f"{u} [ADMIN]" if u in self.state.admins else u
                    ts_str = (
                        time.strftime("%m/%d %H:%M", time.localtime(ts)) if ts else "—"
                    )
                    line = f" {display_name[:16]:16}  {status:8} {ts_str}"
                    is_selected = i == sel
                    if is_selected:
                        attr = curses.color_pair(1) | curses.A_REVERSE
                    elif status.lower().startswith("off"):
                        attr = curses.A_DIM
                    else:
                        attr = curses.A_NORMAL
                    win.addstr(i + 2, 2, line[: win_w - 4], attr)
                except curses.error:
                    pass
            try:
                win.addstr(win_h - 2, 2, "Enter: open DM  Esc: cancel", curses.A_DIM)
            except curses.error:
                pass
            win.refresh()
            ch = win.getch()
            if ch in (27, ord("q")):
                break
            if ch == curses.KEY_UP and sel > 0:
                sel -= 1
            if ch == curses.KEY_DOWN and sel < min(len(ul), win_h - 3) - 1:
                sel += 1
            if ch in (10, 13):
                target = ul[sel][0]
                if target == self.config.USERNAME:
                    break
                with self.state.lock:
                    self.state.dm_target = target
                    self.state.current_view = "dm"
                    self.state.ensure_dm_conversation(target)
                self.state.pending_dm_history = target
                self.network.request_dm_history(target)
                break
        win.clear()
        stdscr.touchwin()
        stdscr.refresh()

    def show_file_picker(self, stdscr):
        IMAGE_EXTS = {".png", ".jpg", ".jpeg", ".gif", ".bmp", ".webp"}
        cwd = os.path.expanduser("~")
        sel = 0
        scroll = 0

        def get_entries(directory):
            entries = []
            try:
                names = sorted(os.listdir(directory))
            except PermissionError:
                return [("..", True, None)]
            if directory != "/":
                entries.append(("..", True, None))
            for name in names:
                if name.startswith("."):
                    continue
                full = os.path.join(directory, name)
                is_dir = os.path.isdir(full)
                ext = os.path.splitext(name)[1].lower()
                if is_dir or ext in IMAGE_EXTS:
                    entries.append((name, is_dir, full))
            return entries

        win = None
        last_win_size = (0, 0)
        while True:
            entries = get_entries(cwd)
            h, w = stdscr.getmaxyx()
            win_h = min(len(entries) + 6, h - 8)
            win_w = min(60, w - 4)
            y = (h - win_h) // 2
            x = (w - win_w) // 2
            if win is None or last_win_size != (win_h, win_w):
                if win is not None:
                    win.erase()
                    win.refresh()
                    del win
                stdscr.touchwin()
                stdscr.refresh()
                win = curses.newwin(win_h, win_w, y, x)
                win.keypad(True)
                win.nodelay(False)
                last_win_size = (win_h, win_w)
            else:
                win.erase()
            win.border()
            visible = win_h - 5
            sel = max(0, min(sel, len(entries) - 1))
            scroll = max(0, min(scroll, max(0, len(entries) - visible)))
            if sel < scroll:
                scroll = sel
            elif sel >= scroll + visible:
                scroll = sel - visible + 1

            try:
                win.addstr(0, 3, " Select Image ", curses.color_pair(2) | curses.A_BOLD)
                cwd_display = cwd if len(cwd) <= win_w - 4 else "…" + cwd[-(win_w - 7):]
                win.addstr(1, 2, cwd_display, curses.A_DIM)
            except curses.error:
                pass

            for i, (name, is_dir, full) in enumerate(entries[scroll: scroll + visible]):
                row = i + 2
                idx = scroll + i
                label = (name + "/") if is_dir else name
                label = label[: win_w - 5]
                attr = curses.color_pair(1) | curses.A_REVERSE if idx == sel else (curses.color_pair(2) | curses.A_DIM if is_dir else curses.A_NORMAL)
                try:
                    win.addstr(row, 2, label, attr)
                except curses.error:
                    pass

            try:
                win.addstr(win_h - 2, 2, "↑↓ Navigate  Enter: Select  Esc: Cancel", curses.A_DIM)
            except curses.error:
                pass

            win.refresh()
            ch = win.getch()
            if ch == 27:
                win.clear()
                stdscr.touchwin()
                stdscr.refresh()
                return None
            if ch == curses.KEY_UP and sel > 0:
                sel -= 1
            elif ch == curses.KEY_DOWN and sel < len(entries) - 1:
                sel += 1
            elif ch in (10, 13):
                name, is_dir, full = entries[sel]
                if is_dir:
                    if name == "..":
                        cwd = os.path.dirname(cwd)
                    else:
                        cwd = full
                    sel = 0
                    scroll = 0
                else:
                    win.clear()
                    stdscr.touchwin()
                    stdscr.refresh()
                    return full

    def _prompt_text(self, stdscr, title: str, prompt: str, max_len: int = 256):
        h, w = stdscr.getmaxyx()
        lines = [title, "", prompt, "", ""]
        win_h = 7
        win_w = min(w - 4, max(len(prompt), len(title)) + 6)
        y = (h - win_h) // 2
        x = (w - win_w) // 2
        win = curses.newwin(win_h, win_w, y, x)
        win.border()
        win.keypad(True)
        win.nodelay(False)

        try:
            header_attr = curses.color_pair(2) | curses.A_BOLD
        except curses.error:
            header_attr = curses.A_BOLD

        # static text
        win.addstr(1, 2, title[: win_w - 4], header_attr)
        win.addstr(2, 2, prompt[: win_w - 4])
        win.addstr(win_h - 2, 2, "Enter: confirm  Esc: cancel"[: win_w - 4], curses.A_DIM)

        buf = ""
        cursor = 0

        while True:
            # draw input line
            visible = buf[: win_w - 4]
            win.addstr(3, 2, " " * (win_w - 4))
            win.addstr(3, 2, visible)
            win.move(3, 2 + min(cursor, win_w - 5))
            win.refresh()

            ch = win.getch()
            if ch in (27, ord("q")):
                return None
            if ch in (10, 13):
                return buf.strip()[:max_len]
            if ch in (curses.KEY_BACKSPACE, 127, 8):
                if cursor > 0:
                    buf = buf[: cursor - 1] + buf[cursor:]
                    cursor -= 1
            elif ch == curses.KEY_LEFT:
                if cursor > 0:
                    cursor -= 1
            elif ch == curses.KEY_RIGHT:
                if cursor < len(buf):
                    cursor += 1
            elif 32 <= ch <= 126 and len(buf) < max_len:
                c = chr(ch)
                buf = buf[:cursor] + c + buf[cursor:]
                cursor += 1

    def prompt_ban_reason(self, stdscr, target: str):
        prompt = f"Enter ban reason for '{target}' (optional):"
        reason = self._prompt_text(stdscr, "Ban user", prompt, max_len=256)
        if reason is None:
            return None
        return reason.strip()


    def confirm_exit(self, stdscr):
        h, w = stdscr.getmaxyx()
        lines = [
            "Are you sure you want to exit?",
            "Press Enter to confirm, any other key to cancel.",
        ]
        win_h = len(lines) + 2
        win_w = max(len(l) for l in lines) + 4
        y = (h - win_h) // 2
        x = (w - win_w) // 2
        win = curses.newwin(win_h, win_w, y, x)
        win.border()
        win.keypad(True)
        win.nodelay(False)
        for i, line in enumerate(lines, start=1):
            win.addstr(i, 2, line)
        win.refresh()
        ch = win.getch()
        return ch in (10, 13)

    def run(self, stdscr):

        curses.cbreak()
        curses.curs_set(0)
        curses.use_default_colors()
        curses.init_pair(1, curses.COLOR_GREEN, -1)
        curses.init_pair(2, curses.COLOR_CYAN, -1)
        curses.init_pair(3, curses.COLOR_RED, -1)
        try:
            curses.init_color(10, 800, 627, 1000)
            curses.init_pair(4, 10, -1)
        except Exception:
            curses.init_pair(4, curses.COLOR_MAGENTA, -1)

        stdscr.nodelay(True)
        stdscr.keypad(True)
        curses.mousemask(curses.ALL_MOUSE_EVENTS | curses.REPORT_MOUSE_POSITION)
        self.input_buf = ""
        self.network.request_user_list()
        self.input_cursor = 0
        self.network.request_max_msg_len()

        while self.state.running:
            stdscr.erase()
            h, w = stdscr.getmaxyx()
            user_w = 22
            chat_w = max(10, w - user_w - 1)
            chat_h = h - 3

            with self.state.lock:
                view = self.state.current_view
                dm_target = self.state.dm_target
                if view == "dm" and dm_target:
                    chat_snapshot = list(self.state.dm_conversations.get(dm_target, []))
                else:
                    chat_snapshot = list(self.state.messages)
                user_snapshot = sorted(self.state.users)

            lines = []
            for entry in chat_snapshot:
                text, is_self, ts = entry.text, entry.is_self, entry.ts
                img_rows = entry.img_rows

                if img_rows is not None:
                    # image entry: label line + one line per image row
                    ts_prefix = time.strftime("[%H:%M] ", time.localtime(ts)) if ts > 0 else ""
                    display = text
                    if is_self and self.config.USERNAME and text.startswith(f"[{self.config.USERNAME}]: "):
                        display = "[you] " + text[len(f"[{self.config.USERNAME}]: "):]
                    label = ts_prefix + display
                    lines.append((label, is_self, text, False, len(ts_prefix), None))
                    for row in img_rows:
                        lines.append((None, is_self, text, False, 0, row))
                    continue

                display_text = text
                is_system = text.startswith("[system]")
                if (
                    is_self
                    and self.config.USERNAME
                    and text.startswith(f"[{self.config.USERNAME}]: ")
                ):
                    display_text = text[len(f"[{self.config.USERNAME}]: ") :]
                elif (
                    is_self
                    and self.config.USERNAME
                    and text.startswith(f"[{self.config.USERNAME}] ")
                ):
                    display_text = text[len(f"[{self.config.USERNAME}] ") :]
                prefix = "[you] " if is_self and not is_system else ""
                ts_prefix = ""
                if ts > 0 and not is_system and not text.endswith(" joined]") and not text.endswith(" left]"):
                    ts_prefix = time.strftime("[%H:%M] ", time.localtime(ts))
                for l in textwrap.wrap(ts_prefix + prefix + display_text, chat_w) or [""]:
                    ts_len = len(ts_prefix) if l.startswith(ts_prefix) else 0
                    lines.append((l, is_self, text, is_system, ts_len, None))

            total_lines = len(lines)
            scroll = (
                self.dm_scroll_offset
                if (view == "dm" and dm_target)
                else self.scroll_offset
            )
            max_scroll = max(0, total_lines - chat_h)
            scroll = min(scroll, max_scroll)
            if view == "dm" and dm_target:
                self.dm_scroll_offset = scroll
            else:
                self.scroll_offset = scroll

            start = max(0, total_lines - chat_h - scroll)
            end = total_lines - scroll
            visible_lines = lines[start:end]

            for i, (line, is_self, original_text, is_system, ts_len, img_row) in enumerate(
                visible_lines
            ):
                if img_row is not None:
                    # render colored image row pixel by pixel
                    col = 0
                    for char, r, g, b in img_row:
                        if col >= chat_w:
                            break
                        pair = self._get_img_color_pair(r, g, b)
                        try:
                            stdscr.addstr(i, col, char, curses.color_pair(pair))
                        except curses.error:
                            pass
                        col += 1
                elif is_system:
                    stdscr.addstr(i, 0, line, curses.color_pair(4))
                elif original_text.startswith("[") and original_text.endswith(
                    " joined]"
                ):
                    stdscr.addstr(i, 0, line, curses.color_pair(2) | curses.A_DIM)
                elif original_text.startswith("[") and original_text.endswith(" left]"):
                    stdscr.addstr(i, 0, line, curses.color_pair(3) | curses.A_DIM)
                else:
                    # images: don't apply green highlight so colors show through
                    is_img_label = original_text.endswith("[image]")
                    attr = (curses.color_pair(1) if is_self and not is_img_label else 0)
                    if ts_len > 0:
                        stdscr.addstr(i, 0, line[:ts_len], curses.A_DIM)
                        stdscr.addstr(i, ts_len, line[ts_len:], attr)
                    else:
                        stdscr.addstr(i, 0, line, attr)

            stdscr.vline(0, chat_w, "|", chat_h)
            for i, u in enumerate(user_snapshot[:chat_h]):
                label = u
                if u in self.state.admins:
                    label = f"{u} [ADMIN]"
                stdscr.addstr(i, chat_w + 2, label[: user_w - 2])

            INPUT_Y = h - 3
            SEP_Y = h - 2
            STATUS_Y = h - 1
            prompt = "> "
            # visible = self.input_buf[-(chat_w - len(prompt) - 1) :] - old code, here until i can test the new scrolling input buffer code

            max_input_width = max(1, chat_w - len(prompt) - 1)

            # Determine which slice of the input buffer to show so that the cursor is visible
            if len(self.input_buf) <= max_input_width:
                start_idx = 0
            else:
                if self.input_cursor <= max_input_width:
                    start_idx = 0
                else:
                    start_idx = self.input_cursor - max_input_width
            end_idx = start_idx + max_input_width
            visible = self.input_buf[start_idx:end_idx]

            stdscr.move(INPUT_Y, 0)
            stdscr.clrtoeol()
            stdscr.addstr(INPUT_Y, 0, f"{prompt}{visible}")

            # draw cursor
            rel_idx = self.input_cursor - start_idx
            cursor_x = len(prompt) + max(0, rel_idx)
            cursor_x = max(len(prompt), min(chat_w - 1, cursor_x))
            try:
                cursor_attr = curses.color_pair(4) | curses.A_BOLD
            except curses.error:
                cursor_attr = curses.A_BOLD
            try:
                stdscr.addstr(INPUT_Y, cursor_x, "|", cursor_attr)
            except curses.error:
                pass
            stdscr.hline(SEP_Y, 0, curses.ACS_HLINE, w)
            # draw status bar 
            self.draw_status_bar(stdscr, h, w, y=STATUS_Y)
            # draw autocomplete if active 
            self.draw_autocomplete(stdscr, INPUT_Y, chat_w, prompt)
            stdscr.refresh()
            try:
                ch = stdscr.getch()
                if ch == -1:
                    time.sleep(0.02)
                    continue
                # ---- double escape to quit immediately ----
                if ch == 27:
                    # when autocomplete active, esc closes it if u dont want it to show 
                    if self.autocomplete_active:
                        self.autocomplete_active = False
                        self.autocomplete_matches = []
                        continue
                    ch2 = stdscr.getch()
                    if ch2 == 27:
                        self.command_handler.shutdown()
                    else:
                        continue

                # ---- keybinds ----
                # - ord('a') - caps lock fix

                # help menu for ctrl + h - ensure fixed on widnows, doesnt trigger when pressing backspace lol
                # REMOVED for now
                # ctrl + / for keybinds
                if ch == 11:  # ctrl+k
                    self.show_keybinds(stdscr)
                    continue
                # ctrl + w for exit with confirm
                if ch in (23, ord("w") - ord("a") + 1):
                    if self.confirm_exit(stdscr):
                        self.command_handler.shutdown()
                    continue
                # ctrl + f for fetch
                if ch in (6, ord("f") - ord("a") + 1):
                    if self.command_handler.handle_command("/fetch", stdscr):
                        continue
                # ctrl + p for panel
                if ch == (ord("p") - ord("a") + 1):
                    if self.command_handler.handle_command("/panel", stdscr):
                        continue
                # ctrl + d for dnd toggle
                if ch == (ord("d") - ord("a") + 1):
                    if self.command_handler.handle_command("/dnd", stdscr):
                        continue
                # ctrl + b to return to main channel
                if ch == (ord("b") - ord("a") + 1):
                    if self.command_handler.handle_command("/back", stdscr):
                        continue
                # ctrl + v to paste image from clipboard
                if ch == 22:
                    from lantern_chat.client.net import get_clipboard_image
                    img_data, img_name = get_clipboard_image()
                    if img_data:
                        with self.state.lock:
                            dm_target_now = self.state.dm_target if self.state.current_view == "dm" else None
                        threading.Thread(
                            target=self.network.send_img_bytes,
                            args=(img_data, img_name, dm_target_now),
                            daemon=True,
                        ).start()
                        continue
                    # no image in clipboard — fall through to normal char handling

                scroll_off = (
                    self.dm_scroll_offset
                    if (view == "dm" and dm_target)
                    else self.scroll_offset
                )
                if ch == curses.KEY_MOUSE:
                    try:
                        _, _, _, _, bstate = curses.getmouse()
                        if bstate & curses.BUTTON4_PRESSED:  # scroll up
                            if view == "dm" and dm_target:
                                self.dm_scroll_offset += 3
                            else:
                                self.scroll_offset += 3
                        elif bstate & curses.BUTTON5_PRESSED:  # scroll down
                            if view == "dm" and dm_target:
                                self.dm_scroll_offset = max(0, self.dm_scroll_offset - 3)
                            else:
                                self.scroll_offset = max(0, self.scroll_offset - 3)
                    except curses.error:
                        pass
                    continue

                if ch == curses.KEY_UP:
                    # nav autocomplete if active 
                    if self.autocomplete_active and self.autocomplete_matches:
                        self.autocomplete_selected = (self.autocomplete_selected - 1) % len(self.autocomplete_matches)
                        continue

                    # browse input history if scroll is at bottom
                    scroll_at_bottom = (
                        (view == "dm" and dm_target and self.dm_scroll_offset == 0) or
                        (not (view == "dm" and dm_target) and self.scroll_offset == 0)
                    )
                    if self.input_history and scroll_at_bottom:
                        if self.history_idx == -1:
                            self._history_draft = self.input_buf
                            self.history_idx = len(self.input_history) - 1
                        elif self.history_idx > 0:
                            self.history_idx -= 1
                        self.input_buf = self.input_history[self.history_idx]
                        self.input_cursor = len(self.input_buf)
                        continue

                    if view == "dm" and dm_target:
                        self.dm_scroll_offset += 1
                    else:
                        self.scroll_offset += 1
                    continue
                if ch == curses.KEY_DOWN:
                    # nav autocomplete if active 
                    if self.autocomplete_active and self.autocomplete_matches:
                        self.autocomplete_selected = (self.autocomplete_selected + 1) % len(self.autocomplete_matches)
                        continue

                    # browse input history forward
                    if self.history_idx != -1:
                        if self.history_idx < len(self.input_history) - 1:
                            self.history_idx += 1
                            self.input_buf = self.input_history[self.history_idx]
                        else:
                            self.history_idx = -1
                            self.input_buf = self._history_draft
                        self.input_cursor = len(self.input_buf)
                        continue

                    if view == "dm" and dm_target and self.dm_scroll_offset > 0:
                        self.dm_scroll_offset -= 1
                    elif not (view == "dm" and dm_target) and self.scroll_offset > 0:
                        self.scroll_offset -= 1
                    continue

                if ch in (10, 13):

                    if self.autocomplete_active and self.autocomplete_matches:
                        selected_cmd = self.autocomplete_matches[self.autocomplete_selected][0]
                        self.input_buf = selected_cmd # + " " # add space for convenience, will test
                        self.input_cursor = len(self.input_buf)
                        self.autocomplete_active = False
                        self.autocomplete_matches = []
                        continue

                    self.input_cursor = 0
                    msg = self.input_buf.strip()
                    self.input_buf = ""
                    self.history_idx = -1
                    self._history_draft = ""
                    if not msg:
                        continue
                    if msg and (not self.input_history or self.input_history[-1] != msg):
                        self.input_history.append(msg)
                        self.input_history = self.input_history[-100:]  # cap at 100
                    if self.command_handler.handle_command(msg, stdscr):
                        continue

                    msg = msg[: self.config.MAX_MESSAGE_LEN]

                    if view == "dm" and dm_target:
                        out = f"[{self.config.USERNAME}]: {msg}"
                        self.network.send_dm(dm_target, msg)
                        with self.state.lock:
                            no_response = (
                                time.time() - self.state.last_received_from_server
                                > self.config.SERVER_RESPONSE_TIMEOUT
                            )
                            if self.state.send_failed or no_response:
                                self.state.send_failed = False
                                self.state.append_dm(
                                    dm_target,
                                    "[system] Failed to send (connection error)",
                                    True,
                                )
                            else:
                                self.state.append_dm(dm_target, out, True, time.time())
                    else:
                        # need to add stuff here 
                        out = f"[{self.config.USERNAME}]: {msg}"
                        self.network.send_message(out)
                        with self.state.lock:
                            no_response = (
                                time.time() - self.state.last_received_from_server
                                > self.config.SERVER_RESPONSE_TIMEOUT
                            )
                            if self.state.send_failed or no_response:
                                self.state.send_failed = False
                                self.state.messages.append(
                                    Message(text="[system] Failed to send (connection error)", is_self=True, ts=0)
                                )
                            else:
                                self.state.messages.append(Message(text=out, is_self=True, ts=time.time()))
                            self.state.messages[:] = self.state.messages[
                                -self.config.MAX_MESSAGES :
                            ]

                elif ch in (curses.KEY_BACKSPACE, 127, 8):
                    if self.input_cursor > 0:
                        self.input_buf = (
                            self.input_buf[: self.input_cursor - 1]
                            + self.input_buf[self.input_cursor :]
                        )
                        self.input_cursor -= 1

                    if self.input_buf.startswith("/"):
                        self.autocomplete_matches = self.get_autocomp_matches(self.input_buf)
                        if self.autocomplete_matches:
                            self.autocomplete_active = True
                            self.autocomplete_selected = 0
                        else:
                            self.autocomplete_active = False
                    else:
                        self.autocomplete_active = False 
                        self.autocomplete_matches = [] 
                elif ch == curses.KEY_DC:
                    if self.input_cursor < len(self.input_buf):
                        self.input_buf = (
                            self.input_buf[: self.input_cursor]
                            + self.input_buf[self.input_cursor + 1 :]
                        )
                elif ch == curses.KEY_LEFT:
                    if self.input_cursor > 0:
                        self.input_cursor -= 1
                elif ch == curses.KEY_RIGHT:
                    if self.input_cursor < len(self.input_buf):
                        self.input_cursor += 1
                elif ch in (curses.KEY_HOME,):
                    self.input_cursor = 0
                elif ch in (curses.KEY_END,):
                    self.input_cursor = len(self.input_buf)
                elif ch == (ord("a") - ord("a") + 1):  # Ctrl+A -> Home
                    self.input_cursor = 0
                elif ch == (ord("e") - ord("a") + 1):  # Ctrl+E -> End
                    self.input_cursor = len(self.input_buf)
                elif (
                    32 <= ch <= 126 and len(self.input_buf) < self.config.MAX_INPUT_LEN
                ):
                    ch_val = chr(ch)
                    self.input_buf = (
                        self.input_buf[: self.input_cursor]
                        + ch_val
                        + self.input_buf[self.input_cursor :]
                    )
                    self.input_cursor += 1

                    if self.input_buf.startswith("/"):
                        self.autocomplete_matches = self.get_autocomp_matches(self.input_buf)
                        if self.autocomplete_matches:
                            self.autocomplete_active = True
                            self.autocomplete_selected = 0
                        else:
                            self.autocomplete_active = False
                    else:
                        self.autocomplete_active = False
                        self.autocomplete_matches = []
                elif ch == 9:  # tab cycles 
                    if self.autocomplete_active and self.autocomplete_matches:
                        self.autocomplete_selected = (self.autocomplete_selected + 1) % len(self.autocomplete_matches)
                        continue
                elif ch == 27:  
                    # let double esc handler do its thing
                    pass
            except Exception:
                pass
