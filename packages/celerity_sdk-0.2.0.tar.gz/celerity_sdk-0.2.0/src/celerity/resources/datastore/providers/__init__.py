"""Datastore provider implementations."""
