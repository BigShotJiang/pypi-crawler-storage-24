"""DynamoDB datastore provider."""
