## $Id: test_configuration.py 18166 2025-09-03 07:38:18Z henrik $
##
## Copyright (C) 2011 Uli Fouquet & Henrik Bettermann
## This program is free software; you can redistribute it and/or modify
## it under the terms of the GNU General Public License as published by
## the Free Software Foundation; either version 2 of the License, or
## (at your option) any later version.
##
## This program is distributed in the hope that it will be useful,
## but WITHOUT ANY WARRANTY; without even the implied warranty of
## MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
## GNU General Public License for more details.
##
## You should have received a copy of the GNU General Public License
## along with this program; if not, write to the Free Software
## Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
##
"""Tests for configuration containers and related.
"""
import os
import shutil
import tempfile
import unittest
from zope.component import queryUtility
from zope.component.hooks import setSite, clearSite
from zope.component.interfaces import IFactory
from zope.interface import verify
from waeup.kofa.testing import FunctionalLayer, FunctionalTestCase
from waeup.kofa.app import University
from waeup.kofa.configuration import (
    ConfigurationContainer, SessionConfiguration, SessionConfigurationFactory,
    ConfigurationContainerExporter, SessionConfigurationExporter,
    ConfigurationContainerProcessor, SessionConfigurationProcessor)
from waeup.kofa.interfaces import(ICSVExporter, IBatchProcessor,
    IConfigurationContainer, ISessionConfiguration, ISessionConfigurationAdd)

class ConfigurationTest(FunctionalTestCase):

    layer = FunctionalLayer

    def setUp(self):
        super(ConfigurationTest, self).setUp()
        self.confcontainer = ConfigurationContainer()
        self.sessionconf = SessionConfiguration()
        return

    def tearDown(self):
        super(ConfigurationTest, self).tearDown()
        return

    def test_interfaces(self):
        verify.verifyClass(IConfigurationContainer, ConfigurationContainer)
        verify.verifyObject(IConfigurationContainer, self.confcontainer)
        verify.verifyClass(ISessionConfiguration, SessionConfiguration)
        verify.verifyObject(ISessionConfiguration, self.sessionconf)
        verify.verifyClass(ISessionConfigurationAdd, SessionConfiguration)
        verify.verifyObject(ISessionConfigurationAdd, self.sessionconf)

class SessionConfigurationFactoryTest(FunctionalTestCase):

    layer = FunctionalLayer

    def setUp(self):
        super(SessionConfigurationFactoryTest, self).setUp()
        self.factory = SessionConfigurationFactory()

    def tearDown(self):
        super(SessionConfigurationFactoryTest, self).tearDown()

    def test_interfaces(self):
        verify.verifyClass(IFactory, SessionConfigurationFactory)
        verify.verifyObject(IFactory, self.factory)

    def test_factory(self):
        obj = self.factory()
        assert isinstance(obj, SessionConfiguration)

    def test_getInterfaces(self):
        implemented_by = self.factory.getInterfaces()
        assert implemented_by.isOrExtends(ISessionConfiguration)


class ConfigurationImportExportSetup(FunctionalTestCase):

    layer = FunctionalLayer

    def setUp(self):
        super(ConfigurationImportExportSetup, self).setUp()
        # Setup a sample site for each test
        app = University()
        self.dc_root = tempfile.mkdtemp()
        app['datacenter'].setStoragePath(self.dc_root)
        self.getRootFolder()['app'] = app
        self.app = self.getRootFolder()['app']
        setSite(app)
        self.workdir = tempfile.mkdtemp()
        self.outfile = os.path.join(self.workdir, 'myoutput.csv')
        return

    def tearDown(self):
        super(ConfigurationImportExportSetup, self).tearDown()
        shutil.rmtree(self.workdir)
        shutil.rmtree(self.dc_root)
        clearSite()
        return

class BaseConfigurationExportTests(ConfigurationImportExportSetup):

    def test_ifaces(self):
        # make sure we fullfill interface contracts
        obj = ConfigurationContainerExporter()
        verify.verifyObject(ICSVExporter, obj)
        verify.verifyClass(ICSVExporter, ConfigurationContainerExporter)
        return

    def test_get_as_utility(self):
        # we can get a faculty exporter as utility
        result = queryUtility(ICSVExporter, name="base_configuration")
        self.assertTrue(result is not None)
        return

    def test_export_all(self):
        exporter = ConfigurationContainerExporter()
        exporter.export_all(self.app, self.outfile)
        result = open(self.outfile, 'rb').read()
        self.assertTrue(
            'acronym,carry_over,current_academic_session,days_pw,email_admin,'
            'email_subject,export_disabled_message,frontpage,'
            'maintmode_enabled_by,name,name_admin,next_matric_integer,'
            'next_matric_integer_2,next_matric_integer_3,'
            'next_matric_integer_4,smtp_mailer,curr_stud_id\r\n'
            'WAeUP.Kofa,0,,0,contact@waeup.org,Kofa Contact,,'
            '"<h1>Welcome to WAeUP.Kofa\n<br>' in result
            )
        return

class SessionConfigurationExportTests(ConfigurationImportExportSetup):

    def test_ifaces(self):
        # make sure we fullfill interface contracts
        obj = SessionConfigurationExporter()
        verify.verifyObject(ICSVExporter, obj)
        verify.verifyClass(ICSVExporter, SessionConfigurationExporter)
        return

    def test_get_as_utility(self):
        # we can get a faculty exporter as utility
        result = queryUtility(ICSVExporter, name="sessionconfigurations")
        self.assertTrue(result is not None)
        return

    def test_export_all(self):
        self.sessionconfig = SessionConfiguration()
        self.sessionconfig.academic_session = 2022
        self.sessionconfig.clearance_fee = 3000.6
        self.app['configuration'].addSessionConfiguration(self.sessionconfig)
        exporter = SessionConfigurationExporter()
        exporter.export_all(self.app, self.outfile)
        result = open(self.outfile, 'rb').read()
        self.assertEqual(result,
            'academic_session,booking_fee,clearance_enabled,clearance_fee,'
            'coursereg_deadline,late_registration_fee,maint_fee,'
            'payment_disabled,transcript_fee,transfer_fee\r\n'
            '2022,0.0,0,3000.6,,0.0,0.0,[],0.0,0.0\r\n'
            )
        return

BASECONFIG_SAMPLE_DATA = open(
    os.path.join(os.path.dirname(__file__), 'sample_baseconfig_data.csv'),
    'rb').read()

BASECONFIG_HEADER_FIELDS = BASECONFIG_SAMPLE_DATA.split(
    '\n')[0].split(',')

class BaseConfigurationProcessorTests(ConfigurationImportExportSetup):

    layer = FunctionalLayer

    def setUp(self):
        super(BaseConfigurationProcessorTests, self).setUp()
        self.processor = ConfigurationContainerProcessor()

    def test_interface(self):
        # Make sure we fulfill the interface contracts.
        assert verify.verifyObject(IBatchProcessor, self.processor) is True
        assert verify.verifyClass(
            IBatchProcessor, ConfigurationContainerProcessor) is True

    def test_import(self):
        self.csv_file = os.path.join(
            self.workdir, 'sample_baseconfig_data.csv')
        open(self.csv_file, 'wb').write(BASECONFIG_SAMPLE_DATA)
        num, num_warns, fin_file, fail_file = self.processor.doImport(
            self.csv_file, BASECONFIG_HEADER_FIELDS,'update')
        self.assertEqual(num_warns,0)
        configcontainer = self.processor.getEntry(dict(), self.app)
        self.assertEqual(configcontainer.frontpage, 'Hello World')

SESSIONCONFIG_SAMPLE_DATA = open(
    os.path.join(os.path.dirname(__file__), 'sample_sessionconfig_data.csv'),
    'rb').read()

SESSIONCONFIG_HEADER_FIELDS = SESSIONCONFIG_SAMPLE_DATA.split(
    '\n')[0].split(',')

class SessionConfigurationProcessorTests(ConfigurationImportExportSetup):

    layer = FunctionalLayer

    def setUp(self):
        super(SessionConfigurationProcessorTests, self).setUp()
        self.processor = SessionConfigurationProcessor()

    def test_interface(self):
        # Make sure we fulfill the interface contracts.
        assert verify.verifyObject(IBatchProcessor, self.processor) is True
        assert verify.verifyClass(
            IBatchProcessor, SessionConfigurationProcessor) is True

    def test_import(self):
        self.csv_file = os.path.join(
            self.workdir, 'sample_sessionconfig_data.csv')
        open(self.csv_file, 'wb').write(SESSIONCONFIG_SAMPLE_DATA)
        num, num_warns, fin_file, fail_file = self.processor.doImport(
            self.csv_file, SESSIONCONFIG_HEADER_FIELDS,'create')
        self.assertEqual(num_warns,0)
        sessionconfig = self.processor.getEntry({'academic_session':'2017'}, self.app)
        self.assertEqual(sessionconfig.payment_disabled[0], 'sf_all')


