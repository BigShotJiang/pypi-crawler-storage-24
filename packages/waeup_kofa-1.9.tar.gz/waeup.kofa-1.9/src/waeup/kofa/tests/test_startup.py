# Tests for local startup functions.
import mock
import os
import shutil
import sys
import tempfile
import unittest
# from zdaemon.zdctl import 
import zdaemon.zdctl
from zope.app.wsgi import WSGIPublisherApplication
# from zdaemon.tests.testzdctl import run as run_zdctl
from waeup.kofa.startup import (
        env_app_factory, env_debug_app_factory, zdaemon_controller,
        )
try:
    from StringIO import StringIO  # py2
except ImportError:
    from io import StringIO        # py3



ZOPE_CONF_TEMPL = '''
site-definition %s

<zodb>
  <mappingstorage />
</zodb>

<eventlog>
  <logfile>
    path STDOUT
  </logfile>
</eventlog>
'''


ZDAEMON_CONF_TEMPL = '''
<runner>
  program echo "zdaemon started"
</runner>
'''


class StartUpTests(unittest.TestCase):

    def setUp(self):
        self.workdir = tempfile.mkdtemp()
        self.site_zcml = os.path.join(self.workdir, 'site.zcml')
        open(self.site_zcml, 'w').write('<configure />')
        self.zope_conf = os.path.join(self.workdir, 'zope.conf')
        open(self.zope_conf, 'wb').write(ZOPE_CONF_TEMPL % self.site_zcml)
        self.zdaemon_conf = os.path.join(self.workdir, 'zdaemon.conf')
        open(self.zdaemon_conf, 'wb').write(ZDAEMON_CONF_TEMPL)
        return

    def tearDown(self):
        shutil.rmtree(self.workdir)
        for name in ('TEST_FOO', 'TEST_BAR'):
            if name in os.environ:
                del os.environ[name]
        return

    def test_env_app_factory(self):
        # We can create plain WSGI apps
        factory = env_app_factory({'zope_conf': self.zope_conf})
        self.assertTrue(
            isinstance(factory, WSGIPublisherApplication))
        return

    def test_env_app_factory_single_env_var(self):
        # We can create WSGI apps with a single env var set
        factory = env_app_factory({'zope_conf': self.zope_conf,
                                   'env_vars': 'TEST_FOO value1'})
        self.assertEqual(os.environ.get('TEST_FOO', None), 'value1')
        return

    def test_env_app_factory_multiple_env_vars(self):
        # We can create WSGI apps with multiple env vars set
        env_vars = 'TEST_FOO  value1   \n  TEST_BAR  value2'
        factory = env_app_factory({'zope_conf': self.zope_conf,
                                   'env_vars': env_vars})
        self.assertEqual(os.environ.get('TEST_FOO', None), 'value1')
        self.assertEqual(os.environ.get('TEST_BAR', None), 'value2')
        return

    def test_env_debug_app_factory(self):
        # We can create debugger WSGI apps
        factory = env_debug_app_factory({'zope_conf': self.zope_conf})
        self.assertTrue(
            isinstance(factory, WSGIPublisherApplication))
        return
        pass

    def test_env_debug_app_factory_single_env_var(self):
        # We can create debugger WSGI apps with a single env var set
        factory = env_debug_app_factory({'zope_conf': self.zope_conf,
                                         'env_vars': 'TEST_FOO value1'})
        self.assertEqual(os.environ.get('TEST_FOO', None), 'value1')
        return

    @mock.patch("sys.stdout", new_callable=StringIO)
    def test_zdaemon_has_debug_help(self, mock_out):
        # We provide a `debug` help text for `kofactl`
        with mock.patch.object(sys, "argv", ["kofactl",  "help", "debug"]):
            with self.assertRaises(SystemExit):
                zdaemon_controller(zdaemon_conf=self.zdaemon_conf)
        self.assertTrue("providing a debugger" in mock_out.getvalue())

    @mock.patch("waeup.kofa.startup.interactive_debug_prompt")
    def test_zdaemon_can_start_debug(self, mock_prompt):
        # We can actually run the debugger...
        with mock.patch.object(sys, "argv", ["kofactl", "debug"]):
            with self.assertRaises(SystemExit):
                zdaemon_controller(zdaemon_conf=self.zdaemon_conf)
        self.assertTrue(mock_prompt.called)
