## $Id: configuration.py 17787 2024-05-15 06:42:58Z henrik $
##
## Copyright (C) 2011 Uli Fouquet & Henrik Bettermann
## This program is free software; you can redistribute it and/or modify
## it under the terms of the GNU General Public License as published by
## the Free Software Foundation; either version 2 of the License, or
## (at your option) any later version.
##
## This program is distributed in the hope that it will be useful,
## but WITHOUT ANY WARRANTY; without even the implied warranty of
## MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
## GNU General Public License for more details.
##
## You should have received a copy of the GNU General Public License
## along with this program; if not, write to the Free Software
## Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
##
"""
Components for portal configuration.
"""
import grok
from zope.component.interfaces import IFactory
from zope.interface import implementedBy, Interface
from waeup.kofa.utils.batching import ExporterBase
from waeup.kofa.interfaces import ICSVExporter
from waeup.kofa.interfaces import (
    ISessionConfiguration, IConfigurationContainer, ISessionConfigurationAdd,
    IBatchProcessor,
    academic_sessions_vocab)
from waeup.kofa.utils.helpers import attrs_to_fields, iface_names
from waeup.kofa.utils.batching import BatchProcessor
from waeup.kofa.interfaces import MessageFactory as _

class ConfigurationContainer(grok.Container):
    """
    The node containing the session configuration models
    """

    grok.implements(IConfigurationContainer)

    frontpage_dict = dict()

    def addSessionConfiguration(self, sessionconfiguration):
        """Add a session configuration object.
        """
        if not ISessionConfiguration.providedBy(sessionconfiguration):
            raise TypeError(
                'ConfigurationContainers contain only '
                'ISessionConfiguration instances')
        code = unicode(sessionconfiguration.academic_session)
        self[code] = sessionconfiguration
        return

ConfigurationContainer = attrs_to_fields(ConfigurationContainer)


class ConfigurationContainerFactory(grok.GlobalUtility):
    """A factory for configuration container. This factory is only needed
    for import.
    """
    grok.implements(IFactory)
    grok.name(u'waeup.ConfigurationContainer')

    def __call__(self, *args, **kw):
        return ConfigurationContainer(*args, **kw)

    def getInterfaces(self):
        return implementedBy(ConfigurationContainer)

class SessionConfiguration(grok.Model):
    """
    Session configuration model
    """

    grok.implements(ISessionConfiguration, ISessionConfigurationAdd)

    def getSessionString(self):
        """Return the session string from the vocabulary.
        """
        return academic_sessions_vocab.getTerm(self.academic_session).title

SessionConfiguration = attrs_to_fields(SessionConfiguration)

class SessionConfigurationFactory(grok.GlobalUtility):
    """A factory for session configuration objects.
    """
    grok.implements(IFactory)
    grok.name(u'waeup.SessionConfiguration')
    title = u"Create a new session configuration object.",
    description = u"This factory instantiates new session configurations."

    def __call__(self, *args, **kw):
        return SessionConfiguration(*args, **kw)

    def getInterfaces(self):
        return implementedBy(SessionConfiguration)

class ConfigurationContainerExporter(grok.GlobalUtility, ExporterBase):
    """The Configuration Container Exporter exports all configuration base data.
    It also exports the last used student id.
    """
    grok.implements(ICSVExporter)
    grok.name('base_configuration')

    title = _(u'Base Configuration')
    fields = tuple(sorted(iface_names(
        IConfigurationContainer, omit=['captcha',]))) + ('curr_stud_id',)

    def mangle_value(self, value, name, context=None):
        if name == 'curr_stud_id':
            value = context.__parent__['students']._curr_stud_id
        return super(
            ConfigurationContainerExporter, self).mangle_value(
            value, name, context=context)

    def export_all(self, site, filepath=None):
        """Export base configuration into filepath as CSV data.
        If `filepath` is ``None``, a raw string with CSV data is returned.
        """
        writer, outfile = self.get_csv_writer(filepath)
        configuration = site.get('configuration')
        self.write_item(configuration, writer)
        return self.close_outfile(filepath, outfile)

class SessionConfigurationExporter(grok.GlobalUtility, ExporterBase):
    """The Session Configuration Exporter exports all configuration data.
    It iterates over all objects of the ``configuration`` container.
    """
    grok.implements(ICSVExporter)
    grok.name('sessionconfigurations')

    title = _(u'Session Configurations')

    fields = tuple(sorted(iface_names(ISessionConfiguration)))

    def export(self, configurations, filepath=None):
        """Export `configurations`, an iterable, as CSV file.

        If `filepath` is ``None``, a raw string with CSV data is returned.
        """
        writer, outfile = self.get_csv_writer(filepath)
        for configuration in configurations:
            self.write_item(configuration, writer)
        return self.close_outfile(filepath, outfile)

    def export_all(self, site, filepath=None):
        """Export session configurations into filepath as CSV data.

        If `filepath` is ``None``, a raw string with CSV data is returned.
        """
        configurations = site.get('configuration', {})
        return self.export(configurations.values(), filepath)

class ConfigurationContainerProcessor(BatchProcessor):
    """The Configuration Container Processor processes processes the
    portal's base confoiguration data. This container exists in the portal.
    Thus only the update method is allowed.

    """
    grok.implements(IBatchProcessor)
    grok.provides(IBatchProcessor)
    grok.context(Interface)
    util_name = 'configurationcontainerupdater'
    grok.name(util_name)

    name = u'ConfigurationConainer Processor (update only)'
    iface = IConfigurationContainer
    factory_name = 'waeup.ConfigurationContainer'

    @property
    def available_fields(self):
        return tuple(
            sorted(iface_names(
                IConfigurationContainer,
                omit=['captcha',]))) + ('curr_stud_id',)

    def parentsExist(self, row, site):
        return True

    def entryExists(self, row, site):
        return True

    def getParent(self, row, site):
        return site

    def getEntry(self, row, site):
        return site['configuration']

    def updateEntry(self, obj, row, site, filename):
        """Update obj to the values given in row.
        """
        if 'curr_stud_id' in row:
            studid = row.get('curr_stud_id')
            site['students']._curr_stud_id = int(studid)
        row.pop('curr_stud_id')
        super(ConfigurationContainerProcessor, self).updateEntry(
            obj, row, site, filename)
        return

class SessionConfigurationProcessor(BatchProcessor):
    """The (Session) Configuration Processor processes session configuration
    objects in the ``configuration`` container.
    """
    grok.implements(IBatchProcessor)
    grok.provides(IBatchProcessor)
    grok.context(Interface)
    util_name = 'sessionconfigurationprocessor'
    grok.name(util_name)

    name = u'SessionConfiguration Processor'
    iface = ISessionConfiguration
    factory_name = 'waeup.SessionConfiguration'

    def parentsExist(self, row, site):
        return 'configuration' in site.keys()

    def entryExists(self, row, site):
        return row['academic_session'] in site['configuration'].keys()

    def getParent(self, row, site):
        return site['configuration']

    def getEntry(self, row, site):
        if not self.entryExists(row, site):
            return None
        parent = self.getParent(row, site)
        return parent.get(row['academic_session'])

    def addEntry(self, obj, row, site):
        parent = self.getParent(row, site)
        parent.addSessionConfiguration(obj)
        return

    def delEntry(self, row, site):
        configuration = self.getEntry(row, site)
        if user is not None:
            parent = self.getParent(row, site)
            grok.getSite().logger.info(
                '%s - %s - Session configuration removed' % (self.name, row['academic_session']))
            del parent[configuration.academic_session]
        pass


