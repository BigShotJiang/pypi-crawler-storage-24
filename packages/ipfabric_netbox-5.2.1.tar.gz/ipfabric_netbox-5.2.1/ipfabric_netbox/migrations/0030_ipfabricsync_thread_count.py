import django.core.validators
from django.db import migrations
from django.db import models


class Migration(migrations.Migration):
    dependencies = [
        ("ipfabric_netbox", "0029_ipfabricsource_owner"),
    ]

    operations = [
        migrations.AddField(
            model_name="ipfabricsync",
            name="thread_count",
            field=models.PositiveIntegerField(
                default=1,
                help_text="Number of threads used to sync records within each model stage (default: 1 = single-threaded).",
                validators=[django.core.validators.MinValueValidator(1)],
            ),
        ),
    ]
