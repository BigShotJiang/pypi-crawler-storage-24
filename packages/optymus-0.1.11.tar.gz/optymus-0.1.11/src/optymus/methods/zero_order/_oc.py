# optimality "criterial"

