"""Input schemas for Kevros AgentKit actions."""

from __future__ import annotations

from typing import Any, Dict, Optional

from pydantic import BaseModel, Field


class VerifyActionSchema(BaseModel):
    """Verify an action against governance policy before executing it."""

    action_type: str = Field(
        description="Type of action to verify (e.g., 'trade', 'transfer', 'deploy', 'api_call')"
    )
    action_payload: Dict[str, Any] = Field(
        description="The action details to verify"
    )
    agent_id: str = Field(
        description="Your agent's identifier"
    )
    policy_context: Optional[Dict[str, Any]] = Field(
        default=None,
        description="Optional policy constraints (max_values, forbidden_keys)",
    )


class AttestProvenanceSchema(BaseModel):
    """Record an action in the tamper-evident provenance ledger."""

    agent_id: str = Field(
        description="Your agent's identifier"
    )
    action_description: str = Field(
        description="What you did (human-readable description)"
    )
    action_payload: Dict[str, Any] = Field(
        description="Full action details for the record"
    )
    context: Optional[Dict[str, Any]] = Field(
        default=None,
        description="Additional context for the attestation",
    )


class BindIntentSchema(BaseModel):
    """Cryptographically bind a declared intent to a command."""

    agent_id: str = Field(
        description="Your agent's identifier"
    )
    intent_type: str = Field(
        description=(
            "Intent category: NAVIGATION, MANIPULATION, SENSING, COMMUNICATION, "
            "MAINTENANCE, EMERGENCY, OPERATOR_COMMAND, AI_GENERATED, AUTOMATED"
        )
    )
    intent_description: str = Field(
        description="What you intend to accomplish"
    )
    command_payload: Dict[str, Any] = Field(
        description="The command being bound to this intent"
    )
    goal_state: Optional[Dict[str, Any]] = Field(
        default=None,
        description="Target state to verify against after execution",
    )


class BindWalletSchema(BaseModel):
    """Bind a wallet address to a governance agent identity."""

    agent_id: str = Field(
        description="Your agent's identifier"
    )
    wallet_address: Optional[str] = Field(
        default=None,
        description="Wallet address to bind (auto-detected from WalletProvider if omitted)",
    )
    network: str = Field(
        default="eip155:8453",
        description="Network identifier (CAIP-2 format, default: Base mainnet)",
    )
    wallet_type: str = Field(
        default="agentic",
        description="Wallet type: 'agentic', 'server', 'embedded', or 'smart'",
    )


class CheckPeerTrustSchema(BaseModel):
    """Check another agent's governance reputation."""

    agent_id: str = Field(
        description="The agent ID to look up"
    )
