"""
Build provenance record — auto-generated, do not edit.

This file is embedded by the CI/CD pipeline at build time.
It provides hash verification and optional cryptographic
signature verification for this package distribution.
"""

PROVENANCE = {
    'schema_version': '1.0',
    'artifact_hash': 'sha512:4efaeea3b7cc162c3c13950e4cef720bf29af98a83d3ef1e263d32c2aa6caaf2e338407307aa8ba2f70d71d70ac311054b7d050a823308350ad5ebf6699fab69',
    'version': '0.1.8',
    'registry': 'pypi',
    'package_name': 'coinbase-agentkit-kevros',
    'build_timestamp': '2026-03-08T19:57:59Z',
    'build_host_hash': 'sha256:a67e39d1e616c143fa8cde43e1a76acf3012068b1109911b3fc4aa780cb69ef4',
    'git_commit': '9e4d6808ad6b638dc9f6e4b933f6be90a0bc3790',
    'git_branch': 'sdk-v0.3.8',
    'signer': 'github-actions-oidc',
    'signature_algorithm': '',
    'signature': '',
    'public_key': '',
    'dependencies_hash': 'sha256:7f16a1ecfe3e3c4ecc06824c953a575b989de847b5ced05397d41e7bf0b2ffbf',
}


def get_provenance() -> dict:
    """Return a copy of the build provenance record."""
    return dict(PROVENANCE)
