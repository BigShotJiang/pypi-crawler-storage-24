"""Sound Event Detection (SED) logic.

This module provides the `SED` class for detecting sound events based on
power thresholds and state tracking.
"""

import numpy as np


class SED:
    """Sound Event Detection (SED) logic using power thresholds.

    Implement detection logic based on configurable dB thresholds and
    frame counts for signal detection.

    This class has the **side effect** of maintaining detection state.
    It is **not thread-safe**.
    """

    def __init__(
        self,
        thresholds: list[float] | None = None,
        index: list[int] | None = None,
        frame_size: int = 64,
        num_classes: int = 1,
        mutex: bool = False,
    ) -> None:
        """Initialize the `SED` detector.

        Args:
            thresholds: List of dB thresholds [high, mid, low] for detection state
                (default: [-38.0, -41.0, -48.0]).
            index: List of class indices to trigger detection for (default: [1]).
            frame_size: Size of the audio processing frame (default: 64).
            num_classes: Total number of detection classes (default: 1).
            mutex: If `True`, detection classes are mutually exclusive (default: `False`).
        """
        self._thresholds = [-38.0, -41.0, -48.0] if thresholds is None else thresholds
        self._index = [1] if index is None else index
        self._frame_size = frame_size
        self._num_classes = num_classes
        self._mutex = mutex

        self._thresholds_lin = self.db_to_lin(self._thresholds)
        self._vad_init = 15

        if self.mutex:
            if self._num_classes <= 1:
                raise ValueError("num_classes must be greater than 1 when in mutex mode")
            if np.count_nonzero(self.index) > 1:
                raise ValueError("index must contain one one non-zero element when in mutex mode")
            self._max_class = self.num_classes - 1
        else:
            self._max_class = self.num_classes

        if len(self.index) > self._max_class:
            raise ValueError(f"index must not contain more than {self._max_class} elements")
        if any(x < 0 for x in self.index):
            raise ValueError("index must contain only positive elements")
        if any(x > self._max_class for x in self.index):
            raise ValueError(f"index elements must not be greater than {self._max_class}")

        self._index_nz = [x - 1 for x in self.index if x > 0]
        self._vad_cnt = self._vad_init

    @property
    def thresholds(self) -> list[float]:
        """Detection thresholds in dB."""
        return self._thresholds

    @property
    def index(self) -> list[int]:
        """Class indices to be triggered."""
        return self._index

    @property
    def frame_size(self) -> int:
        """Size of the audio processing frame."""
        return self._frame_size

    @property
    def num_classes(self) -> int:
        """Total number of detection classes."""
        return self._num_classes

    @property
    def mutex(self) -> bool:
        """Whether detection classes are mutually exclusive."""
        return self._mutex

    def reset(self) -> None:
        """Reset the internal state of the SED detector."""
        self._vad_cnt = self._vad_init

    def execute_all(self, x: np.ndarray) -> np.ndarray:
        """Process multiple frames of audio power data.

        Args:
            x: 1D array of input power frames.

        Returns:
            2D array of detection results [frames, classes].

        """
        frames = x.shape[0]
        y = np.empty((frames, self.num_classes), dtype=np.float32)
        for idx in range(frames):
            y[idx] = self.execute(float(x[idx]))

        return y

    def execute(self, x: float) -> np.ndarray:
        """Process a single frame of audio power.

        Args:
            x: Input power value for the frame.

        Returns:
            1D array of detection results [classes].

        """
        if x > self._thresholds_lin[0]:
            self._vad_cnt = 0
        elif x > self._thresholds_lin[1]:
            self._vad_cnt -= 5
        elif x > self._thresholds_lin[2]:
            self._vad_cnt += 1
        else:
            self._vad_cnt += 2

        self._vad_cnt = max(self._vad_cnt, 0)

        self._vad_cnt = min(self._vad_init, self._vad_cnt)

        if self._vad_cnt >= 10:
            value = 0.0
        elif self._vad_cnt > 0:
            value = 0.5
        else:
            value = 1.0

        out = np.zeros(self.num_classes, dtype=np.float32)
        out[self._index_nz] = value

        if self.mutex:
            out[-1] = 1 - value

        return out

    def db_to_lin(self, db: list[float]) -> list[float]:
        """Convert dB thresholds to linear power values.

        Args:
            db: List of thresholds in dB.

        Returns:
            List of linear power thresholds.
        """
        return [self.frame_size * 10 ** (x / 10) for x in db]
