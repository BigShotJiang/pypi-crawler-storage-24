"""Python library for Aaware AI sound, speech, and voice processing.

This package provides high-performance signal processing, feature generation,
and integration with Aaware's core AI technologies.
"""

from pyaaware.rs import AudioInfo
from pyaaware.rs import FeatureGenerator
from pyaaware.rs import ForwardTransform
from pyaaware.rs import InverseTransform
from pyaaware.rs import StreamingResampler
from pyaaware.rs import __version__
from pyaaware.rs import get_audio_from_feature
from pyaaware.rs import get_audio_info
from pyaaware.rs import get_feature_from_audio
from pyaaware.rs import get_supported_formats
from pyaaware.rs import power_compress
from pyaaware.rs import power_uncompress
from pyaaware.rs import raw_read_audio
from pyaaware.rs import read_audio
from pyaaware.rs import resample
from pyaaware.rs import stack_complex
from pyaaware.rs import stacked_complex_imag
from pyaaware.rs import stacked_complex_real
from pyaaware.rs import unstack_complex
from pyaaware.rs import write_wav

from .env_vars import tokenized_expand
from .env_vars import tokenized_replace
from .feature_generator_parser import feature_forward_transform_config
from .feature_generator_parser import feature_inverse_transform_config
from .feature_generator_parser import feature_parameters
from .nnp_detect import NNPDetect
from .sed import SED

__all__ = [
    "AudioInfo",
    "SED",
    "FeatureGenerator",
    "ForwardTransform",
    "InverseTransform",
    "NNPDetect",
    "StreamingResampler",
    "__version__",
    "feature_forward_transform_config",
    "feature_inverse_transform_config",
    "feature_parameters",
    "get_audio_from_feature",
    "get_audio_info",
    "get_supported_formats",
    "get_feature_from_audio",
    "power_compress",
    "power_uncompress",
    "raw_read_audio",
    "read_audio",
    "resample",
    "stack_complex",
    "stacked_complex_imag",
    "stacked_complex_real",
    "tokenized_expand",
    "tokenized_replace",
    "unstack_complex",
    "write_wav",
]
