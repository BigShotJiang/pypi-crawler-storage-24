"""Rust-backed high-performance components for pyaaware.

This package exposes core signal processing components implemented in Rust
for maximum performance.
"""

from pyaaware.rs import AudioInfo
from pyaaware.rs import FeatureGenerator
from pyaaware.rs import ForwardTransform
from pyaaware.rs import InverseTransform
from pyaaware.rs import StreamingResampler
from pyaaware.rs import get_audio_from_feature
from pyaaware.rs import get_audio_info
from pyaaware.rs import get_feature_from_audio
from pyaaware.rs import get_supported_formats
from pyaaware.rs import power_compress
from pyaaware.rs import power_uncompress
from pyaaware.rs import raw_read_audio
from pyaaware.rs import read_audio
from pyaaware.rs import resample
from pyaaware.rs import sov2nov
from pyaaware.rs import stack_complex
from pyaaware.rs import stacked_complex_imag
from pyaaware.rs import stacked_complex_real
from pyaaware.rs import unstack_complex
from pyaaware.rs import write_wav

__all__ = [
    "AudioInfo",
    "FeatureGenerator",
    "ForwardTransform",
    "InverseTransform",
    "StreamingResampler",
    "get_audio_from_feature",
    "get_audio_info",
    "get_feature_from_audio",
    "get_supported_formats",
    "power_compress",
    "power_uncompress",
    "raw_read_audio",
    "read_audio",
    "resample",
    "sov2nov",
    "stack_complex",
    "stacked_complex_imag",
    "stacked_complex_real",
    "unstack_complex",
    "write_wav",
]
