"""Neural Network Post-processing detection logic.

This module provides detection state machines (rise, fall, hold) for processing
neural network output probabilities.
"""

from enum import IntEnum
from typing import Any

import numpy as np


class State(IntEnum):
    """Detection states for the `NNPDetect` state machine.

    Attributes:
        LOOK_FOR_RISE: Wait for probability to exceed `risethresh`.
        LOOK_FOR_FALL: Wait for probability to drop below `fallthresh`.
        HOLD: Active detection being held.
    """

    LOOK_FOR_RISE = 0
    LOOK_FOR_FALL = 1
    HOLD = 2


class NNPDetect:
    """Neural Network Post-processing detection logic.

    Process probabilities using a state machine with configurable thresholds
    and frame counters to detect events.

    This class has the **side effect** of maintaining detection state.
    It is **not thread-safe**.
    """

    def __init__(
        self,
        channels: int | None = None,
        classes: int | None = None,
        risethresh: list[float] | None = None,
        fallthresh: list[float] | None = None,
        riseframes: list[int] | None = None,
        fallframes: list[int] | None = None,
        hold: list[int] | None = None,
        smoothf: list[float] | None = None,
    ) -> None:
        """Initialize the `NNPDetect` detector.

        Args:
            channels: Number of input channels (default: 1).
            classes: Number of output detection classes (default: 1).
            risethresh: Probability threshold for a 'rise' event (default: [0.5]).
            fallthresh: Probability threshold for a 'fall' event (default: [0.5]).
            riseframes: Number of frames to stay in 'rise' state (default: [0]).
            fallframes: Number of frames to stay in 'fall' state (default: [0]).
            hold: Number of frames to hold a detection (default: [0]).
            smoothf: Smoothing factor for probabilities (default: [0.0]).
        """
        self._channels = 1 if channels is None else channels
        self._classes = 1 if classes is None else classes
        self._risethresh = [0.5] if risethresh is None else risethresh
        self._fallthresh = [0.5] if fallthresh is None else fallthresh
        self._riseframes = [0] if riseframes is None else riseframes
        self._fallframes = [0] if fallframes is None else fallframes
        self._hold = [0] if hold is None else hold
        self._smoothf = [0.0] if smoothf is None else smoothf

        self._risethresh = self.extend_parameter(self._risethresh)
        self._fallthresh = self.extend_parameter(self._fallthresh)
        self._riseframes = self.extend_parameter(self._riseframes)
        self._fallframes = self.extend_parameter(self._fallframes)
        self._hold = self.extend_parameter(self._hold)
        self._smoothf = self.extend_parameter(self._smoothf)

        self._state = np.zeros((self.channels, self.classes), dtype=int)
        self._rise_cnt = np.zeros((self.channels, self.classes), dtype=int)
        self._fall_cnt = np.zeros((self.channels, self.classes), dtype=int)
        self._hold_cnt = np.zeros((self.channels, self.classes), dtype=int)
        self._detect = np.zeros((self.channels, self.classes), dtype=int)
        self._smooth = np.zeros((self.channels, self.classes), dtype=float)

    def extend_parameter(self, param: list[Any]) -> list[Any]:
        """Extend a configuration parameter to match the number of classes.

        If the `param` is a single-element list, it is broadcast to all classes.

        Args:
            param: List of values to be extended.

        Returns:
            List of values with length equal to `classes`.

        Raises:
            ValueError: If the length of `param` is not 1 or equal to `classes`.
        """
        if len(param) == 1:
            return param * self.classes
        if len(param) != self.classes:
            raise ValueError("length of configuration parameter does not match 'classes'")
        return param

    @property
    def channels(self) -> int:
        """Number of input channels."""
        return self._channels

    @property
    def classes(self) -> int:
        """Number of detection classes."""
        return self._classes

    @property
    def risethresh(self) -> list[float]:
        """Probability threshold for triggering a rise event."""
        return self._risethresh

    @property
    def fallthresh(self) -> list[float]:
        """Probability threshold for triggering a fall event."""
        return self._fallthresh

    @property
    def riseframes(self) -> list[int]:
        """Number of frames required for a rise event."""
        return self._riseframes

    @property
    def fallframes(self) -> list[int]:
        """Number of frames required for a fall event."""
        return self._fallframes

    @property
    def hold(self) -> list[int]:
        """Number of frames to hold a detection after fall."""
        return self._hold

    @property
    def smoothf(self) -> list[float]:
        """Smoothing factor applied to input probabilities."""
        return self._smoothf

    def reset(self) -> None:
        """Reset the internal state of the detector."""
        self._state = np.zeros((self.channels, self.classes), dtype=int)
        self._rise_cnt = np.zeros((self.channels, self.classes), dtype=int)
        self._fall_cnt = np.zeros((self.channels, self.classes), dtype=int)
        self._hold_cnt = np.zeros((self.channels, self.classes), dtype=int)
        self._detect = np.zeros((self.channels, self.classes), dtype=bool)
        self._smooth = np.zeros((self.channels, self.classes), dtype=float)

    def execute_all(self, prob: np.ndarray, eof: np.ndarray) -> np.ndarray:
        """Process multiple frames of probabilities.

        Args:
            prob: 3D array of probabilities [channels, classes, frames].
            eof: 1D boolean array indicating end-of-frame.

        Returns:
            3D array of detection results [channels, classes, frames].

        """
        if prob.ndim != 3:
            raise ValueError("prob should be a 3D array")

        channels, classes, frames = prob.shape
        if channels != self.channels or classes != self.classes:
            raise ValueError(f"prob should have dimensions: [{self.channels}, {self.classes}, frames]")

        if eof.ndim != 1 or eof.size != frames:
            raise ValueError("eof should be a 1d array with the same number of frames as prob")

        detect = np.empty((self.channels, self.classes, frames), dtype=int)
        for in_idx in range(frames):
            detect[:, :, in_idx] = self.execute(prob[:, :, in_idx], bool(eof[in_idx]))

        return detect

    def execute(self, prob: np.ndarray, eof: bool) -> np.ndarray:
        """Process a single frame of probabilities.

        Args:
            prob: 2D array of probabilities [channels, classes].
            eof: Boolean indicating if this is the end of a block.

        Returns:
            2D array of detection results [channels, classes].

        """
        if prob.ndim != 2:
            raise ValueError("prob should be a 2D array")

        channels, classes = prob.shape
        if channels != self.channels or classes != self.classes:
            raise ValueError(f"prob should have dimensions: [{self.channels}, {self.classes}]")

        if not eof:
            return np.zeros((self.channels, self.classes), dtype=bool)

        for nci in range(self.classes):
            for chi in range(self.channels):
                self._smooth[chi, nci] = (
                    self.smoothf[nci] * self._smooth[chi, nci] + (1 - self._smoothf[nci]) * prob[chi, nci]
                )

                if self._state[chi, nci] == State.LOOK_FOR_RISE:
                    if self._smooth[chi, nci] > self.risethresh[nci]:
                        if self._rise_cnt[chi, nci] >= self.riseframes[nci]:
                            self._state[chi, nci] = State.LOOK_FOR_FALL
                            self._fall_cnt[chi, nci] = 0
                            self._hold_cnt[chi, nci] = 1
                        else:
                            self._rise_cnt[chi, nci] += 1
                    else:
                        self._rise_cnt[chi, nci] = 0

                elif self._state[chi, nci] == State.LOOK_FOR_FALL:
                    if self._smooth[chi, nci] < self.fallthresh[nci]:
                        if self._fall_cnt[chi, nci] >= self.fallframes[nci]:
                            if self._hold_cnt[chi, nci] >= self.hold[nci]:
                                self._state[chi, nci] = State.LOOK_FOR_RISE
                                self._rise_cnt[chi, nci] = 0
                                self._fall_cnt[chi, nci] = 0
                                self._hold_cnt[chi, nci] = 0
                            else:
                                self._state[chi, nci] = State.HOLD
                                self._hold_cnt[chi, nci] += 1
                        else:
                            self._fall_cnt[chi, nci] += 1
                            self._hold_cnt[chi, nci] += 1
                    else:
                        self._fall_cnt[chi, nci] = 0
                        self._hold_cnt[chi, nci] += 1

                elif self._state[chi, nci] == State.HOLD:
                    if self._hold_cnt[chi, nci] >= self.hold[nci]:
                        self._state[chi, nci] = State.LOOK_FOR_RISE
                        self._rise_cnt[chi, nci] = 0
                        self._fall_cnt[chi, nci] = 0
                        self._hold_cnt[chi, nci] = 0
                    else:
                        self._hold_cnt[chi, nci] += 1

                else:
                    raise RuntimeError("invalid state")

                self._detect[chi, nci] = int(self._hold_cnt[chi, nci] > 0)

        return self._detect
