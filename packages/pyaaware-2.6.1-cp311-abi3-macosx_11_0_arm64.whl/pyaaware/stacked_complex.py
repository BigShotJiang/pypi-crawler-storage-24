"""Utilities for handling stacked complex-valued arrays.

Provides functions to convert between standard complex-valued NumPy arrays
and 'stacked' representations where real and imaginary parts are concatenated.
"""

import numpy as np

_COMPLEX_COMPONENTS = 2  # Real and imaginary parts


def _validate_stacked_array(array: np.ndarray) -> int:
    """Validate a stacked complex array and return the half-size.

    Args:
        array: Array to validate.

    Returns:
        Half size of the last dimension.

    Raises:
        ValueError: If last dimension is not a multiple of 2.
    """
    last_dim_size = array.shape[-1]
    if last_dim_size % _COMPLEX_COMPONENTS != 0:
        raise ValueError("last dimension must be a multiple of 2")

    return last_dim_size // _COMPLEX_COMPONENTS


def stack_complex(unstacked: np.ndarray) -> np.ndarray:
    """Convert a complex array into a stacked real representation.

    A stacked array doubles the last dimension and organizes the data as:
        - first half is all the real data
        - second half is all the imaginary data

    Args:
        unstacked: An nD array containing complex data.

    Returns:
        A stacked real array.

    """
    shape = list(unstacked.shape)
    shape[-1] *= _COMPLEX_COMPONENTS
    stacked = np.empty(shape, dtype=np.float32)

    half_size = unstacked.shape[-1]
    stacked[..., :half_size] = np.real(unstacked)
    stacked[..., half_size:] = np.imag(unstacked)

    return stacked


def unstack_complex(stacked: np.ndarray) -> np.ndarray:
    """Convert a stacked real array back into a complex-valued array.

    Args:
        stacked: An nD array where the last dimension contains stacked complex data.

    Returns:
        An unstacked complex array.

    Raises:
        ValueError: If input validation fails.

    """
    half_size = _validate_stacked_array(stacked)

    real_part = stacked[..., :half_size]
    imag_part = stacked[..., half_size:]

    return real_part + 1j * imag_part


def stacked_complex_real(stacked: np.ndarray) -> np.ndarray:
    """Extract real elements from a stacked complex array.

    Args:
        stacked: An nD array containing stacked complex data.

    Returns:
        The real elements.

    Raises:
        ValueError: If input validation fails.

    """
    half_size = _validate_stacked_array(stacked)
    return stacked[..., :half_size]


def stacked_complex_imag(stacked: np.ndarray) -> np.ndarray:
    """Extract imaginary elements from a stacked complex array.

    Args:
        stacked: An nD array containing stacked complex data.

    Returns:
        The imaginary elements.

    Raises:
        ValueError: If input validation fails.

    """
    half_size = _validate_stacked_array(stacked)
    return stacked[..., half_size:]
