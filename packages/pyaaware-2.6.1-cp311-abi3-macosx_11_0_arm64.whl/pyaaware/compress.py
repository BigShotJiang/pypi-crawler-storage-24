"""Power compression and uncompression for complex-valued features.

This module provides functions to apply and reverse power compression
on complex-valued arrays, typically used for feature scaling in AI models.
"""

import numpy as np

_POWER_COMPRESSION_FACTOR = 0.3


def _reconstruct_complex(magnitude: np.ndarray, phase: np.ndarray) -> np.ndarray:
    """Reconstruct complex numbers from magnitude and phase.

    Args:
        magnitude: Magnitude array.
        phase: Phase array.

    Returns:
        Complex-valued array.
    """
    real_part = magnitude * np.cos(phase)
    imag_part = magnitude * np.sin(phase)
    return real_part + 1j * imag_part


def power_compress(feature: np.ndarray) -> np.ndarray:
    """Apply power compression to a complex-valued array.

    Args:
        feature: A complex-valued array.

    Returns:
        A power-compressed complex-valued array.
    """
    magnitude = np.abs(feature)
    phase = np.angle(feature)
    compressed_magnitude = magnitude**_POWER_COMPRESSION_FACTOR
    return _reconstruct_complex(compressed_magnitude, phase)


def power_uncompress(feature: np.ndarray) -> np.ndarray:
    """Reverse power compression on a complex-valued array.

    Args:
        feature: A power-compressed complex-valued array.

    Returns:
        A power-uncompressed complex-valued array.
    """
    magnitude = np.abs(feature)
    phase = np.angle(feature)
    uncompressed_magnitude = magnitude ** (1.0 / _POWER_COMPRESSION_FACTOR)
    return _reconstruct_complex(uncompressed_magnitude, phase)
