"""Power compression and uncompression layers for PyTorch.

Provides PyTorch-compatible implementations of power-based feature
scaling used in AI audio models.
"""

import torch

_POWER_COMPRESSION_FACTOR = 0.3


def _reconstruct_complex(magnitude: torch.Tensor, phase: torch.Tensor) -> torch.Tensor:
    """Reconstruct complex numbers from magnitude and phase.

    Args:
        magnitude: Magnitude array.
        phase: Phase array.

    Returns:
        Complex-valued array.
    """
    real_part = magnitude * torch.cos(phase)
    imag_part = magnitude * torch.sin(phase)
    return real_part + 1j * imag_part


def power_compress(feature: torch.Tensor) -> torch.Tensor:
    """Compress a complex-valued feature.

    Args:
        feature: A complex-valued array representing the feature.

    Returns:
        A power-compressed complex-valued array.
    """
    magnitude = torch.abs(feature)
    phase = torch.angle(feature)
    compressed_magnitude = magnitude**_POWER_COMPRESSION_FACTOR
    return _reconstruct_complex(compressed_magnitude, phase)


def power_uncompress(feature: torch.Tensor) -> torch.Tensor:
    """Uncompress a power-compressed complex-valued feature.

    Args:
        feature: A complex-valued array representing the power-compressed feature.

    Returns:
        A power-uncompressed complex-valued array.
    """
    magnitude = torch.abs(feature)
    phase = torch.angle(feature)
    uncompressed_magnitude = magnitude ** (1.0 / _POWER_COMPRESSION_FACTOR)
    return _reconstruct_complex(uncompressed_magnitude, phase)
