"""Type definitions for PyTorch transforms.

This module contains shared Enums and type definitions for transform
configurations, such as Overlap types.
"""

from enum import Enum

import torch


class Overlap(Enum):
    """Enumeration of overlap types for audio transforms.

    Supported types include:
    - OLA: Overlap-Add.
    - OLS: Overlap-Save.
    - TDAC: Time-Domain Aliasing Cancellation.
    - TDAC_CO: TDAC with circular overlap.
    """

    OLA = "OLA"
    OLS = "OLS"
    TDAC = "TDAC"
    TDAC_CO = "TDAC_CO"


class Window(Enum):
    """Enumeration of window types for audio transforms.

    Supported types include:
    - NONE: No windowing (rectangular).
    - HANN: Hann window.
    - HAMM: Hamming window.
    - W01: Custom 0-1 windowing for specific transforms.
    - HANN01: Hann window combined with 0-1 padding.
    """

    NONE = "none"
    HANN = "hann"
    HAMM = "hamm"
    W01 = "w01"
    HANN01 = "hann01"


def window(window_type: Window, length: int, overlap: int, periodic: bool = True) -> torch.Tensor:
    """Generate a window for audio transforms.

    Args:
        window_type: Window type.
        length: Transform length.
        overlap: Overlap amount.
        periodic: Whether the window is periodic (default: `True`).

    Returns:
        The generated window tensor.
    """
    sym = not periodic

    if window_type == Window.NONE:
        return torch.ones(length, dtype=torch.float32)

    if window_type == Window.HANN:
        return torch.signal.windows.hann(M=length, sym=sym, dtype=torch.float32)

    if window_type == Window.HAMM:
        return torch.signal.windows.hamming(M=length, sym=sym, dtype=torch.float32)

    if window_type == Window.W01:
        if not (length / overlap) % 2:
            return torch.concatenate(
                (
                    torch.zeros(length // 2, dtype=torch.float32),
                    torch.ones(length // 2, dtype=torch.float32),
                )
            )
        return torch.concatenate(
            (
                torch.zeros(length - overlap, dtype=torch.float32),
                torch.ones(overlap, dtype=torch.float32),
            )
        )

    if window_type == Window.HANN01:
        if (length // 4) < overlap:
            raise ValueError(f"{window_type} window requires R <= N/4")
        if length / 2 % 2:
            raise ValueError(f"{window_type} window requires N to be even")
        return torch.concatenate(
            (
                torch.zeros(length // 2, dtype=torch.float32),
                torch.signal.windows.hann(M=length // 2, sym=sym, dtype=torch.float32),
            )
        )

    raise ValueError(f"Unknown window type: {window_type}")
