# VNSFintech

`VNSFintech` là thư viện Python cung cấp dữ liệu và công cụ hỗ trợ tài chính cho các nhà đầu tư và phân tích thị trường chứng khoán.

## Cài đặt

```bash
pip install VNSFintech
```

Cập nhật phiên bản mới:

```bash
pip install --upgrade VNSFintech
```

## Sử dụng

```python
from VNSFintech import *
```

---

# Hướng dẫn sử dụng

---

# Class `stock`
Cổ phiếu Việt Nam

### 1. Thông tin mã cổ phiếu:
`stock_info(symbol)`

```python
df = stock.stock_info('HPG')
```

---

### 2. Lịch sử ohlcv:
`history(symbol, start, end, time='days')`

```python
df = stock.history('HPG', '2020-01-01', '2023-01-01')
```

`time`:
- `'minutes'`
- `'hours'`
- `'days'`
- `'months'`

---

### 3. Lịch sử khớp lệnh:
`intraday(symbol)`

```python
df = stock.intraday('HPG')
```

---

### 4. Phân loại nhà đầu tư:
`intraday_order(symbol)`

```python
df = stock.intraday_order('HPG')
```

---

### 5. Thông tin giá cổ phiếu:
Lịch sử giá cổ phiếu:
`price_history(symbol, time, start, end)`

```python
df = stock.price_history('HPG', time='days', start='2020-01-01', end='2023-01-01')
```

`time`:
- `'days'`
- `'months'`
- `'quarters'`
- `'years'`

Tổng hợp giá cổ phiếu: tổng và trung bình ngày
`price_history_summary(symbol)`

```python
df = stock.price_history_summary('HPG')
```

---

### 7. Nước ngoài:
Lịch sử giao dịch nước ngoài:
`foreign_history(symbol, time, start, end)` 
```python
df = stock.foreign_history('HPG', time='days', start='2020-01-01', end='2023-01-01')
```

`time`:
- `'days'`
- `'months'`
- `'quarters'`
- `'years'`

Tổng hợp giao dịch nước ngoài:tổng và trung bình ngày
`foreign_history_summary(symbol)`

```python
df = stock.foreign_history_summary('HPG')
```

---

### 8. Tự doanh
Lịch sử giao dịch tự doanh:
`proprietary_history(symbol, time, start, end)`  

```python
df = stock.proprietary_history('HPG', time='days', start='2020-01-01', end='2023-01-01')
```

Tổng hợp giao dịch nước ngoài:tổng và trung bình theo ngày, tháng, quý, năm.
`proprietary_history_summary(symbol, time)`

```python
df = stock.proprietary_history_summary('HPG', time='days')
```

`time`:
- `'days'`
- `'months'`
- `'quarters'`
- `'years'`

---

### 9. Cung cầu
`demand_history(symbol, time, start, end)`

```python
df = stock.demand_history('HPG', time='days', start='2020-01-01', end='2023-01-01')
```

`time`:
- `'days'`
- `'months'`
- `'quarters'`
- `'years'`

---

### 10. Tin tức & sự kiện

Tin tức:
`news(symbol)`
```python
df = stock.news('HPG')
```

Cổ tức:
`dividend(symbol)`  
```python
df = stock.dividend('HPG')
```

Họp HDQT:
`general_meeting(symbol)`  
```python
df = stock.general_meeting('HPG')
```

Sự kiện khác:
`other_event(symbol)`

```python
df = stock.other_event('HPG')
```

---

### 11. Tài chính
Chỉ số tài chính:
`finance_ratio(symbol, time)`  
```python
df = stock.finance_ratio('HPG', time='years')
```

Bảng cân đối kế toán:
`balance_sheet(symbol, time)`  
```python
df = stock.balance_sheet('HPG', time='years')
```

Kết quả kinh doanh:
`income_statement(symbol, time)`  
```python
df = stock.income_statement('HPG', time='years')
```

Báo cáo lưu chuyển tiền tệ:
`cash_flow(symbol, time)`

```python
df = stock.cash_flow('HPG', time='years')
```

`time`:
- `'years'`
- `'quarters'`

---

### 12. Cổ đông
Thông tin cổ đông:
`shareholders_info(symbol)` 
```python
df = stock.shareholders_info('HPG')
```

Cấu trúc cổ đông:
`shareholders_structure(symbol)`  
```python
df = stock.shareholders_structure('HPG')
```

Các công ty liên quan:
`shareholders_relationship(symbol)`  
```python
df = stock.shareholders_relationship('HPG')
```

Giao dịch nội bộ:
`insider_trans(symbol)`

```python
df = stock.insider_trans('HPG')
```

---

# Class `exchange`
Sàn chứng khoán Việt Nam
Danh sách cổ phiếu tăng/giảm:

`get_top_stock(exchange, up_down)`

```python
df = exchange.get_top_stock('HOSE', 'up')
```

`exchange`:
- `'HOSE'`
- `'HNX'`
- `'UPCOM'`

`up_down`:
- `'up'`
- `'down'`

---

# Class `indice`
Chỉ số chứng khoán Việt Nam

`get_overview_market(indice, start, end)`

```python
df = indice.get_overview_market('VNINDEX', '2024-01-01', '2025-01-01')
```

`indice`:
- `'VNINDEX'`
- `'VN30'`
- `'HNXINDEX'`
- `'UPINDEX'`

---

# Class `other`
Các chỉ số khác

`exchange_other()`

```python
df = other.exchange_other()
```

---

# Class `fund`
Chứng chỉ quỹ đầu tư
Tổng quan danh sách các chứng chỉ quỹ:
`fund_market()`

```python
df = fund.fund_market()
```
---
Tăng trưởng tài sản ròng (NAV) của quỹ:
`get_nav_history(fund, start, end)`

```python
df = fund.get_nav_history('BMFF', '2020-01-01', '2023-01-01')
```
---
Danh mục đầu tư lớn:
`get_top_holding(fund)`

```python
df = fund.get_top_holding('BMFF')
```
---
Phân bổ quỹ theo tài sản nắm giữ:
`get_asset_holding(fund)`

```python
df = fund.get_asset_holding('BMFF')
```
---
Phân bổ quỹ theo ngành:
`get_industries_holding(fund)`

```python
df = fund.get_industries_holding('BMFF')
```

---
`fund`:
- `'BMFF'`
- `'87'`
Xem ở fund_market()

---

# Class `macro_eco`
Chỉ số kinh tế vĩ mô

`get(indicator, time, start, end)`

```python
df = macro_eco.get('GDP', 'years', '2021', '2024')
df = macro_eco.get(43, 'quarters', '2020', '2023')
```

`indicator`:
- `'GDP'`, `'CPI'`, ...
- hoặc id: `43`, `52`, ...

`time`:
- `'days'`
- `'months'`
- `'quarters'`
- `'years'`

---

## Danh sách chỉ số vĩ mô

| ID | Chỉ số |
|----|------|
| 43 | GDP |
| 52 | CPI |
| 46 | Sản xuất công nghiệp |
| 47 | Bán lẻ |
| 48 | Xuất nhập khẩu |
| 50 | FDI |
| 51 | Tín dụng |
| 53 | Lãi suất |
| 55 | Dân số và lao động |

---

## Giấy phép

Thư viện này được phát hành theo giấy phép MIT. Vui lòng xem tệp LICENSE để biết thêm chi tiết.