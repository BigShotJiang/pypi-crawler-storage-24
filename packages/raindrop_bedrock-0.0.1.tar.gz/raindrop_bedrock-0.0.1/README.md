# raindrop-bedrock

Raindrop integration for AWS Bedrock (Python). Automatically captures `converse()` and `invoke_model()` calls by wrapping the boto3 bedrock-runtime client.

## Installation

```bash
pip install raindrop-bedrock boto3
```

## Usage

```python
import boto3
from raindrop_bedrock import create_raindrop_bedrock

raindrop = create_raindrop_bedrock(
    api_key="rk_...",
    user_id="user-123",
)

client = boto3.client("bedrock-runtime", region_name="us-east-1")
wrapped = raindrop["wrap"](client)

response = wrapped.converse(
    modelId="anthropic.claude-3-5-sonnet-20241022-v2:0",
    messages=[
        {"role": "user", "content": [{"text": "Hello!"}]},
    ],
)

raindrop["flush"]()
```

## What gets captured

- **converse()**: input messages, output text, model ID, token usage (inputTokens/outputTokens)
- **invoke_model()**: raw request/response bodies, model ID, token usage (Claude, Titan, and Llama formats)
- **Errors**: tracked and re-raised to the caller

## Options

| Option | Type | Default | Description |
|--------|------|---------|-------------|
| `api_key` | `str` | required | Raindrop API key |
| `user_id` | `str` | `None` | Associate all events with a user |
| `convo_id` | `str` | `None` | Group events into a conversation |

## Testing

```bash
cd packages/bedrock-python
pip install -e .
python -m pytest tests/ -v
```

## Known Limitations

- **InvokeModel body replacement**: After consuming the response body stream, it's replaced with a `BytesIO` object. Callers using `StreamingBody.read()` will get the same bytes, but the original `StreamingBody` API is not preserved.
- **No `events.*`, `users.*`, or `signals.*` APIs** — Python SDK limitation. Use `raindrop.analytics` directly for these features.
