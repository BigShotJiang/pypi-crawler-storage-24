''' helper methods '''

ALPHA_LOWER = 'abcdefghijklmnopqrstuvwxyz'
ALPHA_UPPER = ALPHA_LOWER.upper()
DIGITS = '0123456789'
SYMBOLS = '~!@#$%^&*()-_=+[{]}|;:\'\",<.>/?'

# return hexadecimal string from bytes
def hex(b: bytes | bytearray) -> str:
  return b.hex()

# random in in range [a, b)
# using the "division with rejection" method from here: 
# https://www.pcg-random.org/posts/bounded-rands.html
# return None if sample fails
def ranged_int(_bytes: bytes | bytearray, a: int, b: int) -> int:

  if b <= a:
    raise BaseException('invalid range')

  i = int.from_bytes(_bytes, byteorder='little')

  _range = b - a 
  _max = 2 ** (len(_bytes) * 8)

  if _range > _max:
    raise BaseException('not enough bytes to sample that range')

  # this essentially finds which bin the number is in
  # there are _range bins, each of size _max // _range
  ret = (i // (_max // _range))

  # reject if needed
  if ret >= _range:
    return None

  # adjust to fit in range
  return ret + a

# return string containing random characters from l based on byte values
# in b
def custom_chars(b: bytes | bytearray, l: list) -> str:

  n = len(l)
  ret = ''

  for i in range(len(b)):
    r = ranged_int(b[i:i+1], 0, n)
    if r is None:
      continue
    curr = l[r]
    ret = '{}{}'.format(ret, curr)
  
  return ret

# get ascii from bytearray
def ascii(b: bytes | bytearray) -> str:
  return custom_chars(b, ALPHA_LOWER + ALPHA_UPPER + DIGITS + SYMBOLS)

# alphanumeric with lower case
def alpha_numeric(b: bytes | bytearray) -> str:
  return custom_chars(b, ALPHA_LOWER + DIGITS)  

# alphanumeric thats case sensitive
def alpha_numeric_case_sensitive(b: bytes | bytearray) -> str:
  return custom_chars(b, ALPHA_LOWER + ALPHA_UPPER + DIGITS)  

# digits from bytes
def decimal(b: bytes | bytearray) -> str:
  return custom_chars(b, DIGITS)

# Helper method to convert bytes to different formats
# take in bytes (s) and a format, output the bytes converted to the format
def convert_bytes(s, _format):
  if _format == 'hex':
    return hex_from_bytes(s)
  elif _format == 'ascii':
    return ascii_from_bytes(s)
  elif _format == 'alpha-numeric':
    return alpha_numeric_from_bytes(s)
  elif _format == 'Alpha-numeric':
    return alpha_numeric_case_sensitive_from_bytes(s)
  elif _format == 'digits':
    return digits_from_bytes(s)
  elif _format == 'bytes':
    return s
  else:
    raise BaseException('invalid format type') 
