import convert

chars = 'abjk243'

b = bytearray()
b.append(2)
b.append(23)
b.append(44)
b.append(101)
b.append(222)
b.append(56)
b.append(153)

print(b)
print(convert.hex(b))
print(convert.ascii(b))
print(convert.custom_chars(b, chars))
print(convert.ranged_int(b, 0, 10))
print(convert.alpha_numeric(b))
print(convert.alpha_numeric_case_sensitive(b))
print(convert.decimal(b))


