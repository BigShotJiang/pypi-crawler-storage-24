use crate::inference::InferenceResult;
use pyo3::{pyclass, pymethods, PyResult};

#[derive(Clone)]
#[pyclass(name = "InferenceResult", from_py_object)]
pub struct PyInferenceResult {
    pub inner: InferenceResult,
}

#[pymethods]
impl PyInferenceResult {
    fn __repr__(&self) -> PyResult<String> {
        Ok("Contact Data Treehouse to try".to_string())
    }

    fn __str__(&self) -> PyResult<String> {
        Ok("Contact Data Treehouse to try".to_string())
    }
}
