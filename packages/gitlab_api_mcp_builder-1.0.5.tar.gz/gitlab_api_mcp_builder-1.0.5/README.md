# API MCP Builder

Serveur MCP pour générer automatiquement des projets d'agents API à partir de templates GitLab, directement depuis GitHub Copilot.

## ✨ Fonctionnalités

✅ Liste les templates depuis GitLab  
✅ Prévisualise la structure d'un template  
✅ Génère un projet complet en une commande  
✅ Intégré dans VS Code via GitHub Copilot  

## 📋 Prérequis

- Token GitLab personnel ([créer un token](https://gitlab.com/-/user_settings/personal_access_tokens))
- VS Code + GitHub Copilot
- `uvx` installé (généralement inclus avec `uv` ou `pip`)

## 📦 Installation rapide

### 1. Crée le fichier de configuration

Dans ton workspace VS Code, crée le fichier `.vscode/mcp.json` :

```json
{
  "servers": {
    "api-builder": {
      "type": "stdio",
      "command": "uvx",
      "args": ["--from", "gitlab-api-mcp-builder", "api-mcp-builder"],
      "env": {
        "GITLAB_TOKEN": "TON-TOKEN-GITLAB-ICI",
        "GITLAB_DEFAULT_GROUP": "repository-templates1"
      }
    }
  }
}
```

### 2. Remplace le token

- Va sur https://gitlab.com/-/user_settings/personal_access_tokens
- Crée un token avec les scopes : `read_api`, `read_repository`
- Remplace `TON-TOKEN-GITLAB-ICI` dans le fichier ci-dessus

### 3. Redémarre VS Code

`CMD+Shift+P` → `Reload Window`

### 4. Teste

Ouvre Copilot Chat et tape :
```
@api-builder liste les templates
```

✅ C'est tout !

## 💬 Utilisation

Dans GitHub Copilot Chat :

```
liste les templates API disponibles

génère un projet netdata-agent depuis le template agent-api-template

prévisualise le template 80104086
```

## 📚 Documentation complète

Voir [QUICKSTART.md](QUICKSTART.md) pour le guide détaillé.

## 🛠️ Développement

```bash
git clone https://gitlab.com/Achour_C/api-mcp-builder.git
cd api-mcp-builder
pip install -e ".[dev]"
python test_server.py
```

## 📄 Licence

MIT - Voir [LICENSE](LICENSE)
