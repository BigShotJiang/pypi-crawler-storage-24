"""
setup.py for backwards compatibility
Modern Python packages use pyproject.toml instead.
"""
from setuptools import setup

if __name__ == "__main__":
    setup()
