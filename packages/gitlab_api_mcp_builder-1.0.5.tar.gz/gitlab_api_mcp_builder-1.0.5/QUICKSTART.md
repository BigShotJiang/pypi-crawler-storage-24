# 🚀 Guide de démarrage rapide

## Installation en 3 étapes

### 1️⃣ Crée le fichier de configuration MCP

Dans ton workspace VS Code, crée le fichier `.vscode/mcp.json` avec ce contenu :

```json
{
  "servers": {
    "api-builder": {
      "type": "stdio",
      "command": "uvx",
      "args": ["--from", "gitlab-api-mcp-builder", "api-mcp-builder"],
      "env": {
        "GITLAB_TOKEN": "TON-TOKEN-GITLAB-ICI",
        "GITLAB_DEFAULT_GROUP": "repository-templates1"
      }
    }
  }
}
```

### 2️⃣ Obtiens un token GitLab

1. Va sur : https://gitlab.com/-/user_settings/personal_access_tokens
2. Crée un token avec les scopes : `read_api`, `read_repository`
3. Copie le token et remplace `TON-TOKEN-GITLAB-ICI` dans le fichier ci-dessus

### 3️⃣ Redémarre VS Code

`CMD+Shift+P` → `Reload Window`

## ✅ Vérifier que ça marche

**Dans GitHub Copilot Chat** :

```
liste les templates disponibles
```

Si ça fonctionne, tu verras la liste des templates GitLab ✅

## 💬 Exemples d'utilisation

```
liste les templates API

génère un projet netdata-agent depuis le template agent-api-template

prévisualise la structure du template 80104086
```

## 🐛 Dépannage

**Erreur "GITLAB_TOKEN is required"** :
- Vérifie que tu as bien mis ton token dans la config VS Code
- Redémarre VS Code

**Le serveur ne démarre pas** :
```bash
python3 -c "import api_mcp_builder; print(api_mcp_builder.__version__)"
```
Doit afficher `1.0.0`

**Les templates ne s'affichent pas** :
- Vérifie ton token GitLab

## 📚 Plus d'infos

Voir [README.md](README.md) pour la documentation complète
