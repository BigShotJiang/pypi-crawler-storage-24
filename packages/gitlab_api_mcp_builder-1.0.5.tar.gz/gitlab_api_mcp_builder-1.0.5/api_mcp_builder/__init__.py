"""
API MCP Builder - Serveur MCP pour générer des projets d'API depuis GitLab templates
"""

__version__ = "1.0.0"
__author__ = "Kyndryl"

# Ne pas importer server ici pour éviter l'initialisation automatique
# L'utilisateur peut importer explicitement si besoin :
# from api_mcp_builder.server import app, run_server

__all__ = ["__version__", "__author__"]
