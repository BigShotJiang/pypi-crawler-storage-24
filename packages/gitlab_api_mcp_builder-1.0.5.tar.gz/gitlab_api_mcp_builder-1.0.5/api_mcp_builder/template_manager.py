"""
Gestionnaire de templates pour générer des projets à partir de templates GitLab.
"""
import os
import logging
from pathlib import Path
from typing import List, Dict, Optional
from dataclasses import dataclass

from .gitlab_client import GitLabClient

logger = logging.getLogger(__name__)


@dataclass
class FileNode:
    """Représente un fichier ou dossier dans l'arborescence."""
    path: str
    name: str
    type: str  # 'tree' pour dossier, 'blob' pour fichier
    mode: str
    id: str


class TemplateManager:
    """Gestionnaire de templates pour générer des projets."""
    
    def __init__(self, gitlab_client: GitLabClient):
        """
        Initialise le gestionnaire de templates.
        
        Args:
            gitlab_client: Client GitLab configuré
        """
        self.client = gitlab_client
    
    def get_template_structure(self, template_id: int) -> Dict:
        """
        Récupère la structure complète d'un template.
        
        Args:
            template_id: ID du template GitLab
            
        Returns:
            Dict avec les infos du template et son arborescence
        """
        try:
            # Récupérer les infos du projet
            template_info = self.client.get_project_info(template_id)
            
            # Récupérer l'arborescence
            tree = self.client.get_repository_tree(template_id, recursive=True)
            
            # Organiser par type
            files = []
            directories = []
            
            for item in tree:
                node = FileNode(
                    path=item['path'],
                    name=item['name'],
                    type=item['type'],
                    mode=item['mode'],
                    id=item['id']
                )
                
                if item['type'] == 'tree':
                    directories.append(node)
                else:
                    files.append(node)
            
            # Créer une représentation visuelle de l'arborescence
            tree_view = self._build_tree_view(files, directories)
            
            return {
                'template': {
                    'id': template_info.id,
                    'name': template_info.name,
                    'description': template_info.description,
                    'url': template_info.web_url,
                    'topics': template_info.topics
                },
                'structure': {
                    'files_count': len(files),
                    'directories_count': len(directories),
                    'files': [{'path': f.path, 'name': f.name} for f in files],
                    'directories': [{'path': d.path, 'name': d.name} for d in directories]
                },
                'tree_view': tree_view
            }
            
        except Exception as e:
            logger.error(f"Error getting template structure: {e}")
            raise
    
    def _build_tree_view(self, files: List[FileNode], directories: List[FileNode]) -> str:
        """
        Construit une représentation textuelle de l'arborescence.
        
        Args:
            files: Liste des fichiers
            directories: Liste des dossiers
            
        Returns:
            String représentant l'arborescence
        """
        all_items = sorted(
            [(d.path, 'dir') for d in directories] + [(f.path, 'file') for f in files]
        )
        
        tree_lines = []
        path_levels = {}
        
        for path, item_type in all_items:
            parts = path.split('/')
            level = len(parts) - 1
            name = parts[-1]
            
            # Indentation
            indent = '  ' * level
            
            # Symbole
            if item_type == 'dir':
                symbol = '📁'
            else:
                symbol = '📄'
            
            tree_lines.append(f"{indent}{symbol} {name}")
            path_levels[path] = level
        
        return '\n'.join(tree_lines)
    
    def generate_project(
        self,
        template_id: int,
        destination: str,
        project_name: Optional[str] = None,
        exclude_patterns: Optional[List[str]] = None
    ) -> Dict:
        """
        Génère un projet à partir d'un template.
        
        Args:
            template_id: ID du template GitLab
            destination: Dossier de destination
            project_name: Nom du projet (optionnel)
            exclude_patterns: Patterns de fichiers à exclure (ex: ['.git', '.gitlab-ci.yml'])
            
        Returns:
            Dict avec le résumé de la génération
        """
        try:
            # Récupérer les infos du template
            template_info = self.client.get_project_info(template_id)
            
            # Déterminer le nom du projet
            if not project_name:
                project_name = template_info.name.replace('-template', '').replace('template-', '')
            
            # Créer le dossier de destination
            dest_path = Path(destination) / project_name
            dest_path.mkdir(parents=True, exist_ok=True)
            
            logger.info(f"Generating project in {dest_path}")
            
            # Récupérer l'arborescence
            tree = self.client.get_repository_tree(template_id, recursive=True)
            
            exclude_patterns = exclude_patterns or ['.git', '.gitlab-ci.yml']
            
            created_files = []
            created_dirs = []
            skipped = []
            errors = []
            
            # Créer les dossiers
            for item in tree:
                if item['type'] == 'tree':
                    # Vérifier les exclusions
                    if self._should_exclude(item['path'], exclude_patterns):
                        skipped.append(item['path'])
                        continue
                    
                    dir_path = dest_path / item['path']
                    dir_path.mkdir(parents=True, exist_ok=True)
                    created_dirs.append(item['path'])
            
            # Créer les fichiers
            for item in tree:
                if item['type'] == 'blob':
                    # Vérifier les exclusions
                    if self._should_exclude(item['path'], exclude_patterns):
                        skipped.append(item['path'])
                        continue
                    
                    try:
                        # Récupérer le contenu
                        content = self.client.get_file_content(template_id, item['path'])
                        
                        # Écrire le fichier
                        file_path = dest_path / item['path']
                        file_path.parent.mkdir(parents=True, exist_ok=True)
                        
                        # Gérer les fichiers binaires et texte
                        if isinstance(content, bytes):
                            file_path.write_bytes(content)
                        else:
                            file_path.write_text(content)
                        
                        created_files.append(item['path'])
                        
                    except Exception as e:
                        logger.error(f"Error creating file {item['path']}: {e}")
                        errors.append({'path': item['path'], 'error': str(e)})
            
            result = {
                'project_name': project_name,
                'destination': str(dest_path),
                'template': {
                    'id': template_info.id,
                    'name': template_info.name
                },
                'summary': {
                    'files_created': len(created_files),
                    'directories_created': len(created_dirs),
                    'files_skipped': len(skipped),
                    'errors': len(errors)
                },
                'files': created_files[:50],  # Limiter pour éviter un retour trop long
                'has_more_files': len(created_files) > 50
            }
            
            if errors:
                result['errors'] = errors
            
            logger.info(
                f"Project generated successfully: "
                f"{len(created_files)} files, {len(created_dirs)} directories"
            )
            
            return result
            
        except Exception as e:
            logger.error(f"Error generating project: {e}")
            raise
    
    def _should_exclude(self, path: str, exclude_patterns: List[str]) -> bool:
        """
        Vérifie si un chemin doit être exclu.
        
        Args:
            path: Chemin à vérifier
            exclude_patterns: Patterns d'exclusion
            
        Returns:
            True si le fichier doit être exclu
        """
        for pattern in exclude_patterns:
            if pattern in path or path.startswith(pattern):
                return True
        return False
