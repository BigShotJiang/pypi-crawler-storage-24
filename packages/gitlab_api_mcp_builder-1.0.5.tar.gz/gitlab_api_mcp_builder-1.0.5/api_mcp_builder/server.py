#!/usr/bin/env python3
"""
Serveur MCP pour générer des projets d'agents API à partir de templates GitLab.
"""
import os
import sys
import json
import logging
import asyncio
from typing import Any, Sequence
from pathlib import Path

# Configuration du logging
logging.basicConfig(
    level=os.getenv("LOG_LEVEL", "INFO"),
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(Path(__file__).parent / "mcp-server.log"),
        logging.StreamHandler(sys.stderr)
    ]
)
logger = logging.getLogger(__name__)

# Charger les variables d'environnement
from dotenv import load_dotenv
load_dotenv()

# Importer le SDK MCP
from mcp.server import Server
from mcp.types import Tool, TextContent, ImageContent, EmbeddedResource
from mcp.server.stdio import stdio_server

# Importer nos modules
from .gitlab_client import GitLabClient
from .template_manager import TemplateManager

# Initialiser le serveur MCP
app = Server("api-mcp-builder")

# Initialiser les clients
try:
    gitlab_client = GitLabClient()
    template_manager = TemplateManager(gitlab_client)
    logger.info("GitLab client initialized successfully")
except Exception as e:
    logger.error(f"Failed to initialize GitLab client: {e}")
    logger.error("Make sure GITLAB_TOKEN is set in your environment")
    sys.exit(1)


@app.list_tools()
async def list_tools() -> list[Tool]:
    """Liste tous les outils disponibles."""
    return [
        Tool(
            name="list_templates",
            description=(
                "Liste tous les templates d'agents API disponibles depuis le groupe public GitLab 'repository-templates1'. "
                "Utilise cet outil quand l'utilisateur demande : liste des templates, templates disponibles, quels templates, "
                "voir les templates, templates API, templates GitLab, ou mentionne 'repository-templates1' ou 'agent-api'. "
                "Tu peux rechercher par nom ou filtrer par topic/tag. Le groupe par défaut est automatiquement utilisé."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "group": {
                        "type": "string",
                        "description": "Nom du groupe GitLab (optionnel, défaut: 'repository-templates1' configuré dans .env)"
                    },
                    "search": {
                        "type": "string",
                        "description": "Terme de recherche pour filtrer les templates par nom"
                    },
                    "topic": {
                        "type": "string",
                        "description": "Filtrer par topic/tag (ex: 'api-template', 'fastapi', 'agent')"
                    }
                }
            }
        ),
        Tool(
            name="preview_template",
            description=(
                "Prévisualise la structure complète d'un template GitLab : "
                "arborescence des fichiers et dossiers, nombre de fichiers, etc. "
                "Utilise cet outil quand l'utilisateur demande : voir la structure, prévisualiser, montrer l'arborescence, "
                "structure du template, contenu du template, ou avant de générer un projet pour voir ce qui sera créé."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "template_id": {
                        "type": "integer",
                        "description": "ID du template GitLab à prévisualiser"
                    }
                },
                "required": ["template_id"]
            }
        ),
        Tool(
            name="generate_project",
            description=(
                "Génère un nouveau projet d'agent API à partir d'un template GitLab. "
                "Utilise cet outil quand l'utilisateur demande : créer un projet, générer un projet, nouveau projet, "
                "scaffold un projet, initialiser depuis template, créer depuis template, ou partir d'un template. "
                "\n\n"
                "⚠️ PERSONNALISATION MINIMALISTE - Remplace UNIQUEMENT les noms aux endroits clés : "
                "\n"
                "1. **docker-compose.yml** : Remplace 'my-agent' par le nom du projet (service + container_name + image) "
                "2. **docker.manifest.json** : Remplace 'my-agent' par le nom du projet (image_name) "
                "3. **app/api/main.py** : Remplace le titre de l'API FastAPI (title=\"Mon Projet API\") "
                "4. **README.md** : Remplace le titre H1 avec le nom du projet "
                "\n"
                "⚠️ NE TOUCHE PAS au reste : "
                "- Garde TOUS les TODO/FIXME tels quels "
                "- NE remplis PAS les fichiers de service/client/schemas "
                "- NE modifie PAS requirements.txt "
                "- NE change PAS la logique métier "
                "\n"
                "Le template doit rester MINIMAL. L'utilisateur implémentera la logique métier lui-même."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "template_id": {
                        "type": "integer",
                        "description": "ID du template GitLab à utiliser"
                    },
                    "destination": {
                        "type": "string",
                        "description": "Chemin absolu du dossier de destination où générer le projet"
                    },
                    "project_name": {
                        "type": "string",
                        "description": "Nom du nouveau projet (optionnel, par défaut: nom du template sans 'template-')"
                    },
                    "context": {
                        "type": "string",
                        "description": "Contexte du projet pour personnalisation intelligente (ex: 'agent pour Netdata monitoring', 'API pour gérer des utilisateurs'). Utilise ce champ pour comprendre ce que l'utilisateur veut faire."
                    },
                    "exclude_patterns": {
                        "type": "array",
                        "items": {"type": "string"},
                        "description": "Liste de patterns à exclure (ex: ['.git', '.gitlab-ci.yml', 'README.md'])"
                    }
                },
                "required": ["template_id", "destination"]
            }
        )
    ]


@app.call_tool()
async def call_tool(name: str, arguments: Any) -> Sequence[TextContent | ImageContent | EmbeddedResource]:
    """Gère les appels aux outils."""
    
    try:
        if name == "list_templates":
            return await handle_list_templates(arguments)
        elif name == "preview_template":
            return await handle_preview_template(arguments)
        elif name == "generate_project":
            return await handle_generate_project(arguments)
        else:
            raise ValueError(f"Unknown tool: {name}")
    
    except Exception as e:
        logger.error(f"Error in tool {name}: {e}", exc_info=True)
        return [TextContent(
            type="text",
            text=f"❌ Erreur lors de l'exécution de {name}: {str(e)}"
        )]


async def handle_list_templates(arguments: dict) -> Sequence[TextContent]:
    """Gère la liste des templates."""
    logger.info(f"Listing templates with args: {arguments}")
    
    group = arguments.get("group")
    search = arguments.get("search")
    topic = arguments.get("topic")
    
    # Récupérer les templates
    templates = gitlab_client.list_templates(
        group=group,
        search=search,
        topic=topic
    )
    
    if not templates:
        return [TextContent(
            type="text",
            text="Aucun template trouvé avec ces critères. Essaie de modifier tes filtres."
        )]
    
    # Formater la réponse
    response = f"## 📦 Templates disponibles ({len(templates)})\n\n"
    
    for template in templates:
        response += f"### {template.name}\n"
        response += f"- **ID**: `{template.id}`\n"
        response += f"- **Description**: {template.description}\n"
        response += f"- **Path**: `{template.path_with_namespace}`\n"
        if template.topics:
            response += f"- **Topics**: {', '.join(template.topics)}\n"
        response += f"- **URL**: {template.web_url}\n\n"
    
    response += "\n💡 **Prochaine étape**: Utilise `preview_template` avec l'ID pour voir la structure, "
    response += "ou `generate_project` pour créer un nouveau projet."
    
    return [TextContent(type="text", text=response)]


async def handle_preview_template(arguments: dict) -> Sequence[TextContent]:
    """Gère la prévisualisation d'un template."""
    template_id = arguments["template_id"]
    logger.info(f"Previewing template {template_id}")
    
    # Récupérer la structure du template
    structure = template_manager.get_template_structure(template_id)
    
    # Formater la réponse
    template = structure['template']
    stats = structure['structure']
    
    response = f"## 📋 Prévisualisation: {template['name']}\n\n"
    response += f"**Description**: {template['description']}\n"
    response += f"**URL**: {template['url']}\n"
    if template['topics']:
        response += f"**Topics**: {', '.join(template['topics'])}\n"
    
    response += f"\n### 📊 Statistiques\n"
    response += f"- **Fichiers**: {stats['files_count']}\n"
    response += f"- **Dossiers**: {stats['directories_count']}\n"
    
    response += f"\n### 🌳 Arborescence\n\n```\n{structure['tree_view']}\n```\n"
    
    response += f"\n### 📁 Dossiers principaux\n"
    for directory in stats['directories'][:10]:  # Premiers 10 dossiers
        response += f"- `{directory['path']}`\n"
    
    if stats['directories_count'] > 10:
        response += f"- ... et {stats['directories_count'] - 10} autres dossiers\n"
    
    response += f"\n### 📄 Fichiers principaux\n"
    for file in stats['files'][:15]:  # Premiers 15 fichiers
        response += f"- `{file['path']}`\n"
    
    if stats['files_count'] > 15:
        response += f"- ... et {stats['files_count'] - 15} autres fichiers\n"
    
    response += "\n💡 **Prochaine étape**: Utilise `generate_project` pour créer un projet avec ce template."
    
    return [TextContent(type="text", text=response)]


async def handle_generate_project(arguments: dict) -> Sequence[TextContent]:
    """Gère la génération d'un projet."""
    template_id = arguments["template_id"]
    destination = arguments["destination"]
    project_name = arguments.get("project_name")
    context = arguments.get("context", "")
    exclude_patterns = arguments.get("exclude_patterns", ['.git', '.gitlab-ci.yml'])
    
    logger.info(f"Generating project from template {template_id} to {destination}")
    if context:
        logger.info(f"Project context: {context}")
    
    # Générer le projet
    result = template_manager.generate_project(
        template_id=template_id,
        destination=destination,
        project_name=project_name,
        exclude_patterns=exclude_patterns
    )
    
    # Formater la réponse
    response = f"## ✅ Projet généré avec succès!\n\n"
    response += f"**Nom du projet**: {result['project_name']}\n"
    response += f"**Destination**: `{result['destination']}`\n"
    response += f"**Template**: {result['template']['name']} (ID: {result['template']['id']})\n"
    if context:
        response += f"**Contexte**: {context}\n"
    
    response += f"\n### 📊 Résumé\n"
    summary = result['summary']
    response += f"- ✅ **Fichiers créés**: {summary['files_created']}\n"
    response += f"- 📁 **Dossiers créés**: {summary['directories_created']}\n"
    
    if summary['files_skipped'] > 0:
        response += f"- ⏭️  **Fichiers ignorés**: {summary['files_skipped']}\n"
    
    if summary['errors'] > 0:
        response += f"- ❌ **Erreurs**: {summary['errors']}\n"
        if 'errors' in result:
            response += "\n### ⚠️ Erreurs rencontrées\n"
            for error in result['errors'][:5]:
                response += f"- `{error['path']}`: {error['error']}\n"
    
    response += f"\n### 📄 Fichiers créés\n"
    for file in result['files'][:20]:
        response += f"- `{file}`\n"
    
    if result['has_more_files']:
        response += f"- ... et plus encore!\n"
    
    response += f"\n\n⚠️ **PERSONNALISATION MINIMALISTE REQUISE** : Remplace UNIQUEMENT :\n"
    response += f"1. **docker-compose.yml** : 'my-agent' → '{result['project_name']}'\n"
    response += f"2. **docker.manifest.json** : 'my-agent' → '{result['project_name']}'\n"
    response += f"3. **app/api/main.py** : title de l'API → '{result['project_name']} API'\n"
    response += f"4. **README.md** : titre H1 → '# {result['project_name']}'\n"
    response += f"\n💡 **Ne touche PAS** au reste (TODO, logique métier, schemas, etc.)\n"
    
    return [TextContent(type="text", text=response)]


async def run_server():
    """Point d'entrée principal du serveur."""
    logger.info("Starting API MCP Builder server")
    
    async with stdio_server() as (read_stream, write_stream):
        await app.run(
            read_stream,
            write_stream,
            app.create_initialization_options()
        )


if __name__ == "__main__":
    try:
        asyncio.run(run_server())
    except KeyboardInterrupt:
        logger.info("Server stopped by user")
    except Exception as e:
        logger.error(f"Server error: {e}", exc_info=True)
        sys.exit(1)
