"""
Client GitLab pour récupérer les templates et leur contenu.
"""
import os
import gitlab
import logging
from typing import List, Dict, Optional
from dataclasses import dataclass

logger = logging.getLogger(__name__)


@dataclass
class TemplateInfo:
    """Information sur un template GitLab."""
    id: int
    name: str
    description: str
    web_url: str
    path_with_namespace: str
    default_branch: str
    topics: List[str]


class GitLabClient:
    """Client pour interagir avec l'API GitLab."""
    
    def __init__(self, gitlab_url: str = None, token: str = None):
        """
        Initialise le client GitLab.
        
        Args:
            gitlab_url: URL de l'instance GitLab (défaut: https://gitlab.com)
            token: Token d'accès personnel GitLab
        """
        self.gitlab_url = gitlab_url or os.getenv("GITLAB_URL", "https://gitlab.com")
        self.token = token or os.getenv("GITLAB_TOKEN")
        self.default_group = os.getenv("TEMPLATE_GROUP", "repository-templates1")
        
        if not self.token:
            raise ValueError("GITLAB_TOKEN is required")
        
        self.gl = gitlab.Gitlab(self.gitlab_url, private_token=self.token)
        self.gl.auth()
        logger.info(f"Authenticated to GitLab as {self.gl.user.username}")
    
    def list_templates(
        self,
        group: Optional[str] = None,
        search: Optional[str] = None,
        topic: Optional[str] = None
    ) -> List[TemplateInfo]:
        """
        Liste les templates disponibles.
        
        Args:
            group: Filtrer par groupe/namespace (défaut: TEMPLATE_GROUP depuis .env)
            search: Rechercher par nom
            topic: Filtrer par topic/tag
            
        Returns:
            Liste des templates trouvés
        """
        try:
            # Utiliser le groupe par défaut si aucun n'est spécifié
            if not group:
                group = self.default_group
            
            # Chercher dans le groupe spécifié
            if group:
                try:
                    gitlab_group = self.gl.groups.get(group)
                    params = {'all': True}
                    if search:
                        params['search'] = search
                    if topic:
                        params['topic'] = topic
                    projects = gitlab_group.projects.list(**params)
                except gitlab.exceptions.GitlabGetError:
                    logger.error(f"Group '{group}' not found")
                    return []
            
            templates = []
            for project in projects:
                # Récupérer le projet complet pour avoir tous les détails
                full_project = self.gl.projects.get(project.id)
                
                templates.append(TemplateInfo(
                    id=full_project.id,
                    name=full_project.name,
                    description=full_project.description or "Pas de description",
                    web_url=full_project.web_url,
                    path_with_namespace=full_project.path_with_namespace,
                    default_branch=full_project.default_branch,
                    topics=getattr(full_project, 'topics', []) or getattr(full_project, 'tag_list', [])
                ))
            
            logger.info(f"Found {len(templates)} templates")
            return templates
            
        except Exception as e:
            logger.error(f"Error listing templates: {e}")
            raise
    

    
    def get_repository_tree(
        self, 
        project_id: int,
        path: str = "",
        ref: Optional[str] = None,
        recursive: bool = True
    ) -> List[Dict]:
        """
        Récupère l'arborescence d'un repository.
        
        Args:
            project_id: ID du projet GitLab
            path: Chemin dans le repository (défaut: racine)
            ref: Branch/tag/commit (défaut: branch par défaut)
            recursive: Récupérer récursivement tous les fichiers
            
        Returns:
            Liste des fichiers et dossiers
        """
        try:
            project = self.gl.projects.get(project_id)
            
            if not ref:
                ref = project.default_branch
            
            tree = project.repository_tree(
                path=path,
                ref=ref,
                recursive=recursive,
                all=True
            )
            
            logger.info(f"Retrieved {len(tree)} items from project {project.name}")
            return tree
            
        except Exception as e:
            logger.error(f"Error getting repository tree: {e}")
            raise
    
    def get_file_content(
        self,
        project_id: int,
        file_path: str,
        ref: Optional[str] = None
    ) -> bytes:
        """
        Récupère le contenu d'un fichier.
        
        Args:
            project_id: ID du projet GitLab
            file_path: Chemin du fichier dans le repository
            ref: Branch/tag/commit (défaut: branch par défaut)
            
        Returns:
            Contenu du fichier en bytes
        """
        try:
            project = self.gl.projects.get(project_id)
            
            if not ref:
                ref = project.default_branch
            
            file_info = project.files.get(file_path=file_path, ref=ref)
            content = file_info.decode()
            
            return content
            
        except Exception as e:
            logger.error(f"Error getting file content for {file_path}: {e}")
            raise
    
    def get_project_info(self, project_id: int) -> TemplateInfo:
        """
        Récupère les informations d'un projet.
        
        Args:
            project_id: ID du projet GitLab
            
        Returns:
            Informations sur le template
        """
        try:
            project = self.gl.projects.get(project_id)
            
            return TemplateInfo(
                id=project.id,
                name=project.name,
                description=project.description or "Pas de description",
                web_url=project.web_url,
                path_with_namespace=project.path_with_namespace,
                default_branch=project.default_branch,
                topics=getattr(project, 'topics', []) or getattr(project, 'tag_list', [])
            )
            
        except Exception as e:
            logger.error(f"Error getting project info: {e}")
            raise
