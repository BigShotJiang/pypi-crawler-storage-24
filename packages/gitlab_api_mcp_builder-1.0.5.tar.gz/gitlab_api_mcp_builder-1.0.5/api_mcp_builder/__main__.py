#!/usr/bin/env python3
"""
Point d'entrée principal pour le serveur MCP API Builder
Usage: python -m api_mcp_builder
"""
import sys
import asyncio
from .server import run_server


def main():
    """Point d'entrée pour l'exécutable api-mcp-builder"""
    try:
        asyncio.run(run_server())
    except KeyboardInterrupt:
        print("\n👋 Serveur arrêté", file=sys.stderr)
        sys.exit(0)
    except Exception as e:
        print(f"❌ Erreur: {e}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
