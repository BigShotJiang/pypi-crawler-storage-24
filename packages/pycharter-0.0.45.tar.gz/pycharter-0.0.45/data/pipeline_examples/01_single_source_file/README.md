# 01 — Single source (file) + simple transform

Extract from a CSV file, apply simple transforms (rename, convert, add, select), load to CSV.

## What it demonstrates

- Single source extraction (file, CSV)
- Simple transformation (rename, convert, defaults, add, select)
- File load (CSV)

## Files

| File | Purpose |
|------|---------|
| `extract.yaml` | Read from CSV (uses `_shared/products.csv` or `INPUT_PATH`) |
| `transform.yaml` | Rename, convert types, add fields, select columns |
| `load.yaml` | Write to CSV |
| `pipeline.yaml` | Single-file section-based pipeline |
| `input.csv` | Local copy of products data (optional; use for self-contained run) |

## How to run

From the **pycharter repo root**:

```bash
# CLI (directory with extract/transform/load)
pycharter etl run data/etl_examples/01_single_source_file

# Or with variables
pycharter etl run data/etl_examples/01_single_source_file --var INPUT_PATH=data/etl_examples/01_single_source_file/input.csv --var OUTPUT_PATH=data/etl_examples/01_single_source_file/output.csv
```

**ETL UI:** Start the API (`pycharter api`), open the ETL page, paste contents of `extract.yaml`, `transform.yaml`, and `load.yaml` into the panels, set variables if needed, and run.

Output is written to `output.csv` in this directory (or path in `OUTPUT_PATH`).
