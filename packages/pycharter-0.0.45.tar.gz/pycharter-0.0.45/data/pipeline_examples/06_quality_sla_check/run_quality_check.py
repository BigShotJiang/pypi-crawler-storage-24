"""Demonstrate how data_quality.sla in a contract drives quality threshold checks.

This script shows two complementary paths:

1. **ETL Pipeline path** — ``Pipeline.from_config_dir()`` validates records
   against the contract schema during load (pre-load validation) and runs
   post-load structural checks (row_count, null_rate, uniqueness).  Invalid
   records are quarantined to the DLQ with linked violation IDs.

2. **QualityCheck path** — ``QualityCheck.run()`` validates the same data
   against the contract and, when ``check_thresholds=True``, auto-resolves
   the SLA from ``contract.metadata.data_quality.sla``.  Any metric that
   falls below the SLA produces a threshold breach in the report.

Run from the pycharter repo root:
    python data/etl_examples/06_quality_sla_check/run_quality_check.py
"""

from __future__ import annotations

import asyncio
import logging
from pathlib import Path

import yaml

logging.basicConfig(level=logging.INFO, format="%(levelname)s  %(message)s")
logger = logging.getLogger(__name__)

EXAMPLE_DIR = Path(__file__).parent


def load_contract() -> dict:
    """Load the contract YAML as a dict."""
    with open(EXAMPLE_DIR / "contract.yaml") as f:
        return yaml.safe_load(f)


def load_input_data() -> list[dict]:
    """Load input CSV as a list of dicts."""
    import csv

    rows: list[dict] = []
    with open(EXAMPLE_DIR / "input.csv", newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            rows.append(dict(row))
    return rows


# ─── Path 1: ETL Pipeline ────────────────────────────────────────────────────


async def run_pipeline_example():
    """Run the ETL pipeline with contract validation + post-load quality checks.

    The pipeline:
    - Extracts records from input.csv
    - Transforms (coerces types)
    - Validates each record against the contract schema (pre-load)
    - Quarantines invalid records to the DLQ
    - Loads valid records to output.csv
    - Runs post-load quality checks (row_count, null_rate, uniqueness)

    The input data has intentional issues:
    - Row 4: missing VALID_SINCE (required field) → quarantined
    - Row 6: AC_STATE='X' (not in enum [R, O]) → quarantined
    - Row 7: empty REGISTRATION (required field) → quarantined
    """
    from pycharter.pipeline_generator.pipeline import Pipeline

    logger.info("=" * 60)
    logger.info("PATH 1: ETL Pipeline with contract validation")
    logger.info("=" * 60)

    pipeline = Pipeline.from_config_dir(
        EXAMPLE_DIR,
        name="quality_sla_demo",
    )
    result = await pipeline.run()

    logger.info("Pipeline result:")
    logger.info("  success:      %s", result.success)
    logger.info("  extracted:    %d", result.rows_extracted)
    logger.info("  loaded:       %d", result.rows_loaded)
    logger.info(
        "  quarantined:  %d (extract) + %d (load)",
        result.rows_quarantined_extract,
        result.rows_quarantined_load,
    )

    if result.quality_report:
        logger.info("  post-load quality checks:")
        for check in result.quality_report.checks:
            logger.info(
                "    [%s] %s — %s", check.status.value, check.check_name, check.message
            )

    if result.errors:
        logger.info("  errors: %s", result.errors)

    return result


# ─── Path 2: Standalone QualityCheck with SLA thresholds ─────────────────────


def run_quality_check_example():
    """Run QualityCheck.run() with the contract and check_thresholds=True.

    This demonstrates how the SLA thresholds from the contract's
    metadata.data_quality.sla section are auto-resolved and used to
    produce threshold breach reports.

    The contract defines:
        min_overall_score: 90.0
        max_violation_rate: 0.10
        min_completeness: 0.95
        min_accuracy: 0.90

    With 3 out of 8 records being invalid (missing required fields,
    invalid enum), the scores will breach some of these thresholds.
    """
    from pycharter.quality.check import QualityCheck
    from pycharter.quality.models import QualityCheckOptions, QualityThresholds

    logger.info("")
    logger.info("=" * 60)
    logger.info("PATH 2: QualityCheck.run() with contract SLA")
    logger.info("=" * 60)

    contract = load_contract()
    data = load_input_data()

    # Show what QualityThresholds.from_contract() resolves
    thresholds = QualityThresholds.from_contract(contract)
    logger.info("Resolved SLA thresholds from contract:")
    logger.info("  min_overall_score:  %s", thresholds.min_overall_score)
    logger.info("  max_violation_rate: %s", thresholds.max_violation_rate)
    logger.info("  min_completeness:   %s", thresholds.min_completeness)
    logger.info("  min_accuracy:       %s", thresholds.min_accuracy)

    # Run quality check with automatic SLA threshold resolution
    qc = QualityCheck()
    report = qc.run(
        contract=contract,
        data=data,
        options=QualityCheckOptions(
            check_thresholds=True,  # ← enables SLA threshold checking
            # thresholds=...,           # ← not needed; auto-resolved from contract
            record_violations=True,
            calculate_metrics=True,
            include_field_metrics=True,
        ),
    )

    logger.info("")
    logger.info("Quality Report:")
    logger.info("  schema_id:      %s", report.schema_id)
    logger.info("  record_count:   %d", report.record_count)
    logger.info("  valid_count:    %d", report.valid_count)
    logger.info("  invalid_count:  %d", report.invalid_count)
    logger.info("  violations:     %d", report.violation_count)

    if report.quality_score:
        logger.info("  overall_score:  %.1f", report.quality_score.overall_score)
        logger.info("  violation_rate: %.2f", report.quality_score.violation_rate)
        logger.info("  completeness:   %.2f", report.quality_score.completeness)
        logger.info("  accuracy:       %.2f", report.quality_score.accuracy)

    if report.threshold_breaches:
        logger.info("")
        logger.info(
            "SLA BREACHES (thresholds from contract.metadata.data_quality.sla):"
        )
        for breach in report.threshold_breaches:
            logger.info("  ✗ %s", breach)
    else:
        logger.info("  No SLA breaches — all thresholds met.")

    logger.info("  passed: %s", report.passed)

    return report


# ─── Path 3: Show the relationship between SLA presets ────────────────────────


def show_options_presets():
    """Show how QualityCheckOptions presets relate to SLA checking."""
    from pycharter.quality.models import QualityCheckOptions

    logger.info("")
    logger.info("=" * 60)
    logger.info("QualityCheckOptions presets and SLA threshold checking")
    logger.info("=" * 60)

    presets = {
        "basic": QualityCheckOptions.basic(),
        "strict": QualityCheckOptions.strict(),
        "monitoring": QualityCheckOptions.monitoring(),
    }

    for name, opts in presets.items():
        logger.info(
            "  %-12s check_thresholds=%s  record_violations=%s  include_profiling=%s",
            name,
            opts.check_thresholds,
            opts.record_violations,
            opts.include_profiling,
        )

    logger.info("")
    logger.info("When check_thresholds=True and no explicit thresholds are provided,")
    logger.info(
        "QualityCheck.run() auto-resolves them from contract.metadata.data_quality.sla"
    )


# ─── Main ─────────────────────────────────────────────────────────────────────


async def main():
    """Run all examples."""
    await run_pipeline_example()
    run_quality_check_example()
    show_options_presets()


if __name__ == "__main__":
    asyncio.run(main())
