# 03 — JSONata transform

Same source as 01 (products CSV); transform using JSONata expressions, load to JSON.

## What it demonstrates

- Single source extraction (file)
- **JSONata** transformation (per-record: uppercase, number, round, conditional category_group, $now(), lowercase)
- File load (JSON)

## Files

| File | Purpose |
|------|---------|
| `extract.yaml` | Read from products CSV |
| `transform.yaml` | JSONata expression (record mode) |
| `load.yaml` | Write to JSON |
| `pipeline.yaml` | Single-file section-based pipeline |

## How to run

From the **pycharter repo root**:

```bash
pycharter etl run data/etl_examples/03_transform_jsonata
```

Requires `pip install pyjsonata`. Output is written to `output.json`.
