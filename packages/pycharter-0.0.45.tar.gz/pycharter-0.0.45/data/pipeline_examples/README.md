# ETL examples

Sample ETL configs for the pycharter pipeline: file/HTTP sources, transforms (simple ops and JSONata), single and multiple loads, joins, and quality/failure demos.

## Table of examples

| # | Directory | Shows | Config format | Run with |
|---|-----------|--------|----------------|----------|
| 01 | [01_single_source_file/](01_single_source_file/) | Single source (file), simple transform | Section (extract/transform/load) | CLI, API, UI, or Python |
| 02 | [02_single_source_http/](02_single_source_http/) | Single source (HTTP API) | Section | Same |
| 03 | [03_transform_jsonata/](03_transform_jsonata/) | JSONata transform | Section | Same |
| 04 | [04_multi_source_join/](04_multi_source_join/) | Multiple sources, join | Steps (DAG) | Same |
| 05 | [05_multi_load/](05_multi_load/) | Multiple load destinations | Steps (DAG) | Same |
| 06 | [06_quality_sla_check/](06_quality_sla_check/) | Contract + quality SLA | Section | Same |
| — | [_failures/](_failures/) | Failure cases for dashboard/testing | Section | Run via CLI/API (expect failure) |

## How to run

All examples can be run from the **pycharter repo root** using any method:

- **CLI:** `pycharter etl run data/etl_examples/01_single_source_file`
- **API:** `POST /api/v1/etl/run` with the pipeline YAML body.
- **Python:**
  ```python
  from pycharter.pipeline_generator.pipeline import Pipeline
  import asyncio

  # From a directory (supports both section and steps formats):
  pipeline = Pipeline.from_config_dir("data/etl_examples/01_single_source_file")

  # From a single file:
  pipeline = Pipeline.from_file("data/etl_examples/04_multi_source_join/pipeline.yaml")

  asyncio.run(pipeline.run())
  ```

- **Failures (_failures/*):** Run via CLI or API; expect a non-zero exit or failed run in the dashboard.

## Config formats

pycharter accepts two config shapes. Both are fully supported across CLI, API, UI, and Python.

### Steps (canonical)

The `steps` list is the canonical format. Each step has an `id`, `type`, and references upstream steps via `input` (or `left`/`right` for joins, `inputs` for unions). This format supports DAGs: multiple extracts, joins, unions, and multiple loads.

```yaml
name: my_pipeline
steps:
  - id: extract-orders
    type: extract
    source:
      type: file
      path: orders.csv
      format: csv
  - id: transform-clean
    type: transform
    input: extract-orders
    operations:
      rename: { order_id: id }
  - id: load-output
    type: load
    input: transform-clean
    target:
      type: file
      path: output.json
      format: json
```

### Sections (backward compatible)

For simple linear pipelines (one extract, optional transform, one load), the section-based format is a convenient shorthand. It is automatically converted to steps internally.

```yaml
name: my_pipeline
extract:
  type: file
  path: orders.csv
  format: csv
transform:
  - rename: { order_id: id }
load:
  type: file
  path: output.json
  format: json
```

## Mock data

- **[_shared/](_shared/):** Shared files used by multiple examples:
  - `variables.yaml` — `INPUT_PATH`, `OUTPUT_PATH`, `API_URL`.
  - `settings.yaml` — Optional lineage/DLQ settings.
  - `products.csv`, `orders.csv`, `customers.csv` — Small CSVs for file-based examples and joins.

- **Per-example:** Some examples keep a local `input.csv` so the dir is self-contained. Paths use variables (e.g. `${INPUT_PATH:-data/etl_examples/_shared/products.csv}`) so runs work from repo root.
