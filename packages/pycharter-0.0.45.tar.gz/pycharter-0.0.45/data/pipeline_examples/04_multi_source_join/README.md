# 04 — Multi-source join (step-based)

Two CSV extracts (orders, customers), join on `customer_id`, load to JSON.

## What it demonstrates

- **Multiple source** extraction (two file extract steps)
- **Join** step (left join on customer_id)
- Single load (file)

This example uses the **step-based** pipeline format (`steps` list), not the section-based extract/transform/load panels.

## Files

| File | Purpose |
|------|---------|
| `pipeline.yaml` | Step-based config (extract x2, join, load) |
| `orders.csv` | Mock orders (order_id, customer_id, amount, order_date) |
| `customers.csv` | Mock customers (customer_id, name, region) |

## How to run

From the **pycharter repo root** (step-based pipelines use `Pipeline.from_file`, not `pycharter etl run`):

```python
import asyncio
from pycharter import Pipeline

pipeline = Pipeline.from_file("data/etl_examples/04_multi_source_join/pipeline.yaml")
result = asyncio.run(pipeline.run())
print(f"Rows loaded: {result.rows_loaded}")
```

Output is written to `output.json` in this directory.
