"""Route handlers for pipeline configuration management.

CRUD endpoints for storing, listing, retrieving, and managing versioned
pipeline configurations (steps-native).
"""

from __future__ import annotations

import logging
from typing import Any

from fastapi import APIRouter, Depends, HTTPException, status

from pycharter.api.dependencies.pipeline_store import get_pipeline_store
from pycharter.api.models.pipeline_configs import (
    PipelineConfigListResponse,
    PipelineConfigResponse,
    PipelineConfigRunRequest,
    PipelineConfigStatusUpdateRequest,
    PipelineConfigStoreRequest,
    PipelineConfigStoreResponse,
    PipelineConfigSummary,
    PipelineConfigUpdateRequest,
    PipelineConfigVersionsResponse,
)
from pycharter.pipeline_store.client import PipelineStoreClient

logger = logging.getLogger(__name__)

router = APIRouter(tags=["Pipeline Configs"])


# ---------------------------------------------------------------------------
# Store
# ---------------------------------------------------------------------------


@router.post(
    "/pipeline/configs",
    response_model=PipelineConfigStoreResponse,
    status_code=status.HTTP_201_CREATED,
    summary="Store pipeline configuration",
    description=(
        "Store a new versioned pipeline configuration. The "
        "(pipeline_name, pipeline_version) pair must be unique."
    ),
)
async def store_pipeline_config(
    request: PipelineConfigStoreRequest,
    store: PipelineStoreClient = Depends(get_pipeline_store),
) -> PipelineConfigStoreResponse:
    try:
        config_id = store.store_config(
            pipeline_name=request.pipeline_name,
            pipeline_version=request.pipeline_version,
            steps=request.steps,
            settings=request.settings,
            variables=request.variables,
            description=request.description,
            contract_name=request.contract_name,
            contract_version=request.contract_version,
            created_by=request.created_by,
        )
    except ValueError as exc:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=str(exc),
        ) from exc

    return PipelineConfigStoreResponse(
        id=config_id,
        pipeline_name=request.pipeline_name,
        pipeline_version=request.pipeline_version,
    )


# ---------------------------------------------------------------------------
# List
# ---------------------------------------------------------------------------


@router.get(
    "/pipeline/configs",
    response_model=PipelineConfigListResponse,
    summary="List pipeline configurations",
    description="List stored pipeline configurations.",
)
async def list_pipeline_configs(
    pipeline_name: str | None = None,
    store: PipelineStoreClient = Depends(get_pipeline_store),
) -> PipelineConfigListResponse:
    configs = store.list_configs(pipeline_name=pipeline_name)
    return PipelineConfigListResponse(
        configs=[PipelineConfigSummary(**c) for c in configs],
        total=len(configs),
    )


# ---------------------------------------------------------------------------
# Get
# ---------------------------------------------------------------------------


@router.get(
    "/pipeline/configs/{pipeline_name}/{pipeline_version}",
    response_model=PipelineConfigResponse,
    summary="Get pipeline configuration",
    description="Retrieve the full pipeline configuration.",
)
async def get_pipeline_config(
    pipeline_name: str,
    pipeline_version: str,
    store: PipelineStoreClient = Depends(get_pipeline_store),
) -> PipelineConfigResponse:
    config = store.get_config(pipeline_name, pipeline_version)
    if config is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Pipeline config not found: {pipeline_name!r} @ {pipeline_version!r}",
        )
    return PipelineConfigResponse(**config)


# ---------------------------------------------------------------------------
# Patch (update steps/settings/variables/description)
# ---------------------------------------------------------------------------


@router.patch(
    "/pipeline/configs/{pipeline_name}/{pipeline_version}",
    status_code=status.HTTP_204_NO_CONTENT,
    summary="Update pipeline configuration",
    description="Patch mutable fields (steps, settings, variables, description).",
)
async def update_pipeline_config(
    pipeline_name: str,
    pipeline_version: str,
    request: PipelineConfigUpdateRequest,
    store: PipelineStoreClient = Depends(get_pipeline_store),
) -> None:
    try:
        store.update_config(
            pipeline_name,
            pipeline_version,
            steps=request.steps,
            settings=request.settings,
            variables=request.variables,
            description=request.description,
            updated_by=request.updated_by,
        )
    except ValueError as exc:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(exc),
        ) from exc


# ---------------------------------------------------------------------------
# List versions
# ---------------------------------------------------------------------------


@router.get(
    "/pipeline/configs/{pipeline_name}/versions",
    response_model=PipelineConfigVersionsResponse,
    summary="List pipeline versions",
    description="List all stored versions for a given pipeline.",
)
async def list_pipeline_config_versions(
    pipeline_name: str,
    store: PipelineStoreClient = Depends(get_pipeline_store),
) -> PipelineConfigVersionsResponse:
    versions = store.list_versions(pipeline_name)
    return PipelineConfigVersionsResponse(
        pipeline_name=pipeline_name,
        versions=versions,
    )


# ---------------------------------------------------------------------------
# Update status
# ---------------------------------------------------------------------------


@router.patch(
    "/pipeline/configs/{pipeline_name}/{pipeline_version}/status",
    status_code=status.HTTP_204_NO_CONTENT,
    summary="Update pipeline config status",
    description="Update the lifecycle status (active, deprecated, draft).",
)
async def update_pipeline_config_status(
    pipeline_name: str,
    pipeline_version: str,
    request: PipelineConfigStatusUpdateRequest,
    store: PipelineStoreClient = Depends(get_pipeline_store),
) -> None:
    try:
        store.update_status(
            pipeline_name,
            pipeline_version,
            request.status.value,
            updated_by=request.updated_by,
        )
    except ValueError as exc:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(exc),
        ) from exc


# ---------------------------------------------------------------------------
# Delete
# ---------------------------------------------------------------------------


@router.delete(
    "/pipeline/configs/{pipeline_name}/{pipeline_version}",
    status_code=status.HTTP_204_NO_CONTENT,
    summary="Delete pipeline configuration",
    description="Delete a stored pipeline configuration.",
)
async def delete_pipeline_config(
    pipeline_name: str,
    pipeline_version: str,
    store: PipelineStoreClient = Depends(get_pipeline_store),
) -> None:
    deleted = store.delete_config(pipeline_name, pipeline_version)
    if not deleted:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Pipeline config not found: {pipeline_name!r} @ {pipeline_version!r}",
        )


# ---------------------------------------------------------------------------
# Run stored config
# ---------------------------------------------------------------------------


@router.post(
    "/pipeline/configs/{pipeline_name}/{pipeline_version}/run",
    status_code=status.HTTP_200_OK,
    summary="Run a stored pipeline configuration",
    description=("Retrieve a stored config, build a Pipeline, and execute it."),
)
async def run_stored_pipeline_config(
    pipeline_name: str,
    pipeline_version: str,
    request: PipelineConfigRunRequest,
    store: PipelineStoreClient = Depends(get_pipeline_store),
) -> dict[str, Any]:
    pipeline_dict = store.get_pipeline_dict(pipeline_name, pipeline_version)
    if pipeline_dict is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Pipeline config not found: {pipeline_name!r} @ {pipeline_version!r}",
        )

    if request.variable_overrides:
        existing_vars = pipeline_dict.get("variables") or {}
        existing_vars.update(request.variable_overrides)
        pipeline_dict["variables"] = existing_vars

    from pycharter import Pipeline

    try:
        pipeline = Pipeline.from_dict(pipeline_dict)
    except Exception as exc:
        logger.exception("Pipeline build failed for stored config")
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Pipeline config invalid: {exc!s}",
        ) from exc

    try:
        result = await pipeline.run()
    except Exception as exc:
        logger.exception("Pipeline run failed for stored config")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=str(exc),
        ) from exc

    return {
        "success": result.success,
        "rows_extracted": result.rows_extracted,
        "rows_transformed": result.rows_transformed,
        "rows_loaded": result.rows_loaded,
        "rows_failed": result.rows_failed,
        "duration_seconds": result.duration_seconds,
        "errors": result.errors or [],
        "pipeline_name": result.pipeline_name,
        "run_id": result.run_id,
    }
