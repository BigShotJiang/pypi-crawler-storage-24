"""Route handlers for template file downloads.

Provides endpoints to download template files for:
- Contract artifacts (schema, metadata, coercion/validation rules, contract)
- Pipeline configs (extract, transform, load)
"""

from __future__ import annotations

import logging

from fastapi import APIRouter, HTTPException, status
from fastapi.responses import FileResponse, JSONResponse, Response

from pycharter.api.services.template_service import (
    InvalidFilenameError,
    TemplateNotFoundError,
    build_contract_artifacts_zip,
    build_pipeline_artifacts_zip,
    get_contract_template_path,
    get_pipeline_template_path,
    list_pipeline_template_names,
)

logger = logging.getLogger(__name__)
router = APIRouter(tags=["Templates"])


# ---------------------------------------------------------------------------
# Contract template downloads
# ---------------------------------------------------------------------------


@router.get(
    "/templates/schema",
    summary="Download schema template",
    description="Download a template YAML file for creating a new schema",
    response_description="YAML template file",
    tags=["Templates"],
)
async def download_schema_template() -> FileResponse:
    """Download the schema template file."""
    return _serve_contract_template("template_schema.yaml")


@router.get(
    "/templates/metadata",
    summary="Download metadata template",
    description="Download a template YAML file for creating new metadata",
    response_description="YAML template file",
    tags=["Templates"],
)
async def download_metadata_template() -> FileResponse:
    """Download the metadata template file."""
    return _serve_contract_template("template_metadata.yaml")


@router.get(
    "/templates/coercion-rules",
    summary="Download coercion rules template",
    description="Download a template YAML file for creating new coercion rules",
    response_description="YAML template file",
    tags=["Templates"],
)
async def download_coercion_rules_template() -> FileResponse:
    """Download the coercion rules template file."""
    return _serve_contract_template("template_coercion_rules.yaml")


@router.get(
    "/templates/validation-rules",
    summary="Download validation rules template",
    description="Download a template YAML file for creating new validation rules",
    response_description="YAML template file",
    tags=["Templates"],
)
async def download_validation_rules_template() -> FileResponse:
    """Download the validation rules template file."""
    return _serve_contract_template("template_validation_rules.yaml")


@router.get(
    "/templates/contract-artifacts",
    summary="Download contract artifact templates",
    description=(
        "Download a ZIP archive containing all contract artifact templates "
        "(schema, metadata, coercion rules, validation rules, and contract)"
    ),
    response_description="ZIP archive containing template files",
    tags=["Templates"],
)
async def download_contract_artifacts() -> Response:
    """Download all contract artifact templates as a ZIP archive."""
    try:
        content = build_contract_artifacts_zip()
    except TemplateNotFoundError as exc:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND, detail=str(exc)
        ) from exc
    except Exception as exc:
        logger.error("Error creating contract artifacts ZIP: %s", exc, exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to create contract artifacts ZIP: {exc}",
        ) from exc

    return Response(
        content=content,
        media_type="application/zip",
        headers={
            "Content-Disposition": 'attachment; filename="contract_artifact_templates.zip"',
        },
    )


# ---------------------------------------------------------------------------
# Pipeline template endpoints
# ---------------------------------------------------------------------------


@router.get(
    "/templates/pipeline",
    summary="List pipeline template filenames",
    description=(
        "Return a list of available pipeline config template filenames "
        "(extract, transform, load). Use GET /templates/pipeline/{filename} to download one."
    ),
    response_description="JSON array of template filenames",
    tags=["Templates"],
)
async def list_pipeline_templates() -> JSONResponse:
    """List available pipeline config template filenames."""
    try:
        names = list_pipeline_template_names()
    except TemplateNotFoundError as exc:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND, detail=str(exc)
        ) from exc
    except Exception as exc:
        logger.error("Error listing pipeline templates: %s", exc, exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to list pipeline templates: {exc}",
        ) from exc

    return JSONResponse(content={"templates": names})


@router.get(
    "/templates/pipeline/{filename:path}",
    summary="Download a pipeline config template",
    description=(
        "Download a single pipeline template by filename "
        "(e.g. extract_http_simple.yaml, transform_simple.yaml, load_file.yaml). "
        "Use GET /templates/pipeline to see available names."
    ),
    response_description="YAML or Markdown file",
    tags=["Templates"],
)
async def download_pipeline_template(filename: str) -> FileResponse:
    """Download one pipeline config template file."""
    try:
        template_path = get_pipeline_template_path(filename)
    except InvalidFilenameError as exc:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST, detail=str(exc)
        ) from exc
    except TemplateNotFoundError as exc:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND, detail=str(exc)
        ) from exc
    except Exception as exc:
        logger.error(
            "Error serving pipeline template %s: %s", filename, exc, exc_info=True
        )
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to serve pipeline template: {exc}",
        ) from exc

    media_type = (
        "text/markdown" if template_path.suffix == ".md" else "application/x-yaml"
    )
    return FileResponse(
        path=str(template_path),
        media_type=media_type,
        filename=template_path.name,
        headers={"Content-Disposition": f'attachment; filename="{template_path.name}"'},
    )


@router.get(
    "/templates/pipeline-artifacts",
    summary="Download all pipeline config templates",
    description=(
        "Download a ZIP archive of all pipeline config templates "
        "(extract, transform, load YAMLs and README)."
    ),
    response_description="ZIP archive containing pipeline template files",
    tags=["Templates"],
)
async def download_pipeline_artifacts() -> Response:
    """Download all pipeline config templates as a ZIP archive."""
    try:
        content = build_pipeline_artifacts_zip()
    except TemplateNotFoundError as exc:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND, detail=str(exc)
        ) from exc
    except Exception as exc:
        logger.error("Error creating pipeline templates ZIP: %s", exc, exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to create pipeline templates ZIP: {exc}",
        ) from exc

    return Response(
        content=content,
        media_type="application/zip",
        headers={
            "Content-Disposition": 'attachment; filename="pipeline_config_templates.zip"'
        },
    )


# ---------------------------------------------------------------------------
# Private helpers
# ---------------------------------------------------------------------------


def _serve_contract_template(filename: str) -> FileResponse:
    """Resolve a contract template path and return a FileResponse."""
    try:
        template_path = get_contract_template_path(filename)
    except TemplateNotFoundError as exc:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND, detail=str(exc)
        ) from exc
    except Exception as exc:
        logger.error("Error serving template %s: %s", filename, exc, exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to serve template: {exc}",
        ) from exc

    return FileResponse(
        path=str(template_path),
        media_type="application/x-yaml",
        filename=filename,
        headers={
            "Content-Disposition": f'attachment; filename="{filename}"',
        },
    )
