"""Knowledge schema info and CRUD API routes."""

from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException

from pycharter.api.dependencies import get_db_session
from pycharter.api.models.semantic_schema import (
    CreateConceptTypeRequest,
    CreateRelationshipTypeRequest,
    CreateTierRequest,
    UpdateConceptTypeRequest,
    UpdateRelationshipTypeRequest,
    UpdateTierRequest,
)
from pycharter.api.services.semantic_schema_service import (
    SchemaItemConflictError,
    SchemaItemNotFoundError,
    SchemaItemProtectedError,
)
from pycharter.api.services.semantic_schema_service import (
    create_concept_type as svc_create_concept_type,
)
from pycharter.api.services.semantic_schema_service import (
    create_relationship_type as svc_create_relationship_type,
)
from pycharter.api.services.semantic_schema_service import (
    create_tier as svc_create_tier,
)
from pycharter.api.services.semantic_schema_service import (
    delete_concept_type as svc_delete_concept_type,
)
from pycharter.api.services.semantic_schema_service import (
    delete_relationship_type as svc_delete_relationship_type,
)
from pycharter.api.services.semantic_schema_service import (
    delete_tier as svc_delete_tier,
)
from pycharter.api.services.semantic_schema_service import (
    list_concept_types as svc_list_concept_types,
)
from pycharter.api.services.semantic_schema_service import (
    list_relationship_types as svc_list_relationship_types,
)
from pycharter.api.services.semantic_schema_service import (
    list_tiers as svc_list_tiers,
)
from pycharter.api.services.semantic_schema_service import (
    update_concept_type as svc_update_concept_type,
)
from pycharter.api.services.semantic_schema_service import (
    update_relationship_type as svc_update_relationship_type,
)
from pycharter.api.services.semantic_schema_service import (
    update_tier as svc_update_tier,
)
from pycharter.semantic.ontology.schema_loader import (
    get_cardinality_rules,
    get_registry,
    load_ontology_schema,
)

router = APIRouter(tags=["Semantic - Schema"])


# ---------------------------------------------------------------------------
# Relationship types
# ---------------------------------------------------------------------------


@router.get("/relationship-types")
async def list_relationship_types(session=Depends(get_db_session)):
    """List all available relationship types with metadata."""
    return svc_list_relationship_types(session)


@router.post("/relationship-types", status_code=201)
async def create_relationship_type(
    request: CreateRelationshipTypeRequest,
    session=Depends(get_db_session),
):
    """Create a custom relationship type."""
    try:
        return svc_create_relationship_type(session, request)
    except SchemaItemConflictError as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc


@router.put("/relationship-types/{name}")
async def update_relationship_type(
    name: str,
    request: UpdateRelationshipTypeRequest,
    session=Depends(get_db_session),
):
    """Update a relationship type."""
    try:
        return svc_update_relationship_type(session, name, request)
    except SchemaItemNotFoundError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc


@router.delete("/relationship-types/{name}")
async def delete_relationship_type(
    name: str,
    session=Depends(get_db_session),
):
    """Delete a custom relationship type. Built-in types cannot be deleted."""
    try:
        return svc_delete_relationship_type(session, name)
    except SchemaItemNotFoundError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    except SchemaItemProtectedError as exc:
        raise HTTPException(status_code=403, detail=str(exc)) from exc


# ---------------------------------------------------------------------------
# Concept types
# ---------------------------------------------------------------------------


@router.get("/concept-types")
async def list_concept_types(session=Depends(get_db_session)):
    """List all available concept types with descriptions."""
    return svc_list_concept_types(session)


@router.post("/concept-types", status_code=201)
async def create_concept_type(
    request: CreateConceptTypeRequest,
    session=Depends(get_db_session),
):
    """Create a custom concept type."""
    try:
        return svc_create_concept_type(session, request)
    except SchemaItemConflictError as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc


@router.put("/concept-types/{name}")
async def update_concept_type(
    name: str,
    request: UpdateConceptTypeRequest,
    session=Depends(get_db_session),
):
    """Update a concept type."""
    try:
        return svc_update_concept_type(session, name, request)
    except SchemaItemNotFoundError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc


@router.delete("/concept-types/{name}")
async def delete_concept_type(
    name: str,
    session=Depends(get_db_session),
):
    """Delete a custom concept type. Built-in types cannot be deleted."""
    try:
        return svc_delete_concept_type(session, name)
    except SchemaItemNotFoundError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    except SchemaItemProtectedError as exc:
        raise HTTPException(status_code=403, detail=str(exc)) from exc


# ---------------------------------------------------------------------------
# Tiers
# ---------------------------------------------------------------------------


@router.get("/tiers")
async def list_tiers(session=Depends(get_db_session)):
    """List all available governance tiers with descriptions."""
    return svc_list_tiers(session)


@router.post("/tiers", status_code=201)
async def create_tier(
    request: CreateTierRequest,
    session=Depends(get_db_session),
):
    """Create a custom governance tier."""
    try:
        return svc_create_tier(session, request)
    except SchemaItemConflictError as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc


@router.put("/tiers/{name}")
async def update_tier(
    name: str,
    request: UpdateTierRequest,
    session=Depends(get_db_session),
):
    """Update a tier."""
    try:
        return svc_update_tier(session, name, request)
    except SchemaItemNotFoundError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc


@router.delete("/tiers/{name}")
async def delete_tier(
    name: str,
    session=Depends(get_db_session),
):
    """Delete a custom tier. Built-in tiers cannot be deleted."""
    try:
        return svc_delete_tier(session, name)
    except SchemaItemNotFoundError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    except SchemaItemProtectedError as exc:
        raise HTTPException(status_code=403, detail=str(exc)) from exc


# ---------------------------------------------------------------------------
# Cardinality rules
# ---------------------------------------------------------------------------


@router.get("/cardinality-rules")
async def list_cardinality_rules():
    """List all cardinality rules grouped by concept type."""
    try:
        rules = get_cardinality_rules()
        return [
            {
                "concept_type": r.concept_type,
                "relationship_type": r.relationship_type,
                "direction": r.direction,
                "min": r.min,
                "message": r.message,
            }
            for r in rules
        ]
    except FileNotFoundError as e:
        raise HTTPException(status_code=500, detail=str(e)) from e


# ---------------------------------------------------------------------------
# Schema version
# ---------------------------------------------------------------------------


@router.get("/version")
async def get_schema_version():
    """Get the current ontology schema version and counts."""
    try:
        schema = load_ontology_schema()
        return {
            "version": schema.version,
            "relationship_type_count": len(schema.relationship_types),
            "concept_type_count": len(schema.concept_types),
            "tier_count": len(schema.tiers),
            "cardinality_rule_count": len(schema.cardinality_rules),
        }
    except FileNotFoundError as e:
        raise HTTPException(status_code=500, detail=str(e)) from e


# ---------------------------------------------------------------------------
# Schema export
# ---------------------------------------------------------------------------


@router.get("/export")
async def export_schema(session=Depends(get_db_session)):
    """Export the full merged schema as a structured YAML-compatible dict."""
    registry = get_registry()
    schema = registry.get_schema(session=session)

    relationship_types = {}
    for name, info in schema.relationship_types.items():
        relationship_types[name] = {
            "meaning": info.meaning,
            "graph_shape": info.graph_shape,
            "inverse": info.inverse,
            "symmetric": info.symmetric,
            "predicate": info.predicate,
            "domain_types": list(info.domain_types),
            "range_types": list(info.range_types),
        }

    cardinality_rules: dict[str, list[dict]] = {}
    for rule in schema.cardinality_rules:
        if rule.concept_type not in cardinality_rules:
            cardinality_rules[rule.concept_type] = []
        cardinality_rules[rule.concept_type].append(
            {
                "relationship_type": rule.relationship_type,
                "direction": rule.direction,
                "min": rule.min,
                "message": rule.message,
            }
        )

    return {
        "version": schema.version,
        "relationship_types": relationship_types,
        "concept_types": dict(schema.concept_types),
        "tiers": dict(schema.tiers),
        "cardinality_rules": cardinality_rules,
    }
