"""Route handlers for quality assurance.

NOTE: 394 lines — consider splitting before adding new functionality.
"""

from __future__ import annotations

from typing import Any

from fastapi import (
    APIRouter,
    Body,
    Depends,
    File,
    Form,
    HTTPException,
    Query,
    UploadFile,
    status,
)
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session

from pycharter.api.dependencies.database import get_db_session
from pycharter.api.dependencies.store import get_contract_store
from pycharter.api.models.quality import (
    FieldQualityMetricsResponse,
    QualityCheckRequest,
    QualityReportResponse,
    QualityScoreResponse,
    ViolationQueryRequest,
    ViolationRecordResponse,
    ViolationsResponse,
)
from pycharter.api.services.quality_service import (
    QualityCheckValidationError,
    QualityMetricNotFoundError,
    QualityReportNotFoundError,
    convert_report_to_response,
)
from pycharter.api.services.quality_service import (
    get_quality_metric as svc_get_quality_metric,
)
from pycharter.api.services.quality_service import (
    get_quality_reports as svc_get_quality_reports,
)
from pycharter.api.services.quality_service import (
    list_quality_metrics as svc_list_quality_metrics,
)
from pycharter.api.services.quality_service import (
    query_violations as svc_query_violations,
)
from pycharter.api.services.quality_service import (
    run_quality_check as svc_run_quality_check,
)
from pycharter.api.services.quality_service import (
    run_quality_check_with_file as svc_run_quality_check_with_file,
)
from pycharter.api.services.quality_threshold_service import (
    ContractMetadataNotFoundError,
    ContractStoreError,
)
from pycharter.api.services.quality_threshold_service import (
    get_thresholds as svc_get_thresholds,
)
from pycharter.api.services.quality_threshold_service import (
    update_thresholds as svc_update_thresholds,
)
from pycharter.contract_store import ContractStoreClient

router = APIRouter(tags=["Quality"])


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _build_report_response(report_dict: dict) -> QualityReportResponse:
    """Convert a service-layer report dict into a response model."""
    quality_score = None
    if report_dict["quality_score"]:
        quality_score = QualityScoreResponse(**report_dict["quality_score"])

    field_metrics = {
        name: FieldQualityMetricsResponse(**data)
        for name, data in report_dict["field_metrics"].items()
    }

    return QualityReportResponse(
        schema_id=report_dict["schema_id"],
        schema_version=report_dict["schema_version"],
        check_timestamp=report_dict["check_timestamp"],
        quality_score=quality_score,
        field_metrics=field_metrics,
        violation_count=report_dict["violation_count"],
        record_count=report_dict["record_count"],
        valid_count=report_dict["valid_count"],
        invalid_count=report_dict["invalid_count"],
        threshold_breaches=report_dict["threshold_breaches"],
        passed=report_dict["passed"],
        metadata=report_dict["metadata"],
    )


# ---------------------------------------------------------------------------
# Routes
# ---------------------------------------------------------------------------


@router.post(
    "/quality/check",
    response_model=QualityReportResponse,
    status_code=status.HTTP_200_OK,
    summary="Run contract (row-based) quality check",
    description="Validate each row against a data contract and compute metrics.",
)
async def quality_check(
    request: QualityCheckRequest,
    store: ContractStoreClient = Depends(get_contract_store),
    db: Session = Depends(get_db_session),
) -> QualityReportResponse:
    """Run a quality check against a data contract."""
    try:
        report = svc_run_quality_check(
            contract_name=request.contract_name,
            contract_version=request.contract_version,
            contract=request.contract,
            data=request.data,
            record_violations=request.record_violations,
            calculate_metrics=request.calculate_metrics,
            check_thresholds=request.check_thresholds,
            thresholds=request.thresholds,
            include_field_metrics=request.include_field_metrics,
            sample_size=request.sample_size,
            data_source=request.data_source,
            data_version=request.data_version,
            store=store,
            db=db,
        )
    except QualityCheckValidationError as exc:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST, detail=str(exc)
        ) from exc

    return _build_report_response(convert_report_to_response(report))


@router.post(
    "/quality/check/upload",
    response_model=QualityReportResponse,
    status_code=status.HTTP_200_OK,
    summary="Run quality check with file upload",
    description="Run a quality check using an uploaded file (JSON or CSV).",
)
async def quality_check_upload(
    file: UploadFile = File(..., description="Data file (JSON or CSV)"),
    contract_name: str | None = Form(None, description="Data contract name"),
    contract_version: str | None = Form(None, description="Data contract version"),
    contract: str | None = Form(None, description="Contract JSON string"),
    record_violations: bool = Form(True, description="Record violations"),
    calculate_metrics: bool = Form(True, description="Calculate quality metrics"),
    check_thresholds: bool = Form(False, description="Check quality thresholds"),
    thresholds: str | None = Form(None, description="Thresholds JSON string"),
    include_field_metrics: bool = Form(True, description="Include field metrics"),
    sample_size: int | None = Form(None, description="Sample size"),
    data_source: str | None = Form(None, description="Data source identifier"),
    data_version: str | None = Form(None, description="Data version identifier"),
    store: ContractStoreClient = Depends(get_contract_store),
    db: Session = Depends(get_db_session),
) -> QualityReportResponse:
    """Run a quality check with an uploaded file (JSON or CSV)."""
    try:
        content = await file.read()
        report = svc_run_quality_check_with_file(
            file_content=content,
            filename=file.filename,
            contract_name=contract_name,
            contract_version=contract_version,
            contract_raw=contract,
            record_violations=record_violations,
            calculate_metrics=calculate_metrics,
            check_thresholds=check_thresholds,
            thresholds_raw=thresholds,
            include_field_metrics=include_field_metrics,
            sample_size=sample_size,
            data_source=data_source,
            data_version=data_version,
            store=store,
            db=db,
        )
    except QualityCheckValidationError as exc:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST, detail=str(exc)
        ) from exc
    except Exception as exc:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Quality check failed: {exc}",
        ) from exc

    return _build_report_response(convert_report_to_response(report))


@router.post(
    "/quality/violations",
    response_model=ViolationsResponse,
    status_code=status.HTTP_200_OK,
    summary="Query violations",
    description="Query data quality violations.",
)
async def query_violations_route(
    request: ViolationQueryRequest,
    store: ContractStoreClient = Depends(get_contract_store),
) -> ViolationsResponse:
    """Query data quality violations."""
    try:
        violations, summary = svc_query_violations(
            schema_id=request.schema_id,
            start_date=request.start_date,
            end_date=request.end_date,
            severity=request.severity,
            violation_status=request.status,
            store=store,
        )
    except Exception as exc:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to query violations: {exc}",
        ) from exc

    violation_responses = [
        ViolationRecordResponse(
            id=str(v.id),
            schema_id=v.schema_id,
            record_id=v.record_id,
            severity=v.severity,
            status=v.status,
            field_violations=v.field_violations,
            error_count=len(v.field_violations),
            timestamp=v.timestamp,
            resolved_at=v.resolved_at,
            resolved_by=v.resolved_by,
            metadata=v.metadata,
        )
        for v in violations
    ]

    return ViolationsResponse(
        violations=violation_responses,
        total=len(violation_responses),
        summary=summary,
    )


@router.get(
    "/quality/metrics",
    status_code=status.HTTP_200_OK,
    summary="List quality metrics",
    description="Retrieve quality metrics for different data feeds/schemas.",
)
async def list_quality_metrics(
    schema_id: str | None = Query(None, description="Filter by schema ID"),
    limit: int = Query(100, ge=1, le=1000, description="Max results"),
    offset: int = Query(0, ge=0, description="Offset for pagination"),
    db: Session = Depends(get_db_session),
) -> dict:
    """List quality metrics from the database."""
    try:
        return svc_list_quality_metrics(
            schema_id=schema_id, limit=limit, offset=offset, db=db
        )
    except Exception as exc:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to retrieve quality metrics: {exc}",
        ) from exc


@router.get(
    "/quality/metrics/{metric_id}",
    status_code=status.HTTP_200_OK,
    summary="Get quality metric by ID",
    description="Retrieve a specific quality metric by its ID.",
)
async def get_quality_metric(
    metric_id: str,
    db: Session = Depends(get_db_session),
) -> dict:
    """Get a specific quality metric from the database by ID."""
    try:
        return svc_get_quality_metric(metric_id=metric_id, db=db)
    except QualityCheckValidationError as exc:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST, detail=str(exc)
        ) from exc
    except QualityMetricNotFoundError as exc:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND, detail=str(exc)
        ) from exc
    except Exception as exc:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to get quality metric: {exc}",
        ) from exc


@router.get(
    "/quality/reports/{schema_id}",
    status_code=status.HTTP_200_OK,
    summary="Get quality report for schema",
    description="Retrieve the latest quality report for a specific schema.",
)
async def get_quality_report(
    schema_id: str,
    data_source: str | None = Query(None, description="Filter by data source"),
    limit: int = Query(10, ge=1, le=100, description="Max reports to return"),
    db: Session = Depends(get_db_session),
) -> dict:
    """Get quality reports for a specific schema."""
    try:
        return svc_get_quality_reports(
            schema_id=schema_id, data_source=data_source, limit=limit, db=db
        )
    except QualityReportNotFoundError as exc:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND, detail=str(exc)
        ) from exc
    except Exception as exc:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to get quality report: {exc}",
        ) from exc


# ---------------------------------------------------------------------------
# Thresholds (SLA) endpoints
# ---------------------------------------------------------------------------


class ThresholdsUpdateRequest(BaseModel):
    """Request body for updating SLA thresholds."""

    min_overall_score: float = Field(95.0, ge=0.0, le=100.0)
    max_violation_rate: float = Field(0.05, ge=0.0, le=1.0)
    min_completeness: float = Field(0.95, ge=0.0, le=1.0)
    min_accuracy: float = Field(0.95, ge=0.0, le=1.0)
    field_thresholds: dict[str, dict[str, float]] = Field(default_factory=dict)


@router.get(
    "/quality/thresholds/{name}/{version}",
    status_code=status.HTTP_200_OK,
    summary="Get SLA thresholds for a contract",
    description="Retrieve the quality SLA thresholds for a data contract.",
)
async def get_thresholds(
    name: str,
    version: str,
    store: ContractStoreClient = Depends(get_contract_store),
) -> dict[str, Any]:
    """Get quality SLA thresholds from a data contract."""
    try:
        return svc_get_thresholds(name, version, store)
    except ContractMetadataNotFoundError as exc:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND, detail=str(exc)
        ) from exc
    except ContractStoreError as exc:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(exc)
        ) from exc


@router.put(
    "/quality/thresholds/{name}/{version}",
    status_code=status.HTTP_200_OK,
    summary="Update SLA thresholds for a contract",
    description="Update the quality SLA thresholds in a data contract.",
)
async def update_thresholds(
    name: str,
    version: str,
    request: ThresholdsUpdateRequest = Body(...),
    store: ContractStoreClient = Depends(get_contract_store),
) -> dict[str, Any]:
    """Update quality SLA thresholds in a data contract."""
    try:
        return svc_update_thresholds(name, version, request.model_dump(), store)
    except ContractMetadataNotFoundError as exc:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND, detail=str(exc)
        ) from exc
    except ContractStoreError as exc:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(exc)
        ) from exc
