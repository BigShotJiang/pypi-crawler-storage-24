"""Route handlers for settings and configuration testing."""

from __future__ import annotations

from typing import Any

from fastapi import APIRouter, Body, Depends, HTTPException, status
from pydantic import BaseModel, Field
from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy.orm import Session

from pycharter.api.dependencies.database import get_db_session
from pycharter.api.services.settings_service import (
    ConnectionBuildError,
    build_connection_string,
    get_app_config,
    get_database_config,
    get_dlq_stats,
    get_notification_config,
    get_quality_config,
    send_test_notification,
    test_database_connection,
    test_dlq_connection,
    update_notification_config,
    update_quality_config,
)

# Public router: no auth (so UI can load theme before login)
public_router = APIRouter(tags=["Settings"])


# ---------------------------------------------------------------------------
# Response / request models
# ---------------------------------------------------------------------------


class AppConfigResponse(BaseModel):
    """App config for UI (theme, app name, release version)."""

    theme: str
    app_name: str
    version: str = ""


class DatabaseConfigResponse(BaseModel):
    """Response model for database configuration info."""

    configured_url: str | None
    actual_url: str
    database_type: str
    is_default: bool
    contract_count: int
    message: str


class DatabaseTestRequest(BaseModel):
    """Request model for database connection testing."""

    connection_string: str | None = None
    host: str | None = None
    port: int | None = None
    database: str | None = None
    username: str | None = None
    password: str | None = None


class DatabaseTestResponse(BaseModel):
    """Response model for database connection test result."""

    success: bool
    message: str


class DlqTestRequest(BaseModel):
    """Request model for DLQ connection testing."""

    connection_string: str | None = None
    host: str | None = None
    port: int | None = None
    database: str | None = None
    username: str | None = None
    password: str | None = None
    table_name: str | None = None


class DlqTestResponse(BaseModel):
    """Response model for DLQ connection test result."""

    success: bool
    message: str


class DlqStatsRequest(BaseModel):
    """Request model for DLQ statistics."""

    connection_string: str | None = None
    host: str | None = None
    port: int | None = None
    database: str | None = None
    username: str | None = None
    password: str | None = None
    table_name: str | None = None


class DlqStatsResponse(BaseModel):
    """Response model for DLQ statistics."""

    total_messages: int
    by_reason: dict[str, int | None] = Field(default_factory=dict)
    by_stage: dict[str, int | None] = Field(default_factory=dict)
    by_status: dict[str, int | None] = Field(default_factory=dict)


class QualityConfigResponse(BaseModel):
    """Quality monitoring configuration."""

    default_check_preset: str = "basic"
    metric_retention_days: int = 90
    scoring_weights: dict[str, float] = Field(default_factory=dict)
    data_sources: list[dict[str, Any]] = Field(default_factory=list)


class NotificationConfigResponse(BaseModel):
    """Notification settings."""

    enabled: bool = False
    channels: dict[str, Any] = Field(default_factory=dict)
    alert_rules: dict[str, bool] = Field(default_factory=dict)
    frequency: str = "immediate"


# ---------------------------------------------------------------------------
# Public (no auth) routes
# ---------------------------------------------------------------------------


@public_router.get(
    "/settings/app-config",
    response_model=AppConfigResponse,
    status_code=status.HTTP_200_OK,
    summary="Get app config (theme, app name, version) for UI",
    description="Returns UI theme (light, dark, system), app name, and release version. No auth required.",
)
async def get_app_config_route() -> AppConfigResponse:
    """Return application configuration for the UI."""
    cfg = get_app_config()
    return AppConfigResponse(
        theme=cfg.theme, app_name=cfg.app_name, version=cfg.version
    )


# ---------------------------------------------------------------------------
# Protected routes
# ---------------------------------------------------------------------------

router = APIRouter(tags=["Settings"])


@router.get(
    "/settings/database-config",
    response_model=DatabaseConfigResponse,
    status_code=status.HTTP_200_OK,
    summary="Get current database configuration",
    description="Get information about the currently configured database connection",
)
async def get_database_config_route(
    db: Session = Depends(get_db_session),
) -> DatabaseConfigResponse:
    """Return current database configuration and connection info."""
    cfg = get_database_config(db)
    return DatabaseConfigResponse(
        configured_url=cfg.configured_url,
        actual_url=cfg.actual_url,
        database_type=cfg.database_type,
        is_default=cfg.is_default,
        contract_count=cfg.contract_count,
        message=cfg.message,
    )


@router.post(
    "/settings/test-database",
    response_model=DatabaseTestResponse,
    status_code=status.HTTP_200_OK,
    summary="Test database connection",
    description="Test a database connection using provided credentials",
)
async def test_database(request: DatabaseTestRequest) -> DatabaseTestResponse:
    """Test a database connection."""
    try:
        conn_str = build_connection_string(
            connection_string=request.connection_string,
            host=request.host,
            port=request.port,
            database=request.database,
            username=request.username,
            password=request.password,
        )
    except ConnectionBuildError as exc:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST, detail=str(exc)
        ) from exc

    result = test_database_connection(conn_str)
    return DatabaseTestResponse(success=result.success, message=result.message)


@router.post(
    "/settings/test-dlq",
    response_model=DlqTestResponse,
    status_code=status.HTTP_200_OK,
    summary="Test DLQ connection",
    description="Test a DLQ (Dead Letter Queue) database connection and verify table exists",
)
async def test_dlq(request: DlqTestRequest) -> DlqTestResponse:
    """Test DLQ connection and table existence."""
    try:
        conn_str = build_connection_string(
            connection_string=request.connection_string,
            host=request.host,
            port=request.port,
            database=request.database,
            username=request.username,
            password=request.password,
        )
    except ConnectionBuildError as exc:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST, detail=str(exc)
        ) from exc

    if not request.table_name:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="table_name is required",
        )

    result = test_dlq_connection(conn_str, request.table_name)
    return DlqTestResponse(success=result.success, message=result.message)


@router.post(
    "/settings/dlq-stats",
    response_model=DlqStatsResponse,
    status_code=status.HTTP_200_OK,
    summary="Get DLQ statistics",
    description="Get statistics from the DLQ table grouped by reason, stage, and status",
)
async def get_dlq_stats_route(request: DlqStatsRequest) -> DlqStatsResponse:
    """Get DLQ statistics."""
    try:
        conn_str = build_connection_string(
            connection_string=request.connection_string,
            host=request.host,
            port=request.port,
            database=request.database,
            username=request.username,
            password=request.password,
        )
    except ConnectionBuildError as exc:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST, detail=str(exc)
        ) from exc

    if not request.table_name:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="table_name is required",
        )

    try:
        stats = get_dlq_stats(conn_str, request.table_name)
    except SQLAlchemyError as exc:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Database error: {exc}",
        ) from exc
    except Exception as exc:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Unexpected error: {exc}",
        ) from exc

    return DlqStatsResponse(
        total_messages=stats.total_messages,
        by_reason=stats.by_reason,
        by_stage=stats.by_stage,
        by_status=stats.by_status,
    )


# ---------------------------------------------------------------------------
# Quality configuration
# ---------------------------------------------------------------------------


@router.get(
    "/settings/quality",
    status_code=status.HTTP_200_OK,
    summary="Get quality monitoring configuration",
    description="Retrieve quality monitoring defaults and scoring configuration.",
)
async def get_quality_config_route() -> dict[str, Any]:
    """Get quality monitoring configuration."""
    return get_quality_config()


@router.put(
    "/settings/quality",
    status_code=status.HTTP_200_OK,
    summary="Update quality monitoring configuration",
    description="Update quality monitoring defaults and scoring configuration.",
)
async def update_quality_config_route(
    config: dict[str, Any] = Body(...),
) -> dict[str, Any]:
    """Update quality monitoring configuration."""
    return update_quality_config(config)


# ---------------------------------------------------------------------------
# Notification configuration
# ---------------------------------------------------------------------------


@router.get(
    "/settings/notifications",
    status_code=status.HTTP_200_OK,
    summary="Get notification settings",
    description="Retrieve notification and alerting configuration.",
)
async def get_notification_config_route() -> dict[str, Any]:
    """Get notification settings."""
    return get_notification_config()


@router.put(
    "/settings/notifications",
    status_code=status.HTTP_200_OK,
    summary="Update notification settings",
    description="Update notification and alerting configuration.",
)
async def update_notification_config_route(
    config: dict[str, Any] = Body(...),
) -> dict[str, Any]:
    """Update notification settings."""
    return update_notification_config(config)


@router.post(
    "/settings/notifications/test",
    status_code=status.HTTP_200_OK,
    summary="Send a test notification",
    description="Send a test notification using the current notification settings.",
)
async def test_notification(
    channel: str = Body("email", embed=True),
) -> dict[str, Any]:
    """Send a test notification."""
    return send_test_notification(channel)
