"""Route handlers for ontology configuration management.

CRUD endpoints for storing, listing, retrieving, and managing versioned
ontology configurations backed by LinkML YAML.
"""

from __future__ import annotations

import logging

from fastapi import APIRouter, Depends, HTTPException, status

from pycharter.api.dependencies.semantic_store import get_semantic_store
from pycharter.api.models.ontology_configs import (
    OntologyConfigListResponse,
    OntologyConfigResponse,
    OntologyConfigStatusUpdateRequest,
    OntologyConfigStoreFromEditorRequest,
    OntologyConfigStoreRequest,
    OntologyConfigStoreResponse,
    OntologyConfigSummary,
    OntologyConfigVersionsResponse,
)
from pycharter.semantic.linkml._serializer import editor_json_to_linkml_yaml
from pycharter.semantic_store.client import SemanticStoreClient

logger = logging.getLogger(__name__)

router = APIRouter(tags=["Ontology Configs"])


# ---------------------------------------------------------------------------
# Store (raw YAML)
# ---------------------------------------------------------------------------


@router.post(
    "/ontology/configs",
    response_model=OntologyConfigStoreResponse,
    status_code=status.HTTP_201_CREATED,
    summary="Store ontology configuration",
    description=(
        "Store a new versioned ontology configuration from raw "
        "LinkML YAML. The (ontology_name, ontology_version) pair "
        "must be unique."
    ),
)
async def store_ontology_config(
    request: OntologyConfigStoreRequest,
    store: SemanticStoreClient = Depends(get_semantic_store),
) -> OntologyConfigStoreResponse:
    """Store a new ontology configuration."""
    try:
        config_id = store.store_config(
            ontology_name=request.ontology_name,
            ontology_version=request.ontology_version,
            linkml_yaml=request.linkml_yaml,
            description=request.description,
            scheme_key=request.scheme_key,
            created_by=request.created_by,
        )
    except ValueError as exc:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=str(exc),
        ) from exc

    return OntologyConfigStoreResponse(
        id=config_id,
        ontology_name=request.ontology_name,
        ontology_version=request.ontology_version,
    )


# ---------------------------------------------------------------------------
# Store (from editor JSON)
# ---------------------------------------------------------------------------


@router.post(
    "/ontology/configs/from-editor",
    response_model=OntologyConfigStoreResponse,
    status_code=status.HTTP_201_CREATED,
    summary="Store ontology from editor JSON",
    description=(
        "Accept unified editor ontology JSON, convert to LinkML "
        "YAML, and store as a versioned artifact."
    ),
)
async def store_ontology_from_editor(
    request: OntologyConfigStoreFromEditorRequest,
    store: SemanticStoreClient = Depends(get_semantic_store),
) -> OntologyConfigStoreResponse:
    """Convert editor JSON to LinkML YAML and store."""
    try:
        linkml_yaml = editor_json_to_linkml_yaml(
            request.editor_json,
            ontology_name=request.ontology_name,
            ontology_version=request.ontology_version,
        )
    except Exception as exc:
        logger.exception("Failed to convert editor JSON to LinkML")
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Editor JSON conversion failed: {exc!s}",
        ) from exc

    try:
        config_id = store.store_config(
            ontology_name=request.ontology_name,
            ontology_version=request.ontology_version,
            linkml_yaml=linkml_yaml,
            description=request.description,
            scheme_key=request.scheme_key,
            created_by=request.created_by,
        )
    except ValueError as exc:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=str(exc),
        ) from exc

    return OntologyConfigStoreResponse(
        id=config_id,
        ontology_name=request.ontology_name,
        ontology_version=request.ontology_version,
    )


# ---------------------------------------------------------------------------
# List
# ---------------------------------------------------------------------------


@router.get(
    "/ontology/configs",
    response_model=OntologyConfigListResponse,
    summary="List ontology configurations",
    description=(
        "List stored ontology configurations. Optionally filter "
        "by ontology_name query parameter."
    ),
)
async def list_ontology_configs(
    ontology_name: str | None = None,
    store: SemanticStoreClient = Depends(get_semantic_store),
) -> OntologyConfigListResponse:
    """List stored ontology configurations."""
    configs = store.list_configs(ontology_name=ontology_name)
    return OntologyConfigListResponse(
        configs=[OntologyConfigSummary(**c) for c in configs],
        total=len(configs),
    )


# ---------------------------------------------------------------------------
# Get
# ---------------------------------------------------------------------------


@router.get(
    "/ontology/configs/{ontology_name}/{ontology_version}",
    response_model=OntologyConfigResponse,
    summary="Get ontology configuration",
    description=("Retrieve the full ontology configuration by name and version."),
)
async def get_ontology_config(
    ontology_name: str,
    ontology_version: str,
    store: SemanticStoreClient = Depends(get_semantic_store),
) -> OntologyConfigResponse:
    """Get a full ontology configuration."""
    config = store.get_config(ontology_name, ontology_version)
    if config is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=(
                f"Ontology config not found: {ontology_name!r} @ {ontology_version!r}"
            ),
        )
    return OntologyConfigResponse(**config)


# ---------------------------------------------------------------------------
# List versions
# ---------------------------------------------------------------------------


@router.get(
    "/ontology/configs/{ontology_name}/versions",
    response_model=OntologyConfigVersionsResponse,
    summary="List ontology versions",
    description="List all stored versions for a given ontology.",
)
async def list_ontology_config_versions(
    ontology_name: str,
    store: SemanticStoreClient = Depends(get_semantic_store),
) -> OntologyConfigVersionsResponse:
    """List all versions for an ontology."""
    versions = store.list_versions(ontology_name)
    return OntologyConfigVersionsResponse(
        ontology_name=ontology_name,
        versions=versions,
    )


# ---------------------------------------------------------------------------
# Update status
# ---------------------------------------------------------------------------


@router.patch(
    "/ontology/configs/{ontology_name}/{ontology_version}/status",
    status_code=status.HTTP_204_NO_CONTENT,
    summary="Update ontology config status",
    description=(
        "Update the lifecycle status of a stored config. "
        "Valid statuses: active, deprecated, draft."
    ),
)
async def update_ontology_config_status(
    ontology_name: str,
    ontology_version: str,
    request: OntologyConfigStatusUpdateRequest,
    store: SemanticStoreClient = Depends(get_semantic_store),
) -> None:
    """Update config status."""
    try:
        store.update_status(
            ontology_name,
            ontology_version,
            request.status.value,
            updated_by=request.updated_by,
        )
    except ValueError as exc:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(exc),
        ) from exc


# ---------------------------------------------------------------------------
# Delete
# ---------------------------------------------------------------------------


@router.delete(
    "/ontology/configs/{ontology_name}/{ontology_version}",
    status_code=status.HTTP_204_NO_CONTENT,
    summary="Delete ontology configuration",
    description=("Delete a stored ontology configuration by name and version."),
)
async def delete_ontology_config(
    ontology_name: str,
    ontology_version: str,
    store: SemanticStoreClient = Depends(get_semantic_store),
) -> None:
    """Delete a stored ontology configuration."""
    deleted = store.delete_config(ontology_name, ontology_version)
    if not deleted:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=(
                f"Ontology config not found: {ontology_name!r} @ {ontology_version!r}"
            ),
        )
