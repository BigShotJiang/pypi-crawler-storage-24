"""Discovery API routes."""

from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException, Query

from pycharter.api.dependencies import get_db_session
from pycharter.semantic.knowledge.discovery import DiscoveryEngine
from pycharter.semantic.shared.errors import GraphError

router = APIRouter(tags=["Semantic"])


@router.get("/suggest")
async def suggest_concept(
    field_name: str = Query(..., description="Field name to get suggestions for"),
    session=Depends(get_db_session),
):
    """Suggest concepts for a field based on its name."""
    try:
        engine = DiscoveryEngine(session)
        return engine.suggest_concept(field_name)
    except GraphError as e:
        raise HTTPException(status_code=400, detail=str(e)) from e


@router.get("/synonyms")
async def find_synonyms(
    concept_name: str = Query(..., description="Concept name to find synonyms for"),
    session=Depends(get_db_session),
):
    """Find fields that may be synonyms for a concept."""
    try:
        engine = DiscoveryEngine(session)
        return engine.find_synonyms(concept_name)
    except GraphError as e:
        raise HTTPException(status_code=400, detail=str(e)) from e


@router.get("/cross-contract")
async def find_cross_contract_mappings(
    concept_name: str = Query(..., description="Concept name to search for"),
    session=Depends(get_db_session),
):
    """Find fields across contracts that share the same concept."""
    try:
        engine = DiscoveryEngine(session)
        return engine.find_cross_contract_mappings(concept_name)
    except GraphError as e:
        raise HTTPException(status_code=400, detail=str(e)) from e
