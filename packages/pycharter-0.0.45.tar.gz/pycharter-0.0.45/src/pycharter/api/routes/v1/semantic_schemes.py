"""Concept scheme (multi-ontology) CRUD API routes."""

from __future__ import annotations

import logging
from typing import Any

from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel, Field
from sqlalchemy.exc import ProgrammingError

from pycharter.api.dependencies import get_db_session

router = APIRouter(tags=["Semantic - Schemes"])
logger = logging.getLogger(__name__)


# ── Request / response models ────────────────────────────────────────────────


class CreateSchemeRequest(BaseModel):
    """Request body for creating a concept scheme."""

    scheme_key: str = Field(
        ..., description="Unique slug identifier (e.g. 'risk-domain')"
    )
    title: str = Field(..., description="Human-readable scheme title")
    version: str = Field(default="0.0.0", description="Semantic version string")
    description: str | None = Field(default=None, description="Scheme description")
    base_uri: str | None = Field(default=None, description="Base URI for RDF export")


class UpdateSchemeRequest(BaseModel):
    """Request body for updating a concept scheme."""

    title: str | None = Field(default=None, description="Updated title")
    version: str | None = Field(default=None, description="Updated version")
    description: str | None = Field(default=None, description="Updated description")
    base_uri: str | None = Field(default=None, description="Updated base URI")


# ── Helpers ───────────────────────────────────────────────────────────────────


def _row_to_dict(row: Any) -> dict[str, Any]:
    """Convert a ConceptSchemeModel row to a response dict."""
    return {
        "id": str(row.id),
        "scheme_key": row.scheme_key,
        "title": row.title,
        "version": row.version,
        "description": row.description,
        "base_uri": row.base_uri,
        "created_at": row.created_at.isoformat() if row.created_at else None,
        "updated_at": row.updated_at.isoformat() if row.updated_at else None,
        "created_by": row.created_by,
    }


# ── Routes ────────────────────────────────────────────────────────────────────


@router.get("/schemes")
async def list_schemes(session=Depends(get_db_session)):
    """List all concept schemes."""
    from pycharter.db.models.semantic.concept_scheme import ConceptSchemeModel

    try:
        rows = (
            session.query(ConceptSchemeModel).order_by(ConceptSchemeModel.title).all()
        )
        return [_row_to_dict(r) for r in rows]
    except ProgrammingError as e:
        if "concept_schemes" in str(e) and (
            "does not exist" in str(e) or "UndefinedTable" in str(e)
        ):
            logger.warning(
                "concept_schemes table missing. Run migrations: pycharter db upgrade. Error: %s",
                e,
            )
            return []
        raise


@router.get("/schemes/{scheme_id}")
async def get_scheme(scheme_id: str, session=Depends(get_db_session)):
    """Get a concept scheme by ID or scheme_key."""
    from pycharter.db.models.semantic.concept_scheme import ConceptSchemeModel

    row = (
        session.query(ConceptSchemeModel)
        .filter(
            (ConceptSchemeModel.id == scheme_id)
            | (ConceptSchemeModel.scheme_key == scheme_id)
        )
        .first()
    )
    if row is None:
        raise HTTPException(status_code=404, detail=f"Scheme not found: {scheme_id}")

    # Include concept count
    from pycharter.db.models.semantic.concept import ConceptModel

    concept_count = (
        session.query(ConceptModel).filter(ConceptModel.scheme_id == row.id).count()
    )
    result = _row_to_dict(row)
    result["concept_count"] = concept_count
    return result


@router.post("/schemes", status_code=201)
async def create_scheme(
    request: CreateSchemeRequest,
    author: str = Query("api"),
    session=Depends(get_db_session),
):
    """Create a new concept scheme."""
    from pycharter.db.models.semantic.concept_scheme import ConceptSchemeModel

    existing = (
        session.query(ConceptSchemeModel)
        .filter(ConceptSchemeModel.scheme_key == request.scheme_key)
        .first()
    )
    if existing:
        raise HTTPException(
            status_code=409,
            detail=f"Scheme key already exists: {request.scheme_key}",
        )

    row = ConceptSchemeModel(
        scheme_key=request.scheme_key,
        title=request.title,
        version=request.version,
        description=request.description,
        base_uri=request.base_uri,
        created_by=author,
    )
    session.add(row)
    session.flush()
    return _row_to_dict(row)


@router.put("/schemes/{scheme_id}")
async def update_scheme(
    scheme_id: str,
    request: UpdateSchemeRequest,
    author: str = Query("api"),
    session=Depends(get_db_session),
):
    """Update an existing concept scheme."""
    from pycharter.db.models.semantic.concept_scheme import ConceptSchemeModel

    row = (
        session.query(ConceptSchemeModel)
        .filter(
            (ConceptSchemeModel.id == scheme_id)
            | (ConceptSchemeModel.scheme_key == scheme_id)
        )
        .first()
    )
    if row is None:
        raise HTTPException(status_code=404, detail=f"Scheme not found: {scheme_id}")

    if request.title is not None:
        row.title = request.title
    if request.version is not None:
        row.version = request.version
    if request.description is not None:
        row.description = request.description
    if request.base_uri is not None:
        row.base_uri = request.base_uri
    row.updated_by = author

    session.flush()
    return _row_to_dict(row)
