"""Route handlers for contract parsing and building."""

from __future__ import annotations

import logging
from pathlib import Path

from fastapi import (
    APIRouter,
    Depends,
    File,
    Form,
    HTTPException,
    Query,
    UploadFile,
    status,
)
from sqlalchemy.orm import Session

from pycharter import build_contract_from_store
from pycharter.api.dependencies.database import get_db_session
from pycharter.api.dependencies.store import get_contract_store
from pycharter.api.models.contracts import (
    ContractBuildRequest,
    ContractBuildResponse,
    ContractCreateFromArtifactsRequest,
    ContractCreateMixedRequest,
    ContractListItem,
    ContractListResponse,
    ContractParseRequest,
    ContractParseResponse,
    ContractUpdateRequest,
    ContractVersionItem,
    ContractVersionListResponse,
)
from pycharter.api.services import contract_service
from pycharter.api.services.contract_parse_service import (
    contract_to_list_item,
    delete_contract_by_id,
    get_contract_by_id,
    list_all_contracts,
    list_versions_by_name,
    parse_contract_dict,
    parse_contract_from_upload,
    unwrap_contract_data,
)
from pycharter.api.services.contract_service import (
    ArtifactNotFoundError,
    ContractBuildError,
    ContractConflictError,
    ContractNotFoundError,
)
from pycharter.contract_store import ContractStoreClient

logger = logging.getLogger(__name__)
router = APIRouter(tags=["Contracts"])


def _to_item(data: dict) -> ContractListItem:
    """Convert a service-layer dict to a ContractListItem response model."""
    return ContractListItem(**data)


@router.post(
    "/contracts/parse",
    response_model=ContractParseResponse,
    status_code=status.HTTP_200_OK,
    summary="Parse a data contract",
    description="Parse a data contract dictionary into its component parts.",
    tags=["Contracts"],
)
async def parse_contract_endpoint(
    request: ContractParseRequest,
) -> ContractParseResponse:
    """Parse a data contract into its components."""
    try:
        contract_data = unwrap_contract_data(request.contract)
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST, detail=str(e)
        ) from e

    try:
        result = parse_contract_dict(contract_data)
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST, detail=str(e)
        ) from e

    return ContractParseResponse(**result)


@router.post(
    "/contracts/parse/upload",
    response_model=ContractParseResponse,
    status_code=status.HTTP_200_OK,
    summary="Parse a data contract from file upload",
    description="Parse a data contract file (YAML or JSON) uploaded via multipart/form-data.",
    tags=["Contracts"],
)
async def parse_contract_file_endpoint(
    file: UploadFile = File(..., description="Contract file (YAML or JSON)"),
    should_validate: bool = Form(
        True,
        alias="validate",
        description="Validate contract against schema before parsing",
    ),
) -> ContractParseResponse:
    """Parse a data contract from an uploaded file."""
    file_extension = Path(file.filename).suffix.lower()
    content = await file.read()

    try:
        result = parse_contract_from_upload(
            content, file_extension, validate=should_validate
        )
    except (ValueError, FileNotFoundError) as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST, detail=str(e)
        ) from e
    except Exception as e:
        logger.error("Error parsing contract file: %s", e, exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to parse contract file: {e}",
        ) from e

    return ContractParseResponse(**result)


@router.post(
    "/contracts/{contract_id}/build",
    response_model=ContractBuildResponse,
    status_code=status.HTTP_200_OK,
    summary="Build a contract from contract ID",
    description="Reconstruct a complete data contract by fetching its linked artifacts.",
    tags=["Contracts"],
)
async def build_contract_from_id_endpoint(
    contract_id: str,
    include_metadata: bool = Query(True, description="Include metadata"),
    include_ownership: bool = Query(True, description="Include ownership"),
    include_governance: bool = Query(True, description="Include governance rules"),
    store: ContractStoreClient = Depends(get_contract_store),
    db: Session = Depends(get_db_session),
) -> ContractBuildResponse:
    """Build a contract from contract ID."""
    try:
        contract_dict = contract_service.build_contract_from_db(
            contract_id=contract_id,
            store=store,
            db=db,
            include_metadata=include_metadata,
            include_ownership=include_ownership,
            include_governance=include_governance,
        )
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST, detail=str(e)
        ) from e
    except (ContractNotFoundError, ArtifactNotFoundError) as e:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e)) from e
    except ContractBuildError as e:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail=str(e)
        ) from e

    return ContractBuildResponse(contract=contract_dict.to_dict())


@router.post(
    "/contracts/build",
    response_model=ContractBuildResponse,
    status_code=status.HTTP_200_OK,
    summary="Build a contract from contract store",
    description="Reconstruct a complete data contract from components in the store.",
    tags=["Contracts"],
)
async def build_contract_endpoint(
    request: ContractBuildRequest,
    store: ContractStoreClient = Depends(get_contract_store),
) -> ContractBuildResponse:
    """Build a contract from contract store."""
    contract = build_contract_from_store(
        store=store,
        contract_name=request.contract_name,
        contract_version=request.contract_version,
        include_metadata=request.include_metadata,
        include_ownership=request.include_ownership,
        include_governance=request.include_governance,
    )

    if not contract:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=(
                f"Contract not found: {request.contract_name!r} "
                f"@ {request.contract_version!r}"
            ),
        )

    return ContractBuildResponse(contract=contract.to_dict())


@router.post(
    "/contracts/create-from-artifacts",
    response_model=ContractListItem,
    status_code=status.HTTP_201_CREATED,
    summary="Create a data contract from existing artifacts",
    description="Create a new data contract by linking to existing artifacts.",
    tags=["Contracts"],
)
async def create_contract_from_artifacts(
    request: ContractCreateFromArtifactsRequest,
    db: Session = Depends(get_db_session),
) -> ContractListItem:
    """Create a new data contract from existing artifacts."""
    try:
        new_contract = contract_service.create_from_existing_artifacts(request, db)
    except ContractConflictError as e:
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail=str(e)) from e
    except ArtifactNotFoundError as e:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e)) from e
    except RuntimeError as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(e)
        ) from e

    return _to_item(contract_to_list_item(new_contract))


@router.post(
    "/contracts/create-mixed",
    response_model=ContractListItem,
    status_code=status.HTTP_201_CREATED,
    summary="Create a data contract with mixed artifacts",
    description="Create a new data contract with a mix of new and existing artifacts.",
    tags=["Contracts"],
)
async def create_contract_mixed(
    request: ContractCreateMixedRequest,
    store: ContractStoreClient = Depends(get_contract_store),
    db: Session = Depends(get_db_session),
) -> ContractListItem:
    """Create a new data contract with mixed artifacts."""
    try:
        new_contract = contract_service.create_mixed(request, store, db)
    except ContractConflictError as e:
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail=str(e)) from e
    except ArtifactNotFoundError as e:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e)) from e
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST, detail=str(e)
        ) from e
    except RuntimeError as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(e)
        ) from e

    return _to_item(contract_to_list_item(new_contract))


@router.get(
    "/contracts",
    response_model=ContractListResponse,
    status_code=status.HTTP_200_OK,
    summary="List data contracts",
    description="Get a list of all data contracts stored in the database.",
    tags=["Contracts"],
)
async def list_contracts(
    db: Session = Depends(get_db_session),
) -> ContractListResponse:
    """List all data contracts from the database."""
    try:
        items = list_all_contracts(db)
    except Exception as e:
        logger.error("Error listing contracts: %s", e, exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to list contracts: {e}",
        ) from e

    return ContractListResponse(
        contracts=[ContractListItem(**item) for item in items],
        total=len(items),
    )


@router.get(
    "/contracts/{contract_id}",
    response_model=ContractListItem,
    status_code=status.HTTP_200_OK,
    summary="Get data contract by ID",
    description="Retrieve a specific data contract from the database by its ID.",
    tags=["Contracts"],
)
async def get_contract(
    contract_id: str,
    db: Session = Depends(get_db_session),
) -> ContractListItem:
    """Get a specific data contract by ID."""
    try:
        contract = get_contract_by_id(db, contract_id)
    except ValueError:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Invalid contract ID format: {contract_id}",
        ) from None

    return _to_item(contract_to_list_item(contract))


@router.put(
    "/contracts/{contract_id}",
    response_model=ContractListItem,
    status_code=status.HTTP_200_OK,
    summary="Update data contract",
    description="Update contract metadata (name, version, status, description).",
    tags=["Contracts"],
)
async def update_contract(
    contract_id: str,
    request: ContractUpdateRequest,
    db: Session = Depends(get_db_session),
) -> ContractListItem:
    """Update a data contract's metadata."""
    try:
        updated = contract_service.update_fields(contract_id, request, db)
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST, detail=str(e)
        ) from e
    except (ContractNotFoundError, ArtifactNotFoundError) as e:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e)) from e
    except ContractConflictError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST, detail=str(e)
        ) from e
    except RuntimeError as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(e)
        ) from e

    return _to_item(contract_to_list_item(updated))


@router.delete(
    "/contracts/{contract_id}",
    status_code=status.HTTP_204_NO_CONTENT,
    summary="Delete data contract",
    description="Delete a data contract by ID.",
    tags=["Contracts"],
)
async def delete_contract(
    contract_id: str,
    db: Session = Depends(get_db_session),
) -> None:
    """Delete a data contract by ID."""
    try:
        delete_contract_by_id(db, contract_id)
    except ValueError:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Invalid contract ID format: {contract_id}",
        ) from None
    except RuntimeError as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(e)
        ) from e


@router.get(
    "/contracts/versions/{contract_name}",
    response_model=ContractVersionListResponse,
    status_code=status.HTTP_200_OK,
    summary="List versions of a contract",
    description="Get all versions of a data contract by name.",
    tags=["Contracts"],
)
async def list_contract_versions(
    contract_name: str,
    db: Session = Depends(get_db_session),
) -> ContractVersionListResponse:
    """List all versions of a contract by name."""
    try:
        versions = list_versions_by_name(db, contract_name)
    except Exception as e:
        logger.error("Error listing versions for %s: %s", contract_name, e)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to list contract versions: {e}",
        ) from e

    return ContractVersionListResponse(
        name=contract_name,
        versions=[ContractVersionItem(**v) for v in versions],
        total=len(versions),
    )
