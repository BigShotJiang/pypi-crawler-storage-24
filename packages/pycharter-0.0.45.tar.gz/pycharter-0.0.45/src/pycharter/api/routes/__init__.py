"""
API route handlers.

This module contains all FastAPI route handlers organized by service.
"""

from __future__ import annotations
