"""Request/response models for the editor folder endpoints."""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel, Field


class FolderCreate(BaseModel):
    """Create a new folder."""

    name: str = Field(..., min_length=1, max_length=255, description="Folder name")
    parent_id: str | None = Field(None, description="Parent folder ID (null for root)")
    folder_type: str = Field(
        ..., min_length=1, max_length=50, description="Root type discriminator"
    )


class FolderUpdate(BaseModel):
    """Rename, move, or reorder a folder."""

    name: str | None = Field(None, min_length=1, max_length=255)
    parent_id: str | None = Field(None, description="New parent (null for root)")
    position: int | None = Field(None, ge=0)


class FolderResponse(BaseModel):
    """A single folder."""

    id: str
    name: str
    parent_id: str | None
    folder_type: str
    position: int
    created_at: str | None = None
    updated_at: str | None = None


class FolderItemInput(BaseModel):
    """A single item to assign into a folder."""

    item_id: str = Field(..., description="External item identifier")
    item_type: str = Field(..., description="Item type discriminator")
    item_label: str = Field("", description="Cached display name")
    item_meta: dict[str, Any] | None = Field(None, description="Optional metadata")


class FolderItemAssignRequest(BaseModel):
    """Assign one or more items into a folder."""

    items: list[FolderItemInput] = Field(
        ..., min_length=1, description="Items to assign"
    )


class FolderItemRemoveRequest(BaseModel):
    """Remove specific items from a folder."""

    item_ids: list[str] = Field(
        ..., min_length=1, description="External item IDs to remove"
    )


class FolderTreeNode(BaseModel):
    """Recursive tree node for the full-tree response."""

    id: str
    name: str
    kind: str = Field(description="'folder' or 'item'")
    folder_type: str
    children: list[FolderTreeNode] | None = None
    # Present for item nodes only
    item_id: str | None = None
    item_label: str | None = None
    item_meta: dict[str, Any] | None = None


class FolderTreeResponse(BaseModel):
    """Full folder tree for a given type."""

    folder_type: str
    roots: list[FolderTreeNode]


class FolderEnsurePathRequest(BaseModel):
    """Ensure a slash-separated folder path exists, creating missing segments."""

    path: str = Field(
        ...,
        min_length=1,
        max_length=1024,
        description="Slash-separated folder path (e.g. 'finance/reports')",
    )
    folder_type: str = Field(
        ...,
        min_length=1,
        max_length=50,
        description="Root type discriminator (e.g. 'schema', 'ontology')",
    )


class FolderEnsurePathResponse(BaseModel):
    """Result of ensuring a folder path exists."""

    folder_id: str = Field(..., description="ID of the leaf folder")
    path: str = Field(..., description="The normalised path that was ensured")
    created: list[str] = Field(
        default_factory=list,
        description="Names of folders that were newly created",
    )
