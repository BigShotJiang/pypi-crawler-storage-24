"""
Request/Response models for metadata entity endpoints (owners, domains, systems, etc.).
"""

from __future__ import annotations

from typing import Any
from uuid import UUID

from pydantic import BaseModel, Field


# Owner Models
class OwnerCreateRequest(BaseModel):
    """Request model for creating an owner."""

    id: str = Field(..., description="Owner identifier")
    name: str | None = Field(None, description="Display name")
    email: str | None = Field(None, description="Email address")
    team: str | None = Field(None, description="Team name")
    additional_info: dict[str, Any] | None = Field(
        None, description="Additional metadata"
    )


class OwnerUpdateRequest(BaseModel):
    """Request model for updating an owner."""

    name: str | None = Field(None, description="Display name")
    email: str | None = Field(None, description="Email address")
    team: str | None = Field(None, description="Team name")
    additional_info: dict[str, Any] | None = Field(
        None, description="Additional metadata"
    )


# Domain Models
class DomainCreateRequest(BaseModel):
    """Request model for creating a domain."""

    name: str = Field(..., description="Domain name")
    description: str | None = Field(None, description="Domain description")


class DomainUpdateRequest(BaseModel):
    """Request model for updating a domain."""

    name: str | None = Field(None, description="Domain name")
    description: str | None = Field(None, description="Domain description")


# System Models
class SystemCreateRequest(BaseModel):
    """Request model for creating a system."""

    name: str = Field(..., description="System name")
    app_id: str | None = Field(None, description="Application ID")
    description: str | None = Field(None, description="System description")


class SystemUpdateRequest(BaseModel):
    """Request model for updating a system."""

    name: str | None = Field(None, description="System name")
    app_id: str | None = Field(None, description="Application ID")
    description: str | None = Field(None, description="System description")


# Environment Models
class EnvironmentCreateRequest(BaseModel):
    """Request model for creating an environment."""

    name: str = Field(..., description="Environment name")
    description: str | None = Field(None, description="Environment description")
    environment_type: str | None = Field(None, description="Environment type")
    is_production: bool = Field(False, description="Is production environment")
    additional_metadata: dict[str, Any] | None = Field(
        None, description="Additional metadata"
    )


class EnvironmentUpdateRequest(BaseModel):
    """Request model for updating an environment."""

    name: str | None = Field(None, description="Environment name")
    description: str | None = Field(None, description="Environment description")
    environment_type: str | None = Field(None, description="Environment type")
    is_production: bool | None = Field(None, description="Is production environment")
    additional_metadata: dict[str, Any] | None = Field(
        None, description="Additional metadata"
    )


# Storage Location Models
class StorageLocationCreateRequest(BaseModel):
    """Request model for creating a storage location."""

    name: str = Field(..., description="Storage location name")
    location_type: str | None = Field(None, description="Location type")
    cluster: str | None = Field(None, description="Cluster name")
    database: str | None = Field(None, description="Database name")
    collection: str | None = Field(None, description="Collection name (for NoSQL)")
    schema_name: str | None = Field(None, description="Schema name (for SQL)")
    table_name: str | None = Field(None, description="Table name")
    connection_string: str | None = Field(None, description="Connection string")
    system_id: UUID | None = Field(None, description="Related system ID")
    environment_id: UUID | None = Field(None, description="Related environment ID")
    additional_metadata: dict[str, Any] | None = Field(
        None, description="Additional metadata"
    )


class StorageLocationUpdateRequest(BaseModel):
    """Request model for updating a storage location."""

    name: str | None = Field(None, description="Storage location name")
    location_type: str | None = Field(None, description="Location type")
    cluster: str | None = Field(None, description="Cluster name")
    database: str | None = Field(None, description="Database name")
    collection: str | None = Field(None, description="Collection name (for NoSQL)")
    schema_name: str | None = Field(None, description="Schema name (for SQL)")
    table_name: str | None = Field(None, description="Table name")
    connection_string: str | None = Field(None, description="Connection string")
    system_id: UUID | None = Field(None, description="Related system ID")
    environment_id: UUID | None = Field(None, description="Related environment ID")
    additional_metadata: dict[str, Any] | None = Field(
        None, description="Additional metadata"
    )


# Tag Models
class TagCreateRequest(BaseModel):
    """Request model for creating a tag."""

    name: str = Field(..., description="Tag name")
    description: str | None = Field(None, description="Tag description")
    category: str | None = Field(None, description="Tag category")
    color: str | None = Field(None, description="Hex color code")
    additional_metadata: dict[str, Any] | None = Field(
        None, description="Additional metadata"
    )


class TagUpdateRequest(BaseModel):
    """Request model for updating a tag."""

    name: str | None = Field(None, description="Tag name")
    description: str | None = Field(None, description="Tag description")
    category: str | None = Field(None, description="Tag category")
    color: str | None = Field(None, description="Hex color code")
    additional_metadata: dict[str, Any] | None = Field(
        None, description="Additional metadata"
    )
