"""Models for semantic (ontology) command-center dashboard APIs."""

from __future__ import annotations

from pydantic import BaseModel


class ProposalStatsResponse(BaseModel):
    """Aggregate proposal counters."""

    total: int
    open: int
    merged: int
    closed: int
    core_blocked: int


class SemanticHealthOverviewResponse(BaseModel):
    """High-level semantic health aggregates across sampled contracts."""

    sampled_contracts: int
    average_coverage_pct: float
    below_threshold_count: int


class RecentProposalResponse(BaseModel):
    """Compact proposal entry for command-center activity feed."""

    id: str
    title: str
    status: str
    proposal_type: str
    enforce_gates: bool
    gate_overall: str | None = None
    updated_at: str | None = None


class ProposalTrendPointResponse(BaseModel):
    """Daily proposal trend point for charting."""

    date: str
    created: int
    merged: int
    blocked: int


class SemanticDashboardSummaryResponse(BaseModel):
    """Summary payload for semantic command-center landing page."""

    scope: str
    window_days: int
    selected_domain: str | None = None
    available_domains: list[str]
    concepts_count: int
    relationship_types_count: int
    concept_types_count: int
    proposal_stats: ProposalStatsResponse
    semantic_health: SemanticHealthOverviewResponse
    recent_proposals: list[RecentProposalResponse]
    proposal_trend: list[ProposalTrendPointResponse]
