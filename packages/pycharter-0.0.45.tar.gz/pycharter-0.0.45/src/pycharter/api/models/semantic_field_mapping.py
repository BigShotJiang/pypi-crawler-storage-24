"""Pydantic models for field mapping API endpoints."""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel


class FieldMappingParseRequest(BaseModel):
    """Request to parse field mapping data."""

    data: dict[str, Any] | None


class FieldMappingValidateRequest(BaseModel):
    """Request to validate field mapping data."""

    data: dict[str, Any] | None


class FieldMappingValidateResponse(BaseModel):
    """Response from field mapping validation."""

    valid: bool
    errors: list[dict[str, str]]


class FieldMappingResponse(BaseModel):
    """Parsed field mapping response."""

    version: str
    field_bindings: dict[str, Any] | None


class SemanticHealthResponse(BaseModel):
    """Contract field mapping semantic health summary."""

    contract_id: str
    contract_name: str
    contract_version: str
    total_schema_fields: int
    mapped_schema_fields: int
    coverage_pct: float
    total_bindings: int
    unmapped_schema_fields: list[str]
    unknown_mapping_paths: list[str]
    invalid_concepts: list[str]
    deprecated_concepts_in_use: list[str]
    invalid_relationships: list[dict[str, str]]
    warnings: list[str]
