"""
Dependencies for contract store connections.

This module provides FastAPI dependency injection for contract store instances.
"""

from __future__ import annotations

from functools import lru_cache
from pathlib import Path

from fastapi import HTTPException, status
from pydantic_settings import BaseSettings

from pycharter.config import get_database_url
from pycharter.contract_store import (
    ContractStoreClient,
    InMemoryContractStore,
    MongoDBContractStore,
    PostgresContractStore,
    RedisContractStore,
    SQLiteContractStore,
)


class StoreSettings(BaseSettings):
    """Settings for contract store configuration."""

    model_config = {"env_prefix": "PYCHARTER_API_", "case_sensitive": False}

    store_type: str = "sqlite"  # Options: sqlite, in_memory, postgres, mongodb, redis
    connection_string: str | None = None


@lru_cache
def get_store_settings() -> StoreSettings:
    """Get store settings from environment variables (cached)."""
    return StoreSettings()


# Global store instance (singleton pattern)
_store_instance: ContractStoreClient | None = None


def get_contract_store() -> ContractStoreClient:
    """
    FastAPI dependency to get contract store instance (singleton).

    Auto-detects store type from PYCHARTER_DATABASE_URL or uses configured settings.
    Defaults to SQLite if nothing is configured.
    """
    global _store_instance

    if _store_instance is None:
        settings = get_store_settings()
        store_type = settings.store_type.lower()
        connection_string = settings.connection_string

        # Auto-detect from database URL if available
        db_url = get_database_url()
        if db_url and not connection_string:
            if db_url.startswith(("postgresql://", "postgres://")):
                store_type = "postgres"
                connection_string = db_url
            elif db_url.startswith("sqlite://"):
                store_type = "sqlite"
                connection_string = db_url

        # Create store instance
        if store_type == "sqlite":
            if not connection_string:
                connection_string = f"sqlite:///{Path.cwd() / 'pycharter.db'}"
            _store_instance = SQLiteContractStore(connection_string=connection_string)
        elif store_type == "in_memory":
            _store_instance = InMemoryContractStore()
        elif store_type == "postgres":
            connection_string = connection_string or get_database_url()
            if not connection_string:
                raise ValueError("connection_string required for PostgreSQL store")
            _store_instance = PostgresContractStore(connection_string=connection_string)
        elif store_type == "mongodb":
            if not connection_string:
                raise ValueError("connection_string required for MongoDB store")
            _store_instance = MongoDBContractStore(connection_string=connection_string)
        elif store_type == "redis":
            if not connection_string:
                raise ValueError("connection_string required for Redis store")
            _store_instance = RedisContractStore(connection_string=connection_string)
        else:
            raise ValueError(f"Unsupported store type: {store_type}")

        try:
            _store_instance.connect()
        except Exception as e:
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=f"Failed to initialize contract store: {str(e)}",
            ) from e

    return _store_instance
