"""Pycharter-specific folder resolver dependencies.

Provides the ``get_unfiled_resolver`` FastAPI dependency that returns a
dispatcher routing each folder type to its own unfiled-item resolver.

The resolver registry pattern allows adding new folder types (e.g.
``pipeline``) without modifying existing resolver logic — each type
registers a standalone function.
"""

from __future__ import annotations

import itertools
import logging
from collections.abc import Callable

from sqlalchemy.orm import Session

from pycharter.api.models.folders import FolderTreeNode
from pycharter.api.services._folder_helpers import UnfiledItemResolver
from pycharter.db.models.data_contract import DataContractModel
from pycharter.db.models.pipeline_config import PipelineConfigModel

logger = logging.getLogger(__name__)

# Type alias for individual resolver functions.
UnfiledResolverFn = Callable[
    [Session, set[str], str],
    list[FolderTreeNode],
]


# ---------------------------------------------------------------------------
# Per-type resolver functions
# ---------------------------------------------------------------------------


def _contract_unfiled_resolver(
    db: Session,
    filed_item_ids: set[str],
    folder_type: str,
) -> list[FolderTreeNode]:
    """Surface contracts not yet assigned to any folder as root-level items.

    Contracts sharing the same name are grouped into a single tree node
    representing the latest version.  The ``version_count`` field in
    ``item_meta`` indicates how many versions exist for that name.
    """
    contracts = (
        db.query(DataContractModel)
        .order_by(DataContractModel.name, DataContractModel.version)
        .all()
    )

    unfiled = [c for c in contracts if str(c.id) not in filed_item_ids]

    result: list[FolderTreeNode] = []
    for name, group in itertools.groupby(unfiled, key=lambda c: c.name):
        versions = list(group)
        latest = versions[-1]
        result.append(
            FolderTreeNode(
                id=f"unfiled-{folder_type}-group-{name}",
                name=name,
                kind="item",
                folder_type=folder_type,
                item_id=str(latest.id),
                item_label=name,
                item_meta={
                    "version": latest.version,
                    "status": latest.status,
                    "version_count": len(versions),
                },
            )
        )

    if result:
        logger.debug(
            "Added %d unfiled contract groups to %s tree",
            len(result),
            folder_type,
        )
    return result


def _pipeline_unfiled_resolver(
    db: Session,
    filed_item_ids: set[str],
    folder_type: str,
) -> list[FolderTreeNode]:
    """Surface pipeline configs not assigned to any folder.

    Configs sharing the same ``pipeline_name`` are grouped into a single
    tree node representing the latest version.
    """
    configs = (
        db.query(PipelineConfigModel)
        .order_by(
            PipelineConfigModel.pipeline_name,
            PipelineConfigModel.pipeline_version,
        )
        .all()
    )

    unfiled = [c for c in configs if str(c.id) not in filed_item_ids]

    result: list[FolderTreeNode] = []
    for name, group in itertools.groupby(unfiled, key=lambda c: c.pipeline_name):
        versions = list(group)
        latest = versions[-1]
        result.append(
            FolderTreeNode(
                id=f"unfiled-pipeline-group-{name}",
                name=name,
                kind="item",
                folder_type=folder_type,
                item_id=str(latest.id),
                item_label=name,
                item_meta={
                    "version": latest.pipeline_version,
                    "status": latest.status,
                    "version_count": len(versions),
                },
            )
        )

    if result:
        logger.debug(
            "Added %d unfiled pipeline groups to %s tree",
            len(result),
            folder_type,
        )
    return result


# ---------------------------------------------------------------------------
# Resolver registry
# ---------------------------------------------------------------------------

_UNFILED_RESOLVERS: dict[str, UnfiledResolverFn] = {
    "contract": _contract_unfiled_resolver,
    "ontology": _contract_unfiled_resolver,
    "pipeline": _pipeline_unfiled_resolver,
}


def _dispatch_resolver(
    db: Session,
    filed_item_ids: set[str],
    folder_type: str,
) -> list[FolderTreeNode]:
    """Route to the registered resolver for the given folder type."""
    resolver = _UNFILED_RESOLVERS.get(folder_type)
    if resolver is None:
        return []
    return resolver(db, filed_item_ids, folder_type)


# ---------------------------------------------------------------------------
# FastAPI dependency
# ---------------------------------------------------------------------------


def get_unfiled_resolver() -> UnfiledItemResolver | None:
    """FastAPI dependency returning the pycharter unfiled-item dispatcher."""
    return _dispatch_resolver
