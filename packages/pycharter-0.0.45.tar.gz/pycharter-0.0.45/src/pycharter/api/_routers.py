"""Router registration for the FastAPI application.

Centralises all ``include_router`` calls so ``main.py`` stays lean.
"""

from __future__ import annotations

from fastapi import Depends, FastAPI

from pycharter.api.dependencies.auth import get_current_user
from pycharter.api.routes.v1 import (
    auth,
    contracts,
    docs,
    evolution,
    folders,
    metadata,
    metadata_entities,
    ontology_configs,
    pipeline,
    pipeline_configs,
    quality,
    runs,
    schemas,
    semantic_concept_graph,
    semantic_dashboard,
    semantic_discovery,
    semantic_field_mapping,
    semantic_graph,
    semantic_ingestion,
    semantic_lineage,
    semantic_proposals,
    semantic_rdf,
    semantic_reviews,
    semantic_schema,
    semantic_schemes,
    semantic_search,
    semantic_versioning,
    settings,
    templates,
    tracking,
    validation,
    validation_jobs,
)

API_VERSION = "v1"


def register_routers(app: FastAPI) -> None:
    """Attach all v1 routers to *app*.

    Auth routes are public; every other router requires a valid Bearer
    token (when auth is enabled).
    """
    # Auth router: no global auth dependency
    app.include_router(
        auth.router,
        prefix=f"/api/{API_VERSION}",
        tags=["Auth"],
    )

    _auth_dep = [Depends(get_current_user)]

    # --- Core routers ---
    app.include_router(
        contracts.router,
        prefix=f"/api/{API_VERSION}",
        tags=["Contracts"],
        dependencies=_auth_dep,
    )
    app.include_router(
        metadata.router,
        prefix=f"/api/{API_VERSION}",
        tags=["Metadata"],
        dependencies=_auth_dep,
    )
    app.include_router(
        metadata_entities.router,
        prefix=f"/api/{API_VERSION}",
        tags=["Metadata"],
        dependencies=_auth_dep,
    )
    app.include_router(
        schemas.router,
        prefix=f"/api/{API_VERSION}",
        tags=["Schemas"],
        dependencies=_auth_dep,
    )
    app.include_router(
        validation.router,
        prefix=f"/api/{API_VERSION}",
        tags=["Validation"],
        dependencies=_auth_dep,
    )
    app.include_router(
        quality.router,
        prefix=f"/api/{API_VERSION}",
        tags=["Quality"],
        dependencies=_auth_dep,
    )
    app.include_router(
        templates.router,
        prefix=f"/api/{API_VERSION}",
        tags=["Templates"],
        dependencies=_auth_dep,
    )
    app.include_router(
        pipeline.router,
        prefix=f"/api/{API_VERSION}",
        tags=["Pipeline"],
        dependencies=_auth_dep,
    )
    app.include_router(
        pipeline_configs.router,
        prefix=f"/api/{API_VERSION}",
        tags=["Pipeline Configs"],
        dependencies=_auth_dep,
    )
    app.include_router(
        ontology_configs.router,
        prefix=f"/api/{API_VERSION}",
        tags=["Ontology Configs"],
        dependencies=_auth_dep,
    )
    app.include_router(
        runs.router,
        prefix=f"/api/{API_VERSION}",
        tags=["Pipeline Runs"],
        dependencies=_auth_dep,
    )
    app.include_router(
        settings.public_router,
        prefix=f"/api/{API_VERSION}",
        tags=["Settings"],
    )
    app.include_router(
        settings.router,
        prefix=f"/api/{API_VERSION}",
        tags=["Settings"],
        dependencies=_auth_dep,
    )
    # Docs: no auth so UI can load route list without token
    app.include_router(
        docs.router,
        prefix=f"/api/{API_VERSION}",
        tags=["Documentation"],
    )
    app.include_router(
        tracking.router,
        prefix=f"/api/{API_VERSION}",
        tags=["Quality Tracking"],
        dependencies=_auth_dep,
    )
    app.include_router(
        evolution.router,
        prefix=f"/api/{API_VERSION}",
        tags=["Schema Evolution"],
        dependencies=_auth_dep,
    )
    app.include_router(
        validation_jobs.router,
        prefix=f"/api/{API_VERSION}",
        tags=["Validation Jobs"],
        dependencies=_auth_dep,
    )
    app.include_router(
        folders.router,
        prefix=f"/api/{API_VERSION}",
        tags=["Folders"],
        dependencies=_auth_dep,
    )

    # --- Semantic routers (ontology, knowledge graph, governance) ---
    _semantic = [
        (semantic_dashboard, "dashboard", "Dashboard"),
        (semantic_field_mapping, "field-mapping", "Field Mapping"),
        (semantic_versioning, "versioning", "Versioning"),
        (semantic_proposals, "proposals", "Proposals"),
        (semantic_reviews, "reviews", "Reviews"),
        (semantic_graph, "graph", "Graph"),
        (semantic_search, "search", "Search"),
        (semantic_ingestion, "ingestion", "Ingestion"),
        (semantic_lineage, "lineage", "Lineage"),
        (semantic_discovery, "discovery", "Discovery"),
        (semantic_rdf, "rdf", "RDF / JSON-LD / SHACL"),
        (semantic_concept_graph, "concept-graph", "Concept Graph"),
        (semantic_schema, "schema", "Schema"),
    ]
    for module, path, label in _semantic:
        app.include_router(
            module.router,
            prefix=f"/api/{API_VERSION}/semantic/{path}",
            tags=[f"Semantic - {label}"],
            dependencies=_auth_dep,
        )

    # Schemes router has a shorter prefix (no sub-path)
    app.include_router(
        semantic_schemes.router,
        prefix=f"/api/{API_VERSION}/semantic",
        tags=["Semantic - Schemes"],
        dependencies=_auth_dep,
    )
