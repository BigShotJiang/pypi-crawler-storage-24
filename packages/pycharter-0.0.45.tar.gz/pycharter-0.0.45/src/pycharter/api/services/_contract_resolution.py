"""Artifact resolution logic for contract creation.

Resolves schema, rules, and metadata artifacts -- either creating new ones
via the contract store or finding existing ones in the database.
"""

from __future__ import annotations

import uuid
from typing import Any

from sqlalchemy.orm import Session

from pycharter.api.services.contract_validation import find_artifact
from pycharter.api.utils import ensure_uuid
from pycharter.contract_store import ContractStoreClient
from pycharter.db.models.data_contract import DataContractModel
from pycharter.db.models.field_mapping import FieldMappingModel
from pycharter.db.models.metadata_record import MetadataRecordModel
from pycharter.db.models.schema import SchemaModel


def resolve_schema(
    request: Any,
    store: ContractStoreClient,
    db: Session,
) -> uuid.UUID | None:
    """Resolve schema: create new via store or find existing by title+version.

    Args:
        request: A ``ContractCreateMixedRequest`` instance.
        store: Metadata store for creating new artifacts.
        db: Database session.

    Returns:
        UUID of the schema, or None if resolution fails silently.

    Raises:
        ContractConflictError: If the schema or contract already exists.
        ArtifactNotFoundError: If an existing schema cannot be found.
        ValueError: If schema creation fails for a non-conflict reason.
    """
    if request.json_schema is not None:
        return _create_new_schema(request, store, db)
    if request.schema_title and request.schema_version:
        return _find_existing_schema(request, db)
    return None


def _create_new_schema(
    request: Any,
    store: ContractStoreClient,
    db: Session,
) -> uuid.UUID | None:
    """Create a new schema artifact via the contract store.

    Args:
        request: Request with ``name``, ``version``, ``schema`` fields.
        store: Metadata store client.
        db: Database session.

    Returns:
        UUID of the schema created by the store.

    Raises:
        ContractConflictError: If the schema already exists.
        ValueError: If schema creation fails.
    """
    from pycharter.api.services.contract_service import ContractConflictError

    try:
        store.store_schema(request.name, request.version, request.json_schema)
        dc = (
            db.query(DataContractModel)
            .filter(
                DataContractModel.name == request.name,
                DataContractModel.version == request.version,
            )
            .first()
        )
        return dc.schema_id if dc else None
    except ValueError as exc:
        error_msg = str(exc)
        if "already exists" in error_msg.lower():
            schema_title = request.json_schema.get("title") or request.name
            schema_version = request.json_schema.get("version") or request.version
            raise ContractConflictError(
                f"Schema artifact '{schema_title}' v'{schema_version}' already exists. "
                "To use this existing schema, select 'Use Existing' mode and pick it "
                "by title and version. "
                "To create a new schema artifact, use a different version number "
                "in your schema JSON."
            ) from exc
        raise


def _find_existing_schema(request: Any, db: Session) -> uuid.UUID | None:
    """Find an existing schema by title+version, checking for contract duplicates.

    Args:
        request: Request with ``name``, ``version``, ``schema_title``,
            ``schema_version``.
        db: Database session.

    Returns:
        UUID of the found schema.

    Raises:
        ContractConflictError: If a contract with the same name+version exists.
        ArtifactNotFoundError: If the schema is not found.
    """
    from pycharter.api.services.contract_service import ArtifactNotFoundError
    from pycharter.api.services.contract_validation import check_contract_duplicate

    check_contract_duplicate(db, request.name, request.version)

    schema = (
        db.query(SchemaModel)
        .filter(
            SchemaModel.title == request.schema_title,
            SchemaModel.version == request.schema_version,
        )
        .first()
    )
    if not schema:
        raise ArtifactNotFoundError(
            f"Schema not found: title='{request.schema_title}', "
            f"version='{request.schema_version}'"
        )
    return ensure_uuid(schema.id)


def resolve_rules(
    request_data: dict[str, Any] | None,
    request_title: str | None,
    request_version: str | None,
    contract_name: str,
    contract_version: str,
    store_fn: Any,
    db: Session,
    model: type,
    label: str,
) -> uuid.UUID | None:
    """Resolve a rules artifact: create new or find existing.

    Args:
        request_data: New rules data dict, or None.
        request_title: Existing artifact title, or None.
        request_version: Existing artifact version, or None.
        contract_name: Parent contract name.
        contract_version: Parent contract version.
        store_fn: Callable to store new artifact.
        db: Database session.
        model: SQLAlchemy model for DB lookup.
        label: Human-readable label for error messages.

    Returns:
        UUID of the resolved artifact, or None.

    Raises:
        ContractConflictError: If the artifact already exists.
        ArtifactNotFoundError: If an existing artifact cannot be found.
        ValueError: If creation fails for a non-conflict reason.
    """
    if request_data is not None and len(request_data) > 0:
        return create_new_rules(
            request_data, contract_name, contract_version, store_fn, label
        )
    if request_title and request_version:
        return find_artifact(db, model, request_title, request_version, label)
    return None


def create_new_rules(
    data: dict[str, Any],
    contract_name: str,
    contract_version: str,
    store_fn: Any,
    label: str,
) -> uuid.UUID | None:
    """Create a new rules artifact via a store method.

    Args:
        data: The rules payload.
        contract_name: Parent contract name.
        contract_version: Parent contract version.
        store_fn: Store method to call.
        label: Human-readable label.

    Returns:
        UUID of the newly created artifact.

    Raises:
        ContractConflictError: If the artifact already exists.
        ValueError: If creation fails for a non-conflict reason.
    """
    from pycharter.api.services.contract_service import ContractConflictError

    try:
        result_id = store_fn(contract_name, contract_version, data)
        return ensure_uuid(result_id) if result_id else None
    except ValueError as exc:
        if "already exists" in str(exc).lower():
            raise ContractConflictError(
                f"{label} artifact already exists with this version. "
                f"To use existing {label.lower()}, select 'Use Existing' mode. "
                f"To create new {label.lower()}, the artifact version must be unique."
            ) from exc
        raise


def resolve_metadata(
    request: Any,
    store: ContractStoreClient,
    db: Session,
) -> uuid.UUID | None:
    """Resolve metadata: create new via store or find existing by title+version.

    Args:
        request: A ``ContractCreateMixedRequest`` instance.
        store: Metadata store for creating new artifacts.
        db: Database session.

    Returns:
        UUID of the metadata record, or None.

    Raises:
        ContractConflictError: If the metadata artifact already exists.
        ArtifactNotFoundError: If an existing metadata record cannot be found.
        ValueError: If metadata creation fails for a non-conflict reason.
    """
    if request.metadata is not None and len(request.metadata) > 0:
        return create_new_rules(
            request.metadata,
            request.name,
            request.version,
            store.store_metadata,
            "Metadata",
        )
    if request.metadata_title and request.metadata_version:
        return find_artifact(
            db,
            MetadataRecordModel,
            request.metadata_title,
            request.metadata_version,
            "Metadata",
        )
    return None


def resolve_field_mapping(
    request: Any,
    store: ContractStoreClient,
    db: Session,
) -> uuid.UUID | None:
    """Resolve field mapping: create new via store or find existing.

    Args:
        request: A ``ContractCreateMixedRequest`` instance.
        store: Metadata store for creating new artifacts.
        db: Database session.

    Returns:
        UUID of the field mapping, or None.

    Raises:
        ContractConflictError: If the field mapping already exists.
        ArtifactNotFoundError: If an existing field mapping cannot be found.
        ValueError: If creation fails for a non-conflict reason.
    """
    if request.field_mapping is not None and len(request.field_mapping) > 0:
        return create_new_rules(
            request.field_mapping,
            request.name,
            request.version,
            store.store_field_mapping,
            "Field mapping",
        )
    if request.field_mapping_title and request.field_mapping_version:
        return find_artifact(
            db,
            FieldMappingModel,
            request.field_mapping_title,
            request.field_mapping_version,
            "Field mapping",
        )
    return None
