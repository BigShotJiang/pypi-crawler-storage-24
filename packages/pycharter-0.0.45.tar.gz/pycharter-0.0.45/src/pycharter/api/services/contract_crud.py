"""Contract CRUD operations (create, read, update, delete).

Thin re-export shim that provides a single import point for all contract
CRUD functions.  The actual implementations live in:

- ``_contract_read`` -- build_contract_from_db and related helpers.
- ``_contract_create`` -- create_from_existing_artifacts, create_mixed.
- ``_contract_update`` -- update_fields and related helpers.
"""

from __future__ import annotations

from pycharter.api.services._contract_create import (  # noqa: F401
    create_from_existing_artifacts,
    create_mixed,
)
from pycharter.api.services._contract_read import (  # noqa: F401
    build_contract_from_db,
)
from pycharter.api.services._contract_update import (  # noqa: F401
    update_fields,
)

__all__ = [
    "build_contract_from_db",
    "create_from_existing_artifacts",
    "create_mixed",
    "update_fields",
]
