"""Contract parsing and listing business logic.

Extracts parse, list, get, and delete logic from route handlers so that
routes remain thin HTTP adapters.  Functions raise domain exceptions or
plain ``ValueError`` -- callers map them to HTTP responses.
"""

from __future__ import annotations

import contextlib
import logging
import tempfile
from pathlib import Path
from typing import Any

from sqlalchemy.orm import Session

from pycharter import parse_contract, parse_contract_file
from pycharter.api.utils import ensure_uuid, get_by_id_or_404, safe_uuid_to_str
from pycharter.db.models import DataContractModel

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Contract model conversion
# ---------------------------------------------------------------------------


def contract_to_list_item(contract: DataContractModel) -> dict[str, Any]:
    """Convert a DataContractModel to a dict matching ContractListItem fields.

    Args:
        contract: The database model instance.

    Returns:
        Dictionary with id, name, version, status, description, schema_id,
        created_at, and updated_at.
    """
    return {
        "id": safe_uuid_to_str(contract.id),
        "name": contract.name,
        "version": contract.version,
        "status": contract.status,
        "description": contract.description,
        "schema_id": (
            safe_uuid_to_str(contract.schema_id) if contract.schema_id else None
        ),
        "created_at": (
            contract.created_at.isoformat() if contract.created_at else None
        ),
        "updated_at": (
            contract.updated_at.isoformat() if contract.updated_at else None
        ),
    }


# ---------------------------------------------------------------------------
# Parse helpers
# ---------------------------------------------------------------------------


def unwrap_contract_data(contract_data: Any) -> dict[str, Any]:
    """Unwrap potentially double-wrapped contract data and validate.

    Handles the case where the contract is wrapped in an extra
    ``{"contract": ...}`` layer.

    Args:
        contract_data: Raw contract payload from the request.

    Returns:
        Unwrapped contract dictionary.

    Raises:
        ValueError: If the data is not a dict or lacks a ``schema`` key.
    """
    if (
        isinstance(contract_data, dict)
        and "contract" in contract_data
        and len(contract_data) == 1
    ):
        contract_data = contract_data["contract"]

    if not isinstance(contract_data, dict):
        raise ValueError(
            f"Invalid contract format: expected dict, got {type(contract_data)}"
        )

    if "schema" not in contract_data:
        raise ValueError("Contract must contain a 'schema' field at the top level")

    return contract_data


def parse_contract_dict(contract_data: dict[str, Any]) -> dict[str, Any]:
    """Parse a contract dictionary into its component parts.

    Args:
        contract_data: Validated contract dictionary.

    Returns:
        Dictionary with schema, metadata, ownership, governance_rules,
        coercion_rules, validation_rules, and versions keys.

    Raises:
        ValueError: If parsing fails.
    """
    contract_metadata = parse_contract(contract_data)
    return {
        "json_schema": contract_metadata.schema,
        "metadata": contract_metadata.metadata,
        "ownership": contract_metadata.ownership,
        "governance_rules": contract_metadata.governance_rules,
        "coercion_rules": contract_metadata.coercion_rules,
        "validation_rules": contract_metadata.validation_rules,
        "versions": contract_metadata.versions,
    }


def parse_contract_from_upload(
    content: bytes,
    file_extension: str,
    *,
    validate: bool = True,
) -> dict[str, Any]:
    """Parse a contract from uploaded file bytes.

    Writes content to a temporary file, parses it, and cleans up.

    Args:
        content: Raw file bytes.
        file_extension: File extension (e.g. ``.yaml``).
        validate: Whether to validate the contract against schema.

    Returns:
        Dictionary with parsed contract components.

    Raises:
        ValueError: If file format is unsupported or parsing fails.
        FileNotFoundError: If the temp file disappears unexpectedly.
    """
    if file_extension not in (".yaml", ".yml", ".json"):
        raise ValueError(
            f"Unsupported file format: {file_extension}. "
            "Only YAML (.yaml, .yml) and JSON (.json) files are supported."
        )

    with tempfile.NamedTemporaryFile(delete=False, suffix=file_extension) as tmp_file:
        tmp_file.write(content)
        tmp_file_path = tmp_file.name

    try:
        contract_metadata = parse_contract_file(tmp_file_path, validate=validate)
        return {
            "json_schema": contract_metadata.schema,
            "metadata": contract_metadata.metadata,
            "ownership": contract_metadata.ownership,
            "governance_rules": contract_metadata.governance_rules,
            "coercion_rules": contract_metadata.coercion_rules,
            "validation_rules": contract_metadata.validation_rules,
            "versions": contract_metadata.versions,
        }
    finally:
        with contextlib.suppress(Exception):
            Path(tmp_file_path).unlink()


# ---------------------------------------------------------------------------
# List / Get / Delete helpers
# ---------------------------------------------------------------------------


def list_all_contracts(db: Session) -> list[dict[str, Any]]:
    """List all contracts from the database, ordered by created_at desc.

    Args:
        db: Database session.

    Returns:
        List of contract dicts matching ContractListItem fields.
    """
    contracts = (
        db.query(DataContractModel).order_by(DataContractModel.created_at.desc()).all()
    )
    logger.debug("Found %s contracts in database", len(contracts))
    return [contract_to_list_item(c) for c in contracts]


def get_contract_by_id(db: Session, contract_id: str) -> DataContractModel:
    """Fetch a single contract by ID, validating the UUID format.

    Args:
        db: Database session.
        contract_id: Contract UUID string.

    Returns:
        The DataContractModel instance.

    Raises:
        ValueError: If the ID format is invalid.
        HTTPException: Via ``get_by_id_or_404`` if not found.
    """
    ensure_uuid(contract_id)
    return get_by_id_or_404(
        db,
        DataContractModel,
        contract_id,
        error_message=f"Contract not found: {contract_id}",
        model_name="Contract",
    )


def list_versions_by_name(db: Session, contract_name: str) -> list[dict[str, Any]]:
    """List all versions of a contract by name, ordered newest-first.

    Args:
        db: Database session.
        contract_name: Contract name to look up.

    Returns:
        List of dicts with id, version, status, created_at, updated_at.
    """
    contracts = (
        db.query(DataContractModel)
        .filter(DataContractModel.name == contract_name)
        .order_by(DataContractModel.version.desc())
        .all()
    )
    return [
        {
            "id": safe_uuid_to_str(c.id),
            "version": c.version,
            "status": c.status,
            "created_at": c.created_at.isoformat() if c.created_at else None,
            "updated_at": c.updated_at.isoformat() if c.updated_at else None,
        }
        for c in contracts
    ]


def delete_contract_by_id(db: Session, contract_id: str) -> None:
    """Delete a contract by ID.

    Args:
        db: Database session.
        contract_id: Contract UUID string.

    Raises:
        ValueError: If the ID format is invalid.
        RuntimeError: If the delete fails.
    """
    ensure_uuid(contract_id)
    contract = get_by_id_or_404(
        db,
        DataContractModel,
        contract_id,
        error_message=f"Contract not found: {contract_id}",
        model_name="Contract",
    )

    try:
        db.delete(contract)
        db.commit()
    except Exception as exc:
        db.rollback()
        logger.error("Error deleting contract: %s", exc, exc_info=True)
        raise RuntimeError(f"Failed to delete contract: {exc}") from exc
