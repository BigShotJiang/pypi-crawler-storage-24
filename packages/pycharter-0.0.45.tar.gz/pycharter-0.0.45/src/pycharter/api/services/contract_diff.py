"""Contract diff, evolution, and comparison logic.

Provides utilities for comparing contract versions, computing diffs between
contract artifacts, and tracking contract evolution over time.
"""

from __future__ import annotations

import logging

logger = logging.getLogger(__name__)
