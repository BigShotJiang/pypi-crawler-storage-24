"""Generic folder tree helpers.

Pure functions for building folder trees, checking circular references,
and mapping ORM folder models to API response models.  These helpers are
domain-agnostic — they work with any ``folder_type`` string and can be
reused by pystator, pyoptima, pycatalyst, or any other package that
uses the editor folder system.

The one domain-specific extension point is :class:`UnfiledItemResolver`,
a callback protocol that lets each package inject its own logic for
surfacing items that haven't been filed into any folder.
"""

from __future__ import annotations

import logging
import uuid
from typing import Protocol

from sqlalchemy.orm import Session

from pycharter.api.models.folders import FolderResponse, FolderTreeNode
from pycharter.db.models.editor_folder import (
    EditorFolderItemModel,
    EditorFolderModel,
)

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Unfiled-item resolver protocol
# ---------------------------------------------------------------------------


class UnfiledItemResolver(Protocol):
    """Callback that returns items not yet assigned to any folder.

    Each package (pycharter, pystator, …) can implement this to surface
    domain-specific items as root-level entries in the folder tree.

    Args:
        db: Active SQLAlchemy session.
        filed_item_ids: Item IDs already assigned to a folder.
        folder_type: The folder type being queried (e.g. ``'contract'``).

    Returns:
        List of tree nodes to append at the root level.
    """

    def __call__(
        self,
        db: Session,
        filed_item_ids: set[str],
        folder_type: str,
    ) -> list[FolderTreeNode]: ...


# ---------------------------------------------------------------------------
# ORM → response mapping
# ---------------------------------------------------------------------------


def folder_to_response(folder: EditorFolderModel) -> FolderResponse:
    """Map an ORM folder to a response model."""
    return FolderResponse(
        id=str(folder.id),
        name=folder.name,
        parent_id=str(folder.parent_id) if folder.parent_id else None,
        folder_type=folder.folder_type,
        position=folder.position,
        created_at=folder.created_at.isoformat() if folder.created_at else None,
        updated_at=folder.updated_at.isoformat() if folder.updated_at else None,
    )


# ---------------------------------------------------------------------------
# Tree construction
# ---------------------------------------------------------------------------


def build_tree(
    folders: list[EditorFolderModel],
    items: list[EditorFolderItemModel],
    folder_type: str,
) -> list[FolderTreeNode]:
    """Assemble flat folder + item lists into a nested tree."""
    items_by_folder: dict[str, list[FolderTreeNode]] = {}
    for item in sorted(items, key=lambda i: i.position):
        fid = str(item.folder_id)
        items_by_folder.setdefault(fid, []).append(
            FolderTreeNode(
                id=str(item.id),
                name=item.item_label or item.item_id,
                kind="item",
                folder_type=folder_type,
                item_id=item.item_id,
                item_label=item.item_label,
                item_meta=item.item_meta,
            )
        )

    children_by_parent: dict[str | None, list[EditorFolderModel]] = {}
    for folder in sorted(folders, key=lambda f: f.position):
        pid = str(folder.parent_id) if folder.parent_id else None
        children_by_parent.setdefault(pid, []).append(folder)

    def _recurse(parent_id: str | None) -> list[FolderTreeNode]:
        nodes: list[FolderTreeNode] = []
        for folder in children_by_parent.get(parent_id, []):
            fid = str(folder.id)
            folder_children = _recurse(fid)
            folder_items = items_by_folder.get(fid, [])
            nodes.append(
                FolderTreeNode(
                    id=fid,
                    name=folder.name,
                    kind="folder",
                    folder_type=folder_type,
                    children=[*folder_children, *folder_items],
                )
            )
        return nodes

    return _recurse(None)


# ---------------------------------------------------------------------------
# Circular-reference guard
# ---------------------------------------------------------------------------


def check_circular(
    db: Session,
    folder_id: uuid.UUID,
    new_parent_id: uuid.UUID | None,
) -> bool:
    """Return True if moving *folder_id* under *new_parent_id* would cycle."""
    if new_parent_id is None:
        return False
    current = new_parent_id
    while current is not None:
        if current == folder_id:
            return True
        parent = (
            db.query(EditorFolderModel.parent_id)
            .filter(EditorFolderModel.id == current)
            .scalar()
        )
        current = parent
    return False
