"""Contract update and delete operations.

Implements field-level updates for existing data contracts using raw SQL
with fallback strategies for SQLite and PostgreSQL backends.
"""

from __future__ import annotations

import logging
from typing import Any

from sqlalchemy.orm import Session

from pycharter.api.services._contract_read import _get_by_id
from pycharter.api.services.contract_validation import (
    check_name_version_unique,
    check_update_has_fields,
    validate_uuid,
)
from pycharter.api.utils import safe_uuid_to_str
from pycharter.db.models import DataContractModel

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# update_fields
# ---------------------------------------------------------------------------


def update_fields(
    contract_id: str,
    request: Any,
    db: Session,
) -> DataContractModel:
    """Update a contract's metadata fields.

    Args:
        contract_id: Contract UUID string.
        request: A ``ContractUpdateRequest`` instance.
        db: Database session.

    Returns:
        The updated DataContractModel.

    Raises:
        ValueError: If *contract_id* is not a valid UUID or no fields provided.
        ContractNotFoundError: If the contract does not exist.
        ContractConflictError: If name+version would clash with another contract.
        RuntimeError: If the database update fails.
    """
    validate_uuid(contract_id)

    contract = _get_by_id(db, DataContractModel, contract_id, "Contract")

    check_update_has_fields(request)
    check_name_version_unique(request, contract, db)

    _execute_raw_update(contract_id, contract, request, db)

    db.expire(contract)
    return _get_by_id(db, DataContractModel, contract_id, "Contract")


def _build_set_clauses(request: Any) -> tuple[list[str], dict[str, Any]]:
    """Build SQL SET clauses from a ContractUpdateRequest.

    Args:
        request: Update request.

    Returns:
        Tuple of (set_clause_strings, params_dict).
    """
    clauses: list[str] = []
    params: dict[str, Any] = {}

    if request.name is not None:
        clauses.append("name = :name")
        params["name"] = request.name
    if request.version is not None:
        clauses.append("version = :version")
        params["version"] = request.version
    if request.status is not None:
        clauses.append("status = :status")
        params["status"] = request.status
    if request.description is not None:
        clauses.append("description = :description")
        params["description"] = request.description

    clauses.append("updated_at = CURRENT_TIMESTAMP")
    return clauses, params


def _execute_raw_update(
    contract_id: str,
    contract: DataContractModel,
    request: Any,
    db: Session,
) -> None:
    """Execute a raw SQL UPDATE for the contract.

    Args:
        contract_id: Contract UUID string.
        contract: Current contract model.
        request: Update request.
        db: Database session.

    Raises:
        ContractNotFoundError: If no rows are updated after all fallback
            attempts.
        RuntimeError: If the update or commit fails.
    """
    from sqlalchemy import text

    from pycharter.api.services.contract_service import ContractNotFoundError

    set_clauses, params = _build_set_clauses(request)
    set_clause = ", ".join(set_clauses)
    contract_id_str = safe_uuid_to_str(contract.id) or contract_id

    engine = db.bind if hasattr(db, "bind") else None
    is_sqlite = engine and "sqlite" in str(engine.url)

    try:
        _do_update(db, set_clause, params, contract_id_str, contract, is_sqlite, text)
        db.commit()
    except (ContractNotFoundError, RuntimeError):
        db.rollback()
        raise
    except Exception as exc:
        db.rollback()
        logger.error("Error updating contract: %s", exc, exc_info=True)
        raise RuntimeError(f"Failed to update contract: {exc}") from exc


def _do_update(
    db: Session,
    set_clause: str,
    params: dict[str, Any],
    contract_id_str: str,
    contract: DataContractModel,
    is_sqlite: bool,
    text: Any,
) -> None:
    """Try multiple SQL strategies to update the contract row.

    Args:
        db: Database session.
        set_clause: SQL SET clause string.
        params: Query parameters.
        contract_id_str: Contract ID as string.
        contract: Contract model instance.
        is_sqlite: Whether using SQLite backend.
        text: SQLAlchemy ``text`` function.

    Raises:
        ContractNotFoundError: If no rows are updated.
    """
    from pycharter.api.services.contract_service import ContractNotFoundError

    table = "data_contracts" if is_sqlite else "pycharter.data_contracts"
    params["contract_id"] = contract_id_str

    if is_sqlite:
        sql = f"UPDATE {table} SET {set_clause} WHERE id = :contract_id"
    else:
        sql = f"UPDATE {table} SET {set_clause} WHERE id = :contract_id::uuid"

    result = db.execute(text(sql), params)
    if result.rowcount > 0:
        return

    # Fallback: alternative comparison
    if is_sqlite:
        fallback = (
            f"UPDATE {table} SET {set_clause} WHERE CAST(id AS TEXT) = :contract_id"
        )
    else:
        fallback = f"UPDATE {table} SET {set_clause} WHERE id::text = :contract_id"

    params["contract_id"] = contract_id_str
    result = db.execute(text(fallback), params)
    if result.rowcount > 0:
        return

    # Last resort for PostgreSQL: try UUID object
    if not is_sqlite:
        uuid_sql = f"UPDATE {table} SET {set_clause} WHERE id = :contract_id"
        params["contract_id"] = contract.id
        result = db.execute(text(uuid_sql), params)
        if result.rowcount > 0:
            return

    raise ContractNotFoundError(
        f"Contract not found or could not be updated: {contract_id_str}"
    )
