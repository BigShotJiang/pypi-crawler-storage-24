"""Quality assurance business logic.

Backward-compatibility shim -- the implementation now lives in
``_quality_metrics`` and ``_quality_reports``.  All public names are
re-exported here so that existing imports continue to work.
"""

from __future__ import annotations

from pycharter.api.services._quality_metrics import (
    QualityCheckValidationError,
    QualityMetricNotFoundError,
    QualityReportNotFoundError,
    get_quality_metric,
    list_quality_metrics,
    query_violations,
)
from pycharter.api.services._quality_reports import (
    convert_report_to_response,
    get_quality_reports,
    run_quality_check,
    run_quality_check_with_file,
)

__all__ = [
    "QualityCheckValidationError",
    "QualityMetricNotFoundError",
    "QualityReportNotFoundError",
    "convert_report_to_response",
    "get_quality_metric",
    "get_quality_reports",
    "list_quality_metrics",
    "query_violations",
    "run_quality_check",
    "run_quality_check_with_file",
]
