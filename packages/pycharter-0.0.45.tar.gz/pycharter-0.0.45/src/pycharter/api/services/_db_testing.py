"""Database and DLQ connection testing operations.

Internal module containing connection testing, DLQ verification, and DLQ
statistics logic. Re-exported via ``settings_service`` for public use.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from sqlalchemy import create_engine, text
from sqlalchemy.exc import SQLAlchemyError

# ---------------------------------------------------------------------------
# Result types
# ---------------------------------------------------------------------------


@dataclass(frozen=True, slots=True)
class ConnectionTestResult:
    """Result of a database or DLQ connection test."""

    success: bool
    message: str


@dataclass(frozen=True, slots=True)
class DlqStats:
    """DLQ table statistics."""

    total_messages: int
    by_reason: dict[str, int | None] = field(default_factory=dict)
    by_stage: dict[str, int | None] = field(default_factory=dict)
    by_status: dict[str, int | None] = field(default_factory=dict)


# ---------------------------------------------------------------------------
# Exceptions
# ---------------------------------------------------------------------------


class ConnectionBuildError(ValueError):
    """Raised when connection string parameters are insufficient."""


# ---------------------------------------------------------------------------
# Connection string builder
# ---------------------------------------------------------------------------


def build_connection_string(
    connection_string: str | None = None,
    host: str | None = None,
    port: int | None = None,
    database: str | None = None,
    username: str | None = None,
    password: str | None = None,
) -> str:
    """Build a database connection string from components.

    Args:
        connection_string: Full connection string (takes precedence).
        host: Database host.
        port: Database port (defaults to 5432).
        database: Database name.
        username: Optional username.
        password: Optional password.

    Returns:
        A postgresql:// connection string.

    Raises:
        ConnectionBuildError: If neither a connection string nor
            host+database are provided.
    """
    if connection_string:
        return connection_string

    if not all([host, database]):
        raise ConnectionBuildError(
            "Either connection_string or (host and database) must be provided"
        )

    if port is None:
        port = 5432

    if username and password:
        return f"postgresql://{username}:{password}@{host}:{port}/{database}"
    elif username:
        return f"postgresql://{username}@{host}:{port}/{database}"
    else:
        return f"postgresql://{host}:{port}/{database}"


# ---------------------------------------------------------------------------
# Database connection test
# ---------------------------------------------------------------------------


def test_database_connection(
    connection_string: str,
) -> ConnectionTestResult:
    """Test a database connection.

    Args:
        connection_string: Full database connection string.

    Returns:
        ConnectionTestResult indicating success or failure.
    """
    try:
        engine = create_engine(connection_string, pool_pre_ping=True)
        with engine.connect() as conn:
            conn.execute(text("SELECT 1"))
        return ConnectionTestResult(
            success=True, message="Database connection successful"
        )
    except SQLAlchemyError as exc:
        return ConnectionTestResult(
            success=False, message=f"Database connection failed: {exc}"
        )
    except Exception as exc:
        return ConnectionTestResult(success=False, message=f"Unexpected error: {exc}")


# ---------------------------------------------------------------------------
# DLQ connection test
# ---------------------------------------------------------------------------


def test_dlq_connection(
    connection_string: str, table_name: str
) -> ConnectionTestResult:
    """Test a DLQ database connection and verify the table exists.

    Args:
        connection_string: Full database connection string.
        table_name: Name of the DLQ table to check.

    Returns:
        ConnectionTestResult indicating success or failure.
    """
    try:
        engine = create_engine(connection_string, pool_pre_ping=True)
        with engine.connect() as conn:
            if engine.dialect.name == "postgresql":
                result = conn.execute(
                    text(
                        "SELECT EXISTS (SELECT FROM information_schema.tables "
                        "WHERE table_name = :table_name)"
                    ),
                    {"table_name": table_name},
                )
                exists = result.scalar()
                if not exists:
                    return ConnectionTestResult(
                        success=False,
                        message=f"Table '{table_name}' does not exist",
                    )
            elif engine.dialect.name == "sqlite":
                conn.execute(
                    text(
                        "SELECT name FROM sqlite_master "
                        "WHERE type='table' AND name=:table_name"
                    ),
                    {"table_name": table_name},
                )
            else:
                conn.execute(text(f"SELECT 1 FROM {table_name} LIMIT 1"))

        return ConnectionTestResult(
            success=True,
            message=(f"DLQ connection successful. Table '{table_name}' exists."),
        )
    except SQLAlchemyError as exc:
        return ConnectionTestResult(
            success=False, message=f"DLQ connection failed: {exc}"
        )
    except Exception as exc:
        return ConnectionTestResult(success=False, message=f"Unexpected error: {exc}")


# ---------------------------------------------------------------------------
# DLQ statistics
# ---------------------------------------------------------------------------


def get_dlq_stats(connection_string: str, table_name: str) -> DlqStats:
    """Query DLQ table and return statistics.

    Args:
        connection_string: Full database connection string.
        table_name: Name of the DLQ table.

    Returns:
        DlqStats with aggregate counts.

    Raises:
        SQLAlchemyError: On database errors.
    """
    engine = create_engine(connection_string, pool_pre_ping=True)

    with engine.connect() as conn:
        total_result = conn.execute(text(f"SELECT COUNT(*) FROM {table_name}"))
        total_messages = total_result.scalar() or 0

        by_reason = _group_count(conn, table_name, "reason")
        by_stage = _group_count(conn, table_name, "stage")
        by_status = _group_count(conn, table_name, "status")

    return DlqStats(
        total_messages=total_messages,
        by_reason=by_reason,
        by_stage=by_stage,
        by_status=by_status,
    )


# ---------------------------------------------------------------------------
# Private helpers
# ---------------------------------------------------------------------------


def _group_count(conn: Any, table_name: str, column: str) -> dict[str, int | None]:
    """Run a GROUP BY count, returning empty dict if column is missing."""
    try:
        result = conn.execute(
            text(
                f"SELECT {column}, COUNT(*) as count "
                f"FROM {table_name} GROUP BY {column}"
            )
        )
        return {(row[0] or "unknown"): row[1] for row in result}
    except Exception:
        return {}
