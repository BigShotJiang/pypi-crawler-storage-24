"""Contract read operations (build contract from database artifacts).

Loads and assembles a complete contract dictionary from stored database
artifacts -- schema, coercion/validation rules, metadata, and ontology.
"""

from __future__ import annotations

import logging
from contextlib import suppress
from typing import Any

from sqlalchemy.orm import Session

from pycharter import build_contract
from pycharter.api.services.contract_validation import validate_uuid
from pycharter.api.utils import safe_uuid_to_str
from pycharter.contract_builder.builder import ContractArtifacts
from pycharter.contract_store import ContractStoreClient
from pycharter.db.models import (
    CoercionRuleModel,
    DataContractModel,
    MetadataRecordModel,
    SchemaModel,
    ValidationRuleModel,
)

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Shared helpers (private)
# ---------------------------------------------------------------------------


def _get_by_id(db: Session, model: type, id_value: Any, label: str) -> Any:
    """Fetch a record by ID, raising ArtifactNotFoundError if absent.

    Args:
        db: Database session.
        model: SQLAlchemy model class.
        id_value: Primary key value (UUID or str).
        label: Human-readable name for error messages.

    Returns:
        The model instance.

    Raises:
        ArtifactNotFoundError: If no matching record is found.
    """
    from pycharter.api.services.contract_service import ArtifactNotFoundError
    from pycharter.api.utils import get_by_id_with_fallback

    record = get_by_id_with_fallback(db, model, id_value)
    if record is None:
        raise ArtifactNotFoundError(
            f"{label} with ID {safe_uuid_to_str(id_value)} not found"
        )
    return record


# ---------------------------------------------------------------------------
# build_contract_from_db
# ---------------------------------------------------------------------------


def _fetch_ownership(metadata_record: Any) -> dict[str, Any]:
    """Extract ownership data from a metadata record's relationships.

    Args:
        metadata_record: A MetadataRecordModel instance.

    Returns:
        Ownership dict (may be empty).
    """
    ownership: dict[str, Any] = {}
    with suppress(Exception):
        if (
            hasattr(metadata_record, "business_owners_rel")
            and metadata_record.business_owners_rel
        ):
            owners = [
                {
                    "name": getattr(rel.owner, "name", ""),
                    "email": getattr(rel.owner, "email", ""),
                }
                for rel in metadata_record.business_owners_rel
                if hasattr(rel, "owner") and rel.owner
            ]
            if owners:
                ownership["business_owners"] = owners
    return ownership


def _collect_metadata_artifacts(
    contract: DataContractModel,
    db: Session,
    *,
    include_ownership: bool,
    include_governance: bool,
) -> tuple[dict[str, Any] | None, dict[str, Any] | None, Any]:
    """Load metadata, ownership, and governance data for a contract.

    Args:
        contract: The DataContractModel whose metadata to load.
        db: Database session.
        include_ownership: Whether to extract ownership info.
        include_governance: Whether to include governance rules.

    Returns:
        Tuple of (metadata_data, ownership_data, governance_rules_data).
    """
    if not contract.metadata_record_id:
        return None, None, None

    record = _get_by_id(
        db, MetadataRecordModel, contract.metadata_record_id, "MetadataRecord"
    )

    metadata_data: dict[str, Any] = {"version": record.version}
    if record.description:
        metadata_data["description"] = record.description
    if record.status:
        metadata_data["status"] = record.status

    ownership_data = _fetch_ownership(record) if include_ownership else None
    governance_data = (
        record.governance_rules
        if include_governance and record.governance_rules
        else None
    )
    return metadata_data, ownership_data, governance_data


def _load_rules(
    db: Session,
    model: type,
    rules_id: Any,
) -> dict[str, Any] | None:
    """Load coercion or validation rules by ID.

    Args:
        db: Database session.
        model: CoercionRuleModel or ValidationRuleModel.
        rules_id: FK value (UUID, str, or None).

    Returns:
        Dict with ``version`` and ``rules`` keys, or ``None``.
    """
    if not rules_id:
        return None
    record = _get_by_id(db, model, rules_id, model.__name__)
    if record and record.rules:
        return {"version": record.version, "rules": dict(record.rules)}
    return None


def build_contract_from_db(
    contract_id: str,
    store: ContractStoreClient,
    db: Session,
    *,
    include_metadata: bool = True,
    include_ownership: bool = True,
    include_governance: bool = True,
) -> dict[str, Any]:
    """Build a complete contract dict from database artifacts.

    Args:
        contract_id: Contract UUID string.
        store: Metadata store (used for ontology lookup).
        db: Database session.
        include_metadata: Include metadata section.
        include_ownership: Include ownership section.
        include_governance: Include governance rules section.

    Returns:
        The fully assembled contract dictionary.

    Raises:
        ValueError: If *contract_id* is not a valid UUID.
        ContractNotFoundError: If the contract or a required artifact is missing.
        ContractBuildError: If the contract cannot be assembled.
    """
    from pycharter.api.services.contract_service import ContractBuildError

    validate_uuid(contract_id)

    contract = _get_by_id(db, DataContractModel, contract_id, "Contract")

    if not contract.schema_id:
        raise ContractBuildError(
            f"Contract '{contract.name}' (ID: {contract_id}) does not have "
            "a linked schema. Cannot build contract without a schema."
        )

    schema = _get_by_id(db, SchemaModel, contract.schema_id, "Schema")
    schema_data = dict(schema.schema_data) if schema.schema_data else {}
    if "version" not in schema_data:
        schema_data["version"] = schema.version

    coercion_rules_data = _load_rules(db, CoercionRuleModel, contract.coercion_rules_id)
    validation_rules_data = _load_rules(
        db, ValidationRuleModel, contract.validation_rules_id
    )

    metadata_data, ownership_data, governance_data = _collect_metadata_artifacts(
        contract,
        db,
        include_ownership=include_ownership,
        include_governance=include_governance,
    )

    field_mapping_data = None
    with suppress(NotImplementedError):
        field_mapping_data = store.get_field_mapping(contract.name, contract.version)

    artifacts = ContractArtifacts(
        schema=schema_data,
        coercion_rules=coercion_rules_data,
        validation_rules=validation_rules_data,
        metadata=metadata_data if include_metadata else None,
        ownership=ownership_data,
        governance_rules=governance_data,
        field_mapping=field_mapping_data,
    )

    try:
        return build_contract(
            artifacts,
            include_metadata=include_metadata,
            include_ownership=include_ownership,
            include_governance=include_governance,
        )
    except ValueError as exc:
        raise ContractBuildError(f"Failed to build contract: {exc}") from exc
