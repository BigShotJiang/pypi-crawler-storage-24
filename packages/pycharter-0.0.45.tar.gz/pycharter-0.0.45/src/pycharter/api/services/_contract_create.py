"""Contract creation and import logic.

Implements create-from-existing-artifacts and create-mixed flows.

NOTE: 394 lines — consider splitting before adding new functionality.
All functions raise domain exceptions -- callers map them to HTTP responses.
"""

from __future__ import annotations

import logging
import uuid
from typing import Any

from sqlalchemy.orm import Session

from pycharter.api.services.contract_validation import (
    check_contract_duplicate,
    find_artifact,
    resolve_field_mapping,
    resolve_metadata,
    resolve_rules,
    resolve_schema,
    validate_artifact_ids,
    verify_artifacts_exist,
)
from pycharter.api.utils import ensure_uuid
from pycharter.contract_store import ContractStoreClient
from pycharter.db.models import (
    CoercionRuleModel,
    DataContractModel,
    MetadataRecordModel,
    SchemaModel,
    ValidationRuleModel,
)
from pycharter.db.models.field_mapping import FieldMappingModel

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# create_from_existing_artifacts
# ---------------------------------------------------------------------------


def create_from_existing_artifacts(
    request: Any,
    db: Session,
) -> DataContractModel:
    """Create a data contract by linking to existing artifacts.

    Args:
        request: A ``ContractCreateFromArtifactsRequest`` instance.
        db: Database session.

    Returns:
        The newly created DataContractModel.

    Raises:
        ContractConflictError: If a contract with the same name+version exists.
        ArtifactNotFoundError: If a referenced artifact cannot be found.
        RuntimeError: If the database commit fails.
    """
    check_contract_duplicate(db, request.name, request.version)

    schema_id = find_artifact(
        db, SchemaModel, request.schema_title, request.schema_version, "Schema"
    )
    if schema_id is None:
        from pycharter.api.services.contract_service import ArtifactNotFoundError

        raise ArtifactNotFoundError(
            f"Schema not found: title='{request.schema_title}', "
            f"version='{request.schema_version}'"
        )

    coercion_rules_id = find_artifact(
        db,
        CoercionRuleModel,
        request.coercion_rules_title,
        request.coercion_rules_version,
        "Coercion rules",
    )
    validation_rules_id = find_artifact(
        db,
        ValidationRuleModel,
        request.validation_rules_title,
        request.validation_rules_version,
        "Validation rules",
    )
    metadata_record_id = find_artifact(
        db,
        MetadataRecordModel,
        request.metadata_title,
        request.metadata_version,
        "Metadata",
    )

    new_contract = DataContractModel(
        name=request.name,
        version=request.version,
        status=request.status or "active",
        description=request.description,
        schema_id=schema_id,
        coercion_rules_id=coercion_rules_id,
        validation_rules_id=validation_rules_id,
        metadata_record_id=metadata_record_id,
    )

    try:
        db.add(new_contract)
        db.commit()
        db.refresh(new_contract)
    except Exception as exc:
        db.rollback()
        logger.error("Error creating contract from artifacts: %s", exc, exc_info=True)
        raise RuntimeError(f"Failed to create contract: {exc}") from exc

    return new_contract


# ---------------------------------------------------------------------------
# create_mixed
# ---------------------------------------------------------------------------


def _update_contract_fields(
    new_contract: DataContractModel,
    request: Any,
    db: Session,
) -> None:
    """Update status/description on an existing contract if needed.

    Args:
        new_contract: The contract to update.
        request: Request with ``status`` and ``description`` fields.
        db: Database session.

    Raises:
        RuntimeError: If the commit fails.
    """
    needs_update = False
    if request.status and new_contract.status != request.status:
        new_contract.status = request.status
        needs_update = True
    if (
        request.description is not None
        and new_contract.description != request.description
    ):
        new_contract.description = request.description
        needs_update = True

    if needs_update:
        try:
            db.commit()
            db.refresh(new_contract)
        except Exception as exc:
            db.rollback()
            logger.error(
                "Error updating contract status/description: %s",
                exc,
                exc_info=True,
            )
            raise RuntimeError(f"Failed to update contract: {exc}") from exc


def create_mixed(
    request: Any,
    store: ContractStoreClient,
    db: Session,
) -> DataContractModel:
    """Create a data contract with a mix of new and existing artifacts.

    Args:
        request: A ``ContractCreateMixedRequest`` instance.
        store: Metadata store client.
        db: Database session.

    Returns:
        The created or updated DataContractModel.

    Raises:
        ContractConflictError: If the contract or an artifact already exists.
        ArtifactNotFoundError: If a referenced artifact cannot be found.
        ValueError: If UUID validation fails or creation fails.
        RuntimeError: If the database commit fails.
    """
    schema_id = resolve_schema(request, store, db)

    coercion_rules_id = resolve_rules(
        request.coercion_rules,
        request.coercion_rules_title,
        request.coercion_rules_version,
        request.name,
        request.version,
        store.store_coercion_rules,
        db,
        CoercionRuleModel,
        "Coercion rules",
    )
    validation_rules_id = resolve_rules(
        request.validation_rules,
        request.validation_rules_title,
        request.validation_rules_version,
        request.name,
        request.version,
        store.store_validation_rules,
        db,
        ValidationRuleModel,
        "Validation rules",
    )
    metadata_record_id = resolve_metadata(request, store, db)
    field_mapping_id = resolve_field_mapping(request, store, db)

    db.expire_all()

    new_contract = (
        db.query(DataContractModel)
        .filter(
            DataContractModel.name == request.name,
            DataContractModel.version == request.version,
        )
        .first()
    )

    if new_contract:
        _update_contract_fields(new_contract, request, db)
        return new_contract

    return _create_fallback_contract(
        request,
        schema_id,
        coercion_rules_id,
        validation_rules_id,
        metadata_record_id,
        field_mapping_id,
        db,
    )


def _create_fallback_contract(
    request: Any,
    schema_id: uuid.UUID | None,
    coercion_rules_id: uuid.UUID | None,
    validation_rules_id: uuid.UUID | None,
    metadata_record_id: uuid.UUID | None,
    field_mapping_id: uuid.UUID | None,
    db: Session,
) -> DataContractModel:
    """Create a contract when store methods did not create one automatically.

    Args:
        request: The original request.
        schema_id: Resolved schema UUID.
        coercion_rules_id: Resolved coercion rules UUID.
        validation_rules_id: Resolved validation rules UUID.
        metadata_record_id: Resolved metadata record UUID.
        field_mapping_id: Resolved concept mapping UUID.
        db: Database session.

    Returns:
        The newly created DataContractModel.

    Raises:
        ValueError: If UUID types are invalid.
        ArtifactNotFoundError: If referenced artifacts don't exist.
        RuntimeError: If the database commit fails.
    """
    logger.info(
        "Contract not found after store operations, creating new one: %s v%s",
        request.name,
        request.version,
    )

    final_ids = {
        "schema_id": ensure_uuid(schema_id) if schema_id else None,
        "coercion_rules_id": (
            ensure_uuid(coercion_rules_id) if coercion_rules_id else None
        ),
        "validation_rules_id": (
            ensure_uuid(validation_rules_id) if validation_rules_id else None
        ),
        "metadata_record_id": (
            ensure_uuid(metadata_record_id) if metadata_record_id else None
        ),
        "field_mapping_id": (
            ensure_uuid(field_mapping_id) if field_mapping_id else None
        ),
    }
    validate_artifact_ids(final_ids)

    verify_artifacts_exist(
        db,
        {
            "Schema": (SchemaModel, final_ids["schema_id"]),
            "Coercion rules": (CoercionRuleModel, final_ids["coercion_rules_id"]),
            "Validation rules": (
                ValidationRuleModel,
                final_ids["validation_rules_id"],
            ),
            "Metadata record": (
                MetadataRecordModel,
                final_ids["metadata_record_id"],
            ),
            "Field mapping": (
                FieldMappingModel,
                final_ids["field_mapping_id"],
            ),
        },
    )

    logger.debug(
        "Creating contract with IDs - schema_id type: %s, "
        "coercion_rules_id type: %s, validation_rules_id type: %s, "
        "metadata_record_id type: %s, field_mapping_id type: %s",
        type(final_ids["schema_id"]),
        type(final_ids["coercion_rules_id"]),
        type(final_ids["validation_rules_id"]),
        type(final_ids["metadata_record_id"]),
        type(final_ids["field_mapping_id"]),
    )

    # If we created artifacts via store, the data_contract row may already exist
    if request.json_schema is not None:
        existing_dc = (
            db.query(DataContractModel)
            .filter(
                DataContractModel.name == request.name,
                DataContractModel.version == request.version,
            )
            .first()
        )
        if existing_dc:
            return existing_dc

    new_contract = DataContractModel(
        name=request.name,
        version=request.version,
        status=request.status or "active",
        description=request.description,
        schema_id=final_ids["schema_id"],
        coercion_rules_id=final_ids["coercion_rules_id"],
        validation_rules_id=final_ids["validation_rules_id"],
        metadata_record_id=final_ids["metadata_record_id"],
        field_mapping_id=final_ids["field_mapping_id"],
    )

    try:
        db.add(new_contract)
        db.commit()
        db.refresh(new_contract)
    except Exception as exc:
        db.rollback()
        _handle_create_error(exc, final_ids)

    return new_contract


def _handle_create_error(
    exc: Exception,
    final_ids: dict[str, uuid.UUID | None],
) -> None:
    """Handle errors from contract creation, enriching FK messages.

    Args:
        exc: The original exception.
        final_ids: The artifact IDs that were used.

    Raises:
        RuntimeError: Always, with an enriched message.
    """
    error_msg = str(exc)
    logger.error("Error creating contract with mixed artifacts: %s", exc, exc_info=True)

    if (
        "foreign key constraint" in error_msg.lower()
        or "FOREIGN KEY constraint failed" in error_msg
    ):
        logger.error(
            "Foreign key constraint failed. IDs: schema=%s, coercion=%s, "
            "validation=%s, metadata=%s, field_mapping=%s",
            final_ids["schema_id"],
            final_ids["coercion_rules_id"],
            final_ids["validation_rules_id"],
            final_ids["metadata_record_id"],
            final_ids.get("field_mapping_id"),
        )
        raise RuntimeError(
            "Failed to create contract: One or more referenced artifacts do not "
            "exist in the database. "
            "Please verify that all artifacts exist in the current database "
            "before creating the contract. "
            f"Error: {error_msg}"
        ) from exc

    raise RuntimeError(f"Failed to create contract: {error_msg}") from exc
