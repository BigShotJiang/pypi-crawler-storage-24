"""Service layer for metadata entity CRUD and schema storage operations.

Thin re-export shim that preserves backward compatibility for
``from pycharter.api.services import metadata_service as svc``.

Implementation is split across:

- ``_metadata_helpers`` -- domain exceptions and result types.
- ``_metadata_crud`` -- schema, metadata, and rules CRUD functions.
- ``_metadata_entity_ops`` -- entity create/update/list and artifact listing.
"""

from __future__ import annotations

# Re-export schema / metadata / rules CRUD --------------------------------
from pycharter.api.services._metadata_crud import (  # noqa: F401
    get_coercion_rules,
    get_complete_schema,
    get_metadata,
    get_schema,
    get_validation_rules,
    list_coercion_functions,
    list_schemas,
    list_validation_functions,
    store_coercion_rules,
    store_metadata_record,
    store_schema,
    store_validation_rules,
)

# Re-export entity operations ---------------------------------------------
from pycharter.api.services._metadata_entity_ops import (  # noqa: F401
    create_entity,
    list_artifacts,
    list_metadata_entities,
    update_entity,
)

# Re-export exceptions and result types -----------------------------------
from pycharter.api.services._metadata_helpers import (  # noqa: F401
    DuplicateContractError,
    DuplicateEntityError,
    EntityNotFoundError,
    InvalidIdFormatError,
    InvalidVersionError,
    MetadataNotFoundError,
    RulesNotFoundError,
    SchemaListItemResult,
    SchemaNotFoundError,
    SchemaResult,
)

__all__ = [
    # Exceptions
    "DuplicateContractError",
    "DuplicateEntityError",
    "EntityNotFoundError",
    "InvalidIdFormatError",
    "InvalidVersionError",
    "MetadataNotFoundError",
    "RulesNotFoundError",
    "SchemaNotFoundError",
    # Result types
    "SchemaListItemResult",
    "SchemaResult",
    # Schema / metadata / rules CRUD
    "get_coercion_rules",
    "get_complete_schema",
    "get_metadata",
    "get_schema",
    "get_validation_rules",
    "list_coercion_functions",
    "list_schemas",
    "list_validation_functions",
    "store_coercion_rules",
    "store_metadata_record",
    "store_schema",
    "store_validation_rules",
    # Entity operations
    "create_entity",
    "list_artifacts",
    "list_metadata_entities",
    "update_entity",
]
