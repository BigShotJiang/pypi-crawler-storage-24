"""Domain exceptions, result types, and constants for metadata services.

Houses exception classes, value objects, and shared constants used by
both ``_metadata_entity_ops`` and ``_metadata_crud``.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

# ---------------------------------------------------------------------------
# Domain exceptions (no FastAPI dependency)
# ---------------------------------------------------------------------------


class DuplicateEntityError(ValueError):
    """Raised when attempting to create an entity that already exists."""


class EntityNotFoundError(LookupError):
    """Raised when a requested entity cannot be found."""


class DuplicateContractError(ValueError):
    """Raised when a schema contract with the same name+version already exists."""


class InvalidVersionError(ValueError):
    """Raised when a schema version is not higher than the latest existing version."""


class InvalidIdFormatError(ValueError):
    """Raised when an entity ID is not a valid UUID."""


class SchemaNotFoundError(LookupError):
    """Raised when a requested schema cannot be found."""


class MetadataNotFoundError(LookupError):
    """Raised when requested metadata cannot be found."""


class RulesNotFoundError(LookupError):
    """Raised when requested rules cannot be found."""


# ---------------------------------------------------------------------------
# Result types
# ---------------------------------------------------------------------------


@dataclass(frozen=True, slots=True)
class SchemaResult:
    """Result of a schema retrieval."""

    schema: dict[str, Any]
    version: str | None


@dataclass(frozen=True, slots=True)
class SchemaListItemResult:
    """Single item in a schema listing."""

    id: str
    name: str | None
    title: str | None
    version: str | None
