"""Data models for the DDL generator.

Provides immutable value objects that represent SQL table structures
derived from JSON Schema definitions with ``x-database`` extensions.
"""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass(frozen=True, slots=True)
class ColumnModel:
    """A SQL column derived from a JSON Schema property.

    Attributes:
        name: Column name (from the JSON Schema property key).
        sql_type: Resolved SQL type (e.g. ``VARCHAR(255)``, ``INTEGER``).
        nullable: Whether the column allows NULLs.
        primary_key: Column is part of the primary key.
        unique: Column has a UNIQUE constraint.
        auto_increment: Column auto-increments (SERIAL, IDENTITY, etc.).
        default: SQL DEFAULT expression, if any.
        comment: SQL column COMMENT, if any.
    """

    name: str
    sql_type: str
    nullable: bool = True
    primary_key: bool = False
    unique: bool = False
    auto_increment: bool = False
    default: str | None = None
    comment: str | None = None


@dataclass(frozen=True, slots=True)
class ForeignKeyModel:
    """A FK constraint derived from ``x-foreign-keys``.

    Attributes:
        column: Local column name.
        references_table: Target table name.
        references_column: Target column name (defaults to target PK).
    """

    column: str
    references_table: str
    references_column: str = "id"


@dataclass(frozen=True, slots=True)
class IndexModel:
    """A composite index from ``x-database-table``.

    Attributes:
        name: Index name.
        columns: Ordered list of column names.
        unique: Whether the index enforces uniqueness.
    """

    name: str
    columns: tuple[str, ...]
    unique: bool = False


@dataclass(frozen=True, slots=True)
class TableModel:
    """Complete table representation derived from a JSON Schema.

    Attributes:
        name: Table name.
        schema_name: Database schema (e.g. ``public``).
        columns: Ordered list of columns.
        foreign_keys: FK constraints.
        indexes: Composite indexes.
        comment: Table-level COMMENT.
        engine: Database engine hint (e.g. ``InnoDB``).
    """

    name: str
    schema_name: str = "public"
    columns: tuple[ColumnModel, ...] = ()
    foreign_keys: tuple[ForeignKeyModel, ...] = ()
    indexes: tuple[IndexModel, ...] = ()
    comment: str | None = None
    engine: str | None = None


@dataclass(frozen=True, slots=True)
class DdlResult:
    """Result of DDL generation for one or more tables.

    Attributes:
        sql: The full DDL SQL string.
        tables: Parsed table models used to generate the SQL.
    """

    sql: str
    tables: tuple[TableModel, ...] = field(default_factory=tuple)
