"""DDL generator — convert JSON Schema to SQL DDL.

Reads a JSON Schema (with optional ``x-database`` and ``x-database-table``
extensions) and generates SQL DDL statements for creating tables.

Usage::

    from pycharter.ddl_generator import schema_to_ddl

    schema = {
        "type": "object",
        "title": "customers",
        "properties": {
            "id": {
                "type": "integer",
                "x-database": {"primary_key": True, "auto_increment": True},
            },
            "email": {
                "type": "string",
                "format": "email",
                "maxLength": 255,
                "x-database": {"unique": True},
            },
        },
        "required": ["id", "email"],
    }

    ddl = schema_to_ddl(schema, dialect="postgresql")
    print(ddl)
"""

from __future__ import annotations

from typing import Any

from pycharter.ddl_generator._parser import (
    schema_to_table_model,
    schema_to_table_models,
)
from pycharter.ddl_generator._renderer import render_ddl
from pycharter.ddl_generator._type_map import SUPPORTED_DIALECTS
from pycharter.ddl_generator._types import (
    ColumnModel,
    DdlResult,
    ForeignKeyModel,
    IndexModel,
    TableModel,
)


def schema_to_ddl(
    schema: dict[str, Any],
    *,
    dialect: str = "postgresql",
    if_not_exists: bool = True,
) -> str:
    """Generate SQL DDL from a JSON Schema.

    Parses the schema (including ``$defs``) into table models and renders
    them as a SQL DDL script.

    Args:
        schema: A JSON Schema dict with ``type: "object"`` and ``properties``.
        dialect: Target SQL dialect (``postgresql``, ``mysql``, ``sqlite``).
        if_not_exists: Emit ``IF NOT EXISTS`` in CREATE TABLE statements.

    Returns:
        A SQL DDL string with CREATE TABLE and CREATE INDEX statements.

    Raises:
        ValueError: If the schema is invalid or has no properties.
    """
    tables = schema_to_table_models(schema, dialect=dialect)
    return render_ddl(tables, dialect=dialect, if_not_exists=if_not_exists)


def schema_to_ddl_result(
    schema: dict[str, Any],
    *,
    dialect: str = "postgresql",
    if_not_exists: bool = True,
) -> DdlResult:
    """Generate DDL with structured table models.

    Like ``schema_to_ddl`` but also returns the parsed ``TableModel``
    objects for programmatic inspection.

    Args:
        schema: A JSON Schema dict.
        dialect: Target SQL dialect.
        if_not_exists: Emit ``IF NOT EXISTS`` in CREATE TABLE statements.

    Returns:
        A ``DdlResult`` containing both the SQL string and table models.
    """
    tables = schema_to_table_models(schema, dialect=dialect)
    sql = render_ddl(tables, dialect=dialect, if_not_exists=if_not_exists)
    return DdlResult(sql=sql, tables=tuple(tables))


__all__ = [
    "SUPPORTED_DIALECTS",
    "ColumnModel",
    "DdlResult",
    "ForeignKeyModel",
    "IndexModel",
    "TableModel",
    "schema_to_ddl",
    "schema_to_ddl_result",
    "schema_to_table_model",
    "schema_to_table_models",
]
