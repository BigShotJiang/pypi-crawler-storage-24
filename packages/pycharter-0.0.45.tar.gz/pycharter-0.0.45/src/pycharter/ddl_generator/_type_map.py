"""JSON Schema to SQL type mapping tables.

Each supported SQL dialect has a mapping from ``(json_type, format)``
pairs to concrete SQL column types.  The ``resolve_sql_type`` function
selects the correct type, respecting explicit ``x-database.sql_type``
overrides.
"""

from __future__ import annotations

from typing import Any

# ── Dialect-specific type maps ──────────────────────────────────────────

# Keys: (json_schema_type, format_or_None)
# Values: SQL type string

_POSTGRESQL_TYPES: dict[tuple[str, str | None], str] = {
    ("string", None): "TEXT",
    ("string", "email"): "VARCHAR(255)",
    ("string", "uri"): "TEXT",
    ("string", "uuid"): "UUID",
    ("string", "date"): "DATE",
    ("string", "date-time"): "TIMESTAMP",
    ("string", "time"): "TIME",
    ("integer", None): "INTEGER",
    ("number", None): "DOUBLE PRECISION",
    ("boolean", None): "BOOLEAN",
    ("array", None): "JSONB",
    ("object", None): "JSONB",
}

_MYSQL_TYPES: dict[tuple[str, str | None], str] = {
    ("string", None): "TEXT",
    ("string", "email"): "VARCHAR(255)",
    ("string", "uri"): "TEXT",
    ("string", "uuid"): "CHAR(36)",
    ("string", "date"): "DATE",
    ("string", "date-time"): "DATETIME",
    ("string", "time"): "TIME",
    ("integer", None): "INT",
    ("number", None): "DOUBLE",
    ("boolean", None): "TINYINT(1)",
    ("array", None): "JSON",
    ("object", None): "JSON",
}

_SQLITE_TYPES: dict[tuple[str, str | None], str] = {
    ("string", None): "TEXT",
    ("string", "email"): "TEXT",
    ("string", "uri"): "TEXT",
    ("string", "uuid"): "TEXT",
    ("string", "date"): "TEXT",
    ("string", "date-time"): "TEXT",
    ("string", "time"): "TEXT",
    ("integer", None): "INTEGER",
    ("number", None): "REAL",
    ("boolean", None): "INTEGER",
    ("array", None): "TEXT",
    ("object", None): "TEXT",
}

_DIALECT_MAP: dict[str, dict[tuple[str, str | None], str]] = {
    "postgresql": _POSTGRESQL_TYPES,
    "mysql": _MYSQL_TYPES,
    "sqlite": _SQLITE_TYPES,
}

SUPPORTED_DIALECTS: tuple[str, ...] = tuple(_DIALECT_MAP.keys())

# Auto-increment type overrides per dialect.
_AUTO_INCREMENT_TYPES: dict[str, str] = {
    "postgresql": "SERIAL",
    "mysql": "INT AUTO_INCREMENT",
    "sqlite": "INTEGER",  # SQLite auto-increments INTEGER PRIMARY KEY
}


def resolve_sql_type(
    json_type: str,
    *,
    fmt: str | None = None,
    max_length: int | None = None,
    db_ext: dict[str, Any] | None = None,
    dialect: str = "postgresql",
) -> str:
    """Resolve a JSON Schema type to a concrete SQL column type.

    Args:
        json_type: JSON Schema ``type`` value (e.g. ``"string"``).
        fmt: JSON Schema ``format`` value, if present.
        max_length: JSON Schema ``maxLength``, if present.
        db_ext: The ``x-database`` extension object for this property.
        dialect: Target SQL dialect.

    Returns:
        A SQL type string (e.g. ``"VARCHAR(255)"``).
    """
    ext = db_ext or {}

    # Explicit override takes precedence.
    explicit: str | None = ext.get("sql_type")
    if explicit:
        return explicit

    # Auto-increment override.
    if ext.get("auto_increment"):
        return _AUTO_INCREMENT_TYPES.get(dialect, "INTEGER")

    type_map = _DIALECT_MAP.get(dialect, _POSTGRESQL_TYPES)

    # String with maxLength → VARCHAR(N).
    if json_type == "string" and max_length is not None:
        return f"VARCHAR({max_length})"

    # Look up (type, format) first, then (type, None) as fallback.
    sql_type = type_map.get((json_type, fmt))
    if sql_type is None:
        sql_type = type_map.get((json_type, None), "TEXT")

    return sql_type
