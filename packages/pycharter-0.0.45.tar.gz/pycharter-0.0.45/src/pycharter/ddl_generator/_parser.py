"""Parse JSON Schema into table models.

Reads a JSON Schema dict (with optional ``x-database`` and
``x-database-table`` extensions) and produces ``TableModel`` objects
that represent the SQL structure.
"""

from __future__ import annotations

import logging
import re
from typing import Any

from pycharter.ddl_generator._type_map import resolve_sql_type
from pycharter.ddl_generator._types import (
    ColumnModel,
    ForeignKeyModel,
    IndexModel,
    TableModel,
)

logger = logging.getLogger(__name__)

_X_DATABASE = "x-database"
_X_DATABASE_TABLE = "x-database-table"
_X_FOREIGN_KEYS = "x-foreign-keys"


def _to_snake(name: str) -> str:
    """Convert a title to snake_case for table naming."""
    s1 = re.sub(r"([A-Z]+)([A-Z][a-z])", r"\1_\2", name)
    s2 = re.sub(r"([a-z0-9])([A-Z])", r"\1_\2", s1)
    return re.sub(r"[\s\-]+", "_", s2).lower()


def schema_to_table_model(
    schema: dict[str, Any],
    *,
    dialect: str = "postgresql",
) -> TableModel:
    """Parse a single JSON Schema object into a ``TableModel``.

    Args:
        schema: A JSON Schema dict with ``type: "object"`` and ``properties``.
        dialect: Target SQL dialect for type resolution.

    Returns:
        A ``TableModel`` representing the SQL table.

    Raises:
        ValueError: If the schema is not an object type or has no properties.
    """
    schema_type = schema.get("type", "object")
    if schema_type != "object":
        msg = f"Expected JSON Schema type 'object', got '{schema_type}'"
        raise ValueError(msg)

    properties: dict[str, Any] = schema.get("properties", {})
    if not properties:
        msg = "JSON Schema has no properties"
        raise ValueError(msg)

    required_fields: set[str] = set(schema.get("required", []))

    # Table-level metadata.
    table_ext: dict[str, Any] = schema.get(_X_DATABASE_TABLE, {})
    table_name = table_ext.get("table_name") or _to_snake(
        schema.get("title", "unnamed_table")
    )
    schema_name = table_ext.get("schema", "public")
    engine = table_ext.get("engine")
    table_comment = table_ext.get("comment")

    # Parse columns.
    columns: list[ColumnModel] = []
    for prop_name, prop_def in properties.items():
        col = _parse_column(
            prop_name,
            prop_def,
            required=prop_name in required_fields,
            dialect=dialect,
        )
        columns.append(col)

    # Parse foreign keys.
    fk_list: list[ForeignKeyModel] = _parse_foreign_keys(
        schema.get(_X_FOREIGN_KEYS, [])
    )

    # Parse composite indexes.
    idx_list: list[IndexModel] = _parse_indexes(table_ext.get("indexes", []))

    return TableModel(
        name=table_name,
        schema_name=schema_name,
        columns=tuple(columns),
        foreign_keys=tuple(fk_list),
        indexes=tuple(idx_list),
        comment=table_comment,
        engine=engine,
    )


def schema_to_table_models(
    schema: dict[str, Any],
    *,
    dialect: str = "postgresql",
) -> list[TableModel]:
    """Parse a JSON Schema with ``$defs`` into multiple ``TableModel`` objects.

    The root schema becomes the primary table. Each entry in ``$defs``
    that has ``type: "object"`` becomes an additional table.

    Args:
        schema: A JSON Schema dict, possibly containing ``$defs``.
        dialect: Target SQL dialect.

    Returns:
        A list of ``TableModel`` objects.
    """
    tables: list[TableModel] = [
        schema_to_table_model(schema, dialect=dialect),
    ]

    defs: dict[str, Any] = schema.get("$defs", {})
    for def_name, def_schema in defs.items():
        if not isinstance(def_schema, dict):
            continue
        if def_schema.get("type") != "object":
            continue
        if not def_schema.get("properties"):
            continue

        # Use the def name as fallback title.
        if "title" not in def_schema:
            def_schema = {**def_schema, "title": def_name}

        tables.append(schema_to_table_model(def_schema, dialect=dialect))

    return tables


# ── Internals ───────────────────────────────────────────────────────────


def _parse_column(
    name: str,
    prop_def: dict[str, Any],
    *,
    required: bool,
    dialect: str,
) -> ColumnModel:
    """Parse a single JSON Schema property into a ``ColumnModel``."""
    json_type = prop_def.get("type", "string")
    fmt = prop_def.get("format")
    max_length: int | None = prop_def.get("maxLength")
    db_ext: dict[str, Any] = prop_def.get(_X_DATABASE, {})

    sql_type = resolve_sql_type(
        json_type,
        fmt=fmt,
        max_length=max_length,
        db_ext=db_ext,
        dialect=dialect,
    )

    is_pk = db_ext.get("primary_key", False)
    is_auto = db_ext.get("auto_increment", False)

    # PK columns are implicitly NOT NULL.
    nullable = not required and not is_pk

    # JSON Schema `default` → SQL DEFAULT (only for simple literal values).
    json_default = prop_def.get("default")
    sql_default = db_ext.get("default")
    if sql_default is None and json_default is not None:
        sql_default = _json_default_to_sql(json_default)

    return ColumnModel(
        name=name,
        sql_type=sql_type,
        nullable=nullable,
        primary_key=is_pk,
        unique=db_ext.get("unique", False),
        auto_increment=is_auto,
        default=sql_default,
        comment=db_ext.get("comment"),
    )


def _parse_foreign_keys(
    fk_entries: list[dict[str, Any]],
) -> list[ForeignKeyModel]:
    """Parse ``x-foreign-keys`` entries into ``ForeignKeyModel`` objects."""
    result: list[ForeignKeyModel] = []
    for entry in fk_entries:
        field_name = entry.get("field")
        refs = entry.get("references", {})
        ref_schema = refs.get("schema")
        if not field_name or not ref_schema:
            logger.warning("skipping malformed x-foreign-keys entry: %s", entry)
            continue
        ref_column = refs.get("column", "id")
        result.append(
            ForeignKeyModel(
                column=field_name,
                references_table=_to_snake(ref_schema),
                references_column=ref_column,
            )
        )
    return result


def _parse_indexes(
    index_entries: list[dict[str, Any]],
) -> list[IndexModel]:
    """Parse composite index definitions from ``x-database-table.indexes``."""
    result: list[IndexModel] = []
    for entry in index_entries:
        cols = entry.get("columns", [])
        if not cols:
            continue
        name = entry.get("name", f"idx_{'_'.join(cols)}")
        unique = entry.get("unique", False)
        result.append(IndexModel(name=name, columns=tuple(cols), unique=unique))
    return result


def _json_default_to_sql(value: Any) -> str | None:
    """Convert a JSON Schema default value to a SQL DEFAULT expression."""
    if isinstance(value, bool):
        return "TRUE" if value else "FALSE"
    if isinstance(value, int | float):
        return str(value)
    if isinstance(value, str):
        return f"'{value}'"
    return None
