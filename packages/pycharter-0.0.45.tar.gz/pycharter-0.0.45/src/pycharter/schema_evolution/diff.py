"""Schema Evolution Diff - Compute differences between schemas.

Re-export shim -- the actual definitions live in:
- ``_diff_engine`` (compute_diff and comparison functions)
- ``_diff_formatters`` (constraint and default-value helpers)

All public names are re-exported here so that existing
``from pycharter.schema_evolution.diff import X`` imports
continue to work unchanged.
"""

from __future__ import annotations

from pycharter.schema_evolution._diff_engine import compute_diff

__all__ = [
    "compute_diff",
]
