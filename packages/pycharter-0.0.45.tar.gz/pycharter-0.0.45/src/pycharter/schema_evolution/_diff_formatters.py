"""Constraint and default-value comparison helpers for schema diff.

Provides functions to compare numeric/string constraints and default
values between JSON Schema versions, including breaking-change analysis.
"""

from __future__ import annotations

from typing import Any

from pycharter.schema_evolution.models import ChangeType, SchemaChange


def _compare_constraints(
    old_schema: dict[str, Any],
    new_schema: dict[str, Any],
    path: str,
) -> list[SchemaChange]:
    """Compare numeric and string constraints."""
    changes: list[SchemaChange] = []

    constraint_keys = [
        "minimum",
        "maximum",
        "exclusiveMinimum",
        "exclusiveMaximum",
        "minLength",
        "maxLength",
        "minItems",
        "maxItems",
        "minProperties",
        "maxProperties",
        "multipleOf",
        "uniqueItems",
    ]

    for key in constraint_keys:
        old_val = old_schema.get(key)
        new_val = new_schema.get(key)

        if old_val != new_val:
            if old_val is None and new_val is not None:
                # Constraint added (may be breaking)
                breaking = _is_constraint_addition_breaking(key, new_val)
                changes.append(
                    SchemaChange(
                        path=f"{path}.{key}",
                        change_type=ChangeType.CONSTRAINT_ADDED,
                        old_value=None,
                        new_value=new_val,
                        breaking=breaking,
                        message=f"Constraint '{key}' added with value {new_val}",
                    )
                )
            elif old_val is not None and new_val is None:
                # Constraint removed (not breaking)
                changes.append(
                    SchemaChange(
                        path=f"{path}.{key}",
                        change_type=ChangeType.CONSTRAINT_REMOVED,
                        old_value=old_val,
                        new_value=None,
                        breaking=False,
                        message=f"Constraint '{key}' removed",
                    )
                )
            else:
                # Constraint modified
                breaking = _is_constraint_modification_breaking(key, old_val, new_val)
                changes.append(
                    SchemaChange(
                        path=f"{path}.{key}",
                        change_type=ChangeType.CONSTRAINT_MODIFIED,
                        old_value=old_val,
                        new_value=new_val,
                        breaking=breaking,
                        message=f"Constraint '{key}' changed from {old_val} to {new_val}",
                    )
                )

    return changes


def _compare_default(
    old_schema: dict[str, Any],
    new_schema: dict[str, Any],
    path: str,
) -> list[SchemaChange]:
    """Compare default values."""
    changes: list[SchemaChange] = []

    old_default = old_schema.get("default")
    new_default = new_schema.get("default")

    has_old = "default" in old_schema
    has_new = "default" in new_schema

    if has_old != has_new or old_default != new_default:
        if not has_old and has_new:
            changes.append(
                SchemaChange(
                    path=f"{path}.default",
                    change_type=ChangeType.DEFAULT_ADDED,
                    old_value=None,
                    new_value=new_default,
                    breaking=False,
                    message=f"Default value '{new_default}' added",
                )
            )
        elif has_old and not has_new:
            changes.append(
                SchemaChange(
                    path=f"{path}.default",
                    change_type=ChangeType.DEFAULT_REMOVED,
                    old_value=old_default,
                    new_value=None,
                    breaking=False,
                    message=f"Default value '{old_default}' removed",
                )
            )
        elif old_default != new_default:
            changes.append(
                SchemaChange(
                    path=f"{path}.default",
                    change_type=ChangeType.DEFAULT_CHANGED,
                    old_value=old_default,
                    new_value=new_default,
                    breaking=False,
                    message=f"Default value changed from '{old_default}' to '{new_default}'",
                )
            )

    return changes


def _is_constraint_addition_breaking(key: str, value: Any) -> bool:
    """Determine if adding a constraint is breaking."""
    # Adding minimum/maximum constraints is breaking
    # Adding length constraints is breaking
    return True


def _is_constraint_modification_breaking(key: str, old_val: Any, new_val: Any) -> bool:
    """Determine if modifying a constraint is breaking."""
    # For min* constraints: increasing is breaking
    # For max* constraints: decreasing is breaking

    if key.startswith("min"):
        return new_val > old_val
    elif key.startswith("max"):
        return new_val < old_val
    elif key == "uniqueItems":
        return new_val and not old_val  # Adding uniqueItems is breaking

    return True
