"""Core diff computation between JSON Schema versions.

Contains the main ``compute_diff`` entry point and helpers for
comparing properties, required fields, items, and enum values.
"""

from __future__ import annotations

from typing import Any

from pycharter.schema_evolution._diff_formatters import (
    _compare_constraints,
    _compare_default,
)
from pycharter.schema_evolution.models import ChangeType, SchemaChange, SchemaDiff


def compute_diff(
    old_schema: dict[str, Any],
    new_schema: dict[str, Any],
    path: str = "",
) -> SchemaDiff:
    """Compute detailed diff between two JSON Schema versions.

    Args:
        old_schema: Original schema.
        new_schema: New schema.
        path: Current path (for nested comparison).

    Returns:
        SchemaDiff with all detected changes.
    """
    changes: list[SchemaChange] = []

    # Compare top-level attributes
    changes.extend(_compare_attributes(old_schema, new_schema, path))

    # Compare properties
    if "properties" in old_schema or "properties" in new_schema:
        changes.extend(
            _compare_properties(
                old_schema.get("properties", {}),
                new_schema.get("properties", {}),
                f"{path}.properties" if path else "properties",
            )
        )

    # Compare required fields
    changes.extend(
        _compare_required(
            old_schema.get("required", []),
            new_schema.get("required", []),
            f"{path}.required" if path else "required",
        )
    )

    # Compare items (for arrays)
    if "items" in old_schema or "items" in new_schema:
        changes.extend(
            _compare_items(
                old_schema.get("items"),
                new_schema.get("items"),
                f"{path}.items" if path else "items",
            )
        )

    return SchemaDiff(changes=changes)


def _compare_attributes(
    old_schema: dict[str, Any],
    new_schema: dict[str, Any],
    path: str,
) -> list[SchemaChange]:
    """Compare top-level schema attributes."""
    changes: list[SchemaChange] = []

    # Type changes
    old_type = old_schema.get("type")
    new_type = new_schema.get("type")
    if old_type != new_type:
        change_type, breaking = _analyze_type_change(old_type, new_type)
        changes.append(
            SchemaChange(
                path=f"{path}.type" if path else "type",
                change_type=change_type,
                old_value=old_type,
                new_value=new_type,
                breaking=breaking,
                message=f"Type changed from '{old_type}' to '{new_type}'",
            )
        )

    # Format changes
    if old_schema.get("format") != new_schema.get("format"):
        changes.append(
            SchemaChange(
                path=f"{path}.format" if path else "format",
                change_type=ChangeType.FORMAT_CHANGED,
                old_value=old_schema.get("format"),
                new_value=new_schema.get("format"),
                breaking=True,  # Format changes are typically breaking
                message=(
                    f"Format changed from '{old_schema.get('format')}' "
                    f"to '{new_schema.get('format')}'"
                ),
            )
        )

    # Pattern changes
    if old_schema.get("pattern") != new_schema.get("pattern"):
        changes.append(
            SchemaChange(
                path=f"{path}.pattern" if path else "pattern",
                change_type=ChangeType.PATTERN_CHANGED,
                old_value=old_schema.get("pattern"),
                new_value=new_schema.get("pattern"),
                breaking=True,  # Pattern changes are typically breaking
                message="Pattern constraint changed",
            )
        )

    # Enum changes
    changes.extend(_compare_enum(old_schema, new_schema, path))

    # Constraint changes
    changes.extend(_compare_constraints(old_schema, new_schema, path))

    # Default value changes
    changes.extend(_compare_default(old_schema, new_schema, path))

    # Description changes (non-breaking)
    if old_schema.get("description") != new_schema.get("description"):
        changes.append(
            SchemaChange(
                path=f"{path}.description" if path else "description",
                change_type=ChangeType.DESCRIPTION_CHANGED,
                old_value=old_schema.get("description"),
                new_value=new_schema.get("description"),
                breaking=False,
                message="Description changed",
            )
        )

    # Title changes (non-breaking)
    if old_schema.get("title") != new_schema.get("title"):
        changes.append(
            SchemaChange(
                path=f"{path}.title" if path else "title",
                change_type=ChangeType.TITLE_CHANGED,
                old_value=old_schema.get("title"),
                new_value=new_schema.get("title"),
                breaking=False,
                message="Title changed",
            )
        )

    return changes


def _compare_properties(
    old_props: dict[str, Any],
    new_props: dict[str, Any],
    path: str,
) -> list[SchemaChange]:
    """Compare properties between schemas."""
    changes: list[SchemaChange] = []

    old_keys = set(old_props.keys())
    new_keys = set(new_props.keys())

    # Added properties
    for key in new_keys - old_keys:
        changes.append(
            SchemaChange(
                path=f"{path}.{key}",
                change_type=ChangeType.FIELD_ADDED,
                old_value=None,
                new_value=new_props[key],
                breaking=False,  # Adding optional fields is not breaking
                message=f"Field '{key}' added",
            )
        )

    # Removed properties
    for key in old_keys - new_keys:
        changes.append(
            SchemaChange(
                path=f"{path}.{key}",
                change_type=ChangeType.FIELD_REMOVED,
                old_value=old_props[key],
                new_value=None,
                breaking=False,  # Removing fields is backward compatible
                message=f"Field '{key}' removed",
            )
        )

    # Modified properties (recursively)
    for key in old_keys & new_keys:
        nested_diff = compute_diff(old_props[key], new_props[key], f"{path}.{key}")
        changes.extend(nested_diff.changes)

    return changes


def _compare_required(
    old_required: list[str],
    new_required: list[str],
    path: str,
) -> list[SchemaChange]:
    """Compare required fields."""
    changes: list[SchemaChange] = []

    old_set = set(old_required)
    new_set = set(new_required)

    # Newly required fields (breaking for backward compatibility)
    for field in new_set - old_set:
        changes.append(
            SchemaChange(
                path=f"{path}.{field}",
                change_type=ChangeType.REQUIRED_ADDED,
                old_value=None,
                new_value=field,
                breaking=True,  # Adding required is breaking
                message=f"Field '{field}' is now required",
            )
        )

    # No longer required fields (not breaking)
    for field in old_set - new_set:
        changes.append(
            SchemaChange(
                path=f"{path}.{field}",
                change_type=ChangeType.REQUIRED_REMOVED,
                old_value=field,
                new_value=None,
                breaking=False,  # Removing required is not breaking
                message=f"Field '{field}' is no longer required",
            )
        )

    return changes


def _compare_items(
    old_items: dict[str, Any] | None,
    new_items: dict[str, Any] | None,
    path: str,
) -> list[SchemaChange]:
    """Compare array items schema."""
    changes: list[SchemaChange] = []

    if old_items is None and new_items is not None:
        changes.append(
            SchemaChange(
                path=path,
                change_type=ChangeType.CONSTRAINT_ADDED,
                old_value=None,
                new_value=new_items,
                breaking=True,
                message="Array items schema added",
            )
        )
    elif old_items is not None and new_items is None:
        changes.append(
            SchemaChange(
                path=path,
                change_type=ChangeType.CONSTRAINT_REMOVED,
                old_value=old_items,
                new_value=None,
                breaking=False,
                message="Array items schema removed",
            )
        )
    elif old_items is not None and new_items is not None:
        nested_diff = compute_diff(old_items, new_items, path)
        changes.extend(nested_diff.changes)

    return changes


def _compare_enum(
    old_schema: dict[str, Any],
    new_schema: dict[str, Any],
    path: str,
) -> list[SchemaChange]:
    """Compare enum values."""
    changes: list[SchemaChange] = []

    old_enum = set(old_schema.get("enum", []) or [])
    new_enum = set(new_schema.get("enum", []) or [])

    if not old_enum and not new_enum:
        return changes

    # Added enum values (not breaking)
    for value in new_enum - old_enum:
        changes.append(
            SchemaChange(
                path=f"{path}.enum",
                change_type=ChangeType.ENUM_VALUE_ADDED,
                old_value=None,
                new_value=value,
                breaking=False,
                message=f"Enum value '{value}' added",
            )
        )

    # Removed enum values (breaking)
    for value in old_enum - new_enum:
        changes.append(
            SchemaChange(
                path=f"{path}.enum",
                change_type=ChangeType.ENUM_VALUE_REMOVED,
                old_value=value,
                new_value=None,
                breaking=True,
                message=f"Enum value '{value}' removed",
            )
        )

    return changes


def _analyze_type_change(
    old_type: str | None, new_type: str | None
) -> tuple[ChangeType, bool]:
    """Analyze a type change and determine if it's breaking.

    Returns:
        Tuple of (ChangeType, is_breaking).
    """
    # Type widening (not breaking for backward compatibility)
    widening = {
        ("integer", "number"),
        ("int", "number"),
        ("null", "string"),
        ("null", "integer"),
        ("null", "number"),
    }

    # Type narrowing (breaking)
    narrowing = {
        ("number", "integer"),
        ("number", "int"),
        ("string", "null"),
        ("integer", "null"),
        ("number", "null"),
    }

    pair = (old_type, new_type)

    if pair in widening:
        return ChangeType.TYPE_WIDENED, False
    elif pair in narrowing:
        return ChangeType.TYPE_NARROWED, True
    else:
        return ChangeType.TYPE_CHANGED, True
