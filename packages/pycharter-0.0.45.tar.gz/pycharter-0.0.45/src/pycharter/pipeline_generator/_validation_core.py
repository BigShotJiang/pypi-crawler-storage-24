"""Core ETL validation logic.

Provides the ETLValidator class and ETLValidationError for validating data
records against schemas/contracts with configurable error handling and DLQ
support.
"""

from __future__ import annotations

import logging
from typing import Any

from pycharter.pipeline_generator.config_models import OnErrorAction
from pycharter.pipeline_generator.dlq import DeadLetterQueue, DLQReason
from pycharter.quality.violations import ViolationTracker
from pycharter.runtime_validator import Validator
from pycharter.runtime_validator.validator_core import ValidationResult

logger = logging.getLogger(__name__)


class ETLValidationError(Exception):
    """Raised when validation fails with on_error=fail."""

    def __init__(
        self,
        message: str,
        invalid_count: int = 0,
        errors: list[str] | None = None,
    ):
        super().__init__(message)
        self.invalid_count = invalid_count
        self.errors = errors or []


class ETLValidator:
    """Validates data in ETL pipelines with configurable error handling.

    Supports:
    - Source validation (after extract) against a schema file
    - Target validation (before load) against a data contract
    - Error handling modes: fail, warn, skip, quarantine
    - DLQ integration for quarantining invalid records

    Example:
        >>> validator = ETLValidator(
        ...     schema_or_contract={"type": "object", "properties": {...}},
        ...     on_error=OnErrorAction.QUARANTINE,
        ...     dlq=dlq_instance,
        ...     pipeline_name="orders_pipeline",
        ...     stage="extract",
        ... )
        >>> valid, invalid, error_count = await validator.validate(data)
    """

    def __init__(
        self,
        schema_or_contract: dict[str, Any],
        on_error: OnErrorAction = OnErrorAction.FAIL,
        dlq: DeadLetterQueue | None = None,
        pipeline_name: str = "",
        stage: str = "",
        violation_tracker: ViolationTracker | None = None,
        schema_id: str | None = None,
    ):
        """Initialize the ETL validator.

        Args:
            schema_or_contract: JSON Schema dict or complete contract dict.
            on_error: Action on validation error (fail, warn, skip, quarantine).
            dlq: Optional DeadLetterQueue instance for quarantine mode.
            pipeline_name: Name of the pipeline (for DLQ metadata).
            stage: ETL stage (extract or load) for DLQ metadata.
            violation_tracker: Optional tracker for recording quality violations.
            schema_id: Optional schema identifier for violation tracking.
        """
        self.on_error = on_error
        self.dlq = dlq
        self.pipeline_name = pipeline_name
        self.stage = stage
        self.violation_tracker = violation_tracker
        self.schema_id = schema_id

        # Initialize the underlying Validator
        # If it's a full contract (has 'json_schema' or 'schema' key), load as contract_dict
        # Otherwise treat it as a schema directly
        schema = schema_or_contract.get("json_schema") or schema_or_contract.get(
            "schema"
        )
        if schema is not None and isinstance(schema, dict):
            # Ensure schema has version (required by Validator)
            if "version" not in schema:
                schema = {**schema, "version": "1.0.0"}
            contract_dict = dict(schema_or_contract)
            contract_dict["json_schema"] = schema
            if "schema" in contract_dict:
                del contract_dict["schema"]
            self._validator = Validator(contract_dict=contract_dict)
        else:
            # It's a schema, wrap it in contract format
            if "version" not in schema_or_contract:
                schema_or_contract = {**schema_or_contract, "version": "1.0.0"}
            self._validator = Validator(
                contract_dict={"json_schema": schema_or_contract}
            )

    async def validate(
        self,
        data: list[dict[str, Any]],
        run_id: str = "",
    ) -> tuple[list[dict[str, Any]], list[dict[str, Any]], int | None]:
        """Validate a batch of data records.

        Args:
            data: List of data records to validate.
            run_id: Optional run identifier for DLQ metadata.

        Returns:
            Tuple of (valid_records, quarantined_records, error_count).

        Raises:
            ETLValidationError: If on_error=fail and validation fails.
        """
        if not data:
            return [], [], 0

        valid_records: list[dict[str, Any]] = []
        invalid_records: list[dict[str, Any]] = []
        all_errors: list[str] = []

        # Validate each record
        results = self._validator.validate_batch(data, strict=False)

        for record, result in zip(data, results, strict=True):
            if result.is_valid:
                # Return the original dict, not the Pydantic model
                valid_records.append(record)
            else:
                invalid_records.append(
                    {
                        "record": record,
                        "errors": result.errors,
                    }
                )
                all_errors.extend(result.errors)

        error_count = len(invalid_records)

        # Handle based on on_error setting
        if invalid_records:
            return await self._handle_invalid(
                data, valid_records, invalid_records, all_errors, error_count, run_id
            )

        return valid_records, [], 0

    async def _handle_invalid(
        self,
        data: list[dict[str, Any]],
        valid_records: list[dict[str, Any]],
        invalid_records: list[dict[str, Any]],
        all_errors: list[str],
        error_count: int,
        run_id: str,
    ) -> tuple[list[dict[str, Any]], list[dict[str, Any]], int]:
        """Route invalid records based on the on_error setting."""
        if self.on_error == OnErrorAction.FAIL:
            raise ETLValidationError(
                f"Validation failed: {error_count} record(s) invalid",
                invalid_count=error_count,
                errors=all_errors[:10],  # Limit errors in exception
            )

        if self.on_error == OnErrorAction.WARN:
            logger.warning(
                "[%s] Validation warning: %s record(s) invalid in %s stage",
                self.pipeline_name,
                error_count,
                self.stage,
            )
            # Return all records (including invalid) for warn mode
            return data, [], error_count

        if self.on_error == OnErrorAction.SKIP:
            logger.info(
                "[%s] Skipping %s invalid record(s) in %s stage",
                self.pipeline_name,
                error_count,
                self.stage,
            )
            # Return only valid records, no quarantine
            return valid_records, [], error_count

        if self.on_error == OnErrorAction.QUARANTINE:
            logger.info(
                "[%s] Quarantining %s invalid record(s) in %s stage",
                self.pipeline_name,
                error_count,
                self.stage,
            )
            # Send to DLQ if configured
            if self.dlq:
                await self._send_to_dlq(invalid_records, run_id)
            # Return valid records, quarantined records
            return (
                valid_records,
                [item["record"] for item in invalid_records],
                error_count,
            )

        return valid_records, [], error_count

    async def _send_to_dlq(
        self,
        invalid_records: list[dict[str, Any]],
        run_id: str = "",
    ) -> None:
        """Send invalid records to the Dead Letter Queue.

        When a violation tracker is available, also creates violation records
        and links their IDs to the DLQ entry metadata.
        """
        reason = (
            DLQReason.SCHEMA_MISMATCH
            if self.stage == "extract"
            else DLQReason.VALIDATION_ERROR
        )

        for item in invalid_records:
            violation_ids: list[str] = []

            # Create violation record when tracker is available
            if self.violation_tracker and self.schema_id:
                validation_result = ValidationResult(
                    is_valid=False,
                    errors=item["errors"],
                    data=None,
                )
                violation = self.violation_tracker.record_violation(
                    schema_id=self.schema_id,
                    record_id=None,
                    record_data=item["record"],
                    validation_result=validation_result,
                    severity="critical",
                )
                violation_ids.append(str(violation.id))

            await self.dlq.add_record(
                pipeline_name=self.pipeline_name,
                record_data=item["record"],
                reason=reason,
                error_message="; ".join(
                    item["errors"][:5]
                ),  # Limit error message length
                error_type="ValidationError",
                stage=self.stage,
                metadata={
                    "run_id": run_id,
                    "error_count": len(item["errors"]),
                    "validation_errors": item["errors"][:10],
                    "violation_ids": violation_ids,
                },
            )
