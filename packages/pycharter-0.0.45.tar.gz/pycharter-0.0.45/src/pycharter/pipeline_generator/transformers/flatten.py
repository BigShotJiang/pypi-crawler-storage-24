"""Flatten transformer for nested dict fields.

Turns nested dicts into flat dot-notation keys.  For example::

    {"info": {"carrier": "LH", "status": {"code": "ARR"}}}

becomes::

    {"info.carrier": "LH", "info.status.code": "ARR"}
"""

from __future__ import annotations

import logging
from typing import Any

from pycharter.pipeline_generator.transformers.base import BaseTransformer

logger = logging.getLogger(__name__)


class Flatten(BaseTransformer):
    """Flatten nested dict fields into dot-notation keys.

    Args:
        fields: List of top-level field names to flatten.
            If ``None``, all dict-valued fields are flattened.
        separator: Separator between parent and child keys (default ``"."``).
        max_depth: Maximum nesting depth to flatten (default ``10``).
    """

    def __init__(
        self,
        fields: list[str] | None = None,
        separator: str = ".",
        max_depth: int = 10,
    ) -> None:
        self.fields = fields
        self.separator = separator
        self.max_depth = max_depth

    def transform(self, data: list[dict[str, Any]]) -> list[dict[str, Any]]:
        """Flatten selected (or all) dict-valued fields in every record."""
        result: list[dict[str, Any]] = []
        for record in data:
            row: dict[str, Any] = {}
            for key, value in record.items():
                if self._should_flatten(key, value):
                    flattened = self._flatten_dict(value, key, depth=0)
                    row.update(flattened)
                else:
                    row[key] = value
            result.append(row)
        return result

    # ------------------------------------------------------------------

    def _should_flatten(self, key: str, value: Any) -> bool:
        """Decide whether to flatten a given field."""
        if not isinstance(value, dict):
            return False
        if self.fields is None:
            return True
        return key in self.fields

    def _flatten_dict(
        self, obj: dict[str, Any], prefix: str, depth: int
    ) -> dict[str, Any]:
        """Recursively flatten *obj* under *prefix*."""
        items: dict[str, Any] = {}
        for key, value in obj.items():
            full_key = f"{prefix}{self.separator}{key}"
            if isinstance(value, dict) and depth < self.max_depth:
                items.update(self._flatten_dict(value, full_key, depth + 1))
            else:
                items[full_key] = value
        return items

    def __repr__(self) -> str:
        parts: list[str] = []
        if self.fields is not None:
            parts.append(f"fields={self.fields!r}")
        if self.separator != ".":
            parts.append(f"separator={self.separator!r}")
        if self.max_depth != 10:
            parts.append(f"max_depth={self.max_depth!r}")
        return f"Flatten({', '.join(parts)})"
