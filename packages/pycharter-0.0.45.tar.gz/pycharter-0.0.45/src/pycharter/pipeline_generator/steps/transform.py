"""Transform step — applies the three-stage transform pipeline."""

from __future__ import annotations

import logging
import time
from typing import Any

from pycharter.pipeline_generator.steps._base import TransformStepConfig

logger = logging.getLogger(__name__)


def run_transform(
    config: TransformStepConfig,
    data: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    """Execute a transform step.

    Builds a canonical transform config from the step's three optional
    stages (operations, jsonata, custom_function) and delegates to the
    existing ``apply_transforms`` pipeline.

    Args:
        config: Transform step configuration.
        data: Input records from the upstream step.

    Returns:
        Transformed records.
    """
    from pycharter.pipeline_generator.transformers.pipeline import apply_transforms

    transform_config = _build_transform_config(config)

    start = time.monotonic()
    result = apply_transforms(data, transform_config)
    elapsed = time.monotonic() - start

    logger.info(
        "Transform step '%s': %d → %d records in %.2fs",
        config.id,
        len(data),
        len(result),
        elapsed,
    )
    return result


def _build_transform_config(config: TransformStepConfig) -> dict[str, Any]:
    """Build a canonical transform config dict from step fields.

    The existing ``apply_transforms`` expects a dict with optional keys
    ``simple_ops`` (or operation names at the top level), ``jsonata``, and
    ``custom_function``.  This helper maps the step config fields into
    that format.
    """
    tc: dict[str, Any] = {}

    if config.operations:
        # Operations are passed as-is; normalize_transform_config in the
        # transformer pipeline handles flattening.
        tc.update(config.operations)

    if config.jsonata:
        tc["jsonata"] = config.jsonata

    if config.custom_function:
        tc["custom_function"] = config.custom_function

    return tc
