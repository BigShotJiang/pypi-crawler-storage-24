"""Load step — wraps a loader to write data to a destination."""

from __future__ import annotations

import logging
import time
from typing import Any

from pycharter.pipeline_generator.loaders.factory import LoaderFactory
from pycharter.pipeline_generator.result import LoadResult
from pycharter.pipeline_generator.steps._base import LoadStepConfig

logger = logging.getLogger(__name__)


async def run_load(
    config: LoadStepConfig,
    data: list[dict[str, Any]],
    pipeline_name: str,
) -> LoadResult:
    """Execute a load step.

    Creates a loader via the factory, optionally validates input data,
    loads, and runs quality checks.

    Args:
        config: Load step configuration.
        data: Records to load.
        pipeline_name: Name of the parent pipeline (for quality checks).

    Returns:
        Load result from the destination.
    """
    target = dict(config.target)
    loader = LoaderFactory.create(target)

    # Optional pre-load validation.
    validated_data = data
    if config.validation:
        validated_data = _apply_validation(
            data, config.validation, config.id, pipeline_name
        )

    start = time.monotonic()
    load_result = await loader.load(validated_data)
    elapsed = time.monotonic() - start
    load_result.duration_seconds = elapsed

    logger.info(
        "Load step '%s': %d records → %s in %.2fs",
        config.id,
        len(validated_data),
        "success" if load_result.success else "FAILED",
        elapsed,
    )

    # Optional quality checks.
    if config.quality_checks and load_result.success:
        _run_quality_checks(
            config.quality_checks,
            validated_data,
            load_result,
            pipeline_name,
            config.id,
        )

    return load_result


def _apply_validation(
    data: list[dict[str, Any]],
    validation_config: dict[str, Any],
    step_id: str,
    pipeline_name: str,
) -> list[dict[str, Any]]:
    """Apply pre-load validation, returning valid records."""
    try:
        from pycharter.pipeline_generator._pipeline_helpers import create_load_validator

        validator = create_load_validator(
            load_validation_config=validation_config,
            settings={},
            pipeline_name=pipeline_name,
            base_dir=None,
        )
        if validator is None:
            return data
        return validator.validate(data)
    except Exception:
        logger.warning(
            "Load validation failed for step '%s'; proceeding without validation",
            step_id,
            exc_info=True,
        )
        return data


def _run_quality_checks(
    quality_checks_config: list[dict[str, Any]],
    data: list[dict[str, Any]],
    load_result: LoadResult,
    pipeline_name: str,
    step_id: str,
) -> None:
    """Run post-load quality checks."""
    try:
        from pycharter.pipeline_generator._pipeline_helpers import (
            create_quality_checker,
        )

        checker = create_quality_checker(quality_checks_config, pipeline_name)
        if checker is None:
            return
        report = checker.run(data, load_result)
        if not report.passed:
            for failure in report.hard_failures:
                logger.error(
                    "Load step '%s' quality failure: %s", step_id, failure.message
                )
            load_result.success = False
            load_result.error = (
                f"Quality checks failed: {len(report.hard_failures)} failure(s)"
            )
        for warning in report.warnings:
            logger.warning(
                "Load step '%s' quality warning: %s", step_id, warning.message
            )
    except Exception:
        logger.warning(
            "Quality checks failed for step '%s'; proceeding",
            step_id,
            exc_info=True,
        )
