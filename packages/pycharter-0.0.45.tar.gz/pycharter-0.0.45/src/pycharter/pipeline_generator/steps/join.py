"""Join step — hash-join two datasets on specified keys."""

from __future__ import annotations

import logging
import time
from collections import defaultdict
from typing import Any

from pycharter.pipeline_generator.steps._base import JoinHow, JoinStepConfig

logger = logging.getLogger(__name__)


def run_join(
    config: JoinStepConfig,
    left_data: list[dict[str, Any]],
    right_data: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    """Execute a join step.

    Performs a hash-join: builds an index on the right dataset, then
    iterates the left dataset looking up matches.

    Args:
        config: Join step configuration.
        left_data: Records from the left input step.
        right_data: Records from the right input step.

    Returns:
        Joined records.
    """
    start = time.monotonic()

    left_keys = _normalise_keys(config.on.left_key)
    right_keys = _normalise_keys(config.on.right_key)

    left_prefix = config.prefix.left if config.prefix else ""
    right_prefix = config.prefix.right if config.prefix else ""

    # Build right-side index.
    right_index = _build_index(right_data, right_keys)

    result = _execute_join(
        config.how,
        left_data,
        left_keys,
        right_index,
        right_keys,
        left_prefix,
        right_prefix,
    )

    elapsed = time.monotonic() - start
    logger.info(
        "Join step '%s' (%s): %d left × %d right → %d records in %.2fs",
        config.id,
        config.how.value,
        len(left_data),
        len(right_data),
        len(result),
        elapsed,
    )
    return result


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _normalise_keys(key: str | list[str]) -> list[str]:
    """Ensure key specification is always a list."""
    return [key] if isinstance(key, str) else list(key)


def _extract_key(record: dict[str, Any], keys: list[str]) -> tuple[Any, ...]:
    """Extract a composite key tuple from a record."""
    return tuple(record.get(k) for k in keys)


def _build_index(
    data: list[dict[str, Any]],
    keys: list[str],
) -> dict[tuple[Any, ...], list[dict[str, Any]]]:
    """Build a hash index on *data* keyed by *keys*."""
    index: dict[tuple[Any, ...], list[dict[str, Any]]] = defaultdict(list)
    for record in data:
        index[_extract_key(record, keys)].append(record)
    return index


def _merge_records(
    left: dict[str, Any],
    right: dict[str, Any],
    left_prefix: str,
    right_prefix: str,
) -> dict[str, Any]:
    """Merge two records, applying prefixes on field-name conflicts."""
    if not left_prefix and not right_prefix:
        # Default conflict resolution: right fields get right_prefix
        merged = dict(left)
        for k, v in right.items():
            if k in merged:
                merged[f"{k}_right"] = v
            else:
                merged[k] = v
        return merged

    merged: dict[str, Any] = {}
    right_fields = set(right.keys())
    left_fields = set(left.keys())
    conflicts = left_fields & right_fields

    for k, v in left.items():
        prefix = left_prefix if k in conflicts else ""
        merged[f"{prefix}{k}"] = v

    for k, v in right.items():
        prefix = right_prefix if k in conflicts else ""
        merged[f"{prefix}{k}"] = v

    return merged


def _null_record(
    keys: list[str],
    sample: dict[str, Any] | None,
) -> dict[str, Any]:
    """Create a null-filled record matching the schema of *sample*."""
    if sample is None:
        return {}
    return dict.fromkeys(sample)


def _execute_join(
    how: JoinHow,
    left_data: list[dict[str, Any]],
    left_keys: list[str],
    right_index: dict[tuple[Any, ...], list[dict[str, Any]]],
    right_keys: list[str],
    left_prefix: str,
    right_prefix: str,
) -> list[dict[str, Any]]:
    """Run the join algorithm for the given strategy."""
    result: list[dict[str, Any]] = []

    # Sample records for null-fill in outer joins.
    right_sample = (
        next(iter(next(iter(right_index.values()))), None) if right_index else None
    )
    left_sample = left_data[0] if left_data else None

    if how == JoinHow.INNER:
        for left_rec in left_data:
            key = _extract_key(left_rec, left_keys)
            for right_rec in right_index.get(key, []):
                result.append(
                    _merge_records(left_rec, right_rec, left_prefix, right_prefix)
                )

    elif how == JoinHow.LEFT:
        for left_rec in left_data:
            key = _extract_key(left_rec, left_keys)
            matches = right_index.get(key, [])
            if matches:
                for right_rec in matches:
                    result.append(
                        _merge_records(left_rec, right_rec, left_prefix, right_prefix)
                    )
            else:
                null_right = _null_record(right_keys, right_sample)
                result.append(
                    _merge_records(left_rec, null_right, left_prefix, right_prefix)
                )

    elif how == JoinHow.RIGHT:
        # Build left index instead.
        left_index = _build_index(left_data, left_keys)
        for key, right_recs in right_index.items():
            left_matches = left_index.get(key, [])
            for right_rec in right_recs:
                if left_matches:
                    for left_rec in left_matches:
                        result.append(
                            _merge_records(
                                left_rec, right_rec, left_prefix, right_prefix
                            )
                        )
                else:
                    null_left = _null_record(left_keys, left_sample)
                    result.append(
                        _merge_records(null_left, right_rec, left_prefix, right_prefix)
                    )

    elif how == JoinHow.OUTER:
        matched_right_keys: set[tuple[Any, ...]] = set()
        for left_rec in left_data:
            key = _extract_key(left_rec, left_keys)
            matches = right_index.get(key, [])
            if matches:
                matched_right_keys.add(key)
                for right_rec in matches:
                    result.append(
                        _merge_records(left_rec, right_rec, left_prefix, right_prefix)
                    )
            else:
                null_right = _null_record(right_keys, right_sample)
                result.append(
                    _merge_records(left_rec, null_right, left_prefix, right_prefix)
                )
        # Unmatched right records.
        for key, right_recs in right_index.items():
            if key not in matched_right_keys:
                for right_rec in right_recs:
                    null_left = _null_record(left_keys, left_sample)
                    result.append(
                        _merge_records(null_left, right_rec, left_prefix, right_prefix)
                    )

    return result
