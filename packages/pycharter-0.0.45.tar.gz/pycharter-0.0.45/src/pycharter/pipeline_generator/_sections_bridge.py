"""Bridge between section-based and step-based pipeline configs.

Converts ``{extract, transform, load}`` section dicts into a ``steps``
list and vice versa, so both formats can flow through the single
steps-native ``Pipeline``.
"""

from __future__ import annotations

from typing import Any


def sections_to_steps(
    extract: dict[str, Any],
    load: dict[str, Any],
    *,
    transform: dict[str, Any] | list[dict[str, Any]] | None = None,
    jsonata: dict[str, Any] | None = None,
    custom_function: dict[str, Any] | None = None,
) -> list[dict[str, Any]]:
    """Convert section-based config to a steps list.

    A section-based config (one extract, optional transform, one load) is
    the simple linear case of a DAG.  This function builds the
    corresponding ``steps`` list that ``parse_pipeline_config`` expects.

    Args:
        extract: Extract source config (e.g. ``{type: file, path: ...}``).
        load: Load target config (e.g. ``{type: file, path: ...}``).
        transform: Optional simple-ops transform config (dict or ordered
            list of single-key dicts).
        jsonata: Optional JSONata config (``{expression, mode}``).
        custom_function: Optional custom function config.

    Returns:
        A list of step dicts ready for ``parse_pipeline_config``.
    """
    steps: list[dict[str, Any]] = [
        {"id": "extract", "type": "extract", "source": extract},
    ]

    has_transform = any([transform, jsonata, custom_function])
    if has_transform:
        transform_step: dict[str, Any] = {
            "id": "transform",
            "type": "transform",
            "input": "extract",
        }
        if transform is not None:
            transform_step["operations"] = _normalize_ops(transform)
        if jsonata is not None:
            transform_step["jsonata"] = jsonata
        if custom_function is not None:
            transform_step["custom_function"] = custom_function
        steps.append(transform_step)

    steps.append(
        {
            "id": "load",
            "type": "load",
            "input": "transform" if has_transform else "extract",
            "target": load,
        }
    )

    return steps


def steps_to_sections(
    steps: list[dict[str, Any]],
) -> dict[str, Any] | None:
    """Convert a simple linear steps list back to section-based config.

    Only works for pipelines with exactly one extract, zero or one
    transform, and one load arranged linearly.  Returns ``None`` for
    DAGs that cannot be represented as sections (joins, unions, multiple
    extracts/loads).

    Returns:
        Dict with ``extract``, ``load``, and optionally ``transform``,
        ``jsonata``, ``custom_function`` keys — or ``None``.
    """
    extracts = [s for s in steps if s.get("type") == "extract"]
    transforms = [s for s in steps if s.get("type") == "transform"]
    loads = [s for s in steps if s.get("type") == "load"]
    joins = [s for s in steps if s.get("type") == "join"]
    unions = [s for s in steps if s.get("type") == "union"]

    if len(extracts) != 1 or len(loads) != 1 or joins or unions:
        return None
    if len(transforms) > 1:
        return None

    result: dict[str, Any] = {"extract": extracts[0].get("source", {})}

    if transforms:
        t = transforms[0]
        ops = t.get("operations")
        if ops is not None:
            result["transform"] = ops
        if t.get("jsonata"):
            result["jsonata"] = t["jsonata"]
        if t.get("custom_function"):
            result["custom_function"] = t["custom_function"]

    result["load"] = loads[0].get("target", {})
    return result


def is_section_based(raw: dict[str, Any]) -> bool:
    """Return True if *raw* looks like a section-based config."""
    return "extract" in raw and "load" in raw and "steps" not in raw


def normalize_to_steps(raw: dict[str, Any]) -> dict[str, Any]:
    """If *raw* is section-based, convert to steps format in-place.

    Returns the (possibly modified) dict — the original is not mutated.
    """
    if not is_section_based(raw):
        return raw

    extract = raw["extract"]
    load = raw["load"]
    transform = raw.get("transform")
    jsonata = raw.get("jsonata")
    custom_function = raw.get("custom_function")

    steps = sections_to_steps(
        extract,
        load,
        transform=transform,
        jsonata=jsonata,
        custom_function=custom_function,
    )

    result: dict[str, Any] = {}
    for key in ("name", "version", "description", "variables", "settings"):
        if key in raw:
            result[key] = raw[key]
    for key in ("contract_store", "dlq", "contract", "lineage"):
        if key in raw:
            result.setdefault("settings", {})[key] = raw[key]

    result["steps"] = steps
    return result


def _normalize_ops(
    transform: dict[str, Any] | list[dict[str, Any]],
) -> dict[str, Any]:
    """Normalize transform ops to a dict for the step config.

    Section-based transforms come in two shapes:
    - dict: ``{rename: {...}, convert: {...}, ...}`` — pass through.
    - list of single-key dicts: ``[{rename: {...}}, {convert: {...}}]``
      — merge into a single dict (last key wins on collision).
    """
    if isinstance(transform, dict):
        return transform
    merged: dict[str, Any] = {}
    for item in transform:
        if isinstance(item, dict):
            merged.update(item)
    return merged
