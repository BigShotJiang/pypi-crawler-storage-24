"""SSH tunnel management, connection string building, engine creation, and connection pool management.

This module provides the connection infrastructure for the ETL orchestrator,
including database type detection, SSH tunnel creation, URL modification for
tunneled connections, and SQLAlchemy engine/session creation.
"""

from __future__ import annotations

import logging
import re
from typing import Any

from sqlalchemy import create_engine
from sqlalchemy.orm import Session, sessionmaker

from pycharter.utils.value_injector import resolve_values

# Optional dependency for SSH tunnels
try:
    from sshtunnel import SSHTunnelForwarder  # type: ignore[import-untyped]

    SSH_TUNNEL_AVAILABLE = True
except ImportError:
    SSH_TUNNEL_AVAILABLE = False
    SSHTunnelForwarder = None  # type: ignore[assignment]

logger = logging.getLogger(__name__)

# Database type constants
DB_POSTGRESQL = "postgresql"
DB_MYSQL = "mysql"
DB_SQLITE = "sqlite"
DB_MSSQL = "mssql"
DB_ORACLE = "oracle"
DB_MONGODB = "mongodb"

# Default ports for SSH tunnel
DEFAULT_POSTGRES_PORT = 5432
DEFAULT_MYSQL_PORT = 3306
DEFAULT_SSH_PORT = 22
DEFAULT_TUNNEL_LOCAL_PORT = 5433


def detect_database_type(db_url: str) -> str:
    """
    Detect database type from connection string.

    Supports both sync and async database URL formats (e.g., postgresql+asyncpg://).

    Args:
        db_url: Database connection string

    Returns:
        Database type: 'postgresql', 'mysql', 'sqlite', 'mssql', etc.

    Raises:
        ValueError: If database type cannot be determined
    """
    db_url_lower = db_url.lower()

    # Handle async URL formats (e.g., postgresql+asyncpg://, mysql+aiomysql://)
    # Extract base database type by removing driver suffix
    if "+" in db_url_lower:
        base_url = db_url_lower.split("+", 1)[0] + "://"
    else:
        base_url = db_url_lower

    # Check for PostgreSQL variants
    if base_url.startswith(("postgresql://", "postgres://")):
        return DB_POSTGRESQL
    # Check for MySQL variants
    elif base_url.startswith(("mysql://", "mariadb://")):
        return DB_MYSQL
    # Check for SQLite
    elif base_url.startswith("sqlite://"):
        return DB_SQLITE
    # Check for MSSQL variants
    elif base_url.startswith(("mssql://", "sqlserver://")):
        return DB_MSSQL
    # Check for Oracle
    elif base_url.startswith("oracle://"):
        return DB_ORACLE
    # Check for MongoDB
    elif base_url.startswith(("mongodb://", "mongodb+srv://")):
        return DB_MONGODB
    else:
        raise ValueError(
            f"Cannot detect database type from connection string. "
            f"Supported formats: postgresql://, mysql://, sqlite://, mssql://, oracle://, mongodb:// "
            f"(async variants like postgresql+asyncpg:// are also supported). "
            f"Got: {db_url[:50]}..."
        )


def _is_ssh_tunnel_enabled(ssh_config: dict[str, Any]) -> bool:
    """Return True only if enabled is explicitly truthy. Treats string 'false' as disabled."""
    enabled = ssh_config.get("enabled")
    if enabled is None:
        return False
    return enabled in (True, "true", "1", "yes")


def create_ssh_tunnel(ssh_config: dict[str, Any]) -> Any | None:
    """
    Create SSH tunnel for database connection.

    Args:
        ssh_config: SSH tunnel configuration dictionary

    Returns:
        SSHTunnelForwarder instance if tunnel is created, None otherwise

    Raises:
        ImportError: If sshtunnel package is not installed
        ValueError: If SSH configuration is invalid
    """
    if not _is_ssh_tunnel_enabled(ssh_config):
        return None

    if not SSH_TUNNEL_AVAILABLE:
        raise ImportError(
            "sshtunnel package required for SSH tunnels. "
            "Install with: pip install sshtunnel or pip install pycharter[etl]"
        )

    # Validate required SSH config
    required_fields = ["host", "username", "remote_host", "remote_port"]
    missing_fields = [field for field in required_fields if not ssh_config.get(field)]
    if missing_fields:
        raise ValueError(
            f"SSH tunnel configuration missing required fields: {', '.join(missing_fields)}"
        )

    # Get SSH credentials
    ssh_host = ssh_config["host"]
    ssh_port = int(ssh_config.get("port", DEFAULT_SSH_PORT))
    ssh_username = ssh_config["username"]
    ssh_password = ssh_config.get("password")
    ssh_key_file = ssh_config.get("private_key_path")

    # Get remote database connection details
    remote_host = ssh_config["remote_host"]
    remote_port = int(ssh_config["remote_port"])
    local_port = int(ssh_config.get("local_port", DEFAULT_TUNNEL_LOCAL_PORT))

    # Create tunnel
    tunnel = SSHTunnelForwarder(
        (ssh_host, ssh_port),
        ssh_username=ssh_username,
        ssh_password=ssh_password,
        ssh_pkey=ssh_key_file if ssh_key_file and not ssh_password else None,
        remote_bind_address=(remote_host, remote_port),
        local_bind_address=("127.0.0.1", local_port),
    )

    tunnel.start()
    return tunnel


def modify_url_for_tunnel(db_url: str, local_port: int, db_type: str) -> str:
    """
    Modify database URL to use local tunnel port.

    Args:
        db_url: Original database URL
        local_port: Local tunnel port
        db_type: Database type

    Returns:
        Modified database URL
    """
    if db_type == DB_POSTGRESQL:
        return re.sub(r"@[^:]+:\d+/", f"@127.0.0.1:{local_port}/", db_url)
    elif db_type == DB_MYSQL:
        return re.sub(r"@[^:]+:\d+/", f"@127.0.0.1:{local_port}/", db_url)
    # Add other database types as needed
    return db_url


def get_database_connection(
    load_config: dict[str, Any],
    contract_dir: Any | None = None,
    config_context: dict[str, Any] | None = None,
) -> tuple[Any, Session, str, Any | None]:
    """
    Get database connection from load configuration.

    Handles:
    - Database URL resolution (with variable injection)
    - SSH tunnel creation if configured
    - Database type detection
    - Engine and session creation

    Args:
        load_config: Load configuration dictionary
        contract_dir: Contract directory path (for variable resolution)
        config_context: Optional context dictionary for value injection

    Returns:
        Tuple of (engine, session, db_type, tunnel)
        - engine: SQLAlchemy engine
        - session: SQLAlchemy session
        - db_type: Database type string
        - tunnel: SSH tunnel instance (or None)

    Raises:
        ValueError: If database configuration is invalid
    """
    # Get database configuration
    db_config = load_config.get("database", {})

    # Get database URL (with variable injection)
    db_url = db_config.get("url")
    if not db_url:
        raise ValueError(
            "Database URL not specified in load.yaml. "
            "Add 'database.url' to your load configuration."
        )

    # Resolve variables in database URL
    source_file = str(contract_dir / "load.yaml") if contract_dir else None
    db_url = resolve_values(db_url, context=config_context, source_file=source_file)

    # Resolve SSH tunnel config if present
    ssh_config = db_config.get("ssh_tunnel", {})
    if ssh_config:
        ssh_config = resolve_values(
            ssh_config, context=config_context, source_file=source_file
        )
        # Convert string boolean values to actual booleans
        enabled_value = ssh_config.get("enabled", False)
        if isinstance(enabled_value, str):
            # Handle string boolean values
            enabled_lower = enabled_value.lower()
            ssh_config["enabled"] = enabled_lower in ("true", "1", "yes", "on")
        elif not isinstance(enabled_value, bool):
            # Convert other types (int, etc.) to boolean
            ssh_config["enabled"] = bool(enabled_value)

    # Handle SSH tunnel if configured
    tunnel = None
    if ssh_config.get("enabled", False):
        tunnel = create_ssh_tunnel(ssh_config)

        # Modify database URL to use local tunnel port
        if tunnel:
            db_type_from_url = detect_database_type(db_url)
            local_port = int(ssh_config.get("local_port", DEFAULT_TUNNEL_LOCAL_PORT))
            db_url = modify_url_for_tunnel(db_url, local_port, db_type_from_url)

    # Detect database type
    db_type = db_config.get("type")
    if not db_type:
        db_type = detect_database_type(db_url)

    # Create engine
    engine = create_engine(db_url, echo=False)

    # Create session
    Session = sessionmaker(bind=engine)
    session = Session()

    return engine, session, db_type, tunnel
