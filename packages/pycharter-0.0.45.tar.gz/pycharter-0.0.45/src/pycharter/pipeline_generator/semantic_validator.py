"""
Semantic pre-flight validator for ETL pipelines.

Builds RDF graphs from ontology artifacts and concept schemes, generates
dynamic SHACL shapes from the schema registry, and runs validation.
All constraints are soft (warnings only, never block pipeline execution).
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Any

logger = logging.getLogger(__name__)


@dataclass
class SemanticViolation:
    """A single semantic validation warning."""

    severity: str = "warning"
    focus_node: str = ""
    path: str = ""
    message: str = ""
    source_constraint: str = ""


@dataclass
class SemanticReport:
    """Result of a semantic pre-flight validation run.

    All violations are soft warnings — they do not prevent pipeline
    execution but are logged for awareness.
    """

    conforms: bool = True
    violations: list[SemanticViolation] = field(default_factory=list)
    concept_count: int = 0
    relationship_count: int = 0
    shape_count: int = 0


class SemanticPreflightValidator:
    """Validate ontology artifacts against schema-driven SHACL shapes.

    Takes a contract's ontology artifact and optional concept scheme,
    builds RDF graphs, generates SHACL shapes from the schema registry,
    and runs pyshacl validation.

    All constraints are ``sh:severity sh:Warning`` — violations produce
    warnings, never errors.

    Args:
        session: Optional SQLAlchemy session for DB-backed schema.
    """

    def __init__(self, session: Any | None = None) -> None:
        self._session = session

    def validate(
        self,
        artifact: Any,
        contract_id: str,
        *,
        concepts: Any | None = None,
    ) -> SemanticReport:
        """Run semantic pre-flight validation.

        Args:
            artifact: ConceptMapping with field mappings.
            contract_id: Owning contract identifier.
            concepts: Optional ConceptScheme to include in the data graph.

        Returns:
            SemanticReport with conformance flag and violations.
        """
        try:
            from pycharter.semantic.rdf import _check_pyshacl, _check_rdflib

            _check_rdflib()
            _check_pyshacl()
        except ImportError:
            logger.warning("rdflib/pyshacl not installed; skipping semantic validation")
            return SemanticReport()

        from pycharter.semantic.rdf.converter import jsonld_to_graph
        from pycharter.semantic.rdf.emitter import (
            emit_concepts_jsonld,
            emit_ontology_jsonld,
        )
        from pycharter.semantic.rdf.shacl_validator import validate_shacl
        from pycharter.semantic.rdf.shape_generator import generate_all_shapes

        # Build data graph
        ontology_doc = emit_ontology_jsonld(artifact, contract_id)
        data_graph = jsonld_to_graph(ontology_doc)

        concept_count = 0
        if concepts is not None:
            concepts_doc = emit_concepts_jsonld(concepts)
            concepts_graph = jsonld_to_graph(concepts_doc)
            data_graph += concepts_graph
            concept_count = len(concepts.concepts)

        # Generate shapes (file-based + dynamic from schema registry)
        schema = None
        if self._session is not None:
            from pycharter.semantic.ontology.schema_loader import get_registry

            schema = get_registry().get_schema(session=self._session)

        shapes_graph = generate_all_shapes(schema)
        shape_count = len(shapes_graph)

        # Run SHACL validation
        shacl_report = validate_shacl(data_graph, shapes_graph)

        # Convert to semantic report
        violations: list[SemanticViolation] = []
        for v in shacl_report.violations:
            violations.append(
                SemanticViolation(
                    severity=v.get("resultSeverity", "warning").rsplit("#", 1)[-1],
                    focus_node=v.get("focusNode", ""),
                    path=v.get("resultPath", ""),
                    message=v.get("resultMessage", ""),
                    source_constraint=v.get("sourceConstraintComponent", ""),
                )
            )

        return SemanticReport(
            conforms=shacl_report.conforms,
            violations=violations,
            concept_count=concept_count,
            relationship_count=len(getattr(artifact, "field_mappings", [])),
            shape_count=shape_count,
        )


def run_semantic_preflight(
    contract_id: str,
    session: Any,
) -> SemanticReport:
    """Run semantic pre-flight validation for a contract.

    Loads the contract's ontology artifact and concept scheme from the
    database, then validates against schema-driven SHACL shapes.

    Args:
        contract_id: Contract identifier.
        session: SQLAlchemy session.

    Returns:
        SemanticReport with conformance flag and violations.
    """
    from pycharter.semantic.ontology.loader import load_ontology_artifact

    try:
        artifact = load_ontology_artifact(contract_id, session)
    except Exception:
        logger.warning(
            "no ontology artifact found for contract %s; skipping",
            contract_id,
        )
        return SemanticReport()

    concepts = None
    try:
        from pycharter.db.models.semantic.concept import ConceptModel
        from pycharter.semantic.ontology.models import Concept, ConceptScheme

        rows = session.query(ConceptModel).all()
        if rows:
            scheme = ConceptScheme(
                id="validation-snapshot",
                title="Validation Snapshot",
                version="0.0.0",
            )
            for r in rows:
                scheme.concepts.append(
                    Concept(
                        id=r.name,
                        label=r.name,
                        definition=r.description,
                        concept_type=r.concept_type,
                    )
                )
            concepts = scheme
    except Exception:
        logger.debug("could not load concepts for semantic validation")

    validator = SemanticPreflightValidator(session)
    report = validator.validate(artifact, contract_id, concepts=concepts)

    if report.violations:
        logger.info(
            "semantic pre-flight for %s: %d warnings",
            contract_id,
            len(report.violations),
        )
        for v in report.violations:
            logger.warning("  [%s] %s — %s", v.severity, v.path, v.message)
    else:
        logger.info("semantic pre-flight for %s: all clear", contract_id)

    return report
