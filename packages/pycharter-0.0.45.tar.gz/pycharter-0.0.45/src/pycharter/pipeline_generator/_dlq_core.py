"""Core DLQ data types: reason enum and dead-letter record.

Extracted from :mod:`dlq` so that both the ``DeadLetterQueue`` class and
the database persistence module can reference the types without pulling in
the full queue implementation.
"""

from __future__ import annotations

import hashlib
import json
from datetime import datetime
from enum import Enum
from typing import Any


class DLQReason(Enum):
    """Reasons for DLQ placement."""

    EXTRACTION_ERROR = "extraction_error"
    TRANSFORMATION_ERROR = "transformation_error"
    VALIDATION_ERROR = "validation_error"
    LOAD_ERROR = "load_error"
    CONNECTION_ERROR = "connection_error"
    SCHEMA_MISMATCH = "schema_mismatch"
    UNKNOWN = "unknown"


class DeadLetterRecord:
    """Represents a record in the dead letter queue."""

    def __init__(
        self,
        pipeline_name: str,
        record_data: dict[str, Any],
        reason: DLQReason,
        error_message: str,
        error_type: str,
        stage: str,  # 'extract', 'transform', 'load'
        metadata: dict[str, Any] | None = None,
        record_id: str | None = None,
    ):
        """Initialize a dead letter record.

        Args:
            pipeline_name: Name of the pipeline that failed.
            record_data: The actual record data that failed.
            reason: Reason for DLQ placement.
            error_message: Error message.
            error_type: Type of error (exception class name).
            stage: ETL stage where failure occurred.
            metadata: Additional metadata (batch_num, run_id, etc.).
            record_id: Optional record identifier (if None, will be generated).
        """
        self.pipeline_name = pipeline_name
        self.record_data = record_data
        self.reason = reason
        self.error_message = error_message
        self.error_type = error_type
        self.stage = stage
        self.metadata = metadata or {}
        self.timestamp = datetime.utcnow()
        self.retry_count = 0
        self.status = "pending"  # pending, retrying, resolved, ignored

        # Generate ID if not provided
        self.id = record_id or self._generate_id()

    def _generate_id(self) -> str:
        """Generate unique ID for DLQ record."""
        # Create a hash from pipeline, reason, and record data
        data_str = json.dumps(self.record_data, sort_keys=True, default=str)
        hash_input = f"{self.pipeline_name}:{self.reason.value}:{self.stage}:{data_str}"
        return hashlib.sha256(hash_input.encode()).hexdigest()[:16]

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for serialization."""
        return {
            "id": self.id,
            "pipeline_name": self.pipeline_name,
            "record_data": self.record_data,
            "reason": self.reason.value,
            "error_message": self.error_message,
            "error_type": self.error_type,
            "stage": self.stage,
            "metadata": self.metadata,
            "timestamp": self.timestamp.isoformat(),
            "retry_count": self.retry_count,
            "status": self.status,
        }
