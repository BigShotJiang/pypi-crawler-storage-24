"""Pipeline config parser.

Parses YAML files or raw dicts into a ``PipelineConfig`` containing
metadata, variables, settings, and a list of typed ``StepConfig``
objects.  Accepts both step-based configs (``steps: [...]``) and
section-based configs (``extract/transform/load``) — the latter are
automatically converted via :func:`normalize_to_steps`.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import yaml

from pycharter.pipeline_generator._sections_bridge import normalize_to_steps
from pycharter.pipeline_generator.context import PipelineContext
from pycharter.pipeline_generator.steps._base import StepConfig, parse_step_config

logger = logging.getLogger(__name__)


@dataclass(frozen=True, slots=True)
class PipelineConfig:
    """Parsed and validated pipeline configuration."""

    name: str
    version: str = "1.0.0"
    description: str = ""
    variables: dict[str, str] = field(default_factory=dict)
    settings: dict[str, Any] = field(default_factory=dict)
    steps: list[StepConfig] = field(default_factory=list)


def parse_pipeline_config(
    raw: dict[str, Any],
    *,
    extra_variables: dict[str, str] | None = None,
) -> PipelineConfig:
    """Parse a raw dictionary into a PipelineConfig.

    Accepts these config shapes:

    1. Step-based: ``{"steps": [...]}`` (with optional ``name``, ``version``,
       ``pipeline`` envelope).
    2. Section-based: ``{"extract": {...}, "load": {...}}`` with optional
       ``transform``, ``jsonata``, ``custom_function``.  Automatically
       converted to steps via the sections bridge.

    Variable substitution (``${VAR}``, ``${VAR:-default}``) is applied
    to all step configs before parsing.

    Args:
        raw: Raw config dictionary (from YAML or programmatic input).
        extra_variables: Additional variables merged on top of the
            config's ``variables`` section (caller wins).

    Returns:
        A fully parsed and typed ``PipelineConfig``.

    Raises:
        ValueError: If required fields are missing or steps fail parsing.
    """
    raw = normalize_to_steps(raw)

    pipeline_section = raw.get("pipeline", {})
    if isinstance(pipeline_section, dict):
        name = pipeline_section.get("name", raw.get("name", "unnamed"))
        version = pipeline_section.get("version", raw.get("version", "1.0.0"))
        description = pipeline_section.get("description", raw.get("description", ""))
    else:
        name = raw.get("name", "unnamed")
        version = raw.get("version", "1.0.0")
        description = raw.get("description", "")

    variables = {str(k): str(v) for k, v in raw.get("variables", {}).items()}
    if extra_variables:
        variables.update(extra_variables)

    settings = raw.get("settings", {}) or {}

    raw_steps = raw.get("steps")
    if not raw_steps:
        raise ValueError(
            "Pipeline config must contain 'steps' (or 'extract'+'load' sections)."
        )
    if not isinstance(raw_steps, list):
        raise ValueError(f"'steps' must be a list, got {type(raw_steps).__name__}.")

    context = PipelineContext(variables=variables)
    resolved_steps = _resolve_step_variables(raw_steps, context)

    steps: list[StepConfig] = []
    for idx, raw_step in enumerate(resolved_steps):
        if not isinstance(raw_step, dict):
            raise ValueError(
                f"Step at index {idx} must be a dict, got {type(raw_step).__name__}."
            )
        try:
            steps.append(parse_step_config(raw_step))
        except Exception as exc:
            step_id = raw_step.get("id", f"index-{idx}")
            raise ValueError(f"Failed to parse step '{step_id}': {exc}") from exc

    return PipelineConfig(
        name=str(name),
        version=str(version),
        description=str(description),
        variables=variables,
        settings=settings,
        steps=steps,
    )


def load_pipeline_config(
    path: str | Path,
    *,
    extra_variables: dict[str, str] | None = None,
) -> PipelineConfig:
    """Load and parse a pipeline config from a YAML file.

    Args:
        path: Path to the YAML file.
        extra_variables: Additional variables merged on top of the
            config's ``variables`` section.

    Returns:
        Parsed ``PipelineConfig``.

    Raises:
        FileNotFoundError: If the file does not exist.
        ValueError: If parsing fails.
    """
    filepath = Path(path)
    if not filepath.exists():
        raise FileNotFoundError(f"Pipeline config file not found: {filepath}")

    with open(filepath) as f:
        raw = yaml.safe_load(f)

    if not isinstance(raw, dict):
        raise ValueError(
            f"Pipeline config must be a YAML mapping, got "
            f"{type(raw).__name__} in {filepath}"
        )

    logger.debug("Loaded pipeline config from %s", filepath)
    return parse_pipeline_config(raw, extra_variables=extra_variables)


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _resolve_step_variables(
    raw_steps: list[Any],
    context: PipelineContext,
) -> list[Any]:
    """Apply variable substitution to all step dicts."""
    resolved: list[Any] = []
    for step in raw_steps:
        if isinstance(step, dict):
            resolved.append(context.resolve_dict(step))
        else:
            resolved.append(step)
    return resolved
