"""Query execution, schema inspection, table operations, and data loading.

This module is a backward-compatible re-export shim.  All implementation
now lives in ``_db_query`` (SQL building, record processing) and
``_db_load`` (database-specific load functions).  New code should import
from the submodules directly.
"""

from __future__ import annotations

from pycharter.pipeline_generator._db_load import (
    LOAD_FUNCTIONS,
    load_data,
    load_data_generic,
    load_data_mssql,
    load_data_mysql,
    load_data_postgresql,
    load_data_raw_sql,
    load_data_sqlite,
)
from pycharter.pipeline_generator._db_query import (
    _MAX_ERROR_MESSAGE_LEN,
    _build_bulk_upsert_sql_and_params,
    _parse_datetime_string,
    _process_record_value,
    _serialize_json_value,
    _short_error,
    build_column_list,
    build_placeholder_list,
    build_table_name,
    process_batch_for_db,
    process_record_for_db,
)

__all__ = [
    # SQL building helpers
    "build_column_list",
    "build_placeholder_list",
    "build_table_name",
    # Record processing
    "process_batch_for_db",
    "process_record_for_db",
    # Load functions
    "LOAD_FUNCTIONS",
    "load_data",
    "load_data_generic",
    "load_data_mssql",
    "load_data_mysql",
    "load_data_postgresql",
    "load_data_raw_sql",
    "load_data_sqlite",
    # Private (re-exported for any existing direct users)
    "_build_bulk_upsert_sql_and_params",
    "_MAX_ERROR_MESSAGE_LEN",
    "_parse_datetime_string",
    "_process_record_value",
    "_serialize_json_value",
    "_short_error",
]
