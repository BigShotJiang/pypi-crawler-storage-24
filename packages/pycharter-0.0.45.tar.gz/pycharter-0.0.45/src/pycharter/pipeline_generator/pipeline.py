"""Pipeline class — DAG-based ETL pipeline.

Provides a high-level interface for loading, validating, and executing
step-based pipelines defined in YAML config files or dicts.
"""

from __future__ import annotations

import asyncio
import logging
from pathlib import Path
from typing import Any

import yaml

from pycharter.pipeline_generator._config import (
    PipelineConfig,
    load_pipeline_config,
    parse_pipeline_config,
)
from pycharter.pipeline_generator._dag import resolve_dag
from pycharter.pipeline_generator._runner import run_dag
from pycharter.pipeline_generator.result import PipelineResult
from pycharter.pipeline_generator.steps._base import StepConfig

logger = logging.getLogger(__name__)


class Pipeline:
    """DAG-based ETL pipeline.

    Pipelines are constructed from YAML config files or dicts and
    consist of a directed acyclic graph of steps (extract, transform,
    join, union, load).

    Example::

        pipeline = Pipeline.from_file("pipeline.yaml")
        result = asyncio.run(pipeline.run())
    """

    def __init__(
        self,
        config: PipelineConfig,
        steps: list[StepConfig],
    ) -> None:
        self._config = config
        self._steps = steps

    # ------------------------------------------------------------------
    # Properties
    # ------------------------------------------------------------------

    @property
    def name(self) -> str:
        """Pipeline name from config."""
        return self._config.name

    @property
    def version(self) -> str:
        """Pipeline version from config."""
        return self._config.version

    @property
    def steps(self) -> list[StepConfig]:
        """Steps in topological execution order."""
        return list(self._steps)

    @property
    def config(self) -> PipelineConfig:
        """Full parsed pipeline config."""
        return self._config

    # ------------------------------------------------------------------
    # Factory methods
    # ------------------------------------------------------------------

    @classmethod
    def from_file(
        cls,
        path: str | Path,
        *,
        extra_variables: dict[str, str] | None = None,
    ) -> Pipeline:
        """Create a pipeline from a YAML config file.

        Args:
            path: Path to the pipeline YAML file.
            extra_variables: Additional variables merged on top of the
                file's ``variables`` section (caller wins).

        Returns:
            A validated, ready-to-run pipeline.
        """
        config = load_pipeline_config(path, extra_variables=extra_variables)
        sorted_steps = resolve_dag(config.steps)
        return cls(config=config, steps=sorted_steps)

    @classmethod
    def from_dict(
        cls,
        raw: dict[str, Any],
        *,
        extra_variables: dict[str, str] | None = None,
    ) -> Pipeline:
        """Create a pipeline from a config dict.

        Accepts both step-based (``steps: [...]``) and section-based
        (``extract/transform/load``) configs.

        Args:
            raw: Raw config dictionary.
            extra_variables: Additional variables.

        Returns:
            A validated, ready-to-run pipeline.
        """
        config = parse_pipeline_config(raw, extra_variables=extra_variables)
        sorted_steps = resolve_dag(config.steps)
        return cls(config=config, steps=sorted_steps)

    @classmethod
    def from_config_dir(
        cls,
        directory: str | Path,
        *,
        extra_variables: dict[str, str] | None = None,
    ) -> Pipeline:
        """Create a pipeline from a directory of config files.

        Looks for a ``pipeline.yaml`` (or ``.yml``) first.  If not found,
        assembles a section-based config from individual
        ``extract.yaml``, ``load.yaml``, ``transform.yaml`` files.
        Also loads ``variables.yaml`` and ``settings.yaml`` if present.

        Args:
            directory: Path to the config directory.
            extra_variables: Additional variables.

        Returns:
            A validated, ready-to-run pipeline.
        """
        dirpath = Path(directory)
        if not dirpath.is_dir():
            raise FileNotFoundError(f"Config directory not found: {dirpath}")

        pipeline_file = _find_yaml(dirpath, "pipeline")
        if pipeline_file:
            return cls.from_file(pipeline_file, extra_variables=extra_variables)

        extract_file = _find_yaml(dirpath, "extract")
        load_file = _find_yaml(dirpath, "load")
        if not extract_file or not load_file:
            raise FileNotFoundError(
                f"Config directory must contain pipeline.yaml or "
                f"extract.yaml + load.yaml: {dirpath}"
            )

        raw = _merge_section_files(dirpath, extract_file, load_file)
        return cls.from_dict(raw, extra_variables=extra_variables)

    @classmethod
    def from_config_files(
        cls,
        *paths: str | Path,
        extra_variables: dict[str, str] | None = None,
    ) -> Pipeline:
        """Create a pipeline by merging multiple YAML config files.

        Each file is loaded and merged (later files override earlier ones
        on key collisions).

        Args:
            paths: One or more YAML file paths.
            extra_variables: Additional variables.

        Returns:
            A validated, ready-to-run pipeline.
        """
        if not paths:
            raise ValueError("At least one config file path is required.")

        merged: dict[str, Any] = {}
        for p in paths:
            filepath = Path(p)
            if not filepath.exists():
                raise FileNotFoundError(f"Config file not found: {filepath}")
            with open(filepath) as f:
                data = yaml.safe_load(f) or {}
            if not isinstance(data, dict):
                raise ValueError(
                    f"Expected YAML mapping in {filepath}, got {type(data).__name__}"
                )
            merged.update(data)

        return cls.from_dict(merged, extra_variables=extra_variables)

    # ------------------------------------------------------------------
    # Execution
    # ------------------------------------------------------------------

    async def run(
        self,
        *,
        run_id: str | None = None,
        fail_fast: bool = True,
    ) -> PipelineResult:
        """Execute the pipeline.

        Args:
            run_id: Optional identifier for this run.
            fail_fast: Abort on the first step failure.

        Returns:
            Aggregated pipeline result with per-step results.
        """
        return await run_dag(
            self._steps,
            pipeline_name=self._config.name,
            run_id=run_id,
            variables=self._config.variables,
            fail_fast=fail_fast,
        )

    def run_sync(
        self,
        *,
        run_id: str | None = None,
        fail_fast: bool = True,
    ) -> PipelineResult:
        """Execute the pipeline synchronously.

        Convenience wrapper that calls ``asyncio.run()`` on the async
        ``run`` method.
        """
        return asyncio.run(self.run(run_id=run_id, fail_fast=fail_fast))

    # ------------------------------------------------------------------
    # Representation
    # ------------------------------------------------------------------

    def __repr__(self) -> str:
        step_ids = [s.id for s in self._steps]
        return (
            f"Pipeline(name={self._config.name!r}, "
            f"version={self._config.version!r}, "
            f"steps={step_ids})"
        )


# ---------------------------------------------------------------------------
# Module-level helpers for factory methods
# ---------------------------------------------------------------------------


def _find_yaml(directory: Path, stem: str) -> Path | None:
    """Return the first ``<stem>.yaml`` or ``<stem>.yml`` in *directory*."""
    for ext in (".yaml", ".yml"):
        candidate = directory / f"{stem}{ext}"
        if candidate.exists():
            return candidate
    return None


def _merge_section_files(
    directory: Path,
    extract_file: Path,
    load_file: Path,
) -> dict[str, Any]:
    """Build a section-based config dict from individual YAML files."""

    def _load(path: Path) -> Any:
        with open(path) as f:
            return yaml.safe_load(f)

    raw: dict[str, Any] = {
        "extract": _load(extract_file),
        "load": _load(load_file),
    }

    transform_file = _find_yaml(directory, "transform")
    if transform_file:
        raw["transform"] = _load(transform_file)

    jsonata_file = _find_yaml(directory, "transform_jsonata")
    if jsonata_file:
        raw["jsonata"] = _load(jsonata_file)

    variables_file = _find_yaml(directory, "variables")
    if variables_file:
        raw["variables"] = _load(variables_file) or {}

    settings_file = _find_yaml(directory, "settings")
    if settings_file:
        raw["settings"] = _load(settings_file) or {}

    return raw
