"""Built-in function implementations for the expression evaluator.

Each function has the signature ``(args, record, context) -> Any`` and is
registered in :data:`BUILTIN_FUNCTIONS` for consumption by
:class:`~pycharter.pipeline_generator.expression.ExpressionEvaluator`.
"""

from __future__ import annotations

import os
import uuid as uuid_module
from collections.abc import Callable
from datetime import UTC, date, datetime
from typing import Any

from pycharter.shared.errors import ExpressionError


def _fn_now(args: list[Any], record: dict[str, Any], context: dict[str, Any]) -> str:
    """Return current timestamp in ISO format."""
    fmt = args[0] if args else None
    now = datetime.now()
    if fmt:
        return now.strftime(fmt)
    return now.isoformat()


def _fn_uuid(args: list[Any], record: dict[str, Any], context: dict[str, Any]) -> str:
    """Generate a UUID."""
    return str(uuid_module.uuid4())


def _fn_env(
    args: list[Any], record: dict[str, Any], context: dict[str, Any]
) -> str | None:
    """Get environment variable."""
    if not args:
        raise ExpressionError("env() requires a variable name")
    var_name = str(args[0])
    default = args[1] if len(args) > 1 else None
    return os.environ.get(var_name, default)


def _fn_lower(args: list[Any], record: dict[str, Any], context: dict[str, Any]) -> str:
    """Lowercase a value."""
    if not args:
        raise ExpressionError("lower() requires an argument")
    return str(args[0]).lower() if args[0] is not None else ""


def _fn_upper(args: list[Any], record: dict[str, Any], context: dict[str, Any]) -> str:
    """Uppercase a value."""
    if not args:
        raise ExpressionError("upper() requires an argument")
    return str(args[0]).upper() if args[0] is not None else ""


def _fn_concat(args: list[Any], record: dict[str, Any], context: dict[str, Any]) -> str:
    """Concatenate values."""
    return "".join(str(a) if a is not None else "" for a in args)


def _fn_coalesce(
    args: list[Any], record: dict[str, Any], context: dict[str, Any]
) -> Any:
    """Return first non-null value."""
    for arg in args:
        if arg is not None:
            return arg
    return None


def _fn_len(args: list[Any], record: dict[str, Any], context: dict[str, Any]) -> int:
    """Return length of a value."""
    if not args:
        raise ExpressionError("len() requires an argument")
    val = args[0]
    if val is None:
        return 0
    if isinstance(val, str | list | dict):
        return len(val)
    return len(str(val))


def _fn_trim(args: list[Any], record: dict[str, Any], context: dict[str, Any]) -> str:
    """Trim whitespace from a value."""
    if not args:
        raise ExpressionError("trim() requires an argument")
    return str(args[0]).strip() if args[0] is not None else ""


def _fn_default(
    args: list[Any], record: dict[str, Any], context: dict[str, Any]
) -> Any:
    """Return value or default if null."""
    if len(args) < 2:
        raise ExpressionError("default() requires two arguments")
    return args[0] if args[0] is not None else args[1]


def _fn_date(args: list[Any], record: dict[str, Any], context: dict[str, Any]) -> str:
    """Return current date or parse date string."""
    if not args:
        return date.today().isoformat()
    # Parse date from string
    val = args[0]
    if isinstance(val, date):
        return val.isoformat()
    if isinstance(val, datetime):
        return val.date().isoformat()
    # Try parsing
    for fmt in ("%Y-%m-%d", "%Y/%m/%d", "%m/%d/%Y", "%d-%m-%Y"):
        try:
            return datetime.strptime(str(val), fmt).date().isoformat()
        except ValueError:
            continue
    return str(val)


def _fn_datetime(
    args: list[Any], record: dict[str, Any], context: dict[str, Any]
) -> str:
    """Return current datetime or parse datetime string."""
    if not args:
        return datetime.now().isoformat()
    val = args[0]
    if isinstance(val, datetime):
        return val.isoformat()
    # Try parsing
    for fmt in (
        "%Y-%m-%dT%H:%M:%S",
        "%Y-%m-%dT%H:%M:%S.%f",
        "%Y-%m-%d %H:%M:%S",
        "%Y-%m-%d",
    ):
        try:
            return datetime.strptime(str(val), fmt).isoformat()
        except ValueError:
            continue
    return str(val)


def _fn_epoch_ms_to_iso(
    args: list[Any], record: dict[str, Any], context: dict[str, Any]
) -> str | None:
    """Convert Unix timestamp in milliseconds to ISO datetime string (UTC)."""
    if not args or args[0] is None:
        return None
    try:
        ms = int(float(args[0]))
        return datetime.fromtimestamp(ms / 1000.0, tz=UTC).isoformat()
    except (ValueError, TypeError, OSError):
        return None


def _fn_sub(
    args: list[Any], record: dict[str, Any], context: dict[str, Any]
) -> float | None:
    """Return first argument minus second (float)."""
    if not args or len(args) < 2 or args[0] is None or args[1] is None:
        return None
    try:
        return float(args[0]) - float(args[1])
    except (ValueError, TypeError):
        return None


def _fn_pct_change(
    args: list[Any], record: dict[str, Any], context: dict[str, Any]
) -> float | None:
    """Return (new - old) / old * 100. Args: (old_value, new_value)."""
    if not args or len(args) < 2 or args[0] is None or args[1] is None:
        return None
    try:
        old_v, new_v = float(args[0]), float(args[1])
        if old_v == 0:
            return None
        return (new_v - old_v) / old_v * 100.0
    except (ValueError, TypeError):
        return None


def _fn_int(
    args: list[Any], record: dict[str, Any], context: dict[str, Any]
) -> int | None:
    """Convert to integer."""
    if not args or args[0] is None:
        return None
    val = args[0]
    if isinstance(val, str):
        try:
            return int(float(val))
        except ValueError:
            return None
    return int(val)


def _fn_float(
    args: list[Any], record: dict[str, Any], context: dict[str, Any]
) -> float | None:
    """Convert to float."""
    if not args or args[0] is None:
        return None
    return float(args[0])


def _fn_str(args: list[Any], record: dict[str, Any], context: dict[str, Any]) -> str:
    """Convert to string."""
    if not args or args[0] is None:
        return ""
    return str(args[0])


def _fn_bool(args: list[Any], record: dict[str, Any], context: dict[str, Any]) -> bool:
    """Convert to boolean."""
    if not args or args[0] is None:
        return False
    val = args[0]
    if isinstance(val, str):
        return val.lower() in ("true", "1", "yes", "on")
    return bool(val)


BUILTIN_FUNCTIONS: dict[str, Callable] = {
    "now": _fn_now,
    "uuid": _fn_uuid,
    "env": _fn_env,
    "lower": _fn_lower,
    "upper": _fn_upper,
    "concat": _fn_concat,
    "coalesce": _fn_coalesce,
    "len": _fn_len,
    "trim": _fn_trim,
    "default": _fn_default,
    "date": _fn_date,
    "datetime": _fn_datetime,
    "epoch_ms_to_iso": _fn_epoch_ms_to_iso,
    "sub": _fn_sub,
    "pct_change": _fn_pct_change,
    "int": _fn_int,
    "float": _fn_float,
    "str": _fn_str,
    "bool": _fn_bool,
}
