"""Quality metrics and scoring logic for ETL pipelines.

Provides enums, result dataclasses, the QualityReport for aggregating
quality check outcomes, and the QualityChecker orchestrator.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from enum import Enum
from typing import Any

logger = logging.getLogger(__name__)

# =============================================================================
# ENUMS AND DATA CLASSES
# =============================================================================


class QualityCheckSeverity(Enum):
    """Severity level for quality check failures."""

    FAIL = "fail"
    WARN = "warn"


class QualityCheckStatus(Enum):
    """Status of a quality check execution."""

    PASSED = "passed"
    FAILED = "failed"
    SKIPPED = "skipped"


@dataclass(frozen=True, slots=True)
class QualityCheckResult:
    """Result from a single quality check.

    Attributes:
        check_name: Human-readable check name.
        check_type: Check type identifier (e.g. 'row_count').
        status: Whether the check passed, failed, or was skipped.
        severity: Whether failure should fail the pipeline or just warn.
        message: Descriptive message about the result.
        details: Additional context about the check.
    """

    check_name: str
    check_type: str
    status: QualityCheckStatus
    severity: QualityCheckSeverity
    message: str
    details: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True, slots=True)
class QualityReport:
    """Aggregated results from all quality checks.

    Attributes:
        checks: Tuple of individual check results.
        passed: True if no checks with severity=FAIL have failed.
    """

    checks: tuple[QualityCheckResult, ...] = ()
    passed: bool = True

    @property
    def failures(self) -> list[QualityCheckResult]:
        """All failed checks regardless of severity."""
        return [c for c in self.checks if c.status == QualityCheckStatus.FAILED]

    @property
    def warnings(self) -> list[QualityCheckResult]:
        """Failed checks with severity=WARN."""
        return [
            c
            for c in self.checks
            if c.status == QualityCheckStatus.FAILED
            and c.severity == QualityCheckSeverity.WARN
        ]

    @property
    def hard_failures(self) -> list[QualityCheckResult]:
        """Failed checks with severity=FAIL."""
        return [
            c
            for c in self.checks
            if c.status == QualityCheckStatus.FAILED
            and c.severity == QualityCheckSeverity.FAIL
        ]

    def to_dict(self) -> dict[str, Any]:
        """Convert report to a serializable dictionary."""
        return {
            "passed": self.passed,
            "total_checks": len(self.checks),
            "failed_count": len(self.failures),
            "warning_count": len(self.warnings),
            "checks": [
                {
                    "check_name": c.check_name,
                    "check_type": c.check_type,
                    "status": c.status.value,
                    "severity": c.severity.value,
                    "message": c.message,
                    "details": c.details,
                }
                for c in self.checks
            ],
        }


def parse_severity(config: dict[str, Any]) -> QualityCheckSeverity:
    """Parse severity from check config, defaulting to FAIL.

    Args:
        config: Check configuration dict with optional 'severity' key.

    Returns:
        Parsed QualityCheckSeverity value.
    """
    raw = config.get("severity", "fail").lower()
    if raw == "warn":
        return QualityCheckSeverity.WARN
    return QualityCheckSeverity.FAIL


# =============================================================================
# QUALITY CHECKER
# =============================================================================


class QualityChecker:
    """Runs post-load structural quality checks against loaded data.

    Validates row count, null rates, uniqueness, and custom expressions
    after data has been loaded. All checks run even if earlier ones fail
    to provide maximum information per run.

    For contract-based quality scoring, see
    ``pycharter.quality.QualityCheck``. Preferred alias:
    ``PostLoadChecker``.

    Args:
        checks: List of check config dicts with at least a 'type' key.
        pipeline_name: Name of the pipeline (for logging).
    """

    def __init__(
        self,
        checks: list[dict[str, Any]],
        pipeline_name: str = "",
    ) -> None:
        self._checks = checks
        self._pipeline_name = pipeline_name

    def run(
        self,
        loaded_records: list[dict[str, Any]],
        load_result: Any,
    ) -> QualityReport:
        """Execute all configured quality checks.

        Args:
            loaded_records: All records that were loaded.
            load_result: Result from the last load operation.

        Returns:
            QualityReport with results for each check.
        """
        # Lazy import to avoid circular dependency
        from pycharter.pipeline_generator._quality_checks import _CHECK_REGISTRY

        results: list[QualityCheckResult] = []
        has_hard_failure = False

        for check_config in self._checks:
            result = self._run_single_check(
                check_config, loaded_records, load_result, _CHECK_REGISTRY
            )
            results.append(result)
            if (
                result.status == QualityCheckStatus.FAILED
                and result.severity == QualityCheckSeverity.FAIL
            ):
                has_hard_failure = True

        return QualityReport(
            checks=tuple(results),
            passed=not has_hard_failure,
        )

    def _run_single_check(
        self,
        check_config: dict[str, Any],
        loaded_records: list[dict[str, Any]],
        load_result: Any,
        registry: dict[str, Any],
    ) -> QualityCheckResult:
        """Execute a single quality check and handle errors."""
        check_type = check_config.get("type", "")
        check_fn = registry.get(check_type)

        if check_fn is None:
            logger.warning(
                "Unknown quality check type: %s (pipeline: %s)",
                check_type,
                self._pipeline_name,
            )
            return QualityCheckResult(
                check_name=check_type,
                check_type=check_type,
                status=QualityCheckStatus.SKIPPED,
                severity=parse_severity(check_config),
                message=f"Unknown check type: {check_type}",
            )

        try:
            result = check_fn(loaded_records, load_result, check_config)
            self._log_result(result)
            return result
        except Exception as exc:
            logger.warning(
                "Quality check '%s' raised exception: %s",
                check_type,
                exc,
            )
            return QualityCheckResult(
                check_name=check_type,
                check_type=check_type,
                status=QualityCheckStatus.SKIPPED,
                severity=parse_severity(check_config),
                message=f"Check execution error: {exc}",
            )

    def _log_result(self, result: QualityCheckResult) -> None:
        """Log a quality check result at the appropriate level."""
        if (
            result.status == QualityCheckStatus.FAILED
            and result.severity == QualityCheckSeverity.FAIL
        ):
            logger.error(
                "Quality check FAILED (pipeline=%s): %s",
                self._pipeline_name,
                result.message,
            )
        elif result.status == QualityCheckStatus.FAILED:
            logger.warning(
                "Quality check WARNING (pipeline=%s): %s",
                self._pipeline_name,
                result.message,
            )


def create_quality_checker(
    quality_config: list[dict[str, Any]] | None,
    pipeline_name: str = "",
) -> QualityChecker | None:
    """Create a QualityChecker from config, or None if no checks configured.

    Args:
        quality_config: List of quality check configs, or None.
        pipeline_name: Pipeline name for logging.

    Returns:
        QualityChecker instance or None.
    """
    if not quality_config:
        return None
    return QualityChecker(quality_config, pipeline_name=pipeline_name)


# Preferred alias -- disambiguates from pycharter.quality.QualityCheck
PostLoadChecker = QualityChecker
