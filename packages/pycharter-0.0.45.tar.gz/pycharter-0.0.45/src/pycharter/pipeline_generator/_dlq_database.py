"""Database and file persistence backend for the Dead Letter Queue.

Contains the ``persist_to_database`` function and shared helpers.
Query, retry, statistics, and file-query operations live in
:mod:`_dlq_db_operations` and are re-exported here for backward
compatibility.
"""

from __future__ import annotations

import contextlib
import json
import logging
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from pycharter.pipeline_generator._dlq_core import (  # noqa: F401
        DeadLetterRecord,
        DLQReason,
    )

logger = logging.getLogger(__name__)

_EMPTY_STATS: dict[str, Any] = {
    "total": 0,
    "by_reason": {},
    "by_stage": {},
    "by_status": {},
}


def _resolve_table_name(schema_name: str | None) -> str:
    """Build the fully-qualified DLQ table name."""
    schema = schema_name if schema_name is not None else "pycharter"
    if schema:
        return f'"{schema}"."dead_letter_queue"'
    return '"dead_letter_queue"'


def _is_table_missing_error(exc: Exception) -> bool:
    """Return True if *exc* indicates the DLQ table does not exist."""
    error_str = str(exc).lower()
    return (
        "does not exist" in error_str
        or "undefinedtable" in error_str
        or "relation" in error_str
    )


async def _safe_rollback(db_session: Any, is_async: bool) -> None:
    """Rollback a session, suppressing errors during cleanup."""
    with contextlib.suppress(Exception):
        if is_async:
            await db_session.rollback()
        else:
            db_session.rollback()


def _build_insert_params(record: DeadLetterRecord) -> dict[str, Any]:
    """Build the parameter dict for an INSERT statement."""
    return {
        "id": record.id,
        "pipeline_name": record.pipeline_name,
        "record_data": json.dumps(record.record_data),
        "reason": record.reason.value,
        "error_message": record.error_message,
        "error_type": record.error_type,
        "stage": record.stage,
        "additional_metadata": (
            json.dumps(record.metadata) if record.metadata else None
        ),
        "retry_count": record.retry_count,
        "status": record.status,
        "timestamp": record.timestamp,
    }


async def persist_to_database(
    db_session: Any,
    record: DeadLetterRecord,
    schema_name: str | None,
) -> None:
    """Persist a single DLQ record to the database using configurable schema.

    Args:
        db_session: SQLAlchemy sync or async session.
        record: The dead-letter record to persist.
        schema_name: Database schema name override (default uses ``"pycharter"``).
    """
    from sqlalchemy import text
    from sqlalchemy.exc import ProgrammingError
    from sqlalchemy.ext.asyncio import AsyncSession

    is_async = isinstance(db_session, AsyncSession)
    table_name = _resolve_table_name(schema_name)
    check_sql = text(f"SELECT id, retry_count FROM {table_name} WHERE id = :id")
    update_sql = text(f"""
        UPDATE {table_name}
        SET retry_count = retry_count + 1, status = :status,
            error_message = :error_message, updated_at = NOW()
        WHERE id = :id""")
    insert_sql = text(f"""
        INSERT INTO {table_name} (
            id, pipeline_name, record_data, reason, error_message,
            error_type, stage, additional_metadata, retry_count,
            status, timestamp, created_at, updated_at
        ) VALUES (
            :id, :pipeline_name, :record_data::jsonb, :reason,
            :error_message, :error_type, :stage, :additional_metadata::jsonb,
            :retry_count, :status, :timestamp, NOW(), NOW()
        )""")
    update_params = {
        "id": record.id,
        "status": "pending",
        "error_message": record.error_message,
    }
    insert_params = _build_insert_params(record)

    try:
        if is_async:
            result = await db_session.execute(check_sql, {"id": record.id})
            existing = result.fetchone()
            if existing:
                await db_session.execute(update_sql, update_params)
            else:
                await db_session.execute(insert_sql, insert_params)
            await db_session.commit()
        else:
            result = db_session.execute(check_sql, {"id": record.id})
            existing = result.fetchone()
            if existing:
                db_session.execute(update_sql, update_params)
            else:
                db_session.execute(insert_sql, insert_params)
            db_session.commit()
    except ProgrammingError as e:
        await _safe_rollback(db_session, is_async)
        if _is_table_missing_error(e):
            logger.warning(
                "DLQ table does not exist - skipping DLQ persistence. "
                "Create the table to enable DLQ functionality."
            )
            return
        logger.error("Failed to persist DLQ record to database: %s", e, exc_info=True)
    except Exception as e:
        await _safe_rollback(db_session, is_async)
        logger.error("Failed to persist DLQ record to database: %s", e, exc_info=True)


# ---------------------------------------------------------------------------
# Re-exports: downstream code imports these names from _dlq_database
# ---------------------------------------------------------------------------

from pycharter.pipeline_generator._dlq_db_operations import (  # noqa: E402, F401
    get_statistics_from_database,
    query_from_database,
    query_from_files,
    retry_record_in_database,
)
