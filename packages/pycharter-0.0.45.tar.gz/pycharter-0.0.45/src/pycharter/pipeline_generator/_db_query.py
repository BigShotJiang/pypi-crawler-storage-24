"""SQL building, record processing, and bulk upsert query generation.

Provides database-agnostic helpers for quoting identifiers, building
parameterised placeholders, serialising Python values for database
insertion, and constructing bulk ``INSERT ... ON CONFLICT`` statements.
"""

from __future__ import annotations

import json
import logging
import uuid
from datetime import UTC, datetime
from typing import Any

from pycharter.pipeline_generator.database_connection import (
    DB_MSSQL,
    DB_MYSQL,
    DB_POSTGRESQL,
    DB_SQLITE,
)

logger = logging.getLogger(__name__)

# Max length for error messages in logs to avoid dumping full SQL/params
_MAX_ERROR_MESSAGE_LEN = 500


def _short_error(e: Exception) -> str:
    """Return a short, safe error message for logging (no full SQL/params)."""
    msg = str(e).strip()
    if len(msg) <= _MAX_ERROR_MESSAGE_LEN:
        return msg
    return msg[:_MAX_ERROR_MESSAGE_LEN] + " ... [truncated]"


# ============================================================================
# SQL Building Helpers
# ============================================================================


def build_table_name(schema_name: str, table_name: str, db_type: str) -> str:
    """Build fully qualified table name for database-specific syntax.

    Args:
        schema_name: Database schema name.
        table_name: Table name.
        db_type: Database type.

    Returns:
        Fully qualified table name with proper quoting.
    """
    if db_type == DB_POSTGRESQL:
        return f'"{schema_name}"."{table_name}"' if schema_name else f'"{table_name}"'
    elif db_type == DB_MYSQL:
        return f"`{schema_name}`.`{table_name}`" if schema_name else f"`{table_name}`"
    elif db_type == DB_SQLITE:
        # SQLite doesn't support schemas
        return f'"{table_name}"'
    elif db_type == DB_MSSQL:
        return f"[{schema_name}].[{table_name}]" if schema_name else f"[{table_name}]"
    else:
        # Generic fallback
        return f'"{schema_name}"."{table_name}"' if schema_name else f'"{table_name}"'


def build_column_list(columns: list[str], db_type: str) -> str:
    """Build column list with database-specific quoting.

    Args:
        columns: List of column names.
        db_type: Database type.

    Returns:
        Quoted column list string.
    """
    if db_type == DB_POSTGRESQL:
        return ", ".join([f'"{col}"' for col in columns])
    elif db_type == DB_MYSQL:
        return ", ".join([f"`{col}`" for col in columns])
    elif db_type == DB_SQLITE:
        return ", ".join([f'"{col}"' for col in columns])
    elif db_type == DB_MSSQL:
        return ", ".join([f"[{col}]" for col in columns])
    else:
        return ", ".join([f'"{col}"' for col in columns])


def build_placeholder_list(columns: list[str]) -> str:
    """Build placeholder list for parameterized queries."""
    return ", ".join([f":{col}" for col in columns])


# ============================================================================
# Record Processing Utilities
# ============================================================================


def _serialize_json_value(value: Any) -> str:
    """Serialize list/dict to JSON string."""
    return json.dumps(value)


def _parse_datetime_string(value: str) -> Any:
    """Parse datetime string to datetime object, with fallback formats."""
    try:
        # Try ISO format first
        return datetime.fromisoformat(value.replace("Z", "+00:00"))
    except (ValueError, AttributeError):
        try:
            return datetime.strptime(value, "%Y-%m-%dT%H:%M:%S%z")
        except (ValueError, AttributeError):
            return value  # Return as-is if parsing fails


def _process_record_value(key: str, value: Any) -> Any:
    """Process a single record value for database insertion.

    Handles:
    - JSON serialization for list/dict values.
    - Datetime parsing for datetime-like fields (_at, _utc, _date).
    - Pass-through for other types.
    """
    if isinstance(value, list | dict) and value is not None:
        return _serialize_json_value(value)
    elif (
        isinstance(value, str)
        and key not in ("timestamp", "extraction_timestamp")
        and (
            key.endswith("_utc")
            or key.endswith("_at")
            or key.endswith("_date")
            or "timestamp" in key.lower()
        )
    ):
        parsed = _parse_datetime_string(value)
        if isinstance(parsed, datetime) and parsed.tzinfo is None:
            parsed = parsed.replace(tzinfo=UTC)
        return parsed
    else:
        return value


def process_record_for_db(
    record: dict[str, Any],
    needs_id: bool = False,
) -> dict[str, Any]:
    """Process a record for database insertion.

    Handles:
    - JSON serialization for list/dict values.
    - Datetime parsing for datetime-like fields.
    - UUID generation for 'id' column if needed.

    Args:
        record: Raw record dictionary.
        needs_id: If True, generate UUID for 'id' column if missing.

    Returns:
        Processed record ready for database insertion.
    """
    processed = {
        key: _process_record_value(key, value) for key, value in record.items()
    }

    # Generate UUID for 'id' if needed
    if needs_id and "id" not in processed:
        processed["id"] = uuid.uuid4()

    return processed


def process_batch_for_db(
    batch: list[dict[str, Any]],
    needs_id: bool = False,
) -> list[dict[str, Any]]:
    """Process a batch of records for database insertion."""
    return [process_record_for_db(record, needs_id=needs_id) for record in batch]


# ============================================================================
# Bulk Upsert SQL Generation
# ============================================================================


def _build_bulk_upsert_sql_and_params(
    full_table_name: str,
    columns: list[str],
    primary_key_list: list[str],
    processed_batch: list[dict[str, Any]],
    update_columns: list[str] | None = None,
) -> tuple[str, dict[str, Any]]:
    """Build bulk INSERT ... ON CONFLICT SQL and parameters for PostgreSQL.

    Args:
        full_table_name: Fully qualified table name.
        columns: List of column names.
        primary_key_list: List of primary key column names.
        processed_batch: Processed records ready for insertion.
        update_columns: If set, only these columns are updated on conflict
            (default: all non-PK columns).

    Returns:
        Tuple of (SQL statement, parameter dictionary).
    """
    # Deduplicate records based on primary key to avoid
    # "ON CONFLICT DO UPDATE cannot affect row a second time" error
    seen_keys: set[tuple[Any, ...]] = set()
    deduplicated_batch: list[dict[str, Any]] = []
    for record in processed_batch:
        # Create a key from primary key columns
        key = tuple(record.get(pk) for pk in primary_key_list)
        # Skip None keys (invalid records)
        if None in key:
            continue
        if key not in seen_keys:
            seen_keys.add(key)
            deduplicated_batch.append(record)

    if not deduplicated_batch:
        # Return empty SQL if no valid records after deduplication
        return "", {}

    columns_str = ", ".join([f'"{col}"' for col in columns])
    if update_columns:
        set_clause = ", ".join(
            f'"{k}" = EXCLUDED."{k}"'
            for k in update_columns
            if k in columns and k not in primary_key_list
        )
    else:
        set_clause = ", ".join(
            [f'"{k}" = EXCLUDED."{k}"' for k in columns if k not in primary_key_list]
        )
    conflict_columns = ", ".join([f'"{pk}"' for pk in primary_key_list])

    # Build VALUES clauses and parameters for deduplicated batch
    values_clauses = []
    params: dict[str, Any] = {}
    for idx, record in enumerate(deduplicated_batch):
        value_placeholders = []
        for col in columns:
            param_name = f"val_{idx}_{col}"
            value_placeholders.append(f":{param_name}")
            params[param_name] = record.get(col)
        values_clauses.append(f"({', '.join(value_placeholders)})")

    values_clause = ", ".join(values_clauses)

    sql = f"""
        INSERT INTO {full_table_name} ({columns_str})
        VALUES {values_clause}
        ON CONFLICT ({conflict_columns}) DO UPDATE SET {set_clause}
    """

    return sql, params
