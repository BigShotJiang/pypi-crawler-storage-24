"""Component factory helpers shared across pipeline steps."""

from __future__ import annotations

import logging
from pathlib import Path
from typing import TYPE_CHECKING, Any

import yaml

if TYPE_CHECKING:
    from pycharter.contract_store import ContractStoreClient

from pycharter.pipeline_generator.context import PipelineContext

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Config file / variable helpers
# ---------------------------------------------------------------------------


def load_config_input(
    config_input: str | Path | dict[str, Any] | list[dict[str, Any]],
    variables: dict[str, str],
) -> dict[str, Any] | list[dict[str, Any]]:
    """Load config from file path or return dict/list directly."""
    if isinstance(config_input, dict | list):
        return config_input

    path = Path(config_input)
    if not path.exists():
        raise FileNotFoundError(f"Config file not found: {path}")

    with open(path) as f:
        content = f.read()

    context = PipelineContext(variables=variables)
    content = context.resolve(content)
    return yaml.safe_load(content) or {}


def load_variables_file(
    path: Path,
    caller_variables: dict[str, str],
) -> dict[str, str]:
    """Load a variables.yaml file and merge with caller-supplied variables.

    File variables are loaded first, then caller-supplied variables are
    overlaid so that the caller always takes precedence.

    Args:
        path: Path to variables.yaml file.
        caller_variables: Variables supplied by the caller (take precedence).

    Returns:
        Merged variables dict with string values.

    Raises:
        ValueError: If the file does not contain a dict at the top level.
    """
    if not path.exists():
        return dict(caller_variables)

    with open(path) as f:
        raw = yaml.safe_load(f)

    if raw is None:
        return dict(caller_variables)

    if not isinstance(raw, dict):
        raise ValueError(
            f"variables.yaml must contain a mapping, got {type(raw).__name__}: {path}"
        )

    merged = {k: str(v) for k, v in raw.items()}
    merged.update(caller_variables)
    return merged


# ---------------------------------------------------------------------------
# Component factory helpers
# ---------------------------------------------------------------------------


def create_contract_store(
    settings: dict[str, Any],
) -> ContractStoreClient | None:
    """Create contract store client from pipeline settings."""
    store_config = settings.get("contract_store")
    if not store_config:
        return None

    store_type = store_config.get("type", "").lower()
    connection_string = store_config.get("connection_string")

    if not connection_string:
        logger.warning("contract_store missing connection_string")
        return None

    if store_type == "postgres":
        from pycharter.contract_store import PostgresContractStore

        return PostgresContractStore(connection_string)
    elif store_type == "sqlite":
        from pycharter.contract_store import SQLiteContractStore

        return SQLiteContractStore(connection_string)
    elif store_type == "mongodb":
        from pycharter.contract_store import MongoDBContractStore

        return MongoDBContractStore(connection_string)
    elif store_type == "redis":
        from pycharter.contract_store import RedisContractStore

        return RedisContractStore(connection_string)
    elif store_type == "memory":
        from pycharter.contract_store import InMemoryContractStore

        return InMemoryContractStore()
    else:
        logger.warning("Unknown contract_store type: %s", store_type)
        return None


def create_extract_validator(
    extract_validation_config: dict[str, Any] | None,
    settings: dict[str, Any],
    pipeline_name: str,
    base_dir: Path | None,
) -> Any | None:
    """Create extract validator if configured."""
    if not extract_validation_config:
        return None

    from pycharter.pipeline_generator.config_models import DLQConfig
    from pycharter.pipeline_generator.validation import create_etl_validator

    default_dlq = None
    if settings.get("dlq"):
        default_dlq = DLQConfig(**settings["dlq"])

    return create_etl_validator(
        validation_config=extract_validation_config,
        pipeline_name=pipeline_name,
        stage="extract",
        contract_store=None,
        default_contract=None,
        default_dlq_config=default_dlq,
        base_dir=base_dir,
    )


def create_load_validator(
    load_validation_config: dict[str, Any] | None,
    settings: dict[str, Any],
    pipeline_name: str,
    base_dir: Path | None,
) -> Any | None:
    """Create load validator if configured."""
    if not load_validation_config:
        return None

    from pycharter.pipeline_generator.config_models import DLQConfig
    from pycharter.pipeline_generator.validation import create_etl_validator

    default_dlq = None
    if settings.get("dlq"):
        default_dlq = DLQConfig(**settings["dlq"])

    default_contract = settings.get("contract")

    contract_store = None
    if settings.get("contract_store"):
        contract_store = create_contract_store(settings)

    return create_etl_validator(
        validation_config=load_validation_config,
        pipeline_name=pipeline_name,
        stage="load",
        contract_store=contract_store,
        default_contract=default_contract,
        default_dlq_config=default_dlq,
        base_dir=base_dir,
    )


def create_state_store(settings: dict[str, Any]) -> Any:
    """Create state store from settings config."""
    from pycharter.pipeline_generator.state import create_state_store as _create

    store_config = settings.get("state_store", {})
    return _create(store_config)


def create_quality_checker(
    quality_checks_config: list[dict[str, Any]] | None,
    pipeline_name: str,
) -> Any | None:
    """Create quality checker if quality checks are configured."""
    if not quality_checks_config:
        return None
    from pycharter.pipeline_generator.quality import create_quality_checker as _create

    return _create(quality_checks_config, pipeline_name=pipeline_name)
