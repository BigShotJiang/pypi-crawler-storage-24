"""Paginated HTTP extraction logic.

Extracted from ``http.py`` to keep module sizes under 400 lines.
This module contains the pagination loop that drives multi-page
HTTP extraction for
:class:`~pycharter.pipeline_generator.extractors.http.HTTPExtractor`.
"""

from __future__ import annotations

import asyncio
import logging
from collections.abc import AsyncIterator
from typing import Any

from pycharter.pipeline_generator.extractors._http_helpers import (
    check_stop_conditions,
    extract_link_header_url,
)

logger = logging.getLogger(__name__)


async def extract_with_pagination(
    extract_single_page_fn,
    extract_config: dict[str, Any],
    params: dict[str, Any],
    headers: dict[str, Any],
    contract_dir: Any | None = None,
    batch_size: int = 1000,
    max_records: int | None = None,
    config_context: dict[str, Any] | None = None,
) -> AsyncIterator[list[dict[str, Any]]]:
    """Extract data with pagination support.

    Args:
        extract_single_page_fn: Callable that extracts a single page
            (the bound ``HTTPExtractor._extract_single_page`` method).
        extract_config: Extraction configuration dictionary.
        params: Query parameters for the request.
        headers: HTTP headers for the request.
        contract_dir: Optional contract directory for resolving paths.
        batch_size: Number of records per yielded batch.
        max_records: Optional cap on total records to extract.
        config_context: Optional context for value resolution.

    Yields:
        Batches of extracted records.
    """
    pagination_config = extract_config.get("pagination", {})
    strategy = pagination_config.get("strategy", "page")
    stop_conditions = pagination_config.get("stop_conditions", [])
    page_delay = float(pagination_config.get("page_delay", 0.1))
    max_pages = 1000
    max_records_from_config = None

    # Get max_pages and max_records from stop conditions
    for condition in stop_conditions:
        if condition.get("type") == "max_pages":
            max_pages = condition.get("value", 1000)
        elif condition.get("type") == "max_records":
            max_records_from_config = condition.get("value")

    if max_records is None:
        max_records = max_records_from_config

    current_batch: list[dict[str, Any]] = []
    total_extracted = 0
    page_count = 0
    current_url = None
    current_cursor = None

    # Initialize pagination state
    if strategy == "page":
        page_config = pagination_config.get("page", {})
        current_page = page_config.get("start", 0)
        page_increment = page_config.get("increment", 1)
        page_param_name = page_config.get("param_name", "page")
    elif strategy == "offset":
        offset_config = pagination_config.get("offset", {})
        current_offset = offset_config.get("start", 0)
        offset_param_name = offset_config.get("param_name", "offset")
        increment_by = offset_config.get("increment_by", "limit")
    elif strategy == "cursor":
        cursor_config = pagination_config.get("cursor", {})
        cursor_param_name = cursor_config.get("param_name", "cursor")
        cursor_response_path = cursor_config.get("response_path", "next_cursor")
    elif strategy == "next_url":
        next_url_config = pagination_config.get("next_url", {})
        next_url_response_path = next_url_config.get("response_path", "next_url")
    elif strategy == "link_header":
        pass
    else:
        raise ValueError(f"Unsupported pagination strategy: {strategy}")

    extract_config_copy = extract_config.copy()
    original_endpoint = extract_config_copy.get("api_endpoint")
    original_base_url = extract_config_copy.get("base_url", "")

    logger.debug(
        "Starting paginated extraction (strategy: %s, "
        "max_pages: %s, batch_size: %s, page_delay: %ss)",
        strategy,
        max_pages,
        batch_size,
        page_delay,
    )

    while page_count < max_pages:
        # Check max_records limit
        if max_records and total_extracted >= max_records:
            logger.debug(
                "Reached max_records limit (%s), stopping pagination "
                "(extracted %s records from %s pages)",
                max_records,
                total_extracted,
                page_count,
            )
            if current_batch:
                yield current_batch
            return

        # Update params/URL based on strategy
        if strategy == "page":
            params[page_param_name] = current_page
            logger.debug(
                "Fetching page %s (page_count: %s/%s)",
                current_page,
                page_count + 1,
                max_pages,
            )
        elif strategy == "offset":
            params[offset_param_name] = current_offset
        elif strategy == "cursor" and current_cursor:
            params[cursor_param_name] = current_cursor
        elif strategy == "next_url" and current_url:
            extract_config_copy["api_endpoint"] = current_url
            extract_config_copy["base_url"] = ""

        # Make request
        need_full_response = strategy in ["cursor", "next_url", "link_header"]
        try:
            logger.debug(
                "Extracting page %s (total extracted so far: %s)",
                page_count + 1,
                total_extracted,
            )
            (
                page_data,
                full_response_data,
                response_obj,
            ) = await extract_single_page_fn(
                extract_config_copy,
                params,
                headers,
                contract_dir,
                return_full_response=need_full_response,
                config_context=config_context,
            )
            logger.debug(
                "Page %s extracted: %s records", page_count + 1, len(page_data)
            )
        except Exception:
            logger.error(
                "Error extracting page %s",
                page_count + 1,
                extra={"page": page_count + 1, "extracted": total_extracted},
                exc_info=True,
            )
            if current_batch:
                yield current_batch
            raise

        # Restore original endpoint if modified
        if strategy == "next_url" and current_url:
            extract_config_copy["api_endpoint"] = original_endpoint
            extract_config_copy["base_url"] = original_base_url

        # Check for empty page first
        if not page_data:
            logger.debug("Empty page %s received, stopping pagination", page_count + 1)
            if current_batch:
                yield current_batch
            break

        # Check stop conditions
        page_count += 1
        limit_value = params.get("limit", 100)
        record_count = len(page_data)
        logger.debug(
            "Evaluating stop conditions for page %s: %s records returned, limit=%s",
            page_count,
            record_count,
            limit_value,
        )
        should_stop = check_stop_conditions(
            page_data, stop_conditions, params, full_response_data
        )
        if should_stop:
            logger.debug(
                "Stop condition met at page %s (page returned %s records, limit: %s)",
                page_count,
                record_count,
                limit_value,
            )
            for record in page_data:
                current_batch.append(record)
                total_extracted += 1
                if len(current_batch) >= batch_size:
                    yield current_batch
                    current_batch = []
            if current_batch:
                yield current_batch
            break

        # Add page data to current batch
        for record in page_data:
            current_batch.append(record)
            total_extracted += 1
            if len(current_batch) >= batch_size:
                yield current_batch
                current_batch = []
            if max_records and total_extracted >= max_records:
                if current_batch:
                    yield current_batch
                return

        # Extract pagination token/URL for next iteration
        if strategy == "cursor" and full_response_data:
            try:
                current = full_response_data
                for part in cursor_response_path.split("."):
                    if isinstance(current, dict):
                        current = current.get(part)
                    elif isinstance(current, list) and part.isdigit():
                        current = current[int(part)]
                    else:
                        current = None
                        break
                if current and isinstance(current, str):
                    current_cursor = current
                elif current:
                    current_cursor = str(current)
                else:
                    if current_batch:
                        yield current_batch
                    break
            except (KeyError, IndexError, TypeError, ValueError):
                if current_batch:
                    yield current_batch
                break

        elif strategy == "next_url" and full_response_data:
            try:
                current = full_response_data
                for part in next_url_response_path.split("."):
                    if isinstance(current, dict):
                        current = current.get(part)
                    elif isinstance(current, list) and part.isdigit():
                        current = current[int(part)]
                    else:
                        current = None
                        break
                if current and isinstance(current, str):
                    current_url = current
                else:
                    current_url = None
                if not current_url:
                    if current_batch:
                        yield current_batch
                    break
            except (KeyError, IndexError, TypeError, ValueError):
                if current_batch:
                    yield current_batch
                break

        elif strategy == "link_header" and response_obj:
            current_url = extract_link_header_url(response_obj)
            if not current_url:
                if current_batch:
                    yield current_batch
                break
            extract_config_copy["api_endpoint"] = current_url
            extract_config_copy["base_url"] = ""

        # Update pagination state
        if strategy == "page":
            current_page += page_increment
        elif strategy == "offset":
            limit = params.get("limit", 100)
            if increment_by == "limit":
                current_offset += limit
            else:
                current_offset += int(increment_by)

        # Delay between pages
        if page_delay > 0:
            await asyncio.sleep(page_delay)

    # Yield remaining records
    if current_batch:
        yield current_batch
