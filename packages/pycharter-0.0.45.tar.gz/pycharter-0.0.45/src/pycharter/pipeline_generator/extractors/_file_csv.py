"""CSV, TSV, Parquet, Excel, and XML extraction helpers.

Async generator functions for extracting records from tabular file
formats using pandas.
"""

from __future__ import annotations

import logging
from collections.abc import AsyncIterator
from pathlib import Path
from typing import Any

import pandas as pd

logger = logging.getLogger(__name__)


def convert_pandas_types(record: dict[str, Any]) -> dict[str, Any]:
    """Convert pandas types to native Python types.

    Args:
        record: Single record dictionary from pandas DataFrame.

    Returns:
        Dictionary with native Python types.
    """
    converted: dict[str, Any] = {}
    for key, value in record.items():
        if pd.isna(value):
            converted[key] = None
        elif isinstance(value, pd.Timestamp | pd.DatetimeTZDtype):
            converted[key] = value.isoformat()
        elif isinstance(value, pd.Timedelta):
            converted[key] = str(value)
        else:
            converted[key] = value
    return converted


async def extract_csv(
    file_path: Path,
    batch_size: int,
    max_records: int | None,
    offset: int,
    format_type: str,
) -> AsyncIterator[list[dict[str, Any]]]:
    """Extract data from CSV/TSV file.

    Args:
        file_path: Path to the CSV/TSV file.
        batch_size: Number of records per batch.
        max_records: Maximum records to extract.
        offset: Number of initial rows to skip.
        format_type: Either ``'csv'`` or ``'tsv'``.

    Yields:
        Batches of records as list of dicts.
    """
    delimiter = "\t" if format_type == "tsv" else ","
    total_read = 0

    try:
        for chunk in pd.read_csv(
            file_path,
            delimiter=delimiter,
            chunksize=batch_size,
            skiprows=offset if offset > 0 else None,
        ):
            records = chunk.to_dict("records")
            records = [convert_pandas_types(record) for record in records]

            if max_records and total_read + len(records) > max_records:
                records = records[: max_records - total_read]

            total_read += len(records)
            yield records

            if max_records and total_read >= max_records:
                break
    except Exception as exc:
        raise RuntimeError(f"Error reading CSV file {file_path}: {exc}") from exc


async def extract_parquet(
    file_path: Path,
    batch_size: int,
    max_records: int | None,
    offset: int,
) -> AsyncIterator[list[dict[str, Any]]]:
    """Extract data from Parquet file.

    Args:
        file_path: Path to the Parquet file.
        batch_size: Number of records per batch.
        max_records: Maximum records to extract.
        offset: Number of initial rows to skip.

    Yields:
        Batches of records as list of dicts.
    """
    try:
        df = pd.read_parquet(file_path)

        if offset > 0:
            df = df.iloc[offset:]
        if max_records:
            df = df.head(max_records)

        for idx in range(0, len(df), batch_size):
            chunk = df.iloc[idx : idx + batch_size]
            records = chunk.to_dict("records")
            records = [convert_pandas_types(record) for record in records]
            yield records
    except Exception as exc:
        raise RuntimeError(f"Error reading Parquet file {file_path}: {exc}") from exc


async def extract_excel(
    file_path: Path,
    batch_size: int,
    max_records: int | None,
    offset: int,
) -> AsyncIterator[list[dict[str, Any]]]:
    """Extract data from Excel file.

    Args:
        file_path: Path to the Excel file.
        batch_size: Number of records per batch.
        max_records: Maximum records to extract.
        offset: Number of initial rows to skip.

    Yields:
        Batches of records as list of dicts.
    """
    try:
        df = pd.read_excel(file_path)

        if offset > 0:
            df = df.iloc[offset:]
        if max_records:
            df = df.head(max_records)

        for idx in range(0, len(df), batch_size):
            chunk = df.iloc[idx : idx + batch_size]
            records = chunk.to_dict("records")
            records = [convert_pandas_types(record) for record in records]
            yield records
    except Exception as exc:
        raise RuntimeError(f"Error reading Excel file {file_path}: {exc}") from exc


async def extract_xml(
    file_path: Path,
    batch_size: int,
    max_records: int | None,
    offset: int,
) -> AsyncIterator[list[dict[str, Any]]]:
    """Extract data from XML file.

    Args:
        file_path: Path to the XML file.
        batch_size: Number of records per batch.
        max_records: Maximum records to extract.
        offset: Number of initial rows to skip.

    Yields:
        Batches of records as list of dicts.
    """
    try:
        df = pd.read_xml(file_path)

        if offset > 0:
            df = df.iloc[offset:]
        if max_records:
            df = df.head(max_records)

        for idx in range(0, len(df), batch_size):
            chunk = df.iloc[idx : idx + batch_size]
            records = chunk.to_dict("records")
            records = [convert_pandas_types(record) for record in records]
            yield records
    except Exception as exc:
        raise RuntimeError(f"Error reading XML file {file_path}: {exc}") from exc
