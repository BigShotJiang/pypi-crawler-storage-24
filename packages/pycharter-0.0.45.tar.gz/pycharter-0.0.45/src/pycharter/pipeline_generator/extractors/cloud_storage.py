"""Cloud storage extractor for ETL orchestrator.

Supports extracting data from cloud storage providers:
- AWS S3 (via ``_cloud_storage_s3``)
- Google Cloud Storage (via ``_cloud_storage_gcs``)
- Azure Blob Storage (via ``_cloud_storage_azure``)

Provider-specific download/parse logic lives in the corresponding private
modules; this module contains the public ``CloudStorageExtractor`` class
and shared helpers.
"""

from __future__ import annotations

import logging
from collections.abc import AsyncIterator
from pathlib import Path
from typing import Any

from pycharter.pipeline_generator.extractors.base import BaseExtractor
from pycharter.utils.value_injector import resolve_values

logger = logging.getLogger(__name__)


class CloudStorageExtractor(BaseExtractor):
    """Extractor for cloud storage data sources.

    Supports two modes:
    1. Programmatic API:
        >>> extractor = CloudStorageExtractor(provider="s3", bucket="my-bucket", path="data/")
        >>> async for batch in extractor.extract():
        ...     process(batch)

    2. Config-driven:
        >>> extractor = CloudStorageExtractor()
        >>> async for batch in extractor.extract_streaming(config, params, headers):
        ...     process(batch)
    """

    def __init__(
        self,
        provider: str | None = None,
        bucket: str | None = None,
        path: str | None = None,
        credentials: dict[str, Any] | None = None,
        file_format: str | None = None,
        batch_size: int = 1000,
        max_records: int | None = None,
    ):
        self.provider = provider
        self.bucket = bucket
        self.path = path
        self.credentials = credentials
        self.file_format = file_format
        self.batch_size = batch_size
        self.max_records = max_records

    @classmethod
    def from_config(cls, config: dict[str, Any]) -> CloudStorageExtractor:
        """Create extractor from configuration dict."""
        storage_config = config.get("storage", {})
        return cls(
            provider=storage_config.get("provider") or config.get("provider"),
            bucket=storage_config.get("bucket") or config.get("bucket"),
            path=storage_config.get("path") or config.get("path"),
            credentials=storage_config.get("credentials") or config.get("credentials"),
            file_format=config.get("format"),
            batch_size=config.get("batch_size", 1000),
            max_records=config.get("max_records"),
        )

    async def extract(self, **params: Any) -> AsyncIterator[list[dict[str, Any]]]:
        """Extract data from cloud storage.

        Yields:
            Batches of records.
        """
        if not self.provider:
            raise ValueError("Provider is required (s3, gcs, azure)")
        if not self.bucket:
            raise ValueError("Bucket is required")
        if not self.path:
            raise ValueError("Path is required")

        extract_config = {
            "storage": {
                "provider": self.provider,
                "bucket": self.bucket,
                "path": self.path,
                "credentials": self.credentials,
            },
            "format": self.file_format,
        }

        async for batch in self.extract_streaming(
            extract_config,
            {},
            {},
            batch_size=self.batch_size,
            max_records=self.max_records,
        ):
            yield batch

    def validate_config(self, extract_config: dict[str, Any]) -> None:
        """Validate cloud storage extractor configuration."""
        if "type" in extract_config and extract_config["type"] != "cloud_storage":
            raise ValueError(
                f"CloudStorageExtractor requires type='cloud_storage', "
                f"got '{extract_config.get('type')}'"
            )

        storage_config = extract_config.get("storage", {})
        provider = storage_config.get("provider", "").lower()

        if provider not in ["s3", "gcs", "azure"]:
            raise ValueError(
                f"Cloud storage provider must be 's3', 'gcs', or 'azure', got '{provider}'"
            )

        if not storage_config.get("bucket"):
            raise ValueError(
                "Cloud storage extractor requires 'storage.bucket' in extract_config"
            )

        if not storage_config.get("path"):
            raise ValueError(
                "Cloud storage extractor requires 'storage.path' in extract_config"
            )

    async def extract_streaming(
        self,
        extract_config: dict[str, Any],
        params: dict[str, Any],
        headers: dict[str, Any],
        contract_dir: Any | None = None,
        batch_size: int = 1000,
        max_records: int | None = None,
        config_context: dict[str, Any] | None = None,
    ) -> AsyncIterator[list[dict[str, Any]]]:
        """Extract data from cloud storage.

        Downloads files from cloud storage and processes them using
        ``FileExtractor``.  Supports single files and prefixes.
        """
        storage_config = extract_config.get("storage", {})
        provider = storage_config.get("provider", "").lower()

        # Resolve variables
        source_file = str(contract_dir / "extract.yaml") if contract_dir else None
        bucket = resolve_values(
            storage_config.get("bucket"),
            context=config_context,
            source_file=source_file,
        )
        path = resolve_values(
            storage_config.get("path"), context=config_context, source_file=source_file
        )
        credentials = storage_config.get("credentials")

        # Detect format
        file_format = extract_config.get("format")
        if not file_format:
            path_obj = Path(path)
            file_format = _detect_format_from_path(path_obj)

        logger.info("Extracting from %s: %s/%s", provider.upper(), bucket, path)

        # Delegate to provider-specific module
        async for batch in _dispatch_provider(
            provider,
            bucket,
            path,
            credentials,
            file_format,
            batch_size,
            max_records,
            config_context,
            source_file,
        ):
            yield batch


# ------------------------------------------------------------------
# Private helpers
# ------------------------------------------------------------------


def _detect_format_from_path(path: Path) -> str | None:
    """Detect file format from path extension."""
    suffix = path.suffix.lower()
    format_map = {
        ".csv": "csv",
        ".tsv": "tsv",
        ".json": "json",
        ".jsonl": "jsonl",
        ".ndjson": "jsonl",
        ".parquet": "parquet",
        ".xlsx": "excel",
        ".xls": "excel",
        ".xml": "xml",
    }
    return format_map.get(suffix)


async def _dispatch_provider(
    provider: str,
    bucket: str,
    path: str,
    credentials: dict[str, Any] | None,
    file_format: str | None,
    batch_size: int,
    max_records: int | None,
    config_context: dict[str, Any] | None,
    source_file: str | None,
) -> AsyncIterator[list[dict[str, Any]]]:
    """Route extraction to the correct provider module."""
    if provider == "s3":
        from pycharter.pipeline_generator.extractors._cloud_storage_s3 import (
            extract_from_s3,
        )

        async for batch in extract_from_s3(
            bucket,
            path,
            credentials,
            file_format,
            batch_size,
            max_records,
            config_context,
            source_file,
        ):
            yield batch
    elif provider == "gcs":
        from pycharter.pipeline_generator.extractors._cloud_storage_gcs import (
            extract_from_gcs,
        )

        async for batch in extract_from_gcs(
            bucket,
            path,
            credentials,
            file_format,
            batch_size,
            max_records,
            config_context,
            source_file,
        ):
            yield batch
    elif provider == "azure":
        from pycharter.pipeline_generator.extractors._cloud_storage_azure import (
            extract_from_azure,
        )

        async for batch in extract_from_azure(
            bucket,
            path,
            credentials,
            file_format,
            batch_size,
            max_records,
            config_context,
            source_file,
        ):
            yield batch
    else:
        raise ValueError(f"Unsupported cloud storage provider: {provider}")
