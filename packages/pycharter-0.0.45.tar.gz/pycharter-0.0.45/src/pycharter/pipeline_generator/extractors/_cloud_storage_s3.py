"""AWS S3 extraction logic for the cloud storage extractor.

Provides ``extract_from_s3`` -- an async generator that downloads objects
from an S3 bucket and yields record batches via ``FileExtractor``.

This module is internal.  Use ``CloudStorageExtractor`` from
``pycharter.pipeline_generator.extractors.cloud_storage``.
"""

from __future__ import annotations

import logging
import tempfile
from collections.abc import AsyncIterator
from pathlib import Path
from typing import Any

from pycharter.pipeline_generator.extractors.file import FileExtractor

logger = logging.getLogger(__name__)

# Try to import S3 dependencies
try:
    import boto3
    from botocore.exceptions import ClientError  # noqa: F401

    S3_AVAILABLE = True
except ImportError:
    S3_AVAILABLE = False
    boto3 = None
    ClientError = None  # type: ignore[assignment,misc]


async def extract_from_s3(
    bucket: str,
    path: str,
    credentials: dict[str, Any] | None,
    file_format: str | None,
    batch_size: int,
    max_records: int | None,
    config_context: dict[str, Any] | None,
    source_file: str | None,
) -> AsyncIterator[list[dict[str, Any]]]:
    """Extract data from AWS S3.

    Downloads objects from *bucket*/*path* to temporary files and delegates
    parsing to ``FileExtractor``.  Supports both single-key and prefix
    (directory) downloads.

    Args:
        bucket: S3 bucket name.
        path: Object key or prefix (ending with ``/`` or containing ``*``).
        credentials: Optional dict with ``aws_access_key_id``,
            ``aws_secret_access_key``, and ``region``.
        file_format: Explicit file format (csv, json, parquet, ...).
        batch_size: Number of records per yielded batch.
        max_records: Stop after this many records (``None`` = unlimited).
        config_context: Variable-resolution context.
        source_file: Path used for variable resolution.

    Yields:
        Batches of parsed records.
    """
    if not S3_AVAILABLE:
        raise ImportError(
            "boto3 is required for S3 extraction. "
            "Install with: pip install boto3 or pip install pycharter[etl]"
        )

    s3_client = _build_s3_client(credentials)

    if path.endswith("/") or "*" in path:
        async for batch in _extract_s3_prefix(
            s3_client,
            bucket,
            path,
            file_format,
            batch_size,
            max_records,
            config_context,
        ):
            yield batch
    else:
        async for batch in _extract_s3_single(
            s3_client,
            bucket,
            path,
            file_format,
            batch_size,
            max_records,
            config_context,
        ):
            yield batch


def _build_s3_client(credentials: dict[str, Any] | None) -> Any:
    """Build and return a boto3 S3 client, optionally with explicit creds."""
    if not credentials or not isinstance(credentials, dict):
        return boto3.client("s3")

    aws_access_key_id = credentials.get("aws_access_key_id")
    aws_secret_access_key = credentials.get("aws_secret_access_key")
    region = credentials.get("region", "us-east-1")

    if aws_access_key_id and aws_secret_access_key:
        return boto3.client(
            "s3",
            aws_access_key_id=aws_access_key_id,
            aws_secret_access_key=aws_secret_access_key,
            region_name=region,
        )
    return boto3.client("s3")


async def _extract_s3_prefix(
    s3_client: Any,
    bucket: str,
    path: str,
    file_format: str | None,
    batch_size: int,
    max_records: int | None,
    config_context: dict[str, Any] | None,
) -> AsyncIterator[list[dict[str, Any]]]:
    """Download and yield records from all objects under an S3 prefix."""
    prefix = path.rstrip("/")
    if "*" in prefix:
        prefix = prefix.split("*")[0]

    paginator = s3_client.get_paginator("list_objects_v2")
    pages = paginator.paginate(Bucket=bucket, Prefix=prefix)

    total_extracted = 0
    for page in pages:
        if "Contents" not in page:
            continue

        for obj in page["Contents"]:
            if max_records and total_extracted >= max_records:
                return

            key = obj["Key"]
            logger.info("Processing S3 object: %s/%s", bucket, key)

            with tempfile.NamedTemporaryFile(
                delete=False, suffix=Path(key).suffix
            ) as tmp_file:
                tmp_path = Path(tmp_file.name)
                try:
                    s3_client.download_fileobj(bucket, key, tmp_file)

                    file_extractor = FileExtractor()
                    file_config = {
                        "type": "file",
                        "file_path": str(tmp_path),
                        "format": file_format,
                    }

                    async for batch in file_extractor.extract_streaming(
                        file_config,
                        {},
                        {},
                        None,
                        batch_size,
                        max_records,
                        config_context,
                    ):
                        total_extracted += len(batch)
                        yield batch
                        if max_records and total_extracted >= max_records:
                            return
                finally:
                    if tmp_path.exists():
                        tmp_path.unlink()


async def _extract_s3_single(
    s3_client: Any,
    bucket: str,
    path: str,
    file_format: str | None,
    batch_size: int,
    max_records: int | None,
    config_context: dict[str, Any] | None,
) -> AsyncIterator[list[dict[str, Any]]]:
    """Download and yield records from a single S3 object."""
    with tempfile.NamedTemporaryFile(
        delete=False, suffix=Path(path).suffix
    ) as tmp_file:
        tmp_path = Path(tmp_file.name)
        try:
            s3_client.download_fileobj(bucket, path, tmp_file)

            file_extractor = FileExtractor()
            file_config = {
                "type": "file",
                "file_path": str(tmp_path),
                "format": file_format,
            }

            async for batch in file_extractor.extract_streaming(
                file_config,
                {},
                {},
                None,
                batch_size,
                max_records,
                config_context,
            ):
                yield batch
        finally:
            if tmp_path.exists():
                tmp_path.unlink()
