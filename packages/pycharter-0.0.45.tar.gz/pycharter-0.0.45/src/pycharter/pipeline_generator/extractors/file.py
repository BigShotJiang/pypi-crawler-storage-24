"""File-based extractor for ETL orchestrator.

Re-export shim -- format-specific extraction logic lives in:
- ``_file_csv`` (CSV, TSV, Parquet, Excel, XML)
- ``_file_json`` (JSON, JSONL / NDJSON)

Supports reading from local files in various formats:
- CSV, TSV
- JSON (single file or newline-delimited JSON)
- Parquet
- Excel (xlsx, xls)
- XML
"""

from __future__ import annotations

import logging
import zipfile
from collections.abc import AsyncIterator
from pathlib import Path
from typing import Any

from pycharter.pipeline_generator.extractors._file_csv import (
    convert_pandas_types,
    extract_csv,
    extract_excel,
    extract_parquet,
    extract_xml,
)
from pycharter.pipeline_generator.extractors._file_json import (
    extract_json,
    extract_jsonl,
)
from pycharter.pipeline_generator.extractors.base import BaseExtractor
from pycharter.utils.value_injector import resolve_values

logger = logging.getLogger(__name__)

# Supported file formats
SUPPORTED_FORMATS = {
    ".csv": "csv",
    ".tsv": "tsv",
    ".json": "json",
    ".jsonl": "jsonl",  # Newline-delimited JSON
    ".ndjson": "jsonl",
    ".parquet": "parquet",
    ".xlsx": "excel",
    ".xls": "excel",
    ".xml": "xml",
}


class FileExtractor(BaseExtractor):
    """Extractor for file-based data sources.

    Supports two modes:
    1. Programmatic API:
        >>> extractor = FileExtractor(path="data.csv")
        >>> async for batch in extractor.extract():
        ...     process(batch)

    2. Config-driven:
        >>> extractor = FileExtractor()
        >>> async for batch in extractor.extract_streaming(config, params, headers):
        ...     process(batch)
    """

    def __init__(
        self,
        path: str | None = None,
        file_format: str | None = None,
        batch_size: int = 1000,
        max_records: int | None = None,
    ):
        self.path = path
        self.file_format = file_format
        self.batch_size = batch_size
        self.max_records = max_records

    @classmethod
    def from_config(cls, config: dict[str, Any]) -> FileExtractor:
        """Create extractor from configuration dict."""
        return cls(
            path=config.get("file_path") or config.get("path"),
            file_format=config.get("format"),
            batch_size=config.get("batch_size", 1000),
            max_records=config.get("max_records"),
        )

    async def extract(self, **params) -> AsyncIterator[list[dict[str, Any]]]:
        """Extract data from file.

        Yields:
            Batches of records.
        """
        if not self.path:
            raise ValueError("File path is required")

        extract_config = {
            "file_path": self.path,
            "format": self.file_format,
        }

        async for batch in self.extract_streaming(
            extract_config,
            {},
            {},
            batch_size=self.batch_size,
            max_records=self.max_records,
        ):
            yield batch

    def validate_config(self, extract_config: dict[str, Any]) -> None:
        """Validate file extractor configuration."""
        if "type" in extract_config and extract_config["type"] != "file":
            raise ValueError(
                f"FileExtractor requires type='file', got '{extract_config.get('type')}'"
            )

        file_path = extract_config.get("file_path")
        if not file_path:
            raise ValueError("File extractor requires 'file_path' in extract_config")

    async def extract_streaming(
        self,
        extract_config: dict[str, Any],
        params: dict[str, Any],
        headers: dict[str, Any],
        contract_dir: Any | None = None,
        batch_size: int = 1000,
        max_records: int | None = None,
        config_context: dict[str, Any] | None = None,
    ) -> AsyncIterator[list[dict[str, Any]]]:
        """Extract data from file(s) in batches.

        Supports single files, glob patterns, and compressed files (gzip, zip).
        """
        source_file = str(contract_dir / "extract.yaml") if contract_dir else None
        file_path = extract_config.get("file_path")
        if not file_path:
            raise ValueError("File extractor requires 'file_path' in extract_config")

        file_path = resolve_values(
            file_path, context=config_context, source_file=source_file
        )

        file_format = extract_config.get("format")
        if not file_format:
            file_format = self._detect_format(file_path)

        path = Path(file_path)
        if "*" in str(path) or "?" in str(path):
            files = list(path.parent.glob(path.name))
            if not files:
                raise FileNotFoundError(f"No files found matching pattern: {file_path}")
            logger.info("Found %s files matching pattern: %s", len(files), file_path)

            total_extracted = 0
            for item in sorted(files):
                if max_records and total_extracted >= max_records:
                    break

                logger.info("Processing file: %s", item)
                async for batch in self._extract_from_file(
                    item, file_format, batch_size, max_records, total_extracted
                ):
                    total_extracted += len(batch)
                    yield batch
                    if max_records and total_extracted >= max_records:
                        break
        else:
            if not path.exists():
                raise FileNotFoundError(f"File not found: {file_path}")

            async for batch in self._extract_from_file(
                path, file_format, batch_size, max_records, 0
            ):
                yield batch

    async def _extract_from_file(
        self,
        file_path: Path,
        file_format: str,
        batch_size: int,
        max_records: int | None,
        offset: int = 0,
    ) -> AsyncIterator[list[dict[str, Any]]]:
        """Extract data from a single file."""
        extracted_file = None
        if file_path.suffix == ".zip":
            with zipfile.ZipFile(file_path, "r") as zip_ref:
                file_list = zip_ref.namelist()
                if not file_list:
                    raise ValueError(f"Zip file is empty: {file_path}")
                extracted_file = zip_ref.extract(file_list[0])
                file_path = Path(extracted_file)

        try:
            gen = _FORMAT_DISPATCH[file_format](
                file_path, batch_size, max_records, offset, file_format
            )
            async for batch in gen:
                yield batch
        finally:
            if extracted_file and Path(extracted_file).exists():
                Path(extracted_file).unlink()

    def _detect_format(self, file_path: str) -> str:
        """Detect file format from extension."""
        path = Path(file_path)
        suffix = path.suffix.lower()

        if suffix in SUPPORTED_FORMATS:
            return SUPPORTED_FORMATS[suffix]

        if suffix == ".gz":
            stem_suffix = path.stem.split(".")[-1] if "." in path.stem else ""
            if f".{stem_suffix}" in SUPPORTED_FORMATS:
                return SUPPORTED_FORMATS[f".{stem_suffix}"]

        raise ValueError(f"Could not detect file format from extension: {suffix}")

    def _convert_pandas_types(self, record: dict[str, Any]) -> dict[str, Any]:
        """Convert pandas types to native Python types."""
        return convert_pandas_types(record)


# ------------------------------------------------------------------
# Format dispatch helpers -- thin wrappers that normalise signatures
# so ``_extract_from_file`` can call them uniformly.
# ------------------------------------------------------------------


async def _csv_dispatch(
    path: Path, batch_size: int, max_records: int | None, offset: int, fmt: str
) -> AsyncIterator[list[dict[str, Any]]]:
    """Dispatch to CSV/TSV extractor."""
    async for batch in extract_csv(path, batch_size, max_records, offset, fmt):
        yield batch


async def _json_dispatch(
    path: Path, batch_size: int, max_records: int | None, offset: int, _fmt: str
) -> AsyncIterator[list[dict[str, Any]]]:
    """Dispatch to JSON extractor."""
    async for batch in extract_json(path, batch_size, max_records, offset):
        yield batch


async def _jsonl_dispatch(
    path: Path, batch_size: int, max_records: int | None, offset: int, _fmt: str
) -> AsyncIterator[list[dict[str, Any]]]:
    """Dispatch to JSONL extractor."""
    async for batch in extract_jsonl(path, batch_size, max_records, offset):
        yield batch


async def _parquet_dispatch(
    path: Path, batch_size: int, max_records: int | None, offset: int, _fmt: str
) -> AsyncIterator[list[dict[str, Any]]]:
    """Dispatch to Parquet extractor."""
    async for batch in extract_parquet(path, batch_size, max_records, offset):
        yield batch


async def _excel_dispatch(
    path: Path, batch_size: int, max_records: int | None, offset: int, _fmt: str
) -> AsyncIterator[list[dict[str, Any]]]:
    """Dispatch to Excel extractor."""
    async for batch in extract_excel(path, batch_size, max_records, offset):
        yield batch


async def _xml_dispatch(
    path: Path, batch_size: int, max_records: int | None, offset: int, _fmt: str
) -> AsyncIterator[list[dict[str, Any]]]:
    """Dispatch to XML extractor."""
    async for batch in extract_xml(path, batch_size, max_records, offset):
        yield batch


def _unsupported_dispatch(fmt: str):
    """Create a dispatcher that raises for unknown formats."""

    async def _dispatch(
        path: Path, batch_size: int, max_records: int | None, offset: int, _fmt: str
    ) -> AsyncIterator[list[dict[str, Any]]]:
        raise ValueError(f"Unsupported file format: {fmt}")
        yield  # pragma: no cover -- make this an async generator

    return _dispatch


class _FormatDispatch(dict):
    """Dict subclass that returns an error dispatcher for unknown keys."""

    def __missing__(self, key: str):
        return _unsupported_dispatch(key)


_FORMAT_DISPATCH = _FormatDispatch(
    {
        "csv": _csv_dispatch,
        "tsv": _csv_dispatch,
        "json": _json_dispatch,
        "jsonl": _jsonl_dispatch,
        "parquet": _parquet_dispatch,
        "excel": _excel_dispatch,
        "xml": _xml_dispatch,
    }
)
