"""Google Cloud Storage extraction logic for the cloud storage extractor.

Provides ``extract_from_gcs`` -- an async generator that downloads blobs
from a GCS bucket and yields record batches via ``FileExtractor``.

This module is internal.  Use ``CloudStorageExtractor`` from
``pycharter.pipeline_generator.extractors.cloud_storage``.
"""

from __future__ import annotations

import logging
import tempfile
from collections.abc import AsyncIterator
from pathlib import Path
from typing import Any

from pycharter.pipeline_generator.extractors.file import FileExtractor

logger = logging.getLogger(__name__)

# Try to import GCS dependencies
try:
    from google.cloud import storage as gcs_storage

    GCS_AVAILABLE = True
except ImportError:
    GCS_AVAILABLE = False
    gcs_storage = None  # type: ignore[assignment]


async def extract_from_gcs(
    bucket: str,
    path: str,
    credentials: dict[str, Any] | None,
    file_format: str | None,
    batch_size: int,
    max_records: int | None,
    config_context: dict[str, Any] | None,
    source_file: str | None,
) -> AsyncIterator[list[dict[str, Any]]]:
    """Extract data from Google Cloud Storage.

    Downloads blobs from *bucket*/*path* to temporary files and delegates
    parsing to ``FileExtractor``.  Supports single-blob and prefix downloads.

    Args:
        bucket: GCS bucket name.
        path: Blob name or prefix (ending with ``/`` or containing ``*``).
        credentials: Optional service-account JSON path (str) or dict.
        file_format: Explicit file format (csv, json, parquet, ...).
        batch_size: Number of records per yielded batch.
        max_records: Stop after this many records (``None`` = unlimited).
        config_context: Variable-resolution context.
        source_file: Path used for variable resolution.

    Yields:
        Batches of parsed records.
    """
    if not GCS_AVAILABLE:
        raise ImportError(
            "google-cloud-storage is required for GCS extraction. "
            "Install with: pip install google-cloud-storage"
        )

    client = _build_gcs_client(credentials)
    bucket_obj = client.bucket(bucket)

    if path.endswith("/") or "*" in path:
        async for batch in _extract_gcs_prefix(
            bucket,
            bucket_obj,
            path,
            file_format,
            batch_size,
            max_records,
            config_context,
        ):
            yield batch
    else:
        async for batch in _extract_gcs_single(
            bucket_obj,
            path,
            file_format,
            batch_size,
            max_records,
            config_context,
        ):
            yield batch


def _build_gcs_client(credentials: dict[str, Any] | None) -> Any:
    """Build and return a GCS client, optionally with explicit credentials."""
    if not credentials:
        return gcs_storage.Client()

    if isinstance(credentials, str):
        return gcs_storage.Client.from_service_account_json(credentials)

    if isinstance(credentials, dict):
        import json as _json

        with tempfile.NamedTemporaryFile(mode="w", suffix=".json", delete=False) as tmp:
            _json.dump(credentials, tmp)
            tmp_path = tmp.name
        try:
            return gcs_storage.Client.from_service_account_json(tmp_path)
        finally:
            Path(tmp_path).unlink()

    return gcs_storage.Client()


async def _extract_gcs_prefix(
    bucket_name: str,
    bucket_obj: Any,
    path: str,
    file_format: str | None,
    batch_size: int,
    max_records: int | None,
    config_context: dict[str, Any] | None,
) -> AsyncIterator[list[dict[str, Any]]]:
    """Download and yield records from all blobs under a GCS prefix."""
    prefix = path.rstrip("/")
    if "*" in prefix:
        prefix = prefix.split("*")[0]

    blobs = bucket_obj.list_blobs(prefix=prefix)

    total_extracted = 0
    for blob in blobs:
        if max_records and total_extracted >= max_records:
            return

        logger.info("Processing GCS blob: %s/%s", bucket_name, blob.name)

        with tempfile.NamedTemporaryFile(
            delete=False, suffix=Path(blob.name).suffix
        ) as tmp_file:
            tmp_path = Path(tmp_file.name)
            try:
                blob.download_to_filename(tmp_file.name)

                file_extractor = FileExtractor()
                file_config = {
                    "type": "file",
                    "file_path": str(tmp_path),
                    "format": file_format,
                }

                async for batch in file_extractor.extract_streaming(
                    file_config,
                    {},
                    {},
                    None,
                    batch_size,
                    max_records,
                    config_context,
                ):
                    total_extracted += len(batch)
                    yield batch
                    if max_records and total_extracted >= max_records:
                        return
            finally:
                if tmp_path.exists():
                    tmp_path.unlink()


async def _extract_gcs_single(
    bucket_obj: Any,
    path: str,
    file_format: str | None,
    batch_size: int,
    max_records: int | None,
    config_context: dict[str, Any] | None,
) -> AsyncIterator[list[dict[str, Any]]]:
    """Download and yield records from a single GCS blob."""
    blob = bucket_obj.blob(path)
    with tempfile.NamedTemporaryFile(
        delete=False, suffix=Path(path).suffix
    ) as tmp_file:
        tmp_path = Path(tmp_file.name)
        try:
            blob.download_to_filename(tmp_file.name)

            file_extractor = FileExtractor()
            file_config = {
                "type": "file",
                "file_path": str(tmp_path),
                "format": file_format,
            }

            async for batch in file_extractor.extract_streaming(
                file_config,
                {},
                {},
                None,
                batch_size,
                max_records,
                config_context,
            ):
                yield batch
        finally:
            if tmp_path.exists():
                tmp_path.unlink()
