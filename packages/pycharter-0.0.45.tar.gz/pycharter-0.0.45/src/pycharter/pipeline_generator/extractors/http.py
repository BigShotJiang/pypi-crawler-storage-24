"""HTTP/API extractor for ETL orchestrator.

Handles HTTP-based data extraction with support for:
- GET and POST requests
- Retry logic with exponential backoff
- Rate limiting
- Pagination (page, offset, cursor, next_url, link_header)
- Response parsing (JSON, text)
- Path parameter substitution
"""

from __future__ import annotations

import logging
from collections.abc import AsyncIterator
from typing import Any

import httpx

from pycharter.pipeline_generator.extractors._http_helpers import (
    DEFAULT_BACKOFF_FACTOR,
    DEFAULT_MAX_ATTEMPTS,
    DEFAULT_RATE_LIMIT_DELAY,
    DEFAULT_RETRY_STATUS_CODES,
    DEFAULT_TIMEOUT_CONNECT,
    DEFAULT_TIMEOUT_POOL,
    DEFAULT_TIMEOUT_READ,
    DEFAULT_TIMEOUT_WRITE,
    RESPONSE_DATA_KEYS,
    build_request_url,
    check_custom_stop_condition,
    check_stop_condition,
    check_stop_conditions,
    configure_timeout,
    extract_by_path,
    extract_data_array,
    extract_link_header_url,
    get_path_param_names,
    make_http_request,
    resolve_rate_limit_delay,
)
from pycharter.pipeline_generator.extractors.base import BaseExtractor

logger = logging.getLogger(__name__)

# Re-export constants and helpers so existing ``from ...http import X``
# statements continue to work.
__all__ = [
    "DEFAULT_BACKOFF_FACTOR",
    "DEFAULT_MAX_ATTEMPTS",
    "DEFAULT_RATE_LIMIT_DELAY",
    "DEFAULT_RETRY_STATUS_CODES",
    "DEFAULT_TIMEOUT_CONNECT",
    "DEFAULT_TIMEOUT_POOL",
    "DEFAULT_TIMEOUT_READ",
    "DEFAULT_TIMEOUT_WRITE",
    "RESPONSE_DATA_KEYS",
    "HTTPExtractor",
    "get_path_param_names",
]


class HTTPExtractor(BaseExtractor):
    """Extractor for HTTP/API data sources.

    Supports two modes:
    1. Programmatic API:
        >>> extractor = HTTPExtractor(url="https://api.example.com/users")
        >>> async for batch in extractor.extract():
        ...     process(batch)

    2. Config-driven (legacy):
        >>> extractor = HTTPExtractor()
        >>> async for batch in extractor.extract_streaming(config, params, headers):
        ...     process(batch)
    """

    def __init__(
        self,
        url: str | None = None,
        base_url: str | None = None,
        endpoint: str | None = None,
        method: str = "GET",
        headers: dict[str, str] | None = None,
        params: dict[str, Any] | None = None,
        body: Any | None = None,
        response_path: str | None = None,
        batch_size: int = 1000,
        pagination: dict[str, Any] | None = None,
    ):
        self.url = url
        self.base_url = base_url or ""
        self.endpoint = endpoint or ""
        self.method = method
        self.headers = headers or {}
        self.params = params or {}
        self.body = body
        self.response_path = response_path
        self.batch_size = batch_size
        self.pagination = pagination or {}

    @classmethod
    def from_config(cls, config: dict[str, Any]) -> HTTPExtractor:
        """Create extractor from configuration dict."""
        return cls(
            url=config.get("url"),
            base_url=config.get("base_url", ""),
            endpoint=config.get("api_endpoint") or "",
            method=config.get("method", "GET"),
            headers=config.get("headers", {}),
            params=config.get("params", {}),
            body=config.get("body"),
            response_path=config.get("response_path"),
            batch_size=config.get("batch_size", 1000),
            pagination=config.get("pagination"),
        )

    async def extract(self, **params) -> AsyncIterator[list[dict[str, Any]]]:
        """Extract data from HTTP source.

        Yields:
            Batches of records.
        """
        extract_config = {
            "base_url": self.base_url,
            "api_endpoint": self.url or self.endpoint,
            "method": self.method,
            "response_path": self.response_path,
            "pagination": self.pagination,
        }
        merged_params = {**self.params, **params}
        async for batch in self.extract_streaming(
            extract_config,
            merged_params,
            self.headers,
            batch_size=self.batch_size,
        ):
            yield batch

    def validate_config(self, extract_config: dict[str, Any]) -> None:
        """Validate HTTP extractor configuration."""
        if "type" in extract_config and extract_config["type"] != "http":
            raise ValueError(
                f"HTTPExtractor requires type='http', got '{extract_config.get('type')}'"
            )
        api_endpoint = extract_config.get("api_endpoint", "")
        base_url = extract_config.get("base_url", "")
        if not base_url and not api_endpoint:
            raise ValueError(
                "HTTP extractor requires either 'api_endpoint' (with 'base_url') "
                "or 'api_endpoint' as full URL"
            )
        if (
            api_endpoint
            and not api_endpoint.startswith(("http://", "https://"))
            and not base_url
        ):
            raise ValueError(
                "HTTP extractor requires 'base_url' when 'api_endpoint' is a path, "
                "or 'api_endpoint' as full URL"
            )

    async def extract_streaming(
        self,
        extract_config: dict[str, Any],
        params: dict[str, Any],
        headers: dict[str, Any],
        contract_dir: Any | None = None,
        batch_size: int = 1000,
        max_records: int | None = None,
        config_context: dict[str, Any] | None = None,
    ) -> AsyncIterator[list[dict[str, Any]]]:
        """Extract data from HTTP/API source with pagination support.

        Yields batches as they are extracted, preventing memory exhaustion
        for large datasets.
        """
        pagination_config = extract_config.get("pagination", {})
        if not pagination_config.get("enabled", False):
            logger.debug("Pagination disabled, extracting all data in single request")
            all_data = await self._extract_with_retry(
                extract_config,
                params,
                headers,
                contract_dir,
                config_context=config_context,
            )
            if max_records:
                logger.debug(
                    "Limiting to %s records (extracted %s)",
                    max_records,
                    len(all_data),
                )
                all_data = all_data[:max_records]
            logger.debug(
                "Yielding %s records in batches of %s",
                len(all_data),
                batch_size,
            )
            for i in range(0, len(all_data), batch_size):
                batch = all_data[i : i + batch_size]
                logger.debug(
                    "Yielding batch %s with %s records",
                    i // batch_size + 1,
                    len(batch),
                )
                yield batch
            return
        async for batch in self._extract_with_pagination(
            extract_config,
            params,
            headers,
            contract_dir,
            batch_size,
            max_records,
            config_context,
        ):
            yield batch

    async def _extract_with_retry(
        self,
        extract_config: dict[str, Any],
        params: dict[str, Any],
        headers: dict[str, Any],
        contract_dir: Any | None = None,
        config_context: dict[str, Any] | None = None,
    ) -> list[dict[str, Any]]:
        """Extract data from API with retry logic."""
        extracted_data, _, _ = await self._extract_single_page(
            extract_config,
            params,
            headers,
            contract_dir,
            return_full_response=False,
            config_context=config_context,
        )
        return extracted_data

    async def _extract_single_page(
        self,
        extract_config: dict[str, Any],
        params: dict[str, Any],
        headers: dict[str, Any],
        contract_dir: Any | None = None,
        return_full_response: bool = False,
        config_context: dict[str, Any] | None = None,
    ) -> tuple[list[dict[str, Any]], Any | None, httpx.Response | None]:
        """Extract data from a single API request with retry logic."""
        from pycharter.pipeline_generator.extractors._http_request import (
            extract_single_page,
        )

        return await extract_single_page(
            extract_config,
            params,
            headers,
            contract_dir,
            return_full_response=return_full_response,
            config_context=config_context,
        )

    async def _extract_with_pagination(
        self,
        extract_config: dict[str, Any],
        params: dict[str, Any],
        headers: dict[str, Any],
        contract_dir: Any | None = None,
        batch_size: int = 1000,
        max_records: int | None = None,
        config_context: dict[str, Any] | None = None,
    ) -> AsyncIterator[list[dict[str, Any]]]:
        """Extract data with pagination support."""
        from pycharter.pipeline_generator.extractors._http_pagination import (
            extract_with_pagination,
        )

        async for batch in extract_with_pagination(
            self._extract_single_page,
            extract_config,
            params,
            headers,
            contract_dir,
            batch_size,
            max_records,
            config_context,
        ):
            yield batch

    # Backward-compatible delegating stubs for private helpers.
    def _resolve_rate_limit_delay(
        self, rate_limit_delay, contract_dir=None, config_context=None
    ):
        """Resolve and convert rate_limit_delay to float."""
        return resolve_rate_limit_delay(rate_limit_delay, contract_dir, config_context)

    def _build_request_url(self, base_url, api_endpoint, path_params=None):
        """Build full request URL from base URL and endpoint."""
        return build_request_url(base_url, api_endpoint, path_params)

    def _configure_timeout(self, timeout_config):
        """Configure HTTP timeout from config dictionary."""
        return configure_timeout(timeout_config)

    async def _make_http_request(self, client, method, url, params, headers, body=None):
        """Make HTTP request with specified method."""
        return await make_http_request(client, method, url, params, headers, body)

    def _extract_by_path(self, data, path):
        """Extract data using a simple path notation (e.g., 'data.items')."""
        return extract_by_path(data, path)

    def _extract_data_array(self, data):
        """Extract data array from response, handling common response structures."""
        return extract_data_array(data)

    def _check_stop_conditions(
        self, page_data, stop_conditions, params, response_data=None
    ):
        """Check if pagination should stop based on configured stop conditions."""
        return check_stop_conditions(page_data, stop_conditions, params, response_data)

    def _check_stop_condition(self, condition, page_data, params, response_data=None):
        """Check a single stop condition."""
        return check_stop_condition(condition, page_data, params, response_data)

    def _check_custom_stop_condition(self, condition, response_data):
        """Check custom stop condition based on response path."""
        return check_custom_stop_condition(condition, response_data)

    def _extract_link_header_url(self, response):
        """Extract next URL from Link header (RFC 5988)."""
        return extract_link_header_url(response)
