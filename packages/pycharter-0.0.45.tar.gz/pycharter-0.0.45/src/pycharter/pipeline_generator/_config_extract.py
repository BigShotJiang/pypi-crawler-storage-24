"""Pydantic models for ETL extract stage configuration."""

from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field

from pycharter.pipeline_generator._config_enums import (
    FileFormat,
    HTTPMethod,
    PaginationStrategy,
    ResponseFormat,
)
from pycharter.pipeline_generator._config_shared import (
    CloudStorageConfig,
    CSVOptions,
    DatabaseConfig,
    ExtractValidationConfig,
    IncrementalConfig,
    JSONOptions,
    SSHTunnelConfig,
)


class PaginationConfig(BaseModel):
    """HTTP pagination configuration."""

    model_config = ConfigDict(extra="forbid")

    enabled: bool = False
    strategy: PaginationStrategy | None = None
    page_param: str | None = None
    offset_param: str | None = None
    limit_param: str | None = None
    cursor_param: str | None = None
    cursor_path: str | None = None
    next_link_path: str | None = None
    page_size: int | None = Field(None, ge=1)
    max_pages: int | None = Field(None, ge=1)


class RetryConfig(BaseModel):
    """HTTP retry configuration."""

    model_config = ConfigDict(extra="forbid")

    max_attempts: int = Field(3, ge=1)
    backoff_factor: float = Field(2.0, ge=0)
    retry_on_status: list[int] = Field(
        default_factory=lambda: [429, 500, 502, 503, 504]
    )


class TimeoutConfig(BaseModel):
    """HTTP timeout configuration."""

    model_config = ConfigDict(extra="ignore")

    connect: float | None = Field(None, ge=0)
    read: float | None = Field(None, ge=0)
    write: float | None = Field(None, ge=0)


class InputParamConfig(BaseModel):
    """Declaration for a single pipeline input parameter."""

    model_config = ConfigDict(extra="allow")

    type: str = "string"
    required: bool = False
    default: Any | None = None
    description: str = ""


class HTTPExtractConfig(BaseModel):
    """HTTP extraction configuration."""

    model_config = ConfigDict(extra="forbid")

    type: Literal["http"] = "http"
    url: str | None = None
    base_url: str | None = None
    api_endpoint: str | None = None
    method: HTTPMethod = HTTPMethod.GET
    headers: dict[str, str] | None = None
    params: dict[str, Any] | None = None
    body: dict[str, Any] | None = None
    response_format: ResponseFormat = ResponseFormat.JSON
    response_path: str | None = None
    pagination: PaginationConfig | None = None
    retry: RetryConfig | None = None
    timeout: TimeoutConfig | None = None
    rate_limit_delay: float | None = Field(None, ge=0)
    max_calls_per_minute: int | None = Field(None, ge=1)
    batch_size: int = Field(1000, ge=1)
    validation: ExtractValidationConfig | None = None
    input_params: dict[str, InputParamConfig] | None = Field(
        None,
        description="Declared input parameters with type, required, default, and description. "
        "Example: {type: {type: string, required: true, description: 'gainers or losers'}}",
    )
    default_param_values: dict[str, str | list[str]] | None = Field(
        None,
        description="Default values for path parameters. Scalar for single-run, list for run_bulk(). "
        "Example: {type: gainers} or {symbol: [AAPL, MSFT, GOOGL]}",
    )
    incremental: IncrementalConfig | None = None


class FileExtractConfig(BaseModel):
    """File extraction configuration."""

    model_config = ConfigDict(extra="forbid")

    type: Literal["file"] = "file"
    path: str
    format: FileFormat | None = None
    csv_options: CSVOptions | None = None
    json_options: JSONOptions | None = None
    batch_size: int = Field(1000, ge=1)
    validation: ExtractValidationConfig | None = None
    incremental: IncrementalConfig | None = None


class DatabaseExtractConfig(BaseModel):
    """Database extraction configuration."""

    model_config = ConfigDict(extra="forbid")

    type: Literal["database"] = "database"
    query: str
    connection_string: str | None = None
    database: DatabaseConfig | None = None
    query_params: dict[str, Any] | None = None
    ssh_tunnel: SSHTunnelConfig | None = None
    batch_size: int = Field(1000, ge=1)
    validation: ExtractValidationConfig | None = None
    incremental: IncrementalConfig | None = None


class CloudStorageExtractConfig(BaseModel):
    """Cloud storage extraction configuration."""

    model_config = ConfigDict(extra="forbid")

    type: Literal["cloud_storage"] = "cloud_storage"
    storage: CloudStorageConfig
    format: FileFormat | None = None
    batch_size: int = Field(1000, ge=1)
    validation: ExtractValidationConfig | None = None
    incremental: IncrementalConfig | None = None


class SSEExtractConfig(BaseModel):
    """SSE (Server-Sent Events) extraction configuration."""

    model_config = ConfigDict(extra="forbid")

    type: Literal["sse"] = "sse"
    url: str
    headers: dict[str, str] | None = None
    event_filter: str | None = None
    data_format: Literal["json", "text"] = "json"
    batch_size: int = Field(1000, ge=1)
    batch_timeout: float = Field(5.0, ge=0)
    reconnect: bool = True
    reconnect_delay: float = Field(3.0, ge=0)
    max_reconnects: int = Field(10, ge=0)
    max_records: int | None = None
    max_batches: int | None = None
    validation: ExtractValidationConfig | None = None


class WebSocketExtractConfig(BaseModel):
    """WebSocket extraction configuration."""

    model_config = ConfigDict(extra="forbid")

    type: Literal["websocket"] = "websocket"
    url: str
    headers: dict[str, str] | None = None
    subscribe_messages: list[dict[str, Any] | str] | None = None
    data_format: Literal["json", "text"] = "json"
    ping_interval: float | None = 20.0
    batch_size: int = Field(1000, ge=1)
    batch_timeout: float = Field(5.0, ge=0)
    reconnect: bool = True
    reconnect_delay: float = Field(3.0, ge=0)
    max_reconnects: int = Field(10, ge=0)
    max_records: int | None = None
    max_batches: int | None = None
    validation: ExtractValidationConfig | None = None


class FileWatcherExtractConfig(BaseModel):
    """File watcher extraction configuration."""

    model_config = ConfigDict(extra="forbid")

    type: Literal["file_watcher"] = "file_watcher"
    watch_dir: str
    patterns: list[str] | None = None
    file_format: str | None = None
    recursive: bool = False
    poll_interval: float = Field(1.0, ge=0.1)
    process_existing: bool = False
    move_after_process: str | None = None
    batch_size: int = Field(1000, ge=1)
    max_records: int | None = None
    validation: ExtractValidationConfig | None = None


class KafkaExtractConfig(BaseModel):
    """Kafka extraction configuration."""

    model_config = ConfigDict(extra="forbid")

    type: Literal["kafka"] = "kafka"
    topics: list[str]
    bootstrap_servers: str = "localhost:9092"
    consumer_group: str = "pycharter"
    data_format: str = "json"
    auto_offset_reset: str = "earliest"
    security_protocol: str = "PLAINTEXT"
    sasl_mechanism: str | None = None
    sasl_username: str | None = None
    sasl_password: str | None = None
    ssl_cafile: str | None = None
    batch_size: int = Field(1000, ge=1)
    batch_timeout: float = Field(5.0, ge=0)
    poll_timeout: float = Field(1.0, ge=0)
    max_records: int | None = None
    max_batches: int | None = None
    validation: ExtractValidationConfig | None = None


class RabbitMQExtractConfig(BaseModel):
    """RabbitMQ extraction configuration."""

    model_config = ConfigDict(extra="forbid")

    type: Literal["rabbitmq"] = "rabbitmq"
    queue: str
    url: str = "amqp://guest:guest@localhost/"
    exchange: str = ""
    routing_key: str = ""
    prefetch_count: int = Field(100, ge=1)
    data_format: str = "json"
    batch_size: int = Field(1000, ge=1)
    batch_timeout: float = Field(5.0, ge=0)
    max_records: int | None = None
    max_batches: int | None = None
    validation: ExtractValidationConfig | None = None


class SQSExtractConfig(BaseModel):
    """SQS extraction configuration."""

    model_config = ConfigDict(extra="forbid")

    type: Literal["sqs"] = "sqs"
    queue_url: str
    region: str = "us-east-1"
    max_messages_per_poll: int = Field(10, ge=1, le=10)
    wait_time_seconds: int = Field(20, ge=0)
    visibility_timeout: int = Field(300, ge=0)
    data_format: str = "json"
    batch_size: int = Field(1000, ge=1)
    batch_timeout: float = Field(5.0, ge=0)
    max_records: int | None = None
    max_batches: int | None = None
    validation: ExtractValidationConfig | None = None


# Union type for extract config - use discriminator on 'type'
ExtractConfig = (
    HTTPExtractConfig
    | FileExtractConfig
    | DatabaseExtractConfig
    | CloudStorageExtractConfig
    | SSEExtractConfig
    | WebSocketExtractConfig
    | FileWatcherExtractConfig
    | KafkaExtractConfig
    | RabbitMQExtractConfig
    | SQSExtractConfig
)
