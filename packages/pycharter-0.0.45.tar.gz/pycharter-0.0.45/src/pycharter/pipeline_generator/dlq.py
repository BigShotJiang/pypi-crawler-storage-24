"""Dead Letter Queue (DLQ) for ETL pipelines.

Captures and stores failed records that cannot be processed during ETL
operations.  This allows for later analysis, debugging, and potential
retry of failed records.

Core data types (:class:`DLQReason`, :class:`DeadLetterRecord`) live in
:mod:`_dlq_core` and are re-exported here for backward compatibility.
"""

from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Any

from pycharter.pipeline_generator._dlq_core import (
    DeadLetterRecord,  # noqa: F401 — public re-export
    DLQReason,  # noqa: F401 — public re-export
)

logger = logging.getLogger(__name__)


class DeadLetterQueue:
    """Dead Letter Queue for failed ETL records.

    Supports multiple storage backends:
    - database: Store in PostgreSQL/other database
    - file: Store as JSON files
    - memory: In-memory only (for testing)
    """

    def __init__(
        self,
        db_session: Any | None = None,
        storage_backend: str = "database",
        storage_path: str | None = None,
        enabled: bool = True,
        schema_name: str | None = None,
    ):
        """Initialize Dead Letter Queue.

        Args:
            db_session: Database session for database backend.
            storage_backend: Backend type (``"database"``, ``"file"``, ``"memory"``).
            storage_path: Path for file backend.
            enabled: Whether DLQ is enabled.
            schema_name: Database schema name for DLQ table.
        """
        self.db_session = db_session
        self.storage_backend = storage_backend
        self.storage_path = Path(storage_path) if storage_path else None
        self.enabled = enabled
        self.schema_name = schema_name
        self._in_memory_queue: list[DeadLetterRecord] = []

        if storage_backend == "file" and not storage_path:
            raise ValueError("storage_path is required for file backend")

        if storage_backend == "file" and self.storage_path:
            self.storage_path.mkdir(parents=True, exist_ok=True)

    async def add_record(
        self,
        pipeline_name: str,
        record_data: dict[str, Any],
        reason: DLQReason,
        error_message: str,
        error_type: str,
        stage: str,
        metadata: dict[str, Any] | None = None,
        record_id: str | None = None,
    ) -> DeadLetterRecord | None:
        """Add a failed record to the DLQ.

        Args:
            pipeline_name: Name of the pipeline.
            record_data: The failed record data.
            reason: Reason for failure.
            error_message: Error message.
            error_type: Error type.
            stage: ETL stage.
            metadata: Additional metadata.
            record_id: Optional record identifier.

        Returns:
            DeadLetterRecord if added, None if DLQ is disabled.
        """
        if not self.enabled:
            return None

        try:
            dlq_record = DeadLetterRecord(
                pipeline_name=pipeline_name,
                record_data=record_data,
                reason=reason,
                error_message=error_message,
                error_type=error_type,
                stage=stage,
                metadata=metadata,
                record_id=record_id,
            )

            if self.storage_backend == "database" and self.db_session:
                await self._persist_to_database(dlq_record)
            elif self.storage_backend == "file" and self.storage_path:
                await self._persist_to_file(dlq_record)
            else:
                self._in_memory_queue.append(dlq_record)

            logger.debug(
                "Added record to DLQ: %s (pipeline=%s, reason=%s, stage=%s)",
                dlq_record.id,
                pipeline_name,
                reason.value,
                stage,
            )
            return dlq_record
        except Exception as e:
            logger.error("Failed to add record to DLQ: %s", e, exc_info=True)
            # Don't fail the pipeline if DLQ write fails
            return None

    async def add_batch(
        self,
        pipeline_name: str,
        batch: list[dict[str, Any]],
        reason: DLQReason,
        error_message: str,
        error_type: str,
        stage: str,
        metadata: dict[str, Any] | None = None,
    ) -> list[DeadLetterRecord]:
        """Add multiple failed records to the DLQ.

        Args:
            pipeline_name: Name of the pipeline.
            batch: List of failed records.
            reason: Reason for failure.
            error_message: Error message.
            error_type: Error type.
            stage: ETL stage.
            metadata: Additional metadata.

        Returns:
            List of DeadLetterRecord objects.
        """
        if not self.enabled or not batch:
            return []

        records = []
        for idx, record_data in enumerate(batch):
            record_metadata = {**(metadata or {}), "batch_index": idx}
            dlq_record = await self.add_record(
                pipeline_name=pipeline_name,
                record_data=record_data,
                reason=reason,
                error_message=error_message,
                error_type=error_type,
                stage=stage,
                metadata=record_metadata,
            )
            if dlq_record:
                records.append(dlq_record)

        logger.info(
            "Added %s records to DLQ for pipeline %s (reason=%s, stage=%s)",
            len(records),
            pipeline_name,
            reason.value,
            stage,
        )
        return records

    async def _persist_to_database(self, record: DeadLetterRecord) -> None:
        """Persist record to database using configurable schema."""
        from pycharter.pipeline_generator._dlq_database import persist_to_database

        await persist_to_database(self.db_session, record, self.schema_name)

    async def _persist_to_file(self, record: DeadLetterRecord) -> None:
        """Persist record to file."""
        try:
            # Create filename with timestamp and ID
            timestamp_str = record.timestamp.strftime("%Y%m%d_%H%M%S")
            filename = f"{record.pipeline_name}_{timestamp_str}_{record.id}.json"
            filepath = self.storage_path / filename

            with open(filepath, "w") as f:
                json.dump(record.to_dict(), f, indent=2, default=str)

            logger.debug("Persisted DLQ record to file: %s", filepath)
        except Exception as e:
            logger.error("Failed to persist DLQ record to file: %s", e, exc_info=True)
            raise

    def get_records(
        self,
        pipeline_name: str | None = None,
        reason: DLQReason | None = None,
        stage: str | None = None,
        status: str | None = None,
        limit: int = 100,
    ) -> list[DeadLetterRecord]:
        """Query DLQ records.

        Args:
            pipeline_name: Filter by pipeline name.
            reason: Filter by reason.
            stage: Filter by stage.
            status: Filter by status.
            limit: Maximum number of records to return.

        Returns:
            List of DeadLetterRecord objects.
        """
        if self.storage_backend == "database" and self.db_session:
            from pycharter.pipeline_generator._dlq_database import query_from_database

            return query_from_database(
                self.db_session,
                self.schema_name,
                pipeline_name,
                reason,
                stage,
                status,
                limit,
            )
        elif self.storage_backend == "file" and self.storage_path:
            from pycharter.pipeline_generator._dlq_database import query_from_files

            return query_from_files(
                self.storage_path,
                pipeline_name,
                reason,
                stage,
                status,
                limit,
            )
        else:
            return self._query_from_memory(pipeline_name, reason, stage, status, limit)

    def _query_from_memory(
        self,
        pipeline_name: str | None,
        reason: DLQReason | None,
        stage: str | None,
        status: str | None,
        limit: int,
    ) -> list[DeadLetterRecord]:
        """Query records from memory."""
        records = self._in_memory_queue

        # Apply filters
        if pipeline_name:
            records = [r for r in records if r.pipeline_name == pipeline_name]
        if reason:
            records = [r for r in records if r.reason == reason]
        if stage:
            records = [r for r in records if r.stage == stage]
        if status:
            records = [r for r in records if r.status == status]

        return records[:limit]

    async def retry_record(self, record_id: str) -> bool:
        """Mark a record for retry.

        Args:
            record_id: ID of the record to retry.

        Returns:
            True if successful, False otherwise.
        """
        if self.storage_backend == "database" and self.db_session:
            from pycharter.pipeline_generator._dlq_database import (
                retry_record_in_database,
            )

            return await retry_record_in_database(
                self.db_session,
                self.schema_name,
                record_id,
            )
        elif self.storage_backend == "memory":
            for record in self._in_memory_queue:
                if record.id == record_id:
                    record.status = "retrying"
                    record.retry_count += 1
                    return True

        return False

    def get_statistics(
        self,
        pipeline_name: str | None = None,
    ) -> dict[str, Any]:
        """Get DLQ statistics.

        Args:
            pipeline_name: Optional pipeline name filter.

        Returns:
            Dictionary with statistics.
        """
        if self.storage_backend == "database" and self.db_session:
            from pycharter.pipeline_generator._dlq_database import (
                get_statistics_from_database,
            )

            return get_statistics_from_database(
                self.db_session,
                self.schema_name,
                pipeline_name,
            )
        else:
            # Memory or file backend - simple count
            records = self._in_memory_queue if self.storage_backend == "memory" else []
            if pipeline_name:
                records = [r for r in records if r.pipeline_name == pipeline_name]

            return {
                "total": len(records),
                "by_reason": {},
                "by_stage": {},
                "by_status": {},
            }
