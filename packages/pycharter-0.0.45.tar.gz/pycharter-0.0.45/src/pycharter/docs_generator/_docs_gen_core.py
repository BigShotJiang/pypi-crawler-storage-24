"""Core documentation generation logic.

Contains the DocsGenerator class and the ``generate_docs`` convenience
function.
"""

from __future__ import annotations

from typing import Any

from pycharter.contract_builder.types import DataContract
from pycharter.contract_parser import ContractMetadata
from pycharter.docs_generator._docs_gen_templates import (
    build_field_row,
    format_config,
    format_governance,
    format_metadata_dict,
    format_ownership,
    format_versions,
    get_coercion_description,
)
from pycharter.docs_generator.renderers import DocsRenderer, MarkdownRenderer


class DocsGenerator:
    """Generate documentation from data contracts.

    Transforms ContractMetadata objects into human-readable documentation
    in various formats (Markdown, HTML, etc.).

    Example:
        >>> from pycharter import parse_contract_file
        >>> from pycharter.docs_generator import DocsGenerator
        >>>
        >>> contract = parse_contract_file("contract.yaml")
        >>> generator = DocsGenerator()
        >>> docs = generator.generate(contract)
        >>> print(docs)
    """

    def __init__(self, renderer: DocsRenderer | None = None):
        """Initialize the documentation generator.

        Args:
            renderer: Renderer to use for output format. Defaults to MarkdownRenderer.
        """
        self.renderer = renderer or MarkdownRenderer()

    def generate(
        self,
        contract: ContractMetadata,
        include_schema: bool = True,
        include_coercions: bool = True,
        include_validations: bool = True,
        include_metadata: bool = True,
    ) -> str:
        """Generate full documentation for a contract.

        Args:
            contract: ContractMetadata object to document.
            include_schema: Include schema field documentation.
            include_coercions: Include coercion rules documentation.
            include_validations: Include validation rules documentation.
            include_metadata: Include metadata/ownership documentation.

        Returns:
            Generated documentation as string.
        """
        parts: list[str] = []

        schema = getattr(contract, "json_schema", None) or getattr(
            contract, "schema", None
        )
        title = self._get_title(contract)
        version = contract.versions.get("schema") or (
            schema.get("version") if schema else None
        )

        parts.append(self.renderer.render_header(title, version))

        description = (schema or {}).get("description") or (
            contract.metadata or {}
        ).get("description")
        if description:
            parts.append(self.renderer.render_description(description))

        if include_schema and schema:
            parts.append(self.generate_schema_section(schema))

        if include_coercions and contract.coercion_rules:
            parts.append(self.generate_coercion_section(contract.coercion_rules))

        if include_validations and contract.validation_rules:
            parts.append(self.generate_validation_section(contract.validation_rules))

        if include_metadata and contract.metadata:
            parts.append(self.generate_metadata_section(contract))

        if hasattr(self.renderer, "render_footer"):
            parts.append(self.renderer.render_footer())

        return "".join(parts)

    def generate_schema_section(self, schema: dict[str, Any]) -> str:
        """Generate documentation for schema fields.

        Args:
            schema: JSON Schema dictionary.

        Returns:
            Formatted schema documentation.
        """
        properties = schema.get("properties", {})
        required = set(schema.get("required", []))

        if not properties:
            return ""

        headers = ["Field", "Type", "Required", "Description", "Constraints"]
        rows = []

        for field_name, field_def in properties.items():
            row = build_field_row(field_name, field_def, field_name in required)
            rows.append(row)

        table = self.renderer.render_table(headers, rows)
        return self.renderer.render_section("Schema Fields", table)

    def generate_coercion_section(self, rules: dict[str, Any]) -> str:
        """Generate documentation for coercion rules.

        Args:
            rules: Coercion rules dictionary.

        Returns:
            Formatted coercion documentation.
        """
        coercion_rules = {k: v for k, v in rules.items() if k != "version"}

        if not coercion_rules:
            return ""

        headers = ["Field", "Coercion", "Description"]
        rows: list[list[str]] = []

        for field, coercion in coercion_rules.items():
            if isinstance(coercion, str):
                coercion_name = coercion
                description = get_coercion_description(coercion_name)
            elif isinstance(coercion, dict):
                coercion_name = coercion.get("type", str(coercion))
                description = coercion.get(
                    "description", get_coercion_description(coercion_name)
                )
            else:
                coercion_name = str(coercion)
                description = ""

            rows.append([f"`{field}`", f"`{coercion_name}`", description])

        content = self.renderer.render_description(
            "Coercions are applied before validation to transform incoming data."
        )
        content += self.renderer.render_table(headers, rows)
        return self.renderer.render_section("Coercion Rules", content)

    def generate_validation_section(self, rules: dict[str, Any]) -> str:
        """Generate documentation for validation rules.

        Args:
            rules: Validation rules dictionary.

        Returns:
            Formatted validation documentation.
        """
        validation_rules = {k: v for k, v in rules.items() if k != "version"}

        if not validation_rules:
            return ""

        headers = ["Field", "Validation", "Configuration"]
        rows: list[list[str]] = []

        for field, validations in validation_rules.items():
            if isinstance(validations, dict):
                for val_name, val_config in validations.items():
                    config_str = format_config(val_config)
                    rows.append([f"`{field}`", f"`{val_name}`", config_str])
            elif isinstance(validations, str):
                rows.append([f"`{field}`", f"`{validations}`", ""])
            elif isinstance(validations, list):
                for val in validations:
                    rows.append([f"`{field}`", f"`{val}`", ""])

        content = self.renderer.render_description(
            "Validations are applied after coercion to ensure data meets requirements."
        )
        content += self.renderer.render_table(headers, rows)
        return self.renderer.render_section("Validation Rules", content)

    def generate_metadata_section(self, contract: ContractMetadata) -> str:
        """Generate documentation for contract metadata.

        Args:
            contract: ContractMetadata object.

        Returns:
            Formatted metadata documentation.
        """
        parts: list[str] = []

        if contract.ownership:
            ownership_content = format_ownership(self.renderer, contract.ownership)
            parts.append(self.renderer.render_section("Ownership", ownership_content))

        if contract.governance_rules:
            governance_content = format_governance(
                self.renderer, contract.governance_rules
            )
            parts.append(
                self.renderer.render_section("Governance Rules", governance_content)
            )

        if contract.versions:
            version_content = format_versions(self.renderer, contract.versions)
            parts.append(
                self.renderer.render_section("Version Information", version_content)
            )

        other_metadata = {
            k: v
            for k, v in contract.metadata.items()
            if k not in ["ownership", "governance_rules", "version"]
        }
        if other_metadata:
            other_content = format_metadata_dict(self.renderer, other_metadata)
            parts.append(
                self.renderer.render_section("Additional Metadata", other_content)
            )

        return "".join(parts)

    def _get_title(self, contract: ContractMetadata | DataContract) -> str:
        """Extract title from contract."""
        schema = getattr(contract, "json_schema", None) or getattr(
            contract, "schema", None
        )
        if not schema:
            return "Data Contract Documentation"
        if "title" in schema:
            return schema["title"]
        if (
            hasattr(contract, "metadata")
            and contract.metadata
            and "title" in contract.metadata
        ):
            return contract.metadata["title"]
        if "$id" in schema:
            return schema["$id"]
        return "Data Contract Documentation"


def generate_docs(
    contract: ContractMetadata | dict[str, Any],
    format: str = "markdown",
    **kwargs,
) -> str:
    """Convenience function to generate documentation from a contract.

    Args:
        contract: ContractMetadata object or contract dictionary.
        format: Output format ('markdown' or 'html').
        **kwargs: Additional options passed to DocsGenerator.generate().

    Returns:
        Generated documentation as string.
    """
    from pycharter.docs_generator.renderers import HTMLRenderer, MarkdownRenderer

    if isinstance(contract, dict):
        from pycharter.contract_parser import parse_contract

        contract = parse_contract(contract, validate=False)

    if format.lower() == "html":
        renderer = HTMLRenderer()
    else:
        renderer = MarkdownRenderer()

    generator = DocsGenerator(renderer=renderer)
    return generator.generate(contract, **kwargs)
