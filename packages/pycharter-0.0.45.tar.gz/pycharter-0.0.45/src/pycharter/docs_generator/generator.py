"""Documentation Generator - Core generation logic.

Re-export shim -- the actual definitions live in:
- ``_docs_gen_core`` (DocsGenerator class and generate_docs function)
- ``_docs_gen_templates`` (formatting and template helpers)

All public names are re-exported here so that existing
``from pycharter.docs_generator.generator import X`` imports
continue to work unchanged.
"""

from __future__ import annotations

from pycharter.docs_generator._docs_gen_core import (
    DocsGenerator,
    generate_docs,
)

__all__ = [
    "DocsGenerator",
    "generate_docs",
]
