"""Formatting and template helpers for documentation generation.

Contains private helper methods extracted from DocsGenerator for
building field rows, formatting ownership/governance/version tables,
and the convenience ``generate_docs`` function.
"""

from __future__ import annotations

import json
from typing import Any

from pycharter.docs_generator.renderers import DocsRenderer


def get_field_type(field_def: dict[str, Any]) -> str:
    """Extract field type from a JSON Schema field definition.

    Args:
        field_def: Single JSON Schema property definition.

    Returns:
        Human-readable type string.
    """
    if "type" in field_def:
        base_type = field_def["type"]
        if base_type == "array" and "items" in field_def:
            items_type = get_field_type(field_def["items"])
            return f"array[{items_type}]"
        return base_type
    if "anyOf" in field_def:
        types = [get_field_type(t) for t in field_def["anyOf"]]
        return " | ".join(types)
    if "oneOf" in field_def:
        types = [get_field_type(t) for t in field_def["oneOf"]]
        return " | ".join(types)
    if "$ref" in field_def:
        return f"ref: {field_def['$ref']}"
    return "any"


def get_field_constraints(field_def: dict[str, Any]) -> str:
    """Extract constraints from a JSON Schema field definition.

    Args:
        field_def: Single JSON Schema property definition.

    Returns:
        Semicolon-separated constraint summary string.
    """
    constraints: list[str] = []

    # String constraints
    if "minLength" in field_def:
        constraints.append(f"minLength: {field_def['minLength']}")
    if "maxLength" in field_def:
        constraints.append(f"maxLength: {field_def['maxLength']}")
    if "pattern" in field_def:
        constraints.append(f"pattern: `{field_def['pattern']}`")
    if "format" in field_def:
        constraints.append(f"format: {field_def['format']}")

    # Number constraints
    if "minimum" in field_def:
        constraints.append(f"min: {field_def['minimum']}")
    if "maximum" in field_def:
        constraints.append(f"max: {field_def['maximum']}")
    if "exclusiveMinimum" in field_def:
        constraints.append(f"exclusiveMin: {field_def['exclusiveMinimum']}")
    if "exclusiveMaximum" in field_def:
        constraints.append(f"exclusiveMax: {field_def['exclusiveMaximum']}")
    if "multipleOf" in field_def:
        constraints.append(f"multipleOf: {field_def['multipleOf']}")

    # Enum
    if "enum" in field_def:
        enum_vals = ", ".join(str(v) for v in field_def["enum"][:5])
        if len(field_def["enum"]) > 5:
            enum_vals += "..."
        constraints.append(f"enum: [{enum_vals}]")

    # Default
    if "default" in field_def:
        constraints.append(f"default: {field_def['default']}")

    return "; ".join(constraints) if constraints else ""


def build_field_row(
    field_name: str, field_def: dict[str, Any], is_required: bool
) -> list[str]:
    """Build a table row for a schema field.

    Args:
        field_name: The field name.
        field_def: JSON Schema property definition.
        is_required: Whether the field is required.

    Returns:
        List of cell values for the table row.
    """
    field_type = get_field_type(field_def)
    required_str = "Yes" if is_required else "No"
    description = field_def.get("description", "")
    constraints = get_field_constraints(field_def)
    return [f"`{field_name}`", field_type, required_str, description, constraints]


def get_coercion_description(coercion_name: str) -> str:
    """Get description for built-in coercion types.

    Args:
        coercion_name: Name of the coercion function.

    Returns:
        Human-readable description or empty string.
    """
    descriptions = {
        "to_string": "Convert value to string",
        "to_integer": "Convert value to integer",
        "to_float": "Convert value to float",
        "to_number": "Convert value to number",
        "to_boolean": "Convert value to boolean",
        "to_datetime": "Parse value as datetime",
        "to_date": "Parse value as date",
        "trim": "Remove leading/trailing whitespace",
        "lowercase": "Convert to lowercase",
        "uppercase": "Convert to uppercase",
        "strip_html": "Remove HTML tags",
        "normalize_whitespace": "Normalize whitespace characters",
    }
    return descriptions.get(coercion_name, "")


def format_config(config: Any) -> str:
    """Format validation configuration for display.

    Args:
        config: Validation configuration value.

    Returns:
        Formatted string representation.
    """
    if config is None:
        return ""
    if isinstance(config, bool):
        return "enabled" if config else "disabled"
    if isinstance(config, int | float | str):
        return str(config)
    if isinstance(config, dict):
        parts = [f"{k}={v}" for k, v in config.items()]
        return ", ".join(parts)
    if isinstance(config, list):
        return ", ".join(str(v) for v in config)
    return str(config)


def format_ownership(renderer: DocsRenderer, ownership: dict[str, Any]) -> str:
    """Format ownership information as a rendered table.

    Args:
        renderer: DocsRenderer instance for output formatting.
        ownership: Ownership dictionary.

    Returns:
        Rendered ownership table.
    """
    headers = ["Role", "Contact"]
    rows: list[list[str]] = []

    role_labels = {
        "business_owners": "Business Owners",
        "bu_sme": "Business Unit SME",
        "it_application_owners": "IT Application Owners",
        "it_sme": "IT SME",
        "support_lead": "Support Lead",
        "owner": "Owner",
        "team": "Team",
    }

    for key, value in ownership.items():
        label = role_labels.get(key, key.replace("_", " ").title())
        if isinstance(value, list):
            value_str = ", ".join(str(v) for v in value)
        else:
            value_str = str(value)
        rows.append([label, value_str])

    return renderer.render_table(headers, rows)


def format_governance(renderer: DocsRenderer, governance: dict[str, Any]) -> str:
    """Format governance rules as a rendered table.

    Args:
        renderer: DocsRenderer instance for output formatting.
        governance: Governance rules dictionary.

    Returns:
        Rendered governance table.
    """
    headers = ["Rule", "Configuration"]
    rows: list[list[str]] = []

    for rule, config in governance.items():
        rule_label = rule.replace("_", " ").title()
        config_str = format_config(config)
        rows.append([rule_label, config_str])

    return renderer.render_table(headers, rows)


def format_versions(renderer: DocsRenderer, versions: dict[str, str | None]) -> str:
    """Format version information as a rendered table.

    Args:
        renderer: DocsRenderer instance for output formatting.
        versions: Versions dictionary.

    Returns:
        Rendered versions table.
    """
    headers = ["Component", "Version"]
    rows = [[comp.replace("_", " ").title(), ver] for comp, ver in versions.items()]
    return renderer.render_table(headers, rows)


def format_metadata_dict(renderer: DocsRenderer, metadata: dict[str, Any]) -> str:
    """Format a metadata dictionary as a rendered table.

    Args:
        renderer: DocsRenderer instance for output formatting.
        metadata: Arbitrary metadata dictionary.

    Returns:
        Rendered metadata table.
    """
    headers = ["Property", "Value"]
    rows: list[list[str]] = []
    for key, value in metadata.items():
        if isinstance(value, dict | list):
            value_str = json.dumps(value, indent=2)
        else:
            value_str = str(value)
        rows.append([key.replace("_", " ").title(), value_str])
    return renderer.render_table(headers, rows)
