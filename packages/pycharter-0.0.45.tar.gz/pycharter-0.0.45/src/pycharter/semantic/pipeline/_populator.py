"""
Graph populator — converts validated records into RDF triples.

Mints URIs per class mappings, assigns ``rdf:type``, and converts
field values to triples. Supports incremental population (adds to
an existing graph).
"""

from __future__ import annotations

import logging
import time
from typing import Any
from urllib.parse import quote

from pycharter.semantic.linkml._loader import LinkMLSchema
from pycharter.semantic.shared.protocols import GraphStore
from pycharter.semantic.shared.results import PopulationResult

logger = logging.getLogger(__name__)

_RDF_TYPE = "http://www.w3.org/1999/02/22-rdf-syntax-ns#type"
_OWL_CLASS = "http://www.w3.org/2002/07/owl#Class"

# Scalar ranges that produce literal values (not object references)
_SCALAR_RANGES = frozenset(
    {
        "string",
        "integer",
        "float",
        "double",
        "boolean",
        "date",
        "datetime",
        "uri",
        "uriorcurie",
    }
)


def populate(
    records: list[dict[str, Any]] | tuple[Any, ...],
    graph_store: GraphStore,
    schema: LinkMLSchema,
    *,
    target_class: str,
    base_uri: str | None = None,
) -> PopulationResult:
    """Populate a graph store with validated records.

    Each record becomes an entity with ``rdf:type`` set to the
    target class. Scalar slots become data-property triples;
    class-typed slots become object-property triples referencing
    the related entity URI.

    Args:
        records: Validated record dicts.
        graph_store: Graph to add triples to.
        schema: Loaded LinkML schema.
        target_class: LinkML class name for these records.
        base_uri: Base URI for minted entity URIs. Defaults to
            the schema id or ``https://example.org/{schema.name}``.

    Returns:
        PopulationResult with counts and timing.
    """
    start = time.monotonic()
    base = base_uri or schema.id or f"https://example.org/{schema.name}"
    base = base.rstrip("/")

    cls = schema.classes.get(target_class)
    if cls is None:
        return PopulationResult()

    # Find identifier slot for URI minting
    id_slot = _find_identifier_slot(cls, schema)
    class_uri = f"{base}/{target_class}"

    total_triples = 0
    entity_count = 0

    for idx, record in enumerate(records):
        record_dict = record if isinstance(record, dict) else {}
        entity_uri = _mint_uri(base, target_class, record_dict, id_slot, idx)
        triples = _record_to_triples(
            entity_uri, class_uri, record_dict, cls, schema, base
        )
        added = graph_store.add_triples(triples)
        total_triples += added
        entity_count += 1

    duration = time.monotonic() - start
    logger.info(
        "populated %d entities, %d triples in %.3fs",
        entity_count,
        total_triples,
        duration,
    )
    return PopulationResult(
        triples_added=total_triples,
        entities_created=entity_count,
        duration_seconds=duration,
    )


def _find_identifier_slot(cls: Any, schema: LinkMLSchema) -> str | None:
    """Find the identifier slot for a class."""
    for slot_name in cls.slots:
        usage = cls.slot_usage.get(slot_name, {})
        slot = schema.slots.get(slot_name)
        if slot is None:
            continue
        if usage.get("identifier", slot.identifier):
            return slot_name
    return None


def _mint_uri(
    base: str,
    class_name: str,
    record: dict[str, Any],
    id_slot: str | None,
    fallback_idx: int,
) -> str:
    """Mint a unique URI for an entity."""
    if id_slot and id_slot in record and record[id_slot] is not None:
        value = quote(str(record[id_slot]), safe="")
        return f"{base}/{class_name}/{value}"
    return f"{base}/{class_name}/{fallback_idx}"


def _record_to_triples(
    entity_uri: str,
    class_uri: str,
    record: dict[str, Any],
    cls: Any,
    schema: LinkMLSchema,
    base: str,
) -> list[tuple[str, str, str]]:
    """Convert a single record into RDF triples."""
    triples: list[tuple[str, str, str]] = []

    # rdf:type
    triples.append((entity_uri, _RDF_TYPE, class_uri))

    class_names = set(schema.classes.keys())

    for slot_name in cls.slots:
        slot = schema.slots.get(slot_name)
        if slot is None:
            continue

        value = record.get(slot_name)
        if value is None:
            continue

        predicate_uri = f"{base}/{slot_name}"

        if slot.range in class_names:
            # Object property — reference another entity
            obj_value = quote(str(value), safe="")
            obj_uri = f"{base}/{slot.range}/{obj_value}"
            triples.append((entity_uri, predicate_uri, obj_uri))
        else:
            # Data property — literal value
            triples.append((entity_uri, predicate_uri, str(value)))

    return triples
