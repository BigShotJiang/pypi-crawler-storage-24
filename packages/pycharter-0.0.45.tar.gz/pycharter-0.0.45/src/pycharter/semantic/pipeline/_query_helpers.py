"""
Convenience query helpers for common graph operations.

Structured results without requiring SPARQL knowledge. Each helper
builds and executes a SPARQL query internally.
"""

from __future__ import annotations

import logging
from typing import Any

from pycharter.semantic.shared.protocols import GraphStore

logger = logging.getLogger(__name__)

_RDF_TYPE = "http://www.w3.org/1999/02/22-rdf-syntax-ns#type"
_RDFS_SUBCLASS = "http://www.w3.org/2000/01/rdf-schema#subClassOf"
_RDFS_LABEL = "http://www.w3.org/2000/01/rdf-schema#label"


def get_instances(
    graph_store: GraphStore,
    class_uri: str,
) -> list[dict[str, str]]:
    """Get all instances of a given class.

    Args:
        graph_store: Graph to query.
        class_uri: Full URI of the OWL class.

    Returns:
        List of dicts with ``"uri"`` and optional ``"label"`` keys.
    """
    sparql = f"""
        SELECT ?s ?label WHERE {{
            ?s a <{class_uri}> .
            OPTIONAL {{ ?s <{_RDFS_LABEL}> ?label }}
        }}
    """
    rows = graph_store.query_sparql(sparql)
    return [{"uri": row["s"], "label": row.get("label", "")} for row in rows]


def get_relationships(
    graph_store: GraphStore,
    entity_uri: str,
    *,
    predicate: str | None = None,
    direction: str = "outgoing",
) -> list[dict[str, str]]:
    """Get relationships for an entity.

    Args:
        graph_store: Graph to query.
        entity_uri: Full URI of the entity.
        predicate: Optional predicate URI to filter by.
        direction: ``"outgoing"`` (default) for triples where entity
            is subject, or ``"incoming"`` for triples where entity
            is object.

    Returns:
        List of dicts with ``"predicate"`` and ``"target"`` keys.
    """
    if direction == "outgoing":
        if predicate:
            sparql = f"""
                SELECT ?p ?o WHERE {{
                    <{entity_uri}> ?p ?o .
                    FILTER(?p = <{predicate}>)
                }}
            """
        else:
            sparql = f"""
                SELECT ?p ?o WHERE {{
                    <{entity_uri}> ?p ?o .
                }}
            """
        rows = graph_store.query_sparql(sparql)
        return [{"predicate": row["p"], "target": row["o"]} for row in rows]

    # Incoming
    if predicate:
        sparql = f"""
            SELECT ?s ?p WHERE {{
                ?s ?p <{entity_uri}> .
                FILTER(?p = <{predicate}>)
            }}
        """
    else:
        sparql = f"""
            SELECT ?s ?p WHERE {{
                ?s ?p <{entity_uri}> .
            }}
        """
    rows = graph_store.query_sparql(sparql)
    return [{"predicate": row["p"], "target": row["s"]} for row in rows]


def get_ancestors(
    graph_store: GraphStore,
    class_uri: str,
) -> list[str]:
    """Get all ancestor classes via rdfs:subClassOf transitively.

    Args:
        graph_store: Graph to query.
        class_uri: Full URI of the class.

    Returns:
        List of ancestor class URIs (immediate parents first).
    """
    sparql = f"""
        SELECT ?parent WHERE {{
            <{class_uri}> <{_RDFS_SUBCLASS}>+ ?parent .
        }}
    """
    rows = graph_store.query_sparql(sparql)
    return [row["parent"] for row in rows]


def get_properties(
    graph_store: GraphStore,
    entity_uri: str,
) -> dict[str, Any]:
    """Get all properties of an entity as a flat dict.

    Args:
        graph_store: Graph to query.
        entity_uri: Full URI of the entity.

    Returns:
        Dict mapping predicate URIs to their values. Multivalued
        predicates produce a list.
    """
    sparql = f"""
        SELECT ?p ?o WHERE {{
            <{entity_uri}> ?p ?o .
        }}
    """
    rows = graph_store.query_sparql(sparql)

    props: dict[str, Any] = {}
    for row in rows:
        pred = row["p"]
        val = row["o"]
        if pred in props:
            existing = props[pred]
            if isinstance(existing, list):
                existing.append(val)
            else:
                props[pred] = [existing, val]
        else:
            props[pred] = val

    return props
