"""
SPARQL query interface for the semantic pipeline.

Provides a high-level ``query()`` function that wraps the GraphStore's
SPARQL support with result-format options: dicts (default), Pydantic
models, or flat tuples.
"""

from __future__ import annotations

import logging
from typing import Any

from pycharter.semantic.shared.errors import SparqlError
from pycharter.semantic.shared.protocols import GraphStore

logger = logging.getLogger(__name__)


def query(
    graph_store: GraphStore,
    sparql: str,
    *,
    bindings: dict[str, str] | None = None,
    format: str = "dicts",
) -> list[dict[str, Any]] | list[tuple[str, ...]]:
    """Execute a SPARQL SELECT query and return results.

    Args:
        graph_store: Graph to query.
        sparql: SPARQL SELECT query string.
        bindings: Optional variable bindings to inject.
        format: Result format — ``"dicts"`` (default) for list of
            dicts keyed by variable name, or ``"tuples"`` for list
            of value tuples.

    Returns:
        Query results in the requested format.

    Raises:
        SparqlError: If the query fails.
        ValueError: If format is not recognized.
    """
    if format not in ("dicts", "tuples"):
        raise ValueError(f"Unknown format {format!r}; use 'dicts' or 'tuples'")

    try:
        rows = graph_store.query_sparql(sparql, bindings=bindings)
    except SparqlError:
        raise
    except Exception as exc:
        raise SparqlError(str(exc), query=sparql) from exc

    logger.debug("SPARQL query returned %d rows", len(rows))

    if format == "tuples":
        return [tuple(row.values()) for row in rows]

    return rows
