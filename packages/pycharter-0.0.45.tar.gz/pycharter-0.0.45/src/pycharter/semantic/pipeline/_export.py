"""
Graph export in multiple RDF serialization formats.

Exports the contents of a graph store to files on disk. Supports
Turtle, RDF/XML, JSON-LD, and N-Triples.
"""

from __future__ import annotations

import logging
from pathlib import Path

from pycharter.semantic.shared.protocols import GraphStore

logger = logging.getLogger(__name__)

_FORMAT_EXTENSIONS: dict[str, str] = {
    "turtle": ".ttl",
    "xml": ".rdf",
    "json-ld": ".jsonld",
    "nt": ".nt",
    "n3": ".n3",
}


def export(
    graph_store: GraphStore,
    output_dir: Path | str,
    *,
    fmt: str = "turtle",
    filename: str | None = None,
) -> Path:
    """Export a graph to a file.

    Args:
        graph_store: Graph to export.
        output_dir: Directory for the output file.
        fmt: Serialization format — ``"turtle"`` (default),
            ``"xml"``, ``"json-ld"``, ``"nt"``, or ``"n3"``.
        filename: Optional filename override. Defaults to
            ``graph`` + format extension.

    Returns:
        Path to the created file.

    Raises:
        ValueError: If the format is not recognized.
    """
    if fmt not in _FORMAT_EXTENSIONS:
        raise ValueError(
            f"Unknown format {fmt!r}; choose from: "
            f"{', '.join(sorted(_FORMAT_EXTENSIONS))}"
        )

    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    if filename is None:
        filename = f"graph{_FORMAT_EXTENSIONS[fmt]}"

    out_path = output_dir / filename
    content = graph_store.serialize(fmt=fmt)
    out_path.write_text(content, encoding="utf-8")

    logger.info("exported graph to %s (%s format)", out_path, fmt)
    return out_path
