"""
Entity resolution for graph population.

Resolves duplicate entities by merging properties and detecting
conflicts. Key fields are configurable per class (derived from
LinkML ``identifier: true`` slots).
"""

from __future__ import annotations

import logging
from typing import Any, Protocol, runtime_checkable

from pycharter.semantic.linkml._loader import LinkMLSchema

logger = logging.getLogger(__name__)


@runtime_checkable
class EntityResolver(Protocol):
    """Protocol for entity resolution strategies.

    Implementations decide how to merge duplicate records that
    share the same identifier into a single entity representation.
    """

    def resolve(
        self,
        existing: dict[str, Any],
        incoming: dict[str, Any],
        class_name: str,
    ) -> dict[str, Any]:
        """Merge an incoming record with an existing one.

        Args:
            existing: The record already stored.
            incoming: The new record with the same identity.
            class_name: LinkML class name for context.

        Returns:
            Merged record dict.
        """
        ...


class LastWriteWinsResolver:
    """Entity resolver that overwrites existing values with incoming.

    Non-None incoming values replace existing values. Existing values
    are preserved when the incoming value is None.
    """

    def resolve(
        self,
        existing: dict[str, Any],
        incoming: dict[str, Any],
        class_name: str,
    ) -> dict[str, Any]:
        """Merge with last-write-wins semantics."""
        merged = dict(existing)
        for key, value in incoming.items():
            if value is not None:
                merged[key] = value
        return merged


class StrictResolver:
    """Entity resolver that raises on conflicting values.

    If an incoming record has a different non-None value for a field
    that already has a non-None value, a ``ValueError`` is raised.
    """

    def resolve(
        self,
        existing: dict[str, Any],
        incoming: dict[str, Any],
        class_name: str,
    ) -> dict[str, Any]:
        """Merge with strict conflict detection."""
        merged = dict(existing)
        for key, value in incoming.items():
            if value is None:
                continue
            old = existing.get(key)
            if old is not None and old != value:
                raise ValueError(
                    f"Conflict in {class_name}.{key}: "
                    f"existing={old!r}, incoming={value!r}"
                )
            merged[key] = value
        return merged


def deduplicate(
    records: list[dict[str, Any]],
    schema: LinkMLSchema,
    *,
    target_class: str,
    resolver: EntityResolver | None = None,
) -> list[dict[str, Any]]:
    """Deduplicate records by identifier fields.

    Groups records by the identifier slot of *target_class* and
    merges duplicates using the given resolver strategy.

    Args:
        records: Input records to deduplicate.
        schema: Loaded LinkML schema.
        target_class: LinkML class name.
        resolver: Merge strategy. Defaults to ``LastWriteWinsResolver``.

    Returns:
        Deduplicated list of records.
    """
    if resolver is None:
        resolver = LastWriteWinsResolver()

    cls = schema.classes.get(target_class)
    if cls is None:
        return list(records)

    id_slot = _find_id_slot(cls, schema)
    if id_slot is None:
        # No identifier slot — can't deduplicate
        return list(records)

    seen: dict[Any, dict[str, Any]] = {}
    order: list[Any] = []

    for record in records:
        key = record.get(id_slot)
        if key is None:
            # Records without an id are passed through
            order.append(id(record))
            seen[id(record)] = record
            continue

        if key in seen:
            seen[key] = resolver.resolve(seen[key], record, target_class)
        else:
            order.append(key)
            seen[key] = dict(record)

    result = [seen[k] for k in order]
    merged_count = len(records) - len(result)
    if merged_count > 0:
        logger.info("deduplicated %d records (merged %d)", len(result), merged_count)
    return result


def _find_id_slot(cls: Any, schema: LinkMLSchema) -> str | None:
    """Find the identifier slot name for a class."""
    for slot_name in cls.slots:
        usage = cls.slot_usage.get(slot_name, {})
        slot = schema.slots.get(slot_name)
        if slot is None:
            continue
        if usage.get("identifier", slot.identifier):
            return slot_name
    return None
