"""
Inference orchestrator for the semantic pipeline.

Applies OWL-RL reasoning to a populated graph store, materializing
implicit triples. Wraps the Reasoner protocol with sensible defaults
and structured reporting.
"""

from __future__ import annotations

import logging
from typing import Any

from pycharter.semantic.shared.errors import ReasoningError
from pycharter.semantic.shared.protocols import GraphStore, Reasoner
from pycharter.semantic.shared.results import InferenceResult

logger = logging.getLogger(__name__)


def infer(
    graph_store: GraphStore,
    reasoner: Reasoner | None = None,
    *,
    profile: str = "owl-rl",
) -> InferenceResult:
    """Run OWL inference on a populated graph.

    Materializes implicit triples using the given reasoner or the
    default ``OwlrlReasoner``. Reports triples before/after, new
    materialized count, and wall-clock time.

    Args:
        graph_store: Graph containing data and ontology triples.
        reasoner: Optional custom reasoner. Defaults to
            ``OwlrlReasoner(profile=profile)``.
        profile: Reasoning profile when using the default reasoner.
            One of ``"owl-rl"``, ``"rdfs"``, ``"owl-rl-ext"``.

    Returns:
        InferenceResult with counts and timing.

    Raises:
        ReasoningError: If inference fails.
    """
    if reasoner is None:
        reasoner = _default_reasoner(profile)

    try:
        result = reasoner.infer(graph_store)
    except ReasoningError:
        raise
    except Exception as exc:
        raise ReasoningError(f"Inference failed: {exc}") from exc

    logger.info(
        "inference: %d triples added (%d → %d) in %.3fs",
        result.triples_added,
        result.triples_before,
        result.triples_after,
        result.duration_seconds,
    )
    return result


def _default_reasoner(profile: str) -> Any:
    """Create the default OwlrlReasoner."""
    from pycharter.semantic.backends._owlrl_reasoner import OwlrlReasoner

    return OwlrlReasoner(profile=profile)
