"""
Streaming/batched validation and population.

Processes records in configurable batches to handle millions of
records without exhausting memory. Yields intermediate results
per batch.
"""

from __future__ import annotations

import logging
from collections.abc import Iterable, Iterator
from typing import Any

from pycharter.semantic.linkml._loader import LinkMLSchema
from pycharter.semantic.pipeline._populator import populate
from pycharter.semantic.pipeline._validator import validate
from pycharter.semantic.shared.protocols import GraphStore
from pycharter.semantic.shared.results import PopulationResult, ValidationResult

logger = logging.getLogger(__name__)

_DEFAULT_BATCH_SIZE = 1000


def validate_stream(
    records: Iterable[dict[str, Any]],
    schema: LinkMLSchema,
    *,
    target_class: str,
    batch_size: int = _DEFAULT_BATCH_SIZE,
) -> Iterator[ValidationResult]:
    """Validate records in streaming batches.

    Yields one ``ValidationResult`` per batch. Each result is
    independent — valid records and errors are scoped to their batch.

    Args:
        records: Iterable of record dicts (can be a generator).
        schema: Loaded LinkML schema.
        target_class: LinkML class to validate against.
        batch_size: Number of records per batch.

    Yields:
        ValidationResult for each batch.
    """
    batch: list[dict[str, Any]] = []

    for record in records:
        batch.append(record)
        if len(batch) >= batch_size:
            yield validate(batch, schema, target_class=target_class)
            batch = []

    if batch:
        yield validate(batch, schema, target_class=target_class)


def populate_stream(
    records: Iterable[dict[str, Any]],
    graph_store: GraphStore,
    schema: LinkMLSchema,
    *,
    target_class: str,
    batch_size: int = _DEFAULT_BATCH_SIZE,
    base_uri: str | None = None,
) -> Iterator[PopulationResult]:
    """Populate a graph in streaming batches.

    Yields one ``PopulationResult`` per batch. Triples are committed
    to the graph store as each batch completes.

    Args:
        records: Iterable of validated record dicts.
        graph_store: Graph to add triples to.
        schema: Loaded LinkML schema.
        target_class: LinkML class name.
        batch_size: Number of records per batch.
        base_uri: Base URI for entity minting.

    Yields:
        PopulationResult for each batch.
    """
    batch: list[dict[str, Any]] = []

    for record in records:
        batch.append(record)
        if len(batch) >= batch_size:
            yield populate(
                batch,
                graph_store,
                schema,
                target_class=target_class,
                base_uri=base_uri,
            )
            batch = []

    if batch:
        yield populate(
            batch,
            graph_store,
            schema,
            target_class=target_class,
            base_uri=base_uri,
        )


def validate_and_populate_stream(
    records: Iterable[dict[str, Any]],
    graph_store: GraphStore,
    schema: LinkMLSchema,
    *,
    target_class: str,
    batch_size: int = _DEFAULT_BATCH_SIZE,
    base_uri: str | None = None,
) -> Iterator[tuple[ValidationResult, PopulationResult]]:
    """Validate and populate in a single streaming pass.

    For each batch: validates records, populates the graph with
    valid records, and yields both results.

    Args:
        records: Iterable of record dicts.
        graph_store: Graph to add triples to.
        schema: Loaded LinkML schema.
        target_class: LinkML class name.
        batch_size: Number of records per batch.
        base_uri: Base URI for entity minting.

    Yields:
        Tuple of (ValidationResult, PopulationResult) per batch.
    """
    batch: list[dict[str, Any]] = []

    for record in records:
        batch.append(record)
        if len(batch) >= batch_size:
            vr, pr = _validate_and_populate_batch(
                batch, graph_store, schema, target_class, base_uri
            )
            yield vr, pr
            batch = []

    if batch:
        vr, pr = _validate_and_populate_batch(
            batch, graph_store, schema, target_class, base_uri
        )
        yield vr, pr


def _validate_and_populate_batch(
    batch: list[dict[str, Any]],
    graph_store: GraphStore,
    schema: LinkMLSchema,
    target_class: str,
    base_uri: str | None,
) -> tuple[ValidationResult, PopulationResult]:
    """Validate then populate a single batch."""
    vr = validate(batch, schema, target_class=target_class)
    pr = populate(
        list(vr.valid_records),
        graph_store,
        schema,
        target_class=target_class,
        base_uri=base_uri,
    )
    return vr, pr
