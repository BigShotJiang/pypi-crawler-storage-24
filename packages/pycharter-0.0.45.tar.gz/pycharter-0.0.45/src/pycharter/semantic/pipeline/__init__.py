"""
Semantic pipeline for record validation, graph population, and querying.

Composable, stateless functions that form the golden path:
validate → populate → infer → query → validate_graph → export.
"""

from __future__ import annotations
