"""
Graph-level SHACL validation.

Validates a populated graph against SHACL shapes. Optionally
activatable — zero cost if not called.
"""

from __future__ import annotations

import logging
from typing import Any

from pycharter.semantic.shared.protocols import GraphStore, ShapeValidator
from pycharter.semantic.shared.results import ValidationReport

logger = logging.getLogger(__name__)


def validate_graph(
    graph_store: GraphStore,
    shapes: Any | None = None,
    validator: ShapeValidator | None = None,
) -> ValidationReport:
    """Validate a graph against SHACL shapes.

    Args:
        graph_store: Graph containing data to validate.
        shapes: Optional SHACL shapes graph. If None, the validator
            uses shapes embedded in the data graph.
        validator: Optional custom ShapeValidator. Defaults to
            ``PyshaclShapeValidator()``.

    Returns:
        ValidationReport with conformance status and violations.
    """
    if validator is None:
        validator = _default_validator()

    report = validator.validate(graph_store, shapes_graph=shapes)

    logger.info(
        "graph validation: conforms=%s errors=%d warnings=%d",
        report.conforms,
        report.error_count,
        report.warning_count,
    )
    return report


def _default_validator() -> Any:
    """Create the default PyshaclShapeValidator."""
    from pycharter.semantic.backends._pyshacl_validator import PyshaclShapeValidator

    return PyshaclShapeValidator()
