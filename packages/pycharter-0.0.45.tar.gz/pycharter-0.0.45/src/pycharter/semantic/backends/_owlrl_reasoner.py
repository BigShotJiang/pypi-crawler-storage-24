"""
owlrl-backed implementation of the Reasoner protocol.

Applies OWL-RL deductive closure to an rdflib-backed graph store,
materializing implicit triples (transitive closure, inverse, symmetric,
subclass/subproperty inheritance, domain/range).
"""

from __future__ import annotations

import logging
import time
from typing import Any

from pycharter.semantic.backends import _check_owlrl
from pycharter.semantic.shared.errors import ReasoningError
from pycharter.semantic.shared.results import InferenceResult

logger = logging.getLogger(__name__)

# Mapping of profile names to owlrl closure classes.
_PROFILE_MAP: dict[str, str] = {
    "owl-rl": "OWLRL_Semantics",
    "rdfs": "RDFS_Semantics",
    "owl-rl-ext": "OWLRL_Extension",
}


class OwlrlReasoner:
    """OWL-RL reasoner backed by the owlrl library.

    Conforms to the :class:`~pycharter.semantic.shared.protocols.Reasoner`
    protocol.

    Args:
        profile: Reasoning profile to use. One of ``"owl-rl"``,
            ``"rdfs"``, or ``"owl-rl-ext"``. Defaults to ``"owl-rl"``.
    """

    def __init__(self, profile: str = "owl-rl") -> None:
        _check_owlrl()
        if profile not in _PROFILE_MAP:
            raise ValueError(
                f"Unsupported profile {profile!r}. "
                f"Choose from: {', '.join(sorted(_PROFILE_MAP))}"
            )
        self._profile = profile

    # ------------------------------------------------------------------
    # Reasoner protocol
    # ------------------------------------------------------------------

    def infer(self, graph_store: Any) -> InferenceResult:
        """Run OWL-RL inference on the graph store.

        Args:
            graph_store: A GraphStore whose underlying graph is rdflib-based.

        Returns:
            InferenceResult with before/after triple counts and timing.

        Raises:
            ReasoningError: If inference fails.
        """
        import owlrl

        graph = graph_store.get_graph()
        triples_before = len(graph)

        semantics_cls = getattr(owlrl, _PROFILE_MAP[self._profile], None)
        if semantics_cls is None:
            raise ReasoningError(f"owlrl does not expose {_PROFILE_MAP[self._profile]}")

        start = time.perf_counter()
        try:
            owlrl.DeductiveClosure(semantics_cls).expand(graph)
        except Exception as exc:
            raise ReasoningError(
                f"Inference failed with profile {self._profile!r}: {exc}"
            ) from exc
        duration = time.perf_counter() - start

        triples_after = len(graph)
        triples_added = triples_after - triples_before

        logger.info(
            "inference complete: profile=%s added=%d duration=%.3fs",
            self._profile,
            triples_added,
            duration,
        )

        return InferenceResult(
            triples_before=triples_before,
            triples_after=triples_after,
            triples_added=triples_added,
            duration_seconds=duration,
            profile=self._profile,
        )

    def supported_profiles(self) -> list[str]:
        """Return the list of supported reasoning profiles."""
        return sorted(_PROFILE_MAP.keys())
