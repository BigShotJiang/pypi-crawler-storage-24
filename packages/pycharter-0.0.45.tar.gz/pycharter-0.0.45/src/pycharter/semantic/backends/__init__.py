"""
Default backend implementations for the semantic layer.

Provides concrete implementations of the GraphStore, Reasoner, and
ShapeValidator protocols using rdflib, owlrl, and pyshacl respectively.

All backends require the ``ontology`` optional dependency group::

    pip install pycharter[ontology]
"""

from __future__ import annotations


def _check_owlrl() -> None:
    """Raise a helpful ImportError if owlrl is not installed."""
    try:
        import owlrl  # noqa: F401
    except ImportError as exc:
        raise ImportError(
            "The 'owlrl' package is required for OWL reasoning. "
            "Install it with: pip install pycharter[ontology]"
        ) from exc
