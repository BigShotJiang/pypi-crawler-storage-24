"""
rdflib-backed implementation of the GraphStore protocol.

Uses an in-memory ``rdflib.Graph`` as the triple store. Suitable for
moderate-size graphs (up to a few hundred thousand triples). For larger
workloads, swap in an Oxigraph or remote SPARQL endpoint adapter.
"""

from __future__ import annotations

import logging
from collections.abc import Iterable
from typing import Any

from pycharter.semantic.rdf import _check_rdflib

logger = logging.getLogger(__name__)


class RdflibGraphStore:
    """In-memory triple store backed by rdflib.

    Conforms to the :class:`~pycharter.semantic.shared.protocols.GraphStore`
    protocol.

    Args:
        graph: Optional pre-existing ``rdflib.Graph``. A fresh graph is
            created when omitted.
    """

    def __init__(self, graph: Any | None = None) -> None:
        _check_rdflib()
        from rdflib import Graph

        self._graph: Graph = graph if graph is not None else Graph()

    # ------------------------------------------------------------------
    # GraphStore protocol
    # ------------------------------------------------------------------

    def add_triples(
        self,
        triples: Iterable[tuple[str, str, str]],
        graph_name: str | None = None,
    ) -> int:
        """Add triples to the graph and return the count added."""
        from rdflib import URIRef

        count = 0
        for s, p, o in triples:
            self._graph.add((URIRef(s), URIRef(p), self._to_term(o)))
            count += 1
        logger.debug("added %d triples", count)
        return count

    def remove_triples(
        self,
        pattern: tuple[str | None, str | None, str | None],
        graph_name: str | None = None,
    ) -> int:
        """Remove triples matching a wildcard pattern."""
        from rdflib import URIRef

        s_pat = URIRef(pattern[0]) if pattern[0] else None
        p_pat = URIRef(pattern[1]) if pattern[1] else None
        o_pat = self._to_term(pattern[2]) if pattern[2] else None

        matching = list(self._graph.triples((s_pat, p_pat, o_pat)))
        for triple in matching:
            self._graph.remove(triple)
        logger.debug("removed %d triples", len(matching))
        return len(matching)

    def query_sparql(
        self,
        sparql: str,
        *,
        bindings: dict[str, str] | None = None,
    ) -> list[dict[str, Any]]:
        """Execute a SPARQL SELECT query and return rows as dicts."""
        from pycharter.semantic.shared.errors import SparqlError

        try:
            result = self._graph.query(sparql, initBindings=bindings or {})
        except Exception as exc:
            raise SparqlError(str(exc), query=sparql) from exc

        rows: list[dict[str, Any]] = []
        if result.vars is None:
            return rows
        var_names = [str(v) for v in result.vars]
        for row in result:
            rows.append({name: str(row[idx]) for idx, name in enumerate(var_names)})
        return rows

    def get_graph(self) -> Any:
        """Return the underlying rdflib.Graph."""
        return self._graph

    def triple_count(self, graph_name: str | None = None) -> int:
        """Return the number of triples in the graph."""
        return len(self._graph)

    def clear(self, graph_name: str | None = None) -> None:
        """Remove all triples from the graph."""
        self._graph.remove((None, None, None))
        logger.debug("graph cleared")

    def serialize(self, fmt: str = "turtle") -> str:
        """Serialize the graph to a string in the given format."""
        return self._graph.serialize(format=fmt)

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _to_term(value: str) -> Any:
        """Convert a string value to an rdflib term.

        URIs (starting with ``http://`` or ``https://``) become URIRef;
        everything else becomes a Literal.
        """
        from rdflib import Literal, URIRef

        if value.startswith(("http://", "https://")):
            return URIRef(value)
        return Literal(value)
