"""
pyshacl-backed implementation of the ShapeValidator protocol.

Validates a data graph against SHACL shape constraints, returning a
structured ValidationReport with conformance status and violations.
"""

from __future__ import annotations

import logging
from typing import Any

from pycharter.semantic.rdf import _check_pyshacl
from pycharter.semantic.shared.errors import BackendError
from pycharter.semantic.shared.results import (
    ShapeViolation,
    ValidationReport,
)

logger = logging.getLogger(__name__)


class PyshaclShapeValidator:
    """SHACL validator backed by the pyshacl library.

    Conforms to the
    :class:`~pycharter.semantic.shared.protocols.ShapeValidator` protocol.
    """

    # ------------------------------------------------------------------
    # ShapeValidator protocol
    # ------------------------------------------------------------------

    def validate(
        self,
        data_graph: Any,
        shapes_graph: Any | None = None,
    ) -> ValidationReport:
        """Validate a data graph against SHACL shapes.

        Args:
            data_graph: A GraphStore containing the data triples.
            shapes_graph: Optional rdflib.Graph of SHACL shapes. If None
                the validator looks for shapes embedded in the data graph.

        Returns:
            ValidationReport with conformance status and violations.

        Raises:
            BackendError: If pyshacl validation raises an unexpected error.
        """
        _check_pyshacl()
        import pyshacl

        graph = data_graph.get_graph()

        try:
            conforms, results_graph, results_text = pyshacl.validate(
                data_graph=graph,
                shacl_graph=shapes_graph,
                inference="none",
                serialize_report_graph="turtle",
            )
        except Exception as exc:
            raise BackendError(
                f"SHACL validation failed: {exc}", backend="pyshacl"
            ) from exc

        violations = self._parse_violations(results_graph)

        info_count = sum(1 for v in violations if v.severity == "Info")
        warning_count = sum(1 for v in violations if v.severity == "Warning")
        error_count = sum(1 for v in violations if v.severity == "Violation")

        logger.info(
            "SHACL validation: conforms=%s violations=%d "
            "(errors=%d warnings=%d info=%d)",
            conforms,
            len(violations),
            error_count,
            warning_count,
            info_count,
        )

        return ValidationReport(
            conforms=conforms,
            violations=tuple(violations),
            info_count=info_count,
            warning_count=warning_count,
            error_count=error_count,
        )

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _parse_violations(results_graph: Any) -> list[ShapeViolation]:
        """Extract ShapeViolation objects from a pyshacl results graph."""
        from rdflib import Graph

        if isinstance(results_graph, str | bytes):
            g = Graph()
            g.parse(data=results_graph, format="turtle")
        elif isinstance(results_graph, Graph):
            g = results_graph
        else:
            return []

        sparql = """
        PREFIX sh: <http://www.w3.org/ns/shacl#>
        SELECT ?focus ?path ?value ?shape ?severity ?message
        WHERE {
            ?result a sh:ValidationResult ;
                    sh:focusNode ?focus ;
                    sh:resultSeverity ?severity .
            OPTIONAL { ?result sh:resultPath ?path }
            OPTIONAL { ?result sh:value ?value }
            OPTIONAL { ?result sh:sourceShape ?shape }
            OPTIONAL { ?result sh:resultMessage ?message }
        }
        """
        violations: list[ShapeViolation] = []
        for row in g.query(sparql):
            severity_str = str(row.severity).rsplit("#", 1)[-1]
            violations.append(
                ShapeViolation(
                    focus_node=str(row.focus),
                    path=str(row.path) if row.path else "",
                    value=str(row.value) if row.value else None,
                    shape=str(row.shape) if row.shape else "",
                    severity=severity_str,
                    message=str(row.message) if row.message else "",
                )
            )
        return violations
