"""
Bridge from LinkML schemas to pycharter domain models.

Converts a loaded LinkMLSchema into pycharter's internal ConceptScheme,
Concept, and RelationshipTypeInfo representations so that the existing
knowledge graph infrastructure can consume LinkML-authored ontologies.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass

from pycharter.semantic.linkml._loader import ClassInfo, LinkMLSchema
from pycharter.semantic.ontology.models import Concept, ConceptScheme

logger = logging.getLogger(__name__)


@dataclass(frozen=True, slots=True)
class RelationshipTypeInfo:
    """Relationship type derived from a LinkML slot.

    Attributes:
        name: Relationship name (slot name).
        meaning: Description of the relationship.
        inverse: Inverse relationship name (from ``inverse`` annotation).
        symmetric: Whether the relationship is symmetric.
        transitive: Whether the relationship is transitive.
        domain_types: Allowed source class names.
        range_types: Allowed target class names.
        predicate: RDF predicate URI.
    """

    name: str
    meaning: str = ""
    inverse: str | None = None
    symmetric: bool = False
    transitive: bool = False
    domain_types: tuple[str, ...] = ()
    range_types: tuple[str, ...] = ()
    predicate: str | None = None


def linkml_to_concept_scheme(schema: LinkMLSchema) -> ConceptScheme:
    """Convert a LinkML schema's classes into a pycharter ConceptScheme.

    Each LinkML class becomes a ``Concept``, preserving hierarchy
    (``is_a`` → ``broader``), descriptions, and tags.

    Args:
        schema: A loaded LinkML schema.

    Returns:
        ConceptScheme populated with one Concept per class.
    """
    concepts: list[Concept] = []

    for name, cls in sorted(schema.classes.items()):
        concept_type = _infer_concept_type(cls, schema)
        tags = _extract_tags(cls)

        concepts.append(
            Concept(
                id=name,
                label=name,
                definition=cls.description or None,
                broader=cls.is_a,
                tags=tuple(tags),
                concept_type=concept_type,
            )
        )

    return ConceptScheme(
        id=schema.name or schema.id,
        title=schema.name or schema.id,
        version=schema.version or "0.0.0",
        description=schema.description,
        base_uri=schema.id or None,
        concepts=concepts,
    )


def linkml_to_relationship_types(
    schema: LinkMLSchema,
) -> list[RelationshipTypeInfo]:
    """Extract relationship type definitions from a LinkML schema.

    Slots whose range references another class are treated as relationship
    types. Annotations like ``inverse``, ``symmetric``, and ``transitive``
    enrich the result.

    Args:
        schema: A loaded LinkML schema.

    Returns:
        List of RelationshipTypeInfo, one per object-typed slot.
    """
    class_names = set(schema.classes.keys())
    result: list[RelationshipTypeInfo] = []

    for name, slot in sorted(schema.slots.items()):
        # Only slots whose range is a class are relationship types
        if slot.range not in class_names:
            continue

        annotations = slot.annotations or {}
        domain_types = _collect_domains(name, schema)

        result.append(
            RelationshipTypeInfo(
                name=name,
                meaning=slot.description,
                inverse=annotations.get("inverse"),
                symmetric=bool(annotations.get("symmetric", False)),
                transitive=bool(annotations.get("transitive", False)),
                domain_types=tuple(sorted(domain_types)),
                range_types=(slot.range,),
                predicate=annotations.get("predicate"),
            )
        )

    logger.debug(
        "extracted %d relationship types from schema %s",
        len(result),
        schema.name,
    )
    return result


# =====================================================================
# Internal helpers
# =====================================================================


def _infer_concept_type(cls: ClassInfo, schema: LinkMLSchema) -> str | None:
    """Infer a pycharter concept type from class annotations."""
    if "concept_type" in cls.annotations:
        return str(cls.annotations["concept_type"])

    # Walk up the hierarchy to find an annotated ancestor
    visited: set[str] = set()
    current = cls.is_a
    while current and current not in visited:
        visited.add(current)
        parent = schema.classes.get(current)
        if not parent:
            break
        if "concept_type" in parent.annotations:
            return str(parent.annotations["concept_type"])
        current = parent.is_a

    return None


def _extract_tags(cls: ClassInfo) -> list[str]:
    """Extract tags from class annotations."""
    raw = cls.annotations.get("tags")
    if isinstance(raw, list):
        return [str(t) for t in raw]
    if isinstance(raw, str):
        return [t.strip() for t in raw.split(",") if t.strip()]
    return list(cls.mixins)


def _collect_domains(slot_name: str, schema: LinkMLSchema) -> set[str]:
    """Find all classes that declare a slot in their slot list."""
    domains: set[str] = set()
    for cls_name, cls in schema.classes.items():
        if slot_name in cls.slots:
            domains.add(cls_name)
    return domains
