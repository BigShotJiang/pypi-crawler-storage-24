"""
Ontology version registry.

Manages immutable, versioned snapshots of LinkML schemas. Once published,
a version cannot be modified. Stored as YAML files in a configurable
directory (default: ``data/ontology/versions/``).
"""

from __future__ import annotations

import logging
import shutil
from dataclasses import dataclass
from pathlib import Path

from pycharter.semantic.linkml._loader import LinkMLSchema, load_linkml_schema
from pycharter.semantic.shared.errors import LinkMLError, OntologyError

logger = logging.getLogger(__name__)

_DEFAULT_VERSIONS_DIR = (
    Path(__file__).resolve().parents[2] / "data" / "ontology" / "versions"
)


@dataclass(frozen=True, slots=True)
class VersionEntry:
    """Metadata for a published ontology version.

    Attributes:
        name: Schema name.
        version: Semantic version string.
        path: Filesystem path to the stored YAML.
    """

    name: str
    version: str
    path: str


class OntologyVersionRegistry:
    """Manages immutable published ontology versions.

    Args:
        versions_dir: Directory where version snapshots are stored.
            Defaults to ``data/ontology/versions/``.
    """

    def __init__(self, versions_dir: Path | str | None = None) -> None:
        self._dir = Path(versions_dir) if versions_dir else _DEFAULT_VERSIONS_DIR
        self._dir.mkdir(parents=True, exist_ok=True)

    def publish(
        self,
        source_path: Path | str,
        version: str | None = None,
    ) -> VersionEntry:
        """Publish an immutable ontology version.

        Copies the LinkML YAML to the versions directory. If ``version``
        is not provided, it is read from the schema's ``version`` field.

        Args:
            source_path: Path to the LinkML YAML file.
            version: Override version string. Defaults to schema's version.

        Returns:
            VersionEntry for the published snapshot.

        Raises:
            LinkMLError: If the schema is invalid or the version exists.
        """
        schema = load_linkml_schema(source_path)
        ver = version or schema.version
        if not ver:
            raise LinkMLError(
                "Cannot publish without a version. Set 'version' in the "
                "schema or pass it explicitly.",
                path=str(source_path),
            )

        name = schema.name or schema.id or Path(source_path).stem
        dest = self._version_path(name, ver)

        if dest.exists():
            raise OntologyError(f"Version {name}:{ver} already published at {dest}")

        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(str(source_path), str(dest))
        logger.info("published ontology %s:%s to %s", name, ver, dest)

        return VersionEntry(name=name, version=ver, path=str(dest))

    def load(self, name: str, version: str) -> LinkMLSchema:
        """Load a previously published ontology version.

        Args:
            name: Schema name.
            version: Version string.

        Returns:
            Loaded LinkMLSchema.

        Raises:
            OntologyError: If the version does not exist.
        """
        path = self._version_path(name, version)
        if not path.exists():
            raise OntologyError(
                f"Ontology version {name}:{version} not found at {path}"
            )
        return load_linkml_schema(path)

    def list_versions(self, name: str | None = None) -> list[VersionEntry]:
        """List all published versions, optionally filtered by name.

        Args:
            name: Filter to versions of this schema. None returns all.

        Returns:
            Sorted list of VersionEntry objects.
        """
        entries: list[VersionEntry] = []
        if not self._dir.exists():
            return entries

        for schema_dir in sorted(self._dir.iterdir()):
            if not schema_dir.is_dir():
                continue
            if name and schema_dir.name != name:
                continue
            for yaml_file in sorted(schema_dir.glob("*.yaml")):
                ver = yaml_file.stem
                entries.append(
                    VersionEntry(
                        name=schema_dir.name,
                        version=ver,
                        path=str(yaml_file),
                    )
                )
        return entries

    def resolve(self, reference: str) -> LinkMLSchema:
        """Resolve a ``name:version`` reference to a loaded schema.

        Args:
            reference: String in ``"name:version"`` format.

        Returns:
            Loaded LinkMLSchema.

        Raises:
            OntologyError: If the reference is malformed or not found.
        """
        if ":" not in reference:
            raise OntologyError(
                f"Invalid schema reference {reference!r}. "
                "Expected 'name:version' format."
            )
        name, version = reference.rsplit(":", 1)
        return self.load(name.strip(), version.strip())

    # -----------------------------------------------------------------
    # Internal helpers
    # -----------------------------------------------------------------

    def _version_path(self, name: str, version: str) -> Path:
        """Return the filesystem path for a version snapshot."""
        return self._dir / name / f"{version}.yaml"
