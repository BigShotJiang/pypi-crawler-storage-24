"""
LinkML schema integration for pycharter semantic layer.

Provides loading, validation, and bridging of LinkML YAML schemas to
pycharter's internal domain models. Requires the ``linkml`` optional
dependency group::

    pip install pycharter[linkml]
"""

from __future__ import annotations


def _check_linkml() -> None:
    """Raise a helpful ImportError if linkml is not installed."""
    try:
        import linkml_runtime  # noqa: F401
    except ImportError as exc:
        raise ImportError(
            "The 'linkml-runtime' package is required for LinkML support. "
            "Install it with: pip install pycharter[linkml]"
        ) from exc
