"""
LinkML schema loader and validator.

Loads a LinkML YAML file into a frozen dataclass representation,
validates structural integrity, and provides inspection helpers.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import yaml  # type: ignore[import-untyped]

from pycharter.semantic.shared.errors import LinkMLError

logger = logging.getLogger(__name__)


# =====================================================================
# Frozen dataclass wrappers around LinkML schema elements
# =====================================================================


@dataclass(frozen=True, slots=True)
class SlotInfo:
    """Parsed slot (property) from a LinkML schema.

    Attributes:
        name: Slot name.
        description: Human-readable description.
        range: Target type (string, integer, a class name, etc.).
        required: Whether this slot must be present.
        identifier: Whether this slot is the entity identifier.
        multivalued: Whether the slot accepts multiple values.
        pattern: Optional regex constraint.
        minimum_value: Optional minimum for numeric slots.
        maximum_value: Optional maximum for numeric slots.
        annotations: Extra key-value metadata.
    """

    name: str
    description: str = ""
    range: str = "string"
    required: bool = False
    identifier: bool = False
    multivalued: bool = False
    pattern: str | None = None
    minimum_value: float | None = None
    maximum_value: float | None = None
    annotations: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True, slots=True)
class ClassInfo:
    """Parsed class from a LinkML schema.

    Attributes:
        name: Class name.
        description: Human-readable description.
        is_a: Parent class (single inheritance).
        mixins: Mixin classes.
        slots: Ordered list of slot names this class uses.
        slot_usage: Per-class overrides for slot constraints.
        annotations: Extra key-value metadata.
    """

    name: str
    description: str = ""
    is_a: str | None = None
    mixins: tuple[str, ...] = ()
    slots: tuple[str, ...] = ()
    slot_usage: dict[str, dict[str, Any]] = field(default_factory=dict)
    annotations: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True, slots=True)
class EnumInfo:
    """Parsed enum from a LinkML schema.

    Attributes:
        name: Enum name.
        description: Human-readable description.
        permissible_values: Mapping of value name → description.
    """

    name: str
    description: str = ""
    permissible_values: dict[str, str] = field(default_factory=dict)


@dataclass(frozen=True, slots=True)
class LinkMLSchema:
    """Frozen representation of a loaded LinkML schema.

    Attributes:
        name: Schema name identifier.
        id: Schema IRI (e.g. ``https://statfyi.com/ontology/trading``).
        version: Schema version string.
        description: Human-readable description.
        prefixes: Namespace prefix mappings.
        classes: Parsed classes keyed by name.
        slots: Parsed slots keyed by name.
        enums: Parsed enums keyed by name.
        source_path: File path the schema was loaded from.
    """

    name: str
    id: str = ""
    version: str = ""
    description: str = ""
    prefixes: dict[str, str] = field(default_factory=dict)
    classes: dict[str, ClassInfo] = field(default_factory=dict)
    slots: dict[str, SlotInfo] = field(default_factory=dict)
    enums: dict[str, EnumInfo] = field(default_factory=dict)
    source_path: str | None = None


# =====================================================================
# Public API
# =====================================================================


def load_linkml_schema(path: Path | str) -> LinkMLSchema:
    """Load and parse a LinkML YAML file into a LinkMLSchema.

    Args:
        path: Path to the LinkML YAML file.

    Returns:
        Frozen LinkMLSchema dataclass.

    Raises:
        LinkMLError: If the file is missing, invalid YAML, or fails
            structural validation.
    """
    path = Path(path)

    if not path.exists():
        raise LinkMLError(f"Schema file not found: {path}", path=str(path))

    try:
        with path.open(encoding="utf-8") as fh:
            raw = yaml.safe_load(fh)
    except yaml.YAMLError as exc:
        raise LinkMLError(f"Invalid YAML: {exc}", path=str(path)) from exc

    if not isinstance(raw, dict):
        raise LinkMLError(
            f"Schema must be a YAML mapping, got {type(raw).__name__}",
            path=str(path),
        )

    errors = _validate_raw_schema(raw)
    if errors:
        msg = "; ".join(errors[:5])
        raise LinkMLError(f"Schema validation failed: {msg}", path=str(path))

    return _parse_raw_schema(raw, source_path=str(path))


def parse_linkml_yaml_string(yaml_string: str) -> LinkMLSchema:
    """Parse LinkML from a YAML string (not file path).

    Args:
        yaml_string: Raw LinkML YAML content.

    Returns:
        Frozen LinkMLSchema dataclass.

    Raises:
        LinkMLError: If the string is invalid YAML or fails
            structural validation.
    """
    try:
        raw = yaml.safe_load(yaml_string)
    except yaml.YAMLError as exc:
        raise LinkMLError(f"Invalid YAML: {exc}") from exc

    if not isinstance(raw, dict):
        raise LinkMLError(f"Schema must be a YAML mapping, got {type(raw).__name__}")

    errors = _validate_raw_schema(raw)
    if errors:
        msg = "; ".join(errors[:5])
        raise LinkMLError(f"Schema validation failed: {msg}")

    return _parse_raw_schema(raw)


def validate_linkml_schema(schema: LinkMLSchema) -> list[str]:
    """Run structural validation on a loaded LinkMLSchema.

    Checks that class hierarchies don't contain cycles, slot ranges
    reference valid types, and identifier slots exist where expected.

    Args:
        schema: A loaded schema to validate.

    Returns:
        List of validation error messages (empty if valid).
    """
    errors: list[str] = []

    # Check is_a references are valid
    for name, cls in schema.classes.items():
        if cls.is_a and cls.is_a not in schema.classes:
            errors.append(f"Class {name!r} inherits from unknown class {cls.is_a!r}")
        for mixin in cls.mixins:
            if mixin not in schema.classes:
                errors.append(f"Class {name!r} uses unknown mixin {mixin!r}")
        for slot_name in cls.slots:
            if slot_name not in schema.slots:
                errors.append(f"Class {name!r} references unknown slot {slot_name!r}")

    # Check slot range references
    builtin_ranges = {
        "string",
        "integer",
        "float",
        "double",
        "boolean",
        "date",
        "datetime",
        "uri",
        "uriorcurie",
    }
    for name, slot in schema.slots.items():
        if (
            slot.range
            and slot.range not in builtin_ranges
            and slot.range not in schema.classes
            and slot.range not in schema.enums
        ):
            errors.append(f"Slot {name!r} has unknown range {slot.range!r}")

    # Check for inheritance cycles
    for name in schema.classes:
        visited: set[str] = set()
        current = name
        while current:
            if current in visited:
                errors.append(f"Inheritance cycle detected involving {name!r}")
                break
            visited.add(current)
            parent = schema.classes.get(current)
            current = parent.is_a if parent else None

    return errors


# =====================================================================
# Internal parsing helpers
# =====================================================================


def _validate_raw_schema(raw: dict[str, Any]) -> list[str]:
    """Basic structural checks before full parsing."""
    errors: list[str] = []
    if "name" not in raw and "id" not in raw:
        errors.append("Schema must have a 'name' or 'id' field")
    if "classes" in raw and not isinstance(raw["classes"], dict):
        errors.append("'classes' must be a mapping")
    if "slots" in raw and not isinstance(raw["slots"], dict):
        errors.append("'slots' must be a mapping")
    if "enums" in raw and not isinstance(raw["enums"], dict):
        errors.append("'enums' must be a mapping")
    return errors


def _parse_slot(name: str, raw: dict[str, Any] | None) -> SlotInfo:
    """Parse a single slot from raw YAML."""
    if not raw:
        return SlotInfo(name=name)
    return SlotInfo(
        name=name,
        description=str(raw.get("description", "")),
        range=str(raw.get("range", "string")),
        required=bool(raw.get("required", False)),
        identifier=bool(raw.get("identifier", False)),
        multivalued=bool(raw.get("multivalued", False)),
        pattern=raw.get("pattern"),
        minimum_value=_to_float(raw.get("minimum_value")),
        maximum_value=_to_float(raw.get("maximum_value")),
        annotations=dict(raw.get("annotations", {})),
    )


def _parse_class(name: str, raw: dict[str, Any] | None) -> ClassInfo:
    """Parse a single class from raw YAML."""
    if not raw:
        return ClassInfo(name=name)
    mixins = raw.get("mixins", [])
    slots = raw.get("slots", [])
    return ClassInfo(
        name=name,
        description=str(raw.get("description", "")),
        is_a=raw.get("is_a"),
        mixins=tuple(mixins) if isinstance(mixins, list) else (),
        slots=tuple(slots) if isinstance(slots, list) else (),
        slot_usage=dict(raw.get("slot_usage", {})),
        annotations=dict(raw.get("annotations", {})),
    )


def _parse_enum(name: str, raw: dict[str, Any] | None) -> EnumInfo:
    """Parse a single enum from raw YAML."""
    if not raw:
        return EnumInfo(name=name)
    pv_raw = raw.get("permissible_values", {})
    permissible_values: dict[str, str] = {}
    for val_name, val_info in (pv_raw or {}).items():
        if isinstance(val_info, dict):
            permissible_values[str(val_name)] = str(val_info.get("description", ""))
        else:
            permissible_values[str(val_name)] = str(val_info or "")
    return EnumInfo(
        name=name,
        description=str(raw.get("description", "")),
        permissible_values=permissible_values,
    )


def _parse_raw_schema(
    raw: dict[str, Any], source_path: str | None = None
) -> LinkMLSchema:
    """Convert raw YAML dict into a frozen LinkMLSchema."""
    classes = {
        name: _parse_class(name, info)
        for name, info in (raw.get("classes") or {}).items()
    }
    slots = {
        name: _parse_slot(name, info) for name, info in (raw.get("slots") or {}).items()
    }
    enums = {
        name: _parse_enum(name, info) for name, info in (raw.get("enums") or {}).items()
    }
    prefixes = {str(k): str(v) for k, v in (raw.get("prefixes") or {}).items()}

    return LinkMLSchema(
        name=str(raw.get("name", "")),
        id=str(raw.get("id", "")),
        version=str(raw.get("version", "")),
        description=str(raw.get("description", "")),
        prefixes=prefixes,
        classes=classes,
        slots=slots,
        enums=enums,
        source_path=source_path,
    )


def _to_float(value: Any) -> float | None:
    """Safely convert a value to float, returning None on failure."""
    if value is None:
        return None
    try:
        return float(value)
    except (TypeError, ValueError):
        return None
