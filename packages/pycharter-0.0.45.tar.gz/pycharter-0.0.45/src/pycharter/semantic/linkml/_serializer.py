"""LinkML YAML serializer — converts editor JSON to LinkML YAML.

Inverse of ``_bridge.py``. Takes the ontology JSON produced by the
unified editor's ``buildOntologyJSON()`` function and converts it into
a valid LinkML YAML document string.
"""

from __future__ import annotations

import logging
from typing import Any

import yaml  # type: ignore[import-untyped]

logger = logging.getLogger(__name__)

# LinkML built-in type mappings from editor data types
_DATA_TYPE_MAP: dict[str, str] = {
    "string": "string",
    "integer": "integer",
    "float": "float",
    "double": "double",
    "boolean": "boolean",
    "date": "date",
    "datetime": "datetime",
    "uri": "uri",
    "text": "string",
    "number": "float",
    "int": "integer",
    "bool": "boolean",
}


def editor_json_to_linkml_yaml(
    editor_json: dict[str, Any],
    *,
    ontology_name: str = "",
    ontology_version: str = "",
) -> str:
    """Convert unified editor ontology JSON to a LinkML YAML document.

    Args:
        editor_json: Dict with ``entities`` and optional ``relationships``
            keys, as produced by ``buildOntologyJSON()``.
        ontology_name: Schema name for the LinkML document.
        ontology_version: Schema version string.

    Returns:
        Valid LinkML YAML string.
    """
    entities = editor_json.get("entities", [])
    relationships = editor_json.get("relationships", [])

    schema_dict: dict[str, Any] = {}

    # Schema-level metadata
    name = ontology_name or "ontology"
    schema_dict["name"] = name
    schema_dict["id"] = f"https://statfyi.com/ontology/{name}"
    if ontology_version:
        schema_dict["version"] = ontology_version

    schema_dict["prefixes"] = {
        "linkml": "https://w3id.org/linkml/",
        name: f"https://statfyi.com/ontology/{name}/",
    }
    schema_dict["default_range"] = "string"

    # Build entity name set for relationship range resolution
    entity_names = {e.get("name", "") for e in entities}

    # Collect slots from attributes and relationships
    slots: dict[str, dict[str, Any]] = {}
    classes: dict[str, dict[str, Any]] = {}

    for entity in entities:
        entity_name = entity.get("name", "")
        if not entity_name:
            continue

        cls: dict[str, Any] = {}

        description = entity.get("description")
        if description:
            cls["description"] = description

        parent_class = entity.get("parent_class")
        if parent_class and parent_class in entity_names:
            cls["is_a"] = parent_class

        # Annotations for concept_type and tier
        annotations: dict[str, Any] = {}
        if entity.get("concept_type"):
            annotations["concept_type"] = entity["concept_type"]
        if entity.get("tier"):
            annotations["tier"] = entity["tier"]
        if annotations:
            cls["annotations"] = annotations

        # Build slots from attributes
        class_slots: list[str] = []
        attributes = entity.get("attributes", [])
        for attr in attributes:
            attr_name = attr.get("name", "")
            if not attr_name:
                continue

            slot: dict[str, Any] = {}
            data_type = attr.get("data_type", "string")
            slot["range"] = _DATA_TYPE_MAP.get(data_type, data_type)

            if attr.get("description"):
                slot["description"] = attr["description"]
            if attr.get("required"):
                slot["required"] = True
            if attr.get("identifier"):
                slot["identifier"] = True
            if attr.get("multivalued"):
                slot["multivalued"] = True
            if attr.get("pattern"):
                slot["pattern"] = attr["pattern"]

            slots[attr_name] = slot
            class_slots.append(attr_name)

        if class_slots:
            cls["slots"] = class_slots

        classes[entity_name] = cls

    # Build relationship slots
    for rel in relationships:
        rel_name = rel.get("name", "")
        source = rel.get("source", "")
        target = rel.get("target", "")
        if not rel_name or not source or not target:
            continue

        slot: dict[str, Any] = {"range": target}
        if rel.get("description"):
            slot["description"] = rel["description"]

        cardinality = rel.get("cardinality", "one-to-many")
        if cardinality in ("one-to-many", "many-to-many"):
            slot["multivalued"] = True

        slots[rel_name] = slot

        # Add slot to source class
        if source in classes:
            class_slots_list = classes[source].get("slots", [])
            if rel_name not in class_slots_list:
                class_slots_list.append(rel_name)
                classes[source]["slots"] = class_slots_list

    if slots:
        schema_dict["slots"] = slots
    if classes:
        schema_dict["classes"] = classes

    return yaml.dump(
        schema_dict,
        default_flow_style=False,
        sort_keys=False,
        allow_unicode=True,
    )
