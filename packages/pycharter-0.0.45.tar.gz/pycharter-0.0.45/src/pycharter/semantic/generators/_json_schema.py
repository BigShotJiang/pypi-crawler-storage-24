"""
JSON Schema generator from LinkML schemas.

Each LinkML class becomes a JSON Schema ``$defs`` entry. Slots map to
properties with appropriate types and constraints. Deterministic output.
"""

from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Any

from pycharter.semantic.linkml._loader import ClassInfo, LinkMLSchema
from pycharter.semantic.shared.errors import ArtifactGenerationError

logger = logging.getLogger(__name__)

_TYPE_MAP: dict[str, str] = {
    "string": "string",
    "integer": "integer",
    "float": "number",
    "double": "number",
    "boolean": "boolean",
    "date": "string",
    "datetime": "string",
    "uri": "string",
    "uriorcurie": "string",
}

_FORMAT_MAP: dict[str, str] = {
    "date": "date",
    "datetime": "date-time",
    "uri": "uri",
}


class JsonSchemaGenerator:
    """Generates JSON Schema from a LinkML schema.

    Attributes:
        format_name: ``"json-schema"``
    """

    @property
    def format_name(self) -> str:
        """Return the generator format identifier."""
        return "json-schema"

    def generate(
        self,
        schema: LinkMLSchema,
        output_dir: Path,
    ) -> list[Path]:
        """Generate JSON Schema files.

        Args:
            schema: Loaded LinkML schema.
            output_dir: Directory for output files.

        Returns:
            List of created file paths.
        """
        output_dir.mkdir(parents=True, exist_ok=True)
        try:
            doc = self._build(schema)
        except Exception as exc:
            raise ArtifactGenerationError(
                f"JSON Schema generation failed: {exc}",
                generator=self.format_name,
            ) from exc

        out_path = output_dir / "schema.json"
        out_path.write_text(
            json.dumps(doc, indent=2, sort_keys=True) + "\n",
            encoding="utf-8",
        )
        logger.info("wrote JSON Schema to %s", out_path)
        return [out_path]

    # -----------------------------------------------------------------
    # Internal
    # -----------------------------------------------------------------

    def _build(self, schema: LinkMLSchema) -> dict[str, Any]:
        """Build the JSON Schema document."""
        defs: dict[str, Any] = {}

        # Enums as string enums
        for name in sorted(schema.enums):
            enum = schema.enums[name]
            defs[name] = {
                "type": "string",
                "enum": sorted(enum.permissible_values.keys()),
                "description": enum.description,
            }

        # Classes as object schemas
        for name in sorted(schema.classes):
            cls = schema.classes[name]
            defs[name] = self._build_class(cls, schema)

        doc: dict[str, Any] = {
            "$schema": "https://json-schema.org/draft/2020-12/schema",
            "$comment": (
                f"Generated from LinkML schema: {schema.name} v{schema.version}"
            ),
            "$defs": defs,
        }
        return doc

    def _build_class(self, cls: ClassInfo, schema: LinkMLSchema) -> dict[str, Any]:
        """Build a JSON Schema object for a single class."""
        properties: dict[str, Any] = {}
        required: list[str] = []

        for slot_name in cls.slots:
            slot = schema.slots.get(slot_name)
            if not slot:
                continue

            usage = cls.slot_usage.get(slot_name, {})
            prop = _slot_to_property(slot_name, slot, schema)
            properties[slot_name] = prop

            is_required = usage.get("required", slot.required)
            is_identifier = usage.get("identifier", slot.identifier)
            if is_required or is_identifier:
                required.append(slot_name)

        result: dict[str, Any] = {
            "type": "object",
            "description": cls.description,
            "properties": properties,
        }
        if required:
            result["required"] = sorted(required)

        if cls.is_a and cls.is_a in schema.classes:
            result["allOf"] = [{"$ref": f"#/$defs/{cls.is_a}"}]

        return result


def _slot_to_property(
    name: str,
    slot: Any,
    schema: LinkMLSchema,
) -> dict[str, Any]:
    """Convert a slot to a JSON Schema property."""
    prop: dict[str, Any] = {}

    if slot.description:
        prop["description"] = slot.description

    # Determine type
    if slot.range in schema.classes:
        prop["$ref"] = f"#/$defs/{slot.range}"
    elif slot.range in schema.enums:
        prop["$ref"] = f"#/$defs/{slot.range}"
    else:
        json_type = _TYPE_MAP.get(slot.range, "string")
        prop["type"] = json_type
        fmt = _FORMAT_MAP.get(slot.range)
        if fmt:
            prop["format"] = fmt

    if slot.pattern:
        prop["pattern"] = slot.pattern
    if slot.minimum_value is not None:
        prop["minimum"] = slot.minimum_value
    if slot.maximum_value is not None:
        prop["maximum"] = slot.maximum_value

    if slot.multivalued:
        return {"type": "array", "items": prop}

    return prop
