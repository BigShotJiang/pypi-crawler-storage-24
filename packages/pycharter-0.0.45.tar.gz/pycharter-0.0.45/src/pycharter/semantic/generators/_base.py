"""
Base protocol and registry for artifact generators.

Each generator takes a LinkMLSchema and produces output files in a given
format. The registry maps format names to generators, allowing CLI and
API code to look them up dynamically.
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Protocol, runtime_checkable

from pycharter.semantic.linkml._loader import LinkMLSchema
from pycharter.semantic.shared.errors import ArtifactGenerationError

logger = logging.getLogger(__name__)


@runtime_checkable
class ArtifactGenerator(Protocol):
    """Protocol for schema artifact generators.

    Implementations must produce deterministic output: the same schema
    version always generates byte-identical files.
    """

    @property
    def format_name(self) -> str:
        """Short identifier for this generator (e.g. ``"pydantic"``)."""
        ...

    def generate(
        self,
        schema: LinkMLSchema,
        output_dir: Path,
    ) -> list[Path]:
        """Generate artifacts from a LinkML schema.

        Args:
            schema: Loaded LinkML schema.
            output_dir: Directory where artifacts are written.

        Returns:
            List of file paths that were created.

        Raises:
            ArtifactGenerationError: If generation fails.
        """
        ...


class GeneratorRegistry:
    """Registry mapping format names to generator instances.

    Example::

        registry = GeneratorRegistry()
        registry.register(PydanticGenerator())
        gen = registry.get("pydantic")
        gen.generate(schema, output_dir)
    """

    def __init__(self) -> None:
        self._generators: dict[str, ArtifactGenerator] = {}

    def register(self, generator: ArtifactGenerator) -> None:
        """Register a generator by its format_name."""
        name = generator.format_name
        self._generators[name] = generator
        logger.debug("registered generator %r", name)

    def get(self, format_name: str) -> ArtifactGenerator:
        """Look up a generator by format name.

        Raises:
            ArtifactGenerationError: If no generator is registered.
        """
        gen = self._generators.get(format_name)
        if gen is None:
            available = ", ".join(sorted(self._generators)) or "(none)"
            raise ArtifactGenerationError(
                f"Unknown generator format {format_name!r}. Available: {available}",
                generator=format_name,
            )
        return gen

    def list_formats(self) -> list[str]:
        """Return sorted list of registered format names."""
        return sorted(self._generators.keys())

    def generate_all(
        self,
        schema: LinkMLSchema,
        output_dir: Path,
    ) -> dict[str, list[Path]]:
        """Run all registered generators.

        Returns:
            Mapping of format name to list of generated file paths.
        """
        results: dict[str, list[Path]] = {}
        for name, gen in sorted(self._generators.items()):
            fmt_dir = output_dir / name
            fmt_dir.mkdir(parents=True, exist_ok=True)
            results[name] = gen.generate(schema, fmt_dir)
        return results
