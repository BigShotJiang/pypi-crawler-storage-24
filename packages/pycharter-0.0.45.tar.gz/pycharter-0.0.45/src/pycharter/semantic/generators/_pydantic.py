"""
Pydantic v2 model generator from LinkML schemas.

Each LinkML class becomes a Pydantic ``BaseModel`` with typed fields
derived from slot definitions. Deterministic output: identical schema →
identical Python source.
"""

from __future__ import annotations

import logging
from pathlib import Path

from pycharter.semantic.linkml._loader import ClassInfo, LinkMLSchema
from pycharter.semantic.shared.errors import ArtifactGenerationError

logger = logging.getLogger(__name__)

# Maps LinkML range names to Python type annotations
_TYPE_MAP: dict[str, str] = {
    "string": "str",
    "integer": "int",
    "float": "float",
    "double": "float",
    "boolean": "bool",
    "date": "datetime.date",
    "datetime": "datetime.datetime",
    "uri": "str",
    "uriorcurie": "str",
}


class PydanticGenerator:
    """Generates Pydantic v2 BaseModel classes from a LinkML schema.

    Attributes:
        format_name: ``"pydantic"``
    """

    @property
    def format_name(self) -> str:
        """Return the generator format identifier."""
        return "pydantic"

    def generate(
        self,
        schema: LinkMLSchema,
        output_dir: Path,
    ) -> list[Path]:
        """Generate Pydantic model source files.

        Args:
            schema: Loaded LinkML schema.
            output_dir: Directory for output files.

        Returns:
            List of created file paths.

        Raises:
            ArtifactGenerationError: If generation fails.
        """
        output_dir.mkdir(parents=True, exist_ok=True)
        try:
            source = self._render(schema)
        except Exception as exc:
            raise ArtifactGenerationError(
                f"Pydantic generation failed: {exc}",
                generator=self.format_name,
            ) from exc

        out_path = output_dir / "models.py"
        out_path.write_text(source, encoding="utf-8")
        logger.info("wrote pydantic models to %s", out_path)
        return [out_path]

    # -----------------------------------------------------------------
    # Internal rendering
    # -----------------------------------------------------------------

    def _render(self, schema: LinkMLSchema) -> str:
        """Render full Python source for all classes."""
        lines: list[str] = [
            '"""',
            f"Auto-generated Pydantic models from LinkML schema: {schema.name}",
            "",
            f"Schema version: {schema.version}",
            '"""',
            "",
            "from __future__ import annotations",
            "",
        ]

        # Conditional imports
        needs_datetime = any(
            slot.range in ("date", "datetime") for slot in schema.slots.values()
        )
        if needs_datetime:
            lines.append("import datetime")
            lines.append("")

        needs_enum = bool(schema.enums)
        if needs_enum:
            lines.append("from enum import StrEnum")
            lines.append("")

        lines.append("from pydantic import BaseModel, Field")
        lines.append("")
        lines.append("")

        # Render enums first (models may reference them)
        for name in sorted(schema.enums):
            lines.extend(self._render_enum(name, schema))
            lines.append("")

        # Topological sort classes for inheritance ordering
        ordered = _topo_sort_classes(schema)
        for cls_name in ordered:
            cls = schema.classes[cls_name]
            lines.extend(self._render_class(cls, schema))
            lines.append("")

        return "\n".join(lines)

    def _render_enum(self, name: str, schema: LinkMLSchema) -> list[str]:
        """Render a StrEnum class."""
        enum = schema.enums[name]
        lines = [f"class {name}(StrEnum):"]
        lines.append(f'    """{enum.description or name}."""')
        lines.append("")
        for val_name, desc in sorted(enum.permissible_values.items()):
            lines.append(f'    {val_name.upper()} = "{val_name}"')
            if desc:
                lines.append(f'    """{desc}"""')
        if not enum.permissible_values:
            lines.append("    pass")
        lines.append("")
        return lines

    def _render_class(self, cls: ClassInfo, schema: LinkMLSchema) -> list[str]:
        """Render a Pydantic BaseModel class."""
        parent = cls.is_a if cls.is_a else "BaseModel"
        lines = [f"class {cls.name}({parent}):"]
        lines.append(f'    """{cls.description or cls.name}."""')
        lines.append("")

        if not cls.slots:
            lines.append("    pass")
            return lines

        for slot_name in cls.slots:
            slot = schema.slots.get(slot_name)
            if not slot:
                continue

            # Check slot_usage overrides
            usage = cls.slot_usage.get(slot_name, {})
            py_type = _resolve_type(slot.range, slot.multivalued, schema)
            is_required = usage.get("required", slot.required)
            is_identifier = usage.get("identifier", slot.identifier)

            # Build Field kwargs
            field_args: list[str] = []
            if slot.description:
                field_args.append(f'description="{_escape(slot.description)}"')
            if is_identifier:
                field_args.append("frozen=True")

            default = "..." if is_required or is_identifier else "None"
            if not is_required and not is_identifier:
                py_type = f"{py_type} | None"

            field_str = (
                f"Field({', '.join(field_args)})"
                if field_args
                else f"Field(default={default})"
            )
            if is_required or is_identifier:
                lines.append(f"    {slot_name}: {py_type} = {field_str}")
            else:
                lines.append(f"    {slot_name}: {py_type} = {field_str}")

        return lines


# =====================================================================
# Helpers
# =====================================================================


def _resolve_type(
    range_name: str,
    multivalued: bool,
    schema: LinkMLSchema,
) -> str:
    """Convert a LinkML range to a Python type string."""
    if range_name in _TYPE_MAP:
        base = _TYPE_MAP[range_name]
    elif range_name in schema.enums:
        base = range_name
    elif range_name in schema.classes:
        base = range_name
    else:
        base = "str"

    return f"list[{base}]" if multivalued else base


def _topo_sort_classes(schema: LinkMLSchema) -> list[str]:
    """Topological sort of classes for inheritance ordering."""
    visited: set[str] = set()
    order: list[str] = []

    def visit(name: str) -> None:
        if name in visited:
            return
        visited.add(name)
        cls = schema.classes.get(name)
        if cls and cls.is_a and cls.is_a in schema.classes:
            visit(cls.is_a)
        order.append(name)

    for name in sorted(schema.classes):
        visit(name)
    return order


def _escape(text: str) -> str:
    """Escape a string for use in Python source."""
    return text.replace("\\", "\\\\").replace('"', '\\"')
