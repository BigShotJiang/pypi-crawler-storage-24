"""
SQL DDL generator from LinkML schemas.

Each LinkML class becomes a CREATE TABLE statement. Slots map to columns
with appropriate SQL types. Enums become CHECK constraints.
"""

from __future__ import annotations

import logging
from pathlib import Path

from pycharter.semantic.linkml._loader import LinkMLSchema
from pycharter.semantic.shared.errors import ArtifactGenerationError

logger = logging.getLogger(__name__)

_SQL_TYPE_MAP: dict[str, str] = {
    "string": "TEXT",
    "integer": "INTEGER",
    "float": "REAL",
    "double": "DOUBLE PRECISION",
    "boolean": "BOOLEAN",
    "date": "DATE",
    "datetime": "TIMESTAMP",
    "uri": "TEXT",
    "uriorcurie": "TEXT",
}


class SqlDdlGenerator:
    """Generates SQL DDL from a LinkML schema.

    Attributes:
        format_name: ``"sql-ddl"``
    """

    @property
    def format_name(self) -> str:
        """Return the generator format identifier."""
        return "sql-ddl"

    def generate(
        self,
        schema: LinkMLSchema,
        output_dir: Path,
    ) -> list[Path]:
        """Generate SQL DDL files.

        Args:
            schema: Loaded LinkML schema.
            output_dir: Directory for output files.

        Returns:
            List of created file paths.
        """
        output_dir.mkdir(parents=True, exist_ok=True)
        try:
            ddl = self._render(schema)
        except Exception as exc:
            raise ArtifactGenerationError(
                f"SQL DDL generation failed: {exc}",
                generator=self.format_name,
            ) from exc

        out_path = output_dir / "schema.sql"
        out_path.write_text(ddl, encoding="utf-8")
        logger.info("wrote SQL DDL to %s", out_path)
        return [out_path]

    # -----------------------------------------------------------------
    # Internal rendering
    # -----------------------------------------------------------------

    def _render(self, schema: LinkMLSchema) -> str:
        """Render the full DDL script."""
        lines: list[str] = [
            f"-- Generated from LinkML schema: {schema.name} v{schema.version}",
            "",
        ]

        class_names = set(schema.classes.keys())
        enum_values: dict[str, list[str]] = {
            name: sorted(e.permissible_values.keys())
            for name, e in schema.enums.items()
        }

        for cls_name in sorted(schema.classes):
            cls = schema.classes[cls_name]
            if not cls.slots:
                continue

            table = _to_snake(cls_name)
            lines.append(f"CREATE TABLE {table} (")

            col_lines: list[str] = []
            for slot_name in cls.slots:
                slot = schema.slots.get(slot_name)
                if not slot:
                    continue

                usage = cls.slot_usage.get(slot_name, {})
                is_required = usage.get("required", slot.required)
                is_identifier = usage.get("identifier", slot.identifier)

                # Type
                if slot.range in class_names:
                    sql_type = "TEXT"  # FK reference
                elif slot.range in enum_values:
                    sql_type = "TEXT"
                else:
                    sql_type = _SQL_TYPE_MAP.get(slot.range, "TEXT")

                col = f"    {slot_name} {sql_type}"
                if is_identifier:
                    col += " PRIMARY KEY"
                elif is_required:
                    col += " NOT NULL"

                # Enum CHECK constraint
                if slot.range in enum_values:
                    vals = ", ".join(f"'{v}'" for v in enum_values[slot.range])
                    col += f" CHECK ({slot_name} IN ({vals}))"

                col_lines.append(col)

            lines.append(",\n".join(col_lines))
            lines.append(");")
            lines.append("")

        return "\n".join(lines)


def _to_snake(name: str) -> str:
    """Convert PascalCase to snake_case."""
    result: list[str] = []
    for char in name:
        if char.isupper() and result:
            result.append("_")
        result.append(char.lower())
    return "".join(result)
