"""
SHACL shape generator from LinkML schemas.

Generates SHACL NodeShapes and PropertyShapes from LinkML class/slot
definitions. Slot cardinality maps to sh:minCount/sh:maxCount, slot
range to sh:datatype or sh:class.
"""

from __future__ import annotations

import logging
from pathlib import Path

from pycharter.semantic.linkml._loader import LinkMLSchema
from pycharter.semantic.shared.errors import ArtifactGenerationError

logger = logging.getLogger(__name__)

_XSD_MAP: dict[str, str] = {
    "string": "xsd:string",
    "integer": "xsd:integer",
    "float": "xsd:float",
    "double": "xsd:double",
    "boolean": "xsd:boolean",
    "date": "xsd:date",
    "datetime": "xsd:dateTime",
}


class ShaclGenerator:
    """Generates SHACL shapes in Turtle format from a LinkML schema.

    Attributes:
        format_name: ``"shacl"``
    """

    @property
    def format_name(self) -> str:
        """Return the generator format identifier."""
        return "shacl"

    def generate(
        self,
        schema: LinkMLSchema,
        output_dir: Path,
    ) -> list[Path]:
        """Generate SHACL shape files.

        Args:
            schema: Loaded LinkML schema.
            output_dir: Directory for output files.

        Returns:
            List of created file paths.
        """
        output_dir.mkdir(parents=True, exist_ok=True)
        try:
            turtle = self._render(schema)
        except Exception as exc:
            raise ArtifactGenerationError(
                f"SHACL generation failed: {exc}",
                generator=self.format_name,
            ) from exc

        out_path = output_dir / "shapes.ttl"
        out_path.write_text(turtle, encoding="utf-8")
        logger.info("wrote SHACL shapes to %s", out_path)
        return [out_path]

    # -----------------------------------------------------------------
    # Internal rendering
    # -----------------------------------------------------------------

    def _render(self, schema: LinkMLSchema) -> str:
        """Render all SHACL shapes as Turtle."""
        base = schema.id or f"https://example.org/{schema.name}"
        lines: list[str] = [
            f"@prefix : <{base}/> .",
            "@prefix sh: <http://www.w3.org/ns/shacl#> .",
            "@prefix xsd: <http://www.w3.org/2001/XMLSchema#> .",
            "",
        ]

        class_names = set(schema.classes.keys())

        for cls_name in sorted(schema.classes):
            cls = schema.classes[cls_name]
            if not cls.slots:
                continue

            lines.append(f":{cls_name}Shape a sh:NodeShape ;")
            lines.append(f"    sh:targetClass :{cls_name} ;")

            for slot_name in cls.slots:
                slot = schema.slots.get(slot_name)
                if not slot:
                    continue

                usage = cls.slot_usage.get(slot_name, {})
                is_required = usage.get("required", slot.required)
                is_identifier = usage.get("identifier", slot.identifier)

                lines.append("    sh:property [")
                lines.append(f"        sh:path :{slot_name} ;")

                # Type constraint
                if slot.range in class_names:
                    lines.append(f"        sh:class :{slot.range} ;")
                elif slot.range in _XSD_MAP:
                    lines.append(f"        sh:datatype {_XSD_MAP[slot.range]} ;")

                # Cardinality
                if is_required or is_identifier:
                    lines.append("        sh:minCount 1 ;")
                if not slot.multivalued:
                    lines.append("        sh:maxCount 1 ;")

                # Pattern
                if slot.pattern:
                    escaped = slot.pattern.replace("\\", "\\\\")
                    lines.append(f'        sh:pattern "{escaped}" ;')

                # Numeric constraints
                if slot.minimum_value is not None:
                    lines.append(f"        sh:minInclusive {slot.minimum_value} ;")
                if slot.maximum_value is not None:
                    lines.append(f"        sh:maxInclusive {slot.maximum_value} ;")

                # Close property
                last = lines[-1]
                lines[-1] = last.rstrip(" ;") + ""
                lines.append("    ] ;")

            # Close shape
            last = lines[-1]
            lines[-1] = last.rstrip(" ;") + " ."
            lines.append("")

        return "\n".join(lines)
