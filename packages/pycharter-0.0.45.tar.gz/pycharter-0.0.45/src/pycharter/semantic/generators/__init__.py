"""
Artifact generators for LinkML schemas.

Generates downstream artifacts (Pydantic models, OWL ontologies, SHACL
shapes, JSON Schema, SQL DDL) from a loaded LinkML schema. Each generator
conforms to the ``ArtifactGenerator`` protocol.
"""

from __future__ import annotations
