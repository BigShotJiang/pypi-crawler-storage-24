"""
OWL/RDF ontology generator from LinkML schemas.

Generates an OWL ontology in Turtle format with class hierarchies,
object properties (from class-ranged slots), data properties, and
semantic annotations (transitivity, symmetry, inverse).
"""

from __future__ import annotations

import logging
from pathlib import Path

from pycharter.semantic.linkml._loader import LinkMLSchema
from pycharter.semantic.shared.errors import ArtifactGenerationError

logger = logging.getLogger(__name__)


class OwlGenerator:
    """Generates an OWL ontology in Turtle format.

    Attributes:
        format_name: ``"owl"``
    """

    @property
    def format_name(self) -> str:
        """Return the generator format identifier."""
        return "owl"

    def generate(
        self,
        schema: LinkMLSchema,
        output_dir: Path,
    ) -> list[Path]:
        """Generate OWL Turtle files.

        Args:
            schema: Loaded LinkML schema.
            output_dir: Directory for output files.

        Returns:
            List of created file paths.
        """
        output_dir.mkdir(parents=True, exist_ok=True)
        try:
            turtle = self._render(schema)
        except Exception as exc:
            raise ArtifactGenerationError(
                f"OWL generation failed: {exc}",
                generator=self.format_name,
            ) from exc

        out_path = output_dir / "ontology.ttl"
        out_path.write_text(turtle, encoding="utf-8")
        logger.info("wrote OWL ontology to %s", out_path)
        return [out_path]

    # -----------------------------------------------------------------
    # Internal rendering
    # -----------------------------------------------------------------

    def _render(self, schema: LinkMLSchema) -> str:
        """Render the OWL ontology as Turtle."""
        base = schema.id or f"https://example.org/{schema.name}"
        lines: list[str] = [
            f"@prefix : <{base}/> .",
            "@prefix owl: <http://www.w3.org/2002/07/owl#> .",
            "@prefix rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#> .",
            "@prefix rdfs: <http://www.w3.org/2000/01/rdf-schema#> .",
            "@prefix xsd: <http://www.w3.org/2001/XMLSchema#> .",
            "",
            f"<{base}> a owl:Ontology ;",
            f'    rdfs:label "{schema.name}" .',
            "",
        ]

        # Classes
        for name in sorted(schema.classes):
            cls = schema.classes[name]
            lines.append(f":{name} a owl:Class ;")
            lines.append(f'    rdfs:label "{name}" ;')
            if cls.description:
                desc = cls.description.replace('"', '\\"')
                lines.append(f'    rdfs:comment "{desc}" ;')
            if cls.is_a and cls.is_a in schema.classes:
                lines.append(f"    rdfs:subClassOf :{cls.is_a} ;")
            # Close
            last = lines[-1]
            lines[-1] = last.rstrip(" ;") + " ."
            lines.append("")

        # Slots → properties
        class_names = set(schema.classes.keys())
        for name in sorted(schema.slots):
            slot = schema.slots[name]
            annotations = slot.annotations or {}
            is_object = slot.range in class_names

            if is_object:
                lines.append(f":{name} a owl:ObjectProperty ;")
            else:
                lines.append(f":{name} a owl:DatatypeProperty ;")

            lines.append(f'    rdfs:label "{name}" ;')

            if slot.description:
                desc = slot.description.replace('"', '\\"')
                lines.append(f'    rdfs:comment "{desc}" ;')

            if is_object:
                lines.append(f"    rdfs:range :{slot.range} ;")

            # Semantic annotations
            if annotations.get("symmetric"):
                lines.append(f":{name} a owl:SymmetricProperty .")
            if annotations.get("transitive"):
                lines.append(f":{name} a owl:TransitiveProperty .")
            inv = annotations.get("inverse")
            if inv:
                lines.append(f"    owl:inverseOf :{inv} ;")

            last = lines[-1]
            lines[-1] = last.rstrip(" ;") + " ."
            lines.append("")

        return "\n".join(lines)
