"""
Ingestion layer for pycharter semantic layer.

Bridges pycharter contracts with the semantic knowledge system by
importing ontology files and materializing them into the knowledge graph.
"""

from __future__ import annotations

from pycharter.semantic.ingestion.importer import OntologyImporter

__all__ = [
    "OntologyImporter",
]
