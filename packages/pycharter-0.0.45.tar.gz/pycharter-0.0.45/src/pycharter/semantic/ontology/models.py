"""
Ontology models for the pycharter semantic layer.

Defines the core data structures for field mappings, field bindings,
concept tiers, concept types, relationships, lineage, and inverse mappings.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import StrEnum
from typing import Any


class ConceptTier(StrEnum):
    """Built-in governance tiers for concepts.

    These are the default tiers shipped with pycharter.  Custom tiers
    can be added via the ontology schema without modifying this enum.
    Use ``schema_loader.validate_tier()`` for runtime validation.
    """

    CORE = "core"
    """Tier 1: Core concepts governed by central team."""

    DOMAIN = "domain"
    """Tier 2: Domain concepts governed by domain teams."""

    FREE = "free"
    """Tier 3: Free-form concepts with no governance."""


class ConceptType(StrEnum):
    """Built-in concept types for the knowledge graph.

    These are the default types shipped with pycharter.  Custom types
    can be added via the ontology schema without modifying this enum.
    Use ``schema_loader.validate_concept_type()`` for runtime validation.
    """

    ENTITY = "entity"
    """A thing with identity (customer, product, system)."""

    PROCESS = "process"
    """A sequence of steps (checkout, onboarding)."""

    EVENT = "event"
    """Something that happens at a point in time."""

    ATTRIBUTE = "attribute"
    """A property or measurement."""

    RULE = "rule"
    """A constraint or policy."""

    SYSTEM = "system"
    """An external system or service."""

    CONCEPT = "concept"
    """An abstract idea."""

    METRIC = "metric"
    """A computed business measure."""


class RelationshipType(StrEnum):
    """Built-in relationship types between fields or concepts.

    These are the default types shipped with pycharter.  Custom types
    can be added via the ontology schema without modifying this enum.
    Use ``schema_loader.validate_relationship_type()`` for runtime validation.
    """

    # Original field-level types (backward compatible)
    REFERENCES = "references"
    """Foreign key or reference relationship."""

    DERIVED_FROM = "derived_from"
    """Field is computed from another field."""

    SAME_AS = "same_as"
    """Fields represent the same concept."""

    RELATED_TO = "related_to"
    """General relationship."""

    # Knowledge schema types
    IS_A = "is_a"
    """X is a kind of Y (taxonomy)."""

    HAS = "has"
    """X contains or owns Y (composition)."""

    DEPENDS_ON = "depends_on"
    """X requires Y to function."""

    PRECEDES = "precedes"
    """X happens before Y (temporal ordering)."""

    CAUSES = "causes"
    """X leads to or triggers Y."""

    IMPLEMENTS = "implements"
    """X realizes or is a concrete form of Y."""

    GOVERNS = "governs"
    """X constrains or regulates Y."""

    DESCRIBES = "describes"
    """X is a property or attribute of Y."""

    EQUIVALENT_TO = "equivalent_to"
    """X represents the same thing as Y."""


def get_inverse_map() -> dict[str, str]:
    """Return the inverse mapping built from the ontology schema.

    Delegates to ``schema_loader.get_inverse_map()`` which reads the
    ontology schema YAML as source of truth.
    """
    # Lazy import to avoid circular dependency (schema_loader used to import
    # INVERSE_MAP from this module).
    from pycharter.semantic.ontology.schema_loader import (
        get_inverse_map as _get_inverse_map,
    )

    return _get_inverse_map()


def resolve_inverse(relationship_type: str) -> str:
    """Return the inverse name for a relationship type.

    Delegates to ``schema_loader.get_inverse()`` which reads the
    ontology schema YAML as source of truth.
    """
    from pycharter.semantic.ontology.schema_loader import get_inverse

    return get_inverse(relationship_type)


@dataclass(frozen=True, slots=True)
class Lineage:
    """Tracks the origin of a field.

    Attributes:
        derived_from: Field this was derived from (if any).
        source_system: System that produces this field.
    """

    derived_from: str | None = None
    source_system: str | None = None

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "derived_from": self.derived_from,
            "source_system": self.source_system,
        }


@dataclass(frozen=True, slots=True)
class Relationship:
    """A relationship between two fields.

    Attributes:
        target: Target field path (e.g., "customers.id").
        type: Type of relationship (string, validated against schema).
    """

    target: str
    type: str

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "target": self.target,
            "type": self.type,
        }


@dataclass(frozen=True, slots=True)
class Concept:
    """Full definition of a single concept in the vocabulary.

    Mirrors the extended ontologies.yaml schema and can be losslessly
    converted to/from SKOS JSON-LD.
    """

    id: str
    label: str
    definition: str | None = None
    broader: str | None = None
    tags: tuple[str, ...] = ()
    alt_labels: tuple[str, ...] = ()
    notation: str | None = None
    examples: tuple[str, ...] = ()
    exact_match: str | None = None
    deprecated: bool = False
    replaced_by: str | None = None
    concept_type: str | None = None

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary (round-trip safe with YAML schema)."""
        result: dict[str, Any] = {"id": self.id, "label": self.label}
        if self.definition is not None:
            result["definition"] = self.definition
        if self.broader is not None:
            result["broader"] = self.broader
        if self.tags:
            result["tags"] = list(self.tags)
        if self.alt_labels:
            result["alt_labels"] = list(self.alt_labels)
        if self.notation is not None:
            result["notation"] = self.notation
        if self.examples:
            result["examples"] = list(self.examples)
        if self.exact_match is not None:
            result["exact_match"] = self.exact_match
        if self.deprecated:
            result["deprecated"] = self.deprecated
        if self.replaced_by is not None:
            result["replaced_by"] = self.replaced_by
        if self.concept_type is not None:
            result["concept_type"] = self.concept_type
        return result


@dataclass(slots=True)
class ConceptScheme:
    """A complete concept scheme (vocabulary).

    Mirrors the top-level ``scheme:`` + ``concepts:`` structure in
    ontologies.yaml.  Mutable because concepts are appended during parsing.
    """

    id: str
    title: str
    version: str
    description: str = ""
    base_uri: str | None = None
    concepts: list[Concept] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        result: dict[str, Any] = {
            "scheme": {
                "id": self.id,
                "title": self.title,
                "version": self.version,
            },
            "concepts": [c.to_dict() for c in self.concepts],
        }
        if self.description:
            result["scheme"]["description"] = self.description
        if self.base_uri:
            result["scheme"]["base_uri"] = self.base_uri
        return result


@dataclass(frozen=True, slots=True)
class FieldConceptBinding:
    """Semantic annotation for a single field.

    Attributes:
        concept: The semantic concept this field represents.
        broader: Parent concept in the hierarchy (deprecated -- use ontologies.yaml).
        definition: Human-readable definition (deprecated -- use ontologies.yaml).
        tags: Tags for categorization.
        owner: Team or person owning this field.
        description: Field-specific business description.
        deprecated: Whether this field mapping is deprecated.
        lineage: Data lineage information.
        relationships: Relationships to other fields.
    """

    concept: str
    broader: str | None = None
    definition: str | None = None
    tags: tuple[str, ...] = ()
    owner: str | None = None
    description: str | None = None
    deprecated: bool = False
    lineage: Lineage | None = None
    relationships: tuple[Relationship, ...] = ()

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        result: dict[str, Any] = {
            "concept": self.concept,
        }
        if self.broader is not None:
            result["broader"] = self.broader
        if self.definition is not None:
            result["definition"] = self.definition
        if self.tags:
            result["tags"] = list(self.tags)
        if self.owner is not None:
            result["owner"] = self.owner
        if self.description is not None:
            result["description"] = self.description
        if self.deprecated:
            result["deprecated"] = self.deprecated
        if self.lineage is not None:
            result["lineage"] = self.lineage.to_dict()
        if self.relationships:
            result["relationships"] = [r.to_dict() for r in self.relationships]
        return result


@dataclass(frozen=True, slots=True)
class FieldBinding:
    """Binds a physical schema field to a LinkML class and slot.

    This is the class/slot-centric replacement for FieldConceptBinding.
    Used by the new ontology artifact format that references a published
    LinkML domain schema.

    Attributes:
        class_name: LinkML class name the field belongs to.
        slot_name: LinkML slot name within that class.
        tags: Additional field-level tags.
        owner: Team or person owning this field.
        lineage: Data lineage information.
    """

    class_name: str
    slot_name: str
    tags: tuple[str, ...] = ()
    owner: str | None = None
    lineage: Lineage | None = None

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        result: dict[str, Any] = {
            "class": self.class_name,
            "slot": self.slot_name,
        }
        if self.tags:
            result["tags"] = list(self.tags)
        if self.owner is not None:
            result["owner"] = self.owner
        if self.lineage is not None:
            result["lineage"] = self.lineage.to_dict()
        return result


@dataclass(slots=True)
class FieldMapping:
    """A versioned field mapping artifact for a data contract.

    Maps data contract fields to ontology concepts.  Supports two formats:

    - **New format**: ``domain_schema`` + ``field_bindings`` as FieldBinding
    - **Legacy format**: ``field_bindings`` as FieldConceptBinding

    Attributes:
        version: Field mapping version string.
        domain_schema: Reference to a published LinkML schema
            in ``"name:version"`` format. None for legacy artifacts.
        field_bindings: Mapping of field path to its semantic annotation.
            Values may be FieldBinding (new) or FieldConceptBinding (legacy).
    """

    version: str
    domain_schema: str | None = None
    field_bindings: dict[str, FieldBinding | FieldConceptBinding] = field(
        default_factory=dict
    )

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        result: dict[str, Any] = {"version": self.version}
        if self.domain_schema:
            result["domain_schema"] = self.domain_schema
        result["field_bindings"] = {
            name: fb.to_dict() for name, fb in self.field_bindings.items()
        }
        return result
