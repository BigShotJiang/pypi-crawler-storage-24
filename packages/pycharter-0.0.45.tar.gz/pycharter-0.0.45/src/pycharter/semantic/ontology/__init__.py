"""
Ontology subpackage for the pycharter semantic layer.

Provides data models, parsing, validation, and taxonomy for
field mappings and semantic annotations on data contract fields.
"""

from __future__ import annotations

from pycharter.semantic.ontology.models import (
    Concept,
    ConceptScheme,
    ConceptTier,
    FieldBinding,
    FieldConceptBinding,
    FieldMapping,
    Lineage,
    Relationship,
    RelationshipType,
)
from pycharter.semantic.ontology.parser import (
    parse_field_mapping,
    parse_field_mapping_file,
)
from pycharter.semantic.ontology.taxonomy import (
    classify_concept,
    get_concept_hierarchy,
    list_core_concepts,
    register_core_concept,
)
from pycharter.semantic.ontology.validator import (
    validate_field_mapping,
    validate_field_mapping_payload,
)

__all__ = [
    # Models
    "Concept",
    "ConceptScheme",
    "ConceptTier",
    "RelationshipType",
    "Lineage",
    "Relationship",
    "FieldBinding",
    "FieldConceptBinding",
    "FieldMapping",
    # Parser
    "parse_field_mapping",
    "parse_field_mapping_file",
    # Validator
    "validate_field_mapping_payload",
    "validate_field_mapping",
    # Taxonomy
    "classify_concept",
    "register_core_concept",
    "list_core_concepts",
    "get_concept_hierarchy",
]
