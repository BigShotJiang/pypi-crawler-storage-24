"""Normalization helpers for field mapping payloads.

Handles both the new LinkML-backed format (``domain_schema`` +
class/slot bindings) and the legacy concept-centric format
(``fields``/``field_bindings`` + concept bindings).

Normalization runs at the API boundary (before validation/parsing).
The canonical form uses:

- ``concept`` (not ``concept_id``) for concept references
- ``field_bindings`` (not ``fields``) as the bindings key
- JSONPath-style field paths starting with ``$``
"""

from __future__ import annotations

from typing import Any


def to_jsonpath(path: str) -> str:
    """Convert a field path to canonical JSONPath form."""
    if not path:
        return "$"
    path = str(path).strip()
    if not path:
        return "$"
    if path.startswith("$"):
        return path
    if path.startswith("["):
        return f"${path}"
    if path.startswith("."):
        return f"${path}"
    return f"$.{path}"


def normalize_field_mapping(
    field_mapping: dict[str, Any] | None,
) -> tuple[dict[str, Any], list[str]]:
    """Normalize a field mapping payload to canonical shape.

    For new-format payloads (containing ``domain_schema``), field_bindings
    are passed through as-is since they use class/slot keys.

    For legacy payloads, ``fields`` is promoted to ``field_bindings``,
    ``concept_id`` keys are normalized to ``concept``, and field paths
    are converted to JSONPath form.

    Args:
        field_mapping: Raw field mapping dict from YAML.

    Returns:
        Tuple of (normalized dict, list of warning messages).
    """
    if not field_mapping or not isinstance(field_mapping, dict):
        return {}, []

    data = dict(field_mapping)

    # New format: domain_schema present → pass through
    if "domain_schema" in data:
        return _normalize_new_format(data)

    return _normalize_legacy_format(data)


# =====================================================================
# New format normalization
# =====================================================================


def _normalize_new_format(
    data: dict[str, Any],
) -> tuple[dict[str, Any], list[str]]:
    """Normalize new-format payload (domain_schema + class/slot bindings)."""
    warnings: list[str] = []
    raw_bindings = data.get("field_bindings", {})

    if not isinstance(raw_bindings, dict):
        return data, warnings

    # Validate each binding has class + slot
    for field_name, binding in raw_bindings.items():
        if isinstance(binding, dict):
            if "class" not in binding:
                warnings.append(f"Field '{field_name}' missing 'class' key.")
            if "slot" not in binding:
                warnings.append(f"Field '{field_name}' missing 'slot' key.")

    return data, warnings


# =====================================================================
# Legacy format normalization
# =====================================================================


def _normalize_relationship(rel: dict[str, Any]) -> dict[str, Any]:
    """Normalize a single legacy relationship dict."""
    normalized = dict(rel)
    if "target_field" not in normalized and "target" in normalized:
        normalized["target_field"] = normalized.pop("target")
    if "target_field" in normalized and isinstance(normalized["target_field"], str):
        normalized["target_field"] = to_jsonpath(normalized["target_field"])
    return normalized


def _normalize_binding(binding: dict[str, Any]) -> dict[str, Any]:
    """Normalize a single legacy concept binding dict."""
    normalized = dict(binding)
    # Standardize on "concept" (not "concept_id") for the canonical form
    if "concept" not in normalized and "concept_id" in normalized:
        normalized["concept"] = normalized.pop("concept_id")
    rels = normalized.get("relationships")
    if isinstance(rels, list):
        normalized["relationships"] = [
            _normalize_relationship(r) if isinstance(r, dict) else r for r in rels
        ]
    return normalized


def _normalize_legacy_format(
    data: dict[str, Any],
) -> tuple[dict[str, Any], list[str]]:
    """Normalize legacy concept-centric ontology format."""
    warnings: list[str] = []

    field_bindings = data.get("field_bindings")
    legacy_fields = data.get("fields")

    normalized_bindings: dict[str, list[dict[str, Any]]] = {}

    if isinstance(field_bindings, dict):
        for raw_path, raw_binding in field_bindings.items():
            path = to_jsonpath(str(raw_path))
            if path != raw_path:
                warnings.append(
                    f"Converted ontology key '{raw_path}' "
                    f"to canonical JSONPath '{path}'."
                )
            if isinstance(raw_binding, list):
                bindings = [
                    _normalize_binding(item)
                    for item in raw_binding
                    if isinstance(item, dict)
                ]
            elif isinstance(raw_binding, dict):
                bindings = [_normalize_binding(raw_binding)]
            else:
                bindings = []
            normalized_bindings[path] = bindings

    if isinstance(legacy_fields, dict):
        warnings.append(
            "Ontology legacy key 'fields' was normalized to 'field_bindings'."
        )
        for raw_path, raw_value in legacy_fields.items():
            if not isinstance(raw_value, dict):
                continue
            path = to_jsonpath(str(raw_path))
            normalized_bindings.setdefault(path, []).append(
                _normalize_binding(raw_value)
            )

    if normalized_bindings:
        data["field_bindings"] = normalized_bindings
        data.pop("fields", None)

    return data, warnings
