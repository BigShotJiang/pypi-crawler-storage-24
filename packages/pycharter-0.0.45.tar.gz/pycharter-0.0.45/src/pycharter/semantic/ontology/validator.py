"""
Field Mapping Validator — validates field mapping structure and content.

Provides validation for both raw dicts (pre-parse) and
FieldMapping instances (post-parse).
"""

from __future__ import annotations

from typing import Any

from pycharter.semantic.ontology.models import FieldMapping
from pycharter.semantic.ontology.normalizer import normalize_field_mapping
from pycharter.semantic.ontology.schema_loader import load_ontology_schema


def validate_field_mapping_payload(
    ontology_data: dict[str, Any],
) -> list[dict[str, str]]:
    """
    Validate raw field mapping data before parsing.

    Checks structural requirements:
    - Must have 'version' field
    - Must have 'field_bindings' dict
    - Each field must have 'concept'
    - Relationship types must be valid
    - No circular broader references

    Args:
        ontology_data: Raw field mapping dictionary.

    Returns:
        List of error dicts with 'path' and 'message' keys.
        Empty list means valid.
    """
    errors: list[dict[str, str]] = []

    if not isinstance(ontology_data, dict):
        errors.append({"path": "", "message": "Ontology must be a dictionary"})
        return errors

    # Check version
    if "version" not in ontology_data:
        errors.append(
            {"path": "version", "message": "Missing required field 'version'"}
        )

    normalized, normalization_warnings = normalize_field_mapping(ontology_data)
    for warning in normalization_warnings:
        errors.append({"path": "ontology", "message": warning})

    # Check field_bindings (canonical)
    fields = normalized.get("field_bindings")
    if fields is None:
        errors.append(
            {
                "path": "field_bindings",
                "message": "Missing required field 'field_bindings'",
            }
        )
        return errors

    if not isinstance(fields, dict):
        errors.append(
            {
                "path": "field_bindings",
                "message": "'field_bindings' must be a dictionary",
            }
        )
        return errors

    valid_rel_types = set(load_ontology_schema().relationship_types.keys())

    for field_name, field_bindings in fields.items():
        prefix = f"field_bindings.{field_name}"
        if not str(field_name).startswith("$"):
            errors.append(
                {
                    "path": prefix,
                    "message": "Field binding key should be a JSONPath starting with '$'",
                }
            )

        if isinstance(field_bindings, dict):
            field_bindings = [field_bindings]

        if not isinstance(field_bindings, list):
            errors.append(
                {
                    "path": prefix,
                    "message": f"Field '{field_name}' must be a list of bindings",
                }
            )
            continue

        for binding_idx, field_data in enumerate(field_bindings):
            item_prefix = f"{prefix}[{binding_idx}]"
            if not isinstance(field_data, dict):
                errors.append(
                    {
                        "path": item_prefix,
                        "message": "Binding must be a dictionary",
                    }
                )
                continue

            # concept is required (accept legacy "concept_id" as fallback)
            if not field_data.get("concept") and not field_data.get("concept_id"):
                errors.append(
                    {
                        "path": f"{item_prefix}.concept",
                        "message": "Missing required field 'concept'",
                    }
                )

            # tags must be a list
            tags = field_data.get("tags")
            if tags is not None and not isinstance(tags, list):
                errors.append(
                    {"path": f"{item_prefix}.tags", "message": "'tags' must be a list"}
                )

            # lineage must be a dict
            lineage = field_data.get("lineage")
            if lineage is not None and not isinstance(lineage, dict):
                errors.append(
                    {
                        "path": f"{item_prefix}.lineage",
                        "message": "'lineage' must be a dictionary",
                    }
                )

            # relationships must be a list of dicts with valid types
            relationships = field_data.get("relationships")
            if relationships is not None:
                if not isinstance(relationships, list):
                    errors.append(
                        {
                            "path": f"{item_prefix}.relationships",
                            "message": "'relationships' must be a list",
                        }
                    )
                else:
                    for i, rel in enumerate(relationships):
                        rel_prefix = f"{item_prefix}.relationships[{i}]"
                        if not isinstance(rel, dict):
                            errors.append(
                                {
                                    "path": rel_prefix,
                                    "message": "Relationship must be a dictionary",
                                }
                            )
                            continue
                        if (
                            not rel.get("target_field")
                            and not rel.get("target_concept_id")
                            and not rel.get("target")
                        ):
                            errors.append(
                                {
                                    "path": rel_prefix,
                                    "message": "Missing target_field, target_concept_id, or target",
                                }
                            )
                        rel_type = rel.get("type")
                        if rel_type is not None and rel_type not in valid_rel_types:
                            errors.append(
                                {
                                    "path": f"{rel_prefix}.type",
                                    "message": f"Invalid relationship type '{rel_type}'. "
                                    f"Valid: {sorted(valid_rel_types)}",
                                }
                            )

    # Check for circular broader references
    if isinstance(fields, dict):
        errors.extend(_check_circular_broader(fields))

    return errors


def _check_circular_broader(fields: dict[str, Any]) -> list[dict[str, str]]:
    """Check for circular references in broader hierarchy."""
    errors: list[dict[str, str]] = []

    # Build concept -> broader mapping
    concept_to_broader: dict[str, str | None] = {}
    for _field_name, field_bindings in fields.items():
        if isinstance(field_bindings, dict):
            field_bindings = [field_bindings]
        if not isinstance(field_bindings, list):
            continue
        for field_data in field_bindings:
            if not isinstance(field_data, dict):
                continue
            concept = field_data.get("concept") or field_data.get("concept_id")
            broader = field_data.get("broader")
            if concept and broader:
                concept_to_broader[concept] = broader

    # Detect cycles
    for start_concept in concept_to_broader:
        visited: set[str] = set()
        current = start_concept
        while current in concept_to_broader:
            if current in visited:
                errors.append(
                    {
                        "path": "broader",
                        "message": f"Circular broader reference detected involving '{start_concept}'",
                    }
                )
                break
            visited.add(current)
            current = concept_to_broader[current]

    return errors


def validate_field_mapping(artifact: FieldMapping) -> list[dict[str, str]]:
    """Validate a FieldMapping instance.

    Performs the same checks as validate_field_mapping_payload but on a
    parsed artifact.

    Args:
        artifact: Parsed FieldMapping.

    Returns:
        List of error dicts with 'path' and 'message' keys.
        Empty list means valid.
    """
    return validate_field_mapping_payload(artifact.to_dict())
