"""
Ontology schema loader.

Loads and validates the ontology_schema.yaml meta-schema that defines
valid relationship types, concept types, and governance tiers for the
knowledge graph.  The YAML file seeds the initial data; DB tables become
the runtime source of truth when available.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from functools import lru_cache
from pathlib import Path
from typing import Any

import yaml

logger = logging.getLogger(__name__)

_SCHEMA_PATH = (
    Path(__file__).resolve().parents[2] / "data" / "seed" / "ontology_schema.yaml"
)


# ── Data classes ─────────────────────────────────────────────────────────────


@dataclass(frozen=True, slots=True)
class RelationshipTypeInfo:
    """Metadata for a single relationship type."""

    name: str
    meaning: str
    graph_shape: str
    inverse: str
    symmetric: bool = False
    predicate: str = ""
    domain_types: tuple[str, ...] = ()
    range_types: tuple[str, ...] = ()
    is_builtin: bool = True


@dataclass(frozen=True, slots=True)
class CardinalityRule:
    """A soft cardinality constraint on a relationship type for a concept type."""

    concept_type: str
    relationship_type: str
    direction: str
    min: int = 0
    message: str = ""


@dataclass(frozen=True, slots=True)
class OntologySchema:
    """Validated ontology meta-schema."""

    version: int
    relationship_types: dict[str, RelationshipTypeInfo] = field(default_factory=dict)
    concept_types: dict[str, str] = field(default_factory=dict)
    tiers: dict[str, str] = field(default_factory=dict)
    cardinality_rules: list[CardinalityRule] = field(default_factory=list)


# ── Parsing ──────────────────────────────────────────────────────────────────


def _parse_schema(raw: dict[str, Any]) -> OntologySchema:
    """Parse raw YAML dict into an OntologySchema."""
    version = raw.get("version", 1)

    rel_types: dict[str, RelationshipTypeInfo] = {}
    for name, info in raw.get("relationship_types", {}).items():
        rel_types[name] = RelationshipTypeInfo(
            name=name,
            meaning=info.get("meaning", ""),
            graph_shape=info.get("graph_shape", "generic"),
            inverse=info.get("inverse", name),
            symmetric=info.get("symmetric", False),
            predicate=info.get("predicate", ""),
            domain_types=tuple(info.get("domain_types", [])),
            range_types=tuple(info.get("range_types", [])),
        )

    concept_types: dict[str, str] = raw.get("concept_types", {})
    tiers: dict[str, str] = raw.get("tiers", {})

    cardinality_rules: list[CardinalityRule] = []
    for concept_type, rules in raw.get("cardinality_rules", {}).items():
        for rule in rules:
            cardinality_rules.append(
                CardinalityRule(
                    concept_type=concept_type,
                    relationship_type=rule["relationship_type"],
                    direction=rule.get("direction", "outgoing"),
                    min=rule.get("min", 0),
                    message=rule.get("message", ""),
                )
            )

    return OntologySchema(
        version=version,
        relationship_types=rel_types,
        concept_types=concept_types,
        tiers=tiers,
        cardinality_rules=cardinality_rules,
    )


# ── Registry ─────────────────────────────────────────────────────────────────


class OntologySchemaRegistry:
    """Merges YAML seed data with DB overrides for runtime schema.

    The registry lazily loads from YAML on first access and can optionally
    overlay DB-stored types on top.  CRUD operations invalidate the cache.
    """

    def __init__(self) -> None:
        self._schema: OntologySchema | None = None
        self._yaml_path: Path = _SCHEMA_PATH

    def invalidate(self) -> None:
        """Clear cached schema so the next access reloads."""
        self._schema = None
        load_ontology_schema.cache_clear()

    def get_schema(self, *, session: Any | None = None) -> OntologySchema:
        """Return the merged schema (YAML + optional DB overlay).

        Args:
            session: Optional SQLAlchemy session.  When provided, DB-stored
                types are merged over the YAML defaults.
        """
        if self._schema is not None and session is None:
            return self._schema

        base = load_ontology_schema()

        if session is None:
            self._schema = base
            return base

        merged = self._merge_with_db(base, session)
        self._schema = merged
        return merged

    def _merge_with_db(self, base: OntologySchema, session: Any) -> OntologySchema:
        """Overlay DB-stored schema elements on top of YAML defaults."""
        from pycharter.db.models.semantic.ontology_schema import (
            ConceptTypeModel,
            RelationshipTypeModel,
            TierModel,
        )

        # Relationship types: DB overrides YAML
        rel_types = dict(base.relationship_types)
        try:
            for row in session.query(RelationshipTypeModel).all():
                rel_types[row.name] = RelationshipTypeInfo(
                    name=row.name,
                    meaning=row.meaning or "",
                    graph_shape=row.graph_shape or "generic",
                    inverse=row.inverse or row.name,
                    symmetric=row.symmetric,
                    predicate=row.predicate or "",
                    domain_types=tuple(row.domain_types or []),
                    range_types=tuple(row.range_types or []),
                    is_builtin=row.is_builtin,
                )
        except Exception:
            logger.debug("relationship_types table not available, using YAML only")

        # Concept types: DB overrides YAML
        concept_types = dict(base.concept_types)
        try:
            for row in session.query(ConceptTypeModel).all():
                concept_types[row.name] = row.description or ""
        except Exception:
            logger.debug("concept_types table not available, using YAML only")

        # Tiers: DB overrides YAML
        tiers = dict(base.tiers)
        try:
            for row in session.query(TierModel).all():
                tiers[row.name] = row.description or ""
        except Exception:
            logger.debug("tiers table not available, using YAML only")

        return OntologySchema(
            version=base.version,
            relationship_types=rel_types,
            concept_types=concept_types,
            tiers=tiers,
            cardinality_rules=base.cardinality_rules,
        )


# ── Public API ───────────────────────────────────────────────────────────────


@lru_cache(maxsize=1)
def load_ontology_schema(path: str | None = None) -> OntologySchema:
    """Load ontology_schema.yaml and return a validated schema object.

    Args:
        path: Override path to the YAML file.  Defaults to the bundled
              ``data/seed/ontology_schema.yaml``.

    Returns:
        Parsed and validated OntologySchema.

    Raises:
        FileNotFoundError: If the schema file does not exist.
        ValueError: If the YAML is malformed.
    """
    schema_path = Path(path) if path else _SCHEMA_PATH
    if not schema_path.exists():
        msg = f"Ontology schema not found: {schema_path}"
        raise FileNotFoundError(msg)

    with schema_path.open() as fh:
        raw = yaml.safe_load(fh)

    if not isinstance(raw, dict):
        msg = f"Expected a YAML mapping, got {type(raw).__name__}"
        raise ValueError(msg)

    schema = _parse_schema(raw)
    logger.info(
        "loaded ontology schema v%d: %d relationship types, %d concept types, %d tiers",
        schema.version,
        len(schema.relationship_types),
        len(schema.concept_types),
        len(schema.tiers),
    )
    return schema


@lru_cache(maxsize=1)
def get_registry() -> OntologySchemaRegistry:
    """Return the schema registry singleton (lazily created and cached)."""
    return OntologySchemaRegistry()


def get_relationship_types() -> dict[str, RelationshipTypeInfo]:
    """Return all defined relationship types with metadata."""
    return load_ontology_schema().relationship_types


def get_concept_types() -> dict[str, str]:
    """Return all defined concept types with descriptions."""
    return load_ontology_schema().concept_types


def get_tiers() -> dict[str, str]:
    """Return all defined governance tiers with descriptions."""
    return load_ontology_schema().tiers


def get_cardinality_rules() -> list[CardinalityRule]:
    """Return all cardinality rules from the schema."""
    return load_ontology_schema().cardinality_rules


def validate_relationship_type(rel_type: str) -> bool:
    """Check if a relationship type is valid."""
    return rel_type in load_ontology_schema().relationship_types


def validate_concept_type(kind: str) -> bool:
    """Check if a concept type is valid."""
    return kind in load_ontology_schema().concept_types


def validate_tier(tier: str) -> bool:
    """Check if a governance tier is valid."""
    return tier in load_ontology_schema().tiers


def get_inverse_map() -> dict[str, str]:
    """Build inverse mapping from the schema.

    Returns a dict mapping each relationship type name to its inverse name,
    derived from the ``inverse`` field of each ``RelationshipTypeInfo``.
    """
    schema = load_ontology_schema()
    return {name: info.inverse for name, info in schema.relationship_types.items()}


def get_predicate_map() -> dict[str, str]:
    """Build relationship-type-to-predicate mapping from the schema.

    Returns a dict mapping each relationship type name to its JSON-LD
    predicate name, derived from the ``predicate`` field of each
    ``RelationshipTypeInfo``.
    """
    schema = load_ontology_schema()
    return {
        name: info.predicate
        for name, info in schema.relationship_types.items()
        if info.predicate
    }


def get_inverse(rel_type: str) -> str:
    """Return the inverse of a relationship type.

    Uses the schema YAML as the source of truth.
    """
    schema = load_ontology_schema()
    info = schema.relationship_types.get(rel_type)
    if info:
        return info.inverse
    return rel_type
