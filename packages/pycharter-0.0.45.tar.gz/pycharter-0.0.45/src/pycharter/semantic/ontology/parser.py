"""
Field Mapping Parser — Parses field mapping YAML/dict into FieldMapping.

Supports two formats:
- **New format**: ``domain_schema`` + ``field_bindings`` with class/slot
- **Legacy format**: ``fields`` with concept-centric bindings

Auto-detects format based on the presence of ``domain_schema``.
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any

import yaml  # type: ignore[import-untyped]

from pycharter.semantic.ontology.models import (
    FieldBinding,
    FieldConceptBinding,
    FieldMapping,
    Lineage,
    Relationship,
)
from pycharter.semantic.ontology.normalizer import normalize_field_mapping
from pycharter.semantic.ontology.schema_loader import validate_relationship_type
from pycharter.semantic.shared.errors import OntologyError

logger = logging.getLogger(__name__)


# =====================================================================
# Public API
# =====================================================================


def parse_field_mapping(ontology_data: dict[str, Any]) -> FieldMapping:
    """Parse a field mapping dictionary into a FieldMapping.

    Auto-detects whether the payload uses the new LinkML-backed format
    (``domain_schema`` + class/slot bindings) or the legacy concept-centric
    format (``fields`` + concept bindings).

    Args:
        ontology_data: Field mapping data as dictionary.

    Returns:
        FieldMapping with parsed bindings.

    Raises:
        OntologyError: If the data is invalid.
    """
    if not isinstance(ontology_data, dict):
        raise OntologyError(
            f"Field mapping data must be a dictionary, got {type(ontology_data).__name__}"
        )

    if "domain_schema" in ontology_data:
        return _parse_new_format(ontology_data)
    return _parse_legacy_format(ontology_data)


def parse_field_mapping_file(file_path: str) -> FieldMapping:
    """Load and parse a field mapping file (YAML or JSON).

    Args:
        file_path: Path to field mapping file.

    Returns:
        FieldMapping with parsed bindings.

    Raises:
        OntologyError: If the file cannot be read or parsed.
    """
    path = Path(file_path)

    if not path.exists():
        raise OntologyError(f"Ontology file not found: {file_path}", path=file_path)

    suffix = path.suffix.lower()

    if suffix in (".jsonld", ".json"):
        return _parse_jsonld_file(path, file_path)

    if suffix not in (".yaml", ".yml"):
        raise OntologyError(
            f"Unsupported file format: {suffix}. "
            "Supported: .yaml, .yml, .jsonld, .json",
            path=file_path,
        )

    try:
        with open(path, encoding="utf-8") as fh:
            data = yaml.safe_load(fh)
    except yaml.YAMLError as exc:
        raise OntologyError(f"Invalid YAML: {exc}", path=file_path) from exc

    if not isinstance(data, dict):
        raise OntologyError(
            f"Ontology file must contain a dictionary, got {type(data).__name__}",
            path=file_path,
        )

    return parse_field_mapping(data)


# =====================================================================
# New format: domain_schema + field_bindings (class/slot)
# =====================================================================


def _parse_new_format(data: dict[str, Any]) -> FieldMapping:
    """Parse new domain_schema + field_bindings format."""
    version = data.get("version", "0.0.0")
    domain_schema = data.get("domain_schema", "")
    raw_bindings = data.get("field_bindings", {})

    if not isinstance(raw_bindings, dict):
        raise OntologyError(
            f"'field_bindings' must be a mapping, got {type(raw_bindings).__name__}"
        )

    bindings: dict[str, FieldBinding | FieldConceptBinding] = {}
    for field_name, field_data in raw_bindings.items():
        if not isinstance(field_data, dict):
            raise OntologyError(
                f"Field '{field_name}' binding must be a mapping, "
                f"got {type(field_data).__name__}"
            )
        bindings[field_name] = _parse_field_binding(field_data)

    return FieldMapping(
        version=version,
        domain_schema=domain_schema,
        field_bindings=bindings,
    )


def _parse_field_binding(data: dict[str, Any]) -> FieldBinding:
    """Parse a single class/slot field binding."""
    class_name = data.get("class", "")
    slot_name = data.get("slot", "")

    if not class_name:
        raise OntologyError("Field binding missing required 'class' key")
    if not slot_name:
        raise OntologyError("Field binding missing required 'slot' key")

    tags = data.get("tags", [])
    return FieldBinding(
        class_name=class_name,
        slot_name=slot_name,
        tags=tuple(tags) if isinstance(tags, list) else (),
        owner=data.get("owner"),
        lineage=_parse_lineage(data.get("lineage")),
    )


# =====================================================================
# Legacy format: fields/field_bindings with concept-centric bindings
# =====================================================================


def _parse_legacy_format(data: dict[str, Any]) -> FieldMapping:
    """Parse legacy concept-centric ontology format."""
    normalized, _ = normalize_field_mapping(data)
    version = normalized.get("version", "0.0.0")
    raw_bindings = normalized.get("field_bindings", {})

    if not isinstance(raw_bindings, dict):
        raise OntologyError(
            f"'field_bindings' must be a mapping, got {type(raw_bindings).__name__}"
        )

    fields: dict[str, FieldBinding | FieldConceptBinding] = {}
    for field_name, field_items in raw_bindings.items():
        if isinstance(field_items, dict):
            field_items = [field_items]
        if not isinstance(field_items, list):
            raise OntologyError(
                f"Field '{field_name}' must be a list of mappings, "
                f"got {type(field_items).__name__}"
            )
        if not field_items:
            continue
        field_data = field_items[0]
        if not isinstance(field_data, dict):
            raise OntologyError(
                f"Field '{field_name}' mapping must be a dictionary, "
                f"got {type(field_data).__name__}"
            )
        fields[field_name] = _parse_field_concept_binding(field_data)

    return FieldMapping(version=version, field_bindings=fields)


# =====================================================================
# Shared helpers
# =====================================================================


def _parse_lineage(data: dict[str, Any] | None) -> Lineage | None:
    """Parse lineage from raw dict."""
    if data is None:
        return None
    return Lineage(
        derived_from=data.get("derived_from"),
        source_system=data.get("source_system"),
    )


def _parse_relationships(
    data: list[dict[str, Any]],
) -> list[Relationship]:
    """Parse relationships from raw list of dicts."""
    if not data:
        return []
    relationships = []
    for item in data:
        target = item.get("target_field") or item.get("target", "")
        rel_type_str = item.get("type", "related_to")
        if not validate_relationship_type(rel_type_str):
            logger.warning(
                "unknown relationship type %r, keeping as-is",
                rel_type_str,
            )
        relationships.append(Relationship(target=target, type=rel_type_str))
    return relationships


def _parse_field_concept_binding(
    data: dict[str, Any],
) -> FieldConceptBinding:
    """Parse a single legacy field concept binding from raw dict."""
    raw_tags = data.get("tags", [])
    return FieldConceptBinding(
        concept=data.get("concept") or data.get("concept_id", ""),
        broader=data.get("broader"),
        definition=data.get("definition"),
        tags=tuple(raw_tags) if isinstance(raw_tags, list) else (),
        owner=data.get("owner"),
        description=data.get("description"),
        deprecated=bool(data.get("deprecated", False)),
        lineage=_parse_lineage(data.get("lineage")),
        relationships=tuple(_parse_relationships(data.get("relationships"))),
    )


def _parse_jsonld_file(path: Path, file_path: str) -> FieldMapping:
    """Parse a JSON-LD ontology file."""
    try:
        from pycharter.semantic.rdf.jsonld_parser import (
            parse_field_mapping_jsonld,
        )
    except ImportError as exc:
        raise OntologyError(
            "JSON-LD support requires the 'ontology' extra: "
            "pip install pycharter[ontology]",
            path=file_path,
        ) from exc
    import json as _json

    try:
        with open(path, encoding="utf-8") as fh:
            data = _json.load(fh)
    except _json.JSONDecodeError as exc:
        raise OntologyError(f"Invalid JSON: {exc}", path=file_path) from exc
    return parse_field_mapping_jsonld(data)
