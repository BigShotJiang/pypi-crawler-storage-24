"""Semantic health scoring for contract ontology bindings."""

from __future__ import annotations

from typing import Any

from pycharter.semantic.ontology.normalizer import (
    normalize_field_mapping,
    to_jsonpath,
)
from pycharter.semantic.ontology.schema_loader import validate_relationship_type


def _schema_jsonpaths(schema: dict[str, Any]) -> set[str]:
    """Extract leaf JSONPath field paths from a JSON Schema object."""
    paths: set[str] = set()

    def walk(node: dict[str, Any], path: str) -> None:
        if not isinstance(node, dict):
            return
        node_type = node.get("type")
        properties = node.get("properties")

        if isinstance(properties, dict):
            for name, child in properties.items():
                child_path = f"{path}.{name}" if path else f"$.{name}"
                if isinstance(child, dict):
                    child_properties = child.get("properties")
                    child_items = child.get("items")
                    if isinstance(child_properties, dict):
                        walk(child, child_path)
                    elif child.get("type") == "array" and isinstance(child_items, dict):
                        walk(child, child_path)
                    else:
                        paths.add(child_path)
                else:
                    paths.add(child_path)

        items = node.get("items")
        if node_type == "array" and isinstance(items, dict):
            array_path = f"{path}[*]" if path else "$[*]"
            item_props = items.get("properties")
            if isinstance(item_props, dict):
                walk(items, array_path)
            else:
                paths.add(array_path)

    walk(schema, "")
    return paths


def calculate_semantic_health(
    schema: dict[str, Any],
    field_mapping: dict[str, Any] | None,
    known_concepts: set[str] | None = None,
    deprecated_concepts: set[str] | None = None,
) -> dict[str, Any]:
    """Compute semantic coverage and integrity signals for one contract."""
    known_concepts = known_concepts or set()
    deprecated_concepts = deprecated_concepts or set()

    normalized, normalization_warnings = normalize_field_mapping(field_mapping)
    field_bindings = normalized.get("field_bindings", {}) if normalized else {}
    if not isinstance(field_bindings, dict):
        field_bindings = {}

    schema_paths = _schema_jsonpaths(schema)
    mapped_paths: set[str] = {to_jsonpath(str(path)) for path in field_bindings.keys()}
    mapped_schema_paths = mapped_paths.intersection(schema_paths)
    unmapped_schema_paths = sorted(schema_paths - mapped_schema_paths)
    unknown_mapping_paths = sorted(mapped_paths - schema_paths)

    total_fields = len(schema_paths)
    mapped_fields = len(mapped_schema_paths)
    coverage_pct = (
        round((mapped_fields / total_fields) * 100, 2) if total_fields else 0.0
    )

    invalid_relationships: list[dict[str, str]] = []
    invalid_concepts: list[str] = []
    deprecated_usage: list[str] = []
    total_bindings = 0

    for field_path, bindings in field_bindings.items():
        if isinstance(bindings, dict):
            bindings = [bindings]
        if not isinstance(bindings, list):
            continue

        for idx, binding in enumerate(bindings):
            if not isinstance(binding, dict):
                continue
            total_bindings += 1
            concept_id = str(
                binding.get("concept") or binding.get("concept_id", "")
            ).strip()
            if concept_id:
                if known_concepts and concept_id not in known_concepts:
                    invalid_concepts.append(concept_id)
                if concept_id in deprecated_concepts:
                    deprecated_usage.append(concept_id)
            else:
                invalid_concepts.append(f"(missing concept at {field_path}[{idx}])")

            relationships = binding.get("relationships", [])
            if isinstance(relationships, list):
                for rel_idx, rel in enumerate(relationships):
                    if not isinstance(rel, dict):
                        continue
                    rel_type = str(rel.get("type", "")).strip()
                    if rel_type and not validate_relationship_type(rel_type):
                        invalid_relationships.append(
                            {
                                "path": f"{field_path}[{idx}].relationships[{rel_idx}].type",
                                "type": rel_type,
                            }
                        )

    warnings: list[str] = []
    warnings.extend(normalization_warnings)
    if coverage_pct < 100:
        warnings.append(
            f"Semantic coverage is {coverage_pct}% ({mapped_fields}/{total_fields} schema fields mapped)."
        )

    return {
        "total_schema_fields": total_fields,
        "mapped_schema_fields": mapped_fields,
        "coverage_pct": coverage_pct,
        "total_bindings": total_bindings,
        "unmapped_schema_fields": unmapped_schema_paths,
        "unknown_mapping_paths": unknown_mapping_paths,
        "invalid_concepts": sorted(set(invalid_concepts)),
        "deprecated_concepts_in_use": sorted(set(deprecated_usage)),
        "invalid_relationships": invalid_relationships,
        "warnings": warnings,
    }
