"""
PyCharter Semantic Layer — Ontology, knowledge graph, and governance for data contracts.

Provides semantic annotations, concept taxonomy, field relationships,
version-controlled definitions, and collaborative governance workflows.
"""

from __future__ import annotations

from pycharter.semantic.ontology.models import (
    ConceptTier,
    FieldConceptBinding,
    FieldMapping,
    Lineage,
    Relationship,
    RelationshipType,
)
from pycharter.semantic.ontology.parser import (
    parse_field_mapping,
    parse_field_mapping_file,
)
from pycharter.semantic.ontology.validator import (
    validate_field_mapping,
    validate_field_mapping_payload,
)
from pycharter.semantic.shared.errors import PyCharterSemanticError

__all__ = [
    # Core types
    "FieldMapping",
    "FieldConceptBinding",
    "Lineage",
    "Relationship",
    "ConceptTier",
    "RelationshipType",
    # Parsing
    "parse_field_mapping",
    "parse_field_mapping_file",
    # Validation
    "validate_field_mapping_payload",
    "validate_field_mapping",
    # Errors
    "PyCharterSemanticError",
]
