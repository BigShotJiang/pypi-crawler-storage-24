"""Proposal governance policy evaluation."""

from __future__ import annotations

from typing import Any


def evaluate_proposal_policy(
    *,
    proposal_type: str | None,
    affected_tiers: list[str] | None,
) -> dict[str, Any]:
    """Evaluate approval + gate enforcement policy for a proposal."""
    tiers = [t.lower() for t in (affected_tiers or [])]
    has_core = "core" in tiers

    # Current v1 policy:
    # - any authenticated user can approve
    # - one approval required
    # - gate blocking only for core-impacting proposals
    required_approvals = 1
    enforce_gates = has_core

    return {
        "proposal_type": proposal_type or "mapping_change",
        "affected_tiers": tiers,
        "required_approvals": required_approvals,
        "enforce_gates": enforce_gates,
    }
