"""
Collaboration module for pycharter semantic layer.

Provides proposal/review workflows and tiered governance:
- ProposalManager: CRUD for proposals (change requests)
- ReviewWorkflow: Submit reviews and check approval status
- PermissionChecker: Tiered governance enforcement
"""

from __future__ import annotations

from pycharter.semantic.collaboration.conflicts import (
    detect_proposal_conflicts,
    suggest_resolution,
)
from pycharter.semantic.collaboration.permissions import PermissionChecker
from pycharter.semantic.collaboration.proposals import ProposalManager
from pycharter.semantic.collaboration.review import ReviewWorkflow

__all__ = [
    "ProposalManager",
    "ReviewWorkflow",
    "PermissionChecker",
    "detect_proposal_conflicts",
    "suggest_resolution",
]
