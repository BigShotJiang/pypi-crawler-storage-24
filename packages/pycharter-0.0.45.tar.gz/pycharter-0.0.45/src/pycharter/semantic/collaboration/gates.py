"""Proposal validation gates for ontology governance."""

from __future__ import annotations

from datetime import UTC, datetime
from typing import Any

from pycharter.semantic.knowledge.semantic_health import calculate_semantic_health
from pycharter.semantic.ontology.normalizer import normalize_field_mapping
from pycharter.semantic.ontology.schema_loader import validate_relationship_type


def _iter_bindings(ontology: dict[str, Any]) -> list[tuple[str, dict[str, Any]]]:
    bindings: list[tuple[str, dict[str, Any]]] = []
    field_bindings = ontology.get("field_bindings", {})
    if not isinstance(field_bindings, dict):
        return bindings
    for field_path, items in field_bindings.items():
        if isinstance(items, dict):
            items = [items]
        if not isinstance(items, list):
            continue
        for item in items:
            if isinstance(item, dict):
                bindings.append((str(field_path), item))
    return bindings


def run_proposal_gates(
    *,
    schema: dict[str, Any],
    baseline_field_mapping: dict[str, Any] | None,
    proposed_field_mapping: dict[str, Any] | None,
    known_concepts: set[str],
    deprecated_concepts: set[str],
    enforce_gates: bool,
) -> dict[str, Any]:
    """Run validation gates and return persisted gate status payload."""
    baseline_norm, baseline_warnings = normalize_field_mapping(baseline_field_mapping)
    proposed_norm, proposed_warnings = normalize_field_mapping(proposed_field_mapping)

    baseline_health = calculate_semantic_health(
        schema=schema,
        field_mapping=baseline_norm,
        known_concepts=known_concepts,
        deprecated_concepts=deprecated_concepts,
    )
    proposed_health = calculate_semantic_health(
        schema=schema,
        field_mapping=proposed_norm,
        known_concepts=known_concepts,
        deprecated_concepts=deprecated_concepts,
    )

    concept_errors: list[str] = []
    invalid_relationships: list[dict[str, str]] = []

    for field_path, binding in _iter_bindings(proposed_norm):
        concept_id = str(
            binding.get("concept") or binding.get("concept_id", "")
        ).strip()
        if concept_id and concept_id not in known_concepts:
            concept_errors.append(f"{field_path}: unknown concept '{concept_id}'")
        relationships = binding.get("relationships", [])
        if isinstance(relationships, list):
            for idx, rel in enumerate(relationships):
                if not isinstance(rel, dict):
                    continue
                rel_type = str(rel.get("type", "")).strip()
                if rel_type and not validate_relationship_type(rel_type):
                    invalid_relationships.append(
                        {
                            "path": f"{field_path}.relationships[{idx}].type",
                            "type": rel_type,
                        }
                    )

    coverage_delta = round(
        proposed_health["coverage_pct"] - baseline_health["coverage_pct"], 2
    )

    gates: list[dict[str, Any]] = []
    gates.append(
        {
            "name": "concept_existence",
            "status": "pass" if not concept_errors else "fail",
            "errors": concept_errors,
            "warnings": [],
            "metrics": {"unknown_count": len(concept_errors)},
        }
    )
    rel_errors = [
        f"{item['path']}: invalid relationship type '{item['type']}'"
        for item in invalid_relationships
    ]
    gates.append(
        {
            "name": "relationship_type_validity",
            "status": "pass" if not rel_errors else "fail",
            "errors": rel_errors,
            "warnings": [],
            "metrics": {"invalid_count": len(rel_errors)},
        }
    )
    gates.append(
        {
            "name": "semantic_coverage_delta",
            "status": "pass" if coverage_delta >= 0 else "warn",
            "errors": [],
            "warnings": (
                [f"Coverage dropped by {abs(coverage_delta)} points."]
                if coverage_delta < 0
                else []
            ),
            "metrics": {
                "baseline_coverage_pct": baseline_health["coverage_pct"],
                "proposed_coverage_pct": proposed_health["coverage_pct"],
                "coverage_delta_pct": coverage_delta,
            },
        }
    )

    has_fail = any(g["status"] == "fail" for g in gates)
    has_warn = any(g["status"] == "warn" for g in gates)
    if enforce_gates:
        overall = "fail" if has_fail else ("warn" if has_warn else "pass")
    else:
        overall = "warn" if (has_fail or has_warn) else "pass"

    warnings = (
        baseline_warnings + proposed_warnings + proposed_health.get("warnings", [])
    )

    return {
        "validated_at": datetime.now(UTC).isoformat(),
        "overall": overall,
        "enforce_gates": enforce_gates,
        "gates": gates,
        "coverage": {
            "baseline": baseline_health["coverage_pct"],
            "proposed": proposed_health["coverage_pct"],
            "delta": coverage_delta,
        },
        "warnings": warnings,
    }
