"""Argparse subparser registration for the ``db`` command group.

Separated from ``_cli_parsers`` to keep each module under 400 lines.
"""

from __future__ import annotations

import argparse


def register_db(
    subparsers: argparse._SubParsersAction,
) -> tuple[argparse.ArgumentParser, argparse._SubParsersAction]:
    """Register the ``db`` subcommand and its nested commands.

    Returns:
        A tuple of (db_parser, db_subparsers) for downstream help display.
    """
    db_parser = subparsers.add_parser("db", help="Database management commands")
    db_sub = db_parser.add_subparsers(dest="db_command", help="Database command")

    # init
    init_p = db_sub.add_parser(
        "init",
        help=(
            "Initialize database schema from scratch "
            "(auto-detects database type from connection string)"
        ),
    )
    init_p.add_argument(
        "database_url",
        nargs="?",
        help="Database connection string (optional if configured)",
    )
    init_p.add_argument(
        "--db",
        "--database-type",
        dest="db_type",
        choices=["postgresql", "postgres", "mongodb", "sqlite"],
        default=None,
        help="Database type (auto-detected from connection string if not provided)",
    )
    init_p.add_argument(
        "--force",
        action="store_true",
        help="Proceed even if database appears initialized",
    )

    # upgrade
    upgrade_p = db_sub.add_parser("upgrade", help="Upgrade database to latest revision")
    upgrade_p.add_argument(
        "database_url",
        nargs="?",
        help="PostgreSQL connection string (optional if PYCHARTER_DATABASE_URL is set)",
    )
    upgrade_p.add_argument(
        "--revision", default="head", help="Target revision (default: head)"
    )

    # downgrade
    downgrade_p = db_sub.add_parser(
        "downgrade", help="Downgrade database to a previous revision"
    )
    downgrade_p.add_argument(
        "database_url",
        nargs="?",
        help="PostgreSQL connection string (optional if PYCHARTER_DATABASE_URL is set)",
    )
    downgrade_p.add_argument(
        "--revision", default="-1", help="Target revision (default: -1)"
    )

    # current
    current_p = db_sub.add_parser("current", help="Show current database revision")
    current_p.add_argument(
        "database_url",
        nargs="?",
        help="PostgreSQL connection string (optional if PYCHARTER_DATABASE_URL is set)",
    )

    # history
    history_p = db_sub.add_parser("history", help="Show migration history")
    history_p.add_argument(
        "database_url",
        nargs="?",
        help="PostgreSQL connection string (optional if PYCHARTER_DATABASE_URL is set)",
    )

    # stamp
    stamp_p = db_sub.add_parser(
        "stamp",
        help="Stamp database with a specific revision (without running migrations)",
    )
    stamp_p.add_argument(
        "revision",
        nargs="?",
        default="head",
        help="Revision to stamp (default: head)",
    )
    stamp_p.add_argument(
        "database_url",
        nargs="?",
        help="PostgreSQL connection string (optional if PYCHARTER_DATABASE_URL is set)",
    )

    # seed
    seed_p = db_sub.add_parser(
        "seed", help="Seed database with initial data from YAML files"
    )
    seed_p.add_argument(
        "seed_dir",
        nargs="?",
        help="Directory containing seed YAML files (default: package data/seed)",
    )
    seed_p.add_argument(
        "database_url",
        nargs="?",
        help="PostgreSQL connection string (optional if PYCHARTER_DATABASE_URL is set)",
    )

    # truncate
    truncate_p = db_sub.add_parser(
        "truncate",
        help="Truncate all PyCharter database tables (clear all data)",
    )
    truncate_p.add_argument(
        "database_url",
        nargs="?",
        help="PostgreSQL connection string (optional if PYCHARTER_DATABASE_URL is set)",
    )
    truncate_p.add_argument(
        "--force",
        action="store_true",
        help="Skip confirmation prompt (use with caution)",
    )

    return db_parser, db_sub
