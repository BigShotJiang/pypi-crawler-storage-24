"""In-memory pipeline store implementation.

Steps-native store keyed by (pipeline_name, pipeline_version).
Useful for testing and development.
"""

from __future__ import annotations

import copy
import uuid
from datetime import UTC, datetime
from typing import Any

from pycharter.pipeline_store.client import PipelineStoreClient


class InMemoryPipelineStore(PipelineStoreClient):
    """In-memory pipeline config store.  All data is lost when the instance is destroyed."""

    def __init__(self) -> None:
        super().__init__()
        self._configs: dict[tuple[str, str], dict[str, Any]] = {}

    def connect(self) -> None:
        self._connection = "connected"

    def disconnect(self) -> None:
        self._connection = None

    # -----------------------------------------------------------------------
    # CRUD
    # -----------------------------------------------------------------------

    def store_config(
        self,
        pipeline_name: str,
        pipeline_version: str,
        steps: list[dict[str, Any]],
        *,
        settings: dict[str, Any] | None = None,
        variables: dict[str, Any] | None = None,
        description: str | None = None,
        contract_name: str | None = None,
        contract_version: str | None = None,
        created_by: str | None = None,
    ) -> str:
        self._require_connection()
        key = (pipeline_name, pipeline_version)
        if key in self._configs:
            raise ValueError(
                f"ETL config already exists: {pipeline_name!r} @ {pipeline_version!r}"
            )

        config_id = str(uuid.uuid4())
        now = datetime.now(tz=UTC).isoformat()

        self._configs[key] = {
            "id": config_id,
            "pipeline_name": pipeline_name,
            "pipeline_version": pipeline_version,
            "steps": copy.deepcopy(steps),
            "settings": copy.deepcopy(settings) if settings else None,
            "variables": copy.deepcopy(variables) if variables else None,
            "description": description,
            "status": "active",
            "contract_name": contract_name,
            "contract_version": contract_version,
            "created_at": now,
            "updated_at": now,
            "created_by": created_by,
            "updated_by": None,
        }
        return config_id

    def get_config(
        self,
        pipeline_name: str,
        pipeline_version: str,
    ) -> dict[str, Any] | None:
        self._require_connection()
        entry = self._configs.get((pipeline_name, pipeline_version))
        if entry is None:
            return None
        return copy.deepcopy(entry)

    def list_configs(
        self,
        pipeline_name: str | None = None,
    ) -> list[dict[str, Any]]:
        self._require_connection()
        results: list[dict[str, Any]] = []
        for (_name, _version), entry in self._configs.items():
            if pipeline_name is not None and _name != pipeline_name:
                continue
            results.append(
                {
                    "pipeline_name": entry["pipeline_name"],
                    "pipeline_version": entry["pipeline_version"],
                    "status": entry["status"],
                    "description": entry.get("description"),
                    "contract_name": entry.get("contract_name"),
                    "contract_version": entry.get("contract_version"),
                    "created_at": entry.get("created_at"),
                }
            )
        return results

    def list_versions(self, pipeline_name: str) -> list[str]:
        self._require_connection()
        versions = [v for (n, v) in self._configs if n == pipeline_name]
        return sorted(versions)

    def update_status(
        self,
        pipeline_name: str,
        pipeline_version: str,
        status: str,
        *,
        updated_by: str | None = None,
    ) -> None:
        self._require_connection()
        key = (pipeline_name, pipeline_version)
        entry = self._configs.get(key)
        if entry is None:
            raise ValueError(
                f"ETL config not found: {pipeline_name!r} @ {pipeline_version!r}"
            )
        entry["status"] = status
        entry["updated_at"] = datetime.now(tz=UTC).isoformat()
        if updated_by:
            entry["updated_by"] = updated_by

    def update_config(
        self,
        pipeline_name: str,
        pipeline_version: str,
        *,
        steps: list[dict[str, Any]] | None = None,
        settings: dict[str, Any] | None = None,
        variables: dict[str, Any] | None = None,
        description: str | None = None,
        updated_by: str | None = None,
    ) -> None:
        self._require_connection()
        key = (pipeline_name, pipeline_version)
        entry = self._configs.get(key)
        if entry is None:
            raise ValueError(
                f"ETL config not found: {pipeline_name!r} @ {pipeline_version!r}"
            )
        if steps is not None:
            entry["steps"] = copy.deepcopy(steps)
        if settings is not None:
            entry["settings"] = copy.deepcopy(settings)
        if variables is not None:
            entry["variables"] = copy.deepcopy(variables)
        if description is not None:
            entry["description"] = description
        entry["updated_at"] = datetime.now(tz=UTC).isoformat()
        if updated_by:
            entry["updated_by"] = updated_by

    def delete_config(
        self,
        pipeline_name: str,
        pipeline_version: str,
    ) -> bool:
        self._require_connection()
        key = (pipeline_name, pipeline_version)
        if key in self._configs:
            del self._configs[key]
            return True
        return False
