"""MongoDB pipeline config store implementation.

Stores versioned steps-native pipeline configurations in a MongoDB collection.
"""

from __future__ import annotations

import copy
import uuid
from datetime import UTC, datetime
from typing import Any

from pycharter.pipeline_store._mongodb_connection import _MongoDBPipelineConnectionMixin


class MongoDBPipelineStore(_MongoDBPipelineConnectionMixin):
    """MongoDB pipeline config store.

    Collection: ``pipeline_configs``
    Unique index on ``(pipeline_name, pipeline_version)``.
    """

    @property
    def _coll(self) -> Any:
        self._require_connection()
        return self._db.pipeline_configs

    # ------------------------------------------------------------------
    # CRUD
    # ------------------------------------------------------------------

    def store_config(
        self,
        pipeline_name: str,
        pipeline_version: str,
        steps: list[dict[str, Any]],
        *,
        settings: dict[str, Any] | None = None,
        variables: dict[str, Any] | None = None,
        description: str | None = None,
        contract_name: str | None = None,
        contract_version: str | None = None,
        created_by: str | None = None,
    ) -> str:
        existing = self._coll.find_one(
            {
                "pipeline_name": pipeline_name,
                "pipeline_version": pipeline_version,
            }
        )
        if existing:
            raise ValueError(
                f"Pipeline config already exists: {pipeline_name!r} @ {pipeline_version!r}"
            )

        config_id = str(uuid.uuid4())
        now = datetime.now(tz=UTC)

        doc = {
            "_id": config_id,
            "pipeline_name": pipeline_name,
            "pipeline_version": pipeline_version,
            "steps": copy.deepcopy(steps),
            "settings": copy.deepcopy(settings) if settings else None,
            "variables": copy.deepcopy(variables) if variables else None,
            "description": description,
            "status": "active",
            "contract_name": contract_name,
            "contract_version": contract_version,
            "created_at": now,
            "updated_at": now,
            "created_by": created_by,
            "updated_by": None,
        }
        self._coll.insert_one(doc)
        return config_id

    def get_config(
        self,
        pipeline_name: str,
        pipeline_version: str,
    ) -> dict[str, Any] | None:
        doc = self._coll.find_one(
            {
                "pipeline_name": pipeline_name,
                "pipeline_version": pipeline_version,
            }
        )
        if not doc:
            return None
        return self._doc_to_dict(doc)

    def list_configs(
        self,
        pipeline_name: str | None = None,
    ) -> list[dict[str, Any]]:
        query: dict[str, Any] = {}
        if pipeline_name is not None:
            query["pipeline_name"] = pipeline_name
        docs = self._coll.find(query).sort(
            [
                ("pipeline_name", 1),
                ("pipeline_version", 1),
            ]
        )
        return [self._doc_to_summary(d) for d in docs]

    def list_versions(self, pipeline_name: str) -> list[str]:
        docs = self._coll.find(
            {"pipeline_name": pipeline_name},
            {"pipeline_version": 1},
        ).sort("pipeline_version", 1)
        return [d["pipeline_version"] for d in docs]

    def update_status(
        self,
        pipeline_name: str,
        pipeline_version: str,
        status: str,
        *,
        updated_by: str | None = None,
    ) -> None:
        update_fields: dict[str, Any] = {
            "status": status,
            "updated_at": datetime.now(tz=UTC),
        }
        if updated_by:
            update_fields["updated_by"] = updated_by

        result = self._coll.update_one(
            {"pipeline_name": pipeline_name, "pipeline_version": pipeline_version},
            {"$set": update_fields},
        )
        if result.matched_count == 0:
            raise ValueError(
                f"Pipeline config not found: {pipeline_name!r} @ {pipeline_version!r}"
            )

    def update_config(
        self,
        pipeline_name: str,
        pipeline_version: str,
        *,
        steps: list[dict[str, Any]] | None = None,
        settings: dict[str, Any] | None = None,
        variables: dict[str, Any] | None = None,
        description: str | None = None,
        updated_by: str | None = None,
    ) -> None:
        update_fields: dict[str, Any] = {
            "updated_at": datetime.now(tz=UTC),
        }
        if steps is not None:
            update_fields["steps"] = copy.deepcopy(steps)
        if settings is not None:
            update_fields["settings"] = copy.deepcopy(settings)
        if variables is not None:
            update_fields["variables"] = copy.deepcopy(variables)
        if description is not None:
            update_fields["description"] = description
        if updated_by:
            update_fields["updated_by"] = updated_by

        result = self._coll.update_one(
            {"pipeline_name": pipeline_name, "pipeline_version": pipeline_version},
            {"$set": update_fields},
        )
        if result.matched_count == 0:
            raise ValueError(
                f"Pipeline config not found: {pipeline_name!r} @ {pipeline_version!r}"
            )

    def delete_config(
        self,
        pipeline_name: str,
        pipeline_version: str,
    ) -> bool:
        result = self._coll.delete_one(
            {
                "pipeline_name": pipeline_name,
                "pipeline_version": pipeline_version,
            }
        )
        return result.deleted_count > 0

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _doc_to_dict(doc: dict[str, Any]) -> dict[str, Any]:
        created_at = doc.get("created_at")
        updated_at = doc.get("updated_at")
        return {
            "id": str(doc["_id"]),
            "pipeline_name": doc["pipeline_name"],
            "pipeline_version": doc["pipeline_version"],
            "steps": doc.get("steps", []),
            "settings": doc.get("settings"),
            "variables": doc.get("variables"),
            "description": doc.get("description"),
            "status": doc.get("status"),
            "contract_name": doc.get("contract_name"),
            "contract_version": doc.get("contract_version"),
            "created_at": (
                created_at.isoformat()
                if isinstance(created_at, datetime)
                else created_at
            ),
            "updated_at": (
                updated_at.isoformat()
                if isinstance(updated_at, datetime)
                else updated_at
            ),
            "created_by": doc.get("created_by"),
            "updated_by": doc.get("updated_by"),
        }

    @staticmethod
    def _doc_to_summary(doc: dict[str, Any]) -> dict[str, Any]:
        created_at = doc.get("created_at")
        return {
            "pipeline_name": doc["pipeline_name"],
            "pipeline_version": doc["pipeline_version"],
            "status": doc.get("status"),
            "description": doc.get("description"),
            "contract_name": doc.get("contract_name"),
            "contract_version": doc.get("contract_version"),
            "created_at": (
                created_at.isoformat()
                if isinstance(created_at, datetime)
                else created_at
            ),
        }


__all__ = ["MongoDBPipelineStore"]
