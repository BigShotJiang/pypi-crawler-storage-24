"""MongoDB connection management for the pipeline config store.

Handles client lifecycle (connect/disconnect) and ensures indexes exist
for the ``pipeline_configs`` collection.
"""

from __future__ import annotations

from typing import Any

try:
    from pymongo import MongoClient  # type: ignore[import-untyped]

    MONGO_AVAILABLE = True
except ImportError:
    MONGO_AVAILABLE = False
    MongoClient = None  # type: ignore[assignment,misc]

from pycharter.pipeline_store.client import PipelineStoreClient


class _MongoDBPipelineConnectionMixin(PipelineStoreClient):
    """Mixin providing MongoDB connection management for the pipeline config store.

    Handles:
    - Client initialization with connection string validation
    - ``connect()`` / ``disconnect()`` lifecycle
    - Index creation for the ``pipeline_configs`` collection

    This is not meant to be instantiated directly.  Use ``MongoDBPipelineStore``
    from ``pycharter.pipeline_store.mongodb``.
    """

    def __init__(
        self,
        connection_string: str | None = None,
        database_name: str = "pycharter",
    ) -> None:
        """Initialize MongoDB pipeline store connection parameters.

        Args:
            connection_string: MongoDB connection string.
            database_name: Database name (default: "pycharter").
        """
        if not MONGO_AVAILABLE:
            raise ImportError(
                "pymongo is required for MongoDBPipelineStore. "
                "Install with: pip install pymongo"
            )
        if connection_string and not connection_string.startswith(
            ("mongodb://", "mongodb+srv://")
        ):
            raise ValueError(
                f"MongoDBPipelineStore requires a mongodb:// URL, got: {connection_string!r}"
            )
        super().__init__(connection_string)
        self.database_name = database_name
        self._client: MongoClient | None = None  # type: ignore[type-arg]
        self._db: Any = None

    def connect(self, ensure_indexes: bool = True) -> None:
        """Connect to MongoDB.

        Args:
            ensure_indexes: If True, ensure indexes exist (default: True).
        """
        if not self.connection_string:
            raise ValueError("connection_string is required for MongoDB")

        self._client = MongoClient(self.connection_string)
        self._db = self._client[self.database_name]  # type: ignore[index]
        self._connection = self._db

        if ensure_indexes:
            self._ensure_indexes()

    def disconnect(self) -> None:
        """Close MongoDB connection."""
        if self._client:
            self._client.close()
            self._client = None
            self._db = None
            self._connection = None

    def _ensure_indexes(self) -> None:
        """Ensure required indexes exist for pipeline_configs."""
        if self._db is None:
            return
        coll = self._db.pipeline_configs
        _create_index_if_missing(coll, "pipeline_name")
        _create_index_if_missing(coll, "status")
        _create_index_if_missing(coll, "data_contract_id")
        _create_index_if_missing(
            coll,
            [("pipeline_name", 1), ("pipeline_version", 1)],
            unique=True,
        )


# ---------------------------------------------------------------------------
# Index helpers
# ---------------------------------------------------------------------------


def _normalize_index_spec(spec: Any) -> dict[str, Any]:
    """Normalize index spec to a comparable dict format."""
    if isinstance(spec, str):
        return {spec: 1}
    if isinstance(spec, list):
        return dict(spec)
    return spec


def _index_exists_by_keys(collection: Any, index_spec: Any) -> bool:
    """Check if an index with the given key specification exists."""
    try:
        normalized_spec = _normalize_index_spec(index_spec)
        for idx in collection.list_indexes():
            if idx.get("key", {}) == normalized_spec:
                return True
    except Exception:
        return False
    return False


def _create_index_if_missing(collection: Any, index_spec: Any, **kwargs: Any) -> None:
    """Create index only if it doesn't exist."""
    if not _index_exists_by_keys(collection, index_spec):
        collection.create_index(index_spec, background=True, **kwargs)
