"""Redis pipeline config store implementation.

Steps-native store keyed by (pipeline_name, pipeline_version).
Keys: ``{prefix}:pipeline_config:{name}:{version}`` (full JSON blob)
Index: ``{prefix}:pipeline_configs:index`` = set of ``"name:version"``
"""

from __future__ import annotations

import json
import uuid
from datetime import UTC, datetime
from typing import Any

try:
    import redis as redis_lib  # type: ignore[import-not-found,import-untyped]

    REDIS_AVAILABLE = True
except ImportError:
    REDIS_AVAILABLE = False
    redis_lib = None  # type: ignore[assignment]

from pycharter.pipeline_store.client import PipelineStoreClient


class RedisPipelineStore(PipelineStoreClient):
    """Redis pipeline config store keyed by (pipeline_name, pipeline_version).

    Stores the full config as a single JSON value per pipeline version.
    """

    def __init__(
        self,
        connection_string: str | None = None,
        key_prefix: str = "pycharter",
    ) -> None:
        if not REDIS_AVAILABLE:
            raise ImportError(
                "redis is required for RedisPipelineStore. Install with: pip install redis"
            )
        super().__init__(connection_string)
        self.key_prefix = key_prefix
        self._client: Any = None

    def connect(self) -> None:
        if not self.connection_string:
            raise ValueError("connection_string is required for Redis")
        self._client = redis_lib.from_url(self.connection_string, decode_responses=True)
        self._client.ping()
        self._connection = self._client

    def disconnect(self) -> None:
        if self._client:
            self._client.close()
            self._client = None
            self._connection = None

    # ------------------------------------------------------------------
    # Key helpers
    # ------------------------------------------------------------------

    def _config_key(self, name: str, version: str) -> str:
        return f"{self.key_prefix}:pipeline_config:{name}:{version}"

    def _index_key(self) -> str:
        return f"{self.key_prefix}:pipeline_configs:index"

    # ------------------------------------------------------------------
    # CRUD
    # ------------------------------------------------------------------

    def store_config(
        self,
        pipeline_name: str,
        pipeline_version: str,
        steps: list[dict[str, Any]],
        *,
        settings: dict[str, Any] | None = None,
        variables: dict[str, Any] | None = None,
        description: str | None = None,
        contract_name: str | None = None,
        contract_version: str | None = None,
        created_by: str | None = None,
    ) -> str:
        self._require_connection()
        key = self._config_key(pipeline_name, pipeline_version)
        if self._client.exists(key):
            raise ValueError(
                f"ETL config already exists: {pipeline_name!r} @ {pipeline_version!r}"
            )

        config_id = str(uuid.uuid4())
        now = datetime.now(tz=UTC).isoformat()

        doc = {
            "id": config_id,
            "pipeline_name": pipeline_name,
            "pipeline_version": pipeline_version,
            "steps": steps,
            "settings": settings,
            "variables": variables,
            "description": description,
            "status": "active",
            "contract_name": contract_name,
            "contract_version": contract_version,
            "created_at": now,
            "updated_at": now,
            "created_by": created_by,
            "updated_by": None,
        }

        pipe = self._client.pipeline()
        pipe.set(key, json.dumps(doc))
        pipe.sadd(self._index_key(), f"{pipeline_name}:{pipeline_version}")
        pipe.execute()
        return config_id

    def get_config(
        self,
        pipeline_name: str,
        pipeline_version: str,
    ) -> dict[str, Any] | None:
        self._require_connection()
        raw = self._client.get(self._config_key(pipeline_name, pipeline_version))
        if not raw:
            return None
        return json.loads(raw)

    def list_configs(
        self,
        pipeline_name: str | None = None,
    ) -> list[dict[str, Any]]:
        self._require_connection()
        members = self._client.smembers(self._index_key())
        results: list[dict[str, Any]] = []
        for member in sorted(members):
            if ":" not in member:
                continue
            name, version = member.split(":", 1)
            if pipeline_name is not None and name != pipeline_name:
                continue
            raw = self._client.get(self._config_key(name, version))
            if not raw:
                continue
            doc = json.loads(raw)
            results.append(
                {
                    "pipeline_name": doc["pipeline_name"],
                    "pipeline_version": doc["pipeline_version"],
                    "status": doc.get("status"),
                    "description": doc.get("description"),
                    "contract_name": doc.get("contract_name"),
                    "contract_version": doc.get("contract_version"),
                    "created_at": doc.get("created_at"),
                }
            )
        return results

    def list_versions(self, pipeline_name: str) -> list[str]:
        self._require_connection()
        members = self._client.smembers(self._index_key())
        versions = []
        for member in members:
            if ":" not in member:
                continue
            name, version = member.split(":", 1)
            if name == pipeline_name:
                versions.append(version)
        return sorted(versions)

    def update_status(
        self,
        pipeline_name: str,
        pipeline_version: str,
        status: str,
        *,
        updated_by: str | None = None,
    ) -> None:
        self._require_connection()
        key = self._config_key(pipeline_name, pipeline_version)
        raw = self._client.get(key)
        if not raw:
            raise ValueError(
                f"ETL config not found: {pipeline_name!r} @ {pipeline_version!r}"
            )
        doc = json.loads(raw)
        doc["status"] = status
        doc["updated_at"] = datetime.now(tz=UTC).isoformat()
        if updated_by:
            doc["updated_by"] = updated_by
        self._client.set(key, json.dumps(doc))

    def update_config(
        self,
        pipeline_name: str,
        pipeline_version: str,
        *,
        steps: list[dict[str, Any]] | None = None,
        settings: dict[str, Any] | None = None,
        variables: dict[str, Any] | None = None,
        description: str | None = None,
        updated_by: str | None = None,
    ) -> None:
        self._require_connection()
        key = self._config_key(pipeline_name, pipeline_version)
        raw = self._client.get(key)
        if not raw:
            raise ValueError(
                f"ETL config not found: {pipeline_name!r} @ {pipeline_version!r}"
            )
        doc = json.loads(raw)
        if steps is not None:
            doc["steps"] = steps
        if settings is not None:
            doc["settings"] = settings
        if variables is not None:
            doc["variables"] = variables
        if description is not None:
            doc["description"] = description
        doc["updated_at"] = datetime.now(tz=UTC).isoformat()
        if updated_by:
            doc["updated_by"] = updated_by
        self._client.set(key, json.dumps(doc))

    def delete_config(
        self,
        pipeline_name: str,
        pipeline_version: str,
    ) -> bool:
        self._require_connection()
        key = self._config_key(pipeline_name, pipeline_version)
        if not self._client.exists(key):
            return False
        pipe = self._client.pipeline()
        pipe.delete(key)
        pipe.srem(self._index_key(), f"{pipeline_name}:{pipeline_version}")
        pipe.execute()
        return True
