"""Pipeline Store Client — persistence for versioned pipeline configurations.

Pipeline-centric API: all methods are keyed by (pipeline_name, pipeline_version).
Stores steps-native DAG configs alongside optional settings and variables.

Architecture notes:
    ``PipelineStoreClient`` is an abstract base class.  Subclasses (SQLite,
    Postgres, MongoDB, Redis, InMemory) implement the ``@abstractmethod``
    methods.  ``get_pipeline_dict`` returns a dict ready for
    ``Pipeline.from_dict()``.
"""

from __future__ import annotations

import copy
from abc import ABC, abstractmethod
from typing import Any


class PipelineStoreClient(ABC):
    """Client for storing and retrieving pipeline configurations.

    All operations are keyed by (pipeline_name, pipeline_version).
    """

    def __init__(self, connection_string: str | None = None) -> None:
        self.connection_string = connection_string
        self._connection: Any = None

    # -- lifecycle -----------------------------------------------------------

    @abstractmethod
    def connect(self) -> None:
        """Establish database connection."""

    def disconnect(self) -> None:
        """Close database connection."""
        if self._connection:
            self._connection = None

    def _require_connection(self) -> None:
        if self._connection is None:
            raise RuntimeError("Not connected. Call connect() first.")

    # -----------------------------------------------------------------------
    # Pipeline-centric API  (abstract methods)
    # -----------------------------------------------------------------------

    @abstractmethod
    def store_config(
        self,
        pipeline_name: str,
        pipeline_version: str,
        steps: list[dict[str, Any]],
        *,
        settings: dict[str, Any] | None = None,
        variables: dict[str, Any] | None = None,
        description: str | None = None,
        contract_name: str | None = None,
        contract_version: str | None = None,
        created_by: str | None = None,
    ) -> str:
        """Store a pipeline configuration (immutable per version).

        Args:
            pipeline_name: Pipeline identifier.
            pipeline_version: Pipeline version string.
            steps: Steps list (the DAG definition).
            settings: Optional pipeline settings dict.
            variables: Optional variable substitution dict.
            description: Optional human-readable description.
            contract_name: Optional associated data contract name.
            contract_version: Optional associated data contract version.
            created_by: Optional creator identifier.

        Returns:
            Config ID (implementation-defined).

        Raises:
            ValueError: If (pipeline_name, pipeline_version) already exists.
        """

    @abstractmethod
    def get_config(
        self,
        pipeline_name: str,
        pipeline_version: str,
    ) -> dict[str, Any] | None:
        """Retrieve the full stored configuration.

        Returns:
            Dict with keys: pipeline_name, pipeline_version, steps,
            settings, variables, description, status, created_at, etc.
            None if not found.
        """

    @abstractmethod
    def list_configs(
        self,
        pipeline_name: str | None = None,
    ) -> list[dict[str, Any]]:
        """List stored pipeline configurations.

        Args:
            pipeline_name: Optional filter by pipeline name.

        Returns:
            List of summary dicts.
        """

    @abstractmethod
    def list_versions(self, pipeline_name: str) -> list[str]:
        """List all stored versions for a given pipeline."""

    @abstractmethod
    def update_status(
        self,
        pipeline_name: str,
        pipeline_version: str,
        status: str,
        *,
        updated_by: str | None = None,
    ) -> None:
        """Update the lifecycle status of a stored config.

        Raises:
            ValueError: If the config does not exist.
        """

    @abstractmethod
    def update_config(
        self,
        pipeline_name: str,
        pipeline_version: str,
        *,
        steps: list[dict[str, Any]] | None = None,
        settings: dict[str, Any] | None = None,
        variables: dict[str, Any] | None = None,
        description: str | None = None,
        updated_by: str | None = None,
    ) -> None:
        """Patch mutable fields on a stored config.

        Only provided fields are updated; ``None`` means "leave unchanged".

        Raises:
            ValueError: If the config does not exist.
        """

    @abstractmethod
    def delete_config(
        self,
        pipeline_name: str,
        pipeline_version: str,
    ) -> bool:
        """Delete a stored pipeline configuration.

        Returns:
            True if deleted, False if not found.
        """

    # -----------------------------------------------------------------------
    # Concrete helpers
    # -----------------------------------------------------------------------

    def get_pipeline_dict(
        self,
        pipeline_name: str,
        pipeline_version: str,
    ) -> dict[str, Any] | None:
        """Return a config dict ready for ``Pipeline.from_dict()``.

        Args:
            pipeline_name: Pipeline identifier.
            pipeline_version: Pipeline version string.

        Returns:
            Dict with ``name``, ``version``, ``steps``, and optional
            ``settings``/``variables`` — or ``None`` if not found.
        """
        config = self.get_config(pipeline_name, pipeline_version)
        if config is None:
            return None

        result: dict[str, Any] = {
            "name": config.get("pipeline_name", pipeline_name),
            "version": config.get("pipeline_version", pipeline_version),
            "steps": copy.deepcopy(config.get("steps", [])),
        }

        if config.get("settings"):
            result["settings"] = copy.deepcopy(config["settings"])
        if config.get("variables"):
            result["variables"] = copy.deepcopy(config["variables"])
        if config.get("description"):
            result["description"] = config["description"]

        return result

    # -- context manager -----------------------------------------------------

    def __enter__(self) -> PipelineStoreClient:
        self.connect()
        return self

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: Any,
    ) -> None:
        self.disconnect()
