"""SQLAlchemy CRUD operations for the pipeline config store.

Internal module — import the public stores from ``pycharter.pipeline_store``.
"""

from __future__ import annotations

import copy
import logging
import uuid
from typing import Any

from pycharter.db.models.data_contract import DataContractModel
from pycharter.db.models.pipeline_config import PipelineConfigModel
from pycharter.pipeline_store._sqlalchemy_connection import (
    _SQLAlchemyPipelineConnectionMixin,
)

logger = logging.getLogger(__name__)


class _SQLAlchemyPipelineStoreBase(_SQLAlchemyPipelineConnectionMixin):
    """Shared SQLAlchemy CRUD logic for SQLite and PostgreSQL pipeline stores."""

    # ------------------------------------------------------------------
    # Contract FK resolution
    # ------------------------------------------------------------------

    def _resolve_contract_id(
        self,
        contract_name: str,
        contract_version: str,
    ) -> uuid.UUID:
        session = self._get_session()
        row = (
            session.query(DataContractModel)
            .filter(
                DataContractModel.name == contract_name,
                DataContractModel.version == contract_version,
            )
            .first()
        )
        if not row:
            raise ValueError(
                f"Data contract not found: {contract_name!r} @ {contract_version!r}"
            )
        return row.id  # type: ignore[return-value]

    # ------------------------------------------------------------------
    # CRUD
    # ------------------------------------------------------------------

    def store_config(
        self,
        pipeline_name: str,
        pipeline_version: str,
        steps: list[dict[str, Any]],
        *,
        settings: dict[str, Any] | None = None,
        variables: dict[str, Any] | None = None,
        description: str | None = None,
        contract_name: str | None = None,
        contract_version: str | None = None,
        created_by: str | None = None,
    ) -> str:
        session = self._get_session()

        existing = (
            session.query(PipelineConfigModel)
            .filter(
                PipelineConfigModel.pipeline_name == pipeline_name,
                PipelineConfigModel.pipeline_version == pipeline_version,
            )
            .first()
        )
        if existing:
            raise ValueError(
                f"Pipeline config already exists: {pipeline_name!r} @ {pipeline_version!r}"
            )

        data_contract_id: uuid.UUID | None = None
        if contract_name and contract_version:
            data_contract_id = self._resolve_contract_id(
                contract_name, contract_version
            )

        config_obj = PipelineConfigModel(
            pipeline_name=pipeline_name,
            pipeline_version=pipeline_version,
            steps=steps,
            settings=settings,
            variables=variables,
            description=description,
            data_contract_id=data_contract_id,
            created_by=created_by,
        )
        session.add(config_obj)
        session.commit()
        return str(config_obj.id)

    def get_config(
        self,
        pipeline_name: str,
        pipeline_version: str,
    ) -> dict[str, Any] | None:
        session = self._get_session()
        row = (
            session.query(PipelineConfigModel)
            .filter(
                PipelineConfigModel.pipeline_name == pipeline_name,
                PipelineConfigModel.pipeline_version == pipeline_version,
            )
            .first()
        )
        if not row:
            return None
        return self._row_to_dict(row)

    def list_configs(
        self,
        pipeline_name: str | None = None,
    ) -> list[dict[str, Any]]:
        session = self._get_session()
        query = session.query(PipelineConfigModel).order_by(
            PipelineConfigModel.pipeline_name,
            PipelineConfigModel.pipeline_version,
        )
        if pipeline_name is not None:
            query = query.filter(PipelineConfigModel.pipeline_name == pipeline_name)
        rows = query.all()
        return [self._row_to_summary(r) for r in rows]

    def list_versions(self, pipeline_name: str) -> list[str]:
        session = self._get_session()
        rows = (
            session.query(PipelineConfigModel.pipeline_version)
            .filter(PipelineConfigModel.pipeline_name == pipeline_name)
            .order_by(PipelineConfigModel.pipeline_version)
            .all()
        )
        return [r[0] for r in rows]

    def update_status(
        self,
        pipeline_name: str,
        pipeline_version: str,
        status: str,
        *,
        updated_by: str | None = None,
    ) -> None:
        session = self._get_session()
        row = (
            session.query(PipelineConfigModel)
            .filter(
                PipelineConfigModel.pipeline_name == pipeline_name,
                PipelineConfigModel.pipeline_version == pipeline_version,
            )
            .first()
        )
        if not row:
            raise ValueError(
                f"Pipeline config not found: {pipeline_name!r} @ {pipeline_version!r}"
            )
        row.status = status
        if updated_by:
            row.updated_by = updated_by
        session.commit()

    def update_config(
        self,
        pipeline_name: str,
        pipeline_version: str,
        *,
        steps: list[dict[str, Any]] | None = None,
        settings: dict[str, Any] | None = None,
        variables: dict[str, Any] | None = None,
        description: str | None = None,
        updated_by: str | None = None,
    ) -> None:
        session = self._get_session()
        row = (
            session.query(PipelineConfigModel)
            .filter(
                PipelineConfigModel.pipeline_name == pipeline_name,
                PipelineConfigModel.pipeline_version == pipeline_version,
            )
            .first()
        )
        if not row:
            raise ValueError(
                f"Pipeline config not found: {pipeline_name!r} @ {pipeline_version!r}"
            )
        if steps is not None:
            row.steps = copy.deepcopy(steps)
        if settings is not None:
            row.settings = copy.deepcopy(settings)
        if variables is not None:
            row.variables = copy.deepcopy(variables)
        if description is not None:
            row.description = description
        if updated_by:
            row.updated_by = updated_by
        session.commit()

    def delete_config(
        self,
        pipeline_name: str,
        pipeline_version: str,
    ) -> bool:
        session = self._get_session()
        row = (
            session.query(PipelineConfigModel)
            .filter(
                PipelineConfigModel.pipeline_name == pipeline_name,
                PipelineConfigModel.pipeline_version == pipeline_version,
            )
            .first()
        )
        if not row:
            return False
        session.delete(row)
        session.commit()
        return True

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _row_to_dict(row: PipelineConfigModel) -> dict[str, Any]:
        contract_name: str | None = None
        contract_version: str | None = None
        if row.data_contract is not None:
            contract_name = row.data_contract.name
            contract_version = row.data_contract.version
        return {
            "id": str(row.id),
            "pipeline_name": row.pipeline_name,
            "pipeline_version": row.pipeline_version,
            "steps": row.steps,
            "settings": row.settings,
            "variables": row.variables,
            "description": row.description,
            "status": row.status,
            "contract_name": contract_name,
            "contract_version": contract_version,
            "created_at": (row.created_at.isoformat() if row.created_at else None),
            "updated_at": (row.updated_at.isoformat() if row.updated_at else None),
            "created_by": row.created_by,
            "updated_by": row.updated_by,
        }

    @staticmethod
    def _row_to_summary(row: PipelineConfigModel) -> dict[str, Any]:
        contract_name: str | None = None
        contract_version: str | None = None
        if row.data_contract is not None:
            contract_name = row.data_contract.name
            contract_version = row.data_contract.version
        return {
            "pipeline_name": row.pipeline_name,
            "pipeline_version": row.pipeline_version,
            "status": row.status,
            "description": row.description,
            "contract_name": contract_name,
            "contract_version": contract_version,
            "created_at": (row.created_at.isoformat() if row.created_at else None),
        }
