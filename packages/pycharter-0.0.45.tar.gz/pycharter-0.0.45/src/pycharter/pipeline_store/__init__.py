"""Pipeline Store Client Service.

Connects to various databases and manages storage/retrieval
of versioned pipeline configurations.

Available implementations:
- InMemoryPipelineStore: In-memory store for testing/development
- MongoDBPipelineStore: MongoDB implementation
- PostgresPipelineStore: PostgreSQL implementation
- SQLitePipelineStore: SQLite implementation
- RedisPipelineStore: Redis implementation
"""

from __future__ import annotations

from pycharter.pipeline_store.client import PipelineStoreClient

# Import implementations (with optional dependencies)
try:
    from pycharter.pipeline_store.in_memory import InMemoryPipelineStore
except ImportError:
    InMemoryPipelineStore = None  # type: ignore[assignment,misc]

try:
    from pycharter.pipeline_store.mongodb import MongoDBPipelineStore
except ImportError:
    MongoDBPipelineStore = None  # type: ignore[assignment,misc]

try:
    from pycharter.pipeline_store.postgres import PostgresPipelineStore
except ImportError:
    PostgresPipelineStore = None  # type: ignore[assignment,misc]

try:
    from pycharter.pipeline_store.sqlite import SQLitePipelineStore
except ImportError:
    SQLitePipelineStore = None  # type: ignore[assignment,misc]

try:
    from pycharter.pipeline_store.redis import RedisPipelineStore
except ImportError:
    RedisPipelineStore = None  # type: ignore[assignment,misc]

__all__ = [
    "PipelineStoreClient",
    "InMemoryPipelineStore",
    "MongoDBPipelineStore",
    "PostgresPipelineStore",
    "SQLitePipelineStore",
    "RedisPipelineStore",
]
