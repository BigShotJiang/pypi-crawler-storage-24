"""SQLAlchemy connection management for the pipeline config store.

Provides ``_SQLAlchemyPipelineConnectionMixin`` with engine/session lifecycle
and schema helpers.  This module is internal — import the public stores
from ``pycharter.pipeline_store``.
"""

from __future__ import annotations

import logging
from typing import Any

from sqlalchemy import inspect
from sqlalchemy.orm import Session, sessionmaker

from pycharter.db.models.base import Base, get_engine
from pycharter.db.models.data_contract import DataContractModel
from pycharter.db.models.pipeline_config import PipelineConfigModel
from pycharter.pipeline_store.client import PipelineStoreClient

logger = logging.getLogger(__name__)


class _SQLAlchemyPipelineConnectionMixin(PipelineStoreClient):
    """Engine / session lifecycle and schema helpers for SQLAlchemy pipeline stores.

    Subclasses must:
    1. Validate the connection string in ``__init__``.
    2. Implement ``connect()`` and call ``_connect_engine()`` with the
       appropriate ``schema_name``.
    """

    def __init__(self, connection_string: str) -> None:
        super().__init__(connection_string)
        self._engine: Any = None
        self._session: Session | None = None
        self._schema_name: str | None = None

    # ------------------------------------------------------------------
    # Engine / session lifecycle
    # ------------------------------------------------------------------

    def _connect_engine(
        self,
        schema_name: str | None,
        *,
        validate_schema: bool = True,
        auto_initialize: bool = False,
    ) -> None:
        """Create engine, session, and optionally validate / create tables.

        Args:
            schema_name: Database schema to inspect (``None`` for SQLite,
                ``"pycharter"`` for PostgreSQL).
            validate_schema: Check that required tables exist.
            auto_initialize: Create tables if they are missing.
        """
        self._schema_name = schema_name
        self._engine = get_engine(self.connection_string)  # type: ignore[arg-type]
        factory = sessionmaker(bind=self._engine)
        self._session = factory()
        self._connection = self._session

        if not self._is_schema_initialized():
            if auto_initialize:
                self._initialize_schema()
            elif validate_schema:
                raise RuntimeError(
                    "Database schema is not initialized. "
                    "Please run 'pycharter db init' to initialize the "
                    "schema first.\n"
                    f"Example: pycharter db init {self.connection_string}"
                )

    def disconnect(self) -> None:
        """Close session and dispose engine."""
        if self._session is not None:
            self._session.close()
            self._session = None
        if self._engine is not None:
            self._engine.dispose()
            self._engine = None
        self._connection = None

    # ------------------------------------------------------------------
    # Schema helpers
    # ------------------------------------------------------------------

    def _is_schema_initialized(self) -> bool:
        """Check whether the ``pipeline_configs`` table exists."""
        if self._engine is None:
            return False
        try:
            insp = inspect(self._engine)
            tables = insp.get_table_names(schema=self._schema_name)
            return "pipeline_configs" in tables
        except Exception:
            return False

    #: Tables managed by the pipeline config store.  Includes DataContractModel
    #: because PipelineConfigModel has an FK dependency on data_contracts.
    _CORE_TABLES = [
        DataContractModel.__table__,
        PipelineConfigModel.__table__,
    ]

    def _initialize_schema(self) -> None:
        """Create pipeline config tables from SQLAlchemy models."""
        try:
            Base.metadata.create_all(self._engine, tables=self._CORE_TABLES)
        except Exception as exc:
            raise RuntimeError(
                f"Failed to initialize pipeline config schema: {exc}"
            ) from exc

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _get_session(self) -> Session:
        """Return the active session, raising if not connected."""
        self._require_connection()
        assert self._session is not None  # noqa: S101
        return self._session
