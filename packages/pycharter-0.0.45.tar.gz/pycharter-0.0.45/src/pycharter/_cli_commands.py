"""CLI command dispatch handlers for each pycharter subcommand.

Each ``handle_*`` function receives the parsed ``argparse.Namespace`` and
the corresponding sub-parser (for help display).  They return an integer
exit code (0 = success).
"""

from __future__ import annotations

import argparse
import importlib.util
import os
import sys
from pathlib import Path


def handle_db(args: argparse.Namespace, db_parser: argparse.ArgumentParser) -> int:
    """Dispatch ``db`` subcommands to ``pycharter.db.cli``."""
    if not args.db_command:
        db_parser.print_help()
        return 1

    from pycharter.db.cli import (
        cmd_current,
        cmd_downgrade,
        cmd_history,
        cmd_init,
        cmd_seed,
        cmd_stamp,
        cmd_truncate,
        cmd_upgrade,
    )

    if args.db_command == "init":
        return cmd_init(args.database_url, db_type=args.db_type, force=args.force)
    if args.db_command == "upgrade":
        return cmd_upgrade(args.database_url, args.revision)
    if args.db_command == "downgrade":
        return cmd_downgrade(args.database_url, args.revision)
    if args.db_command == "current":
        return cmd_current(args.database_url)
    if args.db_command == "history":
        return cmd_history(args.database_url)
    if args.db_command == "stamp":
        return cmd_stamp(args.database_url, args.revision)
    if args.db_command == "seed":
        return cmd_seed(args.seed_dir, args.database_url)
    if args.db_command == "truncate":
        return cmd_truncate(args.database_url, force=args.force)

    db_parser.print_help()
    return 1


def _pycharter_package_root() -> Path:
    """Return the pycharter package root directory (works installed or in dev)."""
    try:
        import pycharter as _pkg

        return Path(_pkg.__file__).resolve().parent
    except ImportError:
        return Path(__file__).resolve().parent


def _reload_dirs_excluding_ui() -> list[str]:
    """
    Directories to watch in reload mode: all pycharter package subdirs except 'ui'.
    Watching only these avoids hitting the OS inotify limit from ui/node_modules.
    Trade-off: changes to top-level .py files in the package root do not trigger reload.
    """
    pkg_root = _pycharter_package_root()
    return [str(d) for d in sorted(pkg_root.iterdir()) if d.is_dir() and d.name != "ui"]


def handle_api(args: argparse.Namespace) -> int:
    """Start the uvicorn-based API server."""
    try:
        import uvicorn  # type: ignore[import-not-found,import-untyped]
    except ImportError:
        print("Error: uvicorn is required for API server.", file=sys.stderr)
        print("   Install with: pip install pycharter[api]", file=sys.stderr)
        return 1

    # Try to import api module — if it fails, we are in development mode
    # and need to add project root to path.
    try:
        import api  # type: ignore[import-untyped]  # noqa: F401
    except ImportError:
        project_root = Path(__file__).parent.parent.resolve()
        project_root_str = str(project_root)

        if project_root_str not in sys.path:
            sys.path.insert(0, project_root_str)

        # Set PYTHONPATH for uvicorn subprocess (reload mode).
        pythonpath = os.environ.get("PYTHONPATH", "")
        if pythonpath:
            pythonpath = f"{project_root_str}{os.pathsep}{pythonpath}"
        else:
            pythonpath = project_root_str
        os.environ["PYTHONPATH"] = pythonpath

    run_kw: dict = {
        "host": args.host,
        "port": args.port,
        "reload": args.reload,
    }
    # Watch only Python package subdirs (exclude ui) to avoid OS file watch limit
    # from ui/node_modules. Do not use reload_excludes: uvicorn expands globs into
    # huge directory lists and can raise or hang.
    if args.reload:
        run_kw["reload_dirs"] = _reload_dirs_excluding_ui()
    uvicorn.run("pycharter.api.main:app", **run_kw)
    return 0


def handle_ui(
    args: argparse.Namespace,
    ui_parser: argparse.ArgumentParser,
) -> int:
    """Dispatch ``ui`` subcommands (serve / dev / build)."""
    if not args.ui_command:
        ui_parser.print_help()
        return 1

    ui_path = _resolve_ui_path()
    if ui_path is None:
        _print_ui_not_found()
        return 1

    # Add ui directory to Python path.
    if str(ui_path) not in sys.path:
        sys.path.insert(0, str(ui_path))

    if args.ui_command == "serve":
        return _run_ui_module(
            ui_path / "server.py",
            "server",
            "serve_ui",
            api_url=args.api_url,
            host=args.host,
            port=args.port,
        )
    if args.ui_command == "dev":
        return _run_ui_module(
            ui_path / "dev.py",
            "dev",
            "run_dev_server",
            api_url=args.api_url,
            port=args.port,
        )
    if args.ui_command == "build":
        return _run_ui_module(ui_path / "build.py", "build", "build_ui")

    ui_parser.print_help()
    return 1


def handle_worker(
    args: argparse.Namespace,
    worker_parser: argparse.ArgumentParser,
) -> int:
    """Dispatch ``worker start``."""
    if getattr(args, "worker_command", None) == "start":
        from pycharter.worker.cli import cmd_worker_start

        return cmd_worker_start(
            concurrency=args.concurrency,
            poll_interval=args.poll_interval,
        )
    worker_parser.print_help()
    return 1


def handle_pipeline(
    args: argparse.Namespace,
    pipeline_parser: argparse.ArgumentParser,
) -> int:
    """Dispatch ``pipeline`` subcommands to ``pycharter.pipeline_generator.pipeline_cli``."""
    if not args.pipeline_command:
        pipeline_parser.print_help()
        return 1

    from pycharter.pipeline_generator.pipeline_cli import (
        cmd_etl_init,
        cmd_etl_inspect,
        cmd_etl_list,
        cmd_etl_run,
        cmd_etl_validate,
    )

    if args.pipeline_command == "run":
        return cmd_etl_run(
            path=args.path,
            variables=args.var,
            params=args.param,
            dry_run=args.dry_run,
            validate=args.validate,
        )
    if args.pipeline_command == "validate":
        return cmd_etl_validate(path=args.path)
    if args.pipeline_command == "init":
        return cmd_etl_init(path=args.path, template=args.template)
    if args.pipeline_command == "list":
        return cmd_etl_list(path=args.path)
    if args.pipeline_command == "inspect":
        return cmd_etl_inspect(path=args.path)

    pipeline_parser.print_help()
    return 1


def handle_quality(
    args: argparse.Namespace,
    quality_parser: argparse.ArgumentParser,
) -> int:
    """Dispatch ``quality`` subcommands to ``pycharter.quality.cli``."""
    if not args.quality_command:
        quality_parser.print_help()
        return 1

    if args.quality_command == "check":
        from pycharter.quality.cli import cmd_quality_check

        return cmd_quality_check(
            contract_name=args.contract_name,
            contract_version=args.contract_version,
            contract=args.contract,
            data=args.data,
            database_url=args.database_url,
            record_violations=args.record_violations,
            check_thresholds=args.check_thresholds,
            thresholds_file=args.thresholds_file,
            sample_size=args.sample_size,
            output=args.output,
        )
    if args.quality_command == "violations":
        from pycharter.quality.cli import cmd_quality_violations

        return cmd_quality_violations(
            contract_name=args.contract_name,
            contract_version=args.contract_version,
            status=args.status,
            severity=args.severity,
            database_url=args.database_url,
            limit=args.limit,
            output=args.output,
        )

    quality_parser.print_help()
    return 1


def handle_docs(
    args: argparse.Namespace,
    docs_parser: argparse.ArgumentParser,
) -> int:
    """Dispatch ``docs`` subcommands (serve / build)."""
    if not args.docs_command:
        docs_parser.print_help()
        return 1

    from pycharter.docs.cli import cmd_docs_build, cmd_docs_serve

    if args.docs_command == "serve":
        return cmd_docs_serve(host=args.host, port=args.port)
    if args.docs_command == "build":
        return cmd_docs_build()

    docs_parser.print_help()
    return 1


# ------------------------------------------------------------------
# Private helpers
# ------------------------------------------------------------------


def _resolve_ui_path() -> Path | None:
    """Locate the UI directory across installed and development layouts."""
    possible_paths: list[Path] = []

    try:
        import pycharter

        package_ui = Path(pycharter.__file__).parent / "ui"
        possible_paths.append(package_ui)
    except (ImportError, AttributeError):
        pass

    possible_paths.extend(
        [
            Path(__file__).parent / "ui",
            Path.cwd() / "src" / "pycharter" / "ui",
            Path.cwd() / "ui",
        ]
    )

    for path in possible_paths:
        if path.exists() and (path / "server.py").exists():
            return path
    return None


def _print_ui_not_found() -> None:
    """Emit a helpful error when the UI directory cannot be found."""
    print("Error: UI directory not found.", file=sys.stderr)
    print(
        "   If installed from pip: UI should be included in the package.",
        file=sys.stderr,
    )
    print(
        "   If in development: Make sure you're running "
        "from the PyCharter project root.",
        file=sys.stderr,
    )
    print(
        "   Or install the UI dependencies: cd ui && npm install",
        file=sys.stderr,
    )


def _run_ui_module(
    module_path: Path,
    module_name: str,
    func_name: str,
    **kwargs: object,
) -> int:
    """Dynamically load a UI helper module and call *func_name*."""
    spec = importlib.util.spec_from_file_location(module_name, module_path)
    if spec and spec.loader:
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        result = getattr(mod, func_name)(**kwargs)
        return result if isinstance(result, int) else 0
    return 1
