"""Rule extraction, quality metrics computation, and metrics recording helpers.

Internal module supporting the Validator class. Not part of the public API.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from pycharter.runtime_validator.validator_core import QualityMetrics, ValidationResult

if TYPE_CHECKING:
    from pycharter.quality.tracking import MetricsCollector


def extract_rules(rules_data: Any) -> dict[str, Any]:
    """Extract rules from various formats.

    Handles:
    - Direct rules dict: ``{"field1": "rule1", "field2": "rule2"}``
    - Wrapped rules dict: ``{"rules": {"field1": "rule1"}}``
    - Metadata dict with rules: ``{"version": "1.0", "rules": {...}}``

    Args:
        rules_data: Rules data in various formats.

    Returns:
        Dictionary of field_name -> rule mappings.
    """
    if not isinstance(rules_data, dict):
        return {}

    # If "rules" key exists, extract it
    if "rules" in rules_data:
        return rules_data["rules"]

    # If it looks like a metadata dict (has version/description/title), return empty
    # Otherwise, assume it's a direct rules dict
    metadata_keys = {"version", "description", "title"}
    if metadata_keys.intersection(rules_data.keys()):
        return {}

    return rules_data


def compute_quality_metrics(
    data_list: list[dict[str, Any]],
    results: list[ValidationResult],
) -> QualityMetrics:
    """Compute quality metrics for validated data.

    Args:
        data_list: Original data records.
        results: Validation results.

    Returns:
        QualityMetrics object with completeness and counts.
    """
    if not data_list:
        return QualityMetrics()

    # Count valid/invalid
    valid_count = sum(1 for r in results if r.is_valid)
    error_count = len(results) - valid_count

    # Compute field completeness
    field_completeness: dict[str, float | None] = {}
    all_fields: set[str] = set()

    for data in data_list:
        all_fields.update(data.keys())

    for field_name in all_fields:
        non_null_count = sum(
            1 for data in data_list if data.get(field_name) is not None
        )
        field_completeness[field_name] = non_null_count / len(data_list)

    # Compute overall completeness
    if field_completeness:
        completeness = sum(field_completeness.values()) / len(field_completeness)
    else:
        completeness = 1.0

    return QualityMetrics(
        completeness=completeness,
        field_completeness=field_completeness,
        record_count=len(data_list),
        valid_count=valid_count,
        error_count=error_count,
    )


def record_metrics(
    collector: MetricsCollector,
    result: ValidationResult,
    duration_ms: float,
    schema_name: str,
    schema_version: str,
) -> None:
    """Record metrics for a single validation.

    Args:
        collector: MetricsCollector instance.
        result: Validation result.
        duration_ms: Validation duration in milliseconds.
        schema_name: Name of the validated schema.
        schema_version: Version of the validated schema.
    """
    collector.record(
        result,
        schema_name=schema_name,
        version=schema_version,
        duration_ms=duration_ms,
    )


def record_batch_metrics(
    collector: MetricsCollector,
    results: list[ValidationResult],
    duration_ms: float,
    schema_name: str,
    schema_version: str,
) -> None:
    """Record metrics for a batch validation.

    Args:
        collector: MetricsCollector instance.
        results: List of validation results.
        duration_ms: Total validation duration in milliseconds.
        schema_name: Name of the validated schema.
        schema_version: Version of the validated schema.
    """
    collector.record_batch(
        results,
        schema_name=schema_name,
        version=schema_version,
        duration_ms=duration_ms,
    )
