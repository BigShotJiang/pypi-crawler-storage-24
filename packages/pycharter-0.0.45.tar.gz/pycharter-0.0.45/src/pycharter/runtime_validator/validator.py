"""Contract Validator Class -- backward-compatible re-export shim.

The implementation lives in ``_engine.py`` (Validator class and factory) and
``_rules.py`` (rule extraction and quality helpers).  This module re-exports
the public names so that existing ``from pycharter.runtime_validator.validator
import Validator`` statements continue to work without modification.
"""

from __future__ import annotations

from pycharter.runtime_validator._engine import Validator, create_validator

__all__ = [
    "Validator",
    "create_validator",
]
