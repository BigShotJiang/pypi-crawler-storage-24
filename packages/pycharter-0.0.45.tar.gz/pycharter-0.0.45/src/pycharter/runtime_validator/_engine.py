"""Core validation engine -- the Validator class.

This internal module contains the ``Validator`` class and the
``create_validator`` convenience factory.  All public names are
re-exported from ``pycharter.runtime_validator.validator`` for
backward compatibility.
"""

from __future__ import annotations

import copy
import time
from pathlib import Path
from typing import TYPE_CHECKING, Any

from pydantic import BaseModel

from pycharter.contract_builder.types import DataContract
from pycharter.pydantic_generator import from_dict
from pycharter.runtime_validator._loaders import (
    load_from_dict,
    load_from_directory,
    load_from_explicit_files,
    load_from_file,
    load_from_metadata,
    load_from_store,
)
from pycharter.runtime_validator._rules import (
    compute_quality_metrics,
    record_batch_metrics,
    record_metrics,
)
from pycharter.runtime_validator.utils import merge_rules_into_schema
from pycharter.runtime_validator.validator_core import (
    ValidationResult,
    validate,
    validate_batch,
)

if TYPE_CHECKING:
    from pycharter.contract_parser import ContractMetadata
    from pycharter.contract_store import ContractStoreClient
    from pycharter.quality.tracking import MetricsCollector


class Validator:
    """Generic Validator that performs validation from contract artifacts.

    Instantiate with contract files, a directory, or a contract store,
    then call ``validate()`` or ``validate_batch()`` on data dicts.
    """

    def __init__(
        self,
        contract_dir: str | None = None,
        contract_file: str | None = None,
        contract_dict: dict[str, Any] | DataContract | None = None,
        contract_metadata: ContractMetadata | None = None,
        store: ContractStoreClient | None = None,
        contract_name: str | None = None,
        contract_version: str | None = None,
    ):
        """Initialize the validator with contract artifacts.

        Provide exactly one source: *contract_dir*, *contract_file*,
        *contract_dict* (dict or DataContract), *contract_metadata*, or the tuple
        (*store*, *contract_name*, *contract_version*).
        """
        if isinstance(contract_dict, DataContract):
            contract_dict = contract_dict.to_dict()
        self.schema: dict[str, Any] | None = None
        self.coercion_rules: dict[str, Any] = {}
        self.validation_rules: dict[str, Any] = {}
        self.model: type[BaseModel] | None = None
        self._schema_from_store: bool = False

        # Builder configuration options
        self._strict_mode: bool = False
        self._include_quality: bool = False
        self._quality_thresholds: dict[str, float] | None = None
        self._metrics_collector: MetricsCollector | None = None
        self._schema_name: str | None = None
        self._schema_version: str = "1.0.0"

        self._dispatch_load(
            contract_dir=contract_dir,
            contract_file=contract_file,
            contract_dict=contract_dict,
            contract_metadata=contract_metadata,
            store=store,
            contract_name=contract_name,
            contract_version=contract_version,
        )
        self._generate_model()

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _dispatch_load(
        self,
        *,
        contract_dir: str | None,
        contract_file: str | None,
        contract_dict: dict[str, Any] | None,
        contract_metadata: ContractMetadata | None,
        store: ContractStoreClient | None,
        contract_name: str | None,
        contract_version: str | None,
    ) -> None:
        """Route to the appropriate loader and populate instance state."""
        if store and contract_name and contract_version:
            schema, coercion, validation = load_from_store(
                store, contract_name, contract_version
            )
            self._schema_from_store = False
        elif contract_metadata:
            schema, coercion, validation = load_from_metadata(contract_metadata)
        elif contract_dict:
            schema, coercion, validation = load_from_dict(contract_dict)
        elif contract_file:
            schema, coercion, validation = load_from_file(Path(contract_file))
        elif contract_dir:
            schema, coercion, validation = load_from_directory(Path(contract_dir))
        else:
            raise ValueError(
                "Must provide one of: contract_dir, contract_file, contract_dict, "
                "contract_metadata, or (store + contract_name + contract_version)"
            )

        self.schema = schema
        self.coercion_rules = coercion
        self.validation_rules = validation

    def _merge_rules_into_schema(self) -> dict[str, Any]:
        """Merge coercion and validation rules into schema.

        Returns:
            Complete schema with rules merged.

        Raises:
            ValueError: If schema not loaded.
        """
        if not self.schema:
            raise ValueError("Schema not loaded. Check contract loading.")

        if self._schema_from_store:
            return self.schema

        return merge_rules_into_schema(
            self.schema, self.coercion_rules, self.validation_rules
        )

    def _generate_model(self) -> None:
        """Generate Pydantic model from complete schema."""
        complete_schema = self._merge_rules_into_schema()
        model_name = complete_schema.get("title", "DynamicModel")
        self.model = from_dict(complete_schema, model_name)

        self._schema_name = model_name
        if "version" in complete_schema:
            self._schema_version = complete_schema["version"]

    # ------------------------------------------------------------------
    # Factory methods
    # ------------------------------------------------------------------

    @classmethod
    def from_files(
        cls,
        schema: str,
        coercion_rules: str | None = None,
        validation_rules: str | None = None,
    ) -> Validator:
        """Create validator from explicit file paths."""
        contract = load_from_explicit_files(schema, coercion_rules, validation_rules)
        return cls(contract_dict=contract)

    @classmethod
    def from_dir(cls, directory: str) -> Validator:
        """Create validator from a directory containing config files."""
        return cls(contract_dir=directory)

    @classmethod
    def from_dict(
        cls,
        schema: dict[str, Any],
        coercion_rules: dict[str, Any] | None = None,
        validation_rules: dict[str, Any] | None = None,
    ) -> Validator:
        """Create validator from dictionaries."""
        return cls(
            contract_dict={
                "schema": schema,
                "coercion_rules": coercion_rules or {},
                "validation_rules": validation_rules or {},
            }
        )

    @classmethod
    def from_file(cls, path: str) -> Validator:
        """Create validator from a single contract file."""
        return cls(contract_file=path)

    # ------------------------------------------------------------------
    # Validation
    # ------------------------------------------------------------------

    def validate(
        self,
        data: dict[str, Any],
        strict: bool | None = None,
        include_quality: bool | None = None,
    ) -> ValidationResult:
        """Validate a single data record against the contract.

        Args:
            data: Data dictionary to validate.
            strict: If True, raise exceptions on validation errors.
                Defaults to builder setting or False.
            include_quality: If True, include quality metrics in result.
                Defaults to builder setting or False.

        Returns:
            ValidationResult object.
        """
        if not self.model:
            raise ValueError("Model not initialized. Check contract loading.")

        use_strict = strict if strict is not None else self._strict_mode
        use_quality = (
            include_quality if include_quality is not None else self._include_quality
        )

        start_time = time.perf_counter()
        result = validate(self.model, data, strict=use_strict)
        duration_ms = (time.perf_counter() - start_time) * 1000

        if use_quality:
            result.quality = compute_quality_metrics([data], [result])

        if self._metrics_collector:
            record_metrics(
                self._metrics_collector,
                result,
                duration_ms,
                self._schema_name or "unknown",
                self._schema_version,
            )

        return result

    def validate_batch(
        self,
        data_list: list[dict[str, Any]],
        strict: bool | None = None,
        include_quality: bool | None = None,
    ) -> list[ValidationResult]:
        """Validate a batch of data records against the contract.

        Args:
            data_list: List of data dictionaries to validate.
            strict: If True, stop on first validation error.
                Defaults to builder setting or False.
            include_quality: If True, include quality metrics in results.
                Defaults to builder setting or False.

        Returns:
            List of ValidationResult objects.
        """
        if not self.model:
            raise ValueError("Model not initialized. Check contract loading.")

        use_strict = strict if strict is not None else self._strict_mode
        use_quality = (
            include_quality if include_quality is not None else self._include_quality
        )

        start_time = time.perf_counter()
        results = validate_batch(self.model, data_list, strict=use_strict)
        duration_ms = (time.perf_counter() - start_time) * 1000

        if use_quality:
            quality = compute_quality_metrics(data_list, results)
            if results:
                results[-1].quality = quality

        if self._metrics_collector:
            record_batch_metrics(
                self._metrics_collector,
                results,
                duration_ms,
                self._schema_name or "unknown",
                self._schema_version,
            )

        return results

    def validate_for_state(
        self,
        data: dict[str, Any],
        state: str,
        state_rules: dict[str, Any] | None = None,
    ) -> ValidationResult:
        """Validate data with state-specific rule overrides.

        Args:
            data: Data dictionary to validate.
            state: Current state value (e.g. ``"DRAFT"``, ``"FILLED"``).
            state_rules: Mapping from state names to override dicts.

        Returns:
            ValidationResult (identical format to ``validate()``).
        """
        rules = (
            state_rules
            if state_rules is not None
            else getattr(self, "_state_rules", None)
        )

        if not rules or state not in rules:
            return self.validate(data)

        if not self.schema:
            raise ValueError("Schema not loaded. Check contract loading.")

        overrides = rules[state]
        schema_copy = copy.deepcopy(self._merge_rules_into_schema())
        current_required = list(schema_copy.get("required", []))

        for field_name in overrides.get("optional", []):
            if field_name in current_required:
                current_required.remove(field_name)

        for field_name in overrides.get("required", []):
            if field_name not in current_required:
                current_required.append(field_name)

        schema_copy["required"] = current_required

        model_name = schema_copy.get("title", "DynamicModel") + f"_{state}"
        temp_model = from_dict(schema_copy, model_name)

        return validate(temp_model, data, strict=self._strict_mode)

    # ------------------------------------------------------------------
    # Accessors
    # ------------------------------------------------------------------

    def get_model(self) -> type[BaseModel]:
        """Get the generated Pydantic model.

        Returns:
            Pydantic model class.

        Raises:
            ValueError: If model not initialized.
        """
        if not self.model:
            raise ValueError("Model not initialized. Check contract loading.")
        return self.model

    def get_schema(self) -> dict[str, Any]:
        """Get the complete schema (with rules merged).

        Returns:
            Complete schema dictionary.
        """
        return self._merge_rules_into_schema()


def create_validator(
    contract_dir: str | None = None,
    **kwargs: Any,
) -> Validator:
    """Create a Validator instance.

    Args:
        contract_dir: Directory containing contract files.
        **kwargs: Additional arguments passed to Validator.

    Returns:
        Validator instance.
    """
    return Validator(contract_dir=contract_dir, **kwargs)
