"""Contract loading helpers for the Validator class.

Internal module that handles loading contract artifacts from files,
directories, dictionaries, metadata objects, and contract stores.
Not part of the public API.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

import yaml

from pycharter.contract_parser import ContractMetadata, parse_contract_file
from pycharter.contract_store import ContractStoreClient
from pycharter.runtime_validator._rules import extract_rules
from pycharter.utils.value_injector import resolve_values


def load_from_store(
    store: ContractStoreClient,
    contract_name: str,
    contract_version: str,
) -> tuple[dict[str, Any], dict[str, Any], dict[str, Any]]:
    """Load contract from contract store.

    Args:
        store: ContractStoreClient instance.
        contract_name: Data contract name.
        contract_version: Data contract version.

    Returns:
        Tuple of (schema, coercion_rules, validation_rules).

    Raises:
        ValueError: If schema not found in store.
    """
    raw_schema = store.get_schema(contract_name, contract_version)
    if not raw_schema:
        raise ValueError(
            f"Contract {contract_name!r} @ {contract_version!r} not found in store"
        )
    coercion_rules = store.get_coercion_rules(contract_name, contract_version)
    validation_rules = store.get_validation_rules(contract_name, contract_version)

    return (
        raw_schema,
        extract_rules(coercion_rules) if coercion_rules else {},
        extract_rules(validation_rules) if validation_rules else {},
    )


def load_from_metadata(
    metadata: ContractMetadata,
) -> tuple[dict[str, Any], dict[str, Any], dict[str, Any]]:
    """Load contract from ContractMetadata object.

    Args:
        metadata: ContractMetadata object containing schema and rules.

    Returns:
        Tuple of (schema, coercion_rules, validation_rules).
    """
    return (
        metadata.schema,
        metadata.coercion_rules or {},
        metadata.validation_rules or {},
    )


def load_from_dict(
    contract: dict[str, Any],
) -> tuple[dict[str, Any], dict[str, Any], dict[str, Any]]:
    """Load contract from dictionary.

    Args:
        contract: Dictionary with 'json_schema' (or 'schema'), 'coercion_rules',
            'validation_rules' keys.

    Returns:
        Tuple of (schema, coercion_rules, validation_rules).

    Raises:
        ValueError: If 'json_schema' key is missing.
    """
    schema = contract.get("json_schema") or contract.get("schema")
    if not schema:
        raise ValueError("Contract dictionary must contain 'json_schema' key")

    return (
        schema,
        extract_rules(contract.get("coercion_rules", {})),
        extract_rules(contract.get("validation_rules", {})),
    )


def load_from_file(
    file_path: Path,
) -> tuple[dict[str, Any], dict[str, Any], dict[str, Any]]:
    """Load contract from a single contract file.

    Args:
        file_path: Path to contract file (YAML/JSON).

    Returns:
        Tuple of (schema, coercion_rules, validation_rules).
    """
    contract_metadata = parse_contract_file(str(file_path))
    return load_from_metadata(contract_metadata)


def load_from_directory(
    contract_dir: Path,
) -> tuple[dict[str, Any], dict[str, Any], dict[str, Any]]:
    """Load contract components from a directory.

    Expected files:
    - schema.yaml (required)
    - coercion_rules.yaml (optional)
    - validation_rules.yaml (optional)

    Args:
        contract_dir: Path to contract directory.

    Returns:
        Tuple of (schema, coercion_rules, validation_rules).

    Raises:
        ValueError: If directory or schema file doesn't exist.
    """
    if not contract_dir.exists():
        raise ValueError(f"Contract directory not found: {contract_dir}")

    schema_path = contract_dir / "schema.yaml"
    if not schema_path.exists():
        raise ValueError(f"Schema file not found: {schema_path}")

    schema = load_yaml(schema_path)
    coercion_rules: dict[str, Any] = {}
    validation_rules: dict[str, Any] = {}

    coercion_path = contract_dir / "coercion_rules.yaml"
    if coercion_path.exists():
        coercion_rules = extract_rules(load_yaml(coercion_path))

    validation_path = contract_dir / "validation_rules.yaml"
    if validation_path.exists():
        validation_rules = extract_rules(load_yaml(validation_path))

    return schema, coercion_rules, validation_rules


def load_yaml(file_path: Path) -> dict[str, Any]:
    """Load and parse YAML file with variable substitution.

    Args:
        file_path: Path to YAML file.

    Returns:
        Parsed YAML data as dictionary.
    """
    with open(file_path, encoding="utf-8") as f:
        data = yaml.safe_load(f) or {}

    if data:
        data = resolve_values(data, source_file=str(file_path))

    return data


def load_from_explicit_files(
    schema: str,
    coercion_rules: str | None = None,
    validation_rules: str | None = None,
) -> dict[str, Any]:
    """Load contract dict from explicit file paths.

    Args:
        schema: Path to schema file (YAML or JSON).
        coercion_rules: Optional path to coercion rules file.
        validation_rules: Optional path to validation rules file.

    Returns:
        Contract dictionary with 'schema', 'coercion_rules',
        'validation_rules' keys.

    Raises:
        FileNotFoundError: If schema file not found.
    """
    schema_path = Path(schema)
    if not schema_path.exists():
        raise FileNotFoundError(f"Schema file not found: {schema_path}")

    with open(schema_path) as f:
        schema_data = yaml.safe_load(f)

    coercion_data: dict[str, Any] = {}
    if coercion_rules:
        coercion_path = Path(coercion_rules)
        if coercion_path.exists():
            with open(coercion_path) as f:
                coercion_data = yaml.safe_load(f) or {}

    validation_data: dict[str, Any] = {}
    if validation_rules:
        validation_path = Path(validation_rules)
        if validation_path.exists():
            with open(validation_path) as f:
                validation_data = yaml.safe_load(f) or {}

    return {
        "schema": schema_data,
        "coercion_rules": coercion_data,
        "validation_rules": validation_data,
    }
