"""Documentation (MkDocs) CLI and helpers."""

from __future__ import annotations
