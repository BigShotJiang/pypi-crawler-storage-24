"""Code templates, type mapping, and field-definition helpers for model generation.

Provides JSON-Schema-to-Python type mapping, field definition construction,
array schema handling, and Python source file generation from schemas.
"""

from __future__ import annotations

import functools
import operator
from pathlib import Path
from typing import Any

from pydantic import Field

from pycharter.shared.json_schema_support import apply_json_schema_constraints


def _map_json_type_to_python(
    schema: dict[str, Any], field_name: str | None = None
) -> type[Any]:
    """Map JSON Schema type to Python type.

    Handles:
    - Single types: "number" -> float
    - Nullable types: ["number", "null"] -> float (Optional handled later)
    - Union types: ["string", "number"] -> [str, float]
    - Union + nullable: ["string", "number", "null"] -> [str, float]

    Args:
        schema: The schema for the field
        field_name: Optional field name for better error messages

    Returns:
        Python type corresponding to the JSON Schema type
    """
    schema_type = schema.get("type", "string")

    type_mapping: dict[str, type[Any]] = {
        "string": str,
        "integer": int,
        "number": float,
        "boolean": bool,
        "array": list,
        "object": dict,
    }

    # Handle array type (union types in JSON Schema Draft 2020-12)
    if isinstance(schema_type, list):
        # Filter out "null" - nullability is handled separately via Optional
        non_null_types = [t for t in schema_type if t != "null"]

        if not non_null_types:
            # All nulls (rare edge case)
            return type(None)
        elif len(non_null_types) == 1:
            # Single non-null type (nullable case: ["number", "null"])
            schema_type = non_null_types[0]
        else:
            # Multiple non-null types (union type: ["string", "number"])
            # Map each type and create a Union
            python_types = [type_mapping.get(t, str) for t in non_null_types]
            # Remove duplicates while preserving order
            unique_types: list[type[Any]] = []
            seen: set[type[Any]] = set()
            for t in python_types:
                if t not in seen:
                    unique_types.append(t)
                    seen.add(t)

            if len(unique_types) == 1:
                return unique_types[0]
            else:
                # Create union type via | operator
                return functools.reduce(operator.__or__, unique_types)  # type: ignore[return-value]

    # Handle single type
    if schema_type in type_mapping:
        return type_mapping[schema_type]

    # Handle null type (optional)
    if schema_type == "null":
        return type(None)

    # Default to string if type is unknown
    return str


def _get_default_value(schema: dict[str, Any]) -> Any:
    """Extract default value from schema if present.

    Args:
        schema: The schema dictionary

    Returns:
        Default value or ... (Ellipsis) if no default
    """
    if "default" in schema:
        return schema["default"]
    return ...


def _create_field_definition(
    schema: dict[str, Any], field_name: str, required: bool = True
) -> tuple[type[Any], Any]:
    """Create a Pydantic field definition from a JSON schema field.

    Applies standard JSON Schema constraints (minLength, maxLength, pattern,
    enum, etc.) and handles charter extensions (coercion, validations).

    Args:
        schema: The field schema
        field_name: Name of the field
        required: Whether the field is required

    Returns:
        Tuple of (type, Field or default value)
    """
    python_type = _map_json_type_to_python(schema, field_name)
    default_value = _get_default_value(schema)

    # Handle enum - use Literal type if enum is specified
    if "enum" in schema and len(schema["enum"]) > 0:
        from typing import Literal

        enum_values = schema["enum"]
        if len(enum_values) == 1:
            python_type = Literal[enum_values[0]]  # type: ignore[assignment]
        else:
            # Create union of literals
            python_type = Literal[tuple(enum_values)]  # type: ignore[assignment]

    # Handle const - single allowed value
    if "const" in schema:
        from typing import Literal

        python_type = Literal[schema["const"]]  # type: ignore[assignment]

    # Handle optional fields
    if not required or default_value is not ...:
        python_type = python_type | None  # type: ignore[assignment]
        if default_value is ...:
            default_value = None

    # Apply standard JSON Schema constraints
    field_kwargs = apply_json_schema_constraints(schema, field_name)

    if default_value is ...:
        # Required field, no default
        if field_kwargs:
            return (python_type, Field(**field_kwargs))
        return (python_type, ...)
    else:
        # Has default value
        if field_kwargs:
            return (python_type, Field(default=default_value, **field_kwargs))
        return (python_type, default_value)


def _process_array_schema(schema: dict[str, Any], model_name: str) -> type[Any]:
    """Process an array schema, handling nested objects.

    Args:
        schema: The array schema
        model_name: Base name for generating nested model names

    Returns:
        Python type for the array (list[item_type])
    """
    # Lazy import to avoid circular dependency with _generator_core
    from pycharter.pydantic_generator._generator_core import schema_to_model

    items_schema = schema.get("items", {})

    if isinstance(items_schema, dict) and items_schema.get("type") == "object":
        # Nested object in array - create a model for it
        item_model = schema_to_model(items_schema, f"{model_name}Item")
        return list[item_model]  # type: ignore[valid-type]

    # Simple array type
    item_type = _map_json_type_to_python(items_schema)
    return list[item_type]  # type: ignore[valid-type]


def _build_array_field(
    field_name: str,
    field_schema: dict[str, Any],
    model_name: str,
    required: bool,
    field_definitions: dict[str, tuple[type[Any], Any]],
) -> None:
    """Build a field definition for an array-typed field.

    Args:
        field_name: Name of the field.
        field_schema: JSON Schema for the field.
        model_name: Parent model name (used for nested model naming).
        required: Whether the field is required.
        field_definitions: Mutable dict to store the result.
    """
    array_type = _process_array_schema(
        field_schema, f"{model_name}{field_name.capitalize()}"
    )
    default_value = _get_default_value(field_schema)
    field_kwargs = apply_json_schema_constraints(field_schema, field_name)

    if not required or default_value is not ...:
        array_type = array_type | None  # type: ignore[assignment]
        if default_value is ...:
            default_value = []

    if field_kwargs:
        field_definitions[field_name] = (
            array_type,
            Field(
                default=default_value if default_value is not ... else ...,
                **field_kwargs,
            ),
        )
    else:
        field_definitions[field_name] = (
            array_type,
            default_value if default_value is not ... else ...,
        )


def _build_object_field(
    field_name: str,
    field_schema: dict[str, Any],
    model_name: str,
    required: bool,
    field_definitions: dict[str, tuple[type[Any], Any]],
) -> None:
    """Build a field definition for a nested-object field.

    Args:
        field_name: Name of the field.
        field_schema: JSON Schema for the field.
        model_name: Parent model name (used for nested model naming).
        required: Whether the field is required.
        field_definitions: Mutable dict to store the result.
    """
    # Lazy import to avoid circular dependency with _generator_core
    from pycharter.pydantic_generator._generator_core import schema_to_model

    nested_model = schema_to_model(
        field_schema, f"{model_name}{field_name.capitalize()}"
    )
    field_definitions[field_name] = _create_field_definition(
        {"type": "object"}, field_name, required
    )
    field_type_tuple = field_definitions[field_name]
    field_definitions[field_name] = (  # type: ignore[assignment]
        (nested_model | None) if not required else nested_model,
        field_type_tuple[1],
    )


def generate_model_file(
    schema: dict[str, Any],
    output_path: str,
    model_name: str = "DynamicModel",
    imports: list[str] | None = None,
) -> None:
    """Generate a Python file containing a Pydantic model from a JSON Schema.

    Args:
        schema: The JSON schema dictionary
        output_path: Path to the output Python file
        model_name: Name for the generated Pydantic model class
        imports: Optional list of additional import statements

    Example:
        >>> schema = {"type": "object", "properties": {"name": {"type": "string"}}}
        >>> generate_model_file(schema, "person_model.py", "Person")
    """
    from pycharter.pydantic_generator._generator_core import generate_model

    # Generate the model
    model = generate_model(schema, model_name)

    # Get model fields and their types
    fields: Any = {}
    if hasattr(model, "model_fields"):
        fields = model.model_fields  # type: ignore[assignment]
    elif hasattr(model, "__fields__"):
        fields = model.__fields__  # type: ignore[assignment]

    # Build Python code
    lines = [
        '"""',
        f"Generated Pydantic model: {model_name}",
        "Generated from JSON Schema",
        '"""',
        "",
        "from pydantic import BaseModel, Field",
        "from typing import Any",
    ]

    if imports:
        lines.extend(imports)

    lines.extend(
        [
            "",
            f"class {model_name}(BaseModel):",
            '    """',
            f"    {model_name} model generated from JSON Schema",
            '    """',
        ]
    )

    # Add field definitions
    for field_name, field_info in fields.items():
        # Get field type annotation
        if hasattr(field_info, "annotation"):
            field_type = field_info.annotation
        elif hasattr(field_info, "type_"):
            field_type = field_info.type_
        else:
            field_type = Any

        # Convert type to string representation
        type_str = str(field_type).replace("typing.", "")

        # Get default value
        default = "..."
        if hasattr(field_info, "default"):
            default_val = field_info.default
            if default_val is not ...:
                if default_val is None:
                    default = "None"
                elif isinstance(default_val, str):
                    default = f'"{default_val}"'
                else:
                    default = str(default_val)

        # Build field definition
        if default == "...":
            lines.append(f"    {field_name}: {type_str}")
        else:
            lines.append(f"    {field_name}: {type_str} = {default}")

    lines.append("")

    # Write to file
    path = Path(output_path)
    path.parent.mkdir(parents=True, exist_ok=True)

    with open(path, "w", encoding="utf-8") as f:
        f.write("\n".join(lines))
