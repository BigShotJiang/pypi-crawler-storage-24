"""Model generator module for creating Pydantic models from JSON schemas.

This module is a backward-compatible re-export shim. The actual
implementation lives in ``_generator_core`` and ``_generator_templates``.
"""

from __future__ import annotations

from pycharter.pydantic_generator._generator_core import generate_model, schema_to_model
from pycharter.pydantic_generator._generator_templates import generate_model_file

__all__ = ["generate_model", "generate_model_file", "schema_to_model"]
