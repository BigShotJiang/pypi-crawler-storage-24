"""Main generation logic for converting JSON schemas to Pydantic models.

Contains ``schema_to_model`` (the primary entry point) and ``generate_model``
(a convenience alias), plus the validator-wiring logic used during model
construction.
"""

from __future__ import annotations

import warnings
from typing import Any

from pydantic import BaseModel, ValidationInfo, create_model, field_validator

from pycharter.pydantic_generator._generator_templates import (
    _build_array_field,
    _build_object_field,
    _create_field_definition,
)
from pycharter.shared.coercions import get_coercion
from pycharter.shared.json_schema_support import (
    create_const_validator,
    create_enum_validator,
    create_pattern_validator,
    create_unique_items_validator,
)
from pycharter.shared.schema_resolver import normalize_schema_structure, resolve_refs
from pycharter.shared.validations import get_validation


def _build_x_validators(
    field_name: str,
    x_validators: list[Any],
    coercion_validators: dict[str, Any],
    validation_validators: dict[str, list[Any]],
) -> None:
    """Process x-validators extension and populate coercion/validation dicts.

    Args:
        field_name: Name of the field being processed.
        x_validators: List of validator spec dicts from the schema.
        coercion_validators: Mutable dict collecting coercion functions.
        validation_validators: Mutable dict collecting validation functions.
    """
    for validator_spec in x_validators:
        if not isinstance(validator_spec, dict):
            continue

        validator_name = validator_spec.get("name")
        is_pre = validator_spec.get("pre", False)
        params = validator_spec.get("params", {})

        if is_pre:
            _add_coercion(field_name, validator_name, coercion_validators)
        else:
            _add_x_validation(field_name, validator_name, params, validation_validators)


def _add_coercion(
    field_name: str,
    coercion_name: str | None,
    coercion_validators: dict[str, Any],
) -> None:
    """Resolve a coercion by name and store it in *coercion_validators*."""
    try:
        coercion_func = get_coercion(coercion_name)  # type: ignore[arg-type]
        coercion_validators[field_name] = coercion_func
    except ValueError as exc:
        warnings.warn(
            f"Unknown coercion '{coercion_name}' for field '{field_name}': {exc}",
            stacklevel=3,
        )


def _add_x_validation(
    field_name: str,
    validator_name: str | None,
    params: dict[str, Any],
    validation_validators: dict[str, list[Any]],
) -> None:
    """Resolve a single x-validator spec and append to *validation_validators*."""
    # Handle special regex case
    if validator_name == "matches_regex":
        pattern = params.get("pattern", "")
        if pattern:
            validation_func = create_pattern_validator(pattern)
            validation_validators.setdefault(field_name, []).append(validation_func)
        return

    try:
        validation_factory = get_validation(validator_name)  # type: ignore[arg-type]
        validation_func = _call_validation_factory(
            validator_name,
            validation_factory,
            params,  # type: ignore[arg-type]
        )
        validation_validators.setdefault(field_name, []).append(validation_func)
    except ValueError as exc:
        warnings.warn(
            f"Unknown validation '{validator_name}' for field '{field_name}': {exc}",
            stacklevel=3,
        )


def _call_validation_factory(name: str, factory: Any, config: dict[str, Any]) -> Any:
    """Invoke a validation factory with the correct arguments.

    Args:
        name: Registered validation name.
        factory: The factory callable returned by ``get_validation``.
        config: Parameter dict from the schema.

    Returns:
        A validation callable.
    """
    if name in ["min_length", "max_length"]:
        threshold = config.get("threshold", config.get("value", 0))
        return factory(threshold)
    if name == "only_allow":
        allowed_values = config.get("allowed_values", config.get("value", []))
        return factory(allowed_values)
    if name in ["greater_than_or_equal_to", "less_than_or_equal_to", "is_positive"]:
        threshold = config.get("threshold", config.get("value", 0))
        return factory(threshold)
    if name == "matches_regex":
        pattern = config.get("pattern", "")
        return factory(pattern)
    # No-arg validations (non_empty_string, no_capital_characters, is_email, etc.)
    return factory()


def _build_charter_validations(
    field_name: str,
    validations: dict[str, Any],
    validation_validators: dict[str, list[Any]],
) -> None:
    """Process charter-extension ``validations`` block on a field.

    Args:
        field_name: Name of the field being processed.
        validations: Dict of validation_name -> config from the schema.
        validation_validators: Mutable dict collecting validation functions.
    """
    if not isinstance(validations, dict):
        return

    for validation_name, validation_config in validations.items():
        # Handle special regex case
        if validation_name == "matches_regex":
            if isinstance(validation_config, dict):
                pattern = validation_config.get("pattern", "")
            else:
                pattern = str(validation_config) if validation_config else ""
            if pattern:
                validation_func = create_pattern_validator(pattern)
                validation_validators.setdefault(field_name, []).append(validation_func)
            continue

        try:
            validation_factory = get_validation(validation_name)
            # Normalise config to a dict
            if validation_config is None:
                validation_config = {}
            elif not isinstance(validation_config, dict):
                validation_config = {"value": validation_config}

            validation_func = _call_validation_factory(
                validation_name, validation_factory, validation_config
            )
            validation_validators.setdefault(field_name, []).append(validation_func)
        except ValueError as exc:
            warnings.warn(
                f"Unknown validation '{validation_name}' for "
                f"field '{field_name}': {exc}",
                stacklevel=2,
            )


def _attach_validators(
    field_definitions: dict[str, tuple[type[Any], Any]],
    coercion_validators: dict[str, Any],
    validation_validators: dict[str, list[Any]],
    model_name: str,
) -> type[BaseModel]:
    """Create the final Pydantic model, attaching coercion/validation validators.

    Args:
        field_definitions: Mapping of field name to (type, default/Field).
        coercion_validators: Pre-validators keyed by field name.
        validation_validators: Post-validators keyed by field name.
        model_name: Name for the generated model class.

    Returns:
        A dynamically-created Pydantic model class.
    """
    class_dict: dict[str, Any] = {}

    # Add coercion validators (mode='before')
    for field_name, coercion_func in coercion_validators.items():

        def make_coercion_validator(field: str, func: Any):
            @field_validator(field, mode="before")  # type: ignore[misc]
            @classmethod  # type: ignore[misc]
            def _coerce_field(cls, value: Any) -> Any:
                if value is None:
                    return value
                return func(value)

            return _coerce_field

        class_dict[f"_coerce_{field_name}"] = make_coercion_validator(
            field_name, coercion_func
        )

    # Add validation validators (mode='after')
    for field_name, validation_funcs in validation_validators.items():
        for idx, validation_func in enumerate(validation_funcs):

            def make_validation_validator(field: str, func: Any):
                @field_validator(field, mode="after")  # type: ignore[misc]
                @classmethod  # type: ignore[misc]
                def _validate_field(cls, value: Any, info: ValidationInfo) -> Any:
                    return func(value, info)

                return _validate_field

            class_dict[f"_validate_{field_name}_{idx}"] = make_validation_validator(
                field_name, validation_func
            )

    if class_dict:
        base_model = create_model(model_name, **field_definitions)  # type: ignore[call-overload]
        return type(model_name, (base_model,), class_dict)

    return create_model(model_name, **field_definitions)  # type: ignore[call-overload]


def schema_to_model(
    schema: dict[str, Any], model_name: str = "DynamicModel"
) -> type[BaseModel]:
    """Convert a JSON schema to a Pydantic model.

    Args:
        schema: The JSON schema dictionary
        model_name: Name for the generated Pydantic model class

    Returns:
        A Pydantic model class generated from the schema

    Example:
        >>> schema = {
        ...     "type": "object",
        ...     "properties": {
        ...         "name": {"type": "string"},
        ...         "age": {"type": "integer"}
        ...     },
        ...     "required": ["name"]
        ... }
        >>> Model = schema_to_model(schema, "Person")
        >>> person = Model(name="Alice", age=30)
        >>> person.name
        'Alice'
    """
    from pycharter.shared.schema_parser import (
        get_schema_type,
        is_required,
        normalize_schema,
        validate_schema,
    )

    # Validate and normalize schema
    validate_schema(schema)
    schema = normalize_schema(schema)
    schema = normalize_schema_structure(schema)
    schema = resolve_refs(schema)

    schema_type = get_schema_type(schema)
    if schema_type != "object":
        raise ValueError(
            f"Schema must be of type 'object' to create a model. Got '{schema_type}'"
        )

    properties = schema.get("properties", {})
    if not properties:
        return create_model(model_name)

    # Collect field definitions and validators
    field_definitions: dict[str, tuple[type[Any], Any]] = {}
    coercion_validators: dict[str, Any] = {}
    validation_validators: dict[str, list[Any]] = {}

    for field_name, field_schema in properties.items():
        if not isinstance(field_schema, dict):
            continue

        required = is_required(field_name, schema)
        field_type = field_schema.get("type")

        # x-validators extension (array of validator objects)
        x_validators = field_schema.get("x-validators", [])
        if x_validators and isinstance(x_validators, list):
            _build_x_validators(
                field_name, x_validators, coercion_validators, validation_validators
            )

        # coercion extension (original format)
        coercion_name = field_schema.get("coercion")
        if coercion_name:
            _add_coercion(field_name, coercion_name, coercion_validators)

        # Standard JSON Schema enum constraint
        if "enum" in field_schema and len(field_schema["enum"]) > 0:
            validation_validators.setdefault(field_name, []).append(
                create_enum_validator(field_schema["enum"])
            )

        # Standard JSON Schema const constraint
        if "const" in field_schema:
            validation_validators.setdefault(field_name, []).append(
                create_const_validator(field_schema["const"])
            )

        # Standard JSON Schema pattern constraint
        if "pattern" in field_schema:
            validation_validators.setdefault(field_name, []).append(
                create_pattern_validator(field_schema["pattern"])
            )

        # Standard JSON Schema uniqueItems constraint
        if field_type == "array" and field_schema.get("uniqueItems") is True:
            validation_validators.setdefault(field_name, []).append(
                create_unique_items_validator
            )

        # Charter validations extension
        validations = field_schema.get("validations", {})
        if validations:
            _build_charter_validations(field_name, validations, validation_validators)

        # Build the field definition based on type
        if field_type == "array":
            _build_array_field(
                field_name, field_schema, model_name, required, field_definitions
            )
        elif field_type == "object":
            _build_object_field(
                field_name, field_schema, model_name, required, field_definitions
            )
        else:
            field_definitions[field_name] = _create_field_definition(
                field_schema, field_name, required
            )

    return _attach_validators(
        field_definitions, coercion_validators, validation_validators, model_name
    )


def generate_model(
    schema: dict[str, Any], model_name: str = "DynamicModel"
) -> type[BaseModel]:
    """Generate a Pydantic model from a JSON Schema.

    This is an alias for schema_to_model for consistency with the service API.

    Args:
        schema: The JSON schema dictionary
        model_name: Name for the generated Pydantic model class

    Returns:
        A Pydantic model class
    """
    return schema_to_model(schema, model_name)
