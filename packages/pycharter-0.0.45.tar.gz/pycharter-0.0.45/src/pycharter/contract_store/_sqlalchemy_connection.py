"""SQLAlchemy connection management, engine setup, and schema initialization.

Provides ``_SQLAlchemyConnectionMixin`` with engine/session lifecycle,
schema validation, and internal helpers used by the CRUD layer in
``_sqlalchemy_crud``.

This module is internal -- import the public stores from
``pycharter.contract_store``.
"""

from __future__ import annotations

import json
import logging
from typing import Any

from sqlalchemy import inspect
from sqlalchemy.orm import Session, sessionmaker

from pycharter.contract_store.client import ContractStoreClient
from pycharter.db.models.base import Base, get_engine
from pycharter.db.models.coercion_rule import CoercionRuleModel
from pycharter.db.models.data_contract import DataContractModel
from pycharter.db.models.metadata_record import MetadataRecordModel
from pycharter.db.models.schema import SchemaModel
from pycharter.db.models.validation_rule import ValidationRuleModel

logger = logging.getLogger(__name__)


class _SQLAlchemyConnectionMixin(ContractStoreClient):
    """Engine / session lifecycle and schema helpers for SQLAlchemy stores.

    Subclasses must:
    1. Validate the connection string in ``__init__``.
    2. Implement ``connect()`` and call ``_connect_engine()`` with the
       appropriate ``schema_name``.
    """

    def __init__(self, connection_string: str) -> None:
        super().__init__(connection_string)
        self._engine: Any = None
        self._session: Session | None = None
        self._schema_name: str | None = None

    # ------------------------------------------------------------------
    # Engine / session lifecycle
    # ------------------------------------------------------------------

    def _connect_engine(
        self,
        schema_name: str | None,
        *,
        validate_schema: bool = True,
        auto_initialize: bool = False,
    ) -> None:
        """Create engine, session, and optionally validate / create tables.

        Args:
            schema_name: Database schema to inspect (``None`` for SQLite,
                ``"pycharter"`` for PostgreSQL).
            validate_schema: Check that required tables exist.
            auto_initialize: Create tables if they are missing.
        """
        self._schema_name = schema_name
        self._engine = get_engine(self.connection_string)  # type: ignore[arg-type]
        factory = sessionmaker(bind=self._engine)
        self._session = factory()
        self._connection = self._session

        if validate_schema and not self._is_schema_initialized():
            if auto_initialize:
                self._initialize_schema()
            else:
                raise RuntimeError(
                    "Database schema is not initialized. "
                    "Please run 'pycharter db init' to initialize the schema first.\n"
                    f"Example: pycharter db init {self.connection_string}"
                )

    def disconnect(self) -> None:
        """Close session and dispose engine."""
        if self._session is not None:
            self._session.close()
            self._session = None
        if self._engine is not None:
            self._engine.dispose()
            self._engine = None
        self._connection = None

    # ------------------------------------------------------------------
    # Schema helpers
    # ------------------------------------------------------------------

    def _is_schema_initialized(self) -> bool:
        """Check whether the ``schemas`` table exists."""
        if self._engine is None:
            return False
        try:
            insp = inspect(self._engine)
            tables = insp.get_table_names(schema=self._schema_name)
            return "schemas" in tables
        except Exception:
            return False

    #: Tables required by the contract store.  Avoids creating semantic tables
    #: that use PostgreSQL-specific types (JSONB) unsupported on SQLite.
    _CORE_TABLES = [
        DataContractModel.__table__,
        SchemaModel.__table__,
        MetadataRecordModel.__table__,
        CoercionRuleModel.__table__,
        ValidationRuleModel.__table__,
    ]

    def _initialize_schema(self) -> None:
        """Create core metadata tables from SQLAlchemy models."""
        try:
            Base.metadata.create_all(self._engine, tables=self._CORE_TABLES)
        except Exception as exc:
            raise RuntimeError(f"Failed to initialize schema: {exc}") from exc

    def get_schema_info(self) -> dict[str, Any]:
        """Get information about the current database schema."""
        self._require_connection()
        initialized = self._is_schema_initialized()
        revision: str | None = None

        if initialized:
            try:
                insp = inspect(self._engine)
                tables = insp.get_table_names(schema=self._schema_name)
                if "alembic_version" in tables:
                    from sqlalchemy import text

                    result = self._session.execute(  # type: ignore[union-attr]
                        text("SELECT version_num FROM alembic_version LIMIT 1")
                    )
                    row = result.fetchone()
                    if row:
                        revision = row[0]
            except Exception:
                logger.debug("Failed to retrieve alembic revision", exc_info=True)

        message = f"Schema initialized: {initialized}"
        if revision:
            message += f" (revision: {revision})"

        return {
            "revision": revision,
            "initialized": initialized,
            "message": message,
        }

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _get_session(self) -> Session:
        """Return the active session, raising if not connected."""
        self._require_connection()
        assert self._session is not None  # noqa: S101
        return self._session

    def _get_or_create_data_contract(
        self,
        contract_name: str,
        version: str,
        status: str = "active",
        description: str | None = None,
    ) -> str:
        """Get or create a data_contract. Returns data contract ID string."""
        from pycharter.shared.name_validator import validate_name

        contract_name = validate_name(contract_name, field_name="contract_name")
        session = self._get_session()
        row = (
            session.query(DataContractModel)
            .filter(
                DataContractModel.name == contract_name,
                DataContractModel.version == version,
            )
            .first()
        )
        if row:
            return str(row.id)
        new_dc = DataContractModel(
            name=contract_name,
            version=version,
            status=status,
            description=description,
        )
        session.add(new_dc)
        session.flush()
        return str(new_dc.id)

    def _resolve_data_contract(
        self, contract_name: str, contract_version: str
    ) -> dict[str, Any] | None:
        """Resolve (contract_name, contract_version) to data_contract row."""
        session = self._get_session()
        row = (
            session.query(DataContractModel)
            .filter(
                DataContractModel.name == contract_name,
                DataContractModel.version == contract_version,
            )
            .first()
        )
        if not row:
            return None
        return {
            "id": str(row.id),
            "schema_id": str(row.schema_id) if row.schema_id else None,
            "coercion_rules_id": (
                str(row.coercion_rules_id) if row.coercion_rules_id else None
            ),
            "validation_rules_id": (
                str(row.validation_rules_id) if row.validation_rules_id else None
            ),
            "metadata_record_id": (
                str(row.metadata_record_id) if row.metadata_record_id else None
            ),
            "field_mapping_id": (
                str(row.field_mapping_id) if row.field_mapping_id else None
            ),
        }

    def _require_contract_with_schema(
        self, contract_name: str, contract_version: str
    ) -> tuple[str, str]:
        """Resolve contract and ensure it has a schema. Returns (contract_id, schema_id)."""
        row = self._resolve_data_contract(contract_name, contract_version)
        if not row:
            raise ValueError(
                f"Data contract not found: {contract_name!r} @ {contract_version!r}. "
                "Store the schema first."
            )
        schema_id = row.get("schema_id")
        if not schema_id:
            raise ValueError(
                f"Data contract {contract_name!r} @ {contract_version!r} has no schema. "
                "Store the schema first."
            )
        return row["id"], schema_id

    @staticmethod
    def _get_rules_json(obj: Any) -> dict[str, Any] | None:
        """Extract rules dict from a CoercionRuleModel or ValidationRuleModel."""
        if not obj:
            return None
        rules = obj.rules
        if isinstance(rules, str):
            return json.loads(rules)
        return rules
