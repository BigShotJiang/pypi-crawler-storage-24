"""MongoDB coercion/validation rules operations and schema info.

Implements store/get for coercion rules and validation rules,
schema info retrieval, and internal by-ID lookup helpers.
"""

from __future__ import annotations

from typing import Any

from pycharter.contract_store._mongodb_operations import MongoDBOperationsMixin


class MongoDBQueriesMixin(MongoDBOperationsMixin):
    """Mixin providing rules operations and schema info for MongoDB.

    Builds on ``MongoDBOperationsMixin`` (schema/metadata ops) and implements
    coercion rules, validation rules, and schema info methods.

    This is not meant to be instantiated directly. Use
    ``MongoDBContractStore`` from ``pycharter.contract_store.mongodb``.
    """

    # ------------------------------------------------------------------
    # Coercion rules operations
    # ------------------------------------------------------------------

    def store_coercion_rules(
        self,
        contract_name: str,
        contract_version: str,
        coercion_rules: dict[str, Any],
    ) -> str:
        """Store coercion rules for the given data contract.

        Contract must have a schema.
        """
        row = self._resolve_data_contract(contract_name, contract_version)
        if not row:
            raise ValueError(
                f"Data contract not found: {contract_name!r} @ "
                f"{contract_version!r}. Store the schema first."
            )
        data_contract_id = row["id"]
        schema_id = row.get("schema_id")
        if not schema_id:
            raise ValueError(
                f"Data contract {contract_name!r} @ {contract_version!r} "
                "has no schema. Store the schema first."
            )

        from bson import ObjectId

        from pycharter.shared.name_validator import normalize_name, validate_name

        title = (
            normalize_name(f"{contract_name}_coercion_rules")
            or normalize_name(f"{contract_name}_coercion")
            or "coercion_rules"
        )
        title = validate_name(title, field_name="coercion_rules.title")
        version = contract_version

        existing = self._db.coercion_rules.find_one(
            {"title": title, "version": version}
        )
        if existing:
            rule_id = existing["_id"]
            self._db.coercion_rules.update_one(
                {"_id": rule_id},
                {
                    "$set": {
                        "rules": coercion_rules,
                        "title": title,
                        "schema_id": schema_id,
                    }
                },
            )
        else:
            rule_id = ObjectId()
            self._db.coercion_rules.insert_one(
                {
                    "_id": rule_id,
                    "title": title,
                    "data_contract_id": data_contract_id,
                    "version": version,
                    "rules": coercion_rules,
                    "schema_id": schema_id,
                }
            )
        self._db.data_contracts.update_one(
            {"_id": data_contract_id},
            {"$set": {"coercion_rules_id": rule_id}},
        )
        return str(rule_id)

    def get_coercion_rules(
        self, contract_name: str, contract_version: str
    ) -> dict[str, Any] | None:
        """Retrieve coercion rules for the given data contract."""
        row = self._resolve_data_contract(contract_name, contract_version)
        if not row or not row.get("coercion_rules_id"):
            return None
        return self._get_coercion_rules_by_id(row["coercion_rules_id"])

    # ------------------------------------------------------------------
    # Validation rules operations
    # ------------------------------------------------------------------

    def store_validation_rules(
        self,
        contract_name: str,
        contract_version: str,
        validation_rules: dict[str, Any],
    ) -> str:
        """Store validation rules for the given data contract.

        Contract must have a schema.
        """
        row = self._resolve_data_contract(contract_name, contract_version)
        if not row:
            raise ValueError(
                f"Data contract not found: {contract_name!r} @ "
                f"{contract_version!r}. Store the schema first."
            )
        data_contract_id = row["id"]
        schema_id = row.get("schema_id")
        if not schema_id:
            raise ValueError(
                f"Data contract {contract_name!r} @ {contract_version!r} "
                "has no schema. Store the schema first."
            )

        from bson import ObjectId

        from pycharter.shared.name_validator import normalize_name, validate_name

        title = (
            normalize_name(f"{contract_name}_validation_rules")
            or normalize_name(f"{contract_name}_validation")
            or "validation_rules"
        )
        title = validate_name(title, field_name="validation_rules.title")
        version = contract_version

        existing = self._db.validation_rules.find_one(
            {"title": title, "version": version}
        )
        if existing:
            rule_id = existing["_id"]
            self._db.validation_rules.update_one(
                {"_id": rule_id},
                {
                    "$set": {
                        "rules": validation_rules,
                        "title": title,
                        "schema_id": schema_id,
                    }
                },
            )
        else:
            rule_id = ObjectId()
            self._db.validation_rules.insert_one(
                {
                    "_id": rule_id,
                    "title": title,
                    "data_contract_id": data_contract_id,
                    "version": version,
                    "rules": validation_rules,
                    "schema_id": schema_id,
                }
            )
        self._db.data_contracts.update_one(
            {"_id": data_contract_id},
            {"$set": {"validation_rules_id": rule_id}},
        )
        return str(rule_id)

    def get_validation_rules(
        self, contract_name: str, contract_version: str
    ) -> dict[str, Any] | None:
        """Retrieve validation rules for the given data contract."""
        row = self._resolve_data_contract(contract_name, contract_version)
        if not row or not row.get("validation_rules_id"):
            return None
        return self._get_validation_rules_by_id(row["validation_rules_id"])

    # ------------------------------------------------------------------
    # Schema info
    # ------------------------------------------------------------------

    def get_schema_info(self) -> dict[str, Any]:
        """Get information about the current database schema.

        Returns:
            Dictionary with schema information including revision,
            initialized status, and human-readable message.
        """
        if self._db is None:
            raise RuntimeError("Not connected. Call connect() first.")

        # Check if collections exist (equivalent to "initialized")
        collection_names = self._db.list_collection_names()
        initialized = (
            "data_contracts" in collection_names and "schemas" in collection_names
        )

        # MongoDB doesn't have migrations like Postgres, so no revision
        revision = None

        return {
            "revision": revision,
            "initialized": initialized,
            "message": f"Schema initialized: {initialized}"
            + (f" (revision: {revision})" if revision else ""),
        }

    # ------------------------------------------------------------------
    # Internal by-ID lookups
    # ------------------------------------------------------------------

    def _get_coercion_rules_by_id(
        self, coercion_rules_id: Any
    ) -> dict[str, Any] | None:
        """Load coercion rules by _id (internal use)."""
        if self._db is None:
            raise RuntimeError("Not connected. Call connect() first.")

        from bson import ObjectId

        try:
            rule_obj_id: Any = ObjectId(coercion_rules_id)
        except Exception:
            rule_obj_id = coercion_rules_id

        doc = self._db.coercion_rules.find_one({"_id": rule_obj_id})
        if doc:
            return doc.get("rules")
        return None

    def _get_validation_rules_by_id(
        self, validation_rules_id: Any
    ) -> dict[str, Any] | None:
        """Load validation rules by _id (internal use)."""
        if self._db is None:
            raise RuntimeError("Not connected. Call connect() first.")

        from bson import ObjectId

        try:
            rule_obj_id: Any = ObjectId(validation_rules_id)
        except Exception:
            rule_obj_id = validation_rules_id

        doc = self._db.validation_rules.find_one({"_id": rule_obj_id})
        if doc:
            return doc.get("rules")
        return None
