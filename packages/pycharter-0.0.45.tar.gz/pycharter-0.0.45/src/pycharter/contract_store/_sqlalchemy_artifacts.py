"""SQLAlchemy CRUD operations for contract artifacts (metadata, rules, mappings).

Provides ``_SQLAlchemyArtifactsMixin`` used by ``_SQLAlchemyContractStoreBase``
in ``_sqlalchemy_crud``.  All methods assume that session and helper methods
(``_get_session``, ``_resolve_data_contract``, etc.) are provided by
``_SQLAlchemyConnectionMixin``.

Internal module -- import the public stores from ``pycharter.contract_store``.
"""

from __future__ import annotations

import json
import logging
import uuid
from typing import TYPE_CHECKING, Any

from pycharter.db.models.coercion_rule import CoercionRuleModel
from pycharter.db.models.data_contract import DataContractModel
from pycharter.db.models.field_mapping import FieldMappingModel
from pycharter.db.models.metadata_record import MetadataRecordModel
from pycharter.db.models.validation_rule import ValidationRuleModel

if TYPE_CHECKING:
    from pycharter.contract_store._sqlalchemy_connection import (
        _SQLAlchemyConnectionMixin,
    )

logger = logging.getLogger(__name__)


class _SQLAlchemyArtifactsMixin:
    """Mixin with CRUD operations for metadata, coercion/validation rules, and field mappings.

    Designed to be mixed into a class that also inherits from
    ``_SQLAlchemyConnectionMixin``, which provides ``_get_session``,
    ``_resolve_data_contract``, ``_require_contract_with_schema``, and
    ``_get_rules_json``.
    """

    # Type stubs so mypy understands the connection-mixin helpers.
    if TYPE_CHECKING:
        _get_session: _SQLAlchemyConnectionMixin._get_session  # type: ignore[assignment]
        _resolve_data_contract: _SQLAlchemyConnectionMixin._resolve_data_contract  # type: ignore[assignment]
        _require_contract_with_schema: (
            _SQLAlchemyConnectionMixin._require_contract_with_schema
        )  # type: ignore[assignment]
        _get_rules_json: _SQLAlchemyConnectionMixin._get_rules_json  # type: ignore[assignment,name-defined]

    # -- metadata -----------------------------------------------------------

    def store_metadata(
        self,
        contract_name: str,
        contract_version: str,
        metadata: dict[str, Any],
    ) -> str:
        """Store metadata for the given data contract."""
        row = self._resolve_data_contract(contract_name, contract_version)
        if not row:
            raise ValueError(
                f"Data contract not found: {contract_name!r} @ {contract_version!r}. "
                "Store the schema first."
            )
        data_contract_id = row["id"]
        session = self._get_session()

        from pycharter.db.metadata_normalizer import ensure_canonical
        from pycharter.shared.name_validator import normalize_name, validate_name

        canonical = ensure_canonical(metadata)
        title = canonical.get("title")
        if not title:
            title = (
                normalize_name(f"metadata_for_{contract_name}_{contract_version}")
                or "metadata"
            )
        normalized_title = normalize_name(str(title))
        if not normalized_title:
            raise ValueError(
                f"metadata.title '{title}' cannot be normalized to a valid name."
            )
        title = validate_name(normalized_title, field_name="metadata.title")
        version = contract_version

        # Check for duplicate
        existing = (
            session.query(MetadataRecordModel)
            .filter(
                MetadataRecordModel.title == title,
                MetadataRecordModel.version == version,
            )
            .first()
        )
        if existing:
            raise ValueError(
                f"Metadata with title '{title}' and version '{version}' already exists."
            )

        meta_obj = MetadataRecordModel(
            title=title,
            data_contract_id=uuid.UUID(data_contract_id),
            version=version,
            status=canonical.get("status", "active"),
            type=canonical.get("type"),
            description=canonical.get("description"),
            governance_rules=canonical.get("governance_rules"),
            payload=canonical if canonical else None,
        )
        session.add(meta_obj)
        session.flush()

        # Update data_contract.metadata_record_id
        dc = session.query(DataContractModel).get(uuid.UUID(data_contract_id))
        if dc:
            dc.metadata_record_id = meta_obj.id
        session.commit()
        return str(meta_obj.id)

    def get_metadata(
        self, contract_name: str, contract_version: str
    ) -> dict[str, Any] | None:
        """Retrieve metadata for the given data contract."""
        row = self._resolve_data_contract(contract_name, contract_version)
        if not row or not row.get("metadata_record_id"):
            return None
        return self._get_metadata_by_id(row["metadata_record_id"])

    def _get_metadata_by_id(self, metadata_id: str) -> dict[str, Any] | None:
        """Load metadata by id."""
        session = self._get_session()
        row = session.query(MetadataRecordModel).get(uuid.UUID(metadata_id))
        if not row:
            return None
        # Prefer payload if available.
        if row.payload:
            payload = row.payload
            if isinstance(payload, str):
                try:
                    data = json.loads(payload)
                    if isinstance(data, dict) and data:
                        return data
                except (json.JSONDecodeError, TypeError):
                    pass
            elif isinstance(payload, dict) and payload:
                return payload
        # Fallback: reconstruct from columns.
        out: dict[str, Any] = {
            "title": row.title,
            "version": row.version,
            "status": row.status,
            "type": row.type,
            "description": row.description,
            "ownership": {},
            "lineage": {},
        }
        if row.governance_rules:
            gov = row.governance_rules
            if isinstance(gov, str):
                try:
                    out["governance_rules"] = json.loads(gov)
                except (json.JSONDecodeError, TypeError):
                    pass
            else:
                out["governance_rules"] = gov
        return out

    # -- coercion rules -----------------------------------------------------

    def store_coercion_rules(
        self,
        contract_name: str,
        contract_version: str,
        coercion_rules: dict[str, Any],
    ) -> str:
        """Store coercion rules for the given data contract."""
        data_contract_id, schema_id = self._require_contract_with_schema(
            contract_name, contract_version
        )
        session = self._get_session()

        from pycharter.shared.name_validator import normalize_name, validate_name

        title = (
            normalize_name(f"{contract_name}_coercion_rules")
            or normalize_name(f"{contract_name}_coercion")
            or "coercion_rules"
        )
        title = validate_name(title, field_name="coercion_rules.title")

        existing = (
            session.query(CoercionRuleModel)
            .filter(
                CoercionRuleModel.title == title,
                CoercionRuleModel.version == contract_version,
            )
            .first()
        )
        if existing:
            raise ValueError(
                f"Coercion rules with title '{title}' and version "
                f"'{contract_version}' already exist."
            )

        rule_obj = CoercionRuleModel(
            title=title,
            data_contract_id=uuid.UUID(data_contract_id),
            version=contract_version,
            rules=coercion_rules,
            schema_id=uuid.UUID(schema_id),
        )
        session.add(rule_obj)
        session.flush()

        dc = session.query(DataContractModel).get(uuid.UUID(data_contract_id))
        if dc:
            dc.coercion_rules_id = rule_obj.id
        session.commit()
        return str(rule_obj.id)

    def get_coercion_rules(
        self, contract_name: str, contract_version: str
    ) -> dict[str, Any] | None:
        """Retrieve coercion rules for the given data contract."""
        row = self._resolve_data_contract(contract_name, contract_version)
        if not row or not row.get("coercion_rules_id"):
            return None
        session = self._get_session()
        obj = session.query(CoercionRuleModel).get(uuid.UUID(row["coercion_rules_id"]))
        return self._get_rules_json(obj)

    # -- validation rules ---------------------------------------------------

    def store_validation_rules(
        self,
        contract_name: str,
        contract_version: str,
        validation_rules: dict[str, Any],
    ) -> str:
        """Store validation rules for the given data contract."""
        data_contract_id, schema_id = self._require_contract_with_schema(
            contract_name, contract_version
        )
        session = self._get_session()

        from pycharter.shared.name_validator import normalize_name, validate_name

        title = (
            normalize_name(f"{contract_name}_validation_rules")
            or normalize_name(f"{contract_name}_validation")
            or "validation_rules"
        )
        title = validate_name(title, field_name="validation_rules.title")

        existing = (
            session.query(ValidationRuleModel)
            .filter(
                ValidationRuleModel.title == title,
                ValidationRuleModel.version == contract_version,
            )
            .first()
        )
        if existing:
            raise ValueError(
                f"Validation rules with title '{title}' and version "
                f"'{contract_version}' already exist."
            )

        rule_obj = ValidationRuleModel(
            title=title,
            data_contract_id=uuid.UUID(data_contract_id),
            version=contract_version,
            rules=validation_rules,
            schema_id=uuid.UUID(schema_id),
        )
        session.add(rule_obj)
        session.flush()

        dc = session.query(DataContractModel).get(uuid.UUID(data_contract_id))
        if dc:
            dc.validation_rules_id = rule_obj.id
        session.commit()
        return str(rule_obj.id)

    def get_validation_rules(
        self, contract_name: str, contract_version: str
    ) -> dict[str, Any] | None:
        """Retrieve validation rules for the given data contract."""
        row = self._resolve_data_contract(contract_name, contract_version)
        if not row or not row.get("validation_rules_id"):
            return None
        session = self._get_session()
        obj = session.query(ValidationRuleModel).get(
            uuid.UUID(row["validation_rules_id"])
        )
        return self._get_rules_json(obj)

    # -- field mapping ------------------------------------------------------

    def store_field_mapping(
        self,
        contract_name: str,
        contract_version: str,
        field_mapping: dict[str, Any],
    ) -> str:
        """Store field mapping for the given data contract."""
        row = self._resolve_data_contract(contract_name, contract_version)
        if not row:
            raise ValueError(
                f"Data contract not found: {contract_name!r} @ {contract_version!r}. "
                "Store the schema first."
            )
        data_contract_id = row["id"]
        session = self._get_session()

        from pycharter.shared.name_validator import normalize_name, validate_name

        title = normalize_name(f"{contract_name}_field_mapping") or "field_mapping"
        title = validate_name(title, field_name="field_mapping.title")

        existing = (
            session.query(FieldMappingModel)
            .filter(
                FieldMappingModel.title == title,
                FieldMappingModel.version == contract_version,
            )
            .first()
        )
        if existing:
            raise ValueError(
                f"Field mapping with title '{title}' and version "
                f"'{contract_version}' already exists."
            )

        mapping_obj = FieldMappingModel(
            title=title,
            data_contract_id=uuid.UUID(data_contract_id),
            version=contract_version,
            mapping_data=field_mapping,
        )
        session.add(mapping_obj)
        session.flush()

        dc = session.query(DataContractModel).get(uuid.UUID(data_contract_id))
        if dc:
            dc.field_mapping_id = mapping_obj.id
        session.commit()
        return str(mapping_obj.id)

    def get_field_mapping(
        self, contract_name: str, contract_version: str
    ) -> dict[str, Any] | None:
        """Retrieve field mapping for the given data contract."""
        row = self._resolve_data_contract(contract_name, contract_version)
        if not row or not row.get("field_mapping_id"):
            return None
        session = self._get_session()
        obj = session.query(FieldMappingModel).get(uuid.UUID(row["field_mapping_id"]))
        if not obj:
            return None
        data = obj.mapping_data
        if isinstance(data, str):
            return json.loads(data)
        return data
