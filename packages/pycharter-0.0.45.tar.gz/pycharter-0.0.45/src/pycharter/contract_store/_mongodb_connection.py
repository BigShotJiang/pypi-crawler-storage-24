"""MongoDB connection management and index creation.

Handles client lifecycle (connect/disconnect) and ensures indexes exist
for all MongoDB collections used by the contract store.
"""

from __future__ import annotations

from typing import Any

try:
    from pymongo import MongoClient  # type: ignore[import-untyped]
    from pymongo.collection import Collection  # type: ignore[import-untyped]
    from pymongo.database import Database  # type: ignore[import-untyped]

    MONGO_AVAILABLE = True
except ImportError:
    MONGO_AVAILABLE = False
    MongoClient = None  # type: ignore[assignment,misc]
    Collection = None  # type: ignore[assignment,misc]
    Database = None  # type: ignore[assignment,misc]

from pycharter.contract_store.client import ContractStoreClient


class MongoDBConnectionMixin(ContractStoreClient):
    """Mixin providing MongoDB connection management and index creation.

    Handles:
    - Client initialization with connection string validation
    - ``connect()`` / ``disconnect()`` lifecycle
    - Index creation for all contract store collections

    This is not meant to be instantiated directly. Use
    ``MongoDBContractStore`` from ``pycharter.contract_store.mongodb``.
    """

    def __init__(
        self,
        connection_string: str | None = None,
        database_name: str = "pycharter",
    ):
        """Initialize MongoDB contract store connection parameters.

        Args:
            connection_string: MongoDB connection string.
            database_name: Database name (default: "pycharter").
        """
        if not MONGO_AVAILABLE:
            raise ImportError(
                "pymongo is required for MongoDBContractStore. "
                "Install with: pip install pymongo"
            )
        if connection_string and not connection_string.startswith(
            ("mongodb://", "mongodb+srv://")
        ):
            raise ValueError(
                f"MongoDBContractStore requires a mongodb:// URL, got: {connection_string!r}"
            )
        super().__init__(connection_string)
        self.database_name = database_name
        self._client: MongoClient | None = None
        self._db: Any = None

    def connect(self, ensure_indexes: bool = True) -> None:
        """Connect to MongoDB.

        Args:
            ensure_indexes: If True, ensure indexes exist (default: True).
                          Set to False if you've already created indexes manually
                          or want to skip index creation for performance.
        """
        if not self.connection_string:
            raise ValueError("connection_string is required for MongoDB")

        self._client = MongoClient(self.connection_string)
        self._db = self._client[self.database_name]  # type: ignore[assignment]
        self._connection = self._db

        # Create indexes for better query performance (only if requested)
        if ensure_indexes:
            self._ensure_indexes()

    def disconnect(self) -> None:
        """Close MongoDB connection."""
        if self._client:
            self._client.close()
            self._client = None
            self._db = None
            self._connection = None

    def _ensure_indexes(self) -> None:
        """Ensure all required indexes exist.

        This method checks if indexes exist before creating them to avoid
        unnecessary overhead on every connection. Indexes are created in
        the background to avoid blocking operations.

        Note:
            MongoDB's ``create_index()`` is idempotent, but checking first
            avoids the overhead of the check that MongoDB does internally.
        """
        if self._db is None:
            return

        _create_data_contract_indexes(self._db)
        _create_schema_indexes(self._db)
        _create_metadata_indexes(self._db)
        _create_coercion_indexes(self._db)
        _create_validation_indexes(self._db)


# ---------------------------------------------------------------------------
# Index helpers (module-level to keep class body small)
# ---------------------------------------------------------------------------


def _normalize_index_spec(spec: Any) -> dict[str, Any]:
    """Normalize index spec to a comparable dict format."""
    if isinstance(spec, str):
        return {spec: 1}
    if isinstance(spec, list):
        return dict(spec)
    return spec


def _index_exists_by_keys(collection: Any, index_spec: Any) -> bool:
    """Check if an index with the given key specification exists."""
    try:
        normalized_spec = _normalize_index_spec(index_spec)
        for idx in collection.list_indexes():
            if idx.get("key", {}) == normalized_spec:
                return True
    except Exception:
        # If we can't check, assume it doesn't exist and let create_index handle it
        return False
    return False


def _create_index_if_missing(collection: Any, index_spec: Any, **kwargs: Any) -> None:
    """Create index only if it doesn't exist."""
    if not _index_exists_by_keys(collection, index_spec):
        collection.create_index(index_spec, background=True, **kwargs)


def _create_data_contract_indexes(db: Any) -> None:
    """Create indexes for the data_contracts collection."""
    _create_index_if_missing(db.data_contracts, "name")
    _create_index_if_missing(
        db.data_contracts, [("name", 1), ("version", 1)], unique=True
    )


def _create_schema_indexes(db: Any) -> None:
    """Create indexes for the schemas collection."""
    _create_index_if_missing(db.schemas, "data_contract_id")
    _create_index_if_missing(db.schemas, [("title", 1), ("version", 1)], unique=True)


def _create_metadata_indexes(db: Any) -> None:
    """Create indexes for the metadata_records collection."""
    _create_index_if_missing(db.metadata_records, "data_contract_id")
    _create_index_if_missing(
        db.metadata_records, [("title", 1), ("version", 1)], unique=True
    )


def _create_coercion_indexes(db: Any) -> None:
    """Create indexes for the coercion_rules collection."""
    _create_index_if_missing(db.coercion_rules, "data_contract_id")
    _create_index_if_missing(db.coercion_rules, "schema_id")
    _create_index_if_missing(
        db.coercion_rules, [("title", 1), ("version", 1)], unique=True
    )


def _create_validation_indexes(db: Any) -> None:
    """Create indexes for the validation_rules collection."""
    _create_index_if_missing(db.validation_rules, "data_contract_id")
    _create_index_if_missing(db.validation_rules, "schema_id")
    _create_index_if_missing(
        db.validation_rules, [("title", 1), ("version", 1)], unique=True
    )
