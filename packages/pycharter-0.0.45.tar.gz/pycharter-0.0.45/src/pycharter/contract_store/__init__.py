"""
Contract Store Client Service

Connects to various databases and manages storage/retrieval
of data contracts (schemas, coercion rules, validation rules, metadata, etc.).

Available implementations:
- InMemoryContractStore: In-memory store for testing/development
- MongoDBContractStore: MongoDB implementation
- PostgresContractStore: PostgreSQL implementation
- SQLiteContractStore: SQLite implementation
- RedisContractStore: Redis implementation
"""

from __future__ import annotations

from pycharter.contract_store.client import ContractStoreClient

# Import implementations (with optional dependencies)
try:
    from pycharter.contract_store.in_memory import InMemoryContractStore
except ImportError:
    InMemoryContractStore = None  # type: ignore[assignment,misc]

try:
    from pycharter.contract_store.mongodb import MongoDBContractStore
except ImportError:
    MongoDBContractStore = None  # type: ignore[assignment,misc]

try:
    from pycharter.contract_store.postgres import PostgresContractStore
except ImportError:
    PostgresContractStore = None  # type: ignore[assignment,misc]

try:
    from pycharter.contract_store.sqlite import SQLiteContractStore
except ImportError:
    SQLiteContractStore = None  # type: ignore[assignment,misc]

try:
    from pycharter.contract_store.redis import RedisContractStore
except ImportError:
    RedisContractStore = None  # type: ignore[assignment,misc]

__all__ = [
    "ContractStoreClient",
    "InMemoryContractStore",
    "MongoDBContractStore",
    "PostgresContractStore",
    "SQLiteContractStore",
    "RedisContractStore",
]
