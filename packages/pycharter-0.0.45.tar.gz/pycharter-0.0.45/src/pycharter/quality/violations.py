"""Violation tracking for data quality issues.

Backward-compatible re-export shim. The implementation lives in
:mod:`pycharter.quality._violation_types` and
:mod:`pycharter.quality._violation_tracker`.
"""

from __future__ import annotations

from pycharter.quality._violation_tracker import ViolationTracker
from pycharter.quality._violation_types import ViolationRecord

__all__ = ["ViolationRecord", "ViolationTracker"]
