"""Core quality check engine orchestrating contract-based data validation."""

from __future__ import annotations

from collections.abc import Callable
from typing import TYPE_CHECKING, Any

from pycharter.contract_builder.types import DataContract
from pycharter.contract_store import ContractStoreClient
from pycharter.quality._check_rules import (
    calculate_data_fingerprint,
    get_data_source,
    get_existing_metric,
    load_data,
    persist_quality_metrics,
    record_violations,
)
from pycharter.quality.metrics import QualityMetrics
from pycharter.quality.models import (
    QualityCheckOptions,
    QualityReport,
    QualityThresholds,
)
from pycharter.quality.profiling import DataProfiler
from pycharter.quality.violations import ViolationTracker
from pycharter.runtime_validator.wrappers import (
    validate_batch_with_contract,
    validate_batch_with_store,
)

if TYPE_CHECKING:
    from sqlalchemy.orm import Session


class QualityCheck:
    """Contract-based quality scoring engine -- orchestrator-agnostic.

    Validates data against a data contract, calculates quality scores,
    records violations, and optionally checks thresholds.

    This class can be used:
    - Standalone (CLI, API, Python scripts)
    - Within orchestrators (Airflow, Prefect, Dagster)
    - Via API calls

    For post-load structural checks (row count, null rate, uniqueness),
    see ``PostLoadChecker`` in ``pycharter.pipeline_generator``.
    """

    def __init__(
        self,
        store: ContractStoreClient | None = None,
        db_session: Session | None = None,
    ):
        """Initialize quality check.

        Args:
            store: Optional contract store for retrieving contracts and
                storing violations.
            db_session: Optional SQLAlchemy database session for persisting
                metrics and violations.
        """
        self.store = store
        self.db_session = db_session
        self.metrics = QualityMetrics()
        self.violation_tracker = ViolationTracker(store=store, db_session=db_session)
        self.profiler = DataProfiler()

    def run(
        self,
        contract_name: str | None = None,
        contract_version: str | None = None,
        contract: dict[str, Any] | DataContract | str | None = None,
        data: list[dict[str, Any]] | str | Callable[[], Any] | None = None,
        options: QualityCheckOptions | None = None,
    ) -> QualityReport:
        """Run a quality check against a data contract.

        Use ``(contract_name, contract_version)`` for store-based validation,
        or ``contract`` for in-memory.

        Args:
            contract_name: Contract name for store-based validation.
            contract_version: Contract version for store-based validation.
            contract: In-memory contract (dict, DataContract, or file path).
            data: Data source (list, file path, or callable).
            options: Optional quality check options.

        Returns:
            QualityReport with scores, violations, and metadata.
        """
        if options is None:
            options = QualityCheckOptions()

        if isinstance(contract, DataContract):
            contract = contract.to_dict()

        options = self._resolve_thresholds(options, contract)

        schema_id = (
            f"{contract_name}:{contract_version}"
            if (contract_name and contract_version)
            else None
        )

        data_list = load_data(data)
        data_fingerprint = calculate_data_fingerprint(data_list)
        data_source = options.data_source or get_data_source(data)

        if options.sample_size and options.sample_size < len(data_list):
            import random

            data_list = random.sample(data_list, options.sample_size)

        if options.skip_if_unchanged and self.db_session and data_fingerprint:
            existing_metric = get_existing_metric(
                db_session=self.db_session,
                schema_id=schema_id,
                data_fingerprint=data_fingerprint,
                data_version=options.data_version,
            )
            if existing_metric:
                pass

        profile_data = None
        if options.include_profiling:
            profile_data = self.profiler.profile(data_list)

        validation_results = self._validate_data(
            contract_name=contract_name,
            contract_version=contract_version,
            contract=contract,
            data_list=data_list,
        )

        quality_score, field_metrics = self._calculate_scores(
            validation_results, options
        )

        violation_count = 0
        if options.record_violations:
            violation_count = record_violations(
                violation_tracker=self.violation_tracker,
                schema_id=schema_id,
                contract=contract,
                data_list=data_list,
                validation_results=validation_results,
                options=options,
            )

        threshold_breaches = self._check_thresholds(options, quality_score)

        report = self._build_report(
            schema_id=schema_id,
            contract_name=contract_name,
            contract_version=contract_version,
            quality_score=quality_score,
            field_metrics=field_metrics,
            violation_count=violation_count,
            data_list=data_list,
            validation_results=validation_results,
            threshold_breaches=threshold_breaches,
            data_fingerprint=data_fingerprint,
            data_source=data_source,
            profile_data=profile_data,
            options=options,
        )

        if self.db_session and quality_score:
            persist_quality_metrics(
                db_session=self.db_session,
                report=report,
                schema_id=schema_id,
                schema_version=report.schema_version,
                data_fingerprint=data_fingerprint,
                data_version=options.data_version,
                data_source=data_source,
                skip_if_unchanged=options.skip_if_unchanged,
            )

        return report

    def run_by_state(
        self,
        contract_name: str | None = None,
        contract_version: str | None = None,
        contract: dict[str, Any] | str | None = None,
        data: list[dict[str, Any]] | str | Callable[[], Any] | None = None,
        state_field: str = "status",
        options: QualityCheckOptions | None = None,
    ) -> dict[str, QualityReport]:
        """Run quality check segmented by state value.

        Groups the data by the value of *state_field*, runs a separate
        quality check for each group, and returns a mapping from state
        value to :class:`QualityReport`.

        Args:
            contract_name: Contract name for store-based validation.
            contract_version: Contract version for store-based validation.
            contract: In-memory contract dict or file path.
            data: Data source (list, file path, or callable).
            state_field: Field name to group records by (default ``"status"``).
            options: Optional quality check options (applied to each group).

        Returns:
            Dict mapping each unique state value to its ``QualityReport``.
        """
        data_list = load_data(data)

        grouped: dict[str, list[dict[str, Any]]] = {}
        for record in data_list:
            state = record.get(state_field, "_unknown")
            state_str = str(state) if state is not None else "_unknown"
            grouped.setdefault(state_str, []).append(record)

        results: dict[str, QualityReport] = {}
        for state_value, records in grouped.items():
            results[state_value] = self.run(
                contract_name=contract_name,
                contract_version=contract_version,
                contract=contract,
                data=records,
                options=options,
            )
        return results

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _resolve_thresholds(
        options: QualityCheckOptions,
        contract: dict[str, Any] | DataContract | str | None,
    ) -> QualityCheckOptions:
        """Auto-resolve thresholds from contract SLA when not explicitly set."""
        if options.check_thresholds and options.thresholds is None and contract:
            contract_dict = contract if isinstance(contract, dict) else {}
            resolved = QualityThresholds.from_contract(contract_dict)
            if resolved:
                options = options.model_copy(update={"thresholds": resolved})
        return options

    def _validate_data(
        self,
        contract_name: str | None,
        contract_version: str | None,
        contract: dict[str, Any] | DataContract | str | None,
        data_list: list[dict[str, Any]],
    ) -> list:
        """Validate data against contract from store or in-memory contract."""
        if contract_name and contract_version:
            if not self.store:
                raise ValueError("Store is required for store-based validation")
            return validate_batch_with_store(
                self.store, contract_name, contract_version, data_list
            )
        elif contract:
            return validate_batch_with_contract(contract=contract, data_list=data_list)
        else:
            raise ValueError(
                "Either (contract_name and contract_version) or contract "
                "must be provided"
            )

    def _calculate_scores(
        self, validation_results: list, options: QualityCheckOptions
    ) -> tuple[Any, dict]:
        """Calculate quality score and optional field metrics."""
        quality_score = None
        field_metrics: dict = {}
        if options.calculate_metrics:
            quality_score = self.metrics.calculate_quality_score(validation_results)
            if options.include_field_metrics:
                field_metrics = self.metrics.calculate_field_metrics(validation_results)
        return quality_score, field_metrics

    @staticmethod
    def _check_thresholds(options: QualityCheckOptions, quality_score: Any) -> list:
        """Check quality thresholds and return breaches."""
        if options.check_thresholds and options.thresholds and quality_score:
            return options.thresholds.check(quality_score)
        return []

    def _build_report(
        self,
        *,
        schema_id: str | None,
        contract_name: str | None,
        contract_version: str | None,
        quality_score: Any,
        field_metrics: dict,
        violation_count: int,
        data_list: list[dict[str, Any]],
        validation_results: list,
        threshold_breaches: list,
        data_fingerprint: str | None,
        data_source: str | None,
        profile_data: Any,
        options: QualityCheckOptions,
    ) -> QualityReport:
        """Build the final QualityReport from computed components."""
        valid_count = sum(1 for r in validation_results if r.is_valid)
        invalid_count = len(validation_results) - valid_count

        schema_version = self._resolve_schema_version(contract_name, contract_version)

        report_metadata: dict[str, Any] = {
            "sample_size": options.sample_size,
            "contract_based": True,
            "data_fingerprint": data_fingerprint,
            "data_source": data_source,
        }
        if options.data_version:
            report_metadata["data_version"] = options.data_version
        if profile_data:
            report_metadata["profiling"] = profile_data
        if options.metadata:
            report_metadata.update(options.metadata)

        return QualityReport(
            schema_id=schema_id or "unknown",
            schema_version=schema_version,
            quality_score=quality_score,
            field_metrics=field_metrics,
            violation_count=violation_count,
            record_count=len(data_list),
            valid_count=valid_count,
            invalid_count=invalid_count,
            threshold_breaches=threshold_breaches,
            metadata=report_metadata,
        )

    def _resolve_schema_version(
        self, contract_name: str | None, contract_version: str | None
    ) -> str | None:
        """Resolve the schema version from the contract store."""
        if contract_name and contract_version and self.store:
            try:
                full_schema = self.store.get_complete_schema(
                    contract_name, contract_version
                )
                return full_schema.get("version") if full_schema else contract_version
            except Exception:
                pass
        return None
