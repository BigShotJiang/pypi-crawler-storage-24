"""Violation tracking, persistence, and querying logic."""

from __future__ import annotations

import logging
from datetime import datetime
from typing import TYPE_CHECKING, Any
from uuid import UUID, uuid4

from pycharter.quality._violation_types import ViolationRecord, _serialize_for_json
from pycharter.runtime_validator.validator_core import ValidationResult

if TYPE_CHECKING:
    from sqlalchemy.orm import Session

logger = logging.getLogger(__name__)


class ViolationTracker:
    """Track and persist data quality violations."""

    def __init__(self, store: Any = None, db_session: Session | None = None):
        """Initialize violation tracker.

        Args:
            store: Optional contract store.
            db_session: Optional SQLAlchemy database session for persistence.
        """
        self.store = store
        self.db_session = db_session
        self._in_memory_violations: list[ViolationRecord] = []

    def record_violation(
        self,
        schema_id: str,
        record_id: str | None,
        record_data: dict[str, Any],
        validation_result: ValidationResult,
        severity: str = "warning",
        metadata: dict[str, Any] | None = None,
        deduplicate: bool = True,
        # Lifecycle context
        state: str | None = None,
        trigger: str | None = None,
        machine_name: str | None = None,
    ) -> ViolationRecord:
        """Record a quality violation.

        Args:
            schema_id: Schema identifier.
            record_id: Optional record identifier.
            record_data: The data record that violated the contract.
            validation_result: ValidationResult with errors.
            severity: Violation severity (critical, warning, info).
            metadata: Optional additional metadata.
            deduplicate: If True, avoid duplicate violations in the database.
            state: Optional FSM state at the time of violation.
            trigger: Optional FSM trigger that caused the violation.
            machine_name: Optional FSM machine name governing the entity.

        Returns:
            ViolationRecord object.
        """
        violation = ViolationRecord(
            schema_id=schema_id,
            record_id=record_id,
            record_data=record_data,
            validation_result=validation_result,
            severity=severity,
            metadata=metadata,
            state=state,
            trigger=trigger,
            machine_name=machine_name,
        )

        self._in_memory_violations.append(violation)

        if self.db_session:
            self._persist_violation(violation, deduplicate=deduplicate)

        return violation

    def get_violations(
        self,
        schema_id: str | None = None,
        start_date: datetime | None = None,
        end_date: datetime | None = None,
        severity: str | None = None,
        status: str | None = None,
        limit: int | None = None,
    ) -> list[ViolationRecord]:
        """Query violations.

        Args:
            schema_id: Filter by schema ID.
            start_date: Filter violations after this date.
            end_date: Filter violations before this date.
            severity: Filter by severity (critical, warning, info).
            status: Filter by status (open, resolved, ignored).
            limit: Optional limit on number of violations to return.

        Returns:
            List of ViolationRecord objects.
        """
        if self.db_session:
            return self._get_violations_from_db(
                schema_id=schema_id,
                start_date=start_date,
                end_date=end_date,
                severity=severity,
                status=status,
                limit=limit,
            )

        violations = self._in_memory_violations.copy()

        if schema_id:
            violations = [v for v in violations if v.schema_id == schema_id]
        if start_date:
            violations = [v for v in violations if v.timestamp >= start_date]
        if end_date:
            violations = [v for v in violations if v.timestamp <= end_date]
        if severity:
            violations = [v for v in violations if v.severity == severity]
        if status:
            violations = [v for v in violations if v.status == status]
        if limit is not None:
            violations = violations[:limit]

        return violations

    def resolve_violation(
        self, violation_id: UUID, resolved_by: str
    ) -> ViolationRecord | None:
        """Mark a violation as resolved.

        Args:
            violation_id: Violation ID.
            resolved_by: User/process that resolved the violation.

        Returns:
            Updated ViolationRecord or None if not found.
        """
        if self.db_session:
            from pycharter.db.models.quality_violation import QualityViolationModel

            db_violation = (
                self.db_session.query(QualityViolationModel)
                .filter(QualityViolationModel.id == violation_id)
                .first()
            )

            if db_violation:
                db_violation.status = "resolved"
                db_violation.resolved_at = datetime.utcnow()
                db_violation.resolved_by = resolved_by
                self.db_session.commit()

                violations = self.get_violations()
                for violation in violations:
                    if violation.id == violation_id:
                        return violation

        for violation in self._in_memory_violations:
            if violation.id == violation_id:
                violation.status = "resolved"
                violation.resolved_at = datetime.utcnow()
                violation.resolved_by = resolved_by
                return violation

        return None

    def get_violation_summary(self, schema_id: str | None = None) -> dict[str, Any]:
        """Get summary statistics for violations.

        Args:
            schema_id: Optional schema ID to filter by.

        Returns:
            Dictionary with violation statistics.
        """
        violations = self.get_violations(schema_id=schema_id)

        return {
            "total": len(violations),
            "open": sum(1 for v in violations if v.status == "open"),
            "resolved": sum(1 for v in violations if v.status == "resolved"),
            "ignored": sum(1 for v in violations if v.status == "ignored"),
            "by_severity": {
                "critical": sum(1 for v in violations if v.severity == "critical"),
                "warning": sum(1 for v in violations if v.severity == "warning"),
                "info": sum(1 for v in violations if v.severity == "info"),
            },
        }

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    def _persist_violation(
        self, violation: ViolationRecord, deduplicate: bool = True
    ) -> None:
        """Persist violation to database with optional deduplication."""
        if not self.db_session:
            return

        try:
            from sqlalchemy import and_

            from pycharter.db.models.quality_violation import QualityViolationModel

            schema_version, data_contract_id = _lookup_schema_info(
                self.db_session, violation.schema_id
            )

            serialized_record_data = (
                _serialize_for_json(violation.record_data)
                if violation.record_data
                else None
            )
            serialized_metadata = (
                _serialize_for_json(violation.metadata) if violation.metadata else None
            )

            for field_violation in violation.field_violations:
                field_name = field_violation.get("field")
                error_type = field_violation.get("error_type", "validation_error")
                violation_id = uuid4()

                if deduplicate:
                    with self.db_session.no_autoflush:
                        existing = (
                            self.db_session.query(QualityViolationModel)
                            .filter(
                                and_(
                                    QualityViolationModel.schema_id
                                    == violation.schema_id,
                                    QualityViolationModel.record_identifier
                                    == violation.record_id,
                                    QualityViolationModel.field_name == field_name,
                                    QualityViolationModel.error_type == error_type,
                                    QualityViolationModel.status == "open",
                                )
                            )
                            .first()
                        )

                    if existing:
                        existing.check_timestamp = violation.timestamp
                        if serialized_record_data:
                            existing.record_data = serialized_record_data
                        if schema_version and not existing.schema_version:
                            existing.schema_version = schema_version
                        if data_contract_id and not existing.data_contract_id:
                            existing.data_contract_id = data_contract_id
                        continue

                violation_model = QualityViolationModel(
                    id=violation_id,
                    schema_id=violation.schema_id,
                    schema_version=schema_version,
                    data_contract_id=data_contract_id,
                    record_identifier=violation.record_id,
                    record_data=serialized_record_data,
                    field_name=field_name,
                    error_type=error_type,
                    error_message=field_violation.get(
                        "error_message", str(field_violation)
                    ),
                    severity=violation.severity,
                    status=violation.status,
                    check_timestamp=violation.timestamp,
                    additional_metadata=serialized_metadata,
                )
                self.db_session.add(violation_model)

            self.db_session.commit()
        except Exception as exc:
            if self.db_session:
                self.db_session.rollback()
            logger.warning("Failed to persist violation to database: %s", exc)

    def _get_violations_from_db(
        self,
        schema_id: str | None = None,
        start_date: datetime | None = None,
        end_date: datetime | None = None,
        severity: str | None = None,
        status: str | None = None,
        limit: int | None = None,
    ) -> list[ViolationRecord]:
        """Query violations from database."""
        from sqlalchemy import and_

        from pycharter.db.models.quality_violation import QualityViolationModel

        query = self.db_session.query(QualityViolationModel)

        filters = []
        if schema_id:
            filters.append(QualityViolationModel.schema_id == schema_id)
        if start_date:
            filters.append(QualityViolationModel.check_timestamp >= start_date)
        if end_date:
            filters.append(QualityViolationModel.check_timestamp <= end_date)
        if severity:
            filters.append(QualityViolationModel.severity == severity)
        if status:
            filters.append(QualityViolationModel.status == status)

        if filters:
            query = query.filter(and_(*filters))
        if limit is not None:
            query = query.limit(limit)

        db_violations = query.all()

        violation_groups: dict[str, list[QualityViolationModel]] = {}
        for db_violation in db_violations:
            record_id = db_violation.record_identifier or "unknown"
            violation_groups.setdefault(record_id, []).append(db_violation)

        violations: list[ViolationRecord] = []
        for _record_id, db_violations_group in violation_groups.items():
            base = db_violations_group[0]

            errors = []
            for db_viol in db_violations_group:
                errors.append(
                    {
                        "loc": ((db_viol.field_name,) if db_viol.field_name else ()),
                        "type": db_viol.error_type,
                        "msg": db_viol.error_message,
                    }
                )

            validation_result = ValidationResult(
                is_valid=False, errors=errors, data=None
            )

            violation = ViolationRecord(
                schema_id=base.schema_id,
                record_id=base.record_identifier,
                record_data=base.record_data or {},
                validation_result=validation_result,
                severity=base.severity,
                metadata=base.metadata or {},
            )
            violation.id = base.id
            violation.timestamp = base.check_timestamp
            violation.status = base.status
            violation.resolved_at = base.resolved_at
            violation.resolved_by = base.resolved_by
            violation.metadata = base.additional_metadata or {}

            violations.append(violation)

        return violations


def _lookup_schema_info(
    db_session: Any, schema_id: str
) -> tuple[str | None, Any | None]:
    """Look up schema_version and data_contract_id for a violation.

    Args:
        db_session: SQLAlchemy database session.
        schema_id: The schema identifier to look up.

    Returns:
        Tuple of (schema_version, data_contract_id).
    """
    from pycharter.db.models.schema import SchemaModel

    schema_version = None
    data_contract_id = None
    try:
        from uuid import UUID as UUIDType

        schema_uuid = UUIDType(schema_id)
        schema = (
            db_session.query(SchemaModel).filter(SchemaModel.id == schema_uuid).first()
        )
    except (ValueError, TypeError):
        schema = (
            db_session.query(SchemaModel).filter(SchemaModel.id == schema_id).first()
        )

    if schema:
        schema_version = schema.version
        data_contract_id = schema.data_contract_id

    return schema_version, data_contract_id
