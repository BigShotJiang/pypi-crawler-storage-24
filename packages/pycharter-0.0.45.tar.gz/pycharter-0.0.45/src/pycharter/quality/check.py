"""Core quality check functionality.

Backward-compatible re-export shim. The implementation lives in
:mod:`pycharter.quality._check_engine` and
:mod:`pycharter.quality._check_rules`.
"""

from __future__ import annotations

from pycharter.quality._check_engine import QualityCheck

__all__ = ["QualityCheck"]
