"""Helper functions for quality check data loading, fingerprinting, and persistence."""

from __future__ import annotations

import hashlib
import json
import logging
from collections.abc import Callable
from datetime import datetime
from pathlib import Path
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from sqlalchemy.orm import Session

    from pycharter.quality.models import QualityCheckOptions, QualityReport
    from pycharter.quality.violations import ViolationTracker

logger = logging.getLogger(__name__)


def load_data(
    data: list[dict[str, Any]] | str | Callable[[], Any] | None,
) -> list[dict[str, Any]]:
    """Load data from various sources.

    Args:
        data: Data source (list, file path, or callable).

    Returns:
        List of data dictionaries.

    Raises:
        ValueError: If data source is None, unsupported, or returns wrong type.
        FileNotFoundError: If file path does not exist.
    """
    if data is None:
        raise ValueError("Data source is required")

    # If it's already a list, return it
    if isinstance(data, list):
        return data

    # If it's a callable, call it
    if callable(data):
        result = data()
        if isinstance(result, list):
            return result
        raise ValueError("Callable must return a list of dictionaries")

    # If it's a string, treat as file path
    if isinstance(data, str):
        return _load_from_file(data)

    raise ValueError(f"Unsupported data type: {type(data)}")


def _load_from_file(path: str) -> list[dict[str, Any]]:
    """Load data records from a JSON or CSV file.

    Args:
        path: File path string.

    Returns:
        List of data dictionaries.

    Raises:
        FileNotFoundError: If file does not exist.
        ValueError: If file format is unsupported or content is invalid.
    """
    file_path = Path(path)
    if not file_path.exists():
        raise FileNotFoundError(f"Data file not found: {path}")

    if file_path.suffix == ".json":
        with open(file_path) as f:
            loaded = json.load(f)
            if isinstance(loaded, list):
                return loaded
            elif isinstance(loaded, dict):
                return [loaded]
            else:
                raise ValueError("JSON file must contain a list or dict")
    elif file_path.suffix == ".csv":
        import pandas as pd

        df = pd.read_csv(file_path)
        return df.to_dict("records")
    else:
        raise ValueError(f"Unsupported file format: {file_path.suffix}")


def calculate_data_fingerprint(data_list: list[dict[str, Any]]) -> str:
    """Calculate a fingerprint (hash) of the data for deduplication.

    Args:
        data_list: List of data records.

    Returns:
        MD5 hash string of the data, or empty string if data is empty.
    """
    if not data_list:
        return ""

    # Create a stable representation of the data
    try:
        if isinstance(data_list[0], dict):
            sample_keys = list(data_list[0].keys())[:5]
            sorted_data = sorted(
                data_list,
                key=lambda x: tuple(str(x.get(k, "")) for k in sample_keys),
            )
        else:
            sorted_data = sorted(data_list)

        data_str = json.dumps(sorted_data, sort_keys=True, default=str)
    except Exception:
        data_str = json.dumps(data_list, sort_keys=True, default=str)

    return hashlib.md5(data_str.encode()).hexdigest()


def get_data_source(
    data: list[dict[str, Any]] | str | Callable[[], Any] | None,
) -> str | None:
    """Get data source identifier.

    Args:
        data: Data source.

    Returns:
        Source identifier string or None.
    """
    if isinstance(data, str):
        return str(data)
    elif isinstance(data, list):
        return "in-memory"
    elif callable(data):
        return f"callable:{data.__name__ if hasattr(data, '__name__') else 'unknown'}"
    return None


def get_existing_metric(
    db_session: Session,
    schema_id: str | None,
    data_fingerprint: str | None,
    data_version: str | None = None,
) -> Any | None:
    """Check if a quality metric already exists for this data.

    Args:
        db_session: SQLAlchemy database session.
        schema_id: Schema ID.
        data_fingerprint: Data fingerprint.
        data_version: Optional data version.

    Returns:
        Existing QualityMetricModel or None.
    """
    if not db_session or not data_fingerprint:
        return None

    try:
        from sqlalchemy import and_

        from pycharter.db.models.quality_metric import QualityMetricModel

        filters = [
            QualityMetricModel.schema_id == (schema_id or "unknown"),
            QualityMetricModel.data_fingerprint == data_fingerprint,
        ]

        if data_version:
            filters.append(QualityMetricModel.data_version == data_version)

        existing = (
            db_session.query(QualityMetricModel)
            .filter(and_(*filters))
            .order_by(QualityMetricModel.check_timestamp.desc())
            .first()
        )

        return existing
    except Exception:
        return None


def record_violations(
    violation_tracker: ViolationTracker,
    schema_id: str | None,
    contract: dict[str, Any] | str | None,
    data_list: list[dict[str, Any]],
    validation_results: list,
    options: QualityCheckOptions | None = None,
) -> int:
    """Record violations for invalid records.

    Args:
        violation_tracker: ViolationTracker instance.
        schema_id: Schema ID.
        contract: Contract dict or path.
        data_list: List of data records.
        validation_results: List of ValidationResult objects.
        options: Quality check options (for deduplicate_violations setting).

    Returns:
        Number of violations recorded.
    """
    violation_count = 0
    schema_id_str = schema_id or "unknown"

    for i, (record_data, result) in enumerate(
        zip(data_list, validation_results, strict=False)
    ):
        if not result.is_valid:
            record_id = _resolve_record_id(record_data, i)

            # Determine severity based on error count
            error_count = len(result.errors) if result.errors else 1
            if error_count > 5:
                severity = "critical"
            elif error_count > 2:
                severity = "warning"
            else:
                severity = "info"

            violation_tracker.record_violation(
                schema_id=schema_id_str,
                record_id=record_id,
                record_data=record_data,
                validation_result=result,
                severity=severity,
                metadata={"record_index": i},
                deduplicate=options.deduplicate_violations if options else True,
            )
            violation_count += 1

    return violation_count


def _resolve_record_id(record_data: Any, index: int) -> str:
    """Resolve a record ID from data or fall back to index-based ID.

    Args:
        record_data: The data record.
        index: Record index in the batch.

    Returns:
        Record identifier string.
    """
    if isinstance(record_data, dict):
        for id_field in ["id", "_id", "record_id", "uuid"]:
            if id_field in record_data:
                return str(record_data[id_field])
    return f"record_{index}"


def persist_quality_metrics(
    db_session: Session,
    report: QualityReport,
    schema_id: str | None,
    schema_version: str | None,
    data_fingerprint: str | None = None,
    data_version: str | None = None,
    data_source: str | None = None,
    skip_if_unchanged: bool = False,
) -> None:
    """Persist quality metrics to database with version tracking and deduplication.

    Args:
        db_session: SQLAlchemy database session.
        report: Quality report.
        schema_id: Schema ID.
        schema_version: Schema version.
        data_fingerprint: Data fingerprint for deduplication.
        data_version: Data version identifier.
        data_source: Data source identifier.
        skip_if_unchanged: If True, skip persisting if data hasn't changed.
    """
    if not db_session or not report.quality_score:
        return

    try:
        from pycharter.db.models.quality_metric import QualityMetricModel

        # Check for existing metrics with the same fingerprint to prevent inflation
        if data_fingerprint:
            existing = get_existing_metric(
                db_session=db_session,
                schema_id=schema_id,
                data_fingerprint=data_fingerprint,
                data_version=data_version,
            )
            if existing:
                existing.check_timestamp = datetime.utcnow()
                db_session.commit()
                logger.info(
                    "Skipping duplicate quality metric - data unchanged "
                    "(fingerprint: %s..., schema_id: %s)",
                    data_fingerprint[:16],
                    schema_id,
                )
                return

        data_contract_id = _lookup_data_contract_id(db_session, schema_id)

        quality_metric = QualityMetricModel(
            schema_id=schema_id or "unknown",
            schema_version=schema_version,
            data_contract_id=data_contract_id,
            overall_score=report.quality_score.overall_score,
            violation_rate=report.quality_score.violation_rate,
            completeness=report.quality_score.completeness,
            accuracy=report.quality_score.accuracy,
            record_count=report.record_count,
            valid_count=report.valid_count,
            invalid_count=report.invalid_count,
            violation_count=report.violation_count,
            field_scores=report.quality_score.field_scores,
            threshold_breaches=report.threshold_breaches,
            passed="true" if report.passed else "false",
            data_version=data_version,
            data_source=data_source,
            data_fingerprint=data_fingerprint,
            additional_metadata=report.metadata,
        )

        db_session.add(quality_metric)
        db_session.commit()
    except Exception as exc:
        if db_session:
            db_session.rollback()
        logger.warning("Failed to persist quality metrics to database: %s", exc)


def _lookup_data_contract_id(db_session: Session, schema_id: str | None) -> Any | None:
    """Look up data_contract_id from schema if available.

    Args:
        db_session: SQLAlchemy database session.
        schema_id: Schema ID to look up.

    Returns:
        data_contract_id or None.
    """
    if not schema_id:
        return None

    try:
        from pycharter.db.models.schema import SchemaModel

        schema = (
            db_session.query(SchemaModel).filter(SchemaModel.id == schema_id).first()
        )
        if schema:
            return schema.data_contract_id
    except Exception:
        pass
    return None
