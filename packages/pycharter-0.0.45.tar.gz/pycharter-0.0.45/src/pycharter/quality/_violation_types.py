"""Violation record types and serialization helpers."""

from __future__ import annotations

import hashlib
import json
from datetime import date, datetime
from typing import Any
from uuid import UUID, uuid4

from pycharter.runtime_validator.validator_core import ValidationResult


def _serialize_for_json(obj: Any) -> Any:
    """Recursively serialize objects to be JSON-compatible.

    Converts datetime, date, UUID, and other non-serializable types to
    strings so the result can be safely passed to ``json.dumps``.

    Args:
        obj: Any Python object.

    Returns:
        A JSON-serializable equivalent.
    """
    if isinstance(obj, datetime | date):
        return obj.isoformat()
    elif isinstance(obj, dict):
        return {key: _serialize_for_json(value) for key, value in obj.items()}
    elif isinstance(obj, list | tuple):
        return [_serialize_for_json(item) for item in obj]
    elif isinstance(obj, UUID):
        return str(obj)
    else:
        try:
            json.dumps(obj)
            return obj
        except (TypeError, ValueError):
            return str(obj)


class ViolationRecord:
    """Represents a single data quality violation."""

    def __init__(
        self,
        schema_id: str,
        record_id: str | None,
        record_data: dict[str, Any],
        validation_result: ValidationResult,
        severity: str = "warning",
        metadata: dict[str, Any] | None = None,
        # Lifecycle context -- set by caller (e.g. bridge code), not by validator
        state: str | None = None,
        trigger: str | None = None,
        machine_name: str | None = None,
    ):
        """Initialize a violation record.

        Args:
            schema_id: Schema identifier.
            record_id: Optional record identifier (if None, generated from
                data hash).
            record_data: The data record that violated the contract.
            validation_result: ValidationResult with errors.
            severity: Violation severity (critical, warning, info).
            metadata: Optional additional metadata.
            state: Optional FSM state at the time of violation.
            trigger: Optional FSM trigger that caused the violation.
            machine_name: Optional FSM machine name governing the entity.
        """
        self.id = uuid4()
        self.schema_id = schema_id
        self.record_id = record_id or self._generate_record_id(record_data)
        self.record_data = record_data
        self.validation_result = validation_result
        self.severity = severity
        self.metadata = metadata or {}
        self.timestamp = datetime.utcnow()
        self.status = "open"  # open, resolved, ignored
        self.resolved_at: datetime | None = None
        self.resolved_by: str | None = None

        # Lifecycle context
        self.state = state
        self.trigger = trigger
        self.machine_name = machine_name

        # Extract field-level violations
        self.field_violations = self._extract_field_violations(validation_result)

    def _generate_record_id(self, record_data: dict[str, Any]) -> str:
        """Generate a record ID from data hash."""
        data_str = json.dumps(record_data, sort_keys=True)
        return hashlib.md5(data_str.encode()).hexdigest()

    def _extract_field_violations(
        self, validation_result: ValidationResult
    ) -> list[dict[str, Any]]:
        """Extract field-level violation details from validation result."""
        violations: list[dict[str, Any]] = []

        if not validation_result.is_valid:
            for error in validation_result.errors:
                violation = {
                    "field": self._extract_field_name(error),
                    "error_type": self._extract_error_type(error),
                    "error_message": str(error),
                }
                violations.append(violation)

        return violations

    @staticmethod
    def _extract_field_name(error: Any) -> str:
        """Extract field name from validation error."""
        if isinstance(error, dict):
            loc = error.get("loc", [])
            if loc:
                return str(loc[-1]) if isinstance(loc[-1], str) else "unknown"
        return "unknown"

    @staticmethod
    def _extract_error_type(error: Any) -> str:
        """Extract error type from validation error."""
        if isinstance(error, dict):
            return error.get("type", "validation_error")
        elif isinstance(error, str):
            error_lower = error.lower()
            if "missing" in error_lower:
                return "missing_field"
            elif "type" in error_lower:
                return "type_error"
            else:
                return "validation_error"
        return "unknown"

    def to_dict(self) -> dict[str, Any]:
        """Convert violation record to dictionary."""
        d: dict[str, Any] = {
            "id": str(self.id),
            "schema_id": self.schema_id,
            "record_id": self.record_id,
            "record_data": self.record_data,
            "severity": self.severity,
            "status": self.status,
            "field_violations": self.field_violations,
            "error_count": len(self.field_violations),
            "timestamp": self.timestamp.isoformat(),
            "resolved_at": (self.resolved_at.isoformat() if self.resolved_at else None),
            "resolved_by": self.resolved_by,
            "metadata": self.metadata,
        }
        if self.state is not None:
            d["state"] = self.state
        if self.trigger is not None:
            d["trigger"] = self.trigger
        if self.machine_name is not None:
            d["machine_name"] = self.machine_name
        return d
