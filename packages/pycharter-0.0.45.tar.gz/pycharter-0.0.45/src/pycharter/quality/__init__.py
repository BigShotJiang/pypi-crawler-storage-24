"""
Data Quality Assurance Module

Provides quality checking, metrics calculation, violation tracking, and reporting
for data contracts.

Submodules:
    - tracking: Time-series metrics collection and analysis
"""

from __future__ import annotations

# Tracking submodule exports
from pycharter.quality import tracking
from pycharter.quality.check import QualityCheck
from pycharter.quality.metrics import QualityMetrics, QualityScore
from pycharter.quality.models import (
    FieldQualityMetrics,
    QualityCheckOptions,
    QualityReport,
    QualityThresholds,
)
from pycharter.quality.profiling import DataProfiler
from pycharter.quality.tracking import (
    InMemoryMetricsStore,
    MetricsCollector,
    MetricsFilter,
    MetricsStore,
    MetricsSummary,
    SQLiteMetricsStore,
    ValidationMetric,
)
from pycharter.quality.violations import ViolationRecord, ViolationTracker
from pycharter.quality.wrappers import (
    check_quality,
    check_quality_with_store,
    profile_data,
)

__all__ = [
    # Quality checking
    "QualityCheck",
    "QualityMetrics",
    "QualityScore",
    "QualityReport",
    "QualityThresholds",
    "QualityCheckOptions",
    "FieldQualityMetrics",
    "ViolationTracker",
    "ViolationRecord",
    "DataProfiler",
    # Tracking submodule
    "tracking",
    "MetricsCollector",
    "ValidationMetric",
    "MetricsSummary",
    "MetricsFilter",
    "MetricsStore",
    "InMemoryMetricsStore",
    "SQLiteMetricsStore",
    # Convenience wrappers
    "check_quality",
    "check_quality_with_store",
    "profile_data",
]
