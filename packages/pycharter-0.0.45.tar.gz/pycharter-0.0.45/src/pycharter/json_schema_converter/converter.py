"""Convert Pydantic models to JSON Schema.

This module is a backward-compatible re-export shim. The actual
implementation lives in ``_converter_core`` and ``_converter_types``.
"""

from __future__ import annotations

from pycharter.json_schema_converter._converter_core import model_to_schema

__all__ = ["model_to_schema"]
