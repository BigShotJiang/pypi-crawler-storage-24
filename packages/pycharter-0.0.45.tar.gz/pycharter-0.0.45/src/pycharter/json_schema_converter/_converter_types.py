"""Type mapping tables and type-related helpers for JSON Schema conversion.

Provides Python-to-JSON-Schema type mapping, field constraint extraction,
literal value extraction, version extraction, and anyOf normalization.
"""

from __future__ import annotations

import inspect
import types
from typing import Any, Union, get_args, get_origin

from pydantic import BaseModel
from pydantic.fields import FieldInfo


def _python_type_to_json_type(python_type: type[Any]) -> str:
    """Map Python type to JSON Schema type.

    Args:
        python_type: Python type

    Returns:
        JSON Schema type string
    """
    type_mapping = {
        str: "string",
        int: "integer",
        float: "number",
        bool: "boolean",
        list: "array",
        dict: "object",
    }

    # Handle Optional / union types (typing.Union or types.UnionType from X | Y)
    origin = get_origin(python_type)
    if origin is Union or origin is types.UnionType:
        args = get_args(python_type)
        # Filter out None for Optional
        non_none_args = [arg for arg in args if arg is not type(None)]
        if non_none_args:
            return _python_type_to_json_type(non_none_args[0])

    # Check direct mapping
    if python_type in type_mapping:
        return type_mapping[python_type]

    # Check if it's a subclass of BaseModel (nested model)
    if inspect.isclass(python_type) and issubclass(python_type, BaseModel):
        return "object"

    # Default to string
    return "string"


def _extract_field_constraints(field_info: FieldInfo) -> dict[str, Any]:
    """Extract JSON Schema constraints from Pydantic Field.

    Args:
        field_info: Pydantic FieldInfo object

    Returns:
        Dictionary of JSON Schema constraints
    """
    constraints: dict[str, Any] = {}

    # In Pydantic v2, constraints are stored in json_schema_extra or as attributes
    # Try to get JSON schema from the field
    try:
        # Get the JSON schema for this field
        json_schema = field_info.json_schema()  # type: ignore[attr-defined]

        # Extract constraints from JSON schema
        if "minLength" in json_schema:
            constraints["minLength"] = json_schema["minLength"]
        if "maxLength" in json_schema:
            constraints["maxLength"] = json_schema["maxLength"]
        if "pattern" in json_schema:
            constraints["pattern"] = json_schema["pattern"]
        if "minimum" in json_schema:
            constraints["minimum"] = json_schema["minimum"]
        if "exclusiveMinimum" in json_schema:
            constraints["exclusiveMinimum"] = json_schema["exclusiveMinimum"]
        if "maximum" in json_schema:
            constraints["maximum"] = json_schema["maximum"]
        if "exclusiveMaximum" in json_schema:
            constraints["exclusiveMaximum"] = json_schema["exclusiveMaximum"]
        if "multipleOf" in json_schema:
            constraints["multipleOf"] = json_schema["multipleOf"]
        if "minItems" in json_schema:
            constraints["minItems"] = json_schema["minItems"]
        if "maxItems" in json_schema:
            constraints["maxItems"] = json_schema["maxItems"]
    except (AttributeError, TypeError):
        # Fallback: try direct attribute access (Pydantic v1 or different structure)
        if hasattr(field_info, "min_length") and field_info.min_length is not None:
            constraints["minLength"] = field_info.min_length
        if hasattr(field_info, "max_length") and field_info.max_length is not None:
            constraints["maxLength"] = field_info.max_length
        if hasattr(field_info, "pattern") and field_info.pattern:
            constraints["pattern"] = field_info.pattern
        if hasattr(field_info, "ge") and field_info.ge is not None:
            constraints["minimum"] = field_info.ge
        if hasattr(field_info, "gt") and field_info.gt is not None:
            constraints["exclusiveMinimum"] = field_info.gt
        if hasattr(field_info, "le") and field_info.le is not None:
            constraints["maximum"] = field_info.le
        if hasattr(field_info, "lt") and field_info.lt is not None:
            constraints["exclusiveMaximum"] = field_info.lt
        if hasattr(field_info, "multiple_of") and field_info.multiple_of is not None:
            constraints["multipleOf"] = field_info.multiple_of

    # Description
    if hasattr(field_info, "description") and field_info.description:
        constraints["description"] = field_info.description

    return constraints


def _extract_literal_values(python_type: type[Any]) -> list[Any] | None:
    """Extract values from Literal type for enum/const.

    Args:
        python_type: Python type (may be Literal)

    Returns:
        List of literal values if Literal type, None otherwise
    """
    origin = get_origin(python_type)

    if origin is not None:
        # Handle [Literal[...], None (Optional Literal)
        if origin is Union or origin is types.UnionType:
            args = get_args(python_type)
            non_none_args = [arg for arg in args if arg is not type(None)]
            if non_none_args:
                return _extract_literal_values(non_none_args[0])
        return None

    # Check if it's a Literal type (Python 3.8+)
    if hasattr(python_type, "__origin__") and (
        python_type.__origin__ is Union or python_type.__origin__ is types.UnionType
    ):
        # Handle Literal types
        args = get_args(python_type)
        # Check if all args are literals (not types)
        if args and all(not inspect.isclass(arg) for arg in args):
            return list(args)

    # Try to get literal values from __args__
    if hasattr(python_type, "__args__"):
        args = python_type.__args__
        if args and all(not inspect.isclass(arg) for arg in args):
            return list(args)

    return None


def _normalize_anyof_to_type_list(schema: dict[str, Any]) -> dict[str, Any]:
    """Convert anyOf patterns for nullable types to the more readable list notation.

    Converts:
        {"anyOf": [{"type": "number"}, {"type": "null"}]}
        {"anyOf": [{"type": "string", "format": "date-time"}, {"type": "null"}]}
    To:
        {"type": ["number", "null"]}
        {"type": ["string", "null"], "format": "date-time"}

    Args:
        schema: JSON Schema dictionary (can be nested)

    Returns:
        Normalized schema with anyOf converted to type arrays
    """
    if isinstance(schema, dict):
        # Check if this is an anyOf pattern we can simplify
        if "anyOf" in schema and isinstance(schema["anyOf"], list):
            anyof_items = schema["anyOf"]
            # Check if it's a simple nullable type pattern
            if len(anyof_items) == 2:
                null_item = None
                type_item = None

                for item in anyof_items:
                    if isinstance(item, dict):
                        if item.get("type") == "null":
                            null_item = item
                        elif "type" in item:
                            type_item = item

                # If we have exactly one type + null, convert to list notation
                if null_item is not None and type_item is not None:
                    new_schema = schema.copy()
                    del new_schema["anyOf"]

                    # Extract the type
                    type_value = type_item["type"]
                    new_schema["type"] = [type_value, "null"]

                    # Copy other properties from the type item (like format, etc.)
                    for key, value in type_item.items():
                        if key != "type":
                            new_schema[key] = value

                    return new_schema

        # Recursively process nested schemas
        return {k: _normalize_anyof_to_type_list(v) for k, v in schema.items()}
    elif isinstance(schema, list):
        return [_normalize_anyof_to_type_list(item) for item in schema]
    else:
        return schema


def _extract_version_from_model(model: type[BaseModel]) -> str | None:
    """Extract version from a Pydantic model.

    Checks multiple sources in order:
    1. __version__ class variable (ClassVar or regular attribute)
    2. schema_version class variable (ClassVar or regular attribute)
    3. model_config.json_schema_extra["version"]
    4. model_config.json_schema_extra.get("version")

    Args:
        model: Pydantic model class

    Returns:
        Version string if found, None otherwise
    """
    # Check class variables (including ClassVar)
    if hasattr(model, "__version__"):
        version = model.__version__
        # Handle ClassVar - it's stored in __annotations__
        if isinstance(version, str):
            return version
        # If it's a ClassVar descriptor, try to get the actual value
        if hasattr(version, "__get__"):
            try:
                actual_version = version.__get__(None, model)
                if isinstance(actual_version, str):
                    return actual_version
            except (AttributeError, TypeError):
                pass

    if hasattr(model, "schema_version"):
        version = model.schema_version
        if isinstance(version, str):
            return version
        # Handle ClassVar
        if hasattr(version, "__get__"):
            try:
                actual_version = version.__get__(None, model)
                if isinstance(actual_version, str):
                    return actual_version
            except (AttributeError, TypeError):
                pass

    # Check model_config (Pydantic v2)
    if hasattr(model, "model_config"):
        config = model.model_config
        if hasattr(config, "json_schema_extra"):  # type: ignore[attr-defined]
            json_schema_extra = config.json_schema_extra  # type: ignore[attr-defined]
            if isinstance(json_schema_extra, dict) and "version" in json_schema_extra:
                version = json_schema_extra["version"]
                if isinstance(version, str):
                    return version
        # Also check if it's a callable that returns a dict
        elif callable(getattr(config, "json_schema_extra", None)):  # type: ignore[attr-defined]
            try:
                extra = config.json_schema_extra({})  # type: ignore[attr-defined]
                if isinstance(extra, dict) and "version" in extra:
                    version = extra["version"]
                    if isinstance(version, str):
                        return version
            except Exception:
                pass

    return None
