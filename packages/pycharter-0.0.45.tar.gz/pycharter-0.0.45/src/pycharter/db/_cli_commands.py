"""Database CLI command implementations.

Contains the actual ``cmd_*`` functions that perform database operations
(init, upgrade, downgrade, current, stamp, history, truncate).
The thin CLI entry point and argparse setup live in ``cli.py``.
"""

from __future__ import annotations

import logging
from pathlib import Path

try:
    from alembic import command
    from sqlalchemy import create_engine, inspect, text
except ImportError:
    command = None  # type: ignore[assignment]

from pycharter.config import set_database_url
from pycharter.db.config import (
    detect_db_type,
    get_alembic_config,
    get_db_url,
    require_alembic,
)
from pycharter.db.models.base import get_engine

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Init
# ---------------------------------------------------------------------------


def cmd_init(
    database_url: str | None = None,
    db_type: str | None = None,
    force: bool = False,
) -> int:
    """Initialize database schema (PostgreSQL, SQLite, or MongoDB)."""
    try:
        db_url = get_db_url(database_url)
        if not db_url:
            return 1
        db_type = db_type or detect_db_type(db_url)
        if db_type == "mongodb":
            return _init_mongodb(db_url, force)
        if db_type == "sqlite":
            return _init_sqlite(db_url, force)
        return _init_postgresql(db_url, force)
    except Exception as e:
        print(f"\u274c Error: {e}")
        import traceback

        traceback.print_exc()
        return 1


def _init_mongodb(database_url: str, force: bool = False) -> int:
    """Initialize MongoDB (create indexes)."""
    try:
        from pycharter.contract_store.mongodb import MongoDBContractStore

        database_name = "pycharter"
        if "/" in database_url.split("@")[-1]:
            db_part = database_url.split("/")[-1].split("?")[0]
            if db_part and db_part != database_url.split("@")[-1]:
                database_name = db_part
        print(f"Initializing MongoDB database: {database_name}")
        store = MongoDBContractStore(
            connection_string=database_url, database_name=database_name
        )
        store.connect(ensure_indexes=True)
        print("\u2713 MongoDB initialized successfully!")
        store.disconnect()
        return 0
    except ImportError:
        print("\u274c Error: pymongo is required. Install with: pip install pymongo")
        return 1
    except Exception as e:
        print(f"\u274c Error initializing MongoDB: {e}")
        import traceback

        traceback.print_exc()
        return 1


def _init_sqlite(database_url: str, force: bool = False) -> int:
    """Initialize SQLite: run migrations only (same approach as PostgreSQL)."""
    require_alembic()
    try:
        db_path = (
            database_url[10:] if database_url.startswith("sqlite:///") else database_url
        )
        if db_path != ":memory:":
            Path(db_path).parent.mkdir(parents=True, exist_ok=True)
        engine = get_engine(database_url)
        existing_tables = inspect(engine).get_table_names()
        if existing_tables and not force:
            print(
                f"\u26a0 Warning: Database already contains {len(existing_tables)} tables."
            )
            print(
                "   Use --force to reinitialize, or run 'pycharter db upgrade' to apply migrations."
            )
            return 1
        if existing_tables and force:
            with engine.connect() as conn:
                conn.execute(text("PRAGMA foreign_keys=OFF"))
                for name in existing_tables:
                    conn.execute(text(f'DROP TABLE IF EXISTS "{name}"'))
                conn.execute(text("PRAGMA foreign_keys=ON"))
                conn.commit()
            print("\u2713 Dropped existing tables")
        set_database_url(database_url)
        config = get_alembic_config(database_url)
        print("Running migrations to initialize database...")
        command.upgrade(config, "head")
        print("\u2713 SQLite initialization complete!")
        return 0
    except Exception as e:
        print(f"\u274c Error initializing SQLite: {e}")
        import traceback

        traceback.print_exc()
        return 1


def _init_postgresql(database_url: str, force: bool = False) -> int:
    """Initialize PostgreSQL: create pycharter schema and run migrations."""
    require_alembic()
    try:
        set_database_url(database_url)
        config = get_alembic_config(database_url)
        engine = create_engine(database_url)
        with engine.connect() as conn:
            conn.execute(text('CREATE SCHEMA IF NOT EXISTS "pycharter"'))
            conn.commit()
        print("\u2713 Created 'pycharter' schema (if it didn't exist)")
        print("Running migrations to initialize database...")
        command.upgrade(config, "head")
        print("\u2713 Database initialized successfully!")
        return 0
    except Exception as e:
        print(f"\u274c Error initializing database: {e}")
        import traceback

        traceback.print_exc()
        return 1


# ---------------------------------------------------------------------------
# Migrations (upgrade / downgrade / current / stamp / history)
# ---------------------------------------------------------------------------


def cmd_upgrade(database_url: str | None = None, revision: str = "head") -> int:
    """Upgrade database to the given revision (default head)."""
    require_alembic()
    try:
        db_url = get_db_url(database_url)
        if not db_url:
            return 1
        if database_url:
            set_database_url(database_url)
        config = get_alembic_config(db_url)
        print(f"Upgrading database to revision: {revision}...")
        command.upgrade(config, revision)
        print("\u2713 Database upgraded successfully!")
        return 0
    except Exception as e:
        print(f"\u274c Error upgrading database: {e}")
        import traceback

        traceback.print_exc()
        return 1


def cmd_downgrade(database_url: str | None = None, revision: str = "-1") -> int:
    """Downgrade database to the given revision."""
    require_alembic()
    try:
        db_url = get_db_url(database_url)
        if not db_url:
            return 1
        if database_url:
            set_database_url(database_url)
        config = get_alembic_config(db_url)
        print(f"Downgrading database to revision: {revision}...")
        command.downgrade(config, revision)
        print("\u2713 Database downgraded successfully!")
        return 0
    except Exception as e:
        print(f"\u274c Error downgrading database: {e}")
        import traceback

        traceback.print_exc()
        return 1


def cmd_current(database_url: str | None = None) -> int:
    """Print current database revision."""
    require_alembic()
    try:
        db_url = get_db_url(database_url)
        if not db_url:
            return 1
        if database_url:
            set_database_url(database_url)
        engine = create_engine(db_url)
        with engine.connect() as connection:
            try:
                result = connection.execute(
                    text('SELECT version_num FROM "pycharter".alembic_version LIMIT 1')
                )
                version = result.fetchone()
                if version:
                    print(f"Current database revision: {version[0]}")
                    return 0
            except Exception:
                logger.debug(
                    "pycharter.alembic_version query failed, trying fallback",
                    exc_info=True,
                )
            from alembic.runtime.migration import MigrationContext

            context = MigrationContext.configure(connection)
            current_rev = context.get_current_revision()
            if current_rev:
                print(f"Current database revision: {current_rev}")
                return 0
        print("Database is not initialized. Run 'pycharter db init' first.")
        return 1
    except Exception as e:
        print(f"\u274c Error getting current revision: {e}")
        return 1


def cmd_stamp(database_url: str | None = None, revision: str = "head") -> int:
    """Stamp database with a revision without running migrations."""
    require_alembic()
    try:
        db_url = get_db_url(database_url)
        if not db_url:
            return 1
        if database_url:
            set_database_url(database_url)
        config = get_alembic_config(db_url)
        print(f"Stamping database with revision: {revision}...")
        command.stamp(config, revision)
        print(f"\u2713 Database stamped successfully with revision: {revision}")
        return 0
    except Exception as e:
        print(f"\u274c Error stamping database: {e}")
        import traceback

        traceback.print_exc()
        return 1


def cmd_history(database_url: str | None = None) -> int:
    """Show migration history."""
    require_alembic()
    try:
        if database_url:
            set_database_url(database_url)
        config = get_alembic_config()
        command.history(config)
        return 0
    except Exception as e:
        print(f"\u274c Error showing history: {e}")
        return 1


# ---------------------------------------------------------------------------
# Truncate
# ---------------------------------------------------------------------------

# Tables in dependency order for safe truncation.
_TRUNCATE_TABLES = [
    "metadata_record_business_owners",
    "metadata_record_bu_sme",
    "metadata_record_it_application_owners",
    "metadata_record_it_sme",
    "metadata_record_support_lead",
    "metadata_record_system_pulls",
    "metadata_record_system_pushes",
    "metadata_record_system_sources",
    "metadata_record_domains",
    "coercion_rules",
    "validation_rules",
    "schemas",
    "metadata_records",
    "data_contracts",
    "owners",
    "systems",
    "domains",
]


def cmd_truncate(database_url: str | None = None, force: bool = False) -> int:
    """Truncate all PyCharter tables (PostgreSQL or SQLite).

    Prompts for confirmation unless ``--force`` is supplied.
    """
    require_alembic()
    try:
        db_url = get_db_url(database_url)
        if not db_url:
            return 1
        if database_url:
            set_database_url(database_url)
        engine = create_engine(db_url)
        inspector = inspect(engine)
        is_sqlite = detect_db_type(db_url) == "sqlite"
        existing_tables = set(
            inspector.get_table_names()
            if is_sqlite
            else inspector.get_table_names(schema="pycharter")
        )
        tables_to_truncate = [t for t in _TRUNCATE_TABLES if t in existing_tables]
        if not tables_to_truncate:
            print("\u26a0 No PyCharter tables found to truncate.")
            return 0

        print(
            f"\n\u26a0 WARNING: This will truncate {len(tables_to_truncate)} table(s):"
        )
        print(f"   {', '.join(tables_to_truncate)}")
        print("\n\u26a0 ALL DATA IN THESE TABLES WILL BE PERMANENTLY DELETED!")

        if not force:
            try:
                confirmation = input("\nType 'yes' to confirm: ").strip().lower()
                if confirmation not in ("yes", "y"):
                    print("\u274c Truncate cancelled.")
                    return 1
            except (EOFError, KeyboardInterrupt):
                print("\n\u274c Truncate cancelled.")
                return 1

        _do_truncate(engine, tables_to_truncate, is_sqlite=is_sqlite)
        print("\n\u2713 Successfully truncated all existing PyCharter tables!")
        return 0
    except Exception as e:
        print(f"\u274c Error truncating database: {e}")
        import traceback

        traceback.print_exc()
        return 1


def _do_truncate(engine, tables: list[str], *, is_sqlite: bool) -> None:
    """Execute the truncation SQL for the given tables.

    Args:
        engine: SQLAlchemy engine.
        tables: Ordered list of table names.
        is_sqlite: Whether the backend is SQLite.
    """
    with engine.begin() as conn:
        if is_sqlite:
            for table in tables:
                conn.execute(text(f'DELETE FROM "{table}"'))
                print(f"  \u2713 Truncated {table}")
        else:
            conn.execute(text("SET session_replication_role = 'replica'"))
            for table in tables:
                conn.execute(text(f'TRUNCATE TABLE pycharter."{table}" CASCADE'))
                print(f"  \u2713 Truncated {table}")
            conn.execute(text("SET session_replication_role = 'origin'"))
