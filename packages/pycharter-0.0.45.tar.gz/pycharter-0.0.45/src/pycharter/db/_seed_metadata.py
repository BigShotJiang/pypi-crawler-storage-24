"""Metadata record seeding: transform, upsert, and relationship sync."""

from __future__ import annotations

import logging
import uuid
from datetime import datetime
from pathlib import Path
from typing import Any

try:
    import yaml  # type: ignore[import-untyped]
except ImportError:
    yaml = None  # type: ignore[assignment]

from pycharter.db.metadata_normalizer import (
    LINEAGE_KEYS,
    OWNERSHIP_KEYS,
    ensure_canonical,
    relationship_view,
)
from pycharter.db.models import (
    DomainModel,
    EnvironmentModel,
    MetadataRecordBusinessOwner,
    MetadataRecordBUSME,
    MetadataRecordDomain,
    MetadataRecordEnvironment,
    MetadataRecordITApplicationOwner,
    MetadataRecordITSME,
    MetadataRecordModel,
    MetadataRecordStorageLocation,
    MetadataRecordSupportLead,
    MetadataRecordSystemPull,
    MetadataRecordSystemPush,
    MetadataRecordSystemSource,
    StorageLocationModel,
    SystemModel,
)

logger = logging.getLogger(__name__)

# Column names on MetadataRecordModel that we can set from seed
_METADATA_RECORD_COLUMNS = {
    "title",
    "data_contract_id",
    "version",
    "status",
    "type",
    "description",
    "created_at",
    "updated_at",
    "created_by",
    "updated_by",
    "governance_rules",
    "payload",
}

_OWNERSHIP_MODELS = (
    MetadataRecordBusinessOwner,
    MetadataRecordBUSME,
    MetadataRecordITApplicationOwner,
    MetadataRecordITSME,
    MetadataRecordSupportLead,
)
_LINEAGE_MODELS = (
    MetadataRecordSystemPull,
    MetadataRecordSystemPush,
    MetadataRecordSystemSource,
)


def _to_json_serializable(obj: Any) -> Any:
    """Recursively convert UUID/datetime to JSON-serializable types for JSON columns."""
    if obj is None:
        return None
    if isinstance(obj, uuid.UUID):
        return str(obj)
    if isinstance(obj, datetime):
        return obj.isoformat()
    if isinstance(obj, dict):
        return {k: _to_json_serializable(v) for k, v in obj.items()}
    if isinstance(obj, list | tuple):
        return [_to_json_serializable(v) for v in obj]
    return obj


def transform_metadata_record(
    record: dict,
    contract_lookup: dict[tuple[str, str], tuple[int, int | None]],
    transform_artifact_fn: Any,
) -> dict | None:
    """Transform metadata seed entry: resolve contract, normalize to canonical, store payload."""
    base = transform_artifact_fn(record, contract_lookup, include_schema_id=False)
    if not base:
        return None
    canonical = ensure_canonical(base)
    row = {k: v for k, v in canonical.items() if k in _METADATA_RECORD_COLUMNS}
    row["data_contract_id"] = base["data_contract_id"]
    row["payload"] = _to_json_serializable(canonical)
    if "governance_rules" in row and row["governance_rules"] is not None:
        row["governance_rules"] = _to_json_serializable(row["governance_rules"])
    if "title" not in row and canonical.get("title"):
        row["title"] = canonical["title"]
    if "version" not in row and canonical.get("version"):
        row["version"] = canonical["version"]
    return row


def seed_metadata_records(
    seed_path: Path,
    session: Any,
    full_lookup: dict[tuple[str, str], tuple[int, int | None]],
    id_fields: list[str],
    transform_artifact_fn: Any,
    set_sqlite_timestamps_fn: Any,
) -> int:
    """Seed metadata_records from metadata.yaml with canonical payload and relationship sync."""
    metadata_file = seed_path / "metadata.yaml"
    if not metadata_file.exists():
        logger.warning("No metadata.yaml found, skipping metadata_records")
        return 0
    with open(metadata_file) as f:
        data = yaml.safe_load(f) or []
    count = 0
    for record in data:
        row = transform_metadata_record(record, full_lookup, transform_artifact_fn)
        if row is None:
            continue
        filter_kw = {k: row[k] for k in id_fields if k in row}
        if len(filter_kw) != len(id_fields):
            logger.warning(
                "Skipping metadata entry missing key field(s): %s", id_fields
            )
            continue
        existing = session.query(MetadataRecordModel).filter_by(**filter_kw).first()
        if existing:
            for key, value in row.items():
                if hasattr(existing, key):
                    setattr(existing, key, value)
            set_sqlite_timestamps_fn(session, existing)
            session.flush()
            sync_metadata_relationships_from_payload(
                session, existing, set_sqlite_timestamps_fn
            )
            count += 1
        else:
            item = MetadataRecordModel(
                **{k: v for k, v in row.items() if k in _METADATA_RECORD_COLUMNS}
            )
            set_sqlite_timestamps_fn(session, item)
            session.add(item)
            session.flush()
            sync_metadata_relationships_from_payload(
                session, item, set_sqlite_timestamps_fn
            )
            count += 1
    session.commit()
    logger.info("Loaded %d metadata record(s)", count)
    return count


def sync_metadata_relationships_from_payload(
    session: Any,
    meta: MetadataRecordModel,
    set_sqlite_timestamps_fn: Any,
) -> None:
    """Sync join tables from payload; clears existing first."""
    payload = meta.payload
    if not payload or not isinstance(payload, dict):
        return
    view = relationship_view(payload)
    mid = meta.id
    if mid is None:
        return
    for model_class in (
        *_OWNERSHIP_MODELS,
        *_LINEAGE_MODELS,
        MetadataRecordDomain,
        MetadataRecordStorageLocation,
        MetadataRecordEnvironment,
    ):
        session.query(model_class).filter_by(metadata_record_id=mid).delete()
    for rel_type, model_class in zip(OWNERSHIP_KEYS, _OWNERSHIP_MODELS, strict=False):
        for owner_id in view.get(rel_type) or []:
            if isinstance(owner_id, str):
                link = model_class(
                    id=uuid.uuid4(), metadata_record_id=mid, owner_id=owner_id
                )
                set_sqlite_timestamps_fn(session, link)
                session.add(link)
    with session.no_autoflush:
        system_by_name = {s.name: s.id for s in session.query(SystemModel).all()}
    for rel_type, model_class in zip(LINEAGE_KEYS, _LINEAGE_MODELS, strict=False):
        for name in view.get(rel_type) or []:
            if isinstance(name, str) and name in system_by_name:
                link = model_class(
                    id=uuid.uuid4(),
                    metadata_record_id=mid,
                    system_id=system_by_name[name],
                )
                set_sqlite_timestamps_fn(session, link)
                session.add(link)
    domain_name = view.get("domain")
    if isinstance(domain_name, str):
        with session.no_autoflush:
            domain = session.query(DomainModel).filter_by(name=domain_name).first()
        if domain:
            link = MetadataRecordDomain(
                id=uuid.uuid4(), metadata_record_id=mid, domain_id=domain.id
            )
            set_sqlite_timestamps_fn(session, link)
            session.add(link)
    with session.no_autoflush:
        storage_by_name = {
            s.name: s.id for s in session.query(StorageLocationModel).all()
        }
    for entry in view.get("storage_locations") or []:
        name = entry.get("name", entry) if isinstance(entry, dict) else entry
        usage_type = entry.get("usage_type") if isinstance(entry, dict) else None
        if isinstance(name, str) and name in storage_by_name:
            link = MetadataRecordStorageLocation(
                id=uuid.uuid4(),
                metadata_record_id=mid,
                storage_location_id=storage_by_name[name],
                usage_type=usage_type,
            )
            set_sqlite_timestamps_fn(session, link)
            session.add(link)
    with session.no_autoflush:
        env_by_name = {e.name: e.id for e in session.query(EnvironmentModel).all()}
    for env_name in view.get("environments") or []:
        if isinstance(env_name, str) and env_name in env_by_name:
            link = MetadataRecordEnvironment(
                id=uuid.uuid4(),
                metadata_record_id=mid,
                environment_id=env_by_name[env_name],
            )
            set_sqlite_timestamps_fn(session, link)
            session.add(link)
    session.flush()
