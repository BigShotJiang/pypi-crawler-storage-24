"""Semantic field graph seeding: fields, field-concept links, and field relationships."""

from __future__ import annotations

import logging
from typing import Any

try:
    import yaml  # type: ignore[import-untyped]
except ImportError:
    pass

from pathlib import Path

from pycharter.db._seed_core import _set_sqlite_timestamps
from pycharter.db.models.semantic.concept import ConceptModel
from pycharter.db.models.semantic.field import FieldModel
from pycharter.db.models.semantic.field_concept import FieldConceptModel
from pycharter.db.models.semantic.field_relationship import FieldRelationshipModel

logger = logging.getLogger(__name__)


def _iter_mapping_bindings(fields: dict[str, Any]) -> list[tuple[str, dict[str, Any]]]:
    """Normalize field mapping shape to list[(field_name, binding)]."""
    out: list[tuple[str, dict[str, Any]]] = []
    for field_name, field_payload in fields.items():
        if isinstance(field_payload, dict):
            out.append((field_name, field_payload))
        elif isinstance(field_payload, list):
            for item in field_payload:
                if isinstance(item, dict):
                    out.append((field_name, item))
    return out


def _seed_semantic_field_graph(seed_path: Path, session: Any) -> int:
    """Materialize ontology mappings into semantic field graph tables.

    Creates/updates fields, field_concepts, and field_relationships so
    Concepts/Discovery/Lineage pages have rich data in fresh environments.

    Args:
        seed_path: Directory containing seed YAML files.
        session: SQLAlchemy session.

    Returns:
        Total number of items created.
    """
    mappings_file = seed_path / "ontology_mappings.yaml"
    if not mappings_file.exists():
        return 0

    with open(mappings_file) as f:
        data = yaml.safe_load(f) or []
    if not isinstance(data, list) or not data:
        return 0

    concept_rows = session.query(
        ConceptModel.id, ConceptModel.name, ConceptModel.concept_key
    ).all()
    concept_by_ref: dict[str, Any] = {}
    for cid, name, concept_key in concept_rows:
        if isinstance(name, str):
            concept_by_ref[name] = cid
        if isinstance(concept_key, str):
            concept_by_ref[concept_key] = cid

    fields_created = 0
    field_links_created = 0
    relationships_created = 0
    field_lookup: dict[tuple[str, str], Any] = {}

    for entry in data:
        if not isinstance(entry, dict):
            continue
        contract_name = entry.get("contract_name")
        fields = entry.get("fields")
        if not isinstance(contract_name, str) or not isinstance(fields, dict):
            continue

        for field_name, binding in _iter_mapping_bindings(fields):
            existing_field = (
                session.query(FieldModel)
                .filter_by(contract_id=contract_name, name=field_name)
                .first()
            )
            if existing_field is None:
                existing_field = FieldModel(
                    contract_id=contract_name,
                    name=field_name,
                    business_definition=(
                        binding.get("definition")
                        if isinstance(binding.get("definition"), str)
                        else None
                    ),
                    created_by="seed",
                )
                _set_sqlite_timestamps(session, existing_field)
                session.add(existing_field)
                session.flush()
                fields_created += 1
            field_lookup[(contract_name, field_name)] = existing_field.id

            concept_ref = binding.get("concept_id") or binding.get("concept")
            if isinstance(concept_ref, str):
                concept_id = concept_by_ref.get(concept_ref)
                if concept_id is not None:
                    existing_link = (
                        session.query(FieldConceptModel)
                        .filter_by(field_id=existing_field.id, concept_id=concept_id)
                        .first()
                    )
                    if existing_link is None:
                        session.add(
                            FieldConceptModel(
                                field_id=existing_field.id,
                                concept_id=concept_id,
                            )
                        )
                        field_links_created += 1

    for entry in data:
        if not isinstance(entry, dict):
            continue
        contract_name = entry.get("contract_name")
        fields = entry.get("fields")
        if not isinstance(contract_name, str) or not isinstance(fields, dict):
            continue
        for field_name, binding in _iter_mapping_bindings(fields):
            source_id = field_lookup.get((contract_name, field_name))
            if source_id is None:
                continue
            rels = binding.get("relationships")
            if not isinstance(rels, list):
                continue
            for rel in rels:
                if not isinstance(rel, dict):
                    continue
                target = rel.get("target")
                if not isinstance(target, str) or not target.strip():
                    continue
                relationship_type = rel.get("type")
                rel_type = (
                    relationship_type
                    if isinstance(relationship_type, str)
                    else "related_to"
                )
                target_contract = contract_name
                target_field = target
                if "." in target:
                    target_contract, target_field = target.rsplit(".", 1)
                target_id = field_lookup.get((target_contract, target_field))
                if target_id is None:
                    continue
                existing_rel = (
                    session.query(FieldRelationshipModel)
                    .filter_by(
                        source_field_id=source_id,
                        target_field_id=target_id,
                        relationship_type=rel_type,
                    )
                    .first()
                )
                if existing_rel is not None:
                    continue
                session.add(
                    FieldRelationshipModel(
                        source_field_id=source_id,
                        target_field_id=target_id,
                        relationship_type=rel_type,
                        created_by="seed",
                    )
                )
                relationships_created += 1

    session.commit()
    logger.info(
        "Loaded semantic field graph (%d fields, %d field-concept links, "
        "%d field relationships)",
        fields_created,
        field_links_created,
        relationships_created,
    )
    return fields_created + field_links_created + relationships_created
