"""
Canonical database session factory for pycharter.

All code that needs an SQLAlchemy engine or session should import from this
module.  Engines are cached per connection URL, and ``sessionmaker`` factories
are created once per engine.

Usage::

    from pycharter.db.session import get_engine, get_session, get_session_factory

    # One-shot session (caller must close):
    session = get_session()

    # FastAPI dependency (via sessionmaker):
    factory = get_session_factory(db_url)
    session = factory()

    # Direct engine access (migrations, schema ops):
    engine = get_engine(db_url)
"""

from __future__ import annotations

import logging
from typing import Any

from sqlalchemy import create_engine, event
from sqlalchemy.orm import Session, sessionmaker

from pycharter.db.models.base import Base  # noqa: F401 — re-export for consumers

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Internal caches
# ---------------------------------------------------------------------------
_engines: dict[str, Any] = {}
_session_factories: dict[str, sessionmaker] = {}


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def get_database_url() -> str:
    """Resolve the database URL from environment or config file.

    Priority:
        1. ``PYCHARTER_DATABASE_URL`` environment variable
        2. ``pycharter.cfg`` ``[database] url`` value
        3. Default SQLite fallback
    """
    from pycharter.config import get_database_url as _cfg_url

    return _cfg_url()


def get_engine(db_url: str | None = None) -> Any:
    """Get or create a cached SQLAlchemy engine.

    Engines are cached per URL so repeated calls reuse the same pool.
    SQLite-specific event listeners (schema-prefix stripping, PRAGMA
    foreign_keys) are automatically attached.

    Args:
        db_url: Database URL.  Defaults to :func:`get_database_url`.

    Returns:
        A ``sqlalchemy.Engine`` instance.
    """
    if db_url is None:
        db_url = get_database_url()

    # In-memory SQLite databases are unique per connection — never cache them
    # so tests and callers each get an isolated database.
    if db_url == "sqlite:///:memory:":
        return _create_engine(db_url)

    if db_url in _engines:
        return _engines[db_url]

    engine = _create_engine(db_url)
    _engines[db_url] = engine
    logger.debug("created engine for %s", _redact_url(db_url))
    return engine


def get_session_factory(db_url: str | None = None) -> sessionmaker:
    """Get or create a cached ``sessionmaker`` bound to the engine.

    Args:
        db_url: Database URL.  Defaults to :func:`get_database_url`.

    Returns:
        A ``sessionmaker`` instance.
    """
    if db_url is None:
        db_url = get_database_url()

    # In-memory SQLite: always create fresh factory (matches get_engine behavior)
    if db_url == "sqlite:///:memory:":
        engine = get_engine(db_url)
        return sessionmaker(bind=engine)

    if db_url in _session_factories:
        return _session_factories[db_url]

    engine = get_engine(db_url)
    factory = sessionmaker(bind=engine)
    _session_factories[db_url] = factory
    return factory


def get_session(db_url: str | None = None) -> Session:
    """Create a new session.  Caller is responsible for closing it.

    Args:
        db_url: Database URL.  Defaults to :func:`get_database_url`.

    Returns:
        A fresh ``Session`` instance.
    """
    factory = get_session_factory(db_url)
    return factory()


def get_schema_prefix(db_url: str) -> str:
    """Return the schema prefix for raw SQL table references.

    Postgres → ``'pycharter.'``; SQLite → ``''``.
    """
    if db_url.startswith("sqlite://"):
        return ""
    return "pycharter."


def dispose_all() -> None:
    """Dispose all cached engines and clear caches.

    Useful in tests or worker shutdown.
    """
    for engine in _engines.values():
        engine.dispose()
    _engines.clear()
    _session_factories.clear()


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _create_engine(db_url: str) -> Any:
    """Create a new SQLAlchemy engine with the correct settings."""
    if db_url.startswith("sqlite://"):
        connect_args: dict[str, Any] = {}
        if db_url != "sqlite:///:memory:":
            connect_args["check_same_thread"] = False

        engine = create_engine(db_url, echo=False, connect_args=connect_args)

        @event.listens_for(engine, "connect")
        def _set_sqlite_pragma(dbapi_conn, connection_record):
            """Enable foreign keys on SQLite."""
            cursor = dbapi_conn.cursor()
            cursor.execute("PRAGMA foreign_keys=ON")
            cursor.close()

        @event.listens_for(engine, "before_cursor_execute", retval=True)
        def _strip_schema_prefix(conn, cursor, stmt, params, ctx, executemany):
            """Remove ``pycharter.`` schema prefix for SQLite compatibility."""
            stmt = stmt.replace('"pycharter".', "").replace("pycharter.", "")
            return stmt, params

        return engine

    return create_engine(db_url, echo=False)


def _redact_url(db_url: str) -> str:
    """Redact credentials from a database URL for logging."""
    if "@" in db_url:
        scheme_rest = db_url.split("://", 1)
        if len(scheme_rest) == 2:
            after_at = scheme_rest[1].split("@", 1)
            if len(after_at) == 2:
                return f"{scheme_rest[0]}://***@{after_at[1]}"
    return db_url
