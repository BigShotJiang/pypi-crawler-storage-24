"""Squashed schema (single migration).

Revision ID: squashed_root
Revises: None
Create Date: 2026-03-17 00:00:00

Single migration that creates the full current schema from SQLAlchemy models,
including ontology_configs and etl_pipeline_configs (steps-native). All tables
are created via Base.metadata.create_all() after ensuring the pycharter schema
exists (PostgreSQL). create_all() is idempotent: existing tables are skipped.
"""

from __future__ import annotations

from collections.abc import Sequence

from alembic import op
from sqlalchemy import text

from pycharter.db.migrations.schema_helper import get_schema

# revision identifiers, used by Alembic.
revision: str = "squashed_root"
down_revision: str | None = None
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None


def upgrade() -> None:
    bind = op.get_bind()
    schema = get_schema(bind)

    # PostgreSQL: create schema first
    if schema:
        bind.execute(text(f'CREATE SCHEMA IF NOT EXISTS "{schema}"'))

    # Import all models so Base.metadata has every table (main + semantic, including ontology_schema)
    import pycharter.db.models  # noqa: F401
    import pycharter.db.models.semantic  # noqa: F401
    from pycharter.db.models.base import Base

    # SQLite: tables must not have schema="pycharter" or create_all will fail
    if schema is None:
        for table in Base.metadata.tables.values():
            if table.schema == "pycharter":
                table.schema = None

    Base.metadata.create_all(bind)


def downgrade() -> None:
    import pycharter.db.models  # noqa: F401
    import pycharter.db.models.semantic  # noqa: F401
    from pycharter.db.models.base import Base

    bind = op.get_bind()
    schema = get_schema(bind)

    if schema is None:
        for table in Base.metadata.tables.values():
            if table.schema == "pycharter":
                table.schema = None

    Base.metadata.drop_all(bind)

    # PostgreSQL: drop schema
    if schema:
        bind.execute(text(f'DROP SCHEMA IF EXISTS "{schema}" CASCADE'))
