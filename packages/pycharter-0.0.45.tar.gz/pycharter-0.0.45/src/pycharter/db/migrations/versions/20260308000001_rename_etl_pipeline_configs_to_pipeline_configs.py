"""Rename etl_pipeline_configs to pipeline_configs.

Revision ID: rename_etl_to_pipeline
Revises: squashed_root
Create Date: 2026-03-08

Renames table etl_pipeline_configs to pipeline_configs and the unique
constraint uq_etl_pipeline_configs_name_version to uq_pipeline_configs_name_version.
"""

from __future__ import annotations

from collections.abc import Sequence

from alembic import op
from sqlalchemy import text

# revision identifiers, used by Alembic.
revision: str = "rename_etl_to_pipeline"
down_revision: str | None = "squashed_root"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None

SCHEMA = "pycharter"
OLD_TABLE = "etl_pipeline_configs"
NEW_TABLE = "pipeline_configs"
OLD_CONSTRAINT = "uq_etl_pipeline_configs_name_version"
NEW_CONSTRAINT = "uq_pipeline_configs_name_version"


def upgrade() -> None:
    bind = op.get_bind()
    url = str(bind.engine.url)
    if "sqlite" in url:
        schema = None
    else:
        schema = SCHEMA

    op.rename_table(OLD_TABLE, NEW_TABLE, schema=schema)

    if "sqlite" not in url:
        qual_new = f"{schema}.{NEW_TABLE}"
        bind.execute(
            text(
                f'ALTER TABLE {qual_new} RENAME CONSTRAINT "{OLD_CONSTRAINT}" TO "{NEW_CONSTRAINT}"'
            )
        )


def downgrade() -> None:
    bind = op.get_bind()
    url = str(bind.engine.url)
    if "sqlite" in url:
        schema = None
    else:
        schema = SCHEMA

    if "sqlite" not in url:
        qual_new = f"{schema}.{NEW_TABLE}"
        bind.execute(
            text(
                f'ALTER TABLE {qual_new} RENAME CONSTRAINT "{NEW_CONSTRAINT}" TO "{OLD_CONSTRAINT}"'
            )
        )

    op.rename_table(NEW_TABLE, OLD_TABLE, schema=schema)
