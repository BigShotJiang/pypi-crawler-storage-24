"""Field binding and relationship validators for data contract schema.

Contains the field-binding-related Pydantic models with their custom
field validators and model validators.
"""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel, Field, field_validator, model_validator

from pycharter.semantic.ontology.normalizer import normalize_field_mapping
from pycharter.semantic.ontology.schema_loader import validate_relationship_type


class FieldBindingLineageValidator(BaseModel):
    """Optional lineage metadata for a field binding."""

    derived_from: str | None = Field(
        None,
        description="Upstream field path used for derivation",
    )
    source_system: str | None = Field(
        None,
        description="Source system for this value",
    )

    model_config = {
        "extra": "allow",
    }


class FieldBindingRelationshipValidator(BaseModel):
    """Relationship from a field binding to another field or concept."""

    type: str = Field(..., description="Relationship type from knowledge schema")
    target_field: str | None = Field(
        None,
        description="Target JSONPath field (preferred for field-level links)",
    )
    target_concept_id: str | None = Field(
        None,
        description="Target concept id (for concept-level links)",
    )

    @field_validator("type")
    @classmethod
    def validate_type(cls, v: str) -> str:
        """Ensure relationship type is declared in knowledge schema."""
        if not validate_relationship_type(v):
            raise ValueError(f"Unknown relationship type '{v}'")
        return v

    @model_validator(mode="after")
    def validate_target(self):
        """Ensure at least one relationship target is present."""
        if not self.target_field and not self.target_concept_id:
            raise ValueError(
                "Relationship must include target_field or target_concept_id"
            )
        return self

    model_config = {
        "extra": "allow",
    }


class FieldBindingValidator(BaseModel):
    """Canonical field-to-concept binding (many-to-many)."""

    concept: str = Field(..., description="Concept identifier from registry")
    confidence: str | None = Field(
        None,
        description="Optional confidence label: low, medium, high",
    )
    tags: list[str] = Field(default_factory=list, description="Additional field tags")
    owner: str | None = Field(None, description="Owning team/person for mapping")
    description: str | None = Field(None, description="Mapping notes")
    deprecated: bool = Field(False, description="Whether this mapping is deprecated")
    lineage: FieldBindingLineageValidator | None = Field(
        None, description="Lineage for this mapping"
    )
    relationships: list[FieldBindingRelationshipValidator] = Field(
        default_factory=list,
        description="Relationships from this binding to other fields/concepts",
    )

    @field_validator("concept")
    @classmethod
    def validate_concept(cls, v: str) -> str:
        """Validate that concept is non-empty."""
        if not v or not v.strip():
            raise ValueError("concept must be a non-empty string")
        return v.strip()

    @field_validator("confidence")
    @classmethod
    def validate_confidence(cls, v: str | None) -> str | None:
        """Validate confidence level is one of low, medium, high."""
        if v is None:
            return v
        normalized = v.strip().lower()
        if normalized not in {"low", "medium", "high"}:
            raise ValueError("confidence must be one of: low, medium, high")
        return normalized

    model_config = {
        "extra": "allow",
    }


class FieldMappingComponent(BaseModel):
    """Field mapping component - semantic field annotations (optional).

    Stored in semantic tables (concepts, fields, field_relationships).
    Defines what each field means in the business domain.
    """

    version: str | None = Field(
        None, max_length=50, description="Field mapping version"
    )
    field_bindings: dict[str, list[FieldBindingValidator]] | None = Field(
        None,
        description="Canonical JSONPath field bindings (many-to-many)",
    )
    fields: dict[str, Any] | None = Field(
        None,
        description="Legacy field-level ontology annotations (normalized to field_bindings)",
    )

    @model_validator(mode="before")
    @classmethod
    def normalize_legacy_payload(cls, value: Any) -> Any:
        """Accept legacy ontology payload and normalize to canonical shape."""
        if not isinstance(value, dict):
            return value
        normalized, _warnings = normalize_field_mapping(value)
        return normalized

    @field_validator("field_bindings")
    @classmethod
    def validate_jsonpath_keys(
        cls,
        v: dict[str, list[FieldBindingValidator]] | None,
    ) -> dict[str, list[FieldBindingValidator]] | None:
        """Validate that all field_bindings keys are JSONPath expressions."""
        if v is None:
            return v
        for key in v:
            if not key.startswith("$"):
                raise ValueError(
                    f"field_bindings key '{key}' must be JSONPath and start with '$'"
                )
        return v

    model_config = {
        "extra": "allow",
    }
