"""SQLAlchemy model for field_mappings table.

Stores versioned field mapping artifacts that map data contract fields
to ontology concepts.  The ``mapping_data`` JSON column holds the
serialised output of ``FieldMapping.to_dict()``.
"""

from __future__ import annotations

import uuid

from sqlalchemy import JSON, Column, DateTime, ForeignKey, String, UniqueConstraint
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func

from pycharter.db.models.base import Base


class FieldMappingModel(Base):
    """SQLAlchemy model for field_mappings table."""

    __tablename__ = "field_mappings"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)

    # Basic Information
    title = Column(String(255), nullable=False)
    data_contract_id = Column(
        UUID(as_uuid=True),
        ForeignKey("pycharter.data_contracts.id", ondelete="CASCADE"),
        nullable=False,
    )
    description = Column(String(500), nullable=True)
    version = Column(String(50), nullable=False)

    # Field mapping payload (field_bindings, domain_schema, etc.)
    mapping_data = Column(JSON, nullable=False)

    # Audit fields
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(
        DateTime(timezone=True), server_default=func.now(), onupdate=func.now()
    )

    __table_args__ = (
        UniqueConstraint("title", "version", name="uq_field_mappings_title_version"),
        {"schema": "pycharter"},
    )

    # Relationships
    data_contract = relationship("DataContractModel", foreign_keys=[data_contract_id])
