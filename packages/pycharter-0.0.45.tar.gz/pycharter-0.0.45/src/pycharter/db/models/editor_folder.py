"""SQLAlchemy models for the editor folder system.

Provides a generic, self-contained virtual file system that organises
arbitrary external items (schemas, ontology concepts, etc.) into a
hierarchical folder tree.  The two models are fully decoupled from
domain tables — items are referenced by ``(item_type, item_id)`` in a
join table so no existing models need modification.
"""

from __future__ import annotations

import uuid

from sqlalchemy import (
    JSON,
    Column,
    DateTime,
    ForeignKey,
    Integer,
    String,
    UniqueConstraint,
)
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func

from pycharter.db.models.base import Base


class EditorFolderModel(Base):
    """A folder node in the editor virtual file system.

    Folders form an adjacency-list tree via *parent_id*.  Each folder
    belongs to exactly one ``folder_type`` root (e.g. ``'contract'`` or
    ``'ontology'``) so the two trees never intermix.
    """

    __tablename__ = "editor_folders"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    name = Column(String(255), nullable=False)
    parent_id = Column(
        UUID(as_uuid=True),
        ForeignKey("pycharter.editor_folders.id", ondelete="CASCADE"),
        nullable=True,
        index=True,
    )
    folder_type = Column(String(50), nullable=False, index=True)
    position = Column(Integer, nullable=False, default=0)

    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(
        DateTime(timezone=True), server_default=func.now(), onupdate=func.now()
    )

    # Self-referential relationship
    parent = relationship("EditorFolderModel", remote_side=[id])
    items = relationship(
        "EditorFolderItemModel",
        back_populates="folder",
        cascade="all, delete-orphan",
    )

    __table_args__ = (
        UniqueConstraint(
            "parent_id",
            "name",
            "folder_type",
            name="uq_editor_folders_parent_name_type",
        ),
        {"schema": "pycharter"},
    )


class EditorFolderItemModel(Base):
    """Maps an external item into a folder by ``(item_type, item_id)``.

    The *item_label* and *item_meta* columns cache display information
    so the tree can be rendered without joining to domain tables.
    """

    __tablename__ = "editor_folder_items"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    folder_id = Column(
        UUID(as_uuid=True),
        ForeignKey("pycharter.editor_folders.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )
    item_type = Column(String(50), nullable=False)
    item_id = Column(String(255), nullable=False)
    item_label = Column(String(255), nullable=False, default="")
    item_meta = Column(JSON, nullable=True)
    position = Column(Integer, nullable=False, default=0)

    folder = relationship("EditorFolderModel", back_populates="items")

    __table_args__ = (
        UniqueConstraint(
            "item_type",
            "item_id",
            name="uq_editor_folder_items_type_id",
        ),
        {"schema": "pycharter"},
    )
