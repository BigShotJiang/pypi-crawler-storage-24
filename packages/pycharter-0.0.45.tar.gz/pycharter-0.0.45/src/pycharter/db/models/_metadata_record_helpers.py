"""Join-table models for metadata_records many-to-many relationships."""

from __future__ import annotations

import uuid

from sqlalchemy import (
    Column,
    DateTime,
    ForeignKey,
    String,
    UniqueConstraint,
)
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func

from pycharter.db.models.base import Base


class MetadataRecordSystemPull(Base):
    """Join table for metadata_records and systems (pulls_from relationship)."""

    __tablename__ = "metadata_record_system_pulls"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    metadata_record_id = Column(
        UUID(as_uuid=True),
        ForeignKey("pycharter.metadata_records.id", ondelete="CASCADE"),
        nullable=False,
    )
    system_id = Column(
        UUID(as_uuid=True),
        ForeignKey("pycharter.systems.id", ondelete="CASCADE"),
        nullable=False,
    )
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    __table_args__ = (
        UniqueConstraint("metadata_record_id", "system_id", name="uq_mr_system_pull"),
        {"schema": "pycharter"},
    )

    metadata_record = relationship("MetadataRecordModel", back_populates="system_pulls")
    system = relationship("SystemModel", back_populates="metadata_pulls")


class MetadataRecordSystemPush(Base):
    """Join table for metadata_records and systems (pushes_to relationship)."""

    __tablename__ = "metadata_record_system_pushes"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    metadata_record_id = Column(
        UUID(as_uuid=True),
        ForeignKey("pycharter.metadata_records.id", ondelete="CASCADE"),
        nullable=False,
    )
    system_id = Column(
        UUID(as_uuid=True),
        ForeignKey("pycharter.systems.id", ondelete="CASCADE"),
        nullable=False,
    )
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    __table_args__ = (
        UniqueConstraint("metadata_record_id", "system_id", name="uq_mr_system_push"),
        {"schema": "pycharter"},
    )

    metadata_record = relationship(
        "MetadataRecordModel", back_populates="system_pushes"
    )
    system = relationship("SystemModel", back_populates="metadata_pushes")


class MetadataRecordSystemSource(Base):
    """Join table for metadata_records and systems (system_sources relationship)."""

    __tablename__ = "metadata_record_system_sources"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    metadata_record_id = Column(
        UUID(as_uuid=True),
        ForeignKey("pycharter.metadata_records.id", ondelete="CASCADE"),
        nullable=False,
    )
    system_id = Column(
        UUID(as_uuid=True),
        ForeignKey("pycharter.systems.id", ondelete="CASCADE"),
        nullable=False,
    )
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    __table_args__ = (
        UniqueConstraint("metadata_record_id", "system_id", name="uq_mr_system_source"),
        {"schema": "pycharter"},
    )

    metadata_record = relationship(
        "MetadataRecordModel", back_populates="system_sources_rel"
    )
    system = relationship("SystemModel", back_populates="metadata_sources")


class MetadataRecordDomain(Base):
    """Join table for metadata_records and domains."""

    __tablename__ = "metadata_record_domains"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    metadata_record_id = Column(
        UUID(as_uuid=True),
        ForeignKey("pycharter.metadata_records.id", ondelete="CASCADE"),
        nullable=False,
    )
    domain_id = Column(
        UUID(as_uuid=True),
        ForeignKey("pycharter.domains.id", ondelete="CASCADE"),
        nullable=False,
    )
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    __table_args__ = (
        UniqueConstraint("metadata_record_id", "domain_id", name="uq_mr_domain"),
        {"schema": "pycharter"},
    )

    metadata_record = relationship("MetadataRecordModel", back_populates="domains_rel")
    domain = relationship("DomainModel", back_populates="metadata_records")


class MetadataRecordBusinessOwner(Base):
    """Join table for metadata_records and owners (business_owners relationship)."""

    __tablename__ = "metadata_record_business_owners"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    metadata_record_id = Column(
        UUID(as_uuid=True),
        ForeignKey("pycharter.metadata_records.id", ondelete="CASCADE"),
        nullable=False,
    )
    owner_id = Column(
        String(255),
        ForeignKey("pycharter.owners.id", ondelete="CASCADE"),
        nullable=False,
    )
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    __table_args__ = (
        UniqueConstraint("metadata_record_id", "owner_id", name="uq_mr_business_owner"),
        {"schema": "pycharter"},
    )

    metadata_record = relationship(
        "MetadataRecordModel", back_populates="business_owners_rel"
    )
    owner = relationship("OwnerModel", back_populates="business_owner_metadata_records")


class MetadataRecordBUSME(Base):
    """Join table for metadata_records and owners (bu_sme relationship)."""

    __tablename__ = "metadata_record_bu_sme"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    metadata_record_id = Column(
        UUID(as_uuid=True),
        ForeignKey("pycharter.metadata_records.id", ondelete="CASCADE"),
        nullable=False,
    )
    owner_id = Column(
        String(255),
        ForeignKey("pycharter.owners.id", ondelete="CASCADE"),
        nullable=False,
    )
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    __table_args__ = (
        UniqueConstraint("metadata_record_id", "owner_id", name="uq_mr_bu_sme"),
        {"schema": "pycharter"},
    )

    metadata_record = relationship("MetadataRecordModel", back_populates="bu_sme_rel")
    owner = relationship("OwnerModel", back_populates="bu_sme_metadata_records")


class MetadataRecordITApplicationOwner(Base):
    """Join table for metadata_records and owners (it_application_owners relationship)."""

    __tablename__ = "metadata_record_it_application_owners"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    metadata_record_id = Column(
        UUID(as_uuid=True),
        ForeignKey("pycharter.metadata_records.id", ondelete="CASCADE"),
        nullable=False,
    )
    owner_id = Column(
        String(255),
        ForeignKey("pycharter.owners.id", ondelete="CASCADE"),
        nullable=False,
    )
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    __table_args__ = (
        UniqueConstraint(
            "metadata_record_id", "owner_id", name="uq_mr_it_application_owner"
        ),
        {"schema": "pycharter"},
    )

    metadata_record = relationship(
        "MetadataRecordModel", back_populates="it_application_owners_rel"
    )
    owner = relationship(
        "OwnerModel", back_populates="it_application_owner_metadata_records"
    )


class MetadataRecordITSME(Base):
    """Join table for metadata_records and owners (it_sme relationship)."""

    __tablename__ = "metadata_record_it_sme"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    metadata_record_id = Column(
        UUID(as_uuid=True),
        ForeignKey("pycharter.metadata_records.id", ondelete="CASCADE"),
        nullable=False,
    )
    owner_id = Column(
        String(255),
        ForeignKey("pycharter.owners.id", ondelete="CASCADE"),
        nullable=False,
    )
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    __table_args__ = (
        UniqueConstraint("metadata_record_id", "owner_id", name="uq_mr_it_sme"),
        {"schema": "pycharter"},
    )

    metadata_record = relationship("MetadataRecordModel", back_populates="it_sme_rel")
    owner = relationship("OwnerModel", back_populates="it_sme_metadata_records")


class MetadataRecordSupportLead(Base):
    """Join table for metadata_records and owners (support_lead relationship)."""

    __tablename__ = "metadata_record_support_lead"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    metadata_record_id = Column(
        UUID(as_uuid=True),
        ForeignKey("pycharter.metadata_records.id", ondelete="CASCADE"),
        nullable=False,
    )
    owner_id = Column(
        String(255),
        ForeignKey("pycharter.owners.id", ondelete="CASCADE"),
        nullable=False,
    )
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    __table_args__ = (
        UniqueConstraint("metadata_record_id", "owner_id", name="uq_mr_support_lead"),
        {"schema": "pycharter"},
    )

    metadata_record = relationship(
        "MetadataRecordModel", back_populates="support_lead_rel"
    )
    owner = relationship("OwnerModel", back_populates="support_lead_metadata_records")


class MetadataRecordEnvironment(Base):
    """Join table for metadata_records and environments."""

    __tablename__ = "metadata_record_environments"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    metadata_record_id = Column(
        UUID(as_uuid=True),
        ForeignKey("pycharter.metadata_records.id", ondelete="CASCADE"),
        nullable=False,
    )
    environment_id = Column(
        UUID(as_uuid=True),
        ForeignKey("pycharter.environments.id", ondelete="CASCADE"),
        nullable=False,
    )
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    __table_args__ = (
        UniqueConstraint(
            "metadata_record_id", "environment_id", name="uq_mr_environment"
        ),
        {"schema": "pycharter"},
    )

    metadata_record = relationship(
        "MetadataRecordModel", back_populates="environments_rel"
    )
    environment = relationship("EnvironmentModel", back_populates="metadata_records")


class MetadataRecordDataFeed(Base):
    """Join table for metadata_records and data_feeds."""

    __tablename__ = "metadata_record_data_feeds"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    metadata_record_id = Column(
        UUID(as_uuid=True),
        ForeignKey("pycharter.metadata_records.id", ondelete="CASCADE"),
        nullable=False,
    )
    data_feed_id = Column(
        UUID(as_uuid=True),
        ForeignKey("pycharter.data_feeds.id", ondelete="CASCADE"),
        nullable=False,
    )
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    __table_args__ = (
        UniqueConstraint("metadata_record_id", "data_feed_id", name="uq_mr_data_feed"),
        {"schema": "pycharter"},
    )

    metadata_record = relationship(
        "MetadataRecordModel", back_populates="data_feeds_rel"
    )
    data_feed = relationship("DataFeedModel", back_populates="metadata_records")
