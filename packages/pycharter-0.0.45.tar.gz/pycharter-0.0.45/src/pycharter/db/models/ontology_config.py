"""SQLAlchemy model for ontology_configs table.

Stores versioned ontology configurations as first-class artifacts.
Each record represents a frozen (ontology_name, ontology_version) pair
containing a canonical LinkML YAML document with denormalized metadata.
"""

from __future__ import annotations

import uuid

from sqlalchemy import Column, DateTime, String, Text, UniqueConstraint
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.sql import func

from pycharter.db.models.base import Base


class OntologyConfigModel(Base):
    """SQLAlchemy model for ontology_configs table."""

    __tablename__ = "ontology_configs"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)

    # Ontology identity
    ontology_name = Column(String(255), nullable=False, index=True)
    ontology_version = Column(String(50), nullable=False)

    # Canonical artifact
    linkml_yaml = Column(Text, nullable=False)

    # Lifecycle
    status = Column(String(50), nullable=True, default="active")
    description = Column(Text, nullable=True)

    # Denormalized from YAML for listing queries
    schema_id = Column(String(512), nullable=True)
    scheme_key = Column(String(255), nullable=True)

    # Audit fields
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(
        DateTime(timezone=True), server_default=func.now(), onupdate=func.now()
    )
    created_by = Column(String(255), nullable=True)
    updated_by = Column(String(255), nullable=True)

    __table_args__ = (
        UniqueConstraint(
            "ontology_name",
            "ontology_version",
            name="uq_ontology_configs_name_version",
        ),
        {"schema": "pycharter"},
    )
