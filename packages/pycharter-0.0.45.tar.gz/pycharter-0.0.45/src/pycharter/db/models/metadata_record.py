"""SQLAlchemy model for metadata_records table.

Re-export shim -- the actual definitions live in:
- ``_metadata_record_model`` (MetadataRecordModel)
- ``_metadata_record_helpers`` (join-table models)

All public names are re-exported here so that existing
``from pycharter.db.models.metadata_record import X`` imports
continue to work unchanged.
"""

from __future__ import annotations

from pycharter.db.models._metadata_record_helpers import (
    MetadataRecordBusinessOwner,
    MetadataRecordBUSME,
    MetadataRecordDataFeed,
    MetadataRecordDomain,
    MetadataRecordEnvironment,
    MetadataRecordITApplicationOwner,
    MetadataRecordITSME,
    MetadataRecordSupportLead,
    MetadataRecordSystemPull,
    MetadataRecordSystemPush,
    MetadataRecordSystemSource,
)
from pycharter.db.models._metadata_record_model import (
    MetadataRecordComplianceFramework,
    MetadataRecordModel,
    MetadataRecordStorageLocation,
)

__all__ = [
    "MetadataRecordModel",
    "MetadataRecordSystemPull",
    "MetadataRecordSystemPush",
    "MetadataRecordSystemSource",
    "MetadataRecordDomain",
    "MetadataRecordBusinessOwner",
    "MetadataRecordBUSME",
    "MetadataRecordITApplicationOwner",
    "MetadataRecordITSME",
    "MetadataRecordSupportLead",
    "MetadataRecordEnvironment",
    "MetadataRecordDataFeed",
    "MetadataRecordStorageLocation",
    "MetadataRecordComplianceFramework",
]
