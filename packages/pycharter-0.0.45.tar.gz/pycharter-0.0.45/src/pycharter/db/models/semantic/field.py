"""
SQLAlchemy model for fields table.

Fields represent data contract fields with their business definitions
and are linked to concepts via the field_concepts join table.
"""

from __future__ import annotations

import uuid

from sqlalchemy import Column, DateTime, String, Text
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.sql import func

from pycharter.db.models.base import Base


class FieldModel(Base):
    """SQLAlchemy model for fields table."""

    __tablename__ = "fields"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    contract_id = Column(String(255), nullable=False, index=True)
    name = Column(String(255), nullable=False)
    data_type = Column(String(100), nullable=True)
    business_definition = Column(Text, nullable=True)

    # Audit fields
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(
        DateTime(timezone=True), server_default=func.now(), onupdate=func.now()
    )
    created_by = Column(String(255), nullable=True)
    updated_by = Column(String(255), nullable=True)

    __table_args__ = ({"schema": "pycharter"},)
