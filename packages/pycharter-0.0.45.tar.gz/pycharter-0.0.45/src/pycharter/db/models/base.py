"""
Base SQLAlchemy declarative model and backward-compatible helpers.

New code should import from :mod:`pycharter.db.session` instead.
"""

from __future__ import annotations

from sqlalchemy.orm import declarative_base

Base = declarative_base()


# ---------------------------------------------------------------------------
# Backward-compatible re-exports — delegates to pycharter.db.session
# ---------------------------------------------------------------------------


def get_engine(connection_string: str):
    """Create or retrieve a cached SQLAlchemy engine.

    .. deprecated::
        Import :func:`pycharter.db.session.get_engine` directly.
    """
    from pycharter.db.session import get_engine as _get_engine

    return _get_engine(connection_string)


def get_schema_prefix(connection_string: str) -> str:
    """Return schema prefix for raw SQL table references.

    .. deprecated::
        Import :func:`pycharter.db.session.get_schema_prefix` directly.
    """
    from pycharter.db.session import get_schema_prefix as _get_prefix

    return _get_prefix(connection_string)


def get_session(connection_string: str):
    """Create a new SQLAlchemy session.

    .. deprecated::
        Import :func:`pycharter.db.session.get_session` directly.
    """
    from pycharter.db.session import get_session as _get_session

    return _get_session(connection_string)
