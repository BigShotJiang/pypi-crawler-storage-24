"""CLI for database management: init, upgrade, downgrade, seed, truncate.

Pattern: airflow db init / airflow db upgrade.  Delegates URL and
Alembic to ``db.config``, seed to ``db.seed``, and command implementations
to ``db._cli_commands``.
"""

from __future__ import annotations

import argparse
import sys

from pycharter.db._cli_commands import (
    cmd_current,
    cmd_downgrade,
    cmd_history,
    cmd_init,
    cmd_stamp,
    cmd_truncate,
    cmd_upgrade,
)
from pycharter.db.seed import cmd_seed

# ---------------------------------------------------------------------------
# Argparse setup
# ---------------------------------------------------------------------------


def _build_parser() -> argparse.ArgumentParser:
    """Build the argparse parser with all db sub-commands.

    Returns:
        Configured ArgumentParser.
    """
    parser = argparse.ArgumentParser(
        description="PyCharter database management commands",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    sub = parser.add_subparsers(dest="command", help="Command to run")

    # init
    init_p = sub.add_parser("init", help="Initialize database schema from scratch")
    init_p.add_argument(
        "database_url",
        nargs="?",
        help="Database connection string (defaults to sqlite:///pycharter.db)",
    )
    init_p.add_argument(
        "--db",
        "--database-type",
        dest="db_type",
        choices=["postgresql", "postgres", "mongodb", "sqlite"],
        default=None,
        help="Database type (auto-detected from URL if not provided)",
    )
    init_p.add_argument(
        "--force", action="store_true", help="Proceed even if initialized"
    )

    # upgrade
    upgrade_p = sub.add_parser("upgrade", help="Upgrade database to latest revision")
    upgrade_p.add_argument("database_url", nargs="?", help="Database connection string")
    upgrade_p.add_argument("--revision", default="head", help="Target revision")

    # downgrade
    downgrade_p = sub.add_parser("downgrade", help="Downgrade database")
    downgrade_p.add_argument(
        "database_url", nargs="?", help="Database connection string"
    )
    downgrade_p.add_argument("--revision", default="-1", help="Target revision")

    # current
    current_p = sub.add_parser("current", help="Show current database revision")
    current_p.add_argument("database_url", nargs="?", help="Database connection string")

    # history
    history_p = sub.add_parser("history", help="Show migration history")
    history_p.add_argument("database_url", nargs="?", help="Database connection string")

    # stamp
    stamp_p = sub.add_parser("stamp", help="Stamp database with revision")
    stamp_p.add_argument(
        "revision", nargs="?", default="head", help="Revision to stamp"
    )
    stamp_p.add_argument("database_url", nargs="?", help="Database connection string")

    # seed
    seed_p = sub.add_parser("seed", help="Seed database with initial data")
    seed_p.add_argument("seed_dir", nargs="?", help="Directory with seed YAML files")
    seed_p.add_argument("database_url", nargs="?", help="Database connection string")

    # truncate
    truncate_p = sub.add_parser("truncate", help="Truncate all tables")
    truncate_p.add_argument(
        "database_url", nargs="?", help="Database connection string"
    )
    truncate_p.add_argument("--force", action="store_true", help="Skip confirmation")

    return parser


# ---------------------------------------------------------------------------
# Entrypoint
# ---------------------------------------------------------------------------


def main() -> int:
    """Main CLI entry point for pycharter db commands."""
    parser = _build_parser()
    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        return 1

    commands = {
        "init": lambda: cmd_init(
            args.database_url, db_type=args.db_type, force=args.force
        ),
        "upgrade": lambda: cmd_upgrade(args.database_url, args.revision),
        "downgrade": lambda: cmd_downgrade(args.database_url, args.revision),
        "current": lambda: cmd_current(args.database_url),
        "history": lambda: cmd_history(args.database_url),
        "stamp": lambda: cmd_stamp(args.database_url, args.revision),
        "seed": lambda: cmd_seed(args.seed_dir, args.database_url),
        "truncate": lambda: cmd_truncate(args.database_url, force=args.force),
    }
    return commands.get(args.command, lambda: (parser.print_help(), 1)[1])()


if __name__ == "__main__":
    sys.exit(main())
