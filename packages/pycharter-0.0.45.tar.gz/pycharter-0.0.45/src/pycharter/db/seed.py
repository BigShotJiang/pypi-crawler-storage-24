"""Seed database — single entry point for all data seeding.

Provides ``seed_all()`` as the unified function that seeds reference data,
contract artifacts, pipeline configs, and semantic layer data from
YAML files in a seed directory.

Also supports MongoDB seeding and the ``pycharter db seed`` CLI entry point.
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any

try:
    import yaml  # type: ignore[import-untyped]

    YAML_AVAILABLE = True
except ImportError:
    YAML_AVAILABLE = False

from pycharter.db._seed_core import seed_contract_artifacts, seed_model
from pycharter.db._seed_pipeline_configs import _seed_pipeline_configs
from pycharter.db._seed_semantic import (
    _seed_concept_relationships,
    _seed_concepts,
    _seed_ontologies,
    _seed_semantic_field_graph,
    _seed_semantic_proposals,
)
from pycharter.db.config import get_db_url, require_alembic
from pycharter.db.models import (
    ComplianceFrameworkModel,
    DataFeedModel,
    DomainModel,
    EnvironmentModel,
    OwnerModel,
    SystemModel,
    TagModel,
)
from pycharter.db.models.base import get_session

logger = logging.getLogger(__name__)


def seed_all(seed_path: Path, db_url: str) -> int:
    """Seed all data from YAML files in seed_path. Single entry point.

    Seeding order (respects FK dependencies):
      1. Reference data (owners, domains, systems, environments,
         feeds, frameworks, tags)
      2. Contract artifacts (contracts -> schemas ->
         coercion/validation/metadata -> link FKs)
      3. Pipeline configs (with optional contract FK resolution)
      4. Semantic layer (concepts -> relationships -> field graph ->
         proposals -> ontology mappings)

    Args:
        seed_path: Directory containing seed YAML files.
        db_url: Database connection string (PostgreSQL or SQLite).

    Returns:
        0 on success.

    Raises:
        Exception: Re-raised after rolling back the session on failure.
    """
    require_alembic()
    session = get_session(db_url)
    try:
        seed_model(
            session,
            OwnerModel,
            seed_path / "owners.yaml",
            "owners",
        )
        seed_model(
            session,
            DomainModel,
            seed_path / "domains.yaml",
            "domains",
            "name",
        )
        seed_model(
            session,
            SystemModel,
            seed_path / "systems.yaml",
            "systems",
            "name",
        )
        seed_model(
            session,
            EnvironmentModel,
            seed_path / "environments.yaml",
            "environments",
            "name",
        )
        seed_model(
            session,
            DataFeedModel,
            seed_path / "data_feeds.yaml",
            "data_feeds",
            "name",
        )
        seed_model(
            session,
            ComplianceFrameworkModel,
            seed_path / "compliance_frameworks.yaml",
            "compliance_frameworks",
            "name",
        )
        seed_model(
            session,
            TagModel,
            seed_path / "tags.yaml",
            "tags",
            "name",
        )
        seed_contract_artifacts(seed_path, session)
        _seed_pipeline_configs(seed_path, session)
        _seed_concepts(seed_path, session)
        _seed_concept_relationships(seed_path, session)
        _seed_semantic_field_graph(seed_path, session)
        _seed_semantic_proposals(seed_path, session)
        _seed_ontologies(seed_path, db_url)
        logger.info("Seed data loaded successfully")
        return 0
    except Exception as e:
        session.rollback()
        raise e
    finally:
        session.close()


# Backward-compat alias — prefer seed_all() for new code.
seed_postgresql = seed_all


def seed_mongodb(seed_path: Path, db_url: str) -> int:
    """Seed MongoDB with owners, domains, systems from YAML.

    Returns:
        0 on success, 1 on error.
    """
    try:
        from datetime import datetime

        from bson import ObjectId
        from pymongo import MongoClient

        database_name = "pycharter"
        if "/" in db_url.rsplit("@", 1)[-1]:
            database_name = db_url.rsplit("/", 1)[-1].split("?")[0]
        client: Any = MongoClient(db_url)
        db = client[database_name]
        try:
            for collection_name, model_name, id_field in [
                ("owners", "owners", "id"),
                ("domains", "domains", "name"),
                ("systems", "systems", "name"),
            ]:
                seed_file = seed_path / f"{collection_name}.yaml"
                if not seed_file.exists():
                    logger.warning(
                        "No %s file found, skipping %s",
                        seed_file.name,
                        model_name,
                    )
                    continue
                logger.info("Loading %s...", model_name)
                with open(seed_file) as f:
                    data = yaml.safe_load(f) or []
                collection = db[collection_name]
                count_created = count_updated = 0
                now = datetime.utcnow()
                for item_data in data:
                    item_id = item_data.get(id_field)
                    if not item_id:
                        logger.warning(
                            "Skipping %s entry without '%s' field",
                            model_name,
                            id_field,
                        )
                        continue
                    existing = collection.find_one({id_field: item_id})
                    doc = dict(item_data)
                    if existing:
                        doc["updated_at"] = now
                        doc["created_at"] = existing.get("created_at", now)
                        collection.update_one({id_field: item_id}, {"$set": doc})
                        count_updated += 1
                    else:
                        if collection_name != "owners":
                            doc["_id"] = ObjectId()
                        doc["created_at"] = doc["updated_at"] = now
                        collection.insert_one(doc)
                        count_created += 1
                logger.info(
                    "Loaded %d %s(s) (%d created, %d updated)",
                    len(data),
                    model_name,
                    count_created,
                    count_updated,
                )
            logger.info("Seed data loaded successfully")
            return 0
        finally:
            client.close()
    except ImportError:
        logger.error("pymongo is required. Install with: pip install pymongo")
        return 1
    except Exception as e:
        logger.exception("Error seeding MongoDB: %s", e)
        return 1


def cmd_seed(
    seed_dir: str | None = None,
    database_url: str | None = None,
) -> int:
    """CLI entry point: resolve seed dir and DB URL, then seed.

    Returns:
        Exit code (0 on success, 1 on error).
    """
    if not YAML_AVAILABLE:
        logger.error("PyYAML is required. Install with: pip install pyyaml")
        return 1
    try:
        if seed_dir and any(
            seed_dir.startswith(p)
            for p in (
                "postgresql://",
                "postgres://",
                "mysql://",
                "sqlite://",
                "mongodb://",
                "mongodb+srv://",
            )
        ):
            database_url, seed_dir = seed_dir, None
        db_url = get_db_url(database_url)
        if not db_url:
            return 1
        if seed_dir:
            seed_path = Path(seed_dir)
        else:
            pkg_root = Path(__file__).resolve().parent.parent
            seed_path = pkg_root / "data" / "seed"
        if not seed_path.exists():
            logger.error("Seed directory not found: %s", seed_path)
            return 1
        logger.info("Loading seed data from: %s", seed_path)
        if db_url.startswith(("mongodb://", "mongodb+srv://")):
            return seed_mongodb(seed_path, db_url)
        seed_all(seed_path, db_url)
        return 0
    except Exception as e:
        logger.exception("Error seeding database: %s", e)
        return 1


__all__ = [
    "cmd_seed",
    "seed_all",
    "seed_mongodb",
    "seed_postgresql",
]
