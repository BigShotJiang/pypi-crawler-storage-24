# ruff: noqa: E402
"""
PyCharter - Data Contract Management, Pipelines, and Validation

Core Services:
1. Pipelines - Build and run data pipelines with | operator
2. Contract Parser - Reads and decomposes data contract files
3. Contract Builder - Constructs consolidated contracts from separate artifacts
4. Metadata Store - Database operations for metadata storage
5. Pydantic Generator - Generates Pydantic models from JSON Schema
6. JSON Schema Converter - Converts Pydantic models to JSON Schema
7. Runtime Validator - Validation utilities
8. Quality Assurance - Data quality checking and monitoring

Pipeline API:
    >>> from pycharter import Pipeline, HTTPExtractor, PostgresLoader, Rename, AddField
    >>>
    >>> # Programmatic pipeline with | operator
    >>> pipeline = (
    ...     Pipeline(HTTPExtractor(url="https://api.example.com/data"))
    ...     | Rename({"old": "new"})
    ...     | AddField("processed_at", "now()")
    ...     | PostgresLoader(connection_string="...", table="users")
    ... )
    >>> result = await pipeline.run()  # run() is async; use asyncio.run() from scripts
    >>>
    >>> # Config-driven (explicit files)
    >>> pipeline = Pipeline.from_config_files(
    ...     extract="configs/extract.yaml",
    ...     load="configs/load.yaml",
    ...     variables={"API_KEY": "secret"}
    ... )
    >>>
    >>> # Config-driven (directory with extract.yaml, transform.yaml, load.yaml)
    >>> pipeline = Pipeline.from_config_dir("pipelines/users/")
    >>>
    >>> # Config-driven (single file)
    >>> pipeline = Pipeline.from_config_file("pipelines/users/pipeline.yaml")

Validator API:
    >>> from pycharter import Validator
    >>>
    >>> # From explicit files
    >>> validator = Validator.from_files(schema="schema.yaml")
    >>>
    >>> # From directory
    >>> validator = Validator.from_dir("contracts/users/")
    >>>
    >>> result = validator.validate({"name": "Alice", "age": 30})
"""

from __future__ import annotations


def _get_version() -> str:
    try:
        from importlib.metadata import version

        return version("pycharter")
    except Exception:
        return "0.0.0.dev0"


__version__ = _get_version()

# Lazy-import mapping and __all__ live in _exports to keep this file under 400 lines.
from pycharter._exports import _LAZY_IMPORTS
from pycharter._exports import __all__ as __all__  # noqa: F401 — re-export

# Contract Builder
from pycharter.contract_builder import (
    ContractArtifacts,
    DataContract,
    build_contract,
    build_contract_from_store,
)

# Contract Parser
from pycharter.contract_parser import (
    ContractMetadata,
    parse_contract,
    parse_contract_file,
)

# Contract Store — core client always available
from pycharter.contract_store import ContractStoreClient

# JSON Schema Converter
from pycharter.json_schema_converter import model_to_schema, to_dict, to_file, to_json

# Pipelines — core types
from pycharter.pipeline_generator import (
    AddField,
    BaseExtractor,
    BaseLoader,
    BaseTransformer,
    BatchResult,
    CloudStorageExtractor,
    CloudStorageLoader,
    Convert,
    CustomFunction,
    DatabaseExtractor,
    DatabaseLoader,
    Default,
    Drop,
    Extractor,
    FileExtractor,
    FileLoader,
    Filter,
    FlatMap,
    Flatten,
    HTTPExtractor,
    Loader,
    LoadResult,
    Map,
    Pipeline,
    PipelineContext,
    PipelineResult,
    PostgresLoader,
    Rename,
    Select,
    Transformer,
    TransformerChain,
    Unnest,
)

# Pydantic Generator
from pycharter.pydantic_generator import (
    from_dict,
    from_file,
    from_json,
    from_url,
    generate_model,
    generate_model_file,
)

# Runtime Validator
from pycharter.runtime_validator import (
    ValidationResult,
    Validator,
    ValidatorBuilder,
    create_validator,
    get_merged_schema_from_contract,
    get_model_from_contract,
    get_model_from_store,
    merge_rules_into_schema,
    validate,
    validate_batch,
    validate_batch_with_contract,
    validate_batch_with_store,
    validate_input,
    validate_output,
    validate_with_contract,
    validate_with_contract_decorator,
    validate_with_store,
)

# Protocols and Error Handling
from pycharter.shared import (
    CoercionRegistry,
    ConfigError,
    ConfigLoadError,
    ConfigValidationError,
    DataValidator,
    ErrorContext,
    ErrorMode,
    ExpressionError,
    LenientMode,
    PyCharterError,
    StrictMode,
    ValidationRegistry,
    set_error_mode,
)


def __getattr__(name: str):
    """Lazy-load optional and heavy modules on first access."""
    if name in _LAZY_IMPORTS:
        import importlib

        module_path, attr_name = _LAZY_IMPORTS[name]
        try:
            module = importlib.import_module(module_path)
            return getattr(module, attr_name)
        except ImportError:
            return None
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
