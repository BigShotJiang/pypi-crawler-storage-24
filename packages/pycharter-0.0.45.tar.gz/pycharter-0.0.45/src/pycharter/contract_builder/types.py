"""
Canonical data contract type.

The DataContract is the single in-memory representation of a consolidated
contract used by validation, ETL, and quality. All contract-producing APIs
(build_contract, build_contract_from_store) return this type.
"""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel, Field


class DataContract(BaseModel):
    """
    Consolidated data contract: JSON Schema, rules, metadata, and field mapping.

    This is the single source of truth used by Validator, ETL validation,
    and quality checks. json_schema is raw (not merged with rules); the Validator
    merges rules internally during validation.
    """

    json_schema: dict[str, Any] = Field(
        ..., description="JSON Schema definition (raw, must have version)"
    )
    coercion_rules: dict[str, Any] = Field(
        default_factory=dict, description="Coercion rules"
    )
    validation_rules: dict[str, Any] = Field(
        default_factory=dict, description="Validation rules"
    )
    metadata: dict[str, Any] | None = Field(
        default=None, description="Metadata (ownership, governance_rules)"
    )
    ownership: dict[str, Any] | None = Field(
        default=None, description="Ownership (convenience top-level)"
    )
    governance_rules: dict[str, Any] | None = Field(
        default=None, description="Governance rules (convenience top-level)"
    )
    field_mapping: dict[str, Any] | None = Field(
        default=None, description="Semantic field bindings (ontology)"
    )
    versions: dict[str, str | None] | None = Field(
        default=None, description="Version tracking per component"
    )

    model_config = {"extra": "forbid"}

    def to_dict(self) -> dict[str, Any]:
        """Return contract as a plain dict for serialization or legacy callers."""
        return self.model_dump()
