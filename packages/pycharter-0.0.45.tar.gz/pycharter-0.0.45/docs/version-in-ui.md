# Why the UI shows a version that doesn't match the current git tag

The release version shown in the UI (e.g. "Release 0.0.33.dev43+g...") comes from the **installed** package metadata, not from Git at runtime.

- **Source:** `pycharter.__version__` → `importlib.metadata.version("pycharter")`
- **How it gets set:** When you run `pip install -e .` (or `pip install .`), **setuptools-scm** computes the version from the Git repo at **install time** and stores it in the package metadata. That value is then read by the UI and API.

So the UI shows the version that was computed **the last time you installed** the package. If you've since moved to another branch, pulled new commits, or created new tags, the installed metadata still has the old value until you reinstall.

**To make the displayed version match the current git state:** reinstall in the project directory:

```bash
cd /path/to/pycharter
pip install -e .
```

Then restart `pycharter ui dev`. The UI will show a version derived from the current commit and tags (e.g. `0.0.40.dev16+g84d0a0b` if you're 16 commits after `v0.0.40`).

**Interpretation:**
- `0.0.33` = latest tag in history at install time (e.g. `v0.0.33`)
- `dev43` = 43 commits after that tag
- `g3bb834454` = short commit hash
- `d20260305` = date

So the value does match **a** git tag (the base is that tag); the rest indicates a development revision after that tag.
