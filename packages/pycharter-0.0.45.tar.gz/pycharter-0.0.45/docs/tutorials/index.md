# Tutorials

Step-by-step guides to master PyCharter's features. The **data contract** is the single source of truth; all tutorials use **contract name** and **contract version** (or a contract file) where applicable.

## Quick start (30 seconds each)

| Topic | One snippet |
|-------|-------------|
| **ETL** | `Pipeline(HTTPExtractor(url="...")) \| Rename({...}) \| FileLoader(path="out.json")` then `await pipeline.run()` |
| **Contracts** | `parse_contract_file("c.yaml")` → `metadata.to_data_contract()` → `Validator(contract_dict=contract)` |
| **Quality** | `check_quality(contract=contract, data=records)` or `QualityCheck(store).run(contract_name="user", contract_version="1.0.0", data=...)` |
| **Metadata store** | `store.store_schema("user", "1.0.0", schema)`; `store.get_contract("user", "1.0.0")`; `store.list_contracts()` |
| **API & UI** | `pycharter api` and `pycharter ui serve` |

## Learning Path

We recommend following these tutorials in order:

```mermaid
graph LR
    A[ETL Pipelines] --> B[Contracts & Validation]
    B --> C[Quality Monitoring]
    C --> D[Contract Store]
    D --> E[REST API & UI]
```

## Available Tutorials

<div class="grid cards" markdown>

-   :material-pipe:{ .lg .middle } **Building ETL Pipelines**

    ---

    Learn to build data pipelines with extractors, transformers, and loaders.

    **Duration**: 30 minutes

    [:octicons-arrow-right-24: Start Tutorial](pipelines.md)

-   :material-file-document-check:{ .lg .middle } **Data Contracts & Validation**

    ---

    Define contracts, coercion rules, and validation logic for your data.

    **Duration**: 25 minutes

    [:octicons-arrow-right-24: Start Tutorial](contracts-validation.md)

-   :material-chart-line:{ .lg .middle } **Data Quality Monitoring**

    ---

    Monitor quality metrics, track violations, and set threshold alerts.

    **Duration**: 20 minutes

    [:octicons-arrow-right-24: Start Tutorial](quality-monitoring.md)

-   :material-database:{ .lg .middle } **Contract Store & Schema Registry**

    ---

    Store, version, and retrieve schemas using different backends.

    **Duration**: 20 minutes

    [:octicons-arrow-right-24: Start Tutorial](contract-store.md)

-   :material-api:{ .lg .middle } **REST API & Web UI**

    ---

    Use PyCharter's API server and interactive web interface.

    **Duration**: 15 minutes

    [:octicons-arrow-right-24: Start Tutorial](api-and-ui.md)

</div>

## Prerequisites

Before starting the tutorials, ensure you have:

- [x] Python 3.11+ installed
- [x] PyCharter installed (`pip install pycharter[api,ui,etl]`)
- [x] Basic knowledge of Python async/await
- [x] Familiarity with JSON Schema (helpful but not required)

## Tutorial Format

Each tutorial includes:

1. **Overview** - What you'll learn
2. **Prerequisites** - What you need before starting
3. **Step-by-step instructions** - Hands-on coding
4. **Code examples** - Copy-paste ready snippets
5. **Exercises** - Practice what you've learned
6. **Next steps** - Where to go from here

## Getting Help

If you get stuck:

- Check the [API Reference](../api/index.md) for detailed documentation
- Search [GitHub Issues](https://github.com/optophi/pycharter/issues)
- Ask on [GitHub Discussions](https://github.com/optophi/pycharter/discussions)
