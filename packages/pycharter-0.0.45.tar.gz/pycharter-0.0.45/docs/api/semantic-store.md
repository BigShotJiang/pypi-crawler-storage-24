# Semantic Store

The semantic store provides **persistence for the ontology layer**: concept schemes, concepts, relationships, and versioned ontology configurations (e.g. LinkML YAML). Use it when you need a central registry for business concepts and their relationships, or to store and retrieve ontology configs by name and version (e.g. for the Ontology workspace in the Web UI).

## Overview

```python
from pycharter.semantic_store import PostgresSemanticStore

store = PostgresSemanticStore("postgresql://...")
store.connect()

# Store a concept scheme
store.store_scheme("trading-domain", "1.0.0", title="Trading Domain Ontology", description="...")

# Store concepts within the scheme
store.store_concept("OrderId", "trading-domain", label="Order Identifier", definition="Unique order ID")
store.store_concept("CustomerId", "trading-domain", label="Customer Identifier", broader="PartyId")

# Store a relationship
store.store_relationship("OrderId", "CustomerId", "references")

# Store a versioned ontology config (LinkML YAML)
store.store_config("trading_ontology", "1.0.0", linkml_yaml="...")

# Retrieve
scheme = store.get_scheme("trading-domain")
concepts = store.list_concepts(scheme_key="trading-domain")
config = store.get_config("trading_ontology", "1.0.0")
store.disconnect()
```

## When to use

- **Ontology workspace** — The Web UI uses the semantic store for concept schemes, concepts, relationships, and ontology configs.
- **Contract field mapping** — Field-level semantic annotations (which concept a field represents) can be stored per contract in the **contract store**; the semantic store holds the **concept definitions** and schemes.
- **Governance** — Central vocabulary of business terms and their relationships.

## Store implementations

| Class | Backend | Use case |
|-------|---------|----------|
| `InMemorySemanticStore` | Memory | Testing |
| `SQLiteSemanticStore` | SQLite | Development |
| `PostgresSemanticStore` | PostgreSQL | Production, API |

Semantic store does not currently implement MongoDB or Redis backends.

## SemanticStoreClient

Base interface for all semantic stores. Operations are grouped into: **concept schemes**, **concepts**, **relationships**, and **ontology configs**.

::: pycharter.semantic_store.client.SemanticStoreClient
    options:
      show_root_heading: true
      show_source: false
      members:
        - connect
        - disconnect
        - store_scheme
        - get_scheme
        - list_schemes
        - delete_scheme
        - store_concept
        - get_concept
        - list_concepts
        - update_concept
        - delete_concept
        - store_relationship
        - list_relationships
        - delete_relationship
        - store_config
        - get_config
        - list_configs
        - list_versions
        - update_status
        - delete_config
        - get_parsed_schema
        - ingest_vocabulary

## Concept schemes

| Method | Description |
|--------|-------------|
| `store_scheme(scheme_key, version, title, ...)` | Store a concept scheme. Optional: `description`, `base_uri`, `author`. |
| `get_scheme(scheme_key, version=None)` | Retrieve a scheme; if `version` is None, returns latest. |
| `list_schemes()` | List all concept schemes. |
| `delete_scheme(scheme_key)` | Delete a scheme and its concepts. |

## Concepts

| Method | Description |
|--------|-------------|
| `store_concept(name, scheme_key, ...)` | Store a concept. Optional: `label`, `definition`, `broader`, `concept_type`, `tier`, `uri`, `notation`, `deprecated`, `author`. |
| `get_concept(name)` | Retrieve a concept by name. |
| `list_concepts(scheme_key=None)` | List concepts, optionally filtered by scheme. |
| `update_concept(name, **fields)` | Update mutable fields. |
| `delete_concept(name)` | Delete a concept. |

## Relationships

| Method | Description |
|--------|-------------|
| `store_relationship(source_name, target_name, relationship_type, ...)` | Store a relationship between two concepts. |
| `list_relationships(concept_name=None, rel_type=None)` | List relationships with optional filters. |
| `delete_relationship(relationship_id)` | Delete a relationship by ID. |

## Ontology configurations

Versioned ontology artifacts (e.g. LinkML YAML) are stored and retrieved by `ontology_name` and `ontology_version`:

| Method | Description |
|--------|-------------|
| `store_config(ontology_name, ontology_version, linkml_yaml, ...)` | Store an ontology config. Optional: `description`, `scheme_key`, `created_by`. |
| `get_config(ontology_name, ontology_version)` | Retrieve the full config dict. |
| `list_configs(ontology_name=None)` | List stored configs. |
| `list_versions(ontology_name)` | List versions for an ontology. |
| `update_status(...)` | Update lifecycle status. |
| `delete_config(ontology_name, ontology_version)` | Delete a config. |
| `get_parsed_schema(ontology_name, ontology_version)` | Return a parsed `LinkMLSchema` from the stored YAML. |
| `ingest_vocabulary(scheme, author=...)` | Bulk-load a `ConceptScheme` into the store (concepts + hierarchy). |

## SQLite and Postgres

```python
from pycharter.semantic_store import SQLiteSemanticStore, PostgresSemanticStore

# SQLite (development)
store = SQLiteSemanticStore(connection_string="sqlite:///pycharter.db")
store.connect()

# Postgres (production / API)
store = PostgresSemanticStore(connection_string="postgresql://user:pass@localhost/pycharter")
store.connect()
```

## In-memory

```python
from pycharter.semantic_store import InMemorySemanticStore

store = InMemorySemanticStore()
store.connect()
```

## See also

- [Contract Store](contract-store.md) — Schema registry; can store field mapping (ontology) per contract
- [Pipeline Store](pipeline-store.md) — Pipeline config registry
- [Ontology API](ontology.md) — Models, parsers, and validators for field mappings and concepts
- [Ontology guide](../guides/ontology.md) — Conceptual overview
