# Contract Parser

Parse data contract files (YAML/JSON) into **ContractMetadata**. Promote to the canonical **DataContract** with `metadata.to_data_contract()` for use with the Validator, QualityCheck, and ETL.

## Overview

```python
from pycharter import parse_contract_file, parse_contract

# From file
metadata = parse_contract_file("user_contract.yaml")

# From dict (canonical key: json_schema; "schema" also accepted for backward compatibility)
metadata = parse_contract({"json_schema": {...}, "metadata": {...}})

# Promote to DataContract (for Validator, quality, store)
contract = metadata.to_data_contract()
```

## API Reference

::: pycharter.contract_parser.parse_contract
    options:
      show_root_heading: true

::: pycharter.contract_parser.parse_contract_file
    options:
      show_root_heading: true

## ContractMetadata

The result of parsing a contract. Use `.to_data_contract()` to get a **DataContract**.

| Attribute | Type | Description |
|-----------|------|-------------|
| `schema` | Dict | JSON Schema definition (same as dict key `json_schema` when serialized) |
| `coercion_rules` | Dict | Coercion rules (defaults to `{}` if absent) |
| `validation_rules` | Dict | Validation rules (defaults to `{}` if absent) |
| `metadata` | Dict | Metadata (title, description, version) |
| `ownership` | Dict | Ownership information |
| `governance_rules` | Dict | Governance policies |
| `ontology` | Dict | Ontology / field mapping (version, fields) |
| `versions` | Dict | Component versions |

## Examples

```python
from pycharter import parse_contract_file

# Parse from file
metadata = parse_contract_file("contracts/user.yaml")

# Access components
print(metadata.schema)
print(metadata.metadata)
print(metadata.ownership)

# Promote to DataContract for validation or storage
contract = metadata.to_data_contract()
validator = Validator(contract_dict=contract)
```

## See Also

- [Contract Builder](contract-builder.md) — build **DataContract** from artifacts or store
- [Contract-First Guide](../getting-started/contract-first.md)
- [Contracts Tutorial](../tutorials/contracts-validation.md)
