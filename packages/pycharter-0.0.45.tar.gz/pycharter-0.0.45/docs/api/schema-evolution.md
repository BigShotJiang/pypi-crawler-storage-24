# Schema Evolution

Check schema compatibility and compute diffs between versions.

## Overview

```python
from pycharter.schema_evolution import check_compatibility, compute_diff, CompatibilityMode

result = check_compatibility(old_schema, new_schema, mode=CompatibilityMode.BACKWARD)
```

## API Reference

::: pycharter.schema_evolution.check_compatibility
    options:
      show_root_heading: true

::: pycharter.schema_evolution.compute_diff
    options:
      show_root_heading: true

## CompatibilityMode

| Mode | Description |
|------|-------------|
| `BACKWARD` | New schema can read old data |
| `FORWARD` | Old schema can read new data |
| `FULL` | Both backward and forward |
| `NONE` | No compatibility check |

## CompatibilityResult

| Attribute | Type | Description |
|-----------|------|-------------|
| `is_compatible` | bool | Compatibility status |
| `issues` | List[str] | List of issues found |

## SchemaDiff

| Attribute | Type | Description |
|-----------|------|-------------|
| `added_fields` | List[str] | New fields |
| `removed_fields` | List[str] | Removed fields |
| `modified_fields` | Dict | Changed fields |

## Examples

```python
from pycharter.schema_evolution import check_compatibility, compute_diff, CompatibilityMode

# Check compatibility
result = check_compatibility(
    old_schema=schema_v1,
    new_schema=schema_v2,
    mode=CompatibilityMode.BACKWARD
)

if not result.is_compatible:
    print(f"Issues: {result.issues}")

# Compute diff
diff = compute_diff(schema_v1, schema_v2)
print(f"Added: {diff.added_fields}")
print(f"Removed: {diff.removed_fields}")
```

## See Also

- [Contract Store](contract-store.md)
- [Contract Store Tutorial](../tutorials/contract-store.md)
