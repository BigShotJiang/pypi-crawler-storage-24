# Contract Store

The contract store provides centralized schema registry functionality. All operations are keyed by **contract name** and **contract version**.

## Overview

```python
from pycharter import PostgresContractStore

store = PostgresContractStore("postgresql://...")
store.connect()

# Store and retrieve by contract name and version
store.store_schema("user", "1.0.0", schema)
store.store_metadata("user", "1.0.0", metadata)
schema = store.get_schema("user", "1.0.0")
contracts = store.list_contracts()  # [{"name": "user", "version": "1.0.0"}, ...]
store.disconnect()
```

## Store Implementations

| Class | Backend | Use Case |
|-------|---------|----------|
| `InMemoryContractStore` | Memory | Testing |
| `SQLiteContractStore` | SQLite | Development |
| `PostgresContractStore` | PostgreSQL | Production |
| `MongoDBContractStore` | MongoDB | Document-oriented |
| `RedisContractStore` | Redis | Caching |

## ContractStoreClient

Base interface for all stores:

::: pycharter.contract_store.ContractStoreClient
    options:
      show_root_heading: true
      show_source: false
      members:
        - connect
        - disconnect
        - store_schema
        - get_schema
        - list_contracts
        - store_coercion_rules
        - get_coercion_rules
        - store_validation_rules
        - get_validation_rules
        - store_metadata
        - get_metadata
        - get_contract
        - get_field_mapping
        - store_field_mapping

## SQLiteContractStore

```python
from pycharter import SQLiteContractStore

store = SQLiteContractStore("metadata.db")
store.connect()

# Store and retrieve by contract name and version
store.store_schema("user", "1.0.0", {
    "type": "object",
    "properties": {"name": {"type": "string"}}
})
schema = store.get_schema("user", "1.0.0")
```

## PostgresContractStore

```python
from pycharter import PostgresContractStore

store = PostgresContractStore(
    "postgresql://user:pass@localhost/pycharter"
)
store.connect()
```

## MongoDBContractStore

```python
from pycharter import MongoDBContractStore

store = MongoDBContractStore(
    "mongodb://localhost:27017/pycharter"
)
store.connect()
```

## RedisContractStore

```python
from pycharter import RedisContractStore

store = RedisContractStore("redis://localhost:6379/0")
store.connect()
```

## InMemoryContractStore

```python
from pycharter import InMemoryContractStore

store = InMemoryContractStore()
store.connect()
# Data is lost when program exits
```

## Examples

### Schema Versioning

```python
# Store versions
store.store_schema("user", "1.0.0", schema_v1)
store.store_schema("user", "2.0.0", schema_v2)

# Get specific version
schema = store.get_schema("user", "1.0.0")

# List contracts
contracts = store.list_contracts()
```

### Storing Rules

```python
# Coercion rules
store.store_coercion_rules("user", "1.0.0", {
    "version": "1.0.0",
    "rules": {"age": "coerce_to_integer"}
})

# Validation rules
store.store_validation_rules("user", "1.0.0", {
    "version": "1.0.0",
    "rules": {"age": {"is_positive": {}}}
})
```

### Metadata

```python
# Store metadata
store.store_metadata("user", "1.0.0", {
    "title": "User Schema",
    "owner": "data-team",
    "tags": ["user", "pii"]
})

# Retrieve
metadata = store.get_metadata("user", "1.0.0")
```

### Ontology (ontology-enabled stores)

Stores that support ontology (e.g. `PostgresContractStore`, `InMemoryContractStore`) can store and retrieve ontology annotations per contract. **PostgresContractStore** requires the semantic/ontology tables (e.g. `contract_versions`) to exist; run `pycharter db upgrade` if ontology storage fails.

```python
# Store field mapping (ontology) for a contract
store.store_field_mapping("user", "1.0.0", {
    "version": "1.0.0",
    "fields": {
        "email": {"concept": "user_email", "definition": "Primary email address"}
    }
})

# Retrieve
field_mapping = store.get_field_mapping("user", "1.0.0")
```

When you call `store.get_contract(name, version)`, the returned contract dict includes `field_mapping` when available.

## See Also

- [Contract Store Tutorial](../tutorials/contract-store.md)
- [Schema Evolution](schema-evolution.md)
