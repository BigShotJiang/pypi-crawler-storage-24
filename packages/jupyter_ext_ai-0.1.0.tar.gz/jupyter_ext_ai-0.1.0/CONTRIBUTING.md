# Contributing to jupyter-ext-ai

Thank you for your interest in contributing! Here's how to get started.

## Development Setup

```bash
# Clone the repo
git clone https://github.com/novatechnolab/jupyter-ext-ai.git
cd jupyter-ext-ai

# Create a virtual environment
python -m venv .venv
source .venv/bin/activate

# Install in editable mode with dev dependencies
pip install -e ".[dev]"
```

## Running Tests

```bash
pytest tests/ -v --cov=jupyter_ext_ai
```

## Code Style

We use [Ruff](https://docs.astral.sh/ruff/) for linting and formatting:

```bash
ruff check src/ tests/
ruff format src/ tests/
```

## Adding a New Provider

1. Create `src/jupyter_ext_ai/providers/your_provider.py`
2. Subclass `BaseLLMProvider` and implement `chat()` and `list_models()`
3. Register it in `src/jupyter_ext_ai/providers/__init__.py` inside `_auto_register()`
4. Add the default model to `DEFAULT_MODELS` and the env var to `API_KEY_ENV_VARS` in `config.py`
5. Add tests in `tests/test_providers.py`
6. Update `README.md`

## Submitting Changes

1. Fork the repository
2. Create a feature branch: `git checkout -b feature/my-feature`
3. Commit using clear messages
4. Push and open a Pull Request

## Releasing

1. Bump the version in `src/jupyter_ext_ai/__init__.py`
2. Tag: `git tag v<version>`
3. Push: `git push origin v<version>`
4. The CI pipeline handles the rest
