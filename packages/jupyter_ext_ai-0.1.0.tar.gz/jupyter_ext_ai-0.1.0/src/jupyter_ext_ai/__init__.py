"""
jupyter_ext_ai — Jupyter/IPython magic commands for LLMs.

Provides %ai, %%ai, %ai_config, %ai_history, and %ai_reset
magic commands for interacting with OpenAI, Gemini, and Claude.
"""

__version__ = "0.1.0"


def load_ipython_extension(ipython):
    """Entry-point called by ``%load_ext jupyter_ext_ai``."""
    from .magic import AIMagics

    ipython.register_magics(AIMagics)
