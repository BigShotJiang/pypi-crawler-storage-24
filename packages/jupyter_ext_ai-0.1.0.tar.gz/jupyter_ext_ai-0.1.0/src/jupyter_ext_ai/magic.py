"""IPython magic commands for interacting with LLMs."""

from __future__ import annotations

import argparse
import shlex
import time
from typing import Dict, List

from IPython.core.magic import Magics, line_magic, cell_magic, magics_class
from IPython.display import display, Markdown, HTML

from .config import AIConfig
from .providers import get_provider


@magics_class
class AIMagics(Magics):
    """IPython magics for chatting with LLMs.

    Magic commands
    --------------
    %ai <prompt>          – Send a one-line prompt.
    %%ai [flags]          – Send the cell body as a prompt.
    %ai_config [flags]    – Show or update configuration.
    %ai_models            – List models for the active provider.
    %ai_history           – Print conversation history.
    %ai_reset             – Clear conversation history.
    """

    def __init__(self, shell):
        super().__init__(shell)
        self._config = AIConfig()
        self._history: List[Dict[str, str]] = []

    # ── internal helpers ─────────────────────────────────────────────

    def _build_messages(self, prompt: str, *, system: str | None = None) -> List[Dict[str, str]]:
        """Build the full message list including system + history + new prompt."""
        messages: List[Dict[str, str]] = []
        sys_prompt = system or self._config.system_prompt
        if sys_prompt:
            messages.append({"role": "system", "content": sys_prompt})
        messages.extend(self._history)
        messages.append({"role": "user", "content": prompt})
        return messages

    def _call_llm(
        self,
        prompt: str,
        *,
        provider: str | None = None,
        model: str | None = None,
        system: str | None = None,
        temperature: float | None = None,
        max_tokens: int | None = None,
    ) -> str:
        """Resolve config, call the provider, append to history, and return response."""
        prov_name = provider or self._config.provider
        mdl = model or self._config.effective_model
        temp = temperature if temperature is not None else self._config.temperature
        mtok = max_tokens if max_tokens is not None else self._config.max_tokens

        api_key = self._config.get_api_key(prov_name)
        if not api_key:
            from .config import API_KEY_ENV_VARS

            env_var = API_KEY_ENV_VARS.get(prov_name, "???")
            raise ValueError(
                f"No API key found for provider '{prov_name}'.\n"
                f"Set the environment variable {env_var} or pass it in your shell:\n"
                f"  export {env_var}='sk-...'"
            )

        prov = get_provider(prov_name, api_key=api_key)
        messages = self._build_messages(prompt, system=system)

        start = time.time()
        response = prov.chat(messages, model=mdl, temperature=temp, max_tokens=mtok)
        elapsed = time.time() - start

        # Update history
        self._history.append({"role": "user", "content": prompt})
        self._history.append({"role": "assistant", "content": response})

        self._render(response, prov_name=prov_name, model=mdl, elapsed=elapsed)
        return response

    def _render(
        self, text: str, *, prov_name: str, model: str, elapsed: float
    ) -> None:
        """Render the LLM response as rich Markdown in the notebook."""
        badge_html = (
            f'<div style="margin-bottom:6px;">'
            f'<span style="background:#2d2d2d;color:#e0e0e0;padding:2px 8px;'
            f'border-radius:4px;font-size:11px;font-family:monospace;">'
            f'🤖 {prov_name}/{model} &nbsp;·&nbsp; {elapsed:.1f}s</span></div>'
        )
        display(HTML(badge_html))
        display(Markdown(text))

    @staticmethod
    def _parse_flags(line: str):
        """Parse optional flags from the magic line."""
        parser = argparse.ArgumentParser(add_help=False)
        parser.add_argument("--provider", "-p", type=str, default=None)
        parser.add_argument("--model", "-m", type=str, default=None)
        parser.add_argument("--system", "-s", type=str, default=None)
        parser.add_argument("--temperature", "-t", type=float, default=None)
        parser.add_argument("--max-tokens", type=int, default=None)
        try:
            args, remaining = parser.parse_known_args(shlex.split(line))
        except (SystemExit, ValueError):
            # argparse calls sys.exit on error; catch and treat entire line as prompt
            args = argparse.Namespace(
                provider=None, model=None, system=None, temperature=None, max_tokens=None
            )
            remaining = [line]
        return args, " ".join(remaining)

    # ── magic commands ───────────────────────────────────────────────

    @line_magic
    def ai(self, line: str):
        """``%ai <prompt>`` — Send a one-line prompt to the active LLM."""
        if not line.strip():
            display(Markdown("*Usage:* `%ai <your prompt here>`"))
            return
        args, prompt = self._parse_flags(line)
        if not prompt.strip():
            prompt = line  # fallback: entire line is the prompt
        self._call_llm(
            prompt,
            provider=args.provider,
            model=args.model,
            system=args.system,
            temperature=args.temperature,
            max_tokens=args.max_tokens,
        )

    @cell_magic
    def ai(self, line: str, cell: str):  # noqa: F811  — IPython registers both
        """``%%ai [flags]\\nprompt`` — Send the cell body as a prompt."""
        args, extra = self._parse_flags(line)
        prompt = f"{extra}\n{cell}".strip() if extra else cell.strip()
        if not prompt:
            display(Markdown("*Usage:* `%%ai [--provider X --model Y]\\nyour prompt`"))
            return
        self._call_llm(
            prompt,
            provider=args.provider,
            model=args.model,
            system=args.system,
            temperature=args.temperature,
            max_tokens=args.max_tokens,
        )

    @line_magic
    def ai_config(self, line: str):
        """``%ai_config [--provider X] [--model Y] ...`` — Show or update configuration."""
        if not line.strip():
            display(Markdown(f"**Current configuration:**\n```\n{self._config.summary()}\n```"))
            return
        args, _ = self._parse_flags(line)
        if args.provider:
            self._config.provider = args.provider
        if args.model:
            self._config.model = args.model
        if args.system:
            self._config.system_prompt = args.system
        if args.temperature is not None:
            self._config.temperature = args.temperature
        if args.max_tokens is not None:
            self._config.max_tokens = args.max_tokens
        display(Markdown(f"**Configuration updated:**\n```\n{self._config.summary()}\n```"))

    @line_magic
    def ai_models(self, line: str):
        """``%ai_models`` — List available models for the current provider."""
        prov_name = line.strip() or self._config.provider
        api_key = self._config.get_api_key(prov_name)
        try:
            prov = get_provider(prov_name, api_key=api_key)
            models = prov.list_models()
            header = f"**Models for `{prov_name}`:**\n"
            body = "\n".join(f"- `{m}`" for m in models)
            display(Markdown(header + body))
        except ValueError as exc:
            display(Markdown(f"⚠️ {exc}"))

    @line_magic
    def ai_history(self, line: str):
        """``%ai_history`` — Show conversation history."""
        if not self._history:
            display(Markdown("*No conversation history yet.*"))
            return
        parts = []
        for msg in self._history:
            role = msg["role"].upper()
            content = msg["content"]
            if role == "USER":
                parts.append(f"**🧑 USER:**\n{content}\n")
            else:
                parts.append(f"**🤖 ASSISTANT:**\n{content}\n")
        display(Markdown("\n---\n".join(parts)))

    @line_magic
    def ai_reset(self, line: str):
        """``%ai_reset`` — Clear conversation history."""
        count = len(self._history) // 2
        self._history.clear()
        display(Markdown(f"✅ Conversation history cleared ({count} exchanges removed)."))
