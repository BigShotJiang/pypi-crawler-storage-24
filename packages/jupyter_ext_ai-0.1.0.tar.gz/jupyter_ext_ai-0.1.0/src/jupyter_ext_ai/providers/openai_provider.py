"""OpenAI LLM provider."""

from __future__ import annotations

from typing import Any, Dict, List, Optional

from .base import BaseLLMProvider


class OpenAIProvider(BaseLLMProvider):
    """Provider for OpenAI models (GPT-4o, GPT-4o-mini, etc.)."""

    name = "openai"

    def __init__(self, api_key: Optional[str] = None) -> None:
        super().__init__(api_key=api_key)
        try:
            import openai  # noqa: F401
        except ImportError:
            raise ImportError(
                "The 'openai' package is required for the OpenAI provider.\n"
                "Install it with: pip install openai"
            )
        self._client = openai.OpenAI(api_key=self.api_key)

    def chat(
        self,
        messages: List[Dict[str, str]],
        *,
        model: str = "gpt-4o-mini",
        temperature: float = 0.7,
        max_tokens: Optional[int] = None,
        **kwargs: Any,
    ) -> str:
        params: Dict[str, Any] = {
            "model": model,
            "messages": messages,
            "temperature": temperature,
        }
        if max_tokens is not None:
            params["max_tokens"] = max_tokens
        response = self._client.chat.completions.create(**params)
        return response.choices[0].message.content or ""

    def list_models(self) -> List[str]:
        return [
            "gpt-4o",
            "gpt-4o-mini",
            "gpt-4-turbo",
            "gpt-3.5-turbo",
            "o1",
            "o1-mini",
            "o3-mini",
        ]
