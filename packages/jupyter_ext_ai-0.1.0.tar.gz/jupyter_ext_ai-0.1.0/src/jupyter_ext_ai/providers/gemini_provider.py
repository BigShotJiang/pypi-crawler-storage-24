"""Google Gemini LLM provider."""

from __future__ import annotations

from typing import Any, Dict, List, Optional

from .base import BaseLLMProvider


class GeminiProvider(BaseLLMProvider):
    """Provider for Google Gemini models."""

    name = "gemini"

    def __init__(self, api_key: Optional[str] = None) -> None:
        super().__init__(api_key=api_key)
        try:
            from google import genai  # noqa: F401
        except ImportError:
            raise ImportError(
                "The 'google-genai' package is required for the Gemini provider.\n"
                "Install it with: pip install google-genai"
            )
        self._client = genai.Client(api_key=self.api_key)

    def chat(
        self,
        messages: List[Dict[str, str]],
        *,
        model: str = "gemini-2.0-flash",
        temperature: float = 0.7,
        max_tokens: Optional[int] = None,
        **kwargs: Any,
    ) -> str:
        from google.genai import types

        # Build Gemini content list from standard message format
        contents = []
        system_instruction = None
        for msg in messages:
            role = msg["role"]
            text = msg["content"]
            if role == "system":
                system_instruction = text
                continue
            gemini_role = "model" if role == "assistant" else "user"
            contents.append(types.Content(role=gemini_role, parts=[types.Part(text=text)]))

        config_kwargs: Dict[str, Any] = {"temperature": temperature}
        if max_tokens is not None:
            config_kwargs["max_output_tokens"] = max_tokens

        config = types.GenerateContentConfig(
            system_instruction=system_instruction,
            **config_kwargs,
        )

        response = self._client.models.generate_content(
            model=model,
            contents=contents,
            config=config,
        )
        return response.text or ""

    def list_models(self) -> List[str]:
        return [
            "gemini-2.0-flash",
            "gemini-2.0-flash-lite",
            "gemini-1.5-flash",
            "gemini-1.5-pro",
        ]
