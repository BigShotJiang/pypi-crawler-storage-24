"""Provider registry and base class."""

from __future__ import annotations

from typing import Dict, Type

from .base import BaseLLMProvider

# ── Registry ───────────────────────────────────────────────────────────

_PROVIDERS: Dict[str, Type[BaseLLMProvider]] = {}


def register_provider(name: str, cls: Type[BaseLLMProvider]) -> None:
    """Register a provider class under *name*."""
    _PROVIDERS[name.lower()] = cls


def get_provider(name: str, api_key: str | None = None) -> BaseLLMProvider:
    """Return an instance of the provider registered as *name*."""
    name_lower = name.lower()
    if name_lower not in _PROVIDERS:
        available = ", ".join(sorted(_PROVIDERS)) or "(none)"
        raise ValueError(
            f"Unknown provider '{name}'. Available providers: {available}"
        )
    return _PROVIDERS[name_lower](api_key=api_key)


def list_providers() -> list[str]:
    """Return sorted list of registered provider names."""
    return sorted(_PROVIDERS)


# ── Auto-register built-in providers on import ─────────────────────────

def _auto_register() -> None:
    from .openai_provider import OpenAIProvider
    from .gemini_provider import GeminiProvider
    from .claude_provider import ClaudeProvider

    register_provider("openai", OpenAIProvider)
    register_provider("gemini", GeminiProvider)
    register_provider("claude", ClaudeProvider)


_auto_register()
