"""Abstract base class for LLM providers."""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any, Dict, List, Optional


class BaseLLMProvider(ABC):
    """Interface that every LLM provider must implement."""

    name: str = "base"

    def __init__(self, api_key: Optional[str] = None) -> None:
        self.api_key = api_key

    @abstractmethod
    def chat(
        self,
        messages: List[Dict[str, str]],
        *,
        model: str,
        temperature: float = 0.7,
        max_tokens: Optional[int] = None,
        **kwargs: Any,
    ) -> str:
        """Send a list of messages and return the assistant's reply as a string.

        Parameters
        ----------
        messages : list[dict]
            Conversation history in the ``[{"role": "user", "content": "..."}]`` format.
        model : str
            Model identifier recognised by the provider.
        temperature : float
            Sampling temperature.
        max_tokens : int | None
            Maximum tokens in the response.
        """

    @abstractmethod
    def list_models(self) -> List[str]:
        """Return a list of available model identifiers."""

    def __repr__(self) -> str:
        return f"<{self.__class__.__name__} provider='{self.name}'>"
