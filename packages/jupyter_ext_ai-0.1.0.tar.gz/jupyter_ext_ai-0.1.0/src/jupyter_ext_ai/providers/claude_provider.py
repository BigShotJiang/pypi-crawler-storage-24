"""Anthropic Claude LLM provider."""

from __future__ import annotations

from typing import Any, Dict, List, Optional

from .base import BaseLLMProvider


class ClaudeProvider(BaseLLMProvider):
    """Provider for Anthropic Claude models."""

    name = "claude"

    def __init__(self, api_key: Optional[str] = None) -> None:
        super().__init__(api_key=api_key)
        try:
            import anthropic  # noqa: F401
        except ImportError:
            raise ImportError(
                "The 'anthropic' package is required for the Claude provider.\n"
                "Install it with: pip install anthropic"
            )
        self._client = anthropic.Anthropic(api_key=self.api_key)

    def chat(
        self,
        messages: List[Dict[str, str]],
        *,
        model: str = "claude-sonnet-4-20250514",
        temperature: float = 0.7,
        max_tokens: Optional[int] = None,
        **kwargs: Any,
    ) -> str:
        # Separate system prompt from conversation messages
        system_text: Optional[str] = None
        conversation: List[Dict[str, str]] = []
        for msg in messages:
            if msg["role"] == "system":
                system_text = msg["content"]
            else:
                conversation.append(msg)

        params: Dict[str, Any] = {
            "model": model,
            "messages": conversation,
            "max_tokens": max_tokens or 4096,
            "temperature": temperature,
        }
        if system_text:
            params["system"] = system_text

        response = self._client.messages.create(**params)
        # Response content is a list of content blocks
        return "".join(
            block.text for block in response.content if hasattr(block, "text")
        )

    def list_models(self) -> List[str]:
        return [
            "claude-sonnet-4-20250514",
            "claude-3-5-sonnet-20241022",
            "claude-3-5-haiku-20241022",
            "claude-3-opus-20240229",
        ]
