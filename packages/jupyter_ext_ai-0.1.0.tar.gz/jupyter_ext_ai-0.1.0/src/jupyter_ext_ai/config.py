"""Configuration management for jupyter_ext_ai."""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from typing import Optional


# Default models per provider
DEFAULT_MODELS = {
    "openai": "gpt-4o-mini",
    "gemini": "gemini-2.0-flash",
    "claude": "claude-sonnet-4-20250514",
}

# Environment variable names for API keys
API_KEY_ENV_VARS = {
    "openai": "OPENAI_API_KEY",
    "gemini": "GOOGLE_API_KEY",
    "claude": "ANTHROPIC_API_KEY",
}


@dataclass
class AIConfig:
    """Holds the active configuration for the AI magic commands.

    Resolution order (highest priority first):
      1. Per-command flags  (--provider, --model, --system)
      2. %ai_config overrides
      3. Environment variables
    """

    provider: str = field(default_factory=lambda: os.getenv("JUPYTER_AI_PROVIDER", "openai"))
    model: Optional[str] = field(default_factory=lambda: os.getenv("JUPYTER_AI_MODEL"))
    system_prompt: str = "You are a helpful AI assistant working inside a Jupyter notebook."
    temperature: float = 0.7
    max_tokens: Optional[int] = None
    stream: bool = False

    # ── helpers ──────────────────────────────────────────────────────

    @property
    def effective_model(self) -> str:
        """Return the explicitly set model or the default for the active provider."""
        return self.model or DEFAULT_MODELS.get(self.provider, "gpt-4o-mini")

    def get_api_key(self, provider: Optional[str] = None) -> Optional[str]:
        """Resolve the API key for *provider* from environment variables."""
        prov = provider or self.provider
        env_var = API_KEY_ENV_VARS.get(prov)
        if env_var:
            return os.getenv(env_var)
        return None

    def summary(self) -> str:
        """Return a human-readable summary string."""
        lines = [
            f"  provider     : {self.provider}",
            f"  model        : {self.effective_model}",
            f"  temperature  : {self.temperature}",
            f"  max_tokens   : {self.max_tokens or 'auto'}",
            f"  stream       : {self.stream}",
            f"  system_prompt: {self.system_prompt[:80]}{'…' if len(self.system_prompt) > 80 else ''}",
        ]
        # Show key status (never the actual key)
        for prov, env_var in API_KEY_ENV_VARS.items():
            val = os.getenv(env_var)
            status = "✅ set" if val else "❌ not set"
            lines.append(f"  {env_var}: {status}")
        return "\n".join(lines)
