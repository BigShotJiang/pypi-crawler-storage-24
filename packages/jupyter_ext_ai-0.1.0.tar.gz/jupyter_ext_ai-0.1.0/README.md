# 🤖 jupyter-ext-ai

> **IPython magic commands for chatting with LLMs — OpenAI, Gemini & Claude — right inside Jupyter notebooks.**

[![PyPI version](https://img.shields.io/pypi/v/jupyter-ext-ai.svg)](https://pypi.org/project/jupyter-ext-ai/)
[![Python](https://img.shields.io/pypi/pyversions/jupyter-ext-ai.svg)](https://pypi.org/project/jupyter-ext-ai/)
[![License: MIT](https://img.shields.io/badge/License-MIT-blue.svg)](LICENSE)

---

## ✨ Features

| Magic | Description |
|---|---|
| `%ai <prompt>` | One-line prompt → LLM response |
| `%%ai [flags]` | Cell magic — cell body is the prompt |
| `%ai_config` | View / update provider, model, temperature, etc. |
| `%ai_models` | List models for the active provider |
| `%ai_history` | Print conversation history |
| `%ai_reset` | Clear conversation history |

**Supported providers:** OpenAI · Google Gemini · Anthropic Claude

---

## 📦 Installation

```bash
pip install jupyter-ext-ai
```

**From source (development):**

```bash
git clone https://github.com/novatechnolab/jupyter-ext-ai.git
cd jupyter-ext-ai
pip install -e ".[dev]"
```

---

## 🔑 Configuration

Set your API keys as environment variables:

```bash
# Add to your ~/.bashrc, ~/.zshrc, or .env file
export OPENAI_API_KEY="sk-..."
export GOOGLE_API_KEY="AIza..."
export ANTHROPIC_API_KEY="sk-ant-..."

# Optionally set defaults
export JUPYTER_AI_PROVIDER="openai"      # openai | gemini | claude
export JUPYTER_AI_MODEL="gpt-4o-mini"    # any model supported by the provider
```

---

## 🚀 Quickstart

```python
# Load the extension
%load_ext jupyter_ext_ai

# Ask a question (uses default provider)
%ai What is the capital of France?

# Switch provider on the fly
%ai --provider gemini Explain recursion in one sentence.

# Use cell magic for longer prompts
%%ai --provider claude --model claude-sonnet-4-20250514
Write a Python function that computes the Fibonacci sequence
using dynamic programming. Include type hints and docstring.

# View / change config
%ai_config
%ai_config --provider gemini --model gemini-2.0-flash --temperature 0.3

# List models
%ai_models openai

# Show conversation history
%ai_history

# Clear history and start fresh
%ai_reset
```

---

## 🏗️ Project Structure

```
jupyter-ext-ai/
├── pyproject.toml            # Build config & metadata
├── README.md
├── LICENSE
├── CONTRIBUTING.md
├── MANIFEST.in
├── .github/
│   └── workflows/
│       └── ci.yml            # CI + PyPI publish on tag
├── src/
│   └── jupyter_ext_ai/
│       ├── __init__.py       # load_ipython_extension() hook
│       ├── magic.py          # IPython Magics class
│       ├── config.py         # Config dataclass
│       └── providers/
│           ├── __init__.py   # Provider registry
│           ├── base.py       # Abstract base class
│           ├── openai_provider.py
│           ├── gemini_provider.py
│           └── claude_provider.py
└── tests/
    ├── conftest.py
    ├── test_config.py
    ├── test_providers.py
    └── test_magic.py
```

---

## 🧪 Development

```bash
# Install in editable mode with dev dependencies
pip install -e ".[dev]"

# Run tests
pytest tests/ -v

# Lint
ruff check src/ tests/

# Build distribution
python -m build

# Check dist before uploading
twine check dist/*
```

---

## 📤 Publishing to PyPI

### First time setup

1. Create an account at [pypi.org](https://pypi.org) (and optionally [test.pypi.org](https://test.pypi.org))
2. Generate an API token under *Account settings → API tokens*

### Publish manually

```bash
# Build
python -m build

# Upload to TestPyPI first
twine upload --repository testpypi dist/*

# Upload to PyPI
twine upload dist/*
```

### Automated (GitHub Actions)

Push a version tag to trigger the CI workflow:

```bash
git tag v0.1.0
git push origin v0.1.0
```

The GitHub Action at `.github/workflows/ci.yml` will lint, test, build, and publish to PyPI automatically (requires a `PYPI_API_TOKEN` secret in your repo settings).

---

## 📄 License

[MIT](LICENSE) — use it however you like.
