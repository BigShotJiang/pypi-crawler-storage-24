"""Shared test fixtures."""

import os
import pytest


@pytest.fixture(autouse=True)
def fake_api_keys(monkeypatch):
    """Set dummy API keys so config resolution works without real credentials."""
    monkeypatch.setenv("OPENAI_API_KEY", "sk-test-fake-key")
    monkeypatch.setenv("GOOGLE_API_KEY", "AIza-test-fake-key")
    monkeypatch.setenv("ANTHROPIC_API_KEY", "sk-ant-test-fake-key")
