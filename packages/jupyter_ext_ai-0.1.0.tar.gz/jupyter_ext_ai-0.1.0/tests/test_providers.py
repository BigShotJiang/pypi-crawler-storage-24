"""Tests for provider registry and base class."""

from jupyter_ext_ai.providers import list_providers, get_provider, _PROVIDERS
from jupyter_ext_ai.providers.base import BaseLLMProvider
import pytest


def test_all_providers_registered():
    names = list_providers()
    assert "openai" in names
    assert "gemini" in names
    assert "claude" in names


def test_get_provider_returns_instance():
    prov = get_provider("openai", api_key="sk-fake")
    assert isinstance(prov, BaseLLMProvider)
    assert prov.name == "openai"


def test_get_unknown_provider_raises():
    with pytest.raises(ValueError, match="Unknown provider"):
        get_provider("nonexistent")


def test_provider_list_models():
    prov = get_provider("openai", api_key="sk-fake")
    models = prov.list_models()
    assert isinstance(models, list)
    assert len(models) > 0
    assert all(isinstance(m, str) for m in models)


def test_provider_repr():
    prov = get_provider("claude", api_key="sk-ant-fake")
    assert "ClaudeProvider" in repr(prov)
    assert "claude" in repr(prov)
