"""Tests for the AIMagics class and flag parsing."""

from unittest.mock import patch
from IPython.terminal.interactiveshell import TerminalInteractiveShell
from jupyter_ext_ai.magic import AIMagics


def _make_magics():
    """Create an AIMagics instance with a real IPython shell."""
    shell = TerminalInteractiveShell.instance()
    return AIMagics(shell=shell)


def test_parse_flags_basic():
    args, prompt = AIMagics._parse_flags("--provider gemini Hello world")
    assert args.provider == "gemini"
    assert "Hello world" in prompt


def test_parse_flags_empty():
    args, prompt = AIMagics._parse_flags("")
    assert args.provider is None
    assert prompt == ""


def test_parse_flags_with_model_and_temp():
    args, prompt = AIMagics._parse_flags("--model gpt-4o --temperature 0.5 Write code")
    assert args.model == "gpt-4o"
    assert args.temperature == 0.5
    assert "Write code" in prompt


def test_build_messages():
    m = _make_magics()
    msgs = m._build_messages("Hello")
    assert msgs[0]["role"] == "system"
    assert msgs[-1]["role"] == "user"
    assert msgs[-1]["content"] == "Hello"


def test_build_messages_with_history():
    m = _make_magics()
    m._history = [
        {"role": "user", "content": "Hi"},
        {"role": "assistant", "content": "Hello!"},
    ]
    msgs = m._build_messages("Follow up")
    # system + 2 history + 1 new = 4
    assert len(msgs) == 4
    assert msgs[-1]["content"] == "Follow up"


def test_build_messages_custom_system():
    m = _make_magics()
    msgs = m._build_messages("Test", system="You are a poet.")
    assert msgs[0]["content"] == "You are a poet."


def test_ai_reset():
    m = _make_magics()
    m._history = [
        {"role": "user", "content": "Hi"},
        {"role": "assistant", "content": "Hello!"},
    ]
    with patch("jupyter_ext_ai.magic.display"):
        m.ai_reset("")
    assert m._history == []


def test_config_initial_state():
    m = _make_magics()
    assert m._config.provider is not None
    assert m._config.effective_model is not None
    assert m._history == []
