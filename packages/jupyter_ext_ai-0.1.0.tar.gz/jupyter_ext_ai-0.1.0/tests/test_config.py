"""Tests for config module."""

import os
from jupyter_ext_ai.config import AIConfig, DEFAULT_MODELS, API_KEY_ENV_VARS


def test_default_provider():
    cfg = AIConfig()
    assert cfg.provider == os.getenv("JUPYTER_AI_PROVIDER", "openai")


def test_effective_model_default():
    cfg = AIConfig(provider="openai", model=None)
    assert cfg.effective_model == DEFAULT_MODELS["openai"]


def test_effective_model_explicit():
    cfg = AIConfig(provider="openai", model="gpt-4-turbo")
    assert cfg.effective_model == "gpt-4-turbo"


def test_get_api_key(monkeypatch):
    monkeypatch.setenv("OPENAI_API_KEY", "test-key-123")
    cfg = AIConfig(provider="openai")
    assert cfg.get_api_key() == "test-key-123"


def test_get_api_key_missing(monkeypatch):
    monkeypatch.delenv("OPENAI_API_KEY", raising=False)
    cfg = AIConfig(provider="openai")
    assert cfg.get_api_key() is None


def test_summary_contains_provider():
    cfg = AIConfig(provider="gemini")
    s = cfg.summary()
    assert "gemini" in s


def test_api_key_env_vars_all_providers():
    assert "openai" in API_KEY_ENV_VARS
    assert "gemini" in API_KEY_ENV_VARS
    assert "claude" in API_KEY_ENV_VARS
