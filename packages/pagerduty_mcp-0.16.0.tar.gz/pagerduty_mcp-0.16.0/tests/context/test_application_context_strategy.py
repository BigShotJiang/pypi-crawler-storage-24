import pytest

from unittest.mock import MagicMock

from pagerduty.rest_api_v2_client import RestApiV2Client
from pagerduty_mcp.context import ContextResolver, application_context_strategy
from pagerduty_mcp.context.application_context_strategy import ApplicationContextStrategy
from pagerduty_mcp.context.mcp_context import MCPContext
from pagerduty_mcp.models.users import User


@pytest.fixture
def prepare_env(monkeypatch):
    """Fixture to set a specific environment variable."""
    monkeypatch.setenv("PAGERDUTY_USER_API_KEY", "test_api_key")

    yield
    ContextResolver._context_strategy = None


@pytest.fixture
def mock_client(monkeypatch):
    mock_client = MagicMock(RestApiV2Client)
    mock_client.headers = {}

    # mock the method used to create the client
    monkeypatch.setattr(application_context_strategy, "PagerdutyMCPClient", lambda _: mock_client)
    return mock_client


@pytest.fixture
def mock_user(mock_client):
    user_fields = {"email": "test@example.com", "name": "blah", "role": "admin", "teams": []}
    mock_user = User(**user_fields)

    mock_client.rget.return_value = user_fields

    return mock_user


class TestApplicationContextStrategy:
    """Test cases for the ApplicationContextStrategy and its integration with MCPContext."""

    def test_initialization(self, prepare_env, mock_client, mock_user):
        """Test that the ApplicationContextStrategy initializes the context correctly."""
        strategy = ApplicationContextStrategy()

        assert strategy.context.client == mock_client
        assert strategy.context.user == mock_user

    def test_with_context(self, prepare_env, mock_client, mock_user):
        """Can use with_context as a temporarily override."""
        strategy = ApplicationContextStrategy()
        ContextResolver.set_strategy(strategy)

        another_mock_client = MagicMock(RestApiV2Client)
        another_mock_client.headers = {}
        another_context = MCPContext(another_mock_client)

        # should use the new context within the block
        with strategy.use_context(another_context):
            assert strategy.context.client == another_mock_client
            assert strategy.context.user == None

        # also works from manager class helpers
        with ContextResolver.use_context(another_context):
            assert ContextResolver.get_client() == another_mock_client
            assert ContextResolver.get_user() == None

        # context should be reset after the block
        assert strategy.context.client == mock_client
        assert strategy.context.user == mock_user

    def test_get_client_no_api_key(self, monkeypatch):
        monkeypatch.delenv("PAGERDUTY_USER_API_KEY", raising=False)
        with pytest.raises(RuntimeError):
            ApplicationContextStrategy()
