"""MCP server for salaryfyi — AI assistant tools for salaryfyi.com.

Run: uvx --from "salaryfyi[mcp]" python -m salaryfyi.mcp_server
"""
from __future__ import annotations

from mcp.server.fastmcp import FastMCP

mcp = FastMCP("SalaryFYI")


@mcp.tool()
def list_countries(limit: int = 20, offset: int = 0) -> str:
    """List countries from salaryfyi.com.

    Args:
        limit: Maximum number of results. Default 20.
        offset: Number of results to skip. Default 0.
    """
    from salaryfyi.api import SalaryFYI

    with SalaryFYI() as api:
        data = api.list_countries(limit=limit, offset=offset)
        results = data.get("results", data) if isinstance(data, dict) else data
        if not results:
            return "No countries found."
        items = results[:limit] if isinstance(results, list) else []
        return "\n".join(f"- {item.get('name', item.get('slug', '?'))}" for item in items)


@mcp.tool()
def get_country(slug: str) -> str:
    """Get detailed information about a specific country.

    Args:
        slug: URL slug identifier for the country.
    """
    from salaryfyi.api import SalaryFYI

    with SalaryFYI() as api:
        data = api.get_country(slug)
        return str(data)


@mcp.tool()
def list_calculators(limit: int = 20, offset: int = 0) -> str:
    """List calculators from salaryfyi.com.

    Args:
        limit: Maximum number of results. Default 20.
        offset: Number of results to skip. Default 0.
    """
    from salaryfyi.api import SalaryFYI

    with SalaryFYI() as api:
        data = api.list_calculators(limit=limit, offset=offset)
        results = data.get("results", data) if isinstance(data, dict) else data
        if not results:
            return "No calculators found."
        items = results[:limit] if isinstance(results, list) else []
        return "\n".join(f"- {item.get('name', item.get('slug', '?'))}" for item in items)


@mcp.tool()
def search_salary(query: str) -> str:
    """Search salaryfyi.com for salary data, tax calculators, and country comparisons.

    Args:
        query: Search query string.
    """
    from salaryfyi.api import SalaryFYI

    with SalaryFYI() as api:
        data = api.search(query)
        results = data.get("results", data) if isinstance(data, dict) else data
        if not results:
            return f"No results found for \"{query}\"."
        items = results[:10] if isinstance(results, list) else []
        return "\n".join(f"- {item.get('name', item.get('slug', '?'))}" for item in items)


def main() -> None:
    """Run the MCP server."""
    mcp.run()


if __name__ == "__main__":
    main()
