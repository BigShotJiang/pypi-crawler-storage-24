"""Command-line interface for salaryfyi."""

from __future__ import annotations

import json

import typer

from salaryfyi.api import SalaryFYI

app = typer.Typer(help="SalaryFYI — Salary comparison and tax calculator API client.")


@app.command()
def search(query: str) -> None:
    """Search salaryfyi.com."""
    with SalaryFYI() as api:
        result = api.search(query)
        typer.echo(json.dumps(result, indent=2))
