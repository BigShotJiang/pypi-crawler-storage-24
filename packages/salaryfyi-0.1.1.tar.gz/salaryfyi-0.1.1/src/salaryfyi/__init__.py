"""Python API client for salaryfyi.com."""

__version__ = "0.1.0"
