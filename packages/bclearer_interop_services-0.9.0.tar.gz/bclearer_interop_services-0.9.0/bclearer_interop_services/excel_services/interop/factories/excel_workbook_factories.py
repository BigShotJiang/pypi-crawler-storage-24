import os
from typing import Dict, Dict

from bclearer_interop_services.excel_services.interop.objects.excel_workbooks import ExcelWorkbooks
from bclearer_interop_services.file_system_service.objects.folders import (
    Folders,
)
from bclearer_interop_services.file_system_service.objects.files import (
    Files,
)

class ExcelWorkbookFactories:
    @staticmethod
    def from_folder_path(
        excels_folder: Folders) -> Dict[str, ExcelWorkbooks]:
        excel_workbooks = \
            {}

        for file in os.listdir(excels_folder.absolute_path_string):
            if file.endswith('.xlsx') or file.endswith('.xls'):
                excel_workbook = \
                    Files(
                        os.path.join(
                            excels_folder.absolute_path_string,
                            file))

                excel_workbooks[file] = \
                    ExcelWorkbookFactories.from_file_path(
                        excel_workbook)

        return \
            excel_workbooks
    

    @staticmethod
    def from_file_path(
        excel_file: Files) \
        -> ExcelWorkbooks:
        excel_workbook = \
            ExcelWorkbooks(
                excel_file.absolute_path_string)
        
        return \
            excel_workbook