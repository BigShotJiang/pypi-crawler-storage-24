from typing import Dict, List
from bclearer_interop_services.excel_services.interop.objects.excel_cells import ExcelCells
from bclearer_interop_services.excel_services.interop.objects.excel_sheets import ExcelWorksheets
from bclearer_interop_services.excel_services.interop.objects.excel_workbooks import ExcelWorkbooks
from bclearer_interop_services.excel_services.interop.pipelines.excel_to_grid_graph.objects.excel_to_grid_graph_universe import ExcelToGridGraphUniverse
from bclearer_interop_services.excel_services.interop.pipelines.excel_to_grid_graph.objects.grid_graph.grid_graph import GridGraph
from bclearer_interop_services.excel_services.interop.pipelines.excel_to_grid_graph.objects.grid_graph.grid_graph_edges import GridGraphEdges
from bclearer_interop_services.excel_services.interop.pipelines.excel_to_grid_graph.objects.grid_graph.grid_graph_nodes import GridGraphNodes

def __convert_excel_cells_to_left_to_right_edges(
        excel_cells: List[ExcelCells]) \
        -> List:
    edges = \
        []

    cells_by_row: Dict[int, List[ExcelCells]] = \
        {}
    
    for cell in excel_cells:
        row = \
            cell.cell_row
        
        if row not in cells_by_row:
            cells_by_row[row] = \
                []
            
        cells_by_row[row].append(
            cell)
        
    for row, row_cells in cells_by_row.items():
        sorted_row_cells = \
            sorted(
                row_cells,
                key=lambda cell: cell.cell_coordinate.column.index)

        for i in range(len(sorted_row_cells) - 1):
            left_cell = \
                sorted_row_cells[i]
        
            right_cell = \
                sorted_row_cells[i + 1]
        
            edge = \
                GridGraphEdges(
                    source=GridGraphNodes(left_cell),
                    destination=GridGraphNodes(right_cell),
                    edge_type="LEFT_TO_RIGHT")
            
            edges.append(
                edge)

    return \
        edges

def __convert_excel_cells_to_top_to_bottom_edges(
        excel_cells: List[ExcelCells]) \
        -> List:
    edges = \
        []

    cells_by_column: Dict[int, List[ExcelCells]] = \
        {}

    for cell in excel_cells:
        column = \
            cell.cell_coordinate.column.index

        if column not in cells_by_column:
            cells_by_column[column] = \
                []

        cells_by_column[column].append(
            cell)

    for column, column_cells in cells_by_column.items():
        sorted_column_cells = \
            sorted(
                column_cells,
                key=lambda cell: cell.cell_coordinate.row.index)

        for i in range(len(sorted_column_cells) - 1):
            top_cell = \
                sorted_column_cells[i]

            bottom_cell = \
                sorted_column_cells[i + 1]

            edge = \
                GridGraphEdges(
                    source=GridGraphNodes(top_cell),
                    destination=GridGraphNodes(bottom_cell),
                    edge_type="TOP_TO_BOTTOM")

            edges.append(
                edge)

    return \
        edges

def __convert_excel_cells_to_grid_graph(
        excel_cells: List[ExcelCells],
        source_workbook_hash: str,
        source_worksheet_hash: str) \
        -> GridGraph:
    nodes = \
        [
            GridGraphNodes(excel_cell)
            for excel_cell in excel_cells
        ]
    
    left_to_right_edges = \
        __convert_excel_cells_to_left_to_right_edges(
            excel_cells)
    
    top_to_bottom_edges = \
        __convert_excel_cells_to_top_to_bottom_edges(
            excel_cells)
    
    edges = \
        left_to_right_edges + \
        top_to_bottom_edges
    
    grid_graph = \
        GridGraph(
            name=f"{source_workbook_hash}_{source_worksheet_hash}",
            source_workbook_hash=source_workbook_hash,
            source_worksheet_hash=source_worksheet_hash,
            grid_graph_nodes=nodes,
            grid_graph_edges=edges)
    
    return \
        grid_graph


def __convert_excel_worksheet_to_grid_graph(
        excel_worksheet: ExcelWorksheets,
        source_workbook_hash: str,
        source_worksheet_hash: str) \
        -> GridGraph:
    excel_cells = \
        excel_worksheet.cells
    
    grid_graph = \
        __convert_excel_cells_to_grid_graph(
            excel_cells,
            source_workbook_hash=source_workbook_hash,
            source_worksheet_hash=source_worksheet_hash)

    return \
        grid_graph

def convert_excel_workbook_to_grid_graph(
         excel_workbook: ExcelWorkbooks):
    worksheets = \
        excel_workbook.sheets.values()

    for worksheet in worksheets:
        grid_graph = \
            __convert_excel_worksheet_to_grid_graph(
                worksheet,
                source_workbook_hash=excel_workbook.worksheet_cells_content_hash,
                source_worksheet_hash=worksheet.cells_content_hash)

        yield \
            grid_graph

def convert_excel_workbooks_to_grid_graphs(
        excel_workbooks: List[ExcelWorkbooks]) \
        -> List[GridGraph]:
    all_grid_graphs = \
        []
    
    for workbook in excel_workbooks:
        workbook_grid_graphs = \
            list(convert_excel_workbook_to_grid_graph(
                workbook))
        
        all_grid_graphs.extend(
            workbook_grid_graphs)
    
    return \
        all_grid_graphs

def convert_excel_to_grid_graph_universe_to_grid_graphs(
        excel_to_grid_graph_universe: ExcelToGridGraphUniverse) \
        -> ExcelToGridGraphUniverse:
    excel_workbooks = \
        excel_to_grid_graph_universe.registries.workbook_register.get_workbooks()
    
    grid_graphs = \
        convert_excel_workbooks_to_grid_graphs(
            excel_workbooks=excel_workbooks)

    excel_to_grid_graph_universe.registries.grid_graph_register.register_grid_graphs(
        grid_graphs)

    return \
        excel_to_grid_graph_universe