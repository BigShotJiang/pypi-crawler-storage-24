from bclearer_interop_services.excel_services.interop.objects.excel_cells import ExcelCells


class ExcelCellServices:
    @staticmethod
    def to_dictionary(
        excel_cell: ExcelCells)\
        -> dict:
        return \
            {
                "coordinate": excel_cell.coordinate,
                "row": excel_cell.cell_row,
                "column": excel_cell.cell_coordinate.column.index,
                "value": excel_cell.value,
                "color": excel_cell.color,
                "hash": excel_cell.cell_workbook_value_hash,
                "cell_value_hash": excel_cell.cell_value_hash,
                "inverted_row": excel_cell.inverted_row,
                "file_name": str(excel_cell.owning_excel_workbook.file_path),
                "workbook_name": excel_cell.owning_excel_workbook.workbook_name,
                "current_class": excel_cell.__class__.__name__
            }
