from typing import Dict, List, Tuple


from bclearer_interop_services.excel_services.interop.objects.excel_cells import ExcelCells
from bclearer_interop_services.excel_services.interop.objects.excel_sheets import ExcelWorksheets
from bclearer_interop_services.excel_services.interop.objects.excel_workbooks import ExcelWorkbooks



class RawExcelCellNode:
    def __init__(
        self,
        coordinate: str,
        row: int,
        column: int,
        value: str,
        color: str,
        hash: str,
        file_name: str,
        workbook_name: str
    ) -> None:
        self.coordinate = \
            coordinate
        self.row = \
            row
        self.column = \
            column
        self.value = \
            value
        self.color = \
            color
        self.hash = \
            hash
        self.file_name = \
            file_name
        self.workbook_name = \
            workbook_name
        self.inverted_row = \
            None
    
    @staticmethod
    def from_excel_cell(
            excel_cell: ExcelCells):
        return \
            RawExcelCellNode(
                coordinate=excel_cell.coordinate,
                row=excel_cell.cell_row,
                column=excel_cell.cell_coordinate.column.index,
                value=excel_cell.value,
                color=excel_cell.color,
                hash=excel_cell.cell_workbook_value_hash,
                file_name=str(excel_cell.owning_excel_workbook.file_path),
                workbook_name=excel_cell.owning_excel_workbook.workbook_name)

    def to_dict(
        self) \
        -> dict:
        return \
            {
                "coordinate": self.coordinate,
                "row": self.row,
                "column": self.column,
                "value": self.value,
                "color": self.color,
                "hash": self.hash,
                "file_name": self.file_name,
                "inverted_row": self.inverted_row,
                "workbook_name": self.workbook_name,
                'current_class': self.__class__.__name__
            }

    def __str__(self) -> str:
        return f"RawExcelCellNode(workbook_name={self.workbook_name}, cell_address={self.coordinate}, cell_value={self.value})"

class RawExcelCellEdge:
    def __init__(
        self,
        source: ExcelCells,
        destination: ExcelCells,
        edge_type: str) \
        -> None:
        self.source = \
            source
        self.destination = \
            destination
        self.edge_type = \
            edge_type
        
    def to_dict(
        self) \
        -> dict:
        return \
            {
                "source": self.source.cell_workbook_value_hash,
                "destination": self.destination.cell_workbook_value_hash,
                "edge_type": self.edge_type
            }

def add_inverted_row_number_to_cells(
    cells: List[RawExcelCellNode]) \
    -> List[RawExcelCellNode]:
    max_row = \
        max(cell.row for cell in cells)
    # make the smallest row number the largest, and vice versa
    for cell in cells:
        cell.inverted_row = \
            max_row - cell.row + 1
    
    return \
        cells

class ExcelToGridGraphConverter:
    def _create_left_to_right_edges(
            self,
            cells: List[ExcelCells]):
        edges = \
            []

        cells_by_row: Dict[int, List[ExcelCells]] = \
            {}
        
        for cell in cells:
            row = \
                cell.cell_row
            
            if row not in cells_by_row:
                cells_by_row[row] = \
                    []
                
            cells_by_row[row].append(
                cell)
            
        for row, row_cells in cells_by_row.items():
            sorted_row_cells = \
                sorted(
                    row_cells,
                    key=lambda c: c.cell_coordinate.column.index)
            
            for i in range(len(sorted_row_cells) - 1):
                left_cell = \
                    sorted_row_cells[i]
                right_cell = \
                    sorted_row_cells[i + 1]
                
                edge = \
                    RawExcelCellEdge(
                        source=left_cell,
                        destination=right_cell,
                        edge_type="LEFT_TO_RIGHT")
                
                edges.append(
                    edge)
                
        return \
            edges
    
    def _create_top_to_bottom_edges(
            self,
            cells: List[ExcelCells]):
        edges = \
            []
        
        cells_by_column: Dict[int, List[ExcelCells]] = \
            {}
        
        for cell in cells:
            column = \
                cell.cell_coordinate.column.index
            
            if column not in cells_by_column:
                cells_by_column[column] = \
                    []
                
            cells_by_column[column].append(
                cell)
            
        for column, column_cells in cells_by_column.items():
            sorted_column_cells = \
                sorted(
                    column_cells,
                    key=lambda c: c.cell_row)
            
            for i in range(len(sorted_column_cells) - 1):
                top_cell = \
                    sorted_column_cells[i]
                bottom_cell = \
                    sorted_column_cells[i + 1]
                
                edge = \
                    RawExcelCellEdge(
                        source=top_cell,
                        destination=bottom_cell,
                        edge_type="TOP_TO_BOTTOM")
                
                edges.append(
                    edge)
                
        return \
            edges
    
    def _create_grid_edges(
            self,
            cells: List[ExcelCells]):
        return \
            self._create_left_to_right_edges(cells) + \
            self._create_top_to_bottom_edges(cells)

    def _create_cell_nodes(
            self,
            cells: List[ExcelCells]):
        return \
            [RawExcelCellNode.from_excel_cell(cell) for cell in cells]

    def _create_cell_nodes_dataframe(
            self,
            cells: List[RawExcelCellNode]):
        import pandas

        return \
            pandas.DataFrame(
                [cell.to_dict() for cell in cells]
            )

    def convert_excel_cells_to_grid_graph(
            self,
            excel_cells: List[ExcelCells]):
        nodes = \
            self._create_cell_nodes(
                excel_cells)

        nodes = \
            add_inverted_row_number_to_cells(
                nodes)
        
        left_to_right_edges = \
            self._create_left_to_right_edges(
                excel_cells)
        
        top_to_bottom_edges = \
            self._create_top_to_bottom_edges(
                excel_cells)
        edges = \
            left_to_right_edges + top_to_bottom_edges
        
        return \
           nodes, edges
            
    def convert_to_grid_graph_from_worksheets(
            self,
            worksheet: ExcelWorksheets) \
            -> Tuple[List[RawExcelCellNode], List[RawExcelCellEdge]]:
        cells = \
            worksheet.cells
        
        return \
            self.convert_excel_cells_to_grid_graph(
                cells)

    def convert_to_grid_from_workbook(
            self,
            workbook: ExcelWorkbooks):
        worksheets = \
            workbook.sheets.values()
        
        for worksheet in worksheets:
            nodes, edges = \
                self.convert_to_grid_graph_from_worksheets(
                    worksheet)

            yield \
               nodes, edges
    
    def convert_workbooks_to_grid_graph(
            self,
            workbooks: List[ExcelWorkbooks]) \
            -> Tuple[List[RawExcelCellNode], List[RawExcelCellEdge]]:
        all_nodes = \
            []
        all_edges = \
            []
        
        for workbook in workbooks:
            worksheets = \
                workbook.sheets.values()
            
            for worksheet in worksheets:
                nodes, edges = \
                    self.convert_to_grid_graph_from_worksheets(
                        worksheet)
                
                all_nodes.extend(
                    nodes)
                all_edges.extend(
                    edges)
        
        return \
            all_nodes,\
            all_edges
