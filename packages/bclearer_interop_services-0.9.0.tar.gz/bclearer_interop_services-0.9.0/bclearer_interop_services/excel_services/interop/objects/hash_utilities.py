import hashlib


def get_file_content_hash(
        file_path: str) \
        -> str:
    """Fast binary hash of file content."""
    hash_obj = \
        hashlib.md5()
    
    with open(file_path, 'rb') as f:
        # Read in chunks for memory efficiency
        for chunk in iter(lambda: f.read(8192), b""):
            hash_obj.update(
                chunk)
    
    return \
        hash_obj.hexdigest()


def get_string_content_hash(input_string: str) -> str:
    """Generate MD5 hash of string content."""
    input_string = \
        str(
            input_string)
    
    hash_obj = \
        hashlib.md5()
    
    hash_obj.update(
        input_string.encode('utf-8'))
    
    return \
        hash_obj.hexdigest()


def get_string_content_hash_from_list_of_strings(list_of_strings: list) -> str:
    """Generate MD5 hash from concatenated list of strings."""
    string_value = \
        "".join(
            list_of_strings)

    hash_value = \
        get_string_content_hash(
            string_value)
        
    return \
        hash_value
