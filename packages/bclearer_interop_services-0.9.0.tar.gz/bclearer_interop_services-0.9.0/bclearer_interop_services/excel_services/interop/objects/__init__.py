"""
Excel Object Model Package

This package provides a comprehensive object model for working with Excel files.
It includes classes for workbooks, worksheets, cells, ranges, and various utilities.
"""

# Import all the main classes for easy access
from .excel_cells import ExcelCells, ExcelCellBorders
from .excel_coordinates import CellCoordinates, ExcelColumns, ExcelRows
from .excel_enums_and_constants import BorderPosition, BorderStyle, indexed_colors
from .excel_ranges import ExcelCellRanges
from .excel_sheets import ExcelWorksheets
from .excel_workbooks import ExcelWorkbooks
from .hash_utilities import (
    get_file_content_hash,
    get_string_content_hash,
    get_string_content_hash_from_list_of_strings
)
from .path_wrappers import PathWrappers

# Make all classes available at package level
__all__ = [
    # Main Excel classes
    'ExcelWorkbooks',
    'ExcelWorksheets',
    'ExcelCells',
    'ExcelCellRanges',
    'ExcelCellBorders',
    
    # Coordinate classes
    'CellCoordinates',
    'ExcelColumns',
    'ExcelRows',
    
    # Enums and constants
    'BorderPosition',
    'BorderStyle',
    'indexed_colors',
    
    # Utility classes and functions
    'PathWrappers',
    'get_file_content_hash',
    'get_string_content_hash',
    'get_string_content_hash_from_list_of_strings',
]
