from typing import Dict, Optional

from openpyxl.cell.cell import Cell as OpenpyxlCell
from openpyxl.utils import get_column_letter

from .excel_coordinates import CellCoordinates
from .excel_enums_and_constants import BorderPosition, BorderStyle
from .hash_utilities import get_string_content_hash


class ExcelCellBorders:
    """Handles Excel cell border information."""
    
    def __init__(self, cell: OpenpyxlCell, cell_coordinates: CellCoordinates):
        self.cell = \
            cell

        self.position_on_cell = \
            self._determine_border_position()

        self.style = \
            self._determine_border_style()

        self.containing_cell_coordinate = \
            cell_coordinates

        self.containg_cell_letter_coordinate = \
            cell.coordinate

    def _determine_border_position(self) -> BorderPosition:
        """Determine which borders are present and return the appropriate enum"""
        positions = BorderPosition.NONE
        
        if self._has_border(self.cell.border.top):
            positions |= BorderPosition.TOP
        if self._has_border(self.cell.border.bottom):
            positions |= BorderPosition.BOTTOM
        if self._has_border(self.cell.border.left):
            positions |= BorderPosition.LEFT
        if self._has_border(self.cell.border.right):
            positions |= BorderPosition.RIGHT
        if self._has_border(self.cell.border.diagonal):
            positions |= BorderPosition.DIAGONAL
            
        return positions
    
    def _has_border(self, border) -> bool:
        """Check if a border actually exists (has style)"""
        if border is None:
            return False
        return border.style is not None

    def _determine_border_style(self) -> BorderStyle:
        """Determine the predominant border style"""
        # Get all present border styles
        styles = []
        if self._has_border(self.cell.border.top):
            styles.append(self.cell.border.top.style)
        if self._has_border(self.cell.border.bottom):
            styles.append(self.cell.border.bottom.style)
        if self._has_border(self.cell.border.left):
            styles.append(self.cell.border.left.style)
        if self._has_border(self.cell.border.right):
            styles.append(self.cell.border.right.style)
        
        if not styles:
            return BorderStyle.NONE
            
        # Return the most common style, or first one if all different
        most_common_style = max(set(styles), key=styles.count)
        
        # Map openpyxl style to our enum
        try:
            return BorderStyle(most_common_style)
        except ValueError:
            return BorderStyle.NONE
        
    def __str__(self):
        return \
            f"{self.containg_cell_letter_coordinate} - {self.style} - {self.position_on_cell}"


class ExcelCells:
    """Represents an Excel cell with all its properties."""
    
    def __init__(
            self, 
            cell: OpenpyxlCell, 
            cell_coordinates: CellCoordinates,
            owning_excel_worksheet: "ExcelWorksheets"): # type: ignore
        self.cell = \
            cell
        
        self.cell_value = \
            self._clean_cell_value(
                cell.value)
        
        self.cell_coordinate = \
            cell_coordinates
        
        self.cell_row = \
            cell.row
        
        self.color = \
            self._get_cell_color()

        self.cell_value_hash = \
            get_string_content_hash(
                f"{self.cell_value}{cell.coordinate}")
            
        self.owning_excel_workbook = \
            owning_excel_worksheet.owning_excel_workbook
        
        self.cell_workbook_value_hash = \
            get_string_content_hash(
                f"{self.cell_value}{cell.coordinate}{owning_excel_worksheet.workbook_name}")
            
        self.border = \
            ExcelCellBorders(
                cell,
                cell_coordinates)
            
        self.comment = \
            cell.comment

        self.owning_excel_worksheet = \
            owning_excel_worksheet
        
        # Dictionary to track cell types by stage
        self.stage_cell_types: Dict[str, str] = {}

    @property
    def inverted_row(self):
        return self._inverted_row

    @inverted_row.setter
    def inverted_row(self, value):
        self._inverted_row = value

    def _clean_cell_value(self, value):
        """Clean newline and tab characters from cell values to prevent CSV export issues."""
        if value is None:
            return value
        
        if isinstance(value, str):
            value = value.replace('\n', ' ')
            value = value.replace('\t', ' ')
            value = value.replace('\r', ' ')
            # Clean up multiple spaces
            value = ' '.join(value.split())
        
        return value

    @property
    def workbook_name(self):
        return self.owning_excel_worksheet.workbook_name

    @property
    def value(self):
        return self.cell_value

    @value.setter
    def value(self, value):
        cleaned_value = self._clean_cell_value(value)
        # Check if this is a MergedCell (which has read-only value)
        try:
            self.cell.value = cleaned_value
        except AttributeError:
            # If it's a MergedCell, we can't set the value directly
            # Just update our internal cell_value
            pass
        self.cell_value = cleaned_value

    @property
    def coordinate(self):
        return self.cell.coordinate
    
    def _get_cell_color(self):
        color = self.cell.fill.start_color.index
        return color 
    
    @property
    def is_part_of_merged_cell(self) -> bool:
        """Check if this cell is part of a merged range."""
        return self._check_if_merged()
    
    @property
    def merged_range_info(self) -> Optional[Dict]:
        """Get information about the merged range this cell belongs to."""
        return self._get_merged_range_info()
    
    @property
    def is_top_left_of_merged_cell(self) -> bool:
        if not self.is_part_of_merged_cell:
            return \
                False
                
        is_top_left = \
            self._get_merged_range_info()['is_top_left']
        
        return \
            is_top_left

    @property
    def merged_parent_hash(self) -> Optional[str]:
        """Return a hash of the top-left cell coordinate and workbook name in the merged range."""
        if not self.is_part_of_merged_cell:
            return None
        info = self._get_merged_range_info()
        coord = f"{get_column_letter(info['min_col'])}{info['min_row']}"
        
        # Get the parent cell's value (top-left cell of the merged range)
        parent_cell = self.cell_coordinate.row.sheet.cell(info['min_row'], info['min_col'])
        parent_value = self._clean_cell_value(parent_cell.value)
        
        # Use parent cell's value, coordinate, and workbook name for hash calculation
        return get_string_content_hash(f"{parent_value}{coord}{self.owning_excel_workbook.workbook_name}")
    
    @property
    def get_merged_parent_cell(self):
        pass

    def _check_if_merged(self) -> bool:
        """Internal method to check if cell is in a merged range."""
        sheet = self.cell_coordinate.row.sheet
        for merged_range in sheet.merged_cells.ranges:
            if (merged_range.min_row <= self.cell_row <= merged_range.max_row and
                merged_range.min_col <= self.cell_coordinate.column.index <= merged_range.max_col):
                return True
        return False
    
    def _get_merged_range_info(self) -> Optional[Dict]:
        """Get detailed information about the merged range this cell belongs to."""
        sheet = self.cell_coordinate.row.sheet
        for merged_range in sheet.merged_cells.ranges:
            if (merged_range.min_row <= self.cell_row <= merged_range.max_row and
                merged_range.min_col <= self.cell_coordinate.column.index <= merged_range.max_col):
                return {
                    'range_string': str(merged_range),
                    'min_row': merged_range.min_row,
                    'max_row': merged_range.max_row,
                    'min_col': merged_range.min_col,
                    'max_col': merged_range.max_col,
                    'is_top_left': (self.cell_row == merged_range.min_row and 
                                   self.cell_coordinate.column.index == merged_range.min_col),
                    'cell_count': (merged_range.max_row - merged_range.min_row + 1) * 
                                 (merged_range.max_col - merged_range.min_col + 1)
                }
        return None
