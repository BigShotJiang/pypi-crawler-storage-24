from openpyxl.worksheet.worksheet import Worksheet as OpenpyxlWorksheet


class ExcelColumns:
    """Represents an Excel column."""
    
    def __init__(self, sheet: OpenpyxlWorksheet, index: int):
        self.sheet = sheet
        self.index = index


class ExcelRows:
    """Represents an Excel row."""
    
    def __init__(self, sheet: OpenpyxlWorksheet, index: int):
        self.sheet = sheet
        self.index = index


class CellCoordinates:
    """Represents cell coordinates with row and column."""
    
    def __init__(self, row: ExcelRows, column: ExcelColumns):
        self.row = row
        self.column = column
