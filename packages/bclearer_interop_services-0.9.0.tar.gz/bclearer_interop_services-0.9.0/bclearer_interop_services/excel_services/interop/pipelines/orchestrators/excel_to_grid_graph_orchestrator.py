from bclearer_interop_services.excel_services.interop.pipelines.excel_to_grid_graph.objects.excel_to_grid_graph_universe import ExcelToGridGraphUniverse
from bclearer_interop_services.excel_services.interop.pipelines.excel_to_grid_graph.orchestrators.excel_files_to_excel_object_model_orchestrator import orchestrate_excel_files_to_excel_model
from bclearer_interop_services.excel_services.interop.pipelines.excel_to_grid_graph.orchestrators.excel_object_model_to_grid_graph_orchestrator import orchestrate_excel_object_model_to_grid_graph


def orchestrate_excel_to_grid_graph_pipeline(
        excel_to_grid_graph_universe: ExcelToGridGraphUniverse) \
        -> ExcelToGridGraphUniverse:
    excel_to_grid_graph_universe = \
        orchestrate_excel_files_to_excel_model(
            excel_to_grid_graph_universe=excel_to_grid_graph_universe)
    
    excel_to_grid_graph_universe = \
        orchestrate_excel_object_model_to_grid_graph(
            excel_to_grid_graph_universe=excel_to_grid_graph_universe)

    return \
        excel_to_grid_graph_universe