from typing import Dict

from bclearer_interop_services.excel_services.interop.objects.excel_sheets import ExcelWorksheets

class WorksheetRegister:
    def __init__(self):
        self.worksheets: Dict[str, ExcelWorksheets] = \
            {}

    def register_worksheet(
            self,
            worksheet: ExcelWorksheets) \
            -> None:
        self.worksheets[worksheet.worksheet_name] = \
            worksheet

    def get_worksheet(
            self,
            worksheet_name: str) \
            -> ExcelWorksheets | None:
        return \
            self.worksheets.get(
                worksheet_name)
    
    def set_with_dictionary(
            self,
            dictionary: Dict[str, ExcelWorksheets])\
            -> None:
        self.worksheets = \
            dictionary

    def __str__(self) -> str:
        """
        Returns a formatted string representation of the worksheet register contents.
        """
        worksheet_count = len(self.worksheets)
        if worksheet_count == 0:
            return "Worksheet register: 0 worksheets"
        
        lines = [f"Worksheet register: {worksheet_count} worksheets"]
        for worksheet_name, worksheet in self.worksheets.items():
            cell_count = len(worksheet.cells)
            workbook_name = worksheet.workbook_name
            lines.append(f"  - {worksheet_name} (from {workbook_name}): {cell_count} cells")
        
        return "\n".join(lines)
