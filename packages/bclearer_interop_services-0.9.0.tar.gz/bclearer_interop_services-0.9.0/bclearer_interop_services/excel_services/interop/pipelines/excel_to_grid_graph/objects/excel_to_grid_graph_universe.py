from bclearer_interop_services.excel_services.interop.pipelines.excel_to_grid_graph.objects.excel_to_grid_graph_universe_registries import ExcelToGridGraphUniverseRegistries


class ExcelToGridGraphUniverse:
    def __init__(
            self):
        self.registries = \
            ExcelToGridGraphUniverseRegistries(
                self)