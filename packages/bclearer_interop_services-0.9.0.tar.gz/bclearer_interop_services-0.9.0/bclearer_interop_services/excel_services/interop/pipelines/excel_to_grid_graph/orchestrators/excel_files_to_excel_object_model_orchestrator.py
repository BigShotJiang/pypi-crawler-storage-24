from bclearer_interop_services.excel_services.interop.factories.excel_workbook_factories import ExcelWorkbookFactories
from bclearer_interop_services.excel_services.interop.pipelines.excel_to_grid_graph.objects.excel_files_to_grid_graph_configuration_names import EXCEL_GRID_TO_GRAPH_CONFIGURATION_NAMES
from bclearer_interop_services.excel_services.interop.pipelines.excel_to_grid_graph.objects.excel_to_grid_graph_universe import ExcelToGridGraphUniverse


def orchestrate_excel_files_to_excel_model(
    excel_to_grid_graph_universe: ExcelToGridGraphUniverse)\
    -> ExcelToGridGraphUniverse:
    excels_folder_path = \
        excel_to_grid_graph_universe.registries.configuration_register.get(
            EXCEL_GRID_TO_GRAPH_CONFIGURATION_NAMES.EXCELS_FOLDER_PATH)
    
    excel_workbooks = \
        ExcelWorkbookFactories.from_folder_path(
            excels_folder=excels_folder_path)
    
    excel_to_grid_graph_universe.registries.workbook_register.set_with_dictionary(
        dictionary=excel_workbooks)
    
    return \
        excel_to_grid_graph_universe