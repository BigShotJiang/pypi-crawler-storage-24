from bclearer_interop_services.excel_services.interop.objects.excel_cells import ExcelCells
from bclearer_interop_services.excel_services.interop.operations.excel_cell_services import ExcelCellServices


class GridGraphNodes:
    def __init__(
            self,
            base_excel_cell: ExcelCells):
        self.base_excel_cell = \
            base_excel_cell

    def to_dict(
        self)\
        -> dict:
        return \
            ExcelCellServices.to_dictionary(
                excel_cell=self.base_excel_cell)
