
from bclearer_interop_services.excel_services.interop.pipelines.excel_to_grid_graph.objects.excel_to_grid_graph_table_names import ExcelToGridGraphTableNames


from bclearer_interop_services.excel_services.interop.pipelines.excel_to_grid_graph.objects.registers.grid_graph_register import GridGraphRegister
from bclearer_interop_services.excel_services.interop.pipelines.excel_to_grid_graph.objects.registers.workbook_register import WorkbookRegister
from bclearer_interop_services.dataframe_service.registers.pandas_dataframe_registers import PandasDataframeRegisters


class ExcelToGridGraphUniverseRegistries:
    def __init__(
        self,
        owning_excel_to_grid_graph_universe):
        from bclearer_interop_services.excel_services.interop.pipelines.excel_to_grid_graph.objects.excel_to_grid_graph_universe import \
            ExcelToGridGraphUniverse

        self.owning_excel_to_grid_graph_universe: ExcelToGridGraphUniverse = \
            owning_excel_to_grid_graph_universe

        self.configuration_register = \
            {}

        self.table_register = \
            PandasDataframeRegisters(
                allowed_table_names=ExcelToGridGraphTableNames)

        self.workbook_register = \
            WorkbookRegister()
        
        self.grid_graph_register = \
            GridGraphRegister()