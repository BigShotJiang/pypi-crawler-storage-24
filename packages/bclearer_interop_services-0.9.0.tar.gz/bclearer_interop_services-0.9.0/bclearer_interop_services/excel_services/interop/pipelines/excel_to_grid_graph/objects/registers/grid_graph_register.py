from typing import List, Tuple

import pandas
from bclearer_interop_services.excel_services.interop.pipelines.excel_to_grid_graph.objects.grid_graph.grid_graph import GridGraph


class GridGraphRegister:
    def __init__(
        self):
        self._grid_graphs: List[GridGraph] = \
            []

    def register_grid_graphs(
        self,
        grid_graphs: List[GridGraph]):
        self._grid_graphs.extend(
            grid_graphs)
        
    def get_grid_graphs(
        self) \
        -> List[GridGraph]:

        return \
            self._grid_graphs
    
    def get_grid_graph_by_hash(
        self,
        grid_graph_hash: str) \
        -> GridGraph:
        for grid_graph in self._grid_graphs:
            if grid_graph.source_workbook_hash == grid_graph_hash:
                return \
                    grid_graph
            
        raise \
            KeyError(f"Grid graph with hash {grid_graph_hash} not found.")
    
    def get_all_nodes_and_edges_as_pandas_dataframes(
        self) \
        -> Tuple[pandas.DataFrame, pandas.DataFrame]:
        all_edges_dfs = \
            []
        all_nodes_dfs = \
            []
        for grid_graph in self._grid_graphs:
            nodes_df = \
                grid_graph.get_nodes_dataframe()
            
            edges_df = \
                grid_graph.get_edges_dataframe()
            
            all_nodes_dfs.append(
                nodes_df)
            
            all_edges_dfs.append(
                edges_df)
            
        all_nodes_dfs = \
            pandas.concat(
                all_nodes_dfs,
                ignore_index=True)
        
        all_edges_dfs = \
            pandas.concat(
                all_edges_dfs,
                ignore_index=True)

        return \
            all_nodes_dfs,\
            all_edges_dfs
