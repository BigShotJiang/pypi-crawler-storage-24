from typing import List, Tuple

import pandas

from bclearer_interop_services.excel_services.interop.pipelines.excel_to_grid_graph.objects.grid_graph.grid_graph_edges import GridGraphEdges
from bclearer_interop_services.excel_services.interop.pipelines.excel_to_grid_graph.objects.grid_graph.grid_graph_nodes import GridGraphNodes


class GridGraph:
    def __init__(
        self,
        name: str,
        source_workbook_hash: str,
        source_worksheet_hash: str,
        grid_graph_nodes: List[GridGraphNodes] = None,
        grid_graph_edges: List[GridGraphEdges] = None):
        self.name = \
            name
        
        self.source_workbook_hash = \
            source_workbook_hash
        
        self.source_worksheet_hash = \
            source_worksheet_hash

        self.nodes: List[GridGraphNodes] = \
            grid_graph_nodes if grid_graph_nodes is not None else []

        self.edges: List[GridGraphEdges] = \
            grid_graph_edges if grid_graph_edges is not None else []

    def get_nodes_dataframe(
        self) \
        -> pandas.DataFrame:
        nodes = \
            [
                node.to_dict()
                for node in self.nodes
            ]
        
        return \
            pandas.DataFrame(
                nodes)

    def get_edges_dataframe(
        self) \
        -> pandas.DataFrame:
        edges = \
            [
                edge.to_dict()
                for edge in self.edges
            ]

        return \
            pandas.DataFrame(
                edges)

    def to_pandas_dataframes(
        self)\
        -> Tuple[pandas.DataFrame, pandas.DataFrame]:
        return \
            (
                self.get_nodes_dataframe(),
                self.get_edges_dataframe()
            )