from enum import Enum


class EXCEL_GRID_TO_GRAPH_CONFIGURATION_NAMES(Enum):
    EXCELS_FOLDER_PATH = "excels_folder_path"