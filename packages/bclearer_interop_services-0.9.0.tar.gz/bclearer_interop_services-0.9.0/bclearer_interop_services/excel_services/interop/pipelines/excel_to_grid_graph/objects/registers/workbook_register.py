from typing import Dict, List

from bclearer_interop_services.excel_services.interop.objects.excel_workbooks import ExcelWorkbooks

class WorkbookRegister():
    def __init__(
            self):
        self.workbooks: Dict[str, ExcelWorkbooks] = \
            {}

    def register_workbook(
            self,
            workbook: ExcelWorkbooks)\
            -> None:
        self.workbooks[workbook.workbook_name] = \
            workbook

    def get_workbook(
            self,
            workbook_name: str) \
            -> ExcelWorkbooks | None:
        return \
            self.workbooks.get(
                workbook_name)
    
    def set_with_dictionary(
            self,
            dictionary: Dict[str, ExcelWorkbooks])\
            -> None:
        self.workbooks = \
            dictionary
        
    def get_workbooks(
            self) \
            -> List[ExcelWorkbooks]:
        return [
            workbook
            for workbook in self.workbooks.values()
        ]

    def __str__(self) -> str:
        """
        Returns a formatted string representation of the workbook register contents.
        """
        workbook_count = len(self.workbooks)
        if workbook_count == 0:
            return "Workbooks: 0"
        
        lines = [f"Workbooks: {workbook_count}"]
        for workbook_name, workbook in self.workbooks.items():
            worksheet_count = len(workbook.sheets)
            worksheet_details = []
            
            # Get cell counts per worksheet for this workbook
            for worksheet_name, worksheet in workbook.sheets.items():
                cell_count = len(worksheet.cells)
                worksheet_details.append(f"{worksheet_name}: {cell_count} cells")
            
            worksheet_summary = ", ".join(worksheet_details)
            lines.append(f"  - {workbook_name}: {worksheet_count} worksheets ({worksheet_summary})")
        
        return "\n".join(lines)
