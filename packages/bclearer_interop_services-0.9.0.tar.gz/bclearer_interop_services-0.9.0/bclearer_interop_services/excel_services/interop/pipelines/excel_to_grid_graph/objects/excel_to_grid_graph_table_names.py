from enum import Enum


class ExcelToGridGraphTableNames(Enum):
    RAW_EXCEL_CELL_NODES = "raw_excel_cell_nodes"
    RAW_EXCEL_CELL_EDGES = "raw_excel_cell_edges"