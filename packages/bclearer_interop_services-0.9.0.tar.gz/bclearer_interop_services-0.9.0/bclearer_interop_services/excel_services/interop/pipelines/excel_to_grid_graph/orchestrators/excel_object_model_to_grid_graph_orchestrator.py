from bclearer_interop_services.excel_services.interop.operations.excel_workbook_to_grid_graph_converter import convert_excel_to_grid_graph_universe_to_grid_graphs
from bclearer_interop_services.excel_services.interop.pipelines.excel_to_grid_graph.objects.excel_to_grid_graph_universe import ExcelToGridGraphUniverse


def orchestrate_excel_object_model_to_grid_graph(
    excel_to_grid_graph_universe: ExcelToGridGraphUniverse) \
    -> ExcelToGridGraphUniverse:
    excel_to_grid_graph_universe = \
        convert_excel_to_grid_graph_universe_to_grid_graphs(
            excel_to_grid_graph_universe=excel_to_grid_graph_universe)
    
    return \
        excel_to_grid_graph_universe