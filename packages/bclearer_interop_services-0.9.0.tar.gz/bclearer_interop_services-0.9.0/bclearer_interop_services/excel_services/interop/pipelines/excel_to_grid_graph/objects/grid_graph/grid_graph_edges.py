from bclearer_interop_services.excel_services.interop.pipelines.excel_to_grid_graph.objects.grid_graph.grid_graph_nodes import GridGraphNodes


class GridGraphEdges:
    def __init__(
            self,
            source: GridGraphNodes,
            destination: GridGraphNodes,
            edge_type: str):
        self.source = \
            source
        self.destination = \
            destination
        self.edge_type = \
            edge_type
        
    def to_dict(
        self)\
        -> dict:
        return \
            {
                "source": self.source.base_excel_cell.cell_workbook_value_hash,
                "destination": self.destination.base_excel_cell.cell_workbook_value_hash,
                "edge_type": self.edge_type
            }