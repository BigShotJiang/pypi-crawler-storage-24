"""Export data from GridGraph to various formats.

This module provides a unified interface for exporting GridGraph data
to multiple formats including NetworkX, Pandas DataFrames, GraphML,
JSON, CSV, Neo4j, and Raphtory. It follows the same patterns as
RaphtoryDataExporters and Neo4jDataExporters.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import TYPE_CHECKING, Any, Callable

import networkx as nx
import pandas as pd

if TYPE_CHECKING:
    from bclearer_interop_services.excel_services.interop.pipelines.excel_to_grid_graph.objects.grid_graph.grid_graph import (
        GridGraph,
    )
    from bclearer_interop_services.graph_services.neo4j_service.neo4j_service_facade import (
        Neo4jServiceFacade,
    )
    from bclearer_interop_services.graph_services.raphtory_service.raphtory_service_facade import (
        RaphtoryServiceFacade,
    )


class GridGraphDataExporters:
    """Export data from a GridGraph to various formats.

    This class provides methods to export grid graph data to:
    - NetworkX DiGraph (central hub for other conversions)
    - Pandas DataFrames (nodes and edges separately)
    - GraphML files
    - JSON files (adjacency list format)
    - CSV files (nodes and edges separately)
    - B-Dictionary format (for bclearer integration)
    - Neo4j graph database
    - Raphtory temporal graph

    Example:
        >>> from bclearer_interop_services.excel_services.interop.pipelines.excel_to_grid_graph.orchestrators.grid_graph_data_exporters import (
        ...     GridGraphDataExporters,
        ... )
        >>> exporter = GridGraphDataExporters(grid_graph)
        >>> nx_graph = exporter.to_networkx()
        >>> nodes_df = exporter.to_pandas_nodes()
        >>> exporter.to_graphml("output/graph.graphml")

        # Export to Neo4j
        >>> from bclearer_interop_services.graph_services.neo4j_service.neo4j_service_facade import Neo4jServiceFacade
        >>> neo4j = Neo4jServiceFacade(configuration_file="config.ini")
        >>> exporter.to_neo4j(neo4j, node_label="GridCell", relationship_type="ADJACENT")

        # Export to Raphtory
        >>> from bclearer_interop_services.graph_services.raphtory_service.raphtory_service_facade import RaphtoryServiceFacade
        >>> raphtory = RaphtoryServiceFacade(configuration_file="config.json")
        >>> exporter.to_raphtory(raphtory, graph_name="excel_grid")
    """

    def __init__(self, grid_graph: GridGraph) -> None:
        """Create a new exporter for the given grid graph.

        Args:
            grid_graph: The GridGraph instance to export
        """
        self.grid_graph = grid_graph
        self._nx_graph_cache: nx.DiGraph | None = None

    def to_networkx(self) -> nx.DiGraph:
        """Return the grid graph as a NetworkX DiGraph.

        This is the primary conversion method. All other export formats
        leverage the NetworkX graph as an intermediate representation.

        Returns:
            NetworkX DiGraph with nodes and edges from the grid graph.
            Node IDs are cell workbook value hashes.
            Edge attributes include edge_type (LEFT_TO_RIGHT or TOP_TO_BOTTOM).
        """
        if self._nx_graph_cache is not None:
            return self._nx_graph_cache

        nx_graph = nx.DiGraph()

        # Add nodes with their attributes
        for node in self.grid_graph.nodes:
            node_dict = node.to_dict()
            node_id = node.base_excel_cell.cell_workbook_value_hash
            nx_graph.add_node(node_id, **node_dict)

        # Add edges with their attributes
        for edge in self.grid_graph.edges:
            source_id = edge.source.base_excel_cell.cell_workbook_value_hash
            dest_id = edge.destination.base_excel_cell.cell_workbook_value_hash
            nx_graph.add_edge(source_id, dest_id, edge_type=edge.edge_type)

        self._nx_graph_cache = nx_graph
        return nx_graph

    def to_pandas_nodes(self) -> pd.DataFrame:
        """Return nodes of the grid graph as a DataFrame.

        Returns:
            DataFrame with columns: id, coordinate, row, column, value,
            color, hash, cell_value_hash, inverted_row, file_name,
            workbook_name, current_class
        """
        nx_graph = self.to_networkx()
        rows = [
            {"id": node, **data}
            for node, data in nx_graph.nodes(data=True)
        ]
        return pd.DataFrame(rows)

    def to_pandas_edges(self) -> pd.DataFrame:
        """Return edges of the grid graph as a DataFrame.

        Returns:
            DataFrame with columns: source, destination, edge_type
        """
        nx_graph = self.to_networkx()
        rows = [
            {"source": u, "destination": v, **data}
            for u, v, data in nx_graph.edges(data=True)
        ]
        return pd.DataFrame(rows)

    def to_table_dictionary(self) -> dict[str, Any]:
        """Return the grid graph as B-Dictionary tables.

        This format is used for integration with bclearer services.

        Returns:
            Dictionary with 'nodes' and 'edges' keys containing
            B-Dictionary table representations.
        """
        from bclearer_interop_services.b_dictionary_service.dataframe_to_table_b_dictionary_converter import (
            convert_dataframe_to_table_b_dictionary,
        )
        from bclearer_orchestration_services.identification_services.b_identity_ecosystem.bie_id_creators.bie_id_for_single_object_creator import (
            create_bie_id_for_single_object,
        )

        nodes = self.to_pandas_nodes()
        edges = self.to_pandas_edges()

        node_id = create_bie_id_for_single_object("grid_graph_nodes")
        edge_id = create_bie_id_for_single_object("grid_graph_edges")

        node_table = convert_dataframe_to_table_b_dictionary(
            dataframe=nodes,
            table_name="grid_graph_nodes",
            bie_table_id=node_id,
        )
        edge_table = convert_dataframe_to_table_b_dictionary(
            dataframe=edges,
            table_name="grid_graph_edges",
            bie_table_id=edge_id,
        )

        return {
            "nodes": node_table,
            "edges": edge_table,
        }

    def to_graphml(self, file_path: str | Path) -> None:
        """Export the grid graph to a GraphML file.

        Args:
            file_path: Path where the GraphML file will be written.
                      Must end with '.graphml'.

        Raises:
            ValueError: If file_path doesn't end with '.graphml'
            FileNotFoundError: If the parent directory doesn't exist
            OSError: If the file cannot be written
        """
        path = Path(file_path)

        if path.suffix != ".graphml":
            raise ValueError("file_path must end with .graphml")

        if not path.parent.exists():
            raise FileNotFoundError(f"directory does not exist: {path.parent}")

        nx_graph = self.to_networkx()

        # Clean None values for GraphML compatibility
        clean_graph = nx_graph.copy()
        for node_id, node_data in clean_graph.nodes(data=True):
            for key, value in list(node_data.items()):
                if value is None:
                    node_data[key] = ""

        try:
            nx.write_graphml(
                clean_graph,
                path,
                encoding="utf-8",
                prettyprint=True,
            )
        except OSError as err:
            msg = f"failed to write GraphML to {path}"
            raise OSError(msg) from err

    def to_json(self, file_path: str | Path) -> None:
        """Export the grid graph to a JSON file with adjacency information.

        The JSON structure includes node attributes and adjacency lists
        organized by edge type (left_to_right, top_to_bottom).

        Args:
            file_path: Path where the JSON file will be written.
                      Must end with '.json'.

        Raises:
            ValueError: If file_path doesn't end with '.json'
            FileNotFoundError: If the parent directory doesn't exist
            OSError: If the file cannot be written
        """
        path = Path(file_path)

        if path.suffix != ".json":
            raise ValueError("file_path must end with .json")

        if not path.parent.exists():
            raise FileNotFoundError(f"directory does not exist: {path.parent}")

        nx_graph = self.to_networkx()

        adjacency: dict[str, Any] = {}
        for node in nx_graph.nodes():
            node_data = nx_graph.nodes[node]
            adjacency[node] = {
                "attributes": {
                    k: v if v is not None else ""
                    for k, v in node_data.items()
                },
                "left_to_right": [],
                "top_to_bottom": [],
            }
            for neighbor in nx_graph.successors(node):
                edge_data = nx_graph.edges[node, neighbor]
                if edge_data.get("edge_type") == "LEFT_TO_RIGHT":
                    adjacency[node]["left_to_right"].append(neighbor)
                elif edge_data.get("edge_type") == "TOP_TO_BOTTOM":
                    adjacency[node]["top_to_bottom"].append(neighbor)

        try:
            with open(path, "w", encoding="utf-8") as f:
                json.dump(adjacency, f, indent=2)
        except OSError as err:
            msg = f"failed to write JSON to {path}"
            raise OSError(msg) from err

    def to_csv(
        self,
        nodes_file_path: str | Path,
        edges_file_path: str | Path,
    ) -> None:
        """Export the grid graph to CSV files (nodes and edges separately).

        Args:
            nodes_file_path: Path for the nodes CSV file. Must end with '.csv'.
            edges_file_path: Path for the edges CSV file. Must end with '.csv'.

        Raises:
            ValueError: If file paths don't end with '.csv'
            FileNotFoundError: If parent directories don't exist
            OSError: If files cannot be written
        """
        nodes_path = Path(nodes_file_path)
        edges_path = Path(edges_file_path)

        if nodes_path.suffix != ".csv":
            raise ValueError("nodes_file_path must end with .csv")

        if edges_path.suffix != ".csv":
            raise ValueError("edges_file_path must end with .csv")

        if not nodes_path.parent.exists():
            raise FileNotFoundError(
                f"directory does not exist: {nodes_path.parent}"
            )

        if not edges_path.parent.exists():
            raise FileNotFoundError(
                f"directory does not exist: {edges_path.parent}"
            )

        nodes_df = self.to_pandas_nodes()
        edges_df = self.to_pandas_edges()

        try:
            nodes_df.to_csv(nodes_path, index=False)
        except OSError as err:
            msg = f"failed to write nodes CSV to {nodes_path}"
            raise OSError(msg) from err

        try:
            edges_df.to_csv(edges_path, index=False)
        except OSError as err:
            msg = f"failed to write edges CSV to {edges_path}"
            raise OSError(msg) from err

    def to_edge_list(self, file_path: str | Path) -> None:
        """Export the grid graph edges to a text file (edge list format).

        Args:
            file_path: Path for the edge list file. Must end with '.txt'.

        Raises:
            ValueError: If file_path doesn't end with '.txt'
            FileNotFoundError: If the parent directory doesn't exist
            OSError: If the file cannot be written
        """
        path = Path(file_path)

        if path.suffix != ".txt":
            raise ValueError("file_path must end with .txt")

        if not path.parent.exists():
            raise FileNotFoundError(f"directory does not exist: {path.parent}")

        nx_graph = self.to_networkx()

        try:
            nx.write_edgelist(nx_graph, path)
        except OSError as err:
            msg = f"failed to write edge list to {path}"
            raise OSError(msg) from err

    def get_summary(self) -> dict[str, Any]:
        """Return a summary of the grid graph properties.

        Returns:
            Dictionary containing graph metadata and statistics.
        """
        nx_graph = self.to_networkx()

        left_to_right_count = sum(
            1 for _, _, d in nx_graph.edges(data=True)
            if d.get("edge_type") == "LEFT_TO_RIGHT"
        )
        top_to_bottom_count = sum(
            1 for _, _, d in nx_graph.edges(data=True)
            if d.get("edge_type") == "TOP_TO_BOTTOM"
        )

        return {
            "name": self.grid_graph.name,
            "source_workbook_hash": self.grid_graph.source_workbook_hash,
            "source_worksheet_hash": self.grid_graph.source_worksheet_hash,
            "node_count": nx_graph.number_of_nodes(),
            "edge_count": nx_graph.number_of_edges(),
            "left_to_right_edge_count": left_to_right_count,
            "top_to_bottom_edge_count": top_to_bottom_count,
            "is_directed": nx_graph.is_directed(),
            "is_weakly_connected": (
                nx.is_weakly_connected(nx_graph)
                if nx_graph.number_of_nodes() > 0
                else False
            ),
        }

    def to_neo4j(
        self,
        neo4j_facade: Neo4jServiceFacade,
        *,
        node_label: str = "GridCell",
        relationship_type: str = "ADJACENT",
        batch_size: int = 10_000,
        workers: int = 4,
        clear_existing: bool = False,
        node_progress_callback: Callable[[int, int], None] | None = None,
        edge_progress_callback: Callable[[int, int], None] | None = None,
    ) -> dict[str, int]:
        """Export the grid graph to a Neo4j database.

        Loads nodes and edges into Neo4j using the provided facade.
        Nodes are created with the specified label and all cell properties.
        Edges are created as relationships with edge_type property.

        Args:
            neo4j_facade: An initialized Neo4jServiceFacade instance.
            node_label: Label for the nodes in Neo4j. Default: "GridCell".
            relationship_type: Type for the relationships. Default: "ADJACENT".
            batch_size: Number of records per batch. Default: 10,000.
            workers: Number of concurrent worker threads. Default: 4.
            clear_existing: If True, delete existing nodes with the same label
                           before loading. Default: False.
            node_progress_callback: Optional callback(current, total) for node
                                   loading progress.
            edge_progress_callback: Optional callback(current, total) for edge
                                   loading progress.

        Returns:
            Dictionary with 'nodes_loaded' and 'edges_loaded' counts.

        Example:
            >>> from bclearer_interop_services.graph_services.neo4j_service.neo4j_service_facade import Neo4jServiceFacade
            >>> neo4j = Neo4jServiceFacade(configuration_file="config.ini")
            >>> result = exporter.to_neo4j(neo4j, node_label="ExcelCell")
            >>> print(f"Loaded {result['nodes_loaded']} nodes")
        """
        nodes_df = self.to_pandas_nodes()
        edges_df = self.to_pandas_edges()

        # Optionally clear existing data
        if clear_existing:
            neo4j_facade.run_query(f"MATCH (n:{node_label}) DETACH DELETE n")

        # Cypher query for nodes - using MERGE to avoid duplicates
        node_query = f"""
        UNWIND $batch AS row
        MERGE (n:{node_label} {{id: row.id}})
        SET n.coordinate = row.coordinate,
            n.row = row.row,
            n.column = row.column,
            n.value = row.value,
            n.color = row.color,
            n.hash = row.hash,
            n.cell_value_hash = row.cell_value_hash,
            n.inverted_row = row.inverted_row,
            n.file_name = row.file_name,
            n.workbook_name = row.workbook_name,
            n.source_workbook_hash = '{self.grid_graph.source_workbook_hash}',
            n.source_worksheet_hash = '{self.grid_graph.source_worksheet_hash}'
        """

        # Cypher query for relationships
        edge_query = f"""
        UNWIND $batch AS row
        MATCH (src:{node_label} {{id: row.source}})
        MATCH (dst:{node_label} {{id: row.destination}})
        CREATE (src)-[r:{relationship_type} {{edge_type: row.edge_type}}]->(dst)
        """

        # Load nodes and relationships
        neo4j_facade.load_graph(
            nodes=nodes_df,
            node_query=node_query,
            relationships=edges_df,
            relationship_query=edge_query,
            batch_size=batch_size,
            workers=workers,
            node_progress_callback=node_progress_callback,
            relationship_progress_callback=edge_progress_callback,
        )

        return {
            "nodes_loaded": len(nodes_df),
            "edges_loaded": len(edges_df),
        }

    def to_raphtory(
        self,
        raphtory_facade: RaphtoryServiceFacade,
        graph_name: str,
        *,
        timestamp: int = 0,
        create_graph: bool = True,
        node_properties: list[str] | None = None,
        edge_properties: list[str] | None = None,
    ) -> dict[str, int]:
        """Export the grid graph to a Raphtory temporal graph.

        Loads nodes and edges into Raphtory using the provided facade.
        Since Raphtory is a temporal graph system, a timestamp is required.
        By default, all nodes and edges are assigned timestamp 0.

        Args:
            raphtory_facade: An initialized RaphtoryServiceFacade instance.
            graph_name: Name for the graph in Raphtory.
            timestamp: Timestamp to assign to all nodes and edges. Default: 0.
            create_graph: If True, create a new graph. If False, use existing.
                         Default: True.
            node_properties: List of node property names to include.
                            Default: ["coordinate", "row", "column", "value",
                                      "workbook_name"].
            edge_properties: List of edge property names to include.
                            Default: ["edge_type"].

        Returns:
            Dictionary with 'nodes_loaded' and 'edges_loaded' counts.

        Example:
            >>> from bclearer_interop_services.graph_services.raphtory_service.raphtory_service_facade import RaphtoryServiceFacade
            >>> raphtory = RaphtoryServiceFacade(configuration_file="config.json")
            >>> result = exporter.to_raphtory(raphtory, "my_grid_graph")
            >>> print(f"Loaded {result['nodes_loaded']} nodes")
        """
        # Set default properties if not specified
        if node_properties is None:
            node_properties = [
                "coordinate",
                "row",
                "column",
                "value",
                "workbook_name",
            ]

        if edge_properties is None:
            edge_properties = ["edge_type"]

        # Get DataFrames
        nodes_df = self.to_pandas_nodes()
        edges_df = self.to_pandas_edges()

        # Add timestamp column
        nodes_df["timestamp"] = timestamp
        edges_df["timestamp"] = timestamp

        # Create or get graph
        if create_graph:
            raphtory_facade.create_graph(graph_name)

        # Get data loader
        loader = raphtory_facade.get_data_loader(graph_name)

        # Build property mappings for nodes
        node_prop_mapping = {
            prop: prop
            for prop in node_properties
            if prop in nodes_df.columns
        }

        # Load nodes
        loader.add_nodes_batch(
            df=nodes_df,
            time_col="timestamp",
            id_col="id",
            **node_prop_mapping,
        )

        # Build property mappings for edges
        edge_prop_mapping = {
            prop: prop
            for prop in edge_properties
            if prop in edges_df.columns
        }

        # Load edges
        loader.add_edges_batch(
            df=edges_df,
            time_col="timestamp",
            source_col="source",
            destination_col="destination",
            **edge_prop_mapping,
        )

        return {
            "nodes_loaded": len(nodes_df),
            "edges_loaded": len(edges_df),
        }

    def to_raphtory_graph(
        self,
        *,
        timestamp: int = 0,
        node_properties: list[str] | None = None,
    ) -> Any:
        """Create a standalone Raphtory Graph object (without facade).

        This method creates an in-memory Raphtory graph directly,
        without requiring a RaphtoryServiceFacade. Useful for quick
        analysis or when you don't need persistence.

        Args:
            timestamp: Timestamp to assign to all nodes and edges. Default: 0.
            node_properties: List of node property names to include.
                            Default: ["coordinate", "row", "column", "value"].

        Returns:
            A Raphtory Graph object that can be used for temporal analysis.

        Example:
            >>> graph = exporter.to_raphtory_graph()
            >>> print(f"Nodes: {graph.count_nodes()}")
            >>> print(f"Edges: {graph.count_edges()}")
        """
        from raphtory import Graph

        if node_properties is None:
            node_properties = ["coordinate", "row", "column", "value"]

        graph = Graph()

        # Add nodes
        for node in self.grid_graph.nodes:
            node_dict = node.to_dict()
            node_id = node.base_excel_cell.cell_workbook_value_hash

            # Filter properties
            properties = {
                k: v
                for k, v in node_dict.items()
                if k in node_properties and v is not None
            }

            graph.add_node(timestamp, node_id, properties)

        # Add edges
        for edge in self.grid_graph.edges:
            source_id = edge.source.base_excel_cell.cell_workbook_value_hash
            dest_id = edge.destination.base_excel_cell.cell_workbook_value_hash

            graph.add_edge(
                timestamp,
                source_id,
                dest_id,
                {"edge_type": edge.edge_type},
            )

        return graph
