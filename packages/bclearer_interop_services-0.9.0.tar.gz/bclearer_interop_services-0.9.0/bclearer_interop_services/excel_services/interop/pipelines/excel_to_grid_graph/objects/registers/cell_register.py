from typing import Dict, List

from bclearer_interop_services.excel_services.interop.objects.excel_cells import ExcelCells

class CellRegister:
    def __init__(
            self):
        self.cells: Dict[str, List[ExcelCells]] = \
            {}
        
    def register_cell(
            self,
            cell: ExcelCells) \
            -> None:
        self.cells[cell.cell_workbook_value_hash] = \
            self.cells.get(cell.cell_workbook_value_hash, [])
        self.cells[cell.cell_workbook_value_hash].append(cell)

    def get_cell(
            self,
            cell_workbook_value_hash: str) \
            -> ExcelCells | None:
        cells = self.cells.get(cell_workbook_value_hash, [])
        return cells[0] if cells else None
    
    def get_cells_by_property_value(
            self,
            property_name: str,
            property_value: str) \
            -> Dict[str, ExcelCells]:
        return {
            cell_hash: cell
            for cell_hash, cell in self.cells.items()
            if getattr(cell, property_name, None) == property_value}
    
    def update_cell(
            self,
            cell: ExcelCells) \
            -> None:
        if cell.cell_workbook_value_hash in self.cells:
            for idx, existing_cell in enumerate(self.cells[cell.cell_workbook_value_hash]):
                if existing_cell == cell:
                    self.cells[cell.cell_workbook_value_hash][idx] = cell
                    return
            self.cells[cell.cell_workbook_value_hash].append(cell)
    
    def set_with_dictionary(
            self,
            dictionary: Dict[str, List[ExcelCells]]) \
            -> None:
        for key, value in dictionary.items():
            self.cells[key] = \
                value

    def get_cells(
        self) \
        -> List[ExcelCells]:
        return [
            cell 
            for cell_list in self.cells.values() 
            for cell in cell_list
        ]

    def __str__(self) -> str:
        """
        Returns a formatted string representation of the cell register contents.
        """
        total_cell_hashes = len(self.cells)
        total_cells = sum(len(cell_list) for cell_list in self.cells.values())
        
        if total_cell_hashes == 0:
            return "Cell register: 0 unique hashes, 0 total cells"
        
        return f"Cell register: {total_cell_hashes} unique hashes, {total_cells} total cells"
