from typing import Dict
from enum import Enum
import pandas

#TODO: move out to filesystem service enums
class FILE_EXTENSION_TYPES(Enum):
    CSV = 'csv'
    XLSX = 'xlsx'

class PandasDataframeRegisters:
    def __init__(
            self,
            allowed_table_names: type[Enum]):
        self.tables: Dict[str, pandas.DataFrame] = \
            {}
        
        self.allowed_table_names = \
            allowed_table_names
        
    def table_name_allowed(
            self,
            table_name: Enum) \
            -> bool:
        return \
            table_name in self.allowed_table_names
        
    def register_table(
            self,
            table_name: Enum,
            table: pandas.DataFrame) \
            -> None:
        if not self.table_name_allowed(table_name):
            raise ValueError(
                f"Table name '{table_name}' is not in the list of allowed table names.")

        self.tables[table_name.value] = \
            table
        
    def get_table(
            self,
            table_name: Enum) \
            -> pandas.DataFrame | None:
        if not self.table_name_allowed(table_name):
            raise ValueError(
                f"Table name '{table_name}' is not in the list of allowed table names.")
        
        return \
            self.tables.get(
                table_name.value)

    def __str__(self) -> str:
        """
        Returns a formatted string representation of the table register contents.
        """
        table_count = len(self.tables)
        if table_count == 0:
            return "Tables: 0"
        
        lines = [f"Tables: {table_count}"]
        for table_name, table_df in self.tables.items():
            row_count = len(table_df)
            lines.append(f"  - {table_name}: {row_count} rows")
        
        return "\n".join(lines)

    def export_to(
            self,
            output_base_path: str,
            file_type: FILE_EXTENSION_TYPES)\
            -> None:
        for table_name, table in self.tables.items():
            if file_type == FILE_EXTENSION_TYPES.CSV:
                table.to_csv(
                    f"{output_base_path}/{table_name.value}.csv")
            elif file_type == FILE_EXTENSION_TYPES.XLSX:
                table.to_excel(
                    f"{output_base_path}/{table_name.value}.xlsx")