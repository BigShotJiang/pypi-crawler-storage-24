"""
File system service package.

This package provides file system operations including both synchronous
and asynchronous file handling capabilities.

For async file operations, install the 'async' optional dependency:
    pip install bclearer-interop-services[async]
"""

from bclearer_interop_services.file_system_service.file_content_as_string_reader import (
    read_file_content_as_string as read_file_content_as_string,
)

# Conditional async exports - only available if aiofiles is installed
try:
    from bclearer_interop_services.file_system_service.async_file_operations import (
        AIOFILES_AVAILABLE as AIOFILES_AVAILABLE,
        async_append_file_content as async_append_file_content,
        async_copy_file as async_copy_file,
        async_file_exists as async_file_exists,
        async_get_file_size as async_get_file_size,
        async_read_file_content_as_bytes as async_read_file_content_as_bytes,
        async_read_file_content_as_string as async_read_file_content_as_string,
        async_read_file_lines as async_read_file_lines,
        async_read_multiple_files as async_read_multiple_files,
        async_remove_file as async_remove_file,
        async_rename_file as async_rename_file,
        async_write_file_bytes as async_write_file_bytes,
        async_write_file_content as async_write_file_content,
    )

    ASYNC_SUPPORT = AIOFILES_AVAILABLE
except ImportError:
    ASYNC_SUPPORT = False

__all__ = [
    # Synchronous operations
    "read_file_content_as_string",
    # Async support flag
    "ASYNC_SUPPORT",
]

# Add async exports to __all__ if available
if ASYNC_SUPPORT:
    __all__.extend(
        [
            "AIOFILES_AVAILABLE",
            "async_read_file_content_as_string",
            "async_read_file_content_as_bytes",
            "async_write_file_content",
            "async_write_file_bytes",
            "async_append_file_content",
            "async_file_exists",
            "async_get_file_size",
            "async_read_file_lines",
            "async_read_multiple_files",
            "async_copy_file",
            "async_remove_file",
            "async_rename_file",
        ]
    )
