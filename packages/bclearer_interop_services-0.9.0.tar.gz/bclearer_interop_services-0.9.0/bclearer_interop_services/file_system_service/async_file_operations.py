"""
Async file operations module using aiofiles.

This module provides asynchronous alternatives to standard file I/O operations,
enabling non-blocking file operations for improved performance in async applications.

Requires the 'async' optional dependency:
    pip install bclearer-interop-services[async]

Example usage:
    import asyncio
    from bclearer_interop_services.file_system_service.async_file_operations import (
        async_read_file_content_as_string,
        async_write_file_content,
    )

    async def main():
        content = await async_read_file_content_as_string("/path/to/file.txt")
        await async_write_file_content("/path/to/output.txt", content)

    asyncio.run(main())
"""

from __future__ import annotations

import asyncio
from pathlib import Path
from typing import (
    Union,
)

try:
    import aiofiles
    import aiofiles.os

    AIOFILES_AVAILABLE = True
except ImportError:
    AIOFILES_AVAILABLE = False


def _check_aiofiles_available() -> None:
    """Check if aiofiles is available and raise ImportError if not."""
    if not AIOFILES_AVAILABLE:
        raise ImportError(
            "aiofiles is required for async file operations. "
            "Install it with: pip install bclearer-interop-services[async]"
        )


async def async_read_file_content_as_string(
    file_path: Union[str, Path],
    encoding: str = "utf-8",
) -> str:
    """
    Read file content asynchronously and return as string.

    Args:
        file_path: The path to the file to read.
        encoding: The encoding to use when reading the file. Defaults to 'utf-8'.

    Returns:
        The content of the file as a string.

    Raises:
        ImportError: If aiofiles is not installed.
        FileNotFoundError: If the file does not exist.
        IOError: If there is an error reading the file.
    """
    _check_aiofiles_available()

    async with aiofiles.open(
        file_path,
        mode="r",
        encoding=encoding,
    ) as current_file:
        file_content_as_string = await current_file.read()

    return file_content_as_string


async def async_read_file_content_as_bytes(
    file_path: Union[str, Path],
) -> bytes:
    """
    Read file content asynchronously and return as bytes.

    Args:
        file_path: The path to the file to read.

    Returns:
        The content of the file as bytes.

    Raises:
        ImportError: If aiofiles is not installed.
        FileNotFoundError: If the file does not exist.
        IOError: If there is an error reading the file.
    """
    _check_aiofiles_available()

    async with aiofiles.open(
        file_path,
        mode="rb",
    ) as current_file:
        file_content_as_bytes = await current_file.read()

    return file_content_as_bytes


async def async_write_file_content(
    file_path: Union[str, Path],
    content: str,
    encoding: str = "utf-8",
) -> None:
    """
    Write string content to a file asynchronously.

    Args:
        file_path: The path to the file to write.
        content: The string content to write.
        encoding: The encoding to use when writing the file. Defaults to 'utf-8'.

    Raises:
        ImportError: If aiofiles is not installed.
        IOError: If there is an error writing to the file.
    """
    _check_aiofiles_available()

    async with aiofiles.open(
        file_path,
        mode="w",
        encoding=encoding,
    ) as current_file:
        await current_file.write(content)


async def async_write_file_bytes(
    file_path: Union[str, Path],
    content: bytes,
) -> None:
    """
    Write bytes content to a file asynchronously.

    Args:
        file_path: The path to the file to write.
        content: The bytes content to write.

    Raises:
        ImportError: If aiofiles is not installed.
        IOError: If there is an error writing to the file.
    """
    _check_aiofiles_available()

    async with aiofiles.open(
        file_path,
        mode="wb",
    ) as current_file:
        await current_file.write(content)


async def async_append_file_content(
    file_path: Union[str, Path],
    content: str,
    encoding: str = "utf-8",
) -> None:
    """
    Append string content to a file asynchronously.

    Args:
        file_path: The path to the file to append to.
        content: The string content to append.
        encoding: The encoding to use when writing the file. Defaults to 'utf-8'.

    Raises:
        ImportError: If aiofiles is not installed.
        IOError: If there is an error writing to the file.
    """
    _check_aiofiles_available()

    async with aiofiles.open(
        file_path,
        mode="a",
        encoding=encoding,
    ) as current_file:
        await current_file.write(content)


async def async_file_exists(
    file_path: Union[str, Path],
) -> bool:
    """
    Check if a file exists asynchronously.

    Args:
        file_path: The path to check.

    Returns:
        True if the file exists, False otherwise.

    Raises:
        ImportError: If aiofiles is not installed.
    """
    _check_aiofiles_available()

    return await aiofiles.os.path.exists(file_path)


async def async_get_file_size(
    file_path: Union[str, Path],
) -> int:
    """
    Get the size of a file in bytes asynchronously.

    Args:
        file_path: The path to the file.

    Returns:
        The size of the file in bytes.

    Raises:
        ImportError: If aiofiles is not installed.
        FileNotFoundError: If the file does not exist.
    """
    _check_aiofiles_available()

    stat_result = await aiofiles.os.stat(file_path)
    return stat_result.st_size


async def async_read_file_lines(
    file_path: Union[str, Path],
    encoding: str = "utf-8",
) -> list[str]:
    """
    Read file content asynchronously and return as a list of lines.

    Args:
        file_path: The path to the file to read.
        encoding: The encoding to use when reading the file. Defaults to 'utf-8'.

    Returns:
        A list of lines from the file.

    Raises:
        ImportError: If aiofiles is not installed.
        FileNotFoundError: If the file does not exist.
        IOError: If there is an error reading the file.
    """
    _check_aiofiles_available()

    async with aiofiles.open(
        file_path,
        mode="r",
        encoding=encoding,
    ) as current_file:
        lines = await current_file.readlines()

    return lines


async def async_read_multiple_files(
    file_paths: list[Union[str, Path]],
    encoding: str = "utf-8",
) -> dict[str, str]:
    """
    Read multiple files concurrently and return their contents.

    Args:
        file_paths: A list of file paths to read.
        encoding: The encoding to use when reading the files. Defaults to 'utf-8'.

    Returns:
        A dictionary mapping file paths (as strings) to their contents.

    Raises:
        ImportError: If aiofiles is not installed.
        FileNotFoundError: If any file does not exist.
        IOError: If there is an error reading any file.
    """
    _check_aiofiles_available()

    async def read_single_file(path: Union[str, Path]) -> tuple[str, str]:
        content = await async_read_file_content_as_string(
            file_path=path,
            encoding=encoding,
        )
        return (str(path), content)

    results = await asyncio.gather(
        *[read_single_file(path) for path in file_paths]
    )

    return dict(results)


async def async_copy_file(
    source_path: Union[str, Path],
    destination_path: Union[str, Path],
    chunk_size: int = 64 * 1024,
) -> None:
    """
    Copy a file asynchronously using chunked reading/writing.

    This is more memory-efficient for large files compared to reading
    the entire file into memory.

    Args:
        source_path: The path to the source file.
        destination_path: The path to the destination file.
        chunk_size: The size of chunks to read/write. Defaults to 64KB.

    Raises:
        ImportError: If aiofiles is not installed.
        FileNotFoundError: If the source file does not exist.
        IOError: If there is an error during copying.
    """
    _check_aiofiles_available()

    async with aiofiles.open(source_path, mode="rb") as source_file:
        async with aiofiles.open(destination_path, mode="wb") as dest_file:
            while True:
                chunk = await source_file.read(chunk_size)
                if not chunk:
                    break
                await dest_file.write(chunk)


async def async_remove_file(
    file_path: Union[str, Path],
) -> None:
    """
    Remove a file asynchronously.

    Args:
        file_path: The path to the file to remove.

    Raises:
        ImportError: If aiofiles is not installed.
        FileNotFoundError: If the file does not exist.
        IOError: If there is an error removing the file.
    """
    _check_aiofiles_available()

    await aiofiles.os.remove(file_path)


async def async_rename_file(
    source_path: Union[str, Path],
    destination_path: Union[str, Path],
) -> None:
    """
    Rename/move a file asynchronously.

    Args:
        source_path: The current path of the file.
        destination_path: The new path for the file.

    Raises:
        ImportError: If aiofiles is not installed.
        FileNotFoundError: If the source file does not exist.
        IOError: If there is an error renaming the file.
    """
    _check_aiofiles_available()

    await aiofiles.os.rename(source_path, destination_path)
