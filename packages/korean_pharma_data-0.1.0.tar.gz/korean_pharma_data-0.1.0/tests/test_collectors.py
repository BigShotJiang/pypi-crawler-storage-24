"""Tests for data collectors (using fixture XML, no real API calls)."""

from __future__ import annotations

from unittest.mock import AsyncMock, patch

import pytest

from korean_pharma_data.client import MFDSClient
from korean_pharma_data.collectors.drug_info import DrugInfoCollector
from korean_pharma_data.collectors.dur import DURCollector
from korean_pharma_data.collectors.supplement import SupplementCollector


@pytest.fixture
def mock_client():
    """Create a mock MFDSClient."""
    client = AsyncMock(spec=MFDSClient)
    client.api_key = "test_key"
    return client


class TestDrugInfoCollector:
    @pytest.mark.asyncio
    async def test_collect_drugs(self, mock_client, drug_info_xml):
        mock_client.request_all_pages = AsyncMock(return_value=[drug_info_xml])

        collector = DrugInfoCollector(mock_client)
        drugs, result = await collector.collect()

        assert result.source == "drug_info"
        assert result.collected_count == 2
        assert result.error_count == 0
        assert len(drugs) == 2
        assert drugs[0].item_name == "타이레놀정500밀리그램"

    @pytest.mark.asyncio
    async def test_collect_with_filters(self, mock_client, drug_info_xml):
        mock_client.request_all_pages = AsyncMock(return_value=[drug_info_xml])

        collector = DrugInfoCollector(mock_client)
        await collector.collect(item_name="타이레놀", entp_name="한국존슨")

        call_args = mock_client.request_all_pages.call_args
        params = call_args.kwargs.get("params") or call_args[1].get("params", {})
        assert params.get("itemName") == "타이레놀"
        assert params.get("entpName") == "한국존슨"

    @pytest.mark.asyncio
    async def test_search(self, mock_client, drug_info_xml):
        mock_client.request_all_pages = AsyncMock(return_value=[drug_info_xml])

        collector = DrugInfoCollector(mock_client)
        drugs = await collector.search("타이레놀", max_results=5)

        assert len(drugs) == 2  # fixture has 2 items


class TestDURCollector:
    @pytest.mark.asyncio
    async def test_collect_all_types(self, mock_client, dur_xml):
        mock_client.request_all_pages = AsyncMock(return_value=[dur_xml])

        collector = DURCollector(mock_client)
        interactions, result = await collector.collect()

        assert result.source == "dur"
        # 4 DUR types x 2 items per fixture = 8
        assert result.collected_count == 8
        assert result.error_count == 0

    @pytest.mark.asyncio
    async def test_collect_single_type(self, mock_client, dur_xml):
        mock_client.request_all_pages = AsyncMock(return_value=[dur_xml])

        collector = DURCollector(mock_client)
        interactions, result = await collector.collect(dur_type="병용금기")

        assert result.collected_count == 2
        assert all(i.type == "병용금기" for i in interactions)

    @pytest.mark.asyncio
    async def test_collect_invalid_type_raises(self, mock_client):
        collector = DURCollector(mock_client)

        with pytest.raises(ValueError, match="Unknown DUR type"):
            await collector.collect(dur_type="없는유형")

    @pytest.mark.asyncio
    async def test_collect_contraindicated(self, mock_client, dur_xml):
        mock_client.request_all_pages = AsyncMock(return_value=[dur_xml])

        collector = DURCollector(mock_client)
        interactions, result = await collector.collect_contraindicated_combinations()

        assert result.collected_count == 2
        assert all(i.type == "병용금기" for i in interactions)


class TestSupplementCollector:
    @pytest.mark.asyncio
    async def test_collect_supplements(self, mock_client, supplement_xml):
        mock_client.request_all_pages = AsyncMock(return_value=[supplement_xml])

        collector = SupplementCollector(mock_client)
        supplements, result = await collector.collect()

        assert result.source == "supplement"
        assert result.collected_count == 2
        assert supplements[0].product_name == "비타민D 1000IU"
        assert supplements[1].product_name == "오메가3 EPA/DHA"

    @pytest.mark.asyncio
    async def test_supplement_ingredients_parsed(self, mock_client, supplement_xml):
        mock_client.request_all_pages = AsyncMock(return_value=[supplement_xml])

        collector = SupplementCollector(mock_client)
        supplements, _ = await collector.collect()

        vitamin_d = supplements[0]
        assert len(vitamin_d.ingredients) == 3
        assert vitamin_d.ingredients[0].name == "비타민D3"

    @pytest.mark.asyncio
    async def test_supplement_functionality(self, mock_client, supplement_xml):
        mock_client.request_all_pages = AsyncMock(return_value=[supplement_xml])

        collector = SupplementCollector(mock_client)
        supplements, _ = await collector.collect()

        assert "뼈" in supplements[0].functionality
        assert "중성지질" in supplements[1].functionality
