"""Tests for CLI commands."""

from __future__ import annotations

import json
from pathlib import Path
from unittest.mock import AsyncMock, patch

import pytest
from click.testing import CliRunner

from korean_pharma_data.cli import main


@pytest.fixture
def runner():
    return CliRunner()


class TestCLIVersion:
    def test_version(self, runner):
        result = runner.invoke(main, ["--version"])
        assert result.exit_code == 0
        assert "0.1.0" in result.output


class TestCLICollect:
    def test_collect_drugs_help(self, runner):
        result = runner.invoke(main, ["collect", "drugs", "--help"])
        assert result.exit_code == 0
        assert "api-key" in result.output

    def test_collect_dur_help(self, runner):
        result = runner.invoke(main, ["collect", "dur", "--help"])
        assert result.exit_code == 0
        assert "api-key" in result.output

    def test_collect_supplements_help(self, runner):
        result = runner.invoke(main, ["collect", "supplements", "--help"])
        assert result.exit_code == 0


class TestCLIExport:
    def test_export_json_to_csv(self, runner, sample_drugs, tmp_path):
        # First create a JSON file
        input_file = tmp_path / "drugs.json"
        data = [d.model_dump() for d in sample_drugs]
        input_file.write_text(json.dumps(data, ensure_ascii=False), encoding="utf-8")

        output_file = tmp_path / "drugs.csv"
        result = runner.invoke(
            main, ["export", str(input_file), "--format", "csv", "-o", str(output_file)]
        )
        assert result.exit_code == 0
        assert "Exported 2 records" in result.output
        assert output_file.exists()

    def test_export_json_to_sqlite(self, runner, sample_drugs, tmp_path):
        input_file = tmp_path / "drugs.json"
        data = [d.model_dump() for d in sample_drugs]
        input_file.write_text(json.dumps(data, ensure_ascii=False), encoding="utf-8")

        output_file = tmp_path / "drugs.db"
        result = runner.invoke(
            main,
            ["export", str(input_file), "--format", "sqlite", "-o", str(output_file)],
        )
        assert result.exit_code == 0
        assert output_file.exists()

    def test_export_empty_file(self, runner, tmp_path):
        input_file = tmp_path / "empty.json"
        input_file.write_text("[]", encoding="utf-8")

        result = runner.invoke(
            main,
            ["export", str(input_file), "--format", "json", "-o", str(tmp_path / "out.json")],
        )
        assert result.exit_code != 0
        assert "No data" in result.output


class TestCLISearch:
    def test_search_in_sqlite(self, runner, sample_drugs, tmp_path):
        from korean_pharma_data.exporters import export_sqlite

        db_path = tmp_path / "drugs.db"
        export_sqlite(sample_drugs, db_path, table_name="data", enable_fts=True)

        result = runner.invoke(main, ["search", "타이레놀", "--db", str(db_path)])
        assert result.exit_code == 0
        assert "타이레놀" in result.output
