"""Tests for Pydantic data models."""

from __future__ import annotations

import pytest
from pydantic import ValidationError

from korean_pharma_data.models import (
    CollectionResult,
    Drug,
    DURInteraction,
    Ingredient,
    Supplement,
    SupplementIngredient,
)


class TestIngredient:
    def test_create_minimal(self):
        ing = Ingredient(name="아세트아미노펜")
        assert ing.name == "아세트아미노펜"
        assert ing.code == ""
        assert ing.amount == ""

    def test_create_full(self):
        ing = Ingredient(
            code="M040702",
            name="아세트아미노펜",
            name_en="Acetaminophen",
            amount="500",
            unit="mg",
        )
        assert ing.code == "M040702"
        assert ing.name_en == "Acetaminophen"

    def test_missing_name_raises(self):
        with pytest.raises(ValidationError):
            Ingredient()


class TestDrug:
    def test_create_minimal(self):
        drug = Drug(item_seq="200003671", item_name="타이레놀정500밀리그램")
        assert drug.item_seq == "200003671"
        assert drug.ingredients == []
        assert drug.efcy_qesitm is None

    def test_create_with_ingredients(self):
        drug = Drug(
            item_seq="200003671",
            item_name="타이레놀정500밀리그램",
            ingredients=[
                Ingredient(name="아세트아미노펜", amount="500", unit="mg")
            ],
        )
        assert len(drug.ingredients) == 1
        assert drug.ingredients[0].name == "아세트아미노펜"

    def test_missing_item_seq_raises(self):
        with pytest.raises(ValidationError):
            Drug(item_name="타이레놀정500밀리그램")

    def test_serialization_roundtrip(self):
        drug = Drug(
            item_seq="200003671",
            item_name="타이레놀정500밀리그램",
            entp_name="한국존슨앤드존슨판매(유)",
            efcy_qesitm="해열, 진통",
        )
        data = drug.model_dump()
        drug2 = Drug(**data)
        assert drug == drug2


class TestDURInteraction:
    def test_create_minimal(self):
        dur = DURInteraction(
            item_seq_a="200003671",
            item_name_a="타이레놀정500밀리그램",
            type="병용금기",
        )
        assert dur.item_seq_b == ""
        assert dur.prohibition_content == ""

    def test_create_full(self):
        dur = DURInteraction(
            item_seq_a="200003671",
            item_name_a="타이레놀정500밀리그램",
            item_seq_b="200401642",
            item_name_b="와파린나트륨정",
            ingredient_name_a="아세트아미노펜",
            ingredient_name_b="와파린나트륨",
            type="병용금기",
            prohibition_content="출혈 위험 증가",
            remark="모니터링 필요",
        )
        assert dur.type == "병용금기"
        assert "출혈" in dur.prohibition_content


class TestSupplement:
    def test_create_minimal(self):
        sup = Supplement(product_name="비타민D 1000IU")
        assert sup.company == ""
        assert sup.ingredients == []

    def test_create_with_ingredients(self):
        sup = Supplement(
            product_name="비타민D 1000IU",
            company="한국건강식품(주)",
            ingredients=[
                SupplementIngredient(name="비타민D3", amount="1000", unit="IU"),
            ],
            functionality="뼈의 형성과 유지에 필요",
        )
        assert len(sup.ingredients) == 1
        assert sup.functionality == "뼈의 형성과 유지에 필요"


class TestCollectionResult:
    def test_create(self):
        result = CollectionResult(
            source="drug_info",
            total_count=100,
            collected_count=98,
            error_count=2,
            errors=["err1", "err2"],
        )
        assert result.source == "drug_info"
        assert result.error_count == 2
