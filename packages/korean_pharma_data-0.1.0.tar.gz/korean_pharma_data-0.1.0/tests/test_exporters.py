"""Tests for data exporters."""

from __future__ import annotations

import csv
import json
import sqlite3
from pathlib import Path

import pytest

from korean_pharma_data.exporters import export_csv, export_json, export_sqlite


class TestJSONExporter:
    def test_export_drugs(self, sample_drugs, tmp_output):
        output = tmp_output / "drugs.json"
        result = export_json(sample_drugs, output)
        assert result == output
        assert output.exists()

        data = json.loads(output.read_text(encoding="utf-8"))
        assert len(data) == 2
        assert data[0]["item_seq"] == "200003671"
        assert data[0]["item_name"] == "타이레놀정500밀리그램"

    def test_export_korean_encoding(self, sample_drugs, tmp_output):
        output = tmp_output / "drugs.json"
        export_json(sample_drugs, output)
        content = output.read_text(encoding="utf-8")
        # Should contain actual Korean characters, not escaped Unicode
        assert "타이레놀" in content
        assert "\\u" not in content.split('"item_name"')[1].split(",")[0]

    def test_export_empty_list(self, tmp_output):
        output = tmp_output / "empty.json"
        export_json([], output)
        data = json.loads(output.read_text(encoding="utf-8"))
        assert data == []

    def test_export_supplements(self, sample_supplements, tmp_output):
        output = tmp_output / "supplements.json"
        export_json(sample_supplements, output)
        data = json.loads(output.read_text(encoding="utf-8"))
        assert len(data) == 1
        assert data[0]["product_name"] == "비타민D 1000IU"


class TestCSVExporter:
    def test_export_drugs(self, sample_drugs, tmp_output):
        output = tmp_output / "drugs.csv"
        result = export_csv(sample_drugs, output)
        assert result == output
        assert output.exists()

        with open(output, encoding="utf-8-sig") as f:
            reader = csv.DictReader(f)
            rows = list(reader)
        assert len(rows) == 2
        assert rows[0]["item_seq"] == "200003671"

    def test_export_nested_as_json(self, sample_drugs, tmp_output):
        output = tmp_output / "drugs.csv"
        export_csv(sample_drugs, output)

        with open(output, encoding="utf-8-sig") as f:
            reader = csv.DictReader(f)
            row = next(reader)

        # Ingredients should be serialized as JSON string
        ingredients = json.loads(row["ingredients"])
        assert isinstance(ingredients, list)
        assert ingredients[0]["name"] == "아세트아미노펜"

    def test_export_empty(self, tmp_output):
        output = tmp_output / "empty.csv"
        export_csv([], output)
        assert output.exists()
        assert output.read_text(encoding="utf-8") == ""


class TestSQLiteExporter:
    def test_export_drugs(self, sample_drugs, tmp_output):
        output = tmp_output / "drugs.db"
        result = export_sqlite(sample_drugs, output, table_name="drugs")
        assert result == output
        assert output.exists()

        conn = sqlite3.connect(str(output))
        cursor = conn.execute("SELECT COUNT(*) FROM drugs")
        assert cursor.fetchone()[0] == 2
        conn.close()

    def test_fts_search(self, sample_drugs, tmp_output):
        output = tmp_output / "drugs.db"
        export_sqlite(sample_drugs, output, table_name="drugs", enable_fts=True)

        conn = sqlite3.connect(str(output))
        # Use prefix matching (타이레놀*) since FTS5 unicode61 tokenizer
        # treats Korean compound words as single tokens
        cursor = conn.execute(
            "SELECT * FROM drugs WHERE rowid IN "
            "(SELECT rowid FROM drugs_fts WHERE drugs_fts MATCH '타이레놀*')"
        )
        rows = cursor.fetchall()
        assert len(rows) == 1
        conn.close()

    def test_export_without_fts(self, sample_drugs, tmp_output):
        output = tmp_output / "drugs.db"
        export_sqlite(sample_drugs, output, table_name="drugs", enable_fts=False)

        conn = sqlite3.connect(str(output))
        # FTS table should not exist
        cursor = conn.execute(
            "SELECT name FROM sqlite_master WHERE type='table' AND name='drugs_fts'"
        )
        assert cursor.fetchone() is None
        conn.close()

    def test_export_dur_interactions(self, sample_dur_interactions, tmp_output):
        output = tmp_output / "dur.db"
        export_sqlite(sample_dur_interactions, output, table_name="dur")

        conn = sqlite3.connect(str(output))
        cursor = conn.execute("SELECT COUNT(*) FROM dur")
        assert cursor.fetchone()[0] == 1
        conn.close()

    def test_export_empty(self, tmp_output):
        output = tmp_output / "empty.db"
        result = export_sqlite([], output, table_name="data")
        assert result == output
