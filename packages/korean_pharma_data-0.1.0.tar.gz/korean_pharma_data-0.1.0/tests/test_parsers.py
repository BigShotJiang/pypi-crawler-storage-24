"""Tests for XML and data parsers."""

from __future__ import annotations

import pytest

from korean_pharma_data.parsers.xml_parser import parse_xml_items, parse_xml_response
from korean_pharma_data.parsers.drug_parser import parse_drugs_from_xml
from korean_pharma_data.parsers.dur_parser import parse_dur_from_xml


class TestXMLParser:
    """Tests for the generic XML parser."""

    def test_parse_xml_response_metadata(self, drug_info_xml: str):
        meta, items = parse_xml_response(drug_info_xml)
        assert meta.result_code == "00"
        assert meta.result_msg == "NORMAL SERVICE."
        assert meta.total_count == 2
        assert meta.page_no == 1
        assert meta.num_of_rows == 10

    def test_parse_xml_items_count(self, drug_info_xml: str):
        items = parse_xml_items(drug_info_xml)
        assert len(items) == 2

    def test_parse_xml_items_fields(self, drug_info_xml: str):
        items = parse_xml_items(drug_info_xml)
        assert items[0]["ITEM_SEQ"] == "200003671"
        assert items[0]["ITEM_NAME"] == "타이레놀정500밀리그램"
        assert items[0]["ENTP_NAME"] == "한국존슨앤드존슨판매(유)"

    def test_parse_xml_invalid_raises(self):
        with pytest.raises(ValueError, match="Invalid XML"):
            parse_xml_response("<invalid>xml<<<<")

    def test_parse_xml_error_response(self):
        error_xml = """<?xml version="1.0" encoding="UTF-8"?>
        <response>
            <header>
                <resultCode>99</resultCode>
                <resultMsg>SERVICE ERROR.</resultMsg>
            </header>
            <body><items></items></body>
        </response>"""
        with pytest.raises(ValueError, match="API error"):
            parse_xml_response(error_xml)

    def test_parse_xml_empty_items(self):
        empty_xml = """<?xml version="1.0" encoding="UTF-8"?>
        <response>
            <header>
                <resultCode>00</resultCode>
                <resultMsg>NORMAL SERVICE.</resultMsg>
            </header>
            <body>
                <totalCount>0</totalCount>
                <items></items>
            </body>
        </response>"""
        meta, items = parse_xml_response(empty_xml)
        assert meta.total_count == 0
        assert items == []


class TestDrugParser:
    """Tests for drug-specific parsing."""

    def test_parse_drugs_count(self, drug_info_xml: str):
        drugs = parse_drugs_from_xml(drug_info_xml)
        assert len(drugs) == 2

    def test_parse_drug_fields(self, drug_info_xml: str):
        drugs = parse_drugs_from_xml(drug_info_xml)
        tylenol = drugs[0]
        assert tylenol.item_seq == "200003671"
        assert tylenol.item_name == "타이레놀정500밀리그램"
        assert tylenol.entp_name == "한국존슨앤드존슨판매(유)"
        assert tylenol.chart == "흰색의 장방형 필름코팅정"
        assert tylenol.class_name == "해열.진통.소염제"
        assert tylenol.etc_otc_name == "일반의약품"

    def test_parse_drug_ingredients(self, drug_info_xml: str):
        drugs = parse_drugs_from_xml(drug_info_xml)
        tylenol = drugs[0]
        assert len(tylenol.ingredients) == 1
        assert tylenol.ingredients[0].name == "아세트아미노펜"
        assert tylenol.ingredients[0].amount == "500"
        assert tylenol.ingredients[0].unit == "밀리그램"

    def test_parse_drug_text_fields(self, drug_info_xml: str):
        drugs = parse_drugs_from_xml(drug_info_xml)
        tylenol = drugs[0]
        assert "발열" in tylenol.efcy_qesitm
        assert "간손상" in tylenol.atpn_qesitm
        assert tylenol.deposit_method_qesitm is not None

    def test_parse_drug_empty_image(self, drug_info_xml: str):
        drugs = parse_drugs_from_xml(drug_info_xml)
        ibuprofen = drugs[1]
        assert ibuprofen.item_image is None


class TestDURParser:
    """Tests for DUR interaction parsing."""

    def test_parse_dur_count(self, dur_xml: str):
        interactions = parse_dur_from_xml(dur_xml, "병용금기")
        assert len(interactions) == 2

    def test_parse_dur_fields(self, dur_xml: str):
        interactions = parse_dur_from_xml(dur_xml, "병용금기")
        first = interactions[0]
        assert first.item_seq_a == "200003671"
        assert first.item_name_a == "타이레놀정500밀리그램"
        assert first.item_seq_b == "200401642"
        assert first.item_name_b == "와파린나트륨정"
        assert first.type == "병용금기"
        assert "출혈" in first.prohibition_content

    def test_parse_dur_ingredient_names(self, dur_xml: str):
        interactions = parse_dur_from_xml(dur_xml, "병용금기")
        first = interactions[0]
        assert first.ingredient_name_a == "아세트아미노펜"
        assert first.ingredient_name_b == "와파린나트륨"

    def test_parse_dur_custom_type(self, dur_xml: str):
        interactions = parse_dur_from_xml(dur_xml, "연령금기")
        assert all(i.type == "연령금기" for i in interactions)
