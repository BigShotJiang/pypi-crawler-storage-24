"""Pytest configuration and shared fixtures."""

from __future__ import annotations

from pathlib import Path

import pytest

FIXTURES_DIR = Path(__file__).parent / "fixtures"


@pytest.fixture
def drug_info_xml() -> str:
    """Load the drug info fixture XML."""
    return (FIXTURES_DIR / "drug_info_response.xml").read_text(encoding="utf-8")


@pytest.fixture
def dur_xml() -> str:
    """Load the DUR fixture XML."""
    return (FIXTURES_DIR / "dur_response.xml").read_text(encoding="utf-8")


@pytest.fixture
def supplement_xml() -> str:
    """Load the supplement fixture XML."""
    return (FIXTURES_DIR / "supplement_response.xml").read_text(encoding="utf-8")


@pytest.fixture
def sample_drugs():
    """Create sample Drug models for testing."""
    from korean_pharma_data.models import Drug, Ingredient

    return [
        Drug(
            item_seq="200003671",
            item_name="타이레놀정500밀리그램",
            entp_name="한국존슨앤드존슨판매(유)",
            chart="흰색의 장방형 필름코팅정",
            ingredients=[Ingredient(name="아세트아미노펜", amount="500", unit="밀리그램")],
            efcy_qesitm="감기로 인한 발열 및 동통(통증), 두통, 신경통",
        ),
        Drug(
            item_seq="200808876",
            item_name="이부프로펜정200밀리그램",
            entp_name="대웅제약(주)",
            chart="흰색의 원형 정제",
            ingredients=[Ingredient(name="이부프로펜", amount="200", unit="밀리그램")],
            efcy_qesitm="두통, 치통, 생리통, 관절통",
        ),
    ]


@pytest.fixture
def sample_dur_interactions():
    """Create sample DURInteraction models for testing."""
    from korean_pharma_data.models import DURInteraction

    return [
        DURInteraction(
            item_seq_a="200003671",
            item_name_a="타이레놀정500밀리그램",
            item_seq_b="200401642",
            item_name_b="와파린나트륨정",
            ingredient_name_a="아세트아미노펜",
            ingredient_name_b="와파린나트륨",
            type="병용금기",
            prohibition_content="출혈 위험 증가",
        ),
    ]


@pytest.fixture
def sample_supplements():
    """Create sample Supplement models for testing."""
    from korean_pharma_data.models import Supplement, SupplementIngredient

    return [
        Supplement(
            product_name="비타민D 1000IU",
            company="한국건강식품(주)",
            ingredients=[
                SupplementIngredient(name="비타민D3"),
                SupplementIngredient(name="유당"),
            ],
            functionality="뼈의 형성과 유지에 필요",
        ),
    ]


@pytest.fixture
def tmp_output(tmp_path):
    """Provide a temporary output directory."""
    return tmp_path
