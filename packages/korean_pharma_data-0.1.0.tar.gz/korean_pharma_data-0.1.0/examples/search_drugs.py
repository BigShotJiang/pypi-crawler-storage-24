"""Example: search for drugs and check DUR interactions."""

import asyncio
import os

from korean_pharma_data.client import MFDSClient
from korean_pharma_data.collectors.drug_info import DrugInfoCollector
from korean_pharma_data.collectors.dur import DURCollector


async def main():
    api_key = os.environ["MFDS_API_KEY"]

    async with MFDSClient(api_key=api_key) as client:
        drug_collector = DrugInfoCollector(client)
        dur_collector = DURCollector(client)

        # Search for a drug
        drugs = await drug_collector.search("이부프로펜", max_results=5)
        if not drugs:
            print("No drugs found")
            return

        drug = drugs[0]
        print(f"Drug: {drug.item_name}")
        print(f"Company: {drug.entp_name}")
        print(f"Efficacy: {drug.efcy_qesitm}")
        print()

        # Check DUR interactions for this drug
        interactions, result = await dur_collector.collect(
            dur_type="병용금기",
            item_seq=drug.item_seq,
            max_pages=1,
        )

        if interactions:
            print(f"Found {len(interactions)} contraindicated combinations:")
            for inter in interactions[:10]:
                print(f"  - {inter.item_name_a} + {inter.item_name_b}")
                print(f"    {inter.prohibition_content}")
                print()
        else:
            print("No contraindicated combinations found.")


if __name__ == "__main__":
    asyncio.run(main())
