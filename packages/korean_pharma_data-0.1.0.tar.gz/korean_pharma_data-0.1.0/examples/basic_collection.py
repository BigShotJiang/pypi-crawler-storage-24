"""Basic example: collect drug data from MFDS API."""

import asyncio
import os

from korean_pharma_data.client import MFDSClient
from korean_pharma_data.collectors.drug_info import DrugInfoCollector
from korean_pharma_data.exporters import export_json


async def main():
    api_key = os.environ["MFDS_API_KEY"]

    async with MFDSClient(api_key=api_key) as client:
        collector = DrugInfoCollector(client)

        # Search for a specific drug
        drugs = await collector.search("타이레놀", max_results=10)
        print(f"Found {len(drugs)} results for '타이레놀'")

        for drug in drugs:
            print(f"  - {drug.item_name} ({drug.entp_name})")
            if drug.ingredients:
                ingredients = ", ".join(i.name for i in drug.ingredients)
                print(f"    성분: {ingredients}")

        # Export results
        if drugs:
            export_json(drugs, "tylenol_results.json")
            print("Exported to tylenol_results.json")


if __name__ == "__main__":
    asyncio.run(main())
