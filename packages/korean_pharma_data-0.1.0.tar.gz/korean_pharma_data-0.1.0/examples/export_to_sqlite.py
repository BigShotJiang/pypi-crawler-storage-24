"""Example: collect drugs and export to SQLite with full-text search."""

import asyncio
import os
import sqlite3

from korean_pharma_data.client import MFDSClient
from korean_pharma_data.collectors.drug_info import DrugInfoCollector
from korean_pharma_data.exporters import export_sqlite


async def main():
    api_key = os.environ["MFDS_API_KEY"]

    # Collect first 5 pages of drug data
    async with MFDSClient(api_key=api_key) as client:
        collector = DrugInfoCollector(client)
        drugs, result = await collector.collect(max_pages=5)
        print(f"Collected {result.collected_count} drugs")

    # Export to SQLite with FTS5 search index
    db_path = export_sqlite(
        drugs,
        "pharma.db",
        table_name="drugs",
        enable_fts=True,
        fts_columns=["item_name", "entp_name", "efcy_qesitm"],
    )
    print(f"Exported to {db_path}")

    # Demo: search using FTS5
    conn = sqlite3.connect(str(db_path))
    conn.row_factory = sqlite3.Row

    query = "두통"
    cursor = conn.execute(
        "SELECT item_name, entp_name FROM drugs WHERE rowid IN "
        "(SELECT rowid FROM drugs_fts WHERE drugs_fts MATCH ?) LIMIT 5",
        (query,),
    )

    print(f"\nSearch results for '{query}':")
    for row in cursor:
        print(f"  - {row['item_name']} ({row['entp_name']})")

    conn.close()


if __name__ == "__main__":
    asyncio.run(main())
