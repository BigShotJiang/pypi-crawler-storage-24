"""Export collected data to JSON, CSV, SQLite, and Parquet formats."""

from __future__ import annotations

import csv
import json
import sqlite3
from pathlib import Path
from typing import Any, Sequence

from pydantic import BaseModel


def export_json(
    data: Sequence[BaseModel],
    output_path: str | Path,
    indent: int = 2,
) -> Path:
    """Export Pydantic models to a JSON file with Korean encoding.

    Args:
        data: Sequence of Pydantic model instances.
        output_path: Output file path.
        indent: JSON indentation level.

    Returns:
        Path to the written file.
    """
    output_path = Path(output_path)
    records = [item.model_dump() for item in data]
    output_path.write_text(
        json.dumps(records, ensure_ascii=False, indent=indent),
        encoding="utf-8",
    )
    return output_path


def export_csv(
    data: Sequence[BaseModel],
    output_path: str | Path,
) -> Path:
    """Export Pydantic models to a CSV file.

    Nested fields (lists, dicts) are serialized as JSON strings.

    Args:
        data: Sequence of Pydantic model instances.
        output_path: Output file path.

    Returns:
        Path to the written file.
    """
    output_path = Path(output_path)
    if not data:
        output_path.write_text("", encoding="utf-8")
        return output_path

    records = [item.model_dump() for item in data]
    fieldnames = list(records[0].keys())

    with open(output_path, "w", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for record in records:
            row = {}
            for key, value in record.items():
                if isinstance(value, (list, dict)):
                    row[key] = json.dumps(value, ensure_ascii=False)
                else:
                    row[key] = value
            writer.writerow(row)

    return output_path


def export_sqlite(
    data: Sequence[BaseModel],
    output_path: str | Path,
    table_name: str = "data",
    enable_fts: bool = True,
    fts_columns: list[str] | None = None,
) -> Path:
    """Export Pydantic models to a SQLite database.

    Args:
        data: Sequence of Pydantic model instances.
        output_path: Output database file path.
        table_name: Name of the table to create.
        enable_fts: Whether to create FTS5 full-text search index.
        fts_columns: Columns to include in FTS index.
            Defaults to text-like columns if not specified.

    Returns:
        Path to the written database file.
    """
    output_path = Path(output_path)
    if not data:
        return output_path

    records = [item.model_dump() for item in data]
    columns = list(records[0].keys())

    conn = sqlite3.connect(str(output_path))
    try:
        _create_table(conn, table_name, columns, records[0])
        _insert_rows(conn, table_name, columns, records)

        if enable_fts:
            _create_fts_index(conn, table_name, columns, fts_columns, records[0])

        conn.commit()
    finally:
        conn.close()

    return output_path


def _create_table(
    conn: sqlite3.Connection,
    table_name: str,
    columns: list[str],
    sample: dict[str, Any],
) -> None:
    """Create a SQLite table based on data structure."""
    col_defs = []
    for col in columns:
        val = sample[col]
        if isinstance(val, int):
            col_type = "INTEGER"
        elif isinstance(val, float):
            col_type = "REAL"
        elif isinstance(val, (list, dict)):
            col_type = "TEXT"  # store as JSON
        else:
            col_type = "TEXT"
        col_defs.append(f'"{col}" {col_type}')

    sql = f'CREATE TABLE IF NOT EXISTS "{table_name}" ({", ".join(col_defs)})'
    conn.execute(sql)


def _insert_rows(
    conn: sqlite3.Connection,
    table_name: str,
    columns: list[str],
    records: list[dict[str, Any]],
) -> None:
    """Insert data rows into a SQLite table."""
    placeholders = ", ".join("?" for _ in columns)
    col_names = ", ".join(f'"{c}"' for c in columns)
    sql = f'INSERT INTO "{table_name}" ({col_names}) VALUES ({placeholders})'

    rows = []
    for record in records:
        row = []
        for col in columns:
            val = record[col]
            if isinstance(val, (list, dict)):
                row.append(json.dumps(val, ensure_ascii=False))
            else:
                row.append(val)
        rows.append(tuple(row))

    conn.executemany(sql, rows)


def _create_fts_index(
    conn: sqlite3.Connection,
    table_name: str,
    columns: list[str],
    fts_columns: list[str] | None,
    sample: dict[str, Any],
) -> None:
    """Create an FTS5 full-text search index."""
    if fts_columns is None:
        # Auto-detect text columns containing Korean-relevant data
        fts_columns = [
            col
            for col in columns
            if isinstance(sample.get(col), str)
            and col
            not in ("item_image", "class_no", "registration_no", "shelf_life")
        ]

    if not fts_columns:
        return

    fts_table = f"{table_name}_fts"
    fts_col_list = ", ".join(fts_columns)
    conn.execute(
        f'CREATE VIRTUAL TABLE IF NOT EXISTS "{fts_table}" '
        f"USING fts5({fts_col_list}, content_rowid=\"rowid\")"
    )

    # Populate FTS index from the main table
    select_cols = ", ".join(f'"{c}"' for c in fts_columns)
    conn.execute(
        f'INSERT INTO "{fts_table}" (rowid, {fts_col_list}) '
        f'SELECT rowid, {select_cols} FROM "{table_name}"'
    )


def export_parquet(
    data: Sequence[BaseModel],
    output_path: str | Path,
) -> Path:
    """Export Pydantic models to a Parquet file.

    Requires pyarrow to be installed (optional dependency).

    Args:
        data: Sequence of Pydantic model instances.
        output_path: Output file path.

    Returns:
        Path to the written file.

    Raises:
        ImportError: If pyarrow is not installed.
    """
    try:
        import pyarrow as pa
        import pyarrow.parquet as pq
    except ImportError as exc:
        raise ImportError(
            "pyarrow is required for Parquet export. "
            "Install it with: pip install korean-pharma-data[parquet]"
        ) from exc

    output_path = Path(output_path)
    if not data:
        return output_path

    records = [item.model_dump() for item in data]

    # Serialize nested structures as JSON strings for Parquet
    for record in records:
        for key, value in record.items():
            if isinstance(value, (list, dict)):
                record[key] = json.dumps(value, ensure_ascii=False)

    table = pa.Table.from_pylist(records)
    pq.write_table(table, str(output_path))
    return output_path
