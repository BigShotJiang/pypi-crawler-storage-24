"""Collector for 건강기능식품 정보 API."""

from __future__ import annotations

import logging
from typing import Any

from korean_pharma_data.client import MFDSClient
from korean_pharma_data.models import CollectionResult, Supplement, SupplementIngredient
from korean_pharma_data.parsers.xml_parser import parse_xml_items
from korean_pharma_data.utils import clean_html_tags, normalize_korean_name

logger = logging.getLogger(__name__)

ENDPOINT = "/HtfsSleIrdntInfoService/getHtfsInfoList"


class SupplementCollector:
    """Collect health functional food data from MFDS API.

    Args:
        client: Configured MFDSClient instance.
    """

    def __init__(self, client: MFDSClient) -> None:
        self.client = client

    async def collect(
        self,
        product_name: str | None = None,
        company: str | None = None,
        page_size: int = 100,
        max_pages: int | None = None,
    ) -> tuple[list[Supplement], CollectionResult]:
        """Collect supplement (건강기능식품) records.

        Args:
            product_name: Filter by product name.
            company: Filter by company name.
            page_size: Records per page.
            max_pages: Max pages to fetch.

        Returns:
            Tuple of (list of Supplement models, CollectionResult summary).
        """
        params: dict[str, Any] = {"type": "xml"}
        if product_name:
            params["prdlstNm"] = product_name
        if company:
            params["bsshNm"] = company

        pages = await self.client.request_all_pages(
            ENDPOINT, params=params, page_size=page_size, max_pages=max_pages
        )

        supplements: list[Supplement] = []
        errors: list[str] = []

        for page_xml in pages:
            try:
                items = parse_xml_items(page_xml)
                for item in items:
                    try:
                        supplement = self._parse_supplement(item)
                        supplements.append(supplement)
                    except Exception as exc:
                        error_msg = f"Failed to parse supplement: {exc}"
                        logger.warning(error_msg)
                        errors.append(error_msg)
            except Exception as exc:
                error_msg = f"Failed to parse supplement page: {exc}"
                logger.error(error_msg)
                errors.append(error_msg)

        result = CollectionResult(
            source="supplement",
            total_count=len(supplements) + len(errors),
            collected_count=len(supplements),
            error_count=len(errors),
            errors=errors,
        )
        return supplements, result

    @staticmethod
    def _parse_supplement(item: dict[str, str]) -> Supplement:
        """Parse a single supplement item from XML data."""
        ingredients: list[SupplementIngredient] = []
        raw_ingredients = item.get("RAWMTRL_NM", "")
        if raw_ingredients:
            for part in raw_ingredients.split(","):
                part = part.strip()
                if part:
                    ingredients.append(
                        SupplementIngredient(name=normalize_korean_name(part))
                    )

        return Supplement(
            product_name=normalize_korean_name(item.get("PRDLST_NM", "")),
            company=normalize_korean_name(item.get("BSSH_NM", "")),
            registration_no=item.get("STDR_STPT_NO", ""),
            ingredients=ingredients,
            functionality=clean_html_tags(item.get("PRIMARY_FNCLTY", "")),
            precautions=clean_html_tags(item.get("IFTKN_ATNT_MATR_CN", "")),
            intake_method=clean_html_tags(item.get("NTK_MTHD", "")),
            shelf_life=item.get("POG_DAYCNT", ""),
        )
