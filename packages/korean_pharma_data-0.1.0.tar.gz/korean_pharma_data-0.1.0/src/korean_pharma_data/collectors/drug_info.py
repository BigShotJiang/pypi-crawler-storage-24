"""Collector for 의약품 제품 허가정보 (e약은요) API."""

from __future__ import annotations

import logging
from typing import Any

from korean_pharma_data.client import MFDSClient
from korean_pharma_data.models import CollectionResult, Drug
from korean_pharma_data.parsers.drug_parser import parse_drugs_from_xml

logger = logging.getLogger(__name__)

ENDPOINT = "/DrbEasyDrugInfoService/getDrbEasyDrugList"


class DrugInfoCollector:
    """Collect drug product information from the e약은요 API.

    Args:
        client: Configured MFDSClient instance.
    """

    def __init__(self, client: MFDSClient) -> None:
        self.client = client

    async def collect(
        self,
        item_name: str | None = None,
        entp_name: str | None = None,
        item_seq: str | None = None,
        page_size: int = 100,
        max_pages: int | None = None,
    ) -> tuple[list[Drug], CollectionResult]:
        """Collect drug info records.

        Args:
            item_name: Filter by product name (제품명).
            entp_name: Filter by company name (업체명).
            item_seq: Filter by item sequence code (품목기준코드).
            page_size: Records per page.
            max_pages: Max pages to fetch. None for all.

        Returns:
            Tuple of (list of Drug models, CollectionResult summary).
        """
        params: dict[str, Any] = {"type": "xml"}
        if item_name:
            params["itemName"] = item_name
        if entp_name:
            params["entpName"] = entp_name
        if item_seq:
            params["itemSeq"] = item_seq

        pages = await self.client.request_all_pages(
            ENDPOINT, params=params, page_size=page_size, max_pages=max_pages
        )

        drugs: list[Drug] = []
        errors: list[str] = []

        for page_xml in pages:
            try:
                page_drugs = parse_drugs_from_xml(page_xml)
                drugs.extend(page_drugs)
            except Exception as exc:
                error_msg = f"Failed to parse drug info page: {exc}"
                logger.error(error_msg)
                errors.append(error_msg)

        result = CollectionResult(
            source="drug_info",
            total_count=len(drugs) + len(errors),
            collected_count=len(drugs),
            error_count=len(errors),
            errors=errors,
        )
        return drugs, result

    async def search(self, query: str, max_results: int = 20) -> list[Drug]:
        """Search for drugs by name.

        Args:
            query: Search term (Korean drug name).
            max_results: Maximum results to return.

        Returns:
            List of matching Drug models.
        """
        max_pages = (max_results // 100) + 1
        drugs, _ = await self.collect(
            item_name=query, page_size=min(max_results, 100), max_pages=max_pages
        )
        return drugs[:max_results]
