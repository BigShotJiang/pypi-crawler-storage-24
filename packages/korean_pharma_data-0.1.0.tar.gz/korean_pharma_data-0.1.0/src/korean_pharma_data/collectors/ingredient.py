"""Collector for 의약품 성분정보 API."""

from __future__ import annotations

import logging
from typing import Any

from korean_pharma_data.client import MFDSClient
from korean_pharma_data.models import CollectionResult, Ingredient
from korean_pharma_data.parsers.xml_parser import parse_xml_items

logger = logging.getLogger(__name__)

ENDPOINT = "/DURIrdntInfoService03/getIrdntInfoList03"


class IngredientCollector:
    """Collect drug ingredient information from MFDS API.

    Args:
        client: Configured MFDSClient instance.
    """

    def __init__(self, client: MFDSClient) -> None:
        self.client = client

    async def collect(
        self,
        ingredient_name: str | None = None,
        item_seq: str | None = None,
        page_size: int = 100,
        max_pages: int | None = None,
    ) -> tuple[list[Ingredient], CollectionResult]:
        """Collect ingredient records.

        Args:
            ingredient_name: Filter by ingredient name (성분명).
            item_seq: Filter by item sequence code.
            page_size: Records per page.
            max_pages: Max pages to fetch.

        Returns:
            Tuple of (list of Ingredient models, CollectionResult summary).
        """
        params: dict[str, Any] = {"type": "xml"}
        if ingredient_name:
            params["irdntName"] = ingredient_name
        if item_seq:
            params["itemSeq"] = item_seq

        pages = await self.client.request_all_pages(
            ENDPOINT, params=params, page_size=page_size, max_pages=max_pages
        )

        ingredients: list[Ingredient] = []
        errors: list[str] = []

        for page_xml in pages:
            try:
                items = parse_xml_items(page_xml)
                for item in items:
                    try:
                        ingredient = Ingredient(
                            code=item.get("INGR_CODE", ""),
                            name=item.get("INGR_KOR_NAME", item.get("INGR_NAME", "")),
                            name_en=item.get("INGR_ENG_NAME", ""),
                            amount=item.get("UD_QTY", ""),
                            unit=item.get("UD_QTY_UNIT", ""),
                        )
                        ingredients.append(ingredient)
                    except Exception as exc:
                        error_msg = f"Failed to parse ingredient: {exc}"
                        logger.warning(error_msg)
                        errors.append(error_msg)
            except Exception as exc:
                error_msg = f"Failed to parse ingredient page: {exc}"
                logger.error(error_msg)
                errors.append(error_msg)

        result = CollectionResult(
            source="ingredient",
            total_count=len(ingredients) + len(errors),
            collected_count=len(ingredients),
            error_count=len(errors),
            errors=errors,
        )
        return ingredients, result
