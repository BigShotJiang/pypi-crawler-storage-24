"""Collector for DUR (Drug Utilization Review) 품목정보 API."""

from __future__ import annotations

import logging
from typing import Any

from korean_pharma_data.client import MFDSClient
from korean_pharma_data.models import CollectionResult, DURInteraction
from korean_pharma_data.parsers.dur_parser import parse_dur_from_xml

logger = logging.getLogger(__name__)

# DUR API sub-endpoints
DUR_ENDPOINTS = {
    "병용금기": "/DURPrdlstInfoService03/getUsjntTabooInfoList03",
    "연령금기": "/DURPrdlstInfoService03/getSpcifyAgrdeTabooInfoList03",
    "임부금기": "/DURPrdlstInfoService03/getPwnmTabooInfoList03",
    "용량주의": "/DURPrdlstInfoService03/getCpctyAtentInfoList03",
}


class DURCollector:
    """Collect DUR interaction data from MFDS APIs.

    Args:
        client: Configured MFDSClient instance.
    """

    def __init__(self, client: MFDSClient) -> None:
        self.client = client

    async def collect(
        self,
        dur_type: str | None = None,
        item_seq: str | None = None,
        page_size: int = 100,
        max_pages: int | None = None,
    ) -> tuple[list[DURInteraction], CollectionResult]:
        """Collect DUR interaction records.

        Args:
            dur_type: Specific DUR type to collect. None for all types.
                Options: 병용금기, 연령금기, 임부금기, 용량주의
            item_seq: Filter by item sequence code.
            page_size: Records per page.
            max_pages: Max pages per type.

        Returns:
            Tuple of (list of DURInteraction models, CollectionResult summary).
        """
        endpoints = {}
        if dur_type:
            if dur_type not in DUR_ENDPOINTS:
                raise ValueError(
                    f"Unknown DUR type: {dur_type}. "
                    f"Must be one of: {', '.join(DUR_ENDPOINTS.keys())}"
                )
            endpoints = {dur_type: DUR_ENDPOINTS[dur_type]}
        else:
            endpoints = DUR_ENDPOINTS

        all_interactions: list[DURInteraction] = []
        all_errors: list[str] = []

        for type_name, endpoint in endpoints.items():
            params: dict[str, Any] = {"type": "xml"}
            if item_seq:
                params["itemSeq"] = item_seq

            try:
                pages = await self.client.request_all_pages(
                    endpoint,
                    params=params,
                    page_size=page_size,
                    max_pages=max_pages,
                )

                for page_xml in pages:
                    try:
                        interactions = parse_dur_from_xml(page_xml, type_name)
                        all_interactions.extend(interactions)
                    except Exception as exc:
                        error_msg = f"Failed to parse DUR {type_name} page: {exc}"
                        logger.error(error_msg)
                        all_errors.append(error_msg)

            except Exception as exc:
                error_msg = f"Failed to collect DUR {type_name}: {exc}"
                logger.error(error_msg)
                all_errors.append(error_msg)

        result = CollectionResult(
            source="dur",
            total_count=len(all_interactions) + len(all_errors),
            collected_count=len(all_interactions),
            error_count=len(all_errors),
            errors=all_errors,
        )
        return all_interactions, result

    async def collect_contraindicated_combinations(
        self,
        item_seq: str | None = None,
        page_size: int = 100,
        max_pages: int | None = None,
    ) -> tuple[list[DURInteraction], CollectionResult]:
        """Convenience method to collect only contraindicated combinations (병용금기).

        Args:
            item_seq: Filter by item sequence code.
            page_size: Records per page.
            max_pages: Max pages to fetch.

        Returns:
            Tuple of (interactions, result summary).
        """
        return await self.collect(
            dur_type="병용금기",
            item_seq=item_seq,
            page_size=page_size,
            max_pages=max_pages,
        )
