"""Utility functions for Korean pharmaceutical data processing."""

from __future__ import annotations

import re
import unicodedata


def normalize_korean_name(name: str) -> str:
    """Normalize a Korean drug/supplement name.

    - Strip leading/trailing whitespace
    - Collapse multiple whitespace into single space
    - Remove invisible Unicode characters
    - Normalize Unicode (NFC)

    Args:
        name: Raw Korean name string.

    Returns:
        Normalized name string.
    """
    if not name:
        return ""
    text = unicodedata.normalize("NFC", name)
    text = re.sub(r"[\u200b\u200c\u200d\ufeff]", "", text)
    text = re.sub(r"\s+", " ", text).strip()
    return text


def clean_html_tags(text: str) -> str:
    """Remove HTML tags from a string.

    Args:
        text: String potentially containing HTML tags.

    Returns:
        Clean text without HTML tags.
    """
    if not text:
        return ""
    return re.sub(r"<[^>]+>", "", text).strip()


def parse_ingredient_string(raw: str) -> list[dict[str, str]]:
    """Parse a raw ingredient string into structured components.

    Common formats from MFDS APIs:
    - "성분명1|분량1|단위1;성분명2|분량2|단위2"
    - "[M]성분명1 분량1단위1/1정"

    Args:
        raw: Raw ingredient string from API.

    Returns:
        List of dicts with 'name', 'amount', 'unit' keys.
    """
    if not raw:
        return []

    results = []

    # Try pipe-delimited format first
    if "|" in raw:
        entries = raw.split(";")
        for entry in entries:
            parts = entry.strip().split("|")
            if len(parts) >= 1:
                ingredient = {
                    "name": normalize_korean_name(parts[0]),
                    "amount": parts[1].strip() if len(parts) > 1 else "",
                    "unit": parts[2].strip() if len(parts) > 2 else "",
                }
                if ingredient["name"]:
                    results.append(ingredient)
    else:
        # Try [M] prefixed format
        entries = re.split(r"[;,/]", raw)
        for entry in entries:
            entry = re.sub(r"^\[.*?\]", "", entry).strip()
            if not entry:
                continue
            match = re.match(r"(.+?)\s*([\d.]+)\s*(\S+)?", entry)
            if match:
                results.append({
                    "name": normalize_korean_name(match.group(1)),
                    "amount": match.group(2),
                    "unit": match.group(3) or "",
                })
            else:
                results.append({
                    "name": normalize_korean_name(entry),
                    "amount": "",
                    "unit": "",
                })

    return results


def truncate_text(text: str, max_length: int = 500) -> str:
    """Truncate text to a maximum length, adding ellipsis if needed.

    Args:
        text: Text to truncate.
        max_length: Maximum character length.

    Returns:
        Truncated text.
    """
    if not text or len(text) <= max_length:
        return text or ""
    return text[: max_length - 3] + "..."


def make_slug(name: str) -> str:
    """Create a URL-friendly slug from a Korean drug name.

    Keeps Korean characters, lowercases ASCII, replaces non-alphanum with hyphens.

    Args:
        name: Drug or supplement name.

    Returns:
        URL-safe slug string.
    """
    if not name:
        return ""
    text = normalize_korean_name(name).lower()
    text = re.sub(r"[^\w가-힣-]", "-", text)
    text = re.sub(r"-+", "-", text).strip("-")
    return text
