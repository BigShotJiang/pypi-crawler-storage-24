"""CLI interface for korean-pharma-data."""

from __future__ import annotations

import asyncio
import json
import sys
from pathlib import Path

import click


@click.group()
@click.version_option(package_name="korean-pharma-data")
def main() -> None:
    """Korean pharmaceutical data collector and exporter.

    Collect, parse, and export drug/supplement data from
    Korea's Ministry of Food and Drug Safety (MFDS) APIs.
    """


@main.group()
def collect() -> None:
    """Collect data from MFDS APIs."""


@collect.command("drugs")
@click.option("--api-key", required=True, envvar="MFDS_API_KEY", help="공공데이터포털 API key.")
@click.option("--output", "-o", default="drugs.json", help="Output file path.")
@click.option("--format", "fmt", default="json", type=click.Choice(["json", "csv"]))
@click.option("--name", default=None, help="Filter by drug name (제품명).")
@click.option("--max-pages", default=None, type=int, help="Maximum pages to fetch.")
def collect_drugs(
    api_key: str, output: str, fmt: str, name: str | None, max_pages: int | None
) -> None:
    """Collect drug product information (e약은요)."""
    asyncio.run(_collect_drugs(api_key, output, fmt, name, max_pages))


async def _collect_drugs(
    api_key: str, output: str, fmt: str, name: str | None, max_pages: int | None
) -> None:
    from korean_pharma_data.client import MFDSClient
    from korean_pharma_data.collectors.drug_info import DrugInfoCollector
    from korean_pharma_data.exporters import export_csv, export_json

    async with MFDSClient(api_key=api_key) as client:
        collector = DrugInfoCollector(client)
        drugs, result = await collector.collect(item_name=name, max_pages=max_pages)

    click.echo(f"Collected {result.collected_count} drugs.")

    if fmt == "json":
        export_json(drugs, output)
    elif fmt == "csv":
        export_csv(drugs, output)

    click.echo(f"Exported to {output}")
    if result.errors:
        click.echo(f"Errors: {len(result.errors)}", err=True)


@collect.command("dur")
@click.option("--api-key", required=True, envvar="MFDS_API_KEY", help="공공데이터포털 API key.")
@click.option("--output", "-o", default="dur.json", help="Output file path.")
@click.option("--format", "fmt", default="json", type=click.Choice(["json", "csv"]))
@click.option(
    "--type",
    "dur_type",
    default=None,
    type=click.Choice(["병용금기", "연령금기", "임부금기", "용량주의"]),
    help="DUR type to collect.",
)
@click.option("--max-pages", default=None, type=int, help="Maximum pages to fetch.")
def collect_dur(
    api_key: str, output: str, fmt: str, dur_type: str | None, max_pages: int | None
) -> None:
    """Collect DUR interaction data."""
    asyncio.run(_collect_dur(api_key, output, fmt, dur_type, max_pages))


async def _collect_dur(
    api_key: str, output: str, fmt: str, dur_type: str | None, max_pages: int | None
) -> None:
    from korean_pharma_data.client import MFDSClient
    from korean_pharma_data.collectors.dur import DURCollector
    from korean_pharma_data.exporters import export_csv, export_json

    async with MFDSClient(api_key=api_key) as client:
        collector = DURCollector(client)
        interactions, result = await collector.collect(dur_type=dur_type, max_pages=max_pages)

    click.echo(f"Collected {result.collected_count} DUR interactions.")

    if fmt == "json":
        export_json(interactions, output)
    elif fmt == "csv":
        export_csv(interactions, output)

    click.echo(f"Exported to {output}")


@collect.command("supplements")
@click.option("--api-key", required=True, envvar="MFDS_API_KEY", help="공공데이터포털 API key.")
@click.option("--output", "-o", default="supplements.json", help="Output file path.")
@click.option("--format", "fmt", default="json", type=click.Choice(["json", "csv"]))
@click.option("--name", default=None, help="Filter by supplement name.")
@click.option("--max-pages", default=None, type=int, help="Maximum pages to fetch.")
def collect_supplements(
    api_key: str, output: str, fmt: str, name: str | None, max_pages: int | None
) -> None:
    """Collect health functional food data (건강기능식품)."""
    asyncio.run(_collect_supplements(api_key, output, fmt, name, max_pages))


async def _collect_supplements(
    api_key: str, output: str, fmt: str, name: str | None, max_pages: int | None
) -> None:
    from korean_pharma_data.client import MFDSClient
    from korean_pharma_data.collectors.supplement import SupplementCollector
    from korean_pharma_data.exporters import export_csv, export_json

    async with MFDSClient(api_key=api_key) as client:
        collector = SupplementCollector(client)
        supplements, result = await collector.collect(product_name=name, max_pages=max_pages)

    click.echo(f"Collected {result.collected_count} supplements.")

    if fmt == "json":
        export_json(supplements, output)
    elif fmt == "csv":
        export_csv(supplements, output)

    click.echo(f"Exported to {output}")


@main.command("export")
@click.argument("input_file", type=click.Path(exists=True))
@click.option(
    "--format",
    "fmt",
    required=True,
    type=click.Choice(["json", "csv", "sqlite", "parquet"]),
    help="Export format.",
)
@click.option("--output", "-o", required=True, help="Output file path.")
@click.option("--table", default="data", help="Table name (for SQLite).")
def export_cmd(input_file: str, fmt: str, output: str, table: str) -> None:
    """Export a JSON data file to another format."""
    from korean_pharma_data.exporters import export_csv, export_json, export_parquet, export_sqlite
    from korean_pharma_data.models import Drug, DURInteraction, Supplement

    data_raw = json.loads(Path(input_file).read_text(encoding="utf-8"))
    if not data_raw:
        click.echo("No data to export.", err=True)
        sys.exit(1)

    # Auto-detect model type from fields
    sample = data_raw[0]
    if "item_seq" in sample and "efcy_qesitm" in sample:
        models = [Drug(**r) for r in data_raw]
    elif "item_seq_a" in sample:
        models = [DURInteraction(**r) for r in data_raw]
    elif "product_name" in sample and "functionality" in sample:
        models = [Supplement(**r) for r in data_raw]
    else:
        click.echo("Cannot auto-detect data type from JSON fields.", err=True)
        sys.exit(1)

    if fmt == "json":
        export_json(models, output)
    elif fmt == "csv":
        export_csv(models, output)
    elif fmt == "sqlite":
        export_sqlite(models, output, table_name=table)
    elif fmt == "parquet":
        export_parquet(models, output)

    click.echo(f"Exported {len(models)} records to {output}")


@main.command("search")
@click.argument("query")
@click.option("--db", required=True, type=click.Path(exists=True), help="SQLite database path.")
@click.option("--table", default="data", help="Table name to search.")
@click.option("--limit", default=10, help="Max results.")
def search_cmd(query: str, db: str, table: str, limit: int) -> None:
    """Search for drugs in a SQLite database using FTS5."""
    import sqlite3

    conn = sqlite3.connect(db)
    conn.row_factory = sqlite3.Row
    fts_table = f"{table}_fts"

    # Use prefix matching for Korean text compatibility with FTS5 unicode61 tokenizer
    fts_query = f"{query}*" if not query.endswith("*") else query
    try:
        cursor = conn.execute(
            f'SELECT * FROM "{table}" WHERE rowid IN '
            f'(SELECT rowid FROM "{fts_table}" WHERE "{fts_table}" MATCH ?) '
            f"LIMIT ?",
            (fts_query, limit),
        )
        rows = cursor.fetchall()
    except sqlite3.OperationalError:
        # Fallback to LIKE search if FTS not available
        cursor = conn.execute(
            f'SELECT * FROM "{table}" WHERE '
            f"item_name LIKE ? OR product_name LIKE ? LIMIT ?",
            (f"%{query}%", f"%{query}%", limit),
        )
        rows = cursor.fetchall()
    finally:
        conn.close()

    if not rows:
        click.echo("No results found.")
        return

    for row in rows:
        row_dict = dict(row)
        name = row_dict.get("item_name") or row_dict.get("product_name", "Unknown")
        click.echo(f"  {name}")
        for key in ("entp_name", "company", "efcy_qesitm", "functionality"):
            if key in row_dict and row_dict[key]:
                label = key.replace("_", " ").title()
                value = row_dict[key][:80]
                click.echo(f"    {label}: {value}")
        click.echo()


if __name__ == "__main__":
    main()
