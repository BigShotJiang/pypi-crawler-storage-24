"""Pydantic data models for Korean pharmaceutical data."""

from __future__ import annotations

from pydantic import BaseModel, Field


class Ingredient(BaseModel):
    """Single ingredient in a drug product."""

    code: str = Field(default="", description="성분코드")
    name: str = Field(description="성분명 (Korean)")
    name_en: str = Field(default="", description="성분명 (English)")
    amount: str = Field(default="", description="분량")
    unit: str = Field(default="", description="단위")


class Drug(BaseModel):
    """Drug product information from e약은요 API."""

    item_seq: str = Field(description="품목기준코드")
    item_name: str = Field(description="제품명")
    entp_name: str = Field(default="", description="업체명")
    chart: str | None = Field(default=None, description="성상")
    item_image: str | None = Field(default=None, description="제품 이미지 URL")
    class_no: str = Field(default="", description="분류번호")
    class_name: str = Field(default="", description="분류명")
    etc_otc_name: str = Field(default="", description="전문/일반 구분")
    ingredients: list[Ingredient] = Field(default_factory=list, description="성분 목록")
    efcy_qesitm: str | None = Field(default=None, description="효능효과")
    use_method_qesitm: str | None = Field(default=None, description="용법용량")
    atpn_warn_qesitm: str | None = Field(default=None, description="경고")
    atpn_qesitm: str | None = Field(default=None, description="주의사항")
    intrc_qesitm: str | None = Field(default=None, description="상호작용")
    se_qesitm: str | None = Field(default=None, description="부작용")
    deposit_method_qesitm: str | None = Field(default=None, description="보관법")


class DURInteraction(BaseModel):
    """DUR (Drug Utilization Review) interaction record."""

    item_seq_a: str = Field(description="품목기준코드 A")
    item_name_a: str = Field(description="제품명 A")
    item_seq_b: str = Field(default="", description="품목기준코드 B")
    item_name_b: str = Field(default="", description="제품명 B")
    ingredient_name_a: str = Field(default="", description="성분명 A")
    ingredient_name_b: str = Field(default="", description="성분명 B")
    type: str = Field(description="DUR 유형 (병용금기, 연령금기, 임부금기, 용량주의 등)")
    prohibition_content: str = Field(default="", description="금기 내용")
    remark: str = Field(default="", description="비고")


class SupplementIngredient(BaseModel):
    """Single ingredient in a health supplement."""

    name: str = Field(description="원료명")
    amount: str = Field(default="", description="함량")
    unit: str = Field(default="", description="단위")
    daily_value: str = Field(default="", description="일일 영양성분 기준치 비율")


class Supplement(BaseModel):
    """Health functional food (건강기능식품) information."""

    product_name: str = Field(description="제품명")
    company: str = Field(default="", description="업체명")
    registration_no: str = Field(default="", description="신고번호")
    ingredients: list[SupplementIngredient] = Field(
        default_factory=list, description="원료 목록"
    )
    functionality: str = Field(default="", description="기능성 내용")
    precautions: str = Field(default="", description="섭취 시 주의사항")
    intake_method: str = Field(default="", description="섭취 방법")
    shelf_life: str = Field(default="", description="유통기한")


class CollectionResult(BaseModel):
    """Result summary for a data collection run."""

    source: str = Field(description="API source name")
    total_count: int = Field(default=0, description="Total records available")
    collected_count: int = Field(default=0, description="Records collected")
    error_count: int = Field(default=0, description="Records with errors")
    errors: list[str] = Field(default_factory=list, description="Error messages")
