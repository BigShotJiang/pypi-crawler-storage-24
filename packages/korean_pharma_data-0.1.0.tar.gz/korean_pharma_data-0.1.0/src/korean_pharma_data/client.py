"""Base async API client for MFDS (식약처) open data APIs."""

from __future__ import annotations

import asyncio
import hashlib
import json
import logging
from pathlib import Path
from typing import Any

import httpx

logger = logging.getLogger(__name__)

DEFAULT_BASE_URL = "https://apis.data.go.kr/1471000"
DEFAULT_CACHE_DIR = Path(".cache/korean-pharma-data")
DEFAULT_RATE_LIMIT = 5  # requests per second
DEFAULT_TIMEOUT = 30.0


class MFDSClient:
    """Async HTTP client for MFDS open data APIs.

    Features:
    - Automatic pagination
    - Rate limiting
    - Local file caching
    - Retry with exponential backoff

    Args:
        api_key: Public data portal API key (공공데이터포털 인증키).
        base_url: Base URL for the API.
        rate_limit: Max requests per second.
        cache_dir: Directory for response caching. None to disable.
        timeout: Request timeout in seconds.
    """

    def __init__(
        self,
        api_key: str,
        base_url: str = DEFAULT_BASE_URL,
        rate_limit: int = DEFAULT_RATE_LIMIT,
        cache_dir: Path | str | None = DEFAULT_CACHE_DIR,
        timeout: float = DEFAULT_TIMEOUT,
    ) -> None:
        self.api_key = api_key
        self.base_url = base_url.rstrip("/")
        self.rate_limit = rate_limit
        self.cache_dir = Path(cache_dir) if cache_dir else None
        self.timeout = timeout
        self._semaphore = asyncio.Semaphore(rate_limit)
        self._client: httpx.AsyncClient | None = None

        if self.cache_dir:
            self.cache_dir.mkdir(parents=True, exist_ok=True)

    async def _get_client(self) -> httpx.AsyncClient:
        """Get or create the httpx async client."""
        if self._client is None or self._client.is_closed:
            self._client = httpx.AsyncClient(
                base_url=self.base_url,
                timeout=self.timeout,
                headers={"Accept": "application/xml"},
            )
        return self._client

    async def close(self) -> None:
        """Close the underlying HTTP client."""
        if self._client and not self._client.is_closed:
            await self._client.aclose()
            self._client = None

    async def __aenter__(self) -> MFDSClient:
        return self

    async def __aexit__(self, *args: Any) -> None:
        await self.close()

    def _cache_key(self, path: str, params: dict[str, Any]) -> str:
        """Generate a cache key from request path and parameters."""
        raw = f"{path}:{json.dumps(params, sort_keys=True)}"
        return hashlib.sha256(raw.encode()).hexdigest()

    def _get_cached(self, cache_key: str) -> str | None:
        """Retrieve a cached response if available."""
        if not self.cache_dir:
            return None
        cache_file = self.cache_dir / f"{cache_key}.xml"
        if cache_file.exists():
            logger.debug("Cache hit: %s", cache_key[:12])
            return cache_file.read_text(encoding="utf-8")
        return None

    def _set_cached(self, cache_key: str, content: str) -> None:
        """Store a response in the local cache."""
        if not self.cache_dir:
            return
        cache_file = self.cache_dir / f"{cache_key}.xml"
        cache_file.write_text(content, encoding="utf-8")

    async def request(
        self,
        path: str,
        params: dict[str, Any] | None = None,
        use_cache: bool = True,
    ) -> str:
        """Make a single API request.

        Args:
            path: API endpoint path (appended to base_url).
            params: Query parameters (serviceKey is added automatically).
            use_cache: Whether to use local caching.

        Returns:
            Raw XML response body as string.

        Raises:
            httpx.HTTPStatusError: On non-2xx responses after retries.
        """
        params = dict(params or {})
        params["serviceKey"] = self.api_key

        cache_key = self._cache_key(path, params)
        if use_cache:
            cached = self._get_cached(cache_key)
            if cached is not None:
                return cached

        client = await self._get_client()
        max_retries = 3

        for attempt in range(max_retries):
            async with self._semaphore:
                try:
                    response = await client.get(path, params=params)
                    response.raise_for_status()
                    content = response.text
                    if use_cache:
                        self._set_cached(cache_key, content)
                    return content
                except (httpx.HTTPStatusError, httpx.ConnectError) as exc:
                    if attempt == max_retries - 1:
                        raise
                    wait = 2**attempt
                    logger.warning(
                        "Request failed (attempt %d/%d): %s. Retrying in %ds.",
                        attempt + 1,
                        max_retries,
                        exc,
                        wait,
                    )
                    await asyncio.sleep(wait)

        raise RuntimeError("Unreachable")  # pragma: no cover

    async def request_all_pages(
        self,
        path: str,
        params: dict[str, Any] | None = None,
        page_size: int = 100,
        max_pages: int | None = None,
    ) -> list[str]:
        """Fetch all pages of a paginated API endpoint.

        Args:
            path: API endpoint path.
            params: Base query parameters.
            page_size: Number of rows per page.
            max_pages: Maximum pages to fetch (None = all).

        Returns:
            List of raw XML response bodies, one per page.
        """
        params = dict(params or {})
        params["numOfRows"] = str(page_size)

        pages: list[str] = []
        page_no = 1

        while True:
            if max_pages and page_no > max_pages:
                break

            params["pageNo"] = str(page_no)
            logger.info("Fetching page %d of %s", page_no, path)
            content = await self.request(path, params)
            pages.append(content)

            # Simple heuristic: if response contains fewer items than page_size,
            # we've reached the last page. Actual detection is done by parsers.
            if f"<pageNo>{page_no}</pageNo>" in content:
                # Check totalCount vs current position
                import re

                match = re.search(r"<totalCount>(\d+)</totalCount>", content)
                if match:
                    total = int(match.group(1))
                    if page_no * page_size >= total:
                        break

            page_no += 1

        logger.info("Collected %d pages from %s", len(pages), path)
        return pages
