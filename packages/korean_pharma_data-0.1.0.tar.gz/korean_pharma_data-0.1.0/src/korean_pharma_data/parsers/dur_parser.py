"""DUR interaction data parser."""

from __future__ import annotations

from korean_pharma_data.models import DURInteraction
from korean_pharma_data.parsers.xml_parser import parse_xml_items
from korean_pharma_data.utils import normalize_korean_name


def parse_dur_from_xml(xml_text: str, dur_type: str = "병용금기") -> list[DURInteraction]:
    """Parse DUR interaction records from an API XML response.

    Args:
        xml_text: Raw XML response string.
        dur_type: The DUR type label for these records.

    Returns:
        List of DURInteraction models.
    """
    items = parse_xml_items(xml_text)
    interactions: list[DURInteraction] = []

    for item in items:
        interaction = _item_to_interaction(item, dur_type)
        interactions.append(interaction)

    return interactions


def _item_to_interaction(item: dict[str, str], dur_type: str) -> DURInteraction:
    """Convert a raw XML item dict into a DURInteraction model.

    Args:
        item: Dict of tag -> text from XML parsing.
        dur_type: The DUR type label.

    Returns:
        DURInteraction model instance.
    """
    return DURInteraction(
        item_seq_a=item.get("ITEM_SEQ", ""),
        item_name_a=normalize_korean_name(item.get("ITEM_NAME", "")),
        item_seq_b=item.get("MIXTURE_ITEM_SEQ", ""),
        item_name_b=normalize_korean_name(item.get("MIXTURE_ITEM_NAME", "")),
        ingredient_name_a=normalize_korean_name(item.get("INGR_KOR_NAME", "")),
        ingredient_name_b=normalize_korean_name(
            item.get("MIXTURE_INGR_KOR_NAME", item.get("INGR_KOR_NAME_B", ""))
        ),
        type=dur_type,
        prohibition_content=item.get("PROHBT_CONTENT", ""),
        remark=item.get("REMARK", ""),
    )
