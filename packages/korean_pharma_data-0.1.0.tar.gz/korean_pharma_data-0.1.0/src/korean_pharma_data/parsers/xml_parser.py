"""Generic XML response parser for MFDS APIs."""

from __future__ import annotations

from dataclasses import dataclass

from lxml import etree


@dataclass
class XMLResponseMeta:
    """Metadata from an MFDS API XML response."""

    result_code: str
    result_msg: str
    total_count: int
    page_no: int
    num_of_rows: int


def parse_xml_response(xml_text: str) -> tuple[XMLResponseMeta, list[dict[str, str]]]:
    """Parse a full MFDS API XML response.

    The standard MFDS response structure:
    ```xml
    <response>
        <header>
            <resultCode>00</resultCode>
            <resultMsg>NORMAL SERVICE.</resultMsg>
        </header>
        <body>
            <numOfRows>100</numOfRows>
            <pageNo>1</pageNo>
            <totalCount>1234</totalCount>
            <items>
                <item>...</item>
                <item>...</item>
            </items>
        </body>
    </response>
    ```

    Args:
        xml_text: Raw XML response string.

    Returns:
        Tuple of (metadata, list of item dicts).

    Raises:
        ValueError: If the response indicates an error or cannot be parsed.
    """
    try:
        root = etree.fromstring(xml_text.encode("utf-8"))
    except etree.XMLSyntaxError as exc:
        raise ValueError(f"Invalid XML: {exc}") from exc

    # Parse header
    header = root.find(".//header")
    result_code = ""
    result_msg = ""
    if header is not None:
        code_el = header.find("resultCode")
        msg_el = header.find("resultMsg")
        result_code = code_el.text or "" if code_el is not None else ""
        result_msg = msg_el.text or "" if msg_el is not None else ""

    if result_code and result_code != "00":
        raise ValueError(f"API error [{result_code}]: {result_msg}")

    # Parse body metadata
    body = root.find(".//body")
    total_count = 0
    page_no = 1
    num_of_rows = 100

    if body is not None:
        tc = body.find("totalCount")
        pn = body.find("pageNo")
        nr = body.find("numOfRows")
        total_count = int(tc.text) if tc is not None and tc.text else 0
        page_no = int(pn.text) if pn is not None and pn.text else 1
        num_of_rows = int(nr.text) if nr is not None and nr.text else 100

    meta = XMLResponseMeta(
        result_code=result_code,
        result_msg=result_msg,
        total_count=total_count,
        page_no=page_no,
        num_of_rows=num_of_rows,
    )

    # Parse items
    items = _extract_items(root)
    return meta, items


def parse_xml_items(xml_text: str) -> list[dict[str, str]]:
    """Parse XML and return only the list of item dicts.

    Args:
        xml_text: Raw XML response string.

    Returns:
        List of dicts, one per <item> element.
    """
    _, items = parse_xml_response(xml_text)
    return items


def _extract_items(root: etree._Element) -> list[dict[str, str]]:
    """Extract item elements from an XML tree.

    Args:
        root: Parsed XML root element.

    Returns:
        List of dicts mapping tag names to text content.
    """
    items: list[dict[str, str]] = []

    for item_el in root.iter("item"):
        item_dict: dict[str, str] = {}
        for child in item_el:
            tag = etree.QName(child.tag).localname if isinstance(child.tag, str) else str(child.tag)
            text = child.text or ""
            item_dict[tag] = text.strip()
        items.append(item_dict)

    return items
