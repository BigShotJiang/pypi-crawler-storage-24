"""Drug-specific field normalization and parsing."""

from __future__ import annotations

from korean_pharma_data.models import Drug, Ingredient
from korean_pharma_data.parsers.xml_parser import parse_xml_items
from korean_pharma_data.utils import clean_html_tags, normalize_korean_name, parse_ingredient_string


def parse_drugs_from_xml(xml_text: str) -> list[Drug]:
    """Parse drug records from an e약은요 API XML response.

    Args:
        xml_text: Raw XML response string.

    Returns:
        List of Drug models.
    """
    items = parse_xml_items(xml_text)
    drugs: list[Drug] = []

    for item in items:
        drug = _item_to_drug(item)
        drugs.append(drug)

    return drugs


def _item_to_drug(item: dict[str, str]) -> Drug:
    """Convert a raw XML item dict into a Drug model.

    Args:
        item: Dict of tag -> text from XML parsing.

    Returns:
        Drug model instance.
    """
    # Parse ingredients from the raw field
    raw_ingredients = item.get("MATERIAL_NAME", "")
    ingredients = _parse_drug_ingredients(raw_ingredients)

    return Drug(
        item_seq=item.get("ITEM_SEQ", ""),
        item_name=normalize_korean_name(item.get("ITEM_NAME", "")),
        entp_name=normalize_korean_name(item.get("ENTP_NAME", "")),
        chart=item.get("CHART", None) or None,
        item_image=item.get("ITEM_IMAGE", None) or None,
        class_no=item.get("CLASS_NO", ""),
        class_name=item.get("CLASS_NAME", ""),
        etc_otc_name=item.get("ETC_OTC_NAME", ""),
        ingredients=ingredients,
        efcy_qesitm=clean_html_tags(item.get("EE_DOC_DATA", "")) or None,
        use_method_qesitm=clean_html_tags(item.get("UD_DOC_DATA", "")) or None,
        atpn_warn_qesitm=clean_html_tags(item.get("NB_DOC_DATA", "")) or None,
        atpn_qesitm=clean_html_tags(item.get("ATPN_QESITM", "")) or None,
        intrc_qesitm=clean_html_tags(item.get("INTRC_QESITM", "")) or None,
        se_qesitm=clean_html_tags(item.get("SE_QESITM", "")) or None,
        deposit_method_qesitm=clean_html_tags(
            item.get("DEPOSIT_METHOD_QESITM", "")
        ) or None,
    )


def _parse_drug_ingredients(raw: str) -> list[Ingredient]:
    """Parse drug ingredient data into Ingredient models.

    Args:
        raw: Raw ingredient string from MATERIAL_NAME field.

    Returns:
        List of Ingredient models.
    """
    parsed = parse_ingredient_string(raw)
    return [
        Ingredient(
            name=entry["name"],
            amount=entry.get("amount", ""),
            unit=entry.get("unit", ""),
        )
        for entry in parsed
        if entry.get("name")
    ]
