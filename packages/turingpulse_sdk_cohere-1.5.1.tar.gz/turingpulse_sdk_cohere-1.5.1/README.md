# turingpulse-sdk-cohere

TuringPulse SDK integration for Cohere — automatic tracing for Command R+, Embed, and Rerank.

## Installation

```bash
pip install turingpulse-sdk-cohere
```

## Quick Start

```python
import cohere
from turingpulse_sdk import init, TuringPulseConfig
from turingpulse_sdk_cohere import patch_cohere

init(TuringPulseConfig(api_key="sk_live_...", workflow_name="my-project"))
patch_cohere(name="my-project")

client = cohere.ClientV2()
response = client.chat(
    model="command-r-plus",
    messages=[{"role": "user", "content": "Hello!"}]
)
```

## Documentation

Full documentation: [turingpulse.ai/docs/sdk/cohere](https://turingpulse.ai/docs/sdk/cohere)

## Requirements

- Python >= 3.11
- turingpulse-sdk >= 1.0.0
- cohere >= 5.20.0
