"""Cohere monkey-patch instrumentation for TuringPulse."""

from __future__ import annotations

import logging
import os
from contextvars import ContextVar
from typing import Any, Optional

from turingpulse_sdk import instrument, GovernanceDirective
from turingpulse_sdk.config import MAX_FIELD_SIZE
from turingpulse_sdk.context import current_context
from turingpulse_sdk.exceptions import ConfigurationError

logger = logging.getLogger("turingpulse.sdk.cohere")

_INSTRUMENTING: ContextVar[bool] = ContextVar("_tp_cohere_instrumenting", default=False)

_ORIGINAL_CHAT: Any = None


def patch_cohere(
    *,
    name: str | None = None,
    governance: Optional[GovernanceDirective] = None,
) -> None:
    """Monkey-patch ``cohere.ClientV2.chat``."""
    global _ORIGINAL_CHAT

    effective_name = name or os.getenv("TP_WORKFLOW_NAME", "")
    if not effective_name:
        raise ConfigurationError(
            "patch_cohere() requires name= or TP_WORKFLOW_NAME to be set."
        )

    try:
        from cohere import ClientV2
    except ImportError as exc:
        raise ImportError("cohere package is required: pip install cohere>=5.20.0") from exc

    if _ORIGINAL_CHAT is not None:
        logger.warning("Cohere is already patched — skipping")
        return

    _ORIGINAL_CHAT = ClientV2.chat

    @instrument(name=effective_name, governance=governance)
    def _patched_chat(self_client, *args: Any, **kwargs: Any) -> Any:
        if _INSTRUMENTING.get(False):
            return _ORIGINAL_CHAT(self_client, *args, **kwargs)
        token = _INSTRUMENTING.set(True)
        try:
            response = _ORIGINAL_CHAT(self_client, *args, **kwargs)
            _record_cohere_span(response, kwargs)
            return response
        finally:
            _INSTRUMENTING.reset(token)

    ClientV2.chat = _patched_chat
    logger.info("Cohere patched for TuringPulse instrumentation")


def unpatch_cohere() -> None:
    """Restore original Cohere methods."""
    global _ORIGINAL_CHAT
    if _ORIGINAL_CHAT is None:
        return
    try:
        from cohere import ClientV2
        ClientV2.chat = _ORIGINAL_CHAT
    except ImportError:
        pass
    _ORIGINAL_CHAT = None
    logger.info("Cohere unpatched — original methods restored")


def _record_cohere_span(response: Any, kwargs: dict) -> None:
    ctx = current_context()
    if not ctx:
        return
    ctx.framework = "cohere"
    ctx.node_type = "llm"

    usage = getattr(response, "usage", None)
    if usage:
        billed = getattr(usage, "billed_units", None)
        if billed:
            ctx.set_tokens(
                getattr(billed, "input_tokens", 0) or 0,
                getattr(billed, "output_tokens", 0) or 0,
            )

    ctx.set_model(kwargs.get("model", getattr(response, "model", "unknown")), "cohere")

    messages = kwargs.get("messages", [])
    if messages:
        last_user = next(
            (m for m in reversed(messages)
             if (m.get("role") if isinstance(m, dict) else getattr(m, "role", "")) == "user"),
            None,
        )
        if last_user:
            content = last_user.get("content", "") if isinstance(last_user, dict) else getattr(last_user, "content", "")
            ctx.set_prompt(str(content)[:MAX_FIELD_SIZE])

    tools_def = kwargs.get("tools")
    if tools_def:
        tool_names = []
        for t in tools_def:
            if isinstance(t, dict):
                func = t.get("function")
                tname = func.get("name") if isinstance(func, dict) else getattr(func, "name", None) if func else t.get("name")
            else:
                func = getattr(t, "function", None)
                tname = getattr(func, "name", None) if func else getattr(t, "name", None)
            if tname:
                tool_names.append(tname)
        if tool_names:
            ctx.available_tools = tool_names

    tokens = getattr(response, "meta", None)
    if tokens:
        tok = getattr(tokens, "tokens", None) if not isinstance(tokens, dict) else tokens.get("tokens")
        if tok:
            inp = (getattr(tok, "input_tokens", 0) if not isinstance(tok, dict) else tok.get("input_tokens", 0)) or 0
            out = (getattr(tok, "output_tokens", 0) if not isinstance(tok, dict) else tok.get("output_tokens", 0)) or 0
            if inp or out:
                ctx.set_tokens(inp, out)

    message = getattr(response, "message", None)
    if message:
        content = getattr(message, "content", [])
        if content:
            texts = [getattr(c, "text", "") for c in content if getattr(c, "type", "") == "text"]
            if texts:
                ctx.set_io(output_data="\n".join(texts)[:MAX_FIELD_SIZE])

        tool_calls = getattr(message, "tool_calls", None)
        if tool_calls:
            for tc in tool_calls:
                ctx.add_tool_call(
                    tool_name=getattr(tc, "name", "unknown"),
                    tool_args=getattr(tc, "parameters", {}),
                    tool_id=getattr(tc, "id", None),
                )
