---
name: Email Inbox Summary
description: Categorize unread Gmail with CRM cross-reference
schedule: morning
output: google-sheets
sheet_folder: 1jUBDYiyPxpWo1EObIs9rF8nsnSi63MXP
---

# Email Inbox Summary

> Fetches unread Gmail messages, categorizes them by action needed, cross-references senders with Attio CRM, and writes a summary to Google Sheets.

## Constants

| Key | Value |
|-----|-------|
| SHEETS_FOLDER_ID | `1jUBDYiyPxpWo1EObIs9rF8nsnSi63MXP` |

## Steps

### Step 1: Fetch unread emails

**Service:** `GWS`
**Method:** `gmail_list({"maxResults": 50, "q": "is:unread"})`
**Extract:** List of message IDs from the response.

### Step 2: Fetch each message body

**Service:** `GWS`
**Method:** `raw("gmail", "users", "messages", "get", "--params", json.dumps({"userId": "me", "id": message_id, "format": "metadata", "metadataHeaders": ["From", "Subject", "Date"]}))`
**Extract:** For each message — sender email, sender name, subject, date, snippet/preview text.

### Step 3: Categorize emails

**Logic:** Classify each email into one of three buckets:

- **Needs Reply** — Personal emails, client/partner messages, questions directed at me. Assign priority (1 = most urgent). Include a suggested action.
- **Informational** — Newsletters, notifications, FYI emails, automated reports. No reply needed but worth scanning.
- **Skip** — Marketing, spam that passed filters, irrelevant automated emails.

### Step 4: Cross-reference senders with Attio CRM

**Service:** `AttioClient`
**Method:** `list_people()` — search by sender email
**Extract:** For each sender found in CRM — company name, role, associated deals, recent notes. Add "CRM Status" column.

### Step 5: Write to Google Sheet

**Destination:** Google Sheets (create new spreadsheet in `SHEETS_FOLDER_ID`)
**Sheet name:** `Email Inbox Summary - {YYYY-MM-DD}`
**Pattern:** Use `gws` CLI following the pattern in `scripts/write_report.py`.

**Tabs:**

| Tab | Columns |
|-----|---------|
| Needs Reply | Priority, From, Subject, Date, Snippet, CRM Status, Company, Suggested Action |
| Informational | From, Subject, Date, Snippet, CRM Status, Category |
| Stats | Metric, Value |

**Stats tab rows:**
- Total unread
- Needs Reply count
- Informational count
- Skipped count
- Senders in CRM count
- Senders not in CRM count
