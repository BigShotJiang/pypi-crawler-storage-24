---
name: LinkedIn Inbox Triage
description: Categorize LinkedIn messages into action required, nurture, and no action
schedule: morning
output: google-sheets
sheet_folder: 1jUBDYiyPxpWo1EObIs9rF8nsnSi63MXP
---

# LinkedIn Inbox Triage

> Fetches recent LinkedIn conversations, categorizes them by urgency, cross-references with Attio CRM, and writes a triage report to Google Sheets.

## Constants

| Key | Value |
|-----|-------|
| LINKEDIN_ACCOUNT_ID | `PA6s1QH-Q6CZ7IVMiK-M6w` |
| SHEETS_FOLDER_ID | `1jUBDYiyPxpWo1EObIs9rF8nsnSi63MXP` |

## Steps

### Step 1: Fetch LinkedIn chats and messages

**Service:** `UnipileClient`
**Method:** `list_chats(account_id=LINKEDIN_ACCOUNT_ID)`
**Then:** For each chat, fetch messages via `client.request("GET", f"/chats/{chat_id}/messages")`
**Extract:** For each conversation — participant name, last message sender, last message text, timestamp. Focus on chats with activity in the last 7 days.

### Step 2: Categorize conversations

**Logic:** Classify each conversation into one of three buckets:

- **Action Required** — They sent the last message and I haven't replied. Assign a priority (1 = oldest/most urgent). Include suggested follow-up action.
- **Nurture** — I sent the last message and they haven't replied. Calculate a suggested nudge date (5 days after my last message). Include a summary of what I said.
- **No Action Needed** — Conversation is resolved, spam, recruiter outreach, or mutual close. Note the reason (e.g., "meeting planned", "recruiter pitch", "done").

### Step 3: Cross-reference with Attio CRM

**Service:** `AttioClient`
**Method:** `list_people()` and `list_companies()`
**Extract:** For each contact in the triage, check if they exist in Attio. If found, pull: company name, role/title, any associated deals, recent notes. Add a "CRM Status" column (e.g., "In CRM — Active Deal", "In CRM — No Deal", "Not in CRM").

### Step 4: Write to Google Sheet

**Destination:** Google Sheets (create new spreadsheet in `SHEETS_FOLDER_ID`)
**Sheet name:** `LinkedIn Inbox Triage - {YYYY-MM-DD}`
**Pattern:** Use `gws` CLI following the pattern in `scripts/write_report.py` — call `gws sheets spreadsheets values update` with `--params` and `--json` flags.

**Tabs:**

| Tab | Columns |
|-----|---------|
| Action Required | Priority, Who, Last Activity, Context, CRM Status, Suggested Follow-up |
| Nurture | Who, Company/Topic, Date Sent, My Message Summary, CRM Status, Suggested Nudge Date |
| No Action Needed | Who, Status, Last Activity, CRM Status, Notes |
