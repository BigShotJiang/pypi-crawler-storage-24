---
name: Daily Report
description: Daily summary doc + task sheet across Email, LinkedIn, ClearFeed, and Notion
schedule: morning
output: google-doc + google-sheets
doc_folder: 1vwlQ85yrNi61DPu8ddEZiC8eWd3oOrh8
---

# Daily Report

> Consolidates outstanding tasks from Email, LinkedIn, ClearFeed, and Notion into a Google Doc summary and a companion Google Sheet with importance/urgency ratings. Output goes to the Execution folder.

## Constants

| Key | Value |
|-----|-------|
| EXECUTION_FOLDER_ID | `1vwlQ85yrNi61DPu8ddEZiC8eWd3oOrh8` |
| LINKEDIN_ACCOUNT_ID | `PA6s1QH-Q6CZ7IVMiK-M6w` |
| NOTION_DEADLINES_DB | `b1949941-40c4-47a2-8aa0-63a86b7ba958` |

## Steps

### Step 1: Fetch all emails in the main inbox

**Service:** `GWS`
**Method:** `gmail_list({"maxResults": 100, "q": "in:inbox"})` — fetch all messages currently in the inbox (if archived/moved out, they're considered handled).
**Then:** Fetch each message via `raw("gmail", "users", "messages", "get", "--params", '{"userId": "me", "id": "MSG_ID", "format": "metadata"}', "--format", "json")` for metadata (From, Subject, Date).
**Use:** `--page-all` if needed to get beyond the first page.
**Extract:** Every email still in the inbox is outstanding — extract sender, subject, date, snippet.

### Step 2: Fetch LinkedIn conversations needing follow-up

**Service:** `UnipileClient`
**Method:** `list_chats(account_id=LINKEDIN_ACCOUNT_ID)`, then fetch messages for recent chats via `client.request("GET", f"/chats/{chat_id}/messages")`.
**Extract:** Conversations where the other party sent the last message (unanswered), or sent messages unanswered for 5+ days.

### Step 3: Fetch ClearFeed tickets needing attention

**Service:** `ClearFeedClient`
**Method:** `list_requests(status="open")` or equivalent params.
**Extract:** Ticket ID, title, customer, created date, status, collection.

### Step 4: Fetch Notion sprint tasks & deadlines

**Service:** `NotionClient`
**Method:**
```python
notion.query_database(
    NOTION_DEADLINES_DB,
    filter={"and": [{"property": "Status", "status": {"does_not_equal": "Done"}}]},
    sorts=[{"property": "Deadline", "direction": "ascending"}],
)
```
**Extract:** Name, Deadline, Company, Type, Status.

### Step 5: Rate each task by Importance and Urgency

Assign **Importance** (High / Medium / Low) and **Urgency** (High / Medium / Low) to every task from Steps 1–4. Add a one-line **Suggested Action**.

**Heuristics:**
- Overdue deadlines → High urgency
- CRM contacts / active deals → High importance
- Unknown contacts → Low importance
- ClearFeed tickets older than 3 days → High urgency
- Unanswered LinkedIn messages older than 5 days → High urgency
- Emails from known contacts → Medium+ importance

### Step 6: Create Google Doc in Execution folder

**Create doc:**
```
raw("docs", "documents", "create", "--json", '{"title": "Daily Report - YYYY-MM-DD"}', "--format", "json")
```
Extract `documentId`.

**Move to folder:**
```
raw("drive", "files", "update", "--params", '{"fileId": "<DOC_ID>", "addParents": "EXECUTION_FOLDER_ID", "removeParents": "root"}')
```

**Write content:**
```
raw("docs", "+write", "--document", "<DOC_ID>", "--text", "<content>")
```

**Doc structure (plain text, scannable):**

```
DAILY REPORT - YYYY-MM-DD
=========================

SUMMARY
- X emails need reply
- Y LinkedIn contacts need follow-up
- Z ClearFeed tickets open
- W Notion tasks due

EMAIL - OUTSTANDING TASKS
1. [Subject] from [Sender] ([Date])
   Action: [Suggested action]

LINKEDIN - FOLLOW-UP NEEDED
1. [Contact] - last heard [Date]
   Action: [Suggested action]

CLEARFEED - TICKETS
1. [Title] - [Customer] (opened [Date])
   Action: [Suggested action]

NOTION - SPRINT TASKS & DEADLINES
1. [Task] - [Company] (due [Deadline])
   Action: [Suggested action]
```

### Step 7: Create companion Google Sheet in Execution folder

**Create sheet:**
```
raw("sheets", "spreadsheets", "create", "--json", '{"properties": {"title": "Daily Tasks - YYYY-MM-DD"}}', "--format", "json")
```
Extract `spreadsheetId`.

**Move to Execution folder** (same drive update pattern as Step 6).

**Write rows** via `raw("sheets", "spreadsheets", "values", "update", ...)` following `scripts/write_report.py` pattern.

**Sheet columns (single "Outstanding Tasks" tab):**

| Source | Task | Importance | Urgency | Due Date | Contact/Ticket | Suggested Action |
|--------|------|------------|---------|----------|----------------|------------------|

Rows sorted by: Urgency desc → Importance desc → Due Date asc.

### Step 8: Output links

Print the Google Doc URL and Google Sheet URL for easy access.
