---
name: CRM Pipeline Review
description: Snapshot of CRM pipeline, overdue tasks, recent notes, and stale contacts
schedule: morning
output: google-sheets
sheet_folder: 1jUBDYiyPxpWo1EObIs9rF8nsnSi63MXP
---

# CRM Pipeline Review

> Pulls a full snapshot from Attio CRM — pipeline lists, overdue tasks, recent notes, and stale records — and writes a review dashboard to Google Sheets.

## Constants

| Key | Value |
|-----|-------|
| SHEETS_FOLDER_ID | `1jUBDYiyPxpWo1EObIs9rF8nsnSi63MXP` |

## Steps

### Step 1: Fetch pipeline lists

**Service:** `AttioClient`
**Method:** `list_lists()`
**Extract:** All lists with their names and record counts. These represent pipeline stages or segments.

### Step 2: Fetch tasks and flag overdue

**Service:** `AttioClient`
**Method:** `list_tasks()`
**Extract:** All tasks with content, due date, status, and linked record. Categorize as:
- **Overdue** — due date is before today and not completed
- **Due Today** — due date is today
- **Upcoming** — due date is within the next 7 days
- **No Due Date** — tasks without a deadline

### Step 3: Fetch recent notes

**Service:** `AttioClient`
**Method:** `list_notes()`
**Extract:** All notes from the last 7 days. Include: title, content summary (first 100 chars), parent record (person/company name), created date.

### Step 4: Identify stale records

**Service:** `AttioClient`
**Method:** `list_people()` and `list_companies()`
**Extract:** People and companies with no associated notes or tasks in the last 14 days. Flag as "stale" — these need attention or archiving. Include: name, company, last activity date, any open deals.

### Step 5: Write to Google Sheet

**Destination:** Google Sheets (create new spreadsheet in `SHEETS_FOLDER_ID`)
**Sheet name:** `CRM Pipeline Review - {YYYY-MM-DD}`
**Pattern:** Use `gws` CLI following the pattern in `scripts/write_report.py`.

**Tabs:**

| Tab | Columns |
|-----|---------|
| Overdue Tasks | Task, Due Date, Days Overdue, Linked Record, Status |
| This Week's Notes | Date, Title, Summary, Linked Record |
| Stale Records | Name, Type (Person/Company), Last Activity, Open Deals, Suggested Action |
| Pipeline Summary | List Name, Record Count, Notes |
