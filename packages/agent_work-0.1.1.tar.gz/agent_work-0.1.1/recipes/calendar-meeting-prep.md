---
name: Calendar Meeting Prep
description: Prep briefs for upcoming meetings with CRM and LinkedIn context
schedule: morning
output: google-sheets
sheet_folder: 1jUBDYiyPxpWo1EObIs9rF8nsnSi63MXP
---

# Calendar Meeting Prep

> Fetches today's and tomorrow's calendar events, looks up each external attendee in Attio CRM and LinkedIn, and produces a meeting prep brief in Google Sheets.

## Constants

| Key | Value |
|-----|-------|
| LINKEDIN_ACCOUNT_ID | `PA6s1QH-Q6CZ7IVMiK-M6w` |
| SHEETS_FOLDER_ID | `1jUBDYiyPxpWo1EObIs9rF8nsnSi63MXP` |

## Steps

### Step 1: Fetch calendar events for today and tomorrow

**Service:** `GWS`
**Method:** `raw("calendar", "events", "list", "--params", json.dumps({"calendarId": "primary", "timeMin": "<today>T00:00:00Z", "timeMax": "<tomorrow+1>T00:00:00Z", "singleEvents": True, "orderBy": "startTime"}))`
**Extract:** For each event — title, start time, end time, list of attendee emails. Filter out all-day events and events with no external attendees.

### Step 2: Identify external attendees

**Logic:** From each event's attendee list, filter out your own email and any internal domain emails. Collect unique external attendee emails across all events.

### Step 3: Look up attendees in Attio CRM

**Service:** `AttioClient`
**Method:** `list_people()` — filter/search by email address for each external attendee
**Extract:** For each attendee found — company name, role/title, associated deals (stage, value), recent notes (last 30 days). Flag attendees not found in CRM.

### Step 4: Search attendees on LinkedIn

**Service:** `UnipileClient`
**Method:** `search_people(query=attendee_name, account_id=LINKEDIN_ACCOUNT_ID)`
**Extract:** For each attendee — LinkedIn headline, any recent messages exchanged (check via `list_chats` and filter). Skip if attendee not found on LinkedIn.

### Step 5: Write prep brief to Google Sheet

**Destination:** Google Sheets (create new spreadsheet in `SHEETS_FOLDER_ID`)
**Sheet name:** `Meeting Prep - {YYYY-MM-DD}`
**Pattern:** Use `gws` CLI following the pattern in `scripts/write_report.py`.

**Tabs:**

| Tab | Columns |
|-----|---------|
| Meeting Prep | Meeting Time, Meeting Title, Attendee Name, Attendee Email, Company, Role, Deal Stage, Recent Notes, LinkedIn Headline, Recent LinkedIn Messages, Prep Notes |
| Missing from CRM | Attendee Name, Attendee Email, Meeting Title, Meeting Time, Action |
