"""Write LinkedIn follow-up report to Google Sheet."""

import json
import subprocess

SHEET_ID = "1AQUmCIYIF3PyBRv111Yoo3_QQuBaMv3iZVT9mHaVdZc"


def gws_values_update(range_: str, values: list[list[str]]) -> None:
    params = json.dumps({
        "spreadsheetId": SHEET_ID,
        "range": range_,
        "valueInputOption": "USER_ENTERED",
    })
    body = json.dumps({"values": values})
    result = subprocess.run(
        ["gws", "sheets", "spreadsheets", "values", "update",
         "--params", params, "--json", body, "--format", "json"],
        capture_output=True, text=True,
    )
    if result.returncode != 0:
        print(f"Error writing {range_}: {result.stdout} {result.stderr}")
    else:
        print(f"Wrote {range_}")


def main() -> None:
    # Tab 1: Action Required
    gws_values_update("Action Required!A1:E6", [
        ["Priority", "Who", "Last Activity", "Context", "Suggested Follow-up"],
        ["1", "Datamorf founder", "2026-03-06",
         "3 unanswered messages pitching GTM data tool. Latest: \"Guess you are busy Sebastian, all good!\"",
         "Reply to close the loop \u2014 politely decline or agree to a quick look"],
        ["2", "Energy tools developer", "2026-03-05",
         "Said: \"Following you here because we have a lot in common. We also develop tools for energy plants.\"",
         "Reply to explore synergies \u2014 potential partner in your space"],
        ["3", "ESG/Impact reporting person", "2026-03-04",
         "Asked: \"How did the result land for you, did it resonate?\" after you said it could be valuable later",
         "Brief reply acknowledging \u2014 keeps relationship warm for when ESG reporting becomes relevant"],
        ["4", "BESS white paper sender", "2026-03-04",
         "Shared a white paper on BESS modelling assumptions. Relevant to Rebase space.",
         "Thank them and comment on the paper if useful"],
    ])

    # Tab 2: Nurture (No Reply Yet)
    gws_values_update("Nurture (No Reply Yet)!A1:E7", [
        ["Who", "Company/Topic", "Date Sent", "Your Message Summary", "Suggested Nudge Date"],
        ["Julie", "European Energy \u2014 forecasting", "2026-03-05",
         "Asked about forecasting models and energy market participation",
         "2026-03-10"],
        ["Denis", "Weather/energy forecasts", "2026-03-05",
         "Asked about weather and energy forecast improvement points",
         "2026-03-10"],
        ["Andreas", "Trayport connections", "2026-03-05",
         "Asked about connections between Trayport and Rebase",
         "2026-03-11"],
        ["Marcin", "Entrix \u2014 battery optimization", "2026-03-05",
         "Asked about weather/energy forecasts at Entrix, mentioned Flower, Suena, Aire",
         "2026-03-11"],
        ["Rasmus", "Weather/energy forecasts", "2026-03-05",
         "Asked about weather and energy forecast improvement points",
         "2026-03-12"],
    ])

    # Tab 3: No Action Needed
    gws_values_update("No Action Needed!A1:D9", [
        ["Who", "Status", "Last Activity", "Notes"],
        ["Thomas (Kaia)", "Waiting for booking", "2026-03-05",
         "You sent cal.com link, waiting for him to book"],
        ["Lumina / energy trading", "Natural pause", "2026-03-06",
         "You acknowledged their response (\"Got it, sounds interesting!\")"],
        ["Friend (vara-borta-kv\u00e4ll)", "Meeting planned", "2026-03-06",
         "Meeting ~Mar 18, they said they'll send invite"],
        ["Manuel (Artz Energie)", "Email sent", "2026-03-05",
         "You sent email with time suggestions from Mar 18 onwards"],
        ["Mans Skytt", "Done", "2026-03-05",
         "Calendar invite already sent"],
        ["Henrik (Skye)", "Waiting", "2026-03-05",
         "He said he'll get back in a couple of weeks"],
        ["Recruiter", "Skip", "2026-03-06",
         "Headhunter pitch \u2014 not relevant"],
        ["Outsourcing partner", "Skip", "2026-03-05",
         "Generic sales outreach"],
    ])

    print(f"\nDone! Sheet: https://docs.google.com/spreadsheets/d/{SHEET_ID}")


if __name__ == "__main__":
    main()
