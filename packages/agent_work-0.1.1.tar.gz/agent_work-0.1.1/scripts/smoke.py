"""Connectivity smoke test — one read-only call per service."""

from agent_work.integrations import (
    GWS,
    UnipileClient,
    AttioClient,
    ClearFeedClient,
    GitHubClient,
    NotionClient,
)


def main() -> None:
    errors = []

    print("=== Google Workspace (gws CLI) ===")
    try:
        gws = GWS()
        result = gws.calendar_list()
        items = result.get("items", result) if isinstance(result, dict) else result
        print(f"  Calendars: {len(items)} found")
    except Exception as e:
        print(f"  FAILED: {e}")
        errors.append("gws")

    print("\n=== Unipile ===")
    try:
        with UnipileClient() as uni:
            accounts = uni.list_accounts()
            items = accounts.get("items", accounts) if isinstance(accounts, dict) else accounts
            print(f"  Accounts: {len(items)} found")
    except Exception as e:
        print(f"  FAILED: {e}")
        errors.append("unipile")

    print("\n=== Attio CRM ===")
    try:
        with AttioClient() as attio:
            lists = attio.list_lists()
            items = lists.get("data", lists) if isinstance(lists, dict) else lists
            print(f"  Lists: {len(items)} found")
    except Exception as e:
        print(f"  FAILED: {e}")
        errors.append("attio")

    print("\n=== ClearFeed ===")
    try:
        with ClearFeedClient() as cf:
            collections = cf.list_collections()
            items = collections.get("data", collections) if isinstance(collections, dict) else collections
            print(f"  Collections: {len(items)} found")
    except Exception as e:
        print(f"  FAILED: {e}")
        errors.append("clearfeed")

    print("\n=== GitHub ===")
    try:
        with GitHubClient() as gh:
            repos = gh.list_user_repos(per_page=5)
            items = repos if isinstance(repos, list) else repos.get("items", repos)
            print(f"  Repos: {len(items)} found")
    except Exception as e:
        print(f"  FAILED: {e}")
        errors.append("github")

    print("\n=== Notion ===")
    try:
        with NotionClient() as notion:
            result = notion.search("test", page_size=1)
            print(f"  Search: {len(result.get('results', []))} results")
    except Exception as e:
        print(f"  FAILED: {e}")
        errors.append("notion")

    if errors:
        print(f"\nFailed services: {', '.join(errors)}")
        raise SystemExit(1)
    else:
        print("\nAll services connected successfully.")


if __name__ == "__main__":
    main()
