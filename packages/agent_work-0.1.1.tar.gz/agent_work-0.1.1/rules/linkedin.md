# LinkedIn (Unipile) Rules

- Use `UnipileClient` as a context manager: `with UnipileClient() as uni:`
- Returns raw dicts — do not wrap in custom models
- **Never send messages or create posts without explicit user approval**
- `send_message` and `create_post` are write operations — always confirm before calling
- Available read operations: list accounts, list chats, get user profile, search people, list posts
