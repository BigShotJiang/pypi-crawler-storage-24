# Attio CRM Rules

- Use `AttioClient` as a context manager: `with AttioClient() as attio:`
- Returns raw dicts — do not wrap in custom models
- Available operations: list/get people, list/get companies, list lists, list/create notes, list/create tasks
- POST-based query endpoints (`list_people`, `list_companies`) accept `**filters` passed as the `filter` key
- `create_note` requires `parent_object`, `parent_record_id`, `title`, and `content`
