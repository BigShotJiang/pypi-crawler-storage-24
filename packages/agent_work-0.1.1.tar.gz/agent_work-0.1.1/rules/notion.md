# Notion Rules

- Use `NotionClient` as a context manager: `with NotionClient() as notion:`
- Returns raw dicts — do not wrap in custom models
- **Query-only** — do not create, update, or delete pages without explicit user approval
- Available operations: query database, get database, get page, search
- `search` accepts a query string and optional kwargs (e.g., `page_size`)
