# Gmail Rules

- Use the `GWS` class (not a context manager): `gws = GWS()`
- Always pass `userId: "me"` in params for Gmail endpoints
- `gmail_list` automatically injects `userId: "me"`
- For arbitrary Gmail operations, use `gws.raw("gmail", "users", "messages", ...)`
- All methods return raw dicts/lists parsed from JSON CLI output
