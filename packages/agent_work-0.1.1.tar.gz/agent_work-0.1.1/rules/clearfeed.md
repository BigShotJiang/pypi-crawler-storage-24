# ClearFeed Rules

- Use `ClearFeedClient` as a context manager: `with ClearFeedClient() as cf:`
- Returns raw dicts — do not wrap in custom models
- Available operations: list/get/create/update requests, add message to request, list collections, list/get/search customers
- `add_message` requires `html_body` (HTML formatted)
