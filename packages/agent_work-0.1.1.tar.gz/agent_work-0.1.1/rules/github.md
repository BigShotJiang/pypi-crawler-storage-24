# GitHub Rules

- Use `GitHubClient` as a context manager: `with GitHubClient() as gh:`
- **Read-only access** — the client only exposes GET endpoints (repos, issues, PRs, commits, file contents)
- Returns raw dicts/lists — do not wrap in custom models
- `list_user_repos` returns repos for the authenticated user; `list_repos` requires an org name
