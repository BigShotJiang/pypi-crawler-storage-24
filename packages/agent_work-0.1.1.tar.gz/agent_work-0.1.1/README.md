# agent-work

Go-to-market automation toolkit that connects **Google Workspace**, **LinkedIn** (via Unipile), **Attio CRM**, **ClearFeed**, **GitHub**, and **Notion** into agent-driven workflows.

Built to be operated by coding agents (Claude Code, Codex, Gemini CLI, etc.) through natural-language recipes.

## How it works

```
recipes/*.md              Declarative workflow specs (what to do)
agent_work/integrations/  Python clients for each service (how to do it)
rules/*.md                Per-service usage constraints (guardrails)
scripts/                  Standalone utility scripts
```

An agent reads a recipe, calls the service clients, and writes the output to Google Sheets.

## Services

| Client | Service | Transport |
|---|---|---|
| `GWS` | Google Workspace (Gmail, Calendar, Drive, Sheets) | `gws` CLI (subprocess) |
| `UnipileClient` | LinkedIn (messaging, posts, profiles) | REST API via `httpx` |
| `AttioClient` | Attio CRM (people, companies, deals, notes, tasks) | REST API via `httpx` |
| `ClearFeedClient` | ClearFeed (tickets, collections, customers) | REST API via `httpx` |
| `GitHubClient` | GitHub (repos, issues, PRs, commits, file contents) | REST API via `httpx` |
| `NotionClient` | Notion (databases, pages, search) | REST API via `httpx` |

All clients are synchronous and return raw dicts. Unipile, Attio, ClearFeed, GitHub, and Notion are context managers.

## Rules

Per-service usage rules live in `rules/`. Each file documents constraints, required patterns, and approval requirements for its API. Agents should read the relevant rule file before calling a service.

## Recipes

| Recipe | Description |
|---|---|
| [LinkedIn Inbox Triage](recipes/linkedin-inbox-triage.md) | Categorize LinkedIn messages, cross-reference CRM, suggest follow-ups |
| [Calendar Meeting Prep](recipes/calendar-meeting-prep.md) | Prep briefs for upcoming meetings with CRM + LinkedIn context |
| [CRM Pipeline Review](recipes/crm-pipeline-review.md) | Pipeline snapshot — overdue tasks, recent notes, stale contacts |
| [Email Inbox Summary](recipes/email-inbox-summary.md) | Gmail categorization with CRM cross-reference |
| [Daily Report](recipes/daily-report.md) | Daily summary across Email, LinkedIn, ClearFeed, and Notion |

Run any recipe by telling your agent: `Run recipes/<name>.md`

## Setup

```bash
uv sync                # install dependencies
gws auth setup         # authenticate Google Workspace CLI
cp .env.example .env   # add your API keys
```

### Environment variables

| Variable | Required | Service |
|---|---|---|
| `ATTIO_KEY` | yes | Attio CRM |
| `CLEARFEED_API_KEY` | yes | ClearFeed |
| `UNIPILE_DSN` | yes | Unipile |
| `UNIPILE_ACCESS_TOKEN` | yes | Unipile |
| `GITHUB_ACCESS_TOKEN` | yes | GitHub |
| `NOTION_API_KEY` | yes | Notion |
| `SUPABASE_URL` | no | Supabase |
| `SUPABASE_PASSWORD` | no | Supabase |
| `SUPABASE_KEY` | no | Supabase |

## Quick start

```bash
# verify all services are connected
uv run python scripts/smoke.py
```

## Agent compatibility

This repo includes instruction files for multiple coding agents:

| File | Agent |
|---|---|
| `CLAUDE.md` | [Claude Code](https://docs.anthropic.com/en/docs/claude-code) |
| `AGENTS.md` | [OpenAI Codex](https://github.com/openai/codex) |
| `GEMINI.md` | [Gemini CLI](https://github.com/google-gemini/gemini-cli) |

Each file contains the same project context tailored to the agent's expected format.
