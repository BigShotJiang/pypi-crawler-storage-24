# agent-work

Go-to-market automation — Google Workspace, Unipile (LinkedIn), and Attio CRM.

## Setup

```bash
uv sync                # install deps
gws auth setup         # authenticate Google Workspace CLI
```

## Architecture

Six independent service clients in `agent_work/integrations/`:

- **gws.py** — Google Workspace via `gws` CLI (subprocess, JSON output)
- **unipile.py** — Unipile REST API via sync `httpx` (LinkedIn messaging, posts, profiles)
- **attio.py** — Attio CRM REST API via sync `httpx` (people, companies, deals, notes, tasks)
- **clearfeed.py** — ClearFeed REST API via sync `httpx` (tickets, collections, customers)
- **github.py** — GitHub REST API via sync `httpx` (repos, issues, PRs, commits, file contents)
- **notion.py** — Notion REST API via sync `httpx` (databases, pages, search)

Supporting files:

- **agent_work/config.py** — loads `.env`, exports credentials
- **rules/*.md** — API-specific constraints and usage rules (one per service)

All clients are synchronous. Unipile, Attio, ClearFeed, GitHub, and Notion clients are context managers.

Import clients from `agent_work.integrations`:
```python
from agent_work.integrations import GWS, AttioClient, UnipileClient
```

## Conventions

- Type hints on all function signatures
- Return raw dicts from APIs — no custom models
- Never silently catch exceptions
- Use `uv run` to execute scripts (e.g. `uv run python scripts/smoke.py`)

## Environment Variables

| Variable | Required | Service |
|---|---|---|
| `ATTIO_KEY` | yes | Attio CRM |
| `CLEARFEED_API_KEY` | yes | ClearFeed |
| `UNIPILE_DSN` | yes | Unipile |
| `UNIPILE_ACCESS_TOKEN` | yes | Unipile |
| `GITHUB_ACCESS_TOKEN` | yes | GitHub |
| `NOTION_API_KEY` | yes | Notion |
| `SUPABASE_URL` | no | Supabase |
| `SUPABASE_PASSWORD` | no | Supabase |
| `SUPABASE_KEY` | no | Supabase |

## Rules

Per-service usage rules live in `rules/`:

- `rules/attio.md` — Attio CRM client rules
- `rules/clearfeed.md` — ClearFeed client rules
- `rules/github.md` — GitHub client rules (read-only)
- `rules/gmail.md` — Gmail / GWS rules
- `rules/linkedin.md` — LinkedIn / Unipile rules (approval required for writes)
- `rules/notion.md` — Notion rules (query-only by default)

## Recipes

Run any recipe: "Run recipes/<name>.md"

- `linkedin-inbox-triage.md` — LinkedIn message triage + follow-up suggestions
- `calendar-meeting-prep.md` — Meeting prep briefs with CRM + LinkedIn context
- `crm-pipeline-review.md` — CRM pipeline snapshot, overdue tasks, stale contacts
- `email-inbox-summary.md` — Gmail inbox categorization with CRM cross-reference
- `daily-report.md` — Daily summary doc + task sheet across Email, LinkedIn, ClearFeed, and Notion
