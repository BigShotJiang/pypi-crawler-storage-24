from __future__ import annotations

import httpx

from agent_work.config import GITHUB_ACCESS_TOKEN


class GitHubClient:
    """Sync REST client for the GitHub API (read-only)."""

    def __init__(self, token: str = GITHUB_ACCESS_TOKEN) -> None:
        self._client = httpx.Client(
            base_url="https://api.github.com",
            headers={
                "Authorization": f"Bearer {token}",
                "Accept": "application/vnd.github+json",
                "X-GitHub-Api-Version": "2022-11-28",
            },
            timeout=30,
        )

    def __enter__(self) -> GitHubClient:
        return self

    def __exit__(self, *exc) -> None:
        self.close()

    def close(self) -> None:
        self._client.close()

    def request(self, method: str, path: str, **kwargs) -> dict | list:
        resp = self._client.request(method, path, **kwargs)
        resp.raise_for_status()
        return resp.json()

    # --- Repos ---

    def list_repos(self, org: str, **params) -> list:
        return self.request("GET", f"/orgs/{org}/repos", params=params)

    def list_user_repos(self, **params) -> list:
        return self.request("GET", "/user/repos", params=params)

    def get_repo(self, owner: str, repo: str) -> dict:
        return self.request("GET", f"/repos/{owner}/{repo}")

    def search_repos(self, query: str, **params) -> dict:
        return self.request("GET", "/search/repositories", params={"q": query, **params})

    # --- Issues ---

    def list_issues(self, owner: str, repo: str, **params) -> list:
        return self.request("GET", f"/repos/{owner}/{repo}/issues", params=params)

    # --- Pull Requests ---

    def list_pulls(self, owner: str, repo: str, **params) -> list:
        return self.request("GET", f"/repos/{owner}/{repo}/pulls", params=params)

    def get_pull(self, owner: str, repo: str, number: int) -> dict:
        return self.request("GET", f"/repos/{owner}/{repo}/pulls/{number}")

    # --- Commits ---

    def list_commits(self, owner: str, repo: str, **params) -> list:
        return self.request("GET", f"/repos/{owner}/{repo}/commits", params=params)

    # --- Contents ---

    def get_file(self, owner: str, repo: str, path: str, **params) -> dict:
        return self.request("GET", f"/repos/{owner}/{repo}/contents/{path}", params=params)

    def get_readme(self, owner: str, repo: str) -> dict:
        return self.request("GET", f"/repos/{owner}/{repo}/readme")
