from __future__ import annotations

import httpx

from agent_work.config import NOTION_API_KEY


class NotionClient:
    """Sync REST client for the Notion API."""

    def __init__(self, api_key: str = NOTION_API_KEY) -> None:
        self._client = httpx.Client(
            base_url="https://api.notion.com/v1",
            headers={
                "Authorization": f"Bearer {api_key}",
                "Notion-Version": "2022-06-28",
            },
            timeout=30,
        )

    def __enter__(self) -> NotionClient:
        return self

    def __exit__(self, *exc) -> None:
        self.close()

    def close(self) -> None:
        self._client.close()

    def request(self, method: str, path: str, **kwargs) -> dict:
        resp = self._client.request(method, path, **kwargs)
        resp.raise_for_status()
        return resp.json()

    def query_database(self, database_id: str, **kwargs) -> dict:
        return self.request("POST", f"/databases/{database_id}/query", json=kwargs if kwargs else {})

    def get_database(self, database_id: str) -> dict:
        return self.request("GET", f"/databases/{database_id}")

    def get_page(self, page_id: str) -> dict:
        return self.request("GET", f"/pages/{page_id}")

    def search(self, query: str, **kwargs) -> dict:
        body: dict = {"query": query, **kwargs}
        return self.request("POST", "/search", json=body)
