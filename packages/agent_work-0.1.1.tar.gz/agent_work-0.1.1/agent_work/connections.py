"""Connection registry — pure data, no side effects."""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class Credential:
    env_var: str
    prompt: str
    secret: bool = True


@dataclass(frozen=True)
class Connection:
    name: str
    description: str
    credentials: tuple[Credential, ...]
    setup_hint: str | None = None


CONNECTIONS: dict[str, Connection] = {
    "gws": Connection(
        name="gws",
        description="Google Workspace via gws CLI",
        credentials=(),
        setup_hint="Run: gws auth setup",
    ),
    "attio": Connection(
        name="attio",
        description="Attio CRM",
        credentials=(
            Credential(env_var="ATTIO_KEY", prompt="Attio API key"),
        ),
    ),
    "unipile": Connection(
        name="unipile",
        description="Unipile (LinkedIn messaging & posts)",
        credentials=(
            Credential(env_var="UNIPILE_DSN", prompt="Unipile DSN", secret=False),
            Credential(env_var="UNIPILE_ACCESS_TOKEN", prompt="Unipile access token"),
        ),
    ),
    "clearfeed": Connection(
        name="clearfeed",
        description="ClearFeed",
        credentials=(
            Credential(env_var="CLEARFEED_API_KEY", prompt="ClearFeed API key"),
        ),
    ),
    "github": Connection(
        name="github",
        description="GitHub",
        credentials=(
            Credential(env_var="GITHUB_ACCESS_TOKEN", prompt="GitHub access token"),
        ),
    ),
    "notion": Connection(
        name="notion",
        description="Notion",
        credentials=(
            Credential(env_var="NOTION_API_KEY", prompt="Notion API key"),
        ),
    ),
}
