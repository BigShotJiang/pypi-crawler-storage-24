"""CLI entry point — `aw` command. Never imports config.py or integrations/."""

from __future__ import annotations

import subprocess
import sys
from pathlib import Path
from typing import Annotated, Optional

import typer

from agent_work.connections import CONNECTIONS

app = typer.Typer(name="aw", no_args_is_help=True)
add_app = typer.Typer(name="add", no_args_is_help=True)
app.add_typer(add_app, name="add", help="Add a resource.")


REPO_URL = "git@github.com:rebase-energy/agent-work.git"


@app.command()
def init(
    name: Annotated[
        Optional[str],
        typer.Argument(help="Directory name for the clone."),
    ] = None,
) -> None:
    """Clone the agent-work repo and bootstrap the project."""
    target = name or "agent-work"
    target_path = Path.cwd() / target

    if target_path.exists():
        typer.echo(f"Error: '{target}' already exists.", err=True)
        raise typer.Exit(code=1)

    # Clone
    typer.echo(f"Cloning into {target}/...")
    subprocess.run(["git", "clone", REPO_URL, target], check=True)

    # uv sync
    typer.echo("Installing dependencies...")
    subprocess.run(["uv", "sync"], cwd=target_path, check=True)

    # Create empty .env
    env_file = target_path / ".env"
    if not env_file.exists():
        env_file.touch()
        typer.echo("Created .env")

    typer.echo(f"Done! cd {target} to get started.")


def _read_env(path: Path) -> dict[str, str]:
    """Read a .env file into a dict (simple key=value parser)."""
    env: dict[str, str] = {}
    if not path.exists():
        return env
    for line in path.read_text().splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        if "=" in line:
            key, _, value = line.partition("=")
            env[key.strip()] = value.strip()
    return env


def _append_env(path: Path, key: str, value: str) -> None:
    """Append a key=value line to a .env file."""
    with path.open("a") as f:
        f.write(f"{key}={value}\n")


@add_app.command("connection")
def add_connection(
    name: Annotated[
        Optional[str],
        typer.Argument(help="Connection name (e.g. attio, github)."),
    ] = None,
) -> None:
    """Configure credentials for a connection."""
    valid_names = ", ".join(sorted(CONNECTIONS))

    if name is None:
        typer.echo(f"Available connections: {valid_names}")
        raise typer.Exit()

    if name not in CONNECTIONS:
        typer.echo(f"Unknown connection: '{name}'", err=True)
        typer.echo(f"Valid options: {valid_names}", err=True)
        raise typer.Exit(code=1)

    conn = CONNECTIONS[name]

    # Special case: no credentials, just a setup hint
    if not conn.credentials:
        if conn.setup_hint:
            typer.echo(conn.setup_hint)
        else:
            typer.echo(f"{conn.name}: no credentials needed.")
        raise typer.Exit()

    env_path = Path.cwd() / ".env"
    existing = _read_env(env_path)

    for cred in conn.credentials:
        if cred.env_var in existing:
            typer.echo(f"{cred.env_var} already set — skipping.")
            continue

        value = typer.prompt(cred.prompt, hide_input=cred.secret)
        _append_env(env_path, cred.env_var, value)
        typer.echo(f"Saved {cred.env_var}")

    typer.echo(f"Connection '{name}' configured.")
