"""Murmel API client."""

from __future__ import annotations

from pathlib import Path
from typing import BinaryIO

import httpx

from murmel.exceptions import MurmelError, _raise_for_error
from murmel.models import (
    Language,
    Transcription,
    TranscriptionListItem,
    TranscriptionStatus,
    Usage,
)

_DEFAULT_BASE_URL = "https://api.murmel.eu"
_DEFAULT_TIMEOUT = 600  # 10 minutes (synchronous transcription can be slow)


class _Transcriptions:
    """Namespace for transcription-related methods."""

    def __init__(self, client: Murmel):
        self._client = client

    def list(
        self,
        *,
        limit: int = 50,
        status: str | None = None,
    ) -> list[TranscriptionListItem]:
        """List your transcription jobs.

        Args:
            limit: Maximum number of results (max 200).
            status: Filter by status: pending, processing, completed, failed.

        Returns:
            List of transcription summaries, newest first.
        """
        params: dict = {"limit": limit}
        if status:
            params["status"] = status

        data = self._client._get("/v1/transcriptions", params=params)
        return [TranscriptionListItem.model_validate(item) for item in data]

    def get(self, transcription_id: str) -> Transcription:
        """Get a transcription result by ID.

        Args:
            transcription_id: The transcription job ID.

        Returns:
            Full transcription with text and segments.
        """
        data = self._client._get(f"/v1/transcriptions/{transcription_id}")
        return Transcription.model_validate(data)

    def status(self, transcription_id: str) -> TranscriptionStatus:
        """Check transcription status (lightweight).

        Args:
            transcription_id: The transcription job ID.

        Returns:
            Status object with job_id, status, and timestamps.
        """
        data = self._client._get(f"/v1/transcriptions/{transcription_id}/status")
        return TranscriptionStatus.model_validate(data)


class Murmel:
    """Client for the Murmel Speech-to-Text API.

    Usage::

        from murmel import Murmel

        client = Murmel(api_key="murmel_sk_...")

        # Transcribe a file
        result = client.transcribe("meeting.mp3", language="nl")
        print(result.text)

        # Check usage
        usage = client.usage()
        print(f"{usage.remaining_minutes} minutes left")

    Args:
        api_key: Your Murmel API key (starts with ``murmel_sk_``).
        base_url: API base URL. Defaults to ``https://api.murmel.eu``.
        timeout: Request timeout in seconds. Defaults to 600 (10 min)
            to accommodate synchronous transcription.
    """

    def __init__(
        self,
        api_key: str,
        *,
        base_url: str = _DEFAULT_BASE_URL,
        timeout: float = _DEFAULT_TIMEOUT,
    ):
        if not api_key:
            raise MurmelError("API key is required. Get one at https://app.murmel.eu")

        self._api_key = api_key
        self._base_url = base_url.rstrip("/")
        self._timeout = timeout
        self._client = httpx.Client(
            base_url=self._base_url,
            headers={"X-API-Key": self._api_key},
            timeout=self._timeout,
        )
        self.transcriptions = _Transcriptions(self)

    def transcribe(
        self,
        audio: str | Path | BinaryIO,
        *,
        language: str = "nl",
    ) -> Transcription:
        """Transcribe an audio file.

        This method blocks until the transcription is complete (up to 10 min).

        Args:
            audio: Path to an audio file, or a file-like object.
                Supports WAV, MP3, M4A, WEBM, OGG, FLAC, and more.
            language: Language code. Currently only ``"nl"`` (Dutch) is
                supported. Defaults to ``"nl"``.

        Returns:
            A :class:`Transcription` with the full text and segments.

        Raises:
            AuthenticationError: Invalid or missing API key.
            InvalidRequestError: Unsupported language, file too large, etc.
            RateLimitError: Monthly usage limit exceeded.
            ServerError: Transcription processing failed.
            TimeoutError: Transcription didn't complete in time.

        Example::

            result = client.transcribe("interview.mp3", language="nl")
            print(result.text)

            for segment in result.segments:
                print(f"[{segment.start:.1f}s] {segment.text}")
        """
        # Build multipart upload
        if isinstance(audio, (str, Path)):
            audio_path = Path(audio)
            if not audio_path.exists():
                raise FileNotFoundError(f"Audio file not found: {audio_path}")
            file_obj = open(audio_path, "rb")
            filename = audio_path.name
            should_close = True
        else:
            file_obj = audio
            filename = getattr(audio, "name", "audio.wav")
            if isinstance(filename, str) and "/" in filename:
                filename = filename.rsplit("/", 1)[-1]
            should_close = False

        try:
            response = self._client.post(
                "/v1/transcribe",
                files={"audio": (filename, file_obj)},
                params={"language": language},
            )
        finally:
            if should_close:
                file_obj.close()

        if response.status_code != 200:
            _raise_for_error(response.status_code, response.json())

        return Transcription.model_validate(response.json())

    def usage(self) -> Usage:
        """Get your current month's usage statistics.

        Returns:
            A :class:`Usage` object with plan, used/remaining minutes.

        Example::

            usage = client.usage()
            print(f"Plan: {usage.plan}")
            print(f"Used: {usage.used_minutes:.1f} / {usage.limit_minutes:.0f} min")
        """
        data = self._get("/v1/usage")
        return Usage.model_validate(data)

    def languages(self) -> list[Language]:
        """List supported transcription languages.

        Returns:
            List of :class:`Language` objects with code and name.
        """
        # This endpoint doesn't require auth, but we send it anyway
        data = self._get("/v1/languages")
        return [Language.model_validate(lang) for lang in data]

    def _get(self, path: str, *, params: dict | None = None) -> dict | list:
        """Make an authenticated GET request."""
        response = self._client.get(path, params=params)
        if response.status_code != 200:
            _raise_for_error(response.status_code, response.json())
        return response.json()

    def close(self) -> None:
        """Close the underlying HTTP client."""
        self._client.close()

    def __enter__(self) -> Murmel:
        return self

    def __exit__(self, *args) -> None:
        self.close()

    def __repr__(self) -> str:
        return f"Murmel(base_url={self._base_url!r})"
