"""Murmel API exception classes."""


class MurmelError(Exception):
    """Base exception for all Murmel API errors.

    Attributes:
        status: HTTP status code.
        type: Error category (e.g. 'authentication_error').
        code: Machine-readable error code (e.g. 'invalid_api_key').
        message: Human-readable error message.
    """

    def __init__(
        self,
        message: str,
        *,
        status: int | None = None,
        error_type: str | None = None,
        code: str | None = None,
    ):
        super().__init__(message)
        self.status = status
        self.type = error_type
        self.code = code
        self.message = message

    def __repr__(self) -> str:
        return f"{self.__class__.__name__}(status={self.status}, code={self.code!r}, message={self.message!r})"


class AuthenticationError(MurmelError):
    """Raised for 401 errors — invalid or missing API key."""
    pass


class PermissionDeniedError(MurmelError):
    """Raised for 403 errors — account inactive, email not verified."""
    pass


class InvalidRequestError(MurmelError):
    """Raised for 400/413 errors — bad input, unsupported language, file too large."""
    pass


class NotFoundError(MurmelError):
    """Raised for 404 errors — resource not found."""
    pass


class RateLimitError(MurmelError):
    """Raised for 429 errors — usage limit exceeded."""
    pass


class ServerError(MurmelError):
    """Raised for 500/504 errors — transcription failed, timeout."""
    pass


class TimeoutError(MurmelError):
    """Raised when transcription takes too long (504)."""
    pass


# Map API error types to exception classes
_ERROR_TYPE_MAP: dict[str, type[MurmelError]] = {
    "authentication_error": AuthenticationError,
    "permission_denied": PermissionDeniedError,
    "invalid_request": InvalidRequestError,
    "not_found": NotFoundError,
    "rate_limit_exceeded": RateLimitError,
    "server_error": ServerError,
}


def _raise_for_error(status_code: int, body: dict) -> None:
    """Parse an error response body and raise the appropriate exception."""
    detail = body.get("detail", {})

    # Handle structured v1 errors
    if isinstance(detail, dict):
        error_type = detail.get("type", "")
        code = detail.get("code", "")
        message = detail.get("message", "Unknown error")

        exc_class = _ERROR_TYPE_MAP.get(error_type, MurmelError)

        # Special-case timeout
        if code == "timeout":
            exc_class = TimeoutError

        raise exc_class(
            message,
            status=status_code,
            error_type=error_type,
            code=code,
        )

    # Fallback for non-structured errors
    message = detail if isinstance(detail, str) else str(body)
    raise MurmelError(message, status=status_code)
