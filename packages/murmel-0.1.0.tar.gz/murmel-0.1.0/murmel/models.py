"""Pydantic models for Murmel API responses."""

from __future__ import annotations

from datetime import datetime
from typing import Any, Optional

from pydantic import BaseModel, Field


class TranscriptionSegment(BaseModel):
    """A timestamped segment of the transcription."""

    start: float = Field(description="Start time in seconds")
    end: float = Field(description="End time in seconds")
    text: str = Field(description="Transcribed text for this segment")
    words: Optional[list[Any]] = Field(
        default=None, description="Word-level timestamps (if available)"
    )


class Transcription(BaseModel):
    """A transcription result."""

    id: str = Field(description="Unique transcription ID")
    status: str = Field(
        description="Job status: pending, processing, completed, failed"
    )
    text: str = Field(default="", description="Full transcript text")
    segments: Optional[list[TranscriptionSegment]] = Field(
        default=None, description="Timestamped segments"
    )
    language: str = Field(description="Language code used")
    duration_seconds: Optional[float] = Field(
        default=None, description="Audio duration in seconds"
    )
    processing_seconds: Optional[float] = Field(
        default=None, description="Processing time in seconds"
    )
    error: Optional[str] = Field(
        default=None, description="Error message if failed"
    )
    created_at: datetime

    def __repr__(self) -> str:
        return f"Transcription(id={self.id!r}, status={self.status!r}, language={self.language!r})"


class TranscriptionListItem(BaseModel):
    """Summary item from the transcription list."""

    id: str
    name: Optional[str] = None
    status: str
    language: str
    duration_seconds: Optional[float] = None
    created_at: datetime
    completed_at: Optional[datetime] = None

    def __repr__(self) -> str:
        return f"TranscriptionListItem(id={self.id!r}, status={self.status!r})"


class TranscriptionStatus(BaseModel):
    """Lightweight status response."""

    job_id: str
    status: str
    created_at: Optional[str] = None
    completed_at: Optional[str] = None


class Usage(BaseModel):
    """Usage statistics for the current billing period."""

    plan: str = Field(description="Current subscription plan")
    used_minutes: float = Field(description="Minutes used this month")
    limit_minutes: float = Field(description="Total minutes available")
    remaining_minutes: float = Field(description="Minutes remaining")

    def __repr__(self) -> str:
        return f"Usage(plan={self.plan!r}, used={self.used_minutes:.1f}/{self.limit_minutes:.0f} min)"


class Language(BaseModel):
    """A supported transcription language."""

    code: str = Field(description="ISO language code")
    name: str = Field(description="Language name")

    def __repr__(self) -> str:
        return f"Language(code={self.code!r}, name={self.name!r})"
