"""Murmel — Python SDK for the Murmel Speech-to-Text API."""

from murmel.client import Murmel
from murmel.exceptions import (
    MurmelError,
    AuthenticationError,
    PermissionDeniedError,
    NotFoundError,
    InvalidRequestError,
    RateLimitError,
    ServerError,
    TimeoutError,
)

__all__ = [
    "Murmel",
    "MurmelError",
    "AuthenticationError",
    "PermissionDeniedError",
    "NotFoundError",
    "InvalidRequestError",
    "RateLimitError",
    "ServerError",
    "TimeoutError",
]

__version__ = "0.1.0"
