"""Navigation mixin — navigation, toggle, and switching helpers for App."""

import time
from pathlib import Path

from jot.categories.manager import CategoryManager
from jot.commands import CommandHandler
from jot.core.constants import MODE_QUICK_ADD
from jot.core.task_manager import TaskManager
from jot.ui.styles import RESET, CYAN
from jot.utils.date_utils import get_today_day_name


class AppNavigationMixin:
    """Navigation, toggle, and category/project switching for App."""

    def _handle_navigation(self, key, tasks_to_display):
        """Process UP/DOWN/SHIFT_UP/SHIFT_DOWN.  Returns True if
        the key was a navigation key."""
        st = self.state
        filtered = (
            tasks_to_display
            if st.show_today_only or st.collapsed_parents
            else None)

        if key == 'UP':
            self.task_manager.set_prev_current(filtered)
            return True
        if key == 'DOWN':
            self.task_manager.set_next_current(filtered)
            return True
        if key == 'SHIFT_UP':
            self.task_manager.move_task_up()
            return True
        if key == 'SHIFT_DOWN':
            self.task_manager.move_task_down()
            return True
        return False

    def _handle_toggle(self, key):
        """Process shared toggle keys A/O/Y/F/?.  Returns True if
        the key was a toggle key."""
        st = self.state

        toggle_map = {
            'A': ('show_archived', 'archived tasks'),
            'O': ('sort_by_day', None),
            'Y': ('show_today_only', None),
            'F': ('show_notes_inline', 'inline notes'),
            '?': ('show_shortcuts', 'shortcuts'),
        }

        if key not in toggle_map:
            return False

        attr, label = toggle_map[key]

        if key == 'O':
            st.sort_by_day = not st.sort_by_day
            msg = "Sorting by day" if st.sort_by_day else "Normal order"
        elif key == 'Y':
            st.show_today_only = not st.show_today_only
            today = get_today_day_name()
            msg = (f"Showing only {today} tasks"
                   if st.show_today_only else "Showing all tasks")
        else:
            current = getattr(st, attr)
            setattr(st, attr, not current)
            new_val = not current
            status = "Showing" if new_val else "Hiding"
            msg = f"{status} {label}"

        print(f"\n{CYAN}\u2713 {msg}{RESET}")
        time.sleep(0.3)
        st.input_buffer = ""
        return True

    def _reload_task_manager(self, task_manager):
        """Replace the active TaskManager and CommandHandler."""
        import os
        self.task_manager = task_manager
        self.command_handler = CommandHandler(
            task_manager, registry=self.registry)
        self._last_mtime = (
            os.path.getmtime(task_manager.storage_file)
            if task_manager.storage_file.exists() else 0)

    def _handle_switch_category(self):
        """Shift+C — switch category via picker."""
        result = self.command_handler.switch_category()
        if isinstance(result, tuple) and result[0] == 'switch_category':
            _, new_category, new_is_global = result
            if new_is_global:
                tm = TaskManager(
                    category=new_category, is_global=True,
                    project_registry=self.registry)
            else:
                tm = TaskManager(
                    directory=self.target_dir, category=new_category,
                    is_global=False, project_registry=self.registry)
            self._reload_task_manager(tm)
            print(f"\u2713 Switched to category: "
                  f"{new_category or 'default'}")
            print("\nPress Enter to continue...", end='', flush=True)
            input()
        self.state.input_buffer = ""

    def _handle_switch_project(self):
        """Shift+Z — switch project via picker."""
        result = self.command_handler.switch_project()
        if isinstance(result, tuple) and result[0] == 'switch_project':
            _, proj_name, project_path = result
            self.target_dir = project_path
            self.project_name = proj_name
            tm = TaskManager(
                directory=self.target_dir, category=None,
                is_global=False, project_registry=self.registry)
            self._reload_task_manager(tm)
            print(f"\u2713 Switched to project: {proj_name}")
            print("\nPress Enter to continue...", end='', flush=True)
            input()
        self.state.input_buffer = ""

    def _handle_tab_cycle(self):
        """Tab — cycle through categories in the project."""
        cat_manager = CategoryManager(project_dir=self.target_dir)
        categories = cat_manager.discover_categories()
        if not categories:
            self.state.input_buffer = ""
            return

        current_cat = self.task_manager.category
        if current_cat is None:
            next_cat = categories[0]
        else:
            try:
                idx = categories.index(current_cat)
                next_cat = (
                    categories[idx + 1]
                    if idx + 1 < len(categories) else None)
            except ValueError:
                next_cat = categories[0]

        tm = TaskManager(
            directory=self.target_dir, category=next_cat,
            is_global=False, project_registry=self.registry)
        self._reload_task_manager(tm)
        label = next_cat if next_cat else "default"
        print(f"\n{CYAN}\u2192 {label}{RESET}")
        time.sleep(0.2)
        self.state.input_buffer = ""
