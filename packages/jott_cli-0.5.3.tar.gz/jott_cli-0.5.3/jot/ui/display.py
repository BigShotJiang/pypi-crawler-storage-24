"""Display functions for task list UI — re-export facade."""

from jot.ui.display_tasks import display_tasks
from jot.ui.display_projects import display_all_projects, display_category_stats
from jot.ui.display_archive import display_archive, display_all_categories_view
from jot.ui.display_help import display_help, display_categorized_shortcuts

__all__ = [
    'display_all_categories_view',
    'display_all_projects',
    'display_archive',
    'display_category_stats',
    'display_categorized_shortcuts',
    'display_help',
    'display_tasks',
]
