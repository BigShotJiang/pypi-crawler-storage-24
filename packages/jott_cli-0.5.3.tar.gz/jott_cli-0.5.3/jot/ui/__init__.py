"""UI components for jot task list display"""

from jot.ui.display import (
    display_all_categories_view,
    display_all_projects,
    display_archive,
    display_category_stats,
    display_categorized_shortcuts,
    display_help,
    display_tasks,
)
from jot.ui.formatting import format_category_badges, format_inline_notes
from jot.ui.picker import PickerItem, PickerResult, fuzzy_picker, quick_picker
from jot.ui.styles import (
    RESET, BOLD, DIM, REVERSE,
    RED, GREEN, YELLOW, BLUE, MAGENTA, CYAN, WHITE, GRAY, ORANGE, BLACK,
    PRIORITY_COLORS, PRIORITY_SYMBOLS, STATUS_COLORS, STATUS_SYMBOLS,
    ARCHIVE_SYMBOL, ARCHIVE_COLOR,
    BG_YELLOW, BG_ORANGE, BG_MAGENTA, BG_GRAY,
    HIGHLIGHT_COLORS, HIGHLIGHT_DEFAULT, HIGHLIGHT_FMT,
    get_terminal_width, strip_ansi, visible_len,
)

__all__ = [
    'display_all_categories_view',
    'display_all_projects',
    'display_archive',
    'display_category_stats',
    'display_categorized_shortcuts',
    'display_help',
    'display_tasks',
    'format_category_badges',
    'format_inline_notes',
    # Style constants
    'RESET', 'BOLD', 'DIM', 'REVERSE',
    'RED', 'GREEN', 'YELLOW', 'BLUE', 'MAGENTA', 'CYAN', 'WHITE', 'GRAY', 'ORANGE', 'BLACK',
    'PRIORITY_COLORS', 'PRIORITY_SYMBOLS', 'STATUS_COLORS', 'STATUS_SYMBOLS',
    'ARCHIVE_SYMBOL', 'ARCHIVE_COLOR',
    'BG_YELLOW', 'HIGHLIGHT_COLORS', 'HIGHLIGHT_DEFAULT', 'HIGHLIGHT_FMT',
    'get_terminal_width', 'strip_ansi', 'visible_len',
    # Picker
    'PickerItem', 'PickerResult', 'fuzzy_picker', 'quick_picker',
]
