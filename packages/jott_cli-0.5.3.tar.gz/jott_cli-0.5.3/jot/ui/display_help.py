"""Display functions for help and keyboard shortcuts."""

from jot.ui.styles import RESET, BOLD, DIM, CYAN, GREEN, YELLOW, get_terminal_width


def display_categorized_shortcuts():
    """Display keyboard shortcuts organized by category."""
    shortcuts = {
        "Navigation": [
            ("↑/↓", "Navigate tasks"),
            ("Tab", "Cycle through categories"),
            ("Ctrl+F", "Fuzzy search tasks"),
            ("Shift+Z", "Switch project"),
            ("Shift+C", "Switch category"),
            ("Shift+L", "Toggle all categories view"),
        ],
        "Task Management": [
            ("Enter", "Add task"),
            ("Ctrl+E", "Edit current task"),
            ("c", "Mark current task"),
            ("d", "Delete task"),
            ("t", "Toggle task done"),
            ("a", "Archive task"),
            ("Shift+A", "Toggle archive view"),
            ("m", "Move to different category"),
            ("Shift+M", "Move task to another project"),
            ("Ctrl+K", "Copy task to another project"),
            ("Ctrl+T", "Transfer to category"),
            ("Ctrl+↑/↓", "Reorder tasks"),
            ("=", "Sort by priority"),
        ],
        "Task Details": [
            ("n", "Add/edit notes"),
            ("Shift+N", "Edit task notes"),
            ("Shift+F", "Toggle inline notes display"),
            ("p", "Toggle priority cycle"),
            ("Shift+H", "Set priority to high"),
            ("=", "Sort by priority"),
            ("Shift+X", "Set task status"),
            ("Shift+W", "Assign day to task"),
            ("Shift+O", "Toggle day sorting"),
            ("Shift+Y", "Toggle today filter"),
            ("Shift+D", "Mark current as done"),
            ("Shift+J", "Mark as agent task"),
            ("*", "Highlight color picker"),
            ("~", "Quick highlight toggle"),
            ("Ctrl+L", "Assign parent (link subtask)"),
        ],
        "Multi-Select Mode": [
            ("Shift+V", "Enter multi-select mode"),
            ("Space", "Toggle task selection"),
            ("Shift+↑/↓", "Select while moving"),
            ("A", "Select all tasks"),
            ("N", "Select none"),
            ("B", "Bulk actions menu"),
            ("Esc", "Exit multi-select"),
        ],
        "Bulk Operations": [
            ("Shift+B", "Bulk actions / Priority timer"),
        ],
        "Analysis & Export": [
            ("Shift+0", "Execute analysis plan"),
            ("Shift+1", "Fix duplicate task IDs"),
            ("Shift+4", "AI task suggestion"),
            ("Shift+E", "Execute keyword action"),
            ("Shift+G", "Google Calendar setup"),
            ("Shift+I", "Import from Google Calendar"),
            ("Shift+K", "Copy task to clipboard"),
            ("Ctrl+U", "Open URLs in task"),
        ],
        "System": [
            ("h/?", "Show this help"),
            ("r", "Refresh display"),
            ("Ctrl+R", "Register current project"),
            ("q", "Quit"),
            ("Ctrl+X", "Quit"),
            ("Esc", "Exit mode / Quit"),
        ],
        "Fuzzy Search": [
            ("Ctrl+A", "Toggle archived tasks in search"),
        ],
    }

    w = get_terminal_width()
    print(f"\n{BOLD}Keyboard Shortcuts{RESET}")
    print("=" * w)

    for category, items in shortcuts.items():
        print(f"\n{CYAN}{category}:{RESET}")
        for key, description in items:
            print(f"  {YELLOW}{key:15}{RESET} {description}")

    print("\n" + "=" * w + "\n")


def display_help():
    """Display comprehensive help information."""
    help_text = f"""
{BOLD}Jott - Simple Interactive Task List{RESET}
{DIM}Version 0.5.2{RESET}

{BOLD}BASIC USAGE:{RESET}
  jott                      Start interactive task manager (current project)
  jott -c <category>        Start in specific category
  jott --category <cat>     Start in specific category (long form)
  jott --global             Start with global tasks
  jott -h / --help          Show this help message

{BOLD}PROJECT MANAGEMENT:{RESET}
  jott --all-projects       Show tasks from all registered projects
  jott --list-projects      List all registered projects
  jott --register <name> <path>   Register a new project
  jott --unregister <name>  Remove project from registry
  jott --refresh            Refresh project registry (auto-discover)
  jott --fix-duplicates     Fix duplicate task IDs in current directory

{BOLD}NAVIGATION:{RESET}
  {CYAN}↑/↓{RESET}              Navigate through tasks
  {CYAN}Tab{RESET}              Cycle through categories
  {CYAN}Ctrl+F{RESET}           Fuzzy search tasks
  {CYAN}Shift+Z{RESET}          Switch between projects
  {CYAN}Shift+C{RESET}          Switch between categories
  {CYAN}Shift+L{RESET}          Toggle all categories view

{BOLD}TASK MANAGEMENT:{RESET}
  {CYAN}Type + Enter{RESET}     Add new task
  {CYAN}Ctrl+E{RESET}           Edit current task text
  {CYAN}c{RESET}                Mark task as current
  {CYAN}d{RESET}                Delete selected task
  {CYAN}t{RESET}                Toggle task done/undone
  {CYAN}a{RESET}                Archive task (mark as done/canceled)
  {CYAN}Shift+A{RESET}          Toggle archive view
  {CYAN}m{RESET}                Move task to different category
  {CYAN}Shift+M{RESET}          Move task to another project
  {CYAN}Ctrl+K{RESET}           Copy task to another project
  {CYAN}Ctrl+T{RESET}           Transfer task to category
  {CYAN}Ctrl+↑/↓{RESET}         Reorder tasks
  {CYAN}={RESET}                Sort by priority

{BOLD}TASK DETAILS:{RESET}
  {CYAN}n{RESET}                Add/edit task notes (opens editor)
  {CYAN}Shift+N{RESET}          Edit task notes (multi-select: select none)
  {CYAN}Shift+F{RESET}          Toggle inline notes display
  {CYAN}p{RESET}                Toggle task priority cycle
  {CYAN}Shift+H{RESET}          Set priority to high
  {CYAN}Shift+X{RESET}          Set task status (todo/in-progress/blocked/done)
  {CYAN}Shift+W{RESET}          Assign day to task
  {CYAN}Shift+O{RESET}          Toggle day sorting
  {CYAN}Shift+Y{RESET}          Toggle today filter
  {CYAN}Shift+D{RESET}          Mark current task as done
  {CYAN}Shift+J{RESET}          Mark task for agent/AI assistance
  {CYAN}*{RESET}                Highlight color picker (6 colors)
  {CYAN}~{RESET}                Quick highlight toggle (default color)
  {CYAN}Ctrl+L{RESET}           Assign parent task (subtask link)
  {CYAN}Shift+E{RESET}          Execute keyword action for task

{BOLD}MULTI-SELECT MODE:{RESET}
  {CYAN}Shift+V{RESET}          Enter multi-select mode
  {CYAN}Space{RESET}            Toggle task selection
  {CYAN}Shift+↑/↓{RESET}        Select while moving
  {CYAN}A{RESET}                Select all tasks
  {CYAN}N{RESET}                Select none
  {CYAN}B{RESET}                Bulk actions menu
  {CYAN}Esc{RESET}              Exit multi-select mode

{BOLD}BULK OPERATIONS:{RESET}
  {CYAN}Shift+B{RESET}          Bulk actions menu / Priority timer

{BOLD}KEYWORDS:{RESET}
  Keywords trigger automatic actions when added to task text:

  {YELLOW}bullet:{RESET} task    Start bullet priority timer
  {YELLOW}gcal:{RESET} task      Export to Google Calendar
  {YELLOW}ai:{RESET} task        Mark for AI/agent assistance
  {YELLOW}analyze:{RESET} task   Create analysis plan with Claude Code
  {YELLOW}remind:{RESET} task    Set system notification (Shift+E)

  Configure keywords in ~/.jot-keywords.json

{BOLD}CATEGORIES:{RESET}
  Categories organize tasks within projects:
  • Local categories: Project-specific (max 10 per project)
  • Global categories: Cross-project tasks (max 10 global)
  • Default: Tasks without a category

  {CYAN}jott -c backend{RESET}  Start in "backend" category
  {CYAN}Tab{RESET}              Cycle through categories
  {CYAN}Shift+C{RESET}          Create/switch categories interactively
  {CYAN}m{RESET}                Move task between categories

{BOLD}PROJECTS:{RESET}
  Multi-project support with auto-discovery:
  • Auto-discovers projects in ~/projects/
  • Each project has its own .jot.json
  • Switch projects with {CYAN}Shift+Z{RESET} or {CYAN}jott -p <name>{RESET}

{BOLD}ANALYSIS & EXPORT:{RESET}
  {CYAN}Shift+0{RESET}          Execute analysis plan (if exists)
  {CYAN}Shift+1{RESET}          Fix duplicate task IDs
  {CYAN}Shift+4{RESET}          AI task suggestion
  {CYAN}Shift+E{RESET}          Execute keyword action for task
  {CYAN}Shift+G{RESET}          Set up Google Calendar integration
  {CYAN}Shift+I{RESET}          Import tasks from Google Calendar
  {CYAN}Shift+K{RESET}          Copy task text to clipboard
  {CYAN}Ctrl+U{RESET}           Open URLs found in task text

{BOLD}FUZZY SEARCH:{RESET}
  {CYAN}Ctrl+F{RESET}           Enter fuzzy search mode
  {CYAN}Ctrl+A{RESET}           Toggle archived tasks in search results
  {CYAN}↑/↓{RESET}              Navigate results
  {CYAN}Enter{RESET}            Select task
  {CYAN}Esc{RESET}              Exit search

{BOLD}SYSTEM:{RESET}
  {CYAN}h or ?{RESET}           Show keyboard shortcuts
  {CYAN}r{RESET}                Refresh display
  {CYAN}Ctrl+R{RESET}           Register current project in registry
  {CYAN}q{RESET}                Quit
  {CYAN}Ctrl+X{RESET}           Quit
  {CYAN}Esc{RESET}              Exit current mode / Quit

{BOLD}FILES:{RESET}
  {GREEN}.jot.json{RESET}                   Task storage (per project)
  {GREEN}~/.jot-categories/<name>.json{RESET}  Global category tasks
  {GREEN}~/.jot-keywords.json{RESET}           Keyword configuration
  {GREEN}~/.jot-project-registry.json{RESET}   Project discovery cache

{BOLD}CONFIGURATION:{RESET}
  • Edit ~/.jot-keywords.json to customize keyword actions
  • Category colors: Edit category config (Shift+C)
  • Global vs local: Use -g flag or create global categories

{DIM}For more info: https://github.com/your-repo/jot{RESET}"""
    print(help_text)
