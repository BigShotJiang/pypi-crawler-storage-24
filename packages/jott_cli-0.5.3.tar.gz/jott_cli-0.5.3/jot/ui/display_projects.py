"""Display functions for project and category statistics."""

from jot.core.task_manager import TaskManager
from jot.categories.manager import CategoryManager
from jot.ui.styles import (
    RESET, BOLD, DIM, CYAN, GREEN, YELLOW,
    get_terminal_width,
)


def display_all_projects(registry, show_categories=False):
    """Display all projects with their tasks grouped by project."""
    projects = registry.list_projects()

    if not projects:
        print("\nNo registered projects. Run jot to auto-discover "
              "projects in ~/projects/")
        return

    w = get_terminal_width()
    print("\n" + "=" * w)
    if show_categories:
        print(f"{BOLD}ALL PROJECTS OVERVIEW (with categories){RESET}")
    else:
        print(f"{BOLD}ALL PROJECTS OVERVIEW{RESET}")
    print("=" * w)

    for project_name in sorted(projects.keys()):
        project_path = projects[project_name]
        try:
            if show_categories:
                _display_project_with_categories(
                    project_name, project_path)
            else:
                _display_project_simple(project_name, project_path)
        except FileNotFoundError:
            print(f"\n📁 {BOLD}{project_name}{RESET} "
                  f"{DIM}(no .jot.json found){RESET}")
            print(f"   {DIM}{project_path}{RESET}")
        except Exception as e:
            print(f"\n📁 {BOLD}{project_name}{RESET} "
                  f"{DIM}(error loading: {e}){RESET}")
            print(f"   {DIM}{project_path}{RESET}")

    w = get_terminal_width()
    print("\n" + "=" * w)
    print(
        f"Total: {len(projects)} projects  |  "
        f"Use {CYAN}jot -p <project>{RESET} to switch  |  "
        f"{CYAN}Shift+P{RESET} in jot UI"
    )
    print("=" * w + "\n")


def _display_project_with_categories(project_name, project_path):
    """Display a single project with category breakdown."""
    cat_manager = CategoryManager(project_dir=project_path)
    local_categories = cat_manager.discover_categories()

    tm_default = TaskManager(directory=project_path)
    default_count = len(tm_default.tasks)
    archived_count = len(tm_default.archived)

    total_tasks = default_count
    category_counts = {}
    for cat in local_categories:
        tm_cat = TaskManager(directory=project_path, category=cat)
        cat_task_count = len(tm_cat.tasks)
        total_tasks += cat_task_count
        category_counts[cat] = cat_task_count

    print(
        f"\n📁 {BOLD}{project_name}{RESET} "
        f"({total_tasks} tasks total, {archived_count} archived)"
    )
    print(f"   {DIM}{project_path}{RESET}")

    if default_count > 0:
        print(f"   ├─ default: {default_count} tasks")
        for task in tm_default.tasks[:3]:
            print(f"      • {task['text'][:60]}")
        if default_count > 3:
            print(f"      ... and {default_count - 3} more")

    for cat, count in sorted(category_counts.items()):
        print(f"   ├─ {cat}: {count} tasks")
        if count > 0:
            tm_cat = TaskManager(directory=project_path, category=cat)
            for task in tm_cat.tasks[:2]:
                print(f"      • {task['text'][:60]}")
            if count > 2:
                print(f"      ... and {count - 2} more")


def _display_project_simple(project_name, project_path):
    """Display a single project without category breakdown."""
    tm = TaskManager(directory=project_path)
    task_count = len(tm.tasks)
    archived_count = len(tm.archived)

    print(
        f"\n📁 {BOLD}{project_name}{RESET} "
        f"({task_count} tasks, {archived_count} archived)"
    )
    print(f"   {DIM}{project_path}{RESET}")

    if task_count > 0:
        for task in tm.tasks[:5]:
            print(f"   • {task['text'][:70]}")
        if task_count > 5:
            print(f"   ... and {task_count - 5} more tasks")
    else:
        print(f"   {DIM}(no active tasks){RESET}")


def display_category_stats(project_dir):
    """Display statistics for all categories in a project."""
    cat_manager = CategoryManager(project_dir=project_dir)
    local_categories = cat_manager.discover_categories()
    global_categories = CategoryManager.discover_global_categories()

    w = get_terminal_width()
    print(f"\n{BOLD}Category Statistics{RESET}")
    print("=" * w)

    tm_default = TaskManager(directory=project_dir)
    print(f"\n{CYAN}DEFAULT (uncategorized){RESET}")
    print(f"  Active: {len(tm_default.tasks)} "
          f"| Archived: {len(tm_default.archived)}")

    if local_categories:
        print(f"\n{BOLD}Local Categories:{RESET}")
        for cat in sorted(local_categories):
            tm_cat = TaskManager(directory=project_dir, category=cat)
            print(f"\n{CYAN}{cat.upper()}{RESET}")
            print(f"  Active: {len(tm_cat.tasks)} "
                  f"| Archived: {len(tm_cat.archived)}")

    if global_categories:
        print(f"\n{BOLD}Global Categories:{RESET}")
        for cat in sorted(global_categories):
            tm_cat = TaskManager(category=cat, is_global=True)
            print(f"\n{GREEN}{cat.upper()} (GLOBAL){RESET}")
            print(f"  Active: {len(tm_cat.tasks)} "
                  f"| Archived: {len(tm_cat.archived)}")

    print(
        f"\n{YELLOW}⚠  Local categories: "
        f"{len(local_categories)}/{CategoryManager.MAX_CATEGORIES}{RESET}"
    )
    print(
        f"{YELLOW}⚠  Global categories: "
        f"{len(global_categories)}/{CategoryManager.MAX_CATEGORIES}{RESET}"
    )
    print("=" * w + "\n")
