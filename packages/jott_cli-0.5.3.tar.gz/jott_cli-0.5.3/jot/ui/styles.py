"""Central terminal style definitions for jot

Single source of truth for all ANSI color codes, formatting constants,
and semantic color mappings used across the UI.
"""

import re
import shutil

_ANSI_RE = re.compile(r'\033\[[0-9;]*m')


def get_terminal_width():
    """Return current terminal width, defaulting to 80."""
    try:
        return shutil.get_terminal_size().columns
    except (ValueError, OSError):
        return 80


def strip_ansi(text):
    """Remove ANSI escape sequences from text."""
    return _ANSI_RE.sub('', text)


def visible_len(text):
    """Return the visible (non-ANSI) length of text."""
    return len(strip_ansi(text))


# Terminal formatting
RESET = '\033[0m'
BOLD = '\033[1m'
DIM = '\033[2m'
REVERSE = '\033[7m'

# Base colors
RED = '\033[91m'
GREEN = '\033[92m'
YELLOW = '\033[93m'
BLUE = '\033[94m'
MAGENTA = '\033[95m'
CYAN = '\033[96m'
WHITE = '\033[97m'
GRAY = '\033[90m'
ORANGE = '\033[38;5;208m'
BLACK = '\033[30m'

# Background colors
BG_YELLOW = '\033[103m'
BG_ORANGE = '\033[48;5;208m'
BG_MAGENTA = '\033[105m'
BG_GRAY = '\033[100m'
BG_DARK_GRAY = '\033[48;5;236m'
BG_CYAN = '\033[106m'
BG_RED = '\033[101m'
BG_GREEN = '\033[102m'

# Semantic mappings — highlight color palette
HIGHLIGHT_COLORS = {
    'gray': WHITE + BG_DARK_GRAY,
    'yellow': BLACK + BG_YELLOW,
    'orange': BLACK + BG_ORANGE,
    'magenta': WHITE + BG_MAGENTA,
    'cyan': BLACK + BG_CYAN,
    'red': WHITE + BG_RED,
    'green': BLACK + BG_GREEN,
}
HIGHLIGHT_DEFAULT = 'yellow'
HIGHLIGHT_FMT = HIGHLIGHT_COLORS[HIGHLIGHT_DEFAULT]

# Semantic mappings — priority
PRIORITY_COLORS = {
    'none': DIM,
    'low': BLUE,
    'medium': YELLOW,
    'high': RED,
}
PRIORITY_SYMBOLS = {
    'none': '',
    'low': '\u25d4',      # ◔
    'medium': '\u25d1',   # ◑
    'high': '\u25cf',     # ●
}

# Semantic mappings — task status
STATUS_COLORS = {
    'todo': DIM,
    'in-progress': CYAN,
    'blocked': RED,
    'done': GREEN,
}
STATUS_SYMBOLS = {
    'todo': '',
    'in-progress': '\u25b6',  # ▶
    'blocked': '\u26a0',      # ⚠
    'done': '\u2713',         # ✓
}

# Archive display
ARCHIVE_SYMBOL = '\U0001f4e6'  # 📦
ARCHIVE_COLOR = DIM
