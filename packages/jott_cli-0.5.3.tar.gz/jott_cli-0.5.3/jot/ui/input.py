"""Terminal input utilities for jot

Uses prompt_toolkit when available for improved input handling (history,
completion, proper key binding). Falls back to stdlib termios/readline
if prompt_toolkit is not installed.
"""

import sys
import termios

try:
    from prompt_toolkit import prompt as pt_prompt
    from prompt_toolkit.history import FileHistory
    from prompt_toolkit.input.vt100_parser import Vt100Parser
    from prompt_toolkit.keys import Keys
    from pathlib import Path

    PROMPT_TOOLKIT_AVAILABLE = True
    _TASK_HISTORY = FileHistory(str(Path.home() / '.jot_history'))
except ImportError:
    PROMPT_TOOLKIT_AVAILABLE = False
    _TASK_HISTORY = None


# ---------------------------------------------------------------------------
# Fallback (stdlib) implementations
# ---------------------------------------------------------------------------

def _input_with_prefill_legacy(prompt_text, prefill=''):
    """Get input with pre-filled text using readline"""
    import readline

    def hook():
        readline.insert_text(prefill)
        readline.redisplay()

    readline.set_startup_hook(hook)
    try:
        return input(prompt_text)
    finally:
        readline.set_startup_hook()


def _get_key_legacy(timeout=1.0):
    """Read a single keypress with timeout using raw termios/select"""
    import select
    import tty

    fd = sys.stdin.fileno()
    old_settings = termios.tcgetattr(fd)
    try:
        tty.setraw(fd)

        ready, _, _ = select.select([sys.stdin], [], [], timeout)
        if not ready:
            return None

        ch = sys.stdin.read(1)

        # Paste detection via rapid multi-character input
        more_ready, _, _ = select.select([sys.stdin], [], [], 0.001)
        if more_ready:
            pasted_text = ch
            while True:
                chunk_ready, _, _ = select.select([sys.stdin], [], [], 0.001)
                if not chunk_ready:
                    break
                pasted_text += sys.stdin.read(1)
            return ('PASTE', pasted_text)

        if ch == '\x0e':  # Ctrl+n
            return 'DOWN'
        elif ch == '\x10':  # Ctrl+p
            return 'UP'

        if ch == '\x1b':  # ESC
            ch2 = sys.stdin.read(1)
            if ch2 == '[':
                ch3 = sys.stdin.read(1)
                if ch3 == 'A':
                    return 'UP'
                elif ch3 == 'B':
                    return 'DOWN'
                elif ch3 == '1':
                    ch4 = sys.stdin.read(1)
                    if ch4 == ';':
                        ch5 = sys.stdin.read(1)
                        if ch5 == '2':
                            ch6 = sys.stdin.read(1)
                            if ch6 == 'A':
                                return 'SHIFT_UP'
                            elif ch6 == 'B':
                                return 'SHIFT_DOWN'

        return ch
    finally:
        termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)


# ---------------------------------------------------------------------------
# prompt_toolkit implementations
# ---------------------------------------------------------------------------

# Map prompt_toolkit Keys enum values to jot's key names
_PT_KEY_MAP = {
    Keys.Up: 'UP',
    Keys.Down: 'DOWN',
    Keys.ShiftUp: 'SHIFT_UP',
    Keys.ShiftDown: 'SHIFT_DOWN',
    Keys.ControlN: 'DOWN',
    Keys.ControlP: 'UP',
}


def _get_key_pt(timeout=1.0):
    """Read a single keypress using prompt_toolkit's Vt100Parser.

    Uses prompt_toolkit's battle-tested escape sequence parser instead
    of manual character-by-character parsing. Returns the same values
    as _get_key_legacy for full compatibility:
    - None on timeout
    - 'UP', 'DOWN', 'SHIFT_UP', 'SHIFT_DOWN' for arrow keys
    - ('PASTE', text) for pasted content
    - Raw character for everything else
    """
    import select
    import tty

    fd = sys.stdin.fileno()
    old_settings = termios.tcgetattr(fd)
    try:
        tty.setraw(fd)

        ready, _, _ = select.select([sys.stdin], [], [], timeout)
        if not ready:
            return None

        # Read all available bytes at once
        ch = sys.stdin.read(1)

        # Check for more data (escape sequences or paste)
        data = ch
        while True:
            more_ready, _, _ = select.select([sys.stdin], [], [], 0.001)
            if not more_ready:
                break
            data += sys.stdin.read(1)

        # Single printable character — fast path (skip parser overhead)
        if len(data) == 1 and data != '\x1b':
            if data == '\x0e':  # Ctrl+N
                return 'DOWN'
            if data == '\x10':  # Ctrl+P
                return 'UP'
            return data

        # Use Vt100Parser to decode escape sequences
        parsed_keys = []

        def feed_key(key_press):
            parsed_keys.append(key_press)

        parser = Vt100Parser(feed_key)
        parser.feed(data)

        if not parsed_keys:
            return data

        # If parser produced a single known key, map it
        if len(parsed_keys) == 1:
            kp = parsed_keys[0]
            mapped = _PT_KEY_MAP.get(kp.key)
            if mapped:
                return mapped
            if kp.key == Keys.Escape:
                return '\x1b'
            # Return the character data for printable keys
            if kp.data and len(kp.data) == 1:
                return kp.data
            return kp.data or data

        # Multiple keys parsed — likely pasted text
        pasted = ''.join(kp.data for kp in parsed_keys if kp.data)
        if len(pasted) > 1:
            return ('PASTE', pasted)

        # Fallback to first key
        kp = parsed_keys[0]
        mapped = _PT_KEY_MAP.get(kp.key)
        return mapped or kp.data or data

    finally:
        termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)


def _input_with_prefill_pt(prompt_text, prefill=''):
    """Get input with pre-filled text using prompt_toolkit.

    Gains over readline version:
    - Persistent history at ~/.jot_history (Ctrl+R to search)
    - Proper line editing with cursor movement
    """
    return pt_prompt(prompt_text, default=prefill, history=_TASK_HISTORY)


# ---------------------------------------------------------------------------
# Terminal utilities
# ---------------------------------------------------------------------------

def restore_terminal():
    """Restore terminal to normal (cooked) mode and flush pending input.

    Call this before using input() or other line-oriented IO after the
    main loop's get_key() has been reading in raw mode.
    """
    fd = sys.stdin.fileno()
    old_settings = termios.tcgetattr(fd)
    termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)
    termios.tcflush(fd, termios.TCIFLUSH)


def flush_input():
    """Flush any pending terminal input without changing mode."""
    fd = sys.stdin.fileno()
    termios.tcflush(fd, termios.TCIFLUSH)


# ---------------------------------------------------------------------------
# Public API — delegates to prompt_toolkit or legacy based on availability
# ---------------------------------------------------------------------------

if PROMPT_TOOLKIT_AVAILABLE:
    get_key = _get_key_pt
    input_with_prefill = _input_with_prefill_pt
else:
    get_key = _get_key_legacy
    input_with_prefill = _input_with_prefill_legacy
