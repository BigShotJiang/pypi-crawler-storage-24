"""Display functions for archive and all-categories views."""

from jot.core.task_manager import TaskManager
from jot.categories.manager import CategoryManager
from jot.categories.config import CategoryConfig
from jot.ui.styles import (
    RESET, BOLD, DIM, CYAN, YELLOW,
    get_terminal_width,
)


def display_archive(project_dir, filter_category=None):
    """Display archived tasks with optional category filter."""
    cat_manager = CategoryManager(project_dir=project_dir)
    managers_to_check = _build_archive_managers(
        project_dir, cat_manager, filter_category)

    print(f"\n{BOLD}Archived Tasks{RESET}")
    print("=" * get_terminal_width())

    total_archived = 0
    for cat_name, tm in managers_to_check:
        if not tm.archived:
            continue
        print(f"\n{CYAN}{cat_name.upper()}{RESET} "
              f"({len(tm.archived)} archived)")
        for i, task in enumerate(tm.archived, 1):
            task_prefix = _archive_task_prefix(task)
            print(f"  {i}. {task_prefix} {task['text']}")
            if 'archived_at' in task:
                print(f"     {DIM}Archived: {task['archived_at']}{RESET}")
        total_archived += len(tm.archived)

    if total_archived == 0:
        print(f"\n{DIM}No archived tasks{RESET}")
    print("=" * get_terminal_width() + "\n")


def _build_archive_managers(project_dir, cat_manager, filter_category):
    """Build list of (category_name, TaskManager) tuples for archive."""
    if filter_category:
        if filter_category == 'global':
            return [
                (cat, TaskManager(category=cat, is_global=True))
                for cat in CategoryManager.discover_global_categories()
            ]
        return [
            (filter_category,
             TaskManager(directory=project_dir, category=filter_category))
        ]

    managers = [('default', TaskManager(directory=project_dir))]
    for cat in cat_manager.discover_categories():
        tm_cat = TaskManager(directory=project_dir, category=cat)
        managers.append((cat, tm_cat))
    return managers


def _archive_task_prefix(task):
    """Get display prefix for an archived task."""
    if task.get('type') == 'done':
        return f"{CYAN}✓{RESET}"
    if task.get('type') == 'canceled':
        return f"{YELLOW}✗{RESET}"
    return "✓"


def display_all_categories_view(
        all_cat_data, project_dir, show_archived=False):
    """Render the ALL_CATEGORIES grouped task view.

    Args:
        all_cat_data: List of (cat_name, is_global, tasks, archived) tuples.
        project_dir: Path to the project directory (for category config).
        show_archived: Whether to include archived tasks in the view.
    """
    print(f"\n{CYAN}{BOLD}ALL CATEGORIES VIEW{RESET}")
    print("-" * get_terminal_width())

    cat_config = CategoryConfig(project_dir=project_dir)
    task_num = 1
    total_tasks = 0

    for cat_name, is_global, tasks, archived in all_cat_data:
        display_tasks_list = tasks + (archived if show_archived else [])
        if not display_tasks_list:
            continue

        total_tasks += len(display_tasks_list)
        cat_color = cat_config.get_color(cat_name, for_global=is_global)
        global_indicator = (
            f" {DIM}[global]{RESET}" if is_global
            else f" {DIM}[local]{RESET}"
        )
        print(
            f"\n{cat_color}{BOLD}[{cat_name}]{RESET}"
            f"{global_indicator} ({len(display_tasks_list)} tasks)"
        )

        for task in display_tasks_list:
            status = "\u2713" if task.get('done', False) else " "
            is_current = task.get('current', False)
            marker = "\u2192" if is_current else " "
            print(
                f"  {marker} [{status}] {task_num}. "
                f"{task.get('text', '')}"
            )
            task_num += 1

    print(
        f"\n{DIM}Total: {total_tasks} tasks across "
        f"{len(all_cat_data)} categories{RESET}"
    )
    print("-" * get_terminal_width())
    print(
        f"{CYAN}Press Shift+L or ESC to return to "
        f"single category view{RESET}"
    )
