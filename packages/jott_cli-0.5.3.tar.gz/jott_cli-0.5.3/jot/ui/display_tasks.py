"""Display function for the main task list view."""

import textwrap
from datetime import datetime, timezone
from pathlib import Path

from jot.core.constants import (
    MODE_QUICK_ADD, MODE_MULTISELECT,
    DAY_COLORS, DAY_ABBREVIATIONS,
)
from jot.categories.manager import CategoryManager
from jot.categories.config import CategoryConfig
from jot.ui.formatting import format_inline_notes, format_category_badges
from jot.ui.styles import (
    RESET, BOLD, DIM, REVERSE, CYAN, GREEN, YELLOW, MAGENTA,
    PRIORITY_COLORS, PRIORITY_SYMBOLS, STATUS_COLORS, STATUS_SYMBOLS,
    ARCHIVE_SYMBOL, ARCHIVE_COLOR, HIGHLIGHT_COLORS, HIGHLIGHT_DEFAULT,
    get_terminal_width, visible_len,
)
from jot.ui.display_footer import render_mode_footer, render_archived_section


def display_tasks(
    tasks,
    mode=MODE_QUICK_ADD,
    input_buffer="",
    project_name=None,
    category=None,
    is_global=False,
    show_archived=False,
    archived_tasks=None,
    selected_tasks=None,
    search_buffer="",
    archived_task_ids=None,
    include_archived_in_search=True,
    show_shortcuts=False,
    show_notes_inline=False,
    match_positions=None,
    collapsed_parents=None,
    all_tasks=None,
):
    """Display current task list with mode indicator."""
    if selected_tasks is None:
        selected_tasks = set()
    if archived_task_ids is None:
        archived_task_ids = set()
    if collapsed_parents is None:
        collapsed_parents = set()

    cat_color = _get_category_color(category, is_global)
    _render_header(tasks, project_name, category, is_global, cat_color)

    if not tasks:
        print("\n  No tasks yet. Start typing to add one!")
    else:
        # Use full task list for subtask info when available so
        # collapsed parents still show correct descendant counts.
        info_source = all_tasks if all_tasks is not None else tasks
        desc_counts, depths = _build_subtask_info(info_source)
        for task in tasks:
            positions = (match_positions or {}).get(task['id'], [])
            _render_task_line(
                task, mode, selected_tasks, archived_task_ids,
                show_notes_inline, positions,
                child_count=desc_counts.get(task['id'], 0),
                depth=depths.get(task['id'], 0),
                collapsed=task['id'] in collapsed_parents)

    print("\n" + "-" * get_terminal_width())

    if show_archived and archived_tasks:
        render_archived_section(archived_tasks)

    render_mode_footer(
        mode, input_buffer, selected_tasks, search_buffer,
        tasks, archived_task_ids, include_archived_in_search,
        show_shortcuts)


def _get_category_color(category, is_global):
    """Get the display color for the current category."""
    if not category:
        return CYAN
    cat_config = CategoryConfig()
    return cat_config.get_color(category, for_global=is_global)


def _render_header(tasks, project_name, category, is_global, cat_color):
    """Render the ASCII art header and project/category info."""
    print(f"\n{CYAN}{BOLD}")
    print("     _       __  __")
    print("    (_)___  / /_/ /_")
    print("   / / __ \\/ __/ __/")
    print("  / / /_/ / /_/ /_")
    print(" /_/\\____/\\__/\\__/")
    print(f"{RESET}")

    current_task_text = _find_current_task_text(tasks)
    _render_project_line(project_name, category, is_global, cat_color,
                         current_task_text)
    _render_category_badges(category, is_global)
    print("-" * get_terminal_width())


def _find_current_task_text(tasks):
    """Find and truncate the current task's text for the header."""
    for task in tasks:
        if task.get('current', False):
            text = task.get('text', '')
            return text[:37] + "..." if len(text) > 40 else text
    return None


def _render_project_line(project_name, category, is_global, cat_color,
                         current_task_text):
    """Render the project name, category badge, and current task."""
    if project_name:
        print(f"  {YELLOW}{BOLD}{project_name}{RESET} "
              f"{DIM}({Path.cwd().name}){RESET}", end='')
    else:
        print(f"  {YELLOW}{BOLD}{Path.cwd().name}{RESET}", end='')

    if category:
        if is_global:
            print(f" {cat_color}{BOLD}[global:{category}]{RESET}", end='')
        else:
            print(f" {cat_color}{BOLD}[{category}]{RESET}", end='')

    if current_task_text:
        print(f" {DIM}→{RESET} {GREEN}{current_task_text}{RESET}")
    else:
        print()


def _render_category_badges(category, is_global):
    """Render the category badges row."""
    try:
        project_dir = Path.cwd()
        cat_manager = CategoryManager(project_dir)
        badge_config = CategoryConfig(project_dir)
        badges = format_category_badges(
            cat_manager, badge_config, category, is_global)
        if badges:
            print(f"  {badges}")
    except Exception:
        pass


def _build_subtask_info(tasks):
    """Pre-compute recursive descendant counts and nesting depths."""
    parent_of = {}      # child_id → parent_id
    children_of = {}    # parent_id → [child_id, ...]
    for task in tasks:
        for label in task.get('labels', []):
            if label.startswith('parent:'):
                pid = label.split(':', 1)[1]
                try:
                    pid = int(pid)
                except ValueError:
                    pass
                parent_of[task['id']] = pid
                children_of.setdefault(pid, []).append(task['id'])
                break

    # Compute nesting depth by walking parent_of chains
    depths = {}  # task_id → int (1 = direct child, 2 = grandchild, …)
    for tid in parent_of:
        d, cur = 0, tid
        while cur in parent_of:
            d += 1
            cur = parent_of[cur]
            if d > 10:  # guard against cycles
                break
        depths[tid] = d

    # Count all descendants recursively (iterative BFS)
    desc_counts = {}  # task_id → total descendant count
    for root in children_of:
        count = 0
        stack = list(children_of[root])
        seen = {root}
        while stack:
            cid = stack.pop()
            if cid in seen:
                continue
            seen.add(cid)
            count += 1
            stack.extend(children_of.get(cid, []))
        if count > 0:
            desc_counts[root] = count

    return desc_counts, depths


def _build_task_prefixes(task, mode, selected_tasks, archived_task_ids,
                         depth=0):
    """Build all prefix strings for a task line."""
    priority = task.get('priority', 'none')
    task_status = task.get('status', 'todo')
    day = task.get('day')
    has_notes = bool(task.get('notes', '').strip())

    selection_box = ""
    if mode == MODE_MULTISELECT:
        if task['id'] in selected_tasks:
            selection_box = f"{GREEN}[✓]{RESET} "
        else:
            selection_box = "[ ] "

    archive_prefix = ""
    if task['id'] in archived_task_ids:
        archive_prefix = f"{ARCHIVE_COLOR}{ARCHIVE_SYMBOL}{RESET} "

    notes_prefix = "📝 " if has_notes else ""

    analysis_prefix = ""
    analysis_file = Path.cwd() / f".jot.analysis.{task['id']}.org"
    if analysis_file.exists():
        analysis_prefix = "📋 "

    priority_prefix = ""
    if priority and priority != 'none':
        p_color = PRIORITY_COLORS.get(priority, DIM)
        p_symbol = PRIORITY_SYMBOLS.get(priority, '')
        priority_prefix = f"{p_color}{p_symbol}{RESET} "

    status_prefix = ""
    if task_status and task_status not in ['todo', 'done']:
        s_color = STATUS_COLORS.get(task_status, DIM)
        s_symbol = STATUS_SYMBOLS.get(task_status, '')
        status_prefix = f"{s_color}{s_symbol}{RESET} "

    day_prefix = ""
    if day:
        day_color = DAY_COLORS.get(day, CYAN)
        day_abbrev = DAY_ABBREVIATIONS.get(day, day[:3])
        day_prefix = f"{day_color}[{day_abbrev}]{RESET} "

    if depth > 0:
        arrows = "\u21b3" * depth
        subtask_prefix = f"{DIM}{arrows}{RESET} "
    else:
        subtask_prefix = ""

    return (selection_box + archive_prefix + notes_prefix
            + analysis_prefix + priority_prefix + status_prefix
            + day_prefix + subtask_prefix)


def _build_task_suffixes(task, child_count=0, collapsed=False):
    """Build tally, stale-warning, and subtask-count suffixes."""
    tally = task.get('tally', 0)
    tally_suffix = f" {DIM}(\u00d7{tally}){RESET}" if tally > 0 else ""

    stale_warning = ""
    updated_at = task.get('updated_at')
    task_status = task.get('status', 'todo')
    if updated_at and not task.get('done', False) and task_status != 'done':
        try:
            updated_dt = datetime.fromisoformat(
                updated_at.replace('Z', '+00:00'))
            age_days = (datetime.now(timezone.utc) - updated_dt).days
            if age_days >= 7:
                stale_warning = f" {DIM}\u23f0{age_days}d{RESET}"
        except (ValueError, AttributeError):
            pass

    subtask_suffix = ""
    if child_count > 0:
        noun = "subtask" if child_count == 1 else "subtasks"
        if collapsed:
            subtask_suffix = (
                f" {YELLOW}\u25b6 ({child_count} {noun}){RESET}")
        else:
            subtask_suffix = (
                f" {DIM}\u25bc ({child_count} {noun}){RESET}")

    return tally_suffix, stale_warning, subtask_suffix


def _highlight_text(text, positions, base_fmt=""):
    """Highlight matched characters with reverse video."""
    if not positions:
        return text
    pos_set = set(positions)
    parts, in_hl = [], False
    for i, ch in enumerate(text):
        if i in pos_set:
            if not in_hl:
                parts.append(REVERSE)
                in_hl = True
        elif in_hl:
            parts.append(RESET + base_fmt)
            in_hl = False
        parts.append(ch)
    if in_hl:
        parts.append(RESET + base_fmt)
    return ''.join(parts)


def _render_task_line(
        task, mode, selected_tasks, archived_task_ids,
        show_notes_inline, match_positions=None,
        child_count=0, depth=0, collapsed=False):
    """Render a single task line with all decorations and wrapping."""
    status = "\u2713" if task.get('done', False) else " "
    is_current = task.get('current', False)
    is_agent = task.get('agent_task', False)
    is_break = 'break' in task['text'].lower()

    prefixes = _build_task_prefixes(
        task, mode, selected_tasks, archived_task_ids, depth)
    tally_suffix, stale_warning, subtask_suffix = _build_task_suffixes(
        task, child_count, collapsed)

    if is_agent:
        color, icon = MAGENTA, "\U0001f916"
    elif is_current and is_break:
        color, icon = GREEN, "\U0001f33f"
    elif is_current:
        color, icon = CYAN, "\u2728"
    else:
        color, icon = None, None

    task_text = task['text']
    hl_value = task.get('highlight', False)
    # Support both legacy boolean and new color-name highlights
    if hl_value is True:
        hl_fmt = HIGHLIGHT_COLORS[HIGHLIGHT_DEFAULT]
    elif hl_value:
        hl_fmt = HIGHLIGHT_COLORS.get(hl_value, HIGHLIGHT_COLORS[HIGHLIGHT_DEFAULT])
    else:
        hl_fmt = None
    hl_id = f"{hl_fmt}{task['id']}{RESET}" if hl_fmt else str(task['id'])

    # Build the fixed-width scaffold (everything except task text)
    # id_offset = visible columns before the task ID (for wrap indent)
    if is_current or is_agent:
        arrow = "\u2192" if is_current else " "
        before = f"{color}{BOLD}{arrow} [{status}] {hl_id}{color}{BOLD}. {prefixes}{icon} "
        after, line_fmt = f"{RESET}{tally_suffix}{stale_warning}{subtask_suffix}", color + BOLD
        id_offset = 6  # "→ [ ] "
    else:
        before = f"  [{status}] {hl_id}. {prefixes}"
        after, line_fmt = f"{tally_suffix}{stale_warning}{subtask_suffix}", ""
        id_offset = 6  # "  [ ] "

    before_vis = visible_len(before)
    available = min(112, max(20, get_terminal_width() - id_offset - visible_len(after)))

    # Apply match highlighting if present
    hl_base = (color + BOLD) if (is_current or is_agent) else ""
    hl_text = _highlight_text(task_text, match_positions, hl_base) if match_positions else task_text

    if len(task_text) <= available:
        print(f"{before}{hl_text}{after}")
    else:
        wrapped = textwrap.wrap(task_text, width=available) or [task_text]
        first = _highlight_text(wrapped[0], match_positions, hl_base) if match_positions else wrapped[0]
        print(f"{before}{first}{after}")
        indent = " " * id_offset
        cont_prefix = RESET + line_fmt if line_fmt else ""
        for cont in wrapped[1:]:
            print(f"{cont_prefix}{indent}{cont}{RESET}")

    if (show_notes_inline and bool(task.get('notes', '').strip())
            and is_current):
        for line in format_inline_notes(task.get('notes', '')):
            print(line)
