"""Rendering utilities for flicker-free terminal output."""

import io
import sys
from contextlib import contextmanager


@contextmanager
def buffered_output():
    """Redirect stdout to a buffer, then flush in one write.

    Wrapping a render pass in this context manager ensures the
    terminal receives the entire frame atomically, eliminating
    partial-frame tearing.
    """
    buf = io.StringIO()
    old_stdout = sys.stdout
    sys.stdout = buf
    try:
        yield buf
    finally:
        sys.stdout = old_stdout
        old_stdout.write(buf.getvalue())
        old_stdout.flush()
