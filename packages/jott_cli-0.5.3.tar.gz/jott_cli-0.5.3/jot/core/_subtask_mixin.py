"""Subtask sync mixin — parse checklist items from notes."""

import re
import textwrap
from datetime import datetime, timezone

_CHECKLIST_RE = re.compile(r'^-\s*\[([ xX])\]\s+(.+)$')


def _parse_checklist_with_notes(notes_text):
    """Parse checklist items and any nested text below them.

    Returns list of (text, done, nested_notes) tuples.
    Nested text is dedented and trailing whitespace stripped.
    """
    items = []
    current_nested = []

    for line in notes_text.split('\n'):
        match = _CHECKLIST_RE.match(line.strip())
        if match:
            # Flush previous item's nested text
            if items:
                items[-1] = _finalize_nested(items[-1], current_nested)
                current_nested = []
            done = match.group(1).lower() == 'x'
            text = match.group(2).strip()
            items.append((text, done, ''))
        elif items:
            # Non-checklist line after a checklist item
            current_nested.append(line)

    # Flush last item
    if items:
        items[-1] = _finalize_nested(items[-1], current_nested)

    return items


def _finalize_nested(item, nested_lines):
    """Dedent and strip nested lines, attach to item tuple."""
    # Drop leading/trailing blank lines
    while nested_lines and not nested_lines[0].strip():
        nested_lines.pop(0)
    while nested_lines and not nested_lines[-1].strip():
        nested_lines.pop()

    if not nested_lines:
        return item

    notes = textwrap.dedent('\n'.join(nested_lines)).strip()
    return (item[0], item[1], notes)


class SubtaskMixin:
    """Sync subtasks from task notes checklists."""

    def sync_subtasks_from_notes(self, task_id):
        """Parse checklist items from task notes and sync as subtasks.

        Parses '- [ ] text' (todo) and '- [X] text' (done) lines.
        Nested text below a checklist item becomes the subtask's notes.
        Creates new tasks with 'parent:{id}' label, skips duplicates.

        Returns:
            dict with 'created', 'updated', 'total' counts, or None if task not found
        """
        task = next((t for t in self.tasks if t['id'] == task_id), None)
        if not task:
            return None

        notes = task.get('notes', '')
        if not notes:
            return {'created': 0, 'updated': 0, 'total': 0}

        checklist_items = _parse_checklist_with_notes(notes)
        if not checklist_items:
            return {'created': 0, 'updated': 0, 'total': 0}

        parent_label = f"parent:{task_id}"
        existing = {
            t['text']: t for t in self.tasks
            if parent_label in t.get('labels', [])
        }

        now = datetime.now(timezone.utc).isoformat()
        created = updated = 0
        for text, done, nested_notes in checklist_items:
            if text in existing:
                sub = existing[text]
                new_status = 'done' if done else 'todo'
                status_changed = sub['status'] != new_status
                notes_changed = sub.get('notes', '') != nested_notes
                if status_changed:
                    sub['status'] = new_status
                    sub['done'] = done
                    sub['updated_at'] = now
                    updated += 1
                if notes_changed:
                    sub['notes'] = nested_notes
                    sub['updated_at'] = now
                    if not status_changed:
                        updated += 1
            elif not done:
                new_id = self.add_task(
                    text,
                    status='done' if done else 'todo',
                    labels=[parent_label],
                )
                if nested_notes and isinstance(new_id, int):
                    self.set_task_notes(new_id, nested_notes)
                created += 1

        if updated:
            self._save_tasks()

        return {'created': created, 'updated': updated, 'total': len(checklist_items)}
