"""Metadata mixin — current, agent, day, priority, status, tally."""

from datetime import datetime, timezone


class MetadataMixin:
    """Set task metadata: current flag, agent, day, priority, status, tally."""

    def set_current(self, task_id):
        """Mark a task as current (only one can be current).
        If the task is archived, it will be automatically unarchived."""
        for task in self.tasks:
            task['current'] = False

        # Check active tasks
        for task in self.tasks:
            if task['id'] == task_id:
                task['current'] = True
                self._save_tasks()
                return True

        # Check archived — unarchive if found
        for i, task in enumerate(self.archived):
            if task['id'] == task_id:
                archived_task = self.archived.pop(i)
                archived_task['current'] = True
                self.tasks.append(archived_task)
                self._save_tasks()
                return True

        return False

    def set_agent_task(self, task_id=None):
        """Mark a task as agent_task (Claude Code is working on it).
        Only one task can be agent_task at a time. Toggles if already set."""
        if task_id is None:
            current = self.get_current_task()
            if not current:
                return False
            task_id = current['id']

        target_task = None
        for task in self.tasks:
            if task['id'] == task_id:
                target_task = task
                break

        if not target_task:
            return False

        # Toggle if already agent_task
        if target_task.get('agent_task', False):
            target_task['agent_task'] = False
            self._save_tasks()
            return True

        for task in self.tasks:
            task['agent_task'] = False

        target_task['agent_task'] = True
        self._save_tasks()
        return True

    def set_highlight(self, task_id=None, color=None):
        """Set highlight color on a task, or clear it.

        Args:
            task_id: Task to highlight (defaults to current task).
            color: Color name from HIGHLIGHT_COLORS, or None to clear.
        """
        if task_id is None:
            current = self.get_current_task()
            if not current:
                return False
            task_id = current['id']

        for task in self.tasks:
            if task['id'] == task_id:
                task['highlight'] = color if color else False
                self._save_tasks()
                return True
        return False

    def set_task_day(self, task_id, day):
        """Assign a day of the week to a task (Monday-Sunday or None)."""
        for task in self.tasks:
            if task['id'] == task_id:
                task['day'] = day
                self._save_tasks()
                return True
        return False

    def set_task_priority(self, task_id, priority):
        """Set priority for a task ('none', 'low', 'medium', 'high')."""
        valid = ('none', 'low', 'medium', 'high')
        if priority not in valid:
            raise ValueError(f"Priority must be one of: {', '.join(valid)}")

        for task in self.tasks:
            if task['id'] == task_id:
                task['priority'] = priority
                task['updated_at'] = datetime.now(timezone.utc).isoformat()
                self._save_tasks()
                return True
        return False

    def set_task_status(self, task_id, status):
        """Set status for a task ('todo', 'in-progress', 'blocked', 'done')."""
        valid = ('todo', 'in-progress', 'blocked', 'done')
        if status not in valid:
            raise ValueError(f"Status must be one of: {', '.join(valid)}")

        for task in self.tasks:
            if task['id'] == task_id:
                task['status'] = status
                task['updated_at'] = datetime.now(timezone.utc).isoformat()
                if status == 'done':
                    task['done'] = True
                elif task.get('done', False):
                    task['done'] = False
                self._save_tasks()
                return True
        return False

    def increment_tally(self):
        """Increment the tally counter for the current task"""
        for task in self.tasks:
            if task.get('current', False):
                if 'tally' not in task:
                    task['tally'] = 0
                task['tally'] += 1
                self._save_tasks()
                return task['tally']
        return None
