"""Compress mixin — compress archived tasks into tar.gz files."""

import io
import json
import tarfile
from datetime import datetime


class CompressMixin:
    """Compress old archived tasks into monthly tar.gz archives."""

    def compress_archives(self, keep_n=None, category=None):
        """Compress old archived tasks into timestamped tar.gz files.

        Args:
            keep_n: Number of recent archived tasks to keep in main file
            category: Specific category to compress (or None for default)

        Returns:
            dict with compression results
        """
        if keep_n is None:
            keep_n = self.config['keep_in_main']

        # Determine storage file
        if category and category != 'default':
            storage_file = self.project_dir / f'.jot.{category}.json'
        else:
            storage_file = self.project_dir / '.jot.json'

        if not storage_file.exists():
            return {'error': f'File not found: {storage_file}'}

        with open(storage_file) as f:
            data = json.load(f)

        archived = data.get('archived', [])
        if len(archived) <= keep_n:
            return {
                'message': f'Only {len(archived)} archived tasks, '
                           f'no compression needed'}

        to_keep = archived[-keep_n:]
        to_compress = archived[:-keep_n]

        # Group by month and write archives
        by_month = {}
        for task in to_compress:
            month = self._extract_month(task)
            by_month.setdefault(month, []).append(task)

        compressed_count = 0
        for month, tasks in by_month.items():
            self._write_month_archive(month, tasks)
            compressed_count += len(tasks)

        # Update storage file with only recent archives
        data['archived'] = to_keep
        with open(storage_file, 'w') as f:
            json.dump(data, f, indent=2)

        return {
            'compressed': compressed_count,
            'kept_in_main': len(to_keep),
            'archive_files_created': len(by_month),
        }

    def _write_month_archive(self, month, tasks):
        """Write tasks to a monthly tar.gz archive, merging if exists."""
        archive_file = self.project_dir / f'.jot.archive.{month}.tar.gz'

        existing_tasks = []
        if archive_file.exists():
            existing_tasks = self._read_compressed_archive(archive_file)

        # Deduplicate by ID
        task_dict = {t['id']: t for t in existing_tasks + tasks}

        archive_data = {
            'month': month,
            'created_at': datetime.now().isoformat(),
            'tasks': list(task_dict.values()),
        }

        json_data = json.dumps(archive_data, indent=2).encode('utf-8')
        json_file = io.BytesIO(json_data)

        with tarfile.open(archive_file, 'w:gz') as tar:
            tarinfo = tarfile.TarInfo(name='archive.json')
            tarinfo.size = len(json_data)
            tar.addfile(tarinfo, json_file)

    @staticmethod
    def _extract_month(task):
        """Extract YYYY-MM month string from a task's timestamps."""
        for field in ['updated_at', 'created_at']:
            if field in task:
                try:
                    dt = datetime.fromisoformat(
                        task[field].replace('Z', '+00:00'))
                    return dt.strftime('%Y-%m')
                except (ValueError, AttributeError):
                    pass
        return datetime.now().strftime('%Y-%m')
