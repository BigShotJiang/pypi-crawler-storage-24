"""Navigation mixin — move, sort, and cycle through tasks."""


class NavigationMixin:
    """Task ordering and current-task navigation."""

    def move_task_up(self):
        """Move the current task up in the list"""
        if not self.tasks or len(self.tasks) < 2:
            return False

        current_idx = -1
        for i, task in enumerate(self.tasks):
            if task.get('current', False):
                current_idx = i
                break

        if current_idx <= 0:
            return False

        self.tasks[current_idx], self.tasks[current_idx - 1] = (
            self.tasks[current_idx - 1], self.tasks[current_idx])
        self._save_tasks()
        return True

    def move_task_down(self):
        """Move the current task down in the list"""
        if not self.tasks or len(self.tasks) < 2:
            return False

        current_idx = -1
        for i, task in enumerate(self.tasks):
            if task.get('current', False):
                current_idx = i
                break

        if current_idx == -1 or current_idx >= len(self.tasks) - 1:
            return False

        self.tasks[current_idx], self.tasks[current_idx + 1] = (
            self.tasks[current_idx + 1], self.tasks[current_idx])
        self._save_tasks()
        return True

    def sort_by_priority(self):
        """Sort tasks by priority (high -> medium -> low -> none)"""
        if not self.tasks:
            return False

        priority_order = {'high': 0, 'medium': 1, 'low': 2, 'none': 3}

        current_task_id = None
        for task in self.tasks:
            if task.get('current', False):
                current_task_id = task['id']
                break

        self.tasks.sort(
            key=lambda t: priority_order.get(t.get('priority', 'none'), 3))

        if current_task_id:
            for task in self.tasks:
                task['current'] = task['id'] == current_task_id

        self._save_tasks()
        return True

    def set_next_current(self, filtered_tasks=None):
        """Set the next task as current.

        Args:
            filtered_tasks: Optional list to navigate within (today filter, search).
        """
        if not self.tasks:
            return False

        nav_tasks = filtered_tasks if filtered_tasks is not None else self.tasks
        if not nav_tasks:
            return False

        current_idx, current_task_id = -1, None
        for task in self.tasks:
            if task.get('current', False):
                current_task_id = task['id']
                break

        if current_task_id:
            for i, task in enumerate(nav_tasks):
                if task['id'] == current_task_id:
                    current_idx = i
                    break

        for task in self.tasks:
            task['current'] = False

        if current_idx == -1:
            nav_tasks[0]['current'] = True
        else:
            nav_tasks[(current_idx + 1) % len(nav_tasks)]['current'] = True

        self._save_tasks()
        return True

    def set_prev_current(self, filtered_tasks=None):
        """Set the previous task as current.

        Args:
            filtered_tasks: Optional list to navigate within (today filter, search).
        """
        if not self.tasks:
            return False

        nav_tasks = filtered_tasks if filtered_tasks is not None else self.tasks
        if not nav_tasks:
            return False

        current_idx, current_task_id = -1, None
        for task in self.tasks:
            if task.get('current', False):
                current_task_id = task['id']
                break

        if current_task_id:
            for i, task in enumerate(nav_tasks):
                if task['id'] == current_task_id:
                    current_idx = i
                    break

        for task in self.tasks:
            task['current'] = False

        if current_idx == -1:
            nav_tasks[-1]['current'] = True
        else:
            nav_tasks[(current_idx - 1) % len(nav_tasks)]['current'] = True

        self._save_tasks()
        return True
