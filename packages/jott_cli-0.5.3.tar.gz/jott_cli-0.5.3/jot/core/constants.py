"""Core constants for jot application"""

# Mode constants
MODE_QUICK_ADD = 'quick_add'
MODE_COMMAND = 'command'
MODE_MULTISELECT = 'multiselect'
MODE_FUZZY_SEARCH = 'fuzzy_search'
MODE_ALL_CATEGORIES = 'all_categories'

# Day of week colors
DAY_COLORS = {
    'Monday': '\033[91m',  # Red
    'Tuesday': '\033[38;5;208m',  # Orange
    'Wednesday': '\033[93m',  # Yellow
    'Thursday': '\033[92m',  # Green
    'Friday': '\033[94m',  # Blue
    'Saturday': '\033[95m',  # Magenta
    'Sunday': '\033[96m',  # Cyan
}

DAY_ABBREVIATIONS = {
    'Monday': 'Mon',
    'Tuesday': 'Tue',
    'Wednesday': 'Wed',
    'Thursday': 'Thu',
    'Friday': 'Fri',
    'Saturday': 'Sat',
    'Sunday': 'Sun',
}

# Optional dependency availability flags — detected at import time
# so all consumers get the correct value regardless of import order.
try:
    from filelock import FileLock  # noqa: F401
    FILELOCK_AVAILABLE = True
except ImportError:
    FILELOCK_AVAILABLE = False

try:
    from google.auth.transport.requests import Request  # noqa: F401
    GCAL_AVAILABLE = True
except ImportError:
    GCAL_AVAILABLE = False

try:
    import pyttsx3  # noqa: F401
    TTS_AVAILABLE = True
except ImportError:
    TTS_AVAILABLE = False
