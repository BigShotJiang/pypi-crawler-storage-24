"""CRUD mixin — add, get, edit tasks and schema migration."""

import sys
from datetime import datetime, timezone
from pathlib import Path


class CrudMixin:
    """Task creation, retrieval, editing, and schema migration."""

    def add_task(self, task_text, priority='none', status='todo',
                 labels=None, effort=None):
        """Add a new task with guaranteed unique ID from IDManager.

        Returns:
            int or dict: Task ID for normal adds, or routing metadata dict
            if task targets another project or broadcast.
        """
        now = datetime.now(timezone.utc).isoformat()

        keyword, task_text, project_name = \
            self.keyword_handler.extract_keyword(task_text)

        # Return routing info so the caller can confirm before executing
        if project_name and self.keyword_handler.project_registry:
            return {
                'action': ('broadcast'
                           if project_name == '__all__' else 'route'),
                'project_name': project_name,
                'task_text': task_text,
                'priority': priority, 'status': status,
                'labels': labels, 'effort': effort,
            }

        new_id = self.id_manager.allocate_id()
        new_id = self._validate_unique_id(new_id)

        task = {
            'id': new_id, 'text': task_text, 'done': False,
            'current': False, 'day': None, 'tally': 0,
            'agent_task': False, 'highlight': False,
            'priority': priority, 'status': status,
            'created_at': now, 'updated_at': now,
            'labels': labels if labels is not None else [],
            'effort': effort, 'blocked_by': [],
            'notes': '', 'keyword': keyword,
        }

        self.tasks.append(task)
        self._save_tasks()

        if keyword:
            result = self.keyword_handler.handle(keyword, task)
            if result:
                self._save_tasks()

        return new_id

    def _route_to_project(self, task_text, project_name,
                          priority, status, labels, effort):
        """Route task to project(s).

        Returns:
            int: Number of projects that received the task,
                 or 0 if the target project was not found.
        """
        from jot.core.task_manager import TaskManager

        if project_name == "__all__":
            projects = self.keyword_handler.project_registry.list_projects()
            count = 0
            seen_paths = set()
            for _name, proj_path in projects.items():
                resolved = str(Path(proj_path).resolve())
                if resolved in seen_paths:
                    continue
                seen_paths.add(resolved)
                target_tm = TaskManager(
                    directory=proj_path, category=None,
                    project_registry=self.keyword_handler.project_registry)
                all_texts = [t['text']
                             for t in target_tm.tasks + target_tm.archived]
                if task_text not in all_texts:
                    target_tm.add_task(task_text, priority=priority,
                                       status=status, labels=labels,
                                       effort=effort)
                    count += 1
            return count

        target_path = self.keyword_handler.project_registry.get_project_path(
            project_name)
        if target_path:
            target_tm = TaskManager(
                directory=target_path, category=None,
                project_registry=self.keyword_handler.project_registry)
            target_tm.add_task(task_text, priority=priority,
                               status=status, labels=labels, effort=effort)
            return 1
        return 0

    def _validate_unique_id(self, new_id):
        """Validate ID uniqueness, auto-fix on collision."""
        existing_ids = {t['id'] for t in self.tasks + self.archived if 'id' in t}
        if new_id not in existing_ids:
            return new_id

        print(f"WARNING: Duplicate ID {new_id} detected during task creation. "
              f"This indicates a concurrency issue. Auto-fixing...",
              file=sys.stderr)
        self.id_manager._load_ids()
        new_id = self.id_manager.allocate_id()

        if new_id in existing_ids:
            raise ValueError(
                f"Critical error: Unable to allocate unique ID. "
                f"ID {new_id} already exists. Please check .jot.ids.json")
        return new_id

    def ensure_default_task(self):
        """Create default 'take a break' task if no tasks exist"""
        if not self.tasks and not self.archived:
            self.add_task("take a break")

    def get_tasks(self):
        """Return all tasks"""
        return self.tasks

    def get_current_task(self):
        """Get the currently selected task"""
        for task in self.tasks:
            if task.get('current', False):
                return task
        return None

    def get_task_notes(self, task_id):
        """Get notes for a task"""
        for task in self.tasks:
            if task['id'] == task_id:
                return task.get('notes', '')
        return ''

    def edit_task(self, task_id, new_text):
        """Edit a task's text by ID"""
        for task in self.tasks:
            if task['id'] == task_id:
                task['text'] = new_text
                self._save_tasks()
                return True
        return False

    def set_task_notes(self, task_id, notes_text):
        """Set notes for a task"""
        for task in self.tasks:
            if task['id'] == task_id:
                task['notes'] = notes_text
                task['updated_at'] = datetime.now(timezone.utc).isoformat()
                self._save_tasks()
                return True
        return False

    def migrate_backlog_schema(self):
        """Migrate existing tasks to include backlog grooming metadata.

        Returns:
            dict: Migration statistics
        """
        now = datetime.now(timezone.utc).isoformat()
        migrated_count = already_migrated = 0

        _REQUIRED = ('priority', 'status', 'created_at', 'updated_at',
                     'labels', 'effort', 'blocked_by', 'notes', 'keyword')
        _DEFAULTS = {
            'priority': 'none', 'created_at': now, 'updated_at': now,
            'labels': [], 'effort': None, 'blocked_by': [],
            'notes': '', 'keyword': None,
        }

        for task in self.tasks + self.archived:
            if all(k in task for k in _REQUIRED):
                already_migrated += 1
                continue

            # status inferred from done field
            if 'status' not in task:
                task['status'] = 'done' if task.get('done', False) else 'todo'

            for key, default in _DEFAULTS.items():
                if key not in task:
                    task[key] = default if not isinstance(default, list) else []

            migrated_count += 1

        if migrated_count > 0:
            self._save_tasks()

        return {
            'migrated': migrated_count,
            'already_migrated': already_migrated,
            'total': migrated_count + already_migrated,
        }
