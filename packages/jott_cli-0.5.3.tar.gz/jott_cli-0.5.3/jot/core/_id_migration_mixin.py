"""ID migration mixin — migrate and auto-fix task IDs."""

from collections import Counter
from datetime import datetime


class IdMigrationMixin:
    """Migrate existing IDs to IDManager and fix duplicates."""

    def _migrate_ids_if_needed(self):
        """Migrate existing task IDs to IDManager on first load"""
        existing_ids = [t['id'] for t in self.tasks + self.archived if 'id' in t]
        if not existing_ids:
            return

        max_existing = max(existing_ids)
        if self.id_manager.next_id <= max_existing:
            self.id_manager.next_id = max_existing + 1

        # Add any missing IDs to allocated list
        missing = set(existing_ids) - set(self.id_manager.allocated)
        if missing:
            self.id_manager.allocated.extend(sorted(missing))
            self.id_manager.allocated = sorted(set(self.id_manager.allocated))
            self.id_manager._save_ids()

        self._autofix_duplicate_ids()

    def _autofix_duplicate_ids(self):
        """Detect and automatically fix duplicate task IDs.
        Creates backup before fixing and shows warning to user."""
        all_tasks = self.tasks + self.archived
        ids = [t['id'] for t in all_tasks if 'id' in t]

        id_counts = Counter(ids)
        duplicates = {tid: c for tid, c in id_counts.items() if c > 1}
        if not duplicates:
            return

        # Create backup before fixing
        now = datetime.now()
        backup_dir = (self.storage_file.parent / '.jot-backups'
                      / now.strftime("%Y-%m"))
        backup_dir.mkdir(parents=True, exist_ok=True)

        backup_file = backup_dir / f'{now.strftime("%Y%m%d_%H%M%S")}.json'
        with open(self.storage_file, 'r') as f:
            backup_data = f.read()
        with open(backup_file, 'w') as f:
            f.write(backup_data)

        # Keep first occurrence, reassign subsequent duplicates
        seen_ids = set()
        tasks_to_fix = []

        for idx, task in enumerate(self.tasks):
            tid = task.get('id')
            if tid in duplicates:
                if tid in seen_ids:
                    tasks_to_fix.append((task, 'tasks', idx))
                else:
                    seen_ids.add(tid)

        for idx, task in enumerate(self.archived):
            tid = task.get('id')
            if tid in duplicates:
                if tid in seen_ids:
                    tasks_to_fix.append((task, 'archived', idx))
                else:
                    seen_ids.add(tid)

        # Reassign IDs
        old_to_new = {}
        for task, _list_name, _idx in tasks_to_fix:
            old_id = task['id']
            new_id = self.id_manager.allocate_id()
            task['id'] = new_id
            old_to_new.setdefault(old_id, []).append(new_id)

        self._save_tasks()

        # Lazy import to avoid circular dependency (core -> ui)
        from jot.ui.styles import YELLOW, RESET, DIM

        print(f"\n{YELLOW}\u26a0 Auto-fixed duplicate task IDs{RESET}")
        print(f"  Backup: {DIM}{backup_file}{RESET}")
        changes = [f"{old} \u2192 {', '.join(map(str, new))}"
                   for old, new in sorted(old_to_new.items())]
        print(f"  Changed: {', '.join(changes)}")
        print()

    def _get_next_id(self):
        """DEPRECATED: Use id_manager.allocate_id() instead."""
        max_id = 0
        for task in self.tasks + self.archived:
            if task.get('id', 0) > max_id:
                max_id = task['id']
        return max_id + 1
