"""Persistence mixin — load, save, refresh."""

import json


class PersistenceMixin:
    """Load and save tasks to JSON file."""

    def _load_tasks(self):
        """Load tasks from JSON file"""
        if self.storage_file.exists():
            try:
                with open(self.storage_file, 'r') as f:
                    data = json.load(f)
                    # Handle old format (list) and new format (dict)
                    if isinstance(data, list):
                        self.tasks = data
                        self.archived = []
                    else:
                        self.tasks = data.get('tasks', [])
                        self.archived = data.get('archived', [])
            except json.JSONDecodeError:
                self.tasks = []
                self.archived = []
        else:
            self.tasks = []
            self.archived = []

    def _save_tasks(self):
        """Save tasks to JSON file"""
        # Ensure parent directory exists
        self.storage_file.parent.mkdir(parents=True, exist_ok=True)

        with open(self.storage_file, 'w') as f:
            json.dump({'tasks': self.tasks, 'archived': self.archived}, f, indent=2)

    def refresh(self):
        """Reload tasks from file"""
        self._load_tasks()
