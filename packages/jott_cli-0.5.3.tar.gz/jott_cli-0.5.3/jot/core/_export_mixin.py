"""Export mixin — archive export to JSON, CSV, Markdown, text."""

import csv
import json
from datetime import datetime
from pathlib import Path


class ExportMixin:
    """Export archived tasks in multiple formats."""

    def export_archives(self, format='json', output=None,
                        include_compressed=True, category=None):
        """Export archived tasks to various formats.

        Args:
            format: 'json', 'csv', 'markdown', or 'text'
            output: Output file path (or None for auto-named file)
            include_compressed: Include tasks from compressed archives
            category: Export specific category only

        Returns:
            dict with export results
        """
        archived_tasks = self._read_task_manager_archives(category)

        if include_compressed:
            for archive_file in self._get_archive_files():
                archived_tasks.extend(
                    self._read_compressed_archive(archive_file))

        if not archived_tasks:
            return {'error': 'No archived tasks found'}

        if output:
            output_path = Path(output)
        else:
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            output_path = (self.project_dir
                           / f'jot_archive_export_{timestamp}.{format}')

        exporters = {
            'json': self._export_json,
            'csv': self._export_csv,
            'markdown': self._export_markdown,
            'text': self._export_text,
        }
        exporter = exporters.get(format)
        if not exporter:
            return {'error': f'Unknown format: {format}'}

        exporter(archived_tasks, output_path)

        return {
            'exported': len(archived_tasks),
            'format': format,
            'output': str(output_path),
        }

    @staticmethod
    def _export_json(tasks, output_path):
        """Export to JSON format"""
        export_data = {
            'exported_at': datetime.now().isoformat(),
            'task_count': len(tasks),
            'tasks': tasks,
        }
        with open(output_path, 'w') as f:
            json.dump(export_data, f, indent=2)

    @staticmethod
    def _export_csv(tasks, output_path):
        """Export to CSV format"""
        fieldnames = [
            'id', 'text', 'done', 'current', 'day',
            'priority', 'status', 'tally', 'time_spent',
        ]
        with open(output_path, 'w', newline='') as f:
            writer = csv.DictWriter(
                f, fieldnames=fieldnames, extrasaction='ignore')
            writer.writeheader()
            for task in tasks:
                writer.writerow(task)

    @staticmethod
    def _export_markdown(tasks, output_path):
        """Export to Markdown format"""
        with open(output_path, 'w') as f:
            f.write('# Archived Tasks\n\n')
            f.write(f'Exported: {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}\n\n')
            f.write(f'Total tasks: {len(tasks)}\n\n---\n\n')

            for task in tasks:
                f.write(f'## Task #{task["id"]}\n\n')
                f.write(f'**Text:** {task["text"]}\n\n')
                if task.get('done'):
                    f.write('**Status:** Done\n\n')
                if task.get('day'):
                    f.write(f'**Day:** {task["day"]}\n\n')
                if task.get('priority', 'none') != 'none':
                    f.write(f'**Priority:** {task["priority"]}\n\n')
                if task.get('tally', 0) > 0:
                    f.write(f'**Tally:** {task["tally"]}\n\n')
                if task.get('time_spent'):
                    f.write(f'**Time Spent:** {task["time_spent"]}\n\n')
                f.write('---\n\n')

    @staticmethod
    def _export_text(tasks, output_path):
        """Export to plain text format"""
        with open(output_path, 'w') as f:
            f.write('ARCHIVED TASKS\n')
            f.write('=' * 60 + '\n\n')
            f.write(f'Exported: {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}\n')
            f.write(f'Total tasks: {len(tasks)}\n\n')

            for i, task in enumerate(tasks, 1):
                f.write(f'{i}. [{task["id"]}] {task["text"]}\n')
                details = []
                if task.get('done'):
                    details.append('Done')
                if task.get('day'):
                    details.append(f'Day: {task["day"]}')
                if task.get('priority', 'none') != 'none':
                    details.append(f'Priority: {task["priority"]}')
                if task.get('tally', 0) > 0:
                    details.append(f'Tally: {task["tally"]}')
                if details:
                    f.write(f'   {" | ".join(details)}\n')
                f.write('\n')
