"""Archive management for jot tasks: compress, export, prune."""

import json
import re
from datetime import datetime, timedelta
from pathlib import Path

from jot.categories.manager import CategoryManager
from jot.core._compress_mixin import CompressMixin
from jot.core._export_mixin import ExportMixin


class ArchiveManager(ExportMixin, CompressMixin):
    """Manages archived tasks: compress, export, prune"""

    def __init__(self, project_dir=None):
        """Initialize ArchiveManager for a project directory"""
        self.project_dir = Path(project_dir) if project_dir else Path.cwd()
        self.config = self._load_config()

    def _load_config(self):
        """Load archive configuration"""
        config_file = self.project_dir / '.jot.config.json'
        defaults = {
            'archive': {
                'keep_in_main': 20,
                'compress_by': 'month',
                'auto_compress': False,
                'auto_prune_months': None,
            }
        }

        if config_file.exists():
            try:
                with open(config_file) as f:
                    user_config = json.load(f)
                    if 'archive' in user_config:
                        defaults['archive'].update(user_config['archive'])
            except (json.JSONDecodeError, OSError):
                pass

        return defaults['archive']

    def _get_archive_files(self):
        """Find all archive files (.jot.archive.*.tar.gz)"""
        return sorted(self.project_dir.glob('.jot.archive.*.tar.gz'))

    def _read_task_manager_archives(self, category=None):
        """Read archived tasks from TaskManager files"""
        all_archived = []

        if category:
            storage_file = (self.project_dir / '.jot.json' if category == 'default'
                            else self.project_dir / f'.jot.{category}.json')
            if storage_file.exists():
                with open(storage_file) as f:
                    data = json.load(f)
                    all_archived.extend(data.get('archived', []))
        else:
            cat_mgr = CategoryManager(self.project_dir)
            default_file = self.project_dir / '.jot.json'
            if default_file.exists():
                with open(default_file) as f:
                    data = json.load(f)
                    all_archived.extend(data.get('archived', []))
            for cat in cat_mgr.discover_categories():
                cat_file = self.project_dir / f'.jot.{cat}.json'
                if cat_file.exists():
                    with open(cat_file) as f:
                        data = json.load(f)
                        all_archived.extend(data.get('archived', []))

        return all_archived

    @staticmethod
    def _read_compressed_archive(archive_file):
        """Read tasks from a compressed archive file"""
        try:
            import tarfile
            with tarfile.open(archive_file, 'r:gz') as tar:
                member = tar.getmember('archive.json')
                f = tar.extractfile(member)
                if f:
                    data = json.load(f)
                    return data.get('tasks', [])
        except Exception:
            return []
        return []

    def prune_archives(self, strategy='older_than', value=None,
                       interactive=False):
        """Remove old archived tasks.

        Args:
            strategy: 'older_than' (months), 'keep_last' (count), or 'file'
            value: Strategy-specific value
            interactive: Show confirmation dialog
        """
        archive_files = self._get_archive_files()
        if not archive_files:
            return {'message': 'No compressed archive files found'}

        files_to_delete = self._select_files_to_prune(
            archive_files, strategy, value)

        if not files_to_delete:
            return {'message': 'No archives match prune criteria'}

        if interactive and not self._confirm_prune(files_to_delete):
            return {'cancelled': True}

        deleted = 0
        for fp in files_to_delete:
            try:
                fp.unlink()
                deleted += 1
            except OSError as e:
                print(f'Error deleting {fp}: {e}')

        return {'deleted': deleted, 'files': [f.name for f in files_to_delete]}

    def _select_files_to_prune(self, archive_files, strategy, value):
        """Select archive files matching prune criteria."""
        if strategy == 'older_than' and value:
            cutoff = datetime.now() - timedelta(days=value * 30)
            result = []
            for af in archive_files:
                match = re.search(
                    r'\.jot\.archive\.(\d{4}-\d{2})\.tar\.gz', af.name)
                if match:
                    try:
                        if datetime.strptime(match.group(1), '%Y-%m') < cutoff:
                            result.append(af)
                    except ValueError:
                        pass
            return result

        if strategy == 'file' and value:
            target = self.project_dir / value
            return [target] if target.exists() else []

        return []

    @staticmethod
    def _confirm_prune(files_to_delete):
        """Show interactive confirmation for pruning."""
        print('\nFiles to delete:')
        for f in files_to_delete:
            print(f'  - {f.name} ({f.stat().st_size} bytes)')
        print(f'\nTotal: {len(files_to_delete)} files')
        return input('\nProceed with deletion? (y/N): ').strip().lower() == 'y'

    def get_archive_stats(self):
        """Get statistics about archives"""
        archived_in_main = self._read_task_manager_archives()
        archive_files = self._get_archive_files()

        archived_in_compressed = []
        for af in archive_files:
            archived_in_compressed.extend(self._read_compressed_archive(af))

        total_size = sum(f.stat().st_size for f in archive_files)
        all_tasks = archived_in_main + archived_in_compressed

        dates = []
        for task in all_tasks:
            for field in ['updated_at', 'created_at']:
                if field in task:
                    try:
                        dt = datetime.fromisoformat(
                            task[field].replace('Z', '+00:00'))
                        dates.append(dt)
                        break
                    except (ValueError, AttributeError):
                        pass

        return {
            'total_archived': len(all_tasks),
            'in_main_files': len(archived_in_main),
            'in_compressed': len(archived_in_compressed),
            'compressed_files': len(archive_files),
            'total_size_bytes': total_size,
            'oldest_task': min(dates).strftime('%Y-%m-%d') if dates else None,
            'newest_task': max(dates).strftime('%Y-%m-%d') if dates else None,
            'archive_files': [f.name for f in archive_files],
        }
