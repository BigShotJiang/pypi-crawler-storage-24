"""Task management and storage for jot"""

# Module-level imports preserved for test compatibility (test_jot.py checks these)
import json  # noqa: F401
import os  # noqa: F401
import re  # noqa: F401
import sys  # noqa: F401
import uuid  # noqa: F401
from collections import Counter  # noqa: F401
from datetime import datetime, timezone
from pathlib import Path

from jot.core.id_manager import IDManager
from jot.categories.manager import CategoryManager
from jot.integrations.keywords.handler import KeywordHandler
from jot.utils.validation import validate_safe_name

from jot.core._persistence_mixin import PersistenceMixin
from jot.core._id_migration_mixin import IdMigrationMixin
from jot.core._crud_mixin import CrudMixin
from jot.core._metadata_mixin import MetadataMixin
from jot.core._delete_mixin import DeleteMixin
from jot.core._navigation_mixin import NavigationMixin
from jot.core._subtask_mixin import SubtaskMixin
from jot.core._age_backlog_mixin import AgeBacklogMixin


class TaskManager(
    PersistenceMixin, IdMigrationMixin, CrudMixin, MetadataMixin,
    DeleteMixin, NavigationMixin, SubtaskMixin, AgeBacklogMixin,
):
    """Handles task storage and retrieval"""

    def __init__(
        self,
        storage_file='.jot.json',
        directory=None,
        id_manager=None,
        category=None,
        is_global=False,
        project_registry=None,
    ):
        """Initialize TaskManager.

        Args:
            storage_file: Base filename (used only if category is None and not global)
            directory: Project directory (ignored if is_global=True)
            id_manager: Shared IDManager instance
            category: Category name (validated for path traversal safety)
            is_global: If True, use global category storage in ~/.jot-categories/
            project_registry: Optional ProjectRegistry for keyword-based project routing
        """
        # Validate category name for security (prevent path traversal)
        if category and category != 'default':
            category = validate_safe_name(category, "category name")

        self.category = category
        self.is_global = is_global

        if is_global:
            self._init_global_storage(category, id_manager)
        else:
            self._init_local_storage(directory, category, storage_file,
                                     id_manager)

        self.tasks = []
        self.archived = []
        self._load_tasks()

        # Migrate existing IDs to IDManager if needed
        self._migrate_ids_if_needed()

        # Initialize keyword handler for automation
        self.keyword_handler = KeywordHandler(
            project_registry=project_registry)

    def _init_global_storage(self, category, id_manager):
        """Set up global category storage (~/.jot-categories/)."""
        global_dir = CategoryManager.GLOBAL_CATEGORIES_DIR
        global_dir.mkdir(parents=True, exist_ok=True)
        self.project_dir = global_dir

        filename = f'{category}.json' if category else 'default.json'
        self.storage_file = self.project_dir / filename

        if id_manager:
            self.id_manager = id_manager
        else:
            ids_file = self.project_dir / f'{category or "default"}.ids.json'
            self.id_manager = IDManager(project_dir=self.project_dir)
            self.id_manager.ids_file = ids_file
            self.id_manager._load_ids()

    def _init_local_storage(self, directory, category, storage_file,
                            id_manager):
        """Set up local project storage."""
        self.project_dir = Path(directory) if directory else Path.cwd()

        if category:
            categories_dir = self.project_dir / '.jot-categories'
            categories_dir.mkdir(exist_ok=True)
            self.storage_file = categories_dir / f'{category}.json'
        else:
            self.storage_file = self.project_dir / storage_file

        self.id_manager = id_manager if id_manager else IDManager(
            self.project_dir)
