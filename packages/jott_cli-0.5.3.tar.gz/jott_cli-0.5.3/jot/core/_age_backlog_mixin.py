"""Age and backlog mixin — staleness detection and task transfer."""

from datetime import datetime, timezone


class AgeBacklogMixin:
    """Task age analysis, staleness detection, and backlog transfer."""

    def get_task_age_days(self, task):
        """Calculate age of task in days since last update."""
        updated_at = task.get('updated_at')
        if not updated_at:
            return None

        try:
            updated_dt = datetime.fromisoformat(
                updated_at.replace('Z', '+00:00'))
            return (datetime.now(timezone.utc) - updated_dt).days
        except (ValueError, AttributeError):
            return None

    def is_task_stale(self, task, stale_threshold_days=7):
        """Check if a task is considered stale."""
        if task.get('done', False) or task.get('status') == 'done':
            return False

        age = self.get_task_age_days(task)
        if age is None:
            return False
        return age >= stale_threshold_days

    def transfer_old_tasks_to_backlog(self, age_threshold_days=30,
                                      backlog_category='backlog'):
        """Transfer tasks older than threshold to backlog category.

        Returns:
            dict: Statistics about transferred tasks
        """
        from jot.categories.manager import CategoryManager
        from jot.core.task_manager import TaskManager

        if self.category == backlog_category:
            return {'transferred': 0, 'tasks': []}

        transferred = []
        for task in self.tasks[:]:  # slice copy for safe iteration
            if task.get('done', False) or task.get('status') == 'done':
                continue

            age = self.get_task_age_days(task)
            if age is None or age < age_threshold_days:
                continue

            task_data = task.copy()

            # Create backlog TaskManager
            _cat_manager = CategoryManager(project_dir=self.project_dir)
            backlog_tm = TaskManager(
                directory=self.project_dir,
                category=backlog_category,
                project_registry=self.keyword_handler.project_registry,
            )

            backlog_tm.add_task(
                task_data['text'],
                priority=task_data.get('priority', 'none'),
                status=task_data.get('status', 'todo'),
                labels=task_data.get('labels', []),
                effort=task_data.get('effort', None),
            )

            # Restore metadata on the newly created task
            new_task = backlog_tm.tasks[-1]
            new_task['notes'] = task_data.get('notes', '')
            new_task['agent_task'] = task_data.get('agent_task', False)
            new_task['keyword'] = task_data.get('keyword', None)
            new_task['day'] = task_data.get('day', None)
            new_task['tally'] = task_data.get('tally', 0)
            if 'created_at' in task_data:
                new_task['created_at'] = task_data['created_at']
            backlog_tm._save_tasks()

            self.tasks.remove(task)
            transferred.append({
                'id': task_data['id'], 'text': task_data['text'], 'age': age,
            })

        if transferred:
            self._save_tasks()

        return {'transferred': len(transferred), 'tasks': transferred}
