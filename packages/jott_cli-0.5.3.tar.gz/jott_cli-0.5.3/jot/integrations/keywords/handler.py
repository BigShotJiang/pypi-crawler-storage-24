"""Keyword detection and action routing for task automation"""

from jot.integrations.keywords._config_mixin import ConfigMixin
from jot.integrations.keywords._handlers_mixin import HandlersMixin


class KeywordHandler(ConfigMixin, HandlersMixin):
    """Manages keyword detection and action routing for task automation"""

    MAX_KEYWORD_LENGTH = 50

    def __init__(self, project_registry=None):
        """Initialize keyword handler with built-in handlers.

        Args:
            project_registry: Optional ProjectRegistry for project name routing
        """
        self.handlers = {}
        self.config = {}
        self.aliases = {}
        self.project_registry = project_registry
        self._register_builtin_handlers()
        self._load_config()

    def extract_keyword(self, task_text):
        """Extract keyword from task text if present.

        Keyword format: "keyword: rest of task text"
        - First word must end with ':'
        - Keyword must be alphanumeric + hyphens/underscores
        - Case-insensitive (normalized to lowercase)
        - Project names are checked first before treating as action keyword

        Returns:
            tuple: (keyword, original_text, project_name) or (None, text, None)
        """
        if ':' not in task_text:
            return None, task_text, None

        parts = task_text.split(':', 1)
        if len(parts) != 2:
            return None, task_text, None

        first_word = parts[0].strip()

        if len(first_word) > self.MAX_KEYWORD_LENGTH:
            return None, task_text, None

        if not (first_word
                and first_word.replace('-', '').replace('_', '').isalnum()):
            return None, task_text, None

        keyword_lower = first_word.lower()

        # "all" broadcasts to all registered projects
        if keyword_lower == 'all':
            return None, parts[1].strip(), "__all__"

        # Check if this matches a registered project name
        if self.project_registry:
            for project_name in self.project_registry.list_projects():
                if project_name.lower() == keyword_lower:
                    return None, parts[1].strip(), project_name

        return keyword_lower, task_text, None

    def register(self, keyword, handler_func, auto_trigger=False,
                 description=""):
        """Register a keyword action handler."""
        keyword = keyword.lower()
        self.handlers[keyword] = handler_func
        self.config[keyword] = {
            'auto_trigger': auto_trigger, 'description': description}

    def handle(self, keyword, task):
        """Execute handler for detected keyword.

        Returns:
            str: Result message from handler, or None if not registered
        """
        actual_keyword = keyword
        if hasattr(self, 'aliases') and keyword in self.aliases:
            actual_keyword = self.aliases[keyword]

        if actual_keyword not in self.handlers:
            return None

        try:
            return self.handlers[actual_keyword](task)
        except Exception as e:
            return f"Error executing {keyword}: {str(e)}"

    def get_config(self, keyword):
        """Get configuration for a keyword"""
        return self.config.get(keyword.lower())

    def list_keywords(self):
        """List all registered keywords with their configurations"""
        return {k: v for k, v in self.config.items()}
