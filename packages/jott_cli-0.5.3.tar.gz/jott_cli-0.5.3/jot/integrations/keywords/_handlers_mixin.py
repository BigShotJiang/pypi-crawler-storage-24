"""Handlers mixin — built-in keyword action handlers."""

import json
import platform
import subprocess
from datetime import datetime
from pathlib import Path

from jot.core.constants import GCAL_AVAILABLE

if GCAL_AVAILABLE:
    from jot.integrations.gcal.account_manager import GoogleCalendarAccountManager
    from jot.integrations.gcal.auth import GoogleCalendarAuth
    from jot.integrations.gcal.events import create_gcal_event

_ANALYSIS_PROMPT = """\
Analyze this task and provide a structured implementation plan in org-mode format.

Task: {task}{notes}

Create an org-mode document with sections: Task Analysis (Overview, Task \
Breakdown with checklist, Technical Approach, Acceptance Criteria, Complexity \
Estimate, Potential Risks)."""


class HandlersMixin:
    """Built-in keyword action handlers."""

    def _register_builtin_handlers(self):
        """Register built-in keyword handlers"""
        self.register('bullet', self._handle_bullet, auto_trigger=True,
                      description="Start bullet priority timer")
        self.register('gcal', self._handle_gcal, auto_trigger=True,
                      description="Export to Google Calendar")
        self.register('ai', self._handle_ai, auto_trigger=True,
                      description="Mark as AI/agent task")
        self.register('remind', self._handle_remind, auto_trigger=False,
                      description="Set system notification")
        self.register('analyze', self._handle_analyze, auto_trigger=True,
                      description="Analyze task with Claude Code AI")

    @staticmethod
    def _handle_bullet(task):
        """Start bullet priority timer automatically"""
        try:
            subprocess.Popen(['bullet', 'priority'],
                             stdout=subprocess.DEVNULL,
                             stderr=subprocess.DEVNULL)
            return "Started bullet priority timer"
        except FileNotFoundError:
            return "bullet command not found (install: cd ~/projects/bullet && npm link)"

    @staticmethod
    def _handle_gcal(task):
        """Export task to Google Calendar automatically"""
        if not GCAL_AVAILABLE:
            return "Google Calendar API not available (install google-auth packages)"
        try:
            account_manager = GoogleCalendarAccountManager()
            accounts = account_manager.discover_accounts()
            if not accounts:
                return "No Google Calendar accounts configured (use Shift+G to set up)"
            auth = GoogleCalendarAuth(accounts[0])
            service = auth.get_service()
            notes = task.get('notes', '').strip()
            create_gcal_event(service, task['text'],
                              description=notes or None)
            return f"Created Google Calendar event ({accounts[0]})"
        except FileNotFoundError:
            return "Google Calendar credentials not found (use Shift+G to set up)"
        except Exception as e:
            return f"Failed to create calendar event: {str(e)}"

    @staticmethod
    def _handle_ai(task):
        """Mark task as AI/agent task"""
        task['agent_task'] = True
        return "Marked as AI/agent task"

    @staticmethod
    def _handle_remind(task):
        """Set system notification (macOS)"""
        if platform.system() != 'Darwin':
            return "Reminders only supported on macOS"
        try:
            safe_text = json.dumps(task['text'])[1:-1]
            script = (f'display notification "{safe_text}" '
                      f'with title "Jot Reminder" sound name "Ping"')
            subprocess.run(['osascript', '-e', script],
                           stdout=subprocess.DEVNULL,
                           stderr=subprocess.DEVNULL, check=True)
            return "System notification displayed"
        except subprocess.CalledProcessError:
            return "Failed to display notification"
        except Exception as e:
            return f"Notification error: {str(e)}"

    def _handle_analyze(self, task):
        """Analyze task with Claude Code in planning mode"""
        task_text = task['text']
        if task_text.lower().startswith('analyze:'):
            task_text = task_text[8:].strip()

        notes = task.get('notes', '')
        notes_section = f"\n\nTask Notes:\n{notes}" if notes else ""
        prompt = _ANALYSIS_PROMPT.format(task=task_text, notes=notes_section)

        if not self._check_claude_available():
            return "Claude CLI not found. Install: https://claude.com/claude-code"

        return self._run_claude_analysis(prompt, task, task_text)

    @staticmethod
    def _check_claude_available():
        """Check if Claude CLI is available."""
        try:
            r = subprocess.run(['claude', '--version'],
                               capture_output=True, timeout=5)
            return r.returncode == 0
        except (FileNotFoundError, subprocess.TimeoutExpired):
            return False

    @staticmethod
    def _run_claude_analysis(prompt, task, task_text):
        """Run Claude analysis and save results."""
        try:
            result = subprocess.run(
                ['claude', '--print', '--permission-mode', 'plan',
                 '--output-format', 'json', '--max-turns', '5'],
                input=prompt, capture_output=True, text=True, timeout=120)

            if result.returncode != 0:
                stderr = (result.stderr or '').lower()
                if 'authentication' in stderr or 'login' in stderr:
                    return "Claude auth expired. Run: claude login"
                if 'network' in stderr or 'connection' in stderr:
                    return "Network error. Check connection and try again"
                return f"Claude failed: {(result.stderr or '')[:100]}"

            response = json.loads(result.stdout)
            analysis_text = response.get('result', '')
            if not analysis_text:
                return "Empty response from Claude"

            output_file = Path.cwd() / f".jot.analysis.{task['id']}.org"
            with open(output_file, 'w') as f:
                f.write(f"#+TITLE: Analysis for Task {task['id']}\n")
                f.write(f"#+DATE: {datetime.now().strftime('%Y-%m-%d %H:%M')}\n")
                f.write(f"#+TASK: {task_text}\n\n")
                f.write(analysis_text)

            task['analysis_file'] = str(output_file)
            cost = response.get('total_cost_usd', 0)
            cost_str = f" (${cost:.3f})" if cost > 0 else ""
            return f"Analysis saved to {output_file.name}{cost_str}"

        except json.JSONDecodeError:
            return "Failed to parse Claude response"
        except subprocess.TimeoutExpired:
            return "Analysis timed out (120s)"
        except Exception as e:
            return f"Analysis error: {str(e)}"
