"""Config mixin — load and create keyword configuration."""

import json
from pathlib import Path


class ConfigMixin:
    """Keyword configuration file management."""

    def _load_config(self):
        """Load user configuration from ~/.jot-keywords.json"""
        config_file = Path.home() / '.jot-keywords.json'

        if not config_file.exists():
            self._create_default_config(config_file)
            return

        try:
            with open(config_file, 'r') as f:
                user_config = json.load(f)

            for keyword, settings in user_config.get('keywords', {}).items():
                if keyword.lower() in self.config:
                    self.config[keyword.lower()].update(settings)

            self.aliases = user_config.get('aliases', {})

        except (json.JSONDecodeError, IOError) as e:
            print(f"Warning: Failed to load keyword config: {e}")

    @staticmethod
    def _create_default_config(config_file):
        """Create default keyword configuration file"""
        default_config = {
            "_comment": "Jot Keyword Configuration",
            "keywords": {
                "bullet": {
                    "auto_trigger": True,
                    "description": "Start bullet priority timer",
                },
                "gcal": {
                    "auto_trigger": True,
                    "description": "Export task to Google Calendar",
                },
                "ai": {
                    "auto_trigger": True,
                    "description": "Mark task for AI/agent assistance",
                },
                "remind": {
                    "auto_trigger": False,
                    "description": "Set system notification",
                },
                "analyze": {
                    "auto_trigger": True,
                    "description": "Analyze task with Claude Code AI",
                },
            },
            "aliases": {
                "timer": "bullet",
                "cal": "gcal",
                "claude": "ai",
            },
        }

        try:
            with open(config_file, 'w') as f:
                json.dump(default_config, f, indent=2)
        except IOError as e:
            print(f"Warning: Failed to create keyword config: {e}")
