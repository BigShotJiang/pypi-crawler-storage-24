"""Day, today, and week CLI view commands."""

from jot.core.constants import DAY_COLORS, DAY_ABBREVIATIONS
from jot.core.task_manager import TaskManager
from jot.utils.date_utils import get_today_day_name
from jot.ui.styles import RESET, BOLD


def _format_task_line(task):
    """Format a single task for CLI display."""
    status = "✓" if task.get('done', False) else " "
    is_current = "✨ " if task.get('current', False) else ""
    return f"  [{status}] {task['id']}. {is_current}{task['text']}"


def show_day(registry, day_arg):
    """Handle --day command."""
    day_filter = day_arg.capitalize()
    valid_days = [
        'Monday', 'Tuesday', 'Wednesday', 'Thursday',
        'Friday', 'Saturday', 'Sunday',
    ]
    if day_filter not in valid_days:
        print(f"✗ Invalid day: {day_filter}")
        print(f"Valid days: {', '.join(valid_days)}")
        return

    task_manager = TaskManager(project_registry=registry)
    filtered = [t for t in task_manager.get_tasks() if t.get('day') == day_filter]

    day_color = DAY_COLORS[day_filter]
    day_abbrev = DAY_ABBREVIATIONS[day_filter]

    print(f"\n{BOLD}Tasks for {day_color}{day_abbrev}{RESET} {BOLD}{day_filter}:{RESET}")
    print("=" * 50)

    if not filtered:
        print(f"\nNo tasks scheduled for {day_filter}")
    else:
        for task in filtered:
            print(_format_task_line(task))
        print(f"\nTotal: {len(filtered)} tasks")
    print("=" * 50 + "\n")


def show_today(registry):
    """Handle --today command."""
    today = get_today_day_name()
    task_manager = TaskManager(project_registry=registry)
    filtered = [t for t in task_manager.get_tasks() if t.get('day') == today]

    day_color = DAY_COLORS[today]
    day_abbrev = DAY_ABBREVIATIONS[today]

    print(f"\n{BOLD}Today's Tasks ({day_color}{day_abbrev}{RESET} {BOLD}{today}):{RESET}")
    print("=" * 50)

    if not filtered:
        print("\nNo tasks scheduled for today")
    else:
        for task in filtered:
            print(_format_task_line(task))
        print(f"\nTotal: {len(filtered)} tasks")
    print("=" * 50 + "\n")


def show_week(registry):
    """Handle --week command."""
    task_manager = TaskManager(project_registry=registry)
    all_tasks = task_manager.get_tasks()

    days_order = [
        'Sunday', 'Monday', 'Tuesday', 'Wednesday',
        'Thursday', 'Friday', 'Saturday',
    ]
    tasks_by_day = {day: [] for day in days_order}
    tasks_no_day = []

    for task in all_tasks:
        day = task.get('day')
        if day and day in tasks_by_day:
            tasks_by_day[day].append(task)
        elif not day:
            tasks_no_day.append(task)

    today = get_today_day_name()
    print(f"\n{BOLD}This Week's Tasks:{RESET}")
    print("=" * 50)

    total_count = 0
    for day in days_order:
        day_tasks = tasks_by_day[day]
        if day_tasks:
            day_color = DAY_COLORS[day]
            day_abbrev = DAY_ABBREVIATIONS[day]
            today_marker = " (Today)" if day == today else ""
            print(f"\n{day_color}{BOLD}{day_abbrev}{RESET} {BOLD}{day}{today_marker}:{RESET}")
            for task in day_tasks:
                print(_format_task_line(task))
                total_count += 1

    if tasks_no_day:
        print(f"\n{BOLD}No Day Assigned:{RESET}")
        for task in tasks_no_day:
            print(_format_task_line(task))

    print(f"\n{BOLD}Total:{RESET} {total_count} tasks with days assigned")
    print("=" * 50 + "\n")
