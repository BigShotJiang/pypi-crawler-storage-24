"""Color, template, and backup CLI commands."""

from pathlib import Path

from jot.categories.config import CategoryConfig
from jot.categories.templates import CategoryTemplates
from jot.core.task_manager import TaskManager
from jot.projects.backup import ProjectBackup
from jot.ui.styles import RESET, BOLD, DIM, CYAN


# -- Color commands --------------------------------------------------------

def show_colors():
    """Handle --colors command."""
    cat_config = CategoryConfig()
    colors = cat_config.list_available_colors()

    print(f"\n{BOLD}Available Colors:{RESET}")
    print("-" * 40)
    for color_name in colors:
        color_code = CategoryConfig.COLORS[color_name]
        print(f"  {color_code}{color_name:12}{RESET} - {color_code}■■■{RESET} Example text")
    print("-" * 40)
    print(f"\n{BOLD}Usage:{RESET}")
    print("  jot --set-color <category> <color>")
    print("  jot --list-colors")
    print("  jot --reset-colors")
    print()


def set_color(category_name, color_name):
    """Handle --set-color command."""
    cat_config = CategoryConfig()
    success, message = cat_config.set_color(category_name, color_name)
    if success:
        color_code = CategoryConfig.COLORS[color_name]
        print(f"✓ {message}")
        print(f"  Preview: {color_code}{category_name}{RESET}")
    else:
        print(f"✗ {message}")


def list_colors():
    """Handle --list-colors command."""
    cat_config = CategoryConfig()
    custom_colors = cat_config.get_all_colors()

    print(f"\n{BOLD}Configured Category Colors:{RESET}")
    print("-" * 40)

    if not custom_colors:
        print("  No custom colors configured.")
        print("  Using default colors.")
    else:
        for cat_name, color_name in sorted(custom_colors.items()):
            color_code = CategoryConfig.COLORS.get(color_name, '\033[96m')
            print(f"  {color_code}{cat_name:20}{RESET} → {color_name}")

    print("-" * 40)
    print(f"\n{BOLD}Default Colors:{RESET}")
    for cat_name, color_name in sorted(CategoryConfig.DEFAULT_COLORS.items()):
        if cat_name not in custom_colors:
            color_code = CategoryConfig.COLORS[color_name]
            print(f"  {color_code}{cat_name:20}{RESET} → {color_name}")
    print()


def reset_colors():
    """Handle --reset-colors command."""
    cat_config = CategoryConfig()
    cat_config.reset_colors()
    print("✓ Reset all colors to defaults")


# -- Template commands -----------------------------------------------------

def list_templates():
    """Handle --list-templates command."""
    templates_manager = CategoryTemplates()
    templates = templates_manager.list_templates()

    print(f"\n{BOLD}Available Category Templates:{RESET}")
    print("=" * 60)

    for template_id, template in sorted(templates.items()):
        print(f"\n{CYAN}{BOLD}{template_id}{RESET}")
        print(f"  {template['name']}")
        print(f"  {DIM}{template['description']}{RESET}")
        print(f"  Categories: {', '.join(template['categories'])}")

    print("\n" + "=" * 60)
    print(f"\n{BOLD}Usage:{RESET}")
    print("  jot --template <name>              # Apply template")
    print("  jot --template <name> --with-samples  # Include sample tasks")
    print()


def apply_template(template_name, with_samples):
    """Handle --template command."""
    templates_manager = CategoryTemplates()
    success, message = templates_manager.apply_template(
        template_name, with_samples=with_samples,
    )
    if success:
        print(f"✓ {message}")
        if with_samples:
            print("  Sample tasks added to each category")
        print("\n  Use Shift+C to switch between categories")
    else:
        print(f"✗ {message}")


# -- Backup commands -------------------------------------------------------

def backup(args):
    """Handle --backup command."""
    output_file = None
    if '--output' in args:
        idx = args.index('--output')
        if idx + 1 < len(args):
            output_file = args[idx + 1]

    backup_mgr = ProjectBackup()
    success, message = backup_mgr.create_backup(output_file)
    print(f"✓ {message}" if success else f"✗ {message}")


def restore(backup_file, force):
    """Handle --restore command."""
    backup_mgr = ProjectBackup()
    success, message = backup_mgr.restore_backup(backup_file, force=force)
    print(f"✓ {message}" if success else f"✗ {message}")


def list_backup(backup_file):
    """Handle --list-backup command."""
    backup_mgr = ProjectBackup()
    success, message = backup_mgr.list_backup_contents(backup_file)
    print(message if success else f"✗ {message}")


# -- Migration -------------------------------------------------------------

def migrate_backlog_schema(registry, category, explicit_global):
    """Handle --migrate-backlog-schema command."""
    print("\n🔄 Migrating tasks to backlog grooming schema...")
    print("This will add priority, status, labels, timestamps, "
          "effort, and blocked_by fields.\n")

    response = input("Proceed with migration? (y/N): ").strip().lower()
    if response != 'y':
        print("✗ Migration cancelled")
        return

    print("\n📦 Creating backup before migration...")
    backup_mgr = ProjectBackup()
    backup_success, backup_msg = backup_mgr.create_backup()

    if not backup_success:
        print(f"✗ Backup failed: {backup_msg}")
        print("Migration aborted for safety.")
        return

    print(f"✓ {backup_msg}\n")

    task_manager = TaskManager(
        storage_file='.jot.json',
        directory=Path.cwd(),
        category=category,
        is_global=explicit_global,
        project_registry=registry,
    )
    stats = task_manager.migrate_backlog_schema()

    print("✓ Migration complete!")
    print(f"\n  Migrated: {stats['migrated']} tasks")
    print(f"  Already migrated: {stats['already_migrated']} tasks")
    print(f"  Total tasks: {stats['total']} tasks\n")

    if stats['migrated'] > 0:
        print("New fields added:")
        print("  • priority: 'none' (default)")
        print("  • status: 'todo' or 'done' (based on existing done field)")
        print("  • created_at: current timestamp")
        print("  • updated_at: current timestamp")
        print("  • labels: [] (empty)")
        print("  • effort: null")
        print("  • blocked_by: [] (empty)\n")
