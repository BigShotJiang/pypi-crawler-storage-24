"""Archive-related CLI commands."""

from pathlib import Path

from jot.core.archive_manager import ArchiveManager
from jot.ui.styles import RESET, BOLD, CYAN


def handle_archive_compress(args, category):
    """Handle --archive-compress command."""
    archive_mgr = ArchiveManager(Path.cwd())
    keep_n = None
    if '--keep' in args:
        idx = args.index('--keep')
        if idx + 1 < len(args):
            try:
                keep_n = int(args[idx + 1])
            except ValueError:
                print("✗ --keep requires a number")
                return

    result = archive_mgr.compress_archives(keep_n=keep_n, category=category)
    if 'error' in result:
        print(f"✗ {result['error']}")
    elif 'message' in result:
        print(f"ℹ {result['message']}")
    else:
        print(f"✓ Compressed {result['compressed']} archived tasks")
        print(f"  Kept {result['kept_in_main']} in main file")
        print(f"  Created {result['archive_files_created']} archive files")


def handle_archive_export(args, category):
    """Handle --archive-export command."""
    archive_mgr = ArchiveManager(Path.cwd())
    fmt = 'json'
    output = None

    if '--format' in args:
        idx = args.index('--format')
        if idx + 1 < len(args):
            fmt = args[idx + 1]

    if '--output' in args:
        idx = args.index('--output')
        if idx + 1 < len(args):
            output = args[idx + 1]

    result = archive_mgr.export_archives(
        format=fmt, output=output, include_compressed=True, category=category,
    )
    if 'error' in result:
        print(f"✗ {result['error']}")
    else:
        print(f"✓ Exported {result['exported']} archived tasks")
        print(f"  Format: {result['format']}")
        print(f"  Output: {result['output']}")


def handle_archive_prune(args):
    """Handle --archive-prune command."""
    archive_mgr = ArchiveManager(Path.cwd())
    strategy = 'older_than'
    value = None
    interactive = '--interactive' in args

    if '--older-than' in args:
        idx = args.index('--older-than')
        if idx + 1 < len(args):
            try:
                value = int(args[idx + 1])
            except ValueError:
                print("✗ --older-than requires a number (months)")
                return

    if '--file' in args:
        idx = args.index('--file')
        if idx + 1 < len(args):
            value = args[idx + 1]
            strategy = 'file'

    result = archive_mgr.prune_archives(
        strategy=strategy, value=value, interactive=interactive,
    )
    if 'error' in result:
        print(f"✗ {result['error']}")
    elif 'message' in result:
        print(f"ℹ {result['message']}")
    elif 'cancelled' in result:
        print("✗ Pruning cancelled")
    else:
        print(f"✓ Deleted {result['deleted']} archive files")
        for filename in result['files']:
            print(f"  - {filename}")


def handle_archive_stats():
    """Handle --archive-stats command."""
    archive_mgr = ArchiveManager(Path.cwd())
    stats = archive_mgr.get_archive_stats()

    print(f"\n{BOLD}Archive Statistics{RESET}")
    print("-" * 60)
    print(f"Total archived tasks:     {CYAN}{stats['total_archived']}{RESET}")
    print(f"  In main files:          {stats['in_main_files']}")
    print(f"  In compressed files:    {stats['in_compressed']}")
    print()
    print(f"Compressed files:         {stats['compressed_files']}")
    print(f"Total size:               {stats['total_size_bytes']} bytes")

    if stats['oldest_task']:
        print(f"Oldest task:              {stats['oldest_task']}")
    if stats['newest_task']:
        print(f"Newest task:              {stats['newest_task']}")

    if stats['archive_files']:
        print(f"\n{BOLD}Archive Files:{RESET}")
        for filename in stats['archive_files']:
            print(f"  - {filename}")
    print()
