"""CLI argument handlers for one-shot jott commands.

Each ``--flag`` dispatches through handle_cli_args().  If the flag is
recognised the handler runs, prints its output, and the function
returns True so that main() can exit without starting the TUI.
"""

import subprocess
from pathlib import Path

from jot.ui import (
    display_all_projects,
    display_archive,
    display_category_stats,
)

from jot.cli.archive import (
    handle_archive_compress,
    handle_archive_export,
    handle_archive_prune,
    handle_archive_stats,
)
from jot.cli.config import (
    show_colors,
    set_color,
    list_colors,
    reset_colors,
    list_templates,
    apply_template,
    backup,
    restore,
    list_backup,
    migrate_backlog_schema,
)
from jot.cli.views import show_day, show_today, show_week


def handle_cli_args(args, registry, category, explicit_global):
    """Dispatch one-shot CLI commands.

    Returns True if a command was handled (caller should exit).
    Returns False if no matching command was found.
    """
    if not args:
        return False

    cmd = args[0]

    # Dispatch table — simple commands with no extra arg parsing
    _simple = {
        '--list-projects': lambda: _list_projects(registry),
        '--refresh': lambda: _refresh(registry),
        '--stats': lambda: display_category_stats(Path.cwd()),
        '--colors': show_colors,
        '--reset-colors': reset_colors,
        '--list-templates': list_templates,
    }

    handler = _simple.get(cmd)
    if handler:
        handler()
        return True

    # Commands that need additional args / context
    if cmd == '--register' and len(args) == 3:
        _register(registry, args[1], args[2])
        return True

    if cmd == '--unregister' and len(args) == 2:
        _unregister(registry, args[1])
        return True

    if cmd == '--all-projects':
        show_categories = '--show-categories' in args
        display_all_projects(registry, show_categories=show_categories)
        return True

    if cmd == '--fix-duplicates':
        _fix_duplicates()
        return True

    if cmd == '--archive':
        filter_category = args[1] if len(args) > 1 and not args[1].startswith('--') else None
        display_archive(Path.cwd(), filter_category)
        return True

    if cmd == '--archive-compress':
        handle_archive_compress(args, category)
        return True

    if cmd == '--archive-export':
        handle_archive_export(args, category)
        return True

    if cmd == '--archive-prune':
        handle_archive_prune(args)
        return True

    if cmd == '--archive-stats':
        handle_archive_stats()
        return True

    if cmd == '--set-color' and len(args) >= 3:
        set_color(args[1], args[2])
        return True

    if cmd == '--list-colors':
        list_colors()
        return True

    if cmd == '--template' and len(args) >= 2:
        apply_template(args[1], '--with-samples' in args)
        return True

    if cmd == '--backup':
        backup(args)
        return True

    if cmd == '--restore' and len(args) >= 2:
        restore(args[1], '--force' in args)
        return True

    if cmd == '--list-backup' and len(args) >= 2:
        list_backup(args[1])
        return True

    if cmd == '--migrate-backlog-schema':
        migrate_backlog_schema(registry, category, explicit_global)
        return True

    if cmd == '--day' and len(args) >= 2:
        show_day(registry, args[1])
        return True

    if cmd == '--today':
        show_today(registry)
        return True

    if cmd == '--week':
        show_week(registry)
        return True

    return False


# -----------------------------------------------------------------------
# Simple handlers (kept here — too small to warrant their own file)
# -----------------------------------------------------------------------

def _list_projects(registry):
    projects = registry.list_projects()
    if projects:
        print("\nRegistered Projects:")
        for name, path in sorted(projects.items()):
            print(f"  {name:20} → {path}")
    else:
        print("\nNo registered projects. Run jot to auto-discover projects in ~/projects/")


def _register(registry, name, path):
    registry.register_project(name, path)
    print(f"✓ Registered project '{name}' → {path}")


def _unregister(registry, name):
    if registry.unregister_project(name):
        print(f"✓ Unregistered project '{name}'")
    else:
        print(f"✗ Project '{name}' not found")


def _refresh(registry):
    registry.refresh()
    print("✓ Project registry refreshed")


def _fix_duplicates():
    jot_file = Path.cwd() / '.jot.json'
    if not jot_file.exists():
        print(f"✗ No .jot.json found in {Path.cwd()}")
        return

    print(f"\n🔧 Fixing duplicate IDs in {jot_file}...")
    fix_script = (Path(__file__).parent.parent
                  / 'scripts' / 'fix-duplicate-ids.py')

    if not fix_script.exists():
        print(f"✗ fix-duplicate-ids.py not found at {fix_script}")
        print(f"   Please run manually: python3 scripts/fix-duplicate-ids.py {jot_file}")
        return

    try:
        result = subprocess.run(
            ['python3', str(fix_script), str(jot_file)],
            capture_output=True, text=True, check=True,
        )
        print(result.stdout)
        if result.returncode == 0:
            print("\n✓ Duplicate IDs fixed! You can now run jott again.")
        else:
            print(f"\n✗ Fix failed with exit code {result.returncode}")
            if result.stderr:
                print(f"Error: {result.stderr}")
    except subprocess.CalledProcessError as e:
        print(f"✗ Fix failed: {e}")
        if e.stderr:
            print(f"Error: {e.stderr}")
