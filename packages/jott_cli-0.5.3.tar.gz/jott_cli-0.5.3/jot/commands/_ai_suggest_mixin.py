"""AI task suggestion mixin."""

import json
import subprocess

from jot.ui.styles import RESET, BOLD, DIM, CYAN, GREEN, YELLOW


class AiSuggestMixin:
    """Suggest new tasks using Claude CLI."""

    def suggest_task(self):
        """Analyze tasks and suggest a new one using Claude (Shift+4)"""
        tasks = self.task_manager.tasks
        archived = self.task_manager.archived

        if not tasks and not archived:
            print("\n✗ No tasks or archive history to analyze")
            print("\nPress Enter to continue...", end='', flush=True)
            input()
            return True

        print(f"\n{CYAN}⏳ Analyzing tasks for suggestion...{RESET}")
        print(f"{DIM}This may take 10-15 seconds...{RESET}\n")

        prompt = self._build_suggestion_prompt(tasks, archived)
        suggestion = self._call_claude_for_suggestion(prompt)

        if suggestion:
            self._present_suggestion(suggestion)

        return True

    def _build_suggestion_prompt(self, tasks, archived):
        """Build prompt for AI task suggestion"""
        lines = [
            "Analyze these tasks and suggest ONE new task to add.",
            "Return ONLY valid JSON with no other text.",
            "",
            "Active tasks:",
        ]

        for t in tasks:
            notes = t.get('notes', '')
            if len(notes) > 100:
                notes = notes[:100] + '...'
            lines.append(json.dumps({
                'id': t.get('id'),
                'text': t.get('text', ''),
                'priority': t.get('priority', 'none'),
                'labels': t.get('labels', []),
                'effort': t.get('effort'),
                'status': t.get('status', 'todo'),
                'day': t.get('day'),
                'notes': notes,
            }))

        recent_archived = archived[-20:] if len(archived) > 20 else archived
        if recent_archived:
            lines.append("")
            lines.append("Recently completed tasks:")
            for t in recent_archived:
                lines.append(json.dumps({
                    'id': t.get('id'),
                    'text': t.get('text', ''),
                    'labels': t.get('labels', []),
                    'priority': t.get('priority', 'none'),
                }))

        lines.append("")
        lines.append(
            "Based on patterns, gaps, and logical next steps, "
            "suggest ONE new task. Return strict JSON:"
        )
        lines.append(
            '{"text": "task description", "priority": "none|low|medium|high", '
            '"labels": ["label1"], "effort": 1-5, '
            '"reasoning": "why this task"}'
        )

        return "\n".join(lines)

    def _call_claude_for_suggestion(self, prompt):
        """Call Claude CLI and parse suggestion JSON"""
        try:
            check_result = subprocess.run(
                ['claude', '--version'], capture_output=True, timeout=5
            )
            if check_result.returncode != 0:
                print(f"{YELLOW}⚠️ Claude CLI not found.{RESET}")
                print("Install: https://claude.com/claude-code")
                print("\nPress Enter to continue...", end='', flush=True)
                input()
                return None
        except (FileNotFoundError, subprocess.TimeoutExpired):
            print(f"{YELLOW}⚠️ Claude CLI not found.{RESET}")
            print("Install: https://claude.com/claude-code")
            print("\nPress Enter to continue...", end='', flush=True)
            input()
            return None

        try:
            result = subprocess.run(
                [
                    'claude', '--print',
                    '--permission-mode', 'plan',
                    '--output-format', 'json',
                    '--max-turns', '5',
                ],
                input=prompt,
                capture_output=True,
                text=True,
                timeout=120,
            )

            if result.returncode != 0:
                error_msg = result.stderr[:100] if result.stderr else "Unknown error"
                print(f"{YELLOW}⚠️ Claude failed: {error_msg}{RESET}")
                print("\nPress Enter to continue...", end='', flush=True)
                input()
                return None

            response = json.loads(result.stdout)
            inner_text = response.get('result', '')

            if not inner_text:
                print(f"{YELLOW}⚠️ Empty response from Claude{RESET}")
                print("\nPress Enter to continue...", end='', flush=True)
                input()
                return None

            # Strip markdown code fences if present
            cleaned = inner_text.strip()
            if cleaned.startswith('```'):
                first_newline = cleaned.index('\n')
                cleaned = cleaned[first_newline + 1:]
            if cleaned.endswith('```'):
                cleaned = cleaned[:-3]
            cleaned = cleaned.strip()

            suggestion = json.loads(cleaned)

            if 'text' not in suggestion:
                print(f"{YELLOW}⚠️ Invalid suggestion format (missing 'text'){RESET}")
                print("\nPress Enter to continue...", end='', flush=True)
                input()
                return None

            return suggestion

        except subprocess.TimeoutExpired:
            print(f"{YELLOW}⚠️ Suggestion timed out (120s).{RESET}")
            print("\nPress Enter to continue...", end='', flush=True)
            input()
            return None
        except json.JSONDecodeError:
            print(f"{YELLOW}⚠️ Failed to parse suggestion JSON{RESET}")
            print("\nPress Enter to continue...", end='', flush=True)
            input()
            return None
        except Exception as e:
            print(f"{YELLOW}⚠️ Suggestion error: {e}{RESET}")
            print("\nPress Enter to continue...", end='', flush=True)
            input()
            return None

    def _present_suggestion(self, suggestion):
        """Display suggestion and prompt for approval"""
        text = suggestion.get('text', '')
        priority = suggestion.get('priority', 'none')
        labels = suggestion.get('labels', [])
        effort = suggestion.get('effort')
        reasoning = suggestion.get('reasoning', '')

        print(f"\n{BOLD}💡 Suggested Task:{RESET}")
        print(f"   {CYAN}{text}{RESET}")
        if priority != 'none':
            print(f"   Priority: {priority}")
        if labels:
            print(f"   Labels: {', '.join(labels)}")
        if effort:
            print(f"   Effort: {effort}/5")
        if reasoning:
            print(f"\n   {DIM}Reasoning: {reasoning}{RESET}")

        print(f"\n   Add this task? [y/N]: ", end='', flush=True)
        try:
            choice = input().strip().lower()
        except (EOFError, KeyboardInterrupt):
            print("\n✗ Cancelled")
            return

        if choice == 'y':
            self.task_manager.add_task(
                text,
                priority=priority,
                labels=labels if labels else None,
                effort=effort,
            )
            print(f"   {GREEN}✓ Task added{RESET}")
        else:
            print(f"   {DIM}Suggestion discarded{RESET}")
