"""Metadata operations mixin (priority, status, day assignment)."""

from datetime import datetime

from jot.core.constants import DAY_COLORS, DAY_ABBREVIATIONS
from jot.ui.picker import PickerItem, quick_picker, fuzzy_picker
from jot.ui.styles import (
    RESET, BOLD, DIM, GREEN, RED,
    PRIORITY_COLORS, PRIORITY_SYMBOLS, STATUS_COLORS, STATUS_SYMBOLS,
    HIGHLIGHT_COLORS,
)
from jot.ui.input import restore_terminal


class MetadataMixin:
    """Day assignment, priority, and status operations."""

    def assign_day(self):
        """Assign a day of the week to the current task"""
        current_task = self.task_manager.get_current_task()
        if not current_task:
            print("\n✗ No current task selected")
            return True

        task_id = current_task['id']

        # Build day items + "Clear day" option
        days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']
        today_weekday = datetime.now().weekday()

        items = []
        for i, day in enumerate(days):
            annotation = "(Today)" if i == today_weekday else ""
            items.append(PickerItem(
                value=day,
                label=f"{DAY_ABBREVIATIONS[day]} {day}",
                color=DAY_COLORS[day],
                annotation=annotation,
            ))
        items.append(PickerItem(value="_clear", label="Clear day", color=DIM))

        result = quick_picker(
            items,
            prompt=f"Assign day to: {current_task['text']}",
            default_index=today_weekday,
        )

        if result.value is None:
            return True

        if result.value == "_clear":
            self.task_manager.set_task_day(task_id, None)
            print("\n✓ Day cleared")
        else:
            self.task_manager.set_task_day(task_id, result.value)
            day_color = DAY_COLORS[result.value]
            abbrev = DAY_ABBREVIATIONS[result.value]
            print(f"\n✓ Day set to {day_color}{abbrev}{RESET} {result.value}")

        print("\nPress Enter to continue...", end='', flush=True)
        restore_terminal()
        input()

        return True

    @staticmethod
    def _priority_picker_items():
        """Build PickerItems for priority selection."""
        priorities = ['none', 'low', 'medium', 'high']
        return [
            PickerItem(
                value=p,
                label=p,
                color=PRIORITY_COLORS[p],
                symbol=PRIORITY_SYMBOLS.get(p, ''),
            )
            for p in priorities
        ]

    @staticmethod
    def _status_picker_items():
        """Build PickerItems for status selection."""
        statuses = ['todo', 'in-progress', 'blocked', 'done']
        return [
            PickerItem(
                value=s,
                label=s,
                color=STATUS_COLORS[s],
                symbol=STATUS_SYMBOLS.get(s, ''),
            )
            for s in statuses
        ]

    def set_priority(self):
        """Set priority for the current task"""
        current_task = self.task_manager.get_current_task()
        if not current_task:
            print("\n✗ No current task selected")
            print("\nPress Enter to continue...", end='', flush=True)
            input()
            return True

        task_id = current_task['id']
        current_priority = current_task.get('priority', 'none')
        priorities = ['none', 'low', 'medium', 'high']
        default_idx = priorities.index(current_priority) if current_priority in priorities else 0

        result = quick_picker(
            self._priority_picker_items(),
            prompt=f"Set priority for: {current_task['text']}",
            default_index=default_idx,
        )

        if result.value is None:
            return True

        self.task_manager.set_task_priority(task_id, result.value)
        color = PRIORITY_COLORS[result.value]
        symbol = PRIORITY_SYMBOLS.get(result.value, '')
        print(f"\n✓ Priority set to {color}{symbol} {result.value}{RESET}")
        print("\nPress Enter to continue...", end='', flush=True)
        restore_terminal()
        input()

        return True

    def toggle_highlight(self):
        """Pick a highlight color for the current task, or clear it."""
        current_task = self.task_manager.get_current_task()
        if not current_task:
            return True

        items = [PickerItem(value="_clear", label="none (clear)", color=DIM)]
        for name, fmt in HIGHLIGHT_COLORS.items():
            items.append(PickerItem(
                value=name, label=name, color=fmt,
            ))

        result = quick_picker(
            items,
            prompt=f"Highlight color for: {current_task['text']}",
        )

        if result.value is None:
            return True

        if result.value == "_clear":
            self.task_manager.set_highlight(color=None)
            print(f"\n{GREEN}✓{RESET} Highlight cleared")
        else:
            self.task_manager.set_highlight(color=result.value)
            fmt = HIGHLIGHT_COLORS[result.value]
            print(f"\n{GREEN}✓{RESET} Highlight set to {fmt} {result.value} {RESET}")

        print("\nPress Enter to continue...", end='', flush=True)
        restore_terminal()
        input()
        return True

    def quick_highlight(self):
        """Toggle default highlight color on the current task."""
        current_task = self.task_manager.get_current_task()
        if not current_task:
            return True
        from jot.ui.styles import HIGHLIGHT_DEFAULT
        was_highlighted = current_task.get('highlight', False)
        if was_highlighted:
            self.task_manager.set_highlight(color=None)
            print(f"\n{GREEN}✓{RESET} Highlight cleared")
        else:
            self.task_manager.set_highlight(color=HIGHLIGHT_DEFAULT)
            fmt = HIGHLIGHT_COLORS[HIGHLIGHT_DEFAULT]
            print(f"\n{GREEN}✓{RESET} Highlighted {fmt} {HIGHLIGHT_DEFAULT} {RESET}")
        return True

    def set_priority_high(self):
        """Quickly set current task priority to high (shortcut)"""
        current_task = self.task_manager.get_current_task()
        if not current_task:
            return True

        self.task_manager.set_task_priority(current_task['id'], 'high')
        print(f"\n{GREEN}✓{RESET} Priority set to {RED}● high{RESET}")
        return True

    def set_status(self):
        """Set status for the current task"""
        current_task = self.task_manager.get_current_task()
        if not current_task:
            print("\n✗ No current task selected")
            print("\nPress Enter to continue...", end='', flush=True)
            input()
            return True

        task_id = current_task['id']
        current_status = current_task.get('status', 'todo')
        statuses = ['todo', 'in-progress', 'blocked', 'done']
        default_idx = statuses.index(current_status) if current_status in statuses else 0

        result = quick_picker(
            self._status_picker_items(),
            prompt=f"Set status for: {current_task['text']}",
            default_index=default_idx,
        )

        if result.value is None:
            return True

        self.task_manager.set_task_status(task_id, result.value)
        color = STATUS_COLORS[result.value]
        symbol = STATUS_SYMBOLS.get(result.value, '')
        print(f"\n✓ Status set to {color}{symbol} {result.value}{RESET}")
        print("\nPress Enter to continue...", end='', flush=True)
        restore_terminal()
        input()

        return True

    def assign_parent(self):
        """Assign current task as a subtask of another task (Ctrl+L)."""
        current_task = self.task_manager.get_current_task()
        if not current_task:
            print("\n✗ No current task selected")
            return True

        task_id = current_task['id']
        labels = current_task.get('labels', [])

        # Find existing parent label
        current_parent = None
        for lbl in labels:
            if lbl.startswith('parent:'):
                current_parent = lbl.split(':', 1)[1]
                break

        # Build picker items
        items = []
        if current_parent is not None:
            items.append(PickerItem(
                value="_clear", label="Remove parent link", color=DIM,
            ))

        for task in self.task_manager.get_tasks():
            if task['id'] == task_id:
                continue
            if task.get('status') == 'done':
                continue
            annotation = "(current parent)" if str(task['id']) == str(current_parent) else ""
            items.append(PickerItem(
                value=str(task['id']),
                label=f"#{task['id']} {task['text']}",
                annotation=annotation,
            ))

        if not items:
            print("\n✗ No candidate tasks found")
            return True

        result = fuzzy_picker(
            items,
            prompt=f"Assign parent for: {current_task['text']}",
        )

        if result.value is None:
            return True

        # Strip existing parent: label
        new_labels = [l for l in labels if not l.startswith('parent:')]

        if result.value != "_clear":
            new_labels.append(f"parent:{result.value}")

        # Save updated labels
        for task in self.task_manager.tasks:
            if task['id'] == task_id:
                task['labels'] = new_labels
                self.task_manager._save_tasks()
                break

        if result.value == "_clear":
            print(f"\n{GREEN}✓{RESET} Parent link removed")
        else:
            print(f"\n{GREEN}✓{RESET} Assigned as subtask of #{result.value}")

        print("\nPress Enter to continue...", end='', flush=True)
        restore_terminal()
        input()
        return True
