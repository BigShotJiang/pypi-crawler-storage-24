"""Google Calendar integration mixin.

Exceeds 300-line guideline: gcal requires 7 user-facing flows
(account setup, selection, export single/bulk, import with multi-day
direction/grouping/display, re-authentication) that cannot be further
decomposed without losing readability.
"""

from datetime import datetime, timedelta

from jot.core.constants import GCAL_AVAILABLE
from jot.integrations.gcal.account_manager import GoogleCalendarAccountManager
from jot.integrations.gcal.auth import GoogleCalendarAuth
from jot.integrations.gcal.events import create_gcal_event, fetch_gcal_events
from jot.ui.input import get_key, restore_terminal
from jot.ui.picker import PickerItem, multiselect_picker
from jot.ui.styles import RESET, BOLD, DIM, CYAN, GREEN, YELLOW
from jot.utils.date_utils import extract_time_tag, get_today_day_name, round_to_15_minutes

_GCAL_INSTALL = ("   Install with: pip install google-auth google-auth-oauthlib"
                  " google-auth-httplib2 google-api-python-client")
_GCAL_SETUP_URL = "https://developers.google.com/workspace/calendar/api/quickstart/python"
_DAY_NAMES = ['Monday', 'Tuesday', 'Wednesday', 'Thursday',
              'Friday', 'Saturday', 'Sunday']


def _print_setup_instructions(account_name, account_path):
    """Print gcal setup instructions for a newly created account."""
    print(f"\n{GREEN}✓{RESET} Created account: {account_name}")
    print(f"\n{CYAN}{BOLD}Setup Instructions:{RESET}")
    print(f"1. Download credentials.json from Google Cloud Console:")
    print(f"   {_GCAL_SETUP_URL}")
    print(f"2. Save it to: {account_path / 'credentials.json'}")
    print(f"3. Run this command again to authenticate")


class GcalMixin:
    """Google Calendar import, export, and account management."""

    def select_gcal_account(self):
        """Select Google Calendar account. Returns account name or None."""
        account_manager = GoogleCalendarAccountManager()
        accounts = account_manager.discover_accounts()

        if not accounts:
            print(f"\n{YELLOW}No Google Calendar accounts configured yet.{RESET}")
            print(f"\nWould you like to set up an account? (y/N): ", end='', flush=True)
            restore_terminal()
            try:
                if input().strip().lower() != 'y':
                    return None
                return self._create_gcal_account(account_manager)
            except (KeyboardInterrupt, EOFError):
                print("\n✗ Cancelled")
                return None

        print(f"\n{CYAN}{BOLD}Select Google Calendar account:{RESET}")
        for i, account in enumerate(accounts, 1):
            print(f"  {i}. {account}")
        print(f"\n  {GREEN}[n]{RESET} Add new account")
        print(f"  {BOLD}ESC{RESET} Cancel\n")
        print("Choice: ", end='', flush=True)
        restore_terminal()

        try:
            user_input = input().strip().lower()
            if not user_input or user_input == '\x1b':
                print("✗ Cancelled")
                return None
            if user_input == 'n':
                return self._create_gcal_account(account_manager)
            try:
                idx = int(user_input) - 1
                if 0 <= idx < len(accounts):
                    return accounts[idx]
                print("✗ Invalid number")
            except ValueError:
                if user_input in accounts:
                    return user_input
                print(f"✗ Account '{user_input}' not found")
            return None
        except (KeyboardInterrupt, EOFError):
            print("\n✗ Cancelled")
            return None

    @staticmethod
    def _create_gcal_account(account_manager):
        """Create a new gcal account interactively. Returns None always."""
        print(f"\nEnter account name (e.g., 'work', 'personal'): ", end='', flush=True)
        name = input().strip()
        if not name:
            print("✗ Cancelled")
            return None
        path = account_manager.create_account(name)
        _print_setup_instructions(name, path)
        return None

    def _build_gcal_start_time(self, task_text):
        """Parse time tag and build (start_time, end_time, cleaned_text)."""
        hour, minute, cleaned = extract_time_tag(task_text)
        if hour is not None:
            today = datetime.now().astimezone()
            start = today.replace(hour=hour, minute=minute, second=0, microsecond=0)
        else:
            start = round_to_15_minutes(datetime.now().astimezone())
            cleaned = task_text
        return start, start + timedelta(minutes=15), cleaned

    def _export_single_task(self, service, account_name, task):
        """Export a single task to Google Calendar."""
        start, end, cleaned = self._build_gcal_start_time(task['text'])
        notes = task.get('notes', '').strip()
        link = create_gcal_event(service, cleaned, start_time=start,
                                 description=notes or None)
        print(f"  {GREEN}✓{RESET} {BOLD}{cleaned}{RESET}")
        print(f"    {start.strftime('%-I:%M %p')} - {end.strftime('%-I:%M %p')}")
        if link:
            print(f"    {DIM}{link}{RESET}")
        return True

    def export_to_gcal(self):
        """Export task(s) to Google Calendar — single or bulk today"""
        if not GCAL_AVAILABLE:
            print(f"\n✗ Google Calendar API not available\n{_GCAL_INSTALL}")
            print("\nPress Enter to continue...", end='', flush=True)
            input()
            return True

        print(f"\n{BOLD}Export to Google Calendar:{RESET}")
        print(f"  {CYAN}1{RESET} Current task  {CYAN}2{RESET} All today's tasks  {DIM}ESC cancel{RESET}")

        choice = get_key(timeout=30.0)
        if choice not in ('1', '2'):
            print("✗ Cancelled")
            return True

        try:
            account_name = self.select_gcal_account()
            if not account_name:
                print("\nPress Enter to continue...", end='', flush=True)
                input()
                return True

            service = GoogleCalendarAuth(account_name).get_service()

            if choice == '1':
                task = self.task_manager.get_current_task()
                if not task:
                    print("\n✗ No current task selected")
                else:
                    print(f"\n{DIM}Account: {account_name}{RESET}")
                    self._export_single_task(service, account_name, task)
            else:
                today = get_today_day_name()
                tasks = [t for t in self.task_manager.tasks
                         if t.get('day') == today and not t.get('done')]
                if not tasks:
                    print(f"\n✗ No tasks assigned to {today}")
                else:
                    print(f"\n{DIM}Account: {account_name}{RESET}")
                    print(f"Exporting {len(tasks)} {today} tasks:\n")
                    ok = 0
                    for t in tasks:
                        try:
                            self._export_single_task(service, account_name, t)
                            ok += 1
                        except Exception as e:
                            print(f"  ✗ {t['text']}: {e}")
                    print(f"\n✓ Exported {ok}/{len(tasks)} tasks")

        except (FileNotFoundError, ImportError) as e:
            print(f"\n✗ {e}")
        except Exception as e:
            if type(e).__name__ == 'HttpError':
                print(f"\n✗ Google Calendar API error: {e}")
            else:
                print(f"\n✗ Failed to create event: {e}")

        print("\nPress Enter to continue...", end='', flush=True)
        input()
        return True

    def import_from_gcal(self):
        """Import Google Calendar events as tasks (1-7 days)"""
        if not GCAL_AVAILABLE:
            print(f"\n✗ Google Calendar API not available\n{_GCAL_INSTALL}")
            print("\nPress Enter to continue...", end='', flush=True)
            input()
            return True

        try:
            direction, days = self._prompt_import_direction()
            if direction is None:
                return True

            account_name = self.select_gcal_account()
            if not account_name:
                print("\nPress Enter to continue...", end='', flush=True)
                input()
                return True

            service = GoogleCalendarAuth(account_name).get_service()

            if direction == 'today':
                events = fetch_gcal_events(service, days=1)
                days_text = "today"
            elif direction == 'past':
                events = fetch_gcal_events(service, days=days, direction='past')
                days_text = "yesterday" if days == 1 else f"the past {days} days"
            else:
                events = fetch_gcal_events(service, days=days, direction='future')
                days_text = "tomorrow" if days == 1 else f"the next {days} days"

            if not events:
                print(f"\n📅 No events found for {days_text} (account: {account_name})")
                print("\nPress Enter to continue...", end='', flush=True)
                input()
                return True

            self._display_and_import_events(events, days_text, account_name, direction)

        except (FileNotFoundError, ImportError) as e:
            print(f"\n✗ {e}")
        except Exception as e:
            if type(e).__name__ == 'HttpError':
                print(f"\n✗ Google Calendar API error: {e}")
            else:
                print(f"\n✗ Failed to fetch events: {e}")

        print("\nPress Enter to continue...", end='', flush=True)
        input()
        return True

    @staticmethod
    def _prompt_import_direction():
        """Prompt for direction and days. Returns (direction, days) or (None, None)."""
        print(f"\n{CYAN}{BOLD}Import Google Calendar Events{RESET}")
        print(f"\n  {BOLD}p{RESET} Past  {BOLD}f{RESET} Future  {BOLD}t{RESET} Today only")
        print(f"\nDirection [{BOLD}t{RESET}]: ", end='', flush=True)
        restore_terminal()

        try:
            d = input().strip().lower()
            if d in ('', 't'):
                return 'today', 1
            if d not in ('p', 'f'):
                print("\n✗ Invalid option")
                print("\nPress Enter to continue...", end='', flush=True)
                input()
                return None, None
            direction = 'past' if d == 'p' else 'future'
        except (KeyboardInterrupt, EOFError):
            print("\n✗ Import cancelled")
            print("\nPress Enter to continue...", end='', flush=True)
            input()
            return None, None

        print(f"\nHow many {direction} days? (1-7) [{BOLD}1{RESET}]: ", end='', flush=True)
        try:
            val = input().strip()
            days = max(1, min(7, int(val))) if val else 1
        except (ValueError, KeyboardInterrupt, EOFError):
            print("\n✗ Import cancelled")
            print("\nPress Enter to continue...", end='', flush=True)
            input()
            return None, None

        return direction, days

    def _display_and_import_events(self, events, days_text, account_name, direction):
        """Show interactive picker for event selection, then import chosen events."""
        today = datetime.now().date()

        picker_items = []
        for ev in events:
            day_label = self._event_day_annotation(ev['date'], today)
            if ev['all_day']:
                label = f"\U0001f4c5 {ev['summary']}"
            else:
                s = ev['start'].strftime('%-I:%M %p')
                e = ev['end'].strftime('%-I:%M %p')
                label = f"{s} - {e}: {ev['summary']}"
            picker_items.append(
                PickerItem(value=ev, label=label, annotation=day_label))

        selected = multiselect_picker(
            picker_items,
            prompt=f"Import events \u2014 {days_text} ({account_name})")

        if not selected:
            print("\n\u2717 Import cancelled")
            return

        count = 0
        for ev in selected:
            prefix = self._event_day_prefix(ev['date'], today, direction)
            if ev['all_day']:
                text = f"{prefix}\U0001f4c5 {ev['summary']}"
            else:
                text = f"{prefix}\U0001f4c6 {ev['summary']}"
            self.task_manager.add_task(text)
            if ev.get('description'):
                self.task_manager.tasks[-1]['notes'] = ev['description']
                self.task_manager._save_tasks()
            count += 1
        print(f"\n{GREEN}\u2713{RESET} Imported {count} event(s) as tasks")

    @staticmethod
    def _event_day_annotation(event_date, today):
        """Short day annotation for picker items (e.g. 'Today', 'Tomorrow')."""
        if event_date == today:
            return "Today"
        if event_date == today - timedelta(days=1):
            return "Yesterday"
        if event_date == today + timedelta(days=1):
            return "Tomorrow"
        return _DAY_NAMES[event_date.weekday()]

    @staticmethod
    def _event_day_prefix(event_date, today, direction):
        """Build day prefix for imported event (e.g. '[Yesterday] ')."""
        if event_date == today:
            return ""
        if event_date == today - timedelta(days=1):
            return "[Yesterday] "
        if event_date == today + timedelta(days=1):
            return "[Tomorrow] "
        if direction != 'today':
            return f"[{_DAY_NAMES[event_date.weekday()][:3]}] "
        return ""

    def reauthenticate_google_calendar(self):
        """Force re-authentication with Google Calendar (Shift+3)"""
        try:
            if not GCAL_AVAILABLE:
                print(f"\n{YELLOW}⚠️  Google Calendar libraries not installed{RESET}")
                print(f"\n{_GCAL_INSTALL}")
                print("\nPress Enter to continue...", end='', flush=True)
                input()
                return True

            mgr = GoogleCalendarAccountManager()
            accounts = mgr.discover_accounts()

            if not accounts:
                print(f"\n{YELLOW}⚠️  No Google Calendar accounts configured{RESET}")
                print(f"\n{CYAN}{BOLD}Setup:{RESET} mkdir -p ~/.jot/gcal-accounts/default")
                print(f"Save credentials.json there, then try Shift+3 again")
                print("\nPress Enter to continue...", end='', flush=True)
                input()
                return True

            account_name = self.select_gcal_account()
            if not account_name:
                return True

            token_file = mgr.get_account_path(account_name) / 'token.json'

            if not token_file.exists():
                print(f"\n{YELLOW}⚠️  No token for '{account_name}'{RESET}")
                print(f"Use {BOLD}Shift+G{RESET} or {BOLD}Shift+I{RESET} to authenticate first.")
                print("\nPress Enter to continue...", end='', flush=True)
                input()
                return True

            print(f"\n{CYAN}{BOLD}Re-authenticate{RESET}: {account_name}")
            print(f"\n{YELLOW}Delete token and re-auth? (y/N):{RESET} ", end='', flush=True)
            if input().strip().lower() != 'y':
                print("✗ Cancelled")
                print("\nPress Enter to continue...", end='', flush=True)
                input()
                return True

            token_file.unlink()
            print(f"\n{GREEN}✓{RESET} Token deleted")
            print(f"\n{CYAN}Opening browser for authentication...{RESET}")
            GoogleCalendarAuth(account_name=account_name).get_credentials()
            print(f"\n{GREEN}✓ Re-authentication successful!{RESET}")

        except (FileNotFoundError, ImportError) as e:
            print(f"\n{YELLOW}⚠️  {e}{RESET}")
        except Exception as e:
            print(f"\n{YELLOW}⚠️  Re-authentication failed: {e}{RESET}")

        print("\nPress Enter to continue...", end='', flush=True)
        input()
        return True
