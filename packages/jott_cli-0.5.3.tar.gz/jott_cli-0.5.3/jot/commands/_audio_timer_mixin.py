"""Text-to-speech and timer mixin."""

import subprocess

from jot.categories.config import CategoryConfig
from jot.core.constants import TTS_AVAILABLE
from jot.ui.styles import RESET, BOLD, DIM, CYAN, GREEN, YELLOW


class AudioTimerMixin:
    """Read tasks aloud and priority timer."""

    def read_tasks_aloud(self):
        """Read all tasks in current category aloud using TTS (Shift+2)"""
        if not TTS_AVAILABLE:
            print(f"\n{YELLOW}⚠️  Text-to-speech not available{RESET}")
            print(f"{DIM}Install pyttsx3: pip install pyttsx3{RESET}")
            print("\nPress Enter to continue...", end='', flush=True)
            input()
            return True

        cat_config = CategoryConfig(project_dir=self.task_manager.project_dir)
        tts_config = cat_config.get_tts_config()

        if not tts_config.get('enabled', True):
            print(f"\n{YELLOW}⚠️  Text-to-speech is disabled in configuration{RESET}")
            print(f"{DIM}Edit .jot.config.json to enable{RESET}")
            print("\nPress Enter to continue...", end='', flush=True)
            input()
            return True

        tasks = self.task_manager.tasks
        if not tasks:
            print(f"\n{YELLOW}⚠️  No tasks to read{RESET}")
            print("\nPress Enter to continue...", end='', flush=True)
            input()
            return True

        try:
            import pyttsx3
            engine = pyttsx3.init()
            engine.setProperty('rate', tts_config.get('rate', 150))
            engine.setProperty('volume', tts_config.get('volume', 0.9))

            voice_name = tts_config.get('voice')
            if voice_name:
                voices = engine.getProperty('voices')
                for voice in voices:
                    if voice_name in voice.name:
                        engine.setProperty('voice', voice.id)
                        break

        except Exception as e:
            print(f"\n{YELLOW}⚠️  Failed to initialize TTS: {e}{RESET}")
            print("\nPress Enter to continue...", end='', flush=True)
            input()
            return True

        category_name = self.task_manager.category or "default"
        print(f"\n{CYAN}🔊 Reading {len(tasks)} tasks from {category_name} category...{RESET}\n")

        try:
            for i, task in enumerate(tasks, 1):
                task_text = task['text']
                print(f"{DIM}{i}. {task_text}{RESET}")
                engine.say(f"Task {i}. {task_text}")

            engine.runAndWait()
            print(f"\n{GREEN}✓ Finished reading {len(tasks)} tasks{RESET}")

        except KeyboardInterrupt:
            print(f"\n{YELLOW}⚠️  Reading interrupted{RESET}")
            engine.stop()
        except Exception as e:
            print(f"\n{YELLOW}⚠️  Error during reading: {e}{RESET}")
        finally:
            try:
                engine.stop()
            except Exception:
                pass

        print("\nPress Enter to continue...", end='', flush=True)
        input()
        return True

    def start_priority_timer(self):
        """Launch bullet priority timer for current task"""
        current_task = self.task_manager.get_current_task()

        if current_task:
            task_text = current_task['text']
            print(f"\n{YELLOW}🔥 Starting priority timer for:{RESET} {BOLD}{task_text}{RESET}")
        else:
            print(f"\n{YELLOW}🔥 Starting priority timer...{RESET}")

        print("Duration: 12 minutes (default)")
        print("\nPress Enter to continue...", end='', flush=True)
        input()

        try:
            subprocess.Popen(
                ['bullet', 'priority'], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL
            )
            print("\n✓ Priority timer started")
        except FileNotFoundError:
            print("\n✗ bullet command not found")
            print("   Install: cd ~/projects/bullet && npm link")
        except Exception as e:
            print(f"\n✗ Failed to start timer: {e}")

        print("\nPress Enter to continue...", end='', flush=True)
        input()
        return True
