"""Web search, URL opening, and clipboard mixin."""

import platform
import subprocess
import urllib.parse
import webbrowser

from jot.ui.styles import RESET, CYAN, DIM
from jot.utils.text_utils import extract_urls


class WebClipboardMixin:
    """Web search, URL opening, and clipboard operations."""

    def web_search(self):
        """Open a web search with the current task text"""
        current_task = self.task_manager.get_current_task()
        if not current_task:
            print("\n✗ No current task selected")
            return True

        task_text = current_task['text']
        query = urllib.parse.quote_plus(task_text)
        search_url = f"https://www.google.com/search?q={query}"

        try:
            webbrowser.open(search_url)
            print(f"\n✓ Opened web search for: {task_text}")
        except Exception as e:
            print(f"\n✗ Failed to open browser: {e}")

        return True

    def open_url(self):
        """Open URL(s) from current task text in browser"""
        current_task = self.task_manager.get_current_task()
        if not current_task:
            print("\n✗ No current task selected")
            return True

        task_text = current_task['text']
        urls = extract_urls(task_text)

        if not urls:
            print(f"\n✗ No URLs found in task: {task_text}")
            return True

        if len(urls) == 1:
            url = urls[0]
            try:
                webbrowser.open(url)
                print(f"\n✓ Opened URL: {url}")
            except Exception as e:
                print(f"\n✗ Failed to open browser: {e}")
        else:
            print(f"\nFound {len(urls)} URLs in task:")
            for i, url in enumerate(urls, 1):
                print(f"  {i}. {url}")

            print(
                "\nSelect URL to open (1-{}, or Enter to cancel): ".format(len(urls)),
                end='',
                flush=True,
            )
            try:
                choice = input().strip()
                if not choice:
                    print("✗ Cancelled")
                    return True

                index = int(choice) - 1
                if 0 <= index < len(urls):
                    url = urls[index]
                    webbrowser.open(url)
                    print(f"✓ Opened URL: {url}")
                else:
                    print("✗ Invalid selection")
            except (ValueError, KeyboardInterrupt):
                print("\n✗ Cancelled")

        return True

    def copy_to_clipboard(self):
        """Copy current task text to clipboard"""
        current_task = self.task_manager.get_current_task()
        if not current_task:
            print("\n✗ No current task selected")
            print("\nPress Enter to continue...", end='', flush=True)
            input()
            return True

        task_text = current_task['text']

        try:
            system = platform.system()
            if system == 'Darwin':
                process = subprocess.Popen(
                    ['pbcopy'], stdin=subprocess.PIPE, stdout=subprocess.DEVNULL
                )
                process.communicate(task_text.encode('utf-8'))
            elif system == 'Linux':
                try:
                    process = subprocess.Popen(
                        ['xclip', '-selection', 'clipboard'],
                        stdin=subprocess.PIPE,
                        stdout=subprocess.DEVNULL,
                        stderr=subprocess.DEVNULL,
                    )
                    process.communicate(task_text.encode('utf-8'))
                except FileNotFoundError:
                    process = subprocess.Popen(
                        ['xsel', '--clipboard', '--input'],
                        stdin=subprocess.PIPE,
                        stdout=subprocess.DEVNULL,
                        stderr=subprocess.DEVNULL,
                    )
                    process.communicate(task_text.encode('utf-8'))
            else:
                print(f"\n✗ Clipboard not supported on {system}")
                print("\nPress Enter to continue...", end='', flush=True)
                input()
                return True

            display_text = task_text if len(task_text) <= 60 else task_text[:57] + '...'
            print(f"\n{CYAN}✓ Copied to clipboard:{RESET}")
            print(f"  {DIM}{display_text}{RESET}")
            print("\nPress Enter to continue...", end='', flush=True)
            input()

        except FileNotFoundError as e:
            print(f"\n✗ Clipboard tool not found: {e}")
            print("   Install xclip or xsel on Linux")
            print("\nPress Enter to continue...", end='', flush=True)
            input()
        except Exception as e:
            print(f"\n✗ Failed to copy to clipboard: {e}")
            print("\nPress Enter to continue...", end='', flush=True)
            input()

        return True
