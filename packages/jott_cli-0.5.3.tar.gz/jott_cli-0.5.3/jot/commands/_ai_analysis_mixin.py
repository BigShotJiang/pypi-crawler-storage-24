"""AI task analysis and execution mixin."""

import json
import platform
import subprocess
import tempfile
import uuid
from datetime import datetime
from pathlib import Path

from jot.ui.styles import RESET, BOLD, DIM, CYAN, GREEN, YELLOW

_DEFAULT_PROMPT = """\
Analyze this task and provide a structured implementation plan in org-mode format.

Task: {task}{notes}

Create an org-mode document with sections: Task Analysis (Overview, Task Breakdown \
with checklist, Technical Approach, Acceptance Criteria, Complexity Estimate, \
Potential Risks)."""

_CUSTOM_PROMPT = """\
Analyze this task with a focus on: {focus}

Task: {task}{notes}

Provide a detailed analysis in org-mode format addressing {focus}. Include sections: \
Task Analysis, {focus_title}, Implementation Approach, Acceptance Criteria, Potential Risks."""


class AiAnalysisMixin:
    """Analyze tasks with Claude and execute analysis plans."""

    def ultrathink_task(self):
        """Analyze current task with Claude Code"""
        current_task = self.task_manager.get_current_task()
        if not current_task:
            print("\n✗ No current task selected")
            print("\nPress Enter to continue...", end='', flush=True)
            input()
            return True

        task_id = current_task['id']
        task_text = current_task['text']
        notes = current_task.get('notes', '')

        existing = Path.cwd() / f".jot.analysis.{task_id}.org"
        custom_focus = self._prompt_analysis_options(existing, task_text)
        if custom_focus is False:
            return True

        notes_section = f"\n\nTask Notes:\n{notes}" if notes else ""
        if custom_focus:
            prompt = _CUSTOM_PROMPT.format(
                focus=custom_focus, task=task_text,
                notes=notes_section, focus_title=custom_focus.title(),
            )
        else:
            prompt = _DEFAULT_PROMPT.format(task=task_text, notes=notes_section)

        print(f"\n{CYAN}⏳ Analyzing with Claude Code...{RESET}")
        print(f"{DIM}This may take 10-15 seconds...{RESET}\n")

        if not self._check_claude_cli():
            return True

        return self._run_analysis(prompt, task_id, task_text, custom_focus, existing)

    def _prompt_analysis_options(self, existing, task_text):
        """Prompt for analysis options. Returns custom_focus str, None, or False (cancel)."""
        if existing.exists():
            print(f"\n⚠️  Analysis already exists: {existing.name}")
            print("\n  [Enter] View  [r] Re-analyze  [c] Custom  [q] Cancel")
            choice = input("\nChoice: ").strip().lower()

            if choice in ('q', ''):
                if choice == '':
                    self.safe_launch_editor(existing)
                return False
            if choice not in ('r', 'c'):
                return False
        else:
            print(f"\n🤔 Analyze: {task_text[:60]}{'...' if len(task_text) > 60 else ''}")
            print("\n  [Enter] Standard  [c] Custom  [q] Cancel")
            choice = input("\nChoice: ").strip().lower()

            if choice == 'q':
                return False
            if choice != 'c':
                return None

        if choice == 'c':
            print("\nAnalysis focus (e.g. 'security', 'performance', 'test coverage'):")
            focus = input("Focus: ").strip()
            return focus if focus else None
        return None

    @staticmethod
    def _check_claude_cli():
        """Check if Claude CLI is available."""
        try:
            r = subprocess.run(['claude', '--version'], capture_output=True, timeout=5)
            if r.returncode != 0:
                raise FileNotFoundError
        except (FileNotFoundError, subprocess.TimeoutExpired):
            print(f"{YELLOW}⚠️ Claude CLI not found.{RESET}")
            print("Install: https://claude.com/claude-code")
            print("\nPress Enter to continue...", end='', flush=True)
            input()
            return False
        return True

    def _run_analysis(self, prompt, task_id, task_text, custom_focus, output_file):
        """Run Claude analysis and save results."""
        try:
            result = subprocess.run(
                ['claude', '--print', '--permission-mode', 'plan',
                 '--output-format', 'json', '--max-turns', '5'],
                input=prompt, capture_output=True, text=True, timeout=120,
            )

            if result.returncode != 0:
                stderr = (result.stderr or '').lower()
                if 'authentication' in stderr or 'login' in stderr:
                    print(f"{YELLOW}⚠️ Claude auth expired. Run: claude login{RESET}")
                elif 'network' in stderr or 'connection' in stderr:
                    print(f"{YELLOW}⚠️ Network error.{RESET}")
                else:
                    print(f"{YELLOW}⚠️ Claude failed: {(result.stderr or '')[:100]}{RESET}")
                print("\nPress Enter to continue...", end='', flush=True)
                input()
                return True

            response = json.loads(result.stdout)
            analysis_text = response.get('result', '')
            if not analysis_text:
                print(f"{YELLOW}⚠️ Empty response from Claude{RESET}")
                print("\nPress Enter to continue...", end='', flush=True)
                input()
                return True

            with open(output_file, 'w') as f:
                f.write(f"#+TITLE: Analysis for Task {task_id}\n")
                f.write(f"#+DATE: {datetime.now().strftime('%Y-%m-%d %H:%M')}\n")
                f.write(f"#+TASK: {task_text}\n")
                if custom_focus:
                    f.write(f"#+FOCUS: {custom_focus}\n")
                f.write("\n")
                f.write(analysis_text)

            current_task = self.task_manager.get_current_task()
            if current_task:
                current_task['analysis_file'] = str(output_file)
                self.task_manager._save_tasks()

            cost = response.get('total_cost_usd', 0)
            cost_str = f" (${cost:.3f})" if cost > 0 else ""
            print(f"{GREEN}✓ Analysis saved to {output_file.name}{cost_str}{RESET}\n")

            print("Open analysis in editor? [Y/n]: ", end='', flush=True)
            if input().strip().lower() != 'n':
                self.safe_launch_editor(output_file)

        except json.JSONDecodeError:
            print(f"{YELLOW}⚠️ Failed to parse Claude response{RESET}")
            print("\nPress Enter to continue...", end='', flush=True)
            input()
        except subprocess.TimeoutExpired:
            print(f"{YELLOW}⚠️ Analysis timed out (120s).{RESET}")
            print("\nPress Enter to continue...", end='', flush=True)
            input()
        except Exception as e:
            print(f"{YELLOW}⚠️ Analysis error: {e}{RESET}")
            print("\nPress Enter to continue...", end='', flush=True)
            input()

        return True

    def execute_analysis_task(self):
        """Execute analysis plan with Claude Code (Shift+0)"""
        current_task = self.task_manager.get_current_task()
        if not current_task:
            print("\n✗ No current task selected")
            print("\nPress Enter to continue...", end='', flush=True)
            input()
            return True

        task_id = current_task['id']
        task_text = current_task['text']

        analysis_file = Path.cwd() / f".jot.analysis.{task_id}.org"
        if not analysis_file.exists():
            print(f"\n{YELLOW}⚠️  No analysis found for this task{RESET}")
            print(f"\n{DIM}Tip: Press Shift+9 to analyze first, then Shift+0 to execute{RESET}")
            print("\nPress Enter to continue...", end='', flush=True)
            input()
            return True

        try:
            analysis_content = analysis_file.read_text()
        except IOError as e:
            print(f"\n{YELLOW}⚠️  Failed to read analysis file: {e}{RESET}")
            print("\nPress Enter to continue...", end='', flush=True)
            input()
            return True

        session_uuid = str(uuid.uuid5(uuid.NAMESPACE_DNS, f"jot.task.{task_id}"))

        if current_task.get('execution_history'):
            last = current_task['execution_history'][-1]
            print(f"\n{CYAN}Previous execution found:{RESET}")
            print(f"  Started: {last.get('started_at', 'unknown')}")
            print(f"  Status: {last.get('status', 'unknown')}")
            print("\n  [Enter] Resume  [n] New  [q] Cancel")
            choice = input("\nChoice: ").strip().lower()
            if choice == 'q':
                return True
            if choice == 'n':
                session_uuid = str(uuid.uuid4())

        system_prompt = (
            f"You are implementing a task from the jot task manager.\n\n"
            f"TASK: {task_text}\n\nANALYSIS PLAN:\n{analysis_content}\n\n"
            f"Follow the plan step by step, making commits as appropriate."
        )

        print(f"\n{CYAN}🚀 Launching Claude Code...{RESET}")
        print(f"{DIM}Task: {task_id} | Session: {session_uuid[:8]}...{RESET}")

        current_task.setdefault('execution_history', []).append({
            'session_id': session_uuid,
            'started_at': datetime.now().isoformat(),
            'status': 'in_progress',
            'analysis_file': str(analysis_file),
        })
        if not current_task.get('agent_task'):
            current_task['agent_task'] = True
        self.task_manager._save_tasks()

        self._launch_claude_terminal(session_uuid, system_prompt, analysis_file)

        print("\nPress Enter to continue...", end='', flush=True)
        input()
        return True

    @staticmethod
    def _launch_claude_terminal(session_uuid, system_prompt, analysis_file):
        """Launch Claude Code in a new terminal window."""
        system = platform.system()
        try:
            if system == 'Darwin':
                with tempfile.NamedTemporaryFile(mode='w', suffix='.txt', delete=False) as tf:
                    tf.write(system_prompt)
                    prompt_file = tf.name
                applescript = (
                    'tell application "Terminal"\n  activate\n'
                    f'  do script "claude --session-id {session_uuid} '
                    f'--system-prompt \\"$(cat {prompt_file})\\" && rm {prompt_file}"\n'
                    'end tell'
                )
                subprocess.run(['osascript', '-e', applescript], check=True)
                print(f"{GREEN}✓ Terminal launched{RESET}")
            elif system == 'Linux':
                for term in ['gnome-terminal', 'konsole', 'xterm']:
                    try:
                        cmd = f'claude --session-id {session_uuid} --system-prompt "{system_prompt}"'
                        args = [term, '--', 'bash', '-c', f'{cmd}; exec bash'] \
                            if term == 'gnome-terminal' else [term, '-e', cmd]
                        subprocess.Popen(args)
                        print(f"{GREEN}✓ Terminal launched ({term}){RESET}")
                        return
                    except FileNotFoundError:
                        continue
                print(f"{YELLOW}⚠️  No terminal emulator found{RESET}")
            else:
                print(f"{YELLOW}⚠️  Auto-launch not supported on {system}{RESET}")
        except Exception as e:
            print(f"{YELLOW}⚠️  Failed to launch: {e}{RESET}")
            print(f'{DIM}Run: claude --session-id {session_uuid} '
                  f'--system-prompt "$(cat {analysis_file})"{RESET}')
