"""Core task CRUD and utility mixin."""

from collections import Counter
from datetime import datetime
from pathlib import Path

from jot.categories.manager import CategoryManager
from jot.core.constants import MODE_ALL_CATEGORIES, MODE_QUICK_ADD
from jot.core.task_manager import TaskManager
from jot.ui import display_help, display_categorized_shortcuts
from jot.ui.styles import RESET, BOLD, DIM, CYAN, GREEN, YELLOW, MAGENTA
from jot.ui.input import input_with_prefill


class CoreMixin:
    """Core task operations: add, delete, edit, set current, help, refresh."""

    def add_task(self):
        """Add a new task"""
        print("\nEnter task: ", end='', flush=True)
        task_text = input().strip()
        if task_text:
            self.task_manager.add_task(task_text)
            print(f"✓ Added: {task_text}")
        return True

    def quit(self):
        """Quit the application"""
        print("\nGoodbye!")
        return False

    def set_current(self):
        """Mark a task as current"""
        print("\nTask ID to mark as current: ", end='', flush=True)
        try:
            task_id = int(input().strip())
            if self.task_manager.set_current(task_id):
                print(f"✓ Task {task_id} marked as current")
            else:
                print(f"✗ Task {task_id} not found")
        except ValueError:
            print("✗ Invalid task ID")
        return True

    def set_agent_task(self):
        """Mark current task as agent task (Claude Code is working on it)"""
        current_task = self.task_manager.get_current_task()
        if not current_task:
            print("\n✗ No current task selected")
            return True

        task_id = current_task['id']
        is_currently_agent = current_task.get('agent_task', False)

        if self.task_manager.set_agent_task(task_id):
            if is_currently_agent:
                print(f"\n✓ Task {task_id} unmarked as agent task")
            else:
                print(f"\n{MAGENTA}✓ Task {task_id} marked as agent task 🤖{RESET}")
        else:
            print(f"\n✗ Failed to mark task")
        return True

    def fix_duplicate_ids_interactive(self):
        """Check for and fix duplicate task IDs (Shift+1)"""
        all_tasks = self.task_manager.tasks + self.task_manager.archived
        ids = [task['id'] for task in all_tasks if 'id' in task]

        id_counts = Counter(ids)
        duplicates = {tid: count for tid, count in id_counts.items() if count > 1}

        if not duplicates:
            print(f"\n{GREEN}✓ No duplicate IDs found{RESET}")
            print(f"  {DIM}All task IDs are unique{RESET}")
            return True

        print(f"\n{YELLOW}🔧 Found duplicate IDs:{RESET}")
        for tid, count in sorted(duplicates.items()):
            print(f"  ID {BOLD}{tid}{RESET}: {count} occurrences")

        # Create backup before fixing
        now = datetime.now()
        timestamp = now.strftime("%Y%m%d_%H%M%S")
        year_month = now.strftime("%Y-%m")

        backup_dir = self.task_manager.storage_file.parent / '.jot-backups' / year_month
        backup_dir.mkdir(parents=True, exist_ok=True)

        backup_file = backup_dir / f'{timestamp}.json'
        with open(self.task_manager.storage_file, 'r') as f:
            backup_data = f.read()
        with open(backup_file, 'w') as f:
            f.write(backup_data)

        # Build list of tasks that need new IDs
        seen_ids = set()
        tasks_to_fix = []

        for idx, task in enumerate(self.task_manager.tasks):
            tid = task.get('id')
            if tid in duplicates:
                if tid in seen_ids:
                    tasks_to_fix.append((task, 'tasks', idx))
                else:
                    seen_ids.add(tid)

        for idx, task in enumerate(self.task_manager.archived):
            tid = task.get('id')
            if tid in duplicates:
                if tid in seen_ids:
                    tasks_to_fix.append((task, 'archived', idx))
                else:
                    seen_ids.add(tid)

        # Reassign IDs
        old_to_new = {}
        for task, list_name, idx in tasks_to_fix:
            old_id = task['id']
            new_id = self.task_manager.id_manager.allocate_id()
            task['id'] = new_id
            if old_id not in old_to_new:
                old_to_new[old_id] = []
            old_to_new[old_id].append(new_id)

        self.task_manager._save_tasks()

        print(f"\n{GREEN}✓ Fixed {len(tasks_to_fix)} duplicate ID(s){RESET}")
        print(f"  {DIM}Backup: {backup_file.name}{RESET}")

        changes = []
        for old_id, new_ids in sorted(old_to_new.items()):
            changes.append(f"{old_id} → {', '.join(map(str, new_ids))}")
        if changes:
            print(f"  {DIM}Changes: {', '.join(changes)}{RESET}")

        return True

    def delete_task(self):
        """Delete a task by ID"""
        print("\nTask ID to delete: ", end='', flush=True)
        try:
            task_id = int(input().strip())
            if self.task_manager.remove_task(task_id):
                print(f"✓ Task {task_id} deleted")
            else:
                print(f"✗ Task {task_id} not found")
        except ValueError:
            print("✗ Invalid task ID")
        return True

    def delete_current(self):
        """Delete the current task"""
        current_task = self.task_manager.get_current_task()
        if current_task:
            task_id = current_task['id']
            if self.task_manager.remove_task(task_id):
                print(f"\n✓ Current task deleted")
            else:
                print(f"\n✗ Failed to delete task")
        else:
            print("\n✗ No current task selected")
        return True

    def edit_task(self):
        """Edit a task's text"""
        print("\nTask ID to edit: ", end='', flush=True)
        try:
            task_id = int(input().strip())

            task = None
            for t in self.task_manager.tasks:
                if t['id'] == task_id:
                    task = t
                    break

            if not task:
                print(f"✗ Task {task_id} not found")
                return True

            print(f"Editing task {task_id}:")
            try:
                new_text = input_with_prefill("", prefill=task['text']).strip()
                if new_text:
                    if self.task_manager.edit_task(task_id, new_text):
                        print(f"✓ Task {task_id} updated")
                    else:
                        print(f"✗ Failed to update task")
                else:
                    print("✗ Task text cannot be empty")
            except (EOFError, KeyboardInterrupt):
                print("\n✗ Edit cancelled")
        except ValueError:
            print("✗ Invalid task ID")
        return True

    def edit_current(self):
        """Edit the current task"""
        current_task = self.task_manager.get_current_task()
        if current_task:
            task_id = current_task['id']
            current_text = current_task['text']
            print(f"\nEditing task {task_id}:")
            try:
                new_text = input_with_prefill("", prefill=current_text).strip()
                if new_text:
                    if self.task_manager.edit_task(task_id, new_text):
                        print(f"✓ Task updated")
                    else:
                        print(f"✗ Failed to update task")
                else:
                    print("✗ Task text cannot be empty")
            except (EOFError, KeyboardInterrupt):
                print("\n✗ Edit cancelled")
        else:
            print("\n✗ No current task selected")
        return True

    def collect_all_category_tasks(self, project_dir, show_archived=False):
        """Collect tasks from all categories (default + local + global).

        Returns list of (category_name, is_global, tasks, archived_tasks).
        """
        result = []
        cat_manager = CategoryManager(project_dir=project_dir)

        # Build (name, is_global, tm_kwargs) for each category
        specs = [('default', False, dict(directory=project_dir))]
        for cat in cat_manager.discover_categories():
            specs.append((cat, False, dict(directory=project_dir, category=cat)))
        for cat in cat_manager.discover_global_categories():
            specs.append((cat, True, dict(category=cat, is_global=True)))

        for name, is_global, kwargs in specs:
            try:
                tm = TaskManager(project_registry=self.registry, **kwargs)
                tasks = tm.tasks
                archived = tm.archived if show_archived else []
                if tasks or archived:
                    result.append((name, is_global, tasks, archived))
            except Exception:
                pass

        return result

    @staticmethod
    def toggle_all_categories_view(current_mode):
        """Toggle between normal view and all-categories view.

        Returns:
            tuple: (should_toggle, new_mode)
        """
        if current_mode == MODE_ALL_CATEGORIES:
            return (True, MODE_QUICK_ADD)
        return (True, MODE_ALL_CATEGORIES)

    def refresh(self):
        """Refresh task list from file"""
        self.task_manager.refresh()
        print("\n✓ Refreshed task list")
        return True

    @staticmethod
    def help():
        """Show help message"""
        print("""
Commands:  a Add  c Current  d Delete  D Delete-current  e Edit  E Edit-current
           M Move  r Refresh  h Help  q Quit

Navigation: ↑/Ctrl+p Up  ↓/Ctrl+n Down  Shift+↑ Move up  Shift+↓ Move down

Quick-Add: ? Shortcuts  Shift+F Notes display  Shift+N Edit notes
           Shift+J Agent task  Shift+C Category  Shift+Z Project
           Ctrl+R Register  Shift+T Transfer  Shift+M Move  Ctrl+X Quit

Command Mode (ESC): r Refresh

Tip: Press '?' in Quick-Add mode for full categorized shortcuts.
Full CLI docs: jott --help""")
        return True
