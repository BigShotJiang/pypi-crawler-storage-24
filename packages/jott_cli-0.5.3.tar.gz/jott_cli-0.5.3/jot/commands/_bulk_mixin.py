"""Bulk task operations mixin for CommandHandler."""

from jot.ui.input import restore_terminal
from jot.ui.picker import quick_picker
from jot.ui.styles import (
    RESET, BOLD, CYAN, YELLOW,
    PRIORITY_COLORS, PRIORITY_SYMBOLS, STATUS_COLORS, STATUS_SYMBOLS,
)


class BulkMixin:
    """Bulk actions on multiple selected tasks."""

    def bulk_actions_menu(self, selected_task_ids):
        """Show bulk actions menu and return selected action.

        Returns:
            str: 'priority', 'status', 'delete', 'archive', 'cancel', or None
        """
        if not selected_task_ids:
            print("\n✗ No tasks selected")
            print("\nPress Enter to continue...", end='', flush=True)
            input()
            return None

        print(f"\n{CYAN}{BOLD}Bulk Actions{RESET} ({len(selected_task_ids)} tasks selected)")
        print("-" * 50)
        print("  1. Set priority for all selected")
        print("  2. Set status for all selected")
        print("  3. Delete all selected")
        print("  4. Archive all selected")
        print("  5. Cancel")
        print("\nChoice: ", end='', flush=True)

        restore_terminal()

        try:
            choice = input().strip()
            actions = {'1': 'priority', '2': 'status', '3': 'delete', '4': 'archive'}
            return actions.get(choice, 'cancel')
        except (KeyboardInterrupt, EOFError):
            return 'cancel'

    def bulk_set_priority(self, task_ids):
        """Set priority for multiple tasks."""
        result = quick_picker(
            self._priority_picker_items(),
            prompt=f"Set priority for {len(task_ids)} tasks",
        )

        if result.value is None:
            return True

        count = sum(1 for tid in task_ids if self.task_manager.set_task_priority(tid, result.value))
        color = PRIORITY_COLORS[result.value]
        symbol = PRIORITY_SYMBOLS.get(result.value, '')
        print(f"\n✓ Set priority to {color}{symbol} {result.value}{RESET} for {count} tasks")
        print("\nPress Enter to continue...", end='', flush=True)
        restore_terminal()
        input()

        return True

    def bulk_set_status(self, task_ids):
        """Set status for multiple tasks."""
        result = quick_picker(
            self._status_picker_items(),
            prompt=f"Set status for {len(task_ids)} tasks",
        )

        if result.value is None:
            return True

        count = sum(1 for tid in task_ids if self.task_manager.set_task_status(tid, result.value))
        color = STATUS_COLORS[result.value]
        symbol = STATUS_SYMBOLS.get(result.value, '')
        print(f"\n✓ Set status to {color}{symbol} {result.value}{RESET} for {count} tasks")
        print("\nPress Enter to continue...", end='', flush=True)
        restore_terminal()
        input()

        return True

    def bulk_delete(self, task_ids):
        """Delete multiple tasks with confirmation."""
        print(f"\n{YELLOW}{BOLD}⚠  WARNING{RESET}")
        print(f"About to delete {len(task_ids)} tasks. This cannot be undone.\n")
        print("Confirm deletion? (y/N): ", end='', flush=True)

        restore_terminal()

        try:
            confirmation = input().strip().lower()

            if confirmation == 'y':
                count = sum(1 for tid in task_ids if self.task_manager.delete_task_permanently(tid))
                print(f"✓ Deleted {count} tasks")
            else:
                print("✗ Deletion cancelled")

            print("\nPress Enter to continue...", end='', flush=True)
            input()

        except (KeyboardInterrupt, EOFError):
            print("\n✗ Deletion cancelled")
            print("\nPress Enter to continue...", end='', flush=True)
            input()

        return True

    def bulk_archive(self, task_ids):
        """Archive multiple tasks with confirmation."""
        print(f"\n{BOLD}Archive {len(task_ids)} tasks?{RESET} (y/N): ", end='', flush=True)

        restore_terminal()

        try:
            confirmation = input().strip().lower()

            if confirmation == 'y':
                count = sum(1 for tid in task_ids if self.task_manager.archive_task(tid))
                print(f"✓ Archived {count} tasks")
            else:
                print("✗ Archive cancelled")

            print("\nPress Enter to continue...", end='', flush=True)
            input()

        except (KeyboardInterrupt, EOFError):
            print("\n✗ Archive cancelled")
            print("\nPress Enter to continue...", end='', flush=True)
            input()

        return True
