"""Project/category switching mixin."""

from pathlib import Path

from jot.categories.config import CategoryConfig
from jot.categories.manager import CategoryManager
from jot.ui.picker import PickerItem, fuzzy_picker, quick_picker
from jot.ui.styles import RESET, BOLD, DIM, CYAN, YELLOW
from jot.ui.input import restore_terminal


class ContextMixin:
    """Switch projects, switch categories, register projects."""

    def _create_category_dialog(self, cat_name, cat_manager):
        """Ask user whether to create a new category as local or global.

        Returns:
            tuple: (cat_name, is_global) or None if cancelled.
        """
        scope_items = [
            PickerItem(value="local", label="Local", annotation="(this project only)"),
            PickerItem(value="global", label="Global", annotation="(available in all projects)"),
        ]
        scope_result = quick_picker(scope_items, prompt=f"Create '{cat_name}' as")
        if scope_result.value is None:
            return None

        is_global = scope_result.value == "global"

        if not is_global:
            can_create, error_msg = cat_manager.can_create_category(cat_name)
            if not can_create:
                print(f"\n✗ {error_msg}")
                print("\nPress Enter to continue...", end='', flush=True)
                restore_terminal()
                input()
                return None

            warning_msg = cat_manager.get_warning_message(cat_name)
            if warning_msg:
                print(warning_msg)

        return (cat_name, is_global)

    def switch_category(self):
        """Switch to a different category (local or global)"""
        project_dir = (
            self.task_manager.project_dir if not self.task_manager.is_global else Path.cwd()
        )

        cat_manager = CategoryManager(project_dir=project_dir)
        local_categories = cat_manager.discover_categories()
        global_categories = cat_manager.discover_global_categories()
        cat_config = CategoryConfig(project_dir=project_dir)

        # Build picker items — "default" first, then local, then global
        items = [PickerItem(
            value=("default", None, False),
            label="default",
            annotation="(no category)",
            color=cat_config.get_color('default'),
        )]

        for cat in local_categories:
            items.append(PickerItem(
                value=("cat", cat, False),
                label=cat,
                annotation="[local]",
                color=cat_config.get_color(cat, for_global=False),
            ))

        for cat in global_categories:
            if cat not in local_categories:
                items.append(PickerItem(
                    value=("cat", cat, True),
                    label=cat,
                    annotation="[global]",
                    color=cat_config.get_color(cat, for_global=True),
                ))

        result = fuzzy_picker(
            items,
            prompt="Switch to category",
            allow_freeform=True,
            freeform_hint="Type a new category name and press Enter",
        )

        if result.value is None:
            return True

        if result.is_freeform:
            created = self._create_category_dialog(result.value, cat_manager)
            if created is None:
                return True
            return ('switch_category', created[0], created[1])

        tag, cat_name, is_global = result.value
        return ('switch_category', cat_name, is_global)

    def switch_project(self):
        """Switch to a different registered project"""
        all_projects = self.registry.list_projects()

        if not all_projects:
            print("\n✗ No projects registered")
            print("Run 'jott --refresh' to discover projects or '--register' to add one manually")
            print("\nPress Enter to continue...", end='', flush=True)
            restore_terminal()
            input()
            return True

        current_project_path = str(self.task_manager.project_dir)
        available = {n: p for n, p in all_projects.items() if p != current_project_path}

        if not available:
            print("\n✗ No other projects available")
            print("\nPress Enter to continue...", end='', flush=True)
            restore_terminal()
            input()
            return True

        items = [
            PickerItem(value=name, label=name, annotation=f"\u2192 {path}")
            for name, path in sorted(available.items())
        ]

        result = fuzzy_picker(items, prompt="Switch to project")
        if result.value is None:
            return True

        return ('switch_project', result.value, available[result.value])

    def register_current_project(self):
        """Register the current project in the global project registry"""
        current_dir = self.task_manager.project_dir

        jot_file = current_dir / '.jot.json'
        if not jot_file.exists():
            print(f"\n✗ No .jot.json file found in {current_dir}")
            print("Cannot register a directory without a .jot.json file")
            print("\nPress Enter to continue...", end='', flush=True)
            input()
            return True

        suggested_name = current_dir.name

        all_projects = self.registry.list_projects()
        current_path_str = str(current_dir)
        already_registered_as = None
        for name, path in all_projects.items():
            if path == current_path_str:
                already_registered_as = name
                break

        print(f"\n{CYAN}{BOLD}Register Current Project{RESET}")
        print(f"Directory: {DIM}{current_dir}{RESET}")

        if already_registered_as:
            print(f"{YELLOW}⚠ Already registered as: {BOLD}{already_registered_as}{RESET}")
            print(f"\nEnter new name to re-register or press Enter to cancel: ", end='', flush=True)
        else:
            print(f"\nProject name [{suggested_name}]: ", end='', flush=True)

        restore_terminal()

        try:
            project_name = input().strip()

            if not project_name and already_registered_as:
                print("✗ Cancelled")
                print("\nPress Enter to continue...", end='', flush=True)
                input()
                return True

            if not project_name:
                project_name = suggested_name

            if project_name in all_projects and all_projects[project_name] != current_path_str:
                existing_path = all_projects[project_name]
                print(f"{YELLOW}⚠ Project '{project_name}' already exists → {existing_path}{RESET}")
                print(f"Overwrite? (y/N): ", end='', flush=True)
                overwrite = input().strip().lower()
                if overwrite != 'y':
                    print("✗ Cancelled")
                    print("\nPress Enter to continue...", end='', flush=True)
                    input()
                    return True

            self.registry.register_project(project_name, current_path_str)
            print(
                f"\n✓ Registered project '{BOLD}{project_name}{RESET}' → {DIM}{current_dir}{RESET}"
            )
            print(f"\nYou can now access it with: {CYAN}jott {project_name}{RESET}")
            print("\nPress Enter to continue...", end='', flush=True)
            input()
            return True

        except KeyboardInterrupt:
            print("\n✗ Cancelled")
            print("\nPress Enter to continue...", end='', flush=True)
            input()
            return True
