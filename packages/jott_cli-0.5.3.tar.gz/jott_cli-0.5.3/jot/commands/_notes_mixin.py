"""Notes editing, subtask sync, and keyword action mixin."""

import os
import shlex
import subprocess
import tempfile

from jot.ui.styles import RESET, DIM, CYAN, YELLOW


class NotesMixin:
    """Editor-based notes, subtask sync, and keyword actions."""

    @staticmethod
    def safe_launch_editor(file_path):
        """Safely launch editor with file_path, avoiding command injection.

        Uses shlex.split() to safely parse $EDITOR which may contain
        arguments (e.g., "emacs -nw"), then calls subprocess without
        shell=True to prevent command injection.
        """
        editor = os.environ.get('EDITOR', os.environ.get('VISUAL', 'nano'))

        try:
            editor_parts = shlex.split(editor)
        except ValueError:
            print(f"\n⚠️  Invalid $EDITOR value: {editor}")
            print("   Using nano instead")
            editor_parts = ['nano']

        editor_parts.append(str(file_path))

        try:
            result = subprocess.call(editor_parts)
            return result == 0
        except FileNotFoundError:
            raise FileNotFoundError(f"Editor not found: {editor_parts[0]}")

    def get_notes_file_extension(self, editor):
        """Determine file extension based on editor."""
        editor_lower = editor.lower()
        if 'emacs' in editor_lower:
            return '.org'
        return '.txt'

    def edit_task_notes(self):
        """Edit notes for the current task using $EDITOR"""
        current_task = self.task_manager.get_current_task()
        if not current_task:
            print("\n✗ No current task selected")
            print("\nPress Enter to continue...", end='', flush=True)
            input()
            return True

        task_id = current_task['id']
        task_text = current_task['text']
        current_notes = self.task_manager.get_task_notes(task_id)

        editor = os.environ.get('EDITOR', os.environ.get('VISUAL', 'nano'))
        file_extension = self.get_notes_file_extension(editor)
        is_org_mode = file_extension == '.org'

        with tempfile.NamedTemporaryFile(mode='w+', suffix=file_extension, delete=False) as tf:
            temp_file = tf.name
            if is_org_mode:
                tf.write(f"#+TITLE: Notes for task: {task_text}\n")
                tf.write("#+COMMENT: Lines starting with #+COMMENT will be ignored\n")
                tf.write("\n")
            else:
                tf.write(f"# Notes for task: {task_text}\n")
                tf.write("# Lines starting with # will be ignored\n")
                tf.write("#\n")
            if current_notes:
                tf.write(current_notes)

        try:
            self.safe_launch_editor(temp_file)

            with open(temp_file, 'r') as f:
                lines = f.readlines()

            if is_org_mode:
                edited_notes = ''.join(
                    line for line in lines if not line.strip().startswith('#+')
                ).strip()
            else:
                edited_notes = ''.join(
                    line for line in lines if not line.strip().startswith('#')
                ).strip()

            self.task_manager.set_task_notes(task_id, edited_notes)
            sync_result = self.task_manager.sync_subtasks_from_notes(task_id)

            if edited_notes:
                note_lines = edited_notes.split('\n')
                preview = '\n  '.join(note_lines[:3])
                if len(note_lines) > 3:
                    preview += f"\n  {DIM}... ({len(note_lines)} lines total){RESET}"
                print(f"\n{CYAN}✓ Notes saved:{RESET}")
                print(f"  {DIM}{preview}{RESET}")
            else:
                print(f"\n{CYAN}✓ Notes cleared{RESET}")

            if sync_result and (sync_result['created'] or sync_result['updated']):
                parts = []
                if sync_result['created']:
                    parts.append(f"{sync_result['created']} created")
                if sync_result['updated']:
                    parts.append(f"{sync_result['updated']} updated")
                print(f"{CYAN}✓ Subtasks synced: {', '.join(parts)}{RESET}")

            print("\nPress Enter to continue...", end='', flush=True)
            input()

        except FileNotFoundError:
            print(f"\n✗ Editor not found: {editor}")
            print(f"   Set $EDITOR environment variable or install nano")
            print("\nPress Enter to continue...", end='', flush=True)
            input()
        except Exception as e:
            print(f"\n✗ Failed to edit notes: {e}")
            print("\nPress Enter to continue...", end='', flush=True)
            input()
        finally:
            try:
                os.unlink(temp_file)
            except Exception:
                pass

        return True

    def sync_subtasks(self):
        """Manually sync subtasks from current task's notes (Ctrl+S)"""
        current_task = self.task_manager.get_current_task()
        if not current_task:
            print("\n✗ No current task selected")
            print("\nPress Enter to continue...", end='', flush=True)
            input()
            return True

        task_id = current_task['id']
        notes = current_task.get('notes', '')
        if not notes:
            print("\n✗ No notes on current task")
            print("\nPress Enter to continue...", end='', flush=True)
            input()
            return True

        result = self.task_manager.sync_subtasks_from_notes(task_id)

        if result['created'] or result['updated']:
            parts = []
            if result['created']:
                parts.append(f"{result['created']} created")
            if result['updated']:
                parts.append(f"{result['updated']} updated")
            print(f"\n{CYAN}✓ Subtasks synced: {', '.join(parts)}{RESET}")
        elif result['total'] > 0:
            print(f"\n{CYAN}✓ {result['total']} subtasks already in sync{RESET}")
        else:
            print("\n✗ No checklist items found in notes (use '- [ ] task' format)")

        print("\nPress Enter to continue...", end='', flush=True)
        input()
        return True

    def trigger_keyword_action(self):
        """Manually trigger keyword action for current task"""
        current_task = self.task_manager.get_current_task()
        if not current_task:
            print("\n✗ No current task selected")
            print("\nPress Enter to continue...", end='', flush=True)
            input()
            return True

        keyword = current_task.get('keyword')
        if not keyword:
            print("\n✗ Current task has no keyword")
            print("\nPress Enter to continue...", end='', flush=True)
            input()
            return True

        result = self.task_manager.keyword_handler.handle(keyword, current_task)

        if result:
            self.task_manager._save_tasks()
            print(f"\n{CYAN}✓ Executed keyword action:{RESET}")
            print(f"  {DIM}Keyword: {keyword}{RESET}")
            print(f"  {DIM}{result}{RESET}")
        else:
            print(f"\n✗ Unknown keyword: {keyword}")

        print("\nPress Enter to continue...", end='', flush=True)
        input()
        return True
