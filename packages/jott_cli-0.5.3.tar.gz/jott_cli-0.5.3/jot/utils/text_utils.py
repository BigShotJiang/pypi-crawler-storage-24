"""Text manipulation and search utilities for jot"""

import re


def extract_urls(text):
    """Extract URLs from text

    Args:
        text: String to search for URLs

    Returns:
        List of URLs found in text
    """
    # URL regex pattern - matches http://, https://, and www. URLs
    url_pattern = r'https?://[^\s]+|www\.[^\s]+'

    urls = re.findall(url_pattern, text)

    # Ensure www. URLs have http:// prefix for webbrowser
    normalized_urls = []
    for url in urls:
        if url.startswith('www.'):
            normalized_urls.append('http://' + url)
        else:
            normalized_urls.append(url)

    return normalized_urls


def fuzzy_match(query, text):
    """
    Fuzzy match query against text.

    Tries matching from every occurrence of the first query character
    and returns the highest-scoring result, avoiding the greedy trap
    where an early character locks in a suboptimal match.

    Returns:
        (is_match, score, match_positions) where:
        - is_match: bool indicating if all query chars found in text in order
        - score: int score (higher is better match)
        - match_positions: list of indices in text where query chars matched
    """
    if not query:
        return (True, 0, [])

    query_lower = query.lower()
    text_lower = text.lower()

    best_score = None
    best_positions = None
    first_char = query_lower[0]

    for i, ch in enumerate(text_lower):
        if ch != first_char:
            continue
        positions = _find_match_from(query_lower, text_lower, i)
        if positions is None:
            continue
        score = _score_positions(positions, query, text)
        if best_score is None or score > best_score:
            best_score = score
            best_positions = positions

    if best_positions is None:
        return (False, 0, [])

    return (True, best_score, best_positions)


def _find_match_from(query_lower, text_lower, start_idx):
    """Greedy left-to-right scan starting at start_idx.

    Returns list of match positions, or None if no match.
    """
    positions = []
    text_idx = start_idx

    for query_char in query_lower:
        found = False
        while text_idx < len(text_lower):
            if text_lower[text_idx] == query_char:
                positions.append(text_idx)
                text_idx += 1
                found = True
                break
            text_idx += 1
        if not found:
            return None

    return positions


def _score_positions(positions, query, text):
    """Score a set of match positions.

    Rewards: consecutive runs, word boundaries, case matches, start.
    Penalises: gaps between matched characters.
    """
    score = 0

    # Bonus for consecutive character runs
    consecutive_run = 1
    for i in range(1, len(positions)):
        if positions[i] == positions[i - 1] + 1:
            consecutive_run += 1
            score += 10 * consecutive_run
        else:
            consecutive_run = 1

    # Bonus for word boundary matches
    for pos in positions:
        if pos == 0 or text[pos - 1] in ' -_./':
            score += 5

    # Penalty for character gaps
    if len(positions) > 1:
        total_gap = positions[-1] - positions[0]
        gap_penalty = total_gap - len(positions)
        score -= gap_penalty

    # Bonus for exact case matches
    for i, pos in enumerate(positions):
        if query[i] == text[pos]:
            score += 2

    # Bonus for matching at start
    if positions and positions[0] == 0:
        score += 15

    return score
