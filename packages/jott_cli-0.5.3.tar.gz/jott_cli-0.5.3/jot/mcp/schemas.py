"""MCP tool schema definitions for jot server."""

from mcp.types import Tool


def list_tools():
    """Return all MCP tool definitions."""
    return [
        # Category Operations
        Tool(
            name="list_categories",
            description="List all categories (local and global) in current project",
            inputSchema={
                "type": "object", "properties": {}, "required": []},
        ),
        Tool(
            name="get_category_info",
            description="Get detailed information about a category",
            inputSchema={
                "type": "object",
                "properties": {
                    "category": {"type": "string",
                                 "description": "Category name"},
                },
                "required": ["category"],
            },
        ),
        Tool(
            name="create_category",
            description="Create a new category (validates against 12 category limit)",
            inputSchema={
                "type": "object",
                "properties": {
                    "category": {"type": "string",
                                 "description": "Category name"},
                    "is_global": {"type": "boolean",
                                  "description": "Create as global category",
                                  "default": False},
                },
                "required": ["category"],
            },
        ),
        # Task Operations
        Tool(
            name="list_tasks",
            description="List all tasks in a category",
            inputSchema={
                "type": "object",
                "properties": {
                    "category": {"type": "string",
                                 "description": "Category name"},
                },
            },
        ),
        Tool(
            name="add_task",
            description="Add a new task",
            inputSchema={
                "type": "object",
                "properties": {
                    "text": {"type": "string", "description": "Task text"},
                    "category": {"type": "string",
                                 "description": "Category name"},
                },
                "required": ["text"],
            },
        ),
        Tool(
            name="get_current_task",
            description="Get the current task",
            inputSchema={
                "type": "object",
                "properties": {
                    "category": {"type": "string",
                                 "description": "Category name"},
                },
            },
        ),
        Tool(
            name="set_current_task",
            description="Set a task as current by ID",
            inputSchema={
                "type": "object",
                "properties": {
                    "task_id": {"type": "integer",
                                "description": "Task ID"},
                    "category": {"type": "string",
                                 "description": "Category name"},
                },
                "required": ["task_id"],
            },
        ),
        Tool(
            name="update_task",
            description="Update task text",
            inputSchema={
                "type": "object",
                "properties": {
                    "task_id": {"type": "integer",
                                "description": "Task ID"},
                    "text": {"type": "string",
                             "description": "New task text"},
                    "category": {"type": "string",
                                 "description": "Category name"},
                },
                "required": ["task_id", "text"],
            },
        ),
        Tool(
            name="delete_task",
            description="Delete/archive a task",
            inputSchema={
                "type": "object",
                "properties": {
                    "task_id": {"type": "integer",
                                "description": "Task ID"},
                    "category": {"type": "string",
                                 "description": "Category name"},
                },
                "required": ["task_id"],
            },
        ),
        # Task Properties
        Tool(
            name="set_task_day",
            description="Assign a day of the week to a task",
            inputSchema={
                "type": "object",
                "properties": {
                    "task_id": {"type": "integer",
                                "description": "Task ID"},
                    "day": {"type": "string",
                            "description": "Day name (Monday-Sunday) or null",
                            "enum": ["Monday", "Tuesday", "Wednesday",
                                     "Thursday", "Friday", "Saturday",
                                     "Sunday", None]},
                    "category": {"type": "string",
                                 "description": "Category name"},
                },
                "required": ["task_id"],
            },
        ),
        Tool(
            name="set_task_priority",
            description="Set task priority",
            inputSchema={
                "type": "object",
                "properties": {
                    "task_id": {"type": "integer",
                                "description": "Task ID"},
                    "priority": {"type": "string",
                                 "description": "Priority level",
                                 "enum": ["none", "low", "medium",
                                          "high", "urgent"]},
                    "category": {"type": "string",
                                 "description": "Category name"},
                },
                "required": ["task_id", "priority"],
            },
        ),
        Tool(
            name="set_task_status",
            description="Set task status",
            inputSchema={
                "type": "object",
                "properties": {
                    "task_id": {"type": "integer",
                                "description": "Task ID"},
                    "status": {"type": "string",
                               "description": "Status",
                               "enum": ["todo", "in-progress",
                                        "done", "blocked"]},
                    "category": {"type": "string",
                                 "description": "Category name"},
                },
                "required": ["task_id", "status"],
            },
        ),
        # Utility
        Tool(
            name="get_project_context",
            description="Get current project directory and jot configuration",
            inputSchema={"type": "object", "properties": {}, "required": []},
        ),
    ]
