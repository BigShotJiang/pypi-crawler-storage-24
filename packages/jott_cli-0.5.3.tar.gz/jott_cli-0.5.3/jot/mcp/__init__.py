"""MCP (Model Context Protocol) server integration for jot."""
