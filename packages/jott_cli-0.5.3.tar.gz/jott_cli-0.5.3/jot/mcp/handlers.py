"""MCP tool handler functions for jot server."""

import json
import os
from pathlib import Path
from typing import Optional

from mcp.types import TextContent

from jot import TaskManager, CategoryManager, IDManager


def get_project_dir() -> Path:
    """Get current project directory with environment variable fallback."""
    if env_dir := os.getenv('JOT_PROJECT_DIR'):
        return Path(env_dir)
    return Path.cwd()


def get_category_manager(project_dir: Optional[Path] = None) -> CategoryManager:
    """Get CategoryManager instance"""
    if project_dir is None:
        project_dir = get_project_dir()
    return CategoryManager(project_dir)


def get_task_manager(category: Optional[str] = None,
                     project_dir: Optional[Path] = None) -> TaskManager:
    """Get TaskManager instance for a category"""
    if project_dir is None:
        project_dir = get_project_dir()

    if category and category != "default":
        storage_file = f".jot.{category}.json"
    else:
        storage_file = ".jot.json"

    id_manager = IDManager(project_dir=project_dir)
    return TaskManager(
        storage_file=storage_file, project_dir=project_dir,
        id_manager=id_manager)


def _json_response(data):
    """Return a TextContent JSON response."""
    return [TextContent(type="text", text=json.dumps(data, indent=2))]


# Category Handlers

async def handle_list_categories():
    """List all categories"""
    cat_mgr = get_category_manager()
    local_cats = cat_mgr.discover_categories()
    global_cats = cat_mgr.discover_global_categories()
    return _json_response({
        "local_categories": local_cats,
        "global_categories": global_cats,
        "total": len(local_cats) + len(global_cats),
        "limit": CategoryManager.MAX_CATEGORIES,
    })


async def handle_get_category_info(arguments):
    """Get category information"""
    category = arguments["category"]
    cat_mgr = get_category_manager()
    location = cat_mgr.resolve_category_location(category)
    task_mgr = get_task_manager(category)
    tasks = task_mgr.list_tasks()
    current = task_mgr.get_current_task()
    return _json_response({
        "category": category, "location": location,
        "task_count": len(tasks),
        "current_task_id": current["id"] if current else None,
        "exists": location != "new",
    })


async def handle_create_category(arguments):
    """Create a new category"""
    category = arguments["category"]
    is_global = arguments.get("is_global", False)
    cat_mgr = get_category_manager()

    can_create, error_msg = cat_mgr.can_create_category(category)
    if not can_create:
        return [TextContent(type="text", text=f"Error: {error_msg}")]

    if is_global:
        cat_mgr.GLOBAL_CATEGORIES_DIR.mkdir(parents=True, exist_ok=True)
    file_path = cat_mgr.get_category_file_path(category, is_global=is_global)

    with open(file_path, "w") as f:
        json.dump({"tasks": [], "archived": []}, f, indent=2)

    return _json_response({
        "category": category,
        "location": "global" if is_global else "local",
        "file_path": str(file_path), "status": "created",
    })


# Task Handlers

async def handle_list_tasks(arguments):
    """List tasks in a category"""
    category = arguments.get("category")
    task_mgr = get_task_manager(category)
    tasks = task_mgr.list_tasks()

    formatted = [{
        "id": t["id"], "text": t["text"],
        "done": t.get("done", False), "current": t.get("current", False),
        "day": t.get("day"), "priority": t.get("priority", "none"),
        "status": t.get("status", "todo"), "tally": t.get("tally", 0),
    } for t in tasks]

    return _json_response({"category": category or "default", "tasks": formatted})


async def handle_add_task(arguments):
    """Add a new task"""
    text = arguments["text"]
    category = arguments.get("category")
    task_mgr = get_task_manager(category)
    task_id = task_mgr.add_task(text)
    return _json_response({
        "task_id": task_id, "text": text,
        "category": category or "default", "status": "created"})


async def handle_get_current_task(arguments):
    """Get current task"""
    category = arguments.get("category")
    task_mgr = get_task_manager(category)
    current = task_mgr.get_current_task()
    if not current:
        return _json_response({"current_task": None})
    return _json_response({"current_task": {
        "id": current["id"], "text": current["text"],
        "done": current.get("done", False), "day": current.get("day"),
        "priority": current.get("priority", "none"),
        "status": current.get("status", "todo"),
    }})


async def handle_set_current_task(arguments):
    """Set current task"""
    task_id = arguments["task_id"]
    task_mgr = get_task_manager(arguments.get("category"))
    task_mgr.set_current(task_id)
    return _json_response({"task_id": task_id, "status": "set as current"})


async def handle_update_task(arguments):
    """Update task text"""
    task_id, text = arguments["task_id"], arguments["text"]
    task_mgr = get_task_manager(arguments.get("category"))
    task_mgr.edit_task(task_id, text)
    return _json_response(
        {"task_id": task_id, "text": text, "status": "updated"})


async def handle_delete_task(arguments):
    """Delete/archive task"""
    task_id = arguments["task_id"]
    task_mgr = get_task_manager(arguments.get("category"))
    task_mgr.delete_task(task_id)
    return _json_response({"task_id": task_id, "status": "deleted"})


# Task Property Handlers

async def handle_set_task_day(arguments):
    """Set task day"""
    task_id = arguments["task_id"]
    day = arguments.get("day")
    task_mgr = get_task_manager(arguments.get("category"))
    task_mgr.set_task_day(task_id, day)
    return _json_response(
        {"task_id": task_id, "day": day, "status": "updated"})


async def handle_set_task_priority(arguments):
    """Set task priority"""
    task_id, priority = arguments["task_id"], arguments["priority"]
    task_mgr = get_task_manager(arguments.get("category"))
    task_mgr.set_task_priority(task_id, priority)
    return _json_response(
        {"task_id": task_id, "priority": priority, "status": "updated"})


async def handle_set_task_status(arguments):
    """Set task status"""
    task_id, status = arguments["task_id"], arguments["status"]
    task_mgr = get_task_manager(arguments.get("category"))
    task_mgr.set_task_status(task_id, status)
    return _json_response(
        {"task_id": task_id, "status": status, "updated": "success"})


# Utility Handlers

async def handle_get_project_context():
    """Get project context"""
    project_dir = get_project_dir()
    jot_file = project_dir / ".jot.json"
    has_jot = jot_file.exists()

    cat_mgr = get_category_manager(project_dir)
    return _json_response({
        "project_dir": str(project_dir),
        "has_jot": has_jot,
        "jot_file": str(jot_file) if has_jot else None,
        "local_categories": cat_mgr.discover_categories(),
        "global_categories": cat_mgr.discover_global_categories(),
    })
