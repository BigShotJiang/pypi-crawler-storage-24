#!/usr/bin/env python3
"""jot MCP Server — Model Context Protocol for jot task management."""

from typing import Any

from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import Tool, TextContent

from jot.mcp.schemas import list_tools as get_tool_schemas
from jot.mcp.handlers import (
    handle_list_categories, handle_get_category_info,
    handle_create_category, handle_list_tasks, handle_add_task,
    handle_get_current_task, handle_set_current_task, handle_update_task,
    handle_delete_task, handle_set_task_day, handle_set_task_priority,
    handle_set_task_status, handle_get_project_context,
)

app = Server("jot")

# Dispatch table replaces long if-elif chain
_HANDLERS = {
    "list_categories": lambda args: handle_list_categories(),
    "get_category_info": handle_get_category_info,
    "create_category": handle_create_category,
    "list_tasks": handle_list_tasks,
    "add_task": handle_add_task,
    "get_current_task": handle_get_current_task,
    "set_current_task": handle_set_current_task,
    "update_task": handle_update_task,
    "delete_task": handle_delete_task,
    "set_task_day": handle_set_task_day,
    "set_task_priority": handle_set_task_priority,
    "set_task_status": handle_set_task_status,
    "get_project_context": lambda args: handle_get_project_context(),
}


@app.list_tools()
async def list_tools() -> list[Tool]:
    """List available MCP tools."""
    return get_tool_schemas()


@app.call_tool()
async def call_tool(name: str, arguments: Any) -> list[TextContent]:
    """Dispatch tool call to appropriate handler."""
    try:
        handler = _HANDLERS.get(name)
        if not handler:
            return [TextContent(type="text", text=f"Unknown tool: {name}")]
        return await handler(arguments)
    except Exception as e:
        return [TextContent(type="text", text=f"Error: {str(e)}")]


async def main():
    """Run the MCP server."""
    async with stdio_server() as (read_stream, write_stream):
        await app.run(
            read_stream, write_stream, app.create_initialization_options())


if __name__ == "__main__":
    import asyncio
    asyncio.run(main())
