#!/usr/bin/env python3
"""Tests for jot.ui.styles — central terminal style module"""

import jot.ui.styles as styles


class TestFormattingConstants:
    """Verify terminal formatting constants are valid ANSI sequences"""

    def test_reset_is_ansi(self):
        assert styles.RESET.startswith('\033[')

    def test_bold_is_ansi(self):
        assert styles.BOLD.startswith('\033[')

    def test_dim_is_ansi(self):
        assert styles.DIM.startswith('\033[')

    def test_reverse_is_ansi(self):
        assert styles.REVERSE.startswith('\033[')

    def test_formatting_are_strings(self):
        for name in ('RESET', 'BOLD', 'DIM', 'REVERSE'):
            val = getattr(styles, name)
            assert isinstance(val, str), f"{name} should be str, got {type(val)}"


class TestBaseColors:
    """Verify all base color constants"""

    COLOR_NAMES = [
        'RED', 'GREEN', 'YELLOW', 'BLUE', 'MAGENTA',
        'CYAN', 'WHITE', 'GRAY', 'ORANGE', 'BLACK',
    ]

    def test_all_colors_defined(self):
        for name in self.COLOR_NAMES:
            assert hasattr(styles, name), f"Missing color: {name}"

    def test_all_colors_are_ansi(self):
        for name in self.COLOR_NAMES:
            val = getattr(styles, name)
            assert isinstance(val, str), f"{name} should be str"
            assert val.startswith('\033['), f"{name} should start with ESC["

    def test_colors_are_distinct(self):
        values = [getattr(styles, name) for name in self.COLOR_NAMES]
        assert len(values) == len(set(values)), "Duplicate color values found"


class TestPriorityMapping:
    """Verify priority color and symbol mappings"""

    EXPECTED_KEYS = {'none', 'low', 'medium', 'high'}

    def test_priority_colors_keys(self):
        assert set(styles.PRIORITY_COLORS.keys()) == self.EXPECTED_KEYS

    def test_priority_symbols_keys(self):
        assert set(styles.PRIORITY_SYMBOLS.keys()) == self.EXPECTED_KEYS

    def test_priority_colors_are_ansi(self):
        for key, val in styles.PRIORITY_COLORS.items():
            assert isinstance(val, str), f"PRIORITY_COLORS[{key}] should be str"
            assert val.startswith('\033['), f"PRIORITY_COLORS[{key}] not ANSI"

    def test_priority_symbols_are_strings(self):
        for key, val in styles.PRIORITY_SYMBOLS.items():
            assert isinstance(val, str), f"PRIORITY_SYMBOLS[{key}] should be str"

    def test_priority_none_symbol_is_empty(self):
        assert styles.PRIORITY_SYMBOLS['none'] == ''

    def test_priority_high_is_red(self):
        assert styles.PRIORITY_COLORS['high'] == styles.RED

    def test_priority_low_is_blue(self):
        assert styles.PRIORITY_COLORS['low'] == styles.BLUE

    def test_priority_medium_is_yellow(self):
        assert styles.PRIORITY_COLORS['medium'] == styles.YELLOW


class TestStatusMapping:
    """Verify status color and symbol mappings"""

    EXPECTED_KEYS = {'todo', 'in-progress', 'blocked', 'done'}

    def test_status_colors_keys(self):
        assert set(styles.STATUS_COLORS.keys()) == self.EXPECTED_KEYS

    def test_status_symbols_keys(self):
        assert set(styles.STATUS_SYMBOLS.keys()) == self.EXPECTED_KEYS

    def test_status_colors_are_ansi(self):
        for key, val in styles.STATUS_COLORS.items():
            assert isinstance(val, str), f"STATUS_COLORS[{key}] should be str"
            assert val.startswith('\033['), f"STATUS_COLORS[{key}] not ANSI"

    def test_status_symbols_are_strings(self):
        for key, val in styles.STATUS_SYMBOLS.items():
            assert isinstance(val, str), f"STATUS_SYMBOLS[{key}] should be str"

    def test_status_todo_symbol_is_empty(self):
        assert styles.STATUS_SYMBOLS['todo'] == ''

    def test_status_done_is_green(self):
        assert styles.STATUS_COLORS['done'] == styles.GREEN

    def test_status_blocked_is_red(self):
        assert styles.STATUS_COLORS['blocked'] == styles.RED

    def test_status_in_progress_is_cyan(self):
        assert styles.STATUS_COLORS['in-progress'] == styles.CYAN


class TestHighlightConstants:
    """Verify highlight display constants"""

    def test_bg_yellow_defined(self):
        assert isinstance(styles.BG_YELLOW, str)
        assert styles.BG_YELLOW.startswith('\033[')

    def test_highlight_colors_is_dict(self):
        assert isinstance(styles.HIGHLIGHT_COLORS, dict)
        assert len(styles.HIGHLIGHT_COLORS) >= 5

    def test_highlight_colors_all_ansi(self):
        for name, fmt in styles.HIGHLIGHT_COLORS.items():
            assert isinstance(fmt, str), f"{name} format should be str"
            assert '\033[' in fmt, f"{name} format should contain ANSI codes"

    def test_highlight_default_in_colors(self):
        assert styles.HIGHLIGHT_DEFAULT in styles.HIGHLIGHT_COLORS

    def test_highlight_fmt_matches_default(self):
        assert styles.HIGHLIGHT_FMT == styles.HIGHLIGHT_COLORS[styles.HIGHLIGHT_DEFAULT]


class TestArchiveConstants:
    """Verify archive display constants"""

    def test_archive_symbol_defined(self):
        assert isinstance(styles.ARCHIVE_SYMBOL, str)
        assert len(styles.ARCHIVE_SYMBOL) > 0

    def test_archive_color_is_dim(self):
        assert styles.ARCHIVE_COLOR == styles.DIM


class TestModuleReExport:
    """Verify styles are accessible via jot.ui package"""

    def test_import_from_ui_package(self):
        from jot.ui import CYAN, BOLD, RESET
        assert CYAN == styles.CYAN
        assert BOLD == styles.BOLD
        assert RESET == styles.RESET

    def test_priority_colors_from_ui(self):
        from jot.ui import PRIORITY_COLORS
        assert PRIORITY_COLORS is styles.PRIORITY_COLORS

    def test_status_colors_from_ui(self):
        from jot.ui import STATUS_COLORS
        assert STATUS_COLORS is styles.STATUS_COLORS


class TestNoStaleDefinitions:
    """Verify ANSI codes aren't redefined outside styles.py"""

    def _count_ansi_defs_in_file(self, filepath):
        """Count lines matching `= '\\033[` in a file"""
        import re
        count = 0
        with open(filepath) as f:
            for line in f:
                stripped = line.strip()
                # Skip comments and imports
                if stripped.startswith('#') or stripped.startswith('from ') or stripped.startswith('import '):
                    continue
                if re.search(r"= ['\"]\\033\[", stripped):
                    count += 1
        return count

    def test_display_has_no_local_ansi(self):
        from pathlib import Path
        path = Path(__file__).parent.parent / 'jot' / 'ui' / 'display.py'
        assert self._count_ansi_defs_in_file(path) == 0, "display.py still has local ANSI defs"

    def test_formatting_has_no_local_ansi(self):
        from pathlib import Path
        path = Path(__file__).parent.parent / 'jot' / 'ui' / 'formatting.py'
        assert self._count_ansi_defs_in_file(path) == 0, "formatting.py still has local ANSI defs"

    def test_handler_has_no_local_ansi(self):
        from pathlib import Path
        path = Path(__file__).parent.parent / 'jot' / 'commands' / 'handler.py'
        assert self._count_ansi_defs_in_file(path) == 0, "handler.py still has local ANSI defs"

    def test_task_manager_uses_lazy_import_only(self):
        """task_manager.py uses lazy import to avoid circular dep — only 1 occurrence allowed"""
        from pathlib import Path
        path = Path(__file__).parent.parent / 'jot' / 'core' / 'task_manager.py'
        # The lazy import inside _autofix_duplicate_ids is acceptable (avoids circular dep)
        assert self._count_ansi_defs_in_file(path) == 0, "task_manager.py has inline ANSI defs"


if __name__ == '__main__':
    import pytest
    import sys
    sys.exit(pytest.main([__file__, '-v']))
