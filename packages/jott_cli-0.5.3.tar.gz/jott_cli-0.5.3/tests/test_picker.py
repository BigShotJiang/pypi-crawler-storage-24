#!/usr/bin/env python3
"""Tests for jot.ui.picker — reusable interactive terminal picker"""

import sys
from io import StringIO
from unittest.mock import patch

from jot.ui.picker import PickerItem, PickerResult, fuzzy_picker, quick_picker


def _keys(*keys):
    """Create a side_effect for get_key that returns keys in sequence."""
    seq = list(keys)
    def get_key_side_effect(timeout=30.0):
        if seq:
            return seq.pop(0)
        return '\x1b'
    return get_key_side_effect


def _items(*labels):
    """Build a list of simple PickerItems from labels."""
    return [PickerItem(value=label, label=label) for label in labels]


class TestPickerItem:
    """Test PickerItem dataclass"""

    def test_minimal_construction(self):
        item = PickerItem(value="x", label="X")
        assert item.value == "x"
        assert item.label == "X"
        assert item.annotation == ""
        assert item.color == ""
        assert item.symbol == ""

    def test_full_construction(self):
        item = PickerItem(value="high", label="high", annotation="(urgent)",
                          color="\033[91m", symbol="●")
        assert item.value == "high"
        assert item.symbol == "●"
        assert item.annotation == "(urgent)"

    def test_result_cancelled(self):
        r = PickerResult()
        assert r.value is None
        assert r.is_freeform is False

    def test_result_selected(self):
        r = PickerResult(value="foo")
        assert r.value == "foo"
        assert r.is_freeform is False

    def test_result_freeform(self):
        r = PickerResult(value="new-cat", is_freeform=True)
        assert r.value == "new-cat"
        assert r.is_freeform is True


class TestFuzzyPickerNavigation:
    """Test arrow-key navigation and selection"""

    @patch('jot.ui.picker.get_key')
    @patch('sys.stdout', new_callable=StringIO)
    def test_enter_selects_first_by_default(self, mock_out, mock_gk):
        mock_gk.side_effect = _keys('\r')
        items = _items("alpha", "beta", "gamma")
        result = fuzzy_picker(items, prompt="Pick")
        assert result.value == "alpha"

    @patch('jot.ui.picker.get_key')
    @patch('sys.stdout', new_callable=StringIO)
    def test_down_then_enter_selects_second(self, mock_out, mock_gk):
        mock_gk.side_effect = _keys('DOWN', '\r')
        items = _items("alpha", "beta", "gamma")
        result = fuzzy_picker(items, prompt="Pick")
        assert result.value == "beta"

    @patch('jot.ui.picker.get_key')
    @patch('sys.stdout', new_callable=StringIO)
    def test_down_down_enter_selects_third(self, mock_out, mock_gk):
        mock_gk.side_effect = _keys('DOWN', 'DOWN', '\r')
        items = _items("alpha", "beta", "gamma")
        result = fuzzy_picker(items, prompt="Pick")
        assert result.value == "gamma"

    @patch('jot.ui.picker.get_key')
    @patch('sys.stdout', new_callable=StringIO)
    def test_up_at_top_stays(self, mock_out, mock_gk):
        mock_gk.side_effect = _keys('UP', '\r')
        items = _items("alpha", "beta")
        result = fuzzy_picker(items, prompt="Pick")
        assert result.value == "alpha"

    @patch('jot.ui.picker.get_key')
    @patch('sys.stdout', new_callable=StringIO)
    def test_down_past_bottom_stays(self, mock_out, mock_gk):
        mock_gk.side_effect = _keys('DOWN', 'DOWN', 'DOWN', 'DOWN', '\r')
        items = _items("alpha", "beta")
        result = fuzzy_picker(items, prompt="Pick")
        assert result.value == "beta"

    @patch('jot.ui.picker.get_key')
    @patch('sys.stdout', new_callable=StringIO)
    def test_esc_cancels(self, mock_out, mock_gk):
        mock_gk.side_effect = _keys('\x1b')
        items = _items("alpha", "beta")
        result = fuzzy_picker(items, prompt="Pick")
        assert result.value is None
        assert result.is_freeform is False

    @patch('jot.ui.picker.get_key')
    @patch('sys.stdout', new_callable=StringIO)
    def test_default_index_respected(self, mock_out, mock_gk):
        mock_gk.side_effect = _keys('\r')
        items = _items("alpha", "beta", "gamma")
        result = fuzzy_picker(items, prompt="Pick", default_index=2)
        assert result.value == "gamma"

    @patch('jot.ui.picker.get_key')
    @patch('sys.stdout', new_callable=StringIO)
    def test_default_index_clamped(self, mock_out, mock_gk):
        mock_gk.side_effect = _keys('\r')
        items = _items("alpha", "beta")
        result = fuzzy_picker(items, prompt="Pick", default_index=99)
        assert result.value == "beta"


class TestFuzzyPickerFiltering:
    """Test type-to-filter behavior"""

    @patch('jot.ui.picker.get_key')
    @patch('sys.stdout', new_callable=StringIO)
    def test_typing_filters_items(self, mock_out, mock_gk):
        mock_gk.side_effect = _keys('b', '\r')
        items = _items("alpha", "beta", "gamma")
        result = fuzzy_picker(items, prompt="Pick")
        assert result.value == "beta"

    @patch('jot.ui.picker.get_key')
    @patch('sys.stdout', new_callable=StringIO)
    def test_typing_multiple_chars_filters(self, mock_out, mock_gk):
        mock_gk.side_effect = _keys('g', 'a', 'm', '\r')
        items = _items("alpha", "beta", "gamma")
        result = fuzzy_picker(items, prompt="Pick")
        assert result.value == "gamma"

    @patch('jot.ui.picker.get_key')
    @patch('sys.stdout', new_callable=StringIO)
    def test_backspace_clears_filter(self, mock_out, mock_gk):
        # Type 'z' (no match), backspace, then enter selects first
        mock_gk.side_effect = _keys('z', '\x7f', '\r')
        items = _items("alpha", "beta")
        result = fuzzy_picker(items, prompt="Pick")
        assert result.value == "alpha"

    @patch('jot.ui.picker.get_key')
    @patch('sys.stdout', new_callable=StringIO)
    def test_no_matches_enter_cancels(self, mock_out, mock_gk):
        mock_gk.side_effect = _keys('z', 'z', 'z', '\r')
        items = _items("alpha", "beta")
        result = fuzzy_picker(items, prompt="Pick")
        assert result.value is None

    @patch('jot.ui.picker.get_key')
    @patch('sys.stdout', new_callable=StringIO)
    def test_filter_resets_selection(self, mock_out, mock_gk):
        # Move down to "gamma", then type 'a' to filter — selection resets to 0
        mock_gk.side_effect = _keys('DOWN', 'DOWN', 'a', '\r')
        items = _items("alpha", "beta", "gamma")
        result = fuzzy_picker(items, prompt="Pick")
        # "alpha" and "gamma" match 'a', alpha should score higher (starts with a)
        assert result.value in ("alpha", "gamma")

    @patch('jot.ui.picker.get_key')
    @patch('sys.stdout', new_callable=StringIO)
    def test_timeout_continues_loop(self, mock_out, mock_gk):
        # None = timeout, should continue, then Enter selects
        mock_gk.side_effect = _keys(None, None, '\r')
        items = _items("alpha")
        result = fuzzy_picker(items, prompt="Pick")
        assert result.value == "alpha"


class TestFuzzyPickerFreeform:
    """Test allow_freeform behavior"""

    @patch('jot.ui.picker.get_key')
    @patch('sys.stdout', new_callable=StringIO)
    def test_freeform_returns_typed_text(self, mock_out, mock_gk):
        mock_gk.side_effect = _keys('n', 'e', 'w', '\r')
        items = _items("alpha", "beta")
        result = fuzzy_picker(items, prompt="Pick", allow_freeform=True)
        assert result.value == "new"
        assert result.is_freeform is True

    @patch('jot.ui.picker.get_key')
    @patch('sys.stdout', new_callable=StringIO)
    def test_freeform_not_returned_when_match_exists(self, mock_out, mock_gk):
        mock_gk.side_effect = _keys('a', '\r')
        items = _items("alpha", "beta")
        result = fuzzy_picker(items, prompt="Pick", allow_freeform=True)
        # "alpha" matches 'a', so it's a regular selection
        assert result.value == "alpha"
        assert result.is_freeform is False

    @patch('jot.ui.picker.get_key')
    @patch('sys.stdout', new_callable=StringIO)
    def test_freeform_disabled_returns_none(self, mock_out, mock_gk):
        mock_gk.side_effect = _keys('z', 'z', '\r')
        items = _items("alpha", "beta")
        result = fuzzy_picker(items, prompt="Pick", allow_freeform=False)
        assert result.value is None
        assert result.is_freeform is False


class TestQuickPicker:
    """Test quick_picker convenience function"""

    @patch('jot.ui.picker.get_key')
    @patch('sys.stdout', new_callable=StringIO)
    def test_enter_selects_default(self, mock_out, mock_gk):
        mock_gk.side_effect = _keys('\r')
        items = _items("low", "medium", "high")
        result = quick_picker(items, prompt="Priority")
        assert result.value == "low"

    @patch('jot.ui.picker.get_key')
    @patch('sys.stdout', new_callable=StringIO)
    def test_navigation_works(self, mock_out, mock_gk):
        mock_gk.side_effect = _keys('DOWN', 'DOWN', '\r')
        items = _items("low", "medium", "high")
        result = quick_picker(items, prompt="Priority")
        assert result.value == "high"

    @patch('jot.ui.picker.get_key')
    @patch('sys.stdout', new_callable=StringIO)
    def test_typing_ignored(self, mock_out, mock_gk):
        # Type 'h' — should be ignored (filter disabled), then Enter
        mock_gk.side_effect = _keys('h', '\r')
        items = _items("low", "medium", "high")
        result = quick_picker(items, prompt="Priority")
        # Should still select first item since typing is ignored
        assert result.value == "low"

    @patch('jot.ui.picker.get_key')
    @patch('sys.stdout', new_callable=StringIO)
    def test_default_index(self, mock_out, mock_gk):
        mock_gk.side_effect = _keys('\r')
        items = _items("Mon", "Tue", "Wed", "Thu", "Fri")
        result = quick_picker(items, prompt="Day", default_index=2)
        assert result.value == "Wed"


class TestPickerEdgeCases:
    """Test edge cases"""

    def test_empty_items_returns_none(self):
        result = fuzzy_picker([], prompt="Pick")
        assert result.value is None

    @patch('jot.ui.picker.get_key')
    @patch('sys.stdout', new_callable=StringIO)
    def test_single_item(self, mock_out, mock_gk):
        mock_gk.side_effect = _keys('\r')
        items = _items("only")
        result = fuzzy_picker(items, prompt="Pick")
        assert result.value == "only"

    @patch('jot.ui.picker.get_key')
    @patch('sys.stdout', new_callable=StringIO)
    def test_newline_also_selects(self, mock_out, mock_gk):
        mock_gk.side_effect = _keys('\n')
        items = _items("alpha")
        result = fuzzy_picker(items, prompt="Pick")
        assert result.value == "alpha"


class TestPickerRendering:
    """Test screen output content"""

    @patch('jot.ui.picker.get_key')
    @patch('sys.stdout', new_callable=StringIO)
    def test_prompt_displayed(self, mock_out, mock_gk):
        mock_gk.side_effect = _keys('\x1b')
        fuzzy_picker(_items("a"), prompt="My Title")
        output = mock_out.getvalue()
        assert "My Title" in output

    @patch('jot.ui.picker.get_key')
    @patch('sys.stdout', new_callable=StringIO)
    def test_selected_item_has_arrow(self, mock_out, mock_gk):
        mock_gk.side_effect = _keys('\x1b')
        fuzzy_picker(_items("alpha", "beta"), prompt="Pick")
        output = mock_out.getvalue()
        assert "\u2192" in output  # → arrow

    @patch('jot.ui.picker.get_key')
    @patch('sys.stdout', new_callable=StringIO)
    def test_annotation_displayed(self, mock_out, mock_gk):
        mock_gk.side_effect = _keys('\x1b')
        items = [PickerItem(value="x", label="proj", annotation="~/projects/proj")]
        fuzzy_picker(items, prompt="Pick")
        output = mock_out.getvalue()
        assert "~/projects/proj" in output

    @patch('jot.ui.picker.get_key')
    @patch('sys.stdout', new_callable=StringIO)
    def test_symbol_displayed(self, mock_out, mock_gk):
        mock_gk.side_effect = _keys('\x1b')
        items = [PickerItem(value="high", label="high", symbol="●")]
        fuzzy_picker(items, prompt="Pick")
        output = mock_out.getvalue()
        assert "●" in output

    @patch('jot.ui.picker.get_key')
    @patch('sys.stdout', new_callable=StringIO)
    def test_overflow_shows_more(self, mock_out, mock_gk):
        mock_gk.side_effect = _keys('\x1b')
        items = _items(*[f"item{i}" for i in range(20)])
        fuzzy_picker(items, prompt="Pick", max_display=5)
        output = mock_out.getvalue()
        assert "15 more" in output

    @patch('jot.ui.picker.get_key')
    @patch('sys.stdout', new_callable=StringIO)
    def test_filter_disabled_no_search_field(self, mock_out, mock_gk):
        mock_gk.side_effect = _keys('\x1b')
        fuzzy_picker(_items("a", "b"), prompt="Pick", enable_filter=False)
        output = mock_out.getvalue()
        assert "Type to filter" not in output

    @patch('jot.ui.picker.get_key')
    @patch('sys.stdout', new_callable=StringIO)
    def test_freeform_hint_shown(self, mock_out, mock_gk):
        mock_gk.side_effect = _keys('z', 'z', '\x1b')
        fuzzy_picker(_items("alpha"), prompt="Pick",
                     allow_freeform=True, freeform_hint="Create new?")
        output = mock_out.getvalue()
        assert "Create new?" in output


if __name__ == '__main__':
    import pytest
    sys.exit(pytest.main([__file__, '-v']))
