#!/usr/bin/env python3
"""
Edge case tests for jot edit feature
Tests the edit functionality with various edge cases
"""

import sys
import tempfile
from pathlib import Path
from jot import TaskManager


def setup_test_env():
    """Create a temporary directory with test tasks"""
    temp_dir = tempfile.mkdtemp()
    temp_path = Path(temp_dir)
    return temp_path


def test_edit_preserves_metadata():
    """Test that editing preserves tally, day, done, and current fields"""
    print("\n🔍 TEST: Edit preserves metadata (tally, day, done, current)")

    temp_path = setup_test_env()
    tm = TaskManager(directory=temp_path)

    # Add a task with all metadata
    tm.add_task("Original task text")
    task = tm.tasks[0]
    task_id = task['id']

    # Set metadata
    task['tally'] = 5
    task['day'] = 'Monday'
    task['done'] = False
    task['current'] = True
    tm._save_tasks()

    # Edit the task
    success = tm.edit_task(task_id, "Edited task text")

    # Verify edit succeeded
    assert success, "Edit should succeed"

    # Verify metadata preserved
    edited_task = None
    for t in tm.tasks:
        if t['id'] == task_id:
            edited_task = t
            break

    assert edited_task is not None, "Task should exist after edit"
    assert edited_task['text'] == "Edited task text", "Text should be updated"
    assert (
        edited_task.get('tally') == 5
    ), f"Tally should be preserved (got {edited_task.get('tally')})"
    assert (
        edited_task.get('day') == 'Monday'
    ), f"Day should be preserved (got {edited_task.get('day')})"
    assert edited_task.get('done') is False, "Done should be preserved"
    assert edited_task.get('current') is True, "Current should be preserved"

    print("✅ PASS: Metadata preserved correctly")
    return True


def test_edit_very_long_text():
    """Test editing with very long text (1000+ characters)"""
    print("\n🔍 TEST: Edit with very long text (1000+ chars)")

    temp_path = setup_test_env()
    tm = TaskManager(directory=temp_path)

    # Add a task
    tm.add_task("Short task")
    task_id = tm.tasks[0]['id']

    # Create very long text
    long_text = "A" * 1000 + " test task with 1000+ characters"

    # Edit with long text
    success = tm.edit_task(task_id, long_text)

    assert success, "Edit should succeed with long text"
    assert tm.tasks[0]['text'] == long_text, "Long text should be stored correctly"

    print(f"✅ PASS: Handles {len(long_text)} character text")
    return True


def test_edit_special_characters():
    """Test editing with unicode and special characters"""
    print("\n🔍 TEST: Edit with special characters (unicode, emojis)")

    temp_path = setup_test_env()
    tm = TaskManager(directory=temp_path)

    # Add a task
    tm.add_task("Simple task")
    task_id = tm.tasks[0]['id']

    # Test various special characters
    test_cases = [
        "Task with emoji 🎉🚀✨",
        "Unicode: café, naïve, 日本語",
        "Symbols: @#$%^&*()_+-=[]{}|;:',.<>?/~`",
        'Quotes: "double" and \'single\'',
        "Backslash: C:\\Users\\test\\file.txt",
    ]

    for test_text in test_cases:
        success = tm.edit_task(task_id, test_text)
        assert success, f"Edit should succeed with: {test_text}"
        assert tm.tasks[0]['text'] == test_text, f"Text should match: {test_text}"
        print(f"  ✓ Handled: {test_text[:50]}...")

    print("✅ PASS: All special characters handled correctly")
    return True


def test_edit_whitespace():
    """Test that edit strips leading/trailing whitespace"""
    print("\n🔍 TEST: Edit strips whitespace correctly")

    temp_path = setup_test_env()
    tm = TaskManager(directory=temp_path)

    # Add a task
    tm.add_task("Original")
    task_id = tm.tasks[0]['id']

    # The edit happens in CommandHandler.edit_task() which calls .strip()
    # But TaskManager.edit_task() just stores what it's given
    # So we need to test both with and without stripping

    # Test that TaskManager stores exactly what's given (no auto-strip)
    success = tm.edit_task(task_id, "  spaces around  ")
    assert success, "Edit should succeed"
    assert tm.tasks[0]['text'] == "  spaces around  ", "TaskManager should store exact text"

    print("✅ PASS: TaskManager stores exact text (stripping handled by CLI)")
    return True


def test_edit_nonexistent_task():
    """Test editing a task ID that doesn't exist"""
    print("\n🔍 TEST: Edit non-existent task ID")

    temp_path = setup_test_env()
    tm = TaskManager(directory=temp_path)

    # Add a task with ID 1
    tm.add_task("Task 1")

    # Try to edit task 999 (doesn't exist)
    success = tm.edit_task(999, "New text")

    assert success is False, "Edit should fail for non-existent ID"
    print("✅ PASS: Returns False for non-existent task")
    return True


def test_edit_empty_string():
    """Test that empty string edit is handled by CLI (not TaskManager)"""
    print("\n🔍 TEST: Empty string handling")

    temp_path = setup_test_env()
    tm = TaskManager(directory=temp_path)

    # Add a task
    tm.add_task("Original text")
    task_id = tm.tasks[0]['id']

    # TaskManager.edit_task() will accept empty string
    # But CommandHandler.edit_task() and edit_current() check for empty and reject it
    success = tm.edit_task(task_id, "")

    assert success is True, "TaskManager allows empty string (CLI prevents it)"
    assert tm.tasks[0]['text'] == "", "Empty string is stored if passed"

    print("✅ PASS: TaskManager accepts empty (CLI validation prevents it)")
    return True


def test_edit_preserves_other_tasks():
    """Test that editing one task doesn't affect others"""
    print("\n🔍 TEST: Editing one task preserves others")

    temp_path = setup_test_env()
    tm = TaskManager(directory=temp_path)

    # Add multiple tasks
    tm.add_task("Task 1")
    tm.add_task("Task 2")
    tm.add_task("Task 3")

    task2_id = tm.tasks[1]['id']

    # Edit middle task
    success = tm.edit_task(task2_id, "Task 2 EDITED")

    assert success, "Edit should succeed"
    assert tm.tasks[0]['text'] == "Task 1", "Task 1 should be unchanged"
    assert tm.tasks[1]['text'] == "Task 2 EDITED", "Task 2 should be edited"
    assert tm.tasks[2]['text'] == "Task 3", "Task 3 should be unchanged"
    assert len(tm.tasks) == 3, "Should still have 3 tasks"

    print("✅ PASS: Other tasks preserved correctly")
    return True


def test_edit_persistence():
    """Test that edits are persisted to disk"""
    print("\n🔍 TEST: Edits persist to disk")

    temp_path = setup_test_env()
    tm1 = TaskManager(directory=temp_path)

    # Add and edit a task
    tm1.add_task("Original")
    task_id = tm1.tasks[0]['id']
    tm1.edit_task(task_id, "Edited text")

    # Create new TaskManager instance (loads from disk)
    tm2 = TaskManager(directory=temp_path)

    assert len(tm2.tasks) == 1, "Should load 1 task"
    assert tm2.tasks[0]['text'] == "Edited text", "Edited text should persist"
    assert tm2.tasks[0]['id'] == task_id, "Task ID should match"

    print("✅ PASS: Edits persist correctly")
    return True


def run_all_tests():
    """Run all edge case tests"""
    print("=" * 60)
    print("EDGE CASE TESTS FOR JOT EDIT FEATURE")
    print("=" * 60)

    tests = [
        test_edit_preserves_metadata,
        test_edit_very_long_text,
        test_edit_special_characters,
        test_edit_whitespace,
        test_edit_nonexistent_task,
        test_edit_empty_string,
        test_edit_preserves_other_tasks,
        test_edit_persistence,
    ]

    passed = 0
    failed = 0

    for test in tests:
        try:
            if test():
                passed += 1
        except AssertionError as e:
            print(f"❌ FAIL: {e}")
            failed += 1
        except Exception as e:
            print(f"❌ ERROR: {e}")
            failed += 1

    print("\n" + "=" * 60)
    print(f"RESULTS: {passed} passed, {failed} failed")
    print("=" * 60)

    return failed == 0


if __name__ == '__main__':
    import sys

    success = run_all_tests()
    sys.exit(0 if success else 1)
