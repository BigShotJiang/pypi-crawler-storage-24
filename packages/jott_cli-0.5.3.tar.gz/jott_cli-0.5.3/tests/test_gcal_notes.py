"""Tests for including task notes in Google Calendar event descriptions."""

from unittest.mock import Mock

from jot.integrations.gcal.events import create_gcal_event


class TestCreateGcalEventDescription:
    """Test that create_gcal_event uses the description parameter."""

    @staticmethod
    def _mock_service():
        """Return a mock Calendar service that captures the event body."""
        service = Mock()
        mock_insert = Mock()
        mock_insert.execute.return_value = {'htmlLink': 'https://cal.google.com/event/123'}
        service.events.return_value.insert.return_value = mock_insert
        return service

    def test_provided_description_used_in_event(self):
        """When a description is given, it appears in the event body."""
        service = self._mock_service()
        create_gcal_event(service, 'My task', description='These are my notes')

        body = service.events().insert.call_args[1]['body']
        assert body['description'] == 'These are my notes'

    def test_default_description_when_none(self):
        """When no description is given, falls back to default text."""
        service = self._mock_service()
        create_gcal_event(service, 'My task')

        body = service.events().insert.call_args[1]['body']
        assert body['description'] == 'Created from jot task'

    def test_default_description_when_explicit_none(self):
        """When description=None is passed explicitly, falls back to default."""
        service = self._mock_service()
        create_gcal_event(service, 'My task', description=None)

        body = service.events().insert.call_args[1]['body']
        assert body['description'] == 'Created from jot task'

    def test_empty_string_description_falls_back_to_default(self):
        """Empty string description should fall back to default."""
        service = self._mock_service()
        create_gcal_event(service, 'My task', description='')

        body = service.events().insert.call_args[1]['body']
        assert body['description'] == 'Created from jot task'


class TestExportSingleTaskPassesNotes:
    """Test that _export_single_task passes task notes to create_gcal_event."""

    def test_task_with_notes_passes_description(self):
        """Task notes are passed as the event description."""
        from unittest.mock import patch
        from jot.commands._gcal_mixin import GcalMixin

        handler = type('Handler', (GcalMixin,), {})()
        task = {'text': 'Team meeting', 'notes': 'Discuss Q2 roadmap'}

        mock_service = Mock()
        mock_insert = Mock()
        mock_insert.execute.return_value = {'htmlLink': 'https://cal.google.com/event/1'}
        mock_service.events.return_value.insert.return_value = mock_insert

        with patch('jot.commands._gcal_mixin.create_gcal_event',
                   wraps=create_gcal_event) as mock_create:
            mock_create.return_value = 'https://cal.google.com/event/1'
            handler._export_single_task(mock_service, 'default', task)
            mock_create.assert_called_once()
            _, kwargs = mock_create.call_args
            assert kwargs['description'] == 'Discuss Q2 roadmap'

    def test_task_without_notes_passes_none(self):
        """Task with no notes passes description=None (triggers default)."""
        from unittest.mock import patch
        from jot.commands._gcal_mixin import GcalMixin

        handler = type('Handler', (GcalMixin,), {})()
        task = {'text': 'Quick sync'}

        with patch('jot.commands._gcal_mixin.create_gcal_event') as mock_create:
            mock_create.return_value = 'https://cal.google.com/event/1'
            handler._export_single_task(Mock(), 'default', task)
            _, kwargs = mock_create.call_args
            assert kwargs['description'] is None

    def test_task_with_whitespace_only_notes_passes_none(self):
        """Task with whitespace-only notes passes description=None."""
        from unittest.mock import patch
        from jot.commands._gcal_mixin import GcalMixin

        handler = type('Handler', (GcalMixin,), {})()
        task = {'text': 'Standup', 'notes': '   \n  '}

        with patch('jot.commands._gcal_mixin.create_gcal_event') as mock_create:
            mock_create.return_value = 'https://cal.google.com/event/1'
            handler._export_single_task(Mock(), 'default', task)
            _, kwargs = mock_create.call_args
            assert kwargs['description'] is None


class TestHandleGcalPassesNotes:
    """Test that _handle_gcal keyword handler passes task notes."""

    def test_keyword_handler_passes_notes(self):
        """gcal: keyword handler includes task notes as description."""
        from unittest.mock import patch, Mock as M
        from jot.integrations.keywords._handlers_mixin import HandlersMixin

        handler = type('H', (HandlersMixin,), {})()
        task = {'text': 'gcal: Sprint planning', 'notes': 'Review backlog first'}

        mock_service = Mock()
        mock_insert = Mock()
        mock_insert.execute.return_value = {'htmlLink': 'https://cal.google.com/event/1'}
        mock_service.events.return_value.insert.return_value = mock_insert

        with patch('jot.integrations.keywords._handlers_mixin.GCAL_AVAILABLE', True), \
             patch('jot.integrations.keywords._handlers_mixin.GoogleCalendarAccountManager') as mock_mgr, \
             patch('jot.integrations.keywords._handlers_mixin.GoogleCalendarAuth') as mock_auth, \
             patch('jot.integrations.keywords._handlers_mixin.create_gcal_event') as mock_create:
            mock_mgr.return_value.discover_accounts.return_value = ['default']
            mock_auth.return_value.get_service.return_value = mock_service
            mock_create.return_value = 'https://cal.google.com/event/1'

            handler._handle_gcal(task)

            mock_create.assert_called_once()
            _, kwargs = mock_create.call_args
            assert kwargs['description'] == 'Review backlog first'

    def test_keyword_handler_no_notes_passes_none(self):
        """gcal: keyword handler passes None when task has no notes."""
        from unittest.mock import patch
        from jot.integrations.keywords._handlers_mixin import HandlersMixin

        handler = type('H', (HandlersMixin,), {})()
        task = {'text': 'gcal: Quick check-in'}

        with patch('jot.integrations.keywords._handlers_mixin.GCAL_AVAILABLE', True), \
             patch('jot.integrations.keywords._handlers_mixin.GoogleCalendarAccountManager') as mock_mgr, \
             patch('jot.integrations.keywords._handlers_mixin.GoogleCalendarAuth') as mock_auth, \
             patch('jot.integrations.keywords._handlers_mixin.create_gcal_event') as mock_create:
            mock_mgr.return_value.discover_accounts.return_value = ['default']
            mock_auth.return_value.get_service.return_value = Mock()
            mock_create.return_value = 'https://cal.google.com/event/1'

            handler._handle_gcal(task)

            _, kwargs = mock_create.call_args
            assert kwargs['description'] is None
