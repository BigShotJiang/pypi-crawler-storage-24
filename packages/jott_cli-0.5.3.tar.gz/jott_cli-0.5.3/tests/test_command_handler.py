#!/usr/bin/env python3
"""
Unit tests for CommandHandler class
Tests CLI command handling logic
"""

import sys
import tempfile
from pathlib import Path
from unittest.mock import patch
from jot import TaskManager
from jot.commands.handler import CommandHandler


class TestCommandHandlerBasics:
    """Test basic CommandHandler operations"""

    def test_quit(self):
        """Test quit command returns False"""
        with tempfile.TemporaryDirectory() as tmpdir:
            tm = TaskManager(directory=Path(tmpdir))
            handler = CommandHandler(tm)

            result = handler.quit()

            assert result is False

    def test_refresh(self):
        """Test refresh reloads tasks from disk"""
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = Path(tmpdir)
            tm = TaskManager(directory=tmpdir)
            handler = CommandHandler(tm)

            # Add a task
            tm.add_task("Test task")
            initial_count = len(tm.tasks)

            # Modify file externally
            tm2 = TaskManager(directory=tmpdir)
            tm2.add_task("External task")

            # Refresh should reload
            handler.refresh()

            assert len(tm.tasks) == initial_count + 1

    def test_help(self):
        """Test help displays command list"""
        with tempfile.TemporaryDirectory() as tmpdir:
            tm = TaskManager(directory=Path(tmpdir))
            handler = CommandHandler(tm)

            # Should return True and not crash
            result = handler.help()

            assert result is True


class TestCommandHandlerTaskManagement:
    """Test task creation, deletion, and editing"""

    def test_add_task_with_input(self):
        """Test adding task with user input"""
        with tempfile.TemporaryDirectory() as tmpdir:
            tm = TaskManager(directory=Path(tmpdir))
            handler = CommandHandler(tm)

            # Mock input to provide task text
            with patch('builtins.input', return_value='New task from input'):
                result = handler.add_task()

            assert result is True
            assert len(tm.tasks) == 1
            assert tm.tasks[0]['text'] == 'New task from input'

    def test_add_task_empty_input_cancelled(self):
        """Test adding task with empty input is cancelled"""
        with tempfile.TemporaryDirectory() as tmpdir:
            tm = TaskManager(directory=Path(tmpdir))
            handler = CommandHandler(tm)

            # Mock input to provide empty text
            with patch('builtins.input', return_value=''):
                result = handler.add_task()

            assert result is True
            assert len(tm.tasks) == 0  # No task added

    def test_delete_current_no_task(self):
        """Test deleting current when no tasks exist"""
        with tempfile.TemporaryDirectory() as tmpdir:
            tm = TaskManager(directory=Path(tmpdir))
            handler = CommandHandler(tm)

            result = handler.delete_current()

            assert result is True  # Should handle gracefully

    def test_delete_current_with_task(self):
        """Test deleting current task archives it"""
        with tempfile.TemporaryDirectory() as tmpdir:
            tm = TaskManager(directory=Path(tmpdir))
            handler = CommandHandler(tm)

            # Add tasks
            tm.add_task("Task 1")
            tm.add_task("Task 2")
            task_id = tm.tasks[0]['id']
            tm.set_current(task_id)  # Set first as current

            initial_count = len(tm.tasks)
            result = handler.delete_current()

            assert result is True
            assert len(tm.tasks) == initial_count - 1
            assert len(tm.archived) == 1

    def test_delete_task_by_id(self):
        """Test deleting task by ID"""
        with tempfile.TemporaryDirectory() as tmpdir:
            tm = TaskManager(directory=Path(tmpdir))
            handler = CommandHandler(tm)

            # Add tasks
            tm.add_task("Task 1")
            tm.add_task("Task 2")
            task_id = tm.tasks[0]['id']

            # Mock input to provide task ID
            with patch('builtins.input', return_value=str(task_id)):
                result = handler.delete_task()

            assert result is True
            assert len(tm.tasks) == 1
            assert len(tm.archived) == 1

    def test_delete_task_invalid_id(self):
        """Test deleting task with invalid ID"""
        with tempfile.TemporaryDirectory() as tmpdir:
            tm = TaskManager(directory=Path(tmpdir))
            handler = CommandHandler(tm)

            tm.add_task("Task 1")

            # Mock input to provide invalid ID
            with patch('builtins.input', return_value='999'):
                result = handler.delete_task()

            assert result is True
            assert len(tm.tasks) == 1  # Task not deleted
            assert len(tm.archived) == 0

    def test_set_current_by_id(self):
        """Test setting current task by ID"""
        with tempfile.TemporaryDirectory() as tmpdir:
            tm = TaskManager(directory=Path(tmpdir))
            handler = CommandHandler(tm)

            # Add tasks
            tm.add_task("Task 1")
            tm.add_task("Task 2")
            task_id = tm.tasks[1]['id']

            # Mock input to provide task ID
            with patch('builtins.input', return_value=str(task_id)):
                result = handler.set_current()

            assert result is True
            assert tm.tasks[1]['current'] is True
            assert tm.tasks[0]['current'] is False

    def test_set_current_invalid_id(self):
        """Test setting current with invalid ID"""
        with tempfile.TemporaryDirectory() as tmpdir:
            tm = TaskManager(directory=Path(tmpdir))
            handler = CommandHandler(tm)

            tm.add_task("Task 1")

            # Mock input to provide invalid ID
            with patch('builtins.input', return_value='999'):
                result = handler.set_current()

            assert result is True
            # Current should not change

    def test_edit_current_no_task(self):
        """Test editing current when no tasks exist"""
        with tempfile.TemporaryDirectory() as tmpdir:
            tm = TaskManager(directory=Path(tmpdir))
            handler = CommandHandler(tm)

            # Mock input_with_prefill
            with patch('jot.commands._core_mixin.input_with_prefill', return_value='New text'):
                result = handler.edit_current()

            assert result is True

    def test_edit_current_with_task(self):
        """Test editing current task"""
        with tempfile.TemporaryDirectory() as tmpdir:
            tm = TaskManager(directory=Path(tmpdir))
            handler = CommandHandler(tm)

            # Add task and set as current
            tm.add_task("Original text")
            task_id = tm.tasks[0]['id']
            tm.set_current(task_id)

            # Mock input_with_prefill to return new text
            with patch('jot.commands._core_mixin.input_with_prefill', return_value='Edited text'):
                result = handler.edit_current()

            assert result is True
            assert tm.tasks[0]['text'] == 'Edited text'

    def test_edit_current_empty_text_rejected(self):
        """Test editing current with empty text is rejected"""
        with tempfile.TemporaryDirectory() as tmpdir:
            tm = TaskManager(directory=Path(tmpdir))
            handler = CommandHandler(tm)

            # Add task and set as current
            tm.add_task("Original text")
            task_id = tm.tasks[0]['id']
            tm.set_current(task_id)

            # Mock input_with_prefill to return empty text
            with patch('jot.commands._core_mixin.input_with_prefill', return_value='   '):
                result = handler.edit_current()

            assert result is True
            assert tm.tasks[0]['text'] == 'Original text'  # Unchanged

    def test_edit_task_by_id(self):
        """Test editing task by ID"""
        with tempfile.TemporaryDirectory() as tmpdir:
            tm = TaskManager(directory=Path(tmpdir))
            handler = CommandHandler(tm)

            # Add task
            tm.add_task("Original text")
            task_id = tm.tasks[0]['id']

            # Mock inputs: ID selection, then new text
            with patch('builtins.input', return_value=str(task_id)):
                with patch('jot.commands._core_mixin.input_with_prefill', return_value='Edited via ID'):
                    result = handler.edit_task()

            assert result is True
            assert tm.tasks[0]['text'] == 'Edited via ID'


class TestCommandHandlerDayAssignment:
    """Test day of week assignment functionality"""

    def test_assign_day_no_task(self):
        """Test assigning day when no current task"""
        with tempfile.TemporaryDirectory() as tmpdir:
            tm = TaskManager(directory=Path(tmpdir))
            handler = CommandHandler(tm)

            with patch('builtins.input', return_value='1'):
                result = handler.assign_day()

            assert result is True

    # TODO: assign_day tests require mocking termios which is complex
    # These tests are skipped for now - manual testing confirms functionality
    #
    # def test_assign_day_to_task(self):
    #     """Test assigning day to current task"""
    #     ...
    #
    # def test_clear_day_assignment(self):
    #     """Test clearing day assignment"""
    #     ...


class TestSuggestTask:
    """Test AI task suggestion feature (Shift+4)"""

    def test_build_suggestion_prompt_includes_tasks(self):
        """Verify prompt contains task text, priorities, labels"""
        with tempfile.TemporaryDirectory() as tmpdir:
            tm = TaskManager(directory=Path(tmpdir))
            handler = CommandHandler(tm)

            tasks = [
                {'id': 1, 'text': 'Fix login bug', 'priority': 'high',
                 'labels': ['bug'], 'effort': 3, 'status': 'todo',
                 'day': 'Monday', 'notes': 'Affects all users'},
                {'id': 2, 'text': 'Add dark mode', 'priority': 'low',
                 'labels': ['feature'], 'effort': 5, 'status': 'todo',
                 'day': None, 'notes': ''},
            ]
            archived = [
                {'id': 3, 'text': 'Setup CI', 'labels': ['devops'],
                 'priority': 'medium'},
            ]

            prompt = handler._build_suggestion_prompt(tasks, archived)

            assert 'Fix login bug' in prompt
            assert 'Add dark mode' in prompt
            assert 'Setup CI' in prompt
            assert 'high' in prompt
            assert 'bug' in prompt
            assert 'Active tasks' in prompt
            assert 'Recently completed' in prompt

    def test_build_suggestion_prompt_empty(self):
        """Verify handles no tasks gracefully"""
        with tempfile.TemporaryDirectory() as tmpdir:
            tm = TaskManager(directory=Path(tmpdir))
            handler = CommandHandler(tm)

            prompt = handler._build_suggestion_prompt([], [])

            assert 'Active tasks' in prompt
            assert 'Recently completed' not in prompt

    @patch('builtins.input', return_value='y')
    def test_present_suggestion_accept(self, mock_input):
        """Mock input 'y', verify add_task() called with correct args"""
        with tempfile.TemporaryDirectory() as tmpdir:
            tm = TaskManager(directory=Path(tmpdir))
            handler = CommandHandler(tm)

            suggestion = {
                'text': 'Write API docs',
                'priority': 'medium',
                'labels': ['docs'],
                'effort': 2,
                'reasoning': 'No docs exist yet',
            }

            handler._present_suggestion(suggestion)

            assert len(tm.tasks) == 1
            assert tm.tasks[0]['text'] == 'Write API docs'
            assert tm.tasks[0]['priority'] == 'medium'
            assert 'docs' in tm.tasks[0].get('labels', [])

    @patch('builtins.input', return_value='n')
    def test_present_suggestion_reject(self, mock_input):
        """Mock input 'n', verify no task added"""
        with tempfile.TemporaryDirectory() as tmpdir:
            tm = TaskManager(directory=Path(tmpdir))
            handler = CommandHandler(tm)

            suggestion = {
                'text': 'Write API docs',
                'priority': 'medium',
                'labels': ['docs'],
                'effort': 2,
                'reasoning': 'No docs exist yet',
            }

            handler._present_suggestion(suggestion)

            assert len(tm.tasks) == 0

    @patch('builtins.input', return_value='')
    def test_suggest_task_no_tasks(self, mock_input):
        """Verify early return message when no tasks exist"""
        with tempfile.TemporaryDirectory() as tmpdir:
            tm = TaskManager(directory=Path(tmpdir))
            handler = CommandHandler(tm)

            result = handler.suggest_task()

            assert result is True
            assert len(tm.tasks) == 0

    @patch('subprocess.run')
    def test_call_claude_for_suggestion_parse(self, mock_run):
        """Mock subprocess with valid JSON, verify parsing"""
        import json as json_mod

        with tempfile.TemporaryDirectory() as tmpdir:
            tm = TaskManager(directory=Path(tmpdir))
            handler = CommandHandler(tm)

            # Mock version check
            version_result = type('Result', (), {
                'returncode': 0, 'stdout': 'claude 1.0', 'stderr': ''
            })()

            # Mock Claude response with nested JSON
            inner_json = json_mod.dumps({
                'text': 'Add unit tests',
                'priority': 'high',
                'labels': ['testing'],
                'effort': 3,
                'reasoning': 'Low test coverage',
            })
            outer_json = json_mod.dumps({'result': inner_json})
            claude_result = type('Result', (), {
                'returncode': 0, 'stdout': outer_json, 'stderr': ''
            })()

            mock_run.side_effect = [version_result, claude_result]

            suggestion = handler._call_claude_for_suggestion("test prompt")

            assert suggestion is not None
            assert suggestion['text'] == 'Add unit tests'
            assert suggestion['priority'] == 'high'
            assert 'testing' in suggestion['labels']


if __name__ == '__main__':
    import pytest
    import sys

    sys.exit(pytest.main([__file__, '-v']))
