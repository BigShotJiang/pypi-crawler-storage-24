"""Tests for fuzzy search: matching algorithm and highlight rendering."""

from jot.utils.text_utils import fuzzy_match


class TestFuzzyMatchBasic:
    """Core matching behaviour."""

    def test_empty_query_matches_everything(self):
        assert fuzzy_match("", "anything") == (True, 0, [])

    def test_exact_match(self):
        is_match, score, positions = fuzzy_match("hello", "hello")
        assert is_match is True
        assert positions == [0, 1, 2, 3, 4]

    def test_no_match(self):
        is_match, score, positions = fuzzy_match("xyz", "hello")
        assert is_match is False
        assert positions == []

    def test_case_insensitive(self):
        is_match, _, _ = fuzzy_match("HELLO", "hello world")
        assert is_match is True

    def test_subsequence_match(self):
        is_match, _, positions = fuzzy_match("hlo", "hello")
        assert is_match is True
        assert len(positions) == 3

    def test_query_longer_than_text(self):
        is_match, _, _ = fuzzy_match("toolong", "short")
        assert is_match is False

    def test_single_char(self):
        is_match, _, positions = fuzzy_match("f", "foo")
        assert is_match is True
        assert positions == [0]

    def test_single_char_not_found(self):
        is_match, _, _ = fuzzy_match("z", "hello")
        assert is_match is False


class TestFuzzyMatchScoringQuality:
    """The multi-start algorithm should prefer contiguous matches."""

    def test_contiguous_over_greedy(self):
        """'fuzzy' in 'fix fuzzy search' should match the contiguous
        word at [4,5,6,7,8], not greedy [0,5,6,7,8]."""
        is_match, score, positions = fuzzy_match(
            "fuzzy", "fix fuzzy search")
        assert is_match is True
        assert positions == [4, 5, 6, 7, 8]

    def test_word_boundary_preferred(self):
        """'test' in 'attest testing' should prefer 'testing' at
        the word boundary (pos 7) over mid-word 'test' in 'attest'."""
        is_match, _, positions = fuzzy_match("test", "attest testing")
        assert is_match is True
        assert positions[0] == 7

    def test_earlier_contiguous_wins(self):
        """When two contiguous matches exist, earlier one wins
        due to start bonus."""
        is_match, _, positions = fuzzy_match("ab", "ab xx ab")
        assert is_match is True
        assert positions == [0, 1]

    def test_start_bonus(self):
        """Match at position 0 should outscore identical match deeper."""
        _, score_start, _ = fuzzy_match("fix", "fix fuzzy search")
        _, score_mid, _ = fuzzy_match("fix", "please fix this")
        assert score_start > score_mid

    def test_contiguous_outscores_scattered(self):
        _, score_contig, _ = fuzzy_match("test", "test the feature")
        _, score_scatter, _ = fuzzy_match(
            "test", "take extra steps today")
        assert score_contig > score_scatter

    def test_case_match_bonus(self):
        """Exact case match should score higher than wrong case."""
        _, score_exact, _ = fuzzy_match("Fix", "Fix it")
        _, score_wrong, _ = fuzzy_match("fix", "Fix it")
        assert score_exact > score_wrong


class TestFuzzyMatchEdgeCases:
    """Boundary conditions and special inputs."""

    def test_repeated_chars_in_query(self):
        is_match, _, positions = fuzzy_match("oo", "foobar")
        assert is_match is True
        assert positions == [1, 2]

    def test_special_characters(self):
        is_match, _, _ = fuzzy_match("a-b", "a-b-c")
        assert is_match is True

    def test_query_equals_text(self):
        is_match, _, positions = fuzzy_match("abc", "abc")
        assert is_match is True
        assert positions == [0, 1, 2]

    def test_spaces_in_query(self):
        is_match, _, _ = fuzzy_match("a b", "a big bat")
        assert is_match is True

    def test_all_same_char(self):
        is_match, _, positions = fuzzy_match("aaa", "aaaaa")
        assert is_match is True
        assert positions == [0, 1, 2]

    def test_match_at_end_of_text(self):
        is_match, _, positions = fuzzy_match("end", "the end")
        assert is_match is True
        assert positions == [4, 5, 6]


class TestHighlightText:
    """Test the _highlight_text rendering helper."""

    def test_no_positions_returns_original(self):
        from jot.ui.display_tasks import _highlight_text
        assert _highlight_text("hello", []) == "hello"

    def test_positions_include_reverse(self):
        from jot.ui.display_tasks import _highlight_text
        from jot.ui.styles import REVERSE, RESET
        result = _highlight_text("abc", [1])
        assert REVERSE in result
        assert RESET in result
        # The 'b' at position 1 should be highlighted
        assert "b" in result

    def test_consecutive_positions_single_span(self):
        from jot.ui.display_tasks import _highlight_text
        from jot.ui.styles import REVERSE, RESET
        result = _highlight_text("abcde", [1, 2, 3])
        # Should be: "a" + REVERSE + "bcd" + RESET + "e"
        assert result.count(REVERSE) == 1
        assert result.count(RESET) == 1

    def test_base_fmt_restored_after_highlight(self):
        from jot.ui.display_tasks import _highlight_text
        from jot.ui.styles import REVERSE, RESET, BOLD, CYAN
        base = CYAN + BOLD
        result = _highlight_text("abc", [1], base_fmt=base)
        # After the highlight span, base_fmt should be restored
        assert (RESET + base) in result
