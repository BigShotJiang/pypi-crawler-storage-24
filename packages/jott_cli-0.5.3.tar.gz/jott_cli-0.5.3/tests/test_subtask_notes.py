"""Tests for checklist nested text → subtask notes (jot #405)."""

import json
import tempfile
from io import StringIO
from pathlib import Path

import pytest

from jot import TaskManager
from jot.core._subtask_mixin import _parse_checklist_with_notes
from jot.ui.display_tasks import (
    _build_subtask_info, _build_task_suffixes, _render_task_line,
)
from jot.ui.styles import DIM, YELLOW


# ---------------------------------------------------------------------------
# Unit tests for the parser helper
# ---------------------------------------------------------------------------

class TestParseChecklistWithNotes:
    """Test _parse_checklist_with_notes() parser."""

    def test_basic_checklist_no_nested(self):
        notes = "- [ ] item one\n- [X] item two"
        items = _parse_checklist_with_notes(notes)
        assert items == [
            ('item one', False, ''),
            ('item two', True, ''),
        ]

    def test_single_item_with_nested_text(self):
        notes = "- [ ] Research API options\n  Look into REST vs GraphQL\n  Check rate limits"
        items = _parse_checklist_with_notes(notes)
        assert len(items) == 1
        assert items[0][0] == 'Research API options'
        assert items[0][1] is False
        assert items[0][2] == 'Look into REST vs GraphQL\nCheck rate limits'

    def test_mixed_items_with_and_without_nested(self):
        notes = (
            "- [ ] Research API options\n"
            "  Look into REST vs GraphQL\n"
            "  Check rate limits\n"
            "- [ ] Write implementation plan\n"
            "- [X] Set up dev environment\n"
            "  Used docker-compose"
        )
        items = _parse_checklist_with_notes(notes)
        assert len(items) == 3

        assert items[0] == ('Research API options', False,
                            'Look into REST vs GraphQL\nCheck rate limits')
        assert items[1] == ('Write implementation plan', False, '')
        assert items[2] == ('Set up dev environment', True,
                            'Used docker-compose')

    def test_nested_indentation_stripped(self):
        notes = "- [ ] task\n    line one\n    line two"
        items = _parse_checklist_with_notes(notes)
        assert items[0][2] == 'line one\nline two'

    def test_whitespace_only_nested_lines_become_blank(self):
        notes = "- [ ] task\n  line one\n  \n  line two"
        items = _parse_checklist_with_notes(notes)
        assert items[0][2] == 'line one\n\nline two'

    def test_empty_notes(self):
        assert _parse_checklist_with_notes('') == []

    def test_no_checklist_items(self):
        assert _parse_checklist_with_notes('just some text\nno checklist') == []

    def test_trailing_whitespace_stripped(self):
        notes = "- [ ] task\n  nested text   \n  "
        items = _parse_checklist_with_notes(notes)
        assert items[0][2] == 'nested text'

    def test_leading_blank_nested_lines_dropped(self):
        notes = "- [ ] task\n\n  actual content"
        items = _parse_checklist_with_notes(notes)
        assert items[0][2] == 'actual content'


# ---------------------------------------------------------------------------
# Integration tests using TaskManager
# ---------------------------------------------------------------------------

def _make_tm(tmpdir):
    """Create a TaskManager in a temporary directory."""
    jot_file = tmpdir / '.jot.json'
    jot_file.write_text(json.dumps({'tasks': [], 'archived': []}))
    ids_file = tmpdir / '.jot.ids.json'
    ids_file.write_text(json.dumps({'next_id': 1, 'allocated': []}))
    return TaskManager(directory=tmpdir)


class TestSubtaskNotesIntegration:
    """Integration: sync_subtasks_from_notes sets subtask notes."""

    def test_nested_text_becomes_subtask_notes(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = Path(tmpdir)
            tm = _make_tm(tmpdir)

            tm.add_task('Parent')
            pid = tm.tasks[0]['id']

            tm.set_task_notes(pid,
                              '- [ ] Research API\n  REST vs GraphQL\n  Check limits')
            tm.sync_subtasks_from_notes(pid)

            subs = [t for t in tm.tasks
                    if f'parent:{pid}' in t.get('labels', [])]
            assert len(subs) == 1
            assert subs[0]['text'] == 'Research API'
            assert subs[0]['notes'] == 'REST vs GraphQL\nCheck limits'

    def test_item_without_nested_text_has_empty_notes(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = Path(tmpdir)
            tm = _make_tm(tmpdir)

            tm.add_task('Parent')
            pid = tm.tasks[0]['id']

            tm.set_task_notes(pid, '- [ ] Simple task')
            tm.sync_subtasks_from_notes(pid)

            subs = [t for t in tm.tasks
                    if f'parent:{pid}' in t.get('labels', [])]
            assert subs[0]['notes'] == ''

    def test_multiple_items_each_get_own_notes(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = Path(tmpdir)
            tm = _make_tm(tmpdir)

            tm.add_task('Parent')
            pid = tm.tasks[0]['id']

            tm.set_task_notes(pid, (
                '- [ ] Task A\n'
                '  Note for A\n'
                '- [ ] Task B\n'
                '  Note for B\n'
                '- [ ] Task C'
            ))
            tm.sync_subtasks_from_notes(pid)

            subs = {t['text']: t for t in tm.tasks
                    if f'parent:{pid}' in t.get('labels', [])}
            assert subs['Task A']['notes'] == 'Note for A'
            assert subs['Task B']['notes'] == 'Note for B'
            assert subs['Task C']['notes'] == ''

    def test_existing_subtask_notes_updated(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = Path(tmpdir)
            tm = _make_tm(tmpdir)

            tm.add_task('Parent')
            pid = tm.tasks[0]['id']

            # First sync — no nested text
            tm.set_task_notes(pid, '- [ ] Research API')
            tm.sync_subtasks_from_notes(pid)

            subs = [t for t in tm.tasks
                    if f'parent:{pid}' in t.get('labels', [])]
            assert subs[0]['notes'] == ''

            # Second sync — add nested text
            tm.set_task_notes(pid, '- [ ] Research API\n  Now with notes')
            r = tm.sync_subtasks_from_notes(pid)

            assert r['updated'] == 1
            assert r['created'] == 0

            subs = [t for t in tm.tasks
                    if f'parent:{pid}' in t.get('labels', [])]
            assert subs[0]['notes'] == 'Now with notes'

    def test_done_item_with_nested_notes_skipped(self):
        """Checked items should not create new subtasks (#578)."""
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = Path(tmpdir)
            tm = _make_tm(tmpdir)

            tm.add_task('Parent')
            pid = tm.tasks[0]['id']

            tm.set_task_notes(pid,
                              '- [X] Set up dev env\n  Used docker-compose')
            r = tm.sync_subtasks_from_notes(pid)

            subs = [t for t in tm.tasks
                    if f'parent:{pid}' in t.get('labels', [])]
            assert len(subs) == 0
            assert r['created'] == 0

    def test_full_example_from_spec(self):
        """The exact example from the feature spec (checked items skipped, #578)."""
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = Path(tmpdir)
            tm = _make_tm(tmpdir)

            tm.add_task('Parent')
            pid = tm.tasks[0]['id']

            tm.set_task_notes(pid, (
                '- [ ] Research API options\n'
                '  Look into REST vs GraphQL\n'
                '  Check rate limits\n'
                '- [ ] Write implementation plan\n'
                '- [X] Set up dev environment\n'
                '  Used docker-compose'
            ))
            r = tm.sync_subtasks_from_notes(pid)
            assert r['created'] == 2

            subs = {t['text']: t for t in tm.tasks
                    if f'parent:{pid}' in t.get('labels', [])}

            assert subs['Research API options']['notes'] == \
                'Look into REST vs GraphQL\nCheck rate limits'
            assert subs['Write implementation plan']['notes'] == ''
            assert 'Set up dev environment' not in subs

    def test_existing_subtask_notes_and_status_updated(self):
        """Both status and notes change in a single re-sync."""
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = Path(tmpdir)
            tm = _make_tm(tmpdir)

            tm.add_task('Parent')
            pid = tm.tasks[0]['id']

            tm.set_task_notes(pid, '- [ ] task one\n  old notes')
            tm.sync_subtasks_from_notes(pid)

            # Change status and notes
            tm.set_task_notes(pid, '- [X] task one\n  new notes')
            r = tm.sync_subtasks_from_notes(pid)

            subs = [t for t in tm.tasks
                    if f'parent:{pid}' in t.get('labels', [])]
            assert subs[0]['status'] == 'done'
            assert subs[0]['notes'] == 'new notes'
            assert r['updated'] >= 1

    def test_checked_item_does_not_create_new_task(self):
        """Already-checked checklist items should NOT create new subtasks (#578)."""
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = Path(tmpdir)
            tm = _make_tm(tmpdir)

            tm.add_task('Parent')
            pid = tm.tasks[0]['id']

            # Notes with only checked items — should not create any subtasks
            tm.set_task_notes(pid, '- [x] Already done\n- [X] Also done')
            r = tm.sync_subtasks_from_notes(pid)

            subs = [t for t in tm.tasks
                    if f'parent:{pid}' in t.get('labels', [])]
            assert len(subs) == 0
            assert r['created'] == 0

    def test_mixed_checked_unchecked_only_creates_unchecked(self):
        """Only unchecked items create new subtasks; checked ones are skipped (#578)."""
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = Path(tmpdir)
            tm = _make_tm(tmpdir)

            tm.add_task('Parent')
            pid = tm.tasks[0]['id']

            tm.set_task_notes(pid, (
                '- [ ] Todo item\n'
                '- [x] Done item\n'
                '- [ ] Another todo'
            ))
            r = tm.sync_subtasks_from_notes(pid)

            subs = [t for t in tm.tasks
                    if f'parent:{pid}' in t.get('labels', [])]
            assert len(subs) == 2
            assert r['created'] == 2
            texts = {s['text'] for s in subs}
            assert texts == {'Todo item', 'Another todo'}

    def test_existing_subtask_checked_still_updates(self):
        """An unchecked item synced first, then checked, should update status (#578)."""
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = Path(tmpdir)
            tm = _make_tm(tmpdir)

            tm.add_task('Parent')
            pid = tm.tasks[0]['id']

            # First sync — unchecked, creates subtask
            tm.set_task_notes(pid, '- [ ] Build feature')
            tm.sync_subtasks_from_notes(pid)

            subs = [t for t in tm.tasks
                    if f'parent:{pid}' in t.get('labels', [])]
            assert len(subs) == 1
            assert subs[0]['status'] == 'todo'

            # Second sync — now checked, should update (not create)
            tm.set_task_notes(pid, '- [x] Build feature')
            r = tm.sync_subtasks_from_notes(pid)

            subs = [t for t in tm.tasks
                    if f'parent:{pid}' in t.get('labels', [])]
            assert len(subs) == 1
            assert subs[0]['status'] == 'done'
            assert r['updated'] == 1
            assert r['created'] == 0


# ---------------------------------------------------------------------------
# Tests for assign_parent label manipulation (#573)
# ---------------------------------------------------------------------------

class TestAssignParent:
    """Test parent label assignment via direct TaskManager manipulation.

    These mirror the label logic in MetadataMixin.assign_parent() but
    test at the data layer — no UI mocking needed.
    """

    def test_assign_parent_adds_label(self):
        """Assigning a parent adds a parent:{id} label."""
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = Path(tmpdir)
            tm = _make_tm(tmpdir)

            tm.add_task('Parent task')
            tm.add_task('Child task')
            parent_id = tm.tasks[0]['id']
            child = tm.tasks[1]

            # Simulate what assign_parent does: add parent label
            child['labels'] = [f'parent:{parent_id}']
            tm._save_tasks()

            # Reload and verify
            tm._load_tasks()
            child = [t for t in tm.tasks if t['text'] == 'Child task'][0]
            assert f'parent:{parent_id}' in child['labels']

    def test_assign_parent_replaces_existing(self):
        """Changing parent replaces the old parent:{id} label."""
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = Path(tmpdir)
            tm = _make_tm(tmpdir)

            tm.add_task('Old parent')
            tm.add_task('New parent')
            tm.add_task('Child task')
            old_pid = tm.tasks[0]['id']
            new_pid = tm.tasks[1]['id']
            child = tm.tasks[2]

            # Start with old parent
            child['labels'] = [f'parent:{old_pid}', 'other-label']
            tm._save_tasks()

            # Re-assign: strip old parent, add new
            new_labels = [l for l in child['labels']
                          if not l.startswith('parent:')]
            new_labels.append(f'parent:{new_pid}')
            child['labels'] = new_labels
            tm._save_tasks()

            tm._load_tasks()
            child = [t for t in tm.tasks if t['text'] == 'Child task'][0]
            assert f'parent:{new_pid}' in child['labels']
            assert f'parent:{old_pid}' not in child['labels']
            assert 'other-label' in child['labels']

    def test_assign_parent_clear_removes_label(self):
        """Clearing parent removes the parent:{id} label."""
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = Path(tmpdir)
            tm = _make_tm(tmpdir)

            tm.add_task('Parent task')
            tm.add_task('Child task')
            parent_id = tm.tasks[0]['id']
            child = tm.tasks[1]

            child['labels'] = [f'parent:{parent_id}', 'keep-me']
            tm._save_tasks()

            # Clear: strip parent labels
            child['labels'] = [l for l in child['labels']
                               if not l.startswith('parent:')]
            tm._save_tasks()

            tm._load_tasks()
            child = [t for t in tm.tasks if t['text'] == 'Child task'][0]
            assert not any(l.startswith('parent:') for l in child['labels'])
            assert 'keep-me' in child['labels']

    def test_assign_parent_self_excluded(self):
        """Current task should not appear in candidate list."""
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = Path(tmpdir)
            tm = _make_tm(tmpdir)

            tm.add_task('Task A')
            tm.add_task('Task B')
            tm.add_task('Task C')

            current_id = tm.tasks[1]['id']
            # Build candidate list the same way assign_parent does
            candidates = [
                t for t in tm.get_tasks()
                if t['id'] != current_id and t.get('status') != 'done'
            ]
            candidate_ids = {t['id'] for t in candidates}
            assert current_id not in candidate_ids
            assert len(candidates) == 2


# ---------------------------------------------------------------------------
# Tests for subtask display indicators (#visual-distinction)
# ---------------------------------------------------------------------------

class TestSubtaskDisplay:
    """Test visual indicators for parent/subtask relationships."""

    def test_build_subtask_info_basic(self):
        """_build_subtask_info computes descendant counts and depths."""
        tasks = [
            {'id': 1, 'text': 'Parent', 'labels': []},
            {'id': 2, 'text': 'Child A', 'labels': ['parent:1']},
            {'id': 3, 'text': 'Child B', 'labels': ['parent:1']},
        ]
        desc_counts, depths = _build_subtask_info(tasks)
        assert desc_counts == {1: 2}
        assert depths == {2: 1, 3: 1}

    def test_build_subtask_info_no_parents(self):
        """Regular tasks produce empty dicts."""
        tasks = [
            {'id': 1, 'text': 'Task A', 'labels': []},
            {'id': 2, 'text': 'Task B', 'labels': ['bug']},
        ]
        desc_counts, depths = _build_subtask_info(tasks)
        assert desc_counts == {}
        assert depths == {}

    def test_build_subtask_info_recursive_depths(self):
        """Grandchildren get depth 2, great-grandchildren depth 3."""
        tasks = [
            {'id': 1, 'text': 'Root', 'labels': []},
            {'id': 2, 'text': 'Child', 'labels': ['parent:1']},
            {'id': 3, 'text': 'Grandchild', 'labels': ['parent:2']},
            {'id': 4, 'text': 'Great-grandchild', 'labels': ['parent:3']},
        ]
        desc_counts, depths = _build_subtask_info(tasks)
        assert depths == {2: 1, 3: 2, 4: 3}

    def test_build_subtask_info_recursive_counts(self):
        """Descendant counts include all nested children."""
        tasks = [
            {'id': 1, 'text': 'Root', 'labels': []},
            {'id': 2, 'text': 'Child', 'labels': ['parent:1']},
            {'id': 3, 'text': 'Grandchild', 'labels': ['parent:2']},
            {'id': 4, 'text': 'Great-grandchild', 'labels': ['parent:3']},
        ]
        desc_counts, depths = _build_subtask_info(tasks)
        # Root has 3 total descendants (child + grandchild + great-grandchild)
        assert desc_counts[1] == 3
        # Child has 2 descendants (grandchild + great-grandchild)
        assert desc_counts[2] == 2
        # Grandchild has 1 descendant
        assert desc_counts[3] == 1
        # Great-grandchild has none
        assert 4 not in desc_counts

    def test_build_subtask_info_cycle_guard(self):
        """Circular parent refs don't cause infinite loop."""
        tasks = [
            {'id': 1, 'text': 'A', 'labels': ['parent:2']},
            {'id': 2, 'text': 'B', 'labels': ['parent:1']},
        ]
        desc_counts, depths = _build_subtask_info(tasks)
        # Both should resolve without hanging; depth bounded
        assert depths[1] <= 11
        assert depths[2] <= 11

    def test_subtask_shows_arrow_prefix(self, capsys):
        """Task with parent label renders ↳ prefix."""
        task = {'id': 2, 'text': 'Child task', 'labels': ['parent:1'],
                'done': False, 'status': 'todo'}
        _render_task_line(
            task, 'quick_add', set(), set(),
            False, None, child_count=0, depth=1)
        output = capsys.readouterr().out
        assert '\u21b3' in output

    def test_grandchild_shows_double_arrow(self, capsys):
        """Depth-2 subtask renders ↳↳ prefix."""
        task = {'id': 3, 'text': 'Grandchild', 'labels': ['parent:2'],
                'done': False, 'status': 'todo'}
        _render_task_line(
            task, 'quick_add', set(), set(),
            False, None, child_count=0, depth=2)
        output = capsys.readouterr().out
        assert '\u21b3\u21b3' in output

    def test_parent_shows_child_count_plural(self, capsys):
        """Parent task renders (2 subtasks) suffix."""
        task = {'id': 1, 'text': 'Parent task', 'labels': [],
                'done': False, 'status': 'todo'}
        _render_task_line(
            task, 'quick_add', set(), set(),
            False, None, child_count=2, depth=0)
        output = capsys.readouterr().out
        assert '(2 subtasks)' in output

    def test_parent_shows_singular(self, capsys):
        """Single child renders (1 subtask) suffix."""
        task = {'id': 1, 'text': 'Parent task', 'labels': [],
                'done': False, 'status': 'todo'}
        _render_task_line(
            task, 'quick_add', set(), set(),
            False, None, child_count=1, depth=0)
        output = capsys.readouterr().out
        assert '(1 subtask)' in output
        assert '(1 subtasks)' not in output

    def test_regular_task_no_indicators(self, capsys):
        """Task without parent/children has neither indicator."""
        task = {'id': 5, 'text': 'Regular task', 'labels': [],
                'done': False, 'status': 'todo'}
        _render_task_line(
            task, 'quick_add', set(), set(),
            False, None, child_count=0, depth=0)
        output = capsys.readouterr().out
        assert '\u21b3' not in output
        assert 'subtask' not in output


# ---------------------------------------------------------------------------
# Orphan prevention tests (#595)
# ---------------------------------------------------------------------------

class TestOrphanPrevention:
    """Deleting/moving parents must not leave dangling parent: labels."""

    def test_delete_parent_unlinks_children(self):
        """Archiving a parent strips parent:{id} from all children."""
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = Path(tmpdir)
            tm = _make_tm(tmpdir)

            tm.add_task('Parent')
            tm.add_task('Child A')
            tm.add_task('Child B')
            pid = tm.tasks[0]['id']
            tm.tasks[1]['labels'] = [f'parent:{pid}']
            tm.tasks[2]['labels'] = [f'parent:{pid}']
            tm._save_tasks()

            tm.remove_task(pid)

            for task in tm.tasks:
                assert not any(l.startswith('parent:') for l in task.get('labels', []))

    def test_delete_parent_preserves_other_labels(self):
        """Non-parent labels survive parent deletion."""
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = Path(tmpdir)
            tm = _make_tm(tmpdir)

            tm.add_task('Parent')
            tm.add_task('Child')
            pid = tm.tasks[0]['id']
            tm.tasks[1]['labels'] = [f'parent:{pid}', 'bug', 'urgent']
            tm._save_tasks()

            tm.remove_task(pid)

            child = [t for t in tm.tasks if t['text'] == 'Child'][0]
            assert 'bug' in child['labels']
            assert 'urgent' in child['labels']
            assert f'parent:{pid}' not in child['labels']

    def test_delete_leaf_no_side_effects(self):
        """Deleting a child doesn't affect its siblings."""
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = Path(tmpdir)
            tm = _make_tm(tmpdir)

            tm.add_task('Parent')
            tm.add_task('Child A')
            tm.add_task('Child B')
            pid = tm.tasks[0]['id']
            child_a_id = tm.tasks[1]['id']
            tm.tasks[1]['labels'] = [f'parent:{pid}']
            tm.tasks[2]['labels'] = [f'parent:{pid}']
            tm._save_tasks()

            tm.remove_task(child_a_id)

            sibling = [t for t in tm.tasks if t['text'] == 'Child B'][0]
            assert f'parent:{pid}' in sibling['labels']

    def test_permanent_delete_unlinks_children(self):
        """delete_task_permanently also strips parent labels from children."""
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = Path(tmpdir)
            tm = _make_tm(tmpdir)

            tm.add_task('Parent')
            tm.add_task('Child')
            pid = tm.tasks[0]['id']
            tm.tasks[1]['labels'] = [f'parent:{pid}']
            tm._save_tasks()

            tm.delete_task_permanently(pid)

            child = [t for t in tm.tasks if t['text'] == 'Child'][0]
            assert not any(l.startswith('parent:') for l in child.get('labels', []))

    def test_move_strips_parent_label(self):
        """Moving a child to another project strips its parent: label."""
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = Path(tmpdir)
            source = tmpdir / 'source'
            target = tmpdir / 'target'
            source.mkdir()
            target.mkdir()

            tm_src = _make_tm(source)
            tm_src.add_task('Parent')
            tm_src.add_task('Child')
            pid = tm_src.tasks[0]['id']
            tm_src.tasks[1]['labels'] = [f'parent:{pid}', 'keep-me']
            tm_src._save_tasks()

            child = tm_src.tasks[1]

            # Simulate what TransferMixin does: add to target with filtered labels
            tm_tgt = _make_tm(target)
            tm_tgt.add_task(
                child['text'],
                labels=[l for l in child.get('labels', [])
                        if not l.startswith('parent:')],
            )
            tm_tgt._save_tasks()

            new_task = tm_tgt.tasks[0]
            assert not any(l.startswith('parent:') for l in new_task.get('labels', []))

    def test_move_preserves_other_labels(self):
        """Non-parent labels survive cross-project move."""
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = Path(tmpdir)
            source = tmpdir / 'source'
            target = tmpdir / 'target'
            source.mkdir()
            target.mkdir()

            tm_src = _make_tm(source)
            tm_src.add_task('Task')
            tm_src.tasks[0]['labels'] = ['parent:99', 'feature', 'v2']
            tm_src._save_tasks()

            task = tm_src.tasks[0]

            tm_tgt = _make_tm(target)
            tm_tgt.add_task(
                task['text'],
                labels=[l for l in task.get('labels', [])
                        if not l.startswith('parent:')],
            )
            tm_tgt._save_tasks()

            new_task = tm_tgt.tasks[0]
            assert 'feature' in new_task['labels']
            assert 'v2' in new_task['labels']
            assert 'parent:99' not in new_task['labels']


# ---------------------------------------------------------------------------
# Tests for collapse/expand subtasks (#collapse)
# ---------------------------------------------------------------------------

class TestCollapseExpand:
    """Test collapse/expand filtering and visual indicators."""

    def _make_app_with_tasks(self, tasks):
        """Build a minimal App-like object with _filter_collapsed."""
        from jot.app import App, AppState

        class FakeApp:
            def __init__(self):
                self.state = AppState()

        app = FakeApp()
        # Bind the method from App
        app._filter_collapsed = App._filter_collapsed.__get__(app)
        return app

    def test_filter_collapsed_hides_children(self):
        """Collapsed parent's children are excluded from filtered list."""
        tasks = [
            {'id': 1, 'text': 'Parent', 'labels': []},
            {'id': 2, 'text': 'Child A', 'labels': ['parent:1']},
            {'id': 3, 'text': 'Child B', 'labels': ['parent:1']},
            {'id': 4, 'text': 'Unrelated', 'labels': []},
        ]
        app = self._make_app_with_tasks(tasks)
        app.state.collapsed_parents.add(1)
        result = app._filter_collapsed(tasks)
        result_ids = [t['id'] for t in result]
        assert 2 not in result_ids
        assert 3 not in result_ids

    def test_filter_collapsed_preserves_parent(self):
        """The collapsed parent itself remains visible."""
        tasks = [
            {'id': 1, 'text': 'Parent', 'labels': []},
            {'id': 2, 'text': 'Child', 'labels': ['parent:1']},
        ]
        app = self._make_app_with_tasks(tasks)
        app.state.collapsed_parents.add(1)
        result = app._filter_collapsed(tasks)
        result_ids = [t['id'] for t in result]
        assert 1 in result_ids

    def test_filter_collapsed_recursive(self):
        """Collapsing a grandparent hides all descendants."""
        tasks = [
            {'id': 1, 'text': 'Root', 'labels': []},
            {'id': 2, 'text': 'Child', 'labels': ['parent:1']},
            {'id': 3, 'text': 'Grandchild', 'labels': ['parent:2']},
            {'id': 4, 'text': 'Great-grandchild', 'labels': ['parent:3']},
        ]
        app = self._make_app_with_tasks(tasks)
        app.state.collapsed_parents.add(1)
        result = app._filter_collapsed(tasks)
        result_ids = [t['id'] for t in result]
        assert result_ids == [1]

    def test_filter_collapsed_no_effect_on_unrelated(self):
        """Other tasks are unaffected by collapse."""
        tasks = [
            {'id': 1, 'text': 'Parent', 'labels': []},
            {'id': 2, 'text': 'Child', 'labels': ['parent:1']},
            {'id': 5, 'text': 'Standalone A', 'labels': []},
            {'id': 6, 'text': 'Standalone B', 'labels': ['bug']},
        ]
        app = self._make_app_with_tasks(tasks)
        app.state.collapsed_parents.add(1)
        result = app._filter_collapsed(tasks)
        result_ids = [t['id'] for t in result]
        assert 5 in result_ids
        assert 6 in result_ids

    def test_toggle_collapse_parent_task(self):
        """Toggling on a parent adds/removes its ID from collapsed set."""
        from unittest.mock import MagicMock, patch
        from jot._dispatch_mixin import DispatchMixin

        class FakeDispatch:
            def __init__(self):
                from jot.app import AppState
                self.state = AppState()
                self.task_manager = MagicMock()

        app = FakeDispatch()
        app._toggle_collapse = (
            DispatchMixin._toggle_collapse.__get__(app))

        parent = {'id': 1, 'text': 'Parent', 'labels': []}
        child = {'id': 2, 'text': 'Child', 'labels': ['parent:1']}
        app.task_manager.get_current_task.return_value = parent
        app.task_manager.get_tasks.return_value = [parent, child]

        with patch('jot._dispatch_mixin.time'):
            app._toggle_collapse()

        assert 1 in app.state.collapsed_parents

        # Toggle again — removes
        with patch('jot._dispatch_mixin.time'):
            app._toggle_collapse()

        assert 1 not in app.state.collapsed_parents

    def test_toggle_collapse_child_task(self):
        """Toggling on a child collapses its parent."""
        from unittest.mock import MagicMock, patch
        from jot._dispatch_mixin import DispatchMixin

        class FakeDispatch:
            def __init__(self):
                from jot.app import AppState
                self.state = AppState()
                self.task_manager = MagicMock()

        app = FakeDispatch()
        app._toggle_collapse = (
            DispatchMixin._toggle_collapse.__get__(app))

        parent = {'id': 1, 'text': 'Parent', 'labels': []}
        child = {'id': 2, 'text': 'Child', 'labels': ['parent:1']}
        app.task_manager.get_current_task.return_value = child
        app.task_manager.get_tasks.return_value = [parent, child]

        with patch('jot._dispatch_mixin.time'):
            app._toggle_collapse()

        assert 1 in app.state.collapsed_parents

    def test_collapsed_indicator_shown(self, capsys):
        """Collapsed parent suffix shows ▶."""
        task = {'id': 1, 'text': 'Parent task', 'labels': [],
                'done': False, 'status': 'todo'}
        _render_task_line(
            task, 'quick_add', set(), set(),
            False, None, child_count=3, depth=0, collapsed=True)
        output = capsys.readouterr().out
        assert '\u25b6' in output
        assert '(3 subtasks)' in output

    def test_expanded_indicator_shown(self, capsys):
        """Expanded parent suffix shows ▼."""
        task = {'id': 1, 'text': 'Parent task', 'labels': [],
                'done': False, 'status': 'todo'}
        _render_task_line(
            task, 'quick_add', set(), set(),
            False, None, child_count=2, depth=0, collapsed=False)
        output = capsys.readouterr().out
        assert '\u25bc' in output
        assert '(2 subtasks)' in output

    def test_no_indicator_without_children(self, capsys):
        """Tasks without children show no collapse indicator."""
        task = {'id': 1, 'text': 'Regular', 'labels': [],
                'done': False, 'status': 'todo'}
        _render_task_line(
            task, 'quick_add', set(), set(),
            False, None, child_count=0, depth=0, collapsed=False)
        output = capsys.readouterr().out
        assert '\u25b6' not in output
        assert '\u25bc' not in output

    def test_build_suffixes_collapsed(self):
        """_build_task_suffixes returns ▶ in YELLOW when collapsed."""
        task = {'id': 1, 'text': 'P', 'labels': [],
                'done': False, 'status': 'todo'}
        _, _, subtask_suffix = _build_task_suffixes(
            task, child_count=2, collapsed=True)
        assert '\u25b6' in subtask_suffix
        assert '(2 subtasks)' in subtask_suffix
        assert YELLOW in subtask_suffix

    def test_build_suffixes_expanded(self):
        """_build_task_suffixes returns ▼ in DIM when expanded."""
        task = {'id': 1, 'text': 'P', 'labels': [],
                'done': False, 'status': 'todo'}
        _, _, subtask_suffix = _build_task_suffixes(
            task, child_count=1, collapsed=False)
        assert '\u25bc' in subtask_suffix
        assert '(1 subtask)' in subtask_suffix
        assert DIM in subtask_suffix

    def test_build_suffixes_collapsed_not_dim(self):
        """Collapsed suffix uses YELLOW, not DIM."""
        task = {'id': 1, 'text': 'P', 'labels': [],
                'done': False, 'status': 'todo'}
        _, _, subtask_suffix = _build_task_suffixes(
            task, child_count=3, collapsed=True)
        assert DIM not in subtask_suffix
