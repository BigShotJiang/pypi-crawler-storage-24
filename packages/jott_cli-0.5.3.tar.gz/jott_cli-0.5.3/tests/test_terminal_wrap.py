"""Tests for 80-column wrap and terminal width utilities (jot #420)."""

import os
import sys
from unittest.mock import patch

import pytest

from jot.ui.styles import strip_ansi, visible_len, get_terminal_width
from jot.ui.styles import BOLD, RESET, CYAN, GREEN, DIM, HIGHLIGHT_FMT
from jot.core.constants import MODE_QUICK_ADD

# Patch target: shutil.get_terminal_size returns os.terminal_size(columns, lines)
_MOCK_SIZE = lambda cols: patch(
    'shutil.get_terminal_size', return_value=os.terminal_size((cols, 24)))


# ---------------------------------------------------------------------------
# Unit tests for style utilities
# ---------------------------------------------------------------------------

class TestStripAnsi:
    """Test strip_ansi() removes ANSI escape codes."""

    def test_plain_text_unchanged(self):
        assert strip_ansi("hello world") == "hello world"

    def test_single_code_removed(self):
        assert strip_ansi("\033[1mhello\033[0m") == "hello"

    def test_multiple_codes_removed(self):
        text = f"{BOLD}{CYAN}hello{RESET} {GREEN}world{RESET}"
        assert strip_ansi(text) == "hello world"

    def test_empty_string(self):
        assert strip_ansi("") == ""

    def test_highlight_format_removed(self):
        text = f"{HIGHLIGHT_FMT}task text{RESET}"
        assert strip_ansi(text) == "task text"

    def test_dim_removed(self):
        text = f"{DIM}(x3){RESET}"
        assert strip_ansi(text) == "(x3)"


class TestVisibleLen:
    """Test visible_len() returns non-ANSI length."""

    def test_plain_text(self):
        assert visible_len("hello") == 5

    def test_ansi_text(self):
        text = f"{BOLD}{CYAN}hello{RESET}"
        assert visible_len(text) == 5

    def test_empty(self):
        assert visible_len("") == 0


class TestGetTerminalWidth:
    """Test get_terminal_width() with fallback."""

    def test_returns_integer(self):
        w = get_terminal_width()
        assert isinstance(w, int)
        assert w > 0

    def test_fallback_on_error(self):
        with patch('jot.ui.styles.shutil.get_terminal_size',
                   side_effect=OSError):
            assert get_terminal_width() == 80

    def test_respects_terminal_size(self):
        with _MOCK_SIZE(120):
            assert get_terminal_width() == 120


# ---------------------------------------------------------------------------
# Task line wrapping tests
# ---------------------------------------------------------------------------

def _make_task(text, task_id=1, current=False, done=False,
               priority='none', status='todo', highlight=False,
               notes='', day=None, tally=0, agent_task=False):
    """Create a minimal task dict for rendering tests."""
    return {
        'id': task_id, 'text': text, 'done': done,
        'current': current, 'day': day, 'tally': tally,
        'agent_task': agent_task, 'highlight': highlight,
        'priority': priority, 'status': status,
        'labels': [], 'notes': notes,
        'created_at': '2026-03-01T00:00:00+00:00',
        'updated_at': '2026-03-01T00:00:00+00:00',
    }


def _render(task, cols=80):
    """Render a task line at the given terminal width, return output."""
    from jot.ui.display_tasks import _render_task_line
    import io
    from contextlib import redirect_stdout

    buf = io.StringIO()
    with _MOCK_SIZE(cols):
        with redirect_stdout(buf):
            _render_task_line(task, MODE_QUICK_ADD, set(), set(), False)
    return buf.getvalue()


class TestTaskLineWrapping:
    """Test that long task text wraps to terminal width."""

    def test_short_task_single_line(self):
        """Short tasks render on one line."""
        output = _render(_make_task("short task"), cols=80)
        lines = output.strip().split('\n')
        assert len(lines) == 1
        assert "short task" in lines[0]

    def test_long_task_wraps(self):
        """Task text exceeding terminal width wraps to multiple lines."""
        long_text = "implement the full OAuth2 flow with refresh tokens " * 3
        output = _render(_make_task(long_text.strip()), cols=60)
        lines = output.strip().split('\n')
        assert len(lines) > 1, "Long text should wrap to multiple lines"

    def test_continuation_lines_indented(self):
        """Continuation lines should be indented to align with text."""
        long_text = "word " * 40
        output = _render(_make_task(long_text.strip()), cols=60)
        lines = output.strip().split('\n')
        if len(lines) > 1:
            # Continuation lines start with spaces (indentation)
            assert lines[1].startswith(' ')

    def test_current_task_wraps(self):
        """Current task with color/bold still wraps correctly."""
        output = _render(_make_task("x" * 120, current=True), cols=80)
        lines = output.strip().split('\n')
        assert len(lines) > 1

    def test_highlighted_task_wraps(self):
        """Highlighted task wraps correctly."""
        output = _render(_make_task("y" * 120, highlight=True), cols=80)
        lines = output.strip().split('\n')
        assert len(lines) > 1

    def test_wrap_preserves_all_text(self):
        """All words from original text appear in wrapped output."""
        words = ["alpha", "bravo", "charlie", "delta", "echo",
                 "foxtrot", "golf", "hotel", "india", "juliet"]
        long_text = " ".join(words)
        output = _render(_make_task(long_text), cols=40)
        plain = strip_ansi(output)
        for word in words:
            assert word in plain

    def test_narrow_terminal_floor(self):
        """Very narrow terminal doesn't crash — minimum width enforced."""
        output = _render(_make_task("some task text here"), cols=30)
        assert "some task text here" in strip_ansi(output)

    def test_exact_fit_no_wrap(self):
        """Task that easily fits terminal width doesn't wrap."""
        output = _render(_make_task("fit"), cols=200)
        lines = output.strip().split('\n')
        assert len(lines) == 1

    def test_agent_task_wraps(self):
        """Agent task (magenta/robot) wraps correctly."""
        output = _render(
            _make_task("z" * 100, agent_task=True), cols=80)
        lines = output.strip().split('\n')
        assert len(lines) > 1

    def test_no_trailing_whitespace_on_short(self):
        """Short tasks don't get extra whitespace padding."""
        output = _render(_make_task("quick"), cols=80)
        # Should not have excessive trailing spaces
        for line in output.strip().split('\n'):
            stripped = strip_ansi(line)
            assert not stripped.endswith('   ')


# ---------------------------------------------------------------------------
# Dynamic separator tests
# ---------------------------------------------------------------------------

class TestDynamicSeparators:
    """Test that separators use terminal width."""

    def test_display_tasks_separator(self, capsys):
        """Main task list uses terminal-width separator."""
        from jot.ui.display_tasks import display_tasks
        with _MOCK_SIZE(72):
            display_tasks([], input_buffer="")
        output = capsys.readouterr().out
        assert "-" * 72 in output

    def test_separator_not_hardcoded_50(self, capsys):
        """Separators are NOT hardcoded to 50 anymore."""
        from jot.ui.display_tasks import display_tasks
        with _MOCK_SIZE(90):
            display_tasks([], input_buffer="")
        output = capsys.readouterr().out
        assert "-" * 90 in output
        # Old hardcoded width should not appear as a full separator
        lines = output.split('\n')
        sep_lines = [l for l in lines if l.strip() and set(l.strip()) == {'-'}]
        for sep in sep_lines:
            assert len(sep) >= 90
