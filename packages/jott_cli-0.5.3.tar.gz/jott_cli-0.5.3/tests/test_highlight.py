#!/usr/bin/env python3
"""Tests for the task highlight feature."""

import tempfile
from pathlib import Path

import pytest

from jot import TaskManager
from jot.ui.display_tasks import _render_task_line
from jot.ui.styles import HIGHLIGHT_COLORS, HIGHLIGHT_DEFAULT, HIGHLIGHT_FMT, RESET


class TestSetHighlight:
    """Test TaskManager.set_highlight() method."""

    def test_set_highlight_color(self):
        """Set a named highlight color on the current task."""
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = Path(tmpdir)
            tm = TaskManager(storage_file='.jot.json', directory=tmpdir)
            tm.add_task("task 1")
            tm.set_current(tm.tasks[0]['id'])

            result = tm.set_highlight(color='magenta')
            assert result is True
            assert tm.tasks[0]['highlight'] == 'magenta'

    def test_clear_highlight(self):
        """Clearing highlight sets it to False."""
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = Path(tmpdir)
            tm = TaskManager(storage_file='.jot.json', directory=tmpdir)
            tm.add_task("task 1")
            tm.set_current(tm.tasks[0]['id'])

            tm.set_highlight(color='cyan')
            assert tm.tasks[0]['highlight'] == 'cyan'

            tm.set_highlight(color=None)
            assert tm.tasks[0]['highlight'] is False

    def test_set_highlight_no_current(self):
        """Returns False when no current task is set."""
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = Path(tmpdir)
            tm = TaskManager(storage_file='.jot.json', directory=tmpdir)
            tm.add_task("task 1")
            result = tm.set_highlight(color='gray')
            assert result is False

    def test_set_highlight_by_id(self):
        """Set highlight on a specific task by ID."""
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = Path(tmpdir)
            tm = TaskManager(storage_file='.jot.json', directory=tmpdir)
            tm.add_task("task 1")
            tm.add_task("task 2")
            task_2_id = tm.tasks[1]['id']

            result = tm.set_highlight(task_id=task_2_id, color='orange')
            assert result is True
            assert tm.tasks[1]['highlight'] == 'orange'
            assert tm.tasks[0].get('highlight', False) is False

    def test_set_highlight_invalid_id(self):
        """Returns False for a nonexistent task ID."""
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = Path(tmpdir)
            tm = TaskManager(storage_file='.jot.json', directory=tmpdir)
            tm.add_task("task 1")

            result = tm.set_highlight(task_id=9999, color='gray')
            assert result is False

    def test_multiple_highlights_different_colors(self):
        """Multiple tasks can have different highlight colors."""
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = Path(tmpdir)
            tm = TaskManager(storage_file='.jot.json', directory=tmpdir)
            tm.add_task("task 1")
            tm.add_task("task 2")
            tm.add_task("task 3")

            tm.set_highlight(task_id=tm.tasks[0]['id'], color='magenta')
            tm.set_highlight(task_id=tm.tasks[2]['id'], color='cyan')

            assert tm.tasks[0]['highlight'] == 'magenta'
            assert tm.tasks[1].get('highlight', False) is False
            assert tm.tasks[2]['highlight'] == 'cyan'

    def test_highlight_persists_save_load(self):
        """Highlight color survives a save/load round-trip."""
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = Path(tmpdir)
            tm1 = TaskManager(storage_file='.jot.json', directory=tmpdir)
            tm1.add_task("task 1")
            tm1.set_current(tm1.tasks[0]['id'])
            tm1.set_highlight(color='orange')
            assert tm1.tasks[0]['highlight'] == 'orange'

            tm2 = TaskManager(storage_file='.jot.json', directory=tmpdir)
            assert tm2.tasks[0]['highlight'] == 'orange'

    def test_new_task_default_highlight_false(self):
        """New tasks should have highlight=False by default."""
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = Path(tmpdir)
            tm = TaskManager(storage_file='.jot.json', directory=tmpdir)
            tm.add_task("task 1")
            assert tm.tasks[0].get('highlight', False) is False


class TestHighlightDisplay:
    """Test that highlighted tasks render with correct ANSI codes."""

    def test_named_color_display(self, capsys):
        """A task with a named highlight color uses the correct format."""
        task = {
            'id': 1, 'text': 'test task', 'done': False,
            'current': False, 'highlight': 'magenta',
            'priority': 'none', 'status': 'todo', 'day': None,
            'tally': 0, 'notes': '', 'agent_task': False,
        }
        _render_task_line(task, 'quick_add', set(), set(), False)
        captured = capsys.readouterr()
        assert HIGHLIGHT_COLORS['magenta'] in captured.out

    def test_legacy_boolean_true_uses_default(self, capsys):
        """Legacy highlight=True falls back to default color."""
        task = {
            'id': 1, 'text': 'test task', 'done': False,
            'current': False, 'highlight': True,
            'priority': 'none', 'status': 'todo', 'day': None,
            'tally': 0, 'notes': '', 'agent_task': False,
        }
        _render_task_line(task, 'quick_add', set(), set(), False)
        captured = capsys.readouterr()
        assert HIGHLIGHT_COLORS[HIGHLIGHT_DEFAULT] in captured.out

    def test_no_highlight_display(self, capsys):
        """A non-highlighted task has no highlight ANSI codes."""
        task = {
            'id': 1, 'text': 'test task', 'done': False,
            'current': False, 'highlight': False,
            'priority': 'none', 'status': 'todo', 'day': None,
            'tally': 0, 'notes': '', 'agent_task': False,
        }
        _render_task_line(task, 'quick_add', set(), set(), False)
        captured = capsys.readouterr()
        for fmt in HIGHLIGHT_COLORS.values():
            assert fmt not in captured.out

    def test_highlight_current_task(self, capsys):
        """A highlighted current task renders with highlight on ID."""
        task = {
            'id': 1, 'text': 'test task', 'done': False,
            'current': True, 'highlight': 'cyan',
            'priority': 'none', 'status': 'todo', 'day': None,
            'tally': 0, 'notes': '', 'agent_task': False,
        }
        _render_task_line(task, 'quick_add', set(), set(), False)
        captured = capsys.readouterr()
        assert HIGHLIGHT_COLORS['cyan'] in captured.out

    def test_unknown_color_falls_back_to_default(self, capsys):
        """An unrecognized color name falls back to default highlight."""
        task = {
            'id': 1, 'text': 'test task', 'done': False,
            'current': False, 'highlight': 'neon_pink',
            'priority': 'none', 'status': 'todo', 'day': None,
            'tally': 0, 'notes': '', 'agent_task': False,
        }
        _render_task_line(task, 'quick_add', set(), set(), False)
        captured = capsys.readouterr()
        assert HIGHLIGHT_COLORS[HIGHLIGHT_DEFAULT] in captured.out
