#!/usr/bin/env python3
"""
Test the today filter feature
"""

import sys
import tempfile
from pathlib import Path
from jot.core.task_manager import TaskManager
from jot.utils.date_utils import filter_today_tasks, get_today_day_name


def test_filter_today_tasks():
    """Test filtering tasks to show only today's tasks"""
    print("\n🔍 TEST: Filter today's tasks")

    # Get today's day name
    today = get_today_day_name()
    print(f"  Today is: {today}")

    # Create temporary directory for testing
    temp_dir = tempfile.mkdtemp()
    temp_path = Path(temp_dir)
    tm = TaskManager(directory=temp_path)

    # Get other days (not today)
    all_days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']
    other_days = [d for d in all_days if d != today]

    # Add tasks with different days (not today)
    tm.add_task(f"Task for {other_days[0]}")
    tm.tasks[0]['day'] = other_days[0]

    tm.add_task(f"Task for {other_days[1]}")
    tm.tasks[1]['day'] = other_days[1]

    tm.add_task(f"Task for {other_days[2]}")
    tm.tasks[2]['day'] = other_days[2]

    tm.add_task("Task for today")
    tm.tasks[3]['day'] = today  # Set to today

    tm.add_task("Another task for today")
    tm.tasks[4]['day'] = today  # Set to today

    tm.add_task("Task with no day")
    # No day assigned

    tm._save_tasks()

    # Get all tasks
    all_tasks = tm.get_tasks()
    print(f"  Total tasks: {len(all_tasks)}")

    # Filter to today's tasks
    today_tasks = filter_today_tasks(all_tasks, today)
    print(f"  Today's tasks: {len(today_tasks)}")

    # Verify results
    assert len(today_tasks) == 2, f"Expected 2 today tasks, got {len(today_tasks)}"
    assert all(t.get('day') == today for t in today_tasks), "All filtered tasks should be for today"
    assert today_tasks[0]['text'] == "Task for today", "First today task should match"
    assert today_tasks[1]['text'] == "Another task for today", "Second today task should match"

    print("✅ PASS: Today filter works correctly")
    print(f"  Filtered tasks:")
    for task in today_tasks:
        print(f"    - {task['text']} (day: {task.get('day')})")

    return True


def test_filter_with_empty_results():
    """Test filtering when no tasks match today"""
    print("\n🔍 TEST: Filter with no today tasks")

    today = get_today_day_name()

    # Create temporary directory for testing
    temp_dir = tempfile.mkdtemp()
    temp_path = Path(temp_dir)
    tm = TaskManager(directory=temp_path)

    # Add tasks but NOT for today
    days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']
    other_days = [d for d in days if d != today]

    tm.add_task("Task 1")
    tm.tasks[0]['day'] = other_days[0]

    tm.add_task("Task 2")
    tm.tasks[1]['day'] = other_days[1]

    tm._save_tasks()

    # Filter to today's tasks
    today_tasks = filter_today_tasks(tm.get_tasks(), today)

    # Verify results
    assert len(today_tasks) == 0, f"Expected 0 today tasks, got {len(today_tasks)}"

    print("✅ PASS: Filter returns empty when no tasks for today")
    return True


def test_filter_with_all_today():
    """Test filtering when all tasks are for today"""
    print("\n🔍 TEST: Filter with all tasks for today")

    today = get_today_day_name()

    # Create temporary directory for testing
    temp_dir = tempfile.mkdtemp()
    temp_path = Path(temp_dir)
    tm = TaskManager(directory=temp_path)

    # Add multiple tasks all for today
    for i in range(5):
        tm.add_task(f"Today task {i+1}")
        tm.tasks[i]['day'] = today

    tm._save_tasks()

    # Filter to today's tasks
    all_tasks = tm.get_tasks()
    today_tasks = filter_today_tasks(all_tasks, today)

    # Verify results
    assert len(today_tasks) == len(all_tasks), "All tasks should be included"
    assert len(today_tasks) == 5, "Should have 5 tasks"

    print("✅ PASS: Filter includes all tasks when all are for today")
    return True


def run_all_tests():
    """Run all today filter tests"""
    print("=" * 60)
    print("TODAY FILTER TESTS")
    print("=" * 60)

    tests = [
        test_filter_today_tasks,
        test_filter_with_empty_results,
        test_filter_with_all_today,
    ]

    passed = 0
    failed = 0

    for test in tests:
        try:
            if test():
                passed += 1
        except AssertionError as e:
            print(f"❌ FAIL: {e}")
            failed += 1
        except Exception as e:
            print(f"❌ ERROR: {e}")
            failed += 1

    print("\n" + "=" * 60)
    print(f"RESULTS: {passed} passed, {failed} failed")
    print("=" * 60)

    return failed == 0


if __name__ == '__main__':
    import sys

    success = run_all_tests()
    sys.exit(0 if success else 1)
