#!/usr/bin/env python3
"""
Test suite for jot task management system
"""

import pytest
import json
import tempfile
from pathlib import Path
from jot import TaskManager, ProjectRegistry, IDManager, CategoryManager, CategoryConfig


class TestTaskManager:
    """Test TaskManager functionality"""

    def test_unique_ids_after_deletion(self):
        """Test that IDs remain unique after deleting tasks"""
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = Path(tmpdir)

            # Create TaskManager
            tm = TaskManager(storage_file='.jot.json', directory=tmpdir)

            # Add 3 tasks
            tm.add_task("task 1")
            tm.add_task("task 2")
            tm.add_task("task 3")

            # Verify initial IDs (should be 1, 2, 3)
            assert tm.tasks[0]['id'] == 1
            assert tm.tasks[1]['id'] == 2
            assert tm.tasks[2]['id'] == 3

            # Delete task 2 (ID 2)
            tm.remove_task(2)

            # Add a new task
            tm.add_task("task 4")

            # New task should get ID 4, NOT 3 (which would be duplicate)
            active_ids = [task['id'] for task in tm.tasks]
            assert 4 in active_ids
            assert len(active_ids) == len(set(active_ids))  # All unique

            # Check archived task
            assert len(tm.archived) == 1
            assert tm.archived[0]['id'] == 2

    def test_default_task_creation(self):
        """Test that 'take a break' task is created if no tasks exist"""
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = Path(tmpdir)

            # Create TaskManager (no .jot.json exists)
            tm = TaskManager(storage_file='.jot.json', directory=tmpdir)

            # Should have no tasks initially
            assert len(tm.tasks) == 0
            assert len(tm.archived) == 0

            # Call ensure_default_task
            tm.ensure_default_task()

            # Should now have one task
            assert len(tm.tasks) == 1
            assert tm.tasks[0]['text'] == "take a break"
            assert tm.tasks[0]['id'] == 1

    def test_default_task_not_created_if_tasks_exist(self):
        """Test that default task is NOT created if tasks already exist"""
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = Path(tmpdir)

            tm = TaskManager(storage_file='.jot.json', directory=tmpdir)
            tm.add_task("existing task")

            # Call ensure_default_task
            tm.ensure_default_task()

            # Should still have only 1 task (the existing one)
            assert len(tm.tasks) == 1
            assert tm.tasks[0]['text'] == "existing task"

    def test_current_task_exclusivity(self):
        """Test that only one task can be current at a time"""
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = Path(tmpdir)

            tm = TaskManager(storage_file='.jot.json', directory=tmpdir)
            tm.add_task("task 1")
            tm.add_task("task 2")
            tm.add_task("task 3")

            # Set task 1 as current
            tm.set_current(1)
            current_count = sum(1 for task in tm.tasks if task.get('current'))
            assert current_count == 1
            assert tm.tasks[0]['current'] is True

            # Set task 2 as current
            tm.set_current(2)
            current_count = sum(1 for task in tm.tasks if task.get('current'))
            assert current_count == 1
            assert tm.tasks[1]['current'] is True
            assert tm.tasks[0]['current'] is False

    def test_task_navigation(self):
        """Test moving tasks up and down"""
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = Path(tmpdir)

            tm = TaskManager(storage_file='.jot.json', directory=tmpdir)
            tm.add_task("task 1")
            tm.add_task("task 2")
            tm.add_task("task 3")

            # Set task 2 as current
            tm.set_current(tm.tasks[1]['id'])

            # Move task 2 up
            tm.move_task_up()

            # Task 2 should now be first
            assert tm.tasks[0]['text'] == "task 2"
            assert tm.tasks[1]['text'] == "task 1"

            # IDs should remain the same
            task_2_id = next(t['id'] for t in tm.tasks if t['text'] == "task 2")
            task_1_id = next(t['id'] for t in tm.tasks if t['text'] == "task 1")
            assert task_2_id == 2
            assert task_1_id == 1

    def test_archive_system(self):
        """Test that deleted tasks move to archive"""
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = Path(tmpdir)

            tm = TaskManager(storage_file='.jot.json', directory=tmpdir)
            tm.add_task("task to delete")
            tm.add_task("task to keep")

            task_id = tm.tasks[0]['id']

            # Delete first task
            tm.remove_task(task_id)

            # Should be in archive
            assert len(tm.archived) == 1
            assert len(tm.tasks) == 1
            assert tm.archived[0]['text'] == "task to delete"
            assert tm.tasks[0]['text'] == "task to keep"

    def test_deletion_sets_previous_task_current(self):
        """Test that deleting a task sets previous task as current"""
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = Path(tmpdir)

            tm = TaskManager(storage_file='.jot.json', directory=tmpdir)
            tm.add_task("task 1")
            tm.add_task("task 2")
            tm.add_task("task 3")
            tm.add_task("task 4")

            # Delete task 3 (middle task)
            task_3_id = tm.tasks[2]['id']
            tm.remove_task(task_3_id)

            # Task 2 should now be current (previous task)
            assert tm.tasks[1]['current'] is True
            assert tm.tasks[1]['text'] == "task 2"

    def test_deletion_first_task_sets_new_first_current(self):
        """Test that deleting first task sets new first task as current"""
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = Path(tmpdir)

            tm = TaskManager(storage_file='.jot.json', directory=tmpdir)
            tm.add_task("task 1")
            tm.add_task("task 2")
            tm.add_task("task 3")

            # Delete first task
            task_1_id = tm.tasks[0]['id']
            tm.remove_task(task_1_id)

            # Task 2 should now be current (new first task)
            assert tm.tasks[0]['current'] is True
            assert tm.tasks[0]['text'] == "task 2"

    def test_deletion_last_task_sets_new_last_current(self):
        """Test that deleting last task sets new last task as current"""
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = Path(tmpdir)

            tm = TaskManager(storage_file='.jot.json', directory=tmpdir)
            tm.add_task("task 1")
            tm.add_task("task 2")
            tm.add_task("task 3")

            # Delete last task
            task_3_id = tm.tasks[2]['id']
            tm.remove_task(task_3_id)

            # Task 2 should now be current (previous/new last task)
            assert tm.tasks[1]['current'] is True
            assert tm.tasks[1]['text'] == "task 2"

    def test_persistence(self):
        """Test that tasks persist across TaskManager instances"""
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = Path(tmpdir)

            # Create first instance and add tasks
            tm1 = TaskManager(storage_file='.jot.json', directory=tmpdir)
            tm1.add_task("persistent task")
            task_id = tm1.tasks[0]['id']

            # Create second instance (should load from file)
            tm2 = TaskManager(storage_file='.jot.json', directory=tmpdir)

            # Should have the same task
            assert len(tm2.tasks) == 1
            assert tm2.tasks[0]['text'] == "persistent task"
            assert tm2.tasks[0]['id'] == task_id

    def test_move_task_up(self):
        """Test moving a task up in the list"""
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = Path(tmpdir)

            # Create TaskManager with 3 tasks
            tm = TaskManager(storage_file='.jot.json', directory=tmpdir)
            tm.add_task("task 1")
            tm.add_task("task 2")
            tm.add_task("task 3")

            # Set task 2 as current (middle position)
            tm.set_current(tm.tasks[1]['id'])
            assert tm.tasks[1]['text'] == "task 2"
            assert tm.tasks[1]['current'] is True

            # Move task 2 up
            result = tm.move_task_up()
            assert result is True

            # Task 2 should now be in position 0
            assert tm.tasks[0]['text'] == "task 2"
            assert tm.tasks[0]['current'] is True
            assert tm.tasks[1]['text'] == "task 1"
            assert tm.tasks[2]['text'] == "task 3"

            # Try to move up again (should fail - already at top)
            result = tm.move_task_up()
            assert result is False
            assert tm.tasks[0]['text'] == "task 2"  # Should still be at top

    def test_move_task_down(self):
        """Test moving a task down in the list"""
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = Path(tmpdir)

            # Create TaskManager with 3 tasks
            tm = TaskManager(storage_file='.jot.json', directory=tmpdir)
            tm.add_task("task 1")
            tm.add_task("task 2")
            tm.add_task("task 3")

            # Set task 2 as current (middle position)
            tm.set_current(tm.tasks[1]['id'])
            assert tm.tasks[1]['text'] == "task 2"
            assert tm.tasks[1]['current'] is True

            # Move task 2 down
            result = tm.move_task_down()
            assert result is True

            # Task 2 should now be in position 2
            assert tm.tasks[0]['text'] == "task 1"
            assert tm.tasks[1]['text'] == "task 3"
            assert tm.tasks[2]['text'] == "task 2"
            assert tm.tasks[2]['current'] is True

            # Try to move down again (should fail - already at bottom)
            result = tm.move_task_down()
            assert result is False
            assert tm.tasks[2]['text'] == "task 2"  # Should still be at bottom

    def test_move_task_edge_cases(self):
        """Test edge cases for task movement"""
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = Path(tmpdir)

            # Test with empty list
            tm = TaskManager(storage_file='.jot.json', directory=tmpdir)
            assert tm.move_task_up() is False
            assert tm.move_task_down() is False

            # Test with single task
            tm.add_task("only task")
            tm.set_current(tm.tasks[0]['id'])
            assert tm.move_task_up() is False
            assert tm.move_task_down() is False

            # Test with no current task
            tm.add_task("task 2")
            tm.tasks[0]['current'] = False  # Manually unset current
            tm.tasks[1]['current'] = False
            assert tm.move_task_up() is False
            assert tm.move_task_down() is False

    def test_move_task_persistence(self):
        """Test that task order persists after moving"""
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = Path(tmpdir)

            # Create TaskManager with 3 tasks
            tm1 = TaskManager(storage_file='.jot.json', directory=tmpdir)
            tm1.add_task("task 1")
            tm1.add_task("task 2")
            tm1.add_task("task 3")

            # Move task 2 up
            tm1.set_current(tm1.tasks[1]['id'])
            tm1.move_task_up()

            # Create new instance (should load from file)
            tm2 = TaskManager(storage_file='.jot.json', directory=tmpdir)

            # Order should be preserved
            assert len(tm2.tasks) == 3
            assert tm2.tasks[0]['text'] == "task 2"
            assert tm2.tasks[1]['text'] == "task 1"
            assert tm2.tasks[2]['text'] == "task 3"

    def test_set_agent_task(self):
        """Test marking a task as agent_task"""
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = Path(tmpdir)

            # Create TaskManager with 3 tasks
            tm = TaskManager(storage_file='.jot.json', directory=tmpdir)
            tm.add_task("task 1")
            tm.add_task("task 2")
            tm.add_task("task 3")

            # Set task 2 as current
            tm.set_current(tm.tasks[1]['id'])
            assert tm.tasks[1]['current'] is True

            # Mark task 2 as agent_task
            result = tm.set_agent_task()
            assert result is True

            # Task 2 should be marked as agent_task
            assert tm.tasks[1]['agent_task'] is True
            # Other tasks should not be marked
            assert tm.tasks[0].get('agent_task', False) is False
            assert tm.tasks[2].get('agent_task', False) is False

            # Toggle off - mark again to unmark
            result = tm.set_agent_task()
            assert result is True
            assert tm.tasks[1]['agent_task'] is False

    def test_set_agent_task_exclusivity(self):
        """Test that only one task can be marked as agent_task at a time"""
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = Path(tmpdir)

            # Create TaskManager with 3 tasks
            tm = TaskManager(storage_file='.jot.json', directory=tmpdir)
            tm.add_task("task 1")
            tm.add_task("task 2")
            tm.add_task("task 3")

            # Mark task 1 as agent_task
            tm.set_current(tm.tasks[0]['id'])
            tm.set_agent_task()
            assert tm.tasks[0]['agent_task'] is True

            # Mark task 2 as agent_task
            tm.set_current(tm.tasks[1]['id'])
            tm.set_agent_task()

            # Task 1 should no longer be agent_task
            assert tm.tasks[0]['agent_task'] is False
            # Task 2 should be agent_task
            assert tm.tasks[1]['agent_task'] is True
            # Task 3 should not be agent_task
            assert tm.tasks[2].get('agent_task', False) is False

    def test_set_agent_task_with_task_id(self):
        """Test marking a specific task as agent_task by ID"""
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = Path(tmpdir)

            # Create TaskManager with 3 tasks
            tm = TaskManager(storage_file='.jot.json', directory=tmpdir)
            tm.add_task("task 1")
            tm.add_task("task 2")
            tm.add_task("task 3")

            # Mark task 3 as agent_task by ID (without setting it as current)
            task_3_id = tm.tasks[2]['id']
            result = tm.set_agent_task(task_3_id)
            assert result is True

            # Task 3 should be marked as agent_task
            assert tm.tasks[2]['agent_task'] is True
            # Other tasks should not be marked
            assert tm.tasks[0].get('agent_task', False) is False
            assert tm.tasks[1].get('agent_task', False) is False

    def test_agent_task_new_tasks_default_false(self):
        """Test that new tasks have agent_task=False by default"""
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = Path(tmpdir)

            # Create TaskManager and add a task
            tm = TaskManager(storage_file='.jot.json', directory=tmpdir)
            tm.add_task("new task")

            # New task should have agent_task=False
            assert tm.tasks[0]['agent_task'] is False

    def test_agent_task_persistence(self):
        """Test that agent_task flag persists across TaskManager instances"""
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = Path(tmpdir)

            # Create TaskManager and mark a task as agent_task
            tm1 = TaskManager(storage_file='.jot.json', directory=tmpdir)
            tm1.add_task("task 1")
            tm1.add_task("task 2")
            tm1.set_current(tm1.tasks[1]['id'])
            tm1.set_agent_task()

            # Create new instance (should load from file)
            tm2 = TaskManager(storage_file='.jot.json', directory=tmpdir)

            # Agent task flag should be preserved
            assert len(tm2.tasks) == 2
            assert tm2.tasks[0]['agent_task'] is False
            assert tm2.tasks[1]['agent_task'] is True


class TestProjectRegistry:
    """Test ProjectRegistry functionality"""

    def test_project_registration(self):
        """Test manual project registration"""
        with tempfile.TemporaryDirectory() as tmpdir:
            registry_file = Path(tmpdir) / 'test-registry.json'

            pr = ProjectRegistry(registry_file=str(registry_file))

            # Register a project
            pr.register_project("test-project", "/fake/path/to/project")

            # Verify it's registered
            assert "test-project" in pr.projects
            assert pr.get_project_path("test-project") == "/fake/path/to/project"

    def test_project_unregistration(self):
        """Test removing projects from registry"""
        with tempfile.TemporaryDirectory() as tmpdir:
            registry_file = Path(tmpdir) / 'test-registry.json'

            pr = ProjectRegistry(registry_file=str(registry_file))
            pr.register_project("test-project", "/fake/path")

            # Unregister
            result = pr.unregister_project("test-project")

            assert result is True
            assert "test-project" not in pr.projects

    def test_project_auto_discovery(self):
        """Test auto-discovery of projects"""
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = Path(tmpdir)
            registry_file = tmpdir / 'test-registry.json'

            # Create fake projects directory structure
            projects_dir = tmpdir / 'projects'
            projects_dir.mkdir()

            # Create a project with .jot.json
            project1 = projects_dir / 'project1'
            project1.mkdir()
            (project1 / '.jot.json').write_text('{"tasks": [], "archived": []}')

            # Create a project without .jot.json (should be ignored)
            project2 = projects_dir / 'project2'
            project2.mkdir()

            # Note: Auto-discovery looks in ~/projects/, not a temp dir
            # This test would need to mock the home directory
            # For now, just test the registration mechanism
            pr = ProjectRegistry(registry_file=str(registry_file))
            pr.register_project("project1", str(project1))

            assert "project1" in pr.projects

    def test_list_projects(self):
        """Test listing all registered projects"""
        with tempfile.TemporaryDirectory() as tmpdir:
            registry_file = Path(tmpdir) / 'test-registry.json'

            # Create empty registry file to prevent auto-discovery
            registry_file.write_text('{}')

            pr = ProjectRegistry(registry_file=str(registry_file))
            pr.register_project("project1", "/path/1")
            pr.register_project("project2", "/path/2")

            projects = pr.list_projects()

            assert len(projects) == 2
            assert "project1" in projects
            assert "project2" in projects
            assert projects["project1"] == "/path/1"
            assert projects["project2"] == "/path/2"

    def test_get_nonexistent_project(self):
        """Test getting a project that doesn't exist"""
        with tempfile.TemporaryDirectory() as tmpdir:
            registry_file = Path(tmpdir) / 'test-registry.json'

            pr = ProjectRegistry(registry_file=str(registry_file))

            path = pr.get_project_path("nonexistent")

            assert path is None

    def test_unregister_nonexistent_project(self):
        """Test unregistering a project that doesn't exist"""
        with tempfile.TemporaryDirectory() as tmpdir:
            registry_file = Path(tmpdir) / 'test-registry.json'

            pr = ProjectRegistry(registry_file=str(registry_file))

            result = pr.unregister_project("nonexistent")

            assert result is False

    def test_registry_persistence(self):
        """Test that registry persists across instances"""
        with tempfile.TemporaryDirectory() as tmpdir:
            registry_file = Path(tmpdir) / 'test-registry.json'

            # First instance - register projects
            pr1 = ProjectRegistry(registry_file=str(registry_file))
            pr1.register_project("project1", "/path/1")
            pr1.register_project("project2", "/path/2")

            # Second instance - should load from file
            pr2 = ProjectRegistry(registry_file=str(registry_file))

            assert "project1" in pr2.projects
            assert "project2" in pr2.projects
            assert pr2.get_project_path("project1") == "/path/1"

    def test_registry_file_creation(self):
        """Test that registry file is created if it doesn't exist"""
        with tempfile.TemporaryDirectory() as tmpdir:
            registry_file = Path(tmpdir) / 'test-registry.json'

            assert not registry_file.exists()

            pr = ProjectRegistry(registry_file=str(registry_file))
            pr.register_project("test", "/path")

            assert registry_file.exists()

    def test_registry_corrupted_json(self):
        """Test handling of corrupted registry file"""
        with tempfile.TemporaryDirectory() as tmpdir:
            registry_file = Path(tmpdir) / 'test-registry.json'

            # Create corrupted JSON file
            registry_file.write_text("{ invalid json }")

            # Should handle gracefully and start with empty registry
            pr = ProjectRegistry(registry_file=str(registry_file))

            assert len(pr.projects) == 0

    def test_register_project_with_expandable_path(self):
        """Test registering project with ~ in path"""
        with tempfile.TemporaryDirectory() as tmpdir:
            registry_file = Path(tmpdir) / 'test-registry.json'

            pr = ProjectRegistry(registry_file=str(registry_file))
            pr.register_project("home-project", "~/some/path")

            # Path should be expanded
            stored_path = pr.get_project_path("home-project")
            assert stored_path is not None
            assert "~" not in stored_path  # Should be expanded

    def test_refresh_registry(self):
        """Test refreshing the registry"""
        with tempfile.TemporaryDirectory() as tmpdir:
            registry_file = Path(tmpdir) / 'test-registry.json'

            pr = ProjectRegistry(registry_file=str(registry_file))
            pr.register_project("test", "/path")

            # Refresh should work without errors
            pr.refresh()

            # Projects should still be there
            assert "test" in pr.projects

    def test_record_usage_increments(self):
        """Test that record_usage increments the count"""
        with tempfile.TemporaryDirectory() as tmpdir:
            registry_file = Path(tmpdir) / 'test-registry.json'
            registry_file.write_text('{}')

            pr = ProjectRegistry(registry_file=str(registry_file))
            pr.register_project("myproject", "/path/myproject")

            pr.record_usage("myproject")
            pr.record_usage("myproject")
            pr.record_usage("myproject")

            # Verify count via list_projects_by_usage
            items = pr.list_projects_by_usage()
            assert len(items) == 1
            assert items[0][0] == "myproject"
            assert items[0][2] == 3

    def test_record_usage_nonexistent_project(self):
        """Test that record_usage on nonexistent project is a no-op"""
        with tempfile.TemporaryDirectory() as tmpdir:
            registry_file = Path(tmpdir) / 'test-registry.json'
            registry_file.write_text('{}')

            pr = ProjectRegistry(registry_file=str(registry_file))
            pr.record_usage("nonexistent")  # Should not raise

    def test_list_projects_by_usage_sorting(self):
        """Test that projects are sorted by usage desc, then name asc"""
        with tempfile.TemporaryDirectory() as tmpdir:
            registry_file = Path(tmpdir) / 'test-registry.json'
            registry_file.write_text('{}')

            pr = ProjectRegistry(registry_file=str(registry_file))
            pr.register_project("alpha", "/path/alpha")
            pr.register_project("beta", "/path/beta")
            pr.register_project("gamma", "/path/gamma")

            pr.record_usage("gamma")
            pr.record_usage("gamma")
            pr.record_usage("alpha")

            items = pr.list_projects_by_usage()
            names = [item[0] for item in items]
            # gamma (2) first, then alpha (1), then beta (0)
            assert names == ["gamma", "alpha", "beta"]

    def test_backward_compat_old_format(self):
        """Test that old {name: path_string} format still works"""
        with tempfile.TemporaryDirectory() as tmpdir:
            registry_file = Path(tmpdir) / 'test-registry.json'
            # Write old format directly
            registry_file.write_text(json.dumps({
                "old-project": "/path/old"
            }))

            pr = ProjectRegistry(registry_file=str(registry_file))

            # get_project_path should work
            assert pr.get_project_path("old-project") == "/path/old"

            # list_projects should return {name: path}
            projects = pr.list_projects()
            assert projects["old-project"] == "/path/old"

            # list_projects_by_usage should treat usage as 0
            items = pr.list_projects_by_usage()
            assert items[0] == ("old-project", "/path/old", 0)

            # record_usage should migrate to new format
            pr.record_usage("old-project")
            assert pr.get_project_path("old-project") == "/path/old"
            items = pr.list_projects_by_usage()
            assert items[0][2] == 1

    def test_register_preserves_usage_count(self):
        """Test that re-registering a project preserves its usage count"""
        with tempfile.TemporaryDirectory() as tmpdir:
            registry_file = Path(tmpdir) / 'test-registry.json'
            registry_file.write_text('{}')

            pr = ProjectRegistry(registry_file=str(registry_file))
            pr.register_project("myproject", "/path/myproject")
            pr.record_usage("myproject")
            pr.record_usage("myproject")

            # Re-register with same name
            pr.register_project("myproject", "/path/myproject")

            items = pr.list_projects_by_usage()
            assert items[0][2] == 2  # Usage count preserved


def test_id_uniqueness_stress_test():
    """Stress test: Add, delete, add many times"""
    with tempfile.TemporaryDirectory() as tmpdir:
        tmpdir = Path(tmpdir)

        tm = TaskManager(storage_file='.jot.json', directory=tmpdir)

        all_ids = set()

        # Add 10 tasks
        for i in range(10):
            tm.add_task(f"task {i}")
            task_id = tm.tasks[-1]['id']
            assert task_id not in all_ids  # Verify uniqueness
            all_ids.add(task_id)

        # Delete every other task
        for task in tm.tasks[::2]:
            tm.remove_task(task['id'])

        # Add 10 more tasks
        for i in range(10, 20):
            tm.add_task(f"task {i}")
            task_id = tm.tasks[-1]['id']
            assert task_id not in all_ids  # Verify uniqueness
            all_ids.add(task_id)

        # Verify all IDs are unique
        active_ids = [task['id'] for task in tm.tasks]
        archived_ids = [task['id'] for task in tm.archived]
        all_current_ids = active_ids + archived_ids

        assert len(all_current_ids) == len(set(all_current_ids))


class TestIDManager:
    """Test IDManager functionality"""

    def test_id_allocation(self):
        """Test basic ID allocation"""
        with tempfile.TemporaryDirectory() as tmpdir:
            id_mgr = IDManager(project_dir=tmpdir)

            # Allocate IDs
            id1 = id_mgr.allocate_id()
            id2 = id_mgr.allocate_id()
            id3 = id_mgr.allocate_id()

            assert id1 == 1
            assert id2 == 2
            assert id3 == 3
            assert id_mgr.next_id == 4

    def test_id_persistence(self):
        """Test that IDs persist across instances"""
        with tempfile.TemporaryDirectory() as tmpdir:
            # First instance
            id_mgr1 = IDManager(project_dir=tmpdir)
            id1 = id_mgr1.allocate_id()
            id2 = id_mgr1.allocate_id()

            assert id1 == 1
            assert id2 == 2

            # Second instance (load from disk)
            id_mgr2 = IDManager(project_dir=tmpdir)
            assert id_mgr2.next_id == 3
            assert id_mgr2.allocated == [1, 2]

            # Allocate from second instance
            id3 = id_mgr2.allocate_id()
            assert id3 == 3

    def test_id_release(self):
        """Test releasing IDs"""
        with tempfile.TemporaryDirectory() as tmpdir:
            id_mgr = IDManager(project_dir=tmpdir)

            _ = id_mgr.allocate_id()
            _ = id_mgr.allocate_id()
            _ = id_mgr.allocate_id()

            assert id_mgr.allocated == [1, 2, 3]

            # Release middle ID
            id_mgr.release_id(2)
            assert id_mgr.allocated == [1, 3]

            # Release should persist
            id_mgr2 = IDManager(project_dir=tmpdir)
            assert id_mgr2.allocated == [1, 3]

    def test_migration_from_existing_ids(self):
        """Test migrating from existing task IDs"""
        with tempfile.TemporaryDirectory() as tmpdir:
            id_mgr = IDManager(project_dir=tmpdir)

            # Simulate existing task IDs
            existing_ids = [5, 10, 15, 20, 25]
            id_mgr.migrate_from_existing_ids(existing_ids)

            # Next ID should be 26 (max + 1)
            assert id_mgr.next_id == 26
            assert id_mgr.allocated == [5, 10, 15, 20, 25]

            # New allocations should continue from 26
            new_id = id_mgr.allocate_id()
            assert new_id == 26

    def test_migration_with_duplicates(self):
        """Test migration handles duplicate IDs correctly"""
        with tempfile.TemporaryDirectory() as tmpdir:
            id_mgr = IDManager(project_dir=tmpdir)

            # Existing IDs with duplicates
            existing_ids = [1, 2, 2, 3, 3, 3, 4]
            id_mgr.migrate_from_existing_ids(existing_ids)

            # Should deduplicate
            assert id_mgr.allocated == [1, 2, 3, 4]
            assert id_mgr.next_id == 5

    def test_empty_migration(self):
        """Test migration with empty ID list"""
        with tempfile.TemporaryDirectory() as tmpdir:
            id_mgr = IDManager(project_dir=tmpdir)
            id_mgr.migrate_from_existing_ids([])

            # Should remain at defaults
            assert id_mgr.next_id == 1
            assert id_mgr.allocated == []

    def test_get_stats(self):
        """Test ID statistics"""
        with tempfile.TemporaryDirectory() as tmpdir:
            id_mgr = IDManager(project_dir=tmpdir)

            id_mgr.allocate_id()
            id_mgr.allocate_id()
            id_mgr.allocate_id()

            stats = id_mgr.get_stats()
            assert stats['next_id'] == 4
            assert stats['allocated_count'] == 3
            assert stats['allocated_ids'] == [1, 2, 3]

    def test_taskmanager_integration(self):
        """Test TaskManager integration with IDManager"""
        with tempfile.TemporaryDirectory() as tmpdir:
            # Create shared ID manager
            id_mgr = IDManager(project_dir=tmpdir)

            # Create TaskManager with shared ID manager
            tm = TaskManager(storage_file='.jot.json', directory=tmpdir, id_manager=id_mgr)

            # Add tasks
            tm.add_task("task 1")
            tm.add_task("task 2")
            tm.add_task("task 3")

            # Verify IDs are allocated
            assert id_mgr.next_id == 4
            assert id_mgr.allocated == [1, 2, 3]

            # Verify task IDs match
            assert tm.tasks[0]['id'] == 1
            assert tm.tasks[1]['id'] == 2
            assert tm.tasks[2]['id'] == 3

    def test_taskmanager_auto_migration(self):
        """Test TaskManager automatically migrates existing IDs"""
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = Path(tmpdir)

            # Create a .jot.json with existing tasks (simulating legacy data)
            jot_file = tmpdir / '.jot.json'
            jot_file.write_text(
                json.dumps(
                    {
                        'tasks': [
                            {'id': 10, 'text': 'task 10', 'done': False, 'current': False},
                            {'id': 20, 'text': 'task 20', 'done': False, 'current': False},
                        ],
                        'archived': [
                            {'id': 5, 'text': 'task 5', 'done': True, 'current': False},
                        ],
                    }
                )
            )

            # Load TaskManager (should auto-migrate)
            tm = TaskManager(storage_file='.jot.json', directory=tmpdir)

            # Verify migration occurred
            assert tm.id_manager.next_id == 21  # max(10, 20, 5) + 1
            assert sorted(tm.id_manager.allocated) == [5, 10, 20]

            # Add new task - should get ID 21
            tm.add_task("new task")
            assert tm.tasks[-1]['id'] == 21

    def test_duplicate_id_autofix(self):
        """Test that duplicate IDs are automatically fixed"""
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = Path(tmpdir)

            # Create a .jot.json with duplicate IDs
            jot_file = tmpdir / '.jot.json'
            jot_file.write_text(
                json.dumps(
                    {
                        'tasks': [
                            {'id': 10, 'text': 'task 10a', 'done': False, 'current': False},
                            {'id': 10, 'text': 'task 10b', 'done': False, 'current': False},
                            {'id': 20, 'text': 'task 20', 'done': False, 'current': False},
                        ],
                        'archived': [
                            {'id': 10, 'text': 'task 10c', 'done': True, 'current': False},
                        ],
                    }
                )
            )

            # Loading TaskManager should auto-fix duplicates (no error)
            tm = TaskManager(storage_file='.jot.json', directory=tmpdir)

            # Verify duplicates were fixed
            all_ids = [t['id'] for t in tm.tasks] + [t['id'] for t in tm.archived]
            assert len(all_ids) == len(set(all_ids)), "All IDs should be unique"

            # Verify first occurrence kept original ID
            assert tm.tasks[0]['id'] == 10, "First task should keep ID 10"
            assert tm.tasks[0]['text'] == 'task 10a'

            # Verify subsequent duplicates got new IDs
            assert tm.tasks[1]['id'] != 10, "Second task should have new ID"
            assert tm.tasks[1]['text'] == 'task 10b'

            # Verify non-duplicate kept original ID
            assert tm.tasks[2]['id'] == 20, "Non-duplicate should keep original ID"

            # Verify archived duplicate got new ID
            assert tm.archived[0]['id'] != 10, "Archived duplicate should have new ID"
            assert tm.archived[0]['text'] == 'task 10c'

            # Verify backup was created in organized structure
            backup_dir = tmpdir / '.jot-backups'
            assert backup_dir.exists(), "Backup directory should be created"

            # Find all backup files in any month subdirectory
            backup_files = list(backup_dir.glob('*/*.json'))
            assert len(backup_files) == 1, "Backup should be created"

    def test_concurrent_id_allocation(self):
        """Test that concurrent ID allocation doesn't produce duplicates"""
        import threading
        import time

        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = Path(tmpdir)
            allocated_ids = []
            allocation_errors = []

            def allocate_ids(count):
                """Worker function to allocate IDs"""
                try:
                    # Create new IDManager instance (simulates separate process)
                    id_mgr = IDManager(project_dir=tmpdir)

                    for _ in range(count):
                        new_id = id_mgr.allocate_id()
                        allocated_ids.append(new_id)
                        # Small delay to increase chance of race condition
                        time.sleep(0.001)
                except Exception as e:
                    allocation_errors.append(str(e))

            # Create multiple threads that allocate IDs concurrently
            num_threads = 5
            ids_per_thread = 10
            threads = []

            for _ in range(num_threads):
                thread = threading.Thread(target=allocate_ids, args=(ids_per_thread,))
                threads.append(thread)
                thread.start()

            # Wait for all threads to complete
            for thread in threads:
                thread.join()

            # Verify no errors occurred
            assert len(allocation_errors) == 0, f"Allocation errors: {allocation_errors}"

            # Verify total number of IDs allocated
            total_expected = num_threads * ids_per_thread
            assert (
                len(allocated_ids) == total_expected
            ), f"Expected {total_expected} IDs, got {len(allocated_ids)}"

            # Verify all IDs are unique (no duplicates)
            unique_ids = set(allocated_ids)
            assert len(unique_ids) == len(
                allocated_ids
            ), f"Found duplicate IDs! Allocated: {sorted(allocated_ids)}, Unique: {sorted(unique_ids)}"

            # Verify all IDs are sequential from 1 to total_expected
            assert unique_ids == set(
                range(1, total_expected + 1)
            ), f"IDs should be 1 to {total_expected}, got: {sorted(unique_ids)}"

            # Verify IDManager state is correct
            final_id_mgr = IDManager(project_dir=tmpdir)
            assert (
                final_id_mgr.next_id == total_expected + 1
            ), f"next_id should be {total_expected + 1}, got {final_id_mgr.next_id}"
            assert (
                len(final_id_mgr.allocated) == total_expected
            ), f"Should have {total_expected} allocated IDs, got {len(final_id_mgr.allocated)}"


class TestCategories:
    """Test category functionality"""

    def test_category_filename(self):
        """Test that category creates correct filename"""
        with tempfile.TemporaryDirectory() as tmpdir:
            # Default category
            tm_default = TaskManager(directory=tmpdir)
            assert tm_default.storage_file.name == '.jot.json'
            assert tm_default.category is None

            # Named category
            tm_features = TaskManager(directory=tmpdir, category='features')
            assert tm_features.storage_file.name == 'features.json'
            assert str(tm_features.storage_file.parent.name) == '.jot-categories'
            assert tm_features.category == 'features'

            # Another category
            tm_bugs = TaskManager(directory=tmpdir, category='bugs')
            assert tm_bugs.storage_file.name == 'bugs.json'
            assert str(tm_bugs.storage_file.parent.name) == '.jot-categories'
            assert tm_bugs.category == 'bugs'

    def test_category_task_isolation(self):
        """Test that tasks are isolated between categories"""
        with tempfile.TemporaryDirectory() as tmpdir:
            # Create tasks in different categories
            tm_features = TaskManager(directory=tmpdir, category='features')
            tm_bugs = TaskManager(directory=tmpdir, category='bugs')
            tm_default = TaskManager(directory=tmpdir)

            # Add tasks to each category
            tm_features.add_task("Add login feature")
            tm_features.add_task("Add logout feature")

            tm_bugs.add_task("Fix navigation bug")

            tm_default.add_task("General task")

            # Verify isolation
            assert len(tm_features.tasks) == 2
            assert len(tm_bugs.tasks) == 1
            assert len(tm_default.tasks) == 1

            assert tm_features.tasks[0]['text'] == "Add login feature"
            assert tm_bugs.tasks[0]['text'] == "Fix navigation bug"
            assert tm_default.tasks[0]['text'] == "General task"

    def test_shared_id_manager_across_categories(self):
        """Test that categories share ID manager"""
        with tempfile.TemporaryDirectory() as tmpdir:
            # Create shared ID manager
            id_mgr = IDManager(project_dir=tmpdir)

            # Create multiple categories with shared ID manager
            tm_features = TaskManager(directory=tmpdir, category='features', id_manager=id_mgr)
            tm_bugs = TaskManager(directory=tmpdir, category='bugs', id_manager=id_mgr)

            # Add tasks to different categories
            tm_features.add_task("Feature 1")
            tm_bugs.add_task("Bug 1")
            tm_features.add_task("Feature 2")

            # Verify IDs are globally unique
            assert tm_features.tasks[0]['id'] == 1  # Feature 1
            assert tm_bugs.tasks[0]['id'] == 2  # Bug 1
            assert tm_features.tasks[1]['id'] == 3  # Feature 2

            # Verify ID manager has all IDs
            assert id_mgr.allocated == [1, 2, 3]
            assert id_mgr.next_id == 4

    def test_category_persistence(self):
        """Test that category tasks persist across instances"""
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = Path(tmpdir)

            # Create category and add tasks
            tm1 = TaskManager(directory=tmpdir, category='features')
            tm1.add_task("Feature 1")
            tm1.add_task("Feature 2")

            # Verify file was created
            features_file = tmpdir / '.jot-categories' / 'features.json'
            assert features_file.exists()

            # Load in new instance
            tm2 = TaskManager(directory=tmpdir, category='features')
            assert len(tm2.tasks) == 2
            assert tm2.tasks[0]['text'] == "Feature 1"
            assert tm2.tasks[1]['text'] == "Feature 2"

    def test_multiple_categories_coexist(self):
        """Test multiple category files can coexist"""
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = Path(tmpdir)
            id_mgr = IDManager(project_dir=tmpdir)

            # Create multiple categories
            categories = ['features', 'bugs', 'testing', 'docs']
            task_managers = {}

            for cat in categories:
                tm = TaskManager(directory=tmpdir, category=cat, id_manager=id_mgr)
                tm.add_task(f"Task in {cat}")
                task_managers[cat] = tm

            # Verify all files exist
            for cat in categories:
                cat_file = tmpdir / '.jot-categories' / f'{cat}.json'
                assert cat_file.exists()

            # Verify each category has its task
            for cat in categories:
                tm = TaskManager(directory=tmpdir, category=cat, id_manager=id_mgr)
                assert len(tm.tasks) == 1
                assert tm.tasks[0]['text'] == f"Task in {cat}"

            # Verify IDs are unique across all categories
            assert id_mgr.allocated == [1, 2, 3, 4]

    def test_backward_compatibility_no_category(self):
        """Test backward compatibility when no category specified"""
        with tempfile.TemporaryDirectory() as tmpdir:
            # Create TaskManager without category (old behavior)
            tm = TaskManager(directory=tmpdir)

            # Should use .jot.json
            assert tm.storage_file.name == '.jot.json'
            assert tm.category is None

            # Should work normally
            tm.add_task("Test task")
            assert len(tm.tasks) == 1

            # Reload should work
            tm2 = TaskManager(directory=tmpdir)
            assert len(tm2.tasks) == 1
            assert tm2.tasks[0]['text'] == "Test task"


class TestCategoryManager:
    """Test CategoryManager functionality"""

    def test_discover_categories(self):
        """Test discovering categories from .jot-categories/ directory"""
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = Path(tmpdir)

            # Create .jot-categories directory with category files
            (tmpdir / '.jot-categories').mkdir(exist_ok=True)
            (tmpdir / '.jot-categories' / 'features.json').write_text('{}')
            (tmpdir / '.jot-categories' / 'bugs.json').write_text('{}')
            (tmpdir / '.jot-categories' / 'testing.json').write_text('{}')

            # Create some non-category files (should be ignored)
            (tmpdir / '.jot.json').write_text('{}')  # Default file
            (tmpdir / '.jot.ids.json').write_text('{}')  # ID manager file
            (tmpdir / 'other.json').write_text('{}')  # Not a jot file

            cat_mgr = CategoryManager(project_dir=tmpdir)
            categories = cat_mgr.discover_categories()

            assert categories == ['bugs', 'features', 'testing']

    def test_count_categories(self):
        """Test counting categories"""
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = Path(tmpdir)

            cat_mgr = CategoryManager(project_dir=tmpdir)
            assert cat_mgr.count_categories() == 0

            # Add categories
            (tmpdir / '.jot-categories').mkdir(exist_ok=True)
            (tmpdir / '.jot-categories' / 'features.json').write_text('{}')
            assert cat_mgr.count_categories() == 1

            (tmpdir / '.jot-categories' / 'bugs.json').write_text('{}')
            assert cat_mgr.count_categories() == 2

    def test_can_create_category_existing(self):
        """Test that existing categories can be used"""
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = Path(tmpdir)
            (tmpdir / '.jot-categories').mkdir(exist_ok=True)
            (tmpdir / '.jot-categories' / 'features.json').write_text('{}')

            cat_mgr = CategoryManager(project_dir=tmpdir)
            can_create, msg = cat_mgr.can_create_category('features')

            assert can_create is True
            assert msg is None

    def test_can_create_category_new(self):
        """Test creating a new category under limit"""
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = Path(tmpdir)

            # Create 5 categories
            for i in range(5):
                (tmpdir / '.jot-categories').mkdir(exist_ok=True)
                (tmpdir / '.jot-categories' / f'cat{i}.json').write_text('{}')

            cat_mgr = CategoryManager(project_dir=tmpdir)
            can_create, msg = cat_mgr.can_create_category('new_category')

            assert can_create is True
            assert msg is None

    def test_category_limit_enforced(self):
        """Test that category limit is enforced at 12"""
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = Path(tmpdir)

            # Create 12 categories (at the limit)
            for i in range(12):
                (tmpdir / '.jot-categories').mkdir(exist_ok=True)
                (tmpdir / '.jot-categories' / f'cat{i}.json').write_text('{}')

            cat_mgr = CategoryManager(project_dir=tmpdir)
            can_create, msg = cat_mgr.can_create_category('new_category')

            assert can_create is False
            assert 'Category limit reached' in msg
            assert '12 max' in msg

    def test_warning_at_10_categories(self):
        """Test warning when creating 11th category"""
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = Path(tmpdir)

            # Create 10 categories
            for i in range(10):
                (tmpdir / '.jot-categories').mkdir(exist_ok=True)
                (tmpdir / '.jot-categories' / f'cat{i}.json').write_text('{}')

            cat_mgr = CategoryManager(project_dir=tmpdir)
            warning = cat_mgr.get_warning_message('new_category')

            assert warning is not None
            assert 'Approaching category limit' in warning
            assert '11/12' in warning

    def test_warning_at_11_categories(self):
        """Test warning when creating 12th category"""
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = Path(tmpdir)

            # Create 11 categories
            for i in range(11):
                (tmpdir / '.jot-categories').mkdir(exist_ok=True)
                (tmpdir / '.jot-categories' / f'cat{i}.json').write_text('{}')

            cat_mgr = CategoryManager(project_dir=tmpdir)
            warning = cat_mgr.get_warning_message('new_category')

            assert warning is not None
            assert 'Near category limit' in warning
            assert '12/12' in warning

    def test_no_warning_for_existing_category(self):
        """Test no warning when using existing category"""
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = Path(tmpdir)

            # Create 11 categories
            for i in range(11):
                (tmpdir / '.jot-categories').mkdir(exist_ok=True)
                (tmpdir / '.jot-categories' / f'cat{i}.json').write_text('{}')

            cat_mgr = CategoryManager(project_dir=tmpdir)

            # Using existing category should not warn
            warning = cat_mgr.get_warning_message('cat5')
            assert warning is None

    def test_no_warning_under_10_categories(self):
        """Test no warning when under 10 categories"""
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = Path(tmpdir)

            # Create 5 categories
            for i in range(5):
                (tmpdir / '.jot-categories').mkdir(exist_ok=True)
                (tmpdir / '.jot-categories' / f'cat{i}.json').write_text('{}')

            cat_mgr = CategoryManager(project_dir=tmpdir)
            warning = cat_mgr.get_warning_message('new_category')

            assert warning is None

    def test_category_limit_constant(self):
        """Test that MAX_CATEGORIES is set to 12"""
        assert CategoryManager.MAX_CATEGORIES == 12


class TestGlobalCategories:
    """Test global category functionality"""

    def test_global_category_storage(self):
        """Test that global categories are stored in ~/.jot-categories/"""
        with tempfile.TemporaryDirectory() as tmpdir:
            # Override global directory for testing
            original_global_dir = CategoryManager.GLOBAL_CATEGORIES_DIR
            test_global_dir = Path(tmpdir) / '.jot-categories'
            CategoryManager.GLOBAL_CATEGORIES_DIR = test_global_dir

            try:
                # Create global task manager
                tm = TaskManager(category='bills', is_global=True)
                tm.add_task("Pay rent")

                # Verify file was created in global directory
                global_file = test_global_dir / 'bills.json'
                assert global_file.exists()

                # Verify content
                data = json.loads(global_file.read_text())
                assert len(data['tasks']) == 1
                assert data['tasks'][0]['text'] == "Pay rent"

            finally:
                CategoryManager.GLOBAL_CATEGORIES_DIR = original_global_dir

    def test_global_category_ids(self):
        """Test that global categories have separate ID managers"""
        with tempfile.TemporaryDirectory() as tmpdir:
            original_global_dir = CategoryManager.GLOBAL_CATEGORIES_DIR
            test_global_dir = Path(tmpdir) / '.jot-categories'
            CategoryManager.GLOBAL_CATEGORIES_DIR = test_global_dir

            try:
                # Create two global categories
                tm_bills = TaskManager(category='bills', is_global=True)
                tm_health = TaskManager(category='health', is_global=True)

                # Add tasks to each
                tm_bills.add_task("Pay rent")
                tm_health.add_task("Gym appointment")

                # Each should have separate ID files
                bills_ids = test_global_dir / 'bills.ids.json'
                health_ids = test_global_dir / 'health.ids.json'

                assert bills_ids.exists()
                assert health_ids.exists()

                # IDs should be independent
                bills_data = json.loads(bills_ids.read_text())
                health_data = json.loads(health_ids.read_text())

                # Both start from 1
                assert 1 in bills_data['allocated']
                assert 1 in health_data['allocated']

            finally:
                CategoryManager.GLOBAL_CATEGORIES_DIR = original_global_dir

    def test_category_resolution_local_first(self):
        """Test that local categories are preferred over global"""
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = Path(tmpdir)

            original_global_dir = CategoryManager.GLOBAL_CATEGORIES_DIR
            test_global_dir = tmpdir / '.jot-categories-test'
            CategoryManager.GLOBAL_CATEGORIES_DIR = test_global_dir

            try:
                # Create both local and global 'features' category
                local_tm = TaskManager(directory=tmpdir, category='features', is_global=False)
                local_tm.add_task("Local feature")

                global_tm = TaskManager(category='features', is_global=True)
                global_tm.add_task("Global feature")

                # Use CategoryManager to resolve
                cat_mgr = CategoryManager(project_dir=tmpdir)
                location = cat_mgr.resolve_category_location('features')

                # Should resolve to 'local' since local exists
                assert location == 'local'

            finally:
                CategoryManager.GLOBAL_CATEGORIES_DIR = original_global_dir

    def test_category_resolution_global_fallback(self):
        """Test that global categories are used when local doesn't exist"""
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = Path(tmpdir)

            original_global_dir = CategoryManager.GLOBAL_CATEGORIES_DIR
            test_global_dir = tmpdir / '.jot-categories-test'
            CategoryManager.GLOBAL_CATEGORIES_DIR = test_global_dir

            try:
                # Create only global 'bills' category
                global_tm = TaskManager(category='bills', is_global=True)
                global_tm.add_task("Global bill")

                # Use CategoryManager to resolve
                cat_mgr = CategoryManager(project_dir=tmpdir)
                location = cat_mgr.resolve_category_location('bills')

                # Should resolve to 'global' since local doesn't exist
                assert location == 'global'

            finally:
                CategoryManager.GLOBAL_CATEGORIES_DIR = original_global_dir

    def test_category_resolution_new(self):
        """Test that non-existent categories resolve to 'new'"""
        with tempfile.TemporaryDirectory() as tmpdir:
            cat_mgr = CategoryManager(project_dir=tmpdir)
            location = cat_mgr.resolve_category_location('nonexistent')

            assert location == 'new'

    def test_discover_global_categories(self):
        """Test discovering global categories"""
        with tempfile.TemporaryDirectory() as tmpdir:
            original_global_dir = CategoryManager.GLOBAL_CATEGORIES_DIR
            test_global_dir = Path(tmpdir) / '.jot-categories-test'
            CategoryManager.GLOBAL_CATEGORIES_DIR = test_global_dir
            test_global_dir.mkdir(parents=True, exist_ok=True)

            try:
                # Create some global category files
                (test_global_dir / 'bills.json').write_text('{}')
                (test_global_dir / 'health.json').write_text('{}')
                (test_global_dir / 'learning.json').write_text('{}')

                # Create ID files (should be ignored)
                (test_global_dir / 'bills.ids.json').write_text('{}')

                cat_mgr = CategoryManager()
                global_cats = cat_mgr.discover_global_categories()

                assert global_cats == ['bills', 'health', 'learning']

            finally:
                CategoryManager.GLOBAL_CATEGORIES_DIR = original_global_dir

    def test_global_category_persistence(self):
        """Test that global categories persist across instances"""
        with tempfile.TemporaryDirectory() as tmpdir:
            original_global_dir = CategoryManager.GLOBAL_CATEGORIES_DIR
            test_global_dir = Path(tmpdir) / '.jot-categories-test'
            CategoryManager.GLOBAL_CATEGORIES_DIR = test_global_dir

            try:
                # Create global category and add task
                tm1 = TaskManager(category='bills', is_global=True)
                tm1.add_task("Pay rent")

                # Load in new instance
                tm2 = TaskManager(category='bills', is_global=True)

                # Should have the persisted task
                assert len(tm2.tasks) == 1
                assert tm2.tasks[0]['text'] == "Pay rent"

            finally:
                CategoryManager.GLOBAL_CATEGORIES_DIR = original_global_dir


class TestBacklogGrooming:
    """Test backlog grooming features (priority, status, labels, etc.)"""

    def test_new_task_has_grooming_fields(self):
        """Test that newly created tasks have all backlog grooming fields"""
        with tempfile.TemporaryDirectory() as tmpdir:
            tm = TaskManager(storage_file='.jot.json', directory=tmpdir)
            tm.add_task(
                "Test task", priority='high', status='in-progress', labels=['bug', 'urgent']
            )

            task = tm.tasks[0]

            # Verify all grooming fields exist
            assert 'priority' in task
            assert 'status' in task
            assert 'created_at' in task
            assert 'updated_at' in task
            assert 'labels' in task
            assert 'effort' in task
            assert 'blocked_by' in task

            # Verify values
            assert task['priority'] == 'high'
            assert task['status'] == 'in-progress'
            assert task['labels'] == ['bug', 'urgent']
            assert task['effort'] is None  # default
            assert task['blocked_by'] == []  # default

            # Verify timestamps are ISO 8601 format
            from datetime import datetime

            datetime.fromisoformat(task['created_at'])  # Should not raise
            datetime.fromisoformat(task['updated_at'])  # Should not raise

    def test_new_task_default_grooming_values(self):
        """Test that default grooming values are set correctly"""
        with tempfile.TemporaryDirectory() as tmpdir:
            tm = TaskManager(storage_file='.jot.json', directory=tmpdir)
            tm.add_task("Test task")  # No optional parameters

            task = tm.tasks[0]

            # Verify defaults
            assert task['priority'] == 'none'
            assert task['status'] == 'todo'
            assert task['labels'] == []
            assert task['effort'] is None
            assert task['blocked_by'] == []

    def test_migrate_backlog_schema(self):
        """Test migrating existing tasks to backlog grooming schema"""
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = Path(tmpdir)

            # Create legacy .jot.json without grooming fields
            jot_file = tmpdir / '.jot.json'
            jot_file.write_text(
                json.dumps(
                    {
                        'tasks': [
                            {'id': 1, 'text': 'task 1', 'done': False, 'current': False},
                            {'id': 2, 'text': 'task 2', 'done': True, 'current': False},
                        ],
                        'archived': [
                            {'id': 3, 'text': 'task 3', 'done': True, 'current': False},
                        ],
                    }
                )
            )

            # Load and migrate
            tm = TaskManager(storage_file='.jot.json', directory=tmpdir)
            stats = tm.migrate_backlog_schema()

            # Verify migration stats
            assert stats['migrated'] == 3  # 2 active + 1 archived
            assert stats['already_migrated'] == 0
            assert stats['total'] == 3

            # Verify all tasks have grooming fields
            all_tasks = tm.tasks + tm.archived
            for task in all_tasks:
                assert 'priority' in task
                assert 'status' in task
                assert 'created_at' in task
                assert 'updated_at' in task
                assert 'labels' in task
                assert 'effort' in task
                assert 'blocked_by' in task

            # Verify status inference from 'done' field
            assert tm.tasks[0]['status'] == 'todo'  # done=False → todo
            assert tm.tasks[1]['status'] == 'done'  # done=True → done
            assert tm.archived[0]['status'] == 'done'  # done=True → done

    def test_migrate_backlog_schema_idempotent(self):
        """Test that migration can be run multiple times safely"""
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = Path(tmpdir)

            # Create legacy .jot.json
            jot_file = tmpdir / '.jot.json'
            jot_file.write_text(
                json.dumps(
                    {
                        'tasks': [
                            {'id': 1, 'text': 'task 1', 'done': False, 'current': False},
                        ],
                        'archived': [],
                    }
                )
            )

            # First migration
            tm = TaskManager(storage_file='.jot.json', directory=tmpdir)
            stats1 = tm.migrate_backlog_schema()
            assert stats1['migrated'] == 1
            assert stats1['already_migrated'] == 0

            # Second migration (should be idempotent)
            stats2 = tm.migrate_backlog_schema()
            assert stats2['migrated'] == 0
            assert stats2['already_migrated'] == 1  # Already has fields

            # Task should still be valid
            task = tm.tasks[0]
            assert task['priority'] == 'none'
            assert task['status'] == 'todo'

    def test_migrate_preserves_existing_data(self):
        """Test that migration preserves all existing task data"""
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = Path(tmpdir)

            # Create legacy .jot.json with various fields
            jot_file = tmpdir / '.jot.json'
            jot_file.write_text(
                json.dumps(
                    {
                        'tasks': [
                            {
                                'id': 1,
                                'text': 'task with metadata',
                                'done': False,
                                'current': True,
                                'day': 'Monday',
                                'tally': 5,
                                'time_spent': '2h',
                                'sessions': [{'date': '2025-01-01', 'duration': '1h'}],
                            },
                        ],
                        'archived': [],
                    }
                )
            )

            # Load and migrate
            tm = TaskManager(storage_file='.jot.json', directory=tmpdir)
            tm.migrate_backlog_schema()

            task = tm.tasks[0]

            # Verify old fields preserved
            assert task['text'] == 'task with metadata'
            assert task['done'] is False
            assert task['current'] is True
            assert task['day'] == 'Monday'
            assert task['tally'] == 5
            assert task['time_spent'] == '2h'
            assert task['sessions'] == [{'date': '2025-01-01', 'duration': '1h'}]

            # Verify new fields added
            assert 'priority' in task
            assert 'status' in task
            assert 'created_at' in task


class TestPriorityAndStatusManagement:
    """Tests for priority and status management features"""

    def test_set_task_priority(self):
        """Test setting task priority"""
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = Path(tmpdir)

            tm = TaskManager(storage_file='.jot.json', directory=tmpdir)
            tm.add_task('test priority task')

            task_id = tm.tasks[0]['id']

            # Set to low priority
            result = tm.set_task_priority(task_id, 'low')
            assert result is True
            assert tm.tasks[0]['priority'] == 'low'
            assert 'updated_at' in tm.tasks[0]

            # Set to medium priority
            tm.set_task_priority(task_id, 'medium')
            assert tm.tasks[0]['priority'] == 'medium'

            # Set to high priority
            tm.set_task_priority(task_id, 'high')
            assert tm.tasks[0]['priority'] == 'high'

            # Set back to none
            tm.set_task_priority(task_id, 'none')
            assert tm.tasks[0]['priority'] == 'none'

    def test_set_task_priority_invalid(self):
        """Test that invalid priority values raise ValueError"""
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = Path(tmpdir)

            tm = TaskManager(storage_file='.jot.json', directory=tmpdir)
            tm.add_task('test task')

            task_id = tm.tasks[0]['id']

            with pytest.raises(ValueError, match="Priority must be one of"):
                tm.set_task_priority(task_id, 'invalid')

    def test_set_task_priority_nonexistent_task(self):
        """Test setting priority on nonexistent task returns False"""
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = Path(tmpdir)

            tm = TaskManager(storage_file='.jot.json', directory=tmpdir)
            tm.add_task('test task')

            result = tm.set_task_priority(99999, 'high')
            assert result is False

    def test_set_task_status(self):
        """Test setting task status"""
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = Path(tmpdir)

            tm = TaskManager(storage_file='.jot.json', directory=tmpdir)
            tm.add_task('test status task')

            task_id = tm.tasks[0]['id']

            # Set to in-progress
            result = tm.set_task_status(task_id, 'in-progress')
            assert result is True
            assert tm.tasks[0]['status'] == 'in-progress'
            assert 'updated_at' in tm.tasks[0]

            # Set to blocked
            tm.set_task_status(task_id, 'blocked')
            assert tm.tasks[0]['status'] == 'blocked'

            # Set to done
            tm.set_task_status(task_id, 'done')
            assert tm.tasks[0]['status'] == 'done'
            assert tm.tasks[0]['done'] is True  # done field should be auto-updated

            # Set back to todo
            tm.set_task_status(task_id, 'todo')
            assert tm.tasks[0]['status'] == 'todo'
            assert tm.tasks[0]['done'] is False  # done field should be cleared

    def test_set_task_status_syncs_done_field(self):
        """Test that status 'done' syncs with the 'done' field"""
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = Path(tmpdir)

            tm = TaskManager(storage_file='.jot.json', directory=tmpdir)
            tm.add_task('test task')

            task_id = tm.tasks[0]['id']

            # Initially not done
            assert tm.tasks[0]['done'] is False
            assert tm.tasks[0]['status'] == 'todo'

            # Setting status to 'done' should set done=True
            tm.set_task_status(task_id, 'done')
            assert tm.tasks[0]['done'] is True
            assert tm.tasks[0]['status'] == 'done'

            # Setting status away from 'done' should set done=False
            tm.set_task_status(task_id, 'in-progress')
            assert tm.tasks[0]['done'] is False
            assert tm.tasks[0]['status'] == 'in-progress'

    def test_set_task_status_invalid(self):
        """Test that invalid status values raise ValueError"""
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = Path(tmpdir)

            tm = TaskManager(storage_file='.jot.json', directory=tmpdir)
            tm.add_task('test task')

            task_id = tm.tasks[0]['id']

            with pytest.raises(ValueError, match="Status must be one of"):
                tm.set_task_status(task_id, 'invalid')

    def test_set_task_status_nonexistent_task(self):
        """Test setting status on nonexistent task returns False"""
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = Path(tmpdir)

            tm = TaskManager(storage_file='.jot.json', directory=tmpdir)
            tm.add_task('test task')

            result = tm.set_task_status(99999, 'done')
            assert result is False

    def test_priority_and_status_updates_timestamp(self):
        """Test that priority and status changes update the updated_at timestamp"""
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = Path(tmpdir)
            import time

            tm = TaskManager(storage_file='.jot.json', directory=tmpdir)
            tm.add_task('test task')

            task_id = tm.tasks[0]['id']
            initial_updated_at = tm.tasks[0]['updated_at']

            # Wait a tiny bit to ensure timestamp changes
            time.sleep(0.01)

            # Set priority
            tm.set_task_priority(task_id, 'high')
            priority_updated_at = tm.tasks[0]['updated_at']
            assert priority_updated_at != initial_updated_at

            # Wait again
            time.sleep(0.01)

            # Set status
            tm.set_task_status(task_id, 'in-progress')
            status_updated_at = tm.tasks[0]['updated_at']
            assert status_updated_at != priority_updated_at


class TestTaskAgingDetection:
    """Tests for task aging and staleness detection"""

    def test_get_task_age_days(self):
        """Test calculating task age in days"""
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = Path(tmpdir)
            from datetime import datetime, timezone, timedelta

            tm = TaskManager(storage_file='.jot.json', directory=tmpdir)
            tm.add_task('test task')

            # Get the task
            task = tm.tasks[0]

            # Task should have age of 0 days (just created)
            age = tm.get_task_age_days(task)
            assert age == 0

            # Manually set updated_at to 5 days ago
            five_days_ago = datetime.now(timezone.utc) - timedelta(days=5)
            task['updated_at'] = five_days_ago.isoformat()

            age = tm.get_task_age_days(task)
            assert age == 5

    def test_get_task_age_days_no_timestamp(self):
        """Test that tasks without timestamp return None for age"""
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = Path(tmpdir)

            # Create task without timestamp (legacy task)
            jot_file = tmpdir / '.jot.json'
            jot_file.write_text(
                json.dumps(
                    {
                        'tasks': [
                            {
                                'id': 1,
                                'text': 'legacy task',
                                'done': False,
                                'current': False,
                            }
                        ],
                        'archived': [],
                    }
                )
            )

            tm = TaskManager(storage_file='.jot.json', directory=tmpdir)
            task = tm.tasks[0]

            age = tm.get_task_age_days(task)
            assert age is None

    def test_is_task_stale(self):
        """Test staleness detection"""
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = Path(tmpdir)
            from datetime import datetime, timezone, timedelta

            tm = TaskManager(storage_file='.jot.json', directory=tmpdir)
            tm.add_task('test task')

            task = tm.tasks[0]

            # Fresh task should not be stale
            assert tm.is_task_stale(task, stale_threshold_days=7) is False

            # Task 5 days old with 7 day threshold should not be stale
            five_days_ago = datetime.now(timezone.utc) - timedelta(days=5)
            task['updated_at'] = five_days_ago.isoformat()
            assert tm.is_task_stale(task, stale_threshold_days=7) is False

            # Task 7 days old with 7 day threshold should be stale
            seven_days_ago = datetime.now(timezone.utc) - timedelta(days=7)
            task['updated_at'] = seven_days_ago.isoformat()
            assert tm.is_task_stale(task, stale_threshold_days=7) is True

            # Task 10 days old should be stale
            ten_days_ago = datetime.now(timezone.utc) - timedelta(days=10)
            task['updated_at'] = ten_days_ago.isoformat()
            assert tm.is_task_stale(task, stale_threshold_days=7) is True

    def test_is_task_stale_done_tasks(self):
        """Test that done tasks are never considered stale"""
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = Path(tmpdir)
            from datetime import datetime, timezone, timedelta

            tm = TaskManager(storage_file='.jot.json', directory=tmpdir)
            tm.add_task('test task')

            task = tm.tasks[0]

            # Make task 30 days old
            thirty_days_ago = datetime.now(timezone.utc) - timedelta(days=30)
            task['updated_at'] = thirty_days_ago.isoformat()

            # Old task should be stale
            assert tm.is_task_stale(task, stale_threshold_days=7) is True

            # Mark as done
            task['done'] = True

            # Done task should not be stale
            assert tm.is_task_stale(task, stale_threshold_days=7) is False

    def test_is_task_stale_status_done(self):
        """Test that tasks with status='done' are not considered stale"""
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = Path(tmpdir)
            from datetime import datetime, timezone, timedelta

            tm = TaskManager(storage_file='.jot.json', directory=tmpdir)
            tm.add_task('test task')

            task = tm.tasks[0]

            # Make task 30 days old
            thirty_days_ago = datetime.now(timezone.utc) - timedelta(days=30)
            task['updated_at'] = thirty_days_ago.isoformat()

            # Old task should be stale
            assert tm.is_task_stale(task, stale_threshold_days=7) is True

            # Set status to done
            task['status'] = 'done'

            # Task with status='done' should not be stale
            assert tm.is_task_stale(task, stale_threshold_days=7) is False

    def test_is_task_stale_no_timestamp(self):
        """Test that tasks without timestamps are not considered stale"""
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = Path(tmpdir)

            # Create task without timestamp
            jot_file = tmpdir / '.jot.json'
            jot_file.write_text(
                json.dumps(
                    {
                        'tasks': [
                            {
                                'id': 1,
                                'text': 'legacy task',
                                'done': False,
                                'current': False,
                            }
                        ],
                        'archived': [],
                    }
                )
            )

            tm = TaskManager(storage_file='.jot.json', directory=tmpdir)
            task = tm.tasks[0]

            # Task without timestamp should not be considered stale
            assert tm.is_task_stale(task, stale_threshold_days=7) is False


class TestBulkOperations:
    """Tests for bulk operations and multi-select functionality"""

    def test_bulk_set_priority_multiple_tasks(self):
        """Test setting priority on multiple tasks at once"""
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = Path(tmpdir)

            tm = TaskManager(storage_file='.jot.json', directory=tmpdir)
            tm.add_task('task 1')
            tm.add_task('task 2')
            tm.add_task('task 3')

            task_ids = {tm.tasks[0]['id'], tm.tasks[1]['id'], tm.tasks[2]['id']}

            # Set all to high priority
            for task_id in task_ids:
                tm.set_task_priority(task_id, 'high')

            # Verify all tasks have high priority
            assert tm.tasks[0]['priority'] == 'high'
            assert tm.tasks[1]['priority'] == 'high'
            assert tm.tasks[2]['priority'] == 'high'

    def test_bulk_set_priority_mixed_existing_priorities(self):
        """Test bulk priority update overrides existing priorities"""
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = Path(tmpdir)

            tm = TaskManager(storage_file='.jot.json', directory=tmpdir)
            tm.add_task('task 1', priority='low')
            tm.add_task('task 2', priority='medium')
            tm.add_task('task 3', priority='none')

            task_ids = {tm.tasks[0]['id'], tm.tasks[1]['id'], tm.tasks[2]['id']}

            # Set all to high priority
            for task_id in task_ids:
                tm.set_task_priority(task_id, 'high')

            # Verify all now have high priority
            assert tm.tasks[0]['priority'] == 'high'
            assert tm.tasks[1]['priority'] == 'high'
            assert tm.tasks[2]['priority'] == 'high'

    def test_bulk_set_status_multiple_tasks(self):
        """Test setting status on multiple tasks at once"""
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = Path(tmpdir)

            tm = TaskManager(storage_file='.jot.json', directory=tmpdir)
            tm.add_task('task 1')
            tm.add_task('task 2')
            tm.add_task('task 3')

            task_ids = {tm.tasks[0]['id'], tm.tasks[1]['id'], tm.tasks[2]['id']}

            # Set all to in-progress
            for task_id in task_ids:
                tm.set_task_status(task_id, 'in-progress')

            # Verify all tasks have in-progress status
            assert tm.tasks[0]['status'] == 'in-progress'
            assert tm.tasks[1]['status'] == 'in-progress'
            assert tm.tasks[2]['status'] == 'in-progress'

            # Verify done field is not set
            assert tm.tasks[0]['done'] is False
            assert tm.tasks[1]['done'] is False
            assert tm.tasks[2]['done'] is False

    def test_bulk_set_status_to_done_syncs_done_field(self):
        """Test bulk status update to 'done' syncs done field"""
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = Path(tmpdir)

            tm = TaskManager(storage_file='.jot.json', directory=tmpdir)
            tm.add_task('task 1')
            tm.add_task('task 2')
            tm.add_task('task 3')

            task_ids = {tm.tasks[0]['id'], tm.tasks[1]['id'], tm.tasks[2]['id']}

            # Set all to done
            for task_id in task_ids:
                tm.set_task_status(task_id, 'done')

            # Verify all tasks have done status and done field set
            for task in tm.tasks:
                assert task['status'] == 'done'
                assert task['done'] is True

    def test_bulk_delete_multiple_tasks(self):
        """Test deleting multiple tasks"""
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = Path(tmpdir)

            tm = TaskManager(storage_file='.jot.json', directory=tmpdir)
            tm.add_task('task 1')
            tm.add_task('task 2')
            tm.add_task('task 3')
            tm.add_task('task 4')
            tm.add_task('task 5')

            # Get IDs of first 3 tasks
            task_ids = {tm.tasks[0]['id'], tm.tasks[1]['id'], tm.tasks[2]['id']}

            # Delete them
            for task_id in task_ids:
                tm.delete_task_permanently(task_id)

            # Verify only 2 tasks remain
            assert len(tm.tasks) == 2
            assert tm.tasks[0]['text'] == 'task 4'
            assert tm.tasks[1]['text'] == 'task 5'

    def test_bulk_delete_releases_ids(self):
        """Test bulk delete releases task IDs properly"""
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = Path(tmpdir)

            tm = TaskManager(storage_file='.jot.json', directory=tmpdir)
            tm.add_task('task 1')
            tm.add_task('task 2')
            tm.add_task('task 3')

            task_ids = [tm.tasks[0]['id'], tm.tasks[1]['id'], tm.tasks[2]['id']]

            # Delete all tasks
            for task_id in task_ids:
                tm.delete_task_permanently(task_id)

            # Verify IDs were released
            for task_id in task_ids:
                assert task_id not in tm.id_manager.allocated

    def test_bulk_archive_multiple_tasks(self):
        """Test archiving multiple tasks"""
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = Path(tmpdir)

            tm = TaskManager(storage_file='.jot.json', directory=tmpdir)
            tm.add_task('task 1')
            tm.add_task('task 2')
            tm.add_task('task 3')
            tm.add_task('task 4')

            # Get IDs of first 2 tasks
            task_ids = {tm.tasks[0]['id'], tm.tasks[1]['id']}

            # Archive them
            for task_id in task_ids:
                tm.archive_task(task_id)

            # Verify 2 tasks remain active
            assert len(tm.tasks) == 2

            # Verify 2 tasks are archived
            assert len(tm.archived) == 2

    def test_bulk_archive_preserves_metadata(self):
        """Test bulk archive preserves all task metadata"""
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = Path(tmpdir)

            tm = TaskManager(storage_file='.jot.json', directory=tmpdir)
            tm.add_task('task 1', priority='high', status='in-progress')
            tm.add_task('task 2', priority='medium', status='blocked')

            # Set additional metadata
            tm.set_task_day(tm.tasks[0]['id'], 'Monday')
            tm.set_task_day(tm.tasks[1]['id'], 'Friday')

            task_ids = {tm.tasks[0]['id'], tm.tasks[1]['id']}

            # Archive both
            for task_id in task_ids:
                tm.archive_task(task_id)

            # Verify metadata preserved in archived tasks
            assert tm.archived[0]['priority'] == 'high'
            assert tm.archived[0]['status'] == 'in-progress'
            assert tm.archived[0]['day'] == 'Monday'

            assert tm.archived[1]['priority'] == 'medium'
            assert tm.archived[1]['status'] == 'blocked'
            assert tm.archived[1]['day'] == 'Friday'

    def test_bulk_operations_on_empty_selection(self):
        """Test bulk operations handle empty selections gracefully"""
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = Path(tmpdir)

            tm = TaskManager(storage_file='.jot.json', directory=tmpdir)
            tm.add_task('task 1')

            # Try operations on empty set
            empty_set = set()

            # Should not crash or modify anything
            for task_id in empty_set:
                tm.set_task_priority(task_id, 'high')

            # Task should remain unchanged
            assert tm.tasks[0]['priority'] == 'none'

    def test_bulk_operations_on_single_task(self):
        """Test bulk operations work correctly on single task"""
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = Path(tmpdir)

            tm = TaskManager(storage_file='.jot.json', directory=tmpdir)
            tm.add_task('task 1')

            task_id = tm.tasks[0]['id']
            single_task_set = {task_id}

            # Set priority on single task via bulk operation
            for tid in single_task_set:
                tm.set_task_priority(tid, 'high')

            assert tm.tasks[0]['priority'] == 'high'

    def test_bulk_operations_update_timestamps(self):
        """Test bulk operations update updated_at timestamps"""
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = Path(tmpdir)
            import time

            tm = TaskManager(storage_file='.jot.json', directory=tmpdir)
            tm.add_task('task 1')
            tm.add_task('task 2')

            initial_timestamps = [
                tm.tasks[0]['updated_at'],
                tm.tasks[1]['updated_at'],
            ]

            time.sleep(0.01)  # Ensure timestamp changes

            task_ids = {tm.tasks[0]['id'], tm.tasks[1]['id']}

            # Update priority
            for task_id in task_ids:
                tm.set_task_priority(task_id, 'high')

            # Verify timestamps changed
            assert tm.tasks[0]['updated_at'] != initial_timestamps[0]
            assert tm.tasks[1]['updated_at'] != initial_timestamps[1]

    def test_bulk_priority_and_status_combination(self):
        """Test setting both priority and status on multiple tasks"""
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = Path(tmpdir)

            tm = TaskManager(storage_file='.jot.json', directory=tmpdir)
            tm.add_task('task 1')
            tm.add_task('task 2')
            tm.add_task('task 3')

            task_ids = {tm.tasks[0]['id'], tm.tasks[1]['id'], tm.tasks[2]['id']}

            # Set priority first
            for task_id in task_ids:
                tm.set_task_priority(task_id, 'high')

            # Then set status
            for task_id in task_ids:
                tm.set_task_status(task_id, 'in-progress')

            # Verify both are set
            for task in tm.tasks:
                assert task['priority'] == 'high'
                assert task['status'] == 'in-progress'

    def test_bulk_operations_persist_across_reload(self):
        """Test bulk operations persist when reloading TaskManager"""
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = Path(tmpdir)

            # Create and modify tasks
            tm = TaskManager(storage_file='.jot.json', directory=tmpdir)
            tm.add_task('task 1')
            tm.add_task('task 2')

            task_ids = {tm.tasks[0]['id'], tm.tasks[1]['id']}

            for task_id in task_ids:
                tm.set_task_priority(task_id, 'high')
                tm.set_task_status(task_id, 'in-progress')

            # Reload TaskManager
            tm2 = TaskManager(storage_file='.jot.json', directory=tmpdir)

            # Verify changes persisted
            assert tm2.tasks[0]['priority'] == 'high'
            assert tm2.tasks[0]['status'] == 'in-progress'
            assert tm2.tasks[1]['priority'] == 'high'
            assert tm2.tasks[1]['status'] == 'in-progress'

    def test_bulk_delete_all_tasks(self):
        """Test deleting all tasks leaves empty list"""
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = Path(tmpdir)

            tm = TaskManager(storage_file='.jot.json', directory=tmpdir)
            tm.add_task('task 1')
            tm.add_task('task 2')
            tm.add_task('task 3')

            task_ids = [task['id'] for task in tm.tasks]

            # Delete all
            for task_id in task_ids:
                tm.delete_task_permanently(task_id)

            # Verify empty
            assert len(tm.tasks) == 0

    def test_bulk_archive_all_tasks(self):
        """Test archiving all tasks"""
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = Path(tmpdir)

            tm = TaskManager(storage_file='.jot.json', directory=tmpdir)
            tm.add_task('task 1')
            tm.add_task('task 2')
            tm.add_task('task 3')

            task_ids = [task['id'] for task in tm.tasks]

            # Archive all
            for task_id in task_ids:
                tm.archive_task(task_id)

            # Verify all archived
            assert len(tm.tasks) == 0
            assert len(tm.archived) == 3

    def test_bulk_operations_with_mixed_task_states(self):
        """Test bulk operations on tasks with different initial states"""
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = Path(tmpdir)

            tm = TaskManager(storage_file='.jot.json', directory=tmpdir)
            tm.add_task('task 1', priority='none', status='todo')
            tm.add_task('task 2', priority='high', status='done')
            tm.add_task('task 3', priority='low', status='blocked')

            task_ids = {tm.tasks[0]['id'], tm.tasks[1]['id'], tm.tasks[2]['id']}

            # Set all to medium priority
            for task_id in task_ids:
                tm.set_task_priority(task_id, 'medium')

            # Verify all now medium, regardless of initial state
            for task in tm.tasks:
                assert task['priority'] == 'medium'


class TestGoogleCalendarImport:
    """Tests for Google Calendar import functionality"""

    def test_fetch_gcal_events_with_timed_events(self):
        """Test fetching timed calendar events"""
        from datetime import datetime
        from unittest.mock import Mock
        from jot import fetch_gcal_events

        # Mock the service
        mock_service = Mock()
        mock_events = Mock()
        mock_list = Mock()

        mock_service.events.return_value = mock_events
        mock_events.list.return_value = mock_list
        mock_list.execute.return_value = {
            'items': [
                {
                    'summary': 'Morning Standup',
                    'start': {'dateTime': '2025-01-15T09:00:00-05:00'},
                    'end': {'dateTime': '2025-01-15T09:30:00-05:00'},
                },
                {
                    'summary': 'Team Lunch',
                    'start': {'dateTime': '2025-01-15T12:00:00-05:00'},
                    'end': {'dateTime': '2025-01-15T13:00:00-05:00'},
                },
            ]
        }

        # Fetch events
        events = fetch_gcal_events(mock_service, datetime(2025, 1, 15).date())

        # Verify we got 2 events
        assert len(events) == 2

        # Verify first event
        assert events[0]['summary'] == 'Morning Standup'
        assert events[0]['all_day'] is False
        assert events[0]['start'] is not None
        assert events[0]['end'] is not None

        # Verify second event
        assert events[1]['summary'] == 'Team Lunch'
        assert events[1]['all_day'] is False

    def test_fetch_gcal_events_with_all_day_events(self):
        """Test fetching all-day calendar events"""
        from datetime import datetime
        from unittest.mock import Mock
        from jot import fetch_gcal_events

        # Mock the service
        mock_service = Mock()
        mock_events = Mock()
        mock_list = Mock()

        mock_service.events.return_value = mock_events
        mock_events.list.return_value = mock_list
        mock_list.execute.return_value = {
            'items': [
                {
                    'summary': 'Team Offsite',
                    'start': {'date': '2025-01-15'},
                    'end': {'date': '2025-01-16'},
                }
            ]
        }

        # Fetch events
        events = fetch_gcal_events(mock_service, datetime(2025, 1, 15).date())

        # Verify all-day event
        assert len(events) == 1
        assert events[0]['summary'] == 'Team Offsite'
        assert events[0]['all_day'] is True
        assert events[0]['start'] is None
        assert events[0]['end'] is None

    def test_fetch_gcal_events_empty(self):
        """Test fetching when no events exist"""
        from datetime import datetime
        from unittest.mock import Mock
        from jot import fetch_gcal_events

        # Mock the service
        mock_service = Mock()
        mock_events = Mock()
        mock_list = Mock()

        mock_service.events.return_value = mock_events
        mock_events.list.return_value = mock_list
        mock_list.execute.return_value = {'items': []}

        # Fetch events
        events = fetch_gcal_events(mock_service, datetime(2025, 1, 15).date())

        # Verify empty list
        assert len(events) == 0

    def test_fetch_gcal_events_mixed(self):
        """Test fetching mix of timed and all-day events"""
        from datetime import datetime
        from unittest.mock import Mock
        from jot import fetch_gcal_events

        # Mock the service
        mock_service = Mock()
        mock_events = Mock()
        mock_list = Mock()

        mock_service.events.return_value = mock_events
        mock_events.list.return_value = mock_list
        mock_list.execute.return_value = {
            'items': [
                {
                    'summary': 'Conference Day',
                    'start': {'date': '2025-01-15'},
                    'end': {'date': '2025-01-16'},
                },
                {
                    'summary': '1:1 Meeting',
                    'start': {'dateTime': '2025-01-15T14:00:00-05:00'},
                    'end': {'dateTime': '2025-01-15T14:30:00-05:00'},
                },
                {
                    'summary': 'Code Review',
                    'start': {'dateTime': '2025-01-15T16:00:00-05:00'},
                    'end': {'dateTime': '2025-01-15T17:00:00-05:00'},
                },
            ]
        }

        # Fetch events
        events = fetch_gcal_events(mock_service, datetime(2025, 1, 15).date())

        # Verify 3 events with correct types
        assert len(events) == 3
        assert events[0]['all_day'] is True  # Conference Day
        assert events[1]['all_day'] is False  # 1:1 Meeting
        assert events[2]['all_day'] is False  # Code Review

    def test_fetch_gcal_events_no_title(self):
        """Test fetching events with missing title"""
        from datetime import datetime
        from unittest.mock import Mock
        from jot import fetch_gcal_events

        # Mock the service
        mock_service = Mock()
        mock_events = Mock()
        mock_list = Mock()

        mock_service.events.return_value = mock_events
        mock_events.list.return_value = mock_list
        mock_list.execute.return_value = {
            'items': [
                {
                    # No 'summary' field
                    'start': {'dateTime': '2025-01-15T10:00:00-05:00'},
                    'end': {'dateTime': '2025-01-15T11:00:00-05:00'},
                }
            ]
        }

        # Fetch events
        events = fetch_gcal_events(mock_service, datetime(2025, 1, 15).date())

        # Verify default title is used
        assert len(events) == 1
        assert events[0]['summary'] == '(No title)'


class TestTTSConfiguration:
    """Test TTS configuration management"""

    def test_default_tts_config(self, tmpdir):
        """Verify default TTS configuration values when no config exists"""
        tmpdir = Path(tmpdir)
        cat_config = CategoryConfig(project_dir=tmpdir)

        config = cat_config.get_tts_config()

        assert config['enabled'] is True
        assert config['rate'] == 150
        assert config['volume'] == 0.9
        assert config['voice'] is None

    def test_set_tts_config_single_values(self, tmpdir):
        """Test setting individual TTS configuration values"""
        tmpdir = Path(tmpdir)
        cat_config = CategoryConfig(project_dir=tmpdir)

        # Test setting enabled
        cat_config.set_tts_config(enabled=False)
        config = cat_config.get_tts_config()
        assert config['enabled'] is False

        # Test setting rate
        cat_config.set_tts_config(rate=200)
        config = cat_config.get_tts_config()
        assert config['rate'] == 200

        # Test setting volume
        cat_config.set_tts_config(volume=0.5)
        config = cat_config.get_tts_config()
        assert config['volume'] == 0.5

        # Test setting voice
        cat_config.set_tts_config(voice='Alex')
        config = cat_config.get_tts_config()
        assert config['voice'] == 'Alex'

    def test_set_tts_config_multiple_values(self, tmpdir):
        """Test setting multiple TTS values in a single call"""
        tmpdir = Path(tmpdir)
        cat_config = CategoryConfig(project_dir=tmpdir)

        cat_config.set_tts_config(enabled=False, rate=180, volume=0.7, voice='Samantha')
        config = cat_config.get_tts_config()

        assert config['enabled'] is False
        assert config['rate'] == 180
        assert config['volume'] == 0.7
        assert config['voice'] == 'Samantha'

    def test_tts_config_persistence(self, tmpdir):
        """Verify TTS configuration persists across CategoryConfig instances"""
        tmpdir = Path(tmpdir)

        # First instance: set config
        cat_config1 = CategoryConfig(project_dir=tmpdir)
        cat_config1.set_tts_config(enabled=False, rate=180, volume=0.7)

        # Second instance: verify config persists
        cat_config2 = CategoryConfig(project_dir=tmpdir)
        config = cat_config2.get_tts_config()

        assert config['enabled'] is False
        assert config['rate'] == 180
        assert config['volume'] == 0.7

    def test_tts_config_file_creation(self, tmpdir):
        """Verify that .jot.config.json file is created when setting TTS config"""
        tmpdir = Path(tmpdir)
        config_file = tmpdir / '.jot.config.json'

        # Verify file doesn't exist initially
        assert not config_file.exists()

        # Set TTS config
        cat_config = CategoryConfig(project_dir=tmpdir)
        cat_config.set_tts_config(rate=200)

        # Verify file now exists
        assert config_file.exists()

        # Load and verify JSON structure
        with open(config_file, 'r') as f:
            data = json.load(f)

        assert 'tts' in data
        assert data['tts']['rate'] == 200
        assert data['tts']['enabled'] is True
        assert data['tts']['volume'] == 0.9
        assert data['tts']['voice'] is None

    def test_tts_config_preserves_other_config(self, tmpdir):
        """Ensure TTS config doesn't overwrite other configuration like colors"""
        tmpdir = Path(tmpdir)
        cat_config = CategoryConfig(project_dir=tmpdir)

        # Set a color
        cat_config.set_color('features', 'blue')

        # Set TTS config
        cat_config.set_tts_config(rate=175)

        # Verify both configs exist
        tts_config = cat_config.get_tts_config()
        assert tts_config['rate'] == 175

        colors = cat_config.get_all_colors()
        assert colors['features'] == 'blue'

    def test_set_tts_config_ignores_invalid_keys(self, tmpdir):
        """Test that invalid keys are ignored when setting TTS config"""
        tmpdir = Path(tmpdir)
        cat_config = CategoryConfig(project_dir=tmpdir)

        # Set config with valid and invalid keys
        cat_config.set_tts_config(enabled=False, invalid_key='value', rate=200)

        config = cat_config.get_tts_config()

        # Verify valid keys were updated
        assert config['enabled'] is False
        assert config['rate'] == 200

        # Verify invalid key is not in config
        assert 'invalid_key' not in config

    def test_tts_config_partial_updates(self, tmpdir):
        """Verify partial updates don't reset other values to defaults"""
        tmpdir = Path(tmpdir)
        cat_config = CategoryConfig(project_dir=tmpdir)

        # Set all values
        cat_config.set_tts_config(enabled=False, rate=200, volume=0.5, voice='Alex')

        # Update only rate
        cat_config.set_tts_config(rate=180)

        # Verify other values weren't reset
        config = cat_config.get_tts_config()
        assert config['enabled'] is False  # Not reset to True
        assert config['rate'] == 180  # Updated
        assert config['volume'] == 0.5  # Not reset
        assert config['voice'] == 'Alex'  # Not reset

    def test_set_tts_config_return_value(self, tmpdir):
        """Verify set_tts_config returns True on success"""
        tmpdir = Path(tmpdir)
        cat_config = CategoryConfig(project_dir=tmpdir)

        result = cat_config.set_tts_config(rate=180)

        assert result is True

    def test_tts_config_with_boundary_values(self, tmpdir):
        """Test configuration with boundary/edge case values"""
        tmpdir = Path(tmpdir)
        cat_config = CategoryConfig(project_dir=tmpdir)

        # Test minimum volume
        cat_config.set_tts_config(volume=0.0)
        config = cat_config.get_tts_config()
        assert config['volume'] == 0.0

        # Test maximum volume
        cat_config.set_tts_config(volume=1.0)
        config = cat_config.get_tts_config()
        assert config['volume'] == 1.0

        # Test slow speech rate
        cat_config.set_tts_config(rate=50)
        config = cat_config.get_tts_config()
        assert config['rate'] == 50

        # Test fast speech rate
        cat_config.set_tts_config(rate=300)
        config = cat_config.get_tts_config()
        assert config['rate'] == 300

    def test_tts_config_json_structure(self, tmpdir):
        """Verify the JSON structure in .jot.config.json is correct"""
        tmpdir = Path(tmpdir)
        cat_config = CategoryConfig(project_dir=tmpdir)

        # Set TTS config
        cat_config.set_tts_config(enabled=False, rate=175, volume=0.8, voice='Karen')

        # Directly read config file
        config_file = tmpdir / '.jot.config.json'
        with open(config_file, 'r') as f:
            data = json.load(f)

        # Verify structure
        assert 'tts' in data
        assert isinstance(data['tts'], dict)
        assert data['tts']['enabled'] is False
        assert data['tts']['rate'] == 175
        assert data['tts']['volume'] == 0.8
        assert data['tts']['voice'] == 'Karen'


class TestCategoryConfigColors:
    """Test category color management"""

    @pytest.fixture
    def cat_config(self, tmpdir):
        """Create CategoryConfig instance for testing"""
        from jot import CategoryConfig

        return CategoryConfig(project_dir=tmpdir)

    def test_get_default_color_for_known_category(self, cat_config):
        """Verify default colors for known categories"""
        # Test some well-known categories
        features_color = cat_config.get_color('features')
        bugs_color = cat_config.get_color('bugs')
        docs_color = cat_config.get_color('docs')

        # Should get specific ANSI color codes
        assert features_color == cat_config.COLORS['green']
        assert bugs_color == cat_config.COLORS['red']
        assert docs_color == cat_config.COLORS['blue']

    def test_get_color_for_unknown_local_category(self, cat_config):
        """Verify unknown local categories get cyan"""
        color = cat_config.get_color('unknown-category', for_global=False)

        assert color == cat_config.COLORS['cyan']

    def test_get_color_for_global_category(self, cat_config):
        """Verify global categories get magenta"""
        color = cat_config.get_color('some-global', for_global=True)

        assert color == cat_config.COLORS['magenta']

    def test_set_custom_color(self, cat_config):
        """Verify setting custom color for a category"""
        success, message = cat_config.set_color('my-category', 'purple')

        assert success is True
        assert 'purple' in message

        # Verify color was saved
        color = cat_config.get_color('my-category')
        assert color == cat_config.COLORS['purple']

    def test_set_invalid_color(self, cat_config):
        """Verify invalid color names are rejected"""
        success, message = cat_config.set_color('my-category', 'invalid-color')

        assert success is False
        assert 'Invalid color' in message
        assert 'Available:' in message

    def test_custom_color_overrides_default(self, cat_config):
        """Verify custom colors override defaults"""
        # 'bugs' defaults to red
        cat_config.set_color('bugs', 'green')

        color = cat_config.get_color('bugs')

        assert color == cat_config.COLORS['green']  # Not red anymore

    def test_get_all_colors(self, cat_config):
        """Verify retrieving all configured colors"""
        cat_config.set_color('cat1', 'red')
        cat_config.set_color('cat2', 'blue')

        colors = cat_config.get_all_colors()

        assert 'cat1' in colors
        assert 'cat2' in colors
        assert colors['cat1'] == 'red'
        assert colors['cat2'] == 'blue'

    def test_reset_colors(self, cat_config):
        """Verify resetting all custom colors"""
        # Set some custom colors
        cat_config.set_color('cat1', 'red')
        cat_config.set_color('cat2', 'blue')

        # Reset
        result = cat_config.reset_colors()

        assert result is True
        assert len(cat_config.get_all_colors()) == 0

    def test_list_available_colors(self, cat_config):
        """Verify listing all available color names"""
        colors = cat_config.list_available_colors()

        # Should be sorted
        assert colors == sorted(colors)

        # Should include standard colors
        assert 'red' in colors
        assert 'green' in colors
        assert 'blue' in colors
        assert 'purple' in colors
        assert 'cyan' in colors

    def test_color_persistence(self, tmpdir):
        """Verify colors persist across instances"""
        from jot import CategoryConfig

        # First instance - set colors
        config1 = CategoryConfig(project_dir=tmpdir)
        config1.set_color('test-cat', 'yellow')

        # Second instance - should load from file
        config2 = CategoryConfig(project_dir=tmpdir)
        color = config2.get_color('test-cat')

        assert color == config2.COLORS['yellow']

    def test_corrupted_config_handled_gracefully(self, tmpdir):
        """Verify corrupted config file doesn't crash"""
        from jot import CategoryConfig

        # Create corrupted config file
        config_file = Path(tmpdir) / '.jot.config.json'
        config_file.write_text("{ invalid json }")

        # Should handle gracefully
        config = CategoryConfig(project_dir=tmpdir)

        # Should still work with defaults
        color = config.get_color('bugs')
        assert color == config.COLORS['red']


class TestKeywordHandler:
    """Test keyword detection and action routing"""

    @pytest.fixture
    def keyword_handler(self, tmpdir):
        """Create a KeywordHandler instance for testing"""
        # Import here to avoid circular dependencies
        from jot import KeywordHandler

        return KeywordHandler()

    def test_extract_keyword_with_valid_keyword(self, keyword_handler):
        """Verify keyword extraction from task text"""
        keyword, text, project_name = keyword_handler.extract_keyword("gcal: Team meeting")

        assert keyword == "gcal"
        assert text == "gcal: Team meeting"  # Original text unchanged
        assert project_name is None  # No project routing

    def test_extract_keyword_case_insensitive(self, keyword_handler):
        """Verify keywords are normalized to lowercase"""
        keyword, text, project_name = keyword_handler.extract_keyword("BULLET: Focus session")

        assert keyword == "bullet"  # Normalized
        assert text == "BULLET: Focus session"  # Original preserved
        assert project_name is None

    def test_extract_keyword_with_no_keyword(self, keyword_handler):
        """Verify tasks without keywords return None"""
        keyword, text, project_name = keyword_handler.extract_keyword("Regular task")

        assert keyword is None
        assert text == "Regular task"
        assert project_name is None

    def test_extract_keyword_with_invalid_characters(self, keyword_handler):
        """Verify invalid keyword formats are rejected"""
        # Test various invalid formats
        invalid_keywords = [
            "@mention: task",  # Special characters
            "#hashtag: task",  # Hash symbol
            "keyword!: task",  # Exclamation
            "key word: task",  # Space in keyword
        ]

        for task_text in invalid_keywords:
            keyword, text, project_name = keyword_handler.extract_keyword(task_text)
            assert keyword is None
            assert text == task_text
            assert project_name is None

    def test_extract_keyword_with_hyphens_and_underscores(self, keyword_handler):
        """Verify hyphens and underscores are allowed in keywords"""
        keyword1, _, _ = keyword_handler.extract_keyword("my-keyword: task")
        keyword2, _, _ = keyword_handler.extract_keyword("my_keyword: task")

        assert keyword1 == "my-keyword"
        assert keyword2 == "my_keyword"

    def test_extract_keyword_max_length_security(self, keyword_handler):
        """Verify excessively long keywords are rejected (DoS prevention)"""
        long_keyword = "a" * 51  # MAX_KEYWORD_LENGTH is 50
        task_text = f"{long_keyword}: task"

        keyword, text, project_name = keyword_handler.extract_keyword(task_text)

        assert keyword is None
        assert text == task_text
        assert project_name is None

    def test_extract_keyword_with_multiple_colons(self, keyword_handler):
        """Verify only first colon is used for keyword detection"""
        keyword, text, project_name = keyword_handler.extract_keyword("gcal: Meeting: Discussion")

        assert keyword == "gcal"
        assert text == "gcal: Meeting: Discussion"
        assert project_name is None

    def test_register_keyword(self, keyword_handler):
        """Verify keyword registration"""

        def custom_handler(task):
            return "Custom handler executed"

        keyword_handler.register("custom", custom_handler, auto_trigger=True, description="Test")

        # Verify registration
        assert "custom" in keyword_handler.handlers
        assert "custom" in keyword_handler.config
        assert keyword_handler.config["custom"]["auto_trigger"] is True
        assert keyword_handler.config["custom"]["description"] == "Test"

    def test_register_keyword_case_normalization(self, keyword_handler):
        """Verify keywords are normalized to lowercase on registration"""

        def handler(task):
            return "OK"

        keyword_handler.register("MyKeyword", handler)

        assert "mykeyword" in keyword_handler.handlers
        assert "MyKeyword" not in keyword_handler.handlers

    def test_handle_registered_keyword(self, keyword_handler):
        """Verify registered keyword handler execution"""

        def test_handler(task):
            return f"Handled task: {task['text']}"

        keyword_handler.register("test", test_handler)

        task = {"id": 1, "text": "test: sample task"}
        result = keyword_handler.handle("test", task)

        assert result == "Handled task: test: sample task"

    def test_handle_unregistered_keyword(self, keyword_handler):
        """Verify unknown keywords return None (silent failure)"""
        task = {"id": 1, "text": "unknown: task"}
        result = keyword_handler.handle("unknown", task)

        assert result is None

    def test_handle_with_exception(self, keyword_handler):
        """Verify error handling when handler raises exception"""

        def failing_handler(task):
            raise ValueError("Test error")

        keyword_handler.register("fail", failing_handler)

        task = {"id": 1, "text": "fail: task"}
        result = keyword_handler.handle("fail", task)

        assert "Error executing fail:" in result
        assert "Test error" in result

    def test_get_config(self, keyword_handler):
        """Verify retrieving keyword configuration"""
        keyword_handler.register("test", lambda t: "OK", auto_trigger=False, description="Test")

        config = keyword_handler.get_config("test")

        assert config is not None
        assert config["auto_trigger"] is False
        assert config["description"] == "Test"

    def test_get_config_case_insensitive(self, keyword_handler):
        """Verify config lookup is case-insensitive"""
        keyword_handler.register("test", lambda t: "OK")

        config = keyword_handler.get_config("TEST")

        assert config is not None

    def test_list_keywords(self, keyword_handler):
        """Verify listing all registered keywords"""
        keywords = keyword_handler.list_keywords()

        # Should include built-in keywords
        assert "bullet" in keywords
        assert "gcal" in keywords
        assert "ai" in keywords
        assert "remind" in keywords
        assert "analyze" in keywords

        # Each should have config
        for keyword, config in keywords.items():
            assert "auto_trigger" in config
            assert "description" in config

    def test_builtin_keywords_registered(self, keyword_handler):
        """Verify all built-in keywords are registered"""
        required_keywords = ["bullet", "gcal", "ai", "remind", "analyze"]

        for keyword in required_keywords:
            assert keyword in keyword_handler.handlers
            assert keyword in keyword_handler.config


class TestImportIntegrity:
    """Post-refactor import integrity tests.

    Ensures all modules have required imports and key features
    don't crash with NameError at runtime.
    """

    def test_task_manager_imports(self):
        """TaskManager module has all required imports (sys, re, uuid, etc.)"""
        import jot.core.task_manager as mod
        assert hasattr(mod, 'sys')
        assert hasattr(mod, 're')
        assert hasattr(mod, 'json')
        assert hasattr(mod, 'uuid')
        assert hasattr(mod, 'Counter')

    def test_command_handler_imports(self):
        """CommandHandler mixin modules have all required imports"""
        import jot.commands._web_clipboard_mixin as web_mod
        import jot.commands._ai_analysis_mixin as ai_mod
        import jot.commands._core_mixin as core_mod
        assert hasattr(web_mod, 'webbrowser')
        assert hasattr(web_mod, 'urllib')
        assert hasattr(ai_mod, 'uuid')
        assert hasattr(core_mod, 'Counter')

    def test_keyword_handler_imports(self):
        """KeywordHandler mixin modules have all required imports"""
        import jot.integrations.keywords._handlers_mixin as mod
        assert hasattr(mod, 'json')
        assert hasattr(mod, 'subprocess')

    def test_category_templates_importable(self):
        """CategoryTemplates class exists and is importable"""
        from jot.categories.templates import CategoryTemplates
        ct = CategoryTemplates()
        templates = ct.list_templates()
        assert len(templates) > 0
        assert 'software-dev' in templates

    def test_category_templates_apply(self):
        """CategoryTemplates can apply a template"""
        from jot.categories.templates import CategoryTemplates
        with tempfile.TemporaryDirectory() as tmpdir:
            ct = CategoryTemplates(project_dir=tmpdir)
            success, msg = ct.apply_template('software-dev')
            assert success is True
            assert 'Created 4 categories' in msg

    def test_category_templates_invalid(self):
        """CategoryTemplates rejects invalid template name"""
        from jot.categories.templates import CategoryTemplates
        ct = CategoryTemplates()
        success, msg = ct.apply_template('nonexistent-template')
        assert success is False

    def test_webbrowser_open_url_no_crash(self):
        """open_url method can be called without NameError"""
        from jot.commands.handler import CommandHandler
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = Path(tmpdir)
            jot_file = tmpdir / '.jot.json'
            jot_file.write_text(json.dumps({
                'tasks': [{'id': 1, 'text': 'no url here', 'done': False,
                           'current': True}],
                'archived': [],
            }))
            tm = TaskManager(directory=tmpdir)
            ch = CommandHandler(tm)
            # Should print "No URLs found" but NOT raise NameError
            result = ch.open_url()
            assert result is True

    def test_web_search_no_crash(self):
        """web_search method doesn't crash on urllib.parse import"""
        import jot.commands._web_clipboard_mixin as mod
        # Verify urllib.parse is available in the module
        assert hasattr(mod.urllib, 'parse')
        assert callable(mod.urllib.parse.quote_plus)

    def test_uuid_available_in_handler(self):
        """uuid module available for session tracking in analysis mixin"""
        import jot.commands._ai_analysis_mixin as mod
        assert callable(mod.uuid.uuid4)
        assert callable(mod.uuid.uuid5)

    def test_sys_stderr_in_task_manager(self):
        """sys.stderr available for warning output in TaskManager"""
        import jot.core.task_manager as mod
        assert hasattr(mod.sys, 'stderr')

    def test_keyword_all_broadcast(self):
        """'all:' keyword returns __all__ sentinel for broadcast"""
        from jot.integrations.keywords.handler import KeywordHandler
        kh = KeywordHandler()
        keyword, text, project = kh.extract_keyword('all: Test task')
        assert keyword is None
        assert text == 'Test task'
        assert project == '__all__'

    def test_subtask_sync_no_duplicates(self):
        """sync_subtasks_from_notes prevents duplicates on re-sync"""
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = Path(tmpdir)
            jot_file = tmpdir / '.jot.json'
            jot_file.write_text(json.dumps({
                'tasks': [], 'archived': [],
            }))
            ids_file = tmpdir / '.jot.ids.json'
            ids_file.write_text(json.dumps({
                'next_id': 1, 'allocated': [],
            }))

            tm = TaskManager(directory=tmpdir)
            tm.add_task('Parent task')
            parent_id = tm.tasks[0]['id']

            tm.set_task_notes(parent_id,
                              '- [ ] sub one\n- [ ] sub two\n- [X] sub done')

            # First sync — checked item skipped (#578)
            r1 = tm.sync_subtasks_from_notes(parent_id)
            assert r1['created'] == 2
            assert r1['total'] == 3
            assert len(tm.tasks) == 3

            # Second sync — no duplicates
            r2 = tm.sync_subtasks_from_notes(parent_id)
            assert r2['created'] == 0
            assert r2['updated'] == 0
            assert len(tm.tasks) == 3

    def test_subtask_sync_status_update(self):
        """sync_subtasks_from_notes updates status when checkbox changes"""
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = Path(tmpdir)
            jot_file = tmpdir / '.jot.json'
            jot_file.write_text(json.dumps({
                'tasks': [], 'archived': [],
            }))
            ids_file = tmpdir / '.jot.ids.json'
            ids_file.write_text(json.dumps({
                'next_id': 1, 'allocated': [],
            }))

            tm = TaskManager(directory=tmpdir)
            tm.add_task('Parent')
            pid = tm.tasks[0]['id']

            tm.set_task_notes(pid, '- [ ] task one')
            tm.sync_subtasks_from_notes(pid)

            sub = [t for t in tm.tasks if f'parent:{pid}' in t.get('labels', [])][0]
            assert sub['status'] == 'todo'

            # Check the box
            tm.set_task_notes(pid, '- [X] task one')
            r = tm.sync_subtasks_from_notes(pid)
            assert r['updated'] == 1

            sub = [t for t in tm.tasks if f'parent:{pid}' in t.get('labels', [])][0]
            assert sub['status'] == 'done'

    def test_broadcast_all_projects(self):
        """--all broadcast creates tasks in multiple projects"""
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = Path(tmpdir)

            # Create two project directories
            proj_a = tmpdir / 'proj-a'
            proj_b = tmpdir / 'proj-b'
            proj_a.mkdir()
            proj_b.mkdir()

            for proj in [proj_a, proj_b]:
                (proj / '.jot.json').write_text(
                    json.dumps({'tasks': [], 'archived': []}))
                (proj / '.jot.ids.json').write_text(
                    json.dumps({'next_id': 1, 'allocated': []}))

            # Pre-create empty registry to prevent auto-discover
            # from loading real ~/projects into the test registry
            reg_file = tmpdir / '.jot-projects.json'
            reg_file.write_text('{}')
            registry = ProjectRegistry(
                registry_file=str(reg_file))
            registry.register_project('proj-a', str(proj_a))
            registry.register_project('proj-b', str(proj_b))

            # Broadcast a task
            for proj_name, proj_path in registry.list_projects().items():
                tm = TaskManager(directory=proj_path, project_registry=registry)
                tm.add_task('broadcast test')

            # Verify both projects got the task
            for proj in [proj_a, proj_b]:
                data = json.loads((proj / '.jot.json').read_text())
                texts = [t['text'] for t in data['tasks']]
                assert 'broadcast test' in texts

    def test_cli_broadcast_requires_confirmation(self):
        """CLI --all broadcast requires y confirmation, N cancels"""
        from unittest.mock import patch
        import importlib.util
        spec = importlib.util.spec_from_file_location(
            "jot_main", str(Path(__file__).parent.parent / "jot.py"))
        jot_main = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(jot_main)
        _handle_initial_task = jot_main._handle_initial_task

        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = Path(tmpdir)
            proj = tmpdir / 'proj'
            proj.mkdir()
            (proj / '.jot.json').write_text(
                json.dumps({'tasks': [], 'archived': []}))
            (proj / '.jot.ids.json').write_text(
                json.dumps({'next_id': 1, 'allocated': []}))

            reg_file = tmpdir / '.jot-projects.json'
            reg_file.write_text('{}')
            registry = ProjectRegistry(registry_file=str(reg_file))
            registry.register_project('proj', str(proj))

            tm = TaskManager(directory=proj, project_registry=registry)

            # Declining should NOT add any tasks
            with patch('builtins.input', return_value='n'):
                _handle_initial_task(
                    tm, 'test task', True,
                    registry, None, False, None)

            data = json.loads((proj / '.jot.json').read_text())
            assert len(data['tasks']) == 0

    def test_add_task_normal_returns_id(self):
        """Normal add_task returns an integer task ID"""
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = Path(tmpdir)
            (tmpdir / '.jot.json').write_text(
                json.dumps({'tasks': [], 'archived': []}))
            (tmpdir / '.jot.ids.json').write_text(
                json.dumps({'next_id': 1, 'allocated': []}))
            tm = TaskManager(directory=tmpdir)
            result = tm.add_task('normal task')
            assert isinstance(result, int)

    def test_add_task_broadcast_returns_info_dict(self):
        """add_task with 'all:' prefix returns broadcast metadata"""
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = Path(tmpdir)
            (tmpdir / '.jot.json').write_text(
                json.dumps({'tasks': [], 'archived': []}))
            (tmpdir / '.jot.ids.json').write_text(
                json.dumps({'next_id': 1, 'allocated': []}))
            reg_file = tmpdir / '.jot-projects.json'
            reg_file.write_text('{}')
            registry = ProjectRegistry(
                registry_file=str(reg_file))
            registry.register_project('proj-a', str(tmpdir))
            tm = TaskManager(directory=tmpdir, project_registry=registry)
            result = tm.add_task('all: broadcast task')
            assert isinstance(result, dict)
            assert result['action'] == 'broadcast'
            assert result['task_text'] == 'broadcast task'
            assert result['project_name'] == '__all__'
            # Task should NOT have been added yet (awaiting confirmation)
            assert len(tm.tasks) == 0

    def test_add_task_route_returns_info_dict(self):
        """add_task with project prefix returns route metadata"""
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = Path(tmpdir)
            proj_a = tmpdir / 'proj-a'
            proj_a.mkdir()
            (proj_a / '.jot.json').write_text(
                json.dumps({'tasks': [], 'archived': []}))
            (proj_a / '.jot.ids.json').write_text(
                json.dumps({'next_id': 1, 'allocated': []}))
            (tmpdir / '.jot.json').write_text(
                json.dumps({'tasks': [], 'archived': []}))
            (tmpdir / '.jot.ids.json').write_text(
                json.dumps({'next_id': 1, 'allocated': []}))
            reg_file = tmpdir / '.jot-projects.json'
            reg_file.write_text('{}')
            registry = ProjectRegistry(
                registry_file=str(reg_file))
            registry.register_project('proj-a', str(proj_a))
            tm = TaskManager(directory=tmpdir, project_registry=registry)
            result = tm.add_task('proj-a: routed task')
            assert isinstance(result, dict)
            assert result['action'] == 'route'
            assert result['task_text'] == 'routed task'
            assert result['project_name'] == 'proj-a'

    def test_route_to_project_returns_count(self):
        """_route_to_project returns count of affected projects"""
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = Path(tmpdir)
            proj_a = tmpdir / 'proj-a'
            proj_b = tmpdir / 'proj-b'
            proj_a.mkdir()
            proj_b.mkdir()
            for proj in [proj_a, proj_b]:
                (proj / '.jot.json').write_text(
                    json.dumps({'tasks': [], 'archived': []}))
                (proj / '.jot.ids.json').write_text(
                    json.dumps({'next_id': 1, 'allocated': []}))
            (tmpdir / '.jot.json').write_text(
                json.dumps({'tasks': [], 'archived': []}))
            (tmpdir / '.jot.ids.json').write_text(
                json.dumps({'next_id': 1, 'allocated': []}))
            # Pre-create registry file to prevent auto-discover
            reg_file = tmpdir / '.jot-projects.json'
            reg_file.write_text('{}')
            registry = ProjectRegistry(registry_file=str(reg_file))
            registry.register_project('proj-a', str(proj_a))
            registry.register_project('proj-b', str(proj_b))
            tm = TaskManager(directory=tmpdir, project_registry=registry)
            count = tm._route_to_project(
                'test task', '__all__', 'none', 'todo', None, None)
            assert count == 2


    def test_broadcast_deduplicates_symlinked_projects(self):
        """Symlinked projects that resolve to the same path get one write, not two"""
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = Path(tmpdir)
            real_proj = tmpdir / 'real-proj'
            real_proj.mkdir()
            (real_proj / '.jot.json').write_text(
                json.dumps({'tasks': [], 'archived': []}))
            (real_proj / '.jot.ids.json').write_text(
                json.dumps({'next_id': 1, 'allocated': []}))

            # Create a symlink to the same directory
            symlink_proj = tmpdir / 'symlink-proj'
            symlink_proj.symlink_to(real_proj)

            reg_file = tmpdir / '.jot-projects.json'
            reg_file.write_text('{}')
            registry = ProjectRegistry(registry_file=str(reg_file))
            registry.projects['real-proj'] = str(real_proj)
            registry.projects['symlink-proj'] = str(symlink_proj)
            registry._save_registry()

            (tmpdir / '.jot.json').write_text(
                json.dumps({'tasks': [], 'archived': []}))
            (tmpdir / '.jot.ids.json').write_text(
                json.dumps({'next_id': 1, 'allocated': []}))
            tm = TaskManager(directory=tmpdir, project_registry=registry)

            count = tm._route_to_project(
                'dedup test', '__all__', 'none', 'todo', None, None)
            assert count == 1  # Only one write despite two registry entries

            data = json.loads((real_proj / '.jot.json').read_text())
            texts = [t['text'] for t in data['tasks']]
            assert texts.count('dedup test') == 1

    def test_auto_discover_skips_symlinks(self):
        """Auto-discover should not register symlinked directories"""
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = Path(tmpdir)
            projects_dir = tmpdir / 'projects'
            projects_dir.mkdir()

            # Create a real project
            real_proj = projects_dir / 'real'
            real_proj.mkdir()
            (real_proj / '.jot.json').write_text('{}')

            # Create a symlink to it
            sym_proj = projects_dir / 'sym'
            sym_proj.symlink_to(real_proj)

            reg_file = tmpdir / '.jot-projects.json'
            reg_file.write_text('{}')
            registry = ProjectRegistry(registry_file=str(reg_file))

            # Manually call _auto_discover with patched home
            from unittest.mock import patch
            with patch.object(Path, 'home', return_value=tmpdir):
                registry.projects = {}
                registry._auto_discover()

            assert 'real' in registry.projects
            assert 'sym' not in registry.projects


class TestExtractTimeTag:
    """Test extract_time_tag utility"""

    def test_time_tag_at_end(self):
        from jot.utils.date_utils import extract_time_tag
        hour, minute, cleaned = extract_time_tag("standup 0930")
        assert hour == 9
        assert minute == 30
        assert cleaned == "standup"

    def test_time_tag_at_start(self):
        from jot.utils.date_utils import extract_time_tag
        hour, minute, cleaned = extract_time_tag("0800 morning routine")
        assert hour == 8
        assert minute == 0
        assert cleaned == "morning routine"

    def test_time_tag_in_middle(self):
        from jot.utils.date_utils import extract_time_tag
        hour, minute, cleaned = extract_time_tag("do 1430 thing")
        assert hour == 14
        assert minute == 30
        assert cleaned == "do thing"

    def test_no_time_tag(self):
        from jot.utils.date_utils import extract_time_tag
        hour, minute, cleaned = extract_time_tag("no time here")
        assert hour is None
        assert minute is None
        assert cleaned == "no time here"

    def test_invalid_hour(self):
        from jot.utils.date_utils import extract_time_tag
        hour, minute, cleaned = extract_time_tag("meeting 2500")
        assert hour is None  # 25 > 23

    def test_invalid_minute(self):
        from jot.utils.date_utils import extract_time_tag
        hour, minute, cleaned = extract_time_tag("meeting 0961")
        assert hour is None  # 61 > 59

    def test_not_standalone(self):
        from jot.utils.date_utils import extract_time_tag
        hour, minute, cleaned = extract_time_tag("task1430foo")
        assert hour is None  # Not space-delimited


class TestGcalImportTaskText:
    """Test that gcal import creates tasks with icon, not time prefix."""

    @staticmethod
    def _make_event(summary, all_day=False, start_hour=None, end_hour=None):
        from datetime import datetime, timezone
        date = datetime(2026, 2, 27).date()
        if all_day:
            return {'summary': summary, 'start': None, 'end': None,
                    'all_day': True, 'date': date, 'description': ''}
        return {
            'summary': summary,
            'start': datetime(2026, 2, 27, start_hour or 9, 0,
                              tzinfo=timezone.utc),
            'end': datetime(2026, 2, 27, end_hour or 10, 0,
                            tzinfo=timezone.utc),
            'all_day': False, 'date': date, 'description': '',
        }

    def test_timed_event_uses_calendar_icon_not_time(self, tmp_path):
        """Timed events should use 📆 icon, not time range prefix."""
        from unittest.mock import patch
        from jot.commands._gcal_mixin import GcalMixin

        ev = self._make_event('Morning Standup', start_hour=9, end_hour=10)

        tm = TaskManager(directory=tmp_path)
        handler = type('Handler', (GcalMixin,), {})()
        handler.task_manager = tm

        with patch('jot.commands._gcal_mixin.multiselect_picker',
                   return_value=[ev]):
            handler._display_and_import_events(
                [ev], 'today', 'default', 'today')

        assert len(tm.tasks) == 1
        assert tm.tasks[0]['text'] == '📆 Morning Standup'
        assert 'AM' not in tm.tasks[0]['text']

    def test_allday_event_keeps_calendar_emoji(self, tmp_path):
        """All-day events should keep 📅 icon."""
        from unittest.mock import patch
        from jot.commands._gcal_mixin import GcalMixin

        ev = self._make_event('Team Offsite', all_day=True)

        tm = TaskManager(directory=tmp_path)
        handler = type('Handler', (GcalMixin,), {})()
        handler.task_manager = tm

        with patch('jot.commands._gcal_mixin.multiselect_picker',
                   return_value=[ev]):
            handler._display_and_import_events(
                [ev], 'today', 'default', 'today')

        assert len(tm.tasks) == 1
        assert tm.tasks[0]['text'] == '📅 Team Offsite'

    def test_picker_cancel_imports_nothing(self, tmp_path):
        """Cancelling the picker (ESC) imports no events."""
        from unittest.mock import patch
        from jot.commands._gcal_mixin import GcalMixin

        ev = self._make_event('Standup')

        tm = TaskManager(directory=tmp_path)
        handler = type('Handler', (GcalMixin,), {})()
        handler.task_manager = tm

        with patch('jot.commands._gcal_mixin.multiselect_picker',
                   return_value=[]):
            handler._display_and_import_events(
                [ev], 'today', 'default', 'today')

        assert len(tm.tasks) == 0

    def test_partial_selection_imports_subset(self, tmp_path):
        """Selecting only some events imports only those."""
        from unittest.mock import patch
        from jot.commands._gcal_mixin import GcalMixin

        ev1 = self._make_event('Standup', start_hour=9, end_hour=10)
        ev2 = self._make_event('Lunch', start_hour=12, end_hour=13)
        ev3 = self._make_event('Review', start_hour=15, end_hour=16)

        tm = TaskManager(directory=tmp_path)
        handler = type('Handler', (GcalMixin,), {})()
        handler.task_manager = tm

        with patch('jot.commands._gcal_mixin.multiselect_picker',
                   return_value=[ev1, ev3]):
            handler._display_and_import_events(
                [ev1, ev2, ev3], 'today', 'default', 'today')

        assert len(tm.tasks) == 2
        texts = [t['text'] for t in tm.tasks]
        assert '📆 Standup' in texts
        assert '📆 Review' in texts
        assert '📆 Lunch' not in texts

    def test_event_day_prefix_for_today(self):
        """Today's events should have no prefix."""
        from datetime import datetime
        from jot.commands._gcal_mixin import GcalMixin

        today = datetime.now().date()
        prefix = GcalMixin._event_day_prefix(today, today, 'today')
        assert prefix == ""

    def test_event_day_annotation(self):
        """Day annotations for picker items."""
        from datetime import datetime, timedelta
        from jot.commands._gcal_mixin import GcalMixin

        today = datetime.now().date()
        assert GcalMixin._event_day_annotation(today, today) == "Today"
        assert GcalMixin._event_day_annotation(
            today + timedelta(days=1), today) == "Tomorrow"
        assert GcalMixin._event_day_annotation(
            today - timedelta(days=1), today) == "Yesterday"


class TestMultiselectPicker:
    """Test the multiselect_picker function."""

    def test_select_all_default_and_confirm(self):
        """All items checked by default, Enter returns all values."""
        from unittest.mock import patch
        from jot.ui.picker import PickerItem, multiselect_picker

        items = [PickerItem(value='a', label='Alpha'),
                 PickerItem(value='b', label='Beta')]

        with patch('jot.ui.picker.get_key', return_value='\r'):
            result = multiselect_picker(items)

        assert result == ['a', 'b']

    def test_cancel_returns_empty(self):
        """ESC returns empty list."""
        from unittest.mock import patch
        from jot.ui.picker import PickerItem, multiselect_picker

        items = [PickerItem(value='a', label='Alpha')]

        with patch('jot.ui.picker.get_key', return_value='\x1b'):
            result = multiselect_picker(items)

        assert result == []

    def test_space_toggles_selection(self):
        """Space deselects current, Enter returns partial."""
        from unittest.mock import patch
        from jot.ui.picker import PickerItem, multiselect_picker

        items = [PickerItem(value='a', label='Alpha'),
                 PickerItem(value='b', label='Beta')]

        keys = iter([' ', '\r'])  # Space deselects item 0, Enter confirms
        with patch('jot.ui.picker.get_key', side_effect=keys):
            result = multiselect_picker(items)

        assert result == ['b']  # Only item 1 remains checked

    def test_empty_items_returns_empty(self):
        """Empty item list returns empty immediately."""
        from jot.ui.picker import multiselect_picker
        assert multiselect_picker([]) == []


if __name__ == '__main__':
    pytest.main([__file__, '-v'])
