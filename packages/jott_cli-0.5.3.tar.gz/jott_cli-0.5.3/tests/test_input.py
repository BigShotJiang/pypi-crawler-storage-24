#!/usr/bin/env python3
"""
Unit tests for jot/ui/input.py
Tests input utilities, terminal restore, and prompt_toolkit fallback.
"""

import sys
import tempfile
from pathlib import Path
from unittest.mock import patch, MagicMock


class TestPromptToolkitAvailability:
    """Test that prompt_toolkit availability is detected correctly"""

    def test_prompt_toolkit_flag_is_set(self):
        """PROMPT_TOOLKIT_AVAILABLE should be True when installed"""
        from jot.ui.input import PROMPT_TOOLKIT_AVAILABLE
        assert PROMPT_TOOLKIT_AVAILABLE is True

    def test_get_key_is_callable(self):
        """get_key should be a callable function"""
        from jot.ui.input import get_key
        assert callable(get_key)

    def test_input_with_prefill_is_callable(self):
        """input_with_prefill should be a callable function"""
        from jot.ui.input import input_with_prefill
        assert callable(input_with_prefill)


class TestRestoreTerminal:
    """Test restore_terminal utility"""

    def test_restore_terminal_is_callable(self):
        """restore_terminal should be importable and callable"""
        from jot.ui.input import restore_terminal
        assert callable(restore_terminal)

    def test_flush_input_is_callable(self):
        """flush_input should be importable and callable"""
        from jot.ui.input import flush_input
        assert callable(flush_input)

    @patch('jot.ui.input.sys')
    @patch('jot.ui.input.termios')
    def test_restore_terminal_calls_termios(self, mock_termios, mock_sys):
        """restore_terminal should call tcgetattr, tcsetattr, and tcflush"""
        mock_sys.stdin.fileno.return_value = 0
        mock_termios.TCSADRAIN = 1
        mock_termios.TCIFLUSH = 0
        mock_termios.tcgetattr.return_value = 'settings'

        from jot.ui.input import restore_terminal
        restore_terminal()

        mock_termios.tcgetattr.assert_called_once_with(0)
        mock_termios.tcsetattr.assert_called_once_with(0, 1, 'settings')
        mock_termios.tcflush.assert_called_once_with(0, 0)

    @patch('jot.ui.input.sys')
    @patch('jot.ui.input.termios')
    def test_flush_input_calls_tcflush(self, mock_termios, mock_sys):
        """flush_input should call tcflush"""
        mock_sys.stdin.fileno.return_value = 0
        mock_termios.TCIFLUSH = 0

        from jot.ui.input import flush_input
        flush_input()

        mock_termios.tcflush.assert_called_once_with(0, 0)


class TestLegacyFallback:
    """Test legacy implementations still work"""

    def test_legacy_get_key_exists(self):
        """Legacy get_key implementation should be importable"""
        from jot.ui.input import _get_key_legacy
        assert callable(_get_key_legacy)

    def test_legacy_input_with_prefill_exists(self):
        """Legacy input_with_prefill implementation should be importable"""
        from jot.ui.input import _input_with_prefill_legacy
        assert callable(_input_with_prefill_legacy)

    @patch('builtins.input', return_value='test input')
    def test_legacy_input_with_prefill_returns_string(self, mock_input):
        """Legacy input_with_prefill should return user input"""
        from jot.ui.input import _input_with_prefill_legacy

        # Patch readline to avoid terminal issues in test
        with patch('jot.ui.input.readline', create=True) as mock_readline:
            mock_readline.set_startup_hook = MagicMock()
            # Need to import readline in the function scope
            import readline
            with patch.dict('sys.modules', {'readline': mock_readline}):
                result = _input_with_prefill_legacy("prompt: ", "prefill")

        assert result == 'test input'


class TestPromptToolkitInput:
    """Test prompt_toolkit-based implementations"""

    def test_pt_get_key_exists(self):
        """prompt_toolkit get_key should be importable"""
        from jot.ui.input import _get_key_pt
        assert callable(_get_key_pt)

    def test_pt_input_with_prefill_exists(self):
        """prompt_toolkit input_with_prefill should be importable"""
        from jot.ui.input import _input_with_prefill_pt
        assert callable(_input_with_prefill_pt)

    @patch('jot.ui.input.pt_prompt', return_value='edited text')
    def test_pt_input_with_prefill_returns_string(self, mock_prompt):
        """prompt_toolkit input_with_prefill should return user input"""
        from jot.ui.input import _input_with_prefill_pt

        result = _input_with_prefill_pt("prompt: ", "prefill")

        assert result == 'edited text'
        mock_prompt.assert_called_once()

    @patch('jot.ui.input.pt_prompt', return_value='edited text')
    def test_pt_input_with_prefill_passes_default(self, mock_prompt):
        """prompt_toolkit input_with_prefill should pass prefill as default"""
        from jot.ui.input import _input_with_prefill_pt

        _input_with_prefill_pt("prompt: ", "my prefill")

        call_kwargs = mock_prompt.call_args
        assert call_kwargs[1]['default'] == 'my prefill'

    @patch('jot.ui.input.pt_prompt', return_value='new task')
    def test_pt_input_with_prefill_uses_history(self, mock_prompt):
        """prompt_toolkit input_with_prefill should pass FileHistory"""
        from jot.ui.input import _input_with_prefill_pt, _TASK_HISTORY

        _input_with_prefill_pt("prompt: ")

        call_kwargs = mock_prompt.call_args
        assert call_kwargs[1]['history'] is _TASK_HISTORY


class TestKeyMapping:
    """Test the key mapping constants"""

    def test_pt_key_map_defined(self):
        """Key map for prompt_toolkit Keys should be defined"""
        from jot.ui.input import _PT_KEY_MAP
        from prompt_toolkit.keys import Keys

        assert Keys.Up in _PT_KEY_MAP
        assert Keys.Down in _PT_KEY_MAP
        assert Keys.ShiftUp in _PT_KEY_MAP
        assert Keys.ShiftDown in _PT_KEY_MAP
        assert _PT_KEY_MAP[Keys.Up] == 'UP'
        assert _PT_KEY_MAP[Keys.Down] == 'DOWN'
        assert _PT_KEY_MAP[Keys.ShiftUp] == 'SHIFT_UP'
        assert _PT_KEY_MAP[Keys.ShiftDown] == 'SHIFT_DOWN'


class TestPublicAPISelection:
    """Test that the public API correctly selects implementation"""

    def test_get_key_is_pt_when_available(self):
        """When prompt_toolkit is available, get_key should use PT impl"""
        from jot.ui.input import get_key, _get_key_pt, PROMPT_TOOLKIT_AVAILABLE

        if PROMPT_TOOLKIT_AVAILABLE:
            assert get_key is _get_key_pt

    def test_input_with_prefill_is_pt_when_available(self):
        """When prompt_toolkit is available, input_with_prefill should use PT"""
        from jot.ui.input import (
            input_with_prefill, _input_with_prefill_pt, PROMPT_TOOLKIT_AVAILABLE
        )

        if PROMPT_TOOLKIT_AVAILABLE:
            assert input_with_prefill is _input_with_prefill_pt


# ---------------------------------------------------------------------------
# Helper for mocking terminal IO in get_key tests
# ---------------------------------------------------------------------------

def _make_get_key_mocks(chars, select_responses=None):
    """Build mocks for get_key tests.

    Args:
        chars: List of characters that sys.stdin.read(1) returns in sequence.
        select_responses: List of booleans for select.select() calls.
            True means data is ready, False means timeout.
            If None, defaults to [True] + [False] (first select ready,
            second select for paste detection returns not-ready).
    """
    mock_stdin = MagicMock()
    mock_stdin.fileno.return_value = 0
    mock_stdin.read.side_effect = chars

    mock_termios = MagicMock()
    mock_termios.TCSADRAIN = 1
    mock_termios.tcgetattr.return_value = 'old_settings'

    mock_tty = MagicMock()

    if select_responses is None:
        # Default: first select ready, second (paste check) not ready
        select_responses = [True, False]

    def mock_select_fn(rlist, wlist, xlist, timeout=None):
        if select_responses:
            ready = select_responses.pop(0)
            return (rlist if ready else [], [], [])
        return ([], [], [])

    mock_select = MagicMock()
    mock_select.select.side_effect = mock_select_fn

    return mock_stdin, mock_termios, mock_tty, mock_select


class TestGetKeyLegacyBehavior:
    """Test _get_key_legacy key parsing with mocked terminal IO"""

    def _call(self, chars, select_responses=None):
        """Helper to call _get_key_legacy with mocked IO"""
        mock_stdin, mock_termios, mock_tty, mock_select = _make_get_key_mocks(
            chars, select_responses
        )
        with patch('jot.ui.input.sys') as mock_sys, \
             patch('jot.ui.input.termios', mock_termios), \
             patch.dict('sys.modules', {'select': mock_select, 'tty': mock_tty}):
            mock_sys.stdin = mock_stdin
            # Need to patch select and tty inside the function scope
            import jot.ui.input as input_mod
            orig_select = None
            orig_tty = None
            try:
                # The function imports select and tty locally, so we
                # need to make them available via sys.modules
                import select as real_select
                import tty as real_tty
                orig_select_fn = real_select.select
                real_select.select = mock_select.select
                orig_tty_fn = real_tty.setraw
                real_tty.setraw = mock_tty.setraw
                return input_mod._get_key_legacy(timeout=1.0)
            finally:
                real_select.select = orig_select_fn
                real_tty.setraw = orig_tty_fn

    def test_timeout_returns_none(self):
        """No input within timeout should return None"""
        mock_stdin, mock_termios, mock_tty, mock_select = _make_get_key_mocks(
            [], select_responses=[False]
        )
        with patch('jot.ui.input.sys') as mock_sys, \
             patch('jot.ui.input.termios', mock_termios):
            mock_sys.stdin = mock_stdin
            import select as real_select
            import tty as real_tty
            orig_select_fn = real_select.select
            orig_tty_fn = real_tty.setraw
            real_select.select = mock_select.select
            real_tty.setraw = mock_tty.setraw
            try:
                from jot.ui.input import _get_key_legacy
                result = _get_key_legacy(timeout=1.0)
            finally:
                real_select.select = orig_select_fn
                real_tty.setraw = orig_tty_fn
        assert result is None

    def test_regular_character(self):
        """Regular printable character should be returned as-is"""
        result = self._call(['a'])
        assert result == 'a'

    def test_ctrl_n_returns_down(self):
        """Ctrl+N should return 'DOWN'"""
        result = self._call(['\x0e'])
        assert result == 'DOWN'

    def test_ctrl_p_returns_up(self):
        """Ctrl+P should return 'UP'"""
        result = self._call(['\x10'])
        assert result == 'UP'

    def test_up_arrow(self):
        """Up arrow (ESC [ A) should return 'UP'"""
        result = self._call(['\x1b', '[', 'A'])
        assert result == 'UP'

    def test_down_arrow(self):
        """Down arrow (ESC [ B) should return 'DOWN'"""
        result = self._call(['\x1b', '[', 'B'])
        assert result == 'DOWN'

    def test_shift_up_arrow(self):
        """Shift+Up (ESC [ 1 ; 2 A) should return 'SHIFT_UP'"""
        result = self._call(['\x1b', '[', '1', ';', '2', 'A'])
        assert result == 'SHIFT_UP'

    def test_shift_down_arrow(self):
        """Shift+Down (ESC [ 1 ; 2 B) should return 'SHIFT_DOWN'"""
        result = self._call(['\x1b', '[', '1', ';', '2', 'B'])
        assert result == 'SHIFT_DOWN'

    def test_paste_detection(self):
        """Rapid multi-char input should be detected as paste"""
        # "hello" = 5 chars. Flow:
        # select#1 (timeout check) -> ready
        # read 'h'
        # select#2 (paste check) -> ready -> enter paste mode
        # pasted_text = 'h'
        # while: select#3 -> ready, read 'e'  (pasted='he')
        # while: select#4 -> ready, read 'l'  (pasted='hel')
        # while: select#5 -> ready, read 'l'  (pasted='hell')
        # while: select#6 -> ready, read 'o'  (pasted='hello')
        # while: select#7 -> not ready -> break
        result = self._call(
            ['h', 'e', 'l', 'l', 'o'],
            select_responses=[True, True, True, True, True, True, False]
        )

        assert isinstance(result, tuple)
        assert result[0] == 'PASTE'
        assert result[1] == 'hello'

    def test_enter_key(self):
        """Enter key should return carriage return character"""
        result = self._call(['\r'])
        assert result == '\r'

    def test_backspace_key(self):
        """Backspace should return delete character"""
        result = self._call(['\x7f'])
        assert result == '\x7f'

    def test_ctrl_x(self):
        """Ctrl+X should return raw control character"""
        result = self._call(['\x18'])
        assert result == '\x18'

    def test_space_key(self):
        """Space should return space character"""
        result = self._call([' '])
        assert result == ' '

    def test_terminal_restored_after_call(self):
        """Terminal settings should always be restored"""
        mock_stdin, mock_termios, mock_tty, mock_select = _make_get_key_mocks(
            ['a']
        )
        with patch('jot.ui.input.sys') as mock_sys, \
             patch('jot.ui.input.termios', mock_termios):
            mock_sys.stdin = mock_stdin
            import select as real_select
            import tty as real_tty
            orig_select_fn = real_select.select
            orig_tty_fn = real_tty.setraw
            real_select.select = mock_select.select
            real_tty.setraw = mock_tty.setraw
            try:
                from jot.ui.input import _get_key_legacy
                _get_key_legacy(timeout=1.0)
            finally:
                real_select.select = orig_select_fn
                real_tty.setraw = orig_tty_fn

        mock_termios.tcsetattr.assert_called_once_with(
            0, 1, 'old_settings'
        )


class TestGetKeyPtBehavior:
    """Test _get_key_pt key parsing with mocked terminal IO"""

    def _call(self, chars, select_responses=None):
        """Helper to call _get_key_pt with mocked IO"""
        mock_stdin, mock_termios, mock_tty, mock_select = _make_get_key_mocks(
            chars, select_responses
        )
        with patch('jot.ui.input.sys') as mock_sys, \
             patch('jot.ui.input.termios', mock_termios):
            mock_sys.stdin = mock_stdin
            import select as real_select
            import tty as real_tty
            orig_select_fn = real_select.select
            orig_tty_fn = real_tty.setraw
            real_select.select = mock_select.select
            real_tty.setraw = mock_tty.setraw
            try:
                from jot.ui.input import _get_key_pt
                return _get_key_pt(timeout=1.0)
            finally:
                real_select.select = orig_select_fn
                real_tty.setraw = orig_tty_fn

    def test_timeout_returns_none(self):
        """No input within timeout should return None"""
        result = self._call([], select_responses=[False])
        assert result is None

    def test_regular_character(self):
        """Regular printable character should be returned as-is"""
        result = self._call(['x'])
        assert result == 'x'

    def test_ctrl_n_returns_down(self):
        """Ctrl+N should return 'DOWN'"""
        result = self._call(['\x0e'])
        assert result == 'DOWN'

    def test_ctrl_p_returns_up(self):
        """Ctrl+P should return 'UP'"""
        result = self._call(['\x10'])
        assert result == 'UP'

    def test_bare_esc_returns_esc(self):
        """Bare ESC with no following sequence should return ESC char"""
        # New behavior: read ESC, while loop finds no more data -> parse ESC
        # select#1 ready, read ESC
        # while: select#2 not ready -> break
        result = self._call(['\x1b'], select_responses=[True, False])
        assert result == '\x1b'

    def test_up_arrow(self):
        """Up arrow (ESC [ A) should return 'UP'"""
        # New behavior: read ESC, while loop reads [ and A
        # select#1 ready, read ESC
        # while: select#2 ready, read [
        # while: select#3 ready, read A
        # while: select#4 not ready -> break
        # Vt100Parser parses "\x1b[A" -> Keys.Up -> 'UP'
        result = self._call(
            ['\x1b', '[', 'A'],
            select_responses=[True, True, True, False]
        )
        assert result == 'UP'

    def test_down_arrow(self):
        """Down arrow (ESC [ B) should return 'DOWN'"""
        result = self._call(
            ['\x1b', '[', 'B'],
            select_responses=[True, True, True, False]
        )
        assert result == 'DOWN'

    def test_shift_up(self):
        """Shift+Up (ESC [ 1 ; 2 A) should return 'SHIFT_UP'"""
        # 6 chars: ESC [ 1 ; 2 A
        # select#1 ready, read ESC
        # while: 5 ready reads + 1 not-ready
        result = self._call(
            ['\x1b', '[', '1', ';', '2', 'A'],
            select_responses=[True, True, True, True, True, True, False]
        )
        assert result == 'SHIFT_UP'

    def test_shift_down(self):
        """Shift+Down (ESC [ 1 ; 2 B) should return 'SHIFT_DOWN'"""
        result = self._call(
            ['\x1b', '[', '1', ';', '2', 'B'],
            select_responses=[True, True, True, True, True, True, False]
        )
        assert result == 'SHIFT_DOWN'

    def test_paste_detection(self):
        """Multi-char rapid input should be detected as paste"""
        # "hello" = 5 chars
        # select#1 ready, read 'h'
        # while: 4 ready reads (e,l,l,o) + 1 not-ready
        result = self._call(
            ['h', 'e', 'l', 'l', 'o'],
            select_responses=[True, True, True, True, True, False]
        )
        assert isinstance(result, tuple)
        assert result[0] == 'PASTE'
        assert result[1] == 'hello'

    def test_enter_key(self):
        """Enter key should return carriage return"""
        result = self._call(['\r'])
        assert result == '\r'

    def test_backspace_key(self):
        """Backspace should return delete character"""
        result = self._call(['\x7f'])
        assert result == '\x7f'

    def test_terminal_restored_on_success(self):
        """Terminal settings restored after successful read"""
        mock_stdin, mock_termios, mock_tty, mock_select = _make_get_key_mocks(
            ['a']
        )
        with patch('jot.ui.input.sys') as mock_sys, \
             patch('jot.ui.input.termios', mock_termios):
            mock_sys.stdin = mock_stdin
            import select as real_select
            import tty as real_tty
            orig_select_fn = real_select.select
            orig_tty_fn = real_tty.setraw
            real_select.select = mock_select.select
            real_tty.setraw = mock_tty.setraw
            try:
                from jot.ui.input import _get_key_pt
                _get_key_pt(timeout=1.0)
            finally:
                real_select.select = orig_select_fn
                real_tty.setraw = orig_tty_fn

        mock_termios.tcsetattr.assert_called_once_with(
            0, 1, 'old_settings'
        )

    def test_terminal_restored_on_timeout(self):
        """Terminal settings restored even on timeout"""
        mock_stdin, mock_termios, mock_tty, mock_select = _make_get_key_mocks(
            [], select_responses=[False]
        )
        with patch('jot.ui.input.sys') as mock_sys, \
             patch('jot.ui.input.termios', mock_termios):
            mock_sys.stdin = mock_stdin
            import select as real_select
            import tty as real_tty
            orig_select_fn = real_select.select
            orig_tty_fn = real_tty.setraw
            real_select.select = mock_select.select
            real_tty.setraw = mock_tty.setraw
            try:
                from jot.ui.input import _get_key_pt
                _get_key_pt(timeout=1.0)
            finally:
                real_select.select = orig_select_fn
                real_tty.setraw = orig_tty_fn

        mock_termios.tcsetattr.assert_called_once_with(
            0, 1, 'old_settings'
        )


if __name__ == '__main__':
    import pytest
    sys.exit(pytest.main([__file__, '-v']))
