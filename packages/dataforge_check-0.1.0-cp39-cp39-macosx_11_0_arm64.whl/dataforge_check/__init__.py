"""DataForge Check: High-Performance Data Validation."""

__version__ = "0.1.0"

from .dataforge_check import validate, version

__all__ = ["validate", "version"]
