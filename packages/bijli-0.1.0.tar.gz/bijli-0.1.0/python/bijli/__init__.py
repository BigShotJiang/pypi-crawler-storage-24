"""Bijli -- Rust-powered Python profiler.

In-process * No sudo * CPU + Memory * Embeddable * PyPI-ready

Usage::

    from bijli import profile, Profile

    @profile
    def my_function():
        ...

    with Profile() as p:
        my_function()
    p.print_report()
"""

import functools
import threading
import time
import tracemalloc
from typing import Any

try:
    from bijli._core import __version__, PySampler  # type: ignore[import]
except ImportError:
    __version__ = "0.1.0-dev (not built)"
    PySampler = None  # type: ignore[assignment,misc]

__all__: list[str] = ["__version__", "PySampler", "MemWatcher", "Profile", "profile"]


# ---------------------------------------------------------------------------
# Conditional tracemalloc watcher
# ---------------------------------------------------------------------------

class MemWatcher:
    """Daemon thread that polls the Rust spike flag and triggers tracemalloc.

    When the sampler detects an RSS spike > ``mem_spike_threshold_bytes``
    (default 10 MB), it sets an atomic flag.  This watcher thread polls that
    flag every 20 ms; on a spike it starts tracemalloc for
    ``duration_s`` seconds, captures a snapshot, then stops tracemalloc
    (unless it was already tracing before the spike).

    A ``cooldown_s`` guard prevents rapid-fire snapshots.

    Parameters
    ----------
    sampler:
        A ``PySampler`` instance that is already started.
    cooldown_s:
        Minimum seconds between consecutive snapshots.  Default: 5.
    duration_s:
        How long tracemalloc stays active after a spike.  Default: 0.5.
    frames:
        tracemalloc call-stack depth.  Default: 10.
    """

    def __init__(
        self,
        sampler: "PySampler",
        *,
        cooldown_s: float = 5.0,
        duration_s: float = 0.5,
        frames: int = 10,
    ) -> None:
        self._sampler = sampler
        self._cooldown_s = cooldown_s
        self._duration_s = duration_s
        self._frames = frames
        self.snapshots: list[tracemalloc.Snapshot] = []
        self._stop_event = threading.Event()
        self._thread = threading.Thread(
            target=self._run,
            name="bijli-mem-watcher",
            daemon=True,
        )

    def start(self) -> None:
        """Start the watcher daemon thread."""
        self._thread.start()

    def stop(self, timeout: float = 2.0) -> None:
        """Signal the watcher to stop and wait for it to exit."""
        self._stop_event.set()
        self._thread.join(timeout=timeout)

    def _run(self) -> None:
        last_snapshot_time: float = 0.0

        while not self._stop_event.is_set():
            if self._sampler.mem_spike_flag():
                now = time.monotonic()
                if now - last_snapshot_time >= self._cooldown_s:
                    self._take_snapshot()
                    last_snapshot_time = time.monotonic()
                # Always clear the flag so the sampler can set it again.
                self._sampler.notify_snapshot_taken()

            # Poll every 20 ms.  Using wait() instead of sleep() so that
            # stop() wakes us up promptly.
            self._stop_event.wait(timeout=0.02)

    def _take_snapshot(self) -> None:
        was_tracing = tracemalloc.is_tracing()
        try:
            if not was_tracing:
                tracemalloc.start(self._frames)
            time.sleep(self._duration_s)
            snapshot = tracemalloc.take_snapshot()
            self.snapshots.append(snapshot)
        finally:
            # Always restore tracemalloc to the state we found it in.
            if not was_tracing and tracemalloc.is_tracing():
                tracemalloc.stop()


# ---------------------------------------------------------------------------
# Profile context manager
# ---------------------------------------------------------------------------

class Profile:
    """Context manager that profiles a block of code.

    Parameters
    ----------
    interval_ms:
        Sampling interval in milliseconds.  Default: 50.
    top_n:
        Maximum number of hot-path frames in the report.  Default: 20.
    mem_cooldown_s:
        Minimum seconds between consecutive tracemalloc snapshots.
        Default: 5.
    mem_duration_s:
        How long tracemalloc stays active after a memory spike.
        Default: 0.5.
    mem_frames:
        tracemalloc call-stack depth for allocation snapshots.  Default: 10.

    Usage::

        with Profile() as p:
            do_work()
        p.print_report()
    """

    def __init__(
        self,
        *,
        interval_ms: int = 50,
        top_n: int = 20,
        mem_cooldown_s: float = 5.0,
        mem_duration_s: float = 0.5,
        mem_frames: int = 10,
    ) -> None:
        self._sampler: Any = PySampler(interval_ms=interval_ms, top_n=top_n)
        self._watcher = MemWatcher(
            self._sampler,
            cooldown_s=mem_cooldown_s,
            duration_s=mem_duration_s,
            frames=mem_frames,
        )
        self.result: dict | None = None

    def __enter__(self) -> "Profile":
        self._sampler.start()
        self._watcher.start()
        return self

    def __exit__(self, *exc: Any) -> bool:
        self._watcher.stop()
        result = self._sampler.stop()
        # Attach tracemalloc snapshots as a private field for the renderer.
        result["_snapshots"] = self._watcher.snapshots
        self.result = result
        return False  # never suppress exceptions

    def print_report(self, *, json_mode: bool = False) -> None:
        """Print the profiling report to stdout."""
        from bijli.report import render

        if self.result is None:
            raise RuntimeError("Profile has not finished yet (call after __exit__)")
        render(self.result, json_mode=json_mode)


# ---------------------------------------------------------------------------
# @profile decorator
# ---------------------------------------------------------------------------

def profile(func=None, *, interval_ms: int = 50, top_n: int = 20):
    """Decorator that profiles a function and prints a report on return.

    Can be used bare or with keyword arguments::

        @profile
        def my_function(): ...

        @profile(interval_ms=100, top_n=10)
        def my_function(): ...
    """

    def decorator(fn):
        @functools.wraps(fn)
        def wrapper(*args, **kwargs):
            with Profile(interval_ms=interval_ms, top_n=top_n) as p:
                result = fn(*args, **kwargs)
            p.print_report()
            return result

        return wrapper

    if func is not None:
        # Called as @profile (no parentheses) -- func is the decorated fn.
        return decorator(func)

    # Called as @profile(...) -- return the decorator.
    return decorator
