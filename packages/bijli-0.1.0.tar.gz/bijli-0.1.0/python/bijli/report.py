"""ANSI and JSON report renderer for Bijli profiler results.

All output is pure ASCII (cp1252-safe for Windows terminals).
ANSI colour codes are stripped automatically when stdout is not a TTY.
"""

import json
import os
import sys
from typing import Any

# ---------------------------------------------------------------------------
# Terminal helpers
# ---------------------------------------------------------------------------

def _is_tty() -> bool:
    return hasattr(sys.stdout, "isatty") and sys.stdout.isatty()


def _ansi(code: str, text: str) -> str:
    if _is_tty():
        return f"\033[{code}m{text}\033[0m"
    return text


def _red(text: str) -> str:
    return _ansi("31", text)


def _yellow(text: str) -> str:
    return _ansi("33", text)


def _bold(text: str) -> str:
    return _ansi("1", text)


def _green(text: str) -> str:
    return _ansi("32", text)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

# Three clearly distinct ASCII levels: flat/low, medium, dense/high.
# Chosen so the output reads naturally: "____####____" means a CPU burst.
_SPARK = "_-#"
_BAR_WIDTH = 40   # chars at 100% for hot-path bars
_SEP  = "=" * 64
_sep  = "-" * 64


def _sparkline(values: list, width: int = 60) -> str:
    """Render a fixed-width ASCII sparkline from a list of floats.

    Uses three levels: _ (low), - (medium), # (high).
    Values are normalised relative to the min/max in the dataset.
    """
    if not values:
        return "_" * width
    lo = min(values)
    hi = max(values)
    span = hi - lo if hi != lo else 1.0
    n = len(values)
    chars = []
    for i in range(width):
        idx = min(int(i / width * n), n - 1)
        level = int((values[idx] - lo) / span * (len(_SPARK) - 1))
        chars.append(_SPARK[level])
    return "".join(chars)


# ---------------------------------------------------------------------------
# Noise filter for hot paths
# ---------------------------------------------------------------------------

# Bijli's own infrastructure frames that should not appear in user hot paths.
_NOISE_FILES = frozenset({"__init__.py", "cli.py", "report.py"})
_NOISE_FUNS  = frozenset({
    "wrapper", "__enter__", "__exit__", "start", "stop",
    "_tracemalloc_watcher", "print_report",
})
# Python threading internals spawned by bijli's background threads.
_THREADING_NOISE = frozenset({
    "wait", "start", "_bootstrap", "_bootstrap_inner", "_wait_for_tstate_lock",
})


def _is_noise(frame: dict) -> bool:
    """Return True for bijli-internal, threading-internal, and uninformative frames."""
    basename = _basename(frame["file"])
    fn = frame["function"]
    # Top-level module frame — always 100%, tells the user nothing
    if fn == "<module>":
        return True
    if basename in _NOISE_FILES and fn in _NOISE_FUNS:
        return True
    if basename == "threading.py" and fn in _THREADING_NOISE:
        return True
    return False


def _bar(pct: float, width: int = _BAR_WIDTH) -> str:
    """Return a '#'-filled bar proportional to pct (0-100)."""
    filled = max(1, round(pct / 100 * width)) if pct > 0 else 0
    return "#" * filled


def _basename(filepath: str) -> str:
    """Return just the filename, stripping directory components."""
    name = os.path.basename(filepath)
    return name if name else filepath


def _trunc(s: str, n: int) -> str:
    """Truncate string to n chars, appending '>' if cut."""
    return s if len(s) <= n else s[: n - 1] + ">"


# ---------------------------------------------------------------------------
# Public entry point
# ---------------------------------------------------------------------------

def render(result: dict, *, json_mode: bool = False) -> None:
    """Render a profile result dict to stdout.

    Parameters
    ----------
    result:
        Dict returned by ``Profile.__exit__`` / ``PySampler.stop()``.
    json_mode:
        When True, output machine-readable JSON instead of ANSI text.
    """
    if json_mode:
        _render_json(result)
    else:
        _render_ansi(result)


# ---------------------------------------------------------------------------
# JSON output
# ---------------------------------------------------------------------------

def _render_json(result: dict) -> None:
    data: dict = {k: v for k, v in result.items() if not k.startswith("_")}

    snapshots = result.get("_snapshots", [])
    if snapshots:
        alloc_sites = []
        for snap in snapshots:
            stats = snap.statistics("lineno")
            alloc_sites.append(
                [
                    {
                        "traceback": str(stat.traceback),
                        "size_bytes": stat.size,
                        "count": stat.count,
                    }
                    for stat in stats[:10]
                ]
            )
        data["allocation_snapshots"] = alloc_sites

    print(json.dumps(data, indent=2, default=str))


# ---------------------------------------------------------------------------
# ANSI text output
# ---------------------------------------------------------------------------

def _render_ansi(result: dict) -> None:
    wall_ms      = result["wall_time_ms"]
    wall_s       = wall_ms / 1000.0
    samples      = result["samples"]
    spike_events = result["spike_events"]
    hot_paths    = result["hot_paths"]
    n            = len(samples)

    cpu_vals = [s["cpu_percent"] for s in samples if s["cpu_percent"] >= 0]
    rss_mb   = [s["rss_bytes"] / (1024 * 1024) for s in samples if s["rss_bytes"] > 0]

    avg_cpu   = sum(cpu_vals) / len(cpu_vals) if cpu_vals else 0.0
    peak_cpu  = max(cpu_vals) if cpu_vals else 0.0
    rss_start = rss_mb[0] if rss_mb else 0.0
    rss_peak  = max(rss_mb) if rss_mb else 0.0

    cpu_spikes = [e for e in spike_events if e["kind"] == "cpu"]
    mem_spikes = [e for e in spike_events if e["kind"] != "cpu"]

    # ---- Header ----
    print()
    print(_SEP)
    print(_bold("  bijli profiler report"))
    print(_SEP)
    print(f"  wall time  :  {wall_s:.3f} s")
    print(f"  samples    :  {n}")

    if n == 0:
        print("  (no samples collected)")
        print(_SEP)
        return

    print(f"  CPU        :  avg {avg_cpu:.1f}%   peak {peak_cpu:.1f}%")
    if rss_mb:
        mem_delta = rss_peak - rss_start
        delta_str = f"  (+{mem_delta:.1f} MB)" if mem_delta > 0.5 else ""
        print(f"  memory     :  {rss_start:.1f} MB -> {rss_peak:.1f} MB{delta_str}")

    # Spike summary in header
    if spike_events:
        parts = []
        if cpu_spikes:
            parts.append(f"{len(cpu_spikes)} CPU")
        if mem_spikes:
            parts.append(f"{len(mem_spikes)} memory")
        print(f"  spikes     :  {_yellow(', '.join(parts) + ' detected')}")
    else:
        print(f"  spikes     :  {_green('none')}")

    # ---- Timelines ----
    print()
    if cpu_vals:
        spark = _sparkline(cpu_vals)
        print(f"  CPU  [{spark}]  {min(cpu_vals):.0f}%..{peak_cpu:.0f}%")
    if rss_mb:
        spark = _sparkline(rss_mb)
        print(f"  RSS  [{spark}]  {rss_start:.0f}..{rss_peak:.0f} MB")
    if cpu_vals or rss_mb:
        print("         _ = low   - = medium   # = high")

    # ---- Hot paths ----
    print()
    print(_sep)
    visible_paths = [p for p in hot_paths if not _is_noise(p)]
    if visible_paths:
        print("  HOT PATHS  -- where the program spent its time")
        print()
        for i, path in enumerate(visible_paths, 1):
            pct  = path["percent"]
            fn   = _trunc(path["function"], 28)
            loc  = f"{_basename(path['file'])}:{path['line']}"
            bar  = _bar(pct)
            print(f"  {i:2}.  {fn:<28}  {pct:5.1f}%  {bar}")
            print(f"        {loc}")
            print()
    else:
        print("  HOT PATHS  -- no data (increase profiling duration)")

    # ---- Spike events ----
    print(_sep)
    if spike_events:
        print(f"  SPIKES  ({len(spike_events)} detected)")
        for i, ev in enumerate(spike_events, 1):
            start_s = ev["start_ms"] / 1000.0
            end_s   = ev["end_ms"] / 1000.0
            dur_ms  = ev["end_ms"] - ev["start_ms"]
            kind    = ev["kind"].upper()
            label   = _red(f"[{kind}]")

            print()
            print(f"  {i}. {label}  {start_s:.2f} s -- {end_s:.2f} s  ({dur_ms} ms)")

            if ev["kind"] == "cpu":
                print(f"     peak {ev['peak_value']:.1f}%   threshold {ev['threshold']:.1f}%")
            else:
                peak_mb   = ev["peak_value"] / (1024 * 1024)
                thresh_mb = ev["threshold"] / (1024 * 1024)
                print(f"     peak {peak_mb:.1f} MB   threshold {thresh_mb:.1f} MB")

            peak_stack = ev.get("peak_stack")
            if peak_stack:
                print("     Stack at peak:")
                for frame in peak_stack[-5:]:
                    fn  = _trunc(frame["function"], 24)
                    loc = f"{_basename(frame['file'])}:{frame['line']}"
                    print(f"       {fn:<24}  {loc}")
    else:
        print("  No unusual activity detected.")

    # ---- Allocation hotspots ----
    snapshots = result.get("_snapshots", [])
    if snapshots:
        print()
        print(_sep)
        print(f"  ALLOCATIONS  ({len(snapshots)} tracemalloc snapshot(s))")
        print()
        snap  = snapshots[0]
        stats = snap.statistics("lineno")
        for i, stat in enumerate(stats[:10], 1):
            size_kb = stat.size / 1024
            print(f"  {i:2}.  {size_kb:8.1f} KB  {stat.traceback}")

    print()
    print(_SEP)
