"""Type stubs for the bijli._core extension module."""

from __future__ import annotations

__version__: str

class PySampler:
    """Rust-backed background sampler.

    Parameters
    ----------
    interval_ms:
        Sampling interval in milliseconds.  Default: 50.
    top_n:
        Maximum number of hot-path frames returned by ``stop()``.  Default: 20.
    """

    def __new__(
        cls,
        *,
        interval_ms: int = 50,
        top_n: int = 20,
    ) -> "PySampler": ...

    def start(self) -> None:
        """Start the background sampling thread.

        Raises
        ------
        RuntimeError
            If the sampler has already been stopped.
        """
        ...

    def stop(self) -> dict:
        """Stop the sampler and return a profile-result dict.

        The dict contains:

        - ``sample_count`` (int) -- number of samples collected
        - ``wall_time_ms`` (int) -- wall-clock duration of the session
        - ``samples`` (list[dict]) -- per-sample data
        - ``spike_events`` (list[dict]) -- detected CPU / memory spikes
        - ``hot_paths`` (list[dict]) -- top-N most frequent frames

        Each sample dict has keys: ``timestamp_ms``, ``cpu_percent``,
        ``rss_bytes``, ``stack`` (list[dict] | None).

        Raises
        ------
        RuntimeError
            If the sampler has already been stopped.
        """
        ...

    def mem_spike_flag(self) -> bool:
        """Return True if a memory spike has been detected since last cleared."""
        ...

    def notify_snapshot_taken(self) -> None:
        """Clear the memory spike flag after a tracemalloc snapshot."""
        ...

    def is_running(self) -> bool:
        """Return True if the background sampling thread is running."""
        ...
