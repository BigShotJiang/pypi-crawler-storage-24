"""CLI argument parsing for ``python -m bijli``."""

import argparse
import runpy
import sys

from bijli import Profile


def main(argv=None) -> None:
    parser = argparse.ArgumentParser(
        prog="bijli",
        description="Bijli -- Rust-powered in-process Python profiler",
    )
    parser.add_argument("script", help="Python script to profile")
    parser.add_argument(
        "args",
        nargs=argparse.REMAINDER,
        help="Arguments forwarded to the script",
    )
    parser.add_argument(
        "--interval",
        type=int,
        default=50,
        metavar="MS",
        help="Sampling interval in milliseconds (default: 50)",
    )
    parser.add_argument(
        "--top-n",
        type=int,
        default=20,
        metavar="N",
        help="Number of hot paths to show (default: 20)",
    )
    parser.add_argument(
        "--json",
        action="store_true",
        help="Output report as machine-readable JSON",
    )

    args = parser.parse_args(argv)

    # Make the script's directory the first entry in sys.path, and set
    # sys.argv so the profiled script sees its own argument vector.
    import os

    script_dir = os.path.dirname(os.path.abspath(args.script))
    sys.argv = [args.script] + list(args.args)
    if script_dir not in sys.path:
        sys.path.insert(0, script_dir)

    with Profile(interval_ms=args.interval, top_n=args.top_n) as p:
        runpy.run_path(args.script, run_name="__main__")

    p.print_report(json_mode=args.json)
