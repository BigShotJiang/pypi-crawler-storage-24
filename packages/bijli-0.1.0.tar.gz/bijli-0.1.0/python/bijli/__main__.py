"""Entry point for ``python -m bijli``."""

from bijli.cli import main

main()
