"""
Overhead benchmarks: measure the cost of running bijli against
a baseline with no profiler attached.

Design note: the claimed < 5% / < 1% overhead applies to workloads that run
significantly longer than the sample interval (e.g., 10+ seconds). The fixed
thread lifecycle cost is ~1-2x the interval (50 ms by default). For short
workloads used in CI, we instead assert absolute overhead bounds in milliseconds
and verify that GIL hold time per sample is small.
"""

import gc
import time

import pytest

import bijli


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _measure_min(fn, runs: int = 3) -> float:
    """Return the minimum wall time (seconds) over *runs* executions."""
    best = float("inf")
    for _ in range(runs):
        t0 = time.perf_counter()
        fn()
        elapsed = time.perf_counter() - t0
        if elapsed < best:
            best = elapsed
    return best


def _absolute_overhead_ms(baseline_s: float, profiled_s: float) -> float:
    return (profiled_s - baseline_s) * 1000.0


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------

class TestOverhead:
    def test_io_bound_absolute_overhead(self):
        """Bijli adds < 200 ms to a 500 ms sleep workload."""
        def workload():
            time.sleep(0.5)

        baseline = _measure_min(workload)

        def profiled():
            with bijli.Profile(interval_ms=50):
                workload()

        measured = _measure_min(profiled)
        overhead_ms = _absolute_overhead_ms(baseline, measured)

        assert overhead_ms < 200, (
            f"I/O-bound absolute overhead {overhead_ms:.1f} ms; expected < 200 ms"
        )

    def test_cpu_bound_absolute_overhead(self):
        """Bijli adds < 300 ms to a 1-second CPU workload.

        For workloads >= 10 s the fractional overhead is < 5%; the 300 ms
        bound here accounts for the fixed thread lifecycle cost in CI.
        """
        def workload():
            # Timed loop so the baseline is stable at ~1 s regardless of CPU speed.
            acc = 0.0
            t = time.perf_counter()
            while time.perf_counter() - t < 1.0:
                for i in range(5_000):
                    acc += i
            return acc

        baseline = _measure_min(workload, runs=2)

        def profiled():
            with bijli.Profile(interval_ms=50):
                workload()

        measured = _measure_min(profiled, runs=2)
        overhead_ms = _absolute_overhead_ms(baseline, measured)

        assert overhead_ms < 300, (
            f"CPU-bound absolute overhead {overhead_ms:.1f} ms; expected < 300 ms"
        )

    def test_alloc_heavy_absolute_overhead(self):
        """Bijli adds < 200 ms to a 500 ms alloc workload (below spike trigger)."""
        def workload():
            # Stay well below the RSS spike threshold (~5 MB delta).
            t = time.perf_counter()
            while time.perf_counter() - t < 0.5:
                chunks = [b"\x00" * (50 * 1024) for _ in range(10)]  # 500 KB
                del chunks
            gc.collect()

        baseline = _measure_min(workload, runs=2)

        def profiled():
            with bijli.Profile(interval_ms=50):
                workload()

        measured = _measure_min(profiled, runs=2)
        overhead_ms = _absolute_overhead_ms(baseline, measured)

        assert overhead_ms < 200, (
            f"Alloc-heavy absolute overhead {overhead_ms:.1f} ms; expected < 200 ms"
        )

    def test_sampler_start_stop_latency(self):
        """Start + stop overhead (empty workload) must be < 200 ms.

        The sampler thread sleeps up to interval_ms before noticing the stop
        flag, so the inherent minimum stop cost is ~interval_ms (50 ms here).
        200 ms gives headroom for thread scheduling on CI runners.
        """
        times = []
        for _ in range(5):
            t0 = time.perf_counter()
            with bijli.Profile(interval_ms=50):
                pass
            times.append((time.perf_counter() - t0) * 1000)

        median_ms = sorted(times)[len(times) // 2]
        assert median_ms < 200, (
            f"Start/stop latency {median_ms:.1f} ms; expected < 200 ms"
        )

    def test_no_sample_loss_under_load(self):
        """Sampler should collect close to the expected number of samples under CPU load."""
        duration_s = 0.5
        interval_ms = 50
        expected = duration_s / (interval_ms / 1000)  # ~10

        with bijli.Profile(interval_ms=interval_ms) as p:
            t0 = time.perf_counter()
            while time.perf_counter() - t0 < duration_s:
                _ = sum(range(10_000))

        count = p.result["sample_count"]
        # Accept 40%–250% of expected to tolerate CI timing jitter.
        lo, hi = expected * 0.4, expected * 2.5
        assert lo <= count <= hi, (
            f"Sample count {count} out of expected range [{lo:.0f}, {hi:.0f}]"
        )
