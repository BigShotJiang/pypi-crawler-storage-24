"""Shared pytest fixtures for bijli integration tests."""
import pytest


@pytest.fixture(autouse=False)
def venv_python():
    """No-op fixture — tests run inside the .venv via maturin develop."""
    pass
