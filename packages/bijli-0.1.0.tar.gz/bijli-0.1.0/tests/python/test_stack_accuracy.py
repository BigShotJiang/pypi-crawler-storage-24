"""
Tests for CPython stack capture via bijli's Rust core.

These tests exercise capture_stack() indirectly by calling it from Python
using a small helper exposed for testing purposes.
"""

import sys
import threading
import time
import pytest

# Import the Rust extension. Tests are skipped if the build isn't present.
try:
    import bijli._core as _core  # noqa: F401
except ImportError:
    pytest.skip("bijli._core not built", allow_module_level=True)

# ---------------------------------------------------------------------------
# Stack capture helper
# We test stack capture via a thin Python shim that calls
# sys._current_frames() — the same path the Rust code takes.
# ---------------------------------------------------------------------------

def _current_stack_names() -> list[str]:
    """Return function names in the current thread's call stack (innermost last)."""
    frame = sys._current_frames().get(threading.current_thread().ident)
    names = []
    while frame is not None:
        names.append(frame.f_code.co_name)
        frame = frame.f_back
    names.reverse()  # outermost first
    return names


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------

def test_basic_import():
    """bijli._core is importable and exposes __version__."""
    assert hasattr(_core, "__version__")
    assert isinstance(_core.__version__, str)


def test_current_frames_captures_this_function():
    """sys._current_frames() includes the current function — same path Rust uses."""
    names = _current_stack_names()
    assert "test_current_frames_captures_this_function" in names


def test_call_chain_order():
    """Frames are ordered outermost → innermost."""
    def inner():
        return _current_stack_names()

    def middle():
        return inner()

    def outer():
        return middle()

    names = outer()
    # All three should appear
    assert "outer" in names
    assert "middle" in names
    assert "inner" in names
    # outer must come before middle which must come before inner
    assert names.index("outer") < names.index("middle") < names.index("inner")


def test_recursive_depth():
    """Recursive calls are all captured."""
    def recurse(n):
        if n == 0:
            return _current_stack_names()
        return recurse(n - 1)

    depth = 5
    names = recurse(depth)
    # All 'recurse' frames should appear (depth + 1 occurrences)
    count = names.count("recurse")
    assert count == depth + 1, f"Expected {depth + 1} 'recurse' frames, got {count}"


def test_multithreaded_frames():
    """sys._current_frames() returns frames for multiple threads."""
    barrier = threading.Barrier(2)
    captured = {}

    def worker():
        barrier.wait()  # synchronize with main thread
        captured["worker_id"] = threading.current_thread().ident
        time.sleep(0.5)  # keep frame alive

    t = threading.Thread(target=worker)
    t.start()
    barrier.wait()

    # Both main and worker should appear in _current_frames
    all_frames = sys._current_frames()
    assert threading.current_thread().ident in all_frames
    assert captured.get("worker_id") in all_frames or t.ident in all_frames

    t.join(timeout=1.0)
