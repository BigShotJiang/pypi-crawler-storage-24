"""
End-to-end integration tests for the Profile context manager,
@profile decorator, and CLI.

All tests run inside the active .venv after `maturin develop --release`.
"""

import json
import subprocess
import sys
import time

import pytest

try:
    import bijli._core as _core
    from bijli import Profile, profile
except ImportError:
    pytest.skip("bijli._core not built", allow_module_level=True)


# ---------------------------------------------------------------------------
# Profile context manager
# ---------------------------------------------------------------------------

class TestProfileContextManager:
    def test_basic_usage_returns_result(self):
        with Profile() as p:
            time.sleep(0.1)
        assert p.result is not None

    def test_result_has_required_keys(self):
        with Profile() as p:
            time.sleep(0.12)
        r = p.result
        for key in ("sample_count", "wall_time_ms", "samples", "spike_events", "hot_paths"):
            assert key in r, f"Missing key: {key}"

    def test_sample_count_is_positive(self):
        with Profile() as p:
            time.sleep(0.2)
        assert p.result["sample_count"] >= 1

    def test_wall_time_is_plausible(self):
        with Profile() as p:
            time.sleep(0.2)
        assert p.result["wall_time_ms"] >= 150

    def test_samples_have_required_fields(self):
        with Profile() as p:
            time.sleep(0.15)
        samples = p.result["samples"]
        assert len(samples) > 0
        s = samples[0]
        for key in ("timestamp_ms", "cpu_percent", "rss_bytes", "stack"):
            assert key in s, f"Sample missing key: {key}"

    def test_no_crash_on_exception_in_block(self):
        """Profile must clean up the sampler even when the body raises."""
        try:
            with Profile() as p:
                time.sleep(0.05)
                raise ValueError("expected test exception")
        except ValueError:
            pass
        # If we reach here the sampler was stopped cleanly (no hang).
        assert p.result is not None

    def test_print_report_ansi(self, capsys):
        with Profile() as p:
            time.sleep(0.1)
        p.print_report()
        captured = capsys.readouterr()
        assert "bijli profiler report" in captured.out
        assert "wall time" in captured.out

    def test_print_report_json(self, capsys):
        with Profile() as p:
            time.sleep(0.1)
        p.print_report(json_mode=True)
        captured = capsys.readouterr()
        data = json.loads(captured.out)
        assert "sample_count" in data
        assert "wall_time_ms" in data

    def test_custom_interval(self):
        with Profile(interval_ms=100) as p:
            time.sleep(0.35)
        # At 100ms interval expect roughly 3 samples; allow [1, 7].
        count = p.result["sample_count"]
        assert 1 <= count <= 7, f"Unexpected count at 100ms interval: {count}"

    def test_custom_top_n(self):
        with Profile(top_n=3) as p:
            time.sleep(0.2)
        assert len(p.result["hot_paths"]) <= 3

    def test_spike_events_is_list(self):
        with Profile() as p:
            time.sleep(0.1)
        assert isinstance(p.result["spike_events"], list)

    def test_hot_paths_is_list(self):
        with Profile() as p:
            time.sleep(0.1)
        assert isinstance(p.result["hot_paths"], list)

    def test_hot_path_fields(self):
        """Each hot-path entry must have all expected fields."""
        with Profile() as p:
            # Do some real work so at least one hot path is captured.
            total = 0
            for i in range(500_000):
                total += i
        hot_paths = p.result["hot_paths"]
        if hot_paths:
            hp = hot_paths[0]
            for key in ("file", "function", "line", "count", "percent"):
                assert key in hp, f"hot_path missing key: {key}"

    def test_print_report_raises_before_exit(self):
        p = Profile()
        # __enter__ was never called, result is None.
        with pytest.raises(RuntimeError):
            p.print_report()


# ---------------------------------------------------------------------------
# @profile decorator
# ---------------------------------------------------------------------------

class TestProfileDecorator:
    def test_bare_decorator(self):
        ran = {}

        @profile
        def work():
            time.sleep(0.05)
            ran["done"] = True

        work()
        assert ran.get("done") is True

    def test_decorator_with_args(self):
        ran = {}

        @profile(interval_ms=50, top_n=5)
        def work():
            time.sleep(0.05)
            ran["done"] = True

        work()
        assert ran.get("done") is True

    def test_decorator_preserves_return_value(self):
        @profile
        def add(a, b):
            return a + b

        assert add(2, 3) == 5

    def test_decorator_preserves_function_name(self):
        @profile
        def my_named_function():
            pass

        assert my_named_function.__name__ == "my_named_function"

    def test_decorator_with_args_preserves_return_value(self):
        @profile(interval_ms=50)
        def multiply(x, y):
            return x * y

        assert multiply(3, 4) == 12

    def test_decorator_prints_report(self, capsys):
        @profile
        def work():
            time.sleep(0.05)

        work()
        captured = capsys.readouterr()
        assert "bijli profiler report" in captured.out


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

class TestCLI:
    def test_cli_runs_script(self, tmp_path):
        script = tmp_path / "hello.py"
        script.write_text("import time\ntime.sleep(0.05)\n")
        result = subprocess.run(
            [sys.executable, "-m", "bijli", str(script)],
            capture_output=True,
            text=True,
            timeout=30,
        )
        assert result.returncode == 0, result.stderr
        assert "bijli profiler report" in result.stdout

    def test_cli_json_output(self, tmp_path):
        script = tmp_path / "hello.py"
        script.write_text("import time\ntime.sleep(0.05)\n")
        result = subprocess.run(
            [sys.executable, "-m", "bijli", "--json", str(script)],
            capture_output=True,
            text=True,
            timeout=30,
        )
        assert result.returncode == 0, result.stderr
        data = json.loads(result.stdout)
        assert "sample_count" in data
        assert "wall_time_ms" in data

    def test_cli_passes_args_to_script(self, tmp_path):
        script = tmp_path / "args.py"
        script.write_text(
            "import sys\n"
            "assert sys.argv[1] == 'hello', f'got {sys.argv}'\n"
        )
        result = subprocess.run(
            [sys.executable, "-m", "bijli", str(script), "hello"],
            capture_output=True,
            text=True,
            timeout=30,
        )
        assert result.returncode == 0, result.stderr

    def test_cli_custom_interval(self, tmp_path):
        script = tmp_path / "noop.py"
        script.write_text("import time\ntime.sleep(0.1)\n")
        result = subprocess.run(
            [sys.executable, "-m", "bijli", "--interval", "100", str(script)],
            capture_output=True,
            text=True,
            timeout=30,
        )
        assert result.returncode == 0, result.stderr

    def test_no_root_required(self, tmp_path):
        """Profiler must not require elevated privileges."""
        script = tmp_path / "noop.py"
        script.write_text("pass\n")
        result = subprocess.run(
            [sys.executable, "-m", "bijli", str(script)],
            capture_output=True,
            text=True,
            timeout=30,
        )
        stderr_lower = result.stderr.lower()
        assert "permission denied" not in stderr_lower
        assert "root" not in stderr_lower
        assert result.returncode == 0, result.stderr

    def test_cli_script_exit_code_propagated(self, tmp_path):
        """If the profiled script exits non-zero, bijli should too."""
        script = tmp_path / "fail.py"
        script.write_text("raise SystemExit(42)\n")
        result = subprocess.run(
            [sys.executable, "-m", "bijli", str(script)],
            capture_output=True,
            text=True,
            timeout=30,
        )
        assert result.returncode == 42
