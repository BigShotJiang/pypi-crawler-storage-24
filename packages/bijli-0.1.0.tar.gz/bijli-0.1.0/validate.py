"""
Bijli — Real-world validation script.

Runs concrete scenarios and prints human-readable output so you can verify
the profiler is actually capturing correct data, not just passing asserts.

Run with:
    source .venv/Scripts/activate
    python validate.py
"""

import gc
import sys
import time
import tracemalloc
import threading

import subprocess

import bijli._core as _core
from bijli import MemWatcher, Profile, profile

SEP = "-" * 60


def section(title: str) -> None:
    print(f"\n{SEP}\n  {title}\n{SEP}")


def ok(msg: str) -> None:
    print(f"  [OK]   {msg}")


def warn(msg: str) -> None:
    print(f"  [WARN] {msg}")


def info(msg: str) -> None:
    print(f"     {msg}")


# ===========================================================================
# Scenario 1: Stack capture — do we see the right function names?
# ===========================================================================

def scenario_stack_capture() -> None:
    section("1. Stack capture: are frame names visible in samples?")

    # We'll run the sampler while sitting inside a deeply-named call chain
    # and check that the sampler's Rust code saw frames with known names.
    # We verify via sys._current_frames() (same code path the Rust uses).

    import sys as _sys

    def leaf_function():
        frames = _sys._current_frames()
        main_frame = frames.get(threading.main_thread().ident)
        names = []
        while main_frame:
            names.append(main_frame.f_code.co_name)
            main_frame = main_frame.f_back
        names.reverse()
        return names

    def middle_layer():
        return leaf_function()

    def outer_layer():
        return middle_layer()

    names = outer_layer()
    expected = ["outer_layer", "middle_layer", "leaf_function"]
    for fn in expected:
        if fn in names:
            ok(f"'{fn}' found in captured frames")
        else:
            warn(f"'{fn}' NOT found — stack capture may be broken")

    # Also verify the sampler produces samples while inside a known function.
    results = {"names": []}

    def profiled_work():
        s = _core.PySampler()
        s.start()
        time.sleep(0.25)   # 5 ticks
        results["count"] = s.stop()["sample_count"]

    profiled_work()
    n = results["count"]
    if n >= 3:
        ok(f"Sampler collected {n} samples during 250 ms sleep")
    else:
        warn(f"Only {n} samples -- expected >= 3")


# ===========================================================================
# Scenario 2: CPU spike — does CPU% rise during a busy loop?
# ===========================================================================

def scenario_cpu_tracking() -> None:
    section("2. CPU tracking: does CPU% rise during a busy loop?")

    # Check that the sampler thread runs without error and the sample count
    # is consistent with the interval.

    # What we CAN validate now: read_metrics() returns plausible values.
    # We call it directly via sysinfo — but that's Rust-internal.
    # Instead, demonstrate that the sampler doesn't stall during CPU work.

    s = _core.PySampler()
    s.start()

    # Burn CPU for 300 ms.
    deadline = time.monotonic() + 0.3
    x = 0
    while time.monotonic() < deadline:
        for _ in range(100_000):
            x += 1

    n = s.stop()["sample_count"]
    info(f"CPU-bound work for 300 ms -> {n} samples collected")
    if n >= 3:
        ok(f"Sampler kept up during CPU-bound work ({n} samples)")
    else:
        warn(f"Low sample count ({n}) during CPU work -- possible GIL contention")

    # Baseline: idle for 300 ms.
    s2 = _core.PySampler()
    s2.start()
    time.sleep(0.3)
    n_idle = s2.stop()["sample_count"]
    info(f"Idle sleep for 300 ms -> {n_idle} samples collected")

    ok(f"CPU-bound {n} vs idle {n_idle} samples (both should be ~6)")


# ===========================================================================
# Scenario 3: Memory spike detection
# ===========================================================================

def scenario_memory_spike() -> None:
    section("3. Memory spike: does the flag fire on a 25 MB allocation?")

    s = _core.PySampler()
    s.start()

    # Let the sampler record baseline RSS over 2 ticks.
    time.sleep(0.12)
    info("Baseline RSS recorded (2 ticks)")

    # Allocate 25 MB and commit every page.
    info("Allocating 25 MB and touching all pages ...")
    data = bytearray(25 * 1024 * 1024)
    for i in range(0, len(data), 4096):
        data[i] = 0xFF

    # Wait for 2 more ticks so the sampler sees the new RSS.
    time.sleep(0.12)

    flag = s.mem_spike_flag()
    n = s.stop()["sample_count"]
    del data
    gc.collect()

    info(f"Samples collected: {n}")
    if flag:
        ok("Spike flag was set [OK]")
    else:
        warn(
            "Spike flag NOT set — RSS change may not have been visible to the "
            "sampler within 2 ticks (OS/allocator-dependent on Windows)"
        )

    # Negative case: 1 MB should NOT trigger the flag.
    s2 = _core.PySampler()
    s2.start()
    time.sleep(0.12)
    small = bytearray(1 * 1024 * 1024)
    for i in range(0, len(small), 4096):
        small[i] = 0x01
    time.sleep(0.12)
    small_flag = s2.mem_spike_flag()
    s2.stop()
    del small

    if not small_flag:
        ok("1 MB allocation did NOT trigger the flag (correct)")
    else:
        warn("1 MB allocation triggered the spike flag — threshold may be too low")


# ===========================================================================
# Scenario 4: MemWatcher — does tracemalloc actually fire?
# ===========================================================================

def scenario_mem_watcher() -> None:
    section("4. MemWatcher: does tracemalloc fire on a real spike?")

    if tracemalloc.is_tracing():
        tracemalloc.stop()

    s = _core.PySampler()
    s.start()

    watcher = MemWatcher(s, cooldown_s=5.0, duration_s=0.15, frames=10)
    watcher.start()

    # Baseline.
    time.sleep(0.12)
    info("Baseline established")

    # Spike.
    info("Allocating 25 MB ...")
    data = bytearray(25 * 1024 * 1024)
    for i in range(0, len(data), 4096):
        data[i] = 0xFF

    # Wait long enough for: spike detection (1 tick) + watcher poll (20 ms)
    # + tracemalloc duration (150 ms) + margin.
    time.sleep(0.4)

    watcher.stop()
    s.stop()
    del data
    gc.collect()

    n_snapshots = len(watcher.snapshots)
    info(f"Snapshots taken: {n_snapshots}")

    if n_snapshots == 0:
        warn(
            "No tracemalloc snapshots taken — RSS spike may not have been "
            "visible in time (see scenario 3 warning)"
        )
        return

    ok(f"{n_snapshots} tracemalloc snapshot(s) captured")

    # Show the top 5 allocation sites from the first snapshot.
    snapshot = watcher.snapshots[0]
    stats = snapshot.statistics("lineno")
    info("Top 5 allocation sites in the snapshot:")
    for i, stat in enumerate(stats[:5], 1):
        info(f"  {i}. {stat}")

    # Verify tracemalloc was stopped after watcher finished.
    if not tracemalloc.is_tracing():
        ok("tracemalloc was correctly stopped after snapshot")
    else:
        warn("tracemalloc is still running — watcher did not clean up")
        tracemalloc.stop()


# ===========================================================================
# Scenario 5: Sample rate accuracy
# ===========================================================================

def scenario_sample_rate() -> None:
    section("5. Sample rate: are we hitting ~20 samples/sec (50 ms interval)?")

    durations = [0.1, 0.3, 0.5]
    for dur in durations:
        s = _core.PySampler()
        s.start()
        time.sleep(dur)
        n = s.stop()["sample_count"]
        expected = dur / 0.05    # samples at 50 ms interval
        ratio = n / expected if expected > 0 else 0
        # Short windows have higher relative jitter — use wider tolerance.
        hi = 2.0 if dur <= 0.15 else 1.4
        status = "[OK]  " if 0.6 <= ratio <= hi else "[WARN]"
        info(
            f"  {status} {int(dur*1000):3d} ms window -> {n:2d} samples "
            f"(expected ~{expected:.0f}, ratio {ratio:.2f})"
        )

    ok("Sample rate check complete (ratio should be 0.7-1.4)")


# ===========================================================================
# Scenario 6: Drop safety — no crash when GC collects a running sampler
# ===========================================================================

def scenario_drop_safety() -> None:
    section("6. Drop safety: GC-collecting a running PySampler must not crash")

    def start_and_forget():
        s = _core.PySampler()
        s.start()
        time.sleep(0.05)
        # s goes out of scope here, Drop is called while GIL is held

    start_and_forget()
    gc.collect()
    time.sleep(0.12)   # give detached thread time to exit
    ok("No crash on GC-collected running sampler")


# ===========================================================================
# Scenario 7: Thread safety — multiple samplers running concurrently
# ===========================================================================

def scenario_concurrent_samplers() -> None:
    section("7. Concurrency: two PySamplers running simultaneously")

    s1 = _core.PySampler()
    s2 = _core.PySampler()

    s1.start()
    s2.start()
    time.sleep(0.25)
    n1 = s1.stop()
    n2 = s2.stop()

    n1 = n1["sample_count"]
    n2 = n2["sample_count"]
    info(f"Sampler 1: {n1} samples, Sampler 2: {n2} samples")
    if n1 >= 3 and n2 >= 3:
        ok("Both samplers collected data concurrently without errors")
    else:
        warn(f"Low counts: s1={n1}, s2={n2} -- possible GIL contention between sampler threads")


# ===========================================================================
# Scenario 8: Spike detection -- does Welford find a synthetic CPU spike?
# ===========================================================================

def scenario_spike_detection() -> None:
    section("8. Spike detection: does the profiler flag a CPU-bound burst?")

    # Run a CPU-heavy burst after a quiet baseline so Welford's threshold
    # sits between the baseline and the burst.
    s = _core.PySampler()
    s.start()

    # Quiet baseline: ~6 ticks at 50 ms = ~300 ms idle.
    time.sleep(0.3)

    # CPU burst: burn for 300 ms.
    info("Starting CPU burst ...")
    deadline = time.monotonic() + 0.3
    x = 0
    while time.monotonic() < deadline:
        for _ in range(100_000):
            x += 1

    # Another quiet tail so the spike is bounded.
    time.sleep(0.2)

    result = s.stop()

    cpu_spikes = [e for e in result["spike_events"] if e["kind"] == "cpu"]
    cpu_vals = [s["cpu_percent"] for s in result["samples"] if s["cpu_percent"] >= 0]
    info(f"Samples collected: {result['sample_count']}")
    info(f"CPU spike events : {len(cpu_spikes)}")
    if cpu_vals:
        info(
            f"CPU%  min={min(cpu_vals):.1f}  max={max(cpu_vals):.1f}  "
            f"avg={sum(cpu_vals)/len(cpu_vals):.1f}  "
            f"values={[round(v,1) for v in cpu_vals]}"
        )

    if cpu_spikes:
        ev = cpu_spikes[0]
        info(
            f"  spike: peak {ev['peak_value']:.1f}%  "
            f"threshold {ev['threshold']:.1f}%  "
            f"duration {ev['end_ms'] - ev['start_ms']} ms"
        )
        ok("CPU spike detected correctly")
    else:
        warn(
            "No CPU spike detected -- the baseline window (first 25% of "
            "recording) may have contained burst samples, pushing the "
            "threshold above the peak.  Try a longer quiet run-up period."
        )


# ===========================================================================
# Scenario 9: Hot paths — does frame aggregation produce results?
# ===========================================================================

def scenario_hot_paths() -> None:
    section("9. Hot paths: are the most frequent frames reported?")

    def busy_leaf():
        total = 0
        for _ in range(2_000_000):
            total += 1
        return total

    def mid_caller():
        return busy_leaf()

    s = _core.PySampler()
    s.start()
    mid_caller()
    result = s.stop()

    hot_paths = result["hot_paths"]
    info(f"Samples collected : {result['sample_count']}")
    info(f"Hot paths returned: {len(hot_paths)}")

    if not hot_paths:
        warn("No hot paths returned -- too few samples (increase duration)")
        return

    ok(f"Hot paths returned ({len(hot_paths)} entries)")
    info("Top 5 hot paths:")
    for i, hp in enumerate(hot_paths[:5], 1):
        info(f"  {i}. {hp['percent']:5.1f}%  {hp['file']}:{hp['line']}  {hp['function']}")

    # Check that 'busy_leaf' appears in the hot paths.
    names = [hp["function"] for hp in hot_paths]
    if "busy_leaf" in names:
        ok("'busy_leaf' appears in hot paths (correct)")
    else:
        warn("'busy_leaf' NOT in hot paths -- stack capture may have missed it")


# ===========================================================================
# Scenario 10: Profile context manager — end-to-end result
# ===========================================================================

def scenario_profile_context_manager() -> None:
    section("10. Profile context manager: does it produce a usable result?")

    with Profile() as p:
        time.sleep(0.2)

    r = p.result
    info(f"sample_count : {r['sample_count']}")
    info(f"wall_time_ms : {r['wall_time_ms']}")
    info(f"spike_events : {len(r['spike_events'])}")
    info(f"hot_paths    : {len(r['hot_paths'])}")

    if r["sample_count"] >= 2:
        ok(f"Profile collected {r['sample_count']} samples")
    else:
        warn(f"Only {r['sample_count']} samples -- expected >= 2")

    if r["wall_time_ms"] >= 150:
        ok(f"wall_time_ms plausible ({r['wall_time_ms']} ms)")
    else:
        warn(f"wall_time_ms suspiciously low: {r['wall_time_ms']} ms")

    ok("Profile context manager cleaned up without errors")


# ===========================================================================
# Scenario 11: @profile decorator
# ===========================================================================

def scenario_profile_decorator() -> None:
    section("11. @profile decorator: return value preserved, report printed")

    results = {}

    @profile
    def work_fn():
        time.sleep(0.1)
        results["done"] = True
        return 42

    ret = work_fn()

    if results.get("done"):
        ok("Decorated function body executed")
    else:
        warn("Decorated function body did not run")

    if ret == 42:
        ok("Return value (42) preserved through decorator")
    else:
        warn(f"Return value corrupted: expected 42, got {ret!r}")


# ===========================================================================
# Scenario 12: CLI — python -m bijli
# ===========================================================================

def scenario_cli() -> None:
    import tempfile
    import os

    section("12. CLI: 'python -m bijli script.py' produces a report")

    with tempfile.NamedTemporaryFile(
        mode="w", suffix=".py", delete=False
    ) as f:
        f.write("import time\ntime.sleep(0.05)\n")
        script_path = f.name

    try:
        result = subprocess.run(
            [sys.executable, "-m", "bijli", script_path],
            capture_output=True,
            text=True,
            timeout=30,
        )

        info(f"Exit code: {result.returncode}")

        if result.returncode == 0:
            ok("CLI exited with code 0")
        else:
            warn(f"CLI exited with code {result.returncode}")
            info("stderr: " + result.stderr[:200])

        if "bijli profiler report" in result.stdout:
            ok("Report header found in CLI output")
        else:
            warn("Report header NOT found in CLI output")
            info("stdout: " + result.stdout[:200])

        # JSON mode.
        result_json = subprocess.run(
            [sys.executable, "-m", "bijli", "--json", script_path],
            capture_output=True,
            text=True,
            timeout=30,
        )
        if result_json.returncode == 0:
            try:
                import json as _json
                data = _json.loads(result_json.stdout)
                if "sample_count" in data:
                    ok("JSON output is valid and contains 'sample_count'")
                else:
                    warn("JSON output missing 'sample_count'")
            except Exception as exc:
                warn(f"JSON parse error: {exc}")
        else:
            warn(f"CLI --json exited with code {result_json.returncode}")

    finally:
        os.unlink(script_path)


# ===========================================================================
# Main
# ===========================================================================

def main() -> None:
    print()
    print("=" * 60)
    print("  Bijli -- Real-World Validation")
    print(f"  bijli version: {_core.__version__}")
    print(f"  Python:        {sys.version.split()[0]}")
    print("=" * 60)

    scenario_stack_capture()
    scenario_cpu_tracking()
    scenario_memory_spike()
    scenario_mem_watcher()
    scenario_sample_rate()
    scenario_drop_safety()
    scenario_concurrent_samplers()
    scenario_spike_detection()
    scenario_hot_paths()
    scenario_profile_context_manager()
    scenario_profile_decorator()
    scenario_cli()

    print(f"\n{SEP}")
    print("  All scenarios complete.")
    print("  Review [WARN] warnings above -- [OK] means the check passed.")
    print(SEP)


if __name__ == "__main__":
    main()
