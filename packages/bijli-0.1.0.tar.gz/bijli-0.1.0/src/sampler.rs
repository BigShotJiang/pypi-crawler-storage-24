/// Background sampler thread that collects CPU%, RSS, and Python stack
/// snapshots at a configurable interval, stores them in a ring buffer, and
/// sets an atomic flag when a memory spike is detected.
use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::Arc;
use std::thread::{self, JoinHandle};
use std::time::{Duration, Instant};

use pyo3::prelude::*;

use crate::config::ProfilerConfig;
use crate::ringbuf::RingBuffer;
use crate::stack::{capture_stack, StackSnapshot};
use crate::sysinfo::read_metrics;

// ---------------------------------------------------------------------------
// Public data types
// ---------------------------------------------------------------------------

/// One sample collected by the background thread.
#[derive(Debug)]
pub struct Sample {
    /// Milliseconds elapsed since the sampler was started.
    pub timestamp_ms: u64,
    /// CPU usage at this tick (percent, one-core-relative).
    pub cpu_percent: f64,
    /// Resident set size in bytes.
    pub rss_bytes: u64,
    /// Python call stack, or `None` if capture failed.
    pub stack: Option<StackSnapshot>,
}

/// Aggregated output returned by [`Sampler::stop`].
pub struct SampleData {
    /// All samples collected during the profiling session, oldest first.
    pub samples: Vec<Sample>,
    /// Total wall-clock time of the profiling session in milliseconds.
    pub wall_time_ms: u64,
}

// ---------------------------------------------------------------------------
// Sampler
// ---------------------------------------------------------------------------

/// Manages the background sampling thread.
///
/// # Lifecycle
/// 1. [`Sampler::new`] — allocate state.
/// 2. [`Sampler::start`] — spawn background thread.
/// 3. [`Sampler::stop`] — set stop flag, join thread, drain ring buffer.
///
/// If [`stop`] is never called, [`Drop`] sets the stop flag and detaches the
/// thread.  The thread exits within one interval (≤ 50 ms by default).
pub struct Sampler {
    config: ProfilerConfig,
    ring: Arc<RingBuffer<Sample>>,
    stop_flag: Arc<AtomicBool>,
    /// Shared with the Python watcher thread — set when RSS delta exceeds threshold.
    pub mem_spike_flag: Arc<AtomicBool>,
    thread: Option<JoinHandle<()>>,
    start_time: Instant,
}

impl Sampler {
    pub fn new(config: ProfilerConfig) -> Self {
        let ring = Arc::new(RingBuffer::new(config.ring_buffer_capacity));
        Self {
            config,
            ring,
            stop_flag: Arc::new(AtomicBool::new(false)),
            mem_spike_flag: Arc::new(AtomicBool::new(false)),
            thread: None,
            start_time: Instant::now(),
        }
    }

    /// Spawn the sampler thread.  No-op if already running.
    pub fn start(&mut self) {
        if self.thread.is_some() {
            return;
        }

        let ring = Arc::clone(&self.ring);
        let stop_flag = Arc::clone(&self.stop_flag);
        let mem_spike_flag = Arc::clone(&self.mem_spike_flag);
        let interval = Duration::from_millis(self.config.interval_ms);
        let spike_threshold = self.config.mem_spike_threshold_bytes;

        self.start_time = Instant::now();
        self.stop_flag.store(false, Ordering::Release);

        let handle = thread::Builder::new()
            .name("bijli-sampler".to_owned())
            .spawn(move || {
                sampler_loop(ring, stop_flag, mem_spike_flag, interval, spike_threshold);
            })
            .expect("failed to spawn bijli sampler thread");

        self.thread = Some(handle);
    }

    /// Stop the sampler, join the thread, and return collected data.
    ///
    /// The caller **must not** hold the Python GIL when calling this method,
    /// because the sampler thread periodically acquires the GIL to capture
    /// Python stacks.  From `#[pymethods]`, release the GIL with
    /// `py.allow_threads(|| sampler.stop())`.
    pub fn stop(&mut self) -> SampleData {
        self.stop_flag.store(true, Ordering::Release);
        if let Some(handle) = self.thread.take() {
            // Blocks until the thread exits.  Caller must not hold GIL.
            let _ = handle.join();
        }
        let wall_time_ms = self.start_time.elapsed().as_millis() as u64;
        let samples = self.ring.drain();
        SampleData {
            samples,
            wall_time_ms,
        }
    }

    pub fn is_running(&self) -> bool {
        self.thread.is_some()
    }
}

impl Drop for Sampler {
    fn drop(&mut self) {
        // Signal the thread to exit.  We do NOT join here because we may be
        // called while the GIL is held (e.g., Python GC), which would deadlock
        // with the sampler thread trying to acquire the GIL for stack capture.
        // The thread will exit within one tick interval after seeing the flag.
        self.stop_flag.store(true, Ordering::Release);
        // Dropping `self.thread` detaches the JoinHandle — the thread keeps
        // running and self-terminates shortly.
    }
}

// ---------------------------------------------------------------------------
// Sampler loop (runs on the background thread)
// ---------------------------------------------------------------------------

fn sampler_loop(
    ring: Arc<RingBuffer<Sample>>,
    stop_flag: Arc<AtomicBool>,
    mem_spike_flag: Arc<AtomicBool>,
    interval: Duration,
    spike_threshold: u64,
) {
    // Lower thread priority on Linux so the profiler doesn't disturb the
    // measured process.  Best-effort: silently skip if it fails.
    #[cfg(target_os = "linux")]
    {
        // SAFETY: setpriority is always safe to call; failure is non-fatal.
        unsafe {
            libc::setpriority(libc::PRIO_PROCESS, 0, 5);
        }
    }

    let mut prev_cpu_ticks = 0u64;
    let mut prev_wall = Instant::now();
    let mut prev_rss: u64 = 0;
    let session_start = Instant::now();

    loop {
        let tick_start = Instant::now();

        if stop_flag.load(Ordering::Acquire) {
            break;
        }

        // Read CPU and RSS — no GIL needed.
        let metrics = read_metrics(&mut prev_cpu_ticks, &mut prev_wall);

        // Detect memory spikes: a single-tick RSS increase beyond the threshold.
        if prev_rss > 0 && metrics.rss_bytes > prev_rss {
            let delta = metrics.rss_bytes.saturating_sub(prev_rss);
            if delta >= spike_threshold {
                mem_spike_flag.store(true, Ordering::Release);
            }
        }
        if metrics.rss_bytes > 0 {
            prev_rss = metrics.rss_bytes;
        }

        // Capture Python call stack — brief GIL hold (target: < 50 µs).
        // SAFETY: `capture_stack` only reads Python frame objects; it never
        // allocates Python objects or calls back into user code.
        let stack: Option<StackSnapshot> = Python::with_gil(capture_stack);

        let timestamp_ms = session_start.elapsed().as_millis() as u64;

        ring.push(Sample {
            timestamp_ms,
            cpu_percent: metrics.cpu_percent,
            rss_bytes: metrics.rss_bytes,
            stack,
        });

        // Compensated sleep: subtract the time spent on this tick so that
        // the effective sampling rate stays close to the configured interval.
        let elapsed = tick_start.elapsed();
        if elapsed < interval {
            thread::sleep(interval - elapsed);
        }
    }
}

// ---------------------------------------------------------------------------
// Tests
// ---------------------------------------------------------------------------

#[cfg(test)]
mod tests {
    use super::*;
    use crate::config::ProfilerConfig;

    #[test]
    fn test_sampler_new_is_not_running() {
        let s = Sampler::new(ProfilerConfig::default());
        assert!(!s.is_running());
    }

    #[test]
    fn test_spike_flag_initially_false() {
        let s = Sampler::new(ProfilerConfig::default());
        assert!(!s.mem_spike_flag.load(Ordering::Acquire));
    }

    #[test]
    fn test_stop_before_start_returns_zero_samples() {
        let mut s = Sampler::new(ProfilerConfig::default());
        let data = s.stop();
        assert_eq!(data.samples.len(), 0);
    }

    #[test]
    fn test_sample_data_fields() {
        let s = Sample {
            timestamp_ms: 100,
            cpu_percent: 42.5,
            rss_bytes: 1024 * 1024,
            stack: None,
        };
        assert_eq!(s.timestamp_ms, 100);
        assert_eq!(s.cpu_percent, 42.5);
        assert_eq!(s.rss_bytes, 1024 * 1024);
        assert!(s.stack.is_none());
    }
}
