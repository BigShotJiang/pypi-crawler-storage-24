/// Spike detection and hot-path aggregation for the Bijli profiler.
///
/// Spike detection uses Welford's numerically-stable online algorithm to
/// compute the mean and standard deviation of CPU% and RSS in a single pass,
/// then groups contiguous above-threshold samples into `SpikeEvent`s in a
/// second pass.
use std::collections::HashMap;

use crate::config::ProfilerConfig;
use crate::sampler::Sample;
use crate::stack::StackSnapshot;

// ---------------------------------------------------------------------------
// Welford's online algorithm
// ---------------------------------------------------------------------------

/// Numerically stable running mean and sample variance (Welford 1962).
#[derive(Debug, Default, Clone)]
pub struct WelfordStats {
    count: u64,
    mean: f64,
    m2: f64,
}

impl WelfordStats {
    /// Incorporate one new observation.
    pub fn update(&mut self, value: f64) {
        self.count += 1;
        let delta = value - self.mean;
        self.mean += delta / self.count as f64;
        let delta2 = value - self.mean;
        self.m2 += delta * delta2;
    }

    pub fn mean(&self) -> f64 {
        self.mean
    }

    /// Unbiased sample variance (0 when fewer than 2 observations).
    pub fn variance(&self) -> f64 {
        if self.count < 2 {
            0.0
        } else {
            self.m2 / (self.count - 1) as f64
        }
    }

    pub fn stddev(&self) -> f64 {
        self.variance().sqrt()
    }

    pub fn count(&self) -> u64 {
        self.count
    }
}

// ---------------------------------------------------------------------------
// Spike events
// ---------------------------------------------------------------------------

#[derive(Debug, Clone)]
pub enum SpikeKind {
    Cpu,
    Memory,
}

#[derive(Debug, Clone)]
pub struct SpikeEvent {
    pub kind: SpikeKind,
    /// Wall time (ms from session start) when the spike began.
    pub start_ms: u64,
    /// Wall time (ms from session start) when the spike ended.
    pub end_ms: u64,
    /// Peak metric value observed during the spike.
    pub peak_value: f64,
    /// Threshold that was exceeded.
    pub threshold: f64,
    /// Python call stack at the moment of peak value, if captured.
    pub peak_stack: Option<StackSnapshot>,
}

/// Detect CPU and memory spikes from a slice of samples.
///
/// Algorithm:
/// 1. Baseline window — compute Welford mean + σ from the first
///    `spike_baseline_fraction` of the recording's wall time only.
///    This prevents the spike itself from inflating the threshold.
///    Falls back to all samples when the baseline window is too short.
/// 2. Derive thresholds: `max(μ + k·σ, μ + floor)` (always > μ).
/// 3. Second pass — scan **all** samples and group contiguous above-threshold
///    samples into `SpikeEvent`s.
///
/// Returns events sorted by `start_ms`.
pub fn detect_spikes(samples: &[Sample], config: &ProfilerConfig) -> Vec<SpikeEvent> {
    if samples.is_empty() {
        return Vec::new();
    }

    // ---- Baseline window ----
    // Use only the first `spike_baseline_fraction` of the recording to compute
    // statistics.  This prevents a long CPU burst (which may occupy a large
    // fraction of the recording) from pulling the mean up and hiding itself.
    const BASELINE_MIN: usize = 5;

    let total_ms = samples.last().map(|s| s.timestamp_ms).unwrap_or(0);
    let cutoff_ms = (total_ms as f64 * config.spike_baseline_fraction) as u64;
    let baseline_end = samples.partition_point(|s| s.timestamp_ms <= cutoff_ms);

    // If the baseline window is too small, fall back to the full recording.
    let stats_samples = if baseline_end >= BASELINE_MIN {
        &samples[..baseline_end]
    } else {
        samples
    };

    // ---- First pass: Welford stats over baseline window ----
    let mut cpu_stats = WelfordStats::default();
    let mut rss_stats = WelfordStats::default();

    for s in stats_samples {
        if s.cpu_percent >= 0.0 {
            cpu_stats.update(s.cpu_percent);
        }
        if s.rss_bytes > 0 {
            rss_stats.update(s.rss_bytes as f64);
        }
    }

    let k = config.spike_sigma_multiplier;

    let cpu_threshold = {
        let by_sigma = cpu_stats.mean() + k * cpu_stats.stddev();
        let by_floor = cpu_stats.mean() + config.cpu_spike_floor;
        by_sigma.max(by_floor).max(0.0)
    };

    let mem_threshold = {
        let by_sigma = rss_stats.mean() + k * rss_stats.stddev();
        let by_floor = rss_stats.mean() + config.mem_spike_floor_bytes as f64;
        by_sigma.max(by_floor).max(0.0)
    };

    // ---- Second pass: group contiguous spikes ----
    let mut events: Vec<SpikeEvent> = Vec::new();

    group_spikes(
        samples,
        cpu_threshold,
        |s| s.cpu_percent,
        SpikeKind::Cpu,
        &mut events,
    );
    group_spikes(
        samples,
        mem_threshold,
        |s| s.rss_bytes as f64,
        SpikeKind::Memory,
        &mut events,
    );

    events.sort_by_key(|e| e.start_ms);
    events
}

fn group_spikes<F>(
    samples: &[Sample],
    threshold: f64,
    metric_fn: F,
    kind: SpikeKind,
    events: &mut Vec<SpikeEvent>,
) where
    F: Fn(&Sample) -> f64,
{
    let mut in_spike = false;
    let mut start_ms = 0u64;
    let mut end_ms = 0u64;
    let mut peak_value = 0.0f64;
    let mut peak_stack: Option<StackSnapshot> = None;

    for sample in samples {
        let value = metric_fn(sample);

        if value > threshold {
            if !in_spike {
                in_spike = true;
                start_ms = sample.timestamp_ms;
                peak_value = value;
                peak_stack = sample.stack.clone();
            } else if value > peak_value {
                peak_value = value;
                peak_stack = sample.stack.clone();
            }
            end_ms = sample.timestamp_ms;
        } else if in_spike {
            events.push(SpikeEvent {
                kind: kind.clone(),
                start_ms,
                end_ms,
                peak_value,
                threshold,
                peak_stack: peak_stack.take(),
            });
            in_spike = false;
        }
    }

    // Spike reaching the end of the recording.
    if in_spike {
        events.push(SpikeEvent {
            kind,
            start_ms,
            end_ms,
            peak_value,
            threshold,
            peak_stack,
        });
    }
}

// ---------------------------------------------------------------------------
// Hot-path aggregation
// ---------------------------------------------------------------------------

/// A single entry in the hot-path list.
#[derive(Debug, Clone)]
pub struct HotPath {
    pub filename: String,
    pub function: String,
    pub lineno: i32,
    /// Number of samples in which this frame appeared.
    pub count: usize,
    /// Percentage of samples-with-stack that contained this frame.
    pub percent: f64,
}

/// Aggregate the most frequently sampled frames across all samples.
///
/// Only samples that have a captured stack contribute. Returns the top
/// `top_n` frames sorted by hit count (descending).
pub fn aggregate_hot_paths(samples: &[Sample], top_n: usize) -> Vec<HotPath> {
    let mut counts: HashMap<(String, String, i32), usize> = HashMap::new();
    let mut sample_count = 0usize;

    for sample in samples {
        if let Some(stack) = &sample.stack {
            for frame in &stack.frames {
                *counts
                    .entry((frame.filename.clone(), frame.function.clone(), frame.lineno))
                    .or_insert(0) += 1;
            }
            sample_count += 1;
        }
    }

    if sample_count == 0 {
        return Vec::new();
    }

    let mut paths: Vec<HotPath> = counts
        .into_iter()
        .map(|((filename, function, lineno), count)| HotPath {
            filename,
            function,
            lineno,
            count,
            percent: count as f64 / sample_count as f64 * 100.0,
        })
        .collect();

    paths.sort_by(|a, b| b.count.cmp(&a.count));
    paths.truncate(top_n);
    paths
}

// ---------------------------------------------------------------------------
// Tests
// ---------------------------------------------------------------------------

#[cfg(test)]
mod tests {
    use super::*;
    use crate::config::ProfilerConfig;
    use crate::sampler::Sample;
    use crate::stack::{FrameInfo, StackSnapshot};

    fn make_sample(ts_ms: u64, cpu: f64, rss: u64) -> Sample {
        Sample {
            timestamp_ms: ts_ms,
            cpu_percent: cpu,
            rss_bytes: rss,
            stack: None,
        }
    }

    fn make_stack(frames: &[(&str, &str, i32)]) -> StackSnapshot {
        StackSnapshot {
            frames: frames
                .iter()
                .map(|(file, func, line)| FrameInfo {
                    filename: file.to_string(),
                    function: func.to_string(),
                    lineno: *line,
                })
                .collect(),
            hash: 0,
        }
    }

    // ---- Welford ----

    #[test]
    fn test_welford_single_value() {
        let mut w = WelfordStats::default();
        w.update(10.0);
        assert_eq!(w.mean(), 10.0);
        assert_eq!(w.stddev(), 0.0);
        assert_eq!(w.count(), 1);
    }

    #[test]
    fn test_welford_two_values() {
        let mut w = WelfordStats::default();
        w.update(0.0);
        w.update(10.0);
        assert_eq!(w.mean(), 5.0);
        // sample variance = ((0-5)^2 + (10-5)^2) / 1 = 50
        assert!((w.variance() - 50.0).abs() < 1e-9);
    }

    #[test]
    fn test_welford_known_values() {
        let mut w = WelfordStats::default();
        for v in [2.0, 4.0, 4.0, 4.0, 5.0, 5.0, 7.0, 9.0] {
            w.update(v);
        }
        // mean = 5.0
        // SS = (2-5)^2 + 3*(4-5)^2 + 2*(5-5)^2 + (7-5)^2 + (9-5)^2
        //    = 9 + 3 + 0 + 4 + 16 = 32
        // sample variance (Bessel) = 32 / (8-1) = 32/7 ≈ 4.5714
        // Note: population variance = 32/8 = 4.0 — our algorithm uses Bessel's.
        assert!((w.mean() - 5.0).abs() < 1e-9);
        let expected_var = 32.0 / 7.0;
        assert!(
            (w.variance() - expected_var).abs() < 1e-9,
            "variance: expected {expected_var}, got {}",
            w.variance()
        );
        assert!((w.stddev() - expected_var.sqrt()).abs() < 1e-9);
    }

    #[test]
    fn test_welford_zero_count_variance() {
        let w = WelfordStats::default();
        assert_eq!(w.variance(), 0.0);
        assert_eq!(w.stddev(), 0.0);
    }

    // ---- Spike detection ----

    #[test]
    fn test_detect_spikes_empty() {
        let cfg = ProfilerConfig::default();
        assert!(detect_spikes(&[], &cfg).is_empty());
    }

    /// Build a test config with lower sigma so spikes are easier to detect
    /// in short synthetic datasets.
    fn test_cfg() -> ProfilerConfig {
        ProfilerConfig {
            spike_sigma_multiplier: 1.0,
            cpu_spike_floor: 10.0,
            mem_spike_floor_bytes: 5 * 1024 * 1024,
            ..ProfilerConfig::default()
        }
    }

    #[test]
    fn test_detect_cpu_spike() {
        let cfg = test_cfg();
        // 10 baseline samples at 5 % + 2 spike samples at 90 % + 5 tail samples.
        // With k=1 the threshold will be well below 90 %.
        let mut samples: Vec<Sample> = (0..10)
            .map(|i| make_sample(i * 50, 5.0, 100 * 1024 * 1024))
            .collect();
        samples.push(make_sample(500, 90.0, 100 * 1024 * 1024));
        samples.push(make_sample(550, 85.0, 100 * 1024 * 1024));
        for i in 0..5 {
            samples.push(make_sample(600 + i * 50, 5.0, 100 * 1024 * 1024));
        }

        let events = detect_spikes(&samples, &cfg);
        let cpu_spikes: Vec<_> = events
            .iter()
            .filter(|e| matches!(e.kind, SpikeKind::Cpu))
            .collect();
        assert_eq!(
            cpu_spikes.len(),
            1,
            "expected 1 CPU spike, got {}",
            cpu_spikes.len()
        );
        assert_eq!(cpu_spikes[0].start_ms, 500);
        assert_eq!(cpu_spikes[0].end_ms, 550);
        assert!((cpu_spikes[0].peak_value - 90.0).abs() < 1e-9);
    }

    #[test]
    fn test_detect_no_spike_flat_data() {
        let cfg = test_cfg();
        let samples: Vec<Sample> = (0..20)
            .map(|i| make_sample(i * 50, 5.0, 50 * 1024 * 1024))
            .collect();
        let events = detect_spikes(&samples, &cfg);
        let cpu_spikes: Vec<_> = events
            .iter()
            .filter(|e| matches!(e.kind, SpikeKind::Cpu))
            .collect();
        assert_eq!(cpu_spikes.len(), 0);
    }

    #[test]
    fn test_detect_spike_at_end_of_samples() {
        let cfg = test_cfg();
        // 15 baseline + 2 spike reaching end of recording.
        let mut samples: Vec<Sample> = (0..15)
            .map(|i| make_sample(i * 50, 5.0, 100 * 1024 * 1024))
            .collect();
        samples.push(make_sample(750, 90.0, 100 * 1024 * 1024));
        samples.push(make_sample(800, 95.0, 100 * 1024 * 1024));

        let events = detect_spikes(&samples, &cfg);
        let cpu_spikes: Vec<_> = events
            .iter()
            .filter(|e| matches!(e.kind, SpikeKind::Cpu))
            .collect();
        assert_eq!(
            cpu_spikes.len(),
            1,
            "expected 1 CPU spike, got {}",
            cpu_spikes.len()
        );
        assert_eq!(cpu_spikes[0].start_ms, 750);
        assert_eq!(cpu_spikes[0].end_ms, 800);
    }

    #[test]
    fn test_detect_two_separate_spikes() {
        let cfg = test_cfg();
        // 10 baseline + spike1 + 5 quiet + spike2 + 5 tail.
        let mut samples: Vec<Sample> = (0..10)
            .map(|i| make_sample(i * 50, 5.0, 100 * 1024 * 1024))
            .collect();
        samples.push(make_sample(500, 90.0, 100 * 1024 * 1024)); // spike 1
        for i in 0..5 {
            samples.push(make_sample(550 + i * 50, 5.0, 100 * 1024 * 1024));
        }
        samples.push(make_sample(800, 88.0, 100 * 1024 * 1024)); // spike 2
        for i in 0..5 {
            samples.push(make_sample(850 + i * 50, 5.0, 100 * 1024 * 1024));
        }

        let events = detect_spikes(&samples, &cfg);
        let cpu_spikes: Vec<_> = events
            .iter()
            .filter(|e| matches!(e.kind, SpikeKind::Cpu))
            .collect();
        assert_eq!(
            cpu_spikes.len(),
            2,
            "expected 2 CPU spikes, got {}",
            cpu_spikes.len()
        );
    }

    // ---- Hot paths ----

    #[test]
    fn test_baseline_window_enables_spike_detection() {
        // This test reproduces the real-world scenario where a long burst
        // (>30% of recording) would defeat global Welford stats but is
        // correctly detected with the baseline-window approach.
        let cfg = ProfilerConfig::default(); // k=2.0, baseline_fraction=0.25

        // 6 idle samples (300 ms) + 10 burst samples (500 ms) + 5 idle tail.
        let mut samples: Vec<Sample> = (0..6)
            .map(|i| make_sample(i * 50, 0.0, 100 * 1024 * 1024))
            .collect();
        for i in 0..10 {
            samples.push(make_sample(300 + i * 50, 95.0, 100 * 1024 * 1024));
        }
        for i in 0..5 {
            samples.push(make_sample(800 + i * 50, 0.0, 100 * 1024 * 1024));
        }

        let events = detect_spikes(&samples, &cfg);
        let cpu_spikes: Vec<_> = events
            .iter()
            .filter(|e| matches!(e.kind, SpikeKind::Cpu))
            .collect();

        // Baseline window (0–25% of ~1000 ms = first 250 ms, 5 samples) has
        // mean=0, σ=0, threshold=max(0+2*0, 0+15)=15%.  All 95% samples spike.
        assert_eq!(
            cpu_spikes.len(),
            1,
            "expected 1 spike, got {}",
            cpu_spikes.len()
        );
        assert_eq!(cpu_spikes[0].start_ms, 300);
        assert!((cpu_spikes[0].peak_value - 95.0).abs() < 1e-9);
    }

    #[test]
    fn test_hot_paths_empty() {
        assert!(aggregate_hot_paths(&[], 20).is_empty());
    }

    #[test]
    fn test_hot_paths_no_stacks() {
        let samples: Vec<Sample> = (0..5).map(|i| make_sample(i * 50, 5.0, 100_000)).collect();
        assert!(aggregate_hot_paths(&samples, 20).is_empty());
    }

    #[test]
    fn test_hot_paths_frequency_order() {
        let stack_a = make_stack(&[("a.py", "foo", 1)]);
        let stack_b = make_stack(&[("b.py", "bar", 2)]);

        let samples = vec![
            Sample {
                timestamp_ms: 0,
                cpu_percent: 5.0,
                rss_bytes: 1024,
                stack: Some(stack_a.clone()),
            },
            Sample {
                timestamp_ms: 50,
                cpu_percent: 5.0,
                rss_bytes: 1024,
                stack: Some(stack_a.clone()),
            },
            Sample {
                timestamp_ms: 100,
                cpu_percent: 5.0,
                rss_bytes: 1024,
                stack: Some(stack_a),
            },
            Sample {
                timestamp_ms: 150,
                cpu_percent: 5.0,
                rss_bytes: 1024,
                stack: Some(stack_b),
            },
        ];

        let paths = aggregate_hot_paths(&samples, 20);
        assert_eq!(paths[0].function, "foo");
        assert_eq!(paths[0].count, 3);
        assert_eq!(paths[1].function, "bar");
        assert_eq!(paths[1].count, 1);
    }

    #[test]
    fn test_hot_paths_top_n_limit() {
        let samples: Vec<Sample> = (0..10)
            .map(|i| {
                let stack = make_stack(&[(&format!("file{i}.py"), &format!("fn{i}"), i as i32)]);
                Sample {
                    timestamp_ms: i * 50,
                    cpu_percent: 5.0,
                    rss_bytes: 1024,
                    stack: Some(stack),
                }
            })
            .collect();

        let paths = aggregate_hot_paths(&samples, 3);
        assert_eq!(paths.len(), 3);
    }
}
