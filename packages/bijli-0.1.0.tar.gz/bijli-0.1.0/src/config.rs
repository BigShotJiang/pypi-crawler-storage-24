/// Runtime configuration for the Bijli profiler.
///
/// All tunable parameters are centralised here with validated defaults.
#[derive(Debug, Clone)]
pub struct ProfilerConfig {
    /// Sampling interval in milliseconds. Default: 50. Range: [1, 10_000].
    pub interval_ms: u64,

    /// Ring buffer capacity (number of samples). Default: 100_000.
    /// At 50ms interval this covers ~83 minutes before any sample loss.
    pub ring_buffer_capacity: usize,

    /// RSS delta (bytes) that triggers a conditional tracemalloc snapshot.
    /// Default: 10 MB.
    pub mem_spike_threshold_bytes: u64,

    /// How long tracemalloc stays active after a spike is detected (ms).
    /// Default: 500ms.
    pub tracemalloc_duration_ms: u64,

    /// Minimum cooldown between tracemalloc activations (ms). Default: 5_000.
    pub tracemalloc_cooldown_ms: u64,

    /// Number of tracemalloc call stack frames to capture. Default: 10.
    pub tracemalloc_frames: usize,

    /// CPU spike threshold multiplier (mean + N*sigma). Default: 2.0.
    pub spike_sigma_multiplier: f64,

    /// Absolute minimum CPU spike height (percent). Default: 15.0.
    /// Prevents false positives in low-variance workloads.
    pub cpu_spike_floor: f64,

    /// Absolute minimum memory spike size (bytes). Default: 5 MB.
    pub mem_spike_floor_bytes: u64,

    /// Maximum number of hot-path frames returned by `stop()`. Default: 20.
    pub top_n: usize,

    /// Fraction of recording used as the baseline window for spike detection.
    ///
    /// Only samples whose wall-time timestamp falls within the first
    /// `spike_baseline_fraction * total_duration` of the recording are used
    /// to compute the Welford mean and σ.  The resulting threshold is then
    /// applied across **all** samples.
    ///
    /// Using a leading baseline window prevents the spike itself from pulling
    /// the mean up and inflating the threshold, which would cause the spike
    /// to be missed.  When fewer than 5 samples fall in the window the
    /// algorithm falls back to using all samples.
    ///
    /// Default: 0.25 (first quarter of the recording).
    pub spike_baseline_fraction: f64,
}

impl Default for ProfilerConfig {
    fn default() -> Self {
        Self {
            interval_ms: 50,
            ring_buffer_capacity: 100_000,
            mem_spike_threshold_bytes: 10 * 1024 * 1024, // 10 MB
            tracemalloc_duration_ms: 500,
            tracemalloc_cooldown_ms: 5_000,
            tracemalloc_frames: 10,
            spike_sigma_multiplier: 2.0,
            cpu_spike_floor: 15.0,
            mem_spike_floor_bytes: 5 * 1024 * 1024, // 5 MB
            top_n: 20,
            spike_baseline_fraction: 0.25,
        }
    }
}

impl ProfilerConfig {
    /// Validate configuration, returning an error message if any value is invalid.
    pub fn validate(&self) -> Result<(), String> {
        if self.interval_ms == 0 || self.interval_ms > 10_000 {
            return Err(format!(
                "interval_ms must be in [1, 10000], got {}",
                self.interval_ms
            ));
        }
        if self.ring_buffer_capacity == 0 {
            return Err("ring_buffer_capacity must be > 0".into());
        }
        if self.spike_sigma_multiplier < 0.0 {
            return Err(format!(
                "spike_sigma_multiplier must be >= 0, got {}",
                self.spike_sigma_multiplier
            ));
        }
        if self.tracemalloc_frames == 0 {
            return Err("tracemalloc_frames must be > 0".into());
        }
        if !(0.0..=1.0).contains(&self.spike_baseline_fraction) {
            return Err(format!(
                "spike_baseline_fraction must be in [0, 1], got {}",
                self.spike_baseline_fraction
            ));
        }
        Ok(())
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_default_config_is_valid() {
        let cfg = ProfilerConfig::default();
        assert!(cfg.validate().is_ok());
    }

    #[test]
    fn test_interval_zero_is_invalid() {
        let cfg = ProfilerConfig {
            interval_ms: 0,
            ..ProfilerConfig::default()
        };
        assert!(cfg.validate().is_err());
    }

    #[test]
    fn test_interval_too_large_is_invalid() {
        let cfg = ProfilerConfig {
            interval_ms: 10_001,
            ..ProfilerConfig::default()
        };
        assert!(cfg.validate().is_err());
    }

    #[test]
    fn test_zero_ring_capacity_is_invalid() {
        let cfg = ProfilerConfig {
            ring_buffer_capacity: 0,
            ..ProfilerConfig::default()
        };
        assert!(cfg.validate().is_err());
    }

    #[test]
    fn test_negative_sigma_is_invalid() {
        let cfg = ProfilerConfig {
            spike_sigma_multiplier: -1.0,
            ..ProfilerConfig::default()
        };
        assert!(cfg.validate().is_err());
    }

    #[test]
    fn test_zero_tracemalloc_frames_is_invalid() {
        let cfg = ProfilerConfig {
            tracemalloc_frames: 0,
            ..ProfilerConfig::default()
        };
        assert!(cfg.validate().is_err());
    }

    #[test]
    fn test_default_values() {
        let cfg = ProfilerConfig::default();
        assert_eq!(cfg.interval_ms, 50);
        assert_eq!(cfg.ring_buffer_capacity, 100_000);
        assert_eq!(cfg.mem_spike_threshold_bytes, 10 * 1024 * 1024);
        assert_eq!(cfg.tracemalloc_cooldown_ms, 5_000);
        assert_eq!(cfg.spike_sigma_multiplier, 2.0);
        assert_eq!(cfg.cpu_spike_floor, 15.0);
    }
}
