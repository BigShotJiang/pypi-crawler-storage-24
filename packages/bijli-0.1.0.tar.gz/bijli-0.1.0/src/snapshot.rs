/// Serialise Rust profiler data structures into Python objects via PyO3.
///
/// All functions in this module require the GIL (proven by the `Python<'_>`
/// token) and return `PyResult<PyObject>` so that the caller can propagate
/// any allocation errors back to Python.
use pyo3::prelude::*;
use pyo3::types::{PyDict, PyList};

use crate::sampler::{Sample, SampleData};
use crate::spikes::{HotPath, SpikeEvent, SpikeKind};
use crate::stack::StackSnapshot;

// ---------------------------------------------------------------------------
// Internal helpers
// ---------------------------------------------------------------------------

/// Serialise a `StackSnapshot` as a Python `list[dict]`.
///
/// Each dict has keys: `"file"`, `"function"`, `"line"`.
/// Frames are ordered bottom-to-top (outermost caller first).
fn stack_to_py(py: Python<'_>, stack: &StackSnapshot) -> PyResult<PyObject> {
    let list = PyList::empty_bound(py);
    for frame in &stack.frames {
        let d = PyDict::new_bound(py);
        d.set_item("file", &frame.filename)?;
        d.set_item("function", &frame.function)?;
        d.set_item("line", frame.lineno)?;
        list.append(d)?;
    }
    Ok(list.into())
}

/// Serialise one `Sample` as a Python dict.
///
/// Keys: `"timestamp_ms"`, `"cpu_percent"`, `"rss_bytes"`, `"stack"`.
/// `"stack"` is `None` when no Python frames were captured.
fn sample_to_py(py: Python<'_>, sample: &Sample) -> PyResult<PyObject> {
    let d = PyDict::new_bound(py);
    d.set_item("timestamp_ms", sample.timestamp_ms)?;
    d.set_item("cpu_percent", sample.cpu_percent)?;
    d.set_item("rss_bytes", sample.rss_bytes)?;
    match &sample.stack {
        Some(stack) => d.set_item("stack", stack_to_py(py, stack)?)?,
        None => d.set_item("stack", py.None())?,
    }
    Ok(d.into())
}

/// Serialise a `SpikeEvent` as a Python dict.
///
/// Keys: `"kind"` (`"cpu"` or `"memory"`), `"start_ms"`, `"end_ms"`,
/// `"peak_value"`, `"threshold"`, `"peak_stack"` (list or `None`).
fn spike_to_py(py: Python<'_>, event: &SpikeEvent) -> PyResult<PyObject> {
    let d = PyDict::new_bound(py);
    d.set_item(
        "kind",
        match event.kind {
            SpikeKind::Cpu => "cpu",
            SpikeKind::Memory => "memory",
        },
    )?;
    d.set_item("start_ms", event.start_ms)?;
    d.set_item("end_ms", event.end_ms)?;
    d.set_item("peak_value", event.peak_value)?;
    d.set_item("threshold", event.threshold)?;
    match &event.peak_stack {
        Some(stack) => d.set_item("peak_stack", stack_to_py(py, stack)?)?,
        None => d.set_item("peak_stack", py.None())?,
    }
    Ok(d.into())
}

/// Serialise a `HotPath` as a Python dict.
///
/// Keys: `"file"`, `"function"`, `"line"`, `"count"`, `"percent"`.
fn hot_path_to_py(py: Python<'_>, path: &HotPath) -> PyResult<PyObject> {
    let d = PyDict::new_bound(py);
    d.set_item("file", &path.filename)?;
    d.set_item("function", &path.function)?;
    d.set_item("line", path.lineno)?;
    d.set_item("count", path.count)?;
    d.set_item("percent", path.percent)?;
    Ok(d.into())
}

// ---------------------------------------------------------------------------
// Public API
// ---------------------------------------------------------------------------

/// Build the complete profile-result dict returned to Python by `stop()`.
///
/// Top-level keys:
/// - `"sample_count"` — total number of samples collected
/// - `"wall_time_ms"` — wall-clock duration of the profiling session
/// - `"samples"` — list of per-sample dicts (see `sample_to_py`)
/// - `"spike_events"` — list of detected spike dicts (see `spike_to_py`)
/// - `"hot_paths"` — list of top-N frame dicts (see `hot_path_to_py`)
pub fn build_profile_result(
    py: Python<'_>,
    data: SampleData,
    spike_events: Vec<SpikeEvent>,
    hot_paths: Vec<HotPath>,
) -> PyResult<PyObject> {
    let result = PyDict::new_bound(py);

    result.set_item("sample_count", data.samples.len())?;
    result.set_item("wall_time_ms", data.wall_time_ms)?;

    let samples_list = PyList::empty_bound(py);
    for sample in &data.samples {
        samples_list.append(sample_to_py(py, sample)?)?;
    }
    result.set_item("samples", samples_list)?;

    let spikes_list = PyList::empty_bound(py);
    for event in &spike_events {
        spikes_list.append(spike_to_py(py, event)?)?;
    }
    result.set_item("spike_events", spikes_list)?;

    let paths_list = PyList::empty_bound(py);
    for path in &hot_paths {
        paths_list.append(hot_path_to_py(py, path)?)?;
    }
    result.set_item("hot_paths", paths_list)?;

    Ok(result.into())
}
