// PyO3 0.22's #[pymethods] macro emits `PyErr::from(e)` where e is already a
// PyErr, triggering clippy::useless_conversion.  Allow it for the whole file.
#![allow(clippy::useless_conversion)]

use std::sync::atomic::Ordering;

use pyo3::prelude::*;
use pyo3::types::PyModule;

pub mod config;
pub mod ringbuf;
pub mod sampler;
pub mod snapshot;
pub mod spikes;
pub mod stack;
pub mod sysinfo;

use config::ProfilerConfig;
use sampler::Sampler;
use snapshot::build_profile_result;
use spikes::{aggregate_hot_paths, detect_spikes};

// ---------------------------------------------------------------------------
// PySampler — Python-facing wrapper around the Rust Sampler
// ---------------------------------------------------------------------------

/// Python class that drives the Rust background sampler.
///
/// Usage from Python::
///
///     s = bijli._core.PySampler()
///     s.start()
///     # ... code under profiling ...
///     result = s.stop()   # returns a dict with all profiling data
#[pyclass]
pub struct PySampler {
    /// `None` after `stop()` has been called (consumed once).
    inner: Option<Sampler>,
    /// Kept after `inner` is consumed so analysis can use the config.
    config: ProfilerConfig,
}

#[pymethods]
impl PySampler {
    /// Create a new sampler.
    ///
    /// Parameters
    /// ----------
    /// interval_ms : int
    ///     Sampling interval in milliseconds. Default: 50.
    /// top_n : int
    ///     Maximum number of hot-path frames in the result. Default: 20.
    #[new]
    #[pyo3(signature = (*, interval_ms = 50, top_n = 20))]
    fn new(interval_ms: u64, top_n: usize) -> PyResult<Self> {
        let config = ProfilerConfig {
            interval_ms,
            top_n,
            ..ProfilerConfig::default()
        };
        config
            .validate()
            .map_err(pyo3::exceptions::PyValueError::new_err)?;
        Ok(PySampler {
            inner: Some(Sampler::new(config.clone())),
            config,
        })
    }

    /// Start the background sampling thread.
    fn start(&mut self) -> PyResult<()> {
        match &mut self.inner {
            Some(s) => {
                s.start();
                Ok(())
            }
            None => Err(pyo3::exceptions::PyRuntimeError::new_err(
                "PySampler has already been stopped",
            )),
        }
    }

    /// Stop the sampler, run analysis, and return a profile-result dict.
    ///
    /// The returned dict contains:
    ///
    /// - ``sample_count`` — number of samples collected
    /// - ``wall_time_ms`` — wall-clock duration in milliseconds
    /// - ``samples`` — list of per-sample dicts
    /// - ``spike_events`` — list of detected spike dicts
    /// - ``hot_paths`` — list of top-N frame dicts
    ///
    /// Releases the GIL while joining the sampler thread to prevent
    /// deadlocks with the sampler's own brief GIL acquisitions (stack
    /// capture).
    fn stop(&mut self, py: Python<'_>) -> PyResult<PyObject> {
        match self.inner.take() {
            Some(mut s) => {
                // Release GIL while joining — sampler thread calls with_gil.
                let data = py.allow_threads(|| s.stop());

                // Pure-Rust analysis — no GIL needed, but we're back to
                // holding it so we can allocate Python objects afterwards.
                let spike_events = detect_spikes(&data.samples, &self.config);
                let hot_paths = aggregate_hot_paths(&data.samples, self.config.top_n);

                build_profile_result(py, data, spike_events, hot_paths)
            }
            None => Err(pyo3::exceptions::PyRuntimeError::new_err(
                "PySampler has already been stopped",
            )),
        }
    }

    /// Return `True` if a memory spike has been detected since the last
    /// call to `notify_snapshot_taken()`.
    fn mem_spike_flag(&self) -> bool {
        match &self.inner {
            Some(s) => s.mem_spike_flag.load(Ordering::Acquire),
            None => false,
        }
    }

    /// Clear the memory spike flag after the Python watcher has taken a
    /// tracemalloc snapshot.
    fn notify_snapshot_taken(&self) {
        if let Some(s) = &self.inner {
            s.mem_spike_flag.store(false, Ordering::Release);
        }
    }

    /// Return `True` if the sampler thread is currently running.
    fn is_running(&self) -> bool {
        self.inner.as_ref().is_some_and(|s| s.is_running())
    }
}

// ---------------------------------------------------------------------------
// Module entry point
// ---------------------------------------------------------------------------

/// Bijli profiler core extension module.
#[pymodule]
fn _core(m: &Bound<'_, PyModule>) -> PyResult<()> {
    m.add("__version__", "0.1.0-dev")?;
    m.add_class::<PySampler>()?;
    Ok(())
}
