use std::ffi::CStr;
use std::hash::{Hash, Hasher};

use pyo3::prelude::*;
use pyo3::types::PyDict;
use rustc_hash::FxHasher;

/// Information about a single Python stack frame.
#[derive(Debug, Clone, PartialEq, Eq, Hash)]
pub struct FrameInfo {
    pub filename: String,
    pub function: String,
    pub lineno: i32,
}

/// A deduplicated snapshot of a Python call stack.
///
/// `frames` is ordered bottom-to-top (outermost → innermost callee).
/// `hash` is a fast FxHash of the full frame chain for deduplication.
#[derive(Debug, Clone)]
pub struct StackSnapshot {
    pub frames: Vec<FrameInfo>,
    pub hash: u64,
}

/// Capture the current Python call stack for all threads.
///
/// Must be called while holding the GIL (Python<'_> token proves this).
/// Returns `None` if no frames are available (e.g., interpreter is idle).
///
/// Strategy: prefer the main thread's frame. Background library threads
/// (e.g. MemWatcher) can accumulate deeper stacks than user code, causing
/// the "deepest stack" heuristic to report internal frames instead of user
/// frames. The main thread is almost always the right thread to profile.
/// Falls back to deepest stack if the main thread has no active frame.
pub fn capture_stack(py: Python<'_>) -> Option<StackSnapshot> {
    // sys._current_frames() → {thread_id: frame} for all Python threads.
    let sys = py.import_bound("sys").ok()?;
    let frames_obj = sys.call_method0("_current_frames").ok()?;
    let frames_dict = frames_obj.downcast::<PyDict>().ok()?;

    // Look up the main thread's frame using dict.get(main_tid).
    // We call frames_dict.get(ident) as a Python method so PyO3's dict key
    // API differences across versions don't affect us.
    let main_frame: Option<Vec<FrameInfo>> = (|| {
        let threading = py.import_bound("threading").ok()?;
        let main_thread = threading.call_method0("main_thread").ok()?;
        let ident = main_thread.getattr("ident").ok()?;
        if ident.is_none() {
            return None;
        }
        let frame_val = frames_obj.call_method1("get", (ident,)).ok()?;
        if frame_val.is_none() {
            return None;
        }
        let frames = walk_frame_chain(frame_val.as_ptr());
        if frames.is_empty() {
            None
        } else {
            Some(frames)
        }
    })();

    if let Some(frames) = main_frame {
        return Some(make_snapshot(frames));
    }

    // Fallback: keep the deepest stack across all threads.
    let mut best_frames: Vec<FrameInfo> = Vec::new();
    for (_, frame_val) in frames_dict.iter() {
        let frames = walk_frame_chain(frame_val.as_ptr());
        if frames.len() > best_frames.len() {
            best_frames = frames;
        }
    }

    if best_frames.is_empty() {
        return None;
    }
    Some(make_snapshot(best_frames))
}

fn make_snapshot(frames: Vec<FrameInfo>) -> StackSnapshot {
    let mut hasher = FxHasher::default();
    for f in &frames {
        f.hash(&mut hasher);
    }
    StackSnapshot {
        frames,
        hash: hasher.finish(),
    }
}

/// Walk a `PyFrameObject*` chain collecting `FrameInfo` for each frame.
///
/// Returns frames in bottom-to-top order (outermost caller first).
///
/// # Safety invariants
/// - `frame_ptr` comes from `sys._current_frames()`, GIL is held, so the
///   frame is alive for the duration of this call.
/// - `f_code` attribute lookup returns a new strong reference; we decrement it.
/// - Back-frame traversal uses the `f_back` attribute (stable public API).
/// - `PyErr_Clear` is called after any failed lookup to avoid leaving a
///   pending exception.
/// - `PyFrame_GetCode` and `PyUnicode_AsUTF8` are not in the stable ABI
///   (Py_LIMITED_API); we use `PyObject_GetAttrString` and
///   `PyUnicode_AsEncodedString` instead, both of which are stable since 3.2.
fn walk_frame_chain(frame_ptr: *mut pyo3::ffi::PyObject) -> Vec<FrameInfo> {
    use pyo3::ffi;

    if frame_ptr.is_null() {
        return Vec::new();
    }

    let mut frames = Vec::with_capacity(32);

    // Increment refcount so we can handle all frames uniformly as owned refs.
    // SAFETY: frame_ptr is non-null, valid PyObject*, GIL held.
    unsafe { ffi::Py_INCREF(frame_ptr) };

    let mut cur = frame_ptr as *mut ffi::PyFrameObject;

    while !cur.is_null() {
        // Get the code object via the stable `f_code` attribute.
        // SAFETY: cur is valid non-null PyFrameObject*, GIL held.
        let code =
            unsafe { ffi::PyObject_GetAttrString(cur as *mut ffi::PyObject, c"f_code".as_ptr()) };
        let lineno = unsafe { ffi::PyFrame_GetLineNumber(cur) };

        if !code.is_null() {
            let filename = get_str_attr(code, c"co_filename");
            let function = get_str_attr(code, c"co_name");
            // SAFETY: code is a new strong ref from PyObject_GetAttrString.
            unsafe { ffi::Py_DECREF(code) };
            frames.push(FrameInfo {
                filename,
                function,
                lineno,
            });
        } else {
            unsafe { ffi::PyErr_Clear() };
        }

        // Advance to the outer frame via the `f_back` attribute.
        // PyFrame_GetBack is not available in all pyo3-ffi versions, so we
        // use PyObject_GetAttrString which is stable across all Python versions.
        // SAFETY: cur is valid, GIL held.
        let back_obj =
            unsafe { ffi::PyObject_GetAttrString(cur as *mut ffi::PyObject, c"f_back".as_ptr()) };

        // Release the current frame (owned ref).
        // SAFETY: cur is owned.
        unsafe { ffi::Py_DECREF(cur as *mut ffi::PyObject) };

        cur = if back_obj.is_null() {
            // Error (attribute missing) — clear exception and stop.
            unsafe { ffi::PyErr_Clear() };
            std::ptr::null_mut()
        } else {
            // f_back is Python None at the top of the call stack.
            // SAFETY: GIL held.
            let is_none = unsafe { back_obj == ffi::Py_None() };
            if is_none {
                unsafe { ffi::Py_DECREF(back_obj) };
                std::ptr::null_mut()
            } else {
                // back_obj is a new strong ref (PyObject_GetAttrString).
                back_obj as *mut ffi::PyFrameObject
            }
        };
    }

    // Walk produced innermost-first; reverse to bottom-to-top order.
    frames.reverse();
    frames
}

/// Extract a UTF-8 string attribute from a Python object.
///
/// Returns `"<unknown>"` on any failure, clearing any pending exception.
///
/// Uses `PyUnicode_AsEncodedString` (stable ABI since 3.2) instead of
/// `PyUnicode_AsUTF8`, which is not in `Py_LIMITED_API`.
fn get_str_attr(obj: *mut pyo3::ffi::PyObject, attr: &CStr) -> String {
    use pyo3::ffi;

    // SAFETY: obj is valid PyObject*, GIL held.
    let attr_obj = unsafe { ffi::PyObject_GetAttrString(obj, attr.as_ptr()) };

    if attr_obj.is_null() {
        unsafe { ffi::PyErr_Clear() };
        return "<unknown>".to_owned();
    }

    // Encode to UTF-8 bytes via the stable ABI.
    // SAFETY: attr_obj is valid, GIL held.
    let bytes_obj =
        unsafe { ffi::PyUnicode_AsEncodedString(attr_obj, c"utf-8".as_ptr(), c"replace".as_ptr()) };

    let result = if bytes_obj.is_null() {
        unsafe { ffi::PyErr_Clear() };
        "<unknown>".to_owned()
    } else {
        // SAFETY: bytes_obj is a valid bytes object, GIL held.
        let char_ptr = unsafe { ffi::PyBytes_AsString(bytes_obj) };
        let s = if char_ptr.is_null() {
            unsafe { ffi::PyErr_Clear() };
            "<unknown>".to_owned()
        } else {
            // SAFETY: char_ptr is null-terminated, valid while bytes_obj is alive.
            // We copy into a String before decref.
            unsafe { CStr::from_ptr(char_ptr) }
                .to_string_lossy()
                .into_owned()
        };
        // SAFETY: bytes_obj is a new strong ref from PyUnicode_AsEncodedString.
        unsafe { ffi::Py_DECREF(bytes_obj) };
        s
    };

    // SAFETY: attr_obj is a new strong ref from PyObject_GetAttrString.
    unsafe { ffi::Py_DECREF(attr_obj) };
    result
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn frame_info_hash_is_deterministic() {
        let f = FrameInfo {
            filename: "foo.py".to_owned(),
            function: "bar".to_owned(),
            lineno: 42,
        };
        let mut h1 = FxHasher::default();
        f.hash(&mut h1);
        let mut h2 = FxHasher::default();
        f.hash(&mut h2);
        assert_eq!(h1.finish(), h2.finish());
    }

    #[test]
    fn different_frames_have_different_hashes() {
        let f1 = FrameInfo {
            filename: "a.py".to_owned(),
            function: "foo".to_owned(),
            lineno: 1,
        };
        let f2 = FrameInfo {
            filename: "b.py".to_owned(),
            function: "bar".to_owned(),
            lineno: 2,
        };
        let mut h1 = FxHasher::default();
        f1.hash(&mut h1);
        let mut h2 = FxHasher::default();
        f2.hash(&mut h2);
        assert_ne!(h1.finish(), h2.finish());
    }
}
