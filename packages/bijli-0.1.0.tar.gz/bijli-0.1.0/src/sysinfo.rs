use std::time::Instant;

/// CPU and RSS metrics snapshot.
#[derive(Debug, Clone)]
pub struct SysMetrics {
    /// CPU usage percentage since last call.
    /// Range: [0.0, num_logical_cores * 100.0].
    /// Returns -1.0 if the read failed (sentinel value, not a panic).
    pub cpu_percent: f64,
    /// Resident set size (physical memory) in bytes.
    pub rss_bytes: u64,
}

// ---------------------------------------------------------------------------
// Linux implementation
// ---------------------------------------------------------------------------

#[cfg(target_os = "linux")]
mod platform {
    use super::{Instant, SysMetrics};
    use std::fs;

    /// Parse `/proc/self/stat` to extract utime + stime (fields 14–15, jiffies).
    /// Returns `None` if the file is unreadable or the format is unexpected.
    fn read_cpu_ticks() -> Option<u64> {
        let data = fs::read("/proc/self/stat").ok()?;

        // Fields are space-separated. The comm field (field 2) can contain spaces
        // and is wrapped in parentheses. Skip past the closing ')'.
        let after_comm = data.iter().rposition(|&b| b == b')')?;
        let rest = &data[after_comm + 1..];

        // Fields after comm start at index 1 (field 3 in proc(5) numbering).
        // We need fields 14 (utime) and 15 (stime), which are at positions 11 and 12
        // in `rest` (0-indexed after the space following ')').
        let mut fields = rest.split(|&b| b == b' ').filter(|f| !f.is_empty());
        let _skip: Vec<_> = fields.by_ref().take(11).collect(); // skip fields 3–13
        let utime = fields.next().and_then(parse_u64)?;
        let stime = fields.next().and_then(parse_u64)?;

        Some(utime + stime)
    }

    fn parse_u64(b: &[u8]) -> Option<u64> {
        std::str::from_utf8(b).ok()?.trim().parse().ok()
    }

    /// Parse VmRSS from `/proc/self/status` in bytes.
    fn read_rss_bytes() -> u64 {
        let data = match fs::read("/proc/self/status") {
            Ok(d) => d,
            Err(_) => return 0,
        };

        for line in data.split(|&b| b == b'\n') {
            if line.starts_with(b"VmRSS:") {
                // Line looks like "VmRSS:\t12345 kB" (tab-separated on Linux)
                let tail = &line[6..];
                if let Some(kb) = tail
                    .split(|&b: &u8| b.is_ascii_whitespace())
                    .find(|f| !f.is_empty())
                    .and_then(parse_u64)
                {
                    return kb * 1024;
                }
            }
        }
        0
    }

    fn clk_tck() -> u64 {
        // SAFETY: sysconf is async-signal-safe and always succeeds for _SC_CLK_TCK
        let tck = unsafe { libc::sysconf(libc::_SC_CLK_TCK) };
        if tck <= 0 {
            100
        } else {
            tck as u64
        }
    }

    pub fn read_metrics(prev_cpu_ticks: &mut u64, prev_wall: &mut Instant) -> SysMetrics {
        let now = Instant::now();
        let wall_delta = now.duration_since(*prev_wall).as_secs_f64();

        let cpu_ticks = read_cpu_ticks();
        let rss_bytes = read_rss_bytes();

        let cpu_percent = match cpu_ticks {
            None => -1.0, // sentinel: /proc unreadable
            Some(ticks) => {
                let cpu = if wall_delta > 0.0 && *prev_cpu_ticks > 0 {
                    let delta_ticks = ticks.saturating_sub(*prev_cpu_ticks);
                    let ticks_per_sec = clk_tck() as f64;
                    // CPU% = (delta_ticks / ticks_per_sec) / wall_delta * 100
                    (delta_ticks as f64 / ticks_per_sec / wall_delta) * 100.0
                } else {
                    0.0
                };
                *prev_cpu_ticks = ticks;
                cpu.max(0.0)
            }
        };

        *prev_wall = now;

        SysMetrics {
            cpu_percent,
            rss_bytes,
        }
    }
}

// ---------------------------------------------------------------------------
// macOS implementation
// ---------------------------------------------------------------------------

#[cfg(target_os = "macos")]
mod platform {
    use super::{Instant, SysMetrics};

    /// Read CPU time (user+sys) in microseconds and RSS in bytes via
    /// `getrusage(RUSAGE_SELF)`.  This is a single fast syscall with no
    /// sandbox restrictions, unlike `proc_pidinfo` which can be slow or
    /// unavailable in CI environments.
    ///
    /// Note: `ru_maxrss` on macOS is in bytes (Linux reports kilobytes).
    pub fn read_metrics(prev_cpu_us: &mut u64, prev_wall: &mut Instant) -> SysMetrics {
        let now = Instant::now();
        let wall_delta = now.duration_since(*prev_wall).as_secs_f64();

        // SAFETY: rusage is a plain C struct; zero-init is a valid initial state.
        let mut usage: libc::rusage = unsafe { std::mem::zeroed() };
        // SAFETY: RUSAGE_SELF is always a valid argument; &mut usage is valid.
        let ok = unsafe { libc::getrusage(libc::RUSAGE_SELF, &mut usage) } == 0;

        let (rss_bytes, cpu_us_total) = if ok {
            let rss = usage.ru_maxrss as u64; // bytes on macOS
            let user_us = usage.ru_utime.tv_sec as u64 * 1_000_000 + usage.ru_utime.tv_usec as u64;
            let sys_us = usage.ru_stime.tv_sec as u64 * 1_000_000 + usage.ru_stime.tv_usec as u64;
            (rss, user_us + sys_us)
        } else {
            (0, 0)
        };

        let cpu_percent = if ok && wall_delta > 0.0 && *prev_cpu_us > 0 {
            let delta_us = cpu_us_total.saturating_sub(*prev_cpu_us);
            let wall_us = (wall_delta * 1e6) as u64;
            if wall_us > 0 {
                (delta_us as f64 / wall_us as f64) * 100.0
            } else {
                0.0
            }
        } else {
            0.0
        };

        *prev_cpu_us = cpu_us_total;
        *prev_wall = now;

        SysMetrics {
            cpu_percent: if ok { cpu_percent.max(0.0) } else { -1.0 },
            rss_bytes,
        }
    }
}

// ---------------------------------------------------------------------------
// Windows implementation
// ---------------------------------------------------------------------------

#[cfg(target_os = "windows")]
mod platform {
    use super::{Instant, SysMetrics};
    use windows_sys::Win32::Foundation::FILETIME;
    use windows_sys::Win32::System::ProcessStatus::{
        GetProcessMemoryInfo, PROCESS_MEMORY_COUNTERS,
    };
    use windows_sys::Win32::System::Threading::{GetCurrentProcess, GetProcessTimes};

    fn filetime_to_u64(ft: FILETIME) -> u64 {
        ((ft.dwHighDateTime as u64) << 32) | (ft.dwLowDateTime as u64)
    }

    pub fn read_metrics(prev_cpu_100ns: &mut u64, prev_wall: &mut Instant) -> SysMetrics {
        let now = Instant::now();
        let wall_delta = now.duration_since(*prev_wall).as_secs_f64();

        // SAFETY: GetCurrentProcess() returns a pseudo-handle, always valid.
        let handle = unsafe { GetCurrentProcess() };

        let mut cpu_100ns_total = 0u64;
        let mut rss_bytes = 0u64;

        unsafe {
            let mut creation = FILETIME {
                dwLowDateTime: 0,
                dwHighDateTime: 0,
            };
            let mut exit = FILETIME {
                dwLowDateTime: 0,
                dwHighDateTime: 0,
            };
            let mut kernel = FILETIME {
                dwLowDateTime: 0,
                dwHighDateTime: 0,
            };
            let mut user = FILETIME {
                dwLowDateTime: 0,
                dwHighDateTime: 0,
            };

            if GetProcessTimes(handle, &mut creation, &mut exit, &mut kernel, &mut user) != 0 {
                cpu_100ns_total = filetime_to_u64(kernel) + filetime_to_u64(user);
            }

            let mut pmc: PROCESS_MEMORY_COUNTERS = std::mem::zeroed();
            pmc.cb = std::mem::size_of::<PROCESS_MEMORY_COUNTERS>() as u32;
            if GetProcessMemoryInfo(handle, &mut pmc, pmc.cb) != 0 {
                rss_bytes = pmc.WorkingSetSize as u64;
            }
        }

        let cpu_percent = if wall_delta > 0.0 && *prev_cpu_100ns > 0 {
            let delta_cpu = cpu_100ns_total.saturating_sub(*prev_cpu_100ns);
            // wall_delta in 100-ns units
            let wall_100ns = (wall_delta * 1e7) as u64;
            if wall_100ns > 0 {
                (delta_cpu as f64 / wall_100ns as f64) * 100.0
            } else {
                0.0
            }
        } else {
            0.0
        };

        *prev_cpu_100ns = cpu_100ns_total;
        *prev_wall = now;

        SysMetrics {
            cpu_percent: cpu_percent.max(0.0),
            rss_bytes,
        }
    }
}

// ---------------------------------------------------------------------------
// Public API (delegates to platform module)
// ---------------------------------------------------------------------------

/// Read CPU% and RSS for the current process.
///
/// `prev_cpu_ticks` and `prev_wall` are updated in place for delta computation.
/// On the first call, pass `prev_cpu_ticks = 0` and `prev_wall = Instant::now()`.
///
/// CPU% is relative to one core: 100% = one full core, 200% = two cores saturated.
/// Returns `cpu_percent = -1.0` on read failure — caller should treat as missing data.
pub fn read_metrics(prev_cpu_ticks: &mut u64, prev_wall: &mut Instant) -> SysMetrics {
    platform::read_metrics(prev_cpu_ticks, prev_wall)
}

// ---------------------------------------------------------------------------
// Tests
// ---------------------------------------------------------------------------

#[cfg(test)]
mod tests {
    use super::*;
    use std::time::Duration;

    #[test]
    fn test_rss_is_positive() {
        let mut prev_ticks = 0u64;
        let mut prev_wall = Instant::now();
        std::thread::sleep(Duration::from_millis(10));
        let m = read_metrics(&mut prev_ticks, &mut prev_wall);
        assert!(
            m.rss_bytes > 0,
            "RSS should be positive, got {}",
            m.rss_bytes
        );
    }

    #[test]
    fn test_cpu_range_after_warmup() {
        let mut prev_ticks = 0u64;
        let mut prev_wall = Instant::now();

        // First call: establishes baseline
        std::thread::sleep(Duration::from_millis(50));
        let _ = read_metrics(&mut prev_ticks, &mut prev_wall);

        // Second call: computes actual delta
        std::thread::sleep(Duration::from_millis(50));
        let m = read_metrics(&mut prev_ticks, &mut prev_wall);

        // cpu_percent can be -1.0 on error, otherwise should be non-negative
        if m.cpu_percent >= 0.0 {
            // Upper bound: 100% * number of logical CPUs (at most)
            // We use a generous 3200% (32 cores) upper bound for any realistic machine
            assert!(
                m.cpu_percent < 3200.0,
                "CPU% implausibly high: {}",
                m.cpu_percent
            );
        }
    }

    #[test]
    fn test_latency() {
        let mut prev_ticks = 0u64;
        let mut prev_wall = Instant::now();

        // Warmup
        std::thread::sleep(Duration::from_millis(20));
        let _ = read_metrics(&mut prev_ticks, &mut prev_wall);

        // Measure just the read_metrics calls, excluding sleep jitter.
        let mut total_read = Duration::ZERO;
        for _ in 0..10 {
            std::thread::sleep(Duration::from_millis(10));
            let t = Instant::now();
            let _ = read_metrics(&mut prev_ticks, &mut prev_wall);
            total_read += t.elapsed();
        }
        // 10 calls should complete in well under 100ms total;
        // on CI runners allow generous 5ms per call average.
        assert!(
            total_read < Duration::from_millis(50),
            "read_metrics overhead too high: {:?} for 10 calls",
            total_read
        );
    }

    #[test]
    fn test_second_call_produces_delta() {
        let mut prev_ticks = 0u64;
        let mut prev_wall = Instant::now();

        // Burn some CPU so the second call should see non-zero cpu_percent
        std::thread::sleep(Duration::from_millis(50));
        let _ = read_metrics(&mut prev_ticks, &mut prev_wall);

        // Do actual CPU work
        let mut x = 0u64;
        for i in 0..1_000_000u64 {
            x = x.wrapping_add(i);
        }
        std::hint::black_box(x);

        let m = read_metrics(&mut prev_ticks, &mut prev_wall);
        // After doing CPU work, cpu_percent should be >= 0 (not sentinel -1.0)
        // (On a heavily loaded machine it could still be 0 if the loop was very fast)
        assert!(
            m.cpu_percent >= 0.0 || m.cpu_percent == -1.0,
            "Unexpected cpu_percent: {}",
            m.cpu_percent
        );
    }
}
