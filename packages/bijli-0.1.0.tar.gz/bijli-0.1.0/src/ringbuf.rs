/// Lock-free SPSC ring buffer with fixed capacity and overwrite-on-full semantics.
///
/// # Concurrency model
/// - One **producer** thread calls [`push`] exclusively.
/// - One **consumer** calls [`drain`] only *after* the producer has stopped
///   (i.e., after joining the producer thread).
/// - The thread-join gives the necessary happens-before edge, so all producer
///   writes are visible to the consumer without additional synchronisation.
///
/// # Allocation
/// The backing store is allocated once in [`new`].  [`push`] never allocates;
/// it writes into a pre-allocated slot.  [`drain`] allocates a `Vec` to return
/// the collected items — that is acceptable because it is not on the hot path.
use std::cell::UnsafeCell;
use std::mem::MaybeUninit;
use std::sync::atomic::{AtomicUsize, Ordering};

pub struct RingBuffer<T> {
    /// Pre-allocated backing store.
    buf: Box<[UnsafeCell<MaybeUninit<T>>]>,
    capacity: usize,
    /// Absolute write cursor.  Written *only* by the producer.
    head: AtomicUsize,
    /// Absolute read cursor.  Advanced by the producer on overflow; read by
    /// the consumer in [`drain`].
    tail: AtomicUsize,
}

// SAFETY: RingBuffer is SPSC.  The producer holds an `Arc<RingBuffer<T>>`
// during `push`; the consumer holds the other `Arc` and calls `drain` only
// after the producer thread is joined.  The two non-overlapping access
// windows make this sound as long as `T: Send`.
unsafe impl<T: Send> Send for RingBuffer<T> {}
unsafe impl<T: Send> Sync for RingBuffer<T> {}

impl<T> RingBuffer<T> {
    /// Create a new ring buffer with the given capacity.
    ///
    /// # Panics
    /// Panics if `capacity == 0`.
    pub fn new(capacity: usize) -> Self {
        assert!(capacity > 0, "RingBuffer capacity must be > 0");
        let buf = (0..capacity)
            .map(|_| UnsafeCell::new(MaybeUninit::uninit()))
            .collect::<Vec<_>>()
            .into_boxed_slice();
        Self {
            buf,
            capacity,
            head: AtomicUsize::new(0),
            tail: AtomicUsize::new(0),
        }
    }

    /// Push `value` into the buffer.  **Zero allocations on this path.**
    ///
    /// When the buffer is full the oldest item is silently dropped to make room.
    ///
    /// Must be called only from the single producer thread.
    pub fn push(&self, value: T) {
        let head = self.head.load(Ordering::Relaxed);
        let tail = self.tail.load(Ordering::Acquire);

        if head.wrapping_sub(tail) >= self.capacity {
            // Buffer is full: drop the oldest item and advance the tail.
            let idx = tail % self.capacity;
            // SAFETY: The slot at `tail` holds an initialized `T` that the
            // producer originally wrote.  We are the only writer of `tail`
            // when the buffer is full (consumer only runs post-join), so this
            // is exclusively owned here.
            unsafe { (*self.buf[idx].get()).assume_init_drop() };
            self.tail.store(tail.wrapping_add(1), Ordering::Release);
        }

        let idx = head % self.capacity;
        // SAFETY: `head` has not yet been published to the consumer (we
        // store it with Release below).  We exclusively own this slot.
        unsafe { (*self.buf[idx].get()).write(value) };
        self.head.store(head.wrapping_add(1), Ordering::Release);
    }

    /// Drain all buffered items into a `Vec`, oldest first.
    ///
    /// Must be called only after the producer thread has been joined.
    /// The buffer is left empty and ready for reuse after this call.
    pub fn drain(&self) -> Vec<T> {
        let head = self.head.load(Ordering::Acquire);
        let tail = self.tail.load(Ordering::Acquire);
        let count = head.wrapping_sub(tail);

        let mut out = Vec::with_capacity(count);
        for i in 0..count {
            let idx = (tail.wrapping_add(i)) % self.capacity;
            // SAFETY: Slots [tail, head) are initialised.  The producer has
            // stopped (caller ensures this via thread join), so no concurrent
            // access exists.
            let val = unsafe { (*self.buf[idx].get()).assume_init_read() };
            out.push(val);
        }

        // Reset to empty: consumer advances tail to head.
        self.tail.store(head, Ordering::Release);
        out
    }

    /// Number of items currently in the buffer.
    pub fn len(&self) -> usize {
        let head = self.head.load(Ordering::Acquire);
        let tail = self.tail.load(Ordering::Acquire);
        head.wrapping_sub(tail)
    }

    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }
}

impl<T> Drop for RingBuffer<T> {
    fn drop(&mut self) {
        // Drop all initialised items that haven't been drained yet.
        let head = *self.head.get_mut();
        let tail = *self.tail.get_mut();
        for i in 0..head.wrapping_sub(tail) {
            let idx = (tail.wrapping_add(i)) % self.capacity;
            // SAFETY: These slots are initialised; we have exclusive access
            // because `get_mut()` guarantees no other references exist.
            unsafe { (*self.buf[idx].get()).assume_init_drop() };
        }
    }
}

// ---------------------------------------------------------------------------
// Tests
// ---------------------------------------------------------------------------

#[cfg(test)]
mod tests {
    use super::*;
    use std::sync::Arc;

    #[test]
    fn test_push_and_drain_in_order() {
        let rb = RingBuffer::new(5);
        for i in 0u32..5 {
            rb.push(i);
        }
        assert_eq!(rb.drain(), vec![0, 1, 2, 3, 4]);
    }

    #[test]
    fn test_overflow_drops_oldest() {
        let rb = RingBuffer::new(3);
        for i in 0u32..6 {
            rb.push(i);
        }
        // Items 0-2 were overwritten; only 3, 4, 5 remain.
        assert_eq!(rb.drain(), vec![3, 4, 5]);
    }

    #[test]
    fn test_drain_empty_buffer() {
        let rb = RingBuffer::<u32>::new(4);
        assert_eq!(rb.drain(), vec![]);
    }

    #[test]
    fn test_drain_resets_and_reuse() {
        let rb = RingBuffer::new(4);
        rb.push(1u32);
        rb.push(2u32);
        assert_eq!(rb.drain(), vec![1, 2]);

        // Buffer should be empty and reusable.
        rb.push(3u32);
        assert_eq!(rb.drain(), vec![3]);
    }

    #[test]
    fn test_len_and_is_empty() {
        let rb = RingBuffer::new(4);
        assert!(rb.is_empty());
        rb.push(10u32);
        assert_eq!(rb.len(), 1);
        rb.push(20u32);
        assert_eq!(rb.len(), 2);
        rb.drain();
        assert!(rb.is_empty());
    }

    #[test]
    fn test_capacity_one() {
        let rb = RingBuffer::new(1);
        rb.push(42u32);
        rb.push(43u32); // overwrites 42
        assert_eq!(rb.drain(), vec![43]);
    }

    #[test]
    fn test_wrap_around_index_correctness() {
        // Push 2×capacity items; only the last `capacity` items should survive.
        let cap = 4usize;
        let rb = RingBuffer::new(cap);
        for i in 0u32..(cap as u32 * 2) {
            rb.push(i);
        }
        let items = rb.drain();
        assert_eq!(items.len(), cap);
        // Items 4-7 are the survivors.
        assert_eq!(items, vec![4, 5, 6, 7]);
    }

    #[test]
    fn test_producer_thread_then_drain() {
        let rb = Arc::new(RingBuffer::new(10));
        let rb2 = Arc::clone(&rb);

        let handle = std::thread::spawn(move || {
            for i in 0u32..8 {
                rb2.push(i);
            }
        });
        handle.join().unwrap();

        let items = rb.drain();
        assert_eq!(items, (0u32..8).collect::<Vec<_>>());
    }

    #[test]
    fn test_drop_does_not_leak() {
        // Ensure Drop is exercised for non-Copy T with heap allocation.
        {
            let rb = RingBuffer::new(4);
            rb.push("hello".to_owned());
            rb.push("world".to_owned());
            // Drop without drain — strings must be freed.
        }
        // If Miri / ASAN is in play this would catch leaks/UAF.
    }
}
