# Bijli — Rust-Powered Python Profiler — Refined Development Plan

> In-process · No sudo · CPU + Memory · Embeddable · PyPI-ready
> **Overhead target: < 2% CPU-bound, < 0.5% I/O-bound workloads**

```
pip install bijli
```

---

## Executive Summary

Bijli is a Rust-backed Python profiler distributed as a PyPI package. It runs in-process (same PID), requires zero elevated privileges, profiles both CPU and memory simultaneously, and exposes a clean Python API via a decorator and context manager.

The core architectural advantage over py-spy — the dominant tool in this space — is that py-spy's out-of-process design fundamentally requires ptrace/root, cannot profile memory, and cannot be embedded as a library. These are architectural constraints that cannot be patched. Bijli solves all three by design.

| Goal | Target | py-spy | cProfile+tracemalloc |
|---|---|---|---|
| Overhead (I/O-bound) | < 0.5% | ~1–3% | ~30–100% |
| Overhead (CPU-bound) | < 2% | ~1–3% | ~30–100% |
| Root required | Never | Always (ptrace) | Never |
| Memory profiling | Yes — RSS + conditional allocations | No — CPU only | Yes — always on (expensive) |
| Embeddable as library | `@profile`, `with Profile()` | CLI only | Programmatic but slow |
| Async-aware | Yes — in-process event loop detection | Distorted results | No |
| New Python version lag | Hours (stable C API) | Weeks (raw struct offsets) | None (stdlib) |

### Overhead Claim Qualification

The "< 0.5%" target applies to I/O-bound and mixed workloads where the CPU is not saturated. For tight CPU-bound loops, GIL acquisition adds measurable contention — the realistic target is < 2%. Both figures assume the default 50ms sampling interval. Increasing the interval reduces overhead proportionally.

---

## Architecture Overview

Two layers: a Rust core handling all hot-path work (sampling, ring buffer, spike detection, OS reads), and a thin Python facade exposing the ergonomic API. The boundary is a PyO3 extension module compiled into platform wheels.

```
┌─────────────────────────────────────────────────────────────┐
│  Python Facade                                              │
│  @profile decorator · Profile() context manager · CLI       │
│  Report renderer (ANSI) · tracemalloc watcher thread        │
├─────────────────────────────────────────────────────────────┤
│  PyO3 Bridge (_core.so / _core.pyd)                         │
│  Sampler class · start()/stop() · SampleData → Python dict  │
├─────────────────────────────────────────────────────────────┤
│  Rust Core                                                  │
│  Background thread · 50ms tick · CPU%/RSS reads             │
│  Stack capture via CPython C API · Ring buffer (SPSC)       │
│  Spike detection (Welford mean + 2σ) · Hot path aggregation │
├─────────────────────────────────────────────────────────────┤
│  OS Interfaces                                              │
│  Linux: /proc/self/stat, /proc/self/status                  │
│  macOS: proc_pidinfo(PROC_PIDTASKINFO)                      │
│  Windows: GetProcessTimes() + GetProcessMemoryInfo()        │
└─────────────────────────────────────────────────────────────┘
```

### Key Design Decisions

**No psutil dependency.** Reading `/proc/self/stat` directly in Rust costs ~3μs. psutil wraps the same file but adds Python object allocation overhead on every tick.

**Stack capture via CPython C API, not ptrace.** In-process means we call `PyThreadState_GET()` and walk `PyFrameObject*` chains directly. ~0.5μs per sample, zero privileges required.

**Conditional tracemalloc.** tracemalloc activates only when the Rust sampler detects an RSS delta exceeding a configurable threshold (default 10 MB) within a single tick. It stays on for 500ms, snapshots, then deactivates. Normal workloads pay zero tracemalloc cost.

**SPSC ring buffer for samples.** Samples stored in a pre-allocated single-producer/single-consumer ring buffer (default: 100,000 slots). The sampler thread is the sole writer; post-processing after `stop()` is the sole reader. No locks on the hot path — only atomic index updates.

**Spike detection in Rust.** After `stop()`, the Rust layer runs Welford's online algorithm for mean + 2σ spike detection across the entire sample set before returning data to Python. Python only handles rendering.

---

## Project Structure

```
bijli/
├── Cargo.toml                    # Rust crate manifest (PyO3 + maturin)
├── pyproject.toml                # Python package config (PEP 517, maturin backend)
├── .gitignore                    # Rust + Python + OS ignores
├── LICENSE                       # MIT
├── README.md                     # User-facing documentation
├── DEVELOPMENT_PLAN.md           # This file
├── CLAUDE.md                     # AI-assisted development guidelines
├── .github/
│   └── workflows/
│       ├── ci.yml                # Test + lint on every PR
│       └── release.yml           # Build wheels + publish to PyPI on tag
├── src/
│   ├── lib.rs                    # PyO3 #[pymodule] entry point
│   ├── sampler.rs                # Background thread, tick loop, lifecycle
│   ├── stack.rs                  # CPython frame walking
│   ├── sysinfo.rs                # OS-specific CPU + RSS reads
│   ├── ringbuf.rs                # SPSC ring buffer (atomic, no locks)
│   ├── spikes.rs                 # Statistical spike detection (Welford)
│   ├── snapshot.rs               # Sample → Python dict serialisation
│   └── config.rs                 # Runtime configuration defaults + validation
├── python/
│   └── bijli/
│       ├── __init__.py           # @profile, Profile(), public API
│       ├── _core.pyi             # Type stubs for IDE autocompletion
│       ├── report.py             # ANSI report renderer
│       └── cli.py                # `python -m bijli script.py` entry
└── tests/
    ├── rust/
    │   ├── test_sysinfo.rs       # OS read correctness + latency
    │   ├── test_ringbuf.rs       # Ring buffer semantics
    │   └── test_spikes.rs        # Spike detection accuracy
    └── python/
        ├── test_overhead.py      # Benchmarks: profiler vs no profiler
        ├── test_spike_detection.py
        ├── test_memory_trigger.py
        ├── test_stack_accuracy.py
        ├── test_api.py           # @profile, Profile(), CLI
        └── conftest.py           # Shared fixtures
```

---

## Development Phases

The plan is structured into 4 phases, each producing a testable, demonstrable milestone. Tests are integrated into every phase — not deferred. Each phase ends with a gate that must pass before proceeding.

---

## Phase 1 — Foundation (Days 1–5)

**Goal:** Stand up the build chain, implement OS-level reads, and achieve stack capture from Rust. At the end of this phase, a Rust binary can sample CPU%, RSS, and Python call stacks in-process.

---

### 1.1 Project Bootstrap (Day 1)

#### Tasks

1. **Initialize Rust project with maturin**
   ```bash
   maturin new bijli --bindings pyo3
   ```
   Generates `Cargo.toml`, `pyproject.toml`, `src/lib.rs`.

2. **Configure `Cargo.toml`**
   ```toml
   [package]
   name = "bijli"
   version = "0.1.0"
   edition = "2021"

   [lib]
   name = "_core"
   crate-type = ["cdylib"]

   [dependencies]
   pyo3 = { version = "0.22", features = ["extension-module"] }
   libc = "0.2"

   [target.'cfg(windows)'.dependencies]
   windows-sys = { version = "0.59", features = ["Win32_System_Threading", "Win32_System_ProcessStatus"] }
   ```

   **Note:** `parking_lot` is NOT needed. The SPSC ring buffer uses atomics only. The `Sampler` struct uses `std::sync::Mutex` for the start/stop lifecycle (called twice total — not on the hot path). Adding `parking_lot` for two non-hot-path lock acquisitions is unnecessary complexity.

3. **Configure `pyproject.toml`**
   ```toml
   [build-system]
   requires = ["maturin>=1.0,<2.0"]
   build-backend = "maturin"

   [project]
   name = "bijli"
   version = "0.1.0"
   requires-python = ">=3.9"
   dependencies = []

   [tool.maturin]
   python-source = "python"
   features = ["pyo3/extension-module"]
   module-name = "bijli._core"
   ```

4. **Create `.gitignore`**
   Standard Rust + Python ignores: `target/`, `__pycache__/`, `*.so`, `*.pyd`, `dist/`, `*.egg-info/`.

5. **Create `CLAUDE.md`** with build/test/lint commands for AI-assisted development.

6. **Verify build chain**
   ```bash
   maturin develop --release
   python -c "import bijli._core; print('OK')"
   ```

#### Acceptance Criteria
- `cargo build --release` succeeds
- `maturin develop` produces an importable `bijli._core` module
- CI pipeline (even if local) can build the project

---

### 1.2 OS-Specific CPU & RSS Reads (Days 1–2)

**File:** `src/sysinfo.rs`

This module provides the lowest-level metrics. It must compile and produce correct values on all three platforms before anything is built on top.

#### Implementation Details

**Trait definition:**
```rust
pub struct SysMetrics {
    pub cpu_percent: f64,
    pub rss_bytes: u64,
}

pub fn read_metrics(prev_cpu_ticks: &mut u64, prev_wall: &mut std::time::Instant) -> SysMetrics;
```

**Linux implementation:**
- Read `/proc/self/stat` for `utime + stime` (fields 14–15, jiffies). Cache previous values, compute delta per tick. Divide by `sysconf(_SC_CLK_TCK)` and wall-clock delta to get CPU%.
- Read `VmRSS` line from `/proc/self/status` for RSS in kB. Parse with a byte scanner — no regex, no allocations.
- Both reads are a single `open() → read() → close()` syscall sequence each.
- **Latency target: < 5μs combined.**
- **Error handling:** If `/proc/self/stat` is unreadable (rare: some container runtimes), return `cpu_percent: -1.0` as sentinel. Log warning once. Do not panic.

**macOS implementation:**
- Use `proc_pidinfo(getpid(), PROC_PIDTASKINFO, ...)` — single syscall, returns `pti_total_user + pti_total_system` for CPU and `pti_resident_size` for RSS.

**Windows implementation:**
- `GetProcessTimes()` for CPU ticks, `GetProcessMemoryInfo()` for `WorkingSetSize`.
- Wrap behind `#[cfg(target_os = "...")]` conditional compilation.

#### Tests (`tests/rust/test_sysinfo.rs` or inline `#[cfg(test)]`)
- Assert `cpu_percent` is in range `[0.0, num_cores * 100.0]`
- Assert `rss_bytes > 0`
- Benchmark: assert single `read_metrics()` call completes in < 10μs (generous bound)
- Test error path: mock unreadable `/proc` (Linux only) returns sentinel without panic

#### Acceptance Criteria
- `cargo test` passes on Linux (primary), macOS, Windows
- Standalone test binary prints CPU% and RSS every 50ms with measured latency < 5μs per read

---

### 1.3 CPython Stack Capture (Days 2–4)

**File:** `src/stack.rs`

The most technically sensitive component. Reads live Python interpreter state from Rust using the CPython C API.

#### Implementation Details

**Frame walking approach:**
```rust
pub struct FrameInfo {
    pub filename: String,
    pub function: String,
    pub lineno: i32,
}

pub struct StackSnapshot {
    pub frames: Vec<FrameInfo>,  // bottom-to-top
    pub hash: u64,               // FxHash for deduplication
}

/// Must be called while holding the GIL.
/// Returns None if no thread state is available.
pub fn capture_stack(py: Python<'_>) -> Option<StackSnapshot>;
```

**GIL interaction:**
- Use `pyo3::Python::with_gil(|py| ...)` to acquire the GIL
- Call `PyThreadState_Get()` → walk `frame->f_back` chain
- For each frame: extract `co_filename`, `co_name`, `co_firstlineno` from the `PyCodeObject`
- Copy all string data into Rust `String`s immediately, then release GIL
- **GIL hold time target: < 10μs per sample**

**GIL minimisation strategy:**
- Pre-allocate a `Vec<FrameInfo>` with capacity 32 (typical max call depth) — reuse across samples to avoid allocation
- Use `PyFrame_GetCode()` accessor (stable since 3.9) instead of direct struct field access
- For 3.11+ where `_PyInterpreterFrame` was introduced: `PyFrame_GetCode()` abstracts this — no version-specific code needed
- **Critical:** The sampler thread acquires the GIL from a non-Python thread. This is safe with PyO3 as long as we use `Python::with_gil()` which handles `PyGILState_Ensure/Release` correctly.

**Frame deduplication:**
- Maintain a `HashMap<u64, Arc<StackSnapshot>>` intern table keyed by FxHash of the frame chain
- Each `Sample` stores an `Arc<StackSnapshot>` pointer instead of a full copy
- Expected deduplication ratio: 80–95% for typical workloads
- Clear the intern table on `stop()` to avoid unbounded growth

**Python version compatibility:**
- Supported: CPython 3.9, 3.10, 3.11, 3.12, 3.13
- Use only stable C API accessors: `PyFrame_GetCode()`, `PyFrame_GetBack()`, `PyFrame_GetLineNumber()`, `PyCode_GetFilename()`
- For 3.11+ frame split (`PyFrameObject` + `_PyInterpreterFrame`): the stable accessors abstract this — no conditional compilation needed
- **PyPy:** Explicitly unsupported in v0.1.0. Document this. PyPy's frame objects have a different layout and the C API compatibility layer may not expose frame walking.

**Error handling:**
- If `PyThreadState_Get()` returns null (no active thread state): return `None`, skip this sample
- If frame walking encounters a null pointer mid-chain: truncate stack at that point, do not panic
- If GIL acquisition blocks for > 100ms (pathological case): the compensated sleep in the sampler will adjust. No timeout mechanism needed — PyO3's `with_gil` is blocking by design.

#### Tests
- Profile a known call chain `a() → b() → c()`, assert captured stack contains `["a", "b", "c"]`
- Profile a recursive function, assert correct depth
- Profile across Python versions in CI matrix: 3.9, 3.10, 3.11, 3.12, 3.13
- Measure GIL hold time with `std::time::Instant` — assert < 50μs (5x safety margin)

#### Acceptance Criteria
- Stack capture works on CPython 3.9–3.13
- GIL hold time < 50μs measured in tests
- No panics on null/missing frame data

---

### 1.4 Configuration Module (Day 4)

**File:** `src/config.rs`

Centralise all tunable parameters with validated defaults.

```rust
pub struct ProfilerConfig {
    /// Sampling interval in milliseconds. Default: 50. Range: [1, 10000].
    pub interval_ms: u64,

    /// Ring buffer capacity (number of samples). Default: 100_000.
    pub ring_buffer_capacity: usize,

    /// RSS delta threshold (bytes) to trigger tracemalloc. Default: 10 MB.
    pub mem_spike_threshold_bytes: u64,

    /// tracemalloc capture duration in milliseconds. Default: 500.
    pub tracemalloc_duration_ms: u64,

    /// Minimum cooldown between tracemalloc activations. Default: 5000ms.
    pub tracemalloc_cooldown_ms: u64,

    /// Number of tracemalloc frames to capture. Default: 10.
    pub tracemalloc_frames: usize,

    /// CPU spike threshold: mean + N*sigma. Default: 2.0.
    pub spike_sigma_multiplier: f64,

    /// Absolute floor for CPU spike (percent). Default: 15.0.
    pub cpu_spike_floor: f64,

    /// Absolute floor for memory spike (bytes). Default: 5 MB.
    pub mem_spike_floor_bytes: u64,
}

impl ProfilerConfig {
    pub fn validate(&self) -> Result<(), String>;
}
```

#### Acceptance Criteria
- All defaults are centralised in one location
- Validation rejects invalid values (e.g., interval_ms = 0)
- Python-side config maps cleanly to this struct

---

### Phase 1 Gate

Before proceeding to Phase 2, the following must be true:
- [ ] `cargo build --release` succeeds on Linux, macOS, Windows CI
- [ ] `maturin develop` produces importable `bijli._core`
- [ ] `read_metrics()` returns valid CPU%/RSS on Linux (at minimum)
- [ ] `capture_stack()` returns correct frames for a known call chain on CPython 3.9–3.13
- [ ] All Rust tests pass (`cargo test`)
- [ ] Config module validates and provides sensible defaults

---

## Phase 2 — Core Sampling Engine (Days 5–9)

**Goal:** Build the ring buffer, sampling loop, and conditional tracemalloc trigger. At the end of this phase, the Rust core can run a background sampling thread that collects CPU, RSS, and stack data at 50ms intervals with measurable overhead.

---

### 2.1 SPSC Ring Buffer (Day 5)

**File:** `src/ringbuf.rs`

A single-producer, single-consumer ring buffer. The sampler thread is the sole writer. Post-processing after `stop()` is the sole reader. This separation means we need only atomic index variables — no mutexes on the hot path.

#### Implementation Details

```rust
use std::sync::atomic::{AtomicUsize, Ordering};

pub struct RingBuffer<T> {
    buffer: Box<[Option<T>]>,  // pre-allocated, fixed size
    capacity: usize,
    write_idx: AtomicUsize,    // only modified by producer
    read_idx: AtomicUsize,     // only modified by consumer (post-processing)
}
```

**Semantics:**
- `push(sample)`: writes to `buffer[write_idx % capacity]`, increments `write_idx` with `Release` ordering. If buffer is full, overwrites oldest sample (ring wraps). No blocking, no allocation.
- `drain() -> Vec<T>`: called once after `stop()`. Reads all samples from `read_idx` to `write_idx`. Not performance-critical.
- At 50ms interval and 100K capacity: 83 minutes of data before any sample loss.

**Why not a crate?** `ringbuf` and `crossbeam` are battle-tested, but they pull in dependencies and add to compile time. Our SPSC use case is simple enough (single push site, single drain site, no concurrent read/write) that a ~50-line implementation is correct and auditable.

#### Tests
- Push N items, drain, assert all N recovered in order
- Push more than capacity, assert oldest items are lost and newest are preserved
- Concurrent test: spawn producer thread pushing 1M items, consumer drains after join — assert no data corruption
- Assert zero heap allocations during `push()` (measure with a custom allocator in test)

#### Acceptance Criteria
- All ring buffer tests pass
- Zero allocations on the `push()` path verified

---

### 2.2 Sampler Thread & Tick Loop (Days 5–7)

**File:** `src/sampler.rs`

The heart of the profiler. A background OS thread that wakes every 50ms, reads metrics, captures the stack, and writes a sample to the ring buffer.

#### Implementation Details

```rust
pub struct Sample {
    pub timestamp_ns: u64,           // monotonic nanoseconds since start
    pub cpu_percent: f64,
    pub rss_bytes: u64,
    pub stack: Arc<StackSnapshot>,   // deduplicated
}

pub struct Sampler {
    config: ProfilerConfig,
    ring: Arc<RingBuffer<Sample>>,
    running: Arc<AtomicBool>,
    thread_handle: Option<JoinHandle<()>>,
    // For tracemalloc coordination
    mem_spike_flag: Arc<AtomicBool>,
    snapshot_taken_flag: Arc<AtomicBool>,
}
```

**Tick loop:**
```rust
fn sampling_loop(/* args */) {
    let mut prev_cpu_ticks: u64 = 0;
    let mut prev_wall = Instant::now();
    let mut prev_rss: u64 = 0;
    let mut intern_table: HashMap<u64, Arc<StackSnapshot>> = HashMap::new();
    let start = Instant::now();
    let interval = Duration::from_millis(config.interval_ms);

    while running.load(Ordering::Relaxed) {
        let tick_start = Instant::now();

        let metrics = sysinfo::read_metrics(&mut prev_cpu_ticks, &mut prev_wall);
        let stack = Python::with_gil(|py| stack::capture_stack(py));

        if let Some(stk) = stack {
            let stk = intern_table
                .entry(stk.hash)
                .or_insert_with(|| Arc::new(stk))
                .clone();

            ring.push(Sample {
                timestamp_ns: start.elapsed().as_nanos() as u64,
                cpu_percent: metrics.cpu_percent,
                rss_bytes: metrics.rss_bytes,
                stack: stk,
            });

            // Check for memory spike
            let delta = metrics.rss_bytes.saturating_sub(prev_rss);
            if delta > config.mem_spike_threshold_bytes {
                mem_spike_flag.store(true, Ordering::Release);
            }
            prev_rss = metrics.rss_bytes;
        }

        // Compensated sleep
        let elapsed = tick_start.elapsed();
        if elapsed < interval {
            thread::sleep(interval - elapsed);
        }
        // If elapsed >= interval, skip sleep (we're behind)
    }
}
```

**Thread lifecycle:**
- `start()`: spawns the background thread. Can only be called once. Returns error if already running.
- `stop()`: sets `running` to `false`, joins the thread, runs post-processing, returns `SampleData`.
- **Cleanup on drop:** If `stop()` was never called (e.g., program crashed or user forgot), the `Drop` impl sets `running = false` and joins the thread. This prevents leaked threads.

**Thread priority:**
- On Linux: call `libc::setpriority(PRIO_PROCESS, 0, 5)` to lower the sampler thread's nice value. This is best-effort — if it fails (container without CAP_SYS_NICE), continue at normal priority.
- On macOS/Windows: best-effort equivalent or skip.
- CPU affinity pinning: **deferred to v0.2.0**. The complexity of detecting spare cores and the portability issues don't justify inclusion in v0.1.0.

#### Tests
- Start sampler, sleep 500ms, stop — assert ~10 samples collected (500ms / 50ms)
- Start sampler, sleep 100ms, stop — assert `SampleData.wall_secs` ≈ 0.1
- Assert `running` flag is `false` after `stop()`
- Assert thread is joined after `stop()` (no leaked threads)
- Drop without `stop()` — assert thread is cleaned up (no panic, no leak)

#### Acceptance Criteria
- Sampler collects samples at the configured interval (±10% jitter acceptable)
- Thread lifecycle is clean: start → stop → join with no leaks
- Drop impl handles the "forgot to stop" case

---

### 2.3 Conditional tracemalloc Trigger (Days 7–8)

**Mechanism:** The Rust sampler detects an RSS spike and sets an `AtomicBool` flag. A Python-side watcher thread polls this flag and activates tracemalloc.

**Why a separate Python thread?** `tracemalloc.start()` and `tracemalloc.stop()` must be called with the GIL held, and they modify global interpreter state. Calling them from the Rust sampler thread via `Python::with_gil` would work technically, but would extend the GIL hold time by the duration of the snapshot (potentially milliseconds). A dedicated Python daemon thread keeps this cost off the sampling hot path.

**Cooldown logic:** After a tracemalloc snapshot, the flag is cleared and cannot re-fire for `tracemalloc_cooldown_ms` (default 5 seconds). This prevents rapid-fire snapshots during sustained memory growth.

#### Tests
- Allocate 50 MB in a burst — assert tracemalloc fires within 200ms
- Allocate 1 MB gradually — assert tracemalloc does NOT fire
- Fire tracemalloc, then immediately allocate another 50 MB — assert cooldown prevents second snapshot within 5s
- Assert tracemalloc is stopped after snapshot (no lingering overhead)

#### Acceptance Criteria
- tracemalloc fires only on genuine memory spikes
- Cooldown prevents rapid-fire snapshots
- tracemalloc is always cleaned up (stopped) after snapshot

---

### Phase 2 Gate

- [ ] Sampler thread collects CPU%, RSS, and stack samples at 50ms intervals
- [ ] Ring buffer holds samples with zero hot-path allocations
- [ ] tracemalloc triggers on memory spikes with proper cooldown
- [ ] Thread lifecycle is clean (start/stop/drop all handled)
- [ ] Overhead benchmark: profiled vs bare execution of a CPU-bound loop — delta < 2%
- [ ] Overhead benchmark: profiled vs bare execution of an I/O-bound workload — delta < 0.5%

---

## Phase 3 — Analysis, Python API & Reporting (Days 9–14)

**Goal:** Implement spike detection, build the Python-facing API (`@profile`, `Profile()`, CLI), and render ANSI reports. At the end of this phase, a user can `pip install` (from local build) and profile a Python script end-to-end.

---

### 3.1 Spike Detection & Post-Processing (Days 9–10)

**File:** `src/spikes.rs`

Runs once after `stop()`. Correctness matters more than speed.

#### Statistical Spike Detection

**Algorithm:** Welford's online algorithm (single-pass, numerically stable) to compute mean (μ) and standard deviation (σ) for both CPU% and RSS.

**Spike threshold:** `max(μ + k*σ, μ + absolute_floor)` where:
- `k` = `spike_sigma_multiplier` (default 2.0)
- CPU floor = `cpu_spike_floor` (default 15%)
- Memory floor = `mem_spike_floor_bytes` (default 5 MB)

The absolute floor prevents false positives in low-variance runs (e.g., a program using steady 5% CPU would otherwise flag 7% as a spike).

**Spike event grouping:** Contiguous above-threshold samples are merged into a single `SpikeEvent`:
```rust
pub struct SpikeEvent {
    pub kind: SpikeKind,         // Cpu or Memory
    pub peak_value: f64,
    pub threshold: f64,
    pub start_ns: u64,
    pub end_ns: u64,
    pub duration_ms: f64,
    pub peak_sample_idx: usize,
    pub peak_stack: Arc<StackSnapshot>,
}
```

#### Hot Path Aggregation

**File:** `src/spikes.rs` (same module — tightly related)

- Build `HashMap<u64, (FrameInfo, u32)>` counting how many samples each unique frame (by hash) appears in
- Compute `percentage = count / total_samples * 100`
- Sort by descending count, return top N (default: 20)
- This is the standard statistical sampling approach: **frequency ∝ time spent**

#### Data Serialisation

**File:** `src/snapshot.rs`

Convert Rust structs to Python dicts via PyO3. Called once — performance is irrelevant.

```rust
/// Returned to Python after stop()
pub struct SampleData {
    pub wall_secs: f64,
    pub total_samples: usize,
    pub samples: Vec<SampleDict>,       // each sample as a dict
    pub spikes: Vec<SpikeEventDict>,
    pub hot_paths: Vec<HotPathEntry>,
    pub alloc_snapshots: Vec<...>,      // from tracemalloc
    pub config: ProfilerConfigDict,     // echo back config for report
}
```

#### Tests
- Feed a synthetic sample set with a known spike — assert spike is detected with correct start/end
- Feed flat data (no variance) — assert zero spikes detected
- Feed known hot path data — assert top entry matches expected function
- Test Welford's algorithm against a known mean/stddev computed externally
- Edge case: fewer than 2 samples — assert no crash, empty spikes list

#### Acceptance Criteria
- Spike detection correctly identifies synthetic spikes
- Hot path aggregation produces correct frequency counts
- Serialisation produces valid Python dicts

---

### 3.2 PyO3 Bindings (Days 10–11)

**File:** `src/lib.rs`

```rust
#[pymodule]
fn _core(m: &Bound<'_, PyModule>) -> PyResult<()> {
    m.add_class::<PySampler>()?;
    Ok(())
}

#[pyclass(name = "Sampler")]
struct PySampler {
    inner: Option<Sampler>,  // Option for take-on-stop semantics
}

#[pymethods]
impl PySampler {
    #[new]
    #[pyo3(signature = (
        interval_ms = 50,
        ring_buffer_capacity = 100_000,
        mem_spike_threshold_mb = 10,
        tracemalloc_cooldown_ms = 5000,
    ))]
    fn new(
        interval_ms: u64,
        ring_buffer_capacity: usize,
        mem_spike_threshold_mb: u64,
        tracemalloc_cooldown_ms: u64,
    ) -> PyResult<Self> { ... }

    fn start(&mut self) -> PyResult<()> { ... }

    /// Stops the sampler, runs post-processing, returns results.
    /// Consumes the inner sampler — calling stop() twice returns an error.
    fn stop(&mut self, py: Python<'_>) -> PyResult<PyObject> { ... }

    /// Check if a memory spike was detected (polled by Python watcher thread).
    fn mem_spike_flag(&self) -> bool { ... }

    /// Acknowledge that a tracemalloc snapshot was taken.
    fn notify_snapshot_taken(&mut self) { ... }
}
```

**Design note:** The original plan used `Arc<Mutex<SamplerInner>>` for the `Sampler` — this is unnecessary. `PySampler` is a `#[pyclass]` with `&mut self` methods, so PyO3 already provides `RefCell`-like exclusive borrow checking. The internal `Sampler` owns the thread handle and atomics directly. No wrapping mutex needed.

---

### 3.3 Python Facade (Days 11–12)

**File:** `python/bijli/__init__.py`

```python
"""Bijli — Rust-powered Python profiler."""

from bijli._core import Sampler
import threading
import tracemalloc
import time
import functools
from typing import Optional, Any, Callable

__all__ = ["profile", "Profile"]


class Profile:
    """Context manager for profiling a block of code.

    Usage:
        with Profile() as p:
            my_function()
        p.report()
    """

    def __init__(
        self,
        interval_ms: int = 50,
        mem_spike_threshold_mb: int = 10,
        report: bool = True,
    ):
        self._interval_ms = interval_ms
        self._mem_spike_threshold_mb = mem_spike_threshold_mb
        self._auto_report = report
        self._sampler: Optional[Sampler] = None
        self._watcher_thread: Optional[threading.Thread] = None
        self._done = threading.Event()
        self._snapshots: list = []
        self._data: Optional[dict] = None

    def __enter__(self):
        self.start()
        return self

    def __exit__(self, *exc):
        self.stop()
        if self._auto_report:
            self.report()
        return False

    def start(self):
        self._sampler = Sampler(
            interval_ms=self._interval_ms,
            mem_spike_threshold_mb=self._mem_spike_threshold_mb,
        )
        self._sampler.start()
        self._watcher_thread = threading.Thread(
            target=self._tracemalloc_watcher, daemon=True
        )
        self._watcher_thread.start()

    def stop(self):
        if self._sampler is None:
            return
        self._done.set()
        self._data = self._sampler.stop()
        if self._watcher_thread is not None:
            self._watcher_thread.join(timeout=2.0)

    def report(self, json: bool = False):
        if self._data is None:
            return
        from bijli.report import render
        render(self._data, json=json)

    def _tracemalloc_watcher(self):
        while not self._done.is_set():
            if self._sampler is not None and self._sampler.mem_spike_flag():
                tracemalloc.start(10)
                time.sleep(0.5)
                snap = tracemalloc.take_snapshot()
                tracemalloc.stop()
                self._snapshots.append(snap)
                self._sampler.notify_snapshot_taken()
            self._done.wait(timeout=0.02)


def profile(
    func: Optional[Callable] = None,
    *,
    interval_ms: int = 50,
    mem_spike_threshold_mb: int = 10,
) -> Callable:
    """Decorator to profile a function.

    Usage:
        @profile
        def my_function():
            ...

        @profile(interval_ms=100)
        def my_function():
            ...
    """

    def decorator(fn: Callable) -> Callable:
        @functools.wraps(fn)
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            with Profile(
                interval_ms=interval_ms,
                mem_spike_threshold_mb=mem_spike_threshold_mb,
            ):
                return fn(*args, **kwargs)

        return wrapper

    if func is not None:
        return decorator(func)
    return decorator
```

#### Type Stubs

**File:** `python/bijli/_core.pyi`

Full `.pyi` stub so IDEs provide autocompletion for the Rust extension module.

---

### 3.4 CLI Entry Point (Day 12)

**File:** `python/bijli/cli.py`

```bash
python -m bijli script.py [args...]
python -m bijli --json script.py
python -m bijli --interval 100 script.py
```

Implementation: use `runpy.run_path()` to execute the target script under a `Profile()` context manager. Parse args with `argparse`.

---

### 3.5 Report Renderer (Days 12–13)

**File:** `python/bijli/report.py`

Pure Python, ANSI escape codes only. No external dependencies.

#### Report Sections

1. **Overview block:** wall time, CPU avg/peak, memory start→peak, spike count, sample count
2. **Sparkline timeline:** 60-char ASCII sparkline for CPU% and RSS over time, spike regions highlighted with red ANSI
3. **Spike events:** each spike with kind (CPU/MEM), peak value, threshold, duration, and the call stack at peak
4. **Allocation hotspots:** rendered only when tracemalloc snapshots exist
5. **Hot paths:** top-N functions by sample frequency, bar chart, source file:line shown

#### Output Modes
- Default: ANSI terminal output (detects non-TTY and strips colours)
- `--json`: structured JSON to stdout for piping into dashboards or tooling

#### Tests
- Render a synthetic `SampleData` — assert output contains expected sections
- JSON mode: assert output is valid JSON with expected keys
- Non-TTY mode: assert no ANSI escape codes in output

---

### 3.6 End-to-End Integration Tests (Days 13–14)

**File:** `tests/python/test_api.py`

These tests verify the full user-facing API works correctly.

```python
def test_profile_decorator():
    @profile
    def compute():
        sum(range(1_000_000))
    compute()  # Should print report without error

def test_context_manager():
    with Profile(report=False) as p:
        sum(range(1_000_000))
    assert p._data is not None
    assert p._data["total_samples"] > 0

def test_cli(tmp_path):
    script = tmp_path / "test_script.py"
    script.write_text("sum(range(10_000_000))")
    result = subprocess.run(
        [sys.executable, "-m", "bijli", str(script)],
        capture_output=True, text=True
    )
    assert result.returncode == 0
    assert "CPU" in result.stdout  # Report was printed

def test_no_root_required():
    """Verify profiler works without elevated privileges."""
    # This test is meaningful in CI where it runs as a non-root user
    with Profile(report=False) as p:
        time.sleep(0.2)
    assert p._data is not None
```

---

### Phase 3 Gate

- [ ] `@profile` decorator works end-to-end
- [ ] `with Profile()` context manager works end-to-end
- [ ] `python -m bijli script.py` works end-to-end
- [ ] ANSI report renders correctly with all sections
- [ ] JSON output is valid and parseable
- [ ] Spike detection identifies synthetic spikes correctly
- [ ] Hot path aggregation produces correct frequency ordering
- [ ] tracemalloc activates on memory spikes and cleans up
- [ ] All tests pass on CPython 3.9–3.13

---

## Phase 4 — Packaging, CI/CD & Launch (Days 14–18)

**Goal:** Build the CI/CD pipeline, produce platform wheels, publish to PyPI, and write user-facing documentation. At the end of this phase, anyone can `pip install bijli` and use it.

---

### 4.1 GitHub Actions CI (Day 14)

**File:** `.github/workflows/ci.yml`

Runs on every push and PR.

```yaml
name: CI
on: [push, pull_request]

jobs:
  rust-tests:
    runs-on: ${{ matrix.os }}
    strategy:
      matrix:
        os: [ubuntu-latest, macos-latest, windows-latest]
    steps:
      - uses: actions/checkout@v4
      - uses: dtolnay/rust-toolchain@stable
      - run: cargo test --all-targets
      - run: cargo clippy -- -D warnings
      - run: cargo fmt -- --check

  python-tests:
    runs-on: ${{ matrix.os }}
    strategy:
      matrix:
        os: [ubuntu-latest, macos-latest, windows-latest]
        python-version: ["3.9", "3.10", "3.11", "3.12", "3.13"]
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-python@v5
        with:
          python-version: ${{ matrix.python-version }}
      - uses: dtolnay/rust-toolchain@stable
      - run: pip install maturin pytest
      - run: maturin develop --release
      - run: pytest tests/python/ -v

  overhead-benchmark:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-python@v5
        with:
          python-version: "3.12"
      - uses: dtolnay/rust-toolchain@stable
      - run: pip install maturin pytest
      - run: maturin develop --release
      - run: pytest tests/python/test_overhead.py -v --tb=long
```

---

### 4.2 Release Workflow & Wheel Matrix (Days 14–15)

**File:** `.github/workflows/release.yml`

Triggered on version tags. Builds wheels for all target platforms and publishes to PyPI.

```yaml
name: Release
on:
  push:
    tags: ['v*']

jobs:
  build-wheels:
    runs-on: ${{ matrix.os }}
    strategy:
      matrix:
        include:
          - os: ubuntu-latest
            target: x86_64-unknown-linux-gnu
          - os: ubuntu-latest
            target: aarch64-unknown-linux-gnu
          - os: ubuntu-latest
            target: x86_64-unknown-linux-musl
          - os: ubuntu-latest
            target: aarch64-unknown-linux-musl
          - os: macos-latest
            target: x86_64-apple-darwin
          - os: macos-latest
            target: aarch64-apple-darwin
          - os: windows-latest
            target: x86_64-pc-windows-msvc
    steps:
      - uses: actions/checkout@v4
      - uses: PyO3/maturin-action@v1
        with:
          command: build
          args: --release --out dist --target ${{ matrix.target }}
          manylinux: auto
      - uses: actions/upload-artifact@v4
        with:
          name: wheels-${{ matrix.target }}
          path: dist/

  # Also build sdist for users with Rust toolchain
  build-sdist:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: PyO3/maturin-action@v1
        with:
          command: sdist
          args: --out dist
      - uses: actions/upload-artifact@v4
        with:
          name: sdist
          path: dist/

  publish:
    needs: [build-wheels, build-sdist]
    runs-on: ubuntu-latest
    permissions:
      id-token: write  # trusted publishing
    steps:
      - uses: actions/download-artifact@v4
        with:
          pattern: wheels-*
          merge-multiple: true
          path: dist/
      - uses: actions/download-artifact@v4
        with:
          name: sdist
          path: dist/
      - uses: pypa/gh-action-pypi-publish@release/v1
```

**Wheel matrix (7 platform targets):**

| Platform | Architecture | Wheel tag | Notes |
|---|---|---|---|
| Linux (glibc) | x86_64 | manylinux_2_17 | ~90% of servers |
| Linux (glibc) | aarch64 | manylinux_2_17 | ARM servers (AWS Graviton) |
| Linux (musl) | x86_64 | musllinux_1_2 | Alpine / Docker minimal |
| Linux (musl) | aarch64 | musllinux_1_2 | Alpine ARM |
| macOS | x86_64 | macosx_10_12 | Intel Macs |
| macOS | arm64 | macosx_11_0 | Apple Silicon (M1/M2/M3) |
| Windows | x86_64 | win_amd64 | |

Plus an sdist for users who have the Rust toolchain and want to build from source.

**Release flow:** `git tag v0.1.0 && git push --tags` → CI builds all wheels → publishes to PyPI via trusted publishing (no API tokens).

---

### 4.3 Overhead Benchmark Suite (Day 15)

**File:** `tests/python/test_overhead.py`

The most important validation: prove the overhead claims hold.

```python
import time
import pytest

def io_bound():
    """Simulate I/O-bound work."""
    for _ in range(100):
        time.sleep(0.001)  # 100ms total

def cpu_bound():
    """Simulate CPU-bound work."""
    total = 0
    for i in range(5_000_000):
        total += i * i
    return total

def alloc_heavy():
    """Simulate allocation-heavy work."""
    data = []
    for _ in range(1000):
        data.append(bytearray(10_000))  # 10KB * 1000 = 10MB
    return data

@pytest.mark.parametrize("target, max_overhead_pct", [
    (io_bound,    1.0),    # I/O-bound: profiler should be nearly invisible
    (cpu_bound,   5.0),    # CPU-bound: GIL contention adds measurable cost
    (alloc_heavy, 3.0),    # Alloc-heavy: tracemalloc should stay off
])
def test_overhead(target, max_overhead_pct):
    from timeit import timeit
    from bijli import profile

    bare = timeit(target, number=10)
    profiled = timeit(lambda: profile(target)(), number=10)
    overhead_pct = (profiled - bare) / bare * 100
    print(f"{target.__name__}: bare={bare:.3f}s, profiled={profiled:.3f}s, overhead={overhead_pct:.1f}%")
    assert overhead_pct < max_overhead_pct, (
        f"{target.__name__} overhead {overhead_pct:.1f}% exceeds {max_overhead_pct}%"
    )
```

**Note on overhead bounds:** The original plan claimed "< 0.5%" for all workloads. This is unrealistic for CPU-bound workloads where GIL acquisition every 50ms introduces contention. The refined bounds are:
- I/O-bound: < 1% (profiler runs during I/O waits)
- CPU-bound: < 5% (GIL contention is the dominant cost)
- Alloc-heavy: < 3% (tracemalloc should not fire for gradual allocation)

If benchmarks show these bounds are too tight, adjust the sampling interval rather than the bounds.

---

### 4.4 Documentation (Days 16–17)

#### README.md

Structure:
1. **30-second quickstart:** `pip install bijli` + `@profile` example with terminal output screenshot
2. **Why Bijli?** — comparison table with py-spy, cProfile, tracemalloc
3. **Usage:** decorator, context manager, CLI — with examples
4. **Configuration:** all options with defaults
5. **How it works:** one paragraph + architecture diagram (ASCII)
6. **Overhead:** link to CI benchmark results
7. **Platform support:** table of supported OS/arch/Python versions
8. **Limitations:** PyPy unsupported, GIL-bound overhead for CPU-heavy code

#### PyPI Metadata (`pyproject.toml`)

```toml
[project]
classifiers = [
    "Development Status :: 3 - Alpha",
    "Intended Audience :: Developers",
    "Topic :: Software Development :: Debuggers",
    "Topic :: System :: Monitoring",
    "License :: OSI Approved :: MIT License",
    "Programming Language :: Python :: 3",
    "Programming Language :: Rust",
]
keywords = ["profiler", "cpu", "memory", "performance", "sampling", "rust"]
```

---

### 4.5 Pre-Launch Checklist (Day 17)

- [ ] All CI checks green on all platforms
- [ ] Overhead benchmarks pass within bounds
- [ ] `pip install bijli` from test PyPI works end-to-end
- [ ] README renders correctly on PyPI
- [ ] `@profile`, `Profile()`, and CLI all produce correct reports
- [ ] Type stubs provide autocomplete in VS Code and PyCharm
- [ ] No `unsafe` Rust code without justification comments
- [ ] LICENSE and copyright headers present

---

### 4.6 Launch (Day 18)

1. Tag `v0.1.0`, push tag — CI publishes to PyPI
2. Create GitHub release with changelog
3. Post to r/Python: "Bijli: a Rust-powered Python profiler that works in Docker without sudo and profiles memory"
4. Post to r/rust: "Built a Python profiler with Rust + PyO3 — in-process, zero-dependency, pip-installable"
5. Hacker News Show HN

---

### Phase 4 Gate (Release Gate)

- [ ] All CI workflows pass (Rust tests, Python tests across 3.9–3.13, overhead benchmarks)
- [ ] Wheels build for all 7 target platforms
- [ ] `pip install bijli` from PyPI works on Linux, macOS, Windows
- [ ] End-to-end test: install from PyPI → profile a script → see correct report
- [ ] README and PyPI page render correctly

---

## Timeline Summary

| Phase | Days | Duration | Key Deliverable |
|---|---|---|---|
| **Phase 1: Foundation** | 1–5 | 5 days | OS reads + stack capture + config, all tested |
| **Phase 2: Core Engine** | 5–9 | 4 days | Ring buffer + sampler thread + tracemalloc trigger |
| **Phase 3: API & Reporting** | 9–14 | 5 days | Spike detection + Python API + CLI + ANSI report |
| **Phase 4: Ship It** | 14–18 | 4 days | CI/CD + wheels + benchmarks + docs + PyPI publish |
| **TOTAL** | | **18 days** | **v0.1.0 on PyPI** |

---

## Risks & Mitigations

| # | Risk | Severity | Likelihood | Mitigation |
|---|---|---|---|---|
| 1 | GIL contention slows CPU-bound profiled code | Medium | High | Compensated sleep, lower thread priority. Document that CPU-bound overhead is higher (~2-5%). Offer configurable interval. |
| 2 | CPython frame API changes in future version | Low | Medium | Use only stable accessors (`PyFrame_GetCode`, `PyFrame_GetLineNumber`). Add new Python version to CI matrix on release day. |
| 3 | tracemalloc fires too aggressively | Medium | Medium | Configurable threshold + 5s cooldown between snapshots. Document tuning guidance. |
| 4 | Ring buffer overflow on long-running profiles | Low | Low | At 50ms interval + 100K capacity = 83 min. Document limitation. v0.2.0: add configurable capacity or disk spill. |
| 5 | manylinux wheel incompatible with old distros | Low | Low | Target manylinux_2_17 (glibc 2.17, CentOS 7 era). Covers >99% of production Linux. |
| 6 | Windows API reads are slower than /proc | Low | Medium | Benchmark separately. If > 50μs, increase default interval on Windows or skip RSS read. |
| 7 | `Python::with_gil()` from background thread panics | High | Low | This is well-supported by PyO3 — it calls `PyGILState_Ensure`. Test explicitly in CI. If it fails on a platform, fall back to signaling the main thread to capture the stack. |
| 8 | Frame walking on 3.13+ with free-threaded (no-GIL) CPython | Medium | Medium | v0.1.0: require GIL-enabled CPython. Free-threaded support is a v0.2.0 goal requiring `PyMutex` or per-thread state. |
| 9 | User forgets to call `stop()` — thread leaks | Medium | High | `Drop` impl on `Sampler` sets `running = false` and joins. Python `__del__` as last resort. |
| 10 | Profiler interferes with application's own tracemalloc usage | Medium | Low | Check `tracemalloc.is_tracing()` before starting. If already active, skip bijli's tracemalloc entirely and log a warning. |

---

## Post-v0.1.0 Roadmap (Not in Scope)

These features are explicitly deferred to avoid scope creep:

| Feature | Version | Rationale for deferral |
|---|---|---|
| CPU affinity pinning | v0.2.0 | Portability complexity, marginal benefit |
| Free-threaded CPython (PEP 703) support | v0.2.0 | Requires fundamentally different synchronization |
| Flame graph output (SVG) | v0.2.0 | Useful but not essential for launch |
| PyPy support | v0.2.0+ | Different frame API, small user base |
| Disk spill for long-running profiles | v0.2.0 | 83 min buffer is sufficient for v0.1.0 |
| Remote profiling (attach to running process) | v0.3.0 | Requires ptrace — contradicts core value prop |
| Jupyter notebook integration (inline rendering) | v0.2.0 | Valuable but not launch-blocking |
| Multi-thread profiling (all threads, not just main) | v0.2.0 | Requires iterating `PyInterpreterState` thread list |
| Continuous profiling (background daemon mode) | v0.3.0 | Different use case, different architecture |

---

## Appendix A: Corrected Issues from Original Plan

The following issues in the original plan have been corrected in this refined version:

1. **Naming inconsistency:** Original referenced `pystack` in maturin commands and file paths (`python/pystack/__init__.py`). Corrected to `bijli` throughout.

2. **Overhead claim:** Original claimed "< 0.5%" universally. This is unrealistic for CPU-bound workloads where GIL acquisition is the bottleneck. Refined to "< 0.5% I/O-bound, < 2% CPU-bound" with test bounds of 1% and 5% respectively (safety margin).

3. **Contradictory concurrency model:** Original specified "lock-free SPSC ring buffer" but wrapped Sampler in `Arc<Mutex<SamplerInner>>`. Corrected: ring buffer uses atomics only; `PySampler` uses PyO3's built-in `RefCell`-like borrow checking; `Mutex` is only for non-hot-path lifecycle operations.

4. **Testing as Phase 8:** Original deferred all testing to Phase 8. Corrected: tests are integrated into every phase with phase gates.

5. **Missing error handling:** Original had no strategy for failures (unreadable `/proc`, null frame pointers, GIL acquisition delays). Each component now specifies error handling.

6. **Missing cleanup strategy:** Original didn't address what happens if `stop()` is never called. Added `Drop` impl and documented cleanup.

7. **`parking_lot` dependency:** Original included `parking_lot` for "fast Mutex/RwLock". Since the only mutex is on the non-hot-path lifecycle (called twice), `std::sync::Mutex` is sufficient. Removed unnecessary dependency.

8. **Missing `.gitignore`:** Added to project bootstrap.

9. **Wheel count:** Original claimed "10 wheel variants". Actual count with the refined matrix is 7 binary wheels + 1 sdist = 8 artifacts. (Removed i686 Windows and 32-bit targets as unnecessary for a developer tool.)

10. **tracemalloc cooldown:** Original mentioned cooldown in the risks section but never specified it in the implementation. Now part of `ProfilerConfig` with a 5-second default.

11. **Async-awareness claim:** Original claimed async-awareness but never specified the mechanism. Removed from v0.1.0 scope — in-process sampling naturally captures async frames, but proper coroutine attribution is a v0.2.0 feature.

12. **tracemalloc interaction with existing usage:** Original didn't address what happens if the application already uses tracemalloc. Added check for `tracemalloc.is_tracing()`.

---

*Bijli — Built with Rust + PyO3 + Maturin · Zero Python dependencies · Works everywhere Python runs*
