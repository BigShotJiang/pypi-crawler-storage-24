"""PULSE Tax CLI — collect and export crypto trade history for tax reporting."""

import argparse
import json
import os
import sys
from pathlib import Path

from pulse_tax.collector import TaxCollector
from pulse_tax.exporters import KoinlyExporter, CoinTrackerExporter, JSONExporter


def load_config(config_path: str) -> dict:
    """Load exchange credentials from a JSON config file."""
    with open(config_path) as f:
        return json.load(f)


def build_collectors(config: dict) -> TaxCollector:
    """Build TaxCollector from config dict."""
    collector = TaxCollector()

    if "binance" in config:
        from pulse_tax.collectors import BinanceCollector
        c = config["binance"]
        collector.add_exchange(BinanceCollector(
            api_key=c["api_key"],
            api_secret=c["api_secret"],
        ))

    if "bybit" in config:
        from pulse_tax.collectors import BybitCollector
        c = config["bybit"]
        collector.add_exchange(BybitCollector(
            api_key=c["api_key"],
            api_secret=c["api_secret"],
        ))

    if "kraken" in config:
        from pulse_tax.collectors import KrakenCollector
        c = config["kraken"]
        collector.add_exchange(KrakenCollector(
            api_key=c["api_key"],
            api_secret=c["api_secret"],
        ))

    if "okx" in config:
        from pulse_tax.collectors import OKXCollector
        c = config["okx"]
        collector.add_exchange(OKXCollector(
            api_key=c["api_key"],
            api_secret=c["api_secret"],
            passphrase=c["passphrase"],
        ))

    return collector


def cmd_export(args):
    """Handle the 'export' subcommand."""
    # Load config
    if not os.path.exists(args.config):
        print(f"Error: config file not found: {args.config}", file=sys.stderr)
        print("Create a config file with your exchange API keys.", file=sys.stderr)
        print("Example: pulse-tax init --output config.json", file=sys.stderr)
        sys.exit(1)

    config = load_config(args.config)
    collector = build_collectors(config)

    if not collector._collectors:
        print("Error: no exchanges configured in config file.", file=sys.stderr)
        sys.exit(1)

    print(f"Collecting trade history for {args.year}...")
    report = collector.collect(year=args.year, verbose=True)
    print(f"\nTotal: {report.total_trades} trades, {report.total_transfers} transfers")
    print(f"Exchanges: {', '.join(report.exchanges)}")

    # Export
    output_path = args.output
    fmt = args.format.lower()

    if fmt == "koinly":
        exporter = KoinlyExporter()
        result = exporter.export(report.trades, report.transfers)
        if not output_path:
            output_path = f"koinly_{args.year}.csv"
    elif fmt == "cointracker":
        exporter = CoinTrackerExporter()
        result = exporter.export(report.trades, report.transfers)
        if not output_path:
            output_path = f"cointracker_{args.year}.csv"
    elif fmt == "json":
        exporter = JSONExporter()
        result = exporter.export(report)
        if not output_path:
            output_path = f"pulse_tax_{args.year}.json"
    else:
        print(f"Error: unknown format '{fmt}'. Use: koinly, cointracker, json", file=sys.stderr)
        sys.exit(1)

    with open(output_path, "w", encoding="utf-8") as f:
        f.write(result)

    print(f"\nExported to: {output_path}")
    print(f"Format: {fmt}")
    if fmt in ("koinly", "cointracker"):
        print(f"Import this file at {fmt}.com → Import → Generic CSV")


def cmd_init(args):
    """Create a sample config file."""
    sample = {
        "binance": {
            "api_key": "YOUR_BINANCE_API_KEY",
            "api_secret": "YOUR_BINANCE_API_SECRET"
        },
        "bybit": {
            "api_key": "YOUR_BYBIT_API_KEY",
            "api_secret": "YOUR_BYBIT_API_SECRET"
        },
        "kraken": {
            "api_key": "YOUR_KRAKEN_API_KEY",
            "api_secret": "YOUR_KRAKEN_API_SECRET"
        },
        "okx": {
            "api_key": "YOUR_OKX_API_KEY",
            "api_secret": "YOUR_OKX_API_SECRET",
            "passphrase": "YOUR_OKX_PASSPHRASE"
        }
    }
    output = args.output or "pulse_tax_config.json"
    with open(output, "w") as f:
        json.dump(sample, f, indent=2)
    print(f"Created sample config: {output}")
    print("Edit it to add your API keys (read-only keys are sufficient).")
    print("Remove exchanges you don't use.")


def main():
    parser = argparse.ArgumentParser(
        prog="pulse-tax",
        description="Collect crypto trade history from exchanges and export for tax reporting.",
    )
    subparsers = parser.add_subparsers(dest="command")

    # export command
    export_parser = subparsers.add_parser("export", help="Collect and export trade history")
    export_parser.add_argument("--year", type=int, required=True, help="Tax year (e.g. 2026)")
    export_parser.add_argument(
        "--format", default="koinly",
        choices=["koinly", "cointracker", "json"],
        help="Export format (default: koinly)",
    )
    export_parser.add_argument("--output", help="Output file path (auto-generated if not set)")
    export_parser.add_argument(
        "--config", default="pulse_tax_config.json",
        help="Path to config file with API keys (default: pulse_tax_config.json)",
    )

    # init command
    init_parser = subparsers.add_parser("init", help="Create a sample config file")
    init_parser.add_argument("--output", help="Output config file path")

    args = parser.parse_args()

    if args.command == "export":
        cmd_export(args)
    elif args.command == "init":
        cmd_init(args)
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
