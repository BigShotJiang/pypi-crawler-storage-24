"""TaxCollector — aggregates trade history from multiple exchanges via PULSE."""

from typing import Dict, List, Optional
from pulse_tax.models import Trade, Transfer, TaxReport


class TaxCollector:
    """Collect trade history and transfers from multiple exchanges.

    Automatically uses PULSE exchange adapters to query all configured
    exchanges and returns normalized Trade and Transfer records.

    Example:
        >>> from pulse_tax import TaxCollector
        >>> from pulse_tax.collectors import BinanceCollector, BybitCollector

        >>> collector = TaxCollector()
        >>> collector.add_exchange(BinanceCollector(api_key="...", api_secret="..."))
        >>> collector.add_exchange(BybitCollector(api_key="...", api_secret="..."))

        >>> report = collector.collect(year=2026)
        >>> print(f"Total trades: {report.total_trades}")
    """

    def __init__(self):
        self._collectors: List = []

    def add_exchange(self, collector) -> "TaxCollector":
        """Add an exchange collector.

        Args:
            collector: A BinanceCollector, BybitCollector, KrakenCollector, or OKXCollector.

        Returns:
            Self for chaining.
        """
        self._collectors.append(collector)
        return self

    def collect(
        self,
        year: int,
        include_transfers: bool = True,
        verbose: bool = False,
    ) -> TaxReport:
        """Collect all trades and transfers from all configured exchanges.

        Args:
            year: Calendar year to collect data for (e.g. 2026)
            include_transfers: Whether to also collect deposits/withdrawals
            verbose: Print progress to stdout

        Returns:
            TaxReport with all trades and transfers.
        """
        report = TaxReport(year=year)

        for collector in self._collectors:
            exchange = collector.EXCHANGE
            if verbose:
                print(f"  Collecting from {exchange}...")

            try:
                trades = collector.get_trades(year=year)
                report.trades.extend(trades)
                if verbose:
                    print(f"    {len(trades)} trades")
            except Exception as e:
                if verbose:
                    print(f"    ERROR fetching trades from {exchange}: {e}")

            if include_transfers:
                try:
                    transfers = collector.get_transfers(year=year)
                    report.transfers.extend(transfers)
                    if verbose:
                        print(f"    {len(transfers)} transfers")
                except Exception as e:
                    if verbose:
                        print(f"    ERROR fetching transfers from {exchange}: {e}")

            if exchange not in report.exchanges:
                report.exchanges.append(exchange)

        # Sort everything by timestamp
        report.trades.sort(key=lambda x: x.timestamp)
        report.transfers.sort(key=lambda x: x.timestamp)

        return report
