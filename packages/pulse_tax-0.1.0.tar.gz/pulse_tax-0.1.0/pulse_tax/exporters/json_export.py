"""JSON exporter for PULSE Tax — universal format for custom processing."""

import json
from typing import List

from pulse_tax.models import Trade, Transfer, TaxReport


class JSONExporter:
    """Export to JSON format for custom processing or archiving.

    Example:
        >>> exporter = JSONExporter()
        >>> json_str = exporter.export(report)
    """

    def export(self, report: TaxReport, indent: int = 2) -> str:
        """Export full tax report to JSON string.

        Args:
            report: TaxReport containing trades and transfers
            indent: JSON indentation (0 for compact)

        Returns:
            JSON string.
        """
        data = {
            "pulse_tax_version": "0.1.0",
            "year": report.year,
            "exchanges": report.exchanges,
            "summary": {
                "total_trades": report.total_trades,
                "total_transfers": report.total_transfers,
            },
            "trades": [t.to_dict() for t in report.trades],
            "transfers": [t.to_dict() for t in report.transfers],
        }
        return json.dumps(data, indent=indent if indent else None, ensure_ascii=False)
