"""Koinly Universal CSV exporter for PULSE Tax."""

import csv
import io
from typing import List, Union

from pulse_tax.models import Trade, Transfer


# Koinly Universal CSV format columns
KOINLY_COLUMNS = [
    "Date",
    "Sent Amount", "Sent Currency",
    "Received Amount", "Received Currency",
    "Fee Amount", "Fee Currency",
    "Net Worth Amount", "Net Worth Currency",
    "Label",
    "Description",
    "TxHash",
]


class KoinlyExporter:
    """Export trades and transfers to Koinly Universal CSV format.

    Koinly accepts a universal CSV where each row is either:
    - A trade: Sent = what you gave up, Received = what you got
    - A deposit: only Received filled
    - A withdrawal: only Sent filled

    Example:
        >>> exporter = KoinlyExporter()
        >>> csv_str = exporter.export(trades, transfers)
        >>> with open("koinly_2026.csv", "w") as f:
        ...     f.write(csv_str)
    """

    def export(
        self,
        trades: List[Trade],
        transfers: List[Transfer],
        net_worth_currency: str = "USD",
    ) -> str:
        """Export to Koinly Universal CSV string.

        Args:
            trades: List of Trade objects
            transfers: List of Transfer objects
            net_worth_currency: Currency for net worth column (USD or EUR)

        Returns:
            CSV string ready for import into Koinly.
        """
        output = io.StringIO()
        writer = csv.DictWriter(output, fieldnames=KOINLY_COLUMNS)
        writer.writeheader()

        # Combine and sort by timestamp
        all_records: List[Union[Trade, Transfer]] = list(trades) + list(transfers)
        all_records.sort(key=lambda x: x.timestamp)

        for record in all_records:
            if isinstance(record, Trade):
                writer.writerow(self._trade_row(record))
            elif isinstance(record, Transfer):
                writer.writerow(self._transfer_row(record))

        return output.getvalue()

    def _trade_row(self, trade: Trade) -> dict:
        """Convert a Trade to a Koinly CSV row."""
        date_str = trade.timestamp.strftime("%Y-%m-%d %H:%M:%S UTC")

        if trade.side == "buy":
            # Buying: sent quote asset, received base asset
            sent_amount = trade.total
            sent_currency = trade.quote_asset
            received_amount = trade.quantity
            received_currency = trade.base_asset
        else:
            # Selling: sent base asset, received quote asset
            sent_amount = trade.quantity
            sent_currency = trade.base_asset
            received_amount = trade.total
            received_currency = trade.quote_asset

        return {
            "Date": date_str,
            "Sent Amount": f"{sent_amount:.8f}",
            "Sent Currency": sent_currency,
            "Received Amount": f"{received_amount:.8f}",
            "Received Currency": received_currency,
            "Fee Amount": f"{trade.fee:.8f}" if trade.fee else "",
            "Fee Currency": trade.fee_asset if trade.fee else "",
            "Net Worth Amount": "",
            "Net Worth Currency": "",
            "Label": "trade",
            "Description": f"{trade.exchange} | {trade.pair} | ID:{trade.trade_id}",
            "TxHash": "",
        }

    def _transfer_row(self, transfer: Transfer) -> dict:
        """Convert a Transfer to a Koinly CSV row."""
        date_str = transfer.timestamp.strftime("%Y-%m-%d %H:%M:%S UTC")

        if transfer.direction == "deposit":
            sent_amount = ""
            sent_currency = ""
            received_amount = f"{transfer.amount:.8f}"
            received_currency = transfer.asset
            label = "deposit"
        else:
            sent_amount = f"{transfer.amount:.8f}"
            sent_currency = transfer.asset
            received_amount = ""
            received_currency = ""
            label = "withdrawal"

        return {
            "Date": date_str,
            "Sent Amount": sent_amount,
            "Sent Currency": sent_currency,
            "Received Amount": received_amount,
            "Received Currency": received_currency,
            "Fee Amount": f"{transfer.fee:.8f}" if transfer.fee else "",
            "Fee Currency": transfer.fee_asset or transfer.asset if transfer.fee else "",
            "Net Worth Amount": "",
            "Net Worth Currency": "",
            "Label": label,
            "Description": f"{transfer.exchange} | {transfer.direction} | ID:{transfer.transfer_id}",
            "TxHash": transfer.tx_hash or "",
        }
