"""CoinTracker CSV exporter for PULSE Tax."""

import csv
import io
from typing import List, Union

from pulse_tax.models import Trade, Transfer


# CoinTracker CSV columns
COINTRACKER_COLUMNS = [
    "Date",
    "Received Quantity", "Received Currency",
    "Sent Quantity", "Sent Currency",
    "Fee Amount", "Fee Currency",
    "Tag",
]


class CoinTrackerExporter:
    """Export trades and transfers to CoinTracker CSV format.

    Example:
        >>> exporter = CoinTrackerExporter()
        >>> csv_str = exporter.export(trades, transfers)
    """

    def export(self, trades: List[Trade], transfers: List[Transfer]) -> str:
        """Export to CoinTracker CSV string."""
        output = io.StringIO()
        writer = csv.DictWriter(output, fieldnames=COINTRACKER_COLUMNS)
        writer.writeheader()

        all_records: List[Union[Trade, Transfer]] = list(trades) + list(transfers)
        all_records.sort(key=lambda x: x.timestamp)

        for record in all_records:
            if isinstance(record, Trade):
                writer.writerow(self._trade_row(record))
            elif isinstance(record, Transfer):
                writer.writerow(self._transfer_row(record))

        return output.getvalue()

    def _trade_row(self, trade: Trade) -> dict:
        date_str = trade.timestamp.strftime("%m/%d/%Y %H:%M:%S")

        if trade.side == "buy":
            recv_qty = f"{trade.quantity:.8f}"
            recv_cur = trade.base_asset
            sent_qty = f"{trade.total:.8f}"
            sent_cur = trade.quote_asset
        else:
            recv_qty = f"{trade.total:.8f}"
            recv_cur = trade.quote_asset
            sent_qty = f"{trade.quantity:.8f}"
            sent_cur = trade.base_asset

        return {
            "Date": date_str,
            "Received Quantity": recv_qty,
            "Received Currency": recv_cur,
            "Sent Quantity": sent_qty,
            "Sent Currency": sent_cur,
            "Fee Amount": f"{trade.fee:.8f}" if trade.fee else "",
            "Fee Currency": trade.fee_asset if trade.fee else "",
            "Tag": "",
        }

    def _transfer_row(self, transfer: Transfer) -> dict:
        date_str = transfer.timestamp.strftime("%m/%d/%Y %H:%M:%S")

        if transfer.direction == "deposit":
            return {
                "Date": date_str,
                "Received Quantity": f"{transfer.amount:.8f}",
                "Received Currency": transfer.asset,
                "Sent Quantity": "",
                "Sent Currency": "",
                "Fee Amount": f"{transfer.fee:.8f}" if transfer.fee else "",
                "Fee Currency": transfer.fee_asset or "",
                "Tag": "",
            }
        else:
            return {
                "Date": date_str,
                "Received Quantity": "",
                "Received Currency": "",
                "Sent Quantity": f"{transfer.amount:.8f}",
                "Sent Currency": transfer.asset,
                "Fee Amount": f"{transfer.fee:.8f}" if transfer.fee else "",
                "Fee Currency": transfer.fee_asset or "",
                "Tag": "",
            }
