"""Bybit V5 trade history collector for PULSE Tax."""

import hashlib
import hmac
import time
from datetime import datetime, timezone
from typing import List, Optional
from urllib.parse import urlencode

import requests

from pulse_tax.models import Trade, Transfer


BYBIT_BASE = "https://api.bybit.com"


class BybitCollector:
    """Collects trade history and transfers from Bybit V5.

    Example:
        >>> collector = BybitCollector(api_key="...", api_secret="...")
        >>> trades = collector.get_trades(year=2026)
    """

    EXCHANGE = "bybit"

    def __init__(self, api_key: str, api_secret: str):
        self.api_key = api_key
        self.api_secret = api_secret
        self.session = requests.Session()
        self.session.headers.update({"User-Agent": "pulse-tax/0.1.0"})
        self._recv_window = "5000"

    def _sign(self, params: dict, timestamp: str) -> str:
        param_str = timestamp + self.api_key + self._recv_window + urlencode(params)
        return hmac.new(
            self.api_secret.encode(),
            param_str.encode(),
            hashlib.sha256,
        ).hexdigest()

    def _get(self, endpoint: str, params: dict) -> dict:
        ts = str(int(time.time() * 1000))
        sig = self._sign(params, ts)
        headers = {
            "X-BAPI-API-KEY": self.api_key,
            "X-BAPI-TIMESTAMP": ts,
            "X-BAPI-SIGN": sig,
            "X-BAPI-RECV-WINDOW": self._recv_window,
        }
        resp = self.session.get(f"{BYBIT_BASE}{endpoint}", params=params, headers=headers)
        resp.raise_for_status()
        data = resp.json()
        if data.get("retCode") != 0:
            raise RuntimeError(f"Bybit API error: {data.get('retMsg')}")
        return data.get("result", {})

    def _year_to_ms(self, year: int):
        start = int(datetime(year, 1, 1, tzinfo=timezone.utc).timestamp() * 1000)
        end = int(datetime(year + 1, 1, 1, tzinfo=timezone.utc).timestamp() * 1000)
        return start, end

    def get_trades(self, year: int, category: str = "spot") -> List[Trade]:
        """Get all executed trades for a given year.

        Args:
            year: Calendar year (e.g. 2026)
            category: "spot", "linear" (perpetuals), "inverse"

        Returns:
            List of Trade objects sorted by timestamp.
        """
        start_ms, end_ms = self._year_to_ms(year)
        trades = []
        cursor = None

        while True:
            params = {
                "category": category,
                "startTime": start_ms,
                "endTime": end_ms - 1,
                "limit": "100",
            }
            if cursor:
                params["cursor"] = cursor

            result = self._get("/v5/execution/list", params)
            items = result.get("list", [])

            for t in items:
                symbol = t.get("symbol", "")
                base, quote = self._split_symbol(symbol)
                qty = float(t.get("execQty", 0))
                price = float(t.get("execPrice", 0))
                side = t.get("side", "Buy").lower()
                exec_time = int(t.get("execTime", 0))

                trades.append(Trade(
                    exchange=self.EXCHANGE,
                    trade_id=t.get("execId", ""),
                    timestamp=datetime.fromtimestamp(exec_time / 1000, tz=timezone.utc),
                    pair=f"{base}/{quote}",
                    base_asset=base,
                    quote_asset=quote,
                    side=side,
                    quantity=qty,
                    price=price,
                    fee=float(t.get("execFee", 0)),
                    fee_asset=t.get("feeCurrency", quote),
                    total=qty * price,
                ))

            cursor = result.get("nextPageCursor")
            if not cursor or not items:
                break

        trades.sort(key=lambda x: x.timestamp)
        return trades

    def get_transfers(self, year: int) -> List[Transfer]:
        """Get all deposits and withdrawals for a given year.

        Args:
            year: Calendar year (e.g. 2026)

        Returns:
            List of Transfer objects sorted by timestamp.
        """
        start_ms, end_ms = self._year_to_ms(year)
        transfers = []
        cursor = None

        # Deposits
        while True:
            params = {
                "startTime": str(start_ms),
                "endTime": str(end_ms - 1),
                "limit": "50",
            }
            if cursor:
                params["cursor"] = cursor

            result = self._get("/v5/asset/deposit/query-record", params)
            items = result.get("rows", [])

            for d in items:
                if str(d.get("status")) != "3":  # 3 = deposit success
                    continue
                ts = int(d.get("createTime", 0))
                transfers.append(Transfer(
                    exchange=self.EXCHANGE,
                    transfer_id=d.get("txID", ""),
                    timestamp=datetime.fromtimestamp(ts / 1000, tz=timezone.utc),
                    asset=d.get("coin", ""),
                    amount=float(d.get("amount", 0)),
                    direction="deposit",
                    address=d.get("toAddress"),
                    tx_hash=d.get("txID"),
                ))

            cursor = result.get("nextPageCursor")
            if not cursor or not items:
                break

        cursor = None
        # Withdrawals
        while True:
            params = {
                "startTime": str(start_ms),
                "endTime": str(end_ms - 1),
                "limit": "50",
            }
            if cursor:
                params["cursor"] = cursor

            result = self._get("/v5/asset/withdraw/query-record", params)
            items = result.get("rows", [])

            for w in items:
                if str(w.get("status")) != "SecurityCheck":
                    pass  # include all completed statuses
                ts = int(w.get("createTime", 0))
                transfers.append(Transfer(
                    exchange=self.EXCHANGE,
                    transfer_id=w.get("withdrawId", ""),
                    timestamp=datetime.fromtimestamp(ts / 1000, tz=timezone.utc),
                    asset=w.get("coin", ""),
                    amount=float(w.get("amount", 0)),
                    direction="withdrawal",
                    address=w.get("toAddress"),
                    tx_hash=w.get("txID"),
                    fee=float(w.get("withdrawFee", 0)),
                    fee_asset=w.get("coin", ""),
                ))

            cursor = result.get("nextPageCursor")
            if not cursor or not items:
                break

        transfers.sort(key=lambda x: x.timestamp)
        return transfers

    def _split_symbol(self, symbol: str) -> tuple:
        quotes = ["USDT", "USDC", "BTC", "ETH", "EUR"]
        for quote in quotes:
            if symbol.endswith(quote):
                return symbol[:-len(quote)], quote
        return symbol[:-4], symbol[-4:]
