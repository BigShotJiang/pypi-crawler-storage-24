"""Binance trade history collector for PULSE Tax."""

import hashlib
import hmac
import time
from datetime import datetime, timezone
from typing import List, Optional
from urllib.parse import urlencode

import requests

from pulse_tax.models import Trade, Transfer


BINANCE_BASE = "https://api.binance.com"


class BinanceCollector:
    """Collects trade history and transfers from Binance.

    Requires read-only API key with permissions:
    - Read (spot trade history)
    - Enable Withdrawals (to read withdrawal history)

    Example:
        >>> collector = BinanceCollector(api_key="...", api_secret="...")
        >>> trades = collector.get_trades(year=2026)
        >>> transfers = collector.get_transfers(year=2026)
    """

    EXCHANGE = "binance"

    def __init__(self, api_key: str, api_secret: str):
        self.api_key = api_key
        self.api_secret = api_secret
        self.session = requests.Session()
        self.session.headers.update({
            "X-MBX-APIKEY": api_key,
            "User-Agent": "pulse-tax/0.1.0",
        })

    def _sign(self, params: dict) -> dict:
        params["timestamp"] = int(time.time() * 1000)
        query = urlencode(params)
        signature = hmac.new(
            self.api_secret.encode(),
            query.encode(),
            hashlib.sha256,
        ).hexdigest()
        params["signature"] = signature
        return params

    def _get(self, endpoint: str, params: dict) -> dict:
        params = self._sign(params)
        resp = self.session.get(f"{BINANCE_BASE}{endpoint}", params=params)
        resp.raise_for_status()
        return resp.json()

    def _year_to_ms(self, year: int):
        start = int(datetime(year, 1, 1, tzinfo=timezone.utc).timestamp() * 1000)
        end = int(datetime(year + 1, 1, 1, tzinfo=timezone.utc).timestamp() * 1000)
        return start, end

    def get_exchange_symbols(self) -> List[str]:
        """Get all trading symbols from Binance."""
        resp = requests.get(f"{BINANCE_BASE}/api/v3/exchangeInfo")
        resp.raise_for_status()
        data = resp.json()
        return [s["symbol"] for s in data["symbols"] if s["status"] == "TRADING"]

    def get_trades(self, year: int, symbols: Optional[List[str]] = None) -> List[Trade]:
        """Get all executed trades for a given year.

        Args:
            year: Calendar year (e.g. 2026)
            symbols: Optional list of symbols to query (e.g. ["BTCUSDT", "ETHUSDT"]).
                     If None, queries all symbols the account has traded.

        Returns:
            List of Trade objects sorted by timestamp.
        """
        start_ms, end_ms = self._year_to_ms(year)
        trades = []

        if symbols is None:
            # Get symbols from account's trade history
            symbols = self._get_traded_symbols(start_ms, end_ms)

        for symbol in symbols:
            raw = self._get("/api/v3/myTrades", {
                "symbol": symbol,
                "startTime": start_ms,
                "endTime": end_ms - 1,
                "limit": 1000,
            })
            for t in raw:
                base, quote = self._split_symbol(symbol)
                qty = float(t["qty"])
                price = float(t["price"])
                trades.append(Trade(
                    exchange=self.EXCHANGE,
                    trade_id=str(t["id"]),
                    timestamp=datetime.fromtimestamp(t["time"] / 1000, tz=timezone.utc),
                    pair=f"{base}/{quote}",
                    base_asset=base,
                    quote_asset=quote,
                    side="buy" if t["isBuyer"] else "sell",
                    quantity=qty,
                    price=price,
                    fee=float(t["commission"]),
                    fee_asset=t["commissionAsset"],
                    total=qty * price,
                ))

        trades.sort(key=lambda x: x.timestamp)
        return trades

    def get_transfers(self, year: int) -> List[Transfer]:
        """Get all deposits and withdrawals for a given year.

        Args:
            year: Calendar year (e.g. 2026)

        Returns:
            List of Transfer objects sorted by timestamp.
        """
        start_ms, end_ms = self._year_to_ms(year)
        transfers = []

        # Deposits
        deposits = self._get("/sapi/v1/capital/deposit/hisrec", {
            "startTime": start_ms,
            "endTime": end_ms - 1,
        })
        for d in deposits:
            if d.get("status") != 1:  # 1 = success
                continue
            transfers.append(Transfer(
                exchange=self.EXCHANGE,
                transfer_id=d.get("id", d.get("txId", "")),
                timestamp=datetime.fromtimestamp(d["insertTime"] / 1000, tz=timezone.utc),
                asset=d["coin"],
                amount=float(d["amount"]),
                direction="deposit",
                address=d.get("address"),
                tx_hash=d.get("txId"),
            ))

        # Withdrawals
        withdrawals = self._get("/sapi/v1/capital/withdraw/history", {
            "startTime": start_ms,
            "endTime": end_ms - 1,
        })
        for w in withdrawals:
            if w.get("status") != 6:  # 6 = completed
                continue
            transfers.append(Transfer(
                exchange=self.EXCHANGE,
                transfer_id=w.get("id", ""),
                timestamp=datetime.fromtimestamp(w["applyTime"] / 1000
                    if isinstance(w.get("applyTime"), (int, float))
                    else int(datetime.fromisoformat(str(w["applyTime"])).timestamp()),
                    tz=timezone.utc),
                asset=w["coin"],
                amount=float(w["amount"]),
                direction="withdrawal",
                address=w.get("address"),
                tx_hash=w.get("txId"),
                fee=float(w.get("transactionFee", 0)),
                fee_asset=w["coin"],
            ))

        transfers.sort(key=lambda x: x.timestamp)
        return transfers

    def _get_traded_symbols(self, start_ms: int, end_ms: int) -> List[str]:
        """Get symbols this account has trades in by checking account's order history."""
        # Binance doesn't have a "get all traded symbols" endpoint directly.
        # Common approach: check a predefined list of popular pairs.
        # Users can override by passing explicit symbols.
        popular = [
            "BTCUSDT", "ETHUSDT", "BNBUSDT", "SOLUSDT", "XRPUSDT",
            "ADAUSDT", "AVAXUSDT", "DOTUSDT", "MATICUSDT", "LINKUSDT",
            "LTCUSDT", "UNIUSDT", "ATOMUSDT", "FTMUSDT", "NEARUSDT",
            "BTCBUSD", "ETHBUSD", "BTCEUR", "ETHEUR",
        ]
        traded = []
        for symbol in popular:
            try:
                result = self._get("/api/v3/myTrades", {
                    "symbol": symbol,
                    "startTime": start_ms,
                    "endTime": end_ms - 1,
                    "limit": 1,
                })
                if result:
                    traded.append(symbol)
            except Exception:
                pass
        return traded

    def _split_symbol(self, symbol: str) -> tuple:
        """Split a Binance symbol into base/quote assets."""
        # Known stablecoins/quote assets (order matters — check longer first)
        quotes = ["USDT", "BUSD", "USDC", "BTC", "ETH", "BNB", "EUR", "GBP"]
        for quote in quotes:
            if symbol.endswith(quote):
                base = symbol[:-len(quote)]
                return base, quote
        return symbol[:-4], symbol[-4:]
