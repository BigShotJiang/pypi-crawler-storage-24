"""Kraken trade history collector for PULSE Tax."""

import hashlib
import hmac
import base64
import time
import urllib.parse
from datetime import datetime, timezone
from typing import List

import requests

from pulse_tax.models import Trade, Transfer


KRAKEN_BASE = "https://api.kraken.com"


class KrakenCollector:
    """Collects trade history and transfers from Kraken.

    Example:
        >>> collector = KrakenCollector(api_key="...", api_secret="...")
        >>> trades = collector.get_trades(year=2026)
    """

    EXCHANGE = "kraken"

    def __init__(self, api_key: str, api_secret: str):
        self.api_key = api_key
        self.api_secret = api_secret
        self.session = requests.Session()
        self.session.headers.update({"User-Agent": "pulse-tax/0.1.0"})

    def _sign(self, urlpath: str, data: dict) -> str:
        postdata = urllib.parse.urlencode(data)
        encoded = (str(data["nonce"]) + postdata).encode()
        message = urlpath.encode() + hashlib.sha256(encoded).digest()
        mac = hmac.new(
            base64.b64decode(self.api_secret),
            message,
            hashlib.sha512,
        )
        return base64.b64encode(mac.digest()).decode()

    def _post(self, endpoint: str, params: dict) -> dict:
        urlpath = f"/0/private/{endpoint}"
        params["nonce"] = str(int(time.time() * 1000))
        sig = self._sign(urlpath, params)
        headers = {
            "API-Key": self.api_key,
            "API-Sign": sig,
        }
        resp = self.session.post(
            f"{KRAKEN_BASE}{urlpath}",
            data=params,
            headers=headers,
        )
        resp.raise_for_status()
        data = resp.json()
        if data.get("error"):
            raise RuntimeError(f"Kraken API error: {data['error']}")
        return data.get("result", {})

    def get_trades(self, year: int) -> List[Trade]:
        """Get all executed trades for a given year.

        Args:
            year: Calendar year (e.g. 2026)

        Returns:
            List of Trade objects sorted by timestamp.
        """
        start = datetime(year, 1, 1, tzinfo=timezone.utc).timestamp()
        end = datetime(year + 1, 1, 1, tzinfo=timezone.utc).timestamp()
        trades = []
        offset = 0

        while True:
            result = self._post("TradesHistory", {
                "start": str(int(start)),
                "end": str(int(end)),
                "ofs": str(offset),
            })
            raw_trades = result.get("trades", {})
            if not raw_trades:
                break

            for tx_id, t in raw_trades.items():
                pair = t.get("pair", "")
                base, quote = self._split_kraken_pair(pair)
                qty = float(t.get("vol", 0))
                price = float(t.get("price", 0))

                trades.append(Trade(
                    exchange=self.EXCHANGE,
                    trade_id=tx_id,
                    timestamp=datetime.fromtimestamp(float(t["time"]), tz=timezone.utc),
                    pair=f"{base}/{quote}",
                    base_asset=base,
                    quote_asset=quote,
                    side=t.get("type", "buy"),
                    quantity=qty,
                    price=price,
                    fee=float(t.get("fee", 0)),
                    fee_asset=quote,
                    total=qty * price,
                ))

            count = result.get("count", 0)
            offset += len(raw_trades)
            if offset >= count:
                break

        trades.sort(key=lambda x: x.timestamp)
        return trades

    def get_transfers(self, year: int) -> List[Transfer]:
        """Get all deposits and withdrawals for a given year."""
        start = datetime(year, 1, 1, tzinfo=timezone.utc).timestamp()
        end = datetime(year + 1, 1, 1, tzinfo=timezone.utc).timestamp()
        transfers = []

        result = self._post("Ledgers", {
            "type": "deposit",
            "start": str(int(start)),
            "end": str(int(end)),
        })
        for lid, ledger in result.get("ledger", {}).items():
            transfers.append(Transfer(
                exchange=self.EXCHANGE,
                transfer_id=lid,
                timestamp=datetime.fromtimestamp(float(ledger["time"]), tz=timezone.utc),
                asset=ledger.get("asset", ""),
                amount=abs(float(ledger.get("amount", 0))),
                direction="deposit",
                fee=abs(float(ledger.get("fee", 0))),
                fee_asset=ledger.get("asset", ""),
            ))

        result = self._post("Ledgers", {
            "type": "withdrawal",
            "start": str(int(start)),
            "end": str(int(end)),
        })
        for lid, ledger in result.get("ledger", {}).items():
            transfers.append(Transfer(
                exchange=self.EXCHANGE,
                transfer_id=lid,
                timestamp=datetime.fromtimestamp(float(ledger["time"]), tz=timezone.utc),
                asset=ledger.get("asset", ""),
                amount=abs(float(ledger.get("amount", 0))),
                direction="withdrawal",
                fee=abs(float(ledger.get("fee", 0))),
                fee_asset=ledger.get("asset", ""),
            ))

        transfers.sort(key=lambda x: x.timestamp)
        return transfers

    def _split_kraken_pair(self, pair: str) -> tuple:
        """Kraken uses XXBTZUSD style pairs."""
        # Normalize common prefixes
        pair = pair.replace("XXBT", "BTC").replace("XETH", "ETH").replace("ZUSD", "USD").replace("ZEUR", "EUR")
        quotes = ["USDT", "USDC", "USD", "EUR", "BTC", "ETH"]
        for quote in quotes:
            if pair.endswith(quote):
                return pair[:-len(quote)], quote
        return pair[:-4], pair[-4:]
