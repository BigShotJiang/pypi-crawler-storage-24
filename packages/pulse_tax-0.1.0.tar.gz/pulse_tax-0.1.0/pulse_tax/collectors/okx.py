"""OKX trade history collector for PULSE Tax."""

import base64
import hashlib
import hmac
import time
from datetime import datetime, timezone
from typing import List

import requests

from pulse_tax.models import Trade, Transfer


OKX_BASE = "https://www.okx.com"


class OKXCollector:
    """Collects trade history and transfers from OKX.

    Example:
        >>> collector = OKXCollector(api_key="...", api_secret="...", passphrase="...")
        >>> trades = collector.get_trades(year=2026)
    """

    EXCHANGE = "okx"

    def __init__(self, api_key: str, api_secret: str, passphrase: str):
        self.api_key = api_key
        self.api_secret = api_secret
        self.passphrase = passphrase
        self.session = requests.Session()
        self.session.headers.update({"User-Agent": "pulse-tax/0.1.0"})

    def _sign(self, timestamp: str, method: str, path: str, body: str = "") -> str:
        message = timestamp + method + path + body
        return base64.b64encode(
            hmac.new(
                self.api_secret.encode(),
                message.encode(),
                hashlib.sha256,
            ).digest()
        ).decode()

    def _get(self, path: str, params: dict = None) -> dict:
        ts = datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%S.000Z")
        query = ""
        if params:
            query = "?" + "&".join(f"{k}={v}" for k, v in params.items())
        sig = self._sign(ts, "GET", path + query)
        headers = {
            "OK-ACCESS-KEY": self.api_key,
            "OK-ACCESS-SIGN": sig,
            "OK-ACCESS-TIMESTAMP": ts,
            "OK-ACCESS-PASSPHRASE": self.passphrase,
        }
        resp = self.session.get(f"{OKX_BASE}{path}", params=params, headers=headers)
        resp.raise_for_status()
        data = resp.json()
        if data.get("code") != "0":
            raise RuntimeError(f"OKX API error: {data.get('msg')}")
        return data.get("data", [])

    def _year_to_iso(self, year: int):
        start = datetime(year, 1, 1, tzinfo=timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
        end = datetime(year + 1, 1, 1, tzinfo=timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
        return start, end

    def get_trades(self, year: int, inst_type: str = "SPOT") -> List[Trade]:
        """Get all executed trades for a given year.

        Args:
            year: Calendar year (e.g. 2026)
            inst_type: "SPOT", "FUTURES", "SWAP", "OPTION"

        Returns:
            List of Trade objects sorted by timestamp.
        """
        start_ms = int(datetime(year, 1, 1, tzinfo=timezone.utc).timestamp() * 1000)
        end_ms = int(datetime(year + 1, 1, 1, tzinfo=timezone.utc).timestamp() * 1000)
        trades = []
        after = None

        while True:
            params = {
                "instType": inst_type,
                "begin": str(start_ms),
                "end": str(end_ms - 1),
                "limit": "100",
            }
            if after:
                params["after"] = after

            items = self._get("/api/v5/trade/fills-history", params)
            if not items:
                break

            for t in items:
                inst_id = t.get("instId", "")
                parts = inst_id.split("-")
                base = parts[0] if len(parts) >= 2 else inst_id
                quote = parts[1] if len(parts) >= 2 else "USDT"
                qty = float(t.get("fillSz", 0))
                price = float(t.get("fillPx", 0))
                ts_ms = int(t.get("ts", 0))
                side = t.get("side", "buy")

                trades.append(Trade(
                    exchange=self.EXCHANGE,
                    trade_id=t.get("tradeId", t.get("fillId", "")),
                    timestamp=datetime.fromtimestamp(ts_ms / 1000, tz=timezone.utc),
                    pair=f"{base}/{quote}",
                    base_asset=base,
                    quote_asset=quote,
                    side=side,
                    quantity=qty,
                    price=price,
                    fee=abs(float(t.get("fee", 0))),
                    fee_asset=t.get("feeCcy", quote),
                    total=qty * price,
                ))

            # OKX pagination: use oldest ID as cursor
            after = items[-1].get("billId") if items else None
            if len(items) < 100:
                break

        trades.sort(key=lambda x: x.timestamp)
        return trades

    def get_transfers(self, year: int) -> List[Transfer]:
        """Get all deposits and withdrawals for a given year."""
        start_ms = int(datetime(year, 1, 1, tzinfo=timezone.utc).timestamp() * 1000)
        end_ms = int(datetime(year + 1, 1, 1, tzinfo=timezone.utc).timestamp() * 1000)
        transfers = []

        # Deposits
        items = self._get("/api/v5/asset/deposit-history", {
            "state": "2",  # 2 = successful
        })
        for d in items:
            ts_ms = int(d.get("ts", 0))
            if not (start_ms <= ts_ms < end_ms):
                continue
            transfers.append(Transfer(
                exchange=self.EXCHANGE,
                transfer_id=d.get("depId", d.get("txId", "")),
                timestamp=datetime.fromtimestamp(ts_ms / 1000, tz=timezone.utc),
                asset=d.get("ccy", ""),
                amount=float(d.get("amt", 0)),
                direction="deposit",
                address=d.get("to"),
                tx_hash=d.get("txId"),
            ))

        # Withdrawals
        items = self._get("/api/v5/asset/withdrawal-history", {
            "state": "2",  # 2 = success
        })
        for w in items:
            ts_ms = int(w.get("ts", 0))
            if not (start_ms <= ts_ms < end_ms):
                continue
            transfers.append(Transfer(
                exchange=self.EXCHANGE,
                transfer_id=w.get("wdId", w.get("txId", "")),
                timestamp=datetime.fromtimestamp(ts_ms / 1000, tz=timezone.utc),
                asset=w.get("ccy", ""),
                amount=float(w.get("amt", 0)),
                direction="withdrawal",
                address=w.get("to"),
                tx_hash=w.get("txId"),
                fee=float(w.get("fee", 0)),
                fee_asset=w.get("ccy", ""),
            ))

        transfers.sort(key=lambda x: x.timestamp)
        return transfers
