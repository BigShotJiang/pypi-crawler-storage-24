"""Data models for PULSE Tax — normalized trade/deposit/withdrawal records."""

from dataclasses import dataclass, field
from datetime import datetime
from typing import Optional


@dataclass
class Trade:
    """A single executed trade (buy or sell)."""
    exchange: str           # "binance", "bybit", "kraken", "okx"
    trade_id: str           # Exchange-specific trade ID
    timestamp: datetime     # UTC execution time
    pair: str               # e.g. "BTC/USDT"
    base_asset: str         # e.g. "BTC"
    quote_asset: str        # e.g. "USDT"
    side: str               # "buy" or "sell"
    quantity: float         # Amount of base asset
    price: float            # Price per unit in quote asset
    fee: float              # Fee amount
    fee_asset: str          # Asset fee was paid in (e.g. "BNB", "USDT")
    total: float            # Total in quote asset (quantity * price)

    def to_dict(self) -> dict:
        return {
            "exchange": self.exchange,
            "trade_id": self.trade_id,
            "timestamp": self.timestamp.isoformat(),
            "pair": self.pair,
            "base_asset": self.base_asset,
            "quote_asset": self.quote_asset,
            "side": self.side,
            "quantity": self.quantity,
            "price": self.price,
            "fee": self.fee,
            "fee_asset": self.fee_asset,
            "total": self.total,
        }


@dataclass
class Transfer:
    """A deposit or withdrawal."""
    exchange: str
    transfer_id: str
    timestamp: datetime
    asset: str              # e.g. "BTC"
    amount: float
    direction: str          # "deposit" or "withdrawal"
    address: Optional[str] = None
    tx_hash: Optional[str] = None
    fee: float = 0.0
    fee_asset: Optional[str] = None

    def to_dict(self) -> dict:
        return {
            "exchange": self.exchange,
            "transfer_id": self.transfer_id,
            "timestamp": self.timestamp.isoformat(),
            "asset": self.asset,
            "amount": self.amount,
            "direction": self.direction,
            "address": self.address,
            "tx_hash": self.tx_hash,
            "fee": self.fee,
            "fee_asset": self.fee_asset,
        }


@dataclass
class TaxReport:
    """Aggregated tax data for a period."""
    year: int
    trades: list = field(default_factory=list)
    transfers: list = field(default_factory=list)
    exchanges: list = field(default_factory=list)

    @property
    def total_trades(self) -> int:
        return len(self.trades)

    @property
    def total_transfers(self) -> int:
        return len(self.transfers)
