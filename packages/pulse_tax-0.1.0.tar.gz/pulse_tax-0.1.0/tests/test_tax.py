"""Tests for PULSE Tax."""

import pytest
from datetime import datetime, timezone
from unittest.mock import MagicMock, patch

from pulse_tax import TaxCollector, Trade, Transfer, TaxReport
from pulse_tax import KoinlyExporter, CoinTrackerExporter, JSONExporter
from pulse_tax.collector import TaxCollector


# --- Fixtures ---

@pytest.fixture
def sample_trade():
    return Trade(
        exchange="binance",
        trade_id="123456",
        timestamp=datetime(2026, 3, 15, 10, 30, 0, tzinfo=timezone.utc),
        pair="BTC/USDT",
        base_asset="BTC",
        quote_asset="USDT",
        side="buy",
        quantity=0.5,
        price=83000.0,
        fee=2.075,
        fee_asset="BNB",
        total=41500.0,
    )


@pytest.fixture
def sample_sell_trade():
    return Trade(
        exchange="bybit",
        trade_id="789",
        timestamp=datetime(2026, 6, 20, 14, 0, 0, tzinfo=timezone.utc),
        pair="ETH/USDT",
        base_asset="ETH",
        quote_asset="USDT",
        side="sell",
        quantity=2.0,
        price=3500.0,
        fee=3.5,
        fee_asset="USDT",
        total=7000.0,
    )


@pytest.fixture
def sample_deposit():
    return Transfer(
        exchange="binance",
        transfer_id="dep001",
        timestamp=datetime(2026, 1, 5, 9, 0, 0, tzinfo=timezone.utc),
        asset="USDT",
        amount=10000.0,
        direction="deposit",
        tx_hash="0xabc123",
    )


@pytest.fixture
def sample_withdrawal():
    return Transfer(
        exchange="kraken",
        transfer_id="wd001",
        timestamp=datetime(2026, 12, 10, 18, 0, 0, tzinfo=timezone.utc),
        asset="BTC",
        amount=0.1,
        direction="withdrawal",
        fee=0.0001,
        fee_asset="BTC",
        address="bc1qxyz",
    )


# --- Model tests ---

class TestTradeModel:
    def test_trade_creation(self, sample_trade):
        assert sample_trade.exchange == "binance"
        assert sample_trade.side == "buy"
        assert sample_trade.pair == "BTC/USDT"
        assert sample_trade.quantity == 0.5
        assert sample_trade.total == 41500.0

    def test_trade_to_dict(self, sample_trade):
        d = sample_trade.to_dict()
        assert d["exchange"] == "binance"
        assert d["trade_id"] == "123456"
        assert d["side"] == "buy"
        assert d["base_asset"] == "BTC"
        assert d["quote_asset"] == "USDT"
        assert "timestamp" in d

    def test_sell_trade(self, sample_sell_trade):
        assert sample_sell_trade.side == "sell"
        assert sample_sell_trade.exchange == "bybit"


class TestTransferModel:
    def test_deposit(self, sample_deposit):
        assert sample_deposit.direction == "deposit"
        assert sample_deposit.amount == 10000.0
        assert sample_deposit.tx_hash == "0xabc123"

    def test_withdrawal(self, sample_withdrawal):
        assert sample_withdrawal.direction == "withdrawal"
        assert sample_withdrawal.fee == 0.0001
        assert sample_withdrawal.address == "bc1qxyz"

    def test_transfer_to_dict(self, sample_deposit):
        d = sample_deposit.to_dict()
        assert d["direction"] == "deposit"
        assert d["asset"] == "USDT"
        assert d["amount"] == 10000.0


class TestTaxReport:
    def test_empty_report(self):
        report = TaxReport(year=2026)
        assert report.total_trades == 0
        assert report.total_transfers == 0
        assert report.exchanges == []

    def test_report_with_data(self, sample_trade, sample_deposit):
        report = TaxReport(year=2026)
        report.trades.append(sample_trade)
        report.transfers.append(sample_deposit)
        assert report.total_trades == 1
        assert report.total_transfers == 1


# --- Collector tests ---

class TestTaxCollector:
    def test_add_exchange(self):
        collector = TaxCollector()
        mock = MagicMock()
        mock.EXCHANGE = "binance"
        collector.add_exchange(mock)
        assert len(collector._collectors) == 1

    def test_collect_calls_get_trades(self, sample_trade):
        collector = TaxCollector()
        mock = MagicMock()
        mock.EXCHANGE = "binance"
        mock.get_trades.return_value = [sample_trade]
        mock.get_transfers.return_value = []
        collector.add_exchange(mock)

        report = collector.collect(year=2026)
        mock.get_trades.assert_called_once_with(year=2026)
        assert report.total_trades == 1
        assert "binance" in report.exchanges

    def test_collect_multiple_exchanges(self, sample_trade, sample_sell_trade):
        collector = TaxCollector()
        for exchange, trade in [("binance", sample_trade), ("bybit", sample_sell_trade)]:
            mock = MagicMock()
            mock.EXCHANGE = exchange
            mock.get_trades.return_value = [trade]
            mock.get_transfers.return_value = []
            collector.add_exchange(mock)

        report = collector.collect(year=2026)
        assert report.total_trades == 2
        assert set(report.exchanges) == {"binance", "bybit"}

    def test_collect_handles_error_gracefully(self):
        collector = TaxCollector()
        mock = MagicMock()
        mock.EXCHANGE = "binance"
        mock.get_trades.side_effect = RuntimeError("API error")
        mock.get_transfers.return_value = []
        collector.add_exchange(mock)

        # Should not raise
        report = collector.collect(year=2026)
        assert report.total_trades == 0

    def test_collect_sorted_by_timestamp(self, sample_trade, sample_sell_trade):
        collector = TaxCollector()
        mock = MagicMock()
        mock.EXCHANGE = "test"
        # Return trades in wrong order
        mock.get_trades.return_value = [sample_sell_trade, sample_trade]
        mock.get_transfers.return_value = []
        collector.add_exchange(mock)

        report = collector.collect(year=2026)
        assert report.trades[0].timestamp < report.trades[1].timestamp


# --- Koinly exporter tests ---

class TestKoinlyExporter:
    def test_export_buy_trade(self, sample_trade):
        exporter = KoinlyExporter()
        csv = exporter.export([sample_trade], [])
        assert "BTC" in csv
        assert "USDT" in csv
        assert "trade" in csv
        assert "buy" not in csv  # Koinly uses Sent/Received, not buy/sell

    def test_export_sell_trade(self, sample_sell_trade):
        exporter = KoinlyExporter()
        csv = exporter.export([sample_sell_trade], [])
        assert "ETH" in csv
        assert "USDT" in csv

    def test_export_deposit(self, sample_deposit):
        exporter = KoinlyExporter()
        csv = exporter.export([], [sample_deposit])
        assert "deposit" in csv
        assert "USDT" in csv
        assert "10000" in csv

    def test_export_withdrawal(self, sample_withdrawal):
        exporter = KoinlyExporter()
        csv = exporter.export([], [sample_withdrawal])
        assert "withdrawal" in csv
        assert "BTC" in csv

    def test_csv_has_header(self, sample_trade):
        exporter = KoinlyExporter()
        csv = exporter.export([sample_trade], [])
        first_line = csv.split("\n")[0]
        assert "Date" in first_line
        assert "Sent Amount" in first_line
        assert "Received Amount" in first_line

    def test_export_empty(self):
        exporter = KoinlyExporter()
        csv = exporter.export([], [])
        assert "Date" in csv  # header only


# --- CoinTracker exporter tests ---

class TestCoinTrackerExporter:
    def test_export_buy_trade(self, sample_trade):
        exporter = CoinTrackerExporter()
        csv = exporter.export([sample_trade], [])
        assert "BTC" in csv
        assert "USDT" in csv

    def test_csv_has_header(self, sample_trade):
        exporter = CoinTrackerExporter()
        csv = exporter.export([sample_trade], [])
        first_line = csv.split("\n")[0]
        assert "Date" in first_line
        assert "Received Quantity" in first_line

    def test_export_deposit(self, sample_deposit):
        exporter = CoinTrackerExporter()
        csv = exporter.export([], [sample_deposit])
        assert "USDT" in csv


# --- JSON exporter tests ---

class TestJSONExporter:
    def test_export_json(self, sample_trade, sample_deposit):
        import json
        report = TaxReport(year=2026)
        report.trades.append(sample_trade)
        report.transfers.append(sample_deposit)
        report.exchanges = ["binance"]

        exporter = JSONExporter()
        result = json.loads(exporter.export(report))

        assert result["year"] == 2026
        assert result["summary"]["total_trades"] == 1
        assert result["summary"]["total_transfers"] == 1
        assert len(result["trades"]) == 1
        assert len(result["transfers"]) == 1
        assert result["exchanges"] == ["binance"]

    def test_export_version_field(self):
        import json
        report = TaxReport(year=2026)
        exporter = JSONExporter()
        result = json.loads(exporter.export(report))
        assert "pulse_tax_version" in result


# --- Integration test ---

class TestIntegration:
    def test_full_pipeline(self, sample_trade, sample_sell_trade, sample_deposit, sample_withdrawal):
        """Full pipeline: collect → export to all formats."""
        collector = TaxCollector()

        mock_binance = MagicMock()
        mock_binance.EXCHANGE = "binance"
        mock_binance.get_trades.return_value = [sample_trade]
        mock_binance.get_transfers.return_value = [sample_deposit]

        mock_bybit = MagicMock()
        mock_bybit.EXCHANGE = "bybit"
        mock_bybit.get_trades.return_value = [sample_sell_trade]
        mock_bybit.get_transfers.return_value = [sample_withdrawal]

        collector.add_exchange(mock_binance)
        collector.add_exchange(mock_bybit)

        report = collector.collect(year=2026)
        assert report.total_trades == 2
        assert report.total_transfers == 2

        # Koinly export
        koinly_csv = KoinlyExporter().export(report.trades, report.transfers)
        assert len(koinly_csv) > 100

        # CoinTracker export
        ct_csv = CoinTrackerExporter().export(report.trades, report.transfers)
        assert len(ct_csv) > 100

        # JSON export
        import json
        json_data = json.loads(JSONExporter().export(report))
        assert json_data["summary"]["total_trades"] == 2
