#!/usr/bin/env python3
"""
Example test suite using DubboTestCase with pytest.
"""

import sys
sys.path.insert(0, '..')  # Add parent directory to path

from dubbo_testing import DubboTestCase


class TestUserService(DubboTestCase):
    """Test suite for UserService."""
    
    SERVICE_NAME = 'UserService'
    
    def test_initial_count(self):
        """Test initial user count should be zero."""
        count = self.get_user_count()
        assert count == 0
    
    def test_create_user(self):
        """Test creating a user."""
        # Create user
        user = self.create_user('Test User', 'test@example.com')
        assert user is not None
        assert 'id' in user
        assert user['name'] == 'Test User'
        assert user['email'] == 'test@example.com'
        
        # Verify count increased
        count = self.get_user_count()
        assert count == 1
        
        # Clean up
        self.delete_user(user['id'])
    
    def test_get_user(self):
        """Test getting a user by ID."""
        # Create user
        user = self.create_user('Get Test', 'get@example.com')
        user_id = user['id']
        
        # Get user
        fetched = self.get_user(user_id)
        assert fetched is not None
        assert fetched['id'] == user_id
        assert fetched['name'] == 'Get Test'
        
        # Clean up
        self.delete_user(user_id)
    
    def test_get_nonexistent_user(self):
        """Test getting a non-existent user returns None."""
        # Use a large ID that likely doesn't exist
        result = self.get_user(99999)
        assert result is None
    
    def test_update_user(self):
        """Test updating a user."""
        # Create user
        user = self.create_user('Update Test', 'update@example.com')
        user_id = user['id']
        
        # Update user
        updated = self.update_user(user_id, name='Updated Name', email='updated@example.com')
        assert updated is not None
        assert updated['name'] == 'Updated Name'
        assert updated['email'] == 'updated@example.com'
        
        # Verify update
        fetched = self.get_user(user_id)
        assert fetched['name'] == 'Updated Name'
        
        # Clean up
        self.delete_user(user_id)
    
    def test_partial_update(self):
        """Test partial update (only name)."""
        user = self.create_user('Partial Test', 'partial@example.com')
        user_id = user['id']
        
        # Update only name
        updated = self.update_user(user_id, name='New Name Only')
        assert updated['name'] == 'New Name Only'
        # Email should remain unchanged
        assert updated['email'] == 'partial@example.com'
        
        self.delete_user(user_id)
    
    def test_delete_user(self):
        """Test deleting a user."""
        user = self.create_user('Delete Test', 'delete@example.com')
        user_id = user['id']
        
        # Delete user
        deleted = self.delete_user(user_id)
        assert deleted
        
        # Verify user is gone
        fetched = self.get_user(user_id)
        assert fetched is None
        
        # Verify count decreased
        count = self.get_user_count()
        assert count == 0
    
    def test_delete_nonexistent_user(self):
        """Test deleting a non-existent user returns false."""
        result = self.delete_user(99999)
        assert not result
    
    def test_get_all_users(self):
        """Test getting all users."""
        # Clear any existing users
        users = self.get_all_users()
        for user in users:
            self.delete_user(user['id'])
        
        # Create some users
        user1 = self.create_user('User One', 'one@example.com')
        user2 = self.create_user('User Two', 'two@example.com')
        
        # Get all users
        all_users = self.get_all_users()
        assert len(all_users) == 2
        
        # Verify users exist
        self.assertUserExists(all_users, user1['id'], 'User One', 'one@example.com')
        self.assertUserExists(all_users, user2['id'], 'User Two', 'two@example.com')
        
        # Clean up
        self.delete_user(user1['id'])
        self.delete_user(user2['id'])
    
    def test_crud_workflow(self):
        """Test complete CRUD workflow."""
        # Start with zero users
        count = self.get_user_count()
        assert count == 0
        
        # Create user
        user = self.create_user('Workflow Test', 'workflow@example.com')
        user_id = user['id']
        assert self.get_user_count() == 1
        
        # Read user
        fetched = self.get_user(user_id)
        assert fetched is not None
        
        # Update user
        updated = self.update_user(user_id, name='Updated Workflow')
        assert updated['name'] == 'Updated Workflow'
        
        # Delete user
        deleted = self.delete_user(user_id)
        assert deleted
        assert self.get_user_count() == 0


