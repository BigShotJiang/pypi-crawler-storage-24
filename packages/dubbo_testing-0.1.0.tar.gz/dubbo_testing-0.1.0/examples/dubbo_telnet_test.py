#!/usr/bin/env python3
"""
Dubbo QoS Telnet Client Example

This script demonstrates how to connect to Dubbo QoS telnet interface
and execute commands to test the Dubbo CRUD demo service.

Prerequisites:
1. Dubbo service is running with QoS enabled (qos.enable=true)
2. QoS port is accessible (default: 22222)
3. Python 3.x with standard library (telnetlib, json)

Usage:
    python3 dubbo_telnet_test.py [host] [port]
    Default: host=127.0.0.1, port=22222
"""

try:
    import telnetlib3 as telnetlib
except ImportError:
    import telnetlib
import json
import sys
import time

class DubboTelnetClient:
    """Simple Dubbo QoS Telnet client"""
    
    def __init__(self, host='127.0.0.1', port=22222, timeout=5):
        self.host = host
        self.port = port
        self.timeout = timeout
        self.tn = None
        
    def connect(self):
        """Establish connection to QoS service"""
        print(f"Connecting to {self.host}:{self.port}...")
        try:
            self.tn = telnetlib.Telnet(self.host, self.port, timeout=self.timeout)
            # Wait for initial prompt
            response = self.tn.read_until(b'dubbo>', timeout=self.timeout)
            if b'dubbo>' in response:
                print("Connected successfully!")
            else:
                print("Connected but no dubbo> prompt found")
            return True
        except Exception as e:
            print(f"Connection failed: {e}")
            return False
    
    def execute(self, command, wait_response=True):
        """Execute a command and return the response"""
        if not self.tn:
            raise RuntimeError("Not connected")
        
        # Send command with newline
        self.tn.write(command.encode('utf-8') + b'\n')
        
        if not wait_response:
            return ""
        
        # Read until next prompt or timeout
        response = self.tn.read_until(b'dubbo>', timeout=self.timeout).decode('utf-8')
        
        # Clean up the response: remove command echo and final prompt
        lines = response.strip().split('\n')
        result_lines = []
        for line in lines:
            line = line.strip()
            if line and line != command and line != 'dubbo>':
                result_lines.append(line)
        
        return '\n'.join(result_lines)
    
    def close(self):
        """Close the connection"""
        if self.tn:
            self.tn.close()
            print("Connection closed")

def main():
    # Parse command line arguments
    host = '127.0.0.1'
    port = 22222
    if len(sys.argv) > 1:
        host = sys.argv[1]
    if len(sys.argv) > 2:
        port = int(sys.argv[2])
    
    client = DubboTelnetClient(host, port)
    
    try:
        if not client.connect():
            sys.exit(1)
        
        # Give a moment for any initial messages
        time.sleep(0.5)
        
        print("\n1. Getting help...")
        help_result = client.execute('help')
        print(help_result[:200] + "..." if len(help_result) > 200 else help_result)
        
        print("\n2. Listing services...")
        services = client.execute('ls')
        print(services)
        
        print("\n3. Getting user count...")
        count = client.execute('invoke UserService.getUserCount()')
        print(f"User count: {count}")
        
        # Create a test user if count is low
        if count.strip().isdigit() and int(count.strip()) < 5:
            print("\n4. Creating a test user...")
            user_data = json.dumps({
                'name': 'Python Test User',
                'email': 'python@example.com'
            })
            create_result = client.execute(f'invoke UserService.createUser({user_data})')
            print(f"Created: {create_result}")
            
            # Get the new user's ID from the response
            try:
                user_obj = json.loads(create_result)
                user_id = user_obj.get('id')
                if user_id:
                    print(f"\n5. Getting user by ID {user_id}...")
                    get_result = client.execute(f'invoke UserService.getUserById({user_id})')
                    print(f"User: {get_result}")
            except json.JSONDecodeError:
                pass
            
            print("\n6. Getting all users...")
            all_users = client.execute('invoke UserService.getAllUsers()')
            print(f"All users: {all_users}")
            
            print("\n7. Getting updated user count...")
            new_count = client.execute('invoke UserService.getUserCount()')
            print(f"Updated user count: {new_count}")
        
        print("\n8. Testing service status...")
        status = client.execute('ps')
        if status:
            print("Service status retrieved (truncated):")
            print(status[:300] + "..." if len(status) > 300 else status)
        
        print("\n=== Test completed successfully ===")
        
    except KeyboardInterrupt:
        print("\nInterrupted by user")
    except Exception as e:
        print(f"\nError during test: {e}")
        import traceback
        traceback.print_exc()
    finally:
        client.close()

if __name__ == '__main__':
    main()