#!/usr/bin/env python3
"""
Basic usage example of dubbo_testing library.
"""

import sys
sys.path.insert(0, '..')  # Add parent directory to path

from dubbo_testing import TelnetDubboClient, assert_dubbo_success


def main():
    # Create client
    client = TelnetDubboClient(host='127.0.0.1', port=22222, timeout=5)
    
    try:
        # Connect
        print("Connecting to Dubbo QoS...")
        client.connect()
        print("Connected successfully!")
        
        # List services
        print("\n=== Listing services ===")
        services = client.list_services()
        print(services)
        
        # Get help
        print("\n=== Getting help ===")
        help_text = client.help()
        print(help_text[:200] + "..." if len(help_text) > 200 else help_text)
        
        # Get user count
        print("\n=== Getting user count ===")
        count = client.invoke('UserService', 'getUserCount')
        print(f"User count: {count}")
        
        # Create a user if count is low
        if isinstance(count, int) and count < 5:
            print("\n=== Creating test user ===")
            user_data = {
                'name': 'Python Library User',
                'email': 'library@example.com'
            }
            created = client.invoke('UserService', 'createUser', user_data)
            assert_dubbo_success(created)
            print(f"Created user: {created}")
            
            # Get the user by ID
            user_id = created.get('id')
            if user_id:
                print(f"\n=== Getting user by ID {user_id} ===")
                user = client.invoke('UserService', 'getUserById', user_id)
                print(f"User: {user}")
            
            # Get all users
            print("\n=== Getting all users ===")
            all_users = client.invoke('UserService', 'getAllUsers')
            print(f"All users: {all_users}")
            
            # Update user
            print("\n=== Updating user ===")
            updated_data = {'id': user_id, 'name': 'Updated Name'}
            updated = client.invoke('UserService', 'updateUser', updated_data)
            print(f"Updated user: {updated}")
            
            # Delete user
            print("\n=== Deleting user ===")
            deleted = client.invoke('UserService', 'deleteUser', user_id)
            print(f"Deleted: {deleted}")
            
            # Final count
            print("\n=== Final user count ===")
            final_count = client.invoke('UserService', 'getUserCount')
            print(f"Final user count: {final_count}")
        
        # Service status
        print("\n=== Service status ===")
        status = client.service_status()
        print(status[:300] + "..." if len(status) > 300 else status)
        
        print("\n=== Example completed successfully ===")
        
    except Exception as e:
        print(f"\nError: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)
    finally:
        client.close()


if __name__ == '__main__':
    main()