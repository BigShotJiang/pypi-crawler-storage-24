"""
Utility functions for Dubbo testing.
"""

import json
from typing import Any, Dict, List, Union


def json_to_dubbo_args(data: Union[Dict, List, str, int, float, bool, None]) -> str:
    """Convert Python data to Dubbo QoS argument string.
    
    Args:
        data: Python data to convert
        
    Returns:
        String representation suitable for Dubbo invoke command
    """
    if isinstance(data, (dict, list)):
        return json.dumps(data, ensure_ascii=False)
    elif isinstance(data, str):
        return json.dumps(data)
    elif data is None:
        return 'null'
    elif isinstance(data, bool):
        return 'true' if data else 'false'
    else:
        return str(data)


def parse_response(response: str) -> Any:
    """Parse response from Dubbo QoS.
    
    Attempts to parse JSON, then numbers, then booleans.
    
    Args:
        response: Raw response string
        
    Returns:
        Parsed response
    """
    response = response.strip()
    if not response:
        return response
    
    # Try JSON
    try:
        return json.loads(response)
    except json.JSONDecodeError:
        pass
    
    # Try number
    try:
        if '.' in response:
            return float(response)
        else:
            return int(response)
    except ValueError:
        pass
    
    # Try boolean
    if response.lower() == 'true':
        return True
    if response.lower() == 'false':
        return False
    
    # Return as string
    return response


def to_json(data: Any) -> str:
    """Convert data to JSON string.
    
    Args:
        data: Data to convert
        
    Returns:
        JSON string
    """
    return json.dumps(data, ensure_ascii=False, indent=2)


def build_invoke_command(service: str, method: str, *args) -> str:
    """Build an invoke command for Dubbo QoS.
    
    Args:
        service: Service name
        method: Method name
        *args: Arguments
        
    Returns:
        invoke command string
    """
    arg_strs = [json_to_dubbo_args(arg) for arg in args]
    args_str = ','.join(arg_strs)
    return f'invoke {service}.{method}({args_str})'


def extract_user_id(user_data: Dict[str, Any]) -> int:
    """Extract user ID from user data.
    
    Args:
        user_data: User dictionary
        
    Returns:
        User ID
        
    Raises:
        KeyError: If id not found
    """
    if 'id' not in user_data:
        raise KeyError("User data missing 'id' field")
    return user_data['id']