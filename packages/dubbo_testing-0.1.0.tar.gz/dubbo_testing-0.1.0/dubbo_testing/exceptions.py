"""
Custom exceptions for Dubbo testing library.
"""


class DubboError(Exception):
    """Base exception for all Dubbo testing errors."""
    pass


class ConnectionError(DubboError):
    """Raised when connection to Dubbo service fails."""
    pass


class InvocationError(DubboError):
    """Raised when Dubbo service invocation fails."""
    pass


class TimeoutError(DubboError):
    """Raised when a Dubbo operation times out."""
    pass


class SerializationError(DubboError):
    """Raised when serialization/deserialization fails."""
    pass


class ConfigurationError(DubboError):
    """Raised when configuration is invalid."""
    pass