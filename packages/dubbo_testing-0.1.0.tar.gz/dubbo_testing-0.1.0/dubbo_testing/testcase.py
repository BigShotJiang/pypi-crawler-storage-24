"""
Test case base class for Dubbo testing.
"""

import unittest
from typing import Any, Dict, List, Optional

from .client import TelnetDubboClient
from .exceptions import DubboError


class DubboTestCase(unittest.TestCase):
    """Base test case for Dubbo service testing.
    
    Provides convenience methods for connecting to Dubbo service,
    invoking methods, and common assertions.
    """
    
    # Override these in subclass
    DUBBO_HOST: str = '127.0.0.1'
    DUBBO_PORT: int = 22222
    DUBBO_TIMEOUT: int = 5
    SERVICE_NAME: str = 'UserService'
    
    def setUp(self) -> None:
        """Set up test fixture."""
        super().setUp()
        self.client = TelnetDubboClient(
            host=self.DUBBO_HOST,
            port=self.DUBBO_PORT,
            timeout=self.DUBBO_TIMEOUT
        )
        self.client.connect()
    
    def tearDown(self) -> None:
        """Tear down test fixture."""
        if self.client:
            self.client.close()
        super().tearDown()
    
    def invoke(self, method: str, *args) -> Any:
        """Invoke a service method.
        
        Args:
            method: Method name
            *args: Arguments to pass
            
        Returns:
            The invocation result.
        """
        return self.client.invoke(self.SERVICE_NAME, method, *args)
    
    def assertDubboSuccess(self, response: Any, msg: Optional[str] = None) -> None:
        """Assert that Dubbo invocation was successful.
        
        Args:
            response: Response from invoke
            msg: Optional assertion message
        """
        try:
            from .assertions import assert_dubbo_success
            assert_dubbo_success(response)
        except AssertionError as e:
            if msg:
                raise AssertionError(f"{msg}: {e}")
            else:
                raise
    
    def assertDubboError(self, response: Any, expected_error: Optional[str] = None,
                        msg: Optional[str] = None) -> None:
        """Assert that Dubbo invocation resulted in error.
        
        Args:
            response: Response from invoke
            expected_error: Optional error substring to match
            msg: Optional assertion message
        """
        try:
            from .assertions import assert_dubbo_error
            assert_dubbo_error(response, expected_error)
        except AssertionError as e:
            if msg:
                raise AssertionError(f"{msg}: {e}")
            else:
                raise
    
    def assertResponseEqual(self, response: Any, expected: Any,
                           msg: Optional[str] = None) -> None:
        """Assert that response equals expected value.
        
        Args:
            response: Response from invoke
            expected: Expected value
            msg: Optional assertion message
        """
        try:
            from .assertions import assert_response_equal
            assert_response_equal(response, expected)
        except AssertionError as e:
            if msg:
                raise AssertionError(f"{msg}: {e}")
            else:
                raise
    
    def assertResponseContains(self, response: Any, expected: Any,
                              msg: Optional[str] = None) -> None:
        """Assert that response contains expected value.
        
        Args:
            response: Response from invoke
            expected: Value to search for
            msg: Optional assertion message
        """
        try:
            from .assertions import assert_response_contains
            assert_response_contains(response, expected)
        except AssertionError as e:
            if msg:
                raise AssertionError(f"{msg}: {e}")
            else:
                raise
    
    def assertUserExists(self, users: List[Dict[str, Any]], user_id: int,
                        expected_name: Optional[str] = None,
                        expected_email: Optional[str] = None,
                        msg: Optional[str] = None) -> None:
        """Assert that a user exists in a list of users.
        
        Args:
            users: List of user dictionaries
            user_id: ID of user to find
            expected_name: Optional expected name
            expected_email: Optional expected email
            msg: Optional assertion message
        """
        try:
            from .assertions import assert_user_exists
            assert_user_exists(users, user_id, expected_name, expected_email)
        except AssertionError as e:
            if msg:
                raise AssertionError(f"{msg}: {e}")
            else:
                raise
    
    def assertUserCount(self, users: List[Dict[str, Any]], expected_count: int,
                       msg: Optional[str] = None) -> None:
        """Assert that user count matches expected.
        
        Args:
            users: List of user dictionaries
            expected_count: Expected number of users
            msg: Optional assertion message
        """
        try:
            from .assertions import assert_user_count
            assert_user_count(users, expected_count)
        except AssertionError as e:
            if msg:
                raise AssertionError(f"{msg}: {e}")
            else:
                raise
    
    # Common test methods for CRUD operations
    def create_user(self, name: str, email: str) -> Dict[str, Any]:
        """Create a user and return the created user.
        
        Args:
            name: User name
            email: User email
            
        Returns:
            Created user dictionary
        """
        user_data = {'name': name, 'email': email}
        response = self.invoke('createUser', user_data)
        self.assertDubboSuccess(response)
        return response
    
    def get_user(self, user_id: int) -> Dict[str, Any]:
        """Get a user by ID.
        
        Args:
            user_id: User ID
            
        Returns:
            User dictionary or None if not found
        """
        response = self.invoke('getUserById', user_id)
        return response
    
    def get_all_users(self) -> List[Dict[str, Any]]:
        """Get all users.
        
        Returns:
            List of user dictionaries
        """
        response = self.invoke('getAllUsers')
        return response if response is not None else []
    
    def update_user(self, user_id: int, **kwargs) -> Dict[str, Any]:
        """Update a user.
        
        Args:
            user_id: User ID
            **kwargs: Fields to update (name, email)
            
        Returns:
            Updated user dictionary
        """
        user_data = {'id': user_id, **kwargs}
        response = self.invoke('updateUser', user_data)
        self.assertDubboSuccess(response)
        return response
    
    def delete_user(self, user_id: int) -> bool:
        """Delete a user by ID.
        
        Args:
            user_id: User ID
            
        Returns:
            True if deleted, False if not found
        """
        response = self.invoke('deleteUser', user_id)
        return response if isinstance(response, bool) else False
    
    def get_user_count(self) -> int:
        """Get user count.
        
        Returns:
            Number of users
        """
        response = self.invoke('getUserCount')
        return response if isinstance(response, int) else 0