"""
Assertion helpers for Dubbo testing.
"""

import json
from typing import Any, Dict, List, Optional, Union


def assert_dubbo_response(response: Any, expected_type: Optional[type] = None,
                         expected_value: Optional[Any] = None) -> None:
    """Assert that a Dubbo response is valid and optionally matches type/value.
    
    Args:
        response: The response from Dubbo invocation
        expected_type: Expected type of the response
        expected_value: Expected value of the response
        
    Raises:
        AssertionError: If assertion fails
    """
    if response is None:
        raise AssertionError("Response is None")
    
    if expected_type is not None:
        if not isinstance(response, expected_type):
            raise AssertionError(
                f"Response type mismatch: expected {expected_type}, "
                f"got {type(response)}"
            )
    
    if expected_value is not None:
        if response != expected_value:
            raise AssertionError(
                f"Response value mismatch: expected {expected_value}, "
                f"got {response}"
            )


def assert_dubbo_success(response: Any) -> None:
    """Assert that Dubbo invocation was successful.
    
    Checks that response is not an error message and not None.
    
    Args:
        response: The response from Dubbo invocation
        
    Raises:
        AssertionError: If response indicates failure
    """
    if response is None:
        raise AssertionError("Response is None")
    
    if isinstance(response, str):
        response_lower = response.lower()
        if 'error' in response_lower or 'exception' in response_lower:
            raise AssertionError(f"Response indicates error: {response}")
    
    if isinstance(response, dict):
        if 'error' in response or 'exception' in response:
            raise AssertionError(f"Response contains error: {response}")


def assert_dubbo_error(response: Any, expected_error: Optional[str] = None) -> None:
    """Assert that Dubbo invocation resulted in an error.
    
    Args:
        response: The response from Dubbo invocation
        expected_error: Optional substring to match in error message
        
    Raises:
        AssertionError: If response does not indicate error
    """
    if response is None:
        raise AssertionError("Response is None, expected error")
    
    has_error = False
    error_msg = ""
    
    if isinstance(response, str):
        response_lower = response.lower()
        if 'error' in response_lower or 'exception' in response_lower:
            has_error = True
            error_msg = response
    elif isinstance(response, dict):
        if 'error' in response or 'exception' in response:
            has_error = True
            error_msg = str(response)
    
    if not has_error:
        raise AssertionError(f"Expected error but got: {response}")
    
    if expected_error and expected_error not in error_msg:
        raise AssertionError(
            f"Expected error containing '{expected_error}' but got: {error_msg}"
        )


def assert_response_contains(response: Any, expected: Any) -> None:
    """Assert that response contains expected value.
    
    Args:
        response: The response from Dubbo invocation
        expected: Value to search for in response
        
    Raises:
        AssertionError: If response does not contain expected value
    """
    if isinstance(response, (dict, list)):
        response_str = json.dumps(response, ensure_ascii=False)
    else:
        response_str = str(response)
    
    if isinstance(expected, (dict, list)):
        expected_str = json.dumps(expected, ensure_ascii=False)
    else:
        expected_str = str(expected)
    
    if expected_str not in response_str:
        raise AssertionError(
            f"Response does not contain expected value: {expected}"
        )


def assert_response_equal(response: Any, expected: Any) -> None:
    """Assert that response equals expected value.
    
    Args:
        response: The response from Dubbo invocation
        expected: Expected value
        
    Raises:
        AssertionError: If response does not equal expected value
    """
    if response != expected:
        raise AssertionError(
            f"Response does not equal expected: got {response}, expected {expected}"
        )


def assert_user_exists(users: List[Dict[str, Any]], user_id: int, 
                      expected_name: Optional[str] = None,
                      expected_email: Optional[str] = None) -> None:
    """Assert that a user exists in a list of users.
    
    Args:
        users: List of user dictionaries
        user_id: ID of user to find
        expected_name: Optional expected name
        expected_email: Optional expected email
        
    Raises:
        AssertionError: If user not found or attributes don't match
    """
    user = None
    for u in users:
        if u.get('id') == user_id:
            user = u
            break
    
    if user is None:
        raise AssertionError(f"User with id {user_id} not found")
    
    if expected_name is not None and user.get('name') != expected_name:
        raise AssertionError(
            f"User name mismatch: expected {expected_name}, got {user.get('name')}"
        )
    
    if expected_email is not None and user.get('email') != expected_email:
        raise AssertionError(
            f"User email mismatch: expected {expected_email}, got {user.get('email')}"
        )


def assert_user_count(users: List[Dict[str, Any]], expected_count: int) -> None:
    """Assert that the number of users matches expected count.
    
    Args:
        users: List of user dictionaries
        expected_count: Expected number of users
        
    Raises:
        AssertionError: If count doesn't match
    """
    actual_count = len(users)
    if actual_count != expected_count:
        raise AssertionError(
            f"User count mismatch: expected {expected_count}, got {actual_count}"
        )