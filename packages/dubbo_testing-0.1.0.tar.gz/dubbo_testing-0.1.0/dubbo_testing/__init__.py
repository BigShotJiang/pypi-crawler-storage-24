"""
Dubbo Testing Library - A Python library for testing Dubbo3 interfaces.

This library provides utilities and test helpers for testing Dubbo services,
including Telnet-based client, assertions, and test case base classes.
"""

__version__ = '0.1.0'
__author__ = 'Dubbo Testing Contributors'

from .client import DubboClient, TelnetDubboClient
from .exceptions import DubboError, ConnectionError, InvocationError, TimeoutError
from .assertions import (
    assert_dubbo_response,
    assert_dubbo_success,
    assert_dubbo_error,
    assert_response_contains,
    assert_response_equal,
)
from .testcase import DubboTestCase
from .utils import json_to_dubbo_args, parse_response, to_json

__all__ = [
    'DubboClient',
    'TelnetDubboClient',
    'DubboError',
    'ConnectionError',
    'InvocationError',
    'TimeoutError',
    'assert_dubbo_response',
    'assert_dubbo_success',
    'assert_dubbo_error',
    'assert_response_contains',
    'assert_response_equal',
    'DubboTestCase',
    'json_to_dubbo_args',
    'parse_response',
    'to_json',
]