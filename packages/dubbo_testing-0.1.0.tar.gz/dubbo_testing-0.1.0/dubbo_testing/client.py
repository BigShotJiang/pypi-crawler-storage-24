"""
Dubbo client implementations for testing Dubbo3 services.
"""

import abc
import json
import sys
from typing import Any, Optional, Union, Dict, List

try:
    import telnetlib3 as telnet_module
    TELNET_LIB = 'telnetlib3'
except ImportError:
    try:
        import telnetlib as telnet_module
        TELNET_LIB = 'telnetlib'
    except ImportError:
        telnet_module = None
        TELNET_LIB = None

from .exceptions import ConnectionError, DubboError, InvocationError


class DubboClient(abc.ABC):
    """Abstract base class for Dubbo clients."""
    
    @abc.abstractmethod
    def connect(self) -> bool:
        """Establish connection to Dubbo service."""
        pass
    
    @abc.abstractmethod
    def invoke(self, service: str, method: str, *args) -> Any:
        """Invoke a Dubbo service method.
        
        Args:
            service: Service name (e.g., 'UserService')
            method: Method name (e.g., 'getUserById')
            *args: Arguments to pass to the method
            
        Returns:
            The result of the invocation, parsed as appropriate type.
        """
        pass
    
    @abc.abstractmethod
    def close(self) -> None:
        """Close the connection."""
        pass
    
    def __enter__(self):
        self.connect()
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()


class TelnetDubboClient(DubboClient):
    """Dubbo client using Telnet QoS interface."""
    
    def __init__(self, host: str = '127.0.0.1', port: int = 22222, 
                 timeout: int = 5, prompt: str = 'dubbo>'):
        """Initialize TelnetDubboClient.
        
        Args:
            host: Dubbo QoS host
            port: Dubbo QoS port (default 22222)
            timeout: Connection and read timeout in seconds
            prompt: Expected command prompt
        """
        self.host = host
        self.port = port
        self.timeout = timeout
        self.prompt = prompt
        self.tn: Any = None
        
    def connect(self) -> bool:
        """Connect to Dubbo QoS service."""
        if telnet_module is None:
            raise ImportError(
                "No telnet library available. "
                "Please install telnetlib3 (pip install telnetlib3) "
                "or ensure telnetlib is available in your Python installation."
            )
        try:
            self.tn = telnet_module.Telnet(self.host, self.port, timeout=self.timeout)
            response = self.tn.read_until(self.prompt.encode(), timeout=self.timeout)
            if self.prompt.encode() in response:
                return True
            else:
                raise ConnectionError(f"Connected but prompt '{self.prompt}' not found")
        except Exception as e:
            raise ConnectionError(f"Failed to connect to {self.host}:{self.port}: {e}")
    
    def execute_command(self, command: str, wait_response: bool = True) -> str:
        """Execute a raw command and return the response.
        
        Args:
            command: The command to execute
            wait_response: Whether to wait for and return the response
            
        Returns:
            The command response as string.
        """
        if not self.tn:
            raise RuntimeError("Not connected")
        
        self.tn.write(command.encode('utf-8') + b'\n')
        
        if not wait_response:
            return ""
        
        response = self.tn.read_until(self.prompt.encode(), timeout=self.timeout).decode('utf-8')
        
        lines = response.strip().split('\n')
        result_lines = []
        for line in lines:
            line = line.strip()
            if line and line != command and line != self.prompt:
                result_lines.append(line)
        
        return '\n'.join(result_lines)
    
    def invoke(self, service: str, method: str, *args) -> Any:
        """Invoke a Dubbo service method via Telnet.
        
        Args:
            service: Service name (e.g., 'UserService')
            method: Method name (e.g., 'getUserById')
            *args: Arguments to pass to the method
            
        Returns:
            Parsed response (JSON objects parsed to dict/list, numbers to int/float).
        """
        # Build argument string
        arg_strs = []
        for arg in args:
            if isinstance(arg, (dict, list)):
                arg_strs.append(json.dumps(arg, ensure_ascii=False))
            elif isinstance(arg, str):
                arg_strs.append(json.dumps(arg))
            elif arg is None:
                arg_strs.append('null')
            elif isinstance(arg, bool):
                arg_strs.append('true' if arg else 'false')
            else:
                arg_strs.append(str(arg))
        
        args_str = ','.join(arg_strs)
        command = f'invoke {service}.{method}({args_str})'
        
        response = self.execute_command(command)
        return self._parse_response(response)
    
    def _parse_response(self, response: str) -> Any:
        """Parse the response from Dubbo QoS.
        
        Attempts to parse JSON, then falls back to string.
        Raises InvocationError if response contains error.
        """
        response = response.strip()
        if not response:
            return response
        
        # Check for error indications
        response_lower = response.lower()
        if 'error' in response_lower or 'exception' in response_lower:
            raise InvocationError(f"Dubbo invocation error: {response}")
        
        # Try to parse as JSON
        try:
            return json.loads(response)
        except json.JSONDecodeError:
            pass
        
        # Try to parse as number
        try:
            if '.' in response:
                return float(response)
            else:
                return int(response)
        except ValueError:
            pass
        
        # Try boolean
        if response.lower() == 'true':
            return True
        if response.lower() == 'false':
            return False
        
        # Return as string
        return response
    
    def list_services(self) -> str:
        """List available services."""
        return self.execute_command('ls')
    
    def help(self, command: Optional[str] = None) -> str:
        """Get help information."""
        if command:
            return self.execute_command(f'help {command}')
        return self.execute_command('help')
    
    def service_status(self) -> str:
        """Get service status."""
        return self.execute_command('ps')
    
    def close(self) -> None:
        """Close the Telnet connection."""
        if self.tn:
            self.tn.close()
            self.tn = None