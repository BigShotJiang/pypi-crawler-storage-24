# Dubbo Testing Library / Dubbo 测试库

**English:** A Python library for testing Dubbo3 interfaces, providing utilities and test helpers for Dubbo services.

**中文:** 一个用于测试 Dubbo3 接口的 Python 库，为 Dubbo 服务提供实用工具和测试辅助功能。

## Features / 功能特性

**English:**
- **Telnet-based Dubbo client**: Connect to Dubbo QoS telnet interface and invoke services
- **Assertion helpers**: Common assertions for Dubbo responses
- **Test case base class**: `DubboTestCase` for writing unit tests
- **Utility functions**: JSON serialization, response parsing, and more
- **Easy to use**: Simple API for testing Dubbo CRUD operations

**中文:**
- **基于 Telnet 的 Dubbo 客户端**：连接 Dubbo QoS telnet 接口并调用服务
- **断言辅助函数**：用于 Dubbo 响应的常用断言
- **测试用例基类**：`DubboTestCase` 用于编写单元测试
- **实用函数**：JSON 序列化、响应解析等
- **易于使用**：用于测试 Dubbo CRUD 操作的简单 API

## Installation / 安装

**English:** from PyPI:

```bash
pip install dubbo-testing
```

**中文:** 从 PyPI：

```bash
pip install dubbo-testing
```

## Requirements / 要求

**English:**
- Python 3.7 or higher
- telnetlib3 (automatically installed as dependency)
- For Python 3.9 and below: telnetlib is available in standard library, but telnetlib3 is recommended
- For Python 3.13 and above: telnetlib3 is required as telnetlib was removed from standard library

**中文:**
- Python 3.7 或更高版本
- telnetlib3（自动安装为依赖项）
- 对于 Python 3.9 及以下版本：telnetlib 在标准库中可用，但建议使用 telnetlib3
- 对于 Python 3.13 及以上版本：telnetlib 已从标准库中移除，必须使用 telnetlib3

## Quick Start / 快速开始

### Using the TelnetDubboClient / 使用 TelnetDubboClient

**English:** Connect to Dubbo QoS and invoke services:
**中文:** 连接到 Dubbo QoS 并调用服务：

```python
from dubbo_testing import TelnetDubboClient

# Connect to Dubbo QoS / 连接到 Dubbo QoS
client = TelnetDubboClient(host='127.0.0.1', port=22222)
client.connect()

# List services / 列出服务
services = client.list_services()
print(f"Services: {services}")

# Invoke a method / 调用方法
count = client.invoke('UserService', 'getUserCount')
print(f"User count: {count}")

# Create a user / 创建用户
user_data = {'name': 'John Doe', 'email': 'john@example.com'}
created = client.invoke('UserService', 'createUser', user_data)
print(f"Created user: {created}")

client.close()
```

### Using DubboTestCase / 使用 DubboTestCase

**English:** Write unit tests with `DubboTestCase`:
**中文:** 使用 `DubboTestCase` 编写单元测试：

```python
from dubbo_testing import DubboTestCase

class TestUserService(DubboTestCase):
    SERVICE_NAME = 'UserService'
    
    def test_user_crud(self):
        # Create user / 创建用户
        user = self.create_user('Test User', 'test@example.com')
        assert user.get('id') is not None
        
        # Get user / 获取用户
        fetched = self.get_user(user['id'])
        self.assertResponseEqual(fetched['name'], 'Test User')
        
        # Update user / 更新用户
        updated = self.update_user(user['id'], name='Updated Name')
        self.assertResponseEqual(updated['name'], 'Updated Name')
        
        # Get all users / 获取所有用户
        users = self.get_all_users()
        self.assertUserExists(users, user['id'])
        
        # Delete user / 删除用户
        deleted = self.delete_user(user['id'])
        assert deleted
        
        # Verify count / 验证计数
        count = self.get_user_count()
        assert count == 0
```

## API Reference / API 参考

### DubboClient

**English:** Abstract base class for Dubbo clients.

**中文:** Dubbo 客户端的抽象基类。

#### Methods / 方法

**English:**
- `connect()`: Establish connection
- `invoke(service, method, *args)`: Invoke a service method
- `close()`: Close connection

**中文:**
- `connect()`：建立连接
- `invoke(service, method, *args)`：调用服务方法
- `close()`：关闭连接

### TelnetDubboClient

**English:** Dubbo client using Telnet QoS interface.

**中文:** 使用 Telnet QoS 接口的 Dubbo 客户端。

#### Additional Methods / 额外方法

**English:**
- `execute_command(command, wait_response=True)`: Execute raw command
- `list_services()`: List available services
- `help(command=None)`: Get help
- `service_status()`: Get service status

**中文:**
- `execute_command(command, wait_response=True)`：执行原始命令
- `list_services()`：列出可用服务
- `help(command=None)`：获取帮助
- `service_status()`：获取服务状态

### Assertions / 断言

**English:**
- `assert_dubbo_response(response, expected_type=None, expected_value=None)`
- `assert_dubbo_success(response)`
- `assert_dubbo_error(response, expected_error=None)`
- `assert_response_contains(response, expected)`
- `assert_response_equal(response, expected)`
- `assert_user_exists(users, user_id, expected_name=None, expected_email=None)`
- `assert_user_count(users, expected_count)`

**中文:**
- `assert_dubbo_response(response, expected_type=None, expected_value=None)`
- `assert_dubbo_success(response)`
- `assert_dubbo_error(response, expected_error=None)`
- `assert_response_contains(response, expected)`
- `assert_response_equal(response, expected)`
- `assert_user_exists(users, user_id, expected_name=None, expected_email=None)`
- `assert_user_count(users, expected_count)`

### DubboTestCase

**English:** Base test case with convenience methods.

**中文:** 具有便捷方法的测试用例基类。

#### Configuration / 配置

**English:** Override these class variables:
- `DUBBO_HOST`: Dubbo QoS host (default: '127.0.0.1')
- `DUBBO_PORT`: Dubbo QoS port (default: 22222)
- `DUBBO_TIMEOUT`: Timeout in seconds (default: 5)
- `SERVICE_NAME`: Service name (default: 'UserService')

**中文:** 覆盖以下类变量：
- `DUBBO_HOST`：Dubbo QoS 主机（默认：'127.0.0.1'）
- `DUBBO_PORT`：Dubbo QoS 端口（默认：22222）
- `DUBBO_TIMEOUT`：超时时间（秒）（默认：5）
- `SERVICE_NAME`：服务名称（默认：'UserService'）

#### Convenience Methods / 便捷方法

**English:**
- `invoke(method, *args)`: Invoke service method
- `create_user(name, email)`: Create user
- `get_user(user_id)`: Get user by ID
- `get_all_users()`: Get all users
- `update_user(user_id, **kwargs)`: Update user
- `delete_user(user_id)`: Delete user
- `get_user_count()`: Get user count

**中文:**
- `invoke(method, *args)`：调用服务方法
- `create_user(name, email)`：创建用户
- `get_user(user_id)`：根据 ID 获取用户
- `get_all_users()`：获取所有用户
- `update_user(user_id, **kwargs)`：更新用户
- `delete_user(user_id)`：删除用户
- `get_user_count()`：获取用户计数

## Examples / 示例

**English:** See `examples/` directory for complete examples:
- `basic_usage.py`: Basic client usage
- `test_user_service.py`: Complete test suite

**中文:** 查看 `examples/` 目录获取完整示例：
- `basic_usage.py`：基本客户端用法
- `test_user_service.py`：完整的测试套件

## License / 许可证

MIT License / MIT 许可证