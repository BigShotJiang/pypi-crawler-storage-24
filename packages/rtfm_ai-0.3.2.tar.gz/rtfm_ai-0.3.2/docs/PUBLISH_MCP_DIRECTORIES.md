# Publier RTFM sur les annuaires MCP

Instructions complètes pour enregistrer `roomi-fields/rtfm` sur tous les annuaires MCP pertinents.

## Informations du serveur

- **Nom** : RTFM
- **Titre long** : RTFM — Retrieve The Forgotten Memory
- **Repo GitHub** : https://github.com/roomi-fields/rtfm
- **PyPI** : https://pypi.org/project/rtfm-ai/
- **Commande d'install** : `pip install rtfm-ai[mcp]`
- **Licence** : MIT
- **Langage** : Python 3.10+
- **Version actuelle** : 0.3.1
- **Transport** : stdio
- **PYPI_TOKEN** : Configuré dans les secrets GitHub du repo (`gh secret set PYPI_TOKEN`)
- **`pyproject.toml`** : Contient `[tool.mcp] name = "io.github.roomi-fields/rtfm"` (requis pour le registre officiel)

### Description courte (< 100 caractères)

```
The open retrieval layer for AI agents — index code, docs, data. Search via MCP.
```

### Description longue

```
The open retrieval layer for AI agents. Index your entire project — code, docs, legal, research, data — and serve surgical context via MCP. FTS5 full-text search, optional semantic search (FastEmbed/ONNX), 10 built-in parsers (Markdown, Python AST, LaTeX, YAML, JSON, PDF, XML, HTML...), incremental sync, auto-sync hooks. Works with Claude Code, Cursor, Codex, any MCP client.
```

---

## Tier 1 — Haute priorité

### 1. awesome-mcp-servers (79.6k stars)

**Process** : PR sur GitHub + lien Glama obligatoire

1. Le serveur DOIT d'abord être listé sur Glama.ai (voir ci-dessous)
2. Fork `punkpeye/awesome-mcp-servers`
3. Ajouter dans la section **"Knowledge & Memory"** du README.md, par ordre alphabétique :
```markdown
- [roomi-fields/rtfm](https://github.com/roomi-fields/rtfm) ([glama](https://glama.ai/mcp/servers/@roomi-fields/rtfm)) 🐍 🏠 🍎 🪟 🐧 - The open retrieval layer for AI agents. Index code, docs, legal, research, data. FTS5 + semantic search. 10 built-in parsers. Incremental auto-sync. MCP + CLI + Python API.
```
4. Créer la PR vers `punkpeye/awesome-mcp-servers:main`

**Badges** : 🐍 (Python) 🏠 (self-hosted) 🍎 (macOS) 🪟 (Windows) 🐧 (Linux)

### 2. Glama.ai (prérequis pour awesome-mcp-servers)

**Process** : Auto-indexé depuis GitHub. Soumettre sur https://glama.ai/mcp/servers si pas déjà listé.

Vérifier : https://glama.ai/mcp/servers/@roomi-fields/rtfm

### 3. mcp.so

**Process** : Commenter sur l'issue #1 du repo `chatmcp/mcpso`

```bash
gh issue comment 1 --repo chatmcp/mcpso --body "$(cat <<'EOF'
## RTFM — Retrieve The Forgotten Memory

**Repository:** https://github.com/roomi-fields/rtfm
**PyPI:** https://pypi.org/project/rtfm-ai/
**License:** MIT
**Language:** Python

The open retrieval layer for AI agents. Index your entire project — code, docs, legal, research, data — and serve surgical context via MCP.

- **FTS5 full-text search** + optional semantic search (FastEmbed/ONNX, no GPU)
- **10 built-in parsers** — Markdown, Python (AST), LaTeX, YAML, JSON, PDF, XML, HTML, Shell, plain text
- **Incremental sync** with auto-sync hooks (keeps index fresh every prompt)
- **Progressive disclosure** — returns file paths + scores (~300 tokens), agent reads only what it needs
- **MCP server** + CLI + Python API

Works with Claude Code, Cursor, Codex, any MCP client.
EOF
)"
```

### 4. Cline Marketplace

**Process** : Créer une issue sur `cline/mcp-marketplace`

```bash
gh issue create --repo cline/mcp-marketplace --title "[Server Submission]: rtfm — The open retrieval layer for AI agents" --body "$(cat <<'EOF'
### GitHub Repository URL

https://github.com/roomi-fields/rtfm

### Logo Image

No logo available yet — can provide on request.

### Installation Testing

- [x] I have tested installing this server
- [x] The server runs correctly after installation

### Additional Information

**PyPI:** [rtfm-ai](https://pypi.org/project/rtfm-ai/)
**Install:** `pip install rtfm-ai[mcp]`
**License:** MIT
**Language:** Python 3.10+

The open retrieval layer for AI agents. Index your entire project — code, docs, legal, research, data — and serve surgical context via MCP.

**Key features:**
- FTS5 full-text search + optional semantic search (FastEmbed/ONNX)
- 10 built-in parsers (Markdown, Python AST, LaTeX, YAML, JSON, PDF, XML, HTML, Shell, text)
- Incremental auto-sync — index stays fresh every prompt
- Progressive disclosure — metadata-first search (~300 tokens), agent reads only what it needs
- MCP server + CLI + Python API

**Quick start:**
```bash
pip install rtfm-ai[mcp]
cd your-project
rtfm init
```
EOF
)"
```

### 5. Cursor Directory

**Process** : Formulaire web sur https://cursor.directory/mcp/new (connexion GitHub requise)

- **Name** : RTFM
- **Description** : The open retrieval layer for AI agents. Index code, docs, legal, research, data. FTS5 full-text search, semantic search, 10 built-in parsers, incremental auto-sync. MCP server plus CLI plus Python API.
- **Link to install instructions** : https://github.com/roomi-fields/rtfm#quick-start
- **Plan** : Standard Free

### 6. Official MCP Registry

**Process** : CLI `mcp-publisher`

#### Étape A : Créer `server.json` dans le repo RTFM

```json
{
  "$schema": "https://static.modelcontextprotocol.io/schemas/2025-12-11/server.schema.json",
  "name": "io.github.roomi-fields/rtfm",
  "title": "RTFM",
  "description": "The open retrieval layer for AI agents — index code, docs, data. Search via MCP.",
  "repository": {
    "url": "https://github.com/roomi-fields/rtfm",
    "source": "github"
  },
  "version": "0.3.1",
  "packages": [
    {
      "registryType": "pypi",
      "identifier": "rtfm-ai",
      "version": "0.3.1",
      "transport": {
        "type": "stdio"
      }
    }
  ]
}
```

#### Étape B : Ajouter `mcpName` dans `pyproject.toml`

Ajouter dans la section `[project]` :
```toml
[project]
# ... existing fields ...

[tool.mcp]
name = "io.github.roomi-fields/rtfm"
```

> **Note** : Vérifier si le registre MCP officiel supporte `pyproject.toml` pour le champ `mcpName`. Si non, il faudra peut-être publier une nouvelle version sur PyPI avec ce champ, ou utiliser un autre mécanisme de vérification.

#### Étape C : Publier

```bash
# Copier le binaire depuis le projet NBLM ou re-télécharger
cp /mnt/d/Claude/notebooklm-mcp-http/mcp-publisher /mnt/d/Claude/RTFM/

# Login (si pas déjà fait dans cette session — le token est partagé)
cd /mnt/d/Claude/RTFM
./mcp-publisher login github

# Publier
./mcp-publisher publish

# Vérifier
curl "https://registry.modelcontextprotocol.io/v0.1/servers?search=io.github.roomi-fields/rtfm"
```

---

## Tier 2 — Priorité moyenne

### 7. FindMCP.dev
- **URL** : https://findmcp.dev
- **Process** : Formulaire web (~2 min)

### 8. wong2/awesome-mcp-servers (3.6k stars)
- **Process** : PR GitHub, même format que punkpeye mais sans obligation Glama

### 9. appcypher/awesome-mcp-servers (5k stars)
- **Process** : PR GitHub

### 10. MCPIndex.net
- **URL** : https://mcpindex.net/en/contact
- **Process** : Formulaire de contact

### 11. MCPList.ai
- **URL** : https://www.mcplist.ai
- **Process** : Formulaire web

---

## Tier 3 — Priorité basse (formulaires web simples)

| Annuaire | URL de soumission |
|---|---|
| MCPServerFinder.com | Web form |
| MCPServer.dev | Web form |
| MCPServe.com | mcpserve.com/submit |
| MCP-Server-Directory.com | mcp-server-directory.com/submit |
| MCPServers.com | Web form |
| MCPDir.dev | Web form |
| MCPServerHub.net | Web form |
| MCPServerHub.com | Web form |
| MCP-Servers-Hub.net | mcp-servers-hub.net/submit |
| AIAgentsList.com | aiagentslist.com/mcp-servers |
| APITracker.io | apitracker.io/mcp-servers |
| ClaudeMCP.org | Web form |
| ClaudeMCP.com | Web form |
| UBOS.tech | GitHub PR |
| TensorBlock/awesome-mcp-servers | GitHub PR |

---

## Annuaires auto-indexés (rien à faire)

Ces annuaires scrapent automatiquement GitHub/PyPI :
- **mcpservers.org** — vérifie sur mcpservers.org/servers/roomi-fields/rtfm
- **PulseMCP** — vérifie sur pulsemcp.com
- **LobeHub** — vérifie sur lobehub.com/mcp
- **MCPMarket.com** — vérifie sur mcpmarket.com

---

## Annuaires à éviter

| Annuaire | Raison |
|---|---|
| **Smithery.ai** | Requiert un serveur HTTP déployé en ligne. RTFM est un outil local stdio. |
| **Docker MCP Catalog** | Requiert une image Docker. Pas pertinent pour un package pip. |

---

## Ordre d'exécution recommandé

1. Vérifier/soumettre sur **Glama.ai** (prérequis pour awesome-mcp-servers)
2. **mcp.so** (commande `gh` prête à copier-coller)
3. **Cline Marketplace** (commande `gh` prête à copier-coller)
4. **awesome-mcp-servers** PR (après confirmation Glama)
5. **Cursor Directory** (formulaire web)
6. **Official MCP Registry** (créer server.json + publish)
7. Tier 2 et 3 au fil du temps

## Notes importantes

- **Ne PAS héberger Smithery** — RTFM est un outil local, pas un SaaS
- **Glama est obligatoire** avant de soumettre sur awesome-mcp-servers
- Le `mcp-publisher` CLI est déjà installé dans `/mnt/d/Claude/notebooklm-mcp-http/mcp-publisher` — le copier
- Le login GitHub pour le registre officiel est peut-être encore actif (session partagée)
- Les commandes `gh` sont prêtes à copier-coller ci-dessus
