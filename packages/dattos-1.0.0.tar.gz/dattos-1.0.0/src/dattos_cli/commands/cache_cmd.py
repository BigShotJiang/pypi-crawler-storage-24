"""Cache management commands."""
from __future__ import annotations

import typer

from dattos_cli.output import print_json


app = typer.Typer(help="Manage local cache.", no_args_is_help=True)


@app.command("clear")
def cache_clear():
    """Clear all cached API responses for the active profile."""
    from dattos_sdk.config import CONFIG_DIR, get_active_profile
    from dattos_sdk.cache import FileCache

    cache_dir = CONFIG_DIR / "cache" / get_active_profile()
    if cache_dir.exists():
        cache = FileCache(cache_dir)
        cache.clear()
    print_json({"status": "cleared", "profile": get_active_profile()})
