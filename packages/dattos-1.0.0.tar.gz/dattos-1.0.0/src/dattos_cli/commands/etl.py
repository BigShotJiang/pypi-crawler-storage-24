# src/dattos_cli/commands/etl.py
from __future__ import annotations

from typing import Optional

import typer

from dattos_cli.client import ApiError
from dattos_cli.main import get_client, handle_api_error
from dattos_cli.output import print_json

app = typer.Typer(help="ETL flow operations.", no_args_is_help=True)


@app.command("get-by-analysis")
def get_by_analysis(
    analysis_id: int = typer.Argument(help="Analysis ID"),
    folder_id: Optional[str] = typer.Option(None, "--folder-id", help="Folder ID to scope the query"),
):
    """Get the ETL flow associated with an analysis."""
    client = get_client(folder_id)
    try:
        result = client.get(f"/api/Etl/ByAnalysis/{analysis_id}")
        print_json(result)
    except ApiError as e:
        handle_api_error(e)


@app.command("get")
def etl_get(
    etl_id: int = typer.Argument(help="ETL flow ID"),
    folder_id: Optional[str] = typer.Option(None, "--folder-id", help="Folder ID to scope the query"),
):
    """Get an ETL flow by ID."""
    client = get_client(folder_id)
    try:
        result = client.get(f"/api/Etl/{etl_id}")
        print_json(result)
    except ApiError as e:
        handle_api_error(e)
