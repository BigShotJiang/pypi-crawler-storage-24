# src/dattos_cli/commands/auth_cmd.py
from __future__ import annotations

import httpx
import typer

from dattos_cli.config import get_active_profile, _load_profile_config
from dattos_cli.credentials import delete_secret, get_secret, store_secret
from dattos_cli.output import print_error, print_json

app = typer.Typer(help="Authentication management.", no_args_is_help=True)


def _make_http_client() -> httpx.Client:
    return httpx.Client(timeout=15, follow_redirects=False)


@app.command("login")
def login():
    """Log in with username and password. Stores a session token."""
    profile = get_active_profile()
    cfg = _load_profile_config()
    api_url = cfg.get("api_url", "")

    if not api_url:
        print_error("config_error", "api_url not configured. Run: dattos config set api-url <url>", 2)
        raise typer.Exit(2)

    email = typer.prompt("Email or user code")
    password = typer.prompt("Password", hide_input=True)

    http = _make_http_client()
    try:
        resp = http.post(
            f"{api_url}/api/Authentication/Login",
            json={"userCodeOrEmail": email, "password": password},
            headers={"accept": "application/json"},
        )
    except (httpx.ConnectError, httpx.TimeoutException) as e:
        print_error("connection_error", str(e), 1)
        raise typer.Exit(1)

    if resp.status_code in (400, 401):
        print_error("auth_error", "Invalid credentials.", 1)
        raise typer.Exit(1)
    if resp.status_code >= 400:
        print_error("api_error", f"HTTP {resp.status_code}", 1)
        raise typer.Exit(1)

    data = resp.json()
    token = data.get("AuthToken") or data.get("authToken")
    name = data.get("FullName") or data.get("fullName") or ""

    if not token:
        print_error("auth_error", "No token in response.", 1)
        raise typer.Exit(1)

    store_secret(profile, "session_token", token)
    typer.echo()
    typer.echo(f"  Logged in as {name}" if name else "  Logged in")
    typer.echo(f"  Profile: {profile}")
    typer.echo()


@app.command("logout")
def logout():
    """Log out and remove the stored session token."""
    profile = get_active_profile()
    cfg = _load_profile_config()
    api_url = cfg.get("api_url", "")
    token = get_secret(profile, "session_token")

    if token and api_url:
        http = _make_http_client()
        try:
            http.post(
                f"{api_url}/api/Authentication/Logout",
                headers={"Authorization": f"Bearer {token}", "accept": "application/json"},
            )
        except (httpx.ConnectError, httpx.TimeoutException):
            pass  # Best-effort logout

    delete_secret(profile, "session_token")
    print_json({"status": "logged_out", "profile": profile})


@app.command("status")
def auth_status():
    """Show current authentication method and status."""
    profile = get_active_profile()
    cfg = _load_profile_config()

    session = get_secret(profile, "session_token")
    api_key = get_secret(profile, "api_key") or cfg.get("api_key", "")

    if session:
        print_json({"method": "session", "profile": profile, "token": session[:8] + "***"})
    elif api_key:
        masked = api_key[:4] + "***" if len(api_key) > 4 else "***"
        print_json({"method": "api-key", "profile": profile, "key": masked})
    else:
        print_json({"method": "none", "profile": profile})
