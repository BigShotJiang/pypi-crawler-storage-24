"""Re-export shim — real implementation lives in dattos_sdk."""
from dattos_sdk.client import DattosClient
from dattos_sdk.exceptions import ApiError

__all__ = ["DattosClient", "ApiError"]
