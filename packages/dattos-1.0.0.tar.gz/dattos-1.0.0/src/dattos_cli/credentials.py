"""Re-export shim — real implementation lives in dattos_sdk."""
from dattos_sdk.credentials import (  # noqa: F401
    delete_secret,
    get_secret,
    store_secret,
    _keyring_available,
    _keyring_delete,
    _keyring_get,
    _keyring_set,
    _service_name,
)

__all__ = [
    "delete_secret",
    "get_secret",
    "store_secret",
    "_keyring_available",
    "_keyring_delete",
    "_keyring_get",
    "_keyring_set",
    "_service_name",
]
