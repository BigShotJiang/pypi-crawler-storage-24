# src/dattos_cli/banner.py
from __future__ import annotations

import typer

from dattos_cli import __version__

BANNER_LINES = [
    " ██████╗   █████╗  ████████╗████████╗  ██████╗  ███████╗",
    " ██╔══██╗ ██╔══██╗ ╚══██╔══╝╚══██╔══╝ ██╔═══██╗ ██╔════╝",
    " ██║  ██║ ███████║    ██║ ═════██║     ██║   ██║ ███████╗",
    " ██║  ██║ ██╔══██║    ██║      ██║     ██║   ██║ ╚════██║",
    " ██████╔╝ ██║  ██║    ██║      ██║     ╚██████╔╝ ███████║",
    " ╚═════╝  ╚═╝  ╚═╝    ╚═╝      ╚═╝      ╚═════╝  ╚══════╝",
]


def print_banner() -> None:
    """Print the Dattos ASCII art banner with version info."""
    typer.echo()
    for line in BANNER_LINES:
        typer.echo(line)
    typer.echo()
    typer.echo(f"  v{__version__} — CLI for the Dattos platform")
    typer.echo()
