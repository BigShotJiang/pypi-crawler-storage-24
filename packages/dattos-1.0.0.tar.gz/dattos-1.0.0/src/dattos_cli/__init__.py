"""Dattos CLI — agent-native interface for the Dattos platform."""

__version__ = "1.0.0"
