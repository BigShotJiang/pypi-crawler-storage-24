"""Dattos SDK — reusable client library for the Dattos platform."""
from dattos_sdk.cache import FileCache
from dattos_sdk.client import DattosClient
from dattos_sdk.config import DattosConfig, get_config
from dattos_sdk.exceptions import ApiError

__version__ = "1.0.0"
__all__ = ["DattosClient", "ApiError", "get_config", "DattosConfig", "FileCache", "__version__"]
