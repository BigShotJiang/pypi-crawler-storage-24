from __future__ import annotations


class ApiError(Exception):
    """Raised when the Dattos API returns an error."""

    def __init__(self, status_code: int, detail: str, url: str = ""):
        self.status_code = status_code
        self.detail = detail
        self.url = url
        super().__init__(f"HTTP {status_code}: {detail}")
