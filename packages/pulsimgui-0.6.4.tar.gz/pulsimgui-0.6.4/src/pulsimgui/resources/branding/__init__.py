"""Branding resources for PulsimGui."""

