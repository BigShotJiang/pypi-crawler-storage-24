import sys

from aiohttp.client_exceptions import ClientConnectorError
from gql.transport.exceptions import TransportServerError
from loguru import logger
from tenacity import retry, retry_if_exception_type, stop_after_delay, wait_exponential

from ..graphql.sdk import create_session

MAX_RETRY_TIME = 60 * 15  # 15 minutes


def connection_retry_handler(retry_state):
    logger.error(
        f"Cannot connect to API. Waiting {retry_state.next_action.sleep:.1f} seconds "
        f"after {retry_state.attempt_number} tries."
    )


def create_new_session(primitive):
    token = primitive.host_config.get("token")
    transport_protocol = primitive.host_config.get("transport")
    fingerprint = primitive.host_config.get("fingerprint")

    if not token or not transport_protocol:
        logger.error(
            "CLI is not configured. Run `primitive config` to add an auth token."
        )
        sys.exit(1)

    return create_session(
        host=primitive.host,
        token=token,
        transport_protocol=transport_protocol,
        fingerprint=fingerprint,
    )


def guard(func):
    @retry(
        retry=retry_if_exception_type(
            (
                ConnectionRefusedError,
                ClientConnectorError,
                TransportServerError,
            )
        ),
        wait=wait_exponential(multiplier=1, max=60),
        stop=stop_after_delay(MAX_RETRY_TIME),
        before_sleep=connection_retry_handler,
        reraise=True,
    )
    def wrapper(self, *args, **kwargs):
        if self.primitive.session is None:
            self.primitive.session = create_new_session(self.primitive)

        return func(self, *args, **kwargs)

    return wrapper
