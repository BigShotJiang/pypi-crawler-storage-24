---
name: feature
description: Orchestrate cross-repo feature development using Agent Teams. Analyzes a parent Linear ticket, determines affected repos, creates sub-tickets, spawns teammates per repo, and coordinates from planning through PRs.
argument-hint: [parent-ticket-id or ticket-url]
allowed-tools: Read, Bash, Glob, Grep, AskUserQuestion, Skill, mcp__linear-server__get_issue, mcp__linear-server__get_user, mcp__linear-server__update_issue, mcp__linear-server__create_issue, mcp__linear-server__search_issues
---

# Feature — Cross-Repo Orchestration

Orchestrates cross-repo feature development using Agent Teams. Analyzes a parent Linear ticket, determines affected repos, creates sub-tickets, spawns teammates per repo, and coordinates from planning through PRs.

**The lead (you) never writes code — only analyzes, coordinates, and reviews.**

## Usage

```
/feature <parent-ticket-id>
/feature ENG-500
/feature https://linear.app/primitive/issue/ENG-500
```

---

## Phase 1: Preflight

### 1.1 Verify Agent Teams

Check that Agent Teams is enabled in Claude Code settings. Look for `"CLAUDE_CODE_EXPERIMENTAL_AGENT_TEAMS"` set to `true` or `"1"` in the `env` object of either:
1. `.claude/settings.json` in the current project directory
2. `~/.claude/settings.json` (global user settings)

```bash
cat .claude/settings.json 2>/dev/null; cat ~/.claude/settings.json 2>/dev/null
```

If neither file contains `"CLAUDE_CODE_EXPERIMENTAL_AGENT_TEAMS"` enabled in `env`, stop with:
```
Agent Teams is required for /feature.

Enable it by adding to .claude/settings.json or ~/.claude/settings.json:
  {
    "env": {
      "CLAUDE_CODE_EXPERIMENTAL_AGENT_TEAMS": "1"
    }
  }

Then re-run /feature <ticket-id>.
```

### 1.2 Discover Sibling Repos

Check the parent directory for sibling repos:
```bash
ls -d ../backend ../frontend ../primitive-cli 2>/dev/null
```

Record which repos exist on disk. These are the repos that can participate in the feature.

---

## Phase 2: Fetch & Analyze

### 2.1 Fetch Parent Ticket

Use `/fetch-ticket` (invoke via Skill tool) to get the parent ticket from Linear.

### 2.2 Auto-Detect Affected Repos

Analyze the ticket title and description for keywords:

| Keywords | Repo |
|----------|------|
| API, endpoint, model, migration, query, mutation, schema, resolver, Django, GraphQL | backend |
| page, component, route, UI, layout, design, Next.js, React, TypeScript | frontend |
| command, flag, CLI, output, Click, Rich, terminal | primitive-cli |
| full-stack, end-to-end, cross-repo | backend + frontend |

### 2.3 Confirm or Ask

If detection is confident (2+ keyword matches for a repo), proceed.

If ambiguous (0-1 matches, or conflicting signals), ask the user via `AskUserQuestion`:
```
I detected the following repos may be affected:
- backend: <yes/maybe/no> (keywords: ...)
- frontend: <yes/maybe/no> (keywords: ...)
- primitive-cli: <yes/maybe/no> (keywords: ...)

Which repos should be included?
```

### 2.4 Single-Repo Optimization

If only 1 repo is affected, delegate directly to `/plan-work` in that repo and skip the Agent Teams workflow entirely.

---

## Phase 3: Sub-Tickets

### 3.1 Search for Existing Sub-Tickets

```
mcp__linear-server__search_issues
```

Search for issues linked to the parent ticket. Check if sub-tickets already exist for each affected repo.

### 3.2 Create Missing Sub-Tickets

For each affected repo without a sub-ticket, create one:
- Title: `[<repo>] <Parent ticket title>`
- Set parent link to the parent ticket
- Example: `[backend] Add global projects support`

### 3.3 Determine Dependency Order

- **Backend first** — it defines the API contract
- **Frontend + CLI in parallel** — they consume the API

### 3.4 Display Summary

```
Sub-tickets:
- [backend] ENG-501: Add global projects API
- [frontend] ENG-502: Add global projects UI
- [primitive-cli] ENG-503: Add global projects CLI command

Execution order:
1. backend (defines API contract)
2. frontend + primitive-cli (in parallel, consume API)
```

---

## Phase 4: Spawn Teammates

Spawn one teammate per affected repo. Each teammate works in its repo's directory.

### Teammate Prompt Template

Each teammate receives:

```
You are working on sub-ticket <SUB-TICKET-ID>: <TITLE>

Parent ticket: <PARENT-TICKET-ID>: <PARENT-TITLE>
Scope: <REPO> only

Your working directory is: <REPO-PATH>

Instructions:
1. Run /fetch-ticket <SUB-TICKET-ID>
2. Run /setup-worktree <SUB-TICKET-ID>
3. Run /create-plan <SUB-TICKET-ID>
4. Share your plan with the lead and WAIT for approval before proceeding

<IF BACKEND>
Additionally: After planning, share any GraphQL schema changes, new endpoints,
or API contract details so consumer repos can plan against them.
</IF BACKEND>

Do NOT proceed to implementation until the lead approves your plan.
```

### Require Plan Approval

All teammates must share their plans with the lead before implementation. The lead reviews each plan before giving approval.

---

## Phase 5: Coordinate Planning

### 5.1 Backend Plans First

If backend is involved, wait for the backend teammate to complete planning first.

### 5.2 Extract API Contract

From the backend plan, extract:
- New/modified GraphQL types and queries/mutations
- New REST endpoints (if any)
- Schema changes (new models, fields)
- Authentication/permission changes

### 5.3 Relay to Consumer Teammates

Send the API contract to frontend and CLI teammates so they can plan against the actual API surface.

### 5.4 Review All Plans

Review each teammate's plan for:
- Alignment with the parent ticket scope
- Consistency across repos (types match, field names align)
- No conflicting assumptions

### 5.5 Resolve Mismatches

If there's an API contract mismatch:
- **Backend is authoritative** — consumers must adapt
- Relay corrections to affected teammates
- Allow up to 3 revision rounds before escalating to the user

---

## Phase 6: Coordinate Implementation

### 6.1 Backend First

Approve backend teammate to proceed:
```
Proceed with implementation:
1. /implement <SUB-TICKET-ID>
2. /verify
3. /self-review
4. /submit-pr <SUB-TICKET-ID>
```

Wait for backend PR to be created.

### 6.2 Consumers in Parallel

After the backend PR is created, approve consumer teammates to proceed in parallel with the same skill chain.

### 6.3 Handle Failures

- Teammate failures don't block other repos
- Report failures to the user immediately
- Suggest manual intervention for the failed repo

---

## Phase 7: Synthesize

### 7.1 Update Parent Ticket

Update the parent Linear ticket with all PR links:
```
mcp__linear-server__update_issue
```

Add a comment with:
```
PRs created:
- backend: <PR-URL>
- frontend: <PR-URL>
- primitive-cli: <PR-URL>
```

### 7.2 Cross-Reference PRs

Add sibling PR links to each PR body (edit via `gh pr edit`):
```bash
gh pr edit <pr-number> --repo <org>/<repo> --add-body "Related PRs: ..."
```

### 7.3 Final Summary

```
Feature Complete!

Parent: <PARENT-TICKET-ID> - <TITLE>

PRs:
- backend: PR #<n> <url> - <status>
- frontend: PR #<n> <url> - <status>
- primitive-cli: PR #<n> <url> - <status>

Merge order:
1. backend PR first (defines API)
2. frontend + primitive-cli (after backend merges)

All PRs are ready for human review.
```

---

## Error Handling

- **Agent Teams not enabled**: Stop with clear setup instructions (Phase 1)
- **Single-repo feature**: Graceful degradation to `/plan-work` (Phase 2.4)
- **Missing repo on disk**: Warn, continue with available repos
- **Teammate failure**: Don't block others, report to user
- **Plan rejection**: Up to 3 revision rounds before escalating to user
- **Linear API errors**: Report and continue with available data
