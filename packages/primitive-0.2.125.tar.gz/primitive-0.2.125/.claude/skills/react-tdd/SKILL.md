---
name: react-tdd
description: Test-driven development for React with Vitest, React Testing Library, and Playwright
allowed-tools: Read, Edit, Write, Grep, Glob, Bash
---

# React TDD

TDD patterns for React + Next.js using Vitest, React Testing Library, and Playwright.

## Usage

```
/react-tdd [topic]
```

Topics: components, hooks, mutations, e2e, factories, fixtures

## Configuration

### vitest.config.ts

```ts
import { defineConfig } from "vitest/config"
import react from "@vitejs/plugin-react"
import path from "path"

export default defineConfig({
  plugins: [react()],
  test: {
    environment: "jsdom",
    setupFiles: ["./test/setup.ts"],
    globals: true,
    css: false,
    coverage: {
      provider: "v8",
      thresholds: { lines: 80, branches: 80 },
    },
  },
  resolve: {
    alias: { "@": path.resolve(__dirname, "./src") },
  },
})
```

### test/setup.ts

```ts
import "@testing-library/jest-dom/vitest"
import { cleanup } from "@testing-library/react"
import { afterEach } from "vitest"
import { server } from "./mocks/server"

beforeAll(() => server.listen({ onUnhandledRequest: "error" }))
afterEach(() => {
  cleanup()
  server.resetHandlers()
})
afterAll(() => server.close())
```

## TDD Cycle

### 1. RED — Write Failing Test

```tsx
import { render, screen } from "@testing-library/react"
import userEvent from "@testing-library/user-event"
import { ProjectCard } from "./project-card"

test("displays project name and status", () => {
  render(<ProjectCard project={{ id: "1", name: "ML Pipeline", status: "active" }} />)

  expect(screen.getByText("ML Pipeline")).toBeInTheDocument()
  expect(screen.getByText("active")).toBeInTheDocument()
})
```

### 2. GREEN — Implement Minimally

Write just enough component code to pass the test.

### 3. REFACTOR — Clean Up

Simplify while keeping tests green.

## Component Tests

### Query by Accessibility Role

```tsx
test("renders form with accessible labels", () => {
  render(<CreateProjectForm />)

  // Prefer role-based queries
  expect(screen.getByRole("textbox", { name: /project name/i })).toBeInTheDocument()
  expect(screen.getByRole("button", { name: /create/i })).toBeInTheDocument()
})
```

### User Interaction

```tsx
test("submits form with valid data", async () => {
  const user = userEvent.setup()
  const onSubmit = vi.fn()
  render(<CreateProjectForm onSubmit={onSubmit} />)

  await user.type(screen.getByRole("textbox", { name: /name/i }), "New Project")
  await user.click(screen.getByRole("button", { name: /create/i }))

  expect(onSubmit).toHaveBeenCalledWith({ name: "New Project" })
})
```

### Async Loading States

```tsx
test("shows loading skeleton then project data", async () => {
  render(<ProjectList orgId="org-1" />, { wrapper: QueryWrapper })

  expect(screen.getByTestId("project-skeleton")).toBeInTheDocument()
  expect(await screen.findByText("ML Pipeline")).toBeInTheDocument()
  expect(screen.queryByTestId("project-skeleton")).not.toBeInTheDocument()
})
```

## Hook Tests

```tsx
import { renderHook, waitFor } from "@testing-library/react"
import { useProjects } from "./use-projects"

test("fetches projects for organization", async () => {
  const { result } = renderHook(() => useProjects("org-1"), {
    wrapper: QueryWrapper,
  })

  await waitFor(() => expect(result.current.isSuccess).toBe(true))
  expect(result.current.data).toHaveLength(3)
})
```

## Mutation Tests

```tsx
test("creates project and invalidates cache", async () => {
  const user = userEvent.setup()
  render(<CreateProjectForm />, { wrapper: QueryWrapper })

  await user.type(screen.getByRole("textbox", { name: /name/i }), "New Project")
  await user.click(screen.getByRole("button", { name: /create/i }))

  await waitFor(() => {
    expect(screen.getByText("Project created")).toBeInTheDocument()
  })
})
```

## MSW Handlers — Mock API

```ts
// test/mocks/handlers.ts
import { graphql, HttpResponse } from "msw"

export const handlers = [
  graphql.query("Projects", () => {
    return HttpResponse.json({
      data: {
        projects: [
          { id: "1", name: "ML Pipeline", status: "active" },
          { id: "2", name: "Data Ingestion", status: "paused" },
        ],
      },
    })
  }),

  graphql.mutation("CreateProject", ({ variables }) => {
    return HttpResponse.json({
      data: {
        createProject: {
          node: { id: "3", name: variables.name, status: "active" },
          messages: [],
        },
      },
    })
  }),
]
```

## QueryWrapper for Tests

```tsx
import { QueryClient, QueryClientProvider } from "@tanstack/react-query"

function createTestQueryClient() {
  return new QueryClient({
    defaultOptions: {
      queries: { retry: false, gcTime: 0 },
      mutations: { retry: false },
    },
  })
}

export function QueryWrapper({ children }: { children: React.ReactNode }) {
  const client = createTestQueryClient()
  return <QueryClientProvider client={client}>{children}</QueryClientProvider>
}
```

## E2E Tests — Playwright

```ts
import { test, expect } from "@playwright/test"

test("create project flow", async ({ page }) => {
  await page.goto("/projects")
  await page.getByRole("button", { name: /new project/i }).click()
  await page.getByRole("textbox", { name: /name/i }).fill("E2E Project")
  await page.getByRole("button", { name: /create/i }).click()

  await expect(page.getByText("E2E Project")).toBeVisible()
})
```

## DO and DON'T

**DO:**
- Test behavior, not implementation details
- Query by role, label, or text — not by class or test ID (unless necessary)
- Test loading, error, and empty states
- Use `userEvent` over `fireEvent`
- Use `waitFor` and `findBy` for async assertions

**DON'T:**
- Test internal component state directly
- Snapshot test entire pages
- Mock hooks you own — test via the component
- Use `container.querySelector` — use RTL queries
- Skip the RED phase — always verify the test fails first
