---
name: django-security
description: Django security best practices — production settings, authentication, authorization, and Strawberry GraphQL security patterns
allowed-tools: Read, Edit, Write, Grep, Glob, Bash
---

# Django Security

Security patterns for Django + Strawberry GraphQL applications.

## Usage

```
/django-security [topic]
```

Topics: settings, auth, permissions, csrf, uploads, api

## Production Settings

```python
# settings/production.py
DEBUG = False
ALLOWED_HOSTS = [os.environ["DJANGO_ALLOWED_HOSTS"]]
SECRET_KEY = os.environ["DJANGO_SECRET_KEY"]

# HTTPS
SECURE_SSL_REDIRECT = True
SECURE_HSTS_SECONDS = 31536000
SECURE_HSTS_INCLUDE_SUBDOMAINS = True
SECURE_HSTS_PRELOAD = True

# Cookies
SESSION_COOKIE_SECURE = True
CSRF_COOKIE_SECURE = True
SESSION_COOKIE_HTTPONLY = True
CSRF_COOKIE_HTTPONLY = True
SESSION_COOKIE_SAMESITE = "Lax"

# Security headers
SECURE_CONTENT_TYPE_NOSNIFF = True
SECURE_BROWSER_XSS_FILTER = True
X_FRAME_OPTIONS = "DENY"
```

## Authentication

### Custom User Model

```python
from django.contrib.auth.models import AbstractUser

class User(AbstractUser):
    organization = models.ForeignKey("Organization", on_delete=models.CASCADE)

    class Meta:
        indexes = [models.Index(fields=["organization", "is_active"])]
```

### Password Hashing

```python
# settings.py — Argon2 preferred, PBKDF2 fallback
PASSWORD_HASHERS = [
    "django.contrib.auth.hashers.Argon2PasswordHasher",
    "django.contrib.auth.hashers.PBKDF2PasswordHasher",
]
```

## Authorization — Strawberry Patterns

### Permission Classes

```python
import strawberry
from strawberry.permission import BasePermission
from strawberry.types import Info

class IsAuthenticated(BasePermission):
    message = "Authentication required"

    def has_permission(self, source, info: Info, **kwargs) -> bool:
        return info.context.request.user.is_authenticated


class IsOrgMember(BasePermission):
    message = "Organization membership required"

    def has_permission(self, source, info: Info, **kwargs) -> bool:
        user = info.context.request.user
        if not user.is_authenticated:
            return False
        # Object-level check happens in resolver
        return True
```

### Object-Level Authorization

```python
@strawberry.type
class Query:
    @strawberry.field(permission_classes=[IsAuthenticated])
    def project(self, info, id: strawberry.ID) -> ProjectType | None:
        user = info.context.request.user
        project = Project.objects.filter(
            id=id,
            organization=user.organization,  # Org-scoped — prevents IDOR
        ).first()
        return project
```

## SQL Injection Prevention

```python
# NEVER: String interpolation in queries
Project.objects.raw(f"SELECT * FROM project WHERE name = '{name}'")

# ALWAYS: Use ORM
Project.objects.filter(name=name)

# If raw SQL is needed: parameterized queries
Project.objects.raw("SELECT * FROM project WHERE name = %s", [name])
```

## CSRF Protection

Django CSRF middleware is enabled by default. For Strawberry GraphQL:

```python
# views.py — Strawberry handles CSRF via Django middleware
from strawberry.django.views import GraphQLView

urlpatterns = [
    path("graphql/", GraphQLView.as_view(schema=schema)),
]
```

For AJAX requests, include the CSRF token header:
```javascript
fetch("/graphql/", {
  method: "POST",
  headers: {
    "X-CSRFToken": getCookie("csrftoken"),
    "Content-Type": "application/json",
  },
  body: JSON.stringify({ query }),
})
```

## File Upload Security

```python
import magic
from django.core.exceptions import ValidationError

ALLOWED_TYPES = {"image/jpeg", "image/png", "application/pdf"}
MAX_SIZE = 10 * 1024 * 1024  # 10MB

def validate_upload(file):
    if file.size > MAX_SIZE:
        raise ValidationError("File too large (10MB max)")

    mime = magic.from_buffer(file.read(2048), mime=True)
    file.seek(0)
    if mime not in ALLOWED_TYPES:
        raise ValidationError(f"Unsupported file type: {mime}")
```

## Rate Limiting

```python
# Use django-ratelimit on views that need protection
from django_ratelimit.decorators import ratelimit

@ratelimit(key="ip", rate="10/m", method="POST")
def graphql_view(request):
    ...
```

## Security Checklist

- [ ] `DEBUG = False` in production
- [ ] `SECRET_KEY` loaded from environment
- [ ] HTTPS enforced (`SECURE_SSL_REDIRECT`)
- [ ] Cookies marked `Secure`, `HttpOnly`, `SameSite`
- [ ] CSRF protection enabled on all mutation endpoints
- [ ] Object-level authorization on all queries (org-scoped)
- [ ] File uploads validated (type, size)
- [ ] No raw SQL with string interpolation
- [ ] Rate limiting on public endpoints
- [ ] Security headers set (HSTS, X-Frame-Options, etc.)
