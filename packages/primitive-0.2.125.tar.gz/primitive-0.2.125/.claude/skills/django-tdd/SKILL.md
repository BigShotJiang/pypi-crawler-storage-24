---
name: django-tdd
description: Test-driven development for Django with pytest-django, factory_boy, and Strawberry GraphQL testing patterns
allowed-tools: Read, Edit, Write, Grep, Glob, Bash
---

# Django TDD

TDD patterns for Django + Strawberry GraphQL using pytest-django and factory_boy.

## Usage

```
/django-tdd [topic]
```

Topics: models, services, graphql, factories, fixtures

## Configuration

### pytest.ini / pyproject.toml

```ini
[tool.pytest.ini_options]
DJANGO_SETTINGS_MODULE = "config.settings.test"
python_files = "test_*.py"
python_functions = "test_*"
markers = [
    "unit: Unit tests",
    "integration: Integration tests",
    "slow: Slow tests",
]
addopts = "--reuse-db --no-migrations -q"
```

### conftest.py

```python
import pytest
from tests.factories import UserFactory, OrganizationFactory


@pytest.fixture
def org(db):
    return OrganizationFactory()


@pytest.fixture
def user(org):
    return UserFactory(organization=org)


@pytest.fixture
def auth_client(client, user):
    client.force_login(user)
    return client
```

## Factory Boy

```python
import factory
from app.models import Organization, User, Project


class OrganizationFactory(factory.django.DjangoModelFactory):
    class Meta:
        model = Organization

    name = factory.Sequence(lambda n: f"Org {n}")


class UserFactory(factory.django.DjangoModelFactory):
    class Meta:
        model = User

    username = factory.Sequence(lambda n: f"user{n}")
    email = factory.LazyAttribute(lambda o: f"{o.username}@example.com")
    organization = factory.SubFactory(OrganizationFactory)


class ProjectFactory(factory.django.DjangoModelFactory):
    class Meta:
        model = Project

    name = factory.Sequence(lambda n: f"Project {n}")
    organization = factory.SubFactory(OrganizationFactory)
```

## TDD Cycle

### 1. RED — Write Failing Test

```python
@pytest.mark.unit
def test_create_project_assigns_organization(db, org):
    project = ProjectService.create_project(
        org_id=org.id, name="New Project", created_by=org.owner.id
    )
    assert project.organization == org
    assert project.name == "New Project"
```

### 2. GREEN — Implement Minimally

Write just enough service code to pass the test.

### 3. REFACTOR — Clean Up

Simplify while keeping tests green.

## Model Tests

```python
@pytest.mark.unit
def test_project_soft_delete(db):
    project = ProjectFactory()
    project.soft_delete()
    project.refresh_from_db()
    assert project.deleted_at is not None

@pytest.mark.unit
def test_active_queryset_excludes_deleted(db):
    active = ProjectFactory()
    deleted = ProjectFactory(deleted_at=timezone.now())
    assert active in Project.objects.active()
    assert deleted not in Project.objects.active()
```

## Service Tests

```python
@pytest.mark.integration
def test_create_project_creates_audit_log(db, org, user):
    project = ProjectService.create_project(
        org_id=org.id, name="Test", created_by=user.id
    )
    assert AuditLog.objects.filter(
        action="project.created", target_id=project.id
    ).exists()

@pytest.mark.integration
def test_create_project_rolls_back_on_error(db, org, user, mocker):
    mocker.patch.object(AuditLog.objects, "create", side_effect=Exception("fail"))
    with pytest.raises(Exception):
        ProjectService.create_project(
            org_id=org.id, name="Test", created_by=user.id
        )
    assert not Project.objects.filter(name="Test").exists()
```

## Strawberry GraphQL Tests

```python
import json
from strawberry.test import BaseGraphQLTestClient


class GraphQLClient(BaseGraphQLTestClient):
    def request(self, body, headers=None, files=None):
        response = self.client.post(
            "/graphql/",
            data=json.dumps(body),
            content_type="application/json",
            **(headers or {}),
        )
        return response


@pytest.fixture
def gql_client(auth_client):
    return GraphQLClient(auth_client)


@pytest.mark.integration
def test_query_projects(gql_client, user):
    ProjectFactory(organization=user.organization)
    ProjectFactory()  # Different org — should not appear

    response = gql_client.query("""
        query {
            projects {
                id
                name
            }
        }
    """)
    assert len(response.data["projects"]) == 1


@pytest.mark.integration
def test_create_project_mutation(gql_client, user):
    response = gql_client.query("""
        mutation {
            createProject(name: "New Project") {
                node { id name }
                messages { kind message }
            }
        }
    """)
    assert response.data["createProject"]["node"]["name"] == "New Project"
    assert response.data["createProject"]["messages"] == []
```

## Mocking External Services

```python
@pytest.mark.unit
def test_notify_on_project_creation(db, org, user, mocker):
    mock_notify = mocker.patch("app.services.notifications.send_notification")
    ProjectService.create_project(
        org_id=org.id, name="Test", created_by=user.id
    )
    mock_notify.assert_called_once()
```

## DO and DON'T

**DO:**
- Test behavior, not implementation
- Use factories for all test data
- Test error paths and edge cases
- Keep tests independent
- Use `@pytest.mark.parametrize` for multiple inputs

**DON'T:**
- Hardcode IDs or magic values
- Share mutable state between tests
- Test Django/Strawberry framework internals
- Use `unittest.TestCase` (use plain functions)
- Skip the RED phase — always verify the test fails first
