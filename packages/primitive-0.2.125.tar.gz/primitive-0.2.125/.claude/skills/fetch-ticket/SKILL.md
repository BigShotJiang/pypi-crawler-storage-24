---
name: fetch-ticket
description: Parse a Linear ticket ID or URL, fetch issue details, auto-assign to current user, and return ticket context.
argument-hint: [ticket-id or ticket-url]
allowed-tools: Bash, mcp__linear-server__get_issue, mcp__linear-server__get_user, mcp__linear-server__update_issue
---

# Fetch Ticket

Fetches a Linear ticket's details and auto-assigns it to the current user. This is a composable sub-skill used by `/plan-work`, `/start-work`, and `/feature`.

## Usage

```
/fetch-ticket <ticket-id>
/fetch-ticket ENG-537
/fetch-ticket https://linear.app/primitive/issue/ENG-537
```

## Steps

### 1. Parse Ticket ID

Extract the ticket ID from the argument:
- Plain ID: `ENG-537` → use as-is
- Linear URL: `https://linear.app/primitive/issue/ENG-537` → extract `ENG-537`

### 2. Fetch Issue Details

Use the Linear MCP server to fetch the ticket:
- Call `mcp__linear-server__get_issue` with the ticket ID
- Retrieve: title, description, state, labels, assignee

If ticket not found, show error and stop.

### 3. Auto-Assign to Current User

- Get current user: `mcp__linear-server__get_user` with query `"me"`
- Update ticket assignee: `mcp__linear-server__update_issue` with the current user's ID
- This ensures the person starting work is always the assignee

### 4. Display Ticket Context

```
Linear Ticket: <TICKET-ID> - <TITLE>
Status: <STATE>
Assignee: <ASSIGNEE>

Description:
<TICKET-DESCRIPTION>

Labels: <LABELS>
```

## Output

This skill makes the following context available for downstream skills:
- Ticket ID (e.g., `ENG-537`)
- Ticket number (e.g., `537`)
- Ticket title
- Ticket description
- Current user's displayName (for branch naming)
- Current user's ID

## Error Handling

- **Ticket not found**: Show error, ask user to verify ticket ID
- **Linear auth failure**: Show error, ask user to verify Linear MCP configuration
- **User fetch fails**: Show error, ask user to verify Linear authentication
