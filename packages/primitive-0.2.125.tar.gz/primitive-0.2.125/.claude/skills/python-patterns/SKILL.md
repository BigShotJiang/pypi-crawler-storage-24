---
name: python-patterns
description: Python development patterns — type hints, context managers, generators, dataclasses, Protocol, decorators
allowed-tools: Read, Edit, Write, Grep, Glob
---

# Python Patterns

Idiomatic Python patterns for Primitive Corp projects.

## Usage

```
/python-patterns [topic]
```

Topics: types, errors, context-managers, generators, dataclasses, decorators, concurrency

## Type Hints

### Modern Syntax (Python 3.10+)

```python
from __future__ import annotations

# Union types
def find_user(user_id: int) -> User | None: ...

# Collections
def process(items: list[str]) -> dict[str, int]: ...

# Callable
from collections.abc import Callable
def retry(fn: Callable[..., T], attempts: int = 3) -> T: ...
```

### Protocol — Duck Typing

```python
from typing import Protocol

class Repository(Protocol):
    def find_by_id(self, id: int) -> dict | None: ...
    def save(self, entity: dict) -> dict: ...
    def delete(self, id: int) -> None: ...

# Any class with these methods satisfies Repository — no inheritance needed
```

### TypeAlias

```python
from typing import TypeAlias

UserId: TypeAlias = int
Payload: TypeAlias = dict[str, str | int | list[str]]
```

## Error Handling

```python
# Catch specific exceptions
try:
    result = service.process(data)
except ValidationError as e:
    logger.warning("Validation failed: %s", e)
    raise
except DatabaseError as e:
    logger.error("DB error processing %s: %s", data.id, e)
    raise ServiceError("Processing failed") from e

# Custom exception hierarchy
class AppError(Exception):
    """Base exception for application errors."""

class NotFoundError(AppError):
    """Resource not found."""

class PermissionDeniedError(AppError):
    """Insufficient permissions."""
```

## Context Managers

```python
from contextlib import contextmanager

@contextmanager
def temporary_setting(key: str, value: str):
    original = os.environ.get(key)
    os.environ[key] = value
    try:
        yield
    finally:
        if original is None:
            del os.environ[key]
        else:
            os.environ[key] = original

# Usage
with temporary_setting("DEBUG", "true"):
    run_debug_operation()
```

## Generators

```python
# Generator for memory-efficient processing
def read_large_file(path: str, chunk_size: int = 8192):
    with open(path, "rb") as f:
        while chunk := f.read(chunk_size):
            yield chunk

# Generator expression
total = sum(item.price for item in items if item.active)
```

## Dataclasses

```python
from dataclasses import dataclass, field

@dataclass(frozen=True)
class CreateProjectRequest:
    name: str
    org_id: int
    tags: list[str] = field(default_factory=list)

# Frozen dataclasses are hashable and immutable
```

## Decorators

```python
import functools
import time
import logging

logger = logging.getLogger(__name__)

def log_execution_time(func):
    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        start = time.perf_counter()
        result = func(*args, **kwargs)
        elapsed = time.perf_counter() - start
        logger.info("%s took %.3fs", func.__name__, elapsed)
        return result
    return wrapper

# Parameterized decorator
def retry(max_attempts: int = 3, delay: float = 1.0):
    def decorator(func):
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            for attempt in range(max_attempts):
                try:
                    return func(*args, **kwargs)
                except Exception:
                    if attempt == max_attempts - 1:
                        raise
                    time.sleep(delay * (attempt + 1))
        return wrapper
    return decorator
```

## Anti-Patterns to Avoid

| Anti-Pattern | Fix |
|---|---|
| Mutable default args: `def f(x=[])` | `def f(x=None): x = x or []` |
| Bare `except:` | Catch specific exceptions |
| `type(x) == int` | `isinstance(x, int)` |
| String concat in loops | `"".join(parts)` |
| `value == None` | `value is None` |
| `from module import *` | Import specific names |
| Manual file handling | Use `with` statement |
| `print()` for logging | Use `logging` module |
