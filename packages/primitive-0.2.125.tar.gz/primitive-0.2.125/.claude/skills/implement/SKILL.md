---
name: implement
description: Load an existing implementation plan and execute it — edit/create files and write tests. Requires a plan from /create-plan. Does not verify or submit.
argument-hint: [ticket-id or ticket-url]
allowed-tools: Read, Write, Edit, Bash, Glob, Grep
---

# Implement

Loads an existing implementation plan and executes it — writing code and tests. This is a composable sub-skill used by `/start-work` and `/feature`.

**Requires**: A plan must already exist at `.claude/plans/<ticket-id-lowercase>-plan.md`. If no plan exists, this skill stops and prompts the user to run `/create-plan` first.

## Usage

```
/implement <ticket-id>
/implement ENG-537
```

## Steps

### 1. Load Plan

Look for the plan at:
```
.claude/plans/<ticket-id-lowercase>-plan.md
```

**If found**: Read and display the plan. Proceed to step 2.

**If not found**: Stop and display:
```
No implementation plan found for <TICKET-ID>

Please run /create-plan <TICKET-ID> first to create an implementation plan,
then re-run /implement <TICKET-ID>.
```

Do not proceed without a plan.

### 2. Implement Core Changes

Follow the plan to make code changes:
- Use `Edit` to modify existing files
- Use `Write` to create new files
- Follow existing code patterns and conventions
- Read files before editing them
- Don't over-engineer — keep solutions simple

### 3. Write Tests

Create tests following project conventions:
- Place tests in the appropriate `tests/` directory
- Use existing factories and fixtures
- Cover happy path, edge cases, and error conditions
- Follow test naming conventions in the codebase

## Notes

- This skill does NOT run verification (format, lint, test). Use `/verify` for that.
- This skill does NOT commit, push, or create PRs. Use `/self-review` and `/submit-pr` for that.
- Implementation should strictly follow the approved plan.
