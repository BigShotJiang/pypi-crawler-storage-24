---
name: frontend-patterns
description: React and Next.js patterns — component composition, hooks, TanStack Query, performance optimization
allowed-tools: Read, Edit, Write, Grep, Glob
---

# Frontend Patterns

React and Next.js patterns for Primitive Corp's frontend. State management uses TanStack Query for server state and React context for UI state.

## Usage

```
/frontend-patterns [topic]
```

Topics: components, hooks, data-fetching, performance, forms, errors

## Component Composition

### Small, Focused Components

```tsx
// Prefer composition over large monolithic components
function ProjectCard({ project }: { project: Project }) {
  return (
    <Card>
      <CardHeader>
        <ProjectStatus status={project.status} />
        <CardTitle>{project.name}</CardTitle>
      </CardHeader>
      <CardContent>
        <ProjectMetadata project={project} />
      </CardContent>
    </Card>
  )
}
```

### Server vs Client Components (Next.js App Router)

```tsx
// Server Component (default) — fetches data, no interactivity
async function ProjectList() {
  const projects = await getProjects()
  return <ProjectTable projects={projects} />
}

// Client Component — needed for interactivity
"use client"
function ProjectFilter({ onFilter }: { onFilter: (q: string) => void }) {
  const [query, setQuery] = useState("")
  // ...
}
```

## Custom Hooks

```tsx
function useDebounce<T>(value: T, delay: number): T {
  const [debouncedValue, setDebouncedValue] = useState(value)

  useEffect(() => {
    const timer = setTimeout(() => setDebouncedValue(value), delay)
    return () => clearTimeout(timer)
  }, [value, delay])

  return debouncedValue
}

function useMediaQuery(query: string): boolean {
  const [matches, setMatches] = useState(false)

  useEffect(() => {
    const mql = window.matchMedia(query)
    setMatches(mql.matches)
    const handler = (e: MediaQueryListEvent) => setMatches(e.matches)
    mql.addEventListener("change", handler)
    return () => mql.removeEventListener("change", handler)
  }, [query])

  return matches
}
```

## Data Fetching — TanStack Query

### Queries

```tsx
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query"

function useProjects(orgId: string) {
  return useQuery({
    queryKey: ["projects", orgId],
    queryFn: () => fetchProjects(orgId),
    staleTime: 5 * 60 * 1000, // 5 minutes
  })
}

function ProjectList({ orgId }: { orgId: string }) {
  const { data, isLoading, error } = useProjects(orgId)

  if (isLoading) return <ProjectSkeleton />
  if (error) return <ErrorDisplay error={error} />

  return data.map(p => <ProjectCard key={p.id} project={p} />)
}
```

### Mutations with Optimistic Updates

```tsx
function useCreateProject() {
  const queryClient = useQueryClient()

  return useMutation({
    mutationFn: createProject,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["projects"] })
    },
  })
}

// Optimistic update
function useUpdateProject() {
  const queryClient = useQueryClient()

  return useMutation({
    mutationFn: updateProject,
    onMutate: async (newProject) => {
      await queryClient.cancelQueries({ queryKey: ["projects"] })
      const previous = queryClient.getQueryData(["projects"])
      queryClient.setQueryData(["projects"], (old: Project[]) =>
        old.map(p => p.id === newProject.id ? { ...p, ...newProject } : p)
      )
      return { previous }
    },
    onError: (_err, _vars, context) => {
      queryClient.setQueryData(["projects"], context?.previous)
    },
    onSettled: () => {
      queryClient.invalidateQueries({ queryKey: ["projects"] })
    },
  })
}
```

## Performance

### Memoization

```tsx
// Memoize expensive computations
const sortedItems = useMemo(
  () => items.toSorted((a, b) => a.name.localeCompare(b.name)),
  [items]
)

// Memoize callbacks passed to children
const handleSelect = useCallback(
  (id: string) => setSelected(id),
  [setSelected]
)

// Memoize components that receive stable props
const MemoizedRow = memo(function Row({ item }: { item: Item }) {
  return <tr><td>{item.name}</td></tr>
})
```

### Code Splitting

```tsx
import dynamic from "next/dynamic"

const HeavyChart = dynamic(() => import("@/components/HeavyChart"), {
  loading: () => <ChartSkeleton />,
  ssr: false,
})
```

## Error Boundaries

```tsx
"use client"
import { ErrorBoundary } from "react-error-boundary"

function ErrorFallback({ error, resetErrorBoundary }: FallbackProps) {
  return (
    <Alert variant="destructive">
      <AlertTitle>Something went wrong</AlertTitle>
      <AlertDescription>{error.message}</AlertDescription>
      <Button onClick={resetErrorBoundary}>Try again</Button>
    </Alert>
  )
}

// Usage
<ErrorBoundary FallbackComponent={ErrorFallback}>
  <ProjectDashboard />
</ErrorBoundary>
```

## Form Handling

Use `react-hook-form` with Zod validation:

```tsx
import { useForm } from "react-hook-form"
import { zodResolver } from "@hookform/resolvers/zod"
import { z } from "zod"

const schema = z.object({
  name: z.string().min(1, "Name is required"),
  email: z.string().email("Invalid email"),
})

type FormData = z.infer<typeof schema>

function CreateUserForm() {
  const { register, handleSubmit, formState: { errors } } = useForm<FormData>({
    resolver: zodResolver(schema),
  })

  const onSubmit = (data: FormData) => createUser.mutate(data)

  return (
    <form onSubmit={handleSubmit(onSubmit)}>
      <Input {...register("name")} error={errors.name?.message} />
      <Input {...register("email")} error={errors.email?.message} />
      <Button type="submit">Create</Button>
    </form>
  )
}
```

## Checklist

- [ ] Server components for data fetching, client components for interactivity
- [ ] TanStack Query for all server state (no `useEffect` + `useState` for fetching)
- [ ] Loading and error states handled for every data-fetching component
- [ ] `useMemo`/`useCallback` for expensive computations and stable callbacks
- [ ] Forms validated with Zod schemas
- [ ] Error boundaries around major page sections
