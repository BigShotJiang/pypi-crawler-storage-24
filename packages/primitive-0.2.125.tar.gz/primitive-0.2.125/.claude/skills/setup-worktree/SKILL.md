---
name: setup-worktree
description: Create a GitHub branch and git worktree for a Linear ticket. Reads verification commands from CLAUDE.md, installs dependencies, and sets up the dev environment.
argument-hint: [ticket-id or ticket-url]
allowed-tools: Read, Bash
---

# Setup Worktree

Creates a GitHub branch and git worktree for isolated development on a ticket. This is a composable sub-skill used by `/plan-work`, `/start-work`, and `/feature`.

**Expects**: Ticket context (title, number, username) from `/fetch-ticket`. If not available, you may need to re-fetch.

## Usage

```
/setup-worktree <ticket-id>
```

## Steps

### 1. Read Verification Commands from CLAUDE.md

Read this project's `CLAUDE.md` and find the `## Verification` section. Parse the install command.

Expected format:
```markdown
## Verification
- Install: make install
- Format: make format
- Lint: make lint
- Test: ENVIRONMENT=test uv run pytest
```

If the section is missing, use `make install` as the default and warn the user.

### 2. Generate Branch Name

Follow the Linear GitHub branch naming convention:
```
<username>/eng-<ticket-number>-<description>
```

Where:
- `<username>` is the current user's displayName from Linear (lowercase, no spaces)
- `<ticket-number>` is the numeric ticket number (e.g., `537` from `ENG-537`)
- `<description>` is a slugified version of the ticket title (lowercase, hyphens, max 50 chars)

Example: `dylan/eng-537-adds-global-projects`

### 3. Check if Worktree Already Exists

```bash
git worktree list | grep "worktrees/<branch-name>"
```

**If the worktree already exists**:
- Display: `Worktree already exists at worktrees/<branch-name>`
- Skip steps 4-6, proceed to step 7

**If the worktree does NOT exist**:
- Continue with steps 4-6

### 4. Create GitHub Branch

```bash
# Get main branch SHA
gh api repos/{owner}/{repo}/git/refs/heads/main --jq '.object.sha'

# Create new branch
gh api repos/{owner}/{repo}/git/refs \
  -f ref='refs/heads/<branch-name>' \
  -f sha='<main-sha>'
```

If the branch already exists on GitHub, skip creation and just fetch it.

### 5. Create Git Worktree

```bash
mkdir -p worktrees
git fetch origin <branch-name>:<branch-name>
git worktree add worktrees/<branch-name> <branch-name>
```

### 6. Setup Environment

In the new worktree directory:
- Run the install command from CLAUDE.md `## Verification` section
- Copy `.env.example` if present:
  ```bash
  cp .env.example .env 2>/dev/null || true
  ```

### 7. Display Result

```
Worktree ready: worktrees/<branch-name>
Environment setup complete
```

## Error Handling

- **Branch already exists**: Ask if user wants to switch to existing branch or choose a new name
- **Worktree already exists**: Use the existing worktree (skip creation)
- **GitHub API fails**: Fall back to local-only branch creation with a warning
- **CLAUDE.md missing `## Verification`**: Warn user, use `make install` as default
