---
name: tdd-workflow
description: Test-driven development workflow — Red-Green-Refactor cycle, test types, coverage verification
allowed-tools: Read, Edit, Write, Bash, Grep, Glob
---

# TDD Workflow

Structured test-driven development workflow enforcing tests-first with 80%+ coverage.

## Usage

```
/tdd-workflow [feature-description]
```

## Steps

### 1. Understand the Requirement

Read the plan or ticket. Identify:
- What behavior needs to exist?
- What are the inputs and outputs?
- What are the error cases?
- What edge cases matter?

### 2. Write Test First (RED)

Write a test that describes the expected behavior. The test MUST fail before you write implementation code.

```python
# Example: testing a new service method
def test_calculate_project_cost(db):
    project = ProjectFactory(hours=100, rate_per_hour=50)
    result = BillingService.calculate_cost(project.id)
    assert result == Decimal("5000.00")
```

```typescript
// Example: testing a React hook
it("returns filtered projects", () => {
  const { result } = renderHook(() => useFilteredProjects("active"))
  expect(result.current.data).toEqual([])  // initially empty
})
```

### 3. Verify Failure

Run the test. It MUST fail. If it passes, your test isn't testing new behavior.

```bash
# Python
pytest tests/test_billing.py::test_calculate_project_cost -x

# TypeScript
npx vitest run --testNamePattern "returns filtered projects"
```

### 4. Implement Minimally (GREEN)

Write the smallest amount of code to make the test pass. Do not add extra features, error handling, or optimization yet.

### 5. Verify Pass

Run the test again. It must pass now.

### 6. Refactor (IMPROVE)

With tests green, clean up:
- Remove duplication
- Improve naming
- Simplify logic
- Extract helpers if needed

Run tests after each refactor step — they must stay green.

### 7. Add Edge Cases

Write tests for edge cases one at a time, following the same RED-GREEN cycle:

- Null/None/empty input
- Invalid types or values
- Boundary values (0, negative, max)
- Error paths (permission denied, not found)
- Concurrent access

### 8. Verify Coverage

```bash
# Python
pytest --cov=app --cov-report=term-missing --cov-fail-under=80

# TypeScript
npx vitest run --coverage
```

Coverage must be 80%+ on new code. Check for:
- Uncovered branches (if/else paths)
- Uncovered error handlers
- Uncovered edge cases

## Test Types

| Type | Scope | Speed | When |
|------|-------|-------|------|
| **Unit** | Single function/class | <100ms | Always |
| **Integration** | Multiple components, DB | <1s | API endpoints, services |
| **E2E** | Full user flow | <30s | Critical paths only |

## Mocking Guidelines

- Mock external services (APIs, email, payment)
- Mock time-dependent operations (`freezegun`, `time_machine`)
- Do NOT mock the database in integration tests — use a real test DB
- Do NOT mock the thing you're testing

## Anti-Patterns

- Skipping the RED phase (writing tests after implementation)
- Testing implementation details instead of behavior
- Shared mutable state between tests
- Mocking everything (losing integration confidence)
- Writing tests that pass regardless of implementation
