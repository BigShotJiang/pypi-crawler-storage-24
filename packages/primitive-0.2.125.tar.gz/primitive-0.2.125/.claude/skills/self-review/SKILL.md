---
name: self-review
description: Review changed files against a quality checklist, fix issues found, re-verify, and commit with a detailed message.
allowed-tools: Read, Edit, Bash, Glob, Grep
---

# Self-Review

Conducts a thorough self-review of all changed files, fixes issues, re-verifies, and commits. This is a composable sub-skill used by `/start-work` and `/feature`.

## Usage

```
/self-review
```

## Steps

### 1. Find Changed Files

```bash
git diff --name-only HEAD
```

Also check for untracked files:
```bash
git status --short
```

### 2. Review Against Checklist

For each changed file, read it and check against:

**Security & Safety**
- [ ] Input validation on all user-facing APIs
- [ ] SQL injection prevention (parameterized queries / ORM)
- [ ] Authentication/authorization checks on every protected resource
- [ ] No hardcoded secrets or credentials

**Error Handling**
- [ ] External calls have proper error handling
- [ ] Graceful degradation when services fail
- [ ] No bare `except` clauses

**Data Integrity**
- [ ] Transactions used for multi-step writes
- [ ] Race conditions prevented (atomic operations, locking)
- [ ] Null/None checks before attribute access

**Performance**
- [ ] No N+1 query problems
- [ ] Appropriate caching with invalidation
- [ ] Pagination on list endpoints

**Code Quality**
- [ ] No duplicate code
- [ ] Functions are focused and single-purpose
- [ ] No debugging code left (print statements, commented-out code)

**Testing**
- [ ] All new code paths covered by tests
- [ ] Error conditions tested
- [ ] Test names clearly describe what they test

### 3. Fix Issues

For each finding (critical first):
- Make the fix
- Update tests if needed

### 4. Re-verify

Read CLAUDE.md `## Verification` and run all verification commands:
```bash
<FORMAT_CMD>
<LINT_CMD>
<TEST_CMD>
```

Fix any failures and re-run until all pass.

### 5. Commit

```bash
git add <files>
git commit -m "$(cat <<'EOF'
<Feature summary>

<Description>

Key changes:
- <Change 1>
- <Change 2>

Self-review improvements:
- <Improvement 1>
- <Improvement 2>

Co-Authored-By: Claude Sonnet 4.6 <noreply@anthropic.com>
EOF
)"
```

### 6. Display Summary

```
Self-Review Complete!

Findings:
- Critical issues: <n> (all fixed)
- Important improvements: <n> (all fixed)
- Nice-to-have: <n> (fixed <n>)

Verification:
- All tests passing: [pass/fail]
- Code formatted: [pass/fail]
- No lint errors: [pass/fail]

Committed: <commit-sha>
```
