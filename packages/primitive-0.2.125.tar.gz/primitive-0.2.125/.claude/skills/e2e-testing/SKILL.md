---
name: e2e-testing
description: Playwright E2E testing patterns — Page Object Model, flaky test handling, CI integration, artifact management
allowed-tools: Read, Edit, Write, Bash, Grep, Glob
---

# E2E Testing

Playwright end-to-end testing patterns for critical user flows.

## Usage

```
/e2e-testing [topic]
```

Topics: setup, pom, flaky, ci, artifacts

## Configuration

```typescript
// playwright.config.ts
import { defineConfig } from "@playwright/test"

export default defineConfig({
  testDir: "./tests/e2e",
  timeout: 30000,
  retries: process.env.CI ? 2 : 0,
  use: {
    baseURL: process.env.BASE_URL || "http://localhost:3000",
    trace: "on-first-retry",
    screenshot: "only-on-failure",
    video: "retain-on-failure",
  },
  projects: [
    { name: "chromium", use: { browserName: "chromium" } },
  ],
})
```

## Page Object Model

```typescript
// pages/login.page.ts
import { Page, expect } from "@playwright/test"

export class LoginPage {
  constructor(private page: Page) {}

  async goto() {
    await this.page.goto("/login")
  }

  async login(email: string, password: string) {
    await this.page.getByTestId("email-input").fill(email)
    await this.page.getByTestId("password-input").fill(password)
    await this.page.getByTestId("login-button").click()
    await this.page.waitForURL("/dashboard")
  }

  async expectError(message: string) {
    await expect(this.page.getByTestId("error-message")).toContainText(message)
  }
}

// pages/dashboard.page.ts
export class DashboardPage {
  constructor(private page: Page) {}

  async expectLoaded() {
    await expect(this.page.getByTestId("dashboard-title")).toBeVisible()
  }

  async createProject(name: string) {
    await this.page.getByTestId("create-project-btn").click()
    await this.page.getByTestId("project-name-input").fill(name)
    await this.page.getByTestId("submit-btn").click()
    await this.page.waitForResponse(resp =>
      resp.url().includes("/graphql") && resp.status() === 200
    )
  }
}
```

## Test Structure

```typescript
import { test, expect } from "@playwright/test"
import { LoginPage } from "./pages/login.page"
import { DashboardPage } from "./pages/dashboard.page"

test.describe("Project Management", () => {
  let loginPage: LoginPage
  let dashboardPage: DashboardPage

  test.beforeEach(async ({ page }) => {
    loginPage = new LoginPage(page)
    dashboardPage = new DashboardPage(page)
    await loginPage.goto()
    await loginPage.login("test@example.com", "password")
  })

  test("create a new project", async () => {
    await dashboardPage.createProject("Test Project")
    await expect(dashboardPage.page.getByText("Test Project")).toBeVisible()
  })

  test("show error for duplicate project name", async () => {
    await dashboardPage.createProject("Existing Project")
    // Attempt duplicate
    await dashboardPage.createProject("Existing Project")
    await expect(dashboardPage.page.getByText("already exists")).toBeVisible()
  })
})
```

## Locator Strategy

Priority order:
1. `getByTestId("...")` — most stable
2. `getByRole("button", { name: "Submit" })` — semantic
3. `getByText("...")` — visible content
4. `getByLabel("...")` — form fields
5. CSS selectors — last resort

**Never** use XPath or fragile CSS paths.

## Flaky Test Handling

### Prevention
- Wait for conditions, never time: `waitForResponse()` > `waitForTimeout()`
- Wait for network idle after navigation: `waitForLoadState("networkidle")`
- Use auto-waiting locators: `page.getByTestId(...)` auto-waits

### Detection
```bash
# Run 10 times to detect flakiness
npx playwright test --repeat-each=10 tests/e2e/flaky-suspect.spec.ts
```

### Quarantine
```typescript
test("flaky: intermittent network issue", async ({ page }) => {
  test.fixme(true, "Flaky — tracking in ENG-XXX")
})
```

## CI Integration

```yaml
# .github/workflows/e2e.yml
- name: Run E2E tests
  run: npx playwright test
  env:
    BASE_URL: http://localhost:3000
- name: Upload artifacts
  if: failure()
  uses: actions/upload-artifact@v4
  with:
    name: playwright-report
    path: playwright-report/
    retention-days: 7
```

## Artifacts

- **Screenshots**: `only-on-failure` — auto-captured on test failure
- **Traces**: `on-first-retry` — detailed step-by-step for debugging
- **Video**: `retain-on-failure` — video of failed test runs

View traces: `npx playwright show-trace trace.zip`

## Checklist

- [ ] Critical user journeys covered (auth, core CRUD)
- [ ] Page Object Model for all page interactions
- [ ] `data-testid` attributes on interactive elements
- [ ] No `waitForTimeout` — use condition-based waits
- [ ] Flaky tests quarantined with tracking tickets
- [ ] CI uploads artifacts on failure
- [ ] Tests independent — no shared state between tests
