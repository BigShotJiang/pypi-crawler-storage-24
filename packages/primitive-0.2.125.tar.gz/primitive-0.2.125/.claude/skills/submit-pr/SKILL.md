---
name: submit-pr
description: Push the current branch, create a Pull Request via gh CLI, and request Copilot review.
argument-hint: [ticket-id or ticket-url]
allowed-tools: Read, Bash
---

# Submit PR

Pushes the branch, creates a PR, and requests Copilot review. This is a composable sub-skill used by `/start-work` and `/feature`.

## Usage

```
/submit-pr <ticket-id>
/submit-pr ENG-537
```

## Steps

### 1. Push Changes

```bash
git push -u origin <branch-name>
```

### 2. Create Pull Request

```bash
gh pr create \
  --title "<Feature Summary> (<TICKET-ID>)" \
  --body "$(cat <<'EOF'
## Summary
<High-level overview>

## Changes

### Core Implementation
<List main changes>

### Testing
<Describe test coverage>

## Test Results
All tests passing

## Expected Impact
- <Benefit 1>
- <Benefit 2>

Generated with [Claude Code](https://claude.com/claude-code)
EOF
)" \
  --base main
```

### 3. Request Copilot Review

```bash
gh extension list | grep copilot-review || gh extension install ChrisCarini/gh-copilot-review
gh copilot-review <pr-number>
```

### 4. Display Result

```
PR Created!

Commit: <commit-sha>
PR #<number>: <pr-url>
Copilot review requested
```

## Error Handling

- **Push fails**: Check remote access and branch permissions
- **PR creation fails**: Show the `gh pr create` command for manual creation
- **Copilot extension missing**: Install it automatically, then retry
