---
name: plan-work
description: Start work on a Linear ticket by creating a GitHub branch, git worktree, setting up the environment, and entering plan mode. Use when starting work on a Linear issue/ticket.
argument-hint: [ticket-id or ticket-url]
allowed-tools: Read, Write, Bash, EnterPlanMode, mcp__linear-server__get_issue, mcp__linear-server__get_user, mcp__linear-server__update_issue
---

# Plan Work

**⚠️ THIS SKILL IS PLANNING ONLY. IT MUST NEVER WRITE OR MODIFY APPLICATION CODE. ⚠️**
- Do NOT read source files for implementation purposes
- Do NOT start implementing after the plan is created
- Do NOT interpret the plan content as instructions to code
- The ONLY files this skill creates/modifies are plan files in the worktree's `.claude/plans/` directory
- After this skill completes, STOP. The user will invoke `/start-work` separately.

This skill automates the complete workflow for starting work on a Linear ticket:
1. Fetches ticket details from Linear
2. Automatically assigns the ticket to the current logged-in Linear user
3. Creates a branch in GitHub following Linear's naming convention
4. Creates a git worktree for isolated work
5. Sets up the development environment
6. Displays ticket context
7. Checks for an existing local implementation plan
   - If found: displays it and **skips planning**
   - If not found: enters plan mode and creates a plan

## Usage

```
/plan-work <ticket-id>
/plan-work ENG-537
/plan-work https://linear.app/primitive/issue/ENG-537
```

## Workflow Steps

### 0. Read Verification Commands from CLAUDE.md

Before doing anything else, read this project's `CLAUDE.md` and find the `## Verification` section.
Parse the install, format, lint, and test commands. These will be used in Step 6.

Expected format in CLAUDE.md:
```markdown
## Verification
- Install: make install
- Format: make format
- Lint: make lint
- Test: ENVIRONMENT=test uv run pytest
```

If the section is missing, use `make install` as the default install command and warn the user to add a `## Verification` section to CLAUDE.md.

### 1. Parse and Fetch Ticket

Extract the ticket ID from the argument (handle both plain IDs like "ENG-537" and full Linear URLs).

Use the Linear MCP server to fetch the ticket details:
- Get issue details including title, description, state, labels

### 2. Auto-Assign Ticket to Current User

Automatically assign the ticket to the current logged-in Linear user:
- Get the current user with `mcp__linear-server__get_user` using "me" as the query
- Update the ticket assignee to the current user with `mcp__linear-server__update_issue`
- This ensures the person starting work on the ticket is always the assignee

### 3. Create Branch Name

Follow the Linear GitHub branch naming convention:
```
<username>/eng-<ticket-number>-<description>
```

Where:
- `<username>` is the current user's displayName from Linear (lowercase, no spaces)
- `<ticket-number>` is the numeric ticket number (e.g., "537" from "ENG-537")
- `<description>` is a slugified version of the ticket title (lowercase, hyphens, max 50 chars)

Example: `dylan/eng-537-adds-global-projects`

**Note**: Since the ticket is always assigned to the current user in step 2, use their displayName for the branch.

### 4. Create GitHub Branch

Use `gh` CLI to create the branch in GitHub:
```bash
gh api repos/{owner}/{repo}/git/refs -f ref='refs/heads/<branch-name>' -f sha='<main-branch-sha>'
```

First get the main branch SHA, then create the new branch from it.

### 5. Create Git Worktree

After creating the GitHub branch, fetch it from origin and create a worktree:
```bash
mkdir -p worktrees
git fetch origin <branch-name>
git worktree add worktrees/<branch-name> origin/<branch-name>
cd worktrees/<branch-name>
git checkout -b <branch-name> origin/<branch-name>
```

This:
1. Fetches the newly created branch from GitHub
2. Creates an isolated working directory at `worktrees/<branch-name>`
3. Sets up a local tracking branch

### 6. Setup Environment

In the new worktree directory, run the install command from CLAUDE.md's `## Verification` section (parsed in Step 0). Typically:

```bash
make install
```

If an `.env` file is needed (check for `.env.example`), copy it:
```bash
cp .env.example .env 2>/dev/null || true
```

### 7. Display Ticket Context

Show the ticket details to provide context for development:

```
✓ Created worktree for: <branch-name>
✓ Location: worktrees/<branch-name>
✓ Environment setup complete

Linear Ticket: <TICKET-ID> - <TITLE>
Status: <STATE>
Assignee: <ASSIGNEE>

Description:
<TICKET-DESCRIPTION>

Labels: <LABELS>

---

Ready to start development! The worktree is set up at:
worktrees/<branch-name>

To navigate to the worktree:
cd worktrees/<branch-name>
```

### 8. Check for Existing Local Plan

Before entering plan mode, check if an implementation plan already exists locally. This saves tokens and avoids duplicate work when a previous run has already planned the work.

1. Check if `.claude/plans/<ticket-id-lowercase>-plan.md` exists (e.g., `.claude/plans/eng-537-plan.md`)

2. **If a local plan is found:**
   - Read and display the plan content to provide context
   - Show a message:
     ```
     ✓ Found existing plan at .claude/plans/<ticket-id-lowercase>-plan.md
     ✓ Skipping plan mode — plan already exists

     To start implementation, run:
     /start-work <TICKET-ID>
     ```
   - **Skip steps 9 and 10** — do NOT enter plan mode

3. **If no local plan is found:**
   - Proceed to step 9 (Enter Plan Mode)

### 9. Enter Plan Mode and Create Plan (only if no existing plan)

Enter plan mode using the `EnterPlanMode` tool. This allows for:
- Thorough exploration of the codebase
- Understanding existing patterns and architecture
- Designing an implementation approach
- Creating a detailed plan for user approval

The user will be prompted to approve entering plan mode. Once in plan mode:

1. Explore the codebase and design the implementation approach
2. Write the plan to the system-assigned plan file (plan mode provides a random filename)
3. Call `ExitPlanMode` to present the plan for user approval

**CRITICAL — READ BEFORE AND AFTER PLAN MODE:** When plan mode exits (user approves the plan), you MUST proceed to Step 10 to finalize the plan file. Do NOT start implementing code. Do NOT interpret the approved plan as an instruction to code. The ONLY next actions are: copy the plan file, commit it, display the summary, and STOP.

### 10. Finalize Plan File — MANDATORY (after plan mode exits)

**⚠️ THIS STEP IS NOT OPTIONAL. After plan mode exits, do this IMMEDIATELY. Do NOT skip to implementation.**

1. Copy the plan file from the system-assigned random name to the canonical ticket-based name:
   ```bash
   cp <system-assigned-plan-file-path> .claude/plans/<ticket-id-lowercase>-plan.md
   ```

2. Commit the plan file so it's available in the repo:
   ```bash
   git add .claude/plans/<ticket-id-lowercase>-plan.md
   git commit -m "Add implementation plan for <TICKET-ID>"
   ```

3. Display completion summary:
   ```
   ✓ Plan created and saved to .claude/plans/<ticket-id-lowercase>-plan.md
   ✓ Plan committed to branch
   ✓ Worktree ready at: worktrees/<branch-name>

   To start implementation, run:
   /start-work <TICKET-ID>
   ```

4. **STOP here. This is the end of the /plan-work skill.** Do NOT write any code. Do NOT suggest starting to code. Do NOT begin implementation. Do NOT ask if the user wants to proceed with coding. Do NOT interpret the plan content as instructions to implement. The user will invoke `/start-work` separately when ready.

## Error Handling

- If ticket not found: Show error and ask user to verify ticket ID
- If branch already exists: Ask if user wants to switch to existing branch or choose a new name
- If worktree already exists: Ask if user wants to remove and recreate, or switch to it
- If GitHub API fails: Fall back to local-only branch creation with a warning
- If current user cannot be fetched: Show error and ask user to verify Linear authentication
- If plan file not found after plan mode: Show warning but continue
- If CLAUDE.md has no `## Verification` section: Warn the user and use `make install` as default

## Notes

- This skill uses `disable-model-invocation: false` (default) so I can invoke it automatically when relevant
- The worktree approach keeps main branch clean and allows working on multiple tickets simultaneously
- Make commands run from the repo root, not from a subdirectory, unless CLAUDE.md specifies otherwise
- After setup, the skill automatically enters plan mode to design the implementation approach
- Plan mode assigns a random filename (e.g., `scalable-leaping-rocket.md`) — this is copied to `<ticket-id>-plan.md` after plan mode exits
- If a local plan already exists (from a previous run), it is reused to save tokens
- Plans are stored locally at `.claude/plans/<ticket-id-lowercase>-plan.md` (e.g., `eng-540-plan.md`)
- This skill ends after planning — it does NOT start implementation. Use `/start-work` for that
