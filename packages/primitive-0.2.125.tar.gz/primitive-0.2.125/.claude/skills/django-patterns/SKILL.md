---
name: django-patterns
description: Production-grade Django architecture patterns for models, services, caching, and Strawberry GraphQL integration
allowed-tools: Read, Edit, Write, Grep, Glob, Bash
---

# Django Patterns

Production-grade Django patterns for Primitive Corp's backend. All API patterns use Strawberry GraphQL — no DRF.

## Usage

```
/django-patterns [topic]
```

Topics: models, services, caching, signals, queries, strawberry

## Project Structure

```
app/
├── models/           # Django models, managers, querysets
│   ├── __init__.py
│   └── user.py
├── services/         # Business logic (no Django imports ideally)
│   └── user_service.py
├── graphql/          # Strawberry types, queries, mutations
│   ├── types.py
│   ├── queries.py
│   └── mutations.py
├── tasks/            # Celery async tasks
│   └── user_tasks.py
├── tests/
│   ├── test_models.py
│   ├── test_services.py
│   └── test_graphql.py
└── migrations/
```

## Model Patterns

### Custom Manager & QuerySet

```python
class ActiveQuerySet(models.QuerySet):
    def active(self):
        return self.filter(is_active=True, deleted_at__isnull=True)

    def for_org(self, org_id: int):
        return self.filter(organization_id=org_id)


class ProjectManager(models.Manager):
    def get_queryset(self):
        return ActiveQuerySet(self.model, using=self._db)

    def active(self):
        return self.get_queryset().active()


class Project(models.Model):
    name = models.TextField()
    organization = models.ForeignKey("Organization", on_delete=models.CASCADE)
    is_active = models.BooleanField(default=True)
    deleted_at = models.DateTimeField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    objects = ProjectManager()

    class Meta:
        indexes = [
            models.Index(fields=["organization", "is_active"]),
            models.Index(fields=["created_at"]),
        ]
```

### Soft Delete Pattern

```python
class SoftDeleteMixin(models.Model):
    deleted_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        abstract = True

    def soft_delete(self):
        self.deleted_at = timezone.now()
        self.save(update_fields=["deleted_at"])
```

## Service Layer

Business logic lives in services, not models or resolvers:

```python
from django.db import transaction

class ProjectService:
    @staticmethod
    @transaction.atomic
    def create_project(*, org_id: int, name: str, created_by: int) -> Project:
        project = Project.objects.create(
            organization_id=org_id,
            name=name,
        )
        AuditLog.objects.create(
            action="project.created",
            actor_id=created_by,
            target=project,
        )
        return project

    @staticmethod
    def get_projects_for_org(org_id: int) -> QuerySet[Project]:
        return (
            Project.objects.active()
            .for_org(org_id)
            .select_related("organization")
            .order_by("-created_at")
        )
```

## Strawberry GraphQL Integration

### Types

```python
import strawberry
from strawberry import auto

@strawberry.django.type(Project)
class ProjectType:
    id: auto
    name: auto
    organization: "OrganizationType"
    created_at: auto
    updated_at: auto
```

### Queries

```python
@strawberry.type
class Query:
    @strawberry.field
    def projects(self, info) -> list[ProjectType]:
        org = info.context.request.user.organization
        return ProjectService.get_projects_for_org(org.id)
```

### Mutations — Always Return `{ node, messages }`

```python
@strawberry.type
class ProjectPayload:
    node: ProjectType | None = None
    messages: list[OperationMessage] = strawberry.field(default_factory=list)


@strawberry.type
class Mutation:
    @strawberry.mutation
    def create_project(self, info, name: str) -> ProjectPayload:
        user = info.context.request.user
        try:
            project = ProjectService.create_project(
                org_id=user.organization_id,
                name=name,
                created_by=user.id,
            )
            return ProjectPayload(node=project)
        except ValidationError as e:
            return ProjectPayload(
                messages=[OperationMessage(kind="error", message=str(e))]
            )
```

## Query Optimization

### Preventing N+1 Queries

```python
# BAD: N+1
projects = Project.objects.all()
for p in projects:
    print(p.organization.name)  # Hits DB each iteration

# GOOD: select_related for FK/OneToOne
projects = Project.objects.select_related("organization").all()

# GOOD: prefetch_related for M2M/reverse FK
projects = Project.objects.prefetch_related("tags", "members").all()
```

### Strawberry DataLoader

```python
from strawberry.dataloader import DataLoader

async def load_organizations(keys: list[int]) -> list[Organization]:
    orgs = Organization.objects.in_bulk(keys)
    return [orgs.get(key) for key in keys]

org_loader = DataLoader(load_fn=load_organizations)
```

## Caching

```python
from django.core.cache import cache

class ProjectService:
    CACHE_TTL = 300  # 5 minutes

    @staticmethod
    def get_project(project_id: int) -> Project | None:
        cache_key = f"project:{project_id}"
        project = cache.get(cache_key)
        if project is None:
            project = Project.objects.filter(id=project_id).first()
            if project:
                cache.set(cache_key, project, timeout=ProjectService.CACHE_TTL)
        return project

    @staticmethod
    def invalidate_project_cache(project_id: int):
        cache.delete(f"project:{project_id}")
```

## Signals — Use Sparingly

```python
from django.db.models.signals import post_save
from django.dispatch import receiver

@receiver(post_save, sender=Project)
def invalidate_project_cache(sender, instance, **kwargs):
    ProjectService.invalidate_project_cache(instance.id)
```

Prefer explicit service calls over signals for business logic. Signals are appropriate for cache invalidation and audit logging.

## Performance Checklist

- [ ] `select_related` for FK/OneToOne access in loops
- [ ] `prefetch_related` for M2M/reverse FK access
- [ ] `only()`/`defer()` to limit fetched fields on large models
- [ ] `bulk_create`/`bulk_update` for batch operations
- [ ] Database indexes on filter/order columns
- [ ] Cache frequently-read, rarely-changed data
