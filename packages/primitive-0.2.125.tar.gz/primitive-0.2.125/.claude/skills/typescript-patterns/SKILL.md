---
name: typescript-patterns
description: TypeScript development patterns — generics, utility types, discriminated unions, Zod, type guards, and async patterns
allowed-tools: Read, Edit, Write, Grep, Glob
---

# TypeScript Patterns

Idiomatic TypeScript patterns for Primitive Corp frontend projects.

## Usage

```
/typescript-patterns [topic]
```

Topics: generics, utility-types, unions, zod, guards, async, errors

## Generics

### Constrained Generics

```ts
function getProperty<T, K extends keyof T>(obj: T, key: K): T[K] {
  return obj[key]
}

// Generic with default
function createList<T = string>(items: T[]): { items: T[]; count: number } {
  return { items, count: items.length }
}
```

### Generic Components

```tsx
interface ListProps<T> {
  items: T[]
  renderItem: (item: T) => React.ReactNode
  keyExtractor: (item: T) => string
}

function List<T>({ items, renderItem, keyExtractor }: ListProps<T>) {
  return (
    <ul>
      {items.map((item) => (
        <li key={keyExtractor(item)}>{renderItem(item)}</li>
      ))}
    </ul>
  )
}

// Usage — T inferred from items
<List
  items={projects}
  renderItem={(p) => <span>{p.name}</span>}
  keyExtractor={(p) => p.id}
/>
```

### Generic Hooks

```ts
function useLocalStorage<T>(key: string, initialValue: T) {
  const [stored, setStored] = useState<T>(() => {
    const item = window.localStorage.getItem(key)
    return item ? (JSON.parse(item) as T) : initialValue
  })

  const setValue = (value: T | ((prev: T) => T)) => {
    const next = value instanceof Function ? value(stored) : value
    setStored(next)
    window.localStorage.setItem(key, JSON.stringify(next))
  }

  return [stored, setValue] as const
}
```

## Utility Types

### Built-in Utility Types

```ts
// Partial — all properties optional
type ProjectUpdate = Partial<Project>

// Pick — select specific properties
type ProjectSummary = Pick<Project, "id" | "name" | "status">

// Omit — exclude properties
type CreateProjectInput = Omit<Project, "id" | "createdAt" | "updatedAt">

// Record — typed object
type StatusCounts = Record<ProjectStatus, number>

// Extract / Exclude on unions
type ActiveStatus = Extract<ProjectStatus, "active" | "running">
type InactiveStatus = Exclude<ProjectStatus, "active" | "running">

// ReturnType — infer return type
type ServiceResult = ReturnType<typeof projectService.create>
```

### Mapped Types

```ts
// Make all properties readonly
type Immutable<T> = { readonly [K in keyof T]: T[K] }

// Make specific properties required
type RequireFields<T, K extends keyof T> = T & Required<Pick<T, K>>

type ProjectWithOrg = RequireFields<Project, "organizationId">
```

## Discriminated Unions

```ts
type ApiResponse<T> =
  | { status: "success"; data: T }
  | { status: "error"; error: string; code: number }
  | { status: "loading" }

function handleResponse<T>(response: ApiResponse<T>) {
  switch (response.status) {
    case "success":
      return response.data // TypeScript knows data exists
    case "error":
      throw new Error(response.error) // TypeScript knows error exists
    case "loading":
      return null
  }
}
```

### Component State with Discriminated Unions

```tsx
type ProjectState =
  | { status: "idle" }
  | { status: "loading" }
  | { status: "error"; error: Error }
  | { status: "success"; projects: Project[] }

function ProjectList() {
  const [state, setState] = useState<ProjectState>({ status: "idle" })

  switch (state.status) {
    case "loading":
      return <Skeleton />
    case "error":
      return <ErrorDisplay error={state.error} />
    case "success":
      return <List items={state.projects} />
    default:
      return null
  }
}
```

## Zod — Runtime Validation

### Schema Definition

```ts
import { z } from "zod"

const projectSchema = z.object({
  name: z.string().min(1, "Required").max(100),
  description: z.string().optional(),
  status: z.enum(["active", "paused", "archived"]),
  tags: z.array(z.string()).default([]),
})

// Infer TypeScript type from schema
type Project = z.infer<typeof projectSchema>
```

### Validate at Boundaries

```ts
// API response validation
const apiResponseSchema = z.object({
  data: z.object({
    projects: z.array(projectSchema),
  }),
})

async function fetchProjects(): Promise<Project[]> {
  const response = await fetch("/api/projects")
  const json = await response.json()
  const parsed = apiResponseSchema.parse(json)
  return parsed.data.projects
}

// Form validation (with react-hook-form)
const { register, handleSubmit } = useForm<Project>({
  resolver: zodResolver(projectSchema),
})

// Environment validation
const envSchema = z.object({
  NEXT_PUBLIC_API_URL: z.string().url(),
  NEXT_PUBLIC_SENTRY_DSN: z.string(),
})
```

## Type Guards

```ts
// User-defined type guard
function isProject(item: Project | Organization): item is Project {
  return "status" in item && "projectId" in item
}

// Narrowing with `in`
function getName(entity: Project | Organization) {
  if ("projectId" in entity) {
    return entity.name // TypeScript knows it's Project
  }
  return entity.orgName // TypeScript knows it's Organization
}

// Assertion function
function assertDefined<T>(value: T | undefined, message: string): asserts value is T {
  if (value === undefined) throw new Error(message)
}
```

## Async Patterns

### Typed Async Functions

```ts
async function fetchProject(id: string): Promise<Project> {
  const response = await fetch(`/api/projects/${id}`)
  if (!response.ok) throw new ApiError(response.status, await response.text())
  return projectSchema.parse(await response.json())
}
```

### Promise Utilities

```ts
// Parallel execution with typed results
const [projects, members] = await Promise.all([
  fetchProjects(orgId),
  fetchMembers(orgId),
])

// Race with timeout
async function withTimeout<T>(promise: Promise<T>, ms: number): Promise<T> {
  const timeout = new Promise<never>((_, reject) =>
    setTimeout(() => reject(new Error(`Timeout after ${ms}ms`)), ms)
  )
  return Promise.race([promise, timeout])
}
```

## Error Handling

```ts
// Custom error hierarchy
class AppError extends Error {
  constructor(message: string, public readonly code: string) {
    super(message)
    this.name = "AppError"
  }
}

class NotFoundError extends AppError {
  constructor(resource: string, id: string) {
    super(`${resource} ${id} not found`, "NOT_FOUND")
  }
}

class ApiError extends AppError {
  constructor(public readonly status: number, message: string) {
    super(message, `HTTP_${status}`)
  }
}
```

## Anti-Patterns to Avoid

| Anti-Pattern | Fix |
|---|---|
| `any` type | Use `unknown` and narrow, or define proper type |
| Type assertions `as Type` | Use type guards or Zod parsing |
| Non-null assertion `value!` | Check for null/undefined explicitly |
| `enum` keyword | Use `as const` objects or union types |
| `Function` type | Use specific signature: `(arg: string) => void` |
| Nested ternaries | Use `switch`, `if/else`, or discriminated union |
| `@ts-ignore` / `@ts-expect-error` | Fix the type error properly |
| `Object` / `{}` type | Use `Record<string, unknown>` or specific shape |
