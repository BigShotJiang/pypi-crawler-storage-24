---
name: nextjs-security
description: Next.js security best practices — authentication, middleware, CSP, environment variables, server actions, and API route protection
allowed-tools: Read, Edit, Write, Grep, Glob, Bash
---

# Next.js Security

Security patterns for Next.js App Router applications in the Primitive Corp frontend.

## Usage

```
/nextjs-security [topic]
```

Topics: auth, middleware, csp, env, server-actions, api-routes, headers

## Authentication — Middleware Guard

```tsx
// middleware.ts
import { NextResponse } from "next/server"
import type { NextRequest } from "next/server"

const PUBLIC_PATHS = ["/login", "/signup", "/forgot-password"]

export function middleware(request: NextRequest) {
  const { pathname } = request.nextUrl
  const token = request.cookies.get("session")?.value

  // Allow public paths
  if (PUBLIC_PATHS.some((p) => pathname.startsWith(p))) {
    return NextResponse.next()
  }

  // Redirect unauthenticated users
  if (!token) {
    const loginUrl = new URL("/login", request.url)
    loginUrl.searchParams.set("redirect", pathname)
    return NextResponse.redirect(loginUrl)
  }

  return NextResponse.next()
}

export const config = {
  matcher: ["/((?!api|_next/static|_next/image|favicon.ico|health).*)"],
}
```

## Environment Variables

### Never Expose Secrets to the Client

```bash
# .env.local
# Server-only — NOT prefixed with NEXT_PUBLIC_
DATABASE_URL="postgres://..."
SESSION_SECRET="..."
STRIPE_SECRET_KEY="..."

# Client-safe — prefixed with NEXT_PUBLIC_
NEXT_PUBLIC_APP_URL="https://app.primitive.tech"
NEXT_PUBLIC_SENTRY_DSN="..."
```

**Rule:** If a value is sensitive, it must NOT have the `NEXT_PUBLIC_` prefix. Access it only in server components, server actions, or API routes.

### Validate at Startup

```ts
// lib/env.ts
import { z } from "zod"

const envSchema = z.object({
  DATABASE_URL: z.string().url(),
  SESSION_SECRET: z.string().min(32),
  NEXT_PUBLIC_APP_URL: z.string().url(),
})

export const env = envSchema.parse(process.env)
```

## Content Security Policy

```tsx
// next.config.ts
const securityHeaders = [
  {
    key: "Content-Security-Policy",
    value: [
      "default-src 'self'",
      "script-src 'self' 'unsafe-inline' 'unsafe-eval'", // Tighten in production
      "style-src 'self' 'unsafe-inline'",
      "img-src 'self' data: blob: https:",
      "font-src 'self'",
      "connect-src 'self' https://api.primitive.tech",
      "frame-ancestors 'none'",
    ].join("; "),
  },
  { key: "X-Frame-Options", value: "DENY" },
  { key: "X-Content-Type-Options", value: "nosniff" },
  { key: "Referrer-Policy", value: "strict-origin-when-cross-origin" },
  { key: "Permissions-Policy", value: "camera=(), microphone=(), geolocation=()" },
]

export default {
  async headers() {
    return [{ source: "/(.*)", headers: securityHeaders }]
  },
}
```

## XSS Prevention

### Never Use `dangerouslySetInnerHTML`

```tsx
// BAD: XSS vector
<div dangerouslySetInnerHTML={{ __html: userInput }} />

// GOOD: Render as text (React auto-escapes)
<div>{userContent}</div>

// If HTML rendering is required: sanitize first
import DOMPurify from "isomorphic-dompurify"
<div dangerouslySetInnerHTML={{ __html: DOMPurify.sanitize(htmlContent) }} />
```

### Validate User Input

```tsx
import { z } from "zod"

const searchSchema = z.object({
  query: z.string().max(200).trim(),
  page: z.coerce.number().int().positive().default(1),
})

// In server action or API route
export async function searchProjects(formData: FormData) {
  const input = searchSchema.parse({
    query: formData.get("query"),
    page: formData.get("page"),
  })
  // Safe to use input.query
}
```

## Server Actions

```tsx
"use server"

import { auth } from "@/lib/auth"
import { z } from "zod"

const createProjectSchema = z.object({
  name: z.string().min(1).max(100),
})

export async function createProject(formData: FormData) {
  // Always verify authentication
  const session = await auth()
  if (!session) throw new Error("Unauthorized")

  // Always validate input
  const input = createProjectSchema.parse({
    name: formData.get("name"),
  })

  // Always scope to user's organization
  await db.project.create({
    data: { name: input.name, orgId: session.user.orgId },
  })
}
```

### Server Action Rules

- Always authenticate — never trust the client
- Always validate with Zod — `formData` is untrusted
- Always scope queries to the user's organization (prevent IDOR)
- Never expose internal IDs — use the session to determine access

## API Route Protection

```tsx
// app/api/webhooks/stripe/route.ts
import { headers } from "next/headers"
import Stripe from "stripe"

export async function POST(request: Request) {
  const body = await request.text()
  const sig = (await headers()).get("stripe-signature")

  // Verify webhook signature
  const event = stripe.webhooks.constructEvent(body, sig!, process.env.STRIPE_WEBHOOK_SECRET!)

  // Process verified event
  switch (event.type) {
    case "checkout.session.completed":
      // ...
      break
  }

  return Response.json({ received: true })
}
```

## CSRF Protection

GraphQL mutations through `handleMutation()` include CSRF tokens automatically. For custom forms:

```tsx
// Server action forms are CSRF-safe by default in Next.js
<form action={createProject}>
  <input name="name" />
  <button type="submit">Create</button>
</form>
```

For client-side `fetch` to API routes, include credentials:

```tsx
fetch("/api/endpoint", {
  method: "POST",
  credentials: "include",
  headers: { "Content-Type": "application/json" },
  body: JSON.stringify(data),
})
```

## File Upload Security

```tsx
const MAX_SIZE = 10 * 1024 * 1024 // 10MB
const ALLOWED_TYPES = ["image/jpeg", "image/png", "application/pdf"]

export async function uploadFile(formData: FormData) {
  const file = formData.get("file") as File
  if (!file) throw new Error("No file provided")

  if (file.size > MAX_SIZE) throw new Error("File too large (10MB max)")
  if (!ALLOWED_TYPES.includes(file.type)) throw new Error("Unsupported file type")

  // Use presigned URL — never write to local filesystem
  const url = await getPresignedUploadUrl(file.name, file.type)
  await fetch(url, { method: "PUT", body: file })
}
```

## Security Checklist

- [ ] Middleware redirects unauthenticated users from protected routes
- [ ] No sensitive values in `NEXT_PUBLIC_*` environment variables
- [ ] CSP headers configured in `next.config.ts`
- [ ] No `dangerouslySetInnerHTML` without DOMPurify
- [ ] All server actions authenticate and validate input with Zod
- [ ] All queries scoped to user's organization (no IDOR)
- [ ] API routes verify webhook signatures where applicable
- [ ] File uploads validated for type and size
- [ ] `X-Frame-Options: DENY` to prevent clickjacking
- [ ] `pnpm audit` runs clean for high/critical vulnerabilities
