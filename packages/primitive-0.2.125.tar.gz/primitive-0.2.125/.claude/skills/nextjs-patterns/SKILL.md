---
name: nextjs-patterns
description: Next.js App Router architecture — routing, server/client components, middleware, caching, and monorepo patterns
allowed-tools: Read, Edit, Write, Grep, Glob, Bash
---

# Next.js Patterns

Production-grade Next.js App Router patterns for Primitive Corp's frontend monorepo. Uses pnpm + Turborepo.

## Usage

```
/nextjs-patterns [topic]
```

Topics: routing, components, middleware, caching, monorepo, data-fetching

## Monorepo Structure

```
apps/
├── core/              # Main authenticated app
│   ├── app/
│   │   ├── (app)/     # Authenticated routes
│   │   │   ├── layout.tsx
│   │   │   ├── @breadcrumbs/   # Parallel route — mandatory
│   │   │   └── @modal/         # Parallel route — modals
│   │   └── (auth)/    # Public auth routes
│   ├── components/    # App-specific components
│   └── lib/           # App-specific utilities
├── auth/              # Auth app
├── www/               # Marketing site
└── docs/              # Documentation
packages/
├── sdk/               # GraphQL codegen + generated hooks
│   └── src/documents/ # *.graphql files (one per domain)
├── ui/                # Shared components (shadcn + Radix)
└── typescript-config/ # Shared tsconfig
```

## Routing — App Router

### Route Groups

```
app/
├── (app)/             # Authenticated — shared layout with sidebar, nav
│   ├── layout.tsx
│   ├── projects/
│   │   ├── page.tsx
│   │   └── [projectId]/
│   │       ├── page.tsx
│   │       └── @breadcrumbs/
│   │           └── page.tsx   # Required for every authenticated page
│   └── settings/
│       └── page.tsx
└── (auth)/            # Public — minimal layout
    ├── layout.tsx
    ├── login/
    │   └── page.tsx
    └── signup/
        └── page.tsx
```

### Parallel Routes

```tsx
// app/(app)/layout.tsx
export default function AppLayout({
  children,
  breadcrumbs,
  modal,
}: {
  children: React.ReactNode
  breadcrumbs: React.ReactNode
  modal: React.ReactNode
}) {
  return (
    <div>
      <nav>{breadcrumbs}</nav>
      <main>{children}</main>
      {modal}
    </div>
  )
}
```

Every authenticated `page.tsx` must have a matching `@breadcrumbs` page. Run `pnpm run check:breadcrumbs` to verify.

### Dynamic Routes

```tsx
// app/(app)/projects/[projectId]/page.tsx
export default async function ProjectPage({
  params,
}: {
  params: Promise<{ projectId: string }>
}) {
  const { projectId } = await params
  return <ProjectDetail id={projectId} />
}
```

## Server vs Client Components

### Server Components (default)

```tsx
// No "use client" directive — runs on server
async function ProjectList() {
  const projects = await getProjects()
  return (
    <ul>
      {projects.map((p) => (
        <li key={p.id}>{p.name}</li>
      ))}
    </ul>
  )
}
```

Use for: data fetching, static content, SEO-critical pages, accessing backend resources.

### Client Components

```tsx
"use client"

import { useState } from "react"

function ProjectFilter({ onFilter }: { onFilter: (q: string) => void }) {
  const [query, setQuery] = useState("")
  return (
    <input
      value={query}
      onChange={(e) => {
        setQuery(e.target.value)
        onFilter(e.target.value)
      }}
    />
  )
}
```

Use for: interactivity (`useState`, `useEffect`, event handlers), browser APIs, third-party client libs.

### Composition Pattern — Server Wrapping Client

```tsx
// Server component fetches data
async function ProjectPage() {
  const projects = await getProjects()
  // Pass serializable data to client component
  return <ProjectDashboard initialProjects={projects} />
}

// Client component handles interactivity
"use client"
function ProjectDashboard({ initialProjects }: { initialProjects: Project[] }) {
  const [filter, setFilter] = useState("")
  const filtered = initialProjects.filter((p) => p.name.includes(filter))
  return (/* ... */)
}
```

## Middleware

```tsx
// middleware.ts (root of app)
import { NextResponse } from "next/server"
import type { NextRequest } from "next/server"

export function middleware(request: NextRequest) {
  const token = request.cookies.get("session")

  // Redirect unauthenticated users
  if (!token && request.nextUrl.pathname.startsWith("/(app)")) {
    return NextResponse.redirect(new URL("/login", request.url))
  }

  return NextResponse.next()
}

export const config = {
  matcher: ["/((?!api|_next/static|_next/image|favicon.ico).*)"],
}
```

## Caching

### Route Segment Config

```tsx
// Static page — regenerate every 60s
export const revalidate = 60

// Dynamic page — no caching
export const dynamic = "force-dynamic"
```

### Data Cache with `fetch`

```tsx
// Cached for 5 minutes
const data = await fetch(url, { next: { revalidate: 300 } })

// On-demand revalidation
import { revalidateTag } from "next/cache"
revalidateTag("projects")
```

### TanStack Query (Client-Side)

```tsx
const { data } = useQuery({
  queryKey: ["projects", orgId],
  queryFn: () => fetchProjects(orgId),
  staleTime: 5 * 60 * 1000, // 5 minutes
})
```

## Shared Components — packages/ui

Components shared across apps live in `packages/ui`, built on shadcn + Radix UI:

```tsx
// packages/ui/src/components/button.tsx
import { Slot } from "@radix-ui/react-slot"
import { cva, type VariantProps } from "class-variance-authority"

const buttonVariants = cva("inline-flex items-center justify-center ...", {
  variants: {
    variant: { default: "...", destructive: "...", outline: "..." },
    size: { default: "h-10 px-4", sm: "h-9 px-3", lg: "h-11 px-8" },
  },
})

// Import in any app
import { Button } from "@primitive/ui/components/button"
```

Never duplicate shared components in individual apps.

## Performance Checklist

- [ ] Server components for data fetching, client components only for interactivity
- [ ] Every authenticated page has a matching `@breadcrumbs` route
- [ ] `dynamic` import for heavy client-only components (charts, editors)
- [ ] Images use `next/image` with width/height or `fill`
- [ ] TanStack Query with appropriate `staleTime` for server state
- [ ] Shared components in `packages/ui`, not duplicated across apps
- [ ] `loading.tsx` and `error.tsx` at route group boundaries
