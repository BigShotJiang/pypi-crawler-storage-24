---
name: api-design
description: GraphQL API design patterns for Strawberry — schema conventions, mutations, error handling, pagination
allowed-tools: Read, Edit, Write, Grep, Glob
---

# API Design

GraphQL API design patterns for Strawberry GraphQL. All Primitive Corp APIs use GraphQL — no REST.

## Usage

```
/api-design [topic]
```

Topics: schema, mutations, queries, pagination, errors, auth

## Schema Conventions

### Type Naming

```python
import strawberry

# Types match model names with "Type" suffix
@strawberry.django.type(Project)
class ProjectType:
    id: strawberry.ID
    name: str
    organization: "OrganizationType"
    created_at: datetime
    updated_at: datetime

# Input types use "Input" suffix
@strawberry.input
class CreateProjectInput:
    name: str
    description: str | None = None
```

### Query Structure

```python
@strawberry.type
class Query:
    @strawberry.field(permission_classes=[IsAuthenticated])
    def project(self, info, id: strawberry.ID) -> ProjectType | None:
        """Single resource lookup — org-scoped."""
        user = info.context.request.user
        return Project.objects.filter(
            id=id, organization=user.organization
        ).first()

    @strawberry.field(permission_classes=[IsAuthenticated])
    def projects(
        self, info, first: int = 20, after: str | None = None
    ) -> ProjectConnection:
        """List with cursor pagination — org-scoped."""
        user = info.context.request.user
        return get_project_connection(
            org_id=user.organization_id, first=first, after=after
        )
```

## Mutations — Always Return `{ node, messages }`

Every mutation returns a payload with `node` (the result) and `messages` (errors/warnings):

```python
@strawberry.type
class OperationMessage:
    kind: str  # "error", "warning", "info"
    message: str
    field: str | None = None

@strawberry.type
class ProjectPayload:
    node: ProjectType | None = None
    messages: list[OperationMessage] = strawberry.field(default_factory=list)

@strawberry.type
class Mutation:
    @strawberry.mutation(permission_classes=[IsAuthenticated])
    def create_project(self, info, input: CreateProjectInput) -> ProjectPayload:
        user = info.context.request.user
        try:
            project = ProjectService.create_project(
                org_id=user.organization_id,
                name=input.name,
                description=input.description,
                created_by=user.id,
            )
            return ProjectPayload(node=project)
        except ValidationError as e:
            return ProjectPayload(
                messages=[
                    OperationMessage(kind="error", message=str(e), field=e.field)
                    for e in e.errors
                ]
            )
```

### Mutation Rules

- Use input types for complex arguments
- Always return a payload type (not raw model)
- Wrap in `@transaction.atomic` for multi-step operations
- Business logic lives in services, not resolvers
- Validate permissions before executing

## Pagination — Relay-Style Cursor

```python
@strawberry.type
class PageInfo:
    has_next_page: bool
    end_cursor: str | None

@strawberry.type
class ProjectEdge:
    node: ProjectType
    cursor: str

@strawberry.type
class ProjectConnection:
    edges: list[ProjectEdge]
    page_info: PageInfo
    total_count: int
```

Use cursor-based pagination (not offset) for:
- Large datasets
- Real-time data where items can be added/removed
- Consistent performance regardless of page depth

## Error Handling

### Field-Level Errors

```python
# Validation errors return in messages, not as exceptions
ProjectPayload(
    messages=[OperationMessage(kind="error", message="Name already exists", field="name")]
)
```

### System Errors

```python
# Unexpected errors raise — let Strawberry handle them
# Don't catch Exception broadly in resolvers
```

### Permission Errors

```python
# Use permission classes — they return standard GraphQL errors
@strawberry.field(permission_classes=[IsAuthenticated, IsOrgAdmin])
def delete_project(self, info, id: strawberry.ID) -> ProjectPayload:
    ...
```

## DataLoader for N+1 Prevention

```python
from strawberry.dataloader import DataLoader

async def load_organizations(keys: list[int]) -> list[Organization]:
    orgs = await Organization.objects.in_bulk(keys)
    return [orgs.get(key) for key in keys]

# Register in context
class Context:
    def __init__(self, request):
        self.request = request
        self.org_loader = DataLoader(load_fn=load_organizations)
```

## Checklist

- [ ] All queries are org-scoped (no cross-org data leaks)
- [ ] All mutations return `{ node, messages }` payload
- [ ] Permission classes on every query and mutation
- [ ] Input types for complex mutation arguments
- [ ] Cursor pagination for list queries
- [ ] DataLoaders for related object fields
- [ ] Business logic in services, not resolvers
