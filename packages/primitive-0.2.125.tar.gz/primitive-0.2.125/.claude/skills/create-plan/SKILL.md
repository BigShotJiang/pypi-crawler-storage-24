---
name: create-plan
description: Check for an existing implementation plan, or enter plan mode to create one. Saves the plan to .claude/plans/ and commits it. Never implements code.
argument-hint: [ticket-id or ticket-url]
allowed-tools: Read, Write, Bash, EnterPlanMode
---

# Create Plan

**THIS SKILL IS PLANNING ONLY. IT MUST NEVER WRITE OR MODIFY APPLICATION CODE.**

Checks for an existing plan and creates one if needed. This is a composable sub-skill used by `/plan-work` and `/feature`.

## Usage

```
/create-plan <ticket-id>
/create-plan ENG-537
```

## Steps

### 1. Check for Existing Plan

Look for an existing plan at:
```
.claude/plans/<ticket-id-lowercase>-plan.md
```
Example: `.claude/plans/eng-537-plan.md`

**If a local plan is found:**
- Read and display the plan content
- Show:
  ```
  Found existing plan at .claude/plans/<ticket-id-lowercase>-plan.md
  Skipping plan mode -- plan already exists
  ```
- **STOP** — do not enter plan mode

**If no local plan is found:**
- Proceed to step 2

### 2. Enter Plan Mode

Enter plan mode using the `EnterPlanMode` tool. Once in plan mode:

1. Explore the codebase thoroughly
2. Understand existing patterns and architecture
3. Design the implementation approach
4. Write a detailed plan to the system-assigned plan file
5. Call `ExitPlanMode` to present the plan for user approval

### 3. Finalize Plan File

**After plan mode exits (user approves the plan), do this IMMEDIATELY:**

1. Copy the plan file from the system-assigned random name to the canonical path:
   ```bash
   cp <system-assigned-plan-file-path> .claude/plans/<ticket-id-lowercase>-plan.md
   ```

2. Commit the plan file:
   ```bash
   git add .claude/plans/<ticket-id-lowercase>-plan.md
   git commit -m "Add implementation plan for <TICKET-ID>"
   ```

3. Display:
   ```
   Plan created and saved to .claude/plans/<ticket-id-lowercase>-plan.md
   Plan committed to branch
   ```

4. **STOP here.** Do NOT write any code. Do NOT start implementation. Do NOT interpret the plan as instructions to code.

## Notes

- Plan mode assigns a random filename (e.g., `scalable-leaping-rocket.md`) — this is copied to `<ticket-id>-plan.md` after approval
- Plans are stored locally at `.claude/plans/<ticket-id-lowercase>-plan.md`
- This skill ends after planning — it does NOT start implementation

## Error Handling

- **Plan file not found after plan mode**: Show warning but continue
