---
name: search-first
description: Research-before-coding workflow — search for existing solutions, libraries, and patterns before writing new code
allowed-tools: Read, Bash, Grep, Glob, Agent
---

# Search First

Before writing new code, search for existing solutions. Most problems have been solved before.

## Usage

```
/search-first [what-you-need]
```

## Decision Matrix

Before implementing anything, answer these questions:

| Question | If YES | If NO |
|----------|--------|-------|
| Does this exist in the codebase already? | Reuse it | Continue |
| Is there a well-maintained library for this? | Install it | Continue |
| Is there an open-source implementation to adapt? | Fork/port it | Continue |
| Is this a known pattern with best practices? | Follow the pattern | Write from scratch |

Only write new code when all four answers are NO.

## Search Order

### 1. Search the Codebase

```bash
# Find existing implementations
grep -rn "class.*Service" --include="*.py" .
grep -rn "function.*fetch" --include="*.ts" .

# Find similar patterns
grep -rn "def.*calculate" --include="*.py" .
```

### 2. Search Package Registries

```bash
# Python
pip search <keyword>      # or search pypi.org
pip show <package>        # check if already installed

# Node.js
npm search <keyword>
npm ls <package>          # check if already installed
```

Prefer battle-tested libraries with:
- Active maintenance (commits in last 6 months)
- Good test coverage
- No known CVEs
- Reasonable dependency footprint

### 3. Search for Patterns

Look for established patterns in:
- Project's own codebase (how was this done before?)
- Framework documentation (Django, Next.js, Strawberry)
- Language standard library (often has what you need)

## When to Write From Scratch

- The requirement is truly unique to your domain
- Existing solutions are abandoned or insecure
- The library would be much heavier than a simple implementation
- You need tight integration with existing project patterns

## Anti-Patterns

- **Not Invented Here**: Rejecting good libraries because "we can write it better"
- **Dependency Bloat**: Adding a library for something the stdlib already does
- **Blind Copy-Paste**: Copying code without understanding it
- **Outdated Solutions**: Using deprecated patterns when modern alternatives exist

## Integration with Other Skills

After finding a solution:
- `/django-patterns` — adapt to project's Django conventions
- `/frontend-patterns` — adapt to project's React/Next.js conventions
- `/tdd-workflow` — write tests for adopted code
- `/security-review` — audit third-party code before integrating
