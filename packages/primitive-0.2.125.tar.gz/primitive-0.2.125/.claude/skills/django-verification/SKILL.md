---
name: django-verification
description: Pre-PR verification pipeline for Django projects — format, lint, type-check, test, security scan, migration check
allowed-tools: Read, Bash, Grep, Glob
---

# Django Verification

Comprehensive verification pipeline to run before opening a PR on a Django project.

## Usage

```
/django-verification [quick|full]
```

- `quick` — format + lint + type-check only
- `full` (default) — all phases

## Steps

### 1. Code Quality & Formatting

```bash
# Format check
ruff format --check .

# Lint
ruff check .

# Type check
mypy .

# Django system check
python manage.py check --deploy
```

Fix any failures before proceeding. Use `ruff format .` and `ruff check --fix .` for auto-fixable issues.

### 2. Migration Check

```bash
# Check for unapplied migrations
python manage.py migrate --check

# Check for missing migrations
python manage.py makemigrations --check --dry-run
```

If migrations are missing, create them and include in the PR.

### 3. Tests & Coverage

```bash
# Run tests with coverage
ENVIRONMENT=test pytest --cov=app --cov-report=term-missing -q

# Check coverage threshold
pytest --cov=app --cov-fail-under=80
```

All tests must pass. Coverage must be 80%+ on new code.

### 4. Security Scan

```bash
# Dependency vulnerabilities
pip-audit

# Static security analysis
bandit -r app/ -q

# Check for hardcoded secrets
ruff check --select S105,S106,S107 .
```

Address all HIGH/CRITICAL findings before merge.

### 5. Final Diff Review

```bash
# Review what will be in the PR
git diff main...HEAD --stat
git diff main...HEAD -- '*.py'
```

Check for:
- Unintended file changes
- Debug code (`print()`, `breakpoint()`, `import pdb`)
- Commented-out code
- Missing test coverage for new code paths

## Output Format

```
## Verification Results

| Check | Status |
|-------|--------|
| Format (ruff) | PASS/FAIL |
| Lint (ruff) | PASS/FAIL |
| Types (mypy) | PASS/FAIL |
| Django check | PASS/FAIL |
| Migrations | PASS/FAIL |
| Tests | PASS (N passed) / FAIL |
| Coverage | XX% (target: 80%) |
| Security (bandit) | PASS/FAIL |
| Deps (pip-audit) | PASS/FAIL |

Ready for PR: YES / NO
```

## Error Handling

If any phase fails:
1. Report the specific failure with error details
2. Attempt auto-fix for formatting/lint issues
3. Re-run the failed check
4. If still failing, report and stop — do not proceed to PR
