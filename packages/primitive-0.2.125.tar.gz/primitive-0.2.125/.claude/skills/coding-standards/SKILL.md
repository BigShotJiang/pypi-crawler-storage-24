---
name: coding-standards
description: Universal coding standards — KISS, DRY, YAGNI, code smell detection, and quality principles
allowed-tools: Read, Edit, Write, Grep, Glob
---

# Coding Standards

Universal code quality principles and smell detection.

## Usage

```
/coding-standards [check|fix]
```

- `check` — analyze code for violations
- `fix` — apply fixes for detected issues

## Core Principles

### KISS — Keep It Simple
- Prefer the simplest solution that works
- If a junior developer can't understand it in 5 minutes, simplify it
- Avoid clever one-liners that sacrifice readability

### DRY — Don't Repeat Yourself
- Extract shared logic only when duplicated 3+ times
- Don't DRY too early — two similar blocks may diverge later
- Prefer duplication over the wrong abstraction

### YAGNI — You Aren't Gonna Need It
- Don't build for hypothetical future requirements
- Don't add configuration for things that only have one value
- Don't create abstractions before you have 3+ concrete uses

## Code Smells

### File-Level
- **Large file** (>800 lines) — split by responsibility
- **Mixed concerns** — UI rendering mixed with business logic
- **Circular dependencies** — restructure module boundaries

### Function-Level
- **Long function** (>50 lines) — extract sub-functions
- **Too many parameters** (>5) — use a config object/dataclass
- **Deep nesting** (>4 levels) — use early returns, extract helpers
- **Flag arguments** — split into separate functions

### Code-Level
- **Magic numbers** — extract named constants
- **Dead code** — remove commented-out code and unused functions
- **Inconsistent naming** — follow project conventions
- **Copy-paste duplication** — extract shared function (if 3+ occurrences)

## Quality Checklist

Before marking work complete:

- [ ] Functions are small (<50 lines) and do one thing
- [ ] Files are focused (<800 lines) on one responsibility
- [ ] No deep nesting (>4 levels)
- [ ] No magic numbers — named constants used
- [ ] No dead code — commented-out code removed
- [ ] Error handling is explicit (no silent swallowing)
- [ ] No hardcoded values — use config or environment variables
- [ ] Tests cover new behavior

## Detection Commands

```bash
# Python
ruff check .                    # Lint
vulture .                       # Dead code

# TypeScript
npx eslint .                    # Lint
npx knip                        # Dead code/exports
```

## When to Refactor

**Do refactor** when:
- Adding a feature requires changing the same code in 3+ places
- A function/file has grown beyond readability
- Tests are hard to write because of tight coupling

**Don't refactor** when:
- You're "just cleaning up" during a feature PR (separate PR)
- The code works and isn't being changed
- You don't have test coverage to verify the refactor
