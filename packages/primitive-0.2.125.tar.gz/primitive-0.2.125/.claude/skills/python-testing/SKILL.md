---
name: python-testing
description: Python testing patterns — pytest fixtures, parametrize, mocking, async testing
allowed-tools: Read, Edit, Write, Bash, Grep, Glob
---

# Python Testing

Comprehensive pytest patterns for Python projects.

## Usage

```
/python-testing [topic]
```

Topics: fixtures, parametrize, mocking, async, organization

## Pytest Fundamentals

```python
# Basic test structure
def test_calculate_total():
    items = [Item(price=10), Item(price=20)]
    assert calculate_total(items) == 30

# Testing exceptions
def test_division_by_zero():
    with pytest.raises(ZeroDivisionError, match="division by zero"):
        divide(10, 0)
```

## Fixtures

```python
@pytest.fixture
def sample_user(db):
    return UserFactory(username="testuser")

@pytest.fixture
def api_client(sample_user):
    client = APIClient()
    client.force_login(sample_user)
    return client

# Fixture with teardown
@pytest.fixture
def temp_file(tmp_path):
    path = tmp_path / "test.txt"
    path.write_text("test content")
    yield path
    # Cleanup happens automatically via tmp_path

# Scoped fixtures
@pytest.fixture(scope="session")
def db_engine():
    engine = create_engine("sqlite:///:memory:")
    yield engine
    engine.dispose()
```

### conftest.py

Place shared fixtures in `conftest.py` at the appropriate directory level:
```
tests/
├── conftest.py          # Shared across all tests
├── unit/
│   ├── conftest.py      # Unit test fixtures
│   └── test_service.py
└── integration/
    ├── conftest.py      # Integration test fixtures
    └── test_api.py
```

## Parametrize

```python
@pytest.mark.parametrize("input_val,expected", [
    ("hello", "HELLO"),
    ("", ""),
    ("Hello World", "HELLO WORLD"),
])
def test_uppercase(input_val, expected):
    assert uppercase(input_val) == expected

# Multiple parameters with IDs
@pytest.mark.parametrize("status,should_retry", [
    (429, True),
    (500, True),
    (503, True),
    (400, False),
    (404, False),
], ids=["rate-limit", "server-error", "unavailable", "bad-request", "not-found"])
def test_should_retry(status, should_retry):
    assert is_retryable(status) == should_retry
```

## Mocking

```python
from unittest.mock import patch, MagicMock, AsyncMock

# Patch a function
def test_send_notification(mocker):
    mock_send = mocker.patch("app.services.email.send_email")
    NotificationService.notify_user(user_id=1, message="hello")
    mock_send.assert_called_once_with(
        to="user@example.com", subject="Notification", body="hello"
    )

# Mock return values
def test_external_api(mocker):
    mocker.patch(
        "app.clients.external.fetch_data",
        return_value={"status": "ok", "data": [1, 2, 3]},
    )
    result = process_external_data()
    assert result == [1, 2, 3]

# Mock exceptions
def test_api_failure(mocker):
    mocker.patch(
        "app.clients.external.fetch_data",
        side_effect=ConnectionError("timeout"),
    )
    with pytest.raises(ServiceError, match="External API unavailable"):
        process_external_data()
```

## Async Testing

```python
import pytest

@pytest.mark.asyncio
async def test_async_fetch():
    result = await fetch_user_data(user_id=1)
    assert result["name"] == "Test User"

# Async fixture
@pytest.fixture
async def async_client():
    async with AsyncClient(app=app, base_url="http://test") as client:
        yield client

# Mock async functions
def test_async_operation(mocker):
    mocker.patch(
        "app.services.async_fetch",
        new_callable=AsyncMock,
        return_value={"status": "ok"},
    )
```

## Test Organization

```
tests/
├── conftest.py
├── factories.py           # All factory_boy factories
├── unit/
│   ├── test_models.py
│   └── test_services.py
├── integration/
│   ├── test_api.py
│   └── test_graphql.py
└── e2e/
    └── test_workflows.py
```

## Best Practices

**DO:**
- Test behavior, not implementation
- Use factories for test data (`factory_boy`)
- Keep tests independent — no shared mutable state
- Use descriptive names: `test_user_cannot_access_other_org`
- Use `freezegun`/`time_machine` for time-dependent tests

**DON'T:**
- Hardcode IDs, timestamps, or magic values
- Use `unittest.TestCase` (use plain functions + fixtures)
- Test private methods directly
- Mock everything — integration tests should hit the DB
- Use `sleep()` in tests — use proper async patterns

## Running Tests

```bash
# All tests
pytest

# Specific markers
pytest -m unit
pytest -m "not slow"

# With coverage
pytest --cov=app --cov-report=term-missing

# Verbose on failure
pytest -x --tb=short
```
