---
name: start-work
description: Complete automated workflow from Linear ticket to reviewed PR - requires an existing plan (from /plan-work), implements changes, writes tests, conducts critical self-review, commits improvements, opens PR, requests Copilot review, waits for review, addresses all feedback, resolves GitHub threads, and updates PR. Use when a plan already exists and you want full automation from implementation to PR.
argument-hint: [ticket-id or ticket-url] [--skip-review-wait]
allowed-tools: Read, Write, Edit, Bash, Glob, Grep, AskUserQuestion, mcp__linear-server__get_issue, mcp__linear-server__get_user, mcp__linear-server__update_issue
allowed-prompts:
  - tool: Bash
    prompt: run tests
  - tool: Bash
    prompt: format code
  - tool: Bash
    prompt: lint code
  - tool: Bash
    prompt: install dependencies
  - tool: Bash
    prompt: git operations
  - tool: Bash
    prompt: create pull request
  - tool: Bash
    prompt: install gh extensions
  - tool: Bash
    prompt: check review status
  - tool: Bash
    prompt: retrieve review comments
  - tool: Bash
    prompt: resolve review threads
---

# Start Work - Complete Automated Workflow

This skill provides end-to-end automation from an existing implementation plan to a reviewed Pull Request. It **requires** that `/plan-work` has already been run for the ticket — if no plan exists, it will stop and prompt the user to run `/plan-work` first.

## What This Skill Does

1. **Setup Phase** (from plan-work): fetch ticket, assign, create branch, create worktree, setup environment
2. **Plan Loading Phase**: load existing plan or stop and prompt `/plan-work`
3. **Implementation Phase**: execute plan, write code and tests
4. **Verification Phase**: run format, lint, test using commands from CLAUDE.md `## Verification`
5. **Self-Review Phase**: critically review own implementation, make improvements, re-verify, commit
6. **Submission Phase**: push, create PR, request Copilot review
7. **Review Monitoring Phase**: poll for Copilot review, retrieve comments
8. **Address Feedback Phase**: implement fixes, re-verify
9. **Update PR Phase**: commit fixes, push, resolve threads

## Usage

```bash
/start-work <ticket-id>
/start-work ENG-537
/start-work https://linear.app/primitive/issue/ENG-537
/start-work ENG-537 --skip-review-wait  # Create PR and request review but don't wait for it
```

**Prerequisite**: A plan must already exist for this ticket. Run `/plan-work <ticket-id>` first to create one.

---

## Detailed Workflow

### Phase 0: Read Verification Commands

Before any other work, read this project's `CLAUDE.md` and find the `## Verification` section.
Parse the format, lint, and test commands from it.

Expected format:
```markdown
## Verification
- Format: make format
- Lint: make lint
- Test: ENVIRONMENT=test uv run pytest
```

Store these as `FORMAT_CMD`, `LINT_CMD`, and `TEST_CMD`. Use them in every verification step throughout this skill (Phases 4, 5, and 8).

If the section is missing, warn the user and ask them to add it to CLAUDE.md before continuing.

### Phase 1: Setup (from plan-work)

#### 1.1 Parse and Fetch Ticket

Extract ticket ID from argument (handle both plain IDs and full Linear URLs).

Use Linear MCP server to fetch ticket details: title, description, state, labels.

#### 1.2 Auto-Assign Ticket

- Get current user: `mcp__linear-server__get_user` with "me"
- Update ticket: `mcp__linear-server__update_issue` with assigneeId

#### 1.3 Create Branch Name

Follow Linear GitHub naming convention:
```
<username>/eng-<ticket-number>-<description>
```
Example: `dylan/eng-537-adds-global-projects`

#### 1.4 Create GitHub Branch

```bash
# Get main branch SHA
gh api repos/{owner}/{repo}/git/refs/heads/main

# Create new branch
gh api repos/{owner}/{repo}/git/refs \
  -f ref='refs/heads/<branch-name>' \
  -f sha='<main-sha>'
```

#### 1.5 Create Git Worktree

```bash
mkdir -p worktrees
git fetch origin <branch-name>:<branch-name>
git worktree add worktrees/<branch-name> <branch-name>
```

#### 1.6 Setup Environment

In the worktree directory, run the install command from CLAUDE.md `## Verification` (or `make install` if not specified).

#### 1.7 Display Ticket Context

```
✓ Created worktree: worktrees/<branch-name>
✓ Environment setup complete

Linear Ticket: <TICKET-ID> - <TITLE>
Status: <STATE>
Assignee: <ASSIGNEE>

Description:
<TICKET-DESCRIPTION>

Labels: <LABELS>
```

### Phase 2: Load Existing Plan

The plan file lives inside the worktree:
```
worktrees/<branch-name>/.claude/plans/<ticket-id-lowercase>-plan.md
```

**If found**: Read and display the plan. Proceed to Phase 3.

**If not found**: Stop and display:
```
✗ No implementation plan found for <TICKET-ID>

Please run /plan-work <TICKET-ID> first to create an implementation plan,
then re-run /start-work <TICKET-ID>.
```

Do not proceed without a plan.

### Phase 3: Implementation

#### 3.1 Implement Core Changes

Follow the plan to make code changes:
- Use `Edit` tool to modify existing files
- Use `Write` tool to create new files
- Follow existing code patterns and conventions
- Read files before editing them
- Don't over-engineer — keep solutions simple

#### 3.2 Write Comprehensive Tests

Create tests following project conventions:
- Place tests in the appropriate `tests/` directory
- Use existing factories and fixtures
- Cover happy path, edge cases, and error conditions
- Follow test naming convention in the codebase

### Phase 4: Verification

Run commands from CLAUDE.md `## Verification` (parsed in Phase 0):

#### 4.1 Run Tests
```bash
<TEST_CMD>
```

If tests fail: fix the underlying issue and re-run. Do not patch tests to force them to pass.

#### 4.2 Format Code
```bash
<FORMAT_CMD>
```

#### 4.3 Lint Code
```bash
<LINT_CMD>
```

Fix any lint errors. Re-run until all pass.

#### 4.4 Verify All Pass

Ensure:
- ✅ All tests pass
- ✅ No lint errors
- ✅ Code is properly formatted

### Phase 5: Self-Review

Before submitting, conduct a thorough self-review to catch issues early.

#### 5.1 Review Checklist

**Security & Safety**
- [ ] Input validation on all user-facing APIs
- [ ] SQL injection prevention (parameterized queries / ORM)
- [ ] Authentication/authorization checks on every protected resource
- [ ] No hardcoded secrets or credentials

**Error Handling**
- [ ] External calls have proper error handling
- [ ] Graceful degradation when services fail
- [ ] No bare `except` clauses

**Data Integrity**
- [ ] Transactions used for multi-step writes
- [ ] Race conditions prevented (atomic operations, locking)
- [ ] Null/None checks before attribute access

**Performance**
- [ ] No N+1 query problems
- [ ] Appropriate caching with invalidation
- [ ] Pagination on list endpoints

**Code Quality**
- [ ] No duplicate code
- [ ] Functions are focused and single-purpose
- [ ] No debugging code left (print statements, commented-out code)

**Testing**
- [ ] All new code paths covered by tests
- [ ] Error conditions tested
- [ ] Test names clearly describe what they test

#### 5.2 Read and Review Changed Files

```bash
git diff --name-only HEAD
```

For each changed file: read it, check against the checklist, identify issues.

#### 5.3 Implement Improvements

For each finding (critical first), make the change, then update tests if needed.

#### 5.4 Re-run Full Verification

```bash
<TEST_CMD>
<FORMAT_CMD>
<LINT_CMD>
```

#### 5.5 Commit

```bash
git add <files>
git commit -m "$(cat <<'EOF'
<Feature summary>

<Description>

Key changes:
- <Change 1>
- <Change 2>

Self-review improvements:
- <Improvement 1>
- <Improvement 2>

Co-Authored-By: Claude Sonnet 4.6 <noreply@anthropic.com>
EOF
)"
```

#### 5.6 Self-Review Summary

```
✅ Self-Review Complete!

Findings:
- Critical issues: <n> (all fixed)
- Important improvements: <n> (all fixed)
- Nice-to-have: <n> (fixed <n>)

Verification:
- All tests passing: ✅
- Code formatted: ✅
- No lint errors: ✅

📝 Committed: <commit-sha>
```

### Phase 6: Submission

#### 6.1 Push Changes

```bash
git push
# or first push:
git push -u origin <branch-name>
```

#### 6.2 Create Pull Request

```bash
gh pr create \
  --title "<Feature Summary> (<TICKET-ID>)" \
  --body "$(cat <<'EOF'
## Summary
<High-level overview>

## Changes

### Core Implementation
<List main changes>

### Testing
<Describe test coverage>

## Test Results
All tests passing ✅

## Expected Impact
- <Benefit 1>
- <Benefit 2>

## Rollback Plan
<How to revert>

🤖 Generated with [Claude Code](https://claude.com/claude-code)
EOF
)" \
  --base main
```

#### 6.3 Request Copilot Review

```bash
gh extension list | grep copilot-review || gh extension install ChrisCarini/gh-copilot-review
gh copilot-review <pr-number>
```

#### 6.4 Success Message

```
✅ PR Created!

📝 Commit: <commit-sha>
🔀 PR #<number>: <pr-url>
🤖 Copilot review requested

⏳ Waiting for Copilot to complete review...
```

### Phase 7: Review Monitoring

#### 7.1 Install gh-pr-review Extension

```bash
gh extension list | grep pr-review || gh extension install agynio/gh-pr-review
```

#### 7.2 Poll for Review Completion

Check every 5 seconds (max 2 minutes):
```bash
gh api repos/{owner}/{repo}/pulls/<pr-number>/reviews \
  --jq '.[] | select(.user.login == "copilot") | {state: .state, submitted_at: .submitted_at}'
```

If `--skip-review-wait` was passed, skip polling and return.

#### 7.3 Retrieve Comments

```bash
gh pr-review review view --pr <pr-number> --reviewer copilot --not-outdated
```

#### 7.4 Display Review Summary

```
✅ Copilot Review Complete!

Review State: <state>
Total Comments: <n>

Key Feedback:
- <file>:<line> - <summary>
...
```

### Phase 8: Address Copilot Feedback

For each comment (critical first):
1. Read the file at the referenced location
2. Understand Copilot's concern
3. Make the fix with `Edit`
4. Update tests if needed
5. Track the thread_id

After all fixes, re-run verification:
```bash
<TEST_CMD>
<FORMAT_CMD>
<LINT_CMD>
```

### Phase 9: Update PR

#### 9.1 Commit Feedback Fixes

```bash
git add <files>
git commit -m "$(cat <<'EOF'
Address Copilot review feedback

- <Change 1>
- <Change 2>

Co-Authored-By: Claude Sonnet 4.6 <noreply@anthropic.com>
EOF
)"
```

#### 9.2 Push

```bash
git push
```

#### 9.3 Resolve Threads

```bash
gh pr-review threads resolve --thread-id <thread-id>
```

Only resolve threads where the feedback was fully implemented.

#### 9.4 Final Summary

```
✅ Work Complete with Self-Review and Copilot Feedback Addressed!

📝 Commit: <commit-sha-1>
📝 Feedback Commit: <commit-sha-2>
🔀 PR #<number>: <pr-url>

Self-Review:
- Issues found and fixed: <n>
- Final test count: ✅

Copilot Review:
- Comments: <n>
- Comments addressed: <n>
- Threads resolved: <n>

The PR is ready for human review!
```

---

## Error Handling

- **No plan found**: Stop and prompt user to run `/plan-work` first
- **Tests fail**: Debug and fix the underlying issue; never skip or patch tests
- **Lint errors**: Fix manually; re-run lint until clean
- **Commit fails**: Check pre-commit hooks and fix issues
- **Push fails**: Check remote access and branch permissions
- **PR creation fails**: Show the `gh pr create` command for manual creation
- **Copilot review timeout**: Warn user after 2 minutes; ask whether to continue waiting
- **Thread resolution fails**: Continue; threads can be resolved manually in the GitHub UI
- **CLAUDE.md missing `## Verification`**: Stop and ask user to add the section before continuing

## Comparison to plan-work

| Feature                 | plan-work | start-work |
| ----------------------- | --------- | ---------- |
| Setup worktree          | ✅        | ✅         |
| Create/load plan        | ✅        | Load only  |
| Enter plan mode         | ✅        | ❌         |
| Implement changes       | ❌        | ✅         |
| Write tests             | ❌        | ✅         |
| Run tests               | ❌        | ✅         |
| Format/lint             | ❌        | ✅         |
| Commit changes          | ❌        | ✅         |
| Create PR               | ❌        | ✅         |
| Request Copilot review  | ❌        | ✅         |
| Wait for review         | ❌        | ✅         |
| Address review feedback | ❌        | ✅         |
| Update PR with fixes    | ❌        | ✅         |
| Resolve review threads  | ❌        | ✅         |

**Intended workflow**: Run `/plan-work` first to set up the worktree and create/approve a plan, then run `/start-work` to implement, test, and submit.
