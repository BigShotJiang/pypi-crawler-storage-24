---
name: address-review
description: Poll for Copilot review completion, retrieve comments, implement fixes, re-verify, commit, push, and resolve threads.
argument-hint: [pr-number] [--skip-review-wait]
allowed-tools: Read, Edit, Bash, Glob, Grep
---

# Address Review

Waits for Copilot review, retrieves feedback, implements fixes, and resolves threads. This is a composable sub-skill used by `/start-work` and `/feature`.

## Usage

```
/address-review <pr-number>
/address-review 42
/address-review 42 --skip-review-wait
```

## Steps

### 1. Poll for Review Completion

Check every 5 seconds (max 2 minutes):
```bash
gh api repos/{owner}/{repo}/pulls/<pr-number>/reviews \
  --jq '.[] | select(.user.login == "copilot-pull-request-reviewer[bot]") | {state: .state, submitted_at: .submitted_at}'
```

If `--skip-review-wait` was passed, skip polling and return immediately.

If review times out after 2 minutes, warn user and ask whether to continue waiting.

### 2. Retrieve Comments

```bash
# Get inline review comments
gh api repos/{owner}/{repo}/pulls/<pr-number>/comments \
  --jq '.[] | select(.user.login == "copilot-pull-request-reviewer[bot]")'

# Get top-level review body
gh api repos/{owner}/{repo}/pulls/<pr-number>/reviews \
  --jq '.[] | select(.user.login == "copilot-pull-request-reviewer[bot]")'
```

### 3. Display Review Summary

```
Copilot Review Complete!

Review State: <state>
Total Comments: <n>

Key Feedback:
- <file>:<line> - <summary>
...
```

### 4. Address Each Comment

For each comment (critical first):
1. Read the file at the referenced location
2. Understand Copilot's concern
3. Make the fix with `Edit`
4. Update tests if needed
5. Track the thread_id for resolution

### 5. Re-verify

Read CLAUDE.md `## Verification` and run all verification commands:
```bash
<FORMAT_CMD>
<LINT_CMD>
<TEST_CMD>
```

### 6. Commit and Push

```bash
git add <files>
git commit -m "$(cat <<'EOF'
Address Copilot review feedback

- <Change 1>
- <Change 2>

Co-Authored-By: Claude Sonnet 4.6 <noreply@anthropic.com>
EOF
)"
git push
```

### 7. Resolve Threads

For each addressed comment, reply via the API:
```bash
gh api repos/{owner}/{repo}/pulls/<pr-number>/comments/<comment-id>/replies \
  -f body="Addressed in <commit-sha>"
```

Only resolve threads where the feedback was fully implemented.

### 8. Final Summary

```
Review Feedback Addressed!

Comments: <n>
Comments addressed: <n>
Threads resolved: <n>

Feedback Commit: <commit-sha>
```

## Error Handling

- **Review timeout**: Warn user after 2 minutes, ask whether to continue waiting
- **Thread resolution fails**: Continue; threads can be resolved manually in GitHub UI
