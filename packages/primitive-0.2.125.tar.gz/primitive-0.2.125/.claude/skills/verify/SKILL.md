---
name: verify
description: Run format, lint, and test commands from CLAUDE.md's Verification section. Fix any failures and re-run until all pass.
allowed-tools: Read, Bash
---

# Verify

Runs the project's format, lint, and test commands. Fixes failures and re-runs until all pass. This is a composable sub-skill used by `/start-work` and `/feature`.

No arguments needed — reads commands from `CLAUDE.md`.

## Usage

```
/verify
```

## Steps

### 1. Read Verification Commands

Read this project's `CLAUDE.md` and find the `## Verification` section. Parse:
- `FORMAT_CMD` (e.g., `make format`)
- `LINT_CMD` (e.g., `make lint`)
- `TEST_CMD` (e.g., `ENVIRONMENT=test uv run pytest`)

If the section is missing, stop and ask user to add it to CLAUDE.md.

### 2. Run Format

```bash
<FORMAT_CMD>
```

### 3. Run Lint

```bash
<LINT_CMD>
```

Fix any lint errors. Re-run until clean.

### 4. Run Tests

```bash
<TEST_CMD>
```

If tests fail: fix the underlying issue and re-run. Do not patch tests to force them to pass.

### 5. Report Status

```
Verification:
- Code formatted: [pass/fail]
- No lint errors: [pass/fail]
- All tests passing: [pass/fail]
```

## Error Handling

- **CLAUDE.md missing `## Verification`**: Stop, ask user to add the section
- **Tests fail**: Debug and fix the underlying issue, re-run
- **Lint errors**: Fix manually, re-run until clean
