---
name: security-review
description: Security review checklist — secrets detection, input validation, dependency audit, OWASP Top 10
allowed-tools: Read, Bash, Grep, Glob
---

# Security Review

Comprehensive security review checklist for pre-merge and pre-deploy.

## Usage

```
/security-review [scope]
```

Scope: `diff` (changed files only), `full` (entire codebase), `deps` (dependencies only)

## Steps

### 1. Secrets Detection

```bash
# Search for hardcoded secrets
ruff check --select S105,S106,S107 .      # Python
grep -rn "sk-\|api_key\|password\s*=" --include="*.py" --include="*.ts" .

# Check .env files aren't committed
git ls-files | grep -i '\.env$'
```

Flag:
- API keys, tokens, passwords in source code
- `.env` files tracked by git
- Secrets in log statements or error messages

### 2. Input Validation

Check all system boundaries:
- API endpoints: request body validated with schemas (Zod, Pydantic, Strawberry input types)
- File uploads: type and size validated
- URL parameters: sanitized before use
- GraphQL arguments: typed and validated

### 3. Injection Prevention

- **SQL**: No string interpolation in queries — use ORM or parameterized queries
- **Command**: No user input in shell commands — use `subprocess` with list args
- **XSS**: No `dangerouslySetInnerHTML` with user data — use React's built-in escaping
- **Template**: No user input in template strings that get rendered as HTML

### 4. Authentication & Authorization

- All mutation endpoints require authentication
- Object-level authorization: users can only access their org's data
- No IDOR vulnerabilities (direct object references without auth check)
- Session management is correct (secure cookies, expiry)

### 5. Dependency Audit

```bash
# Python
pip-audit
bandit -r app/ -q

# Node.js
npm audit --audit-level=high

# Both: check for known CVEs
```

### 6. Configuration Review

- `DEBUG = False` in production
- HTTPS enforced
- CORS properly configured (not `*` in production)
- Security headers set (HSTS, X-Frame-Options, CSP)
- Error pages don't leak internal details

## Common False Positives

Before flagging, verify context:
- `.env.example` files (placeholder values, not secrets)
- Test fixtures with fake credentials
- Public API keys (Stripe publishable, Google Maps)
- Hash functions for checksums (SHA256 for cache, not passwords)

## Output Format

```
## Security Review: <scope>

### Critical
- [TYPE] file:line — description and exploitation path

### High
- [TYPE] file:line — description

### Informational
- description

### Summary
- Critical: N | High: N | Info: N
- Verdict: PASS / FAIL
```

## When to Run

- Before every PR merge
- After adding new API endpoints
- After changing auth/authorization code
- After adding new dependencies
- Before production deployments
