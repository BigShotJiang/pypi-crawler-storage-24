---
name: database-migrations
description: Safe database migration patterns — expand-contract, zero-downtime, Django migration workflow
allowed-tools: Read, Edit, Write, Bash, Grep, Glob
---

# Database Migrations

Safe migration patterns for Django + PostgreSQL. All migrations must be backwards-compatible and zero-downtime.

## Usage

```
/database-migrations [topic]
```

Topics: add-column, rename, drop, index, data-migration, expand-contract

## Core Principles

1. Migrations are source of truth for schema
2. Forward-only in production — never roll back schema changes
3. Separate schema migrations from data migrations
4. Every migration must be backwards-compatible with the previous deploy

## Migration Safety Checklist

- [ ] Migration can run while old code is still serving traffic
- [ ] No exclusive table locks on large tables
- [ ] Data migration is separate from schema migration
- [ ] Rollback plan documented (even if it's "deploy next migration")

## Common Patterns

### Adding a Column (Safe)

```python
# Safe: nullable column with no default
class Migration(migrations.Migration):
    operations = [
        migrations.AddField(
            model_name="project",
            name="description",
            field=models.TextField(null=True, blank=True),
        ),
    ]
```

Adding a NOT NULL column requires a default:
```python
migrations.AddField(
    model_name="project",
    name="priority",
    field=models.IntegerField(default=0),
),
```

### Creating an Index (Safe with CONCURRENTLY)

```python
from django.contrib.postgres.operations import AddIndexConcurrently

class Migration(migrations.Migration):
    atomic = False  # Required for CONCURRENTLY

    operations = [
        AddIndexConcurrently(
            model_name="project",
            index=models.Index(fields=["organization", "created_at"], name="idx_proj_org_created"),
        ),
    ]
```

### Renaming a Column (Expand-Contract)

Never rename directly — it breaks running code. Use expand-contract:

**Step 1 — Expand** (Migration 1):
```python
# Add new column
migrations.AddField(model_name="project", name="title", field=models.TextField(null=True)),
# Backfill with RunPython
migrations.RunPython(copy_name_to_title, reverse_code=migrations.RunPython.noop),
```

**Step 2 — Switch** (Code change):
Update all code to read/write `title` instead of `name`. Deploy.

**Step 3 — Contract** (Migration 2, next deploy):
```python
migrations.RemoveField(model_name="project", name="name"),
```

### Dropping a Column (Two-Phase)

**Phase 1**: Remove all code references. Deploy.
**Phase 2**: Drop the column in a migration. Deploy.

Never drop a column in the same deploy that removes code references.

### Data Migrations

```python
from django.db import migrations

def backfill_priority(apps, schema_editor):
    Project = apps.get_model("app", "Project")
    Project.objects.filter(priority__isnull=True).update(priority=0)

class Migration(migrations.Migration):
    operations = [
        migrations.RunPython(backfill_priority, reverse_code=migrations.RunPython.noop),
    ]
```

For large tables, batch the update:
```python
def backfill_priority(apps, schema_editor):
    Project = apps.get_model("app", "Project")
    batch_size = 1000
    while True:
        ids = list(
            Project.objects.filter(priority__isnull=True)
            .values_list("id", flat=True)[:batch_size]
        )
        if not ids:
            break
        Project.objects.filter(id__in=ids).update(priority=0)
```

## Anti-Patterns

- Renaming columns directly (`RenameField` breaks running code)
- Mixing schema and data in one migration
- Running data migrations on huge tables without batching
- Adding NOT NULL columns without a default
- `DROP TABLE` in the same deploy that removes model code
- Running `ALTER TABLE` on large tables during peak traffic
- Using `RunSQL` without a reverse operation

## Django Commands Reference

```bash
# Create migrations
python manage.py makemigrations

# Apply migrations
python manage.py migrate

# Show migration status
python manage.py showmigrations

# Generate SQL without applying
python manage.py sqlmigrate app_name 0042

# Squash migrations (dev only)
python manage.py squashmigrations app_name 0001 0042
```
