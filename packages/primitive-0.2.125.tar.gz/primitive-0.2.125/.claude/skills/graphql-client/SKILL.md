---
name: graphql-client
description: GraphQL client patterns — codegen, TanStack Query hooks, optimistic updates, cache management, and error handling
allowed-tools: Read, Edit, Write, Grep, Glob, Bash
---

# GraphQL Client

GraphQL client patterns for Primitive Corp's frontend. Uses codegen to generate typed hooks consumed via TanStack Query.

## Usage

```
/graphql-client [topic]
```

Topics: codegen, queries, mutations, cache, errors, pagination, optimistic

## Architecture

```
packages/sdk/
├── codegen.ts              # GraphQL codegen config
├── src/
│   ├── documents/          # *.graphql files (one per domain)
│   │   ├── projects.graphql
│   │   ├── organizations.graphql
│   │   └── users.graphql
│   ├── generated/          # Auto-generated — never edit
│   │   ├── graphql.ts      # Types + operations
│   │   └── hooks.ts        # TanStack Query hooks
│   └── client.ts           # GraphQL client setup
```

## GraphQL Documents

### Queries

```graphql
# packages/sdk/src/documents/projects.graphql

query Projects($first: Int = 20, $after: String) {
  projects(first: $first, after: $after) {
    edges {
      node {
        id
        name
        status
        createdAt
        organization {
          id
          name
        }
      }
    }
    pageInfo {
      hasNextPage
      endCursor
    }
    totalCount
  }
}

query Project($id: ID!) {
  project(id: $id) {
    id
    name
    status
    description
    createdAt
    updatedAt
  }
}
```

### Mutations

```graphql
mutation CreateProject($input: CreateProjectInput!) {
  createProject(input: $input) {
    node {
      id
      name
      status
    }
    messages {
      kind
      message
      field
    }
  }
}

mutation UpdateProject($id: ID!, $input: UpdateProjectInput!) {
  updateProject(id: $id, input: $input) {
    node {
      id
      name
      status
    }
    messages {
      kind
      message
      field
    }
  }
}
```

## Codegen

### Configuration

```ts
// packages/sdk/codegen.ts
import type { CodegenConfig } from "@graphql-codegen/cli"

const config: CodegenConfig = {
  schema: process.env.GRAPHQL_SCHEMA_URL || "http://localhost:8000/graphql/",
  documents: "src/documents/**/*.graphql",
  generates: {
    "src/generated/graphql.ts": {
      plugins: ["typescript", "typescript-operations"],
    },
    "src/generated/hooks.ts": {
      plugins: ["typescript-react-query"],
      config: {
        fetcher: "../client#graphqlFetcher",
        reactQueryVersion: 5,
      },
    },
  },
}

export default config
```

### Running Codegen

```bash
# After schema or document changes
pnpm run generate:graphql

# Verify no drift in CI
pnpm run generate:graphql && git diff --exit-code packages/sdk/src/generated/
```

**Never edit files in `generated/`.** Modify the `.graphql` documents and re-run codegen.

## Using Generated Hooks

### Queries

```tsx
import { useProjectsQuery, useProjectQuery } from "@primitive/sdk/generated/hooks"

function ProjectList() {
  const { data, isLoading, error } = useProjectsQuery({ first: 20 })

  if (isLoading) return <ProjectSkeleton />
  if (error) return <ErrorDisplay error={error} />

  return (
    <ul>
      {data.projects.edges.map(({ node }) => (
        <li key={node.id}>{node.name}</li>
      ))}
    </ul>
  )
}

function ProjectDetail({ id }: { id: string }) {
  const { data, isLoading } = useProjectQuery({ id })

  if (isLoading) return <Skeleton />
  if (!data?.project) return <NotFound />

  return <h1>{data.project.name}</h1>
}
```

### Mutations with `handleMutation`

All mutations go through `handleMutation()` — never manually parse the `{ node, messages }` response:

```tsx
import { useCreateProjectMutation } from "@primitive/sdk/generated/hooks"
import { handleMutation } from "@primitive/sdk/client"

function CreateProjectForm() {
  const createProject = useCreateProjectMutation()

  async function onSubmit(data: { name: string }) {
    const result = await handleMutation(
      createProject.mutateAsync({ input: { name: data.name } })
    )

    if (result.success) {
      toast.success("Project created")
      router.push(`/projects/${result.node.id}`)
    }
    // Errors are handled by handleMutation — displayed via toast
  }

  return (/* form JSX */)
}
```

## Cache Management

### Query Key Conventions

```ts
// Generated hooks use consistent query keys:
// ["Projects", variables]
// ["Project", { id }]
```

### Invalidation After Mutation

```tsx
import { useQueryClient } from "@tanstack/react-query"

function useCreateProject() {
  const queryClient = useQueryClient()
  const mutation = useCreateProjectMutation()

  return {
    ...mutation,
    mutateAsync: async (input: CreateProjectInput) => {
      const result = await mutation.mutateAsync({ input })
      // Invalidate list queries after create
      queryClient.invalidateQueries({ queryKey: ["Projects"] })
      return result
    },
  }
}
```

### Optimistic Updates

```tsx
function useUpdateProjectStatus() {
  const queryClient = useQueryClient()
  const mutation = useUpdateProjectMutation()

  return useMutation({
    mutationFn: (vars: { id: string; status: string }) =>
      mutation.mutateAsync({ id: vars.id, input: { status: vars.status } }),

    onMutate: async ({ id, status }) => {
      await queryClient.cancelQueries({ queryKey: ["Projects"] })
      const previous = queryClient.getQueryData(["Projects"])

      queryClient.setQueryData(["Projects"], (old: ProjectsQuery) => ({
        ...old,
        projects: {
          ...old.projects,
          edges: old.projects.edges.map((edge) =>
            edge.node.id === id
              ? { ...edge, node: { ...edge.node, status } }
              : edge
          ),
        },
      }))

      return { previous }
    },

    onError: (_err, _vars, context) => {
      queryClient.setQueryData(["Projects"], context?.previous)
    },

    onSettled: () => {
      queryClient.invalidateQueries({ queryKey: ["Projects"] })
    },
  })
}
```

## Pagination — Cursor-Based

```tsx
import { useInfiniteQuery } from "@tanstack/react-query"

function useInfiniteProjects() {
  return useInfiniteQuery({
    queryKey: ["Projects", "infinite"],
    queryFn: ({ pageParam }) =>
      graphqlFetcher(ProjectsDocument, { first: 20, after: pageParam }),
    initialPageParam: null as string | null,
    getNextPageParam: (lastPage) =>
      lastPage.projects.pageInfo.hasNextPage
        ? lastPage.projects.pageInfo.endCursor
        : undefined,
  })
}

function ProjectList() {
  const { data, fetchNextPage, hasNextPage, isFetchingNextPage } =
    useInfiniteProjects()

  const projects = data?.pages.flatMap((p) => p.projects.edges) ?? []

  return (
    <>
      {projects.map(({ node }) => (
        <ProjectCard key={node.id} project={node} />
      ))}
      {hasNextPage && (
        <Button onClick={() => fetchNextPage()} disabled={isFetchingNextPage}>
          {isFetchingNextPage ? "Loading..." : "Load more"}
        </Button>
      )}
    </>
  )
}
```

## Error Handling

### GraphQL Errors

```tsx
function ErrorDisplay({ error }: { error: Error }) {
  // Network error
  if (error.message.includes("NetworkError")) {
    return <Alert variant="destructive">Unable to connect. Check your network.</Alert>
  }

  // GraphQL error
  return (
    <Alert variant="destructive">
      <AlertTitle>Something went wrong</AlertTitle>
      <AlertDescription>{error.message}</AlertDescription>
    </Alert>
  )
}
```

### Mutation Error Messages

The `{ node, messages }` pattern returns field-level errors:

```tsx
// handleMutation processes this automatically, but for custom handling:
const result = await createProject.mutateAsync({ input })
const errors = result.createProject.messages.filter((m) => m.kind === "error")
if (errors.length > 0) {
  errors.forEach((e) => form.setError(e.field ?? "root", { message: e.message }))
}
```

## Checklist

- [ ] GraphQL documents in `packages/sdk/src/documents/` (one file per domain)
- [ ] Codegen re-run after any schema or document change
- [ ] All mutations use `handleMutation()` — no manual error parsing
- [ ] Cache invalidated after mutations (`invalidateQueries`)
- [ ] Loading and error states for every query consumer
- [ ] Cursor-based pagination for list views (`useInfiniteQuery`)
- [ ] Optimistic updates for frequent user interactions
- [ ] Never edit files in `generated/`
