---
name: docker-patterns
description: Docker and Docker Compose patterns — development setup, networking, volumes, security, multi-stage builds
allowed-tools: Read, Edit, Write, Bash, Grep, Glob
---

# Docker Patterns

Docker and Docker Compose best practices for local development and production.

## Usage

```
/docker-patterns [topic]
```

Topics: compose, networking, volumes, security, debugging

## Docker Compose — Development Stack

```yaml
# docker-compose.yml
services:
  db:
    image: postgres:16
    environment:
      POSTGRES_DB: app_dev
      POSTGRES_USER: postgres
      POSTGRES_PASSWORD: postgres
    ports:
      - "5432:5432"
    volumes:
      - postgres_data:/var/lib/postgresql/data
    healthcheck:
      test: ["CMD-SHELL", "pg_isready -U postgres"]
      interval: 5s
      timeout: 3s
      retries: 5

  redis:
    image: redis:7-alpine
    ports:
      - "6379:6379"
    healthcheck:
      test: ["CMD", "redis-cli", "ping"]
      interval: 5s
      timeout: 3s

  app:
    build:
      context: .
      dockerfile: Dockerfile.dev
    ports:
      - "8000:8000"
    volumes:
      - .:/app
      - /app/.venv  # Don't mount venv from host
    environment:
      DATABASE_URL: postgres://postgres:postgres@db:5432/app_dev
      REDIS_URL: redis://redis:6379/0
    depends_on:
      db:
        condition: service_healthy
      redis:
        condition: service_healthy

  worker:
    build:
      context: .
      dockerfile: Dockerfile.dev
    command: celery -A config worker -l info
    volumes:
      - .:/app
    environment:
      DATABASE_URL: postgres://postgres:postgres@db:5432/app_dev
      REDIS_URL: redis://redis:6379/0
    depends_on:
      db:
        condition: service_healthy
      redis:
        condition: service_healthy

volumes:
  postgres_data:
```

## Development vs Production Dockerfile

### Development

```dockerfile
# Dockerfile.dev
FROM python:3.13-slim
WORKDIR /app
RUN pip install uv
COPY pyproject.toml uv.lock ./
RUN uv sync --frozen
COPY . .
CMD ["uv", "run", "python", "manage.py", "runserver", "0.0.0.0:8000"]
```

### Production (Multi-Stage)

```dockerfile
# Dockerfile
FROM python:3.13-slim AS builder
WORKDIR /app
RUN pip install uv
COPY pyproject.toml uv.lock ./
RUN uv sync --frozen --no-dev

FROM python:3.13-slim
RUN useradd -r -s /bin/false appuser
WORKDIR /app
COPY --from=builder /app/.venv /app/.venv
COPY . .
ENV PATH="/app/.venv/bin:$PATH"
USER appuser
EXPOSE 8000
CMD ["gunicorn", "config.wsgi", "--bind", "0.0.0.0:8000", "--workers", "4"]
```

## Networking

- Services within the same `docker-compose.yml` communicate by service name (`db`, `redis`, `app`)
- Only expose ports that need host access
- Use `depends_on` with `condition: service_healthy` for startup ordering

## Volume Strategy

- **Named volumes** for data persistence (databases): `postgres_data:/var/lib/postgresql/data`
- **Bind mounts** for development code: `.:/app`
- **Anonymous volumes** to exclude host dirs: `/app/.venv`, `/app/node_modules`

## Container Security

- Run as non-root user in production: `USER appuser`
- Use specific image tags, not `latest`
- Don't mount Docker socket into containers
- Don't store secrets in images — use environment variables
- Use `.dockerignore` to exclude `.env`, `.git`, `node_modules`

## Debugging

```bash
# View logs
docker compose logs -f app

# Execute command in running container
docker compose exec app python manage.py shell

# View resource usage
docker stats

# Inspect container
docker compose exec app bash

# Restart a single service
docker compose restart app

# Rebuild without cache
docker compose build --no-cache app
```

## Anti-Patterns

- Using `latest` tag for base images (pin versions)
- Running as root in production
- Storing secrets in Dockerfile (`ENV SECRET_KEY=...`)
- Not using `.dockerignore`
- Installing dev dependencies in production image
- Not using health checks for service dependencies
- Mounting host paths in production
