---
name: deployment-patterns
description: Deployment strategies — rolling, blue-green, canary, Docker, CI/CD pipelines, rollback
allowed-tools: Read, Edit, Write, Bash, Grep, Glob
---

# Deployment Patterns

Deployment strategies and CI/CD patterns for production systems.

## Usage

```
/deployment-patterns [topic]
```

Topics: strategies, docker, ci-cd, rollback, health-checks

## Deployment Strategies

### Rolling Deployment (Default)

Replace instances one at a time. Zero downtime if health checks are configured.

```yaml
# Kubernetes-style rolling update
strategy:
  type: RollingUpdate
  rollingUpdate:
    maxUnavailable: 0
    maxSurge: 1
```

**Use when**: Standard deployments, stateless services, low-risk changes.

### Blue-Green Deployment

Run two identical environments. Switch traffic from blue (current) to green (new) after verification.

**Use when**: Major version changes, database migration deployments, need instant rollback.

### Canary Deployment

Route a small percentage of traffic to the new version. Gradually increase if metrics are healthy.

**Use when**: High-risk changes, performance-sensitive updates, validating behavior under real load.

## Docker Multi-Stage Build

```dockerfile
# Build stage
FROM python:3.13-slim AS builder
WORKDIR /app
COPY pyproject.toml uv.lock ./
RUN pip install uv && uv sync --frozen --no-dev

# Runtime stage
FROM python:3.13-slim
WORKDIR /app
COPY --from=builder /app/.venv /app/.venv
COPY . .
ENV PATH="/app/.venv/bin:$PATH"

EXPOSE 8000
HEALTHCHECK --interval=30s --timeout=5s \
  CMD curl -f http://localhost:8000/health/ || exit 1

CMD ["gunicorn", "config.wsgi", "--bind", "0.0.0.0:8000", "--workers", "4"]
```

## Health Checks

Every service must expose a health endpoint:

```python
# Django health check
from django.http import JsonResponse
from django.db import connection

def health(request):
    try:
        connection.ensure_connection()
        return JsonResponse({"status": "healthy"})
    except Exception:
        return JsonResponse({"status": "unhealthy"}, status=503)
```

## CI/CD Pipeline

```yaml
# .github/workflows/deploy.yml
name: Deploy
on:
  push:
    branches: [main]

jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - name: Run tests
        run: make test
      - name: Run lint
        run: make lint

  deploy:
    needs: test
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - name: Build and push Docker image
        run: |
          docker build -t app:${{ github.sha }} .
          docker push app:${{ github.sha }}
      - name: Deploy
        run: |
          # Deploy using your platform's CLI
          echo "Deploying app:${{ github.sha }}"
```

## Rollback Plan

Every deployment must have a rollback strategy:

1. **Automated rollback**: If health checks fail after deploy, automatically roll back
2. **Manual rollback**: `git revert` + redeploy, or point to previous image tag
3. **Database rollback**: Expand-contract migrations are forward-only; no need to roll back schema

## Pre-Deployment Checklist

- [ ] All tests passing in CI
- [ ] Lint and type checks passing
- [ ] No unapplied database migrations
- [ ] Environment variables configured for target environment
- [ ] Health check endpoint verified
- [ ] Rollback plan documented
- [ ] Monitoring and alerting configured

## Environment Configuration

```bash
# Use environment variables for all config
DATABASE_URL=postgres://...
REDIS_URL=redis://...
SECRET_KEY=...
DEBUG=false
ALLOWED_HOSTS=app.example.com

# Never hardcode environment-specific values in code
```
