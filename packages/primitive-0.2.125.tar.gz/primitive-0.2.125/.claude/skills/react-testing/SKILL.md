---
name: react-testing
description: React testing patterns — Vitest, React Testing Library, MSW, component and hook testing
allowed-tools: Read, Edit, Write, Bash, Grep, Glob
---

# React Testing

Comprehensive testing patterns for React + Next.js using Vitest and React Testing Library.

## Usage

```
/react-testing [topic]
```

Topics: components, hooks, msw, async, forms, organization

## Testing Fundamentals

```tsx
import { render, screen } from "@testing-library/react"
import userEvent from "@testing-library/user-event"

// Basic component test
test("renders project name", () => {
  render(<ProjectCard project={{ id: "1", name: "Pipeline", status: "active" }} />)
  expect(screen.getByText("Pipeline")).toBeInTheDocument()
})

// Testing exceptions
test("throws on missing required prop", () => {
  // @ts-expect-error — testing runtime behavior
  expect(() => render(<ProjectCard />)).toThrow()
})
```

## Query Priority

Prefer accessible queries in this order:

```tsx
// 1. Role (best — matches accessibility tree)
screen.getByRole("button", { name: /submit/i })
screen.getByRole("textbox", { name: /email/i })
screen.getByRole("heading", { level: 2 })

// 2. Label text
screen.getByLabelText(/password/i)

// 3. Placeholder text
screen.getByPlaceholderText(/search/i)

// 4. Text content
screen.getByText(/no projects found/i)

// 5. Test ID (last resort)
screen.getByTestId("project-chart")
```

## User Events

Always use `userEvent` over `fireEvent`:

```tsx
test("filters projects on search", async () => {
  const user = userEvent.setup()
  render(<ProjectList projects={mockProjects} />)

  await user.type(screen.getByRole("searchbox"), "ML")

  expect(screen.getByText("ML Pipeline")).toBeInTheDocument()
  expect(screen.queryByText("Data Ingestion")).not.toBeInTheDocument()
})

test("selects option from dropdown", async () => {
  const user = userEvent.setup()
  render(<StatusFilter onChange={vi.fn()} />)

  await user.click(screen.getByRole("combobox"))
  await user.click(screen.getByRole("option", { name: /active/i }))

  expect(screen.getByRole("combobox")).toHaveTextContent("Active")
})

test("keyboard navigation", async () => {
  const user = userEvent.setup()
  render(<ProjectTable projects={mockProjects} />)

  await user.tab()
  expect(screen.getByRole("link", { name: /pipeline/i })).toHaveFocus()

  await user.keyboard("{Enter}")
  // Assert navigation or action
})
```

## Async Testing

```tsx
// waitFor — poll until assertion passes
test("loads and displays projects", async () => {
  render(<ProjectList />, { wrapper: QueryWrapper })

  await waitFor(() => {
    expect(screen.getByText("ML Pipeline")).toBeInTheDocument()
  })
})

// findBy — shorthand for waitFor + getBy
test("shows data after loading", async () => {
  render(<ProjectList />, { wrapper: QueryWrapper })

  const heading = await screen.findByRole("heading", { name: /projects/i })
  expect(heading).toBeInTheDocument()
})

// waitForElementToBeRemoved
test("loading spinner disappears", async () => {
  render(<ProjectList />, { wrapper: QueryWrapper })

  await waitForElementToBeRemoved(() => screen.queryByTestId("spinner"))
  expect(screen.getByText("ML Pipeline")).toBeInTheDocument()
})
```

## MSW — API Mocking

### Setup

```ts
// test/mocks/server.ts
import { setupServer } from "msw/node"
import { handlers } from "./handlers"

export const server = setupServer(...handlers)
```

### GraphQL Handlers

```ts
// test/mocks/handlers.ts
import { graphql, HttpResponse } from "msw"

export const handlers = [
  graphql.query("Projects", () => {
    return HttpResponse.json({
      data: {
        projects: {
          edges: [
            { node: { id: "1", name: "ML Pipeline", status: "active" } },
          ],
          pageInfo: { hasNextPage: false, endCursor: null },
        },
      },
    })
  }),

  graphql.mutation("CreateProject", ({ variables }) => {
    return HttpResponse.json({
      data: {
        createProject: {
          node: { id: "99", name: variables.input.name },
          messages: [],
        },
      },
    })
  }),
]
```

### Per-Test Overrides

```tsx
import { server } from "@/test/mocks/server"
import { graphql, HttpResponse } from "msw"

test("shows error state on API failure", async () => {
  server.use(
    graphql.query("Projects", () => {
      return HttpResponse.json({
        errors: [{ message: "Internal server error" }],
      })
    })
  )

  render(<ProjectList />, { wrapper: QueryWrapper })

  expect(await screen.findByText(/something went wrong/i)).toBeInTheDocument()
})
```

## Hook Testing

```tsx
import { renderHook, act, waitFor } from "@testing-library/react"

test("useDebounce delays value update", async () => {
  const { result, rerender } = renderHook(
    ({ value }) => useDebounce(value, 300),
    { initialProps: { value: "hello" } }
  )

  expect(result.current).toBe("hello")

  rerender({ value: "world" })
  expect(result.current).toBe("hello") // Still old value

  await waitFor(() => {
    expect(result.current).toBe("world") // Updated after delay
  })
})

test("useProjects fetches data", async () => {
  const { result } = renderHook(() => useProjects("org-1"), {
    wrapper: QueryWrapper,
  })

  await waitFor(() => expect(result.current.isSuccess).toBe(true))
  expect(result.current.data).toHaveLength(1)
  expect(result.current.data![0].name).toBe("ML Pipeline")
})
```

## Form Testing

```tsx
test("validates required fields", async () => {
  const user = userEvent.setup()
  render(<CreateProjectForm />)

  // Submit empty form
  await user.click(screen.getByRole("button", { name: /create/i }))

  expect(await screen.findByText(/name is required/i)).toBeInTheDocument()
})

test("submits valid form data", async () => {
  const user = userEvent.setup()
  const onSuccess = vi.fn()
  render(<CreateProjectForm onSuccess={onSuccess} />, { wrapper: QueryWrapper })

  await user.type(screen.getByRole("textbox", { name: /name/i }), "New Project")
  await user.click(screen.getByRole("button", { name: /create/i }))

  await waitFor(() => expect(onSuccess).toHaveBeenCalled())
})
```

## Test Organization

```
src/
├── components/
│   ├── project-card.tsx
│   └── project-card.test.tsx      # Co-located tests
├── hooks/
│   ├── use-projects.ts
│   └── use-projects.test.ts
├── lib/
│   ├── utils.ts
│   └── utils.test.ts
test/
├── setup.ts                       # Global test setup
├── mocks/
│   ├── server.ts                  # MSW server
│   └── handlers.ts                # Default handlers
└── helpers/
    └── query-wrapper.tsx           # QueryClient wrapper
```

## Best Practices

**DO:**
- Co-locate tests with source files (`*.test.tsx` next to `*.tsx`)
- Test user-visible behavior, not implementation
- Use `screen.getByRole` as the primary query
- Use MSW for API mocking — don't mock `fetch` directly
- Use `vi.fn()` for callback assertions
- Use `vi.useFakeTimers()` for time-dependent tests

**DON'T:**
- Mock modules you own — test through the public API
- Use `container.innerHTML` or `container.querySelector`
- Snapshot test entire component trees
- Test CSS classes or styling details
- Use `act()` directly — RTL queries handle it
- Use `waitFor` with side effects — only assertions

## Running Tests

```bash
# All tests
pnpm vitest run

# Watch mode
pnpm vitest

# Single file
pnpm vitest run src/components/project-card.test.tsx

# With coverage
pnpm vitest run --coverage

# Update snapshots (if using inline snapshots)
pnpm vitest run -u
```
