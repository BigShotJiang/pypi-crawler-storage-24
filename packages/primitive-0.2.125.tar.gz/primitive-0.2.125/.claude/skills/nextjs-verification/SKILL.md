---
name: nextjs-verification
description: Pre-PR verification pipeline for Next.js projects — format, lint, type-check, test, security scan
allowed-tools: Read, Bash, Grep, Glob
---

# Next.js Verification

Comprehensive verification pipeline to run before opening a PR on the frontend monorepo.

## Usage

```
/nextjs-verification [quick|full]
```

- `quick` — format + lint + type-check only
- `full` (default) — all phases

## Steps

### 1. Code Quality & Formatting

```bash
# Format check
pnpm oxfmt --check .

# Lint
pnpm oxlint .

# Type check
pnpm tsgo --noEmit
```

Fix any failures before proceeding. Use `pnpm oxfmt .` for auto-formatting.

### 2. GraphQL Codegen Check

```bash
# Regenerate and check for drift
pnpm run generate:graphql
git diff --exit-code packages/sdk/src/
```

If generated files changed, include the updated codegen output in the PR.

### 3. Breadcrumb Check

```bash
# Verify every authenticated page has @breadcrumbs
pnpm run check:breadcrumbs
```

Every `page.tsx` under `(app)/` must have a matching `@breadcrumbs` page.

### 4. Tests & Coverage

```bash
# Unit + integration tests
pnpm vitest run --coverage

# Check coverage threshold
pnpm vitest run --coverage --coverage.thresholds.lines=80

# E2E tests (if changed)
pnpm playwright test
```

All tests must pass. Coverage must be 80%+ on new code.

### 5. Build Check

```bash
# Verify production build succeeds
pnpm turbo build
```

Build errors must be resolved before merge.

### 6. Security Scan

```bash
# Dependency vulnerabilities
pnpm audit --audit-level=high

# Check for leaked secrets
pnpm oxlint --deny suspicious
```

Address all HIGH/CRITICAL findings before merge.

### 7. Final Diff Review

```bash
# Review what will be in the PR
git diff main...HEAD --stat
git diff main...HEAD -- '*.ts' '*.tsx'
```

Check for:
- Unintended file changes
- Debug code (`console.log`, `debugger`)
- Commented-out code
- Missing test coverage for new code paths
- `"use client"` on components that don't need it

## Output Format

```
## Verification Results

| Check | Status |
|-------|--------|
| Format (oxfmt) | PASS/FAIL |
| Lint (oxlint) | PASS/FAIL |
| Types (tsgo) | PASS/FAIL |
| GraphQL codegen | PASS/FAIL |
| Breadcrumbs | PASS/FAIL |
| Tests (vitest) | PASS (N passed) / FAIL |
| Coverage | XX% (target: 80%) |
| Build | PASS/FAIL |
| Security (pnpm audit) | PASS/FAIL |

Ready for PR: YES / NO
```

## Error Handling

If any phase fails:
1. Report the specific failure with error details
2. Attempt auto-fix for formatting/lint issues
3. Re-run the failed check
4. If still failing, report and stop — do not proceed to PR
