# Development Conventions

## Universal

- Use dedicated tools for file operations (Read/Edit/Write/Glob/Grep), not bash equivalents
- Never commit `.env` files or secrets
- All PRs go through the `/plan-work` → `/start-work` workflow
- Plans are stored at `.claude/plans/<ticket-id-lowercase>-plan.md`

## Backend Conventions

### Project Structure

- All Django apps live in `core/`
- `make` commands run from the repo root (Makefile handles `cd core/` internally)
- Tests live in `tests/` within each app

### Code Patterns

- Models: add `__str__`, use `select_related`/`prefetch_related` to avoid N+1
- Mutations: return `{ node, messages }` with `OperationMessage[]` for errors
- Celery tasks: decorators in `tasks.py`, business logic in separate functions
- Use `F()` expressions for atomic numeric updates

### Testing

- Framework: pytest with `@pytest.mark.django_db`
- Factories: `factory_boy` via pytest-factoryboy — register in `conftest.py`
- Run with `ENVIRONMENT=test` to use test database
- Parallel: `-n 5` for full suite
- Coverage: `--cov=.`

## Frontend Conventions

### File Organization

- Apps: `apps/core`, `apps/auth`, `apps/www`, `apps/docs`
- Shared packages: `packages/sdk`, `packages/ui`, `packages/typescript-config`
- Components shared across apps go in `packages/ui`, never in individual apps

### Data Fetching

- Generated hooks only — run `pnpm run generate:graphql` after schema changes
- GraphQL documents in `packages/sdk/src/documents/*.graphql` (one file per domain)
- Use `handleMutation()` for all mutations — do not manually parse errors

### Routing

- Every authenticated `page.tsx` needs a matching `@breadcrumbs` page
- Check `apps/core/scripts/check-breadcrumbs.mts` for the enforcement script

## CLI Conventions

### Module Pattern

Each module follows:
- `commands.py` — Click commands
- `actions.py` — Business logic extending `BaseAction`
- `graphql/` — GraphQL documents
- `ui.py` — Rich rendering

### API Calls

- Always use the `@guard` decorator for API calls (backoff retry, lazy session)
- Handle errors via `handle_mutation_response()` in `graphql/sdk.py`

## Git Conventions

See `git-conventions.md` for branch naming, commit format, and PR rules.

## Linear / Ticket Workflow

- Team prefix: `ENG-`
- Branch: `<username>/eng-<number>-<description>`
- Assign ticket to yourself when starting work
- Update ticket status as work progresses
