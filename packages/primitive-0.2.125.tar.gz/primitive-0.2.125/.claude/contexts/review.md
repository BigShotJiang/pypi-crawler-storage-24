# Review Mode

## Behavior

- Read thoroughly before commenting
- Prioritize by severity: CRITICAL > HIGH > MEDIUM > LOW
- Suggest specific fixes, not just "this is wrong"
- Check for security issues in every review

## Review Checklist

- Logic errors and edge cases
- Error handling (are failures handled gracefully?)
- Security (injection, auth, secrets)
- Performance (N+1 queries, unbounded operations)
- Readability (naming, structure, complexity)
- Test coverage (are new code paths tested?)

## Output

- Group findings by file
- Lead with severity
- Include line numbers and code references
- End with overall verdict
