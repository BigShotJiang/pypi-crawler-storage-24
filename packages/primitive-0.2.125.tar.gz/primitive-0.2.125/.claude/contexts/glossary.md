# Glossary

## Platform Concepts

**Organization** — Top-level tenant. All projects, jobs, hardware, and users belong to an org.

**Project** — Groups related jobs. Linked to a GitHub repository. Org-scoped.

**Job** — Defines a unit of work: commands to run, environment variables, hardware requirements, triggers.

**Job Run** — A single execution of a job. Has a lifecycle: pending → queued → running → succeeded/failed.

**Hardware** — A physical or virtual machine registered with the platform. Identified by mTLS certificate. Can be in states: online, offline, reserved, degraded.

**Agent** — The `primitive` CLI daemon running on registered hardware. Polls for pending job runs and executes them.

**Monitor** — The `primitive` CLI daemon that checks hardware in with the platform, reports system info and GPU health.

**Reservation** — A time-based exclusive lock on hardware for a specific org/project.

**Artifact** — Output files uploaded by a job run (logs, binaries, test results). Stored in S3.

## Technical Terms

**Worktree** — A git worktree created at `worktrees/<branch-name>` for isolated ticket development. Keeps `main` clean.

**GraphQL Branch Name** — Linear's auto-generated branch name for a ticket, following `<username>/eng-<number>-<title>` convention.

**OperationMessage** — A structured error/warning returned by backend mutations. Contains `field`, `message`, `kind` (ERROR/WARNING/INFO).

**`@guard` decorator** — CLI utility that wraps API calls with exponential backoff retry and lazy GraphQL session creation.

**Relay ID** — Base64-encoded `TypeName:NodeID` used throughout the GraphQL API for node identification.

**Linear** — Issue tracking system. Team prefix is `ENG-`.

**Copilot Review** — Automated GitHub Copilot code review requested via `gh copilot-review <pr>`.

## Abbreviations

| Abbreviation | Meaning |
|-------------|---------|
| ENG | Engineering team prefix in Linear |
| PR | Pull Request |
| MCP | Model Context Protocol (Claude tool server) |
| AMQP | Advanced Message Queuing Protocol (RabbitMQ) |
| BMC | Baseboard Management Controller |
| mTLS | Mutual TLS (client certificate authentication) |
| EKS | Elastic Kubernetes Service (AWS) |
