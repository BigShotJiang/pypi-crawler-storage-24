# Tech Stack

## Backend

| Category | Choice | Notes |
|----------|--------|-------|
| Language | Python 3.13 | |
| Framework | Django 6.0 | |
| API | Strawberry GraphQL | `strawberry-graphql-django` |
| Database | PostgreSQL | via Django ORM |
| Cache | Redis | |
| Task Queue | Celery + RabbitMQ | `celery` queue, `logging` queue, `hardware` queue |
| ASGI Server | Uvicorn | |
| Package Manager | uv | replaces pip/poetry |
| Linter/Formatter | ruff | |
| Test Framework | pytest | pytest-django, pytest-factoryboy |
| AWS SDK | boto3 | |
| Kubernetes Client | kubernetes | |
| Payments | Stripe | |
| Error Tracking | Sentry | |
| Email | Resend | |

## Frontend

| Category | Choice | Notes |
|----------|--------|-------|
| Language | TypeScript | |
| Framework | Next.js (App Router) | Node 22.x |
| Package Manager | pnpm 10 | Turborepo monorepo |
| State/Data | TanStack Query (React Query) | |
| API Layer | GraphQL (codegen → hooks) | `packages/sdk` |
| UI Components | shadcn + Radix UI | `packages/ui` |
| Linter | oxlint | Rust-based |
| Formatter | oxfmt | Rust-based |
| Type Checker | tsgo | |
| Test Framework | Vitest | |
| E2E Tests | Playwright | `packages/playwright` |

## CLI

| Category | Choice | Notes |
|----------|--------|-------|
| Language | Python 3.13 | |
| CLI Framework | Click | |
| Package Manager | uv | |
| GraphQL Client | gql + aiohttp | |
| HTTP Client | requests | for file uploads |
| Messaging | pika (RabbitMQ/AMQP) | hardware check-ins |
| Hardware | Redfish | BMC/out-of-band management |
| Linter/Formatter | ruff | |
| Type Checker | pyright | |
| Output | Rich | tables, progress, status |
| Daemon | macOS LaunchAgent / Linux systemd | |
| Published | PyPI as `primitive` | via hatch |
