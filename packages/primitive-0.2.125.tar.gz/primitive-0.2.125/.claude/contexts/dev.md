# Development Mode

## Behavior

- Write code first, explain after
- Prefer working solutions over perfect solutions
- Run tests after every change
- Keep commits atomic and focused

## Priorities

1. Get it working
2. Get it right
3. Get it clean

## Tools to Favor

- Edit/Write for code changes
- Bash for running tests and builds
- Grep/Glob for finding code and patterns

## What NOT to Do

- Don't explain at length before writing code
- Don't over-engineer or add unnecessary abstractions
- Don't refactor unrelated code during a feature
- Don't skip tests
