# Primitive Architecture

## System Overview

Primitive is a CI/CD platform for running jobs on registered hardware. The core data model:

```
Organization → Projects → Jobs → Job Runs → Hardware
```

- **Organizations** own everything; all data is tenanted by org
- **Projects** group related jobs and are linked to GitHub repositories
- **Jobs** define what runs (commands, environment, hardware requirements)
- **Job Runs** are individual executions of a job on specific hardware
- **Hardware** is registered by users and connects to the platform via the CLI agent

## Services

| Service | Purpose | Tech |
|---------|---------|------|
| Backend | GraphQL API, business logic, webhooks | Django 6, Python 3.13, Strawberry GraphQL |
| Frontend | Web UI | Next.js App Router, TypeScript, React Query |
| primitive-cli | CLI tool, hardware agent, monitor daemon | Python 3.13, Click, uv |

## Communication

- **Frontend → Backend**: GraphQL over HTTPS (`POST /graphql`)
- **CLI → Backend**: GraphQL (primary), REST (file uploads)
- **Hardware Agent → Backend**: RabbitMQ/AMQP for check-ins and events
- **Webhooks**: GitHub App sends webhook events to backend via cloudflared tunnel in development

## Infrastructure

- **AWS EKS** — Kubernetes cluster hosting backend and workers
- **PostgreSQL** — Primary database
- **RabbitMQ** — Message broker for hardware communication
- **Redis** — Caching layer
- **Celery** — Background tasks and scheduled jobs
- **AWS S3** — Artifact and log storage
- **Stripe** — Billing and subscription management

## Authentication

- GitHub OAuth via GitHub App for user login
- mTLS certificates for hardware registration and agent authentication
- Sessions stored server-side; frontend uses `whoami` query to check auth state

## Environments

| Environment | Purpose | Deploy |
|-------------|---------|--------|
| dev | Development | Auto-deploy on merge to main |
| test | Integration testing | Manual via `make deploy-test` |
| prod | Production | Manual via `make deploy-prod` |
