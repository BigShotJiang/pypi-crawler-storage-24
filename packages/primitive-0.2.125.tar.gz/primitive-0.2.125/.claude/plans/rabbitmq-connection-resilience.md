# Plan: Make primitive-cli Resilient to Transient RabbitMQ Failures

## Context

When RabbitMQ restarts (triggered by Let's Encrypt cert renewal every ~60 days), hardware nodes running `primitive-cli` crash and don't recover. Investigation traced the root cause to three gaps in error handling:

1. `send_message()` only retries DNS errors — SSL/connection/AMQP errors crash the process
2. The monitor's main loop has no try/except around check-in calls — any exception kills it
3. The initial check-in does `sys.exit(1)` on first failure instead of retrying

Full investigation: `backend/.claude/investigations/rabbitmq-ssl-handshake-failures.md`

## Files to Modify

All in `/Users/djstein/Development/primitivecorp/primitive-cli`:

1. `src/primitive/messaging/actions.py` — broaden retry logic in `send_message()`
2. `src/primitive/hardware/actions.py` — add fallback in `check_in()`
3. `src/primitive/monitor/actions.py` — make loop and initial check-in resilient
4. `src/primitive/daemons/launch_service.py` — add `RestartSec`, `StartLimitIntervalSec` to systemd template + enable loginctl linger

Reference (no changes): `src/primitive/utils/auth.py` — existing `backoff` pattern to follow

## Changes

### Change 1: `messaging/actions.py` — Retry all transient connection errors

Replace the manual DNS-only retry loop (lines 122-143) with a `backoff`-decorated inner function that retries on all transient connection errors. This follows the existing `@guard` pattern in `utils/auth.py`.

**Add imports:**
```python
import ssl
import backoff
import pika.exceptions
```

**Add module-level constants and handler:**
```python
TRANSIENT_CONNECTION_ERRORS = (
    socket.gaierror,
    ssl.SSLEOFError,
    ssl.SSLError,
    ConnectionResetError,
    ConnectionRefusedError,
    OSError,
    pika.exceptions.AMQPConnectionError,
)

MAX_MESSAGING_BACKOFF_TIME = 300  # 5 minutes — enough for a pod restart

def _messaging_backoff_handler(details):
    logger.warning(
        "RabbitMQ connection failed. Retrying in {wait:0.1f}s (attempt {tries}).".format(**details)
    )
```

**Replace lines 122-177** (the manual retry loop + publish block) with:

```python
@backoff.on_exception(
    backoff.expo,
    TRANSIENT_CONNECTION_ERRORS,
    max_time=MAX_MESSAGING_BACKOFF_TIME,
    on_backoff=_messaging_backoff_handler,
)
def _connect_and_publish():
    conn = pika.BlockingConnection(parameters=self.parameters)
    with conn:
        message_uuid = str(uuid4())
        channel = conn.channel()
        headers = {
            "fingerprint": self.fingerprint,
            "version": __version__,
            "token": self.token,
            "argsrepr": "()",
            "id": message_uuid,
            "ignore_result": False,
            "kwargsrepr": f"{{message_type: {message_type.value}}}",
            "lang": "py",
            "replaced_task_nesting": 0,
            "retries": 0,
            "root_id": message_uuid,
            "task": CELERY_TASK_NAME,
        }
        channel.basic_publish(
            exchange=EXCHANGE,
            routing_key=ROUTING_KEY,
            body=json.dumps(full_body_for_celery),
            properties=pika.BasicProperties(
                user_id=self.common_name,
                correlation_id=message_uuid,
                priority=0,
                delivery_mode=2,
                headers=headers,
                content_encoding="utf-8",
                content_type="application/json",
            ),
        )

_connect_and_publish()
```

The nested function approach avoids changing the `Messaging` class interface. Both the connection and publish are inside the retry scope since errors can occur at either stage.

### Change 2: `hardware/actions.py` — Fallback to HTTP when messaging fails

Wrap the messaging path in `check_in()` (lines 543-552) so that if `send_message()` fails after exhausting its retries, we fall back to the existing `check_in_http()`.

```python
def check_in(self, ...):
    if not http and self.primitive.messaging.ready:
        try:
            message = {
                "is_healthy": is_healthy,
                "is_quarantined": is_quarantined,
                "is_available": is_available,
                "is_online": is_online,
            }
            self.primitive.messaging.send_message(
                message_type=MESSAGE_TYPES.CHECK_IN, message=message
            )
        except Exception:
            logger.warning("RabbitMQ check-in failed after retries, falling back to HTTP")
            self.check_in_http(
                is_healthy=is_healthy,
                is_quarantined=is_quarantined,
                is_available=is_available,
                is_online=is_online,
                stopping_agent=stopping_agent,
            )
    else:
        self.check_in_http(...)  # unchanged
```

Broad `except Exception` is intentional here — `send_message` has already exhausted its 5-minute backoff, so anything that escapes is unrecoverable via messaging. HTTP fallback is the safe choice. `check_in_http` already has its own retry via the `@guard` decorator (15-minute backoff).

### Change 3: `monitor/actions.py` — Resilient loop and initial check-in

**3a. Initial check-in (lines 36-46):** Replace immediate `sys.exit(1)` with a retry loop. Since `check_in` already retries internally (via Changes 1 and 2), each attempt here represents a full retry cycle (~5 min messaging backoff + ~15 min HTTP backoff).

```python
if not RUNNING_IN_CONTAINER:
    max_initial_attempts = 3
    for attempt in range(max_initial_attempts):
        try:
            self.primitive.hardware.check_in(is_online=True)
            break
        except Exception as exception:
            logger.error(
                f"Error checking in hardware (attempt {attempt + 1}/{max_initial_attempts}): {exception}"
            )
            if attempt < max_initial_attempts - 1:
                sleep(min(2 ** attempt * 5, 30))
            else:
                logger.error("Initial check-in failed after all retries. Exiting.")
                sys.exit(1)
```

**3b. Main loop (lines 68-229):** Wrap the body of the `while True` loop in a try/except that catches all exceptions except `KeyboardInterrupt`, logs, and continues. Structure:

```python
try:
    while True:
        try:
            # ... entire existing loop body (lines 69-228, unchanged) ...
        except KeyboardInterrupt:
            raise  # re-raise to hit the outer handler
        except Exception as exception:
            logger.error(f"Error in monitor loop, will retry: {exception}")
            sleep(10)
            continue
except KeyboardInterrupt:
    # existing shutdown logic (lines 231-241, unchanged)
```

### Change 4: `daemons/launch_service.py` — Harden systemd service template

The current `populate()` method (line 158-163) generates a `[Service]` section with only `Restart = always`. With systemd defaults (`RestartSec=100ms`, `StartLimitBurst=5`, `StartLimitIntervalSec=10`), a rapid crash loop hits the restart limit in ~1 second and systemd **permanently stops the service**.

Add `RestartSec` to slow down restarts, and `StartLimitIntervalSec`/`StartLimitBurst` to give the service more room to recover:

```python
config["Service"] = {
    "ExecStart": f'/bin/sh -lc "{self.executable} {self.command}"',
    "Restart": "always",
    "RestartSec": "10",
    "StartLimitIntervalSec": "300",
    "StartLimitBurst": "10",
    "StandardError": f"append:{self.logs}",
    "StandardOutput": f"append:{self.logs}",
}
```

This means:
- Wait 10 seconds between restarts (instead of 100ms)
- Allow 10 restarts within a 5-minute window before giving up (instead of 5 in 10 seconds)
- Combined with the CLI-side retry logic (5 min messaging backoff + HTTP fallback), the service can survive a RabbitMQ outage of ~50 minutes before systemd gives up

**Note:** `StartLimitIntervalSec` and `StartLimitBurst` are `[Unit]` directives in newer systemd versions, but placing them in `[Service]` also works and is more portable. If we want to be strict, move them to `[Unit]`:

```python
config["Unit"] = {
    "Description": "Primitive {} daemon".format(self.name),
    "After": "network.target",
    "StartLimitIntervalSec": "300",
    "StartLimitBurst": "10",
}
```

**Important:** Existing machines need to run `primitive daemons install` to regenerate the service file with these new settings.

### Change 5: `daemons/launch_service.py` — Enable loginctl linger on install

User-level systemd services (`~/.config/systemd/user/`) are killed when the user's last login session ends (SSH disconnect, logout). This causes the monitor to silently stop with no error in the logs — systemd just tears down the user service manager.

The fix is to enable `loginctl enable-linger` for the current user during daemon install. This tells systemd to keep the user's service manager running even with no active sessions.

Add to the `install()` method (line 218-228), before `self.start()`:

```python
def install(self) -> bool:
    # Enable linger so user services survive logout
    if not self.root_user:
        try:
            subprocess.check_output(
                ["loginctl", "enable-linger", os.environ.get("USER", "")],
                stderr=subprocess.DEVNULL,
            )
            logger.info("Enabled loginctl linger for current user.")
        except subprocess.CalledProcessError as exception:
            logger.warning(
                f"Failed to enable linger (may need sudo): {exception}"
            )

    return all(
        [
            self.stop(),
            self.disable(),
            self.create_stdout_file(),
            self.populate(),
            self.enable(),
            self.start(),
        ]
    )
```

**Note:** `loginctl enable-linger` may require sudo on some systems. If it fails, we log a warning but don't block the install — the service will still work as long as a session is active. The user can manually run `sudo loginctl enable-linger <username>` if needed.

## What NOT to Change

- `Messaging.__init__` — no changes to initialization or class interface
- `utils/auth.py` — reference only, no modifications
- `utils/exceptions.py` — no new exception classes needed
- No new dependencies — `backoff` is already available (transitive via `gql`)
- Monitor CLI command structure — no changes to how it's invoked

## Verification

1. `cd /Users/djstein/Development/primitivecorp/primitive-cli`
2. Run existing tests: `uv run pytest`
3. Verify the generated systemd service file includes `RestartSec` and `StartLimitIntervalSec`: run `primitive daemons install` on a test machine, then `cat ~/.config/systemd/user/tech.primitive.monitor.service`
4. Manual test: start the monitor, verify it connects to RabbitMQ and sends check-ins
5. Simulate RabbitMQ outage: temporarily block port 443 on the node, verify the monitor logs retries and falls back to HTTP, then recovers when connectivity is restored
