---
name: build-fix
description: Fix build and type errors with minimal changes
allowed-tools: Read, Edit, Write, Bash, Grep, Glob, Agent
---

# /build-fix — Fix Build Errors

Diagnose and fix build/type errors with minimal diffs.

## Steps

### 1. Detect Build System

Identify the project's build/type-check commands from `CLAUDE.md` or common patterns:
- Python: `mypy .`, `ruff check .`
- TypeScript: `npx tsc --noEmit`, `npm run build`

### 2. Collect Errors

Run the build command and capture all errors. Group by file.

### 3. Fix Loop

For each error:
1. Read the file and understand the error
2. Apply the minimal fix (type annotation, null check, import fix)
3. Re-run the build command
4. Move to next error if fixed, otherwise try an alternative fix

### 4. Guardrails

Stop and report if:
- Same error persists after 3 attempts
- Fix introduces more errors than it resolves
- Error requires architectural changes

### 5. Summary

Report fixed errors, remaining errors (if any), and verify tests still pass.

## Delegates To

- `build-error-resolver` agent for complex error chains
