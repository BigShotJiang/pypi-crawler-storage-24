---
name: deploy-check
description: Pre-deployment checklist — runs verification commands, checks for uncommitted changes, confirms migrations are applied, and surfaces any blockers before deploying.
argument-hint: [environment] (dev | test | prod — defaults to dev)
allowed-tools: Read, Bash, Glob
---

# /deploy-check — Pre-Deployment Checklist

Run this before deploying to catch common issues.

## Steps

1. **Check for uncommitted changes**
   ```bash
   git status --short
   ```
   Fail if there are uncommitted changes.

2. **Confirm on main (or release branch)**
   ```bash
   git branch --show-current
   ```
   Warn if not on `main`.

3. **Run verification commands**
   Read the `## Verification` section from this project's CLAUDE.md and run:
   - Format check
   - Lint
   - Tests

4. **Check for unapplied migrations** (backend only)
   ```bash
   make migrate --check
   ```
   Fail if there are pending migrations.

5. **Check CI status for current commit**
   ```bash
   gh run list --branch main --limit 5
   ```
   Warn if the latest run is not passing.

6. **Report**
   Output a pass/fail summary for each check. If any CRITICAL check fails, print:
   ```
   ❌ Deploy blocked — resolve the issues above before deploying.
   ```
   If all pass:
   ```
   ✅ All checks passed — ready to deploy to <environment>.
   ```
