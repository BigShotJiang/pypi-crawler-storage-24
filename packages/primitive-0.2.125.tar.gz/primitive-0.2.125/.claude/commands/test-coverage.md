---
name: test-coverage
description: Run coverage analysis and identify gaps in test coverage
allowed-tools: Read, Edit, Write, Bash, Grep, Glob
---

# /test-coverage — Coverage Analysis

Run test coverage and identify untested code.

## Steps

### 1. Detect Test Framework

Check for pytest, vitest, jest configuration in the project.

### 2. Run Coverage

```bash
# Python
pytest --cov=app --cov-report=term-missing --cov-report=html

# TypeScript
npx vitest run --coverage
```

### 3. Analyze Gaps

Identify:
- Files below 80% coverage
- Untested public functions
- Missing branch coverage (if/else paths)
- Untested error handlers

### 4. Report

```
## Coverage Report

Overall: XX%
Target: 80%

### Files Below Target
| File | Coverage | Missing Lines |
|------|----------|---------------|
| app/services/billing.py | 62% | 45-52, 78-85 |

### Recommended Tests
1. test_billing_calculation_with_discount — covers lines 45-52
2. test_billing_error_on_invalid_input — covers lines 78-85
```

### 5. Generate Tests (if requested)

If the user asks, generate tests for uncovered code following TDD patterns:
- Happy path first
- Then error handling
- Then edge cases
- Then branch coverage
