---
name: refactor-clean
description: Find and remove dead code, unused imports, and unnecessary dependencies
allowed-tools: Read, Edit, Write, Bash, Grep, Glob, Agent
---

# /refactor-clean — Dead Code Cleanup

Identify and safely remove dead code, unused imports, and unnecessary dependencies.

## Steps

### 1. Detect Dead Code

Run detection tools:
```bash
# Python
vulture .
ruff check --select F811,F401 .

# TypeScript
npx knip
npx depcheck
```

### 2. Categorize

- **SAFE**: Unused imports, unused private functions, unused dependencies
- **CAUTION**: Unused exports (may have dynamic consumers)
- **DANGER**: Config files, entry points — skip these

### 3. Remove Safely

Start with SAFE items only:
1. Remove one category at a time
2. Run tests after each batch
3. Commit after each batch

### 4. Report

Summary of what was removed, what was skipped, and verification results.

## Delegates To

- `refactor-cleaner` agent for analysis and safe removal
