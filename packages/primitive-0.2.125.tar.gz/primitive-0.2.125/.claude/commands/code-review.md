---
name: code-review
description: Review uncommitted changes for quality, security, and correctness
allowed-tools: Read, Bash, Grep, Glob, Agent
---

# /code-review — Review Uncommitted Changes

Review all uncommitted changes (staged and unstaged) for issues before committing. This is distinct from `/review` which reviews PR-level changes.

## Steps

### 1. Gather Changes

```bash
git diff --name-only HEAD
git diff HEAD
```

### 2. Review Each File

For each changed file, check:
- **CRITICAL**: Security vulnerabilities, logic errors, data loss risks
- **HIGH**: Performance issues, missing tests, incorrect error handling
- **MEDIUM**: Convention violations, missing validation

### 3. Confidence Filter

Only report issues where confidence is >80%. Consolidate similar issues. Skip style-only concerns unless they violate project conventions.

### 4. Report

```
### <filename>

**Summary**: What changed

**Issues**:
- [CRITICAL] description — line N
- [HIGH] description — line N

**Strengths**:
- What was done well
```

End with overall assessment and verdict: APPROVE / CHANGES REQUESTED.

## Delegates To

- `reviewer` agent for the review itself
- `python-reviewer` agent for Python-specific checks
- `typescript-reviewer` agent for TypeScript/React-specific checks
