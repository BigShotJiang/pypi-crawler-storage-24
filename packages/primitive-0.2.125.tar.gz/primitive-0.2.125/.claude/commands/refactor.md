---
name: refactor
description: Refactor a file or module for clarity and maintainability — without changing behavior. Runs verification after to confirm nothing broke.
argument-hint: <file-or-directory>
allowed-tools: Read, Edit, Bash, Glob, Grep
---

# /refactor — Refactor Without Behavior Change

Refactor the specified file or module. The goal is improved clarity and maintainability — **not** new features or performance optimization unless explicitly requested.

## Rules

- Do NOT change behavior
- Do NOT add features
- Do NOT change the public API (function signatures, exported names)
- Keep changes reviewable — prefer many small commits over one large one
- Run verification after every logical chunk of changes

## Steps

1. **Read** the target file(s) and understand the current structure

2. **Identify** specific issues:
   - Long functions that should be split
   - Unclear variable or function names
   - Duplicated logic
   - Dead code
   - Unnecessary complexity

3. **Plan** the refactoring steps (list them before starting)

4. **Apply** changes incrementally

5. **Verify** after each step — read the `## Verification` section from CLAUDE.md and run the relevant commands (at minimum, lint and tests)

6. **Report** what changed and confirm all verification checks pass

## What Not to Do

- Do not refactor code you were not asked to refactor
- Do not change tests unless they need updating due to the refactor
- Do not introduce new abstractions speculatively ("this might be useful later")
