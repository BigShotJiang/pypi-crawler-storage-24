---
name: ticket
description: Fetch and display a Linear ticket's details, including description, status, assignee, labels, and related PRs.
argument-hint: <ticket-id-or-url>
allowed-tools: Bash, mcp__linear-server__get_issue
---

# /ticket — View Linear Ticket

Fetch and display a Linear ticket.

## Steps

1. Parse the ticket ID from the argument (handle plain IDs like "ENG-537" and full Linear URLs)

2. Fetch the issue via `mcp__linear-server__get_issue`

3. Display in a structured format:

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
ENG-537 — <Title>
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Status:   <state>
Assignee: <name or unassigned>
Labels:   <labels>
Priority: <priority>

Description:
<description>

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

4. If there is a related GitHub branch, show it:
   ```bash
   gh pr list --search "ENG-537" --json number,title,url,state
   ```

## Error Handling

- If ticket not found, show a clear error and suggest verifying the ticket ID
- If Linear MCP is unavailable, show a message asking the user to check their MCP config
