---
name: review
description: Conduct a thorough code review of changed files in the current branch. Reviews for correctness, security, performance, and adherence to project conventions.
argument-hint: [file-or-directory] (optional — defaults to all changes vs main)
allowed-tools: Read, Glob, Grep, Bash
---

# /review — Code Review

Review changed files in the current branch (or a specific file/directory if provided).

## What to Review

For each changed file:

1. **Correctness** — Does the logic do what it claims? Are edge cases handled?
2. **Security** — SQL injection, XSS, command injection, IDOR, exposed secrets?
3. **Performance** — N+1 queries, unbounded loops, missing indexes, unnecessary work?
4. **Tests** — Are new behaviors tested? Do tests actually verify the behavior?
5. **Conventions** — Does the code follow the patterns in `.claude/rules/`?
6. **Simplicity** — Is there unnecessary complexity, over-abstraction, or dead code?

## Output Format

```
## Review: <filename>

**Summary**: [1-2 sentences]

**Issues:**
- [CRITICAL] <description> — <file>:<line>
- [IMPORTANT] <description> — <file>:<line>
- [SUGGESTION] <description> — <file>:<line>

**Good:**
- [what was done well]
```

Use CRITICAL for bugs and security issues, IMPORTANT for correctness and perf, SUGGESTION for style.

## Steps

1. Get changed files: `git diff --name-only main...HEAD` (or use the argument if provided)
2. Read each changed file
3. Read relevant context files (tests, related modules) as needed
4. Output the structured review for each file
5. Finish with an overall summary: total issues by severity, whether the PR is ready to merge
