---
name: tdd
description: Start TDD workflow — write failing test, implement, refactor, verify coverage
argument-hint: <feature-or-function-description>
allowed-tools: Read, Edit, Write, Bash, Grep, Glob, Agent
---

# /tdd — Test-Driven Development

Run the TDD cycle for a feature or function.

## Steps

### 1. Understand

Read the feature description or ticket. Identify the behavior to implement.

### 2. Write Failing Test (RED)

Write a test that describes the expected behavior. Run it — it must fail.

### 3. Implement (GREEN)

Write the minimum code to make the test pass. Nothing extra.

### 4. Refactor (IMPROVE)

Clean up while tests stay green. Remove duplication, improve naming.

### 5. Edge Cases

Add tests for null/empty input, invalid values, boundary conditions, error paths.

### 6. Verify Coverage

Run coverage and confirm 80%+ on new code:
```bash
# Python
pytest --cov=app --cov-report=term-missing

# TypeScript
npx vitest run --coverage
```

Report results to the user.

## Delegates To

- `tdd-guide` agent for enforcement and guidance
- `tdd-workflow` skill for detailed patterns
