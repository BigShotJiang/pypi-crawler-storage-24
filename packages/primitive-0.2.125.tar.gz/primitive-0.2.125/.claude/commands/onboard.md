---
name: onboard
description: New developer onboarding guide — walks through repo setup, explains architecture, and gets the dev environment running.
argument-hint: (none)
allowed-tools: Read, Bash, Glob
---

# /onboard — New Developer Onboarding

Welcome to the team. This command walks you through setting up this repo and understanding the codebase.

## Steps

### 1. Read CLAUDE.md

Read this project's CLAUDE.md to understand:
- Project overview and tech stack
- Common commands
- Architecture
- Development workflow

### 2. Check Prerequisites

Verify required tools are installed:
```bash
# Adjust per project type
which git gh make
```

Report any missing tools with installation instructions.

### 3. Environment Setup

Read the `## Common Commands` section from CLAUDE.md and run the initial setup command (typically `make setup`).

If setup fails, diagnose the error and suggest a fix.

### 4. Explain Architecture

Give a tour of the main directories and what each contains. Focus on:
- Where the entry point is
- Where data models/schemas live
- Where tests live
- How a typical feature flows through the system

### 5. First Task Suggestion

Suggest the new developer's next steps:
1. Find a "good first issue" label in Linear
2. Run `/plan-work <ticket-id>` to start working on it

## Output

Structure the output as a readable guide, not a wall of text. Use headers, bullet points, and code blocks.
