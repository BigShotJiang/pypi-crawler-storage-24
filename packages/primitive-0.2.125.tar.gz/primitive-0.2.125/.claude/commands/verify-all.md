---
name: verify-all
description: Run full verification pipeline — format, lint, type-check, test, security scan
allowed-tools: Read, Bash, Grep, Glob
---

# /verify-all — Full Verification Pipeline

Run the complete verification pipeline. This is a command alias that delegates to the `/verify` skill with all checks enabled.

## Steps

### 1. Read Verification Commands

Read the `## Verification` section from the project's `CLAUDE.md` for exact commands.

### 2. Run All Checks

Execute in order:
1. Format check
2. Lint check
3. Type check
4. Test suite
5. Security scan (if available)

### 3. Report

```
## Verification Results

| Check | Status |
|-------|--------|
| Format | PASS/FAIL |
| Lint | PASS/FAIL |
| Types | PASS/FAIL |
| Tests | PASS (N passed) / FAIL |
| Security | PASS/FAIL |

Ready for PR: YES / NO
```

If any check fails, report details and stop.
