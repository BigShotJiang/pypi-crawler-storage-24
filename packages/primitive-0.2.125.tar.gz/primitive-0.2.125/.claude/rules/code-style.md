# Code Style

## General Principles

- Write the minimum code needed for the task. Do not over-engineer.
- Do not add features, refactor, or "improve" beyond what was explicitly requested.
- Do not add docstrings, comments, or type annotations to code you didn't change.
- Only add comments where logic is not self-evident.
- Do not add error handling for scenarios that cannot happen. Trust internal code and framework guarantees.
- Do not create helpers or abstractions for one-time operations.
- Three similar lines of code is better than a premature abstraction.

## File Operations

Always use dedicated tools (Read, Edit, Write) rather than bash commands for file operations:
- Read files with Read, not `cat`/`head`/`tail`
- Edit files with Edit, not `sed`/`awk`
- Create files with Write, not `echo >` or heredoc
- Search files with Grep, not `grep`/`rg`
- Find files with Glob, not `find`/`ls`

## Security

- Never introduce SQL injection, XSS, command injection, or other OWASP top 10 vulnerabilities.
- Never commit `.env` files or secrets.
- Only validate at system boundaries (user input, external APIs); trust internal code.
- If you write insecure code, fix it immediately.

## Commits and PRs

See `git-conventions.md` for branch naming, commit format, and PR rules.
