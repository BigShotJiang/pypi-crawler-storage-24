# CLI UX Patterns

## General

- CLI is `primitive` — entry point at `primitive.cli:cli` (Click-based)
- Global options: `--host`, `--yes`, `--debug`, `--json`, `-v/--verbose`
- All subcommands access the `Primitive` client via Click context (`context.obj["PRIMITIVE"]`)

## Command Structure

- Commands live in `commands.py` per module; business logic in `actions.py`
- `actions.py` classes extend `BaseAction` and hold a reference to the `Primitive` client via `self.primitive`
- Keep commands thin: parse args, call action, display result

## Output

- Use Rich for all terminal output (tables, progress, status)
- Table rendering goes in `ui.py` per module
- Respect `--json` flag: output machine-readable JSON instead of Rich tables when set
- Respect `--debug` flag: enable verbose logging via loguru

## Error Handling

- Use the `@guard` decorator for all API calls — it handles backoff retry and lazy session creation
- Return descriptive error messages; do not expose raw stack traces to users
- Non-zero exit code on failure; zero only on success

## Interactivity

- Use `--yes` / `-y` to skip confirmation prompts in scripted contexts
- Confirm destructive operations before proceeding unless `--yes` is set
- Progress indicators for long-running operations (downloads, uploads, polling)

## API Communication

- GraphQL via `gql` with aiohttp transport for primary API
- REST via `requests.Session` for file uploads
- RabbitMQ/AMQP via `pika` for messaging (hardware check-ins, events)
- Redfish for BMC/out-of-band hardware management
