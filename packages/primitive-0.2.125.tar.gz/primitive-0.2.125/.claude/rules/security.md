# Security Rules

## Secrets and Credentials

- Never commit `.env` files, credentials, API keys, or secrets of any kind
- Never log secrets, tokens, or passwords
- Environment variables are the only acceptable way to pass secrets at runtime
- Use secrets managers (AWS Secrets Manager, etc.) for shared secrets

## Input Validation

- Validate at system boundaries: user input, external API responses, webhook payloads
- Trust internal code and framework guarantees — do not add redundant checks
- Sanitize all user input before use in database queries, shell commands, or HTML output

## Common Vulnerabilities to Avoid

- **SQL injection**: Always use ORM or parameterized queries, never string interpolation in queries
- **XSS**: Never render user-supplied content as raw HTML without escaping
- **Command injection**: Never pass user input to shell commands; use `subprocess` with a list, never `shell=True`
- **CSRF**: Ensure CSRF tokens are present on all state-changing forms and API endpoints
- **IDOR**: Always check object-level authorization before returning or modifying data
- **Path traversal**: Validate and sanitize file paths; never construct paths from user input

## Authentication and Authorization

- Always verify authentication before accessing protected resources
- Apply least-privilege: grant only the permissions actually needed
- Log authentication failures for monitoring

## Dependencies

- Do not add new dependencies without considering their security track record
- Keep dependencies up to date; address known CVEs promptly

## Reporting

If you discover a security issue in the codebase while working on a task, flag it immediately before proceeding.
