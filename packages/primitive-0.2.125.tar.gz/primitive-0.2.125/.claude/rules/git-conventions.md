# Git Conventions

## Branch Naming

Follow the Linear GitHub branch naming convention:

```
<username>/eng-<ticket-number>-<description>
```

- `<username>`: Linear displayName, lowercase, no spaces
- `<ticket-number>`: numeric part only (e.g., "537" from "ENG-537")
- `<description>`: slugified ticket title, lowercase, hyphens, max 50 chars

Example: `dylan/eng-537-adds-global-projects`

## Commit Messages

- Use imperative mood: "Add feature" not "Added feature"
- First line: 50 chars or less, no period
- Body (if needed): wrap at 72 chars, explain _why_ not _what_
- Reference ticket in body when relevant: `Closes ENG-537`

## PR Rules

- Title mirrors the commit message style (imperative, ≤70 chars)
- Body must include: summary bullets, test plan checklist
- Request Copilot review via `gh copilot-review`
- Address all review feedback before merging
- Resolve threads after addressing feedback

## Workflow

**Always use the two-phase skill workflow for ticket work:**

1. `/plan-work <ticket-id>` — fetch ticket, create branch, worktree, plan
2. `/start-work <ticket-id>` — implement, test, self-review, PR, Copilot review

Never implement a plan manually. Never skip `/plan-work` before `/start-work`.

## Worktrees

- Created at `worktrees/<branch-name>` relative to repo root
- One worktree per ticket
- If worktree exists, reuse it; do not recreate unless explicitly asked

## Safety

- Never force-push to `main`/`master`
- Never skip pre-commit hooks (`--no-verify`)
- Never amend published commits
- Prefer new commits over amending existing ones
- Stage specific files; avoid `git add -A` or `git add .`
