# Testing Rules

## General

- Write tests for all new features and bug fixes
- Tests must pass before opening a PR
- Do not disable or skip tests to make CI pass; fix the underlying issue

## Test Scope

- Unit tests: test one function or class in isolation
- Integration tests: test interactions between components (e.g., API endpoint + database)
- E2E tests: reserved for critical user flows; require explicit justification to add

## What to Test

- Happy path: the expected successful case
- Error cases: invalid input, missing data, authorization failures
- Edge cases: empty lists, null values, boundary conditions
- Do NOT write tests for internal implementation details — test behavior, not structure

## Test Quality

- Tests should be deterministic (no flakiness)
- Tests should be independent (no shared mutable state between tests)
- Use factories/fixtures for test data; do not hardcode IDs or magic strings
- Prefer descriptive test names: `test_user_cannot_access_other_org_projects` over `test_access_2`

## Running Tests

See the `## Verification` section in this project's CLAUDE.md for the exact commands.

## Self-Review Checklist for Tests

- Does the test actually fail if the code it tests is removed?
- Are error paths tested as well as happy paths?
- Are any async operations awaited correctly?
- Is test data cleaned up after each test?
