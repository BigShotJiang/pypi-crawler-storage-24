# Development Workflow

## Feature Implementation Pipeline

### 1. Plan First
- Use `/plan-work` to create an implementation plan before writing code
- Plans are saved to `.claude/plans/<ticket-id>-plan.md`
- Identify dependencies, risks, and testing strategy

### 2. TDD Approach
- Write tests first (RED) — verify they fail
- Write minimal implementation (GREEN) — just enough to pass
- Refactor (IMPROVE) — clean up while tests stay green
- Verify 80%+ coverage

### 3. Code Review
- Use `/review` or the reviewer agent after writing code
- Address CRITICAL and HIGH issues before committing
- Fix MEDIUM issues when practical

### 4. Verify
- Use `/verify` to run format, lint, and test before pushing
- All checks must pass before opening a PR

### 5. Commit & Submit
- Use `/start-work` for the full pipeline, or individual skills as needed
- Follow commit conventions in `git-conventions.md`

## Research Before Coding

Before implementing anything new:
- Search the codebase for existing patterns that solve the same problem
- Check if a library already handles the use case
- Look at how similar features were built in the project
- Prefer adapting existing code over writing from scratch
