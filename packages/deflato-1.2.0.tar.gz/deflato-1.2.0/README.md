# Deflato Python SDK

Compress images with one line of code. Powered by [deflato.com](https://deflato.com).

## Install

```bash
pip install deflato
```

## Quick Start

```python
from deflato import Deflato

client = Deflato("your-api-key")

# Compress a single image
result = client.compress("photo.jpg", format="WEBP", quality=75)
print(f"Saved {result.savings_percent}% → {result.output_path}")

# Get info without saving
info = client.info("photo.jpg", format="AVIF")
print(f"{info.input_size:,} → {info.output_size:,} bytes ({info.savings_percent}% savings)")

# Batch compress
results = client.compress_batch(
    ["img1.jpg", "img2.png", "img3.heic"],
    output_dir="./compressed",
    format="WEBP",
    quality=80,
)
for r in results:
    print(f"{r.output_path}: {r.savings_percent}%")
```

## API

### `Deflato(api_key, base_url="https://deflato.com")`

### `client.compress(input_path, output=None, quality=80, max_dimension=0, format="JPEG", strip_exif=True)`

Returns `CompressResult`:
- `success: bool`
- `input_size: int` (bytes)
- `output_size: int` (bytes)
- `savings_percent: int`
- `output_path: str`
- `output_format: str`

### `client.info(input_path, quality=80, format="JPEG")`

Same as compress but doesn't save — returns size/dimension info.

### `client.compress_batch(input_paths, output_dir=None, quality=80, format="JPEG")`

Compress multiple files. Returns list of `CompressResult`.

## Supported Formats

**Input:** JPEG, PNG, WEBP, HEIC, TIFF, BMP, GIF, RAW (CR2, NEF, ARW, DNG)

**Output:** JPEG, PNG, WEBP, AVIF

## Get API Key

1. Sign up at [deflato.com](https://deflato.com)
2. Activate Pro (or use promo code)
3. Go to [Account](https://deflato.com/en/account) → Generate API Key

## License

MIT
