# northcli

`northcli` is the local CLI for North Star spec-driven delivery.

## Install

### Option 1 (recommended): pipx

```bash
pipx install northcli
```

### Option 2: user install via pip

```bash
python3 -m pip install --user northcli
```

### Option 3: installer script

macOS/Linux:

```bash
curl -fsSL https://raw.githubusercontent.com/<ORG_OR_USER>/<REPO>/main/scripts/install_northcli.sh | bash
```

Windows PowerShell:

```powershell
iwr https://raw.githubusercontent.com/<ORG_OR_USER>/<REPO>/main/scripts/install_northcli.ps1 -UseBasicParsing | iex
```

For local development installs from this repo, run:

```bash
./scripts/install_northcli.sh "" local
```

## Verify

```bash
northcli --help
northcli login --api-url http://localhost:8000/api/v1
northcli projects
northcli init --project-id 3
northcli ready
northcli pull STORY-123
northcli run STORY-123 --agent codex --copy
northcli done STORY-123 --report-file codex-report.txt --auto-git --status verified
```

`northcli pull` copies the agent prompt (`STORY-123.task.md`) to your clipboard by default.

`northcli run` pulls the story and prepares a single handoff prompt for your agent.
Use `--copy` to copy the full handoff prompt to clipboard.

`northcli done` can parse a structured completion report file and auto-attach git metadata.

If you need to re-copy later:

```bash
northcli copy-prompt STORY-123
```

## Config layout

- Global auth config: `~/.config/northcli/config.toml`
- Local project config: `.northcli/config.toml`
- Local story packs: `.northcli/projects/<project_id>/stories/`

## Maintainer release flow

1. Bump version in `pyproject.toml`.
2. Push a git tag `northcli-vX.Y.Z`.
3. GitHub Action `Release northcli` builds and publishes to PyPI.

Use PyPI Trusted Publishing with repository environment `pypi`.

Detailed runbook: `../docs/northcli_release_runbook.md`.
