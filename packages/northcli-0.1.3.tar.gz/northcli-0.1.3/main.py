from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
from pathlib import Path
from typing import Any

import httpx
import typer

app = typer.Typer(help="northcli for North Star spec delivery")

LOCAL_CONFIG_DIR = Path(".northcli")
LOCAL_CONFIG_PATH = LOCAL_CONFIG_DIR / "config.toml"
LOCAL_PROJECTS_DIR = LOCAL_CONFIG_DIR / "projects"
LOCAL_STORIES_DIR = LOCAL_CONFIG_DIR / "stories"

LEGACY_LOCAL_CONFIG_DIR = Path(".specctl")
LEGACY_LOCAL_CONFIG_PATH = LEGACY_LOCAL_CONFIG_DIR / "config.toml"
LEGACY_LOCAL_STORIES_DIR = LEGACY_LOCAL_CONFIG_DIR / "stories"


def _default_global_config_dir() -> Path:
    if os.name == "nt":
        appdata = os.environ.get("APPDATA")
        if appdata:
            return Path(appdata) / "northcli"
    xdg = os.environ.get("XDG_CONFIG_HOME")
    if xdg:
        return Path(xdg) / "northcli"
    return Path.home() / ".config" / "northcli"


GLOBAL_CONFIG_DIR = Path(os.environ.get("NORTHCLI_CONFIG_DIR", _default_global_config_dir()))
GLOBAL_CONFIG_PATH = GLOBAL_CONFIG_DIR / "config.toml"


def _parse_work_item_ref(story: str) -> tuple[str | None, int]:
    raw = story.strip().upper()
    if raw.startswith("STORY-") or raw.startswith("BUG-"):
        prefix, suffix = raw.split("-", 1)
        if not re.fullmatch(r"\d+", suffix):
            raise typer.BadParameter("Key must be STORY-<number> or BUG-<number>")
        return prefix, int(suffix)
    if not re.fullmatch(r"\d+", raw):
        raise typer.BadParameter("Work item must be numeric, STORY-123, or BUG-123")
    return None, int(raw)


def _resolve_local_story_key(project_id: int, story: str, suffix: str) -> str:
    prefix, local_id = _parse_work_item_ref(story)
    candidates = (
        [f"{prefix}-{local_id}"] if prefix else [f"BUG-{local_id}", f"STORY-{local_id}"]
    )
    for candidate in candidates:
        if _find_story_file(project_id, candidate, suffix) is not None:
            return candidate
    raise typer.Exit(
        f"Missing local file for reference '{story}' in project_id={project_id} storage."
    )


def _parse_toml_like(path: Path) -> dict[str, Any]:
    parsed: dict[str, Any] = {}
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = [p.strip() for p in line.split("=", 1)]
        if value.startswith('"') and value.endswith('"'):
            parsed[key] = value[1:-1]
        elif value.isdigit():
            parsed[key] = int(value)
        else:
            parsed[key] = value
    return parsed


def _write_toml_like(path: Path, data: dict[str, Any], chmod_600: bool = False) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    lines: list[str] = []
    for key, value in data.items():
        if isinstance(value, int):
            lines.append(f"{key} = {value}")
        else:
            escaped = str(value).replace('"', '\\"')
            lines.append(f'{key} = "{escaped}"')
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    if chmod_600:
        try:
            path.chmod(0o600)
        except Exception:
            pass


def _read_global_config() -> dict[str, Any]:
    if GLOBAL_CONFIG_PATH.exists():
        parsed = _parse_toml_like(GLOBAL_CONFIG_PATH)
        required = {"api_url", "token"}
        missing = required - set(parsed)
        if missing:
            raise typer.BadParameter(
                f"Invalid global config {GLOBAL_CONFIG_PATH}. Missing: {', '.join(sorted(missing))}"
            )
        return parsed

    if LEGACY_LOCAL_CONFIG_PATH.exists():
        parsed = _parse_toml_like(LEGACY_LOCAL_CONFIG_PATH)
        if {"api_url", "token"}.issubset(set(parsed)):
            return parsed

    raise typer.BadParameter(
        f"Missing global auth config. Run `northcli login` to create {GLOBAL_CONFIG_PATH}."
    )


def _read_local_config(required: bool = True) -> dict[str, Any] | None:
    if LOCAL_CONFIG_PATH.exists():
        parsed = _parse_toml_like(LOCAL_CONFIG_PATH)
        if "project_id" not in parsed:
            raise typer.BadParameter(
                f"Invalid local config {LOCAL_CONFIG_PATH}. Missing: project_id"
            )
        return parsed

    if LEGACY_LOCAL_CONFIG_PATH.exists():
        parsed = _parse_toml_like(LEGACY_LOCAL_CONFIG_PATH)
        if "project_id" in parsed:
            return parsed

    if required:
        raise typer.BadParameter(
            "Missing local repo config. Run `northcli init` in this repository."
        )
    return None


def _stories_dir() -> Path:
    if LOCAL_STORIES_DIR.exists():
        return LOCAL_STORIES_DIR
    if LEGACY_LOCAL_STORIES_DIR.exists():
        return LEGACY_LOCAL_STORIES_DIR
    return LOCAL_STORIES_DIR


def _project_stories_dir(project_id: int) -> Path:
    return LOCAL_PROJECTS_DIR / str(project_id) / "stories"


def _find_story_file(project_id: int, story_key: str, suffix: str) -> Path | None:
    candidates = [
        _project_stories_dir(project_id) / f"{story_key}{suffix}",
        _stories_dir() / f"{story_key}{suffix}",
        LEGACY_LOCAL_STORIES_DIR / f"{story_key}{suffix}",
    ]
    for path in candidates:
        if path.exists():
            return path
    return None


def _resolve_story_id_for_pull(
    story: str, api_url: str, token: str, project_id: int
) -> tuple[int, str]:
    prefix, local_id = _parse_work_item_ref(story)
    requested_key = f"{prefix}-{local_id}" if prefix else None
    with _client(api_url, token) as client:
        resp = client.get(f"/spec-cli/projects/{project_id}/stories/ready")
        _ensure_ok(resp, "List ready stories")
        stories = resp.json()
    numeric_matches: list[tuple[int, str]] = []
    for item in stories:
        key = str(item.get("key", "")).upper()
        if requested_key:
            if key == requested_key:
                return int(item["id"]), key
            continue
        match = re.fullmatch(r"(STORY|BUG)-(\d+)", key)
        if match and int(match.group(2)) == local_id:
            numeric_matches.append((int(item["id"]), key))
    if not requested_key and numeric_matches:
        if len(numeric_matches) == 1:
            return numeric_matches[0]
        story_match = [entry for entry in numeric_matches if entry[1].startswith("STORY-")]
        bug_match = [entry for entry in numeric_matches if entry[1].startswith("BUG-")]
        if len(story_match) == 1 and len(bug_match) == 0:
            return story_match[0]
        if len(bug_match) == 1 and len(story_match) == 0:
            return bug_match[0]
        raise typer.Exit(
            f"Reference '{local_id}' is ambiguous in project_id={project_id}. "
            f"Use explicit key: STORY-{local_id} or BUG-{local_id}."
        )
    searched = requested_key or str(local_id)
    raise typer.Exit(
        f"{searched} was not found in ready stories for project_id={project_id}. "
        "Run `northcli ready` to see valid keys."
    )


def _client(api_url: str, token: str) -> httpx.Client:
    return httpx.Client(
        base_url=api_url.rstrip("/"),
        headers={"Authorization": f"Bearer {token}"},
        timeout=30.0,
    )


def _extract_detail(response: httpx.Response) -> str:
    detail = response.text
    try:
        payload = response.json()
        if isinstance(payload, dict):
            detail = str(payload.get("detail", detail))
    except Exception:
        pass
    return detail


def _ensure_ok(response: httpx.Response, action: str) -> None:
    if response.status_code >= 400:
        detail = _extract_detail(response)
        raise typer.Exit(f"{action} failed ({response.status_code}): {detail}")


def _validate_pat(api_url: str, token: str) -> dict[str, Any]:
    try:
        with _client(api_url, token) as client:
            resp = client.get("/spec-cli/auth/pat/validate")
    except httpx.HTTPError as exc:
        raise typer.Exit(f"Token validation failed: unable to reach API at {api_url} ({exc})") from exc
    _ensure_ok(resp, "Token validation")
    payload = resp.json()
    if not isinstance(payload, dict):
        raise typer.Exit("Token validation failed: unexpected response format")
    return payload


def _resolved_api_url(global_cfg: dict[str, Any], local_cfg: dict[str, Any] | None = None) -> str:
    if local_cfg and local_cfg.get("api_url"):
        return str(local_cfg["api_url"])
    return str(global_cfg["api_url"])


def _copy_to_clipboard(text: str) -> bool:
    if os.name == "nt":
        clip_cmd = shutil.which("clip")
        if clip_cmd:
            subprocess.run([clip_cmd], input=text, text=True, check=True)
            return True
        return False

    pbcopy_cmd = shutil.which("pbcopy")
    if pbcopy_cmd:
        subprocess.run([pbcopy_cmd], input=text, text=True, check=True)
        return True

    xclip_cmd = shutil.which("xclip")
    if xclip_cmd:
        subprocess.run([xclip_cmd, "-selection", "clipboard"], input=text, text=True, check=True)
        return True

    wl_copy_cmd = shutil.which("wl-copy")
    if wl_copy_cmd:
        subprocess.run([wl_copy_cmd], input=text, text=True, check=True)
        return True

    return False


def _pull_task_pack(
    *,
    story: str,
    api_url: str,
    token: str,
    project_id: int,
) -> tuple[str, dict[str, Any], Path]:
    story_id, requested_story_key = _resolve_story_id_for_pull(
        story=story,
        api_url=api_url,
        token=token,
        project_id=project_id,
    )
    with _client(api_url, token) as client:
        resp = client.get(f"/spec-cli/stories/{story_id}/task-pack")
        _ensure_ok(resp, "Pull story")
        payload = resp.json()

    stories_dir = _project_stories_dir(project_id)
    stories_dir.mkdir(parents=True, exist_ok=True)
    story_key = str(payload.get("key", requested_story_key))

    (stories_dir / f"{story_key}.md").write_text(payload["story_md"], encoding="utf-8")
    (stories_dir / f"{story_key}.task.md").write_text(payload["task_md"], encoding="utf-8")
    (stories_dir / f"{story_key}.json").write_text(
        json.dumps(payload, indent=2, sort_keys=True), encoding="utf-8"
    )
    return story_key, payload, stories_dir


def _read_text_file(path: Path) -> str:
    if not path.exists():
        raise typer.Exit(f"File not found: {path}")
    return path.read_text(encoding="utf-8")


def _run_git_command(args: list[str]) -> str | None:
    git_cmd = shutil.which("git")
    if not git_cmd:
        return None
    try:
        result = subprocess.run(
            [git_cmd, *args],
            check=True,
            text=True,
            capture_output=True,
        )
    except Exception:
        return None
    value = result.stdout.strip()
    return value or None


def _collect_git_metadata() -> dict[str, str]:
    metadata: dict[str, str] = {}
    commit_sha = _run_git_command(["rev-parse", "HEAD"])
    branch = _run_git_command(["rev-parse", "--abbrev-ref", "HEAD"])
    dirty = _run_git_command(["status", "--porcelain"])
    if commit_sha:
        metadata["commit_sha"] = commit_sha
    if branch:
        metadata["branch"] = branch
    metadata["dirty"] = "true" if dirty else "false"
    return metadata


def _parse_completion_report(report_text: str) -> dict[str, str]:
    header_pattern = re.compile(r"^([A-Z_]+):\s*(.*)$")
    parsed: dict[str, str] = {}
    current_key: str | None = None
    current_lines: list[str] = []

    def _flush() -> None:
        nonlocal current_key, current_lines
        if current_key is None:
            return
        parsed[current_key] = "\n".join(current_lines).strip()
        current_key = None
        current_lines = []

    for raw_line in report_text.splitlines():
        line = raw_line.rstrip()
        match = header_pattern.match(line)
        if match:
            _flush()
            current_key = match.group(1)
            initial = match.group(2).strip()
            current_lines = [initial] if initial else []
            continue
        if current_key is not None:
            current_lines.append(line)

    _flush()
    return parsed


def _clean_optional(value: str | None) -> str | None:
    if value is None:
        return None
    cleaned = value.strip()
    if not cleaned:
        return None
    if cleaned.upper() == "N/A":
        return None
    return cleaned


def _launch_agent(agent: str, prompt: str) -> None:
    normalized = agent.strip().lower()
    if normalized != "codex":
        raise typer.Exit(
            f"Automatic execution is currently supported only for agent='codex' (got '{agent}')."
        )

    codex_cmd = os.environ.get("NORTHCLI_CODEX_CMD", "codex")
    if not shutil.which(codex_cmd):
        raise typer.Exit(
            f"Could not find '{codex_cmd}' on PATH. Install Codex CLI or set NORTHCLI_CODEX_CMD."
        )

    typer.echo(f"Launching {codex_cmd} with handoff prompt...")
    # Try positional prompt first.
    proc = subprocess.run([codex_cmd, prompt], check=False)
    if proc.returncode == 0:
        return

    # Fallback: feed prompt via stdin for CLIs that expect piped input.
    typer.echo("Codex positional prompt launch failed; retrying with stdin...")
    proc_stdin = subprocess.run([codex_cmd], input=prompt, text=True, check=False)
    if proc_stdin.returncode != 0:
        raise typer.Exit(
            f"Codex execution failed (exit={proc_stdin.returncode}). "
            "Use --no-exec and paste from clipboard manually."
        )


@app.command()
def login(
    token: str | None = typer.Option(None, help="PAT from /api/v1/spec/auth/pat"),
    api_url: str = typer.Option("http://localhost:8000/api/v1", help="Base API URL"),
) -> None:
    """Validate PAT and store global CLI credentials."""
    resolved_token = token or typer.prompt("PAT", hide_input=True).strip()
    if not resolved_token:
        raise typer.Exit("PAT is required. Re-run login and provide a valid token.")

    validate_payload = _validate_pat(api_url, resolved_token)
    _write_toml_like(
        GLOBAL_CONFIG_PATH,
        {
            "api_url": api_url,
            "token": resolved_token,
        },
        chmod_600=True,
    )

    typer.echo(
        "Login successful. "
        f"(user_id={validate_payload.get('user_id')}, org_id={validate_payload.get('org_id')})"
    )
    typer.echo(f"Saved global config: {GLOBAL_CONFIG_PATH}")


@app.command("auth-check")
def auth_check() -> None:
    """Verify configured PAT and display auth context."""
    global_cfg = _read_global_config()
    payload = _validate_pat(str(global_cfg["api_url"]), str(global_cfg["token"]))
    local_cfg = _read_local_config(required=False)
    project_id = local_cfg.get("project_id") if local_cfg else None
    typer.echo(
        "Authenticated. "
        f"user_id={payload.get('user_id')} org_id={payload.get('org_id')} "
        f"project_id={project_id if project_id is not None else 'not initialized'}"
    )


@app.command("projects")
def list_projects_cmd() -> None:
    """List projects available for the current PAT/org."""
    global_cfg = _read_global_config()
    api_url = _resolved_api_url(global_cfg)
    token = str(global_cfg["token"])

    with _client(api_url, token) as client:
        resp = client.get("/spec-cli/projects")
        _ensure_ok(resp, "List projects")
        projects = resp.json()

    if not projects:
        typer.echo("No projects available.")
        return

    typer.echo("Projects:")
    for item in projects:
        typer.echo(f"- id={item['id']} name={item['name']}")


@app.command()
def init(project_id: int | None = typer.Option(None, help="Project ID to bind")) -> None:
    """Bind current repository to a project."""
    global_cfg = _read_global_config()
    api_url = _resolved_api_url(global_cfg)
    token = str(global_cfg["token"])

    with _client(api_url, token) as client:
        resp = client.get("/spec-cli/projects")
        _ensure_ok(resp, "List projects")
        projects = resp.json()

    if not projects:
        raise typer.Exit("No projects available. Create one in the API first.")

    selected = project_id
    if selected is None:
        selected = int(projects[0]["id"])

    if selected not in {int(p["id"]) for p in projects}:
        raise typer.Exit(f"Project {selected} not found in accessible projects")

    _write_toml_like(
        LOCAL_CONFIG_PATH,
        {
            "project_id": int(selected),
        },
        chmod_600=False,
    )
    typer.echo(f"Initialized local repo config: {LOCAL_CONFIG_PATH} (project_id={selected})")


@app.command("ready")
def list_ready_cmd(
    project_id: int | None = typer.Option(None, help="Project ID override; defaults to local init"),
) -> None:
    """List Ready stories for the initialized project (or provided project_id)."""
    global_cfg = _read_global_config()
    local_cfg = _read_local_config(required=project_id is None)
    if project_id is not None:
        effective_project_id = project_id
    else:
        if local_cfg is None or "project_id" not in local_cfg:
            raise typer.Exit("Missing local repo config. Run `northcli init` in this repository.")
        effective_project_id = int(local_cfg["project_id"])

    api_url = _resolved_api_url(global_cfg, local_cfg)
    token = str(global_cfg["token"])
    with _client(api_url, token) as client:
        resp = client.get(f"/spec-cli/projects/{effective_project_id}/stories/ready")
        _ensure_ok(resp, "List ready stories")
        stories = resp.json()

    if not stories:
        typer.echo(f"No ready stories for project_id={effective_project_id}")
        return

    typer.echo(f"Ready stories for project_id={effective_project_id}:")
    for item in stories:
        typer.echo(
            f"- key={item['key']} priority={item['priority']} "
            f"size={item['size']} title={item['title']}"
        )


@app.command()
def pull(
    story: str,
    copy_prompt: bool = typer.Option(
        True,
        "--copy-prompt/--no-copy-prompt",
        help="Copy <KEY>.task.md content to clipboard after pull",
    ),
) -> None:
    """Pull a ready story task pack into .northcli/stories/."""
    global_cfg = _read_global_config()
    local_cfg = _read_local_config(required=True)

    api_url = _resolved_api_url(global_cfg, local_cfg)
    token = str(global_cfg["token"])
    project_id = int(local_cfg["project_id"])
    story_key, payload, stories_dir = _pull_task_pack(
        story=story,
        api_url=api_url,
        token=token,
        project_id=project_id,
    )
    task_md = str(payload["task_md"])

    typer.echo(f"Pulled {story_key} into {stories_dir} (project_id={project_id})")
    if copy_prompt:
        try:
            copied = _copy_to_clipboard(task_md)
        except Exception as exc:
            typer.echo(f"Pulled {story_key}, but clipboard copy failed: {exc}")
            return
        if copied:
            typer.echo(f"Copied agent prompt to clipboard from {story_key}.task.md")
        else:
            typer.echo(
                "Pulled story, but no clipboard tool found. "
                "Copy manually from the .task.md file."
            )


@app.command("run")
def run_story(
    story: str,
    agent: str = typer.Option("codex", "--agent", help="Agent target, e.g. codex|cursor"),
    exec_agent: bool | None = typer.Option(
        None,
        "--exec/--no-exec",
        help="Execute the agent command after pull (defaults to true for --agent codex)",
    ),
    copy_prompt: bool = typer.Option(
        True,
        "--copy/--no-copy",
        help="Copy the generated handoff prompt to clipboard",
    ),
) -> None:
    """Pull a story and prepare one-step handoff prompt for the coding agent."""
    global_cfg = _read_global_config()
    local_cfg = _read_local_config(required=True)

    api_url = _resolved_api_url(global_cfg, local_cfg)
    token = str(global_cfg["token"])
    project_id = int(local_cfg["project_id"])
    story_key, payload, stories_dir = _pull_task_pack(
        story=story,
        api_url=api_url,
        token=token,
        project_id=project_id,
    )

    task_md = str(payload["task_md"])
    contract_hash = str(payload.get("contract_hash", ""))
    handoff = (
        f"Implement {story_key} using the exact contract in the task pack below.\n"
        f"Project ID: {project_id}\n"
        f"Story ID: {payload.get('story_id')}\n"
        f"Contract Hash: {contract_hash}\n\n"
        "At completion, output the Required Completion Report block exactly as specified.\n\n"
        f"{task_md}"
    )
    should_exec = exec_agent if exec_agent is not None else (agent.strip().lower() == "codex")

    typer.echo(f"Pulled {story_key} into {stories_dir} (project_id={project_id})")
    if copy_prompt:
        try:
            copied = _copy_to_clipboard(handoff)
        except Exception as exc:
            typer.echo(f"Handoff prepared, but clipboard copy failed: {exc}")
            copied = False
        if copied:
            typer.echo("Copied agent handoff prompt to clipboard.")
        else:
            typer.echo("No clipboard tool found. Prompt printed below.")
            typer.echo("")
            typer.echo(handoff)
    else:
        typer.echo("")
        typer.echo(handoff)

    if should_exec:
        _launch_agent(agent=agent, prompt=handoff)


@app.command("copy-prompt")
def copy_prompt(story: str) -> None:
    """Copy local task prompt content to clipboard."""
    local_cfg = _read_local_config(required=True)
    project_id = int(local_cfg["project_id"])
    story_key = _resolve_local_story_key(project_id, story, ".task.md")
    task_path = _find_story_file(project_id, story_key, ".task.md")
    if task_path is None:
        raise typer.Exit(
            f"Missing local task prompt file for {story_key} in project_id={project_id} storage."
        )

    text = task_path.read_text(encoding="utf-8")
    try:
        copied = _copy_to_clipboard(text)
    except Exception as exc:
        raise typer.Exit(f"Clipboard copy failed: {exc}") from exc

    if not copied:
        raise typer.Exit(
            "No clipboard tool found. Install pbcopy (macOS), xclip/wl-copy (Linux), or use Windows clip."
        )

    typer.echo(f"Copied {story_key}.task.md to clipboard")


@app.command()
def done(
    story: str,
    summary: str | None = typer.Option(None, "--summary", help="Execution summary"),
    status: str | None = typer.Option(None, "--status", help="in_progress|verified"),
    tool: str = typer.Option("codex", "--tool", help="codex|cursor|other"),
    notes: str | None = typer.Option(None, "--notes"),
    notes_file: Path | None = typer.Option(None, "--notes-file", help="Path to notes markdown/text file"),
    report_file: Path | None = typer.Option(
        None,
        "--report-file",
        help="Path to completion report using required headers (SUMMARY, RESULT, COMMIT_SHA, PR_URL, CI_URL, ...)",
    ),
    auto_git: bool = typer.Option(False, "--auto-git", help="Auto-fill git commit metadata"),
    commit: str | None = typer.Option(None, "--commit"),
    pr_url: str | None = typer.Option(None, "--pr-url"),
    ci_url: str | None = typer.Option(None, "--ci-url"),
) -> None:
    """Submit story completion and evidence."""
    global_cfg = _read_global_config()
    local_cfg = _read_local_config(required=True)
    api_url = _resolved_api_url(global_cfg, local_cfg)
    project_id = int(local_cfg["project_id"])

    story_key = _resolve_local_story_key(project_id, story, ".json")
    local_pack_path = _find_story_file(project_id, story_key, ".json")
    if local_pack_path is None:
        raise typer.Exit(
            f"Missing local task pack for {story_key} in project_id={project_id} storage."
        )

    pack = json.loads(local_pack_path.read_text(encoding="utf-8"))
    story_id = pack.get("story_id")
    if not isinstance(story_id, int):
        raise typer.Exit(f"Local task pack for {story_key} is missing story_id")
    hash_value = pack.get("contract_hash")
    if not hash_value:
        raise typer.Exit("Local task pack missing contract_hash")

    report_data: dict[str, str] = {}
    if report_file is not None:
        report_data = _parse_completion_report(_read_text_file(report_file))
        if not notes:
            notes = _read_text_file(report_file)

    if notes_file is not None:
        file_notes = _read_text_file(notes_file)
        notes = f"{notes}\n\n{file_notes}".strip() if notes else file_notes

    summary = summary or _clean_optional(report_data.get("SUMMARY"))
    status = status or _clean_optional(report_data.get("RESULT"))
    commit = commit or _clean_optional(report_data.get("COMMIT_SHA"))
    pr_url = pr_url or _clean_optional(report_data.get("PR_URL"))
    ci_url = ci_url or _clean_optional(report_data.get("CI_URL"))

    if auto_git:
        git_meta = _collect_git_metadata()
        if not commit:
            commit = git_meta.get("commit_sha")
        if notes:
            notes = f"{notes}\n\n[GIT]\n{json.dumps(git_meta, indent=2)}"
        else:
            notes = f"[GIT]\n{json.dumps(git_meta, indent=2)}"

    if not summary:
        raise typer.Exit("Missing summary. Provide --summary or include SUMMARY: in --report-file.")
    if not status:
        raise typer.Exit("Missing status. Provide --status or include RESULT: in --report-file.")

    normalized_status = status.strip().lower()
    if normalized_status not in {"in_progress", "verified"}:
        raise typer.Exit("--status must be one of: in_progress, verified")

    evidence = []
    if commit:
        evidence.append({"type": "commit", "value": commit})
    if pr_url:
        evidence.append({"type": "pr", "value": pr_url})
    if ci_url:
        evidence.append({"type": "ci", "value": ci_url})

    if normalized_status == "verified" and len(evidence) == 0:
        raise typer.Exit(
            "Verified requires at least one evidence item. Provide --commit, --pr-url, or --ci-url."
        )

    payload = {
        "tool": tool,
        "action": "verify" if normalized_status == "verified" else "start",
        "summary": summary,
        "notes": notes,
        "requested_status": normalized_status,
        "reported_contract_hash": hash_value,
        "evidence": evidence,
    }

    with _client(api_url, str(global_cfg["token"])) as client:
        resp = client.post(f"/spec-cli/stories/{story_id}/execution-logs", json=payload)
        _ensure_ok(resp, "Done update")

    typer.echo(f"Reported {story_key} as {normalized_status}")


if __name__ == "__main__":
    app()
