from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Awaitable, Callable

# 合法事件名集合（用于注册时校验）
HOOK_EVENTS: frozenset[str] = frozenset({
    "PreToolUse", "PostToolUse", "PostToolUseFailure",
    "UserPromptSubmit", "Stop", "SessionStart", "SessionEnd",
    "SubagentStart", "SubagentStop",
})

# 回调签名：(hook_input_dict, tool_use_id | None) -> output_dict | None
# 返回 None 或空 dict 表示不干预
HookCallback = Callable[
    [dict[str, Any], str | None],
    Awaitable[dict[str, Any] | None],
]


@dataclass(slots=True)
class HookMatcher:
    """Hook 匹配器：将回调绑定到特定事件的特定工具（或所有工具）。"""

    matcher: str | None = None  # 正则匹配工具名，None = 匹配所有
    hooks: list[HookCallback] = field(default_factory=list)
    timeout: float | None = None  # 超时秒数，None = 使用 SDK 默认值（10s）
