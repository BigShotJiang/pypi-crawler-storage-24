from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import TYPE_CHECKING, Any, Literal

from comate_agent_sdk.agent.system_prompt import SystemPromptConfig
from comate_agent_sdk.facade.config.hooks import HookMatcher
from comate_agent_sdk.mcp.types import McpServerConfig

if TYPE_CHECKING:
    from pydantic import BaseModel
    from comate_agent_sdk.llm.base import BaseChatModel


SettingSource = Literal["user", "project", "local"]


@dataclass(slots=True)
class SubagentConfig:
    """Facade 层 subagent 配置（简化版 AgentDefinition）。

    name 由 agents 字典的 key 提供，不在此 dataclass 中。
    """

    description: str
    prompt: str
    tools: list[str] | None = None
    model: str | None = None
    max_iterations: int = 100
    skills: list[str] | None = None
    shared_auto_memory: bool = False


@dataclass(slots=True)
class AgentOptions:
    """Agent 配置选项。"""

    # 已有字段（语义升级）
    system_prompt: str | SystemPromptConfig | None = None
    tools: list[str] | Literal["comate"] | None = None
    max_iterations: int = 200
    mcp_servers: dict[str, McpServerConfig] | None = None
    session_id: str | None = None
    cwd: str | Path | None = None

    # 新增字段
    model: str | BaseChatModel | None = None
    agents: dict[str, SubagentConfig] | None = None
    setting_sources: list[SettingSource] | None = field(default_factory=lambda: ["user"])
    env: dict[str, str] | None = None
    add_dirs: list[str | Path] | None = None
    disallowed_tools: list[str] | None = None
    output_format: dict[str, Any] | type[BaseModel] | None = None
    hooks: dict[str, list[HookMatcher]] | None = None
