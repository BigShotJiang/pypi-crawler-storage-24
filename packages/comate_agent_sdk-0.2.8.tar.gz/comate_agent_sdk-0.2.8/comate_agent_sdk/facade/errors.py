from __future__ import annotations


class AgentError(Exception):
    """Facade public error base class."""


class AgentConfigError(AgentError):
    """Raised when facade options or construction inputs are invalid."""


class AgentConnectionError(AgentError):
    """Raised when the underlying LLM or MCP transport fails."""


class AgentExecutionError(AgentError):
    """Raised when execution fails after the agent has started."""


class AgentTimeoutError(AgentExecutionError):
    """Raised when the underlying execution exceeds a timeout."""
