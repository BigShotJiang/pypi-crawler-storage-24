from __future__ import annotations

from collections.abc import AsyncIterator
from dataclasses import replace

from comate_agent_sdk.facade.client import AgentClient
from comate_agent_sdk.facade.core.events import Event
from comate_agent_sdk.facade.config.options import AgentOptions
from comate_agent_sdk.llm.base import BaseChatModel
from comate_agent_sdk.tools.decorator import Tool


def _resolve_options(
    *,
    options: AgentOptions | None,
    tools: list[Tool] | None,
) -> AgentOptions | None:
    if tools is None:
        return options
    if options is None:
        return AgentOptions(tools=tools)
    return replace(options, tools=tools)


async def query(
    prompt: str,
    *,
    llm: BaseChatModel,
    tools: list[Tool] | None = None,
    options: AgentOptions | None = None,
) -> AsyncIterator[Event]:
    client = AgentClient(
        llm=llm,
        options=_resolve_options(options=options, tools=tools),
    )
    async for event in client.chat(prompt):
        yield event
