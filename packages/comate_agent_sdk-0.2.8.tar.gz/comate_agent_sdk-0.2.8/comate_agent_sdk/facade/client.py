from __future__ import annotations

import asyncio
import logging
from collections.abc import AsyncIterable, AsyncIterator
from dataclasses import replace
from typing import Any

from comate_agent_sdk.agent.chat_session import ChatSession
from comate_agent_sdk.agent.session_store import default_session_root
from comate_agent_sdk.agent.service import AgentTemplate
from comate_agent_sdk.facade._internals.adapters import (
    _filter_events,
    _map_construction_exception,
    _map_options,
    _map_runtime_exception,
)
from comate_agent_sdk.facade.errors import AgentConfigError
from comate_agent_sdk.facade.core.events import Event
from comate_agent_sdk.facade.config.options import AgentOptions
from comate_agent_sdk.llm.base import BaseChatModel
from comate_agent_sdk.llm.messages import ContentPartImageParam, ContentPartTextParam, ImageURL

logger = logging.getLogger(__name__)


def _resolve_stream_message_part(part: dict[str, Any]) -> ContentPartTextParam | ContentPartImageParam:
    part_type = str(part.get("type", "")).strip()
    if part_type == "text":
        text = part.get("text")
        if not isinstance(text, str):
            raise AgentConfigError("Streaming input text block requires string field 'text'")
        return ContentPartTextParam(text=text)

    if part_type == "image":
        source = part.get("source")
        if not isinstance(source, dict):
            raise AgentConfigError("Streaming input image block requires object field 'source'")
        source_type = str(source.get("type", "")).strip()
        media_type = source.get("media_type")
        data = source.get("data")
        if source_type != "base64":
            raise AgentConfigError("Streaming input image block only supports source.type='base64'")
        if not isinstance(media_type, str) or not media_type:
            raise AgentConfigError("Streaming input image block requires string field 'source.media_type'")
        if not isinstance(data, str) or not data:
            raise AgentConfigError("Streaming input image block requires string field 'source.data'")
        return ContentPartImageParam(
            image_url=ImageURL(
                url=f"data:{media_type};base64,{data}",
                media_type=media_type,
            )
        )

    raise AgentConfigError(f"Unsupported streaming input content block type: {part_type!r}")


def _resolve_stream_message(
    envelope: dict[str, Any],
) -> str | list[ContentPartTextParam | ContentPartImageParam]:
    envelope_type = str(envelope.get("type", "")).strip()
    if envelope_type != "user":
        raise AgentConfigError("Streaming input envelope only supports type='user'")

    message = envelope.get("message")
    if not isinstance(message, dict):
        raise AgentConfigError("Streaming input envelope requires object field 'message'")

    role = str(message.get("role", "")).strip()
    if role != "user":
        raise AgentConfigError("Streaming input envelope only supports message.role='user'")

    content = message.get("content")
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        parts: list[ContentPartTextParam | ContentPartImageParam] = []
        for part in content:
            if not isinstance(part, dict):
                raise AgentConfigError("Streaming input content blocks must be objects")
            parts.append(_resolve_stream_message_part(part))
        return parts
    raise AgentConfigError("Streaming input message.content must be a string or a list of blocks")


def _open_chat_session(
    *,
    template: AgentTemplate,
    options: AgentOptions,
    session_id: str | None,
) -> ChatSession:
    resolved_cwd = options.cwd if options.cwd is not None else template.config.cwd
    if session_id is None:
        return ChatSession(
            template,
            cwd=resolved_cwd,
        )

    session_root = default_session_root(session_id, cwd=resolved_cwd)
    context_jsonl = session_root / "context.jsonl"
    if context_jsonl.exists():
        return ChatSession.resume(
            template,
            session_id=session_id,
            cwd=resolved_cwd,
        )

    return ChatSession(
        template,
        cwd=resolved_cwd,
        session_id=session_id,
    )


class Session:
    def __init__(
        self,
        *,
        template: AgentTemplate,
        options: AgentOptions | None = None,
        session_id: str | None = None,
    ) -> None:
        self._template = template
        self._options = options or AgentOptions()
        resolved_session_id = session_id if session_id is not None else self._options.session_id
        try:
            self._session = _open_chat_session(
                template=self._template,
                options=self._options,
                session_id=resolved_session_id,
            )
        except Exception as exc:
            mapped = _map_construction_exception(exc)
            raise mapped from exc

    @property
    def session_id(self) -> str:
        return self._session.session_id

    async def chat(self, prompt: str) -> AsyncIterator[Event]:
        try:
            async for event in _filter_events(self._session.query_stream(prompt)):
                yield event
        except Exception as exc:
            mapped = _map_runtime_exception(exc)
            raise mapped from exc

    async def _shutdown(self) -> None:
        try:
            await self._session.shutdown()
        except Exception as exc:
            mapped = _map_runtime_exception(exc)
            raise mapped from exc

    async def __aenter__(self) -> "Session":
        return self

    async def __aexit__(self, exc_type, exc, tb) -> None:
        await self._shutdown()


class AgentClient:
    def __init__(self, *, llm: BaseChatModel, options: AgentOptions | None = None) -> None:
        self._options = options or AgentOptions()
        try:
            self._template = AgentTemplate(
                llm=llm,
                config=_map_options(self._options),
            )
        except Exception as exc:
            mapped = _map_construction_exception(exc)
            raise mapped from exc

    async def chat(self, prompt: str) -> AsyncIterator[Event]:
        session = Session(
            template=self._template,
            options=replace(self._options, session_id=None),
            session_id=None,
        )
        try:
            async for event in session.chat(prompt):
                yield event
        finally:
            try:
                await session._shutdown()
            except Exception:
                logger.warning("Failed to shutdown temporary facade session", exc_info=True)

    async def query(
        self,
        prompt: str | AsyncIterable[dict[str, Any]],
        session_id: str = "default",
    ) -> AsyncIterator[Event]:
        if isinstance(prompt, str):
            session = Session(
                template=self._template,
                options=self._options,
                session_id=session_id,
            )
            try:
                async for event in session.chat(prompt):
                    yield event
            finally:
                try:
                    await session._shutdown()
                except Exception:
                    logger.warning("Failed to shutdown facade query session", exc_info=True)
            return

        chat_session = _open_chat_session(
            template=self._template,
            options=self._options,
            session_id=session_id,
        )
        producer_error: AgentConfigError | None = None

        async def _push_messages() -> None:
            nonlocal producer_error
            try:
                async for envelope in prompt:
                    if not isinstance(envelope, dict):
                        raise AgentConfigError("Streaming input items must be dict envelopes")
                    await chat_session.send(_resolve_stream_message(envelope))
            except AgentConfigError as exc:
                producer_error = exc
            finally:
                await chat_session.close()

        producer_task = None
        try:
            producer_task = asyncio.create_task(_push_messages())
            async for event in _filter_events(chat_session.events()):
                yield event
            if producer_task is not None:
                await producer_task
            if producer_error is not None:
                raise producer_error
        except Exception as exc:
            mapped = _map_runtime_exception(exc)
            raise mapped from exc
        finally:
            try:
                if producer_task is not None and not producer_task.done():
                    producer_task.cancel()
                await chat_session.shutdown()
            except Exception:
                logger.warning("Failed to shutdown facade streaming query session", exc_info=True)

    def session(self, session_id: str | None = None) -> Session:
        return Session(
            template=self._template,
            options=self._options,
            session_id=session_id,
        )
