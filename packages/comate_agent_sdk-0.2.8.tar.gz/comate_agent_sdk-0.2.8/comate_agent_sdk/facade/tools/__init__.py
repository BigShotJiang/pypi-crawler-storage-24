"""
工具定义 Facade 层（Tool Definition Facade）。

核心功能：
- @tool 装饰器：使用函数定义工具，自动生成 JSON schema 和执行器
- 支持类型注解、Pydantic 模型、依赖注入
- 无需继承，函数即工具

Example:
    from comate_agent_sdk.facade.tools import tool

    @tool("执行自定义 SQL 查询")
    async def query_db(sql: str) -> str:
        '''根据 SQL 返回查询结果'''
        # Implementation here
        return "Result"

    # 构建工具并传给 Agent
    agent = Agent(tools=[query_db])
"""

from comate_agent_sdk.facade.tools.decorators import tool

__all__ = ["tool"]
