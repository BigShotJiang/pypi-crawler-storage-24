import unittest

from comate_agent_sdk.llm.anthropic.serializer import AnthropicMessageSerializer
from comate_agent_sdk.llm.messages import (
    AssistantMessage,
    Function,
    SystemMessage,
    ToolCall,
    ToolMessage,
    UserMessage,
)


class TestAnthropicCacheControlRouting(unittest.TestCase):
    def test_system_prompt_never_uses_cache_control(self) -> None:
        messages = [
            SystemMessage(content="SYSTEM_PROMPT", cache=True),
            UserMessage(content="hello"),
        ]

        _, system_prompt = AnthropicMessageSerializer.serialize_messages(messages)
        self.assertIsInstance(system_prompt, str)
        self.assertEqual(system_prompt, "SYSTEM_PROMPT")

    def test_session_state_user_message_uses_ephemeral_cache_control(self) -> None:
        session_state = UserMessage(
            content="<system_env>\ncompact\n</system_env>",
            is_meta=True,
            cache=False,
        )
        messages = [
            SystemMessage(content="SYSTEM_PROMPT", cache=True),
            session_state,
        ]

        serialized_messages, _ = AnthropicMessageSerializer.serialize_messages(messages)
        self.assertEqual(len(serialized_messages), 1)
        user_msg = serialized_messages[0]
        self.assertEqual(user_msg["role"], "user")
        self.assertIsInstance(user_msg["content"], list)
        block = user_msg["content"][0]
        self.assertEqual(block["type"], "text")
        self.assertEqual(block["cache_control"]["type"], "ephemeral")

    def test_consecutive_user_messages_are_coalesced(self) -> None:
        session_state = UserMessage(
            content="<system_env>\ncompact\n</system_env>",
            is_meta=True,
        )
        reminder = UserMessage(
            content="<system-reminder>\nteam\n</system-reminder>",
            is_meta=True,
        )
        messages = [
            SystemMessage(content="SYSTEM_PROMPT"),
            session_state,
            UserMessage(content="write a story"),
            reminder,
        ]

        serialized_messages, _ = AnthropicMessageSerializer.serialize_messages(messages)
        self.assertEqual(len(serialized_messages), 1)
        user_msg = serialized_messages[0]
        self.assertEqual(user_msg["role"], "user")
        self.assertEqual(len(user_msg["content"]), 3)
        self.assertEqual(user_msg["content"][0]["cache_control"]["type"], "ephemeral")

    def test_output_style_meta_message_is_not_treated_as_session_state(self) -> None:
        messages = [
            SystemMessage(content="SYSTEM_PROMPT", cache=True),
            UserMessage(
                content="<output_style>\ncompact\n</output_style>",
                is_meta=True,
            ),
            UserMessage(content="follow up"),
        ]

        serialized_messages, _ = AnthropicMessageSerializer.serialize_messages(messages)
        self.assertEqual(len(serialized_messages), 1)
        user_msg = serialized_messages[0]
        self.assertEqual(user_msg["role"], "user")
        self.assertIsInstance(user_msg["content"], list)
        first_block = user_msg["content"][0]
        self.assertEqual(first_block["type"], "text")
        self.assertEqual(first_block["text"], "<output_style>\ncompact\n</output_style>")
        self.assertNotIn("cache_control", first_block)

    def test_tool_result_remains_first_when_followed_by_user_reminder(self) -> None:
        messages = [
            UserMessage(content="hello"),
            AssistantMessage(
                content=None,
                tool_calls=[
                    ToolCall(
                        id="tc1",
                        function=Function(name="Read", arguments="{}"),
                    )
                ],
            ),
            ToolMessage(
                tool_call_id="tc1",
                tool_name="Read",
                content="file body",
            ),
            UserMessage(
                content="<system-reminder>\nteam follow-up\n</system-reminder>",
                is_meta=True,
            ),
        ]

        serialized_messages, _ = AnthropicMessageSerializer.serialize_messages(messages)
        self.assertEqual(len(serialized_messages), 3)
        merged_user_msg = serialized_messages[2]
        self.assertEqual(merged_user_msg["role"], "user")
        self.assertEqual(merged_user_msg["content"][0]["type"], "tool_result")
        self.assertEqual(merged_user_msg["content"][0]["tool_use_id"], "tc1")
        self.assertEqual(merged_user_msg["content"][1]["type"], "text")


if __name__ == "__main__":
    unittest.main(verbosity=2)
