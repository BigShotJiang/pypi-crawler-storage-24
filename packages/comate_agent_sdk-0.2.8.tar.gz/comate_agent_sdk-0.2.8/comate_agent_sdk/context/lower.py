"""Lowering 管道

将 ContextIR 的高层语义结构转换为 LLM API 所需的 list[BaseMessage] 格式。

数据流：
    ContextIR.lower()
    → LoweringPipeline.lower(context)
    → list[BaseMessage]
    → llm.ainvoke(messages=...)
"""

from __future__ import annotations

import re
from typing import TYPE_CHECKING

from comate_agent_sdk.context.header.order import (
    SESSION_STATE_ITEM_TYPES_IN_ORDER,
    STATIC_HEADER_ITEM_TYPES_IN_ORDER,
)
from comate_agent_sdk.context.items import ItemType
from comate_agent_sdk.llm.messages import (
    SystemMessage,
    UserMessage,
)
from comate_agent_sdk.prompts import render_prompt

if TYPE_CHECKING:
    from comate_agent_sdk.context.ir import ContextIR
    from comate_agent_sdk.llm.messages import BaseMessage


_PROMPT_VARIABLE_PATTERN = re.compile(r"{{\s*([A-Za-z_][A-Za-z0-9_]*)\s*}}")
_STATIC_HEADER_TEMPLATE_VARIABLES: dict[str, ItemType] = {
    "MEMORY_USAGE": ItemType.MEMORY_USAGE,
    "TOOL_STRATEGY": ItemType.TOOL_STRATEGY,
    "SUBAGENT_STRATEGY": ItemType.SUBAGENT_STRATEGY,
    "SKILL_STRATEGY": ItemType.SKILL_STRATEGY,
}


class LoweringPipeline:
    """Lowering 管道：IR → API messages

    转换规则：
    1. Static Header → SystemMessage
       cache=True 如果任一 static header item 有 cache_hint
    2. User Instruction → UserMessage(is_meta=True)（独立输出，携带 cache hint）
    3. Auto Memory → UserMessage(is_meta=True)
    4. Session State → UserMessage(is_meta=True)（不含 user_instruction）
    5. Conversation items → 按顺序转为 BaseMessage
    """

    @staticmethod
    def lower(context: ContextIR) -> list[BaseMessage]:
        """将 ContextIR 转换为 API messages 格式

        Args:
            context: ContextIR 实例

        Returns:
            可直接传给 llm.ainvoke() 的消息列表
        """
        messages: list[BaseMessage] = []

        # Step 1: Static Header → SystemMessage
        header_text = LoweringPipeline._build_static_header_text(context)
        if header_text:
            # 判断是否需要 cache hint
            cache = any(item.cache_hint for item in context.header.items)
            messages.append(SystemMessage(content=header_text, cache=cache))

        # Step 2: User Instruction → 独立 UserMessage(is_meta=True)
        # user_instruction 存储在 session_state 中，但 lowering 时单独输出（保留 cache hint）
        user_instruction_item = context.session_state.find_one_by_type(ItemType.USER_INSTRUCTION)
        if user_instruction_item and user_instruction_item.message:
            messages.append(user_instruction_item.message)



        # Step 3: Session State → UserMessage(is_meta=True)（跳过 user_instruction，已在 Step 2 输出）
        session_state_text = LoweringPipeline._build_session_state_text(context)
        if session_state_text:
            messages.append(UserMessage(content=session_state_text, is_meta=True))

        # Step 4: Auto Memory → UserMessage(is_meta=True)
        if context.memory and context.memory.message:
            messages.append(context.memory.message)

        # Step 5: Conversation items → BaseMessage
        for item in context.conversation.items:
            if item.destroyed:
                # 已销毁的条目仍然需要保留在列表中（serializer 会用 placeholder）
                if item.message is not None:
                    messages.append(item.message)
                continue

            if item.item_type == ItemType.TEAM_INBOX_TURN and item.message is not None:
                messages.append(item.message)
                continue

            if item.message is not None:
                messages.append(item.message)

        return messages

    @staticmethod
    def _build_static_header_text(context: ContextIR) -> str:
        """拼接 static header 段的各部分文本。

        顺序：system_prompt → memory_usage → tool_strategy → subagent_strategy → skill_strategy
        """
        parts: list[str] = []
        consumed_item_types: set[ItemType] = set()

        system_prompt_item = context.header.find_one_by_type(ItemType.SYSTEM_PROMPT)
        if system_prompt_item and system_prompt_item.content_text:
            rendered_system_prompt, consumed_item_types = (
                LoweringPipeline._render_static_header_template(
                    system_prompt_item.content_text,
                    context,
                )
            )
            parts.append(rendered_system_prompt)

        for item_type in STATIC_HEADER_ITEM_TYPES_IN_ORDER:
            if item_type == ItemType.SYSTEM_PROMPT:
                continue
            if item_type in consumed_item_types:
                continue
            item = context.header.find_one_by_type(item_type)
            if item and item.content_text:
                parts.append(item.content_text)

        return "\n".join(parts) if parts else ""

    @staticmethod
    def _render_static_header_template(
        system_prompt_text: str,
        context: ContextIR,
    ) -> tuple[str, set[ItemType]]:
        """在 lowering 阶段按需注入静态 header 占位符。"""
        referenced_names = {
            match.group(1)
            for match in _PROMPT_VARIABLE_PATTERN.finditer(system_prompt_text)
        }
        supported_names = referenced_names.intersection(
            _STATIC_HEADER_TEMPLATE_VARIABLES.keys()
        )
        if not supported_names:
            return system_prompt_text, set()

        variables: dict[str, str] = {}
        consumed_item_types: set[ItemType] = set()

        for variable_name in referenced_names:
            item_type = _STATIC_HEADER_TEMPLATE_VARIABLES.get(variable_name)
            if item_type is None:
                variables[variable_name] = f"{{{{{variable_name}}}}}"
                continue

            item = context.header.find_one_by_type(item_type)
            variables[variable_name] = item.content_text if item and item.content_text else ""
            consumed_item_types.add(item_type)

        rendered = render_prompt(
            system_prompt_text,
            variables=variables,
            source="header.system_prompt",
        )
        return rendered, consumed_item_types

    @staticmethod
    def _build_session_state_text(context: ContextIR) -> str:
        """拼接 session_state 段文本。

        顺序：system_env → git_env → mcp_tool → output_style
        注意：USER_INSTRUCTION 跳过，它在 Step 2 作为独立 UserMessage 输出。
        """
        parts: list[str] = []

        for item_type in SESSION_STATE_ITEM_TYPES_IN_ORDER:
            if item_type == ItemType.USER_INSTRUCTION:
                continue  # 在 Step 2 独立输出，不并入 session_state 文本块
            item = context.session_state.find_one_by_type(item_type)
            if item and item.content_text:
                parts.append(item.content_text)

        return "\n".join(parts) if parts else ""
