<team-inbox-turn>
source: team_inbox
messages:
{{MESSAGES}}
</team-inbox-turn>
