You have exited plan mode. You can now make edits, run tools, and take actions.
