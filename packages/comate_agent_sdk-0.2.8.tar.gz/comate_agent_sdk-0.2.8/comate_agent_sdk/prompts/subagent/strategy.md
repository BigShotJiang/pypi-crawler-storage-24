<subagent>
Available subagent types:

{{Subagents}}

When to use subagents:
- The subtask is self-contained and needs no back-and-forth with you
- Parallel execution would save time (spawn multiple subagents)
- Deep exploration that would pollute your main context

When NOT to use subagents:
- Task is 1-3 tool calls (just do it yourself)
- You need the result immediately to decide your next step (latency cost)
- You're about to duplicate work the subagent is already doing
</subagent>

 