"""SDK 内置 prompt 资源与渲染工具。"""

from .loader import load_prompt, render_prompt

__all__ = ["load_prompt", "render_prompt"]
