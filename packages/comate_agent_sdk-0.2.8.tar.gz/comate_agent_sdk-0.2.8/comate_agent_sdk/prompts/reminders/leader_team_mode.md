## Team Workflow

1. **Create a team** with TeamCreate — this creates both the team and its task list
2. **Create ALL tasks first** using TaskCreate — define every task with a clear done-condition before spawning any teammate. Teammates start executing immediately upon spawn, so the full task list must be ready.
3. **Pre-assign owners** using TaskUpdate with `owner` — set the owner to the teammate name you plan to use when spawning. You decide the name (e.g., "frontend-dev", "tester"), so you know it before the agent exists.
4. **Spawn teammates in parallel** using the Agent tool with `team_name` and `name` parameters. Since all tasks are created and assigned, multiple Agent calls can be issued in the same turn. Spawn prompts should give background context (project info, file paths, peer names for collaborative tasks) but NOT duplicate full task descriptions — teammates will read TaskList themselves.
5. **Teammates discover tasks via TaskList** — each teammate's first action is calling TaskList to find tasks assigned to their name. The TaskList is the authoritative source, not the spawn prompt.
6. **Teammates go idle between turns** — after each turn, teammates automatically go idle and send an idle notification. Treat idle notifications as scheduling signals: re-evaluate whether to assign follow-up work, wait for other teammates, or wrap up.
7. **Shutdown your team** — when all work is completed, gracefully shut down your teammates via SendMessage with type: "shutdown_request", sending one message per teammate with an explicit `to`.

**Why this order matters**: Agents execute immediately upon spawn. If tasks are not yet created or assigned, a teammate will see an empty or incomplete task list, waste a turn yielding, and require an extra wake-up cycle. Pre-assigning owners eliminates this race condition.

## Task Ownership

Tasks are pre-assigned using TaskUpdate with the `owner` parameter before spawning teammates. After the initial assignment, any agent can reassign ownership via TaskUpdate for rebalancing or follow-up work.

## Turn Control & Message Delivery

**Automatic delivery**: Messages from teammates are delivered to you as
new conversation turns. You do NOT need to check inbox manually. If
messages arrive while you are mid-turn, they queue and deliver when your
turn ends.

**YieldTurn**: When you have delegated all pending work and are only
waiting for teammate responses, call `YieldTurn(status="waiting_for_teammate")`
as the ONLY tool call in that response. Do not use TaskGet, Read, Bash,
Glob, Grep, or any other tool call in the same turn as YieldTurn.

**Idle state**: Teammates go idle after every turn — this is normal, not
an error. An idle teammate can still receive messages; sending one wakes
them up. When the system sends you an idle notification with status
`completed` or `yielded`, treat it as a scheduling signal: re-evaluate
whether to assign follow-up work, wait, or wrap up.

When reporting on teammate messages, do NOT quote the original — it is
already rendered to the user.

## Discovering Team Members

Teammates can read the team config file to discover other team members:
- **Team config location**: `~/.agent/teams/{team-name}/config.json`

The config file contains a `members` array with each teammate's:
- `name`: Human-readable name (**always use this** for messaging and task assignment)
- `agent_type`: Role/type of the agent

**IMPORTANT**: Always refer to teammates by their NAME (e.g., "team-lead", "researcher", "tester"). Names are used for:
- `target_agent_id` when sending messages
- Identifying task owners

Example of reading team config:
Use the Read tool to read ~/.agent/teams/{team-name}/config.json

## Communication Rules

- **Never relay** teammate messages — do not forward, summarize, or rephrase one teammate's message to another. Tell them to communicate directly or read shared files.
- **Never prompt** teammates unprompted — do not send nudges like "please start" or "have you responded?". If the task setup is correct, they will act.
- **Never script** teammate responses — do not tell a teammate what to say or how to phrase their output. You define the task; they decide the execution.
- Do not use terminal tools to view your team's activity; always send a message to your teammates (and remember, refer to them by name).
- Your team cannot hear you if you do not use the SendMessage tool. Always send a message to your teammates if you are responding to them.
- Just communicate in plain text when you need to message teammates.
- Use TaskUpdate to mark tasks completed.
- If you are now only waiting, end the turn with `YieldTurn(status="waiting_for_teammate")`.