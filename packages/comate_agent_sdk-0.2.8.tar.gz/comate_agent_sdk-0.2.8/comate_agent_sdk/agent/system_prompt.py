from __future__ import annotations

import logging
from dataclasses import dataclass
from pathlib import Path
from typing import Literal

from comate_agent_sdk.prompts import load_prompt, render_prompt

logger = logging.getLogger("comate_agent_sdk.agent.system_prompt")

AUTO_MEMORY_DIR_PLACEHOLDER = "AUTO_MEMORY_DIR_PLACEHOLDER"
MEMORY_USAGE_PLACEHOLDER = "MEMORY_USAGE"
SUBAGENT_STRATEGY_PLACEHOLDER = "SUBAGENT_STRATEGY"
SKILL_STRATEGY_PLACEHOLDER = "SKILL_STRATEGY"
_DEFAULT_SYSTEM_PROMPT_TEMPLATE = load_prompt("agent/default_system_prompt.md")


GENERAL_ROLE = "general"
SOFTWARE_ENGINEERING_ROLE = "software_engineering"
DEFAULT_AGENT_ROLE = GENERAL_ROLE

_ROLE_OPENING_LINES: dict[str, str] = {
    GENERAL_ROLE: (
        "You are Comate, an AI-powered agent developed by AndyLee. an interactive general AI agent running on a user's computer that helps users as a general AI agent."
    ),
    SOFTWARE_ENGINEERING_ROLE: (
        "You are Comate, an AI-powered coding agent developed by AndyLee. You run locally on the user's computer and help with software engineering tasks. You are NOT related to Baidu Comate or any other product with a similar name."
    ),
}


def _normalize_role(role: str | None) -> str:
    if role is None:
        return DEFAULT_AGENT_ROLE

    normalized = role.strip().lower()
    if not normalized:
        return DEFAULT_AGENT_ROLE

    if normalized not in _ROLE_OPENING_LINES:
        logger.warning(f"Unknown role '{role}', fallback to '{GENERAL_ROLE}'")
        return GENERAL_ROLE

    return normalized


def _normalize_auto_memory_dir_for_prompt(auto_memory_dir: str) -> str:
    resolved = Path(auto_memory_dir).expanduser().resolve()
    normalized = resolved.as_posix()
    if not normalized.endswith("/"):
        normalized = f"{normalized}/"
    return normalized


def build_default_system_prompt(role: str | None = None) -> str:
    resolved_role = _normalize_role(role)
    opening_line = _ROLE_OPENING_LINES[resolved_role]
    return render_prompt(
        _DEFAULT_SYSTEM_PROMPT_TEMPLATE,
        variables={
            "SYSTEM_ROLE_LINE": opening_line,
            MEMORY_USAGE_PLACEHOLDER: f"{{{{{MEMORY_USAGE_PLACEHOLDER}}}}}",
            SUBAGENT_STRATEGY_PLACEHOLDER: f"{{{{{SUBAGENT_STRATEGY_PLACEHOLDER}}}}}",
            SKILL_STRATEGY_PLACEHOLDER: f"{{{{{SKILL_STRATEGY_PLACEHOLDER}}}}}",
        },
        source="agent/default_system_prompt.md",
    )


@dataclass
class SystemPromptConfig:
    """System prompt 配置

    Attributes:
        content: 系统提示内容
        mode:
            - "override": 完全覆盖 SDK 默认 prompt
            - "append": 追加到 SDK 默认 prompt 之后
    """

    content: str
    mode: Literal["override", "append"] = "override"


# 支持 str（向后兼容，等同于 override）或 SystemPromptConfig
SystemPromptType = str | SystemPromptConfig | None


def resolve_system_prompt(
    system_prompt: SystemPromptType,
    *,
    role: str | None = None,
    auto_memory_dir: str | None = None,
) -> str:
    """解析 system_prompt 配置，返回最终的系统提示文本

    逻辑：
    - None → 带 role 的 SDK 默认 prompt
    - str → 完全覆盖（向后兼容）
    - SystemPromptConfig(mode="override") → 完全覆盖
    - SystemPromptConfig(mode="append") → 带 role 的 SDK 默认 + 用户内容
    """
    if system_prompt is None:
        prompt = build_default_system_prompt(role=role)
    elif isinstance(system_prompt, str):
        # 向后兼容：str 等同于 override
        prompt = system_prompt
    elif system_prompt.mode == "override":
        prompt = system_prompt.content
    else:
        default_prompt = build_default_system_prompt(role=role)
        prompt = f"{default_prompt}\n\n{system_prompt.content}"

    if auto_memory_dir and AUTO_MEMORY_DIR_PLACEHOLDER in prompt:
        normalized_dir = _normalize_auto_memory_dir_for_prompt(auto_memory_dir)
        prompt = prompt.replace(AUTO_MEMORY_DIR_PLACEHOLDER, normalized_dir)

    return prompt


def resolve_memory_usage_prompt(auto_memory_dir: str | None) -> str:
    """解析 memory usage static header。"""
    if not auto_memory_dir:
        return ""

    normalized_dir = _normalize_auto_memory_dir_for_prompt(auto_memory_dir)
    return render_prompt(
        load_prompt("agent/memory_usage.md"),
        variables={"MEMORY_DIR_PATH": normalized_dir},
        source="agent/memory_usage.md",
    )
