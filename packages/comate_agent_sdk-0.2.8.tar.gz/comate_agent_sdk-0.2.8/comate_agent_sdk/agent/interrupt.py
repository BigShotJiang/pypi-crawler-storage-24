from __future__ import annotations

import logging
import threading
from dataclasses import dataclass, field
from typing import Callable


logger = logging.getLogger(__name__)


@dataclass
class SessionRunController:
    """Session-scoped controller for cooperative interruption."""

    _lock: threading.Lock = field(default_factory=threading.Lock, init=False, repr=False)
    _interrupted: bool = field(default=False, init=False, repr=False)
    _reason: str = field(default="", init=False, repr=False)
    _interrupt_count: int = field(default=0, init=False, repr=False)
    _callbacks: dict[int, Callable[[str, int], None]] = field(
        default_factory=dict,
        init=False,
        repr=False,
    )
    _next_callback_id: int = field(default=1, init=False, repr=False)

    def interrupt(self, reason: str = "user") -> None:
        normalized_reason = reason.strip() if isinstance(reason, str) else "user"
        if not normalized_reason:
            normalized_reason = "user"
        with self._lock:
            self._interrupted = True
            self._reason = normalized_reason
            self._interrupt_count += 1
            interrupt_count = self._interrupt_count
            callbacks = list(self._callbacks.values())

        for callback in callbacks:
            try:
                callback(normalized_reason, interrupt_count)
            except Exception as exc:
                logger.warning(f"interrupt callback failed: {exc}", exc_info=True)

    def clear(self) -> None:
        with self._lock:
            self._interrupted = False
            self._reason = ""
            self._interrupt_count = 0

    def register_interrupt_callback(
        self,
        callback: Callable[[str, int], None],
    ) -> Callable[[], None]:
        with self._lock:
            callback_id = self._next_callback_id
            self._next_callback_id += 1
            self._callbacks[callback_id] = callback

        def _unregister() -> None:
            with self._lock:
                self._callbacks.pop(callback_id, None)

        return _unregister

    @property
    def is_interrupted(self) -> bool:
        with self._lock:
            return self._interrupted

    @property
    def reason(self) -> str | None:
        with self._lock:
            if not self._interrupted:
                return None
            return self._reason or "user"

    @property
    def interrupt_count(self) -> int:
        with self._lock:
            return self._interrupt_count
