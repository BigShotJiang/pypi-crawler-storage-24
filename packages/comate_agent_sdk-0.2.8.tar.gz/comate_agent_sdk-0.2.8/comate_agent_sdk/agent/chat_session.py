from __future__ import annotations

import asyncio
import json
import logging
import os
import shutil
import uuid
from contextlib import nullcontext, suppress
from collections.abc import AsyncIterator, Iterable, Iterator
from pathlib import Path

from comate_agent_sdk.agent.events import (
    AgentEvent,
    ExternalTurnScheduledEvent,
    LLMSwitchedEvent,
    SessionInitEvent,
    StopEvent,
    TeamMessageEvent,
)
from comate_agent_sdk.agent.external_turns import (
    ExternalTurn,
    ExternalTurnEnqueueResult,
    ExternalTurnInput,
    ScheduledExternalTurn,
    is_control_external_turn,
)
from comate_agent_sdk.agent.session_scheduler import SessionScheduler
from comate_agent_sdk.agent.llm_levels import LLMLevel
from comate_agent_sdk.agent.settings import persist_user_model_preference
from comate_agent_sdk.agent.interrupt import SessionRunController
from comate_agent_sdk.agent.service import AgentTemplate, AgentRuntime
from comate_agent_sdk.agent.session_store import (
    PERSISTENCE_SCHEMA_VERSION,
    ConversationState,
    build_conversation_event,
    build_header_snapshot_event,
    build_usage_event,
    default_session_root,
    external_turns_journal_path,
    events_jsonl_append,
    load_session_metadata,
    normalize_cwd,
    replay_header_snapshot,
    replay_session_events,
    rewrite_session_id_in_jsonl,
    write_session_metadata,
    slice_usage_delta,
)
from comate_agent_sdk.context.items import ItemType
from comate_agent_sdk.llm.messages import ContentPartImageParam, ContentPartTextParam
from comate_agent_sdk.system_tools.task import TaskStore
from comate_agent_sdk.tokens.total_usage import TotalUsageSnapshot
from comate_agent_sdk.tokens.views import UsageSummary
from comate_agent_sdk.utils.paths import PathInput

logger = logging.getLogger("comate_agent_sdk.agent.chat_session")

ChatMessage = str | list[ContentPartTextParam | ContentPartImageParam]
MessageSource = AsyncIterator[ChatMessage] | Iterator[ChatMessage] | Iterable[ChatMessage]


class ChatSessionError(Exception):
    pass


class ChatSessionClosedError(ChatSessionError):
    pass


# Backward-compatible aliases for test code that imports private names.
_ConversationState = ConversationState
_build_conversation_event = build_conversation_event
_events_jsonl_append = events_jsonl_append
_replay_conversation_events = None  # replaced; see session_store.replay_conversation_events
_replay_session_events = replay_session_events


class ChatSession:
    def __init__(
        self,
        template: AgentTemplate,
        *,
        cwd: PathInput | None = None,
        runtime: AgentRuntime | None = None,
        session_id: str | None = None,
        message_source: MessageSource | None = None,
        turn_timeout: float | None = None,
    ):
        resolved_session_id = (
            session_id or (runtime._session_id if runtime is not None else None)
        )
        self.session_id = resolved_session_id or str(uuid.uuid4())
        runtime_cwd = runtime._runtime_state.cwd if runtime is not None else None
        effective_cwd = (
            cwd
            if cwd is not None
            else (runtime_cwd if runtime_cwd is not None else template.config.cwd)
        )
        self._cwd = normalize_cwd(effective_cwd)
        self._storage_root = default_session_root(self.session_id, cwd=self._cwd)
        self._offload_root = self._storage_root / "offload"
        self._context_jsonl = self._storage_root / "context.jsonl"
        self._external_turns_journal = external_turns_journal_path(self._storage_root)

        self._template = template
        # Backward-compatible alias for existing call sites/tests.
        self._template_agent = template
        if runtime is None:
            self._runtime = template.create_runtime(
                cwd=self._cwd,
                session_id=self.session_id,
            )
        else:
            if runtime._session_id != self.session_id:
                raise ChatSessionError(
                    f"runtime.session_id={runtime._session_id} does not match session_id={self.session_id}"
                )
            self._runtime = runtime
        # Backward-compatible alias for existing call sites/tests.
        self._agent = self._runtime

        self._closed = False
        self._shutdown_completed = False
        self._turn_number = 0
        self._init_event_emitted = False
        self._turn_timeout: float | None = turn_timeout if turn_timeout and turn_timeout > 0 else None

        self._events_started = False
        self._queue: asyncio.Queue[ChatMessage | None] = asyncio.Queue()
        self._session_event_queue: asyncio.Queue[AgentEvent] = asyncio.Queue()
        self._message_source = message_source
        self.run_controller = SessionRunController()
        self._message_source_task: asyncio.Task[None] | None = None
        self._message_source_finished = False
        self._agent._team.disable_legacy_inbox_poll = True

        # resume session 时 runtime is not None，header 已在文件中，标记为已持久化
        # new session 时 runtime is None，等待第一条消息时再落盘（惰性落盘）
        self._header_persisted: bool = runtime is not None

        if runtime is None:
            self._persist_session_metadata(force=True)
            self._restore_task_state_from_task_store()

        self._scheduler = SessionScheduler(
            session_id=self.session_id,
            journal_path=self._external_turns_journal,
            emit_event=self._emit_session_event,
        )
        if runtime is not None:
            self._restore_external_turn_state()

        self._agent._team.discard_team_turns_callback = self.discard_team_external_turns
        self._maybe_start_runtime_inbox_poll()

    @property
    def runtime(self) -> AgentRuntime:
        return self._runtime

    def _maybe_start_runtime_inbox_poll(self) -> None:
        sync_poll = getattr(self._agent, "_sync_inbox_poll_task", None)
        if callable(sync_poll):
            sync_poll()

    def _restore_external_turn_state(self) -> None:
        self._scheduler.recover_from_journal()
        self._restore_pending_team_inbox_ack_keys()

    def _restore_pending_team_inbox_ack_keys(self) -> None:
        for turn in self._scheduler.get_queued_external_turns():
            for key in self._team_inbox_turn_ack_keys(turn):
                self._agent._team.pending_inbox_keys.add(key)

    @staticmethod
    def _team_inbox_turn_ack_keys(turn: ExternalTurn) -> list[str]:
        if str(turn.source or "").strip() != "team_inbox":
            return []

        raw_messages = turn.payload.get("messages")
        normalized_keys: list[str] = []
        if isinstance(raw_messages, list):
            for item in raw_messages:
                if not isinstance(item, dict):
                    continue
                key = str(item.get("key", "") or "").strip()
                if key:
                    normalized_keys.append(key)

        if normalized_keys:
            return normalized_keys

        source_event_id = str(turn.source_event_id or "").strip()
        if source_event_id:
            return [source_event_id]
        return []

    def _ack_completed_team_inbox_turn(self, turn: ExternalTurn) -> None:
        ack_keys = self._team_inbox_turn_ack_keys(turn)
        if not ack_keys:
            return
        ack_pending = getattr(self._agent, "ack_pending_inbox_events", None)
        if callable(ack_pending):
            ack_pending(ack_keys)

    async def _emit_session_event(self, event: AgentEvent) -> None:
        await self._session_event_queue.put(event)

    def has_pending_external_turns(self) -> bool:
        """Check if there are pending external turns in the scheduler."""
        return self._scheduler.has_pending_external_turns()

    async def enqueue_external_turn(self, turn: ExternalTurn) -> ExternalTurnEnqueueResult:
        return await self._scheduler.enqueue_external_turn(turn)

    def discard_team_external_turns(self) -> int:
        discarded_turn_ids = self._scheduler.discard_external_turns(
            predicate=lambda turn: str(turn.source or "").strip() == "team_inbox",
            reason="team_namespace_cleared",
        )
        return len(discarded_turn_ids)

    async def _drain_session_events(self) -> AsyncIterator[AgentEvent]:
        while True:
            try:
                event = self._session_event_queue.get_nowait()
            except asyncio.QueueEmpty:
                return
            yield event

    async def _drain_fifo_external_turns(
        self,
        *,
        snapshot_count: int,
        terminal_events: list[StopEvent],
    ) -> AsyncIterator[AgentEvent]:
        """处理快照数量内的 pending external turns（FIFO pre-drain）。

        在 query_stream() 执行用户消息之前调用，确保比用户消息更早入队的
        external turn 先被处理，维护全局 FIFO 调度语义。
        """
        for _ in range(snapshot_count):
            if self._scheduler.has_control_external_turn():
                # control turn 在 drain 期间到达，退出 drain 交由上层处理
                break
            if not self._scheduler.has_pending_external_turns():
                break
            scheduled = await self._scheduler.schedule_external_turn(
                dispatch_reason="fifo_pre_user"
            )
            if scheduled is None:
                break
            external_input = ExternalTurnInput(turn=scheduled.turn)
            try:
                pre_terminal: list[StopEvent] = []
                yield ExternalTurnScheduledEvent(
                    turn_id=scheduled.turn.turn_id,
                    source=scheduled.turn.source,
                    dispatch_reason=scheduled.dispatch_reason,
                    queue_size_remaining=self._scheduler.external_turn_queue_size(),
                    wait_ms=0,
                )
                async for ev in self._run_turn_stream(
                    message=external_input,
                    terminal_events=pre_terminal,
                ):
                    yield ev
                await self._scheduler.complete_external_turn(
                    turn_id=scheduled.turn.turn_id,
                    dispatch_token=scheduled.dispatch_token,
                )
                self._ack_completed_team_inbox_turn(scheduled.turn)
                if pre_terminal and pre_terminal[-1].reason != "completed":
                    terminal_events.extend(pre_terminal)
                    return
            except Exception:
                await self._scheduler.requeue_external_turn(
                    turn=scheduled.turn,
                    dispatch_token=scheduled.dispatch_token,
                    reason="execution_failed",
                )
                raise
            async for event in self._drain_session_events():
                yield event

    def _enqueue_team_message_event(self, event: TeamMessageEvent) -> None:
        try:
            self._session_event_queue.put_nowait(event)
        except asyncio.QueueFull:
            logger.warning("Session event queue full, dropping TeamMessageEvent")

    def _set_external_turn_callback(self) -> object | None:
        previous = self._agent._team.external_turn_callback
        self._agent._team.external_turn_callback = self.enqueue_external_turn
        # 只在未被外部（如 TeamSessionActor 转发）预设时才注册本 session 的回调
        if self._agent._team.team_message_event_callback is None:
            self._agent._team.team_message_event_callback = self._enqueue_team_message_event
        sync_poll = getattr(self._agent, "_sync_inbox_poll_task", None)
        if callable(sync_poll):
            sync_poll()
        return previous

    @staticmethod
    def _is_bound_chat_session_callback(
        callback: object | None,
        *,
        owner: "ChatSession",
        func: object,
    ) -> bool:
        return (
            getattr(callback, "__self__", None) is owner
            and getattr(callback, "__func__", None) is func
        )

    def _clear_owned_external_turn_callback(self) -> None:
        callback = self._agent._team.external_turn_callback
        if not self._is_bound_chat_session_callback(
            callback,
            owner=self,
            func=ChatSession.enqueue_external_turn,
        ):
            return
        self._agent._team.external_turn_callback = None
        if self._agent._team.team_message_event_callback is self._enqueue_team_message_event:
            self._agent._team.team_message_event_callback = None
        sync_poll = getattr(self._agent, "_sync_inbox_poll_task", None)
        if callable(sync_poll):
            sync_poll()

    def _restore_external_turn_callback(self, previous: object | None) -> None:
        if self._closed:
            self._clear_owned_external_turn_callback()
            return
        current = self._agent._team.external_turn_callback
        if not self._is_bound_chat_session_callback(
            current,
            owner=self,
            func=ChatSession.enqueue_external_turn,
        ):
            return
        self._agent._team.external_turn_callback = previous
        if self._agent._team.team_message_event_callback is self._enqueue_team_message_event:
            self._agent._team.team_message_event_callback = None
        sync_poll = getattr(self._agent, "_sync_inbox_poll_task", None)
        if callable(sync_poll):
            sync_poll()

    def _ensure_header_persisted(self) -> None:
        """幂等落盘 header_snapshot，仅在第一条消息发送前触发一次。"""
        if self._header_persisted:
            return
        self._persist_initial_header_snapshot_if_needed()
        self._header_persisted = True

    def _persist_initial_header_snapshot_if_needed(self) -> None:
        if self._context_jsonl.exists():
            try:
                existing = self._context_jsonl.read_text(encoding="utf-8").strip()
            except Exception:
                existing = ""
            if existing:
                return

        snapshot = self._agent._context.export_header_snapshot()
        evt = build_header_snapshot_event(
            session_id=self.session_id,
            snapshot=snapshot,
            turn_number=0,
        )
        events_jsonl_append(self._context_jsonl, evt)

    def _persist_session_metadata(self, *, force: bool = False) -> None:
        if self._agent._task_namespace == "" or (self._storage_root / "session.json").exists() and not force:
            return
        write_session_metadata(
            self._storage_root,
            session_id=self.session_id,
            task_namespace=self._agent._task_namespace,
            team_name=self._agent._team_name,
        )

    def _bind_task_namespace(self, task_namespace: str, *, persist: bool) -> None:
        normalized = str(task_namespace or "").strip()
        if not normalized:
            return
        self._agent._task_namespace = normalized
        self._agent._task_store = TaskStore(list_id=normalized)
        if persist:
            self._persist_session_metadata(force=True)

    def _latest_task_list_id_from_conversation_history(self) -> str | None:
        for item in reversed(self._agent._context.conversation.items):
            if item.destroyed:
                continue
            if item.item_type != ItemType.TOOL_RESULT or bool(item.is_tool_error):
                continue
            if str(item.tool_name or "").strip() not in {"TaskCreate", "TaskList", "TaskUpdate"}:
                continue

            envelope = (item.metadata or {}).get("tool_raw_envelope")
            if not isinstance(envelope, dict):
                continue
            data = envelope.get("data", {})
            if not isinstance(data, dict):
                continue

            list_id = str(data.get("list_id", "")).strip()
            if list_id:
                return list_id
        return None

    def _restore_task_state_from_conversation_history(self) -> None:
        for item in reversed(self._agent._context.conversation.items):
            if item.destroyed:
                continue
            if item.item_type != ItemType.TOOL_RESULT or bool(item.is_tool_error):
                continue
            if str(item.tool_name or "").strip() not in {"TaskCreate", "TaskList", "TaskUpdate"}:
                continue

            envelope = (item.metadata or {}).get("tool_raw_envelope")
            if not isinstance(envelope, dict):
                continue
            data = envelope.get("data", {})
            if not isinstance(data, dict):
                continue

            raw_tasks = data.get("tasks", [])
            if not isinstance(raw_tasks, list):
                continue

            tasks = [task for task in raw_tasks if isinstance(task, dict)]
            turn_number_at_update = max(0, int(getattr(item, "created_turn", 0) or 0))
            self._agent._context.reminder_engine.restore_task_list(
                tasks=tasks,
                turn_number_at_update=turn_number_at_update,
                current_turn=self._agent._context.turn_number,
                list_id=str(data.get("list_id", "default") or "default"),
            )
            logger.info(f"Restored {len(tasks)} task items from conversation history")
            return

        logger.debug(
            f"No Task tool envelope found for session_id={self.session_id}; skipped task detail restore"
        )

    def _restore_task_state_from_task_store(self) -> None:
        store = getattr(self._agent, "_task_store", None)
        if store is None:
            return

        tasks_payload: list[dict[str, object]] = []
        for task in store.list_tasks():
            payload = task.model_dump(mode="json")
            payload["blocks"] = list(task.blocks)
            payload["open_blocked_by"] = store.get_open_blocked_by(task.id)
            tasks_payload.append(payload)

        self._agent._context.reminder_engine.restore_task_list(
            tasks=tasks_payload,
            turn_number_at_update=self._agent._context.turn_number,
            current_turn=self._agent._context.turn_number,
            list_id=store.list_id_value(),
        )
        logger.info(
            f"Restored {len(tasks_payload)} task item(s) from task store "
            f"for session_id={self.session_id} namespace={store.list_id_value()}"
        )

    @classmethod
    def resume(
        cls,
        template: AgentTemplate,
        *,
        session_id: str,
        cwd: PathInput | None = None,
        message_source: MessageSource | None = None,
    ) -> "ChatSession":
        resolved_cwd = normalize_cwd(cwd if cwd is not None else template.config.cwd)
        session_root = default_session_root(session_id, cwd=resolved_cwd)
        metadata = load_session_metadata(session_root)
        context_jsonl = session_root / "context.jsonl"
        header_snapshot = replay_header_snapshot(path=context_jsonl)
        if header_snapshot is None:
            raise ChatSessionError(
                f"Session {session_id} is missing required header_snapshot in {context_jsonl}"
            )
        try:
            runtime = template.create_runtime_from_snapshot(
                cwd=resolved_cwd,
                header_snapshot=header_snapshot,
                session_id=session_id,
                task_namespace=metadata["task_namespace"] if metadata is not None else None,
                team_name=metadata.get("team_name", "") if metadata is not None else "",
            )
        except Exception as e:
            raise ChatSessionError(
                f"Failed to restore header snapshot for session {session_id}: {e}"
            ) from e
        session = cls(
            template,
            runtime=runtime,
            cwd=resolved_cwd,
            session_id=session_id,
            message_source=message_source,
        )

        turn_number, items, usage_entries = replay_session_events(
            path=session._context_jsonl,
            offload_root=session._offload_root,
        )
        session._turn_number = int(turn_number)
        if items:
            session._agent._context.replace_conversation(items)
        else:
            logger.info(f"No persisted conversation found for session_id={session_id}, starting empty")
        session._agent._token_cost.usage_history = usage_entries

        session._agent._context.set_turn_number(session._turn_number)
        try:
            session._agent._context.rehydrate_reminder_state_from_conversation(
                suppress_task_nudge_on_next_turn=True,
            )
        except Exception as e:
            logger.warning(
                f"Failed to rehydrate reminder state for session_id={session_id}: {e}",
                exc_info=True,
            )

        try:
            has_env_override = bool(str(os.environ.get("COMATE_TASK_LIST_ID", "")).strip())
            has_config_override = bool(str(template.config.task_namespace or "").strip())
            if metadata is None and not has_env_override and not has_config_override:
                legacy_namespace = session._latest_task_list_id_from_conversation_history()
                if legacy_namespace and legacy_namespace != session._agent._task_namespace:
                    session._bind_task_namespace(legacy_namespace, persist=True)
                elif metadata is None:
                    session._persist_session_metadata(force=True)
            elif metadata is None:
                session._persist_session_metadata(force=True)
            session._restore_task_state_from_task_store()
        except Exception as e:
            logger.warning(
                f"Failed to restore task details from task store for session_id={session_id}: {e}",
                exc_info=True,
            )

        # Header 从持久化快照恢复后，禁止自动改写 static header。
        session._agent._lock_header_from_snapshot = True

        return session

    def fork_session(
        self,
        *,
        message_source: MessageSource | None = None,
    ) -> "ChatSession":
        new_session_id = str(uuid.uuid4())
        src = self._storage_root
        dst = default_session_root(new_session_id, cwd=self._cwd)

        if self._closed:
            raise ChatSessionClosedError("Cannot fork a closed session")

        if dst.exists():
            raise ChatSessionError(f"Fork destination already exists: {dst}")

        dst.parent.mkdir(parents=True, exist_ok=True)
        self._ensure_header_persisted()  # fork 前必须保证快照已存在于源目录
        shutil.copytree(src, dst)

        forked_external_turns = external_turns_journal_path(dst)
        if forked_external_turns.exists():
            forked_external_turns.unlink()

        rewrite_session_id_in_jsonl(dst / "context.jsonl", session_id=new_session_id)

        offload_index = dst / "offload" / "index.json"
        if offload_index.exists():
            try:
                data = json.loads(offload_index.read_text(encoding="utf-8"))
                data["session_id"] = new_session_id
                offload_index.write_text(
                    json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8"
                )
            except Exception as e:
                logger.warning(f"Failed to rewrite offload index session_id: {e}")

        try:
            write_session_metadata(
                dst,
                session_id=new_session_id,
                task_namespace=new_session_id,
                team_name="",
            )
        except Exception as e:
            logger.warning(f"Failed to rewrite session metadata for forked session: {e}")

        return ChatSession.resume(
            self._template,
            session_id=new_session_id,
            cwd=self._cwd,
            message_source=message_source,
        )

    async def get_usage(
        self,
        *,
        model: str | None = None,
        source_prefix: str | None = None,
    ) -> UsageSummary:
        """获取会话的 token 使用统计。"""
        return await self._agent.get_usage(
            model=model,
            source_prefix=source_prefix,
        )

    async def get_context_info(self):
        """获取当前会话的上下文使用情况。"""
        return await self._agent.get_context_info()

    async def compact_context_manual(self):
        """手动触发一次上下文压缩（不依赖阈值）。"""
        if self._closed:
            raise ChatSessionClosedError("Cannot compact context on a closed session")
        return await self._agent.compact_context_manual()

    def get_mode(self) -> str:
        if self._closed:
            raise ChatSessionClosedError("Cannot get mode on a closed session")
        return self._agent.get_mode()

    def set_mode(self, mode: str) -> str:
        if self._closed:
            raise ChatSessionClosedError("Cannot set mode on a closed session")
        self._agent.set_mode(mode)
        return self._agent.get_mode()

    def cycle_mode(self) -> str:
        if self._closed:
            raise ChatSessionClosedError("Cannot cycle mode on a closed session")
        return self._agent.cycle_mode()

    def has_pending_plan_approval(self) -> bool:
        if self._closed:
            raise ChatSessionClosedError("Cannot read pending plan approval on a closed session")
        return self._agent.has_pending_plan_approval()

    def get_pending_plan_approval(self) -> dict[str, str] | None:
        if self._closed:
            raise ChatSessionClosedError("Cannot read pending plan approval on a closed session")
        return self._agent.pending_plan_approval()

    def approve_plan(self, *, clear_context: bool = False) -> str:
        if self._closed:
            raise ChatSessionClosedError("Cannot approve plan on a closed session")
        return self._agent.approve_plan(clear_context=clear_context)

    def reject_plan(self) -> None:
        if self._closed:
            raise ChatSessionClosedError("Cannot reject plan on a closed session")
        self._agent.reject_plan()

    def _update_total_usage(self, new_entries: list) -> None:
        """把本 turn 的 usage entries 追加写入 total_usage.json。"""
        if not new_entries:
            return
        try:
            total_usage_path = self._storage_root / "total_usage.json"
            if total_usage_path.exists():
                snapshot = TotalUsageSnapshot.load(total_usage_path)
            else:
                snapshot = TotalUsageSnapshot.new(session_id=self.session_id)
            snapshot.add_turn_entries(new_entries)
            snapshot.save(total_usage_path)
        except Exception as e:
            logger.warning(f"Failed to update total_usage.json: {e}", exc_info=True)

    async def get_total_usage(self) -> TotalUsageSnapshot:
        """获取会话累计 token 使用快照（total_usage.json）。"""
        total_usage_path = self._storage_root / "total_usage.json"
        if total_usage_path.exists():
            return TotalUsageSnapshot.load(total_usage_path)
        return TotalUsageSnapshot.new(session_id=self.session_id)

    def clear_history(self) -> None:
        """清空会话历史和 token 使用记录。"""
        if self._closed:
            raise ChatSessionClosedError("Cannot clear history on a closed session")

        self._ensure_header_persisted()
        self._agent.clear_history()

        self._turn_number += 1
        reset_event = {
            "schema_version": PERSISTENCE_SCHEMA_VERSION,
            "session_id": self.session_id,
            "turn_number": self._turn_number,
            "op": "conversation_reset",
            "conversation": {
                "items": []
            },
        }
        events_jsonl_append(self._context_jsonl, reset_event)
        usage_reset_event = {
            "schema_version": PERSISTENCE_SCHEMA_VERSION,
            "session_id": self.session_id,
            "turn_number": self._turn_number,
            "op": "usage_reset",
            "usage": {
                "entries": []
            },
        }
        events_jsonl_append(self._context_jsonl, usage_reset_event)

    def restore_conversation_to_turn(self, *, target_turn: int) -> None:
        """仅回滚会话对话到指定 turn（不回滚 usage）。"""
        if self._closed:
            raise ChatSessionClosedError("Cannot restore conversation on a closed session")

        try:
            normalized_turn = int(target_turn)
        except Exception as exc:
            raise ChatSessionError(f"Invalid target_turn={target_turn}") from exc

        if normalized_turn < 0:
            raise ChatSessionError(f"target_turn must be >= 0, got {normalized_turn}")
        if normalized_turn > self._turn_number:
            raise ChatSessionError(
                f"target_turn={normalized_turn} exceeds current turn={self._turn_number}"
            )

        _, items, _ = replay_session_events(
            path=self._context_jsonl,
            offload_root=self._offload_root,
            max_turn=normalized_turn,
        )

        before = ConversationState.capture(self._agent._context.get_conversation_items_snapshot())
        self._agent._context.replace_conversation(list(items))

        self._turn_number += 1
        evt = build_conversation_event(
            session_id=self.session_id,
            turn_number=self._turn_number,
            before=before,
            after_items=self._agent._context.get_conversation_items_snapshot(),
            offload_root=self._offload_root,
        )
        events_jsonl_append(self._context_jsonl, evt)
        self._agent._context.set_turn_number(self._turn_number)
        self._agent._context.rehydrate_reminder_state_from_conversation(
            suppress_task_nudge_on_next_turn=True,
        )

    def set_level(self, level: LLMLevel) -> LLMSwitchedEvent:
        """Set the LLM level for this session."""
        if self._closed:
            raise ChatSessionClosedError("Cannot set level on a closed session")

        previous_level = self._agent.level
        previous_model = self._agent.llm.model if self._agent.llm else None

        self._agent.level = level

        if self._agent._runtime_state.llm_levels and level in self._agent._runtime_state.llm_levels:
            self._agent.llm = self._agent._runtime_state.llm_levels[level]

        setting_sources = self._agent.config.setting_sources
        should_persist_model = bool(setting_sources and "user" in setting_sources)
        if should_persist_model:
            try:
                persist_user_model_preference(level)
            except Exception as e:
                logger.warning(
                    f"Session {self.session_id}: model 偏好持久化失败（忽略）: {e}",
                    exc_info=True,
                )

        new_model = None
        if self._agent._runtime_state.llm_levels and level in self._agent._runtime_state.llm_levels:
            new_model = self._agent._runtime_state.llm_levels[level].model

        event = LLMSwitchedEvent(
            previous_level=previous_level,
            new_level=level,
            previous_model=previous_model,
            new_model=new_model,
        )

        logger.info(f"Session {self.session_id}: {event}")
        return event

    async def send(self, message: ChatMessage) -> None:
        if self._closed:
            raise ChatSessionClosedError("ChatSession is closed")
        if self._message_source is not None:
            raise ChatSessionError("send() is not allowed when message_source is provided")
        await self._queue.put(message)

    async def close(self) -> None:
        if self._closed:
            return
        if self._agent._hooks_session_started and not self._agent._hooks_session_ended:
            await self._agent.run_hook_event("SessionEnd")
            self._agent._hooks_session_ended = True
        # Runtime may be reused across ChatSession instances.
        self._agent._hooks_session_started = False
        self._agent._hooks_session_ended = False
        self._closed = True
        self._clear_owned_external_turn_callback()
        if self._message_source_task is not None:
            self._message_source_task.cancel()
            with suppress(asyncio.CancelledError):
                await self._message_source_task
            self._message_source_task = None
        discard_callback = self._agent._team.discard_team_turns_callback
        if (
            getattr(discard_callback, "__self__", None) is self
            and getattr(discard_callback, "__func__", None) is ChatSession.discard_team_external_turns
        ):
            self._agent._team.discard_team_turns_callback = None
        await self._queue.put(None)

    async def shutdown(self) -> None:
        """Strong shutdown for process-exit paths.

        Compared with `close()`, this additionally tears down runtime-owned
        resources (for example MCP managers/subprocesses).
        """
        if self._shutdown_completed:
            return

        await self.close()

        runtime_aclose = getattr(self._agent, "aclose", None)
        if callable(runtime_aclose):
            await runtime_aclose()

        self._shutdown_completed = True

    async def __aenter__(self) -> "ChatSession":
        return self

    async def __aexit__(self, exc_type, exc, tb) -> None:
        await self.close()

    def _persist_stream_turn_delta(
        self,
        *,
        before: ConversationState,
        before_usage_count: int,
    ) -> None:
        evt = build_conversation_event(
            session_id=self.session_id,
            turn_number=self._turn_number,
            before=before,
            after_items=self._agent._context.get_conversation_items_snapshot(),
            offload_root=self._offload_root,
        )
        events_jsonl_append(self._context_jsonl, evt)
        new_entries = slice_usage_delta(
            self._agent._token_cost.usage_history,
            before_count=before_usage_count,
        )
        tracker = getattr(self._agent, "_context_usage_tracker", None)
        context_usage = tracker.context_usage if tracker is not None else None
        usage_evt = build_usage_event(
            session_id=self.session_id,
            turn_number=self._turn_number,
            added_entries=new_entries,
            context_usage=context_usage,
        )
        if usage_evt is not None:
            events_jsonl_append(self._context_jsonl, usage_evt)
        self._update_total_usage(new_entries)

    async def query_stream(self, message: ChatMessage | None = None) -> AsyncIterator[AgentEvent]:
        if self._closed:
            raise ChatSessionClosedError("ChatSession is closed")

        if not self._init_event_emitted:
            self._init_event_emitted = True
            yield SessionInitEvent(session_id=self.session_id)

        previous_external_callback = self._set_external_turn_callback()
        try:
            async for event in self._drain_session_events():
                yield event

            if self._scheduler.has_control_external_turn():
                scheduled = await self._scheduler.schedule_external_turn(
                    dispatch_reason="control"
                )
                if scheduled is not None:
                    control_terminal_events: list[StopEvent] = []
                    yield ExternalTurnScheduledEvent(
                        turn_id=scheduled.turn.turn_id,
                        source=scheduled.turn.source,
                        dispatch_reason="control",
                        queue_size_remaining=self._scheduler.external_turn_queue_size(),
                        wait_ms=0,
                    )
                    async for control_event in self._handle_control_external_turn(
                        scheduled,
                        terminal_events=control_terminal_events,
                    ):
                        yield control_event
                    async for event in self._drain_session_events():
                        yield event
                    if control_terminal_events:
                        yield control_terminal_events[-1]
                    return

            terminal_events: list[StopEvent] = []
            if message is not None:
                # --- FIFO: 先处理比用户消息更早到达的 external turns ---
                snapshot_count = self._scheduler.external_turn_queue_size()
                pre_drain_terminal: list[StopEvent] = []
                async for event in self._drain_fifo_external_turns(
                    snapshot_count=snapshot_count,
                    terminal_events=pre_drain_terminal,
                ):
                    yield event
                if pre_drain_terminal:
                    yield pre_drain_terminal[-1]
                    return

                async for event in self._run_turn_stream(
                    message=message,
                    terminal_events=terminal_events,
                ):
                    yield event

                async for event in self._drain_session_events():
                    yield event

            terminal_event = terminal_events[0] if terminal_events else None
            while True:
                if terminal_event is not None and terminal_event.reason != "completed":
                    break

                if self._scheduler.has_control_external_turn():
                    scheduled = await self._scheduler.schedule_external_turn(
                        dispatch_reason="control"
                    )
                    if scheduled is not None:
                        yield ExternalTurnScheduledEvent(
                            turn_id=scheduled.turn.turn_id,
                            source=scheduled.turn.source,
                            dispatch_reason="control",
                            queue_size_remaining=self._scheduler.external_turn_queue_size(),
                            wait_ms=0,
                        )
                        async for control_event in self._handle_control_external_turn(
                            scheduled,
                            terminal_events=terminal_events,
                        ):
                            yield control_event
                        terminal_event = terminal_events[-1] if terminal_events else terminal_event
                        break

                if not self._scheduler.has_pending_external_turns():
                    break

                scheduled = await self._scheduler.schedule_external_turn(
                    dispatch_reason="post_turn_auto"
                )
                if scheduled is None:
                    break

                external_input = ExternalTurnInput(turn=scheduled.turn)
                try:
                    continuation_terminal_events: list[StopEvent] = []
                    yield ExternalTurnScheduledEvent(
                        turn_id=scheduled.turn.turn_id,
                        source=scheduled.turn.source,
                        dispatch_reason=scheduled.dispatch_reason,
                        queue_size_remaining=self._scheduler.external_turn_queue_size(),
                        wait_ms=0,
                    )
                    async for continuation_event in self._run_turn_stream(
                        message=external_input,
                        terminal_events=continuation_terminal_events,
                    ):
                        yield continuation_event
                    await self._scheduler.complete_external_turn(
                        turn_id=scheduled.turn.turn_id,
                        dispatch_token=scheduled.dispatch_token,
                    )
                    self._ack_completed_team_inbox_turn(scheduled.turn)
                    if continuation_terminal_events:
                        terminal_event = continuation_terminal_events[-1]
                except Exception:
                    await self._scheduler.requeue_external_turn(
                        turn=scheduled.turn,
                        dispatch_token=scheduled.dispatch_token,
                        reason="execution_failed",
                    )
                    raise

                async for event in self._drain_session_events():
                    yield event

            if terminal_event is not None:
                yield terminal_event
        finally:
            self._restore_external_turn_callback(previous_external_callback)

    async def _run_turn_stream(
        self,
        *,
        message: ChatMessage | ExternalTurnInput,
        terminal_events: list[StopEvent] | None = None,
    ) -> AsyncIterator[AgentEvent]:
        self._ensure_header_persisted()
        self._turn_number += 1
        before = ConversationState.capture(self._agent._context.get_conversation_items_snapshot())
        before_usage_count = len(self._agent._token_cost.usage_history)
        previous_controller = self._agent._run_controller
        previous_turn_callback = self._agent._team.turn_complete_callback
        terminal_event: StopEvent | None = None
        self.run_controller.clear()
        self._agent._run_controller = self.run_controller

        def _persist_completed_turn() -> None:
            nonlocal before, before_usage_count
            self._persist_stream_turn_delta(
                before=before,
                before_usage_count=before_usage_count,
            )
            before = ConversationState.capture(self._agent._context.get_conversation_items_snapshot())
            before_usage_count = len(self._agent._token_cost.usage_history)
            self._turn_number += 1

        self._agent._team.turn_complete_callback = _persist_completed_turn
        try:
            timeout_ctx = (
                asyncio.timeout(self._turn_timeout)
                if self._turn_timeout is not None
                else nullcontext()
            )
            async with timeout_ctx:
                async for event in self._agent.query_stream(message):  # type: ignore[arg-type]
                    if isinstance(event, StopEvent):
                        terminal_event = event
                        break
                    yield event
        finally:
            self._agent._team.turn_complete_callback = previous_turn_callback
            self._agent._run_controller = previous_controller
            self.run_controller.clear()
            self._persist_stream_turn_delta(
                before=before,
                before_usage_count=before_usage_count,
            )
        if terminal_event is None:
            return
        if terminal_events is not None:
            terminal_events.append(terminal_event)
            return
        yield terminal_event

    async def _ensure_message_source_task(self) -> None:
        if self._message_source is None or self._message_source_task is not None:
            return

        async def _feed_messages() -> None:
            try:
                if hasattr(self._message_source, "__aiter__"):
                    async for msg in self._message_source:  # type: ignore[misc]
                        if self._closed:
                            return
                        await self._queue.put(msg)
                else:
                    for msg in self._message_source:
                        if self._closed:
                            return
                        await self._queue.put(msg)
            finally:
                self._message_source_finished = True
                await self._queue.put(None)

        self._message_source_task = asyncio.create_task(
            _feed_messages(),
            name=f"chat-session-message-source-{self.session_id}",
        )

    async def _wait_for_next_trigger(self) -> tuple[str, ChatMessage | ScheduledExternalTurn | None] | None:
        await self._ensure_message_source_task()
        while True:
            if self._scheduler.has_control_external_turn():
                scheduled = await self._scheduler.schedule_external_turn(
                    dispatch_reason="control"
                )
                if scheduled is not None:
                    return "external", scheduled

            # 先检查已排队的 external turns（它们比刚到达的用户消息更早入队）
            if self._scheduler.has_pending_external_turns():
                scheduled = await self._scheduler.schedule_external_turn(
                    dispatch_reason="idle_auto"
                )
                if scheduled is not None:
                    return "external", scheduled

            try:
                message = self._queue.get_nowait()
            except asyncio.QueueEmpty:
                message = None
            else:
                if message is None:
                    if self._closed or self._message_source_finished:
                        return None
                else:
                    return "user", message

            if self._closed:
                return None

            queue_get_task = asyncio.create_task(self._queue.get(), name="chat-session-user-queue-get")
            session_event_task = asyncio.create_task(
                self._session_event_queue.get(),
                name="chat-session-event-queue-get",
            )
            try:
                done, pending = await asyncio.wait(
                    {queue_get_task, session_event_task},
                    return_when=asyncio.FIRST_COMPLETED,
                )
                for task in pending:
                    task.cancel()
                    with suppress(asyncio.CancelledError):
                        await task
                if session_event_task in done:
                    event = session_event_task.result()
                    await self._session_event_queue.put(event)
                    continue
                message = queue_get_task.result()
                if message is None:
                    if self._closed or self._message_source_finished:
                        return None
                    continue
                return "user", message
            finally:
                for task in (queue_get_task, session_event_task):
                    if not task.done():
                        task.cancel()
                        with suppress(asyncio.CancelledError):
                            await task

    async def _handle_control_external_turn(
        self,
        scheduled: ScheduledExternalTurn,
        *,
        terminal_events: list[StopEvent] | None = None,
    ) -> AsyncIterator[AgentEvent]:
        self._ensure_header_persisted()
        payload = scheduled.turn.payload
        request_from = str(payload.get("from_agent", "") or "").strip()
        await self._scheduler.complete_external_turn(
            turn_id=scheduled.turn.turn_id,
            dispatch_token=scheduled.dispatch_token,
        )
        self._ack_completed_team_inbox_turn(scheduled.turn)
        metadata = {}
        if request_from:
            metadata["shutdown_recipients"] = [request_from]
        stop_event = StopEvent(reason="shutdown_request", metadata=metadata)
        if terminal_events is not None:
            terminal_events.append(stop_event)
            return
        yield stop_event

    async def events(self) -> AsyncIterator[AgentEvent]:
        if self._events_started:
            raise ChatSessionError("events() can only be consumed once")
        self._events_started = True

        if not self._init_event_emitted:
            self._init_event_emitted = True
            yield SessionInitEvent(session_id=self.session_id)

        previous_external_callback = self._set_external_turn_callback()
        try:
            while True:
                async for event in self._drain_session_events():
                    yield event

                trigger = await self._wait_for_next_trigger()
                if trigger is None:
                    return

                async for event in self._drain_session_events():
                    yield event

                trigger_kind, payload = trigger
                if trigger_kind == "user":
                    assert payload is not None
                    async for event in self._run_turn_stream(message=payload):
                        yield event
                    continue

                assert isinstance(payload, ScheduledExternalTurn)
                if is_control_external_turn(payload.turn):
                    control_terminal_events: list[StopEvent] = []
                    yield ExternalTurnScheduledEvent(
                        turn_id=payload.turn.turn_id,
                        source=payload.turn.source,
                        dispatch_reason="control",
                        queue_size_remaining=self._scheduler.external_turn_queue_size(),
                        wait_ms=0,
                    )
                    async for event in self._handle_control_external_turn(
                        payload,
                        terminal_events=control_terminal_events,
                    ):
                        yield event
                    if control_terminal_events:
                        yield control_terminal_events[-1]
                    return

                external_input = ExternalTurnInput(turn=payload.turn)
                try:
                    terminal_events: list[StopEvent] = []
                    yield ExternalTurnScheduledEvent(
                        turn_id=payload.turn.turn_id,
                        source=payload.turn.source,
                        dispatch_reason=payload.dispatch_reason,
                        queue_size_remaining=self._scheduler.external_turn_queue_size(),
                        wait_ms=0,
                    )
                    async for event in self._run_turn_stream(
                        message=external_input,
                        terminal_events=terminal_events,
                    ):
                        yield event
                    await self._scheduler.complete_external_turn(
                        turn_id=payload.turn.turn_id,
                        dispatch_token=payload.dispatch_token,
                    )
                    self._ack_completed_team_inbox_turn(payload.turn)
                    if terminal_events:
                        yield terminal_events[-1]
                except Exception:
                    await self._scheduler.requeue_external_turn(
                        turn=payload.turn,
                        dispatch_token=payload.dispatch_token,
                        reason="execution_failed",
                    )
                    raise
        finally:
            self._restore_external_turn_callback(previous_external_callback)

    async def _message_iter(self) -> AsyncIterator[ChatMessage]:
        if self._message_source is not None:
            if hasattr(self._message_source, "__aiter__"):
                async for msg in self._message_source:  # type: ignore[misc]
                    if self._closed:
                        return
                    yield msg
            else:
                for msg in self._message_source:
                    if self._closed:
                        return
                    yield msg
            return

        while True:
            msg = await self._queue.get()
            if msg is None:
                return
            yield msg
