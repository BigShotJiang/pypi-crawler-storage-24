from __future__ import annotations

import asyncio
import tempfile
import unittest
from pathlib import Path
from types import MethodType, SimpleNamespace
from unittest.mock import AsyncMock, patch

from comate_agent_sdk.agent import Agent, AgentConfig
from comate_agent_sdk.agent.chat_session import ChatSession
from comate_agent_sdk.agent.core.team_state import TeamCoordinationState
from comate_agent_sdk.llm.views import ChatInvokeCompletion
from comate_agent_sdk.system_tools.team.inbox_transport import BufferedInboxBatch, TeamInboxEnvelope
from comate_agent_sdk.subagent.agent_tool import _clear_team_namespace, _switch_parent_to_team_namespace


class _FakeChatModel:
    def __init__(self) -> None:
        self.model = "fake:model"

    @property
    def provider(self) -> str:
        return "fake"

    @property
    def name(self) -> str:
        return self.model

    async def ainvoke(self, messages, tools=None, tool_choice=None, **kwargs):  # type: ignore[no-untyped-def]
        raise AssertionError("This test should not call the LLM")


class _StaticChatModel:
    def __init__(self, content: str = "ok") -> None:
        self.model = "fake:model"
        self._content = content

    @property
    def provider(self) -> str:
        return "fake"

    @property
    def name(self) -> str:
        return self.model

    async def ainvoke(self, messages, tools=None, tool_choice=None, **kwargs):  # type: ignore[no-untyped-def]
        del messages, tools, tool_choice, kwargs
        return ChatInvokeCompletion(content=self._content)


class _FakeMcpManager:
    def __init__(self) -> None:
        self.close_calls = 0

    async def aclose(self) -> None:
        self.close_calls += 1


class TestRuntimeShutdown(unittest.IsolatedAsyncioTestCase):
    def setUp(self) -> None:
        super().setUp()
        self._team_poll_patch = patch.dict(
            "os.environ",
            {"COMATE_TEAM_POLL_INTERVAL_SECONDS": "0.01"},
        )
        self._team_poll_patch.start()
        self.addCleanup(self._team_poll_patch.stop)

    def _build_runtime(self):
        template = Agent(
            llm=_FakeChatModel(),  # type: ignore[arg-type]
            config=AgentConfig(
                tools=(),
                agents=(),
                offload_enabled=False,
                setting_sources=None,
            ),
        )
        return template, template.create_runtime(session_id="runtime-shutdown-test")

    async def test_runtime_aclose_is_idempotent(self) -> None:
        _, runtime = self._build_runtime()
        manager = _FakeMcpManager()
        runtime._mcp_manager = manager
        runtime._mcp_loaded = True
        runtime._mcp_dirty = True
        runtime._mcp_pending_tool_names = ["mcp__demo__tool"]

        await runtime.aclose()
        await runtime.aclose()

        self.assertEqual(manager.close_calls, 1)
        self.assertIsNone(runtime._mcp_manager)
        self.assertFalse(runtime._mcp_loaded)
        self.assertFalse(runtime._mcp_dirty)
        self.assertEqual(runtime._mcp_pending_tool_names, [])

    async def test_runtime_uses_shared_team_poll_interval_config(self) -> None:
        _, runtime = self._build_runtime()

        self.assertEqual(runtime._team.poll_interval_seconds, 0.01)

    async def test_chat_session_shutdown_closes_runtime_once(self) -> None:
        template, runtime = self._build_runtime()
        runtime.aclose = AsyncMock()  # type: ignore[method-assign]

        with tempfile.TemporaryDirectory() as tmp:
            session = ChatSession(
                template,
                runtime=runtime,
                session_id=runtime._session_id,
                cwd=Path(tmp),
            )
            await session.shutdown()
            await session.shutdown()

        self.assertIs(session.runtime, runtime)
        self.assertTrue(session._closed)
        self.assertTrue(session._shutdown_completed)
        runtime.aclose.assert_awaited_once()

    async def test_start_mcp_preload_reuses_existing_task_and_ensure_waits(self) -> None:
        _, runtime = self._build_runtime()
        started = asyncio.Event()
        release = asyncio.Event()
        call_count = 0

        async def _fake_load(self, *, force: bool = False) -> None:
            del force
            nonlocal call_count
            call_count += 1
            started.set()
            await release.wait()
            self._mcp_loaded = True
            self._mcp_dirty = False

        runtime._load_mcp_tools = MethodType(_fake_load, runtime)  # type: ignore[method-assign]

        task1 = runtime.start_mcp_preload()
        self.assertIsNotNone(task1)
        await started.wait()

        task2 = runtime.start_mcp_preload()
        self.assertIs(task1, task2)

        ensure_task = asyncio.create_task(runtime.ensure_mcp_tools_loaded())
        await asyncio.sleep(0)
        self.assertFalse(ensure_task.done())

        release.set()
        await asyncio.gather(task1, ensure_task)

        self.assertEqual(call_count, 1)
        self.assertTrue(runtime._mcp_loaded)
        self.assertFalse(runtime._mcp_dirty)
        self.assertIsNone(runtime._mcp_preload_task)

    async def test_runtime_aclose_cancels_mcp_preload_task(self) -> None:
        _, runtime = self._build_runtime()
        cancelled = asyncio.Event()

        async def _fake_load(self, *, force: bool = False) -> None:
            del force
            try:
                await asyncio.Event().wait()
            except asyncio.CancelledError:
                cancelled.set()
                raise

        runtime._load_mcp_tools = MethodType(_fake_load, runtime)  # type: ignore[method-assign]

        preload_task = runtime.start_mcp_preload()
        self.assertIsNotNone(preload_task)
        await asyncio.sleep(0)

        await runtime.aclose()

        self.assertTrue(cancelled.is_set())
        self.assertIsNone(runtime._mcp_preload_task)

    async def test_runtime_query_auto_starts_mcp_preload(self) -> None:
        _, runtime = self._build_runtime()
        preload_calls = 0

        def _fake_start_mcp_preload(*, force: bool = False):  # type: ignore[no-untyped-def]
            del force
            nonlocal preload_calls
            preload_calls += 1
            return None

        runtime.start_mcp_preload = _fake_start_mcp_preload  # type: ignore[method-assign]

        async def _fake_run_query(_runtime, message: str) -> str:
            self.assertIs(_runtime, runtime)
            self.assertEqual(message, "hello")
            return "ok"

        with patch("comate_agent_sdk.agent.runner_engine.run_query", _fake_run_query):
            result = await runtime.query("hello")

        self.assertEqual(result, "ok")
        self.assertEqual(preload_calls, 1)

    async def test_runtime_query_stream_auto_starts_mcp_preload(self) -> None:
        _, runtime = self._build_runtime()
        preload_calls = 0

        def _fake_start_mcp_preload(*, force: bool = False):  # type: ignore[no-untyped-def]
            del force
            nonlocal preload_calls
            preload_calls += 1
            return None

        runtime.start_mcp_preload = _fake_start_mcp_preload  # type: ignore[method-assign]

        async def _fake_run_query_stream(_runtime, message: str):  # type: ignore[no-untyped-def]
            self.assertIs(_runtime, runtime)
            self.assertEqual(message, "stream")
            yield "event-1"
            yield "event-2"

        events: list[str] = []
        with patch(
            "comate_agent_sdk.agent.runner_engine.run_query_stream",
            _fake_run_query_stream,
        ):
            async for event in runtime.query_stream("stream"):
                events.append(event)

        self.assertEqual(events, ["event-1", "event-2"])
        self.assertEqual(preload_calls, 1)

    async def test_runtime_aclose_cancels_background_subagent_tasks(self) -> None:
        _, runtime = self._build_runtime()
        cancelled = asyncio.Event()

        async def _run_forever() -> None:
            try:
                await asyncio.Event().wait()
            except asyncio.CancelledError:
                cancelled.set()
                raise

        background_task = asyncio.create_task(_run_forever())
        runtime.register_team_session(
            team_name="review-team",
            name="worker-1",
            task=background_task,
        )
        await asyncio.sleep(0)

        await runtime.aclose()

        self.assertTrue(cancelled.is_set())
        self.assertFalse(
            runtime.has_active_team_session(
                team_name="review-team",
                name="worker-1",
            )
        )

    async def test_runtime_aclose_cancels_inbox_poll_task(self) -> None:
        _, runtime = self._build_runtime()
        cancelled = asyncio.Event()

        async def _poll_forever() -> None:
            try:
                await asyncio.Event().wait()
            except asyncio.CancelledError:
                cancelled.set()
                raise

        runtime._team.inbox_poll_task = asyncio.create_task(_poll_forever())
        await asyncio.sleep(0)
        await runtime.aclose()

        self.assertTrue(cancelled.is_set())
        self.assertIsNone(runtime._team.inbox_poll_task)

    async def test_chat_session_close_stops_inbox_poll_task_without_closing_runtime(self) -> None:
        template, runtime = self._build_runtime()
        runtime.aclose = AsyncMock()  # type: ignore[method-assign]
        runtime._team_name = "review-team"

        with tempfile.TemporaryDirectory() as tmp:
            session = ChatSession(
                template,
                runtime=runtime,
                session_id=runtime._session_id,
                cwd=Path(tmp) / "s1",
            )

            previous_callback = session._set_external_turn_callback()
            self.assertIsNone(previous_callback)
            await asyncio.sleep(0)
            self.assertIsNotNone(runtime._team.inbox_poll_task)

            await session.close()
            session._restore_external_turn_callback(previous_callback)

            self.assertTrue(session._closed)
            self.assertIsNone(runtime._team.external_turn_callback)
            self.assertIsNone(runtime._team.inbox_poll_task)
            runtime.aclose.assert_not_awaited()

            session2 = ChatSession(
                template,
                runtime=runtime,
                session_id=runtime._session_id,
                cwd=Path(tmp) / "s2",
            )
            previous_callback2 = session2._set_external_turn_callback()
            self.assertIsNone(previous_callback2)
            self.assertIsNotNone(runtime._team.inbox_poll_task)
            await session2.close()

    async def test_inbox_poll_loop_uses_fixed_interval(self) -> None:
        _, runtime = self._build_runtime()
        runtime._team_name = "review-team"
        runtime._team.poll_interval_seconds = 0.5
        runtime._team.external_turn_callback = AsyncMock()
        runtime._poll_team_inbox_once = AsyncMock(side_effect=["idle", "idle", "event"])  # type: ignore[method-assign]

        sleep_calls: list[float] = []

        async def _fake_sleep(delay: float) -> None:
            sleep_calls.append(delay)
            if len(sleep_calls) >= 3:
                runtime._team.external_turn_callback = None

        with patch("comate_agent_sdk.agent.core.team_state.asyncio.sleep", _fake_sleep):
            await runtime._run_inbox_poll_loop()

        self.assertEqual(sleep_calls, [0.5, 0.5, 0.5])
        self.assertEqual(runtime._poll_team_inbox_once.await_count, 3)

    async def test_inbox_poll_loop_keeps_running_across_idle_until_callback_clears(self) -> None:
        _, runtime = self._build_runtime()
        runtime._team_name = "review-team"
        runtime._team.poll_interval_seconds = 0.5
        runtime._team.external_turn_callback = AsyncMock()
        runtime._poll_team_inbox_once = AsyncMock(side_effect=["idle"] * 6)  # type: ignore[method-assign]

        sleep_calls: list[float] = []

        async def _fake_sleep(delay: float) -> None:
            sleep_calls.append(delay)
            if len(sleep_calls) >= 6:
                runtime._team.external_turn_callback = None

        with patch("comate_agent_sdk.agent.core.team_state.asyncio.sleep", _fake_sleep):
            runtime._start_inbox_poll_task()
            task = runtime._team.inbox_poll_task
            self.assertIsNotNone(task)
            assert task is not None
            await task

        self.assertEqual(sleep_calls, [0.5, 0.5, 0.5, 0.5, 0.5, 0.5])
        self.assertIsNone(runtime._team.inbox_poll_task)

    async def test_sync_inbox_poll_task_starts_only_when_team_mode_and_callback_present(self) -> None:
        _, runtime = self._build_runtime()

        runtime._sync_inbox_poll_task()
        self.assertIsNone(runtime._team.inbox_poll_task)

        runtime._team_name = "review-team"
        runtime._sync_inbox_poll_task()
        self.assertIsNone(runtime._team.inbox_poll_task)

        runtime._team.external_turn_callback = AsyncMock()
        runtime._sync_inbox_poll_task()
        self.assertIsNotNone(runtime._team.inbox_poll_task)

        await runtime._stop_inbox_poll_task_async()
        self.assertIsNone(runtime._team.inbox_poll_task)

    async def test_team_inbox_delivery_mode_resolution_prefers_external_turn(self) -> None:
        _, runtime = self._build_runtime()

        self.assertEqual(runtime._resolve_team_inbox_delivery_mode(), "disabled")

        runtime._team_name = "review-team"
        self.assertEqual(runtime._resolve_team_inbox_delivery_mode(), "legacy_buffer")

        runtime._team.external_turn_callback = AsyncMock()
        self.assertEqual(runtime._resolve_team_inbox_delivery_mode(), "external_turn")

        runtime._team.disable_legacy_inbox_poll = True
        self.assertEqual(runtime._resolve_team_inbox_delivery_mode(), "external_turn")

        runtime._team.external_turn_callback = None
        self.assertEqual(runtime._resolve_team_inbox_delivery_mode(), "disabled")

    async def test_poll_team_inbox_once_filters_duplicate_keys_in_both_delivery_modes(self) -> None:
        _, runtime = self._build_runtime()
        runtime._team_name = "review-team"

        duplicate_event = TeamInboxEnvelope(
            key="dup-1",
            from_agent="worker-1",
            message_type="message",
            content="duplicate",
            timestamp="2026-03-11T00:00:00+00:00",
            raw_envelope={},
        )
        fresh_event = TeamInboxEnvelope(
            key="fresh-1",
            from_agent="worker-2",
            message_type="message",
            content="fresh",
            timestamp="2026-03-11T00:00:01+00:00",
            raw_envelope={},
        )

        class _FakeTransport:
            acked_keys: list[str] = []

            def __init__(self, *, team_name: str, agent_name: str) -> None:
                del team_name, agent_name

            def poll_new(self) -> BufferedInboxBatch:
                return BufferedInboxBatch(events=[duplicate_event, fresh_event])

            def ack(self, keys: list[str]) -> None:
                self.acked_keys.extend(keys)

        with patch("comate_agent_sdk.agent.core.team_state.TeamInboxTransport", _FakeTransport):
            runtime._team.pending_inbox_keys = {"dup-1"}
            outcome = await runtime._poll_team_inbox_once()
            self.assertEqual(outcome, "event")
            self.assertEqual([event.key for event in runtime._team.pending_inbox_events], ["fresh-1"])
            self.assertEqual(runtime._team.pending_inbox_keys, {"dup-1", "fresh-1"})

            runtime._team.pending_inbox_events.clear()
            runtime._team.pending_inbox_keys = {"dup-1"}
            runtime._team.external_turn_callback = AsyncMock(
                return_value=SimpleNamespace(accepted=True, should_ack=True)
            )

            outcome = await runtime._poll_team_inbox_once()
            self.assertEqual(outcome, "event")
            runtime._team.external_turn_callback.assert_awaited_once()
            queued_turn = runtime._team.external_turn_callback.await_args.args[0]
            messages = queued_turn.payload.get("messages")
            self.assertEqual([item["key"] for item in messages], ["fresh-1"])
            self.assertEqual(runtime._team.pending_inbox_keys, {"dup-1", "fresh-1"})
            self.assertEqual(_FakeTransport.acked_keys, [])

    async def test_team_namespace_switch_syncs_inbox_poll_task(self) -> None:
        _, runtime = self._build_runtime()
        runtime._team.external_turn_callback = AsyncMock()

        _switch_parent_to_team_namespace(runtime, "review-team")
        self.assertIsNotNone(runtime._team.inbox_poll_task)

        _clear_team_namespace(runtime)
        await asyncio.sleep(0)
        self.assertIsNone(runtime._team.inbox_poll_task)

    async def test_chat_session_query_stream_uses_delivery_mode_to_disable_legacy_poll(self) -> None:
        template = Agent(
            llm=_StaticChatModel(),  # type: ignore[arg-type]
            config=AgentConfig(
                tools=(),
                agents=(),
                offload_enabled=False,
                setting_sources=None,
            ),
        )
        runtime = template.create_runtime(session_id="runtime-shutdown-test")
        session = ChatSession(template, runtime=runtime)

        self.assertTrue(runtime._team.disable_legacy_inbox_poll)
        self.assertEqual(runtime._resolve_team_inbox_delivery_mode(), "disabled")

        with (
            patch(
                "comate_agent_sdk.agent.runner_engine.query_stream.loop_hooks.check_legacy_before_turn",
                new_callable=AsyncMock,
            ) as check_legacy_before_turn,
            patch(
                "comate_agent_sdk.agent.runner_engine.query_stream.loop_hooks.run_legacy_turn_end",
                new_callable=AsyncMock,
            ) as run_legacy_turn_end,
        ):
            events = [event async for event in session.query_stream("hello")]

        self.assertTrue(events)
        check_legacy_before_turn.assert_not_awaited()
        run_legacy_turn_end.assert_not_awaited()
        await session.shutdown()

    async def test_clear_team_namespace_discards_runtime_inbox_backlog(self) -> None:
        _, runtime = self._build_runtime()
        runtime._team_name = "review-team"
        runtime._task_namespace = "review-team"
        runtime._team.pending_inbox_events.append(
            TeamInboxEnvelope(
                key="evt-1",
                from_agent="worker-1",
                message_type="message",
                content="done",
                timestamp="2026-03-11T00:00:00+00:00",
                raw_envelope={},
            )
        )
        runtime._team.pending_inbox_keys.add("evt-1")
        runtime._team.acked_inbox_keys.add("evt-acked")

        _clear_team_namespace(runtime)
        await asyncio.sleep(0)

        self.assertEqual(runtime._team.pending_inbox_events, [])
        self.assertEqual(runtime._team.pending_inbox_keys, set())
        self.assertEqual(runtime._team.acked_inbox_keys, set())
        self.assertEqual(runtime._team_name, "")


class TestTeamCoordinationStateCancelAllSessions(unittest.IsolatedAsyncioTestCase):
    async def test_cancel_all_sessions_cancels_and_clears(self) -> None:
        state = TeamCoordinationState()
        ev = asyncio.Event()

        async def long_task() -> None:
            await ev.wait()

        task1 = asyncio.get_event_loop().create_task(long_task())
        task2 = asyncio.get_event_loop().create_task(long_task())
        state.session_tasks["team::a"] = task1
        state.session_tasks["team::b"] = task2

        await state.cancel_all_sessions()

        self.assertEqual(state.session_tasks, {})
        self.assertTrue(task1.cancelled())
        self.assertTrue(task2.cancelled())

    async def test_cancel_all_sessions_empty_is_noop(self) -> None:
        state = TeamCoordinationState()
        await state.cancel_all_sessions()  # should not raise
        self.assertEqual(state.session_tasks, {})


if __name__ == "__main__":
    unittest.main(verbosity=2)
