from __future__ import annotations

import json
import unittest

from comate_agent_sdk.agent import Agent, AgentConfig
from comate_agent_sdk.agent.events import StopEvent, TextEvent, ToolResultEvent
from comate_agent_sdk.llm.messages import Function, ToolCall
from comate_agent_sdk.llm.views import ChatInvokeCompletion
from comate_agent_sdk.system_tools.tool_result import err
from comate_agent_sdk.system_tools.tools import YieldTurn
from comate_agent_sdk.tools import tool


class _FakeChatModel:
    def __init__(self, completions: list[ChatInvokeCompletion]):
        self._completions = completions
        self._idx = 0
        self.model = "fake:model"

    @property
    def provider(self) -> str:
        return "fake"

    @property
    def name(self) -> str:
        return self.model

    async def ainvoke(self, messages, tools=None, tool_choice=None, **kwargs):  # type: ignore[no-untyped-def]
        del messages, tools, tool_choice, kwargs
        if self._idx >= len(self._completions):
            raise AssertionError(f"Unexpected ainvoke call #{self._idx + 1}")
        completion = self._completions[self._idx]
        self._idx += 1
        return completion


def _tool_call(*, tool_call_id: str, name: str, arguments: dict) -> ToolCall:
    return ToolCall(
        id=tool_call_id,
        function=Function(
            name=name,
            arguments=json.dumps(arguments, ensure_ascii=False),
        ),
    )


class TestRunnerStreamYieldTurn(unittest.IsolatedAsyncioTestCase):
    async def test_yield_turn_stops_with_yielded_reason(self) -> None:
        llm = _FakeChatModel(
            [
                ChatInvokeCompletion(
                    tool_calls=[
                        _tool_call(
                            tool_call_id="tc_yield_1",
                            name="YieldTurn",
                            arguments={"status": "waiting_for_teammate"},
                        )
                    ]
                )
            ]
        )
        template = Agent(
            llm=llm,  # type: ignore[arg-type]
            config=AgentConfig(
                tools=(YieldTurn,),
                agents=(),
                offload_enabled=False,
            ),
        )
        agent = template.create_runtime()

        events = []
        async for event in agent.query_stream("wait here"):
            events.append(event)

        stop_events = [event for event in events if isinstance(event, StopEvent)]
        self.assertEqual([event.reason for event in stop_events], ["yielded"])

        tool_results = [event for event in events if isinstance(event, ToolResultEvent)]
        self.assertEqual(len(tool_results), 1)
        self.assertEqual(tool_results[0].tool, "YieldTurn")
        self.assertFalse(tool_results[0].is_error)

        tool_messages = [message for message in agent.messages if getattr(message, "role", None) == "tool"]
        self.assertEqual(len(tool_messages), 1)
        self.assertEqual(tool_messages[0].tool_name, "YieldTurn")

    async def test_yield_turn_preempts_mixed_tool_batch(self) -> None:
        called: list[str] = []

        @tool("Should never run after YieldTurn interception.", name="Read")
        async def ForbiddenRead(file_path: str) -> str:
            del file_path
            called.append("Read")
            return "unexpected"

        llm = _FakeChatModel(
            [
                ChatInvokeCompletion(
                    tool_calls=[
                        _tool_call(
                            tool_call_id="tc_read_1",
                            name="Read",
                            arguments={"file_path": "README.md"},
                        ),
                        _tool_call(
                            tool_call_id="tc_yield_2",
                            name="YieldTurn",
                            arguments={"status": "waiting_for_teammate"},
                        ),
                    ]
                )
            ]
        )
        template = Agent(
            llm=llm,  # type: ignore[arg-type]
            config=AgentConfig(
                tools=(ForbiddenRead, YieldTurn),
                agents=(),
                offload_enabled=False,
            ),
        )
        agent = template.create_runtime()

        events = []
        async for event in agent.query_stream("mixed batch"):
            events.append(event)

        self.assertEqual(called, [])
        tool_results = [event for event in events if isinstance(event, ToolResultEvent)]
        self.assertEqual(len(tool_results), 1)
        self.assertEqual(tool_results[0].tool, "YieldTurn")
        self.assertEqual(
            tool_results[0].metadata["interceptor"]["reason"],
            "yield_turn_preempted_batch",
        )
        self.assertEqual(
            tool_results[0].metadata["interceptor"]["dropped_calls"][0]["tool_name"],
            "Read",
        )

        assistant_messages = [message for message in agent.messages if getattr(message, "role", None) == "assistant"]
        self.assertEqual(len(assistant_messages), 1)
        self.assertEqual(len(assistant_messages[0].tool_calls or []), 1)
        self.assertEqual(assistant_messages[0].tool_calls[0].function.name, "YieldTurn")

    async def test_policy_denied_short_circuits_remaining_calls_but_keeps_turn_alive(self) -> None:
        called: list[str] = []

        @tool("Always deny for testing.", name="DeniedTool")
        async def DeniedTool() -> dict:
            return err("POLICY_DENIED", "Stop here and yield.")

        @tool("Should not execute after POLICY_DENIED.", name="SecondTool")
        async def SecondTool() -> str:
            called.append("SecondTool")
            return "unexpected"

        llm = _FakeChatModel(
            [
                ChatInvokeCompletion(
                    tool_calls=[
                        _tool_call(tool_call_id="tc_denied_1", name="DeniedTool", arguments={}),
                        _tool_call(tool_call_id="tc_second_1", name="SecondTool", arguments={}),
                    ]
                ),
                ChatInvokeCompletion(content="handled after denial"),
            ]
        )
        template = Agent(
            llm=llm,  # type: ignore[arg-type]
            config=AgentConfig(
                tools=(DeniedTool, SecondTool),
                agents=(),
                offload_enabled=False,
            ),
        )
        agent = template.create_runtime()

        events = []
        async for event in agent.query_stream("policy denial"):
            events.append(event)

        self.assertEqual(called, [])
        self.assertEqual(
            [event.content for event in events if isinstance(event, TextEvent)],
            ["handled after denial"],
        )
        self.assertEqual(
            [event.reason for event in events if isinstance(event, StopEvent)],
            ["completed"],
        )

        tool_messages = [message for message in agent.messages if getattr(message, "role", None) == "tool"]
        self.assertEqual(len(tool_messages), 1)
        self.assertEqual(tool_messages[0].tool_name, "DeniedTool")


if __name__ == "__main__":
    unittest.main(verbosity=2)
