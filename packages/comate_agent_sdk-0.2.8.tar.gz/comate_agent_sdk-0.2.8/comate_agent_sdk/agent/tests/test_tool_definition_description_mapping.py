import unittest

from comate_agent_sdk.tools.decorator import tool


class TestToolDefinitionDescriptionMapping(unittest.TestCase):
    def test_usage_rules_go_to_tool_definition_description(self) -> None:
        @tool(
            "Short overview for system prompt",
            name="DemoTool",
            usage_rules="Detailed usage policy for model tool definition.",
        )
        async def demo_tool(query: str) -> str:
            return query

        self.assertEqual(
            demo_tool.definition.description,
            "Detailed usage policy for model tool definition.",
        )

    def test_tool_definition_description_falls_back_to_description(self) -> None:
        @tool("Fallback short description", name="NoRulesTool")
        async def no_rules_tool(query: str) -> str:
            return query

        self.assertEqual(
            no_rules_tool.definition.description,
            "Fallback short description",
        )


if __name__ == "__main__":
    unittest.main()
