from __future__ import annotations

import uuid
from collections import deque
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from typing import Any, Literal

from comate_agent_sdk.prompts import load_prompt, render_prompt

_DEFAULT_SCHEDULE_LEASE_SECONDS = 30


def utc_now() -> datetime:
    return datetime.now(timezone.utc)


def utc_now_iso() -> str:
    return utc_now().isoformat()


def truncate_preview(text: str, *, max_chars: int = 160) -> str:
    normalized = str(text or "").strip()
    if len(normalized) <= max_chars:
        return normalized
    return f"{normalized[:max_chars].rstrip()}..."


def _team_inbox_message_payload(event: Any) -> dict[str, str]:
    return {
        "key": str(getattr(event, "key", "") or "").strip(),
        "from_agent": str(getattr(event, "from_agent", "") or "").strip(),
        "message_type": str(getattr(event, "message_type", "") or "").strip(),
        "content": str(getattr(event, "content", "") or "").strip(),
        "timestamp": str(getattr(event, "timestamp", "") or "").strip(),
    }


@dataclass(frozen=True, slots=True)
class ExternalTurn:
    turn_id: str
    source: str
    source_event_id: str
    dedupe_key: str
    received_at: str
    payload: dict[str, Any]
    can_auto_consume: bool = True
    retry_count: int = 0
    preview: str = ""


@dataclass(frozen=True, slots=True)
class ExternalTurnInput:
    turn: ExternalTurn


@dataclass(frozen=True, slots=True)
class ExternalTurnEnqueueResult:
    accepted: bool
    duplicate: bool
    should_ack: bool
    turn_id: str | None = None


@dataclass(frozen=True, slots=True)
class ScheduledExternalTurn:
    turn: ExternalTurn
    dispatch_token: str
    lease_expires_at: str
    dispatch_reason: str


@dataclass(frozen=True, slots=True)
class ReplayedExternalTurnState:
    queued_turns: list[ExternalTurn] = field(default_factory=list)
    dangling_scheduled_turns: list[ExternalTurn] = field(default_factory=list)
    terminal_turn_ids: set[str] = field(default_factory=set)


def build_team_inbox_external_turn(event: Any) -> ExternalTurn:
    message = _team_inbox_message_payload(event)
    payload = {
        "from_agent": message["from_agent"],
        "message_type": message["message_type"],
        "content": message["content"],
        "timestamp": message["timestamp"],
        "messages": [message],
    }
    dedupe_key = f"team_inbox:{event.key}"
    return ExternalTurn(
        turn_id=dedupe_key,
        source="team_inbox",
        source_event_id=event.key,
        dedupe_key=dedupe_key,
        received_at=utc_now_iso(),
        payload=payload,
        can_auto_consume=True,
        retry_count=0,
        preview=truncate_preview(event.content),
    )


def build_team_inbox_batch_external_turn(events: list[Any]) -> ExternalTurn:
    if not events:
        raise ValueError("team inbox batch requires at least one event")

    messages = [_team_inbox_message_payload(event) for event in events]
    first_key = messages[0]["key"]
    last_key = messages[-1]["key"]
    dedupe_key = f"team_inbox_batch:{first_key}:{last_key}:{len(messages)}"
    preview = truncate_preview(
        " | ".join(message["content"] for message in messages if message["content"])
    )
    return ExternalTurn(
        turn_id=dedupe_key,
        source="team_inbox",
        source_event_id=first_key,
        dedupe_key=dedupe_key,
        received_at=utc_now_iso(),
        payload={"messages": messages},
        can_auto_consume=True,
        retry_count=0,
        preview=preview,
    )


def _format_timestamp(timestamp_str: str) -> str:
    try:
        dt = datetime.fromisoformat(timestamp_str)
        return dt.strftime("%Y-%m-%d %H:%M:%S")
    except Exception:
        return timestamp_str


def build_team_inbox_turn_text(turn: ExternalTurn) -> str:
    payload = turn.payload
    raw_messages = payload.get("messages")
    message_lines: list[str] = []

    if isinstance(raw_messages, list) and raw_messages:
        for item in raw_messages:
            if not isinstance(item, dict):
                continue
            timestamp = _format_timestamp(str(item.get("timestamp", "") or "").strip())
            from_agent = str(item.get("from_agent", "") or "").strip() or "unknown"
            message_type = str(item.get("message_type", "") or "").strip() or "message"
            content = str(item.get("content", "") or "").strip()
            message_lines.append(f"- [{timestamp}] from={from_agent} type={message_type}")
            message_lines.append(f"  content={content}")
    else:
        timestamp = _format_timestamp(str(payload.get("timestamp", "") or "").strip())
        from_agent = str(payload.get("from_agent", "") or "").strip() or "unknown"
        message_type = str(payload.get("message_type", "") or "").strip() or "message"
        content = str(payload.get("content", "") or "").strip()
        message_lines.append(f"- [{timestamp}] from={from_agent} type={message_type}")
        message_lines.append(f"  content={content}")

    return render_prompt(
        load_prompt("agent/team_inbox_turn.md"),
        variables={"MESSAGES": "\n".join(message_lines)},
        source="agent/team_inbox_turn.md",
    )


def is_control_external_turn(turn: ExternalTurn) -> bool:
    if turn.source != "team_inbox":
        return False
    message_type = str(turn.payload.get("message_type", "") or "").strip()
    return message_type == "shutdown_request"


def make_dispatch_token() -> str:
    return uuid.uuid4().hex


def build_lease_expires_at(*, lease_seconds: int = _DEFAULT_SCHEDULE_LEASE_SECONDS) -> str:
    expires_at = utc_now() + timedelta(seconds=max(1, int(lease_seconds)))
    return expires_at.isoformat()


def external_turn_to_dict(turn: ExternalTurn) -> dict[str, Any]:
    return {
        "turn_id": turn.turn_id,
        "source": turn.source,
        "source_event_id": turn.source_event_id,
        "dedupe_key": turn.dedupe_key,
        "received_at": turn.received_at,
        "payload": dict(turn.payload),
        "can_auto_consume": bool(turn.can_auto_consume),
        "retry_count": int(turn.retry_count),
        "preview": turn.preview,
    }


def external_turn_from_dict(data: dict[str, Any]) -> ExternalTurn:
    return ExternalTurn(
        turn_id=str(data.get("turn_id", "") or "").strip(),
        source=str(data.get("source", "") or "").strip(),
        source_event_id=str(data.get("source_event_id", "") or "").strip(),
        dedupe_key=str(data.get("dedupe_key", "") or "").strip(),
        received_at=str(data.get("received_at", "") or "").strip(),
        payload=dict(data.get("payload", {}) or {}),
        can_auto_consume=bool(data.get("can_auto_consume", True)),
        retry_count=int(data.get("retry_count", 0) or 0),
        preview=str(data.get("preview", "") or "").strip(),
    )


def replay_external_turn_records(records: list[dict[str, Any]]) -> ReplayedExternalTurnState:
    turns_by_id: dict[str, ExternalTurn] = {}
    queued_ids: deque[str] = deque()
    queued_id_set: set[str] = set()
    scheduled_ids: set[str] = set()
    dangling_scheduled_ids: list[str] = []
    terminal_turn_ids: set[str] = set()

    def _drop_from_queue(turn_id: str) -> None:
        nonlocal queued_ids
        if turn_id not in queued_id_set:
            return
        queued_ids = deque(item_id for item_id in queued_ids if item_id != turn_id)
        queued_id_set.discard(turn_id)

    for record in records:
        op = str(record.get("op", "") or "").strip()
        if op in {"external_turn_enqueued", "external_turn_requeued"}:
            turn_payload = record.get("turn")
            if not isinstance(turn_payload, dict):
                continue
            turn = external_turn_from_dict(turn_payload)
            if not turn.turn_id or turn.turn_id in terminal_turn_ids:
                continue
            turns_by_id[turn.turn_id] = turn
            if turn.turn_id in scheduled_ids:
                scheduled_ids.discard(turn.turn_id)
            if turn.turn_id not in queued_id_set:
                queued_ids.append(turn.turn_id)
                queued_id_set.add(turn.turn_id)
            continue

        if op == "external_turn_scheduled":
            turn_id = str(record.get("turn_id", "") or "").strip()
            if not turn_id or turn_id in terminal_turn_ids:
                continue
            _drop_from_queue(turn_id)
            scheduled_ids.add(turn_id)
            if turn_id not in dangling_scheduled_ids:
                dangling_scheduled_ids.append(turn_id)
            continue

        if op in {"external_turn_completed", "external_turn_failed_terminal"}:
            turn_id = str(record.get("turn_id", "") or "").strip()
            if not turn_id:
                continue
            _drop_from_queue(turn_id)
            scheduled_ids.discard(turn_id)
            terminal_turn_ids.add(turn_id)

    queued_turns = [
        turns_by_id[turn_id]
        for turn_id in queued_ids
        if turn_id in turns_by_id and turn_id not in terminal_turn_ids
    ]
    dangling_scheduled_turns = [
        turns_by_id[turn_id]
        for turn_id in dangling_scheduled_ids
        if turn_id in turns_by_id
        and turn_id in scheduled_ids
        and turn_id not in terminal_turn_ids
    ]
    return ReplayedExternalTurnState(
        queued_turns=queued_turns,
        dangling_scheduled_turns=dangling_scheduled_turns,
        terminal_turn_ids=terminal_turn_ids,
    )
