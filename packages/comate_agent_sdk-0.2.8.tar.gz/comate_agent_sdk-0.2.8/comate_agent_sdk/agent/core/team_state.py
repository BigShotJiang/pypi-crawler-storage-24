from __future__ import annotations

import asyncio
import logging
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any, Literal

from comate_agent_sdk.system_tools.team.inbox_transport import TeamInboxEnvelope, TeamInboxTransport
from comate_agent_sdk.system_tools.team.polling import (
    DEFAULT_TEAM_POLL_INTERVAL_SECONDS,
)

if TYPE_CHECKING:
    from comate_agent_sdk.agent.core.runtime import AgentRuntime

logger = logging.getLogger(__name__)


@dataclass
class TeamCoordinationState:
    team_name: str = ""
    session_tasks: dict[str, asyncio.Task[None]] = field(default_factory=dict)
    inbox_poll_task: asyncio.Task[None] | None = None
    inbox_poll_lock: asyncio.Lock = field(default_factory=asyncio.Lock)
    pending_inbox_events: list[TeamInboxEnvelope] = field(default_factory=list)
    pending_inbox_keys: set[str] = field(default_factory=set)
    acked_inbox_keys: set[str] = field(default_factory=set)
    inbox_epoch: int = 0
    suppress_idle_notification: bool = False
    poll_interval_seconds: float = DEFAULT_TEAM_POLL_INTERVAL_SECONDS
    disable_legacy_inbox_poll: bool = False
    discard_team_turns_callback: Any | None = None
    external_turn_callback: Any | None = None
    turn_complete_callback: Any | None = None
    team_message_event_callback: Any | None = None

    @property
    def is_active(self) -> bool:
        return bool(self.team_name)

    # ── Session task 管理 ────────────────────────────────────────────────────

    @staticmethod
    def _session_identity(*, team_name: str, name: str) -> str:
        return f"{team_name.strip()}::{name.strip()}"

    def has_active_team_session(self, *, team_name: str, name: str) -> bool:
        identity = self._session_identity(team_name=team_name, name=name)
        task = self.session_tasks.get(identity)
        if task is None:
            return False
        if task.done():
            self.session_tasks.pop(identity, None)
            return False
        return True

    def register_team_session(
        self,
        *,
        team_name: str,
        name: str,
        task: asyncio.Task[None],
    ) -> None:
        identity = self._session_identity(team_name=team_name, name=name)
        existing = self.session_tasks.get(identity)
        if existing is not None and not existing.done():
            raise ValueError(
                f"Team session '{name}' is already running in team '{team_name}'."
            )
        self.session_tasks[identity] = task

        def _cleanup(completed_task: asyncio.Task[None]) -> None:
            current = self.session_tasks.get(identity)
            if current is completed_task:
                self.session_tasks.pop(identity, None)

        task.add_done_callback(_cleanup)

    def list_active_team_session_names(self, *, team_name: str) -> list[str]:
        normalized_team_name = str(team_name or "").strip()
        if not normalized_team_name:
            return []

        active_names: list[str] = []
        stale_identities: list[str] = []
        prefix = f"{normalized_team_name}::"
        for identity, task in self.session_tasks.items():
            if not identity.startswith(prefix):
                continue
            if task.done():
                stale_identities.append(identity)
                continue
            _, _, raw_name = identity.partition("::")
            if raw_name:
                active_names.append(raw_name)

        for identity in stale_identities:
            self.session_tasks.pop(identity, None)

        return sorted(active_names)

    # ── Inbox 状态管理 ────────────────────────────────────────────────────────

    def discard_backlog(self, *, discard_session_callback: Any | None = None) -> int:
        """Invalidate team inbox state and drop any queued team turns."""
        self.inbox_epoch += 1

        dropped_count = len(self.pending_inbox_events)
        self.pending_inbox_events.clear()
        self.pending_inbox_keys.clear()
        self.acked_inbox_keys.clear()

        discard_fn = discard_session_callback or self.discard_team_turns_callback
        if callable(discard_fn):
            try:
                dropped_count += int(discard_fn())
            except Exception as exc:
                logger.warning(
                    f"Failed to discard chat-session team turns during namespace teardown: {exc}",
                    exc_info=True,
                )

        return dropped_count

    def drain_pending_events(self) -> list[TeamInboxEnvelope]:
        events = list(self.pending_inbox_events)
        self.pending_inbox_events.clear()
        self.pending_inbox_keys.clear()
        return events

    async def cancel_all_sessions(self) -> None:
        """Cancel all running team session tasks and clear the registry."""
        tasks = list(self.session_tasks.values())
        self.session_tasks.clear()
        for task in tasks:
            task.cancel()
        if tasks:
            await asyncio.gather(*tasks, return_exceptions=True)


# ── 需要 AgentRuntime 的模块级函数 ─────────────────────────────────────────────
# 这些函数除了 TeamCoordinationState 字段外，还需要 runtime.name / _is_subagent 等。
# 模式与 core/runtime_mcp.py 一致：接收 AgentRuntime 作为第一个参数。


def resolve_team_inbox_delivery_mode(
    agent: "AgentRuntime",
) -> Literal["disabled", "external_turn", "legacy_buffer"]:
    if not agent.is_team_member:
        return "disabled"
    if callable(agent._team.external_turn_callback):
        return "external_turn"
    if agent._team.disable_legacy_inbox_poll:
        return "disabled"
    return "legacy_buffer"


async def poll_team_inbox_once(
    agent: "AgentRuntime",
) -> Literal["event", "idle", "skip"]:
    from comate_agent_sdk.agent.external_turns import (
        build_team_inbox_batch_external_turn,
        build_team_inbox_external_turn,
    )
    from comate_agent_sdk.system_tools.team.identity import resolve_runtime_team_agent_name

    delivery_mode = resolve_team_inbox_delivery_mode(agent)
    if delivery_mode == "disabled":
        return "skip"

    def _emit_team_message_events(events: list[TeamInboxEnvelope], *, receiver_name: str) -> None:
        team_msg_cb = agent._team.team_message_event_callback
        if not callable(team_msg_cb) or not events:
            return

        from comate_agent_sdk.agent.events import TeamMessageEvent

        for env in events:
            msg_type = str(env.message_type or "").strip()
            to_agent = None if msg_type == "broadcast" else receiver_name
            content_preview = str(env.content or "")[:80]
            try:
                team_msg_cb(
                    TeamMessageEvent(
                        agent_name=receiver_name,
                        from_agent=env.from_agent,
                        to_agent=to_agent,
                        message_type=msg_type,
                        content_preview=content_preview,
                        timestamp=env.timestamp,
                    )
                )
            except Exception as exc:
                logger.debug(f"team_message_event_callback raised: {exc}")

    async with agent._team.inbox_poll_lock:
        delivery_mode = resolve_team_inbox_delivery_mode(agent)
        if delivery_mode == "disabled":
            return "skip"
        poll_epoch = agent._team.inbox_epoch
        team_name = str(agent._team_name or "").strip()
        agent_name = resolve_runtime_team_agent_name(
            runtime_name=agent.name,
            is_subagent=bool(agent._is_subagent),
        )
        if not team_name or not agent_name:
            return "skip"

        transport = TeamInboxTransport(team_name=team_name, agent_name=agent_name)
        batch = transport.poll_new()
        if not batch.events:
            return "idle"

        fresh_events: list[TeamInboxEnvelope] = []
        for event in batch.events:
            if poll_epoch != agent._team.inbox_epoch:
                return "skip"
            if event.key in agent._team.pending_inbox_keys or event.key in agent._team.acked_inbox_keys:
                continue
            fresh_events.append(event)

        if delivery_mode == "legacy_buffer":
            for event in fresh_events:
                agent._team.pending_inbox_events.append(event)
                agent._team.pending_inbox_keys.add(event.key)
            _emit_team_message_events(fresh_events, receiver_name=agent_name)
            return "event"

        enqueue_external_turn = agent._team.external_turn_callback
        if not callable(enqueue_external_turn):
            return "skip"

        ack_keys: list[str] = []
        conversational_events: list[TeamInboxEnvelope] = []
        callback_events: list[TeamInboxEnvelope] = []
        for event in fresh_events:
            message_type = str(event.message_type or "").strip()
            if message_type == "shutdown_request":
                try:
                    result = await enqueue_external_turn(
                        build_team_inbox_external_turn(event)
                    )
                except Exception as exc:
                    logger.warning(
                        f"Failed to enqueue external turn from inbox: {exc}",
                        exc_info=True,
                    )
                    continue
                if bool(getattr(result, "accepted", False)):
                    callback_events.append(event)
                if bool(getattr(result, "should_ack", False)):
                    ack_keys.append(event.key)
                continue
            conversational_events.append(event)

        if conversational_events:
            conversational_event_keys = [
                event.key
                for event in conversational_events
                if str(event.key or "").strip()
            ]
            try:
                result = await enqueue_external_turn(
                    build_team_inbox_batch_external_turn(conversational_events)
                )
            except Exception as exc:
                logger.warning(
                    f"Failed to enqueue batched external turn from inbox: {exc}",
                    exc_info=True,
                )
            else:
                if bool(getattr(result, "accepted", False)):
                    agent._team.pending_inbox_keys.update(conversational_event_keys)
                    callback_events.extend(conversational_events)

        if ack_keys:
            transport.ack(ack_keys)
            agent._team.acked_inbox_keys.update(ack_keys)
        _emit_team_message_events(callback_events, receiver_name=agent_name)
        return "event"


async def run_inbox_poll_loop(agent: "AgentRuntime") -> None:
    current_task = asyncio.current_task()
    interval = max(float(agent._team.poll_interval_seconds), 0.0)
    try:
        while True:
            if resolve_team_inbox_delivery_mode(agent) != "external_turn":
                return

            # 调用 runtime 方法而非直接调用模块函数，保留外部 mock 能力。
            outcome = await agent._poll_team_inbox_once()
            if outcome == "skip":
                if resolve_team_inbox_delivery_mode(agent) != "external_turn":
                    return

            await asyncio.sleep(interval)
    except asyncio.CancelledError:
        raise
    except Exception as exc:
        logger.warning(f"Team inbox poll loop exited with error: {exc}", exc_info=True)
    finally:
        if current_task is not None and agent._team.inbox_poll_task is current_task:
            agent._team.inbox_poll_task = None


async def stop_inbox_poll_task_async(agent: "AgentRuntime") -> None:
    inbox_poll_task = agent._team.inbox_poll_task
    agent._team.inbox_poll_task = None
    if inbox_poll_task is None:
        return
    inbox_poll_task.cancel()
    await asyncio.gather(inbox_poll_task, return_exceptions=True)


def stop_inbox_poll_task(agent: "AgentRuntime") -> None:
    inbox_poll_task = agent._team.inbox_poll_task
    agent._team.inbox_poll_task = None
    if inbox_poll_task is None:
        return
    inbox_poll_task.cancel()


def start_inbox_poll_task(agent: "AgentRuntime") -> None:
    if agent._team.inbox_poll_task is not None and not agent._team.inbox_poll_task.done():
        return
    try:
        loop = asyncio.get_running_loop()
    except RuntimeError:
        logger.debug("Skip starting inbox poll task because no running event loop is available")
        return
    agent._team.inbox_poll_task = loop.create_task(run_inbox_poll_loop(agent))


def sync_inbox_poll_task(agent: "AgentRuntime") -> None:
    if resolve_team_inbox_delivery_mode(agent) == "external_turn":
        start_inbox_poll_task(agent)
        return
    stop_inbox_poll_task(agent)


def ack_pending_inbox_events(agent: "AgentRuntime", keys: list[str]) -> None:
    from comate_agent_sdk.system_tools.team.identity import resolve_runtime_team_agent_name

    normalized_keys = [str(key).strip() for key in keys if str(key).strip()]
    if not normalized_keys:
        return

    for key in normalized_keys:
        agent._team.pending_inbox_keys.discard(key)

    team_name = str(agent._team_name or "").strip()
    agent_name = resolve_runtime_team_agent_name(
        runtime_name=agent.name,
        is_subagent=bool(agent._is_subagent),
    )
    if not team_name or not agent_name:
        return

    transport = TeamInboxTransport(team_name=team_name, agent_name=agent_name)
    transport.ack(normalized_keys)
    agent._team.acked_inbox_keys.update(normalized_keys)
