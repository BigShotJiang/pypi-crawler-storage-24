from __future__ import annotations

import logging
from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING

from comate_agent_sdk.agent.events import (
    AgentEvent,
    PlanApprovalRequiredEvent,
    StopEvent,
    UserQuestionEvent,
)
from comate_agent_sdk.llm.messages import ToolCall, ToolMessage

from ..projection.tool_result_projection import extract_plan_approval, extract_questions

if TYPE_CHECKING:
    from comate_agent_sdk.agent.core import AgentRuntime

    from .state import TurnEngineState
    from .stream_drain import EventDrainHub
    from .tool_execution import ToolExecutionCallbacks
    from .txn_commit import ToolTxnCommitter

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class PostHandlerResult:
    events: list[AgentEvent]
    should_stop: bool
    stop_reason: str | None = None


async def run_post_handlers(
    agent: "AgentRuntime",
    tool_name: str,
    tool_call: ToolCall,
    tool_result: ToolMessage,
    *,
    committer: "ToolTxnCommitter",
    results_by_id: dict[str, ToolMessage],
    callbacks: "ToolExecutionCallbacks",
    drain_hub: "EventDrainHub",
    engine_state: "TurnEngineState",
) -> PostHandlerResult | None:
    del engine_state

    handlers = (
        _handle_ask_user_question,
        _handle_exit_plan_mode,
        _handle_yield_turn,
    )
    for handler in handlers:
        result = await handler(
            agent,
            tool_name,
            tool_call,
            tool_result,
            committer=committer,
            results_by_id=results_by_id,
            callbacks=callbacks,
            drain_hub=drain_hub,
        )
        if result is not None:
            return result
    return None


async def _handle_ask_user_question(
    agent: "AgentRuntime",
    tool_name: str,
    tool_call: ToolCall,
    tool_result: ToolMessage,
    *,
    committer: "ToolTxnCommitter",
    results_by_id: dict[str, ToolMessage],
    callbacks: "ToolExecutionCallbacks",
    drain_hub: "EventDrainHub",
) -> PostHandlerResult | None:
    del agent
    if tool_name != "AskUserQuestion" or tool_result.is_error:
        return None

    questions = extract_questions(tool_result)
    if not questions:
        return None

    events: list[AgentEvent] = [
        UserQuestionEvent(
            questions=questions,
            tool_call_id=tool_call.id,
        )
    ]
    if await committer.commit_if_needed(results_by_id):
        async for hidden_event in drain_hub.drain_hidden_events():
            events.append(hidden_event)
    async for usage_event in drain_hub.drain_usage_events():
        events.append(usage_event)
    if await callbacks.run_stop_hook("waiting_for_input"):
        async for hidden_event in drain_hub.drain_hidden_events():
            events.append(hidden_event)
        return PostHandlerResult(events=events, should_stop=False)

    async for hidden_event in drain_hub.drain_hidden_events():
        events.append(hidden_event)
    events.append(StopEvent(reason="waiting_for_input"))
    return PostHandlerResult(
        events=events,
        should_stop=True,
        stop_reason="waiting_for_input",
    )


async def _handle_exit_plan_mode(
    agent: "AgentRuntime",
    tool_name: str,
    tool_call: ToolCall,
    tool_result: ToolMessage,
    *,
    committer: "ToolTxnCommitter",
    results_by_id: dict[str, ToolMessage],
    callbacks: "ToolExecutionCallbacks",
    drain_hub: "EventDrainHub",
) -> PostHandlerResult | None:
    del tool_call
    if tool_name != "ExitPlanMode" or tool_result.is_error:
        return None

    plan_approval = extract_plan_approval(tool_result)
    if plan_approval is None:
        return None

    plan_path = plan_approval["plan_path"]
    plan_markdown = ""
    try:
        plan_markdown = Path(plan_path).read_text(encoding="utf-8")
    except Exception as exc:
        logger.warning("ExitPlanMode: 无法读取计划文件 %s: %s", plan_path, exc)
    agent.arm_plan_approval(
        plan_path=plan_path,
        summary=plan_approval["summary"],
        execution_prompt=plan_approval["execution_prompt"],
    )

    budget_status = agent._context.get_budget_status()
    utilization_pct = int(budget_status.utilization_ratio * 100)
    events: list[AgentEvent] = [
        PlanApprovalRequiredEvent(
            plan_path=plan_path,
            summary=plan_approval["summary"],
            execution_prompt=plan_approval["execution_prompt"],
            plan_markdown=plan_markdown,
            context_utilization_pct=utilization_pct,
        )
    ]
    if await committer.commit_if_needed(results_by_id):
        async for hidden_event in drain_hub.drain_hidden_events():
            events.append(hidden_event)
    async for usage_event in drain_hub.drain_usage_events():
        events.append(usage_event)
    if await callbacks.run_stop_hook("waiting_for_plan_approval"):
        async for hidden_event in drain_hub.drain_hidden_events():
            events.append(hidden_event)
        return PostHandlerResult(events=events, should_stop=False)

    async for hidden_event in drain_hub.drain_hidden_events():
        events.append(hidden_event)
    events.append(StopEvent(reason="waiting_for_plan_approval"))
    return PostHandlerResult(
        events=events,
        should_stop=True,
        stop_reason="waiting_for_plan_approval",
    )


async def _handle_yield_turn(
    agent: "AgentRuntime",
    tool_name: str,
    tool_call: ToolCall,
    tool_result: ToolMessage,
    *,
    committer: "ToolTxnCommitter",
    results_by_id: dict[str, ToolMessage],
    callbacks: "ToolExecutionCallbacks",
    drain_hub: "EventDrainHub",
) -> PostHandlerResult | None:
    del agent, tool_call
    if tool_name != "YieldTurn" or tool_result.is_error:
        return None

    events: list[AgentEvent] = []
    if await committer.commit_if_needed(results_by_id):
        async for hidden_event in drain_hub.drain_hidden_events():
            events.append(hidden_event)
    async for usage_event in drain_hub.drain_usage_events():
        events.append(usage_event)
    await callbacks.before_terminal_stop("yielded")
    async for hidden_event in drain_hub.drain_hidden_events():
        events.append(hidden_event)
    events.append(StopEvent(reason="yielded"))
    return PostHandlerResult(
        events=events,
        should_stop=True,
        stop_reason="yielded",
    )
