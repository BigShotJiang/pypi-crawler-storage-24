from __future__ import annotations

from dataclasses import dataclass, field

from comate_agent_sdk.llm.messages import AssistantMessage, ToolCall

YIELD_TURN_TOOL_NAME = "YieldTurn"


def is_yield_turn(call: ToolCall) -> bool:
    return str(call.function.name or "").strip() == YIELD_TURN_TOOL_NAME


@dataclass(slots=True)
class ToolCallInterceptResult:
    assistant_message: AssistantMessage
    tool_calls: list[ToolCall]
    dropped_calls: list[ToolCall] = field(default_factory=list)


class ToolCallInterceptor:
    """Sanitize tool-call batches before any tool execution starts."""

    def intercept(
        self,
        *,
        assistant_message: AssistantMessage,
        tool_calls: list[ToolCall],
    ) -> ToolCallInterceptResult:
        yield_index = next((idx for idx, call in enumerate(tool_calls) if is_yield_turn(call)), None)
        if yield_index is None:
            return ToolCallInterceptResult(
                assistant_message=assistant_message,
                tool_calls=list(tool_calls),
            )

        kept_call = tool_calls[yield_index]
        kept_calls = [kept_call]
        dropped_calls = [call for idx, call in enumerate(tool_calls) if idx != yield_index]
        sanitized_message = assistant_message.model_copy(update={"tool_calls": kept_calls})
        return ToolCallInterceptResult(
            assistant_message=sanitized_message,
            tool_calls=kept_calls,
            dropped_calls=dropped_calls,
        )
