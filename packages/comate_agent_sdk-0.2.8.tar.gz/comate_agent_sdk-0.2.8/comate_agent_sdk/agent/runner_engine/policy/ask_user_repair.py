from __future__ import annotations

import json
from collections.abc import AsyncIterator
from typing import TYPE_CHECKING

from comate_agent_sdk.agent.events import (
    AgentEvent,
    StepCompleteEvent,
    StepStartEvent,
    ToolCallEvent,
    ToolResultEvent,
)
from comate_agent_sdk.llm.messages import ToolCall, ToolMessage

from .tool_policy import is_ask_user_question, policy_violation_message

if TYPE_CHECKING:
    from comate_agent_sdk.agent.core import AgentRuntime
    from ..execution.stream_drain import EventDrainHub
    from ..execution.task_lifecycle import TaskLifecycleEmitter


async def _emit_policy_repair_events(
    agent: "AgentRuntime",
    *,
    tool_calls: list[ToolCall],
    task_lifecycle: "TaskLifecycleEmitter",
    drain_hub: "EventDrainHub",
) -> AsyncIterator[AgentEvent]:
    results_by_id: dict[str, ToolMessage] = {}
    for call in tool_calls:
        if is_ask_user_question(call):
            results_by_id[call.id] = policy_violation_message(
                call=call,
                code="ASKUSER_EXCLUSIVE",
                message="AskUserQuestion must be called alone in a single assistant tool_calls response.",
                required_fix="Retry now with ONLY AskUserQuestion. Run other tools after the user answer in the next turn.",
            )
        else:
            results_by_id[call.id] = policy_violation_message(
                call=call,
                code="ASKUSER_BLOCKED_BY_ASK",
                message="Blocked because AskUserQuestion was present in the same tool_calls response.",
                required_fix="Retry without mixing tools with AskUserQuestion.",
            )

    step_number = 0
    for call in tool_calls:
        step_number += 1
        tool_name = str(call.function.name or "").strip()
        try:
            args = json.loads(call.function.arguments)
        except json.JSONDecodeError:
            args = {"_raw": call.function.arguments}

        from ..query_stream import _normalize_tool_call_event_args, _resolve_task_metadata

        args_dict = _normalize_tool_call_event_args(
            agent,
            tool_name=tool_name,
            raw_args=args,
        )

        is_task = tool_name == "Agent"
        task_subagent_name = "Agent"
        task_description = tool_name
        if is_task:
            task_subagent_name, task_description, _ = _resolve_task_metadata(
                tool_call_id=call.id,
                args=args_dict,
            )

        yield StepStartEvent(
            step_id=call.id,
            title=task_description if is_task else tool_name,
            step_number=step_number,
        )
        yield ToolCallEvent(
            tool=tool_name,
            args=args_dict,
            tool_call_id=call.id,
            display_name=task_description if is_task else tool_name,
        )

        tool_result = results_by_id[call.id]
        if is_task:
            async for event in task_lifecycle.emit_start(
                tool_call_id=call.id,
                subagent_name=task_subagent_name,
                description=task_description,
            ):
                yield event
            async for event in task_lifecycle.emit_stop(
                tool_call_id=call.id,
                subagent_name=task_subagent_name,
                description=task_description,
                duration_ms=0.0,
                tokens=0,
                tool_result=tool_result,
            ):
                yield event

        yield ToolResultEvent(
            tool=tool_name,
            result=tool_result.text,
            tool_call_id=call.id,
            is_error=True,
            screenshot_base64=None,
        )
        yield StepCompleteEvent(
            step_id=call.id,
            status="error",
            duration_ms=0.0,
        )
        async for hidden_event in drain_hub.drain_hidden_events():
            yield hidden_event
