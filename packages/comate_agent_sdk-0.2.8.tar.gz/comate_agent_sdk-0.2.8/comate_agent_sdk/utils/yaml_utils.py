"""YAML frontmatter 解析工具，带容错 fallback"""

import logging

import yaml

logger = logging.getLogger(__name__)


def safe_load_frontmatter(text: str, *, source: str = "") -> dict:
    """解析 YAML frontmatter 文本，当 yaml.safe_load 失败时回退到逐行解析。

    Fallback 只支持扁平 key-value（不支持嵌套 map/列表），
    适用于 description 等字段包含未加引号冒号的常见场景。

    Args:
        text: YAML frontmatter 文本（不含 --- 围栏）
        source: 来源标识，用于日志

    Returns:
        解析后的 dict
    """
    try:
        result = yaml.safe_load(text)
        if result is None:
            return {}
        if not isinstance(result, dict):
            raise ValueError(f"frontmatter must be a YAML mapping, got {type(result).__name__}")
        return result
    except yaml.YAMLError:
        location = f" ({source})" if source else ""
        logger.debug(
            f"yaml.safe_load failed{location}, falling back to line-by-line parser"
        )
        return _fallback_parse(text, source=source)


def _fallback_parse(text: str, *, source: str = "") -> dict:
    """逐行解析扁平 YAML key-value，按第一个 ': ' 分割。"""
    result: dict = {}
    for line in text.strip().splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue

        sep_idx = line.find(": ")
        if sep_idx == -1:
            # 尝试 key: (末尾冒号，空值)
            if line.endswith(":"):
                result[line[:-1].strip()] = ""
            continue

        key = line[:sep_idx].strip()
        value = line[sep_idx + 2 :].strip()

        # 类型推断：bool / int / float / str
        result[key] = _coerce_scalar(value)

    location = f" ({source})" if source else ""
    if not result:
        raise ValueError(f"fallback parser produced empty result{location}")

    logger.info(f"Fallback YAML parser succeeded{location}, parsed keys: {list(result.keys())}")
    return result


def _coerce_scalar(value: str) -> object:
    """将字符串值转换为合适的 Python 类型。"""
    lower = value.lower()
    if lower in ("true", "yes", "on"):
        return True
    if lower in ("false", "no", "off"):
        return False
    if lower in ("null", "~", ""):
        return None
    try:
        return int(value)
    except ValueError:
        pass
    try:
        return float(value)
    except ValueError:
        pass
    return value
