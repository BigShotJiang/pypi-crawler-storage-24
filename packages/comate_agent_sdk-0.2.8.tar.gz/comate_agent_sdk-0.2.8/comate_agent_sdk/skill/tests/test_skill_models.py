from __future__ import annotations

import unittest
from pathlib import Path

from comate_agent_sdk.skill.models import SkillDefinition


class TestSkillDefinition(unittest.TestCase):
    def test_from_markdown_supports_quoted_description(self) -> None:
        skill = SkillDefinition.from_markdown(
            content=(
                "---\n"
                "name: xlsx\n"
                'description: "Specialized spreadsheet workflow."\n'
                "---\n"
                "\n"
                "Use openpyxl."
            ),
            dir_name="xlsx",
            base_dir=Path("/tmp/xlsx"),
        )

        self.assertEqual(skill.name, "xlsx")
        self.assertEqual(skill.description, "Specialized spreadsheet workflow.")
        self.assertEqual(skill.prompt, "Use openpyxl.")

    def test_from_markdown_supports_legacy_double_dash_closing_fence(self) -> None:
        skill = SkillDefinition.from_markdown(
            content=(
                "---\n"
                "name: xlsx\n"
                'description: "Specialized spreadsheet workflow."\n'
                "--\n"
                "\n"
                "Use openpyxl."
            ),
            dir_name="xlsx",
            base_dir=Path("/tmp/xlsx"),
        )

        self.assertEqual(skill.name, "xlsx")
        self.assertEqual(skill.description, "Specialized spreadsheet workflow.")
        self.assertEqual(skill.prompt, "Use openpyxl.")
        self.assertNotIn("name: xlsx", skill.description)

    def test_from_markdown_supports_legacy_frontmatter_without_opening_fence(self) -> None:
        skill = SkillDefinition.from_markdown(
            content=(
                "name: xlsx\n"
                'description: "Specialized spreadsheet workflow."\n'
                "--\n"
                "\n"
                "Use openpyxl."
            ),
            dir_name="xlsx",
            base_dir=Path("/tmp/xlsx"),
        )

        self.assertEqual(skill.name, "xlsx")
        self.assertEqual(skill.description, "Specialized spreadsheet workflow.")
        self.assertEqual(skill.prompt, "Use openpyxl.")


if __name__ == "__main__":
    unittest.main(verbosity=2)
