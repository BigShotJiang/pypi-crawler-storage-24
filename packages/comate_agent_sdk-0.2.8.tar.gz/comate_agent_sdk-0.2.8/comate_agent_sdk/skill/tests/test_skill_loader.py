from __future__ import annotations

import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from comate_agent_sdk.skill.loader import discover_skills


class TestSkillLoader(unittest.TestCase):
    def test_discover_skills_accepts_str_project_root(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td) / "project"
            skill_dir = root / ".agent" / "skills" / "demo"
            skill_dir.mkdir(parents=True)
            (skill_dir / "SKILL.md").write_text(
                "---\nname: demo\ndescription: demo skill\n---\nUse demo.",
                encoding="utf-8",
            )

            with patch("comate_agent_sdk.skill.loader.Path.home", return_value=Path(td) / "home"):
                skills = discover_skills(project_root=str(root))

        self.assertEqual([skill.name for skill in skills], ["demo"])


if __name__ == "__main__":
    unittest.main(verbosity=2)
