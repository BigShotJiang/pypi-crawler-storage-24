"""Public facade exports for building agentic applications."""

from comate_agent_sdk.facade import (
    Agent,
    AgentConfigError,
    AgentConnectionError,
    AgentError,
    AgentExecutionError,
    AgentTimeoutError,
    Event,
    StopEvent,
    TextEvent,
    ToolUseEvent,
    UserQuestionEvent,
    YieldEvent,
    run_agent,
    run_agent_async,
)

__all__ = [
    # 核心 API
    "Agent",
    "run_agent",
    "run_agent_async",
    # 事件
    "Event",
    "TextEvent",
    "ToolUseEvent",
    "YieldEvent",
    "StopEvent",
    "UserQuestionEvent",
    # 错误 (兼容性)
    "AgentError",
    "AgentConfigError",
    "AgentConnectionError",
    "AgentExecutionError",
    "AgentTimeoutError",
]
