from __future__ import annotations

import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from comate_agent_sdk.subagent.loader import discover_subagents


class TestSubagentLoader(unittest.TestCase):
    def test_discover_subagents_accepts_str_project_root(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td) / "project"
            subagent_dir = root / ".agent" / "subagents"
            subagent_dir.mkdir(parents=True)
            (subagent_dir / "reviewer.md").write_text(
                "---\nname: reviewer\ndescription: review things\n---\nReview code.",
                encoding="utf-8",
            )

            with patch("comate_agent_sdk.subagent.loader.Path.home", return_value=Path(td) / "home"):
                agents = discover_subagents(project_root=str(root))

        self.assertEqual([agent.name for agent in agents], ["reviewer"])


if __name__ == "__main__":
    unittest.main(verbosity=2)
