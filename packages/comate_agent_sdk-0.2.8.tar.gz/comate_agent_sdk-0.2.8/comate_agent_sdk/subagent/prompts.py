"""
Subagent 系统提示模板
"""

from comate_agent_sdk.prompts import load_prompt, render_prompt
from comate_agent_sdk.subagent.models import AgentDefinition

_SUBAGENT_STRATEGY_TEMPLATE = load_prompt("subagent/strategy.md")


def generate_subagent_prompt(agents: list[AgentDefinition]) -> str:
    """生成 Subagent 策略提示。

    Args:
        agents: AgentDefinition 列表

    Returns:
        格式化后的 Subagent 策略提示文本
    """
    subagent_list = "\n".join([f"- **{agent.name}**: {agent.description}" for agent in agents])
    return render_prompt(
        _SUBAGENT_STRATEGY_TEMPLATE,
        variables={"Subagents": subagent_list},
        source="subagent/strategy.md",
    )
