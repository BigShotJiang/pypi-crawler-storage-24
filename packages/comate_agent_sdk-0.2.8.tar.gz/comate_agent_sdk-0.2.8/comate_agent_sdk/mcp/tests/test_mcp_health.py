from __future__ import annotations

import asyncio

from comate_agent_sdk.mcp import create_sdk_mcp_server, mcp_tool
from comate_agent_sdk.mcp.health import collect_mcp_server_health


def _build_calc_server():
    @mcp_tool(name="add", description="Add two numbers")
    async def add(a: float, b: float) -> str:
        return f"sum={a + b}"

    return create_sdk_mcp_server(name="calculator", tools=[add])


def test_collect_mcp_server_health_marks_connected_server() -> None:
    async def _run() -> None:
        servers = {"calc": _build_calc_server()}
        rows = await collect_mcp_server_health(servers=servers)
        assert len(rows) == 1
        assert rows[0].alias == "calc"
        assert rows[0].connected is True
        assert rows[0].reason is None
        assert rows[0].tool_count >= 1

    asyncio.run(_run())


def test_collect_mcp_server_health_marks_failed_server() -> None:
    async def _run() -> None:
        servers = {"bad-http": {"type": "http", "url": ""}}
        rows = await collect_mcp_server_health(servers=servers)  # type: ignore[arg-type]
        assert len(rows) == 1
        assert rows[0].alias == "bad-http"
        assert rows[0].connected is False
        assert rows[0].reason

    asyncio.run(_run())
