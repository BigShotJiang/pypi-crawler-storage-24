from __future__ import annotations

import logging
from collections.abc import Mapping

from comate_agent_sdk.mcp.store import (
    load_effective_servers,
    load_mcp_servers_from_path,
)
from comate_agent_sdk.mcp.types import McpServerConfig, McpServersInput
from comate_agent_sdk.utils.paths import PathInput, is_path_input

logger = logging.getLogger("comate_agent_sdk.mcp.config")


def resolve_mcp_servers(
    mcp_servers: McpServersInput,
    *,
    project_root: PathInput | None,
) -> dict[str, McpServerConfig]:
    """解析 Agent.mcp_servers 输入为标准 dict[alias, config]。"""
    if mcp_servers is None:
        return load_effective_servers(project_root=project_root)

    if is_path_input(mcp_servers):
        return load_mcp_servers_from_path(mcp_servers)

    if isinstance(mcp_servers, Mapping):
        # 显式 {} 表示禁用/不配置任何 server
        return {str(alias): cfg for alias, cfg in mcp_servers.items()}  # type: ignore[dict-item]

    logger.warning(f"不支持的 mcp_servers 类型：{type(mcp_servers).__name__}")
    return {}
