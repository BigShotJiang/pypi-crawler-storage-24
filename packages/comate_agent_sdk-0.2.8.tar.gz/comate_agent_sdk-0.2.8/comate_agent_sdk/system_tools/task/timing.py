from __future__ import annotations

import logging
import os

logger = logging.getLogger(__name__)

DEFAULT_TASKLIST_TEAM_BLOCK_SECONDS = 5.0
TASKLIST_TEAM_BLOCK_ENV_VAR = "COMATE_TASKLIST_TEAM_BLOCK_SECONDS"


def resolve_tasklist_team_block_seconds() -> float:
    raw_value = os.getenv(TASKLIST_TEAM_BLOCK_ENV_VAR, "").strip()
    if not raw_value:
        return DEFAULT_TASKLIST_TEAM_BLOCK_SECONDS
    try:
        parsed = float(raw_value)
    except ValueError:
        logger.warning(
            f"Invalid {TASKLIST_TEAM_BLOCK_ENV_VAR}={raw_value!r}, "
            f"fallback to {DEFAULT_TASKLIST_TEAM_BLOCK_SECONDS}s"
        )
        return DEFAULT_TASKLIST_TEAM_BLOCK_SECONDS
    if parsed <= 0:
        logger.warning(
            f"Non-positive {TASKLIST_TEAM_BLOCK_ENV_VAR}={raw_value!r}, "
            f"fallback to {DEFAULT_TASKLIST_TEAM_BLOCK_SECONDS}s"
        )
        return DEFAULT_TASKLIST_TEAM_BLOCK_SECONDS
    return parsed
