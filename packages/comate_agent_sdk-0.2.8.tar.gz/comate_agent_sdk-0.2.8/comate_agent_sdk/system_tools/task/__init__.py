from __future__ import annotations

from comate_agent_sdk.system_tools.task.models import TaskItem, TaskListModel, TaskStatus
from comate_agent_sdk.system_tools.task.store import TaskStore
from comate_agent_sdk.system_tools.task.tools import TaskCreate, TaskGet, TaskList, TaskUpdate
from comate_agent_sdk.tools.decorator import Tool
from comate_agent_sdk.tools.registry import ToolRegistry

TASK_TOOLS: list[Tool] = [TaskCreate, TaskList, TaskGet, TaskUpdate]


def register_task_tools(registry: ToolRegistry) -> None:
    for tool in TASK_TOOLS:
        registry.register(tool)


__all__ = [
    "TaskCreate",
    "TaskGet",
    "TaskItem",
    "TaskList",
    "TaskListModel",
    "TaskStatus",
    "TaskStore",
    "TaskUpdate",
    "TASK_TOOLS",
    "register_task_tools",
]
