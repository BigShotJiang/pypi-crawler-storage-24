from __future__ import annotations

from datetime import datetime, timezone
from enum import Enum
from typing import Any

from pydantic import BaseModel, Field


def utc_now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


class TaskStatus(str, Enum):
    PENDING = "pending"
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"


class TaskItem(BaseModel):
    id: str
    subject: str = Field(min_length=1)
    description: str = ""
    status: TaskStatus = TaskStatus.PENDING
    owner: str = ""
    blocked_by: list[str] = Field(default_factory=list)
    blocks: list[str] = Field(default_factory=list)
    metadata: dict[str, Any] = Field(default_factory=dict)
    created_at: str = Field(default_factory=utc_now_iso)
    updated_at: str = Field(default_factory=utc_now_iso)

    model_config = {"extra": "forbid"}


class TaskListModel(BaseModel):
    id: str
    tasks: dict[str, TaskItem] = Field(default_factory=dict)
    next_id: int = 1
    schema_version: str = "2"
    created_at: str = Field(default_factory=utc_now_iso)
    updated_at: str = Field(default_factory=utc_now_iso)

    model_config = {"extra": "forbid"}
