from __future__ import annotations

from comate_agent_sdk.system_tools.task.models import TaskItem, TaskListModel, TaskStatus


def test_task_item_defaults() -> None:
    item = TaskItem(id="1", subject="Implement task system")
    assert item.status == TaskStatus.PENDING
    assert item.description == ""
    assert item.owner == ""
    assert item.blocked_by == []
    assert item.metadata == {}


def test_task_list_model_defaults() -> None:
    model = TaskListModel(id="default")
    assert model.tasks == {}
    assert model.next_id == 1
    assert model.schema_version == "2"
