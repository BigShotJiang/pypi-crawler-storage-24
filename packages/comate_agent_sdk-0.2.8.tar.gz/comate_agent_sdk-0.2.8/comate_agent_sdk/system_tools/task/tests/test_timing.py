from __future__ import annotations

import unittest
from unittest.mock import patch

from comate_agent_sdk.system_tools.task.timing import (
    DEFAULT_TASKLIST_TEAM_BLOCK_SECONDS,
    resolve_tasklist_team_block_seconds,
)


class TestTaskTiming(unittest.TestCase):
    def test_tasklist_team_block_uses_default(self) -> None:
        with patch.dict("os.environ", {}, clear=True):
            self.assertEqual(
                resolve_tasklist_team_block_seconds(),
                DEFAULT_TASKLIST_TEAM_BLOCK_SECONDS,
            )

    def test_tasklist_team_block_accepts_env_override(self) -> None:
        with patch.dict("os.environ", {"COMATE_TASKLIST_TEAM_BLOCK_SECONDS": "2.5"}, clear=True):
            self.assertEqual(resolve_tasklist_team_block_seconds(), 2.5)

    def test_tasklist_team_block_invalid_env_falls_back(self) -> None:
        with patch.dict("os.environ", {"COMATE_TASKLIST_TEAM_BLOCK_SECONDS": "oops"}, clear=True):
            self.assertEqual(
                resolve_tasklist_team_block_seconds(),
                DEFAULT_TASKLIST_TEAM_BLOCK_SECONDS,
            )

    def test_tasklist_team_block_non_positive_env_falls_back(self) -> None:
        with patch.dict("os.environ", {"COMATE_TASKLIST_TEAM_BLOCK_SECONDS": "0"}, clear=True):
            self.assertEqual(
                resolve_tasklist_team_block_seconds(),
                DEFAULT_TASKLIST_TEAM_BLOCK_SECONDS,
            )


if __name__ == "__main__":
    unittest.main(verbosity=2)
