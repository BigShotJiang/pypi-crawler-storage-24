from __future__ import annotations

import logging
import os

logger = logging.getLogger(__name__)

DEFAULT_TEAM_POLL_INTERVAL_SECONDS = 0.5
_TEAM_POLL_ENV_VAR = "COMATE_TEAM_POLL_INTERVAL_SECONDS"


def resolve_team_poll_interval_seconds(*, legacy_env_var: str | None = None) -> float:
    env_var_names = [_TEAM_POLL_ENV_VAR]
    if legacy_env_var:
        env_var_names.append(legacy_env_var)

    for env_var_name in env_var_names:
        raw_value = os.getenv(env_var_name, "").strip()
        if not raw_value:
            continue
        try:
            parsed = float(raw_value)
        except ValueError:
            logger.warning(
                f"Invalid {env_var_name}={raw_value!r}, "
                f"fallback to {DEFAULT_TEAM_POLL_INTERVAL_SECONDS}s"
            )
            return DEFAULT_TEAM_POLL_INTERVAL_SECONDS
        if parsed <= 0:
            logger.warning(
                f"Non-positive {env_var_name}={raw_value!r}, "
                f"fallback to {DEFAULT_TEAM_POLL_INTERVAL_SECONDS}s"
            )
            return DEFAULT_TEAM_POLL_INTERVAL_SECONDS
        return parsed

    return DEFAULT_TEAM_POLL_INTERVAL_SECONDS
