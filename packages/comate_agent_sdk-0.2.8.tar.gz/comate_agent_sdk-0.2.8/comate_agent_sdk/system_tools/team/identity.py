from __future__ import annotations

DEFAULT_TEAM_LEAD_NAME = "team-lead"


def normalize_agent_name(name: str) -> str:
    """将 agent 名字标准化为小写。

    - 去除前后空格
    - 转换为小写

    Args:
        name: 原始 agent 名字

    Returns:
        标准化后的名字（小写）

    Raises:
        ValueError: 若标准化后为空字符串
    """
    normalized = name.strip().lower()
    if not normalized:
        raise ValueError("agent_name 不能为空")
    return normalized


def resolve_runtime_team_agent_name(
    *,
    runtime_name: str | None,
    is_subagent: bool,
) -> str:
    """Resolve the effective Team-mode agent name for a runtime.

    Main agent may be unnamed in normal CLI usage. In Team mode we keep a
    stable synthetic identity "team-lead" so TeamCreate, inbox polling, and
    messaging all agree on the same mailbox/config entry.
    """
    normalized = str(runtime_name or "").strip()
    if normalized:
        return normalized
    if is_subagent:
        return ""
    return DEFAULT_TEAM_LEAD_NAME


def resolve_context_team_agent_name(
    *,
    agent_name: str | None,
    subagent_name: str | None,
) -> str:
    """Resolve the effective Team-mode agent name from SystemToolContext."""
    normalized_agent_name = str(agent_name or "").strip()
    if normalized_agent_name:
        return normalized_agent_name

    normalized_subagent_name = str(subagent_name or "").strip()
    if normalized_subagent_name:
        return normalized_subagent_name

    return DEFAULT_TEAM_LEAD_NAME
