"""测试 ExitPlanMode 工具。"""

from __future__ import annotations

import asyncio
import json
import tempfile
import unittest
from pathlib import Path

from comate_agent_sdk.system_tools.tools import ExitPlanMode
from comate_agent_sdk.tools.system_context import bind_system_tool_context, get_system_tool_context


class TestExitPlanMode(unittest.TestCase):
    def test_bind_system_tool_context_accepts_str_paths(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td).resolve()
            session_root = root / "sessions" / "s1"
            plans_root = root / "plans"
            session_root.mkdir(parents=True, exist_ok=True)
            plans_root.mkdir(parents=True, exist_ok=True)
            active_plan_path = plans_root / "plan.md"
            active_plan_path.write_text("# Plan\n", encoding="utf-8")

            with bind_system_tool_context(
                project_root=str(root),
                session_root=str(session_root),
                active_plan_path=str(active_plan_path),
                extra_write_roots=(str(plans_root),),
                extra_read_roots=(str(plans_root),),
            ):
                ctx = get_system_tool_context()
                self.assertEqual(ctx.project_root, root)
                self.assertEqual(ctx.session_root, session_root)
                self.assertEqual(ctx.active_plan_path, active_plan_path)
                self.assertEqual(ctx.extra_write_roots, (plans_root,))
                self.assertEqual(ctx.extra_read_roots, (plans_root,))

    def test_exit_plan_mode_reads_active_plan_file_and_returns_approval_payload(self) -> None:
        async def _run() -> None:
            with tempfile.TemporaryDirectory() as td:
                root = Path(td).resolve()
                plan_path = root / "plan.md"
                plan_path.write_text("# Plan\n\n- step 1", encoding="utf-8")
                with bind_system_tool_context(
                    project_root=root,
                    active_plan_path=plan_path,
                ):
                    result = await ExitPlanMode.execute(
                        summary="ready for approval",
                        execution_prompt="execute now",
                    )

                payload = json.loads(result)
                self.assertTrue(payload["ok"])
                data = payload["data"]
                self.assertEqual(data["status"], "waiting_for_plan_approval")
                self.assertEqual(data["summary"], "ready for approval")
                self.assertEqual(data["execution_prompt"], "execute now")
                self.assertEqual(data["plan_path"], str(plan_path))

                artifact_path = Path(data["plan_path"])
                self.assertTrue(artifact_path.exists())
                content = artifact_path.read_text(encoding="utf-8")
                self.assertIn("# Plan", content)

        asyncio.run(_run())

    def test_exit_plan_mode_rejects_plan_markdown_argument(self) -> None:
        async def _run() -> None:
            with tempfile.TemporaryDirectory() as td:
                root = Path(td).resolve()
                plan_path = root / "plan.md"
                plan_path.write_text("# Plan\n\n- step 1", encoding="utf-8")
                with bind_system_tool_context(
                    project_root=root,
                    active_plan_path=plan_path,
                ):
                    result = await ExitPlanMode.execute(
                        plan_markdown="# Other plan",
                        summary="ready for approval",
                    )

            payload = json.loads(result)
            self.assertFalse(payload["ok"])
            self.assertEqual(payload["error"]["code"], "INVALID_ARGUMENT")

        asyncio.run(_run())
