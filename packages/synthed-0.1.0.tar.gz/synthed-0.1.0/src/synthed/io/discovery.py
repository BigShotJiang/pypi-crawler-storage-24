"""Dataset discovery — scan directories for supported data files."""

from __future__ import annotations

import sqlite3
from dataclasses import dataclass, field
from pathlib import Path

from synthed.config.models import FileFormat
from synthed.utils.logging import get_logger

logger = get_logger("io.discovery")

EXTENSION_MAP = {
    ".csv": FileFormat.CSV,
    ".parquet": FileFormat.PARQUET,
    ".sqlite": FileFormat.SQLITE,
    ".db": FileFormat.SQLITE,
}


@dataclass
class DatasetInfo:
    """Metadata about a discovered dataset (one table)."""

    name: str
    path: Path
    format: FileFormat
    table_name: str | None = None  # For SQLite tables


@dataclass
class DiscoveryResult:
    """Collection of discovered datasets."""

    datasets: list[DatasetInfo] = field(default_factory=list)


def discover_datasets(path: Path) -> list[DatasetInfo]:
    """Discover all supported datasets under a path.

    For files, returns a single dataset. For directories, recursively finds
    all CSV, Parquet, and SQLite files. SQLite files yield one DatasetInfo
    per table.
    """
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(f"Path does not exist: {path}")

    results: list[DatasetInfo] = []

    if path.is_file():
        results.extend(_discover_file(path))
    elif path.is_dir():
        for child in sorted(path.rglob("*")):
            if child.is_file():
                results.extend(_discover_file(child))

    logger.info("Discovered %d dataset(s) under %s", len(results), path)
    return results


def _discover_file(path: Path) -> list[DatasetInfo]:
    """Discover datasets from a single file."""
    fmt = EXTENSION_MAP.get(path.suffix.lower())
    if fmt is None:
        return []

    if fmt == FileFormat.SQLITE:
        return _discover_sqlite_tables(path)

    name = path.stem
    return [DatasetInfo(name=name, path=path, format=fmt)]


def _discover_sqlite_tables(path: Path) -> list[DatasetInfo]:
    """List all user tables in a SQLite database."""
    results: list[DatasetInfo] = []
    try:
        conn = sqlite3.connect(str(path))
        cursor = conn.execute(
            "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'"
        )
        for (table_name,) in cursor.fetchall():
            results.append(
                DatasetInfo(
                    name=table_name,
                    path=path,
                    format=FileFormat.SQLITE,
                    table_name=table_name,
                )
            )
        conn.close()
    except Exception:
        logger.warning("Failed to read SQLite file: %s", path)
    return results
