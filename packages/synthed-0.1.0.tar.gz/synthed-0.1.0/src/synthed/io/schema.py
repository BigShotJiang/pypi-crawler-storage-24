"""Schema normalization utilities."""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import pandas as pd


@dataclass
class ColumnSchema:
    """Normalized schema info for a single column."""

    name: str
    pandas_dtype: str
    nullable: bool
    is_numeric: bool
    is_datetime: bool
    is_boolean: bool
    is_string: bool


def extract_schema(df: pd.DataFrame) -> list[ColumnSchema]:
    """Extract normalized schema from a DataFrame."""
    schemas: list[ColumnSchema] = []
    for col in df.columns:
        series = df[col]
        dtype_str = str(series.dtype)
        schemas.append(
            ColumnSchema(
                name=str(col),
                pandas_dtype=dtype_str,
                nullable=bool(series.isna().any()),
                is_numeric=pd.api.types.is_numeric_dtype(series),
                is_datetime=pd.api.types.is_datetime64_any_dtype(series),
                is_boolean=pd.api.types.is_bool_dtype(series)
                or set(series.dropna().unique()).issubset({True, False, 0, 1}),
                is_string=pd.api.types.is_string_dtype(series)
                or pd.api.types.is_object_dtype(series),
            )
        )
    return schemas
