"""Dataset readers for CSV, Parquet, and SQLite."""

from __future__ import annotations

import sqlite3

import pandas as pd

from synthed.config.models import FileFormat
from synthed.io.discovery import DatasetInfo
from synthed.utils.logging import get_logger

logger = get_logger("io.readers")


def read_dataset(info: DatasetInfo, sample_rows: int | None = None) -> pd.DataFrame:
    """Read a dataset into a pandas DataFrame.

    Args:
        info: Dataset metadata from discovery.
        sample_rows: If set, read only this many rows (for profiling large files).
    """
    reader = _READERS[info.format]
    df = reader(info, sample_rows)
    logger.info("Read %s: %d rows × %d columns", info.name, len(df), len(df.columns))
    return df


def _read_csv(info: DatasetInfo, sample_rows: int | None) -> pd.DataFrame:
    kwargs: dict = {"low_memory": False}
    if sample_rows is not None:
        kwargs["nrows"] = sample_rows
    return pd.read_csv(info.path, **kwargs)


def _read_parquet(info: DatasetInfo, sample_rows: int | None) -> pd.DataFrame:
    df = pd.read_parquet(info.path)
    if sample_rows is not None:
        df = df.head(sample_rows)
    return df


def _read_sqlite(info: DatasetInfo, sample_rows: int | None) -> pd.DataFrame:
    conn = sqlite3.connect(str(info.path))
    table = info.table_name or info.name
    query = f'SELECT * FROM "{table}"'
    if sample_rows is not None:
        query += f" LIMIT {sample_rows}"
    df = pd.read_sql_query(query, conn)
    conn.close()
    return df


_READERS = {
    FileFormat.CSV: _read_csv,
    FileFormat.PARQUET: _read_parquet,
    FileFormat.SQLITE: _read_sqlite,
}
