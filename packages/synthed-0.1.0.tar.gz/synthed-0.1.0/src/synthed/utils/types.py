"""Shared type definitions for Synthed."""

from __future__ import annotations

from enum import Enum


class SemanticType(str, Enum):
    """Inferred semantic type for a column."""

    ID = "id"
    FOREIGN_KEY = "foreign_key"
    CATEGORICAL = "categorical"
    NUMERIC = "numeric"
    DATETIME = "datetime"
    BOOLEAN = "boolean"
    TEXT = "text"
    UNKNOWN = "unknown"


class ColumnRole(str, Enum):
    """Role of a column in the table."""

    PRIMARY_KEY = "primary_key"
    FOREIGN_KEY = "foreign_key"
    ATTRIBUTE = "attribute"
    TIMESTAMP = "timestamp"
