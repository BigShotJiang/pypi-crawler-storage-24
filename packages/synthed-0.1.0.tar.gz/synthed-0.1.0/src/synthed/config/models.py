"""Configuration models for Synthed."""

from __future__ import annotations

from enum import Enum
from pathlib import Path
from typing import Any

from pydantic import BaseModel, Field


class FileFormat(str, Enum):
    CSV = "csv"
    PARQUET = "parquet"
    SQLITE = "sqlite"


class PrivacyConfig(BaseModel):
    """Privacy-related configuration."""

    min_group_size: int = Field(default=5, ge=1, description="Minimum group size for rare-group checks")
    max_exact_overlap_ratio: float = Field(default=0.0, ge=0.0, le=1.0, description="Maximum allowed exact row overlap ratio")
    high_risk_patterns: list[str] = Field(
        default_factory=lambda: [
            r".*_id$", r"^id$", r".*_key$", r"^ssn$", r"^email$",
            r"^phone$", r"^address$", r"^name$", r".*_number$",
            r"^account.*", r"^customer.*", r"^device.*", r"^transaction.*",
        ],
        description="Regex patterns for high-risk column names",
    )
    block_on_high_risk: bool = Field(default=True, description="Block export if high privacy risk detected")


class EdgeCaseConfig(BaseModel):
    """Edge case injection settings."""

    enabled: bool = True
    null_density_ratio: float = Field(default=0.02, ge=0.0, le=1.0)
    outlier_ratio: float = Field(default=0.01, ge=0.0, le=1.0)
    duplicate_like_ratio: float = Field(default=0.005, ge=0.0, le=1.0)
    date_boundary_cases: bool = True
    skewed_tail_boost: float = Field(default=0.01, ge=0.0, le=0.5)


class GenerationConfig(BaseModel):
    """Generation settings."""

    seed: int | None = Field(default=None, description="Random seed for reproducibility")
    row_scale_factor: float = Field(default=1.0, gt=0.0, description="Scale factor for row counts")
    edge_cases: EdgeCaseConfig = Field(default_factory=EdgeCaseConfig)
    batch_size: int = Field(default=10000, gt=0)


class SynthedConfig(BaseModel):
    """Top-level configuration."""

    input_paths: list[Path] = Field(default_factory=list)
    output_path: Path = Field(default=Path("./artifacts"))
    privacy: PrivacyConfig = Field(default_factory=PrivacyConfig)
    generation: GenerationConfig = Field(default_factory=GenerationConfig)
    formats: list[FileFormat] = Field(default_factory=lambda: [FileFormat.CSV])
    log_level: str = "INFO"

    @classmethod
    def default(cls) -> SynthedConfig:
        return cls()
