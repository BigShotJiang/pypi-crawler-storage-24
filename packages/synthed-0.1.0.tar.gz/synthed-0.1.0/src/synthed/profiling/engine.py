"""Table and column profiling engine."""

from __future__ import annotations

import re

import numpy as np
import pandas as pd
from pydantic import BaseModel, Field

from synthed.utils.logging import get_logger

logger = get_logger("profiling")


class ColumnProfile(BaseModel):
    """Statistical profile for a single column."""

    name: str
    dtype: str
    total_count: int
    null_count: int
    null_rate: float
    distinct_count: int
    distinct_rate: float
    is_unique: bool

    # Numeric stats (None if not numeric)
    min_val: float | None = None
    max_val: float | None = None
    mean: float | None = None
    median: float | None = None
    std: float | None = None
    q25: float | None = None
    q75: float | None = None
    zero_rate: float | None = None

    # Categorical stats
    top_values: dict[str, int] | None = None
    category_count: int | None = None

    # Datetime stats
    min_date: str | None = None
    max_date: str | None = None

    # Pattern hints
    sample_patterns: list[str] | None = None
    likely_id: bool = False


class TableProfile(BaseModel):
    """Profile for an entire table."""

    name: str
    row_count: int
    column_count: int
    columns: list[ColumnProfile]
    duplicate_row_count: int = 0
    candidate_keys: list[str] = Field(default_factory=list)


def profile_table(name: str, df: pd.DataFrame) -> TableProfile:
    """Profile all columns and table-level stats."""
    columns = [_profile_column(df[col]) for col in df.columns]
    dup_count = int(df.duplicated().sum())

    # Candidate keys: columns that are unique and not nullable
    candidate_keys = [
        cp.name for cp in columns if cp.is_unique and cp.null_count == 0
    ]

    return TableProfile(
        name=name,
        row_count=len(df),
        column_count=len(df.columns),
        columns=columns,
        duplicate_row_count=dup_count,
        candidate_keys=candidate_keys,
    )


def _profile_column(series: pd.Series) -> ColumnProfile:
    """Profile a single column."""
    name = str(series.name)
    total = len(series)
    null_count = int(series.isna().sum())
    non_null = series.dropna()
    distinct = int(non_null.nunique())

    profile = ColumnProfile(
        name=name,
        dtype=str(series.dtype),
        total_count=total,
        null_count=null_count,
        null_rate=null_count / total if total > 0 else 0.0,
        distinct_count=distinct,
        distinct_rate=distinct / total if total > 0 else 0.0,
        is_unique=distinct == len(non_null) and len(non_null) > 0,
    )

    # Check boolean before numeric (booleans are numeric in pandas)
    if pd.api.types.is_bool_dtype(series):
        pass  # Boolean — no extra stats needed
    elif pd.api.types.is_datetime64_any_dtype(series):
        _add_datetime_stats(profile, non_null)
    elif _try_parse_datetime(non_null):
        parsed = pd.to_datetime(non_null, errors="coerce").dropna()
        if len(parsed) > 0:
            _add_datetime_stats(profile, parsed)
    elif pd.api.types.is_numeric_dtype(series):
        _add_numeric_stats(profile, non_null)
    else:
        _add_categorical_stats(profile, non_null)
        _add_pattern_hints(profile, non_null)

    # ID heuristic
    profile.likely_id = _is_likely_id(profile, name)
    return profile


def _add_numeric_stats(profile: ColumnProfile, non_null: pd.Series) -> None:
    if len(non_null) == 0:
        return
    profile.min_val = float(non_null.min())
    profile.max_val = float(non_null.max())
    profile.mean = float(non_null.mean())
    profile.median = float(non_null.median())
    profile.std = float(non_null.std()) if len(non_null) > 1 else 0.0
    profile.q25 = float(non_null.quantile(0.25))
    profile.q75 = float(non_null.quantile(0.75))
    zeros = (non_null == 0).sum()
    profile.zero_rate = float(zeros / len(non_null))


def _add_categorical_stats(profile: ColumnProfile, non_null: pd.Series) -> None:
    if len(non_null) == 0:
        return
    vc = non_null.value_counts()
    profile.category_count = len(vc)
    profile.top_values = {str(k): int(v) for k, v in vc.head(20).items()}


def _add_datetime_stats(profile: ColumnProfile, non_null: pd.Series) -> None:
    if len(non_null) == 0:
        return
    profile.min_date = str(non_null.min())
    profile.max_date = str(non_null.max())


def _add_pattern_hints(profile: ColumnProfile, non_null: pd.Series) -> None:
    """Extract regex-like patterns from string columns."""
    if len(non_null) == 0:
        return
    sample = non_null.head(100).astype(str)
    patterns = set()
    for val in sample:
        pattern = re.sub(r"[A-Z]", "A", val)
        pattern = re.sub(r"[a-z]", "a", pattern)
        pattern = re.sub(r"[0-9]", "9", pattern)
        patterns.add(pattern)
        if len(patterns) >= 10:
            break
    profile.sample_patterns = sorted(patterns)[:10]


def _try_parse_datetime(series: pd.Series) -> bool:
    """Heuristic check if a string series looks like datetimes."""
    if len(series) == 0 or not (pd.api.types.is_object_dtype(series) or pd.api.types.is_string_dtype(series)):
        return False
    sample = series.head(20)
    try:
        import warnings
        with warnings.catch_warnings():
            warnings.simplefilter("ignore", UserWarning)
            parsed = pd.to_datetime(sample, errors="coerce", format="mixed")
        return parsed.notna().mean() > 0.8
    except Exception:
        return False


def _is_likely_id(profile: ColumnProfile, name: str) -> bool:
    """Heuristic: is this column likely an identifier?"""
    # If it has datetime stats, it's not an ID
    if profile.min_date is not None:
        return False

    name_lower = name.lower()

    # Exclude common non-ID names
    non_id_names = ["date", "time", "name", "email", "address", "description", "comment", "text"]
    if any(n in name_lower for n in non_id_names):
        return False

    id_patterns = ["_id", "id_", "^id$", "key", "code", "uuid", "guid", "number"]
    if any(re.search(p, name_lower) for p in id_patterns):
        if profile.is_unique or profile.distinct_rate > 0.95:
            return True

    # Only flag as ID if name-based heuristic matches (don't use uniqueness alone)
    return False
