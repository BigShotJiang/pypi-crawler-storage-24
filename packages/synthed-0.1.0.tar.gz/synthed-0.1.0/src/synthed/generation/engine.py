"""Synthetic data generation engine."""

from __future__ import annotations

import uuid
from datetime import datetime, timedelta

import numpy as np
import pandas as pd

from synthed.spec.models import ColumnSpec, DatasetSpec, ForeignKeySpec, TableSpec
from synthed.utils.logging import get_logger
from synthed.utils.types import SemanticType

logger = get_logger("generation")


class SyntheticGenerator:
    """Generate synthetic datasets from a DatasetSpec."""

    def __init__(self, spec: DatasetSpec) -> None:
        self.spec = spec
        self.rng = np.random.default_rng(spec.generation.seed)
        self.generated_tables: dict[str, pd.DataFrame] = {}

    def generate_all(self) -> dict[str, pd.DataFrame]:
        """Generate all tables in dependency order (parents first)."""
        order = self._resolve_generation_order()
        logger.info("Generation order: %s", order)

        for table_name in order:
            tspec = self._get_table_spec(table_name)
            row_count = max(1, int(tspec.row_count * self.spec.generation.row_scale_factor))
            logger.info("Generating %s: %d rows", table_name, row_count)
            df = self._generate_table(tspec, row_count)
            self.generated_tables[table_name] = df

        return self.generated_tables

    def _resolve_generation_order(self) -> list[str]:
        """Topological sort: parent tables before children."""
        table_names = {t.name for t in self.spec.tables}
        # Build dependency graph
        deps: dict[str, set[str]] = {t: set() for t in table_names}
        for fk in self.spec.foreign_keys:
            if fk.child_table in deps and fk.parent_table in table_names:
                deps[fk.child_table].add(fk.parent_table)

        # Simple topological sort
        order: list[str] = []
        visited: set[str] = set()

        def visit(name: str) -> None:
            if name in visited:
                return
            visited.add(name)
            for dep in deps.get(name, set()):
                visit(dep)
            order.append(name)

        for t in table_names:
            visit(t)
        return order

    def _get_table_spec(self, name: str) -> TableSpec:
        for t in self.spec.tables:
            if t.name == name:
                return t
        raise ValueError(f"Table not found in spec: {name}")

    def _generate_table(self, tspec: TableSpec, row_count: int) -> pd.DataFrame:
        """Generate a single table."""
        data: dict[str, list] = {}

        for cspec in tspec.columns:
            # Check if this column is an FK — if so, sample from parent
            fk = self._find_fk(tspec.name, cspec.name)
            if fk is not None:
                values = self._generate_fk_column(fk, cspec, row_count)
            else:
                values = self._generate_column(cspec, row_count)

            # Inject nulls
            if cspec.nullable and cspec.null_rate > 0:
                values = self._inject_nulls(values, cspec.null_rate)

            data[cspec.name] = values

        df = pd.DataFrame(data)

        # Edge case injection
        if self.spec.generation.edge_cases.enabled:
            df = self._inject_edge_cases(df, tspec)

        return df

    def _generate_column(self, cspec: ColumnSpec, n: int) -> list:
        """Generate values for a column based on its spec."""
        sem = cspec.semantic_type

        if sem == SemanticType.ID:
            return self._gen_id(cspec, n)
        elif sem == SemanticType.NUMERIC:
            return self._gen_numeric(cspec, n)
        elif sem == SemanticType.CATEGORICAL:
            return self._gen_categorical(cspec, n)
        elif sem == SemanticType.DATETIME:
            return self._gen_datetime(cspec, n)
        elif sem == SemanticType.BOOLEAN:
            return self._gen_boolean(cspec, n)
        elif sem == SemanticType.TEXT:
            return self._gen_text(cspec, n)
        elif sem == SemanticType.FOREIGN_KEY:
            # Should be handled by FK logic; fallback to sequential
            return list(range(1, n + 1))
        else:
            return [f"val_{i}" for i in range(n)]

    def _gen_id(self, cspec: ColumnSpec, n: int) -> list:
        """Generate unique IDs."""
        if cspec.id_type == "uuid":
            return [str(uuid.UUID(int=self.rng.integers(0, 2**128))) for _ in range(n)]
        elif cspec.id_type == "pattern" and cspec.patterns:
            pattern = cspec.patterns[0]
            return [self._fill_pattern(pattern, i) for i in range(1, n + 1)]
        else:
            # Sequential
            prefix = cspec.id_prefix or "SYN"
            return [f"{prefix}_{i:08d}" for i in range(1, n + 1)]

    def _gen_numeric(self, cspec: ColumnSpec, n: int) -> list:
        """Generate numeric values from distribution summary."""
        mean = cspec.numeric_mean or 0.0
        std = cspec.numeric_std or 1.0
        lo = cspec.numeric_min if cspec.numeric_min is not None else mean - 4 * std
        hi = cspec.numeric_max if cspec.numeric_max is not None else mean + 4 * std

        values = self.rng.normal(mean, max(std, 1e-9), size=n)
        values = np.clip(values, lo, hi)

        # Inject zeros
        if cspec.zero_rate and cspec.zero_rate > 0:
            mask = self.rng.random(n) < cspec.zero_rate
            values[mask] = 0.0

        # If original was integer-like
        if lo == int(lo) and hi == int(hi) and (cspec.numeric_mean is None or cspec.numeric_mean == int(cspec.numeric_mean)):
            return [int(round(v)) for v in values]
        return [round(float(v), 4) for v in values]

    def _gen_categorical(self, cspec: ColumnSpec, n: int) -> list:
        """Generate categorical values from distribution."""
        if not cspec.categories:
            return [f"cat_{i % 5}" for i in range(n)]
        cats = list(cspec.categories.keys())
        probs = list(cspec.categories.values())
        # Normalize probabilities
        total = sum(probs)
        probs = [p / total for p in probs]
        return list(self.rng.choice(cats, size=n, p=probs))

    def _gen_datetime(self, cspec: ColumnSpec, n: int) -> list:
        """Generate datetime values within range."""
        try:
            dt_min = pd.Timestamp(cspec.date_min) if cspec.date_min else pd.Timestamp("2020-01-01")
            dt_max = pd.Timestamp(cspec.date_max) if cspec.date_max else pd.Timestamp("2025-12-31")
        except Exception:
            dt_min = pd.Timestamp("2020-01-01")
            dt_max = pd.Timestamp("2025-12-31")

        if dt_min >= dt_max:
            dt_max = dt_min + pd.Timedelta(days=365)

        delta = (dt_max - dt_min).total_seconds()
        offsets = self.rng.uniform(0, delta, size=n)
        dates = [dt_min + pd.Timedelta(seconds=float(o)) for o in sorted(offsets)]
        return [d.strftime("%Y-%m-%d %H:%M:%S") for d in dates]

    def _gen_boolean(self, cspec: ColumnSpec, n: int) -> list:
        """Generate boolean values."""
        true_rate = cspec.true_rate if cspec.true_rate is not None else 0.5
        return list(self.rng.random(n) < true_rate)

    def _gen_text(self, cspec: ColumnSpec, n: int) -> list:
        """Generate text-like values."""
        min_len = cspec.min_length or 5
        max_len = cspec.max_length or 50
        max_len = max(max_len, min_len + 1)
        results = []
        chars = "abcdefghijklmnopqrstuvwxyz "
        for _ in range(n):
            length = int(self.rng.integers(min_len, max_len))
            text = "".join(self.rng.choice(list(chars), size=length))
            results.append(text)
        return results

    def _generate_fk_column(self, fk: ForeignKeySpec, cspec: ColumnSpec, n: int) -> list:
        """Generate FK values by sampling from parent table."""
        parent_df = self.generated_tables.get(fk.parent_table)
        if parent_df is None:
            logger.warning("Parent table %s not yet generated for FK %s.%s", fk.parent_table, fk.child_table, fk.child_column)
            return list(range(1, n + 1))

        parent_values = parent_df[fk.parent_column].dropna().unique()
        if len(parent_values) == 0:
            return list(range(1, n + 1))

        return list(self.rng.choice(parent_values, size=n))

    def _find_fk(self, table_name: str, col_name: str) -> ForeignKeySpec | None:
        for fk in self.spec.foreign_keys:
            if fk.child_table == table_name and fk.child_column == col_name:
                return fk
        return None

    def _inject_nulls(self, values: list, null_rate: float) -> list:
        """Randomly replace values with None at the given rate."""
        mask = self.rng.random(len(values)) < null_rate
        return [None if mask[i] else values[i] for i in range(len(values))]

    def _inject_edge_cases(self, df: pd.DataFrame, tspec: TableSpec) -> pd.DataFrame:
        """Inject edge cases into generated data."""
        ec = self.spec.generation.edge_cases
        n = len(df)
        if n == 0:
            return df

        # Convert to object dtype for safe null/value injection
        df = df.astype(object)

        # Collect FK columns to skip for edge cases
        fk_cols = {fk.child_column for fk in self.spec.foreign_keys if fk.child_table == tspec.name}

        # High null density rows
        null_rows = max(1, int(n * ec.null_density_ratio))
        null_indices = self.rng.choice(n, size=min(null_rows, n), replace=False)
        nullable_cols = [c.name for c in tspec.columns if c.nullable and c.name not in fk_cols and not c.unique]
        for idx in null_indices:
            for col in nullable_cols:
                df.iloc[int(idx), df.columns.get_loc(col)] = None

        # Numeric outliers (skip FK and PK columns)
        for cspec in tspec.columns:
            if cspec.name in fk_cols or cspec.unique:
                continue
            if cspec.semantic_type == SemanticType.NUMERIC and cspec.numeric_std:
                outlier_count = max(1, int(n * ec.outlier_ratio))
                outlier_indices = self.rng.choice(n, size=min(outlier_count, n), replace=False)
                lo = cspec.numeric_min if cspec.numeric_min is not None else 0
                hi = cspec.numeric_max if cspec.numeric_max is not None else 100
                col_loc = df.columns.get_loc(cspec.name)
                for idx in outlier_indices:
                    if self.rng.random() < 0.5:
                        df.iloc[int(idx), col_loc] = lo
                    else:
                        df.iloc[int(idx), col_loc] = hi

        return df

    def _fill_pattern(self, pattern: str, seq: int) -> str:
        """Fill a pattern like 'AAA-9999' with random/sequential chars."""
        result = []
        seq_str = str(seq)
        digit_pos = 0
        for ch in pattern:
            if ch == "A":
                result.append(chr(self.rng.integers(65, 91)))
            elif ch == "a":
                result.append(chr(self.rng.integers(97, 123)))
            elif ch == "9":
                if digit_pos < len(seq_str):
                    result.append(seq_str[digit_pos])
                    digit_pos += 1
                else:
                    result.append(str(self.rng.integers(0, 10)))
            else:
                result.append(ch)
        return "".join(result)
