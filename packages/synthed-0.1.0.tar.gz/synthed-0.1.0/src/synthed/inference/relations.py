"""Relation inference — detect PK/FK relationships between tables."""

from __future__ import annotations

from dataclasses import dataclass

import pandas as pd

from synthed.profiling.engine import TableProfile
from synthed.utils.logging import get_logger

logger = get_logger("inference.relations")


@dataclass
class ForeignKeyCandidate:
    """A candidate foreign key relationship."""

    child_table: str
    child_column: str
    parent_table: str
    parent_column: str
    coverage: float  # Fraction of child values found in parent
    confidence: float  # Overall confidence score


def infer_relations(
    profiles: dict[str, TableProfile],
    dataframes: dict[str, pd.DataFrame],
) -> list[ForeignKeyCandidate]:
    """Infer foreign key relationships between tables.

    Strategy:
    1. For each table, identify candidate primary keys (unique, non-null).
    2. For each non-PK column in other tables, check if its values are
       largely contained in a PK column.
    3. Also check name-based hints (e.g., orders.customer_id → customers.id).
    """
    # Build PK map: table → list of PK column names
    pk_map: dict[str, list[str]] = {}
    for tname, prof in profiles.items():
        pk_map[tname] = prof.candidate_keys

    candidates: list[ForeignKeyCandidate] = []

    for child_name, child_df in dataframes.items():
        child_prof = profiles[child_name]
        for col_prof in child_prof.columns:
            if col_prof.name in pk_map.get(child_name, []):
                continue  # Skip PKs of this table
            if col_prof.distinct_count == 0:
                continue

            # Check against PKs of other tables
            for parent_name, pk_cols in pk_map.items():
                if parent_name == child_name:
                    continue
                for pk_col in pk_cols:
                    score = _score_fk_candidate(
                        child_df, col_prof.name,
                        dataframes[parent_name], pk_col,
                        child_name, parent_name,
                    )
                    if score is not None:
                        candidates.append(score)

    # Sort by confidence descending
    candidates.sort(key=lambda c: c.confidence, reverse=True)

    # Deduplicate: keep highest confidence per child column
    seen: set[tuple[str, str]] = set()
    deduped: list[ForeignKeyCandidate] = []
    for c in candidates:
        key = (c.child_table, c.child_column)
        if key not in seen:
            seen.add(key)
            deduped.append(c)

    logger.info("Inferred %d FK relationship(s)", len(deduped))
    return deduped


def _score_fk_candidate(
    child_df: pd.DataFrame,
    child_col: str,
    parent_df: pd.DataFrame,
    parent_col: str,
    child_name: str,
    parent_name: str,
) -> ForeignKeyCandidate | None:
    """Score a single FK candidate."""
    # Type compatibility check: both should be same general type
    child_dtype = child_df[child_col].dtype
    parent_dtype = parent_df[parent_col].dtype
    child_is_num = pd.api.types.is_numeric_dtype(child_dtype)
    parent_is_num = pd.api.types.is_numeric_dtype(parent_dtype)
    if child_is_num != parent_is_num:
        return None

    child_vals = set(child_df[child_col].dropna().unique())
    parent_vals = set(parent_df[parent_col].dropna().unique())

    if len(child_vals) == 0 or len(parent_vals) == 0:
        return None

    overlap = child_vals & parent_vals
    coverage = len(overlap) / len(child_vals)

    if coverage < 0.7:
        return None

    # Name similarity bonus
    name_score = _name_similarity(child_col, parent_col, parent_name)

    # Require at least some name similarity for numeric columns
    confidence = coverage * 0.6 + name_score * 0.4

    if confidence < 0.65:
        return None

    return ForeignKeyCandidate(
        child_table=child_name,
        child_column=child_col,
        parent_table=parent_name,
        parent_column=parent_col,
        coverage=round(coverage, 4),
        confidence=round(confidence, 4),
    )


def _name_similarity(child_col: str, parent_col: str, parent_table: str) -> float:
    """Score name-based FK hints."""
    child_lower = child_col.lower()
    parent_lower = parent_col.lower()
    table_lower = parent_table.lower()

    # Direct match: child_col == parent_col
    if child_lower == parent_lower:
        return 0.8

    # Convention: child has "{parent_table}_id" or "{parent_table}id"
    if child_lower in (f"{table_lower}_id", f"{table_lower}id"):
        return 1.0

    # Convention: child ends with "_id" and parent is "id"
    if child_lower.endswith("_id") and parent_lower == "id":
        prefix = child_lower[:-3]
        if prefix == table_lower or table_lower.startswith(prefix):
            return 0.9

    return 0.0
