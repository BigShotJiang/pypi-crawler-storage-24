"""Semantic type inference for columns."""

from __future__ import annotations

import re

import pandas as pd

from synthed.profiling.engine import ColumnProfile
from synthed.utils.logging import get_logger
from synthed.utils.types import SemanticType

logger = get_logger("inference.semantic")


def infer_semantic_type(profile: ColumnProfile, series: pd.Series) -> SemanticType:
    """Infer the semantic type of a column from its profile and data."""
    # Datetime detection (before ID, since dates can be unique)
    if profile.min_date is not None:
        return SemanticType.DATETIME

    # ID detection
    if profile.likely_id:
        return SemanticType.ID

    # Boolean detection
    if _is_boolean(profile, series):
        return SemanticType.BOOLEAN

    # Numeric detection
    if profile.min_val is not None:
        if profile.category_count is not None and profile.category_count <= 20:
            return SemanticType.CATEGORICAL
        return SemanticType.NUMERIC

    # Categorical vs text
    if profile.category_count is not None:
        # High distinct_rate means values are mostly unique — treat as text
        if profile.distinct_rate > 0.9:
            return SemanticType.TEXT
        if profile.category_count <= 100 or profile.distinct_rate < 0.5:
            return SemanticType.CATEGORICAL
        return SemanticType.TEXT

    return SemanticType.UNKNOWN


def _is_boolean(profile: ColumnProfile, series: pd.Series) -> bool:
    """Check if column is boolean-like."""
    if pd.api.types.is_bool_dtype(series):
        return True
    non_null = series.dropna()
    if len(non_null) == 0:
        return False
    unique = set(non_null.unique())
    bool_sets = [
        {True, False},
        {0, 1},
        {"true", "false"},
        {"yes", "no"},
        {"y", "n"},
        {"0", "1"},
        {"T", "F"},
    ]
    str_unique = {str(v).lower() for v in unique}
    for bs in bool_sets:
        if str_unique.issubset({str(v).lower() for v in bs}):
            return True
    return False
