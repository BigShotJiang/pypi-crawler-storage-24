"""Synthed CLI application."""

from __future__ import annotations

from pathlib import Path
from typing import Optional

import typer
from rich.console import Console

from synthed import PRIVACY_DISCLAIMER, __version__

app = typer.Typer(
    name="synthed",
    help="Privacy-first synthetic data blueprint generator.",
    no_args_is_help=True,
)
console = Console(stderr=True)


def version_callback(value: bool) -> None:
    if value:
        typer.echo(f"synthed {__version__}")
        raise typer.Exit()


@app.callback()
def main(
    version: Optional[bool] = typer.Option(None, "--version", callback=version_callback, is_eager=True),
) -> None:
    """Synthed — Privacy-first synthetic data blueprint generator."""


@app.command()
def scan(
    data_path: Path = typer.Argument(..., help="Path to data directory or file"),
    verbose: bool = typer.Option(False, "--verbose", "-v"),
) -> None:
    """Scan a data directory and list discovered datasets."""
    from synthed.utils.logging import setup_logging

    setup_logging("DEBUG" if verbose else "INFO")

    from synthed.io.discovery import discover_datasets

    datasets = discover_datasets(data_path)
    console.print(f"[bold]Discovered {len(datasets)} dataset(s):[/bold]")
    for ds in datasets:
        console.print(f"  • {ds.name} ({ds.format.value}) — {ds.path}")


@app.command()
def profile(
    data_path: Path = typer.Argument(..., help="Path to data directory or file"),
    out: Path = typer.Option(Path("./artifacts/profile"), "--out", "-o"),
    verbose: bool = typer.Option(False, "--verbose", "-v"),
) -> None:
    """Profile datasets and output statistics."""
    from synthed.utils.logging import setup_logging

    setup_logging("DEBUG" if verbose else "INFO")

    from synthed.io.discovery import discover_datasets
    from synthed.io.readers import read_dataset
    from synthed.profiling.engine import profile_table
    from synthed.export.writer import write_json

    out.mkdir(parents=True, exist_ok=True)
    datasets = discover_datasets(data_path)
    for ds in datasets:
        df = read_dataset(ds)
        prof = profile_table(ds.name, df)
        write_json(prof.model_dump(), out / f"{ds.name}_profile.json")
        console.print(f"  ✓ Profiled {ds.name}: {len(df)} rows, {len(df.columns)} columns")
    console.print(f"[bold green]Profiles written to {out}[/bold green]")


@app.command(name="build-spec")
def build_spec(
    data_path: Path = typer.Argument(..., help="Path to data directory or file"),
    out: Path = typer.Option(Path("./artifacts/spec"), "--out", "-o"),
    verbose: bool = typer.Option(False, "--verbose", "-v"),
) -> None:
    """Build a portable synthetic data spec from source data."""
    from synthed.utils.logging import setup_logging

    setup_logging("DEBUG" if verbose else "INFO")

    from synthed.pipeline import build_spec_from_path

    spec = build_spec_from_path(data_path)

    from synthed.export.writer import write_yaml

    out.mkdir(parents=True, exist_ok=True)
    write_yaml(spec.model_dump(mode="json"), out / "spec.yaml")
    console.print(f"[bold green]Spec written to {out / 'spec.yaml'}[/bold green]")


@app.command()
def generate(
    spec_path: Path = typer.Option(..., "--spec", "-s", help="Path to spec YAML file"),
    out: Path = typer.Option(Path("./artifacts/generated"), "--out", "-o"),
    seed: Optional[int] = typer.Option(None, "--seed"),
    scale: float = typer.Option(1.0, "--scale", help="Row count scale factor"),
    verbose: bool = typer.Option(False, "--verbose", "-v"),
) -> None:
    """Generate synthetic data from a spec."""
    from synthed.utils.logging import setup_logging

    setup_logging("DEBUG" if verbose else "INFO")

    from synthed.export.writer import read_yaml, write_csv
    from synthed.generation.engine import SyntheticGenerator
    from synthed.spec.models import DatasetSpec

    raw = read_yaml(spec_path)
    spec = DatasetSpec.model_validate(raw)
    if seed is not None:
        spec.generation.seed = seed
    spec.generation.row_scale_factor = scale

    gen = SyntheticGenerator(spec)
    tables = gen.generate_all()

    out.mkdir(parents=True, exist_ok=True)
    for name, df in tables.items():
        write_csv(df, out / f"{name}.csv")
        console.print(f"  ✓ Generated {name}: {len(df)} rows")
    console.print(f"[bold green]Synthetic data written to {out}[/bold green]")


@app.command()
def evaluate(
    real_path: Path = typer.Option(..., "--real", "-r", help="Path to real data directory"),
    synthetic_path: Path = typer.Option(..., "--synthetic", "-s", help="Path to synthetic data directory"),
    out: Path = typer.Option(Path("./artifacts/report"), "--out", "-o"),
    verbose: bool = typer.Option(False, "--verbose", "-v"),
) -> None:
    """Evaluate synthetic data against real data."""
    from synthed.utils.logging import setup_logging

    setup_logging("DEBUG" if verbose else "INFO")

    from synthed.evaluation.engine import evaluate_synthetic
    from synthed.export.writer import write_json, write_markdown
    from synthed.io.discovery import discover_datasets
    from synthed.io.readers import read_dataset
    from synthed.reporting.engine import render_report

    real_datasets = {ds.name: read_dataset(ds) for ds in discover_datasets(real_path)}
    synth_datasets = {ds.name: read_dataset(ds) for ds in discover_datasets(synthetic_path)}

    report = evaluate_synthetic(real_datasets, synth_datasets)

    out.mkdir(parents=True, exist_ok=True)
    write_json(report.model_dump(), out / "evaluation.json")
    write_markdown(render_report(report), out / "evaluation.md")
    console.print(f"[bold green]Evaluation report written to {out}[/bold green]")


@app.command(name="run-pipeline")
def run_pipeline(
    data_path: Path = typer.Argument(..., help="Path to data directory"),
    out: Path = typer.Option(Path("./artifacts"), "--out", "-o"),
    seed: Optional[int] = typer.Option(None, "--seed"),
    scale: float = typer.Option(1.0, "--scale"),
    verbose: bool = typer.Option(False, "--verbose", "-v"),
) -> None:
    """Run the full pipeline: scan → profile → build-spec → generate → evaluate → report."""
    from synthed.utils.logging import setup_logging

    setup_logging("DEBUG" if verbose else "INFO")

    from synthed.pipeline import run_full_pipeline

    run_full_pipeline(data_path, out, seed=seed, scale=scale)
    console.print(f"\n[bold green]Pipeline complete. Artifacts in {out}[/bold green]")
    console.print(f"[dim]{PRIVACY_DISCLAIMER}[/dim]")
