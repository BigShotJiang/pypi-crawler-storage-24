"""Constraint extraction — hard and soft rules from profiled data."""

from __future__ import annotations

from pydantic import BaseModel, Field

import pandas as pd

from synthed.profiling.engine import ColumnProfile, TableProfile
from synthed.utils.logging import get_logger
from synthed.utils.types import SemanticType

logger = get_logger("constraints")


class HardConstraint(BaseModel):
    """A hard constraint that must be satisfied."""

    table: str
    column: str
    rule_type: str  # "unique", "not_null", "range", "date_order", "conditional_null"
    params: dict = Field(default_factory=dict)


class SoftConstraint(BaseModel):
    """A soft constraint (statistical pattern to approximate)."""

    table: str
    column: str | None = None
    rule_type: str  # "category_cooccurrence", "row_count_ratio", "child_count_dist"
    params: dict = Field(default_factory=dict)


def extract_constraints(
    name: str,
    df: pd.DataFrame,
    profile: TableProfile,
    semantic_types: dict[str, SemanticType],
) -> tuple[list[HardConstraint], list[SoftConstraint]]:
    """Extract hard and soft constraints from a table."""
    hard: list[HardConstraint] = []
    soft: list[SoftConstraint] = []

    for cp in profile.columns:
        sem = semantic_types.get(cp.name, SemanticType.UNKNOWN)

        # Uniqueness
        if cp.is_unique and cp.null_count == 0:
            hard.append(HardConstraint(
                table=name, column=cp.name,
                rule_type="unique",
            ))

        # Not-null
        if cp.null_count == 0:
            hard.append(HardConstraint(
                table=name, column=cp.name,
                rule_type="not_null",
            ))

        # Numeric range
        if cp.min_val is not None and cp.max_val is not None and sem == SemanticType.NUMERIC:
            hard.append(HardConstraint(
                table=name, column=cp.name,
                rule_type="range",
                params={"min": cp.min_val, "max": cp.max_val},
            ))

        # Categorical distribution as soft constraint
        if cp.top_values and sem == SemanticType.CATEGORICAL:
            total = sum(cp.top_values.values())
            dist = {k: round(v / total, 4) for k, v in cp.top_values.items()}
            soft.append(SoftConstraint(
                table=name, column=cp.name,
                rule_type="category_distribution",
                params={"distribution": dist},
            ))

    # Date ordering: if multiple datetime cols, check ordering
    dt_cols = [cp.name for cp in profile.columns if cp.min_date is not None]
    if len(dt_cols) >= 2:
        for i, c1 in enumerate(dt_cols):
            for c2 in dt_cols[i + 1:]:
                if _check_date_order(df, c1, c2):
                    hard.append(HardConstraint(
                        table=name, column=c1,
                        rule_type="date_order",
                        params={"before": c1, "after": c2},
                    ))

    logger.info("Extracted %d hard, %d soft constraints for %s", len(hard), len(soft), name)
    return hard, soft


def _check_date_order(df: pd.DataFrame, col_a: str, col_b: str) -> bool:
    """Check if col_a <= col_b in at least 95% of non-null rows."""
    try:
        a = pd.to_datetime(df[col_a], errors="coerce")
        b = pd.to_datetime(df[col_b], errors="coerce")
        valid = a.notna() & b.notna()
        if valid.sum() == 0:
            return False
        return float((a[valid] <= b[valid]).mean()) >= 0.95
    except Exception:
        return False
