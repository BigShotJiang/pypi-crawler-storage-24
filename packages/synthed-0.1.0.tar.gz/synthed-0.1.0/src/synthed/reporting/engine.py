"""Report rendering engine."""

from __future__ import annotations

from synthed import PRIVACY_DISCLAIMER
from synthed.evaluation.engine import EvaluationReport


def render_report(report: EvaluationReport) -> str:
    """Render an evaluation report as Markdown."""
    lines: list[str] = []
    lines.append("# Synthed Evaluation Report\n")

    # Overall summary
    lines.append("## Summary\n")
    lines.append(f"- **Overall fidelity score**: {report.overall_fidelity_score:.2%}")
    lines.append(f"- **Overall usability**: {report.overall_usability}")
    lines.append(f"- **Privacy risk**: {report.privacy.overall_risk}")
    lines.append("")

    # Per-table details
    lines.append("## Table Results\n")
    for te in report.tables:
        lines.append(f"### {te.name}\n")
        lines.append(f"- Real rows: {te.real_rows}")
        lines.append(f"- Synthetic rows: {te.synth_rows}")
        lines.append(f"- Schema match: {'Yes' if te.schema_match else 'No'}")
        lines.append("")

        if te.column_fidelity:
            lines.append("| Column | Null Δ | Distinct Δ | Mean Δ | Cat Overlap |")
            lines.append("|--------|--------|------------|--------|-------------|")
            for cf in te.column_fidelity:
                mean_str = f"{cf.mean_diff:.4f}" if cf.mean_diff is not None else "—"
                cat_str = f"{cf.category_overlap:.2%}" if cf.category_overlap is not None else "—"
                lines.append(
                    f"| {cf.name} | {cf.null_rate_diff:.4f} | {cf.distinct_rate_diff:.4f} | {mean_str} | {cat_str} |"
                )
            lines.append("")

    # Privacy results
    lines.append("## Privacy Checks\n")
    for check in report.privacy.checks:
        status = "PASS" if check.passed else "FAIL"
        lines.append(f"- **[{status}]** {check.check_name} — {check.details} (risk: {check.risk_level})")
    lines.append("")

    if report.privacy.high_risk_columns:
        lines.append("### High-Risk Columns Detected\n")
        for hrc in report.privacy.high_risk_columns:
            lines.append(f"- {hrc['table']}.{hrc['column']}")
        lines.append("")

    # Disclaimer
    lines.append("---\n")
    lines.append(f"*{PRIVACY_DISCLAIMER}*\n")

    return "\n".join(lines)
