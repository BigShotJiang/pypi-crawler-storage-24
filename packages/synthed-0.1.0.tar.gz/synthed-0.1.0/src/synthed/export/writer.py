"""Export utilities — write data, specs, and reports."""

from __future__ import annotations

import json
import sqlite3
from pathlib import Path
from typing import Any

import pandas as pd
import yaml

from synthed.utils.logging import get_logger

logger = get_logger("export")


def write_csv(df: pd.DataFrame, path: Path) -> None:
    """Write DataFrame to CSV."""
    path.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(path, index=False)
    logger.info("Wrote CSV: %s (%d rows)", path, len(df))


def write_parquet(df: pd.DataFrame, path: Path) -> None:
    """Write DataFrame to Parquet."""
    path.parent.mkdir(parents=True, exist_ok=True)
    df.to_parquet(path, index=False)
    logger.info("Wrote Parquet: %s (%d rows)", path, len(df))


def write_sqlite(tables: dict[str, pd.DataFrame], path: Path) -> None:
    """Write multiple DataFrames to a SQLite database."""
    path.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(path))
    for name, df in tables.items():
        df.to_sql(name, conn, if_exists="replace", index=False)
        logger.info("Wrote SQLite table %s: %d rows", name, len(df))
    conn.close()


def write_json(data: Any, path: Path) -> None:
    """Write data to JSON file."""
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w") as f:
        json.dump(data, f, indent=2, default=str)
    logger.info("Wrote JSON: %s", path)


def _sanitize_for_yaml(obj: Any) -> Any:
    """Convert enums and other non-serializable types to plain values."""
    if isinstance(obj, dict):
        return {k: _sanitize_for_yaml(v) for k, v in obj.items()}
    elif isinstance(obj, list):
        return [_sanitize_for_yaml(v) for v in obj]
    elif hasattr(obj, "value") and isinstance(obj, type(obj)):
        # Enum-like
        return obj.value
    elif isinstance(obj, (str, int, float, bool, type(None))):
        return obj
    else:
        return str(obj)


def write_yaml(data: Any, path: Path) -> None:
    """Write data to YAML file."""
    path.parent.mkdir(parents=True, exist_ok=True)
    clean = _sanitize_for_yaml(data)
    with open(path, "w") as f:
        yaml.dump(clean, f, default_flow_style=False, sort_keys=False, allow_unicode=True)
    logger.info("Wrote YAML: %s", path)


def read_yaml(path: Path) -> dict:
    """Read a YAML file."""
    with open(path) as f:
        return yaml.safe_load(f)


def write_markdown(content: str, path: Path) -> None:
    """Write markdown content to file."""
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w") as f:
        f.write(content)
    logger.info("Wrote Markdown: %s", path)
