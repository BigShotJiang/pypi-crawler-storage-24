"""Evaluation engine — compare synthetic data against real data."""

from __future__ import annotations

import numpy as np
import pandas as pd
from pydantic import BaseModel, Field

from synthed.config.models import PrivacyConfig
from synthed.privacy.checks import PrivacyReport, run_privacy_checks
from synthed.utils.logging import get_logger

logger = get_logger("evaluation")


class ColumnFidelity(BaseModel):
    """Fidelity metrics for a single column."""

    name: str
    dtype_match: bool
    null_rate_diff: float
    distinct_rate_diff: float
    # Numeric
    mean_diff: float | None = None
    std_diff: float | None = None
    # Categorical
    category_overlap: float | None = None
    distribution_divergence: float | None = None


class TableEvaluation(BaseModel):
    """Evaluation for one table."""

    name: str
    real_rows: int
    synth_rows: int
    schema_match: bool
    column_fidelity: list[ColumnFidelity]
    rule_violations: int = 0


class EvaluationReport(BaseModel):
    """Full evaluation report."""

    tables: list[TableEvaluation] = Field(default_factory=list)
    privacy: PrivacyReport = Field(default_factory=PrivacyReport)
    overall_fidelity_score: float = 0.0
    overall_usability: str = "unknown"


def evaluate_synthetic(
    real: dict[str, pd.DataFrame],
    synthetic: dict[str, pd.DataFrame],
    privacy_config: PrivacyConfig | None = None,
) -> EvaluationReport:
    """Evaluate synthetic data quality and privacy."""
    privacy_config = privacy_config or PrivacyConfig()
    tables: list[TableEvaluation] = []

    for table_name, real_df in real.items():
        synth_df = synthetic.get(table_name)
        if synth_df is None:
            logger.warning("Table %s not found in synthetic data", table_name)
            continue
        tables.append(_evaluate_table(table_name, real_df, synth_df))

    privacy_report = run_privacy_checks(real, synthetic, privacy_config)

    fidelity_scores = []
    for te in tables:
        for cf in te.column_fidelity:
            scores = [1.0 - min(cf.null_rate_diff, 1.0), 1.0 - min(cf.distinct_rate_diff, 1.0)]
            if cf.mean_diff is not None:
                scores.append(1.0 - min(cf.mean_diff, 1.0))
            if cf.category_overlap is not None:
                scores.append(cf.category_overlap)
            fidelity_scores.extend(scores)

    overall = float(np.mean(fidelity_scores)) if fidelity_scores else 0.0

    usability = "good" if overall > 0.8 and not privacy_report.has_critical_risk() else (
        "acceptable" if overall > 0.6 else "poor"
    )

    return EvaluationReport(
        tables=tables,
        privacy=privacy_report,
        overall_fidelity_score=round(overall, 4),
        overall_usability=usability,
    )


def _evaluate_table(name: str, real: pd.DataFrame, synth: pd.DataFrame) -> TableEvaluation:
    """Evaluate a single table."""
    common_cols = sorted(set(real.columns) & set(synth.columns))
    schema_match = set(real.columns) == set(synth.columns)

    col_fidelities = []
    for col in common_cols:
        col_fidelities.append(_evaluate_column(col, real[col], synth[col]))

    return TableEvaluation(
        name=name,
        real_rows=len(real),
        synth_rows=len(synth),
        schema_match=schema_match,
        column_fidelity=col_fidelities,
    )


def _evaluate_column(name: str, real: pd.Series, synth: pd.Series) -> ColumnFidelity:
    """Evaluate fidelity of a single column."""
    real_null_rate = real.isna().mean()
    synth_null_rate = synth.isna().mean()
    real_distinct_rate = real.nunique() / len(real) if len(real) > 0 else 0
    synth_distinct_rate = synth.nunique() / len(synth) if len(synth) > 0 else 0

    fidelity = ColumnFidelity(
        name=name,
        dtype_match=str(real.dtype) == str(synth.dtype) or True,  # Lenient on dtype
        null_rate_diff=abs(real_null_rate - synth_null_rate),
        distinct_rate_diff=abs(real_distinct_rate - synth_distinct_rate),
    )

    # Numeric comparison
    if pd.api.types.is_numeric_dtype(real) and pd.api.types.is_numeric_dtype(synth):
        real_clean = real.dropna()
        synth_clean = synth.dropna()
        if len(real_clean) > 0 and len(synth_clean) > 0:
            real_std = real_clean.std()
            normalizer = real_std if real_std > 0 else 1.0
            fidelity.mean_diff = abs(real_clean.mean() - synth_clean.mean()) / normalizer
            fidelity.std_diff = abs(real_clean.std() - synth_clean.std()) / normalizer

    # Categorical comparison
    elif real.dtype == "object" or synth.dtype == "object":
        real_cats = set(real.dropna().unique())
        synth_cats = set(synth.dropna().unique())
        if len(real_cats) > 0:
            fidelity.category_overlap = len(real_cats & synth_cats) / len(real_cats)
            # Distribution divergence (simplified)
            real_dist = real.value_counts(normalize=True)
            synth_dist = synth.value_counts(normalize=True)
            all_cats = set(real_dist.index) | set(synth_dist.index)
            divergence = sum(
                abs(real_dist.get(c, 0) - synth_dist.get(c, 0)) for c in all_cats
            ) / 2
            fidelity.distribution_divergence = float(divergence)

    return fidelity
