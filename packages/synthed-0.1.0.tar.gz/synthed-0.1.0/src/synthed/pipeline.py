"""Pipeline orchestration — ties all phases together."""

from __future__ import annotations

from pathlib import Path

import pandas as pd

from synthed.config.models import PrivacyConfig
from synthed.constraints.extractor import extract_constraints
from synthed.evaluation.engine import evaluate_synthetic
from synthed.export.writer import write_csv, write_json, write_markdown, write_yaml
from synthed.generation.engine import SyntheticGenerator
from synthed.inference.relations import infer_relations
from synthed.inference.semantic import infer_semantic_type
from synthed.io.discovery import discover_datasets
from synthed.io.readers import read_dataset
from synthed.profiling.engine import profile_table
from synthed.reporting.engine import render_report
from synthed.spec.builder import build_spec
from synthed.spec.models import DatasetSpec
from synthed.utils.logging import get_logger
from synthed.utils.types import SemanticType

logger = get_logger("pipeline")


def build_spec_from_path(data_path: Path, privacy_config: PrivacyConfig | None = None) -> DatasetSpec:
    """Build a DatasetSpec by scanning, profiling, and inferring from data."""
    datasets = discover_datasets(data_path)
    if not datasets:
        raise ValueError(f"No datasets found at {data_path}")

    dataframes: dict[str, pd.DataFrame] = {}
    profiles = {}
    semantic_types: dict[str, dict[str, SemanticType]] = {}
    all_constraints = {}

    for ds in datasets:
        df = read_dataset(ds)
        dataframes[ds.name] = df

        # Profile
        prof = profile_table(ds.name, df)
        profiles[ds.name] = prof

        # Semantic inference
        col_types: dict[str, SemanticType] = {}
        for cp in prof.columns:
            col_types[cp.name] = infer_semantic_type(cp, df[cp.name])
        semantic_types[ds.name] = col_types

        # Constraints
        hard, soft = extract_constraints(ds.name, df, prof, col_types)
        all_constraints[ds.name] = (hard, soft)

    # Relation inference
    fk_candidates = infer_relations(profiles, dataframes)

    # Build spec
    spec = build_spec(
        profiles=profiles,
        dataframes=dataframes,
        semantic_types=semantic_types,
        fk_candidates=fk_candidates,
        constraints=all_constraints,
        privacy_config=privacy_config,
    )

    return spec


def run_full_pipeline(
    data_path: Path,
    output_path: Path,
    seed: int | None = None,
    scale: float = 1.0,
) -> None:
    """Run the complete pipeline: scan → spec → generate → evaluate → report."""
    logger.info("Starting full pipeline: %s → %s", data_path, output_path)

    # Phase 1: Build spec
    spec = build_spec_from_path(data_path)
    if seed is not None:
        spec.generation.seed = seed
    spec.generation.row_scale_factor = scale

    spec_dir = output_path / "spec"
    spec_dir.mkdir(parents=True, exist_ok=True)
    write_yaml(spec.model_dump(mode="json"), spec_dir / "spec.yaml")
    logger.info("Spec written to %s", spec_dir / "spec.yaml")

    # Phase 2: Generate synthetic data
    gen = SyntheticGenerator(spec)
    synthetic_tables = gen.generate_all()

    gen_dir = output_path / "generated"
    gen_dir.mkdir(parents=True, exist_ok=True)
    for name, df in synthetic_tables.items():
        write_csv(df, gen_dir / f"{name}.csv")

    # Phase 3: Evaluate
    real_datasets = {}
    for ds in discover_datasets(data_path):
        real_datasets[ds.name] = read_dataset(ds)

    report = evaluate_synthetic(real_datasets, synthetic_tables, spec.privacy)

    report_dir = output_path / "report"
    report_dir.mkdir(parents=True, exist_ok=True)
    write_json(report.model_dump(), report_dir / "evaluation.json")
    write_markdown(render_report(report), report_dir / "evaluation.md")

    logger.info(
        "Pipeline complete. Fidelity: %.2f%%, Privacy risk: %s",
        report.overall_fidelity_score * 100,
        report.privacy.overall_risk,
    )
