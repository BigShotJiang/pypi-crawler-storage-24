"""Privacy risk checks for synthetic data."""

from __future__ import annotations

import re

import numpy as np
import pandas as pd
from pydantic import BaseModel, Field

from synthed.config.models import PrivacyConfig
from synthed.utils.logging import get_logger

logger = get_logger("privacy")


class PrivacyCheckResult(BaseModel):
    """Result of a single privacy check."""

    check_name: str
    passed: bool
    risk_level: str  # "low", "medium", "high", "critical"
    details: str
    metrics: dict = Field(default_factory=dict)


class PrivacyReport(BaseModel):
    """Aggregated privacy report."""

    overall_risk: str = "low"
    checks: list[PrivacyCheckResult] = Field(default_factory=list)
    high_risk_columns: list[dict] = Field(default_factory=list)
    disclaimer: str = (
        "This tool reduces privacy risk but does not automatically establish "
        "legal anonymization. Users are responsible for compliance."
    )

    def has_critical_risk(self) -> bool:
        return any(c.risk_level == "critical" for c in self.checks)


def run_privacy_checks(
    real: dict[str, pd.DataFrame],
    synthetic: dict[str, pd.DataFrame],
    config: PrivacyConfig,
) -> PrivacyReport:
    """Run all privacy checks and return a report."""
    checks: list[PrivacyCheckResult] = []
    hr_cols: list[dict] = []

    for table_name in real:
        if table_name not in synthetic:
            continue

        real_df = real[table_name]
        synth_df = synthetic[table_name]

        # 1. Exact row overlap
        checks.append(check_exact_overlap(table_name, real_df, synth_df, config))

        # 2. Rare group leakage
        checks.append(check_rare_groups(table_name, real_df, synth_df, config))

        # 3. High-risk columns
        for col in real_df.columns:
            if _is_high_risk_column(col, config):
                hr_cols.append({"table": table_name, "column": col})
                checks.append(check_high_risk_regeneration(table_name, col, real_df, synth_df))

        # 4. Small dataset warning
        if len(real_df) < 100:
            checks.append(PrivacyCheckResult(
                check_name=f"{table_name}:small_dataset_warning",
                passed=True,
                risk_level="medium",
                details=f"Small dataset ({len(real_df)} rows) — higher re-identification risk.",
                metrics={"row_count": len(real_df)},
            ))

    overall = _compute_overall_risk(checks)

    return PrivacyReport(
        overall_risk=overall,
        checks=checks,
        high_risk_columns=hr_cols,
    )


def check_exact_overlap(
    table: str, real: pd.DataFrame, synth: pd.DataFrame, config: PrivacyConfig
) -> PrivacyCheckResult:
    """Check for exact row overlap between real and synthetic data."""
    # Compare on common columns only
    common_cols = sorted(set(real.columns) & set(synth.columns))
    if not common_cols:
        return PrivacyCheckResult(
            check_name=f"{table}:exact_overlap",
            passed=True,
            risk_level="low",
            details="No common columns to compare.",
        )

    real_tuples = set(real[common_cols].dropna().apply(tuple, axis=1))
    synth_tuples = set(synth[common_cols].dropna().apply(tuple, axis=1))

    overlap = real_tuples & synth_tuples
    overlap_ratio = len(overlap) / len(real_tuples) if len(real_tuples) > 0 else 0.0

    passed = overlap_ratio <= config.max_exact_overlap_ratio

    if overlap_ratio > 0.1:
        risk = "critical"
    elif overlap_ratio > 0.01:
        risk = "high"
    elif overlap_ratio > 0:
        risk = "medium"
    else:
        risk = "low"

    return PrivacyCheckResult(
        check_name=f"{table}:exact_overlap",
        passed=passed,
        risk_level=risk,
        details=f"Exact row overlap: {overlap_ratio:.4%} ({len(overlap)} rows)",
        metrics={"overlap_ratio": overlap_ratio, "overlap_count": len(overlap)},
    )


def check_rare_groups(
    table: str, real: pd.DataFrame, synth: pd.DataFrame, config: PrivacyConfig
) -> PrivacyCheckResult:
    """Check for rare group leakage in categorical columns."""
    cat_cols = [c for c in real.columns if real[c].dtype == "object" and real[c].nunique() < 50]

    if len(cat_cols) < 2:
        return PrivacyCheckResult(
            check_name=f"{table}:rare_groups",
            passed=True,
            risk_level="low",
            details="Not enough categorical columns for group analysis.",
        )

    # Use first 3 categorical columns for group check
    group_cols = cat_cols[:3]
    real_groups = real.groupby(group_cols, dropna=False).size().reset_index(name="count")
    rare_real = real_groups[real_groups["count"] < config.min_group_size]

    if len(rare_real) == 0:
        return PrivacyCheckResult(
            check_name=f"{table}:rare_groups",
            passed=True,
            risk_level="low",
            details="No rare groups found in real data.",
        )

    # Check if synthetic reproduces rare groups
    synth_groups = synth.groupby(group_cols, dropna=False).size().reset_index(name="count")
    rare_real_tuples = set(rare_real[group_cols].apply(tuple, axis=1))
    synth_tuples = set(synth_groups[group_cols].apply(tuple, axis=1))
    leaked = rare_real_tuples & synth_tuples
    leak_ratio = len(leaked) / len(rare_real_tuples) if len(rare_real_tuples) > 0 else 0.0

    if leak_ratio > 0.5:
        risk = "high"
    elif leak_ratio > 0.1:
        risk = "medium"
    else:
        risk = "low"

    return PrivacyCheckResult(
        check_name=f"{table}:rare_groups",
        passed=leak_ratio <= 0.5,
        risk_level=risk,
        details=f"Rare group leakage: {leak_ratio:.2%} ({len(leaked)}/{len(rare_real_tuples)})",
        metrics={"leak_ratio": leak_ratio, "leaked_groups": len(leaked), "total_rare_groups": len(rare_real_tuples)},
    )


def check_high_risk_regeneration(
    table: str, column: str, real: pd.DataFrame, synth: pd.DataFrame
) -> PrivacyCheckResult:
    """Check that high-risk identifiers were regenerated (no overlap)."""
    if column not in synth.columns:
        return PrivacyCheckResult(
            check_name=f"{table}:{column}:high_risk_regen",
            passed=True,
            risk_level="low",
            details=f"Column {column} not in synthetic data (suppressed).",
        )

    real_vals = set(real[column].dropna().unique())
    synth_vals = set(synth[column].dropna().unique())
    overlap = real_vals & synth_vals
    overlap_ratio = len(overlap) / len(real_vals) if len(real_vals) > 0 else 0.0

    if overlap_ratio > 0.1:
        risk = "critical"
        passed = False
    elif overlap_ratio > 0:
        risk = "high"
        passed = False
    else:
        risk = "low"
        passed = True

    return PrivacyCheckResult(
        check_name=f"{table}:{column}:high_risk_regen",
        passed=passed,
        risk_level=risk,
        details=f"High-risk column overlap: {overlap_ratio:.4%} ({len(overlap)} values)",
        metrics={"overlap_ratio": overlap_ratio, "overlap_count": len(overlap)},
    )


def _is_high_risk_column(col_name: str, config: PrivacyConfig) -> bool:
    for pattern in config.high_risk_patterns:
        if re.search(pattern, col_name.lower()):
            return True
    return False


def _compute_overall_risk(checks: list[PrivacyCheckResult]) -> str:
    if any(c.risk_level == "critical" for c in checks):
        return "critical"
    if any(c.risk_level == "high" for c in checks):
        return "high"
    if any(c.risk_level == "medium" for c in checks):
        return "medium"
    return "low"
