"""Spec models — portable description of how to generate synthetic data."""

from __future__ import annotations

from pydantic import BaseModel, Field

from synthed.config.models import EdgeCaseConfig, GenerationConfig, PrivacyConfig
from synthed.utils.types import SemanticType


class ColumnSpec(BaseModel):
    """Specification for generating a single column."""

    name: str
    semantic_type: SemanticType
    nullable: bool = False
    null_rate: float = 0.0
    unique: bool = False

    # Numeric
    numeric_min: float | None = None
    numeric_max: float | None = None
    numeric_mean: float | None = None
    numeric_std: float | None = None
    zero_rate: float | None = None

    # Categorical
    categories: dict[str, float] | None = None  # value → probability

    # Datetime
    date_min: str | None = None
    date_max: str | None = None

    # Boolean
    true_rate: float | None = None

    # Text / pattern
    patterns: list[str] | None = None
    min_length: int | None = None
    max_length: int | None = None

    # ID generation
    id_prefix: str | None = None
    id_type: str | None = None  # "sequential", "uuid", "pattern"

    # Privacy
    is_high_risk: bool = False
    privacy_action: str | None = None  # "regenerate", "suppress"


class ForeignKeySpec(BaseModel):
    """Specification for a foreign key relationship."""

    child_table: str
    child_column: str
    parent_table: str
    parent_column: str


class TableSpec(BaseModel):
    """Specification for generating a single table."""

    name: str
    row_count: int
    columns: list[ColumnSpec]
    primary_key: str | None = None
    hard_constraints: list[dict] = Field(default_factory=list)
    soft_constraints: list[dict] = Field(default_factory=list)


class DatasetSpec(BaseModel):
    """Top-level spec for an entire dataset."""

    spec_version: str = "0.1.0"
    tables: list[TableSpec]
    foreign_keys: list[ForeignKeySpec] = Field(default_factory=list)
    privacy: PrivacyConfig = Field(default_factory=PrivacyConfig)
    generation: GenerationConfig = Field(default_factory=GenerationConfig)
    metadata: dict = Field(default_factory=dict)
