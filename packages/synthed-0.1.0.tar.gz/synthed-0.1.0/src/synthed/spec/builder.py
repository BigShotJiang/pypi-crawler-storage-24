"""Build a DatasetSpec from profiled and inferred data."""

from __future__ import annotations

import re

import pandas as pd

from synthed.config.models import PrivacyConfig
from synthed.constraints.extractor import HardConstraint, SoftConstraint
from synthed.inference.relations import ForeignKeyCandidate
from synthed.profiling.engine import ColumnProfile, TableProfile
from synthed.spec.models import ColumnSpec, DatasetSpec, ForeignKeySpec, TableSpec
from synthed.utils.logging import get_logger
from synthed.utils.types import SemanticType

logger = get_logger("spec.builder")


def build_spec(
    profiles: dict[str, TableProfile],
    dataframes: dict[str, pd.DataFrame],
    semantic_types: dict[str, dict[str, SemanticType]],
    fk_candidates: list[ForeignKeyCandidate],
    constraints: dict[str, tuple[list[HardConstraint], list[SoftConstraint]]],
    privacy_config: PrivacyConfig | None = None,
) -> DatasetSpec:
    """Assemble a full DatasetSpec from analysis results."""
    privacy_config = privacy_config or PrivacyConfig()
    tables: list[TableSpec] = []

    for tname, prof in profiles.items():
        sem_types = semantic_types.get(tname, {})
        df = dataframes[tname]
        hard, soft = constraints.get(tname, ([], []))

        columns = [
            _build_column_spec(cp, df[cp.name], sem_types.get(cp.name, SemanticType.UNKNOWN), privacy_config)
            for cp in prof.columns
        ]

        pk = prof.candidate_keys[0] if prof.candidate_keys else None

        tables.append(TableSpec(
            name=tname,
            row_count=prof.row_count,
            columns=columns,
            primary_key=pk,
            hard_constraints=[h.model_dump() for h in hard],
            soft_constraints=[s.model_dump() for s in soft],
        ))

    fk_specs = [
        ForeignKeySpec(
            child_table=fk.child_table,
            child_column=fk.child_column,
            parent_table=fk.parent_table,
            parent_column=fk.parent_column,
        )
        for fk in fk_candidates
    ]

    spec = DatasetSpec(
        tables=tables,
        foreign_keys=fk_specs,
        privacy=privacy_config,
    )
    logger.info("Built spec with %d tables, %d FK relationships", len(tables), len(fk_specs))
    return spec


def _build_column_spec(
    profile: ColumnProfile,
    series: pd.Series,
    sem_type: SemanticType,
    privacy_config: PrivacyConfig,
) -> ColumnSpec:
    """Build a ColumnSpec from a column profile."""
    is_high_risk = _check_high_risk(profile.name, privacy_config)

    spec = ColumnSpec(
        name=profile.name,
        semantic_type=sem_type,
        nullable=profile.null_count > 0,
        null_rate=profile.null_rate,
        unique=profile.is_unique,
        is_high_risk=is_high_risk,
        privacy_action="regenerate" if is_high_risk else None,
    )

    if sem_type == SemanticType.NUMERIC:
        spec.numeric_min = profile.min_val
        spec.numeric_max = profile.max_val
        spec.numeric_mean = profile.mean
        spec.numeric_std = profile.std
        spec.zero_rate = profile.zero_rate

    elif sem_type == SemanticType.CATEGORICAL:
        if profile.top_values:
            total = sum(profile.top_values.values())
            spec.categories = {k: round(v / total, 6) for k, v in profile.top_values.items()}

    elif sem_type == SemanticType.DATETIME:
        spec.date_min = profile.min_date
        spec.date_max = profile.max_date

    elif sem_type == SemanticType.BOOLEAN:
        non_null = series.dropna()
        if len(non_null) > 0:
            true_vals = non_null.isin([True, 1, "true", "True", "yes", "Yes", "Y", "y", "1", "T"])
            spec.true_rate = float(true_vals.mean())

    elif sem_type == SemanticType.TEXT:
        spec.patterns = profile.sample_patterns
        lengths = series.dropna().astype(str).str.len()
        if len(lengths) > 0:
            spec.min_length = int(lengths.min())
            spec.max_length = int(lengths.max())

    elif sem_type == SemanticType.ID:
        spec.id_type = "sequential"
        if profile.sample_patterns:
            spec.patterns = profile.sample_patterns
            spec.id_type = "pattern"

    return spec


def _check_high_risk(col_name: str, config: PrivacyConfig) -> bool:
    """Check if a column name matches high-risk patterns."""
    for pattern in config.high_risk_patterns:
        if re.search(pattern, col_name.lower()):
            return True
    return False
