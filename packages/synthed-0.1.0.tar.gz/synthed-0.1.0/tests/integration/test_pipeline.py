"""Integration tests for the full pipeline."""

import shutil
from pathlib import Path

import pandas as pd
import pytest

from synthed.pipeline import build_spec_from_path, run_full_pipeline

SAMPLE_DATA = Path(__file__).parent.parent.parent / "examples" / "sample_data"


@pytest.fixture
def sample_dir(tmp_path: Path) -> Path:
    """Copy sample data to temp dir."""
    dest = tmp_path / "data"
    shutil.copytree(SAMPLE_DATA, dest)
    return dest


def test_build_spec(sample_dir: Path):
    spec = build_spec_from_path(sample_dir)
    table_names = {t.name for t in spec.tables}
    assert "customers" in table_names
    assert "orders" in table_names
    assert "order_items" in table_names
    assert len(spec.foreign_keys) >= 1


def test_full_pipeline(sample_dir: Path, tmp_path: Path):
    out = tmp_path / "artifacts"
    run_full_pipeline(sample_dir, out, seed=42)

    # Spec exists
    assert (out / "spec" / "spec.yaml").exists()

    # Generated data exists
    assert (out / "generated" / "customers.csv").exists()
    assert (out / "generated" / "orders.csv").exists()
    assert (out / "generated" / "order_items.csv").exists()

    # Report exists
    assert (out / "report" / "evaluation.json").exists()
    assert (out / "report" / "evaluation.md").exists()


def test_relational_integrity(sample_dir: Path, tmp_path: Path):
    out = tmp_path / "artifacts"
    run_full_pipeline(sample_dir, out, seed=42)

    customers = pd.read_csv(out / "generated" / "customers.csv")
    orders = pd.read_csv(out / "generated" / "orders.csv")

    # All order customer_ids should be in customers
    customer_ids = set(customers["customer_id"].dropna())
    order_customer_ids = set(orders["customer_id"].dropna())
    assert order_customer_ids.issubset(customer_ids), (
        f"Orphan customer_ids in orders: {order_customer_ids - customer_ids}"
    )


def test_no_exact_original_ids(sample_dir: Path, tmp_path: Path):
    out = tmp_path / "artifacts"
    run_full_pipeline(sample_dir, out, seed=42)

    real_customers = pd.read_csv(sample_dir / "customers.csv")
    synth_customers = pd.read_csv(out / "generated" / "customers.csv")

    # customer_id should not overlap
    real_ids = set(real_customers["customer_id"])
    synth_ids = set(synth_customers["customer_id"])
    assert len(real_ids & synth_ids) == 0, "Synthetic IDs should not match real IDs"


def test_pipeline_with_scale(sample_dir: Path, tmp_path: Path):
    out = tmp_path / "artifacts"
    run_full_pipeline(sample_dir, out, seed=42, scale=2.0)

    customers = pd.read_csv(out / "generated" / "customers.csv")
    assert len(customers) == 40  # 20 * 2.0


def test_pipeline_reproducibility(sample_dir: Path, tmp_path: Path):
    out1 = tmp_path / "run1"
    out2 = tmp_path / "run2"

    run_full_pipeline(sample_dir, out1, seed=42)
    run_full_pipeline(sample_dir, out2, seed=42)

    df1 = pd.read_csv(out1 / "generated" / "customers.csv")
    df2 = pd.read_csv(out2 / "generated" / "customers.csv")

    pd.testing.assert_frame_equal(df1, df2)
