"""CLI smoke tests."""

import shutil
from pathlib import Path

import pytest
from typer.testing import CliRunner

from synthed.cli.main import app

runner = CliRunner()

SAMPLE_DATA = Path(__file__).parent.parent.parent / "examples" / "sample_data"


@pytest.fixture
def sample_dir(tmp_path: Path) -> Path:
    dest = tmp_path / "data"
    shutil.copytree(SAMPLE_DATA, dest)
    return dest


def test_version():
    result = runner.invoke(app, ["--version"])
    assert result.exit_code == 0
    assert "0.1.0" in result.stdout


def test_scan(sample_dir: Path):
    result = runner.invoke(app, ["scan", str(sample_dir)])
    assert result.exit_code == 0
    assert "customers" in result.stdout


def test_profile(sample_dir: Path, tmp_path: Path):
    out = tmp_path / "profile_out"
    result = runner.invoke(app, ["profile", str(sample_dir), "--out", str(out)])
    assert result.exit_code == 0
    assert (out / "customers_profile.json").exists()


def test_build_spec(sample_dir: Path, tmp_path: Path):
    out = tmp_path / "spec_out"
    result = runner.invoke(app, ["build-spec", str(sample_dir), "--out", str(out)])
    assert result.exit_code == 0
    assert (out / "spec.yaml").exists()


def test_generate(sample_dir: Path, tmp_path: Path):
    spec_out = tmp_path / "spec"
    runner.invoke(app, ["build-spec", str(sample_dir), "--out", str(spec_out)])

    gen_out = tmp_path / "generated"
    result = runner.invoke(app, ["generate", "--spec", str(spec_out / "spec.yaml"), "--out", str(gen_out), "--seed", "42"])
    assert result.exit_code == 0
    assert (gen_out / "customers.csv").exists()


def test_run_pipeline(sample_dir: Path, tmp_path: Path):
    out = tmp_path / "artifacts"
    result = runner.invoke(app, ["run-pipeline", str(sample_dir), "--out", str(out), "--seed", "42"])
    assert result.exit_code == 0
    assert (out / "spec" / "spec.yaml").exists()
    assert (out / "generated" / "customers.csv").exists()
    assert (out / "report" / "evaluation.md").exists()
