"""Tests for privacy checks."""

import pandas as pd
import pytest

from synthed.config.models import PrivacyConfig
from synthed.privacy.checks import (
    check_exact_overlap,
    check_high_risk_regeneration,
    check_rare_groups,
    run_privacy_checks,
)


def test_exact_overlap_detected():
    real = pd.DataFrame({"a": [1, 2, 3], "b": ["x", "y", "z"]})
    synth = pd.DataFrame({"a": [1, 2, 4], "b": ["x", "y", "w"]})
    config = PrivacyConfig()
    result = check_exact_overlap("test", real, synth, config)
    # Two rows overlap: (1,x) and (2,y)
    assert result.metrics["overlap_count"] == 2
    assert not result.passed  # overlap > 0


def test_no_overlap():
    real = pd.DataFrame({"a": [1, 2, 3], "b": ["x", "y", "z"]})
    synth = pd.DataFrame({"a": [4, 5, 6], "b": ["a", "b", "c"]})
    config = PrivacyConfig()
    result = check_exact_overlap("test", real, synth, config)
    assert result.metrics["overlap_count"] == 0
    assert result.passed


def test_high_risk_regeneration_pass():
    real = pd.DataFrame({"user_id": ["U001", "U002", "U003"]})
    synth = pd.DataFrame({"user_id": ["SYN_001", "SYN_002", "SYN_003"]})
    result = check_high_risk_regeneration("test", "user_id", real, synth)
    assert result.passed
    assert result.risk_level == "low"


def test_high_risk_regeneration_fail():
    real = pd.DataFrame({"user_id": ["U001", "U002", "U003"]})
    synth = pd.DataFrame({"user_id": ["U001", "SYN_002", "SYN_003"]})
    result = check_high_risk_regeneration("test", "user_id", real, synth)
    assert not result.passed


def test_full_privacy_report():
    real = {"table1": pd.DataFrame({"id": [1, 2, 3], "cat": ["a", "b", "c"]})}
    synth = {"table1": pd.DataFrame({"id": [4, 5, 6], "cat": ["d", "e", "f"]})}
    config = PrivacyConfig()
    report = run_privacy_checks(real, synth, config)
    assert report.overall_risk in ("low", "medium", "high", "critical")
    assert len(report.checks) > 0
    assert report.disclaimer != ""


def test_rare_group_detection():
    real = pd.DataFrame({
        "cat1": ["a", "a", "b", "b", "c", "c", "d", "d", "e", "e", "a", "b", "c", "d", "e", "a", "b", "c", "d", "e"],
        "cat2": ["x", "x", "x", "x", "x", "y", "y", "y", "y", "y", "x", "x", "x", "y", "y", "x", "y", "x", "y", "x"],
    })
    synth = pd.DataFrame({
        "cat1": ["a", "b", "c", "d", "e"] * 4,
        "cat2": ["x", "y"] * 10,
    })
    config = PrivacyConfig(min_group_size=5)
    result = check_rare_groups("test", real, synth, config)
    assert isinstance(result.passed, bool)
