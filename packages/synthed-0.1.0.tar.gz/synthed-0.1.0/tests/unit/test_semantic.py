"""Tests for semantic type inference."""

import pandas as pd
import pytest

from synthed.inference.semantic import infer_semantic_type
from synthed.profiling.engine import profile_table
from synthed.utils.types import SemanticType


def _infer(df: pd.DataFrame, col: str) -> SemanticType:
    prof = profile_table("test", df)
    cp = next(c for c in prof.columns if c.name == col)
    return infer_semantic_type(cp, df[col])


def test_infer_numeric():
    df = pd.DataFrame({"score": [85.0, 92.5, 78.0, 95.0, 88.5, 70.0, 60.0, 55.0, 80.0, 75.0]})
    assert _infer(df, "score") == SemanticType.NUMERIC


def test_infer_categorical():
    df = pd.DataFrame({"status": ["active", "inactive", "active", "pending", "active"] * 4})
    assert _infer(df, "status") == SemanticType.CATEGORICAL


def test_infer_datetime():
    df = pd.DataFrame({"dt": pd.to_datetime(["2023-01-01", "2023-06-15", "2023-12-31"])})
    assert _infer(df, "dt") == SemanticType.DATETIME


def test_infer_boolean():
    df = pd.DataFrame({"flag": [True, False, True, False, True]})
    assert _infer(df, "flag") == SemanticType.BOOLEAN


def test_infer_id():
    df = pd.DataFrame({"customer_id": range(1, 21)})
    assert _infer(df, "customer_id") == SemanticType.ID


def test_infer_text_high_cardinality():
    df = pd.DataFrame({"description": [f"text item {i}" for i in range(20)]})
    assert _infer(df, "description") == SemanticType.TEXT
