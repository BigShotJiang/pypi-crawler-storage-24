"""Tests for spec serialization and deserialization."""

import tempfile
from pathlib import Path

import yaml
import pytest

from synthed.export.writer import read_yaml, write_yaml
from synthed.spec.models import ColumnSpec, DatasetSpec, TableSpec
from synthed.utils.types import SemanticType


def test_spec_roundtrip(tmp_path: Path):
    spec = DatasetSpec(
        tables=[
            TableSpec(
                name="test",
                row_count=100,
                columns=[
                    ColumnSpec(name="id", semantic_type=SemanticType.ID, unique=True, id_type="sequential"),
                    ColumnSpec(name="value", semantic_type=SemanticType.NUMERIC, numeric_min=0, numeric_max=100),
                ],
            ),
        ],
    )

    path = tmp_path / "spec.yaml"
    write_yaml(spec.model_dump(mode="json"), path)

    loaded = read_yaml(path)
    spec2 = DatasetSpec.model_validate(loaded)

    assert spec2.tables[0].name == "test"
    assert spec2.tables[0].row_count == 100
    assert len(spec2.tables[0].columns) == 2


def test_spec_version():
    spec = DatasetSpec(tables=[])
    assert spec.spec_version == "0.1.0"


def test_spec_optional_sections():
    """Spec should work with minimal fields."""
    raw = {
        "tables": [{"name": "t", "row_count": 10, "columns": []}],
    }
    spec = DatasetSpec.model_validate(raw)
    assert len(spec.tables) == 1
    assert spec.foreign_keys == []
    assert spec.generation.seed is None


def test_spec_yaml_readable(tmp_path: Path):
    spec = DatasetSpec(
        tables=[
            TableSpec(
                name="users",
                row_count=50,
                columns=[
                    ColumnSpec(name="id", semantic_type=SemanticType.ID),
                    ColumnSpec(name="status", semantic_type=SemanticType.CATEGORICAL, categories={"active": 0.7, "inactive": 0.3}),
                ],
            ),
        ],
    )
    path = tmp_path / "spec.yaml"
    write_yaml(spec.model_dump(mode="json"), path)

    content = path.read_text()
    # Should be plain YAML, no Python-specific types
    assert "!!python" not in content
    assert "tables:" in content
