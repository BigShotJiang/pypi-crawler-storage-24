"""Tests for dataset discovery."""

import tempfile
from pathlib import Path

import pytest

from synthed.config.models import FileFormat
from synthed.io.discovery import discover_datasets


def test_discover_csv_files(tmp_path: Path):
    (tmp_path / "data.csv").write_text("a,b\n1,2\n")
    datasets = discover_datasets(tmp_path)
    assert len(datasets) == 1
    assert datasets[0].name == "data"
    assert datasets[0].format == FileFormat.CSV


def test_discover_multiple_formats(tmp_path: Path):
    (tmp_path / "file1.csv").write_text("a\n1\n")
    (tmp_path / "file2.parquet").write_bytes(b"")  # invalid but discovered
    datasets = discover_datasets(tmp_path)
    names = {d.name for d in datasets}
    assert "file1" in names


def test_discover_empty_dir(tmp_path: Path):
    datasets = discover_datasets(tmp_path)
    assert len(datasets) == 0


def test_discover_nonexistent_path():
    with pytest.raises(FileNotFoundError):
        discover_datasets(Path("/nonexistent/path"))


def test_discover_single_file(tmp_path: Path):
    f = tmp_path / "test.csv"
    f.write_text("x,y\n1,2\n")
    datasets = discover_datasets(f)
    assert len(datasets) == 1


def test_discover_sqlite(tmp_path: Path):
    import sqlite3
    db_path = tmp_path / "test.sqlite"
    conn = sqlite3.connect(str(db_path))
    conn.execute("CREATE TABLE users (id INTEGER, name TEXT)")
    conn.execute("INSERT INTO users VALUES (1, 'Alice')")
    conn.commit()
    conn.close()

    datasets = discover_datasets(db_path)
    assert len(datasets) == 1
    assert datasets[0].name == "users"
    assert datasets[0].format == FileFormat.SQLITE


def test_discover_ignores_unknown_formats(tmp_path: Path):
    (tmp_path / "readme.txt").write_text("hello")
    (tmp_path / "data.csv").write_text("a\n1\n")
    datasets = discover_datasets(tmp_path)
    assert len(datasets) == 1
