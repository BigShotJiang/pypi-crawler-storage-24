"""Tests for synthetic data generation."""

import pandas as pd
import pytest

from synthed.generation.engine import SyntheticGenerator
from synthed.spec.models import ColumnSpec, DatasetSpec, ForeignKeySpec, TableSpec
from synthed.utils.types import SemanticType


def _make_simple_spec() -> DatasetSpec:
    return DatasetSpec(
        tables=[
            TableSpec(
                name="users",
                row_count=100,
                columns=[
                    ColumnSpec(name="id", semantic_type=SemanticType.ID, unique=True, id_type="sequential"),
                    ColumnSpec(name="age", semantic_type=SemanticType.NUMERIC, numeric_min=18, numeric_max=90, numeric_mean=40, numeric_std=15),
                    ColumnSpec(name="status", semantic_type=SemanticType.CATEGORICAL, categories={"active": 0.7, "inactive": 0.3}),
                    ColumnSpec(name="created", semantic_type=SemanticType.DATETIME, date_min="2020-01-01", date_max="2024-12-31"),
                    ColumnSpec(name="verified", semantic_type=SemanticType.BOOLEAN, true_rate=0.8),
                ],
            ),
        ],
    )


def test_generate_basic():
    spec = _make_simple_spec()
    spec.generation.seed = 42
    gen = SyntheticGenerator(spec)
    tables = gen.generate_all()
    assert "users" in tables
    df = tables["users"]
    assert len(df) == 100
    assert set(df.columns) == {"id", "age", "status", "created", "verified"}


def test_generate_unique_ids():
    spec = _make_simple_spec()
    spec.generation.seed = 42
    gen = SyntheticGenerator(spec)
    tables = gen.generate_all()
    df = tables["users"]
    assert df["id"].nunique() == 100


def test_generate_categorical_distribution():
    spec = _make_simple_spec()
    spec.generation.seed = 42
    gen = SyntheticGenerator(spec)
    tables = gen.generate_all()
    df = tables["users"]
    active_rate = (df["status"] == "active").mean()
    assert 0.5 < active_rate < 0.9  # Roughly 70%


def test_generate_reproducible():
    spec = _make_simple_spec()
    spec.generation.seed = 42
    gen1 = SyntheticGenerator(spec)
    t1 = gen1.generate_all()

    gen2 = SyntheticGenerator(spec)
    t2 = gen2.generate_all()

    pd.testing.assert_frame_equal(t1["users"], t2["users"])


def test_generate_with_fk():
    spec = DatasetSpec(
        tables=[
            TableSpec(
                name="parents",
                row_count=10,
                columns=[ColumnSpec(name="id", semantic_type=SemanticType.ID, unique=True, id_type="sequential")],
                primary_key="id",
            ),
            TableSpec(
                name="children",
                row_count=30,
                columns=[
                    ColumnSpec(name="id", semantic_type=SemanticType.ID, unique=True, id_type="sequential"),
                    ColumnSpec(name="parent_id", semantic_type=SemanticType.FOREIGN_KEY),
                    ColumnSpec(name="value", semantic_type=SemanticType.NUMERIC, numeric_min=0, numeric_max=100, numeric_mean=50, numeric_std=20),
                ],
            ),
        ],
        foreign_keys=[
            ForeignKeySpec(child_table="children", child_column="parent_id", parent_table="parents", parent_column="id"),
        ],
    )
    spec.generation.seed = 42

    gen = SyntheticGenerator(spec)
    tables = gen.generate_all()

    parent_ids = set(tables["parents"]["id"])
    child_parent_ids = set(tables["children"]["parent_id"].dropna())
    assert child_parent_ids.issubset(parent_ids)


def test_generate_scale_factor():
    spec = _make_simple_spec()
    spec.generation.seed = 42
    spec.generation.row_scale_factor = 2.0
    gen = SyntheticGenerator(spec)
    tables = gen.generate_all()
    assert len(tables["users"]) == 200


def test_generate_nullable_column():
    spec = DatasetSpec(
        tables=[
            TableSpec(
                name="test",
                row_count=1000,
                columns=[
                    ColumnSpec(name="id", semantic_type=SemanticType.ID, unique=True, id_type="sequential"),
                    ColumnSpec(name="opt", semantic_type=SemanticType.NUMERIC, nullable=True, null_rate=0.3, numeric_min=0, numeric_max=100, numeric_mean=50, numeric_std=20),
                ],
            ),
        ],
    )
    spec.generation.seed = 42
    gen = SyntheticGenerator(spec)
    tables = gen.generate_all()
    df = tables["test"]
    null_rate = df["opt"].isna().mean()
    assert 0.15 < null_rate < 0.45  # Roughly 30%
