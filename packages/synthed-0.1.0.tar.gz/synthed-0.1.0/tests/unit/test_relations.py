"""Tests for relation inference."""

import pandas as pd
import pytest

from synthed.inference.relations import infer_relations
from synthed.profiling.engine import profile_table


def test_infer_simple_fk():
    parents = pd.DataFrame({"id": [1, 2, 3]})
    children = pd.DataFrame({"parent_id": [1, 2, 1, 3], "value": [10, 20, 30, 40]})

    profs = {
        "parents": profile_table("parents", parents),
        "children": profile_table("children", children),
    }
    dfs = {"parents": parents, "children": children}

    fks = infer_relations(profs, dfs)
    # May or may not detect depending on name matching
    # At minimum should not crash
    assert isinstance(fks, list)


def test_infer_fk_with_naming_convention():
    customers = pd.DataFrame({"id": range(1, 11)})
    orders = pd.DataFrame({"id": range(100, 120), "customer_id": [1, 2, 3, 4, 5] * 4})

    profs = {
        "customers": profile_table("customers", customers),
        "orders": profile_table("orders", orders),
    }
    dfs = {"customers": customers, "orders": orders}

    fks = infer_relations(profs, dfs)
    fk_pairs = [(f.child_table, f.child_column, f.parent_table) for f in fks]
    assert ("orders", "customer_id", "customers") in fk_pairs


def test_no_false_fk_on_unrelated():
    table_a = pd.DataFrame({"id": [1, 2, 3], "value": [100, 200, 300]})
    table_b = pd.DataFrame({"id": [10, 20, 30], "score": [1.5, 2.5, 3.5]})

    profs = {
        "a": profile_table("a", table_a),
        "b": profile_table("b", table_b),
    }
    dfs = {"a": table_a, "b": table_b}

    fks = infer_relations(profs, dfs)
    # Should not infer FK between unrelated tables with no value overlap
    assert len(fks) == 0
