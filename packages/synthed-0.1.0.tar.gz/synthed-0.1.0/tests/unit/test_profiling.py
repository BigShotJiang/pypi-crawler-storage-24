"""Tests for profiling engine."""

import pandas as pd
import pytest

from synthed.profiling.engine import profile_table


def test_profile_basic_table():
    df = pd.DataFrame({
        "id": [1, 2, 3, 4, 5],
        "name": ["Alice", "Bob", "Charlie", "Diana", "Eve"],
        "score": [85.0, 92.5, 78.0, 95.0, 88.5],
    })
    prof = profile_table("test", df)
    assert prof.name == "test"
    assert prof.row_count == 5
    assert prof.column_count == 3
    assert len(prof.columns) == 3


def test_profile_numeric_stats():
    df = pd.DataFrame({"value": [10, 20, 30, 40, 50]})
    prof = profile_table("test", df)
    col = prof.columns[0]
    assert col.min_val == 10.0
    assert col.max_val == 50.0
    assert col.mean == 30.0


def test_profile_null_detection():
    df = pd.DataFrame({"x": [1, None, 3, None, 5]})
    prof = profile_table("test", df)
    col = prof.columns[0]
    assert col.null_count == 2
    assert col.null_rate == 0.4


def test_profile_unique_detection():
    df = pd.DataFrame({"id": [1, 2, 3, 4, 5]})
    prof = profile_table("test", df)
    col = prof.columns[0]
    assert col.is_unique is True


def test_profile_candidate_keys():
    df = pd.DataFrame({
        "id": [1, 2, 3],
        "name": ["a", "b", "c"],
        "category": ["x", "x", "y"],
    })
    prof = profile_table("test", df)
    assert "id" in prof.candidate_keys


def test_profile_duplicate_detection():
    df = pd.DataFrame({
        "a": [1, 1, 2],
        "b": ["x", "x", "y"],
    })
    prof = profile_table("test", df)
    assert prof.duplicate_row_count == 1


def test_profile_datetime_column():
    df = pd.DataFrame({"dt": pd.to_datetime(["2023-01-01", "2023-06-15", "2023-12-31"])})
    prof = profile_table("test", df)
    col = prof.columns[0]
    assert col.min_date is not None
    assert col.max_date is not None


def test_profile_zero_rate():
    df = pd.DataFrame({"val": [0, 0, 0, 1, 2]})
    prof = profile_table("test", df)
    col = prof.columns[0]
    assert col.zero_rate == 0.6
