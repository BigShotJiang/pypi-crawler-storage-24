"""Tests for dataset readers."""

import sqlite3
from pathlib import Path

import pandas as pd
import pytest

from synthed.config.models import FileFormat
from synthed.io.discovery import DatasetInfo
from synthed.io.readers import read_dataset


def test_read_csv(tmp_path: Path):
    csv_path = tmp_path / "data.csv"
    csv_path.write_text("id,value\n1,hello\n2,world\n")
    info = DatasetInfo(name="data", path=csv_path, format=FileFormat.CSV)
    df = read_dataset(info)
    assert len(df) == 2
    assert list(df.columns) == ["id", "value"]


def test_read_csv_with_sample(tmp_path: Path):
    csv_path = tmp_path / "data.csv"
    csv_path.write_text("id\n1\n2\n3\n4\n5\n")
    info = DatasetInfo(name="data", path=csv_path, format=FileFormat.CSV)
    df = read_dataset(info, sample_rows=2)
    assert len(df) == 2


def test_read_sqlite(tmp_path: Path):
    db_path = tmp_path / "test.sqlite"
    conn = sqlite3.connect(str(db_path))
    conn.execute("CREATE TABLE items (id INTEGER, name TEXT)")
    conn.execute("INSERT INTO items VALUES (1, 'widget')")
    conn.execute("INSERT INTO items VALUES (2, 'gadget')")
    conn.commit()
    conn.close()

    info = DatasetInfo(name="items", path=db_path, format=FileFormat.SQLITE, table_name="items")
    df = read_dataset(info)
    assert len(df) == 2


def test_read_parquet(tmp_path: Path):
    parquet_path = tmp_path / "data.parquet"
    df_orig = pd.DataFrame({"a": [1, 2, 3], "b": ["x", "y", "z"]})
    df_orig.to_parquet(parquet_path, index=False)

    info = DatasetInfo(name="data", path=parquet_path, format=FileFormat.PARQUET)
    df = read_dataset(info)
    assert len(df) == 3
    assert set(df.columns) == {"a", "b"}
