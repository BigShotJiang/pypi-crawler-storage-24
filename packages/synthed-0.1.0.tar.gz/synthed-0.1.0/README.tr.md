# Synthed

**Gizlilik odaklı sentetik veri üretim aracı.**

Synthed, yerel veri setlerini tarar, yapı ve davranışlarını çıkarır, taşınabilir bir üretim spesifikasyonu oluşturur ve orijinal kayıtları kopyalamadan gerçekçi sentetik veriler üretir.

> **Uyarı:** Bu araç gizlilik riskini azaltır ancak otomatik olarak yasal anonimleştirme sağlamaz. Kullanıcılar, geçerli veri koruma düzenlemelerine uyumdan sorumludur.

## Hızlı Başlangıç

```bash
# Kurulum
pip install -e ".[dev]"

# Tüm pipeline'ı örnek veri üzerinde çalıştır
synthed run-pipeline ./examples/sample_data --out ./artifacts --seed 42

# Veya adım adım:
synthed scan ./examples/sample_data
synthed build-spec ./examples/sample_data --out ./artifacts/spec
synthed generate --spec ./artifacts/spec/spec.yaml --out ./artifacts/generated --seed 42
synthed evaluate --real ./examples/sample_data --synthetic ./artifacts/generated --out ./artifacts/report
```

## CLI Komutları

| Komut | Açıklama |
|-------|----------|
| `scan` | Dizindeki veri setlerini keşfet |
| `profile` | Veri setlerini profille ve istatistikleri çıkar |
| `build-spec` | Taşınabilir sentetik veri spesifikasyonu oluştur |
| `generate` | Spesifikasyondan sentetik veri üret |
| `evaluate` | Sentetik veriyi gerçek veriyle karşılaştır |
| `run-pipeline` | Tüm pipeline'ı uçtan uca çalıştır |

## Nasıl Çalışır

1. **Tara** — CSV, Parquet ve SQLite dosyalarını keşfeder
2. **Profille** — İstatistikler, desenler ve dağılımlar toplar
3. **Çıkarım Yap** — Semantik tipler, birincil/yabancı anahtarlar, kısıtlamalar tespit eder
4. **Spec Oluştur** — Veriyi tanımlayan taşınabilir YAML spesifikasyonu üretir
5. **Üret** — Kural tabanlı üretecilerle sentetik veri oluşturur
6. **Değerlendir** — Doğruluk, kullanılabilirlik ve gizlilik riskini ölçer

## Mimari

```
src/synthed/
├── cli/          # CLI uygulaması (Typer)
├── config/       # Yapılandırma modelleri (Pydantic)
├── io/           # Dosya keşfi ve okuyucular
├── profiling/    # Sütun/tablo profilleme
├── inference/    # Semantik tip ve ilişki çıkarımı
├── constraints/  # Katı/esnek kısıtlama çıkarımı
├── spec/         # Spec modelleri ve oluşturucu
├── generation/   # Sentetik veri üreteçleri
├── evaluation/   # Doğruluk ve kalite metrikleri
├── privacy/      # Gizlilik risk kontrolleri
├── export/       # Çıktı yazıcıları (CSV, Parquet, SQLite, YAML, JSON)
├── reporting/    # Rapor oluşturucu
└── utils/        # Loglama, tip tanımları
```

## Gizlilik Kontrolleri

- **Tam satır eşleşme tespiti** — Sentetik satırların gerçek satırlarla eşleşip eşleşmediğini kontrol eder
- **Yüksek riskli tanımlayıcı yeniden üretimi** — ID, anahtar ve KKV sütunları yeniden üretilir
- **Nadir grup sızıntı tespiti** — Yapılandırılabilir eşik değerinin altındaki grupları işaretler
- **Küçük veri seti uyarıları** — 100 satırın altındaki veri setleri için ekstra dikkat
- **Gizlilik raporu** — Her çalıştırmada otomatik olarak üretilir

## Desteklenen Formatlar

- Girdi: CSV, Parquet, SQLite
- Çıktı: CSV, Parquet, SQLite
- Spec: YAML

## Geliştirme

```bash
pip install -e ".[dev]"
pytest
ruff check src/ tests/
mypy src/
```

## Kullanım Alanları

- ETL geliştirme
- Özellik mühendisliği
- Model prototipleme
- SQL testi
- Dashboard/sorgu testi
- Pipeline hata ayıklama

## Bilinen Kısıtlamalar

- V1 yalnızca tablo/ilişkisel veriyi destekler (görüntü, PDF, serbest metin yok)
- Metin üreteci rastgele karakter dizileri üretir (dilsel gerçekçilik yok)
- İstatistiksel üreteçler kural tabanlıdır, ML tabanlı değil
- FK çıkarımı buluşsal yöntemlerle çalışır (isim eşleştirme + değer örtüşmesi)
- Yasal anonimleştirme garantisi sağlamaz
- Tamsayı sütunları ondalıklı sayı olarak üretilebilir

## Lisans

MIT
