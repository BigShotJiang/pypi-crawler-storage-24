from __future__ import annotations

import ast
from typing import List, Optional, Tuple

from .models import Endpoint

_FASTAPI_METHODS = {"get", "post", "put", "delete", "patch", "options", "head"}


def _get_str(node: ast.AST) -> Optional[str]:
    if isinstance(node, ast.Constant) and isinstance(node.value, str):
        return node.value
    return None


def _call_name(expr: ast.AST) -> Tuple[Optional[str], Optional[str]]:
    if isinstance(expr, ast.Call):
        func = expr.func
        if isinstance(func, ast.Attribute) and isinstance(func.value, ast.Name):
            return func.value.id, func.attr
    return None, None


def _extract_flask_methods(dec_call: ast.Call) -> List[str]:
    for kw in dec_call.keywords:
        if kw.arg == "methods" and isinstance(kw.value, (ast.List, ast.Tuple)):
            ms: List[str] = []
            for el in kw.value.elts:
                s = _get_str(el)
                if s:
                    ms.append(s.upper())
            return sorted(set(ms)) if ms else ["GET"]
    return ["GET"]


def extract_python_endpoints(py_source: str, file_path: str) -> List[Endpoint]:
    try:
        tree = ast.parse(py_source)
    except SyntaxError:
        return []

    endpoints: List[Endpoint] = []

    for node in ast.walk(tree):
        if not isinstance(node, ast.FunctionDef):
            continue

        if not node.decorator_list:
            continue

        handler = node.name

        for dec in node.decorator_list:
            if not isinstance(dec, ast.Call):
                continue

            obj, meth = _call_name(dec)
            if not obj or not meth:
                continue

            # path is usually first arg
            pnode = dec.args[0] if dec.args else None
            path = _get_str(pnode) if pnode else None
            if not path or not path.startswith("/"):
                continue

            low = meth.lower()

            # FastAPI: @app.get("/x") / @router.post("/x")
            if low in _FASTAPI_METHODS:
                endpoints.append(
                    Endpoint(
                        method=low.upper(),
                        path=path,
                        file=file_path,
                        line=getattr(dec, "lineno", getattr(node, "lineno", 1)),
                        handler=handler,
                        framework="fastapi",
                    )
                )
                continue

            # Flask: @app.route("/x", methods=[...])
            if low == "route":
                ms = _extract_flask_methods(dec)
                for m in ms:
                    endpoints.append(
                        Endpoint(
                            method=m,
                            path=path,
                            file=file_path,
                            line=getattr(dec, "lineno", getattr(node, "lineno", 1)),
                            handler=handler,
                            framework="flask",
                        )
                    )

    return endpoints