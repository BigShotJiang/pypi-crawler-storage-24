from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Iterable, Optional

# Optional: pip install pathspec
try:
    import pathspec  # type: ignore
except Exception:  # pragma: no cover
    pathspec = None

from ..core.project import find_project_root, SKIP_DIRS
# NOTE: duplicated here to avoid circular import:
# endpoints.scan -> tree_cmd -> endpoints_cmd -> endpoints.scan
DEFAULT_IGNORE_NAMES = {
    '.git', '.idea', '.vscode', '.mvn',
    '__pycache__', '.pytest_cache', '.ruff_cache', '.tox',
    '.venv', 'venv', 'env',
    'node_modules', 'dist', 'build', 'out', 'target', '.gradle',
}

@dataclass(frozen=True)
class EndpointScanOptions:
    show_hidden: bool
    use_gitignore: bool


def _is_hidden_name(name: str) -> bool:
    return name.startswith(".")


def _load_gitignore_spec(root: Path):
    if pathspec is None:
        return None
    gi = root / ".gitignore"
    if not gi.exists():
        return None

    lines: list[str] = []
    for line in gi.read_text(encoding="utf-8", errors="ignore").splitlines():
        s = line.strip()
        if not s or s.startswith("#"):
            continue
        lines.append(s)

    if not lines:
        return None
    return pathspec.PathSpec.from_lines("gitwildmatch", lines)


def _gitignore_matches(spec, rel_posix: str, is_dir: bool) -> bool:
    if spec is None:
        return False
    if spec.match_file(rel_posix):
        return True
    if is_dir and spec.match_file(rel_posix.rstrip("/") + "/"):
        return True
    return False


def _is_skipped(p: Path, root: Path, spec, opts: EndpointScanOptions) -> bool:
    name = p.name

    # reuse your directory skip policy + tree ignores
    if any(part in SKIP_DIRS for part in p.parts):
        return True
    if name in DEFAULT_IGNORE_NAMES:
        return True

    if _is_hidden_name(name) and not opts.show_hidden:
        return True

    if opts.use_gitignore and spec is not None:
        try:
            rel = p.relative_to(root).as_posix()
        except Exception:
            rel = p.as_posix()
        if _gitignore_matches(spec, rel, p.is_dir()):
            return True

    return False


def iter_supported_source_files(start: Path, opts: EndpointScanOptions) -> Iterable[Path]:
    start = start.resolve()
    project_root = find_project_root(start)
    spec = _load_gitignore_spec(project_root) if opts.use_gitignore else None

    # manual walk so we can prune dirs early
    stack = [project_root]
    while stack:
        cur = stack.pop()
        if _is_skipped(cur, project_root, spec, opts):
            continue
        try:
            entries = list(cur.iterdir())
        except Exception:
            continue

        for e in entries:
            if _is_skipped(e, project_root, spec, opts):
                continue
            if e.is_dir():
                stack.append(e)
            elif e.is_file():
                if e.suffix.lower() in {".java", ".py"}:
                    yield e.resolve()