﻿from __future__ import annotations

import re
from fnmatch import fnmatch
from typing import List, Tuple, Optional, Set

from .models import Endpoint

_MAPPING_ANN = {
    "GetMapping",
    "PostMapping",
    "PutMapping",
    "DeleteMapping",
    "PatchMapping",
    "RequestMapping",
}

_ANNOT_RE = re.compile(r"@\s*([A-Za-z_]\w*)\s*(\((.*?)\))?", re.DOTALL)
_CLASS_RE = re.compile(r"\b(class|record)\s+([A-Za-z_]\w*)\b")
_METHOD_RE = re.compile(r"(public|protected|private)?\s*(static\s+)?[\w<>\[\], ?]+\s+([A-Za-z_]\w*)\s*\(")

_PREAUTHORIZE_RE = re.compile(r'@PreAuthorize\s*\(\s*"([^"]+)"\s*\)')
_SECURED_RE = re.compile(r"@Secured\s*\((.*?)\)")
_ROLESALLOWED_RE = re.compile(r"@RolesAllowed\s*\((.*?)\)")

_HASROLE_RE = re.compile(r"hasRole\s*\(\s*'([^']+)'\s*\)")
_HASANYROLE_RE = re.compile(r"hasAnyRole\s*\(\s*([^\)]+)\)")

_HASAUTHORITY_RE = re.compile(r"hasAuthority\s*\(\s*'([^']+)'\s*\)")
_HASANYAUTHORITY_RE = re.compile(r"hasAnyAuthority\s*\(\s*([^\)]+)\)")


def _extract_paths(arg_str: str) -> List[str]:
    s = arg_str or ""
    named = re.findall(r'\b(?:value|path)\s*=\s*"([^"]+)"', s)
    if named:
        return named
    named_arr = re.search(r'\b(?:value|path)\s*=\s*\{([^}]+)\}', s, re.DOTALL)
    if named_arr:
        return re.findall(r'"([^"]+)"', named_arr.group(1))
    positional = re.findall(r'"([^"]+)"', s)
    if positional:
        return [positional[0]]
    return []


def _normalize_join(base: str, sub: str) -> str:
    if not base:
        result = sub or "/"
        return result if result.startswith("/") else "/" + result
    if not sub:
        return base if base.startswith("/") else "/" + base
    if base.endswith("/") and sub.startswith("/"):
        return base[:-1] + sub
    if not base.endswith("/") and not sub.startswith("/"):
        return base + "/" + sub
    result = base + sub
    return result if result.startswith("/") else "/" + result


def _methods_from_annotation(ann: str, args: str) -> List[str]:
    ann = ann.lower()
    if ann == "getmapping":
        return ["GET"]
    if ann == "postmapping":
        return ["POST"]
    if ann == "putmapping":
        return ["PUT"]
    if ann == "deletemapping":
        return ["DELETE"]
    if ann == "patchmapping":
        return ["PATCH"]
    if ann == "requestmapping":
        return re.findall(r"RequestMethod\.([A-Z]+)", args or "")
    return []


def _roles_from_expr(expr: str) -> Set[str]:
    roles: Set[str] = set()
    for m in _HASROLE_RE.finditer(expr):
        roles.add(m.group(1))
    for m in _HASANYROLE_RE.finditer(expr):
        for r in re.findall(r"'([^']+)'", m.group(1)):
            roles.add(r)
    for m in _HASAUTHORITY_RE.finditer(expr):
        r = m.group(1)
        if r.startswith("ROLE_"):
            r = r[5:]
        roles.add(r)
    for m in _HASANYAUTHORITY_RE.finditer(expr):
        for r in re.findall(r"'([^']+)'", m.group(1)):
            if r.startswith("ROLE_"):
                r = r[5:]
            roles.add(r)
    return roles


def _roles_from_strings(arg: str) -> Set[str]:
    out: Set[str] = set()
    for s in re.findall(r'"([^"]+)"', arg or ""):
        if s.startswith("ROLE_"):
            s = s[5:]
        out.add(s)
    return out


def _extract_roles_block(text: str) -> Set[str]:
    roles: Set[str] = set()
    for m in _PREAUTHORIZE_RE.finditer(text):
        roles |= _roles_from_expr(m.group(1))
    for m in _SECURED_RE.finditer(text):
        roles |= _roles_from_strings(m.group(1))
    for m in _ROLESALLOWED_RE.finditer(text):
        roles |= _roles_from_strings(m.group(1))
    return roles


def _ant_to_fnmatch(p: str) -> str:
    return (p or "").replace("**", "*")


def _matches_permit_all(path: str, permit_all: Optional[List[str]]) -> bool:
    for pat in permit_all or []:
        if fnmatch(path, _ant_to_fnmatch(pat)):
            return True
    return False


def _is_common_public_auth_path(path: str) -> bool:
    return path.startswith("/auth") or path.startswith("/api/auth/") or path.startswith("/api/authenticate")


def extract_spring_endpoints(
    java_source: str,
    file_path: str,
    *,
    default_auth: bool = False,
    permit_all: Optional[List[str]] = None,
) -> List[Endpoint]:
    endpoints: List[Endpoint] = []
    lines = java_source.splitlines()

    mcls = _CLASS_RE.search(java_source)
    if not mcls:
        return []

    class_pos = mcls.start()
    controller = mcls.group(2)
    pre = java_source[:class_pos]

    if "@RestController" not in pre and "@Controller" not in pre:
        return []

    base_path = ""
    for m in _ANNOT_RE.finditer(pre):
        if m.group(1) == "RequestMapping":
            ps = _extract_paths(m.group(3) or "")
            if ps:
                base_path = ps[0] if ps[0].startswith("/") else "/" + ps[0]

    class_roles = _extract_roles_block(pre)
    pending: List[Tuple[str, str, int]] = []

    for i, line in enumerate(lines, start=1):
        s = line.strip()

        if s.startswith("@"):
            am = _ANNOT_RE.search(s)
            if am and am.group(1) in _MAPPING_ANN:
                pending.append((am.group(1), am.group(3) or "", i))
            continue

        mm = _METHOD_RE.search(s)
        if mm and pending:
            handler = mm.group(3)

            j = i - 2
            buf: list[str] = []
            while j >= 0:
                s2 = (lines[j] or "").strip()
                if not s2:
                    j -= 1
                    continue
                if s2.startswith("@"):
                    buf.append(lines[j])
                    j -= 1
                    continue
                break

            method_roles = _extract_roles_block("\n".join(reversed(buf)))
            roles = class_roles | method_roles

            for ann, args, ln in pending:
                for meth in _methods_from_annotation(ann, args):
                    paths = _extract_paths(args) or [""]
                    for p in paths:
                        full = _normalize_join(base_path, p)
                        final_roles: Optional[Set[str]] = roles or None
                        if not final_roles:
                            if _matches_permit_all(full, permit_all) or _is_common_public_auth_path(full):
                                final_roles = None
                            elif default_auth:
                                final_roles = {"AUTH"}
                            else:
                                final_roles = None

                        endpoints.append(
                            Endpoint(
                                method=meth,
                                path=full,
                                file=file_path,
                                line=ln,
                                handler=handler,
                                framework="spring",
                                controller=controller,
                                roles=final_roles,
                            )
                        )
            pending = []

    return endpoints