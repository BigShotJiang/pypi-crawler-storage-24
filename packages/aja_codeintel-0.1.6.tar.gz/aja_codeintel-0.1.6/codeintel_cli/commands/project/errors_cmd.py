﻿from __future__ import annotations

import re
import subprocess
import time
from pathlib import Path
from typing import Optional

import typer

from ...core.project import find_project_root
from ...scanner.scanner import find_all_supported_files
from ...db.cache import CacheManager


# ─────────────────────────── helpers ────────────────────────────

def _find_maven_cmd(root: Path) -> str:
    for name in ["mvnw.cmd", "mvnw"]:
        if (root / name).exists():
            return str(root / name)
    return "mvn"


def _changed_files(project_root: Path) -> list[Path]:
    """Return java files modified since last scan."""
    try:
        cache = CacheManager(project_root)
        cached = {Path(p) for p in cache.get_cached_files()}
        changed = []
        for p in cached:
            if not p.exists():
                continue
            db_mtime = cache.get_file_mtime(p)
            if db_mtime is None or p.stat().st_mtime > db_mtime:
                changed.append(p)
        return changed
    except Exception:
        return []


# ─────────────────────── mvn compile errors ─────────────────────

_MVN_ERROR_RE = re.compile(
    r'^\[ERROR\]\s+(.+?\.java):\[(\d+),\d+\]\s+(.+)$'
)
_MVN_WARNING_RE = re.compile(
    r'^\[WARNING\]\s+(.+?\.java):\[(\d+),\d+\]\s+(.+)$'
)


def _run_mvn_compile(project_root: Path) -> tuple[list[dict], list[dict]]:
    mvn = _find_maven_cmd(project_root)
    try:
        result = subprocess.run(
            f'"{mvn}" compile -q --batch-mode',
            cwd=str(project_root),
            capture_output=True,
            text=True,
            shell=True,
            timeout=120,
        )
        output = result.stdout + result.stderr
    except subprocess.TimeoutExpired:
        return [], [{"file": "?", "line": "?", "msg": "mvn compile timed out after 120s"}]
    except Exception as e:
        return [], [{"file": "?", "line": "?", "msg": str(e)}]

    errors: list[dict] = []
    warnings: list[dict] = []
    for line in output.splitlines():
        m = _MVN_ERROR_RE.match(line.strip())
        if m:
            errors.append({"file": Path(m.group(1)).name, "line": m.group(2), "msg": m.group(3).strip()})
            continue
        m = _MVN_WARNING_RE.match(line.strip())
        if m:
            warnings.append({"file": Path(m.group(1)).name, "line": m.group(2), "msg": m.group(3).strip()})
    return errors, warnings


# ──────────────────────── static analysis ───────────────────────

# Patterns: (regex, message, severity)
_STATIC_CHECKS: list[tuple[re.Pattern, str, str]] = [
    # Empty catch block
    (re.compile(r'catch\s*\([^)]+\)\s*\{\s*\}'), "Empty catch block swallows exception", "warning"),
    # Null dereference risk: .get() without check
    (re.compile(r'\.get\(\)\s*\.'), "Possible null dereference after .get()", "warning"),
    # Syso debug prints left in
    (re.compile(r'System\.out\.print'), "Debug System.out.print left in code", "warning"),
    # TODO/FIXME left in
    (re.compile(r'//\s*(TODO|FIXME|HACK|XXX)\b'), "Unresolved TODO/FIXME comment", "info"),
    # Catching raw Exception
    (re.compile(r'catch\s*\(\s*Exception\s+\w+\s*\)'), "Catching raw Exception — too broad", "warning"),
    # Unused import hint (simple heuristic)
    (re.compile(r'^import\s+java\.util\.(Vector|Hashtable|Stack)\s*;', re.MULTILINE), "Outdated collection type import", "info"),
    # Magic numbers (not 0/1/-1)
    (re.compile(r'(?<![.\w])[2-9]\d{2,}(?![.\w])'), "Magic number — consider named constant", "info"),
    # String == comparison
    (re.compile(r'==\s*"[^"]*"'), 'String compared with == instead of .equals()', "error"),
    # Mutable static field
    (re.compile(r'static\s+(?!final)\w+\s+\w+\s*='), "Mutable static field — potential concurrency issue", "warning"),
    # NullPointerException throw without message
    (re.compile(r'throw\s+new\s+NullPointerException\s*\(\s*\)'), "NullPointerException thrown without message", "warning"),
]

_SKIP_DIRS = {"target", "build", ".git", "test", "tests"}


def _static_analyze(files: list[Path]) -> list[dict]:
    issues: list[dict] = []
    for f in files:
        if any(part in _SKIP_DIRS for part in f.parts):
            continue
        try:
            lines = f.read_text(encoding="utf-8", errors="ignore").splitlines()
        except Exception:
            continue
        for lineno, line in enumerate(lines, 1):
            stripped = line.strip()
            if stripped.startswith("//") and not re.match(r'//\s*(TODO|FIXME)', stripped):
                continue  # skip pure comment lines except TODO/FIXME
            for pattern, msg, severity in _STATIC_CHECKS:
                if pattern.search(line):
                    issues.append({
                        "file": f.name,
                        "line": str(lineno),
                        "msg": msg,
                        "severity": severity,
                    })
                    break  # one issue per line
    return issues


# ────────────────────────── renderer ────────────────────────────

_SEV_ORDER = {"error": 0, "warning": 1, "info": 2}
_SEV_LABEL = {"error": "ERROR", "warning": "WARN ", "info": "INFO "}


def _render(
    compile_errors: list[dict],
    compile_warnings: list[dict],
    static_issues: list[dict],
) -> list[str]:
    out: list[str] = []
    total = len(compile_errors) + len(compile_warnings) + len(static_issues)

    if total == 0:
        return ["✓ No issues found."]

    # ── Compile errors
    if compile_errors:
        out.append(f"COMPILE ERRORS ({len(compile_errors)})")
        out.append("─" * 60)
        for e in compile_errors:
            pad = max(0, 30 - len(e["file"]))
            out.append(f"  {e['file']}{' '*pad} line {e['line']:<6}  {e['msg']}")
        out.append("")

    # ── Compile warnings
    if compile_warnings:
        out.append(f"COMPILE WARNINGS ({len(compile_warnings)})")
        out.append("─" * 60)
        for w in compile_warnings:
            pad = max(0, 30 - len(w["file"]))
            out.append(f"  {w['file']}{' '*pad} line {w['line']:<6}  {w['msg']}")
        out.append("")

    # ── Static issues grouped by severity
    if static_issues:
        static_issues.sort(key=lambda x: (_SEV_ORDER.get(x["severity"], 9), x["file"], int(x["line"])))
        by_sev: dict[str, list[dict]] = {}
        for i in static_issues:
            by_sev.setdefault(i["severity"], []).append(i)
        for sev in ("error", "warning", "info"):
            group = by_sev.get(sev, [])
            if not group:
                continue
            label = {"error": "STATIC ERRORS", "warning": "STATIC WARNINGS", "info": "STATIC INFO"}[sev]
            out.append(f"{label} ({len(group)})")
            out.append("─" * 60)
            for i in group:
                pad = max(0, 30 - len(i["file"]))
                out.append(f"  {i['file']}{' '*pad} line {i['line']:<6}  {i['msg']}")
            out.append("")

    out.append(f"{'─'*60}")
    out.append(f"  Total: {len(compile_errors)} compile error(s), {len(compile_warnings)} compile warning(s), {len(static_issues)} static issue(s)")
    return out


# ─────────────────────────── command ────────────────────────────

def register_errors(app: typer.Typer) -> None:
    @app.command("errors", help="Show compile errors + static analysis issues.")
    def errors(
        path: str = typer.Argument(".", help="Project root folder"),
        changed_only: bool = typer.Option(False, "--changed-only", "-c", help="Only scan files changed since last aja scan"),
        skip_compile: bool = typer.Option(False, "--skip-compile", help="Skip mvn compile, only run static analysis"),
        skip_static: bool = typer.Option(False, "--skip-static", help="Skip static analysis, only run mvn compile"),
        verbose: bool = typer.Option(False, "--verbose", "-v", help="Show INFO level issues"),
    ) -> None:
        t0 = time.perf_counter()
        project_root = find_project_root(Path(path).resolve())

        # Collect files for static analysis
        if changed_only:
            java_files = _changed_files(project_root)
            typer.echo(f"Scanning {len(java_files)} changed file(s)...")
        else:
            java_files = [
                f for f in find_all_supported_files(project_root)
                if f.suffix.lower() == ".java"
            ]
            typer.echo(f"Scanning {len(java_files)} Java file(s)...")
        typer.echo("")

        compile_errors: list[dict] = []
        compile_warnings: list[dict] = []
        static_issues: list[dict] = []

        if not skip_compile:
            typer.echo("Running mvn compile...")
            compile_errors, compile_warnings = _run_mvn_compile(project_root)

        if not skip_static:
            static_issues = _static_analyze(java_files)
            if not verbose:
                static_issues = [i for i in static_issues if i["severity"] != "info"]

        for line in _render(compile_errors, compile_warnings, static_issues):
            typer.echo(line)

        elapsed = time.perf_counter() - t0
        typer.echo(f"\nFinished in {elapsed:.3f}s")

