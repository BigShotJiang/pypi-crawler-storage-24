﻿from __future__ import annotations

import time
from collections import defaultdict
from dataclasses import dataclass
from pathlib import Path
import typer

from ...errors import InvalidPathError
from ...core.project import find_project_root
from ...scanner.scanner import find_all_supported_files
from ...endpoints.scan import EndpointScanOptions, iter_supported_source_files
from ...endpoints.java_spring import extract_spring_endpoints
from ...endpoints.openapi_spec import extract_openapi_endpoints
from .endpoints_cmd import _detect_spring_security_policy, _norm_path, _display_role_str
from .models_cmd import _import_extractors, _is_model_path
from . import types_cmd as tcmd
from ...context.java_rel import java_fields_and_rels, top_type_name


@dataclass(frozen=True)
class RelEdge:
    src: str
    kind: str
    field: str
    target: str


def _validate_folder(path: str) -> Path:
    folder = Path(path).resolve()
    if not folder.exists() or not folder.is_dir():
        raise InvalidPathError(message="Invalid folder", path=folder)
    return folder


def _print_header(title: str) -> None:
    typer.echo("")
    typer.echo(title)
    typer.echo("-" * len(title))


def _is_basic_type(name: str) -> bool:
    n = (name or "").strip()
    if not n:
        return True
    basics = {
        "String","Long","Integer","int","long","double","Double",
        "float","Float","boolean","Boolean","UUID","BigDecimal",
        "Date","LocalDate","LocalDateTime","Instant","Object",
    }
    return n in basics


def _scan_models(project_root: Path) -> list[str]:
    _, extract_java_models = _import_extractors()
    files = find_all_supported_files(project_root)
    candidates: list[Path] = []
    pr = project_root.resolve()
    for f in files:
        fr = f.resolve()
        try:
            rel = fr.relative_to(pr)
        except Exception:
            continue
        if _is_model_path(rel):
            candidates.append(fr)
    out: list[str] = []
    for f in sorted(candidates, key=lambda x: str(x).lower()):
        if f.suffix.lower() != ".java" or extract_java_models is None:
            continue
        defs = extract_java_models(f, project_root)
        for d in defs:
            out.append(f"{d.name}  ({d.kind})  {d.file}")
            for fld in d.fields:
                out.append(f"  - {fld.name}: {fld.type}")
    return out


def _scan_relationships(project_root: Path) -> tuple[list[RelEdge], dict[str, int], dict[str, list[RelEdge]]]:
    files = find_all_supported_files(project_root)
    candidates: list[Path] = []
    pr = project_root.resolve()
    for f in files:
        if f.suffix.lower() != ".java":
            continue
        fr = f.resolve()
        try:
            rel = fr.relative_to(pr)
        except Exception:
            continue
        if _is_model_path(rel):
            candidates.append(fr)
    edges: list[RelEdge] = []
    counts: dict[str, int] = defaultdict(int)
    per_src: dict[str, list[RelEdge]] = defaultdict(list)
    for f in sorted(candidates, key=lambda x: str(x).lower()):
        try:
            raw = f.read_text(encoding="utf-8", errors="ignore")
        except Exception:
            continue
        src_type = top_type_name(raw, fallback=f.stem)
        _fields, rels = java_fields_and_rels(f)
        for r in rels:
            tgt = (r.target or "").strip()
            if not tgt or _is_basic_type(tgt):
                continue
            e = RelEdge(src=src_type, kind=r.kind, field=r.field, target=tgt)
            edges.append(e)
            counts[r.kind] += 1
            per_src[src_type].append(e)
    edges.sort(key=lambda e: (e.src.lower(), e.kind, e.field.lower(), e.target.lower()))
    for k in list(per_src.keys()):
        per_src[k].sort(key=lambda e: (e.kind, e.field.lower(), e.target.lower()))
    return edges, dict(counts), dict(per_src)


def _scan_types(project_root: Path) -> list[str]:
    root = project_root
    java_files: list[Path] = []
    for f in tcmd._walk_files(root):
        if tcmd._is_java_dto(f):
            java_files.append(f)
    java_files.sort(key=lambda p: tcmd._rel(p, root).lower())
    java_items: list[dict] = []
    for f in java_files[:500]:
        src = tcmd._read_text_limited(f, max_kb=256)
        rel = tcmd._rel(f, root)
        for parser in (tcmd._parse_java_record, tcmd._parse_java_interface_projection, tcmd._parse_java_class_fields):
            parsed = parser(src)
            if parsed:
                name, fields, tag = parsed
                kind = tcmd._classify_java(rel, name)
                java_items.append({"kind": kind, "name": name, "fields": fields, "tag": tag})
                break
    out: list[str] = []
    if java_items:
        req   = [x for x in java_items if x["kind"] == "request"]
        res   = [x for x in java_items if x["kind"] == "response"]
        other = [x for x in java_items if x["kind"] == "other"]
        out.append(f"JAVA DTO SUMMARY ({len(java_items)})")
        for label, group in (("REQUEST", req), ("RESPONSE", res), ("OTHER", other)):
            if not group: continue
            out.append(f"  {label} ({len(group)})")
            for x in group:
                flds = ", ".join(x["fields"]) if x["fields"] else "(no fields)"
                out.append(f"  • {x['name']}: {flds}")
    if not out:
        out.append("(no DTO-like types found)")
    return out


def _scan_endpoints(project_root: Path) -> list[str]:
    opts = EndpointScanOptions(show_hidden=False, use_gitignore=True)
    t0 = time.perf_counter()
    all_eps = []
    files = list(iter_supported_source_files(project_root, opts))
    files_for_security = [
        f for f in files
        if not any(x in _norm_path(str(f)).lower() for x in ("/src/test/", "/target/", "/build/"))
    ]
    default_auth, permit_all = _detect_spring_security_policy(files_for_security)
    for f in files:
        if f.suffix.lower() != ".java":
            continue
        try:
            src = f.read_text(encoding="utf-8", errors="ignore")
        except Exception:
            continue
        all_eps.extend(extract_spring_endpoints(src, str(f), default_auth=default_auth, permit_all=permit_all))
    if not any(e.framework == "spring" for e in all_eps):
        all_eps.extend(extract_openapi_endpoints(project_root))
    filtered = [
        e for e in all_eps
        if "/src/test/" not in _norm_path(e.file)
        and ("/src/main/" in _norm_path(e.file) or "/main/" in _norm_path(e.file))
    ]
    seen: set[tuple[str,str]] = set()
    uniq = []
    for e in filtered:
        key = (e.method, e.path)
        if key not in seen:
            seen.add(key)
            uniq.append(e)
    uniq.sort(key=lambda e: (e.path, e.method))
    elapsed = time.perf_counter() - t0
    out: list[str] = [f"Found {len(uniq)} endpoints in {elapsed:.3f}s", ""]
    methods_by_path: dict[str, set[str]] = defaultdict(set)
    roles_by_key: dict[tuple[str,str], set[str]] = defaultdict(set)
    for e in uniq:
        methods_by_path[e.path].add(e.method)
        if e.roles:
            roles_by_key[(e.path, e.method)].update(e.roles)
    for idx, p in enumerate(sorted(methods_by_path.keys()), 1):
        methods = sorted(methods_by_path[p])
        parts = [f"{m}{_display_role_str(p, roles_by_key.get((p,m),set()), default_auth=default_auth, permit_all=permit_all)}" for m in methods]
        out.append(f"{idx:02d}. {p}  [{', '.join(parts)}]")
    return out


def register_overview(app: typer.Typer) -> None:
    @app.command("overview", help="Single summary: models + relationships + DTO/types + endpoints.")
    def overview(
        path: str = typer.Argument(".", help="Project root folder"),
        show_edges: bool = typer.Option(True, "--show-edges/--no-edges"),
        max_edges: int = typer.Option(200, "--max-edges"),
    ) -> None:
        folder = _validate_folder(path)
        project_root = find_project_root(folder)
        typer.echo("=" * 80)
        typer.echo("CODEINTEL OVERVIEW")
        typer.echo("=" * 80)
        typer.echo(f"ROOT: {project_root}")

        _print_header("MODELS")
        models_out = _scan_models(project_root)
        for line in (models_out or ["No domain models found."]):
            typer.echo(line)

        _print_header("RELATIONSHIPS")
        edges, counts, per_src = _scan_relationships(project_root)
        total = sum(counts.values())
        if total == 0:
            typer.echo("No relationships found.")
        else:
            typer.echo("Counts:")
            for k in sorted(counts.keys()):
                typer.echo(f"  {k}: {counts[k]}")
            typer.echo(f"  TOTAL: {total}")
            typer.echo("")
            typer.echo("Per Model:")
            for src in sorted(per_src.keys(), key=lambda s: s.lower()):
                typer.echo(f"  {src}:")
                for e in per_src[src][:50]:
                    typer.echo(f"    - {e.kind} {e.field} -> {e.target}")
            if show_edges:
                typer.echo("")
                typer.echo("Edges:")
                for i, e in enumerate(edges):
                    if i >= max_edges:
                        typer.echo(f"  ... ({len(edges)-i} more)")
                        break
                    typer.echo(f"  {e.src} --[{e.kind}]({e.field})--> {e.target}")

        _print_header("DTO / TYPES")
        for line in _scan_types(project_root):
            typer.echo(line)

        _print_header("ENDPOINTS")
        for line in _scan_endpoints(project_root):
            typer.echo(line)


