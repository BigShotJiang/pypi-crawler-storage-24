﻿# codeintel_cli/commands/project/endpoints_cmd.py
from __future__ import annotations

import json
import re
import time
from collections import defaultdict
from fnmatch import fnmatch
from pathlib import Path

import typer

from ...core.project import find_project_root
from ...endpoints.java_spring import extract_spring_endpoints
from ...endpoints.python_web import extract_python_endpoints
from ...endpoints.scan import EndpointScanOptions, iter_supported_source_files
from ...endpoints.openapi_spec import extract_openapi_endpoints  # NEW
from ...errors import InvalidPathError


def _validate_folder(path: str) -> Path:
    folder = Path(path).resolve()
    if not folder.exists() or not folder.is_dir():
        raise InvalidPathError(message="Invalid folder", path=folder)
    return folder


def _norm_path(p: str) -> str:
    return p.replace("\\", "/")


_ANYREQ_AUTH_RE = re.compile(r"\.anyRequest\s*\(\s*\)\s*\.authenticated\s*\(\s*\)")
_LAST_SECURITY_CANDIDATES: list[str] = []

# JHipster / modern Spring Security style:
#   .requestMatchers("/api/**").authenticated()
#   .requestMatchers("/api/admin/**").hasAuthority(...)
_MATCHERS_AUTHZ_RE = re.compile(
    r"\.(requestMatchers|antMatchers|mvcMatchers)\s*\(\s*([^\)]*?)\)\s*\.\s*(authenticated|hasRole|hasAuthority)\s*\(",
    re.DOTALL,
)


def _extract_strings(text: str) -> list[str]:
    return re.findall(r'"([^"]+)"', text or "")


def _ant_to_fnmatch(p: str) -> str:
    return (p or "").replace("**", "*")


def _matches_any(path: str, patterns: list[str]) -> bool:
    for pat in patterns or []:
        if fnmatch(path, _ant_to_fnmatch(pat)):
            return True
    return False


def _detect_spring_security_policy(files: list[Path]) -> tuple[bool, list[str]]:
    global _LAST_SECURITY_CANDIDATES
    """
    default_auth:
      - detects anyRequest().authenticated()
      - detects requestMatchers(...).authenticated/hasRole/hasAuthority
      - JHipster fallback: if any security config is found, assume API is secured by default
    permit_all:
      - detects requestMatchers(...).permitAll() and extracts only those patterns
    """
    default_auth = False
    permit_all: list[str] = []
    _LAST_SECURITY_CANDIDATES = []
    found_security_config = False

    # Exact match: .requestMatchers(...).permitAll()
    _MATCHERS_PERMITALL_RE = re.compile(
        r"\.(requestMatchers|antMatchers|mvcMatchers)\s*\(\s*([^\)]*?)\)\s*\.\s*permitAll\s*\(\s*\)",
        re.DOTALL,
    )

    SEC_KEYWORDS = (
        "SecurityFilterChain",
        "authorizeHttpRequests",
        "EnableWebSecurity",
        "HttpSecurity",
        "org.springframework.security",
        "springSecurityFilterChain",
        "requestMatchers",
        "antMatchers",
        "mvcMatchers",
        "AuthenticationManager",
        "Jwt",
        "Bearer",
    )

    for f in files:
        if f.suffix.lower() != ".java":
            continue

        fp = str(f).replace("\\", "/").lower()
        if "/src/test/" in fp or "/target/" in fp or "/build/" in fp:
            continue

        try:
            src = f.read_text(encoding="utf-8", errors="ignore")
        except Exception:
            continue

        try:
            parts = [p.lower() for p in f.parts]
            secpath = any("security" in p for p in parts) or any("config" == p for p in parts)
        except Exception:
            secpath = False

        hits = any(k in src for k in SEC_KEYWORDS)
        if secpath or hits:
            _LAST_SECURITY_CANDIDATES.append(str(f))

        if not hits and not secpath:
            continue

        found_security_config = True

        if _ANYREQ_AUTH_RE.search(src):
            default_auth = True

        if not default_auth:
            for mm in _MATCHERS_AUTHZ_RE.finditer(src):
                args = mm.group(2) or ""
                paths = _extract_strings(args)
                for s in paths:
                    if s.startswith("/api") or s.startswith("/admin") or s.startswith("/management"):
                        default_auth = True
                        break
                if default_auth:
                    break

        for mm in _MATCHERS_PERMITALL_RE.finditer(src):
            args = mm.group(2) or ""
            for s in _extract_strings(args):
                permit_all.append(s)

    if found_security_config and not default_auth:
        default_auth = True

    seen: set[str] = set()
    uniq: list[str] = []
    for pth in permit_all:
        if pth in seen:
            continue
        seen.add(pth)
        uniq.append(pth)

    return default_auth, uniq


def _is_auth_public_endpoint(path: str) -> bool:
    return (
        path.startswith("/auth")
        or path.startswith("/api/authenticate")
        or path.startswith("/api/auth/")  # strict
        or path.startswith("/api/register")
        or path.startswith("/api/activate")
        or path.startswith("/api/account/reset-password")
    )


def _guess_access(path: str, *, default_auth: bool, permit_all: list[str]) -> str:
    if _is_auth_public_endpoint(path):
        return "PUBLIC"
    if _matches_any(path, permit_all):
        return "PUBLIC"
    if path.startswith("/api/admin") or path.startswith("/admin"):
        return "ADMIN"
    if path.startswith("/me"):
        return "CUSTOMER"
    if default_auth:
        return "AUTH"
    return "PUBLIC"


def _display_role_str(path: str, roles: set[str], *, default_auth: bool, permit_all: list[str]) -> str:
    if _is_auth_public_endpoint(path):
        return "{PUBLIC}"
    if roles:
        return "{" + ", ".join(sorted(roles)) + "}"
    return "{" + _guess_access(path, default_auth=default_auth, permit_all=permit_all) + "}"


def register_endpoints(app: typer.Typer) -> None:
    @app.command()
    def endpoints(
        path: str = typer.Argument(".", help="Folder to scan"),
        lang: str = typer.Option("all", "--lang", help="all | py | java"),
        hidden: bool = typer.Option(False, "--hidden", help="Include hidden dotfiles/folders"),
        no_gitignore: bool = typer.Option(False, "--no-gitignore", help="Do not apply .gitignore rules"),
        fmt: str = typer.Option("clean", "--format", help="clean | text | json"),
        only_main: bool = typer.Option(True, "--only-main/--all-sources", help="Only scan src/main (skip tests)"),
        only_api: bool = typer.Option(False, "--only-api", help="Only show paths starting with /api"),
        dedupe: bool = typer.Option(True, "--dedupe/--no-dedupe", help="Remove duplicates (method+path)"),
        debug_security: bool = typer.Option(False, "--debug-security", help="Debug Spring Security detection"),
    ):
        folder = _validate_folder(path)
        project_root = find_project_root(folder)

        opts = EndpointScanOptions(
            show_hidden=hidden,
            use_gitignore=not no_gitignore,
        )

        lang_norm = lang.strip().lower()
        if lang_norm not in {"all", "py", "java"}:
            raise typer.BadParameter("Invalid --lang. Use: all | py | java")

        t0 = time.perf_counter()
        all_eps = []

        files = list(iter_supported_source_files(project_root, opts))

        files_for_security = files
        if only_main:
            tmp: list[Path] = []
            for f in files:
                fp = _norm_path(str(f)).lower()
                if "/src/test/" in fp or "/target/" in fp or "/build/" in fp:
                    continue
                tmp.append(f)
            files_for_security = tmp

        default_auth, permit_all = _detect_spring_security_policy(files_for_security)

        if debug_security:
            typer.echo("")
            typer.echo("DEBUG SECURITY DETECTION")
            typer.echo("  default_auth=" + str(default_auth))
            typer.echo("  permit_all_count=" + str(len(permit_all)))
            typer.echo("  security_candidates_detected=" + str(len(_LAST_SECURITY_CANDIDATES)))
            for i, fp in enumerate(_LAST_SECURITY_CANDIDATES[:25], start=1):
                typer.echo(f"  {i:02d}. {fp}")
            typer.echo("")

        for f in files:
            suf = f.suffix.lower()
            if lang_norm == "py" and suf != ".py":
                continue
            if lang_norm == "java" and suf != ".java":
                continue

            try:
                src = f.read_text(encoding="utf-8", errors="ignore")
            except Exception:
                continue

            if suf == ".java":
                all_eps.extend(
                    extract_spring_endpoints(
                        src,
                        str(f),
                        default_auth=default_auth,
                        permit_all=permit_all,
                    )
                )
            elif suf == ".py":
                all_eps.extend(extract_python_endpoints(src, str(f)))

        # NEW: OpenAPI fallback (spec-first repos like spring-petclinic-rest)
        if lang_norm in {"all", "java"}:
            spring_count = sum(1 for e in all_eps if e.framework == "spring")
            if spring_count == 0:
                all_eps.extend(extract_openapi_endpoints(project_root))

        if only_main:
            filtered = []
            for e in all_eps:
                fp = _norm_path(e.file)
                if "/src/test/" in fp:
                    continue
                if "/src/main/" in fp or "/main/" in fp:
                    filtered.append(e)
            all_eps = filtered

        if only_api:
            all_eps = [e for e in all_eps if e.path.startswith("/api")]

        if dedupe:
            seen = set()
            uniq = []
            for e in all_eps:
                key = (e.method, e.path)
                if key in seen:
                    continue
                seen.add(key)
                uniq.append(e)
            all_eps = uniq

        all_eps.sort(key=lambda e: (e.path, e.method, e.file, e.line))
        elapsed = time.perf_counter() - t0

        fmt_norm = fmt.strip().lower()

        if fmt_norm == "json":
            typer.echo(json.dumps([e.to_dict() for e in all_eps], indent=2))
            return

        if fmt_norm == "text":
            typer.echo(f"Project: {project_root}")
            typer.echo(f"Found {len(all_eps)} endpoints in {elapsed:.3f}s")
            typer.echo("")
            for e in all_eps:
                roles = set(e.roles or [])
                typer.echo(
                    f"{e.method:6} {e.path:40} "
                    f"{_display_role_str(e.path, roles, default_auth=default_auth, permit_all=permit_all)}  "
                    f"{e.file}:{e.line}  {e.handler}  <{e.framework}>"
                )
            return

        typer.echo(f"Found {len(all_eps)} endpoints in {elapsed:.3f}s")
        typer.echo("")

        methods_by_path: dict[str, set[str]] = defaultdict(set)
        roles_by_key: dict[tuple[str, str], set[str]] = defaultdict(set)

        for e in all_eps:
            methods_by_path[e.path].add(e.method)
            if e.roles:
                roles_by_key[(e.path, e.method)].update(e.roles)

        paths = sorted(methods_by_path.keys())
        for idx, p in enumerate(paths, start=1):
            methods = sorted(methods_by_path[p])
            parts = []
            for m in methods:
                role_set = roles_by_key.get((p, m), set())
                parts.append(f"{m}{_display_role_str(p, role_set, default_auth=default_auth, permit_all=permit_all)}")
            typer.echo(f"{idx:02d}. {p}  [{', '.join(parts)}]")