﻿from __future__ import annotations

from pathlib import Path
from typing import Iterable, Optional, Tuple, Any
import re
import typer

IGNORE_DIRS = {
    ".git", ".idea", ".vscode", ".mvn",
    "__pycache__", ".pytest_cache", ".ruff_cache", ".tox",
    ".venv", "venv", "env",
    "node_modules", "dist", "build", "out", "target", ".gradle",
}

REQ_KEYS = ("request", "create", "update", "input", "payload", "command", "param", "params", "form")
RES_KEYS = ("response", "result", "output", "view", "data")

_DENY_TYPES = {"return", "throw", "new", "super", "this", "break", "continue"}
_DENY_NAMES = {"return", "throw", "new", "super", "this", "true", "false", "null"}

_record_re = re.compile(r"\brecord\s+([A-Za-z_][A-Za-z0-9_]*)\s*\((.*?)\)\s*(?:implements[^{]*)?\{", re.S)
_class_re = re.compile(r"\b(class|record|interface)\s+([A-Za-z_][A-Za-z0-9_]*)\b")
_field_re = re.compile(
    r"^\s*(public|protected|private)?\s*(static\s+)?(final\s+)?([A-Za-z_][\w\<\>\[\]\., ?]+)\s+([A-Za-z_]\w*)\s*(=.*)?;",
    re.M,
)
_annotation_token_re = re.compile(r"^@\w+(\(.*\))?$")
_lombok_re = re.compile(r"@(Data|Value|Builder|Getter|Setter|AllArgsConstructor|NoArgsConstructor|RequiredArgsConstructor)\b")
_jackson_re = re.compile(r"@(JsonProperty|JsonAlias|JsonIgnoreProperties|JsonInclude|JsonNaming)\b")
_jakarta_re = re.compile(r"@(NotNull|NotBlank|NotEmpty|Size|Min|Max|Email|Valid|Pattern)\b")
_interface_method_re = re.compile(r"^\s+([A-Za-z_][\w<>\[\]., ?]+)\s+get([A-Z]\w*)\s*\(\s*\)\s*;", re.M)

NON_NON_NON_DTO_SUFFIXES = (
    "Resource","Controller","RestController","Service","ServiceImpl",
    "Repository","Config","Configuration","Mapper","Handler",
    "Filter","Interceptor","Listener","Scheduler","Factory",
)

DTO_SUFFIXES = (
    "Resource","Controller","RestController","Service","ServiceImpl",
    "Repository","Config","Configuration","Mapper","Handler",
    "Filter","Interceptor","Listener","Scheduler","Factory",
)

NON_DTO_SUFFIXES = (
    "Resource","Controller","RestController","Service","ServiceImpl",
    "Repository","Config","Configuration","Mapper","Handler",
    "Filter","Interceptor","Listener","Scheduler","Factory",
)

DTO_SUFFIXES = (
    "Resource","Controller","RestController","Service","ServiceImpl",
    "Repository","Config","Configuration","Mapper","Handler",
    "Filter","Interceptor","Listener","Scheduler","Factory",
)

NON_NON_DTO_SUFFIXES = (
    "Resource","Controller","RestController","Service","ServiceImpl",
    "Repository","Config","Configuration","Mapper","Handler",
    "Filter","Interceptor","Listener","Scheduler","Factory",
)

DTO_SUFFIXES = (
    "Resource","Controller","RestController","Service","ServiceImpl",
    "Repository","Config","Configuration","Mapper","Handler",
    "Filter","Interceptor","Listener","Scheduler","Factory",
)

NON_DTO_SUFFIXES = (
    "Resource","Controller","RestController","Service","ServiceImpl",
    "Repository","Config","Configuration","Mapper","Handler",
    "Filter","Interceptor","Listener","Scheduler","Factory",
)

DTO_SUFFIXES = (
    "dto", "request", "response", "payload",
    "input", "output", "command", "result", "view",
    "param", "params", "form", "body", "data",
    "message", "event", "query", "vo", "transfer",
    "contract", "resource", "projection", "summary",
    "detail", "info", "spec",
)

DTO_DIRS = {
    "dto", "dtos", "payload", "payloads", "transfer",
    "vo", "vos", "contract", "contracts", "api",
    "request", "response", "requests", "responses",
    "resource", "resources", "projection", "projections",
    "service/dto", "web/rest",
}

# Dirs that strongly indicate NOT a DTO
NON_DTO_DIRS = {
    "entity","entities","repository","repositories","config","configuration",
    "security","exception","exceptions","mapper","mappers","migration","migrations",
    "test","tests","web","rest","controller","controllers","resource","resources",
}


def _walk_files(root: Path) -> Iterable[Path]:
    stack = [root]
    while stack:
        cur = stack.pop()
        try:
            for child in cur.iterdir():
                if child.is_dir():
                    if child.name not in IGNORE_DIRS:
                        stack.append(child)
                else:
                    yield child
        except (PermissionError, FileNotFoundError):
            continue


def _rel(p: Path, root: Path) -> str:
    try:
        return str(p.relative_to(root))
    except ValueError:
        return str(p)


def _read_text_limited(p: Path, max_kb: int = 256) -> str:
    try:
        raw = p.read_bytes()
    except Exception:
        return ""
    raw = raw[: max_kb * 1024]
    return raw.decode("utf-8-sig", errors="replace")


def _parts_lower(p: Path) -> set[str]:
    return {part.lower() for part in p.parts}


def _is_java_dto(p: Path) -> bool:
    if p.suffix != ".java":
        return False
    if p.name == "package-info.java":
        return False
    parts = _parts_lower(p)
    stem = p.stem.lower()

    # Hard exclude non-DTO dirs
    if parts & NON_DTO_DIRS:
        return False

    # Explicit DTO dirs — strong signal
    if parts & DTO_DIRS:
        return True

    # Suffix match on class name
    if any(stem.endswith(s) for s in DTO_SUFFIXES):
        return True

    return False


def _classify_java(rel_path: str, type_name: str) -> str:
    r = rel_path.lower().replace("\\", "/")
    n = type_name.lower()
    if "/request/" in r or r.endswith("/request") or any(k in n for k in REQ_KEYS):
        return "request"
    if "/response/" in r or r.endswith("/response") or any(k in n for k in RES_KEYS):
        return "response"
    return "other"


def _iter_java_top_level_lines(text: str) -> list[str]:
    lines = text.splitlines()
    out: list[str] = []
    depth = 0
    in_block_comment = False
    in_string = False
    in_char = False
    escape = False

    for line in lines:
        if depth == 1:
            out.append(line)
        i = 0
        while i < len(line):
            ch = line[i]
            nxt = line[i + 1] if i + 1 < len(line) else ""
            if in_block_comment:
                if ch == "*" and nxt == "/":
                    in_block_comment = False
                    i += 2
                    continue
                i += 1
                continue
            if in_string:
                if escape:
                    escape = False
                elif ch == "\\":
                    escape = True
                elif ch == '"':
                    in_string = False
                i += 1
                continue
            if in_char:
                if escape:
                    escape = False
                elif ch == "\\":
                    escape = True
                elif ch == "'":
                    in_char = False
                i += 1
                continue
            if ch == "/" and nxt == "/":
                break
            if ch == "/" and nxt == "*":
                in_block_comment = True
                i += 2
                continue
            if ch == '"':
                in_string = True
                i += 1
                continue
            if ch == "'":
                in_char = True
                i += 1
                continue
            if ch == "{":
                depth += 1
            elif ch == "}":
                depth = max(0, depth - 1)
            i += 1
    return out


def _parse_java_record(src: str) -> Optional[Tuple[str, list[str], str]]:
    m = _record_re.search(src)
    if not m:
        return None
    name = m.group(1)
    params = m.group(2).strip()
    if not params:
        return (name, [], "record")
    parts = []
    buf = []
    depth_angle = depth_paren = 0
    for ch in params:
        if ch == "<": depth_angle += 1
        elif ch == ">": depth_angle = max(0, depth_angle - 1)
        elif ch == "(": depth_paren += 1
        elif ch == ")": depth_paren = max(0, depth_paren - 1)
        if ch == "," and depth_angle == 0 and depth_paren == 0:
            parts.append("".join(buf).strip())
            buf = []
        else:
            buf.append(ch)
    if buf:
        parts.append("".join(buf).strip())
    fields = []
    for part in parts:
        tokens = part.split()
        if len(tokens) >= 2:
            fname = tokens[-1].strip()
            ftype_tokens = [t for t in tokens[:-1] if not _annotation_token_re.match(t.strip())]
            ftype = " ".join(ftype_tokens).strip() or "?"
            fields.append(f"{fname}:{ftype}")
    return (name, fields, "record")


def _parse_java_interface_projection(src: str) -> Optional[Tuple[str, list[str], str]]:
    """Detect Spring Data projection interfaces — getX() methods become fields."""
    cm = _class_re.search(src)
    if not cm or cm.group(1) != "interface":
        return None
    name = cm.group(2)
    fields = []
    for m in _interface_method_re.finditer(src):
        ftype = m.group(1).strip()
        # getFirstName -> firstName
        prop = m.group(2)
        fname = prop[0].lower() + prop[1:]
        fields.append(f"{fname}:{ftype}")
    if not fields:
        return None
    return (name, fields, "projection")


def _parse_java_class_fields(src: str) -> Optional[Tuple[str, list[str], str]]:
    cm = _class_re.search(src)
    if not cm or cm.group(1) == "interface":
        return None
    kind = cm.group(1)
    name = cm.group(2)
    if kind == "record":
        return None

    has_lombok = bool(_lombok_re.search(src))
    has_validation = bool(_jakarta_re.search(src))
    has_jackson = bool(_jackson_re.search(src))

    fields: list[str] = []
    for line in _iter_java_top_level_lines(src):
        s = (line or "").strip()
        if not s:
            continue
        low = s.lstrip("\ufeff").lower()
        if low.startswith("return") or low.startswith("throw"):
            continue
        m = _field_re.match(line)
        if not m:
            continue
        if m.group(2) is not None:  # static
            continue
        ftype = re.sub(r"\s+", " ", (m.group(4) or "").strip()).replace(" ?", "?")
        fname = (m.group(5) or "").strip()
        if not ftype or not fname:
            continue
        if ftype.lower() in _DENY_TYPES or fname.lower() in _DENY_NAMES:
            continue
        fields.append(f"{fname}:{ftype}")

    # Lombok @Data/@Value with no explicit fields — flag it
    if not fields and has_lombok:
        fields = ["(Lombok-generated fields)"]

    seen: set[str] = set()
    uniq = [f for f in fields if not (f in seen or seen.add(f))]  # type: ignore[func-returns-value]

    # Extra metadata tag
    tags = []
    if has_lombok: tags.append("@Lombok")
    if has_validation: tags.append("@Validated")
    if has_jackson: tags.append("@Jackson")
    tag_str = " ".join(tags)

    return (name, uniq, tag_str or "class")


def register_types_command(app: typer.Typer) -> None:
    @app.command("types")
    def types_cmd(
        path: str = typer.Argument(".", help="Project root/folder to scan"),
        contains: str = typer.Option("", "-c", "--contains", help="Filter by path substring"),
        max_files: int = typer.Option(500, "-n", "--max-files"),
        max_kb: int = typer.Option(256, "--max-kb"),
        show_path: bool = typer.Option(False, "--show-path", "-p", help="Show file path"),
        kind: str = typer.Option("all", "--kind", "-k", help="Filter: all | request | response | other"),
    ) -> None:
        root = Path(path).resolve()
        filt = contains.strip().lower()
        java_files: list[Path] = []

        for f in _walk_files(root):
            rel = _rel(f, root)
            if filt and filt not in rel.lower():
                continue
            if _is_java_dto(f):
                java_files.append(f)

        java_files.sort(key=lambda p: _rel(p, root).lower())

        java_items: list[dict[str, Any]] = []
        for f in java_files[:max_files]:
            src = _read_text_limited(f, max_kb=max_kb)
            rel = _rel(f, root)

            # 1. Java record
            parsed = _parse_java_record(src)
            if parsed:
                name, fields, tag = parsed
                item_kind = _classify_java(rel, name)
                if kind == "all" or kind == item_kind:
                    java_items.append({"kind": item_kind, "name": name, "fields": fields, "path": rel, "tag": tag})
                continue

            # 2. Interface projection
            parsed2 = _parse_java_interface_projection(src)
            if parsed2:
                name, fields, tag = parsed2
                item_kind = _classify_java(rel, name)
                if kind == "all" or kind == item_kind:
                    java_items.append({"kind": item_kind, "name": name, "fields": fields, "path": rel, "tag": tag})
                continue

            # 3. Class with fields
            parsed3 = _parse_java_class_fields(src)
            if parsed3:
                name, fields, tag = parsed3
                item_kind = _classify_java(rel, name)
                if kind == "all" or kind == item_kind:
                    java_items.append({"kind": item_kind, "name": name, "fields": fields, "path": rel, "tag": tag})

        typer.echo(f"ROOT  : {root}")
        typer.echo(f"Filter: {contains!r}" if contains else "Filter: (none)")
        typer.echo(f"Found : {len(java_items)} DTO/transfer types")

        if java_items:
            typer.echo("")
            # Group by kind
            for group_kind in ("request", "response", "other"):
                group = [x for x in java_items if x["kind"] == group_kind]
                if not group:
                    continue
                label = {"request": "REQUEST", "response": "RESPONSE", "other": "OTHER / SHARED"}[group_kind]
                typer.echo(f"{label} ({len(group)})")
                typer.echo("-" * 40)
                for x in group:
                    tag_part = f"  [{x['tag']}]" if x["tag"] not in ("class", "record") else ""
                    f_str = ", ".join(x["fields"]) if x["fields"] else "(no fields)"
                    path_part = f"  ({x['path']})" if show_path else ""
                    typer.echo(f"  • {x['name']}{tag_part}: {f_str}{path_part}")
                typer.echo("")











# Compatibility stub — kept so server.py and overview_cmd don't break
def _is_python_dto_like(p) -> bool:
    return False

def _parse_python_dataclasses(src: str) -> list:
    return []
