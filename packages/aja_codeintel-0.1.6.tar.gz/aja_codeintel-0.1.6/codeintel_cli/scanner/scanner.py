﻿from __future__ import annotations

import os
from pathlib import Path

from ..core.project import is_skipped_path

_HARD_SKIP: set[str] = {
    "__pycache__", "venv", ".venv", ".git", "node_modules",
    "dist", "build", "out", ".gradle", ".idea", ".mvn",
    "site-packages", "codeintel.egg-info", ".mypy_cache",
    ".pytest_cache", ".ruff_cache", "target",
}

def _should_skip_dir(name: str) -> bool:
    return name in _HARD_SKIP or name.startswith(".")

def _scandir_java(root: str) -> list[Path]:
    results: list[Path] = []
    stack: list[str] = [root]
    while stack:
        cur = stack.pop()
        try:
            with os.scandir(cur) as it:
                for entry in it:
                    if entry.is_dir(follow_symlinks=False):
                        if not _should_skip_dir(entry.name):
                            stack.append(entry.path)
                    elif entry.is_file(follow_symlinks=False):
                        if entry.name.endswith(".java"):
                            p = Path(entry.path)
                            if not is_skipped_path(p):
                                results.append(p.resolve())
        except (PermissionError, FileNotFoundError):
            continue
    return results

def find_source_files(root: Path, exts: tuple[str, ...]) -> list[Path]:
    return find_all_supported_files(root)

def find_python_files(root: Path) -> list[Path]:
    return []

def find_java_files(root: Path) -> list[Path]:
    return find_all_supported_files(root)

def find_all_supported_files(root: Path) -> list[Path]:
    root = root.resolve()
    results = _scandir_java(str(root))
    return sorted(set(results))
