﻿from __future__ import annotations
from pathlib import Path

try:
    from tree_sitter import Language, Parser
    import tree_sitter_java as tsjava
    _JAVA_LANGUAGE = Language(tsjava.language())
    _parser = Parser(_JAVA_LANGUAGE)
    _TS_AVAILABLE = True
except Exception:
    _TS_AVAILABLE = False
    _parser = None
    _JAVA_LANGUAGE = None

def is_available() -> bool:
    return _TS_AVAILABLE

def parse_java_bytes(source: bytes):
    if not _TS_AVAILABLE:
        raise RuntimeError("tree-sitter-java not available")
    tree = _parser.parse(source)
    return tree.root_node

def parse_java_file(path: Path):
    return parse_java_bytes(path.read_bytes())

def _node_text(node, source: bytes) -> str:
    return source[node.start_byte:node.end_byte].decode("utf-8", errors="ignore")

def _children_of_type(node, type_name: str):
    return [c for c in node.children if c.type == type_name]

def _find_nodes(node, type_name: str) -> list:
    results = []
    stack = [node]
    while stack:
        cur = stack.pop()
        if cur.type == type_name:
            results.append(cur)
        stack.extend(reversed(cur.children))
    return results

def extract_classes(path: Path) -> list[str]:
    if not _TS_AVAILABLE:
        import re
        try:
            text = path.read_text(encoding="utf-8", errors="ignore")
            return re.findall(r"\bclass\s+([A-Za-z_][A-Za-z0-9_]*)\b", text)
        except Exception:
            return []
    try:
        source = path.read_bytes()
        root = parse_java_bytes(source)
    except Exception:
        return []
    names: list[str] = []
    for node in _find_nodes(root, "class_declaration"):
        id_nodes = _children_of_type(node, "identifier")
        if id_nodes:
            names.append(_node_text(id_nodes[0], source))
    return names

def extract_fields_ts(path: Path) -> list[tuple[str, str, bool]]:
    if not _TS_AVAILABLE:
        from ..java.models import extract_java_models
        try:
            defs = extract_java_models(path, path.parent)
            if defs:
                return [(f.name, f.type, f.name.lower() == "id") for f in defs[0].fields]
        except Exception:
            pass
        return []
    try:
        source = path.read_bytes()
        root = parse_java_bytes(source)
    except Exception:
        return []
    fields: list[tuple[str, str, bool]] = []
    for class_node in _find_nodes(root, "class_declaration"):
        body_nodes = _children_of_type(class_node, "class_body")
        if not body_nodes:
            continue
        body = body_nodes[0]
        for decl in _children_of_type(body, "field_declaration"):
            modifiers = {_node_text(m, source) for m in _children_of_type(decl, "modifiers")}
            if "static" in modifiers:
                continue
            type_nodes = [c for c in decl.children if c.type not in {"modifiers","variable_declarator",";",","}]
            if not type_nodes:
                continue
            ftype = _node_text(type_nodes[0], source).strip()
            for var in _children_of_type(decl, "variable_declarator"):
                id_nodes = _children_of_type(var, "identifier")
                if id_nodes:
                    fname = _node_text(id_nodes[0], source).strip()
                    fields.append((fname, ftype, fname.lower() == "id"))
        break
    return fields
