﻿from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import re


@dataclass(frozen=True)
class ModelField:
    name: str
    type: str


@dataclass(frozen=True)
class ModelDef:
    name: str
    file: str
    kind: str
    bases: list[str]
    fields: list[ModelField]


# Field declarations like:
#   private String name;
#   @NotNull private Long id;
#   static final int X = 1;
# (Top-level only; enforced by brace-depth scanning below.)
FIELD_RE = re.compile(
    r"^\s*(?:@\w+(?:\([^)]*\))?\s*)*"
    r"(?:(?:public|protected|private)\s+)?"
    r"(?:(?:static|final)\s+)*"
    r"([A-Za-z0-9_<>\[\].,?]+)\s+([A-Za-z_][A-Za-z0-9_]*)\s*(?:=.*)?;"
)

_DENY_TYPES = {"return", "throw", "new", "super", "this", "break", "continue"}
_DENY_NAMES = {"return", "throw", "new", "super", "this", "true", "false", "null"}

# Match only REAL declarations on real lines (not comments).
DECL_RE = re.compile(
    r"^\s*(?:public|protected|private)?\s*(?:abstract\s+|final\s+)?"
    r"(class|interface|enum|record)\s+([A-Za-z_][A-Za-z0-9_]*)\b"
)
RECORD_DECL_RE = re.compile(
    r"^\s*(?:public|protected|private)?\s*record\s+([A-Za-z_][A-Za-z0-9_]*)\s*\((.*)\)"
)


def _split_record_params(sig: str) -> list[tuple[str, str]]:
    s = (sig or "").strip()
    if not s:
        return []
    parts: list[str] = []
    cur: list[str] = []
    depth = 0
    for ch in s:
        if ch == "<":
            depth += 1
        elif ch == ">":
            depth = max(0, depth - 1)
        elif ch == "," and depth == 0:
            parts.append("".join(cur).strip())
            cur = []
            continue
        cur.append(ch)
    if cur:
        parts.append("".join(cur).strip())

    out: list[tuple[str, str]] = []
    for p in parts:
        toks = p.split()
        if len(toks) >= 2:
            t = " ".join(toks[:-1]).strip()
            n = toks[-1].strip()
            if t and n:
                out.append((n, t))
    return out


def _find_top_level_type_name(text: str) -> tuple[str, str] | None:
    """
    Returns (kind, name) for the first real top-level type declaration line.
    This avoids false matches from Javadoc/comments like "Base class for ...".
    """
    in_block = False
    for raw in text.splitlines():
        line = raw

        # Handle /* ... */ blocks
        if in_block:
            if "*/" in line:
                in_block = False
                line = line.split("*/", 1)[1]
            else:
                continue

        if "/*" in line:
            before, after = line.split("/*", 1)
            if "*/" in after:
                after2 = after.split("*/", 1)[1]
                line = before + " " + after2
            else:
                in_block = True
                line = before

        # Strip // comments
        if "//" in line:
            line = line.split("//", 1)[0]

        s = line.strip()
        if not s:
            continue

        mr = RECORD_DECL_RE.match(s)
        if mr:
            return ("record", mr.group(1))

        md = DECL_RE.match(s)
        if md:
            return (md.group(1), md.group(2))

    return None


def _iter_top_level_lines(text: str) -> list[str]:
    """
    Return lines that occur at class top-level (brace depth == 1).
    This avoids parsing method bodies (where 'return x;' lives).
    """
    lines = text.splitlines()
    out: list[str] = []

    depth = 0
    in_block_comment = False
    in_string = False
    in_char = False
    escape = False

    for line in lines:
        # Collect line if it was at depth==1 (inside class body, not method bodies).
        if depth == 1:
            out.append(line)

        i = 0
        while i < len(line):
            ch = line[i]
            nxt = line[i + 1] if i + 1 < len(line) else ""

            if in_block_comment:
                if ch == "*" and nxt == "/":
                    in_block_comment = False
                    i += 2
                    continue
                i += 1
                continue

            if in_string:
                if escape:
                    escape = False
                elif ch == "\\":
                    escape = True
                elif ch == '"':
                    in_string = False
                i += 1
                continue

            if in_char:
                if escape:
                    escape = False
                elif ch == "\\":
                    escape = True
                elif ch == "'":
                    in_char = False
                i += 1
                continue

            # line comment starts -> ignore rest for depth tracking
            if ch == "/" and nxt == "/":
                break

            # block comment starts
            if ch == "/" and nxt == "*":
                in_block_comment = True
                i += 2
                continue

            if ch == '"':
                in_string = True
                i += 1
                continue

            if ch == "'":
                in_char = True
                i += 1
                continue

            if ch == "{":
                depth += 1
            elif ch == "}":
                depth = max(0, depth - 1)

            i += 1

    return out


def extract_java_models(path: Path, project_root: Path) -> list[ModelDef]:
    try:
        text = path.read_text(encoding="utf-8", errors="ignore")
    except Exception:
        return []

    rel = str(path.relative_to(project_root))

    decl = _find_top_level_type_name(text)
    if not decl:
        return []

    kind, name = decl

    # record: try to parse record params (signature may be on same line or elsewhere)
    if kind == "record":
        mrec = re.search(rf"\brecord\s+{re.escape(name)}\s*\(([^)]*)\)", text)
        if mrec:
            params = mrec.group(1)
            fields = [ModelField(n, t) for (n, t) in _split_record_params(params)]
            return [ModelDef(name, rel, "java", [], fields)]
        # record but signature not found: return empty fields
        return [ModelDef(name, rel, "java", [], [])]

    # class/interface/enum: parse top-level fields inside first class body
    fields: list[ModelField] = []
    for line in _iter_top_level_lines(text):
        s = (line or "").strip()
        if not s:
            continue

        # Ignore method-body-ish statements that might still appear (or weird BOM cases)
        low = s.lstrip("\ufeff").lower()
        if low.startswith("return") or low.startswith("throw") or " return " in low or " throw " in low:
            continue

        fm = FIELD_RE.match(line)
        if not fm:
            continue

        ftype = (fm.group(1) or "").strip()
        fname = (fm.group(2) or "").strip()
        if not ftype or not fname:
            continue

        if ftype.lower() in _DENY_TYPES:
            continue
        if fname.lower() in _DENY_NAMES:
            continue

        fields.append(ModelField(fname, ftype))

    return [ModelDef(name, rel, "java", [], fields)]