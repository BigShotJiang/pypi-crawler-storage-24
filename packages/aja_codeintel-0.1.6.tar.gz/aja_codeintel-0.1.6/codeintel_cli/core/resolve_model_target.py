﻿from __future__ import annotations

import os
from pathlib import Path
import typer

from ..errors import InvalidPathError
from .project import find_project_root
from .fuzzy import rank_paths, fuzzy_is_confident
from ..scanner.scanner import find_all_supported_files

_MODEL_DIRS = {
    "model","models","entity","entities","domain","domains",
    "core","aggregate","aggregates","persistence","pojo",
    "bean","beans","orm","schemas","datamodel","record","records",
    "document","documents",
}
_NON_MODEL_DIRS = {
    "controller","controllers","service","services",
    "repository","repositories","config","configuration",
    "util","utils","helper","helpers",
    "exception","exceptions","security",
    "mapper","mappers","migration","migrations",
    "test","tests",
}
_NON_MODEL_SUFFIXES = (
    "Example", "Criteria", "Criterion", "Generated",
    "Service","ServiceImpl","Controller","Repository","Mapper",
    "Config","Configuration","Util","Utils","Helper",
    "Exception","Handler","Interceptor","Filter","Listener",
    "Scheduler","Validator","Converter","Serializer","Deserializer",
    "Factory","Builder","Specification","Dao",
)
_JPA_ANNOTATIONS = ("@Entity","@Table","@Embeddable","@MappedSuperclass")


def _read_head(path: Path, max_bytes: int = 4096) -> str:
    try:
        with open(path, "r", encoding="utf-8", errors="ignore") as f:
            return f.read(max_bytes)
    except Exception:
        return ""

def _has_jpa_annotation(head: str) -> bool:
    return any(ann in head for ann in _JPA_ANNOTATIONS)

def _has_class_definition(head: str) -> bool:
    return "class " in head and len(head.strip()) > 50

def _parts_lower(path: Path) -> set[str]:
    return {p.lower() for p in path.parts}

def _is_test_path(path: Path) -> bool:
    return bool(_parts_lower(path) & {"test", "tests"})

def _stem_is_non_model(path: Path) -> bool:
    return any(path.stem.endswith(s) for s in _NON_MODEL_SUFFIXES)

def _is_java_model_file(path: Path) -> bool:
    if path.suffix.lower() != ".java":
        return False
    if path.name == "package-info.java":
        return False
    if _is_test_path(path):
        return False
    if _stem_is_non_model(path):
        return False
    head = _read_head(path)
    if not head or not _has_class_definition(head):
        return False
    if _has_jpa_annotation(head):
        return True
    if any(ann in head for ann in ("@Document",)):
        return True
    parts = _parts_lower(path)
    if parts & _MODEL_DIRS and not (parts & _NON_MODEL_DIRS):
        return True
    return False


def resolve_model_target_file(query: str, root: str = ".", top: int = 6) -> tuple[Path, Path]:
    auto = os.environ.get("AJA_AUTO") == "1"
    root_path = Path(root).resolve()
    project_root = find_project_root(root_path)

    q = Path(query)
    if q.exists() and q.is_file():
        return q.resolve(), project_root

    try:
        from ..db.cache import CacheManager
        with CacheManager(project_root) as cache:
            if cache.needs_rescan():
                cache.scan_project(verbose=False)
            all_files = [p for p in cache.get_cached_files() if p.suffix.lower() == ".java"]
    except Exception:
        all_files = [p for p in find_all_supported_files(project_root) if p.suffix.lower() == ".java"]

    model_files: list[Path] = [p for p in all_files if _is_java_model_file(p)]

    if not model_files:
        raise InvalidPathError(message="No model/entity files found", path=project_root)

    qstem_lower = Path(query).stem.lower()
    exact_matches = [f for f in model_files if f.stem.lower() == qstem_lower]

    if len(exact_matches) == 1:
        return exact_matches[0].resolve(), project_root

    ranked = rank_paths(query, exact_matches if exact_matches else model_files, project_root, top=top)

    if not ranked:
        raise InvalidPathError(message=f"Model '{query}' not found", path=Path(query))

    if fuzzy_is_confident(ranked):
        ties = [x for x in ranked if abs(x[1] - ranked[0][1]) < 0.02]
        if len(ties) == 1:
            return ranked[0][0].resolve(), project_root

    if auto:
        return ranked[0][0].resolve(), project_root

    typer.echo("Select model:")
    for i, (p, score) in enumerate(ranked, 1):
        try:
            rel = p.relative_to(project_root)
        except Exception:
            rel = p
        typer.echo(f"  {i}. {rel.as_posix()}   score={score:.2f}")

    choice = typer.prompt("Select number (0=cancel)", type=int, default=0)
    if choice == 0 or choice < 1 or choice > len(ranked):
        raise typer.Exit()
    return ranked[choice - 1][0].resolve(), project_root

