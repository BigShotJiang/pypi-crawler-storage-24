﻿from __future__ import annotations
import re
from pathlib import Path
from typing import Any
from ..context.java_rel import clean_java, top_type_name, java_fields_and_rels

_METHOD_RE = re.compile(
    r"^\s*(?:public|protected|private)\s+(?:static\s+)?(?:final\s+)?"
    r"([A-Za-z0-9_<>\[\].,?\s]+?)\s+([a-z][A-Za-z0-9_]*)\s*\(([^)]*)\)\s*(?:throws[^{;]*)?\s*\{",
    re.M
)
_FIELD_RE = re.compile(r"^\s*(?:private|protected)\s+(?:final\s+)?([A-Za-z0-9_<>,\s]+?)\s+([A-Za-z_][A-Za-z0-9_]*)\s*;", re.M)
_MAPPING_RE = re.compile(
    r'@(Get|Post|Put|Delete|Patch|Request)Mapping\s*(?:\(\s*(?:value\s*=\s*|path\s*=\s*)?["\']([^"\']*)["\'][^)]*\)|\(\s*\)|(?=\s|$))',
    re.M
)
_CLASS_MAPPING_RE = re.compile(r'@RequestMapping\s*\(\s*(?:value\s*=\s*|path\s*=\s*)?["\']([^"\']*)["\']')
_CLASS_NAME_RE = re.compile(r"\bclass\s+([A-Za-z_][A-Za-z0-9_]*)\b")
_SKIP_TYPES = {"void","public","private","protected","static","final","return","throw","if","else","for","while","try","catch","new","synchronized","override"}
_SKIP_METHODS = {"equals","hashCode","toString","clone","getClass","notify","notifyAll","wait"}
_JAVA_KEYWORDS = {"if","else","for","while","do","switch","try","catch","finally","return","throw","new","super","this","instanceof","synchronized","assert","break","continue","default","import","package","class","interface","enum","extends","implements","static","final","abstract","public","private","protected","void","int","long","boolean","double","float","char","byte","short"}
_PRIMITIVES = {"String","Long","Integer","Boolean","List","Set","Optional","Page","Object","ResponseEntity","HttpStatus"}
_ENTITY_DIRS = {"model","models","entity","entities","domain","core"}
_DEFAULT_REPO_METHODS = ["findById(ID) -> Optional<T>","save(T) -> T","findAll() -> List<T>","deleteById(ID)","existsById(ID) -> boolean"]

# Controller directory patterns — supports standard MVC and JHipster web/rest/
_CONTROLLER_DIR_PATTERNS = {"controller","controllers","web","rest","resource","resources","api"}


def _get_all_java_files(project_root: Path) -> list[Path]:
    try:
        from ..db.cache import CacheManager
        with CacheManager(project_root) as cache:
            if cache.needs_rescan():
                cache.scan_project(verbose=False)
            return [p for p in cache.get_cached_files() if p.suffix.lower() == ".java"]
    except Exception:
        from ..scanner.scanner import find_all_supported_files
        return [p for p in find_all_supported_files(project_root) if p.suffix.lower() == ".java"]


def _build_stem_index(files: list[Path]) -> dict[str, list[Path]]:
    idx: dict[str, list[Path]] = {}
    for f in files:
        idx.setdefault(f.stem, []).append(f)
    return idx


def _extract_type_name(full_type: str) -> str:
    s = (full_type or "").strip()
    s = s.replace("java.util.","").replace("org.springframework.","")
    if "." in s:
        s = re.sub(r"\b\w+\.", "", s)
    return s


def _is_controller_file(f: Path) -> bool:
    """Detect controllers by directory name OR class suffix."""
    parts_lower = {p.lower() for p in f.parts}
    if parts_lower & _CONTROLLER_DIR_PATTERNS:
        return True
    # Also catch *Resource.java (JHipster convention) and *Controller.java anywhere
    return f.stem.endswith(("Controller", "Resource", "RestController"))


def _find_controllers(all_files: list[Path], service_name: str) -> list[dict]:
    endpoints: list[dict] = []
    seen: set[tuple[str, str]] = set()
    controller_files = [f for f in all_files if _is_controller_file(f)]
    for f in controller_files:
        try:
            text = clean_java(f.read_text(encoding="utf-8", errors="ignore"))
        except OSError:
            continue
        if service_name not in text:
            continue
        m = _CLASS_NAME_RE.search(text)
        controller_class = m.group(1) if m else ""
        class_mapping = ""
        cm = _CLASS_MAPPING_RE.search(text)
        if cm:
            class_mapping = cm.group(1).rstrip("/")
        for mm in _MAPPING_RE.finditer(text):
            verb = mm.group(1)
            if not verb:
                continue
            verb = verb.upper()
            if verb == "REQUEST":
                continue
            raw_path = mm.group(2) or ""
            full_path = (class_mapping + "/" + raw_path.lstrip("/")) if class_mapping else raw_path or "/"
            full_path = re.sub(r"/+", "/", full_path)
            next_chunk = text[mm.end():mm.end()+400]
            handler_match = re.search(
                r"(?:public|protected|private)[^(]*\s+([a-z][A-Za-z0-9_]*)\s*\(", next_chunk
            )
            if not handler_match:
                continue
            handler_name = handler_match.group(1)
            key = (verb, full_path)
            if key in seen:
                continue
            seen.add(key)
            endpoints.append({
                "method": verb,
                "path": full_path,
                "handler": f"{f.stem}.{handler_name}()"
            })
    return endpoints


def _find_models_used(text: str, stem_index: dict[str, list[Path]]) -> dict[str, Any]:
    model_names: set[str] = set()
    for match in re.finditer(r"import\s+[\w.]+\.(?:entity|model|domain|core)\.([A-Z]\w+);", text):
        model_names.add(match.group(1))
    for match in re.finditer(r"\b([A-Z][A-Za-z0-9_]+)\s+\w+\s*[;=]", text):
        name = match.group(1)
        if len(name) > 2 and not name.isupper() and name not in _PRIMITIVES:
            model_names.add(name)
    models: dict[str, Any] = {}
    for model_name in model_names:
        for f in stem_index.get(model_name, []):
            if not (_ENTITY_DIRS & {p.lower() for p in f.parts}):
                continue
            try:
                fields, rels = java_fields_and_rels(f)
                if fields:
                    models[model_name] = {
                        "fields": fields,
                        "relationships": [{"kind": r.kind, "target": r.target, "field": r.field} for r in rels]
                    }
                    break
            except Exception:
                pass
    return models


def _find_repositories(text: str) -> list[dict]:
    repos: list[dict] = []
    for match in _FIELD_RE.finditer(text):
        ftype, fname = match.group(1), match.group(2)
        if "Repository" in ftype or "repository" in fname.lower():
            repo_name = _extract_type_name(ftype)
            if not any(r["name"] == repo_name for r in repos):
                repos.append({"name": repo_name, "methods": _DEFAULT_REPO_METHODS})
    for match in re.finditer(r"import\s+[\w.]+\.repository\.([A-Z]\w+Repository);", text):
        repo_name = match.group(1)
        if not any(r["name"] == repo_name for r in repos):
            repos.append({"name": repo_name, "methods": _DEFAULT_REPO_METHODS})
    return repos


def _extract_service_methods(text: str, class_name: str = "") -> list[dict]:
    methods: list[dict] = []
    seen_names: set[str] = set()
    for match in _METHOD_RE.finditer(text):
        raw_ret = match.group(1).strip()
        method_name = match.group(2).strip()
        params = match.group(3).strip()

        # Skip Java keywords parsed as method names
        if method_name in _JAVA_KEYWORDS:
            continue
        if method_name in seen_names or method_name in _SKIP_METHODS:
            continue
        # Skip constructor (same name as class)
        if class_name and method_name == class_name[0].lower() + class_name[1:]:
            continue
        # Skip setters
        if method_name.startswith("set") and params:
            continue
        ret_type = _extract_type_name(raw_ret)
        if ret_type.lower() in {s.lower() for s in _SKIP_TYPES}:
            continue

        param_list: list[str] = []
        for p in params.split(","):
            p = p.strip()
            if not p:
                continue
            tokens = p.split()
            if len(tokens) >= 2:
                param_list.append(f"{_extract_type_name(' '.join(tokens[:-1]))} {tokens[-1]}")

        seen_names.add(method_name)
        methods.append({
            "name": method_name,
            "params": ", ".join(param_list),
            "return": ret_type if ret_type.lower() not in {s.lower() for s in _SKIP_TYPES} else ""
        })
    return methods


def analyze_java_service(service_file: Path, project_root: Path) -> dict:
    try:
        text = clean_java(service_file.read_text(encoding="utf-8", errors="ignore"))
    except OSError:
        text = ""
    service_name = top_type_name(text, service_file.stem)
    all_files = _get_all_java_files(project_root)
    stem_index = _build_stem_index(all_files)
    impl_text = text
    if "interface " in text:
        hits = stem_index.get(service_file.stem + "Impl", [])
        if hits:
            try:
                impl_text = clean_java(hits[0].read_text(encoding="utf-8", errors="ignore"))
            except OSError:
                pass
    endpoints = _find_controllers(all_files, service_name)
    methods   = _extract_service_methods(text, service_name)
    models    = _find_models_used(impl_text, stem_index)
    repos     = _find_repositories(impl_text)
    return {
        "service_name": service_name,
        "endpoints":    endpoints,
        "methods":      methods,
        "models":       models,
        "repositories": repos,
        "summary": {
            "Endpoints": len(endpoints),
            "Service methods": len(methods),
            "Models used": len(models),
            "Repositories": len(repos)
        },
    }
