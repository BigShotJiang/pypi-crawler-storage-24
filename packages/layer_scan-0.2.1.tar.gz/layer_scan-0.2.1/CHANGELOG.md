# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.2.0] - 2026-03-15

### Added

- **Scoring diagnostics**: `ScoreResult` now includes `coverage`, `full_vocab_entropy`, `full_vocab_log_odds`, `top_token`, and `top_token_prob` fields for signal-vs-noise diagnosis
- **Coverage metric**: Measures how much of the full-vocab probability mass falls on score tokens (>0.5 = reliable, <0.1 = noise)
- **Cross-tool annotation**: New `annotate` command overlays neuro-scan layer labels on layer-scan heatmaps — shows which top configs duplicate reasoning vs syntax layers
- **Annotated heatmap**: Interactive Plotly HTML with layer-function color band and starred top configs

### Changed

- `score_from_logits()` now accepts an optional `tokenizer` parameter for full-vocab diagnostics
- `AggregateResult` and `ScanResult` include `mean_coverage` for aggregate coverage tracking
- Results JSON export includes coverage and per-config coverage data
- Summary text displays coverage alongside log-odds and accuracy for top configs

## [0.1.0] - 2026-03-11

### Added

- Core scanning engine with configurable (i, j) layer duplication
- Logit distribution scoring (deterministic, no sampling)
- Three built-in probes: math, eq (emotional intelligence), json (format compliance)
- Custom probe support via JSON files
- Two inference backends: HuggingFace Transformers and ExLlamaV2
- Interactive Plotly HTML heatmap visualization
- mergekit passthrough YAML export (`--export-mergekit`)
- Sparse-first two-pass scanning (`--sparse-first`)
- CLI with `scan`, `probes`, and `version` commands
- Input validation for ScanConfig parameters
- Comprehensive test suite (smoke, black-box, white-box, boundary, stress)
- CI/CD with GitHub Actions (lint, test, PyPI publish)
