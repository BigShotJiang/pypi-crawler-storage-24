## Type

- [ ] Bug fix
- [ ] New feature
- [ ] Refactoring
- [ ] Documentation
- [ ] CI/CD

## Summary

<!-- Brief description of what this PR does -->

## Test plan

- [ ] New tests added / existing tests updated
- [ ] `pytest -m smoke` passes
- [ ] `pytest -m "not slow"` passes
- [ ] `ruff check .` passes

## Documentation

- [ ] README updated (if user-facing change)
- [ ] CHANGELOG updated
