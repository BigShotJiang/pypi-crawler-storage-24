---
afad: "3.3"
version: "0.143.0"
domain: "architecture"
updated: "2026-02-28"
route:
  keywords: [data integrity, strict mode, FrozenFluentError, IntegrityCache, CacheCorruptionError, WriteConflictError, BLAKE2b, checksum, write-once, idempotent, RWLock, security, FormattingIntegrityError, SyntaxIntegrityError]
  questions: ["how does data integrity work?", "what is strict mode?", "how does cache checksum verification work?", "what is write-once mode?", "how to detect cache corruption?", "what is the data integrity architecture?"]
---

# Data Integrity Architecture

This document describes the architectural design for data integrity in FTLLexEngine.

## Design Principle: Configurable Data Safety

The system separates two distinct safety concerns: formatting error handling and cache integrity.

**Formatting error handling** defaults to fail-fast (`strict=True`). On any formatting error, `FormattingIntegrityError` is raised immediately. Soft error recovery (returning a placeholder like `{$amount}` alongside errors as data) is opt-in via `strict=False`. The Fluent specification defines fallback behavior as valid — FTLLexEngine defaults to the stricter interpretation to prevent silent data errors in production.

**Cache integrity** is always-on by default (`integrity_strict=True`). Cache corruption is a system-level failure independent of how an application handles formatting errors.

| Failure Mode | Default (`strict=True`) | Soft Mode (`strict=False`) |
|:-------------|:------------------------|:---------------------------|
| Missing message | Raise `FormattingIntegrityError` | Return placeholder `{message-id}` + error |
| Missing variable | Raise `FormattingIntegrityError` | Return placeholder `{$var}` + error |
| Cache corruption | Raise `CacheCorruptionError` (always) | Raise `CacheCorruptionError` (always) |
| Error mutation | Immutable `FrozenFluentError` (always) | Immutable `FrozenFluentError` (always) |

**Rationale for strict default:** A bank displaying `{$amount}` when a variable is missing may show no financial figure at all — which is worse than an explicit error. By defaulting to `strict=True`, FTLLexEngine guarantees that every successful `format_pattern()` return is a correct, fully-resolved result. Applications that prefer graceful degradation opt in to soft mode with `strict=False`.

## Architecture Overview

```
+------------------------------------------------------------------+
|                   FluentBundle / FluentLocalization                |
|  +------------------------------------------------------------+  |
|  |                     Strict Mode Layer                       |  |
|  |  Responsibility: Fail-fast on ANY formatting error         |  |
|  |  Raises: FormattingIntegrityError                          |  |
|  |  Scope: Both FluentBundle AND FluentLocalization            |  |
|  +------------------------------------------------------------+  |
|                               |                                   |
|  +------------------------------------------------------------+  |
|  |                     Error Layer                             |  |
|  |  Responsibility: Immutable, verifiable error objects       |  |
|  |  Type: FrozenFluentError (sealed, content-addressed)       |  |
|  +------------------------------------------------------------+  |
|                               |                                   |
|  +------------------------------------------------------------+  |
|  |                     Cache Layer                             |  |
|  |  Responsibility: Checksum-verified format result caching   |  |
|  |  Type: IntegrityCache (BLAKE2b-128, write-once option)     |  |
|  |  Integrity: Independent of strict mode (always-on default) |  |
|  +------------------------------------------------------------+  |
|                               |                                   |
|  +------------------------------------------------------------+  |
|  |       Integrity Exception Layer (cross-cutting)            |  |
|  |  Responsibility: System failure signaling (not Fluent)     |  |
|  |  Types: DataIntegrityError hierarchy                       |  |
|  |  Used by: Strict Mode Layer and Cache Layer                |  |
|  +------------------------------------------------------------+  |
+------------------------------------------------------------------+
```

## Component Responsibilities

### Strict Mode Layer

**Responsibility:** Provide fail-fast behavior at both bundle and localization levels.

**Design Decision:** Strict mode is the default (`strict=True`). Soft error recovery is opt-out via `strict=False`.

**Why fail-fast by default?**

Silent fallbacks are the primary source of data errors in localized applications. When formatting fails and returns `{$amount}`, the application may render no financial figure at all without any indication that something went wrong. Defaulting to fail-fast eliminates this silent failure class.

| Consideration | Rationale |
|:--------------|:----------|
| Financial safety | Missing balance variable must not silently render as `{$amount}` |
| Explicit opt-out | Applications that prefer graceful degradation set `strict=False` deliberately |
| Spec compliance | Fluent spec defines fallback behavior; FTLLexEngine enforces it only when explicitly requested |
| Development feedback | Errors surface immediately rather than appearing as mysterious placeholders in the UI |

**Why offer soft mode at all?**

Some applications — particularly those with partially-translated resources or during migration — prefer graceful degradation: show something rather than crash. These applications opt in to soft mode:

**Soft mode activation:**
- `FluentBundle(..., strict=False)` - explicit opt-out to soft error recovery
- `FluentLocalization(..., strict=False)` - propagates to all bundles
- Combine with `cache=CacheConfig()` for caching

**Invariant:** When `strict=True`, NO formatting operation returns a fallback value. Every error path raises `FormattingIntegrityError`. This invariant holds at both levels:
- `FluentBundle.format_pattern()` - raises on resolver errors
- `FluentLocalization.format_value()` / `format_pattern()` - raises on missing messages across all locales

### Strict Mode vs Cache Integrity

These are independent concerns controlled by separate parameters:

| Parameter | Controls | Default |
|:----------|:---------|:--------|
| `FluentBundle(strict=...)` | Formatting error handling (raise vs return fallback) | `True` |
| `FluentLocalization(strict=...)` | Propagated to each bundle | `True` |
| `CacheConfig(integrity_strict=...)` | Cache corruption response (raise vs evict) | `True` |

**Rationale:** Cache corruption is a system-level integrity failure independent of how an application handles formatting errors. A non-strict application (returning fallbacks for missing translations) should still detect and report cache corruption. The default `integrity_strict=True` ensures this.

### Error Layer (FrozenFluentError)

**Responsibility:** Provide immutable, verifiable error objects.

**Design Decisions:**

| Decision | Rationale |
|:---------|:----------|
| Sealed class (`@final`) | Prevents subclass invariant violations |
| Content-addressed (BLAKE2b-128) | Enables corruption detection |
| Slots-only | Memory efficiency, prevents dynamic attributes |
| Composition over inheritance | `ErrorCategory` enum replaces class hierarchy |

**Content Hash Composition:**

The BLAKE2b-128 content hash includes ALL error fields for complete audit trail integrity:

1. **Core fields:** `message`, `category.value`
2. **Diagnostic (if present):**
   - Core: `code.name`, `message`
   - Location: `span` (start, end, line, column as 4-byte big-endian)
   - Context: `hint`, `help_url`, `function_name`, `argument_name`, `expected_type`, `received_type`, `ftl_location`
   - Metadata: `severity`, `resolution_path` (each element)
3. **Context (if present):** `input_value`, `locale_code`, `parse_type`, `fallback_value`

**Length-Prefixing:** All string fields are length-prefixed (4-byte big-endian UTF-8 byte length) before hashing. This prevents collision attacks where concatenating different field sequences produces identical byte streams (e.g., `("ab", "c")` vs `("a", "bc")`).

**Sentinel Bytes:** None values are distinguished from empty values using sentinel bytes, preventing collision between `span=None` and `span=SourceSpan(0, 0, 0, 0)`.

**Freeze Ordering:** `Exception.__init__` is called before `_frozen` is set to `True`. This ensures compatibility with alternative Python runtimes (PyPy, free-threaded builds) where `Exception.__init__` may route through `__setattr__`.

**Invariants:**
- All attributes frozen after `__init__` completes
- `verify_integrity()` always returns True for uncorrupted errors
- Hash is stable for object lifetime

**Security Properties:**
- Constant-time hash comparison (`hmac.compare_digest`) prevents timing attacks
- Surrogate handling (`errors="surrogatepass"`) prevents Unicode exploits
- Complete field coverage prevents metadata tampering

### Cache Layer (IntegrityCache)

**Responsibility:** Provide checksum-verified caching of format results.

**Design Decisions:**

| Decision | Rationale |
|:---------|:----------|
| BLAKE2b-128 checksums | Fast cryptographic hash, 16-byte overhead per entry |
| Write-once option | Prevents data races from overwriting cached results |
| Independent integrity_strict | Cache corruption detection decoupled from formatting strict mode |
| Audit logging | Compliance and debugging for financial systems |
| Sequence numbers | Monotonic ordering for audit trail integrity |
| Idempotent write detection | Content-hash comparison for thundering herd tolerance |
| Node budget protection | `_MAX_HASHABLE_NODES` prevents DAG expansion attacks on all paths |

**Configuration via CacheConfig:**

`CacheConfig` validates all parameters at construction time (fail-fast). Invalid values raise `ValueError` immediately rather than deferring to `IntegrityCache.__init__`.

```python
config = CacheConfig(
    size=500,
    write_once=True,
    integrity_strict=True,   # Cache corruption: raise (default)
    enable_audit=True,
)
bundle = FluentBundle("en", cache=config)  # strict=True is the default
```

**Checksum Composition:**

The BLAKE2b-128 checksum includes ALL entry fields for complete audit trail integrity:

1. **Content:** `formatted` (UTF-8 encoded, length-prefixed message output)
2. **Errors:** Each error's `content_hash` bytes (BLAKE2b-128, always present; `FrozenFluentError` is `@final`)
3. **Metadata:**
   - `created_at`: 8-byte IEEE 754 double (monotonic timestamp)
   - `sequence`: 8-byte signed big-endian integer (audit trail ordering)

**Length-Prefixing:** All variable-length fields (formatted string, error messages) are length-prefixed (4-byte big-endian UTF-8 byte length) before hashing, preventing collision attacks from field concatenation.

This means different entries with identical content will have different checksums if their metadata differs. This is correct behavior: the checksum protects the complete entry, not just its content.

**Idempotent Write Detection:**

In write-once mode, concurrent writes of the same message pose a challenge: multiple threads may resolve the same message simultaneously (thundering herd). Without idempotent detection, all but the first thread would trigger `WriteConflictError`, even though all produced identical results.

The cache computes a **content-only hash** (excluding metadata like `created_at` and `sequence`) to detect idempotent writes:

1. Second write arrives for an existing key
2. Cache computes content hash of new entry: `BLAKE2b-128(formatted, errors)`
3. Compares with existing entry's content hash (constant-time via `hmac.compare_digest`)
4. If identical: increment `idempotent_writes` counter, return silently (benign race)
5. If different: TRUE conflict - raise `WriteConflictError` (integrity_strict) or log (non-strict)

This allows write-once mode to work correctly under load without false-positive conflicts.

**Type-Tagging for Cache Keys:**

Cache keys must distinguish between values that hash identically but have different types. The `_make_hashable()` function applies type-tagging to prevent collisions:

| Type | Tag Format | Purpose |
|:-----|:-----------|:--------|
| `bool` | `("__bool__", value)` | Distinguish `True` from `1` (`bool` subclasses `int`) |
| `int` | `("__int__", value)` | Distinguish `1` from `True` (must be checked after `bool`) |
| `Decimal` | `("__decimal__", str(value))` | Preserve scale for CLDR plural rules (`Decimal("1.0")` vs `Decimal("1.00")`) |
| `FluentNumber` | `("__fluentnumber__", type, value, formatted, precision)` | Preserve underlying type and formatting info |
| `list` | `("__list__", tuple(...))` | Distinguish from tuple in formatted output |
| `tuple` | `("__tuple__", tuple(...))` | Distinguish from list |

**CLDR Plural Rule Preservation:** Decimal type-tagging uses `str(value)` instead of the numeric value. This preserves scale information critical for CLDR plural rules: `Decimal("1.0")` and `Decimal("1.00")` must cache separately because some locales have scale-dependent plural forms.

**Recursive Verification:**

The `IntegrityCacheEntry.verify()` method performs recursive integrity verification:

1. Recomputes entry checksum from current field values
2. For each `FrozenFluentError` in the errors tuple, calls `verify_integrity()`
3. Returns `True` only if ALL checks pass (entry checksum AND all error content hashes)

This defense-in-depth approach detects corruption at any level of the data hierarchy.

**Invariants:**
- Every `get()` verifies checksum before returning
- Corrupted entries are never returned (either raise or evict)
- Sequence numbers never decrease, even after `clear()`
- Metadata tampering is detected by checksum verification
- Node budget enforced on all recursive `_make_hashable` paths (including Mapping ABC)

**Trade-offs:**
- Checksum verification adds ~0.1 microseconds per `get()` - acceptable for financial correctness
- Write-once mode prevents legitimate cache updates - use only when data race prevention is critical
- Different timestamps produce different checksums - not suitable for content-only comparison
- Idempotent detection adds hash comparison on cache hit - negligible for concurrent workloads

### Integrity Exception Layer

**Responsibility:** Signal system failures distinct from Fluent errors.

**Design Decision:** Separate hierarchy from `FrozenFluentError` because:
1. Different error domains (system failure vs. translation issue)
2. Different handling requirements (escalate vs. fallback)
3. Prevents confusion when catching exceptions

**Hierarchy:**
```
DataIntegrityError (base - immutable after construction)
+-- CacheCorruptionError       - Checksum mismatch detected
+-- FormattingIntegrityError   - Strict mode formatting failure
+-- ImmutabilityViolationError - Mutation attempt on frozen object
+-- IntegrityCheckFailedError  - Generic verification failure
+-- SyntaxIntegrityError       - Strict mode syntax error during resource loading
+-- WriteConflictError         - Write-once cache violation
```

**Invariant:** All integrity exceptions carry `IntegrityContext` for post-mortem analysis.

## Concurrency Model

### Lock Architecture

| Component | Lock Type | Rationale |
|:----------|:----------|:----------|
| `FluentBundle._rwlock` | Custom `RWLock` | High-concurrency format operations; read-heavy; writer-preference; reentrant reads supported (custom function re-entry); write reentrancy and downgrade prohibited |
| `FluentLocalization._lock` | Custom `RWLock` | Brief read lock for bundle map lookup; write lock for lazy bundle creation; exclusive writes for add_resource/add_function |
| `IntegrityCache._lock` | `threading.Lock` | Short operations; no reentrant acquisition in the call path; `RLock` thread-tracking overhead eliminated |
| `LocaleContext._cache_lock` | `threading.Lock` | Class-level LRU cache; two sequential (never nested) acquisitions; `RLock` thread-tracking overhead unnecessary |

## Security Model

### Attack Vectors Mitigated

| Attack | Mitigation |
|:-------|:-----------|
| Error mutation after logging | `__setattr__` raises after freeze |
| Subclass overrides | `@final` + `__init_subclass__` raises |
| Dynamic attribute injection | `__slots__` only, no `__dict__` |
| Hash tampering | Constant-time comparison |
| Cache poisoning | Checksum verification on every read |
| Data race overwrites | Write-once semantics option |
| Metadata tampering | Complete field coverage in checksums/hashes |
| Diagnostic field tampering | All 12 Diagnostic fields included in error hash |
| Timestamp/sequence forgery | Metadata included in cache checksum |
| Field concatenation collision | Length-prefixing prevents `("ab","c")` = `("a","bc")` |
| Type confusion in cache keys | Type-tagging distinguishes `1` from `1.0` from `True` |
| Decimal scale loss | `str(Decimal)` preserves scale for CLDR plural rules |
| Nested error corruption | Recursive verification checks entry AND all contained errors |
| DAG expansion in cache keys | Node budget (`_MAX_HASHABLE_NODES`) on all recursive paths |

### Trust Boundaries

1. **External input** (FTL source, format arguments): Validated at parser/bundle boundary
2. **Cached data**: Verified on every read via checksum
3. **Error objects**: Immutable after construction
4. **Configuration**: Validated at `CacheConfig` construction (fail-fast)

## Performance Characteristics

| Operation | Overhead | Acceptable Because |
|:----------|:---------|:-------------------|
| Error hash computation | ~0.1 microseconds | One-time at construction |
| Cache checksum verification | ~0.1 microseconds | Correctness over speed for financial |
| Slots vs dict | ~200 bytes saved per error | Net memory reduction |
| RWLock vs RLock | Negligible for writes, better for reads | Concurrent format operations scale linearly |

## References

- [FrozenFluentError API](DOC_05_Errors.md)
- [ErrorCategory Enum](DOC_05_Errors.md)
- [FluentBundle strict mode](DOC_01_Core.md)
- [Thread Safety](THREAD_SAFETY.md)
- [BLAKE2 Specification](https://www.blake2.net/)
