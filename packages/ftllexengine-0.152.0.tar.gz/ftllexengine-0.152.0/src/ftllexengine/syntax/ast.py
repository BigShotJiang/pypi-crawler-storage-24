"""Fluent AST (Abstract Syntax Tree) node definitions.

Complete implementation of Fluent 1.0 AST spec.
Includes type guards as static methods (eliminates circular imports).

Python 3.13+. Zero external dependencies.

Type Alias Hierarchy:
    SelectorExpression - restricted set valid as SelectExpression.selector
    InlineExpression   - all inline expressions (superset of SelectorExpression)
    Expression         - InlineExpression | SelectExpression (top-level expression type)
    PatternElement     - TextElement | Placeable
    Entry              - Message | Term | Comment | Junk
    FTLLiteral         - StringLiteral | NumberLiteral
    VariantKey         - Identifier | NumberLiteral
    ASTNode            - union of all AST node types
"""

from __future__ import annotations

import sys
from dataclasses import dataclass
from decimal import Decimal, InvalidOperation
from typing import TYPE_CHECKING

from ftllexengine.enums import (
    CommentType,  # noqa: TC001 - CommentType is re-exported as a public runtime symbol; callers do `from ftllexengine.syntax.ast import CommentType`
)

# TypeIs was added in Python 3.13 (PEP 742). Use a version guard so:
# - Python 3.13+: TypeIs is in the module namespace at runtime; get_type_hints() works.
# - Python 3.12: avoids ImportError; defer to TYPE_CHECKING for mypy only.
if sys.version_info >= (3, 13) or TYPE_CHECKING:
    from typing import TypeIs

# ruff: noqa: RUF022 - __all__ organized by category for readability
__all__ = [
    # Base types
    "Span",
    "Annotation",
    "Identifier",
    # Resource structure
    "Resource",
    "Message",
    "Term",
    "Attribute",
    "Comment",
    "Junk",
    # Pattern elements
    "Pattern",
    "TextElement",
    "Placeable",
    # Expressions
    "SelectExpression",
    "Variant",
    "StringLiteral",
    "NumberLiteral",
    "VariableReference",
    "MessageReference",
    "TermReference",
    "FunctionReference",
    "CallArguments",
    "NamedArgument",
    # Type aliases
    "Entry",
    "FTLLiteral",
    "PatternElement",
    "Expression",
    "InlineExpression",
    "SelectorExpression",
    "VariantKey",
    "ASTNode",
]

# ============================================================================
# BASE TYPES
# ============================================================================

# ASTNode type alias is defined at the end of this file after all classes
# This is necessary because it references all the AST node classes


@dataclass(frozen=True, slots=True)
class Span:
    """Source position span per Fluent spec.

    Tracks character offsets in source text for error reporting and tooling.
    Positions are 0-indexed character offsets in the normalized source
    (after CRLF -> LF line ending normalization).

    Attributes:
        start: Starting character offset (inclusive)
        end: Ending character offset (exclusive)

    Example:
        Source: "hello = world"
        Message span: Span(start=0, end=13)
        Identifier "hello" span: Span(start=0, end=5)

    Note:
        Python strings measure positions in characters (code points), not bytes.
        For CRLF files, positions refer to the normalized (LF-only) source.
    """

    start: int
    end: int

    def __post_init__(self) -> None:
        """Validate span invariants."""
        if self.start < 0:
            msg = f"Span start must be >= 0, got {self.start}"
            raise ValueError(msg)
        if self.end < self.start:
            msg = f"Span end ({self.end}) must be >= start ({self.start})"
            raise ValueError(msg)


@dataclass(frozen=True, slots=True)
class Annotation:
    """Parse error annotation per Fluent spec.

    Attached to Junk nodes to provide structured error information.

    Attributes:
        code: Error code (e.g., "E0001", "expected-token")
        message: Human-readable error message
        arguments: Additional error context as immutable tuple of (key, value) pairs
        span: Location of the error (optional)

    Example:
        Annotation(
            code="expected-token",
            message="Expected '}' but found EOF",
            arguments=(("found", "EOF"), ("expected", "}")),
            span=Span(start=10, end=10)
        )
    """

    code: str
    message: str
    arguments: tuple[tuple[str, str], ...] | None = None
    span: Span | None = None


@dataclass(frozen=True, slots=True)
class Identifier:
    """Identifier: [a-zA-Z][a-zA-Z0-9_-]*"""

    name: str
    span: Span | None = None

    @staticmethod
    def guard(key: object) -> TypeIs[Identifier]:
        """Type guard for Identifier (used in variant keys)."""
        return isinstance(key, Identifier)


# ============================================================================
# TOP-LEVEL ENTRIES
# ============================================================================


@dataclass(frozen=True, slots=True)
class Resource:
    """Root AST node containing all entries."""

    entries: tuple[Entry, ...]


@dataclass(frozen=True, slots=True, weakref_slot=True)
class Message:
    """Message definition.

    Examples:
        hello = Hello, world!
        welcome = Welcome, { $name }!
        button = Save
            .tooltip = Click to save
    """

    id: Identifier
    value: Pattern | None
    attributes: tuple[Attribute, ...]
    comment: Comment | None = None
    span: Span | None = None

    def __post_init__(self) -> None:
        """Validate Fluent spec invariants.

        Per Fluent spec, a message must have either a value pattern or
        at least one attribute (or both).
        """
        if self.value is None and not self.attributes:
            msg = "Message must have a value or at least one attribute"
            raise ValueError(msg)

    @staticmethod
    def guard(entry: object) -> TypeIs[Message]:
        """Type guard for Message (used in entry filtering)."""
        return isinstance(entry, Message)


@dataclass(frozen=True, slots=True, weakref_slot=True)
class Term:
    """Term definition (private, prefixed with -).

    Example:
        -brand = Firefox
    """

    id: Identifier
    value: Pattern
    attributes: tuple[Attribute, ...]
    comment: Comment | None = None
    span: Span | None = None

    def __post_init__(self) -> None:
        """Validate Fluent spec invariants.

        Per Fluent spec, a term must always have a value pattern.
        The type annotation (Pattern, not Pattern | None) enforces this
        at the type level; this validates at runtime for programmatic construction.
        """
        if self.value is None:  # pragma: no branch - runtime guard for programmatic construction
            msg = "Term must have a value pattern (cannot be None)"  # type: ignore[unreachable]
            raise ValueError(msg)

    @staticmethod
    def guard(entry: object) -> TypeIs[Term]:
        """Type guard for Term (used in entry filtering)."""
        return isinstance(entry, Term)


@dataclass(frozen=True, slots=True)
class Attribute:
    """Message or term attribute.

    Example:
        login = Sign In
            .tooltip = Click here to sign in  ← attribute
    """

    id: Identifier
    value: Pattern
    span: Span | None = None


@dataclass(frozen=True, slots=True)
class Comment:
    """Comment (# single, ## group, ### resource)."""

    content: str
    type: CommentType
    span: Span | None = None

    @staticmethod
    def guard(entry: object) -> TypeIs[Comment]:
        """Type guard for Comment (used in entry filtering)."""
        return isinstance(entry, Comment)


@dataclass(frozen=True, slots=True)
class Junk:
    """Unparseable content (syntax error recovery).

    Per Fluent spec, Junk nodes wrap unparseable content and include
    structured error annotations for tooling support.

    Attributes:
        content: The unparseable source text
        annotations: Parse errors with positions and messages
        span: Location of junk content in source

    Example:
        Junk(
            content="invalid { syntax",
            annotations=(
                Annotation(
                    code="expected-token",
                    message="Expected '}' but found EOF",
                    span=Span(start=9, end=16)
                ),
            ),
            span=Span(start=0, end=16)
        )
    """

    content: str
    annotations: tuple[Annotation, ...] = ()
    span: Span | None = None

    @staticmethod
    def guard(entry: object) -> TypeIs[Junk]:
        """Type guard for Junk (used in entry filtering)."""
        return isinstance(entry, Junk)


# ============================================================================
# PATTERNS
# ============================================================================


@dataclass(frozen=True, slots=True)
class Pattern:
    """Text pattern with optional placeables.

    Attributes:
        elements: Sequence of text segments and placeables
        span: Source position in normalized (LF-only) source text
    """

    elements: tuple[PatternElement, ...]
    span: Span | None = None


@dataclass(frozen=True, slots=True)
class TextElement:
    """Plain text segment.

    Attributes:
        value: The text content
        span: Source position in normalized (LF-only) source text
    """

    value: str
    span: Span | None = None

    @staticmethod
    def guard(elem: object) -> TypeIs[TextElement]:
        """Type guard for TextElement.

        Enables type-safe narrowing without circular imports.

        Args:
            elem: Object to check

        Returns:
            True if elem is TextElement

        Example:
            if TextElement.guard(elem):
                elem.value  # Type-safe! mypy knows elem is TextElement
        """
        return isinstance(elem, TextElement)


@dataclass(frozen=True, slots=True)
class Placeable:
    """Dynamic content: { expression }

    Attributes:
        expression: The contained expression
        span: Source position in normalized (LF-only) source text
    """

    expression: Expression
    span: Span | None = None

    @staticmethod
    def guard(elem: object) -> TypeIs[Placeable]:
        """Type guard for Placeable."""
        return isinstance(elem, Placeable)


# ============================================================================
# EXPRESSIONS
# ============================================================================


@dataclass(frozen=True, slots=True)
class SelectExpression:
    """Conditional expression with variants.

    Example:
        { $count ->
            [one] 1 item
           *[other] { $count } items
        }

    Selector constraint:
        ``selector`` is typed as ``SelectorExpression``, a restricted subset
        of ``InlineExpression`` that excludes ``Placeable``. The Fluent spec
        EBNF technically permits any ``inline-expression`` as a selector, but
        the Fluent Guide limits useful selectors to variable references, string
        and number literals, message/term references, and function calls. The
        FTL parser enforces this restriction at parse time; this type encodes
        the constraint so that programmatic AST construction receives static
        analysis feedback when an invalid selector type is used.
    """

    selector: SelectorExpression
    variants: tuple[Variant, ...]
    span: Span | None = None

    def __post_init__(self) -> None:
        """Validate Fluent spec invariants.

        Per Fluent spec, a select expression must have at least one variant,
        and exactly one variant must be marked as the default (with *).
        """
        if not self.variants:
            msg = "SelectExpression requires at least one variant"
            raise ValueError(msg)
        default_count = sum(1 for v in self.variants if v.default)
        if default_count != 1:
            msg = f"SelectExpression requires exactly one default variant, got {default_count}"
            raise ValueError(msg)

    @staticmethod
    def guard(expr: object) -> TypeIs[SelectExpression]:
        """Type guard for SelectExpression."""
        return isinstance(expr, SelectExpression)


@dataclass(frozen=True, slots=True)
class Variant:
    """Single variant in select expression."""

    key: VariantKey
    value: Pattern
    default: bool = False
    span: Span | None = None


# ============================================================================
# LITERALS
# ============================================================================


@dataclass(frozen=True, slots=True)
class StringLiteral:
    """String literal: "text"

    Supports escape sequences:
        \\" → "
        \\\\ → \\
        \\u0000 → Unicode
    """

    value: str
    span: Span | None = None

    @staticmethod
    def guard(expr: object) -> TypeIs[StringLiteral]:
        """Type guard for StringLiteral."""
        return isinstance(expr, StringLiteral)


@dataclass(frozen=True, slots=True)
class NumberLiteral:
    """Number literal: 42 or 3.14

    Decimal numbers use Python's Decimal type for financial-grade precision.
    Integers use Python's int type for memory efficiency.

    The raw field preserves original source for serialization.

    Invariant:
        AST transformers creating new NumberLiteral nodes must ensure
        raw correctly represents value. Parser guarantees consistency
        at construction time. Divergence between these fields indicates
        a transformer bug, not a library issue.
    """

    value: int | Decimal
    """Parsed numeric value (int for integers, Decimal for decimals)."""

    raw: str
    """Original source representation (for serialization)."""

    span: Span | None = None

    def __post_init__(self) -> None:
        """Validate NumberLiteral invariants.

        Raises:
            TypeError: If value is bool (bool is a subclass of int but is not
                a valid numeric literal value in FTL).
            ValueError: If raw is not parseable as a finite integer or decimal
                number, or if parsing raw yields a value that differs from the
                value field. Divergence between raw and value would cause the
                serializer to output a number that does not match the value used
                for plural category matching.
        """
        if isinstance(self.value, bool):
            msg = "NumberLiteral.value must be int or Decimal, not bool"
            raise TypeError(msg)
        try:
            if isinstance(self.value, int):
                parsed: int | Decimal = int(self.raw)
            else:
                parsed = Decimal(self.raw)
        except (ValueError, InvalidOperation) as exc:
            msg = f"NumberLiteral.raw {self.raw!r} is not a valid number literal"
            raise ValueError(msg) from exc
        if isinstance(parsed, Decimal) and not parsed.is_finite():
            msg = f"NumberLiteral.raw {self.raw!r} is not a finite number"
            raise ValueError(msg)
        if parsed != self.value:
            msg = (
                f"NumberLiteral.raw {self.raw!r} parses to {parsed!r} "
                f"but value is {self.value!r}"
            )
            raise ValueError(msg)

    @staticmethod
    def guard(key: object) -> TypeIs[NumberLiteral]:
        """Type guard for NumberLiteral (used in variant keys)."""
        return isinstance(key, NumberLiteral)


# ============================================================================
# REFERENCES
# ============================================================================


@dataclass(frozen=True, slots=True)
class VariableReference:
    """Variable reference: $variable"""

    id: Identifier
    span: Span | None = None

    @staticmethod
    def guard(expr: object) -> TypeIs[VariableReference]:
        """Type guard for VariableReference."""
        return isinstance(expr, VariableReference)


@dataclass(frozen=True, slots=True)
class MessageReference:
    """Message reference: message-id or message-id.attribute"""

    id: Identifier
    attribute: Identifier | None = None
    span: Span | None = None

    @staticmethod
    def guard(expr: object) -> TypeIs[MessageReference]:
        """Type guard for MessageReference."""
        return isinstance(expr, MessageReference)


@dataclass(frozen=True, slots=True)
class TermReference:
    """Term reference: -term-id or -term-id.attribute"""

    id: Identifier
    attribute: Identifier | None = None
    arguments: CallArguments | None = None
    span: Span | None = None

    @staticmethod
    def guard(expr: object) -> TypeIs[TermReference]:
        """Type guard for TermReference."""
        return isinstance(expr, TermReference)


@dataclass(frozen=True, slots=True)
class FunctionReference:
    """Function call: FUNCTION(arg1, key: value)"""

    id: Identifier
    arguments: CallArguments
    span: Span | None = None

    @staticmethod
    def guard(expr: object) -> TypeIs[FunctionReference]:
        """Type guard for FunctionReference."""
        return isinstance(expr, FunctionReference)


@dataclass(frozen=True, slots=True)
class CallArguments:
    """Function call arguments."""

    positional: tuple[InlineExpression, ...]
    named: tuple[NamedArgument, ...]
    span: Span | None = None


@dataclass(frozen=True, slots=True)
class NamedArgument:
    """Named argument: name: value

    Per Fluent spec, named argument values are constrained to literals:
        named-argument ::= identifier ":" literal
        literal        ::= number-literal | quoted-literal
    The value field therefore uses FTLLiteral (StringLiteral | NumberLiteral),
    which is a strict subtype of InlineExpression. The parser enforces this
    constraint; the type encodes it so that downstream code never needs to
    handle the wider union for this field.
    """

    name: Identifier
    value: FTLLiteral
    span: Span | None = None


# ============================================================================
# TYPE ALIASES
# ============================================================================

# Selector expressions: restricted subset of InlineExpression valid as SelectExpression.selector.
# The Fluent Guide limits selectors to these 6 concrete types. Placeable is excluded: the parser
# checks is_valid_selector before constructing SelectExpression and never places Placeable there.
# This alias propagates the restriction to programmatic AST construction via static analysis.
type SelectorExpression = (
    StringLiteral
    | NumberLiteral
    | VariableReference
    | MessageReference
    | TermReference
    | FunctionReference
)

type Entry = Message | Term | Comment | Junk
type PatternElement = TextElement | Placeable
type Expression = SelectExpression | InlineExpression
type InlineExpression = (
    StringLiteral
    | NumberLiteral
    | VariableReference
    | MessageReference
    | TermReference
    | FunctionReference
    | Placeable
)
type VariantKey = Identifier | NumberLiteral

# Per Fluent spec EBNF: named-argument ::= identifier ":" literal
#                        literal        ::= number-literal | quoted-literal
# Named argument values are constrained to literals only.
# VariableReference, MessageReference, TermReference, FunctionReference,
# and Placeable are INVALID named argument values and are rejected by the
# parser. This alias encodes the constraint at the type level so that
# downstream code (serializer, resolver, transformer) does not need to
# handle the full InlineExpression union for NamedArgument.value.
type FTLLiteral = StringLiteral | NumberLiteral

# Complete ASTNode type - union of all AST node types
# This replaces the forward declaration at the top of the file
type ASTNode = (
    Resource
    | Message
    | Term
    | Attribute
    | Comment
    | Junk
    | Pattern
    | TextElement
    | Placeable
    | SelectExpression
    | Variant
    | StringLiteral
    | NumberLiteral
    | VariableReference
    | MessageReference
    | TermReference
    | FunctionReference
    | CallArguments
    | NamedArgument
    | Identifier
    | Annotation
    | Span
)
