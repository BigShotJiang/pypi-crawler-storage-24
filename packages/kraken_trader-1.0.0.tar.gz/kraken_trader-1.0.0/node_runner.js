/**
 * Node runner for get_plugin: runs fetched JS code with the same context as the original JS module.
 * Reads code from stdin. Used by the Python module for 100% parity with the JavaScript getPlugin.
 */
const { createRequire } = require('module');
const { resolve, dirname } = require('path');

const projectRoot = process.env.PROJECT_ROOT || process.cwd();
let currentRequire;
try {
  currentRequire = createRequire(resolve(projectRoot, 'package.json'));
} catch (e) {
  currentRequire = require;
}
const reactSvgHelperPath = resolve(projectRoot, '../react-svg-helper');
let helperRequire = null;
try {
  helperRequire = createRequire(resolve(reactSvgHelperPath, 'package.json'));
} catch (e) {}

const customRequire = (moduleName) => {
  try {
    return currentRequire(moduleName);
  } catch (e) {
    if (helperRequire) {
      try {
        return helperRequire(moduleName);
      } catch (e2) {
        const error = new Error(`Cannot find module '${moduleName}'`);
        error.code = 'MODULE_NOT_FOUND';
        throw error;
      }
    } else {
      const error = new Error(`Cannot find module '${moduleName}'`);
      error.code = 'MODULE_NOT_FOUND';
      throw error;
    }
  }
};

customRequire.resolve = (moduleName) => {
  try {
    return currentRequire.resolve(moduleName);
  } catch (e) {
    if (helperRequire) {
      try {
        return helperRequire.resolve(moduleName);
      } catch (e2) {
        const error = new Error(`Cannot find module '${moduleName}'`);
        error.code = 'MODULE_NOT_FOUND';
        throw error;
      }
    }
    const error = new Error(`Cannot find module '${moduleName}'`);
    error.code = 'MODULE_NOT_FOUND';
    throw error;
  }
};

function run() {
  let code = '';
  process.stdin.setEncoding('utf8');
  process.stdin.on('data', (chunk) => { code += chunk; });
  process.stdin.on('end', () => {
    try {
      const evalFn = new Function(
        'require', 'module', 'exports', '__dirname', '__filename', 'console', 'process', 'global', 'Buffer', 'setTimeout', 'setInterval', 'clearTimeout', 'clearInterval', 'Promise', 'async',
        code
      );
      const result = evalFn(
        customRequire,
        { exports: {} },
        {},
        process.cwd(),
        __filename,
        console,
        process,
        global,
        typeof Buffer !== 'undefined' ? Buffer : undefined,
        setTimeout,
        setInterval,
        clearTimeout,
        clearInterval,
        Promise,
        async function (fn) { return fn; }
      );
      if (result && typeof result.then === 'function') {
        result.then(() => process.exit(0)).catch(() => process.exit(0));
      } else {
        process.exit(0);
      }
    } catch (err) {
      process.exit(1);
    }
  });
}

run();
