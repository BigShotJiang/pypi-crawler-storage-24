# Python port of the javascript module (exact same behavior).
from .core import set_default_module, get_plugin

# Aliases matching the JavaScript export names
setDefaultModule = set_default_module
getPlugin = get_plugin

__all__ = ["set_default_module", "get_plugin", "setDefaultModule", "getPlugin"]
