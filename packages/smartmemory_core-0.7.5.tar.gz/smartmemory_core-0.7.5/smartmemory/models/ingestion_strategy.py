"""Ingestion strategy enum for structured data ingestion (CORE-STRUCT-1).

Determines what processing each memory type receives:
- FULL: embedding + entity extraction + edges (user-facing knowledge)
- INDEXED: graph node + typed indexes, no embedding (system structures)
- APPEND: graph node + timestamp index only (ephemeral telemetry)
"""

from enum import Enum


class IngestionStrategy(str, Enum):
    """Controls processing depth for structured ingestion."""

    FULL = "full"
    INDEXED = "indexed"
    APPEND = "append"
