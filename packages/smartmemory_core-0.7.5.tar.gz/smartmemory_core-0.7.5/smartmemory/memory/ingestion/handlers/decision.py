"""DecisionHandler — structured ingestion for decision records (CORE-STRUCT-1 Phase 1b).

Strategy: INDEXED — decisions are queried by typed fields (status, domain, decision_type).
Coexists with DecisionManager (lifecycle operations) — this handler is for structured import.
"""

from __future__ import annotations

from typing import Optional

from smartmemory.models.ingestion_strategy import IngestionStrategy
from smartmemory.models.memory_item import MemoryItem


class DecisionHandler:
    """Structured handler for decision records."""

    strategy = IngestionStrategy.INDEXED
    schema_name = "decision"
    embed: Optional[bool] = None  # defer to strategy default (no embedding)

    def validate(self, data: dict) -> bool:
        """Require non-empty content string."""
        content = data.get("content")
        return isinstance(content, str) and len(content.strip()) > 0

    def to_memory_item(self, data: dict) -> MemoryItem:
        """Convert decision data to MemoryItem.

        Mirrors DecisionManager._store_decision() (decisions/manager.py:281-291)
        for field mapping, but allows callers to pass a fully-formed dict.
        """
        evidence_ids = data.get("evidence_ids", [])
        return MemoryItem(
            content=data["content"],
            memory_type="decision",
            item_id=data.get("decision_id"),
            confidence=data.get("confidence", 0.8),
            derived_from=evidence_ids[0] if evidence_ids else None,
            metadata={
                "decision_type": data.get("decision_type", "inference"),
                "status": data.get("status", "active"),
                "source_type": data.get("source_type", "inferred"),
                "source_trace_id": data.get("source_trace_id"),
                "evidence_ids": evidence_ids,
                "domain": data.get("domain"),
                "tags": data.get("tags", []),
            },
        )

    def get_edges(self, data: dict, item_id: str) -> list[tuple[str, str, str, dict]]:
        """Create PRODUCED and DERIVED_FROM edges (mirrors DecisionManager.create())."""
        edges: list[tuple[str, str, str, dict]] = []

        # PRODUCED edge from source trace (DecisionManager line 84-90)
        source_trace_id = data.get("source_trace_id")
        if source_trace_id:
            edges.append(
                (
                    source_trace_id,
                    item_id,
                    "PRODUCED",
                    {"confidence": 0.5, "origin": "structured:decision"},
                )
            )

        # DERIVED_FROM edges for evidence (DecisionManager line 92-94, 318-329)
        for eid in data.get("evidence_ids", []):
            edges.append(
                (
                    item_id,
                    eid,
                    "DERIVED_FROM",
                    {"role": "evidence", "origin": "structured:decision", "confidence": 0.5},
                )
            )

        return edges

    def get_indexes(self) -> list[str]:
        """Typed indexes for decision queries."""
        return [
            "CREATE INDEX IF NOT EXISTS idx_decision_status "
            "ON nodes(json_extract(properties, '$.status')) WHERE memory_type='decision'",
            "CREATE INDEX IF NOT EXISTS idx_decision_domain "
            "ON nodes(json_extract(properties, '$.domain')) WHERE memory_type='decision'",
            "CREATE INDEX IF NOT EXISTS idx_decision_type "
            "ON nodes(json_extract(properties, '$.decision_type')) WHERE memory_type='decision'",
        ]
