"""Structured handler for anchor records (CORE-GAPS-1).

Anchors are persistent requirement/constraint markers that participate
in forced-inclusion retrieval. They use INDEXED strategy (no embedding)
and memory_type="anchor" with metadata for anchor_type, session, and status.
"""

from __future__ import annotations

from typing import Optional
from uuid import uuid4

from smartmemory.models.ingestion_strategy import IngestionStrategy
from smartmemory.models.memory_item import MemoryItem

VALID_ANCHOR_TYPES = {"spec", "scope", "decision", "constraint"}


class AnchorHandler:
    """Structured handler for spec anchoring & anti-drift (CORE-GAPS-1)."""

    strategy = IngestionStrategy.INDEXED
    schema_name = "anchor"
    embed: Optional[bool] = None

    def validate(self, data: dict) -> bool:
        content = data.get("content")
        anchor_type = data.get("anchor_type", "spec")
        return (
            isinstance(content, str)
            and len(content.strip()) > 0
            and anchor_type in VALID_ANCHOR_TYPES
        )

    def to_memory_item(self, data: dict) -> MemoryItem:
        anchor_id = data.get("anchor_id") or f"anchor_{uuid4().hex[:12]}"
        return MemoryItem(
            content=data["content"],
            memory_type="anchor",
            item_id=anchor_id,
            confidence=1.0,
            metadata={
                "anchor_type": data.get("anchor_type", "spec"),
                "anchor_session": data.get("session_id", ""),
                "anchor_status": "active",
            },
        )

    def get_edges(self, data: dict, item_id: str) -> list[tuple[str, str, str, dict]]:
        return []

    def get_indexes(self) -> list[str]:
        return [
            "CREATE INDEX IF NOT EXISTS idx_anchor_status "
            "ON nodes(json_extract(properties, '$.anchor_status')) WHERE memory_type='anchor'",
            "CREATE INDEX IF NOT EXISTS idx_anchor_session "
            "ON nodes(json_extract(properties, '$.anchor_session')) WHERE memory_type='anchor'",
            "CREATE INDEX IF NOT EXISTS idx_anchor_type "
            "ON nodes(json_extract(properties, '$.anchor_type')) WHERE memory_type='anchor'",
        ]
