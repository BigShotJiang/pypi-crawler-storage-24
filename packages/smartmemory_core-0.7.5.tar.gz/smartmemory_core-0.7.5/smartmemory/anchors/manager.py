"""AnchorManager — lifecycle orchestrator for CORE-GAPS-1.

Manages anchor creation, listing, clearing, graduation to decisions,
and drift detection. Follows the PlanManager pattern.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Any, Optional
from uuid import uuid4

from smartmemory.anchors.drift import AnchorDriftChecker
from smartmemory.anchors.models import DriftReport
from smartmemory.anchors.queries import AnchorQueries

if TYPE_CHECKING:
    from smartmemory.smart_memory import SmartMemory

logger = logging.getLogger(__name__)

VALID_ANCHOR_TYPES = {"spec", "scope", "decision", "constraint"}

# Graduation mapping: anchor_type -> decision_type
_GRADUATION_MAP = {
    "spec": "policy",
    "scope": "policy",
    "constraint": "policy",
    "decision": "inference",
}


class AnchorManager:
    """Lifecycle manager for spec anchors."""

    def __init__(self, memory: SmartMemory) -> None:
        self.memory = memory
        self.queries = AnchorQueries(memory)
        self.drift_checker = AnchorDriftChecker()

    def set(self, content: str, anchor_type: str, session_id: str) -> str:
        """Create a new anchor.

        Args:
            content: The requirement/constraint text.
            anchor_type: One of spec, scope, decision, constraint.
            session_id: Session scope for this anchor.

        Returns:
            The anchor item_id.

        Raises:
            ValueError: If anchor_type is invalid.
        """
        if anchor_type not in VALID_ANCHOR_TYPES:
            raise ValueError(
                f"Invalid anchor_type '{anchor_type}'. "
                f"Must be one of: {', '.join(sorted(VALID_ANCHOR_TYPES))}"
            )

        anchor_id = f"anchor_{uuid4().hex[:12]}"
        item_id = self.memory.ingest_structured(
            {
                "content": content,
                "anchor_type": anchor_type,
                "session_id": session_id,
                "anchor_id": anchor_id,
            },
            schema="anchor",
        )
        logger.info(f"Anchor set: {item_id} type={anchor_type} session={session_id}")
        return item_id

    def list(
        self, session_id: str, anchor_type: Optional[str] = None
    ) -> list[dict[str, Any]]:
        """List active anchors for a session.

        Args:
            session_id: Session scope.
            anchor_type: Optional type filter.

        Returns:
            List of anchor dicts.
        """
        return self.queries.get_active(session_id, anchor_type)

    def clear(
        self, session_id: str, anchor_type: Optional[str] = None
    ) -> int:
        """Clear (deactivate) anchors for a session.

        Args:
            session_id: Session scope.
            anchor_type: Optional type filter. If None, clears all.

        Returns:
            Number of anchors cleared.
        """
        active = self.queries.get_active(session_id, anchor_type)
        count = 0
        for anchor in active:
            try:
                self.memory.update_properties(
                    anchor["anchor_id"],
                    {"anchor_status": "cleared"},
                )
                count += 1
            except Exception as e:
                logger.warning(f"Failed to clear anchor {anchor['anchor_id']}: {e}")
        logger.info(f"Cleared {count} anchors for session={session_id}")
        return count

    def graduate(self, session_id: str) -> list[str]:
        """Graduate active anchors to decisions.

        Creates a decision for each active anchor via DecisionManager,
        then marks the anchor as graduated.

        Args:
            session_id: Session scope.

        Returns:
            List of created decision IDs.
        """
        from smartmemory.decisions.manager import DecisionManager

        active = self.queries.get_active(session_id)
        if not active:
            return []

        dm = DecisionManager(self.memory)
        decision_ids = []

        for anchor in active:
            anchor_type = anchor.get("anchor_type", "spec")
            decision_type = _GRADUATION_MAP.get(anchor_type, "policy")

            try:
                decision = dm.create(
                    content=anchor["content"],
                    decision_type=decision_type,
                    evidence_ids=[anchor["anchor_id"]],
                )
                decision_id = decision.decision_id

                self.memory.update_properties(
                    anchor["anchor_id"],
                    {
                        "anchor_status": "graduated",
                        "graduated_to": decision_id,
                    },
                )
                decision_ids.append(decision_id)
                logger.info(
                    f"Graduated anchor {anchor['anchor_id']} -> decision {decision_id}"
                )
            except Exception as e:
                logger.error(f"Failed to graduate anchor {anchor['anchor_id']}: {e}")

        return decision_ids

    def check_drift(
        self, session_id: str, recent_outputs: list[str]
    ) -> list[DriftReport]:
        """Check active anchors for drift against recent outputs.

        Args:
            session_id: Session scope.
            recent_outputs: List of recent output strings.

        Returns:
            List of DriftReport, one per active anchor.
        """
        active = self.queries.get_active(session_id)
        if not active:
            return []

        # Convert dicts to MemoryItems for the drift checker
        anchor_items = []
        for a in active:
            item = self.memory.get(a["anchor_id"])
            if item is not None:
                anchor_items.append(item)

        return self.drift_checker.check(anchor_items, recent_outputs)
