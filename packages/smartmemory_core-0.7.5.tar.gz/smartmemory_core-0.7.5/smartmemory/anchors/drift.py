"""Stateless drift checker for CORE-GAPS-1.

Compares anchor content against recent outputs using keyword overlap.
No SmartMemory dependency — pure Python, testable with plain strings.
"""

from __future__ import annotations

from smartmemory.anchors.models import DriftReport
from smartmemory.models.memory_item import MemoryItem

# Common English stopwords to filter out of keyword extraction
_STOPWORDS = frozenset({
    "a", "an", "the", "is", "are", "was", "were", "be", "been", "being",
    "have", "has", "had", "do", "does", "did", "will", "would", "could",
    "should", "may", "might", "shall", "can", "need", "must", "ought",
    "and", "but", "or", "nor", "not", "no", "so", "yet", "both", "either",
    "neither", "each", "every", "all", "any", "few", "more", "most", "other",
    "some", "such", "than", "too", "very", "just", "also", "only",
    "in", "on", "at", "to", "for", "of", "with", "by", "from", "as",
    "into", "through", "during", "before", "after", "above", "below",
    "between", "under", "over", "about", "up", "out", "off", "then",
    "once", "here", "there", "when", "where", "why", "how", "what",
    "which", "who", "whom", "this", "that", "these", "those",
    "i", "me", "my", "we", "our", "you", "your", "he", "him", "his",
    "she", "her", "it", "its", "they", "them", "their",
    "use", "used", "using", "get", "got", "set", "let", "put", "run",
    "make", "made", "take", "give", "keep", "find", "tell", "ask",
})


class AnchorDriftChecker:
    """Stateless comparator — receives anchors and recent text, returns drift signals."""

    def check(
        self,
        anchors: list[MemoryItem],
        recent_outputs: list[str],
    ) -> list[DriftReport]:
        """Check each anchor against recent outputs for keyword drift.

        Args:
            anchors: List of anchor MemoryItems.
            recent_outputs: List of recent output strings to check against.

        Returns:
            One DriftReport per anchor.
        """
        if not anchors:
            return []

        output_tokens = self._extract_keywords(" ".join(recent_outputs))

        reports = []
        for anchor in anchors:
            anchor_keywords = self._extract_keywords(anchor.content)
            if not anchor_keywords:
                reports.append(DriftReport(
                    anchor_id=getattr(anchor, "item_id", "") or "",
                    anchor_content=anchor.content,
                    drift_score=0.0,
                    missing_keywords=[],
                    severity="none",
                ))
                continue

            overlap = anchor_keywords & output_tokens
            missing = sorted(anchor_keywords - output_tokens)
            score = 1.0 - (len(overlap) / len(anchor_keywords))

            reports.append(DriftReport(
                anchor_id=getattr(anchor, "item_id", "") or "",
                anchor_content=anchor.content,
                drift_score=round(score, 3),
                missing_keywords=missing,
                severity=self._severity(score),
            ))

        return reports

    def _extract_keywords(self, text: str) -> set[str]:
        """Extract meaningful keywords from text."""
        tokens = set()
        for word in text.lower().split():
            # Strip punctuation
            cleaned = word.strip(".,;:!?()[]{}\"'`-_/\\")
            if len(cleaned) >= 3 and cleaned not in _STOPWORDS:
                tokens.add(cleaned)
        return tokens

    def _severity(self, score: float) -> str:
        """Map drift score to severity level."""
        if score <= 0.2:
            return "none"
        elif score <= 0.5:
            return "mild"
        elif score <= 0.8:
            return "significant"
        else:
            return "critical"
