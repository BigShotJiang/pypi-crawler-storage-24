"""
Direct OpenAI Chat Completions client — bypasses dspy/litellm.

Works with any OpenAI-compatible API (Groq, Together, Fireworks, etc.)
via the `openai` SDK. Uses standard Chat Completions endpoint, not the
newer Responses API.

Created as a workaround for litellm supply chain issues (2026-03).
"""

import logging
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)

try:
    from openai import OpenAI  # type: ignore
except ImportError:  # pragma: no cover
    OpenAI = None  # type: ignore


def call_openai_chat(
    *,
    model: str,
    messages: List[Dict[str, str]],
    max_output_tokens: int = 2000,
    api_key: Optional[str] = None,
    api_base: Optional[str] = None,
    response_format: Optional[Dict[str, Any]] = None,
    temperature: Optional[float] = None,
) -> Optional[str]:
    """Invoke OpenAI Chat Completions and return the assistant message text.

    Works with Groq, Together, and any OpenAI-compatible endpoint.
    Returns raw text — caller handles JSON parsing.

    Args:
        model: Model name (e.g., "llama-3.3-70b-versatile")
        messages: Chat messages [{role, content}, ...]
        max_output_tokens: Max tokens in response
        api_key: API key (if None, SDK reads from OPENAI_API_KEY env)
        api_base: Base URL override (e.g., "https://api.groq.com/openai/v1")
        response_format: e.g., {"type": "json_object"}
        temperature: Sampling temperature
    """
    if OpenAI is None:  # pragma: no cover
        raise ImportError("openai package is required")

    client_kwargs: Dict[str, Any] = {}
    if api_key:
        client_kwargs["api_key"] = api_key
    if api_base:
        client_kwargs["base_url"] = api_base

    client = OpenAI(**client_kwargs)

    params: Dict[str, Any] = {
        "model": model,
        "messages": messages,
        "max_tokens": max_output_tokens,
    }
    if response_format:
        params["response_format"] = response_format
    if temperature is not None:
        params["temperature"] = temperature

    response = client.chat.completions.create(**params)
    choice = response.choices[0] if response.choices else None
    if choice and choice.message and choice.message.content:
        return choice.message.content
    return None
