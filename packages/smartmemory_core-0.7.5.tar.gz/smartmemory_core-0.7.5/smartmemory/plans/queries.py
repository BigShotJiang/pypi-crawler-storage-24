"""Plan query helpers (CORE-GAPS-2 Phase 1).

Read-only queries for plan containers and tasks. Separated from PlanManager
to keep query logic reusable (mirrors DecisionQueries pattern).
"""

from __future__ import annotations

import json
import logging
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from smartmemory.smart_memory import SmartMemory

logger = logging.getLogger(__name__)


class PlanQueries:
    """Read-only query helpers for plans and tasks."""

    def __init__(self, memory: SmartMemory) -> None:
        self.memory = memory

    def get_plan(self, plan_id: str) -> dict[str, Any] | None:
        """Get a plan container by plan_id."""
        item = self.memory.get(plan_id)
        if item is None:
            return None
        return self._to_plan_dict(item)

    def get_plan_with_tasks(self, plan_id: str) -> dict[str, Any] | None:
        """Get a plan container with all its tasks."""
        plan = self.get_plan(plan_id)
        if plan is None:
            return None
        tasks = self.get_tasks_for_plan(plan_id)
        return {"plan": plan, "tasks": tasks}

    def get_tasks_for_plan(self, plan_id: str) -> list[dict[str, Any]]:
        """Get all task nodes for a plan via direct backend query."""
        from smartmemory.graph.backends.sqlite import SQLiteBackend

        backend = self.memory._graph.backend
        if isinstance(backend, SQLiteBackend):
            return self._get_tasks_sqlite(backend, plan_id)

        # FalkorDB fallback — search + post-filter (Phase 3 will add Cypher path)
        logger.warning("Plan task query on non-SQLite backend — using search fallback")
        return self._get_tasks_search_fallback(plan_id)

    def get_active_plans(self, limit: int = 20) -> list[dict[str, Any]]:
        """Get all plans with status='active'."""
        from smartmemory.graph.backends.sqlite import SQLiteBackend

        backend = self.memory._graph.backend
        if isinstance(backend, SQLiteBackend):
            return self._get_active_sqlite(backend, limit)

        # FalkorDB fallback
        logger.warning("Active plan query on non-SQLite backend — using search fallback")
        return self._get_active_search_fallback(limit)

    def get_next_tasks(self, plan_id: str) -> list[dict[str, Any]]:
        """Get pending tasks whose dependencies are all complete."""
        tasks = self.get_tasks_for_plan(plan_id)
        completed_ids = {t["item_id"] for t in tasks if t.get("status") == "complete"}

        next_tasks = []
        for task in tasks:
            if task.get("status") != "pending":
                continue
            deps = task.get("depends_on", [])
            if all(dep in completed_ids for dep in deps):
                next_tasks.append(task)
        return next_tasks

    def get_blocked_tasks(self, plan_id: str) -> list[dict[str, Any]]:
        """Get tasks with at least one incomplete dependency."""
        tasks = self.get_tasks_for_plan(plan_id)
        completed_ids = {t["item_id"] for t in tasks if t.get("status") == "complete"}

        blocked = []
        for task in tasks:
            if task.get("status") == "complete":
                continue
            deps = task.get("depends_on", [])
            if deps and not all(dep in completed_ids for dep in deps):
                blocked.append(task)
        return blocked

    # ---- SQLite query paths ----

    def _get_tasks_sqlite(self, backend: Any, plan_id: str) -> list[dict[str, Any]]:
        """Direct SQLite query for plan tasks — uses idx_plan_task_plan_id index."""
        with backend._lock:
            cursor = backend._conn.execute(
                "SELECT item_id, properties FROM nodes "
                "WHERE memory_type = 'plan_task' "
                "AND json_extract(properties, '$.plan_id') = ?",
                (plan_id,),
            )
            rows = cursor.fetchall()
        return [self._to_task_dict(row) for row in rows]

    def _get_active_sqlite(self, backend: Any, limit: int) -> list[dict[str, Any]]:
        """Direct SQLite query for active plans — uses idx_plan_status index."""
        with backend._lock:
            cursor = backend._conn.execute(
                "SELECT item_id, properties FROM nodes "
                "WHERE memory_type = 'plan' "
                "AND json_extract(properties, '$.status') = 'active' "
                "LIMIT ?",
                (limit,),
            )
            rows = cursor.fetchall()
        return [self._to_plan_dict_from_row(row) for row in rows]

    # ---- Search fallbacks (FalkorDB / non-SQLite) ----

    def _get_tasks_search_fallback(self, plan_id: str) -> list[dict[str, Any]]:
        """Fallback: search + post-filter for non-SQLite backends."""
        try:
            items = self.memory.search(query="*", memory_type="plan_task", top_k=200)
        except Exception as e:
            logger.warning("Plan task search fallback failed (returning empty): %s", e)
            items = []
        return [
            self._to_task_dict_from_item(item)
            for item in items
            if getattr(item, "metadata", {}).get("plan_id") == plan_id
        ]

    def _get_active_search_fallback(self, limit: int) -> list[dict[str, Any]]:
        """Fallback: search + post-filter for non-SQLite backends."""
        try:
            items = self.memory.search(query="*", memory_type="plan", top_k=limit * 2)
        except Exception as e:
            logger.warning("Active plan search fallback failed (returning empty): %s", e)
            items = []
        plans = []
        for item in items:
            meta = getattr(item, "metadata", {})
            if meta.get("status") == "active":
                plans.append(self._to_plan_dict(item))
                if len(plans) >= limit:
                    break
        return plans

    # ---- Converters ----

    def _to_plan_dict(self, item: Any) -> dict[str, Any]:
        """Convert MemoryItem to plan dict."""
        metadata = getattr(item, "metadata", {}) or {}
        return {
            "item_id": getattr(item, "item_id", None),
            "content": getattr(item, "content", ""),
            "plan_id": metadata.get("plan_id", ""),
            "status": metadata.get("status", "active"),
            "total_tasks": metadata.get("total_tasks", 0),
            "completed_tasks": metadata.get("completed_tasks", 0),
            "context": metadata.get("context", ""),
            "created_by": metadata.get("created_by", ""),
        }

    def _to_plan_dict_from_row(self, row: tuple) -> dict[str, Any]:
        """Convert raw SQLite (item_id, properties_json) row to plan dict."""
        props = json.loads(row[1])
        return {
            "item_id": row[0],
            "content": props.get("content", ""),
            "plan_id": props.get("plan_id", ""),
            "status": props.get("status", "active"),
            "total_tasks": props.get("total_tasks", 0),
            "completed_tasks": props.get("completed_tasks", 0),
            "context": props.get("context", ""),
            "created_by": props.get("created_by", ""),
        }

    def _to_task_dict(self, row: tuple) -> dict[str, Any]:
        """Convert raw SQLite (item_id, properties_json) row to task dict."""
        props = json.loads(row[1])
        return {
            "item_id": row[0],
            "content": props.get("content", ""),
            "plan_id": props.get("plan_id", ""),
            "status": props.get("status", "pending"),
            "task_index": props.get("task_index"),
            "depends_on": props.get("depends_on", []),
        }

    def _to_task_dict_from_item(self, item: Any) -> dict[str, Any]:
        """Convert MemoryItem to task dict (for search fallback path)."""
        metadata = getattr(item, "metadata", {}) or {}
        return {
            "item_id": getattr(item, "item_id", None),
            "content": getattr(item, "content", ""),
            "plan_id": metadata.get("plan_id", ""),
            "status": metadata.get("status", "pending"),
            "task_index": metadata.get("task_index"),
            "depends_on": metadata.get("depends_on", []),
        }
