"""SQLiteOntologyStore — persistent ontology store for local mode.

Replaces InMemoryOntologyStore with SQLite-backed persistence. Entity types,
relation types, entity patterns, and novel relation labels survive daemon
restarts. Uses the same memory.db file as the graph backend.

DIST-FULL-LOCAL-1 Phase 2a.
"""

import json
import logging
import sqlite3
import threading
from datetime import datetime, UTC
from typing import Any, Dict, List, Optional

from smartmemory.ontology.in_memory_store import InMemoryOntologyStore, SEED_TYPES

logger = logging.getLogger(__name__)

_CREATE_ENTITY_TYPES = """
CREATE TABLE IF NOT EXISTS ontology_types (
    name_lower     TEXT PRIMARY KEY,
    name_display   TEXT NOT NULL,
    status         TEXT NOT NULL DEFAULT 'seed',
    frequency      INTEGER NOT NULL DEFAULT 0,
    avg_confidence REAL NOT NULL DEFAULT 0.0
)
"""

_CREATE_RELATION_TYPES = """
CREATE TABLE IF NOT EXISTS ontology_relation_types (
    name_lower     TEXT PRIMARY KEY,
    name_display   TEXT NOT NULL,
    status         TEXT NOT NULL DEFAULT 'provisional',
    category       TEXT NOT NULL DEFAULT 'unknown',
    frequency      INTEGER NOT NULL DEFAULT 0,
    aliases        TEXT DEFAULT '[]',
    type_pairs     TEXT DEFAULT '[]'
)
"""

_CREATE_ENTITY_PATTERNS = """
CREATE TABLE IF NOT EXISTS ontology_entity_patterns (
    name_lower     TEXT NOT NULL,
    label          TEXT NOT NULL,
    workspace_id   TEXT NOT NULL DEFAULT 'default',
    count          INTEGER NOT NULL DEFAULT 1,
    confidence     REAL NOT NULL DEFAULT 0.85,
    is_global      INTEGER NOT NULL DEFAULT 0,
    source         TEXT NOT NULL DEFAULT 'llm_discovery',
    discovered_at  TEXT,
    PRIMARY KEY (name_lower, label, workspace_id)
)
"""

_CREATE_NOVEL_RELATIONS = """
CREATE TABLE IF NOT EXISTS ontology_novel_relations (
    name_lower     TEXT NOT NULL,
    workspace_id   TEXT NOT NULL DEFAULT 'default',
    frequency      INTEGER NOT NULL DEFAULT 1,
    status         TEXT NOT NULL DEFAULT 'tracking',
    raw_examples   TEXT DEFAULT '[]',
    source_types   TEXT DEFAULT '[]',
    target_types   TEXT DEFAULT '[]',
    first_seen     TEXT,
    last_seen      TEXT,
    PRIMARY KEY (name_lower, workspace_id)
)
"""


def _now_iso() -> str:
    return datetime.now(UTC).isoformat()


class SQLiteOntologyStore(InMemoryOntologyStore):
    """Persistent ontology store backed by SQLite.

    Uses the same memory.db as the graph backend. Thread-safe via RLock.
    """

    def __init__(self, db_path: str, workspace_id: str = "default"):
        # Skip InMemoryOntologyStore.__init__ — we don't need in-memory dicts
        self.workspace_id = workspace_id
        self._lock = threading.RLock()
        self._conn = sqlite3.connect(db_path, check_same_thread=False)
        self._conn.execute("PRAGMA journal_mode=WAL")
        self._conn.execute("PRAGMA foreign_keys=ON")
        self._create_tables()
        self.seed_types()

    def _create_tables(self) -> None:
        with self._lock:
            self._conn.execute(_CREATE_ENTITY_TYPES)
            self._conn.execute(_CREATE_RELATION_TYPES)
            self._conn.execute(_CREATE_ENTITY_PATTERNS)
            self._conn.execute(_CREATE_NOVEL_RELATIONS)
            self._conn.commit()

    def close(self) -> None:
        """Close the SQLite connection."""
        try:
            self._conn.close()
        except Exception:
            pass

    # ── Entity Type Management ──────────────────────────────────────

    def seed_types(self, types: Optional[List[str]] = None) -> int:
        types_to_seed = types or SEED_TYPES
        created = 0
        with self._lock:
            for name in types_to_seed:
                try:
                    cur = self._conn.execute(
                        "INSERT OR IGNORE INTO ontology_types (name_lower, name_display, status) "
                        "VALUES (?, ?, 'seed')",
                        (name.lower(), name),
                    )
                    if cur.rowcount > 0:
                        created += 1
                except Exception:
                    pass
            self._conn.commit()
        return created

    def get_type_status(self, name: str) -> Optional[str]:
        with self._lock:
            row = self._conn.execute(
                "SELECT status FROM ontology_types WHERE name_lower=?",
                (name.lower(),),
            ).fetchone()
        return row[0] if row else None

    def add_provisional(self, name: str) -> bool:
        with self._lock:
            cursor = self._conn.execute(
                "INSERT OR IGNORE INTO ontology_types (name_lower, name_display, status) "
                "VALUES (?, ?, 'provisional')",
                (name.lower(), name),
            )
            self._conn.commit()
            return cursor.rowcount > 0

    def promote(self, name: str) -> bool:
        with self._lock:
            cursor = self._conn.execute(
                "UPDATE ontology_types SET status='confirmed' WHERE name_lower=?",
                (name.lower(),),
            )
            self._conn.commit()
            return cursor.rowcount > 0

    def reject(self, name: str) -> bool:
        with self._lock:
            cursor = self._conn.execute(
                "UPDATE ontology_types SET status='rejected' WHERE name_lower=?",
                (name.lower(),),
            )
            self._conn.commit()
            return cursor.rowcount > 0

    def increment_frequency(self, name: str, confidence: float) -> None:
        with self._lock:
            row = self._conn.execute(
                "SELECT frequency, avg_confidence FROM ontology_types WHERE name_lower=?",
                (name.lower(),),
            ).fetchone()
            if not row:
                return
            freq, avg_conf = row
            new_freq = freq + 1
            new_avg = (avg_conf * freq + confidence) / new_freq
            self._conn.execute(
                "UPDATE ontology_types SET frequency=?, avg_confidence=? WHERE name_lower=?",
                (new_freq, new_avg, name.lower()),
            )
            self._conn.commit()

    def get_frequency(self, name: str) -> int:
        with self._lock:
            row = self._conn.execute(
                "SELECT frequency FROM ontology_types WHERE name_lower=?",
                (name.lower(),),
            ).fetchone()
        return row[0] if row else 0

    def get_entity_types(self) -> List[Dict[str, Any]]:
        with self._lock:
            rows = self._conn.execute(
                "SELECT name_display, status, frequency, avg_confidence FROM ontology_types"
            ).fetchall()
        return [
            {"name": r[0], "status": r[1], "frequency": r[2], "avg_confidence": r[3]}
            for r in rows
        ]

    def get_all_frequencies(self) -> Dict[str, int]:
        with self._lock:
            rows = self._conn.execute(
                "SELECT name_display, frequency FROM ontology_types"
            ).fetchall()
        return {r[0]: r[1] for r in rows}

    # ── Relation Types ──────────────────────────────────────────────

    def increment_relation_frequency(self, name: str, confidence: float) -> None:
        key = name.lower()
        with self._lock:
            self._conn.execute(
                "INSERT OR IGNORE INTO ontology_relation_types "
                "(name_lower, name_display, status, category, frequency) "
                "VALUES (?, ?, 'provisional', 'unknown', 0)",
                (key, name),
            )
            self._conn.execute(
                "UPDATE ontology_relation_types SET frequency=frequency+1 WHERE name_lower=?",
                (key,),
            )
            self._conn.commit()

    def add_provisional_relation_type(self, name: str, category: str = "unknown") -> bool:
        with self._lock:
            cursor = self._conn.execute(
                "INSERT OR IGNORE INTO ontology_relation_types "
                "(name_lower, name_display, status, category) VALUES (?, ?, 'provisional', ?)",
                (name.lower(), name, category),
            )
            self._conn.commit()
            return cursor.rowcount > 0

    def get_relation_types(self, status: Optional[str] = None) -> List[Dict[str, Any]]:
        with self._lock:
            if status:
                rows = self._conn.execute(
                    "SELECT name_display, status, category, frequency, aliases, type_pairs "
                    "FROM ontology_relation_types WHERE status=?",
                    (status,),
                ).fetchall()
            else:
                rows = self._conn.execute(
                    "SELECT name_display, status, category, frequency, aliases, type_pairs "
                    "FROM ontology_relation_types"
                ).fetchall()
        return [
            {
                "name": r[0], "status": r[1], "category": r[2], "frequency": r[3],
                "aliases": json.loads(r[4] or "[]"), "type_pairs": json.loads(r[5] or "[]"),
            }
            for r in rows
        ]

    # ── Entity Patterns ─────────────────────────────────────────────

    def add_entity_pattern(self, name, label, confidence=0.85,
                           workspace_id=None, is_global=False,
                           source="llm_discovery", initial_count=1, **kwargs) -> bool:
        key = name.lower()
        ws = workspace_id or self.workspace_id
        now = _now_iso()
        with self._lock:
            existing = self._conn.execute(
                "SELECT count FROM ontology_entity_patterns "
                "WHERE name_lower=? AND label=? AND workspace_id=?",
                (key, label, ws),
            ).fetchone()
            if existing:
                self._conn.execute(
                    "UPDATE ontology_entity_patterns SET count=count+1 WHERE "
                    "name_lower=? AND label=? AND workspace_id=?",
                    (key, label, ws),
                )
                self._conn.commit()
                return False  # Updated, not new
            else:
                self._conn.execute(
                    "INSERT INTO ontology_entity_patterns "
                    "(name_lower, label, workspace_id, count, confidence, is_global, source, discovered_at) "
                    "VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                    (key, label, ws, initial_count, confidence, int(is_global), source, now),
                )
                self._conn.commit()
                return True  # New pattern

    def get_entity_patterns(self, workspace_id=None) -> List[Dict]:
        ws = workspace_id or self.workspace_id
        with self._lock:
            rows = self._conn.execute(
                "SELECT name_lower, label, confidence, count, source "
                "FROM ontology_entity_patterns "
                "WHERE (is_global=1 OR workspace_id=?) AND count>=2",
                (ws,),
            ).fetchall()
        return [
            {"name": r[0], "label": r[1], "confidence": r[2], "count": r[3], "source": r[4]}
            for r in rows
        ]

    def seed_entity_patterns(self, patterns=None) -> int:
        return 0  # Seed patterns handled by JSONLPatternStore

    def get_pattern_stats(self) -> Dict[str, int]:
        with self._lock:
            rows = self._conn.execute(
                "SELECT source, COUNT(*) FROM ontology_entity_patterns GROUP BY source"
            ).fetchall()
        return {r[0]: r[1] for r in rows}

    def get_type_assignments(self, entity_name: str) -> List[Dict]:
        """Return [{type, count}] matching OntologyGraph.get_type_assignments() shape."""
        with self._lock:
            rows = self._conn.execute(
                "SELECT label, count FROM ontology_entity_patterns "
                "WHERE name_lower=? AND (is_global=1 OR workspace_id=?)",
                (entity_name.lower(), self.workspace_id),
            ).fetchall()
        return [{"type": r[0], "count": r[1]} for r in rows]

    def delete_entity_pattern(self, name, label, workspace_id=None) -> bool:
        ws = workspace_id or self.workspace_id
        with self._lock:
            cursor = self._conn.execute(
                "DELETE FROM ontology_entity_patterns "
                "WHERE name_lower=? AND label=? AND workspace_id=?",
                (name.lower(), label, ws),
            )
            self._conn.commit()
            return cursor.rowcount > 0

    # ── Novel Relation Labels ───────────────────────────────────────

    def add_novel_relation_label(self, name, raw_examples=None,
                                  source_types=None, target_types=None,
                                  workspace_id=None, **kwargs) -> bool:
        key = name.lower()
        ws = workspace_id or self.workspace_id
        now = _now_iso()
        examples_json = json.dumps(raw_examples or [])
        src_json = json.dumps(source_types or [])
        tgt_json = json.dumps(target_types or [])

        with self._lock:
            existing = self._conn.execute(
                "SELECT frequency, raw_examples FROM ontology_novel_relations "
                "WHERE name_lower=? AND workspace_id=?",
                (key, ws),
            ).fetchone()
            if existing:
                freq = existing[0]
                old_examples = json.loads(existing[1] or "[]")
                # Append new examples, cap at 10
                merged = (old_examples + (raw_examples or []))[:10]
                self._conn.execute(
                    "UPDATE ontology_novel_relations SET "
                    "frequency=?, raw_examples=?, last_seen=? "
                    "WHERE name_lower=? AND workspace_id=?",
                    (freq + 1, json.dumps(merged), now, key, ws),
                )
                self._conn.commit()
                return False  # Updated
            else:
                self._conn.execute(
                    "INSERT INTO ontology_novel_relations "
                    "(name_lower, workspace_id, frequency, status, raw_examples, "
                    "source_types, target_types, first_seen, last_seen) "
                    "VALUES (?, ?, 1, 'tracking', ?, ?, ?, ?, ?)",
                    (key, ws, examples_json, src_json, tgt_json, now, now),
                )
                self._conn.commit()
                return True  # New

    def get_novel_relation_labels(self, min_frequency=1, status=None,
                                   workspace_id=None) -> List[Dict]:
        ws = workspace_id or self.workspace_id
        with self._lock:
            if status:
                rows = self._conn.execute(
                    "SELECT name_lower, frequency, status, raw_examples, "
                    "source_types, target_types, first_seen, last_seen "
                    "FROM ontology_novel_relations "
                    "WHERE frequency>=? AND status=? AND workspace_id=?",
                    (min_frequency, status, ws),
                ).fetchall()
            else:
                rows = self._conn.execute(
                    "SELECT name_lower, frequency, status, raw_examples, "
                    "source_types, target_types, first_seen, last_seen "
                    "FROM ontology_novel_relations "
                    "WHERE frequency>=? AND workspace_id=?",
                    (min_frequency, ws),
                ).fetchall()
        return [
            {
                "name": r[0], "frequency": r[1], "status": r[2],
                "raw_examples": json.loads(r[3] or "[]"),
                "source_types": json.loads(r[4] or "[]"),
                "target_types": json.loads(r[5] or "[]"),
                "first_seen": r[6], "last_seen": r[7],
            }
            for r in rows
        ]

    def promote_relation_type(self, name, category="discovered",
                               aliases=None, type_pairs=None,
                               workspace_id=None, **kwargs) -> bool:
        key = name.lower()
        ws = workspace_id or self.workspace_id
        aliases_json = json.dumps(aliases or [])
        type_pairs_json = json.dumps(type_pairs or [])
        with self._lock:
            # Upsert: preserve frequency on conflict (INSERT OR REPLACE would drop it)
            self._conn.execute(
                "INSERT INTO ontology_relation_types "
                "(name_lower, name_display, status, category, aliases, type_pairs) "
                "VALUES (?, ?, 'confirmed', ?, ?, ?) "
                "ON CONFLICT(name_lower) DO UPDATE SET "
                "status='confirmed', name_display=excluded.name_display, "
                "category=excluded.category, "
                "aliases=excluded.aliases, type_pairs=excluded.type_pairs",
                (key, name, category, aliases_json, type_pairs_json),
            )
            # Update novel label status — scoped to workspace
            self._conn.execute(
                "UPDATE ontology_novel_relations SET status='promoted' "
                "WHERE name_lower=? AND workspace_id=?",
                (key, ws),
            )
            self._conn.commit()
            return True
