"""
wagtail-herald template tags.
"""
