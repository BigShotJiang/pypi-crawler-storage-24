"""Birds vs Bats - Terminal ASCII art game."""
__version__ = "1.0.1"
