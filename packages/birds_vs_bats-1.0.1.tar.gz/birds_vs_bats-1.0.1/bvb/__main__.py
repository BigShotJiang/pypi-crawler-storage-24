#!/usr/bin/env python3
"""Entry point for `python -m bvb` and `birds-vs-bats` CLI command."""

import os
import sys


def main():
    # bvb package directory (where config.yml lives when installed via pip)
    pkg_dir = os.path.dirname(os.path.abspath(__file__))
    # project root (parent of bvb/ when running from source)
    project_root = os.path.dirname(pkg_dir)
    # site-packages (parent of bvb/ when installed via pip)
    site_packages = os.path.dirname(pkg_dir)

    # Find config.yml - try multiple locations
    found = False
    for candidate in [pkg_dir, project_root, os.getcwd()]:
        if os.path.exists(os.path.join(candidate, 'config.yml')):
            os.chdir(candidate)
            found = True
            break

    if not found:
        print(f"ERROR: config.yml not found in any of:")
        print(f"  - {pkg_dir}")
        print(f"  - {project_root}")
        print(f"  - {os.getcwd()}")
        sys.exit(1)

    # Ensure src package and game.py are importable
    # When installed via pip, game.py and src/ are in site-packages
    if site_packages not in sys.path:
        sys.path.insert(0, site_packages)
    if project_root not in sys.path:
        sys.path.insert(0, project_root)

    from game import main as game_main
    game_main()


if __name__ == '__main__':
    main()
