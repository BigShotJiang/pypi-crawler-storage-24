"""
Type annotations for polly service type definitions.

[Documentation](https://youtype.github.io/types_boto3_docs/types_boto3_polly/type_defs/)

Copyright 2026 Vlad Emelianov

Usage::

    ```python
    from types_boto3_polly.type_defs import AudioEventTypeDef

    data: AudioEventTypeDef = ...
    ```
"""

from __future__ import annotations

import sys
from collections.abc import Mapping, Sequence
from datetime import datetime
from typing import Any

from botocore.eventstream import EventStream
from botocore.response import StreamingBody

from .literals import (
    EngineType,
    GenderType,
    LanguageCodeType,
    OutputFormatType,
    QuotaCodeType,
    SpeechMarkTypeType,
    TaskStatusType,
    TextTypeType,
    ValidationExceptionReasonType,
    VoiceIdType,
)

if sys.version_info >= (3, 12):
    from typing import Literal, NotRequired, TypedDict
else:
    from typing_extensions import Literal, NotRequired, TypedDict


__all__ = (
    "AudioEventTypeDef",
    "DeleteLexiconInputTypeDef",
    "DescribeVoicesInputPaginateTypeDef",
    "DescribeVoicesInputTypeDef",
    "DescribeVoicesOutputTypeDef",
    "FlushStreamConfigurationTypeDef",
    "GetLexiconInputTypeDef",
    "GetLexiconOutputTypeDef",
    "GetSpeechSynthesisTaskInputTypeDef",
    "GetSpeechSynthesisTaskOutputTypeDef",
    "LexiconAttributesTypeDef",
    "LexiconDescriptionTypeDef",
    "LexiconTypeDef",
    "ListLexiconsInputPaginateTypeDef",
    "ListLexiconsInputTypeDef",
    "ListLexiconsOutputTypeDef",
    "ListSpeechSynthesisTasksInputPaginateTypeDef",
    "ListSpeechSynthesisTasksInputTypeDef",
    "ListSpeechSynthesisTasksOutputTypeDef",
    "PaginatorConfigTypeDef",
    "PutLexiconInputTypeDef",
    "ResponseMetadataTypeDef",
    "ServiceFailureExceptionTypeDef",
    "ServiceQuotaExceededExceptionTypeDef",
    "StartSpeechSynthesisStreamActionStreamTypeDef",
    "StartSpeechSynthesisStreamEventStreamTypeDef",
    "StartSpeechSynthesisStreamInputTypeDef",
    "StartSpeechSynthesisStreamOutputTypeDef",
    "StartSpeechSynthesisTaskInputTypeDef",
    "StartSpeechSynthesisTaskOutputTypeDef",
    "StreamClosedEventTypeDef",
    "SynthesisTaskTypeDef",
    "SynthesizeSpeechInputTypeDef",
    "SynthesizeSpeechOutputTypeDef",
    "TextEventTypeDef",
    "ThrottlingExceptionTypeDef",
    "ThrottlingReasonTypeDef",
    "ValidationExceptionFieldTypeDef",
    "ValidationExceptionTypeDef",
    "VoiceTypeDef",
)


class AudioEventTypeDef(TypedDict):
    AudioChunk: NotRequired[bytes]


class DeleteLexiconInputTypeDef(TypedDict):
    Name: str


class PaginatorConfigTypeDef(TypedDict):
    MaxItems: NotRequired[int]
    PageSize: NotRequired[int]
    StartingToken: NotRequired[str]


class DescribeVoicesInputTypeDef(TypedDict):
    Engine: NotRequired[EngineType]
    LanguageCode: NotRequired[LanguageCodeType]
    IncludeAdditionalLanguageCodes: NotRequired[bool]
    NextToken: NotRequired[str]


class ResponseMetadataTypeDef(TypedDict):
    RequestId: str
    HTTPStatusCode: int
    HTTPHeaders: dict[str, str]
    RetryAttempts: int
    HostId: NotRequired[str]


class VoiceTypeDef(TypedDict):
    Gender: NotRequired[GenderType]
    Id: NotRequired[VoiceIdType]
    LanguageCode: NotRequired[LanguageCodeType]
    LanguageName: NotRequired[str]
    Name: NotRequired[str]
    AdditionalLanguageCodes: NotRequired[list[LanguageCodeType]]
    SupportedEngines: NotRequired[list[EngineType]]


class FlushStreamConfigurationTypeDef(TypedDict):
    Force: NotRequired[bool]


class GetLexiconInputTypeDef(TypedDict):
    Name: str


class LexiconAttributesTypeDef(TypedDict):
    Alphabet: NotRequired[str]
    LanguageCode: NotRequired[LanguageCodeType]
    LastModified: NotRequired[datetime]
    LexiconArn: NotRequired[str]
    LexemesCount: NotRequired[int]
    Size: NotRequired[int]


class LexiconTypeDef(TypedDict):
    Content: NotRequired[str]
    Name: NotRequired[str]


class GetSpeechSynthesisTaskInputTypeDef(TypedDict):
    TaskId: str


class SynthesisTaskTypeDef(TypedDict):
    Engine: NotRequired[EngineType]
    TaskId: NotRequired[str]
    TaskStatus: NotRequired[TaskStatusType]
    TaskStatusReason: NotRequired[str]
    OutputUri: NotRequired[str]
    CreationTime: NotRequired[datetime]
    RequestCharacters: NotRequired[int]
    SnsTopicArn: NotRequired[str]
    LexiconNames: NotRequired[list[str]]
    OutputFormat: NotRequired[OutputFormatType]
    SampleRate: NotRequired[str]
    SpeechMarkTypes: NotRequired[list[SpeechMarkTypeType]]
    TextType: NotRequired[TextTypeType]
    VoiceId: NotRequired[VoiceIdType]
    LanguageCode: NotRequired[LanguageCodeType]


class ListLexiconsInputTypeDef(TypedDict):
    NextToken: NotRequired[str]


class ListSpeechSynthesisTasksInputTypeDef(TypedDict):
    MaxResults: NotRequired[int]
    NextToken: NotRequired[str]
    Status: NotRequired[TaskStatusType]


class PutLexiconInputTypeDef(TypedDict):
    Name: str
    Content: str


class ServiceFailureExceptionTypeDef(TypedDict):
    message: NotRequired[str]


class ServiceQuotaExceededExceptionTypeDef(TypedDict):
    message: str
    quotaCode: QuotaCodeType
    serviceCode: Literal["polly"]


class StreamClosedEventTypeDef(TypedDict):
    RequestCharacters: NotRequired[int]


StartSpeechSynthesisTaskInputTypeDef = TypedDict(
    "StartSpeechSynthesisTaskInputTypeDef",
    {
        "OutputFormat": OutputFormatType,
        "OutputS3BucketName": str,
        "Text": str,
        "VoiceId": VoiceIdType,
        "Engine": NotRequired[EngineType],
        "LanguageCode": NotRequired[LanguageCodeType],
        "LexiconNames": NotRequired[Sequence[str]],
        "OutputS3KeyPrefix": NotRequired[str],
        "SampleRate": NotRequired[str],
        "SnsTopicArn": NotRequired[str],
        "SpeechMarkTypes": NotRequired[Sequence[SpeechMarkTypeType]],
        "TextType": NotRequired[TextTypeType],
    },
)
SynthesizeSpeechInputTypeDef = TypedDict(
    "SynthesizeSpeechInputTypeDef",
    {
        "OutputFormat": OutputFormatType,
        "Text": str,
        "VoiceId": VoiceIdType,
        "Engine": NotRequired[EngineType],
        "LanguageCode": NotRequired[LanguageCodeType],
        "LexiconNames": NotRequired[Sequence[str]],
        "SampleRate": NotRequired[str],
        "SpeechMarkTypes": NotRequired[Sequence[SpeechMarkTypeType]],
        "TextType": NotRequired[TextTypeType],
    },
)


class ThrottlingReasonTypeDef(TypedDict):
    reason: NotRequired[str]
    resource: NotRequired[str]


class ValidationExceptionFieldTypeDef(TypedDict):
    name: str
    message: str


class DescribeVoicesInputPaginateTypeDef(TypedDict):
    Engine: NotRequired[EngineType]
    LanguageCode: NotRequired[LanguageCodeType]
    IncludeAdditionalLanguageCodes: NotRequired[bool]
    PaginationConfig: NotRequired[PaginatorConfigTypeDef]


class ListLexiconsInputPaginateTypeDef(TypedDict):
    PaginationConfig: NotRequired[PaginatorConfigTypeDef]


class ListSpeechSynthesisTasksInputPaginateTypeDef(TypedDict):
    Status: NotRequired[TaskStatusType]
    PaginationConfig: NotRequired[PaginatorConfigTypeDef]


class SynthesizeSpeechOutputTypeDef(TypedDict):
    AudioStream: StreamingBody
    ContentType: str
    RequestCharacters: int
    ResponseMetadata: ResponseMetadataTypeDef


class DescribeVoicesOutputTypeDef(TypedDict):
    Voices: list[VoiceTypeDef]
    ResponseMetadata: ResponseMetadataTypeDef
    NextToken: NotRequired[str]


TextEventTypeDef = TypedDict(
    "TextEventTypeDef",
    {
        "Text": str,
        "TextType": NotRequired[TextTypeType],
        "FlushStreamConfiguration": NotRequired[FlushStreamConfigurationTypeDef],
    },
)


class LexiconDescriptionTypeDef(TypedDict):
    Name: NotRequired[str]
    Attributes: NotRequired[LexiconAttributesTypeDef]


class GetLexiconOutputTypeDef(TypedDict):
    Lexicon: LexiconTypeDef
    LexiconAttributes: LexiconAttributesTypeDef
    ResponseMetadata: ResponseMetadataTypeDef


class GetSpeechSynthesisTaskOutputTypeDef(TypedDict):
    SynthesisTask: SynthesisTaskTypeDef
    ResponseMetadata: ResponseMetadataTypeDef


class ListSpeechSynthesisTasksOutputTypeDef(TypedDict):
    SynthesisTasks: list[SynthesisTaskTypeDef]
    ResponseMetadata: ResponseMetadataTypeDef
    NextToken: NotRequired[str]


class StartSpeechSynthesisTaskOutputTypeDef(TypedDict):
    SynthesisTask: SynthesisTaskTypeDef
    ResponseMetadata: ResponseMetadataTypeDef


class ThrottlingExceptionTypeDef(TypedDict):
    message: NotRequired[str]
    throttlingReasons: NotRequired[list[ThrottlingReasonTypeDef]]


class ValidationExceptionTypeDef(TypedDict):
    message: str
    reason: ValidationExceptionReasonType
    fields: NotRequired[list[ValidationExceptionFieldTypeDef]]


class StartSpeechSynthesisStreamActionStreamTypeDef(TypedDict):
    TextEvent: NotRequired[TextEventTypeDef]
    CloseStreamEvent: NotRequired[Mapping[str, Any]]


class ListLexiconsOutputTypeDef(TypedDict):
    Lexicons: list[LexiconDescriptionTypeDef]
    ResponseMetadata: ResponseMetadataTypeDef
    NextToken: NotRequired[str]


class StartSpeechSynthesisStreamEventStreamTypeDef(TypedDict):
    AudioEvent: NotRequired[AudioEventTypeDef]
    StreamClosedEvent: NotRequired[StreamClosedEventTypeDef]
    ValidationException: NotRequired[ValidationExceptionTypeDef]
    ServiceQuotaExceededException: NotRequired[ServiceQuotaExceededExceptionTypeDef]
    ServiceFailureException: NotRequired[ServiceFailureExceptionTypeDef]
    ThrottlingException: NotRequired[ThrottlingExceptionTypeDef]


class StartSpeechSynthesisStreamInputTypeDef(TypedDict):
    Engine: EngineType
    OutputFormat: OutputFormatType
    VoiceId: VoiceIdType
    LanguageCode: NotRequired[LanguageCodeType]
    LexiconNames: NotRequired[Sequence[str]]
    SampleRate: NotRequired[str]
    ActionStream: NotRequired[EventStream[StartSpeechSynthesisStreamActionStreamTypeDef]]


class StartSpeechSynthesisStreamOutputTypeDef(TypedDict):
    EventStream: EventStream[StartSpeechSynthesisStreamEventStreamTypeDef]
    ResponseMetadata: ResponseMetadataTypeDef
