import json
import math

from ab.nn.util.Const import *
from ab.nn.util.Util import is_full_config, str_not_none
from ab.nn.util.db.Init import sql_conn, close_conn
from ab.nn.util.db.Write import init_population

from ab.nn.util.db.Query import *

init_population()


def query_cursor_cols_rows(*q) -> tuple[list, list]:
    conn, cursor = sql_conn()
    cursor.execute(*q)
    rows = cursor.fetchall()
    # Extract column names from cursor description.
    columns = [col[0] for col in cursor.description]
    close_conn(conn)
    return columns, rows


def query_rows(*q):
    conn, cursor = sql_conn()
    cursor.execute(*q)
    rows = cursor.fetchall()
    close_conn(conn)
    return [tuple([s for s in r]) for r in rows]


def query_cols_rows(q) -> tuple[list, list]:
    rows = query_rows(q)
    # Since each row is a tuple (with one element), you can simply use row[0]
    columns = [row[0] for row in rows]
    return columns, rows


def code(table: str, nm: str) -> str:
    return query_rows(f'SELECT code FROM {table} where name = ?', [nm])[0][0]

def nn_code(nm: str) -> str:
    return code('nn', nm)

def data(only_best_accuracy: bool = False,
         task: Optional[str] = None,
         dataset: Optional[str] = None,
         metric: Optional[str] = None,
         nn: Optional[str | tuple[str]] = None,
         epoch: Optional[int] = None,
         max_rows: Optional[int] = None,
         nn_prefixes: Optional[tuple] = None,
         sql: Optional[JoinConf] = None,
         unique_nn: bool = False,
         include_nn_stats: bool = False,
         ) -> tuple[
    dict[str, int | float | str | dict[str, int | float | str]], ...
]:
    """
    Get the NN model code and all related statistics from the database.

    - If only_best_accuracy == True, then for every unique combination of
      (task, dataset, metric, nn, epoch) only the row with the highest accuracy is returned.
    - If only_best_accuracy == False, all matching rows are returned.
    - Additionally, if any of the parameters (task, dataset, metric, nn, epoch) is not None,
      the results are filtered accordingly in the SQL query.

    Each returned dictionary has the following keys:
      - 'task': str
      - 'dataset': str
      - 'metric': str
      - 'metric_code': str    (source code from the metric table)
      - 'nn': str or tuple[str]
      - 'nn_code': str        (source code from the nn table)
      - 'epoch': int
      - 'accuracy': float
      - 'duration': int
      - 'prm': dict           (hyperparameters, reconstructed from the "prm" table)
      - 'transform_code': str (source code from the transform table)

    If include_nn_stats == True, additional NN statistics fields are included:
      - 'nn_total_params': int        (total model parameters)
      - 'nn_trainable_params': int    (trainable parameters)
      - 'nn_frozen_params': int       (frozen parameters)
      - 'nn_total_layers': int        (total number of layers)
      - 'nn_leaf_layers': int         (number of leaf layers)
      - 'nn_max_depth': int           (maximum depth of the model)
      - 'nn_flops': int               (floating point operations)
      - 'nn_model_size_mb': float     (model size in MB)
      - 'nn_buffer_size_mb': float    (buffer size in MB)
      - 'nn_total_memory_mb': float   (total memory in MB)
      - 'nn_dropout_count': int       (number of dropout layers)
      - 'nn_has_attention': bool      (has attention mechanism)
      - 'nn_has_residual': bool       (has residual connections)
      - 'nn_is_resnet_like': bool     (ResNet-like architecture)
      - 'nn_is_vgg_like': bool        (VGG-like architecture)
      - 'nn_is_inception_like': bool  (Inception-like architecture)
      - 'nn_is_densenet_like': bool   (DenseNet-like architecture)
      - 'nn_is_unet_like': bool       (U-Net-like architecture)
      - 'nn_is_transformer_like': bool (Transformer-like architecture)
      - 'nn_is_mobilenet_like': bool  (MobileNet-like architecture)
      - 'nn_is_efficientnet_like': bool (EfficientNet-like architecture)
      - 'nn_code_length': int         (length of code in characters)
      - 'nn_num_classes': int         (number of classes defined)
      - 'nn_num_functions': int       (number of functions defined)
      - 'nn_uses_sequential': bool    (uses Sequential module)
      - 'nn_uses_modulelist': bool    (uses ModuleList)
      - 'nn_uses_moduledict': bool    (uses ModuleDict)
      - 'nn_stats_meta': dict         (additional metadata as JSON)
      - 'nn_stats_error': str         (error message if statistics failed)
    """

    # Build filtering conditions based on provided parameters.
    params, where_clause = sql_where([task, dataset, metric, nn, epoch])
    if nn_prefixes:
        where_clause += ' AND (' + ' OR '.join([f"nn LIKE '{prefix}%'" for prefix in nn_prefixes]) + ')'

    source = f'(SELECT s.* FROM stat s {where_clause})'
    if unique_nn:
        source = f'(SELECT * FROM (SELECT *, ROW_NUMBER() OVER (PARTITION BY nn ORDER BY accuracy DESC) rn FROM {source}) WHERE rn = 1)'
    if only_best_accuracy:
        source = """
            (WITH filtered_stat AS {source}
            SELECT f.* FROM filtered_stat f
            JOIN (
                SELECT task, dataset, metric, nn, epoch, MAX(accuracy) AS max_accuracy
                FROM filtered_stat
                GROUP BY task, dataset, metric, nn, epoch
            ) b
            ON f.task = b.task AND f.dataset = b.dataset AND f.metric = b.metric
               AND f.nn = b.nn AND f.epoch = b.epoch AND f.accuracy = b.max_accuracy
        )""".format(source=source)

    # Build the SELECT clause based on whether nn_stats are requested
    if include_nn_stats:
        select_clause = """
            SELECT s.id, s.task, s.dataset, s.metric, m.code AS metric_code, m.id AS metric_id,
                   s.nn, n.code AS nn_code, n.id AS nn_id, s.epoch, s.accuracy, s.duration,
                   s.prm AS prm_id, t.code AS transform_code, t.id AS transform_id, s.transform,
                   ns.total_params AS nn_total_params,
                   ns.trainable_params AS nn_trainable_params,
                   ns.frozen_params AS nn_frozen_params,
                   ns.total_layers AS nn_total_layers,
                   ns.leaf_layers AS nn_leaf_layers,
                   ns.max_depth AS nn_max_depth,
                   ns.flops AS nn_flops,
                   ns.model_size_mb AS nn_model_size_mb,
                   ns.buffer_size_mb AS nn_buffer_size_mb,
                   ns.total_memory_mb AS nn_total_memory_mb,
                   ns.dropout_count AS nn_dropout_count,
                   ns.has_attention AS nn_has_attention,
                   ns.has_residual_connections AS nn_has_residual,
                   ns.is_resnet_like AS nn_is_resnet_like,
                   ns.is_vgg_like AS nn_is_vgg_like,
                   ns.is_inception_like AS nn_is_inception_like,
                   ns.is_densenet_like AS nn_is_densenet_like,
                   ns.is_unet_like AS nn_is_unet_like,
                   ns.is_transformer_like AS nn_is_transformer_like,
                   ns.is_mobilenet_like AS nn_is_mobilenet_like,
                   ns.is_efficientnet_like AS nn_is_efficientnet_like,
                   ns.code_length AS nn_code_length,
                   ns.num_classes_defined AS nn_num_classes,
                   ns.num_functions_defined AS nn_num_functions,
                   ns.uses_sequential AS nn_uses_sequential,
                   ns.uses_modulelist AS nn_uses_modulelist,
                   ns.uses_moduledict AS nn_uses_moduledict,
                   ns.meta_json AS nn_stats_meta,
                   ns.error AS nn_stats_error
        """
        join_clause = """
            FROM {source} s
            LEFT JOIN nn       n ON s.nn = n.name
            LEFT JOIN metric   m ON s.metric = m.name
            LEFT JOIN transform t ON s.transform = t.name
            LEFT JOIN nn_stat ns ON s.nn = ns.nn_name
        """
    else:
        select_clause = """
            SELECT s.id, s.task, s.dataset, s.metric, m.code AS metric_code, m.id AS metric_id,
                   s.nn, n.code AS nn_code, n.id AS nn_id, s.epoch, s.accuracy, s.duration,
                   s.prm AS prm_id, t.code AS transform_code, t.id AS transform_id, s.transform
        """
        join_clause = """
            FROM {source} s
            LEFT JOIN nn       n ON s.nn = n.name
            LEFT JOIN metric   m ON s.metric = m.name
            LEFT JOIN transform t ON s.transform = t.name
        """

    base_query = select_clause + join_clause.format(source=source)

    limit_clause = str_not_none('LIMIT ', max_rows)

    # Execute a *single* query for the main stat rows
    conn = None
    try:
        conn, cur = sql_conn()
        if sql: cur.execute(f'DROP TABLE IF EXISTS {tmp_data}')
        cur.execute(f'CREATE TEMP TABLE {tmp_data} AS {base_query} ORDER BY RANDOM()' if sql else
                    f'''{base_query}
                        ORDER BY s.task, s.dataset, s.metric, s.nn, s.epoch
                        {limit_clause}''',
                    params)
        if sql:
            results = join_nn_query(sql,limit_clause, cur)
        else:
            results = fill_hyper_prm(cur, include_nn_stats=include_nn_stats)
        return tuple(results)
    finally:
        if conn: close_conn(conn)


_NN_STAT_OUTPUT_TO_COL: dict[str, str] = {
    'nn_total_params': 'total_params',
    'nn_trainable_params': 'trainable_params',
    'nn_frozen_params': 'frozen_params',
    'nn_total_layers': 'total_layers',
    'nn_leaf_layers': 'leaf_layers',
    'nn_max_depth': 'max_depth',
    'nn_flops': 'flops',
    'nn_model_size_mb': 'model_size_mb',
    'nn_buffer_size_mb': 'buffer_size_mb',
    'nn_total_memory_mb': 'total_memory_mb',
    'nn_dropout_count': 'dropout_count',
    'nn_has_attention': 'has_attention',
    'nn_has_residual': 'has_residual_connections',
    'nn_is_resnet_like': 'is_resnet_like',
    'nn_is_vgg_like': 'is_vgg_like',
    'nn_is_inception_like': 'is_inception_like',
    'nn_is_densenet_like': 'is_densenet_like',
    'nn_is_unet_like': 'is_unet_like',
    'nn_is_transformer_like': 'is_transformer_like',
    'nn_is_mobilenet_like': 'is_mobilenet_like',
    'nn_is_efficientnet_like': 'is_efficientnet_like',
    'nn_code_length': 'code_length',
    'nn_num_classes': 'num_classes_defined',
    'nn_num_functions': 'num_functions_defined',
    'nn_uses_sequential': 'uses_sequential',
    'nn_uses_modulelist': 'uses_modulelist',
    'nn_uses_moduledict': 'uses_moduledict',
    'nn_stats_meta': 'meta_json',
    'nn_stats_error': 'error',
}
_NN_STAT_COL_SET: frozenset[str] = frozenset(_NN_STAT_OUTPUT_TO_COL.values())
_NN_STAT_COL_TO_OUT: dict[str, str] = {c: a for a, c in _NN_STAT_OUTPUT_TO_COL.items()}
_STAT_NONNULL_COLS: frozenset[str] = frozenset(
    {'id', 'task', 'dataset', 'metric', 'nn', 'epoch', 'accuracy', 'duration', 'transform', 'prm'}
)


def _resolve_nn_stat_sql_col(name: str) -> str:
    if name in _NN_STAT_OUTPUT_TO_COL:
        return _NN_STAT_OUTPUT_TO_COL[name]
    if name in _NN_STAT_COL_SET:
        return name
    raise ValueError(f"Unknown nn_stat column or alias: {name!r}")


def _nn_stat_out_alias(sql_col: str) -> str:
    return _NN_STAT_COL_TO_OUT.get(sql_col, f'nn_{sql_col}')


def _is_nullish(v) -> bool:
    if v is None:
        return True
    if isinstance(v, float) and math.isnan(v):
        return True
    return False


def _row_passes_nonnull(
    rec: dict,
    require_stat_nonnull: tuple[str, ...],
    require_nn_stat_nonnull: tuple[str, ...],
    require_prm_nonnull: tuple[str, ...],
) -> bool:
    for c in require_stat_nonnull:
        key = 'prm_id' if c == 'prm' else c
        if key not in rec or _is_nullish(rec[key]):
            return False
    for name in require_nn_stat_nonnull:
        sqlc = _resolve_nn_stat_sql_col(name)
        out = _nn_stat_out_alias(sqlc)
        if out not in rec or _is_nullish(rec[out]):
            return False
    prm = rec.get('prm') or {}
    for k in require_prm_nonnull:
        if k not in prm or _is_nullish(prm[k]):
            return False
    return True


def _assemble_rows_without_prm_bulk(
    cur, include_nn_stats: bool
) -> list[dict]:
    rows = cur.fetchall()
    if not rows:
        return []
    columns = [c[0] for c in cur.description]
    results = []
    for r in rows:
        rec = dict(zip(columns, r))
        rec['prm'] = {}
        if include_nn_stats and rec.get('nn_stats_meta'):
            try:
                rec['nn_stats_meta'] = json.loads(rec['nn_stats_meta'])
            except Exception:
                rec['nn_stats_meta'] = None
        results.append(rec)
    return results


def data_withnonnullvalue(
    only_best_accuracy: bool = False,
    task: Optional[str] = None,
    dataset: Optional[str] = None,
    metric: Optional[str] = None,
    nn: Optional[str | tuple[str]] = None,
    epoch: Optional[int] = None,
    max_rows: Optional[int] = None,
    nn_prefixes: Optional[tuple] = None,
    sql: Optional[JoinConf] = None,
    unique_nn: bool = False,
    include_nn_stats: bool = False,
    include_prm: bool = True,
    require_stat_nonnull: tuple[str, ...] = (),
    require_nn_stat_nonnull: tuple[str, ...] = (),
    require_prm_nonnull: tuple[str, ...] = (),
    prm_as_columns: bool = False,
) -> tuple[dict[str, int | float | str | bool | dict | None], ...]:
    """
    Like :func:`data`, but can restrict rows to those where chosen ``stat``, ``nn_stat``,
    and ``prm`` fields are non-NULL (and non-NaN for numeric values after load).

    - ``include_nn_stats``: when True, selects all architecture-stat columns (same as ``data``).
    - ``include_prm``: when True, attaches the hyperparameter dict from the ``prm`` table;
      when False, ``prm`` is left as ``{}`` (faster if you only need stat / nn_stat).
    - ``require_stat_nonnull``: names of ``stat`` columns that must be NOT NULL
      (use ``'prm'`` for the FK column; it appears as ``prm_id`` in the row dict before
      ``prm`` is filled).
    - ``require_nn_stat_nonnull``: ``nn_*`` output names (e.g. ``nn_flops``) or raw ``nn_stat``
      column names; implies a join to ``nn_stat`` on ``nn_name`` and ``prm_id``.
    - ``require_prm_nonnull``: hyperparameter names that must exist on the row's config and
      be non-null / non-NaN.

    If ``sql`` is not ``None``, use :func:`data` instead (not supported here).
    """
    if sql is not None:
        raise ValueError("data_withnonnullvalue does not support sql=JoinConf; use data() instead.")

    for c in require_stat_nonnull:
        if c not in _STAT_NONNULL_COLS:
            raise ValueError(f"require_stat_nonnull: unknown stat column {c!r}")

    for name in require_nn_stat_nonnull:
        _resolve_nn_stat_sql_col(name)

    need_nn_stat_join = include_nn_stats or bool(require_nn_stat_nonnull)
    nn_stat_inner = bool(require_nn_stat_nonnull)

    params, where_clause = sql_where([task, dataset, metric, nn, epoch])
    if nn_prefixes:
        where_clause += ' AND (' + ' OR '.join([f"nn LIKE '{prefix}%'" for prefix in nn_prefixes]) + ')'

    extra_where: list[str] = []
    for c in require_stat_nonnull:
        col = 'prm' if c == 'prm' else c
        extra_where.append(f's.{col} IS NOT NULL')

    prm_params: list = []
    for pk in require_prm_nonnull:
        extra_where.append(
            'EXISTS (SELECT 1 FROM prm p WHERE p.uid = s.prm AND p.name = ? AND p.value IS NOT NULL)'
        )
        prm_params.append(pk)

    if require_nn_stat_nonnull:
        seen_nn: set[str] = set()
        nn_null_parts: list[str] = []
        for name in require_nn_stat_nonnull:
            sqlc = _resolve_nn_stat_sql_col(name)
            if sqlc in seen_nn:
                continue
            seen_nn.add(sqlc)
            nn_null_parts.append(f'ns.{sqlc} IS NOT NULL')
        extra_where.append(
            'EXISTS (SELECT 1 FROM nn_stat ns WHERE ns.nn_name = s.nn AND ns.prm_id = s.prm AND '
            + ' AND '.join(nn_null_parts)
            + ')'
        )

    if extra_where:
        where_clause += (' AND ' if where_clause else ' WHERE ') + ' AND '.join(extra_where)

    source = f'(SELECT s.* FROM stat s {where_clause})'
    if unique_nn:
        source = (
            f'(SELECT * FROM (SELECT *, ROW_NUMBER() OVER (PARTITION BY nn ORDER BY accuracy DESC) rn '
            f'FROM {source}) WHERE rn = 1)'
        )
    if only_best_accuracy:
        source = """
            (WITH filtered_stat AS {source}
            SELECT f.* FROM filtered_stat f
            JOIN (
                SELECT task, dataset, metric, nn, epoch, MAX(accuracy) AS max_accuracy
                FROM filtered_stat
                GROUP BY task, dataset, metric, nn, epoch
            ) b
            ON f.task = b.task AND f.dataset = b.dataset AND f.metric = b.metric
               AND f.nn = b.nn AND f.epoch = b.epoch AND f.accuracy = b.max_accuracy
        )""".format(source=source)

    join_nn_stat = ''
    if need_nn_stat_join:
        join_kw = 'INNER JOIN' if nn_stat_inner else 'LEFT JOIN'
        join_nn_stat = f"""
            {join_kw} nn_stat ns ON s.nn = ns.nn_name AND s.prm = ns.prm_id
        """

    if include_nn_stats:
        select_clause = """
            SELECT s.id, s.task, s.dataset, s.metric, m.code AS metric_code, m.id AS metric_id,
                   s.nn, n.code AS nn_code, n.id AS nn_id, s.epoch, s.accuracy, s.duration,
                   s.prm AS prm_id, t.code AS transform_code, t.id AS transform_id, s.transform,
                   ns.total_params AS nn_total_params,
                   ns.trainable_params AS nn_trainable_params,
                   ns.frozen_params AS nn_frozen_params,
                   ns.total_layers AS nn_total_layers,
                   ns.leaf_layers AS nn_leaf_layers,
                   ns.max_depth AS nn_max_depth,
                   ns.flops AS nn_flops,
                   ns.model_size_mb AS nn_model_size_mb,
                   ns.buffer_size_mb AS nn_buffer_size_mb,
                   ns.total_memory_mb AS nn_total_memory_mb,
                   ns.dropout_count AS nn_dropout_count,
                   ns.has_attention AS nn_has_attention,
                   ns.has_residual_connections AS nn_has_residual,
                   ns.is_resnet_like AS nn_is_resnet_like,
                   ns.is_vgg_like AS nn_is_vgg_like,
                   ns.is_inception_like AS nn_is_inception_like,
                   ns.is_densenet_like AS nn_is_densenet_like,
                   ns.is_unet_like AS nn_is_unet_like,
                   ns.is_transformer_like AS nn_is_transformer_like,
                   ns.is_mobilenet_like AS nn_is_mobilenet_like,
                   ns.is_efficientnet_like AS nn_is_efficientnet_like,
                   ns.code_length AS nn_code_length,
                   ns.num_classes_defined AS nn_num_classes,
                   ns.num_functions_defined AS nn_num_functions,
                   ns.uses_sequential AS nn_uses_sequential,
                   ns.uses_modulelist AS nn_uses_modulelist,
                   ns.uses_moduledict AS nn_uses_moduledict,
                   ns.meta_json AS nn_stats_meta,
                   ns.error AS nn_stats_error
        """
    elif need_nn_stat_join:
        seen: set[str] = set()
        parts: list[str] = []
        for name in require_nn_stat_nonnull:
            sqlc = _resolve_nn_stat_sql_col(name)
            if sqlc in seen:
                continue
            seen.add(sqlc)
            parts.append(f'ns.{sqlc} AS {_nn_stat_out_alias(sqlc)}')
        nn_sel = ',\n                   ' + ',\n                   '.join(parts) if parts else ''
        select_clause = f"""
            SELECT s.id, s.task, s.dataset, s.metric, m.code AS metric_code, m.id AS metric_id,
                   s.nn, n.code AS nn_code, n.id AS nn_id, s.epoch, s.accuracy, s.duration,
                   s.prm AS prm_id, t.code AS transform_code, t.id AS transform_id, s.transform
                   {nn_sel}
        """
    else:
        select_clause = """
            SELECT s.id, s.task, s.dataset, s.metric, m.code AS metric_code, m.id AS metric_id,
                   s.nn, n.code AS nn_code, n.id AS nn_id, s.epoch, s.accuracy, s.duration,
                   s.prm AS prm_id, t.code AS transform_code, t.id AS transform_id, s.transform
        """

    join_clause = f"""
            FROM {{source}} s
            LEFT JOIN nn       n ON s.nn = n.name
            LEFT JOIN metric   m ON s.metric = m.name
            LEFT JOIN transform t ON s.transform = t.name
            {join_nn_stat}
        """

    base_query = select_clause + join_clause.format(source=source)
    limit_clause = str_not_none('LIMIT ', max_rows)
    exec_params = list(params) + prm_params

    conn = None
    try:
        conn, cur = sql_conn()
        cur.execute(
            f'''{base_query}
                ORDER BY s.task, s.dataset, s.metric, s.nn, s.epoch
                {limit_clause}''',
            exec_params,
        )
        if include_prm:
            results = fill_hyper_prm(cur, include_nn_stats=include_nn_stats)
        else:
            results = _assemble_rows_without_prm_bulk(cur, include_nn_stats=include_nn_stats)

        filtered = [
            r for r in results
            if _row_passes_nonnull(
                r, require_stat_nonnull, require_nn_stat_nonnull, require_prm_nonnull
            )
        ]

        if prm_as_columns:
            out = []
            for r in filtered:
                row = dict(r)
                prm = row.pop('prm', None) or {}
                for k, v in prm.items():
                    row[k] = v
                out.append(row)
            filtered = out

        return tuple(filtered)
    finally:
        if conn:
            close_conn(conn)


def run_data(
        model_name: str | None = None,
        device_type: str | None = None,
        max_rows: int | None = None,
):
    """
    Query mobile runtime analytics from the `mobile` table with optional filters.
    Returns a tuple of dicts with columns and parsed device_analytics JSON.
    """
    params = []
    filters = []
    if model_name is not None:
        filters.append('model_name = ?')
        params.append(model_name)
    if device_type is not None:
        filters.append('device_type = ?')
        params.append(device_type)

    where_clause = (' WHERE ' + ' AND '.join(filters)) if filters else ''
    limit_clause = (' LIMIT ' + str(max_rows)) if max_rows else ''

    conn, cur = sql_conn()
    try:
        cur.execute(
            f"""
                 SELECT id, model_name, device_type, os_version, valid, emulator, error_message, duration,
                     iterations, unit, cpu_duration, cpu_min_duration, cpu_max_duration, cpu_std_dev, cpu_error,
                   gpu_duration, gpu_min_duration, gpu_max_duration, gpu_std_dev, gpu_error,
                   npu_duration, npu_min_duration, npu_max_duration, npu_std_dev, npu_error,
                   total_ram_kb, free_ram_kb, available_ram_kb, cached_kb,
                   in_dim_0, in_dim_1, in_dim_2, in_dim_3, device_analytics_json, precision_type
            FROM {run_table}
            {where_clause}
            ORDER BY model_name
            {limit_clause}
            """,
            params,
        )
        rows = cur.fetchall()
        columns = [c[0] for c in cur.description]
        results = []
        for r in rows:
            rec = dict(zip(columns, r))
            try:
                if rec.get('device_analytics_json'):
                    rec['device_analytics'] = json.loads(rec['device_analytics_json'])
            except Exception:
                rec['device_analytics'] = None
            rec.pop('device_analytics_json', None)
            results.append(rec)
        return tuple(results)
    finally:
        close_conn(conn)


def tflite_data(
        model_name: str | None = None,
        precision_type: str | None = None,
        max_rows: int | None = None,
):
    """
    Query TFLite model analytics from the `tflite` table with optional filters.
    Returns a tuple of dicts with columns: id, model_name, accuracy, transform, precision_type.
    """
    params = []
    filters = []
    if model_name is not None:
        filters.append('model_name = ?')
        params.append(model_name)
    if precision_type is not None:
        filters.append('precision_type = ?')
        params.append(precision_type)

    where_clause = (' WHERE ' + ' AND '.join(filters)) if filters else ''
    limit_clause = (' LIMIT ' + str(max_rows)) if max_rows else ''

    conn, cur = sql_conn()
    try:
        cur.execute(
            f"""
                SELECT id, model_name, accuracy, transform, precision_type
                FROM {tflite_table}
                {where_clause}
                ORDER BY model_name
                {limit_clause}
            """,
            params,
        )
        rows = cur.fetchall()
        columns = [c[0] for c in cur.description]
        results = [dict(zip(columns, r)) for r in rows]
        return tuple(results)
    finally:
        close_conn(conn)


def prun_data(
        model_name: str | None = None,
        pruning_method: str | None = None,
        task_dataset: str | None = None,
        max_rows: int | None = None,
):
    """
    Query pruning analytics from the `prun` table with optional filters.
    Returns a tuple of dicts with columns: id, model_name, pruning_method, task_dataset, status, accuracy, duration, etc.
    """
    params = []
    filters = []
    if model_name is not None:
        filters.append('model_name = ?')
        params.append(model_name)
    if pruning_method is not None:
        filters.append('pruning_method = ?')
        params.append(pruning_method)
    if task_dataset is not None:
        filters.append('task_dataset = ?')
        params.append(task_dataset)

    where_clause = (' WHERE ' + ' AND '.join(filters)) if filters else ''
    limit_clause = (' LIMIT ' + str(max_rows)) if max_rows else ''

    conn, cur = sql_conn()
    try:
        cur.execute(
            f"""
                SELECT id, model_name, pruning_method, task_dataset, status, accuracy, duration, pruning_ratio,
                       params_before, params_after, params_removed, model_size_before_kb, model_size_after_kb
                FROM {prun_table}
                {where_clause}
                ORDER BY model_name
                {limit_clause}
            """,
            params,
        )
        rows = cur.fetchall()
        columns = [c[0] for c in cur.description]
        results = [dict(zip(columns, r)) for r in rows]
        return tuple(results)
    finally:
        close_conn(conn)


def sql_where(value_list):
    filters = []
    params = []
    for nm, v in zip(main_columns_ext, value_list):
        if v is not None:
            if isinstance(v, tuple):
                phs = ",".join("?" for _ in v)
                filters.append(f"s.{nm} in ({phs})")
                params.extend(v)
            else:
                filters.append(f"s.{nm} = ?")
                params.append(v)
    return params, ' WHERE ' + ' AND '.join(filters) if filters else ''


def remaining_trials(config_ext, n_optuna_trials) -> tuple[int, int]:
    """
    Calculate the number of remaining Optuna trials for a given model configuration by querying the database.
    
    Instead of reading trial counts from a file, we query the database to count all trial records
    for the specified model (identified by model_name). The trial_file parameter is retained for
    interface compatibility but is not used.
    
    If n_optuna_trials is negative, its absolute value is taken as the required number of additional trials.
    Otherwise, the function computes:
    
        remaining_trials = max(0, n_optuna_trials - n_passed_trials)
    
    :param config_ext: Tuple of names (Task, Dataset, Metric, Model, Epoch).
    :param n_optuna_trials: Target number of trials. If negative, its absolute value specifies the additional trials required.
    :return: A tuple (n_remaining_trials, n_passed_trials) where:
             - n_remaining_trials is the number of new trials to run (or 0 if none remain).
             - n_passed_trials is the number of trials already recorded in the database for this model.
    """

    conn, cursor = sql_conn()
    params, where_clause = sql_where(config_ext)
    cursor.execute('SELECT COUNT(*) AS trial_count FROM stat s' + where_clause, params)
    row = cursor.fetchone()
    if row:
        # Convert the tuple row to a dict
        columns = [col[0] for col in cursor.description]
        row_dict = dict(zip(columns, row))
        n_passed_trials = row_dict.get("trial_count", 0)
    else:
        n_passed_trials = 0

    if n_optuna_trials < 0:
        n_remaining_trials = abs(n_optuna_trials)
    else:
        n_remaining_trials = max(0, n_optuna_trials - n_passed_trials)

    if n_passed_trials > 0:
        print(f"Model '{config_ext[-2]}' has {n_passed_trials} recorded trial(s), {n_remaining_trials} remaining.")

    close_conn(conn)
    return n_remaining_trials, n_passed_trials


def nn_stat_data(
        nn_name: str | None = None,
        prm_id: str | None = None,
        max_rows: int | None = None,
):
    """
    Query NN statistics from the `nn_stat` table with optional filters.
    Returns a tuple of dicts with columns and parsed meta JSON.

    :param nn_name: Filter by neural network name
    :param prm_id: Filter by parameter configuration ID
    :param max_rows: Maximum number of results to return
    :return: Tuple of dictionaries containing NN statistics
    """
    params = []
    filters = []
    if nn_name is not None:
        filters.append('nn_name = ?')
        params.append(nn_name)
    if prm_id is not None:
        filters.append('prm_id = ?')
        params.append(prm_id)

    where_clause = (' WHERE ' + ' AND '.join(filters)) if filters else ''
    limit_clause = (' LIMIT ' + str(max_rows)) if max_rows else ''

    conn, cur = sql_conn()
    try:
        cur.execute(
            f"""
            SELECT id, nn_name, prm_id,
                   total_layers, leaf_layers, max_depth,
                   total_params, trainable_params, frozen_params,
                   flops, model_size_mb, buffer_size_mb, total_memory_mb,
                   dropout_count, has_attention, has_residual_connections,
                   is_resnet_like, is_vgg_like, is_inception_like,
                   is_densenet_like, is_unet_like, is_transformer_like,
                   is_mobilenet_like, is_efficientnet_like,
                   code_length, num_classes_defined, num_functions_defined,
                   uses_sequential, uses_modulelist, uses_moduledict,
                   meta_json, error
            FROM nn_stat
            {where_clause}
            ORDER BY nn_name
            {limit_clause}
            """,
            params,
        )
        rows = cur.fetchall()
        columns = [c[0] for c in cur.description]
        results = []
        for r in rows:
            rec = dict(zip(columns, r))
            try:
                if rec.get('meta_json'):
                    rec['meta'] = json.loads(rec['meta_json'])
            except Exception:
                rec['meta'] = None
            rec.pop('meta_json', None)
            results.append(rec)
        return tuple(results)
    finally:
        close_conn(conn)


def supported_transformers() -> list[str]:
    """
    Returns a list of all transformer names available in the database.
    
    The function queries the 'transform' table for all records and extracts the 'name'
    field from each row.
    """
    return query_cols_rows("SELECT name FROM transform")[0]


def unique_configs(patterns: list[tuple[str, ...]]) -> list[list[str]]:
    """
    Returns a list of unique configuration strings from the database that match at least one of the input patterns.
    
    A configuration string is constructed by concatenating the 'task', 'dataset', 'metric', and 'nn'
    fields from the 'stat' table using the configuration splitter defined in your constants.
    
    :param patterns: A tuple of configuration prefix patterns.
    :return: A list of unique configuration strings that start with any of the provided patterns.
    """
    matched_configs = []
    for pattern in patterns:
        pattern = list(filter(None, pattern))
        params, where_clause = sql_where(pattern)
        # params = params if not params else params[:-1] + [params[-1] + '*']
        rows = query_rows(f"SELECT DISTINCT {', '.join(main_columns)} FROM stat s" + where_clause, params)
        if not rows and is_full_config(pattern):
            rows = [tuple(pattern)]
        matched_configs = matched_configs + rows
    return list(set(matched_configs))