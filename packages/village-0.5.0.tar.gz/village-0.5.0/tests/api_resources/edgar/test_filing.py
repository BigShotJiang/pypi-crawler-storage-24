# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import os
from typing import Any, cast

import pytest

from village import Village, AsyncVillage
from tests.utils import assert_matches_type
from village.types.edgar import EdgarFilingFull

base_url = os.environ.get("TEST_API_BASE_URL", "http://127.0.0.1:4010")


class TestFiling:
    parametrize = pytest.mark.parametrize("client", [False, True], indirect=True, ids=["loose", "strict"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_retrieve(self, client: Village) -> None:
        filing = client.edgar.filing.retrieve(
            "0000320193-23-000077",
        )
        assert_matches_type(EdgarFilingFull, filing, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_retrieve(self, client: Village) -> None:
        response = client.edgar.filing.with_raw_response.retrieve(
            "0000320193-23-000077",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        filing = response.parse()
        assert_matches_type(EdgarFilingFull, filing, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_retrieve(self, client: Village) -> None:
        with client.edgar.filing.with_streaming_response.retrieve(
            "0000320193-23-000077",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            filing = response.parse()
            assert_matches_type(EdgarFilingFull, filing, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_path_params_retrieve(self, client: Village) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `accession_number` but received ''"):
            client.edgar.filing.with_raw_response.retrieve(
                "",
            )


class TestAsyncFiling:
    parametrize = pytest.mark.parametrize(
        "async_client", [False, True, {"http_client": "aiohttp"}], indirect=True, ids=["loose", "strict", "aiohttp"]
    )

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_retrieve(self, async_client: AsyncVillage) -> None:
        filing = await async_client.edgar.filing.retrieve(
            "0000320193-23-000077",
        )
        assert_matches_type(EdgarFilingFull, filing, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_retrieve(self, async_client: AsyncVillage) -> None:
        response = await async_client.edgar.filing.with_raw_response.retrieve(
            "0000320193-23-000077",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        filing = await response.parse()
        assert_matches_type(EdgarFilingFull, filing, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_retrieve(self, async_client: AsyncVillage) -> None:
        async with async_client.edgar.filing.with_streaming_response.retrieve(
            "0000320193-23-000077",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            filing = await response.parse()
            assert_matches_type(EdgarFilingFull, filing, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_path_params_retrieve(self, async_client: AsyncVillage) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `accession_number` but received ''"):
            await async_client.edgar.filing.with_raw_response.retrieve(
                "",
            )
