# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import os
from typing import Any, cast

import pytest

from village import Village, AsyncVillage
from tests.utils import assert_matches_type
from village.types import QuartrRetrieveEventResponse, QuartrListEventTypesResponse, QuartrListDocumentTypesResponse

base_url = os.environ.get("TEST_API_BASE_URL", "http://127.0.0.1:4010")


class TestQuartr:
    parametrize = pytest.mark.parametrize("client", [False, True], indirect=True, ids=["loose", "strict"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_list_document_types(self, client: Village) -> None:
        quartr = client.quartr.list_document_types()
        assert_matches_type(QuartrListDocumentTypesResponse, quartr, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_list_document_types(self, client: Village) -> None:
        response = client.quartr.with_raw_response.list_document_types()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        quartr = response.parse()
        assert_matches_type(QuartrListDocumentTypesResponse, quartr, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_list_document_types(self, client: Village) -> None:
        with client.quartr.with_streaming_response.list_document_types() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            quartr = response.parse()
            assert_matches_type(QuartrListDocumentTypesResponse, quartr, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_list_event_types(self, client: Village) -> None:
        quartr = client.quartr.list_event_types()
        assert_matches_type(QuartrListEventTypesResponse, quartr, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_list_event_types(self, client: Village) -> None:
        response = client.quartr.with_raw_response.list_event_types()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        quartr = response.parse()
        assert_matches_type(QuartrListEventTypesResponse, quartr, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_list_event_types(self, client: Village) -> None:
        with client.quartr.with_streaming_response.list_event_types() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            quartr = response.parse()
            assert_matches_type(QuartrListEventTypesResponse, quartr, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_retrieve_event(self, client: Village) -> None:
        quartr = client.quartr.retrieve_event(
            123456,
        )
        assert_matches_type(QuartrRetrieveEventResponse, quartr, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_retrieve_event(self, client: Village) -> None:
        response = client.quartr.with_raw_response.retrieve_event(
            123456,
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        quartr = response.parse()
        assert_matches_type(QuartrRetrieveEventResponse, quartr, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_retrieve_event(self, client: Village) -> None:
        with client.quartr.with_streaming_response.retrieve_event(
            123456,
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            quartr = response.parse()
            assert_matches_type(QuartrRetrieveEventResponse, quartr, path=["response"])

        assert cast(Any, response.is_closed) is True


class TestAsyncQuartr:
    parametrize = pytest.mark.parametrize(
        "async_client", [False, True, {"http_client": "aiohttp"}], indirect=True, ids=["loose", "strict", "aiohttp"]
    )

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_list_document_types(self, async_client: AsyncVillage) -> None:
        quartr = await async_client.quartr.list_document_types()
        assert_matches_type(QuartrListDocumentTypesResponse, quartr, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_list_document_types(self, async_client: AsyncVillage) -> None:
        response = await async_client.quartr.with_raw_response.list_document_types()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        quartr = await response.parse()
        assert_matches_type(QuartrListDocumentTypesResponse, quartr, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_list_document_types(self, async_client: AsyncVillage) -> None:
        async with async_client.quartr.with_streaming_response.list_document_types() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            quartr = await response.parse()
            assert_matches_type(QuartrListDocumentTypesResponse, quartr, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_list_event_types(self, async_client: AsyncVillage) -> None:
        quartr = await async_client.quartr.list_event_types()
        assert_matches_type(QuartrListEventTypesResponse, quartr, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_list_event_types(self, async_client: AsyncVillage) -> None:
        response = await async_client.quartr.with_raw_response.list_event_types()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        quartr = await response.parse()
        assert_matches_type(QuartrListEventTypesResponse, quartr, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_list_event_types(self, async_client: AsyncVillage) -> None:
        async with async_client.quartr.with_streaming_response.list_event_types() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            quartr = await response.parse()
            assert_matches_type(QuartrListEventTypesResponse, quartr, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_retrieve_event(self, async_client: AsyncVillage) -> None:
        quartr = await async_client.quartr.retrieve_event(
            123456,
        )
        assert_matches_type(QuartrRetrieveEventResponse, quartr, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_retrieve_event(self, async_client: AsyncVillage) -> None:
        response = await async_client.quartr.with_raw_response.retrieve_event(
            123456,
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        quartr = await response.parse()
        assert_matches_type(QuartrRetrieveEventResponse, quartr, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_retrieve_event(self, async_client: AsyncVillage) -> None:
        async with async_client.quartr.with_streaming_response.retrieve_event(
            123456,
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            quartr = await response.parse()
            assert_matches_type(QuartrRetrieveEventResponse, quartr, path=["response"])

        assert cast(Any, response.is_closed) is True
