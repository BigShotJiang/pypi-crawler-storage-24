# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import httpx

from .edgar import (
    EdgarResource,
    AsyncEdgarResource,
    EdgarResourceWithRawResponse,
    AsyncEdgarResourceWithRawResponse,
    EdgarResourceWithStreamingResponse,
    AsyncEdgarResourceWithStreamingResponse,
)
from .quartr import (
    QuartrResource,
    AsyncQuartrResource,
    QuartrResourceWithRawResponse,
    AsyncQuartrResourceWithRawResponse,
    QuartrResourceWithStreamingResponse,
    AsyncQuartrResourceWithStreamingResponse,
)
from ..._types import Body, Query, Headers, NotGiven, not_given
from ..._compat import cached_property
from ..._resource import SyncAPIResource, AsyncAPIResource
from ..._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from ..._base_client import make_request_options
from ...types.company_lookup_response import CompanyLookupResponse

__all__ = ["CompanyResource", "AsyncCompanyResource"]


class CompanyResource(SyncAPIResource):
    """
    Look up companies by ticker and browse their EDGAR filings and Quartr documents.
    """

    @cached_property
    def edgar(self) -> EdgarResource:
        """
        Look up companies by ticker and browse their EDGAR filings and Quartr documents.
        """
        return EdgarResource(self._client)

    @cached_property
    def quartr(self) -> QuartrResource:
        """
        Look up companies by ticker and browse their EDGAR filings and Quartr documents.
        """
        return QuartrResource(self._client)

    @cached_property
    def with_raw_response(self) -> CompanyResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/village-dev/village-python#accessing-raw-response-data-eg-headers
        """
        return CompanyResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> CompanyResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/village-dev/village-python#with_streaming_response
        """
        return CompanyResourceWithStreamingResponse(self)

    def lookup(
        self,
        qualified_ticker: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> CompanyLookupResponse:
        """
        Look up a company by its ticker symbol.

        Accepts a qualified ticker in SYMBOL:EXCHANGE format (e.g. 'AAPL:NASDAQ'). An
        unqualified symbol (e.g. 'AAPL') is also accepted and will be resolved
        automatically.

        Performs a two-hop search across both EDGAR entities and Quartr companies.
        First, direct matches for the provided ticker are found. Then, all tickers from
        the initial matches are pooled and used to discover additional related entities.
        Returns the best-matching EDGAR entity and Quartr company (at most one of each),
        along with a company profile summary from Financial Modeling Prep when
        available.

        Args:
          qualified_ticker: A ticker symbol qualified with the exchange in SYMBOL:EXCHANGE format (e.g.
              'AAPL:NASDAQ').

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not qualified_ticker:
            raise ValueError(f"Expected a non-empty value for `qualified_ticker` but received {qualified_ticker!r}")
        return self._get(
            f"/company/{qualified_ticker}",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=CompanyLookupResponse,
        )


class AsyncCompanyResource(AsyncAPIResource):
    """
    Look up companies by ticker and browse their EDGAR filings and Quartr documents.
    """

    @cached_property
    def edgar(self) -> AsyncEdgarResource:
        """
        Look up companies by ticker and browse their EDGAR filings and Quartr documents.
        """
        return AsyncEdgarResource(self._client)

    @cached_property
    def quartr(self) -> AsyncQuartrResource:
        """
        Look up companies by ticker and browse their EDGAR filings and Quartr documents.
        """
        return AsyncQuartrResource(self._client)

    @cached_property
    def with_raw_response(self) -> AsyncCompanyResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/village-dev/village-python#accessing-raw-response-data-eg-headers
        """
        return AsyncCompanyResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncCompanyResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/village-dev/village-python#with_streaming_response
        """
        return AsyncCompanyResourceWithStreamingResponse(self)

    async def lookup(
        self,
        qualified_ticker: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> CompanyLookupResponse:
        """
        Look up a company by its ticker symbol.

        Accepts a qualified ticker in SYMBOL:EXCHANGE format (e.g. 'AAPL:NASDAQ'). An
        unqualified symbol (e.g. 'AAPL') is also accepted and will be resolved
        automatically.

        Performs a two-hop search across both EDGAR entities and Quartr companies.
        First, direct matches for the provided ticker are found. Then, all tickers from
        the initial matches are pooled and used to discover additional related entities.
        Returns the best-matching EDGAR entity and Quartr company (at most one of each),
        along with a company profile summary from Financial Modeling Prep when
        available.

        Args:
          qualified_ticker: A ticker symbol qualified with the exchange in SYMBOL:EXCHANGE format (e.g.
              'AAPL:NASDAQ').

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not qualified_ticker:
            raise ValueError(f"Expected a non-empty value for `qualified_ticker` but received {qualified_ticker!r}")
        return await self._get(
            f"/company/{qualified_ticker}",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=CompanyLookupResponse,
        )


class CompanyResourceWithRawResponse:
    def __init__(self, company: CompanyResource) -> None:
        self._company = company

        self.lookup = to_raw_response_wrapper(
            company.lookup,
        )

    @cached_property
    def edgar(self) -> EdgarResourceWithRawResponse:
        """
        Look up companies by ticker and browse their EDGAR filings and Quartr documents.
        """
        return EdgarResourceWithRawResponse(self._company.edgar)

    @cached_property
    def quartr(self) -> QuartrResourceWithRawResponse:
        """
        Look up companies by ticker and browse their EDGAR filings and Quartr documents.
        """
        return QuartrResourceWithRawResponse(self._company.quartr)


class AsyncCompanyResourceWithRawResponse:
    def __init__(self, company: AsyncCompanyResource) -> None:
        self._company = company

        self.lookup = async_to_raw_response_wrapper(
            company.lookup,
        )

    @cached_property
    def edgar(self) -> AsyncEdgarResourceWithRawResponse:
        """
        Look up companies by ticker and browse their EDGAR filings and Quartr documents.
        """
        return AsyncEdgarResourceWithRawResponse(self._company.edgar)

    @cached_property
    def quartr(self) -> AsyncQuartrResourceWithRawResponse:
        """
        Look up companies by ticker and browse their EDGAR filings and Quartr documents.
        """
        return AsyncQuartrResourceWithRawResponse(self._company.quartr)


class CompanyResourceWithStreamingResponse:
    def __init__(self, company: CompanyResource) -> None:
        self._company = company

        self.lookup = to_streamed_response_wrapper(
            company.lookup,
        )

    @cached_property
    def edgar(self) -> EdgarResourceWithStreamingResponse:
        """
        Look up companies by ticker and browse their EDGAR filings and Quartr documents.
        """
        return EdgarResourceWithStreamingResponse(self._company.edgar)

    @cached_property
    def quartr(self) -> QuartrResourceWithStreamingResponse:
        """
        Look up companies by ticker and browse their EDGAR filings and Quartr documents.
        """
        return QuartrResourceWithStreamingResponse(self._company.quartr)


class AsyncCompanyResourceWithStreamingResponse:
    def __init__(self, company: AsyncCompanyResource) -> None:
        self._company = company

        self.lookup = async_to_streamed_response_wrapper(
            company.lookup,
        )

    @cached_property
    def edgar(self) -> AsyncEdgarResourceWithStreamingResponse:
        """
        Look up companies by ticker and browse their EDGAR filings and Quartr documents.
        """
        return AsyncEdgarResourceWithStreamingResponse(self._company.edgar)

    @cached_property
    def quartr(self) -> AsyncQuartrResourceWithStreamingResponse:
        """
        Look up companies by ticker and browse their EDGAR filings and Quartr documents.
        """
        return AsyncQuartrResourceWithStreamingResponse(self._company.quartr)
