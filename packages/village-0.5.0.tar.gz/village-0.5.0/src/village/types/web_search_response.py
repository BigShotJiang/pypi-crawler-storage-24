# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List, Optional
from datetime import date

from .._models import BaseModel

__all__ = ["WebSearchResponse", "Result"]


class Result(BaseModel):
    author: Optional[str] = None
    """Result author, if available."""

    favicon_url: Optional[str] = None
    """Favicon URL for the source website, if available."""

    image_url: Optional[str] = None
    """Representative image URL, if available."""

    published_date: Optional[date] = None
    """Parsed publication date, if available.

    This is primarily populated when the provider returns an absolute date.
    """

    text: Optional[str] = None
    """Snippet or scraped markdown content associated with the result."""

    title: Optional[str] = None
    """Result title, if available."""

    url: str
    """Canonical result URL."""

    published_date_raw: Optional[str] = None
    """
    Original publication date string when the provider returns a relative or
    otherwise non-ISO value such as `today`.
    """


class WebSearchResponse(BaseModel):
    effective_query: str
    """Search query sent to the upstream provider after source filters were applied."""

    excluded_domains: List[str]
    """
    Effective domain denylist applied to the search, including the built-in finance
    denylist plus any caller-provided exclusions.
    """

    results: List[Result]
    """Normalized combined result list.

    When `search_type="all"`, `web` results appear first, followed by `news`
    results.
    """
