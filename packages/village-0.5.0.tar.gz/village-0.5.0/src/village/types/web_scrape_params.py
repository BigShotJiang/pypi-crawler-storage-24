# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Optional
from typing_extensions import Required, TypedDict

__all__ = ["WebScrapeParams"]


class WebScrapeParams(TypedDict, total=False):
    url: Required[str]
    """HTTP(S) URL of the webpage to scrape."""

    max_age: int
    """Maximum cache age in milliseconds to allow when reusing a prior scrape result."""

    min_age: Optional[int]
    """
    Minimum cache age in milliseconds required before reusing a prior scrape result.
    """
