# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Optional
from datetime import date

from .._models import BaseModel

__all__ = ["WebScrapeResponse"]


class WebScrapeResponse(BaseModel):
    favicon_url: Optional[str] = None
    """Favicon URL, if available."""

    image_url: Optional[str] = None
    """Open Graph image URL, if available."""

    markdown: str
    """Extracted markdown content for the page."""

    published_date: Optional[date] = None
    """Parsed publication date, if available.

    This is primarily populated when the provider returns an absolute date.
    """

    resolved_url: str
    """
    Final resolved URL reported by the scraper, or the requested URL when no
    different final URL is available.
    """

    status: str
    """Normalized scrape status.

    Returns `success` for 2xx responses or when the provider omits a status code;
    otherwise returns the provider error string or `error`.
    """

    title: Optional[str] = None
    """Page title, if available."""

    url: str
    """Requested URL."""
