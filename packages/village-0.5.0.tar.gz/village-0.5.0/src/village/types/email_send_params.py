# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Iterable, Optional
from typing_extensions import Literal, Required, TypedDict

from .._types import SequenceNotStr

__all__ = ["EmailSendParams", "Attachment"]


class EmailSendParams(TypedDict, total=False):
    body: Required[str]
    """Plain-text email body."""

    subject: Required[str]
    """Email subject line."""

    to: Required[SequenceNotStr[str]]
    """List of recipient email addresses."""

    attachments: Iterable[Attachment]
    """Attachments to include with the email."""

    bcc: SequenceNotStr[str]
    """List of BCC email addresses."""

    cc: SequenceNotStr[str]
    """List of CC email addresses."""

    from_name: Optional[str]
    """Display name for the sender. Defaults to "Village"."""

    html_body: Optional[str]
    """HTML email body."""


class Attachment(TypedDict, total=False):
    """Attachment payload for a send-email request."""

    content_base64: Required[str]
    """Base64-encoded attachment bytes."""

    content_type: Required[str]
    """MIME content type for the attachment, such as image/png."""

    filename: Required[str]
    """Filename to present in the email client."""

    content_id: Optional[str]
    """Required for inline attachments; reference from HTML as cid:<content_id>."""

    disposition: Literal["inline", "attachment"]
    """Whether the attachment should be inline or downloadable."""
