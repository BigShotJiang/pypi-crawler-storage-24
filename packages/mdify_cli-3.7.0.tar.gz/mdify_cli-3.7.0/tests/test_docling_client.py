"""Tests for docling_client module."""

from unittest.mock import patch, Mock
import pytest
import requests
from pathlib import Path

from mdify.docling_client import (
    check_health,
    convert_file,
    convert_file_async,
    poll_status,
    get_result,
    ConvertResult,
    StatusResult,
    DoclingHTTPError,
)


class TestCheckHealth:
    """Test health check function."""

    def test_check_health_success(self):
        """Test health check with successful response."""
        with patch("mdify.docling_client.requests.get") as mock_get:
            mock_get.return_value.status_code = 200
            mock_get.return_value.json.return_value = {"status": "healthy"}

            assert check_health("http://localhost:5001") is True

    def test_check_health_failure_404(self):
        """Test health check with 404 response."""
        with patch("mdify.docling_client.requests.get") as mock_get:
            mock_get.return_value.status_code = 404

            assert check_health("http://localhost:5001") is False

    def test_check_health_connection_error(self):
        """Test health check with connection error."""
        with patch("mdify.docling_client.requests.get") as mock_get:
            mock_get.side_effect = requests.ConnectionError()

            assert check_health("http://localhost:5001") is False

    def test_check_health_timeout(self):
        """Test health check with timeout."""
        with patch("mdify.docling_client.requests.get") as mock_get:
            mock_get.side_effect = requests.Timeout()

            assert check_health("http://localhost:5001") is False


class TestConvertFile:
    """Test synchronous file conversion."""

    def test_convert_file_success_list_format(self, tmp_path):
        """Test successful file conversion with list response format."""
        test_file = tmp_path / "test.pdf"
        test_file.write_bytes(b"fake pdf content")

        with patch("mdify.docling_client.requests.post") as mock_post:
            mock_response = Mock()
            mock_response.status_code = 200
            mock_response.json.return_value = [
                {"content": "# Test Document\n\nContent here."}
            ]
            mock_post.return_value = mock_response

            result = convert_file("http://localhost:5001", test_file)

            assert result.success is True
            assert "# Test Document" in result.content
            assert result.error is None
            assert result.format == "md"

    def test_convert_file_success_dict_format(self, tmp_path):
        """Test successful file conversion with dict response format."""
        test_file = tmp_path / "test.pdf"
        test_file.write_bytes(b"fake pdf content")

        with patch("mdify.docling_client.requests.post") as mock_post:
            mock_response = Mock()
            mock_response.status_code = 200
            mock_response.json.return_value = {"content": "# Test Document"}
            mock_post.return_value = mock_response

            result = convert_file("http://localhost:5001", test_file)

            assert result.success is True
            assert "# Test Document" in result.content

    def test_convert_file_http_error(self, tmp_path):
        """Test file conversion with HTTP error."""
        test_file = tmp_path / "test.pdf"
        test_file.write_bytes(b"fake pdf")

        with patch("mdify.docling_client.requests.post") as mock_post:
            mock_response = Mock()
            mock_response.status_code = 500
            mock_response.text = "Internal Server Error"
            mock_post.return_value = mock_response

            with pytest.raises(DoclingHTTPError) as exc_info:
                convert_file("http://localhost:5001", test_file)

            assert exc_info.value.status_code == 500

    def test_convert_file_connection_error(self, tmp_path):
        """Test file conversion with connection error."""
        test_file = tmp_path / "test.pdf"
        test_file.write_bytes(b"fake pdf")

        with patch("mdify.docling_client.requests.post") as mock_post:
            mock_post.side_effect = requests.ConnectionError("Connection refused")

            result = convert_file("http://localhost:5001", test_file)

            assert result.success is False
            assert "Connection refused" in result.error

    def test_convert_file_with_custom_format(self, tmp_path):
        """Test file conversion with custom output format."""
        test_file = tmp_path / "test.pdf"
        test_file.write_bytes(b"fake pdf")

        with patch("mdify.docling_client.requests.post") as mock_post:
            mock_response = Mock()
            mock_response.status_code = 200
            mock_response.json.return_value = [{"content": "Result"}]
            mock_post.return_value = mock_response

            result = convert_file("http://localhost:5001", test_file, to_format="html")

            assert result.format == "html"

    def test_convert_file_new_document_format(self, tmp_path):
        """Test file conversion with new document.md_content format."""
        test_file = tmp_path / "test.pdf"
        test_file.write_bytes(b"fake pdf content")

        with patch("mdify.docling_client.requests.post") as mock_post:
            mock_response = Mock()
            mock_response.status_code = 200
            mock_response.json.return_value = {
                "document": {"md_content": "# New Format Content\n\nMarkdown here."}
            }
            mock_post.return_value = mock_response

            result = convert_file("http://localhost:5001", test_file)

            assert result.success is True
            assert "# New Format Content" in result.content
            assert result.error is None
            assert result.format == "md"


class TestConvertFileAsync:
    """Test async file conversion."""

    def test_convert_file_async_success(self, tmp_path):
        """Test async conversion returns task ID."""
        test_file = tmp_path / "test.pdf"
        test_file.write_bytes(b"fake pdf")

        with patch("mdify.docling_client.requests.post") as mock_post:
            mock_response = Mock()
            mock_response.status_code = 200
            mock_response.json.return_value = {"task_id": "abc123"}
            mock_post.return_value = mock_response

            task_id = convert_file_async("http://localhost:5001", test_file)

            assert task_id == "abc123"

    def test_convert_file_async_http_error(self, tmp_path):
        """Test async conversion with HTTP error."""
        test_file = tmp_path / "test.pdf"
        test_file.write_bytes(b"fake pdf")

        with patch("mdify.docling_client.requests.post") as mock_post:
            mock_response = Mock()
            mock_response.status_code = 400
            mock_response.text = "Bad Request"
            mock_post.return_value = mock_response

            with pytest.raises(DoclingHTTPError):
                convert_file_async("http://localhost:5001", test_file)

    def test_convert_file_async_missing_task_id(self, tmp_path):
        """Test async conversion with missing task_id in response."""
        test_file = tmp_path / "test.pdf"
        test_file.write_bytes(b"fake pdf")

        with patch("mdify.docling_client.requests.post") as mock_post:
            mock_response = Mock()
            mock_response.status_code = 200
            mock_response.json.return_value = {}
            mock_post.return_value = mock_response

            with pytest.raises(DoclingHTTPError):
                convert_file_async("http://localhost:5001", test_file)

    def test_convert_file_async_connection_error(self, tmp_path):
        """Test async conversion with connection error."""
        test_file = tmp_path / "test.pdf"
        test_file.write_bytes(b"fake pdf")

        with patch("mdify.docling_client.requests.post") as mock_post:
            mock_post.side_effect = requests.ConnectionError("Connection refused")

            with pytest.raises(DoclingHTTPError):
                convert_file_async("http://localhost:5001", test_file)


class TestPollStatus:
    """Test status polling."""

    def test_poll_status_completed(self):
        """Test polling with completed status."""
        with patch("mdify.docling_client.requests.get") as mock_get:
            mock_response = Mock()
            mock_response.status_code = 200
            mock_response.json.return_value = {
                "task_id": "abc123",
                "status": "completed",
            }
            mock_get.return_value = mock_response

            status = poll_status("http://localhost:5001", "abc123")

            assert status.task_id == "abc123"
            assert status.status == "completed"

    def test_poll_status_pending(self):
        """Test polling with pending status."""
        with patch("mdify.docling_client.requests.get") as mock_get:
            mock_response = Mock()
            mock_response.status_code = 200
            mock_response.json.return_value = {"task_id": "abc123", "status": "pending"}
            mock_get.return_value = mock_response

            status = poll_status("http://localhost:5001", "abc123")

            assert status.status == "pending"

    def test_poll_status_failed(self):
        """Test polling with failed status."""
        with patch("mdify.docling_client.requests.get") as mock_get:
            mock_response = Mock()
            mock_response.status_code = 200
            mock_response.json.return_value = {
                "task_id": "abc123",
                "status": "failed",
                "error": "Processing error",
            }
            mock_get.return_value = mock_response

            status = poll_status("http://localhost:5001", "abc123")

            assert status.status == "failed"
            assert status.error == "Processing error"

    def test_poll_status_http_error(self):
        """Test polling with HTTP error."""
        with patch("mdify.docling_client.requests.get") as mock_get:
            mock_response = Mock()
            mock_response.status_code = 500
            mock_response.text = "Server error"
            mock_get.return_value = mock_response

            with pytest.raises(DoclingHTTPError):
                poll_status("http://localhost:5001", "abc123")


class TestGetResult:
    """Test result retrieval."""

    def test_get_result_success_list_format(self):
        """Test getting result for completed task with list format."""
        with patch("mdify.docling_client.requests.get") as mock_get:
            mock_response = Mock()
            mock_response.status_code = 200
            mock_response.json.return_value = [{"content": "# Result\n\nContent."}]
            mock_get.return_value = mock_response

            result = get_result("http://localhost:5001", "abc123")

            assert result.success is True
            assert "# Result" in result.content

    def test_get_result_success_dict_format(self):
        """Test getting result for completed task with dict format."""
        with patch("mdify.docling_client.requests.get") as mock_get:
            mock_response = Mock()
            mock_response.status_code = 200
            mock_response.json.return_value = {"content": "# Result"}
            mock_get.return_value = mock_response

            result = get_result("http://localhost:5001", "abc123")

            assert result.success is True
            assert "# Result" in result.content

    def test_get_result_http_error(self):
        """Test getting result with HTTP error."""
        with patch("mdify.docling_client.requests.get") as mock_get:
            mock_response = Mock()
            mock_response.status_code = 404
            mock_response.text = "Task not found"
            mock_get.return_value = mock_response

            with pytest.raises(DoclingHTTPError):
                get_result("http://localhost:5001", "nonexistent")

    def test_get_result_connection_error(self):
        """Test getting result with connection error."""
        with patch("mdify.docling_client.requests.get") as mock_get:
            mock_get.side_effect = requests.ConnectionError()

            result = get_result("http://localhost:5001", "abc123")

            assert result.success is False
            assert result.error is not None

    def test_get_result_new_document_format(self):
        """Test getting result with new document.md_content format."""
        with patch("mdify.docling_client.requests.get") as mock_get:
            mock_response = Mock()
            mock_response.status_code = 200
            mock_response.json.return_value = {
                "document": {
                    "md_content": "# Result with MD Content\n\nFormatted markdown."
                }
            }
            mock_get.return_value = mock_response

            result = get_result("http://localhost:5001", "abc123")

            assert result.success is True
            assert "# Result with MD Content" in result.content
            assert result.error is None
            assert result.format == "md"


class TestDataClasses:
    """Test dataclass definitions."""

    def test_convert_result_creation(self):
        """Test ConvertResult dataclass creation."""
        result = ConvertResult(content="Test", format="md", success=True)

        assert result.content == "Test"
        assert result.format == "md"
        assert result.success is True
        assert result.error is None

    def test_convert_result_with_error(self):
        """Test ConvertResult with error."""
        result = ConvertResult(
            content="", format="md", success=False, error="Test error"
        )

        assert result.success is False
        assert result.error == "Test error"

    def test_status_result_creation(self):
        """Test StatusResult dataclass creation."""
        status = StatusResult(status="completed", task_id="abc123")

        assert status.status == "completed"
        assert status.task_id == "abc123"
        assert status.error is None

    def test_status_result_with_error(self):
        """Test StatusResult with error."""
        status = StatusResult(status="failed", task_id="abc123", error="Failed")

        assert status.status == "failed"
        assert status.error == "Failed"


class TestDoclingHTTPError:
    """Test custom HTTP error."""

    def test_http_error_message(self):
        """Test HTTP error message formatting."""
        error = DoclingHTTPError(500, "Internal Server Error")

        assert error.status_code == 500
        assert "500" in str(error)
        assert "Internal Server Error" in str(error)

    def test_http_error_inheritance(self):
        """Test HTTP error is proper exception type."""
        error = DoclingHTTPError(400, "Bad Request")

        assert isinstance(error, Exception)


class TestMimeTypeDetection:
    """Test MIME type detection in file conversion."""

    def test_convert_file_sends_correct_mime_for_xlsx(self, tmp_path):
        """Test that .xlsx files are sent with correct MIME type."""
        test_file = tmp_path / "test.xlsx"
        test_file.write_bytes(b"fake xlsx content")

        with patch("mdify.docling_client.requests.post") as mock_post:
            mock_response = Mock()
            mock_response.status_code = 200
            mock_response.json.return_value = [
                {"content": "# Test Spreadsheet\n\nContent here."}
            ]
            mock_post.return_value = mock_response

            convert_file("http://localhost:5001", test_file)

            mock_post.assert_called_once()
            call_args = mock_post.call_args
            files_param = call_args[1]["files"]
            filename, file_obj, mime_type = files_param["files"]
            assert (
                mime_type
                == "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
            )

    def test_convert_file_sends_correct_mime_for_pdf(self, tmp_path):
        """Test that .pdf files are sent with correct MIME type (regression test)."""
        test_file = tmp_path / "test.pdf"
        test_file.write_bytes(b"fake pdf content")

        with patch("mdify.docling_client.requests.post") as mock_post:
            mock_response = Mock()
            mock_response.status_code = 200
            mock_response.json.return_value = [
                {"content": "# Test Document\n\nContent here."}
            ]
            mock_post.return_value = mock_response

            convert_file("http://localhost:5001", test_file)

            mock_post.assert_called_once()
            call_args = mock_post.call_args
            files_param = call_args[1]["files"]
            filename, file_obj, mime_type = files_param["files"]
            assert mime_type == "application/pdf"

    def test_convert_file_sends_correct_mime_for_docx(self, tmp_path):
        """Test that .docx files are sent with correct MIME type."""
        test_file = tmp_path / "test.docx"
        test_file.write_bytes(b"fake docx content")

        with patch("mdify.docling_client.requests.post") as mock_post:
            mock_response = Mock()
            mock_response.status_code = 200
            mock_response.json.return_value = [
                {"content": "# Test Document\n\nContent here."}
            ]
            mock_post.return_value = mock_response

            convert_file("http://localhost:5001", test_file)

            mock_post.assert_called_once()
            call_args = mock_post.call_args
            files_param = call_args[1]["files"]
            filename, file_obj, mime_type = files_param["files"]
            assert (
                mime_type
                == "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
            )

    def test_convert_file_fallback_for_unknown_extension(self, tmp_path):
        """Test that unknown file extensions fall back to application/octet-stream."""
        test_file = tmp_path / "test.unknownext123"
        test_file.write_bytes(b"fake unknown content")

        with patch("mdify.docling_client.requests.post") as mock_post:
            mock_response = Mock()
            mock_response.status_code = 200
            mock_response.json.return_value = [
                {"content": "# Test Content\n\nContent here."}
            ]
            mock_post.return_value = mock_response

            convert_file("http://localhost:5001", test_file)

            mock_post.assert_called_once()
            call_args = mock_post.call_args
            files_param = call_args[1]["files"]
            filename, file_obj, mime_type = files_param["files"]
            assert mime_type == "application/octet-stream"


class TestErrorDetection:
    """Test error response detection functionality."""

    def test_error_detection_with_detail_key(self):
        """Test detection of error response with 'detail' key."""
        from mdify.docling_client import _is_error_response
        
        error_response = {"detail": "Conversion is taking too long"}
        assert _is_error_response(error_response) is True

    def test_error_detection_with_error_key(self):
        """Test detection of error response with 'error' key."""
        from mdify.docling_client import _is_error_response
        
        error_response = {"error": "Internal server error"}
        assert _is_error_response(error_response) is True

    def test_error_detection_with_message_key(self):
        """Test detection of error response with 'message' key."""
        from mdify.docling_client import _is_error_response
        
        error_response = {"message": "Request failed"}
        assert _is_error_response(error_response) is True

    def test_error_detection_with_code_key(self):
        """Test detection of error response with 'code' key."""
        from mdify.docling_client import _is_error_response
        
        error_response = {"code": 500}
        assert _is_error_response(error_response) is True

    def test_error_detection_with_status_key(self):
        """Test detection of error response with 'status' key."""
        from mdify.docling_client import _is_error_response
        
        error_response = {"status": "error"}
        assert _is_error_response(error_response) is True

    def test_error_detection_timeout_error(self):
        """Test detection of specific timeout error from docling-serve."""
        from mdify.docling_client import _is_error_response
        
        error_response = {
            "detail": "Conversion is taking too long. The maximum wait time is configure as DOCLING_SERVE_MAX_SYNC_WAIT=120."
        }
        assert _is_error_response(error_response) is True

    def test_valid_response_not_detected_as_error(self):
        """Test that valid responses are not marked as errors."""
        from mdify.docling_client import _is_error_response
        
        valid_response = {"document": {"md_content": "# Valid Markdown"}}
        assert _is_error_response(valid_response) is False

    def test_empty_dict_not_detected_as_error(self):
        """Test that empty dict is not detected as error."""
        from mdify.docling_client import _is_error_response
        
        assert _is_error_response({}) is False

    def test_non_dict_not_detected_as_error(self):
        """Test that non-dict values are not detected as errors."""
        from mdify.docling_client import _is_error_response
        
        assert _is_error_response("not a dict") is False
        assert _is_error_response(None) is False
        assert _is_error_response([]) is False


class TestContentExtraction:
    """Test content extraction from responses, including error handling."""

    def test_extract_content_from_error_returns_empty(self):
        """Test that error responses return empty content."""
        from mdify.docling_client import _extract_content
        
        error_response = {"detail": "Conversion failed"}
        assert _extract_content(error_response) == ""

    def test_extract_content_from_document_md_content(self):
        """Test extracting content from document.md_content."""
        from mdify.docling_client import _extract_content
        
        valid_response = {
            "document": {
                "md_content": "# Valid Markdown\n\nThis is valid content."
            }
        }
        content = _extract_content(valid_response)
        assert content == "# Valid Markdown\n\nThis is valid content."

    def test_extract_content_from_document_content_fallback(self):
        """Test extracting content from document.content fallback."""
        from mdify.docling_client import _extract_content
        
        response = {
            "document": {
                "content": "Alternative content format"
            }
        }
        content = _extract_content(response)
        assert content == "Alternative content format"

    def test_extract_content_from_empty_document(self):
        """Test that empty document returns empty string."""
        from mdify.docling_client import _extract_content
        
        response = {"document": {"md_content": ""}}
        assert _extract_content(response) == ""

    def test_extract_content_from_results_old_format(self):
        """Test extracting content from old list format."""
        from mdify.docling_client import _extract_content
        
        response = [
            {
                "document": {
                    "md_content": "# Header\n\nMarkdown content"
                }
            }
        ]
        content = _extract_content(response)
        assert "Header" in content

    def test_extract_content_with_nested_markdown(self):
        """Test extracting nested markdown content."""
        from mdify.docling_client import _extract_content
        
        response = {
            "document": {
                "content": {
                    "markdown": "# Nested Markdown"
                }
            }
        }
        content = _extract_content(response)
        assert len(content) > 0


class TestContentValidation:
    """Test content length validation for preventing invalid files."""

    def test_validation_threshold_minimum(self):
        """Test that exactly 50 characters passes validation."""
        content = "This is exactly 50 character string for testing."
        # Verify it's exactly 50 characters (or use a longer string)
        if len(content.strip()) < 50:
            content = "This is a string that is at least 50 characters long to validate the threshold."
        assert len(content.strip()) >= 50

    def test_validation_threshold_below_minimum(self):
        """Test that less than 50 characters fails validation."""
        content = "Too short"
        assert len(content.strip()) < 50

    def test_validation_empty_content_fails(self):
        """Test that empty content fails validation."""
        content = ""
        content_length = len(content.strip()) if content else 0
        assert content_length < 50

    def test_validation_whitespace_stripped(self):
        """Test that whitespace is stripped during validation."""
        content = "   Too short   "
        # After strip, it's less than 50 chars
        assert len(content.strip()) < 50

    def test_validation_error_json_fails(self):
        """Test that typical error JSON fails validation."""
        import json
        error_json = json.dumps({
            "detail": "Conversion is taking too long. The maximum wait time is configure as DOCLING_SERVE_MAX_SYNC_WAIT=120."
        })
        # Even the error message is < 50 chars when just the string
        error_detail = '{"detail": "Conversion failed"}'
        assert len(error_detail.strip()) < 50

    def test_validation_valid_content_passes(self):
        """Test that typical valid content passes validation."""
        content = "# Markdown Heading\n\nThis is substantial content that exceeds the 50 character minimum."
        assert len(content.strip()) >= 50

    def test_convert_result_with_short_content(self):
        """Test ConvertResult with content below threshold."""
        result = ConvertResult(content="Short", format="md", success=True)
        content_length = len(result.content.strip()) if result.content else 0
        assert content_length < 50

    def test_convert_result_with_valid_content(self):
        """Test ConvertResult with content above threshold."""
        result = ConvertResult(
            content="# Valid content that exceeds the 50 character minimum threshold",
            format="md",
            success=True
        )
        content_length = len(result.content.strip()) if result.content else 0
        assert content_length >= 50

    def test_convert_result_with_empty_content(self):
        """Test ConvertResult with empty content."""
        result = ConvertResult(content="", format="md", success=True)
        assert result.success is True
        assert result.content == ""
        content_length = len(result.content.strip()) if result.content else 0
        assert content_length < 50
