# Changelog

## 0.6.0 (8 March 2026)

- Be less aggressive about invalidating `Item`s
  - eg appending to an array cannot invalidate any existing path
- Reject integer keys in tables
- Allow floats and integers to be equal
- Implement `__copy__` and `__deepcopy__` on `Document`

## 0.5.0 (8 March 2026)

- Add `Item.parse()`
- Allow assigning `Documents`s back into the document (e.g. `doc1["a"] = doc2["b"]`)

## 0.4.0 (8 March 2026)

- Allow assigning `Item`s back into the document (e.g. `doc["b"] = doc["a"]`)

## 0.3.0 (8 March 2026)

- Invalidate `Item`s when the document changes
- Remove `TomlError`
- Bugfix inserting into inline table

## 0.2.0 (8 March 2026)

- Add support for manipulating comments

## 0.1.1 (7 March 2026)

- Initial release
