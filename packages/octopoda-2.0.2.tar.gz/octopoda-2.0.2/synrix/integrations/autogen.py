"""
Octopoda × AutoGen Integration
================================
Persistent memory for Microsoft AutoGen agents.

Setup:
    pip install octopoda pyautogen

Usage:
    from autogen import ConversableAgent
    from synrix.integrations.autogen import OctopodaAutoGenMemory

    memory = OctopodaAutoGenMemory(agent_id="autogen_assistant")

    assistant = ConversableAgent(
        name="assistant",
        system_message="You are a helpful assistant with persistent memory.",
        llm_config={"config_list": [{"model": "gpt-4"}]},
    )

    # Teach the agent something
    memory.remember("user_name", "Alice")
    memory.remember("project", "Building an AI startup")

    # Later, retrieve what it learned
    name = memory.recall("user_name")  # "Alice"

    # Search by meaning
    results = memory.search("startup details")

    # Use as a teachability replacement
    memory.learn_from_conversation(conversation_history)
"""

from __future__ import annotations

import time
import json
from typing import Any, Dict, List, Optional

from synrix_runtime.api.runtime import AgentRuntime


class OctopodaAutoGenMemory:
    """
    Persistent memory for AutoGen agents.

    Replaces AutoGen's built-in Teachability with Octopoda-backed memory
    that includes semantic search, knowledge graphs, and temporal versioning.

    Features:
        - Persists across agent restarts
        - Semantic search for relevant memories
        - Knowledge graph extraction
        - Temporal versioning
        - Works with ConversableAgent, AssistantAgent, GroupChat
    """

    def __init__(
        self,
        agent_id: str = "autogen_agent",
        auto_learn: bool = True,
    ):
        self.agent_id = agent_id
        self.auto_learn = auto_learn
        self._runtime = AgentRuntime(agent_id, agent_type="autogen")

    # ----- Core memory operations -----

    def remember(self, key: str, value: Any, tags: List[str] = None) -> bool:
        """Store a memory. Returns True on success."""
        result = self._runtime.remember(key, value, tags=tags)
        return result.success

    def recall(self, key: str) -> Optional[Any]:
        """Recall a specific memory by key."""
        result = self._runtime.recall(key)
        return result.value if result.found else None

    def search(self, query: str, limit: int = 5) -> List[Dict]:
        """Search memories by meaning (semantic search)."""
        result = self._runtime.recall_similar(query, limit=limit)
        return result.items

    def related(self, entity: str) -> Dict:
        """Query the knowledge graph for entity relationships."""
        result = self._runtime.related(entity)
        return {
            "entity": result.entity,
            "type": result.entity_type,
            "relationships": result.relationships,
            "found": result.found,
        }

    def history(self, key: str) -> List[Dict]:
        """Get all versions of a memory over time."""
        result = self._runtime.recall_history(key)
        return result.versions

    # ----- AutoGen-specific: conversation learning -----

    def learn_from_conversation(self, messages: List[Dict]) -> int:
        """
        Extract and store knowledge from a conversation history.

        Args:
            messages: List of dicts with 'role' and 'content' keys
                      (standard AutoGen/OpenAI message format)

        Returns:
            Number of memories stored
        """
        stored = 0
        for i, msg in enumerate(messages):
            content = msg.get("content", "")
            role = msg.get("role", "user")
            name = msg.get("name", role)

            if not content or not isinstance(content, str):
                continue

            # Store each meaningful message
            key = f"conversation:turn_{i}:{name}"
            self.remember(key, content, tags=["conversation", name, role])
            stored += 1

        # Store conversation summary
        if messages:
            all_text = "\n".join(
                f"{m.get('name', m.get('role', 'unknown'))}: {m.get('content', '')}"
                for m in messages if m.get("content")
            )
            self.remember(
                f"conversation:summary:{int(time.time())}",
                all_text,
                tags=["conversation_summary"],
            )
            stored += 1

        return stored

    def get_relevant_context(self, query: str, limit: int = 3) -> str:
        """
        Get relevant context from memory for an agent's system message.

        Usage:
            context = memory.get_relevant_context("What do we know about the user?")
            system_message = f"You are a helpful assistant.\\n\\nRelevant context:\\n{context}"
        """
        results = self.search(query, limit=limit)
        if not results:
            return ""

        parts = []
        for r in results:
            val = r.get("value", "")
            score = r.get("score", 0)
            if score > 0.3:  # Only include reasonably relevant results
                parts.append(f"- {val}")

        return "\n".join(parts) if parts else ""

    # ----- AutoGen GroupChat support -----

    def save_group_message(self, sender: str, content: str, group_name: str = "default") -> bool:
        """Store a message from a group chat."""
        return self.remember(
            f"group:{group_name}:msg:{int(time.time() * 1000)}",
            {"sender": sender, "content": content, "timestamp": time.time()},
            tags=["group_chat", group_name, sender],
        )

    def get_group_history(self, group_name: str = "default", limit: int = 50) -> List[Dict]:
        """Get message history for a group chat."""
        result = self._runtime.search(f"group:{group_name}:msg:", limit=limit)
        return result.items

    def search_group(self, query: str, group_name: str = "default", limit: int = 5) -> List[Dict]:
        """Search within a group chat's history."""
        # Use semantic search, which searches all memories
        all_results = self.search(query, limit=limit * 2)
        # Filter to group messages
        group_results = [
            r for r in all_results
            if f"group:{group_name}" in r.get("key", "")
        ]
        return group_results[:limit]
