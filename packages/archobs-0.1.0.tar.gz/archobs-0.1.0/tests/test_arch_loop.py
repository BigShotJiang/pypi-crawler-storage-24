from __future__ import annotations

import shlex
import subprocess
from collections import Counter
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
SCRIPT = ROOT / "arch-loop.sh"
HEADERS = [
    "## Suggestion 1/3: One",
    "## Suggestion 2/3: Two",
    "## Suggestion 3/3: Three",
]


def _run_bash(script: str) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        ["bash", "-lc", script],
        cwd=ROOT,
        check=True,
        capture_output=True,
        text=True,
    )


def test_weighted_headers_returns_each_suggestion_once() -> None:
    command = f"""
source "{SCRIPT}"
ARCH_LOOP_RANDOM_SEED=123 weighted_headers <<'EOF'
{chr(10).join(HEADERS)}
EOF
"""

    result = _run_bash(command)
    lines = result.stdout.strip().splitlines()

    assert len(lines) == len(HEADERS)
    assert set(lines) == set(HEADERS)


def test_weighted_headers_favors_lower_numbered_suggestions() -> None:
    headers_text = "\\n".join(HEADERS)
    command = f"""
source "{SCRIPT}"
headers=$'{headers_text}'
for seed in $(seq 1 400); do
  ARCH_LOOP_RANDOM_SEED="$seed" weighted_headers <<< "$headers" | head -n 1
done
"""

    result = _run_bash(command)
    counts = Counter(result.stdout.strip().splitlines())

    assert counts[HEADERS[0]] > counts[HEADERS[1]] > counts[HEADERS[2]]


def test_commit_change_uses_prompt_as_commit_body(tmp_path: Path) -> None:
    capture = tmp_path / "git-commit-args.bin"
    prompt = "## Suggestion 1/3: One\\nApply the requested refactor.\\n\\nKeep tests green."
    command = f"""
source "{SCRIPT}"
capture={shlex.quote(str(capture))}
git() {{
  if [[ "$1" == "commit" ]]; then
    printf '%s\\0' "$@" > "$capture"
  fi
  return 0
}}
prompt=$'{prompt}'
commit_change "{HEADERS[0]}" "$prompt"
"""

    _run_bash(command)
    args = capture.read_bytes().split(b"\0")[:-1]

    assert args == [
        b"commit",
        b"-m",
        b"archobs: One",
        b"-m",
        b"## Suggestion 1/3: One\nApply the requested refactor.\n\nKeep tests green.",
    ]
