# platform-common

**This package is reserved by [Blockaid](https://blockaid.io) and is not intended for public use.**

If you are seeing this, this name has been claimed to prevent dependency confusion attacks.
The actual package is distributed via Blockaid's internal package registry.
