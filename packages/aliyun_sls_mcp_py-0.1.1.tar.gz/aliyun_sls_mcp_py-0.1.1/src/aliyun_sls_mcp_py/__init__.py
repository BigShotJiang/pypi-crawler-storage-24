"""Aliyun SLS MCP Server - Pure Python Implementation"""

__version__ = "0.1.0"
