"""Aliyun SLS MCP Server entry point"""

from aliyun_sls_mcp_py.server import main

if __name__ == "__main__":
    main()
