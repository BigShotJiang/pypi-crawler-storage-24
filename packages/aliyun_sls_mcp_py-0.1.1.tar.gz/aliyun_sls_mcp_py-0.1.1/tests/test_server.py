"""Tests for Aliyun SLS MCP Server"""

import pytest
from datetime import datetime

from aliyun_sls_mcp_py.server import parse_time, format_timestamp


class TestTimeParsing:
    """时间解析测试"""

    def test_parse_now(self):
        """测试 'now' 解析"""
        result = parse_time("now")
        assert isinstance(result, int)
        assert result > 0

    def test_parse_relative_hours(self):
        """测试相对时间 - 小时"""
        result = parse_time("-1h")
        assert isinstance(result, int)
        now = int(datetime.now().timestamp())
        assert now - 3600 - 10 <= result <= now - 3600 + 10

    def test_parse_relative_days(self):
        """测试相对时间 - 天"""
        result = parse_time("-1d")
        assert isinstance(result, int)
        now = int(datetime.now().timestamp())
        expected = now - 86400
        assert expected - 10 <= result <= expected + 10

    def test_parse_relative_minutes(self):
        """测试相对时间 - 分钟"""
        result = parse_time("-30m")
        assert isinstance(result, int)

    def test_parse_timestamp_seconds(self):
        """测试秒级时间戳"""
        ts = 1704067200  # 2024-01-01 00:00:00
        result = parse_time(ts)
        assert result == ts

    def test_parse_timestamp_milliseconds(self):
        """测试毫秒级时间戳"""
        ts_ms = 1704067200000
        result = parse_time(ts_ms)
        assert result == 1704067200

    def test_parse_iso_format(self):
        """测试 ISO 格式"""
        result = parse_time("2024-01-01T00:00:00")
        assert result == 1704067200


class TestFormatTimestamp:
    """时间戳格式化测试"""

    def test_format_seconds(self):
        """测试秒级时间戳格式化"""
        result = format_timestamp(1704067200)
        assert "2024" in result

    def test_format_milliseconds(self):
        """测试毫秒级时间戳格式化"""
        result = format_timestamp(1704067200000)
        assert "2024" in result


# 集成测试需要真实 SLS 凭证，跳过
@pytest.mark.skip(reason="需要 SLS 凭证")
class TestSLSIntegration:
    """SLS 集成测试"""

    def test_list_logstores(self):
        pass

    def test_query_logs(self):
        pass
