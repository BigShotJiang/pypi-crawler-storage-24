"""
insurance-cure: Mixture cure models for insurance non-claimer scoring.

This library fills a specific gap: no Python package provides a
covariate-aware mixture cure model (MCM) with actuarial output.
R has smcure, flexsurvcure, cuRe. Python has nothing pip-installable
that matches this capability.

The MCM splits a population into two latent groups:

1. Structurally immune — will never experience the target event
   (e.g. a structural non-claimer who would not claim regardless of
   how long you observed them).

2. Susceptible — will eventually experience the event, modelled by
   a conditional survival distribution.

The population survival function is:

    S_pop(t | x, z) = pi(z) * S_u(t | x) + [1 - pi(z)]

where pi(z) = P(susceptible | z) is a logistic incidence sub-model
and S_u(t | x) is the latency survival for susceptibles.

The primary output is a per-policyholder susceptibility score
pi(z_i) — a non-claimer probability score that drives pricing
differentiation between structural non-claimers and genuine risk.

Key classes
-----------
WeibullMixtureCure
    EM with Weibull AFT latency. The primary workhorse. Best default
    choice: parametric extrapolation, clean shape interpretation.

LogNormalMixtureCure
    EM with log-normal AFT latency. Better fit when the conditional
    hazard for susceptibles is non-monotone (peaks then falls).

CoxMixtureCure
    EM with semiparametric Cox PH latency. Most flexible baseline
    hazard. Cannot extrapolate beyond the observation window.

PromotionTimeCure
    Non-mixture model (Tsodikov 1998). Population-level PH structure.
    Include for comparison; less natural insurance interpretation than MCM.

Diagnostics
-----------
sufficient_followup_test
    Maller-Zhou Qn test. Run BEFORE fitting — if follow-up is too short,
    the cure fraction estimate is upwardly biased.

CureScorecard
    Decile table of predicted cure fractions versus observed event rates.
    Standard validation for pricing committee sign-off.

Data simulation
---------------
simulate_motor_panel
    Synthetic multi-year motor panel with NCB structure and known
    true cure fraction. For validation and demo purposes.

simulate_pet_panel
    Synthetic pet insurance cross-section.

Quick start
-----------
>>> import pandas as pd
>>> from insurance_cure import WeibullMixtureCure
>>> from insurance_cure.diagnostics import sufficient_followup_test
>>> from insurance_cure.simulate import simulate_motor_panel

>>> df = simulate_motor_panel(n_policies=3000, cure_fraction=0.40, seed=42)

>>> # Always check sufficient follow-up before trusting the model
>>> qn = sufficient_followup_test(df["tenure_months"], df["claimed"])
>>> print(qn.summary())

>>> model = WeibullMixtureCure(
...     incidence_formula="ncb_years + age + vehicle_age",
...     latency_formula="ncb_years + age",
...     n_em_starts=5,
... )
>>> model.fit(df, duration_col="tenure_months", event_col="claimed")
>>> print(model.result_.summary())

>>> cure_scores = model.predict_cure_fraction(df)
>>> pop_surv = model.predict_population_survival(df, times=[12, 24, 36, 60])

References
----------
- Farewell (1982), Biometrics 38:1041-1046
- Maller & Zhou (1996), Survival Analysis with Long-Term Survivors, Wiley
- Peng & Dear (2000), Biometrics 56:237-243
- Sy & Taylor (2000), Biometrics 56:227-236
- Tsodikov (1998), JRSS-B 60:195-207
"""

from .weibull import WeibullMixtureCure
from .lognormal import LogNormalMixtureCure
from .cox import CoxMixtureCure
from .promotion_time import PromotionTimeCure
from ._base import MCMResult
from . import diagnostics
from . import simulate

__version__ = "0.1.0"

__all__ = [
    # Core model classes
    "WeibullMixtureCure",
    "LogNormalMixtureCure",
    "CoxMixtureCure",
    "PromotionTimeCure",
    # Results
    "MCMResult",
    # Submodules
    "diagnostics",
    "simulate",
    # Version
    "__version__",
]
