<div align="center">

# 🌍 pytest-translate

### pytest terminal output in your language — automatically

[![Python](https://img.shields.io/badge/Python-3.9+-3776AB?style=for-the-badge&logo=python&logoColor=white)](https://python.org)
[![pytest](https://img.shields.io/badge/pytest-Plugin-0A9EDC?style=for-the-badge&logo=pytest&logoColor=white)](https://pytest.org)
[![PyPI](https://img.shields.io/badge/PyPI-pytest--translate-blue?style=for-the-badge&logo=pypi&logoColor=white)](https://pypi.org/project/pytest-translate/)
[![Languages](https://img.shields.io/badge/Languages-134-brightgreen?style=for-the-badge)]()
[![License](https://img.shields.io/badge/License-MIT-yellow?style=for-the-badge)](LICENSE)

<br/>

**Why should pytest speak only English?**

A Chinese developer, a Japanese tester, an Arabic QA engineer — they all use pytest.
They all read `FAILED` and `short test summary info` in English.
Not anymore.

</div>

---

## ⚡ Quick Start

```bash
pip install pytest-translate
```

That's it. pytest now speaks your OS language automatically.

```bash
pytest tests/                    # auto-detects your OS locale
pytest tests/ --lang=zh_CN       # force Chinese
pytest tests/ --lang=fr_FR       # force French
pytest tests/ --lang=ja          # force Japanese
pytest tests/ --lang=ar          # force Arabic
pytest tests/ --lang=yi          # force Yiddish (yes, really)
pytest tests/ --lang=sa          # force Sanskrit (Hindu priests approved)
pytest tests/ --lang=off         # back to English
```

---

## 🗺️ How it works

`pytest-translate` hooks into pytest's terminal reporter and translates:

- **Test statuses** — `PASSED`, `FAILED`, `SKIPPED`, `ERROR`
- **Summary line** — `6 failed, 1 passed in 142s`
- **Section headers** — `FAILURES SUMMARY`, `short test summary`

Translation is done via **Google Translate** through `deep-translator` — 134 languages supported, zero configuration required.

---

## 🌐 Language detection priority

1. `--lang=zh_CN` CLI argument
2. `PYTEST_LANG=zh_CN` environment variable
3. OS locale (automatic — `fr_FR` on a French system, `zh_CN` on a Chinese system)
4. English fallback if detection fails

---

## 📦 Installation

```bash
pip install pytest-translate
```

Or with pip + deep-translator explicitly:

```bash
pip install pytest-translate deep-translator
```

---

## ⚙️ Configuration

### CLI

```bash
pytest tests/ --lang=zh_CN
```

### Environment variable

```bash
export PYTEST_LANG=zh_CN
pytest tests/
```

### pyproject.toml (permanent)

```toml
[tool.pytest.ini_options]
addopts = "--lang=zh_CN"
```

---

## 🗾 Supported languages (134)

Afrikaans, Albanian, Amharic, Arabic, Armenian, Azerbaijani, Basque, Bengali, Bosnian, Bulgarian, Catalan, Chinese (Simplified), Chinese (Traditional), Croatian, Czech, Danish, Dutch, English, Esperanto, Estonian, Filipino, Finnish, French, Galician, Georgian, German, Greek, Gujarati, Haitian Creole, Hausa, Hawaiian, Hebrew, Hindi, Hungarian, Icelandic, Indonesian, Irish, Italian, Japanese, Javanese, Kannada, Kazakh, Khmer, Korean, Kurdish, Kyrgyz, Lao, **Latin**, Latvian, Lithuanian, Macedonian, Malagasy, Malay, Malayalam, Maltese, Maori, Marathi, Mongolian, Myanmar, Nepali, Norwegian, Persian, Polish, Portuguese, Punjabi, Romanian, Russian, **Sanskrit**, Serbian, Sinhala, Slovak, Slovenian, Somali, Spanish, Swahili, Swedish, Tajik, Tamil, Telugu, Thai, Turkish, Ukrainian, Urdu, Uzbek, Vietnamese, Welsh, **Yiddish**, Yoruba, Zulu...

---

## 🤝 Contributors

| Contributor | Contribution |
|:------------|:-------------|
| [Julien Mer](https://github.com/julienmerconsulting) | Original author |

---

## 📄 License

MIT — do whatever you want with it.

---

<div align="center">

**Created by [Julien Mer](https://www.linkedin.com/in/julienmer/) — JMer Consulting**

*QA Architect · 20+ years · Katalon Top Partner Europe*

[![Newsletter](https://img.shields.io/badge/Newsletter-Bonnes_Pratiques_QA-blue?style=flat-square)](https://www.linkedin.com/newsletters/bonnes-pratiques-qa-6878703775620636672)

*Also check out [qa-autopilot](https://pypi.org/project/qa-autopilot/) — AI-powered diagnostic for Playwright test failures in 134 languages.*

</div>
