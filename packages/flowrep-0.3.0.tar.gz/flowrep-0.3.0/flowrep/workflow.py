import ast
import builtins
import functools
import hashlib
import inspect
import json
import re
import textwrap
from collections.abc import Callable
from dataclasses import asdict, is_dataclass
from typing import Any, cast

import networkx as nx
from networkx.algorithms.dag import topological_sort

from flowrep import tools


def _sanitize_input(keys, *args, **kwargs) -> dict[str, Any]:
    assert len(args) <= len(
        keys
    ), f"At most {len(keys)} positional arguments but {len(args)} were given"
    for ii, arg in enumerate(args):
        if keys[ii] in kwargs:
            raise TypeError(f"Multiple values for argument '{keys[ii]}'")
        kwargs[keys[ii]] = arg
    return kwargs


class FunctionDictFlowAnalyzer:
    def __init__(self, ast_dict, scope):
        self.graph = nx.DiGraph()
        self.scope = scope  # mapping from function names to objects
        self.function_defs = {}
        self.ast_dict = ast_dict
        self._call_counter = {}
        self._control_flow_list = []
        self._parallel_var = {}
        self._output_args = []

    @staticmethod
    def get_inputs_with_default(inp):
        args = [tag["arg"] for tag in inp["args"]]
        defaults = []
        for d in inp["defaults"]:
            defaults.append({"default": _ast_dict_to_python_object(d)})
        defaults = [{} for _ in range(len(inp["args"]) - len(defaults))] + defaults
        return dict(zip(args, defaults, strict=True))

    def analyze(self) -> tuple[nx.DiGraph, dict[str, Any]]:
        for arg in self.ast_dict.get("args", {}).get("args", []):
            if arg["_type"] == "arg":
                self._add_output_edge("input", arg["arg"])
        inputs = self.get_inputs_with_default(self.ast_dict.get("args", {}))
        return_was_called = False
        for node in self.ast_dict.get("body", []):
            assert not return_was_called
            self._visit_node(node)
            if node["_type"] == "Return":
                return_was_called = True
        return self.graph, self.function_defs, inputs, self._output_args

    def _visit_node(self, node, control_flow: str | None = None):
        if node["_type"] == "Assign":
            self._handle_assign(node, control_flow=control_flow)
        elif node["_type"] == "Expr":
            self._handle_expr(node, control_flow=control_flow)
        elif node["_type"] == "While":
            self._handle_while(node, control_flow=control_flow)
        elif node["_type"] == "For":
            self._handle_for(node, control_flow=control_flow)
        elif node["_type"] == "If":
            self._handle_if(node, control_flow=control_flow)
        elif node["_type"] == "Return":
            self._handle_return(node, control_flow=control_flow)
        else:
            raise NotImplementedError(f"Node type {node['_type']} not implemented")

    def _handle_return(self, node, control_flow: str | None = None):
        if not node["value"]:
            return
        if node["value"]["_type"] == "Tuple":
            for idx, elt in enumerate(node["value"]["elts"]):
                if elt["_type"] != "Name":
                    raise NotImplementedError("Only variable returns supported")
                self._add_input_edge(elt, "output", input_index=idx)
                self._output_args.append(elt["id"])
        elif node["value"]["_type"] == "Name":
            self._add_input_edge(node["value"], "output")
            self._output_args.append(node["value"]["id"])

    def _handle_if(self, node, control_flow: str | None = None):
        assert node["test"]["_type"] == "Call"
        control_flow = self._convert_control_flow(control_flow, tag="if")
        self._parse_function_call(node["test"], control_flow=f"{control_flow}-test")
        for n in node["body"]:
            self._visit_node(n, control_flow=f"{control_flow}-body")
        for n in node.get("orelse", []):
            cf_else = "/".join(
                control_flow.split("/")[:-1]
                + [control_flow.split("/")[-1].replace("if", "else") + "-body"]
            )
            self._visit_node(n, control_flow=cf_else)
            self._reconnect_parallel(cf_else, f"{control_flow}-body")
            self._register_parallel_variables(cf_else, f"{control_flow}-body")

    def _reconnect_parallel(self, control_flow: str, ref_control_flow: str):
        all_edges = list(self.graph.edges.data())
        for edge in all_edges:
            if (
                "control_flow" not in edge[2]
                or edge[2]["control_flow"] != control_flow
                or edge[2]["type"] == "output"
            ):
                continue
            var, ind = "_".join(edge[0].split("_")[:-1]), int(edge[0].split("_")[-1])
            while True:
                if any(
                    [
                        e[2].get("control_flow") == ref_control_flow
                        for e in self.graph.in_edges(f"{var}_{ind}", data=True)
                    ]
                ):
                    ind -= 1
                break
            if f"{var}_{ind}" != edge[0]:
                self.graph.add_edge(f"{var}_{ind}", edge[1], **edge[2])
                self.graph.remove_edge(edge[0], edge[1])

    def _register_parallel_variables(self, control_flow: str, ref_control_flow: str):
        data: dict[str, dict] = {control_flow: {}, ref_control_flow: {}}
        for edge in self.graph.edges.data():
            if (
                edge[2].get("control_flow", "") in [control_flow, ref_control_flow]
                and edge[2]["type"] == "output"
            ):
                data[edge[2]["control_flow"]][edge[1].rsplit("_", 1)[0]] = edge[1]
        for key in set(data[control_flow].keys()).intersection(
            data[ref_control_flow].keys()
        ):
            values = sorted([data[control_flow][key], data[ref_control_flow][key]])
            self._parallel_var[values[-1]] = [values[0]]
            if values[0] in self._parallel_var:
                self._parallel_var[values[-1]].extend(self._parallel_var.pop(values[0]))

    def _handle_while(self, node, control_flow: str | None = None):
        assert node["test"]["_type"] == "Call"
        control_flow = self._convert_control_flow(control_flow, tag="while")
        self._parse_function_call(node["test"], control_flow=f"{control_flow}-test")
        for n in node["body"]:
            self._visit_node(n, control_flow=f"{control_flow}-body")

    def _handle_for(self, node, control_flow: str | None = None):
        assert node["iter"]["_type"] == "Call"
        control_flow = self._convert_control_flow(control_flow, tag="for")

        unique_func_name = self._parse_function_call(
            node["iter"], control_flow=f"{control_flow}-iter"
        )
        self._parse_outputs(
            [node["target"]], unique_func_name, control_flow=control_flow
        )
        for n in node["body"]:
            self._visit_node(n, control_flow=f"{control_flow}-body")

    def _handle_expr(self, node, control_flow: str | None = None) -> str:
        value = node["value"]
        return self._parse_function_call(value, control_flow=control_flow)

    def _parse_function_call(self, value, control_flow: str | None = None) -> str:
        if value["_type"] != "Call":
            raise NotImplementedError(
                f"Only function calls allowed on RHS: {value['_type']}"
            )

        func_node = value["func"]
        if func_node["_type"] != "Name":
            raise NotImplementedError("Only simple functions allowed")

        func_name = func_node["id"]
        unique_func_name = self._get_unique_func_name(func_name)

        if func_name not in self.scope:
            raise ValueError(f"Function {func_name} not found in scope")

        self.function_defs[unique_func_name] = {"function": self.scope[func_name]}
        if control_flow is not None:
            self.function_defs[unique_func_name]["control_flow"] = control_flow

        arg_list = _get_function_keywords(self.scope[func_name])

        # Parse inputs (positional + keyword)
        for i, arg in enumerate(value.get("args", [])):
            self._add_input_edge(
                arg, unique_func_name, input_name=arg_list[i], control_flow=control_flow
            )
        for kw in value.get("keywords", []):
            self._add_input_edge(
                kw["value"],
                unique_func_name,
                input_name=kw["arg"],
                control_flow=control_flow,
            )
        return unique_func_name

    def _handle_assign(self, node, control_flow: str | None = None):
        unique_func_name = self._handle_expr(node, control_flow=control_flow)
        self._parse_outputs(
            node["targets"], unique_func_name, control_flow=control_flow
        )

    def _parse_outputs(
        self, targets, unique_func_name, control_flow: str | None = None
    ):
        if len(targets) == 1 and targets[0]["_type"] == "Tuple":
            for idx, elt in enumerate(targets[0]["elts"]):
                self._add_output_edge(
                    unique_func_name,
                    elt["id"],
                    output_index=idx,
                    control_flow=control_flow,
                )
        else:
            for target in targets:
                self._add_output_edge(
                    unique_func_name, target["id"], control_flow=control_flow
                )

    def _get_max_index(self, variable: str) -> int:
        index = 0
        while True:
            if len(self.graph.in_edges(f"{variable}_{index}")) > 0:
                index += 1
                continue
            break
        return index

    def _get_var_index(self, variable: str, output: bool = False) -> int:
        index = self._get_max_index(variable)
        if index == 0 and not output:
            raise KeyError(
                f"Variable {variable} not found in graph. "
                "This usually means that the variable was never defined."
            )
        if output:
            return index
        else:
            return index - 1

    def _add_output_edge(
        self, source: str, target: str, control_flow: str | None = None, **kwargs
    ):
        """
        Add an output edge from the source to the target variable.

        Args:
            source (str): The source node (function name).
            target (str): The target variable name.
            control_flow (str | None): The control flow tag, if any.
            **kwargs: Additional keyword arguments to pass to the edge.

        In the case of the following line:

        >>> y = f(x)

        This function will add an edge from the function `f` to the variable `y`.
        """
        versioned = f"{target}_{self._get_var_index(target, output=True)}"
        if control_flow is not None:
            kwargs["control_flow"] = control_flow
        self.graph.add_edge(source, versioned, type="output", **kwargs)

    def _add_input_edge(
        self, source: dict, target: str, control_flow: str | None = None, **kwargs
    ):
        """
        Add an input edge from the source variable to the target node.

        Args:
            source (dict): The source variable node.
            target (str): The target node (function name).
            control_flow (str | None): The control flow tag, if any.
            **kwargs: Additional keyword arguments to pass to the edge.

        In the case of the following line:

        >>> y = f(x)

        This function will add an edge from the variable `x` to the function `f`.
        """
        if source["_type"] != "Name":
            raise NotImplementedError(f"Only variable inputs supported, got: {source}")
        var_name = source["id"]
        if control_flow is not None:
            kwargs["control_flow"] = control_flow
        versioned = f"{var_name}_{self._get_var_index(var_name)}"
        self.graph.add_edge(versioned, target, type="input", **kwargs)
        if versioned in self._parallel_var:
            for key in self._parallel_var.pop(versioned):
                self.graph.add_edge(key, target, type="input", **kwargs)

    def _get_unique_func_name(self, base_name):
        i = self._call_counter.get(base_name, 0)
        self._call_counter[base_name] = i + 1
        return f"{base_name}_{i}"

    def _convert_control_flow(self, control_flow: str | None, tag: str) -> str:
        control_flow = "" if control_flow is None else f"{control_flow.split('-')[0]}/"
        counter = 0
        while True:
            if f"{control_flow}{tag}_{counter}" not in self._control_flow_list:
                self._control_flow_list.append(f"{control_flow}{tag}_{counter}")
                break
            counter += 1
        return f"{control_flow}{tag}_{counter}"


def _get_variables_from_subgraph(graph: nx.DiGraph, io_: str) -> set[str]:
    """
    Get variables from a subgraph based on the type of I/O and control flow.

    Args:
        graph (nx.DiGraph): The directed graph representing the function.
        io_ (str): The type of I/O to filter by ("input" or "output").
        control_flow (list, str): A list of control flow types to filter by.

    Returns:
        set[str]: A set of variable names that match the specified I/O type and
            control flow.
    """
    assert io_ in ["input", "output"], "io_ must be 'input' or 'output'"
    if io_ == "input":
        edge_ind = 0
    elif io_ == "output":
        edge_ind = 1
    return set(
        [edge[edge_ind] for edge in graph.edges.data() if edge[2]["type"] == io_]
    )


def _get_parent_graph(graph: nx.DiGraph, control_flow: str) -> nx.DiGraph:
    """
    Get parent body of the indented body

    Args:
        graph (nx.DiGraph): Full graph to look for the parent graph from
        control_flow (str): Control flow whose parent graph is to look for

    Returns:
        (nx.DiGraph): Parent graph
    """
    return nx.DiGraph(
        [
            edge
            for edge in graph.edges.data()
            if not _get_control_flow(edge[2]).startswith(control_flow)
        ]
    )


def _detect_io_variables_from_control_flow(
    graph: nx.DiGraph, subgraph: nx.DiGraph
) -> dict[str, list[str]]:
    """
    Detect input and output variables from a graph based on control flow.

    Args:
        graph (nx.DiGraph): The directed graph representing the function.

    Returns:
        dict[str, set]: A dictionary with keys "input" and "output", each
            containing a set

    Take a look at the unit tests for examples of how to use this function.
    """
    sg_body = nx.DiGraph(
        [
            edge
            for edge in subgraph.edges.data()
            if edge[0] != "input" and edge[1] != "output"
        ]
    )
    cf = sorted(
        [
            _get_control_flow(edge[2])
            for edge in sg_body.edges.data()
            if "control_flow" in edge[2]
        ]
    )
    if len(cf) == 0:
        return {"inputs": [], "outputs": []}
    assert all([cf[ii + 1].startswith(cf[ii]) for ii in range(len(cf) - 1)])
    parent_graph = _get_parent_graph(graph, cf[0])
    var_inp_1 = _get_variables_from_subgraph(graph=sg_body, io_="input")
    var_inp_2 = _get_variables_from_subgraph(graph=parent_graph, io_="output")
    var_out_1 = _get_variables_from_subgraph(graph=parent_graph, io_="input")
    var_out_2 = _get_variables_from_subgraph(graph=sg_body, io_="output")
    inputs = var_inp_1.intersection(var_inp_2)
    input_stem = [inp.rsplit("_", 1)[0] for inp in inputs]
    outputs = var_out_1.intersection(var_out_2)
    # Lines below are needed in order to add those outputs which are updated
    # during the control flow to the outputs. For example, the variable x in the
    # following workflow has to be in the outputs because it is updated in the
    # while loop, even though it is not used subsequently.
    # def f(x):
    #     while h(x):
    #         x, y = k(y)
    #     return y
    output_candidate = {}
    for edges in subgraph.edges:
        if edges[0] == "input" or edges[1] == "output":
            continue
        if edges[1].rsplit("_", 1)[0] in input_stem:
            output_candidate[edges[1].rsplit("_", 1)[0]] = edges[1]
    outputs.update(set(output_candidate.values()))
    return {
        "inputs": list(inputs),
        "outputs": list(outputs),
    }


def _extract_control_flows(graph: nx.DiGraph) -> list[str]:
    return list(set([_get_control_flow(edge[2]) for edge in graph.edges.data()]))


def _split_graphs_into_subgraphs(graph: nx.DiGraph) -> dict[str, nx.DiGraph]:
    return {
        control_flow: nx.DiGraph(
            [
                edge
                for edge in graph.edges.data()
                if _get_control_flow(edge[2]) == control_flow
            ]
        )
        for control_flow in _extract_control_flows(graph)
    }


def _get_subgraphs(graph: nx.DiGraph, cf_graph: nx.DiGraph) -> dict[str, nx.DiGraph]:
    """
    Separate a flat graph into subgraphs nested by control flows

    Args:
        graph (nx.DiGraph): Flat workflow graph
        cf_graph (nx.DiGraph): Control flow graph (cf. _get_control_flow_graph)

    Returns:
        dict[str, nx.DiGraph]: Subgraphs
    """
    subgraphs = _split_graphs_into_subgraphs(graph)
    for key in list(topological_sort(cf_graph))[::-1]:
        subgraph = subgraphs[key]
        node_name = key
        io_ = _detect_io_variables_from_control_flow(graph, subgraph)
        for parent_graph_name in cf_graph.predecessors(key):
            parent_graph = subgraphs[parent_graph_name]
            for inp in io_["inputs"]:
                parent_graph.add_edge(
                    inp, node_name, type="input", input_name=_remove_index(inp)
                )
            for out in io_["outputs"]:
                parent_graph.add_edge(
                    node_name, out, type="output", output_name=_remove_index(out)
                )
        for inp in io_["inputs"]:
            subgraph.add_edge("input", inp, type="output")
        for out in io_["outputs"]:
            subgraph.add_edge(out, "output", type="input")
    return subgraphs


def _extract_functions_from_graph(graph: nx.DiGraph) -> set:
    function_names = []
    for edge in graph.edges.data():
        if edge[2]["type"] == "output" and edge[0] != "input":
            function_names.append(edge[0])
        elif edge[2]["type"] == "input" and edge[1] != "output":
            function_names.append(edge[1])
    return set(function_names)


def _get_control_flow_graph(control_flows: list[str]) -> nx.DiGraph:
    """
    Create a graph based on the control flows. The indentation level
    corresponds to the graph level. The higher level body is the parent node
    of the lower body.


    Args:
        control_flows (list[str]): All control flows present in a workflow

    Returns:
        nx.DiGraph: Control flow graph
    """
    cf_list = []
    for cf in control_flows:
        if cf == "":
            continue
        if "/" in cf:
            cf_list.append(["/".join(cf.split("/")[:-1]), cf])
        else:
            cf_list.append(["", cf])
    graph = nx.DiGraph(cf_list)
    if len(graph) == 0:
        graph.add_node("")
    return graph


def _ast_dict_to_python_object(node_dict: dict[str, Any] | list[Any] | Any) -> Any:
    """
    Converts a dictionary representation of an AST (Abstract Syntax Tree) node
    back into the corresponding Python object. Supports lists, tuples, dictionaries,
    and constants.

    Args:
        node_dict (dict[str, Any] | list[Any] | Any): The dictionary representation
            of an AST node, or a list, or a constant value.

    Returns:
        Any: The reconstructed Python object. This could be a list, tuple, dictionary,
        or a constant value, depending on the input.

    Supported AST Node Types:
        - Tuple: Converts to a Python tuple.
        - Constant: Converts to the constant value.
        - Load: Ignored (used in AST context but not relevant for Python objects).

    Raises:
        ValueError: If an unsupported AST node type is encountered.
    """
    if isinstance(node_dict, dict):
        if "_type" in node_dict:
            node_type = node_dict["_type"]
            if node_type == "Tuple":
                # Handle tuples
                return tuple(
                    _ast_dict_to_python_object(item) for item in node_dict["elts"]
                )
            elif node_type == "Constant":
                # Handle constants
                return node_dict["value"]
            elif node_type == "Load":
                # Contexts like 'Load' are not directly relevant for the Python object
                return None
            elif node_type == "Name":
                raise NotImplementedError(
                    f"Arguments are not supported: {node_dict['id']}"
                )
            else:
                raise ValueError(
                    f"Unsupported type: {node_type} - you can use only non-mutable defaults"
                )
        else:
            # If it's a dictionary but not an AST node, process recursively
            return {
                key: _ast_dict_to_python_object(value)
                for key, value in node_dict.items()
            }
    elif isinstance(node_dict, list):
        # Recursively process lists
        return [_ast_dict_to_python_object(item) for item in node_dict]
    else:
        # Base case: return the value as is
        return node_dict


def _function_to_ast_dict(node):
    if isinstance(node, ast.AST):
        result = {"_type": type(node).__name__}
        for field, value in ast.iter_fields(node):
            result[field] = _function_to_ast_dict(value)
        return result
    elif isinstance(node, list):
        return [_function_to_ast_dict(item) for item in node]
    else:
        return node


def get_ast_dict(func: Callable) -> dict:
    """Get the AST dictionary representation of a function."""
    source_code = textwrap.dedent(inspect.getsource(func))
    tree = ast.parse(source_code)
    return _function_to_ast_dict(tree)


def analyze_function(func: Callable) -> tuple[nx.DiGraph, dict[str, Any], dict]:
    """Extracts the variable flow graph from a function"""
    ast_dict = get_ast_dict(func)
    scope = inspect.getmodule(func).__dict__ | vars(builtins)
    analyzer = FunctionDictFlowAnalyzer(ast_dict["body"][0], scope)
    return analyzer.analyze()


def _get_nodes(
    data: dict[str, dict],
    with_function: bool = False,
) -> dict[str, dict]:
    result = {}
    for label, function in data.items():
        func = function["function"]
        if hasattr(func, "get_flowrep_dict") and callable(func.get_flowrep_dict):
            result[label] = function["function"].get_flowrep_dict(with_io=True)
            result[label]["label"] = label
            if with_function:
                result[label]["function"] = function["function"]
        else:
            result[label] = {"function": function["function"], "type": "atomic"}
    return result


def _remove_index(s: str) -> str:
    return "_".join(s.split("_")[:-1])


def _get_control_flow(data: dict[str, Any]) -> str:
    """
    Get the control flow name

    Args:
        data (dict[str, Any]): metadata of the edge (which is stored in the
            third element of each edge of nx.Digraph)

    Returns:
        (str): Control flow name (e.g. While_0, For_3 etc.)
    """
    return data.get("control_flow", "").split("-")[0]


def _get_sorted_edges(graph: nx.DiGraph) -> list:
    """
    Sort the edges of the graph based on the topological order of the nodes.

    Args:
        graph (nx.DiGraph): The directed graph representing the function.

    Returns:
        list: A sorted list of edges in the graph.

    Example:

    >>> graph.add_edges_from([('A', 'B'), ('B', 'D'), ('A', 'C'), ('C', 'D')])
    >>> sorted_edges = _get_sorted_edges(graph)
    >>> print(sorted_edges)

    Output:

    >>> [('A', 'B', {}), ('A', 'C', {}), ('B', 'D', {}), ('C', 'D', {})]
    """
    topo_order = list(topological_sort(graph))
    node_order = {node: i for i, node in enumerate(topo_order)}
    return sorted(graph.edges.data(), key=lambda edge: node_order[edge[0]])


def _remove_and_reconnect_nodes(
    G: nx.DiGraph, nodes_to_remove: list[str]
) -> nx.DiGraph:
    for node in set(nodes_to_remove):
        preds = list(G.predecessors(node))
        succs = list(G.successors(node))
        for u in preds:
            for v in succs:
                G.add_edge(u, v)
        G.remove_node(node)
    return G


def _get_edges(
    graph: nx.DiGraph, output_mapping: dict[str, list]
) -> list[tuple[str, str]]:
    edges = []
    nodes_to_remove = []
    for edge in graph.edges.data():
        if edge[0] == "input":
            edges.append([edge[0] + "s." + _remove_index(edge[1]), edge[1]])
            nodes_to_remove.append(edge[1])
        elif edge[1] == "output":
            edges.append([edge[0], edge[1] + "s." + _remove_index(edge[0])])
            nodes_to_remove.append(edge[0])
        elif edge[2]["type"] == "input":
            tag = edge[2].get("input_name", edge[2].get("input_index"))
            if tag is None:
                raise ValueError(f"Edge {edge} has no input_name or input_index")
            edges.append([edge[0], f"{edge[1]}.inputs.{tag}"])
            nodes_to_remove.append(edge[0])
        elif edge[2]["type"] == "output":
            if edge[0] in output_mapping:
                if "output_index" in edge[2]:
                    tag = output_mapping[edge[0]][edge[2]["output_index"]]
                else:
                    tag = output_mapping[edge[0]][0]
            else:
                tag = edge[2].get("output_name", edge[2].get("output_index", "output"))
            edges.append([f"{edge[0]}.outputs.{tag}", edge[1]])
            nodes_to_remove.append(edge[1])
    new_graph = _remove_and_reconnect_nodes(nx.DiGraph(edges), nodes_to_remove)
    return [tuple(e.split("/")[-1] for e in edge) for edge in new_graph.edges]


def _to_workflow_dict_entry(
    inputs: dict[str, dict],
    outputs: list[str] | dict[str, dict],
    nodes: dict[str, dict],
    edges: list[tuple[str, str]],
    label: str,
    **kwargs,
) -> dict[str, object]:
    assert all(
        "function" in v or ("nodes" in v and "edges" in v) for v in nodes.values()
    )
    if isinstance(outputs, list):
        outputs = {output: {} for output in outputs}
    return {
        "inputs": inputs,
        "outputs": outputs,
        "nodes": nodes,
        "edges": edges,
        "label": label,
        "type": "workflow",
    } | kwargs


def _get_test_dict(f_dict: dict[str, dict]) -> dict[str, str]:
    """
    dict to translate test and iter nodes into "test" and "iter"

    Args:
        f_dict (dict[str, dict]): Function dictionary

    Returns:
        dict[str, str]: Translation of node name to "test" or "iter"
    """
    return {
        key: tag
        for key, value in f_dict.items()
        for tag in ["test", "iter"]
        if value.get("control_flow", "").endswith(tag)
    }


def _nest_nodes(
    graph: nx.DiGraph, nodes: dict[str, dict], f_dict: dict[str, dict]
) -> tuple[dict[str, dict], list[tuple[str, str]]]:
    """
    Nest workflow nodes

    Args:
        graph (nx.DiGraph): The directed graph representing the function.
        nodes (dict[str, dict]): The dictionary of nodes.
        f_dict (dict[str, dict]): The dictionary of functions.

    Returns:
        dict: A dictionary containing the nested nodes, edges, and label.
    """
    test_dict = _get_test_dict(f_dict=f_dict)
    cf_graph = _get_control_flow_graph(_extract_control_flows(graph))
    subgraphs = _get_subgraphs(graph, cf_graph)
    injected_nodes: dict[str, Any] = {}
    for cf_key in list(topological_sort(cf_graph))[::-1]:
        subgraph = nx.relabel_nodes(subgraphs[cf_key], test_dict)
        new_key = cf_key if len(cf_key) > 0 else cf_key
        current_nodes = {}
        output_mapping = {}
        for key in _extract_functions_from_graph(subgraphs[cf_key]):
            dict_key = key.split("/")[-1]
            if key in test_dict:
                current_nodes[test_dict[key]] = nodes[key]
            elif key in nodes:
                current_nodes[dict_key] = nodes[key]
                if "outputs" in current_nodes[dict_key]:
                    output_mapping[key] = list(current_nodes[key]["outputs"].keys())
                    current_nodes[dict_key].pop("outputs")
            else:
                current_nodes[dict_key] = injected_nodes.pop(key)
        injected_nodes[new_key] = {
            "nodes": current_nodes,
            "edges": _get_edges(graph=subgraph, output_mapping=output_mapping),
            "label": new_key.split("/")[-1],
            "type": cf_key.split("/")[-1].split("_")[0] if cf_key != "" else "workflow",
        }
        for tag in ["test", "iter"]:
            if tag in injected_nodes[new_key]["nodes"]:
                injected_nodes[new_key][tag] = injected_nodes[new_key]["nodes"].pop(tag)
    return injected_nodes[""]["nodes"], injected_nodes[""]["edges"]


def get_workflow_dict(
    func: Callable, with_function: bool = False, with_io: bool = False
) -> dict[str, object]:
    """
    Get a dictionary representation of the workflow for a given function.

    Args:
        func (Callable): The function to be analyzed.

    Returns:
        dict: A dictionary representation of the workflow, including inputs,
            outputs, nodes, edges, and label.
        with_function (bool): Whether to include the function object in the
            workflow dictionary.
    """
    graph, f_dict, inputs, outputs = analyze_function(func)
    nodes = _get_nodes(f_dict, with_function=with_function)
    nested_nodes, edges = _nest_nodes(graph, nodes, f_dict)
    result = _to_workflow_dict_entry(
        inputs=inputs,
        outputs=outputs,
        nodes=nested_nodes,
        edges=edges,
        label=func.__name__,
    )
    if not with_io:
        result.pop("outputs")
        result.pop("inputs")
        for node in result["nodes"].values():
            if "outputs" in node:
                node.pop("outputs")
            if "inputs" in node:
                node.pop("inputs")
    if with_function:
        result["function"] = func
    return result


def _get_missing_edges(edge_list: list[tuple[str, str]]) -> list[tuple[str, str]]:
    """
    Insert processes into the data edges. Take the following workflow:

    >>> y = f(x=x)
    >>> z = g(y=y)

    The data flow is

    - f.inputs.x -> f.outputs.y
    - f.outputs.y -> g.inputs.y
    - g.inputs.y -> g.outputs.z

    `_get_missing_edges` adds the processes:

    - f.inputs.x -> f
    - f -> f.outputs.y
    - f.outputs.y -> g.inputs.y
    - g.inputs.y -> g
    - g -> g.outputs.z
    """
    extra_edges = []
    for edge in edge_list:
        for tag in edge:
            if len(tag.split(".")) < 3:
                continue
            if tag.split(".")[1] == "inputs":
                new_edge = (tag, tag.split(".")[0])
            elif tag.split(".")[1] == "outputs":
                new_edge = (tag.split(".")[0], tag)
            if new_edge not in extra_edges:
                extra_edges.append(new_edge)
    return edge_list + extra_edges


def workflow(func: Callable) -> Callable:
    """
    Decorator to convert a function into a workflow with metadata.

    Args:
        func (Callable): The function to be converted into a workflow.

    Returns:
        FunctionWithWorkflow: A callable object that includes the original function

    Example:

    >>> def operation(x: float, y: float) -> tuple[float, float]:
    >>>     return x + y, x - y
    >>>
    >>>
    >>> def add(x: float = 2.0, y: float = 1) -> float:
    >>>     return x + y
    >>>
    >>>
    >>> def multiply(x: float, y: float = 5) -> float:
    >>>     return x * y
    >>>
    >>>
    >>> @workflow
    >>> def example_macro(a=10, b=20):
    >>>     c, d = operation(a, b)
    >>>     e = add(c, y=d)
    >>>     f = multiply(e)
    >>>     return f
    >>>
    >>>
    >>> @workflow
    >>> def example_workflow(a=10, b=20):
    >>>     y = example_macro(a, b)
    >>>     z = add(y, b)
    >>>     return z

    This example defines a workflow `example_macro`, that includes `operation`,
    `add`, and `multiply`, which is nested inside another workflow
    `example_workflow`. Both workflows can be executed using their `run` method,
    which returns the dictionary representation of the workflow with all the
    intermediate steps and outputs.
    """
    func.get_flowrep_dict = functools.partial(get_workflow_dict, func)
    func.run = functools.partial(
        run_workflow_dict,
        func,
    )
    return func


def run_workflow_dict(
    func, *args, with_function: bool = False, **kwargs
) -> dict[str, Any]:
    wf_dict = get_workflow_dict(func, with_function=with_function, with_io=True)
    for arg, value in _sanitize_input(
        list(wf_dict["inputs"].keys()), *args, **kwargs
    ).items():
        wf_dict["inputs"][arg]["value"] = value
    G = get_workflow_graph(wf_dict)
    G_run = simple_run(G)
    return graph_to_wf_dict(G_run)


def get_workflow_graph(workflow_dict: dict[str, Any]) -> nx.DiGraph:
    """
    Convert a workflow dictionary into a directed graph representation.

    Args:
        workflow_dict (dict[str, Any]): The dictionary representation of the
            workflow.

    Returns:
        nx.DiGraph: A directed graph representing the workflow.
    """

    def _to_gnode(node: str) -> str:
        node_split = node.rsplit(".", 2)
        if len(node_split) < 2:
            return node
        if len(node_split) == 2:
            assert node_split[0] in [
                "inputs",
                "outputs",
            ], f"Node {node} is not correctly formatted"
            return f"{node_split[0]}@{node_split[1]}"
        assert node_split[1] in [
            "inputs",
            "outputs",
        ], f"Node {node} is not correctly formatted"
        return f"{node_split[0]}:{node_split[1]}@{node_split[2]}"

    G = nx.DiGraph()
    for inp, data in workflow_dict.get("inputs", {}).items():
        G.add_node(f"inputs@{inp}", step="input", **data)
    for out, data in workflow_dict.get("outputs", {}).items():
        G.add_node(f"outputs@{out}", step="output", **data)

    nodes_to_delete = []
    for key, node in workflow_dict["nodes"].items():
        assert node["type"] in ["atomic", "workflow"]
        if node["type"] == "workflow":
            child_G = get_workflow_graph(node)
            for child_key in list(child_G.graph.keys()):
                new_key = f"{key}/{child_key}" if child_key != "" else key
                child_G.graph[new_key] = child_G.graph[child_key]
            mapping = {}
            for n in child_G.nodes():
                if n.startswith("inputs@") or n.startswith("outputs@"):
                    mapping[n] = key + ":" + n
                else:
                    mapping[n] = key + "/" + n
            G = nx.union(nx.relabel_nodes(child_G, mapping), G)
            nodes_to_delete.append(key)
        else:
            G.add_node(
                key,
                step="node",
                **{k: v for k, v in node.items() if k not in ["inputs", "outputs"]},
            )
        for ii, (inp, data) in enumerate(node.get("inputs", {}).items()):
            G.add_node(f"{key}:inputs@{inp}", step="input", **({"position": ii} | data))
        for ii, (out, data) in enumerate(node.get("outputs", {}).items()):
            G.add_node(
                f"{key}:outputs@{out}", step="output", **({"position": ii} | data)
            )
    for edge in _get_missing_edges(cast(list[tuple[str, str]], workflow_dict["edges"])):
        G.add_edge(_to_gnode(edge[0]), _to_gnode(edge[1]))
    for node in nodes_to_delete:
        G.remove_node(node)
    for node in G.nodes():
        if "@" not in node:
            continue
        io = node.split(":")[-1].split("@")[0]
        assert io in ["inputs", "outputs"], f"Node {node} is not correctly formatted"
        G.nodes[node]["step"] = {"inputs": "input", "outputs": "output"}[io]
    G.graph[""] = {
        key: value
        for key, value in workflow_dict.items()
        if key not in ["nodes", "edges", "inputs", "outputs"]
    }

    return G


def get_hashed_node_dict(workflow_dict: dict[str, dict]) -> dict[str, Any]:
    G = get_workflow_graph(workflow_dict)
    hash_dict = {}

    for node in list(nx.topological_sort(G)):
        break_flag = False
        if "@" in node:
            for term in ["hash", "value"]:
                if "hash" not in G.nodes[node]:
                    for pre in G.predecessors(node):
                        if term in G.nodes[pre]:
                            G.nodes[node][term] = G.nodes[pre][term]
                            continue
            continue
        hash_dict_tmp = {
            "inputs": {},
            "outputs": [
                G.nodes[out].get("label", out.split("@")[-1])
                for out in G.successors(node)
            ],
            "node": tools.get_function_metadata(G.nodes[node]["function"]),
        }
        hash_dict_tmp["node"]["connected_inputs"] = []
        for inp in G.predecessors(node):
            data = G.nodes[inp]
            inp_name = inp.split("@")[-1]
            if "hash" in data:
                hash_dict_tmp["inputs"][inp_name] = data["hash"]
                hash_dict_tmp["node"]["connected_inputs"].append(inp_name)
            elif "value" in data:
                if is_dataclass(data["value"]):
                    hash_dict_tmp["inputs"][inp_name] = asdict(data["value"])
                else:
                    hash_dict_tmp["inputs"][inp_name] = data["value"]
            else:
                break_flag = True
        if break_flag:
            continue
        h = hashlib.sha256(
            json.dumps(hash_dict_tmp, sort_keys=True).encode("utf-8")
        ).hexdigest()
        for out in G.successors(node):
            G.nodes[out]["hash"] = (
                h + "@" + G.nodes[out].get("label", out.split("@")[-1])
            )
        hash_dict_tmp["hash"] = h
        hash_dict[node.replace("/", ".")] = hash_dict_tmp
    return hash_dict


def _set_entry(
    data: dict[str, Any], key: str, value: Any, create_missing: bool = False
) -> None:
    """
    Set a value in a nested dictionary at the specified key path.

    Args:
        data (dict[str, Any]): The dictionary to modify.
        key (str): The key path to set the value at, separated by dots.
        value (Any): The value to set.
        create_missing (bool): Whether to create missing keys in the path.
    """
    keys = key.split(".")
    for k in keys[:-1]:
        if k not in data:
            if create_missing:
                data[k] = {}
            else:
                raise KeyError(f"Key '{k}' not found in data.")
        data = data[k]
    data[keys[-1]] = value


def _get_function_keywords(function: Callable) -> list[str | int]:
    signature = inspect.signature(function)
    items = []
    for ii, (name, param) in enumerate(signature.parameters.items()):
        if param.kind == inspect.Parameter.POSITIONAL_ONLY:
            items.append(ii)
        else:
            items.append(name)
    return items


def simple_run(G: nx.DiGraph) -> nx.DiGraph:
    for node in nx.topological_sort(G):
        data = G.nodes[node]
        if data["step"] == "node":
            if all("value" in G.nodes[succ] for succ in G.successors(node)):
                continue
            kwargs = {}
            for inp in G.predecessors(node):
                kwargs[inp.split("@")[-1]] = G.nodes[inp]["value"]
            outputs = data["function"](**kwargs)
            successors = list(G.successors(node))
            if len(successors) == 1:
                G.nodes[successors[0]]["value"] = outputs
            else:
                for succ in successors:
                    G.nodes[succ]["value"] = outputs[
                        int(G.nodes[succ].get("position", succ.split("@")[-1]))
                    ]
            continue
        if "default" in data and "value" not in data:
            data["value"] = data["default"]
        if G.in_degree(node) == 0 and "value" not in data:
            raise ValueError(f"Input values not given for {node}")
        assert "value" in data
        for succ in G.successors(node):
            if G.nodes[succ].get("type") != "atomic":
                G.nodes[succ]["value"] = data["value"]
    return G


class GNode:
    def __init__(self, key: str):
        self.key = key

    @property
    def node(self) -> str | None:
        if "@" in self.key and ":" not in self.key:
            return None
        return self.key.split(":")[0]

    @property
    def node_list(self) -> list[str]:
        if self.node is None:
            return []
        return self.node.split("/")

    @property
    def io(self) -> str | None:
        arg = re.search(r":(inputs|outputs)@", self.key)
        if arg is not None:
            return arg.group(1)
        arg = re.search(r"(inputs|outputs)@", self.key)
        if arg is not None:
            return arg.group(1)
        return None

    @property
    def arg(self) -> str | None:
        return self.key.split("@")[-1] if "@" in self.key else None

    @property
    def is_io(self) -> bool:
        return self.io is not None


def graph_to_wf_dict(G: nx.DiGraph) -> dict:
    """
    Convert a directed graph representation of a workflow into a workflow
    dictionary.

    Args:
        G (nx.DiGraph): A directed graph representing the workflow.

    Returns:
        dict: The dictionary representation of the workflow.
    """
    wf_dict = tools.dict_to_recursive_dd({})

    for node, metadata in list(G.nodes.data()):
        gn = GNode(node)
        d = wf_dict
        for n in gn.node_list:
            d = d["nodes"][n]
        if gn.is_io:
            d[gn.io][gn.arg] = {
                key: value for key, value in metadata.items() if key != "step"
            }
        else:
            d.update({key: value for key, value in metadata.items() if key != "step"})

    for edge in G.edges:
        orig = GNode(edge[0])
        dest = GNode(edge[1])
        if not orig.is_io or not dest.is_io:
            continue
        if len(orig.node_list) == len(dest.node_list):
            nodes = orig.node_list[:-1]
            if len(orig.node_list) == 0:
                edge = (
                    ".".join([orig.io, orig.arg]),
                    ".".join([dest.io, dest.arg]),
                )
            else:
                edge = (
                    ".".join([orig.node_list[-1], orig.io, orig.arg]),
                    ".".join([dest.node_list[-1], dest.io, dest.arg]),
                )
        elif len(orig.node_list) > len(dest.node_list):
            nodes = dest.node_list
            edge = (
                ".".join([orig.node_list[-1], orig.io, orig.arg]),
                ".".join([dest.io, dest.arg]),
            )
        else:
            nodes = orig.node_list
            edge = (
                ".".join([orig.io, orig.arg]),
                ".".join([dest.node_list[-1], dest.io, dest.arg]),
            )
        d = wf_dict
        for node in nodes:
            d = d["nodes"][node]
        if not isinstance(d["edges"], list):
            d["edges"] = []
        d["edges"].append(edge)
    for key, value in G.graph.items():
        d = wf_dict
        if key != "":
            for n in key.split("/"):
                d = d["nodes"][n]
        for k, v in value.items():
            d[k] = v
    return tools.recursive_dd_to_dict(wf_dict)
