import pytest

try:
    import paddle

    HAS_PADDLE = True
except ImportError:
    HAS_PADDLE = False

from tensor_spec_worker.backend.paddle_backend import PaddleBackend

pytestmark = pytest.mark.skipif(not HAS_PADDLE, reason="paddle not installed")


@pytest.fixture
def backend():
    b = PaddleBackend()
    b.import_framework()
    return b


def test_name(backend):
    assert backend.name == "paddle"


def test_numpy_to_tensor(backend):
    import numpy as np

    from tensor_spec_core.tensor import Tensor

    spec = Tensor.float32((2, 3))
    np_data = np.ones((2, 3), dtype=np.float32)
    t = backend.numpy_to_tensor(np_data, spec)
    assert t.shape == [2, 3]
    assert str(t.dtype) == "paddle.float32"


def test_numpy_to_tensor_with_grad(backend):
    import numpy as np

    from tensor_spec_core.state import TensorState
    from tensor_spec_core.tensor import Tensor

    spec = Tensor.float32((2, 3)).with_state(TensorState(need_grad=True))
    np_data = np.ones((2, 3), dtype=np.float32)
    t = backend.numpy_to_tensor(np_data, spec)
    assert t.stop_gradient is False


def test_tensor_to_numpy(backend):
    import numpy as np

    t = paddle.to_tensor(np.array([1.0, 2.0, 3.0], dtype=np.float32))
    result = backend.tensor_to_numpy(t)
    assert isinstance(result, np.ndarray)
    np.testing.assert_array_equal(result, [1.0, 2.0, 3.0])


def test_exec_api_abs(backend):
    import numpy as np

    t = paddle.to_tensor(np.array([-1.0, 2.0, -3.0], dtype=np.float32))
    result = backend.exec_api("abs", (t,), {})
    expected = np.array([1.0, 2.0, 3.0], dtype=np.float32)
    np.testing.assert_array_equal(backend.tensor_to_numpy(result), expected)


def test_exec_api_add(backend):
    import numpy as np

    x = paddle.to_tensor(np.array([1.0, 2.0], dtype=np.float32))
    y = paddle.to_tensor(np.array([3.0, 4.0], dtype=np.float32))
    result = backend.exec_api("add", (), {"x": x, "y": y})
    np.testing.assert_array_equal(backend.tensor_to_numpy(result), [4.0, 6.0])


def test_exec_api_matmul(backend):
    import numpy as np

    x = paddle.to_tensor(np.eye(3, dtype=np.float32))
    y = paddle.to_tensor(np.array([[1.0], [2.0], [3.0]], dtype=np.float32))
    result = backend.exec_api("matmul", (), {"x": x, "y": y})
    np.testing.assert_array_almost_equal(backend.tensor_to_numpy(result), [[1.0], [2.0], [3.0]])


def test_paddle_check_cuda_error():
    b = PaddleBackend()
    b.import_framework()
    b.check_cuda_error()


def test_paddle_compute_grad():
    b = PaddleBackend()
    b.import_framework()
    import paddle

    x = paddle.to_tensor([1.0, 2.0, 3.0])
    x.stop_gradient = False
    y = paddle.sum(x * x)
    grads = b.compute_grad(y, [x])
    assert len(grads) == 1
    expected = [2.0, 4.0, 6.0]
    for g, e in zip(grads[0].numpy().tolist(), expected, strict=True):
        assert abs(g - e) < 1e-5
