"""Tests for CUDA IPC handle wrapper."""

from __future__ import annotations

import ctypes

import pytest

from tensor_spec_worker.ipc.cuda_handle import CudaIpcMemHandle, get_cuda_rt


class TestCudaIpcMemHandle:
    def test_structure_size(self):
        """Handle must be exactly 64 bytes."""
        handle = CudaIpcMemHandle()
        assert ctypes.sizeof(handle) == 64

    def test_bytes_roundtrip(self):
        """bytes() -> memmove roundtrip preserves data."""
        handle = CudaIpcMemHandle()
        for i in range(64):
            handle.reserved[i] = i % 128
        raw = bytes(handle.reserved)
        assert len(raw) == 64

        restored = CudaIpcMemHandle()
        ctypes.memmove(restored.reserved, raw, 64)
        assert bytes(restored.reserved) == raw


class TestGetCudaRt:
    def test_returns_none_or_cdll(self):
        """get_cuda_rt() returns None if no CUDA, or a CDLL with proper argtypes."""
        result = get_cuda_rt()
        assert result is None or hasattr(result, "cudaIpcGetMemHandle")


# GPU-only tests
_has_cuda = False
try:
    _rt = ctypes.CDLL("libcudart.so")
    _has_cuda = True
except OSError:
    pass

requires_cuda = pytest.mark.skipif(not _has_cuda, reason="No CUDA runtime")


def _child_open_handle(handle_bytes: bytes, result_queue) -> None:
    """Child process helper: open IPC handle and report success."""
    try:
        from tensor_spec_worker.ipc.cuda_handle import close_ipc_handle, open_ipc_handle

        opened_ptr = open_ipc_handle(handle_bytes)
        close_ipc_handle(opened_ptr)
        result_queue.put(("ok", opened_ptr))
    except Exception as exc:
        result_queue.put(("error", str(exc)))


@requires_cuda
class TestCudaIpcOperations:
    def test_get_handle_returns_64_bytes(self):
        """get_ipc_handle returns a 64-byte handle for allocated GPU memory."""
        from tensor_spec_worker.ipc.cuda_handle import get_ipc_handle

        cuda_rt = ctypes.CDLL("libcudart.so")
        ptr = ctypes.c_void_p()
        err = cuda_rt.cudaMalloc(ctypes.byref(ptr), ctypes.c_size_t(1024))
        assert err == 0, f"cudaMalloc failed: {err}"

        try:
            assert ptr.value is not None
            handle_bytes = get_ipc_handle(ptr.value)
            assert isinstance(handle_bytes, bytes)
            assert len(handle_bytes) == 64
        finally:
            cuda_rt.cudaFree(ptr)

    def test_open_handle_in_child_process(self):
        """IPC handle can be opened from a different process (CUDA IPC requirement)."""
        import multiprocessing

        from tensor_spec_worker.ipc.cuda_handle import get_ipc_handle

        cuda_rt = ctypes.CDLL("libcudart.so")
        ptr = ctypes.c_void_p()
        err = cuda_rt.cudaMalloc(ctypes.byref(ptr), ctypes.c_size_t(1024))
        assert err == 0, f"cudaMalloc failed: {err}"

        try:
            assert ptr.value is not None
            handle_bytes = get_ipc_handle(ptr.value)
            ctx = multiprocessing.get_context("spawn")
            q = ctx.Queue()
            child = ctx.Process(target=_child_open_handle, args=(handle_bytes, q))
            child.start()
            child.join(timeout=30)
            assert child.exitcode == 0, f"Child process exited with code {child.exitcode}"

            status, value = q.get(timeout=5)
            assert status == "ok", f"Child process error: {value}"
            assert value != 0
        finally:
            cuda_rt.cudaFree(ptr)
