"""Tests for SharedMemory-based numpy array transport."""

from __future__ import annotations

import numpy as np
import pytest

from tensor_spec_worker.ipc.shared_memory import ShmBuffer, read_array, unlink, write_array


class TestShmBuffer:
    def test_to_dict_roundtrip(self):
        buf = ShmBuffer(name="shm_test", shape=(2, 3), dtype="float32", nbytes=24)
        assert ShmBuffer.from_dict(buf.to_dict()) == buf

    def test_frozen(self):
        buf = ShmBuffer(name="x", shape=(1,), dtype="float32", nbytes=4)
        with pytest.raises(AttributeError):
            setattr(buf, "name", "y")


class TestWriteReadArray:
    def test_float32_roundtrip(self):
        arr = np.array([[1.0, 2.0], [3.0, 4.0]], dtype=np.float32)
        buf = write_array(arr)
        try:
            result = read_array(buf)
            np.testing.assert_array_equal(result, arr)
            assert result.dtype == arr.dtype
            assert result.shape == arr.shape
        finally:
            unlink(buf.name)

    def test_int64_roundtrip(self):
        arr = np.arange(100, dtype=np.int64)
        buf = write_array(arr)
        try:
            result = read_array(buf)
            np.testing.assert_array_equal(result, arr)
        finally:
            unlink(buf.name)

    def test_bool_roundtrip(self):
        arr = np.array([True, False, True], dtype=np.bool_)
        buf = write_array(arr)
        try:
            result = read_array(buf)
            np.testing.assert_array_equal(result, arr)
        finally:
            unlink(buf.name)

    def test_empty_array(self):
        arr = np.array([], dtype=np.float32)
        buf = write_array(arr)
        try:
            result = read_array(buf)
            assert result.shape == (0,)
        finally:
            unlink(buf.name)

    def test_large_nd_array(self):
        arr = np.random.default_rng(42).standard_normal((8, 3, 32, 32)).astype(np.float32)
        buf = write_array(arr)
        try:
            result = read_array(buf)
            np.testing.assert_array_equal(result, arr)
        finally:
            unlink(buf.name)

    def test_result_is_owned_copy(self):
        """read_array returns an owned copy --- safe after unlink."""
        arr = np.array([1.0, 2.0], dtype=np.float32)
        buf = write_array(arr)
        result = read_array(buf)
        unlink(buf.name)
        assert result[0] == 1.0
