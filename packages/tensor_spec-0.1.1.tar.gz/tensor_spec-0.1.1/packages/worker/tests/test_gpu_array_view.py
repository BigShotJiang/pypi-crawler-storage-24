"""Tests for GpuArrayView -- __cuda_array_interface__ wrapper."""

from __future__ import annotations

import pytest

from tensor_spec_worker.ipc.gpu_array_view import DTYPE_TO_TYPESTR, GpuArrayView


class TestGpuArrayView:
    def test_interface_shape(self):
        view = GpuArrayView(ptr=0xDEADBEEF, shape=(2, 3), dtype="float32")
        iface = view.__cuda_array_interface__
        assert iface["shape"] == (2, 3)

    def test_interface_typestr(self):
        view = GpuArrayView(ptr=0x1000, shape=(4,), dtype="float64")
        assert view.__cuda_array_interface__["typestr"] == "<f8"

    def test_interface_data_ptr(self):
        view = GpuArrayView(ptr=42, shape=(1,), dtype="int32")
        data = view.__cuda_array_interface__["data"]
        assert isinstance(data, tuple)
        assert data[0] == 42
        assert data[1] is False

    def test_interface_version(self):
        view = GpuArrayView(ptr=0, shape=(1,), dtype="float32")
        assert view.__cuda_array_interface__["version"] == 2

    def test_unknown_dtype_raises(self):
        with pytest.raises(ValueError, match="Unsupported dtype"):
            GpuArrayView(ptr=0, shape=(1,), dtype="weird_type")


class TestDtypeMapping:
    @pytest.mark.parametrize(
        ("dtype", "expected"),
        [
            ("float16", "<f2"),
            ("float32", "<f4"),
            ("float64", "<f8"),
            ("int8", "<i1"),
            ("int16", "<i2"),
            ("int32", "<i4"),
            ("int64", "<i8"),
            ("uint8", "<u1"),
            ("bool", "|b1"),
            ("complex64", "<c8"),
            ("complex128", "<c16"),
        ],
    )
    def test_dtype_to_typestr(self, dtype, expected):
        assert DTYPE_TO_TYPESTR[dtype] == expected

    def test_all_common_dtypes_covered(self):
        required = {
            "float16",
            "float32",
            "float64",
            "int8",
            "int16",
            "int32",
            "int64",
            "uint8",
            "bool",
            "complex64",
            "complex128",
        }
        assert required.issubset(set(DTYPE_TO_TYPESTR.keys()))
