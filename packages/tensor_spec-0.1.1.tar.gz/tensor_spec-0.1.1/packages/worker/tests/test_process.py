"""Tests for worker process -- runs the worker as a subprocess."""

from __future__ import annotations

import json
import subprocess
import sys

import numpy as np
import pytest

from tensor_spec_worker.ipc.shared_memory import ShmBuffer, read_array, unlink, write_array


def _start_worker(backend: str) -> subprocess.Popen:
    """Start a worker subprocess using current Python."""
    return subprocess.Popen(
        [sys.executable, "-m", "tensor_spec_worker", "--backend", backend],
        stdin=subprocess.PIPE,
        stdout=subprocess.PIPE,
        text=True,
    )


def _send(proc: subprocess.Popen, msg_type: str, payload: dict | None = None) -> dict:
    """Send a request and read a response."""
    msg: dict = {"id": 1, "type": msg_type}
    if payload:
        msg["payload"] = payload
    assert proc.stdin is not None
    assert proc.stdout is not None
    proc.stdin.write(json.dumps(msg) + "\n")
    proc.stdin.flush()
    line = proc.stdout.readline()
    return json.loads(line)


class TestWorkerLifecycle:
    def test_ping(self):
        proc = _start_worker("paddle")
        try:
            resp = _send(proc, "ping")
            assert resp["ok"] is True
            assert resp["result"] == "pong"
        finally:
            _send(proc, "shutdown")
            proc.wait(timeout=5)

    def test_shutdown(self):
        proc = _start_worker("paddle")
        resp = _send(proc, "shutdown")
        assert resp["ok"] is True
        proc.wait(timeout=5)
        assert proc.returncode == 0

    def test_unknown_message(self):
        proc = _start_worker("paddle")
        try:
            resp = _send(proc, "totally_unknown_type")
            assert resp["ok"] is False
            assert "Unknown" in resp["error"]
        finally:
            _send(proc, "shutdown")
            proc.wait(timeout=5)


@pytest.fixture()
def paddle_worker():
    pytest.importorskip("paddle")
    proc = _start_worker("paddle")
    _send(proc, "import_framework")
    yield proc
    _send(proc, "shutdown")
    proc.wait(timeout=5)


class TestWorkerLoadStoreTensor:
    def test_load_float32(self, paddle_worker):
        arr = np.array([1.0, 2.0, 3.0], dtype=np.float32)
        buf = write_array(arr)
        try:
            resp = _send(
                paddle_worker,
                "load_tensor",
                {
                    "shm_name": buf.name,
                    "shape": list(arr.shape),
                    "dtype": "float32",
                },
            )
            assert resp["ok"] is True
            assert "tensor_id" in resp["result"]
        finally:
            unlink(buf.name)

    def test_store_roundtrip(self, paddle_worker):
        arr = np.array([10.0, 20.0], dtype=np.float64)
        buf = write_array(arr)
        try:
            resp = _send(
                paddle_worker,
                "load_tensor",
                {
                    "shm_name": buf.name,
                    "shape": list(arr.shape),
                    "dtype": "float64",
                },
            )
            tid = resp["result"]["tensor_id"]
        finally:
            unlink(buf.name)

        resp = _send(paddle_worker, "store_tensor", {"tensor_id": tid})
        assert resp["ok"] is True
        result = read_array(ShmBuffer.from_dict(resp["result"]))
        unlink(resp["result"]["name"])
        np.testing.assert_array_equal(result, arr)


class TestWorkerExecApi:
    def test_exec_abs(self, paddle_worker):
        arr = np.array([-1.0, 2.0, -3.0], dtype=np.float32)
        buf = write_array(arr)
        try:
            resp = _send(
                paddle_worker,
                "load_tensor",
                {
                    "shm_name": buf.name,
                    "shape": list(arr.shape),
                    "dtype": "float32",
                },
            )
            tid = resp["result"]["tensor_id"]
        finally:
            unlink(buf.name)

        resp = _send(
            paddle_worker,
            "exec_api",
            {
                "api": "abs",
                "args": [{"_ref": tid}],
                "kwargs": {},
            },
        )
        assert resp["ok"] is True
        result_tid = resp["result"]["tensor_id"]

        resp = _send(paddle_worker, "store_tensor", {"tensor_id": result_tid})
        assert resp["ok"] is True
        result = read_array(ShmBuffer.from_dict(resp["result"]))
        unlink(resp["result"]["name"])
        np.testing.assert_array_equal(result, np.array([1.0, 2.0, 3.0], dtype=np.float32))


class TestWorkerFreeTensor:
    def test_free(self, paddle_worker):
        arr = np.array([1.0], dtype=np.float32)
        buf = write_array(arr)
        try:
            resp = _send(
                paddle_worker,
                "load_tensor",
                {
                    "shm_name": buf.name,
                    "shape": list(arr.shape),
                    "dtype": "float32",
                },
            )
            tid = resp["result"]["tensor_id"]
        finally:
            unlink(buf.name)
        resp = _send(paddle_worker, "free_tensor", {"tensor_id": tid})
        assert resp["ok"] is True

    def test_free_unknown_id(self, paddle_worker):
        resp = _send(paddle_worker, "free_tensor", {"tensor_id": "t9999"})
        assert resp["ok"] is False
