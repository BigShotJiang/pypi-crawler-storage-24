import pytest

from tensor_spec_worker.backend.base import BackendBase


def test_backend_base_is_abstract():
    with pytest.raises(TypeError):
        # Intentionally instantiate abstract class to verify TypeError is raised
        BackendBase()  # pyright: ignore[reportAbstractUsage]


def test_backend_base_has_compute_grad():
    assert hasattr(BackendBase, "compute_grad")


def test_backend_base_has_check_cuda_error():
    assert hasattr(BackendBase, "check_cuda_error")
