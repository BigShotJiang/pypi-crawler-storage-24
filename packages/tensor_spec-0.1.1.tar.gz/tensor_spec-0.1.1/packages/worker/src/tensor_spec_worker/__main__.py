"""Entry point for ``python -m tensor_spec_worker``."""

from tensor_spec_worker.process import main

main()
