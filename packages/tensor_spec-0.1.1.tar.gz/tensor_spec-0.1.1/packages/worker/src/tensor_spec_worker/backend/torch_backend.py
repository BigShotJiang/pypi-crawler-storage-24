"""TorchBackend: PyTorch framework backend implementation."""

from __future__ import annotations

import contextlib
from typing import Any

import numpy as np

from tensor_spec_core.tensor import TensorSpec
from tensor_spec_worker.backend.base import BackendBase


class TorchBackend(BackendBase):
    """Backend for PyTorch framework."""

    def __init__(self) -> None:
        self._torch: Any = None

    @property
    def name(self) -> str:
        return "torch"

    def import_framework(self) -> None:
        import torch

        self._torch = torch

    def numpy_to_tensor(self, np_array: np.ndarray, spec: TensorSpec) -> Any:
        torch = self._torch
        t = torch.tensor(np_array)
        if spec.state and spec.state.need_grad:
            t = t.requires_grad_(True)
        return t

    def tensor_to_numpy(self, tensor: Any) -> np.ndarray:
        return tensor.detach().cpu().numpy()

    def exec_api(self, api_name: str, args: tuple[Any, ...], kwargs: dict[str, Any]) -> Any:
        api_func = self._resolve_api(api_name)
        return api_func(*args, **kwargs)

    def compute_grad(self, output: Any, inputs: list[Any], grad_output: Any | None = None) -> list[Any]:
        torch = self._torch
        grads = torch.autograd.grad(output, inputs, grad_outputs=grad_output, allow_unused=True)
        return list(grads)

    def empty_cache(self) -> None:
        torch = self._torch
        if torch.cuda.is_available():
            torch.cuda.empty_cache()

    def check_cuda_error(self) -> None:
        torch = self._torch
        if torch.cuda.is_available():
            with contextlib.suppress(Exception):
                torch.cuda.synchronize()

    def _resolve_api(self, api_name: str) -> Any:
        """Resolve a dotted API name to a callable on the torch module."""
        obj = self._torch
        for part in api_name.split("."):
            obj = getattr(obj, part)
        return obj
