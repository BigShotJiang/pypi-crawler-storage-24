"""PaddleBackend: Paddle framework backend implementation."""

from __future__ import annotations

from typing import Any

import numpy as np

from tensor_spec_core.tensor import TensorSpec
from tensor_spec_worker.backend.base import BackendBase


class PaddleBackend(BackendBase):
    """Backend for PaddlePaddle framework."""

    def __init__(self) -> None:
        self._paddle: Any = None

    @property
    def name(self) -> str:
        return "paddle"

    def import_framework(self) -> None:
        import paddle

        self._paddle = paddle

    def numpy_to_tensor(self, np_array: np.ndarray, spec: TensorSpec) -> Any:
        paddle = self._paddle
        t = paddle.to_tensor(np_array)
        if spec.state and spec.state.need_grad:
            t.stop_gradient = False
        return t

    def tensor_to_numpy(self, tensor: Any) -> np.ndarray:
        return tensor.numpy(force=True)

    def exec_api(self, api_name: str, args: tuple[Any, ...], kwargs: dict[str, Any]) -> Any:
        api_func = self._resolve_api(api_name)
        return api_func(*args, **kwargs)

    def empty_cache(self) -> None:
        import contextlib

        paddle = self._paddle
        if hasattr(paddle, "device") and hasattr(paddle.device, "cuda"):
            with contextlib.suppress(Exception):
                paddle.device.cuda.empty_cache()

    def compute_grad(self, output: Any, inputs: list[Any], grad_output: Any | None = None) -> list[Any]:
        paddle = self._paddle
        return paddle.grad(output, inputs, grad_outputs=grad_output, allow_unused=True)

    def check_cuda_error(self) -> None:
        paddle = self._paddle
        if hasattr(paddle, "base") and hasattr(paddle.base, "core"):
            import contextlib

            with contextlib.suppress(Exception):
                paddle.base.core.eager._for_test_check_cuda_error()

    def _resolve_api(self, api_name: str) -> Any:
        """Resolve a dotted API name to a callable on the paddle module."""
        obj = self._paddle
        for part in api_name.split("."):
            obj = getattr(obj, part)
        return obj
