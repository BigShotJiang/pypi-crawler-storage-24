"""Lightweight worker subprocess for tensor-spec."""
