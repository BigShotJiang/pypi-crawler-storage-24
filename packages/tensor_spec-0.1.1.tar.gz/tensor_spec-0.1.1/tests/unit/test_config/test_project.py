"""Tests for ProjectConfig and related dataclasses."""

from __future__ import annotations

import pytest

from tensor_spec.config.project import DefaultsConfig, ProjectConfig, SourceConfig


class TestSourceConfig:
    def test_defaults(self) -> None:
        src = SourceConfig()
        assert src.index_url == ""
        assert src.extra_index_url == "https://pypi.org/simple/"
        assert src.package == ""
        assert src.version == ""
        assert src.whl == ""
        assert src.python_version == "3.12"
        assert src.cuda_version == "cu129"

    def test_frozen(self) -> None:
        src = SourceConfig()
        with pytest.raises(AttributeError):
            src.index_url = "x"  # type: ignore[misc]


class TestDefaultsConfig:
    def test_defaults(self) -> None:
        cfg = DefaultsConfig()
        assert cfg.backends == ()
        assert cfg.pythons == ()
        assert cfg.seed == 42
        assert cfg.verbose is False
        # Legacy fields
        assert cfg.backend_a == ""
        assert cfg.backend_b == ""
        assert cfg.python_a == ""
        assert cfg.python_b == ""

    def test_frozen(self) -> None:
        cfg = DefaultsConfig()
        with pytest.raises(AttributeError):
            cfg.seed = 99  # type: ignore[misc]


class TestProjectConfig:
    def test_from_toml(self, tmp_path) -> None:
        toml_content = """\
[sources.paddle]
index_url = "https://example.com/paddle/"
package = "paddlepaddle-gpu"

[sources.torch]
whl = "/tmp/torch.whl"

[defaults]
backend_a = "paddle"
backend_b = "torch"
seed = 123
verbose = true

[tolerance.default]
atol = 0.1
rtol = 0.2

[tolerance.overrides.matmul]
atol = 2.0
rtol = 0.05
"""
        f = tmp_path / "tensor-spec.toml"
        f.write_text(toml_content)

        config = ProjectConfig.from_toml(f)
        assert "paddle" in config.sources
        assert config.sources["paddle"].index_url == "https://example.com/paddle/"
        assert config.sources["paddle"].package == "paddlepaddle-gpu"
        assert config.sources["torch"].whl == "/tmp/torch.whl"
        assert config.defaults.backend_a == "paddle"
        assert config.defaults.seed == 123
        assert config.defaults.verbose is True
        assert config.tolerance_data["default"]["atol"] == pytest.approx(0.1)
        assert config.tolerance_data["overrides"]["matmul"]["atol"] == pytest.approx(2.0)

    def test_find_and_load_found(self, tmp_path) -> None:
        toml_content = """\
[defaults]
seed = 77
"""
        (tmp_path / "tensor-spec.toml").write_text(toml_content)
        sub = tmp_path / "a" / "b"
        sub.mkdir(parents=True)

        config = ProjectConfig.find_and_load(start_dir=sub)
        assert config is not None
        assert config.defaults.seed == 77

    def test_find_and_load_not_found(self, tmp_path) -> None:
        sub = tmp_path / "empty"
        sub.mkdir()
        config = ProjectConfig.find_and_load(start_dir=sub)
        assert config is None

    def test_get_source_builtin_defaults(self) -> None:
        config = ProjectConfig()
        paddle_src = config.get_source("paddle")
        assert "paddlepaddle" in paddle_src.index_url or "paddlepaddle" in paddle_src.package
        assert paddle_src.package == "paddlepaddle-gpu"

    def test_get_source_user_overrides_builtin(self) -> None:
        config = ProjectConfig(
            sources={"paddle": SourceConfig(index_url="https://custom.example.com/", package="my-paddle")}
        )
        paddle_src = config.get_source("paddle")
        assert paddle_src.index_url == "https://custom.example.com/"
        assert paddle_src.package == "my-paddle"

    def test_resolve_index_url_interpolation(self) -> None:
        config = ProjectConfig(sources={"paddle": SourceConfig(cuda_version="cu118")})
        url = config.resolve_index_url("paddle")
        assert "cu118" in url

    def test_frozen(self) -> None:
        config = ProjectConfig()
        with pytest.raises(AttributeError):
            config.defaults = DefaultsConfig()  # type: ignore[misc]
