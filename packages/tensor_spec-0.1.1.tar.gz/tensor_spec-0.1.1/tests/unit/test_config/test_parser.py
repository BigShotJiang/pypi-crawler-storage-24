import pytest

from tensor_spec.config.parser import parse_case
from tensor_spec_core.tensor import FloatTensorSpec, IntTensorSpec


class TestParseSimple:
    def test_abs(self):
        case = parse_case("abs(x=Tensor.float64((1, 100)))")
        assert case.api_name == "abs"
        assert "x" in case.kwargs
        spec = case.kwargs["x"]
        assert isinstance(spec, FloatTensorSpec)
        assert spec.dtype == "float64"
        assert spec.shape == (1, 100)

    def test_add(self):
        case = parse_case("add(x=Tensor.float32((2, 3)), y=Tensor.float32((2, 3)))")
        assert case.api_name == "add"
        assert len(case.kwargs) == 2
        assert case.kwargs["x"].shape == (2, 3)
        assert case.kwargs["y"].shape == (2, 3)


class TestParseNamespaced:
    def test_linalg_cholesky(self):
        case = parse_case("linalg.cholesky(x=Tensor.float64((4, 4)).stats(positive_definite=True))")
        assert case.api_name == "linalg.cholesky"
        spec = case.kwargs["x"]
        assert isinstance(spec, FloatTensorSpec)
        assert spec.stats is not None
        assert spec.stats.positive_definite is True

    def test_nn_conv2d(self):
        case = parse_case(
            "nn.conv2d(x=Tensor.float32((1, 3, 224, 224)).state(need_grad=True), "
            "weight=Tensor.float32((64, 3, 7, 7)), stride=2, padding=3)"
        )
        assert case.api_name == "nn.conv2d"
        assert case.kwargs["stride"] == 2
        assert case.kwargs["padding"] == 3
        spec_x = case.kwargs["x"]
        assert spec_x.state is not None
        assert spec_x.state.need_grad is True


class TestParseScalars:
    def test_int_kwarg(self):
        case = parse_case("cumsum(x=Tensor.float32((3, 4, 5)), axis=1)")
        assert case.kwargs["axis"] == 1

    def test_float_kwarg(self):
        case = parse_case("clip(x=Tensor.float32((3,)), min=-1.5, max=2.5)")
        assert case.kwargs["min"] == -1.5
        assert case.kwargs["max"] == 2.5

    def test_negative_int(self):
        case = parse_case("roll(x=Tensor.float32((4, 5)), shifts=-1, axis=0)")
        assert case.kwargs["shifts"] == -1

    def test_bool_kwarg(self):
        case = parse_case("sum(x=Tensor.float32((3, 4)), keepdim=True)")
        assert case.kwargs["keepdim"] is True

    def test_none_kwarg(self):
        case = parse_case("sum(x=Tensor.float32((3, 4)), axis=None)")
        assert case.kwargs["axis"] is None

    def test_string_kwarg(self):
        case = parse_case('pad(x=Tensor.float32((1, 3, 4)), pad=[1, 1], mode="constant")')
        assert case.kwargs["mode"] == "constant"


class TestParseContainers:
    def test_list_kwarg(self):
        case = parse_case("pad(x=Tensor.float32((1, 3, 4)), pad=[1, 2, 3, 4])")
        assert case.kwargs["pad"] == [1, 2, 3, 4]

    def test_tuple_kwarg(self):
        case = parse_case("reshape(x=Tensor.float32((6,)), shape=(2, 3))")
        assert case.kwargs["shape"] == (2, 3)


class TestParseTuplePositional:
    def test_concat_tuple_of_tensors(self):
        case = parse_case("concat(tuple(Tensor.float32((31376, 768)), Tensor.float32((1, 768))), axis=0)")
        assert case.api_name == "concat"
        assert isinstance(case.args[0], tuple)
        assert len(case.args[0]) == 2
        assert case.args[0][0].shape == (31376, 768)


class TestParseStats:
    def test_float_stats(self):
        case = parse_case("abs(x=Tensor.float32((4, 4)).stats(min=-10.0, max=10.0))")
        spec = case.kwargs["x"]
        assert spec.stats.min == -10.0
        assert spec.stats.max == 10.0

    def test_int_stats(self):
        case = parse_case("scatter(index=Tensor.int64((5, 3)).stats(low=0, high=3))")
        spec = case.kwargs["index"]
        assert isinstance(spec, IntTensorSpec)
        assert spec.stats is not None
        assert spec.stats.low == 0
        assert spec.stats.high == 3


class TestParseErrors:
    def test_empty_string(self):
        with pytest.raises(ValueError):
            parse_case("")

    def test_missing_parens(self):
        with pytest.raises(ValueError):
            parse_case("abs")

    def test_unknown_constructor(self):
        with pytest.raises(ValueError, match="Unknown"):
            parse_case("abs(x=Foo.bar((2,)))")
