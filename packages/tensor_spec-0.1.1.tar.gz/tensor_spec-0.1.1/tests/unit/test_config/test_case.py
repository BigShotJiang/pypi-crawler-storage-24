import pytest

from tensor_spec.config.case import CaseConfig
from tensor_spec_core.tensor import Tensor


def test_case_config_basic():
    spec = Tensor.float64((1, 100))
    case = CaseConfig(
        api_name="abs",
        args=(),
        kwargs={"x": spec},
    )
    assert case.api_name == "abs"
    assert case.kwargs["x"] is spec


def test_case_config_frozen():
    case = CaseConfig(api_name="abs", args=(), kwargs={})
    with pytest.raises(AttributeError):
        setattr(case, "api_name", "add")


def test_case_config_with_scalar_kwargs():
    case = CaseConfig(
        api_name="nn.conv2d",
        args=(),
        kwargs={
            "x": Tensor.float32((1, 3, 224, 224)),
            "weight": Tensor.float32((64, 3, 7, 7)),
            "stride": 2,
            "padding": 3,
        },
    )
    assert case.kwargs["stride"] == 2


def test_case_config_tensor_specs():
    case = CaseConfig(
        api_name="add",
        args=(),
        kwargs={
            "x": Tensor.float32((2, 3)),
            "y": Tensor.float32((2, 3)),
        },
    )
    specs = case.tensor_specs
    assert len(specs) == 2
    assert "x" in specs
    assert "y" in specs
