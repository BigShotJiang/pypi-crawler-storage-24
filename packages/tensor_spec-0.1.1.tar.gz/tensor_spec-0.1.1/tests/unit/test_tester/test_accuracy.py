"""Tests for tester.accuracy module."""

from __future__ import annotations

from unittest.mock import MagicMock, PropertyMock

import numpy as np

from tensor_spec.compare.comparator import NumpyComparator
from tensor_spec.compare.tolerance import Tolerance, ToleranceConfig
from tensor_spec.config.case import CaseConfig
from tensor_spec.datagen.generator import TensorGenerator
from tensor_spec.mapping.registry import APIMapping, MappingRegistry
from tensor_spec.tester.accuracy import AccuracyTester, BackendError
from tensor_spec.tester.base import TestStatus
from tensor_spec_core.tensor import Tensor


def _make_mock_backend(name: str) -> MagicMock:
    """Create a mock backend with standard passthrough behaviour."""
    backend = MagicMock()
    type(backend).name = PropertyMock(return_value=name)
    backend.numpy_to_tensor.side_effect = lambda arr, spec: arr
    backend.tensor_to_numpy.side_effect = lambda t: t
    backend.exec_api.side_effect = lambda api, args, kwargs: kwargs.get(
        "x", kwargs.get("input", args[0] if args else None)
    )
    backend.empty_cache.return_value = None
    backend.check_cuda_error.return_value = None
    return backend


def _make_mapping() -> MappingRegistry:
    """Build a MappingRegistry with 'abs' mapped for paddle and torch."""
    registry = MappingRegistry()
    # Manually inject mappings
    registry._mappings["paddle"] = {
        "abs": APIMapping(api="paddle.abs", args_map={"x": "x"}),
    }
    registry._mappings["torch"] = {
        "abs": APIMapping(api="torch.abs", args_map={"x": "input"}),
    }
    return registry


def _make_tester(
    backend_a: MagicMock | None = None,
    backend_b: MagicMock | None = None,
) -> AccuracyTester:
    """Build an AccuracyTester with mock backends."""
    ba = backend_a or _make_mock_backend("paddle")
    bb = backend_b or _make_mock_backend("torch")
    return AccuracyTester(
        backend_a=ba,
        backend_b=bb,
        mapping=_make_mapping(),
        comparator=NumpyComparator(),
        tolerance=Tolerance(default=ToleranceConfig(atol=1e-5, rtol=1e-5)),
        generator=TensorGenerator(seed=42),
    )


class TestAccuracyTesterPass:
    """Both backends return the same values -- expect PASSED."""

    def test_accuracy_tester_pass(self) -> None:
        tester = _make_tester()
        spec = Tensor.float32((2, 3))
        case = CaseConfig(api_name="abs", args=(), kwargs={"x": spec})
        result = tester.test(case)
        assert result.status == TestStatus.PASSED
        assert result.compare_result is not None
        assert result.compare_result.passed is True
        assert result.duration_ms > 0


class TestAccuracyTesterMismatch:
    """Backend B returns different values -- expect ACCURACY_ERROR."""

    def test_accuracy_tester_mismatch(self) -> None:
        ba = _make_mock_backend("paddle")
        bb = _make_mock_backend("torch")
        # Override backend_b exec_api to return a very different array
        bb.exec_api.side_effect = lambda api, args, kwargs: np.ones((2, 3), dtype=np.float32) * 1e6
        tester = _make_tester(backend_a=ba, backend_b=bb)
        spec = Tensor.float32((2, 3))
        case = CaseConfig(api_name="abs", args=(), kwargs={"x": spec})
        result = tester.test(case)
        assert result.status == TestStatus.ACCURACY_ERROR
        assert result.compare_result is not None
        assert result.compare_result.passed is False
        assert result.duration_ms > 0


class TestAccuracyTesterBackendError:
    """Backend raises RuntimeError -- expect BACKEND_ERROR."""

    def test_accuracy_tester_backend_error(self) -> None:
        ba = _make_mock_backend("paddle")
        bb = _make_mock_backend("torch")
        bb.exec_api.side_effect = RuntimeError("CUDA error: device-side assert")
        tester = _make_tester(backend_a=ba, backend_b=bb)
        spec = Tensor.float32((2, 3))
        case = CaseConfig(api_name="abs", args=(), kwargs={"x": spec})
        result = tester.test(case)
        assert result.status == TestStatus.BACKEND_ERROR
        assert result.error is not None
        assert "CUDA error" in result.error
        assert result.duration_ms > 0

    def test_accuracy_tester_paddle_error(self) -> None:
        ba = _make_mock_backend("paddle")
        ba.exec_api.side_effect = RuntimeError("PaddlePaddle error")
        bb = _make_mock_backend("torch")
        tester = _make_tester(backend_a=ba, backend_b=bb)
        spec = Tensor.float32((2, 3))
        case = CaseConfig(api_name="abs", args=(), kwargs={"x": spec})
        result = tester.test(case)
        assert result.status == TestStatus.BACKEND_ERROR
        assert result.error is not None
        assert "PaddlePaddle" in result.error


class TestBackendError:
    """Tests for BackendError exception."""

    def test_backend_error_attributes(self) -> None:
        original = RuntimeError("boom")
        err = BackendError("torch", original)
        assert err.backend_name == "torch"
        assert err.original is original
        assert "torch error: boom" in str(err)
