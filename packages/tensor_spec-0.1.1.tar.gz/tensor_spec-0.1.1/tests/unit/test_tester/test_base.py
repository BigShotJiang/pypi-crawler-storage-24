"""Tests for tester.base module."""

from __future__ import annotations

import numpy as np

from tensor_spec.compare.comparator import CompareResult
from tensor_spec.config.case import CaseConfig
from tensor_spec.tester.base import (
    GeneratedInputs,
    TestResult,
    TestStatus,
)


class TestTestStatus:
    """Tests for TestStatus enum."""

    def test_test_status_values(self) -> None:
        assert TestStatus.PASSED.value == "pass"
        assert TestStatus.ACCURACY_ERROR.value == "accuracy_error"
        assert TestStatus.BACKEND_ERROR.value == "backend_error"
        assert TestStatus.CUDA_ERROR.value == "cuda_error"
        assert TestStatus.OOM_ERROR.value == "oom"
        assert TestStatus.ERROR.value == "error"

    def test_test_status_count(self) -> None:
        assert len(TestStatus) == 6


class TestTestResult:
    """Tests for TestResult dataclass."""

    def test_test_result_creation(self) -> None:
        case = CaseConfig(api_name="abs", args=(), kwargs={})
        result = TestResult(case=case, status=TestStatus.PASSED)
        assert result.case is case
        assert result.status == TestStatus.PASSED
        assert result.compare_result is None
        assert result.error is None
        assert result.duration_ms == 0.0

    def test_test_result_with_error(self) -> None:
        case = CaseConfig(api_name="abs", args=(), kwargs={})
        result = TestResult(
            case=case,
            status=TestStatus.ERROR,
            error="something went wrong",
            duration_ms=42.5,
        )
        assert result.status == TestStatus.ERROR
        assert result.error == "something went wrong"
        assert result.duration_ms == 42.5

    def test_test_result_with_compare_result(self) -> None:
        case = CaseConfig(api_name="abs", args=(), kwargs={})
        cmp = CompareResult(
            passed=True,
            max_abs_diff=0.001,
            max_rel_diff=0.0001,
            mismatched_count=0,
            total_count=100,
        )
        result = TestResult(
            case=case,
            status=TestStatus.PASSED,
            compare_result=cmp,
        )
        assert result.compare_result is not None
        assert result.compare_result.passed is True

    def test_test_result_is_mutable(self) -> None:
        """TestResult must be mutable so duration_ms can be set after creation."""
        case = CaseConfig(api_name="abs", args=(), kwargs={})
        result = TestResult(case=case, status=TestStatus.PASSED)
        result.duration_ms = 123.4
        assert result.duration_ms == 123.4


class TestGeneratedInputs:
    """Tests for GeneratedInputs dataclass."""

    def test_defaults(self) -> None:
        gi = GeneratedInputs()
        assert gi.arg_arrays == []
        assert gi.kwarg_arrays == {}

    def test_with_data(self) -> None:
        arr = np.ones((2, 3), dtype=np.float32)
        gi = GeneratedInputs(
            arg_arrays=[arr, None],
            kwarg_arrays={"x": arr},
        )
        assert len(gi.arg_arrays) == 2
        assert gi.arg_arrays[0] is arr
        assert gi.arg_arrays[1] is None
        assert "x" in gi.kwarg_arrays
