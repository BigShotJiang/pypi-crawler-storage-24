"""Coordinator: manages worker subprocesses and SharedMemory transport."""

from __future__ import annotations

import contextlib
import json
import subprocess
from concurrent.futures import ThreadPoolExecutor
from typing import Any

import numpy as np
from loguru import logger

from tensor_spec_worker.ipc.shared_memory import ShmBuffer, read_array, unlink, write_array
from tensor_spec_worker.protocol import encode_arg_value


class WorkerHandle:
    """Manages communication with a single worker subprocess."""

    def __init__(self, python_path: str, backend: str) -> None:
        self.backend = backend
        self.process = subprocess.Popen(
            [python_path, "-m", "tensor_spec_worker", "--backend", backend],
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            text=True,
        )
        self._next_msg_id = 0

    def send(self, msg_type: str, payload: dict[str, Any] | None = None) -> dict:
        """Send a request and wait for the response."""
        self._next_msg_id += 1
        msg: dict[str, Any] = {"id": self._next_msg_id, "type": msg_type}
        if payload:
            msg["payload"] = payload
        assert self.process.stdin is not None
        assert self.process.stdout is not None
        self.process.stdin.write(json.dumps(msg) + "\n")
        self.process.stdin.flush()
        line = self.process.stdout.readline()
        if not line:
            raise RuntimeError("Worker process exited unexpectedly")
        return json.loads(line)

    def shutdown(self) -> None:
        """Send shutdown command and wait for process to exit."""
        with contextlib.suppress(BrokenPipeError, RuntimeError):
            self.send("shutdown")
        self.process.wait(timeout=10)


class Coordinator:
    """Manages multiple worker subprocesses, routes commands, handles SharedMemory."""

    def __init__(self) -> None:
        self.workers: dict[str, WorkerHandle] = {}
        self._shm_to_unlink: list[str] = []

    def start_worker(self, name: str, python_path: str, backend: str) -> None:
        """Start a named worker subprocess (blocking: ping + import_framework)."""
        handle = WorkerHandle(python_path, backend)
        resp = handle.send("ping")
        if not resp.get("ok"):
            raise RuntimeError(f"Worker {name} failed ping: {resp}")
        self.workers[name] = handle

    def start_workers_parallel(
        self,
        configs: list[tuple[str, str, str]],
    ) -> None:
        """Start multiple workers in parallel, each doing spawn + ping + import.

        Args:
            configs: List of (name, python_path, backend) tuples.
        """
        names = [c[2] for c in configs]
        logger.info("Starting workers: {} ...", ", ".join(names))

        def _boot(name: str, python_path: str, backend: str) -> tuple[str, WorkerHandle]:
            logger.debug("Spawning worker {} ({})", name, backend)
            handle = WorkerHandle(python_path, backend)
            resp = handle.send("ping")
            if not resp.get("ok"):
                raise RuntimeError(f"Worker {name} failed ping: {resp}")
            logger.debug("Worker {} alive, importing {} ...", name, backend)
            resp = handle.send("import_framework")
            if not resp.get("ok"):
                raise RuntimeError(f"Worker {name} import_framework failed: {resp.get('error')}")
            logger.info("Worker {} ({}) ready", name, backend)
            return name, handle

        with ThreadPoolExecutor(max_workers=len(configs)) as pool:
            futures = [pool.submit(_boot, name, python_path, backend) for name, python_path, backend in configs]
            for fut in futures:
                name, handle = fut.result()
                self.workers[name] = handle

    def import_framework(self, worker_name: str) -> None:
        """Tell a worker to import its framework."""
        resp = self.workers[worker_name].send("import_framework")
        if not resp.get("ok"):
            raise RuntimeError(f"import_framework failed: {resp.get('error')}")

    def send_numpy(self, worker_name: str, arr: np.ndarray) -> str:
        """Send a numpy array to a worker via SharedMemory. Returns tensor_id."""
        buf = write_array(arr)
        self._shm_to_unlink.append(buf.name)
        resp = self.workers[worker_name].send(
            "load_tensor",
            {
                "shm_name": buf.name,
                "shape": list(arr.shape),
                "dtype": str(arr.dtype),
            },
        )
        if not resp.get("ok"):
            raise RuntimeError(f"load_tensor failed: {resp.get('error')}")
        return resp["result"]["tensor_id"]

    def get_numpy(self, worker_name: str, tensor_id: str) -> np.ndarray:
        """Get a numpy array from a worker via SharedMemory."""
        resp = self.workers[worker_name].send(
            "store_tensor",
            {
                "tensor_id": tensor_id,
            },
        )
        if not resp.get("ok"):
            raise RuntimeError(f"store_tensor failed: {resp.get('error')}")
        buf = ShmBuffer.from_dict(resp["result"])
        arr = read_array(buf)
        unlink(buf.name)
        return arr

    def exec_api(
        self,
        worker_name: str,
        api_name: str,
        args: list[str | Any],
        kwargs: dict[str, str | Any],
    ) -> str:
        """Execute an API on a worker. Tensor IDs (strings starting with 't') are
        wrapped as _ref dicts. Returns the result tensor_id.
        """
        encoded_args = [{"_ref": v} if isinstance(v, str) and v.startswith("t") else encode_arg_value(v) for v in args]
        encoded_kwargs = {
            k: {"_ref": v} if isinstance(v, str) and v.startswith("t") else encode_arg_value(v)
            for k, v in kwargs.items()
        }
        resp = self.workers[worker_name].send(
            "exec_api",
            {
                "api": api_name,
                "args": encoded_args,
                "kwargs": encoded_kwargs,
            },
        )
        if not resp.get("ok"):
            raise RuntimeError(f"exec_api failed: {resp.get('error')}")
        return resp["result"]["tensor_id"]

    def free_tensor(self, worker_name: str, tensor_id: str) -> None:
        """Release a tensor in a worker."""
        self.workers[worker_name].send("free_tensor", {"tensor_id": tensor_id})

    def empty_cache(self, worker_name: str) -> None:
        """Clear GPU cache on a worker."""
        self.workers[worker_name].send("empty_cache")

    def check_cuda_error(self, worker_name: str) -> None:
        """Check for CUDA errors on a worker."""
        self.workers[worker_name].send("check_cuda_error")

    def get_ipc_handle(self, worker_name: str, tensor_id: str) -> dict:
        """Get CUDA IPC handle from a worker's GPU tensor.

        Returns dict with keys: handle (base64), shape, dtype.
        """
        resp = self.workers[worker_name].send("get_ipc_handle", {"tensor_id": tensor_id})
        if not resp.get("ok"):
            raise RuntimeError(f"get_ipc_handle failed: {resp.get('error')}")
        return resp["result"]

    def open_ipc_handle(self, worker_name: str, handle_info: dict) -> str:
        """Open a CUDA IPC handle on a worker, returns tensor_id."""
        resp = self.workers[worker_name].send("open_ipc_handle", handle_info)
        if not resp.get("ok"):
            raise RuntimeError(f"open_ipc_handle failed: {resp.get('error')}")
        return resp["result"]["tensor_id"]

    def close_ipc_handle(self, worker_name: str, tensor_id: str) -> None:
        """Close an IPC handle on a worker."""
        self.workers[worker_name].send("close_ipc_handle", {"tensor_id": tensor_id})

    def shutdown_all(self) -> None:
        """Shutdown all workers and clean up SharedMemory."""
        logger.debug("Shutting down {} worker(s)", len(self.workers))
        for handle in self.workers.values():
            handle.shutdown()
        for name in self._shm_to_unlink:
            with contextlib.suppress(FileNotFoundError):
                unlink(name)
        self._shm_to_unlink.clear()
        logger.debug("All workers stopped")
