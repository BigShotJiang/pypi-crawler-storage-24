"""API mapping registry: canonical name -> framework-specific API + arg names."""

from __future__ import annotations

import json
import tomllib
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any


def _load_toml(path: str | Path) -> dict[str, Any]:
    """Load a TOML file."""
    with open(path, "rb") as f:
        return tomllib.load(f)


@dataclass(frozen=True, slots=True)
class APIMapping:
    """Mapping for a single API: framework-specific path + arg name map."""

    api: str
    args_map: dict[str, str] = field(default_factory=dict)


@dataclass(frozen=True, slots=True)
class ArgRule:
    """A single arg-rename rule: rename `from_` to `to` for matching APIs."""

    from_: str
    to: str
    apis: frozenset[str] | None = None  # None means all APIs


@dataclass(frozen=True, slots=True)
class ApiPrefixRule:
    """Add a path prefix to listed APIs."""

    prefix: str
    apis: frozenset[str]


@dataclass(frozen=True, slots=True)
class MappingRules:
    """Parsed rule set from a .rules.toml file."""

    api_rename: dict[str, str]
    api_prefix_rules: tuple[ApiPrefixRule, ...]
    arg_rules: tuple[ArgRule, ...]

    def resolve_api(self, canonical: str) -> str:
        """Resolve canonical API name to framework-specific path."""
        if canonical in self.api_rename:
            return self.api_rename[canonical]
        for rule in self.api_prefix_rules:
            if canonical in rule.apis:
                return rule.prefix + canonical
        return canonical

    def resolve_arg(self, canonical_api: str, arg_name: str) -> str:
        """Resolve a single arg name for the given canonical API (first-match-wins)."""
        for rule in self.arg_rules:
            if rule.from_ != arg_name:
                continue
            if rule.apis is None or canonical_api in rule.apis:
                return rule.to
        return arg_name

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> MappingRules:
        api_rename = dict(data.get("api_rename", {}))
        api_prefix_rules = tuple(
            ApiPrefixRule(prefix=r["prefix"], apis=frozenset(r["apis"])) for r in data.get("api_rules", [])
        )
        arg_rules = tuple(
            ArgRule(
                from_=r["from"],
                to=r["to"],
                apis=frozenset(r["apis"]) if "apis" in r else None,
            )
            for r in data.get("arg_rules", [])
        )
        return cls(
            api_rename=api_rename,
            api_prefix_rules=api_prefix_rules,
            arg_rules=arg_rules,
        )


class MappingRegistry:
    """Registry of API mappings per framework."""

    def __init__(self) -> None:
        self._mappings: dict[str, dict[str, APIMapping]] = {}
        self._rules: dict[str, MappingRules] = {}

    def load(self, framework: str, path: str) -> None:
        """Load API mappings from a JSON file for the given framework."""
        with open(path) as f:
            data = json.load(f)
        self._mappings[framework] = {
            canonical: APIMapping(api=entry["api"], args_map=entry.get("args_map", {}))
            for canonical, entry in data.items()
        }

    def load_rules(self, framework: str, path: str, api_names: list[str]) -> None:
        """Load mapping rules from a TOML file and expand into per-API mappings.

        Args:
            framework: Framework name (e.g. "paddle", "torch").
            path: Path to the .rules.toml file.
            api_names: List of canonical API names to generate mappings for.
        """
        data = _load_toml(path)
        rules = MappingRules.from_dict(data)
        self._rules[framework] = rules
        self._mappings[framework] = {}
        for canonical in api_names:
            api = rules.resolve_api(canonical)
            self._mappings[framework][canonical] = APIMapping(api=api)

    def load_bundled(self, framework: str) -> None:
        """Load the bundled mapping file shipped with the package.

        Prefers .rules.toml if it exists, otherwise falls back to .json.
        """
        mappings_dir = Path(__file__).parent / "mappings"
        rules_path = mappings_dir / f"{framework}.rules.toml"
        json_path = mappings_dir / f"{framework}.json"
        if rules_path.exists():
            api_names = _load_canonical_api_names(mappings_dir)
            self.load_rules(framework, str(rules_path), api_names)
        elif json_path.exists():
            self.load(framework, str(json_path))
        else:
            raise FileNotFoundError(f"No mapping file found for '{framework}' in {mappings_dir}")

    def resolve(self, canonical_name: str, framework: str) -> APIMapping:
        """Return the full APIMapping for *canonical_name* in *framework*."""
        return self._mappings[framework][canonical_name]

    def resolve_api(self, canonical_name: str, framework: str) -> str:
        """Return just the framework-specific API path string."""
        return self._mappings[framework][canonical_name].api

    def map_kwargs(self, canonical_name: str, framework: str, kwargs: dict) -> dict:
        """Remap canonical keyword-argument names to framework-specific names."""
        rules = self._rules.get(framework)
        if rules is not None:
            return {rules.resolve_arg(canonical_name, k): v for k, v in kwargs.items()}
        mapping = self._mappings[framework][canonical_name]
        return {mapping.args_map.get(k, k): v for k, v in kwargs.items()}


def _load_canonical_api_names(mappings_dir: Path) -> list[str]:
    """Read canonical API names from apis.toml."""
    data = _load_toml(mappings_dir / "apis.toml")
    return list(data["apis"])
