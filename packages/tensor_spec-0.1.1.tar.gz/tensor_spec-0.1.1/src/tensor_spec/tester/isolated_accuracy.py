"""IsolatedAccuracyTester: process-isolated multi-backend accuracy comparison."""

from __future__ import annotations

import time
from typing import Any

import numpy as np
from loguru import logger

from tensor_spec.compare.comparator import NumpyComparator
from tensor_spec.compare.tolerance import Tolerance
from tensor_spec.config.case import CaseConfig
from tensor_spec.datagen.generator import TensorGenerator
from tensor_spec.mapping.registry import MappingRegistry
from tensor_spec.tester.base import GeneratedInputs, TesterBase, TestResult, TestStatus
from tensor_spec.worker.coordinator import Coordinator
from tensor_spec_core.tensor import TensorSpec


class IsolatedAccuracyTester(TesterBase):
    """Runs accuracy comparison across N backends in separate subprocesses.

    The first backend is the reference; all others are compared against it.
    """

    def __init__(
        self,
        backends: list[tuple[str, str, str]],
        mapping: MappingRegistry,
        comparator: NumpyComparator,
        tolerance: Tolerance,
        generator: TensorGenerator,
    ) -> None:
        """Initialize with a list of (worker_name, python_path, backend_name) tuples."""
        super().__init__(generator)
        if len(backends) < 2:
            raise ValueError("IsolatedAccuracyTester requires at least 2 backends")
        self._backends = backends  # [(worker_name, python_path, backend_name), ...]
        self._mapping = mapping
        self._comparator = comparator
        self._tolerance = tolerance
        self._coordinator = Coordinator()
        self._coordinator.start_workers_parallel(
            [(name, python_path, backend_name) for name, python_path, backend_name in backends]
        )

    def shutdown(self) -> None:
        """Shutdown worker processes."""
        self._coordinator.shutdown_all()

    def test(self, case: CaseConfig) -> TestResult:
        """Override template to handle subprocess errors."""
        logger.info("Testing {} ...", case.api_name)
        start = time.perf_counter()
        try:
            inputs = self._generate_inputs(case)
            outputs = self.execute(case, inputs)
            result = self.compare(case, outputs)
            result.duration_ms = (time.perf_counter() - start) * 1000
            logger.info(
                "{} -> {} ({:.0f}ms)",
                case.api_name,
                result.status.value,
                result.duration_ms,
            )
            return result
        except _WorkerBackendError as e:
            dur = (time.perf_counter() - start) * 1000
            logger.warning("{} -> backend_error : {}", case.api_name, e.message)
            return TestResult(
                case=case,
                status=TestStatus.BACKEND_ERROR,
                error=f"[{e.backend_name}] {e.message}",
                duration_ms=dur,
            )
        except MemoryError as e:
            dur = (time.perf_counter() - start) * 1000
            logger.error("{} -> OOM: {}", case.api_name, e)
            return TestResult(
                case=case,
                status=TestStatus.OOM_ERROR,
                error=str(e),
                duration_ms=dur,
            )
        except Exception as e:
            dur = (time.perf_counter() - start) * 1000
            logger.error("{} -> error: {}", case.api_name, e)
            return TestResult(
                case=case,
                status=TestStatus.ERROR,
                error=str(e),
                duration_ms=dur,
            )

    def execute(self, case: CaseConfig, inputs: GeneratedInputs) -> dict[str, Any]:
        """Execute API on all workers and return numpy outputs keyed by worker name."""
        results: dict[str, Any] = {}
        for worker_name, _python_path, backend_name in self._backends:
            np_out = self._execute_on_worker(worker_name, backend_name, case, inputs)
            self._coordinator.empty_cache(worker_name)
            results[worker_name] = np_out
        return results

    def compare(self, case: CaseConfig, outputs: dict[str, Any]) -> TestResult:
        """Compare all worker outputs against the first (reference) worker."""
        tol = self._tolerance.get(case.api_name)
        ref_name = self._backends[0][0]
        ref_numpy = outputs[ref_name]

        for worker_name, _python_path, backend_name in self._backends[1:]:
            cmp_result = self._comparator.compare(ref_numpy, outputs[worker_name], tol)
            if not cmp_result.passed:
                return TestResult(
                    case=case,
                    status=TestStatus.ACCURACY_ERROR,
                    compare_result=cmp_result,
                    error=f"Mismatch: {self._backends[0][2]} vs {backend_name}",
                )

        # All passed — return the last comparison result (or a simple PASSED for 2-backend case)
        cmp_result = self._comparator.compare(
            ref_numpy,
            outputs[self._backends[-1][0]],
            tol,
        )
        return TestResult(case=case, status=TestStatus.PASSED, compare_result=cmp_result)

    def _execute_on_worker(
        self,
        worker_name: str,
        backend_name: str,
        case: CaseConfig,
        inputs: GeneratedInputs,
    ) -> np.ndarray:
        """Send data to a worker, execute API, retrieve numpy result."""
        coord = self._coordinator
        mapping = self._mapping.resolve(case.api_name, backend_name)

        # Send tensor args
        arg_refs: list[Any] = []
        for i, val in enumerate(case.args):
            if isinstance(val, TensorSpec) and (arr := inputs.arg_arrays[i]) is not None:
                tid = coord.send_numpy(worker_name, arr)
                arg_refs.append(tid)
            elif isinstance(val, tuple):
                items = []
                for v in val:
                    if isinstance(v, TensorSpec):
                        np_data = self._generator.generate(v)
                        items.append(coord.send_numpy(worker_name, np_data))
                    else:
                        items.append(v)
                arg_refs.append(tuple(items))
            else:
                arg_refs.append(val)

        # Send tensor kwargs (with name remapping)
        kwarg_refs: dict[str, Any] = {}
        for key, val in case.kwargs.items():
            mapped_key = mapping.args_map.get(key, key)
            if isinstance(val, TensorSpec) and key in inputs.kwarg_arrays:
                tid = coord.send_numpy(worker_name, inputs.kwarg_arrays[key])
                kwarg_refs[mapped_key] = tid
            else:
                kwarg_refs[mapped_key] = val

        # Execute
        try:
            result_tid = coord.exec_api(
                worker_name,
                mapping.api,
                list(arg_refs),
                kwarg_refs,
            )
        except RuntimeError as e:
            raise _WorkerBackendError(backend_name, str(e)) from e

        # Get result numpy
        coord.check_cuda_error(worker_name)
        return coord.get_numpy(worker_name, result_tid)


class _WorkerBackendError(Exception):
    """Internal: raised when a worker's exec_api fails."""

    def __init__(self, backend_name: str, message: str) -> None:
        self.backend_name = backend_name
        self.message = message
        super().__init__(f"{backend_name}: {message}")
