"""Tester base class with template method pattern."""

from __future__ import annotations

import time
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from enum import Enum
from typing import Any

import numpy as np

from tensor_spec.compare.comparator import CompareResult
from tensor_spec.config.case import CaseConfig
from tensor_spec.datagen.generator import TensorGenerator
from tensor_spec_core.tensor import TensorSpec


class TestStatus(Enum):
    """Outcome status for a single test case."""

    PASSED = "pass"
    ACCURACY_ERROR = "accuracy_error"
    BACKEND_ERROR = "backend_error"
    CUDA_ERROR = "cuda_error"
    OOM_ERROR = "oom"
    ERROR = "error"


@dataclass
class TestResult:
    """Structured result for a single test case execution."""

    case: CaseConfig
    status: TestStatus
    compare_result: CompareResult | None = None
    error: str | None = None
    duration_ms: float = 0.0


@dataclass
class GeneratedInputs:
    """Holds generated numpy arrays for args and kwargs."""

    arg_arrays: list[np.ndarray | None] = field(default_factory=list)
    kwarg_arrays: dict[str, np.ndarray] = field(default_factory=dict)


class TesterBase(ABC):
    """Abstract base class implementing the template method pattern for test execution."""

    def __init__(self, generator: TensorGenerator) -> None:
        self._generator = generator

    def test(self, case: CaseConfig) -> TestResult:
        """Template method: generate inputs -> execute -> compare."""
        start = time.perf_counter()
        try:
            inputs = self._generate_inputs(case)
            outputs = self.execute(case, inputs)
            result = self.compare(case, outputs)
            result.duration_ms = (time.perf_counter() - start) * 1000
            return result
        except MemoryError as e:
            return TestResult(
                case=case,
                status=TestStatus.OOM_ERROR,
                error=str(e),
                duration_ms=(time.perf_counter() - start) * 1000,
            )
        except Exception as e:
            return TestResult(
                case=case,
                status=TestStatus.ERROR,
                error=str(e),
                duration_ms=(time.perf_counter() - start) * 1000,
            )

    def _generate_inputs(self, case: CaseConfig) -> GeneratedInputs:
        """Generate numpy arrays for all TensorSpec arguments."""
        arg_arrays = []
        for val in case.args:
            if isinstance(val, TensorSpec):
                arg_arrays.append(self._generator.generate(val))
            else:
                arg_arrays.append(None)
        kwarg_arrays = {}
        for key, val in case.kwargs.items():
            if isinstance(val, TensorSpec):
                kwarg_arrays[key] = self._generator.generate(val)
        return GeneratedInputs(arg_arrays=arg_arrays, kwarg_arrays=kwarg_arrays)

    @abstractmethod
    def execute(self, case: CaseConfig, inputs: GeneratedInputs) -> dict[str, Any]:
        """Execute the API under test. Must be implemented by subclasses."""
        ...

    @abstractmethod
    def compare(self, case: CaseConfig, outputs: dict[str, Any]) -> TestResult:
        """Compare outputs and return a TestResult. Must be implemented by subclasses."""
        ...
