"""Project-level configuration: sources, defaults, and tolerance."""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

# Built-in default sources per backend
_BUILTIN_SOURCES: dict[str, dict[str, str]] = {
    "paddle": {
        "index_url": "https://www.paddlepaddle.org.cn/packages/stable/{cuda_version}/",
        "package": "paddlepaddle-gpu",
    },
    "torch": {
        "index_url": "https://download.pytorch.org/whl/cu124",
        "package": "torch",
    },
}


@dataclass(frozen=True, slots=True)
class SourceConfig:
    """Installation source configuration for a single framework."""

    index_url: str = ""
    extra_index_url: str = "https://pypi.org/simple/"
    package: str = ""
    version: str = ""
    whl: str = ""
    python_version: str = "3.12"
    cuda_version: str = "cu129"


@dataclass(frozen=True, slots=True)
class DefaultsConfig:
    """CLI default parameters from config file."""

    backends: tuple[str, ...] = ()
    seed: int = 42
    verbose: bool = False
    pythons: tuple[str, ...] = ()
    # Legacy fields for backward compatibility with old config files
    backend_a: str = ""
    backend_b: str = ""
    python_a: str = ""
    python_b: str = ""


@dataclass(frozen=True, slots=True)
class ProjectConfig:
    """Unified project configuration loaded from tensor-spec.toml."""

    sources: dict[str, SourceConfig] = field(default_factory=dict)
    defaults: DefaultsConfig = field(default_factory=DefaultsConfig)
    tolerance_data: dict[str, Any] = field(default_factory=dict)

    def get_source(self, backend: str) -> SourceConfig:
        """Get source config for a backend, merging with built-in defaults."""
        user = self.sources.get(backend, SourceConfig())
        builtin = _BUILTIN_SOURCES.get(backend, {})

        return SourceConfig(
            index_url=user.index_url or builtin.get("index_url", ""),
            extra_index_url=user.extra_index_url,
            package=user.package or builtin.get("package", ""),
            version=user.version,
            whl=user.whl,
            python_version=user.python_version,
            cuda_version=user.cuda_version,
        )

    def resolve_index_url(self, backend: str) -> str:
        """Resolve index URL with {cuda_version} interpolation."""
        src = self.get_source(backend)
        return src.index_url.format(cuda_version=src.cuda_version)

    @classmethod
    def from_toml(cls, path: str | Path) -> ProjectConfig:
        """Load ProjectConfig from a TOML file."""
        import tomllib

        with open(path, "rb") as f:
            data = tomllib.load(f)

        # Parse [sources.*]
        sources: dict[str, SourceConfig] = {}
        for name, src_data in data.get("sources", {}).items():
            sources[name] = SourceConfig(
                index_url=src_data.get("index_url", ""),
                extra_index_url=src_data.get("extra_index_url", "https://pypi.org/simple/"),
                package=src_data.get("package", ""),
                version=src_data.get("version", ""),
                whl=src_data.get("whl", ""),
                python_version=src_data.get("python_version", "3.12"),
                cuda_version=src_data.get("cuda_version", "cu129"),
            )

        # Parse [defaults]
        defaults_data = data.get("defaults", {})
        # Support new list-based backends/pythons and legacy backend_a/backend_b
        backends_list = defaults_data.get("backends", [])
        pythons_list = defaults_data.get("pythons", [])
        defaults = DefaultsConfig(
            backends=tuple(backends_list),
            seed=defaults_data.get("seed", 42),
            verbose=defaults_data.get("verbose", False),
            pythons=tuple(pythons_list),
            backend_a=defaults_data.get("backend_a", ""),
            backend_b=defaults_data.get("backend_b", ""),
            python_a=defaults_data.get("python_a", ""),
            python_b=defaults_data.get("python_b", ""),
        )

        # Pass [tolerance] through as raw dict for Tolerance.from_dict()
        tolerance_data = data.get("tolerance", {})

        return cls(sources=sources, defaults=defaults, tolerance_data=tolerance_data)

    @classmethod
    def find_and_load(cls, start_dir: str | Path | None = None) -> ProjectConfig | None:
        """Walk up from start_dir looking for tensor-spec.toml; return None if not found."""
        current = Path(start_dir) if start_dir else Path.cwd()
        current = current.resolve()

        for directory in [current, *current.parents]:
            candidate = directory / "tensor-spec.toml"
            if candidate.is_file():
                return cls.from_toml(candidate)

        return None
