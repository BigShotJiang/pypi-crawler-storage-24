# ClickHouse query tools

Exposes ClickHouse internals to parse and manipulate ClickHouse queries.

Currently made of 1 module, clickhouse-toolset, which includes functionality both for the server and the CLI.

Initially this was published in pypi as `clickhouse-toolset`. After release 0.36 it was moved to `tinybird-toolset` 1.0.0.

---

## C++ Extension Architecture

This is a Python extension module built with the native CPython C API that wraps ClickHouse parsing functionality.

### Architecture Overview

```
Python Application
        │
        ▼
┌──────────────────┐
│ chtoolset.query  │  Python wrapper (chtoolset/query.py)
└────────┬─────────┘
         │
         ▼
┌──────────────────┐
│ _query.so        │  Python extension (src/query.cpp)
└────────┬─────────┘
         │
         ▼
┌──────────────────┐
│ libCHToolset.a   │  C++ library (functions/*.cpp)
└────────┬─────────┘
         │
         ▼
┌─────────────────────────────────┐
│ ClickHouse Static Libraries     │
│ (libclickhouse_parsers.a, etc.) │
└─────────────────────────────────┘
```

### Directory Structure

- **`src/query.cpp`** - Main Python binding file. Defines the `_query` module and maps Python functions to C++ implementations. Uses `PythonThreadHandler` to release the GIL during C++ computation.

- **`functions/`** - C++ implementation of all extension functionality. Key files include:
  - `TBQueryParser.cpp` - Thread-local LRU cache for parsed queries
  - `Tables.cpp` - Extract table names from queries (e.g., `tables("SELECT * FROM foo JOIN bar")` → `["foo", "bar"]`)
  - `ReplaceTables.cpp` - Rewrite table names in queries
  - `RowBinaryEncoder.cpp` - High-performance JSON to RowBinary conversion using simdjson
  - `Validation.cpp` - Function and settings validation against ClickHouse's registry

- **`chtoolset/query.py`** - Python wrapper that imports from `_query.so` and provides the public API

### Build System

The build is a multi-stage process orchestrated by `conf.py`:

1. **ClickHouse Build** - Applies patches from `patches/`, builds ClickHouse with CMake+Ninja
2. **Toolset Build** - Compiles `functions/*.cpp` into `libCHToolset.a`
3. **Extension Build** - Compiles `src/query.cpp`, links everything into `_query.so`

```bash
make build-3.11    # Build for Python 3.11
make test-3.11     # Build and test
OMIT_PATCHES=1 make build-3.11  # Skip patches on rebuild
```

### Key Profiling Targets

For performance work, focus on:
- `TBQueryParser::getOrSet()` - Parser cache lookup (hot path for repeated queries)
- `RowBinaryEncoder::convert()` - JSON parsing for large payloads
- `TB::tables()` - Table extraction (heavily used in query routing)

---

## Installing prebuilts

The module is available in PyPI with prebuilt wheels for Linux (x86_64 and ARM64) and macOS (ARM64):

```bash
pip install tinybird-toolset
```

If we don't have prebuilts for your platform the installation will fail.

### Alternative: Use Docker for compilation and testing

If you prefer not to install all dependencies locally, you can use the provided Docker image that contains all necessary tools:

```bash
# Build the Docker image
cd gitlab-runner
docker build -t build:latest -f build.Dockerfile .

# Run container with your code mounted
cd ..  # Back to project root
docker run -it -v $(pwd):/workspace build:latest bash

# Inside the container, compile and test
cd /workspace
make build      # Build for all Python versions
make test       # Run tests for all Python versions

# Or for a specific Python version
make build-3.11 # Build only for Python 3.11
make test-3.11  # Test only for Python 3.11
```

The Docker image includes:
- Clang 19 compiler toolchain
- CMake and Ninja build systems
- ccache for faster builds
- uv for Python environment management

This approach ensures a consistent build environment and is the same one used in the CI/CD pipeline.

**Note:** When upgrading ClickHouse, you may need to update the Clang version in the Docker image. Check `UPGRADE_CLICKHOUSE.md` for the upgrade process.

## Development

### Install pre-requisites (Ubuntu)

```bash
sudo apt-get update
sudo apt-get install git cmake ccache python3 python3-pip ninja-build nasm yasm gawk lsb-release wget software-properties-common gnupg

sudo bash -c "$(wget -O - https://apt.llvm.org/llvm.sh)"

sudo add-apt-repository ppa:deadsnakes/ppa
sudo apt update
sudo apt install python3.10-dev python3.11-dev python3.12-dev python3.13-dev python3.14-dev

pip3 install virtualenv
```

### Run tests

First, you need to clone the repo and **its submodules**.

```bash
git clone --recursive git@gitlab.com:tinybird/clickhouse-toolset.git
```

Then, you will compile the dependencies and the module itself. You need a modern compiler to build it, both under Linux and MacOS (AppleClang is not supported). The required Clang version depends on your ClickHouse version - check the [ClickHouse build documentation](https://clickhouse.com/docs/en/development/build) for the minimum required version (e.g., ClickHouse 25.3+ requires Clang 19+).

If your system Clang is not the correct version, set the CC and CXX environment variables before building:

```bash
# Example for macOS with Homebrew llvm@19
export CC=/opt/homebrew/opt/llvm@19/bin/clang
export CXX=/opt/homebrew/opt/llvm@19/bin/clang++
```

The best option is to use the Makefile targets which will use virtualenv to install dependencies, build the packages, install them too and run tests:

```bash
make test-3.14
```

### Generate pre-built packages

You need to install all the necessary python releases so they are available via virtualenv.

#### If you are In MacOS, prepare your environment:

You need to be able to compile ClickHouse for MacOS so we follow [their guide](https://github.com/ClickHouse/ClickHouse/blob/master/docs/en/development/build-osx.md) to install the necessary packages:

* Install Homebrew
* Install Xcode and Command Line Tools
* Install the necessary tools (cmake ninja libtool gettext llvm gcc ccache findutils grep). For the LLVM version, check the [ClickHouse build documentation](https://clickhouse.com/docs/en/development/build) for the minimum required Clang version.
* Make sure your local clang is pointing to the llvm installation and not the default from OSX / Xcode. You can check it by running `clang --version` - it should show "Homebrew clang" and the correct version.
* Set the CC and CXX environment variables before building:
```bash
# Example for llvm@19
export CC=/opt/homebrew/opt/llvm@19/bin/clang
export CXX=/opt/homebrew/opt/llvm@19/bin/clang++
```
* Follow the normal build (`make build`)

#### Clean environment if you already did some compilation before
To clean your environment you need to make sure that the repository is clean and updated with the expected values. To do that you can use:

```bash
make distclean
git clean -fdx
```

#### Make sure you have the expeted version from the submodules
```bash
git submodule sync && git submodule update --init --recursive

# If it fails because of changes inside the ClickHouse folder related to the patchs we apply, just reset all the changes in that directory so these patchs can be reaplied in the next step.
cd clickhouse
git reset --hard
```

#### Compile and generate the new .whl files
Use:

```bash
make build
```

#### Tip: re-compiling and debugging

A couple of environment variables can be defined with a non-empty value to help retrying the compilation and debugging:

* `OMIT_PATCHES` prevents the application of the ClickHouse patches: this is useful if you've already applied them to avoid having to restore the original source code, since some patches may not re-apply cleanly.
* `DEBUG_SYMBOLS` triggers the generation of debug symbols for the python extension code (query.cpp and the C++ functions, but not for the ClickHouse code).

## Examples

Check tests directory

## Release

Releasing a new version requires publishing wheels for three platforms: Linux x86_64, Linux ARM64 (automated via CI), and macOS ARM64 (manual).

### 1. Prepare the release

1. Update `VERSION` in `setup.py`
2. Update `CHANGELOG.md`
3. Create a MR with these changes and merge to `master`

### 2. Linux release (automatic)

Linux x86_64 and ARM64 wheels are published automatically when the MR is merged to `master`. The CI detects the `setup.py` change, and the `release` job will:

- Compare the version in `setup.py` with the latest version on PyPI (skips if already published)
- Collect auditwheel-repaired wheels for both x86_64 and ARM64
- Build the source distribution
- Upload everything to PyPI
- Create a git tag `vX.Y.Z` automatically

The `PYPI_TOKEN` CI/CD variable must be configured in GitLab (Settings > CI/CD > Variables) with a valid PyPI API token.

### 3. macOS release (manual)

macOS ARM64 wheels must be built and uploaded from a Mac with Apple Silicon using `release.sh`:

```bash
export TWINE_PASSWORD=pypi-...  # PyPI API token
./release.sh
```

The script will:
- Build wheels for Python 3.10-3.14
- Delocate them (bundle dynamic libraries, set minimum macOS version to 11.0)
- Run tests for each Python version
- Upload to PyPI

Requirements:
- macOS with Apple Silicon (ARM64)
- Homebrew LLVM 19 (`CC` and `CXX` must point to the Homebrew clang, not Apple's)
- `uv` and `make` installed
