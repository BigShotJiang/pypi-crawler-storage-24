"""AIRS - AI Runtime Security implementation toolkit."""

__version__ = "0.1.0"
