"""Lakebench CLI."""

from __future__ import annotations

import logging
import re
import shutil
import subprocess
import time
from datetime import datetime
from pathlib import Path
from typing import Annotated, Any

import typer
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from lakebench import __version__
from lakebench._constants import DEFAULT_OUTPUT_DIR
from lakebench.config import (
    ConfigError,
    ConfigFileNotFoundError,
    ConfigValidationError,
    generate_example_config_yaml,
    load_config,
    parse_spark_memory,
)
from lakebench.config.schema import PipelineMode
from lakebench.journal import DEFAULT_JOURNAL_DIR, CommandName, EventType, Journal
from lakebench.k8s import K8sConnectionError, PlatformType, SecurityVerifier, get_k8s_client
from lakebench.s3 import test_s3_connectivity

# Default config file name for auto-discovery
DEFAULT_CONFIG = "lakebench.yaml"

logger = logging.getLogger(__name__)

# Global journal instance (lazy-initialized)
_journal: Journal | None = None

# ANSI escape code stripper for log output
_ANSI_RE = re.compile(r"\x1b\[[0-9;]*[a-zA-Z]")


def _strip_ansi(text: str) -> str:
    """Remove ANSI escape codes from text."""
    return _ANSI_RE.sub("", text)


app = typer.Typer(
    name="lakebench",
    help="Deploy and benchmark lakehouse architectures on Kubernetes",
    add_completion=False,
    no_args_is_help=True,
    rich_markup_mode="rich",
    context_settings={"help_option_names": ["-h", "--help"]},
    epilog="[dim]Workflow: init -> validate -> deploy -> generate -> run -> report -> destroy[/dim]",
)

console = Console()


# =============================================================================
# Helper Functions
# =============================================================================


def resolve_config_path(
    config_file: Path | None,
    file_option: Path | None = None,
) -> Path:
    """Resolve config file path, using ./lakebench.yaml as default.

    Supports both positional argument and --file/-f option.
    If both are provided, --file takes precedence.
    """
    path = file_option or config_file
    if path is not None:
        return path

    default = Path(DEFAULT_CONFIG)
    if default.exists():
        return default

    console.print(f"[red]ERROR[/red] No config file specified and ./{DEFAULT_CONFIG} not found")
    console.print("[blue]INFO[/blue] Create one with: lakebench init")
    raise typer.Exit(1)


def get_journal() -> Journal:
    """Get or create the global journal instance."""
    global _journal
    if _journal is None:
        _journal = Journal()
    return _journal


def journal_open(config_path: Path | None, config_name: str = "") -> Journal:
    """Open journal session for a command that loads config."""
    j = get_journal()
    j.open_session(config_path=config_path, config_name=config_name)
    return j


def print_success(message: str) -> None:
    """Print a success message."""
    console.print(f"[green]OK[/green] {message}")


def print_error(message: str) -> None:
    """Print an error message."""
    console.print(f"[red]ERROR[/red] {message}")


def print_warning(message: str) -> None:
    """Print a warning message."""
    console.print(f"[yellow]WARN[/yellow] {message}")


def print_info(message: str) -> None:
    """Print an info message."""
    console.print(f"[blue]...[/blue] {message}")


_journal_warned = False


def _journal_safe(fn, *args, **kwargs) -> None:
    """Call a journal function, logging failures instead of silently dropping them."""
    global _journal_warned
    try:
        fn(*args, **kwargs)
    except Exception:
        if not _journal_warned:
            logger.debug("Journal write failed (further warnings suppressed)", exc_info=True)
            _journal_warned = True


def _print_pipeline_scorecard(
    pb,
    stage_results: list[tuple[str, bool, float]],
    datagen_elapsed: float,
    benchmark_qph: float | None,
) -> None:
    """Print the pipeline complete panel with full scorecard."""
    # Stage timing lines
    lines: list[str] = []
    if datagen_elapsed > 0:
        lines.append(f"  data-generation {datagen_elapsed:>8.0f}s")
    for name, _ok, elapsed in stage_results:
        lines.append(f"  {name:<16}{elapsed:>8.0f}s")
    total_time = datagen_elapsed + sum(r[2] for r in stage_results)

    body = "[green]Pipeline completed successfully[/green]\n\n"
    body += "\n".join(lines)

    # Scores section
    scores: list[str] = []
    if pb.pipeline_mode == PipelineMode.SUSTAINED.value:
        if (pb.data_freshness_seconds or 0) > 0:
            scores.append(f"  Freshness:      {pb.data_freshness_seconds:>8.1f}s")
        if pb.sustained_throughput_rps > 0:
            scores.append(f"  Throughput:     {pb.sustained_throughput_rps:>8,.0f} rows/s")
        if pb.stage_latency_profile:
            lat = "/".join(f"{v:.0f}" for v in pb.stage_latency_profile)
            scores.append(f"  Latency (b/s/g):  {lat}ms")
        if pb.ingest_ratio > 0:
            pct = pb.ingest_ratio * 100
            scores.append(f"  Completeness:   {pct:>7.1f}%")
        if pb.pipeline_saturated:
            scores.append("  [yellow]Pipeline saturated (completeness < 95%)[/yellow]")
    else:
        if pb.time_to_value_seconds > 0:
            scores.append(f"  Time to Value:  {pb.time_to_value_seconds:>8.1f}s")
        if pb.pipeline_throughput_gb_per_second > 0:
            scores.append(f"  Throughput:     {pb.pipeline_throughput_gb_per_second:>8.3f} GB/s")
        if pb.total_data_processed_gb > 0:
            scores.append(f"  Data Processed: {pb.total_data_processed_gb:>8.1f} GB")
        if pb.compute_efficiency_gb_per_core_hour > 0:
            scores.append(
                f"  Efficiency:     {pb.compute_efficiency_gb_per_core_hour:>8.3f} GB/core-hr"
            )
        if pb.scale_ratio > 0:
            pct = pb.scale_ratio * 100
            label = "[green]verified[/green]" if pct >= 95 else "[yellow]incomplete[/yellow]"
            scores.append(f"  Scale:          {pct:>7.1f}% {label}")

    if benchmark_qph is not None:
        scores.append(f"  QpH:            {benchmark_qph:>8,.1f}")

    if scores:
        body += "\n\n[bold]Scores[/bold]\n" + "\n".join(scores)

    body += f"\n\nTotal: {total_time:.0f}s\n\nFull report: [bold]lakebench report[/bold]"

    console.print()
    console.print(Panel(body, title="Pipeline Complete", expand=False))


def _print_report_summary(metrics) -> None:
    """Print key scores from saved metrics to the terminal."""
    pb = metrics.pipeline_benchmark
    if pb is None:
        print_warning("No pipeline benchmark data in this run.")
        return

    # Header
    status = "[green]Passed[/green]" if pb.success else "[red]Failed[/red]"
    header = (
        f"[bold]{pb.deployment_name}[/bold]  run {pb.run_id}\n"
        f"Mode: {pb.pipeline_mode} | Status: {status}"
    )

    # Stage table
    table = Table(show_header=True, header_style="bold", expand=False)
    table.add_column("Stage", style="cyan")
    table.add_column("Time", justify="right")
    table.add_column("In (GB)", justify="right")
    table.add_column("Out (GB)", justify="right")
    table.add_column("GB/s", justify="right")
    table.add_column("Executors", justify="right")

    for stage in pb.stages:
        table.add_row(
            stage.stage_name,
            f"{stage.elapsed_seconds:.0f}s",
            f"{stage.input_size_gb:.1f}" if stage.input_size_gb > 0 else "-",
            f"{stage.output_size_gb:.1f}" if stage.output_size_gb > 0 else "-",
            f"{stage.throughput_gb_per_second:.3f}" if stage.throughput_gb_per_second > 0 else "-",
            str(stage.executor_count) if stage.executor_count > 0 else "-",
        )

    # Scores
    scores: list[str] = []
    if pb.pipeline_mode == PipelineMode.SUSTAINED.value:
        if (pb.data_freshness_seconds or 0) > 0:
            scores.append(f"Freshness:       {pb.data_freshness_seconds:>8.1f}s")
        if pb.sustained_throughput_rps > 0:
            scores.append(f"Throughput:      {pb.sustained_throughput_rps:>8,.0f} rows/s")
        if pb.stage_latency_profile:
            lat = "/".join(f"{v:.0f}" for v in pb.stage_latency_profile)
            scores.append(f"Latency (b/s/g): {lat}ms")
        if pb.ingest_ratio > 0:
            pct = pb.ingest_ratio * 100
            scores.append(f"Completeness:    {pct:>7.1f}%")
        if pb.pipeline_saturated:
            scores.append("[yellow]Pipeline saturated (completeness < 95%)[/yellow]")
    else:
        if pb.time_to_value_seconds > 0:
            scores.append(f"Time to Value:   {pb.time_to_value_seconds:>8.1f}s")
        if pb.pipeline_throughput_gb_per_second > 0:
            scores.append(f"Throughput:      {pb.pipeline_throughput_gb_per_second:>8.3f} GB/s")
        if pb.total_data_processed_gb > 0:
            scores.append(f"Data Processed:  {pb.total_data_processed_gb:>8.1f} GB")
        if pb.compute_efficiency_gb_per_core_hour > 0:
            scores.append(
                f"Efficiency:      {pb.compute_efficiency_gb_per_core_hour:>8.3f} GB/core-hr"
            )
        if pb.scale_ratio > 0:
            pct = pb.scale_ratio * 100
            label = "[green]verified[/green]" if pct >= 95 else "[yellow]incomplete[/yellow]"
            scores.append(f"Scale:           {pct:>7.1f}% {label}")

    if pb.query_benchmark:
        scores.append(f"QpH:             {pb.query_benchmark.qph:>8,.1f}")

    console.print()
    console.print(Panel(header, title="Benchmark Summary", expand=False))
    console.print(table)
    if scores:
        console.print()
        for s in scores:
            console.print(f"  {s}")
    console.print()


def _preflight_check(cfg) -> None:
    """Run critical pre-flight checks before deployment.

    Prints warnings for non-critical issues; exits on blockers.
    """
    print_info("Tip: run 'lakebench validate' for a full prerequisite check")

    # 1. S3 endpoint must be set
    s3 = cfg.platform.storage.s3
    if not s3.endpoint:
        print_error("S3 endpoint not configured (platform.storage.s3.endpoint)")
        print_info("Run 'lakebench validate' for detailed diagnostics")
        raise typer.Exit(1)

    # 2. S3 credentials must be present (inline or secret_ref)
    has_inline = bool(s3.access_key and s3.secret_key)
    has_ref = bool(getattr(s3, "secret_ref", None))
    if not has_inline and not has_ref:
        print_error("S3 credentials not configured (set access_key/secret_key or secret_ref)")
        raise typer.Exit(1)

    # 3. Check Stackable CRDs if catalog=hive
    if cfg.architecture.catalog.type.value == "hive":
        _missing_stackable: list[str] = []
        try:
            # Check CRDs directly without instantiating a full deployer
            from kubernetes import client as k8s_client

            api_ext = k8s_client.ApiextensionsV1Api()
            crds = api_ext.list_custom_resource_definition()
            crd_names = {crd.metadata.name for crd in crds.items}
            required_crds = {
                "hiveclusters.hive.stackable.tech": "hive-operator",
                "secretclasses.secrets.stackable.tech": "secret-operator",
            }
            _missing_stackable = [op for crd, op in required_crds.items() if crd not in crd_names]
        except Exception:
            logger.debug("Preflight CRD check skipped (K8s not reachable)", exc_info=True)

        if _missing_stackable:
            op_install = getattr(
                getattr(getattr(cfg.architecture.catalog, "hive", None), "operator", None),
                "install",
                False,
            )
            if op_install:
                print_info(
                    f"Stackable operators missing ({', '.join(_missing_stackable)}) "
                    "-- will be auto-installed during deploy (install: true)"
                )
            else:
                print_error(f"Missing Stackable operators: {', '.join(_missing_stackable)}")
                print_info("Install operators first:")
                for op in [
                    "commons-operator",
                    "listener-operator",
                    "secret-operator",
                    "hive-operator",
                ]:
                    console.print(
                        f"  helm install {op} "
                        f"oci://oci.stackable.tech/sdp-charts/{op} "
                        f"--version 25.7.0 --namespace stackable --create-namespace"
                    )
                print_info(
                    "Or switch to a Polaris recipe (no operators needed):\n"
                    "  Set recipe: polaris-iceberg-spark-trino in your config"
                )
                raise typer.Exit(1)


def _run_preflight_infra_check(cfg) -> None:
    """Check that required infrastructure is deployed before running the pipeline.

    Verifies the namespace, Postgres, configured catalog, and configured query
    engine are present and ready. Exits with actionable guidance if anything is
    missing.
    """
    ns = cfg.get_namespace()

    try:
        k8s = get_k8s_client(
            context=cfg.platform.kubernetes.context,
            namespace=ns,
        )
    except K8sConnectionError as e:
        print_error(f"Cannot connect to Kubernetes: {e}")
        print_info("Check your kubectl context and cluster connectivity")
        raise typer.Exit(1) from None

    # 1. Namespace must exist
    if not k8s.namespace_exists(ns):
        print_error(f"Namespace '{ns}' does not exist")
        print_info("Run 'lakebench deploy' to create the deployment first")
        raise typer.Exit(1)

    # 2. Build config-aware list of required components
    from kubernetes import client as k8s_client

    apps_v1 = k8s_client.AppsV1Api()

    required: list[tuple[str, str, str]] = [
        ("lakebench-postgres", "StatefulSet", "PostgreSQL"),
    ]
    cat = cfg.architecture.catalog.type.value
    if cat == "hive":
        required.append(("lakebench-hive-metastore-default", "StatefulSet", "Hive Metastore"))
    elif cat == "polaris":
        required.append(("lakebench-polaris", "Deployment", "Polaris Catalog"))

    engine = cfg.architecture.query_engine.type.value
    if engine == "trino":
        required.append(("lakebench-trino-coordinator", "Deployment", "Trino coordinator"))
        required.append(("lakebench-trino-worker", "StatefulSet", "Trino workers"))
    elif engine == "spark-thrift":
        required.append(("lakebench-spark-thrift", "Deployment", "Spark Thrift Server"))
    elif engine == "duckdb":
        required.append(("lakebench-duckdb", "Deployment", "DuckDB"))

    # 3. Check each component
    missing: list[str] = []
    not_ready: list[str] = []
    for name, kind, label in required:
        try:
            if kind == "StatefulSet":
                obj = apps_v1.read_namespaced_stateful_set(name, ns)
                ready = obj.status.ready_replicas or 0
                desired = obj.spec.replicas or 1
            else:
                obj = apps_v1.read_namespaced_deployment(name, ns)
                ready = obj.status.ready_replicas or 0
                desired = obj.spec.replicas or 1
            if ready < desired:
                not_ready.append(f"{label} ({ready}/{desired} replicas ready)")
        except k8s_client.rest.ApiException as e:
            if e.status == 404:
                missing.append(label)
            else:
                logger.warning("Preflight check error for %s: %s", name, e.reason)
                not_ready.append(f"{label} (API error: {e.reason})")

    # 4. Report and block
    if missing or not_ready:
        print_error("Infrastructure not ready -- cannot run pipeline")
        if missing:
            console.print(f"  [red]Missing:[/red] {', '.join(missing)}")
        if not_ready:
            console.print(f"  [yellow]Not ready:[/yellow] {', '.join(not_ready)}")
        console.print()
        if missing:
            print_info("Run 'lakebench deploy' to create the missing components")
        else:
            print_info("Wait for components to become ready, or check 'lakebench status'")
        # Show config mismatch hint if catalog/engine might be wrong
        console.print(f"  Config expects: catalog={cat}, query_engine={engine} (namespace: {ns})")
        raise typer.Exit(1)

    print_success("Infrastructure check passed")


def _build_component_list(cfg) -> str:
    """Build a config-aware component list for confirmation prompts."""
    parts = ["PostgreSQL"]
    cat = cfg.architecture.catalog.type.value
    if cat == "hive":
        parts.append("Hive Metastore")
    elif cat == "polaris":
        parts.append("Polaris Catalog")
    engine = cfg.architecture.query_engine.type.value
    if engine == "trino":
        parts.append("Trino")
    elif engine == "spark-thrift":
        parts.append("Spark Thrift Server")
    elif engine == "duckdb":
        parts.append("DuckDB")
    parts.append("Spark RBAC")
    if cfg.platform.compute.spark.operator.install:
        parts.append("Spark Operator")
    if cfg.observability.enabled:
        if cfg.observability.prometheus_stack_enabled:
            parts.append("Prometheus")
        if cfg.observability.dashboards_enabled:
            parts.append("Grafana")
    return ", ".join(parts)


def _build_destroy_list(cfg) -> str:
    """Build a config-aware destruction list for confirmation prompt."""
    items = ["PostgreSQL data"]
    cat = cfg.architecture.catalog.type.value
    if cat == "hive":
        items.append("Hive Metastore")
    elif cat == "polaris":
        items.append("Polaris Catalog")
    engine = cfg.architecture.query_engine.type.value
    if engine == "trino":
        items.append("Trino cluster")
    elif engine == "spark-thrift":
        items.append("Spark Thrift Server")
    elif engine == "duckdb":
        items.append("DuckDB")
    if cfg.observability.enabled:
        items.append("Prometheus + Grafana")
    items.append("All secrets, configs, and namespace")
    return "\n".join(f"  - {item}" for item in items)


# =============================================================================
# CLI Commands
# =============================================================================


@app.command()
def version() -> None:
    """Show version information."""
    console.print(f"Lakebench version {__version__}")


@app.command()
def init(
    output: Annotated[
        Path,
        typer.Option(
            "--output",
            "-o",
            help="Output file path for configuration",
        ),
    ] = Path("lakebench.yaml"),
    name: Annotated[
        str,
        typer.Option(
            "--name",
            "-n",
            help="Deployment name",
        ),
    ] = "my-lakehouse",
    scale: Annotated[
        int,
        typer.Option(
            "--scale",
            "-s",
            help="Scale factor (1 = ~10 GB, 100 = ~1 TB, 1000 = ~10 TB)",
        ),
    ] = 10,
    endpoint: Annotated[
        str,
        typer.Option(
            "--endpoint",
            help="S3 endpoint URL (e.g. http://your-s3:80 or https://your-s3:443)",
        ),
    ] = "",
    access_key: Annotated[
        str,
        typer.Option(
            "--access-key",
            help="S3 access key",
        ),
    ] = "",
    secret_key: Annotated[
        str,
        typer.Option(
            "--secret-key",
            help="S3 secret key",
        ),
    ] = "",
    namespace: Annotated[
        str,
        typer.Option(
            "--namespace",
            help="Kubernetes namespace (default: same as deployment name)",
        ),
    ] = "",
    recipe: Annotated[
        str,
        typer.Option(
            "--recipe",
            "-r",
            help="Architecture recipe (e.g. hive-iceberg-spark-trino, default)",
        ),
    ] = "",
    interactive: Annotated[
        bool,
        typer.Option(
            "--interactive/--no-interactive",
            "-i",
            help="Guided wizard setup (default when no flags given)",
        ),
    ] = True,
    force: Annotated[
        bool,
        typer.Option(
            "--force",
            "-f",
            help="Overwrite existing file",
        ),
    ] = False,
) -> None:
    """Generate a starter configuration file.

    Launches an interactive wizard by default. The wizard guides you through
    5 steps: identity, recipe, storage, workload, and review.

    Use --no-interactive with flags for scripted/CI usage:

        lakebench init --no-interactive --endpoint http://s3:80 --access-key A --secret-key B

    Use 'lakebench recommend' first to find the right scale for your cluster.
    """
    if output.exists() and not force:
        print_error(f"File already exists: {output}")
        print_info("Use --force to overwrite")
        raise typer.Exit(1)

    # Detect whether user passed substantive flags -- if so, skip wizard
    # even if --interactive wasn't explicitly set to false.
    # Also skip wizard when stdin is not a TTY (CI, test runners, pipes).
    import sys

    has_flags = endpoint or access_key or secret_key
    is_tty = hasattr(sys.stdin, "isatty") and sys.stdin.isatty()

    if interactive and not has_flags and is_tty:
        # Wizard mode
        from lakebench.init_wizard import run_wizard

        result = run_wizard(console)
        if result is None:
            raise typer.Exit(0)

        # Apply any CLI flag overrides onto wizard state
        if name != "my-lakehouse":
            result.name = name
        if namespace:
            result.namespace = namespace
        if recipe:
            result.recipe = recipe
        if scale != 10:
            result.scale = scale

        # Confirm write
        import typer as _typer

        console.print()
        if not _typer.confirm(f"  Write configuration to {output}?", default=True):
            console.print("[yellow]Cancelled.[/yellow]")
            raise typer.Exit(0)

        output.write_text(result.config_yaml)
        console.print()
        print_success(f"Created configuration file: {output}")
        print_info("Next steps:")
        print_info("  1. lakebench validate       -- check config for errors")
        print_info("  2. lakebench deploy          -- deploy infrastructure")
        print_info("  3. lakebench generate --wait -- generate test data")
        print_info("  4. lakebench run             -- run pipeline + benchmark")
        return

    # Non-interactive / flag mode (backward compatible)
    config_content = generate_example_config_yaml()
    config_content = config_content.replace("name: my-lakehouse", f"name: {name}")
    config_content = re.sub(r"scale:\s*\d+", f"scale: {scale}", config_content)

    if recipe:
        config_content = config_content.replace(
            f"name: {name}",
            f"name: {name}\nrecipe: {recipe}",
        )

    if endpoint:
        config_content = config_content.replace('endpoint: ""', f'endpoint: "{endpoint}"', 1)
    if access_key:
        config_content = config_content.replace('access_key: ""', f'access_key: "{access_key}"')
    if secret_key:
        config_content = config_content.replace('secret_key: ""', f'secret_key: "{secret_key}"')
    if namespace:
        config_content = config_content.replace('namespace: ""', f'namespace: "{namespace}"', 1)

    output.write_text(config_content)
    print_success(f"Created configuration file: {output}")
    print_info(f"Scale: {scale}")
    if not endpoint:
        print_info("Edit the file to configure your S3 endpoint and credentials")
    print_info("Then run: lakebench validate")
    print_info("Run 'lakebench recommend' to find the optimal scale for your cluster")


@app.command()
def validate(
    config_file: Annotated[
        Path | None,
        typer.Argument(
            help="Path to configuration YAML file (default: ./lakebench.yaml)",
        ),
    ] = None,
    file_option: Annotated[
        Path | None,
        typer.Option(
            "--file",
            "-f",
            help="Path to configuration YAML file (alternative to positional argument)",
        ),
    ] = None,
    verbose: Annotated[
        bool,
        typer.Option(
            "--verbose",
            "-v",
            help="Show detailed validation output",
        ),
    ] = False,
) -> None:
    """Validate configuration and test connectivity.

    This command performs the following checks:
    - YAML syntax is valid
    - Required fields are present
    - S3 endpoint is reachable
    - S3 credentials are valid
    - Kubernetes context is accessible
    - Kubernetes namespace is accessible or can be created
    """
    config_file = resolve_config_path(config_file, file_option)
    console.print(Panel(f"Validating: [bold]{config_file}[/bold]", expand=False))

    # Journal (opened early so we can record config_loaded)
    j = journal_open(config_file, config_name="")
    j.begin_command(CommandName.VALIDATE, {"verbose": verbose})

    # Track validation results
    checks_passed = 0
    checks_failed = 0
    checks_warned = 0

    # --- Helpers for grouped section output ---
    _section_items: list[tuple[str, str, str | None]] = []  # (status, msg, hint)

    def _section_start(title: str) -> None:
        _section_items.clear()
        console.print(f"\n [bold]{title}[/bold]")

    def _check_ok(msg: str, *, hint: str | None = None) -> None:
        _section_items.append(("ok", msg, hint))

    def _check_fail(msg: str, *, hint: str | None = None) -> None:
        _section_items.append(("fail", msg, hint))

    def _check_warn(msg: str, *, hint: str | None = None) -> None:
        _section_items.append(("warn", msg, hint))

    def _section_end() -> tuple[int, int, int]:
        """Flush section items. Returns (passed, failed, warned)."""
        ok = fail = warn = 0
        for status, msg, hint in _section_items:
            if status == "ok":
                console.print(f"   [green]+[/green] {msg}")
                ok += 1
            elif status == "fail":
                console.print(f"   [red]x[/red] {msg}")
                fail += 1
            else:
                console.print(f"   [yellow]![/yellow] {msg}")
                warn += 1
            if hint:
                for line in hint.split("\n"):
                    console.print(f"     [dim]{line}[/dim]")
        _section_items.clear()
        return ok, fail, warn

    # 1. Load and validate config
    _section_start("Configuration")
    try:
        cfg = load_config(config_file)
        _check_ok("Config syntax valid")
        if verbose:
            _check_ok(f"Name: {cfg.name}, Namespace: {cfg.get_namespace()}")
    except ConfigFileNotFoundError as e:
        print_error(f"File not found: {e}")
        raise typer.Exit(1)  # noqa: B904
    except ConfigValidationError as e:
        print_error("Config validation failed:")
        for err in e.errors:
            loc = ".".join(str(x) for x in err["loc"])
            console.print(f"  [red]x[/red] {loc}: {err['msg']}")
        raise typer.Exit(1)  # noqa: B904
    except ConfigError as e:
        print_error(f"Config error: {e}")
        raise typer.Exit(1)  # noqa: B904
    p, f, w = _section_end()
    checks_passed += p
    checks_failed += f
    checks_warned += w

    # 2. CLI tools
    _section_start("CLI Tools")
    for tool in ["kubectl", "helm"]:
        if shutil.which(tool):
            _check_ok(f"{tool} found")
        else:
            _check_fail(f"{tool} not found on PATH")
    p, f, w = _section_end()
    checks_passed += p
    checks_failed += f
    checks_warned += w

    # 3. S3 storage (endpoint + credentials + connectivity -- single group)
    _section_start("S3 Storage")
    s3 = cfg.platform.storage.s3

    if not s3.endpoint:
        _check_fail("Endpoint not configured")
    else:
        _check_ok(f"Endpoint: {s3.endpoint}")

    if not cfg.has_inline_s3_credentials() and not cfg.has_s3_secret_ref():
        _check_fail("Credentials not configured (neither inline nor secret_ref)")
    else:
        _check_ok("Credentials configured")

    # Live connectivity
    if s3.endpoint and cfg.has_inline_s3_credentials():
        results = test_s3_connectivity(
            endpoint=s3.endpoint,
            access_key=s3.access_key,
            secret_key=s3.secret_key,
            region=s3.region,
            path_style=s3.path_style,
            ca_cert=s3.ca_cert,
            verify_ssl=s3.verify_ssl,
        )

        if results["endpoint_reachable"]:
            _check_ok("Endpoint reachable")
        else:
            _check_fail(results["endpoint_message"])

        if results["credentials_valid"]:
            _check_ok("Credentials valid")
            if verbose and results["buckets"]:
                _check_ok(f"Buckets: {', '.join(results['buckets'])}")
        elif results["endpoint_reachable"]:
            _check_fail(results["credentials_message"])

    # Secret ref validation
    if cfg.has_s3_secret_ref():
        secret_name = cfg.platform.storage.s3.secret_ref
        try:
            k8s = get_k8s_client(
                context=cfg.platform.kubernetes.context,
                namespace=cfg.get_namespace(),
            )
            if k8s.secret_exists(secret_name, cfg.get_namespace()):
                _check_ok(f"Secret '{secret_name}' exists")
            else:
                _check_fail(
                    f"Secret '{secret_name}' not found in namespace '{cfg.get_namespace()}'"
                )
        except K8sConnectionError:
            _check_warn("Cannot verify S3 secret (K8s not connected yet)")
        except Exception as e:
            _check_warn(f"Cannot verify S3 secret: {e}")

    # Bucket name overlap
    bucket_names = [s3.buckets.bronze, s3.buckets.silver, s3.buckets.gold]
    if len(set(bucket_names)) < 3:
        _check_warn("Bronze, silver, and gold use overlapping bucket names")

    p, f, w = _section_end()
    checks_passed += p
    checks_failed += f
    checks_warned += w

    # 4. Kubernetes cluster (connectivity + namespace + platform security)
    _section_start("Kubernetes")
    try:
        k8s = get_k8s_client(
            context=cfg.platform.kubernetes.context,
            namespace=cfg.get_namespace(),
        )

        connected, msg = k8s.test_connectivity()
        if connected:
            _check_ok(msg)
        else:
            _check_fail(msg)

        ctx = k8s.get_current_context()
        if ctx and verbose:
            _check_ok(f"Context: {ctx.name} / Cluster: {ctx.cluster}")

        ns = cfg.get_namespace()
        if k8s.namespace_exists(ns):
            _check_ok(f"Namespace '{ns}' exists")
        else:
            can_create, msg = k8s.can_create_namespace(ns)
            if can_create:
                _check_ok(f"Namespace '{ns}' can be created")
            else:
                _check_fail(f"Cannot create namespace '{ns}': {msg}")

        # Platform security
        verifier = SecurityVerifier(k8s)
        platform = verifier.detect_platform()
        platform_version = verifier.get_platform_version()

        platform_info = f"{platform.value}"
        if platform_version:
            platform_info += f" {platform_version}"
        _check_ok(f"Platform: {platform_info}")

        security_result = verifier.verify_security(ns)

        if platform == PlatformType.OPENSHIFT:
            for scc in security_result.scc_status:
                if scc.assigned:
                    _check_ok(f"SCC '{scc.name}' assigned to '{scc.service_account}'")
                else:
                    fix_hint = (
                        f"Fix: oc adm policy add-scc-to-user {scc.name} "
                        f"-z {scc.service_account} -n {ns}"
                    )
                    _check_warn(
                        f"SCC '{scc.name}' not assigned to '{scc.service_account}'",
                        hint="Auto-configured during deploy" if not verbose else fix_hint,
                    )

        if security_result.passed:
            checks_passed += security_result.checks_passed
        else:
            if platform == PlatformType.OPENSHIFT:
                _check_warn(
                    f"Security: {security_result.checks_failed} item(s) need attention",
                    hint="SCC will be configured automatically during deploy",
                )
            checks_passed += security_result.checks_passed

        if verbose and security_result.recommendations:
            for rec in security_result.recommendations:
                _check_ok(f"Tip: {rec}")

    except K8sConnectionError as e:
        _check_fail(f"Connection failed: {e}")

    p, f, w = _section_end()
    checks_passed += p
    checks_failed += f
    checks_warned += w

    # 5. Storage classes
    _section_start("Storage Classes")
    try:
        from kubernetes import client as k8s_client
        from kubernetes.client.rest import ApiException

        storage_v1 = k8s_client.StorageV1Api()

        storage_classes = []
        scratch_cfg = cfg.platform.storage.scratch
        if scratch_cfg.enabled and scratch_cfg.storage_class:
            storage_classes.append(
                (scratch_cfg.storage_class, "scratch", not scratch_cfg.create_storage_class)
            )

        pg_sc = cfg.platform.compute.postgres.storage_class
        if pg_sc:
            storage_classes.append((pg_sc, "postgres", True))

        if not storage_classes:
            _check_ok("Using cluster defaults (no custom storage classes)")
        else:
            for sc_name, purpose, required in storage_classes:
                try:
                    storage_v1.read_storage_class(sc_name)
                    _check_ok(f"{sc_name} ({purpose})")
                except ApiException as e:
                    if e.status == 404:
                        if required:
                            _check_fail(f"{sc_name} not found ({purpose})")
                        else:
                            _check_warn(
                                f"{sc_name} will be created during deploy ({purpose})",
                            )
                    else:
                        _check_warn(f"Could not check {sc_name}: {e.reason}")
    except Exception as e:
        _check_warn(f"Could not validate storage classes: {e}")
    p, f, w = _section_end()
    checks_passed += p
    checks_failed += f
    checks_warned += w

    # 6. Catalog prerequisites
    _section_start("Catalog")
    if cfg.architecture.catalog.type.value == "hive":
        try:
            from kubernetes import client as k8s_client

            api_ext = k8s_client.ApiextensionsV1Api()
            crds = api_ext.list_custom_resource_definition()
            crd_names = {crd.metadata.name for crd in crds.items}
            required_crds = {
                "hiveclusters.hive.stackable.tech": "hive-operator",
                "secretclasses.secrets.stackable.tech": "secret-operator",
            }
            missing = [op for crd, op in required_crds.items() if crd not in crd_names]
            if missing:
                hive_op_cfg = cfg.architecture.catalog.hive.operator
                if hive_op_cfg.install:
                    _check_warn(
                        f"Missing Stackable operators: {', '.join(missing)}",
                        hint="Will be auto-installed during deploy (install: true)",
                    )
                else:
                    install_hint = (
                        "Option 1: Set architecture.catalog.hive.operator.install: true\n"
                        "Option 2: Install manually:\n"
                        + "\n".join(
                            f"  helm install {op} oci://oci.stackable.tech/sdp-charts/{op} "
                            f"--version {hive_op_cfg.version} --namespace {hive_op_cfg.namespace}"
                            " --create-namespace"
                            for op in [
                                "commons-operator",
                                "listener-operator",
                                "secret-operator",
                                "hive-operator",
                            ]
                        )
                    )
                    _check_fail(
                        f"Missing Stackable operators: {', '.join(missing)}",
                        hint=install_hint,
                    )
            else:
                _check_ok("Stackable operators installed (Hive)")
        except Exception:
            _check_warn("Could not verify Stackable operators (K8s not reachable)")
    elif cfg.architecture.catalog.type.value == "polaris":
        _check_ok("Polaris catalog (no external operators needed)")
    else:
        _check_ok(f"Catalog type: {cfg.architecture.catalog.type.value}")
    p, f, w = _section_end()
    checks_passed += p
    checks_failed += f
    checks_warned += w

    # 7. Spark Operator
    _section_start("Spark Operator")
    try:
        from lakebench.spark import SparkOperatorManager

        spark_op_cfg = cfg.platform.compute.spark.operator
        operator = SparkOperatorManager(
            namespace=spark_op_cfg.namespace,
            version=spark_op_cfg.version,
            job_namespace=cfg.get_namespace(),
        )
        status = operator.check_status()

        if status.ready:
            version_info = f" v{status.version}" if status.version else ""
            _check_ok(f"Ready in '{status.namespace}'{version_info}")

            # Check namespace watching
            if status.watching_namespace is False:
                existing = status.watched_namespaces or []
                new_list = ",".join(existing + [cfg.get_namespace()])
                fix_cmd = (
                    f"helm upgrade {operator.HELM_RELEASE_NAME} "
                    f"{operator.HELM_CHART_NAME} "
                    f"-n {spark_op_cfg.namespace} --reuse-values "
                    f"--set 'spark.jobNamespaces={{{new_list}}}'"
                )
                if spark_op_cfg.install:
                    _check_warn(
                        f"Does not watch namespace '{cfg.get_namespace()}'",
                        hint=f"Currently watching: {existing}\n"
                        f"Will be added automatically during deploy (install: true)",
                    )
                else:
                    _check_fail(
                        f"Does not watch namespace '{cfg.get_namespace()}'",
                        hint=f"Currently watching: {existing}\n"
                        f"SparkApplications will hang. Fix with:\n  {fix_cmd}",
                    )
            elif status.watching_namespace is None:
                _check_ok(
                    "Namespace watching unverified (helm values unavailable)",
                )
        elif status.installed:
            if spark_op_cfg.install:
                _check_warn(
                    f"Installed but not ready: {status.message}",
                    hint="Operator will be repaired during deploy",
                )
            else:
                _check_warn(f"Installed but not ready: {status.message}")
        else:
            if spark_op_cfg.install:
                _check_warn(
                    "Not installed",
                    hint="Will be auto-installed during deploy (install: true)",
                )
            else:
                ns = cfg.get_namespace()
                _check_fail(
                    "Not installed",
                    hint="Option 1: Set platform.compute.spark.operator.install: true\n"
                    "Option 2: Install manually:\n"
                    f"  helm repo add spark-operator https://kubeflow.github.io/spark-operator\n"
                    f"  helm install spark-operator spark-operator/spark-operator \\\n"
                    f"    --namespace spark-operator --create-namespace \\\n"
                    f"    --set 'spark.jobNamespaces={{{ns}}}' \\\n"
                    f"    --set webhook.enable=true",
                )
    except Exception as e:
        _check_warn(f"Could not check status: {e}")
    p, f, w = _section_end()
    checks_passed += p
    checks_failed += f
    checks_warned += w

    # 8. Compute adequacy
    _section_start("Compute")
    try:
        from lakebench.config.scale import compute_guidance as _cg

        scale = cfg.architecture.workload.datagen.get_effective_scale()
        dims = cfg.get_scale_dimensions()
        guidance = _cg(scale)

        actual_executors = cfg.platform.compute.spark.executor.instances
        actual_memory = cfg.platform.compute.spark.executor.memory
        actual_mem_bytes = parse_spark_memory(actual_memory)
        rec_mem_bytes = parse_spark_memory(guidance.recommended_memory)
        min_mem_bytes = parse_spark_memory(guidance.min_memory)

        # Executors
        if actual_executors >= guidance.recommended_executors:
            _check_ok(
                f"Executors: {actual_executors} "
                f"(rec {guidance.recommended_executors} for scale {scale})"
            )
        elif actual_executors >= guidance.min_executors:
            _check_warn(
                f"Executors: {actual_executors} "
                f"(min {guidance.min_executors}, rec {guidance.recommended_executors} "
                f"for scale {scale})"
            )
        else:
            _check_fail(
                f"Executors: {actual_executors} below minimum "
                f"{guidance.min_executors} for scale {scale}"
            )

        # Memory
        if actual_mem_bytes >= rec_mem_bytes:
            _check_ok(
                f"Memory: {actual_memory} (rec {guidance.recommended_memory} for scale {scale})"
            )
        elif actual_mem_bytes >= min_mem_bytes:
            _check_warn(
                f"Memory: {actual_memory} "
                f"(min {guidance.min_memory}, rec {guidance.recommended_memory} "
                f"for scale {scale})"
            )
        else:
            _check_fail(
                f"Memory: {actual_memory} below minimum {guidance.min_memory} for scale {scale}"
            )

        _check_ok(f"Scale {scale}: {dims.customers:,} customers, {dims.approx_rows:,} rows")

        if guidance.warning:
            _check_warn(guidance.warning)

    except Exception as e:
        _check_warn(f"Could not validate compute adequacy: {e}")
    p, f, w = _section_end()
    checks_passed += p
    checks_failed += f
    checks_warned += w

    # Summary
    console.print()
    if checks_failed == 0:
        if checks_warned > 0:
            warn_s = "s" if checks_warned > 1 else ""
            _journal_safe(
                j.end_command,
                success=True,
                message=f"{checks_passed} passed, {checks_warned} warning{warn_s}",
            )
            console.print(
                Panel(
                    f"[green]{checks_passed} passed[/green], "
                    f"[yellow]{checks_warned} warning{warn_s}[/yellow]\n"
                    f"Run [bold]lakebench deploy[/bold] to deploy",
                    title="Validation Passed",
                    expand=False,
                )
            )
        else:
            _journal_safe(j.end_command, success=True, message=f"All {checks_passed} checks passed")
            console.print(
                Panel(
                    f"[green]All {checks_passed} checks passed[/green]\n"
                    f"Run [bold]lakebench deploy[/bold] to deploy",
                    title="Validation Successful",
                    expand=False,
                )
            )
    else:
        _journal_safe(
            j.end_command, success=False, message=f"{checks_passed} passed, {checks_failed} failed"
        )
        console.print(
            Panel(
                f"[green]{checks_passed} passed[/green], [red]{checks_failed} failed[/red]\n"
                f"Fix the issues above before deploying",
                title="Validation Failed",
                expand=False,
            )
        )
        raise typer.Exit(1)


@app.command()
def status(
    config_file: Annotated[
        Path | None,
        typer.Argument(
            help="Path to configuration YAML file (optional)",
        ),
    ] = None,
    file_option: Annotated[
        Path | None,
        typer.Option(
            "--file",
            "-f",
            help="Path to configuration YAML file (alternative to positional argument)",
        ),
    ] = None,
    namespace: Annotated[
        str | None,
        typer.Option(
            "--namespace",
            "-n",
            help="Kubernetes namespace to check",
        ),
    ] = None,
) -> None:
    """Show deployment status.

    Shows the current status of Lakebench components in the cluster.
    """
    # Determine namespace
    ns = namespace
    if not ns:
        config_file = resolve_config_path(config_file, file_option)
    if config_file:
        try:
            cfg = load_config(config_file)
            ns = ns or cfg.get_namespace()
        except ConfigError as e:
            print_error(f"Config error: {e}")
            raise typer.Exit(1)  # noqa: B904

    if not ns:
        print_error("Specify --namespace or provide a config file")
        raise typer.Exit(1)

    console.print(Panel(f"Status for namespace: [bold]{ns}[/bold]", expand=False))

    try:
        k8s = get_k8s_client(namespace=ns)

        # Check if namespace exists
        if not k8s.namespace_exists(ns):
            print_warning(f"Namespace '{ns}' does not exist")
            print_info("Run 'lakebench deploy' to create the deployment")
            return

        # Check components
        from kubernetes import client as k8s_client

        apps_v1 = k8s_client.AppsV1Api()

        table = Table(title="Components")
        table.add_column("Component", style="cyan")
        table.add_column("Type", style="dim")
        table.add_column("Status", style="bold")
        table.add_column("Ready", justify="center")

        # Build component list -- config-aware when a config file was loaded
        if config_file:
            components: list[tuple[str, str]] = [("lakebench-postgres", "StatefulSet")]
            cat = cfg.architecture.catalog.type.value
            if cat == "hive":
                components.append(("lakebench-hive-metastore-default", "StatefulSet"))
            elif cat == "polaris":
                components.append(("lakebench-polaris", "Deployment"))
            engine = cfg.architecture.query_engine.type.value
            if engine == "trino":
                components.append(("lakebench-trino-coordinator", "Deployment"))
                components.append(("lakebench-trino-worker", "StatefulSet"))
            elif engine == "spark-thrift":
                components.append(("lakebench-spark-thrift", "Deployment"))
            elif engine == "duckdb":
                components.append(("lakebench-duckdb", "Deployment"))
            if cfg.observability.enabled:
                components.append(
                    ("prometheus-lakebench-observability-ku-prometheus", "StatefulSet")
                )
                components.append(("lakebench-observability-grafana", "Deployment"))
        else:
            # Namespace-only mode (no config loaded) -- show all possible components
            components = [
                ("lakebench-postgres", "StatefulSet"),
                ("lakebench-hive-metastore-default", "StatefulSet"),
                ("lakebench-polaris", "Deployment"),
                ("lakebench-trino-coordinator", "Deployment"),
                ("lakebench-trino-worker", "StatefulSet"),
                ("lakebench-spark-thrift", "Deployment"),
                ("lakebench-duckdb", "Deployment"),
                ("prometheus-lakebench-observability-ku-prometheus", "StatefulSet"),
                ("lakebench-observability-grafana", "Deployment"),
            ]

        for name, kind in components:
            try:
                if kind == "StatefulSet":
                    sts = apps_v1.read_namespaced_stateful_set(name, ns)
                    ready = sts.status.ready_replicas or 0
                    desired = sts.spec.replicas or 1
                    status_str = f"{ready}/{desired} replicas"
                    ready_str = "[green]OK[/green]" if ready >= desired else "[yellow]--[/yellow]"
                else:
                    dep = apps_v1.read_namespaced_deployment(name, ns)
                    ready = dep.status.ready_replicas or 0
                    desired = dep.spec.replicas or 1
                    status_str = f"{ready}/{desired} replicas"
                    ready_str = "[green]OK[/green]" if ready >= desired else "[yellow]--[/yellow]"

                table.add_row(name, kind, status_str, ready_str)
            except k8s_client.rest.ApiException as e:
                if e.status == 404:
                    table.add_row(name, kind, "Not found", "[dim]-[/dim]")
                else:
                    table.add_row(name, kind, f"Error: {e.reason}", "[red]ERROR[/red]")

        console.print(table)

        # Check for datagen job status
        try:
            batch_v1 = k8s_client.BatchV1Api()
            job = batch_v1.read_namespaced_job("lakebench-datagen", ns)
            active = job.status.active or 0
            succeeded = job.status.succeeded or 0
            completions = job.spec.completions or 1
            if active > 0 or succeeded < completions:
                console.print()
                console.print(
                    f"[bold]Datagen:[/bold] {succeeded}/{completions} pods completed, "
                    f"{active} active"
                )
        except k8s_client.rest.ApiException as e:
            if e.status != 404:
                logger.debug("Could not check datagen job: %s", e)

    except K8sConnectionError as e:
        print_error(f"Kubernetes connection failed: {e}")
        raise typer.Exit(1)  # noqa: B904


@app.command()
def deploy(
    config_file: Annotated[
        Path | None,
        typer.Argument(
            help="Path to configuration YAML file (default: ./lakebench.yaml)",
        ),
    ] = None,
    file_option: Annotated[
        Path | None,
        typer.Option(
            "--file",
            "-f",
            help="Path to configuration YAML file (alternative to positional argument)",
        ),
    ] = None,
    dry_run: Annotated[
        bool,
        typer.Option(
            "--dry-run",
            help="Show what would be deployed without making changes",
        ),
    ] = False,
    include_observability: Annotated[
        bool,
        typer.Option(
            "--include-observability",
            help="Deploy Prometheus and Grafana monitoring stack",
        ),
    ] = False,
    yes: Annotated[
        bool,
        typer.Option(
            "--yes",
            "-y",
            help="Skip confirmation prompt",
        ),
    ] = False,
) -> None:
    """Deploy lakehouse infrastructure.

    Deploys all components in the correct order:
    1. Namespace + Secrets + Scratch StorageClass
    2. PostgreSQL
    3. Catalog (Hive Metastore or Polaris)
    4. Spark RBAC
    5. Spark Operator (if operator.install: true)
    6. Query Engine (Trino / Spark Thrift / DuckDB)
    7. Observability (if enabled)
    """
    from lakebench.deploy import DeploymentEngine, DeploymentStatus

    config_file = resolve_config_path(config_file, file_option)

    # Load configuration
    try:
        cfg = load_config(config_file)
    except ConfigFileNotFoundError as e:
        print_error(f"File not found: {e}")
        raise typer.Exit(1)  # noqa: B904
    except ConfigValidationError as e:
        print_error("Config validation failed:")
        for err in e.errors:
            loc = ".".join(str(x) for x in err["loc"])
            console.print(f"  [red]*[/red] {loc}: {err['msg']}")
        raise typer.Exit(1)  # noqa: B904
    except ConfigError as e:
        print_error(f"Config error: {e}")
        raise typer.Exit(1)  # noqa: B904

    # Enable observability if flag is set
    if include_observability:
        cfg.observability.enabled = True

    namespace = cfg.get_namespace()

    # Pre-flight validation (BUG-012)
    if not dry_run:
        _preflight_check(cfg)

    # Confirmation prompt (mirrors destroy command pattern)
    if not yes and not dry_run:
        components = _build_component_list(cfg)
        console.print(
            Panel(
                f"Deploying to namespace [bold]{namespace}[/bold]\n\nComponents: {components}",
                title="Confirm Deployment",
                expand=False,
            )
        )
        typer.confirm("Proceed with deployment?", abort=True)

    # Display deployment info
    components = _build_component_list(cfg)
    header = f"[bold]{cfg.name}[/bold]  ·  namespace: [bold]{namespace}[/bold]"
    if dry_run:
        header = f"[yellow]DRY RUN[/yellow]  ·  {header}"
    console.print(
        Panel(
            f"{header}\nConfig: {config_file.resolve()}\nComponents: {components}",
            title="Deploy",
            expand=False,
        )
    )
    console.print()

    # Journal
    j = journal_open(config_file, config_name=cfg.name)
    j.begin_command(CommandName.DEPLOY, {"dry_run": dry_run})

    # Deploy
    deploy_start = time.time()
    try:
        engine = DeploymentEngine(cfg, dry_run=dry_run)

        # Progress callback -- columnar output with version info
        _step_start: dict[str, float] = {}

        def _fmt_deploy_line(icon: str, color: str, elapsed: float) -> str:
            """Format a deploy progress line from the latest engine result."""
            r = engine.results[-1] if engine.results else None
            if r and r.label:
                return (
                    f"  [{color}]{icon}[/{color}] {r.label:<22} "
                    f"{r.detail:<30} [dim]{elapsed:>6.1f}s[/dim]"
                )
            # Fallback for results without label/detail
            return f"  [{color}]{icon}[/{color}] {r.message if r else '':<54} [dim]{elapsed:>6.1f}s[/dim]"

        def on_progress(component: str, status: DeploymentStatus, message: str) -> None:
            if status == DeploymentStatus.IN_PROGRESS:
                _step_start[component] = time.time()
            elif status == DeploymentStatus.SKIPPED:
                _step_start.pop(component, None)
            elif status == DeploymentStatus.SUCCESS:
                elapsed = time.time() - _step_start.pop(component, time.time())
                console.print(_fmt_deploy_line("+", "green", elapsed))
            elif status == DeploymentStatus.FAILED:
                elapsed = time.time() - _step_start.pop(component, time.time())
                console.print(_fmt_deploy_line("x", "red", elapsed))

        results = engine.deploy_all(progress_callback=on_progress)

        # Record each component result in journal
        for r in results:
            _journal_safe(
                j.record,
                EventType.DEPLOY_COMPONENT,
                message=r.message,
                success=r.status == DeploymentStatus.SUCCESS,
                details={
                    "component": r.component,
                    "status": r.status.value,
                    "elapsed_seconds": r.elapsed_seconds,
                },
            )
    except K8sConnectionError as e:
        print_error(f"Kubernetes connection failed: {e}")
        _journal_safe(j.end_command, success=False, message=str(e))
        raise typer.Exit(1)  # noqa: B904

    # Summary
    console.print()
    passed = sum(1 for r in results if r.status == DeploymentStatus.SUCCESS)
    failed = sum(1 for r in results if r.status == DeploymentStatus.FAILED)
    skipped = sum(1 for r in results if r.status == DeploymentStatus.SKIPPED)

    _journal_safe(
        j.record,
        EventType.DEPLOY_COMPLETE,
        message=f"{passed} succeeded, {failed} failed",
        success=failed == 0,
        details={
            "components_succeeded": passed,
            "components_failed": failed,
            "components_skipped": skipped,
            "dry_run": dry_run,
        },
    )
    _journal_safe(j.end_command, success=failed == 0)

    deploy_elapsed = int(time.time() - deploy_start)

    if failed == 0:
        # Build success message
        success_msg = f"[green]{passed} components deployed in {deploy_elapsed}s[/green]"

        # Add monitoring access info if observability was deployed
        obs_result = next(
            (
                r
                for r in results
                if r.component == "observability" and r.status == DeploymentStatus.SUCCESS
            ),
            None,
        )
        if obs_result and obs_result.details:
            namespace = cfg.get_namespace()
            success_msg += (
                f"\n\n[bold]Monitoring (in-cluster):[/bold]"
                f"\n  Grafana:    http://lakebench-grafana.{namespace}.svc:3000 (admin / lakebench)"
                f"\n  Prometheus: http://lakebench-prometheus.{namespace}.svc:9090"
                f"\n\n[bold]Local access via port-forward:[/bold]"
                f"\n  [cyan]kubectl port-forward svc/lakebench-grafana 3000:3000 -n {namespace}[/cyan]"
                f"\n  [cyan]kubectl port-forward svc/lakebench-prometheus 9090:9090 -n {namespace}[/cyan]"
            )

        success_msg += (
            "\n\nNext: [bold]lakebench generate[/bold]      to create test data"
            "\n      [bold]lakebench run --generate[/bold]  to generate data and run the pipeline"
            "\n      [bold]lakebench status[/bold]          to check deployment"
        )

        console.print(
            Panel(
                success_msg,
                title="Deployment Successful",
                expand=False,
            )
        )
    else:
        failed_component = next((r for r in results if r.status == DeploymentStatus.FAILED), None)
        guidance = "Check the errors above, then re-run 'lakebench deploy'."
        if failed_component:
            guidance = (
                f"Failed at: {failed_component.component}\n"
                "Fix the issue above, then re-run 'lakebench deploy'.\n"
                "Successful steps will be skipped on retry."
            )
        console.print(
            Panel(
                f"[red]{failed} failed[/red], {passed} succeeded" + f"\n\n{guidance}",
                title="Deployment Failed",
                expand=False,
            )
        )
        raise typer.Exit(1)


@app.command()
def destroy(
    config_file: Annotated[
        Path | None,
        typer.Argument(
            help="Path to configuration YAML file (default: ./lakebench.yaml)",
        ),
    ] = None,
    file_option: Annotated[
        Path | None,
        typer.Option(
            "--file",
            help="Path to configuration YAML file (alternative to positional argument)",
        ),
    ] = None,
    force: Annotated[
        bool,
        typer.Option(
            "--force",
            "-f",
            help="Skip confirmation prompt",
        ),
    ] = False,
) -> None:
    """Tear down lakehouse infrastructure.

    Removes all Lakebench resources from the cluster.
    """
    from lakebench.deploy import DeploymentEngine, DeploymentStatus

    config_file = resolve_config_path(config_file, file_option)

    # Load configuration
    try:
        cfg = load_config(config_file)
    except ConfigFileNotFoundError as e:
        print_error(f"File not found: {e}")
        raise typer.Exit(1)  # noqa: B904
    except ConfigValidationError as e:
        print_error("Config validation failed:")
        for err in e.errors:
            loc = ".".join(str(x) for x in err["loc"])
            console.print(f"  [red]*[/red] {loc}: {err['msg']}")
        raise typer.Exit(1)  # noqa: B904
    except ConfigError as e:
        print_error(f"Config error: {e}")
        raise typer.Exit(1)  # noqa: B904

    namespace = cfg.get_namespace()

    # Confirmation
    if not force:
        console.print(
            Panel(
                f"[red]WARNING[/red]: This will destroy all Lakebench resources in namespace [bold]{namespace}[/bold]\n\n"
                f"This includes:\n{_build_destroy_list(cfg)}",
                title="Confirm Destruction",
                expand=False,
            )
        )
        confirm = typer.confirm("Are you sure you want to proceed?")
        if not confirm:
            print_info("Destruction cancelled")
            raise typer.Exit(0)

    console.print(
        Panel(
            f"[bold]{cfg.name}[/bold]  ·  namespace: [bold]{namespace}[/bold]",
            title="Destroy",
            expand=False,
        )
    )
    console.print()

    # Journal
    j = journal_open(config_file, config_name=cfg.name)
    j.begin_command(CommandName.DESTROY, {"force": force})

    # Progress callback -- phase headers with timed sub-steps
    _destroy_groups = {
        "spark-jobs": "Cleaning up jobs and pods",
        "spark-pods": "Cleaning up jobs and pods",
        "datagen-jobs": "Cleaning up jobs and pods",
        "iceberg-tables": "Cleaning data",
        "s3-buckets": "Cleaning data",
        "observability": "Removing infrastructure",
        "trino": "Removing infrastructure",
        "spark-thrift": "Removing infrastructure",
        "duckdb": "Removing infrastructure",
        "hive": "Removing infrastructure",
        "polaris": "Removing infrastructure",
        "postgres": "Removing infrastructure",
        "rbac": "Removing infrastructure",
        "scratch-sc": "Removing infrastructure",
        "namespace": "Removing namespace",
    }
    _dg_current_group = ""
    _dg_step_start: dict[str, float] = {}

    def on_progress(component: str, status: DeploymentStatus, message: str) -> None:
        nonlocal _dg_current_group
        group = _destroy_groups.get(component, component)

        if status == DeploymentStatus.IN_PROGRESS:
            if group != _dg_current_group:
                _dg_current_group = group
                console.print(f"  [dim]{group}[/dim]")
            _dg_step_start[component] = time.time()
        elif status == DeploymentStatus.SKIPPED:
            _dg_step_start.pop(component, None)
        elif status == DeploymentStatus.SUCCESS:
            elapsed = time.time() - _dg_step_start.pop(component, time.time())
            console.print(f"    [green]+[/green] {message:<56} [dim]{elapsed:>6.1f}s[/dim]")
            _journal_safe(
                j.record,
                EventType.DESTROY_COMPONENT,
                message=message,
                success=True,
                details={"component": component, "status": "success"},
            )
        elif status == DeploymentStatus.FAILED:
            elapsed = time.time() - _dg_step_start.pop(component, time.time())
            console.print(f"    [red]x[/red] {message:<56} [dim]{elapsed:>6.1f}s[/dim]")
            _journal_safe(
                j.record,
                EventType.DESTROY_COMPONENT,
                message=message,
                success=False,
                details={"component": component, "status": "failed"},
            )

    # Destroy
    destroy_start = time.time()
    try:
        engine = DeploymentEngine(cfg)
        results = engine.destroy_all(progress_callback=on_progress)
    except K8sConnectionError as e:
        print_error(f"Kubernetes connection failed: {e}")
        _journal_safe(j.end_command, success=False, message=str(e))
        raise typer.Exit(1)  # noqa: B904

    # Summary
    destroy_elapsed = int(time.time() - destroy_start)
    console.print()
    passed = sum(1 for r in results if r.status == DeploymentStatus.SUCCESS)
    failed = sum(1 for r in results if r.status == DeploymentStatus.FAILED)

    _journal_safe(
        j.record,
        EventType.DESTROY_COMPLETE,
        message=f"{passed} destroyed, {failed} failed",
        success=failed == 0,
        details={"components_destroyed": passed, "components_failed": failed},
    )
    _journal_safe(j.end_command, success=failed == 0)
    _journal_safe(j.close_session)

    if failed == 0:
        console.print(
            Panel(
                f"[green]{passed} components removed in {destroy_elapsed}s[/green]"
                f"\n\nTo re-deploy: [bold]lakebench deploy[/bold]",
                title="Destroy Complete",
                expand=False,
            )
        )
    else:
        console.print(
            Panel(
                f"[red]{failed} failed[/red], {passed} succeeded\n\n"
                f"Some resources may need manual cleanup",
                title="Destroy Incomplete",
                expand=False,
            )
        )
        raise typer.Exit(1)


# Valid clean targets
CLEAN_TARGETS = ["bronze", "silver", "gold", "data", "metrics", "journal"]


@app.command()
def clean(
    target: Annotated[
        str,
        typer.Argument(
            help=f"What to clean: {', '.join(CLEAN_TARGETS)}",
        ),
    ],
    config_file: Annotated[
        Path | None,
        typer.Argument(
            help="Path to configuration YAML file (default: ./lakebench.yaml)",
        ),
    ] = None,
    file_option: Annotated[
        Path | None,
        typer.Option(
            "--file",
            help="Path to configuration YAML file (alternative to positional argument)",
        ),
    ] = None,
    force: Annotated[
        bool,
        typer.Option(
            "--force",
            "-f",
            help="Skip confirmation prompt",
        ),
    ] = False,
    metrics_dir: Annotated[
        Path,
        typer.Option(
            "--metrics-dir",
            "-m",
            help="Metrics/runs directory (for 'metrics' target)",
        ),
    ] = Path(DEFAULT_OUTPUT_DIR) / "runs",
) -> None:
    """Delete data without destroying infrastructure.

    Granular data cleanup for re-running pipeline stages.

    Targets:
      bronze  - Empty the bronze S3 bucket
      silver  - Empty the silver S3 bucket
      gold    - Empty the gold S3 bucket
      data    - Empty all three buckets (bronze + silver + gold)
      metrics - Delete local metrics/runs directory
      journal - Delete all journal session files
    """
    target = target.lower().strip()
    if target not in CLEAN_TARGETS:
        print_error(f"Invalid target: '{target}'. Must be one of: {', '.join(CLEAN_TARGETS)}")
        raise typer.Exit(1)

    config_file = resolve_config_path(config_file, file_option)

    # Load configuration
    try:
        cfg = load_config(config_file)
    except ConfigFileNotFoundError as e:
        print_error(f"File not found: {e}")
        raise typer.Exit(1)  # noqa: B904
    except ConfigValidationError as e:
        print_error("Config validation failed:")
        for err in e.errors:
            loc = ".".join(str(x) for x in err["loc"])
            console.print(f"  [red]*[/red] {loc}: {err['msg']}")
        raise typer.Exit(1)  # noqa: B904
    except ConfigError as e:
        print_error(f"Config error: {e}")
        raise typer.Exit(1)  # noqa: B904

    s3_cfg = cfg.platform.storage.s3

    # Determine which buckets to clean
    if target == "data":
        bucket_targets = {
            "bronze": s3_cfg.buckets.bronze,
            "silver": s3_cfg.buckets.silver,
            "gold": s3_cfg.buckets.gold,
        }
    elif target in ("metrics", "journal"):
        bucket_targets = {}
    else:
        bucket_targets = {target: getattr(s3_cfg.buckets, target)}

    # Build description of what will be cleaned
    descriptions = []
    if bucket_targets:
        for layer, bucket in bucket_targets.items():
            descriptions.append(f"  - {layer}: s3://{bucket}/ (all objects)")
    if target == "metrics":
        descriptions.append(f"  - metrics: {metrics_dir}/ (all files)")
    if target == "journal":
        descriptions.append(f"  - journal: {DEFAULT_JOURNAL_DIR}/ (all session files)")

    # Confirmation
    if not force:
        console.print(
            Panel(
                "[yellow]WARNING[/yellow]: This will delete the following data:\n\n"
                + "\n".join(descriptions)
                + "\n\n"
                "Infrastructure (K8s, catalog) will NOT be affected.",
                title="Confirm Clean",
                expand=False,
            )
        )
        confirm = typer.confirm("Are you sure you want to proceed?")
        if not confirm:
            print_info("Clean cancelled")
            raise typer.Exit(0)

    console.print(Panel(f"Cleaning: [bold]{target}[/bold]", expand=False))

    # Journal
    j = journal_open(config_file, config_name=cfg.name)
    j.begin_command(CommandName.CLEAN, {"target": target})

    total_deleted = 0
    errors = []

    # Check for active datagen before cleaning S3 buckets
    if bucket_targets:
        try:
            from kubernetes import client as k8s_client

            ns = cfg.get_namespace()
            batch_v1 = k8s_client.BatchV1Api()
            job = batch_v1.read_namespaced_job("lakebench-datagen", ns)
            active_pods = job.status.active or 0
            if active_pods > 0:
                print_warning(f"Datagen job has {active_pods} active pod(s)")
                if not force:
                    typer.confirm("Data generation is running. Clean anyway?", abort=True)
        except Exception:
            pass  # No datagen job or K8s unavailable -- safe to proceed

    # Clean S3 buckets
    if bucket_targets:
        try:
            from lakebench.s3 import S3Client

            s3 = S3Client(
                endpoint=s3_cfg.endpoint,
                access_key=s3_cfg.access_key,
                secret_key=s3_cfg.secret_key,
                region=s3_cfg.region,
                path_style=s3_cfg.path_style,
                ca_cert=s3_cfg.ca_cert,
                verify_ssl=s3_cfg.verify_ssl,
            )

            def _clean_progress(bkt: str, count: int) -> None:
                console.print(f"  Deleting from s3://{bkt}/... ({count:,} objects so far)")

            for layer, bucket in bucket_targets.items():
                try:
                    deleted = s3.empty_bucket(bucket, progress_callback=_clean_progress)
                    total_deleted += deleted
                    if deleted > 0:
                        print_success(
                            f"Cleaned {layer}: {deleted:,} objects deleted from s3://{bucket}/"
                        )
                    else:
                        print_info(f"Cleaned {layer}: bucket s3://{bucket}/ already empty")
                except Exception as e:
                    errors.append(f"{layer}: {e}")
                    print_error(f"Failed to clean {layer}: {e}")

        except Exception as e:
            errors.append(f"S3 connection: {e}")
            print_error(f"S3 connection failed: {e}")

    # Clean metrics directory
    if target == "metrics":
        import shutil

        if metrics_dir.exists():
            file_count = sum(1 for _ in metrics_dir.rglob("*") if _.is_file())
            shutil.rmtree(metrics_dir)
            total_deleted += file_count
            print_success(f"Cleaned metrics: {file_count} files deleted from {metrics_dir}/")
        else:
            print_info(f"Metrics directory {metrics_dir}/ does not exist")

    # Clean journal files
    if target == "journal":
        journal_path = Path(DEFAULT_JOURNAL_DIR)
        if journal_path.exists():
            purge_journal = Journal(journal_dir=journal_path)
            deleted = purge_journal.purge()
            total_deleted += deleted
            if deleted > 0:
                print_success(
                    f"Cleaned journal: {deleted} session files deleted from {journal_path}/"
                )
            else:
                print_info(f"Journal directory {journal_path}/ has no session files")
        else:
            print_info(f"Journal directory {journal_path}/ does not exist")

    # Journal recording
    _journal_safe(
        j.record,
        EventType.CLEAN_TARGET,
        message=f"Cleaned {target}: {total_deleted:,} objects",
        success=len(errors) == 0,
        details={
            "target": target,
            "objects_deleted": total_deleted,
            "buckets": list(bucket_targets.keys()) if bucket_targets else [],
        },
    )
    _journal_safe(j.end_command, success=len(errors) == 0)
    if target == "data":
        _journal_safe(j.close_session)

    # Summary
    console.print()
    if not errors:
        console.print(
            Panel(
                f"[green]Clean complete[/green]: {total_deleted:,} objects deleted",
                title="Clean Complete",
                expand=False,
            )
        )
    else:
        console.print(
            Panel(
                f"[red]{len(errors)} error(s)[/red] during clean\n\n"
                + "\n".join(f"  - {e}" for e in errors),
                title="Clean Incomplete",
                expand=False,
            )
        )
        raise typer.Exit(1)


@app.command()
def generate(
    config_file: Annotated[
        Path | None,
        typer.Argument(
            help="Path to configuration YAML file (default: ./lakebench.yaml)",
        ),
    ] = None,
    file_option: Annotated[
        Path | None,
        typer.Option(
            "--file",
            "-f",
            help="Path to configuration YAML file (alternative to positional argument)",
        ),
    ] = None,
    wait: Annotated[
        bool,
        typer.Option(
            "--wait",
            "-w",
            help="Wait for data generation to complete",
        ),
    ] = True,
    timeout: Annotated[
        int,
        typer.Option(
            "--timeout",
            "-t",
            help="Timeout in seconds when waiting for completion",
        ),
    ] = 7200,
    resume: Annotated[
        bool,
        typer.Option(
            "--resume",
            help="Resume from checkpoint if previous generation was interrupted",
        ),
    ] = False,
    yes: Annotated[
        bool,
        typer.Option(
            "--yes",
            "-y",
            help="Skip confirmation prompt",
        ),
    ] = False,
) -> None:
    """Generate synthetic data to bronze bucket.

    Runs the datagen job to populate the bronze bucket with synthetic data.
    Uses parallel Kubernetes Jobs for efficient generation.

    Use --resume to continue from a previous interrupted generation.
    """
    from lakebench.deploy import DatagenDeployer, DeploymentEngine, DeploymentStatus

    config_file = resolve_config_path(config_file, file_option)

    # Load configuration
    try:
        cfg = load_config(config_file)
    except ConfigFileNotFoundError as e:
        print_error(f"File not found: {e}")
        raise typer.Exit(1)  # noqa: B904
    except ConfigValidationError as e:
        print_error("Config validation failed:")
        for err in e.errors:
            loc = ".".join(str(x) for x in err["loc"])
            console.print(f"  [red]*[/red] {loc}: {err['msg']}")
        raise typer.Exit(1)  # noqa: B904
    except ConfigError as e:
        print_error(f"Config error: {e}")
        raise typer.Exit(1)  # noqa: B904

    # Auto-size resources based on scale + cluster capacity
    from lakebench.config.autosizer import resolve_auto_sizing

    try:
        k8s_for_cap = get_k8s_client(
            context=cfg.platform.kubernetes.context,
            namespace=cfg.get_namespace(),
        )
        cluster_cap = k8s_for_cap.get_cluster_capacity()
    except Exception as e:
        logger.warning("Could not get cluster capacity for auto-sizing: %s", e)
        cluster_cap = None
    resolve_auto_sizing(cfg, cluster_cap)

    workload = cfg.architecture.workload
    datagen_cfg = workload.datagen
    dims = cfg.get_scale_dimensions()
    console.print(
        Panel(
            f"Generating data for: [bold]{cfg.name}[/bold]\n\n"
            f"Scale: {dims.scale}\n"
            f"Customers: {dims.customers:,}\n"
            f"Parallelism: {datagen_cfg.parallelism} pods\n"
            f"Bucket: {cfg.platform.storage.s3.buckets.bronze}",
            expand=False,
        )
    )

    if not yes:
        typer.confirm("Start data generation?", default=True, abort=True)

    # Journal
    j = journal_open(config_file, config_name=cfg.name)
    j.begin_command(
        CommandName.GENERATE,
        {
            "wait": wait,
            "timeout": timeout,
            "resume": resume,
        },
    )

    try:
        engine = DeploymentEngine(cfg)
        datagen = DatagenDeployer(engine)

        # Submit job
        if resume:
            print_info("Submitting datagen job with checkpoint resume...")
        else:
            print_info("Submitting datagen job...")
        result = datagen.deploy(resume=resume)

        if result.status != DeploymentStatus.SUCCESS:
            print_error(f"Failed to submit job: {result.message}")
            _journal_safe(j.end_command, success=False, message=result.message)
            raise typer.Exit(1)

        print_success("Datagen job submitted")
        console.print(f"  Parallelism: {result.details.get('parallelism', '?')} pods")
        target_tb = float(result.details.get("target_tb", 0))
        console.print(f"  Target: {target_tb * 1024:.0f} GB")

        _journal_safe(
            j.record,
            EventType.GENERATE_START,
            message="Data generation started",
            details={
                "scale": dims.scale,
                "parallelism": datagen_cfg.parallelism,
                "target_gb": round(dims.approx_bronze_gb, 1),
                "bucket": cfg.platform.storage.s3.buckets.bronze,
            },
        )

        if not wait:
            print_info("Use 'lakebench status' to check progress")
            _journal_safe(j.end_command, success=True, message="Job submitted (no-wait)")
            return

        # Wait for completion with progress bar
        import time

        from rich.progress import (
            BarColumn,
            Progress,
            SpinnerColumn,
            TextColumn,
            TimeElapsedColumn,
            TimeRemainingColumn,
        )

        start = time.time()

        # Get initial progress to determine total completions
        initial_progress = datagen.get_progress()
        total_completions = initial_progress.get("completions", 1)

        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            BarColumn(),
            TextColumn("{task.completed}/{task.total} pods"),
            TimeElapsedColumn(),
            TimeRemainingColumn(),
            console=console,
        ) as progress_bar:
            task = progress_bar.add_task("Generating data", total=total_completions)

            while time.time() - start < timeout:
                prog = datagen.get_progress()

                if not prog.get("running", False):
                    if prog.get("error"):
                        progress_bar.stop()
                        print_error(prog["error"])
                        raise typer.Exit(1)
                    # Mark complete
                    progress_bar.update(task, completed=total_completions)
                    break

                # Surface pod failures early
                if prog.get("oom_pods"):
                    progress_bar.stop()
                    print_error(f"OOMKilled: {', '.join(prog['oom_pods'])}")
                    print_info("Increase datagen memory or reduce parallelism")
                    _journal_safe(j.end_command, success=False, message="OOMKilled pods detected")
                    raise typer.Exit(1)
                if prog.get("pending_pods"):
                    progress_bar.console.print(
                        f"  [yellow]{len(prog['pending_pods'])} pod(s) pending[/yellow]"
                    )

                succeeded = prog.get("succeeded", 0)
                progress_bar.update(task, completed=succeeded)

                time.sleep(30)

        # Final result
        completion_result = datagen.wait_for_completion(timeout_seconds=10)

        console.print()
        if completion_result.status == DeploymentStatus.SUCCESS:
            _journal_safe(
                j.record,
                EventType.GENERATE_COMPLETE,
                message="Data generation complete",
                success=True,
                details={
                    "succeeded_pods": completion_result.details.get("succeeded", 0),
                    "failed_pods": completion_result.details.get("failed", 0),
                    "elapsed_seconds": completion_result.elapsed_seconds,
                },
            )
            _journal_safe(j.end_command, success=True)

            console.print(
                Panel(
                    f"[green]Data generation complete![/green]\n\n"
                    f"Succeeded: {completion_result.details.get('succeeded', '?')} pods\n"
                    f"Elapsed: {completion_result.elapsed_seconds:.0f}s\n\n"
                    f"Data written to: s3://{cfg.platform.storage.s3.buckets.bronze}/{cfg.architecture.pipeline.medallion.bronze.path_template}"
                    f"\n\nNext: [bold]lakebench run[/bold]  to execute the pipeline",
                    title="Generation Complete",
                    expand=False,
                )
            )
        else:
            _journal_safe(
                j.record,
                EventType.GENERATE_COMPLETE,
                message=completion_result.message,
                success=False,
                details={
                    "succeeded_pods": completion_result.details.get("succeeded", 0),
                    "failed_pods": completion_result.details.get("failed", 0),
                    "elapsed_seconds": completion_result.elapsed_seconds,
                },
            )
            _journal_safe(j.end_command, success=False, message=completion_result.message)

            console.print(
                Panel(
                    f"[red]Data generation failed![/red]\n\n{completion_result.message}",
                    title="Generation Failed",
                    expand=False,
                )
            )
            raise typer.Exit(1)

    except K8sConnectionError as e:
        print_error(f"Kubernetes connection failed: {e}")
        _journal_safe(j.end_command, success=False, message=str(e))
        raise typer.Exit(1)  # noqa: B904


@app.command()
def run(
    config_file: Annotated[
        Path | None,
        typer.Argument(
            help="Path to configuration YAML file (default: ./lakebench.yaml)",
        ),
    ] = None,
    file_option: Annotated[
        Path | None,
        typer.Option(
            "--file",
            "-f",
            help="Path to configuration YAML file (alternative to positional argument)",
        ),
    ] = None,
    stage: Annotated[
        str | None,
        typer.Option(
            "--stage",
            "-s",
            help="Run specific stage only (bronze-verify, silver-build, gold-finalize)",
        ),
    ] = None,
    timeout: Annotated[
        int | None,
        typer.Option(
            "--timeout",
            "-t",
            help="Timeout per job in seconds (auto-scaled from data scale if omitted)",
        ),
    ] = None,
    skip_benchmark: Annotated[
        bool,
        typer.Option(
            "--skip-benchmark",
            help="Skip the query benchmark after pipeline completion",
        ),
    ] = False,
    sustained: Annotated[
        bool,
        typer.Option(
            "--sustained",
            help="Run in sustained streaming mode (bronze-ingest → silver-stream → gold-refresh)",
        ),
    ] = False,
    continuous: Annotated[
        bool,
        typer.Option(
            "--continuous",
            help="Deprecated alias for --sustained",
            hidden=True,
        ),
    ] = False,
    duration: Annotated[
        int | None,
        typer.Option(
            "--duration",
            help="Streaming run duration in seconds (default: from config, typically 1800)",
        ),
    ] = None,
    include_datagen: Annotated[
        bool,
        typer.Option(
            "--generate",
            help="Run datagen before pipeline stages (batch mode only; sustained always runs datagen)",
        ),
    ] = False,
) -> None:
    """Execute the data pipeline.

    Runs the medallion pipeline (bronze → silver → gold).
    Each stage is a separate Spark job submitted to the cluster.
    Metrics are automatically collected and saved for reporting.
    After gold finalize, runs a query benchmark (QpH).
    Use --skip-benchmark to skip the benchmark stage.

    With --generate (batch mode), generates data first, then runs the full
    pipeline. Sustained mode always runs datagen automatically.

    With --sustained, runs the streaming pipeline instead:
    starts datagen, then launches bronze-ingest, silver-stream,
    and gold-refresh as concurrent streaming jobs. Monitors for
    the configured duration, then stops streaming and runs benchmark.
    """
    import uuid

    from lakebench.metrics import JobMetrics, MetricsCollector, MetricsStorage
    from lakebench.spark import SparkJobManager, SparkJobMonitor, SparkOperatorManager
    from lakebench.spark.job import JobState, JobType, get_executor_count, get_job_profile

    config_file = resolve_config_path(config_file, file_option)

    # Load configuration
    try:
        cfg = load_config(config_file)
    except ConfigFileNotFoundError as e:
        print_error(f"File not found: {e}")
        raise typer.Exit(1)  # noqa: B904
    except ConfigValidationError as e:
        print_error("Config validation failed:")
        for err in e.errors:
            loc = ".".join(str(x) for x in err["loc"])
            console.print(f"  [red]*[/red] {loc}: {err['msg']}")
        raise typer.Exit(1)  # noqa: B904
    except ConfigError as e:
        print_error(f"Config error: {e}")
        raise typer.Exit(1)  # noqa: B904

    # Auto-size resources based on scale + cluster capacity
    from lakebench.config.autosizer import resolve_auto_sizing

    try:
        k8s_for_cap = get_k8s_client(
            context=cfg.platform.kubernetes.context,
            namespace=cfg.get_namespace(),
        )
        cluster_cap = k8s_for_cap.get_cluster_capacity()
    except Exception as e:
        logger.warning("Could not get cluster capacity for auto-sizing: %s", e)
        cluster_cap = None
    resolve_auto_sizing(cfg, cluster_cap)

    # Auto-scale timeout if not explicitly set
    if timeout is None:
        scale = cfg.architecture.workload.datagen.get_effective_scale()
        timeout = max(3600, scale * 120)
        if scale >= 50:
            print_info(f"Per-job timeout: {timeout}s (auto-scaled for scale {scale})")

    # Preflight: verify infrastructure is deployed and ready
    _run_preflight_infra_check(cfg)

    # Branch: sustained streaming pipeline (CLI flag overrides config)
    use_sustained = sustained or continuous or cfg.architecture.pipeline.mode == "sustained"
    if use_sustained:
        _run_sustained(cfg, config_file, timeout, skip_benchmark, duration)
        return

    console.print(
        Panel(
            f"Running pipeline for: [bold]{cfg.name}[/bold]\n\n"
            f"Stages: bronze-verify → silver-build → gold-finalize",
            expand=False,
        )
    )

    # Journal
    j = journal_open(config_file, config_name=cfg.name)
    j.begin_command(CommandName.RUN, {"stage": stage, "timeout": timeout})

    # Initialize metrics collection
    collector = MetricsCollector()
    metrics_storage = MetricsStorage()
    run_id = datetime.now().strftime("%Y%m%d-%H%M%S") + "-" + uuid.uuid4().hex[:6]
    from lakebench.metrics import build_config_snapshot

    config_snapshot = build_config_snapshot(cfg)
    collector.start_run(run_id, cfg.name, config_snapshot)

    pipeline_success = True
    _datagen_elapsed = 0.0
    _datagen_output_gb = 0.0
    _datagen_output_rows = 0
    results: list[tuple[str, bool, float]] = []
    benchmark_qph: float | None = None

    try:
        # Check Spark operator
        print_info("Checking Spark Operator...")
        spark_op_cfg = cfg.platform.compute.spark.operator
        operator = SparkOperatorManager(
            namespace=spark_op_cfg.namespace,
            version=spark_op_cfg.version if spark_op_cfg.install else None,
            job_namespace=cfg.get_namespace(),
        )
        status = operator.check_status()

        if not status.ready:
            hint = ""
            if not status.installed and spark_op_cfg.install:
                hint = " -- run 'lakebench deploy' first to install it"
            print_error(f"Spark Operator not ready: {status.message}{hint}")
            pipeline_success = False
            raise typer.Exit(1)

        # Ensure operator watches the target namespace (always try to heal)
        ns_status = operator.ensure_namespace_watched(can_heal=True)
        if ns_status.watching_namespace is False:
            print_error(ns_status.message)
            pipeline_success = False
            raise typer.Exit(1)

        print_success(f"Spark Operator ready (version: {status.version or 'unknown'})")

        # Initialize job manager
        k8s = get_k8s_client(
            context=cfg.platform.kubernetes.context,
            namespace=cfg.get_namespace(),
        )

        job_manager = SparkJobManager(cfg, k8s)
        monitor = SparkJobMonitor(cfg, k8s)

        # Deploy scripts ConfigMap -- must succeed or pipeline jobs will fail
        print_info("Deploying Spark scripts...")
        if not job_manager.deploy_scripts_configmap():
            print_error("Failed to deploy Spark scripts ConfigMap -- pipeline cannot proceed")
            _journal_safe(j.end_command, success=False, message="Scripts ConfigMap deploy failed")
            raise typer.Exit(1)
        print_success("Spark scripts deployed")

        # Run datagen if requested (full end-to-end measurement)
        if include_datagen:
            console.print()
            console.print("[bold]Stage: datagen (ingest)[/bold]")
            print_info("Generating data for pipeline benchmark...")
            datagen_start = datetime.now()
            try:
                from lakebench.deploy import DatagenDeployer, DeploymentEngine

                dg_engine = DeploymentEngine(cfg)
                datagen_deployer = DatagenDeployer(dg_engine)
                datagen_deployer.deploy()
                datagen_deployer.wait_for_completion(timeout_seconds=timeout)
                datagen_end = datetime.now()
                _datagen_elapsed = (datagen_end - datagen_start).total_seconds()
                print_success(f"Datagen completed in {_datagen_elapsed:.0f}s")

                # Measure bronze bucket after datagen
                try:
                    from lakebench.s3 import S3Client

                    s3_cfg = cfg.platform.storage.s3
                    _s3_dg = S3Client(
                        endpoint=s3_cfg.endpoint,
                        access_key=s3_cfg.access_key,
                        secret_key=s3_cfg.secret_key,
                        region=s3_cfg.region,
                        path_style=s3_cfg.path_style,
                    )
                    dg_info = _s3_dg.get_bucket_size(s3_cfg.buckets.bronze)
                    if dg_info.size_bytes:
                        _datagen_output_gb = dg_info.size_bytes / (1024**3)
                    if dg_info.object_count:
                        # Estimate rows from scale factor (1.5M rows per scale unit)
                        _datagen_output_rows = cfg.architecture.workload.datagen.scale * 1_500_000
                except Exception as e:
                    logger.warning("Could not measure bronze bucket size: %s", e)
            except Exception as e:
                print_error(f"Datagen failed: {e}")
                pipeline_success = False
                raise typer.Exit(1)  # noqa: B904

        # Determine stages to run
        all_stages = [
            (JobType.BRONZE_VERIFY, "bronze-verify", "Verifying bronze data"),
            (JobType.SILVER_BUILD, "silver-build", "Building silver layer"),
            (JobType.GOLD_FINALIZE, "gold-finalize", "Finalizing gold layer"),
        ]

        if stage:
            stages = [(jt, name, desc) for jt, name, desc in all_stages if name == stage]
            if not stages:
                print_error(f"Unknown stage: {stage}")
                print_info("Valid stages: bronze-verify, silver-build, gold-finalize")
                raise typer.Exit(1)
        else:
            stages = all_stages

        # Multi-cycle batch support (v1.1.0)
        total_cycles = cfg.architecture.pipeline.cycles

        for cycle_idx in range(total_cycles):
            # Track per-cycle metrics (v1.1.0)
            _cycle_start = datetime.now()
            _cycle_jobs: list[JobMetrics] = []
            _cycle_ts_start = ""
            _cycle_ts_end = ""
            _cycle_dg_elapsed = 0.0

            # Cycle header for multi-cycle runs
            if total_cycles > 1:
                console.print()
                console.print(f"[bold cyan]Cycle {cycle_idx + 1}/{total_cycles}[/bold cyan]")

                # Run datagen for this cycle's time window
                try:
                    from lakebench.deploy import DatagenDeployer, DeploymentEngine, DeploymentStatus

                    _cycle_engine = DeploymentEngine(cfg)
                    _cycle_datagen = DatagenDeployer(_cycle_engine)
                    datagen_result = _cycle_datagen.deploy_cycle(cycle_idx, total_cycles)
                    if datagen_result.status != DeploymentStatus.SUCCESS:
                        print_warning(
                            f"Datagen cycle {cycle_idx + 1} failed: {datagen_result.message}"
                        )
                    else:
                        ts_start = datagen_result.details.get("timestamp_start", "")
                        ts_end = datagen_result.details.get("timestamp_end", "")
                        _cycle_ts_start = ts_start
                        _cycle_ts_end = ts_end
                        print_info(f"Datagen: {ts_start} to {ts_end}")

                        # Wait for datagen completion
                        _dg_start = datetime.now()
                        dg_wait = _cycle_datagen.wait_for_completion(timeout_seconds=timeout)
                        _cycle_dg_elapsed = (datetime.now() - _dg_start).total_seconds()
                        if dg_wait.status != DeploymentStatus.SUCCESS:
                            print_warning(f"Datagen did not complete: {dg_wait.message}")
                except Exception as e:
                    print_warning(f"Cycle datagen failed: {e}")

            # Cycle env vars for incremental mode (cycles 2+)
            cycle_env: dict[str, str] | None = None
            if cycle_idx > 0:
                cycle_env = {
                    "LB_SILVER_INCREMENTAL": "true",
                    "LB_GOLD_INCREMENTAL": "true",
                }

            # Run each stage
            for job_type, stage_name, description in stages:
                console.print()
                if total_cycles > 1:
                    console.print(f"[bold]Stage: {stage_name} (cycle {cycle_idx + 1})[/bold]")
                else:
                    console.print(f"[bold]Stage: {stage_name}[/bold]")
                print_info(description)

                job_start = datetime.now()

                # Submit job
                job_status = job_manager.submit_job(job_type, cycle_env=cycle_env)
                if job_status.state == JobState.FAILED:
                    print_error(f"Failed to submit job: {job_status.message}")
                    collector.record_job(
                        JobMetrics(
                            job_name=f"lakebench-{stage_name}",
                            job_type=stage_name,
                            start_time=job_start,
                            end_time=datetime.now(),
                            elapsed_seconds=(datetime.now() - job_start).total_seconds(),
                            success=False,
                            error_message=job_status.message,
                        )
                    )
                    pipeline_success = False
                    raise typer.Exit(1)

                print_success(f"Job submitted: lakebench-{stage_name}")

                # Wait for completion -- capture max executor count seen
                _max_executors = 0
                _last_reported_executors = -1

                def on_progress(status):
                    nonlocal _max_executors, _last_reported_executors
                    if status.state == JobState.RUNNING:
                        _max_executors = max(_max_executors, status.executor_count)
                        if status.executor_count != _last_reported_executors:
                            console.print(f"  Running... (executors: {status.executor_count})")
                            _last_reported_executors = status.executor_count

                result = monitor.wait_for_completion(
                    f"lakebench-{stage_name}",
                    timeout_seconds=timeout,
                    poll_interval=15,
                    progress_callback=on_progress,
                )

                job_end = datetime.now()

                # Build job metrics
                job_metrics = JobMetrics(
                    job_name=f"lakebench-{stage_name}",
                    job_type=stage_name,
                    start_time=job_start,
                    end_time=job_end,
                    elapsed_seconds=result.elapsed_seconds,
                    success=result.success,
                    error_message=result.message if not result.success else None,
                    executor_count=_max_executors,
                )

                # Parse driver logs for data metrics if available
                if result.driver_logs:
                    parsed = collector.parse_driver_logs(result.driver_logs, stage_name)
                    job_metrics.input_size_gb = parsed.input_size_gb
                    job_metrics.output_size_gb = parsed.output_size_gb
                    job_metrics.input_rows = parsed.input_rows
                    job_metrics.output_rows = parsed.output_rows
                    job_metrics.throughput_gb_per_second = parsed.throughput_gb_per_second
                    job_metrics.throughput_rows_per_second = parsed.throughput_rows_per_second

                # Populate resource metrics from job profile
                _profile = get_job_profile(stage_name)
                if _profile:
                    _scale = cfg.architecture.workload.datagen.get_effective_scale()
                    _expected_executors = get_executor_count(stage_name, _scale)

                    # Check per-job executor override
                    _override_map = {
                        "bronze-verify": cfg.platform.compute.spark.bronze_executors,
                        "silver-build": cfg.platform.compute.spark.silver_executors,
                        "gold-finalize": cfg.platform.compute.spark.gold_executors,
                    }
                    _override = _override_map.get(stage_name)
                    if _override is not None:
                        _expected_executors = _override

                    # Use deterministic count when progress callback didn't capture
                    if job_metrics.executor_count == 0:
                        job_metrics.executor_count = _expected_executors

                    job_metrics.executor_cores = _profile["executor_cores"]
                    _mem_gb = parse_spark_memory(_profile["executor_memory"]) / (1024**3)
                    _overhead_gb = parse_spark_memory(_profile["executor_memory_overhead"]) / (
                        1024**3
                    )
                    job_metrics.executor_memory_gb = _mem_gb

                    # Requested CPU-seconds and peak memory
                    job_metrics.cpu_seconds_requested = (
                        job_metrics.executor_count
                        * job_metrics.executor_cores
                        * job_metrics.elapsed_seconds
                    )
                    job_metrics.memory_gb_requested = job_metrics.executor_count * (
                        _mem_gb + _overhead_gb
                    )

                # Gold input fallback: gold reads from silver
                if (
                    stage_name == "gold-finalize"
                    and job_metrics.input_size_gb == 0.0
                    and collector.current_run
                ):
                    for _prev in collector.current_run.jobs:
                        if _prev.job_type == "silver-build" and _prev.output_size_gb > 0:
                            job_metrics.input_size_gb = _prev.output_size_gb
                            if job_metrics.elapsed_seconds > 0:
                                job_metrics.throughput_gb_per_second = (
                                    job_metrics.input_size_gb / job_metrics.elapsed_seconds
                                )
                            break

                # Measure per-stage S3 output size
                _stage_bucket_map = {
                    "bronze-verify": cfg.platform.storage.s3.buckets.bronze,
                    "silver-build": cfg.platform.storage.s3.buckets.silver,
                    "gold-finalize": cfg.platform.storage.s3.buckets.gold,
                }
                if stage_name in _stage_bucket_map and job_metrics.output_size_gb == 0:
                    try:
                        from lakebench.s3 import S3Client

                        s3_cfg = cfg.platform.storage.s3
                        _s3 = S3Client(
                            endpoint=s3_cfg.endpoint,
                            access_key=s3_cfg.access_key,
                            secret_key=s3_cfg.secret_key,
                            region=s3_cfg.region,
                            path_style=s3_cfg.path_style,
                        )
                        _bucket_info = _s3.get_bucket_size(_stage_bucket_map[stage_name])
                        if _bucket_info.size_bytes:
                            job_metrics.output_size_gb = _bucket_info.size_bytes / (1024**3)
                    except Exception as e:
                        logger.warning("Could not measure %s bucket size: %s", stage_name, e)

                collector.record_job(job_metrics)
                _cycle_jobs.append(job_metrics)

                if result.success:
                    print_success(f"{stage_name} completed in {result.elapsed_seconds:.0f}s")
                    results.append((stage_name, True, result.elapsed_seconds))
                    _journal_safe(
                        j.record,
                        EventType.PIPELINE_STAGE,
                        message=f"{stage_name} completed",
                        success=True,
                        details={
                            "stage": stage_name,
                            "success": True,
                            "elapsed_seconds": result.elapsed_seconds,
                            "input_gb": job_metrics.input_size_gb,
                            "output_rows": job_metrics.output_rows,
                        },
                    )
                else:
                    print_error(f"{stage_name} failed: {result.message}")
                    if result.driver_logs:
                        console.print("[dim]Driver logs (last 20 lines):[/dim]")
                        for line in result.driver_logs.split("\n")[-20:]:
                            console.print(f"  {line}")
                    results.append((stage_name, False, result.elapsed_seconds))
                    _journal_safe(
                        j.record,
                        EventType.PIPELINE_STAGE,
                        message=f"{stage_name} failed: {result.message}",
                        success=False,
                        details={
                            "stage": stage_name,
                            "success": False,
                            "elapsed_seconds": result.elapsed_seconds,
                        },
                    )
                    pipeline_success = False
                    raise typer.Exit(1)

            # Record CycleMetrics after all stages for this cycle (v1.1.0)
            if total_cycles > 1:
                _cycle_health: dict[str, int] = {}
                try:
                    _cycle_health = _probe_table_health(cfg, k8s)
                except Exception:
                    pass
                from lakebench.metrics.collector import CycleMetrics as _CM

                _cm = _CM(
                    cycle_index=cycle_idx,
                    timestamp_start=_cycle_ts_start,
                    timestamp_end=_cycle_ts_end,
                    datagen_elapsed_seconds=_cycle_dg_elapsed,
                    jobs=list(_cycle_jobs),
                    table_health=_cycle_health,
                )
                if collector.current_run is not None:
                    collector.current_run.cycles.append(_cm)

        # Summary
        console.print()
        total_time = sum(r[2] for r in results)

        stages_succeeded = sum(1 for _, ok, _ in results if ok)
        stages_failed = sum(1 for _, ok, _ in results if not ok)
        _journal_safe(
            j.record,
            EventType.PIPELINE_COMPLETE,
            message=f"Pipeline complete: {stages_succeeded} stages succeeded",
            success=stages_failed == 0,
            details={
                "run_id": run_id,
                "stages_succeeded": stages_succeeded,
                "stages_failed": stages_failed,
                "total_seconds": total_time,
            },
        )

        # Pre-benchmark maintenance (v1.1.0): compact + expire before
        # measuring QpH so the benchmark reflects query engine performance,
        # not Iceberg metadata overhead from accumulated writes.
        if not skip_benchmark and cfg.architecture.pipeline.pre_benchmark_maintenance:
            try:
                console.print()
                console.print("[bold]Pre-benchmark maintenance[/bold]")
                _run_iceberg_maintenance(cfg, k8s, console, j, retention_threshold="0s")
                _run_iceberg_compaction(cfg, k8s, console, j)
            except Exception as e:
                print_warning(f"Pre-benchmark maintenance failed (non-fatal): {e}")

        # Run Trino benchmark after pipeline completes
        if not skip_benchmark:
            try:
                from lakebench.benchmark import BenchmarkRunner
                from lakebench.metrics import BenchmarkMetrics

                console.print()
                console.print("[bold]Stage: benchmark[/bold]")
                print_info("Running query benchmark (hot cache, power)...")

                _journal_safe(
                    j.record,
                    EventType.BENCHMARK_START,
                    message="Benchmark started",
                    details={"mode": "power", "cache": "hot"},
                )

                bench_runner = BenchmarkRunner(cfg)
                bench_result = bench_runner.run_power(cache="hot")

                # Display per-query results
                for qr in bench_result.queries:
                    status_str = "[green]PASS[/green]" if qr.success else "[red]FAIL[/red]"
                    console.print(
                        f"  {qr.query.name[:4]}  {qr.query.display_name:<34} "
                        f"{qr.elapsed_seconds:>7.2f}s   "
                        f"{qr.rows_returned:>6} rows   {status_str}"
                    )

                console.print(f"\n  Total: {bench_result.total_seconds:.2f}s")
                console.print(f"  [bold]QpH:   {bench_result.qph:.1f}[/bold]")
                benchmark_qph = bench_result.qph

                # Record in metrics
                bench_metrics = BenchmarkMetrics(
                    mode=bench_result.mode,
                    cache=bench_result.cache,
                    scale=bench_result.scale,
                    qph=bench_result.qph,
                    total_seconds=bench_result.total_seconds,
                    queries=[q.to_dict() for q in bench_result.queries],
                    iterations=bench_result.iterations,
                )
                collector.record_benchmark(bench_metrics)

                _journal_safe(
                    j.record,
                    EventType.BENCHMARK_COMPLETE,
                    message=f"Benchmark complete: QpH={bench_result.qph:.1f}",
                    success=True,
                    details={
                        "qph": round(bench_result.qph, 1),
                        "total_seconds": round(bench_result.total_seconds, 2),
                        "queries_passed": sum(1 for q in bench_result.queries if q.success),
                        "queries_total": len(bench_result.queries),
                    },
                )

            except Exception as e:
                print_warning(f"Benchmark failed: {e}")
                print_info(
                    "Pipeline results are still valid. Run 'lakebench benchmark' separately."
                )

        # Summary panel is printed in the finally block (after pipeline
        # benchmark scores are computed) so it can include the full scorecard.

    except K8sConnectionError as e:
        print_error(f"Kubernetes connection failed: {e}")
        pipeline_success = False
        _journal_safe(j.end_command, success=False, message=str(e))
        raise typer.Exit(1)  # noqa: B904
    finally:
        # Measure actual S3 bucket sizes before saving metrics
        try:
            from lakebench.s3 import S3Client

            s3_cfg = cfg.platform.storage.s3
            s3_client = S3Client(
                endpoint=s3_cfg.endpoint,
                access_key=s3_cfg.access_key,
                secret_key=s3_cfg.secret_key,
                region=s3_cfg.region,
                path_style=s3_cfg.path_style,
                ca_cert=s3_cfg.ca_cert,
                verify_ssl=s3_cfg.verify_ssl,
            )
            print_info("Measuring actual S3 bucket sizes...")
            collector.record_actual_sizes(
                s3_client,
                s3_cfg.buckets.bronze,
                s3_cfg.buckets.silver,
                s3_cfg.buckets.gold,
            )
        except Exception as e:
            console.print(f"  [yellow]Could not measure S3 sizes: {e}[/yellow]")

        # Always save metrics, even on failure
        run_metrics = collector.end_run(success=pipeline_success)
        if run_metrics:
            # Collect platform metrics from Prometheus (best-effort)
            _collect_platform_metrics(cfg, run_metrics)

            # Build pipeline benchmark (stage-matrix view)
            try:
                from lakebench.metrics import build_pipeline_benchmark

                pb = build_pipeline_benchmark(
                    run_metrics,
                    datagen_elapsed=_datagen_elapsed,
                    datagen_output_gb=_datagen_output_gb,
                    datagen_output_rows=_datagen_output_rows,
                )
                run_metrics.pipeline_benchmark = pb

                # Print full scorecard panel
                if pipeline_success:
                    _print_pipeline_scorecard(pb, results, _datagen_elapsed, benchmark_qph)
            except Exception as e:
                console.print(f"  [yellow]Could not build pipeline benchmark: {e}[/yellow]")
                # Fallback summary if scorecard build failed
                if pipeline_success and results:
                    _total = sum(r[2] for r in results)
                    _qph = f"\nQpH: {benchmark_qph:.1f}" if benchmark_qph else ""
                    console.print(
                        Panel(
                            "[green]Pipeline complete[/green]\n\n"
                            + "\n".join(f"  {n}: {el:.0f}s" for n, _, el in results)
                            + f"\n\nTotal: {_total:.0f}s{_qph}"
                            + "\n\nFull report: [bold]lakebench report[/bold]",
                            title="Pipeline Complete",
                            expand=False,
                        )
                    )

            metrics_path = metrics_storage.save_run(run_metrics)
            print_info(f"Metrics saved to {metrics_path}")
            print_info(f"Run ID: {run_id}")

            _journal_safe(
                j.record,
                EventType.METRICS_SAVED,
                message=f"Metrics saved for run {run_id}",
                details={"run_id": run_id, "metrics_path": str(metrics_path)},
            )

        _journal_safe(j.end_command, success=pipeline_success)


def _find_prometheus_svc(namespace: str) -> str | None:
    """Find the Prometheus service name in the given namespace.

    The kube-prometheus-stack Helm chart truncates the service name based on
    the release name length, so we cannot predict it. We try the K8s Python
    client first, then fall back to kubectl.
    """
    from lakebench.deploy.observability import HELM_RELEASE_NAME

    label = f"release={HELM_RELEASE_NAME},app=kube-prometheus-stack-prometheus"

    # Attempt 1: K8s Python client
    try:
        from kubernetes import client as k8s_client
        from kubernetes import config as k8s_config

        try:
            k8s_config.load_incluster_config()
        except k8s_config.ConfigException:
            k8s_config.load_kube_config()

        v1 = k8s_client.CoreV1Api()
        svcs = v1.list_namespaced_service(namespace, label_selector=label)
        if svcs.items:
            return svcs.items[0].metadata.name
    except Exception:
        pass

    # Attempt 2: kubectl fallback
    try:
        result = subprocess.run(
            [
                "kubectl",
                "get",
                "svc",
                "-n",
                namespace,
                "-l",
                label,
                "-o",
                "jsonpath={.items[0].metadata.name}",
            ],
            capture_output=True,
            text=True,
            timeout=10,
        )
        svc_name = result.stdout.strip()
        if result.returncode == 0 and svc_name:
            return svc_name
    except Exception:
        pass

    return None


def _collect_platform_metrics(cfg, run_metrics) -> None:
    """Collect platform metrics from Prometheus and attach to run_metrics.

    Only runs when observability is enabled. Best-effort -- failures are
    logged as warnings but do not affect the pipeline result.

    When running outside the K8s cluster (no CoreDNS), uses kubectl
    port-forward to reach Prometheus.
    """
    if not cfg.observability.enabled:
        return

    try:
        from lakebench.observability.platform_collector import PlatformCollector

        namespace = cfg.get_namespace()
        svc_name = _find_prometheus_svc(namespace)
        if not svc_name:
            console.print("  [yellow]Could not find Prometheus service[/yellow]")
            return

        # Try in-cluster DNS first (fast path when running inside K8s)
        prometheus_url = f"http://{svc_name}.{namespace}.svc:9090"
        try:
            import httpx

            httpx.get(f"{prometheus_url}/api/v1/status/config", timeout=5)
            # DNS resolved and Prometheus responded -- use this URL
        except Exception:
            # DNS failed -- we are outside the cluster. Use port-forward.
            import socket

            local_port = _find_free_port()
            pf_proc = subprocess.Popen(
                [
                    "kubectl",
                    "port-forward",
                    f"svc/{svc_name}",
                    f"{local_port}:9090",
                    "-n",
                    namespace,
                ],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
            # Wait for port-forward to be ready
            import time

            for _ in range(20):
                time.sleep(0.5)
                try:
                    with socket.create_connection(("127.0.0.1", local_port), timeout=1):
                        break
                except OSError:
                    continue
            else:
                pf_proc.kill()
                console.print("  [yellow]Could not establish port-forward to Prometheus[/yellow]")
                return

            prometheus_url = f"http://127.0.0.1:{local_port}"

        print_info("Collecting platform metrics from Prometheus...")
        collector = PlatformCollector(prometheus_url, namespace)
        pm = collector.collect(run_metrics.start_time, run_metrics.end_time or datetime.now())
        run_metrics.platform_metrics = pm.to_dict()

        # Clean up port-forward if we started one
        if "pf_proc" in locals():
            pf_proc.kill()
            pf_proc.wait()

        if pm.collection_error:
            console.print(f"  [yellow]Platform metrics partial: {pm.collection_error}[/yellow]")
        else:
            pod_count = len(pm.pods)
            engine_tag = ""
            if pm.engine.has_data:
                engine_tag = " (+ engine metrics)"
            print_success(f"Platform metrics collected: {pod_count} pods{engine_tag}")
    except Exception as e:
        # Clean up port-forward on error
        if "pf_proc" in locals():
            pf_proc.kill()
            pf_proc.wait()
        console.print(f"  [yellow]Could not collect platform metrics: {e}[/yellow]")


def _find_free_port() -> int:
    """Find an available local TCP port."""
    import socket

    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


def _parse_spark_interval(interval_str: str) -> int:
    """Parse a Spark-style interval string to seconds.

    Handles: ``"30 seconds"``, ``"5 minutes"``, ``"1 minute"``.
    Falls back to 300 if unparseable.
    """
    parts = interval_str.strip().lower().split()
    if len(parts) != 2:
        return 300
    try:
        value = int(parts[0])
    except ValueError:
        return 300
    unit = parts[1].rstrip("s")  # "minutes" -> "minute"
    if unit == "second":
        return value
    elif unit == "minute":
        return value * 60
    elif unit == "hour":
        return value * 3600
    return 300


def _run_iceberg_maintenance(
    cfg,
    k8s,
    console: Console,
    j,
    retention_threshold: str,
) -> None:
    """Run Iceberg expire_snapshots + remove_orphan_files.

    Engine-aware: uses Trino (preferred) or Spark Thrift Server.
    DuckDB cannot run Iceberg maintenance -- skipped with a warning.
    Failures on individual tables are logged but do not abort.
    """
    from lakebench.deploy.iceberg import (
        build_maintenance_sql,
        exec_sql,
        find_maintenance_engine,
    )

    namespace = cfg.get_namespace()
    engine_type = cfg.architecture.query_engine.type.value

    if engine_type == "duckdb":
        console.print("  [dim]Iceberg maintenance skipped (DuckDB cannot run maintenance)[/dim]")
        return

    engine, pod_name, catalog = find_maintenance_engine(cfg, namespace)
    if engine is None or pod_name is None or catalog is None:
        console.print("  [dim]Iceberg maintenance skipped (no capable engine pod found)[/dim]")
        return

    tables = cfg.architecture.tables
    table_names = [
        f"{catalog}.{tables.bronze}",
        f"{catalog}.{tables.silver}",
        f"{catalog}.{tables.gold}",
    ]

    maintained = 0
    for table in table_names:
        for sql in build_maintenance_sql(engine, catalog, table, retention_threshold):
            try:
                exec_sql(engine, k8s, pod_name, namespace, sql)
                maintained += 1
            except Exception as e:
                logger.warning("Iceberg maintenance failed for %s: %s", table, e)

    console.print(
        f"  Iceberg maintenance ({engine}): {maintained}/{len(table_names) * 2} "
        f"operations (threshold: {retention_threshold})"
    )
    _journal_safe(
        j.record,
        EventType.STREAMING_HEALTH,
        message="Iceberg maintenance",
        details={
            "engine": engine,
            "retention_threshold": retention_threshold,
            "operations_succeeded": maintained,
            "operations_total": len(table_names) * 2,
        },
    )


def _run_iceberg_compaction(
    cfg,
    k8s,
    console: Console,
    j,
    file_size_threshold: str = "128MB",
) -> None:
    """Run Iceberg compaction (optimize / rewrite_data_files).

    Merges small files produced by streaming micro-batches or repeated
    incremental writes.  Heavier than expire_snapshots.
    DuckDB cannot run compaction -- skipped with a warning.
    """
    from lakebench.deploy.iceberg import (
        build_compaction_sql,
        exec_sql,
        find_maintenance_engine,
    )

    namespace = cfg.get_namespace()
    engine_type = cfg.architecture.query_engine.type.value

    if engine_type == "duckdb":
        console.print("  [dim]Iceberg compaction skipped (DuckDB read-only)[/dim]")
        return

    engine, pod_name, catalog = find_maintenance_engine(cfg, namespace)
    if engine is None or pod_name is None or catalog is None:
        console.print("  [dim]Iceberg compaction skipped (no capable engine pod found)[/dim]")
        return

    tables = cfg.architecture.tables
    table_names = [
        f"{catalog}.{tables.silver}",
        f"{catalog}.{tables.gold}",
    ]

    compacted = 0
    for table in table_names:
        for sql in build_compaction_sql(engine, catalog, table, file_size_threshold):
            try:
                exec_sql(engine, k8s, pod_name, namespace, sql)
                compacted += 1
            except Exception as e:
                logger.warning("Iceberg compaction failed for %s: %s", table, e)

    console.print(
        f"  Iceberg compaction ({engine}): {compacted}/{len(table_names)} "
        f"tables (threshold: {file_size_threshold})"
    )


def _probe_table_health(cfg, k8s) -> dict[str, int]:
    """Query Iceberg system tables for file/snapshot counts on silver and gold.

    Returns a dict like {"silver_data_file_count": N, "silver_snapshot_count": N, ...}.
    Returns empty dict if no engine is available.
    """
    from lakebench.deploy.iceberg import (
        build_table_health_sql,
        find_maintenance_engine,
        query_sql,
    )

    namespace = cfg.get_namespace()
    engine_type = cfg.architecture.query_engine.type.value

    if engine_type == "duckdb":
        return {}

    engine, pod_name, catalog = find_maintenance_engine(cfg, namespace)
    if engine is None or pod_name is None or catalog is None:
        return {}

    tables = cfg.architecture.tables
    health: dict[str, int] = {}

    for label, table_ref in [("silver", tables.silver), ("gold", tables.gold)]:
        fq = f"{catalog}.{table_ref}"
        for metric_name, sql in build_table_health_sql(engine, fq).items():
            try:
                import re as _re

                stdout = query_sql(engine, k8s, pod_name, namespace, sql)
                # Parse count from output.  Trino CLI prints a bare number;
                # beeline wraps results in pipes and column headers.  Extract
                # the first integer from any non-header line.
                _found = False
                for line in stdout.strip().splitlines():
                    cleaned = line.strip().strip("|").strip().strip('"').strip()
                    if not cleaned or cleaned.startswith("-"):
                        continue
                    # Skip column header lines (contain letters like "count")
                    if _re.fullmatch(r"\d+", cleaned):
                        health[f"{label}_{metric_name}"] = int(cleaned)
                        _found = True
                        break
                    # Beeline tabular: number may be padded with spaces
                    m = _re.fullmatch(r"\s*(\d+)\s*", cleaned)
                    if m:
                        health[f"{label}_{metric_name}"] = int(m.group(1))
                        _found = True
                        break
                if not _found:
                    health[f"{label}_{metric_name}"] = -1
            except Exception:
                health[f"{label}_{metric_name}"] = -1

    return health


def _run_benchmark_round(
    cfg,
    bench_runner,
    collector,
    console,
    round_index: int,
    j,
    k8s=None,
) -> None:
    """Execute a single in-stream benchmark round.

    Flushes the Trino metadata cache, probes gold-table freshness, runs
    the full 8-query power benchmark, and records the result as a
    benchmark round.  If Q9 (the gold-table query) fails, retries up to
    twice with 30s/60s backoff to ride out the ``createOrReplace()``
    window.
    """
    from lakebench.metrics import BenchmarkMetrics, BenchmarkRoundMeta

    round_meta = BenchmarkRoundMeta(
        round_index=round_index,
        timestamp=datetime.now(),
    )

    # Table health probe (v1.1.0)
    if k8s is not None:
        try:
            health = _probe_table_health(cfg, k8s)
            round_meta.silver_data_file_count = health.get("silver_data_file_count", 0)
            round_meta.silver_snapshot_count = health.get("silver_snapshot_count", 0)
            round_meta.gold_data_file_count = health.get("gold_data_file_count", 0)
            round_meta.gold_snapshot_count = health.get("gold_snapshot_count", 0)
        except Exception:
            pass  # Health probe failure should not block the benchmark

    # 1. Flush Trino metadata cache
    try:
        bench_runner.executor.flush_cache()
    except Exception:
        pass

    # 2. Freshness probe: measure gold table staleness at query time
    try:
        catalog = bench_runner.catalog
        gold_table = bench_runner.gold_table
        freshness_sql = (
            f"SELECT date_diff('second', CAST(MAX(interaction_date) AS timestamp), current_timestamp) "
            f"FROM {catalog}.{gold_table}"
        )
        freshness_sql = bench_runner.executor.adapt_query(freshness_sql)
        freshness_result = bench_runner.executor.execute_query(freshness_sql, timeout=30)
        if freshness_result.success and freshness_result.raw_output.strip():
            try:
                round_meta.gold_freshness_seconds = float(
                    freshness_result.raw_output.strip().split("\n")[0]
                )
            except (ValueError, IndexError):
                pass
    except Exception:
        pass

    # 3. Run the full 8-query power benchmark
    bench_result = bench_runner.run_power(cache="hot")

    # 4. Check Q9 for contention (gold-table query)
    q9_failed = False
    for qr in bench_result.queries:
        if qr.query.name == "q9" and not qr.success:
            q9_failed = True
            break

    if q9_failed:
        round_meta.q9_contention_observed = True
        q9_query = None
        for qr in bench_result.queries:
            if qr.query.name == "q9":
                q9_query = qr.query
                break
        if q9_query is not None:
            # Two retries with increasing backoff (30s, 60s) to ride out
            # the gold createOrReplace() window at larger scales.
            for attempt, wait in enumerate([30, 60], start=1):
                console.print(f"    Q9 failed (gold contention) -- retry {attempt}/2 in {wait}s...")
                time.sleep(wait)
                try:
                    bench_runner.executor.flush_cache()
                except Exception:
                    pass
                retry_result = bench_runner._execute_single_query(q9_query)
                if retry_result.success:
                    round_meta.q9_retry_used = True
                    # Replace Q9 in results
                    for i, qr in enumerate(bench_result.queries):
                        if qr.query.name == "q9":
                            bench_result.queries[i] = retry_result
                            break
                    # Recompute total_seconds and qph
                    bench_result.total_seconds = sum(
                        qr.elapsed_seconds for qr in bench_result.queries
                    )
                    if bench_result.total_seconds > 0:
                        bench_result.qph = (
                            len(bench_result.queries) / bench_result.total_seconds
                        ) * 3600
                    break

    # 5. Build BenchmarkMetrics with round_meta
    passed = sum(1 for qr in bench_result.queries if qr.success)
    total = len(bench_result.queries)

    bench_metrics = BenchmarkMetrics(
        mode=bench_result.mode,
        cache=bench_result.cache,
        scale=bench_result.scale,
        qph=bench_result.qph,
        total_seconds=bench_result.total_seconds,
        queries=[q.to_dict() for q in bench_result.queries],
        iterations=bench_result.iterations,
        round_meta=round_meta,
    )

    # 6. Record the round
    collector.record_benchmark_round(bench_metrics)

    # 7. Print inline result
    freshness_str = (
        f" | Freshness: {round_meta.gold_freshness_seconds:.1f}s"
        if round_meta.gold_freshness_seconds > 0
        else ""
    )
    q9_str = ""
    if round_meta.q9_contention_observed:
        q9_str = " | Q9: retry" if round_meta.q9_retry_used else " | Q9: contention"
    console.print(
        f"  Round {round_index}: {passed}/{total} passed "
        f"| QpH: {bench_result.qph:.1f}{freshness_str}{q9_str}"
    )

    _journal_safe(
        j.record,
        EventType.STREAMING_HEALTH,
        message=f"Benchmark round {round_index}",
        details={
            "round": round_index,
            "qph": round(bench_result.qph, 1),
            "passed": passed,
            "total": total,
            "freshness_seconds": round(round_meta.gold_freshness_seconds, 2),
            "q9_contention": round_meta.q9_contention_observed,
        },
    )


def _print_rounds_summary(console, rounds: list) -> None:
    """Print a Rich table summarizing all in-stream benchmark rounds."""
    table = Table(title="Benchmark Rounds (In-Stream)", expand=False)
    table.add_column("Round", justify="right", style="bold")
    table.add_column("QpH", justify="right")

    # Collect query names from the first round
    query_names: list[str] = []
    if rounds and rounds[0].queries:
        for q in rounds[0].queries:
            name = q.get("name", "?")
            query_names.append(name)
            table.add_column(name, justify="right")

    table.add_column("Freshness", justify="right")
    table.add_column("Q9", justify="center")

    import statistics

    qph_values: list[float] = []
    freshness_values: list[float] = []

    for rnd in rounds:
        meta = rnd.round_meta
        row: list[str] = [str(meta.round_index if meta else "?")]
        row.append(f"{rnd.qph:.1f}")
        qph_values.append(rnd.qph)

        # Per-query elapsed times
        for qname in query_names:
            matched = False
            for q in rnd.queries:
                if q.get("name") == qname:
                    row.append(f"{q['elapsed_seconds']:.1f}s")
                    matched = True
                    break
            if not matched:
                row.append("-")

        # Freshness
        if meta and meta.gold_freshness_seconds > 0:
            row.append(f"{meta.gold_freshness_seconds:.1f}s")
            freshness_values.append(meta.gold_freshness_seconds)
        else:
            row.append("-")

        # Q9 status
        if meta and meta.q9_contention_observed:
            row.append("retry" if meta.q9_retry_used else "FAIL")
        else:
            row.append("OK")

        table.add_row(*row)

    console.print(table)

    # Summary line
    median_qph = statistics.median(qph_values) if qph_values else 0.0
    median_freshness = statistics.median(freshness_values) if freshness_values else 0.0
    parts = [f"Median QpH: {median_qph:.1f}"]
    if median_freshness > 0:
        parts.append(f"Median freshness: {median_freshness:.1f}s")
    console.print(f"  {' | '.join(parts)}")


def _run_sustained(
    cfg,
    config_file: Path,
    timeout: int,
    skip_benchmark: bool,
    duration: int | None,
) -> None:
    """Run the sustained streaming pipeline.

    Starts datagen concurrently with bronze-ingest, silver-stream, and
    gold-refresh streaming SparkApplications. Monitors for the configured
    duration, then stops streaming jobs and optionally runs the benchmark.
    """
    import uuid

    from lakebench.deploy import DatagenDeployer, DeploymentEngine, DeploymentStatus
    from lakebench.metrics import MetricsCollector, MetricsStorage, StreamingJobMetrics
    from lakebench.spark import SparkJobManager, SparkJobMonitor, SparkOperatorManager
    from lakebench.spark.job import JobState, JobType

    run_duration = duration or cfg.architecture.pipeline.sustained.run_duration

    console.print(
        Panel(
            f"Running sustained pipeline for: [bold]{cfg.name}[/bold]\n\n"
            f"Stages: bronze-ingest + silver-stream + gold-refresh (concurrent)\n"
            f"Duration: {run_duration}s ({run_duration / 60:.0f} min)",
            expand=False,
        )
    )

    j = journal_open(config_file, config_name=cfg.name)
    j.begin_command(CommandName.RUN, {"sustained": True, "duration": run_duration})

    collector = MetricsCollector()
    metrics_storage = MetricsStorage()
    run_id = datetime.now().strftime("%Y%m%d-%H%M%S") + "-" + uuid.uuid4().hex[:6]
    from lakebench.metrics import build_config_snapshot

    config_snapshot = build_config_snapshot(cfg)
    collector.start_run(run_id, cfg.name, config_snapshot)

    pipeline_success = True
    _datagen_output_gb = 0.0
    _datagen_output_rows = 0
    streaming_jobs = [
        (JobType.BRONZE_INGEST, "bronze-ingest"),
        (JobType.SILVER_STREAM, "silver-stream"),
        (JobType.GOLD_REFRESH, "gold-refresh"),
    ]

    try:
        # Check Spark operator
        print_info("Checking Spark Operator...")
        spark_op_cfg = cfg.platform.compute.spark.operator
        operator = SparkOperatorManager(
            namespace=spark_op_cfg.namespace,
            version=spark_op_cfg.version if spark_op_cfg.install else None,
            job_namespace=cfg.get_namespace(),
        )
        status = operator.check_status()
        if not status.ready:
            hint = ""
            if not status.installed and spark_op_cfg.install:
                hint = " -- run 'lakebench deploy' first to install it"
            print_error(f"Spark Operator not ready: {status.message}{hint}")
            pipeline_success = False
            raise typer.Exit(1)

        # Ensure operator watches the target namespace (always try to heal)
        ns_status = operator.ensure_namespace_watched(can_heal=True)
        if ns_status.watching_namespace is False:
            print_error(ns_status.message)
            pipeline_success = False
            raise typer.Exit(1)

        print_success(f"Spark Operator ready (version: {status.version or 'unknown'})")

        k8s = get_k8s_client(
            context=cfg.platform.kubernetes.context,
            namespace=cfg.get_namespace(),
        )
        job_manager = SparkJobManager(cfg, k8s)
        monitor = SparkJobMonitor(cfg, k8s)

        # Deploy scripts ConfigMap (includes streaming scripts) -- must succeed
        print_info("Deploying Spark scripts...")
        if not job_manager.deploy_scripts_configmap():
            print_error("Failed to deploy Spark scripts ConfigMap -- pipeline cannot proceed")
            _journal_safe(j.end_command, success=False, message="Scripts ConfigMap deploy failed")
            raise typer.Exit(1)
        print_success("Spark scripts deployed")

        # Start datagen (runs concurrently with streaming jobs)
        console.print()
        console.print("[bold]Starting datagen...[/bold]")
        engine = DeploymentEngine(cfg)
        datagen = DatagenDeployer(engine)
        datagen_result = datagen.deploy()
        if datagen_result.status != DeploymentStatus.SUCCESS:
            print_error(f"Failed to start datagen: {datagen_result.message}")
            pipeline_success = False
            raise typer.Exit(1)
        print_success("Datagen started (sustained mode)")
        dims = cfg.get_scale_dimensions()
        console.print(f"  Scale: {dims.scale}")
        console.print(f"  Parallelism: {cfg.architecture.workload.datagen.parallelism} pods")
        _journal_safe(
            j.record,
            EventType.GENERATE_START,
            message="Datagen started for sustained pipeline",
            details={
                "scale": dims.scale,
                "parallelism": cfg.architecture.workload.datagen.parallelism,
                "target_gb": round(dims.approx_bronze_gb, 1),
            },
        )

        # Launch all streaming jobs concurrently
        console.print()
        console.print("[bold]Launching streaming jobs...[/bold]")

        _journal_safe(
            j.record,
            EventType.STREAMING_START,
            message="Starting streaming pipeline",
            details={"jobs": [name for _, name in streaming_jobs]},
        )

        submitted = []
        for job_type, job_name in streaming_jobs:
            job_status = job_manager.submit_job(job_type)
            if job_status.state == JobState.FAILED:
                print_error(f"Failed to submit {job_name}: {job_status.message}")
                pipeline_success = False
                raise typer.Exit(1)
            print_success(f"Submitted: lakebench-{job_name}")
            submitted.append((job_type, job_name))

        # Monitor for configured duration, running benchmark rounds at intervals
        console.print()
        print_info(
            f"Streaming pipeline running for {run_duration}s ({run_duration / 60:.0f} min)..."
        )

        # In-stream benchmark scheduling
        sustained_cfg = cfg.architecture.pipeline.sustained
        bench_warmup = sustained_cfg.benchmark_warmup
        bench_interval = sustained_cfg.benchmark_interval
        gold_interval_s = _parse_spark_interval(sustained_cfg.gold_refresh_interval)

        # Hard floor: both warmup and interval must be >= gold_refresh_interval.
        # Gold rewrites the entire table each cycle via createOrReplace().
        # Warmup < gold interval -> Q9 hits an empty/stale table, inflated QpH.
        # Interval < gold interval -> rounds overlap with gold rewrites, Q9
        # contention and inconsistent QpH across rounds.
        if bench_warmup < gold_interval_s and not skip_benchmark:
            print_warning(
                f"benchmark_warmup ({bench_warmup}s) is less than "
                f"gold_refresh_interval ({gold_interval_s}s) -- "
                f"clamping warmup to {gold_interval_s}s."
            )
            bench_warmup = gold_interval_s
        if bench_interval < gold_interval_s and not skip_benchmark:
            print_warning(
                f"benchmark_interval ({bench_interval}s) is less than "
                f"gold_refresh_interval ({gold_interval_s}s) -- "
                f"clamping interval to {gold_interval_s}s."
            )
            bench_interval = gold_interval_s

        # Guard: skip in-stream rounds if run duration is too short
        can_run_rounds = not skip_benchmark and run_duration >= bench_warmup + bench_interval
        if not skip_benchmark and not can_run_rounds:
            print_warning(
                f"Run duration ({run_duration}s) too short for in-stream benchmarking "
                f"(need >= {bench_warmup + bench_interval}s). "
                f"No benchmark rounds will run."
            )

        # Pre-create benchmark runner for in-stream rounds
        bench_runner_instream = None
        if can_run_rounds:
            try:
                from lakebench.benchmark import BenchmarkRunner

                bench_runner_instream = BenchmarkRunner(cfg)
                print_info(
                    f"In-stream benchmarking: warmup {bench_warmup}s, then every {bench_interval}s"
                )
            except Exception as e:
                print_warning(f"Could not create benchmark runner: {e}")
                can_run_rounds = False

        # Iceberg retention scheduling
        retention_interval = sustained_cfg.retention_interval
        retention_threshold = sustained_cfg.retention_threshold
        next_maintenance_at = float(retention_interval)  # first run after one interval
        print_info(
            f"Iceberg retention: every {retention_interval}s (threshold: {retention_threshold})"
        )

        # Iceberg compaction scheduling (v1.1.0)
        compaction_enabled = sustained_cfg.compaction_enabled
        compaction_interval = sustained_cfg.compaction_interval
        next_compaction_at = float(compaction_interval) if compaction_enabled else float("inf")
        if compaction_enabled:
            print_info(f"Iceberg compaction: every {compaction_interval}s")

        start = time.time()
        check_interval = 30
        # First round fires after warmup (no offset -- Q9 contention
        # is handled by the retry logic inside _run_benchmark_round).
        next_round_at = bench_warmup if can_run_rounds else float("inf")
        round_index = 0
        # Adaptive guard: after the first round completes, use the
        # observed duration * 1.2 as the minimum remaining time for
        # subsequent rounds.  Before any round completes, use a small
        # fixed floor (60s) so we don't skip the first attempt on
        # short runs.  This scales naturally with cluster performance
        # -- fast clusters get more rounds, slow clusters don't start
        # rounds they can't finish.
        last_round_seconds: float = 0.0
        min_remaining_floor = 60

        while time.time() - start < run_duration:
            elapsed = time.time() - start
            remaining = run_duration - elapsed

            # Adaptive guard: use observed round time when available
            min_remaining = max(
                min_remaining_floor,
                last_round_seconds * 1.2,
            )

            # Check if it's time for a benchmark round
            if (
                can_run_rounds
                and elapsed >= next_round_at
                and remaining >= min_remaining
                and bench_runner_instream is not None
            ):
                round_index += 1
                console.print(
                    f"\n  [{elapsed:.0f}s / {run_duration}s] "
                    f"Starting benchmark round {round_index}..."
                )
                round_start = time.time()
                _run_benchmark_round(
                    cfg=cfg,
                    bench_runner=bench_runner_instream,
                    collector=collector,
                    console=console,
                    round_index=round_index,
                    j=j,
                    k8s=k8s,
                )
                last_round_seconds = time.time() - round_start
                # Next round at interval from round completion
                next_round_at = (time.time() - start) + bench_interval
                continue

            # Iceberg retention maintenance
            if elapsed >= next_maintenance_at:
                _run_iceberg_maintenance(cfg, k8s, console, j, retention_threshold)
                next_maintenance_at = (time.time() - start) + retention_interval

            # Iceberg compaction (v1.1.0)
            if compaction_enabled and elapsed >= next_compaction_at:
                _run_iceberg_compaction(cfg, k8s, console, j)
                next_compaction_at = (time.time() - start) + compaction_interval

            # Sleep until next event (health check, benchmark round, maintenance, or compaction)
            sleep_until = min(
                elapsed + check_interval,
                next_round_at if can_run_rounds else float("inf"),
                next_maintenance_at,
                next_compaction_at,
                run_duration,
            )
            sleep_time = max(0, sleep_until - (time.time() - start))
            if sleep_time > 0:
                time.sleep(sleep_time)

            # Periodic health check
            elapsed = time.time() - start
            remaining = run_duration - elapsed
            console.print(
                f"  [{elapsed:.0f}s / {run_duration}s] "
                f"Streaming jobs running... ({remaining:.0f}s remaining)"
            )

            _journal_safe(
                j.record,
                EventType.STREAMING_HEALTH,
                message="Health check",
                details={"elapsed_seconds": elapsed, "remaining_seconds": remaining},
            )

        # Measure bronze bucket for datagen stats (datagen runs concurrently,
        # so we measure after the monitoring window to capture all output)
        try:
            from lakebench.s3 import S3Client

            s3_cfg = cfg.platform.storage.s3
            _s3_dg = S3Client(
                endpoint=s3_cfg.endpoint,
                access_key=s3_cfg.access_key,
                secret_key=s3_cfg.secret_key,
                region=s3_cfg.region,
                path_style=s3_cfg.path_style,
                ca_cert=s3_cfg.ca_cert,
                verify_ssl=s3_cfg.verify_ssl,
            )
            dg_info = _s3_dg.get_bucket_size(s3_cfg.buckets.bronze)
            if dg_info.size_bytes:
                _datagen_output_gb = dg_info.size_bytes / (1024**3)
            if dg_info.object_count:
                _datagen_output_rows = cfg.architecture.workload.datagen.scale * 1_500_000
        except Exception as e:
            logger.warning("Could not measure streaming bronze bucket size: %s", e)

        # Capture driver logs BEFORE stopping jobs (pods are deleted on stop)
        console.print()
        console.print("[bold]Collecting streaming metrics...[/bold]")
        namespace = cfg.get_namespace()
        driver_logs: dict[str, str | None] = {}
        for _job_type, job_name in submitted:
            try:
                logs = monitor._get_driver_logs(
                    f"lakebench-{job_name}",
                    tail_lines=None,
                )
                driver_logs[job_name] = logs
                # Diagnostic: report log capture status
                if logs is None:
                    print_warning(f"{job_name}: no driver logs (pod not found)")
                elif len(logs) == 0:
                    print_warning(f"{job_name}: driver logs empty (0 bytes)")
                else:
                    lines = logs.strip().split("\n")
                    console.print(
                        f"  {job_name}: captured {len(logs):,} bytes ({len(lines)} lines)"
                    )
                    # Show first line to verify format
                    if lines:
                        first = lines[0][:80] + "..." if len(lines[0]) > 80 else lines[0]
                        console.print(f"    first: {first}")
            except Exception as e:
                driver_logs[job_name] = None
                print_warning(f"{job_name}: log capture failed: {e}")

        # Stop streaming jobs
        console.print("[bold]Stopping streaming jobs...[/bold]")
        for _job_type, job_name in submitted:
            try:
                k8s.delete_custom_resource(
                    group="sparkoperator.k8s.io",
                    version="v1beta2",
                    plural="sparkapplications",
                    name=f"lakebench-{job_name}",
                    namespace=namespace,
                )
                print_success(f"Stopped: lakebench-{job_name}")
            except Exception as e:
                print_warning(f"Could not stop {job_name}: {e}")

        _journal_safe(
            j.record,
            EventType.STREAMING_STOP,
            message="Streaming pipeline stopped",
            details={"duration_seconds": run_duration},
        )

        # Record streaming metrics (from pre-captured driver logs)
        console.print()
        console.print("[bold]Parsing streaming metrics...[/bold]")
        for _job_type, job_name in submitted:
            logs = driver_logs.get(job_name)
            if logs:
                try:
                    streaming_metrics = collector.parse_streaming_logs(
                        logs,
                        job_name,
                    )
                    # Diagnostic: report what was parsed
                    console.print(
                        f"  {job_name}: {streaming_metrics.total_batches} batches, "
                        f"{streaming_metrics.total_rows_processed:,} rows"
                    )
                    if streaming_metrics.total_batches == 0:
                        # Show a sample of the logs to debug pattern mismatch
                        lines = [line for line in logs.split("\n") if line.strip()]
                        if lines:
                            console.print("    [dim]no batches parsed -- sample lines:[/dim]")
                            for sample in lines[:3]:
                                truncated = sample[:100] + "..." if len(sample) > 100 else sample
                                console.print(f"      {truncated}")
                except Exception as e:
                    print_warning(f"{job_name}: parse failed: {e}")
                    streaming_metrics = StreamingJobMetrics(
                        job_name=f"lakebench-{job_name}",
                        job_type=job_name,
                    )
            else:
                console.print(f"  {job_name}: no logs to parse")
                streaming_metrics = StreamingJobMetrics(
                    job_name=f"lakebench-{job_name}",
                    job_type=job_name,
                )

            streaming_metrics.elapsed_seconds = run_duration
            streaming_metrics.success = pipeline_success
            if streaming_metrics.elapsed_seconds > 0 and streaming_metrics.total_rows_processed > 0:
                streaming_metrics.throughput_rps = (
                    streaming_metrics.total_rows_processed / streaming_metrics.elapsed_seconds
                )
            collector.record_streaming(streaming_metrics)

        # Aggregate in-stream benchmark rounds
        if not skip_benchmark:
            try:
                from lakebench.metrics import aggregate_benchmark_rounds

                rounds = collector.current_run.benchmark_rounds if collector.current_run else []
                if rounds:
                    aggregated = aggregate_benchmark_rounds(rounds)
                    collector.record_benchmark(aggregated)
                    console.print()
                    console.print(
                        f"  In-stream median QpH: [bold]{aggregated.qph:.1f}[/bold] "
                        f"({len(rounds)} rounds)"
                    )
                    _print_rounds_summary(console, rounds)
            except Exception as e:
                print_warning(f"Benchmark aggregation failed: {e}")

        # Summary
        console.print(
            Panel(
                f"[green]Sustained pipeline completed![/green]\n\n"
                f"  Duration: {run_duration}s ({run_duration / 60:.0f} min)\n"
                f"  Streaming jobs: {len(submitted)}\n\n"
                f"Query results: lakebench query --example count\n"
                f"Generate report: lakebench report",
                title="Sustained Pipeline Complete",
                expand=False,
            )
        )

    except K8sConnectionError as e:
        print_error(f"Kubernetes connection failed: {e}")
        pipeline_success = False
        _journal_safe(j.end_command, success=False, message=str(e))
        raise typer.Exit(1)  # noqa: B904
    finally:
        # Measure actual S3 bucket sizes before saving metrics
        try:
            from lakebench.s3 import S3Client

            s3_cfg = cfg.platform.storage.s3
            s3_client = S3Client(
                endpoint=s3_cfg.endpoint,
                access_key=s3_cfg.access_key,
                secret_key=s3_cfg.secret_key,
                region=s3_cfg.region,
                path_style=s3_cfg.path_style,
                ca_cert=s3_cfg.ca_cert,
                verify_ssl=s3_cfg.verify_ssl,
            )
            print_info("Measuring actual S3 bucket sizes...")
            _total_s3_objects = collector.record_actual_sizes(
                s3_client,
                s3_cfg.buckets.bronze,
                s3_cfg.buckets.silver,
                s3_cfg.buckets.gold,
            )
        except Exception as e:
            _total_s3_objects = 0
            console.print(f"  [yellow]Could not measure S3 sizes: {e}[/yellow]")

        run_metrics = collector.end_run(success=pipeline_success)
        if run_metrics:
            # Collect platform metrics from Prometheus (best-effort)
            _collect_platform_metrics(cfg, run_metrics)

            # Build pipeline benchmark (stage-matrix view)
            try:
                from lakebench.metrics import build_pipeline_benchmark

                pb = build_pipeline_benchmark(
                    run_metrics,
                    datagen_output_gb=_datagen_output_gb,
                    datagen_output_rows=_datagen_output_rows,
                )
                pb.total_s3_objects = _total_s3_objects
                run_metrics.pipeline_benchmark = pb
                if pb.pipeline_mode == PipelineMode.SUSTAINED.value:
                    if pb.sustained_throughput_rps > 0:
                        latency_str = (
                            "/".join(f"{v:.0f}" for v in pb.stage_latency_profile)
                            if pb.stage_latency_profile
                            else "n/a"
                        )
                        freshness_label = "freshness"
                        freshness_val = pb.data_freshness_seconds
                        if (pb.query_time_freshness_seconds or 0) > 0:
                            freshness_label = "freshness (at query time)"
                            freshness_val = pb.query_time_freshness_seconds
                        freshness_str = (
                            f"{freshness_val:.1f}s" if freshness_val is not None else "n/a"
                        )
                        print_info(
                            f"Pipeline Score: {freshness_str} {freshness_label}"
                            f" | {pb.sustained_throughput_rps:,.0f} rows/s sustained"
                            f" | {latency_str}ms latency (b/s/g)"
                        )
                elif pb.time_to_value_seconds > 0:
                    print_info(
                        f"Pipeline Score: {pb.time_to_value_seconds:.1f}s time-to-value"
                        f" | {pb.pipeline_throughput_gb_per_second:.3f} GB/s throughput"
                    )
            except Exception as e:
                console.print(f"  [yellow]Could not build pipeline benchmark: {e}[/yellow]")

            metrics_path = metrics_storage.save_run(run_metrics)
            print_info(f"Metrics saved to {metrics_path}")
            print_info(f"Run ID: {run_id}")

        _journal_safe(j.end_command, success=pipeline_success)


@app.command()
def stop(
    config_file: Annotated[
        Path | None,
        typer.Argument(
            help="Path to configuration YAML file (default: ./lakebench.yaml)",
        ),
    ] = None,
    file_option: Annotated[
        Path | None,
        typer.Option(
            "--file",
            "-f",
            help="Path to configuration YAML file (alternative to positional argument)",
        ),
    ] = None,
) -> None:
    """Stop running streaming jobs.

    Deletes all streaming SparkApplications (bronze-ingest, silver-stream,
    gold-refresh) from the cluster.
    """

    config_file = resolve_config_path(config_file, file_option)
    try:
        cfg = load_config(config_file)
    except ConfigError as e:
        print_error(f"Config error: {e}")
        raise typer.Exit(1)  # noqa: B904

    namespace = cfg.get_namespace()
    k8s = get_k8s_client(
        context=cfg.platform.kubernetes.context,
        namespace=namespace,
    )

    j = journal_open(config_file, config_name=cfg.name)
    j.begin_command(CommandName.STOP, {})

    streaming_names = ["bronze-ingest", "silver-stream", "gold-refresh"]
    stopped = 0

    console.print(
        Panel(
            f"Stopping streaming jobs for: [bold]{cfg.name}[/bold]",
            expand=False,
        )
    )

    for name in streaming_names:
        try:
            k8s.delete_custom_resource(
                group="sparkoperator.k8s.io",
                version="v1beta2",
                plural="sparkapplications",
                name=f"lakebench-{name}",
                namespace=namespace,
            )
            print_success(f"Stopped: lakebench-{name}")
            stopped += 1
        except Exception as e:
            print_info(f"lakebench-{name}: not running ({e})")

    if stopped > 0:
        print_success(f"Stopped {stopped} streaming job(s)")
    else:
        print_info("No streaming jobs were running")

    _journal_safe(
        j.record,
        EventType.STREAMING_STOP,
        message=f"Stopped {stopped} streaming jobs",
        details={"stopped": stopped},
    )
    _journal_safe(j.end_command, success=True)


@app.command()
def info(
    config_file: Annotated[
        Path | None,
        typer.Argument(
            help="Path to configuration YAML file (default: ./lakebench.yaml)",
        ),
    ] = None,
    file_option: Annotated[
        Path | None,
        typer.Option(
            "--file",
            "-f",
            help="Path to configuration YAML file (alternative to positional argument)",
        ),
    ] = None,
) -> None:
    """Show configuration summary with scale dimensions and compute guidance.

    Displays a concise overview of the recipe configuration including
    schema, scale factor, derived dimensions, compute guidance,
    catalog, table format, and query engine.
    """
    config_file = resolve_config_path(config_file, file_option)
    try:
        cfg = load_config(config_file)
    except ConfigError as e:
        print_error(f"Config error: {e}")
        raise typer.Exit(1)  # noqa: B904

    # Auto-size resources based on scale (tier guidance only)
    from lakebench.config.autosizer import resolve_auto_sizing

    resolve_auto_sizing(cfg)

    from lakebench.config.autosizer import _resolve_datagen_mode
    from lakebench.config.scale import compute_guidance as _compute_guidance
    from lakebench.spark.job import _JOB_PROFILES, _scale_executor_count

    spark = cfg.platform.compute.spark
    s3 = cfg.platform.storage.s3
    arch = cfg.architecture
    workload = arch.workload
    scale = workload.datagen.get_effective_scale()
    dims = cfg.get_scale_dimensions()
    guidance = _compute_guidance(scale)

    # Derive workload profile: {schema}-{mode}
    effective_mode = _resolve_datagen_mode(cfg)
    workload_profile = f"{workload.schema_type.value}-{effective_mode}"

    is_sustained = arch.pipeline.mode == PipelineMode.SUSTAINED

    # Per-job executor counts with auto/override labels
    override_map = {
        "bronze-verify": spark.bronze_executors,
        "silver-build": spark.silver_executors,
        "gold-finalize": spark.gold_executors,
    }
    executor_parts = []
    for job_name, override_val in override_map.items():
        auto_count = _scale_executor_count(_JOB_PROFILES[job_name], scale)
        if override_val is not None:
            executor_parts.append(f"{job_name}={override_val} (override)")
        else:
            executor_parts.append(f"{job_name}={auto_count} (auto)")

    # Streaming executor counts
    streaming_override_map = {
        "bronze-ingest": spark.bronze_ingest_executors,
        "silver-stream": spark.silver_stream_executors,
        "gold-refresh": spark.gold_refresh_executors,
    }
    streaming_executor_parts = []
    for job_name, override_val in streaming_override_map.items():
        auto_count = _scale_executor_count(_JOB_PROFILES[job_name], scale)
        if override_val is not None:
            streaming_executor_parts.append(f"{job_name}={override_val} (override)")
        else:
            streaming_executor_parts.append(f"{job_name}={auto_count} (auto)")

    # Build info lines
    lines = [
        ("Deployment", cfg.name),
        ("Namespace", cfg.get_namespace()),
        ("Workload", workload_profile),
        ("Schema", workload.schema_type.value),
        ("Scale", f"{scale}"),
        ("Customers", f"{dims.customers:,}"),
        ("Events/customer", f"~{dims.events_per_customer}"),
        ("Date range", f"{dims.date_range_days} days"),
        ("Approx rows", f"{dims.approx_rows:,}"),
        ("Pipeline mode", f"{arch.pipeline.mode.value}"),
        ("Processing", f"{arch.pipeline.pattern.value} (bronze > silver > gold)"),
        ("Catalog", f"{arch.catalog.type.value}"),
        ("Table format", f"{arch.table_format.type.value} {arch.table_format.iceberg.version}"),
        ("Query engine", f"{arch.query_engine.type.value}"),
        ("Parallelism", str(workload.datagen.parallelism)),
        (
            "Compute tier",
            f"{guidance.tier_name} (rec: {guidance.recommended_executors} executors, {guidance.recommended_memory})",
        ),
    ]

    if is_sustained:
        sustained_cfg = arch.pipeline.sustained
        lines += [
            ("Executors", ", ".join(streaming_executor_parts)),
            (
                "Trigger intervals",
                f"bronze={sustained_cfg.bronze_trigger_interval}, silver={sustained_cfg.silver_trigger_interval}, gold={sustained_cfg.gold_refresh_interval}",
            ),
            ("Run duration", f"{sustained_cfg.run_duration}s"),
        ]
    else:
        lines += [
            ("Executors", ", ".join(executor_parts)),
        ]

    lines += [
        ("S3 endpoint", s3.endpoint or "(not set)"),
        ("Buckets", f"{s3.buckets.bronze}, {s3.buckets.silver}, {s3.buckets.gold}"),
    ]

    # Add monitoring info if enabled
    obs = cfg.observability
    if obs.enabled:
        prom_status = "enabled" if obs.prometheus_stack_enabled else "disabled"
        graf_status = "enabled" if obs.dashboards_enabled else "disabled"
        lines.append(
            (
                "Prometheus",
                f"{prom_status} (retention={obs.retention}, storage={obs.storage})",
            )
        )
        lines.append(("Grafana", graf_status))

    # Format as panel
    max_label = max(len(label) for label, _ in lines)
    formatted = "\n".join(
        f"[dim]{label + ':':<{max_label + 1}}[/dim] [bold]{value}[/bold]" for label, value in lines
    )

    console.print(Panel(formatted, title=f"Lakebench: {cfg.name}", expand=False))

    if guidance.warning:
        console.print(f"  [yellow]Warning: {guidance.warning}[/yellow]")

    # Check cluster feasibility
    try:
        k8s = get_k8s_client()
        cap = k8s.get_cluster_capacity()
        if cap is None:
            raise ValueError("Could not detect cluster capacity")
        cluster_cores = cap.total_cpu_millicores // 1000

        # Quick feasibility check using the recommend logic
        from lakebench.config.scale import full_compute_guidance as _full_guidance

        full_g = _full_guidance(scale)

        # Calculate requirements (simplified version of recommend's logic)
        spark_cores = full_g.spark.recommended_executors * full_g.spark.recommended_cores
        datagen_cores = full_g.datagen.parallelism * int(full_g.datagen.cpu)
        trino_cores = int(full_g.trino.coordinator_cpu) + full_g.trino.worker_replicas * int(
            full_g.trino.worker_cpu
        )
        if is_sustained:
            # Sustained: datagen + streaming spark + trino all run concurrently
            streaming_cores = sum(
                _scale_executor_count(_JOB_PROFILES[j], scale) * _JOB_PROFILES[j]["executor_cores"]
                for j in ("bronze-ingest", "silver-stream", "gold-refresh")
            )
            peak_cores = datagen_cores + streaming_cores + trino_cores + 4
        else:
            # Batch: datagen and spark are sequential (never overlap)
            peak_cores = max(spark_cores, datagen_cores) + trino_cores + 4
        needed_cores = int(peak_cores * 1.15)

        if cluster_cores >= needed_cores:
            console.print(
                f"  [green]Cluster OK:[/green] {cluster_cores} cores available, {needed_cores} needed"
            )
        else:
            console.print(
                f"  [red]Cluster undersized:[/red] {cluster_cores} cores available, {needed_cores} needed"
            )
            console.print("  [dim]Run 'lakebench recommend' to find max feasible scale[/dim]")
    except Exception as e:
        logger.debug("Could not check cluster feasibility: %s", e)


# =============================================================================
# Enterprise Query Examples
# =============================================================================

EXAMPLE_QUERIES: dict[str, tuple[str, str]] = {
    "count": (
        "Row counts per table",
        """SELECT 'silver.customer_interactions_enriched' AS table_name, count(*) AS row_count
FROM lakehouse.silver.customer_interactions_enriched
UNION ALL
SELECT 'gold.customer_executive_dashboard', count(*)
FROM lakehouse.gold.customer_executive_dashboard""",
    ),
    "revenue": (
        "Daily revenue with 7-day moving average",
        """SELECT
  interaction_date,
  total_daily_revenue,
  ROUND(avg_transaction_value, 2) AS avg_txn,
  daily_active_customers AS dau,
  ROUND(AVG(total_daily_revenue) OVER (
    ORDER BY interaction_date
    ROWS BETWEEN 6 PRECEDING AND CURRENT ROW
  ), 2) AS revenue_ma7
FROM lakehouse.gold.customer_executive_dashboard
ORDER BY interaction_date DESC
LIMIT 30""",
    ),
    "channels": (
        "Channel revenue breakdown",
        """SELECT
  interaction_date,
  web_revenue,
  mobile_revenue,
  store_revenue,
  call_center_revenue,
  total_daily_revenue,
  web_interactions + mobile_interactions + store_interactions AS total_interactions,
  conversions
FROM lakehouse.gold.customer_executive_dashboard
ORDER BY interaction_date DESC
LIMIT 30""",
    ),
    "engagement": (
        "Engagement and churn risk summary",
        """SELECT
  interaction_date,
  daily_active_customers,
  ROUND(avg_engagement_score, 2) AS avg_engagement,
  high_churn_risk_count,
  medium_churn_risk_count,
  support_tickets_created,
  ROUND(avg_satisfaction_score, 2) AS avg_satisfaction,
  loyalty_member_interactions,
  total_points_earned
FROM lakehouse.gold.customer_executive_dashboard
ORDER BY interaction_date DESC
LIMIT 30""",
    ),
    "funnel": (
        "Daily conversion funnel",
        """SELECT
  interaction_date,
  awareness_interactions,
  consideration_interactions,
  conversions,
  retention_interactions,
  ROUND(CAST(conversions AS DOUBLE) / NULLIF(awareness_interactions, 0) * 100, 2) AS conversion_rate_pct
FROM lakehouse.gold.customer_executive_dashboard
ORDER BY interaction_date DESC
LIMIT 30""",
    ),
    "clv": (
        "Lifetime value estimates by day",
        """SELECT
  interaction_date,
  daily_active_customers,
  ROUND(total_estimated_ltv, 2) AS total_ltv,
  ROUND(avg_estimated_ltv, 2) AS avg_ltv,
  total_transactions,
  ROUND(avg_transaction_value, 2) AS avg_txn_value,
  ROUND(largest_transaction, 2) AS max_txn
FROM lakehouse.gold.customer_executive_dashboard
ORDER BY interaction_date DESC
LIMIT 30""",
    ),
}


def _run_query_repl(
    config_file: Path,
    timeout: int,
    output_format: str,
) -> None:
    """Interactive SQL REPL for the configured query engine."""
    import sys

    from rich.prompt import Prompt

    from lakebench.benchmark.executor import get_executor

    if not sys.stdin.isatty():
        print_error("Interactive mode requires a terminal")
        raise typer.Exit(1)

    config_file = resolve_config_path(config_file)
    try:
        cfg = load_config(config_file)
    except ConfigError as e:
        print_error(f"Config error: {e}")
        raise typer.Exit(1)  # noqa: B904

    namespace = cfg.get_namespace()

    try:
        executor = get_executor(cfg, namespace)
    except ValueError as e:
        print_error(str(e))
        raise typer.Exit(1)  # noqa: B904

    console.print(
        Panel(
            f"Lakebench SQL REPL ({executor.engine_name()})\n"
            f"Namespace: {namespace}\n"
            f"Format: {output_format} | Timeout: {timeout}s\n"
            f"Type 'exit', 'quit', or Ctrl+D to quit",
            expand=False,
        )
    )

    query_count = 0
    while True:
        try:
            sql = Prompt.ask("\n[bold cyan]SQL[/bold cyan]")
        except (EOFError, KeyboardInterrupt):
            break

        sql = sql.strip()

        # Exit commands
        if sql.lower() in ("exit", "quit", ".quit", "\\q"):
            break

        # Skip empty input
        if not sql:
            continue

        # Strip trailing semicolon
        if sql.endswith(";"):
            sql = sql[:-1]

        query_count += 1

        try:
            result = executor.execute_query(sql, timeout=timeout)
        except RuntimeError as e:
            print_error(str(e))
            continue

        if not result.success:
            print_error(result.error or "Query failed")
            continue

        # Display results
        output = result.raw_output
        rows = output.split("\n") if output else []
        row_count = result.rows_returned

        if rows:
            if output_format == "json":
                import json

                data = [row.split("\t") for row in rows]
                console.print(json.dumps({"rows": data, "count": len(data)}, indent=2))
            elif output_format == "csv":
                import csv
                import io

                buf = io.StringIO()
                writer = csv.writer(buf)
                for row in rows:
                    writer.writerow(row.split("\t"))
                console.print(buf.getvalue().strip())
            else:  # table
                for line in rows[:50]:
                    console.print(line)
                if row_count > 50:
                    console.print(f"[dim]... ({row_count - 50} more rows)[/dim]")

        console.print(f"[green]{row_count} rows in {result.duration_seconds:.2f}s[/green]")

    console.print(f"\n[dim]Executed {query_count} queries. Goodbye![/dim]")


@app.command()
def query(
    config_file: Annotated[
        Path | None,
        typer.Argument(
            help="Path to configuration YAML file (default: ./lakebench.yaml)",
        ),
    ] = None,
    file_option: Annotated[
        Path | None,
        typer.Option(
            "--file",
            "-f",
            help="Path to configuration YAML file (alternative to positional argument)",
        ),
    ] = None,
    sql: Annotated[
        str | None,
        typer.Option(
            "--sql",
            "-q",
            help="SQL query to execute",
        ),
    ] = None,
    example: Annotated[
        str | None,
        typer.Option(
            "--example",
            "-e",
            help="Run a built-in example query (count, revenue, channels, engagement, funnel, clv)",
        ),
    ] = None,
    file: Annotated[
        Path | None,
        typer.Option(
            "--file",
            help="Read SQL from file (use '-' for stdin)",
        ),
    ] = None,
    interactive: Annotated[
        bool,
        typer.Option(
            "--interactive",
            "-i",
            help="Start interactive SQL shell (REPL)",
        ),
    ] = False,
    output_format: Annotated[
        str,
        typer.Option(
            "--format",
            "-o",
            help="Output format: table (default), json, csv",
        ),
    ] = "table",
    show_query: Annotated[
        bool,
        typer.Option(
            "--show-query",
            help="Show the SQL query before executing",
        ),
    ] = False,
    query_timeout: Annotated[
        int,
        typer.Option(
            "--timeout",
            "-t",
            help="Query timeout in seconds",
        ),
    ] = 120,
) -> None:
    """Execute SQL queries against the configured query engine.

    Run custom SQL, built-in examples, read from file, or start interactive shell.
    Results can be displayed as table, JSON, or CSV.

    Examples:

        lakebench query --example count

        lakebench query --sql "SELECT count(*) FROM lakehouse.gold.customer_executive_dashboard"

        lakebench query --file query.sql

        lakebench query --file - < query.sql

        lakebench query --interactive

        lakebench query --example count --format json
    """
    import sys

    from lakebench.metrics import QueryMetrics

    config_file = resolve_config_path(config_file, file_option)

    # Validate mutually exclusive options
    sources = sum(1 for x in [sql, example, file, interactive] if x)
    if sources > 1:
        print_error("Specify only one of: --sql, --example, --file, --interactive")
        raise typer.Exit(1)

    # Handle interactive mode early
    if interactive:
        _run_query_repl(config_file, query_timeout, output_format)
        return

    # Handle file input
    query_name = "custom"
    if file is not None:
        if str(file) == "-":
            if sys.stdin.isatty():
                print_error("No input from stdin (pipe SQL or use --sql/--example)")
                raise typer.Exit(1)
            sql = sys.stdin.read().strip()
            query_name = "stdin"
        else:
            try:
                sql = file.read_text().strip()
                query_name = file.stem
            except FileNotFoundError:
                print_error(f"File not found: {file}")
                raise typer.Exit(1)  # noqa: B904
            except Exception as e:
                print_error(f"Error reading file: {e}")
                raise typer.Exit(1)  # noqa: B904
    elif example:
        if example not in EXAMPLE_QUERIES:
            print_error(f"Unknown example: {example}")
            print_info(f"Available: {', '.join(EXAMPLE_QUERIES.keys())}")
            raise typer.Exit(1)
        query_name = example
        _, sql = EXAMPLE_QUERIES[example]
    elif not sql:
        # No input specified - show help
        console.print(Panel("Built-in Enterprise Query Examples", expand=False))
        table = Table()
        table.add_column("Name", style="cyan")
        table.add_column("Description")
        for name, (desc, _) in EXAMPLE_QUERIES.items():
            table.add_row(name, desc)
        console.print(table)
        print_info("Usage: lakebench query <config> --example <name>")
        print_info('Usage: lakebench query <config> --sql "SELECT ..."')
        print_info("Usage: lakebench query <config> --file query.sql")
        print_info("Usage: lakebench query <config> --interactive")
        return

    if not sql:
        print_error("No SQL query provided")
        raise typer.Exit(1)

    # Load config
    try:
        cfg = load_config(config_file)
    except ConfigError as e:
        print_error(f"Config error: {e}")
        raise typer.Exit(1)  # noqa: B904

    namespace = cfg.get_namespace()

    # Journal
    j = journal_open(config_file, config_name=cfg.name)
    j.begin_command(CommandName.QUERY, {"query_name": query_name})

    if show_query or example:
        console.print(f"\n[dim]Query ({query_name}):[/dim]")
        console.print(f"[dim]{sql}[/dim]\n")

    # Execute via QueryExecutor
    from lakebench.benchmark.executor import get_executor

    try:
        executor = get_executor(cfg, namespace)
    except ValueError as e:
        print_error(str(e))
        _journal_safe(j.end_command, success=False, message=str(e))
        raise typer.Exit(1)  # noqa: B904

    try:
        result = executor.execute_query(sql, timeout=query_timeout)
    except FileNotFoundError:
        print_error("kubectl not found on PATH")
        _journal_safe(j.end_command, success=False, message="kubectl not found")
        raise typer.Exit(1)  # noqa: B904
    except RuntimeError as e:
        print_error(str(e))
        print_info("Is the query engine deployed? Run: lakebench status")
        _journal_safe(j.end_command, success=False, message=str(e))
        raise typer.Exit(1)  # noqa: B904

    elapsed = result.duration_seconds

    if not result.success:
        print_error(f"Query failed ({elapsed:.2f}s)")
        if result.error:
            console.print(f"[red]{result.error}[/red]")
        _journal_safe(
            j.record,
            EventType.QUERY_EXECUTED,
            message=f"Query '{query_name}' failed",
            success=False,
            details={
                "query_name": query_name,
                "elapsed_seconds": round(elapsed, 3),
                "success": False,
            },
        )
        _journal_safe(j.end_command, success=False, message="Query failed")
        raise typer.Exit(1)

    # Parse and display results
    output = result.raw_output
    rows = output.split("\n") if output else []
    row_count = result.rows_returned

    if rows:
        if output_format == "json":
            import json

            parsed = [row.split("\t") for row in rows if row.strip()]
            if len(parsed) > 1:
                headers = [h.strip().strip('"') for h in parsed[0]]
                data = [
                    dict(zip(headers, [v.strip().strip('"') for v in r], strict=False))
                    for r in parsed[1:]
                ]
            else:
                data = [{str(i): v.strip().strip('"') for i, v in enumerate(r)} for r in parsed]
            console.print(json.dumps({"rows": data, "count": len(data)}, indent=2))
        elif output_format == "csv":
            import csv
            import io

            buf = io.StringIO()
            writer = csv.writer(buf)
            for row in rows:
                if row.strip():
                    writer.writerow([c.strip().strip('"') for c in row.split("\t")])
            console.print(buf.getvalue().strip())
        else:  # table (default)
            console.print()
            for line in rows[:50]:
                console.print(line)
            if row_count > 50:
                console.print(f"[dim]... ({row_count - 50} more rows)[/dim]")

    console.print(f"\n[green]{row_count} rows in {elapsed:.2f}s[/green]")

    _journal_safe(
        j.record,
        EventType.QUERY_EXECUTED,
        message=f"Query '{query_name}' returned {row_count} rows in {elapsed:.2f}s",
        success=True,
        details={
            "query_name": query_name,
            "elapsed_seconds": round(elapsed, 3),
            "rows": row_count,
            "success": True,
        },
    )
    _journal_safe(j.end_command, success=True)

    # Record query metrics
    query_metrics = QueryMetrics(
        query_name=query_name,
        query_text=sql,
        elapsed_seconds=elapsed,
        rows_returned=row_count,
        success=True,
    )

    # Try to append to latest run's metrics
    from lakebench.metrics import MetricsStorage

    storage = MetricsStorage()
    latest_run = storage.get_latest_run()
    if latest_run:
        latest_run.queries.append(query_metrics)
        storage.save_run(latest_run)
        print_info(f"Query metrics appended to run {latest_run.run_id}")


@app.command()
def benchmark(
    config_file: Annotated[
        Path | None,
        typer.Argument(
            help="Path to configuration YAML file (default: ./lakebench.yaml)",
        ),
    ] = None,
    file_option: Annotated[
        Path | None,
        typer.Option(
            "--file",
            "-f",
            help="Path to configuration YAML file (alternative to positional argument)",
        ),
    ] = None,
    mode: Annotated[
        str | None,
        typer.Option(
            "--mode",
            "-m",
            help="Benchmark mode: power, throughput, or composite (overrides config)",
        ),
    ] = None,
    streams: Annotated[
        int | None,
        typer.Option(
            "--streams",
            "-s",
            help="Number of concurrent query streams for throughput/composite (overrides config)",
        ),
    ] = None,
    cold: Annotated[
        bool,
        typer.Option(
            "--cold",
            help="Flush Iceberg metadata cache before each query (cold run)",
        ),
    ] = False,
    iterations: Annotated[
        int,
        typer.Option(
            "--iterations",
            "-n",
            help="Number of iterations per query (>1 uses median)",
        ),
    ] = 1,
    query_class: Annotated[
        str | None,
        typer.Option(
            "--class",
            "-c",
            help="Run only queries of a specific class (scan, analytics, gold)",
        ),
    ] = None,
) -> None:
    """Run query benchmark and compute QpH.

    Executes 8 analytical queries against the Customer 360 pipeline
    and reports Queries per Hour (QpH) throughput.

    Modes:

        power       Single sequential query stream (default)

        throughput   N concurrent query streams

        composite    Power + throughput, geometric mean QpH

    Examples:

        lakebench benchmark test-config.yaml

        lakebench benchmark test-config.yaml --cold

        lakebench benchmark test-config.yaml --iterations 5

        lakebench benchmark test-config.yaml --mode throughput --streams 8

        lakebench benchmark test-config.yaml --mode composite --streams 4

        lakebench benchmark test-config.yaml --class scan
    """
    from lakebench.benchmark import BenchmarkRunner
    from lakebench.metrics import BenchmarkMetrics, MetricsStorage

    config_file = resolve_config_path(config_file, file_option)

    try:
        cfg = load_config(config_file)
    except ConfigError as e:
        print_error(f"Config error: {e}")
        raise typer.Exit(1)  # noqa: B904

    scale = cfg.architecture.workload.datagen.get_effective_scale()
    cache_mode = "cold" if cold else None  # None = let runner use config default

    # Resolve effective mode for display
    bench_cfg = cfg.architecture.benchmark
    effective_mode = mode or bench_cfg.mode.value
    effective_streams = streams if streams is not None else bench_cfg.streams
    effective_cache = cache_mode or bench_cfg.cache

    console.print(
        Panel(
            f"Lakebench Query Benchmark\n"
            f"{'=' * 25}\n"
            f"Scale: {scale}\n"
            f"Mode: {effective_mode}"
            + (f" ({effective_streams} streams)" if effective_mode != "power" else "")
            + f" ({iterations} iteration{'s' if iterations > 1 else ''})\n"
            f"Cache: {effective_cache}" + (f"\nClass: {query_class}" if query_class else ""),
            expand=False,
        )
    )

    # Journal
    j = journal_open(config_file, config_name=cfg.name)
    j.begin_command(
        CommandName.BENCHMARK,
        {
            "mode": effective_mode,
            "streams": effective_streams,
            "cold": cold,
            "iterations": iterations,
            "query_class": query_class,
        },
    )

    _journal_safe(
        j.record,
        EventType.BENCHMARK_START,
        message="Benchmark started",
        details={"mode": effective_mode, "cache": effective_cache, "scale": scale},
    )

    try:
        runner = BenchmarkRunner(cfg)
        run_result = runner.run(
            mode=mode,
            cache=cache_mode,
            iterations=iterations,
            streams=streams,
            query_class=query_class,
        )
    except RuntimeError as e:
        print_error(str(e))
        _journal_safe(j.end_command, success=False, message=str(e))
        raise typer.Exit(1)  # noqa: B904

    # Handle composite (returns tuple) vs single result
    if isinstance(run_result, tuple):
        power_result, throughput_result, composite_result = run_result
        _display_power_results(power_result)
        _display_throughput_results(throughput_result)
        console.print(
            f"\n  [bold]Composite QpH: {composite_result.qph:.1f}[/bold]  "
            f"(geometric mean of power {power_result.qph:.1f} "
            f"and throughput {throughput_result.qph:.1f})"
        )
        primary_result = composite_result
    else:
        if run_result.mode == "throughput":
            _display_throughput_results(run_result)
        else:
            _display_power_results(run_result)
        primary_result = run_result

    # Save to latest metrics if available
    storage = MetricsStorage()
    latest_run = storage.get_latest_run()
    if latest_run:
        bench_metrics = BenchmarkMetrics(
            mode=primary_result.mode,
            cache=primary_result.cache,
            scale=primary_result.scale,
            qph=primary_result.qph,
            total_seconds=primary_result.total_seconds,
            queries=[q.to_dict() for q in primary_result.queries],
            iterations=primary_result.iterations,
            streams=primary_result.streams,
            stream_results=[s.to_dict() for s in primary_result.stream_results],
        )
        latest_run.benchmark = bench_metrics
        storage.save_run(latest_run)
        print_info(f"Benchmark metrics appended to run {latest_run.run_id}")

    _journal_safe(
        j.record,
        EventType.BENCHMARK_COMPLETE,
        message=f"Benchmark complete: QpH={primary_result.qph:.1f}",
        success=True,
        details={
            "mode": primary_result.mode,
            "qph": round(primary_result.qph, 1),
            "total_seconds": round(primary_result.total_seconds, 2),
            "queries_passed": sum(1 for q in primary_result.queries if q.success),
            "queries_total": len(primary_result.queries),
            "streams": primary_result.streams,
        },
    )
    _journal_safe(j.end_command, success=True)


def _display_power_results(result: Any) -> None:
    """Display power benchmark results."""
    console.print()
    for qr in result.queries:
        status = "[green]PASS[/green]" if qr.success else "[red]FAIL[/red]"
        name_padded = f"{qr.query.name[:4]}  {qr.query.display_name}"
        console.print(
            f"  {name_padded:<40} {qr.elapsed_seconds:>7.2f}s   "
            f"{qr.rows_returned:>6} rows   {status}"
        )

    console.print(f"\n  Total: {result.total_seconds:.2f}s")
    console.print(f"  [bold]Power QpH: {result.qph:.1f}[/bold]")


def _display_throughput_results(result: Any) -> None:
    """Display throughput benchmark results."""
    console.print()
    console.print(f"  [bold]Throughput run: {result.streams} streams[/bold]")
    for sr in result.stream_results:
        status = "[green]PASS[/green]" if sr.success else "[red]FAIL[/red]"
        console.print(
            f"    Stream {sr.stream_id}:  {len(sr.queries):>2} queries  "
            f"{sr.total_seconds:>7.1f}s  {status}"
        )
    console.print(f"\n  Wall clock: {result.total_seconds:.1f}s")
    console.print(f"  [bold]Throughput QpH: {result.qph:.1f}[/bold]")


@app.command()
def report(
    metrics_dir: Annotated[
        Path,
        typer.Option(
            "--metrics",
            "-m",
            help="Directory containing run subdirectories",
        ),
    ] = Path(DEFAULT_OUTPUT_DIR) / "runs",
    run_id: Annotated[
        str | None,
        typer.Option(
            "--run",
            "-r",
            help="Specific run ID to report on (default: latest)",
        ),
    ] = None,
    list_runs: Annotated[
        bool,
        typer.Option(
            "--list",
            "-l",
            help="List available runs instead of generating report",
        ),
    ] = False,
    summary: Annotated[
        bool,
        typer.Option(
            "--summary",
            "-s",
            help="Print key scores to the terminal (with or without HTML generation)",
        ),
    ] = False,
) -> None:
    """Generate benchmark report from collected metrics.

    Creates an HTML report inside the per-run directory.
    Use --summary to print key scores to the terminal.
    """
    from lakebench.metrics import MetricsStorage
    from lakebench.reports import ReportGenerator

    storage = MetricsStorage(metrics_dir)

    # List runs mode
    if list_runs:
        runs = storage.list_runs()
        if not runs:
            print_warning(f"No runs found in {metrics_dir}")
            return

        console.print(Panel(f"Available runs in [bold]{metrics_dir}[/bold]", expand=False))

        table = Table()
        table.add_column("Run ID", style="cyan")
        table.add_column("Deployment")
        table.add_column("Date")
        table.add_column("Status")
        table.add_column("Duration")

        for r in runs:
            status = "[green]Passed[/green]" if r.get("success") else "[red]Failed[/red]"
            elapsed = f"{r.get('total_elapsed_seconds', 0):.1f}s"
            date = r.get("start_time", "")[:10] if r.get("start_time") else ""
            table.add_row(
                r.get("run_id", ""),
                r.get("deployment_name", ""),
                date,
                status,
                elapsed,
            )

        console.print(table)
        return

    # Generate report
    try:
        generator = ReportGenerator(metrics_dir)
        report_path = generator.generate_report(run_id)
    except ValueError as e:
        print_error(str(e))
        print_info("Use 'lakebench report --list' to see available runs")
        raise typer.Exit(1)  # noqa: B904

    # Print summary to terminal
    if summary:
        resolved_id = run_id
        if not resolved_id:
            # Extract run ID from report path (run-<id>/report.html)
            resolved_id = report_path.parent.name.removeprefix("run-")
        metrics = storage.load_run(resolved_id)
        if metrics:
            _print_report_summary(metrics)

    console.print(
        Panel(
            f"[green]Report generated successfully![/green]\n\n"
            f"Output: {report_path}\n\n"
            + ("[dim]Scores printed above.[/dim]" if summary else "Open in browser to view."),
            title="Report Generated",
            expand=False,
        )
    )


@app.command()
def results(
    metrics_dir: Annotated[
        Path,
        typer.Option(
            "--metrics",
            "-m",
            help="Directory containing run subdirectories",
        ),
    ] = Path(DEFAULT_OUTPUT_DIR) / "runs",
    run_id: Annotated[
        str | None,
        typer.Option(
            "--run",
            "-r",
            help="Specific run ID (default: latest)",
        ),
    ] = None,
    output_format: Annotated[
        str,
        typer.Option(
            "--format",
            "-f",
            help="Output format: table, json, csv",
        ),
    ] = "table",
) -> None:
    """Display pipeline benchmark results.

    Shows the stage-matrix view of pipeline performance -- each stage
    as a column with consistent metrics as rows. Use --format json or
    --format csv for machine-readable output.
    """
    import json as _json

    from lakebench.metrics import MetricsStorage

    storage = MetricsStorage(metrics_dir)

    if run_id:
        metrics = storage.load_run(run_id)
    else:
        metrics = storage.get_latest_run()

    if metrics is None:
        print_error("No run found" + (f" with ID {run_id}" if run_id else ""))
        print_info("Use 'lakebench report --list' to see available runs")
        raise typer.Exit(1)

    pb = metrics.pipeline_benchmark
    if pb is None:
        print_warning("This run does not have pipeline benchmark data.")
        print_info("Pipeline benchmark is generated for runs after this feature was added.")
        raise typer.Exit(1)

    if output_format == "json":
        console.print(_json.dumps(pb.to_dict(), indent=2))
        return

    if output_format == "csv":
        import csv
        import io

        matrix = pb.to_matrix()
        if not matrix:
            print_warning("No stages in pipeline benchmark.")
            return
        # Build CSV: rows are metrics, columns are stages
        metric_keys = list(next(iter(matrix.values())).keys())
        buf = io.StringIO()
        writer = csv.writer(buf)
        writer.writerow(["metric"] + list(matrix.keys()))
        for key in metric_keys:
            row = [key] + [matrix[stage].get(key, "") for stage in matrix]
            writer.writerow(row)
        console.print(buf.getvalue())
        return

    # Table format (default)
    console.print()
    console.print(
        Panel(
            f"[bold]Pipeline Benchmark:[/bold] {pb.deployment_name} (run {pb.run_id})\n"
            f"Mode: {pb.pipeline_mode} | "
            f"Time-to-Value: {pb.time_to_value_seconds:.1f}s | "
            f"Throughput: {pb.pipeline_throughput_gb_per_second:.3f} GB/s",
            expand=False,
        )
    )

    table = Table(show_header=True, header_style="bold")
    table.add_column("Stage", style="cyan")
    table.add_column("Engine")
    table.add_column("Time(s)", justify="right")
    table.add_column("In(GB)", justify="right")
    table.add_column("Out(GB)", justify="right")
    table.add_column("In Rows", justify="right")
    table.add_column("Out Rows", justify="right")
    table.add_column("GB/s", justify="right")
    table.add_column("Rows/s", justify="right")
    table.add_column("Execs", justify="right")
    table.add_column("Status")

    for stage in pb.stages:
        status = "[green]OK[/green]" if stage.success else "[red]FAIL[/red]"
        table.add_row(
            stage.stage_name,
            stage.engine,
            f"{stage.elapsed_seconds:.1f}",
            f"{stage.input_size_gb:.3f}" if stage.input_size_gb > 0 else "-",
            f"{stage.output_size_gb:.3f}" if stage.output_size_gb > 0 else "-",
            f"{stage.input_rows:,}" if stage.input_rows > 0 else "-",
            f"{stage.output_rows:,}" if stage.output_rows > 0 else "-",
            f"{stage.throughput_gb_per_second:.4f}" if stage.throughput_gb_per_second > 0 else "-",
            f"{stage.throughput_rows_per_second:.0f}"
            if stage.throughput_rows_per_second > 0
            else "-",
            str(stage.executor_count) if stage.executor_count > 0 else "-",
            status,
        )

    console.print(table)

    # Query stage detail
    if pb.query_benchmark:
        qb = pb.query_benchmark
        console.print(
            f"\n  Query Benchmark: {qb.mode} mode | QpH: {qb.qph:.1f} | {qb.total_seconds:.1f}s"
        )

    console.print(
        f"\n  Pipeline: {pb.total_elapsed_seconds:.1f}s total"
        f" | {pb.time_to_value_seconds:.1f}s time-to-value"
        f" | {pb.pipeline_throughput_gb_per_second:.3f} GB/s"
    )
    console.print()


@app.command()
def logs(
    component: Annotated[
        str,
        typer.Argument(
            help="Component to show logs for (postgres, hive, polaris, trino, spark-driver)",
        ),
    ],
    config_file: Annotated[
        Path | None,
        typer.Argument(
            help="Path to configuration YAML file (default: ./lakebench.yaml)",
        ),
    ] = None,
    file_option: Annotated[
        Path | None,
        typer.Option(
            "--file",
            help="Path to configuration YAML file (alternative to positional argument)",
        ),
    ] = None,
    follow: Annotated[
        bool,
        typer.Option(
            "--follow",
            "-f",
            help="Follow log output",
        ),
    ] = False,
    lines: Annotated[
        int,
        typer.Option(
            "--lines",
            "-n",
            help="Number of lines to show",
        ),
    ] = 100,
) -> None:
    """Stream logs from a component.

    Shows logs from the specified Lakebench component.

    Valid components: postgres, hive, polaris, trino, spark-driver
    """
    # Map component names to pod selectors
    COMPONENT_SELECTORS = {
        "postgres": ("app.kubernetes.io/component=postgres", None),
        "hive": ("app.kubernetes.io/component=metastore", None),
        "polaris": ("app.kubernetes.io/component=polaris", None),
        "trino": ("app.kubernetes.io/component=trino-coordinator", None),
        "spark-driver": ("spark-role=driver", None),
    }

    if component not in COMPONENT_SELECTORS:
        print_error(f"Unknown component: {component}")
        print_info(f"Valid components: {', '.join(COMPONENT_SELECTORS.keys())}")
        raise typer.Exit(1)

    config_file = resolve_config_path(config_file, file_option)

    try:
        cfg = load_config(config_file)
    except ConfigError as e:
        print_error(f"Config error: {e}")
        raise typer.Exit(1)  # noqa: B904

    namespace = cfg.get_namespace()
    label_selector, container = COMPONENT_SELECTORS[component]

    console.print(
        f"Fetching logs for [bold]{component}[/bold] in namespace [bold]{namespace}[/bold]"
    )

    # Build kubectl logs command
    cmd = [
        "kubectl",
        "logs",
        "-l",
        label_selector,
        "-n",
        namespace,
        f"--tail={lines}",
    ]
    if container:
        cmd.extend(["-c", container])
    if follow:
        cmd.append("-f")

    try:
        if follow:
            # Stream logs
            process = subprocess.Popen(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
            )
            try:
                if process.stdout:
                    for line in iter(process.stdout.readline, ""):
                        console.print(_strip_ansi(line), end="")
            except KeyboardInterrupt:
                process.terminate()
                print_info("\nLog streaming stopped")
        else:
            # One-shot log fetch
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=30,
            )
            if result.returncode != 0:
                if "not found" in result.stderr.lower() or not result.stderr.strip():
                    print_warning(f"No pods found for {component}")
                    print_info("Is the component deployed? Run: lakebench status")
                else:
                    print_error(result.stderr.strip())
                return

            if result.stdout:
                console.print(_strip_ansi(result.stdout))
            else:
                print_warning(f"No logs available for {component}")

    except subprocess.TimeoutExpired:
        print_error("Timed out fetching logs")
    except FileNotFoundError:
        print_error("kubectl not found on PATH")


@app.command()
def journal(
    session_id: Annotated[
        str | None,
        typer.Option(
            "--session",
            "-s",
            help="Show events for a specific session",
        ),
    ] = None,
    last: Annotated[
        int,
        typer.Option(
            "--last",
            "-n",
            help="Show last N sessions",
        ),
    ] = 10,
    journal_dir: Annotated[
        Path,
        typer.Option(
            "--dir",
            help="Journal directory",
        ),
    ] = Path(DEFAULT_OUTPUT_DIR) / "journal",
) -> None:
    """View command and execution provenance journal.

    Shows the history of all lakebench operations including deploys,
    data generation, pipeline runs, and teardowns.

    Examples:

        lakebench journal

        lakebench journal --session 20260129-120000-a1b2c3
    """
    j = Journal(journal_dir)

    if session_id:
        events = j.load_session_events(session_id)
        if not events:
            print_warning(f"No events found for session {session_id}")
            return

        console.print(Panel(f"Session: [bold]{session_id}[/bold]", expand=False))
        table = Table()
        table.add_column("Time", style="dim", width=19)
        table.add_column("Event", style="cyan")
        table.add_column("Command", style="bold")
        table.add_column("Message")
        table.add_column("Status", justify="center")

        for event in events:
            ts = event.get("timestamp", "")[:19]
            etype = event.get("event_type", "").split(".")[-1]
            cmd = event.get("command", "") or ""
            msg = event.get("message", "")
            success = event.get("success")
            status = ""
            if success is True:
                status = "[green]OK[/green]"
            elif success is False:
                status = "[red]FAIL[/red]"
            table.add_row(ts, etype, cmd, msg, status)

        console.print(table)
    else:
        sessions = j.list_sessions()
        if not sessions:
            print_warning(f"No journal sessions found in {journal_dir}")
            return

        console.print(Panel("Lakebench Journal Sessions", expand=False))
        table = Table()
        table.add_column("Session ID", style="cyan")
        table.add_column("Config")
        table.add_column("Started", style="dim")
        table.add_column("Events", justify="right")
        table.add_column("Commands")
        table.add_column("Status")

        for s in sessions[:last]:
            status = "[green]closed[/green]" if s["closed"] else "[yellow]active[/yellow]"
            cmds = ", ".join(s.get("commands", []))
            table.add_row(
                s["session_id"],
                s.get("config_name", ""),
                s.get("started", "")[:19],
                str(s.get("event_count", 0)),
                cmds,
                status,
            )

        console.print(table)


# =============================================================================
# Cluster Sizing Guidance
# =============================================================================


@app.command()
def recommend(
    cluster_cores: Annotated[
        int | None,
        typer.Option(
            "--cores",
            "-c",
            help="Total cluster CPU cores (auto-detects from connected cluster if not set)",
        ),
    ] = None,
    cluster_memory_gb: Annotated[
        int | None,
        typer.Option(
            "--memory",
            "-m",
            help="Total cluster memory in GB (auto-detects from connected cluster if not set)",
        ),
    ] = None,
    target_scale: Annotated[
        int | None,
        typer.Option(
            "--scale",
            "-s",
            help="Target scale factor to check requirements for",
        ),
    ] = None,
    extended: Annotated[
        bool,
        typer.Option(
            "--extended",
            "-e",
            help="[deprecated: use --slow-datagen] Reduces datagen parallelism to fit cluster.",
            hidden=True,
        ),
    ] = False,
    slow_datagen: Annotated[
        bool,
        typer.Option(
            "--slow-datagen",
            help="Reduce datagen parallelism to fit smaller clusters (slower generation, same Spark resources).",
        ),
    ] = False,
    mode: Annotated[
        str | None,
        typer.Option(
            "--mode",
            help="Pipeline mode: batch (sequential phases) or sustained (concurrent datagen+streaming). Default: batch.",
        ),
    ] = None,
) -> None:
    """Show cluster sizing guidance for lakebench workloads.

    This command helps answer two questions:
    - "I have cluster X -- what scale can I run?"
    - "I want to run scale X -- what cluster do I need?"

    Without arguments, auto-detects connected cluster capacity and shows
    the maximum feasible scale. Use --scale to check requirements for
    a specific target (any scale from 1 to 100,000,000+ is supported).

    Scale maps linearly to data volume: scale 1 = ~10 GB, scale 100 = ~1 TB,
    scale 100,000 = ~1 PB.

    Examples:

        lakebench recommend                     # auto-detect cluster, find max scale
        lakebench recommend --cores 64 --memory 256
        lakebench recommend --scale 100         # what do I need for scale 100?
        lakebench recommend --scale 100000      # what do I need for 1 PB?
    """
    from lakebench.config.scale import customer360_dimensions, full_compute_guidance
    from lakebench.spark.job import _JOB_PROFILES, _scale_executor_count

    # Resolve --extended -> --slow-datagen
    use_slow_datagen = slow_datagen or extended
    if extended:
        console.print("[yellow]--extended is deprecated, use --slow-datagen instead[/yellow]\n")

    # Resolve pipeline mode
    pipeline_mode = mode or "batch"
    is_sustained = pipeline_mode == "sustained"

    def format_data_size(gb: float) -> str:
        """Format data size in human-readable units."""
        if gb >= 1_000_000_000:  # 1 EB = 10^9 GB
            return f"{gb / 1_000_000_000:.1f} EB"
        if gb >= 1_000_000:  # 1 PB = 10^6 GB
            return f"{gb / 1_000_000:.1f} PB"
        if gb >= 1_000:
            return f"{gb / 1_000:.1f} TB"
        return f"{gb:.0f} GB"

    def _streaming_resources(scale: int) -> tuple[int, int]:
        """Compute total streaming cores and memory for sustained mode."""
        streaming_jobs = ("bronze-ingest", "silver-stream", "gold-refresh")
        cores = sum(
            _scale_executor_count(_JOB_PROFILES[j], scale) * _JOB_PROFILES[j]["executor_cores"]
            for j in streaming_jobs
        )
        mem_gi = sum(
            _scale_executor_count(_JOB_PROFILES[j], scale)
            * int(_JOB_PROFILES[j]["executor_memory"].rstrip("g"))
            for j in streaming_jobs
        )
        return cores, mem_gi

    def compute_cluster_requirements(scale: int) -> dict:
        """Compute minimum cluster requirements for a given scale."""
        dims = customer360_dimensions(scale)
        guidance = full_compute_guidance(scale)

        # Datagen
        datagen_cores = guidance.datagen.parallelism * int(guidance.datagen.cpu)
        datagen_mem_gi = guidance.datagen.parallelism * int(
            guidance.datagen.memory.rstrip("Gi").rstrip("gi")
        )

        # Trino (always running)
        trino_cores = int(guidance.trino.coordinator_cpu) + guidance.trino.worker_replicas * int(
            guidance.trino.worker_cpu
        )
        trino_mem_gi = int(
            guidance.trino.coordinator_memory.rstrip("Gi")
        ) + guidance.trino.worker_replicas * int(guidance.trino.worker_memory.rstrip("Gi"))

        # Infra overhead (Hive/Polaris, Postgres) ~4 cores, 8 Gi
        infra_cores = 4
        infra_mem_gi = 8

        if is_sustained:
            # Sustained: datagen + streaming spark + trino all run concurrently
            streaming_cores, streaming_mem = _streaming_resources(scale)
            peak_cores = datagen_cores + streaming_cores + trino_cores + infra_cores
            peak_mem = datagen_mem_gi + streaming_mem + trino_mem_gi + infra_mem_gi
        else:
            # Batch: datagen runs first, then Spark. They don't overlap.
            spark_cores = guidance.spark.recommended_executors * guidance.spark.recommended_cores
            spark_mem_gi = guidance.spark.recommended_executors * int(
                guidance.spark.recommended_memory.rstrip("g")
            )
            peak_cores = max(spark_cores, datagen_cores) + trino_cores + infra_cores
            peak_mem = max(spark_mem_gi, datagen_mem_gi) + trino_mem_gi + infra_mem_gi

        # Add 15% headroom for system pods
        total_cores = int(peak_cores * 1.15)
        total_mem_gi = int(peak_mem * 1.15)

        result = {
            "scale": scale,
            "data_gb": dims.approx_bronze_gb,
            "tier": guidance.spark.tier_name,
            "datagen_pods": guidance.datagen.parallelism,
            "trino_workers": guidance.trino.worker_replicas,
            "total_cores": total_cores,
            "total_mem_gi": total_mem_gi,
        }

        if is_sustained:
            streaming_cores, _ = _streaming_resources(scale)
            result["streaming_executors"] = sum(
                _scale_executor_count(_JOB_PROFILES[j], scale)
                for j in ("bronze-ingest", "silver-stream", "gold-refresh")
            )
            result["streaming_cores"] = streaming_cores
        else:
            result["spark_executors"] = guidance.spark.recommended_executors
            result["spark_cores_per_exec"] = guidance.spark.recommended_cores
            result["spark_mem_per_exec"] = guidance.spark.recommended_memory

        return result

    def is_feasible(scale: int, cores: int, mem_gb: int) -> bool:
        """Check if a scale is feasible on given cluster resources."""
        reqs = compute_cluster_requirements(scale)
        return cores >= reqs["total_cores"] and mem_gb >= reqs["total_mem_gi"]

    def compute_slow_datagen_requirements(scale: int) -> dict:
        """Compute requirements assuming datagen runs with reduced parallelism.

        Datagen parallelism is reduced to fit the cluster. This means datagen
        takes longer, but Spark/streaming and Trino requirements remain.
        """
        dims = customer360_dimensions(scale)
        guidance = full_compute_guidance(scale)

        # Trino (always running)
        trino_cores = int(guidance.trino.coordinator_cpu) + guidance.trino.worker_replicas * int(
            guidance.trino.worker_cpu
        )
        trino_mem_gi = int(
            guidance.trino.coordinator_memory.rstrip("Gi")
        ) + guidance.trino.worker_replicas * int(guidance.trino.worker_memory.rstrip("Gi"))

        # Infra
        infra_cores = 4
        infra_mem_gi = 8

        if is_sustained:
            # Sustained slow-datagen: streaming + trino + infra (datagen reduced)
            streaming_cores, streaming_mem = _streaming_resources(scale)
            total_cores = streaming_cores + trino_cores + infra_cores
            total_mem_gi = streaming_mem + trino_mem_gi + infra_mem_gi
        else:
            # Batch slow-datagen: spark + trino + infra (datagen reduced)
            spark_cores = guidance.spark.recommended_executors * guidance.spark.recommended_cores
            spark_mem_gi = guidance.spark.recommended_executors * int(
                guidance.spark.recommended_memory.rstrip("g")
            )
            total_cores = spark_cores + trino_cores + infra_cores
            total_mem_gi = spark_mem_gi + trino_mem_gi + infra_mem_gi

        # Add 15% headroom
        total_cores = int(total_cores * 1.15)
        total_mem_gi = int(total_mem_gi * 1.15)

        result = {
            "scale": scale,
            "data_gb": dims.approx_bronze_gb,
            "tier": guidance.spark.tier_name,
            "datagen_pods": guidance.datagen.parallelism,
            "trino_workers": guidance.trino.worker_replicas,
            "total_cores": total_cores,
            "total_mem_gi": total_mem_gi,
        }

        if is_sustained:
            streaming_cores, _ = _streaming_resources(scale)
            result["streaming_executors"] = sum(
                _scale_executor_count(_JOB_PROFILES[j], scale)
                for j in ("bronze-ingest", "silver-stream", "gold-refresh")
            )
            result["streaming_cores"] = streaming_cores
        else:
            result["spark_executors"] = guidance.spark.recommended_executors
            result["spark_cores_per_exec"] = guidance.spark.recommended_cores
            result["spark_mem_per_exec"] = guidance.spark.recommended_memory

        return result

    def is_feasible_slow_datagen(scale: int, cores: int, mem_gb: int) -> bool:
        """Check feasibility with reduced datagen (Spark/streaming-limited)."""
        reqs = compute_slow_datagen_requirements(scale)
        return cores >= reqs["total_cores"] and mem_gb >= reqs["total_mem_gi"]

    def find_max_scale(cores: int, mem_gb: int, use_slow_datagen: bool = False) -> int:
        """Binary search to find max feasible scale."""
        check_fn = is_feasible_slow_datagen if use_slow_datagen else is_feasible
        if not check_fn(1, cores, mem_gb):
            return 0

        # Binary search between 1 and 100 million (1 EB)
        lo, hi = 1, 100_000_000
        while lo < hi:
            mid = (lo + hi + 1) // 2
            if check_fn(mid, cores, mem_gb):
                lo = mid
            else:
                hi = mid - 1
        return lo

    # Case 1: User wants to know requirements for a specific scale
    if target_scale is not None:
        reqs = compute_cluster_requirements(target_scale)
        dims = customer360_dimensions(target_scale)

        mode_label = "sustained" if is_sustained else "batch"
        if is_sustained:
            workload_line = (
                f"  Streaming:       {reqs['streaming_executors']} executors "
                f"({reqs['streaming_cores']} cores)"
            )
        else:
            workload_line = (
                f"  Spark:           {reqs['spark_executors']} x "
                f"{reqs['spark_cores_per_exec']} cores x "
                f"{reqs['spark_mem_per_exec']}"
            )

        console.print(
            Panel(
                f"[bold]Scale {target_scale:,}[/bold] ({format_data_size(reqs['data_gb'])})\n\n"
                f"[dim]Tier:[/dim]             {reqs['tier']}\n"
                f"[dim]Rows:[/dim]             {dims.approx_rows:,}\n"
                f"[dim]Mode:[/dim]             {mode_label}\n\n"
                f"[yellow]Minimum Cluster Requirements:[/yellow]\n"
                f"  CPU cores:       [bold]{reqs['total_cores']:,}[/bold]\n"
                f"  Memory:          [bold]{reqs['total_mem_gi']:,} GB[/bold]\n\n"
                f"[dim]Breakdown:[/dim]\n"
                f"{workload_line}\n"
                f"  Datagen:         {reqs['datagen_pods']} pods\n"
                f"  Trino:           {reqs['trino_workers']} workers\n"
                f"  + infra overhead",
                title="Cluster Requirements",
                expand=False,
            )
        )
        return

    # Case 2: Auto-detect cluster or use provided specs
    detected_cores = cluster_cores
    detected_mem = cluster_memory_gb
    cluster_source = "user-provided"

    if detected_cores is None or detected_mem is None:
        # Try to detect from connected cluster
        try:
            k8s = get_k8s_client()
            cap = k8s.get_cluster_capacity()
            if cap is not None:
                if detected_cores is None:
                    detected_cores = cap.total_cpu_millicores // 1000
                if detected_mem is None:
                    detected_mem = int(cap.total_memory_bytes / (1024**3))
                cluster_source = f"detected ({cap.node_count} nodes)"
        except Exception as e:
            console.print(f"[yellow]Could not detect cluster capacity: {e}[/yellow]")
            console.print("[dim]Use --cores and --memory to specify manually[/dim]\n")

    if detected_cores is None or detected_mem is None:
        # Show reference table without cluster info
        mode_label = "sustained" if is_sustained else "batch"
        console.print(f"[bold]Cluster Sizing Reference[/bold] (mode: {mode_label})\n")
        console.print(
            "[dim]Tip: Connect to a cluster or use --cores/--memory for max scale calculation[/dim]\n"
        )
        console.print("[dim]Use --scale N to see requirements for any specific scale[/dim]\n")

        # Show common reference points
        table = Table(title="Common Scale Points")
        table.add_column("Scale", justify="right", style="cyan")
        table.add_column("Data Size", justify="right")
        table.add_column("Min Cores", justify="right")
        table.add_column("Min Memory", justify="right")

        for scale in [1, 10, 100, 500, 1000, 10000, 100000]:
            reqs = compute_cluster_requirements(scale)
            table.add_row(
                f"{scale:,}",
                format_data_size(reqs["data_gb"]),
                f"{reqs['total_cores']:,}",
                f"{reqs['total_mem_gi']:,} GB",
            )

        console.print(table)
        return

    # Case 3: Find max feasible scale for this cluster
    max_scale = find_max_scale(detected_cores, detected_mem, use_slow_datagen=use_slow_datagen)
    max_scale_standard = find_max_scale(detected_cores, detected_mem, use_slow_datagen=False)
    max_scale_slow = find_max_scale(detected_cores, detected_mem, use_slow_datagen=True)

    mode_label = "sustained" if is_sustained else "batch"
    console.print(f"[bold]Cluster Capacity[/bold] ({cluster_source}, mode: {mode_label})")
    console.print(f"  CPU cores: [bold]{detected_cores}[/bold]")
    console.print(f"  Memory:    [bold]{detected_mem} GB[/bold]\n")

    if max_scale == 0:
        console.print("[yellow]Cluster is below minimum requirements for scale 1.[/yellow]")
        reqs = compute_cluster_requirements(1)
        console.print(
            f"[dim]Minimum for scale 1: {reqs['total_cores']} cores, {reqs['total_mem_gi']} GB RAM[/dim]"
        )
        return

    # Show both datagen modes
    std_reqs = compute_cluster_requirements(max_scale_standard)
    slow_reqs = compute_slow_datagen_requirements(max_scale_slow)

    if use_slow_datagen:
        console.print(
            "[bold yellow]Slow datagen:[/bold yellow] Datagen runs with reduced parallelism (slower generation, same compute resources)\n"
        )
        console.print(
            f"[green]Maximum scale (slow datagen):[/green] [bold]{max_scale_slow:,}[/bold] ({format_data_size(slow_reqs['data_gb'])})"
        )
        console.print(
            f"[dim]Standard max:              {max_scale_standard:,} ({format_data_size(std_reqs['data_gb'])})[/dim]\n"
        )
    else:
        console.print(
            f"[green]Maximum scale:[/green] [bold]{max_scale_standard:,}[/bold] ({format_data_size(std_reqs['data_gb'])})"
        )
        if max_scale_slow > max_scale_standard:
            console.print(
                f"[dim]With --slow-datagen:        {max_scale_slow:,} ({format_data_size(slow_reqs['data_gb'])})[/dim]"
            )
        console.print()

    # Use appropriate requirements function based on datagen mode
    req_fn = compute_slow_datagen_requirements if use_slow_datagen else compute_cluster_requirements
    check_fn = is_feasible_slow_datagen if use_slow_datagen else is_feasible

    # Build a cleaner table: only show FEASIBLE milestones + max + next infeasible tier
    # This avoids confusion from non-monotonic tier boundaries
    scale_points = []
    milestones = [1, 10, 50, 100, 500, 1000, 5000, 10000, 50000, 100000]

    # Only include milestones that are actually feasible
    for s in milestones:
        if s < max_scale and check_fn(s, detected_cores, detected_mem):
            scale_points.append(s)

    # Always include the max
    scale_points.append(max_scale)

    # Find the next milestone above max that's NOT feasible (to show "what you'd need")
    for s in milestones:
        if s > max_scale:
            scale_points.append(s)
            break
    # If no milestone above, use 2x max
    if (
        len(scale_points)
        == len(
            [s for s in milestones if s < max_scale and check_fn(s, detected_cores, detected_mem)]
        )
        + 1
    ):
        scale_points.append(max_scale * 2)

    table = Table(title="Scale Options")
    table.add_column("Scale", justify="right", style="cyan")
    table.add_column("Data", justify="right")
    table.add_column("Cores", justify="right")
    table.add_column("Memory", justify="right")
    table.add_column("Status")

    for scale in scale_points:
        reqs = req_fn(scale)
        feasible = check_fn(scale, detected_cores, detected_mem)

        if scale == max_scale:
            status = "[green bold]<- MAX[/green bold]"
        elif feasible:
            status = "[green]OK[/green]"
        else:
            cores_need = max(0, reqs["total_cores"] - detected_cores)
            mem_need = max(0, reqs["total_mem_gi"] - detected_mem)
            parts = []
            if cores_need > 0:
                parts.append(f"+{cores_need:,} cores")
            if mem_need > 0:
                parts.append(f"+{mem_need:,} GB")
            status = f"[red]needs {', '.join(parts)}[/red]"

        table.add_row(
            f"{scale:,}",
            format_data_size(reqs["data_gb"]),
            f"{reqs['total_cores']:,}",
            f"{reqs['total_mem_gi']:,} GB",
            status,
        )

    console.print(table)

    # Show next steps
    console.print()
    if use_slow_datagen:
        console.print("[dim]Slow datagen: generation runs slower to fit cluster resources[/dim]")
    console.print(f"[dim]Next: lakebench init --scale {max_scale}[/dim]")


# =============================================================================
# Entry Point
# =============================================================================


def main() -> None:
    """Main entry point for CLI."""
    app()


if __name__ == "__main__":
    main()
