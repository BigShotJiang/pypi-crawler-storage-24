"""L30: How It Works — systems diagram for telecom, AI, and control plane."""
LAYOUT_ID = "L30"
LAYOUT_NAME = "How It Works"
LAYOUT_DESC = "Layered systems diagram showing app, control plane, and network layers."
from .core import *

def L30_how_it_works(prs, bk, T, logo, ai_notes=None):
    S = SlideBuilder(prs, bk, T, logo, ai_notes=ai_notes or "L30 How It Works: layered systems diagram showing control plane, AI, and protocol layers")
    S.title("How it works")

    # Three horizontal layers stacked vertically
    layer_w = Inches(10.5); pad = Inches(0.4)
    lx = ML + Inches(0.7)  # centered

    layers = [("Your application", "SWML, RELAY SDK, REST API, webhooks"),
               ("SignalWire control plane", "Call routing, AI agents, conferencing, queuing, recording, compliance"),
               ("Network layer", "PSTN, SIP, WebRTC, WhatsApp, SMS, carrier interconnects")]
    accents = [T["emphasis"], FUCHSIA, T["muted"]]
    layer_h = Inches(1.3); gap = Inches(0.15)
    start_y = Inches(1.6)

    for i, (title, desc) in enumerate(layers):
        y = start_y + (layer_h + gap) * i
        # Layer box
        rect(S.s, lx, y, layer_w, layer_h, T["surface"])
        hline(S.s, lx, y, layer_w, accents[i], Inches(0.04))
        # Title left, description right
        txt(S.s, lx + pad, y + Inches(0.2), Inches(3.5), Inches(0.5),
            title, FONT_H, Pt(20), accents[i], bold=True)
        txt(S.s, lx + Inches(4.2), y + Inches(0.25), Inches(5.8), Inches(0.8),
            desc, FONT_B, Pt(16), T["text2"], line_spacing=1.3)

    # Arrows between layers
    arrow_x = lx + layer_w / 2
    for i in range(2):
        y = start_y + layer_h + gap * (i + 1) + layer_h * i - Inches(0.05)
        txt(S.s, arrow_x - Inches(0.3), y, Inches(0.6), Inches(0.3),
            "\u2195", FONT_H, Pt(18), T["subtle"], align=PP_ALIGN.CENTER)

    # Bottom note
    S.text("One platform, every protocol. Deterministic code governs AI and humans alike.",
           ML, 5.8, w=CW, h=0.5, size=16, color="muted", italic=True,
           align=PP_ALIGN.CENTER)
    S.done()
