"""L09: Table slide."""
LAYOUT_ID = "L09"
LAYOUT_NAME = "Table"
LAYOUT_DESC = "Structured data comparison with key takeaway."
from .core import *

def L09_table(prs, bk, T, logo, ai_notes=None):
    S = SlideBuilder(prs, bk, T, logo, ai_notes=ai_notes or "L09 Table: structured data comparison with key takeaway")
    S.title("Table headline: state the insight")
    # Table requires direct slide access
    s = S.s
    rows, cols = 5, 4
    ts = s.shapes.add_table(rows, cols, ML, Inches(1.6), CW, Inches(3.8))
    tbl = ts.table
    cw_t = int(CW / cols)
    for c in range(cols): tbl.columns[c].width = cw_t
    hdrs = ["Feature", "Starter", "Business", "Enterprise"]
    data = [["Local numbers", "$0.50/mo", "$0.50/mo", "Custom"],
             ["AI agent runtime", "$0.16/min", "$0.16/min", "Volume"],
             ["SIP trunking", "Metered", "Metered", "Committed"],
             ["Support", "Community", "Priority", "Dedicated"]]
    for c in range(cols):
        cl = tbl.cell(0, c); cl.text = hdrs[c]
        cl.fill.solid(); cl.fill.fore_color.rgb = BLUE
        for p in cl.text_frame.paragraphs:
            p.font.name = FONT_H; p.font.size = Pt(16)
            p.font.color.rgb = WHITE; p.font.bold = True
        cl.vertical_anchor = MSO_ANCHOR.MIDDLE
        cl.margin_left = Emu(91440); cl.margin_top = Emu(45720); cl.margin_bottom = Emu(45720)
    for r in range(1, rows):
        for c in range(cols):
            cl = tbl.cell(r, c); cl.text = data[r-1][c]
            bg = T["surface"] if r % 2 == 1 else T["raised"]
            cl.fill.solid(); cl.fill.fore_color.rgb = bg
            for p in cl.text_frame.paragraphs:
                p.font.name = FONT_B; p.font.size = Pt(16); p.font.color.rgb = T["text2"]
            cl.vertical_anchor = MSO_ANCHOR.MIDDLE
            cl.margin_left = Emu(91440); cl.margin_top = Emu(45720); cl.margin_bottom = Emu(45720)
            border_hex = "%02X%02X%02X" % (T["raised"][0], T["raised"][1], T["raised"][2])
            set_cell_border(cl, border_hex)
    S.text("Key takeaway from the data above.",
           ML, 5.6, w=9, h=0.5, size=16, color="muted", italic=True)
    S.done()
