"""L25: Full-Bleed Image with gradient overlay."""
LAYOUT_ID = "L25"
LAYOUT_NAME = "Full-Bleed Image"
LAYOUT_DESC = "Cinematic photo with gradient overlay and headline."
from .core import *

def L25_full_bleed_image(prs, bk, T, logo, ai_notes=None):
    S = SlideBuilder(prs, bk, T, logo, ai_notes=ai_notes or "L25 Full-Bleed Image: cinematic photo with gradient overlay and headline")
    s = S.s

    # Full-slide image placeholder
    rect(s, 0, 0, SW, SH, T["raised"])

    # Gradient overlay (dark at bottom for text readability)
    overlay = s.shapes.add_shape(MSO_SHAPE.RECTANGLE, 0, Inches(3.5), SW, Inches(4.0))
    overlay.line.fill.background()
    spPr = overlay._element.spPr
    for child in list(spPr):
        if child.tag.endswith(('solidFill', 'noFill', 'gradFill')):
            spPr.remove(child)
    gf = etree.SubElement(spPr, qn("a:gradFill"))
    gl = etree.SubElement(gf, qn("a:gsLst"))
    gs1 = etree.SubElement(gl, qn("a:gs"), attrib={"pos": "0"})
    c1 = etree.SubElement(gs1, qn("a:srgbClr"), attrib={"val": "0A0A12"})
    etree.SubElement(c1, qn("a:alpha"), attrib={"val": "0"})
    gs2 = etree.SubElement(gl, qn("a:gs"), attrib={"pos": "100000"})
    etree.SubElement(gs2, qn("a:srgbClr"), attrib={"val": "0A0A12"})
    etree.SubElement(gf, qn("a:lin"), attrib={"ang": "5400000", "scaled": "1"})

    S.text("[ Replace with full-bleed image ]",
           1.2, 0.5, w=5, h=0.5, size=16, color=GRAD["muted"], align=PP_ALIGN.CENTER)
    S.text("Cinematic headline on image",
           ML, 4.0, w=CW, h=1.2, font="h", size=TITLE_LG, color="white",
           bold=True, line_spacing=1.1)
    S.text("Supporting context that sits on the gradient overlay.",
           ML, 5.5, w=10, h=0.6, color="white")

    S.done()
