"""L02: Section Divider slide."""
LAYOUT_ID = "L02"
LAYOUT_NAME = "Section Divider"
LAYOUT_DESC = "Marks the start of a new section with large title and context."
from .core import *

def L02_section(prs, bk, T, logo, ai_notes=None):
    S = SlideBuilder(prs, bk, T, logo, ai_notes=ai_notes or "L02 Section Divider: marks the start of a new section")
    S.title("Section 1 - Title", large=True, top=2.5)
    S.text("Brief context for this section",
           ML, 4.6, w=Inches(7), h=0.7, color="muted")
    S.done()
