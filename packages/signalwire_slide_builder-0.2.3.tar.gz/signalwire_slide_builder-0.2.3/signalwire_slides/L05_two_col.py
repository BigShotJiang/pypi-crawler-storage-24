"""L05: Two-Column Comparison slide."""
LAYOUT_ID = "L05"
LAYOUT_NAME = "Two-Column"
LAYOUT_DESC = "Side-by-side comparison of two options or approaches."
from .core import *

def L05_two_col(prs, bk, T, logo, ai_notes=None):
    S = SlideBuilder(prs, bk, T, logo, ai_notes=ai_notes or "L05 Two-Column: side-by-side comparison of two options or approaches")
    S.title("Comparison headline goes here")
    left_items = ["Left column point one", "Left column point two", "Left column point three"]
    right_items = ["Right column point one", "Right column point two", "Right column point three"]
    S.two_col(
        "Column A", left_items,
        "Column B", right_items)
    S.done()
