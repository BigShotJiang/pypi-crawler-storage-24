"""L12: Big Number / KPI slide."""
LAYOUT_ID = "L12"
LAYOUT_NAME = "KPI"
LAYOUT_DESC = "Single headline metric at 96pt with context caption."
from .core import *

def L12_kpi(prs, bk, T, logo, ai_notes=None):
    S = SlideBuilder(prs, bk, T, logo, ai_notes=ai_notes or "L12 KPI: single headline metric with context caption")
    S.kpi(
        "2.7B",
        "Minutes processed annually",
        "KEY METRIC")
    S.done()
