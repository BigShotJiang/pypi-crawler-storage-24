"""L14: Architecture / Diagram slide."""
LAYOUT_ID = "L14"
LAYOUT_NAME = "Architecture"
LAYOUT_DESC = "Technical diagram placeholder with title and legend."
from .core import *

def L14_architecture(prs, bk, T, logo, ai_notes=None):
    S = SlideBuilder(prs, bk, T, logo, ai_notes=ai_notes or "L14 Architecture: technical diagram or system overview with legend")
    S.title("Diagram title goes here")
    S.image_area(ML, 1.5, CW, 4.8,
                 "[ Insert architecture diagram ]")
    S.text("Key assumptions or legend notes",
           ML + Inches(0.3), 5.8, w=8, h=0.4, size=CAPTION_SIZE, color="muted", italic=True)
    S.done()
