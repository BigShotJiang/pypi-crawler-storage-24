"""L29: Competitive Matrix — narrative comparison, not just a table."""
LAYOUT_ID = "L29"
LAYOUT_NAME = "Competitive Matrix"
LAYOUT_DESC = "Narrative comparison showing what each category can and cannot do."
from .core import *

def L29_competitive(prs, bk, T, logo, ai_notes=None):
    S = SlideBuilder(prs, bk, T, logo, ai_notes=ai_notes or "L29 Competitive Matrix: narrative comparison showing what each category can and cannot do")
    S.title("Not all platforms are built the same")

    # Three columns: category headers + capability rows
    col_w = Inches(3.65); gap = Inches(0.28); sy = 1.5
    headers = ["Legacy CPaaS", "AI-only vendors", "SignalWire"]
    accents = [T["muted"], T["subtle"], T["emphasis"]]
    header_colors = [T["muted"], T["subtle"], T["emphasis"]]

    for i in range(3):
        cx = ML + (col_w + gap) * i
        # Column header
        rect(S.s, cx, Inches(sy), col_w, Inches(0.6), T["surface"] if i < 2 else BLUE)
        color = T["text2"] if i < 2 else WHITE
        txt(S.s, cx + Inches(0.3), Inches(sy + 0.1), col_w - Inches(0.6), Inches(0.4),
            headers[i], FONT_H, Pt(18), color, bold=True, align=PP_ALIGN.CENTER)

    # Capability rows
    rows = ["Programmability", "Call authority", "AI governance", "Protocol handling"]
    # Cells: 0=weak, 1=partial, 2=strong
    cell_data = [["API bolted on", "None", "Native, composable"],
                  ["Middleware only", "None", "Full lifecycle"],
                  ["External, fragile", "Partial, no guardrails", "System-Directed AI"],
                  ["SIP only", "WebRTC only", "All protocols unified"]]

    row_h = Inches(0.85); row_start = sy + 0.7
    for r, (label, cells) in enumerate(zip(rows, cell_data)):
        ry = Inches(row_start + r * (0.85 + 0.08))
        # Row label
        txt(S.s, ML - Inches(0.1), ry + Inches(0.05), Inches(0.1), row_h,
            "", FONT_B, Pt(1), T["subtle"])  # spacer
        for c in range(3):
            cx = ML + (col_w + gap) * c
            bg = T["raised"] if r % 2 == 0 else T["surface"]
            if c == 2:
                bg = T["surface"] if r % 2 == 0 else T["raised"]
            rect(S.s, cx, ry, col_w, row_h, bg)
            # Row label in first column
            if c == 0:
                txt(S.s, cx + Inches(0.2), ry + Inches(0.05), Inches(1.6), row_h,
                    label, FONT_H, Pt(13), T["emphasis"], bold=True)
                txt(S.s, cx + Inches(1.9), ry + Inches(0.15), col_w - Inches(2.2), Inches(0.5),
                    cells[c], FONT_B, Pt(14), T["muted"])
            else:
                color = T["text_hi"] if c == 2 else T["muted"]
                txt(S.s, cx + Inches(0.2), ry + Inches(0.15), col_w - Inches(0.4), Inches(0.5),
                    cells[c], FONT_B, Pt(14), color, bold=(c == 2))

    S.done()
