"""L13: Case Study slide."""
LAYOUT_ID = "L13"
LAYOUT_NAME = "Case Study"
LAYOUT_DESC = "Customer story in three cards: challenge, solution, result."
from .core import *

def L13_case_study(prs, bk, T, logo, ai_notes=None):
    S = SlideBuilder(prs, bk, T, logo, ai_notes=ai_notes or "L13 Case Study: customer story in three parts: challenge, solution, result")
    S.label("CASE STUDY", top=0.4)
    S.title("Case study headline goes here", top=0.75)
    labels = ["Challenge", "Solution", "Result"]
    descs = ["Describe the problem the customer faced.",
              "Describe the solution and how it was implemented.",
              "Describe the measurable outcome."]
    accents = [T["emphasis"], BLUE, FUCHSIA]
    cw_c, gap = Inches(3.65), Inches(0.28)
    for i in range(3):
        cx = ML + (cw_c + gap) * i
        S.card(cx, 1.9, cw_c, Inches(4.5), accent=accents[i],
               title=labels[i], body_text=descs[i])
    S.done()
