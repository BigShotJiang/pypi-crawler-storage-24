"""FastPDF framework integrations."""
