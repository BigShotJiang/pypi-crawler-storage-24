import os
import sys
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
from src.dquant.models import VolClustGB, VolClustXGB, VolClustLightGB
import MetaTrader5 as mt5
import datetime as dt
import numpy as np
from arch import arch_model
import pandas as pd



if __name__ == '__main__':

    # ===================== НАСТРОЙКИ =====================
    symbol = "EURUSD"          # какой символ смотреть
    timeframe = mt5.TIMEFRAME_H1   # M1, M5, M15, H1, D1 и т.д.
    days_back = 1000             # сколько дней истории загрузить
    # ====================================================

    # Подключаемся к MT5
    if not mt5.initialize():
        print("Не удалось подключиться к MetaTrader5")
        quit()

    # Проверяем, что символ доступен
    if not mt5.symbol_select(symbol, True):
        print(f"Символ {symbol} не найден или не включён")
        mt5.shutdown()
        quit()

    # Вычисляем даты
    to_date = dt.datetime.now() + dt.timedelta(hours=3)
    from_date = to_date - dt.timedelta(days=days_back)

    # Загружаем бары
    rates = mt5.copy_rates_range(symbol, timeframe, from_date, to_date)

    mt5.shutdown()  # больше не нужен терминал

    if rates is None or len(rates) == 0:
        print("Нет данных!")
        quit()

    # Превращаем в DataFrame
    df = pd.DataFrame(rates)
    df['time'] = pd.to_datetime(df['time'], unit='s')  # правильное время
    df.set_index('time', inplace=True)


    df.rename(columns={
        'tick_volume': 'volume'
    }, inplace=True)



    #df = df.iloc[-20:]
    # Параметры для нижнего расположения
    #show_vol(df)

    print(f"Загружено {len(df)} баров с {df.index[0]} по {df.index[-1]}")

    """settings = {
        'loss': 'squared_error',
        'learning_rate': 0.1,
        'n_estimators': 1,
        'max_depth': 4,
        'min_samples_split': 5,
        'min_samples_leaf': 5,
        'subsample': 0.8,
        'random_state': 42,
        'warm_start': True
    }"""
    settings = {
        'objective': 'reg:squarederror',
        'learning_rate': 0.1,
        'n_estimators': 1,
        'max_depth': 3,
        'min_child_weight': 5,
        'subsample': 0.8,
        'random_state': 42
    }
    """settings = {
        'objective': 'regression',
        'learning_rate': 0.01,
        'n_estimators': 1,
        'max_depth': 3,
        'min_sum_hessian_in_leaf': 5,  # вместо min_child_weight
        'subsample': 0.8,  # или bagging_fraction
        'subsample_freq': 1,  # частота применения subsample
        'random_state': 42,
        'verbose': -1
    }"""
    model = VolClustXGB(settings, default=False, early_stopping=True)


    while True:
        match input(">> "):
            case "clear":
                os.system('cls')
            case "train":
                model.fit(df, 70, 20, 200, True)
            case "show":
                rez = model.forecast(df.iloc[-70:].copy(), show=True)
                print(rez)
            case "show train":
                model.show_train_results()
            case "save":
                model.save(str(input()))
            case "load":
                model.load(str(input()))
            case "exit":
                break

    # Вывод результатов
    #print(np.array(df[-30:]))

    #model.forecast(df.iloc[-20:].copy())
