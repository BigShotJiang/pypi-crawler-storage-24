#   Hyrrokkin - a library for building and running executable graphs
#
#   MIT License - Copyright (C) 2022-2025  Visual Topology Ltd
#
#   Permission is hereby granted, free of charge, to any person obtaining a copy of this software
#   and associated documentation files (the "Software"), to deal in the Software without
#   restriction, including without limitation the rights to use, copy, modify, merge, publish,
#   distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the
#   Software is furnished to do so, subject to the following conditions:
#
#   The above copyright notice and this permission notice shall be included in all copies or
#   substantial portions of the Software.
#
#   THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
#   BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
#   NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
#   DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
#   OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

from hyrrokkin.service.topology_endpoint import TopologyEndpoint
from hyrrokkin.api.topology import Topology

DEFAULT_PORT = 9103

class NotebookAdapter:

    def __init__(self, topology:Topology, port:int|None=None):
        """
        Experimental adapter for opening hyrrokkin's UI inside a jupyter or colab notebook

        Args:
            topology: a topology instance to work with
            port: a port number (optional).  If not provided, may be selected using portpicker with a fallback to 9103.
        """
        self.topology = topology
        if port is not None:
            self.port = port
        else:
            try:
                import portpicker
                self.port = portpicker.pick_unused_port()
            except:
                self.port = DEFAULT_PORT
        self.endpoint = TopologyEndpoint("localhost", self.port, "", self.topology, start_callback=lambda ep:None)
        self.endpoint.start()
        self.running = True

    def open_designer_in_cell(self,window_height:int=600):
        """
        Open the designer in a notebook cell

        Args:
            window_height: the height of the designer window in pixels
        """
        if not self.running:
            print("Unable to open - notebook adapter was closed")
            return
        try:
            from google.colab import output
            output.serve_kernel_port_as_iframe(self.port, path="/topology-designer.html", height=window_height)
        except:
            # try proxying with jupyter server proxy at <hub_domain>/user/<username>/proxy/<port>
            from IPython.display import display, HTML
            display(HTML('''
            <iframe id="designer_iframe" src="" width="95%" height="{WINDOW_HEIGHT}"></iframe>
            <script>
                var path_components = window.location.pathname.split("/");
                var ok = false;
                for(var idx=0; idx<path_components.length; idx++) {
                    if (idx > 0 && path_components[idx-1] === "user") {
                        ok = true;
                        break;
                    }
                }
                if (ok) {
                    var designer_path = path_components.slice(0,idx+1).join("/") + "/proxy/{PORT}/topology-designer.html";
                    document.getElementById("designer_iframe").src=designer_path;
                }
            </script>'''.replace("{PORT}",str(self.port)).replace("{WINDOW_HEIGHT}",str(window_height))))


    def open_designer_in_window(self):
        """
        Open the designer in a new window (currently requires google colab)
        """
        if not self.running:
            print("Unable to open - notebook adapter was closed")
            return
        try:
            from google.colab import output
            output.serve_kernel_port_as_window(self.port, path="/topology-designer.html")
        except:
            print("Unable to open designer in a window - only supported in google colab")

    def close(self):
        """
        Shut down the service
        """
        if self.running:
            self.endpoint.stop()
            self.running = False