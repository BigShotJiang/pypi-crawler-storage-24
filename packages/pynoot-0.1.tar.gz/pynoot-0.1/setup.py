from setuptools import setup, find_packages



setup(
    name='pynoot',
    version='0.1',
    packages=find_packages(),
    author='Nour Eldeen Ahmed',
    description='Arabic style Python library',
)