"""FL SDK CLI - scaffold, validate, test, and package model profiles."""

import json
import shutil
import sys
import zipfile
from pathlib import Path

import click

from .manifest import parse_manifest_file, _find_manifest_path, NAME_PATTERN


@click.group()
@click.version_option()
def cli():
    """FL SDK - Federated Learning model profile development kit."""


@cli.command()
@click.argument("name")
@click.option("--framework", default="pytorch", type=click.Choice(["pytorch", "tensorflow"]))
def init(name, framework):
    """Scaffold a new model profile directory."""
    if not NAME_PATTERN.match(name):
        click.echo(f"Error: name must match {NAME_PATTERN.pattern}", err=True)
        sys.exit(1)

    target = Path(name)
    if target.exists():
        click.echo(f"Error: directory '{name}' already exists", err=True)
        sys.exit(1)

    scaffold_dir = Path(__file__).parent / "scaffold"
    target.mkdir()

    # Copy scaffold files
    for src_file in ["model.py", "trainer.py"]:
        src = scaffold_dir / src_file
        if src.exists():
            shutil.copy2(src, target / src_file)

    # Generate model.yaml
    manifest_content = f"""name: {name}
description: "TODO: describe your model"
framework: {framework}

model:
  file: model.py
  class: SimpleModel

trainer:
  file: trainer.py

requirements: []

data:
  description: "TODO: describe the expected data format"
  required_files:
    - name: "train_data.pt"
      description: "Training data tensor"
    - name: "train_labels.pt"
      description: "Training labels tensor"
  optional_files:
    - name: "val_data.pt"
      description: "Validation data tensor"
    - name: "val_labels.pt"
      description: "Validation labels tensor"

hyperparameters:
  batch_size:
    default: 32
    type: int
    description: "Training batch size"
  learning_rate:
    default: 0.001
    type: float
    description: "Learning rate"

metrics:
  train:
    - name: train_loss
      display_name: "Training Loss"
      primary: true
    - name: num_samples
      type: int
      aggregate: sum
  validate:
    - name: val_loss
      display_name: "Validation Loss"
      primary: true
    - name: accuracy
      display_name: "Accuracy"
      format: percentage
      primary: true
  test: []
"""
    (target / "model.yaml").write_text(manifest_content)
    (target / "requirements.txt").write_text("# Add extra pip dependencies here\n")

    click.echo(f"Model profile scaffolded at ./{name}/")
    click.echo("Next steps:")
    click.echo(f"  1. Edit {name}/model.py with your model")
    click.echo(f"  2. Edit {name}/trainer.py with your trainer")
    click.echo(f"  3. Fill in {name}/model.yaml")
    click.echo(f"  4. Run: naira-fl-sdk validate ./{name}")


@cli.command()
@click.argument("model_dir", type=click.Path(exists=True))
def validate(model_dir):
    """Validate a model profile directory."""
    tdir = Path(model_dir).resolve()
    errors = []
    warnings = []

    # Find manifest (model.yaml or template.yaml fallback)
    try:
        manifest_path = _find_manifest_path(str(tdir))
    except FileNotFoundError:
        click.echo("FAIL: model.yaml not found")
        sys.exit(1)

    # Parse manifest
    try:
        manifest = parse_manifest_file(manifest_path)
    except Exception as e:
        click.echo(f"FAIL: manifest parse error: {e}")
        sys.exit(1)

    click.echo(f"Model: {manifest.name}")
    click.echo(f"Framework: {manifest.framework}")

    # Check model file
    model_file = tdir / manifest.model.file
    if not model_file.exists():
        errors.append(f"Model file not found: {manifest.model.file}")
    else:
        content = model_file.read_text()
        if f"class {manifest.model.class_name}" not in content:
            warnings.append(
                f"Model class '{manifest.model.class_name}' not found in {manifest.model.file}"
            )

    # Check trainer file
    trainer_file = tdir / manifest.trainer.file
    if not trainer_file.exists():
        errors.append(f"Trainer file not found: {manifest.trainer.file}")
    else:
        content = trainer_file.read_text()
        if "FLTrainer" not in content:
            warnings.append(f"FLTrainer not referenced in {manifest.trainer.file}")
        if "validate_data" not in content:
            warnings.append(f"validate_data() not found in {manifest.trainer.file}")

    # Check metrics schema
    if not manifest.metrics.train and not manifest.metrics.validate:
        errors.append("metrics section must define at least one train or validate metric")
    else:
        train_names = [m.name for m in manifest.metrics.train]
        val_names = [m.name for m in manifest.metrics.validate]
        click.echo(f"Metrics (train): {', '.join(train_names) or '(none)'}")
        click.echo(f"Metrics (validate): {', '.join(val_names) or '(none)'}")

    # Check requirements.txt if listed
    if manifest.requirements:
        click.echo(f"Requirements: {', '.join(manifest.requirements)}")

    # Report
    if errors:
        for e in errors:
            click.echo(f"  ERROR: {e}")
        sys.exit(1)

    for w in warnings:
        click.echo(f"  WARN: {w}")

    click.echo("PASS: model profile is valid")


@cli.command()
@click.argument("model_dir", type=click.Path(exists=True))
@click.option("--rounds", default=2, help="Number of simulation rounds")
@click.option("--data", "data_path", default=None, help="Path to data directory")
def test(model_dir, rounds, data_path):
    """Run a local FL simulation (no NVFlare required)."""
    from .simulator import run_simulation

    run_simulation(
        template_dir=model_dir,
        data_path=data_path,
        num_rounds=rounds,
    )


@cli.command()
@click.argument("model_dir", type=click.Path(exists=True))
@click.option("-o", "--output", default=None, help="Output zip file path")
def package(model_dir, output):
    """Package a model profile directory into a zip file for upload."""
    tdir = Path(model_dir).resolve()

    # Find manifest
    try:
        manifest_path = _find_manifest_path(str(tdir))
    except FileNotFoundError:
        click.echo("Error: model.yaml not found", err=True)
        sys.exit(1)

    try:
        manifest = parse_manifest_file(manifest_path)
    except Exception as e:
        click.echo(f"Error: invalid model profile: {e}", err=True)
        sys.exit(1)

    output_path = Path(output) if output else Path(f"{manifest.name}.zip")

    with zipfile.ZipFile(output_path, "w", zipfile.ZIP_DEFLATED) as zf:
        for file_path in tdir.rglob("*"):
            if file_path.is_file():
                # Skip __pycache__ and hidden files
                rel = file_path.relative_to(tdir)
                if any(p.startswith(".") or p == "__pycache__" for p in rel.parts):
                    continue
                zf.write(file_path, str(rel))

    click.echo(f"Packaged: {output_path} ({output_path.stat().st_size} bytes)")
