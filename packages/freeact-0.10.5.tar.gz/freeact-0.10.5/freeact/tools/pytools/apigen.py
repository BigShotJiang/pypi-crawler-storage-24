import logging
from pathlib import Path
from typing import Any

import mcpygen

from freeact.tools.pytools import MCPTOOLS_DIR
from freeact.tools.pytools.categories import Categories, list_categories

logger = logging.getLogger("freeact")


async def generate_mcp_sources(config: dict[str, dict[str, Any]], generated_dir: Path) -> None:
    """Generate Python API for MCP servers in `config`.

    For servers not already in `mcptools/` categories, generates Python API
    using `mcpygen.generate_mcp_sources`.

    Args:
        config: Dictionary mapping server names to server configurations.
        generated_dir: Directory for generated tool sources.
    """
    if not config:
        return

    categories: Categories = list_categories(base_dir=generated_dir)
    categories_mcptools = set(categories.mcptools)

    for name, params in config.items():
        if name not in categories_mcptools:
            logger.info(f"Generating Python API for MCP server: {name}")
            await mcpygen.generate_mcp_sources(name, params, generated_dir / MCPTOOLS_DIR)
