"""
TUI 面板组件 — ChatPanel / CommandPanel / BoardPanel / StatusPanel
纯终端风格：所有面板只有 RichLog，无独立输入框
"""

from __future__ import annotations

from textual.app import ComposeResult
from textual.widgets import Static, RichLog
from textual.containers import Vertical, Horizontal
from textual.widget import Widget
from textual.scrollbar import ScrollBar, ScrollBarRender
from rich.segment import Segment, Segments
from rich.style import Style
from rich.color import Color
from rich.table import Table

from .config import (
    COLOR_BG_PRIMARY, COLOR_BORDER,
    COLOR_HINT_BORDER, COLOR_HINT_TAB_ACTIVE, COLOR_HINT_TAB_DIM,
)
from .game_registry import get_renderer
from .module_state import ModuleStateManager, MSG, SYS, HISTORY


def _set_pane_subtitle(widget, text: str):
    """沿 DOM 向上找到 PaneWrapper 并设置 border_subtitle"""
    node = widget.parent
    while node is not None:
        if hasattr(node, 'pane_id'):
            node.border_subtitle = text
            return
        node = node.parent


# ═══════════════════════════════════════════════════════
#  圆角滚动条渲染器
# ═══════════════════════════════════════════════════════

class RoundedScrollBarRender(ScrollBarRender):
    """药丸形滚动条 — 用半块字符 ▄█▀ 组成圆头圆尾的拇指"""

    @classmethod
    def render_bar(
        cls,
        size: int = 25,
        virtual_size: float = 50,
        window_size: float = 20,
        position: float = 0,
        thickness: int = 1,
        vertical: bool = True,
        back_color: Color = Color.parse(COLOR_BG_PRIMARY),
        bar_color: Color = Color.parse(COLOR_BORDER),
    ) -> Segments:
        result = ScrollBarRender.render_bar(
            size=size, virtual_size=virtual_size, window_size=window_size,
            position=position, thickness=thickness, vertical=vertical,
            back_color=back_color, bar_color=bar_color,
        )
        if not vertical or not result.segments:
            return result

        segs = list(result.segments)
        # 找到拇指范围（有前景色的段即为拇指/部分块）
        thumb_indices = [
            i for i, seg in enumerate(segs)
            if seg.style and seg.style.color is not None
        ]
        if not thumb_indices:
            return result

        first, last = thumb_indices[0], thumb_indices[-1]
        meta = {"@mouse.down": "grab"}
        w = thickness
        cap_style = Style(color=bar_color, bgcolor=back_color, meta=meta)
        body_style = Style(color=bar_color, bgcolor=bar_color, meta=meta)

        if first == last:
            # 只有1格：用实心块
            segs[first] = Segment("█" * w, cap_style)
        elif last - first == 1:
            # 只有2格：上半圆 + 下半圆
            segs[first] = Segment("▄" * w, cap_style)
            segs[last] = Segment("▀" * w, cap_style)
        else:
            # 3格以上：上半圆 + 实心体 + 下半圆
            segs[first] = Segment("▄" * w, cap_style)
            for i in range(first + 1, last):
                segs[i] = Segment("█" * w, body_style)
            segs[last] = Segment("▀" * w, cap_style)

        return Segments(segs, new_lines=True)


# 全局替换滚动条渲染器
ScrollBar.renderer = RoundedScrollBarRender


# ═══════════════════════════════════════════════════════
#  PromptMixin — 输入提示（LoginPanel 专用）
# ═══════════════════════════════════════════════════════

class PromptMixin:
    """面板输入提示的通用实现"""

    _prompt_id: str  # 子类必须定义

    def show_prompt(self, text: str = ""):
        prompt = self.query_one(f"#{self._prompt_id}", Static)
        prompt.update(f"> {text}█")
        prompt.add_class("visible")

    def update_prompt(self, text: str):
        prompt = self.query_one(f"#{self._prompt_id}", Static)
        prompt.update(f"> {text}█")

    def hide_prompt(self):
        prompt = self.query_one(f"#{self._prompt_id}", Static)
        prompt.update("")
        prompt.remove_class("visible")


# ═══════════════════════════════════════════════════════
#  InputBar — 蓝色输入框（可复用基础组件）
# ═══════════════════════════════════════════════════

class InputBar(Vertical):
    """蓝色输入框 — 聊天/登录等通用输入栏"""

    def __init__(self, prompt_id: str, title: str = "", **kw):
        super().__init__(**kw)
        self._prompt_id = prompt_id
        if title:
            self.border_title = title

    def compose(self) -> ComposeResult:
        yield Static("", id=self._prompt_id, classes="input-bar-prompt")

    def show_prompt(self, text: str = ""):
        try:
            self.query_one(f"#{self._prompt_id}", Static).update(f"> {text}█")
        except Exception:
            pass

    def update_prompt(self, text: str):
        try:
            self.query_one(f"#{self._prompt_id}", Static).update(f"> {text}█")
        except Exception:
            pass

    def hide_prompt(self):
        try:
            self.query_one(f"#{self._prompt_id}", Static).update("")
        except Exception:
            pass


# ═══════════════════════════════════════════════════
#  ChatPanel — 聊天面板（左栏）
# ═══════════════════════════════════════════════════

class ChatPanel(Widget):
    """聊天面板：频道标签 + 消息日志 + 输入框"""

    CHANNEL_NAMES = {1: "世界", 2: "房间"}

    def __init__(self, **kw):
        super().__init__(**kw)
        self.current_channel = 1

    def compose(self) -> ComposeResult:
        yield RichLog(id="chat-log", wrap=True, highlight=True, markup=True, max_lines=500)
        yield InputBar(prompt_id="chat-prompt", id="chat-input-bar")

    def show_prompt(self, text: str = ""):
        try:
            self.query_one("#chat-input-bar", InputBar).show_prompt(text)
        except Exception:
            pass

    def update_prompt(self, text: str):
        try:
            self.query_one("#chat-input-bar", InputBar).update_prompt(text)
        except Exception:
            pass

    def hide_prompt(self):
        try:
            self.query_one("#chat-input-bar", InputBar).hide_prompt()
        except Exception:
            pass

    def show_input_bar(self):
        try:
            self.query_one("#chat-input-bar", InputBar).add_class("visible")
        except Exception:
            pass

    def hide_input_bar(self):
        try:
            self.query_one("#chat-input-bar", InputBar).remove_class("visible")
        except Exception:
            pass

    def add_message(self, name: str, text: str, channel: int = 1, time_str: str = ""):
        if channel != self.current_channel:
            return
        log: RichLog = self.query_one("#chat-log", RichLog)
        log.write(f"{name}> {text}")

    def add_system_message(self, text: str):
        log: RichLog = self.query_one("#chat-log", RichLog)
        log.write(f"[dim]>>> {text}[/]")

    def show_history(self, messages: list, channel: int):
        if channel != self.current_channel:
            return
        log: RichLog = self.query_one("#chat-log", RichLog)
        log.clear()
        for m in messages:
            name = m.get("name", "???")
            text = m.get("text", "")
            log.write(f"{name}> {text}")

    def switch_channel(self, channel_id: int):
        self.current_channel = channel_id
        labels = []
        for cid, cname in self.CHANNEL_NAMES.items():
            if cid == channel_id:
                labels.append(f"[b]{cname}[/b]")
            else:
                labels.append(f"[dim]{cname}[/]")
        self.border_title = " │ ".join(labels)

    def update_online_users(self, users: list):
        if not users:
            _set_pane_subtitle(self, "")
            return
        _set_pane_subtitle(self, f"在线({len(users)})")

    def restore(self, state: ModuleStateManager):
        st = state.chat
        self.switch_channel(st.current_channel)
        log: RichLog = self.query_one("#chat-log", RichLog)
        for entry in st.entries:
            if entry[0] == MSG:
                _, name, text, channel, time_str = entry
                if channel == st.current_channel:
                    log.write(f"{name}> {text}")
            elif entry[0] == SYS:
                log.write(f"[dim]>>> {entry[1]}[/]")
            elif entry[0] == HISTORY:
                _, messages, channel = entry
                if channel == st.current_channel:
                    log.clear()
                    for m in messages:
                        log.write(f"{m.get('name', '???')}> {m.get('text', '')}")
        if st.online_count:
            _set_pane_subtitle(self, f"在线({st.online_count})")


# ═══════════════════════════════════════════════════════
#  CommandHintBar — 指令输入框（标签页导航 + 指令选择 + 补全 + 输入）
# ═══════════════════════════════════════════════════════

MAX_HINT_VISIBLE = 4


class CommandHintBar(InputBar):
    """指令输入框：标签页导航 + 指令选择 + 补全 + 输入提示"""

    # mode: 'normal' 标签页+指令浏览 | 'completion' 补全

    def __init__(self, **kw):
        super().__init__(prompt_id="cmd-prompt", title="指令菜单", **kw)
        self._tabs: list[tuple[str, list]] = []
        self._active_tab: int = 0
        self._mode: str = 'normal'
        self._selected_idx: int = 0
        self._scroll_offset: int = 0
        self._completion_matches: list = []

    def compose(self) -> ComposeResult:
        yield Static("", id="hint-tabs", classes="hint-tabs")
        yield Static("", id="hint-content", classes="hint-content")
        yield Static("", id="cmd-prompt", classes="input-bar-prompt")

    # ── 数据更新 ──

    def update_tabs(self, tabs: list[tuple[str, list]]):
        self._tabs = tabs
        if self._active_tab >= len(tabs):
            self._active_tab = 0
        self._mode = 'normal'
        self._selected_idx = 0
        self._scroll_offset = 0
        self._completion_matches = []
        self._refresh_display()

    # ── 导航 ──

    def nav_left(self):
        """H: 切换上一标签"""
        if self._mode != 'normal' or not self._tabs:
            return
        self._active_tab = (self._active_tab - 1) % len(self._tabs)
        self._selected_idx = 0
        self._scroll_offset = 0
        self._refresh_display()

    def nav_right(self):
        """L: 切换下一标签"""
        if self._mode != 'normal' or not self._tabs:
            return
        self._active_tab = (self._active_tab + 1) % len(self._tabs)
        self._selected_idx = 0
        self._scroll_offset = 0
        self._refresh_display()

    def nav_down(self):
        """J: 指令列表向下选择"""
        items = self._current_items()
        if not items:
            return
        self._selected_idx = min(self._selected_idx + 1, len(items) - 1)
        self._ensure_visible()
        self._refresh_display()

    def nav_up(self):
        """K: 指令列表向上选择"""
        items = self._current_items()
        if not items:
            return
        self._selected_idx = max(self._selected_idx - 1, 0)
        self._ensure_visible()
        self._refresh_display()

    def enter(self):
        """Enter: 返回选中的 CommandInfo，或 None"""
        items = self._current_items()
        if items and 0 <= self._selected_idx < len(items):
            return items[self._selected_idx]
        return None

    def back(self):
        """Backspace 空输入: 退出补全回到标签页"""
        if self._mode == 'completion':
            self._mode = 'normal'
            self._selected_idx = 0
            self._scroll_offset = 0
            self._completion_matches = []
            self._refresh_display()

    # ── 补全 ──

    def show_completion(self, matches: list):
        self._mode = 'completion'
        self._completion_matches = matches
        self._selected_idx = 0
        self._scroll_offset = 0
        self._refresh_display()

    def exit_completion(self):
        if self._mode == 'completion':
            self._mode = 'normal'
            self._selected_idx = 0
            self._scroll_offset = 0
            self._completion_matches = []
            self._refresh_display()

    # ── 内部 ──

    def _current_items(self) -> list:
        if self._mode == 'completion':
            return self._completion_matches
        if self._tabs and self._active_tab < len(self._tabs):
            return self._tabs[self._active_tab][1]
        return []

    def _ensure_visible(self):
        if self._selected_idx < self._scroll_offset:
            self._scroll_offset = self._selected_idx
        elif self._selected_idx >= self._scroll_offset + MAX_HINT_VISIBLE:
            self._scroll_offset = self._selected_idx - MAX_HINT_VISIBLE + 1

    def _refresh_display(self):
        if not self._tabs and self._mode != 'completion':
            try:
                self.query_one("#hint-tabs", Static).update("")
                self.query_one("#hint-content", Static).update("")
            except Exception:
                pass
            return

        # 标签行
        if self._mode == 'completion':
            tab_text = f"  [bold {COLOR_HINT_TAB_ACTIVE}]补全[/]"
        else:
            parts = []
            for i, (name, _) in enumerate(self._tabs):
                if i == self._active_tab:
                    parts.append(f"[bold {COLOR_HINT_TAB_ACTIVE}]▶ {name}[/]")
                else:
                    parts.append(f"[{COLOR_HINT_TAB_DIM}]  {name}[/]")
            tab_text = "".join(parts)

        # 指令列表
        items = self._current_items()
        content_text = self._render_items(items)

        try:
            self.query_one("#hint-tabs", Static).update(tab_text)
            self.query_one("#hint-content", Static).update(content_text)
        except Exception:
            pass

    def _render_items(self, items: list):
        total = len(items)
        offset = self._scroll_offset
        visible = items[offset:offset + MAX_HINT_VISIBLE]
        need_sb = total > MAX_HINT_VISIBLE

        table = Table(
            show_header=False, show_edge=False,
            box=None, expand=True, padding=(0, 0), pad_edge=False,
        )
        table.add_column(width=2, no_wrap=True)          # 箭头列
        table.add_column(no_wrap=True)                    # 指令名
        table.add_column(justify="right", style=COLOR_HINT_TAB_DIM, ratio=1, no_wrap=True)  # 说明
        if need_sb:
            table.add_column(width=1, no_wrap=True)       # 滚动条
            max_off = max(1, total - MAX_HINT_VISIBLE)
            thumb_size = max(1, round(MAX_HINT_VISIBLE / total * MAX_HINT_VISIBLE))
            track_space = MAX_HINT_VISIBLE - thumb_size
            thumb_start = round(offset / max_off * track_space) if track_space > 0 else 0

        for i, c in enumerate(visible):
            real_idx = offset + i
            if real_idx == self._selected_idx:
                arrow = f"[bold {COLOR_HINT_TAB_ACTIVE}]▶ [/]"
            else:
                arrow = "  "
            row = [arrow, c.command, c.description or ""]
            if need_sb:
                if thumb_start <= i < thumb_start + thumb_size:
                    row.append(f"[{COLOR_HINT_TAB_ACTIVE}]█[/]")
                else:
                    row.append(f"[{COLOR_HINT_TAB_DIM}]│[/]")
            table.add_row(*row)

        # 不足 MAX_HINT_VISIBLE 行时补空行
        for _ in range(MAX_HINT_VISIBLE - len(visible)):
            table.add_row("", "", "")

        return table


# ═══════════════════════════════════════════════════════
#  CommandPanel — 指令面板（中栏）
# ═══════════════════════════════════════════════════════

class CommandPanel(Widget):
    """指令面板：纯终端输出 + 指令提示栏"""

    def compose(self) -> ComposeResult:
        yield RichLog(id="cmd-log", wrap=True, highlight=True, markup=True, max_lines=1000)
        yield CommandHintBar(id="cmd-hint-bar")

    # ── 提示栏代理 ──

    def show_prompt(self, text: str = ""):
        try:
            self.query_one("#cmd-hint-bar", CommandHintBar).show_prompt(text)
        except Exception:
            pass

    def update_prompt(self, text: str):
        try:
            self.query_one("#cmd-hint-bar", CommandHintBar).update_prompt(text)
        except Exception:
            pass

    def hide_prompt(self):
        try:
            self.query_one("#cmd-hint-bar", CommandHintBar).hide_prompt()
        except Exception:
            pass

    # ── 消息 ──

    def add_message(self, text: str, update_last: bool = False):
        log: RichLog = self.query_one("#cmd-log", RichLog)
        log.write(text)

    def clear(self):
        log: RichLog = self.query_one("#cmd-log", RichLog)
        log.clear()

    # ── 指令菜单 ──

    def update_hint_tabs(self, tabs: list[tuple[str, list]]):
        try:
            self.query_one("#cmd-hint-bar", CommandHintBar).update_tabs(tabs)
        except Exception:
            pass

    def show_hint_bar(self):
        try:
            self.query_one("#cmd-hint-bar", CommandHintBar).add_class("visible")
        except Exception:
            pass

    def hide_hint_bar(self):
        try:
            bar = self.query_one("#cmd-hint-bar", CommandHintBar)
            bar.remove_class("visible")
            bar.exit_completion()
        except Exception:
            pass

    def show_completion(self, matches: list):
        try:
            self.query_one("#cmd-hint-bar", CommandHintBar).show_completion(matches)
        except Exception:
            pass

    def exit_completion(self):
        try:
            self.query_one("#cmd-hint-bar", CommandHintBar).exit_completion()
        except Exception:
            pass

    def hint_enter(self):
        try:
            return self.query_one("#cmd-hint-bar", CommandHintBar).enter()
        except Exception:
            return None

    def hint_back(self):
        try:
            self.query_one("#cmd-hint-bar", CommandHintBar).back()
        except Exception:
            pass

    def hint_nav(self, direction: str):
        try:
            bar = self.query_one("#cmd-hint-bar", CommandHintBar)
            getattr(bar, f'nav_{direction}')()
        except Exception:
            pass

    def restore(self, state: ModuleStateManager):
        st = state.cmd
        log: RichLog = self.query_one("#cmd-log", RichLog)
        for line in st.lines:
            log.write(line)
        from .command_registry import get_command_tabs
        tabs = get_command_tabs()
        if tabs:
            self.update_hint_tabs(tabs)



# ═══════════════════════════════════════════════════════
#  BoardPanel — 棋盘/牌桌/地图（可视化游戏场景）
# ═══════════════════════════════════════════════════════

class BoardPanel(Widget):
    """棋盘面板：通过 RENDERER_REGISTRY 渲染任意游戏的棋盘/牌桌/地图"""

    def __init__(self, **kw):
        super().__init__(**kw)
        self.current_location = "lobby"

    def compose(self) -> ComposeResult:
        yield RichLog(id="board-content", wrap=True, highlight=True, markup=True, max_lines=500)

    def set_location(self, location: str):
        self.current_location = location

    def update_map(self, map_data):
        content: RichLog = self.query_one("#board-content", RichLog)
        content.clear()
        lines = map_data if isinstance(map_data, list) else map_data.split("\n")
        for line in lines:
            content.write(line)

    def update_status(self, player_data: dict):
        name = player_data.get("name", "?")
        level = player_data.get("level", 1)
        gold = player_data.get("gold", 0)
        self.border_subtitle = f"{name} Lv.{level} {gold}G"

    def update_table(self, room_data: dict | None):
        """通过渲染注册表渲染棋盘 — 这就是"切口" """
        content: RichLog = self.query_one("#board-content", RichLog)
        if room_data is None:
            content.clear()
            return
        game_type = room_data.get("game_type", "")
        renderer = get_renderer(game_type)
        if renderer:
            renderer.render_board(content, room_data)
        else:
            content.clear()
            content.write(f"[dim]未知游戏类型: {game_type}[/]")

    def restore(self, state: ModuleStateManager):
        st = state.board
        if st.player_data:
            self.update_status(st.player_data)
        if st.map_data:
            self.update_map(st.map_data)
        if st.room_data:
            self.update_table(st.room_data)
        self.set_location(st.location)


# ═══════════════════════════════════════════════════════
#  StatusPanel — 状态面板（手牌/走棋历史/属性等文字数据）
# ═══════════════════════════════════════════════════════

class StatusPanel(Widget):
    """状态面板：通过 RENDERER_REGISTRY 渲染手牌/走棋历史等游戏状态"""

    def compose(self) -> ComposeResult:
        yield RichLog(id="status-content", wrap=True, highlight=True, markup=True, max_lines=500)

    def update_game_status(self, game_type: str, game_data: dict):
        """通过渲染注册表渲染游戏状态 — 这就是"切口" """
        content: RichLog = self.query_one("#status-content", RichLog)
        renderer = get_renderer(game_type)
        if renderer:
            renderer.render_status(content, game_data)

    def add_message(self, text: str):
        content: RichLog = self.query_one("#status-content", RichLog)
        content.write(text)

    def clear(self):
        content: RichLog = self.query_one("#status-content", RichLog)
        content.clear()

    def restore(self, state: ModuleStateManager):
        st = state.status
        if st.game_type and st.game_data:
            self.update_game_status(st.game_type, st.game_data)
        else:
            log: RichLog = self.query_one("#status-content", RichLog)
            for line in st.lines:
                log.write(line)


# ═══════════════════════════════════════════════════════
#  OnlineUsersPanel — 在线用户列表
# ═══════════════════════════════════════════════════════

class OnlineUsersPanel(Widget):
    """在线用户列表面板"""

    def compose(self) -> ComposeResult:
        yield RichLog(id="online-log", wrap=True, highlight=True, markup=True, max_lines=200)

    def update_users(self, users: list):
        content: RichLog = self.query_one("#online-log", RichLog)
        content.clear()
        content.write(f"[b]在线 ({len(users)})[/b]")
        content.write("─" * 16)
        for u in users:
            if isinstance(u, dict):
                content.write(u.get("name", str(u)))
            else:
                content.write(str(u))

    def restore(self, state: ModuleStateManager):
        if state.online.users:
            self.update_users(state.online.users)


# ═══════════════════════════════════════════════════════
#  LoginPanel — 登录面板（连接 + 登录）
# ═══════════════════════════════════════════════════════

class LoginPanel(PromptMixin, Widget):
    """登录面板：游戏标题 + 服务器连接 + 登录流程"""

    _prompt_id = "login-prompt"

    def compose(self) -> ComposeResult:
        yield Static("[b]游 戏 大 厅[/b]", id="login-title")
        yield RichLog(id="login-log", wrap=True, highlight=True, markup=True, max_lines=100)
        yield Static("", id="login-prompt", classes="panel-prompt")

    def on_mount(self) -> None:
        from .config import DEFAULT_HOST
        log: RichLog = self.query_one("#login-log", RichLog)
        log.write(f"输入服务器地址连接（默认 {DEFAULT_HOST}）")

    def add_message(self, text: str):
        log: RichLog = self.query_one("#login-log", RichLog)
        log.write(text)

    def restore(self, state: ModuleStateManager):
        pass


# ── 注册内置模块 ──

from .module_registry import register_module  # noqa: E402

register_module('login',  '登录',     LoginPanel)
register_module('chat',   '聊天',     ChatPanel)
register_module('cmd',    '指令',     CommandPanel)
register_module('board',  '棋盘',     BoardPanel)
register_module('status', '状态',     StatusPanel)
register_module('online', '在线用户', OnlineUsersPanel)
