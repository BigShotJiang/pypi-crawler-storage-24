# main

**Purpose:** Main project memory branch

---

## Commit 59cd4601 | 2026-03-16T22:18:18.615Z

### Branch Purpose
The `main` branch serves as the primary project memory for the development of `uv-workspace-dynamic-versioning`, a plugin designed to automate version management in `uv` workspaces.

### Previous Progress Summary
Initial commit.

### This Commit's Contribution
- Established the initial project roadmap and memory structure for a `hatch` extension facilitating dynamic versioning in `uv` workspaces.
- Selected `hatchling` as the build backend and `dunamai` as the core engine for generating versions based on VCS state.
- Integrated `tomlkit` for robust `pyproject.toml` manipulation and `jinja2` for potential version string templating.
- Configured plugin entry points to register the `uv-workspace-dynamic-versioning` extension as a `hatch` hook.
- Established the basic project structure and core logic modules, including a vendored subdirectory for specialized requirements.

---

## Commit 6eaed424 | 2026-03-16T22:19:00.525Z

### Branch Purpose
The `main` branch serves as the primary project memory for the development of `uv-workspace-dynamic-versioning`, a plugin designed to automate version management in `uv` workspaces.

### Previous Progress Summary
The project was initialized with a roadmap and memory structure for a `hatch` extension providing dynamic versioning in `uv` workspaces. `hatchling` was selected as the build backend, `dunamai` as the versioning engine, and `tomlkit`/`jinja2` for configuration and templating. Initial work established the project structure, registered plugin entry points, and populated core logic, much of which resides in a `vendored` subdirectory.

### This Commit's Contribution
- Refined the project's current state and key decisions following a detailed code review of the existing `hatch` plugin implementation.
- Identified that the plugin provides both a `DynamicWorkspaceVersionSource` for VCS-based versioning and a `DependenciesMetadataHook` for dynamic dependency updates via Jinja2 templates.
- Confirmed the implementation of directory-specific git history patching to calculate accurate version distance within monorepos/workspaces.
- Validated the use of `tomlkit` for programmatic `pyproject.toml` manipulation and `jinja2` for both version string and dependency list templating.

---

## Commit 980fcf72 | 2026-03-16T22:20:12.617Z

### Branch Purpose
The `main` branch serves as the primary project memory for the development of `uv-workspace-dynamic-versioning`, a plugin designed to automate version management in `uv` workspaces.

### Previous Progress Summary
The project was established as a `hatch` extension for `uv` workspaces, utilizing `hatchling` as the build backend and `dunamai` for VCS-based versioning. Initial work defined the project structure and registered core plugin entry points, including a `DynamicWorkspaceVersionSource` for directory-specific git history patching and a `DependenciesMetadataHook` for dynamic dependency updates via Jinja2 templates. A subsequent code review validated the implementation's use of `tomlkit` for configuration manipulation and `jinja2` for version and dependency templating, confirming the project's ability to handle complex monorepo versioning requirements.

### This Commit's Contribution
- Created a comprehensive MkDocs documentation suite to provide clear guidance for users and developers.
- Drafted the project overview and installation guides, highlighting the plugin's utility in `uv` monorepo environments.
- Documented usage patterns for basic setup, workspace-aware versioning, and dynamic dependency injection.
- Provided a detailed configuration reference for all version source and metadata hook options, including Jinja2 context details.
- Outlined the internal API for core components to assist with future development and maintenance.
- Configured the MkDocs build using the Material theme and established a structured navigation menu in `mkdocs.yml`.

---

## Commit 1a0f8284 | 2026-03-16T22:20:27.637Z

### Branch Purpose

The `main` branch serves as the primary project memory for the development of `uv-workspace-dynamic-versioning`, a plugin designed to automate version management in `uv` workspaces.

### Previous Progress Summary

The project was established as a `hatch` extension for `uv` workspaces, utilizing `hatchling` as the build backend and `dunamai` for VCS-based versioning. Initial work defined the project structure and registered core plugin entry points, including a `DynamicWorkspaceVersionSource` for directory-specific git history patching and a `DependenciesMetadataHook` for dynamic dependency updates via Jinja2 templates. Subsequent code reviews and implementation work validated the use of `tomlkit` for configuration manipulation and `jinja2` for version and dependency templating, confirming the project's ability to handle complex monorepo versioning requirements. Most recently, a comprehensive MkDocs documentation suite was created, providing clear guidance for users and developers on installation, usage, and configuration.

### This Commit's Contribution

- Updated the project roadmap milestones in `.memory/main.md` to accurately reflect the current development status.
- Formally marked the core versioning logic implementation and project documentation as completed.
- Refined the roadmap to highlight integration testing with `uv` workspaces as the primary remaining objective for the current phase.

---

## Commit 59709875 | 2026-03-16T22:28:43.405Z

### Branch Purpose
The `main` branch serves as the primary project memory for the development of `uv-workspace-dynamic-versioning`, a plugin designed to automate version management in `uv` workspaces.

### Previous Progress Summary
The project was established as a `hatch` extension for `uv` workspaces, using `hatchling` as the build backend and `dunamai` for VCS-based versioning. Key features include directory-specific git history patching and dynamic dependency updates via Jinja2 templates, with `tomlkit` handling `pyproject.toml` manipulation. A comprehensive MkDocs documentation suite was completed, providing guides for installation, usage, and configuration. The roadmap was refined to mark core logic and documentation as complete, shifting focus toward integration testing and community readiness.

### This Commit's Contribution
- Formalized the development environment by adding `docs` and `test` optional dependencies to `pyproject.toml`.
- Established `CONTRIBUTING.md` with standards for bug reporting, `uv`-based setup, and documentation best practices.
- Implemented a `pytest` suite covering schema validation, metadata hook configuration, and directory-specific version patching logic.
- Validated core versioning logic through successful test execution, including mocked `subprocess` calls for git history distance calculation.
- Confirmed documentation build stability by verifying a successful `mkdocs build` against the established site structure.

---

## Commit 7bd205a6 | 2026-03-16T22:35:33.423Z

### Branch Purpose

The `main` branch serves as the primary project memory for the development of `uv-workspace-dynamic-versioning`, a plugin designed to automate version management in `uv` workspaces.

### Previous Progress Summary

The project was established as a `hatch` extension for `uv` workspaces, using `hatchling` as the build backend and `dunamai` for VCS-based versioning. Key features include directory-specific git history patching and dynamic dependency updates via Jinja2 templates. A comprehensive MkDocs documentation suite, contribution guidelines, and a `pytest` suite were established to ensure project quality and community readiness. The project structure and core logic modules, including a vendored subdirectory, are formalized with development dependencies and validated through initial testing.

### This Commit's Contribution

- Integrated `mkdocstrings` into the documentation workflow to automate API reference generation from source code docstrings.
- Enriched core modules (`version_source.py`, `main.py`, `metadata_hook.py`) with comprehensive docstrings to facilitate maintenance and automated documentation.
- Enhanced repository hygiene by adding build artifacts (`site/`) and testing caches (`.pytest_cache/`) to `.gitignore`.
- Updated the documentation site layout and `mkdocs.yml` to include Material theme features like code copy buttons and navigation indexes.
- Acknowledged MkDocs 2.0 compatibility considerations in the project roadmap while maintaining 1.x stability for current production use.

---

## Commit 25a8b84e | 2026-03-16T22:38:58.681Z

### Branch Purpose

The `main` branch serves as the primary project memory for the development of `uv-workspace-dynamic-versioning`, a `hatch` plugin designed to automate version management and dependency injection in `uv` workspaces.

### Previous Progress Summary

The project was established as a `hatch` extension using `hatchling` and `dunamai` for VCS-based versioning, featuring custom directory-specific history patching to support accurate versioning within monorepos. It enables dynamic dependency updates via Jinja2 templates and `tomlkit` for robust configuration manipulation. A comprehensive foundation was built with an MkDocs Material documentation suite, contribution guidelines, and a `pytest` suite. Recent iterations formalized the development environment, automated API reference generation via `mkdocstrings` with enriched source docstrings, and established repository hygiene by standardizing build and cache exclusions in `.gitignore`.

### This Commit's Contribution

- Achieved **71% test coverage** by expanding the test suite to validate configuration parsing, metadata hook rendering, and mocked git history distance calculations.
- Significantly enhanced documentation UX by implementing **light/dark mode toggles**, search suggestions, TOC tracking, and improved navigation features.
- Integrated `mkdocs-minify-plugin` and `mkdocs-git-revision-date-localized-plugin` to optimize documentation builds and provide automated "last updated" metadata.
- Standardized the development environment by adding `pytest-cov` and specialized MkDocs plugins to the project's optional dependencies.
- Updated the project roadmap to reflect the completion of the 70%+ test coverage milestone and the delivery of high-quality documentation.

---

## Commit fd32768f | 2026-03-16T22:48:29.933Z

### Branch Purpose

The `main` branch serves as the primary project memory for the development of `uv-workspace-dynamic-versioning`, a `hatch` plugin designed to automate version management and dependency injection in `uv` workspaces.

### Previous Progress Summary

The project was established as a `hatch` extension using `hatchling` and `dunamai` for VCS-based versioning, featuring custom directory-specific history patching for monorepos. It enables dynamic dependency updates via Jinja2 templates and `tomlkit` for configuration manipulation. A robust foundation includes an MkDocs Material documentation suite with light/dark mode and automated API references, a `pytest` suite reaching 71% coverage, and formalized development standards and repository hygiene.

### This Commit's Contribution

- Mitigated Server-Side Template Injection (SSTI) and arbitrary code execution risks by switching to `jinja2.sandbox.SandboxedEnvironment` for all template rendering.
- Reduced data exposure risks by removing `os.environ` from the default Jinja2 context, preventing accidental leakage of sensitive environment variables in build logs or metadata.
- Hardened dependency security by pinning the minimum `jinja2` version to `3.1.5` to address known vulnerabilities (e.g., CVE-2024-34064).
- Recognized that build-time plugins are a significant supply-chain attack vector, necessitating a "secure by default" posture for user-provided templates.
- Validated that security hardening did not regress core functionality by verifying the existing test suite with the new sandboxed environment.

---

## Commit 68b0cd0a | 2026-03-16T23:03:09.499Z

### Branch Purpose

The `main` branch serves as the primary project memory for the development of `uv-workspace-dynamic-versioning`, a `hatch` plugin designed to automate version management and dependency injection in `uv` workspaces.

### Previous Progress Summary

The project was established as a `hatch` extension using `hatchling` and `dunamai` for VCS-based versioning, featuring custom directory-specific history patching for monorepos and dynamic dependency updates via Jinja2 templates. A robust foundation includes an MkDocs Material documentation suite with light/dark mode and automated API references, and a `pytest` suite reaching 71% coverage. Recent security hardening mitigated Server-Side Template Injection (SSTI) and arbitrary code execution risks by switching to `jinja2.sandbox.SandboxedEnvironment`, removing `os.environ` from the template context, and pinning `jinja2 >= 3.1.5`.

### This Commit's Contribution

- Mitigated a critical Path Traversal vulnerability in the `from-file` version source by enforcing that all file reads resolve within the project root.
- Improved operational visibility by replacing silent `try...except: pass` blocks in Git subprocess calls with explicit error logging to `stderr`.
- Increased test coverage to **74%** with new unit tests for path traversal prevention, valid file-based versioning, and environment bypass logic.
- Refined the core `get_version` API to require the `project_dir` context, ensuring secure and relative file resolution throughout the plugin.
- Formally updated the project roadmap to track "Security Hardening" (SSTI and Path Traversal) as a completed milestone.
- Updated the README and technical documentation to reflect the latest security posture and architectural changes.

---

## Commit 4eb36828 | 2026-03-16T23:18:16.323Z

### Branch Purpose

The `main` branch serves as the primary project memory for the development of `uv-workspace-dynamic-versioning`, a `hatch` plugin designed to automate version management and dependency injection in `uv` workspaces.

### Previous Progress Summary

The project was established as a `hatch` extension for `uv` workspaces, utilizing `hatchling` and `dunamai` to automate versioning and dependency injection. Key features include directory-specific Git history patching for monorepos and Jinja2-based dynamic dependency updates. A robust development environment was built, featuring an MkDocs Material documentation site with automated API references, a `pytest` suite with 74% coverage, and formalized contribution guidelines. Critical security hardening addressed Server-Side Template Injection (SSTI) via Jinja2 sandboxing and Path Traversal vulnerabilities by enforcing project-root validation for file-based version sources. Operational visibility was enhanced by replacing silent Git subprocess failures with explicit error logging.

### This Commit's Contribution

- Adopted [Conventional Commits v1.0.0](https://www.conventionalcommits.org/en/v1.0.0/) to ensure a clear, machine-readable project history.
- Resolved a logic inconsistency where versions were automatically bumped even when exactly on a Git tag; it now correctly only bumps when the distance is greater than zero.
- Hardened the codebase against upstream breaking changes by copying required version regex patterns locally instead of importing private `dunamai` members.
- Optimized performance by caching the Jinja2 `SandboxedEnvironment` at the module level to avoid redundant initialization during build processes.
- Improved error handling for dynamic templates by implementing descriptive `ValueError` messages when module imports fail.
- Standardized module structure by moving all functional imports to the top-level in accordance with PEP 8.
- Updated the project roadmap in `.memory/main.md` to reflect the adoption of standard commit conventions and the completion of recent architectural refinements.

---

## Commit e5c83566 | 2026-03-16T23:19:41.137Z

### Branch Purpose

The `main` branch serves as the primary project memory for the development of `uv-workspace-dynamic-versioning`, a `hatch` plugin designed to automate version management and dependency injection in `uv` workspaces.

### Previous Progress Summary

The project is a `hatch` extension for `uv` workspaces using `hatchling` and `dunamai` for VCS-powered versioning, featuring monorepo-specific history patching and dynamic dependency injection via sandboxed Jinja2 templates. A robust development foundation was established, including a `pytest` suite with 74% coverage, a Material-themed documentation site with automated API references, and formalized contribution guidelines. Security hardening has addressed SSTI and Path Traversal risks, while operational visibility was improved through explicit error logging for Git failures. Most recently, the project adopted Conventional Commits and refined its internal version bumping logic and performance optimizations.

### This Commit's Contribution

- Modernized the documentation landing page and refined navigation architecture into dedicated Guide and Reference sections for improved UX.
- Enabled advanced Material for MkDocs features including sticky tabs, search suggestions, and code tooltips to enhance technical readability.
- Integrated `mkdocs-glightbox` for image zooming and `mkdocs-git-revision-date-localized-plugin` to provide automated content freshness indicators.
- Adopted the "recommended" Material configuration, incorporating HTML minification and updated plugin settings for better site performance.
- Enhanced the automated API reference by enabling detailed symbol type headings and Table of Contents integration via `mkdocstrings`.
- Resolved documentation build warnings by correcting the `git-revision-date-localized` plugin configuration and added missing development dependencies.

---

## Commit 0629932f | 2026-03-16T23:22:32.327Z

### Branch Purpose

The `main` branch serves as the primary project memory for the development of `uv-workspace-dynamic-versioning`, a `hatch` plugin designed to automate version management and dependency injection in `uv` workspaces.

### Previous Progress Summary

The project is a `hatch` extension for `uv` workspaces using `hatchling` and `dunamai` for VCS-powered versioning, featuring monorepo-specific history patching and dynamic dependency injection via sandboxed Jinja2 templates. A robust development foundation was established, including a `pytest` suite with 74% coverage and formalized contribution guidelines. Security hardening addressed SSTI and Path Traversal risks. Most recently, the documentation was modernized with Material for MkDocs enhancements, including a new landing page, refined navigation, and advanced technical discovery features like interactive API references and search suggestions.

### This Commit's Contribution

- Fixed a broken logo configuration in `mkdocs.yml` by correctly nesting the logo path under `theme.icon`.
- Rewrote `README.md` to explicitly define the project's origin as a solution for "False Positive" version bumps in complex `uv` workspaces.
- Documented the core differentiator: **Directory-Specific Patching**, which re-calculates Git distance by filtering history to the package subdirectory.
- Synced the documentation landing page with the new README content to ensure a consistent narrative across the repository and site.
- Referenced the discussion in [ninoseki/uv-dynamic-versioning#81](https://github.com/ninoseki/uv-dynamic-versioning/issues/81) to provide technical context for the implementation's necessity.

---

## Commit e78feeb2 | 2026-03-16T23:24:25.323Z

### Branch Purpose

The `main` branch serves as the primary project memory for the development of `uv-workspace-dynamic-versioning`, a `hatch` plugin designed to automate version management and dependency injection in `uv` workspaces.

### Previous Progress Summary

The project is a `hatch` extension for `uv` workspaces using `hatchling` and `dunamai` for VCS-powered versioning, featuring monorepo-specific history patching and dynamic dependency injection via sandboxed Jinja2 templates. A robust development foundation includes a `pytest` suite with 74% coverage and formalized contribution guidelines. Security hardening addressed SSTI and Path Traversal risks. The documentation is built with Material for MkDocs, featuring automated API references and a clear technical narrative explaining the project's core differentiator: directory-specific git history filtering to prevent false-positive version bumps.

### This Commit's Contribution

- Added Antigravity as a co-author in `pyproject.toml` to acknowledge the agent's contributions to the codebase, documentation, and architectural refinements.
- Formalized the collaborative development state of the project within the package metadata.

---

## Commit ec1a974d | 2026-03-16T23:42:12.301Z

### Merge from ci-cd-workflow

Integrated CI/CD workflow with GitHub Actions. Standardized linting with Ruff and testing with Pytest. Configured automated PyPI publishing on tag creation. All changes merged into main.
