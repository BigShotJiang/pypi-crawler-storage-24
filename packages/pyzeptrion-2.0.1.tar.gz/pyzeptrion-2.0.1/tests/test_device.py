"""Tests for ZeptrionDevice (base class)."""

import pytest
import asyncio
from aioresponses import aioresponses
from aiohttp import ClientResponseError, ClientError

from pyzeptrion.device import ZeptrionDevice
from pyzeptrion.exceptions import ZeptrionConnectionError
from pyzeptrion.const import ON_STATE, OFF_STATE

from .conftest import (
    HOST, CHN,
    DESC_URL, STATE_URL, CTRL_URL,
    DESC_XML_DIMMABLE, STATE_ON_XML, STATE_OFF_XML,
)


@pytest.fixture
def device():
    return ZeptrionDevice(HOST, CHN, session=None)


# ---------------------------------------------------------------------------
# _set_description
# ---------------------------------------------------------------------------

async def test_set_description_parses_name(device):
    with aioresponses() as m:
        m.get(DESC_URL, body=DESC_XML_DIMMABLE, status=200)
        await device._set_description()

    assert device.name == "TestLight"


async def test_set_description_parses_group(device):
    with aioresponses() as m:
        m.get(DESC_URL, body=DESC_XML_DIMMABLE, status=200)
        await device._set_description()

    assert device.group == "LivingRoom"


async def test_set_description_parses_dev_type(device):
    with aioresponses() as m:
        m.get(DESC_URL, body=DESC_XML_DIMMABLE, status=200)
        await device._set_description()

    assert device.dev_type == "Bulb dimmable"


async def test_set_description_generates_dev_id(device):
    with aioresponses() as m:
        m.get(DESC_URL, body=DESC_XML_DIMMABLE, status=200)
        await device._set_description()

    assert device.dev_id is not None
    assert len(device.dev_id) == 40  # SHA-1 hex digest


async def test_set_description_dev_id_stable(device):
    """Same inputs must always produce the same ID."""
    with aioresponses() as m:
        m.get(DESC_URL, body=DESC_XML_DIMMABLE, status=200)
        await device._set_description()
    id1 = device.dev_id

    device2 = ZeptrionDevice(HOST, CHN, session=None)
    with aioresponses() as m:
        m.get(DESC_URL, body=DESC_XML_DIMMABLE, status=200)
        await device2._set_description()
    id2 = device2.dev_id

    assert id1 == id2


# ---------------------------------------------------------------------------
# get_state
# ---------------------------------------------------------------------------

async def test_get_state_returns_on(device):
    with aioresponses() as m:
        m.get(STATE_URL, body=STATE_ON_XML, status=200)
        state = await device.get_state()

    assert state == ON_STATE


async def test_get_state_returns_off(device):
    with aioresponses() as m:
        m.get(STATE_URL, body=STATE_OFF_XML, status=200)
        state = await device.get_state()

    assert state == OFF_STATE


# ---------------------------------------------------------------------------
# post_cmd
# ---------------------------------------------------------------------------

async def test_post_cmd_sends_correct_payload(device):
    with aioresponses() as m:
        m.post(CTRL_URL, status=302, body="")
        await device.post_cmd("on")

        requests = m.requests
        assert len(requests) == 1
        _, call = list(requests.items())[0]
        assert call[0].kwargs["data"] == {"cmd": "on"}


async def test_post_cmd_updates_state(device):
    with aioresponses() as m:
        m.post(CTRL_URL, status=302, body="")
        await device.post_cmd("on")

    assert device.state == "on"


# ---------------------------------------------------------------------------
# request — error handling
# ---------------------------------------------------------------------------

async def test_request_raises_on_timeout(device):
    with aioresponses() as m:
        m.get(STATE_URL, exception=asyncio.TimeoutError())

        with pytest.raises(ZeptrionConnectionError, match="Timeout"):
            await device.request(uri=device._get_state_uri, method="GET")


async def test_request_raises_on_client_error(device):
    with aioresponses() as m:
        m.get(STATE_URL, exception=ClientError("network error"))

        with pytest.raises(ZeptrionConnectionError):
            await device.request(uri=device._get_state_uri, method="GET")


# ---------------------------------------------------------------------------
# Properties
# ---------------------------------------------------------------------------

def test_host_property(device):
    assert device.host == HOST


def test_chn_property(device):
    assert device.chn == CHN


def test_initial_state_is_false(device):
    assert device.state is False


def test_str_representation(device):
    s = str(device)
    assert HOST in s
    assert CHN in s


# ---------------------------------------------------------------------------
# Session management
# ---------------------------------------------------------------------------

async def test_close_session_owned_by_device():
    """When session=None the device opens its own session and closes it."""
    device = ZeptrionDevice(HOST, CHN, session=None)
    with aioresponses() as m:
        m.get(STATE_URL, body=STATE_ON_XML, status=200)
        await device.request(uri=device._get_state_uri, method="GET")

    assert device._close_session is True
    await device.close()
    assert device._session is None


async def test_close_does_not_close_external_session():
    """When a session is passed in, close() must not close it."""
    import aiohttp
    async with aiohttp.ClientSession() as session:
        device = ZeptrionDevice(HOST, CHN, session=session)
        await device.close()
        assert not session.closed
