"""Tests for pyzeptrion.const."""

from pyzeptrion.const import (
    TIMEOUT,
    DIMMER_FULL_TRAVEL_TIME,
    GET_STATE_URL,
    GET_DESC_URL,
    POST_CTRL_URL,
    BULB_ON,
    BULB_OFF,
    BULB_TOGGLE,
    BULB_DIMUP,
    BULB_DIMDOWN,
    BLIND_OPEN,
    BLIND_CLOSE,
    BLIND_STOP,
    ON_STATE,
    OFF_STATE,
    device_types,
)


def test_timeout_positive():
    assert TIMEOUT > 0


def test_dimmer_travel_time_positive():
    assert DIMMER_FULL_TRAVEL_TIME > 0


def test_api_urls():
    assert GET_STATE_URL.startswith("/")
    assert GET_DESC_URL.startswith("/")
    assert POST_CTRL_URL.startswith("/")


def test_bulb_commands_are_strings():
    for cmd in (BULB_ON, BULB_OFF, BULB_TOGGLE, BULB_DIMUP, BULB_DIMDOWN):
        assert isinstance(cmd, str)
        assert len(cmd) > 0


def test_blind_commands_are_strings():
    for cmd in (BLIND_OPEN, BLIND_CLOSE, BLIND_STOP):
        assert isinstance(cmd, str)
        assert len(cmd) > 0


def test_on_off_states_differ():
    assert ON_STATE != OFF_STATE


def test_device_types_known_keys():
    assert device_types["-1"] == "NaN"
    assert device_types["1"] == "Bulb on/off"
    assert device_types["3"] == "Bulb dimmable"
    assert device_types["5"] == "Blind"
    assert device_types["6"] == "Blind"
