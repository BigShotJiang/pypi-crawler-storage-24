"""Tests for pyzeptrion.exceptions."""

from pyzeptrion.exceptions import ZeptrionError, ZeptrionConnectionError


def test_zeptrion_error_is_exception():
    assert issubclass(ZeptrionError, Exception)


def test_connection_error_inherits_from_base():
    assert issubclass(ZeptrionConnectionError, ZeptrionError)


def test_connection_error_can_be_raised_and_caught():
    with pytest.raises(ZeptrionConnectionError):
        raise ZeptrionConnectionError("test")


def test_base_error_catches_connection_error():
    with pytest.raises(ZeptrionError):
        raise ZeptrionConnectionError("test")


def test_message_preserved():
    msg = "connection timed out"
    exc = ZeptrionConnectionError(msg)
    assert str(exc) == msg


import pytest
