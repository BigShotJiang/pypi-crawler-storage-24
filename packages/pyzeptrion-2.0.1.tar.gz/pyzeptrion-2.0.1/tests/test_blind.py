"""Tests for ZeptrionBlind."""

import pytest
from aioresponses import aioresponses

from pyzeptrion.blind import ZeptrionBlind
from pyzeptrion.const import BLIND_OPEN, BLIND_CLOSE, BLIND_STOP, ON_STATE, OFF_STATE

from .conftest import (
    HOST, CHN,
    DESC_URL, STATE_URL, CTRL_URL,
    DESC_XML_BLIND, STATE_ON_XML, STATE_OFF_XML,
)


@pytest.fixture
def blind():
    return ZeptrionBlind(HOST, CHN, session=None)


# ---------------------------------------------------------------------------
# Factory: create()
# ---------------------------------------------------------------------------

async def test_create_returns_blind_instance():
    with aioresponses() as m:
        m.get(DESC_URL, body=DESC_XML_BLIND, status=200)
        m.get(STATE_URL, body=STATE_OFF_XML, status=200)
        b = await ZeptrionBlind.create(HOST, CHN)

    assert isinstance(b, ZeptrionBlind)
    await b.close()


async def test_create_sets_name():
    with aioresponses() as m:
        m.get(DESC_URL, body=DESC_XML_BLIND, status=200)
        m.get(STATE_URL, body=STATE_OFF_XML, status=200)
        b = await ZeptrionBlind.create(HOST, CHN)

    assert b.name == "TestBlind"
    await b.close()


async def test_create_sets_dev_type():
    with aioresponses() as m:
        m.get(DESC_URL, body=DESC_XML_BLIND, status=200)
        m.get(STATE_URL, body=STATE_OFF_XML, status=200)
        b = await ZeptrionBlind.create(HOST, CHN)

    assert b.dev_type == "Blind"
    await b.close()


async def test_create_sets_initial_state():
    with aioresponses() as m:
        m.get(DESC_URL, body=DESC_XML_BLIND, status=200)
        m.get(STATE_URL, body=STATE_OFF_XML, status=200)
        b = await ZeptrionBlind.create(HOST, CHN)

    assert b.state == OFF_STATE
    await b.close()


# ---------------------------------------------------------------------------
# Commands: move_open / move_close / stop
# ---------------------------------------------------------------------------

async def test_move_open_sends_correct_command(blind):
    with aioresponses() as m:
        m.post(CTRL_URL, status=302, body="")
        await blind.move_open()

        _, calls = list(m.requests.items())[0]
        assert calls[0].kwargs["data"] == {"cmd": BLIND_OPEN}


async def test_move_open_sets_on_state(blind):
    with aioresponses() as m:
        m.post(CTRL_URL, status=302, body="")
        await blind.move_open()

    assert blind._state == ON_STATE


async def test_move_close_sends_correct_command(blind):
    with aioresponses() as m:
        m.post(CTRL_URL, status=302, body="")
        await blind.move_close()

        _, calls = list(m.requests.items())[0]
        assert calls[0].kwargs["data"] == {"cmd": BLIND_CLOSE}


async def test_move_close_sets_off_state(blind):
    with aioresponses() as m:
        m.post(CTRL_URL, status=302, body="")
        await blind.move_close()

    assert blind._state == OFF_STATE


async def test_stop_sends_correct_command(blind):
    with aioresponses() as m:
        m.post(CTRL_URL, status=302, body="")
        await blind.stop()

        _, calls = list(m.requests.items())[0]
        assert calls[0].kwargs["data"] == {"cmd": BLIND_STOP}


async def test_stop_sets_off_state(blind):
    with aioresponses() as m:
        m.post(CTRL_URL, status=302, body="")
        await blind.stop()

    assert blind._state == OFF_STATE


# ---------------------------------------------------------------------------
# Properties
# ---------------------------------------------------------------------------

def test_host_property(blind):
    assert blind.host == HOST


def test_chn_property(blind):
    assert blind.chn == CHN
