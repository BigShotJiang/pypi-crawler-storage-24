"""Tests for ZeptrionRegistry and related discovery classes."""

import pytest
from unittest.mock import AsyncMock, MagicMock, patch

from pyzeptrion.discover import (
    ZeptrionRegistry,
    ZeptrionRegistryDevice,
    ZeptrionZeroconfListener,
)

from .conftest import HOST, CHN, DESC_XML_DIMMABLE, DESC_XML_BLIND, DESC_XML_EMPTY


# ---------------------------------------------------------------------------
# ZeptrionRegistryDevice
# ---------------------------------------------------------------------------

def test_registry_device_properties():
    d = ZeptrionRegistryDevice("10.0.0.1", 2, "Blind")
    assert d.host == "10.0.0.1"
    assert d.chn == 2
    assert d.dev_type == "Blind"


def test_registry_device_str():
    d = ZeptrionRegistryDevice("10.0.0.1", 2, "Blind")
    s = str(d)
    assert "10.0.0.1" in s
    assert "Blind" in s


# ---------------------------------------------------------------------------
# ZeptrionRegistry — basic structure
# ---------------------------------------------------------------------------

def test_registry_empty_on_init():
    r = ZeptrionRegistry()
    assert r.devices == []


def test_registry_devices_is_list():
    r = ZeptrionRegistry()
    assert isinstance(r.devices, list)


# ---------------------------------------------------------------------------
# ZeptrionZeroconfListener
# ---------------------------------------------------------------------------

def test_listener_starts_empty():
    listener = ZeptrionZeroconfListener()
    assert listener.get_data() == []


def test_listener_remove_service_does_not_raise():
    listener = ZeptrionZeroconfListener()
    # Should not raise even with dummy arguments
    listener.remove_service(MagicMock(), "_zapp._tcp.local.", "dummy._zapp._tcp.local.")


# ---------------------------------------------------------------------------
# ZeptrionRegistry.create_registry — with fully mocked zeroconf + bulb
# ---------------------------------------------------------------------------

def _make_mock_info(host, channels, dev_type_bytes=b"FMI.61-1"):
    """Build a mock AsyncServiceInfo object."""
    info = MagicMock()
    info.parsed_addresses.return_value = [host]
    info.properties = {b"type": dev_type_bytes}
    return info


async def test_create_registry_returns_registry_instance():
    mock_listener = MagicMock()
    mock_listener.get_data.return_value = []

    with _patch_zeroconf(mock_listener), \
         patch("pyzeptrion.discover.ZeptrionBulb.create", new_callable=AsyncMock) as mock_create:
        registry = await ZeptrionRegistry.create_registry()

    assert isinstance(registry, ZeptrionRegistry)


async def test_create_registry_empty_network():
    mock_listener = MagicMock()
    mock_listener.get_data.return_value = []

    with _patch_zeroconf(mock_listener):
        registry = await ZeptrionRegistry.create_registry()

    assert registry.devices == []


async def test_create_registry_discovers_dimmable_bulb():
    mock_listener = MagicMock()
    mock_listener.get_data.return_value = [_make_mock_info("10.0.0.1", 1, b"FMI.61-1")]

    mock_device = MagicMock()
    mock_device.dev_type = "Bulb dimmable"
    mock_device.close = AsyncMock()

    with _patch_zeroconf(mock_listener), \
         patch("pyzeptrion.discover.ZeptrionBulb.create", new_callable=AsyncMock, return_value=mock_device):
        registry = await ZeptrionRegistry.create_registry()

    assert len(registry.devices) == 1
    assert registry.devices[0].host == "10.0.0.1"
    assert registry.devices[0].chn == 1
    assert registry.devices[0].dev_type == "Bulb dimmable"


async def test_create_registry_skips_nan_devices():
    mock_listener = MagicMock()
    mock_listener.get_data.return_value = [_make_mock_info("10.0.0.2", 1, b"FMI.61-1")]

    mock_device = MagicMock()
    mock_device.dev_type = "NaN"
    mock_device.close = AsyncMock()

    with _patch_zeroconf(mock_listener), \
         patch("pyzeptrion.discover.ZeptrionBulb.create", new_callable=AsyncMock, return_value=mock_device):
        registry = await ZeptrionRegistry.create_registry()

    assert registry.devices == []


async def test_create_registry_multi_channel_device():
    """A 4-channel device should produce up to 4 entries (minus NaN channels)."""
    mock_listener = MagicMock()
    mock_listener.get_data.return_value = [_make_mock_info("10.0.0.3", 4, b"FMI.61-4")]

    call_count = 0

    async def mock_create(host, chn):
        nonlocal call_count
        call_count += 1
        dev = MagicMock()
        dev.dev_type = "Blind"
        dev.close = AsyncMock()
        return dev

    with _patch_zeroconf(mock_listener), \
         patch("pyzeptrion.discover.ZeptrionBulb.create", side_effect=mock_create):
        registry = await ZeptrionRegistry.create_registry()

    assert call_count == 4
    assert len(registry.devices) == 4


async def test_create_registry_devices_sorted_by_type():
    mock_listener = MagicMock()
    mock_listener.get_data.return_value = [
        _make_mock_info("10.0.0.1", 1, b"FMI.61-1"),
        _make_mock_info("10.0.0.2", 1, b"FMI.61-1"),
    ]

    types = ["Blind", "Bulb dimmable"]
    idx = 0

    async def mock_create(host, chn):
        nonlocal idx
        dev = MagicMock()
        dev.dev_type = types[idx % 2]
        dev.close = AsyncMock()
        idx += 1
        return dev

    with _patch_zeroconf(mock_listener), \
         patch("pyzeptrion.discover.ZeptrionBulb.create", side_effect=mock_create):
        registry = await ZeptrionRegistry.create_registry()

    result_types = [d.dev_type for d in registry.devices]
    assert result_types == sorted(result_types)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _patch_zeroconf(mock_listener):
    """Context manager that patches all zeroconf internals."""
    from contextlib import ExitStack
    stack = ExitStack()

    mock_azc = MagicMock()
    mock_azc.async_close = AsyncMock()
    mock_azc.zeroconf = MagicMock()

    mock_browser = MagicMock()
    mock_browser.async_cancel = AsyncMock()

    stack.enter_context(patch("pyzeptrion.discover.AsyncZeroconf", return_value=mock_azc))
    stack.enter_context(patch("pyzeptrion.discover.AsyncServiceBrowser", return_value=mock_browser))
    stack.enter_context(patch("pyzeptrion.discover.ZeptrionZeroconfListener", return_value=mock_listener))
    stack.enter_context(patch("pyzeptrion.discover.asyncio.sleep", new_callable=AsyncMock))

    return stack
