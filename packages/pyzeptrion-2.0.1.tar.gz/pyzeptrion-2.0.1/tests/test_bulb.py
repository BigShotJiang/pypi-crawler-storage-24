"""Tests for ZeptrionBulb."""

import pytest
from unittest.mock import AsyncMock, patch, call

from pyzeptrion.bulb import ZeptrionBulb
from pyzeptrion.const import (
    BULB_ON, BULB_OFF, BULB_DIMUP, BULB_DIMDOWN, BLIND_STOP,
    ON_STATE, OFF_STATE, DIMMER_FULL_TRAVEL_TIME,
)
from aioresponses import aioresponses

from .conftest import (
    HOST, CHN,
    DESC_URL, STATE_URL, CTRL_URL,
    DESC_XML_DIMMABLE, DESC_XML_ONOFF,
    STATE_ON_XML, STATE_OFF_XML,
)


@pytest.fixture
def bulb():
    return ZeptrionBulb(HOST, CHN, session=None)


# ---------------------------------------------------------------------------
# Factory: create()
# ---------------------------------------------------------------------------

async def test_create_returns_bulb_instance():
    with aioresponses() as m:
        m.get(DESC_URL, body=DESC_XML_DIMMABLE, status=200)
        m.get(STATE_URL, body=STATE_ON_XML, status=200)
        b = await ZeptrionBulb.create(HOST, CHN)

    assert isinstance(b, ZeptrionBulb)
    await b.close()


async def test_create_sets_name():
    with aioresponses() as m:
        m.get(DESC_URL, body=DESC_XML_DIMMABLE, status=200)
        m.get(STATE_URL, body=STATE_ON_XML, status=200)
        b = await ZeptrionBulb.create(HOST, CHN)

    assert b.name == "TestLight"
    await b.close()


async def test_create_sets_dev_type():
    with aioresponses() as m:
        m.get(DESC_URL, body=DESC_XML_DIMMABLE, status=200)
        m.get(STATE_URL, body=STATE_ON_XML, status=200)
        b = await ZeptrionBulb.create(HOST, CHN)

    assert b.dev_type == "Bulb dimmable"
    await b.close()


async def test_create_sets_initial_state_on():
    with aioresponses() as m:
        m.get(DESC_URL, body=DESC_XML_DIMMABLE, status=200)
        m.get(STATE_URL, body=STATE_ON_XML, status=200)
        b = await ZeptrionBulb.create(HOST, CHN)

    assert b.state == ON_STATE
    await b.close()


async def test_create_sets_initial_state_off():
    with aioresponses() as m:
        m.get(DESC_URL, body=DESC_XML_DIMMABLE, status=200)
        m.get(STATE_URL, body=STATE_OFF_XML, status=200)
        b = await ZeptrionBulb.create(HOST, CHN)

    assert b.state == OFF_STATE
    await b.close()


async def test_create_survives_state_fetch_failure():
    """create() must succeed even if get_state() raises."""
    with aioresponses() as m:
        m.get(DESC_URL, body=DESC_XML_DIMMABLE, status=200)
        m.get(STATE_URL, status=500, body="error")
        b = await ZeptrionBulb.create(HOST, CHN)
        assert isinstance(b, ZeptrionBulb)
    await b.close()


# ---------------------------------------------------------------------------
# Simple commands: on / off / dim_up / dim_down
# ---------------------------------------------------------------------------

async def test_on_sends_correct_command(bulb):
    with aioresponses() as m:
        m.post(CTRL_URL, status=302, body="")
        await bulb.on()

        _, calls = list(m.requests.items())[0]
        assert calls[0].kwargs["data"] == {"cmd": BULB_ON}


async def test_off_sends_correct_command(bulb):
    with aioresponses() as m:
        m.post(CTRL_URL, status=302, body="")
        await bulb.off()

        _, calls = list(m.requests.items())[0]
        assert calls[0].kwargs["data"] == {"cmd": BULB_OFF}


async def test_dim_up_sends_correct_command(bulb):
    with aioresponses() as m:
        m.post(CTRL_URL, status=302, body="")
        await bulb.dim_up()

        _, calls = list(m.requests.items())[0]
        assert calls[0].kwargs["data"] == {"cmd": BULB_DIMUP}


async def test_dim_down_sends_correct_command(bulb):
    with aioresponses() as m:
        m.post(CTRL_URL, status=302, body="")
        await bulb.dim_down()

        _, calls = list(m.requests.items())[0]
        assert calls[0].kwargs["data"] == {"cmd": BULB_DIMDOWN}


# ---------------------------------------------------------------------------
# set_level
# ---------------------------------------------------------------------------

async def test_set_level_zero_turns_off(bulb):
    mock_off = AsyncMock()
    with patch.object(bulb, "off", mock_off):
        await bulb.set_level(0)

    mock_off.assert_awaited_once()
    assert bulb._state == OFF_STATE


async def test_set_level_zero_clamps_negative(bulb):
    mock_off = AsyncMock()
    with patch.object(bulb, "off", mock_off):
        await bulb.set_level(-10)

    mock_off.assert_awaited_once()


async def test_set_level_100_ramps_up_then_stops(bulb):
    cmd_calls = []
    sleep_calls = []

    async def mock_post_cmd(cmd):
        cmd_calls.append(cmd)

    async def mock_sleep(t):
        sleep_calls.append(t)

    with patch.object(bulb, "post_cmd", side_effect=mock_post_cmd), \
         patch("pyzeptrion.bulb.asyncio.sleep", side_effect=mock_sleep):
        await bulb.set_level(100)

    assert cmd_calls == [BULB_DIMUP, BLIND_STOP]
    assert sleep_calls[0] == pytest.approx(DIMMER_FULL_TRAVEL_TIME + 0.3)
    assert bulb._state == ON_STATE


async def test_set_level_30_command_sequence(bulb):
    cmd_calls = []
    sleep_calls = []

    async def mock_post_cmd(cmd):
        cmd_calls.append(cmd)

    async def mock_sleep(t):
        sleep_calls.append(t)

    with patch.object(bulb, "post_cmd", side_effect=mock_post_cmd), \
         patch("pyzeptrion.bulb.asyncio.sleep", side_effect=mock_sleep):
        await bulb.set_level(30)

    assert cmd_calls == [BULB_DIMUP, BLIND_STOP, BULB_DIMDOWN, BLIND_STOP]


async def test_set_level_30_ramp_up_sleep_duration(bulb):
    sleep_calls = []

    async def mock_sleep(t):
        sleep_calls.append(t)

    with patch.object(bulb, "post_cmd", AsyncMock()), \
         patch("pyzeptrion.bulb.asyncio.sleep", side_effect=mock_sleep):
        await bulb.set_level(30)

    # First sleep: full ramp up
    assert sleep_calls[0] == pytest.approx(DIMMER_FULL_TRAVEL_TIME + 0.3)
    # Second sleep: 0.2s settling pause
    assert sleep_calls[1] == pytest.approx(0.2)
    # Third sleep: dim_down hold for 70% of travel
    expected_hold = DIMMER_FULL_TRAVEL_TIME * (100 - 30) / 100.0
    assert sleep_calls[2] == pytest.approx(expected_hold)


async def test_set_level_50_hold_duration(bulb):
    sleep_calls = []

    async def mock_sleep(t):
        sleep_calls.append(t)

    with patch.object(bulb, "post_cmd", AsyncMock()), \
         patch("pyzeptrion.bulb.asyncio.sleep", side_effect=mock_sleep):
        await bulb.set_level(50)

    expected_hold = DIMMER_FULL_TRAVEL_TIME * 0.5
    assert sleep_calls[2] == pytest.approx(expected_hold)


async def test_set_level_clamps_above_100(bulb):
    sleep_calls = []

    async def mock_sleep(t):
        sleep_calls.append(t)

    with patch.object(bulb, "post_cmd", AsyncMock()), \
         patch("pyzeptrion.bulb.asyncio.sleep", side_effect=mock_sleep):
        await bulb.set_level(150)

    # Clamped to 100 -> only ramp up, no dim_down
    assert len(sleep_calls) == 2  # ramp + settle, no hold


async def test_set_level_positive_sets_on_state(bulb):
    with patch.object(bulb, "post_cmd", AsyncMock()), \
         patch("pyzeptrion.bulb.asyncio.sleep", AsyncMock()):
        await bulb.set_level(60)

    assert bulb._state == ON_STATE
