"""Class to represent a dimmable or on/off bulb attached to a Zeptrion device."""

import logging
import asyncio

from pyzeptrion.device import ZeptrionDevice
from pyzeptrion.const import (
    BULB_DIMDOWN,
    BULB_DIMUP,
    BULB_OFF,
    BULB_ON,
    OFF_STATE,
    ON_STATE,
    BLIND_STOP,
    DIMMER_FULL_TRAVEL_TIME,
)

_LOGGER = logging.getLogger(__name__)


class ZeptrionBulb(ZeptrionDevice):
    """A class for a Zeptrion bulb derived from ZeptrionDevice."""

    def __init__(self, host: str, chn: str, session=None) -> None:
        super().__init__(host, chn, session)

    @classmethod
    async def create(cls, host: str, chn: str):
        """Factory that initializes and fetches initial description/state."""
        self = cls(host, chn)
        await self._set_description()
        try:
            self._state = await self.get_state()
        except Exception:
            pass
        return self

    # --- Convenience controls ---
    async def on(self):
        return await self.post_cmd(BULB_ON)

    async def off(self):
        return await self.post_cmd(BULB_OFF)

    async def dim_up(self):
        return await self.post_cmd(BULB_DIMUP)

    async def dim_down(self):
        return await self.post_cmd(BULB_DIMDOWN)

    async def set_level(self, target: int) -> None:
        """Dim to target brightness (0..100) using time-based press-and-hold.

        The Zeptrion API does not expose the actual current brightness level —
        the state endpoint only returns 0 (off) or 100 (on). Therefore dimming
        is done by:
          1. Ramping fully up (ensures a known starting point at 100%).
          2. Holding dim_down for the proportional fraction of DIMMER_FULL_TRAVEL_TIME.
          3. Sending stop.
        Calling set_level(0) simply turns the light off.
        """
        target = max(0, min(100, int(target)))

        if target == 0:
            await self.off()
            self._state = OFF_STATE
            return

        # Ramp to 100% so we always start from a known position.
        await self.post_cmd(BULB_DIMUP)
        await asyncio.sleep(DIMMER_FULL_TRAVEL_TIME + 0.3)
        await self.post_cmd(BLIND_STOP)
        await asyncio.sleep(0.2)

        if target == 100:
            self._state = ON_STATE
            return

        # Dim down from 100% to target.
        hold = DIMMER_FULL_TRAVEL_TIME * (100 - target) / 100.0
        await self.post_cmd(BULB_DIMDOWN)
        await asyncio.sleep(hold)
        await self.post_cmd(BLIND_STOP)
        self._state = ON_STATE
