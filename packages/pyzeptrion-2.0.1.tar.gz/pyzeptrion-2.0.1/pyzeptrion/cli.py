import argparse
import asyncio

from pyzeptrion.blind import ZeptrionBlind
from pyzeptrion.bulb import ZeptrionBulb
from pyzeptrion.discover import ZeptrionRegistry
from .const import (
    BULB_ON,
    BULB_OFF,
    BULB_DIMDOWN,
    BULB_DIMUP,
    BULB_TOGGLE,
    BLIND_CLOSE,
    BLIND_OPEN,
    BLIND_STOP,
)

VALID_BULB_CMDS = {BULB_ON, BULB_OFF, BULB_TOGGLE, BULB_DIMUP, BULB_DIMDOWN}
VALID_BLIND_CMDS = {BLIND_OPEN, BLIND_CLOSE, BLIND_STOP}


async def _safe_close(obj):
    try:
        close = getattr(obj, "close", None)
        if close is not None:
            if asyncio.iscoroutinefunction(close):
                await close()
            else:
                close()
    except Exception:
        pass


async def main():
    """Entry point of the cli."""
    parser = argparse.ArgumentParser(
        description="Command line interface for the pyzeptrion library."
    )
    parser.add_argument("action", choices=["set", "discover"], help='"set" oder "discover"')
    parser.add_argument("-a", "--address", help="IP-Adresse des Geraets")
    parser.add_argument("-c", "--channel", type=int, help="Kanal des Geraets (Integer)")
    parser.add_argument(
        "-p",
        "--params",
        help='Kommando: fuer Bulb {on, off, toggle, dim_up, dim_down, dim_to}; fuer Blind {move_open, move_close, stop}',
    )
    parser.add_argument(
        "--level",
        type=int,
        help="Helligkeit 0-100 fuer dimmbare Lampen (nur mit -p dim_to)",
    )

    args = parser.parse_args()

    # Registry erstellen
    my_registry = await ZeptrionRegistry.create_registry()

    temp_device = None
    try:
        if args.action == "discover":
            for device in my_registry.devices:
                print(device)
            for device in my_registry.devices:
                await _safe_close(device)

        elif args.action == "set":
            if not args.address:
                print("IP address is empty.")
                return
            if args.channel is None:
                print("Channel is empty.")
                return
            if args.params is None:
                print("Parameter is empty.")
                return

            # Device im Registry finden
            for device in my_registry.devices:
                if args.address == getattr(device, "host", None) and args.channel == getattr(device, "chn", None):
                    print("Passendes Zeptrion-Geraet im Registry gefunden:")
                    print(device)
                    if getattr(device, "dev_type", None) == "Blind":
                        temp_device = await ZeptrionBlind.create(args.address, str(args.channel))
                    else:
                        temp_device = await ZeptrionBulb.create(args.address, str(args.channel))
                    break
            else:
                print("no device found")
                return

            # Dimmbare Spezialbehandlung: dim_to
            if getattr(temp_device, "dev_type", None) == "Bulb dimmable" and args.params == "dim_to":
                if args.level is None or not (0 <= args.level <= 100):
                    print("Bitte --level 0..100 fuer dimmbare Lampen angeben.")
                    return
                await temp_device.set_level(args.level)
                print(f"Dimmed to ~{args.level}%.")
                return

            # Normale Kommandos pruefen
            if getattr(temp_device, "dev_type", None) == "Blind":
                if args.params not in VALID_BLIND_CMDS:
                    print(f'Parameter "{args.params}" kann nicht fuer Blind verwendet werden. Erlaubt: {sorted(VALID_BLIND_CMDS)}')
                    return
            elif getattr(temp_device, "dev_type", None) in ["Bulb on/off", "Bulb dimmable"]:
                if args.params not in VALID_BULB_CMDS:
                    print(f'Parameter "{args.params}" kann nicht fuer Bulb verwendet werden. Erlaubt: {sorted(VALID_BULB_CMDS)} oder "dim_to" mit --level.')
                    return
            else:
                print(f'Unerwarteter Geraetetyp: {getattr(temp_device, "dev_type", None)}')
                return

            await temp_device.post_cmd(args.params)
            print("Succesfully changed the state of the device!")
            print(temp_device)

    finally:
        if temp_device is not None:
            await _safe_close(temp_device)
        await _safe_close(my_registry)


if __name__ == "__main__":
    asyncio.run(main())
