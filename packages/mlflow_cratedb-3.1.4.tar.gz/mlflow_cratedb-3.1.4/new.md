# MLflow and CrateDB


## About MLflow

[MLflow] is an open source platform to manage the ML lifecycle, including
experimentation, reproducibility, deployment, and a central model registry.
MLflow currently offers four components:

- [MLflow Tracking]\: Record and query experiments: code, data, config, and results
- [MLflow Projects]\: Package data science code in a format to reproduce runs on any platform
- [MLflow Models]\: Deploy machine learning models in diverse serving environments
- [MLflow Model Registry]\: Store, annotate, discover, and manage models in a central repository.

An [MLflow Model][MLflow Models] is a standard format for packaging machine
learning models that can be used in a variety of downstream tools—for example,
real-time serving through a REST API or batch inference on Apache Spark. The
format defines a convention that lets you save a model in different "flavors"
that can be understood by different downstream tools.


## What's inside

This folder provides guidelines and runnable code to get started with [MLflow]
and [CrateDB].

- [readme.md](readme.md): The file you are currently reading contains a walkthrough
  about how to install an MLflow stack, and how to use the [MLflow Tracking]
  subsystem on behalf on an experiment run.
- [requirements.txt](requirements.txt): Pulls in a patched version of MLflow,
  [mlflow-cratedb], and the [Merlion] library. MLflow has been adjusted not to
  invoke the database provisioning based on SQLAlchemy and Alembic, but uses a
  traditional approach by running a bunch of SQL DDL statements, fitted to be
  usable with CrateDB.
- [tracking_merlion.py](tracking_merlion.py): The example program uses [Merlion],
  a Python library for time series intelligence, which can be used for time series
  anomaly detection and forecasting. Before running an experiment for demonstration
  purposes, it will import the `machine_temperature_system_failure.csv` dataset
  from the [Numenta Anomaly Benchmark] data.


## Install

In order to properly set up a development sandbox environment, it is advised
to create a Python virtualenv, and install the dependencies there. In this
way, it is easy to wipe your virtualenv and start from scratch anytime.

```shell
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```


## Setup

The upcoming commands expect that you are working on a terminal with
activated virtualenv.
```shell
source .venv/bin/activate
```



## Run Experiment

In another terminal, run the Python program which defines the experiment. You can
point it towards the MLflow server you just started, using the `MLFLOW_TRACKING_URI`
environment variable, so the program will send events and outcomes from experiment
runs, and the MLflow server will record them.

```shell
export MLFLOW_TRACKING_URI=http://127.0.0.1:5000
python tracking_merlion.py
```



[CrateDB]: https://github.com/crate/crate
[CrateDB Cloud]: https://console.cratedb.cloud/
[Merlion]: https://pypi.org/project/salesforce-merlion/
[MLflow]: https://mlflow.org/
[mlflow-cratedb]: https://github.com/crate/mlflow-cratedb
[MLflow Models]: https://mlflow.org/docs/latest/models.html
[MLflow Model Registry]: https://mlflow.org/docs/latest/model-registry.html
[MLflow Projects]: https://mlflow.org/docs/latest/projects.html
[MLflow Tracking]: https://mlflow.org/docs/latest/tracking.html
[Numenta Anomaly Benchmark]: https://github.com/numenta/NAB
