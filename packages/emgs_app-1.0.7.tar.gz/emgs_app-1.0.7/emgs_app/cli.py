from __future__ import annotations

import sys


def _missing_dep_hint(mod: str) -> str:
    return (
        f"Missing dependency: {mod}\n\n"
        "Install from git (recommended):\n"
        '  pip install "emgs-app @ git+https://<REPO_URL>.git"\n\n'
        "Or, from a local checkout:\n"
        "  python -m venv .venv\n"
        "  source .venv/bin/activate   # Windows: .venv\\Scripts\\activate\n"
        "  pip install -e .\n"
    )


def main() -> int:
    # Safety: never write __pycache__/bytecode into the installed checkout/repo.
    # This keeps the package directory read-only in practice.
    sys.dont_write_bytecode = True

    try:
        from .app import main as _gui_main
    except ModuleNotFoundError as e:
        # Friendly bootstrap message if user forgot to install deps.
        print(_missing_dep_hint(e.name or "unknown"))
        return 1

    return int(_gui_main() or 0)


if __name__ == "__main__":
    raise SystemExit(main())

