# rules/

## 1. 目的
- 提供跨 workflow/skills 的全局约束，确保执行一致、可审计、可闭环。

## 2. 适用场景
- 适用：所有任务在选择 workflow/skills 前的规则对齐。
- 不适用：无仓库操作的纯讨论。

## 3. 输入
| 输入项 | 必填 | 说明 | 示例 |
|---|---|---|---|
| 当前任务描述 | 是 | 用于判定适用规则 | “修复线上回归” |
| AGENTS 约束 | 是 | 根级强约束优先 | `/workspace/AGENTS.md` |

## 4. 步骤
1. 先读取本目录规则，再选择 workflow/skills。
2. 若出现规则冲突，按优先级处理：
   - `AGENTS.md` > `rules/` > workflow/skill 细则。
3. 将关键约束回填到执行计划中（如 gate/issue/PR 关联）。

## 5. 输出
| 输出物 | 格式 | 去向 |
|---|---|---|
| 规则适用结论 | 文本 | 会话上下文 |
| 冲突处理结论 | 文本 | 执行计划 |

## 6. 约束
- 必须：任何执行前先完成规则对齐。
- 必须：冲突时遵循优先级，不可自行降级约束。

## 7. 验证
- [ ] 已读取并应用本目录规则。
- [ ] 冲突处理符合优先级。
- [ ] 执行计划与规则一致。

## Files
- `github-agent-rules.md`: lifecycle, issue-first gate, branch/commit/PR/CI/release rules.
- `review-rules.md`: review focus, evidence expectations, and comment quality requirements.
