# skills/

## 1. 目的
- 提供可组合的能力包（skills），让不同 workflow 在同一执行标准下复用能力。

## 2. 适用场景
- 适用：需要根据任务类型加载对应能力（实现、规划、研究、PR 编写等）。
- 不适用：无需执行动作的纯只读问答。

## 3. 输入
| 输入项 | 必填 | 说明 | 示例 |
|---|---|---|---|
| workflow/stage 路由结果 | 是 | 决定 required/recommended skills | `bugfix / implement-pr` |
| 任务约束与目标 | 是 | 决定是否叠加技能 | “需求不清晰，需要拆解” |

## 4. 步骤
1. 根据 workflow/stage 加载 required skills。
2. 任务复杂或不明确时叠加 `task-planner`。
3. 执行过程中按技能边界分工，不重复职责。
4. 产物回填到 issue/PR，保持可追溯。

## 5. 输出
| 输出物 | 格式 | 去向 |
|---|---|---|
| 技能加载组合 | 文本 | 会话上下文 |
| 对应技能产物 | markdown/链接 | issue/PR |

## 6. 约束
- 必须：优先复用现有技能，避免能力重叠。
- 必须：每个技能保持清晰“Use this skill when”边界。
- 禁止：为同一职责新增重复技能。

## 7. 验证
- [ ] required skills 已加载。
- [ ] 推荐技能叠加有明确理由。
- [ ] 技能边界无冲突且产物可追溯。

## Standard subdirectories
- `scripts/`: 智能体可执行的代码或脚本。
- `references/`: 按需加载的补充文档。
- `assets/`: 模板、图片、数据等静态资源。

## Files
- `task-planner`: split complex tasks into low-risk executable steps.
- `github-operator`: implement, validate, commit, and prepare PR content.
- `exploration-logger`: maintain spike/research logs in a single issue.
- `pr-writer`: produce structured PR descriptions.
- `market-discovery`: run pre-product market opportunity discovery and go/no-go decision.
- `digital-user-research`: run passive user research from public reviews/discussions and output journey map + design recommendations.
- `prd-analyzer`: parse PRD, extract features/modules, build feature/module trees, surface quality issues and clarification list.
- `prd-quality-assessor`: assess quality concerns per feature using ISO 25010 and Android platform scenarios (requires feature tree input).
- `prd-test-cases`: full PRD→test flow (stages 1–4); functional/edge/negative tests, NFR checklists, traceability matrices.

## Composition examples
- feature/bugfix/refactor:
  - `github-operator`
  - add `task-planner` when requirements are unclear
- exploration:
  - `exploration-logger`
  - add `task-planner` for multi-stage investigations
- market analysis / opportunity discovery:
  - `market-discovery`
  - add `task-planner` when the market scope is too broad
- review/comment-based user research:
  - `digital-user-research`
  - add `task-planner` when scope or source coverage is unclear
- PR polishing:
  - `pr-writer`
- PRD → test pipeline (`prd-to-test` workflow):
  - stage 1: `prd-analyzer` (parse + trees + clarification)
  - stage 2: `prd-quality-assessor` (quality concerns per feature)
  - stage 3: `prd-test-cases` (test design + cases only, reuse stage 1–2 outputs)
