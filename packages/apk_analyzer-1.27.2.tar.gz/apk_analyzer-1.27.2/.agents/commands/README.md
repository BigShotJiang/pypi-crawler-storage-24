# commands/

## 1. 目的
- 汇总可复用命令手册，统一执行“路由 + 门禁 + 闭环”检查。

## 2. 适用场景
- 适用：所有 GitHub 任务执行前/中/后的流程检查。
- 不适用：无执行动作的纯问答。

## 3. 输入
| 输入项 | 必填 | 说明 | 示例 |
|---|---|---|---|
| 用户输入 | 是 | 用于按 AGENTS 规则完成 workflow 路由与原因判定 | “修复回归 bug” |
| issue/branch 状态 | 是 | 用于 gate 判断 | `#40` + branch |
| token 状态（如需） | 条件必填 | 用于 GitHub 鉴权操作 | `GITHUB_TOKEN` |

## 4. 步骤
1. 对每次新输入按 `/workspace/AGENTS.md` 执行路由，并输出 `Matched Workflow / Match Reason / Fallback Used`。
2. 任务开始前执行 `issue-first-gate`。
3. 需要 GitHub 鉴权时执行 `github-auth-token`。
4. 任务收尾前执行 `issue-pr-closure-gate`。
5. 任一 gate=BLOCKED 时，先处理阻塞再继续。

## 5. 输出
| 输出物 | 格式 | 去向 |
|---|---|---|
| 工作流路由结果（3 字段） | 文本/json | 会话上下文 |
| Gate 状态（PASS/BLOCKED） | 文本 | 会话上下文 |
| Next Action | 文本 | 执行入口 |

## 6. 约束
- 必须：先按 `AGENTS.md` 路由，再 gate，再执行。
- 必须：Gate=PASS 前禁止实现/提交/PR。
- 必须：BLOCKED 默认由 Cloud Agent 处理，不转交用户。

## 7. 验证
- [ ] 每次新输入已按 `AGENTS.md` 完成路由输出。
- [ ] 任务起始与收尾 gate 已执行。
- [ ] BLOCKED 状态已被消除或明确记录。

## Files
- `issue-first-gate.md`: hard-stop check before implementation actions.
- `github-auth-token.md`: preflight check for GitHub token source and presence.
- `issue-pr-closure-gate.md`: end-to-end check for issue creation, PR linking, and post-merge closure.
