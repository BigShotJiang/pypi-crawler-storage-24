import os
import unittest

from qhub.service.client import HubServiceClient
from qhub.service.datapool import DataPoolReference


class ClientTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        print(f"Token endpoint: {os.environ.get('TOKEN_ENDPOINT')}")
        print(f"Service endpoint: {os.environ.get('SERVICE_ENDPOINT')}")

    @unittest.skip("integration test")
    def test_retrieve_logs(self):
        client = HubServiceClient(
            os.environ.get("SERVICE_ENDPOINT"),
            os.environ.get("ACCESS_KEY_ID"),
            os.environ.get("SECRET_ACCESS_KEY"),
            os.environ.get("TOKEN_ENDPOINT"),
        )
        service_executions = client.get_service_executions()
        print(service_executions)
        logs = service_executions[0].logs()
        print(logs)

    @unittest.skip("integration test")
    def test_create_execution_and_retrieve_result(self):
        client = HubServiceClient(
            os.environ.get("SERVICE_ENDPOINT"),
            os.environ.get("ACCESS_KEY_ID"),
            os.environ.get("SECRET_ACCESS_KEY"),
            os.environ.get("TOKEN_ENDPOINT"),
        )
        service_executions = client.get_service_executions()
        print(service_executions)
        service_execution = client.run({"duration": 10, "num_cpus": 1, "tags": ["foo", "bar"]})
        print(service_execution)
        print(service_execution.status)
        service_execution.wait_for_final_state(timeout=60)
        print(service_execution.status)
        result = service_execution.result()
        print(result)
        logs = service_execution.logs()
        print(logs)
        service_execution.cancel()
        print(service_execution.status)
        service_executions = client.get_service_executions()
        print(service_executions)

    @unittest.skip("integration test")
    def test_using_data_pools(self):
        client = HubServiceClient(
            os.environ.get("SERVICE_ENDPOINT"),
            os.environ.get("ACCESS_KEY_ID"),
            os.environ.get("SECRET_ACCESS_KEY"),
            os.environ.get("TOKEN_ENDPOINT"),
        )
        data = {"file_to_read": "example.txt"}

        dataset = DataPoolReference(id="ac0e22be-9673-4353-bb27-6a19d5b3ba17")
        service_execution = client.run({"data": data, "dataset": dataset.dict()})
        print(service_execution)
        service_execution.wait_for_final_state(timeout=60)
        print(service_execution.status)
        logs = service_execution.logs()
        print(logs)
