# Browser Hybrid — Specification

**Chrome DevTools with accessibility-tree semantics for browser automation.**

Use your existing authenticated Chrome sessions for browser automation, with agent-browser-style accessibility tree element targeting.

---

## Overview

Browser Hybrid (BH) connects to Chrome via the Chrome DevTools Protocol (CDP), enabling browser automation that preserves your logged-in sessions (Gmail, GitHub, banking, SSO). Unlike Selenium/Playwright which spin up fresh browser instances, BH uses Chrome you already have running with `--remote-debugging-port=9222`.

### Key Properties

| Property | Value |
|---|---|
| Language | Python ≥3.10 |
| Dependencies | `websockets >= 12.0` only (stdlib + websockets) |
| Package | `src/browser_hybrid/` |
| Entry point | `browser-hybrid` CLI / `from browser_hybrid import Browser` |
| License | MIT |

---

## Architecture

```
┌─────────────────────────────────────────────────────┐
│                  Browser Hybrid                     │
├─────────────────────────────────────────────────────┤
│  Python API (browser.py)  │  CLI (cli.py)           │
├─────────────────────────────────────────────────────┤
│              CDP Client Layer                        │
│  HTTP API (/json/*)      │  WebSocket API (CDP)    │
│  Tab management          │  DOM/A11y/Page cmds     │
└─────────────────────────────────────────────────────┘
                          │
                          ▼
              ┌────────────────────────┐
              │  Chrome DevTools        │
              │  localhost:9222        │
              │  (your Chrome)         │
              └────────────────────────┘
```

### Chrome Requirement

Chrome must be running with remote debugging enabled:

```bash
# macOS
/Applications/Google\ Chrome.app/Contents/MacOS/Google\ Chrome \
  --remote-debugging-port=9222 \
  --user-data-dir="$HOME/Library/Application Support/Google/Chrome-Debug"

# Linux
google-chrome --remote-debugging-port=9222 --user-data-dir="$HOME/chrome-debug"

# Windows
start chrome --remote-debugging-port=9222 --user-data-dir="%LOCALAPPDATA%\Google\Chrome-Debug"
```

Or use the provided `chrome-debug.sh` helper script.

---

## API Reference

### `Browser(host="localhost", port=9222, timeout=10.0)`

Main browser automation class. Connects to Chrome at the given host/port.

**Raises:** `ConnectionError` if Chrome DevTools is not reachable.

```python
from browser_hybrid import Browser

browser = Browser()                    # Connect to localhost:9222
browser = Browser(port=9223)           # Custom port
```

### Tab Management

#### `browser.list_tabs() -> List[Tab]`
Returns all open browser tabs (excludes service workers).

```python
tabs = browser.list_tabs()
for tab in tabs:
    print(tab.id, tab.title, tab.url)
```

#### `browser.new_tab(url="about:blank") -> Tab`
Opens a new tab and navigates to URL. Sets as current tab.

```python
tab = browser.new_tab("https://gmail.com")
```

#### `browser.activate_tab(tab_id: str) -> bool`
Brings tab to front (focuses it).

#### `browser.close_tab(tab_id: Optional[str] = None) -> bool`
Closes specified tab or current tab if no ID given.

#### `browser.get_version() -> BrowserInfo`
Returns Chrome version and protocol info.

```python
info = browser.get_version()
print(info.browser)        # Chrome/120.0.0.0
print(info.protocol_version)  # 1.3
```

---

### Navigation

#### `browser.navigate(url: str, tab: Optional[Tab] = None) -> str`
Navigates current tab (or specified tab) to URL. Returns frameId.

```python
frame_id = browser.navigate("https://github.com")
```

#### `browser.goto(url: str) -> Tab`
Convenience: creates new tab, navigates, waits 0.5s for initial load. Returns Tab.

```python
tab = browser.goto("https://news.ycombinator.com")
```

#### `browser.wait_for(selector: Optional[str] = None, text: Optional[str] = None, timeout: float = 10.0) -> bool`
Polls until element selector or text content appears. Returns `True` if found, `False` on timeout.

```python
browser.goto("https://example.com")
browser.wait_for(text="Sign in", timeout=15.0)
browser.wait_for(selector="button.submit")
```

---

### Accessibility Tree

#### `browser.accessibility_tree(tab: Optional[Tab] = None) -> AXNode`
Returns the full accessibility tree for the current tab (or specified tab). Tree uses Chrome's `nodeId` as `ref` for element targeting.

```python
tree = browser.accessibility_tree()
print(tree.to_tree_str())

# Find elements
links = tree.find_by_role("link")
buttons = tree.find_by_role("button")
headings = tree.find_by_role("heading")
inputs = tree.find_by_role("textbox")

# Find by text
matches = tree.find_by_name("Submit")

# Find by ref
node = tree.find("42")
```

**Output format** (agent-browser compatible):
```
- RootWebArea "Page Title" [ref=1]
    /url: https://example.com/
  - heading "Welcome" [ref=2] [level=1]
  - link "Sign in" [ref=3]
      /url: /login
  - textbox "Email" [ref=4]
```

#### `browser.snapshot(tab: Optional[Tab] = None) -> str`
Alias for `accessibility_tree().to_tree_str()`.

---

### Interactions

#### `browser.click(ref: str, tab: Optional[Tab] = None) -> bool`
Click element by accessibility ref (nodeId).

```python
browser.click("42")  # Click element with ref=42
```

#### `browser.click_by_text(text: str, tab: Optional[Tab] = None) -> bool`
Click first element matching text. Searches links, buttons, then any clickable element.

```python
browser.click_by_text("Sign in")
browser.click_by_text("Submit")
```

**Behavior:**
1. Search `<a>` elements by innerText/textContent
2. Search `<button>` and `<input type="button/submit">` by text
3. Search any element with exact text match and `.click()` method

Returns `True` if click was dispatched, `False` if no matching element found.

#### `browser.type_text(ref: str, text: str, tab: Optional[Tab] = None) -> bool`
Type text into element identified by ref. Falls back to first input if ref lookup fails.

```python
browser.type_text("42", "hello world")
```

#### `browser.fill_form(fields: Dict[str, str], tab: Optional[Tab] = None) -> bool`
Fill multiple form fields at once. Keys are label text, placeholder, or input name/id.

```python
browser.fill_form({
    "Email": "user@example.com",
    "Password": "secret123"
})
```

**Behavior:**
1. Find `<label>` elements whose text contains the key → use `for` attribute or child input
2. Find input by `name` or `id` matching the key

---

### Content & Screenshot

#### `browser.screenshot(path: str, tab: Optional[Tab] = None) -> str`
Capture PNG screenshot and save to path. Returns path.

```python
browser.screenshot("/tmp/page.png")
browser.screenshot("/tmp/gmail_inbox.png")
```

#### `browser.get_html(tab: Optional[Tab] = None) -> str`
Returns page `outerHTML`.

```python
html = browser.get_html()
```

#### `browser.evaluate(script: str, tab: Optional[Tab] = None) -> Any`
Execute JavaScript and return result (must be JSON-serializable).

```python
title = browser.evaluate("document.title")
count = browser.evaluate("document.querySelectorAll('.item').length")
```

---

## Data Models

### `Tab`

```python
@dataclass
class Tab:
    id: str                  # Chrome tab ID
    url: str                 # Current URL
    title: str               # Page title
    type: str                # "page" (always for our purposes)
    web_socket_debugger_url: str  # CDP WebSocket URL
```

### `AXNode`

Accessibility tree node. Refs are Chrome `nodeId` values.

```python
@dataclass
class AXNode:
    ref: str                          # Accessibility ref (nodeId)
    role: str                         # ARIA role (link, button, textbox, etc.)
    name: str                         # Accessible name
    value: Optional[str] = None       # Input value
    url: Optional[str] = None        # Link URL
    level: Optional[int] = None       # Heading level (1-6)
    focused: bool = False              # Is focused
    children: List["AXNode"] = []      # Child nodes
    parent: Optional["AXNode"] = None # Parent node
```

**Methods:**

| Method | Returns | Description |
|---|---|---|
| `find(ref)` | `Optional[AXNode]` | Find node by ref |
| `find_by_role(role)` | `List[AXNode]` | Find all nodes with ARIA role |
| `find_by_name(text)` | `List[AXNode]` | Find nodes where name contains text (case-insensitive) |
| `find_interactive()` | `List[AXNode]` | Find all interactive elements (link, button, textbox, checkbox, radio, combobox, searchbox, etc.) |
| `to_tree_str()` | `str` | Format as agent-browser-compatible tree string |
| `to_dict()` | `dict` | Serialize to dict |

### `BrowserInfo`

```python
@dataclass
class BrowserInfo:
    browser: str                  # Full browser version string
    protocol_version: str          # CDP protocol version
    user_agent: str                # User-Agent header
    v8_version: str               # V8 JavaScript engine version
    webkit_version: str            # WebKit version
    web_socket_debugger_url: str   # Browser WebSocket URL
```

---

## Exception Hierarchy

```
BrowserError (base)
├── ConnectionError   — Chrome not running or debug port unavailable
├── TabError          — Tab not found or operation failed
└── TimeoutError     — Operation timed out
```

All exceptions inherit from `BrowserError`. Users should catch `BrowserError` for broad coverage or specific subtypes for targeted handling.

---

## CLI Reference

**Usage:** `browser-hybrid <command> [args]`

| Command | Args | Description |
|---|---|---|
| `list` | — | List all open tabs |
| `new` | `<url>` | Open new tab |
| `snapshot` | — | Print accessibility tree |
| `screenshot` | `[path]` | Save screenshot (default: `/tmp/screenshot.png`) |
| `html` | — | Print page HTML |
| `eval` | `<js>` | Execute JavaScript |
| `click` | `<text>` | Click element by text |
| `navigate` | `<url>` | Navigate current tab |
| `close` | `[id...]` | Close tabs (default: all non-chrome:// tabs) |
| `version` | — | Show Chrome version info |

**Examples:**

```bash
browser-hybrid list
browser-hybrid new https://gmail.com
browser-hybrid snapshot
browser-hybrid screenshot /tmp/page.png
browser-hybrid click "Sign in"
browser-hybrid eval "document.title"
browser-hybrid navigate https://github.com
browser-hybrid close
```

---

## Current Implementation Status (v0.1.0)

### Completed ✅

- [x] Tab management (HTTP API): list, new, activate, close
- [x] Navigation: navigate, goto, wait_for (selector/text)
- [x] Accessibility tree: full AX tree via CDP, parse to AXNode tree
- [x] AXNode tree traversal: find, find_by_role, find_by_name, find_interactive
- [x] AXNode tree output: to_tree_str() (agent-browser format), to_dict()
- [x] Click by ref (accessibility nodeId)
- [x] Click by text (link/button/any element)
- [x] Type text into element
- [x] Form filling (label association, name/id, placeholder)
- [x] Screenshot capture (PNG via CDP)
- [x] Page HTML retrieval
- [x] JavaScript evaluation
- [x] CLI interface (all commands)
- [x] Exception hierarchy
- [x] Type hints throughout
- [x] Unit tests (mocked)
- [x] Integration test markers (require Chrome debug mode)

### Not Yet Implemented (v0.2.0+)

- [ ] WebSocket reconnection on disconnect
- [ ] Timeout handling (per-operation timeouts)
- [ ] Custom exception hierarchy refinement
- [ ] `wait_for(url=...)` and `wait_until(condition=...)`
- [ ] Improved form detection (label/for, ARIA)
- [ ] Keyboard input (character-by-character, key combos)
- [ ] Mouse actions (hover, double-click, right-click)
- [ ] Cookie extraction/import
- [ ] Network interception
- [ ] PDF generation
- [ ] Multi-tab coordination
- [ ] Recording/playback

---

## Platform Support

Tested on:
- macOS (Chrome, remote debugging)
- Linux (Chrome/Chromium, remote debugging)
- Windows (Chrome, remote debugging)

The CDP protocol is cross-platform; any Chrome/Chromium-based browser with `--remote-debugging-port` works.

---

## Security Considerations

1. **Localhost only** — CDP debugging on 9222 is localhost-only by default. Do not expose to network.
2. **Arbitrary JS execution** — `evaluate()` runs whatever script you pass. Treat accordingly.
3. **No sandbox** — BH uses your real Chrome session. Actions have real consequences (real emails sent, real data modified).
4. **No authentication** — Anyone with localhost CDP access can automate your browser.

---

## File Structure

```
browser-hybrid/
├── src/browser_hybrid/
│   ├── __init__.py       # Package init, exports Browser, Tab, AXNode, BrowserInfo
│   ├── __main__.py       # python -m browser_hybrid entry point
│   ├── browser.py        # Main Browser class + exceptions
│   ├── cli.py            # CLI implementation
│   └── models.py         # Tab, AXNode, BrowserInfo dataclasses
├── tests/
│   ├── test_browser.py   # Unit tests + integration markers
│   └── SPEC.md           # This file (for test-driven verification)
├── docs/                 # (reserved for MkDocs)
├── pyproject.toml        # Package config (hatchling)
├── README.md             # User-facing overview
├── ROADMAP.md            # Future plans
└── Makefile              # Common tasks
```

---

## Design Decisions

### Why not use Playwright/Selenium DOM APIs?

BH deliberately uses the **accessibility tree** (via `Accessibility.getFullAXTree` CDP) rather than raw DOM or CSS selectors. This gives:
- Semantic element targeting (by role, name, label) instead of fragile selectors
- Ref-based targeting compatible with agent-browser
- Stable across page restructuring (DOM changes but AX tree semantics persist)
- Built-in filtering to interactive elements

### Why WebSockets for commands?

Tab operations (navigation, DOM, accessibility) require bidirectional communication. HTTP is sufficient for tab CRUD, but CDP commands (Page.navigate, Accessibility.getFullAXTree, Runtime.evaluate) require WebSocket. Each CDP command opens a WebSocket, does one operation, closes.

### Why stdlib + websockets only?

Minimal dependency surface. The `urllib` stdlib handles HTTP CDP endpoints. `websockets` handles the WebSocket CDP commands. No heavy browser automation framework needed.

### Why async internal but sync external?

The CDP WebSocket protocol is async. We use `asyncio.run()` internally to bridge sync→async. The public API is synchronous for simplicity. This may change to fully async in a future version if there's demand.

---

*Last updated: 2026-03-22*
