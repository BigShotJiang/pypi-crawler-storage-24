"""
Live tests for browser-hybrid.

End-to-end scenarios testing real-world usage patterns.
These require Chrome running with --remote-debugging-port=9222.

Run: pytest tests/test_live.py -v --live
"""

from __future__ import annotations

import os
import tempfile
import time

import pytest

from browser_hybrid import Browser
from browser_hybrid.errors import ConnectionError

# Skip all tests in this module if no Chrome
# Uses real _check_connection, not mocked
pytestmark = [
    pytest.mark.skipif(
        not os.environ.get("LIVE_TESTS"),
        reason="LIVE_TESTS env var not set",
    ),
    pytest.mark.real_connection_check,
]


@pytest.fixture
def browser():
    """Browser instance for live tests."""
    b = None
    try:
        b = Browser(timeout=30.0)
        yield b
    except ConnectionError:
        pytest.skip("Chrome not running with --remote-debugging-port=9222")
    finally:
        if b:
            try:
                b.close()
            except Exception:
                pass


class TestNavigationLive:
    """Live tests for navigation."""

    def test_navigate_to_example(self, browser):
        """Navigate to example.com."""
        tab = browser.goto("https://example.com", wait=1.0)

        # Verify URL
        assert "example.com" in tab.url

        # Verify title via JS
        title = browser.evaluate("document.title")
        assert title == "Example Domain"

        browser.close_tab(tab.id)

    def test_navigate_to_multiple_pages(self, browser):
        """Navigate through multiple pages."""
        # Start at example.com
        tab = browser.goto("https://example.com", wait=1.0)

        # Navigate to another page
        browser.navigate("https://www.iana.org/domains/reserved")

        # Wait for navigation
        time.sleep(0.5)

        # Verify we're on the new page
        title = browser.evaluate("document.title")
        assert "IANA" in title or "domains" in title.lower()

        browser.close_tab(tab.id)

    def test_wait_for_element(self, browser):
        """Wait for element to appear."""
        # httpbin has dynamic content
        tab = browser.goto("https://httpbin.org/html", wait=2.0)

        # Wait for h1
        found = browser.wait_for(selector="h1", timeout=5.0)
        assert found

        # Get the heading text
        heading = browser.evaluate("document.querySelector('h1').innerText")
        assert len(heading) > 0

        browser.close_tab(tab.id)


class TestAccessibilityLive:
    """Live tests for accessibility tree."""

    def test_parse_complex_page(self, browser):
        """Parse accessibility tree of complex page."""
        tab = browser.goto("https://httpbin.org/html", wait=2.0)

        tree = browser.accessibility_tree()

        # Should have structure
        assert tree.role in ("RootWebArea", "WebArea", "document")

        # Should have heading
        headings = tree.find_by_role("heading")
        assert len(headings) > 0

        # Should have paragraphs
        paragraphs = tree.find_by_role("paragraph")
        assert len(paragraphs) > 0

        browser.close_tab(tab.id)

    def test_find_links(self, browser):
        """Find links via accessibility tree."""
        tab = browser.goto("https://example.com", wait=1.0)

        tree = browser.accessibility_tree()
        links = tree.find_by_role("link")

        # example.com has a link to www.iana.org
        assert len(links) >= 1

        # First link should have URL
        if links:
            assert links[0].url is not None

        browser.close_tab(tab.id)

    def test_find_interactive(self, browser):
        """Find interactive elements."""
        # httpbin forms page has inputs
        tab = browser.goto("https://httpbin.org/forms/post", wait=1.0)

        tree = browser.accessibility_tree()
        interactive = tree.find_interactive()

        # Should have form elements
        roles = {el.role for el in interactive}
        assert "textbox" in roles or "button" in roles or "checkbox" in roles

        browser.close_tab(tab.id)


class TestInteractionsLive:
    """Live tests for interactions."""

    def test_click_link(self, browser):
        """Click a link."""
        tab = browser.goto("https://example.com", wait=1.0)

        # Click "More information" link
        browser.click_by_text("More information")

        # Wait for navigation
        time.sleep(1.0)

        # Should have navigated to iana.org
        current_url = browser.evaluate("window.location.href")
        assert "iana.org" in current_url

        browser.close_tab(tab.id)

    def test_click_button(self, browser):
        """Click a button."""
        # httpbin has buttons
        tab = browser.goto("https://httpbin.org/forms/post", wait=1.0)

        # Find and click submit button
        tree = browser.accessibility_tree()
        buttons = tree.find_by_role("button")

        if buttons:
            # Click via ref
            browser.click(buttons[0].ref)
            # Note: submit will navigate, we don't verify result here

        browser.close_tab(tab.id)

    def test_evaluate_javascript(self, browser):
        """Execute various JavaScript."""
        tab = browser.goto("https://example.com", wait=1.0)

        # Simple expression
        result = browser.evaluate("1 + 1")
        assert result == 2

        # DOM access
        result = browser.evaluate("document.querySelectorAll('p').length")
        assert result >= 0

        # String result
        result = browser.evaluate("document.title")
        assert result == "Example Domain"

        browser.close_tab(tab.id)


class TestScrenshotLive:
    """Live tests for screenshots."""

    def test_screenshot_png(self, browser):
        """Take PNG screenshot."""
        tab = browser.goto("https://example.com", wait=1.0)

        with tempfile.NamedTemporaryFile(suffix=".png", delete=False) as f:
            path = f.name

        try:
            result_path = browser.screenshot(path)
            assert os.path.exists(result_path)
            assert os.path.getsize(result_path) > 1000  # At least 1KB

            # Verify it's a PNG
            with open(result_path, "rb") as f:
                header = f.read(8)
                assert header[:4] == b"\x89PNG"

        finally:
            if os.path.exists(path):
                os.unlink(path)

        browser.close_tab(tab.id)


class TestErrorHandlingLive:
    """Live tests for error handling."""

    def test_invalid_url(self, browser):
        """Handle invalid URL."""
        # Chrome will show an error page, not raise exception
        tab = browser.new_tab("not-a-url")

        # Should still be able to get tree (error page)
        tree = browser.accessibility_tree()
        assert tree is not None

        browser.close_tab(tab.id)

    def test_nonexistent_element_click(self, browser):
        """Click nonexistent element returns False."""
        tab = browser.goto("https://example.com", wait=1.0)

        result = browser.click_by_text("XyzzyPlughBazoo")
        assert result is False

        browser.close_tab(tab.id)


class TestConnectionPoolLive:
    """Live tests for connection pool."""

    def test_connection_persists(self, browser):
        """Connection persists across operations."""
        tab = browser.goto("https://example.com", wait=1.0)

        # Multiple operations
        for _ in range(5):
            browser.accessibility_tree()
            browser.evaluate("1 + 1")

        # Should still work
        result = browser.evaluate("2 + 2")
        assert result == 4

        browser.close_tab(tab.id)

    def test_reconnect_after_tab_close(self, browser):
        """Can create new connection after closing tab."""
        # Create and close first tab
        tab1 = browser.new_tab("https://example.com")
        browser.close_tab(tab1.id)

        # Create second tab
        tab2 = browser.new_tab("https://example.com")

        # Should work fine
        tree = browser.accessibility_tree()
        assert tree is not None

        browser.close_tab(tab2.id)


class TestFormFillingLive:
    """Live tests for form filling."""

    def test_fill_form(self, browser):
        """Fill form fields."""
        tab = browser.goto("https://httpbin.org/forms/post", wait=1.0)

        # Fill form fields by label
        browser.fill_form(
            {
                "custname": "Test Customer",
                "custtel": "555-1234",
            }
        )

        # Verify values were set
        name_value = browser.evaluate("document.querySelector('input[name=custname]').value")
        assert name_value == "Test Customer"

        browser.close_tab(tab.id)
