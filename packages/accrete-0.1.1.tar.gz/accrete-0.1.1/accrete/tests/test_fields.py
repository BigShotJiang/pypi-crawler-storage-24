from django.utils import translation
from django.test import TestCase
from accrete.models import AccessGroup
from accrete.utils import translated_db_value


class FieldTestCase(TestCase):

    lang_settings = {
        'LANGUAGE_CODE': 'en-us',
        'LANGUAGES': [
            ('de-de', 'German'),
            ('en-us', 'English'),
        ]
    }

    def test_assign_string(self):
        with self.settings(**self.lang_settings):
            group = AccessGroup(
                name='Test en-us',
                description='Test Description en-us',
                code='test',
            )
            group.save()
            self.assertEqual(group.name, 'Test en-us')
            self.assertEqual(group.description, 'Test Description en-us')
            translation.activate('de-de')
            self.assertEqual(group.name, 'Test en-us')
            self.assertEqual(group.description, 'Test Description en-us')
            translation.activate('en-us')

    def test_assign_string_german(self):
        with self.settings(**self.lang_settings):
            translation.activate('de-de')
            group = AccessGroup(
                name='Test de-de',
                description='Test Description de-de',
                code='test',
            )
            group.save()
            self.assertEqual(group.name, 'Test de-de')
            self.assertEqual(group.description, 'Test Description de-de')
            translation.activate('en-us')
            self.assertEqual(group.name, 'Test de-de')
            self.assertEqual(group.description, 'Test Description de-de')
            translation.activate('en-us')

    def test_write_string(self):
        with self.settings(**self.lang_settings):
            translation.activate('en-us')
            group = AccessGroup(
                name='Test en-us',
                description='Test Description en-us',
                code='test',
            )
            group.save()
            translation.activate('de-de')
            group.name = 'Test de-de'
            group.description = 'Test Description de-de'
            group.save()
            self.assertEqual(group.name, 'Test de-de')
            self.assertEqual(group.description, 'Test Description de-de')
            translation.activate('en-us')
            group.refresh_from_db()
            self.assertEqual(group.name, 'Test en-us')
            self.assertEqual(group.description, 'Test Description en-us')
            self.assertDictEqual(
                translated_db_value(group, 'name'),
                {'en-us': 'Test en-us', 'de-de': 'Test de-de'}
            )

    def test_assign_dict(self):
        with self.settings(**self.lang_settings):
            group = AccessGroup(
                name={'en-us': 'Test en-us', 'de-de': 'Test de-de'},
                description={
                    'en-us': 'Test Description en-us',
                    'de-de': 'Test Description de-de'
                },
                code='test',
            )
            group.save()
            self.assertEqual(group.name, 'Test en-us')
            self.assertEqual(group.description, 'Test Description en-us')
            translation.activate('de-de')
            group.refresh_from_db()
            self.assertEqual(group.name, 'Test de-de')
            self.assertEqual(group.description, 'Test Description de-de')
            translation.activate('en-us')
            self.assertDictEqual(
                translated_db_value(group, 'name'),
                {'en-us': 'Test en-us', 'de-de': 'Test de-de'}
            )
            self.assertDictEqual(
                translated_db_value(group, 'description'),
                {'en-us': 'Test Description en-us', 'de-de': 'Test Description de-de'}
            )
