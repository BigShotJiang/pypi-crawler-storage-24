from django.test import TestCase
from accrete.contrib.ui.templatetags import ui as tags


class TemplatetagsTestCase(TestCase):

    def test_zero_trail_no_str(self):
        value = None
        res = tags.zero_trail(value)
        self.assertIsNone(res)
        value = 50
        res = tags.zero_trail(value)
        self.assertEqual(value, res)

    def test_zero_trail(self):
        values = [
            ('', ''), ('1', '1'), ('10', '10'), ('01', '01'),
            ('010', '010'), ('1.10', '1.1'), ('1,11', '1,11'),
            ('1.01', '1.01'), ('1.010', '1.01'), ('1.0', '1')
        ]
        for value in values:
            res = tags.zero_trail(value[0])
            self.assertEqual(res, value[1])
