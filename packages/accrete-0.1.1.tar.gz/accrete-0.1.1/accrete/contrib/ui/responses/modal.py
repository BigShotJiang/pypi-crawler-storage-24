
import re
from django.utils.functional import Promise
from .response import Response


class ModalResponse(Response):

    def __init__(
        self, *,
        modal_id: str,
        template: str,
        context: dict,
        title: str | Promise = None,
        is_update: bool = False,
        is_blocking: bool = False,
        modal_width: str = None

    ):
        super().__init__(template=template, context=context)
        self.modal_id = modal_id
        self.title = title
        self.is_update = is_update
        self.is_blocking = is_blocking
        self.modal_width = modal_width

    def get_context(self):
        context = super().get_context()
        context.update({
            'title': self.title,
            'modal_id': re.sub(r'[^A-Za-z-]+', '', self.modal_id).strip('-'),
            'is_update': self.is_update,
            'is_blocking': self.is_blocking,
            'modal_width': self.modal_width
        })
        return context
