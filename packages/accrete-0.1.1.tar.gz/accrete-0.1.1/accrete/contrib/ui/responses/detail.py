from .response import Response, add_trigger


class DetailResponse(Response):

    base_template = 'ui/detail.html'

    def __init__(
        self, *,
        context: dict,
        header_template: str = None,
        data_template: str = None
    ):
        super().__init__(template=self.base_template, context=context)
        self.header_template = header_template
        self.data_template = data_template
        self.context.update()

    def add_trigger(self, response):
        super().add_trigger(response)
        add_trigger(response, 'activate-detail')

    def get_context(self):
        context = super().get_context()
        context.update({
            'detail_header_template': self.header_template,
            'detail_data_template': self.data_template
        })
        return context
