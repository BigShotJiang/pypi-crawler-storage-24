from dataclasses import dataclass
from django.shortcuts import HttpResponse
from django.utils.functional import Promise

from .response import Response


@dataclass(kw_only=True)
class WindowResponseConfig:

    display_header: bool = True

    def dict(self):
        return vars(self)


class WindowResponse(Response):

    base_template = 'ui/layout.html'

    def __init__(
        self, *,
        title: str | Promise,
        context: dict = None,
        overview_template: str = None,
        header_template: str = None,
        panel_template: str = None,
        style_template: str = None,
        script_template: str = None,
        is_centered: bool = False,
        config: WindowResponseConfig = None
    ):
        super().__init__(template=self.base_template, context=context)
        self.title = title
        self.overview_template = overview_template
        self.header_template = header_template
        self.panel_template = panel_template
        self.style_template = style_template
        self.script_template = script_template
        self.is_centered = is_centered
        self.config = config or WindowResponseConfig()

    def _has_panel(self):
        return bool(self.panel_template)

    def get_context(self):
        context = super().get_context()
        if 'has_panel' not in context.keys():
            context.update(has_panel=self._has_panel())
        context.update({
            'title': self.title,
            'overview_template': self.overview_template,
            'header_template': self.header_template,
            'panel_template': self.panel_template,
            'style_template': self.style_template,
            'script_template': self.script_template,
            'is_centered': self.is_centered,
            'config': self.config.dict()
        })
        return context

    def response(self, request, extra_content: str = None, replace_body: bool = True) -> HttpResponse:
        return super().response(request, extra_content, replace_body)
