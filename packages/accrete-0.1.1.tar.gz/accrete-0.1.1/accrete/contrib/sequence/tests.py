from django.test import TestCase
from accrete.models import Tenant
from accrete.tenant import set_tenant
from accrete.contrib.sequence.models import Sequence
from accrete.contrib.sequence import get_nextval


class SequenceTestCase(TestCase):

    def setUp(self):
        super().setUp()
        tenant = Tenant(name='test')
        tenant.save()
        set_tenant(tenant)

    def test_sequence_new(self):
        sequence_data = get_nextval('test_new', create_values={})
        self.assertEqual(sequence_data.counter, 1)
    
    def test_sequence_per_year_new(self):
        sequence_data = get_nextval(
            'test_per_year_new', 
            create_values={'has_subsequence_per_year': True}
        )
        self.assertEqual(sequence_data.counter, 1)
        base_sequence = Sequence.objects.get(name='test_per_year_new')
        self.assertEqual(base_sequence.nextval, 1)
        sequence_for_year = Sequence.objects.get(name='test_per_year_new__2026')
        self.assertEqual(sequence_for_year.nextval, 2)
        sequence_data = get_nextval('test_per_year_new')
        self.assertEqual(sequence_data.counter, 2)
