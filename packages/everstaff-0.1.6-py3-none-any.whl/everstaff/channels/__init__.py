"""HITL channel implementations."""
