import{h as t}from"./_baseUniq-B7rcs83s.js";var n=Object.prototype,o=n.hasOwnProperty;function s(r,a){return r!=null&&o.call(r,a)}function h(r,a){return r!=null&&t(r,a,s)}export{h};
