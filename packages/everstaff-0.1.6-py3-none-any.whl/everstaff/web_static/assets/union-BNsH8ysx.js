import{c as r,d as e}from"./_baseUniq-B7rcs83s.js";import{av as s,aw as t}from"./index-BwOzunQK.js";var o=s(function(a){return r(e(a,1,t,!0))});export{o as u};
