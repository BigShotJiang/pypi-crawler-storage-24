import{b as r}from"./_baseUniq-B7rcs83s.js";var e=4;function a(o){return r(o,e)}export{a as c};
