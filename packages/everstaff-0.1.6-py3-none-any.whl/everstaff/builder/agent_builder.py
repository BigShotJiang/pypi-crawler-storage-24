from __future__ import annotations

import asyncio
import logging
import datetime
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

from everstaff.builder.environment import RuntimeEnvironment
from everstaff.core.context import AgentContext
from everstaff.core.runtime import AgentRuntime
from everstaff.tools.pipeline import ToolCallPipeline
from everstaff.tools.stages import ExecutionStage, PermissionStage
from everstaff.schema.agent_spec import AgentSpec
from everstaff.tools.default_registry import DefaultToolRegistry
from everstaff.protocols import AgentEvent, CancellationEvent


class AgentBuilder:
    """
    Single place that knows how to assemble AgentContext from AgentSpec + RuntimeEnvironment.
    AgentRuntime has no knowledge of this class.
    """

    def __init__(
        self,
        spec: AgentSpec,
        env: RuntimeEnvironment,
        parent_model_id: str | None = None,
        parent_session_id: str | None = None,
        parent_cancellation: CancellationEvent | None = None,
        hooks: list[Any] | None = None,
        caller_span_id: str | None = None,
        session_id: str | None = None,
        trigger: "AgentEvent | None" = None,
        root_session_id: str | None = None,
        user_input: str | None = None,
        user_id: str | None = None,
    ) -> None:
        self._spec = spec
        self._env = env
        self._parent_model_id = parent_model_id
        self._parent_session_id = parent_session_id
        self._parent_cancellation = parent_cancellation
        self._hooks = hooks or []
        self._caller_span_id = caller_span_id
        self._session_id = session_id
        self._trigger = trigger
        self._root_session_id = root_session_id
        self._user_input = user_input
        self._user_id = user_id
        self._feishu_auto_allow: list[str] = []

    def _resolve_model(self) -> str:
        """Resolve the concrete LiteLLM model string for this agent.

        Priority:
        1. spec.model_override — explicit override takes precedence
        2. spec.adviced_model_kind == "inherit" → use parent model id
        3. spec.adviced_model_kind → looked up in config.model_mappings
        """
        if self._spec.model_override:
            return self._spec.model_override

        if self._spec.adviced_model_kind == "inherit":
            if self._parent_model_id:
                return self._parent_model_id
            # fallthrough: defensive, shouldn't happen at top level

        kind = self._spec.adviced_model_kind
        if kind == "inherit":
            kind = "smart"  # defensive fallback when no parent provided
        return self._env.config.resolve_model(kind).model_id

    def _build_system_prompt(self) -> str | None:
        parts = []
        # 1. Runtime environment context
        now = datetime.datetime.now().astimezone()
        parts.append(f"Current local time: {now.strftime('%Y-%m-%dT%H:%M:%S%z')} ({now.tzname()})\n")

        # 2. Project context
        try:
            from everstaff.project_context import ProjectContextLoader
            loader = ProjectContextLoader(self._env.project_root())
            proj = loader.load()
            if proj:
                parts.append(proj)
        except Exception as exc:
            logger.debug("ProjectContextLoader unavailable: %s", exc)

        # 3. Agent instructions
        if self._spec.instructions:
            parts.append(self._spec.instructions)
        return "\n\n".join(parts) if parts else None

    async def build(self) -> tuple[AgentRuntime, AgentContext]:
        # 0. Generate session_id first so it can be passed to tracer
        session_id = self._session_id or self._env.new_session_id()

        # Resolve root_session_id: explicit > parent > self (root)
        root_session_id = self._root_session_id
        if root_session_id is None:
            root_session_id = self._parent_session_id if self._parent_session_id else session_id

        workdir = self._env.working_dir(session_id, root_session_id=root_session_id)
        model_id = self._resolve_model()

        # Resolve cancellation FIRST so all children share the same event
        cancellation = self._parent_cancellation if self._parent_cancellation is not None else CancellationEvent()

        # Determine mem0 scope
        mem0_scope = {}
        if self._env.config.memory.enabled:
            mem0_scope["agent_id"] = self._spec.uuid or self._spec.agent_name
            mem0_scope["user_id"] = self._user_id or "default"

        # 1. Build independent modules in parallel
        memory, tracer = await asyncio.gather(
            self._build_memory(session_id, **mem0_scope),
            self._build_tracer(session_id),
        )

        # Register nested path for child sessions
        if root_session_id != session_id:
            from everstaff.session.index import SessionIndex
            relpath = SessionIndex.session_relpath(session_id, root_session_id)
            if hasattr(memory, "set_session_path"):
                memory.set_session_path(session_id, relpath)

        tool_registry = self._build_tool_registry(workdir)
        sub_agent_provider = self._build_sub_agent_provider(model_id, workdir, session_id, cancellation, root_session_id)

        # Build mem0 provider early so we can prefetch in parallel
        extra_providers = []
        mem0_provider = self._env.build_mem0_provider(**mem0_scope)
        if mem0_provider is not None:
            extra_providers.append(mem0_provider)
            # Start mem0 search in background — runs concurrently with the
            # gather below (MCP connect, skill/knowledge loading).
            if self._user_input:
                mem0_provider.start_prefetch(self._user_input)

        # Build memory tool provider (injects search/write/delete tools when memory is on)
        from everstaff.memory.tool_provider import MemoryToolProvider
        memory_tool_provider = MemoryToolProvider(
            mem0_provider._client if mem0_provider is not None else None,
            mem0_scope,
        )

        # Build skill, knowledge, and MCP providers in parallel
        skill_provider, knowledge_provider, mcp_provider = await asyncio.gather(
            self._build_skill_provider(),
            self._build_knowledge_provider(),
            self._build_mcp_provider(),
        )

        hooks = list(self._hooks)
        if mem0_provider is not None:
            mem0_hook = self._env.build_mem0_hook(mem0_provider, memory, **mem0_scope)
            if mem0_hook is not None:
                hooks.append(mem0_hook)

        # Collect system tool names (framework + provider)
        def _tool_name(t) -> str:
            return t.name if hasattr(t, "name") else t.definition.name

        system_tool_names: set[str] = set()

        # Provider tools (skills, knowledge, sub-agent, MCP)
        for provider in (skill_provider, knowledge_provider, sub_agent_provider, mcp_provider, memory_tool_provider):
            for t in provider.get_tools():
                system_tool_names.add(_tool_name(t))

        # Internal daemon tools — always bypass permission checks
        system_tool_names.update({
            "make_decision",
            "break_down_goal",
            "update_goal_progress",
            "record_learning_insight",
        })

        # Framework tools
        hitl_mode = getattr(self._spec, "hitl_mode", "on_request")
        if hitl_mode != "never":
            system_tool_names.add("request_human_input")
        if getattr(self._spec, "sub_agents", None):
            system_tool_names.add("delegate_task_to_subagent")
        if getattr(self._spec, "workflow", None):
            system_tool_names.add("write_workflow_plan")
        if getattr(self._spec, "enable_bootstrap", False):
            system_tool_names.update(("create_agent", "create_skill"))

        # Framework tools (e.g. system_reconcile) are builtin-only
        # and should bypass permission checks.
        _FRAMEWORK_TOOL_NAMES = {"system_reconcile"}
        spec_tools = set(getattr(self._spec, "tools", None) or [])
        source = getattr(self._spec, "source", "custom")
        if source == "builtin":
            system_tool_names.update(spec_tools & _FRAMEWORK_TOOL_NAMES)

        # Resolve file_store BEFORE permissions (needed for session grants)
        try:
            file_store = self._env.build_file_store()
        except NotImplementedError:
            file_store = None

        # Load session grants from session.json if resuming
        session_grants = await self._load_session_grants(file_store)

        permissions = self._build_permissions(
            system_tool_names=system_tool_names,
            session_grants=session_grants,
        )

        # 1b. Register tools from all providers into the shared registry
        for tool in sub_agent_provider.get_tools():
            tool_registry.register(tool)
        for tool in skill_provider.get_tools():
            tool_registry.register(tool)
        for tool in knowledge_provider.get_tools():
            tool_registry.register(tool)
        for tool in mcp_provider.get_tools():
            tool_registry.register(tool)
        for tool in memory_tool_provider.get_tools():
            tool_registry.register(tool)

        # 1c. Register DAGTool if workflow is configured
        dag_tool = self._build_workflow_tool(session_id, model_id, cancellation, tracer, memory, root_session_id)
        if dag_tool:
            tool_registry.register_native(dag_tool)

        # 2. Assemble pipeline (order is explicit and intentional)
        pipeline = ToolCallPipeline([
            PermissionStage(permissions),
            ExecutionStage(tool_registry),
        ])

        # Resolve sessions_dir from environment (may be None for non-CLI envs)
        sessions_dir = self._env.sessions_dir() if callable(getattr(self._env, "sessions_dir", None)) else None

        # 3. Build context
        context = AgentContext(
            # Required
            tool_registry=tool_registry,
            memory=memory,
            tool_pipeline=pipeline,

            # Basic
            agent_name=self._spec.agent_name,
            agent_uuid=self._spec.uuid,
            system_prompt=self._build_system_prompt(),
            permissions=permissions,
            skill_provider=skill_provider,
            knowledge_provider=knowledge_provider,
            sub_agent_provider=sub_agent_provider,
            mcp_provider=mcp_provider,

            # Metadata & infrastructure
            session_id=session_id,
            parent_session_id=self._parent_session_id,
            root_session_id=root_session_id,
            tracer=tracer,
            hooks=hooks,
            extra_providers=extra_providers,
            cancellation=cancellation,
            caller_span_id=self._caller_span_id,

            # Bootstrap support
            sessions_dir=sessions_dir,
            file_store=file_store,
            workdir=workdir,

            # LLM limits for metadata persistence
            max_tokens=getattr(self._spec, "max_tokens", None),

            # Event that triggered this session (e.g. from scheduler)
            trigger=self._trigger,
        )

        # Wire env reference for dynamic agent/skill registration
        context._env = self._env
        # Wire channel_manager from environment (set by API/CLI layer)
        if self._env.channel_manager is not None:
            context.channel_manager = self._env.channel_manager
        # Wire hitl_router from environment for source-aware HITL routing
        if self._env.hitl_router is not None:
            context.hitl_router = self._env.hitl_router
            # Wire channel_manager + session_id into HITL tool for notify-type broadcasts
            from everstaff.tools.hitl_tool import RequestHumanInputTool
            for tool in tool_registry._tools.values():
                if isinstance(tool, RequestHumanInputTool):
                    tool._channel_manager = self._env.channel_manager
                    tool._session_id = session_id

        # 4. Build LLM client and runtime
        # Forward AgentSpec overrides (max_tokens, temperature) to LiteLLM kwargs.
        llm_kwargs: dict = {}
        if getattr(self._spec, "max_tokens", None) is not None:
            llm_kwargs["max_tokens"] = self._spec.max_tokens
        if getattr(self._spec, "temperature", None) is not None:
            llm_kwargs["temperature"] = self._spec.temperature
        llm_client = self._env.build_llm_client(model_id, **llm_kwargs)

        # 5. Register bootstrap tools only when explicitly enabled
        if getattr(self._spec, "enable_bootstrap", False):
            from everstaff.tools.bootstrap import CreateAgentTool
            from everstaff.skills.create_skill_tool import CreateSkillTool

            bootstrap_tool = CreateAgentTool(ctx=context, llm=llm_client)
            tool_registry.register_native(bootstrap_tool)

            # Filter out package builtin dir (read-only) from install dirs
            install_dirs = list(self._env.config.skills_dirs)
            try:
                import everstaff as _pkg
                builtin = str(Path(_pkg.__file__).parent / "builtin_skills")
                install_dirs = [d for d in install_dirs if str(Path(d).expanduser().resolve()) != str(Path(builtin).resolve())]
            except Exception:
                pass

            create_skill_tool = CreateSkillTool(install_dirs=install_dirs)
            tool_registry.register_native(create_skill_tool)

        return AgentRuntime(context=context, llm_client=llm_client), context

    async def _build_memory(self, session_id: str = "", **mem0_scope):
        # Resolve the model's max_tokens so the memory store can set a
        # context-aware compression threshold (0.7 × max_tokens).
        kind = self._spec.adviced_model_kind
        if kind == "inherit":
            kind = "smart"
        try:
            model_max_tokens = self._env.config.resolve_model(kind).max_tokens
        except Exception:
            model_max_tokens = None
        return self._env.build_memory_store(max_tokens=model_max_tokens, **mem0_scope)

    async def _build_tracer(self, session_id: str = ""):
        return self._env.build_tracer(session_id)

    def _build_permissions(
        self,
        system_tool_names: set[str] | None = None,
        session_grants: list[str] | None = None,
    ):
        from everstaff.permissions.rule_checker import RuleBasedChecker
        from everstaff.permissions.dynamic_checker import DynamicPermissionChecker

        global_cfg = self._env.config.permissions

        # Global checker — only if global has any rules
        global_checker = None
        if global_cfg.allow or global_cfg.deny:
            global_checker = RuleBasedChecker(
                allow=global_cfg.allow,
                deny=global_cfg.deny,
            )

        # Agent checker — explicit allow/deny from spec ONLY
        # NO auto-injection of spec.tools
        agent_cfg = self._spec.permissions
        agent_allow = list(agent_cfg.allow) + getattr(self, '_feishu_auto_allow', [])
        agent_checker = RuleBasedChecker(
            allow=agent_allow,
            deny=list(agent_cfg.deny),
        )

        return DynamicPermissionChecker(
            global_checker=global_checker,
            agent_checker=agent_checker,
            session_grants=session_grants or [],
            is_system_tool=lambda name: name in (system_tool_names or set()),
        )

    async def _load_session_grants(self, file_store) -> list[str]:
        """Load extra_permissions from session.json if resuming."""
        if not self._session_id or file_store is None:
            return []
        try:
            import json
            from everstaff.session.index import SessionIndex
            path = SessionIndex.session_relpath(self._session_id, self._root_session_id)
            if not await file_store.exists(path):
                return []
            raw = await file_store.read(path)
            data = json.loads(raw.decode())
            return data.get("extra_permissions", [])
        except Exception:
            return []

    def _build_tool_registry(self, workdir: Path | None = None) -> DefaultToolRegistry:
        reg = DefaultToolRegistry()
        tool_names = list(getattr(self._spec, "tools", None) or [])

        # Separate framework tools from regular tools
        framework_tools, regular_tools = self._split_framework_tools(tool_names)

        # Register regular tools via ToolLoader
        if regular_tools:
            from everstaff.tools.loader import ToolLoader
            loader = ToolLoader(self._env.config.tools_dirs)
            for t in loader.load(regular_tools, workdir=workdir):
                reg.register_native(t)

        # Register framework tools (builtin-only)
        for tool in framework_tools:
            reg.register_native(tool)

        # Register HITL tool unless explicitly disabled
        hitl_mode = getattr(self._spec, "hitl_mode", "on_request")
        if hitl_mode != "never":
            from everstaff.tools.hitl_tool import RequestHumanInputTool
            reg.register_native(RequestHumanInputTool(mode=hitl_mode))

        # Register Feishu user-identity tools if configured on any Lark channel
        self._register_feishu_tools(reg)

        return reg

    def _register_feishu_tools(self, reg: DefaultToolRegistry) -> None:
        """Register Feishu user-identity tools if any LarkWs channel has feishu_tools configured."""
        from everstaff.core.config import LarkWsChannelConfig

        channels = self._env.config.channels or {}
        logger.debug("_register_feishu_tools checking %d channels", len(channels))
        for name, ch_cfg in channels.items():
            logger.debug("_register_feishu_tools channel=%s type=%s is_lark_ws=%s feishu_tools=%s",
                         name, type(ch_cfg).__name__, isinstance(ch_cfg, LarkWsChannelConfig),
                         getattr(ch_cfg, 'feishu_tools', None))
            if not isinstance(ch_cfg, LarkWsChannelConfig) or not ch_cfg.feishu_tools:
                continue

            # Find the matching channel instance for card sending
            auth_handler = None
            _auth_channel = None
            if self._env.channel_manager is not None:
                from everstaff.channels.lark_ws import LarkWsChannel
                for ch in self._env.channel_manager._channels:
                    if isinstance(ch, LarkWsChannel) and ch._app_id == ch_cfg.app_id:
                        _auth_channel = ch
                        break

            # Resolve Feishu open_id: prefer trigger payload (daemon loop),
            # fall back to user_id (Lark private-chat sessions via _send_to_session).
            feishu_open_id = ""
            if self._trigger is not None:
                feishu_open_id = self._trigger.payload.get("sender_open_id", "")
            if not feishu_open_id and self._user_id:
                feishu_open_id = self._user_id

            # Build auth_handler now that feishu_open_id is known
            if _auth_channel is not None:
                from everstaff.tools.feishu.auth_handler import FeishuAuthHandler
                auth_handler = FeishuAuthHandler(_auth_channel, user_open_id=feishu_open_id)

            from everstaff.tools.feishu.token_store import FileTokenStore
            # Resolve sessions_dir to absolute path (config may store a relative
            # path like ".agent/sessions" which depends on process CWD).
            raw_sessions_dir = self._env.sessions_dir() or self._env.config.sessions_dir
            token_base = Path(raw_sessions_dir).expanduser().resolve() / "feishu-tokens"
            logger.info("feishu token_store base_dir=%s (raw=%s)", token_base, raw_sessions_dir)
            token_store = FileTokenStore(base_dir=token_base)

            try:
                from everstaff.tools.feishu.tools.registry import create_feishu_tools
                tools = create_feishu_tools(
                    app_id=ch_cfg.app_id,
                    app_secret=ch_cfg.app_secret,
                    domain=ch_cfg.domain,
                    categories=ch_cfg.feishu_tools,
                    auth_handler=auth_handler,
                    user_open_id=feishu_open_id,
                    token_store=token_store,
                )
                for t in tools:
                    reg.register_native(t)

                # Resolve auto-allow list
                auto_allow = ch_cfg.auto_allow_tools
                if auto_allow:
                    if "*" in auto_allow:
                        allow_names = [t.name for t in tools]
                    else:
                        allow_names = [n for n in auto_allow if any(t.name == n for t in tools)]
                    self._feishu_auto_allow = allow_names
                    logger.info("feishu auto_allow_tools: %s", allow_names)

                logger.info("registered %d feishu tools from channel %s: %s", len(tools), name, ch_cfg.feishu_tools)
            except Exception as exc:
                logger.error("failed to register feishu tools from channel %s: %s", name, exc, exc_info=True)
            break  # Only register once (first channel with feishu_tools)

    def _split_framework_tools(self, tool_names: list[str]) -> tuple[list, list[str]]:
        """Separate framework tools from regular tools.

        Framework tools require env injection and are only available to builtin agents.
        Returns (framework_tool_instances, remaining_tool_names).
        """
        from everstaff.tools.reconcile import SystemReconcileTool

        _FRAMEWORK_TOOL_FACTORIES = {
            "system_reconcile": lambda env: SystemReconcileTool(env),
        }

        framework = []
        regular = []
        source = getattr(self._spec, "source", "custom")

        for name in tool_names:
            factory = _FRAMEWORK_TOOL_FACTORIES.get(name)
            if factory is not None:
                if source != "builtin":
                    logger.warning(
                        "Framework tool '%s' is only available to builtin agents (source=%s), skipping",
                        name, source,
                    )
                    continue
                framework.append(factory(self._env))
            else:
                regular.append(name)

        return framework, regular

    async def _build_skill_provider(self):
        if not self._spec.skills:
            from everstaff.nulls import NullSkillProvider
            return NullSkillProvider()
        try:
            from everstaff.skills.manager import SkillManager
            # Merge built-in skills dir (last so user dirs take precedence via first-dir-wins)
            skills_dirs = list(self._env.config.skills_dirs)
            try:
                import everstaff as _pkg
                builtin = str(Path(_pkg.__file__).parent / "builtin_skills")
                if builtin not in skills_dirs:
                    skills_dirs.append(builtin)
            except Exception:
                pass
            return SkillManager(
                skills_dirs=skills_dirs,
                active_skill_names=self._spec.skills,
            )
        except Exception as exc:
            logger.debug("SkillManager unavailable for skills %s: %s", self._spec.skills, exc)
            from everstaff.nulls import NullSkillProvider
            return NullSkillProvider()

    async def _build_knowledge_provider(self):
        if not getattr(self._spec, "knowledge_base", None):
            from everstaff.nulls import NullKnowledgeProvider
            return NullKnowledgeProvider()
        try:
            from everstaff.knowledge.manager import KnowledgeManager
            return KnowledgeManager(self._spec.knowledge_base)
        except Exception as exc:
            logger.debug("KnowledgeManager unavailable: %s", exc)
            from everstaff.nulls import NullKnowledgeProvider
            return NullKnowledgeProvider()

    def _build_sub_agent_provider(self, model_id: str, workdir: Path, session_id: str, cancellation: "CancellationEvent", root_session_id: str | None = None):
        if not getattr(self._spec, "sub_agents", None):
            from everstaff.nulls import NullSubAgentProvider
            return NullSubAgentProvider()
        from everstaff.agents.sub_agent_provider import DefaultSubAgentProvider

        specs = []
        for key, sub_spec in self._spec.sub_agents.items():
            if not sub_spec.name:
                sub_spec = sub_spec.model_copy(update={"name": key})
            specs.append(sub_spec)

        return DefaultSubAgentProvider(
            specs=specs,
            env=self._env,
            parent_model_id=model_id,
            parent_session_id=session_id,
            parent_cancellation=cancellation,
            parent_hooks=self._hooks,
            root_session_id=root_session_id,
        )

    async def _build_mcp_provider(self):
        if not self._spec.mcp_servers:
            from everstaff.nulls import NullMcpProvider
            return NullMcpProvider()
        try:
            pool = self._env.mcp_pool
            if pool is not None:
                from everstaff.mcp_client.provider import PooledMcpProvider
                provider = PooledMcpProvider(self._spec.mcp_servers, pool=pool)
            else:
                from everstaff.mcp_client.provider import DefaultMcpProvider
                provider = DefaultMcpProvider(self._spec.mcp_servers)
            await provider.connect_all()
            return provider
        except Exception as exc:
            logger.warning("MCP provider setup failed, falling back to NullMcpProvider: %s", exc)
            from everstaff.nulls import NullMcpProvider
            return NullMcpProvider()

    def _build_workflow_tool(
        self,
        session_id: str,
        model_id: str,
        cancellation: "CancellationEvent",
        tracer: Any,
        memory: Any = None,
        root_session_id: str | None = None,
    ):
        if not getattr(self._spec, "workflow", None):
            return None
        from everstaff.workflow.factory import WorkflowSubAgentFactory
        from everstaff.workflow.dag_tool import DAGTool
        factory = WorkflowSubAgentFactory(
            available_agents=self._spec.sub_agents or {},
            env=self._env,
            parent_session_id=session_id,
            parent_cancellation=cancellation,
            parent_model_id=model_id,
            root_session_id=root_session_id,
        )
        return DAGTool(
            factory=factory,
            max_parallel=self._spec.workflow.max_parallel,
            cancellation=cancellation,
            tracer=tracer,
            session_id=session_id,
            coordinator_name=self._spec.agent_name,
            memory=memory,
        )
