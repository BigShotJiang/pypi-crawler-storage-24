"""CLI GPI – Point d'entrée principal."""
from __future__ import annotations
import sys
import typer
from rich.console import Console
from rich.panel import Panel
from pathlib import Path

app = typer.Typer(
    name="gpi",
    help="GPI – Générateur de Projet Intelligent 🚀",
    add_completion=False,
)
console = Console()


@app.command()
def init(
    config: str = typer.Option(None, "--config", "-c",
        help="Fichier de configuration YAML/JSON (optionnel)"),
    no_network: bool = typer.Option(False, "--no-network",
        help="Désactiver la détection réseau"),
):
    """Générer un nouveau projet backend."""
    # Vérification Python
    if sys.version_info < (3, 8):
        console.print("[red]❌ Python 3.8+ requis.[/]")
        raise typer.Exit(1)

    try:
        if config:
            cfg = _from_file(config)
        else:
            from gpi.core.profile import collecter_config
            cfg = collecter_config()

        if no_network:
            cfg.local_ip = "localhost"

        # Vérifier les permissions d'écriture
        from gpi.utils.file_utils import verifier_permissions
        projet_dir = Path.cwd() / cfg.nom
        if not verifier_permissions(projet_dir.parent):
            console.print("[red]❌ Impossible d'écrire dans ce dossier.[/]")
            import sys as _sys
            if _sys.platform == "win32":
                console.print("[yellow]💡 Relancez le terminal en tant qu'Administrateur.[/]")
            else:
                console.print("[yellow]💡 Utilisez sudo ou changez de répertoire.[/]")
            raise typer.Exit(1)

        # Vérifier le dossier
        from gpi.utils.file_utils import verifier_dossier
        result = verifier_dossier(projet_dir)
        if result is None:
            console.print("[yellow]Annulé.[/]")
            raise typer.Exit(0)
        if result != cfg.nom:
            cfg.nom = result

        # Récapitulatif
        _afficher_recap(cfg)
        from rich.prompt import Confirm
        if not Confirm.ask("\n✅ Générer le projet ?", default=True):
            console.print("[yellow]Annulé.[/]")
            raise typer.Exit(0)

        # Génération
        console.print("\n[bold]⏳ Génération en cours...[/]")
        from rich.progress import Progress
        with Progress() as progress:
            task = progress.add_task("Création des fichiers...", total=100)
            from gpi.generators.factory import get_generator
            gen = get_generator(cfg)
            progress.update(task, advance=30)
            racine = gen.generer()
            progress.update(task, advance=70)

        # Message final
        _afficher_final(cfg, racine)

    except KeyboardInterrupt:
        console.print("\n[yellow]Interrompu. Aucun fichier généré.[/]")
        raise typer.Exit(0)
    except Exception as e:
        console.print(f"\n[red]❌ Erreur : {e}[/]")
        raise typer.Exit(1)


@app.command()
def version():
    """Afficher la version de GPI."""
    from gpi import __version__
    console.print(f"GPI v{__version__}")


def _from_file(path: str):
    """Charge la config depuis un fichier YAML/JSON."""
    from gpi.core.config import ProjectConfig
    import yaml
    p = Path(path)
    if not p.exists():
        console.print(f"[red]Fichier {path} introuvable.[/]")
        raise typer.Exit(1)
    data = yaml.safe_load(p.read_text(encoding="utf-8"))
    return ProjectConfig(**data)


def _afficher_recap(cfg):
    """Affiche un récapitulatif des choix."""
    lignes = [
        f"[cyan]Framework[/]    : {cfg.framework}",
        f"[cyan]Architecture[/] : {cfg.architecture}",
        f"[cyan]Niveau[/]       : {cfg.niveau}",
        f"[cyan]Nom[/]          : {cfg.nom}",
        f"[cyan]Base de données[/] : {cfg.database}",
        f"[cyan]Auth[/]         : {cfg.auth}",
        f"[cyan]Tests[/]        : {'oui' if cfg.tests else 'non'}",
        f"[cyan]Docker[/]       : {'oui' if cfg.docker else 'non'}",
        f"[cyan]Langue[/]       : {cfg.langue}",
        f"[cyan]IP locale[/]    : {cfg.local_ip}",
    ]
    if cfg.architecture == "microservices":
        lignes.append(f"[cyan]Services[/]     : {', '.join(cfg.services)}")
    if cfg.redis:
        lignes.append(f"[cyan]Redis[/]        : oui")
    if cfg.queue != "aucune":
        lignes.append(f"[cyan]Queue[/]        : {cfg.queue}")

    console.print(Panel("\n".join(lignes), title="📋 Récapitulatif", border_style="cyan"))


def _afficher_final(cfg, racine: Path):
    """Affiche le message de succès."""
    msg = f'[bold green]✅ Projet généré avec succès dans "{cfg.nom}"[/]\n\n'
    msg += "[bold]Pour lancer votre application :[/]\n"
    msg += f"  cd {cfg.nom}\n"
    msg += "  pip install -r requirements.txt\n"

    if cfg.framework == "fastapi":
        msg += f"  uvicorn main:app --reload --host 0.0.0.0 --port {cfg.port}\n\n"
        msg += f"  Documentation : http://localhost:{cfg.port}/docs\n"
    elif cfg.framework == "flask":
        msg += "  python run.py\n"
    elif cfg.framework == "django":
        msg += "  python manage.py migrate\n"
        msg += f"  python manage.py runserver 0.0.0.0:{cfg.port}\n"

    if cfg.local_ip != "localhost":
        msg += f"\n  📱 Mobile : http://{cfg.local_ip}:{cfg.port}\n"

    msg += "\n[bold]Bon développement ! 🚀[/]"
    console.print(Panel(msg, border_style="green"))


if __name__ == "__main__":
    app()
