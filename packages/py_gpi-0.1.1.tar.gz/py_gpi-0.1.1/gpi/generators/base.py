"""Classe abstraite pour tous les générateurs."""
from __future__ import annotations
from abc import ABC, abstractmethod
from pathlib import Path
from gpi.core.config import ProjectConfig
from gpi.utils.file_utils import generer_fichiers
from gpi.utils.i18n import cmt


class BaseGenerator(ABC):
    def __init__(self, config: ProjectConfig):
        self.cfg = config
        self.racine = Path.cwd() / config.nom
        self.ctx = self._build_ctx()

    def _build_ctx(self) -> dict:
        c = self.cfg
        return {
            "nom": c.nom, "description": c.description or c.nom,
            "secret_key": c.secret_key, "database": c.database,
            "auth": c.auth, "has_auth": c.auth != "aucune",
            "has_jwt": c.auth == "jwt", "has_oauth2": c.auth == "oauth2",
            "has_tests": c.tests, "has_docker": c.docker,
            "has_redis": c.redis, "has_monitoring": c.monitoring,
            "queue": c.queue, "has_queue": c.queue != "aucune",
            "route_org": c.route_org, "split_routes": c.route_org == "split",
            "langue": c.langue, "local_ip": c.local_ip, "port": c.port,
            "niveau": c.niveau, "services": c.services,
            "architecture": c.architecture, "is_micro": c.architecture == "microservices",
            "framework": c.framework,
            "cmt": lambda k: cmt(k, c.langue),
        }

    def generer(self) -> Path:
        self.racine.mkdir(parents=True, exist_ok=True)
        f = self._communs()
        f.update(self._specifiques())
        if self.cfg.auth != "aucune":
            f.update(self._auth())
        if self.cfg.tests:
            f.update(self._tests())
        if self.cfg.docker:
            f.update(self._docker())
        generer_fichiers(self.racine, f, self.ctx)
        return self.racine

    def _communs(self) -> dict[str, str]:
        return {
            ".env": TPL_ENV, ".env.example": TPL_ENV_EX,
            ".gitignore": TPL_GIT, "README.md": TPL_README,
        }

    @abstractmethod
    def _specifiques(self) -> dict[str, str]: ...
    def _auth(self) -> dict[str, str]: return {}
    def _tests(self) -> dict[str, str]: return {}
    def _docker(self) -> dict[str, str]: return {}


TPL_ENV = """\
{{ cmt("env_config") }}
SECRET_KEY={{ secret_key }}
DATABASE_URL={% if database == "sqlite" %}sqlite:///./{{ nom }}.db{% elif database == "postgresql" %}postgresql://postgres:postgres@localhost:5432/{{ nom }}{% else %}mysql://root:root@localhost:3306/{{ nom }}{% endif %}

HOST=0.0.0.0
PORT={{ port }}
DEBUG=true
{% if has_redis %}REDIS_URL=redis://localhost:6379/0{% endif %}
"""

TPL_ENV_EX = """\
SECRET_KEY=changez-moi
DATABASE_URL=sqlite:///./app.db
HOST=0.0.0.0
PORT={{ port }}
DEBUG=true
"""

TPL_GIT = """\
__pycache__/
*.pyc
.env
*.db
.venv/
venv/
dist/
*.egg-info/
.pytest_cache/
"""

TPL_README = """\
# {{ nom }}

{{ description }}

## Installation

```bash
pip install -r requirements.txt
```

## Lancement
{% if framework == "fastapi" %}
```bash
uvicorn main:app --reload --host 0.0.0.0 --port {{ port }}
```
Documentation interactive : http://localhost:{{ port }}/docs
{% elif framework == "flask" %}
```bash
python run.py
```
{% elif framework == "django" %}
```bash
python manage.py migrate
python manage.py runserver 0.0.0.0:{{ port }}
```
{% endif %}
{% if local_ip != "localhost" %}
## Tester sur mobile

Connectez votre mobile au même réseau Wi-Fi :
http://{{ local_ip }}:{{ port }}
{% endif %}

---
Généré par GPI 🚀
"""
