"""Générateur Flask monolithique."""
from __future__ import annotations
from gpi.generators.base import BaseGenerator


class FlaskMonolithique(BaseGenerator):
    def _specifiques(self) -> dict[str, str]:
        f = {"requirements.txt": TPL_REQ, "run.py": TPL_RUN,
             "app/__init__.py": TPL_APP_INIT, "app/database.py": TPL_DB,
             "app/models/__init__.py": "", "app/models/item.py": TPL_MODEL}
        if self.ctx["split_routes"]:
            f["app/routes/__init__.py"] = TPL_ROUTES_INIT
            f["app/routes/items/__init__.py"] = ""
            f["app/routes/items/create.py"] = TPL_R_CREATE
            f["app/routes/items/read.py"] = TPL_R_READ
            f["app/routes/items/update.py"] = TPL_R_UPDATE
            f["app/routes/items/delete.py"] = TPL_R_DELETE
        else:
            f["app/routes/__init__.py"] = TPL_ROUTES_INIT
            f["app/routes/items.py"] = TPL_ROUTES
        return f

    def _auth(self) -> dict[str, str]:
        return {
            "app/auth/__init__.py": "",
            "app/auth/routes.py": TPL_AUTH,
            "app/auth/security.py": TPL_AUTH_SEC,
            "app/models/user.py": TPL_USER_MODEL,
        }

    def _tests(self) -> dict[str, str]:
        return {"tests/__init__.py": "", "tests/test_app.py": TPL_TEST}

    def _docker(self) -> dict[str, str]:
        return {"Dockerfile": TPL_DOCKERFILE, "docker-compose.yml": TPL_COMPOSE}


TPL_REQ = """\
{{ cmt("requirements") }}
flask>=3.0.0
flask-sqlalchemy>=3.1.0
python-dotenv>=1.0.0
{% if has_jwt %}pyjwt>=2.8.0
passlib[bcrypt]>=1.7.4
{% endif %}{% if database == "postgresql" %}psycopg2-binary>=2.9.0
{% endif %}{% if has_tests %}pytest>=7.0.0
{% endif %}"""

TPL_RUN = """\
{{ cmt("main_app") }}
import os
from dotenv import load_dotenv

load_dotenv()

from app import create_app

app = create_app()

if __name__ == "__main__":
    app.run(host=os.getenv("HOST", "0.0.0.0"),
            port=int(os.getenv("PORT", {{ port }})),
            debug=os.getenv("DEBUG", "true").lower() == "true")
"""

TPL_APP_INIT = """\
{{ cmt("main_app") }}
from flask import Flask
from app.database import db

def create_app():
    app = Flask(__name__)
    app.config["SECRET_KEY"] = "{{ secret_key }}"
    app.config["SQLALCHEMY_DATABASE_URI"] = (
        "{% if database == "sqlite" %}sqlite:///{{ nom }}.db{% else %}postgresql://postgres:postgres@localhost:5432/{{ nom }}{% endif %}"
    )
    db.init_app(app)

    from app.routes import register_routes
    register_routes(app)
    {% if has_auth %}
    from app.auth.routes import auth_bp
    app.register_blueprint(auth_bp, url_prefix="/auth")
    {% endif %}

    with app.app_context():
        db.create_all()

    return app
"""

TPL_DB = """\
{{ cmt("db_config") }}
from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()
"""

TPL_MODEL = """\
{{ cmt("item_model") }}
from app.database import db
from datetime import datetime

class Item(db.Model):
    __tablename__ = "items"
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(255), nullable=False)
    description = db.Column(db.String(500), default="")
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    def to_dict(self):
        return {"id": self.id, "name": self.name,
                "description": self.description,
                "created_at": str(self.created_at)}
"""

TPL_ROUTES_INIT = """\
def register_routes(app):
    {% if split_routes %}from app.routes.items.create import create_bp
    from app.routes.items.read import read_bp
    from app.routes.items.update import update_bp
    from app.routes.items.delete import delete_bp
    app.register_blueprint(create_bp, url_prefix="/items")
    app.register_blueprint(read_bp, url_prefix="/items")
    app.register_blueprint(update_bp, url_prefix="/items")
    app.register_blueprint(delete_bp, url_prefix="/items")
    {% else %}from app.routes.items import items_bp
    app.register_blueprint(items_bp, url_prefix="/items")
    {% endif %}
"""

TPL_ROUTES = """\
{{ cmt("crud_create") }}
{{ cmt("crud_read") }}
{{ cmt("crud_update") }}
{{ cmt("crud_delete") }}
from flask import Blueprint, request, jsonify
from app.database import db
from app.models.item import Item

items_bp = Blueprint("items", __name__)

@items_bp.route("/", methods=["POST"])
def create_item():
    data = request.get_json()
    item = Item(name=data["name"], description=data.get("description", ""))
    db.session.add(item); db.session.commit()
    return jsonify(item.to_dict()), 201

@items_bp.route("/", methods=["GET"])
def read_items():
    items = Item.query.all()
    return jsonify([i.to_dict() for i in items])

@items_bp.route("/<int:item_id>", methods=["GET"])
def read_item(item_id):
    item = db.session.get(Item, item_id)
    if not item: return jsonify({"error": "Non trouvé"}), 404
    return jsonify(item.to_dict())

@items_bp.route("/<int:item_id>", methods=["PUT"])
def update_item(item_id):
    item = db.session.get(Item, item_id)
    if not item: return jsonify({"error": "Non trouvé"}), 404
    data = request.get_json()
    if "name" in data: item.name = data["name"]
    if "description" in data: item.description = data["description"]
    db.session.commit()
    return jsonify(item.to_dict())

@items_bp.route("/<int:item_id>", methods=["DELETE"])
def delete_item(item_id):
    item = db.session.get(Item, item_id)
    if not item: return jsonify({"error": "Non trouvé"}), 404
    db.session.delete(item); db.session.commit()
    return jsonify({"ok": True})
"""

_BP_BASE = """\
from flask import Blueprint, request, jsonify
from app.database import db
from app.models.item import Item
"""

TPL_R_CREATE = _BP_BASE + """
create_bp = Blueprint("create", __name__)

{{ cmt("crud_create") }}
@create_bp.route("/", methods=["POST"])
def create_item():
    data = request.get_json()
    item = Item(name=data["name"], description=data.get("description", ""))
    db.session.add(item); db.session.commit()
    return jsonify(item.to_dict()), 201
"""

TPL_R_READ = _BP_BASE + """
read_bp = Blueprint("read", __name__)

{{ cmt("crud_read") }}
@read_bp.route("/", methods=["GET"])
def read_items():
    return jsonify([i.to_dict() for i in Item.query.all()])

@read_bp.route("/<int:item_id>", methods=["GET"])
def read_item(item_id):
    item = db.session.get(Item, item_id)
    if not item: return jsonify({"error": "Non trouvé"}), 404
    return jsonify(item.to_dict())
"""

TPL_R_UPDATE = _BP_BASE + """
update_bp = Blueprint("update", __name__)

{{ cmt("crud_update") }}
@update_bp.route("/<int:item_id>", methods=["PUT"])
def update_item(item_id):
    item = db.session.get(Item, item_id)
    if not item: return jsonify({"error": "Non trouvé"}), 404
    data = request.get_json()
    if "name" in data: item.name = data["name"]
    if "description" in data: item.description = data["description"]
    db.session.commit()
    return jsonify(item.to_dict())
"""

TPL_R_DELETE = _BP_BASE + """
delete_bp = Blueprint("delete", __name__)

{{ cmt("crud_delete") }}
@delete_bp.route("/<int:item_id>", methods=["DELETE"])
def delete_item(item_id):
    item = db.session.get(Item, item_id)
    if not item: return jsonify({"error": "Non trouvé"}), 404
    db.session.delete(item); db.session.commit()
    return jsonify({"ok": True})
"""

TPL_USER_MODEL = """\
{{ cmt("user_model") }}
from app.database import db
from datetime import datetime

class User(db.Model):
    __tablename__ = "users"
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(150), unique=True, nullable=False)
    email = db.Column(db.String(255), unique=True, nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
"""

TPL_AUTH_SEC = """\
{{ cmt("auth_module") }}
import jwt, os
from datetime import datetime, timedelta
from passlib.context import CryptContext
from functools import wraps
from flask import request, jsonify

SECRET = os.getenv("SECRET_KEY", "secret")
pwd_ctx = CryptContext(schemes=["bcrypt"], deprecated="auto")

def hash_password(p): return pwd_ctx.hash(p)
def verify_password(p, h): return pwd_ctx.verify(p, h)

def create_token(user_id):
    return jwt.encode({"sub": user_id, "exp": datetime.utcnow() + timedelta(hours=1)},
                      SECRET, algorithm="HS256")

def login_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        token = request.headers.get("Authorization", "").replace("Bearer ", "")
        try:
            payload = jwt.decode(token, SECRET, algorithms=["HS256"])
            request.user_id = payload["sub"]
        except jwt.PyJWTError:
            return jsonify({"error": "Token invalide"}), 401
        return f(*args, **kwargs)
    return decorated
"""

TPL_AUTH = """\
{{ cmt("register_route") }}
{{ cmt("login_route") }}
from flask import Blueprint, request, jsonify
from app.database import db
from app.models.user import User
from app.auth.security import hash_password, verify_password, create_token, login_required

auth_bp = Blueprint("auth", __name__)

@auth_bp.route("/register", methods=["POST"])
def register():
    data = request.get_json()
    if User.query.filter_by(email=data["email"]).first():
        return jsonify({"error": "Email déjà utilisé"}), 400
    user = User(username=data["username"], email=data["email"],
                password_hash=hash_password(data["password"]))
    db.session.add(user); db.session.commit()
    return jsonify({"id": user.id, "username": user.username}), 201

@auth_bp.route("/login", methods=["POST"])
def login():
    data = request.get_json()
    user = User.query.filter_by(email=data["email"]).first()
    if not user or not verify_password(data["password"], user.password_hash):
        return jsonify({"error": "Identifiants invalides"}), 401
    return jsonify({"access_token": create_token(user.id)})

{{ cmt("protected_route") }}
@auth_bp.route("/me", methods=["GET"])
@login_required
def me():
    user = db.session.get(User, request.user_id)
    return jsonify({"id": user.id, "username": user.username, "email": user.email})
"""

TPL_TEST = """\
{{ cmt("test_module") }}
from app import create_app

def test_app():
    app = create_app()
    client = app.test_client()
    r = client.get("/items/")
    assert r.status_code == 200
"""

TPL_DOCKERFILE = """\
FROM python:3.11-slim
WORKDIR /app
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt
COPY . .
CMD ["python", "run.py"]
"""

TPL_COMPOSE = """\
{{ cmt("docker_compose") }}
version: "3.8"
services:
  api:
    build: .
    ports:
      - "{{ port }}:{{ port }}"
    env_file: .env
{% if database == "postgresql" %}
  db:
    image: postgres:15
    environment:
      POSTGRES_DB: {{ nom }}
      POSTGRES_USER: postgres
      POSTGRES_PASSWORD: postgres
    ports:
      - "5432:5432"
    volumes:
      - pgdata:/var/lib/postgresql/data

volumes:
  pgdata:
{% endif %}
"""
