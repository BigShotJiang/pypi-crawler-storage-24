"""Générateur Flask microservices."""
from __future__ import annotations
from gpi.generators.base import BaseGenerator


class FlaskMicroservices(BaseGenerator):
    def _specifiques(self) -> dict[str, str]:
        f: dict[str, str] = {"docker-compose.yml": TPL_COMPOSE}
        for svc in self.cfg.services:
            p = f"services/{svc}"
            f[f"{p}/run.py"] = TPL_RUN
            f[f"{p}/requirements.txt"] = TPL_REQ
            f[f"{p}/Dockerfile"] = TPL_DOCKER
            f[f"{p}/app/__init__.py"] = TPL_APP
            f[f"{p}/app/database.py"] = TPL_DB
            f[f"{p}/app/models.py"] = TPL_MODEL
            f[f"{p}/app/routes.py"] = TPL_ROUTES
        return f

    def _build_ctx(self) -> dict:
        ctx = super()._build_ctx()
        ports = {svc: self.cfg.port + i for i, svc in enumerate(self.cfg.services)}
        ctx["svc_ports"] = ports
        return ctx


TPL_COMPOSE = """\
{{ cmt("docker_compose") }}
version: "3.8"
services:
{% for svc in services %}
  {{ svc }}:
    build: ./services/{{ svc }}
    ports:
      - "{{ svc_ports[svc] }}:5000"
    env_file: .env
{% endfor %}
{% if database == "postgresql" %}
  db:
    image: postgres:15
    environment:
      POSTGRES_DB: {{ nom }}
      POSTGRES_USER: postgres
      POSTGRES_PASSWORD: postgres
    ports:
      - "5432:5432"
{% endif %}
"""

TPL_RUN = """\
{{ cmt("main_app") }}
from app import create_app
app = create_app()
if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
"""

TPL_REQ = """\
flask>=3.0.0
flask-sqlalchemy>=3.1.0
python-dotenv>=1.0.0
{% if database == "postgresql" %}psycopg2-binary>=2.9.0{% endif %}
"""

TPL_DOCKER = """\
FROM python:3.11-slim
WORKDIR /app
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt
COPY . .
CMD ["python", "run.py"]
"""

TPL_APP = """\
from flask import Flask
from app.database import db

def create_app():
    app = Flask(__name__)
    app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///service.db"
    db.init_app(app)
    from app.routes import bp
    app.register_blueprint(bp)
    with app.app_context():
        db.create_all()
    return app
"""

TPL_DB = """\
from flask_sqlalchemy import SQLAlchemy
db = SQLAlchemy()
"""

TPL_MODEL = """\
{{ cmt("item_model") }}
from app.database import db
from datetime import datetime

class Resource(db.Model):
    __tablename__ = "resources"
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(255), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    def to_dict(self):
        return {"id": self.id, "name": self.name, "created_at": str(self.created_at)}
"""

TPL_ROUTES = """\
from flask import Blueprint, request, jsonify
from app.database import db
from app.models import Resource

bp = Blueprint("main", __name__)

@bp.route("/", methods=["GET"])
def list_all():
    return jsonify([r.to_dict() for r in Resource.query.all()])

@bp.route("/", methods=["POST"])
def create():
    data = request.get_json()
    r = Resource(name=data["name"])
    db.session.add(r); db.session.commit()
    return jsonify(r.to_dict()), 201
"""
