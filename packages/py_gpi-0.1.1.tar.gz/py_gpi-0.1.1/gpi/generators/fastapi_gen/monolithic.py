"""Générateur FastAPI monolithique."""
from __future__ import annotations
from gpi.generators.base import BaseGenerator

class FastAPIMonolithique(BaseGenerator):
    def _specifiques(self) -> dict[str, str]:
        f = {"requirements.txt": TPL_REQ, "main.py": TPL_MAIN, "database.py": TPL_DB}
        if self.ctx["split_routes"]:
            f["routers/items/__init__.py"] = ""
            f["routers/items/create.py"] = TPL_ROUTE_CREATE
            f["routers/items/read.py"] = TPL_ROUTE_READ
            f["routers/items/update.py"] = TPL_ROUTE_UPDATE
            f["routers/items/delete.py"] = TPL_ROUTE_DELETE
        else:
            f["routers/__init__.py"] = ""
            f["routers/items.py"] = TPL_ROUTES
        f["models/__init__.py"] = ""
        f["models/item.py"] = TPL_MODEL
        f["schemas/__init__.py"] = ""
        f["schemas/item.py"] = TPL_SCHEMA
        return f

    def _auth(self) -> dict[str, str]:
        return {
            "auth/__init__.py": "",
            "auth/security.py": TPL_AUTH_SEC,
            "auth/routes.py": TPL_AUTH_ROUTES,
            "models/user.py": TPL_USER_MODEL,
            "schemas/user.py": TPL_USER_SCHEMA,
        }

    def _tests(self) -> dict[str, str]:
        return {
            "tests/__init__.py": "",
            "tests/test_items.py": TPL_TEST,
        }

    def _docker(self) -> dict[str, str]:
        f = {"Dockerfile": TPL_DOCKERFILE, "docker-compose.yml": TPL_COMPOSE}
        return f

# ── Templates ──

TPL_REQ = """\
{{ cmt("requirements") }}
fastapi>=0.100.0
uvicorn[standard]>=0.23.0
sqlalchemy>=2.0.0
python-dotenv>=1.0.0
{% if has_jwt %}python-jose[cryptography]>=3.3.0
passlib[bcrypt]>=1.7.4
{% endif %}{% if database == "postgresql" %}psycopg2-binary>=2.9.0
{% endif %}{% if database == "mysql" %}pymysql>=1.1.0
{% endif %}{% if has_redis %}redis>=5.0.0
{% endif %}{% if has_tests %}pytest>=7.0.0
httpx>=0.24.0
{% endif %}"""

TPL_MAIN = """\
{{ cmt("main_app") }}
from fastapi import FastAPI
from database import engine, Base
{% if split_routes %}from routers.items.create import router as create_router
from routers.items.read import router as read_router
from routers.items.update import router as update_router
from routers.items.delete import router as delete_router
{% else %}from routers.items import router as items_router
{% endif %}{% if has_auth %}from auth.routes import router as auth_router
{% endif %}
import models.item
{% if has_auth %}import models.user{% endif %}

app = FastAPI(title="{{ nom }}", description="{{ description }}")

{{ cmt("create_tables") }}
@app.on_event("startup")
def startup():
    Base.metadata.create_all(bind=engine)

{% if split_routes %}app.include_router(create_router, prefix="/items", tags=["items"])
app.include_router(read_router, prefix="/items", tags=["items"])
app.include_router(update_router, prefix="/items", tags=["items"])
app.include_router(delete_router, prefix="/items", tags=["items"])
{% else %}app.include_router(items_router, prefix="/items", tags=["items"])
{% endif %}{% if has_auth %}app.include_router(auth_router, prefix="/auth", tags=["auth"])
{% endif %}

@app.get("/")
def root():
    return {"message": "Bienvenue sur {{ nom }} !"}
"""

TPL_DB = """\
{{ cmt("db_config") }}
import os
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, DeclarativeBase
from dotenv import load_dotenv

load_dotenv()

DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///./{{ nom }}.db")
{% if database == "sqlite" %}
engine = create_engine(DATABASE_URL, connect_args={"check_same_thread": False})
{% else %}
engine = create_engine(DATABASE_URL)
{% endif %}
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

class Base(DeclarativeBase):
    pass

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
"""

TPL_MODEL = """\
{{ cmt("item_model") }}
from sqlalchemy import Column, Integer, String, DateTime, func
from database import Base

class Item(Base):
    __tablename__ = "items"
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(255), nullable=False)
    description = Column(String(500), default="")
    created_at = Column(DateTime, server_default=func.now())
"""

TPL_SCHEMA = """\
{{ cmt("schemas") }}
from pydantic import BaseModel
from datetime import datetime

class ItemCreate(BaseModel):
    name: str
    description: str = ""

class ItemUpdate(BaseModel):
    name: str | None = None
    description: str | None = None

class ItemResponse(BaseModel):
    id: int
    name: str
    description: str
    created_at: datetime
    model_config = {"from_attributes": True}
"""

TPL_ROUTES = """\
{{ cmt("crud_create") }}
{{ cmt("crud_read") }}
{{ cmt("crud_update") }}
{{ cmt("crud_delete") }}
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from database import get_db
from models.item import Item
from schemas.item import ItemCreate, ItemUpdate, ItemResponse

router = APIRouter()

@router.post("/", response_model=ItemResponse)
def create_item(data: ItemCreate, db: Session = Depends(get_db)):
    item = Item(**data.model_dump())
    db.add(item); db.commit(); db.refresh(item)
    return item

@router.get("/", response_model=list[ItemResponse])
def read_items(skip: int = 0, limit: int = 100, db: Session = Depends(get_db)):
    return db.query(Item).offset(skip).limit(limit).all()

@router.get("/{item_id}", response_model=ItemResponse)
def read_item(item_id: int, db: Session = Depends(get_db)):
    item = db.query(Item).get(item_id)
    if not item:
        raise HTTPException(404, "Item non trouvé")
    return item

@router.put("/{item_id}", response_model=ItemResponse)
def update_item(item_id: int, data: ItemUpdate, db: Session = Depends(get_db)):
    item = db.query(Item).get(item_id)
    if not item:
        raise HTTPException(404, "Item non trouvé")
    for k, v in data.model_dump(exclude_unset=True).items():
        setattr(item, k, v)
    db.commit(); db.refresh(item)
    return item

@router.delete("/{item_id}")
def delete_item(item_id: int, db: Session = Depends(get_db)):
    item = db.query(Item).get(item_id)
    if not item:
        raise HTTPException(404, "Item non trouvé")
    db.delete(item); db.commit()
    return {"ok": True}
"""

# Routes séparées (split)
_ROUTE_BASE = """\
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from database import get_db
from models.item import Item
from schemas.item import ItemCreate, ItemUpdate, ItemResponse

router = APIRouter()
"""

TPL_ROUTE_CREATE = _ROUTE_BASE + """
{{ cmt("crud_create") }}
@router.post("/", response_model=ItemResponse)
def create_item(data: ItemCreate, db: Session = Depends(get_db)):
    item = Item(**data.model_dump())
    db.add(item); db.commit(); db.refresh(item)
    return item
"""

TPL_ROUTE_READ = _ROUTE_BASE + """
{{ cmt("crud_read") }}
@router.get("/", response_model=list[ItemResponse])
def read_items(skip: int = 0, limit: int = 100, db: Session = Depends(get_db)):
    return db.query(Item).offset(skip).limit(limit).all()

@router.get("/{item_id}", response_model=ItemResponse)
def read_item(item_id: int, db: Session = Depends(get_db)):
    item = db.query(Item).get(item_id)
    if not item:
        raise HTTPException(404, "Item non trouvé")
    return item
"""

TPL_ROUTE_UPDATE = _ROUTE_BASE + """
{{ cmt("crud_update") }}
@router.put("/{item_id}", response_model=ItemResponse)
def update_item(item_id: int, data: ItemUpdate, db: Session = Depends(get_db)):
    item = db.query(Item).get(item_id)
    if not item:
        raise HTTPException(404, "Item non trouvé")
    for k, v in data.model_dump(exclude_unset=True).items():
        setattr(item, k, v)
    db.commit(); db.refresh(item)
    return item
"""

TPL_ROUTE_DELETE = _ROUTE_BASE + """
{{ cmt("crud_delete") }}
@router.delete("/{item_id}")
def delete_item(item_id: int, db: Session = Depends(get_db)):
    item = db.query(Item).get(item_id)
    if not item:
        raise HTTPException(404, "Item non trouvé")
    db.delete(item); db.commit()
    return {"ok": True}
"""

# Auth
TPL_USER_MODEL = """\
{{ cmt("user_model") }}
from sqlalchemy import Column, Integer, String, DateTime, func
from database import Base

class User(Base):
    __tablename__ = "users"
    id = Column(Integer, primary_key=True, index=True)
    username = Column(String(150), unique=True, nullable=False)
    email = Column(String(255), unique=True, nullable=False)
    hashed_password = Column(String(255), nullable=False)
    created_at = Column(DateTime, server_default=func.now())
"""

TPL_USER_SCHEMA = """\
from pydantic import BaseModel

class UserCreate(BaseModel):
    username: str
    email: str
    password: str

class UserResponse(BaseModel):
    id: int
    username: str
    email: str
    model_config = {"from_attributes": True}

class Token(BaseModel):
    access_token: str
    token_type: str = "bearer"
"""

TPL_AUTH_SEC = """\
{{ cmt("auth_module") }}
import os
from datetime import datetime, timedelta
from jose import jwt, JWTError
from passlib.context import CryptContext
from fastapi import Depends, HTTPException
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from dotenv import load_dotenv

load_dotenv()
SECRET = os.getenv("SECRET_KEY", "secret")
ALGO = "HS256"
EXPIRE_MIN = 60

pwd_ctx = CryptContext(schemes=["bcrypt"], deprecated="auto")
security = HTTPBearer()

{{ cmt("hash_password") }}
def hash_password(p: str) -> str:
    return pwd_ctx.hash(p)

def verify_password(plain: str, hashed: str) -> bool:
    return pwd_ctx.verify(plain, hashed)

{{ cmt("create_token") }}
def create_token(data: dict) -> str:
    to_encode = data.copy()
    to_encode["exp"] = datetime.utcnow() + timedelta(minutes=EXPIRE_MIN)
    return jwt.encode(to_encode, SECRET, algorithm=ALGO)

{{ cmt("verify_token") }}
def get_current_user(creds: HTTPAuthorizationCredentials = Depends(security)):
    try:
        payload = jwt.decode(creds.credentials, SECRET, algorithms=[ALGO])
        user_id = payload.get("sub")
        if user_id is None:
            raise HTTPException(401, "Token invalide")
        return int(user_id)
    except JWTError:
        raise HTTPException(401, "Token invalide")
"""

TPL_AUTH_ROUTES = """\
{{ cmt("register_route") }}
{{ cmt("login_route") }}
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from database import get_db
from models.user import User
from schemas.user import UserCreate, UserResponse, Token
from auth.security import hash_password, verify_password, create_token, get_current_user

router = APIRouter()

@router.post("/register", response_model=UserResponse)
def register(data: UserCreate, db: Session = Depends(get_db)):
    if db.query(User).filter(User.email == data.email).first():
        raise HTTPException(400, "Email déjà utilisé")
    user = User(username=data.username, email=data.email,
                hashed_password=hash_password(data.password))
    db.add(user); db.commit(); db.refresh(user)
    return user

@router.post("/login", response_model=Token)
def login(data: UserCreate, db: Session = Depends(get_db)):
    user = db.query(User).filter(User.email == data.email).first()
    if not user or not verify_password(data.password, user.hashed_password):
        raise HTTPException(401, "Identifiants invalides")
    return Token(access_token=create_token({"sub": str(user.id)}))

{{ cmt("protected_route") }}
@router.get("/me")
def me(user_id: int = Depends(get_current_user), db: Session = Depends(get_db)):
    user = db.query(User).get(user_id)
    if not user:
        raise HTTPException(404, "Utilisateur non trouvé")
    return {"id": user.id, "username": user.username, "email": user.email}
"""

# Tests
TPL_TEST = """\
{{ cmt("test_module") }}
from fastapi.testclient import TestClient
from main import app

client = TestClient(app)

def test_root():
    r = client.get("/")
    assert r.status_code == 200

def test_create_item():
    r = client.post("/items/", json={"name": "Test", "description": "Desc"})
    assert r.status_code == 200
    assert r.json()["name"] == "Test"

def test_read_items():
    r = client.get("/items/")
    assert r.status_code == 200
    assert isinstance(r.json(), list)
"""

# Docker
TPL_DOCKERFILE = """\
{{ cmt("dockerfile") }}
FROM python:3.11-slim
WORKDIR /app
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt
COPY . .
CMD ["uvicorn", "main:app", "--host", "0.0.0.0", "--port", "{{ port }}"]
"""

TPL_COMPOSE = """\
{{ cmt("docker_compose") }}
version: "3.8"
services:
  api:
    build: .
    ports:
      - "{{ port }}:{{ port }}"
    env_file: .env
    depends_on:
{% if database == "postgresql" %}      - db
{% endif %}{% if has_redis %}      - redis
{% endif %}
{% if database == "postgresql" %}
  db:
    image: postgres:15
    environment:
      POSTGRES_DB: {{ nom }}
      POSTGRES_USER: postgres
      POSTGRES_PASSWORD: postgres
    ports:
      - "5432:5432"
    volumes:
      - pgdata:/var/lib/postgresql/data
{% endif %}
{% if has_redis %}
  redis:
    image: redis:7-alpine
    ports:
      - "6379:6379"
{% endif %}
{% if has_monitoring %}
  prometheus:
    image: prom/prometheus
    ports:
      - "9090:9090"

  grafana:
    image: grafana/grafana
    ports:
      - "3000:3000"
{% endif %}
{% if database == "postgresql" %}
volumes:
  pgdata:
{% endif %}
"""
