"""Générateur FastAPI microservices."""
from __future__ import annotations
from gpi.generators.base import BaseGenerator


class FastAPIMicroservices(BaseGenerator):
    def _specifiques(self) -> dict[str, str]:
        f: dict[str, str] = {"docker-compose.yml": TPL_COMPOSE_MICRO}
        for svc in self.cfg.services:
            prefix = f"services/{svc}"
            f[f"{prefix}/main.py"] = TPL_SVC_MAIN
            f[f"{prefix}/requirements.txt"] = TPL_SVC_REQ
            f[f"{prefix}/Dockerfile"] = TPL_SVC_DOCKER
            f[f"{prefix}/models.py"] = TPL_SVC_MODEL
            f[f"{prefix}/routes.py"] = TPL_SVC_ROUTES
            f[f"{prefix}/database.py"] = TPL_SVC_DB
        return f

    def _build_ctx(self) -> dict:
        ctx = super()._build_ctx()
        # Ajouter port par service
        ports = {}
        for i, svc in enumerate(self.cfg.services):
            ports[svc] = self.cfg.port + i
        ctx["svc_ports"] = ports
        return ctx


TPL_COMPOSE_MICRO = """\
{{ cmt("docker_compose") }}
version: "3.8"
services:
{% for svc in services %}
  {{ svc }}:
    build: ./services/{{ svc }}
    ports:
      - "{{ svc_ports[svc] }}:8000"
    env_file: .env
    environment:
      SERVICE_NAME: {{ svc }}
{% endfor %}
{% if database == "postgresql" %}
  db:
    image: postgres:15
    environment:
      POSTGRES_DB: {{ nom }}
      POSTGRES_USER: postgres
      POSTGRES_PASSWORD: postgres
    ports:
      - "5432:5432"
    volumes:
      - pgdata:/var/lib/postgresql/data
{% endif %}
{% if has_redis %}
  redis:
    image: redis:7-alpine
    ports:
      - "6379:6379"
{% endif %}

{% if database == "postgresql" %}
volumes:
  pgdata:
{% endif %}
"""

TPL_SVC_MAIN = """\
{{ cmt("main_app") }}
from fastapi import FastAPI
from routes import router
from database import engine, Base

app = FastAPI(title="{{ nom }}")

@app.on_event("startup")
def startup():
    Base.metadata.create_all(bind=engine)

app.include_router(router)

@app.get("/health")
def health():
    return {"status": "ok"}
"""

TPL_SVC_REQ = """\
fastapi>=0.100.0
uvicorn[standard]>=0.23.0
sqlalchemy>=2.0.0
python-dotenv>=1.0.0
{% if database == "postgresql" %}psycopg2-binary>=2.9.0{% endif %}
"""

TPL_SVC_DOCKER = """\
FROM python:3.11-slim
WORKDIR /app
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt
COPY . .
CMD ["uvicorn", "main:app", "--host", "0.0.0.0", "--port", "8000"]
"""

TPL_SVC_MODEL = """\
{{ cmt("item_model") }}
from sqlalchemy import Column, Integer, String, DateTime, func
from database import Base

class Resource(Base):
    __tablename__ = "resources"
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(255), nullable=False)
    created_at = Column(DateTime, server_default=func.now())
"""

TPL_SVC_ROUTES = """\
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from database import get_db
from models import Resource

router = APIRouter()

@router.get("/")
def list_all(db: Session = Depends(get_db)):
    return db.query(Resource).all()

@router.post("/")
def create(name: str, db: Session = Depends(get_db)):
    r = Resource(name=name)
    db.add(r); db.commit(); db.refresh(r)
    return r
"""

TPL_SVC_DB = """\
{{ cmt("db_config") }}
import os
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, DeclarativeBase
from dotenv import load_dotenv

load_dotenv()
DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///./service.db")

engine = create_engine(DATABASE_URL)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

class Base(DeclarativeBase):
    pass

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
"""
