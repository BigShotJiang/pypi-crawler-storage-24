"""Factory pour sélectionner le bon générateur."""
from __future__ import annotations
from gpi.core.config import ProjectConfig
from gpi.generators.base import BaseGenerator


def get_generator(config: ProjectConfig) -> BaseGenerator:
    """Retourne le générateur approprié selon framework + architecture."""
    key = (config.framework, config.architecture)

    if key == ("fastapi", "monolithique"):
        from gpi.generators.fastapi_gen.monolithic import FastAPIMonolithique
        return FastAPIMonolithique(config)
    elif key == ("fastapi", "microservices"):
        from gpi.generators.fastapi_gen.microservices import FastAPIMicroservices
        return FastAPIMicroservices(config)
    elif key == ("flask", "monolithique"):
        from gpi.generators.flask_gen.monolithic import FlaskMonolithique
        return FlaskMonolithique(config)
    elif key == ("flask", "microservices"):
        from gpi.generators.flask_gen.microservices import FlaskMicroservices
        return FlaskMicroservices(config)
    elif key == ("django", "monolithique"):
        from gpi.generators.django_gen.monolithic import DjangoMonolithique
        return DjangoMonolithique(config)
    elif key == ("django", "microservices"):
        from gpi.generators.django_gen.microservices import DjangoMicroservices
        return DjangoMicroservices(config)
    else:
        raise ValueError(f"Combinaison non supportée : {key}")
