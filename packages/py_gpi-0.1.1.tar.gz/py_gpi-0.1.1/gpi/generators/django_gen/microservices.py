"""Générateur Django microservices."""
from __future__ import annotations
from gpi.generators.base import BaseGenerator


class DjangoMicroservices(BaseGenerator):
    def _specifiques(self) -> dict[str, str]:
        f: dict[str, str] = {"docker-compose.yml": TPL_COMPOSE}
        for svc in self.cfg.services:
            p = f"services/{svc}"
            n = svc
            f[f"{p}/manage.py"] = TPL_MANAGE
            f[f"{p}/requirements.txt"] = TPL_REQ
            f[f"{p}/Dockerfile"] = TPL_DOCKER
            f[f"{p}/{n}/__init__.py"] = ""
            f[f"{p}/{n}/settings.py"] = TPL_SETTINGS
            f[f"{p}/{n}/urls.py"] = TPL_URLS
            f[f"{p}/{n}/wsgi.py"] = TPL_WSGI
            f[f"{p}/api/__init__.py"] = ""
            f[f"{p}/api/models.py"] = TPL_MODEL
            f[f"{p}/api/views.py"] = TPL_VIEWS
            f[f"{p}/api/urls.py"] = TPL_API_URLS
            f[f"{p}/api/serializers.py"] = TPL_SERIAL
            f[f"{p}/api/apps.py"] = TPL_APPS
        return f

    def _build_ctx(self) -> dict:
        ctx = super()._build_ctx()
        ports = {svc: self.cfg.port + i for i, svc in enumerate(self.cfg.services)}
        ctx["svc_ports"] = ports
        return ctx


TPL_COMPOSE = """\
{{ cmt("docker_compose") }}
version: "3.8"
services:
{% for svc in services %}
  {{ svc }}:
    build: ./services/{{ svc }}
    ports:
      - "{{ svc_ports[svc] }}:8000"
    env_file: .env
{% endfor %}
{% if database == "postgresql" %}
  db:
    image: postgres:15
    environment:
      POSTGRES_DB: {{ nom }}
      POSTGRES_USER: postgres
      POSTGRES_PASSWORD: postgres
    ports:
      - "5432:5432"
{% endif %}
"""

TPL_MANAGE = """\
#!/usr/bin/env python
import os, sys
def main():
    os.environ.setdefault("DJANGO_SETTINGS_MODULE", "{{ nom }}.settings")
    from django.core.management import execute_from_command_line
    execute_from_command_line(sys.argv)
if __name__ == "__main__":
    main()
"""

TPL_REQ = """\
django>=5.0
djangorestframework>=3.14.0
python-dotenv>=1.0.0
{% if database == "postgresql" %}psycopg2-binary>=2.9.0{% endif %}
"""

TPL_DOCKER = """\
FROM python:3.11-slim
WORKDIR /app
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt
COPY . .
CMD ["python", "manage.py", "runserver", "0.0.0.0:8000"]
"""

TPL_SETTINGS = """\
import os
from pathlib import Path
from dotenv import load_dotenv

load_dotenv()
BASE_DIR = Path(__file__).resolve().parent.parent
SECRET_KEY = os.getenv("SECRET_KEY", "dev-secret")
DEBUG = True
ALLOWED_HOSTS = ["*"]

INSTALLED_APPS = [
    "django.contrib.admin", "django.contrib.auth",
    "django.contrib.contenttypes", "django.contrib.sessions",
    "django.contrib.messages", "django.contrib.staticfiles",
    "rest_framework", "api",
]

MIDDLEWARE = [
    "django.middleware.security.SecurityMiddleware",
    "django.contrib.sessions.middleware.SessionMiddleware",
    "django.middleware.common.CommonMiddleware",
    "django.middleware.csrf.CsrfViewMiddleware",
    "django.contrib.auth.middleware.AuthenticationMiddleware",
    "django.contrib.messages.middleware.MessageMiddleware",
]

ROOT_URLCONF = "{{ nom }}.urls"
DATABASES = {"default": {"ENGINE": "django.db.backends.sqlite3", "NAME": BASE_DIR / "db.sqlite3"}}
TEMPLATES = [{"BACKEND": "django.template.backends.django.DjangoTemplates", "DIRS": [], "APP_DIRS": True,
    "OPTIONS": {"context_processors": ["django.template.context_processors.debug", "django.template.context_processors.request",
        "django.contrib.auth.context_processors.auth", "django.contrib.messages.context_processors.messages"]}}]
STATIC_URL = "static/"
DEFAULT_AUTO_FIELD = "django.db.models.BigAutoField"
"""

TPL_URLS = """\
from django.contrib import admin
from django.urls import path, include
urlpatterns = [path("admin/", admin.site.urls), path("api/", include("api.urls"))]
"""

TPL_WSGI = """\
import os
from django.core.wsgi import get_wsgi_application
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "{{ nom }}.settings")
application = get_wsgi_application()
"""

TPL_MODEL = """\
{{ cmt("item_model") }}
from django.db import models

class Resource(models.Model):
    name = models.CharField(max_length=255)
    created_at = models.DateTimeField(auto_now_add=True)
    def __str__(self): return self.name
"""

TPL_SERIAL = """\
from rest_framework import serializers
from api.models import Resource

class ResourceSerializer(serializers.ModelSerializer):
    class Meta:
        model = Resource
        fields = "__all__"
"""

TPL_VIEWS = """\
from rest_framework import viewsets
from api.models import Resource
from api.serializers import ResourceSerializer

class ResourceViewSet(viewsets.ModelViewSet):
    queryset = Resource.objects.all()
    serializer_class = ResourceSerializer
"""

TPL_API_URLS = """\
from django.urls import path, include
from rest_framework.routers import DefaultRouter
from api.views import ResourceViewSet

router = DefaultRouter()
router.register("resources", ResourceViewSet)
urlpatterns = [path("", include(router.urls))]
"""

TPL_APPS = """\
from django.apps import AppConfig

class ApiConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "api"
"""
