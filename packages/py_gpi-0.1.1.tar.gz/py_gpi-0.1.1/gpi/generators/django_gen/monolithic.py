"""Générateur Django monolithique."""
from __future__ import annotations
from gpi.generators.base import BaseGenerator


class DjangoMonolithique(BaseGenerator):
    def _specifiques(self) -> dict[str, str]:
        n = self.cfg.nom
        return {
            "requirements.txt": TPL_REQ,
            "manage.py": TPL_MANAGE,
            f"{n}/__init__.py": "",
            f"{n}/settings.py": TPL_SETTINGS,
            f"{n}/urls.py": TPL_URLS,
            f"{n}/wsgi.py": TPL_WSGI,
            "core/__init__.py": "",
            "core/models.py": TPL_MODELS,
            "core/views.py": TPL_VIEWS,
            "core/urls.py": TPL_CORE_URLS,
            "core/serializers.py": TPL_SERIAL,
            "core/admin.py": TPL_ADMIN,
            "core/apps.py": TPL_APPS,
        }

    def _auth(self) -> dict[str, str]:
        return {
            "accounts/__init__.py": "",
            "accounts/models.py": TPL_USER_MODEL,
            "accounts/views.py": TPL_AUTH_VIEWS,
            "accounts/urls.py": TPL_AUTH_URLS,
            "accounts/serializers.py": TPL_AUTH_SERIAL,
            "accounts/apps.py": TPL_ACC_APPS,
        }

    def _tests(self) -> dict[str, str]:
        return {"core/tests.py": TPL_TEST}

    def _docker(self) -> dict[str, str]:
        return {"Dockerfile": TPL_DOCKER, "docker-compose.yml": TPL_COMPOSE}


TPL_REQ = """\
{{ cmt("requirements") }}
django>=5.0
djangorestframework>=3.14.0
python-dotenv>=1.0.0
{% if has_jwt %}djangorestframework-simplejwt>=5.3.0
{% endif %}{% if database == "postgresql" %}psycopg2-binary>=2.9.0
{% endif %}{% if has_tests %}pytest-django>=4.5.0
{% endif %}"""

TPL_MANAGE = """\
#!/usr/bin/env python
{{ cmt("main_app") }}
import os, sys

def main():
    os.environ.setdefault("DJANGO_SETTINGS_MODULE", "{{ nom }}.settings")
    from django.core.management import execute_from_command_line
    execute_from_command_line(sys.argv)

if __name__ == "__main__":
    main()
"""

TPL_SETTINGS = """\
{{ cmt("env_config") }}
import os
from pathlib import Path
from dotenv import load_dotenv

load_dotenv()
BASE_DIR = Path(__file__).resolve().parent.parent
SECRET_KEY = os.getenv("SECRET_KEY", "{{ secret_key }}")
DEBUG = os.getenv("DEBUG", "true").lower() == "true"
ALLOWED_HOSTS = ["*"]

INSTALLED_APPS = [
    "django.contrib.admin",
    "django.contrib.auth",
    "django.contrib.contenttypes",
    "django.contrib.sessions",
    "django.contrib.messages",
    "django.contrib.staticfiles",
    "rest_framework",
    "core",
{% if has_auth %}    "accounts",{% endif %}
]

MIDDLEWARE = [
    "django.middleware.security.SecurityMiddleware",
    "django.contrib.sessions.middleware.SessionMiddleware",
    "django.middleware.common.CommonMiddleware",
    "django.middleware.csrf.CsrfViewMiddleware",
    "django.contrib.auth.middleware.AuthenticationMiddleware",
    "django.contrib.messages.middleware.MessageMiddleware",
]

ROOT_URLCONF = "{{ nom }}.urls"
WSGI_APPLICATION = "{{ nom }}.wsgi.application"

{% if database == "sqlite" %}
DATABASES = {
    "default": {
        "ENGINE": "django.db.backends.sqlite3",
        "NAME": BASE_DIR / "db.sqlite3",
    }
}
{% elif database == "postgresql" %}
DATABASES = {
    "default": {
        "ENGINE": "django.db.backends.postgresql",
        "NAME": "{{ nom }}",
        "USER": os.getenv("DB_USER", "postgres"),
        "PASSWORD": os.getenv("DB_PASSWORD", "postgres"),
        "HOST": os.getenv("DB_HOST", "localhost"),
        "PORT": os.getenv("DB_PORT", "5432"),
    }
}
{% endif %}

TEMPLATES = [{
    "BACKEND": "django.template.backends.django.DjangoTemplates",
    "DIRS": [], "APP_DIRS": True,
    "OPTIONS": {"context_processors": [
        "django.template.context_processors.debug",
        "django.template.context_processors.request",
        "django.contrib.auth.context_processors.auth",
        "django.contrib.messages.context_processors.messages",
    ]},
}]

STATIC_URL = "static/"
DEFAULT_AUTO_FIELD = "django.db.models.BigAutoField"

REST_FRAMEWORK = {
{% if has_jwt %}    "DEFAULT_AUTHENTICATION_CLASSES": [
        "rest_framework_simplejwt.authentication.JWTAuthentication",
    ],{% endif %}
    "DEFAULT_PERMISSION_CLASSES": [
        "rest_framework.permissions.AllowAny",
    ],
}
"""

TPL_URLS = """\
from django.contrib import admin
from django.urls import path, include

urlpatterns = [
    path("admin/", admin.site.urls),
    path("api/", include("core.urls")),
{% if has_auth %}    path("auth/", include("accounts.urls")),{% endif %}
]
"""

TPL_WSGI = """\
import os
from django.core.wsgi import get_wsgi_application
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "{{ nom }}.settings")
application = get_wsgi_application()
"""

TPL_MODELS = """\
{{ cmt("item_model") }}
from django.db import models

class Item(models.Model):
    name = models.CharField(max_length=255)
    description = models.TextField(blank=True, default="")
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.name
"""

TPL_SERIAL = """\
{{ cmt("schemas") }}
from rest_framework import serializers
from core.models import Item

class ItemSerializer(serializers.ModelSerializer):
    class Meta:
        model = Item
        fields = "__all__"
"""

TPL_VIEWS = """\
{{ cmt("crud_create") }}
{{ cmt("crud_read") }}
{{ cmt("crud_update") }}
{{ cmt("crud_delete") }}
from rest_framework import viewsets
from core.models import Item
from core.serializers import ItemSerializer

class ItemViewSet(viewsets.ModelViewSet):
    queryset = Item.objects.all()
    serializer_class = ItemSerializer
"""

TPL_CORE_URLS = """\
from django.urls import path, include
from rest_framework.routers import DefaultRouter
from core.views import ItemViewSet

router = DefaultRouter()
router.register("items", ItemViewSet)

urlpatterns = [path("", include(router.urls))]
"""

TPL_ADMIN = """\
from django.contrib import admin
from core.models import Item

admin.site.register(Item)
"""

TPL_APPS = """\
from django.apps import AppConfig

class CoreConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "core"
"""

TPL_ACC_APPS = """\
from django.apps import AppConfig

class AccountsConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "accounts"
"""

TPL_USER_MODEL = """\
{{ cmt("user_model") }}
from django.contrib.auth.models import AbstractUser
from django.db import models

class CustomUser(AbstractUser):
    email = models.EmailField(unique=True)
    USERNAME_FIELD = "email"
    REQUIRED_FIELDS = ["username"]
"""

TPL_AUTH_SERIAL = """\
from rest_framework import serializers
from django.contrib.auth import get_user_model

User = get_user_model()

class RegisterSerializer(serializers.ModelSerializer):
    password = serializers.CharField(write_only=True)
    class Meta:
        model = User
        fields = ["id", "username", "email", "password"]
    def create(self, validated_data):
        return User.objects.create_user(**validated_data)

class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ["id", "username", "email"]
"""

TPL_AUTH_VIEWS = """\
{{ cmt("register_route") }}
{{ cmt("login_route") }}
from rest_framework import generics, permissions, status
from rest_framework.response import Response
from django.contrib.auth import get_user_model
from accounts.serializers import RegisterSerializer, UserSerializer

User = get_user_model()

class RegisterView(generics.CreateAPIView):
    queryset = User.objects.all()
    serializer_class = RegisterSerializer
    permission_classes = [permissions.AllowAny]

class MeView(generics.RetrieveAPIView):
    serializer_class = UserSerializer
    permission_classes = [permissions.IsAuthenticated]
    def get_object(self):
        return self.request.user
"""

TPL_AUTH_URLS = """\
from django.urls import path
from accounts.views import RegisterView, MeView
{% if has_jwt %}from rest_framework_simplejwt.views import TokenObtainPairView, TokenRefreshView{% endif %}

urlpatterns = [
    path("register/", RegisterView.as_view()),
{% if has_jwt %}    path("login/", TokenObtainPairView.as_view()),
    path("refresh/", TokenRefreshView.as_view()),{% endif %}
    path("me/", MeView.as_view()),
]
"""

TPL_TEST = """\
{{ cmt("test_module") }}
from django.test import TestCase
from core.models import Item

class ItemTest(TestCase):
    def test_create_item(self):
        item = Item.objects.create(name="Test", description="Desc")
        self.assertEqual(item.name, "Test")

    def test_list_items(self):
        Item.objects.create(name="A")
        self.assertEqual(Item.objects.count(), 1)
"""

TPL_DOCKER = """\
FROM python:3.11-slim
WORKDIR /app
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt
COPY . .
RUN python manage.py collectstatic --noinput 2>/dev/null || true
CMD ["python", "manage.py", "runserver", "0.0.0.0:{{ port }}"]
"""

TPL_COMPOSE = """\
{{ cmt("docker_compose") }}
version: "3.8"
services:
  api:
    build: .
    ports:
      - "{{ port }}:{{ port }}"
    env_file: .env
{% if database == "postgresql" %}
  db:
    image: postgres:15
    environment:
      POSTGRES_DB: {{ nom }}
      POSTGRES_USER: postgres
      POSTGRES_PASSWORD: postgres
    ports:
      - "5432:5432"
    volumes:
      - pgdata:/var/lib/postgresql/data

volumes:
  pgdata:
{% endif %}
"""
