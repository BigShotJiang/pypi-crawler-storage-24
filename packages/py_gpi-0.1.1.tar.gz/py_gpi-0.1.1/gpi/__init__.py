"""GPI – Générateur de Projet Intelligent."""
__version__ = "0.1.1"
