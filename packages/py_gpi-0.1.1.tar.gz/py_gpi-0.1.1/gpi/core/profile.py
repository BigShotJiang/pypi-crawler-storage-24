"""Gestion des questions interactives selon le niveau."""
from __future__ import annotations
from rich.console import Console
from rich.prompt import Prompt, Confirm
from gpi.core.config import ProjectConfig
from gpi.core.network import detecter_ips

console = Console()


def choix_numerique(prompt: str, options: list[str], descriptions: list[str] | None = None) -> str:
    """Demande un choix numérique avec validation."""
    if descriptions:
        for i, (opt, desc) in enumerate(zip(options, descriptions), 1):
            console.print(f"  [cyan]{i}[/]. {opt} – {desc}")
    else:
        for i, opt in enumerate(options, 1):
            console.print(f"  [cyan]{i}[/]. {opt}")

    while True:
        rep = Prompt.ask(f"{prompt} (1-{len(options)})", default="1")
        try:
            idx = int(rep) - 1
            if 0 <= idx < len(options):
                return options[idx]
        except ValueError:
            pass
        console.print("[red]Choix invalide, réessayez.[/]")


def collecter_config() -> ProjectConfig:
    """Pose les questions et retourne la configuration."""
    console.print("\n[bold cyan]🎓 GPI – Générateur de Projet Intelligent[/]")
    console.print("[dim]=" * 45 + "[/]\n")

    # Framework
    console.print("[bold]🔧 Quel framework souhaitez-vous utiliser ?[/]")
    framework = choix_numerique("Votre choix", 
        ["fastapi", "flask", "django"],
        ["Moderne, asynchrone, idéal pour API rapides",
         "Léger et flexible, parfait pour prototypes",
         "Tout-en-un, idéal pour applications complexes"])

    # Architecture
    console.print("\n[bold]🏗️  Quelle architecture ?[/]")
    architecture = choix_numerique("Votre choix",
        ["monolithique", "microservices"],
        ["Un seul projet, simple à démarrer",
         "Plusieurs services indépendants (avancé)"])

    # Niveau
    console.print("\n[bold]🎓 Quel est votre niveau ?[/]")
    niveau = choix_numerique("Votre choix",
        ["debutant", "intermediaire", "expert"],
        ["Projet simple et bien expliqué",
         "Plus d'options techniques",
         "Architecture production-ready"])

    # Si débutant + microservices → avertissement
    if niveau == "debutant" and architecture == "microservices":
        console.print("\n[yellow]⚠️  Les microservices sont complexes pour un débutant.[/]")
        if not Confirm.ask("Continuer quand même ?", default=False):
            architecture = "monolithique"
            console.print("[green]→ Architecture monolithique sélectionnée.[/]")

    # Nom et description
    console.print()
    nom = Prompt.ask("📁 Nom du projet", default="monapi")
    # Validation du nom
    import re
    while not re.match(r"^[a-zA-Z_][a-zA-Z0-9_]*$", nom):
        console.print("[red]Nom invalide (lettres, chiffres, _ uniquement, commencer par une lettre).[/]")
        nom = Prompt.ask("📁 Nom du projet", default="monapi")

    description = Prompt.ask("📝 Description (optionnelle)", default="")

    # Variables selon le niveau
    auth = "aucune"
    database = "sqlite"
    route_org = "single"
    langue = "fr"
    tests = False
    docker = False
    services: list[str] = []
    redis = False
    queue = "aucune"
    monitoring = False

    if niveau == "debutant":
        _questions_debutant(locals())
        # Auth
        if Confirm.ask("\n🔐 Ajouter l'authentification JWT ?", default=True):
            auth = "jwt"
        # DB fixée à SQLite
        console.print("\n[dim]🗄️  Base de données : SQLite (automatique)[/]")
        # Routes
        console.print("\n[bold]📂 Organisation des routes CRUD[/]")
        route_org = choix_numerique("Votre choix",
            ["single", "split"],
            ["Un fichier par ressource (ex: users.py)",
             "Quatre fichiers par ressource (create/read/update/delete)"])
        # Langue
        console.print("\n[bold]🌐 Langue des commentaires[/]")
        langue = choix_numerique("Votre choix", ["fr", "en"],
            ["Français", "Anglais"])

    elif niveau == "intermediaire":
        # DB
        console.print("\n[bold]🗄️  Base de données[/]")
        database = choix_numerique("Votre choix",
            ["sqlite", "postgresql"],
            ["SQLite (simple, sans installation)", "PostgreSQL (via Docker ou local)"])
        # Auth
        console.print("\n[bold]🔐 Authentification[/]")
        auth = choix_numerique("Votre choix",
            ["jwt", "sessions", "aucune"],
            ["JWT (tokens)", "Sessions (cookies)", "Aucune"])
        # Tests
        tests = Confirm.ask("\n🧪 Tests unitaires ?", default=True)
        # Docker
        if database == "postgresql":
            docker = Confirm.ask("\n🐳 Docker-compose pour la base de données ?", default=True)
        # Routes
        console.print("\n[bold]📂 Organisation des routes[/]")
        route_org = choix_numerique("Votre choix", ["single", "split"],
            ["Un fichier par ressource", "Quatre fichiers par ressource"])
        # Langue
        console.print("\n[bold]🌐 Langue des commentaires[/]")
        langue = choix_numerique("Votre choix", ["fr", "en", "bilingue"],
            ["Français", "Anglais", "Bilingue"])

    else:  # expert
        # Services si microservices
        if architecture == "microservices":
            srv_input = Prompt.ask(
                "\n🔧 Services souhaités (séparés par des virgules)",
                default="auth,users")
            services = [s.strip() for s in srv_input.split(",") if s.strip()]
        # DB
        console.print("\n[bold]🗄️  Base de données[/]")
        database = choix_numerique("Votre choix",
            ["postgresql", "mysql", "sqlite"],
            ["PostgreSQL (recommandé)", "MySQL", "SQLite"])
        # Cache
        redis = Confirm.ask("\n🧠 Cache Redis ?", default=True)
        # Queue
        console.print("\n[bold]📦 File d'attente[/]")
        queue = choix_numerique("Votre choix",
            ["celery", "rq", "aucune"],
            ["Celery (robuste)", "RQ (simple)", "Aucune"])
        # Auth
        console.print("\n[bold]🔐 Authentification[/]")
        auth_opts = ["jwt", "oauth2", "aucune"]
        auth_descs = ["JWT (tokens)", "OAuth2", "Aucune"]
        if framework == "django":
            auth_opts.insert(2, "django_builtin")
            auth_descs.insert(2, "Django built-in")
        auth = choix_numerique("Votre choix", auth_opts, auth_descs)
        # Docker
        docker = Confirm.ask("\n🐳 Stack Docker complète ?", default=True)
        # Monitoring
        if docker:
            monitoring = Confirm.ask("📊 Monitoring (Prometheus/Grafana) ?", default=False)
        # Tests
        tests = Confirm.ask("\n🧪 Tests (unitaires + intégration) ?", default=True)
        # Langue
        console.print("\n[bold]🌐 Langue des commentaires[/]")
        langue = choix_numerique("Votre choix", ["en", "fr", "bilingue"],
            ["Anglais", "Français", "Bilingue"])

    # Détection IP
    console.print("\n[dim]🌐 Détection de l'IP locale...[/]")
    ips = detecter_ips()
    local_ip = "localhost"
    if len(ips) == 1:
        local_ip = ips[0]
        console.print(f"[green]   IP détectée : {local_ip}[/]")
    elif len(ips) > 1:
        console.print("[yellow]   Plusieurs IPs détectées :[/]")
        local_ip = choix_numerique("Laquelle utiliser ?", ips)
    else:
        console.print("[yellow]   Impossible de détecter l'IP automatiquement.[/]")
        manual = Prompt.ask("   Saisir l'IP manuellement (ou Entrée pour ignorer)", default="")
        if manual:
            local_ip = manual

    return ProjectConfig(
        framework=framework, architecture=architecture, niveau=niveau,
        nom=nom, description=description, auth=auth, database=database,
        route_org=route_org, langue=langue, tests=tests, docker=docker,
        services=services, redis=redis, queue=queue, monitoring=monitoring,
        local_ip=local_ip,
    )


def _questions_debutant(ctx):
    """Placeholder pour regrouper les questions débutant."""
    pass
