"""Modèle de configuration du projet – Pydantic."""
from __future__ import annotations
from pydantic import BaseModel, field_validator
import re
import secrets

# Types autorisés
FRAMEWORKS = ("fastapi", "flask", "django")
ARCHITECTURES = ("monolithique", "microservices")
NIVEAUX = ("debutant", "intermediaire", "expert")
LANGUES = ("fr", "en", "bilingue")
AUTH_TYPES = ("jwt", "sessions", "oauth2", "django_builtin", "aucune")
DB_TYPES = ("sqlite", "postgresql", "mysql")
ROUTE_ORGS = ("single", "split")  # 1 fichier vs 4 fichiers
QUEUES = ("celery", "rq", "aucune")


class ProjectConfig(BaseModel):
    """Configuration complète du projet à générer."""
    # Choix principaux
    framework: str = "fastapi"
    architecture: str = "monolithique"
    niveau: str = "debutant"

    # Infos projet
    nom: str = "monapi"
    description: str = ""

    # Options
    auth: str = "aucune"
    database: str = "sqlite"
    route_org: str = "single"
    langue: str = "fr"

    # Options intermédiaire/expert
    tests: bool = False
    docker: bool = False

    # Options expert
    services: list[str] = []
    redis: bool = False
    queue: str = "aucune"
    monitoring: bool = False

    # Réseau
    local_ip: str = "localhost"
    port: int = 8000

    # Généré automatiquement
    secret_key: str = ""

    def model_post_init(self, __context) -> None:
        if not self.secret_key:
            self.secret_key = secrets.token_urlsafe(32)
        if self.architecture == "microservices" and not self.services:
            self.services = ["auth", "users"]

    @field_validator("nom")
    @classmethod
    def valider_nom(cls, v: str) -> str:
        if not re.match(r"^[a-zA-Z_][a-zA-Z0-9_]*$", v):
            raise ValueError(
                "Le nom doit commencer par une lettre et ne contenir que "
                "des lettres, chiffres et underscores."
            )
        return v.lower()
