"""Permet d'exécuter GPI avec : python -m gpi"""
from gpi.cli import app

if __name__ == "__main__":
    app()
