"""Tests unitaires – Modèle de configuration."""
import pytest
from pydantic import ValidationError
from gpi.core.config import ProjectConfig


class TestProjectConfig:
    """Tests de validation du modèle Pydantic."""

    def test_config_defaut(self):
        """La config par défaut doit être valide."""
        cfg = ProjectConfig()
        assert cfg.nom == "monapi"
        assert cfg.framework == "fastapi"
        assert cfg.architecture == "monolithique"
        assert cfg.niveau == "debutant"
        assert cfg.secret_key  # Généré automatiquement

    def test_nom_valide(self):
        """Noms de projet valides."""
        for nom in ["monapi", "my_app", "App2", "_private"]:
            cfg = ProjectConfig(nom=nom)
            assert cfg.nom == nom.lower()

    def test_nom_invalide(self):
        """Noms avec caractères interdits → erreur."""
        for nom in ["mon api", "123abc", "mon-app", "app@home", ""]:
            with pytest.raises(ValidationError):
                ProjectConfig(nom=nom)

    def test_secret_key_unique(self):
        """Chaque config génère un secret différent."""
        c1 = ProjectConfig()
        c2 = ProjectConfig()
        assert c1.secret_key != c2.secret_key

    def test_services_auto_microservices(self):
        """Si microservices sans services → auth + users par défaut."""
        cfg = ProjectConfig(architecture="microservices")
        assert cfg.services == ["auth", "users"]

    def test_services_conserves(self):
        """Les services fournis sont conservés."""
        cfg = ProjectConfig(architecture="microservices",
                            services=["api", "worker"])
        assert cfg.services == ["api", "worker"]

    def test_toutes_combinaisons_framework(self):
        """Tous les frameworks sont acceptés."""
        for fw in ["fastapi", "flask", "django"]:
            cfg = ProjectConfig(framework=fw)
            assert cfg.framework == fw

    def test_tous_niveaux(self):
        """Tous les niveaux sont acceptés."""
        for niv in ["debutant", "intermediaire", "expert"]:
            cfg = ProjectConfig(niveau=niv)
            assert cfg.niveau == niv

    def test_toutes_langues(self):
        """Toutes les langues sont acceptées."""
        for lang in ["fr", "en", "bilingue"]:
            cfg = ProjectConfig(langue=lang)
            assert cfg.langue == lang

    def test_port_defaut(self):
        """Le port par défaut est 8000."""
        assert ProjectConfig().port == 8000
