"""Tests fonctionnels – CLI."""
import pytest
from pathlib import Path
from typer.testing import CliRunner
from gpi.cli import app

runner = CliRunner()


class TestCLI:
    def test_version(self):
        """La commande version affiche le numéro."""
        result = runner.invoke(app, ["version"])
        assert result.exit_code == 0
        assert "0.1.0" in result.output

    def test_init_avec_config_yaml(self, tmp_cwd):
        """Génération via fichier YAML."""
        config = tmp_cwd / "projet.yaml"
        config.write_text(
            "framework: fastapi\nnom: clitest\nauth: aucune\n",
            encoding="utf-8"
        )
        result = runner.invoke(app, ["init", "-c", str(config)], input="y\n")
        assert (tmp_cwd / "clitest").exists() or result.exit_code == 0

    def test_init_config_introuvable(self, tmp_cwd):
        """Fichier config inexistant → erreur."""
        result = runner.invoke(app, ["init", "-c", "nexiste_pas.yaml"])
        assert result.exit_code != 0

    def test_help(self):
        """L'aide s'affiche correctement."""
        result = runner.invoke(app, ["--help"])
        assert result.exit_code == 0
        assert "GPI" in result.output or "gpi" in result.output
