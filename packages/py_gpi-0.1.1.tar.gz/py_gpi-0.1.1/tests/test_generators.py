"""Tests fonctionnels – Génération complète de projets."""
import pytest
from pathlib import Path
from gpi.core.config import ProjectConfig
from gpi.generators.factory import get_generator


class TestFastAPIMonolithique:
    """Génération FastAPI monolithique."""

    def test_structure_de_base(self, tmp_cwd, config_fastapi):
        gen = get_generator(config_fastapi)
        racine = gen.generer()
        assert racine.exists()
        # Fichiers obligatoires
        for f in ["main.py", "database.py", "requirements.txt",
                   ".env", ".gitignore", "README.md"]:
            assert (racine / f).exists(), f"Manque {f}"

    def test_routes_single(self, tmp_cwd):
        cfg = ProjectConfig(nom="api_single", route_org="single")
        gen = get_generator(cfg)
        gen.generer()
        assert (Path("api_single") / "routers" / "items.py").exists()

    def test_routes_split(self, tmp_cwd):
        cfg = ProjectConfig(nom="api_split", route_org="split")
        gen = get_generator(cfg)
        gen.generer()
        for f in ["create.py", "read.py", "update.py", "delete.py"]:
            assert (Path("api_split") / "routers" / "items" / f).exists(), f"Manque {f}"

    def test_auth_jwt(self, tmp_cwd):
        cfg = ProjectConfig(nom="api_auth", auth="jwt")
        gen = get_generator(cfg)
        gen.generer()
        r = Path("api_auth")
        assert (r / "auth" / "security.py").exists()
        assert (r / "auth" / "routes.py").exists()
        assert (r / "models" / "user.py").exists()
        # Vérifier les imports dans main.py
        main = (r / "main.py").read_text(encoding="utf-8")
        assert "auth" in main

    def test_sans_auth(self, tmp_cwd):
        cfg = ProjectConfig(nom="api_noauth", auth="aucune")
        gen = get_generator(cfg)
        gen.generer()
        assert not (Path("api_noauth") / "auth").exists()

    def test_tests_generes(self, tmp_cwd):
        cfg = ProjectConfig(nom="api_tests", tests=True)
        gen = get_generator(cfg)
        gen.generer()
        assert (Path("api_tests") / "tests" / "test_items.py").exists()

    def test_docker(self, tmp_cwd):
        cfg = ProjectConfig(nom="api_docker", docker=True)
        gen = get_generator(cfg)
        gen.generer()
        r = Path("api_docker")
        assert (r / "Dockerfile").exists()
        assert (r / "docker-compose.yml").exists()

    def test_commentaires_francais(self, tmp_cwd):
        cfg = ProjectConfig(nom="api_fr", langue="fr")
        gen = get_generator(cfg)
        gen.generer()
        main = (Path("api_fr") / "main.py").read_text(encoding="utf-8")
        assert "principal" in main.lower() or "application" in main.lower()

    def test_commentaires_anglais(self, tmp_cwd):
        cfg = ProjectConfig(nom="api_en", langue="en")
        gen = get_generator(cfg)
        gen.generer()
        main = (Path("api_en") / "main.py").read_text(encoding="utf-8")
        assert "Main" in main or "entry" in main.lower()

    def test_env_contient_secret(self, tmp_cwd):
        cfg = ProjectConfig(nom="api_env")
        gen = get_generator(cfg)
        gen.generer()
        env = (Path("api_env") / ".env").read_text(encoding="utf-8")
        assert "SECRET_KEY=" in env
        assert len(env.split("SECRET_KEY=")[1].split("\n")[0]) > 10

    def test_readme_contient_nom(self, tmp_cwd):
        cfg = ProjectConfig(nom="api_readme", description="Ma super API")
        gen = get_generator(cfg)
        gen.generer()
        readme = (Path("api_readme") / "README.md").read_text(encoding="utf-8")
        assert "api_readme" in readme
        assert "Ma super API" in readme

    def test_readme_ip_locale(self, tmp_cwd):
        cfg = ProjectConfig(nom="api_ip", local_ip="192.168.1.50")
        gen = get_generator(cfg)
        gen.generer()
        readme = (Path("api_ip") / "README.md").read_text(encoding="utf-8")
        assert "192.168.1.50" in readme


class TestFastAPIMicroservices:
    """Génération FastAPI microservices."""

    def test_structure_services(self, tmp_cwd, config_micro):
        gen = get_generator(config_micro)
        gen.generer()
        r = Path("testmicro")
        assert (r / "docker-compose.yml").exists()
        for svc in ["auth", "users", "products"]:
            svc_dir = r / "services" / svc
            assert svc_dir.exists(), f"Manque service {svc}"
            assert (svc_dir / "main.py").exists()
            assert (svc_dir / "Dockerfile").exists()
            assert (svc_dir / "requirements.txt").exists()

    def test_services_par_defaut(self, tmp_cwd):
        cfg = ProjectConfig(nom="micro_default", architecture="microservices")
        gen = get_generator(cfg)
        gen.generer()
        r = Path("micro_default")
        assert (r / "services" / "auth").exists()
        assert (r / "services" / "users").exists()


class TestFlaskMonolithique:
    """Génération Flask monolithique."""

    def test_structure(self, tmp_cwd, config_flask):
        gen = get_generator(config_flask)
        gen.generer()
        r = Path("testflask")
        for f in ["run.py", "requirements.txt", ".env", "README.md"]:
            assert (r / f).exists(), f"Manque {f}"
        assert (r / "app" / "__init__.py").exists()
        assert (r / "app" / "database.py").exists()
        assert (r / "app" / "models" / "item.py").exists()

    def test_auth_flask(self, tmp_cwd):
        cfg = ProjectConfig(framework="flask", nom="flask_auth", auth="jwt")
        gen = get_generator(cfg)
        gen.generer()
        r = Path("flask_auth")
        assert (r / "app" / "auth" / "routes.py").exists()
        assert (r / "app" / "auth" / "security.py").exists()

    def test_tests_flask(self, tmp_cwd):
        cfg = ProjectConfig(framework="flask", nom="flask_tests", tests=True)
        gen = get_generator(cfg)
        gen.generer()
        assert (Path("flask_tests") / "tests" / "test_app.py").exists()


class TestFlaskMicroservices:
    def test_structure(self, tmp_cwd):
        cfg = ProjectConfig(framework="flask", architecture="microservices",
                            nom="flask_micro", services=["api", "worker"])
        gen = get_generator(cfg)
        gen.generer()
        r = Path("flask_micro")
        assert (r / "docker-compose.yml").exists()
        for svc in ["api", "worker"]:
            assert (r / "services" / svc / "run.py").exists()


class TestDjangoMonolithique:
    """Génération Django monolithique."""

    def test_structure(self, tmp_cwd, config_django):
        gen = get_generator(config_django)
        gen.generer()
        r = Path("testdjango")
        assert (r / "manage.py").exists()
        assert (r / "testdjango" / "settings.py").exists()
        assert (r / "testdjango" / "urls.py").exists()
        assert (r / "core" / "models.py").exists()
        assert (r / "core" / "views.py").exists()

    def test_auth_django(self, tmp_cwd):
        cfg = ProjectConfig(framework="django", nom="dj_auth", auth="jwt")
        gen = get_generator(cfg)
        gen.generer()
        r = Path("dj_auth")
        assert (r / "accounts" / "views.py").exists()
        assert (r / "accounts" / "urls.py").exists()

    def test_docker_django(self, tmp_cwd, config_django):
        gen = get_generator(config_django)
        gen.generer()
        r = Path("testdjango")
        assert (r / "Dockerfile").exists()
        compose = (r / "docker-compose.yml").read_text(encoding="utf-8")
        assert "postgres" in compose.lower()


class TestDjangoMicroservices:
    def test_structure(self, tmp_cwd):
        cfg = ProjectConfig(framework="django", architecture="microservices",
                            nom="dj_micro", services=["auth", "catalog"])
        gen = get_generator(cfg)
        gen.generer()
        r = Path("dj_micro")
        assert (r / "docker-compose.yml").exists()
        for svc in ["auth", "catalog"]:
            assert (r / "services" / svc / "manage.py").exists()


class TestFactory:
    """Tests de la factory de générateurs."""

    @pytest.mark.parametrize("fw,arch", [
        ("fastapi", "monolithique"), ("fastapi", "microservices"),
        ("flask", "monolithique"), ("flask", "microservices"),
        ("django", "monolithique"), ("django", "microservices"),
    ])
    def test_toutes_combinaisons(self, tmp_cwd, fw, arch):
        """Chaque combinaison framework/architecture génère sans erreur."""
        cfg = ProjectConfig(framework=fw, architecture=arch,
                            nom=f"test_{fw}_{arch[:4]}")
        gen = get_generator(cfg)
        racine = gen.generer()
        assert racine.exists()
        assert (racine / ".env").exists()
        assert (racine / "README.md").exists()
