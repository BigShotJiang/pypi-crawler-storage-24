# GPI – Générateur de Projet Intelligent

[![PyPI version](https://img.shields.io/pypi/v/py-gpi?color=dc2626&label=PyPI)](https://pypi.org/project/py-gpi/)
[![Python](https://img.shields.io/pypi/pyversions/py-gpi?color=fbbf24)](https://pypi.org/project/py-gpi/)
[![License: MIT](https://img.shields.io/badge/License-MIT-green.svg)](https://opensource.org/licenses/MIT)

**Générez un projet backend complet et professionnel en 30 secondes.**

GPI est un outil en ligne de commande qui génère des projets backend Python prêts à l'emploi. Choisissez votre framework (FastAPI, Flask ou Django), votre architecture (monolithique ou microservices) et votre niveau d'expertise — GPI s'occupe du reste : structure de fichiers, base de données, authentification, Docker, tests et documentation.

<p align="center">
  <img src="https://img.shields.io/badge/FastAPI-009688?style=for-the-badge&logo=fastapi&logoColor=white" alt="FastAPI"/>
  <img src="https://img.shields.io/badge/Flask-000000?style=for-the-badge&logo=flask&logoColor=white" alt="Flask"/>
  <img src="https://img.shields.io/badge/Django-092E20?style=for-the-badge&logo=django&logoColor=white" alt="Django"/>
</p>

---

## Installation

```bash
pip install py_gpi
```

> **Note :** Le package s'appelle `py_gpi` sur PyPI. La commande CLI est `gpi`.

Vérifiez l'installation :

```bash
gpi version
# GPI v0.1.1
```

**Si `gpi` n'est pas trouvé**, utilisez l'alternative :

```bash
python -m gpi init
```

Cela signifie que le dossier `Scripts` de Python n'est pas dans votre PATH. Consultez la section [Résolution de problèmes](#résolution-de-problèmes) pour corriger cela.

---

## Utilisation rapide

### Mode interactif (recommandé)

```bash
gpi init
```

GPI vous guide pas à pas avec des questions simples :

```
GPI – Générateur de Projet Intelligent
=============================================

Quel framework souhaitez-vous utiliser ?
  1. fastapi – Moderne, asynchrone, idéal pour API rapides
  2. flask – Léger et flexible, parfait pour prototypes
  3. django – Tout-en-un, idéal pour applications complexes
  Votre choix (1-3) : 1

Quelle architecture ?
  1. monolithique – Un seul projet, simple à démarrer
  2. microservices – Plusieurs services indépendants (avancé)
  Votre choix (1-2) : 1

Quel est votre niveau ?
  1. debutant – Projet simple et bien expliqué
  2. intermediaire – Plus d'options techniques
  3. expert – Architecture production-ready
  Votre choix (1-3) : 2

Nom du projet : monapi
Description : Mon API REST
Ajouter l'authentification JWT ? : oui
Base de données : postgresql
Tests : oui

⏳ Génération en cours...
✅ Projet généré avec succès dans "monapi"
```

### Mode fichier de configuration

Pour automatiser ou reproduire une configuration, créez un fichier YAML :

```yaml
# monprojet.yaml
framework: fastapi
architecture: monolithique
niveau: intermediaire
nom: monapi
description: "Mon API REST"
auth: jwt
database: postgresql
tests: true
docker: true
langue: fr
```

Puis lancez :

```bash
gpi init --config monprojet.yaml
```

---

## Ce que GPI génère

### Architecture monolithique

En mode monolithique, **tout le code est regroupé dans un seul projet**. Modèles, routes, schémas, authentification et configuration cohabitent dans le même répertoire. C'est l'approche idéale pour les prototypes, l'apprentissage et les projets de taille moyenne.

**Exemple FastAPI :**

```
monapi/
├── main.py              ← Point d'entrée de l'application
├── database.py          ← Connexion et session SQLAlchemy
├── models/
│   ├── item.py          ← Modèle SQLAlchemy (table items)
│   └── user.py          ← Modèle utilisateur (si auth activée)
├── schemas/
│   ├── item.py          ← Schémas Pydantic (validation)
│   └── user.py          ← Schémas auth (si auth activée)
├── routers/
│   └── items.py         ← Routes CRUD (GET, POST, PUT, DELETE)
├── auth/                ← (si authentification activée)
│   ├── security.py      ← Hachage bcrypt + JWT
│   └── routes.py        ← Inscription, connexion, profil
├── tests/               ← (si tests activés)
│   └── test_items.py    ← Tests automatiques pytest
├── .env                 ← Variables d'environnement (SECRET_KEY, DB...)
├── .env.example         ← Modèle pour les collaborateurs
├── .gitignore
├── requirements.txt
└── README.md            ← Documentation avec instructions de lancement
```

**Exemple Flask :** structure `app/` avec Blueprints (`app/models/`, `app/routes/`).

**Exemple Django :** projet Django classique avec app `core/` et Django REST Framework.

### Architecture microservices

En mode microservices, **chaque service est une API indépendante** avec son propre code source, sa base de données, son Dockerfile et ses dépendances. Les services sont orchestrés par un `docker-compose.yml` à la racine. Cette architecture est conçue pour la scalabilité et le déploiement indépendant.

```
monprojet/
├── docker-compose.yml   ← Orchestre tous les services
├── .env                 ← Variables partagées
├── README.md
└── services/
    ├── auth/            ← Service d'authentification (API indépendante)
    │   ├── main.py      ← Point d'entrée FastAPI/Flask/Django
    │   ├── models.py    ← Modèles de données
    │   ├── routes.py    ← Endpoints API
    │   ├── database.py  ← Connexion DB propre au service
    │   ├── Dockerfile   ← Image Docker du service
    │   └── requirements.txt
    ├── users/           ← Service utilisateurs (même structure)
    │   └── ...
    └── products/        ← Service produits (même structure)
        └── ...
```

> **Chaque service** fonctionne de manière autonome. Vous pouvez les développer, tester et déployer indépendamment. `docker-compose up` lance l'ensemble.

---

## Lancer le projet généré

### FastAPI

```bash
cd monapi
pip install -r requirements.txt
uvicorn main:app --reload --host 0.0.0.0 --port 8000
```

Documentation Swagger interactive : [http://localhost:8000/docs](http://localhost:8000/docs)

### Flask

```bash
cd monapi
pip install -r requirements.txt
python run.py
```

### Django

```bash
cd monapi
pip install -r requirements.txt
python manage.py migrate
python manage.py runserver 0.0.0.0:8000
```

Admin panel : [http://localhost:8000/admin](http://localhost:8000/admin)

### Microservices (Docker)

```bash
cd monprojet
docker-compose up --build
```

---

## Les 3 niveaux

| | Débutant | Intermédiaire | Expert |
|---|---|---|---|
| **Base de données** | SQLite | SQLite / PostgreSQL | PostgreSQL / MySQL |
| **Auth** | JWT (oui/non) | JWT / Sessions | JWT / OAuth2 / Built-in |
| **Docker** | — | DB seulement | Stack complète |
| **Tests** | — | pytest | pytest + intégration |
| **Redis** | — | — | Cache + sessions |
| **File d'attente** | — | — | Celery / RQ |
| **Monitoring** | — | — | Prometheus + Grafana |
| **Microservices** | Déconseillé | Possible | Recommandé + Gateway |

---

## Test sur mobile

GPI détecte automatiquement l'adresse IP de votre ordinateur sur le réseau local. Après la génération, le README du projet contient :

```
## Tester sur mobile

Connectez votre mobile au même réseau Wi-Fi :
http://192.168.1.20:8000
```

Le serveur est configuré pour écouter sur `0.0.0.0` (toutes les interfaces). Pour désactiver cette fonctionnalité :

```bash
gpi init --no-network
```

---

## Référence CLI

| Commande | Description |
|---|---|
| `gpi init` | Lancer l'assistant interactif |
| `gpi init -c config.yaml` | Générer depuis un fichier de configuration |
| `gpi init --no-network` | Désactiver la détection IP réseau |
| `gpi version` | Afficher la version installée |
| `gpi --help` | Afficher l'aide complète |
| `python -m gpi init` | Alternative si `gpi` n'est pas dans le PATH |

---

## Référence YAML

| Clé | Valeurs possibles | Défaut |
|---|---|---|
| `framework` | `fastapi`, `flask`, `django` | `fastapi` |
| `architecture` | `monolithique`, `microservices` | `monolithique` |
| `niveau` | `debutant`, `intermediaire`, `expert` | `debutant` |
| `nom` | Lettres, chiffres, _ (pas d'espace) | `monapi` |
| `description` | Texte libre | `""` |
| `auth` | `jwt`, `sessions`, `oauth2`, `aucune` | `aucune` |
| `database` | `sqlite`, `postgresql`, `mysql` | `sqlite` |
| `route_org` | `single` (1 fichier), `split` (4 fichiers) | `single` |
| `langue` | `fr`, `en`, `bilingue` | `fr` |
| `tests` | `true`, `false` | `false` |
| `docker` | `true`, `false` | `false` |
| `services` | Liste de noms (mode microservices) | `[auth, users]` |
| `redis` | `true`, `false` | `false` |
| `queue` | `celery`, `rq`, `aucune` | `aucune` |
| `monitoring` | `true`, `false` | `false` |
| `port` | Numéro de port | `8000` |

---

## Résolution de problèmes

### « gpi : commande introuvable »

Le dossier `Scripts` de Python n'est pas dans votre PATH. Deux solutions :

**Solution rapide :** utilisez `python -m gpi` à la place :

```bash
python -m gpi init
```

**Solution permanente (Windows PowerShell) :**

```powershell
# Trouver le dossier Scripts
python -c "import sysconfig; print(sysconfig.get_path('scripts'))"

# Ajouter au PATH (remplacez le chemin)
$scriptsPath = "C:\Users\VOTRE_NOM\AppData\Roaming\Python\Python3XX\Scripts"
[Environment]::SetEnvironmentVariable("Path",
  "$([Environment]::GetEnvironmentVariable('Path','User'));$scriptsPath", "User")
```

Redémarrez votre terminal après cette commande.

### « Permission denied » / « Accès refusé »

- **Windows :** ouvrez le terminal en tant qu'**administrateur**
- **Linux/Mac :** utilisez `pip install --user py-gpi` ou `sudo pip install py_gpi`

### « Le port 8000 est déjà utilisé »

Changez le port dans le fichier `.env` ou en ligne de commande :

```bash
# FastAPI
uvicorn main:app --reload --port 8001

# Django
python manage.py runserver 0.0.0.0:8001
```

### « Mon téléphone ne peut pas se connecter »

1. Vérifiez que PC et mobile sont sur le **même réseau Wi-Fi**
2. Vérifiez que le **pare-feu** autorise le port (désactivez temporairement pour tester)
3. Retrouvez votre IP manuellement :
   - **Windows :** `ipconfig` → cherchez « Adresse IPv4 »
   - **Linux/Mac :** `ifconfig` ou `ip addr`

---

## Tests

```bash
pip install pytest
python -m pytest tests/ -v
```

---

## Licence

MIT – Libre d'utilisation, modification et distribution.

---

Créé par **SOSSOU Elkast Orsini** · [PyPI](https://pypi.org/project/py-gpi/) · Fait avec soin pour la communauté Python.
