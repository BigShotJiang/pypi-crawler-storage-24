from __future__ import annotations

from typing import Any, Dict, List, Optional

from pydantic import BaseModel, ConfigDict, Field

from goodmem.models.space_embedder_config import SpaceEmbedderConfig
from goodmem.models.chunking_configuration import ChunkingConfiguration


class SpaceCreationRequest(BaseModel):
    """Request body for creating a new Space. A Space is a container for organizing related memories with vector embeddings."""

    model_config = ConfigDict(populate_by_name=True, protected_namespaces=(), extra='forbid')

    name: str = Field(description="The desired name for the space. Must be unique within the user's scope.")
    labels: Optional[dict] = Field(default=None, description='A set of key-value pairs to categorize or tag the space. Used for filtering and organizational purposes.')
    space_embedders: list[SpaceEmbedderConfig] = Field(description='List of embedder configurations to associate with this space. Each specifies an embedder ID and a relative default retrieval weight used when no per-request overrides are provided.', alias="spaceEmbedders")
    public_read: Optional[bool] = Field(default=None, description='Indicates if the space and its memories can be read by unauthenticated users or users other than the owner. Defaults to false.', alias="publicRead")
    owner_id: Optional[str] = Field(default=None, description='Optional owner ID. If not provided, derived from the authentication context. Requires CREATE_SPACE_ANY permission if specified.', alias="ownerId")
    default_chunking_config: ChunkingConfiguration = Field(description='Default chunking strategy for memories in this space', alias="defaultChunkingConfig")
    space_id: Optional[str] = Field(default=None, description='Optional client-provided UUID for idempotent creation. If not provided, server generates a new UUID. Returns ALREADY_EXISTS if ID is already in use.', alias="spaceId")

