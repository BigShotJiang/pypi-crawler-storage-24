from __future__ import annotations

from typing import Any, Dict, List, Optional

from pydantic import BaseModel, ConfigDict, Field

from goodmem.models.batch_delete_memory_selector_request import BatchDeleteMemorySelectorRequest


class BatchMemoryDeletionRequest(BaseModel):
    """Request body for deleting memories using ID and/or filtered selectors"""

    model_config = ConfigDict(populate_by_name=True, protected_namespaces=(), extra='forbid')

    requests: list[BatchDeleteMemorySelectorRequest] = Field(description='Array of delete selectors')

