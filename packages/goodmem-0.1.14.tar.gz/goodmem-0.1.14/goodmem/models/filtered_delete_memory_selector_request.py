from __future__ import annotations

from typing import Any, Dict, List, Optional

from pydantic import BaseModel, ConfigDict, Field



class FilteredDeleteMemorySelectorRequest(BaseModel):
    """Filtered selector scoped to a specific space"""

    model_config = ConfigDict(populate_by_name=True, protected_namespaces=(), extra='forbid')

    space_id: str = Field(description='Space ID scope for the filtered delete', alias="spaceId")
    status_filter: Optional[str] = Field(default=None, description='Optional processing status filter (PENDING, PROCESSING, COMPLETED, FAILED)', alias="statusFilter")
    filter: Optional[str] = Field(default=None, description='Optional metadata filter expression')

