from __future__ import annotations

from typing import Any, Dict, List, Optional

from pydantic import BaseModel, ConfigDict, Field



class AdminPurgeJobsRequest(BaseModel):
    """AdminPurgeJobsRequest"""

    model_config = ConfigDict(populate_by_name=True, protected_namespaces=(), extra='forbid')

    older_than: Optional[str] = Field(default=None, description='ISO-8601 timestamp cutoff; only terminal jobs older than this instant are eligible.', alias="olderThan")
    statuses: Optional[list[str]] = Field(default=None, description='Optional terminal background job statuses to target for purging.')
    dry_run: Optional[bool] = Field(default=None, description='If true, report purge counts without deleting any rows.', alias="dryRun")
    limit: Optional[int] = Field(default=None, description='Maximum number of jobs to purge in this request.')

