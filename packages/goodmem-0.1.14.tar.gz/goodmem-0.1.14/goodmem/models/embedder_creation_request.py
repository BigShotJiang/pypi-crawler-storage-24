from __future__ import annotations

from typing import Any, Dict, List, Optional

from pydantic import BaseModel, ConfigDict, Field

from goodmem.models.provider_type import ProviderType
from goodmem.models.distribution_type import DistributionType
from goodmem.models.modality import Modality
from goodmem.models.endpoint_authentication import EndpointAuthentication


class EmbedderCreationRequest(BaseModel):
    """Request body for creating a new Embedder. An Embedder represents a configuration for vectorizing content."""

    model_config = ConfigDict(populate_by_name=True, protected_namespaces=(), extra='forbid')

    display_name: str = Field(description='User-facing name of the embedder', alias="displayName")
    description: Optional[str] = Field(default=None, description='Description of the embedder')
    provider_type: ProviderType = Field(description='Type of embedding provider', alias="providerType")
    endpoint_url: str = Field(description='API endpoint URL', alias="endpointUrl")
    api_path: Optional[str] = Field(default=None, description='API path for embeddings request (defaults: Cohere /v2/embed, TEI /embed, others /embeddings)', alias="apiPath")
    model_identifier: str = Field(description='Model identifier', alias="modelIdentifier")
    dimensionality: int = Field(description='Output vector dimensions')
    distribution_type: DistributionType = Field(description='Type of embedding distribution (DENSE or SPARSE)', alias="distributionType")
    max_sequence_length: Optional[int] = Field(default=None, description='Maximum input sequence length', alias="maxSequenceLength")
    supported_modalities: Optional[list[Modality]] = Field(default=None, description='Supported content modalities (defaults to TEXT if not provided)', alias="supportedModalities")
    credentials: Optional[EndpointAuthentication] = Field(default=None, description='Structured credential payload describing how to authenticate with the provider. Required for SaaS providers such as COHERE, JINA, and VOYAGE; optional for local or proxy providers.')
    labels: Optional[dict] = Field(default=None, description='User-defined labels for categorization')
    version: Optional[str] = Field(default=None, description='Version information')
    monitoring_endpoint: Optional[str] = Field(default=None, description='Monitoring endpoint URL', alias="monitoringEndpoint")
    owner_id: Optional[str] = Field(default=None, description='Optional owner ID. If not provided, derived from the authentication context. Requires CREATE_EMBEDDER_ANY permission if specified.', alias="ownerId")
    embedder_id: Optional[str] = Field(default=None, description='Optional client-provided UUID for idempotent creation. If not provided, server generates a new UUID. Returns ALREADY_EXISTS if ID is already in use.', alias="embedderId")

