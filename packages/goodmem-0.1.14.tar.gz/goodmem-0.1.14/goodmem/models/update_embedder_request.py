from __future__ import annotations

from typing import Any, Dict, List, Optional

from pydantic import BaseModel, ConfigDict, Field

from goodmem.models.modality import Modality
from goodmem.models.endpoint_authentication import EndpointAuthentication


class UpdateEmbedderRequest(BaseModel):
    """Request body for updating an existing Embedder. Only fields that should be updated need to be included."""

    model_config = ConfigDict(populate_by_name=True, protected_namespaces=(), extra='forbid')

    display_name: Optional[str] = Field(default=None, description='User-facing name of the embedder', alias="displayName")
    description: Optional[str] = Field(default=None, description='Description of the embedder')
    endpoint_url: Optional[str] = Field(default=None, description='API endpoint URL', alias="endpointUrl")
    api_path: Optional[str] = Field(default=None, description='API path for embeddings request', alias="apiPath")
    model_identifier: Optional[str] = Field(default=None, description='Model identifier', alias="modelIdentifier")
    dimensionality: Optional[int] = Field(default=None, description='Output vector dimensions')
    max_sequence_length: Optional[int] = Field(default=None, description='Maximum input sequence length', alias="maxSequenceLength")
    supported_modalities: Optional[list[Modality]] = Field(default=None, description='Supported content modalities', alias="supportedModalities")
    credentials: Optional[EndpointAuthentication] = Field(default=None, description='Structured credential payload describing how to authenticate with the provider')
    replace_labels: Optional[dict] = Field(default=None, description='Replace all existing labels with these (mutually exclusive with mergeLabels)', alias="replaceLabels")
    merge_labels: Optional[dict] = Field(default=None, description='Merge these labels with existing ones (mutually exclusive with replaceLabels)', alias="mergeLabels")
    version: Optional[str] = Field(default=None, description='Version information')
    monitoring_endpoint: Optional[str] = Field(default=None, description='Monitoring endpoint URL', alias="monitoringEndpoint")

