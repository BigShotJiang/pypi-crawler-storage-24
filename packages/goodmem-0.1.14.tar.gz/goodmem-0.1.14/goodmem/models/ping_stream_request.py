from __future__ import annotations

from typing import Any, Dict, List, Optional

from pydantic import BaseModel, ConfigDict, Field

from goodmem.models.ping_target_type import PingTargetType
from goodmem.models.ping_payload_type import PingPayloadType


class PingStreamRequest(BaseModel):
    """Request payload for a streaming ping session"""

    model_config = ConfigDict(populate_by_name=True, protected_namespaces=(), extra='forbid')

    target_id: str = Field(description='Target resource ID (UUID)', alias="targetId")
    target_type_hint: Optional[PingTargetType] = Field(default=None, description='Optional hint for the target resource type', alias="targetTypeHint")
    count: Optional[int] = Field(default=None, description='Number of probes to run (0 uses server default)')
    interval_ms: Optional[int] = Field(default=None, description='Delay between probes in milliseconds (0 uses server default)', alias="intervalMs")
    timeout_ms: Optional[int] = Field(default=None, description='Per-probe timeout in milliseconds (0 uses server default)', alias="timeoutMs")
    payload_type: Optional[PingPayloadType] = Field(default=None, description='Desired payload type (defaults to provider-specific value)', alias="payloadType")
    payload: Optional[str] = Field(default=None, description='Explicit UTF-8 payload to send with each probe (mutually exclusive with payloadSizeBytes)')
    payload_size_bytes: Optional[int] = Field(default=None, description='Synthetic payload size in bytes (mutually exclusive with payload)', alias="payloadSizeBytes")
    max_in_flight: Optional[int] = Field(default=None, description='Maximum concurrent probes (defaults to 1)', alias="maxInFlight")
    jitter: Optional[bool] = Field(default=None, description='Add jitter to probe scheduling')
    labels: Optional[dict] = Field(default=None, description='Optional labels to attach to the ping session')

