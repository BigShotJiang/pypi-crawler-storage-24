from __future__ import annotations

from typing import Any, Dict, List, Optional

from pydantic import BaseModel, ConfigDict, Field

from goodmem.models.ocr_input_format import OcrInputFormat


class OcrDocumentRequest(BaseModel):
    """Request body for OCR document processing."""

    model_config = ConfigDict(populate_by_name=True, protected_namespaces=(), extra='forbid')

    content: Optional[str] = Field(description='Base64-encoded document bytes')
    format: Optional[OcrInputFormat] = Field(default=None, description='Input format hint (AUTO, PDF, TIFF, PNG, JPEG, BMP)')
    include_raw_json: Optional[bool] = Field(default=None, description='Include raw OCR JSON payload in the response', alias="includeRawJson")
    include_markdown: Optional[bool] = Field(default=None, description='Include markdown rendering in the response', alias="includeMarkdown")
    start_page: Optional[int] = Field(default=None, description='0-based inclusive start page', alias="startPage")
    end_page: Optional[int] = Field(default=None, description='0-based inclusive end page', alias="endPage")

