"""GoodMem Python SDK.

The main entry points are :class:`Goodmem` (synchronous) and
:class:`AsyncGoodmem` (async). Both expose the same namespace attributes
(``embedders``, ``memories``, ``spaces``, etc.) and raise typed exceptions
from :mod:`goodmem.errors` on non-2xx responses.

See https://docs.goodmem.ai for the full tutorial and API reference.
"""

from importlib.metadata import version as _pkg_version

__version__ = _pkg_version("goodmem")

from goodmem.client import AsyncGoodmem, Goodmem
from goodmem.pagination import AsyncPage, Page
from goodmem._overrides import MemoryCreationRequest
from goodmem.errors import (
    APIError,
    AuthenticationError,
    BadRequestError,
    ConflictError,
    GoodMemError,
    InternalServerError,
    NotFoundError,
    PermissionDeniedError,
    RateLimitError,
    UnprocessableEntityError,
)

__all__ = [
    "__version__",
    "Goodmem",
    "AsyncGoodmem",
    "Page",
    "AsyncPage",
    "MemoryCreationRequest",
    "GoodMemError",
    "APIError",
    "BadRequestError",
    "AuthenticationError",
    "PermissionDeniedError",
    "NotFoundError",
    "ConflictError",
    "UnprocessableEntityError",
    "RateLimitError",
    "InternalServerError",
]
