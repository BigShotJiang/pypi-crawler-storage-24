// DON'T MODIFY. Stores hash of current source code, auto-added on recompile
#ifndef RH56F1_SOURCE_HASH_H
#define RH56F1_SOURCE_HASH_H
static const char* rh56f1_source_hash_str __attribute__((used)) = "__FEATHER_SOURCE_HASH__333201650629967171302132822713902257025__END_FEATHER_SOURCE_HASH__";
#endif


