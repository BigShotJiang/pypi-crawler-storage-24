// DON'T MODIFY. Stores hash of current source code, auto-added on recompile
static const char* sct_source_hash_str __attribute__((used)) = "__FEATHER_SOURCE_HASH__1399813087062705112618061280789162657740__END_FEATHER_SOURCE_HASH__";
