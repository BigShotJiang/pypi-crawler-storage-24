import{b as r}from"./graph-Bu4Rf9jc.js";var e=4;function a(o){return r(o,e)}export{a as c};
