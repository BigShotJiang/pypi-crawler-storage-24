from cremalink.transports.cloud.transport import CloudTransport


def test_cloud_transport_set_property_posts_datapoint():
    transport = CloudTransport.__new__(CloudTransport)
    calls = {}

    def fake_post(path, data):
        calls["path"] = path
        calls["data"] = data
        return {"status": "queued"}

    transport._post = fake_post

    result = transport.set_property("app_data_request", "blob")

    assert calls == {
        "path": "/properties/app_data_request/datapoints.json",
        "data": {"datapoint": {"value": "blob"}},
    }
    assert result == {"status": "queued"}
