"""Tests for cremalink.parsing.properties.settings.

Blob constants are reused from the HA integration test suite — they were
captured from a live ECAM450 device (DSN AC000W032240853).
"""

import base64

import crcmod
import pytest

from cremalink.parsing.properties.settings import (
    build_profile_switch_cmd,
    decode_active_profile,
    decode_custom_recipe_names,
    decode_profile_names,
    decode_serial_number,
    decode_temperature,
    encode_temperature,
)

_CRC_FN = crcmod.mkCrcFun(0x11021, initCrc=0x1D0F, rev=False, xorOut=0x0000)

# ---------------------------------------------------------------------------
# Blobs (verified against live ECAM450)
# ---------------------------------------------------------------------------

# d270 — serial number; "SN-12345" embedded in ASCII payload
_D270_SERIAL = "AAAAAAAAU04tMTIzNDUA"

# d051/d052 — profile names  Alice=1, Bob=2, Carol=3, Dave=4
_D051_BLOB = "0ACk8AEDAEEAbABpAGMAZQABAUIAbwBiAAEBQwBhAHIAbwBs/w=="
_D052_BLOB = "0ACk8AQBAEQAYQB2AGX/"

# d053/d054 — custom recipe names (same binary format, different slot indices)
_D053_BLOB = _D051_BLOB  # start_idx=1 → slots 1,2,3
_D054_BLOB = _D052_BLOB  # start_idx=4 → slot 4
_D053_ECAM450_LIVE = "0Eaq8AEDAFMAcABlAHMAaAB1AGwAAAAAAAAOAEMAdQBzAHQAbwBtACAAMgAAAAAAAEMAdQBzAHQAbwBtACAAMwAAAAAAscE="
_D054_ECAM450_LIVE = "0Eaq8AQGAEMAdQBzAHQAbwBtACAANAAAAAAAAEMAdQBzAHQAbwBtACAANQAAAAAAAEMAdQBzAHQAbwBtACAANgAAAAAAwHw="

# d286 — active profile (byte[9] = 0-based index)
_D286_PROFILE_1 = "0AuV8APuAAAAAB+t"  # byte[9]=0x00 → profile 1
_D286_PROFILE_2 = "0AuV8APuAAAAAR+t"  # byte[9]=0x01 → profile 2
_D286_PROFILE_3 = "0AuV8APuAAAAAh+t"  # byte[9]=0x02 → profile 3

# d281 — brew temperature; byte[9]=0x01 → Medium (96 °C)
_D281_MEDIUM = "0AuVDwA9AAAAAb0t"


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_d281_blob(value: int) -> str:
    """Build a valid d281 blob with byte[9]=value and recalculated CRC."""
    raw = bytearray(base64.b64decode(_D281_MEDIUM))
    raw[9] = value
    crc = _CRC_FN(bytes(raw[:10]))
    raw[10] = (crc >> 8) & 0xFF
    raw[11] = crc & 0xFF
    return base64.b64encode(bytes(raw)).decode()


# ---------------------------------------------------------------------------
# decode_serial_number
# ---------------------------------------------------------------------------


def test_decode_serial_number_returns_string() -> None:
    assert decode_serial_number(_D270_SERIAL) == "SN-12345"


def test_decode_serial_number_none_input() -> None:
    assert decode_serial_number(None) is None


def test_decode_serial_number_empty_input() -> None:
    assert decode_serial_number("") is None


def test_decode_serial_number_header_only_returns_none() -> None:
    # 6 header bytes, no printable payload
    blob = base64.b64encode(bytes(6)).decode()
    assert decode_serial_number(blob) is None


# ---------------------------------------------------------------------------
# decode_profile_names
# ---------------------------------------------------------------------------


def test_decode_profile_names_four_profiles() -> None:
    result = decode_profile_names(_D051_BLOB, _D052_BLOB)
    assert result == {1: "Alice", 2: "Bob", 3: "Carol", 4: "Dave"}


def test_decode_profile_names_first_blob_only() -> None:
    result = decode_profile_names(_D051_BLOB, None)
    assert result == {1: "Alice", 2: "Bob", 3: "Carol"}


def test_decode_profile_names_second_blob_only() -> None:
    result = decode_profile_names(None, _D052_BLOB)
    assert result == {4: "Dave"}


def test_decode_profile_names_both_none() -> None:
    assert decode_profile_names(None, None) == {}


def test_decode_profile_names_header_only_blob() -> None:
    header_only = base64.b64encode(bytes([0xD0, 0x00, 0xA4, 0xF0, 1, 1, 0x00])).decode()
    assert decode_profile_names(header_only, None) == {}


# ---------------------------------------------------------------------------
# decode_custom_recipe_names
# ---------------------------------------------------------------------------


def test_decode_custom_recipe_names_six_slots() -> None:
    result = decode_custom_recipe_names(_D053_BLOB, _D054_BLOB)
    assert result == {1: "Alice", 2: "Bob", 3: "Carol", 4: "Dave"}


def test_decode_custom_recipe_names_partial() -> None:
    assert decode_custom_recipe_names(_D053_BLOB, None) == {
        1: "Alice",
        2: "Bob",
        3: "Carol",
    }
    assert decode_custom_recipe_names(None, _D054_BLOB) == {4: "Dave"}


def test_decode_custom_recipe_names_both_none() -> None:
    assert decode_custom_recipe_names(None, None) == {}


def test_decode_custom_recipe_names_live_ecam450_padding() -> None:
    result = decode_custom_recipe_names(_D053_ECAM450_LIVE, _D054_ECAM450_LIVE)
    assert result == {
        1: "Speshul",
        2: "Custom 2",
        3: "Custom 3",
        4: "Custom 4",
        5: "Custom 5",
        6: "Custom 6",
    }


# ---------------------------------------------------------------------------
# decode_active_profile
# ---------------------------------------------------------------------------


def test_decode_active_profile_returns_1based_index() -> None:
    assert decode_active_profile(_D286_PROFILE_1) == 1
    assert decode_active_profile(_D286_PROFILE_2) == 2
    assert decode_active_profile(_D286_PROFILE_3) == 3


def test_decode_active_profile_none_input() -> None:
    assert decode_active_profile(None) is None


def test_decode_active_profile_empty_input() -> None:
    assert decode_active_profile("") is None


def test_decode_active_profile_too_short_blob() -> None:
    blob = base64.b64encode(bytes(8)).decode()  # only 8 bytes, byte[9] missing
    assert decode_active_profile(blob) is None


def test_decode_active_profile_out_of_range() -> None:
    # byte[9] = 0xFF — not a valid profile index
    raw = bytearray(10)
    raw[9] = 0xFF
    blob = base64.b64encode(bytes(raw)).decode()
    assert decode_active_profile(blob) is None


# ---------------------------------------------------------------------------
# decode_temperature
# ---------------------------------------------------------------------------


def test_decode_temperature_medium_from_live_blob() -> None:
    assert decode_temperature(_D281_MEDIUM) == "medium"


def test_decode_temperature_all_levels() -> None:
    for idx, expected in enumerate(("low", "medium", "high")):
        assert decode_temperature(_make_d281_blob(idx)) == expected


def test_decode_temperature_none_input() -> None:
    assert decode_temperature(None) is None


def test_decode_temperature_empty_input() -> None:
    assert decode_temperature("") is None


def test_decode_temperature_too_short_blob() -> None:
    blob = base64.b64encode(bytes(8)).decode()
    assert decode_temperature(blob) is None


# ---------------------------------------------------------------------------
# encode_temperature
# ---------------------------------------------------------------------------


def test_encode_temperature_round_trips() -> None:
    """encode then decode returns the same level."""
    for level in ("low", "medium", "high"):
        new_blob = encode_temperature(_D281_MEDIUM, level)
        assert decode_temperature(new_blob) == level


def test_encode_temperature_crc_is_correct() -> None:
    """encode_temperature recalculates a valid CRC-16."""
    for level in ("low", "medium", "high"):
        new_blob = encode_temperature(_D281_MEDIUM, level)
        raw = base64.b64decode(new_blob)
        assert len(raw) == 12
        expected_crc = _CRC_FN(bytes(raw[:10]))
        actual_crc = int.from_bytes(raw[10:12], "big")
        assert actual_crc == expected_crc, f"CRC mismatch for level={level}"


def test_encode_temperature_invalid_level_raises() -> None:
    with pytest.raises(ValueError, match="Unknown temperature level"):
        encode_temperature(_D281_MEDIUM, "scorching")


def test_encode_temperature_preserves_other_bytes() -> None:
    """Only byte[9] and CRC bytes change; bytes[0:9] remain untouched."""
    original = base64.b64decode(_D281_MEDIUM)
    new_blob = encode_temperature(_D281_MEDIUM, "high")
    result = base64.b64decode(new_blob)
    assert result[:9] == original[:9]


# ---------------------------------------------------------------------------
# build_profile_switch_cmd
# ---------------------------------------------------------------------------


def test_build_profile_switch_cmd_length() -> None:
    for profile in (1, 2, 3, 4):
        cmd = build_profile_switch_cmd(profile)
        assert len(cmd) == 15, f"Expected 15 bytes for profile {profile}"


def test_build_profile_switch_cmd_fixed_bytes() -> None:
    for profile in (1, 2, 3, 4):
        cmd = build_profile_switch_cmd(profile)
        assert cmd[0] == 0x0D
        assert cmd[1] == 0x06
        assert cmd[3] == 0xF0
        assert cmd[4] == profile
        assert cmd[12:15] == bytes([0x30, 0xC8, 0x1A])


def test_build_profile_switch_cmd_crc() -> None:
    for profile in (1, 2, 3, 4):
        cmd = build_profile_switch_cmd(profile)
        expected_crc = _CRC_FN(cmd[:5])
        actual_crc = int.from_bytes(cmd[5:7], "big")
        assert actual_crc == expected_crc, f"CRC mismatch for profile {profile}"


def test_build_profile_switch_cmd_nonce_varies() -> None:
    """The nonce byte (cmd[2]) is random — two calls should almost never match."""
    results = {build_profile_switch_cmd(1)[2] for _ in range(20)}
    # With 256 possible values, 20 draws should yield >1 unique value with
    # overwhelming probability. A single repeated value would be a fluke.
    assert len(results) > 1


def test_build_profile_switch_cmd_out_of_range_raises() -> None:
    for bad in (0, 5, -1, 255):
        with pytest.raises(ValueError, match="profile_1based must be 1"):
            build_profile_switch_cmd(bad)


def test_encode_temperature_short_blob_raises() -> None:
    short_blob = base64.b64encode(bytes(8)).decode()
    with pytest.raises(ValueError, match="too short"):
        encode_temperature(short_blob, "high")
