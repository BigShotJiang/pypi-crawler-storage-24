"""
Decoders and encoders for machine-settings properties (d051/d052/d053/d054/d270/d281/d286).

All functions operate on raw base64-encoded property blobs as returned by the cloud API.
No I/O or transport dependency — pure data transformation.

CRC algorithm (CRC-16/XMODEM variant used throughout):
    poly=0x11021, initCrc=0x1D0F, rev=False, xorOut=0x0000
"""

from __future__ import annotations

import base64
import os
import re
import time
from typing import Optional

try:
    import crcmod as _crcmod

    _CRC_FN = _crcmod.mkCrcFun(0x11021, initCrc=0x1D0F, rev=False, xorOut=0x0000)
except ImportError:  # pragma: no cover
    _CRC_FN = None  # type: ignore[assignment]


# ---------------------------------------------------------------------------
# d270 — serial number
# ---------------------------------------------------------------------------

_D270_HEADER_LEN = 6
_SERIAL_RE = re.compile(rb"[\x20-\x7e]+")


def decode_serial_number(blob_b64: Optional[str]) -> Optional[str]:
    """Decode a d270_serialnumber base64 blob and return the serial string.

    The blob has a 6-byte header followed by printable ASCII bytes terminated
    by a null byte.

    Returns None if the blob is missing or cannot be decoded.
    """
    if not blob_b64:
        return None
    try:
        raw = base64.b64decode(blob_b64)
        payload = raw[_D270_HEADER_LEN:]
        m = _SERIAL_RE.search(payload)
        if m:
            return m.group().decode("ascii")
    except Exception:
        pass
    return None


# ---------------------------------------------------------------------------
# d051/d052 — profile names  |  d053/d054 — custom recipe names
# ---------------------------------------------------------------------------

_D05X_HEADER_LEN = 7


def _decode_name_blob(blob_b64: Optional[str]) -> tuple[int, list[str]]:
    """Parse a d051/d052/d053/d054 name blob.

    Returns (start_index, [name, ...]) where start_index is the 1-based slot
    index of the first name encoded in the blob (read from header byte[4]).
    Names are UTF-16LE, packed sequentially and separated by non-printable pairs.

    Returns (0, []) on any error.
    """
    if not blob_b64:
        return 0, []
    try:
        raw = base64.b64decode(blob_b64)
    except Exception:
        return 0, []
    if len(raw) <= _D05X_HEADER_LEN:
        return 0, []

    start_idx: int = raw[4]  # 1-based index of first name in this blob
    payload = raw[_D05X_HEADER_LEN:]
    names: list[str] = []
    current = bytearray()
    i = 0
    while i < len(payload) - 1:
        lo, hi = payload[i], payload[i + 1]
        # Real ECAM450 blobs can contain uneven zero padding between names.
        # Scan byte-by-byte until we find the next printable UTF-16LE pair.
        if (hi == 0x00 or hi == 0xFF) and 0x20 <= lo <= 0x7E:
            current.extend([lo, 0x00])
            i += 2
            continue
        if current:
            names.append(current.decode("utf-16-le"))
            current = bytearray()
        i += 1
    if current:
        names.append(current.decode("utf-16-le"))

    return start_idx, names


def decode_profile_names(
    blob_1_3_b64: Optional[str],
    blob_4_b64: Optional[str],
) -> dict[int, str]:
    """Merge d051 and d052 blobs into a {1-based-index: name} mapping.

    Args:
        blob_1_3_b64: Base64 value of d051_profile_name1_3 (profiles 1–3).
        blob_4_b64:   Base64 value of d052_profile_name4  (profile 4).

    Returns a dict such as {1: "Alice", 2: "Bob", 3: "Carol", 4: "Dave"}.
    Missing blobs are silently skipped; the returned dict may be empty.
    """
    name_map: dict[int, str] = {}
    for blob in (blob_1_3_b64, blob_4_b64):
        start_idx, names = _decode_name_blob(blob)
        for offset, name in enumerate(names):
            name_map[start_idx + offset] = name
    return name_map


def decode_custom_recipe_names(
    blob_1_3_b64: Optional[str],
    blob_4_6_b64: Optional[str],
) -> dict[int, str]:
    """Merge d053 and d054 blobs into a {1-based slot index: name} mapping.

    Identical blob format to profile names. d053 covers custom slots 1–3,
    d054 covers slots 4–6.

    Args:
        blob_1_3_b64: Base64 value of d053_custom_name_13 (slots 1–3).
        blob_4_6_b64: Base64 value of d054_custom_name_46 (slots 4–6).

    Returns a dict such as {1: "MyEspresso", 2: "MyLatte"}.
    """
    name_map: dict[int, str] = {}
    for blob in (blob_1_3_b64, blob_4_6_b64):
        start_idx, names = _decode_name_blob(blob)
        for offset, name in enumerate(names):
            name_map[start_idx + offset] = name
    return name_map


# ---------------------------------------------------------------------------
# d286 — active profile index
# ---------------------------------------------------------------------------

_D286_VALUE_BYTE = 9


def decode_active_profile(blob_b64: Optional[str]) -> Optional[int]:
    """Decode the d286_mach_sett_profile blob and return the active profile index.

    The profile index is stored at byte[9] and is 0-based (0 = profile 1).
    This function returns a 1-based index for consistency with decode_profile_names.

    Returns None if the blob is missing, malformed, or out of range.
    """
    if not blob_b64:
        return None
    try:
        raw = base64.b64decode(blob_b64)
        if len(raw) > _D286_VALUE_BYTE:
            idx_0based = raw[_D286_VALUE_BYTE]
            if 0 <= idx_0based <= 3:
                return idx_0based + 1
    except Exception:
        pass
    return None


# ---------------------------------------------------------------------------
# d281 — brew temperature
# ---------------------------------------------------------------------------

_D281_VALUE_BYTE = 9
_D281_CRC_RANGE = 10  # CRC-16 covers bytes[0:10]
_TEMPERATURE_LEVELS = ("low", "medium", "high")  # indices 0, 1, 2


def decode_temperature(blob_b64: Optional[str]) -> Optional[str]:
    """Decode the d281_mach_sett_temperature blob and return a level string.

    Returns one of "low", "medium", "high", or None if the blob is absent/invalid.

    Level mapping (confirmed by live capture on ECAM450):
        0 → "low"    (93 °C)
        1 → "medium" (96 °C)
        2 → "high"   (100 °C)
    """
    if not blob_b64:
        return None
    try:
        raw = base64.b64decode(blob_b64)
        if len(raw) > _D281_VALUE_BYTE:
            val = raw[_D281_VALUE_BYTE]
            if 0 <= val < len(_TEMPERATURE_LEVELS):
                return _TEMPERATURE_LEVELS[val]
    except Exception:
        pass
    return None


def encode_temperature(blob_b64: str, level: str) -> str:
    """Return a new base64 d281 blob with the temperature set to *level*.

    Mutates byte[9] in the existing blob and recalculates the CRC-16 over
    bytes[0:10], writing the result to bytes[10:11] (big-endian).

    Args:
        blob_b64: Current base64-encoded d281 blob (as returned by the API).
        level:    One of "low", "medium", "high".

    Returns:
        A new base64-encoded blob ready to be written back via set_property.

    Raises:
        ValueError: If *level* is not a recognised temperature level.
        RuntimeError: If the crcmod package is not installed.
    """
    if level not in _TEMPERATURE_LEVELS:
        raise ValueError(
            f"Unknown temperature level {level!r}; expected one of {_TEMPERATURE_LEVELS}"
        )
    if _CRC_FN is None:
        raise RuntimeError(
            "crcmod is required for encode_temperature; install it with: pip install crcmod"
        )

    new_val = _TEMPERATURE_LEVELS.index(level)
    raw = bytearray(base64.b64decode(blob_b64))
    if len(raw) < 12:
        raise ValueError(
            f"d281 blob is too short ({len(raw)} bytes); expected at least 12"
        )
    raw[_D281_VALUE_BYTE] = new_val
    crc = _CRC_FN(bytes(raw[:_D281_CRC_RANGE]))
    raw[10] = (crc >> 8) & 0xFF
    raw[11] = crc & 0xFF
    return base64.b64encode(bytes(raw)).decode()


# ---------------------------------------------------------------------------
# app_data_request — profile switch command frame
# ---------------------------------------------------------------------------


def build_profile_switch_cmd(profile_1based: int) -> bytes:
    """Build the 15-byte app_data_request frame to switch the active user profile.

    Frame layout (confirmed by live traffic capture on ECAM450):

        byte[0]     0x0d            frame start
        byte[1]     0x06            fixed length byte
        byte[2]     <nonce>         random byte (ignored by machine)
        byte[3]     0xf0            fixed
        byte[4]     <profile>       1-based profile index (1–4)
        bytes[5:7]                  CRC-16/XMODEM over bytes[0:5]
        bytes[7:11]                 unix timestamp, big-endian uint32
        byte[11]    0x00            padding
        bytes[12:15]                fixed trailer 0x30 0xc8 0x1a

    Args:
        profile_1based: Target profile number (1–4).

    Returns:
        Raw bytes suitable for base64-encoding and writing to app_data_request.

    Raises:
        RuntimeError: If the crcmod package is not installed.
    """
    if not (1 <= profile_1based <= 4):
        raise ValueError(f"profile_1based must be 1–4, got {profile_1based!r}")
    if _CRC_FN is None:
        raise RuntimeError(
            "crcmod is required for build_profile_switch_cmd; install it with: pip install crcmod"
        )

    nonce = os.urandom(1)[0]
    header = bytes([0x0D, 0x06, nonce, 0xF0, profile_1based])
    crc = _CRC_FN(header)
    ts = int(time.time()).to_bytes(4, "big")
    return header + crc.to_bytes(2, "big") + ts + bytes([0x00, 0x30, 0xC8, 0x1A])
