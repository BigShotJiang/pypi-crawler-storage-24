import os
import sys
import signal
import time
import datetime
import subprocess
import argparse
import psutil

PID = os.getpid()


def get_real_path(directory, raw_filename):
    if os.path.isabs(raw_filename):
        file_path = raw_filename
    else:
        file_path = os.path.join(directory, raw_filename)
    if os.path.exists(file_path):
        return os.path.realpath(file_path)
    return raw_filename


def get_std_cmdline(process):
    try:
        cwd = process.cwd()
        cmdline = [get_real_path(cwd, i) for i in process.cmdline()]
        return cmdline
    except Exception:
        return None


def kill_process_tree(pid, sig_n=signal.SIGKILL):
    if pid == PID:
        return
    sig = signal.SIGTERM
    if sig_n == 9:
        sig = signal.SIGKILL
    pid_list = [pid]
    while True:
        if len(pid_list) == 0:
            break
        tmp_pid = pid_list.pop(0)
        if not psutil.pid_exists(tmp_pid):
            continue
        try:
            parent = psutil.Process(tmp_pid)
            if parent is not None:
                children = parent.children(recursive=False)
                if children is not None:
                    for child in children:
                        pid_list.append(child.pid)
                cmdline = " ".join(parent.cmdline())
                print(f"kill {parent.pid} {cmdline}")
                parent.send_signal(sig)
        except psutil.NoSuchProcess:
            continue


def mkdir(path):
    if not os.path.exists(path):
        os.makedirs(path)


def RUN():
    if len(sys.argv) < 2:
        print("usage RUN [script_file]")
        return
    if len(sys.argv) >= 3:
        args = " ".join(sys.argv[2:])
    else:
        args = ""
    script_file = os.path.realpath(os.path.abspath(sys.argv[1]))
    path, name = os.path.split(script_file)
    log_path = os.path.join(path, "log")
    log_file = os.path.join(path, "log", f"{name}.log")
    mkdir(log_path)
    now = datetime.datetime.now()
    if name.endswith(".py"):
        cmd = f"nohup python3 -Wignore {script_file} {args} &"
    elif name.endswith(".sh"):
        cmd = f"nohup bash {script_file} {args} &"
    else:
        cmd = f"nohup {script_file} {args} &"

    with open(log_file, "a") as f:
        f.write(f"{now} | start run {name}\n")
    subprocess.Popen(
        cmd,
        cwd=path,
        stdout=open(log_file, "a"),
        stderr=open(log_file, "a"),
        shell=True,
    )
    print("run success, cmd:", cmd)


def KILL():
    if len(sys.argv) < 2 or "-h" in sys.argv:
        print("usage: KILL [script_file]")
        return
    signal_num = 9
    use_key_word = True
    if "-f" in sys.argv:
        use_key_word = False
    argv = [i for i in sys.argv[1:] if i != "-f"]
    keys = [i for i in argv if i[0] == "-"]
    for arg in argv:
        if arg[0] == "-":
            signal_num = int(arg[1:])
            continue
        key = arg
        break
    if not use_key_word:
        key = os.path.realpath(os.path.abspath(key))
    for process in psutil.process_iter(["pid", "name", "cmdline"]):
        cmdll = get_std_cmdline(process)
        if cmdll is None:
            continue
        cmdline = " ".join(cmdll)
        if "KILL" in cmdline:
            continue
        if key in cmdline:
            pid = process.info["pid"]
            kill_process_tree(pid, signal_num)


def RESTART():
    if len(sys.argv) < 2 or "-h" in sys.argv:
        print("usage: RESTART [script_file]")
        return
    signal_num = 15
    key = sys.argv[-1]
    key = os.path.realpath(os.path.abspath(key))
    print("restart", key)
    if not os.path.exists(key):
        print(f"{key} is not exists")
        return

    for process in psutil.process_iter(["pid", "name", "cmdline"]):
        cmdll = get_std_cmdline(process)
        if cmdll is None or len(cmdll) == 0:
            continue
        exe = cmdll[0]
        if "/" in exe:
            exe = exe.split("/")[-1]
        if exe not in ["python3", "bash"]:
            continue
        if len(cmdll) < 2:
            continue
        script_file = ""
        for cc in cmdll[1:]:
            if cc.startswith("-"):
                continue
            script_file = cc
            break
        if "RESTART" in script_file:
            continue
        if os.path.realpath(os.path.abspath(script_file)) == key:
            try:
                pid = process.info["pid"]
            except Exception:
                print(f"pid {pid} is not exists")
                continue
            if pid == PID:
                continue
            for i in range(30):
                if psutil.pid_exists(pid):
                    kill_process_tree(pid, signal_num)
                    time.sleep(1)
                else:
                    print(f"kill {key} success!")
                    break
            if psutil.pid_exists(pid):
                kill_process_tree(pid, 9)
    TASK([sys.argv[-1], "--daemon"])


def today():
    return datetime.datetime.now().strftime("%Y%m%d")


def TASK(args=None):
    if args is None:
        args = sys.argv[1:].copy()
        TASK(args)
        return
    if len(args) == 0 or "-h" in args or "--help" in args:
        usage = """usage TASK [script_file] <options>
    -q : quiet mode, all output will be redirect to /dev/null
    --daemon : run as daemon, this is default mode"""
        print(usage)
        return
    if "--daemon" not in args:
        args.append("--daemon")
        TASK(args)
        return
    available_argv = [i for i in args if i[0] != "-"]
    script_file = available_argv[0]
    no_log = "-q" in args
    now = datetime.datetime.now()
    if not os.path.exists(script_file):
        print(f"{now} ERROR | script {script_file} is not exists")
        return
    script_file = os.path.realpath(os.path.abspath(sys.argv[1]))
    date = today()
    mkdir(os.path.expanduser("~/.cache/task_log/"))
    task_log = os.path.expanduser(f"~/.cache/task_log/out.{date}")
    for process in psutil.process_iter(["pid", "name", "cmdline"]):
        cmdline = get_std_cmdline(process)
        if cmdline is None or len(cmdline) < 2:
            continue
        if process.info["pid"] == PID:
            continue
        exe_name = cmdline[0]
        if "/" in exe_name:
            exe_name = exe_name.split("/")[-1]
        norm_exe = exe_name in ["python3", "bash"]
        script_file_name = os.path.realpath(os.path.abspath(cmdline[1]))
        if (
            script_file in script_file_name
            and norm_exe
            and "bash -c TASK" not in cmdline
        ):
            with open(task_log, "a") as f:
                f.write(f"{now} | {script_file} is running {cmdline}\n")
            s = " ".join(cmdline)
            create_time = process.create_time()
            readable_time = time.strftime(
                "%Y-%m-%d %H:%M:%S", time.localtime(create_time)
            )
            print(f"{now} INFO | already running, ps:\n {readable_time} {s}")
            return
    path, name = os.path.split(script_file)
    if script_file.endswith(".py"):
        cmd = ["cd", path, "&&", "python3", script_file]
    elif script_file.endswith(".sh"):
        cmd = ["cd", path, "&&", "bash", script_file]
    else:
        cmd = [script_file]
    if len(sys.argv) >= 3:
        cmd += [i for i in sys.argv[2:] if i not in ["--daemon", "-q", "-nolog"]]
    with open(task_log, "a") as f:
        f.write("{} | start run {}\n".format(datetime.datetime.now(), script_file))
        f.write("{} | cmd: {}\n".format(datetime.datetime.now(), " ".join(cmd)))
    if no_log:
        cmd += [">>", "/dev/null", "2>&1"]
    else:
        log_path = os.path.join(path, "log")
        mkdir(log_path)
        log_file = os.path.join(log_path, f"{name}.log")
    one_line_cmd = 'nohup bash -c "{}" >> {} 2>&1 &'.format(" ".join(cmd), log_file)
    os.system(one_line_cmd)
    print("start:", one_line_cmd)
    return


def DELETE():
    if len(sys.argv) < 2 or "-h" in sys.argv:
        print("usage DELETE [file]")
        return
    file = sys.argv[1]
    os.system(f"nohup shred -u -n 5 -z {file} >> /dev/null &")


def manage_crontab(script_name, hour, minute, weekday):
    script_name = os.path.abspath(script_name)

    # 2. 构建任务字符串
    # 格式：m h * * w cd /path/to/dir && TASK a.py >> /dev/null
    cmd = f"TASK {script_name} >> /dev/null"
    new_job = f"{minute:2s} {hour:2s}  *  * {weekday:2s} {cmd}"

    try:
        # 3. 读取现有的 crontab 任务
        # 如果当前用户没有 crontab，此命令可能报错，所以捕获异常
        current_cron = subprocess.check_output(
            "crontab -l", shell=True, stderr=subprocess.STDOUT
        ).decode()
    except subprocess.CalledProcessError:
        raise Exception("当前用户没有 crontab")

    # 4. 检查是否已经存在该任务（避免重复）
    cron_lines = current_cron.splitlines()
    same_cmd = [line for line in cron_lines if cmd in line]
    if len(same_cmd) > 0:
        print("任务已存在 \n{}".format("\n".join(same_cmd)))
        user_input = input("是否继续添加 (输入 y 继续，其他键退出): ").strip().lower()
        if user_input != "y":
            print("已退出")
            return

    # 5. 添加新任务并写回
    cron_lines.append(new_job)
    new_cron_content = "\n".join(cron_lines) + "\n"

    # 使用 echo 将新内容喂给 crontab 命令
    process = subprocess.Popen(
        ["crontab", "-"],
        stdin=subprocess.PIPE,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
    )
    stdout, stderr = process.communicate(input=new_cron_content)

    if process.returncode == 0:
        print(f"成功添加定时任务:\n{new_job}")
    else:
        print(f"添加失败: {stderr}")


def add_cront():
    parser = argparse.ArgumentParser(description="将脚本加入 crontab 定时任务")
    parser.add_argument("-f", "--file", required=True, help="脚本文件名")
    parser.add_argument("-H", "--hour", help="小时 (0-23)", default="0")
    parser.add_argument("-m", "--minute", help="分钟 (0-59)", default="0")
    parser.add_argument("-w", "--weekday", help="周次 (0-6, 0是周日)", default="*")
    args = parser.parse_args()
    manage_crontab(args.file, args.hour, args.minute, args.weekday)
