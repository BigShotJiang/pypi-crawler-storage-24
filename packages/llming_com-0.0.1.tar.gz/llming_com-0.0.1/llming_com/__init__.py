"""Shared communication infrastructure — WebSocket transport, sessions, auth"""

__version__ = "0.0.1"
