# llming-com

Shared communication infrastructure — WebSocket transport, sessions, auth

> This is a placeholder release. The full package is coming soon.
