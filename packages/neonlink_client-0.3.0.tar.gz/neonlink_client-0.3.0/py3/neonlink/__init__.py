"""NeonLink Kafka client library for Python services.

Thin wrapper around confluent-kafka-python providing:
- Producer with circuit breaker, error classification, and payload validation
- TransactionalProducer for atomic multi-topic writes
- Consumer with manual offset commit, failure tracking, and panic recovery
- DLQ routing with enriched forensics headers
- HealthChecker for broker readiness probes
- OpenTelemetry W3C trace context propagation via Kafka headers
- Error taxonomy (PermanentError, Classify, IsTransient, IsPermanent)
- Metrics interface with NoopMetrics default
- MockProducer and MockConsumer for testing
"""

from neonlink.config import Config, new_config_from_lookup, new_config_from_map
from neonlink.producer import Producer
from neonlink.transaction import TransactionalProducer
from neonlink.consumer import Consumer, MessageHandler, MessageHandlerWithCommit
from neonlink.health import HealthChecker
from neonlink.record import Record, Headers, encoded_record_size
from neonlink.dlq import route_to_dlq
from neonlink.poison import is_poison_pill, get_retry_count, increment_retry_count
from neonlink.tracing import inject_trace_context, extract_trace_context
from neonlink.errors import (
    ErrorClass,
    PermanentError,
    CircuitBreakerOpenError,
    PayloadTooLargeError,
    classify,
    is_transient,
    is_permanent,
)
from neonlink.metrics import Metrics, NoopMetrics
from neonlink.mock import MockProducer, MockConsumer
from neonlink.router import TopicRouter

__all__ = [
    "Config",
    "new_config_from_lookup",
    "new_config_from_map",
    "Producer",
    "TransactionalProducer",
    "Consumer",
    "MessageHandler",
    "MessageHandlerWithCommit",
    "HealthChecker",
    "Record",
    "Headers",
    "encoded_record_size",
    "route_to_dlq",
    "is_poison_pill",
    "get_retry_count",
    "increment_retry_count",
    "inject_trace_context",
    "extract_trace_context",
    "ErrorClass",
    "PermanentError",
    "CircuitBreakerOpenError",
    "PayloadTooLargeError",
    "classify",
    "is_transient",
    "is_permanent",
    "Metrics",
    "NoopMetrics",
    "MockProducer",
    "MockConsumer",
    "TopicRouter",
]
