"""Tests for neonlink.mock."""

import pytest

from neonlink.mock import MockConsumer, MockProducer
from neonlink.record import Record


class TestMockProducer:
    def test_publish(self):
        mp = MockProducer()
        mp.publish("test-topic", b"key", b"value", {"h": "v"})
        assert len(mp.records) == 1
        assert mp.records[0].topic == "test-topic"
        assert mp.records[0].headers["h"] == "v"

    def test_error_injection(self):
        mp = MockProducer()
        mp.errors["bad-topic"] = RuntimeError("injected")
        with pytest.raises(RuntimeError, match="injected"):
            mp.publish("bad-topic", None, None)
        assert len(mp.records) == 0

    def test_publish_record(self):
        mp = MockProducer()
        rec = Record(topic="t", key=b"k", value=b"v")
        mp.publish_record(rec)
        assert len(mp.records) == 1

    def test_publish_batch(self):
        mp = MockProducer()
        records = [
            Record(topic="t1", key=b"k1", value=b"v1"),
            Record(topic="t2", key=b"k2", value=b"v2"),
        ]
        mp.publish_batch(records)
        assert len(mp.records) == 2

    def test_reset(self):
        mp = MockProducer()
        mp.publish("t", None, None)
        mp.reset()
        assert len(mp.records) == 0
        assert len(mp.errors) == 0


class TestMockConsumer:
    def test_subscribe(self):
        records = [
            Record(topic="t1", value=b"v1"),
            Record(topic="t2", value=b"v2"),
        ]
        mc = MockConsumer(records)

        handled = []

        class Handler:
            def handle_message(self, record):
                handled.append(record)

        mc.subscribe(Handler())
        assert len(handled) == 2
        assert handled[0].topic == "t1"
        assert handled[1].topic == "t2"

    def test_subscribe_with_dlq_delegates_to_subscribe(self):
        """P-01: subscribe_with_dlq must delegate to subscribe (Liskov substitution)."""
        records = [Record(topic="t", value=b"v")]
        mc = MockConsumer(records)

        handled = []

        class Handler:
            def handle_message(self, record):
                handled.append(record)

        mc.subscribe_with_dlq(Handler(), dlq_producer=MockProducer())
        assert len(handled) == 1
        assert handled[0].topic == "t"
