//! # HORUS Core
//!
//! The core runtime system for the HORUS robotics framework.
//!
//! HORUS is a distributed real-time robotics system designed for high-performance
//! applications. This crate provides the fundamental building blocks:
//!
//! - **Nodes**: Independent computational units that process data
//! - **Communication**: Publisher-subscriber message passing between nodes
//! - **Memory**: High-performance shared memory and zero-copy messaging
//! - **Scheduling**: Real-time task scheduling and execution
//! - **Monitoring**: Cross-process system monitoring and diagnostics
//! - **Actions**: Long-running tasks with progress feedback and cancellation
//!
//! **Note:** This is an internal crate. Users should depend on `horus` and
//! import from `horus::prelude::*`.

// Public modules — accessible cross-crate but hidden from user docs.
// Users should go through `horus::prelude`, not import from `horus_core` directly.
#[doc(hidden)]
pub mod actions;
#[doc(hidden)]
pub mod communication;
#[doc(hidden)]
pub mod core;
#[doc(hidden)]
pub mod dlpack;
#[doc(hidden)]
pub mod error;
#[doc(hidden)]
pub mod memory;
#[doc(hidden)]
pub mod params;
#[doc(hidden)]
pub mod scheduling;
#[doc(hidden)]
pub mod services;
pub(crate) mod terminal;
#[doc(hidden)]
pub mod types;
pub(crate) mod utils;

// Test utilities — available under `test-utils` feature or in test builds
#[cfg(any(test, feature = "test-utils"))]
#[doc(hidden)]
pub mod testing;

// Crate-internal re-exports (used by `crate::HorusError` etc. within this crate,
// and by horus_py / macro-generated code cross-crate).
#[doc(hidden)]
pub use actions::{
    Action, ActionClientBuilder, ActionClientNode, ActionError, ActionServerBuilder,
    ActionServerNode, CancelResponse, ClientGoalHandle, GoalId, GoalOutcome, GoalPriority,
    GoalResponse, GoalStatus, PreemptionPolicy, ServerGoalHandle, SyncActionClient,
};
#[doc(hidden)]
pub use communication::{
    set_topic_debug, PodMessage, SendBlockingError, Topic, TOPIC_DEBUG_LOG_OFFSET,
};
#[doc(hidden)]
pub use core::{
    DeadlineMissPolicy, HealthStatus, LogSummary, Node, NodeMetrics, NodePresence, NodeState, Rate,
    RtStats, Stopwatch, TopicMetadata,
};
#[doc(hidden)]
pub use error::{
    retry_transient, CommunicationError, ConfigError, HorusContext, HorusError, HorusResult,
    MemoryError, NodeError, NotFoundError, ParseError, ResourceError, Result, RetryConfig,
    SerializationError, Severity, TimeoutError, TransformError, ValidationError,
};
#[doc(hidden)]
pub use params::RuntimeParams;
#[doc(hidden)]
pub use scheduling::Scheduler;
#[doc(hidden)]
pub use services::{
    AsyncServiceClient, Service, ServiceClient, ServiceError, ServiceRequest, ServiceResponse,
    ServiceResult, ServiceServer, ServiceServerBuilder,
};

// Re-export dependencies used by macro-generated code and horus_py
#[doc(hidden)]
pub use bytemuck;
#[doc(hidden)]
pub use paste;
#[doc(hidden)]
pub use serde_json;
#[doc(hidden)]
pub use serde_yaml;
