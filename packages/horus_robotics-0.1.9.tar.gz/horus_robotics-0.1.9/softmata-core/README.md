# softmata-core

Foundational robotics types and traits for the [SOFTMATA](https://github.com/softmata) ecosystem.

[![Crates.io](https://img.shields.io/crates/v/softmata-core.svg)](https://crates.io/crates/softmata-core)
[![License](https://img.shields.io/crates/l/softmata-core.svg)](LICENSE)

## What's inside

**Geometry** — Pose2D, Pose3D, Vector2/3, Quaternion, Transform2D/3D, Twist, Wrench, Accel, covariance wrappers. Backed by `nalgebra`.

**Sensor traits** — `ScanData`, `ImuData`, `OdometryData`, `JointData`, `ImageData`, `PointCloudData`, `DepthImageData`, `WrenchData`, `BatteryData`, `RangeData`, `TemperatureData`, `MagneticFieldData`, `GamepadData`. Write algorithms against traits, swap implementations freely.

**Point types** — `PointXYZ`, `PointXYZI`, `PointXYZRGB`, `PointXYZNormal`. `#[repr(C)]` for zero-copy interop.

**Time** — `Timestamp`, `Duration`, `Rate` with nanosecond precision.

## Quick start

```toml
[dependencies]
softmata-core = "0.1"
```

```rust
use softmata_core::prelude::*;

let pose = Pose2D::new(1.0, 2.0, 0.0);
let goal = Pose2D::new(5.0, 3.0, 1.57);
println!("distance: {:.2}m", pose.distance_to(&goal));

let rate = Rate::from_hz(30.0);
println!("period: {:.1}ms", rate.period_secs() * 1000.0);
```

## `no_std` support

Disable the default `std` feature for embedded / bare-metal targets:

```toml
[dependencies]
softmata-core = { version = "0.1", default-features = false }
```

All types derive `Serialize`/`Deserialize` via serde (also `no_std` compatible).

## License

Apache-2.0
