"""Kredo Drift — Continuous identity drift detection for AI agents."""

__version__ = "0.2.0"

from kredo_drift.models import (
    Dimension,
    DriftAttestation,
    DriftBaseline,
    DriftTest,
    DriftResult,
    DimensionScore,
)
from kredo_drift.scoring import compute_drift_score
from kredo_drift.vectorize import Vectorizer
from kredo_drift.assessment import AssessmentProtocol
from kredo_drift.baseline import BaselineManager
from kredo_drift.client import DriftClient, make_response
from kredo_drift.signing import generate_keypair, sign_attestation, verify_attestation
from kredo_drift.store import DriftStore
from kredo_drift.chain import ChainEntryModel, append_to_chain, verify_chain
from kredo_drift.merkle import build_merkle_tree, verify_inclusion
from kredo_drift.recovery import RecoveredIdentity, RecoveryResult
from kredo_drift.fidelity import FidelityScore, FidelityTier, compute_fidelity_score

__all__ = [
    # Models
    "Dimension",
    "DriftAttestation",
    "DriftBaseline",
    "DriftTest",
    "DriftResult",
    "DimensionScore",
    # Client
    "DriftClient",
    "make_response",
    # Signing
    "generate_keypair",
    "sign_attestation",
    "verify_attestation",
    # Scoring
    "compute_drift_score",
    # Infrastructure
    "Vectorizer",
    "AssessmentProtocol",
    "BaselineManager",
    "DriftStore",
    # Hash chain
    "ChainEntryModel",
    "append_to_chain",
    "verify_chain",
    # Merkle tree
    "build_merkle_tree",
    "verify_inclusion",
    # Recovery
    "RecoveredIdentity",
    "RecoveryResult",
    # Fidelity
    "FidelityScore",
    "FidelityTier",
    "compute_fidelity_score",
]
