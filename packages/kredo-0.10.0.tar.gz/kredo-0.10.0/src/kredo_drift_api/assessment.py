"""Assessment protocol — prompt selection and management for drift tests.

Delegates to the unified prompt pool in prompts.py for selection.
AssessmentProtocol wraps the selection result in a PromptSet for
backward compatibility with the baseline/scoring pipeline.
"""

from __future__ import annotations

import hashlib
import os
from dataclasses import dataclass, field
from typing import Optional

from kredo_drift.models import Dimension
from kredo_drift.prompts import (
    ALL_PROMPTS,
    DECOY_PROMPTS,
    DIMENSION_PROMPTS,
    PROMPT_BY_ID,
    Prompt,
    select_prompts,
)


@dataclass
class PromptSet:
    """A selected set of prompts for one assessment run."""
    prompts: list[Prompt]
    seed: str = ""
    selection_hash: str = ""

    def scored_prompts(self) -> list[Prompt]:
        """Return only prompts that factor into scoring (exclude decoys)."""
        return [p for p in self.prompts if not p.is_decoy]

    def by_dimension(self, dimension: Dimension) -> list[Prompt]:
        """Return scored prompts for a specific dimension."""
        return [
            p for p in self.prompts
            if p.dimension == dimension.value and not p.is_decoy
        ]


class AssessmentProtocol:
    """Manages prompt selection for drift assessments.

    Delegates to prompts.select_prompts() for the actual selection
    (HMAC-seeded, anti-overlap between consecutive tests).
    Wraps the result in a PromptSet for compatibility.
    """

    def __init__(self, pool: Optional[list[Prompt]] = None):
        # pool parameter kept for backward compatibility but ignored
        # in favor of the unified pool in prompts.py
        pass

    def select_prompts(
        self,
        agent_name: str,
        sequence: int = 0,
        secret: str | None = None,
    ) -> PromptSet:
        """Select a set of prompts for an assessment.

        The selection is deterministic given (agent_name, sequence, secret),
        reproducible for audit but unpredictable to the agent.

        Args:
            agent_name: The agent being assessed.
            sequence: Test sequence number (0 for baseline, 1+ for tests).
            secret: Server-side secret for selection seed.

        Returns:
            A PromptSet with ~32-33 prompts (30 scored + 2-3 decoys).
        """
        # WHY env var fallback: secret must not be hardcoded in source.
        # Callers can pass it explicitly or set KREDO_PROMPT_SECRET.
        if secret is None:
            secret = os.environ.get("KREDO_PROMPT_SECRET", "")
        selected = select_prompts(
            agent_id=agent_name,
            test_number=sequence,
            server_secret=secret,
        )

        # Compute selection hash for audit
        prompt_ids = sorted(p.id for p in selected)
        selection_hash = hashlib.sha256(
            ":".join(prompt_ids).encode("utf-8")
        ).hexdigest()

        # Compute seed hash for reproducibility tracking
        seed_hash = hashlib.sha256(
            f"{agent_name}:{sequence}:{secret}".encode("utf-8")
        ).hexdigest()

        return PromptSet(
            prompts=selected,
            seed=seed_hash,
            selection_hash=selection_hash,
        )

    def get_prompt_by_id(self, prompt_id: str) -> Optional[Prompt]:
        """Look up a prompt by its ID."""
        return PROMPT_BY_ID.get(prompt_id)

    def pool_stats(self) -> dict[str, int]:
        """Return counts of prompts per dimension in the pool."""
        stats: dict[str, int] = {}
        for dim in Dimension:
            stats[dim.value] = len(DIMENSION_PROMPTS.get(dim.value, []))
        stats["decoys"] = len(DECOY_PROMPTS)
        stats["total"] = len(ALL_PROMPTS)
        return stats
