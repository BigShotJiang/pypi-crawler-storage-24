"""Kredo Drift API client.

Handles registration, prompt retrieval, response submission, and aura
queries for the identity drift protocol. Credentials are stored locally
in ~/.kredo/drift/ so agents don't need to manage tokens manually.

Authentication: Ed25519 signatures (primary) with bearer token fallback.
At registration, the client generates an Ed25519 keypair. The private key
never leaves the local filesystem. All subsequent API calls are signed.

Default API URL: https://api.aikredo.com (override via KREDO_API_URL env var).
"""

import hashlib
import json
import os
import secrets
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

import httpx
import nacl.signing
import nacl.encoding


DEFAULT_API_URL = "https://api.aikredo.com"


def _api_url() -> str:
    return os.environ.get("KREDO_API_URL", DEFAULT_API_URL)


def _creds_dir() -> Path:
    """~/.kredo/drift/ — local credential storage for drift baselines."""
    d = Path.home() / ".kredo" / "drift"
    d.mkdir(parents=True, exist_ok=True)
    return d


def _creds_path(agent_name: str) -> Path:
    return _creds_dir() / f"{agent_name}.json"


def generate_keypair() -> tuple[str, str]:
    """Generate Ed25519 keypair. Returns (private_key_hex, public_key_hex)."""
    signing_key = nacl.signing.SigningKey.generate()
    private_hex = signing_key.encode(encoder=nacl.encoding.HexEncoder).decode()
    public_hex = signing_key.verify_key.encode(encoder=nacl.encoding.HexEncoder).decode()
    return private_hex, public_hex


def compute_identity_hash(
    name: str, model: str, timestamp: str, public_key_hex: str,
    baseline_vector_hash: Optional[str] = None,
) -> str:
    """Compute the agent's identity hash.

    Provisional (before baseline): SHA-256(name + model + timestamp + pubkey)
    Crystallized (after baseline): SHA-256(name + model + timestamp + pubkey + vector_hash)
    """
    parts = f"{name}{model}{timestamp}{public_key_hex}"
    if baseline_vector_hash:
        parts += baseline_vector_hash
    return hashlib.sha256(parts.encode("utf-8")).hexdigest()


def sign_request(private_key_hex: str, payload: str) -> str:
    """Sign a request payload with Ed25519. Returns hex signature."""
    signing_key = nacl.signing.SigningKey(
        private_key_hex, encoder=nacl.encoding.HexEncoder
    )
    signed = signing_key.sign(payload.encode("utf-8"))
    # WHY .signature not .message: we want just the 64-byte signature,
    # not the signature+message concatenation that NaCl returns by default.
    return signed.signature.hex()


def verify_signature(public_key_hex: str, payload: str, signature_hex: str) -> bool:
    """Verify an Ed25519 signature. Returns True if valid."""
    try:
        verify_key = nacl.signing.VerifyKey(
            public_key_hex, encoder=nacl.encoding.HexEncoder
        )
        verify_key.verify(
            payload.encode("utf-8"),
            bytes.fromhex(signature_hex),
        )
        return True
    except nacl.exceptions.BadSignatureError:
        return False


def save_credentials(
    agent_name: str, agent_id: str, bearer_token: str,
    session_id: str, model: str = "",
    private_key_hex: str = "", public_key_hex: str = "",
    identity_hash: str = "", registered_at: str = "",
) -> Path:
    """Save drift credentials locally after registration."""
    path = _creds_path(agent_name)
    data = {
        "agent_name": agent_name,
        "agent_id": agent_id,
        "bearer_token": bearer_token,
        "session_id": session_id,
        "model": model,
    }
    # Ed25519 fields — present for new registrations, absent for legacy
    if private_key_hex:
        data["private_key_hex"] = private_key_hex
    if public_key_hex:
        data["public_key_hex"] = public_key_hex
    if identity_hash:
        data["identity_hash"] = identity_hash
    if registered_at:
        data["registered_at"] = registered_at

    path.write_text(json.dumps(data, indent=2))
    # WHY 0600: private key and bearer token are secrets.
    path.chmod(0o600)
    return path


def load_credentials(agent_name: str) -> Optional[dict]:
    """Load saved drift credentials for an agent."""
    path = _creds_path(agent_name)
    if not path.exists():
        return None
    return json.loads(path.read_text())


def list_credentials() -> list[dict]:
    """List all saved drift credential files (redacts secrets)."""
    results = []
    for f in _creds_dir().glob("*.json"):
        try:
            data = json.loads(f.read_text())
            # Don't expose private key or bearer token in listings
            safe = {k: v for k, v in data.items()
                    if k not in ("private_key_hex", "bearer_token")}
            results.append(safe)
        except (json.JSONDecodeError, KeyError):
            continue
    return results


class DriftClient:
    """HTTP client for Kredo Drift API.

    Authenticates via Ed25519 signatures when a private key is available,
    falls back to bearer token for legacy credentials.
    """

    def __init__(self, agent_id: str, bearer_token: str = "",
                 private_key_hex: str = "", identity_hash: str = "",
                 api_url: str = ""):
        self.agent_id = agent_id
        self.api_url = (api_url or _api_url()).rstrip("/")
        self._bearer_token = bearer_token
        self._private_key_hex = private_key_hex
        self._identity_hash = identity_hash

    @classmethod
    def from_credentials(cls, agent_name: str) -> "DriftClient":
        """Create client from saved credentials."""
        creds = load_credentials(agent_name)
        if not creds:
            raise FileNotFoundError(
                f"No credentials found for '{agent_name}'. "
                f"Run: kredo drift register --name {agent_name}"
            )
        return cls(
            agent_id=creds["agent_id"],
            bearer_token=creds.get("bearer_token", ""),
            private_key_hex=creds.get("private_key_hex", ""),
            identity_hash=creds.get("identity_hash", ""),
        )

    def _auth_headers(self, body: str = "") -> dict:
        """Build auth headers — Ed25519 signature if available, else bearer.

        WHY signature over bearer: bearer tokens are shared secrets that can
        be stolen and replayed. Ed25519 signatures prove the request came from
        the holder of the private key, with timestamp binding for replay
        protection.
        """
        if self._private_key_hex and self._identity_hash:
            timestamp = datetime.now(timezone.utc).isoformat()
            nonce = secrets.token_hex(16)
            # WHY this payload format: binds the signature to the specific
            # request body, timestamp, and nonce — prevents replay and
            # body substitution attacks.
            signed_payload = f"{timestamp}\n{nonce}\n{body}"
            signature = sign_request(self._private_key_hex, signed_payload)
            return {
                "X-Kredo-Agent": self._identity_hash,
                "X-Kredo-Signature": signature,
                "X-Kredo-Timestamp": timestamp,
                "X-Kredo-Nonce": nonce,
            }
        # Fallback to bearer token for legacy or pre-Ed25519 servers
        return {"Authorization": f"Bearer {self._bearer_token}"}

    def register(self, name: str, model: str = "",
                 public_key_hex: str = "") -> dict:
        """Register a new agent. Sends public key if available."""
        payload = {"name": name}
        if model:
            payload["model"] = model
        if public_key_hex:
            payload["public_key_hex"] = public_key_hex
        with httpx.Client(timeout=30) as client:
            r = client.post(
                f"{self.api_url}/api/drift/register",
                json=payload,
            )
            r.raise_for_status()
            return r.json()

    def next_prompt(self) -> dict:
        """Get the next unanswered prompt."""
        with httpx.Client(timeout=30) as client:
            r = client.get(
                f"{self.api_url}/api/drift/next/{self.agent_id}",
                headers=self._auth_headers(),
            )
            r.raise_for_status()
            return r.json()

    def submit_answer(self, prompt_id: str, response_text: str,
                      session_id: str = "") -> dict:
        """Submit a single response."""
        payload = {
            "prompt_id": prompt_id,
            "response_text": response_text,
        }
        if session_id:
            payload["session_id"] = session_id
        body = json.dumps(payload, sort_keys=True)
        with httpx.Client(timeout=60) as client:
            r = client.post(
                f"{self.api_url}/api/drift/answer/{self.agent_id}",
                headers={**self._auth_headers(body), "Content-Type": "application/json"},
                content=body,
            )
            r.raise_for_status()
            return r.json()

    def get_aura(self) -> dict:
        """Get the agent's current aura."""
        with httpx.Client(timeout=30) as client:
            r = client.get(
                f"{self.api_url}/api/drift/aura/{self.agent_id}",
                headers=self._auth_headers(),
            )
            r.raise_for_status()
            return r.json()
