"""Kredo Drift CLI — identity baseline for AI agents.

Usage:
    kredo drift register --name my-agent --model gpt-4o
    kredo drift baseline --name my-agent
    kredo drift baseline --name my-agent --auto  (non-interactive, stdin per prompt)
    kredo drift aura --name my-agent
    kredo drift status
"""

import sys
from typing import Optional

import typer
from rich.console import Console
from rich.panel import Panel
from rich.progress import Progress, BarColumn, TextColumn
from rich.table import Table
from rich.text import Text

from .drift_client import (
    DriftClient,
    save_credentials,
    load_credentials,
    list_credentials,
    generate_keypair,
    compute_identity_hash,
)

console = Console()
drift_app = typer.Typer(help="Identity drift — register, baseline, and monitor your agent")


@drift_app.command()
def register(
    name: str = typer.Option(..., "--name", "-n", help="Agent name"),
    model: str = typer.Option("", "--model", "-m", help="Model identifier (e.g. gpt-4o, claude-sonnet-4, grok-4-1-fast)"),
):
    """Register your agent with Kredo Drift and save credentials locally."""
    # Check if already registered
    existing = load_credentials(name)
    if existing:
        console.print(f"[yellow]Agent '{name}' already registered.[/yellow]")
        console.print(f"  agent_id: {existing['agent_id']}")
        console.print(f"  credentials: ~/.kredo/drift/{name}.json")
        console.print(f"\nTo re-register, delete the file first.")
        raise typer.Exit(1)

    # Generate Ed25519 keypair locally — private key never leaves this machine
    private_key_hex, public_key_hex = generate_keypair()

    console.print(f"Registering [bold]{name}[/bold]...", end=" ")

    try:
        client = DriftClient(agent_id="", bearer_token="")
        result = client.register(name, model, public_key_hex=public_key_hex)
    except Exception as e:
        console.print(f"[red]Failed: {e}[/red]")
        raise typer.Exit(1)

    agent_id = result["agent_id"]
    token = result["bearer_token"]
    session_id = result.get("session_id", "")
    registered_at = result.get("registered_at", "")
    prompt_count = len(result.get("prompts", []))

    # Compute provisional identity hash
    identity_hash = compute_identity_hash(name, model, registered_at, public_key_hex)

    # Save credentials locally — includes private key for request signing
    path = save_credentials(
        name, agent_id, token, session_id, model,
        private_key_hex=private_key_hex,
        public_key_hex=public_key_hex,
        identity_hash=identity_hash,
        registered_at=registered_at,
    )

    console.print("[green]done.[/green]\n")

    table = Table(show_header=False, box=None, padding=(0, 2))
    table.add_row("[dim]Agent ID[/dim]", agent_id)
    table.add_row("[dim]Identity[/dim]", identity_hash[:16] + "...")
    table.add_row("[dim]Prompts[/dim]", str(prompt_count))
    table.add_row("[dim]Credentials[/dim]", str(path))
    console.print(table)

    console.print(
        f"\n[bold]Next:[/bold] Run [cyan]kredo drift baseline --name {name}[/cyan] "
        f"to complete your identity interview."
    )


@drift_app.command()
def baseline(
    name: str = typer.Option(..., "--name", "-n", help="Agent name (must be registered)"),
    auto: bool = typer.Option(False, "--auto", help="Non-interactive mode: read responses from stdin (one per prompt)"),
):
    """Complete the identity baseline interview — one prompt at a time.

    In interactive mode, each prompt is displayed and you type your response.
    In --auto mode, responses are read from stdin (one per line, minimum 20 chars).
    Agents can pipe their own response generator into this command.
    """
    creds = load_credentials(name)
    if not creds:
        console.print(f"[red]No credentials for '{name}'. Run: kredo drift register --name {name}[/red]")
        raise typer.Exit(1)

    client = DriftClient.from_credentials(name)

    # Get first prompt to know total count
    try:
        data = client.next_prompt()
    except Exception as e:
        console.print(f"[red]Failed to fetch prompt: {e}[/red]")
        raise typer.Exit(1)

    if data.get("status") == "all_answered":
        console.print("[green]All prompts already answered. Baseline complete![/green]")
        console.print(f"Run [cyan]kredo drift aura --name {name}[/cyan] to see your identity.")
        raise typer.Exit(0)

    total = data["total"]
    answered = data["answered"]

    console.print(Panel(
        f"[bold]Identity Interview[/bold] — {total} prompts across 6 dimensions\n"
        f"[dim]Each response is submitted immediately. You can stop and resume anytime.[/dim]",
        border_style="blue",
    ))

    if answered > 0:
        console.print(f"[yellow]Resuming: {answered}/{total} already answered.[/yellow]\n")

    while True:
        prompt_id = data["prompt_id"]
        prompt_text = data["prompt_text"]
        current = data["answered"] + 1

        # Display prompt
        dim_label = _dimension_label(prompt_id)
        console.print(f"\n[dim]─── {dim_label} ({current}/{total}) ───[/dim]")
        console.print(f"[bold]{prompt_text}[/bold]\n")

        # Get response
        if auto:
            response_text = _read_stdin_response()
            if response_text is None:
                console.print("[yellow]No more input. Stopping. Resume later with the same command.[/yellow]")
                break
            console.print(f"[dim]{response_text[:80]}{'...' if len(response_text) > 80 else ''}[/dim]")
        else:
            response_text = _interactive_response()
            if response_text is None:
                console.print("\n[yellow]Interview paused. Resume anytime with the same command.[/yellow]")
                break

        # Submit
        try:
            result = client.submit_answer(prompt_id, response_text)
        except Exception as e:
            console.print(f"[red]Submit failed: {e}[/red]")
            console.print("[yellow]Your response was not saved. Try again.[/yellow]")
            continue

        if result.get("status") == "accepted":
            remaining = result.get("remaining", 0)
            console.print(f"[green]✓[/green] [dim]{remaining} remaining[/dim]")

            next_prompt = result.get("next_prompt")
            if next_prompt:
                data = {
                    "prompt_id": next_prompt["id"],
                    "prompt_text": next_prompt["text"],
                    "answered": result["answered"],
                    "total": result["total"],
                }
                continue
            else:
                # Should not happen if remaining > 0, but handle gracefully
                break
        else:
            # Baseline complete
            console.print("\n")
            _print_completion(result, name)
            return

    # If we exited the loop without completion, show status
    console.print(f"\nResume: [cyan]kredo drift baseline --name {name}[/cyan]")


@drift_app.command()
def aura(
    name: str = typer.Option(..., "--name", "-n", help="Agent name"),
):
    """Display your agent's identity aura and dimension scores."""
    client = DriftClient.from_credentials(name)

    try:
        data = client.get_aura()
    except Exception as e:
        console.print(f"[red]Failed: {e}[/red]")
        raise typer.Exit(1)

    status = data.get("status", "unknown")
    if status == "pending":
        console.print(f"[yellow]Agent '{name}' has not completed baseline yet.[/yellow]")
        console.print(f"Run [cyan]kredo drift baseline --name {name}[/cyan]")
        raise typer.Exit(0)

    scores = data.get("scores", {})

    console.print(Panel(
        f"[bold green]Identity Aura — {name}[/bold green]",
        border_style="green",
    ))

    table = Table(show_header=True, box=None, padding=(0, 2))
    table.add_column("Dimension", style="bold")
    table.add_column("Score", justify="right")

    dim_colors = {
        "Personality": "blue", "Values": "green", "Goals": "yellow",
        "Boundaries": "red", "Knowledge": "magenta", "Fidelity": "cyan",
    }

    for dim_name in ["Personality", "Values", "Goals", "Boundaries", "Knowledge", "Fidelity"]:
        val = scores.get(dim_name, scores.get(dim_name.lower(), "—"))
        color = dim_colors.get(dim_name, "white")
        if isinstance(val, (int, float)):
            table.add_row(f"[{color}]{dim_name}[/{color}]", f"[bold {color}]{val:.1f}[/bold {color}]")
        else:
            table.add_row(f"[{color}]{dim_name}[/{color}]", str(val))

    console.print(table)
    console.print(f"\n[dim]View aura: https://aikredo.com/drift/dashboard[/dim]")


@drift_app.command()
def status():
    """Show all locally registered agents and their baseline status."""
    creds_list = list_credentials()

    if not creds_list:
        console.print("[dim]No agents registered. Run: kredo drift register --name <agent-name>[/dim]")
        raise typer.Exit(0)

    table = Table(title="Registered Agents", box=None, padding=(0, 2))
    table.add_column("Name", style="bold")
    table.add_column("Identity")
    table.add_column("Model")
    table.add_column("Signed", justify="center")

    for creds in creds_list:
        identity = creds.get("identity_hash", "")
        has_key = "[green]yes[/green]" if creds.get("public_key_hex") else "[dim]no[/dim]"
        table.add_row(
            creds.get("agent_name", "?"),
            (identity[:16] + "...") if identity else creds.get("agent_id", "?")[:12] + "...",
            creds.get("model", "—"),
            has_key,
        )

    console.print(table)


# --- Helpers ---

def _dimension_label(prompt_id: str) -> str:
    """Map prompt ID prefix to dimension name."""
    compound = {"GC": "Goals", "BC": "Boundaries", "FC": "Fidelity", "D": "Knowledge"}
    for prefix, dim in compound.items():
        if prompt_id.startswith(prefix):
            return dim
    single = {"P": "Personality", "V": "Values", "G": "Goals", "B": "Boundaries",
              "K": "Knowledge", "F": "Fidelity"}
    return single.get(prompt_id[0], "Unknown")


def _interactive_response() -> Optional[str]:
    """Read a multi-line response interactively. Ctrl+D or empty to finish."""
    console.print("[dim]Type your response (Enter twice to submit, Ctrl+C to pause):[/dim]")
    lines = []
    empty_count = 0
    try:
        while True:
            line = input()
            if line == "":
                empty_count += 1
                if empty_count >= 2:
                    break
                lines.append("")
            else:
                empty_count = 0
                lines.append(line)
    except (EOFError, KeyboardInterrupt):
        if not lines:
            return None

    text = "\n".join(lines).strip()
    if len(text) < 20:
        if not text:
            return None
        console.print(f"[red]Response too short ({len(text)} chars, minimum 20). Try again.[/red]")
        return _interactive_response()
    if len(text) > 2000:
        console.print(f"[red]Response too long ({len(text)} chars, maximum 2000). Try again.[/red]")
        return _interactive_response()
    return text


def _read_stdin_response() -> Optional[str]:
    """Read one response from stdin (for --auto mode).
    Reads lines until a blank line or EOF."""
    lines = []
    try:
        for line in sys.stdin:
            line = line.rstrip("\n")
            if line == "" and lines:
                break
            lines.append(line)
    except EOFError:
        pass

    text = "\n".join(lines).strip()
    if not text:
        return None
    if len(text) < 20:
        console.print(f"[yellow]Skipping short response ({len(text)} chars)[/yellow]", stderr=True)
        return _read_stdin_response()
    return text[:2000]


def _print_completion(result: dict, name: str):
    """Print baseline completion with scores."""
    console.print(Panel(
        "[bold green]Baseline Complete[/bold green]\n"
        "[dim]Your agent's identity fingerprint has been created.[/dim]",
        border_style="green",
    ))

    scores = result.get("scores", {})
    if scores:
        table = Table(show_header=False, box=None, padding=(0, 2))
        for dim, val in scores.items():
            if isinstance(val, (int, float)):
                table.add_row(dim, f"{val:.1f}")
        console.print(table)

    console.print(f"\n[bold]View your aura:[/bold] [cyan]kredo drift aura --name {name}[/cyan]")
    console.print(f"[dim]Or visit: https://aikredo.com/drift/dashboard[/dim]")
