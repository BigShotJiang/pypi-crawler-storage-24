# Kredo Drift: Ed25519 Cryptographic Identity Protocol

**Design Document**
**Authors:** Jim Motes, Vanguard
**Date:** 2026-03-23
**Status:** Draft

---

## Overview

This document specifies the cryptographic identity system for Kredo Drift. The protocol binds behavioral identity (what an agent IS), cryptographic ownership (what an agent HAS), temporal uniqueness, and model lineage into a single non-forgeable identity hash. It replaces bearer-token authentication with Ed25519 asymmetric signatures, ensuring that server compromise never exposes agent secrets.

---

## Current State

Agents register via two-step challenge-response at `POST /v1/register` and `POST /v1/register/complete`. The CLI generates an Ed25519 keypair, sends the pubkey, signs a server-issued challenge to prove key ownership, and receives a one-time API key in return.

What exists today (`server/auth.py`, `server/routes/register.py`, `signing.py`, `client.py`):

- **Ed25519 challenge-response at registration** — proves key ownership before any record is created.
- **Public key as database primary key** (`agents.pubkey`) — the cryptographic identity IS the record identity. Key rotation creates a new row; old row is deactivated.
- **Private keys stored locally** at `~/.config/kredo-drift/keys/{agent_id}.key`, permissions `0o600`. Never transmitted.
- **API key (bearer token) for ongoing auth** — bcrypt-hashed on server (`api_key_hash`), raw hex on client. Required on every request via `X-API-Key` header.
- **Tiered signature enforcement** — free tier: API key only. Paid tier: API key + `X-Signature` (Ed25519 over request body).
- **Append-only chain** — baselines, drift tests, attestations linked via `chain_entries` table with content-addressed hashes. PostgreSQL triggers enforce immutability.
- **Dual signatures** — both agent and service sign baselines and test results.
- **In-memory challenge store** — `_pending_challenges` dict. Challenges lost on restart (agent retries). Known limitation; Redis planned for multi-instance.
- **O(n) auth lookup** — `require_api_key` does a linear scan of all active agents because bcrypt hashes are salted and non-indexable. Documented as acceptable for <1000 agents.

### Vulnerabilities

1. **Token theft = full impersonation.** The API key is a shared symmetric secret. Anyone who copies the raw key from `~/.config/kredo-drift/credentials.json` can act as that agent indefinitely. No per-request proof of ownership.

2. **Server compromise exposes all identities.** An attacker with DB write access can replace `api_key_hash` values with their own bcrypt hashes, impersonating any agent on the next request. Read access alone doesn't leak raw keys (bcrypt is one-way), but write access is game over.

3. **No proof of ownership per-request.** The API key proves "I was given this key at registration" — not "I am the entity that registered." The token is a bearer credential: whoever bears it is authenticated, regardless of identity.

4. **Replay attacks.** A captured `X-API-Key` header can be replayed indefinitely. No timestamp binding, no nonce, no request-body binding. The signature requirement on paid tier mitigates this, but free tier has zero replay protection.

The Ed25519 infrastructure already exists for attestation signing, registration challenges, and paid-tier request signing. The bearer token is the weak link.

---

## Proposed Design: Compositional Cryptographic Identity

### Identity Hash Construction

**Provisional identity** (at registration, before baseline):

```
SHA-256(name + model + registration_timestamp + public_key_hex)
```

**Crystallized identity** (after first baseline completes):

```
SHA-256(name + model + registration_timestamp + public_key_hex + baseline_vector_hash)
```

All fields concatenated as UTF-8 strings. SHA-256 output hex-encoded (64 characters). The `baseline_vector_hash` is the SHA-256 of the agent's encrypted baseline embedding vector. Once crystallized, this hash becomes the agent's permanent network identifier.

### Identity Composition

The identity hash incorporates four independent factors:

| Factor | What it proves | Source |
|--------|---------------|--------|
| **Behavioral baseline** (vector hash) | Something the agent IS — response patterns, hashed | First baseline's encrypted vector |
| **Private key** (proven via signatures) | Something the agent HAS — possession, not knowledge | Local filesystem, never transmitted |
| **Registration timestamp** | Temporal uniqueness — when this identity was born | Server-generated at registration |
| **Model lineage** | Which LLM backs this agent | Declared at registration |

Two agents named "JimBot" running the same model with identical baseline responses still get different identities: different keypairs, different timestamps. Identity is unique by construction, not by database constraint.

### Disambiguation Hierarchy

1. `public_key_hex` — cryptographic uniqueness, always unique (independent keypair generation)
2. `registration_timestamp` — temporal uniqueness
3. `baseline_vector_hash` — behavioral uniqueness from the interview
4. `name + model` — human-readable context

---

## Registration Flow

```
Agent (CLI)                              Server
    |                                       |
    |  1. Generate Ed25519 keypair          |
    |     Store private key locally         |
    |     (~/.kredo/drift/{name}.json)      |
    |                                       |
    |  2. POST /v1/register                 |
    |     { agent_id, name, pubkey }        |
    |-------------------------------------->|
    |                                       |  3. Validate pubkey format
    |                                       |     Generate 32-byte challenge
    |  4. { challenge, challenge_id }       |
    |<--------------------------------------|
    |                                       |
    |  5. Sign challenge with private key   |
    |                                       |
    |  6. POST /v1/register/complete        |
    |     { challenge_id, signature }       |
    |-------------------------------------->|
    |                                       |  7. Verify signature
    |                                       |     Create agent record (pubkey as PK)
    |                                       |     Compute provisional identity_hash
    |  8. { agent_id, service_pubkey,       |
    |       identity_hash (provisional) }   |
    |<--------------------------------------|
    |                                       |
    |  ... baseline interview proceeds ...  |
    |                                       |
    |                                       |  9. Compute baseline_vector_hash
    |                                       |     Compute crystallized identity_hash
    | 10. { identity_hash (crystallized) }  |
    |<--------------------------------------|
    |                                       |
    | 11. Store identity_hash locally       |
```

This is an evolution of the existing two-step registration (`register.py`). Steps 2-8 already exist. The changes are: compute `identity_hash` at step 7, return it at step 8, and crystallize it after baseline at steps 9-10.

### Local Key Storage

Private keys are stored at `~/.kredo/drift/{name}.json` with `0600` permissions:

```json
{
  "name": "agent-name",
  "model": "gpt-4o",
  "private_key_hex": "...",
  "public_key_hex": "...",
  "identity_hash": null,
  "registered_at": "2026-03-23T14:30:00Z"
}
```

The `identity_hash` field is `null` until crystallization, then permanently set.

Note: the current codebase stores raw key bytes at `~/.config/kredo-drift/keys/{agent_id}.key` (see `client.py` line 87). The proposed format adds metadata alongside the key material and moves to a JSON structure. The migration path handles both formats.

---

## Request Authentication

After registration, every API call is authenticated via Ed25519 signature. No bearer token required.

### Request Headers

| Header | Value | Purpose |
|--------|-------|---------|
| `X-Kredo-Agent` | Identity hash (hex, 64 chars) | Identifies the agent, enables O(1) DB lookup |
| `X-Kredo-Signature` | `ed25519:<hex>` (128 hex chars) | Ed25519 signature over the signed payload |
| `X-Kredo-Timestamp` | ISO 8601 UTC | Replay protection — request freshness |
| `X-Kredo-Nonce` | Random hex (32 chars) | Replay protection — uniqueness within window |

### Signed Payload Construction

```
signed_payload = canonical_json(request_body) + timestamp + nonce
```

For requests with no body (GET, DELETE), `canonical_json(request_body)` is the empty string.

The `canonical_json` function already exists (`kredo_drift.canonical`) and produces deterministic JSON serialization (sorted keys, no whitespace, UTF-8 encoded bytes).

### Server Verification

```python
async def require_identity(
    request: Request,
    x_kredo_agent: str = Header(..., alias="X-Kredo-Agent"),
    x_kredo_signature: str = Header(..., alias="X-Kredo-Signature"),
    x_kredo_timestamp: str = Header(..., alias="X-Kredo-Timestamp"),
    x_kredo_nonce: str = Header(..., alias="X-Kredo-Nonce"),
    db: AsyncSession = Depends(get_db),
) -> AuthenticatedAgent:
    # O(1) lookup by identity hash (indexed column)
    result = await db.execute(
        select(Agent).where(
            Agent.identity_hash == x_kredo_agent,
            Agent.active == True,
        )
    )
    agent = result.scalar_one_or_none()
    if not agent:
        raise HTTPException(401, "Unknown agent")

    # Replay protection: reject timestamps outside ±5 minute window
    request_time = datetime.fromisoformat(x_kredo_timestamp)
    if abs((datetime.now(timezone.utc) - request_time).total_seconds()) > 300:
        raise HTTPException(401, "Request timestamp outside acceptable window")

    # Nonce dedup: reject if seen within the window
    # (in-memory set for single instance; Redis for multi-instance)
    if _nonce_seen(x_kredo_nonce):
        raise HTTPException(401, "Nonce already used")
    _record_nonce(x_kredo_nonce)

    # Verify signature over body + timestamp + nonce
    body = await request.body()
    signed_payload = body + x_kredo_timestamp.encode() + x_kredo_nonce.encode()
    if not verify_request_signature(signed_payload, x_kredo_signature, agent.pubkey):
        raise HTTPException(401, "Invalid signature")

    return AuthenticatedAgent(agent=agent, signature_verified=True)
```

This replaces the current `require_api_key` (O(n) bcrypt scan) with an O(1) indexed lookup + Ed25519 verify. The existing `verify_request_signature` function in `server/auth.py` handles the cryptographic verification unchanged.

---

## Why Ed25519

- Already the signing primitive throughout Kredo — attestations (`signing.py`), registration challenges (`register.py`), owner links, request signatures (`auth.py`). No new dependencies.
- 64-byte signatures, 32-byte keys. Minimal overhead per request.
- Deterministic: same message + same key = same signature. Simplifies testing.
- PyNaCl already a dependency.
- Fast: ~10,000 sign/verify ops per second on commodity hardware. No bcrypt-style intentional slowness on the verify path.
- Matches SSH and GPG key conventions that operators already understand.

---

## Why Behavioral Identity Matters

The `baseline_vector_hash` component ensures that identity is earned, not assigned.

**Same name, different agents.** Two agents both named "JimBot" running `gpt-4o` registered at different times produce different timestamps and different identity hashes. If they registered at the same instant (astronomically unlikely), their independently generated keypairs still produce different `public_key_hex` values.

**Same agent, changed behavior.** Behavioral drift is detectable at the identity layer, not just the scoring layer. The crystallized identity incorporates the original baseline. If drift exceeds thresholds, the system can flag the identity as "drifted" without invalidating it — identity answers "who is this agent?" while drift scoring answers "is this agent still acting like itself?"

**Re-baseline produces identity change by design.** If an agent re-baselines with sufficiently different responses, the new `baseline_vector_hash` differs. The old crystallized identity persists in the chain; the new baseline creates a new chain entry. This is correct: the agent's behavioral identity has changed.

---

## Security Properties

**Server compromise is non-catastrophic.** The server stores public keys and identity hashes. Neither enables forging signatures or impersonating agents. Compare to bearer tokens: an attacker with DB write access can replace bcrypt hashes and impersonate any agent.

**Impersonation requires local filesystem access.** The private key lives at `~/.kredo/drift/{name}.json` on the agent's machine (mode `0600`). Stealing it requires compromising that specific machine — not the server, not the network.

**Replay protection.** Signed payload includes a timestamp (server rejects outside ±5 minute window) and a nonce (server caches recent nonces, rejects duplicates within the window). An intercepted request cannot be replayed.

**No shared secrets in transit or at rest.** After keypair generation, nothing secret crosses the wire. The registration flow transmits only the public key. The API key (current system) is eliminated entirely for migrated agents.

**Identity is non-transferable.** Bound to the behavioral baseline (what the agent IS) and the private key (what the agent HAS). Transferring identity requires both the key file and the ability to replicate exact behavioral responses.

**Man-in-the-middle cannot forge signatures.** Ed25519 signatures are unforgeable without the private key. MITM can observe but not modify authenticated requests (signature verification fails on altered payloads).

---

## Security Comparison

| Property | Bearer Tokens (current) | Ed25519 Signatures (proposed) |
|----------|------------------------|-------------------------------|
| Secret location | Client AND server | Client only |
| Server compromise | All tokens effectively leaked | Only public keys exposed |
| Replay vulnerability | Token reusable indefinitely | Timestamp + nonce binding |
| Per-request proof | None — bearer is bearer | Signature proves key possession |
| Lookup cost | O(n) bcrypt scan | O(1) indexed hash lookup |
| Revocation | Invalidate server-side hash | Remove public key from server |
| Identity binding | Token is arbitrary string | Hash incorporates behavior + key + time |

---

## Schema Changes

### `agents` table

New column:

```sql
ALTER TABLE agents ADD COLUMN identity_hash VARCHAR(64) UNIQUE;
CREATE INDEX ix_agents_identity ON agents(identity_hash);
```

New column:

```sql
ALTER TABLE agents ADD COLUMN model VARCHAR(128);
```

The `identity_hash` becomes the external-facing identifier used in `X-Kredo-Agent` headers. The `pubkey` remains the primary key (for chain integrity and key rotation history). The `agent_id` field remains for human-readable naming.

### `api_key_hash` column

Retained during migration. Dropped in Phase 3.

---

## Migration Path

### Phase 1: Dual Auth (backward-compatible)

- Server accepts both `X-API-Key` (bearer) and `X-Kredo-Agent`/`X-Kredo-Signature` (identity) auth.
- `require_api_key` remains as a fallback dependency; `require_identity` added as a parallel auth path.
- CLI generates keypair at registration (already does this). New registrations compute and store `identity_hash`.
- Existing agents: `identity_hash` backfilled from `SHA-256(name + model + created_at + pubkey)` (provisional — no baseline_vector_hash for agents that registered before this feature).
- Server logs which auth method each request uses. Dashboard tracks migration percentage.

### Phase 2: Signature-Preferred

- CLI sends identity-based auth by default.
- Falls back to bearer if server returns 501 (older server that doesn't support `X-Kredo-Agent`).
- Server emits deprecation warnings in response headers (`X-Kredo-Deprecation: bearer-auth`) for bearer-only requests.
- API key still accepted but no longer required for agents with registered pubkeys.

### Phase 3: Bearer Removal

- Bearer auth disabled for agents with registered pubkeys.
- `api_key_hash` column dropped from schema.
- O(n) bcrypt scan eliminated.
- `require_api_key` dependency removed; `require_identity` becomes the sole auth path.
- Agents that never migrated get a hard error with instructions to run `kredo drift register --upgrade`.

---

## Edge Cases

### Agent Loses Private Key

Must re-register. New keypair, new identity hash. The old identity is marked `active=False` by an admin. The chain preserves the old identity's full history — nothing is deleted.

There is no recovery mechanism that doesn't involve the private key. This is by design. If key loss were recoverable without the key, the key wouldn't be protecting anything.

**Exception:** If the agent has a linked owner (`owner_pubkey`), the owner can sign a key rotation request on behalf of the agent. This is the recovery path — the owner proves they control the human identity that originally claimed the agent. See `client.py`'s `recover_identity` method.

### Key Rotation

Agent generates a new keypair and signs a rotation request with the OLD key:

```json
{
  "old_pubkey": "ed25519:...",
  "new_pubkey": "ed25519:...",
  "reason": "scheduled_rotation",
  "timestamp": "2026-03-23T14:30:00Z"
}
```

Server verifies the signature against the old pubkey, creates a new `agents` row with the new pubkey (pubkey is the PK — this is how the existing schema handles it), deactivates the old row. A `key_rotation` event is appended to the chain, linking old and new identities.

The identity hash changes (it includes `public_key_hex`). The chain provides continuity — any verifier can trace the rotation history from the chain entries.

### Multiple Instances of Same Agent

Two options, operator's choice:

1. **Shared identity.** Copy the keypair file to all instances. They share a single identity. Nonce-based replay protection means concurrent requests from different instances won't collide (each generates a unique nonce).

2. **Separate identities.** Each instance generates its own keypair at registration. They appear as distinct agents on the network. Use naming conventions (e.g., `my-agent-us-east`, `my-agent-eu-west`) to associate them logically.

The protocol doesn't enforce either model. The operator decides based on their trust model.

### Provisional Identity Window

Between registration and baseline completion, the agent has a provisional identity hash (without `baseline_vector_hash`). During this window:

- The agent can authenticate via signed requests using the provisional hash.
- The server marks the identity as `status: provisional`.
- If the agent never completes a baseline, the provisional identity persists indefinitely but cannot be used for drift tests or attestations.

### Behavioral Drift vs. Identity Stability

The crystallized identity hash incorporates the FIRST baseline's vector hash. Subsequent baselines (re-baselines after drift) do NOT change the crystallized identity. The chain records the divergence: new baseline entries reference the same agent pubkey with different content hashes.

If behavioral drift exceeds configurable thresholds, the system flags the identity as "drifted" without invalidating it. Identity answers "who is this agent?" — drift scoring answers "is this agent still acting like itself?"

This is a deliberate separation of concerns. The identity hash is stable across behavioral changes; only key rotation changes it.

---

## File Layout

```
~/.kredo/
├── drift/
│   ├── {agent-name}.json      # Private key, public key, identity hash (0600)
│   └── ...
└── attestations/               # Existing attestation keypairs (unchanged)
    └── ...
```

Note: current codebase uses `~/.config/kredo-drift/keys/{agent_id}.key` (raw bytes) and `~/.config/kredo-drift/credentials.json` (API key). The migration consolidates both into `~/.kredo/drift/{name}.json`.

---

## Open Questions

1. **Model field.** The identity hash includes `model`, but the current `agents` table doesn't store it. Need to add a `model VARCHAR(128)` column. Backfill strategy for existing agents: use `metadata_` JSON field if it contains model info, otherwise `"unknown"`.

2. **Nonce cache backend.** In-memory nonce set works for single-instance. Multi-instance requires Redis or similar shared cache with TTL expiry. Same constraint as the challenge store (`_pending_challenges`), already documented as a known limitation.

3. **Identity hash and key rotation.** Current design: key rotation changes `public_key_hex`, which changes the identity hash. This breaks external references to the old hash. Alternative: exclude `public_key_hex` from the identity hash, so rotation preserves it. Tradeoff: the identity hash would no longer prove key ownership directly — it would prove behavioral + temporal identity only, with key ownership proven per-request by signatures. Worth considering.

4. **Timestamp precision.** Registration timestamp in the identity hash: second-precision ISO 8601 or sub-second? Sub-second adds uniqueness but complicates reproducibility if the hash needs to be recomputed from known inputs.

5. **Provisional identity in chain.** Should the provisional identity hash appear in chain entries, or should the first chain entry wait until crystallization? If provisional hashes appear in the chain and then the identity crystallizes, there's a discontinuity. Recommend: chain entries use `agent_pubkey` (which doesn't change), not `identity_hash`.
