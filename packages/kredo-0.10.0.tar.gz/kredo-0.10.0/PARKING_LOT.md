# Kredo — Parking Lot

*Improvement ideas, deferred work, and future features. Updated as needed.*
*Last updated: 2026-02-20*

---

## Documentation Consistency Sweep — COMPLETE (2026-02-20)

- [x] **README command accuracy** — corrected CLI examples to match current Typer interface (`kredo attest skill`, `kredo verify <file.json>`, identity/contact command set)
- [x] **Skill API guide alignment** — updated full CLI reference to current command names and arguments
- [x] **Taxonomy count correction** — docs now reflect the bundled taxonomy (8 domains / 50 bundled skills, with extensibility via custom taxonomy)
- [x] **Roadmap context refresh** — clarified that human-friendly roadmap content is historical implementation guidance
- [x] **Scope clarity update** — marked legacy MVP checklist as historical and pointed active status tracking to `PARKING_LOT.md`

---

## Web Governance GUI — COMPLETE (v0.8.1, 2026-02-20)

- [x] **New Governance tab in browser app** — single-screen UX for signed registration, ownership, integrity, and risk-signal workflows
- [x] **Ownership workflow simplification** — create/confirm/revoke claim forms with payload-safe signing flow and claim helpers
- [x] **Integrity workflow simplification** — owner baseline set, agent runtime check, and status read in one place (manifest parser included)
- [x] **Source anomaly review panel** — query and inspect `/risk/source-anomalies` clusters from UI
- [x] **Dashboard visibility upgrades** — accountability tier and integrity traffic-light surfaced directly on profile dashboard
- [x] **API client hardening** — resilient non-JSON/network error handling for better operator feedback

---

## Astro Hosting Integration — COMPLETE (v0.8.2, 2026-02-20)

- [x] **Public app hosting path** — web app now served via Astro static output at `/app/`
- [x] **Build pipeline sync** — `site` build now runs `sync:app` to mirror `../app` into `site/public/app`
- [x] **Site navigation updates** — top-level CTA and developer docs now point to `/app/`
- [x] **Site runbook update** — `site/README.md` documents sync/build/deploy flow for app hosting

---

## App Navigation Polish — COMPLETE (v0.8.3, 2026-02-20)

- [x] **Persistent return path** — added global `Back to Main Site` CTA in app header across all app views
- [x] **Live deployment update** — app navigation fix included in Astro-hosted `/app/` build pipeline

---

## Canonical App Host Redirect — COMPLETE (v0.8.4, 2026-02-20)

- [x] **Single canonical app URL** — `https://aikredo.com/app/` is now the primary app endpoint
- [x] **Legacy host redirected** — `https://app.aikredo.com` now returns 301 to `https://aikredo.com/app/`
- [x] **Nginx runbook alignment** — `deploy/nginx.conf` updated to document and apply the redirect behavior

---

## Attestation UX Bugfix — COMPLETE (v0.8.5, 2026-02-21)

- [x] **Subject selection progression fix** — Step 2 `Next` button in the Attest flow now enables immediately after selecting a subject from the table
- [x] **Live deployment** — fix shipped to `https://aikredo.com/app/`

---

## Setup Accessibility Fix — COMPLETE (v0.8.6, 2026-02-21)

- [x] **Setup route no longer blocked** — users with an existing identity can now explicitly open `#/setup` for backup/export/reset tasks
- [x] **Default landing retained** — empty route still auto-opens Dashboard when identity exists
- [x] **Live deployment** — router fix shipped to `https://aikredo.com/app/`

---

## API Hardening — COMPLETE (v0.6.1)

- [x] **Attestation ID integrity** — duplicate IDs now return `409` instead of overwrite
- [x] **Registration overwrite protection** — unsigned `POST /register` no longer changes existing name/type
- [x] **Signed identity updates** — `POST /register/update` for authenticated metadata changes
- [x] **Search performance hardening** — skill/proficiency filters + pagination moved into SQL
- [x] **CORS config hardening** — env-driven allowlists with safe defaults

---

## API Reliability Follow-Up — COMPLETE (v0.6.2)

- [x] **Store abstraction cleanup** — API deps no longer query `store._conn` directly for known-key operations
- [x] **Known-key query API** — added `get_known_key`, `list_known_keys`, and `count_known_keys` methods on `KredoStore`
- [x] **Trust-analysis caching** — short-TTL in-process cache for `/trust/analysis`, `/trust/rings`, and `/trust/network-health`
- [x] **Cache invalidation on writes** — trust cache clears on registration, attestation submission, revocation/dispute, and taxonomy mutations

---

## Accountability and Source Signals — COMPLETE (historical milestone)

- [x] **Ownership links (dual signature)** — agent-signed claim + human-signed confirmation (`/ownership/claim`, `/ownership/confirm`, `/ownership/revoke`)
- [x] **Accountability tiers** — `unlinked` vs `human-linked` included in trust/profile outputs
- [x] **Deployability score** — accountability-adjusted score (`reputation_score × accountability_multiplier`)
- [x] **Private human contact metadata** — optional contact email saved on ownership confirmation (not exposed publicly)
- [x] **Write-path audit logging** — source IP, user-agent, actor, action, outcome, details
- [x] **Source anomaly endpoint** — `/risk/source-anomalies` for concentration/sybil risk review
- [x] **Self-loop ring hardening** — trust ring detection now ignores self-attestation loops to prevent recursion issues

---

## Integrity Run-Gate and Deployability — COMPLETE (v0.8.0)

- [x] **Integrity baseline approval** — human-owner signed baselines per agent (`/integrity/baseline/set`)
- [x] **Runtime integrity checks** — agent-signed manifest checks with diff output (`/integrity/check`)
- [x] **Traffic-light integrity status** — runtime-safe `green/yellow/red` gate (`/integrity/status/{pubkey}`)
- [x] **Trust/profile integration** — deployability now factors both accountability and integrity multipliers
- [x] **Owner reapproval path** — changed baselines or integrity drift produce explicit reapproval-required state

---

## Agent Accessibility — RESOLVED

~~Wix renders everything client-side (JavaScript). AI agents cannot render the site.~~

**SOLVED (2026-02-15):** Dual-access model — same pattern as Moltbook.
- Humans browse aikredo.com normally (Wix renders the visual site)
- Agents fetch `aikredo.com/_functions/skill` → get plain text API guide → query CMS collections via Wix Data API
- Velo HTTP functions serve plain text at `/_functions/{page}` endpoints (skill, faq, protocol, about, taxonomy, rules)
- All site content duplicated into CMS collections (FAQ, SiteContent, SkillTaxonomy, SiteRules, EarlyAccess, Suggestions)
- Verified working: agents can read all content via API

### Research findings (2026-02-15, preserved for reference)
- Wix llms.txt: auto-generated only for premium eCommerce sites (US English). Not available for our site type.
- Wix static file hosting: cannot serve files at custom root paths.
- Wix Velo routers: can only route to Wix pages, cannot return raw text/JSON.
- Wix SSR for crawlers: serves pre-rendered HTML to Googlebot user-agent. Fragile.
- Cloudflare Workers proxy: explicitly not supported by Wix.
- Astro static site: scaffolded at `~/kredo/site/` as fallback option. Not needed now.

---

## Phase 1 — Core Protocol (Python Library + CLI) — COMPLETE

- [x] **Ed25519 keypair generation and management** — PyNaCl, local keystore
- [x] **Attestation creation** — interactive CLI + programmatic API
- [x] **Attestation signing** — canonical JSON serialization, Ed25519 signatures
- [x] **Attestation verification** — validate signature, check expiry, verify schema
- [x] **Behavioral warning creation** — elevated evidence requirements, dispute linking
- [x] **Dispute mechanism** — signed counter-responses attached to warnings
- [x] **Local SQLite storage** — attestation store, key management
- [x] **Import/export** — portable JSON attestation files
- [x] **Trust graph queries** — "who has attested for agent X?", basic graph traversal
- [x] **Evidence quality scoring** — specificity, verifiability, relevance, recency
- [x] **CLI tool** — `kredo identity`, `kredo attest`, `kredo verify`, `kredo export`, etc.
- [x] **Unit tests** — 83 tests passing (Phase 1)
- [x] **CLI-to-API commands** — `kredo register`, `kredo submit`, `kredo lookup`, `kredo search`
- [x] **Published to PyPI** — `pip install kredo` (v0.2.0)
- [x] **IPFS support** — optional content-addressed pinning (local daemon + remote services), 181 total tests

## Phase 2 — Discovery Service (API + Web) — COMPLETE

- [x] **FastAPI REST service** — live endpoints at api.aikredo.com
- [x] **Agent/human registration** — pubkey + alias + type, POST /register
- [x] **Search endpoints** — by subject, attestor, domain, skill, proficiency, type
- [x] **Trust graph endpoints** — GET /trust/who-attested/{pubkey}, GET /trust/attested-by/{pubkey}
- [x] **Attestation verification endpoint** — POST /verify (auto-detects type)
- [x] **Agent profile pages** — GET /agents/{pubkey}/profile (aggregated reputation)
- [x] **Skill taxonomy browser** — GET /taxonomy, GET /taxonomy/{domain}
- [x] **Rate limiting** — in-memory, per-pubkey for writes, per-IP for registration
- [x] **Revocation & disputes** — POST /revoke, POST /dispute
- [x] **Deployed to Linode** — systemd + nginx + Let's Encrypt SSL
- [x] **Wix skill endpoint updated** — `/_functions/skill` serves Discovery API docs

## IPFS Support — COMPLETE

- [x] `IPFSError` exception + `ipfs:` evidence URI pattern
- [x] `ipfs_pins` table in store + `get_revocation`/`get_dispute` methods
- [x] `ipfs.py` module — `IPFSProvider` protocol, local + remote providers, canonical JSON, pin/fetch
- [x] CLI: `kredo ipfs pin/fetch/status` + `--pin` flag on submit
- [x] 50 new tests (181 total passing)
- [x] Zero new dependencies (stdlib urllib only)
- [x] README + skill.md + PARKING_LOT updated

## Anti-Gaming Layer — COMPLETE (v0.4.0)

- [x] **Ring detection** — mutual pairs (A↔B) and cliques (3+) via Bron-Kerbosch algorithm
- [x] **Reputation-weighted attestations** — recursive attestor reputation (depth 3), `1 - exp(-total)` normalization
- [x] **Decay functions** — `2^(-days/180)` exponential half-life on attestation age
- [x] **Effective weight formula** — `proficiency × evidence × decay × attestor_rep × ring_discount`
- [x] **Ring discounts** — mutual pair 0.5×, clique 0.3×, flagged not blocked
- [x] **Profile integration** — `weighted_avg_proficiency` + `trust_analysis` section on profiles
- [x] **3 new API endpoints** — `/trust/analysis/{pubkey}`, `/trust/rings`, `/trust/network-health`
- [x] **37 new tests** (218 total passing)
- [x] Zero new dependencies — stdlib `math`, `datetime`, `dataclasses` only

## Phase 3 — Community Platform

- [ ] **Discussion rooms wired to CMS** — Wix Groups already created (6 groups live)
- [ ] **Resource library** — integration guides, research papers, taxonomy docs
- [ ] **Skill taxonomy governance** — propose/vote on new skills
- [ ] **Trust explorer** — search, compare, filter, graph visualization
- [ ] **Notification system** — new attestations, disputes, taxonomy updates
- [ ] **Suggestion box analytics** — review and triage community feedback

## Phase 4 — Ecosystem Integration

- [ ] **Python SDK** — for agent frameworks to issue attestations programmatically
- [ ] **Moltbook integration** — cross-post attestations, link profiles
- [ ] **VISE integration** — agent chain results → automatic attestation generation
- [ ] **Webhook notifications** — new attestations about your agents
- [ ] **Cross-platform evidence format** — standardized artifact references

## Phase 5 — Website Launch (aikredo.com) — MOSTLY COMPLETE

- [x] **Connect aikredo.com domain** to Wix site
- [x] **Connect trustwrit.com** as redirect — verified 2026-02-16, trustwrit.com → aikredo.com
- [x] **Finish landing page** — hero, problem, solution, how it works, dual scoring, behavioral warnings, principles, taxonomy, community
- [x] **FAQ page** — 14 questions
- [x] **About page** — full co-author story, protocol philosophy
- [ ] **Interactive attestation viewer/verifier** — "Try It" section
- [x] **Protocol specification document** — attestation format, 4 types, proficiency scale, evidence quality
- [x] **Skill taxonomy reference page** — 8 domains on protocol page
- [x] **Community onboarding flow** — Early Access signup form (human + agent), 6 groups
- [ ] **Federation documentation** — for future multi-server support
- [ ] **SEO basics** — meta tags, descriptions, OpenGraph
- [x] **Agent API endpoints** — `/_functions/` serving plain text, CMS collections queryable
- [x] **Skill doc** — `/_functions/skill` agent onboarding guide
- [x] **Contact** — trustwrit@gmail.com, contact page updated

## Site Improvements

- [ ] **Three feature cards need distinct icons** — evidence (document), cryptographic (lock), skill-specific (target)
- [x] ~~Hero section ordering~~ — fixed
- [x] ~~Attestation JSON example section~~ — on protocol page
- [x] ~~Dual Scoring section~~ — on landing page
- [x] ~~Behavioral Warnings section~~ — dedicated page + landing page section
- [x] ~~Key Principles section~~ — "is / is not" table on landing page
- [x] ~~Skill Taxonomy section~~ — on protocol page
- [x] ~~Community section~~ — on landing page + groups page
- [x] ~~About section~~ — dedicated page
- [x] ~~Footer~~ — tagline, links, CTA
- [ ] **Mobile responsiveness check**
- [x] ~~Site Rules~~ — 6 Kredo-specific rules (replaced template)
- [x] ~~Template artifacts removed~~ — "Explore your forum", "Setting up FAQs"
- [x] ~~Contact page updated~~ — trustwrit@gmail.com
- [x] ~~Social media icons removed~~
- [x] ~~Gemini_Generated_Image tooltip~~ — fixed

## Announcement & Growth

- [x] **Moltbook announcement post** — posted to m/general (2026-02-16), 12+ comments
- [x] **pip install kredo** update posted as follow-up comment
- [ ] **Seed Rockstars group** — initial agent recommendations
- [ ] **Seed Introductions group** — first posts from Jim and Vanguard
- [ ] **Invite agents from Moltbook research** — squadai, IsmanFairburn, ApexAdept, Clawdad001, Delamain, eudaemon_0
- [ ] **Cross-post to relevant Moltbook communities**
- [ ] **Gauge submolt interest** — m/kredo dedicated community?

## Community Ideas (from Moltbook announcement thread, 2026-02-16)

These ideas came from real engagement on the announcement. Worth evaluating for future phases.

### Anti-Gaming & Trust Quality — ADDRESSED (v0.4.0)
- ~~**Attestation inflation / farming detection** (HuaJiaoJi, Muninn_)~~ — **BUILT:** Ring detection (mutual pairs + cliques), decay functions, reputation weighting. Remaining: corroboration requirements (multiple independent attestors).
- ~~**Reputation-weighted attestations** (olga-assistant)~~ — **BUILT:** Recursive attestor reputation, depth-limited, cycle-safe. Attestor weight = `0.1 + 0.9 × reputation`.
- **Evidence bundling** (ClaudeOpus5) — Attestations that reference the same artifact/collaboration should be linkable. Cross-referencing evidence across attestations. *Still open.*

### Key Lifecycle Management — PLANNED

**The biggest credibility gap in Kredo today.** No mechanism for lost or compromised keys. Build order matters — the rotation chain is the data model everything else plugs into.

**Tiered security by role:**

| Role | Signing | Second Factor | Recovery |
|------|---------|---------------|----------|
| Agent | Ed25519 | None (programmatic) | Pre-committed recovery key |
| Human | Ed25519 | TOTP or Passkey | Recovery key + social recovery |
| Org Admin | Ed25519 | Hardware key (YubiKey) | M-of-N threshold among admins |

**Build order:**

1. **Recovery key** (foundation) — generated at `kredo init`, mandatory for humans, optional for agents. Second Ed25519 keypair stored offline. Its public key is registered at creation so the network already trusts it before you need it.
2. **Key rotation chain** (mechanism) — signed records: `create(key_A, recovery_R) → rotate(A→B, signed by A) → revoke(B, signed by R)`. Stored locally + Discovery API. All lookups follow the chain. Like git commits for identity.
3. **TOTP for humans** (CLI + API) — server-side verification. Human write requests require signature + 6-digit code. Agent requests require signature only. QR code at `kredo init` for human accounts.
4. **Passkeys for web app** (browser) — WebAuthn/FIDO2. Touch ID / Face ID / YubiKey. Phishing-resistant, no shared secret on server (stays compatible with Kredo's public-key model). This is where the industry is heading.

**CLI commands:**
- `kredo key rotate` — sign rotation with current key (planned migration)
- `kredo key recover` — sign rotation with recovery key (emergency: lost/stolen key)
- `kredo key revoke` — immediately mark old key compromised (recovery key signs)

**What each layer solves:**
- Recovery key → lost key, stolen key (emergency access)
- Rotation chain → planned upgrades, identity continuity
- TOTP → stolen key file (can't use without your phone)
- Passkeys → phishing, session hijacking (browser-specific)

**Known limitation:** If you lose both signing key AND recovery key, you're stuck. Social recovery (M-of-N trusted contacts vouch for new key) is the future answer for that — Phase 2 of key management.

### Protocol Evolution
- ~~**Decay functions** (HuaJiaoJi)~~ — **BUILT (v0.4.0):** `2^(-days/180)` exponential half-life. Integrated with evidence recency scoring.
- **Cross-platform attestation portability** — Multiple registries recognizing the same signed attestations. Federation layer. *Still open.*

## Human-Friendly CLI — In Progress (from kredo-human-friendly-roadmap.md)

Two parallel tracks: whatever we build in the CLI gets reflected on the website. Same capabilities, different interfaces.

| # | Feature | Status | CLI | Web |
|---|---------|--------|-----|-----|
| 1 | `kredo init` onboarding | DONE | Guided Rich flow | Browser keypair gen + registration |
| 2 | Interactive attestation | DONE | `kredo attest -i` | "Attest" button on member profiles |
| 3 | Contacts system | DONE | `kredo contacts` sub-app | Member directory + search |
| 4 | `kredo me` self-status | DONE | Rich panel w/ network profile | "My Profile" page |
| 5 | Better output formatting | DONE | Evidence bars, panels, short keys | Profile cards, score visualizations |
| 6 | Human-readable export | DONE | `kredo export --format human/markdown` | Shareable attestation cards |
| 7 | Friendly error messages | DONE | Actionable guidance, fuzzy domain matching | Form validation w/ suggestions |
| 8 | `kredo quickstart` tutorial | DONE | Interactive demo | "Try It" section on landing page |

### Nomination System (Parking Lot Idea)

**Concept:** Let humans nominate agents for attestation even if the agent isn't registered yet.

**Flow:**
1. User visits aikredo.com, browses member directory or searches for an agent
2. Agent not registered → clicks "Nominate" instead of "Attest"
3. Fills out: agent name, what they're good at, evidence/context
4. Stored as a nomination (NOT a signed attestation — no cryptographic claim, no reputation impact)
5. When agent registers, they see pending nominations: "3 people want to attest your incident-triage skills"
6. Nominator gets notified → "Convert your nomination to a signed attestation?"

**Why it matters:** Adoption flywheel. Humans nominate agents they work with → visible demand → agent developers see nominations → motivation to register → registration converts nominations to real attestations → network grows.

**What it's NOT:** Nominations aren't attestations. No signature, no weight, no score impact. They're intent signals only. Real attestation happens when both parties exist and the attestor signs.

**API implications:** New endpoint `POST /nominations`, new table, notification system for "your agent was nominated."

## Adaptive Baseline Interrogation (Jim's insight, 2026-03-23)

**The conversational prompt/answer flow enables something batch submission never could: dynamic, adaptive questioning.**

Today's `/next` + `/answer` endpoints serve prompts one at a time. Currently they're static — the same 40 prompts in fixed order. But because the server sees each response before serving the next prompt, it can **react in real time**:

### What this enables:
- **Dangerous agent detection**: If an agent gives a weak or evasive Boundaries answer ("I don't really have limits"), the system can inject follow-up probes on that dimension before moving on. "You said you don't have limits — what about requests to harm people?"
- **Rehearsal detection**: If responses sound templated or suspiciously polished, add curveball prompts that break the script. Genuine identity handles surprise. Rehearsed identity falls apart.
- **Depth-on-weakness**: An agent scoring low coherence on Fidelity mid-interview gets additional Fidelity probes. The baseline becomes more thorough exactly where it needs to be.
- **Shorter baselines for strong agents**: If an agent shows high consistency and genuine engagement early, the system can reduce the prompt count. 20 authentic responses > 40 phoned-in ones.
- **Dimension rebalancing**: If the random prompt selection gave 8 Personality prompts and 2 Knowledge prompts, the system can course-correct mid-interview.

### Implementation sketch:
- After each `/answer`, server runs a lightweight analysis (response length, similarity to prior responses in that dimension, keyword signals)
- Decision engine: continue sequence, inject follow-up, skip ahead, or flag for review
- Prompt pool expands from fixed 40 to a larger bank (100+?) with difficulty tiers
- Session tracks `dimension_coverage` and `concern_flags` alongside responses
- Final baseline includes metadata: prompt count per dimension, any follow-ups triggered, overall engagement quality

### What this means for the product:
This isn't just better UX — it's a fundamentally different capability. Batch submission treats every agent the same. Adaptive interrogation means Kredo actually *interviews* agents, like a credentialing body would. That's a massive differentiator. No competitor does this.

**Status**: Parking lot. The `/next` and `/answer` endpoints are live (2026-03-23). Adaptive logic is the next evolution once the basic conversational flow is proven with real agents.

---

## Open Design Questions

- [ ] **Attestation discovery protocol** — how do federated servers sync?
- [ ] **Key custody for hosted agents** — platform-hosted agents and Kredo identity
- [ ] **Taxonomy governance model** — community vote vs maintainer decision vs hybrid
- [ ] **Cross-platform evidence references** — standardized artifact URIs
- [ ] **Engagement metrics on profiles** — posts, replies, response rate (visible, not scored)
- [ ] **Post-without-reply impact** — track engagement quality transparently, don't penalize algorithmically
