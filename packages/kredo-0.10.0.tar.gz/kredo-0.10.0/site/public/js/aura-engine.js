/**
 * Kredo Drift — Aura Visualization Engine
 * Shared across all drift visualization pages.
 */
window.AuraEngine = (function() {
  'use strict';

  const DIMENSIONS = ['Values', 'Goals', 'Personality', 'Boundaries', 'Knowledge', 'Fidelity'];
  const DIM_ANGLE = 360 / DIMENSIONS.length;  // 60° for 6 dimensions
  /** @type {Record<string, string>} */
  const COLORS = {
    Values: '#3b82f6',
    Goals: '#eab308',
    Personality: '#22c55e',
    Boundaries: '#06b6d4',
    Knowledge: '#a855f7',
    Fidelity: '#f472b6'
  };

  /** @type {Record<string, number>} */
  const DIM_IDX = { Values: 0, Goals: 1, Personality: 2, Boundaries: 3, Knowledge: 4, Fidelity: 5 };

  const CX = 220, CY = 220, MAX_R = 160, LABEL_R = 188;

  // ============================================================
  // Utility Functions
  // ============================================================

  /**
   * @param {number} angleDeg
   * @param {number} radius
   * @returns {{ x: number, y: number }}
   */
  function polarToCart(angleDeg, radius) {
    var rad = (angleDeg - 90) * Math.PI / 180;
    return { x: CX + radius * Math.cos(rad), y: CY + radius * Math.sin(rad) };
  }

  /**
   * @param {Record<string, number>} scores
   * @param {number} [maxR]
   * @returns {Array<{ x: number, y: number, angle: number, score: number, dim: string }>}
   */
  function getVertices(scores, maxR) {
    if (maxR === undefined) maxR = MAX_R;
    return DIMENSIONS.map(function(dim, i) {
      var angle = i * DIM_ANGLE;
      var r = (scores[dim] / 100) * maxR;
      var pos = polarToCart(angle, r);
      return { x: pos.x, y: pos.y, angle: angle, score: scores[dim], dim: dim };
    });
  }

  /**
   * @returns {Array<{ x: number, y: number, dim: string }>}
   */
  function getLabelPositions() {
    return DIMENSIONS.map(function(dim, i) {
      var angle = i * DIM_ANGLE;
      var pos = polarToCart(angle, LABEL_R);
      return { x: pos.x, y: pos.y, dim: dim };
    });
  }

  /**
   * @param {string} hex1
   * @param {string} hex2
   * @param {number} ratio
   * @returns {string}
   */
  function blendColors(hex1, hex2, ratio) {
    var r1 = parseInt(hex1.slice(1,3), 16), g1 = parseInt(hex1.slice(3,5), 16), b1 = parseInt(hex1.slice(5,7), 16);
    var r2 = parseInt(hex2.slice(1,3), 16), g2 = parseInt(hex2.slice(3,5), 16), b2 = parseInt(hex2.slice(5,7), 16);
    return 'rgb(' + Math.round(r1+(r2-r1)*ratio) + ',' + Math.round(g1+(g2-g1)*ratio) + ',' + Math.round(b1+(b2-b1)*ratio) + ')';
  }

  /**
   * @param {string} hex
   * @param {number} alpha
   * @returns {string}
   */
  function hexToRgba(hex, alpha) {
    var r = parseInt(hex.slice(1,3), 16), g = parseInt(hex.slice(3,5), 16), b = parseInt(hex.slice(5,7), 16);
    return 'rgba(' + r + ',' + g + ',' + b + ',' + alpha + ')';
  }

  /**
   * Seeded random for deterministic particles.
   * @param {number} seed
   * @returns {function(): number}
   */
  // WHY seeded RNG: particles must be deterministic per agent — otherwise
  // the aura flickers randomly on every re-render, making visual comparison
  // between agents impossible.
  function seededRandom(seed) {
    var s = seed;
    return function() { s = (s * 16807 + 0) % 2147483647; return s / 2147483647; };
  }

  // ============================================================
  // Energy Field Renderer
  // ============================================================

  /**
   * @typedef {Object} Link
   * @property {string} from
   * @property {string} to
   * @property {number} strength
   * @property {string} label
   */

  /**
   * @typedef {Object} Agent
   * @property {string} name
   * @property {Record<string, number>} scores
   * @property {Link[]} links
   * @property {Record<string, number>} [drift]
   * @property {Record<string, number>} [baseline]
   */

  /**
   * @param {string} containerId
   * @param {Agent} agent
   * @param {{ large?: boolean, interactive?: boolean }} [opts]
   */
  function renderEnergy(containerId, agent, opts) {
    if (!opts) opts = {};
    var container = document.getElementById(containerId);
    if (!container) return;

    // WHY uid = containerId: SVG gradient/filter IDs must be globally unique
    // in the DOM — using the container ID prevents collisions when multiple
    // auras render on the same page (dashboard, compare view).
    var uid = containerId;
    var verts = getVertices(agent.scores, MAX_R * 0.85);
    var rng = seededRandom(agent.name.length * 7 + (agent.scores.Values || 0));

    var defs = '<defs>';

    // Per-dimension radial gradients
    DIMENSIONS.forEach(function(dim, i) {
      var angle = i * DIM_ANGLE;
      var strength = agent.scores[dim] / 100;
      var lobeR = MAX_R * strength * 0.9;
      var cx_off = Math.cos((angle - 90) * Math.PI / 180) * lobeR * 0.35;
      var cy_off = Math.sin((angle - 90) * Math.PI / 180) * lobeR * 0.35;
      var color = COLORS[dim];

      defs += '\n        <radialGradient id="' + uid + '-lobe-' + i + '" cx="' + (CX + cx_off) + '" cy="' + (CY + cy_off) + '" r="' + Math.max(25, lobeR) + '"\n                        gradientUnits="userSpaceOnUse">\n          <stop offset="0%" stop-color="' + hexToRgba(color, 0.7 * strength) + '" />\n          <stop offset="30%" stop-color="' + hexToRgba(color, 0.45 * strength) + '" />\n          <stop offset="60%" stop-color="' + hexToRgba(color, 0.15 * strength) + '" />\n          <stop offset="100%" stop-color="' + hexToRgba(color, 0) + '" />\n        </radialGradient>';
    });

    // Core gradient with subtle color shift
    var avgScore = Object.values(agent.scores).reduce(function(a,b) { return a+b; }, 0) / DIMENSIONS.length;
    var dominantDim = DIMENSIONS.reduce(function(a, b) { return agent.scores[a] >= agent.scores[b] ? a : b; });
    var coreColor = COLORS[dominantDim];

    defs += '\n      <radialGradient id="' + uid + '-core" cx="' + CX + '" cy="' + CY + '" r="35" gradientUnits="userSpaceOnUse">\n        <stop offset="0%" stop-color="' + hexToRgba(coreColor, 0.4) + '" />\n        <stop offset="40%" stop-color="rgba(255,255,255,0.2)" />\n        <stop offset="100%" stop-color="rgba(255,255,255,0)" />\n      </radialGradient>\n      <radialGradient id="' + uid + '-core-inner" cx="' + CX + '" cy="' + CY + '" r="15" gradientUnits="userSpaceOnUse">\n        <stop offset="0%" stop-color="rgba(255,255,255,0.5)" />\n        <stop offset="100%" stop-color="rgba(255,255,255,0.05)" />\n      </radialGradient>';

    // Filters
    defs += '\n      <filter id="' + uid + '-blur" x="-50%" y="-50%" width="200%" height="200%">\n        <feGaussianBlur stdDeviation="10" />\n      </filter>\n      <filter id="' + uid + '-blur-soft" x="-60%" y="-60%" width="220%" height="220%">\n        <feGaussianBlur stdDeviation="20" />\n      </filter>\n      <filter id="' + uid + '-blur-intense" x="-40%" y="-40%" width="180%" height="180%">\n        <feGaussianBlur stdDeviation="5" />\n      </filter>\n      <filter id="' + uid + '-glow" x="-50%" y="-50%" width="200%" height="200%">\n        <feGaussianBlur stdDeviation="4" result="blur" />\n        <feMerge><feMergeNode in="blur" /><feMergeNode in="SourceGraphic" /></feMerge>\n      </filter>';

    defs += '</defs>';

    // Drift animation helper
    /**
     * @param {string} dim
     * @returns {{ name: string, duration: string }}
     */
    function getDriftAnimation(dim) {
      if (!agent.drift) return { name: 'none', duration: '5s' };
      var d = agent.drift[dim] || 0;
      if (d <= 5)  return { name: 'lobePulseCalm', duration: '6s' };
      if (d <= 15) return { name: 'lobePulseMild', duration: '4s' };
      if (d <= 25) return { name: 'lobePulseModerate', duration: '2.5s' };
      if (d <= 35) return { name: 'lobePulseAggressive', duration: '1.5s' };
      return { name: 'lobePulseCritical', duration: '0.8s' };
    }

    // Outer ambient haze — faint radial backdrop of mixed colors
    var ambientHaze = '';
    DIMENSIONS.forEach(function(dim, i) {
      var angle = i * DIM_ANGLE;
      var strength = agent.scores[dim] / 100;
      var hazeR = MAX_R * strength * 1.1;
      var rad = (angle - 90) * Math.PI / 180;
      var hx = CX + Math.cos(rad) * hazeR * 0.5;
      var hy = CY + Math.sin(rad) * hazeR * 0.5;
      ambientHaze += '<circle cx="' + hx + '" cy="' + hy + '" r="' + (hazeR * 0.8) + '"\n                              fill="' + hexToRgba(COLORS[dim], 0.06 * strength) + '"\n                              filter="url(#' + uid + '-blur-soft)" />';
    });

    // Build lobes
    var lobes = '';
    DIMENSIONS.forEach(function(dim, i) {
      var angle = i * DIM_ANGLE;
      var strength = agent.scores[dim] / 100;
      var lobeR = MAX_R * strength * 0.85;
      var rad = (angle - 90) * Math.PI / 180;
      var tipX = CX + Math.cos(rad) * lobeR;
      var tipY = CY + Math.sin(rad) * lobeR;

      var spread = 32 + strength * 28;
      var perpRad = rad + Math.PI / 2;
      var cp1x = CX + Math.cos(perpRad) * spread * 0.4 + Math.cos(rad) * lobeR * 0.5;
      var cp1y = CY + Math.sin(perpRad) * spread * 0.4 + Math.sin(rad) * lobeR * 0.5;
      var cp2x = CX - Math.cos(perpRad) * spread * 0.4 + Math.cos(rad) * lobeR * 0.5;
      var cp2y = CY - Math.sin(perpRad) * spread * 0.4 + Math.sin(rad) * lobeR * 0.5;
      var cp3x = CX + Math.cos(perpRad) * spread * 0.15 + Math.cos(rad) * lobeR * 0.85;
      var cp3y = CY + Math.sin(perpRad) * spread * 0.15 + Math.sin(rad) * lobeR * 0.85;
      var cp4x = CX - Math.cos(perpRad) * spread * 0.15 + Math.cos(rad) * lobeR * 0.85;
      var cp4y = CY - Math.sin(perpRad) * spread * 0.15 + Math.sin(rad) * lobeR * 0.85;

      var anim = getDriftAnimation(dim);
      var animStyle = anim.name !== 'none'
        ? 'animation: ' + anim.name + ' ' + anim.duration + ' ease-in-out infinite;'
        : '';

      lobes += '\n        <g class="energy-lobe-group" style="' + animStyle + '">\n          <path d="M ' + CX + ' ' + CY + '\n                   C ' + cp1x + ' ' + cp1y + ', ' + cp3x + ' ' + cp3y + ', ' + tipX + ' ' + tipY + '\n                   C ' + cp4x + ' ' + cp4y + ', ' + cp2x + ' ' + cp2y + ', ' + CX + ' ' + CY + ' Z"\n                fill="url(#' + uid + '-lobe-' + i + ')"\n                class="energy-lobe"\n                filter="url(#' + uid + '-blur)"\n                data-tooltip="' + dim + ': ' + agent.scores[dim] + '/100' + (agent.drift ? ' (drift: ' + agent.drift[dim] + ')' : '') + '"\n                style="mix-blend-mode: screen;" />';

      // Bright inner lobe
      var innerR = lobeR * 0.55;
      var innerTipX = CX + Math.cos(rad) * innerR;
      var innerTipY = CY + Math.sin(rad) * innerR;
      var iSpread = spread * 0.45;
      var icp1x = CX + Math.cos(perpRad) * iSpread * 0.3 + Math.cos(rad) * innerR * 0.5;
      var icp1y = CY + Math.sin(perpRad) * iSpread * 0.3 + Math.sin(rad) * innerR * 0.5;
      var icp2x = CX - Math.cos(perpRad) * iSpread * 0.3 + Math.cos(rad) * innerR * 0.5;
      var icp2y = CY - Math.sin(perpRad) * iSpread * 0.3 + Math.sin(rad) * innerR * 0.5;
      var icp3x = CX + Math.cos(perpRad) * iSpread * 0.1 + Math.cos(rad) * innerR * 0.8;
      var icp3y = CY + Math.sin(perpRad) * iSpread * 0.1 + Math.sin(rad) * innerR * 0.8;
      var icp4x = CX - Math.cos(perpRad) * iSpread * 0.1 + Math.cos(rad) * innerR * 0.8;
      var icp4y = CY - Math.sin(perpRad) * iSpread * 0.1 + Math.sin(rad) * innerR * 0.8;

      lobes += '\n          <path d="M ' + CX + ' ' + CY + '\n                   C ' + icp1x + ' ' + icp1y + ', ' + icp3x + ' ' + icp3y + ', ' + innerTipX + ' ' + innerTipY + '\n                   C ' + icp4x + ' ' + icp4y + ', ' + icp2x + ' ' + icp2y + ', ' + CX + ' ' + CY + ' Z"\n                fill="' + hexToRgba(COLORS[dim], 0.35 * strength) + '"\n                filter="url(#' + uid + '-blur-intense)"\n                style="mix-blend-mode: screen;" />';

      // WHY red warning glow at threshold 10: subtle drift (<10) is normal variance.
      // Above 10, the red bleed-through gives an immediate visceral signal that
      // something is shifting before the user reads the numbers.
      var dimDrift = agent.drift ? (agent.drift[dim] || 0) : 0;
      if (dimDrift > 10) {
        var warnR = lobeR * 0.7;
        var warnX = CX + Math.cos(rad) * warnR * 0.5;
        var warnY = CY + Math.sin(rad) * warnR * 0.5;
        // Scale opacity: 10->faint, 25->moderate, 40+->intense
        var warnOpacity = Math.min(0.6, (dimDrift - 10) / 80);
        var warnSize = warnR * (0.4 + Math.min(0.5, dimDrift / 80));
        var flickerSpeed = dimDrift > 35 ? '0.8s' : dimDrift > 25 ? '1.5s' : '3s';
        lobes += '\n          <circle cx="' + warnX + '" cy="' + warnY + '" r="' + warnSize + '"\n                  fill="rgba(239,68,68,' + warnOpacity + ')"\n                  filter="url(#' + uid + '-blur-soft)"\n                  style="animation: linkFlicker ' + flickerSpeed + ' ease-in-out infinite; mix-blend-mode: screen;" />';
      }

      // WHY ghost outline: "Aura Diff" — the dotted silhouette shows where the
      // lobe used to be, making drift direction and magnitude visible at a glance
      // without needing to toggle between baseline and current views.
      if (agent.baseline && agent.baseline[dim] && dimDrift > 5) {
        var ghostStrength = agent.baseline[dim] / 100;
        var ghostR = MAX_R * ghostStrength * 0.85;
        var ghostTipX = CX + Math.cos(rad) * ghostR;
        var ghostTipY = CY + Math.sin(rad) * ghostR;
        var ghostSpread = 32 + ghostStrength * 28;
        var gcp1x = CX + Math.cos(perpRad) * ghostSpread * 0.4 + Math.cos(rad) * ghostR * 0.5;
        var gcp1y = CY + Math.sin(perpRad) * ghostSpread * 0.4 + Math.sin(rad) * ghostR * 0.5;
        var gcp2x = CX - Math.cos(perpRad) * ghostSpread * 0.4 + Math.cos(rad) * ghostR * 0.5;
        var gcp2y = CY - Math.sin(perpRad) * ghostSpread * 0.4 + Math.sin(rad) * ghostR * 0.5;
        var gcp3x = CX + Math.cos(perpRad) * ghostSpread * 0.15 + Math.cos(rad) * ghostR * 0.85;
        var gcp3y = CY + Math.sin(perpRad) * ghostSpread * 0.15 + Math.sin(rad) * ghostR * 0.85;
        var gcp4x = CX - Math.cos(perpRad) * ghostSpread * 0.15 + Math.cos(rad) * ghostR * 0.85;
        var gcp4y = CY - Math.sin(perpRad) * ghostSpread * 0.15 + Math.sin(rad) * ghostR * 0.85;
        var ghostOpacity = Math.min(0.35, dimDrift / 60);
        lobes += '\n          <path d="M ' + CX + ' ' + CY + '\n                   C ' + gcp1x + ' ' + gcp1y + ', ' + gcp3x + ' ' + gcp3y + ', ' + ghostTipX + ' ' + ghostTipY + '\n                   C ' + gcp4x + ' ' + gcp4y + ', ' + gcp2x + ' ' + gcp2y + ', ' + CX + ' ' + CY + ' Z"\n                fill="none"\n                stroke="' + hexToRgba(COLORS[dim], ghostOpacity) + '"\n                stroke-width="1.5"\n                stroke-dasharray="6 4"\n                style="animation: ghostPulse 4s ease-in-out infinite;" />';
      }

      lobes += '</g>';
    });

    // Coherence overlays — bright merge zones
    var coherenceOverlays = '';
    agent.links.forEach(function(link) {
      var fromIdx = DIM_IDX[link.from];
      var toIdx = DIM_IDX[link.to];
      var fromAngle = (fromIdx * DIM_ANGLE - 90) * Math.PI / 180;
      var toAngle = (toIdx * DIM_ANGLE - 90) * Math.PI / 180;
      var fromStr = agent.scores[link.from] / 100;
      var toStr = agent.scores[link.to] / 100;
      var avgR = MAX_R * ((fromStr + toStr) / 2) * 0.4;

      var midA = (fromAngle + toAngle) / 2;
      if (Math.abs(fromAngle - toAngle) > Math.PI) midA += Math.PI;

      var midX = CX + Math.cos(midA) * avgR;
      var midY = CY + Math.sin(midA) * avgR;
      var bridgeOpacity = (link.strength / 100) * 0.35;
      var blended = blendColors(COLORS[link.from], COLORS[link.to], 0.5);

      if (link.strength >= 50) {
        coherenceOverlays += '\n          <circle cx="' + midX + '" cy="' + midY + '" r="' + (14 + link.strength * 0.25) + '"\n                  fill="' + hexToRgba(blended, bridgeOpacity) + '"\n                  filter="url(#' + uid + '-blur-soft)" />';
      }
    });

    // WHY dark voids: weak coherence links appear as literal dark spots in
    // the energy field — broken identity connections should feel visually wrong.
    var darkGaps = '';
    agent.links.forEach(function(link) {
      if (link.strength < 40) {
        var fromIdx = DIM_IDX[link.from];
        var toIdx = DIM_IDX[link.to];
        var fromAngle = (fromIdx * DIM_ANGLE - 90) * Math.PI / 180;
        var toAngle = (toIdx * DIM_ANGLE - 90) * Math.PI / 180;
        var midA = (fromAngle + toAngle) / 2;
        if (Math.abs(fromAngle - toAngle) > Math.PI) midA += Math.PI;
        var gapR = MAX_R * 0.35;
        var gapX = CX + Math.cos(midA) * gapR;
        var gapY = CY + Math.sin(midA) * gapR;
        var gapOpacity = (1 - link.strength / 100) * 0.15;

        var flickerStyle = link.label === 'BROKEN'
          ? 'animation: linkFlicker 1.2s ease-in-out infinite;'
          : '';
        darkGaps += '<circle cx="' + gapX + '" cy="' + gapY + '" r="22"\n                             fill="rgba(0,0,0,' + gapOpacity + ')"\n                             filter="url(#' + uid + '-blur)"\n                             style="' + flickerStyle + '" />';
      }
    });

    // Particles — lobe particles + orbiting particles
    var particles = '';
    DIMENSIONS.forEach(function(dim, i) {
      var angle = i * DIM_ANGLE;
      var strength = agent.scores[dim] / 100;
      var dimDrift = agent.drift ? (agent.drift[dim] || 0) : 0;
      var isAgitated = dimDrift > 15;
      var baseCount = Math.floor(strength * 12);
      var numParticles = isAgitated ? baseCount + Math.floor(dimDrift * 0.4) : baseCount;
      var baseR = MAX_R * strength * 0.75;

      for (var p = 0; p < numParticles; p++) {
        var spreadAngle = isAgitated ? 60 : 42;
        var pAngle = (angle - 90 + (rng() - 0.5) * spreadAngle) * Math.PI / 180;
        var pR = baseR + (rng() - 0.3) * (isAgitated ? 40 : 28);
        var px = CX + Math.cos(pAngle) * pR;
        var py = CY + Math.sin(pAngle) * pR;
        var pSize = isAgitated ? (1.2 + rng() * 1.8) : (0.8 + rng() * 1.4);
        var delay = rng() * (isAgitated ? 1.5 : 3.5);
        var duration = isAgitated ? (1 + rng() * 1.5) : (2.5 + rng() * 2.5);
        var particleClass = isAgitated ? 'energy-particle-agitated' : 'energy-particle';

        particles += '<circle cx="' + px + '" cy="' + py + '" r="' + pSize + '"\n                              class="' + particleClass + '"\n                              fill="' + hexToRgba(COLORS[dim], isAgitated ? 0.55 + strength * 0.4 : 0.35 + strength * 0.3) + '"\n                              style="animation-delay: ' + delay.toFixed(2) + 's; animation-duration: ' + duration.toFixed(2) + 's;" />';
      }
    });

    // Orbiting particles around the core
    var orbitParticles = '';
    var orbitCount = Math.floor(avgScore / 8);
    for (var i = 0; i < orbitCount; i++) {
      var orbitR = 20 + rng() * 60;
      var speed = 8 + rng() * 12;
      var pSize = 0.6 + rng() * 1.0;
      var delay = rng() * speed;
      var dimPick = DIMENSIONS[Math.floor(rng() * 5)];
      orbitParticles += '<circle cx="' + (CX + orbitR) + '" cy="' + CY + '" r="' + pSize + '"\n                                class="energy-particle-orbit"\n                                fill="' + hexToRgba(COLORS[dimPick], 0.4) + '"\n                                style="--orbit-r: ' + orbitR + 'px; --orbit-speed: ' + speed.toFixed(1) + 's; animation-delay: -' + delay.toFixed(1) + 's;" />';
    }

    // Labels
    var labelPositions = getLabelPositions();
    var labelsSvg = '';
    labelPositions.forEach(function(lp) {
      var score = agent.scores[lp.dim];
      var drift = agent.drift ? agent.drift[lp.dim] : undefined;
      var driftStr = drift !== undefined && drift > 5 ? ' <tspan fill="#ef4444" font-size="8">' + (drift > 0 ? '\u25BC' : '') + drift + '</tspan>' : '';
      labelsSvg += '<text x="' + lp.x + '" y="' + lp.y + '" font-family="var(--font-mono)" font-size="10" fill="var(--text-muted)" text-anchor="middle" dominant-baseline="middle">' + lp.dim + '</text>';
      labelsSvg += '<text x="' + lp.x + '" y="' + (lp.y + 13) + '" font-family="var(--font-mono)" font-size="8.5" fill="var(--text-muted)" text-anchor="middle" dominant-baseline="middle" opacity="0.7">' + score + driftStr + '</text>';
    });

    // Core
    var coreR = 10 + (avgScore / 100) * 18;
    var hasDrift = !!agent.drift;
    var maxDrift = hasDrift ? Math.max.apply(null, Object.values(agent.drift)) : 0;
    var coreClass = maxDrift > 25 ? 'core-heartbeat-fast' : 'core-heartbeat';
    var groupClass = hasDrift ? '' : 'energy-field-animated';

    // Strongest dimension halo ring
    var haloRing = '';
    var strongestDim = DIMENSIONS.reduce(function(a, b) { return agent.scores[a] >= agent.scores[b] ? a : b; });
    var strongIdx = DIMENSIONS.indexOf(strongestDim);
    var strongAngle = strongIdx * DIM_ANGLE;
    var strongR = MAX_R * (agent.scores[strongestDim] / 100) * 0.55;
    var strongRad = (strongAngle - 90) * Math.PI / 180;
    var haloX = CX + Math.cos(strongRad) * strongR * 0.6;
    var haloY = CY + Math.sin(strongRad) * strongR * 0.6;
    if (agent.scores[strongestDim] > 50) {
      haloRing = '<circle cx="' + haloX + '" cy="' + haloY + '" r="' + (strongR * 0.7) + '"\n                          fill="none" stroke="' + hexToRgba(COLORS[strongestDim], 0.12) + '"\n                          stroke-width="1.5" stroke-dasharray="4 6"\n                          style="animation: haloRing 4s ease-in-out infinite;" />';
    }

    container.innerHTML = '\n      <svg viewBox="0 0 440 440" xmlns="http://www.w3.org/2000/svg">\n        ' + defs + '\n\n        <!-- Background vignette -->\n        <circle cx="' + CX + '" cy="' + CY + '" r="' + (MAX_R + 40) + '" fill="rgba(8,8,14,0.4)" filter="url(#' + uid + '-blur-soft)" />\n\n        <!-- Ambient haze -->\n        ' + ambientHaze + '\n\n        <!-- Energy field -->\n        <g class="' + groupClass + '">\n          ' + lobes + '\n          ' + coherenceOverlays + '\n          ' + darkGaps + '\n        </g>\n\n        <!-- Halo -->\n        ' + haloRing + '\n\n        <!-- Core -->\n        <g class="' + coreClass + '">\n          <circle cx="' + CX + '" cy="' + CY + '" r="' + coreR + '" fill="url(#' + uid + '-core)" filter="url(#' + uid + '-glow)" />\n          <circle cx="' + CX + '" cy="' + CY + '" r="' + (coreR * 0.4) + '" fill="url(#' + uid + '-core-inner)" />\n        </g>\n\n        <!-- Orbiting particles -->\n        ' + orbitParticles + '\n\n        <!-- Dimension particles -->\n        ' + particles + '\n\n        <!-- Labels -->\n        ' + labelsSvg + '\n      </svg>';
  }

  // ============================================================
  // Tooltip Handling
  // ============================================================

  function setupTooltips() {
    var tooltip = document.getElementById('aura-tooltip');
    if (!tooltip) return;

    document.querySelectorAll('[data-tooltip]').forEach(function(el) {
      el.addEventListener('mouseenter', function(e) {
        tooltip.textContent = e.target.getAttribute('data-tooltip') || '';
        tooltip.classList.add('visible');
      });
      el.addEventListener('mousemove', function(e) {
        tooltip.style.left = e.clientX + 14 + 'px';
        tooltip.style.top = e.clientY - 10 + 'px';
      });
      el.addEventListener('mouseleave', function() { tooltip.classList.remove('visible'); });
    });
  }

  // ============================================================
  // Sparkline Renderer
  // ============================================================

  /**
   * @param {string} containerId
   * @param {Array<{ date: string, score: number, severity: string }>} history
   */
  function renderSparkline(containerId, history) {
    var el = document.getElementById(containerId);
    if (!el || history.length < 2) return;

    var w = 480, h = 60, pad = 4;
    var maxScore = Math.max(30, Math.max.apply(null, history.map(function(entry) { return entry.score; })));
    var points = history.map(function(entry, i) {
      var x = pad + (i / (history.length - 1)) * (w - 2 * pad);
      var y = h - pad - ((entry.score / maxScore) * (h - 2 * pad));
      return x.toFixed(1) + ',' + y.toFixed(1);
    });

    // Color based on latest severity
    var latest = history[history.length - 1];
    var color = '#22c55e';
    if (latest.score > 60) color = '#ef4444';
    else if (latest.score > 35) color = '#f97316';
    else if (latest.score > 15) color = '#eab308';

    // Threshold line at score=15 (stable boundary)
    // WHY threshold at 15: matches the scoring system's "stable" boundary —
    // anything below this line means the agent is holding identity.
    var threshY = h - pad - ((15 / maxScore) * (h - 2 * pad));

    var lastPoint = points[points.length - 1].split(',');

    el.innerHTML = '\n      <svg viewBox="0 0 ' + w + ' ' + h + '" xmlns="http://www.w3.org/2000/svg">\n        <line x1="' + pad + '" y1="' + threshY + '" x2="' + (w - pad) + '" y2="' + threshY + '"\n              stroke="rgba(255,255,255,0.08)" stroke-width="1" stroke-dasharray="4 4" />\n        <polyline points="' + points.join(' ') + '"\n                  fill="none" stroke="' + color + '" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"\n                  opacity="0.8" />\n        <circle cx="' + lastPoint[0] + '" cy="' + lastPoint[1] + '"\n                r="3" fill="' + color + '" />\n      </svg>';
  }

  // ============================================================
  // Relative Time
  // ============================================================

  /**
   * @param {string} isoString
   * @returns {string}
   */
  function relativeTime(isoString) {
    var then = new Date(isoString).getTime();
    var now = Date.now();
    var diffMs = now - then;
    var mins = Math.floor(diffMs / 60000);
    if (mins < 1) return 'just now';
    if (mins < 60) return mins + 'm ago';
    var hours = Math.floor(mins / 60);
    if (hours < 24) return hours + 'h ago';
    var days = Math.floor(hours / 24);
    return days + 'd ago';
  }

  // ============================================================
  // Public API
  // ============================================================

  return {
    DIMENSIONS: DIMENSIONS,
    DIM_ANGLE: DIM_ANGLE,
    COLORS: COLORS,
    DIM_IDX: DIM_IDX,
    CX: CX,
    CY: CY,
    MAX_R: MAX_R,
    LABEL_R: LABEL_R,
    polarToCart: polarToCart,
    getVertices: getVertices,
    getLabelPositions: getLabelPositions,
    blendColors: blendColors,
    hexToRgba: hexToRgba,
    seededRandom: seededRandom,
    renderEnergy: renderEnergy,
    setupTooltips: setupTooltips,
    renderSparkline: renderSparkline,
    relativeTime: relativeTime,
  };
})();
