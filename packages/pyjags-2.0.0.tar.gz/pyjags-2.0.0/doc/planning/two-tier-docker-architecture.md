# Two-Tier Docker Architecture for PyJAGS

## Motivation

The current single Dockerfile serves development well but conflates two distinct use cases:

1. **CI/CD and lightweight testing** — needs only JAGS, Python, build tools, and core
   pyjags dependencies. Must be fast to build and small to pull.
2. **Interactive development & notebooks** — needs everything above plus JupyterLab,
   the scientific Python stack, and packages referenced by example notebooks.

Splitting into two tiers keeps CI fast and images lean while giving notebook users a
batteries-included environment.

---

## Dependency Analysis

### Core dependencies (in `setup.py` `install_requires`)

| Package | Why it's core |
|---------|---------------|
| `numpy` | Fundamental array type for all sample data |
| `arviz` | Used in `pyjags/incremental_sampling.py` for `az.from_pyjags()`, `az.ess()`, `az.rhat()` |
| `h5py` | Used in `pyjags/io.py` for HDF5 sample persistence |

**Important**: `arviz` is a genuine runtime dependency, not just a notebook convenience.
It pulls in `xarray`, `pandas`, `scipy`, and `matplotlib` as transitive dependencies.
This means the base image already includes a significant portion of the scientific stack.

### Notebook-only dependencies

Found by scanning imports across all four notebooks:

| Package | Used in | Notes |
|---------|---------|-------|
| `matplotlib` | 3/4 notebooks | Already a transitive dep of arviz |
| `pandas` | 3/4 notebooks | Already a transitive dep of arviz |
| `seaborn` | 3/4 notebooks | Lightweight addition |
| `xarray` | 3/4 notebooks | Already a transitive dep of arviz |
| `scikit-learn` | 2/4 notebooks | Used for data generation (make_moons, etc.) |
| `line_profiler` | 1/4 notebooks | Advanced Functionality.ipynb |
| `pymc3` | 1/4 notebooks | **Deprecated** — Eight Schools.ipynb needs migration to `pymc` v5 |

### What the lab tier actually adds on top of base

Because arviz already pulls in matplotlib, pandas, xarray, and scipy, the *net new*
packages for the lab tier are quite small:

- `jupyterlab`
- `seaborn`
- `scikit-learn`
- `line_profiler`
- `pymc` (v5, replacing deprecated pymc3 — optional, can defer)

---

## Proposed Architecture

### File Layout

```
Dockerfile              → base image (renamed from current Dockerfile)
Dockerfile.lab          → lab image, FROM pyjags-base
requirements-lab.txt    → extra pip packages for the lab tier
compose.yaml            → updated to reference Dockerfile.lab for dev
compose.ci.yaml         → CI override using base image only
```

### Tier 1: Base Image (`Dockerfile`)

Purpose: minimal image for building, testing, and CI/CD.

```dockerfile
FROM python:3.12-bookworm

RUN apt-get update && apt-get install -y --no-install-recommends \
    jags \
    pkg-config \
    g++ \
    && rm -rf /var/lib/apt/lists/*

# Core build and runtime dependencies (arviz + h5py pre-installed for faster CI)
RUN pip install --no-cache-dir numpy setuptools arviz h5py

WORKDIR /pyjags

CMD ["tail", "-f", "/dev/null"]
```

Notes:
- No JupyterLab, no notebook extras.
- `arviz` and `h5py` are pre-installed to speed up `pip install -e .` in CI.
  The image is rebuilt infrequently, so the larger layer is acceptable.

### Tier 2: Lab Image (`Dockerfile.lab`)

Purpose: full development environment with JupyterLab and scientific packages.

```dockerfile
FROM pyjags-base:latest

# Install Jupyter and notebook dependencies
COPY requirements-lab.txt /tmp/requirements-lab.txt
RUN pip install --no-cache-dir -r /tmp/requirements-lab.txt \
    && rm /tmp/requirements-lab.txt

EXPOSE 8888

CMD ["tail", "-f", "/dev/null"]
```

### `requirements-lab.txt`

```
jupyterlab
seaborn
scikit-learn
line_profiler
# pymc  # uncomment after Eight Schools.ipynb is migrated from pymc3 to pymc v5
```

Note: `matplotlib`, `pandas`, `xarray`, and `scipy` are omitted because they are
already transitive dependencies of `arviz` and will be installed when pyjags is
pip-installed.

---

## compose.yaml Updates

### Development (default — uses lab image)

```yaml
services:
  pyjags:
    build:
      context: .
      dockerfile: Dockerfile.lab
    volumes:
      - .:/pyjags
      - ./notebooks:/app/notebooks
    ports:
      - "${JAGSLAB_PORT:-8888}:8888"
    stdin_open: true
    tty: true
```

### CI/CD (`compose.ci.yaml` override)

```yaml
services:
  pyjags:
    build:
      context: .
      dockerfile: Dockerfile
    # No ports, no notebook volume
    volumes:
      - .:/pyjags
```

Usage in CI:

```bash
docker compose -f compose.yaml -f compose.ci.yaml build
docker compose -f compose.yaml -f compose.ci.yaml run --rm pyjags \
    bash -c "pip install --no-build-isolation -e . && python -m unittest discover test/ -v"
```

---

## jagslab CLI Integration

The `jagslab` script needs minimal changes:

| Command | Tier used | Notes |
|---------|-----------|-------|
| `build` | Lab (default) | Builds both base and lab images |
| `test` | Lab (currently) | Could optionally use base-only for faster CI |
| `start` | Lab | JupyterLab requires lab image |
| `install` | Either | Works in both tiers |
| `shell` | Lab | Developer convenience |
| `python` | Either | Works in both tiers |

### Proposed `build` command flow

```bash
cmd_build() {
    info "Building base image..."
    docker build -t pyjags-base:latest -f Dockerfile .

    info "Building lab image..."
    docker compose build

    info "Build complete."
}
```

### Optional: `--ci` flag

For running tests without the lab overhead:

```bash
jagslab test --ci    # Uses base image only, skips JupyterLab
jagslab test         # Uses lab image (current behavior)
```

This is a nice-to-have and can be deferred.

---

## `setup.py` — No Changes Needed

The current `install_requires` is correct:

```python
install_requires=[
    'numpy',
    'arviz',
    'h5py'
]
```

- `arviz` must stay: it's used in `pyjags/incremental_sampling.py`.
- Notebook-only packages go in `requirements-lab.txt`, not `setup.py`.
- No `extras_require` section is needed — the lab requirements file is simpler
  and more appropriate for a Docker-based workflow.

---

## Image Size Estimates

| Tier | Estimated size | Contents |
|------|---------------|----------|
| Base | ~500 MB | Python 3.12 + JAGS + g++ + numpy + setuptools |
| Base + pyjags installed | ~700 MB | Above + arviz + h5py + transitive deps |
| Lab | ~900 MB | Above + JupyterLab + seaborn + scikit-learn + line_profiler |

These are rough estimates. The base image is dominated by the Python runtime (~350 MB)
and build tools (~100 MB).

---

## Migration Plan

### Phase 1: Split Dockerfiles (minimal disruption)

1. Rename current `Dockerfile` to `Dockerfile` (keep as base — remove jupyterlab line)
2. Create `Dockerfile.lab` that extends base
3. Create `requirements-lab.txt`
4. Update `compose.yaml` to use `Dockerfile.lab`
5. Update `jagslab build` to build base first, then lab
6. Test: `jagslab build && jagslab test && jagslab start`

### Phase 2: CI/CD support (when needed)

1. Create `compose.ci.yaml` override
2. Add GitHub Actions workflow using base image
3. Document CI usage in README

### Phase 3: Notebook maintenance (separate effort)

1. Migrate Eight Schools.ipynb from pymc3 to pymc v5
2. Add `pymc` to `requirements-lab.txt`
3. Review and update all notebooks for Python 3.12 / numpy 2.x compatibility

---

## Alternatives Considered

### Single Dockerfile with multi-stage build

Could use a single Dockerfile with `--target base` and `--target lab` stages. This
keeps everything in one file but makes `compose.yaml` slightly more complex. The two-file
approach is more readable and conventional for this project's scale.

### `extras_require` in setup.py

Could add `extras_require={'lab': ['jupyterlab', 'seaborn', ...]}` and install via
`pip install -e .[lab]`. This is a valid Python packaging approach but:
- Mixes Docker environment concerns with Python packaging
- These aren't optional *library* features — they're development environment tools
- A requirements file is more conventional for Docker workflows

### Single fat image

Keep everything in one Dockerfile. Simpler, but CI pulls ~400 MB of unnecessary
packages on every run. Given that CI runners typically pull images fresh, this adds
up.

**Recommendation**: The two-file approach (Dockerfile + Dockerfile.lab) is the best
balance of simplicity, convention, and CI efficiency for this project.

---

## Resolved Questions

1. **Pre-install arviz in base image?** **Yes.** Pre-installing reduces `pip install -e .`
   time in CI and the image is rebuilt infrequently. The base Dockerfile includes arviz
   and h5py.

2. **Image registry?** Deferred. No registry for now; keep in mind for when CI is set up.

3. **pymc v5 migration**: Separate task, not blocking the Docker tier split. Confirm the
   lab environment works first by running a notebook that does not depend on pymc3.

4. **Multi-platform builds?** Deferred. JAGS supports both Intel and Apple Silicon Macs
   (see https://sourceforge.net/projects/mcmc-jags/files/JAGS/4.x/Mac%20OS%20X/).
   A plan for this is tracked in `doc/planning/multi-platform-builds.md`.