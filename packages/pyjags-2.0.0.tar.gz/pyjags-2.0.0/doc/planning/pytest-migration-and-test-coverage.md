# Pytest Migration and Test Coverage Plan

## Overview

Migrate from `unittest` to `pytest` and expand test coverage for untested modules.
Current state: 78 tests across 3 test files covering `model.py`, `arviz.py`, and
`modules.py`. Several modules have zero test coverage.

## Phase 1: Pytest Migration

### Steps

1. Add `pytest` and `hypothesis` (with `hypothesis[numpy]`) to dev dependencies
2. Rename test files to follow pytest conventions (already `test_*.py`)
3. Convert `unittest.TestCase` classes to plain test functions/classes using
   `assert` statements instead of `self.assertEqual()` etc.
4. Replace `setUp`/`tearDown` with pytest fixtures
5. Add `conftest.py` with shared fixtures (e.g., sample data generators)
6. Update `scripts/jagslab` and `scripts/test-all-pythons` to use `pytest`
7. Add `pyproject.toml` or `pytest.ini` section for pytest configuration
8. Verify all 78 existing tests still pass

### Pytest Configuration

```ini
# in setup.cfg or pyproject.toml
[tool:pytest]
testpaths = test
markers =
    slow: tests that require JAGS model compilation (> 1s)
```

### Fixtures (conftest.py)

```python
# Reusable sample dictionaries for chain_utilities, arviz, io tests
@pytest.fixture
def scalar_samples():
    """Scalar variable: shape (1, iterations, chains)."""
    return {"mu": np.random.randn(1, 100, 4)}

@pytest.fixture
def vector_samples():
    """Vector variable: shape (param_dim, iterations, chains)."""
    return {"beta": np.random.randn(5, 100, 4)}

@pytest.fixture
def multi_variable_samples():
    """Multiple variables with different shapes."""
    return {
        "mu": np.random.randn(1, 100, 4),
        "beta": np.random.randn(5, 100, 4),
    }

@pytest.fixture
def tmp_hdf5(tmp_path):
    """Temporary HDF5 file path (auto-cleaned by pytest)."""
    return str(tmp_path / "samples.hdf5")
```

## Phase 2: Test Coverage Expansion

### Priority 1: chain_utilities.py (pure functions, no JAGS needed)

**Approach:** Standard pytest + Hypothesis for property-based testing.

Hypothesis is ideal here because these are pure numpy array transformations with
clear algebraic invariants:

| Function | Tests | Hypothesis Properties |
|----------|-------|-----------------------|
| `get_chain_length` | valid input, empty dict, inconsistent lengths | chain length equals `arr.shape[1]` for any valid sample dict |
| `discard_burn_in_samples` | burn_in=0, burn_in < length, burn_in = length | output length = input length - burn_in |
| `merge_consecutive_chains` | two chunks, many chunks, single chunk | output iterations = sum of input iterations; values preserved |
| `merge_parallel_chains` | two sets, many sets, single set | output chains = sum of input chains; values preserved |
| `extract_final_iteration_from_samples_for_initialization` | scalar var, vector var, multi-chain | extracted values match `arr[:, -1, chain]` |

**Error cases (standard pytest):**
- `get_chain_length({})` raises `ValueError`
- `merge_consecutive_chains` with mismatched variable names
- `merge_consecutive_chains` with mismatched param dimensions
- `merge_consecutive_chains` with mismatched chain counts
- `merge_parallel_chains` with mismatched chain lengths

**Hypothesis strategies:**

```python
from hypothesis import given, settings
from hypothesis.extra.numpy import arrays
import hypothesis.strategies as st

# Strategy for generating valid sample dictionaries
@st.composite
def sample_dicts(draw, min_vars=1, max_vars=3):
    n_vars = draw(st.integers(min_value=min_vars, max_value=max_vars))
    iterations = draw(st.integers(min_value=1, max_value=50))
    chains = draw(st.integers(min_value=1, max_value=4))
    samples = {}
    for i in range(n_vars):
        param_dim = draw(st.integers(min_value=1, max_value=5))
        arr = draw(arrays(
            dtype=np.float64,
            shape=(param_dim, iterations, chains),
            elements=st.floats(min_value=-1e6, max_value=1e6,
                               allow_nan=False, allow_infinity=False),
        ))
        samples[f"var_{i}"] = arr
    return samples
```

**Estimated test count:** ~20 tests
**Estimated run time:** < 2s (no JAGS, pure numpy)

### Priority 2: io.py (pure functions, no JAGS needed)

**Approach:** pytest with `tmp_path` fixture + Hypothesis for round-trip property.

| Function | Tests |
|----------|-------|
| `save_samples_dictionary_to_file` | basic save, with compression, without compression |
| `load_samples_dictionary_from_file` | basic load, non-existent file raises error |
| Round-trip | save then load preserves values and shapes exactly |

**Hypothesis property:** For any valid sample dictionary, `load(save(samples)) == samples`.

```python
@given(samples=sample_dicts())
def test_round_trip_preserves_data(samples, tmp_path):
    path = str(tmp_path / "test.hdf5")
    save_samples_dictionary_to_file(path, samples)
    loaded = load_samples_dictionary_from_file(path)
    for key in samples:
        np.testing.assert_array_equal(samples[key], loaded[key])
```

**Estimated test count:** ~8 tests
**Estimated run time:** < 1s

### Priority 3: dic.py (data classes are pure, dic_samples needs JAGS)

**Approach:** Test `DIC` and `DiffDIC` classes directly (pure). Test `dic_samples`
with a simple JAGS model (mark as `@pytest.mark.slow`).

| Component | Tests |
|-----------|-------|
| `DIC` | construction, properties, `construct_report`, `__str__`, `__repr__` |
| `DIC.__sub__` | same type succeeds, different type raises, non-DIC raises |
| `DiffDIC` | construction from array, construction from scalar, `__str__` |
| `dic_samples` | with valid model, invalid model type, single chain raises, invalid n_iter |

**Bug noted:** Line 141 has a logic error:
```python
if not type == "pD" or type == "popt":  # always True when type == "popt"
```
Should be:
```python
if type not in ("pD", "popt"):
```
Fix this as part of the test work.

**Estimated test count:** ~15 tests
**Estimated run time:** < 1s for pure tests, ~2s for dic_samples (needs JAGS)

### Priority 4: incremental_sampling.py (needs JAGS for integration tests)

**Approach:** Unit test the criteria classes with synthetic data (fast). Integration
test `sample_until` with a simple JAGS model (mark as `@pytest.mark.slow`).

| Component | Tests |
|-----------|-------|
| `EffectiveSampleSizeCriterion` | construction, properties, __call__ with sufficient/insufficient ESS |
| `RHatDeviationCriterion` | construction, properties, __call__ with converged/unconverged chains |
| `EffectiveSampleSizeAndRHatCriterion` | construction, both criteria must be met |
| `sample_until` | converges within limit, hits max_iterations, with previous_samples, chunk_size > max_iterations raises |

**Testing convergence criteria without JAGS:** Generate synthetic samples that
either look converged (iid draws across chains) or unconverged (different means
per chain), then call the criterion directly.

```python
def test_ess_criterion_satisfied():
    # iid draws -> high ESS -> criterion satisfied
    samples = {"mu": np.random.randn(1, 500, 4)}
    criterion = EffectiveSampleSizeCriterion(minimum_ess=100)
    assert criterion(samples, verbose=False)

def test_ess_criterion_not_satisfied():
    # very few draws -> low ESS -> criterion not satisfied
    samples = {"mu": np.random.randn(1, 5, 4)}
    criterion = EffectiveSampleSizeCriterion(minimum_ess=1000)
    assert not criterion(samples, verbose=False)
```

**Estimated test count:** ~15 tests
**Estimated run time:** < 2s for criteria tests, ~3s for sample_until integration

### Priority 5: Edge cases for existing modules

**arviz.py additions:**
- Empty sample dictionary
- 2D array input (no param dim — shape `(iterations, chains)`)
- Very high dimensional array (5D+)
- Warmup iterations exceeding total iterations

**modules.py additions:**
- `version()` returns a tuple of ints
- `set_modules_dir()` with valid/invalid paths

**Estimated test count:** ~10 tests

## Phase 3: Hypothesis Configuration

### Settings

```python
# conftest.py
from hypothesis import settings, HealthCheck

settings.register_profile("ci", max_examples=50, deadline=1000)
settings.register_profile("dev", max_examples=10, deadline=2000)
settings.load_profile("dev")  # fast by default, CI uses more examples
```

Keep Hypothesis `max_examples` low (10 for dev, 50 for CI) so the full test suite
runs in under 10 seconds. The property-based tests add confidence through invariant
checking, not through brute-force example counts.

### Where Hypothesis Adds Value vs. Where It Doesn't

**Good fit (use Hypothesis):**
- `chain_utilities.py` — algebraic invariants on array shapes and values
- `io.py` — round-trip save/load property
- `arviz.py` — shape transformation invariants

**Poor fit (use standard pytest):**
- `dic.py` — data classes with simple construction
- `incremental_sampling.py` — criteria need realistic MCMC samples
- `model.py` — needs JAGS compilation (slow)
- `modules.py` — filesystem/system interaction

## Test Organization

```
test/
    conftest.py                    # shared fixtures and Hypothesis strategies
    test_arviz.py                  # existing (migrated to pytest style)
    test_chain_utilities.py        # NEW
    test_dic.py                    # NEW
    test_incremental_sampling.py   # NEW
    test_io.py                     # NEW
    test_model.py                  # existing (migrated to pytest style)
    test_modules.py                # existing (migrated to pytest style)
```

## Performance Budget

| Test file | Estimated time | Uses JAGS |
|-----------|---------------|-----------|
| test_chain_utilities.py | < 2s | No |
| test_io.py | < 1s | No |
| test_dic.py | < 3s | Yes (1 model) |
| test_incremental_sampling.py | < 5s | Yes (1 model) |
| test_arviz.py | < 2s | No |
| test_model.py | < 3s | Yes |
| test_modules.py | < 1s | No |
| **Total** | **< 15s** | |

## Dependencies to Add

```
# dev/test dependencies (not runtime)
pytest
hypothesis
```

These do NOT go in `install_requires` — they are development-only.
Add to a `requirements-dev.txt` or `[project.optional-dependencies]` section.

## Execution Order

1. Add pytest + hypothesis to dev deps, add conftest.py
2. Migrate existing 3 test files to pytest style
3. Write test_chain_utilities.py (Hypothesis + pytest)
4. Write test_io.py (Hypothesis + pytest)
5. Write test_dic.py (fix the logic bug on line 141)
6. Write test_incremental_sampling.py
7. Add edge case tests for arviz.py and modules.py
8. Update CI/scripts to use pytest
9. Verify full suite runs in < 15s