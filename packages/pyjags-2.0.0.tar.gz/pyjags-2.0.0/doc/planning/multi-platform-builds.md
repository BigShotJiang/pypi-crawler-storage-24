# Multi-Platform Docker Builds for PyJAGS

## Status: Deferred

## Context

The current Docker setup targets `linux/amd64` only. Supporting `linux/arm64` would
benefit developers using Apple Silicon Macs with Docker Desktop.

## JAGS Platform Support

JAGS officially supports both Intel and Apple Silicon Macs:
- https://sourceforge.net/projects/mcmc-jags/files/JAGS/4.x/Mac%20OS%20X/

The Debian `jags` package is available for `arm64` in bookworm, so the Docker approach
should work on ARM without source compilation.

## Implementation Plan

1. **Verify**: Confirm `jags` package installs cleanly on `linux/arm64` in a
   `python:3.12-bookworm` container.
2. **Build**: Use `docker buildx` with `--platform linux/amd64,linux/arm64` to produce
   multi-arch images.
3. **Test**: Run the full test suite on both architectures.
4. **CI**: If using GitHub Actions, use a matrix strategy with `runs-on` for both
   `ubuntu-latest` (amd64) and an ARM runner if available, or use QEMU emulation.

## Considerations

- **Build time**: Cross-compilation via QEMU is slow. Native ARM runners are preferable.
- **C++ extension**: The pybind11 extension (`console.cc`) should compile on ARM without
  changes, but this needs verification.
- **Image registry**: Multi-arch manifests require pushing to a registry (Docker Hub or
  GHCR). This depends on the image registry decision.

## Prerequisites

- Two-tier Docker architecture implemented (see `two-tier-docker-architecture.md`)
- CI/CD pipeline in place (Phase 2 of the two-tier plan)