# Release Plan: PyJAGS 2.0.0

## Why 2.0.0

The `modernize-python312` branch introduces breaking changes:
- Python 3.12+ required (previously 3.9+)
- ArviZ 1.0+ required (API changes: `InferenceData` → `DataTree`)
- NumPy 2.x supported (may drop NumPy 1.x compatibility in practice)
- Python 3.10/3.11 dropped

The last PyPI release was **1.3.8**. Semantic versioning calls for a major bump.

## Current State

- **Branch**: `modernize-python312` (14 commits ahead of `master`)
- **Last PyPI version**: 1.3.8
- **Git tags**: None (versioneer reports `0+untagged.119.g73d24ed`)
- **Versioneer**: Configured with empty `tag_prefix` (tags like `2.0.0`, not `v2.0.0`)
- **Build system**: `setup.py` with `python setup.py sdist`
- **Upload tool**: `twine`
- **Known issue**: `pyjags.egg-info/` is owned by root (from Docker). Must be removed
  before building the sdist.

## Pre-Release Checklist

### 1. Verify everything is clean and tested

```bash
# Ensure we're on the right branch
git checkout modernize-python312
git status                          # Should be clean

# Run the full test suite locally
python -m pytest test/ -v --tb=short

# Run the multi-Python test matrix (Docker)
./scripts/test-all-pythons 3.12 3.13
```

### 2. Fix the root-owned egg-info directory

The `pyjags.egg-info/` directory is owned by root (created during a Docker run).
It must be removed before `setup.py sdist` can work.

```bash
# Option A: use Docker to remove it
docker run --rm -v "$(pwd):/pyjags" -w /pyjags python:3.12-bookworm \
    rm -rf pyjags.egg-info

# Option B: use sudo
sudo rm -rf pyjags.egg-info
```

### 3. Merge modernize-python312 into master

```bash
git checkout master
git merge modernize-python312 --no-ff -m "Merge modernize-python312: Python 3.12+, ArviZ 1.0+, pytest, expanded test coverage"
```

**Do NOT delete the branch yet** — wait until the release is confirmed on PyPI.

### 4. Tag the release

Versioneer uses tags with no prefix (configured in `setup.cfg`: `tag_prefix = `).

```bash
git tag 2.0.0
```

Verify the version is picked up:

```bash
python setup.py --version
# Should print: 2.0.0
```

If it prints something like `2.0.0+0.g<hash>`, you're not on the tagged commit.

### 5. Push master and the tag

```bash
git push origin master
git push origin 2.0.0
```

### 6. Build the source distribution

```bash
# Clean any previous builds
rm -rf dist/ build/ pyjags.egg-info/

# Build sdist
python setup.py sdist

# Verify the archive
ls -la dist/
# Should show: pyjags-2.0.0.tar.gz

# Inspect the archive contents
tar tzf dist/pyjags-2.0.0.tar.gz | head -20
```

**Verify the sdist contains**:
- `pyjags/console.cc`
- `pyjags/*.py` (all Python modules)
- `pybind11/include/` (pybind11 headers)
- `setup.py`
- `setup.cfg`
- `versioneer.py`
- `pyjags/_version.py`
- `README.md`

**Verify it does NOT contain**:
- `test/` (unless you want it — currently MANIFEST.in doesn't exclude it)
- `.venv/`
- `notebooks/`
- `.hypothesis/`
- `.coverage`
- `*.hdf5`

### 7. Install tools

```bash
pip install twine build
```

### 8. Upload to Test PyPI

```bash
twine upload --repository-url https://test.pypi.org/legacy/ dist/pyjags-2.0.0.tar.gz
```

You'll be prompted for Test PyPI credentials. Use an API token if possible:
- Username: `__token__`
- Password: `pypi-<your-test-pypi-token>`

**To create a Test PyPI API token**: Go to https://test.pypi.org/manage/account/token/

### 9. Verify the Test PyPI upload

```bash
# Create a temporary venv to test installation
python -m venv /tmp/test-pyjags
source /tmp/test-pyjags/bin/activate

# Install from Test PyPI (with real PyPI as fallback for dependencies)
pip install numpy setuptools pybind11
pip install --no-build-isolation \
    --index-url https://test.pypi.org/simple/ \
    --extra-index-url https://pypi.org/simple/ \
    pyjags==2.0.0

# Verify
python -c "import pyjags; print(pyjags.__version__); print(pyjags.version())"
# Should print:
#   2.0.0
#   (4, 3, 2)   (or whatever JAGS version is installed)

# Run a quick smoke test
python -c "
import pyjags
import numpy as np

model = pyjags.Model(code='model { mu ~ dnorm(0, 1) }', chains=2)
samples = model.sample(100)
print('Sample shape:', samples['mu'].shape)
print('Success!')
"

# Clean up
deactivate
rm -rf /tmp/test-pyjags
```

**If anything is wrong**: Fix the issue, re-tag (delete and re-create the tag), rebuild,
and re-upload to Test PyPI. Test PyPI allows overwriting versions.

### 10. Upload to real PyPI

Only proceed if Test PyPI verification passed.

```bash
twine upload dist/pyjags-2.0.0.tar.gz
```

Credentials:
- Username: `__token__`
- Password: `pypi-<your-real-pypi-token>`

**To create a PyPI API token**: Go to https://pypi.org/manage/account/token/
Scope it to the `pyjags` project for security.

### 11. Verify the real PyPI upload

```bash
python -m venv /tmp/verify-pyjags
source /tmp/verify-pyjags/bin/activate

pip install numpy setuptools pybind11
pip install --no-build-isolation pyjags==2.0.0

python -c "import pyjags; print(pyjags.__version__)"
# Should print: 2.0.0

deactivate
rm -rf /tmp/verify-pyjags
```

### 12. Create a GitHub Release

Go to https://github.com/michaelnowotny/pyjags/releases/new

- **Tag**: `2.0.0` (select existing tag)
- **Title**: `PyJAGS 2.0.0`
- **Description**:

```markdown
## PyJAGS 2.0.0

### Breaking Changes
- **Python 3.12+ required** (previously 3.9+). ArviZ 1.0 — a core dependency —
  requires Python 3.12+.
- **ArviZ 1.0+ required**. The `from_pyjags()` converter now returns `xarray.DataTree`
  instead of `arviz.InferenceData`.

### New Features
- **ArviZ integration**: Built-in `pyjags.from_pyjags()` converter with support for
  prior samples, log-likelihood extraction, and warmup splitting.
- **Native macOS support**: Installation docs and troubleshooting for Apple Silicon
  (M1/M2/M3/M4) and Intel Macs via Homebrew.
- **Native Jupyter Lab**: `./scripts/jagslab lab` runs Jupyter Lab directly from a
  local virtual environment without Docker.

### Improvements
- Migrated test suite from unittest to pytest with Hypothesis property-based testing
  (166 tests, 80% coverage).
- Fixed logic bug in `dic.py` type validation.
- Updated all notebooks for ArviZ 1.0 API compatibility.
- Expanded README with compatibility table, installation guides, and troubleshooting.
- Docker development environment: two-tier architecture (base + lab images).
- Multi-Python testing script (`scripts/test-all-pythons`).

### Compatibility
| Component | Supported |
|-----------|-----------|
| Python | 3.12, 3.13, 3.14 |
| NumPy | 1.x and 2.x |
| ArviZ | 1.0+ |
| macOS | Intel and Apple Silicon |
| Linux | Debian/Ubuntu (tested) |
```

### 13. Post-release cleanup

```bash
# Optionally delete the feature branch
git branch -d modernize-python312
git push origin --delete modernize-python312
```

---

## Credentials Needed

| Service | URL | What you need |
|---------|-----|---------------|
| Test PyPI | https://test.pypi.org | Account + API token |
| PyPI | https://pypi.org | Account + API token (scoped to `pyjags`) |
| GitHub | https://github.com | Already authenticated |

**API token setup**: Both PyPI and Test PyPI support project-scoped API tokens. Create
them at the URLs above under Account Settings → API tokens. Store them securely (e.g.,
in a password manager). Do not commit them to the repository.

**Alternative**: Use a `~/.pypirc` file to avoid entering credentials each time:

```ini
[distutils]
index-servers =
    pypi
    testpypi

[pypi]
username = __token__
password = pypi-<your-real-token>

[testpypi]
repository = https://test.pypi.org/legacy/
username = __token__
password = pypi-<your-test-token>
```

Then use `twine upload -r testpypi dist/*` and `twine upload dist/*`.

**Important**: Set `chmod 600 ~/.pypirc` to protect your tokens.

---

## Rollback Plan

If a critical issue is discovered after PyPI upload:

1. **Yank the release** (hides from `pip install pyjags` but allows
   `pip install pyjags==2.0.0`):
   - Go to https://pypi.org/manage/project/pyjags/releases/
   - Click on 2.0.0 → "Yank release"

2. **Fix the issue** on master, tag `2.0.1`, rebuild, and upload.

3. **Do NOT delete the PyPI release** — PyPI does not allow re-uploading the same
   version number. If you delete 2.0.0, that version is permanently burned.

---

## Future Releases

For future releases, this process simplifies to:

```bash
# 1. Ensure tests pass
python -m pytest test/ -v

# 2. Tag
git tag X.Y.Z

# 3. Push
git push origin master --tags

# 4. Build and upload
rm -rf dist/ build/
python setup.py sdist
twine upload --repository-url https://test.pypi.org/legacy/ dist/*
# verify on Test PyPI...
twine upload dist/*

# 5. GitHub Release
```

Once CI is in place (Phase 2 of the modernization roadmap), this can be automated
with a GitHub Actions release workflow triggered by tag pushes.