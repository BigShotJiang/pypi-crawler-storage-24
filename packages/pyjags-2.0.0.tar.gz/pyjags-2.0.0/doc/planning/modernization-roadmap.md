# PyJAGS Modernization Roadmap

## Context

PyJAGS is a mature, working library with a solid core (pybind11 C++ bindings,
multithreaded sampling, ArviZ integration, convergence diagnostics). However, its
packaging, tooling, and discoverability lag behind modern Python ecosystem standards.
This document proposes improvements to make PyJAGS more accessible to a wider audience.

**Reference**: GitHub PR #1 (mschulist) proposed scikit-build-core, uv, ruff, and pytest.
We've already completed the pytest migration. This roadmap incorporates the valuable
ideas from that PR alongside additional improvements, organized into phases with
dependencies mapped out.

---

## Phase 1: Modern Python Packaging

**Goal**: Make `pip install pyjags` work reliably, drop legacy build machinery.

### 1.1 Migrate to `pyproject.toml` + scikit-build-core

**Current state**: `setup.py` with manual `pkg-config` calls, `setup.cfg` for versioneer
only, no `pyproject.toml`.

**Target state**: Declarative `pyproject.toml` using `scikit-build-core` as the build
backend, with a `CMakeLists.txt` to find JAGS and build the C++ extension.

**Why scikit-build-core**: It's the maintained successor to scikit-build, designed
specifically for C++ extensions. It handles cross-platform CMake builds, integrates with
pip's build isolation, and works with cibuildwheel for wheel generation.

```toml
[build-system]
requires = ["scikit-build-core>=0.10", "pybind11>=2.12", "numpy>=2.0"]
build-backend = "scikit_build_core.build"

[project]
name = "pyjags"
dynamic = ["version"]
description = "Python interface to JAGS for Bayesian analysis via MCMC"
readme = "README.md"
license = "GPL-2.0-only"
requires-python = ">=3.12"
authors = [
    { name = "Michael Nowotny", email = "nowotnym@gmail.com" },
]
classifiers = [
    "Development Status :: 4 - Beta",
    "License :: OSI Approved :: GNU General Public License v2 (GPLv2)",
    "Operating System :: POSIX",
    "Programming Language :: C++",
    "Programming Language :: Python :: 3.12",
    "Programming Language :: Python :: 3.13",
    "Programming Language :: Python :: 3.14",
    "Topic :: Scientific/Engineering",
    "Topic :: Scientific/Engineering :: Information Analysis",
]
dependencies = [
    "numpy",
    "arviz>=1.0",
    "h5py",
]

[project.optional-dependencies]
dev = [
    "pytest",
    "hypothesis",
    "pytest-cov",
    "ruff",
]

[project.urls]
Homepage = "https://github.com/michaelnowotny/pyjags"
Documentation = "https://github.com/michaelnowotny/pyjags"
Repository = "https://github.com/michaelnowotny/pyjags"
Issues = "https://github.com/michaelnowotny/pyjags/issues"

[tool.scikit-build]
cmake.version = ">=3.15"
cmake.build-type = "Release"
wheel.packages = ["pyjags"]
sdist.include = ["pyjags/console.cc"]
sdist.exclude = ["test", "notebooks", "doc", "scripts"]

[tool.scikit-build.metadata.version]
provider = "scikit_build_core.metadata.setuptools_scm"

[tool.setuptools-scm]
```

### 1.2 Write CMakeLists.txt

The CMakeLists.txt must handle:
- Finding JAGS via `pkg-config` (primary, works on Linux and macOS)
- Fallback: direct path search for conda environments and Homebrew
- Finding numpy headers
- Building the pybind11 console extension
- Setting RPATH correctly for runtime library resolution

```cmake
cmake_minimum_required(VERSION 3.15)
project(pyjags LANGUAGES CXX)

set(CMAKE_CXX_STANDARD 14)
set(CMAKE_CXX_STANDARD_REQUIRED ON)

find_package(Python3 REQUIRED COMPONENTS Interpreter Development.Module NumPy)
find_package(pybind11 REQUIRED)

# Try pkg-config first (works on most Linux and macOS setups)
find_package(PkgConfig)
if(PkgConfig_FOUND)
    pkg_check_modules(JAGS jags)
endif()

# Fallback: direct search (conda, non-standard installs)
if(NOT JAGS_FOUND)
    find_path(JAGS_INCLUDE_DIRS Console.h
        PATH_SUFFIXES JAGS
        PATHS
            /opt/homebrew/include
            /opt/homebrew/opt/jags/include
            /usr/local/include
            /usr/include
            $ENV{CONDA_PREFIX}/include
            $ENV{JAGS_HOME}/include
    )
    find_library(JAGS_LIBRARIES NAMES jags JAGS
        PATHS
            /opt/homebrew/lib
            /opt/homebrew/opt/jags/lib
            /usr/local/lib
            /usr/lib
            /usr/lib/x86_64-linux-gnu
            /usr/lib/aarch64-linux-gnu
            $ENV{CONDA_PREFIX}/lib
            $ENV{JAGS_HOME}/lib
    )
    if(JAGS_INCLUDE_DIRS AND JAGS_LIBRARIES)
        set(JAGS_FOUND TRUE)
    endif()
endif()

if(NOT JAGS_FOUND)
    message(FATAL_ERROR
        "Could not find JAGS. Install it via:\n"
        "  macOS:  brew install jags\n"
        "  Debian: sudo apt-get install jags\n"
        "  conda:  conda install -c conda-forge jags\n"
    )
endif()

message(STATUS "JAGS include: ${JAGS_INCLUDE_DIRS}")
message(STATUS "JAGS library: ${JAGS_LIBRARIES}")

pybind11_add_module(console pyjags/console.cc)
target_include_directories(console PRIVATE ${JAGS_INCLUDE_DIRS})
target_link_libraries(console PRIVATE ${JAGS_LIBRARIES} Python3::NumPy)

# Ensure libjags is found at runtime
if(JAGS_LIBRARY_DIRS)
    set_target_properties(console PROPERTIES
        BUILD_RPATH "${JAGS_LIBRARY_DIRS}"
        INSTALL_RPATH "${JAGS_LIBRARY_DIRS}"
    )
endif()

install(TARGETS console DESTINATION pyjags)
```

### 1.3 Replace versioneer with setuptools-scm

**Current state**: Versioneer generates a 460-line `_version.py` that parses git tags.

**Target state**: `setuptools-scm` (or `hatch-vcs`) reads git tags at build time and
writes a minimal version file. This is the standard approach for modern Python projects.

**Steps**:
1. Remove `versioneer.py` and `pyjags/_version.py`
2. Add `setuptools-scm` to `[build-system].requires`
3. Configure in `pyproject.toml` (shown above)
4. Update `pyjags/__init__.py` to use `importlib.metadata`:
   ```python
   from importlib.metadata import version
   __version__ = version("pyjags")
   ```
5. Remove `setup.cfg` (only contained versioneer config)
6. Remove `setup.py` (fully replaced by pyproject.toml + CMakeLists.txt)

### 1.4 Remove pybind11 git submodule

**Current state**: pybind11 is vendored as a git submodule. Users must clone with
`--recurse-submodules` or run `git submodule update --init`.

**Target state**: pybind11 is a build dependency declared in `pyproject.toml`. CMake
finds it via `find_package(pybind11 REQUIRED)`. pip installs it automatically during
build isolation.

**Steps**:
1. Remove `.gitmodules` file
2. Remove `pybind11/` directory from the repo
3. Add `pybind11>=2.12` to `[build-system].requires` (already in the proposed toml)
4. Update README to remove all `--recurse-submodules` instructions
5. Verify build works with `pip install -e .` (with build isolation)

**Benefits**: Simpler cloning, no submodule staleness issues, automatic version management.

### 1.5 Clean up dead Windows code

**Current state**: `setup.py` contains a Windows code path (`add_jags` function,
lines 60-90) that references `JAGS_HOME`, architecture detection, and `.dll` linking.
This code has never worked fully (there's a TODO about .dll vs .lib linking) and PyJAGS
doesn't claim Windows support.

**Decision needed**: Either remove the Windows code and document PyJAGS as POSIX-only,
or invest in making Windows work properly (significant effort — JAGS Windows builds,
MSVC compilation, CI testing).

**Recommendation**: Remove the dead code. If Windows demand materializes, WSL2 is a
viable path that works with the existing Linux build. Document this in README.

---

## Phase 2: CI/CD and Quality Tooling

**Goal**: Automated testing, linting, and release publishing.

### 2.1 GitHub Actions CI

**Current state**: No CI. Testing is manual via Docker or local JAGS install.

**Target state**: GitHub Actions workflow that runs on every push and PR.

**Proposed workflow** (`.github/workflows/test.yml`):

```yaml
name: Test

on:
  push:
    branches: [master]
  pull_request:
    branches: [master]

jobs:
  test:
    runs-on: ubuntu-latest
    strategy:
      matrix:
        python-version: ["3.12", "3.13"]
    steps:
      - uses: actions/checkout@v4
      - name: Install JAGS
        run: sudo apt-get update && sudo apt-get install -y jags pkg-config
      - uses: actions/setup-python@v5
        with:
          python-version: ${{ matrix.python-version }}
      - name: Install dependencies
        run: |
          pip install numpy setuptools pybind11
          pip install --no-build-isolation -e ".[dev]"
      - name: Run tests
        run: python -m pytest test/ -v --tb=short
      - name: Run tests with coverage
        run: python -m pytest test/ --cov=pyjags --cov-report=xml
      - name: Upload coverage
        uses: codecov/codecov-action@v4
        with:
          file: coverage.xml
```

**macOS CI** (separate job):

```yaml
  test-macos:
    runs-on: macos-latest
    steps:
      - uses: actions/checkout@v4
      - name: Install JAGS
        run: brew install jags
      - uses: actions/setup-python@v5
        with:
          python-version: "3.12"
      - name: Install and test
        run: |
          export PKG_CONFIG_PATH="/opt/homebrew/lib/pkgconfig:$PKG_CONFIG_PATH"
          pip install numpy setuptools pybind11
          pip install --no-build-isolation -e ".[dev]"
          python -m pytest test/ -v
```

**Note**: After Phase 1 (scikit-build-core migration), the install step simplifies to
just `pip install -e ".[dev]"` since build isolation will work properly.

### 2.2 Adopt ruff for linting and formatting

**Current state**: No linter or formatter configured.

**Target state**: ruff configured in `pyproject.toml` for both linting and formatting.

```toml
[tool.ruff]
target-version = "py312"
line-length = 88

[tool.ruff.lint]
select = [
    "E",      # pycodestyle errors
    "W",      # pycodestyle warnings
    "F",      # pyflakes
    "I",      # isort
    "UP",     # pyupgrade
    "B",      # flake8-bugbear
    "SIM",    # flake8-simplify
    "RUF",    # ruff-specific rules
]
ignore = [
    "E501",   # line too long (let formatter handle)
]

[tool.ruff.lint.isort]
known-first-party = ["pyjags"]
```

**Adoption strategy**:
1. Add ruff config to `pyproject.toml`
2. Run `ruff format` once across the codebase (single formatting commit)
3. Run `ruff check --fix` to apply safe auto-fixes
4. Add ruff to CI workflow
5. Optional: add a pre-commit hook via `.pre-commit-config.yaml`

**Important**: Do the formatting in a single commit to keep git blame useful. Do not
mix formatting changes with functional changes.

### 2.3 Pre-commit hooks (optional)

```yaml
# .pre-commit-config.yaml
repos:
  - repo: https://github.com/astral-sh/ruff-pre-commit
    rev: v0.9.0
    hooks:
      - id: ruff
        args: [--fix]
      - id: ruff-format
```

### 2.4 Codecov / coverage badges

After CI is in place, add a coverage badge to README and configure Codecov to track
coverage over time. Current coverage is 80% — set a floor at 75% to prevent regression.

---

## Phase 3: Distribution — Pre-built Wheels and conda-forge

**Goal**: Make installation painless for end users who don't have a C++ toolchain.

### 3.1 Pre-built wheels via cibuildwheel

**Current state**: Users must compile from source, requiring JAGS headers, a C++ compiler,
and pkg-config. This is the single biggest adoption barrier.

**Target state**: Pre-built wheels on PyPI for common platforms. Users run
`pip install pyjags` and it just works (assuming JAGS shared library is installed).

**Approach**: Use `cibuildwheel` in GitHub Actions to build wheels for:
- `manylinux_2_28` (x86_64, aarch64)
- `macosx_11_0` (x86_64, arm64)

**Key challenge**: JAGS shared library linkage. Two strategies:

**Strategy A — Dynamic linking (recommended first)**:
- Build wheels that dynamically link against `libjags.so` / `libjags.dylib`
- Users must have JAGS installed at runtime (via `apt`, `brew`, or `conda`)
- Simpler to implement, smaller wheel size
- Works well since most users already need JAGS

**Strategy B — Bundled JAGS (future)**:
- Use `auditwheel repair` / `delocate` to bundle `libjags` into the wheel
- Fully self-contained wheels — no system JAGS needed
- Larger wheels, more complex build, JAGS licensing implications (GPLv2 — compatible
  since PyJAGS is also GPLv2)

**Proposed workflow** (`.github/workflows/wheels.yml`):

```yaml
name: Build wheels

on:
  release:
    types: [published]
  workflow_dispatch:

jobs:
  build_wheels:
    runs-on: ${{ matrix.os }}
    strategy:
      matrix:
        os: [ubuntu-latest, macos-latest]
    steps:
      - uses: actions/checkout@v4
      - name: Install JAGS (Ubuntu)
        if: runner.os == 'Linux'
        run: sudo apt-get update && sudo apt-get install -y jags pkg-config
      - name: Install JAGS (macOS)
        if: runner.os == 'macOS'
        run: brew install jags
      - uses: pypa/cibuildwheel@v2.22
        env:
          CIBW_BUILD: "cp312-* cp313-*"
          CIBW_SKIP: "*-win* *-musllinux*"
          CIBW_BEFORE_ALL_LINUX: "yum install -y jags jags-devel || apt-get install -y jags"
      - uses: actions/upload-artifact@v4
        with:
          name: wheels-${{ matrix.os }}
          path: wheelhouse/

  publish:
    needs: build_wheels
    runs-on: ubuntu-latest
    if: github.event_name == 'release'
    steps:
      - uses: actions/download-artifact@v4
      - uses: pypa/gh-action-pypi-publish@release/v1
        with:
          packages-dir: wheels-*/
```

**Prerequisites**: Phase 1 (pyproject.toml + scikit-build-core) must be complete.

### 3.2 conda-forge package

**Why**: Many Bayesian stats users live in the conda ecosystem. JAGS is already available
on conda-forge (`conda install -c conda-forge jags`), so a PyJAGS conda-forge package
would have its JAGS dependency resolved automatically.

**Steps**:
1. Create a conda-forge feedstock recipe (`meta.yaml`)
2. Declare `jags` as a host and run dependency
3. Submit to conda-forge via staged-recipes PR
4. Maintenance: conda-forge bots will auto-update on new PyPI releases

**Example `meta.yaml` sketch**:

```yaml
package:
  name: pyjags
  version: {{ version }}

source:
  url: https://pypi.io/packages/source/p/pyjags/pyjags-{{ version }}.tar.gz
  sha256: {{ sha256 }}

build:
  number: 0
  skip: true  # [win]

requirements:
  build:
    - {{ compiler('cxx') }}
    - cmake >=3.15
    - pkg-config
  host:
    - python
    - pip
    - scikit-build-core
    - pybind11
    - numpy
    - jags
  run:
    - python
    - numpy
    - arviz >=1.0
    - h5py
    - jags

test:
  imports:
    - pyjags
```

**Prerequisites**: Phase 1 (modern packaging) and a PyPI release.

---

## Phase 4: Developer Experience and API Improvements

**Goal**: Make PyJAGS easier to use and debug.

### 4.1 Better JAGS error messages

**Current state**: JAGS syntax errors produce opaque messages:
```
console.JagsError:
Error parsing model file:
syntax error on line 3 near ";"
```

The user cannot see what line 3 contains because the model code was written to a
temporary file.

**Proposed improvement**: Catch `JagsError` in `Model.__init__`, and if the error
mentions a line number, annotate the error with the offending line(s) from the model code.

```python
# In Model.__init__, wrap the checkModel call:
try:
    self.console.checkModel(path)
except JagsError as e:
    msg = str(e)
    match = re.search(r'line (\d+)', msg)
    if match and model_code is not None:
        lineno = int(match.group(1))
        lines = model_code.splitlines()
        context_start = max(0, lineno - 3)
        context_end = min(len(lines), lineno + 2)
        context = '\n'.join(
            f'  {"-->" if i + 1 == lineno else "   "} {i + 1}: {line}'
            for i, line in enumerate(lines[context_start:context_end],
                                     start=context_start)
        )
        raise JagsError(f'{msg}\n\nModel code:\n{context}') from None
    raise
```

**Result**:
```
console.JagsError:
Error parsing model file:
syntax error on line 3 near ";"

Model code:
     1: model {
     2:     for (i in 1:N) {
  --> 3:         x[i] ~ dbern(p);
     4:     }
     5:     p ~ dbeta(1, 1)
```

**Effort**: Small. High value for new users.

### 4.2 Type annotations and `py.typed`

**Current state**: No type hints, no type stubs. IDE autocomplete is limited.

**Target state**: Full type annotations on all public API functions and classes, a
`console.pyi` stub for the C++ extension, and a `py.typed` marker.

**Scope**:

| File | Effort | Priority |
|------|--------|----------|
| `pyjags/model.py` (`Model` class) | Medium | High — most-used API |
| `pyjags/__init__.py` (re-exports) | Small | High — affects IDE discovery |
| `pyjags/chain_utilities.py` | Small | Medium |
| `pyjags/incremental_sampling.py` | Already typed | Done |
| `pyjags/arviz.py` | Small | Medium |
| `pyjags/dic.py` | Small | Medium |
| `pyjags/io.py` | Small | Low |
| `pyjags/console.pyi` (C++ stub) | Medium | High — unlocks IDE support for C++ module |

**`console.pyi` sketch** (based on the actual C++ bindings):

```python
from typing import Any
import numpy as np

class DumpType:
    DUMP_DATA: int
    DUMP_PARAMETERS: int
    DUMP_ALL: int

class FactoryType:
    SAMPLER_FACTORY: int
    MONITOR_FACTORY: int
    RNG_FACTORY: int

class Console:
    def checkModel(self, path: str) -> None: ...
    def compile(self, data: dict[str, Any], chains: int, generate_data: bool) -> None: ...
    def setParameters(self, parameters: dict[str, Any], chain: int) -> None: ...
    def setRNGname(self, name: str, chain: int) -> None: ...
    def initialize(self) -> None: ...
    def update(self, iterations: int) -> None: ...
    def setMonitor(self, name: str, thin: int, type: str) -> None: ...
    def setMonitors(self, names: tuple[str, ...], thin: int, type: str) -> None: ...
    def clearMonitor(self, name: str, type: str) -> None: ...
    def dumpState(self, type: int, chain: int) -> dict[str, Any]: ...
    def iter(self) -> int: ...
    def variableNames(self) -> list[str]: ...
    def nchain(self) -> int: ...
    def dumpMonitors(self, type: str, flat: bool) -> dict[str, np.ndarray]: ...
    def dumpSamplers(self) -> list[str]: ...
    def adaptOff(self) -> None: ...
    def checkAdaptation(self) -> bool: ...
    def isAdapting(self) -> bool: ...
    def clearModel(self) -> None: ...

    @staticmethod
    def loadModule(name: str) -> None: ...
    @staticmethod
    def unloadModule(name: str) -> None: ...
    @staticmethod
    def listModules() -> list[str]: ...
    @staticmethod
    def listFactories(type: int) -> list[tuple[str, bool]]: ...
    @staticmethod
    def setFactoryActive(name: str, type: int, active: bool) -> None: ...
    @staticmethod
    def na() -> float: ...
    @staticmethod
    def version() -> tuple[int, int, int]: ...
    @staticmethod
    def parallel_rngs(factory: str, chains: int) -> list[dict[str, Any]]: ...
```

**Steps**:
1. Create `pyjags/console.pyi` from the C++ binding definitions
2. Add `pyjags/py.typed` marker file (empty file)
3. Add type annotations to public functions incrementally
4. Optionally add mypy to CI (strict mode on typed files only)

### 4.3 Model syntax validation helper

**Current state**: The only way to check model syntax is to create a full `Model`,
which compiles the model, allocates chains, and initializes parameters.

**Proposed**: A lightweight `pyjags.check_model()` function that validates syntax
without compiling:

```python
def check_model(code: str) -> None:
    """Validate JAGS model syntax without compiling.

    Raises JagsError if the model code has syntax errors.
    """
    with tempfile.NamedTemporaryFile(mode='w', suffix='.jags', delete=False) as f:
        f.write(code)
        path = f.name
    try:
        console = Console()
        console.checkModel(path)
    finally:
        os.unlink(path)
```

**Effort**: Small — wraps an existing C++ method.

### 4.4 Progress reporting for `sample_until()`

**Current state**: `sample_until()` has a `verbose` flag that prints ESS/Rhat values
but provides no progress indication during long sampling runs.

**Proposed**: Add an optional `progress` parameter that accepts:
- `True` — use tqdm if available, fall back to print
- A callable — called with a progress dict each iteration
- `False` / `None` — silent (current behavior)

```python
def sample_until(model, criterion, ..., progress=None):
    ...
    while True:
        new_samples = model.sample(iterations=iterations, ...)
        ...
        if progress is True:
            _default_progress(current_iterations, max_iterations, criterion_values)
        elif callable(progress):
            progress({
                'iterations': current_iterations,
                'max_iterations': max_iterations,
                'criterion_satisfied': criterion_satisfied,
                'ess': ...,
                'rhat': ...,
            })
```

**Effort**: Small. Nice quality-of-life improvement.

### 4.5 Convenience diagnostics from samples

**Current state**: Users must convert to ArviZ manually before running diagnostics:

```python
samples = model.sample(5000)
idata = pyjags.from_pyjags(samples)
az.summary(idata)
az.plot_trace(idata)
```

**Proposed**: Add convenience methods that do the conversion internally:

```python
# Option A: functions in pyjags namespace
pyjags.summary(samples)           # Returns pandas DataFrame
pyjags.plot_trace(samples)        # Returns matplotlib figure

# Option B: a SampleResult wrapper class
result = model.sample(5000)       # Returns SampleResult instead of dict
result.summary()                  # Calls az.summary internally
result.plot_trace()
result['mu']                      # Dict-like access still works
result.to_arviz()                 # Explicit conversion
```

**Decision needed**: Option A is simpler and non-breaking. Option B is more Pythonic
but changes the return type of `Model.sample()` (breaking change). Option A is
recommended for now; Option B could be introduced in a major version.

**Effort**: Medium. Requires careful API design.

---

## Phase 5: Documentation and Discoverability

**Goal**: Make PyJAGS findable and understandable.

### 5.1 Documentation site (MkDocs or Sphinx)

**Current state**: README.md is the only documentation. Notebooks serve as tutorials
but aren't indexed or searchable.

**Target state**: A documentation site hosted on GitHub Pages or Read the Docs with:
- Installation guide (already in README)
- Quick start tutorial
- API reference (auto-generated from docstrings)
- Notebook gallery (rendered notebooks)
- Comparison with alternatives (PyMC, Stan, etc.) — positioning guide

**Recommended tool**: MkDocs with mkdocstrings (lighter weight than Sphinx, good for
small-to-medium projects). Alternative: Sphinx with myst-parser for Markdown support.

**Structure**:

```
docs/
    index.md                  # Landing page
    installation.md           # From README
    quickstart.md             # New: minimal working example
    api/
        model.md              # Model class reference
        sampling.md           # sample_until, convergence criteria
        chain_utilities.md    # Chain manipulation functions
        io.md                 # HDF5 persistence
        arviz.md              # ArviZ integration
    tutorials/
        eight_schools.md      # Rendered from notebook
        logistic_regression.md
    changelog.md
```

**Effort**: Medium. Most content exists; needs restructuring and hosting setup.

### 5.2 README improvements

The README is already comprehensive. Additional improvements:

- Add badges: CI status, PyPI version, conda-forge, coverage, Python versions
- Add a minimal "30-second quick start" at the top (before compatibility table)
- Add a "Why PyJAGS?" section positioning it vs. PyMC/Stan/cmdstanpy
- Add a "Contributing" section

**Quick start example for top of README**:

```python
import pyjags
import arviz as az

model = pyjags.Model(code="""
    model {
        for (i in 1:N) {
            y[i] ~ dnorm(mu, 1/sigma^2)
        }
        mu ~ dnorm(0, 0.001)
        sigma ~ dunif(0, 100)
    }
""", data={'y': [1.2, 1.8, 2.1, 1.5, 1.9], 'N': 5}, chains=4)

samples = model.sample(5000)
idata = pyjags.from_pyjags(samples)
print(az.summary(idata))
```

### 5.3 CHANGELOG

**Current state**: No changelog. Version history is only in git tags and commit messages.

**Target state**: A `CHANGELOG.md` following Keep a Changelog format, updated with each
release.

---

## Phase 6: Extended Platform and Ecosystem Support

**Goal**: Reach users on more platforms and in more workflows.

### 6.1 Multi-platform Docker builds (linux/arm64)

**Status**: Already planned in `doc/planning/multi-platform-builds.md`.

This becomes more valuable as ARM Linux servers (AWS Graviton, etc.) gain adoption.
Prerequisite: CI in place.

### 6.2 Expose JAGS sampler diagnostics

**Current state**: Users can only assess sampling quality post-hoc via ESS/Rhat. The
JAGS Console exposes `dumpSamplers()` and `checkAdaptation()`, but these aren't surfaced
in a user-friendly way.

**Proposed**: Add properties to `Model`:

```python
@property
def samplers(self) -> list[str]:
    """List of sampler types used for each stochastic node."""
    return self.console.dumpSamplers()

@property
def is_adapted(self) -> bool:
    """Whether adaptation is complete for all chains."""
    return not self.console.isAdapting()
```

**Effort**: Small — wrapping existing C++ methods.

### 6.3 Jupyter widget integration (long-term)

For Jupyter notebook users, a rich display of sampling progress with live-updating
ESS/Rhat plots would be compelling. This is a significant effort and depends on
having the diagnostics API (6.2) and progress reporting (4.4) in place first.

---

## Dependency and Ordering Summary

```
Phase 1 (Packaging)
├── 1.1 pyproject.toml + scikit-build-core
├── 1.2 CMakeLists.txt
├── 1.3 Replace versioneer with setuptools-scm
├── 1.4 Remove pybind11 submodule
└── 1.5 Clean up Windows code

Phase 2 (CI/Quality) — depends on Phase 1
├── 2.1 GitHub Actions CI
├── 2.2 Adopt ruff
├── 2.3 Pre-commit hooks
└── 2.4 Coverage badges

Phase 3 (Distribution) — depends on Phase 1 + 2
├── 3.1 Pre-built wheels (cibuildwheel)
└── 3.2 conda-forge package

Phase 4 (API) — independent, can start anytime
├── 4.1 Better error messages          ← start here (quick win)
├── 4.2 Type annotations + py.typed
├── 4.3 check_model() helper
├── 4.4 sample_until() progress
└── 4.5 Convenience diagnostics

Phase 5 (Docs) — partially independent
├── 5.1 Documentation site            ← after Phase 1 (needs stable API)
├── 5.2 README improvements           ← anytime
└── 5.3 CHANGELOG                     ← anytime

Phase 6 (Extended) — depends on Phase 2+
├── 6.1 Multi-platform Docker
├── 6.2 Sampler diagnostics API
└── 6.3 Jupyter widget (long-term)
```

## Recommended Execution Order

**Batch 1 — Quick wins (independent of packaging)**:
1. 4.1 Better error messages
2. 2.2 Adopt ruff (single formatting commit)
3. 4.3 `check_model()` helper
4. 5.2 README improvements (quick start, badges placeholder)
5. 5.3 CHANGELOG

**Batch 2 — Packaging modernization**:
6. 1.1 + 1.2 + 1.3 pyproject.toml + CMakeLists.txt + setuptools-scm
7. 1.4 Remove pybind11 submodule
8. 1.5 Remove dead Windows code

**Batch 3 — CI and quality**:
9. 2.1 GitHub Actions CI
10. 2.3 Pre-commit hooks
11. 2.4 Coverage badges

**Batch 4 — Distribution**:
12. 3.1 Pre-built wheels
13. 3.2 conda-forge

**Batch 5 — API polish**:
14. 4.2 Type annotations + console.pyi
15. 4.4 sample_until() progress
16. 4.5 Convenience diagnostics
17. 6.2 Sampler diagnostics API

**Batch 6 — Documentation site**:
18. 5.1 MkDocs site

---

## What NOT to do (from PR #1 lessons)

- **Don't move source to `src/` layout** — unnecessary churn, breaks Docker setup, no
  benefit for a single-package project with C++ extensions.
- **Don't add `deepdish`** — h5py is the standard, maintained HDF5 library. deepdish is
  unmaintained (the PR author had to use a fork).
- **Don't add `pytest` as a runtime dependency** — it's dev-only.
- **Don't commit `uv.lock`** — PyJAGS is a library, not an application. Lock files
  belong in applications.
- **Don't remove copyright headers** — GPLv2 Section 2a requires prominent notices on
  modified files.
- **Don't hardcode version** — use git tags with setuptools-scm.