# Inscribe AI Pro — All features unlocked
"""
Inscribe AI v5 — Real Fine-Tuning Platform
- On-device fine-tuning via transformers + PEFT (LoRA)
- Real RAG with sentence-transformers embeddings
- Streaming training logs
- Downloadable model + standalone chat app
"""
import os, json, re, time, uuid, hashlib, secrets, threading, shutil, zipfile, tempfile
from flask import Flask, request, jsonify, send_from_directory, make_response, Response, stream_with_context
import requests as req
from bs4 import BeautifulSoup

BASE_DIR    = os.path.dirname(os.path.abspath(__file__))
STATIC_DIR  = os.path.join(BASE_DIR, "static")
app = Flask(__name__, static_folder=STATIC_DIR, static_url_path="")
app.config["MAX_CONTENT_LENGTH"] = 500 * 1024 * 1024

@app.after_request
def add_cors(r):
    origin = request.headers.get("Origin", "")
    # Allow localhost (dev) and any netlify.app domain (production landing page)
    allowed = (
        not origin or
        "localhost" in origin or
        "127.0.0.1" in origin or
        origin.endswith(".netlify.app") or
        origin.endswith(".netlify.com")
    )
    if allowed:
        r.headers["Access-Control-Allow-Origin"] = origin or "*"
    else:
        r.headers["Access-Control-Allow-Origin"] = "*"
    r.headers["Access-Control-Allow-Credentials"] = "true"
    r.headers["Access-Control-Allow-Methods"] = "GET,POST,PATCH,DELETE,OPTIONS"
    r.headers["Access-Control-Allow-Headers"] = "Content-Type,X-Token,Authorization"
    return r

@app.route("/landing")
def landing():
    return send_from_directory(BASE_DIR, "landing.html")

@app.before_request
def options_handler():
    if request.method == "OPTIONS":
        return make_response("", 204)

DATA     = os.path.join(BASE_DIR, "data")
MODELS_D = os.path.join(DATA, "models")
os.makedirs(DATA, exist_ok=True)
os.makedirs(MODELS_D, exist_ok=True)

USERS_F    = os.path.join(DATA, "users.json")
SESSIONS_F = os.path.join(DATA, "sessions.json")
PROJECTS_F = os.path.join(DATA, "projects.json")

_file_lock = threading.Lock()

def _l(p):
    """Read JSON file safely — returns {} on any error."""
    try:
        with open(p, encoding="utf-8") as f:
            content = f.read().strip()
            if not content:
                return {}
            return json.loads(content)
    except (FileNotFoundError, json.JSONDecodeError):
        return {}
    except Exception:
        return {}

def _s(p, d):
    """Write JSON atomically — write to temp file then rename to prevent corruption."""
    tmp = p + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(d, f, indent=2, ensure_ascii=False)
    os.replace(tmp, p)  # atomic on all platforms

def gu():
    with _file_lock: return _l(USERS_F)
def gs():
    with _file_lock: return _l(SESSIONS_F)
def gp():
    with _file_lock: return _l(PROJECTS_F)
def su(d):
    with _file_lock: _s(USERS_F, d)
def ss(d):
    with _file_lock: _s(SESSIONS_F, d)
def sp(d):
    with _file_lock: _s(PROJECTS_F, d)
hpw = lambda pw: hashlib.sha256(pw.encode()).hexdigest()
tok = lambda: secrets.token_hex(32)

# Training job status store (in-memory, keyed by job_id)
_train_status = {}   # job_id -> {status, log, progress}
_train_lock   = threading.Lock()

def cur_user():
    # Support token via header (API calls) OR query param (file downloads)
    t = request.headers.get("X-Token","") or request.args.get("_t","")
    if not t: return None
    s = gs().get(t)
    if not s or time.time() - s.get("ts", 0) > 86400 * 30: return None
    return gu().get(s["uid"])

def req_auth():
    u = cur_user()
    if not u: return None, (jsonify({"error": "Not authenticated"}), 401)
    return u, None

# ── SERVE ────────────────────────────────────────────────────
@app.route("/")
def index(): return send_from_directory(STATIC_DIR, "index.html")

@app.route("/api/health")
def health():
    users = gu()
    real_users = len([u for u in users.values() if not u.get("is_admin")])
    return jsonify({"ok": True, "version": "5.0.0", "users": real_users})

@app.route("/api/admin/users/by-email/<path:email>", methods=["DELETE"])
def admin_delete_by_email(email):
    """Admin: delete a user by email — useful to clear stuck registrations."""
    _, err = req_admin()
    if err: return err
    email = email.strip().lower()
    with _file_lock:
        users = _l(USERS_F)
        uid = next((uid for uid,u in users.items() if u.get("email","").lower()==email), None)
        if not uid: return jsonify({"error": f"No user with email '{email}'"}), 404
        if users[uid].get("is_admin"): return jsonify({"error":"Cannot delete admin"}), 400
        del users[uid]
        _s(USERS_F, users)
    return jsonify({"ok": True, "deleted": email})

# ── AUTH ─────────────────────────────────────────────────────
@app.route("/api/auth/signup", methods=["POST"])
def signup():
    d = request.json or {}
    email = d.get("email","").strip().lower()
    pw    = d.get("password","")
    name  = d.get("name","").strip()
    uname = d.get("username","").strip().lower()

    # Basic validation
    if not email or not pw:
        return jsonify({"error":"Email and password required"}),400
    if len(pw) < 6:
        return jsonify({"error":"Password must be at least 6 characters"}),400
    if "@" not in email or len(email) < 4:
        return jsonify({"error":"Please enter a valid email address"}),400
    if uname and not re.match(r"^[a-z0-9_-]{3,24}$", uname):
        return jsonify({"error":"Username: 3-24 chars, letters/numbers/_ only"}),400

    # Read, check AND write under one lock — prevents race conditions
    with _file_lock:
        users = _l(USERS_F)

        # Check email (case-insensitive)
        for u in users.values():
            if u.get("email","").lower() == email:
                return jsonify({
                    "error": "That email already has an account — please sign in.",
                    "already_exists": True
                }), 400

        # Check username
        if uname:
            for u in users.values():
                if u.get("username","").lower() == uname:
                    return jsonify({"error":"Username already taken — try a different one"}),400

        # All clear — create account
        uid   = str(uuid.uuid4())[:12]
        uname = uname or re.sub(r"[^a-z0-9]","",email.split("@")[0])[:20] or "user"+uid[:4]
        users[uid] = {
            "id": uid, "email": email, "name": name or uname,
            "username": uname, "pw": hpw(pw),
            "bio": "", "avatar": "🧠",
            "plan": "free", "plan_since": time.strftime("%Y-%m-%d"),
            "created": time.strftime("%Y-%m-%d %H:%M"),
            "stars_given": [], "projects_forked": []
        }
        _s(USERS_F, users)

    # Create session (sessions use their own lock via ss())
    t2 = tok()
    with _file_lock:
        sess = _l(SESSIONS_F)
        sess[t2] = {"uid": uid, "ts": time.time()}
        _s(SESSIONS_F, sess)

    safe = {k:v for k,v in users[uid].items() if k!="pw"}
    safe["plan"] = "free"
    safe["is_admin"] = False
    return jsonify({"token": t2, "user": safe})

@app.route("/api/auth/delete-account", methods=["POST"])
def delete_own_account():
    """User deletes their own account by confirming email + password."""
    d = request.json or {}
    email = d.get("email","").strip().lower()
    pw    = d.get("password","")
    with _file_lock:
        users = _l(USERS_F)
        u = next((v for v in users.values()
                  if v.get("email","").lower()==email and v.get("pw")==hpw(pw)), None)
        if not u:
            return jsonify({"error": "Email or password incorrect"}), 401
        if u.get("is_admin"):
            return jsonify({"error": "Cannot delete admin account"}), 400
        del users[u["id"]]
        _s(USERS_F, users)
    # Clear their sessions
    with _file_lock:
        sess = _l(SESSIONS_F)
        for t2 in [t for t,s in sess.items() if s.get("uid")==u["id"]]:
            del sess[t2]
        _s(SESSIONS_F, sess)
    return jsonify({"ok": True})

@app.route("/api/admin/reset-all-users", methods=["POST"])
def admin_reset_users():
    """DANGER: wipe all non-admin users. Admin only. Useful during testing."""
    _, err = req_admin()
    if err: return err
    with _file_lock:
        users = _l(USERS_F)
        admin_users = {k:v for k,v in users.items() if v.get("is_admin")}
        _s(USERS_F, admin_users)
        _s(SESSIONS_F, {})
    return jsonify({"ok": True, "kept": len(admin_users)})


def upgrade():
    """Submit a pro upgrade request — admin approves it."""
    u, err = req_auth()
    if err: return err
    if u.get("plan") == "pro":
        return jsonify({"ok": True, "already_pro": True})
    d = request.json or {}
    requests_list = gr()
    if any(r.get("uid") == u["id"] and r.get("status") == "pending" for r in requests_list):
        return jsonify({"ok": True, "msg": "Request already submitted — the admin will review it shortly."})
    requests_list.append({
        "id": str(uuid.uuid4())[:10],
        "uid": u["id"], "email": u.get("email",""),
        "name": u.get("name",""), "username": u.get("username",""),
        "message": d.get("message","").strip()[:500],
        "status": "pending",
        "created": time.strftime("%Y-%m-%d %H:%M")
    })
    sr(requests_list)
    return jsonify({"ok": True, "msg": "Pro request sent! The admin will review and approve shortly."})

@app.route("/api/auth/login", methods=["POST"])
def login():
    d = request.json or {}
    ident = d.get("email","").strip().lower()
    pw    = d.get("password","")
    if not ident or not pw:
        return jsonify({"error":"Email and password required"}),400
    users = gu()
    u = next((v for v in users.values()
              if v.get("email","").lower()==ident or v.get("username","").lower()==ident), None)
    if not u or u.get("pw") != hpw(pw):
        return jsonify({"error":"Incorrect email or password"}),401
    t2 = tok()
    with _file_lock:
        sess = _l(SESSIONS_F)
        sess[t2] = {"uid": u["id"], "ts": time.time()}
        _s(SESSIONS_F, sess)
    safe = {k:v for k,v in u.items() if k!="pw"}
    safe.setdefault("plan","free")
    safe.setdefault("is_admin", False)
    return jsonify({"token":t2,"user":safe})

@app.route("/api/auth/me")
def me():
    u = cur_user()
    if not u: return jsonify({"error":"Not authenticated"}),401
    safe = {k:v for k,v in u.items() if k!="pw"}
    safe.setdefault("plan","free")  # backfill old accounts
    safe.setdefault("is_admin", False)
    return jsonify(safe)

@app.route("/api/auth/logout", methods=["POST"])
def logout():
    t2 = request.headers.get("X-Token","")
    if t2: sess=gs(); sess.pop(t2,None); ss(sess)
    return jsonify({"ok":True})

# ── SCRAPE ───────────────────────────────────────────────────
def _scrape_single(url, seen_urls=None):
    """Scrape one URL — returns {title, text, images, videos, links}"""
    from urllib.parse import urljoin, urlparse
    HEADERS = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Language": "en-US,en;q=0.9",
    }
    resp = req.get(url, timeout=30, headers=HEADERS, allow_redirects=True)
    resp.encoding = resp.apparent_encoding or "utf-8"
    soup = BeautifulSoup(resp.text, "lxml")
    base_domain = urlparse(url).netloc

    title = (soup.title.string or "").strip()[:300] or url[:100]

    # ── IMAGES ──
    images = []
    seen_img_urls = seen_urls or set()
    for img in soup.find_all("img"):
        src = (img.get("src") or img.get("data-src") or img.get("data-lazy-src") or "").strip()
        if not src or src.startswith("data:"): continue
        alt = (img.get("alt") or img.get("title") or "").strip()
        try:
            full_url = urljoin(url, src)
            if full_url in seen_img_urls: continue
            # Only include real images (skip icons/tiny images)
            if any(x in src.lower() for x in ["icon","logo","spinner","avatar","1x1","pixel"]): continue
            seen_img_urls.add(full_url)
            images.append({"url": full_url, "alt": alt or src.rsplit("/",1)[-1][:80]})
        except: pass

    # ── EMBEDDED YOUTUBE VIDEOS ──
    videos = []
    for iframe in soup.find_all("iframe"):
        src = iframe.get("src","")
        for pat in [r"youtube\.com/embed/([A-Za-z0-9_-]{11})",r"youtu\.be/([A-Za-z0-9_-]{11})"]:
            m = re.search(pat, src)
            if m:
                vid_id = m.group(1)
                videos.append({"vid": vid_id, "url": f"https://www.youtube.com/watch?v={vid_id}",
                               "thumb": f"https://img.youtube.com/vi/{vid_id}/hqdefault.jpg"})
                break

    # ── INTERNAL LINKS (same domain) ──
    links = []
    seen_l = set()
    for a in soup.find_all("a", href=True):
        href = a.get("href","").strip()
        if not href or href.startswith(("#","mailto:","tel:","javascript:")): continue
        try:
            full = urljoin(url, href)
            parsed = urlparse(full)
            if parsed.netloc != base_domain: continue
            clean = parsed.scheme + "://" + parsed.netloc + parsed.path
            if clean in seen_l or clean == url: continue
            seen_l.add(clean)
            link_text = a.get_text(strip=True)[:80]
            # Skip nav/footer/legal links
            if any(x in link_text.lower() for x in ["privacy","cookie","terms","contact","login","signup","cart"]): continue
            links.append({"url": clean, "text": link_text})
            if len(links) >= 30: break
        except: pass

    # ── TEXT ──
    for tag in soup(["script","style","noscript","iframe","svg","canvas","nav","footer","header"]):
        tag.decompose()
    content_root = (
        soup.find("article") or soup.find("main") or
        soup.find(id=re.compile(r"content|main|body|post|article", re.I)) or
        soup.find(class_=re.compile(r"content|main|post|article|entry", re.I)) or
        soup.find("body") or soup
    )
    raw = content_root.get_text(separator="\n", strip=True)
    lines = []
    seen_lines = set()
    for ln in raw.split("\n"):
        ln = ln.strip()
        if not ln: continue
        key = ln.lower()
        if key in seen_lines: continue
        seen_lines.add(key)
        lines.append(ln)
    text = "\n".join(lines)

    # Tables
    table_texts = []
    for table in soup.find_all("table"):
        rows = []
        for tr in table.find_all("tr"):
            cells = [td.get_text(" ", strip=True) for td in tr.find_all(["td","th"])]
            if any(c.strip() for c in cells): rows.append(" | ".join(cells))
        if rows: table_texts.append("\n".join(rows))
    if table_texts:
        text += "\n\n=== TABLES ===\n" + "\n\n".join(table_texts)

    # Meta description
    meta_desc = soup.find("meta", attrs={"name": re.compile(r"description|keywords", re.I)})
    if meta_desc:
        mc = (meta_desc.get("content") or "").strip()
        if mc and mc not in text:
            text = f"Description: {mc}\n\n" + text

    return {"title": title, "text": text, "images": images, "videos": videos, "links": links}


@app.route("/api/scrape", methods=["POST"])
def scrape():
    body       = request.json or {}
    url        = body.get("url","").strip()
    deep_crawl = body.get("deep_crawl", False)   # user toggle: follow links?
    max_pages  = min(int(body.get("max_pages", 5)), 10)  # safety limit

    if not url.startswith("http"): return jsonify({"ok":False,"error":"Invalid URL"}),400
    try:
        from urllib.parse import urlparse
        seen_img_urls = set()
        result = _scrape_single(url, seen_img_urls)

        all_text   = f"=== {result['title']} ===\n{result['text']}"
        all_images = result["images"]
        all_videos = result["videos"]
        pages_done = [url]
        child_pages = []

        # Deep crawl: follow internal links if user enabled it
        if deep_crawl and result["links"]:
            for link in result["links"][:max_pages]:
                child_url = link["url"]
                if child_url in pages_done: continue
                try:
                    child = _scrape_single(child_url, seen_img_urls)
                    pages_done.append(child_url)
                    all_text   += f"\n\n=== {child['title']} ({child_url}) ===\n{child['text']}"
                    all_images += child["images"]
                    all_videos += child["videos"]
                    child_pages.append({"url": child_url, "title": child["title"], "words": len(child["text"].split())})
                except Exception as ce:
                    print(f"[scrape-child] {child_url}: {ce}")
                    continue

        return jsonify({
            "ok":        True,
            "title":     result["title"],
            "text":      all_text,
            "words":     len(all_text.split()),
            "chars":     len(all_text),
            "images":    all_images[:40],   # cap at 40 images
            "videos":    all_videos,
            "links":     result["links"],
            "pages_scraped": pages_done,
            "child_pages":   child_pages,
            "url":       url
        })
    except Exception as e:
        return jsonify({"ok":False,"error":str(e)})



# ── YOUTUBE SUGGESTIONS ───────────────────────────────────────
@app.route("/api/youtube-suggest", methods=["POST"])
def youtube_suggest():
    """Search YouTube for related videos using yt-dlp — no API key needed."""
    body    = request.json or {}
    query   = body.get("query","").strip()
    max_res = min(int(body.get("max",6)), 12)
    if not query: return jsonify({"ok":False,"error":"Query required"}),400
    try:
        import subprocess, sys as _sys
        cmd = [
            _sys.executable, "-m", "yt_dlp",
            f"ytsearch{max_res}:{query}",
            "--dump-json", "--flat-playlist",
            "--no-check-certificate",
            "--skip-download",
        ]
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
        videos = []
        for line in result.stdout.strip().split("\n"):
            if not line.strip(): continue
            try:
                v = json.loads(line)
                vid_id = v.get("id","")
                if not vid_id: continue
                videos.append({
                    "vid_id":   vid_id,
                    "title":    v.get("title","")[:120],
                    "channel":  v.get("uploader","") or v.get("channel",""),
                    "duration": v.get("duration"),
                    "url":      f"https://www.youtube.com/watch?v={vid_id}",
                    "thumb":    f"https://img.youtube.com/vi/{vid_id}/hqdefault.jpg",
                })
            except: continue
        return jsonify({"ok":True,"videos":videos,"query":query})
    except Exception as e:
        return jsonify({"ok":False,"error":str(e)})

# ── YOUTUBE TRANSCRIPT ───────────────────────────────────────
@app.route("/api/transcript", methods=["POST"])
def transcript():
    body = request.json or {}
    raw = body.get("url","") or body.get("vid","")
    title = body.get("title","Video").strip()
    vid = raw.strip()
    for pat in [r"v=([A-Za-z0-9_-]{11})",r"youtu\.be/([A-Za-z0-9_-]{11})",r"embed/([A-Za-z0-9_-]{11})",r"shorts/([A-Za-z0-9_-]{11})"]:
        m = re.search(pat, vid)
        if m: vid=m.group(1); break
    if not re.match(r"^[A-Za-z0-9_-]{11}$", vid):
        return jsonify({"ok":False,"error":f"Cannot parse YouTube ID from: {raw[:60]}"}),400
    thumb = f"https://img.youtube.com/vi/{vid}/hqdefault.jpg"
    errors = []

    # Method 1: youtube-transcript-api (new + old API)
    try:
        from youtube_transcript_api import YouTubeTranscriptApi
        fetched = None
        def _txt(e):
            if isinstance(e, dict): return str(e.get("text",""))
            return str(getattr(e, "text", ""))
        try:
            tlist = YouTubeTranscriptApi.list_transcripts(vid)
            transcript_objs = list(tlist)
            transcript_objs.sort(key=lambda t:(0 if (not getattr(t,"is_generated",True) and "en" in getattr(t,"language_code","").lower()) else 1 if "en" in getattr(t,"language_code","").lower() else 2))
            for t in transcript_objs:
                try:
                    raw2 = t.fetch()
                    fetched = list(raw2) if hasattr(raw2,"__iter__") and not isinstance(raw2,list) else raw2
                    if fetched: break
                except: continue
        except: pass
        if not fetched:
            for langs in [["en"],["en-US","en-GB"],["en","a.en"],None]:
                try:
                    fetched = (YouTubeTranscriptApi.get_transcript(vid,languages=langs) if langs else YouTubeTranscriptApi.get_transcript(vid))
                    if fetched: break
                except: continue
        if fetched:
            txt = re.sub(r"\s+"," "," ".join(_txt(e).replace("\n"," ") for e in fetched)).strip()
            if len(txt)>80:
                try:
                    rp = req.get(f"https://www.youtube.com/watch?v={vid}",timeout=8,headers={"User-Agent":"Mozilla/5.0"})
                    tm = re.search(r'"title":"([^"]+)"',rp.text)
                    if tm: title=tm.group(1).replace("\\u0026","&")[:150]
                except: pass
                return jsonify({"ok":True,"transcript":txt,"words":len(txt.split()),"thumb":thumb,"title":title,"method":"library"})
        errors.append("library: no transcript found")
    except Exception as ex: errors.append(f"library: {str(ex)[:80]}")

    # Method 2: yt-dlp via Python module (works on Windows, Mac, Linux)
    try:
        import subprocess, tempfile as tf, sys as _sys
        with tf.TemporaryDirectory() as tmpdir:
            # Use sys.executable -m yt_dlp so it always works regardless of PATH
            cmd = [_sys.executable, "-m", "yt_dlp",
                   "--write-auto-sub", "--write-sub",
                   "--sub-lang", "en",
                   "--skip-download",
                   "--sub-format", "vtt",
                   "--no-check-certificate",
                   "--output", os.path.join(tmpdir, "%(id)s.%(ext)s"),
                   f"https://www.youtube.com/watch?v={vid}"]
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=90)
            vtts = [f for f in os.listdir(tmpdir) if f.endswith(".vtt")]
            if vtts:
                import html as _hv
                with open(os.path.join(tmpdir, vtts[0]), "r", encoding="utf-8") as vf:
                    raw3 = vf.read()
                lines = []
                for ln in raw3.split("\n"):
                    ln = ln.strip()
                    if not ln: continue
                    if "-->" in ln: continue
                    if ln.startswith("WEBVTT"): continue
                    if ln[:1].isdigit() and len(ln) < 6: continue
                    if ln.startswith("align:"): continue
                    if ln.startswith("Kind:") or ln.startswith("Language:"): continue
                    lines.append(_hv.unescape(ln))
                txt = re.sub(r"\s+", " ", " ".join(lines)).strip()
                # Remove duplicate adjacent words (VTT overlap artefact)
                txt = re.sub(r"(\b\w+\b)(\s+\1)+", r"\1", txt)
                if len(txt) > 80:
                    return jsonify({"ok":True,"transcript":txt,"words":len(txt.split()),
                                    "thumb":thumb,"title":title,"method":"yt-dlp"})
            errors.append(f"yt-dlp: no .vtt found (stderr: {result.stderr[:120]})")
    except ImportError:
        errors.append("yt-dlp: not installed — run: pip install yt-dlp")
    except subprocess.TimeoutExpired:
        errors.append("yt-dlp: timed out after 90s")
    except Exception as ex:
        errors.append(f"yt-dlp: {str(ex)[:120]}")

    # Method 3: yt-dlp audio download + OpenAI Whisper (local, no API key needed)
    try:
        import subprocess, tempfile as tf, sys as _sys
        # Quick check that whisper is available before doing the slow audio download
        whisper_check = subprocess.run(
            [_sys.executable, "-c", "import whisper"],
            capture_output=True, timeout=10
        )
        if whisper_check.returncode != 0:
            errors.append("whisper: not installed — run: pip install openai-whisper && brew install ffmpeg  (or apt install ffmpeg)")
            raise ImportError("openai-whisper not installed")

        with tf.TemporaryDirectory() as tmpdir:
            audio_path = os.path.join(tmpdir, "audio.m4a")
            # Download audio only (~few MB, much faster than video)
            cmd_dl = [
                _sys.executable, "-m", "yt_dlp",
                "-f", "bestaudio[ext=m4a]/bestaudio/best",
                "--no-playlist",
                "--no-check-certificate",
                "-o", audio_path,
                f"https://www.youtube.com/watch?v={vid}"
            ]
            dl_result = subprocess.run(cmd_dl, capture_output=True, text=True, timeout=120)
            # yt-dlp may save with a different extension; find what was saved
            saved = [f for f in os.listdir(tmpdir) if f.startswith("audio")]
            if not saved:
                errors.append(f"whisper: yt-dlp audio download failed — {dl_result.stderr[:150]}")
                raise RuntimeError("no audio file downloaded")

            actual_audio = os.path.join(tmpdir, saved[0])

            # Run Whisper transcription in a subprocess to avoid blocking the main process
            whisper_script = f"""
import whisper, json, sys
model = whisper.load_model("base")
result = model.transcribe({json.dumps(actual_audio)}, fp16=False)
print(json.dumps({{"text": result["text"]}}))
"""
            wh_result = subprocess.run(
                [_sys.executable, "-c", whisper_script],
                capture_output=True, text=True, timeout=300  # 5 min max
            )
            if wh_result.returncode != 0:
                errors.append(f"whisper: transcription failed — {wh_result.stderr[:200]}")
                raise RuntimeError("whisper subprocess failed")

            out = json.loads(wh_result.stdout.strip())
            txt = re.sub(r"\s+", " ", out.get("text", "")).strip()
            if len(txt) > 80:
                try:
                    rp = req.get(f"https://www.youtube.com/watch?v={vid}", timeout=8, headers={"User-Agent": "Mozilla/5.0"})
                    tm = re.search(r'"title":"([^"]+)"', rp.text)
                    if tm: title = tm.group(1).replace("\\u0026", "&")[:150]
                except: pass
                return jsonify({"ok": True, "transcript": txt, "words": len(txt.split()),
                                "thumb": thumb, "title": title, "method": "whisper"})
            errors.append("whisper: transcript too short")
    except ImportError:
        pass  # already logged above
    except Exception as ex:
        errors.append(f"whisper: {str(ex)[:150]}")

    return jsonify({"ok":False,"error":f"No transcript available. Details: {' | '.join(errors[:4])}"})

# ── WHISPER SETUP CHECK ──────────────────────────────────────
@app.route("/api/whisper-check", methods=["GET"])
def whisper_check():
    """Check whether Whisper + ffmpeg are installed on this machine."""
    import subprocess, sys as _sys
    results = {}
    # Check openai-whisper
    r = subprocess.run([_sys.executable, "-c", "import whisper; print(whisper.__version__)"],
                       capture_output=True, text=True, timeout=15)
    results["whisper"] = {"ok": r.returncode == 0, "version": r.stdout.strip() or None,
                          "install": "pip install openai-whisper"}
    # Check ffmpeg
    r2 = subprocess.run(["ffmpeg", "-version"], capture_output=True, text=True, timeout=10)
    ver_line = (r2.stdout or r2.stderr or "").split("\n")[0][:80]
    results["ffmpeg"] = {"ok": r2.returncode == 0, "version": ver_line or None,
                         "install": "brew install ffmpeg  (Mac) / apt install ffmpeg  (Linux) / download from ffmpeg.org (Windows)"}
    # Check yt-dlp
    r3 = subprocess.run([_sys.executable, "-m", "yt_dlp", "--version"],
                        capture_output=True, text=True, timeout=15)
    results["yt_dlp"] = {"ok": r3.returncode == 0, "version": r3.stdout.strip() or None,
                         "install": "pip install yt-dlp"}
    all_ok = all(v["ok"] for v in results.values())
    return jsonify({"ok": all_ok, "deps": results})

# ── IMAGE DESCRIPTION ────────────────────────────────────────
@app.route("/api/describe-image", methods=["POST"])
def describe_image():
    d = request.json or {}
    image_url = d.get("url",""); api_key = d.get("api_key","")
    if not api_key: return jsonify({"ok":False,"error":"OpenAI key required"}),400
    try:
        r = req.post("https://api.openai.com/v1/chat/completions",
            headers={"Authorization":f"Bearer {api_key}","Content-Type":"application/json"},
            json={"model":"gpt-4o-mini","max_tokens":300,"messages":[{"role":"user","content":[{"type":"text","text":"Describe this image in detail for an AI training dataset."},{"type":"image_url","image_url":{"url":image_url}}]}]},timeout=30)
        data = r.json()
        if "error" in data: return jsonify({"ok":False,"error":data["error"].get("message","API error")})
        return jsonify({"ok":True,"description":data["choices"][0]["message"]["content"]})
    except Exception as e: return jsonify({"ok":False,"error":str(e)})

# ── REAL ON-DEVICE FINE-TUNING ────────────────────────────────
@app.route("/api/check-finetune-deps", methods=["GET"])
def check_finetune_deps():
    """Quick check that all required fine-tuning packages are installed."""
    import subprocess, sys as _sys
    pkgs = [
        ("torch",          "pip install torch"),
        ("transformers",   "pip install transformers"),
        ("peft",           "pip install peft"),
        ("datasets",       "pip install datasets"),
        ("accelerate",     "pip install accelerate"),
    ]
    results = {}
    all_ok = True
    for pkg, install_cmd in pkgs:
        r = subprocess.run(
            [_sys.executable, "-c", f"import {pkg}; print(getattr({pkg}, '__version__', 'ok'))"],
            capture_output=True, text=True, timeout=15
        )
        ok = r.returncode == 0
        results[pkg] = {"ok": ok, "version": r.stdout.strip() or None, "install": install_cmd}
        if not ok:
            all_ok = False
    if all_ok:
        fix_cmd = None
    else:
        missing = [p for p,(d2) in results.items() if not d2["ok"]]
        fix_cmd = "pip install " + " ".join(missing)
    return jsonify({"ok": all_ok, "deps": results, "fix": fix_cmd})

@app.route("/api/finetune", methods=["POST"])
def finetune():
    """Start real on-device fine-tuning using transformers + PEFT LoRA"""
    u, err = req_auth()
    if err: return err
    d = request.json or {}
    pid        = d.get("pid","")
    model_name = d.get("model","gpt2")   # HuggingFace model ID
    pairs      = d.get("pairs",[])       # [{"q":"...","a":"..."}]
    ai_name    = d.get("ai_name","My AI")
    ai_role    = d.get("ai_role","")
    epochs     = min(int(d.get("epochs",3)), 10)
    job_id     = "ft-" + str(uuid.uuid4())[:10]

    if not pairs: return jsonify({"ok":False,"error":"No training pairs"}),400

    # Init status
    with _train_lock:
        _train_status[job_id] = {"status":"starting","log":[],"progress":0,"model_path":None,"error":None}

    def do_train():
        def log(msg, p=None):
            with _train_lock:
                _train_status[job_id]["log"].append(msg)
                if p is not None: _train_status[job_id]["progress"] = p
            print(f"[{job_id}] {msg}")

        try:
            log(f"🚀 Starting fine-tuning: {model_name}", 2)
            log(f"📦 Training pairs: {len(pairs)} | Epochs: {epochs}", 3)

            # ── Check deps ──
            try:
                import torch
                from transformers import AutoTokenizer, AutoModelForCausalLM, TrainingArguments, Trainer, DataCollatorForLanguageModeling
                from peft import LoraConfig, get_peft_model, TaskType
                import datasets as ds_lib
            except ImportError as ie:
                log(f"❌ Missing package: {ie}. Run: pip install transformers peft datasets torch accelerate", 0)
                with _train_lock: _train_status[job_id]["status"]="failed"; _train_status[job_id]["error"]=str(ie)
                return

            log(f"✅ Dependencies OK. Loading tokenizer…", 5)

            # ── Load tokenizer ──
            tokenizer = AutoTokenizer.from_pretrained(model_name)
            if tokenizer.pad_token is None:
                tokenizer.pad_token = tokenizer.eos_token
            log(f"✅ Tokenizer loaded", 10)

            # ── Build training text ──
            # Repeat each pair multiple times so the model truly learns the content.
            # Reduced from 100x to 8x per epoch — still thorough, but CPU-feasible.
            REPEATS_PER_EPOCH = 8
            actual_repeats = max(1, epochs * REPEATS_PER_EPOCH)
            log(f"📝 Training intensity: {epochs} epochs × {REPEATS_PER_EPOCH} repeats = {actual_repeats} passes per example", 14)

            sys_prompt = f"You are {ai_name}." + (f" {ai_role}" if ai_role else "")
            def make_text(p):
                q = p.get('q','').strip()
                a = p.get('a','').strip()
                return f"<|system|>{sys_prompt}<|user|>{q}<|assistant|>{a}{tokenizer.eos_token}"

            # Build expanded dataset with shuffle-repetitions
            base_texts = [make_text(p) for p in pairs]
            import random as _rnd
            texts = []
            for _ in range(actual_repeats):
                shuffled = list(base_texts)
                _rnd.shuffle(shuffled)
                texts.extend(shuffled)
            log(f"📝 Built {len(texts)} training examples ({len(base_texts)} unique × {actual_repeats} repeats)", 15)

            # ── Tokenize ──
            # CRITICAL: Do NOT set 'labels' here manually.
            # DataCollatorForLanguageModeling(mlm=False) copies input_ids→labels
            # automatically and handles variable-length padding with -100 masking.
            # Setting labels here causes a tensor-nesting crash with padding=False.
            def tokenize(examples):
                out = tokenizer(
                    examples["text"],
                    truncation=True,
                    max_length=512,
                    padding=False,   # dynamic padding handled by the collator
                )
                # Do NOT add out["labels"] here — collator does it correctly
                return out

            import datasets as ds_lib
            dataset = ds_lib.Dataset.from_dict({"text": texts})
            tokenized = dataset.map(
                tokenize, batched=True,
                remove_columns=["text"],
                batch_size=500,          # keep map batches small to avoid OOM
            )
            log(f"✅ Tokenization done ({len(tokenized)} examples)", 20)

            # ── Load model ──
            log(f"🔽 Loading model {model_name} (may take a minute)…", 22)
            import torch
            device = "cuda" if torch.cuda.is_available() else "cpu"
            log(f"💻 Using device: {device}", 24)

            model = AutoModelForCausalLM.from_pretrained(
                model_name,
                torch_dtype=torch.float32,
                low_cpu_mem_usage=True
            )
            log(f"✅ Model loaded ({sum(p.numel() for p in model.parameters())//1_000_000}M params)", 30)

            # ── Apply LoRA — correct target modules per model family ──
            model_lower = model_name.lower()
            if any(x in model_lower for x in ["gpt2","distilgpt2"]):
                target_modules = ["c_attn"]
            elif any(x in model_lower for x in ["llama","mistral","qwen","phi","gemma","tinyllama"]):
                target_modules = ["q_proj","v_proj","k_proj","o_proj"]
            elif "opt" in model_lower:
                target_modules = ["q_proj","v_proj"]
            elif "bloom" in model_lower:
                target_modules = ["query_key_value"]
            elif "falcon" in model_lower:
                target_modules = ["query_key_value"]
            elif "mpt" in model_lower:
                target_modules = ["Wqkv"]
            else:
                # Auto-detect: find all linear layer names
                target_modules = []
                for name_m, module in model.named_modules():
                    if hasattr(module, 'weight') and len(module.weight.shape) == 2:
                        leaf = name_m.split('.')[-1]
                        if any(x in leaf.lower() for x in ['q','k','v','query','key','value','attn','proj']):
                            if leaf not in target_modules:
                                target_modules.append(leaf)
                if not target_modules:
                    target_modules = None  # let PEFT auto-detect

            lora_config = LoraConfig(
                task_type=TaskType.CAUSAL_LM,
                r=16, lora_alpha=32, lora_dropout=0.05,
                target_modules=target_modules,
                bias="none",
                inference_mode=False
            )
            model = get_peft_model(model, lora_config)
            trainable = sum(p.numel() for p in model.parameters() if p.requires_grad)
            total = sum(p.numel() for p in model.parameters())
            log(f"✅ LoRA applied — training {trainable/total*100:.1f}% of params ({trainable//1000}K)", 35)

            # ── Training args — 1 epoch over expanded dataset, compatible with all transformers versions ──
            model_out = os.path.join(MODELS_D, job_id)
            os.makedirs(model_out, exist_ok=True)

            import inspect
            _ta_params = inspect.signature(TrainingArguments.__init__).parameters
            _cpu_kwargs = {}
            if "use_cpu" in _ta_params:
                _cpu_kwargs["use_cpu"] = (device == "cpu")
            elif "no_cuda" in _ta_params:
                _cpu_kwargs["no_cuda"] = (device == "cpu")

            # Compute logging frequency (~20 progress updates during training)
            effective_batch = 2 * 4
            steps_per_epoch = max(1, len(tokenized) // effective_batch)
            log_every = max(1, steps_per_epoch // 20)

            args = TrainingArguments(
                output_dir=model_out,
                num_train_epochs=1,            # repetitions already baked in
                per_device_train_batch_size=2,
                gradient_accumulation_steps=4, # effective batch=8, more stable
                learning_rate=3e-4,
                weight_decay=0.01,
                warmup_ratio=0.06,
                lr_scheduler_type="cosine",    # cosine decay → better convergence
                fp16=False,
                bf16=False,
                save_strategy="no",
                logging_steps=log_every,
                report_to="none",
                dataloader_num_workers=0,
                remove_unused_columns=False,
                group_by_length=True,          # batch similar lengths → faster + less waste
                **_cpu_kwargs,
            )

            # ── Custom callback for progress ──
            from transformers import TrainerCallback
            step_counter = [0]
            total_steps_estimate = max(1, len(tokenized) // effective_batch)

            class LogCallback(TrainerCallback):
                def on_log(self, args, state, control, logs=None, **kwargs):
                    if logs:
                        loss = logs.get("loss", None)
                        step_counter[0] += 1
                        prog = 35 + int(min(step_counter[0]/max(1,state.max_steps),1.0)*58)
                        if loss is not None:
                            msg = f"  Step {state.global_step}/{state.max_steps} — loss: {loss:.4f}"
                        else:
                            msg = f"  Step {state.global_step}/{state.max_steps}"
                        log(msg, min(prog, 93))

            # ── Train ──
            log(f"\n🔬 Training started… (page may be slow — this is normal)", 36)
            data_collator = DataCollatorForLanguageModeling(tokenizer=tokenizer, mlm=False)
            trainer = Trainer(
                model=model, args=args,
                train_dataset=tokenized,
                data_collator=data_collator,
                callbacks=[LogCallback()]
            )
            trainer.train()
            log(f"✅ Training complete!", 95)

            # ── Save final model ──
            model.save_pretrained(model_out)
            tokenizer.save_pretrained(model_out)

            # Save metadata
            meta = {
                "job_id": job_id, "pid": pid, "model_name": model_name,
                "ai_name": ai_name, "ai_role": ai_role,
                "pair_count": len(pairs), "epochs": epochs,
                "created_at": time.strftime("%Y-%m-%d %H:%M")
            }
            with open(os.path.join(model_out,"modelforge_meta.json"),"w") as f: json.dump(meta,f,indent=2)
            log(f"💾 Model saved to: {model_out}", 97)

            # Update project job
            ps = gp()
            if pid in ps:
                jobs = ps[pid].setdefault("finetune_jobs",[])
                job_rec = next((j for j in jobs if j.get("job_id")==job_id), None)
                if job_rec: job_rec.update({"status":"succeeded","model_path":model_out,"ft_model_id":job_id})
                else: jobs.append({"job_id":job_id,"status":"succeeded","type":"finetune","model_path":model_out,"ft_model_id":job_id,"model_name":model_name,"ft_name":ai_name,"ft_role":ai_role,"provider":"local","provider_label":"On-Device","source_count":d.get("source_count",0),"pair_count":len(pairs),"created_at":meta["created_at"]})
                ps[pid]["updated"] = time.strftime("%Y-%m-%d %H:%M")
                sp(ps)

            log(f"\n🎉 {ai_name} is trained and ready!", 100)
            with _train_lock: _train_status[job_id]["status"]="succeeded"; _train_status[job_id]["model_path"]=model_out

        except Exception as e:
            import traceback
            tb = traceback.format_exc()
            log(f"❌ Training failed: {str(e)}", 0)
            log(tb[:500])
            with _train_lock: _train_status[job_id]["status"]="failed"; _train_status[job_id]["error"]=str(e)

    t = threading.Thread(target=do_train, daemon=True)
    t.start()
    return jsonify({"ok":True,"job_id":job_id})

@app.route("/api/finetune/<job_id>/status")
def finetune_status(job_id):
    u, err = req_auth()
    if err: return err
    with _train_lock:
        s = _train_status.get(job_id)
    if not s: return jsonify({"error":"Job not found"}),404
    return jsonify(s)

@app.route("/api/finetune/<job_id>/stream")
def finetune_stream(job_id):
    """SSE stream of training logs"""
    def generate():
        sent = 0
        while True:
            with _train_lock:
                s = _train_status.get(job_id,{})
                logs = s.get("log",[])
                status = s.get("status","")
                progress = s.get("progress",0)
            while sent < len(logs):
                msg = logs[sent]
                yield f"data: {json.dumps({'log':msg,'progress':progress,'status':status})}\n\n"
                sent += 1
            if status in ("succeeded","failed"):
                yield f"data: {json.dumps({'done':True,'status':status,'progress':progress})}\n\n"
                break
            time.sleep(0.5)
    return Response(stream_with_context(generate()), mimetype="text/event-stream",
                    headers={"Cache-Control":"no-cache","X-Accel-Buffering":"no"})

@app.route("/api/finetune/<job_id>/chat", methods=["POST"])
def finetune_chat(job_id):
    """Chat with the locally fine-tuned model"""
    u, err = req_auth()
    if err: return err
    d = request.json or {}
    question  = d.get("question","")
    rag       = d.get("rag_knowledge", {})
    ai_name   = d.get("ai_name","AI")
    ai_role   = d.get("ai_role","")
    history   = d.get("history",[])

    with _train_lock:
        s = _train_status.get(job_id,{})
        model_path = s.get("model_path")

    # Try to find model path from disk if not in memory
    if not model_path:
        candidate = os.path.join(MODELS_D, job_id)
        if os.path.exists(candidate): model_path = candidate

    if not model_path:
        return jsonify({"ok":False,"error":f"Fine-tuned model not found on disk for job '{job_id}'. "
                        "Make sure training completed successfully (check the terminal). "
                        "If training just finished, try again in a few seconds."}), 404

    try:
        import torch
        from transformers import AutoTokenizer, AutoModelForCausalLM
        from peft import PeftModel

        # Load model — cache in app globals to avoid reloading every request
        cache_key = f"_model_{job_id}"
        if not hasattr(app, cache_key):
            log_prefix = f"[chat:{job_id[:8]}]"
            print(f"{log_prefix} Loading fine-tuned model from {model_path}…")
            meta_path = os.path.join(model_path, "modelforge_meta.json")
            if os.path.exists(meta_path):
                with open(meta_path) as f:
                    base_model_name = json.load(f).get("model_name", "gpt2")
            else:
                # Infer from adapter_config.json if meta missing
                acfg = os.path.join(model_path, "adapter_config.json")
                if os.path.exists(acfg):
                    with open(acfg) as f:
                        base_model_name = json.load(f).get("base_model_name_or_path", "gpt2")
                else:
                    base_model_name = "gpt2"
            print(f"{log_prefix} Base model: {base_model_name}")
            tok2 = AutoTokenizer.from_pretrained(model_path)
            if tok2.pad_token is None: tok2.pad_token = tok2.eos_token
            base = AutoModelForCausalLM.from_pretrained(
                base_model_name, torch_dtype=torch.float32, low_cpu_mem_usage=True
            )
            model2 = PeftModel.from_pretrained(base, model_path)
            model2.eval()
            setattr(app, cache_key, (tok2, model2))
            print(f"{log_prefix} Model loaded and cached.")

        tokenizer2, model2 = getattr(app, cache_key)

        sys_p = f"You are {ai_name}." + (f" {ai_role}" if ai_role else "")
        # Include top RAG context so fine-tuned model has knowledge to draw from
        rag_ctx = ""
        if rag:
            qwords = set(w.lower() for w in re.split(r'\W+', question) if len(w) > 2)
            stops = {'the','and','for','are','was','this','that','with','from','have',
                     'what','when','where','who','how','can','they','will','been','into'}
            qwords -= stops
            if qwords:
                scored = []
                for chunk in rag.values():
                    t = (chunk.get("text","") + " " + chunk.get("title","")).lower()
                    sc = sum(2 if chunk.get("title","").lower().find(w)>=0 else 1
                             for w in qwords if w in t)
                    if sc: scored.append((sc, chunk.get("text","")))
                scored.sort(reverse=True)
                if scored:
                    top_text = " ".join(x[1] for x in scored[:3])
                    sents = re.split(r'(?<=[.!?])\s+', top_text)
                    relevant = [s.strip() for s in sents
                                if len(s.strip()) > 20 and any(w in s.lower() for w in qwords)]
                    rag_ctx = "\n\nContext: " + " ".join(relevant[:4])[:600] if relevant else ""

        # Use same template format as training
        prompt = f"<|system|>{sys_p}{rag_ctx}<|user|>{question}<|assistant|>"
        inputs = tokenizer2(prompt, return_tensors="pt", truncation=True, max_length=450)
        input_len = inputs["input_ids"].shape[1]
        with torch.no_grad():
            out = model2.generate(
                **inputs,
                max_new_tokens=200,
                do_sample=True,
                temperature=0.5,
                top_p=0.9,
                repetition_penalty=1.3,
                pad_token_id=tokenizer2.eos_token_id,
                eos_token_id=tokenizer2.eos_token_id,
            )
        # Decode only the new tokens (not the prompt)
        new_tokens = out[0][input_len:]
        answer = tokenizer2.decode(new_tokens, skip_special_tokens=True).strip()

        # Clean up common artifacts from causal LM generation
        for marker in ["<|user|>", "<|system|>", "<|assistant|>", "Q:", "A:", "\n\nQ",
                        "Question:", "Answer:", "Human:", "Assistant:"]:
            if marker in answer:
                answer = answer.split(marker)[0].strip()
        answer = re.sub(r'\s+', ' ', answer).strip()

        # If the model output is too short or gibberish, tell the user
        words = answer.split()
        if len(words) < 3 or len(answer) < 10:
            return jsonify({"ok":True,"answer":
                f"[Model produced a very short response — try rephrasing your question or use more training data. Raw output: '{answer}']",
                "source":"finetune_short"})

        return jsonify({"ok":True,"answer":_maybe_watermark(answer, u),"source":"finetune","plan":u.get("plan","free") if u else "free"})
    except Exception as e:
        import traceback
        tb = traceback.format_exc()
        print(f"[finetune_chat error] {tb}")
        return jsonify({"ok":False,"error":f"Model inference error: {str(e)[:200]}. Check the terminal for details."}), 500

def _maybe_watermark(answer, user):
    """Append watermark for free-plan users."""
    if user and user.get("plan","free") == "free":
        return answer  # Pro version — watermark removed
    return answer

def _rag_answer(q, rag, name, persona):
    """Generate accurate answer from knowledge — includes images and better scoring."""
    if not rag:
        return f"Hi! I'm {name}. Ask me anything!"
    stops = {'the','and','for','are','was','this','that','with','from','have','what',
             'when','where','who','how','can','you','your','its','not','all','a','an',
             'is','in','of','to','do','be','at','on','it','by','up','if','so','as','we',
             'they','has','had','i','me','my','our','us','him','her','his'}
    qwords = [w.lower() for w in re.split(r'\W+', q) if len(w) > 2 and w.lower() not in stops]
    if not qwords:
        topics = list(set(c.get("title","") for c in list(rag.values())[:4]))[:3]
        return f"Hi! I'm {name}. I know about: {', '.join(t for t in topics if t)}. What would you like to know?"

    # Score chunks — bigram bonus for phrase matching
    scored = []
    bigrams = [qwords[i]+" "+qwords[i+1] for i in range(len(qwords)-1)]
    for chunk in rag.values():
        text  = chunk.get("text","")
        title = chunk.get("title","").lower()
        tl    = (text+" "+title).lower()
        sc    = sum(6 if title.find(w) >= 0 else 2 for w in qwords if w in tl)
        sc   += sum(5 for bg in bigrams if bg in tl)           # phrase match bonus
        if sc > 0:
            scored.append((sc, text, chunk.get("title",""), chunk))
    scored.sort(key=lambda x: -x[0])

    if not scored:
        return f"I don't have specific information about that. Try asking about topics I was trained on."

    # Extract best SENTENCES across top chunks
    relevant_sentences = []
    seen = set()
    for _, text, title, _ in scored[:6]:
        sents = re.split(r'(?<=[.!?])\s+', text.strip())
        for sent in sents:
            sent = sent.strip()
            if len(sent) < 25: continue
            sl   = sent.lower()
            sc2  = sum(2 for w in qwords if w in sl) + sum(3 for bg in bigrams if bg in sl)
            if sc2 > 0:
                key = sent[:50].lower()
                if key not in seen:
                    seen.add(key)
                    relevant_sentences.append((sc2, sent))

    relevant_sentences.sort(key=lambda x: -x[0])
    answer_sents = [s for _,s in relevant_sentences[:5]]
    answer = " ".join(answer_sents) if answer_sents else ""

    # Fallback to top chunk if no sentences scored
    if not answer:
        top_text = scored[0][1]
        sents = re.split(r'(?<=[.!?])\s+', top_text.strip())
        answer = " ".join(s.strip() for s in sents[:3] if len(s.strip()) > 20)

    # Clean up
    answer = re.sub(r'\s{2,}', ' ', answer).strip()
    if len(answer) > 800:
        answer = answer[:800].rsplit(' ', 1)[0] + "…"

    # ── Attach relevant image if available ──
    image_md = ""
    for _, _, _, chunk in scored[:3]:
        imgs = chunk.get("images", [])
        for img in imgs:
            img_url = img.get("url","")
            img_alt = img.get("alt","image")
            if img_url and img_url.startswith("http"):
                image_md = f"\n\n![{img_alt}]({img_url})"
                break
        if image_md: break

    return (answer if len(answer) > 20 else "I have relevant data but couldn't form a clean answer. Try rephrasing.") + image_md

@app.route("/api/finetune/<job_id>/download")
def download_model(job_id):
    """Generate a real downloadable standalone chat app with the trained model baked in"""
    u, err = req_auth()
    if err: return err

    model_path = os.path.join(MODELS_D, job_id)
    if not os.path.exists(model_path):
        return jsonify({"error": "Model not found — make sure on-device training completed successfully"}), 404

    meta_path = os.path.join(model_path, "modelforge_meta.json")
    meta = json.load(open(meta_path)) if os.path.exists(meta_path) else {}
    ai_name    = meta.get("ai_name", "My AI")
    ai_role    = meta.get("ai_role", "")
    base_model = meta.get("model_name", "gpt2")

    # ── STANDALONE app.py ──────────────────────────────────────────────────
    chat_app_py = f'''#!/usr/bin/env python3
"""
{ai_name} — Standalone AI Chat App
Generated by Inscribe AI

Setup (one time):
  pip install flask transformers peft torch accelerate sentencepiece

Run:
  python app.py

Then open: http://localhost:7860
"""
import os, json, torch
from flask import Flask, request, jsonify, send_from_directory, make_response

BASE      = os.path.dirname(os.path.abspath(__file__))
MODEL_DIR = os.path.join(BASE, "model")
app = Flask(__name__, static_folder=BASE, static_url_path="")

@app.after_request
def cors(r):
    r.headers["Access-Control-Allow-Origin"] = "*"
    r.headers["Access-Control-Allow-Headers"] = "Content-Type"
    r.headers["Access-Control-Allow-Methods"] = "GET,POST,OPTIONS"
    return r

@app.before_request
def opts():
    from flask import request as req2, make_response as mr
    if req2.method == "OPTIONS": return mr("", 204)

AI_NAME = {json.dumps(ai_name)}
AI_ROLE = {json.dumps(ai_role)}
SYS     = f"You are {{AI_NAME}}.{{chr(32)+AI_ROLE if AI_ROLE else ''}}"

print(f"Loading {{AI_NAME}}...")
try:
    from transformers import AutoTokenizer, AutoModelForCausalLM
    from peft import PeftModel
    tokenizer = AutoTokenizer.from_pretrained(MODEL_DIR)
    if tokenizer.pad_token is None: tokenizer.pad_token = tokenizer.eos_token
    base = AutoModelForCausalLM.from_pretrained(
        {json.dumps(base_model)},
        torch_dtype=torch.float32,
        low_cpu_mem_usage=True
    )
    model = PeftModel.from_pretrained(base, MODEL_DIR)
    model.eval()
    USE_LOCAL = True
    print(f"✅ {{AI_NAME}} loaded from fine-tuned weights!")
except Exception as e:
    print(f"⚠ Could not load fine-tuned model: {{e}}")
    print("   Falling back to rule-based answers from knowledge base.")
    USE_LOCAL = False
    model = tokenizer = None

# Load knowledge base if present
KB_PATH = os.path.join(BASE, "knowledge.json")
knowledge = json.load(open(KB_PATH)) if os.path.exists(KB_PATH) else {{}}

def rag_answer(q, k=knowledge):
    if not k: return None
    qw = set(w.lower() for w in q.split() if len(w)>2)
    stops = {{"the","and","for","are","was","this","that","with","from","have","what","when","where","who","how"}}
    qw -= stops
    if not qw: return None
    scored = []
    for chunk in k.values():
        t = (chunk.get("text","")+" "+chunk.get("title","")).lower()
        sc = sum(1 for w in qw if w in t)
        if sc: scored.append((sc, chunk.get("text","")))
    scored.sort(reverse=True)
    if scored:
        ctx = " ".join(x[1] for x in scored[:5])
        return ctx[:2000]
    return None

def local_generate(prompt):
    if not USE_LOCAL: return None
    try:
        inputs = tokenizer(prompt, return_tensors="pt", truncation=True, max_length=512)
        input_len = inputs["input_ids"].shape[1]
        with torch.no_grad():
            out = model.generate(
                **inputs, max_new_tokens=250,
                do_sample=True, temperature=0.5, top_p=0.9,
                repetition_penalty=1.3,
                pad_token_id=tokenizer.eos_token_id,
                eos_token_id=tokenizer.eos_token_id,
            )
        new_tokens = out[0][input_len:]
        answer = tokenizer.decode(new_tokens, skip_special_tokens=True).strip()
        for marker in ["<|user|>", "<|system|>", "<|assistant|>", "Q:", "\n\nQ"]:
            if marker in answer:
                answer = answer.split(marker)[0].strip()
        return answer if len(answer.split()) >= 3 else None
    except Exception as e:
        print(f"Generate error: {{e}}")
        return None

@app.route("/")
def index():
    return send_from_directory(BASE, "index.html")

@app.route("/chat", methods=["POST","OPTIONS"])
def chat():
    data = request.json or {{}}
    q    = data.get("question","").strip()
    if not q: return jsonify({{"answer": "Ask me something!"}})

    # Try fine-tuned model first
    ctx = rag_answer(q)
    if USE_LOCAL:
        if ctx:
            prompt = f"<|system|>{{SYS}}\\n\\nContext: {{ctx[:800]}}<|user|>{{q}}<|assistant|>"
        else:
            prompt = f"<|system|>{{SYS}}<|user|>{{q}}<|assistant|>"
        answer = local_generate(prompt)
        if answer: return jsonify({{"answer": answer}})

    # Fallback: RAG keyword answer
    if ctx:
        return jsonify({{"answer": ctx[:600]}})

    return jsonify({{"answer": f"I\\'m {{AI_NAME}}. I don\\'t have specific info on that in my knowledge base. Try rephrasing your question."}})

if __name__ == "__main__":
    print(f"\\n{'='*50}")
    print(f"  {{AI_NAME}} is running!")
    print(f"  Open http://localhost:7860 in your browser")
    print(f"{'='*50}\\n")
    app.run(host="0.0.0.0", port=7860, debug=False)
'''

    # ── STANDALONE index.html ──────────────────────────────────────────────
    chat_html = f'''<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>{ai_name}</title>
<style>
*{{margin:0;padding:0;box-sizing:border-box;}}
:root{{--bg:#0d1117;--bg2:#161b22;--s1:#1c2128;--b:#30363d;--tx:#e6edf3;--mu:#848d97;--ac:#2f81f7;--gr:#3fb950;}}
html,body{{height:100%;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;background:var(--bg);color:var(--tx);}}
body{{display:flex;flex-direction:column;height:100vh;}}
.hdr{{padding:14px 20px;border-bottom:1px solid var(--b);background:var(--bg2);display:flex;align-items:center;gap:12px;flex-shrink:0;}}
.hdr-ico{{width:38px;height:38px;border-radius:10px;background:linear-gradient(135deg,#2f81f7,#1f6feb);display:flex;align-items:center;justify-content:center;font-size:20px;}}
.hdr-name{{font-size:17px;font-weight:700;color:#fff;}}
.hdr-sub{{font-size:11px;color:var(--mu);margin-top:1px;}}
.hdr-badge{{margin-left:auto;padding:3px 10px;border-radius:99px;background:rgba(63,185,80,.12);border:1px solid rgba(63,185,80,.3);color:var(--gr);font-size:11px;font-weight:600;}}
.msgs{{flex:1;overflow-y:auto;padding:20px;display:flex;flex-direction:column;gap:14px;}}
.msgs::-webkit-scrollbar{{width:4px;}}
.msgs::-webkit-scrollbar-thumb{{background:var(--b);border-radius:2px;}}
.msg{{display:flex;flex-direction:column;animation:fadein .2s ease;}}
@keyframes fadein{{from{{opacity:0;transform:translateY(6px)}}to{{opacity:1;transform:none}}}}
.msg.user{{align-items:flex-end;}}
.msg.ai{{align-items:flex-start;}}
.bubble{{max-width:78%;padding:11px 15px;border-radius:14px;font-size:14px;line-height:1.7;word-break:break-word;white-space:pre-wrap;}}
.msg.user .bubble{{background:var(--ac);color:#fff;border-radius:14px 14px 3px 14px;}}
.msg.ai .bubble{{background:var(--s1);border:1px solid var(--b);border-radius:3px 14px 14px 14px;}}
.msg.ai .name{{font-size:11px;color:var(--mu);margin-bottom:4px;padding-left:2px;}}
.inp-bar{{padding:14px 16px;border-top:1px solid var(--b);background:var(--bg2);display:flex;gap:10px;align-items:flex-end;flex-shrink:0;}}
.inp{{flex:1;background:var(--s1);border:1px solid var(--b);border-radius:10px;padding:10px 14px;color:var(--tx);font-size:14px;font-family:inherit;outline:none;resize:none;min-height:44px;max-height:140px;transition:border-color .15s;line-height:1.5;}}
.inp:focus{{border-color:var(--ac);}}
.inp::placeholder{{color:var(--mu);}}
.send{{width:44px;height:44px;border-radius:10px;border:none;background:var(--ac);color:#fff;font-size:19px;cursor:pointer;flex-shrink:0;transition:opacity .15s;display:flex;align-items:center;justify-content:center;}}
.send:hover{{opacity:.9;}}
.send:disabled{{opacity:.35;cursor:not-allowed;}}
.dots{{display:flex;gap:4px;padding:4px 0;}}
.dots span{{width:6px;height:6px;background:var(--ac);border-radius:50%;animation:dot 1.2s ease-in-out infinite;}}
.dots span:nth-child(2){{animation-delay:.15s;}}
.dots span:nth-child(3){{animation-delay:.3s;}}
@keyframes dot{{0%,100%{{opacity:.3;transform:scale(.7)}}50%{{opacity:1;transform:scale(1.2)}}}}
</style>
</head>
<body>
<div class="hdr">
  <div class="hdr-ico">✍️</div>
  <div>
    <div class="hdr-name">{ai_name}</div>
    <div class="hdr-sub">{"Fine-tuned AI · "+ai_role[:60] if ai_role else "Fine-tuned AI · Powered by Inscribe AI"}</div>
  </div>
  <div class="hdr-badge">🟢 Online</div>
</div>
<div class="msgs" id="msgs">
  <div class="msg ai">
    <div class="name">{ai_name}</div>
    <div class="bubble">Hi! I&apos;m <b>{ai_name}</b>.{"  " + ai_role.split(".")[0]+"." if ai_role else ""} Ask me anything!</div>
  </div>
</div>
<div class="inp-bar">
  <textarea class="inp" id="inp" placeholder="Ask {ai_name} anything…" rows="1"
    onkeydown="if(event.key===\\'Enter\\'&&!event.shiftKey){{event.preventDefault();send();}}"
    oninput="this.style.height=\\'auto\\';this.style.height=Math.min(this.scrollHeight,140)+\\'px\\'"></textarea>
  <button class="send" id="send-btn" onclick="send()">↑</button>
</div>
<script>
const AI = {json.dumps(ai_name)};
let busy = false;

function addMsg(role, html, isHtml) {{
  const wrap = document.createElement("div");
  wrap.className = "msg " + role;
  if(role === "ai") {{
    const nm = document.createElement("div"); nm.className = "name"; nm.textContent = AI;
    wrap.appendChild(nm);
  }}
  const b = document.createElement("div"); b.className = "bubble";
  if(isHtml) b.innerHTML = html; else b.textContent = html;
  wrap.appendChild(b);
  const msgs = document.getElementById("msgs");
  msgs.appendChild(wrap);
  msgs.scrollTop = msgs.scrollHeight;
  return b;
}}

async function send() {{
  if(busy) return;
  const inp = document.getElementById("inp");
  const q = inp.value.trim();
  if(!q) return;
  inp.value = ""; inp.style.height = "auto";
  busy = true; document.getElementById("send-btn").disabled = true;
  addMsg("user", q);
  const thinking = addMsg("ai", '<div class="dots"><span></span><span></span><span></span></div>', true);
  try {{
    const r = await fetch("/chat", {{
      method: "POST",
      headers: {{"Content-Type": "application/json"}},
      body: JSON.stringify({{question: q}})
    }});
    const data = await r.json();
    thinking.textContent = data.answer || "I\\'m not sure about that.";
  }} catch(e) {{
    thinking.textContent = "Error: " + e.message;
  }}
  busy = false; document.getElementById("send-btn").disabled = false;
  document.getElementById("inp").focus();
}}

document.getElementById("inp").addEventListener("input", function() {{
  this.style.height = "auto";
  this.style.height = Math.min(this.scrollHeight, 140) + "px";
}});
</script>
</body>
</html>'''

    readme = f"""# {ai_name} — Standalone AI Chat App
Generated by **Inscribe AI**

## Quick Start

```bash
# 1. Install dependencies (one time)
pip install flask transformers peft torch accelerate sentencepiece

# 2. Run the app
python app.py

# 3. Open in your browser
# http://localhost:7860
```

## What's in this package

| File | Description |
|------|-------------|
| `app.py` | Flask backend — loads your fine-tuned model and serves the chat API |
| `index.html` | Clean chat UI — open via the app, not directly |
| `model/` | Your trained LoRA weights (based on `{base_model}`) |
| `knowledge.json` | Your knowledge base (RAG fallback) |
| `README.md` | This file |

## How it works

This is a **real fine-tuned model** using LoRA adapters on top of `{base_model}`.
The model was trained on your data. When you ask a question, it:
1. Tries the fine-tuned model first
2. Falls back to RAG keyword search if the model isn't confident

## Requirements

- Python 3.9+
- ~4GB RAM for small models (GPT-2, TinyLlama)
- ~8GB RAM for larger models (Phi-2, Llama)
- GPU optional but speeds things up significantly

Built with ❤️ by Inscribe AI
"""

    # ── BUILD ZIP ──────────────────────────────────────────────────────────
    tmp     = tempfile.mkdtemp()
    app_dir = os.path.join(tmp, ai_name.replace(" ","_")+"_AI")
    os.makedirs(app_dir)
    os.makedirs(os.path.join(app_dir, "model"))

    with open(os.path.join(app_dir, "app.py"),    "w", encoding="utf-8") as f: f.write(chat_app_py)
    with open(os.path.join(app_dir, "index.html"),"w", encoding="utf-8") as f: f.write(chat_html)
    with open(os.path.join(app_dir, "README.md"), "w", encoding="utf-8") as f: f.write(readme)

    # Copy trained LoRA model files
    for fname in os.listdir(model_path):
        src = os.path.join(model_path, fname)
        dst = os.path.join(app_dir, "model", fname)
        if os.path.isfile(src): shutil.copy2(src, dst)

    # Copy knowledge base if it exists in the project
    # Try to find it from the meta job_id → project
    ps = gp()
    for proj in ps.values():
        for job in proj.get("finetune_jobs", []):
            if job.get("job_id") == job_id:
                rag_k = job.get("rag_knowledge", {})
                if rag_k:
                    with open(os.path.join(app_dir,"knowledge.json"),"w",encoding="utf-8") as f:
                        json.dump(rag_k, f, ensure_ascii=False, indent=2)
                break

    zip_path = os.path.join(tmp, f"{ai_name.replace(' ','_')}_AI.zip")
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
        for root, dirs, files in os.walk(app_dir):
            for file in files:
                fp  = os.path.join(root, file)
                arc = os.path.relpath(fp, tmp)
                zf.write(fp, arc)

    from flask import send_file
    return send_file(zip_path, as_attachment=True,
                     download_name=f"{ai_name.replace(' ','_')}_AI.zip",
                     mimetype="application/zip")

# ── PROJECTS ─────────────────────────────────────────────────
@app.route("/api/projects", methods=["GET"])
def list_projects():
    u, err = req_auth()
    if err: return err
    return jsonify([p for p in gp().values() if p.get("owner")==u["id"]])

@app.route("/api/projects", methods=["POST"])
def create_project():
    u, err = req_auth()
    if err: return err
    d = request.json or {}; pid = str(uuid.uuid4())[:10]
    p = {"id":pid,"owner":u["id"],"owner_name":u.get("name",""),
         "owner_username":u.get("username",""),"owner_avatar":u.get("avatar","🧠"),
         "name":d.get("name","My Project"),"desc":d.get("desc",""),
         "project_type":d.get("project_type","rag"),  # "rag" or "finetune"
         "tags":[],"is_public":False,"is_editable":False,
         "stars":0,"forks":0,"views":0,"forked_from":None,"forked_from_name":None,
         "created":time.strftime("%Y-%m-%d %H:%M"),"updated":time.strftime("%Y-%m-%d %H:%M"),
         "sources":[],"finetune_jobs":[],"manual_text":"","ft_name":"","ft_role":"","readme":""}
    ps = gp(); ps[pid]=p; sp(ps)
    return jsonify(p)

@app.route("/api/projects/<pid>", methods=["GET"])
def get_project(pid):
    u=cur_user(); ps=gp(); p=ps.get(pid)
    if not p: return jsonify({"error":"Not found"}),404
    if not p.get("is_public") and (not u or u["id"]!=p.get("owner")):
        return jsonify({"error":"Private project"}),403
    if p.get("is_public") and u and u["id"]!=p.get("owner"):
        ps[pid]["views"]=ps[pid].get("views",0)+1; sp(ps); p=ps[pid]
    return jsonify(p)

@app.route("/api/projects/<pid>", methods=["PATCH"])
def patch_project(pid):
    u, err = req_auth()
    if err: return err
    ps = gp()
    if pid not in ps: return jsonify({"error":"Not found"}),404
    if ps[pid].get("owner")!=u["id"] and not ps[pid].get("is_editable"):
        return jsonify({"error":"Permission denied"}),403
    for k,v in (request.json or {}).items(): ps[pid][k]=v
    ps[pid]["updated"]=time.strftime("%Y-%m-%d %H:%M"); sp(ps)
    return jsonify(ps[pid])

@app.route("/api/projects/<pid>", methods=["DELETE"])
def delete_project(pid):
    u, err = req_auth()
    if err: return err
    ps = gp()
    if pid not in ps or ps[pid].get("owner")!=u["id"]: return jsonify({"error":"Not found"}),404
    # Clean up trained model if exists
    for job in ps[pid].get("finetune_jobs",[]):
        mp = os.path.join(MODELS_D, job.get("job_id",""))
        if os.path.exists(mp): shutil.rmtree(mp, ignore_errors=True)
    del ps[pid]; sp(ps)
    return jsonify({"ok":True})

@app.route("/api/projects/<pid>/publish", methods=["POST"])
def publish_project(pid):
    u, err = req_auth()
    if err: return err
    ps = gp()
    if pid not in ps or ps[pid].get("owner")!=u["id"]: return jsonify({"error":"Not found"}),404
    d = request.json or {}
    for k in ("is_public","is_editable","tags","desc","readme"):
        if k in d: ps[pid][k]=d[k]
    ps[pid]["updated"]=time.strftime("%Y-%m-%d %H:%M"); sp(ps)
    return jsonify(ps[pid])

@app.route("/api/projects/<pid>/star", methods=["POST"])
def star_project(pid):
    u, err = req_auth()
    if err: return err
    ps = gp()
    if pid not in ps or not ps[pid].get("is_public"): return jsonify({"error":"Not found"}),404
    users=gu(); starred=users[u["id"]].get("stars_given",[])
    if pid in starred:
        starred.remove(pid); ps[pid]["stars"]=max(0,ps[pid].get("stars",0)-1); action="unstarred"
    else:
        starred.append(pid); ps[pid]["stars"]=ps[pid].get("stars",0)+1; action="starred"
    users[u["id"]]["stars_given"]=starred; su(users); sp(ps)
    return jsonify({"action":action,"stars":ps[pid]["stars"]})

@app.route("/api/projects/<pid>/fork", methods=["POST"])
def fork_project(pid):
    u, err = req_auth()
    if err: return err
    ps = gp(); orig=ps.get(pid)
    if not orig or not orig.get("is_public"): return jsonify({"error":"Not public"}),404
    new_pid = str(uuid.uuid4())[:10]
    fork = {**orig,"id":new_pid,"owner":u["id"],"owner_name":u.get("name",""),
            "owner_username":u.get("username",""),"owner_avatar":u.get("avatar","🧠"),
            "name":orig["name"]+" (fork)","is_public":False,"is_editable":False,
            "stars":0,"forks":0,"views":0,"forked_from":pid,
            "forked_from_name":orig.get("owner_username","?")+"/" +orig["name"],
            "finetune_jobs":[],  # don't copy trained model jobs
            "created":time.strftime("%Y-%m-%d %H:%M"),"updated":time.strftime("%Y-%m-%d %H:%M")}
    ps[pid]["forks"]=ps[pid].get("forks",0)+1; ps[new_pid]=fork; sp(ps)
    users=gu(); users[u["id"]].setdefault("projects_forked",[]).append(pid); su(users)
    return jsonify(fork)

@app.route("/api/projects/<pid>/jobs", methods=["POST"])
def save_job(pid):
    u, err = req_auth()
    if err: return err
    ps = gp()
    if pid not in ps: return jsonify({"error":"Not found"}),404
    if ps[pid].get("owner")!=u["id"] and not ps[pid].get("is_editable"):
        return jsonify({"error":"Permission denied"}),403
    job = request.json or {}
    p = ps[pid]; p.setdefault("finetune_jobs",[])
    ex = next((j for j in p["finetune_jobs"] if j.get("job_id")==job.get("job_id")),None)
    if ex: ex.update(job)
    else: p["finetune_jobs"].append(job)
    p["updated"]=time.strftime("%Y-%m-%d %H:%M"); sp(ps)
    return jsonify({"ok":True})

ADMIN_REQUESTS_F = os.path.join(DATA, "admin_requests.json")
def gr(): 
    try:
        with open(ADMIN_REQUESTS_F, encoding="utf-8") as f: return json.load(f)
    except: return []
def sr(d): _s(ADMIN_REQUESTS_F, d)

# ── BOOTSTRAP ADMIN ACCOUNT ───────────────────────────────────
def _bootstrap_admin():
    """Create the inscribe@team admin account on first run if it doesn't exist."""
    users = gu()
    # SHA256 of "Govinda@2013" — never stored in plain text
    ADMIN_PW_HASH = "04ba82f3868fe7c1047f29d585d7354472abbc5b59132d5fba73ab93ff247a6d"
    uid = "admin-inscribe"
    if uid in users:
        # Always sync the hash in case file was reset
        users[uid]["pw"] = ADMIN_PW_HASH
        su(users)
        return
    users[uid] = {
        "id": uid, "email": "inscribe@team", "name": "Inscribe Admin",
        "username": "inscribe_admin", "pw": ADMIN_PW_HASH,
        "bio": "Platform administrator", "avatar": "🛡️",
        "plan": "pro", "plan_since": "2025-01-01",
        "is_admin": True,
        "created": time.strftime("%Y-%m-%d %H:%M"),
        "stars_given": [], "projects_forked": []
    }
    su(users)
    print("\n" + "="*50)
    print("  🛡️  Admin account ready!")
    print("  Email:    inscribe@team")
    print("  Password: [secured]")
    print("="*50 + "\n")

def req_admin():
    u, err = req_auth()
    if err: return None, err
    if not u.get("is_admin"): return None, (jsonify({"error":"Admin only"}), 403)
    return u, None

# ── PRO REQUEST (user side) ────────────────────────────────────
@app.route("/api/request-pro", methods=["POST"])
def request_pro():
    u, err = req_auth()
    if err: return err
    if u.get("plan") == "pro": return jsonify({"ok": True, "msg": "Already Pro!"})
    d = request.json or {}
    requests_list = gr()
    # Avoid duplicate requests
    if any(r.get("uid") == u["id"] and r.get("status") == "pending" for r in requests_list):
        return jsonify({"ok": True, "msg": "Request already sent! The admin will review it shortly."})
    requests_list.append({
        "id": str(uuid.uuid4())[:10],
        "uid": u["id"],
        "email": u.get("email",""),
        "name": u.get("name",""),
        "username": u.get("username",""),
        "message": d.get("message","").strip()[:500],
        "status": "pending",
        "created": time.strftime("%Y-%m-%d %H:%M")
    })
    sr(requests_list)
    return jsonify({"ok": True, "msg": "Pro request sent! You'll be notified when approved."})

# ── ADMIN ROUTES ───────────────────────────────────────────────
@app.route("/api/admin/stats")
def admin_stats():
    _, err = req_admin()
    if err: return err
    users = gu(); ps = gp()
    return jsonify({
        "total_users": len([u for u in users.values() if not u.get("is_admin")]),
        "pro_users": len([u for u in users.values() if u.get("plan")=="pro" and not u.get("is_admin")]),
        "free_users": len([u for u in users.values() if u.get("plan","free")=="free" and not u.get("is_admin")]),
        "total_projects": len(ps),
        "public_projects": len([p for p in ps.values() if p.get("is_public")]),
        "pending_pro_requests": len([r for r in gr() if r.get("status")=="pending"]),
    })

@app.route("/api/admin/users")
def admin_users():
    _, err = req_admin()
    if err: return err
    users = gu(); ps = gp()
    result = []
    for u in users.values():
        if u.get("is_admin"): continue
        proj_count = len([p for p in ps.values() if p.get("owner")==u["id"]])
        result.append({k:v for k,v in u.items() if k!="pw"} | {"project_count": proj_count})
    result.sort(key=lambda x: x.get("created",""), reverse=True)
    return jsonify(result)

@app.route("/api/admin/users/<uid>/plan", methods=["POST"])
def admin_set_plan(uid):
    _, err = req_admin()
    if err: return err
    plan = (request.json or {}).get("plan","free")
    if plan not in ("free","pro"): return jsonify({"error":"Invalid plan"}),400
    users = gu()
    if uid not in users: return jsonify({"error":"User not found"}),404
    users[uid]["plan"] = plan
    users[uid]["plan_since"] = time.strftime("%Y-%m-%d")
    su(users)
    return jsonify({"ok": True, "uid": uid, "plan": plan})

@app.route("/api/admin/users/<uid>", methods=["DELETE"])
def admin_delete_user(uid):
    _, err = req_admin()
    if err: return err
    users = gu()
    if uid not in users: return jsonify({"error":"Not found"}),404
    if users[uid].get("is_admin"): return jsonify({"error":"Cannot delete admin"}),400
    # Delete user's projects and model files
    ps = gp()
    for pid, p in list(ps.items()):
        if p.get("owner") == uid:
            for job in p.get("finetune_jobs",[]):
                mp = os.path.join(MODELS_D, job.get("job_id",""))
                if os.path.exists(mp): shutil.rmtree(mp, ignore_errors=True)
            del ps[pid]
    sp(ps)
    # Delete sessions
    sess = gs()
    for t2 in [t for t,s in sess.items() if s.get("uid")==uid]:
        del sess[t2]
    ss(sess)
    del users[uid]
    su(users)
    return jsonify({"ok": True})

@app.route("/api/admin/projects")
def admin_projects():
    _, err = req_admin()
    if err: return err
    ps = gp()
    return jsonify(list(ps.values()))

@app.route("/api/admin/projects/<pid>", methods=["DELETE"])
def admin_delete_project(pid):
    _, err = req_admin()
    if err: return err
    ps = gp()
    if pid not in ps: return jsonify({"error":"Not found"}),404
    for job in ps[pid].get("finetune_jobs",[]):
        mp = os.path.join(MODELS_D, job.get("job_id",""))
        if os.path.exists(mp): shutil.rmtree(mp, ignore_errors=True)
    del ps[pid]
    sp(ps)
    return jsonify({"ok": True})

@app.route("/api/admin/pro-requests")
def admin_pro_requests():
    _, err = req_admin()
    if err: return err
    return jsonify(gr())

@app.route("/api/admin/pro-requests/<rid>/approve", methods=["POST"])
def admin_approve_request(rid):
    _, err = req_admin()
    if err: return err
    requests_list = gr()
    req_obj = next((r for r in requests_list if r["id"]==rid), None)
    if not req_obj: return jsonify({"error":"Not found"}),404
    req_obj["status"] = "approved"
    req_obj["approved_at"] = time.strftime("%Y-%m-%d %H:%M")
    # Grant pro to user
    users = gu()
    uid = req_obj.get("uid")
    if uid and uid in users:
        users[uid]["plan"] = "pro"
        users[uid]["plan_since"] = time.strftime("%Y-%m-%d")
        su(users)
    sr(requests_list)
    return jsonify({"ok": True})

@app.route("/api/admin/pro-requests/<rid>/deny", methods=["POST"])
def admin_deny_request(rid):
    _, err = req_admin()
    if err: return err
    requests_list = gr()
    req_obj = next((r for r in requests_list if r["id"]==rid), None)
    if not req_obj: return jsonify({"error":"Not found"}),404
    req_obj["status"] = "denied"
    sr(requests_list)
    return jsonify({"ok": True})

@app.route("/api/admin/password", methods=["POST"])
def admin_set_password():
    """Admin sets their own password."""
    u, err = req_admin()
    if err: return err
    d = request.json or {}
    new_pw = d.get("password","").strip()
    if len(new_pw) < 8: return jsonify({"error":"Password must be 8+ characters"}),400
    users = gu()
    users[u["id"]]["pw"] = hpw(new_pw)
    su(users)
    return jsonify({"ok": True})



# ── MERGE MULTIPLE FINE-TUNED MODELS ────────────────────────
@app.route("/api/finetune/merge", methods=["POST"])
def merge_models():
    """Merge multiple LoRA fine-tuned models into one combined model."""
    u, err = req_auth()
    if err: return err
    d       = request.json or {}
    job_ids = d.get("job_ids", [])
    name    = d.get("name", "Merged AI")[:60]

    if len(job_ids) < 2:
        return jsonify({"ok":False,"error":"Need at least 2 models to merge"}),400

    # Verify all models exist
    model_paths = []
    for jid in job_ids:
        mp = os.path.join(MODELS_D, jid)
        if not os.path.exists(mp):
            return jsonify({"ok":False,"error":f"Model {jid} not found on disk"}),404
        model_paths.append(mp)

    merge_job_id = "merge-" + str(uuid.uuid4())[:10]
    with _train_lock:
        _train_status[merge_job_id] = {"status":"merging","log":[],"progress":0,"model_path":None}

    def do_merge():
        def log(msg, p=None):
            with _train_lock:
                _train_status[merge_job_id]["log"].append(msg)
                if p is not None: _train_status[merge_job_id]["progress"] = p
            print(f"[{merge_job_id}] {msg}")

        try:
            import torch
            from transformers import AutoTokenizer, AutoModelForCausalLM
            from peft import PeftModel
            log(f"🔀 Merging {len(model_paths)} models into '{name}'…", 5)

            # Load base model from first adapter
            meta0_path = os.path.join(model_paths[0], "modelforge_meta.json")
            acfg0      = os.path.join(model_paths[0], "adapter_config.json")
            if os.path.exists(meta0_path):
                with open(meta0_path) as f: base_model_name = json.load(f).get("model_name","gpt2")
            elif os.path.exists(acfg0):
                with open(acfg0) as f: base_model_name = json.load(f).get("base_model_name_or_path","gpt2")
            else:
                base_model_name = "gpt2"

            log(f"🔽 Loading base model: {base_model_name}", 10)
            tokenizer = AutoTokenizer.from_pretrained(model_paths[0])
            if tokenizer.pad_token is None: tokenizer.pad_token = tokenizer.eos_token
            base = AutoModelForCausalLM.from_pretrained(base_model_name, torch_dtype=torch.float32, low_cpu_mem_usage=True)
            log(f"✅ Base model loaded", 20)

            # Merge all LoRA adapters by averaging weights
            # Method: load each adapter, extract merged weights, average them
            merged_state = None
            total_models = len(model_paths)

            for i, mp in enumerate(model_paths):
                prog = 20 + int((i / total_models) * 60)
                log(f"  Loading adapter {i+1}/{total_models}: {os.path.basename(mp)}…", prog)
                try:
                    peft_model = PeftModel.from_pretrained(base, mp)
                    merged = peft_model.merge_and_unload()  # merge LoRA into base weights
                    state  = {k: v.clone().float() for k, v in merged.state_dict().items()}
                    if merged_state is None:
                        merged_state = state
                    else:
                        for k in merged_state:
                            if k in state:
                                merged_state[k] += state[k]
                    del peft_model, merged
                    if torch.cuda.is_available(): torch.cuda.empty_cache()
                except Exception as ae:
                    log(f"  ⚠ Skipping adapter {i+1}: {ae}")
                    total_models -= 1

            if merged_state is None:
                raise RuntimeError("No adapters could be loaded")

            # Average the weights
            log(f"⚙️ Averaging weights across {total_models} models…", 82)
            for k in merged_state:
                merged_state[k] = merged_state[k] / total_models

            # Save merged model
            out_path = os.path.join(MODELS_D, merge_job_id)
            os.makedirs(out_path, exist_ok=True)
            base.load_state_dict(merged_state)
            base.save_pretrained(out_path)
            tokenizer.save_pretrained(out_path)

            meta = {
                "job_id": merge_job_id, "ai_name": name,
                "model_name": base_model_name, "merged_from": job_ids,
                "created_at": time.strftime("%Y-%m-%d %H:%M"), "is_merged": True
            }
            with open(os.path.join(out_path,"modelforge_meta.json"),"w") as f:
                json.dump(meta, f, indent=2)

            log(f"🎉 Merged model '{name}' ready!", 100)
            with _train_lock:
                _train_status[merge_job_id]["status"]     = "succeeded"
                _train_status[merge_job_id]["model_path"] = out_path

        except Exception as e:
            import traceback
            log(f"❌ Merge failed: {e}", 0)
            log(traceback.format_exc()[:400])
            with _train_lock:
                _train_status[merge_job_id]["status"] = "failed"
                _train_status[merge_job_id]["error"]  = str(e)

    threading.Thread(target=do_merge, daemon=True).start()
    return jsonify({"ok":True,"merge_job_id":merge_job_id})

# ── INSTALL INFO (no source files distributed) ───────────────
@app.route("/api/download/free")
@app.route("/api/download/pro")
@app.route("/api/install-info")
def install_info():
    """Tell users how to install — never send source code."""
    u, err = req_auth()
    if err: return err
    return jsonify({
        "install_command": "pip install inscribe-ai",
        "run_command":     "inscribe-ai",
        "message":         "Training runs on your computer via the pip package."
    })

@app.route("/api/explore")
def explore():
    q=request.args.get("q","").lower().strip()
    tag=request.args.get("tag","").lower().strip()
    sort=request.args.get("sort","recent")
    page=int(request.args.get("page","1")); limit=24
    ps=gp(); public=[p for p in ps.values() if p.get("is_public")]
    if q: public=[p for p in public if q in p.get("name","").lower() or q in p.get("desc","").lower() or q in p.get("owner_username","").lower() or any(q in t.lower() for t in p.get("tags",[]))]
    if tag: public=[p for p in public if tag in [t.lower() for t in p.get("tags",[])]]
    if sort=="stars": public.sort(key=lambda p:p.get("stars",0),reverse=True)
    elif sort=="forks": public.sort(key=lambda p:p.get("forks",0),reverse=True)
    elif sort=="views": public.sort(key=lambda p:p.get("views",0),reverse=True)
    else: public.sort(key=lambda p:p.get("updated",""),reverse=True)
    total=len(public); items=public[(page-1)*limit:page*limit]
    all_tags=sorted(set(t for p in ps.values() if p.get("is_public") for t in p.get("tags",[])))
    u=cur_user(); starred=set(gu().get(u["id"],{}).get("stars_given",[])) if u else set()
    for item in items: item["i_starred"]=item["id"] in starred
    return jsonify({"items":items,"total":total,"page":page,"all_tags":all_tags})

@app.route("/api/explore/trending")
def trending():
    ps=gp(); public=[p for p in ps.values() if p.get("is_public")]
    now=time.time()
    def score(p):
        try: age=(now-time.mktime(time.strptime(p.get("updated","2024-01-01 00:00"),"%Y-%m-%d %H:%M")))/86400
        except: age=30
        return p.get("stars",0)*3+p.get("forks",0)*2+p.get("views",0)*0.1+max(0,1-age/30)*5
    public.sort(key=score,reverse=True)
    return jsonify(public[:12])

if __name__=="__main__":
    _bootstrap_admin()
    print("\n"+"="*60)
    print("  🚀  Inscribe AI v5  —  http://localhost:5050")
    print(f"  📁  Serving from: {BASE_DIR}")
    print(f"  📁  Data: {DATA}")
    print()
    print("  Real on-device fine-tuning with LoRA")
    print("  Open http://localhost:5050 in your browser")
    print("="*60+"\n")
    app.run(host="0.0.0.0", port=5050, debug=False)