"""Entry point: users run `inscribe-ai` in their terminal."""
import webbrowser, threading, time

def main():
    from inscribe_ai.server import app, _bootstrap_admin, DATA, MODELS_D
    import os
    os.makedirs(DATA, exist_ok=True)
    os.makedirs(MODELS_D, exist_ok=True)
    _bootstrap_admin()

    print("\n" + "="*55)
    print("  🚀  Inscribe AI  —  Starting...")
    print("  Opening http://localhost:5050 in your browser")
    print("="*55 + "\n")

    # Auto-open browser after 1 second
    def open_browser():
        time.sleep(1.2)
        webbrowser.open("http://localhost:5050")
    threading.Thread(target=open_browser, daemon=True).start()

    app.run(host="0.0.0.0", port=5050, debug=False)

if __name__ == "__main__":
    main()
