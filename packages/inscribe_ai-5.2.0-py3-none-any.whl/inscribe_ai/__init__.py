"""Inscribe AI — Train your own AI on your computer."""
__version__ = "5.0.0"
