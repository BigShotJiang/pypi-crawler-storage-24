"""
Basic market/limit order HTTP module for the gq-sdk.
"""

from typing import Any, Dict, List, Optional

from ._http_manager import _HTTPManager
from . import _helpers


class BasicOrdersHTTP(_HTTPManager):
    """Basic order HTTP mixin class."""

    def place_market_order(
        self,
        exchange_name: str,
        account_name: str,
        symbol: str,
        side: str,
        quantity: float,
        algorithm_type: str = "market",
        client_algo_id: Optional[str] = None,
        tpsl: Optional[Dict[str, Any]] = None,
        directives: Optional[Dict[str, Any]] = None,
        instrument_type: str = "",
        frontend_inst_type: Optional[str] = None,
        display_name: Optional[str] = None,
        mirror_accounts: Optional[List[Dict[str, Any]]] = None,
        is_proportional: Optional[bool] = None,
        round_robin: Optional[bool] = None,
        reduce_only: Optional[bool] = False,
        **kwargs,
    ) -> str:
        """Place a basic market order via /api/v5/gotrade/order/place."""
        _helpers.validate_mirror_params(is_proportional, round_robin)

        if client_algo_id is None:
            client_algo_id = _helpers.generate_client_algo_id()

        payload: Dict[str, Any] = {
            "exchange_name": exchange_name,
            "account_name": account_name,
            "symbol": symbol,
            "side": side,
            "quantity": quantity,
            "algorithm_type": algorithm_type,
            "client_algo_id": client_algo_id,
            "instrument_type": instrument_type,
            "frontend_inst_type": frontend_inst_type,
            "display_name": display_name,
            "tpsl": tpsl,
            "directives": directives,
            "reduce_only": reduce_only,
        }

        if mirror_accounts is not None:
            payload["mirror_accounts"] = mirror_accounts
        if is_proportional is not None:
            payload["is_proportional"] = is_proportional
        if round_robin is not None:
            payload["round_robin"] = round_robin

        payload.update(kwargs)

        self._submit_place_order(payload=payload, strict=True)
        return client_algo_id

    def place_limit_order(
        self,
        exchange_name: str,
        account_name: str,
        symbol: str,
        side: str,
        quantity: float,
        price: float,
        algorithm_type: str = "limit",
        client_algo_id: Optional[str] = None,
        tpsl: Optional[Dict[str, Any]] = None,
        directives: Optional[Dict[str, Any]] = None,
        instrument_type: str = "",
        frontend_inst_type: Optional[str] = None,
        display_name: Optional[str] = None,
        mirror_accounts: Optional[List[Dict[str, Any]]] = None,
        is_proportional: Optional[bool] = None,
        round_robin: Optional[bool] = None,
        reduce_only: Optional[bool] = False,
        time_in_force: Optional[str] = None,
        execution_type: Optional[str] = None,
        visibility: Optional[str] = None,
        nbbo_protection: Optional[Dict[str, Any]] = None,
        aon: Optional[bool] = None,
        min_fill_size: Optional[float] = None,
        **kwargs,
    ) -> str:
        """Place a basic limit order via /api/v5/gotrade/order/place."""
        _helpers.validate_mirror_params(is_proportional, round_robin)

        if client_algo_id is None:
            client_algo_id = _helpers.generate_client_algo_id()

        payload: Dict[str, Any] = {
            "exchange_name": exchange_name,
            "account_name": account_name,
            "symbol": symbol,
            "side": side,
            "quantity": quantity,
            "price": price,
            "algorithm_type": algorithm_type,
            "client_algo_id": client_algo_id,
            "instrument_type": instrument_type,
            "frontend_inst_type": frontend_inst_type,
            "display_name": display_name,
            "tpsl": tpsl,
            "directives": directives,
            "reduce_only": reduce_only,
            "time_in_force": time_in_force,
            "execution_type": execution_type,
            "visibility": visibility,
            "nbbo_protection": nbbo_protection,
            "aon": aon,
            "min_fill_size": min_fill_size,
        }

        if mirror_accounts is not None:
            payload["mirror_accounts"] = mirror_accounts
        if is_proportional is not None:
            payload["is_proportional"] = is_proportional
        if round_robin is not None:
            payload["round_robin"] = round_robin

        payload.update(kwargs)

        self._submit_place_order(payload=payload, strict=True)
        return client_algo_id
