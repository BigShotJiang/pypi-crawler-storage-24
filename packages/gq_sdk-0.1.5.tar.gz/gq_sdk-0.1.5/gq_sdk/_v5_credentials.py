"""
Credentials HTTP module for the gq-sdk.
"""

from typing import Any, Dict, List, Optional

from ._http_manager import _HTTPManager
from .credentials import Credentials
from .exceptions import ExchangeLoginError, FailedRequestError, NotAuthenticatedError


class CredentialsHTTP(_HTTPManager):
    """Credentials HTTP mixin class."""

    def login_exchange(
        self,
        exchange_name: str,
        account_name: str,
        api_key: str,
        api_secret: str,
        api_password: str = "",
        is_testnet: bool = True,
        mode: Optional[str] = "",
        enable_smart_order: bool = False,
        sender_comp_id: Optional[str] = None,
        trading_comp_id: Optional[str] = None,
        positions_comp_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Login to an exchange account. See documentation for details."""
        if not self.authenticated:
            raise NotAuthenticatedError(
                "Must authenticate with GoQuant before logging into an exchange"
            )

        payload = {
            "exchange_name": exchange_name,
            "account_name": account_name,
            "key": api_key,
            "secret": api_secret,
            "password": api_password,
            "is_testnet": is_testnet,
            "authenticate": True,
            "mode": mode,
            "enable_smart_order": enable_smart_order,
        }
        if sender_comp_id:
            payload["sender_comp_id"] = sender_comp_id
        if trading_comp_id:
            payload["trading_comp_id"] = trading_comp_id
        if positions_comp_id:
            payload["positions_comp_id"] = positions_comp_id

        try:
            response = self._submit_request(
                method="POST",
                path=Credentials.LOGIN,
                query=payload,
                auth_required=True,
            )

            # Return the exact API response
            return response

        except FailedRequestError as e:
            # Check if account already exists - return the API response as success
            if "already exists" in e.message.lower() or "already logged in" in e.message.lower():
                self.logger.info(e.message)
                # Return the actual API response body if available
                if e.response_body:
                    return e.response_body
                return {"type": "success", "message": e.message}

            raise ExchangeLoginError(
                message=e.message,
                exchange_name=exchange_name,
                account_name=account_name,
            )

        except Exception as e:
            raise ExchangeLoginError(
                message=str(e),
                exchange_name=exchange_name,
                account_name=account_name,
            )

    def list_credentials(self) -> list:
        """List all registered exchange credentials."""
        return self.get_credentials()

    def get_credentials(self, exchange_name: Optional[str] = None) -> List[Dict[str, Any]]:
        """Get credentials for all exchanges or a specific exchange."""
        path = (
            Credentials.GET_BY_EXCHANGE.format(exchange_name=exchange_name.lower())
            if exchange_name
            else Credentials.LIST
        )
        response = self._submit_request(method="GET", path=path, auth_required=True)

        if isinstance(response, list):
            return response
        if isinstance(response, dict) and "data" in response:
            data = response["data"]
            return data if isinstance(data, list) else [data]

        return []

    def get_credential(self, exchange_name: str, credential_id: str) -> Dict[str, Any]:
        """Get details for a specific credential."""
        path = Credentials.GET_BY_ID.format(
            exchange_name=exchange_name.lower(),
            credential_id=credential_id,
        )
        response = self._submit_request(method="GET", path=path, auth_required=True)
        if isinstance(response, dict):
            if "data" in response and isinstance(response["data"], dict):
                return response["data"]
            return response
        return {"data": response}

    def update_credential(
        self,
        exchange_name: str,
        account_name: str,
        new_account_name: str,
        key: Optional[str] = None,
        secret: Optional[str] = None,
        password: Optional[str] = None,
        mode: Optional[str] = None,
        is_testnet: Optional[bool] = None,
        enable_smart_order: Optional[bool] = None,
    ) -> Dict[str, Any]:
        """Update an existing credential."""
        payload: Dict[str, Any] = {
            "exchange_name": exchange_name,
            "account_name": account_name,
            "new_account_name": new_account_name,
            "key": key,
            "secret": secret,
            "password": password,
            "mode": mode,
            "is_testnet": is_testnet,
            "enable_smart_order": enable_smart_order,
        }
        return self._submit_request(
            method="PUT",
            path=Credentials.UPDATE,
            query=payload,
            auth_required=True,
        )

    def delete_credential(
        self,
        exchange_name: str,
        account_name: str,
    ) -> Dict[str, Any]:
        """Delete a credential."""
        payload = {
            "exchange_name": exchange_name,
            "account_name": account_name,
        }
        return self._submit_request(
            method="DELETE",
            path=Credentials.DELETE,
            query=payload,
            auth_required=True,
        )

    def list_conversion_types(self, exchange_name: str) -> List[str]:
        """List supported credential conversion types for an exchange."""
        path = Credentials.CONVERSION_TYPES.format(exchange_name=exchange_name.lower())
        response = self._submit_request(method="GET", path=path, auth_required=True)
        if isinstance(response, dict) and "data" in response and isinstance(
            response["data"], list
        ):
            return response["data"]
        if isinstance(response, list):
            return response
        return []
