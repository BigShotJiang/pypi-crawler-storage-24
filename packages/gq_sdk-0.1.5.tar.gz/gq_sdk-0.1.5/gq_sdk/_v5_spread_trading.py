"""
Spread Trading HTTP module for the gq-sdk.
"""

from typing import Any, Dict, List, Optional

from ._http_manager import _HTTPManager
from . import _helpers

# Default weight applied to hedge basket entries that omit it.
_DEFAULT_HEDGE_WEIGHT = 1.0


class SpreadTradingHTTP(_HTTPManager):
    """Spread Trading HTTP mixin class."""

    @staticmethod
    def _normalize_hedge_basket(
        hedge_basket: List[Dict[str, Any]],
    ) -> List[Dict[str, Any]]:
        """Apply defaults to each hedge basket entry.

        Required keys per entry:
            - symbol: Hedge leg symbol.
            - instrument_type: Instrument type for the hedge leg.

        Optional keys (with defaults):
            - weight: Hedge weight (default 1.0).
            - exchange_name: Defaults to the quote leg exchange on the server.
            - account_name: Defaults to the quote leg account on the server.

        Returns:
            A new list with defaults applied.

        Raises:
            ValueError: If a required key is missing from any entry.
        """
        normalized: List[Dict[str, Any]] = []
        for idx, entry in enumerate(hedge_basket):
            if "symbol" not in entry:
                raise ValueError(
                    f"hedge_basket[{idx}] is missing required key 'symbol'"
                )
            if "instrument_type" not in entry:
                raise ValueError(
                    f"hedge_basket[{idx}] is missing required key 'instrument_type'"
                )

            item: Dict[str, Any] = {
                "symbol": entry["symbol"],
                "instrument_type": entry["instrument_type"],
                "weight": entry.get("weight", _DEFAULT_HEDGE_WEIGHT),
            }

            # Pass through optional cross-exchange fields only when present
            if "exchange_name" in entry:
                item["exchange_name"] = entry["exchange_name"]
            if "account_name" in entry:
                item["account_name"] = entry["account_name"]
            if "base_instrument" in entry:
                item["base_instrument"] = entry["base_instrument"]
            if "quote_instrument" in entry:
                item["quote_instrument"] = entry["quote_instrument"]

            normalized.append(item)

        return normalized

    def place_spread_trading_order(
        self,
        exchange_name: str,
        account_name: str,
        symbol: str,
        side: str,
        quantity: float,
        spread_duration: Optional[int] = None,
        hedge_basket: Optional[List[Dict[str, Any]]] = None,
        spread_preset: Optional[str] = None,
        spread_condition_config: Optional[Dict[str, Any]] = None,
        quote_execution_config: Optional[Dict[str, Any]] = None,
        hedge_execution_config: Optional[Dict[str, Any]] = None,
        imbalance_config: Optional[Dict[str, Any]] = None,
        spread_tpsl: Optional[Dict[str, Any]] = None,
        algorithm_type: str = "spread_trading",
        client_algo_id: Optional[str] = None,
        tpsl: Optional[Dict[str, Any]] = None,
        directives: Optional[Dict[str, Any]] = None,
        instrument_type: str = "",
        mirror_accounts: Optional[List[Dict[str, Any]]] = None,
        **kwargs,
    ) -> str:
        """Place a spread trading order.

        Spread trading executes quote/hedge legs with nested configuration
        objects matching FastAPI's SpreadTradingAlgoRequest contract.

        Args:
            exchange_name: Target exchange for the quote leg (e.g. "okx").
            account_name: Account name on the exchange.
            symbol: Quote leg symbol (e.g. "BTC-USDT-SWAP").
            side: Order side for the quote leg ("buy" or "sell").
            quantity: Quote leg quantity.
            spread_duration: Optional duration for spread execution.
            hedge_basket: List of hedge leg dicts.  Required keys per entry:
                - symbol: Hedge leg symbol (e.g. "ETH-USDT-SWAP").
                - instrument_type: Instrument type (e.g. "SWAP", "SPOT").
                Optional keys:
                - weight: Hedge weight (default 1.0).
                - exchange_name: Exchange for this leg (defaults to quote exchange).
                - account_name: Account for this leg (defaults to quote account).
                - base_instrument: Base instrument identifier.
                - quote_instrument: Quote instrument identifier.
            spread_preset: Optional spread preset.
            spread_condition_config: Nested spread condition config.
            quote_execution_config: Nested quote execution config.
            hedge_execution_config: Nested hedge execution config.
            imbalance_config: Nested spread imbalance config.
            spread_tpsl: Spread-specific TPSL config.
            algorithm_type: Algorithm identifier (default "spread_trading").
            client_algo_id: Optional client-generated algorithm ID.
            tpsl: Base request TPSL object.
            directives: Base request directives object.
            instrument_type: Instrument type for the quote leg.
            mirror_accounts: List of mirror accounts to replicate the spread to.
                Each dict should include "exchange_name" and "account_name".
                Optional quantity-based allocation is supported with "quantity".
            **kwargs: Additional parameters passed to the API.

        Returns:
            The client_algo_id string.

        Raises:
            InvalidRequestError: If the API returns an error response.
            FailedRequestError: If the request fails after retries.
        """
        if client_algo_id is None:
            client_algo_id = _helpers.generate_client_algo_id()

        payload: Dict[str, Any] = {
            "exchange_name": exchange_name,
            "account_name": account_name,
            "symbol": symbol,
            "side": side,
            "quantity": quantity,
            "algorithm_type": algorithm_type,
            "spread_duration": spread_duration,
            "client_algo_id": client_algo_id,
            "instrument_type": instrument_type,
            "spread_preset": spread_preset,
            "spread_condition_config": spread_condition_config,
            "quote_execution_config": quote_execution_config,
            "hedge_execution_config": hedge_execution_config,
            "imbalance_config": imbalance_config,
            "spread_tpsl": spread_tpsl,
            "tpsl": tpsl,
            "directives": directives,
        }

        if hedge_basket is not None:
            payload["hedge_basket"] = self._normalize_hedge_basket(hedge_basket)

        if "initial_ratio" in kwargs or "threshold" in kwargs:
            raise ValueError(
                "Legacy top-level spread fields are not supported. "
                "Use spread_condition_config.initial_ratio and "
                "spread_condition_config.threshold."
            )

        if mirror_accounts is not None:
            payload["mirror_accounts"] = mirror_accounts

        payload.update(kwargs)

        self._submit_place_order(payload=payload, strict=True)

        return client_algo_id
