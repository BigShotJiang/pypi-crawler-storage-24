"""
Credentials endpoint definitions for the gq-sdk.
"""

from enum import Enum


class Credentials(str, Enum):
    """Credentials API endpoints."""

    LOGIN = "/api/v5/credentials/login"
    LIST = "/api/v5/credentials"
    GET_BY_EXCHANGE = "/api/v5/credentials/{exchange_name}"
    GET_BY_ID = "/api/v5/credentials/{exchange_name}/{credential_id}"
    UPDATE = "/api/v5/credentials/update"
    DELETE = "/api/v5/credentials/delete"
    CONVERSION_TYPES = "/api/v5/conversiontypes/{exchange_name}"

    def __str__(self) -> str:
        return self.value

    def format(self, **kwargs) -> str:
        """Format the endpoint path with the given parameters."""
        return self.value.format(**kwargs)
