"""
Market Edge HTTP module for the gq-sdk.
"""

from typing import Any, Dict, List, Optional

from ._http_manager import _HTTPManager
from . import _helpers


class MarketEdgeHTTP(_HTTPManager):
    """Market Edge HTTP mixin class."""

    def place_market_edge_order(
        self,
        exchange_name: str,
        account_name: str,
        symbol: str,
        side: str,
        quantity: float,
        duration: int = 600,
        decay_factor: float = 1.0,
        algorithm_type: str = "market_edge",
        asset1_symbol: Optional[str] = None,
        asset2_symbol: Optional[str] = None,
        ratio: Optional[Dict[str, Any]] = None,
        client_algo_id: Optional[str] = None,
        tpsl: Optional[Dict[str, Any]] = None,
        directives: Optional[Dict[str, Any]] = None,
        instrument_type: str = "",
        frontend_inst_type: Optional[str] = None,
        display_name: Optional[str] = None,
        mirror_accounts: Optional[List[Dict[str, Any]]] = None,
        is_proportional: Optional[bool] = None,
        round_robin: Optional[bool] = None,
        **kwargs,
    ) -> str:
        """Place a market edge order.

        Args:
            exchange_name: Target exchange (e.g. "okx", "binance").
            account_name: Account name on the exchange.
            symbol: Trading symbol (e.g. "BTC-USDT-SWAP").
            side: Order side ("buy" or "sell").
            quantity: Order quantity.
            duration: Execution duration in seconds.
            decay_factor: Decay rate for order execution.
            algorithm_type: Algorithm identifier (default "market_edge").
            asset1_symbol: Optional ratio leg symbol.
            asset2_symbol: Optional ratio leg symbol.
            ratio: Optional ratio configuration object.
            client_algo_id: Optional client-generated algorithm ID.
            tpsl: Structured TPSL object accepted by FastAPI schema.
            directives: Structured directives object accepted by FastAPI schema.
            instrument_type: Instrument type for the exchange.
            frontend_inst_type: Optional frontend instrument type.
            display_name: Optional display name for the order.
            mirror_accounts: List of mirror accounts to replicate trades to.
                Each dict should include "exchange_name" and "account_name".
                Optional quantity-based allocation is supported with "quantity".
            is_proportional: If True, scale mirror quantities proportionally
                by NAV (Net Asset Value) ratio.
            round_robin: If True, rotate order execution across mirror accounts
                one-at-a-time instead of executing on all simultaneously.
            **kwargs: Additional parameters passed to the API.

        Returns:
            The client_algo_id string.

        Raises:
            ValueError: If both is_proportional and round_robin are True.
            InvalidRequestError: If the API returns an error response.
            FailedRequestError: If the request fails after retries.
        """
        _helpers.validate_mirror_params(is_proportional, round_robin)

        if client_algo_id is None:
            client_algo_id = _helpers.generate_client_algo_id()

        payload: Dict[str, Any] = {
            "exchange_name": exchange_name,
            "account_name": account_name,
            "symbol": symbol,
            "side": side,
            "quantity": quantity,
            "algorithm_type": algorithm_type,
            "duration": duration,
            "decay_factor": decay_factor,
            "asset1_symbol": asset1_symbol,
            "asset2_symbol": asset2_symbol,
            "ratio": ratio,
            "client_algo_id": client_algo_id,
            "instrument_type": instrument_type,
            "frontend_inst_type": frontend_inst_type,
            "display_name": display_name,
            "tpsl": tpsl,
            "directives": directives,
        }

        # Add mirror trading parameters
        if mirror_accounts is not None:
            payload["mirror_accounts"] = mirror_accounts
        if is_proportional is not None:
            payload["is_proportional"] = is_proportional
        if round_robin is not None:
            payload["round_robin"] = round_robin

        # Add any additional kwargs
        payload.update(kwargs)

        self._submit_place_order(payload=payload, strict=True)

        return client_algo_id
