const s=globalThis.__sveltekit_jqa455?.base??"",a=globalThis.__sveltekit_jqa455?.assets??s??"";export{a,s as b};
