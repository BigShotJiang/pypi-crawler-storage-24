import{l as o,a as r}from"../chunks/Dgw2w0cG.js";export{o as load_css,r as start};
