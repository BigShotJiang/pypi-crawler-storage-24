import{a as e}from"../chunks/DzafCSUv.js";export{e as component};
