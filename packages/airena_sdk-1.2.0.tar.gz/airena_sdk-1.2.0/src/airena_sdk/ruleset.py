"""Typed ruleset parser for openra.v1 ruleset messages.

Parses the raw ruleset message into indexed dataclasses for easy lookup.
Field names and structure match ruleset.schema.json (source of truth).
"""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass(frozen=True, slots=True)
class Weapon:
    weapon_id: str
    range: float
    damage: int
    reload_ticks: int
    burst: int = 1
    min_range: float = 0.0
    projectile_speed: float = 0.0
    can_target: str = "ground"
    splash: float = 0.0
    versus: dict[str, int] = field(default_factory=dict)


@dataclass(frozen=True, slots=True)
class UnitType:
    type_id: str
    is_building: bool
    max_hp: int
    speed: float
    weapons: tuple[str, ...]
    display_name: str = ""
    armor_type: str = ""
    turn_speed: float = 0.0
    sight_range: float = 0.0
    cost: int = 0
    build_time: int = 0
    power_delta: int = 0
    prerequisites: tuple[str, ...] = ()
    transport_capacity: int = 0
    abilities: tuple[str, ...] = ()
    sell_ratio: float = 0.0
    repair_cost_factor: float = 0.0
    footprint_width: int = 1
    footprint_height: int = 1
    footprint_shape: str = ""


@dataclass(frozen=True, slots=True)
class Terrain:
    """Static terrain data from the ruleset message."""
    width: int
    height: int
    passability: str
    terrain_types: str = ""


@dataclass(frozen=True, slots=True)
class Ruleset:
    """Indexed ruleset. Created via ``Ruleset.from_msg(msg)``."""

    mod_id: str
    ruleset_id: str
    ruleset_version: str
    unit_types: dict[str, UnitType]
    weapons: dict[str, Weapon]
    terrain: Terrain | None = None

    def get_unit_type(self, type_id: str) -> UnitType | None:
        """Look up a unit type by type_id."""
        return self.unit_types.get(type_id)

    def get_weapon(self, weapon_id: str) -> Weapon | None:
        """Look up a weapon by weapon_id."""
        return self.weapons.get(weapon_id)

    def weapon_range(self, type_id: str) -> float:
        """Max range of a unit type's first weapon (0.0 if none)."""
        ut = self.unit_types.get(type_id)
        if ut is None or not ut.weapons:
            return 0.0
        w = self.weapons.get(ut.weapons[0])
        return w.range if w is not None else 0.0

    def buildings(self) -> list[UnitType]:
        """All unit types that are buildings."""
        return [ut for ut in self.unit_types.values() if ut.is_building]

    def mobile_units(self) -> list[UnitType]:
        """All unit types that are not buildings."""
        return [ut for ut in self.unit_types.values() if not ut.is_building]

    @classmethod
    def from_msg(cls, msg: dict) -> Ruleset:
        """Parse a raw ruleset message dict into an indexed Ruleset."""
        weapons = {}
        for w in msg["weapons"]:
            weapons[w["weapon_id"]] = Weapon(
                weapon_id=w["weapon_id"],
                range=w["range"],
                damage=w["damage"],
                reload_ticks=w["reload_ticks"],
                burst=w.get("burst", 1),
                min_range=w.get("min_range", 0.0),
                projectile_speed=w.get("projectile_speed", 0.0),
                can_target=w.get("can_target", "ground"),
                splash=w.get("splash", 0.0),
                versus=w.get("versus", {}),
            )

        unit_types = {}
        for u in msg["unit_types"]:
            unit_types[u["type_id"]] = UnitType(
                type_id=u["type_id"],
                is_building=u["is_building"],
                max_hp=u["max_hp"],
                speed=u["speed"],
                weapons=tuple(u["weapons"]),
                display_name=u.get("display_name", ""),
                armor_type=u.get("armor_type", ""),
                turn_speed=u.get("turn_speed", 0.0),
                sight_range=u.get("sight_range", 0.0),
                cost=u.get("cost", 0),
                build_time=u.get("build_time", 0),
                power_delta=u.get("power_delta", 0),
                prerequisites=tuple(u.get("prerequisites", [])),
                transport_capacity=u.get("transport_capacity", 0),
                abilities=tuple(u.get("abilities", [])),
                sell_ratio=u.get("sell_ratio", 0.0),
                repair_cost_factor=u.get("repair_cost_factor", 0.0),
                footprint_width=u.get("footprint_width", 1),
                footprint_height=u.get("footprint_height", 1),
                footprint_shape=u.get("footprint_shape", ""),
            )

        terrain = None
        t = msg.get("terrain")
        if t is not None:
            terrain = Terrain(
                width=t["width"],
                height=t["height"],
                passability=t["passability"],
                terrain_types=t.get("terrain_types", ""),
            )

        return cls(
            mod_id=msg["mod_id"],
            ruleset_id=msg["ruleset_id"],
            ruleset_version=msg["ruleset_version"],
            unit_types=unit_types,
            weapons=weapons,
            terrain=terrain,
        )
