"""Typed observation parser for openra.v1 tick messages.

Parses raw tick message dicts into frozen dataclasses with named fields.
Field names and structure match tick.schema.json (source of truth).
"""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass(frozen=True, slots=True)
class Resources:
    cash: int
    power: int


@dataclass(frozen=True, slots=True)
class ProductionItem:
    item_type_id: str
    progress: float
    done: bool
    paused: bool
    ticks_remaining: int | None = None
    status: str | None = None


@dataclass(frozen=True, slots=True)
class ProductionQueue:
    queue_type: str
    enabled: bool
    queue_length: int
    items: tuple[ProductionItem, ...]
    buildable_items: tuple[str, ...]

    def first_done(self) -> str | None:
        """Return type_id of first completed item, or None."""
        for item in self.items:
            if item.done:
                return item.item_type_id
        return None


@dataclass(frozen=True, slots=True)
class ActionResult:
    action: str
    status: str
    unit_id: int | None = None
    detail: str | None = None
    placement_detail: str | None = None


@dataclass(frozen=True, slots=True)
class Veterancy:
    level: int = 0
    progress: float = 0.0


@dataclass(frozen=True, slots=True)
class Passenger:
    id: int
    type_id: str


@dataclass(frozen=True, slots=True)
class Unit:
    id: int
    type_id: str
    x: int
    y: int
    hp: int
    max_hp: int
    facing: int
    cooldowns: dict[str, int]
    can_deploy: bool = False
    current_order: str = ""
    cargo_ratio: float | None = None
    harvester_state: str | None = None
    refinery_queue: int | None = None
    veterancy: Veterancy | None = None
    stance: str | None = None
    passenger_count: int | None = None
    passengers: tuple[Passenger, ...] = ()
    repairing: bool | None = None


@dataclass(frozen=True, slots=True)
class EnemyUnit:
    id: int
    type_id: str
    x: int
    y: int
    hp: int
    max_hp: int
    facing: int | None = None
    current_order: str | None = None


@dataclass(frozen=True, slots=True)
class ResourceCell:
    x: int
    y: int
    kind: str
    density: float | None = None


@dataclass(frozen=True, slots=True)
class MapInfo:
    width: int
    height: int
    buildable: str | None = None


@dataclass(frozen=True, slots=True)
class MatchStats:
    units_killed: int = 0
    buildings_killed: int = 0
    units_lost: int = 0
    buildings_lost: int = 0
    total_earned: int = 0
    total_spent: int = 0
    army_value: int = 0


@dataclass(frozen=True, slots=True)
class Superweapon:
    type_id: str
    ready: bool = False
    ticks_remaining: int = 0


@dataclass(frozen=True, slots=True)
class GameEvent:
    event: str
    tick: int
    unit_id: int | None = None
    type_id: str | None = None
    x: int | None = None
    y: int | None = None
    detail: str | None = None


@dataclass(frozen=True, slots=True)
class SelfInfo:
    player_id: int
    faction: str
    resources: Resources
    production_queues: tuple[ProductionQueue, ...]
    placement_pending: bool = False
    placement_type_id: str | None = None
    build_queue: tuple[ProductionItem, ...] = ()
    action_results: tuple[ActionResult, ...] = ()
    actions_dropped: int = 0
    explored_ratio: float | None = None
    match_stats: MatchStats | None = None
    superweapons: tuple[Superweapon, ...] = ()

    def queue_for(self, queue_type: str) -> ProductionQueue | None:
        """Find a production queue by type (case-insensitive)."""
        key = queue_type.lower()
        for q in self.production_queues:
            if q.queue_type.lower() == key:
                return q
        return None

    def buildable_in(self, queue_type: str) -> tuple[str, ...]:
        """Return buildable item type_ids for a queue type."""
        q = self.queue_for(queue_type)
        return q.buildable_items if q is not None else ()

    def find_action_result(self, action_type: str) -> ActionResult | None:
        """Return first action result matching the action type."""
        for ar in self.action_results:
            if ar.action == action_type:
                return ar
        return None


@dataclass(frozen=True, slots=True)
class Observation:
    """Parsed tick observation. Created via ``Observation.from_tick(msg)``."""

    tick: int
    self_info: SelfInfo
    units: tuple[Unit, ...]
    enemies: tuple[EnemyUnit, ...]
    nearby_resources: tuple[ResourceCell, ...]
    map: MapInfo
    fow_enforced: bool = True
    game_events: tuple[GameEvent, ...] = ()

    @classmethod
    def from_tick(cls, msg: dict) -> Observation:
        """Parse a raw tick message dict into a typed Observation."""
        obs = msg["observation"]
        s = obs["self"]
        res = s["resources"]

        production_queues = tuple(
            ProductionQueue(
                queue_type=q["queue_type"],
                enabled=q["enabled"],
                queue_length=q["queue_length"],
                items=tuple(
                    ProductionItem(
                        item_type_id=it["item_type_id"],
                        progress=it["progress"],
                        done=it["done"],
                        paused=it["paused"],
                        ticks_remaining=it.get("ticks_remaining"),
                        status=it.get("status"),
                    )
                    for it in q["items"]
                ),
                buildable_items=tuple(q["buildable_items"]),
            )
            for q in s["production_queues"]
        )

        action_results = tuple(
            ActionResult(
                action=ar["action"],
                status=ar["status"],
                unit_id=ar.get("unit_id"),
                detail=ar.get("detail"),
                placement_detail=ar.get("placement_detail"),
            )
            for ar in s.get("action_results", [])
        )

        build_queue = tuple(
            ProductionItem(
                item_type_id=it["item_type_id"],
                progress=it["progress"],
                done=it["done"],
                paused=it["paused"],
                ticks_remaining=it.get("ticks_remaining"),
                status=it.get("status"),
            )
            for it in s.get("build_queue", [])
        )

        # Match stats
        ms_raw = s.get("match_stats")
        match_stats = MatchStats(
            units_killed=ms_raw.get("units_killed", 0),
            buildings_killed=ms_raw.get("buildings_killed", 0),
            units_lost=ms_raw.get("units_lost", 0),
            buildings_lost=ms_raw.get("buildings_lost", 0),
            total_earned=ms_raw.get("total_earned", 0),
            total_spent=ms_raw.get("total_spent", 0),
            army_value=ms_raw.get("army_value", 0),
        ) if ms_raw is not None else None

        # Superweapons
        superweapons = tuple(
            Superweapon(
                type_id=sw["type_id"],
                ready=sw.get("ready", False),
                ticks_remaining=sw.get("ticks_remaining", 0),
            )
            for sw in s.get("superweapons", [])
        )

        self_info = SelfInfo(
            player_id=s["player_id"],
            faction=s["faction"],
            resources=Resources(cash=res["cash"], power=res["power"]),
            production_queues=production_queues,
            placement_pending=s.get("placement_pending", False),
            placement_type_id=s.get("placement_type_id"),
            build_queue=build_queue,
            action_results=action_results,
            actions_dropped=s.get("actions_dropped", 0),
            explored_ratio=s.get("explored_ratio"),
            match_stats=match_stats,
            superweapons=superweapons,
        )

        units = tuple(
            Unit(
                id=u["id"],
                type_id=u["type_id"],
                x=u["x"],
                y=u["y"],
                hp=u["hp"],
                max_hp=u["max_hp"],
                facing=u["facing"],
                cooldowns=u["cooldowns"],
                can_deploy=u.get("can_deploy", False),
                current_order=u.get("current_order", ""),
                cargo_ratio=u.get("cargo_ratio"),
                harvester_state=u.get("harvester_state"),
                refinery_queue=u.get("refinery_queue"),
                veterancy=Veterancy(
                    level=u["veterancy"].get("level", 0),
                    progress=u["veterancy"].get("progress", 0.0),
                ) if "veterancy" in u else None,
                stance=u.get("stance"),
                passenger_count=u.get("passenger_count"),
                passengers=tuple(
                    Passenger(id=p["id"], type_id=p["type_id"])
                    for p in u.get("passengers", [])
                ),
                repairing=u.get("repairing"),
            )
            for u in obs["units"]
        )

        enemies = tuple(
            EnemyUnit(
                id=e["id"],
                type_id=e["type_id"],
                x=e["x"],
                y=e["y"],
                hp=e["hp"],
                max_hp=e["max_hp"],
                facing=e.get("facing"),
                current_order=e.get("current_order"),
            )
            for e in obs["visible_enemies"]
        )

        nearby_resources = tuple(
            ResourceCell(x=r["x"], y=r["y"], kind=r["kind"], density=r.get("density"))
            for r in obs.get("nearby_resources", [])
        )

        m = obs["map"]

        game_events = tuple(
            GameEvent(
                event=ge["event"],
                tick=ge["tick"],
                unit_id=ge.get("unit_id"),
                type_id=ge.get("type_id"),
                x=ge.get("x"),
                y=ge.get("y"),
                detail=ge.get("detail"),
            )
            for ge in obs.get("game_events", [])
        )

        return cls(
            tick=msg["tick"],
            self_info=self_info,
            units=units,
            enemies=enemies,
            nearby_resources=nearby_resources,
            map=MapInfo(width=m["width"], height=m["height"], buildable=m.get("buildable")),
            fow_enforced=obs.get("fow_enforced", True),
            game_events=game_events,
        )
