"""Derived helper functions for bot decision-making.

Pure functions that combine Ruleset and Observation data to answer
common questions without requiring protocol or adapter changes.
"""

from __future__ import annotations

from airena_sdk.ruleset import Ruleset, UnitType, Weapon
from airena_sdk.observation import SelfInfo


# ---------------------------------------------------------------------------
# Economy helpers
# ---------------------------------------------------------------------------

def can_afford(ruleset: Ruleset, self_info: SelfInfo, type_id: str) -> bool:
    """Check if the player can afford to produce the given unit/building."""
    ut = ruleset.get_unit_type(type_id)
    if ut is None:
        return False
    return self_info.resources.cash >= ut.cost


def can_produce(ruleset: Ruleset, self_info: SelfInfo, type_id: str) -> bool:
    """Check if the player can afford AND has the item available in a queue."""
    if not can_afford(ruleset, self_info, type_id):
        return False
    for q in self_info.production_queues:
        if type_id in q.buildable_items and q.enabled:
            return True
    return False


# ---------------------------------------------------------------------------
# Power helpers
# ---------------------------------------------------------------------------

# Fallback power values for standard RA mod buildings.
# Used when ruleset doesn't provide power_delta (older adapters).
_POWER_TABLE: dict[str, int] = {
    "powr": 100,
    "apwr": 200,
    "tent": -20,
    "barr": -20,
    "weap": -30,
    "proc": -30,
    "fix": -30,
    "hpad": -10,
    "afld": -20,
    "dome": -40,
    "atek": -200,
    "stek": -100,
    "tsla": -80,
    "iron": -200,
    "gap": -60,
    "sam": -40,
    "agun": -50,
    "gun": -40,
    "ftur": -20,
    "pbox": -20,
    "mslo": -150,
    "silo": -10,
}


def power_for(type_id: str, ruleset: Ruleset | None = None) -> int:
    """Return power delta for a building type_id.

    Positive = generates power, negative = drains power.
    If a ruleset is provided and contains power_delta, uses that.
    Otherwise falls back to a hardcoded table for common RA buildings.
    Returns 0 for unknown types.
    """
    if ruleset is not None:
        ut = ruleset.get_unit_type(type_id)
        if ut is not None and ut.power_delta != 0:
            return ut.power_delta
    return _POWER_TABLE.get(type_id, 0)


def projected_power(
    self_info: SelfInfo,
    type_id: str,
    ruleset: Ruleset | None = None,
) -> int:
    """Project power balance after building the given type.

    Returns current_power + power_delta(type_id).
    """
    return self_info.resources.power + power_for(type_id, ruleset)


# ---------------------------------------------------------------------------
# Combat helpers
# ---------------------------------------------------------------------------

def dps(ruleset: Ruleset, type_id: str) -> float:
    """Compute raw damage per second for a unit type.

    Sums DPS across all weapons. Assumes 25 ticks/second (OpenRA default).
    Returns 0.0 if the unit type has no weapons or is unknown.
    """
    TICKS_PER_SECOND = 25
    ut = ruleset.get_unit_type(type_id)
    if ut is None:
        return 0.0
    total = 0.0
    for wid in ut.weapons:
        w = ruleset.get_weapon(wid)
        if w is None or w.reload_ticks <= 0:
            continue
        total += (w.damage * w.burst) / w.reload_ticks * TICKS_PER_SECOND
    return total


def effective_dps(
    ruleset: Ruleset,
    attacker_type_id: str,
    target_armor: str,
) -> float:
    """Compute DPS adjusted by versus multiplier against a target armor class.

    ``target_armor`` should match the target's ``armor_type`` field
    (e.g. ``"Heavy"``, ``"Light"``, ``"None"``).
    If no versus entry exists for the armor type, assumes 100% damage.
    """
    TICKS_PER_SECOND = 25
    ut = ruleset.get_unit_type(attacker_type_id)
    if ut is None:
        return 0.0
    total = 0.0
    for wid in ut.weapons:
        w = ruleset.get_weapon(wid)
        if w is None or w.reload_ticks <= 0:
            continue
        multiplier = w.versus.get(target_armor, 100) / 100.0
        total += (w.damage * w.burst) / w.reload_ticks * TICKS_PER_SECOND * multiplier
    return total


def unit_dps_against(
    ruleset: Ruleset,
    attacker_type_id: str,
    target_type_id: str,
) -> float:
    """Compute DPS of attacker against a specific target unit type.

    Looks up the target's armor_type and delegates to effective_dps.
    """
    target = ruleset.get_unit_type(target_type_id)
    if target is None:
        return 0.0
    armor = target.armor_type if target.armor_type else "None"
    return effective_dps(ruleset, attacker_type_id, armor)


# ---------------------------------------------------------------------------
# Map / terrain helpers
# ---------------------------------------------------------------------------

def decode_rle(encoded: str) -> str:
    """Decode an RLE-encoded grid string.

    Format: digit prefix repeats next character (e.g. '5.' = '.....').
    Multi-digit runs supported (e.g. '128.' = 128 dots).
    Characters without a digit prefix appear once.
    """
    result: list[str] = []
    i = 0
    n = len(encoded)
    while i < n:
        # Collect digits
        num_start = i
        while i < n and encoded[i].isdigit():
            i += 1
        if i < n:
            count = int(encoded[num_start:i]) if i > num_start else 1
            result.append(encoded[i] * count)
            i += 1
    return "".join(result)


def can_build_at(obs_map, x: int, y: int) -> bool:
    """Check if a building can be placed at (x, y) using the buildable grid.

    ``obs_map`` should be an ``Observation.map`` (MapInfo) instance.
    Returns False if buildable grid is not available or coords are out of bounds.
    """
    if obs_map.buildable is None:
        return False
    grid = decode_rle(obs_map.buildable)
    idx = y * obs_map.width + x
    if idx < 0 or idx >= len(grid):
        return False
    return grid[idx] == "."
