"""Protocol I/O for the openra.v1 bot protocol.

All communication is JSON Lines on stdin/stdout.
Logging goes to stderr only.
"""

import json
import sys

PROTOCOL = "openra.v1"


def log(msg: str) -> None:
    """Log a message to stderr (never touches stdout)."""
    print(f"[bot] {msg}", file=sys.stderr, flush=True)


def send(obj: dict) -> None:
    """Send a JSON message to the adapter via stdout."""
    line = json.dumps(obj, separators=(",", ":"))
    sys.stdout.write(line + "\n")
    sys.stdout.flush()


def send_error(message: str) -> None:
    """Send an error message to the adapter."""
    send({"type": "error", "message": message})
