"""BotRunner — JSONL main loop with message dispatch.

Reads JSON Lines from stdin, dispatches to registered handlers,
handles malformed input gracefully.
"""

import json
import sys
from typing import Callable

from airena_sdk.protocol import PROTOCOL, log, send, send_error

Handler = Callable[[dict, dict], None]


class BotRunner:
    """Minimal protocol runner for openra.v1 bots.

    Usage::

        from airena_sdk import BotRunner

        bot = BotRunner()

        @bot.on("tick")
        def handle_tick(msg, state):
            ...

        bot.run(initial_state={})
    """

    def __init__(self, protocol: str = PROTOCOL):
        self.protocol = protocol
        self._handlers: dict[str, Handler] = {}
        # Register default hello handler (can be overridden)
        self._handlers["hello"] = self._default_hello

    def on(self, msg_type: str):
        """Decorator to register a handler for a message type."""
        def decorator(fn: Handler) -> Handler:
            self._handlers[msg_type] = fn
            return fn
        return decorator

    def register(self, msg_type: str, handler: Handler) -> None:
        """Register a handler for a message type (non-decorator form)."""
        self._handlers[msg_type] = handler

    def run(self, initial_state: dict | None = None) -> None:
        """Read JSONL from stdin, dispatch to handlers. Blocks until EOF."""
        log("Bot starting. Waiting for messages on stdin...")
        state = initial_state if initial_state is not None else {}

        for raw_line in sys.stdin:
            line = raw_line.strip()
            if not line:
                continue

            try:
                msg = json.loads(line)
            except json.JSONDecodeError as exc:
                send_error(f"Invalid JSON: {exc}")
                continue

            msg_type = msg.get("type")
            handler = self._handlers.get(msg_type)

            if handler is None:
                log(f"Unknown message type: {msg_type!r} (ignored)")
                continue

            try:
                handler(msg, state)
            except Exception as exc:
                send_error(f"Error handling {msg_type}: {exc}")
                log(f"Exception in handler for {msg_type}: {exc}")

    def _default_hello(self, msg: dict, state: dict) -> None:
        """Default hello handler: validate protocol and send ready."""
        proto = msg.get("protocol")
        if proto != self.protocol:
            send_error(f"Unsupported protocol: {proto}")
            sys.exit(1)

        log(f"Received hello (protocol={proto}). Sending ready.")
        send({"type": "ready", "protocol": self.protocol})
