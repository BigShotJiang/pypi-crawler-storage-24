"""Red Alert mod constants.

Usage::

    from airena_sdk.mods import ra

    ra.Buildings.CONSTRUCTION_YARD  # "fact"
    ra.Units.RIFLEMAN               # "e1"
    ra.Factions.ENGLAND             # "england"
"""

MOD_ID = "ra"


class Factions:
    """Playable RA factions. Allied side: England, France, Germany. Soviet side: Russia, Ukraine."""

    ENGLAND = "england"
    FRANCE = "france"
    GERMANY = "germany"
    RUSSIA = "russia"
    UKRAINE = "ukraine"

    # Side aliases — pick a representative faction when side doesn't matter
    ALLIED = ENGLAND
    SOVIET = RUSSIA

    ALL = (ENGLAND, FRANCE, GERMANY, RUSSIA, UKRAINE)
    ALLIED_ALL = (ENGLAND, FRANCE, GERMANY)
    SOVIET_ALL = (RUSSIA, UKRAINE)


class Buildings:
    """Key RA building type_ids."""

    # Core
    CONSTRUCTION_YARD = "fact"
    POWER_PLANT = "powr"
    ADVANCED_POWER = "apwr"
    REFINERY = "proc"
    SILO = "silo"

    # Production
    BARRACKS_ALLIED = "tent"
    BARRACKS_SOVIET = "barr"
    WAR_FACTORY = "weap"
    AIRFIELD = "afld"
    HELIPAD = "hpad"
    SERVICE_DEPOT = "fix"
    NAVAL_YARD = "syrd"

    # Tech
    RADAR_DOME = "dome"
    TECH_CENTER_ALLIED = "atek"
    TECH_CENTER_SOVIET = "stek"

    # Defense
    PILLBOX = "pbox"
    CAMO_PILLBOX = "hbox"
    GUN_TURRET = "gun"
    FLAME_TURRET = "ftur"
    SAM_SITE = "sam"
    AA_GUN = "agun"
    TESLA_COIL = "tsla"
    GAP_GENERATOR = "gap"

    # Superweapons
    CHRONOSPHERE = "pdox"
    IRON_CURTAIN = "iron"
    MISSILE_SILO = "mslo"

    # Walls
    SANDBAG = "sbag"
    CHAIN_LINK = "fenc"
    CONCRETE = "brik"


class Units:
    """Key RA unit type_ids."""

    # Special
    MCV = "mcv"
    HARVESTER = "harv"

    # Infantry
    RIFLEMAN = "e1"
    GRENADIER = "e2"
    ROCKET_SOLDIER = "e3"
    FLAMETHROWER = "e4"
    ENGINEER = "e6"
    SPY = "spy"
    TANYA = "e7"
    MEDIC = "medi"
    MECHANIC = "mech"
    SHOCK_TROOPER = "shok"
    DOG = "dog"
    THIEF = "thf"

    # Vehicles
    LIGHT_TANK = "1tnk"
    MEDIUM_TANK = "2tnk"
    HEAVY_TANK = "3tnk"
    MAMMOTH_TANK = "4tnk"
    RANGER = "jeep"
    APC = "apc"
    ARTILLERY = "arty"
    V2_LAUNCHER = "v2rl"
    MINELAYER = "mnly"
    MOBILE_GAP = "mgg"
    MOBILE_RADAR_JAMMER = "mrj"
    DEMOLITION_TRUCK = "dtrk"
    CHRONO_TANK = "ctnk"
    TESLA_TANK = "ttnk"

    # Aircraft
    MIG = "mig"
    YAK = "yak"
    LONGBOW = "heli"
    HIND = "hind"
    CHINOOK = "tran"


class BuildOrders:
    """Common RA opening build sequences.

    Each is a tuple of type_ids to queue in order.
    """

    #: Fast infantry rush: power up, refinery, barracks, mass riflemen
    ALLIED_INFANTRY_RUSH = ("powr", "powr", "proc", "tent", "e1", "e1", "e1", "e1", "e1")
    SOVIET_INFANTRY_RUSH = ("powr", "powr", "proc", "barr", "e1", "e1", "e1", "e1", "e1")

    #: Tank-focused opening
    ALLIED_TANKS = ("powr", "powr", "proc", "weap", "1tnk", "1tnk", "2tnk")
    SOVIET_TANKS = ("powr", "powr", "proc", "weap", "3tnk", "3tnk", "3tnk")

    #: Balanced economy opener
    ALLIED_BALANCED = ("powr", "powr", "proc", "tent", "e1", "e1", "weap", "1tnk")
    SOVIET_BALANCED = ("powr", "powr", "proc", "barr", "e1", "e1", "weap", "3tnk")
