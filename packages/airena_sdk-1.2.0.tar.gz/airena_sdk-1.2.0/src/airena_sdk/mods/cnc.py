"""Tiberian Dawn (Command & Conquer) mod constants.

Usage::

    from airena_sdk.mods import cnc

    cnc.Buildings.HAND_OF_NOD      # "hand"
    cnc.Units.MINIGUNNER           # "e1"
    cnc.Factions.GDI               # "gdi"
"""

MOD_ID = "cnc"


class Factions:
    """Playable CNC factions."""

    GDI = "gdi"
    NOD = "nod"

    ALL = (GDI, NOD)


class Buildings:
    """Key CNC building type_ids."""

    # Core
    CONSTRUCTION_YARD = "fact"
    POWER_PLANT = "nuke"
    ADVANCED_POWER = "nuk2"
    REFINERY = "proc"
    SILO = "silo"

    # Production — GDI
    BARRACKS_GDI = "pyle"
    WAR_FACTORY = "weap"
    HELIPAD = "hpad"

    # Production — Nod
    HAND_OF_NOD = "hand"
    AIRSTRIP = "afld"

    # Shared
    SERVICE_DEPOT = "fix"

    # Tech
    COMMUNICATIONS_CENTER = "hq"
    ADVANCED_COMMS = "eye"
    TEMPLE_OF_NOD = "tmpl"

    # Defense
    GUARD_TOWER = "gtwr"
    ADVANCED_GUARD_TOWER = "atwr"
    GUN_TURRET = "gun"
    SAM_SITE = "sam"
    OBELISK = "obli"

    # Walls
    SANDBAG = "sbag"
    CHAIN_LINK = "cycl"
    CONCRETE = "brik"


class Units:
    """Key CNC unit type_ids."""

    # Special
    MCV = "mcv"
    HARVESTER = "harv"

    # Infantry
    MINIGUNNER = "e1"
    GRENADIER = "e2"
    ROCKET_SOLDIER = "e3"
    FLAMETHROWER = "e4"
    COMMANDO = "e5"
    ENGINEER = "e6"

    # Vehicles — GDI
    MEDIUM_TANK = "mtnk"
    MAMMOTH_TANK = "htnk"
    HUMVEE = "jeep"
    APC = "apc"
    MLRS = "mlrs"

    # Vehicles — Nod
    LIGHT_TANK = "ltnk"
    FLAME_TANK = "ftnk"
    BUGGY = "bggy"
    RECON_BIKE = "bike"
    STEALTH_TANK = "stnk"
    ARTILLERY = "arty"
    SSM_LAUNCHER = "msam"

    # Aircraft
    ORCA = "orca"
    TRANSPORT_HELICOPTER = "tran"
    APACHE = "heli"
    A10 = "a10"


class BuildOrders:
    """Common CNC opening build sequences."""

    #: GDI infantry rush
    GDI_INFANTRY_RUSH = ("nuke", "nuke", "proc", "pyle", "e1", "e1", "e1", "e1", "e1")

    #: GDI tank-focused opener
    GDI_TANKS = ("nuke", "nuke", "proc", "weap", "mtnk", "mtnk", "mtnk")

    #: GDI balanced
    GDI_BALANCED = ("nuke", "nuke", "proc", "pyle", "e1", "e1", "weap", "mtnk")

    #: Nod infantry rush
    NOD_INFANTRY_RUSH = ("nuke", "nuke", "proc", "hand", "e1", "e1", "e1", "e1", "e1")

    #: Nod light vehicle rush
    NOD_VEHICLE_RUSH = ("nuke", "nuke", "proc", "afld", "bggy", "bggy", "bike", "bike")

    #: Nod balanced
    NOD_BALANCED = ("nuke", "nuke", "proc", "hand", "e1", "e1", "afld", "ltnk")
