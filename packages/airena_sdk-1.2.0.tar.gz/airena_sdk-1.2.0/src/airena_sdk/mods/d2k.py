"""Dune 2000 mod constants.

Usage::

    from airena_sdk.mods import d2k

    d2k.Buildings.BARRACKS         # "barracks"
    d2k.Units.LIGHT_INFANTRY       # "light_inf"
    d2k.Factions.ATREIDES          # "atreides"
"""

MOD_ID = "d2k"


class Factions:
    """Playable D2K factions."""

    ATREIDES = "atreides"
    HARKONNEN = "harkonnen"
    ORDOS = "ordos"

    # Minor factions (available in some maps/scenarios)
    CORRINO = "corrino"
    FREMEN = "fremen"
    MERCENARY = "mercenary"
    SMUGGLER = "smuggler"

    ALL = (ATREIDES, HARKONNEN, ORDOS)
    ALL_WITH_MINOR = (ATREIDES, HARKONNEN, ORDOS, CORRINO, FREMEN, MERCENARY, SMUGGLER)


class Buildings:
    """Key D2K building type_ids."""

    # Core
    CONSTRUCTION_YARD = "construction_yard"
    WIND_TRAP = "wind_trap"
    REFINERY = "refinery"
    SILO = "silo"

    # Production
    BARRACKS = "barracks"
    LIGHT_FACTORY = "light_factory"
    HEAVY_FACTORY = "heavy_factory"
    HIGH_TECH_FACTORY = "high_tech_factory"
    STARPORT = "starport"
    REPAIR_PAD = "repair_pad"

    # Tech
    OUTPOST = "outpost"
    RESEARCH_CENTRE = "research_centre"
    PALACE = "palace"

    # Defense
    MEDIUM_GUN_TURRET = "medium_gun_turret"
    LARGE_GUN_TURRET = "large_gun_turret"

    # Foundations
    CONCRETE_A = "concretea"
    CONCRETE_B = "concreteb"
    WALL = "wall"


class Units:
    """Key D2K unit type_ids."""

    # Special
    MCV = "mcv"
    HARVESTER = "harvester"
    CARRYALL = "carryall"

    # Infantry
    LIGHT_INFANTRY = "light_inf"
    TROOPER = "trooper"
    ENGINEER = "engineer"
    THUMPER = "thumper"
    GRENADIER = "grenadier"
    FREMEN = "fremen"
    SARDAUKAR = "sardaukar"
    SABOTEUR = "saboteur"

    # Vehicles — shared
    TRIKE = "trike"
    QUAD = "quad"
    SIEGE_TANK = "siege_tank"
    MISSILE_TANK = "missile_tank"

    # Vehicles — Atreides
    COMBAT_TANK_A = "combat_tank_a"
    SONIC_TANK = "sonic_tank"

    # Vehicles — Harkonnen
    COMBAT_TANK_H = "combat_tank_h"
    DEVASTATOR = "devastator"

    # Vehicles — Ordos
    COMBAT_TANK_O = "combat_tank_o"
    RAIDER = "raider"
    STEALTH_RAIDER = "stealth_raider"
    DEVIATOR = "deviator"

    # Aircraft
    ORNITHOPTER = "ornithopter"


class BuildOrders:
    """Common D2K opening build sequences."""

    #: Infantry rush (any faction)
    INFANTRY_RUSH = (
        "wind_trap", "wind_trap", "refinery", "barracks",
        "light_inf", "light_inf", "light_inf", "light_inf", "light_inf",
    )

    #: Vehicle rush (any faction)
    VEHICLE_RUSH = (
        "wind_trap", "wind_trap", "refinery", "light_factory",
        "trike", "trike", "quad", "quad",
    )

    #: Balanced opener (any faction, uses faction-neutral units)
    BALANCED = (
        "wind_trap", "wind_trap", "refinery", "barracks",
        "light_inf", "light_inf", "light_factory", "trike",
    )
