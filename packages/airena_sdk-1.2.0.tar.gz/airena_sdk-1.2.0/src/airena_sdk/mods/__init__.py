"""Mod-specific constants and build orders for OpenRA mods.

Import the mod you need::

    from airena_sdk.mods import ra
    from airena_sdk.mods import cnc
    from airena_sdk.mods import d2k

Each module provides:
- ``MOD_ID`` — the mod identifier string (e.g. ``"ra"``)
- ``Buildings`` — key building type_ids
- ``Units`` — key unit type_ids (infantry, vehicles, aircraft)
- ``Factions`` — available faction identifiers
- ``BuildOrders`` — common opening build sequences
"""
