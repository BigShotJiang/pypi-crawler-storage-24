"""Tests for airena_sdk.helpers derived helper functions."""

import pytest

from airena_sdk.helpers import (
    can_afford,
    can_produce,
    power_for,
    projected_power,
    dps,
    effective_dps,
    unit_dps_against,
    decode_rle,
    can_build_at,
)
from airena_sdk.observation import (
    SelfInfo,
    Resources,
    ProductionQueue,
    ProductionItem,
    MapInfo,
)
from airena_sdk.ruleset import Ruleset, UnitType, Weapon


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

def _make_ruleset() -> Ruleset:
    return Ruleset(
        mod_id="ra",
        ruleset_id="standard",
        ruleset_version="test",
        unit_types={
            "1tnk": UnitType(
                type_id="1tnk",
                is_building=False,
                max_hp=30000,
                speed=85,
                weapons=("75mm",),
                armor_type="Heavy",
                cost=700,
            ),
            "e1": UnitType(
                type_id="e1",
                is_building=False,
                max_hp=5000,
                speed=56,
                weapons=("m60",),
                armor_type="None",
                cost=100,
            ),
            "powr": UnitType(
                type_id="powr",
                is_building=True,
                max_hp=40000,
                speed=0,
                weapons=(),
                cost=300,
                power_delta=100,
            ),
            "unarmed": UnitType(
                type_id="unarmed",
                is_building=False,
                max_hp=1000,
                speed=50,
                weapons=(),
                cost=50,
            ),
        },
        weapons={
            "75mm": Weapon(
                weapon_id="75mm",
                range=5.5,
                damage=4000,
                reload_ticks=50,
                burst=1,
                versus={"None": 100, "Light": 70, "Heavy": 30},
            ),
            "m60": Weapon(
                weapon_id="m60",
                range=4.0,
                damage=2000,
                reload_ticks=25,
                burst=1,
                versus={"None": 100, "Heavy": 10},
            ),
        },
    )


def _make_self_info(cash: int = 1000, power: int = 50) -> SelfInfo:
    return SelfInfo(
        player_id=1,
        faction="england",
        resources=Resources(cash=cash, power=power),
        production_queues=(
            ProductionQueue(
                queue_type="Vehicle",
                enabled=True,
                queue_length=0,
                items=(),
                buildable_items=("1tnk", "e1"),
            ),
            ProductionQueue(
                queue_type="Building",
                enabled=True,
                queue_length=0,
                items=(),
                buildable_items=("powr",),
            ),
        ),
    )


# ---------------------------------------------------------------------------
# Economy tests
# ---------------------------------------------------------------------------

class TestCanAfford:
    def test_can_afford_yes(self):
        assert can_afford(_make_ruleset(), _make_self_info(cash=700), "1tnk") is True

    def test_can_afford_no(self):
        assert can_afford(_make_ruleset(), _make_self_info(cash=699), "1tnk") is False

    def test_can_afford_unknown_type(self):
        assert can_afford(_make_ruleset(), _make_self_info(), "unknown") is False

    def test_can_afford_exact(self):
        assert can_afford(_make_ruleset(), _make_self_info(cash=300), "powr") is True


class TestCanProduce:
    def test_can_produce_yes(self):
        assert can_produce(_make_ruleset(), _make_self_info(cash=700), "1tnk") is True

    def test_can_produce_no_cash(self):
        assert can_produce(_make_ruleset(), _make_self_info(cash=50), "1tnk") is False

    def test_can_produce_not_in_queue(self):
        # unarmed is in ruleset but not in any buildable_items
        assert can_produce(_make_ruleset(), _make_self_info(cash=9999), "unarmed") is False

    def test_can_produce_unknown(self):
        assert can_produce(_make_ruleset(), _make_self_info(), "nonexistent") is False


# ---------------------------------------------------------------------------
# Power tests
# ---------------------------------------------------------------------------

class TestPower:
    def test_power_for_known(self):
        assert power_for("powr") == 100
        assert power_for("apwr") == 200
        assert power_for("weap") == -30

    def test_power_for_unknown(self):
        assert power_for("unknown_building") == 0

    def test_power_for_from_ruleset(self):
        rs = _make_ruleset()
        assert power_for("powr", ruleset=rs) == 100

    def test_power_for_fallback_when_ruleset_zero(self):
        # 1tnk has power_delta=0 (default), falls back to table
        assert power_for("weap", ruleset=_make_ruleset()) == -30

    def test_projected_power(self):
        si = _make_self_info(power=50)
        assert projected_power(si, "powr") == 150
        assert projected_power(si, "weap") == 20
        assert projected_power(si, "unknown") == 50

    def test_projected_power_with_ruleset(self):
        si = _make_self_info(power=50)
        rs = _make_ruleset()
        assert projected_power(si, "powr", ruleset=rs) == 150


# ---------------------------------------------------------------------------
# Combat tests
# ---------------------------------------------------------------------------

class TestDps:
    def test_dps_tank(self):
        # 75mm: 4000 damage, 1 burst, 50 reload ticks, 25 tps
        # DPS = (4000 * 1) / 50 * 25 = 2000.0
        assert dps(_make_ruleset(), "1tnk") == pytest.approx(2000.0)

    def test_dps_infantry(self):
        # m60: 2000 damage, 1 burst, 25 reload ticks, 25 tps
        # DPS = (2000 * 1) / 25 * 25 = 2000.0
        assert dps(_make_ruleset(), "e1") == pytest.approx(2000.0)

    def test_dps_unarmed(self):
        assert dps(_make_ruleset(), "unarmed") == 0.0

    def test_dps_unknown(self):
        assert dps(_make_ruleset(), "nonexistent") == 0.0


class TestEffectiveDps:
    def test_vs_heavy(self):
        # Tank 75mm vs Heavy: 2000 * 0.30 = 600.0
        assert effective_dps(_make_ruleset(), "1tnk", "Heavy") == pytest.approx(600.0)

    def test_vs_none(self):
        # Tank 75mm vs None: 2000 * 1.0 = 2000.0
        assert effective_dps(_make_ruleset(), "1tnk", "None") == pytest.approx(2000.0)

    def test_vs_unknown_armor(self):
        # Unknown armor defaults to 100%
        assert effective_dps(_make_ruleset(), "1tnk", "Alien") == pytest.approx(2000.0)

    def test_unarmed(self):
        assert effective_dps(_make_ruleset(), "unarmed", "None") == 0.0


class TestUnitDpsAgainst:
    def test_tank_vs_tank(self):
        # 1tnk (75mm) vs 1tnk (Heavy armor): 2000 * 0.30 = 600
        assert unit_dps_against(_make_ruleset(), "1tnk", "1tnk") == pytest.approx(600.0)

    def test_tank_vs_infantry(self):
        # 1tnk (75mm) vs e1 (None armor): 2000 * 1.0 = 2000
        assert unit_dps_against(_make_ruleset(), "1tnk", "e1") == pytest.approx(2000.0)

    def test_infantry_vs_tank(self):
        # e1 (m60) vs 1tnk (Heavy): 2000 * 0.10 = 200
        assert unit_dps_against(_make_ruleset(), "e1", "1tnk") == pytest.approx(200.0)

    def test_unknown_target(self):
        assert unit_dps_against(_make_ruleset(), "1tnk", "nonexistent") == 0.0


# ---------------------------------------------------------------------------
# RLE / Map helpers tests
# ---------------------------------------------------------------------------

class TestDecodeRle:
    def test_simple(self):
        assert decode_rle("3.2#") == "...##"

    def test_no_prefix(self):
        assert decode_rle(".#.") == ".#."

    def test_multi_digit(self):
        assert decode_rle("10.") == ".........."

    def test_mixed(self):
        assert decode_rle("3.#2.") == "...#.."

    def test_empty(self):
        assert decode_rle("") == ""

    def test_single_char(self):
        assert decode_rle("1X") == "X"


class TestCanBuildAt:
    def test_buildable_cell(self):
        # "4.4#" decodes to "....####" — first row buildable, second row not
        m = MapInfo(width=4, height=2, buildable="4.4#")
        assert can_build_at(m, 0, 0) is True
        assert can_build_at(m, 3, 0) is True

    def test_not_buildable_cell(self):
        m = MapInfo(width=4, height=2, buildable="4.4#")
        assert can_build_at(m, 0, 1) is False

    def test_out_of_bounds(self):
        m = MapInfo(width=4, height=2, buildable="4.4#")
        assert can_build_at(m, 10, 10) is False

    def test_no_buildable_grid(self):
        m = MapInfo(width=4, height=2)
        assert can_build_at(m, 0, 0) is False
