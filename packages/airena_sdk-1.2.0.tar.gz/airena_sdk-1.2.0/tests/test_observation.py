"""Tests for the observation parser."""

from airena_sdk.observation import (
    Observation, Unit, EnemyUnit, SelfInfo, Resources,
    ProductionQueue, ProductionItem, ActionResult,
    ResourceCell, MapInfo,
)


def _make_tick(**overrides):
    """Build a minimal valid tick message."""
    self_info = {
        "player_id": 1,
        "faction": "england",
        "resources": {"cash": 5000, "power": 10},
        "production_queues": [
            {
                "queue_type": "Building",
                "enabled": True,
                "queue_length": 1,
                "items": [
                    {"item_type_id": "powr", "progress": 0.5, "done": False, "paused": False},
                ],
                "buildable_items": ["powr", "proc", "barr"],
            },
            {
                "queue_type": "Infantry",
                "enabled": False,
                "queue_length": 0,
                "items": [],
                "buildable_items": [],
            },
        ],
        "placement_pending": False,
        "placement_type_id": None,
        "build_queue": [],
        "action_results": [
            {"action": "move", "status": "ok", "unit_id": 42},
            {"action": "queue_production", "status": "insufficient_funds", "detail": "need 800"},
        ],
    }
    msg = {
        "type": "tick",
        "tick": 120,
        "observation": {
            "self": self_info,
            "units": [
                {
                    "id": 1, "type_id": "mcv", "x": 50, "y": 50,
                    "hp": 600, "max_hp": 600, "facing": 128,
                    "cooldowns": {}, "can_deploy": True, "current_order": "Idle",
                },
                {
                    "id": 2, "type_id": "harv", "x": 55, "y": 50,
                    "hp": 300, "max_hp": 300, "facing": 64,
                    "cooldowns": {}, "cargo_ratio": 0.75,
                    "harvester_state": "harvesting",
                },
                {
                    "id": 3, "type_id": "proc", "x": 45, "y": 50,
                    "hp": 900, "max_hp": 900, "facing": 0,
                    "cooldowns": {}, "refinery_queue": 2,
                },
            ],
            "visible_enemies": [
                {"id": 99, "type_id": "e1", "x": 100, "y": 100, "hp": 50, "max_hp": 50},
            ],
            "nearby_resources": [
                {"x": 60, "y": 55, "kind": "gold"},
                {"x": 61, "y": 55, "kind": "gems"},
            ],
            "map": {"width": 128, "height": 128},
            "fow_enforced": True,
        },
    }
    # Apply overrides to observation level
    for k, v in overrides.items():
        if k in msg:
            msg[k] = v
        elif k in msg["observation"]:
            msg["observation"][k] = v
    return msg


def test_from_tick_basic():
    obs = Observation.from_tick(_make_tick())
    assert obs.tick == 120
    assert obs.self_info.faction == "england"
    assert obs.self_info.resources.cash == 5000
    assert obs.self_info.resources.power == 10
    assert obs.self_info.player_id == 1
    assert obs.map.width == 128
    assert obs.map.height == 128
    assert obs.fow_enforced is True


def test_units_parsed():
    obs = Observation.from_tick(_make_tick())
    assert len(obs.units) == 3
    mcv = obs.units[0]
    assert isinstance(mcv, Unit)
    assert mcv.id == 1
    assert mcv.type_id == "mcv"
    assert mcv.can_deploy is True
    assert mcv.current_order == "Idle"
    assert mcv.cooldowns == {}
    assert mcv.cargo_ratio is None


def test_harvester_cargo_ratio():
    obs = Observation.from_tick(_make_tick())
    harv = obs.units[1]
    assert harv.type_id == "harv"
    assert harv.cargo_ratio == 0.75


def test_harvester_state():
    obs = Observation.from_tick(_make_tick())
    harv = obs.units[1]
    assert harv.harvester_state == "harvesting"
    # Non-harvester units have no harvester_state
    mcv = obs.units[0]
    assert mcv.harvester_state is None


def test_refinery_queue():
    obs = Observation.from_tick(_make_tick())
    proc = obs.units[2]
    assert proc.type_id == "proc"
    assert proc.refinery_queue == 2
    # Non-refinery units have no refinery_queue
    mcv = obs.units[0]
    assert mcv.refinery_queue is None


def test_enemies_parsed():
    obs = Observation.from_tick(_make_tick())
    assert len(obs.enemies) == 1
    e = obs.enemies[0]
    assert isinstance(e, EnemyUnit)
    assert e.id == 99
    assert e.type_id == "e1"
    assert e.hp == 50


def test_production_queues():
    obs = Observation.from_tick(_make_tick())
    queues = obs.self_info.production_queues
    assert len(queues) == 2

    bq = queues[0]
    assert isinstance(bq, ProductionQueue)
    assert bq.queue_type == "Building"
    assert bq.enabled is True
    assert bq.queue_length == 1
    assert len(bq.items) == 1
    assert bq.items[0].item_type_id == "powr"
    assert bq.items[0].progress == 0.5
    assert bq.items[0].done is False
    assert bq.buildable_items == ("powr", "proc", "barr")


def test_action_results():
    obs = Observation.from_tick(_make_tick())
    results = obs.self_info.action_results
    assert len(results) == 2
    assert isinstance(results[0], ActionResult)
    assert results[0].action == "move"
    assert results[0].status == "ok"
    assert results[0].unit_id == 42
    assert results[1].detail == "need 800"


def test_nearby_resources():
    obs = Observation.from_tick(_make_tick())
    assert len(obs.nearby_resources) == 2
    assert isinstance(obs.nearby_resources[0], ResourceCell)
    assert obs.nearby_resources[0].kind == "gold"
    assert obs.nearby_resources[1].kind == "gems"


def test_queue_for_case_insensitive():
    obs = Observation.from_tick(_make_tick())
    q = obs.self_info.queue_for("building")
    assert q is not None
    assert q.queue_type == "Building"

    q2 = obs.self_info.queue_for("INFANTRY")
    assert q2 is not None
    assert q2.enabled is False


def test_queue_for_missing():
    obs = Observation.from_tick(_make_tick())
    assert obs.self_info.queue_for("Aircraft") is None


def test_buildable_in():
    obs = Observation.from_tick(_make_tick())
    items = obs.self_info.buildable_in("building")
    assert items == ("powr", "proc", "barr")
    assert obs.self_info.buildable_in("Aircraft") == ()


def test_find_action_result():
    obs = Observation.from_tick(_make_tick())
    ar = obs.self_info.find_action_result("queue_production")
    assert ar is not None
    assert ar.status == "insufficient_funds"
    assert obs.self_info.find_action_result("deploy") is None


def test_first_done():
    msg = _make_tick()
    msg["observation"]["self"]["production_queues"][0]["items"].append(
        {"item_type_id": "proc", "progress": 1.0, "done": True, "paused": False}
    )
    obs = Observation.from_tick(msg)
    q = obs.self_info.queue_for("building")
    assert q.first_done() == "proc"


def test_first_done_none():
    obs = Observation.from_tick(_make_tick())
    q = obs.self_info.queue_for("building")
    assert q.first_done() is None


def test_optional_fields_defaults():
    """Units missing optional fields get sensible defaults."""
    msg = _make_tick()
    # Minimal unit: only required fields
    msg["observation"]["units"] = [
        {"id": 10, "type_id": "e1", "x": 30, "y": 30,
         "hp": 50, "max_hp": 50, "facing": 0, "cooldowns": {}},
    ]
    obs = Observation.from_tick(msg)
    u = obs.units[0]
    assert u.can_deploy is False
    assert u.current_order == ""
    assert u.cargo_ratio is None
    assert u.harvester_state is None
    assert u.refinery_queue is None


def test_placement_pending():
    msg = _make_tick()
    msg["observation"]["self"]["placement_pending"] = True
    msg["observation"]["self"]["placement_type_id"] = "powr"
    obs = Observation.from_tick(msg)
    assert obs.self_info.placement_pending is True
    assert obs.self_info.placement_type_id == "powr"


def test_frozen():
    """Observation and sub-objects are immutable."""
    obs = Observation.from_tick(_make_tick())
    try:
        obs.tick = 999
        assert False, "Should have raised"
    except AttributeError:
        pass
