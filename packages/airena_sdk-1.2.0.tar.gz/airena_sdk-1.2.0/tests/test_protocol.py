"""Tests for protocol I/O functions."""

import json
import sys
from io import StringIO
from unittest.mock import patch

from airena_sdk import PROTOCOL, log, send, send_error


def test_protocol_value():
    assert PROTOCOL == "openra.v1"


def test_send_writes_json_line():
    buf = StringIO()
    with patch.object(sys, "stdout", buf):
        send({"type": "ready", "protocol": "openra.v1"})
    line = buf.getvalue()
    assert line.endswith("\n")
    parsed = json.loads(line.strip())
    assert parsed == {"type": "ready", "protocol": "openra.v1"}


def test_send_uses_compact_json():
    buf = StringIO()
    with patch.object(sys, "stdout", buf):
        send({"a": 1, "b": 2})
    line = buf.getvalue().strip()
    # compact = no spaces after separators
    assert " " not in line


def test_send_error():
    buf = StringIO()
    with patch.object(sys, "stdout", buf):
        send_error("something broke")
    parsed = json.loads(buf.getvalue().strip())
    assert parsed == {"type": "error", "message": "something broke"}


def test_log_writes_to_stderr():
    buf = StringIO()
    with patch.object(sys, "stderr", buf):
        log("hello world")
    output = buf.getvalue()
    assert "[bot] hello world" in output
