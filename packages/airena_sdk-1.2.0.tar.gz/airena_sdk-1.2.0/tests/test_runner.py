"""Tests for BotRunner message dispatch."""

import json
import sys
from io import StringIO
from unittest.mock import patch

from airena_sdk import BotRunner, PROTOCOL


def _run_with_input(bot: BotRunner, lines: list[str], initial_state=None):
    """Feed lines to bot.run() via stdin mock."""
    stdin_data = "\n".join(lines) + "\n"
    buf_out = StringIO()
    with patch.object(sys, "stdin", StringIO(stdin_data)), \
         patch.object(sys, "stdout", buf_out), \
         patch.object(sys, "stderr", StringIO()):
        bot.run(initial_state=initial_state)
    return [json.loads(l) for l in buf_out.getvalue().strip().splitlines() if l.strip()]


def test_default_hello_sends_ready():
    bot = BotRunner()
    hello = json.dumps({"type": "hello", "protocol": PROTOCOL})
    responses = _run_with_input(bot, [hello])
    assert len(responses) == 1
    assert responses[0]["type"] == "ready"
    assert responses[0]["protocol"] == PROTOCOL


def test_wrong_protocol_exits():
    bot = BotRunner()
    hello = json.dumps({"type": "hello", "protocol": "wrong.v99"})
    try:
        _run_with_input(bot, [hello])
        assert False, "Should have called sys.exit"
    except SystemExit as e:
        assert e.code == 1


def test_custom_handler():
    bot = BotRunner()
    received = []

    @bot.on("tick")
    def handle_tick(msg, state):
        received.append(msg["tick"])

    tick1 = json.dumps({"type": "tick", "tick": 1})
    tick2 = json.dumps({"type": "tick", "tick": 2})
    _run_with_input(bot, [tick1, tick2])
    assert received == [1, 2]


def test_state_persists_across_messages():
    bot = BotRunner()

    @bot.on("tick")
    def handle_tick(msg, state):
        state["count"] = state.get("count", 0) + 1

    @bot.on("game_over")
    def handle_game_over(msg, state):
        # state should have the accumulated count
        assert state["count"] == 3

    lines = [
        json.dumps({"type": "tick", "tick": i}) for i in range(3)
    ] + [json.dumps({"type": "game_over"})]
    _run_with_input(bot, lines)


def test_initial_state():
    bot = BotRunner()
    observed = []

    @bot.on("tick")
    def handle_tick(msg, state):
        observed.append(state.get("key"))

    tick = json.dumps({"type": "tick", "tick": 1})
    _run_with_input(bot, [tick], initial_state={"key": "value"})
    assert observed == ["value"]


def test_invalid_json_sends_error():
    bot = BotRunner()
    responses = _run_with_input(bot, ["not-json!!!"])
    assert len(responses) == 1
    assert responses[0]["type"] == "error"
    assert "Invalid JSON" in responses[0]["message"]


def test_unknown_type_is_ignored():
    bot = BotRunner()
    msg = json.dumps({"type": "alien_message"})
    responses = _run_with_input(bot, [msg])
    assert responses == []


def test_handler_exception_sends_error():
    bot = BotRunner()

    @bot.on("tick")
    def bad_handler(msg, state):
        raise ValueError("boom")

    tick = json.dumps({"type": "tick", "tick": 1})
    responses = _run_with_input(bot, [tick])
    assert len(responses) == 1
    assert responses[0]["type"] == "error"
    assert "boom" in responses[0]["message"]
