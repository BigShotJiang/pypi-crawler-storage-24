"""Tests for the ruleset parser."""

from airena_sdk.ruleset import Ruleset, UnitType, Weapon


def _make_ruleset_msg():
    """Build a minimal valid ruleset message."""
    return {
        "type": "ruleset",
        "protocol": "openra.v1",
        "mod_id": "ra",
        "ruleset_id": "standard",
        "ruleset_version": "20240101",
        "unit_types": [
            {
                "type_id": "e1",
                "display_name": "Rifle Infantry",
                "is_building": False,
                "max_hp": 50,
                "armor_type": "None",
                "speed": 56,
                "turn_speed": 255,
                "sight_range": 5.0,
                "cost": 100,
                "build_time": 150,
                "weapons": ["m60"],
            },
            {
                "type_id": "fact",
                "display_name": "Construction Yard",
                "is_building": True,
                "max_hp": 1500,
                "armor_type": "Heavy",
                "speed": 0,
                "weapons": [],
                "cost": 2500,
            },
            {
                "type_id": "harv",
                "is_building": False,
                "max_hp": 300,
                "speed": 70,
                "weapons": [],
            },
        ],
        "weapons": [
            {
                "weapon_id": "m60",
                "range": 5.0,
                "damage": 20,
                "reload_ticks": 25,
                "burst": 3,
                "can_target": "ground",
                "versus": {"None": 100, "Light": 50, "Heavy": 25},
            },
            {
                "weapon_id": "vulcan",
                "range": 6.5,
                "damage": 15,
                "reload_ticks": 10,
            },
        ],
    }


def test_from_msg_basic():
    rs = Ruleset.from_msg(_make_ruleset_msg())
    assert rs.mod_id == "ra"
    assert rs.ruleset_id == "standard"
    assert rs.ruleset_version == "20240101"
    assert len(rs.unit_types) == 3
    assert len(rs.weapons) == 2


def test_unit_type_lookup():
    rs = Ruleset.from_msg(_make_ruleset_msg())
    e1 = rs.get_unit_type("e1")
    assert isinstance(e1, UnitType)
    assert e1.type_id == "e1"
    assert e1.display_name == "Rifle Infantry"
    assert e1.is_building is False
    assert e1.max_hp == 50
    assert e1.cost == 100
    assert e1.weapons == ("m60",)


def test_unit_type_not_found():
    rs = Ruleset.from_msg(_make_ruleset_msg())
    assert rs.get_unit_type("nonexistent") is None


def test_weapon_lookup():
    rs = Ruleset.from_msg(_make_ruleset_msg())
    m60 = rs.get_weapon("m60")
    assert isinstance(m60, Weapon)
    assert m60.weapon_id == "m60"
    assert m60.range == 5.0
    assert m60.damage == 20
    assert m60.burst == 3
    assert m60.versus == {"None": 100, "Light": 50, "Heavy": 25}


def test_weapon_optional_fields_defaults():
    rs = Ruleset.from_msg(_make_ruleset_msg())
    vulcan = rs.get_weapon("vulcan")
    assert vulcan.burst == 1
    assert vulcan.min_range == 0.0
    assert vulcan.projectile_speed == 0.0
    assert vulcan.can_target == "ground"
    assert vulcan.splash == 0.0
    assert vulcan.versus == {}


def test_weapon_range():
    rs = Ruleset.from_msg(_make_ruleset_msg())
    assert rs.weapon_range("e1") == 5.0


def test_weapon_range_no_weapons():
    rs = Ruleset.from_msg(_make_ruleset_msg())
    assert rs.weapon_range("harv") == 0.0


def test_weapon_range_unknown_unit():
    rs = Ruleset.from_msg(_make_ruleset_msg())
    assert rs.weapon_range("nonexistent") == 0.0


def test_buildings_filter():
    rs = Ruleset.from_msg(_make_ruleset_msg())
    buildings = rs.buildings()
    assert len(buildings) == 1
    assert buildings[0].type_id == "fact"


def test_mobile_units_filter():
    rs = Ruleset.from_msg(_make_ruleset_msg())
    mobile = rs.mobile_units()
    assert len(mobile) == 2
    type_ids = {u.type_id for u in mobile}
    assert type_ids == {"e1", "harv"}


def test_unit_type_optional_fields_defaults():
    rs = Ruleset.from_msg(_make_ruleset_msg())
    harv = rs.get_unit_type("harv")
    assert harv.display_name == ""
    assert harv.armor_type == ""
    assert harv.turn_speed == 0.0
    assert harv.sight_range == 0.0
    assert harv.build_time == 0


def test_frozen():
    rs = Ruleset.from_msg(_make_ruleset_msg())
    e1 = rs.get_unit_type("e1")
    try:
        e1.max_hp = 999
        assert False, "Should have raised"
    except AttributeError:
        pass
