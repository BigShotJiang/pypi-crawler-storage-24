"""Validate sample tick observations against tick.schema.json.

Ensures the tick observation format documented in the protocol spec
matches the JSON schema. Tests both minimal and rich observations.

Requires: pip install jsonschema (test dependency)
"""

import json
import pathlib
import pytest

_SDK_ROOT = pathlib.Path(__file__).resolve().parents[1]
_AIRENA_ROOT = _SDK_ROOT.parent
TICK_SCHEMA_PATH = (
    _AIRENA_ROOT
    / "airena-bot-protocol"
    / "schemas"
    / "openra"
    / "v1"
    / "tick.schema.json"
)

try:
    import jsonschema
    HAS_JSONSCHEMA = True
except ImportError:
    HAS_JSONSCHEMA = False

skip_if_no_schema = pytest.mark.skipif(
    not TICK_SCHEMA_PATH.exists(), reason="tick.schema.json not found"
)
skip_if_no_jsonschema = pytest.mark.skipif(
    not HAS_JSONSCHEMA, reason="jsonschema not installed"
)


def _load_schema():
    with open(TICK_SCHEMA_PATH) as f:
        return json.load(f)


def _minimal_tick():
    """Minimal valid tick observation (no units, no enemies, no queued items)."""
    return {
        "type": "tick",
        "tick": 0,
        "observation": {
            "self": {
                "player_id": 1,
                "faction": "england",
                "resources": {"cash": 5000, "power": 0},
                "placement_pending": False,
                "placement_type_id": None,
                "build_queue": [],
                "production_queues": [],
                "action_results": [],
            },
            "units": [],
            "visible_enemies": [],
            "nearby_resources": [],
            "map": {"width": 128, "height": 128},
            "fow_enforced": True,
        },
    }


def _rich_tick():
    """Rich tick with units, enemies, production, action results."""
    return {
        "type": "tick",
        "tick": 150,
        "observation": {
            "self": {
                "player_id": 1,
                "faction": "ukraine",
                "resources": {"cash": 3200, "power": -30},
                "placement_pending": True,
                "placement_type_id": "powr",
                "build_queue": [
                    {"item_type_id": "powr", "progress": 1.0, "done": True, "paused": False}
                ],
                "production_queues": [
                    {
                        "queue_type": "Building",
                        "enabled": True,
                        "queue_length": 1,
                        "items": [
                            {"item_type_id": "powr", "progress": 1.0, "done": True, "paused": False}
                        ],
                        "buildable_items": ["powr", "proc", "tent"],
                    }
                ],
                "action_results": [
                    {"action": "move", "status": "ok", "unit_id": 42},
                    {"action": "deploy", "status": "cannot_deploy", "unit_id": 7},
                    {"action": "queue_production", "status": "ok"},
                ],
            },
            "units": [
                {
                    "id": 42,
                    "type_id": "1tnk",
                    "x": 100,
                    "y": 200,
                    "hp": 30000,
                    "max_hp": 30000,
                    "facing": 128,
                    "can_deploy": False,
                    "current_order": "Idle",
                    "cooldowns": {},
                },
                {
                    "id": 20,
                    "type_id": "harv",
                    "x": 50,
                    "y": 60,
                    "hp": 60000,
                    "max_hp": 60000,
                    "facing": 0,
                    "can_deploy": False,
                    "current_order": "FindAndDeliverResources",
                    "cooldowns": {},
                    "cargo_ratio": 0.75,
                },
            ],
            "visible_enemies": [
                {"id": 99, "type_id": "e1", "x": 300, "y": 400, "hp": 5000, "max_hp": 5000}
            ],
            "nearby_resources": [
                {"x": 50, "y": 60, "kind": "gold"},
                {"x": 51, "y": 60, "kind": "gems"},
            ],
            "map": {"width": 128, "height": 128},
            "fow_enforced": True,
        },
    }


@skip_if_no_schema
@skip_if_no_jsonschema
def test_minimal_tick_validates():
    """A minimal tick with empty arrays should be valid."""
    schema = _load_schema()
    jsonschema.validate(instance=_minimal_tick(), schema=schema)


@skip_if_no_schema
@skip_if_no_jsonschema
def test_rich_tick_validates():
    """A rich tick with units, enemies, production, and results should be valid."""
    schema = _load_schema()
    jsonschema.validate(instance=_rich_tick(), schema=schema)


@skip_if_no_schema
@skip_if_no_jsonschema
def test_negative_power_validates():
    """Power can be negative (low power state)."""
    schema = _load_schema()
    tick = _minimal_tick()
    tick["observation"]["self"]["resources"]["power"] = -50
    jsonschema.validate(instance=tick, schema=schema)


@skip_if_no_schema
@skip_if_no_jsonschema
def test_missing_faction_fails():
    """Faction is required — removing it should fail validation."""
    schema = _load_schema()
    tick = _minimal_tick()
    del tick["observation"]["self"]["faction"]
    with pytest.raises(jsonschema.ValidationError):
        jsonschema.validate(instance=tick, schema=schema)


@skip_if_no_schema
@skip_if_no_jsonschema
def test_missing_production_queues_fails():
    """production_queues is required — removing it should fail validation."""
    schema = _load_schema()
    tick = _minimal_tick()
    del tick["observation"]["self"]["production_queues"]
    with pytest.raises(jsonschema.ValidationError):
        jsonschema.validate(instance=tick, schema=schema)


@skip_if_no_schema
@skip_if_no_jsonschema
def test_enemy_with_extra_fields_fails():
    """visible_enemies must NOT have own-unit fields like can_deploy."""
    schema = _load_schema()
    tick = _minimal_tick()
    tick["observation"]["visible_enemies"] = [
        {
            "id": 99,
            "type_id": "e1",
            "x": 300,
            "y": 400,
            "hp": 5000,
            "max_hp": 5000,
            "can_deploy": False,  # NOT allowed on enemies
        }
    ]
    with pytest.raises(jsonschema.ValidationError):
        jsonschema.validate(instance=tick, schema=schema)


@skip_if_no_schema
@skip_if_no_jsonschema
def test_action_result_status_enum():
    """action_results status must be one of the defined enum values."""
    schema = _load_schema()
    tick = _minimal_tick()
    tick["observation"]["self"]["action_results"] = [
        {"action": "move", "status": "bogus_status"}
    ]
    with pytest.raises(jsonschema.ValidationError):
        jsonschema.validate(instance=tick, schema=schema)


@skip_if_no_schema
@skip_if_no_jsonschema
def test_all_action_result_statuses_valid():
    """All documented status codes should pass validation."""
    schema = _load_schema()
    statuses = [
        "ok", "invalid_unit", "invalid_target", "invalid_placement",
        "insufficient_funds", "no_completed_item", "unknown_building",
        "unknown_item", "not_buildable", "queue_disabled",
        "producer_not_found", "not_a_harvester", "invalid_resource_target",
        "out_of_map", "cannot_deploy", "unknown_action",
    ]
    for status in statuses:
        tick = _minimal_tick()
        tick["observation"]["self"]["action_results"] = [
            {"action": "move", "status": status}
        ]
        jsonschema.validate(instance=tick, schema=schema)
