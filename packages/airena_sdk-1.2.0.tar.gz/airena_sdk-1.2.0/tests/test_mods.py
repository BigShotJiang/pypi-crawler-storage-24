"""Tests for airena_sdk.mods — mod-specific constants."""

import pytest

from airena_sdk.mods import ra, cnc, d2k


# ---------------------------------------------------------------------------
# MOD_ID
# ---------------------------------------------------------------------------

class TestModIds:
    def test_ra_mod_id(self):
        assert ra.MOD_ID == "ra"

    def test_cnc_mod_id(self):
        assert cnc.MOD_ID == "cnc"

    def test_d2k_mod_id(self):
        assert d2k.MOD_ID == "d2k"


# ---------------------------------------------------------------------------
# Faction constants
# ---------------------------------------------------------------------------

class TestFactions:
    def test_ra_factions_all_populated(self):
        assert len(ra.Factions.ALL) == 5
        assert ra.Factions.ENGLAND in ra.Factions.ALL
        assert ra.Factions.RUSSIA in ra.Factions.ALL

    def test_ra_side_aliases(self):
        assert ra.Factions.ALLIED == ra.Factions.ENGLAND
        assert ra.Factions.SOVIET == ra.Factions.RUSSIA

    def test_ra_allied_soviet_partition(self):
        all_set = set(ra.Factions.ALLIED_ALL) | set(ra.Factions.SOVIET_ALL)
        assert all_set == set(ra.Factions.ALL)

    def test_cnc_factions(self):
        assert ra.Factions.ALL != cnc.Factions.ALL
        assert cnc.Factions.GDI == "gdi"
        assert cnc.Factions.NOD == "nod"
        assert len(cnc.Factions.ALL) == 2

    def test_d2k_factions(self):
        assert len(d2k.Factions.ALL) == 3
        assert d2k.Factions.ATREIDES in d2k.Factions.ALL
        assert d2k.Factions.HARKONNEN in d2k.Factions.ALL
        assert d2k.Factions.ORDOS in d2k.Factions.ALL

    def test_d2k_minor_factions(self):
        assert len(d2k.Factions.ALL_WITH_MINOR) == 7
        assert d2k.Factions.CORRINO in d2k.Factions.ALL_WITH_MINOR


# ---------------------------------------------------------------------------
# Building constants
# ---------------------------------------------------------------------------

class TestBuildings:
    def test_all_mods_have_construction_yard(self):
        assert ra.Buildings.CONSTRUCTION_YARD == "fact"
        assert cnc.Buildings.CONSTRUCTION_YARD == "fact"
        assert d2k.Buildings.CONSTRUCTION_YARD == "construction_yard"

    def test_all_mods_have_refinery(self):
        assert ra.Buildings.REFINERY == "proc"
        assert cnc.Buildings.REFINERY == "proc"
        assert d2k.Buildings.REFINERY == "refinery"

    def test_ra_faction_specific_barracks(self):
        assert ra.Buildings.BARRACKS_ALLIED == "tent"
        assert ra.Buildings.BARRACKS_SOVIET == "barr"
        assert ra.Buildings.BARRACKS_ALLIED != ra.Buildings.BARRACKS_SOVIET

    def test_cnc_faction_specific_barracks(self):
        assert cnc.Buildings.BARRACKS_GDI == "pyle"
        assert cnc.Buildings.HAND_OF_NOD == "hand"

    def test_d2k_single_barracks(self):
        assert d2k.Buildings.BARRACKS == "barracks"

    def test_ra_power_plants(self):
        assert ra.Buildings.POWER_PLANT == "powr"
        assert ra.Buildings.ADVANCED_POWER == "apwr"

    def test_cnc_power_plants(self):
        assert cnc.Buildings.POWER_PLANT == "nuke"
        assert cnc.Buildings.ADVANCED_POWER == "nuk2"

    def test_d2k_power(self):
        assert d2k.Buildings.WIND_TRAP == "wind_trap"


# ---------------------------------------------------------------------------
# Unit constants
# ---------------------------------------------------------------------------

class TestUnits:
    def test_all_mods_have_mcv(self):
        assert ra.Units.MCV == "mcv"
        assert cnc.Units.MCV == "mcv"
        assert d2k.Units.MCV == "mcv"

    def test_all_mods_have_harvester(self):
        assert ra.Units.HARVESTER == "harv"
        assert cnc.Units.HARVESTER == "harv"
        assert d2k.Units.HARVESTER == "harvester"

    def test_ra_infantry(self):
        assert ra.Units.RIFLEMAN == "e1"
        assert ra.Units.ENGINEER == "e6"
        assert ra.Units.TANYA == "e7"

    def test_cnc_infantry(self):
        assert cnc.Units.MINIGUNNER == "e1"
        assert cnc.Units.COMMANDO == "e5"
        assert cnc.Units.ENGINEER == "e6"

    def test_d2k_infantry(self):
        assert d2k.Units.LIGHT_INFANTRY == "light_inf"
        assert d2k.Units.ENGINEER == "engineer"
        assert d2k.Units.SARDAUKAR == "sardaukar"

    def test_ra_vehicles(self):
        assert ra.Units.LIGHT_TANK == "1tnk"
        assert ra.Units.HEAVY_TANK == "3tnk"

    def test_cnc_vehicles(self):
        assert cnc.Units.MEDIUM_TANK == "mtnk"
        assert cnc.Units.MAMMOTH_TANK == "htnk"
        assert cnc.Units.BUGGY == "bggy"

    def test_d2k_faction_tanks(self):
        assert d2k.Units.COMBAT_TANK_A == "combat_tank_a"
        assert d2k.Units.COMBAT_TANK_H == "combat_tank_h"
        assert d2k.Units.COMBAT_TANK_O == "combat_tank_o"

    def test_all_constants_are_lowercase_strings(self):
        """All type_id values must be lowercase strings (OpenRA convention)."""
        for mod in (ra, cnc, d2k):
            for cls in (mod.Buildings, mod.Units):
                for attr in dir(cls):
                    if attr.startswith("_"):
                        continue
                    val = getattr(cls, attr)
                    if isinstance(val, str):
                        assert val == val.lower(), f"{mod.MOD_ID}.{cls.__name__}.{attr} = {val!r} is not lowercase"


# ---------------------------------------------------------------------------
# Build orders
# ---------------------------------------------------------------------------

class TestBuildOrders:
    def test_ra_build_orders_are_tuples(self):
        assert isinstance(ra.BuildOrders.ALLIED_INFANTRY_RUSH, tuple)
        assert isinstance(ra.BuildOrders.SOVIET_TANKS, tuple)

    def test_cnc_build_orders_are_tuples(self):
        assert isinstance(cnc.BuildOrders.GDI_INFANTRY_RUSH, tuple)
        assert isinstance(cnc.BuildOrders.NOD_VEHICLE_RUSH, tuple)

    def test_d2k_build_orders_are_tuples(self):
        assert isinstance(d2k.BuildOrders.INFANTRY_RUSH, tuple)
        assert isinstance(d2k.BuildOrders.BALANCED, tuple)

    def test_build_orders_start_with_power(self):
        """Every build order should start with power buildings."""
        assert ra.BuildOrders.ALLIED_INFANTRY_RUSH[0] == ra.Buildings.POWER_PLANT
        assert cnc.BuildOrders.GDI_INFANTRY_RUSH[0] == cnc.Buildings.POWER_PLANT
        assert d2k.BuildOrders.INFANTRY_RUSH[0] == d2k.Buildings.WIND_TRAP

    def test_build_orders_not_empty(self):
        for mod in (ra, cnc, d2k):
            for attr in dir(mod.BuildOrders):
                if attr.startswith("_"):
                    continue
                order = getattr(mod.BuildOrders, attr)
                assert len(order) > 0, f"{mod.MOD_ID}.BuildOrders.{attr} is empty"


# ---------------------------------------------------------------------------
# Cross-mod consistency
# ---------------------------------------------------------------------------

class TestCrossModConsistency:
    def test_shared_type_ids_match_across_mods(self):
        """RA and CNC share some actor IDs (e1, e2, etc)."""
        assert ra.Units.RIFLEMAN == cnc.Units.MINIGUNNER  # both "e1"
        assert ra.Units.GRENADIER == cnc.Units.GRENADIER  # both "e2"

    def test_d2k_uses_readable_ids(self):
        """D2K uses human-readable IDs, not abbreviations."""
        assert "_" in d2k.Buildings.CONSTRUCTION_YARD
        assert "_" in d2k.Units.LIGHT_INFANTRY
