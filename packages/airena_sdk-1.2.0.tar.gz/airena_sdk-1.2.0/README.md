# airena-sdk

Python SDK for writing AiRENA bots. Handles the `openra.v1` protocol so you can focus on bot logic.

Uses only the Python standard library. Requires Python 3.10+.

Install:

```
pip install airena-sdk
```

## Quick start

```python
from airena_sdk import BotRunner, move, queue_production, place_building

def on_tick(obs, ruleset):
    actions = []
    for unit in obs.units:
        if unit.type == "E1":
            actions.append(move(unit.id, x=50, y=50))
    return actions

runner = BotRunner()
runner.run(on_tick)
```

## API

### BotRunner

`BotRunner.run(tick_fn)` — starts the bot loop. Handles handshake, ruleset, and game_over automatically. Calls `tick_fn(obs, ruleset)` each tick expecting a list of actions.

### Actions

| Function | Description |
|---|---|
| `move(unit_id, x, y)` | Move unit to cell |
| `attack_unit(unit_id, target_id)` | Attack enemy unit |
| `deploy(unit_id)` | Deploy MCV or deployable |
| `stop(unit_id)` | Stop unit |
| `harvest(unit_id, x, y)` | Send harvester to resource cell |
| `capture(unit_id, target_id)` | Capture building |
| `queue_production(queue, item)` | Start producing unit/building |
| `cancel_production(queue, item)` | Cancel production item |
| `place_building(item, x, y)` | Place queued building |
| `sell(unit_id)` | Sell building |
| `repair(unit_id)` | Repair building |
| `guard(unit_id, target_id)` | Guard unit |
| `stance(unit_id, stance)` | Set combat stance |
| `scatter(unit_id)` | Scatter unit |
| `force_fire(unit_id, x, y)` | Force fire at cell |
| `patrol(unit_id, x, y)` | Patrol to cell |
| `group_move(unit_ids, x, y)` | Move group |
| `group_attack_move(unit_ids, x, y)` | Attack-move group |
| `noop()` | Explicit no-op |

### Observation

The `obs` argument passed to your tick function is an `Observation` instance:

- `obs.tick` — current tick number
- `obs.units` — list of your units (`Unit`)
- `obs.visible_enemies` — enemies in line of sight (`EnemyUnit`)
- `obs.self` — your player info (`SelfInfo`: credits, power, etc.)
- `obs.resources` — nearby resource cells
- `obs.production_queues` — active production queues
- `obs.action_results` — results from last tick's actions
- `obs.map` — map dimensions
- `obs.game_events` — recent game events

### Ruleset

The `ruleset` argument is a `Ruleset` instance with unit/building/weapon definitions. Available after the first tick.

### Helpers

```python
from airena_sdk import can_afford, can_produce, dps, can_build_at

can_afford(obs, ruleset, "e1")        # True if you can afford to produce E1
can_produce(obs, ruleset, "e1")       # True if tech and queue allow it
dps(ruleset, "e1")                    # Effective DPS of unit type
can_build_at(obs, ruleset, "barr", x, y)  # True if cell is buildable
```

### Mod constants

The `airena_sdk.mods` subpackage provides typed constants for each OpenRA mod — building/unit type IDs, faction names, and common build orders:

```python
from airena_sdk.mods import ra, cnc, d2k

# Use constants instead of hardcoding type IDs
ra.Buildings.BARRACKS_ALLIED   # "tent"
ra.Units.RIFLEMAN              # "e1"
ra.Factions.ENGLAND            # "england"
cnc.Buildings.HAND_OF_NOD      # "hand"
d2k.Units.LIGHT_INFANTRY       # "light_inf"

# Common build orders as tuples
ra.BuildOrders.ALLIED_INFANTRY_RUSH  # ("powr", "powr", "proc", "tent", "e1", ...)
```

Available modules: `ra` (Red Alert), `cnc` (Tiberian Dawn), `d2k` (Dune 2000). Each provides `Buildings`, `Units`, `Factions`, and `BuildOrders` classes.

### Logging

```python
from airena_sdk import log
log("my bot started")  # Writes to STDERR (captured to bot_logs.txt)
```

## Packaging

Located in `sdk/` within the `airena-openra` monorepo. Published to PyPI as `airena-sdk`.

To release: create a GitHub Release tagged `vX.Y.Z` where `X.Y.Z` matches the version in `sdk/pyproject.toml`.
