"""
memstate-langchain
==================

LangChain integration for Memstate AI — persistent, structured, versioned
memory for AI agents.

Memstate is a direct competitor to Mem0, with superior conflict detection,
version history, and server-side intelligence for automatic keypath extraction.

Quick Start
-----------

**Option 1: Semantic memory for LCEL chains**::

    from memstate_langchain import MemstateMemory
    from langchain_openai import ChatOpenAI
    from langchain_core.prompts import ChatPromptTemplate

    llm = ChatOpenAI(model="gpt-4o-mini")
    prompt = ChatPromptTemplate.from_messages([
        ("system", "You are a helpful assistant.\n\n{relevant_memories}"),
        ("human", "{input}"),
    ])
    memory = MemstateMemory(api_key="mst_...", project_id="my-assistant")
    chain = memory.wrap(prompt | llm)          # wrap any LCEL chain
    chain.invoke({"input": "My name is Alice."})

**Option 2: Persistent chat message history**::

    from memstate_langchain import MemstateChatMessageHistory
    from langchain_core.runnables.history import RunnableWithMessageHistory

    chain_with_history = RunnableWithMessageHistory(
        chain,
        lambda session_id: MemstateChatMessageHistory(
            api_key="mst_...",
            project_id="my-assistant",
            session_id=session_id,
        ),
        input_messages_key="input",
        history_messages_key="history",
    )

**Option 3: Agent tools (ReAct / function-calling)**::

    from memstate_langchain import create_memstate_tools
    from langchain_openai import ChatOpenAI
    from langchain.agents import create_tool_calling_agent, AgentExecutor

    tools = create_memstate_tools(api_key="mst_...", project_id="my-app")
    agent = create_tool_calling_agent(ChatOpenAI(model="gpt-4o-mini"), tools, prompt)
    executor = AgentExecutor(agent=agent, tools=tools)

Links
-----
- Website: https://memstate.ai
- Documentation: https://memstate.ai/docs
- Dashboard (get API key): https://memstate.ai/dashboard
- GitHub (MCP): https://github.com/memstate-ai/memstate-mcp
"""

from .memory import (
    MemstateChatMessageHistory,
    MemstateClient,
    MemstateMemory,
    MemstateSemanticMemory,
    MemstateAPIError,
    MemstateConnectionError,
    MemstateError,
)
from .tools import (
    MemstateDeleteTool,
    MemstateGetTool,
    MemstateHistoryTool,
    MemstateRememberTool,
    MemstateSearchTool,
    MemstateSetTool,
    create_memstate_tools,
)

__version__ = "1.0.0"
__author__ = "Memstate AI"
__email__ = "hello@memstate.ai"
__url__ = "https://memstate.ai"

__all__ = [
    # Memory classes
    "MemstateMemory",          # alias for MemstateSemanticMemory
    "MemstateSemanticMemory",
    "MemstateChatMessageHistory",
    # REST client
    "MemstateClient",
    # Exceptions
    "MemstateError",
    "MemstateAPIError",
    "MemstateConnectionError",
    # Tools
    "create_memstate_tools",
    "MemstateRememberTool",
    "MemstateSetTool",
    "MemstateGetTool",
    "MemstateSearchTool",
    "MemstateHistoryTool",
    "MemstateDeleteTool",
]
