"""
Pytest configuration for memstate-langchain tests.
"""

import os
import pytest


def pytest_configure(config):
    """Register custom markers."""
    config.addinivalue_line(
        "markers",
        "integration: mark test as requiring a live Memstate API key",
    )
    config.addinivalue_line(
        "markers",
        "agent: mark test as requiring both MEMSTATE_API_KEY and OPENAI_API_KEY",
    )


def pytest_collection_modifyitems(config, items):
    """
    Automatically skip integration tests if MEMSTATE_API_KEY is not set.
    Automatically skip agent tests if OPENAI_API_KEY is not set.
    """
    skip_integration = pytest.mark.skip(
        reason="MEMSTATE_API_KEY not set — run with: MEMSTATE_API_KEY=mst_... pytest"
    )
    skip_agent = pytest.mark.skip(
        reason="OPENAI_API_KEY not set — run with: OPENAI_API_KEY=sk_... pytest"
    )

    for item in items:
        if "integration" in item.keywords and not os.environ.get("MEMSTATE_API_KEY"):
            item.add_marker(skip_integration)
        if "agent" in item.keywords and not os.environ.get("OPENAI_API_KEY"):
            item.add_marker(skip_agent)
