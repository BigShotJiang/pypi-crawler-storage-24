#!/usr/bin/env python3
"""Example usage of genipng library."""

from genipng import generate, PatternGenerator


def main():
    patterns = ["flowers", "yin_yang", "mandala", "cross_stitch", 
                "geometric_tiles", "waves", "pseudocalligraphy"]
    
    for pattern in patterns:
        filename = f"example_{pattern}.png"
        print(f"Generating {filename}...")
        generate(pattern, filename, width=600, height=400, seed=42)
    
    print("All examples generated!")


if __name__ == "__main__":
    main()
