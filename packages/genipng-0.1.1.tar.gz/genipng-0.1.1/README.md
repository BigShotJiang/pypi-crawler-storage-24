# genipng

Infinite pattern generator in Python.

## Installation

```bash
pip install genipng
```

## Usage

```bash
# Generate flower pattern (default)
genipng -o flowers.png

# Generate different patterns
genipng -p yin_yang -o yinyang.png
genipng -p mandala -o mandala.png
genipng -p cross_stitch -o crossstitch.png
genipng -p geometric_tiles -o tiles.png
genipng -p waves -o waves.png

# Custom size and seed
genipng -p flowers -W 1920 -H 1080 -s 42 -o big_flowers.png

# SVG output
genipng -p geometric_tiles -f svg -o tiles.svg
```

## Available Patterns

- `yin_yang` - Yin-yang symbol
- `flowers` - Flower patterns
- `pseudocalligraphy` - Brush stroke style
- `cross_stitch` - Cross-stitch pattern
- `mandala` - Mandala design
- `geometric_tiles` - Geometric tile patterns
- `waves` - Wave patterns

## As Library

```python
from genipng import generate, PatternGenerator

# Generate from code
generate("flowers", "output.png", width=800, height=600, seed=42)

# Or use class directly
gen = PatternGenerator(width=800, height=600, seed=123)
img = gen.flowers()
img.save("my_flowers.png")
```
