import argparse
import sys
from pathlib import Path
from genipng import generate, PatternGenerator


def main():
    parser = argparse.ArgumentParser(description="Infinite pattern generator for wallpapers")
    parser.add_argument("-p", "--pattern",
                        choices=PatternGenerator.AVAILABLE_PATTERNS,
                        default="flowers", help="Pattern type to generate")
    parser.add_argument("-o", "--output", default="output", help="Output file path")
    parser.add_argument("-W", "--width", type=int, default=800, help="Image width")
    parser.add_argument("-H", "--height", type=int, default=600, help="Image height")
    parser.add_argument("-s", "--seed", type=int, help="Random seed")
    parser.add_argument("-f", "--format", choices=["png", "svg"], default="png",
                        help="Output format")

    args = parser.parse_args()

    # Ensure the output file extension matches the chosen format
    output_path = Path(args.output)
    if output_path.suffix.lower() != f".{args.format}":
        output_path = output_path.with_suffix(f".{args.format}")

    try:
        generate(
            pattern=args.pattern,
            output=str(output_path),
            width=args.width,
            height=args.height,
            seed=args.seed,
            format=args.format
        )
        print(f"Generated successfully: {output_path}")
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
