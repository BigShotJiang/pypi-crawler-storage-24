#!/usr/bin/env python
"""Check that docstrings in specified folders can be parsed.

This script scans Python files in specified directories and checks if their
docstrings can be parsed with the google_docstring_parser.
"""

from __future__ import annotations

import argparse
import ast
import re
import sys
from pathlib import Path
from typing import Any, NamedTuple

import tomli

from google_docstring_parser.google_docstring_parser import (
    parse_google_docstring,
)

# Preview length for short description error messages
SHORT_DESC_PREVIEW_LENGTH = 50

# Default configuration
DEFAULT_CONFIG = {
    "paths": [],  # Empty by default, so no directories are scanned unless explicitly specified
    "require_param_types": False,
    "check_references": True,
    "check_type_consistency": False,
    "min_short_description_length": 0,
    "exclude_files": [],
    "verbose": False,
}


class DocstringContext(NamedTuple):
    """Context for docstring processing, validation, and error reporting.

    Args:
        file_path (Path): Path to the file
        line_no (int): Line number
        name (str): Name of the function or class
        verbose (bool): Whether to print verbose output
        require_param_types (bool): Whether parameter types are required
        check_references (bool): Whether to check references for errors
        check_type_consistency (bool): Whether to compare docstring types with annotations
        min_short_description_length (int): Minimum length for short description
        node (ast.AST | None): AST node for the function or class

    Returns:
        DocstringContext: A named tuple containing docstring processing context
    """

    file_path: Path
    line_no: int
    name: str
    verbose: bool
    require_param_types: bool = False
    check_references: bool = True
    check_type_consistency: bool = False
    min_short_description_length: int = 0
    node: ast.AST | None = None


_CONFIG_KEYS: dict[str, tuple[str, type]] = {
    "paths": ("paths", list),
    "require_param_types": ("require_param_types", bool),
    "check_references": ("check_references", bool),
    "check_type_consistency": ("check_type_consistency", bool),
    "min_short_description_length": ("min_short_description_length", int),
    "exclude_files": ("exclude_files", list),
    "verbose": ("verbose", bool),
}


def _config_keys_match() -> bool:
    """Return True if DEFAULT_CONFIG and _CONFIG_KEYS have the same keys."""
    return set(DEFAULT_CONFIG.keys()) == set(_CONFIG_KEYS.keys())


def _apply_tool_config(config: dict[str, Any], tool_config: dict[str, Any]) -> None:
    """Apply tool_config values to config. Modifies config in place."""
    for key, (config_key, converter) in _CONFIG_KEYS.items():
        if key in tool_config:
            raw = tool_config[key]
            config[config_key] = raw if converter is list else converter(raw)


def load_pyproject_config() -> dict[str, Any]:
    """Load configuration from pyproject.toml if it exists.

    Returns:
        dict[str, Any]: Dictionary with configuration values
    """
    config = DEFAULT_CONFIG.copy()
    pyproject_path = Path("pyproject.toml")
    if not pyproject_path.is_file():
        return config

    try:
        with pyproject_path.open("rb") as f:
            pyproject_data = tomli.load(f)
        tool_config = pyproject_data.get("tool", {}).get("docstring_checker", {})
        if not tool_config:
            return config
        _apply_tool_config(config, tool_config)
    except Exception as e:
        print(f"Warning: Failed to load configuration from pyproject.toml: {e}")

    return config


def get_docstrings(file_path: Path) -> list[tuple[str, int, str | None, ast.AST | None]]:
    """Extract docstrings from a Python file using AST parsing.

    Args:
        file_path (Path): Path to the Python file

    Returns:
        list[tuple[str, int, str | None, ast.AST | None]]: List of tuples containing:
            - str: function/class name
            - int: line number
            - str | None: docstring
            - ast.AST | None: AST node
    """
    with file_path.open(encoding="utf-8") as f:
        content = f.read()

    try:
        tree = ast.parse(content)
    except SyntaxError as e:
        print(f"Syntax error in {file_path}: {e}")
        return []

    docstrings = []

    # Get function and class docstrings only
    for node in ast.walk(tree):
        if isinstance(node, (ast.FunctionDef, ast.ClassDef, ast.AsyncFunctionDef)):
            docstring = ast.get_docstring(node)
            if docstring:
                docstrings.append((node.name, node.lineno, docstring, node))

    return docstrings


def check_param_types(docstring_dict: dict[str, Any], require_types: bool) -> list[str]:
    """Check if all parameters have types when types are required.

    Args:
        docstring_dict (dict[str, Any]): Parsed docstring dictionary
        require_types (bool): Whether parameter types are required

    Returns:
        list[str]: List of error messages for parameters missing types or having invalid types
    """
    if not require_types or "Args" not in docstring_dict:
        return []

    errors = []
    for arg in docstring_dict["Args"]:
        if arg["type"] is None:
            errors.append(f"Parameter '{arg['name']}' is missing a type in docstring")
        elif "invalid type" in arg["type"].lower():
            errors.append(f"Parameter '{arg['name']}' has an invalid type in docstring: '{arg['type']}'")

    return errors


def _normalize_type(type_str: str) -> str:
    """Normalize type string for comparison (quotes and whitespace only).

    Python 3.10+ typing uses list, dict, tuple, X|Y - no List, Dict, Tuple, Union.
    We do not normalize those; mismatches will be reported.
    Internal whitespace differences (e.g., around commas, |, or brackets) are ignored.

    Args:
        type_str (str): Type string to normalize

    Returns:
        str: Normalized type string
    """
    normalized = type_str.strip().strip("'\"")
    return re.sub(r"\s+", "", normalized)


def _annotation_to_str(annotation: ast.expr | None) -> str | None:
    """Extract the type string from an AST annotation node.

    Args:
        annotation (ast.expr | None): AST annotation node

    Returns:
        str | None: Type string or None if no annotation
    """
    if annotation is None:
        return None
    if isinstance(annotation, ast.Constant) and isinstance(annotation.value, str):
        return annotation.value
    return ast.unparse(annotation)


def _get_ast_param_types(node: ast.FunctionDef | ast.AsyncFunctionDef) -> dict[str, str]:
    """Extract parameter names and type strings from function AST.

    Args:
        node (ast.FunctionDef | ast.AsyncFunctionDef): Function AST node

    Returns:
        dict[str, str]: Map of param name to annotation string (skips self/cls)
    """
    ast_params: dict[str, str] = {}
    all_args: list[ast.arg] = []
    all_args.extend(node.args.posonlyargs)
    all_args.extend(node.args.args)
    all_args.extend(node.args.kwonlyargs)
    if node.args.vararg is not None:
        all_args.append(node.args.vararg)
    if node.args.kwarg is not None:
        all_args.append(node.args.kwarg)
    for arg in all_args:
        if arg.arg in ("self", "cls"):
            continue
        if ann_str := _annotation_to_str(arg.annotation):
            ast_params[arg.arg] = ann_str
    return ast_params


def check_type_consistency(
    parsed: dict[str, Any],
    node: ast.FunctionDef | ast.AsyncFunctionDef,
) -> list[str]:
    """Compare docstring types with function annotations.

    Args:
        parsed (dict[str, Any]): Parsed docstring dictionary
        node (ast.FunctionDef | ast.AsyncFunctionDef): Function AST node

    Returns:
        list[str]: List of error messages for type mismatches
    """
    errors = []
    ast_params = _get_ast_param_types(node)

    # Compare Args
    for arg in parsed.get("Args", []):
        doc_type = arg.get("type")
        if not doc_type:
            continue
        param_name = arg.get("name")
        if not param_name or param_name not in ast_params:
            continue
        ast_type = ast_params[param_name]
        if _normalize_type(doc_type) != _normalize_type(ast_type):
            errors.append(
                f"Parameter '{param_name}': docstring says '{doc_type}' but annotation says '{ast_type}'",
            )

    # Compare Returns (handle both dict and string "None" from parse_google_docstring)
    returns = parsed.get("Returns")
    doc_ret: str | None = None
    if isinstance(returns, dict):
        doc_ret = returns.get("type")
    elif isinstance(returns, str):
        doc_ret = returns
    ast_ret = _annotation_to_str(node.returns)
    if doc_ret and ast_ret and _normalize_type(doc_ret) != _normalize_type(ast_ret):
        errors.append(
            f"Returns: docstring says '{doc_ret}' but annotation says '{ast_ret}'",
        )

    return errors


def _check_reference_fields(reference: dict[str, Any], index: int) -> list[str]:
    """Check a single reference for missing or empty fields.

    Args:
        reference (dict[str, Any]): The reference to check
        index (int): The index of the reference (for error messages)

    Returns:
        list[str]: List of error messages
    """
    errors = []

    # Check required fields
    if "description" not in reference:
        errors.append(f"Reference #{index + 1} is missing a description")
    elif not reference["description"]:
        errors.append(f"Reference #{index + 1} has an empty description")

    if "source" not in reference:
        errors.append(f"Reference #{index + 1} is missing a source")
    elif not reference["source"]:
        errors.append(f"Reference #{index + 1} has an empty source")

    return errors


def check_references(docstring_dict: dict[str, Any]) -> list[str]:
    """Check references section for common formatting errors.

    Args:
        docstring_dict (dict[str, Any]): Parsed docstring dictionary

    Returns:
        list[str]: List of error messages for problematic references
    """
    errors = []

    # Check for References section
    for ref_section in ["References", "Reference"]:
        if ref_section in docstring_dict:
            references = docstring_dict[ref_section]

            # Check if references is a list
            if not isinstance(references, list):
                errors.append(f"{ref_section} section is not properly formatted")
                return errors

            # If no references, that's fine
            if not references:
                return errors

            # Check each reference
            for i, ref in enumerate(references):
                if not isinstance(ref, dict):
                    errors.append(f"Reference #{i + 1} is not properly formatted")
                    continue

                errors.extend(_check_reference_fields(ref, i))

            # We've processed one references section, no need to check the other
            break

    return errors


def validate_docstring(docstring: str) -> list[str]:
    """Perform additional validation on docstring format and structure.

    Args:
        docstring (str): The docstring to validate

    Returns:
        list[str]: List of validation error messages
    """
    errors = []

    # Check for unclosed parentheses in parameter types
    lines = docstring.split("\n")
    for line in lines:
        stripped_line = line.strip()
        if not stripped_line:
            continue

        # Check for parameter definitions with unclosed parentheses
        # Improved regex to better detect unclosed parentheses and brackets
        if param_match := re.match(
            r"^\s*(\w+)\s+\(([^)]*$|.*\[[^\]]*$)",
            stripped_line,
        ):
            errors.append(f"Unclosed parenthesis in parameter type: '{stripped_line}'")

        # Check for invalid type declarations
        param_match = re.match(r"^\s*(\w+)\s+\((invalid type)\)", stripped_line)
        if param_match:
            errors.append(f"Invalid type declaration: '{stripped_line}'")

    return errors


def check_returns_section_name(docstring: str) -> list[str]:
    """Check for incorrect Returns section names (e.g. return vs Returns).

    Args:
        docstring (str): The docstring to check

    Returns:
        list[str]: List of error messages for incorrect Returns section names
    """
    errors = []
    lines = docstring.split("\n")
    for line in lines:
        stripped = line.strip()
        if stripped in ["return:", "Return:", "returns:"]:
            errors.append(f"Invalid section name '{stripped}', use 'Returns:' instead")
    return errors


def check_short_description_length(parsed: dict[str, Any], min_length: int) -> list[str]:
    """Check that the short description meets the minimum length requirement.

    Args:
        parsed (dict[str, Any]): Parsed docstring dictionary
        min_length (int): Minimum length for short description (0 to disable)

    Returns:
        list[str]: List of error messages for short descriptions that are too short
    """
    if min_length <= 0:
        return []

    short_desc = (parsed.get("Description") or "").split("\n")[0].strip()
    if not short_desc:
        return []

    if len(short_desc) < min_length:
        preview = (
            short_desc[:SHORT_DESC_PREVIEW_LENGTH] + "..."
            if len(short_desc) > SHORT_DESC_PREVIEW_LENGTH
            else short_desc
        )
        return [
            f"Short description too short ({len(short_desc)} chars, min {min_length}): '{preview}'",
        ]
    return []


def check_returns_type(docstring_dict: dict[str, Any]) -> list[str]:
    """Check that the Returns section has proper type annotation."""
    errors = []
    if returns := docstring_dict.get("Returns"):
        # Special case: Returns section just contains "None"
        if isinstance(returns, str) and returns.strip() == "None":
            return errors

        if not isinstance(returns, dict):
            errors.append("Returns section must be either 'None' or have a type annotation")
            return errors

        if not returns.get("type"):
            errors.append("Returns section is missing type annotation")

    return errors


def _format_error(context: DocstringContext, error: str) -> str:
    """Format an error message consistently with file, line, and name.

    Args:
        context (DocstringContext): Docstring context
        error (str): Error message

    Returns:
        str: Formatted error message
    """
    msg = f"{context.file_path}:{context.line_no}: {error} in '{context.name}'"
    if context.verbose:
        print(msg)
    return msg


def safe_execute(
    context: DocstringContext,
    func: callable,
    *args,  # noqa: ANN002
    error_prefix: str,
    format_results: bool = True,
) -> tuple[list[str], Any]:
    """Safely execute a function and handle errors consistently.

    Args:
        context (DocstringContext): Context for error formatting
        func (callable): Function to execute
        *args (Any): Arguments to pass to the function
        error_prefix (str): Prefix for error messages
        format_results (bool): Whether to format results as errors

    Returns:
        tuple[list[str], Any]: Tuple containing:
            - List of error messages
            - Result of the function if successful, None otherwise
    """
    try:
        result = func(*args)
    except Exception as e:
        return ([_format_error(context, f"{error_prefix}: {e}")], None)

    if format_results and isinstance(result, list):
        return ([_format_error(context, err) for err in result], None)
    return ([], result)


def _check_returns_section(context: DocstringContext, docstring: str) -> list[str]:
    """Check the Returns section name for correct spelling.

    Args:
        context (DocstringContext): Docstring context
        docstring (str): The docstring to process

    Returns:
        list[str]: List of error messages
    """
    errors, _ = safe_execute(
        context,
        check_returns_section_name,
        docstring,
        error_prefix="Error checking Returns section name",
    )
    return errors


def _validate_docstring_format(context: DocstringContext, docstring: str) -> list[str]:
    """Validate docstring format for common structural issues.

    Args:
        context (DocstringContext): Docstring context
        docstring (str): The docstring to process

    Returns:
        list[str]: List of error messages
    """
    errors, _ = safe_execute(
        context,
        validate_docstring,
        docstring,
        error_prefix="Error validating docstring",
    )
    return errors


def _parse_and_check_returns(context: DocstringContext, docstring: str) -> tuple[list[str], dict[str, Any] | None]:
    """Parse docstring and check that the Returns section has proper type.

    Args:
        context (DocstringContext): Docstring context
        docstring (str): The docstring to process

    Returns:
        tuple[list[str], dict[str, Any] | None]: Tuple containing:
            - List of error messages
            - Parsed docstring dictionary if successful, None otherwise
    """
    errors = []

    # Parse docstring
    parse_errors, parsed = safe_execute(
        context,
        parse_google_docstring,
        docstring,
        error_prefix="Error parsing docstring",
        format_results=False,
    )
    if parse_errors:
        return parse_errors, None

    # Check returns type
    returns_errors, _ = safe_execute(
        context,
        check_returns_type,
        parsed,
        error_prefix="Error checking Returns type",
    )
    errors.extend(returns_errors)

    return errors, parsed


def _check_additional_validations(context: DocstringContext, parsed: dict[str, Any]) -> list[str]:
    """Run additional validations on the parsed docstring dictionary.

    Args:
        context (DocstringContext): Docstring context
        parsed (dict[str, Any]): Parsed docstring

    Returns:
        list[str]: List of error messages
    """
    errors = []

    if context.require_param_types:
        type_errors, _ = safe_execute(
            context,
            check_param_types,
            parsed,
            context.require_param_types,
            error_prefix="Error checking parameter types",
        )
        errors.extend(type_errors)

    if context.check_references:
        ref_errors, _ = safe_execute(
            context,
            check_references,
            parsed,
            error_prefix="Error checking references",
        )
        errors.extend(ref_errors)

    if context.min_short_description_length > 0:
        length_errors, _ = safe_execute(
            context,
            check_short_description_length,
            parsed,
            context.min_short_description_length,
            error_prefix="Error checking short description length",
        )
        errors.extend(length_errors)

    if (
        context.check_type_consistency
        and context.node is not None
        and isinstance(context.node, (ast.FunctionDef, ast.AsyncFunctionDef))
    ):
        consistency_errors, _ = safe_execute(
            context,
            check_type_consistency,
            parsed,
            context.node,
            error_prefix="Error checking type consistency",
        )
        errors.extend(consistency_errors)

    return errors


def _process_docstring(context: DocstringContext, docstring: str) -> list[str]:
    """Process a single docstring and collect all validation errors.

    Args:
        context (DocstringContext): Docstring context
        docstring (str): The docstring to process

    Returns:
        list[str]: List of error messages
    """
    if not docstring:
        return []

    errors = []

    # Check Returns section name
    errors.extend(_check_returns_section(context, docstring))

    # Validate docstring format
    format_errors = _validate_docstring_format(context, docstring)
    errors.extend(format_errors)
    if format_errors:
        return errors

    # Parse and check returns
    parse_errors, parsed = _parse_and_check_returns(context, docstring)
    errors.extend(parse_errors)
    if not parsed:
        return errors

    # Run additional validations
    errors.extend(_check_additional_validations(context, parsed))

    return errors


def check_file(
    file_path: Path,
    require_param_types: bool = False,
    verbose: bool = False,
    check_references: bool = True,
    check_type_consistency: bool = False,
    min_short_description_length: int = 0,
) -> list[str]:
    """Check docstrings in a Python file for parsing and validation errors.

    Args:
        file_path (Path): Path to the Python file
        require_param_types (bool): Whether parameter types are required
        verbose (bool): Whether to print verbose output
        check_references (bool): Whether to check references for errors
        check_type_consistency (bool): Whether to compare docstring types with annotations
        min_short_description_length (int): Minimum length for short description (0 to disable)

    Returns:
        list[str]: List of error messages
    """
    if verbose:
        print(f"Checking {file_path}")

    errors = []

    try:
        docstrings = get_docstrings(file_path)
    except Exception as e:
        error_msg = f"{file_path}: Error getting docstrings: {e!s}"
        errors.append(error_msg)
        if verbose:
            print(error_msg)
        return errors

    for name, line_no, docstring, node in docstrings:
        context = DocstringContext(
            file_path=file_path,
            line_no=line_no,
            name=name,
            verbose=verbose,
            require_param_types=require_param_types,
            check_references=check_references,
            check_type_consistency=check_type_consistency,
            min_short_description_length=min_short_description_length,
            node=node,
        )
        errors.extend(_process_docstring(context, docstring))

    return errors


def scan_directory(
    directory: Path,
    exclude_files: list[str] | None = None,
    require_param_types: bool = False,
    verbose: bool = False,
    check_references: bool = True,
    check_type_consistency: bool = False,
    min_short_description_length: int = 0,
) -> list[str]:
    """Scan a directory for Python files and check their docstrings.

    Args:
        directory (Path): Directory to scan
        exclude_files (list[str] | None): List of filenames to exclude
        require_param_types (bool): Whether parameter types are required
        verbose (bool): Whether to print verbose output
        check_references (bool): Whether to check references for errors
        check_type_consistency (bool): Whether to compare docstring types with annotations
        min_short_description_length (int): Minimum length for short description (0 to disable)

    Returns:
        list[str]: List of error messages
    """
    if exclude_files is None:
        exclude_files = []

    errors = []
    for py_file in directory.glob("**/*.py"):
        # Check if the file should be excluded
        should_exclude = False
        for exclude_pattern in exclude_files:
            # Check if the filename matches exactly
            if py_file.name == exclude_pattern:
                should_exclude = True
                break
            # Check if the path ends with the pattern (for subdirectories)
            if str(py_file).endswith(f"/{exclude_pattern}"):
                should_exclude = True
                break

        if not should_exclude:
            errors.extend(
                check_file(
                    py_file,
                    require_param_types,
                    verbose,
                    check_references,
                    check_type_consistency,
                    min_short_description_length,
                ),
            )
    return errors


def _parse_args() -> argparse.Namespace:
    """Parse command line arguments for the docstring checker.

    Returns:
        argparse.Namespace: Parsed command line arguments
    """
    parser = argparse.ArgumentParser(
        description="Check that docstrings in specified folders can be parsed.",
    )
    parser.add_argument(
        "paths",
        nargs="*",
        help="Directories or files to scan for Python docstrings",
    )
    parser.add_argument(
        "--require-param-types",
        action="store_true",
        help="Require parameter types in docstrings",
    )
    ref_group = parser.add_mutually_exclusive_group()
    ref_group.add_argument(
        "--check-references",
        action="store_true",
        help="Check references for errors",
    )
    ref_group.add_argument(
        "--no-check-references",
        action="store_true",
        help="Skip reference checking",
    )
    type_consistency_group = parser.add_mutually_exclusive_group()
    type_consistency_group.add_argument(
        "--check-type-consistency",
        action="store_true",
        help="Compare docstring types with function annotations",
    )
    type_consistency_group.add_argument(
        "--no-check-type-consistency",
        action="store_true",
        help="Skip type consistency checking",
    )
    parser.add_argument(
        "--exclude-files",
        help="Comma-separated list of filenames to exclude",
        default="",
    )
    parser.add_argument("-v", "--verbose", action="store_true", help="Verbose output")
    parser.add_argument(
        "--min-short-description-length",
        type=int,
        metavar="N",
        help="Minimum length for short description (0 to disable)",
    )
    return parser.parse_args()


def _get_config_values(
    args: argparse.Namespace,
    config: dict[str, Any],
) -> tuple[list[str], bool, bool, bool, bool, int, list[str]]:
    """Get configuration values from command line arguments and config file.

    Args:
        args (argparse.Namespace): Command line arguments
        config (dict[str, Any]): Configuration dictionary

    Returns:
        tuple[list[str], bool, bool, bool, bool, int, list[str]]: Tuple containing:
            - List of paths to check
            - Whether to require parameter types
            - Whether to enable verbose output
            - Whether to check references
            - Whether to check type consistency
            - Minimum short description length
            - List of files to exclude
    """
    # Get paths
    paths = args.paths or config["paths"]

    # Get require_param_types
    require_param_types = args.require_param_types or config["require_param_types"]

    # Get verbose
    verbose = args.verbose or config["verbose"]

    # Get check_references - handle both positive and negative flags (mutually exclusive)
    check_references = config["check_references"]
    if args.check_references:
        check_references = True
    if args.no_check_references:
        check_references = False

    # Get check_type_consistency - handle both positive and negative flags (mutually exclusive)
    check_type_consistency = config.get("check_type_consistency", False)
    if args.check_type_consistency:
        check_type_consistency = True
    if args.no_check_type_consistency:
        check_type_consistency = False

    # Get exclude_files
    exclude_files = []
    if args.exclude_files:
        exclude_files = [f.strip() for f in args.exclude_files.split(",") if f.strip()]

    # If no exclude_files specified on command line, use the ones from config
    if not exclude_files:
        exclude_files = config["exclude_files"]

    # Get min_short_description_length - CLI overrides config
    min_short_description_length = config.get("min_short_description_length", 0)
    if args.min_short_description_length is not None:
        min_short_description_length = args.min_short_description_length

    return (
        paths,
        require_param_types,
        verbose,
        check_references,
        check_type_consistency,
        min_short_description_length,
        exclude_files,
    )


def _process_paths(
    paths: list[str],
    exclude_files: list[str],
    require_param_types: bool,
    verbose: bool,
    check_references: bool,
    check_type_consistency: bool,
    min_short_description_length: int,
) -> list[str]:
    """Process paths and check docstrings in each file or directory.

    Args:
        paths (list[str]): List of paths to check
        exclude_files (list[str]): List of files to exclude
        require_param_types (bool): Whether parameter types are required
        verbose (bool): Whether to print verbose output
        check_references (bool): Whether to check references for errors
        check_type_consistency (bool): Whether to compare docstring types with annotations
        min_short_description_length (int): Minimum length for short description (0 to disable)

    Returns:
        list[str]: List of error messages
    """
    all_errors = []
    for path_str in paths:
        path = Path(path_str)
        if path.is_dir():
            errors = scan_directory(
                path,
                exclude_files,
                require_param_types,
                verbose,
                check_references,
                check_type_consistency,
                min_short_description_length,
            )
            all_errors.extend(errors)
        elif path.is_file() and path.suffix == ".py":
            errors = check_file(
                path,
                require_param_types,
                verbose,
                check_references,
                check_type_consistency,
                min_short_description_length,
            )
            all_errors.extend(errors)
        else:
            print(f"Error: {path} is not a directory or Python file")
    return all_errors


def main() -> None:
    """Run the docstring checker and exit with appropriate status code.

    Returns:
        None
    """
    # Load configuration from pyproject.toml
    config = load_pyproject_config()

    # Parse command line arguments
    args = _parse_args()

    # Get configuration values
    (
        paths,
        require_param_types,
        verbose,
        check_references,
        check_type_consistency,
        min_short_description_length,
        exclude_files,
    ) = _get_config_values(args, config)

    # Print configuration if verbose
    if verbose:
        print("Configuration:")
        print(f"  Paths: {paths}")
        print(f"  Require parameter types: {require_param_types}")
        print(f"  Check references: {check_references}")
        print(f"  Check type consistency: {check_type_consistency}")
        print(f"  Min short description length: {min_short_description_length}")
        print(f"  Exclude files: {exclude_files}")

    # Check if paths is empty
    if not paths:
        print(
            "No paths specified for checking. Please specify paths as command line "
            "arguments or configure them in pyproject.toml under [tool.docstring_checker] section.",
        )
        sys.exit(0)

    if all_errors := _process_paths(
        paths,
        exclude_files,
        require_param_types,
        verbose,
        check_references,
        check_type_consistency,
        min_short_description_length,
    ):
        for error in all_errors:
            print(error)
        print(f"\nFound {len(all_errors)} error{'s' if len(all_errors) != 1 else ''}")
        sys.exit(1)
    elif verbose:
        print("All docstrings parsed successfully!")

    sys.exit(0)


if __name__ == "__main__":
    main()
