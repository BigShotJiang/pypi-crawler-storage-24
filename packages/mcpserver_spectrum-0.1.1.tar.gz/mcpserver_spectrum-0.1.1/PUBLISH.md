# PyPI 发布指南

本指南说明如何将 `mcpserver-spectrum` 发布到 PyPI。

## 前置准备

### 1. 注册 PyPI 账号
- 访问 [https://pypi.org/account/register/](https://pypi.org/account/register/) 注册账号
- 验证邮箱地址

### 2. 创建 API Token（推荐）
- 登录 PyPI 后，访问 [https://pypi.org/manage/account/token/](https://pypi.org/manage/account/token/)
- 点击 "Add API token"
- Token 名称：`mcpserver-spectrum-publish`
- 权限范围：选择 "Entire account" 或项目范围
- 复制生成的 token（只显示一次！）

### 3. 配置 .pypirc 文件（可选）
在用户目录下创建 `~/.pypirc` 文件：
```ini
[pypi]
  username = __token__
  password = pypi-你的token在这里
```

## 发布步骤

### 1. 安装构建工具
```bash
pip install --upgrade build twine
```

### 2. 更新版本号
编辑 `pyproject.toml`，更新 `version` 字段：
```toml
version = "0.1.0"  # 更新为新版本号
```

### 3. 构建分发文件
```bash
python -m build
```

这会在 `dist/` 目录下生成：
- `mcpserver-spectrum-0.1.0.tar.gz` (源码包)
- `mcpserver_spectrum-0.1.0-py3-none-any.whl` (wheel 包)

### 4. 上传到 PyPI（使用 API Token）
```bash
twine upload dist/*
```

提示输入用户名时输入 `__token__`，密码输入你的 API token。

或者，如果已配置 `.pypirc`：
```bash
twine upload dist/*
```

### 5. 验证发布
访问 [https://pypi.org/project/mcpserver-spectrum/](https://pypi.org/project/mcpserver-spectrum/) 查看包是否已发布。

## 测试安装

发布成功后，可以测试安装：
```bash
pip install mcpserver-spectrum
```

## 使用 uvx 运行

发布到 PyPI 后，可以使用 uvx 直接运行：
```bash
uvx mcpserver-spectrum
```

## 注意事项

1. **包名唯一性**：确保 `mcpserver-spectrum` 这个包名在 PyPI 上未被占用
2. **版本号**：每次发布必须使用新的版本号
3. **测试环境**：建议先发布到 TestPyPI 测试：
   ```bash
   twine upload --repository testpypi dist/*
   ```
4. **清理旧文件**：每次构建前删除旧的 `dist/` 目录：
   ```bash
   rm -rf dist/ build/ *.egg-info/
   ```

## 常见问题

### Q: 包名已被占用怎么办？
A: 修改 `pyproject.toml` 中的 `name` 字段，使用其他名称。

### Q: 如何更新已发布的版本？
A: 不能覆盖已发布的版本，必须使用新的版本号。

### Q: 如何删除已发布的版本？
A: PyPI 不允许删除版本，但可以隐藏（yank）旧版本。
