''' \"\"\"O-lang Semantic Document Search Resolver - Python implementation\"\"\" '''

__version__ = "1.0.0"
__author__ = "Olang Team"
__email__ = "info@olang.cloud"

from .core import SemanticDocSearch
from .server import main, app

__all__ = ["SemanticDocSearch", "app", "main"]
