"""Tests for identity module."""

import tempfile
from pathlib import Path

from a2a_p2p.identity import PeerIdentity, _b58decode, _b58encode


class TestBase58:
    def test_roundtrip(self):
        data = b"\x00\x01\x02\xff" * 5
        encoded = _b58encode(data)
        decoded = _b58decode(encoded)
        assert decoded == data

    def test_empty(self):
        assert _b58encode(b"") == ""

    def test_zeros(self):
        encoded = _b58encode(b"\x00\x00\x00")
        decoded = _b58decode(encoded)
        assert decoded == b"\x00\x00\x00"


class TestPeerIdentity:
    def test_generate(self):
        identity = PeerIdentity.generate()
        assert identity.peer_id.startswith("a2a:")
        assert len(identity.peer_id) > 10

    def test_deterministic_peer_id(self):
        identity = PeerIdentity.generate()
        # Recreate from same private key
        identity2 = PeerIdentity(identity.private_key)
        assert identity.peer_id == identity2.peer_id

    def test_different_keys_different_ids(self):
        id1 = PeerIdentity.generate()
        id2 = PeerIdentity.generate()
        assert id1.peer_id != id2.peer_id

    def test_save_and_load(self):
        identity = PeerIdentity.generate()
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "keys"
            identity.save(path)

            loaded = PeerIdentity.load(path)
            assert loaded.peer_id == identity.peer_id
            assert loaded.public_key_raw() == identity.public_key_raw()

    def test_save_and_load_with_passphrase(self):
        identity = PeerIdentity.generate()
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "keys"
            identity.save(path, passphrase="test123")

            loaded = PeerIdentity.load(path, passphrase="test123")
            assert loaded.peer_id == identity.peer_id

    def test_sign_and_verify(self):
        identity = PeerIdentity.generate()
        data = b"hello world"
        sig = identity.sign(data)
        assert PeerIdentity.verify(data, sig, identity.public_key)

    def test_verify_wrong_data(self):
        identity = PeerIdentity.generate()
        sig = identity.sign(b"hello")
        assert not PeerIdentity.verify(b"wrong", sig, identity.public_key)

    def test_verify_wrong_key(self):
        id1 = PeerIdentity.generate()
        id2 = PeerIdentity.generate()
        sig = id1.sign(b"hello")
        assert not PeerIdentity.verify(b"hello", sig, id2.public_key)

    def test_public_key_pem_roundtrip(self):
        identity = PeerIdentity.generate()
        pem = identity.public_key_pem()
        assert pem.startswith("-----BEGIN PUBLIC KEY-----")
        loaded = PeerIdentity.load_public_key_pem(pem)
        raw1 = identity.public_key_raw()
        from cryptography.hazmat.primitives.serialization import Encoding, PublicFormat
        raw2 = loaded.public_bytes(Encoding.Raw, PublicFormat.Raw)
        assert raw1 == raw2

    def test_peer_id_short(self):
        identity = PeerIdentity.generate()
        short = identity.peer_id_short()
        assert short.startswith("a2a:")
        assert len(short) == 12
