"""Tests for JSON-backed peer store."""

import tempfile
from pathlib import Path

from a2a_p2p.peer_store import PeerRecord, PeerStore


class TestPeerStore:
    def _make_store(self, tmp: str) -> PeerStore:
        return PeerStore(Path(tmp) / "peers.json")

    def test_empty_store(self):
        with tempfile.TemporaryDirectory() as tmp:
            store = self._make_store(tmp)
            assert len(store) == 0
            assert store.list_all() == []

    def test_save_and_get(self):
        with tempfile.TemporaryDirectory() as tmp:
            store = self._make_store(tmp)
            record = PeerRecord(
                peer_id="a2a:test123",
                alias="Nova",
                trust_level=2,
                capabilities=["code", "research"],
                description="Test agent",
            )
            store.save(record)
            assert len(store) == 1

            got = store.get("a2a:test123")
            assert got is not None
            assert got.alias == "Nova"
            assert got.description == "Test agent"
            assert got.capabilities == ["code", "research"]

    def test_persistence(self):
        with tempfile.TemporaryDirectory() as tmp:
            store = self._make_store(tmp)
            store.save(PeerRecord(peer_id="a2a:abc", alias="Test"))

            # Load fresh
            store2 = self._make_store(tmp)
            assert len(store2) == 1
            assert store2.get("a2a:abc").alias == "Test"

    def test_remove(self):
        with tempfile.TemporaryDirectory() as tmp:
            store = self._make_store(tmp)
            store.save(PeerRecord(peer_id="a2a:abc", alias="Test"))
            assert store.remove("a2a:abc") is True
            assert store.get("a2a:abc") is None
            assert len(store) == 0

    def test_remove_nonexistent(self):
        with tempfile.TemporaryDirectory() as tmp:
            store = self._make_store(tmp)
            assert store.remove("a2a:nope") is False

    def test_update_description(self):
        with tempfile.TemporaryDirectory() as tmp:
            store = self._make_store(tmp)
            store.save(PeerRecord(peer_id="a2a:abc", alias="Test"))
            store.update_description("a2a:abc", "Updated description")
            assert store.get("a2a:abc").description == "Updated description"

    def test_update_trust(self):
        with tempfile.TemporaryDirectory() as tmp:
            store = self._make_store(tmp)
            store.save(PeerRecord(peer_id="a2a:abc", alias="Test", trust_level=1))
            store.update_trust("a2a:abc", 3)
            assert store.get("a2a:abc").trust_level == 3

    def test_update_last_seen(self):
        with tempfile.TemporaryDirectory() as tmp:
            store = self._make_store(tmp)
            store.save(PeerRecord(peer_id="a2a:abc", alias="Test"))
            store.update_last_seen("a2a:abc")
            assert store.get("a2a:abc").last_seen > 0

    def test_upsert(self):
        with tempfile.TemporaryDirectory() as tmp:
            store = self._make_store(tmp)
            store.save(PeerRecord(peer_id="a2a:abc", alias="Old"))
            store.save(PeerRecord(peer_id="a2a:abc", alias="New"))
            assert len(store) == 1
            assert store.get("a2a:abc").alias == "New"

    def test_list_all(self):
        with tempfile.TemporaryDirectory() as tmp:
            store = self._make_store(tmp)
            store.save(PeerRecord(peer_id="a2a:a", alias="A"))
            store.save(PeerRecord(peer_id="a2a:b", alias="B"))
            store.save(PeerRecord(peer_id="a2a:c", alias="C"))
            all_peers = store.list_all()
            assert len(all_peers) == 3
            aliases = {p.alias for p in all_peers}
            assert aliases == {"A", "B", "C"}
