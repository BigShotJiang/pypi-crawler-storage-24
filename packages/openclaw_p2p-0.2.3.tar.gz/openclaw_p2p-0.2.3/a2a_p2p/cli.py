"""CLI entry points for a2a-p2p."""

from __future__ import annotations

import argparse
import sys
from pathlib import Path


def keygen() -> None:
    """Generate a new A2A identity keypair."""
    parser = argparse.ArgumentParser(description="Generate A2A-P2P identity keypair")
    parser.add_argument(
        "--dir", "-d",
        default="~/.a2a/identity",
        help="Directory to save keys (default: ~/.a2a/identity)",
    )
    parser.add_argument(
        "--passphrase", "-p",
        default="",
        help="Passphrase to encrypt the private key (optional)",
    )
    parser.add_argument(
        "--force", "-f",
        action="store_true",
        help="Overwrite existing keys",
    )
    args = parser.parse_args()

    from a2a_p2p.identity import PeerIdentity

    directory = Path(args.dir).expanduser()

    if (directory / "private.pem").exists() and not args.force:
        # Load and display existing
        identity = PeerIdentity.load(directory, passphrase=args.passphrase)
        print(f"Identity already exists at {directory}")
        print(f"PeerID: {identity.peer_id}")
        print(f"Use --force to regenerate")
        sys.exit(0)

    identity = PeerIdentity.generate()
    identity.save(directory, passphrase=args.passphrase)

    print(f"Generated new A2A identity:")
    print(f"  PeerID:  {identity.peer_id}")
    print(f"  Keys:    {directory}/")
    print(f"  Private: {directory}/private.pem")
    print(f"  Public:  {directory}/public.pem")
    if args.passphrase:
        print(f"  (encrypted with passphrase)")
