"""Custom exceptions for a2a-p2p."""


class A2AError(Exception):
    """Base exception for all a2a-p2p errors."""


class PeerUnreachable(A2AError):
    """Could not connect to the specified peer."""

    def __init__(self, peer_id: str, reason: str = "") -> None:
        self.peer_id = peer_id
        msg = f"Peer unreachable: {peer_id}"
        if reason:
            msg += f" ({reason})"
        super().__init__(msg)


class HandshakeFailed(A2AError):
    """The agent handshake protocol failed."""

    def __init__(self, peer_id: str, phase: str, reason: str = "") -> None:
        self.peer_id = peer_id
        self.phase = phase
        msg = f"Handshake failed with {peer_id} at phase '{phase}'"
        if reason:
            msg += f": {reason}"
        super().__init__(msg)


class HandshakeTimeout(HandshakeFailed):
    """Handshake timed out waiting for a response."""

    def __init__(self, peer_id: str, phase: str) -> None:
        super().__init__(peer_id, phase, reason="timeout")


class CryptoError(A2AError):
    """Cryptographic operation failed (bad key, verification failure, etc.)."""


class ProtocolError(A2AError):
    """Wire-protocol violation (bad envelope, unknown version, etc.)."""


class PeerRejected(A2AError):
    """The remote peer (or their owner) rejected the connection."""

    def __init__(self, peer_id: str) -> None:
        self.peer_id = peer_id
        super().__init__(f"Connection rejected by {peer_id}")
