"""JSON-file-backed peer store."""

from __future__ import annotations

import json
import logging
import os
import tempfile
import time
from pathlib import Path

from pydantic import BaseModel, Field

logger = logging.getLogger(__name__)


class PeerRecord(BaseModel):
    """A known peer agent."""

    peer_id: str
    alias: str = ""
    public_key_pem: str = ""
    addresses: list[str] = Field(default_factory=list)
    trust_level: int = 0  # 0=unknown, 1=verified, 2=trusted, 3=allied
    scope_instructions: str = ""
    description: str = ""
    capabilities: list[str] = Field(default_factory=list)
    last_seen: float = 0.0
    added_at: float = Field(default_factory=time.time)
    metadata: dict = Field(default_factory=dict)


class PeerStore:
    """JSON-file-backed store for known peers.

    Loads the full file on init, flushes atomically on every mutation.
    """

    def __init__(self, path: Path | str = "~/.a2a/peers.json") -> None:
        self._path = Path(path).expanduser()
        self._peers: dict[str, PeerRecord] = {}
        self._load()

    def _load(self) -> None:
        """Load peers from disk."""
        if not self._path.exists():
            self._peers = {}
            return
        try:
            raw = self._path.read_text("utf-8")
            data = json.loads(raw)
            self._peers = {
                pid: PeerRecord.model_validate(rec) for pid, rec in data.items()
            }
        except Exception:
            logger.warning("Failed to load peer store from %s", self._path, exc_info=True)
            self._peers = {}

    def _flush(self) -> None:
        """Write peers to disk atomically (write tmp → rename)."""
        self._path.parent.mkdir(parents=True, exist_ok=True)
        data = {pid: rec.model_dump(mode="json") for pid, rec in self._peers.items()}
        # Atomic write: write to temp file then rename
        fd, tmp_path = tempfile.mkstemp(
            dir=str(self._path.parent), suffix=".tmp",
        )
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as f:
                json.dump(data, f, indent=2, ensure_ascii=False)
            os.replace(tmp_path, str(self._path))
        except Exception:
            # Clean up temp file on failure
            try:
                os.unlink(tmp_path)
            except OSError:
                pass
            raise

    def get(self, peer_id: str) -> PeerRecord | None:
        """Get a peer record by PeerID."""
        return self._peers.get(peer_id)

    def save(self, record: PeerRecord) -> None:
        """Insert or update a peer record."""
        self._peers[record.peer_id] = record
        self._flush()

    def remove(self, peer_id: str) -> bool:
        """Remove a peer. Returns True if it existed."""
        if peer_id in self._peers:
            del self._peers[peer_id]
            self._flush()
            return True
        return False

    def list_all(self) -> list[PeerRecord]:
        """Return all known peers."""
        return list(self._peers.values())

    def update_last_seen(self, peer_id: str) -> None:
        """Update a peer's last_seen timestamp."""
        rec = self._peers.get(peer_id)
        if rec:
            rec.last_seen = time.time()
            self._flush()

    def update_description(self, peer_id: str, description: str) -> None:
        """Update a peer's description."""
        rec = self._peers.get(peer_id)
        if rec:
            rec.description = description
            self._flush()

    def update_trust(self, peer_id: str, trust_level: int) -> None:
        """Update a peer's trust level."""
        rec = self._peers.get(peer_id)
        if rec:
            rec.trust_level = trust_level
            self._flush()

    def __len__(self) -> int:
        return len(self._peers)
