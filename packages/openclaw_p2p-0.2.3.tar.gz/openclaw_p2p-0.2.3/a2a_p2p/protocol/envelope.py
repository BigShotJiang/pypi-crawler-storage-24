"""A2AEnvelope — wire-level message wrapper."""

from __future__ import annotations

import time
import uuid

from pydantic import BaseModel, Field


class A2AEnvelope(BaseModel):
    """Every A2A message is wrapped in this envelope."""

    version: int = 1
    id: str = Field(default_factory=lambda: uuid.uuid4().hex)
    sender_id: str = ""       # PeerID of sender
    recipient_id: str = ""    # PeerID of recipient
    timestamp: float = Field(default_factory=time.time)
    type: str                 # MessageType value
    payload: dict = Field(default_factory=dict)
    in_reply_to: str = ""     # For request-response correlation
    signature_hex: str = ""   # Ed25519 signature as hex string

    def signing_material(self) -> bytes:
        """Return the bytes to be signed: id + type + msgpack(payload)."""
        import msgpack
        return (
            self.id.encode("utf-8")
            + self.type.encode("utf-8")
            + msgpack.packb(self.payload, use_bin_type=True)
        )
