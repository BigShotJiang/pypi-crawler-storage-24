"""A2A-P2P: Agent-to-Agent P2P Communication Protocol.

Encrypted, authenticated, relay-capable communication between AI agents.
"""

from a2a_p2p.config import A2AConfig
from a2a_p2p.identity import PeerIdentity
from a2a_p2p.node import A2ANode
from a2a_p2p.peer_store import PeerRecord, PeerStore
from a2a_p2p.protocol.envelope import A2AEnvelope
from a2a_p2p.protocol.types import MessageType

__all__ = [
    "A2AConfig",
    "A2AEnvelope",
    "A2ANode",
    "MessageType",
    "PeerIdentity",
    "PeerRecord",
    "PeerStore",
]

__version__ = "0.2.3"
