"""Transport layer — connection and transport abstractions."""

from a2a_p2p.transport.base import Connection, Transport

__all__ = ["Connection", "Transport"]
