"""Real-world multi-agent support workflow example (Postgres + LangGraph + AIEL memory)."""

