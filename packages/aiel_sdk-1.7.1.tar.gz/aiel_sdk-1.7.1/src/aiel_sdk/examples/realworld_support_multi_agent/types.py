from __future__ import annotations

from typing import Any, Dict, Literal, TypedDict


class SupportState(TypedDict, total=False):
    case_id: str
    user_id: str
    account_id: str
    request_text: str
    openai_resource_id: str
    postgres_resource_id: str
    triage_summary: str
    triage_label: Literal["billing", "general"]
    route: Literal["research", "respond"]
    customer_360: Dict[str, Any]
    risk_report: Dict[str, Any]
    decision: Dict[str, Any]
    execution_result: Dict[str, Any]
    final_response: str
