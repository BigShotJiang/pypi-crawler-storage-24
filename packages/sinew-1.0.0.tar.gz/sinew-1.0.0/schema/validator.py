"""
sinew/schema/validator.py

Standalone validator for sinew.json files.

Takes any sinew.json path, runs it through the full model,
and reports every structural problem clearly — what failed,
where it is in the file, and what needs to be fixed.

Usage (CLI):
    python -m sinew.schema.validator path/to/sinew.json
    python -m sinew.schema.validator path/to/sinew.json --strict
    python -m sinew.schema.validator path/to/sinew.json --json

Usage (programmatic):
    from sinew.schema.validator import validate_file, validate_dict

    result = validate_file("sinew.json")
    if result.passed:
        graph = result.graph
    else:
        for issue in result.issues:
            print(issue)
"""

from __future__ import annotations

import argparse
import json
import sys
import traceback
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any

from pydantic import ValidationError

from sinew.schema.models import (
    sinewGraph,
    ConfidenceLabel,
    EdgeType,
    NodeType,
    confidence_label,
)


# ---------------------------------------------------------------------------
# Issue model
# ---------------------------------------------------------------------------

class IssueSeverity(str, Enum):
    ERROR   = "error"    # invalid schema — graph cannot be used
    WARNING = "warning"  # valid schema but suspicious — graph may mislead
    INFO    = "info"     # advisory — not a problem, just worth knowing


@dataclass
class ValidationIssue:
    severity:  IssueSeverity
    code:      str        # short machine-readable code e.g. "E001"
    message:   str        # human-readable description
    location:  str | None = None   # e.g. "nodes[4].id", "edges[12].confidence"
    context:   str | None = None   # extra detail — what was found, what was expected
    suggestion: str | None = None  # concrete fix hint

    def __str__(self) -> str:
        parts = [f"[{self.severity.value.upper()}] {self.code}: {self.message}"]
        if self.location:
            parts.append(f"  location  : {self.location}")
        if self.context:
            parts.append(f"  context   : {self.context}")
        if self.suggestion:
            parts.append(f"  suggestion: {self.suggestion}")
        return "\n".join(parts)

    def to_dict(self) -> dict[str, Any]:
        return {
            "severity":   self.severity.value,
            "code":       self.code,
            "message":    self.message,
            "location":   self.location,
            "context":    self.context,
            "suggestion": self.suggestion,
        }


# ---------------------------------------------------------------------------
# Validation result
# ---------------------------------------------------------------------------

@dataclass
class ValidationResult:
    passed:     bool
    graph:      sinewGraph | None
    issues:     list[ValidationIssue] = field(default_factory=list)
    file_path:  str | None = None

    @property
    def errors(self) -> list[ValidationIssue]:
        return [i for i in self.issues if i.severity == IssueSeverity.ERROR]

    @property
    def warnings(self) -> list[ValidationIssue]:
        return [i for i in self.issues if i.severity == IssueSeverity.WARNING]

    @property
    def infos(self) -> list[ValidationIssue]:
        return [i for i in self.issues if i.severity == IssueSeverity.INFO]

    def summary(self) -> str:
        status = "PASSED" if self.passed else "FAILED"
        e = len(self.errors)
        w = len(self.warnings)
        i = len(self.infos)
        src = f" — {self.file_path}" if self.file_path else ""
        return f"Validation {status}{src}: {e} error(s), {w} warning(s), {i} info(s)"

    def to_dict(self) -> dict[str, Any]:
        return {
            "passed":    self.passed,
            "file_path": self.file_path,
            "summary":   self.summary(),
            "errors":    len(self.errors),
            "warnings":  len(self.warnings),
            "infos":     len(self.infos),
            "issues":    [i.to_dict() for i in self.issues],
        }


# ---------------------------------------------------------------------------
# Issue codes
# ---------------------------------------------------------------------------
#
# E = Error   (schema-breaking, graph cannot be trusted)
# W = Warning (valid schema, suspicious content)
# I = Info    (advisory)
#
# 0xx — file / parse errors
# 1xx — root and meta errors
# 2xx — node errors
# 3xx — edge errors
# 4xx — index errors
# 5xx — stats errors
# 6xx — cross-reference errors
# 7xx — agent / session errors
# 8xx — warnings
# 9xx — info

CODES = {
    # file / parse
    "E001": "File not found",
    "E002": "File is not valid JSON",
    "E003": "File is empty",
    "E004": "JSON is not an object at root",

    # root
    "E010": "Missing required root field",
    "E011": "sinew_version format invalid",
    "E012": "Root version does not match meta version",

    # meta
    "E020": "meta.total_nodes does not match actual node count",
    "E021": "meta.total_edges does not match actual edge count",
    "E022": "meta.confidence_threshold out of range",

    # nodes
    "E030": "Duplicate node id",
    "E031": "Node id is empty or blank",
    "E032": "Node qualified_name does not match id",
    "E033": "Node line is <= 0",
    "E034": "Node line_end is before line",
    "E035": "Node confidence_min out of range",
    "E036": "Node type is unknown and not NodeType.UNKNOWN",
    "E037": "Node file path is absolute (must be relative)",
    "E038": "Node references parent that does not exist",

    # edges
    "E040": "Duplicate edge id",
    "E041": "Edge from_node references non-existent node",
    "E042": "Edge to_node references non-existent node",
    "E043": "Edge confidence out of range",
    "E044": "Edge id format invalid — expected {from}__{type}__{to}",
    "E045": "Dynamic edge has confidence >= 0.80",
    "E046": "Non-inferred edge has confidence < 0.90",
    "E047": "Edge self-loop — from_node equals to_node",

    # indexes
    "E050": "Reverse index references node id not in nodes",
    "E051": "Origin index references node id not in nodes",
    "E052": "File index references node id not in nodes",
    "E053": "Call index references node id not in nodes",

    # stats
    "E060": "stats.symbols.total_nodes does not match actual node count",
    "E061": "structural_score field out of range 0–100",

    # cross-references
    "E070": "Node test_ids references node id not in nodes",
    "E071": "Node parent references node id not in nodes",
    "E072": "Node children references node id not in nodes",
    "E073": "meta.entry_points references node id not in nodes",

    # agent / session
    "E080": "Session completed but territory_released is False",
    "E081": "AgentWarning resolved_at is set but resolved is False",
    "E082": "sinewAnnotation frozen=True but frozen_reason is missing",

    # warnings
    "W001": "Node has no notes or sinew annotation — undocumented symbol",
    "W002": "Hotspot node has no tests",
    "W003": "Hotspot node has no sinew annotation",
    "W004": "Edge confidence is speculative (< 0.40)",
    "W005": "Frozen node has no owner in sinew annotation",
    "W006": "Node caller_count > 0 but reverse index has no callers for this node",
    "W007": "Critical node has no owner",
    "W008": "Circular dependency detected in call index chain",
    "W009": "Constitution errors present but severity is only warning-level",

    # info
    "I001": "No entry points detected",
    "I002": "No sinew Schema annotations found",
    "I003": "No tests found in graph",
    "I004": "No constitution results present",
    "I005": "Graph has no session state",
    "I006": "Structural score below 70",
}


# ---------------------------------------------------------------------------
# Core validator
# ---------------------------------------------------------------------------

class GraphValidator:
    """
    Runs all validation checks against a raw JSON dict.
    Call validate() to receive a ValidationResult.
    """

    def __init__(self, raw: dict[str, Any], file_path: str | None = None, strict: bool = False):
        self._raw       = raw
        self._file_path = file_path
        self._strict    = strict    # if True, warnings are treated as errors
        self._issues:   list[ValidationIssue] = []
        self._graph:    sinewGraph | None = None

    # -----------------------------------------------------------------------
    # Public entry point
    # -----------------------------------------------------------------------

    def validate(self) -> ValidationResult:
        # Phase 1 — Pydantic model validation
        # If this fails we still run structural checks on whatever we can.
        try:
            self._graph = sinewGraph.model_validate(self._raw)
        except ValidationError as exc:
            self._collect_pydantic_errors(exc)
        except Exception as exc:
            self._add(IssueSeverity.ERROR, "E010",
                      f"Unexpected error during model validation: {exc}",
                      suggestion="Check the JSON structure matches the schema spec.")

        # Phase 2 — structural checks (run regardless of phase 1 result)
        self._check_root_fields()
        self._check_meta()
        self._check_nodes()
        self._check_edges()
        self._check_indexes()
        self._check_stats()
        self._check_cross_references()
        self._check_agent_fields()
        self._check_warnings()
        self._check_info()

        passed = not any(
            i.severity == IssueSeverity.ERROR for i in self._issues
        )
        if self._strict:
            passed = passed and not any(
                i.severity == IssueSeverity.WARNING for i in self._issues
            )

        return ValidationResult(
            passed=passed,
            graph=self._graph if passed else None,
            issues=self._issues,
            file_path=self._file_path,
        )

    # -----------------------------------------------------------------------
    # Phase 1 helper — convert Pydantic errors to our format
    # -----------------------------------------------------------------------

    def _collect_pydantic_errors(self, exc: ValidationError) -> None:
        for err in exc.errors():
            loc   = " → ".join(str(p) for p in err["loc"])
            msg   = err["msg"]
            etype = err["type"]
            self._add(
                IssueSeverity.ERROR, "E010",
                f"Schema validation failed: {msg}",
                location=loc,
                context=f"pydantic error type: {etype}",
                suggestion="Check the schema spec for the correct field type and constraints.",
            )

    # -----------------------------------------------------------------------
    # Phase 2 checks
    # -----------------------------------------------------------------------

    def _check_root_fields(self) -> None:
        required = ["sinew_version", "meta", "nodes", "edges", "indexes", "lists", "stats"]
        for f in required:
            if f not in self._raw:
                self._add(IssueSeverity.ERROR, "E010",
                          f"Missing required root field: '{f}'",
                          location=f,
                          suggestion=f"Add the '{f}' field. See schema spec: Top-Level Structure.")

        version = self._raw.get("sinew_version", "")
        if version:
            parts = str(version).split(".")
            if len(parts) != 2 or not all(p.isdigit() for p in parts):
                self._add(IssueSeverity.ERROR, "E011",
                          f"sinew_version must be 'MAJOR.MINOR', got '{version}'",
                          location="sinew_version",
                          suggestion="Example: \"1.0\"")

        meta_version = self._raw.get("meta", {}).get("sinew_version", "")
        if version and meta_version and version != meta_version:
            self._add(IssueSeverity.ERROR, "E012",
                      "Root sinew_version does not match meta.sinew_version",
                      location="sinew_version / meta.sinew_version",
                      context=f"root='{version}', meta='{meta_version}'",
                      suggestion="Both fields must be identical.")

    def _check_meta(self) -> None:
        meta  = self._raw.get("meta", {})
        nodes = self._raw.get("nodes", [])
        edges = self._raw.get("edges", [])

        declared_nodes = meta.get("total_nodes")
        if declared_nodes is not None and declared_nodes != len(nodes):
            self._add(IssueSeverity.ERROR, "E020",
                      "meta.total_nodes does not match actual node count",
                      location="meta.total_nodes",
                      context=f"declared={declared_nodes}, actual={len(nodes)}",
                      suggestion="Update meta.total_nodes after adding or removing nodes.")

        declared_edges = meta.get("total_edges")
        if declared_edges is not None and declared_edges != len(edges):
            self._add(IssueSeverity.ERROR, "E021",
                      "meta.total_edges does not match actual edge count",
                      location="meta.total_edges",
                      context=f"declared={declared_edges}, actual={len(edges)}",
                      suggestion="Update meta.total_edges after adding or removing edges.")

        threshold = meta.get("confidence_threshold")
        if threshold is not None:
            if not isinstance(threshold, (int, float)) or not (0.0 <= float(threshold) <= 1.0):
                self._add(IssueSeverity.ERROR, "E022",
                          "meta.confidence_threshold must be a float in [0.0, 1.0]",
                          location="meta.confidence_threshold",
                          context=f"got: {threshold}")

    def _check_nodes(self) -> None:
        nodes     = self._raw.get("nodes", [])
        seen_ids: set[str] = set()

        for i, node in enumerate(nodes):
            loc = f"nodes[{i}]"

            # duplicate id
            nid = node.get("id", "")
            if not nid or not nid.strip():
                self._add(IssueSeverity.ERROR, "E031", "Node id is empty or blank",
                          location=f"{loc}.id")
                continue

            if nid in seen_ids:
                self._add(IssueSeverity.ERROR, "E030", f"Duplicate node id: '{nid}'",
                          location=f"{loc}.id",
                          suggestion="Every node must have a unique fully-qualified id.")
            seen_ids.add(nid)

            # qualified_name matches id
            qname = node.get("qualified_name")
            if qname and qname != nid:
                self._add(IssueSeverity.ERROR, "E032",
                          f"Node qualified_name '{qname}' does not match id '{nid}'",
                          location=f"{loc}.qualified_name",
                          suggestion="Set qualified_name to the same value as id.")

            # line numbers
            line     = node.get("line", 0)
            line_end = node.get("line_end")
            if isinstance(line, int) and line <= 0:
                self._add(IssueSeverity.ERROR, "E033",
                          "Node line must be >= 1",
                          location=f"{loc}.line",
                          context=f"got: {line}")
            if isinstance(line_end, int) and isinstance(line, int) and line_end < line:
                self._add(IssueSeverity.ERROR, "E034",
                          f"Node line_end ({line_end}) is before line ({line})",
                          location=f"{loc}.line_end")

            # confidence_min range
            cmin = node.get("confidence_min")
            if cmin is not None:
                if not isinstance(cmin, (int, float)) or not (0.0 <= float(cmin) <= 1.0):
                    self._add(IssueSeverity.ERROR, "E035",
                              "Node confidence_min must be in [0.0, 1.0]",
                              location=f"{loc}.confidence_min",
                              context=f"got: {cmin}")

            # absolute file path
            fpath = node.get("file", "")
            if fpath.startswith("/") or (len(fpath) > 1 and fpath[1] == ":"):
                self._add(IssueSeverity.ERROR, "E037",
                          "Node file path must be relative, not absolute",
                          location=f"{loc}.file",
                          context=f"got: '{fpath}'",
                          suggestion="Use a path relative to the repository root.")

    def _check_edges(self) -> None:
        edges    = self._raw.get("edges", [])
        nodes    = self._raw.get("nodes", [])
        node_ids = {n.get("id") for n in nodes}
        seen_ids: set[str] = set()

        for i, edge in enumerate(edges):
            loc  = f"edges[{i}]"
            eid  = edge.get("id", "")
            frm  = edge.get("from", "")
            to   = edge.get("to", "")
            etype = edge.get("type", "")
            conf = edge.get("confidence")
            is_dynamic  = edge.get("is_dynamic", False)
            is_inferred = edge.get("is_inferred", False)

            # duplicate id
            if eid in seen_ids:
                self._add(IssueSeverity.ERROR, "E040",
                          f"Duplicate edge id: '{eid}'",
                          location=f"{loc}.id")
            seen_ids.add(eid)

            # id format check
            expected_id = f"{frm}__{etype}__{to}"
            if eid and eid != expected_id:
                self._add(IssueSeverity.ERROR, "E044",
                          "Edge id format is invalid",
                          location=f"{loc}.id",
                          context=f"expected '{expected_id}', got '{eid}'",
                          suggestion="Edge id must follow format: {from}__{type}__{to}")

            # node existence
            if frm and frm not in node_ids:
                self._add(IssueSeverity.ERROR, "E041",
                          f"Edge from_node '{frm}' does not exist in nodes",
                          location=f"{loc}.from",
                          suggestion="Ensure the source node is added to the nodes array first.")
            if to and to not in node_ids:
                self._add(IssueSeverity.ERROR, "E042",
                          f"Edge to_node '{to}' does not exist in nodes",
                          location=f"{loc}.to",
                          suggestion="Ensure the target node is added to the nodes array first.")

            # self-loop
            if frm and to and frm == to:
                self._add(IssueSeverity.ERROR, "E047",
                          f"Edge '{eid}' is a self-loop — from_node equals to_node",
                          location=loc,
                          context=f"node: '{frm}'",
                          suggestion="Remove this edge or reconsider the relationship.")

            # confidence range and rules
            if conf is not None:
                if not isinstance(conf, (int, float)) or not (0.0 <= float(conf) <= 1.0):
                    self._add(IssueSeverity.ERROR, "E043",
                              "Edge confidence must be in [0.0, 1.0]",
                              location=f"{loc}.confidence",
                              context=f"got: {conf}")
                else:
                    c = float(conf)
                    if is_dynamic and c >= 0.80:
                        self._add(IssueSeverity.ERROR, "E045",
                                  "Dynamic edge has confidence >= 0.80",
                                  location=f"{loc}.confidence",
                                  context=f"is_dynamic=True, confidence={c}",
                                  suggestion="Dynamic edges must have confidence < 0.80.")
                    if not is_inferred and c < 0.90:
                        self._add(IssueSeverity.ERROR, "E046",
                                  "Non-inferred edge has confidence < 0.90",
                                  location=f"{loc}.confidence",
                                  context=f"is_inferred=False, confidence={c}",
                                  suggestion="Set is_inferred=True if this edge was inferred, "
                                             "or raise confidence if it is a proven relationship.")

    def _check_indexes(self) -> None:
        indexes  = self._raw.get("indexes", {})
        node_ids = {n.get("id") for n in self._raw.get("nodes", [])}

        # reverse index
        for nid, entry in indexes.get("reverse", {}).items():
            if nid not in node_ids:
                self._add(IssueSeverity.ERROR, "E050",
                          f"Reverse index key '{nid}' not in nodes",
                          location=f"indexes.reverse.{nid}",
                          suggestion="Remove stale reverse index entries after deleting nodes.")
            for rel in ("called_by", "imported_by", "instantiated_by", "read_by", "written_by"):
                for ref in entry.get(rel, []):
                    if ref not in node_ids and not ref.endswith(".py") and not ref.endswith(".ts"):
                        # file paths are valid references — only check fully qualified IDs
                        pass  # file-path refs are allowed in imported_by

        # origin index
        for sym, entry in indexes.get("origin", {}).items():
            ref_id = entry.get("id")
            if ref_id and ref_id not in node_ids:
                self._add(IssueSeverity.ERROR, "E051",
                          f"Origin index entry for '{sym}' references unknown node id '{ref_id}'",
                          location=f"indexes.origin.{sym}.id",
                          suggestion="Rebuild origin index after removing nodes.")

        # file index
        for fpath, entry in indexes.get("files", {}).items():
            for ref_id in entry.get("node_ids", []):
                if ref_id not in node_ids:
                    self._add(IssueSeverity.ERROR, "E052",
                              f"File index for '{fpath}' references unknown node id '{ref_id}'",
                              location=f"indexes.files.{fpath}.node_ids",
                              suggestion="Rebuild file index after removing nodes.")

        # call index
        for nid, entry in indexes.get("calls", {}).items():
            if nid not in node_ids:
                self._add(IssueSeverity.ERROR, "E053",
                          f"Call index key '{nid}' not in nodes",
                          location=f"indexes.calls.{nid}")
            for ref_id in entry.get("full_chain", []):
                if ref_id not in node_ids:
                    self._add(IssueSeverity.ERROR, "E053",
                              f"Call index chain for '{nid}' references unknown node '{ref_id}'",
                              location=f"indexes.calls.{nid}.full_chain")

    def _check_stats(self) -> None:
        stats     = self._raw.get("stats", {})
        nodes     = self._raw.get("nodes", [])
        symbols   = stats.get("symbols", {})
        declared  = symbols.get("total_nodes")

        if declared is not None and declared != len(nodes):
            self._add(IssueSeverity.ERROR, "E060",
                      "stats.symbols.total_nodes does not match actual node count",
                      location="stats.symbols.total_nodes",
                      context=f"declared={declared}, actual={len(nodes)}",
                      suggestion="Recompute stats after modifying nodes.")

        score = stats.get("structural_score", {})
        for sf in ("total", "coupling", "cohesion", "circularity", "testability", "dead_code", "documentation"):
            val = score.get(sf)
            if val is not None and not (0 <= int(val) <= 100):
                self._add(IssueSeverity.ERROR, "E061",
                          f"structural_score.{sf} must be in [0, 100]",
                          location=f"stats.structural_score.{sf}",
                          context=f"got: {val}")

    def _check_cross_references(self) -> None:
        nodes       = self._raw.get("nodes", [])
        node_ids    = {n.get("id") for n in nodes}
        entry_pts   = self._raw.get("meta", {}).get("entry_points", [])

        # meta.entry_points
        for ep in entry_pts:
            if ep not in node_ids:
                self._add(IssueSeverity.ERROR, "E073",
                          f"meta.entry_points references unknown node id '{ep}'",
                          location="meta.entry_points",
                          suggestion="Remove stale entry point or add the node to the graph.")

        for i, node in enumerate(nodes):
            loc = f"nodes[{i}]"
            nid = node.get("id", "")

            # parent exists
            parent = node.get("parent")
            if parent and parent not in node_ids:
                self._add(IssueSeverity.ERROR, "E071",
                          f"Node '{nid}' references parent '{parent}' which does not exist",
                          location=f"{loc}.parent",
                          suggestion="Ensure the parent node is present in the graph.")

            # children exist
            children = node.get("children")
            if children is not None:
                for child in children:
                    if child not in node_ids:
                        self._add(IssueSeverity.ERROR, "E072",
                                  f"Node '{nid}' children references unknown node '{child}'",
                                  location=f"{loc}.children",
                                  suggestion="Remove stale child reference or add the missing node.")

            # test_ids exist
            test_ids = node.get("test_ids")
            if test_ids is not None:
                for tid in test_ids:
                    if tid not in node_ids:
                        self._add(IssueSeverity.ERROR, "E070",
                                  f"Node '{nid}' test_ids references unknown node '{tid}'",
                                  location=f"{loc}.test_ids",
                                  suggestion="Remove stale test reference or add the test node.")

    def _check_agent_fields(self) -> None:
        nodes = self._raw.get("nodes", [])

        # frozen annotation requires reason
        for i, node in enumerate(nodes):
            sinew = node.get("sinew")
            if sinew:
                if sinew.get("frozen") and not sinew.get("frozen_reason"):
                    self._add(IssueSeverity.ERROR, "E082",
                              f"Node '{node.get('id')}' has sinew.frozen=True but no frozen_reason",
                              location=f"nodes[{i}].sinew.frozen_reason",
                              suggestion="Add frozen_reason: e.g. 'vendor contract, do not modify'")

        # agent warnings: resolved_at without resolved
        for i, node in enumerate(nodes):
            for j, warn in enumerate(node.get("agent_warnings", [])):
                if warn.get("resolved_at") and not warn.get("resolved"):
                    self._add(IssueSeverity.ERROR, "E081",
                              "AgentWarning has resolved_at but resolved=False",
                              location=f"nodes[{i}].agent_warnings[{j}]",
                              suggestion="Set resolved=True when setting resolved_at.")

        # session state: complete requires territory released
        for j, session in enumerate(self._raw.get("session_state", [])):
            if session.get("status") == "complete" and not session.get("territory_released"):
                self._add(IssueSeverity.ERROR, "E080",
                          f"Session '{session.get('session_id')}' is complete but territory_released=False",
                          location=f"session_state[{j}].territory_released",
                          suggestion="Set territory_released=True when a session completes.")

    def _check_warnings(self) -> None:
        nodes = self._raw.get("nodes", [])

        for i, node in enumerate(nodes):
            nid     = node.get("id", "")
            ntype   = node.get("type", "")
            sinew   = node.get("sinew") or {}
            notes   = node.get("notes")
            hotspot = node.get("is_hotspot", False)
            has_tests = node.get("has_tests", False)
            critical = sinew.get("critical", False)
            owner    = sinew.get("owner")
            frozen   = sinew.get("frozen", False)
            conf_min = node.get("confidence_min", 1.0)

            # undocumented public symbols (not files, not modules, not params)
            if ntype not in ("file", "module", "parameter") and not notes and not sinew.get("note"):
                self._add(IssueSeverity.WARNING, "W001",
                          f"Node '{nid}' has no notes or sinew annotation",
                          location=f"nodes[{i}]",
                          suggestion="Add a docstring or # @sinew: note='...' annotation.")

            # untested hotspot
            if hotspot and not has_tests:
                self._add(IssueSeverity.WARNING, "W002",
                          f"Hotspot node '{nid}' has no tests",
                          location=f"nodes[{i}]",
                          context=f"incoming_edge_count={node.get('incoming_edge_count')}",
                          suggestion="This node is heavily depended on — add tests before modifying.")

            # unannotated hotspot
            if hotspot and not sinew:
                self._add(IssueSeverity.WARNING, "W003",
                          f"Hotspot node '{nid}' has no sinew annotation",
                          location=f"nodes[{i}]",
                          suggestion="Add # @sinew: critical=true note='...' to this symbol.")

            # speculative edges
            if isinstance(conf_min, (int, float)) and float(conf_min) < 0.40:
                self._add(IssueSeverity.WARNING, "W004",
                          f"Node '{nid}' has speculative-confidence edges (min={conf_min})",
                          location=f"nodes[{i}].confidence_min",
                          suggestion="Review dynamic dispatch — consider type annotations to improve confidence.")

            # frozen without owner
            if frozen and not owner:
                self._add(IssueSeverity.WARNING, "W005",
                          f"Frozen node '{nid}' has no sinew.owner",
                          location=f"nodes[{i}].sinew.owner",
                          suggestion="Add owner='team-name' so agents know who to contact.")

            # critical without owner
            if critical and not owner:
                self._add(IssueSeverity.WARNING, "W007",
                          f"Critical node '{nid}' has no sinew.owner",
                          location=f"nodes[{i}].sinew.owner",
                          suggestion="Critical symbols should always have an owner assigned.")

        # circular dependency warning
        indexes = self._raw.get("indexes", {})
        for nid, entry in indexes.get("calls", {}).items():
            chain = entry.get("full_chain", [])
            if len(chain) != len(set(chain)):
                self._add(IssueSeverity.WARNING, "W008",
                          f"Circular dependency detected in call chain starting from '{nid}'",
                          location=f"indexes.calls.{nid}.full_chain",
                          context=" → ".join(chain),
                          suggestion="Consider extracting shared logic into a third module.")

    def _check_info(self) -> None:
        nodes       = self._raw.get("nodes", [])
        entry_pts   = self._raw.get("meta", {}).get("entry_points", [])
        has_sinew   = any(n.get("sinew") for n in nodes)
        has_tests   = any(n.get("has_tests") for n in nodes)
        has_constitution = "constitution_results" in self._raw
        has_sessions = bool(self._raw.get("session_state"))
        score = self._raw.get("stats", {}).get("structural_score", {}).get("total")

        if not entry_pts:
            self._add(IssueSeverity.INFO, "I001",
                      "No entry points detected in this graph",
                      suggestion="Set entry_points in .sinewconfig or add # @sinew: entry_point=true.")

        if not has_sinew:
            self._add(IssueSeverity.INFO, "I002",
                      "No sinew Schema annotations found in this graph",
                      suggestion="Add # @sinew: note='...' to important symbols for richer agent context.")

        if not has_tests:
            self._add(IssueSeverity.INFO, "I003",
                      "No test nodes found in this graph",
                      suggestion="Ensure test files are not excluded by .sinewignore.")

        if not has_constitution:
            self._add(IssueSeverity.INFO, "I004",
                      "No constitution results in this graph",
                      suggestion="Add a .sinewconstitution file to enforce architectural rules.")

        if not has_sessions:
            self._add(IssueSeverity.INFO, "I005",
                      "No agent session state in this graph — first build or sessions not used yet",)

        if score is not None and int(score) < 70:
            self._add(IssueSeverity.INFO, "I006",
                      f"Structural score is {score}/100 — below recommended threshold of 70",
                      suggestion="Run 'sinew stats' for a breakdown of which dimensions to improve.")

    # -----------------------------------------------------------------------
    # Internal helper
    # -----------------------------------------------------------------------

    def _add(self,
             severity:   IssueSeverity,
             code:       str,
             message:    str,
             location:   str | None = None,
             context:    str | None = None,
             suggestion: str | None = None) -> None:
        self._issues.append(ValidationIssue(
            severity=severity,
            code=code,
            message=message,
            location=location,
            context=context,
            suggestion=suggestion,
        ))


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def validate_dict(raw: dict[str, Any],
                  file_path: str | None = None,
                  strict: bool = False) -> ValidationResult:
    """Validate a raw JSON dict. Returns a ValidationResult."""
    return GraphValidator(raw, file_path=file_path, strict=strict).validate()


def validate_file(path: str | Path, strict: bool = False) -> ValidationResult:
    """
    Load and validate a sinew.json file.
    Returns a ValidationResult with graph=None on failure.
    """
    p = Path(path)
    issues: list[ValidationIssue] = []

    if not p.exists():
        return ValidationResult(
            passed=False,
            graph=None,
            file_path=str(path),
            issues=[ValidationIssue(
                severity=IssueSeverity.ERROR, code="E001",
                message=f"File not found: {path}",
                suggestion="Check the path and try again.",
            )],
        )

    content = p.read_text(encoding="utf-8").strip()
    if not content:
        return ValidationResult(
            passed=False,
            graph=None,
            file_path=str(path),
            issues=[ValidationIssue(
                severity=IssueSeverity.ERROR, code="E003",
                message="File is empty",
                suggestion="Run 'sinew build' to generate a valid sinew.json.",
            )],
        )

    try:
        raw = json.loads(content)
    except json.JSONDecodeError as exc:
        return ValidationResult(
            passed=False,
            graph=None,
            file_path=str(path),
            issues=[ValidationIssue(
                severity=IssueSeverity.ERROR, code="E002",
                message=f"File is not valid JSON: {exc}",
                location=f"line {exc.lineno}, column {exc.colno}",
                suggestion="Use a JSON linter to find the syntax error.",
            )],
        )

    if not isinstance(raw, dict):
        return ValidationResult(
            passed=False,
            graph=None,
            file_path=str(path),
            issues=[ValidationIssue(
                severity=IssueSeverity.ERROR, code="E004",
                message="JSON root must be an object, not an array or primitive",
                suggestion="The entire graph must be wrapped in a top-level JSON object {}.",
            )],
        )

    return validate_dict(raw, file_path=str(path), strict=strict)


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def _print_result(result: ValidationResult, as_json: bool = False) -> None:
    if as_json:
        print(json.dumps(result.to_dict(), indent=2, default=str))
        return

    print()
    print("─" * 60)
    print(result.summary())
    print("─" * 60)

    if not result.issues:
        print("  No issues found.")
    else:
        if result.errors:
            print(f"\n  ERRORS ({len(result.errors)})")
            for issue in result.errors:
                print()
                for line in str(issue).splitlines():
                    print(f"    {line}")

        if result.warnings:
            print(f"\n  WARNINGS ({len(result.warnings)})")
            for issue in result.warnings:
                print()
                for line in str(issue).splitlines():
                    print(f"    {line}")

        if result.infos:
            print(f"\n  INFO ({len(result.infos)})")
            for issue in result.infos:
                print()
                for line in str(issue).splitlines():
                    print(f"    {line}")

    print()
    print("─" * 60)
    print()


def main() -> None:
    parser = argparse.ArgumentParser(
        prog="sinew-validate",
        description="Validate a sinew.json file against the schema specification.",
    )
    parser.add_argument(
        "path",
        help="Path to the sinew.json file to validate",
    )
    parser.add_argument(
        "--strict",
        action="store_true",
        default=False,
        help="Treat warnings as errors — exit non-zero if any warnings are found",
    )
    parser.add_argument(
        "--json",
        action="store_true",
        default=False,
        dest="as_json",
        help="Output results as JSON instead of human-readable text",
    )
    args = parser.parse_args()

    result = validate_file(args.path, strict=args.strict)
    _print_result(result, as_json=args.as_json)
    sys.exit(0 if result.passed else 1)


if __name__ == "__main__":
    main()