"""
sinew/schema/models.py

Canonical in-memory representation of the Sinew graph.
Every parser writes to these models. Every consumer reads from them.
Every JSON output is serialized from these models.

Pydantic v2 required: pip install pydantic>=2.0
"""

from __future__ import annotations

from datetime import date, datetime
from enum import Enum
from typing import Any

from pydantic import BaseModel, Field, field_validator, model_validator


# ---------------------------------------------------------------------------
# Enums
# ---------------------------------------------------------------------------

class NodeType(str, Enum):
    FILE        = "file"
    MODULE      = "module"
    CLASS       = "class"
    FUNCTION    = "function"
    METHOD      = "method"
    VARIABLE    = "variable"
    PARAMETER   = "parameter"
    INTERFACE   = "interface"
    STRUCT      = "struct"
    ENUM        = "enum"
    DECORATOR   = "decorator"
    TEST        = "test"
    ENTRY_POINT = "entry_point"
    UNKNOWN     = "unknown"


class EdgeType(str, Enum):
    CALLS       = "calls"
    IMPORTS     = "imports"
    INHERITS    = "inherits"
    IMPLEMENTS  = "implements"
    INSTANTIATES = "instantiates"
    READS       = "reads"
    WRITES      = "writes"
    RETURNS     = "returns"
    RAISES      = "raises"
    DECORATES   = "decorates"
    DEFINES     = "defines"
    RE_EXPORTS  = "re_exports"
    PASSES      = "passes"
    TESTS       = "tests"


class Language(str, Enum):
    PYTHON     = "python"
    JAVASCRIPT = "javascript"
    TYPESCRIPT = "typescript"
    JAVA       = "java"
    GO         = "go"
    RUST       = "rust"
    CPP        = "cpp"
    CSHARP     = "csharp"
    PHP        = "php"
    SWIFT      = "swift"


class Visibility(str, Enum):
    PUBLIC    = "public"
    PRIVATE   = "private"
    PROTECTED = "protected"
    INTERNAL  = "internal"


class ConfidenceLabel(str, Enum):
    DEFINITE    = "definite"     # 0.95 – 1.00
    HIGH        = "high"         # 0.80 – 0.94
    MEDIUM      = "medium"       # 0.60 – 0.79
    LOW         = "low"          # 0.40 – 0.59
    SPECULATIVE = "speculative"  # 0.00 – 0.39


class WarningSeverity(str, Enum):
    LOW      = "low"
    MEDIUM   = "medium"
    HIGH     = "high"
    CRITICAL = "critical"


class SessionStatus(str, Enum):
    COMPLETE  = "complete"
    PARTIAL   = "partial"
    ABANDONED = "abandoned"


class ControlFlowType(str, Enum):
    IF      = "if"
    ELIF    = "elif"
    ELSE    = "else"
    TRY     = "try"
    EXCEPT  = "except"
    FINALLY = "finally"
    FOR     = "for"
    WHILE   = "while"
    SWITCH  = "switch"
    CASE    = "case"
    WITH    = "with"


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def confidence_label(score: float) -> ConfidenceLabel:
    if score >= 0.95:
        return ConfidenceLabel.DEFINITE
    if score >= 0.80:
        return ConfidenceLabel.HIGH
    if score >= 0.60:
        return ConfidenceLabel.MEDIUM
    if score >= 0.40:
        return ConfidenceLabel.LOW
    return ConfidenceLabel.SPECULATIVE


# ---------------------------------------------------------------------------
# Sub-objects
# ---------------------------------------------------------------------------

class Origin(BaseModel):
    """True first-definition location of a symbol."""
    file:                  str
    line:                  int = Field(ge=1)
    is_same_as_definition: bool = True
    re_exported_by:        list[str] = Field(default_factory=list)


class GitMeta(BaseModel):
    """Git context captured at build time."""
    branch:         str
    commit:         str
    commit_message: str | None = None
    committed_at:   datetime | None = None
    dirty:          bool = False


class Parameter(BaseModel):
    """A single function or method parameter."""
    name:            str
    type_annotation: str | None = None
    position:        int = Field(ge=0)
    default_value:   str | None = None
    is_variadic:     bool = False   # *args / **kwargs


class ExceptHandler(BaseModel):
    """A single except/catch block within a try statement."""
    exception_type: str | None = None  # None means bare except
    line:           int = Field(ge=1)
    action:         str | None = None


class ControlFlow(BaseModel):
    """A conditional or exception-handling block inside a function body."""
    type:              ControlFlowType
    line:              int = Field(ge=1)
    condition_summary: str | None = None
    branches:          list[str] = Field(default_factory=list)
    calls_in_block:    list[str] = Field(default_factory=list)
    except_handlers:   list[ExceptHandler] = Field(default_factory=list)


class sinewAnnotation(BaseModel):
    """
    Parsed @sinew: inline annotation.
    All fields are optional — the object is omitted from a node
    entirely when no annotations are present.
    """
    note:             str | None = None
    critical:         bool = False
    frozen:           bool = False
    frozen_reason:    str | None = None
    frozen_since:     date | None = None
    deprecated:       bool = False
    deprecated_reason: str | None = None
    deprecated_since: date | None = None
    group:            str | None = None
    owner:            str | None = None
    since:            date | None = None
    ignore:           bool = False
    custom:           dict[str, Any] = Field(default_factory=dict)

    @model_validator(mode="after")
    def frozen_requires_reason(self) -> "sinewAnnotation":
        if self.frozen and not self.frozen_reason:
            raise ValueError("frozen=true requires frozen_reason to be set")
        return self

    @model_validator(mode="after")
    def deprecated_requires_reason(self) -> "sinewAnnotation":
        if self.deprecated and not self.deprecated_reason:
            raise ValueError("deprecated=true requires deprecated_reason to be set")
        return self


class AgentWarning(BaseModel):
    """
    Persistent mistake memory attached to a node.
    Included in every agent boot payload that touches this node.
    """
    id:             str
    description:    str
    severity:       WarningSeverity
    logged_at:      datetime
    logged_by:      str                # "human-review", "sinew-audit", or session ID
    source_session: str | None = None
    resolved:       bool = False
    resolved_at:    datetime | None = None

    @model_validator(mode="after")
    def resolved_at_requires_resolved(self) -> "AgentWarning":
        if self.resolved_at and not self.resolved:
            raise ValueError("resolved_at is set but resolved is False")
        return self


# ---------------------------------------------------------------------------
# Node
# ---------------------------------------------------------------------------

class Node(BaseModel):
    """
    A single code object in the repository.
    Base fields shared by all node types.
    Type-specific fields are optional and populated only when relevant.
    """

    # --- Identity ---
    id:             str   # fully qualified: "auth.security.verify_password"
    type:           NodeType
    name:           str   # short: "verify_password"
    qualified_name: str   # must match id
    language:       Language
    file:           str   # relative from repo root: "auth/security.py"
    line:           int   = Field(ge=1)
    line_end:       int | None = Field(default=None, ge=1)
    origin:         Origin
    parent:         str | None = None  # ID of enclosing node. None for top-level.

    # --- Structural properties ---
    visibility:          Visibility | None = None
    is_entry_point:      bool = False
    is_hotspot:          bool = False
    caller_count:        int  = Field(default=0, ge=0)
    callee_count:        int  = Field(default=0, ge=0)
    outgoing_edge_count: int  = Field(default=0, ge=0)
    incoming_edge_count: int  = Field(default=0, ge=0)

    # --- Test coverage ---
    has_tests: bool = False
    test_ids:  list[str] = Field(default_factory=list)

    # --- Confidence ---
    confidence_min: float = Field(default=1.0, ge=0.0, le=1.0)

    # --- Documentation ---
    notes: str | None = None  # extracted docstring or nearest comment

    # --- Control flow (functions and methods only) ---
    control_flow: list[ControlFlow] = Field(default_factory=list)

    # --- sinew Schema annotation ---
    sinew: sinewAnnotation | None = None

    # --- Agent warnings ---
    agent_warnings: list[AgentWarning] = Field(default_factory=list)

    # --- Type-specific: file ---
    children:     list[str] | None = None  # IDs of top-level symbols in file
    import_count: int | None = None
    export_count: int | None = None

    # --- Type-specific: class ---
    methods:                list[str] | None = None
    properties:             list[str] | None = None
    base_classes:           list[str] | None = None
    interfaces_implemented: list[str] | None = None
    is_abstract:            bool | None = None

    # --- Type-specific: function / method ---
    parameters:  list[Parameter] | None = None
    return_type: str | None = None
    is_async:    bool | None = None
    is_generator: bool | None = None
    raises:      list[str] | None = None
    decorators:  list[str] | None = None

    # --- Type-specific: variable ---
    value_type:       str | None = None
    is_constant:      bool | None = None
    is_global:        bool | None = None
    assignment_count: int | None = None
    read_count:       int | None = None
    write_count:      int | None = None

    # --- Type-specific: module ---
    is_external:      bool | None = None
    is_stdlib:        bool | None = None
    is_third_party:   bool | None = None
    exported_symbols: list[str] | None = None
    imported_by_count: int | None = None

    @field_validator("qualified_name")
    @classmethod
    def qualified_name_matches_id(cls, v: str, info: Any) -> str:
        node_id = info.data.get("id")
        if node_id and v != node_id:
            raise ValueError(f"qualified_name '{v}' must match id '{node_id}'")
        return v

    @field_validator("line_end")
    @classmethod
    def line_end_after_line(cls, v: int | None, info: Any) -> int | None:
        if v is not None:
            line = info.data.get("line", 1)
            if v < line:
                raise ValueError(f"line_end ({v}) must be >= line ({line})")
        return v

    @property
    def confidence_label(self) -> ConfidenceLabel:
        return confidence_label(self.confidence_min)

    @property
    def is_frozen(self) -> bool:
        return self.sinew is not None and self.sinew.frozen

    @property
    def is_dead(self) -> bool:
        return self.incoming_edge_count == 0 and not self.is_entry_point

    @property
    def has_agent_warnings(self) -> bool:
        return len(self.agent_warnings) > 0

    @property
    def active_warnings(self) -> list[AgentWarning]:
        return [w for w in self.agent_warnings if not w.resolved]


# ---------------------------------------------------------------------------
# Edge
# ---------------------------------------------------------------------------

class Edge(BaseModel):
    """
    A directional relationship between two nodes.
    confidence is always explicit — never assume an edge is proven without checking.
    """
    id:          str        # "{from}__{type}__{to}"
    from_node:   str = Field(alias="from")
    to_node:     str = Field(alias="to")
    type:        EdgeType
    file:        str
    line:        int   = Field(ge=1)
    confidence:  float = Field(ge=0.0, le=1.0)
    is_inferred: bool  = False
    is_dynamic:  bool  = False
    via:         str | None = None  # intermediate node ID if relationship passes through one

    model_config = {"populate_by_name": True}

    @model_validator(mode="after")
    def dynamic_implies_lower_confidence(self) -> "Edge":
        if self.is_dynamic and self.confidence >= 0.80:
            raise ValueError(
                f"Dynamic edge '{self.id}' has confidence {self.confidence} >= 0.80. "
                "Dynamic edges must have confidence < 0.80."
            )
        return self

    @model_validator(mode="after")
    def proven_implies_high_confidence(self) -> "Edge":
        if not self.is_inferred and self.confidence < 0.90:
            raise ValueError(
                f"Non-inferred edge '{self.id}' has confidence {self.confidence} < 0.90. "
                "Proven edges must have confidence >= 0.90."
            )
        return self

    @property
    def confidence_label(self) -> ConfidenceLabel:
        return confidence_label(self.confidence)


# ---------------------------------------------------------------------------
# Indexes
# ---------------------------------------------------------------------------

class ReverseIndexEntry(BaseModel):
    called_by:      list[str] = Field(default_factory=list)
    imported_by:    list[str] = Field(default_factory=list)
    instantiated_by: list[str] = Field(default_factory=list)
    read_by:        list[str] = Field(default_factory=list)
    written_by:     list[str] = Field(default_factory=list)


class OriginIndexEntry(BaseModel):
    id:   str
    file: str
    line: int = Field(ge=1)


class FileImportUsage(BaseModel):
    file:         str
    symbols_used: list[str] = Field(default_factory=list)
    lines:        list[int] = Field(default_factory=list)


class FileIndexEntry(BaseModel):
    node_ids:    list[str] = Field(default_factory=list)
    imports:     list[str] = Field(default_factory=list)
    imported_by: list[str] = Field(default_factory=list)


class ModuleIndexEntry(BaseModel):
    exported_symbols:  list[str] = Field(default_factory=list)
    imported_by:       list[FileImportUsage] = Field(default_factory=list)


class CallIndexEntry(BaseModel):
    calls:      list[str] = Field(default_factory=list)
    called_by:  list[str] = Field(default_factory=list)
    call_depth: int = Field(default=0, ge=0)
    full_chain: list[str] = Field(default_factory=list)


class Indexes(BaseModel):
    reverse: dict[str, ReverseIndexEntry] = Field(default_factory=dict)
    origin:  dict[str, OriginIndexEntry]  = Field(default_factory=dict)
    files:   dict[str, FileIndexEntry]    = Field(default_factory=dict)
    modules: dict[str, ModuleIndexEntry]  = Field(default_factory=dict)
    calls:   dict[str, CallIndexEntry]    = Field(default_factory=dict)


# ---------------------------------------------------------------------------
# Lists
# ---------------------------------------------------------------------------

class FunctionListItem(BaseModel):
    id:           str
    name:         str
    file:         str
    line:         int = Field(ge=1)
    is_dead:      bool = False
    is_hotspot:   bool = False
    has_tests:    bool = False
    sinew_critical: bool = False
    sinew_owner:  str | None = None


class ClassListItem(BaseModel):
    id:           str
    name:         str
    file:         str
    line:         int = Field(ge=1)
    is_abstract:  bool = False
    has_tests:    bool = False
    sinew_critical: bool = False
    sinew_owner:  str | None = None


class VariableListItem(BaseModel):
    id:          str
    name:        str
    file:        str
    line:        int = Field(ge=1)
    is_constant: bool = False
    is_global:   bool = False
    sinew_critical: bool = False


class ModuleListItem(BaseModel):
    id:              str
    name:            str
    is_external:     bool = False
    is_stdlib:       bool = False
    is_third_party:  bool = False
    imported_by_count: int = Field(default=0, ge=0)


class DeadSymbolItem(BaseModel):
    id:            str
    type:          NodeType
    file:          str
    line:          int = Field(ge=1)
    caller_count:  int = Field(default=0, ge=0)
    last_modified: date | None = None


class PhantomImportItem(BaseModel):
    file:            str
    module:          str
    imported_at_line: int = Field(ge=1)
    usage_count:     int = Field(default=0, ge=0)


class HotspotItem(BaseModel):
    id:                  str
    incoming_edge_count: int = Field(ge=0)


class Lists(BaseModel):
    functions:         list[FunctionListItem]  = Field(default_factory=list)
    classes:           list[ClassListItem]     = Field(default_factory=list)
    variables:         list[VariableListItem]  = Field(default_factory=list)
    modules:           list[ModuleListItem]    = Field(default_factory=list)
    dead_symbols:      list[DeadSymbolItem]    = Field(default_factory=list)
    phantom_imports:   list[PhantomImportItem] = Field(default_factory=list)
    frozen_symbols:    list[str]               = Field(default_factory=list)
    deprecated_symbols: list[str]             = Field(default_factory=list)
    hotspots:          list[HotspotItem]       = Field(default_factory=list)


# ---------------------------------------------------------------------------
# Stats
# ---------------------------------------------------------------------------

class FileStats(BaseModel):
    total:       int = Field(ge=0)
    by_language: dict[str, int] = Field(default_factory=dict)


class SymbolStats(BaseModel):
    total_nodes: int = Field(ge=0)
    functions:   int = Field(ge=0)
    classes:     int = Field(ge=0)
    variables:   int = Field(ge=0)
    modules:     int = Field(ge=0)
    interfaces:  int = Field(ge=0)


class DeadCodeStats(BaseModel):
    dead_functions:  int = Field(ge=0)
    dead_classes:    int = Field(ge=0)
    dead_variables:  int = Field(ge=0)
    phantom_imports: int = Field(ge=0)


class ComplexityStats(BaseModel):
    circular_dependencies:       int = Field(ge=0)
    circular_dependency_chains:  list[list[str]] = Field(default_factory=list)
    max_call_depth:              int = Field(ge=0)
    avg_incoming_edges:          float = Field(ge=0.0)
    max_incoming_edges:          int = Field(ge=0)
    max_outgoing_edges:          int = Field(ge=0)


class HotspotStats(BaseModel):
    count: int = Field(ge=0)
    top:   list[HotspotItem] = Field(default_factory=list)


class CoverageStats(BaseModel):
    functions_with_tests:    int   = Field(ge=0)
    functions_without_tests: int   = Field(ge=0)
    coverage_percent:        float = Field(ge=0.0, le=100.0)
    hotspots_without_tests:  int   = Field(ge=0)


class ConfidenceStats(BaseModel):
    edges_above_0_95:   int = Field(ge=0)
    edges_0_80_to_0_95: int = Field(ge=0)
    edges_0_60_to_0_80: int = Field(ge=0)
    edges_below_0_60:   int = Field(ge=0)


class sinewSchemaStats(BaseModel):
    annotated_nodes:    int = Field(ge=0)
    critical_nodes:     int = Field(ge=0)
    frozen_nodes:       int = Field(ge=0)
    deprecated_nodes:   int = Field(ge=0)
    nodes_with_owner:   int = Field(ge=0)


class StructuralScore(BaseModel):
    total:          int = Field(ge=0, le=100)
    coupling:       int = Field(ge=0, le=100)
    cohesion:       int = Field(ge=0, le=100)
    circularity:    int = Field(ge=0, le=100)
    testability:    int = Field(ge=0, le=100)
    dead_code:      int = Field(ge=0, le=100)
    documentation:  int = Field(ge=0, le=100)
    previous_score: int | None = Field(default=None, ge=0, le=100)
    score_delta:    int | None = None
    scored_at:      datetime | None = None


class BusFactorCluster(BaseModel):
    cluster:    str
    bus_factor: int = Field(ge=0)
    sole_owner: str | None = None


class BusFactorStats(BaseModel):
    single_owner_nodes:  int = Field(ge=0)
    riskiest_developer:  str | None = None
    by_cluster:          list[BusFactorCluster] = Field(default_factory=list)


class Stats(BaseModel):
    files:            FileStats
    symbols:          SymbolStats
    dead_code:        DeadCodeStats
    complexity:       ComplexityStats
    hotspots:         HotspotStats
    coverage:         CoverageStats
    confidence:       ConfidenceStats
    sinew_schema:     sinewSchemaStats
    structural_score: StructuralScore
    bus_factor:       BusFactorStats


# ---------------------------------------------------------------------------
# Constitution Results
# ---------------------------------------------------------------------------

class ConstitutionViolation(BaseModel):
    rule_name:   str
    severity:    WarningSeverity
    description: str
    violation:   str
    edge_id:     str | None = None
    chain:       list[str] | None = None
    file:        str | None = None
    line:        int | None = Field(default=None, ge=1)
    suggestion:  str | None = None


class ConstitutionResults(BaseModel):
    evaluated_at:      datetime
    constitution_file: str
    total_rules:       int = Field(ge=0)
    violations:        list[ConstitutionViolation] = Field(default_factory=list)
    warnings:          list[ConstitutionViolation] = Field(default_factory=list)
    passed_rules:      list[str] = Field(default_factory=list)
    error_count:       int = Field(default=0, ge=0)
    warning_count:     int = Field(default=0, ge=0)

    @model_validator(mode="after")
    def counts_match_lists(self) -> "ConstitutionResults":
        errors = [v for v in self.violations if v.severity in (WarningSeverity.HIGH, WarningSeverity.CRITICAL)]
        actual_errors = len([v for v in self.violations])
        if self.error_count != actual_errors:
            raise ValueError(
                f"error_count ({self.error_count}) does not match violations list length ({actual_errors})"
            )
        actual_warnings = len(self.warnings)
        if self.warning_count != actual_warnings:
            raise ValueError(
                f"warning_count ({self.warning_count}) does not match warnings list length ({actual_warnings})"
            )
        return self


# ---------------------------------------------------------------------------
# Session State
# ---------------------------------------------------------------------------

class SessionState(BaseModel):
    """Agent session continuity snapshot — persisted across sessions."""
    session_id:        str
    task:              str
    status:            SessionStatus
    created_at:        datetime
    last_updated:      datetime
    agent_id:          str | None = None
    completed_steps:   list[str] = Field(default_factory=list)
    remaining_steps:   list[str] = Field(default_factory=list)
    dead_ends:         list[str] = Field(default_factory=list)
    decisions:         list[str] = Field(default_factory=list)
    nodes_modified:    list[str] = Field(default_factory=list)
    nodes_read:        list[str] = Field(default_factory=list)
    territory_scope:   str | None = None
    territory_released: bool = False

    @model_validator(mode="after")
    def complete_session_releases_territory(self) -> "SessionState":
        if self.status == SessionStatus.COMPLETE and not self.territory_released:
            raise ValueError("Completed sessions must have territory_released=True")
        return self


# ---------------------------------------------------------------------------
# Meta
# ---------------------------------------------------------------------------

class Meta(BaseModel):
    repo_name:           str
    repo_root:           str
    repo_root_relative:  str = "./"
    built_at:            datetime
    build_duration_ms:   int = Field(ge=0)
    sinew_version:   str
    languages_detected:  list[Language]
    files_scanned:       int = Field(ge=0)
    files_ignored:       int = Field(ge=0)
    total_nodes:         int = Field(ge=0)
    total_edges:         int = Field(ge=0)
    confidence_threshold: float = Field(default=0.75, ge=0.0, le=1.0)
    entry_points:        list[str] = Field(default_factory=list)
    git:                 GitMeta | None = None
    config_file:         str | None = None
    constitution_file:   str | None = None

    @field_validator("sinew_version")
    @classmethod
    def valid_version_format(cls, v: str) -> str:
        parts = v.split(".")
        if len(parts) != 2 or not all(p.isdigit() for p in parts):
            raise ValueError(f"sinew_version must be 'MAJOR.MINOR', got '{v}'")
        return v


# ---------------------------------------------------------------------------
# Root graph — the full sinew.json
# ---------------------------------------------------------------------------

class sinewGraph(BaseModel):
    """
    Root object. The complete in-memory representation of sinew.json.
    Serialise with: graph.model_dump_json(by_alias=True, indent=2)
    """
    sinew_version:   str
    meta:                Meta
    nodes:               list[Node]
    edges:               list[Edge]
    indexes:             Indexes
    lists:               Lists
    stats:               Stats
    constitution_results: ConstitutionResults | None = None
    session_state:       list[SessionState] = Field(default_factory=list)

    @field_validator("sinew_version")
    @classmethod
    def valid_version_format(cls, v: str) -> str:
        parts = v.split(".")
        if len(parts) != 2 or not all(p.isdigit() for p in parts):
            raise ValueError(f"sinew_version must be 'MAJOR.MINOR', got '{v}'")
        return v

    @model_validator(mode="after")
    def version_matches_meta(self) -> "sinewGraph":
        if self.sinew_version != self.meta.sinew_version:
            raise ValueError(
                f"Root sinew_version '{self.sinew_version}' does not match "
                f"meta.sinew_version '{self.meta.sinew_version}'"
            )
        return self

    @model_validator(mode="after")
    def node_count_matches_meta(self) -> "sinewGraph":
        if len(self.nodes) != self.meta.total_nodes:
            raise ValueError(
                f"meta.total_nodes ({self.meta.total_nodes}) does not match "
                f"actual node count ({len(self.nodes)})"
            )
        return self

    @model_validator(mode="after")
    def edge_count_matches_meta(self) -> "sinewGraph":
        if len(self.edges) != self.meta.total_edges:
            raise ValueError(
                f"meta.total_edges ({self.meta.total_edges}) does not match "
                f"actual edge count ({len(self.edges)})"
            )
        return self

    @model_validator(mode="after")
    def edge_nodes_exist(self) -> "sinewGraph":
        node_ids = {n.id for n in self.nodes}
        for edge in self.edges:
            if edge.from_node not in node_ids:
                raise ValueError(f"Edge '{edge.id}' references unknown from_node '{edge.from_node}'")
            if edge.to_node not in node_ids:
                raise ValueError(f"Edge '{edge.id}' references unknown to_node '{edge.to_node}'")
        return self

    @model_validator(mode="after")
    def no_duplicate_node_ids(self) -> "sinewGraph":
        seen: set[str] = set()
        for node in self.nodes:
            if node.id in seen:
                raise ValueError(f"Duplicate node id: '{node.id}'")
            seen.add(node.id)
        return self

    @model_validator(mode="after")
    def no_duplicate_edge_ids(self) -> "sinewGraph":
        seen: set[str] = set()
        for edge in self.edges:
            if edge.id in seen:
                raise ValueError(f"Duplicate edge id: '{edge.id}'")
            seen.add(edge.id)
        return self

    # --- Convenience lookups ---

    def get_node(self, node_id: str) -> Node | None:
        for node in self.nodes:
            if node.id == node_id:
                return node
        return None

    def get_edges_from(self, node_id: str) -> list[Edge]:
        return [e for e in self.edges if e.from_node == node_id]

    def get_edges_to(self, node_id: str) -> list[Edge]:
        return [e for e in self.edges if e.to_node == node_id]

    def get_callers(self, node_id: str) -> list[Node]:
        caller_ids = [e.from_node for e in self.edges if e.to_node == node_id and e.type == EdgeType.CALLS]
        return [n for n in self.nodes if n.id in caller_ids]

    def get_callees(self, node_id: str) -> list[Node]:
        callee_ids = [e.to_node for e in self.edges if e.from_node == node_id and e.type == EdgeType.CALLS]
        return [n for n in self.nodes if n.id in callee_ids]

    def get_hotspots(self) -> list[Node]:
        return [n for n in self.nodes if n.is_hotspot]

    def get_dead_symbols(self) -> list[Node]:
        return [n for n in self.nodes if n.is_dead and n.type not in (NodeType.FILE, NodeType.MODULE)]

    def get_frozen_nodes(self) -> list[Node]:
        return [n for n in self.nodes if n.is_frozen]

    def get_nodes_by_type(self, node_type: NodeType) -> list[Node]:
        return [n for n in self.nodes if n.type == node_type]

    def get_nodes_by_file(self, file_path: str) -> list[Node]:
        return [n for n in self.nodes if n.file == file_path]

    def get_nodes_with_warnings(self) -> list[Node]:
        return [n for n in self.nodes if n.has_agent_warnings]

    # --- Serialisation ---

    def to_json(self, indent: int = 2) -> str:
        return self.model_dump_json(by_alias=True, indent=indent)

    @classmethod
    def from_json(cls, json_str: str) -> "sinewGraph":
        return cls.model_validate_json(json_str)