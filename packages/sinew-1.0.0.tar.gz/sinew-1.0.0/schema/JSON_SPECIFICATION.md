# Sinew JSON Schema Specification
## Version 1.0

---

This document is the authoritative specification for the `sinew.json` graph format.

Every parser, renderer, agent tool, MCP server, CI integration, and export format is built on this schema. If the schema is right, everything built on top of it is right. If the schema changes, this document changes first and everything else follows.

---

## Table of Contents

- [Design Principles](#design-principles)
- [Top-Level Structure](#top-level-structure)
- [Meta Object](#meta-object)
- [Node Object](#node-object)
  - [Node Types](#node-types)
  - [Node Fields by Type](#node-fields-by-type)
- [Edge Object](#edge-object)
  - [Edge Types](#edge-types)
  - [Confidence Scoring](#confidence-scoring)
- [Symbol Object](#symbol-object)
- [Origin Object](#origin-object)
- [sinew Annotation Object](#sinew-annotation-object)
- [Agent Warning Object](#agent-warning-object)
- [Control Flow Object](#control-flow-object)
- [Indexes](#indexes)
  - [Reverse Index](#reverse-index)
  - [Origin Index](#origin-index)
  - [File Index](#file-index)
  - [Module Index](#module-index)
  - [Call Index](#call-index)
- [Lists](#lists)
- [Stats Object](#stats-object)
- [Constitution Results Object](#constitution-results-object)
- [Session State Object](#session-state-object)
- [Full Example](#full-example)
- [Field Reference](#field-reference)
- [Versioning and Compatibility](#versioning-and-compatibility)

---

## Design Principles

**1. Fully self-contained.**
A `sinew.json` file must be interpretable without access to the source repository. Every node carries its file path, line number, and origin. No consumer should need to open a source file to understand what a node represents.

**2. Flat over nested.**
Nodes and edges live in flat arrays at the top level. Deep nesting of relationships creates parsing complexity and makes graph traversal expensive. Relationships between objects are expressed as references by `id`, not as nested children.

**3. IDs are fully qualified.**
Every node `id` is a dot-separated fully qualified path from the repository root. This prevents collisions across files, packages, and languages. There are no short names as primary keys.

**4. Confidence is always explicit.**
Every edge carries a `confidence` score. An edge with no confidence score is a schema violation. Consumers must never treat inferred relationships as proven relationships without checking this field.

**5. Agent fields are first-class.**
Fields like `sinew_frozen`, `agent_warnings`, and `session_state` are not extensions or plugins. They are part of the core schema. The graph is designed to serve both humans and machines equally.

**6. Additive versioning.**
New fields are added without breaking existing consumers. Fields are never removed without a major version increment. Consumers must ignore unknown fields gracefully.

---

## Top-Level Structure

```json
{
  "sinew_version": "1.0",
  "meta": { ... },
  "nodes": [ ... ],
  "edges": [ ... ],
  "indexes": { ... },
  "lists": { ... },
  "stats": { ... },
  "constitution_results": { ... },
  "session_state": { ... }
}
```

| Field | Type | Required | Description |
|---|---|---|---|
| `sinew_version` | `string` | ✅ | Schema version. Format: `"MAJOR.MINOR"` |
| `meta` | `Meta` | ✅ | Graph metadata — repository info, build details |
| `nodes` | `Node[]` | ✅ | All code objects in the repository |
| `edges` | `Edge[]` | ✅ | All relationships between code objects |
| `indexes` | `Indexes` | ✅ | Pre-computed lookup indexes for fast queries |
| `lists` | `Lists` | ✅ | Flat typed lists — functions, classes, variables, modules |
| `stats` | `Stats` | ✅ | Repository health metrics |
| `constitution_results` | `ConstitutionResults` | ❌ | Results of architecture constitution validation |
| `session_state` | `SessionState[]` | ❌ | Agent session continuity snapshots |

---

## Meta Object

The `meta` object describes the repository and the build that produced the graph.

```json
"meta": {
  "repo_name": "my-project",
  "repo_root": "/home/raj/projects/my-project",
  "repo_root_relative": "./",
  "built_at": "2026-03-15T14:32:00Z",
  "build_duration_ms": 4821,
  "sinew_version": "1.0",
  "languages_detected": ["python", "typescript"],
  "files_scanned": 142,
  "files_ignored": 23,
  "total_nodes": 2847,
  "total_edges": 6103,
  "confidence_threshold": 0.75,
  "entry_points": [
    "app.main",
    "app.server.run"
  ],
  "git": {
    "branch": "main",
    "commit": "a3f92c1",
    "commit_message": "feat: add password reset flow",
    "committed_at": "2026-03-14T10:21:00Z",
    "dirty": false
  },
  "config_file": ".sinewconfig",
  "constitution_file": ".sinewconstitution"
}
```

| Field | Type | Required | Description |
|---|---|---|---|
| `repo_name` | `string` | ✅ | Repository directory name |
| `repo_root` | `string` | ✅ | Absolute path to repository root at build time |
| `repo_root_relative` | `string` | ✅ | Relative path — always `"./"` for top-level builds |
| `built_at` | `string` | ✅ | ISO 8601 UTC timestamp of build |
| `build_duration_ms` | `integer` | ✅ | Total build time in milliseconds |
| `sinew_version` | `string` | ✅ | Must match top-level `sinew_version` |
| `languages_detected` | `string[]` | ✅ | Languages found and parsed in this repository |
| `files_scanned` | `integer` | ✅ | Number of source files parsed |
| `files_ignored` | `integer` | ✅ | Number of files skipped by ignore rules |
| `total_nodes` | `integer` | ✅ | Total node count |
| `total_edges` | `integer` | ✅ | Total edge count |
| `confidence_threshold` | `float` | ✅ | Minimum confidence for edges to be included |
| `entry_points` | `string[]` | ❌ | Fully qualified IDs of detected entry point nodes |
| `git` | `GitMeta` | ❌ | Git context at build time |
| `config_file` | `string` | ❌ | Path to `.sinewconfig` used for this build |
| `constitution_file` | `string` | ❌ | Path to `.sinewconstitution` used for this build |

### GitMeta Object

| Field | Type | Required | Description |
|---|---|---|---|
| `branch` | `string` | ✅ | Current git branch |
| `commit` | `string` | ✅ | Short commit SHA |
| `commit_message` | `string` | ❌ | First line of commit message |
| `committed_at` | `string` | ❌ | ISO 8601 UTC timestamp of last commit |
| `dirty` | `boolean` | ✅ | `true` if working directory has uncommitted changes |

---

## Node Object

A node represents any named, addressable code object in the repository.

```json
{
  "id": "auth.security.verify_password",
  "type": "function",
  "name": "verify_password",
  "qualified_name": "auth.security.verify_password",
  "language": "python",
  "file": "auth/security.py",
  "line": 42,
  "line_end": 61,
  "origin": {
    "file": "auth/security.py",
    "line": 42
  },
  "parent": "auth.security",
  "visibility": "public",
  "is_entry_point": false,
  "is_hotspot": true,
  "caller_count": 17,
  "callee_count": 4,
  "outgoing_edge_count": 5,
  "incoming_edge_count": 17,
  "has_tests": true,
  "test_ids": ["tests.test_auth.test_valid_login", "tests.test_auth.test_locked_account"],
  "confidence_min": 0.91,
  "notes": "Authenticates a user credential pair. Raises AuthError on failure.",
  "control_flow": [ ... ],
  "sinew": { ... },
  "agent_warnings": [ ... ]
}
```

### Core Node Fields

| Field | Type | Required | Description |
|---|---|---|---|
| `id` | `string` | ✅ | Fully qualified unique ID. Format: `package.module.ClassName.method_name` |
| `type` | `NodeType` | ✅ | One of the defined node types. See [Node Types](#node-types) |
| `name` | `string` | ✅ | Short unqualified symbol name |
| `qualified_name` | `string` | ✅ | Full dot-separated path. Must match `id` |
| `language` | `string` | ✅ | Source language: `python`, `javascript`, `typescript`, `java`, `go`, `rust`, `cpp`, `csharp`, `php`, `swift` |
| `file` | `string` | ✅ | Relative path from repo root to the source file |
| `line` | `integer` | ✅ | Line number of the symbol definition (1-indexed) |
| `line_end` | `integer` | ❌ | Last line of the symbol body. Omitted for single-line symbols |
| `origin` | `Origin` | ✅ | True first-definition location. See [Origin Object](#origin-object) |
| `parent` | `string` | ❌ | ID of the enclosing node. `null` for file-level symbols |
| `visibility` | `string` | ❌ | `public`, `private`, `protected`, `internal`. Language-dependent |
| `is_entry_point` | `boolean` | ✅ | `true` if this node is a detected application entry point |
| `is_hotspot` | `boolean` | ✅ | `true` if `incoming_edge_count` exceeds the hotspot threshold (default: 10) |
| `caller_count` | `integer` | ✅ | Number of nodes that call or import this node directly |
| `callee_count` | `integer` | ✅ | Number of nodes this node calls or imports |
| `outgoing_edge_count` | `integer` | ✅ | Total outgoing edges from this node |
| `incoming_edge_count` | `integer` | ✅ | Total incoming edges to this node |
| `has_tests` | `boolean` | ✅ | `true` if at least one test node references this node |
| `test_ids` | `string[]` | ❌ | IDs of test nodes that cover this symbol |
| `confidence_min` | `float` | ✅ | Lowest confidence score among all edges from this node. Range: 0.0–1.0 |
| `notes` | `string` | ❌ | Extracted docstring or nearest comment above the symbol |
| `control_flow` | `ControlFlow[]` | ❌ | Conditionals and exception blocks within this symbol |
| `sinew` | `sinewAnnotation` | ❌ | sinew Schema annotation if present |
| `agent_warnings` | `AgentWarning[]` | ❌ | Persistent mistake memories attached to this node |

---

### Node Types

| Type | Description | Example |
|---|---|---|
| `file` | A source file | `auth/login.py` |
| `module` | An importable module or package | `database`, `os`, `express` |
| `class` | A class definition | `AuthService` |
| `function` | A standalone function | `verify_password` |
| `method` | A function defined inside a class | `AuthService.login` |
| `variable` | A module-level or class-level named binding | `db_conn`, `MAX_RETRIES` |
| `parameter` | A function parameter that is tracked for data flow | `user` in `def login(user)` |
| `interface` | An interface or protocol definition | `IAuthProvider` |
| `struct` | A struct or named data type | `UserConfig` |
| `enum` | An enum type | `AuthStatus` |
| `decorator` | A decorator or annotation applied to a symbol | `@login_required` |
| `test` | A test function or class | `test_valid_login` |
| `entry_point` | A special alias node for detected application entry points | `app:main` |

---

### Node Fields by Type

Some fields are specific to certain node types.

#### `file` nodes

```json
{
  "id": "auth.security",
  "type": "file",
  "name": "security.py",
  "file": "auth/security.py",
  "line": 1,
  "line_end": 214,
  "children": [
    "auth.security.verify_password",
    "auth.security.hash_password",
    "auth.security.AuthError"
  ],
  "import_count": 4,
  "export_count": 6
}
```

| Field | Type | Description |
|---|---|---|
| `children` | `string[]` | IDs of all top-level symbols defined in this file |
| `import_count` | `integer` | Number of modules or symbols imported |
| `export_count` | `integer` | Number of symbols exported or accessible from this file |

#### `class` nodes

```json
{
  "id": "auth.service.AuthService",
  "type": "class",
  "name": "AuthService",
  "methods": [
    "auth.service.AuthService.login",
    "auth.service.AuthService.logout"
  ],
  "properties": [
    "auth.service.AuthService.db_conn"
  ],
  "base_classes": ["auth.base.BaseService"],
  "interfaces_implemented": ["auth.interfaces.IAuthProvider"],
  "is_abstract": false
}
```

| Field | Type | Description |
|---|---|---|
| `methods` | `string[]` | IDs of all methods defined on this class |
| `properties` | `string[]` | IDs of class-level variable nodes |
| `base_classes` | `string[]` | IDs of parent classes. Empty array if none |
| `interfaces_implemented` | `string[]` | IDs of interfaces or protocols this class implements |
| `is_abstract` | `boolean` | `true` if this is an abstract class or base class |

#### `function` and `method` nodes

```json
{
  "id": "auth.security.verify_password",
  "type": "function",
  "parameters": [
    {
      "name": "user",
      "type_annotation": "User",
      "position": 0
    },
    {
      "name": "password",
      "type_annotation": "str",
      "position": 1
    }
  ],
  "return_type": "bool",
  "is_async": false,
  "is_generator": false,
  "raises": ["AuthError", "DatabaseError"],
  "decorators": ["auth.decorators.rate_limited"]
}
```

| Field | Type | Description |
|---|---|---|
| `parameters` | `Parameter[]` | Ordered list of function parameters |
| `return_type` | `string` | Return type annotation if present |
| `is_async` | `boolean` | `true` if the function is async |
| `is_generator` | `boolean` | `true` if the function uses `yield` |
| `raises` | `string[]` | Exception types this function is documented or detected to raise |
| `decorators` | `string[]` | IDs of decorators applied to this function |

#### `variable` nodes

```json
{
  "id": "auth.security.db_conn",
  "type": "variable",
  "value_type": "DatabaseConnection",
  "is_constant": false,
  "is_global": false,
  "assignment_count": 1,
  "read_count": 14,
  "write_count": 1
}
```

| Field | Type | Description |
|---|---|---|
| `value_type` | `string` | Inferred or annotated type of the variable |
| `is_constant` | `boolean` | `true` if the variable is declared as a constant |
| `is_global` | `boolean` | `true` if the variable is module-level |
| `assignment_count` | `integer` | Number of locations where this variable is assigned |
| `read_count` | `integer` | Number of locations where this variable is read |
| `write_count` | `integer` | Number of locations where this variable is written |

#### `module` nodes

```json
{
  "id": "database",
  "type": "module",
  "is_external": false,
  "is_stdlib": false,
  "is_third_party": false,
  "exported_symbols": [
    "database.get_user",
    "database.create_record",
    "database.db_conn"
  ],
  "imported_by_count": 6
}
```

| Field | Type | Description |
|---|---|---|
| `is_external` | `boolean` | `true` if the module is outside the repository |
| `is_stdlib` | `boolean` | `true` if the module is part of the language standard library |
| `is_third_party` | `boolean` | `true` if the module is an installed third-party package |
| `exported_symbols` | `string[]` | IDs of symbols exported from this module |
| `imported_by_count` | `integer` | Number of files that import this module |

---

## Edge Object

An edge represents a directional relationship between two nodes.

```json
{
  "id": "auth.security.verify_password__calls__database.queries.get_user",
  "from": "auth.security.verify_password",
  "to": "database.queries.get_user",
  "type": "calls",
  "file": "auth/security.py",
  "line": 55,
  "confidence": 0.97,
  "is_inferred": false,
  "is_dynamic": false,
  "via": null
}
```

| Field | Type | Required | Description |
|---|---|---|---|
| `id` | `string` | ✅ | Unique edge ID. Format: `{from}__{type}__{to}` |
| `from` | `string` | ✅ | ID of the source node |
| `to` | `string` | ✅ | ID of the target node |
| `type` | `EdgeType` | ✅ | One of the defined edge types. See [Edge Types](#edge-types) |
| `file` | `string` | ✅ | File where this relationship is expressed |
| `line` | `integer` | ✅ | Line number where this relationship is expressed |
| `confidence` | `float` | ✅ | Certainty that this relationship is correct. Range: 0.0–1.0 |
| `is_inferred` | `boolean` | ✅ | `true` if this edge was inferred from dynamic dispatch or type analysis |
| `is_dynamic` | `boolean` | ✅ | `true` if the target cannot be statically resolved |
| `via` | `string` | ❌ | ID of an intermediate node if the relationship passes through one (e.g. a decorator or middleware) |

---

### Edge Types

| Type | Direction | Description |
|---|---|---|
| `calls` | `function → function` | A calls B directly |
| `imports` | `file → module` or `file → symbol` | A imports B |
| `inherits` | `class → class` | A extends B |
| `implements` | `class → interface` | A implements B |
| `instantiates` | `function → class` | A creates an instance of B |
| `reads` | `function → variable` | A reads the value of B |
| `writes` | `function → variable` | A assigns a value to B |
| `returns` | `function → type` | A has a return type of B |
| `raises` | `function → class` | A raises exception B |
| `decorates` | `decorator → function/class` | A is applied to B |
| `defines` | `file → symbol` | A contains the definition of B |
| `re_exports` | `module → symbol` | A makes B available under its own namespace |
| `passes` | `function → variable` | A passes variable B as an argument to another function |
| `tests` | `test → function/class` | A is a test that covers B |

---

### Confidence Scoring

Confidence scores reflect how certain Sinew is that a given edge represents a real relationship in the codebase at runtime.

| Score Range | Label | Meaning |
|---|---|---|
| `0.95 – 1.00` | `definite` | Static resolution confirmed. Direct call, explicit import. |
| `0.80 – 0.94` | `high` | Strong inference from type annotations or clear usage patterns. |
| `0.60 – 0.79` | `medium` | Inferred from context. Type is annotated but not guaranteed at runtime. |
| `0.40 – 0.59` | `low` | Dynamic dispatch detected. Target resolved by heuristic only. |
| `0.00 – 0.39` | `speculative` | Best-guess only. Multiple equally plausible targets. |

Edges below the `confidence_threshold` in `.sinewconfig` (default `0.75`) are excluded from the graph unless `--include-low-confidence` is passed.

---

## Origin Object

Every node carries an `origin` describing the true first-definition location of the symbol — not where it was imported, re-exported, or re-used, but where it was created.

```json
"origin": {
  "file": "auth/security.py",
  "line": 42,
  "is_same_as_definition": true,
  "re_exported_by": []
}
```

| Field | Type | Required | Description |
|---|---|---|---|
| `file` | `string` | ✅ | Relative path from repo root to the file of first definition |
| `line` | `integer` | ✅ | Line of first definition (1-indexed) |
| `is_same_as_definition` | `boolean` | ✅ | `true` if the node's `file` and `line` match the origin |
| `re_exported_by` | `string[]` | ❌ | List of file paths that re-export this symbol |

---

## sinew Annotation Object

The `sinew` field on a node holds all sinew Schema annotations parsed from inline `# @sinew:` comments in source code.

```json
"sinew": {
  "note": "core auth primitive — never inline, 17 callers depend on stable interface",
  "critical": true,
  "frozen": false,
  "frozen_reason": null,
  "frozen_since": null,
  "deprecated": false,
  "deprecated_reason": null,
  "deprecated_since": null,
  "group": "auth",
  "owner": "platform-team",
  "since": "2025-11-01",
  "ignore": false,
  "custom": {}
}
```

| Field | Type | Required | Description |
|---|---|---|---|
| `note` | `string` | ❌ | Human-readable note for graph consumers |
| `critical` | `boolean` | ❌ | If `true`, this node is included in all agent boot payloads regardless of task scope |
| `frozen` | `boolean` | ❌ | If `true`, modification of this node is blocked in agent outputs and flagged in constitution checks |
| `frozen_reason` | `string` | ❌ | Explanation of why this node is frozen |
| `frozen_since` | `string` | ❌ | ISO 8601 date when the node was frozen |
| `deprecated` | `boolean` | ❌ | If `true`, this symbol is marked as deprecated |
| `deprecated_reason` | `string` | ❌ | Reason for deprecation |
| `deprecated_since` | `string` | ❌ | ISO 8601 date when deprecation was applied |
| `group` | `string` | ❌ | Architectural group for cluster queries |
| `owner` | `string` | ❌ | Team or developer responsible for this symbol |
| `since` | `string` | ❌ | ISO 8601 date when this annotation was written |
| `ignore` | `boolean` | ❌ | If `true`, this node is excluded from the graph entirely |
| `custom` | `object` | ❌ | Arbitrary key-value pairs for project-specific extensions |

---

## Agent Warning Object

Agent warnings are persistent mistake memories attached to nodes. Once logged, they are included in every agent boot payload for any task touching this node — across all sessions, all agents, all time.

```json
"agent_warnings": [
  {
    "id": "warn_verify_password_001",
    "description": "Inlining this function breaks 17 callers. Always keep it as a standalone function.",
    "severity": "high",
    "logged_at": "2026-01-09T11:42:00Z",
    "logged_by": "human-review",
    "source_session": "auth-refactor-session-1",
    "resolved": false,
    "resolved_at": null
  }
]
```

| Field | Type | Required | Description |
|---|---|---|---|
| `id` | `string` | ✅ | Unique ID for this warning. Format: `warn_{node_name}_{sequence}` |
| `description` | `string` | ✅ | Clear, agent-readable explanation of the mistake to avoid |
| `severity` | `string` | ✅ | `low`, `medium`, `high`, `critical` |
| `logged_at` | `string` | ✅ | ISO 8601 UTC timestamp |
| `logged_by` | `string` | ✅ | `human-review`, `sinew-audit`, or an agent session ID |
| `source_session` | `string` | ❌ | Session ID of the agent session that produced the original mistake |
| `resolved` | `boolean` | ✅ | `true` if the underlying issue has been permanently fixed |
| `resolved_at` | `string` | ❌ | ISO 8601 UTC timestamp of resolution |

---

## Control Flow Object

Control flow blocks inside functions are tracked as structured objects on the parent node's `control_flow` array. This enables agents and tools to understand conditional logic and exception handling paths without parsing the source file.

```json
"control_flow": [
  {
    "type": "if",
    "line": 47,
    "condition_summary": "user.is_locked",
    "branches": ["raises AuthError"],
    "calls_in_block": []
  },
  {
    "type": "try",
    "line": 52,
    "branches": ["calls database.get_user"],
    "except_handlers": [
      {
        "exception_type": "DatabaseError",
        "line": 57,
        "action": "raises AuthError"
      }
    ]
  }
]
```

| Field | Type | Required | Description |
|---|---|---|---|
| `type` | `string` | ✅ | `if`, `elif`, `else`, `try`, `except`, `finally`, `for`, `while`, `switch`, `case`, `with` |
| `line` | `integer` | ✅ | Line number of the control flow statement |
| `condition_summary` | `string` | ❌ | Short human-readable summary of the condition |
| `branches` | `string[]` | ❌ | Summary of what each branch does |
| `calls_in_block` | `string[]` | ❌ | IDs of nodes called within this block |
| `except_handlers` | `ExceptHandler[]` | ❌ | For `try` blocks — list of except handlers |

---

## Indexes

Indexes are pre-computed lookup tables stored inside the graph JSON. They make common queries O(1) instead of requiring full graph traversal. Every index is derived entirely from the nodes and edges arrays and can be recomputed at any time.

### Reverse Index

Maps every node ID to everything that depends on it.

```json
"indexes": {
  "reverse": {
    "auth.security.verify_password": {
      "called_by": [
        "auth.login.login",
        "auth.admin.admin_login",
        "auth.reset.reset_flow"
      ],
      "imported_by": [
        "auth/login.py",
        "tests/test_auth.py"
      ],
      "instantiated_by": [],
      "read_by": [],
      "written_by": []
    }
  }
}
```

### Origin Index

Maps every symbol name to its origin location for fast `sinew origin` queries.

```json
"indexes": {
  "origin": {
    "verify_password": {
      "id": "auth.security.verify_password",
      "file": "auth/security.py",
      "line": 42
    },
    "db_conn": {
      "id": "config.database.db_conn",
      "file": "config/database.py",
      "line": 8
    }
  }
}
```

### File Index

Maps every file path to the IDs of all nodes defined in it.

```json
"indexes": {
  "files": {
    "auth/security.py": {
      "node_ids": [
        "auth.security",
        "auth.security.verify_password",
        "auth.security.hash_password",
        "auth.security.AuthError"
      ],
      "imports": ["database", "os", "hashlib"],
      "imported_by": ["auth/login.py", "auth/admin.py", "tests/test_auth.py"]
    }
  }
}
```

### Module Index

Maps every module to the symbols it exports and every file that imports it.

```json
"indexes": {
  "modules": {
    "database": {
      "exported_symbols": [
        "database.queries.get_user",
        "database.queries.create_record",
        "database.connection.db_conn"
      ],
      "imported_by": [
        {
          "file": "auth/security.py",
          "symbols_used": ["get_user", "db_conn"],
          "lines": [3, 4]
        },
        {
          "file": "auth/admin.py",
          "symbols_used": ["get_user"],
          "lines": [2]
        }
      ]
    }
  }
}
```

### Call Index

Maps every function to its full call chain — both forward (callees) and backward (callers) to the configured depth.

```json
"indexes": {
  "calls": {
    "auth.login.login": {
      "calls": [
        "auth.security.verify_password",
        "session.create.create_session"
      ],
      "called_by": [],
      "call_depth": 4,
      "full_chain": [
        "auth.login.login",
        "auth.security.verify_password",
        "database.queries.get_user",
        "cache.redis.fetch"
      ]
    }
  }
}
```

---

## Lists

Flat typed lists of every symbol in the repository. Used by `sinew list` commands and agent boot payloads.

```json
"lists": {
  "functions": [
    {
      "id": "auth.security.verify_password",
      "name": "verify_password",
      "file": "auth/security.py",
      "line": 42,
      "is_dead": false,
      "is_hotspot": true,
      "has_tests": true,
      "sinew_critical": true,
      "sinew_owner": "platform-team"
    }
  ],
  "classes": [ ... ],
  "variables": [ ... ],
  "modules": [ ... ],
  "interfaces": [ ... ],
  "entry_points": [ ... ],
  "dead_symbols": [ ... ],
  "phantom_imports": [ ... ],
  "frozen_symbols": [ ... ],
  "deprecated_symbols": [ ... ],
  "hotspots": [ ... ]
}
```

Each list item is a lightweight summary containing only the fields needed for display and filtering. Full node details are always available by looking up the node by `id` in the `nodes` array.

### DeadSymbol Item

```json
{
  "id": "auth.utils.old_hash",
  "type": "function",
  "file": "auth/utils.py",
  "line": 88,
  "caller_count": 0,
  "last_modified": "2025-08-14"
}
```

### PhantomImport Item

```json
{
  "file": "auth/login.py",
  "module": "logging",
  "imported_at_line": 4,
  "usage_count": 0
}
```

---

## Stats Object

Repository-level structural health metrics.

```json
"stats": {
  "files": {
    "total": 142,
    "by_language": {
      "python": 98,
      "typescript": 44
    }
  },
  "symbols": {
    "total_nodes": 2847,
    "functions": 1892,
    "classes": 204,
    "variables": 3410,
    "modules": 87,
    "interfaces": 12
  },
  "dead_code": {
    "dead_functions": 231,
    "dead_classes": 14,
    "dead_variables": 87,
    "phantom_imports": 43
  },
  "complexity": {
    "circular_dependencies": 3,
    "circular_dependency_chains": [
      ["auth.login", "session.create", "auth.login"],
      ["config.loader", "database.connection", "config.loader"]
    ],
    "max_call_depth": 12,
    "avg_incoming_edges": 2.4,
    "max_incoming_edges": 34,
    "max_outgoing_edges": 28
  },
  "hotspots": {
    "count": 7,
    "top": [
      { "id": "config.database.db_conn", "incoming_edge_count": 34 },
      { "id": "auth.security.verify_password", "incoming_edge_count": 17 }
    ]
  },
  "coverage": {
    "functions_with_tests": 812,
    "functions_without_tests": 1080,
    "coverage_percent": 42.9,
    "hotspots_without_tests": 3
  },
  "confidence": {
    "edges_above_0_95": 4821,
    "edges_0_80_to_0_95": 873,
    "edges_0_60_to_0_80": 241,
    "edges_below_0_60": 168
  },
  "sinew_schema": {
    "annotated_nodes": 147,
    "critical_nodes": 12,
    "frozen_nodes": 4,
    "deprecated_nodes": 23,
    "nodes_with_owner": 89
  },
  "structural_score": {
    "total": 68,
    "coupling": 71,
    "cohesion": 83,
    "circularity": 55,
    "testability": 72,
    "dead_code": 61,
    "documentation": 45,
    "previous_score": 72,
    "score_delta": -4,
    "scored_at": "2026-03-15T14:32:00Z"
  },
  "bus_factor": {
    "single_owner_nodes": 14,
    "riskiest_developer": "raj",
    "by_cluster": [
      { "cluster": "auth", "bus_factor": 1, "sole_owner": "raj" },
      { "cluster": "payments", "bus_factor": 4 }
    ]
  }
}
```

---

## Constitution Results Object

Results of architecture constitution validation. Present only if a `.sinewconstitution` file exists and `enforce_on_build` is `true`.

```json
"constitution_results": {
  "evaluated_at": "2026-03-15T14:32:00Z",
  "constitution_file": ".sinewconstitution",
  "total_rules": 6,
  "violations": [
    {
      "rule_name": "no-auth-to-db-direct",
      "severity": "error",
      "description": "Auth layer must not call database layer directly.",
      "violation": "auth.login.login calls database.queries.get_user directly",
      "edge_id": "auth.login.login__calls__database.queries.get_user",
      "file": "auth/login.py",
      "line": 34,
      "suggestion": "Route through service layer: auth.login.login → services.auth.AuthService.login → database"
    },
    {
      "rule_name": "no-circular-deps",
      "severity": "error",
      "description": "No circular dependencies anywhere.",
      "violation": "Circular dependency: auth.login → session.create → auth.login",
      "chain": ["auth.login.login", "session.create.create_session", "auth.login.login"],
      "file": "session/create.py",
      "line": 19,
      "suggestion": "Extract shared state into a third module that neither auth nor session imports."
    }
  ],
  "warnings": [
    {
      "rule_name": "services-must-be-tested",
      "severity": "warning",
      "description": "Every public function in services/ must have at least one test.",
      "violation": "services/reset.py — reset_password has no tests",
      "file": "services/reset.py",
      "line": 12
    }
  ],
  "passed_rules": ["no-god-files", "no-low-confidence-in-core", "hotspot-functions-must-be-tested"],
  "error_count": 2,
  "warning_count": 1
}
```

---

## Session State Object

Agent session continuity snapshots. Each snapshot records what an agent learned and decided during a session so future sessions can resume with full context.

```json
"session_state": [
  {
    "session_id": "auth-refactor-session-1",
    "task": "Refactor auth module — separate verify_password from login, add mfa_token support",
    "status": "partial",
    "created_at": "2026-03-14T09:00:00Z",
    "last_updated": "2026-03-14T11:30:00Z",
    "agent_id": "claude-sonnet-4-6",
    "completed_steps": [
      "Extracted verify_password into standalone function in auth/security.py",
      "Updated all 17 callers to use new standalone function",
      "Added mfa_token parameter to verify_password signature"
    ],
    "remaining_steps": [
      "Propagate mfa_token through session.py — not touched yet",
      "Update tests for new verify_password signature"
    ],
    "dead_ends": [
      "Tried using auth middleware for mfa validation — creates circular dep with auth cluster. Abandoned."
    ],
    "decisions": [
      "mfa_token is optional (default None) to maintain backward compatibility with 13 untested callers",
      "AuthError is raised, not returned, to match existing error handling pattern"
    ],
    "nodes_modified": [
      "auth.security.verify_password",
      "auth.login.login",
      "auth.admin.admin_login"
    ],
    "nodes_read": [
      "session.create.create_session",
      "models.user.User"
    ],
    "territory_scope": "auth/",
    "territory_released": false
  }
]
```

| Field | Type | Required | Description |
|---|---|---|---|
| `session_id` | `string` | ✅ | Unique session identifier |
| `task` | `string` | ✅ | Original task description |
| `status` | `string` | ✅ | `complete`, `partial`, `abandoned` |
| `created_at` | `string` | ✅ | ISO 8601 UTC session start time |
| `last_updated` | `string` | ✅ | ISO 8601 UTC last update time |
| `agent_id` | `string` | ❌ | Model or agent tool that ran this session |
| `completed_steps` | `string[]` | ✅ | What the agent finished |
| `remaining_steps` | `string[]` | ✅ | What still needs to be done |
| `dead_ends` | `string[]` | ❌ | Approaches tried and abandoned, with reasons |
| `decisions` | `string[]` | ❌ | Architectural decisions the agent made and why |
| `nodes_modified` | `string[]` | ✅ | IDs of nodes the agent changed |
| `nodes_read` | `string[]` | ❌ | IDs of nodes the agent read for context |
| `territory_scope` | `string` | ❌ | File/folder scope this session claimed |
| `territory_released` | `boolean` | ✅ | `true` if territory was released on completion |

---

## Full Example

A minimal but complete `sinew.json` demonstrating every top-level section.

```json
{
  "sinew_version": "1.0",

  "meta": {
    "repo_name": "my-project",
    "repo_root": "/home/raj/projects/my-project",
    "repo_root_relative": "./",
    "built_at": "2026-03-15T14:32:00Z",
    "build_duration_ms": 4821,
    "sinew_version": "1.0",
    "languages_detected": ["python"],
    "files_scanned": 2,
    "files_ignored": 3,
    "total_nodes": 4,
    "total_edges": 3,
    "confidence_threshold": 0.75,
    "entry_points": ["auth.login.login"],
    "git": {
      "branch": "main",
      "commit": "a3f92c1",
      "dirty": false
    }
  },

  "nodes": [
    {
      "id": "auth.login",
      "type": "file",
      "name": "login.py",
      "qualified_name": "auth.login",
      "language": "python",
      "file": "auth/login.py",
      "line": 1,
      "line_end": 38,
      "origin": { "file": "auth/login.py", "line": 1, "is_same_as_definition": true, "re_exported_by": [] },
      "parent": null,
      "children": ["auth.login.login"],
      "is_entry_point": false,
      "is_hotspot": false,
      "caller_count": 0,
      "callee_count": 1,
      "outgoing_edge_count": 1,
      "incoming_edge_count": 0,
      "has_tests": true,
      "confidence_min": 0.97,
      "import_count": 2,
      "export_count": 1
    },
    {
      "id": "auth.login.login",
      "type": "function",
      "name": "login",
      "qualified_name": "auth.login.login",
      "language": "python",
      "file": "auth/login.py",
      "line": 12,
      "line_end": 28,
      "origin": { "file": "auth/login.py", "line": 12, "is_same_as_definition": true, "re_exported_by": [] },
      "parent": "auth.login",
      "visibility": "public",
      "is_entry_point": true,
      "is_hotspot": false,
      "caller_count": 0,
      "callee_count": 1,
      "outgoing_edge_count": 1,
      "incoming_edge_count": 0,
      "has_tests": true,
      "test_ids": ["tests.test_auth.test_valid_login"],
      "confidence_min": 0.97,
      "notes": "Authenticates a user and creates a session. Raises AuthError on failure.",
      "parameters": [
        { "name": "user", "type_annotation": "str", "position": 0 },
        { "name": "password", "type_annotation": "str", "position": 1 }
      ],
      "return_type": "Session",
      "is_async": false,
      "raises": ["AuthError"],
      "control_flow": [
        {
          "type": "try",
          "line": 17,
          "branches": ["calls verify_password"],
          "except_handlers": [
            { "exception_type": "AuthError", "line": 22, "action": "raises AuthError" }
          ]
        }
      ],
      "sinew": {
        "note": "primary login entry point",
        "critical": true,
        "frozen": false,
        "group": "auth",
        "owner": "platform-team"
      },
      "agent_warnings": []
    },
    {
      "id": "auth.security.verify_password",
      "type": "function",
      "name": "verify_password",
      "qualified_name": "auth.security.verify_password",
      "language": "python",
      "file": "auth/security.py",
      "line": 42,
      "line_end": 61,
      "origin": { "file": "auth/security.py", "line": 42, "is_same_as_definition": true, "re_exported_by": [] },
      "parent": "auth.security",
      "visibility": "public",
      "is_entry_point": false,
      "is_hotspot": true,
      "caller_count": 17,
      "callee_count": 2,
      "outgoing_edge_count": 2,
      "incoming_edge_count": 17,
      "has_tests": true,
      "test_ids": ["tests.test_auth.test_valid_login", "tests.test_auth.test_locked_account"],
      "confidence_min": 0.91,
      "notes": "Verifies a password against stored hash. Raises AuthError if invalid.",
      "parameters": [
        { "name": "user", "type_annotation": "User", "position": 0 },
        { "name": "password", "type_annotation": "str", "position": 1 }
      ],
      "return_type": "bool",
      "is_async": false,
      "raises": ["AuthError"],
      "sinew": {
        "note": "core auth primitive — never inline, 17 callers depend on stable interface",
        "critical": true,
        "frozen": false,
        "group": "auth",
        "owner": "platform-team"
      },
      "agent_warnings": [
        {
          "id": "warn_verify_password_001",
          "description": "Inlining this function breaks 17 callers. Always keep it as a standalone function.",
          "severity": "high",
          "logged_at": "2026-01-09T11:42:00Z",
          "logged_by": "human-review",
          "resolved": false
        }
      ]
    }
  ],

  "edges": [
    {
      "id": "auth.login.login__calls__auth.security.verify_password",
      "from": "auth.login.login",
      "to": "auth.security.verify_password",
      "type": "calls",
      "file": "auth/login.py",
      "line": 17,
      "confidence": 0.97,
      "is_inferred": false,
      "is_dynamic": false
    }
  ],

  "indexes": {
    "reverse": {
      "auth.security.verify_password": {
        "called_by": ["auth.login.login"],
        "imported_by": ["auth/login.py"],
        "instantiated_by": [],
        "read_by": [],
        "written_by": []
      }
    },
    "origin": {
      "verify_password": {
        "id": "auth.security.verify_password",
        "file": "auth/security.py",
        "line": 42
      }
    },
    "files": {
      "auth/login.py": {
        "node_ids": ["auth.login", "auth.login.login"],
        "imports": ["auth.security"],
        "imported_by": []
      }
    },
    "modules": {},
    "calls": {
      "auth.login.login": {
        "calls": ["auth.security.verify_password"],
        "called_by": [],
        "call_depth": 2,
        "full_chain": ["auth.login.login", "auth.security.verify_password"]
      }
    }
  },

  "lists": {
    "functions": [
      {
        "id": "auth.login.login",
        "name": "login",
        "file": "auth/login.py",
        "line": 12,
        "is_dead": false,
        "is_hotspot": false,
        "has_tests": true,
        "sinew_critical": true,
        "sinew_owner": "platform-team"
      },
      {
        "id": "auth.security.verify_password",
        "name": "verify_password",
        "file": "auth/security.py",
        "line": 42,
        "is_dead": false,
        "is_hotspot": true,
        "has_tests": true,
        "sinew_critical": true,
        "sinew_owner": "platform-team"
      }
    ],
    "classes": [],
    "variables": [],
    "modules": [],
    "dead_symbols": [],
    "phantom_imports": [],
    "frozen_symbols": [],
    "hotspots": [
      { "id": "auth.security.verify_password", "incoming_edge_count": 17 }
    ]
  },

  "stats": {
    "files": { "total": 2, "by_language": { "python": 2 } },
    "symbols": { "total_nodes": 4, "functions": 2, "classes": 0, "variables": 0, "modules": 0 },
    "dead_code": { "dead_functions": 0, "dead_classes": 0, "dead_variables": 0, "phantom_imports": 0 },
    "complexity": { "circular_dependencies": 0, "circular_dependency_chains": [], "max_call_depth": 2 },
    "hotspots": { "count": 1, "top": [{ "id": "auth.security.verify_password", "incoming_edge_count": 17 }] },
    "structural_score": { "total": 84, "coupling": 90, "cohesion": 85, "circularity": 100, "testability": 80, "dead_code": 100, "documentation": 60 }
  }
}
```

---

## Field Reference

### Required vs Optional Summary

| Section | Required Fields | Optional Fields |
|---|---|---|
| Root | `sinew_version`, `meta`, `nodes`, `edges`, `indexes`, `lists`, `stats` | `constitution_results`, `session_state` |
| Meta | `repo_name`, `repo_root`, `built_at`, `languages_detected`, `total_nodes`, `total_edges`, `confidence_threshold` | `git`, `entry_points`, `config_file` |
| Node | `id`, `type`, `name`, `qualified_name`, `language`, `file`, `line`, `origin`, `is_entry_point`, `is_hotspot`, `caller_count`, `callee_count`, `has_tests`, `confidence_min` | `parent`, `notes`, `sinew`, `agent_warnings`, `control_flow`, type-specific fields |
| Edge | `id`, `from`, `to`, `type`, `file`, `line`, `confidence`, `is_inferred`, `is_dynamic` | `via` |
| Origin | `file`, `line`, `is_same_as_definition` | `re_exported_by` |
| sinewAnnotation | (all optional — object is omitted entirely if no annotations present) | all fields |
| AgentWarning | `id`, `description`, `severity`, `logged_at`, `logged_by`, `resolved` | `source_session`, `resolved_at` |

### ID Format Rules

- IDs use dot notation: `package.module.ClassName.method_name`
- File IDs use the file path with `/` replaced by `.` and extension removed: `auth/security.py` → `auth.security`
- External module IDs use only the module name: `os`, `express`, `lodash`
- No spaces, hyphens, or special characters in IDs
- IDs are case-sensitive and must match the source symbol's casing exactly
- Test node IDs are prefixed with their test directory: `tests.test_auth.test_valid_login`

### Confidence Score Rules

- All edge `confidence` values must be floats in range `[0.0, 1.0]`
- Edges below `confidence_threshold` in config are excluded unless `--include-low-confidence` is passed
- `confidence_min` on a node must equal the lowest `confidence` among all outgoing edges from that node
- Edges with `is_dynamic: true` must have `confidence < 0.80`
- Edges with `is_inferred: false` should have `confidence >= 0.90`

---

## Versioning and Compatibility

Sinew schema versioning follows **semantic versioning** with two components: `MAJOR.MINOR`.

| Change Type | Version Bump | Description |
|---|---|---|
| New optional field added | `MINOR` | Fully backward compatible. Consumers must ignore unknown fields. |
| New required field added | `MAJOR` | Breaking change. All producers and consumers must be updated. |
| Field renamed or removed | `MAJOR` | Breaking change. |
| New node type added | `MINOR` | Consumers that don't handle the new type should treat it as `unknown`. |
| New edge type added | `MINOR` | Consumers that don't handle the new type should ignore the edge. |
| Index structure changed | `MAJOR` | Breaking change. |

### Consumer Compatibility Rules

1. Every consumer must check `sinew_version` before processing.
2. Consumers must silently ignore any field they do not recognize.
3. Consumers must not fail on unknown `node.type` values — treat them as `"unknown"`.
4. Consumers must not fail on unknown `edge.type` values — skip the edge.
5. Consumers must treat any missing optional field as `null` or an empty collection as appropriate.
6. Consumers must not assume any ordering of nodes or edges in their respective arrays.

### Current Version: `1.0`

This document describes schema version `1.0`. All `sinew.json` files produced by Sinew `1.x` will carry `"sinew_version": "1.0"` and conform to this specification.