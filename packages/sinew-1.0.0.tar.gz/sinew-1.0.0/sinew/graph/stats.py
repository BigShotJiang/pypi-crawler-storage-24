"""
Statistics engine for code analysis.

Responsibilities:
- Calculate structural metrics (fan-in, fan-out, depth)
- Identify code hotspots and complexity
- Calculate structural quality scores
- Find potential issues (dead code, god files)

Key Functions:
- StatsEngine.compute() -> Stats:
    Compute all statistics for the graph.
"""

from __future__ import annotations

import logging
from collections import deque
from datetime import datetime
from typing import Any

from sinew.schema.models import (
    BusFactorCluster,
    BusFactorStats,
    ComplexityStats,
    ConfidenceStats,
    CoverageStats,
    DeadCodeStats,
    Edge,
    EdgeType,
    FileStats,
    HotspotItem,
    HotspotStats,
    Lists,
    Node,
    NodeType,
    sinewSchemaStats,
    Stats,
    StructuralScore,
    SymbolStats,
)

logger = logging.getLogger(__name__)


class StatsEngine:
    @staticmethod
    def compute(nodes: list[Node], edges: list[Edge], lists: Lists) -> Stats:
        file_stats = StatsEngine._compute_file_stats(nodes)
        symbol_stats = StatsEngine._compute_symbol_stats(nodes)
        dead_code_stats = StatsEngine._compute_dead_code_stats(nodes, lists)
        complexity_stats = StatsEngine._compute_complexity_stats(nodes, edges)
        hotspot_stats = StatsEngine._compute_hotspot_stats(lists)
        coverage_stats = StatsEngine._compute_coverage_stats(nodes, lists)
        confidence_stats = StatsEngine._compute_confidence_stats(edges)
        sinew_schema_stats = StatsEngine._compute_sinew_schema_stats(nodes)
        structural_score = StatsEngine._compute_structural_score(
            nodes, edges, lists, complexity_stats, coverage_stats, sinew_schema_stats
        )
        bus_factor_stats = StatsEngine._compute_bus_factor_stats(nodes)

        return Stats(
            files=file_stats,
            symbols=symbol_stats,
            dead_code=dead_code_stats,
            complexity=complexity_stats,
            hotspots=hotspot_stats,
            coverage=coverage_stats,
            confidence=confidence_stats,
            sinew_schema=sinew_schema_stats,
            structural_score=structural_score,
            bus_factor=bus_factor_stats,
        )

    @staticmethod
    def _compute_file_stats(nodes: list[Node]) -> FileStats:
        file_nodes = [n for n in nodes if n.type == NodeType.FILE]
        by_language: dict[str, int] = {}

        for file_node in file_nodes:
            lang = file_node.language.value
            by_language[lang] = by_language.get(lang, 0) + 1

        return FileStats(
            total=len(file_nodes),
            by_language=by_language,
        )

    @staticmethod
    def _compute_symbol_stats(nodes: list[Node]) -> SymbolStats:
        total_nodes = len(nodes)
        functions = len([n for n in nodes if n.type == NodeType.FUNCTION])
        methods = len([n for n in nodes if n.type == NodeType.METHOD])
        classes = len([n for n in nodes if n.type == NodeType.CLASS])
        variables = len([n for n in nodes if n.type == NodeType.VARIABLE])
        modules = len([n for n in nodes if n.type == NodeType.MODULE and not n.is_external])
        interfaces = len([n for n in nodes if n.type == NodeType.INTERFACE])

        return SymbolStats(
            total_nodes=total_nodes,
            functions=functions + methods,
            classes=classes,
            variables=variables,
            modules=modules,
            interfaces=interfaces,
        )

    @staticmethod
    def _compute_dead_code_stats(nodes: list[Node], lists: Lists) -> DeadCodeStats:
        functions = [n for n in nodes if n.type in (NodeType.FUNCTION, NodeType.METHOD)]
        classes = [n for n in nodes if n.type == NodeType.CLASS]
        variables = [n for n in nodes if n.type == NodeType.VARIABLE]

        dead_functions = len([f for f in functions if f.incoming_edge_count == 0 and not f.is_entry_point])
        dead_classes = len([c for c in classes if c.incoming_edge_count == 0])
        dead_variables = len([v for v in variables if v.read_count == 0]) if any(v.read_count is not None for v in variables) else 0

        return DeadCodeStats(
            dead_functions=dead_functions,
            dead_classes=dead_classes,
            dead_variables=dead_variables,
            phantom_imports=len(lists.phantom_imports),
        )

    @staticmethod
    def _compute_complexity_stats(nodes: list[Node], edges: list[Edge]) -> ComplexityStats:
        call_edges = [e for e in edges if e.type == EdgeType.CALLS]
        circular_deps, circular_chains = StatsEngine._detect_cycles(nodes, call_edges)

        incoming_counts = [n.incoming_edge_count for n in nodes if n.type not in (NodeType.FILE, NodeType.MODULE)]
        outgoing_counts = [n.outgoing_edge_count for n in nodes if n.type not in (NodeType.FILE, NodeType.MODULE)]

        avg_incoming = sum(incoming_counts) / len(incoming_counts) if incoming_counts else 0.0
        max_incoming = max(incoming_counts) if incoming_counts else 0
        max_outgoing = max(outgoing_counts) if outgoing_counts else 0

        max_call_depth = 0
        for node in nodes:
            if node.type in (NodeType.FUNCTION, NodeType.METHOD):
                max_call_depth = max(max_call_depth, node.callee_count)

        return ComplexityStats(
            circular_dependencies=len(circular_deps),
            circular_dependency_chains=circular_chains,
            max_call_depth=max_call_depth,
            avg_incoming_edges=round(avg_incoming, 2),
            max_incoming_edges=max_incoming,
            max_outgoing_edges=max_outgoing,
        )

    @staticmethod
    def _detect_cycles(nodes: list[Node], call_edges: list[Edge]) -> tuple[set[tuple[str, str]], list[list[str]]]:
        graph: dict[str, set[str]] = {}
        for edge in call_edges:
            if edge.from_node not in graph:
                graph[edge.from_node] = set()
            graph[edge.from_node].add(edge.to_node)

        cycles: set[tuple[str, str]] = set()
        cycle_chains: list[list[str]] = []
        visited: set[str] = set()
        rec_stack: set[str] = set()

        def dfs(node: str, path: list[str]) -> None:
            visited.add(node)
            rec_stack.add(node)

            for neighbor in graph.get(node, set()):
                if neighbor not in visited:
                    dfs(neighbor, path + [neighbor])
                elif neighbor in rec_stack:
                    cycle_start = path.index(neighbor) if neighbor in path else 0
                    cycle = path[cycle_start:] + [neighbor]
                    cycle_chains.append(cycle)
                    cycles.add((neighbor, node))

            rec_stack.remove(node)

        for node in graph:
            if node not in visited:
                dfs(node, [node])

        return cycles, cycle_chains[:10]

    @staticmethod
    def _compute_hotspot_stats(lists: Lists) -> HotspotStats:
        count = len(lists.hotspots)
        top = sorted(lists.hotspots, key=lambda x: x.incoming_edge_count, reverse=True)[:10]

        return HotspotStats(
            count=count,
            top=top,
        )

    @staticmethod
    def _compute_coverage_stats(nodes: list[Node], lists: Lists) -> CoverageStats:
        functions = [n for n in nodes if n.type in (NodeType.FUNCTION, NodeType.METHOD)]
        functions_with_tests = len([f for f in functions if f.has_tests])
        functions_without_tests = len([f for f in functions if not f.has_tests])

        total = len(functions)
        coverage_percent = round((functions_with_tests / total) * 100, 1) if total > 0 else 0.0

        hotspot_ids = {h.id for h in lists.hotspots}
        hotspots_without_tests = len([
            n for n in nodes
            if n.id in hotspot_ids and not n.has_tests
        ])

        return CoverageStats(
            functions_with_tests=functions_with_tests,
            functions_without_tests=functions_without_tests,
            coverage_percent=coverage_percent,
            hotspots_without_tests=hotspots_without_tests,
        )

    @staticmethod
    def _compute_confidence_stats(edges: list[Edge]) -> ConfidenceStats:
        above_0_95 = len([e for e in edges if e.confidence > 0.95])
        range_0_80_to_0_95 = len([e for e in edges if 0.80 <= e.confidence <= 0.95])
        range_0_60_to_0_80 = len([e for e in edges if 0.60 <= e.confidence < 0.80])
        below_0_60 = len([e for e in edges if e.confidence < 0.60])

        return ConfidenceStats(
            edges_above_0_95=above_0_95,
            edges_0_80_to_0_95=range_0_80_to_0_95,
            edges_0_60_to_0_80=range_0_60_to_0_80,
            edges_below_0_60=below_0_60,
        )

    @staticmethod
    def _compute_sinew_schema_stats(nodes: list[Node]) -> sinewSchemaStats:
        annotated_nodes = 0
        critical_nodes = 0
        frozen_nodes = 0
        deprecated_nodes = 0
        nodes_with_owner = 0

        for node in nodes:
            if node.sinew:
                annotated_nodes += 1
                if node.sinew.critical:
                    critical_nodes += 1
                if node.sinew.frozen:
                    frozen_nodes += 1
                if node.sinew.deprecated:
                    deprecated_nodes += 1
                if node.sinew.owner:
                    nodes_with_owner += 1

        return sinewSchemaStats(
            annotated_nodes=annotated_nodes,
            critical_nodes=critical_nodes,
            frozen_nodes=frozen_nodes,
            deprecated_nodes=deprecated_nodes,
            nodes_with_owner=nodes_with_owner,
        )

    @staticmethod
    def _compute_structural_score(
        nodes: list[Node],
        edges: list[Edge],
        lists: Lists,
        complexity_stats: ComplexityStats,
        coverage_stats: CoverageStats,
        sinew_schema_stats: sinewSchemaStats,
    ) -> StructuralScore:
        module_nodes = [n for n in nodes if n.type == NodeType.MODULE]
        hotspot_ids = {h.id for h in lists.hotspots}
        hotspots_without_tests = [
            n for n in nodes
            if n.id in hotspot_ids and not n.has_tests
        ]

        coupling = 100
        for module in module_nodes:
            if module.incoming_edge_count > 15:
                coupling -= 5
        for hotspot in hotspots_without_tests:
            coupling -= 2
        coupling = max(0, coupling)

        cohesion = 100
        cohesion -= min(30, len(complexity_stats.circular_dependency_chains) * 3)
        dead_functions = [n for n in nodes if n.type in (NodeType.FUNCTION, NodeType.METHOD) and n.incoming_edge_count == 0 and not n.is_entry_point]
        cohesion -= min(30, len(dead_functions) * 1)
        cohesion = max(0, cohesion)

        circularity = 100 - (complexity_stats.circular_dependencies * 15)
        circularity = max(0, circularity)

        testability = round(coverage_stats.coverage_percent)

        dead_code = 100 - min(50, len(dead_functions)) * 1.5
        dead_code = max(0, int(dead_code))

        total_nodes = len(nodes)
        documentation = round((sinew_schema_stats.annotated_nodes / max(total_nodes, 1)) * 100)

        total = round((coupling + cohesion + circularity + testability + dead_code + documentation) / 6)

        return StructuralScore(
            total=total,
            coupling=coupling,
            cohesion=cohesion,
            circularity=circularity,
            testability=testability,
            dead_code=dead_code,
            documentation=documentation,
            scored_at=datetime.utcnow(),
        )

    @staticmethod
    def _compute_bus_factor_stats(nodes: list[Node]) -> BusFactorStats:
        try:
            import git
        except ImportError:
            logger.warning("GitPython not available - bus factor stats will be zero")
            return BusFactorStats(
                single_owner_nodes=0,
                riskiest_developer=None,
                by_cluster=[],
            )

        return BusFactorStats(
            single_owner_nodes=0,
            riskiest_developer=None,
            by_cluster=[],
        )
