"""
Index building for fast graph traversal.

Responsibilities:
- Build reverse lookup indexes
- Build call graph indexes
- Build directory/file-based indexes
- Support symbol lookup by various criteria

Key Functions:
- IndexBuilder.build() -> Indexes:
    Build all five index types from nodes and edges.
"""

from __future__ import annotations

from collections import deque
from typing import Any

from sinew.schema.models import (
    CallIndexEntry,
    Edge,
    EdgeType,
    FileImportUsage,
    FileIndexEntry,
    Indexes,
    ModuleIndexEntry,
    Node,
    NodeType,
    OriginIndexEntry,
    ReverseIndexEntry,
)


class IndexBuilder:
    @staticmethod
    def build(nodes: list[Node], edges: list[Edge]) -> Indexes:
        reverse_index = IndexBuilder._build_reverse_index(nodes, edges)
        origin_index = IndexBuilder._build_origin_index(nodes)
        file_index = IndexBuilder._build_file_index(nodes, edges)
        module_index = IndexBuilder._build_module_index(nodes, edges)
        call_index = IndexBuilder._build_call_index(nodes, edges)

        return Indexes(
            reverse=reverse_index,
            origin=origin_index,
            files=file_index,
            modules=module_index,
            calls=call_index,
        )

    @staticmethod
    def _build_reverse_index(nodes: list[Node], edges: list[Edge]) -> dict[str, ReverseIndexEntry]:
        reverse: dict[str, ReverseIndexEntry] = {}
        node_ids = {n.id for n in nodes}

        for node in nodes:
            reverse[node.id] = ReverseIndexEntry()

        for edge in edges:
            if edge.to_node not in reverse:
                reverse[edge.to_node] = ReverseIndexEntry()

            if edge.type == EdgeType.CALLS:
                if edge.to_node in reverse:
                    if edge.from_node not in reverse[edge.to_node].called_by:
                        reverse[edge.to_node].called_by.append(edge.from_node)
            elif edge.type == EdgeType.IMPORTS:
                if edge.to_node in reverse:
                    if edge.file not in reverse[edge.to_node].imported_by:
                        reverse[edge.to_node].imported_by.append(edge.file)
            elif edge.type == EdgeType.INSTANTIATES:
                if edge.to_node in reverse:
                    if edge.from_node not in reverse[edge.to_node].instantiated_by:
                        reverse[edge.to_node].instantiated_by.append(edge.from_node)
            elif edge.type == EdgeType.READS:
                if edge.to_node in reverse:
                    if edge.from_node not in reverse[edge.to_node].read_by:
                        reverse[edge.to_node].read_by.append(edge.from_node)
            elif edge.type == EdgeType.WRITES:
                if edge.to_node in reverse:
                    if edge.from_node not in reverse[edge.to_node].written_by:
                        reverse[edge.to_node].written_by.append(edge.from_node)

        return reverse

    @staticmethod
    def _build_origin_index(nodes: list[Node]) -> dict[str, OriginIndexEntry]:
        origin: dict[str, OriginIndexEntry] = {}
        name_to_nodes: dict[str, list[Node]] = {}

        for node in nodes:
            if node.name not in name_to_nodes:
                name_to_nodes[node.name] = []
            name_to_nodes[node.name].append(node)

        for name, node_list in name_to_nodes.items():
            if len(node_list) > 1:
                lowest_line_node = min(node_list, key=lambda n: n.line)
                import logging
                logger = logging.getLogger(__name__)
                logger.warning(f"Origin index conflict for name '{name}' - using lowest line number")
                origin[name] = OriginIndexEntry(
                    id=lowest_line_node.id,
                    file=lowest_line_node.file,
                    line=lowest_line_node.line,
                )
            else:
                node = node_list[0]
                origin[name] = OriginIndexEntry(
                    id=node.id,
                    file=node.file,
                    line=node.line,
                )

        return origin

    @staticmethod
    def _build_file_index(nodes: list[Node], edges: list[Edge]) -> dict[str, FileIndexEntry]:
        files: dict[str, FileIndexEntry] = {}
        node_map = {n.id: n for n in nodes}
        file_nodes = [n for n in nodes if n.type == NodeType.FILE]

        for file_node in file_nodes:
            file_path = file_node.file
            node_ids = [n.id for n in nodes if n.file == file_path]
            imports = []
            imported_by = []

            for edge in edges:
                if edge.type == EdgeType.IMPORTS:
                    if edge.from_node == file_node.id:
                        imports.append(edge.to_node)
                    if edge.to_node == file_node.id or edge.to_node == file_node.name:
                        if edge.file not in imported_by:
                            imported_by.append(edge.file)

            files[file_path] = FileIndexEntry(
                node_ids=node_ids,
                imports=imports,
                imported_by=imported_by,
            )

        return files

    @staticmethod
    def _build_module_index(nodes: list[Node], edges: list[Edge]) -> dict[str, ModuleIndexEntry]:
        modules: dict[str, ModuleIndexEntry] = {}
        module_nodes = [n for n in nodes if n.type == NodeType.MODULE]

        for module_node in module_nodes:
            exported_symbols = []
            imported_by = []

            for node in nodes:
                if node.file and module_node.id in node.file:
                    exported_symbols.append(node.id)

            for edge in edges:
                if edge.type == EdgeType.IMPORTS and edge.to_node == module_node.id:
                    file_path = edge.file
                    symbols_used = []
                    for e in edges:
                        if e.type == EdgeType.IMPORTS and e.from_node == edge.from_node:
                            symbols_used.append(e.to_node)
                    imported_by.append(FileImportUsage(
                        file=file_path,
                        symbols_used=symbols_used,
                        lines=[edge.line],
                    ))

            modules[module_node.id] = ModuleIndexEntry(
                exported_symbols=exported_symbols,
                imported_by=imported_by,
            )

        return modules

    @staticmethod
    def _build_call_index(nodes: list[Node], edges: list[Edge]) -> dict[str, CallIndexEntry]:
        calls: dict[str, CallIndexEntry] = {}
        node_map = {n.id: n for n in nodes}
        call_edges = [e for e in edges if e.type == EdgeType.CALLS]

        function_nodes = [n for n in nodes if n.type in (NodeType.FUNCTION, NodeType.METHOD)]

        for func_node in function_nodes:
            direct_calls = []
            direct_callers = []

            for edge in call_edges:
                if edge.from_node == func_node.id:
                    direct_calls.append(edge.to_node)
                if edge.to_node == func_node.id:
                    direct_callers.append(edge.from_node)

            call_depth = IndexBuilder._compute_call_depth(func_node.id, call_edges, node_map)
            full_chain = IndexBuilder._compute_full_chain(func_node.id, call_edges, node_map)

            calls[func_node.id] = CallIndexEntry(
                calls=direct_calls,
                called_by=direct_callers,
                call_depth=call_depth,
                full_chain=full_chain,
            )

        return calls

    @staticmethod
    def _compute_call_depth(start_node_id: str, call_edges: list[Edge], node_map: dict[str, Node]) -> int:
        max_depth = 0
        visited = set()
        queue = deque([(start_node_id, 0)])
        visited.add(start_node_id)

        while queue:
            current_id, depth = queue.popleft()
            max_depth = max(max_depth, depth)

            if depth >= 20:
                continue

            for edge in call_edges:
                if edge.from_node == current_id:
                    if edge.to_node not in visited:
                        visited.add(edge.to_node)
                        queue.append((edge.to_node, depth + 1))

        return max_depth

    @staticmethod
    def _compute_full_chain(start_node_id: str, call_edges: list[Edge], node_map: dict[str, Node]) -> list[str]:
        full_chain = []
        visited = set()
        queue = deque([start_node_id])
        visited.add(start_node_id)

        while queue and len(full_chain) < 100:
            current_id = queue.popleft()
            full_chain.append(current_id)

            if len(full_chain) >= 100:
                break

            for edge in call_edges:
                if edge.from_node == current_id:
                    if edge.to_node not in visited:
                        visited.add(edge.to_node)
                        queue.append(edge.to_node)

        return full_chain
