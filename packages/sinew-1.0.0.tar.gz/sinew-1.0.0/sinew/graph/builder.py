"""
Graph construction and merging.

Responsibilities:
- Combine ParsedFile results into a single sinewGraph
- Resolve cross-file references and dependencies
- Deduplicate nodes and edges
- Build indexes and compute statistics

Key Functions:
- GraphBuilder.build() -> sinewGraph:
    Main entry point that assembles the complete graph.
"""

from __future__ import annotations

import logging
import time
from datetime import datetime
from pathlib import Path
from typing import Any

from sinew.parsers.base import ParsedFile
from sinew.core.config import sinewConfig
from sinew.schema.models import (
    Edge,
    EdgeType,
    FileImportUsage,
    FileIndexEntry,
    GitMeta,
    HotspotItem,
    Indexes,
    Language,
    Lists as ListsModel,
    Meta,
    ModuleIndexEntry,
    Node,
    NodeType,
    Origin,
    OriginIndexEntry,
    ReverseIndexEntry,
    sinewGraph,
    Stats,
    CallIndexEntry,
)
from sinew.graph.indexer import IndexBuilder
from sinew.graph.stats import StatsEngine

logger = logging.getLogger(__name__)

STDLIB_MODULES: set[str] = {
    "os", "sys", "re", "json", "typing", "collections", "itertools",
    "functools", "operator", "string", "datetime", "time", "calendar",
    "io", "pickle", "copy", "pprint", "math", "random", "hashlib",
    "base64", "binascii", "struct", "codecs", "unicodedata", "locale",
    "gettext", "warnings", "dataclasses", "abc", "contextlib",
    "ast", "dis", "inspect", "traceback", "gc", "weakref",
    "types", "copyreg", "linecache", "tokenize", "keyword",
    "statistics", "decimal", "fractions", "numbers", "cmath",
    "array", "bisect", "graphlib", "heapq", "queue", "threading",
    "multiprocessing", "concurrent", "asyncio", "subprocess", "socket",
    "ssl", "select", "selectors", "signal", "mmap", "email",
    "mailbox", "smtplib", "ftplib", "http", "urllib", "html",
    "xml", "csv", "configparser", "toml", "logging", "logging.config",
    "hmac", "secrets", "textwrap", "stringprep",
}

GraphBuilderError = type("GraphBuilderError", (Exception,), {})


class GraphBuilder:
    def build(
        self,
        parsed_files: list[ParsedFile],
        repo_root: Path,
        config: sinewConfig,
        git_meta: GitMeta | None = None,
        skip_validation: bool = False,
    ) -> sinewGraph:
        start_time = time.perf_counter()
        nodes: list[Node] = []
        edges: list[Edge] = []
        languages_detected: set[str] = set()

        for pf in parsed_files:
            languages_detected.add(pf.language.value)
            nodes.extend(pf.nodes)
            edges.extend(pf.edges)

        nodes = self._merge_nodes(nodes)
        edges = self._merge_edges(edges, nodes)
        self._resolve_origins(nodes, edges)
        self._resolve_external_modules(nodes)
        self._compute_node_metrics(nodes, edges, config)
        self._resolve_test_coverage(nodes, edges)

        indexes = IndexBuilder.build(nodes, edges)
        lists = self._build_lists(nodes, edges)
        stats = StatsEngine.compute(nodes, edges, lists)

        build_duration_ms = int((time.perf_counter() - start_time) * 1000)

        meta = Meta(
            repo_name=repo_root.name,
            repo_root=str(repo_root),
            repo_root_relative="./",
            built_at=datetime.utcnow(),
            build_duration_ms=build_duration_ms,
            sinew_version="1.0",
            languages_detected=[Language(l) for l in languages_detected if l],
            files_scanned=len(parsed_files),
            files_ignored=0,
            total_nodes=len(nodes),
            total_edges=len(edges),
            confidence_threshold=config.confidence_threshold,
            entry_points=config.entry_points,
            git=git_meta,
        )

        graph = sinewGraph(
            sinew_version="1.0",
            meta=meta,
            nodes=nodes,
            edges=edges,
            indexes=indexes,
            lists=lists,
            stats=stats,
        )

        from sinew.schema.validator import validate_dict
        import json
        raw = json.loads(graph.to_json())
        if not skip_validation:
            result = validate_dict(raw)
            if not result.passed:
                raise GraphBuilderError(f"Graph validation failed: {result.summary()}")

        return graph

    def _merge_nodes(self, nodes: list[Node]) -> list[Node]:
        node_map: dict[str, Node] = {}
        for node in nodes:
            if node.id in node_map:
                existing = node_map[node.id]
                if node.line < existing.line:
                    logger.warning(f"Duplicate node id '{node.id}' - keeping lower line number ({node.line} < {existing.line})")
                    node_map[node.id] = node
            else:
                node_map[node.id] = node
        return list(node_map.values())

    def _merge_edges(self, edges: list[Edge], nodes: list[Node]) -> list[Edge]:
        node_ids = {n.id for n in nodes}
        edge_map: dict[str, Edge] = {}
        for edge in edges:
            if edge.id in edge_map:
                continue
            if edge.from_node not in node_ids:
                logger.warning(f"Orphaned edge '{edge.id}' - from_node '{edge.from_node}' not in nodes")
                continue
            if edge.to_node not in node_ids:
                logger.warning(f"Orphaned edge '{edge.id}' - to_node '{edge.to_node}' not in nodes")
                continue
            edge_map[edge.id] = edge
        return list(edge_map.values())

    def _resolve_origins(self, nodes: list[Node], edges: list[Edge]) -> None:
        node_map = {n.id: n for n in nodes}
        re_export_targets: dict[str, list[str]] = {}
        for edge in edges:
            if edge.type == EdgeType.RE_EXPORTS:
                if edge.to_node not in re_export_targets:
                    re_export_targets[edge.to_node] = []
                re_export_targets[edge.to_node].append(edge.file)

        for node in nodes:
            if node.id in re_export_targets:
                node.origin.is_same_as_definition = False
                node.origin.re_exported_by = re_export_targets[node.id]

    def _resolve_external_modules(self, nodes: list[Node]) -> None:
        file_node_ids = {n.id for n in nodes if n.type == NodeType.FILE}
        for node in nodes:
            if node.type == NodeType.MODULE:
                if node.id in file_node_ids:
                    node.is_external = False
                    node.is_stdlib = False
                    node.is_third_party = False
                elif node.id in STDLIB_MODULES:
                    node.is_external = True
                    node.is_stdlib = True
                    node.is_third_party = False
                else:
                    node.is_external = True
                    node.is_stdlib = False
                    node.is_third_party = True

    def _compute_node_metrics(
        self, nodes: list[Node], edges: list[Edge], config: sinewConfig
    ) -> None:
        node_map = {n.id: n for n in nodes}
        incoming_edges: dict[str, int] = {}
        outgoing_edges: dict[str, int] = {}
        callers: dict[str, int] = {}
        callees: dict[str, int] = {}

        for edge in edges:
            incoming_edges[edge.to_node] = incoming_edges.get(edge.to_node, 0) + 1
            outgoing_edges[edge.from_node] = outgoing_edges.get(edge.from_node, 0) + 1
            if edge.type == EdgeType.CALLS:
                callers[edge.to_node] = callers.get(edge.to_node, 0) + 1
                callees[edge.from_node] = callees.get(edge.from_node, 0) + 1

        for node in nodes:
            node.incoming_edge_count = incoming_edges.get(node.id, 0)
            node.outgoing_edge_count = outgoing_edges.get(node.id, 0)
            node.caller_count = callers.get(node.id, 0)
            node.callee_count = callees.get(node.id, 0)
            node.is_hotspot = node.incoming_edge_count >= 10

            if node.id in config.entry_points:
                node.is_entry_point = True
            elif node.name == "main" and node.caller_count == 0:
                node.is_entry_point = True

    def _resolve_test_coverage(self, nodes: list[Node], edges: list[Edge]) -> None:
        node_map = {n.id: n for n in nodes}
        test_nodes = [n for n in nodes if n.type == NodeType.TEST]

        for test_node in test_nodes:
            for edge in edges:
                if edge.from_node == test_node.id and edge.type in (EdgeType.CALLS, EdgeType.TESTS):
                    target = node_map.get(edge.to_node)
                    if target:
                        target.has_tests = True
                        if test_node.id not in target.test_ids:
                            target.test_ids.append(test_node.id)

    def _build_lists(self, nodes: list[Node], edges: list[Edge]) -> ListsModel:
        functions: list = []
        classes: list = []
        variables: list = []
        modules: list = []
        dead_symbols: list = []
        phantom_imports: list = []
        frozen_symbols: list = []
        deprecated_symbols: list = []
        hotspots: list = []

        node_map = {n.id: n for n in nodes}
        imported_modules: dict[str, set[str]] = {}
        for edge in edges:
            if edge.type == EdgeType.IMPORTS and edge.from_node not in imported_modules:
                imported_modules[edge.from_node] = set()
            if edge.type == EdgeType.IMPORTS:
                imported_modules[edge.from_node].add(edge.to_node)

        for node in nodes:
            if node.type == NodeType.FUNCTION or node.type == NodeType.METHOD:
                functions.append({
                    "id": node.id,
                    "name": node.name,
                    "file": node.file,
                    "line": node.line,
                    "is_dead": node.incoming_edge_count == 0 and not node.is_entry_point,
                    "is_hotspot": node.is_hotspot,
                    "has_tests": node.has_tests,
                    "sinew_critical": node.sinew.critical if node.sinew else False,
                    "sinew_owner": node.sinew.owner if node.sinew else None,
                })
            elif node.type == NodeType.CLASS:
                classes.append({
                    "id": node.id,
                    "name": node.name,
                    "file": node.file,
                    "line": node.line,
                    "is_abstract": node.is_abstract or False,
                    "has_tests": node.has_tests,
                    "sinew_critical": node.sinew.critical if node.sinew else False,
                    "sinew_owner": node.sinew.owner if node.sinew else None,
                })
            elif node.type == NodeType.VARIABLE:
                variables.append({
                    "id": node.id,
                    "name": node.name,
                    "file": node.file,
                    "line": node.line,
                    "is_constant": node.is_constant or False,
                    "is_global": node.is_global or False,
                    "sinew_critical": node.sinew.critical if node.sinew else False,
                })
            elif node.type == NodeType.MODULE:
                modules.append({
                    "id": node.id,
                    "name": node.name,
                    "is_external": node.is_external or False,
                    "is_stdlib": node.is_stdlib or False,
                    "is_third_party": node.is_third_party or False,
                    "imported_by_count": node.imported_by_count or 0,
                })
            elif node.type in (NodeType.FUNCTION, NodeType.METHOD, NodeType.CLASS, NodeType.VARIABLE):
                if node.incoming_edge_count == 0 and not node.is_entry_point:
                    dead_symbols.append({
                        "id": node.id,
                        "type": node.type,
                        "file": node.file,
                        "line": node.line,
                        "caller_count": node.caller_count,
                    })

            if node.is_hotspot:
                hotspots.append({
                    "id": node.id,
                    "incoming_edge_count": node.incoming_edge_count,
                })

            if node.sinew:
                if node.sinew.frozen:
                    frozen_symbols.append(node.id)
                if node.sinew.deprecated:
                    deprecated_symbols.append(node.id)

        from sinew.schema.models import (
            FunctionListItem, ClassListItem, VariableListItem, ModuleListItem,
            DeadSymbolItem, PhantomImportItem, HotspotItem
        )

        return ListsModel(
            functions=[FunctionListItem(**f) for f in functions],
            classes=[ClassListItem(**c) for c in classes],
            variables=[VariableListItem(**v) for v in variables],
            modules=[ModuleListItem(**m) for m in modules],
            dead_symbols=[DeadSymbolItem(**d) for d in dead_symbols],
            phantom_imports=[PhantomImportItem(**p) for p in phantom_imports],
            frozen_symbols=frozen_symbols,
            deprecated_symbols=deprecated_symbols,
            hotspots=[HotspotItem(**h) for h in hotspots],
        )
