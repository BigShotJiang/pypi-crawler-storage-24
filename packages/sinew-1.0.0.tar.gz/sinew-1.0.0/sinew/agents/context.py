import json
from typing import Any

from sinew.schema.models import sinewGraph, NodeType


def generate_context(
    graph: sinewGraph,
    task: str,
    token_budget: int = 4000,
) -> dict:
    task_lower = task.lower()

    scored_nodes: list[tuple[int, Any]] = []
    for node in graph.nodes:
        score = 0
        if node.name.lower() in task_lower:
            score += 3
        if node.file.lower() in task_lower:
            score += 2
        if node.sinew and node.sinew.group and node.sinew.group.lower() in task_lower:
            score += 2
        if node.sinew and node.sinew.critical:
            score += 1
        if score > 0:
            scored_nodes.append((score, node))

    scored_nodes.sort(key=lambda x: x[0], reverse=True)

    selected_nodes: list[Any] = []
    for score, node in scored_nodes:
        node_data = _extract_node_data(node)
        test_payload = {
            "nodes": selected_nodes + [node_data],
            "edges": [],
        }
        if _estimate_tokens(test_payload) <= token_budget:
            selected_nodes.append(node_data)
        else:
            break

    selected_ids = {n["id"] for n in selected_nodes}
    selected_edges = []
    for edge in graph.edges:
        if edge.from_node in selected_ids and edge.to_node in selected_ids:
            selected_edges.append({
                "id": edge.id,
                "from": edge.from_node,
                "to": edge.to_node,
                "type": edge.type.value,
                "confidence": edge.confidence,
            })

    return {
        "nodes": selected_nodes,
        "edges": selected_edges,
    }


def _extract_node_data(node: Any) -> dict:
    data: dict[str, Any] = {
        "id": node.id,
        "type": node.type.value,
        "file": node.file,
        "line": node.line,
        "notes": node.notes,
    }

    if node.sinew:
        data["sinew"] = {
            "note": node.sinew.note,
            "critical": node.sinew.critical,
            "frozen": node.sinew.frozen,
            "frozen_reason": node.sinew.frozen_reason,
            "group": node.sinew.group,
            "owner": node.sinew.owner,
        }

    if node.type in (NodeType.FUNCTION, NodeType.METHOD):
        if node.parameters:
            data["parameters"] = [
                {"name": p.name, "type": p.type_annotation}
                for p in node.parameters
            ]
        data["return_type"] = node.return_type
        data["raises"] = node.raises

    if node.type == NodeType.CLASS:
        data["methods"] = node.methods
        data["base_classes"] = node.base_classes

    active_warnings = [w for w in node.agent_warnings if not w.resolved]
    if active_warnings:
        data["agent_warnings"] = [
            {
                "description": w.description,
                "severity": w.severity.value,
                "logged_at": w.logged_at.isoformat(),
            }
            for w in active_warnings
        ]

    return data


def _estimate_tokens(payload: dict) -> int:
    return len(json.dumps(payload)) // 4
