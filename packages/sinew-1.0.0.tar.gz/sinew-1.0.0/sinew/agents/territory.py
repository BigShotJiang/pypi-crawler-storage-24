import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from sinew.schema.models import sinewGraph


TERRITORY_FILE = ".sinew_territory.json"


@dataclass
class TerritoryConflict:
    other_agent: str
    other_scope: str
    other_task: str
    shared_nodes: list[str]
    recommendation: str


@dataclass
class TerritoryResult:
    success: bool
    conflicts: list[TerritoryConflict] = field(default_factory=list)


class TerritoryMap:
    def __init__(self, repo_root: Path | None = None):
        self.repo_root = repo_root or Path.cwd()
        self.territory_file = self.repo_root / TERRITORY_FILE

    def _load_territories(self) -> dict[str, Any]:
        if not self.territory_file.exists():
            return {"claims": []}
        try:
            return json.loads(self.territory_file.read_text(encoding="utf-8"))
        except Exception:
            return {"claims": []}

    def _save_territories(self, data: dict[str, Any]) -> None:
        self.territory_file.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")

    def claim(
        self,
        agent_id: str,
        scope: str,
        task: str,
        graph: sinewGraph,
    ) -> TerritoryResult:
        data = self._load_territories()
        claims = data.get("claims", [])

        scope_nodes = self._get_nodes_in_scope(graph, scope)

        conflicts: list[TerritoryConflict] = []
        for existing in claims:
            if existing.get("agent_id") == agent_id:
                continue

            existing_scope = existing.get("scope", "")
            existing_nodes = self._get_nodes_in_scope(graph, existing_scope)

            overlap = list(set(scope_nodes) & set(existing_nodes))
            if overlap:
                shared_node_names = [graph.get_node(n).name if graph.get_node(n) else n for n in overlap[:5]]
                conflicts.append(TerritoryConflict(
                    other_agent=existing.get("agent_id", "unknown"),
                    other_scope=existing.get("scope", ""),
                    other_task=existing.get("task", ""),
                    shared_nodes=overlap,
                    recommendation=f"Coordinate with {existing.get('agent_id')} or wait for them to complete.",
                ))

        if conflicts:
            return TerritoryResult(success=False, conflicts=conflicts)

        new_claim = {
            "agent_id": agent_id,
            "scope": scope,
            "task": task,
            "node_ids": scope_nodes,
        }
        claims.append(new_claim)
        data["claims"] = claims
        self._save_territories(data)

        return TerritoryResult(success=True, conflicts=[])

    def release(self, agent_id: str) -> None:
        data = self._load_territories()
        claims = data.get("claims", [])
        claims = [c for c in claims if c.get("agent_id") != agent_id]
        data["claims"] = claims
        self._save_territories(data)

    def status(self) -> list[dict]:
        data = self._load_territories()
        return data.get("claims", [])

    def _get_nodes_in_scope(self, graph: sinewGraph, scope: str) -> list[str]:
        scope_normalized = scope.replace("\\", "/").strip("/")
        scope_parts = scope_normalized.split("/")

        nodes_in_scope = []
        for node in graph.nodes:
            node_file_normalized = node.file.replace("\\", "/")
            node_parts = node_file_normalized.split("/")

            match = True
            for i, part in enumerate(scope_parts):
                if i >= len(node_parts) or node_parts[i] != part:
                    match = False
                    break
            if match:
                nodes_in_scope.append(node.id)

        if not nodes_in_scope:
            scope_lower = scope_normalized.lower()
            for node in graph.nodes:
                node_file_lower = node.file.replace("\\", "/").lower()
                if scope_lower in node_file_lower:
                    nodes_in_scope.append(node.id)

        return nodes_in_scope
