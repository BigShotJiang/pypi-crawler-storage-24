import difflib
from dataclasses import dataclass, field
from typing import Any

from sinew.schema.models import sinewGraph, Language


@dataclass
class HallucinationIssue:
    symbol: str
    kind: str
    line: int
    suggestion: str | None = None


@dataclass
class VerifyResult:
    passed: bool
    hallucinations: list[HallucinationIssue] = field(default_factory=list)
    frozen_violations: list[str] = field(default_factory=list)
    constitution_violations: list[str] = field(default_factory=list)


def verify_output(
    code: str,
    graph: sinewGraph,
    language: Language = Language.PYTHON,
) -> VerifyResult:
    symbols = _extract_symbols(code, language)

    all_node_names = [n.name for n in graph.nodes]
    node_map = {n.name: n for n in graph.nodes}

    hallucinations: list[HallucinationIssue] = []
    frozen_violations: list[str] = []

    for symbol, kind, line in symbols:
        node = node_map.get(symbol)
        if node is None:
            suggestion = None
            matches = difflib.get_close_matches(symbol, all_node_names, n=1)
            if matches:
                suggestion = f"Did you mean: {matches[0]}"
            hallucinations.append(HallucinationIssue(
                symbol=symbol,
                kind=kind,
                line=line,
                suggestion=suggestion,
            ))
        elif node.is_frozen:
            frozen_violations.append(f"{symbol} — frozen ({node.sinew.frozen_reason})")

    passed = len(hallucinations) == 0 and len(frozen_violations) == 0

    return VerifyResult(
        passed=passed,
        hallucinations=hallucinations,
        frozen_violations=frozen_violations,
    )


def _extract_symbols(code: str, language: Language) -> list[tuple[str, str, int]]:
    symbols: list[tuple[str, str, int]] = []

    if language == Language.PYTHON:
        symbols.extend(_extract_python_symbols(code))

    return symbols


def _extract_python_symbols(code: str) -> list[tuple[str, str, int]]:
    symbols: list[tuple[str, str, int]] = []

    try:
        from tree_sitter import Language, Parser
        from tree_sitter_languages import get_language

        parser = Parser()
        parser.set_language(get_language("python"))

        tree = parser.parse(bytes(code, "utf8"))

        def visit(node: Any) -> None:
            node_type = node.type

            if node_type == "call":
                func_node = node.child_by_field_name("function")
                if func_node:
                    if func_node.type == "identifier":
                        func_name = code[func_node.start_byte:func_node.end_byte]
                        if func_name and not func_name.startswith("_"):
                            symbols.append((func_name, "function_call", node.start_point[0] + 1))
                    elif func_node.type == "attribute":
                        attr_name = code[func_node.start_byte:func_node.end_byte]
                        if attr_name:
                            symbols.append((attr_name, "function_call", node.start_point[0] + 1))

            elif node_type == "attribute":
                attr_node = node.child_by_field_name("attribute")
                if attr_node:
                    attr_name = code[attr_node.start_byte:attr_node.end_byte]
                    symbols.append((attr_name, "attribute_access", node.start_point[0] + 1))

            elif node_type == "import_statement":
                for child in node.children:
                    if child.type == "dotted_name":
                        name = code[child.start_byte:child.end_byte]
                        symbols.append((name, "import", node.start_point[0] + 1))

            elif node_type == "import_from_statement":
                for child in node.children:
                    if child.type == "dotted_name":
                        name = code[child.start_byte:child.end_byte]
                        symbols.append((name, "import", node.start_point[0] + 1))

            for child in node.children:
                visit(child)

        visit(tree.root_node)

    except ImportError:
        symbols.extend(_extract_python_symbols_fallback(code))
    except Exception as e:
        import sys
        print(f"Tree-sitter parsing error: {e}", file=sys.stderr)
        symbols.extend(_extract_python_symbols_fallback(code))

    return symbols


def _extract_python_symbols_fallback(code: str) -> list[tuple[str, str, int]]:
    """Fallback parser using Python AST when tree-sitter is unavailable."""
    import ast
    symbols: list[tuple[str, str, int]] = []

    try:
        tree = ast.parse(code)
        for node in ast.walk(tree):
            if isinstance(node, ast.Call):
                if isinstance(node.func, ast.Name):
                    if not node.func.id.startswith("_"):
                        symbols.append((node.func.id, "function_call", node.lineno))
                elif isinstance(node.func, ast.Attribute):
                    attr_name = node.func.attr
                    symbols.append((attr_name, "function_call", node.lineno))
            elif isinstance(node, ast.Import):
                for alias in node.names:
                    symbols.append((alias.name, "import", node.lineno))
            elif isinstance(node, ast.ImportFrom):
                if node.module:
                    symbols.append((node.module, "import", node.lineno))
    except Exception:
        pass

    return symbols
