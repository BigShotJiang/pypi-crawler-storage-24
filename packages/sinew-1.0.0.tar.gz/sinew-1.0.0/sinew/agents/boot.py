import json
from typing import Any

from sinew.schema.models import sinewGraph, SessionState


def generate_boot_payload(
    graph: sinewGraph,
    task: str,
    token_budget: int = 800,
    session_id: str | None = None,
) -> dict:
    task_lower = task.lower()

    scored_nodes: list[tuple[int, Any]] = []
    for node in graph.nodes:
        score = 0
        if node.name.lower() in task_lower:
            score += 3
        if node.file.lower() in task_lower:
            score += 2
        if node.sinew and node.sinew.group and node.sinew.group.lower() in task_lower:
            score += 2
        if node.sinew and node.sinew.critical:
            score += 1
        if score > 0:
            scored_nodes.append((score, node))

    scored_nodes.sort(key=lambda x: x[0], reverse=True)
    in_scope = [n for _, n in scored_nodes[:10]]

    relevant_files = list({n.file for n in in_scope})
    entry_points = [n.id for n in in_scope if n.is_entry_point]
    hotspots_in_scope = [n.id for n in in_scope if n.is_hotspot]

    naming_pattern = "snake_case"
    func_names = [n.name for n in in_scope if n.type.value in ("function", "method")]
    if func_names:
        underscore_count = sum(1 for name in func_names if "_" in name)
        if underscore_count > len(func_names) / 2:
            naming_pattern = "snake_case"
        else:
            naming_pattern = "camelCase"

    owners = list({n.sinew.owner for n in in_scope if n.sinew and n.sinew.owner})
    groups = list({n.sinew.group for n in in_scope if n.sinew and n.sinew.group})

    do_not_recreate = [
        f"{n.name} — {n.file} line {n.line}" for n in in_scope
    ]

    past_mistakes = []
    for node in in_scope:
        for warning in node.agent_warnings:
            if not warning.resolved:
                past_mistakes.append(warning.description)

    frozen_zones = []
    for node in in_scope:
        if node.is_frozen:
            frozen_zones.append(f"{node.id} — {node.sinew.frozen_reason}")

    confidence_warnings = []
    for node in in_scope:
        if node.confidence_min < 0.75:
            confidence_warnings.append(f"{node.id} — confidence {node.confidence_min}")

    payload = {
        "task_scope": {
            "relevant_files": relevant_files,
            "entry_points": entry_points,
            "hotspots_in_scope": hotspots_in_scope,
        },
        "conventions": {
            "naming": naming_pattern,
            "owners": owners,
            "groups": groups,
        },
        "what_already_exists": {
            "do_not_recreate": do_not_recreate,
        },
        "past_mistakes": past_mistakes,
        "frozen_zones": frozen_zones,
        "confidence_warnings": confidence_warnings,
    }

    if session_id:
        for session in graph.session_state:
            if session.session_id == session_id:
                payload["remaining_steps"] = session.remaining_steps
                payload["decisions"] = session.decisions
                break

    payload = _trim_payload(payload, token_budget)

    return payload


def _trim_payload(payload: dict, token_budget: int) -> dict:
    while _estimate_tokens(payload) > token_budget:
        if payload["what_already_exists"]["do_not_recreate"]:
            payload["what_already_exists"]["do_not_recreate"].pop()
        elif payload["confidence_warnings"]:
            payload["confidence_warnings"].pop()
        elif payload["frozen_zones"]:
            payload["frozen_zones"].pop()
        else:
            break
    return payload


def _estimate_tokens(payload: dict) -> int:
    return len(json.dumps(payload)) // 4
