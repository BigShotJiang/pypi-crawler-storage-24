"""
Schema module - imports from root schema/ directory.

This module re-exports all schema components from the root schema/
directory to maintain a single source of truth while providing
the expected import path (sinew.schema.models, sinew.schema.validator).

The root schema/ directory contains the canonical implementations:
- schema/models.py: Pydantic models for the sinew graph structure
- schema/validator.py: Validation logic for sinew.json files

This __init__.py uses path manipulation to include the root schema/
directory and re-exports all components, allowing imports like:
    from sinew.schema.models import Node, Edge, sinewGraph
    from sinew.schema.validator import validate_file, validate_dict
"""

import sys
from pathlib import Path

# Add root schema directory to path
root_schema = Path(__file__).parent.parent.parent / "schema"
if str(root_schema) not in sys.path:
    sys.path.insert(0, str(root_schema))

# Import models module and make it available as sinew.schema.models
import models as _models_module  # noqa: F401
sys.modules['sinew.schema.models'] = _models_module

# Now we can safely import validator (which depends on sinew.schema.models)
import validator as _validator_module  # noqa: F401
sys.modules['sinew.schema.validator'] = _validator_module

# Re-export all components from models
from models import *  # noqa: F401, F403

# Re-export all components from validator
from validator import *  # noqa: F401, F403
