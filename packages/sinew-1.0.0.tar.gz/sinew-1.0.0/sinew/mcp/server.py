import os
import json
from pathlib import Path
from datetime import datetime
from typing import Any

from fastmcp import FastMCP

from sinew.agents.boot import generate_boot_payload
from sinew.agents.context import generate_context
from sinew.agents.verify import verify_output as verify_output_func
from sinew.agents.territory import TerritoryMap
from sinew.schema.models import sinewGraph, Language, WarningSeverity, AgentWarning, NodeType
from sinew.schema.validator import validate_file

mcp = FastMCP("sinew")


class SinewMCPServer:
    def __init__(self, graph_path: str | None = None):
        self._graph_path = graph_path or os.environ.get("sinew_GRAPH", "sinew.json")
        self._graph: sinewGraph | None = None

    @property
    def graph(self) -> sinewGraph:
        if self._graph is None:
            self._graph = self._load_graph()
        return self._graph

    def _load_graph(self) -> sinewGraph:
        result = validate_file(self._graph_path)
        if not result.passed:
            raise ValueError(f"Failed to load graph from {self._graph_path}: {result.errors}")
        return result.graph

    def reload_graph(self) -> None:
        self._graph = self._load_graph()

    def set_graph(self, graph: sinewGraph) -> None:
        self._graph = graph


_server: SinewMCPServer | None = None


def get_server(graph_path: str | None = None, graph: sinewGraph | None = None) -> SinewMCPServer:
    global _server
    if _server is None:
        _server = SinewMCPServer(graph_path)
    if graph is not None:
        _server.set_graph(graph)
    return _server


@mcp.tool()
def get_boot(task: str, tokens: int = 800) -> dict:
    server = get_server()
    payload = generate_boot_payload(server.graph, task, tokens)
    return payload


@mcp.tool()
def get_context(task: str, tokens: int = 4000) -> dict:
    server = get_server()
    return generate_context(server.graph, task, tokens)


@mcp.tool()
def check_exists(symbol: str) -> dict:
    server = get_server()
    matches = []
    for node in server.graph.nodes:
        if node.name == symbol:
            matches.append({
                "id": node.id,
                "type": node.type.value,
                "file": node.file,
                "line": node.line,
            })
    return {"found": len(matches) > 0, "matches": matches}


@mcp.tool()
def get_impact(symbol: str) -> dict:
    server = get_server()
    node = None
    for n in server.graph.nodes:
        if n.name == symbol:
            node = n
            break

    if not node:
        return {"callers": [], "files": [], "risk_level": "unknown", "callers_affected": 0}

    callers = server.graph.get_callers(node.id)
    files = list({c.file for c in callers})

    caller_count = len(callers)
    if caller_count > 10:
        risk_level = "high"
    elif caller_count > 5:
        risk_level = "medium"
    else:
        risk_level = "low"

    return {
        "callers": [{"id": c.id, "name": c.name, "file": c.file} for c in callers],
        "files": files,
        "risk_level": risk_level,
        "callers_affected": caller_count,
    }


@mcp.tool()
def get_preflight(changes: str) -> dict:
    server = get_server()
    words = changes.lower().split()
    matched_nodes = []
    for word in words:
        for node in server.graph.nodes:
            if node.name.lower() == word:
                matched_nodes.append(node)

    unique_nodes = list({n.id: n for n in matched_nodes}.values())

    callers_affected = 0
    frozen_nodes_touched = []
    agent_warnings = []

    for node in unique_nodes:
        callers = server.graph.get_callers(node.id)
        callers_affected += len(callers)
        if node.is_frozen:
            frozen_nodes_touched.append(f"{node.id}: {node.sinew.frozen_reason}")
        for warning in node.agent_warnings:
            if not warning.resolved:
                agent_warnings.append(f"{node.id}: {warning.description}")

    if frozen_nodes_touched:
        risk = "high"
        recommendation = "Frozen nodes affected. Do not proceed without approval."
    elif callers_affected > 10:
        risk = "high"
        recommendation = "Many callers affected. Review carefully."
    elif callers_affected > 5:
        risk = "medium"
        recommendation = "Some callers affected. Test thoroughly."
    else:
        risk = "low"
        recommendation = "Low impact. Safe to proceed."

    return {
        "risk": risk,
        "callers_affected": callers_affected,
        "frozen_nodes_touched": frozen_nodes_touched,
        "agent_warnings": agent_warnings,
        "recommendation": recommendation,
    }


@mcp.tool()
def claim_territory(agent_id: str, scope: str, task: str) -> dict:
    server = get_server()
    territory = TerritoryMap()
    result = territory.claim(agent_id, scope, task, server.graph)
    return {
        "success": result.success,
        "conflicts": [
            {
                "other_agent": c.other_agent,
                "other_scope": c.other_scope,
                "other_task": c.other_task,
                "shared_nodes": c.shared_nodes,
                "recommendation": c.recommendation,
            }
            for c in result.conflicts
        ],
    }


@mcp.tool()
def release_territory(agent_id: str) -> dict:
    server = get_server()
    territory = TerritoryMap()
    territory.release(agent_id)
    return {"released": True}


@mcp.tool()
def log_mistake(node_id: str, description: str, severity: str = "high") -> dict:
    server = get_server()
    node = server.graph.get_node(node_id)
    if not node:
        raise ValueError(f"Node {node_id} not found")

    warning = AgentWarning(
        id=f"warning_{datetime.now().timestamp()}",
        description=description,
        severity=WarningSeverity(severity),
        logged_at=datetime.now(),
        logged_by="mcp-server",
    )

    if node.agent_warnings is None:
        node.agent_warnings = []
    node.agent_warnings.append(warning)

    with open(server._graph_path, "w") as f:
        f.write(server.graph.to_json())

    return {"logged": True, "warning_id": warning.id}


@mcp.tool()
def verify_output(code: str, language: str = "python") -> dict:
    server = get_server()
    lang = Language(language.lower())
    result = verify_output_func(code, server.graph, lang)
    return {
        "passed": result.passed,
        "hallucinations": [
            {
                "symbol": h.symbol,
                "kind": h.kind,
                "line": h.line,
                "suggestion": h.suggestion,
            }
            for h in result.hallucinations
        ],
        "frozen_violations": result.frozen_violations,
    }


@mcp.tool()
def search(query: str, node_type: str | None = None) -> dict:
    server = get_server()
    query_lower = query.lower()
    results = []

    for node in server.graph.nodes:
        if node_type and node.type.value != node_type:
            continue
        if query_lower in node.name.lower() or query_lower in (node.file or "").lower():
            results.append({
                "id": node.id,
                "name": node.name,
                "type": node.type.value,
                "file": node.file,
                "line": node.line,
            })

    return {"results": results}


@mcp.tool()
def trace(symbol: str, depth: int = 10) -> dict:
    server = get_server()
    node = None
    for n in server.graph.nodes:
        if n.name == symbol:
            node = n
            break

    if not node:
        return {"error": f"Symbol {symbol} not found"}

    def build_trace(node_id: str, current_depth: int) -> dict | None:
        if current_depth <= 0:
            return None
        n = server.graph.get_node(node_id)
        if not n:
            return None
        callees = server.graph.get_callees(node_id)
        children = []
        for callee in callees[:5]:
            child = build_trace(callee.id, current_depth - 1)
            if child:
                children.append(child)
        return {
            "id": n.id,
            "name": n.name,
            "type": n.type.value,
            "file": n.file,
            "line": n.line,
            "calls": children,
        }

    trace_result = build_trace(node.id, depth)
    if trace_result is None:
        trace_result = {"id": node.id, "name": node.name, "type": node.type.value, "file": node.file, "line": node.line, "calls": []}

    return trace_result


def run_server(graph_path: str | None = None, port: int = 2048) -> None:
    global _server
    _server = SinewMCPServer(graph_path)
    print(f"Sinew MCP server running on http://localhost:{port}/mcp")
    mcp.run(transport="stdio")
