"""
CLI entry point for Sinew.

Responsibilities:
- Parse command-line arguments and options.
- Orchestrate scanning, parsing, graph building, and export.
- Provide rich console output and progress tracking.
- Handle errors and display user-friendly messages.

Key Commands:
- build: Scan a directory and build a dependency graph.
- stats: Display structural statistics about a codebase.
- validate: Check code against constitution rules.
- export: Export the graph to various formats.

Implementation Notes:
- Use Typer for CLI argument parsing.
- Use Rich for terminal formatting and progress bars.
- Ensure all commands respect .sinewconfig.
"""

import json
import time
from pathlib import Path
from typing import Any, Optional

import typer
from rich.console import Console
from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, TextColumn, BarColumn, TaskProgressColumn
from rich.table import Table
from rich.tree import Tree
from rich.layout import Layout
from rich import box

from sinew.core.config import sinewConfig
from sinew.core.scanner import FileScanner
from sinew.graph.builder import GraphBuilder
from sinew.graph.stats import StatsEngine
from sinew.graph.indexer import IndexBuilder
from sinew.parsers.python.parser import PythonParser
from sinew.agents.boot import generate_boot_payload
from sinew.agents.context import generate_context
from sinew.agents.verify import verify_output
from sinew.agents.territory import TerritoryMap
from sinew.schema.models import NodeType, EdgeType, sinewGraph, Language, WarningSeverity, AgentWarning
from datetime import datetime
from sinew.schema.validator import validate_file, validate_dict
from sinew.mcp.server import run_server

app = typer.Typer(
    name="sinew",
    help="Structural dependency graph generator for codebases",
    add_completion=False,
)
console = Console()


def _load_graph(graph_path: str | Path) -> sinewGraph | None:
    """Load and validate a sinew.json file."""
    result = validate_file(graph_path)
    if not result.passed:
        console.print(Panel(
            "[bold red]Validation Failed[/bold red]\n\n" +
            "\n".join(f"[red]•[/red] {i.message}" for i in result.errors),
            title="Graph Validation Error",
            border_style="red"
        ))
        return None
    return result.graph


def _load_graph_or_exit(graph_path: str | Path) -> sinewGraph:
    """Load graph or exit with code 1."""
    graph = _load_graph(graph_path)
    if graph is None:
        raise typer.Exit(code=1)
    return graph


def _check_config_exists(repo_root: Path) -> bool:
    """Check if .sinewconfig exists, prompt user if not."""
    config_file = repo_root / ".sinewconfig"
    if not config_file.exists():
        console.print(Panel(
            f"[bold yellow]No .sinewconfig found in {repo_root}[/bold yellow]\n\n"
            "Please create a .sinewconfig file in your project root.\n"
            "Example:\n"
            "[dim]sinew = {{ languages = [\"python\"] }}[/dim]",
            title="Configuration Required",
            border_style="yellow"
        ))
        return False
    return True


def _get_parser_for_language(language: str):
    """Get the appropriate parser for a language."""
    if language == "python":
        return PythonParser()
    raise ValueError(f"No parser for language: {language}")


@app.command()
def build(
    path: str = typer.Argument(".", help="Path to the codebase to analyze"),
    output: str = typer.Option("sinew.json", "--output", "-o", help="Output file path"),
    file: bool = typer.Option(False, "--file", help="Treat PATH as a single file, not a directory"),
    ignore: str = typer.Option("", "--ignore", help="Comma-separated extra ignore patterns"),
):
    """Scan code and build a dependency graph."""
    start_time = time.perf_counter()

    if file:
        repo_root = Path(path).parent
    else:
        repo_root = Path(path)

    if not _check_config_exists(repo_root):
        raise typer.Exit(code=1)

    config = sinewConfig.from_repo(repo_root)

    if ignore:
        extra_patterns = [p.strip() for p in ignore.split(",") if p.strip()]
        config.ignore_custom.extend(extra_patterns)
        config._ignore_patterns = None
        config = sinewConfig.from_repo(repo_root)
        config.ignore_custom.extend(extra_patterns)

    scanned_files = FileScanner.scan(repo_root, config)

    parsed_files = []
    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        BarColumn(),
        TaskProgressColumn(),
        console=console,
    ) as progress:
        task = progress.add_task("[cyan]Parsing files...", total=len(scanned_files))
        parser = _get_parser_for_language(config.languages[0])
        for scanned in scanned_files:
            result = parser.parse_file(str(scanned.path), repo_root)
            parsed_files.append(result)
            progress.advance(task)

    graph = GraphBuilder().build(parsed_files, repo_root, config, skip_validation=True)

    output_path = Path(output)
    if not output_path.is_absolute():
        output_path = repo_root / output_path
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(graph.to_json(), encoding="utf-8")

    elapsed_ms = int((time.perf_counter() - start_time) * 1000)

    console.print(Panel(
        f"[bold]Files scanned:[/bold] {len(scanned_files)} | "
        f"[bold]Nodes:[/bold] {len(graph.nodes)} | "
        f"[bold]Edges:[/bold] {len(graph.edges)} | "
        f"[bold]Time:[/bold] {elapsed_ms}ms\n"
        f"[bold]Warnings:[/bold] 0 | [bold]Errors:[/bold] 0\n"
        f"Saved to: {output_path}",
        title="Build Complete",
        border_style="green"
    ))


@app.command()
def stats(
    graph_path: str = typer.Option("sinew.json", "--graph", help="Path to sinew.json"),
):
    """Show statistics about the code graph."""
    graph = _load_graph_or_exit(graph_path)

    s = graph.stats
    ss = s.structural_score

    left_table = Table(title="Symbol Counts", box=box.ROUNDED)
    left_table.add_column("Metric", style="cyan")
    left_table.add_column("Count", style="magenta", justify="right")
    left_table.add_row("Files", str(s.files.total))
    left_table.add_row("Functions", str(s.symbols.functions))
    left_table.add_row("Classes", str(s.symbols.classes))
    left_table.add_row("Variables", str(s.symbols.variables))
    left_table.add_row("Modules", str(s.symbols.modules))
    left_table.add_row("Dead functions", str(s.dead_code.dead_functions))
    left_table.add_row("Dead classes", str(s.dead_code.dead_classes))
    left_table.add_row("Phantom imports", str(s.dead_code.phantom_imports))

    def score_color(score: int) -> str:
        if score >= 80:
            return "green"
        elif score >= 60:
            return "yellow"
        return "red"

    def score_bar(score: int) -> str:
        c = score_color(score)
        filled = int(score / 10)
        return f"[{c}]" + "█" * filled + "░" * (10 - filled) + f"[/{c}]"

    right_table = Table(title="Structural Score", box=box.ROUNDED)
    right_table.add_column("Dimension", style="cyan")
    right_table.add_column("Score", style="magenta")
    right_table.add_row("Total Score", f"[bold]{ss.total}[/bold]")
    right_table.add_row("Complexity", f"{score_bar(ss.coupling)} {ss.coupling}")
    right_table.add_row("Coverage", f"{score_bar(ss.testability)} {ss.testability}")
    right_table.add_row("Hotspots", f"{score_bar(ss.cohesion)} {ss.cohesion}")
    right_table.add_row("Confidence", f"{score_bar(ss.documentation)} {ss.documentation}")

    layout = Layout()
    layout.split_row(
        Layout(left_table, size=40),
        Layout(right_table, size=60),
    )
    console.print(layout)


@app.command()
def trace(
    symbol: str = typer.Argument(..., help="Function name or fully qualified ID"),
    graph_path: str = typer.Option("sinew.json", "--graph", help="Path to sinew.json"),
    depth: int = typer.Option(10, "--depth", help="Max depth"),
):
    """Print the call chain for a symbol as a tree."""
    graph = _load_graph_or_exit(graph_path)

    matches = [n for n in graph.nodes if symbol.lower() in n.name.lower()]

    if not matches:
        console.print(f"[red]Symbol '{symbol}' not found[/red]")
        raise typer.Exit(code=1)

    if len(matches) > 1:
        table = Table(title="Multiple matches found", box=box.ROUNDED)
        table.add_column("Name", style="cyan")
        table.add_column("Type", style="magenta")
        table.add_column("File", style="green")
        table.add_column("Line", justify="right")
        for m in matches:
            table.add_row(m.name, m.type.value, m.file, str(m.line))
        console.print(table)
        raise typer.Exit(code=1)

    target = matches[0]
    node_map = {n.id: n for n in graph.nodes}

    def build_tree(node_id: str, current_depth: int, tree: Tree) -> None:
        if current_depth >= depth:
            return
        for edge in graph.edges:
            if edge.from_node == node_id and edge.type == EdgeType.CALLS:
                callee = node_map.get(edge.to_node)
                if callee:
                    child_tree = tree.add(f"[cyan]{callee.name}[/cyan] ({callee.file}:{callee.line})")
                    build_tree(edge.to_node, current_depth + 1, child_tree)

    root_tree = Tree(f"[bold]{target.name}[/bold] ({target.file}:{target.line})")
    build_tree(target.id, 0, root_tree)
    console.print(Panel(root_tree, title=f"Call Chain: {symbol}", border_style="blue"))


@app.command()
def impact(
    symbol: str = typer.Argument(..., help="Symbol to analyze"),
    graph_path: str = typer.Option("sinew.json", "--graph", help="Path to sinew.json"),
):
    """Show blast radius of changing this symbol."""
    graph = _load_graph_or_exit(graph_path)

    matches = [n for n in graph.nodes if symbol.lower() in n.name.lower()]
    if not matches:
        console.print(f"[red]Symbol '{symbol}' not found[/red]")
        raise typer.Exit(code=1)

    target = matches[0] if len(matches) == 1 else matches[0]
    if len(matches) > 1:
        console.print(f"[yellow]Multiple matches, using first: {target.id}[/yellow]")

    node_map = {n.id: n for n in graph.nodes}
    affected: list[tuple[str, str, int, bool]] = []

    def collect_callers(node_id: str, depth: int, visited: set[str]) -> None:
        if node_id in visited or depth > 20:
            return
        visited.add(node_id)
        reverse = graph.indexes.reverse.get(node_id)
        if reverse:
            for caller_id in reverse.called_by:
                caller = node_map.get(caller_id)
                if caller:
                    has_tests = caller.has_tests
                    affected.append((caller.name, caller.file, depth + 1, has_tests))
                    collect_callers(caller_id, depth + 1, visited)

    collect_callers(target.id, 0, set())

    risk_level = "LOW"
    if len(affected) >= 10:
        risk_level = "HIGH"
    elif len(affected) >= 5:
        risk_level = "MEDIUM"

    risk_color = {"HIGH": "red", "MEDIUM": "yellow", "LOW": "green"}[risk_level]

    console.print(Panel(
        f"[bold]Symbol:[/bold] {target.name}\n"
        f"[bold]File:[/bold] {target.file}:{target.line}\n"
        f"[bold]Risk level:[/bold] [{risk_color}]{risk_level}[/{risk_color}]",
        title="Impact Analysis",
        border_style=risk_color
    ))

    table = Table(title="Affected Callers", box=box.ROUNDED)
    table.add_column("Caller", style="cyan")
    table.add_column("File", style="green")
    table.add_column("Depth", justify="right")
    table.add_column("Has Tests")
    for name, file, d, has_tests in affected:
        table.add_row(name, file, str(d), "✓" if has_tests else "✗")
    console.print(table)

    files = set(f for _, f, _, _ in affected)
    modules = set(f.split("/")[0] if "/" in f else "" for f in files)
    console.print(f"\n[bold]Summary:[/bold] {len(affected)} affected functions, {len(files)} files, {len(modules)} modules")


@app.command()
def search(
    query: str = typer.Argument(..., help="Search query (partial match, case-insensitive)"),
    graph_path: str = typer.Option("sinew.json", "--graph", help="Path to sinew.json"),
    type: Optional[str] = typer.Option(None, "--type", help="Filter by node type"),
    save: Optional[str] = typer.Option(None, "--save", help="Save matching subgraph to JSON"),
):
    """Search nodes by name and print results as a table."""
    graph = _load_graph_or_exit(graph_path)

    matches = [n for n in graph.nodes if query.lower() in n.name.lower()]
    if type:
        node_type = NodeType(type.lower())
        matches = [n for n in matches if n.type == node_type]

    if not matches:
        console.print("[yellow]No matches found[/yellow]")
        raise typer.Exit(code=0)

    table = Table(title=f"Search Results: {query}", box=box.ROUNDED)
    table.add_column("ID", style="cyan")
    table.add_column("Type", style="magenta")
    table.add_column("File", style="green")
    table.add_column("Line", justify="right")
    table.add_column("Hotspot", justify="center")
    table.add_column("Has Tests", justify="center")

    for n in matches:
        table.add_row(
            n.name,
            n.type.value,
            n.file,
            str(n.line),
            "🔥" if n.is_hotspot else "",
            "✓" if n.has_tests else ""
        )
    console.print(table)

    if save:
        matching_ids = {n.id for n in matches}
        neighbor_ids = set()
        for n in matches:
            for e in graph.edges:
                if e.from_node == n.id:
                    neighbor_ids.add(e.to_node)
                if e.to_node == n.id:
                    neighbor_ids.add(e.from_node)

        subgraph_nodes = [n for n in graph.nodes if n.id in matching_ids or n.id in neighbor_ids]
        subgraph_edges = [e for e in graph.edges if e.from_node in matching_ids or e.to_node in matching_ids]

        subgraph = {
            "sinew_version": "1.0",
            "meta": graph.meta.model_dump(),
            "nodes": [n.model_dump() for n in subgraph_nodes],
            "edges": [e.model_dump() for e in subgraph_edges],
            "indexes": {},
            "lists": {},
            "stats": {}
        }
        Path(save).write_text(json.dumps(subgraph, indent=2), encoding="utf-8")
        console.print(f"[green]Saved to: {save}[/green]")


@app.command()
def dead(
    graph_path: str = typer.Option("sinew.json", "--graph", help="Path to sinew.json"),
    type: Optional[str] = typer.Option(None, "--type", help="Filter by node type"),
):
    """Print dead code as a table grouped by file."""
    graph = _load_graph_or_exit(graph_path)

    dead_nodes = [n for n in graph.nodes if n.incoming_edge_count == 0 and not n.is_entry_point]
    if type:
        node_type = NodeType(type.lower())
        dead_nodes = [n for n in dead_nodes if n.type == node_type]

    if not dead_nodes:
        console.print("[green]No dead code found[/green]")
        return

    by_file: dict[str, list] = {}
    for n in dead_nodes:
        if n.file not in by_file:
            by_file[n.file] = []
        by_file[n.file].append((n.name, n.type.value, n.line))

    for file, items in sorted(by_file.items()):
        table = Table(title=file, box=box.ROUNDED)
        table.add_column("Symbol", style="cyan")
        table.add_column("Type", style="magenta")
        table.add_column("Line", justify="right")
        for name, ntype, line in items:
            table.add_row(name, ntype, str(line))
        console.print(table)


@app.command()
def list(
    kind: str = typer.Argument(..., help="Type: functions, classes, variables, modules"),
    graph_path: str = typer.Option("sinew.json", "--graph", help="Path to sinew.json"),
    critical: bool = typer.Option(False, "--critical", help="Filter by critical"),
    deprecated: bool = typer.Option(False, "--deprecated", help="Filter by deprecated"),
    owner: Optional[str] = typer.Option(None, "--owner", help="Filter by owner"),
    group: Optional[str] = typer.Option(None, "--group", help="Filter by group"),
):
    """Print functions, classes, variables, or modules as a table."""
    graph = _load_graph_or_exit(graph_path)

    kind_lower = kind.lower()
    if kind_lower not in ("functions", "classes", "variables", "modules"):
        console.print(f"[red]Invalid type: {kind}. Use: functions, classes, variables, modules[/red]")
        raise typer.Exit(code=1)

    if kind_lower == "functions":
        items = graph.lists.functions
    elif kind_lower == "classes":
        items = graph.lists.classes
    elif kind_lower == "variables":
        items = graph.lists.variables
    else:
        items = graph.lists.modules

    filtered = []
    for item in items:
        if kind_lower in ("functions", "classes", "variables"):
            if critical and not getattr(item, "sinew_critical", False):
                continue
            if owner and getattr(item, "sinew_owner", None) != owner:
                continue
        filtered.append(item)

    if not filtered:
        console.print(f"[yellow]No {kind} found[/yellow]")
        return

    table = Table(title=f"{kind.title()}", box=box.ROUNDED)
    table.add_column("ID", style="cyan")
    table.add_column("File", style="green")
    table.add_column("Line", justify="right")

    if kind_lower in ("functions", "classes", "variables"):
        table.add_column("Has Tests", justify="center")
        if kind_lower == "functions":
            table.add_column("Hotspot", justify="center")

    for item in filtered[:50]:
        row = [getattr(item, "id", "") or "", getattr(item, "file", ""), str(getattr(item, "line", ""))]
        if kind_lower in ("functions", "classes", "variables"):
            row.append("✓" if getattr(item, "has_tests", False) else "")
            if kind_lower == "functions":
                row.append("🔥" if getattr(item, "is_hotspot", False) else "")
        table.add_row(*row)

    console.print(table)


@app.command()
def hotspots(
    graph_path: str = typer.Option("sinew.json", "--graph", help="Path to sinew.json"),
    top: int = typer.Option(10, "--top", help="Number of hotspots to show"),
):
    """Print top N hotspots sorted by incoming edge count."""
    graph = _load_graph_or_exit(graph_path)

    hotspots_list = sorted(
        graph.lists.hotspots,
        key=lambda h: h.incoming_edge_count,
        reverse=True
    )[:top]

    if not hotspots_list:
        console.print("[yellow]No hotspots found[/yellow]")
        return

    node_map = {n.id: n for n in graph.nodes}

    table = Table(title="Top Hotspots", box=box.ROUNDED)
    table.add_column("Symbol", style="cyan")
    table.add_column("Type", style="magenta")
    table.add_column("Callers", justify="right")
    table.add_column("Has Tests", justify="center")
    table.add_column("Owner", style="green")

    for h in hotspots_list:
        node = node_map.get(h.id)
        if node:
            owner = node.sinew.owner if node.sinew else ""
            risk = "🔥" * min(3, h.incoming_edge_count // 5)
            table.add_row(
                node.name,
                node.type.value,
                str(h.incoming_edge_count),
                "✓" if node.has_tests else "",
                owner + " " + risk
            )

    console.print(table)


@app.command()
def validate(
    path: str = typer.Argument("sinew.json", help="Path to sinew.json"),
    strict: bool = typer.Option(False, "--strict", help="Treat warnings as errors"),
):
    """Validate a sinew.json file."""
    result = validate_file(path, strict=strict)

    if result.passed:
        console.print(Panel(
            f"[bold green]Validation Passed[/bold green]\n"
            f"Errors: {len(result.errors)} | Warnings: {len(result.warnings)} | Info: {len(result.infos)}",
            title=path,
            border_style="green"
        ))
        raise typer.Exit(code=0)
    else:
        console.print(Panel(
            f"[bold red]Validation Failed[/bold red]\n\n" +
            "\n".join(f"[red]•[/red] {i.message}" for i in result.errors),
            title=path,
            border_style="red"
        ))
        raise typer.Exit(code=1)


@app.command()
def explain(
    file_path: str = typer.Argument(..., help="Source file path, e.g. auth/security.py"),
    graph_path: str = typer.Option("sinew.json", "--graph", help="Path to sinew.json"),
):
    """Explain a source file's relationship in the codebase."""
    graph = _load_graph_or_exit(graph_path)

    file_nodes = [n for n in graph.nodes if n.type == NodeType.FILE and n.file == file_path]
    if not file_nodes:
        console.print(f"[red]File '{file_path}' not found in graph[/red]")
        raise typer.Exit(code=1)

    file_node = file_nodes[0]

    imported_by_count = len(graph.indexes.reverse.get(file_node.id, []).imported_by)

    outgoing = [e.to_node for e in graph.edges if e.from_node == file_node.id and e.type == EdgeType.IMPORTS]
    outgoing_modules = set()
    for node_id in outgoing:
        node = next((n for n in graph.nodes if n.id == node_id), None)
        if node and node.type == NodeType.MODULE:
            outgoing_modules.add(node.name)

    child_nodes = [n for n in graph.nodes if n.file == file_path and n.id != file_node.id]
    call_edges = [e for e in graph.edges if e.from_node in [n.id for n in child_nodes] and e.type == EdgeType.CALLS]
    callee_counts: dict[str, int] = {}
    for e in call_edges:
        callee_counts[e.to_node] = callee_counts.get(e.to_node, 0) + 1
    most_called = max(callee_counts.items(), key=lambda x: x[1]) if callee_counts else None
    most_called_name = ""
    if most_called:
        called_node = next((n for n in graph.nodes if n.id == most_called[0]), None)
        if called_node:
            most_called_name = f"{called_node.name} ({most_called[1]} callers)"

    dead_funcs = len([n for n in child_nodes if n.type in (NodeType.FUNCTION, NodeType.METHOD) and n.incoming_edge_count == 0])

    circular_count = 0
    for e in graph.edges:
        if e.from_node == file_node.id and e.type == EdgeType.CALLS:
            if any(e2.from_node == e.to_node and e2.to_node == file_node.id for e2 in graph.edges):
                circular_count += 1

    low_confidence = len([e for e in graph.edges if e.from_node in [n.id for n in child_nodes] and e.confidence < 0.75])

    warnings = len([n for n in child_nodes if n.sinew and n.sinew.warnings])

    centrality = "HIGH" if imported_by_count > 5 else "MEDIUM" if imported_by_count > 2 else "LOW"
    centrality_color = {"HIGH": "green", "MEDIUM": "yellow", "LOW": "red"}[centrality]

    content = f"""[bold]File:[/bold] {file_path}
[bold]Centrality:[/bold] [{centrality_color}]{centrality}[/{centrality_color}] — imported by {imported_by_count} files
[bold]Outgoing deps:[/bold] {len(outgoing_modules)} modules ({", ".join(sorted(outgoing_modules)) if outgoing_modules else "none"})
[bold]Most-called fn:[/bold] {most_called_name or "none"}
[bold]Dead code:[/bold] {dead_funcs} functions with no callers
[bold]Circular deps:[/bold] {circular_count}
[bold]Confidence:[/bold] {low_confidence} edges below 0.75
[bold]Agent warnings:[/bold] {warnings}"""

    console.print(Panel(content, title=f"File Analysis: {file_path}", border_style="blue"))


@app.command()
def agent_boot(
    task: str = typer.Option(..., "--task", help="Task description"),
    graph_path: str = typer.Option("sinew.json", "--graph", help="Path to sinew.json"),
    tokens: int = typer.Option(800, "--tokens", help="Token budget"),
    resume: str | None = typer.Option(None, "--resume", help="Session ID to resume"),
):
    """Generate task-scoped agent boot payload."""
    graph = _load_graph_or_exit(graph_path)
    payload = generate_boot_payload(graph, task, tokens, resume)
    console.print_json(json.dumps(payload))


@app.command()
def context(
    query: str = typer.Argument(..., help="Task description"),
    graph_path: str = typer.Option("sinew.json", "--graph", help="Path to sinew.json"),
    tokens: int = typer.Option(4000, "--tokens", help="Token budget"),
):
    """Generate precision-scoped context payload within token budget."""
    graph = _load_graph_or_exit(graph_path)
    result = generate_context(graph, query, tokens)
    console.print_json(json.dumps(result))


@app.command()
def verify(
    file_path: str = typer.Argument(..., help="File to verify"),
    graph_path: str = typer.Option("sinew.json", "--graph", help="Path to sinew.json"),
):
    """Verify agent output against graph for hallucinations."""
    graph = _load_graph_or_exit(graph_path)
    code = Path(file_path).read_text(encoding="utf-8")
    result = verify_output(code, graph, Language.PYTHON)

    if result.passed:
        console.print(Panel(
            "[bold green]Verification Passed[/bold green]\nNo hallucinations or violations detected.",
            title="Verify Output",
            border_style="green"
        ))
    else:
        table = Table(title="Hallucinations & Violations", box=box.ROUNDED)
        table.add_column("Symbol", style="cyan")
        table.add_column("Kind", style="magenta")
        table.add_column("Line", justify="right")
        table.add_column("Issue", style="red")

        for h in result.hallucinations:
            table.add_row(h.symbol, h.kind, str(h.line), h.suggestion or "NOT FOUND")

        for fv in result.frozen_violations:
            table.add_row(fv, "frozen", "", "VIOLATION")

        console.print(table)
        console.print(f"[bold red]{len(result.hallucinations)} hallucinations, {len(result.frozen_violations)} frozen violations[/bold red]")

    raise typer.Exit(code=0 if result.passed else 1)


territory_app = typer.Typer(help="Manage agent territories")


@territory_app.command()
def claim(
    agent: str = typer.Option(..., "--agent", help="Agent ID"),
    scope: str = typer.Option(..., "--scope", help="File or folder path"),
    task: str = typer.Option(..., "--task", help="Task description"),
    graph_path: str = typer.Option("sinew.json", "--graph", help="Path to sinew.json"),
):
    """Claim territory for an agent."""
    graph = _load_graph_or_exit(graph_path)
    repo_root = Path(graph_path).parent
    tm = TerritoryMap(repo_root)
    result = tm.claim(agent, scope, task, graph)

    if result.success:
        console.print(Panel(
            f"[bold green]Territory Claimed[/bold green]\nAgent: {agent}\nScope: {scope}",
            border_style="green"
        ))
    else:
        for conflict in result.conflicts:
            console.print(Panel(
                f"[bold red]Territory Conflict[/bold red]\n"
                f"Other agent: {conflict.other_agent}\n"
                f"Other scope: {conflict.other_scope}\n"
                f"Shared nodes: {', '.join(conflict.shared_nodes[:3])}\n"
                f"Recommendation: {conflict.recommendation}",
                border_style="red"
            ))
    raise typer.Exit(code=0 if result.success else 1)


@territory_app.command()
def status(
    graph_path: str = typer.Option("sinew.json", "--graph", help="Path to sinew.json"),
):
    """Show all active agent territories."""
    repo_root = Path(graph_path).parent
    tm = TerritoryMap(repo_root)
    claims = tm.status()

    if not claims:
        console.print("[yellow]No active territories[/yellow]")
        return

    table = Table(title="Active Territories", box=box.ROUNDED)
    table.add_column("Agent", style="cyan")
    table.add_column("Scope", style="green")
    table.add_column("Task", style="magenta")

    for claim in claims:
        table.add_row(claim.get("agent_id", ""), claim.get("scope", ""), claim.get("task", ""))

    console.print(table)


@territory_app.command()
def release(
    agent: str = typer.Option(..., "--agent", help="Agent ID"),
    graph_path: str = typer.Option("sinew.json", "--graph", help="Path to sinew.json"),
):
    """Release territory on task completion."""
    repo_root = Path(graph_path).parent
    tm = TerritoryMap(repo_root)
    tm.release(agent)
    console.print(Panel(
        f"[bold green]Territory Released[/bold green]\nAgent: {agent}",
        border_style="green"
    ))


app.add_typer(territory_app, name="territory")


@app.command()
def agent_log(
    node: str = typer.Option(..., "--node", help="Node ID to log warning for"),
    description: str = typer.Option(..., "--description", help="Warning description"),
    severity: str = typer.Option(..., "--severity", help="Severity: low, medium, high, critical"),
    graph_path: str = typer.Option("sinew.json", "--graph", help="Path to sinew.json"),
    only_mistake: bool = typer.Option(False, "--only-mistake", help="Only show mistake logs"),
):
    """Add an agent warning to a node."""
    graph = _load_graph_or_exit(graph_path)

    target_node = graph.get_node(node)
    if not target_node:
        console.print(f"[red]Node '{node}' not found[/red]")
        raise typer.Exit(code=1)

    try:
        severity_enum = WarningSeverity(severity.lower())
    except ValueError:
        console.print(f"[red]Invalid severity: {severity}. Use: low, medium, high, critical[/red]")
        raise typer.Exit(code=1)

    warning = AgentWarning(
        id=f"warn-{datetime.now().timestamp()}",
        description=description,
        severity=severity_enum,
        logged_at=datetime.now(),
        logged_by="cli",
    )

    if target_node.agent_warnings is None:
        target_node.agent_warnings = []
    target_node.agent_warnings.append(warning)

    output_path = Path(graph_path)
    output_path.write_text(graph.to_json(), encoding="utf-8")

    console.print(Panel(
        f"[bold green]Warning Logged[/bold green]\nNode: {node}\nSeverity: {severity}",
        border_style="green"
    ))


@app.command()
def serve(
    port: int = typer.Option(2048, "--port", help="Port for MCP server"),
    graph: str = typer.Option("sinew.json", "--graph", help="Path to sinew.json"),
):
    """Start the Sinew MCP server."""
    run_server(graph_path=graph, port=port)


if __name__ == "__main__":
    app()
