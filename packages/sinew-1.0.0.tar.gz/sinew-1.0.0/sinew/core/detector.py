"""
Language detection utilities.

Responsibilities:
- Detect programming language from file extension
- Provide list of supported extensions

Key Functions:
- detect(file_path: Path) -> Language | None:
    Detect language from file extension.
  
- is_supported(file_path: Path) -> bool:
    Check if file extension is supported.
  
- supported_extensions() -> list[str]:
    Get list of all supported file extensions.
"""

from __future__ import annotations

from pathlib import Path

from sinew.schema.models import Language


EXTENSION_TO_LANGUAGE: dict[str, Language] = {
    ".py": Language.PYTHON,
    ".js": Language.JAVASCRIPT,
    ".mjs": Language.JAVASCRIPT,
    ".cjs": Language.JAVASCRIPT,
    ".ts": Language.TYPESCRIPT,
    ".mts": Language.TYPESCRIPT,
    ".tsx": Language.TYPESCRIPT,
    ".jsx": Language.JAVASCRIPT,
    ".java": Language.JAVA,
    ".go": Language.GO,
    ".rs": Language.RUST,
    ".cpp": Language.CPP,
    ".cc": Language.CPP,
    ".cxx": Language.CPP,
    ".hpp": Language.CPP,
    ".h": Language.CPP,
    ".cs": Language.CSHARP,
    ".php": Language.PHP,
    ".swift": Language.SWIFT,
}


class LanguageDetector:
    @staticmethod
    def detect(file_path: Path) -> Language | None:
        ext = file_path.suffix.lower()
        return EXTENSION_TO_LANGUAGE.get(ext)

    @staticmethod
    def is_supported(file_path: Path) -> bool:
        return file_path.suffix.lower() in EXTENSION_TO_LANGUAGE

    @staticmethod
    def supported_extensions() -> list[str]:
        return list(EXTENSION_TO_LANGUAGE.keys())
