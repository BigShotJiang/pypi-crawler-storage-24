"""
Configuration management for Sinew.

Responsibilities:
- Load and parse .sinewconfig file
- Provide configuration defaults
- Handle ignore patterns

Key Functions:
- sinewConfig: Main configuration dataclass
- load_config(repo_root: Path) -> sinewConfig:
    Load configuration from repository root.
"""

from __future__ import annotations

import toml
from dataclasses import dataclass, field
from pathlib import Path

import pathspec


DEFAULT_IGNORE_DIRECTORIES = [
    "__pycache__",
    ".venv",
    "venv",
    "env",
    "node_modules",
    ".git",
    "dist",
    "build",
    ".next",
    ".nuxt",
    ".pytest_cache",
    ".mypy_cache",
    ".egg-info",
    "coverage",
    ".tox",
    ".hg",
    ".svn",
]


@dataclass
class sinewConfig:
    languages: list[str] = field(default_factory=lambda: ["python"])
    output: str = "sinew.json"
    confidence_threshold: float = 0.75
    entry_points: list[str] = field(default_factory=list)
    ignore_directories: list[str] = field(default_factory=lambda: DEFAULT_IGNORE_DIRECTORIES.copy())
    ignore_files: list[str] = field(default_factory=list)
    ignore_custom: list[str] = field(default_factory=list)
    boot_token_budget: int = 800
    context_token_budget: int = 4000
    mistake_memory: bool = True
    territory_map: bool = True

    _ignore_patterns: pathspec.PathSpec = field(default=None, repr=False)

    @classmethod
    def from_repo(cls, repo_root: Path) -> sinewConfig:
        config_file = repo_root / ".sinewconfig"
        ignore_file = repo_root / ".sinewignore"

        config = cls()

        if config_file.exists():
            try:
                data = toml.load(config_file)
                sinew_data = data.get("sinew", {})

                if "languages" in sinew_data:
                    config.languages = sinew_data["languages"]
                if "output" in sinew_data:
                    config.output = sinew_data["output"]
                if "confidence_threshold" in sinew_data:
                    config.confidence_threshold = sinew_data["confidence_threshold"]
                if "entry_points" in sinew_data:
                    config.entry_points = sinew_data["entry_points"]
                if "ignore_directories" in sinew_data:
                    config.ignore_directories = sinew_data["ignore_directories"]
                if "ignore_files" in sinew_data:
                    config.ignore_files = sinew_data["ignore_files"]
                if "ignore_custom" in sinew_data:
                    config.ignore_custom = sinew_data["ignore_custom"]
                if "boot_token_budget" in sinew_data:
                    config.boot_token_budget = sinew_data["boot_token_budget"]
                if "context_token_budget" in sinew_data:
                    config.context_token_budget = sinew_data["context_token_budget"]
                if "mistake_memory" in sinew_data:
                    config.mistake_memory = sinew_data["mistake_memory"]
                if "territory_map" in sinew_data:
                    config.territory_map = sinew_data["territory_map"]
            except Exception:
                pass

        patterns = []

        for dir_name in config.ignore_directories:
            patterns.append(f"{dir_name}/")
            patterns.append(f"*/{dir_name}/")
            patterns.append(f"*/{dir_name}")

        for file_name in config.ignore_files:
            patterns.append(file_name)
            patterns.append(f"*/{file_name}")

        for custom_pattern in config.ignore_custom:
            patterns.append(custom_pattern)

        if ignore_file.exists():
            try:
                with open(ignore_file, "r", encoding="utf-8") as f:
                    for line in f:
                        line = line.strip()
                        if line and not line.startswith("#"):
                            patterns.append(line)
            except Exception:
                pass

        config._ignore_patterns = pathspec.PathSpec.from_lines(
            "gitwildmatch", patterns
        )

        return config

    def should_ignore(self, path: Path, repo_root: Path) -> bool:
        if self._ignore_patterns is None:
            return False

        try:
            rel_path = path.relative_to(repo_root)
        except ValueError:
            rel_path = path

        path_str = str(rel_path)
        if path.is_dir():
            path_str += "/"

        if self._ignore_patterns.match_file(path_str):
            return True

        parts = rel_path.parts if not isinstance(rel_path, str) else Path(path_str).parts
        for part in parts:
            if part in self.ignore_directories:
                return True
            if part.endswith(".egg-info"):
                return True

        return False
