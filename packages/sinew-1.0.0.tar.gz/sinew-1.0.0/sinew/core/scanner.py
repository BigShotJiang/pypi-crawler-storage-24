"""
File system scanner for discovering source files.

Responsibilities:
- Recursively scan repository for source files
- Filter files based on language and ignore patterns
- Detect file languages using LanguageDetector

Key Functions:
- scan(repo_root: Path, config: sinewConfig) -> list[ScannedFile]:
    Scan repository and return all discoverable source files.
  
- scan_file(file_path: Path, repo_root: Path, config: sinewConfig) -> ScannedFile | None:
    Scan a single file and return its metadata if valid.

Implementation Notes:
- Respects ignore patterns from config
- Skips files larger than 5MB
- Returns relative paths for discovered files
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from pathlib import Path

from sinew.core.config import sinewConfig
from sinew.core.detector import LanguageDetector
from sinew.schema.models import Language


logger = logging.getLogger(__name__)

MAX_FILE_SIZE = 5 * 1024 * 1024


@dataclass
class ScannedFile:
    path: Path
    relative_path: str
    language: Language
    size_bytes: int


class FileScanner:
    @staticmethod
    def scan(repo_root: Path, config: sinewConfig) -> list[ScannedFile]:
        scanned_files: list[ScannedFile] = []

        for file_path in repo_root.rglob("*"):
            if file_path.is_dir():
                continue

            scanned = FileScanner.scan_file(file_path, repo_root, config)
            if scanned:
                scanned_files.append(scanned)

        scanned_files.sort(key=lambda f: f.relative_path)
        return scanned_files

    @staticmethod
    def scan_file(file_path: Path, repo_root: Path, config: sinewConfig) -> ScannedFile | None:
        if config.should_ignore(file_path, repo_root):
            return None

        if not file_path.is_file():
            return None

        try:
            size_bytes = file_path.stat().st_size
        except OSError:
            return None

        if size_bytes > MAX_FILE_SIZE:
            logger.warning(f"Skipping large file ({size_bytes} bytes): {file_path}")
            return None

        language = LanguageDetector.detect(file_path)
        if language is None:
            return None

        if language.value not in config.languages:
            return None

        try:
            rel_path = file_path.relative_to(repo_root)
            relative_path = rel_path.as_posix()
        except ValueError:
            relative_path = str(file_path)

        return ScannedFile(
            path=file_path,
            relative_path=relative_path,
            language=language,
            size_bytes=size_bytes,
        )
