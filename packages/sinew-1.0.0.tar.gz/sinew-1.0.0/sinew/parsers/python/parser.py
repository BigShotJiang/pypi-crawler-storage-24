"""
Python source code parser using tree-sitter.

Responsibilities:
- Parse Python source files into nodes and edges
- Extract functions, classes, variables, imports
- Build call graph edges from function calls

Key Functions:
- PythonParser.parse_file() -> ParsedFile:
    Parse a Python file and return nodes and edges.
"""

from __future__ import annotations

import time
from pathlib import Path
from typing import Any

from tree_sitter import Language, Parser
import tree_sitter_python as python_language

from sinew.parsers.base import BaseParser, ParsedFile
from sinew.schema.models import (
    Language as ModelLanguage,
    Node,
    NodeType,
    Edge,
    EdgeType,
    Origin,
    Parameter,
    ControlFlow,
    ControlFlowType,
    sinewAnnotation,
)


STDLIB_MODULES = {
    "os", "sys", "re", "json", "typing", "collections", "itertools",
    "functools", "operator", "string", "datetime", "time", "calendar",
    "io", "pickle", "copy", "pprint", "math", "random", "hashlib",
    "base64", "binascii", "struct", "codecs", "unicodedata", "locale",
    "gettext", "warnings", "dataclasses", "abc", "contextlib",
    "abc", "ast", "dis", "inspect", "traceback", "gc", "weakref",
    "types", "copyreg", "linecache", "tokenize", "keyword", "astor",
    "symbol", "random", "statistics", "decimal", "fractions",
    "numbers", "cmath", "array", "bisect", "graphlib", "heapq",
    "queue", "threading", "multiprocessing", "concurrent", "asyncio",
    "subprocess", "socket", "ssl", "select", "selectors", "signal",
    "mmap", "email", "json", "mailbox", "smtplib", "ftplib",
    "http", "urllib", "html", "xml", "csv", "configparser", "toml",
    "logging", "logging.config", "logging.handlers", "hashlib",
    "hmac", "secrets", "ssl", "textwrap", "unicodedata", "stringprep",
}


class PythonParser(BaseParser):
    @property
    def language(self) -> ModelLanguage:
        return ModelLanguage.PYTHON

    @property
    def file_extensions(self) -> list[str]:
        return [".py"]

    def parse_file(self, file_path: str, repo_root: Path | None = None) -> ParsedFile:
        start_time = time.perf_counter()

        abs_path = Path(file_path)
        if not abs_path.exists():
            abs_path = Path(file_path)

        if repo_root is not None:
            try:
                rel_path = abs_path.relative_to(repo_root)
                file_path_for_nodes = str(rel_path)
            except ValueError:
                file_path_for_nodes = str(abs_path)
        else:
            file_path_for_nodes = str(abs_path)

        try:
            content = abs_path.read_text(encoding="utf-8")
        except Exception as e:
            return ParsedFile(
                file_path=file_path,
                language=self.language,
                errors=[f"Failed to read file: {e}"],
            )

        try:
            parser = Parser(Language(python_language.language()))
            tree = parser.parse(bytes(content, "utf8"))
        except Exception as e:
            return ParsedFile(
                file_path=file_path,
                language=self.language,
                errors=[f"Failed to parse: {e}"],
            )

        nodes: list[Node] = []
        edges: list[Edge] = []
        errors: list[str] = []

        try:
            file_node, file_edges, import_count, export_count = self._parse_module(
                abs_path, file_path_for_nodes, content, tree, repo_root
            )
            nodes.append(file_node)
            edges.extend(file_edges)

            import_nodes, import_edges = self._parse_imports(abs_path, file_path_for_nodes, content, tree, file_node.id)
            nodes.extend(import_nodes)
            edges.extend(import_edges)

            class_nodes, class_edges = self._parse_classes(
                abs_path, file_path_for_nodes, content, tree, file_node.id
            )
            nodes.extend(class_nodes)
            edges.extend(class_edges)

            func_nodes, func_edges = self._parse_functions(
                abs_path, file_path_for_nodes, content, tree, file_node.id, class_nodes
            )
            nodes.extend(func_nodes)
            edges.extend(func_edges)

            var_nodes, var_edges = self._parse_variables(
                abs_path, file_path_for_nodes, content, tree, file_node.id, class_nodes
            )
            nodes.extend(var_nodes)
            edges.extend(var_edges)

            call_edges = self._parse_calls(content, tree, nodes)
            edges.extend(call_edges)

            dec_nodes, dec_edges = self._parse_decorators(content, tree, nodes)
            nodes.extend(dec_nodes)
            edges.extend(dec_edges)

            cf_edges = self._parse_control_flow(content, tree, nodes)
            edges.extend(cf_edges)

            self._parse_sinew_schema(content, tree, nodes, errors)

            self._parse_docstrings(content, tree, nodes)

            file_node.children = [n.id for n in nodes if n.id != file_node.id and n.parent is None]
            file_node.import_count = import_count
            file_node.export_count = export_count

        except Exception as e:
            errors.append(f"Parse error: {e}")

        parse_time_ms = (time.perf_counter() - start_time) * 1000

        return ParsedFile(
            file_path=file_path,
            language=self.language,
            nodes=nodes,
            edges=edges,
            errors=errors,
            parse_time_ms=parse_time_ms,
        )

    def _get_file_id(self, file_path: Path, repo_root: Path | None = None) -> str:
        stem = file_path.stem
        if repo_root:
            try:
                rel_path = file_path.relative_to(repo_root)
                parts = rel_path.parts[:-1]
                if parts:
                    return ".".join([*parts, stem]).replace("-", "_")
                return stem
            except ValueError:
                pass
        parts = file_path.parts
        if len(parts) > 1:
            return ".".join([*parts[:-1], stem]).replace("-", "_")
        return stem

    def _get_line(self, node: Any, source: bytes) -> int:
        return node.start_point[0] + 1

    def _get_line_end(self, node: Any, source: bytes) -> int:
        return node.end_point[0] + 1

    def _get_text(self, node: Any, source: bytes) -> str:
        return source[node.start_byte : node.end_byte].decode("utf-8")

    def _parse_module(
        self, file_path: Path, rel_file_path: str, content: str, tree: Any, repo_root: Path | None = None
    ) -> tuple[Node, list[Edge], int, int]:
        source = content.encode("utf-8")
        file_id = self._get_file_id(file_path, repo_root)

        root = tree.root_node
        import_count = 0
        export_count = 0

        for child in root.children:
            if child.type == "import_statement":
                import_count += 1
            elif child.type == "import_from_statement":
                import_count += 1

        for child in root.children:
            if child.type == "expression_statement":
                export_count += 1

        file_node = Node(
            id=file_id,
            type=NodeType.FILE,
            name=file_path.name,
            qualified_name=file_id,
            language=ModelLanguage.PYTHON,
            file=rel_file_path,
            line=1,
            line_end=len(content.splitlines()),
            origin=Origin(file=rel_file_path, line=1, is_same_as_definition=True),
            children=[],
            import_count=0,
            export_count=0,
        )

        return file_node, [], import_count, export_count

    def _parse_imports(
        self, file_path: Path, rel_file_path: str, content: str, tree: Any, file_id: str
    ) -> tuple[list[Node], list[Edge]]:
        nodes: list[Node] = []
        edges: list[Edge] = []
        source = content.encode("utf-8")
        root = tree.root_node

        for child in root.children:
            if child.type in ("import_statement", "import_from_statement"):
                module_name = self._get_import_module_name(child, source)
                if not module_name or not module_name.strip():
                    continue

                module_id = module_name.split(".")[0]
                if not module_id or not module_id.strip():
                    continue

                module_node = Node(
                    id=module_id,
                    type=NodeType.MODULE,
                    name=module_id,
                    qualified_name=module_id,
                    language=ModelLanguage.PYTHON,
                    file=rel_file_path,
                    line=self._get_line(child, source),
                    line_end=self._get_line_end(child, source),
                    origin=Origin(
                        file=rel_file_path,
                        line=self._get_line(child, source),
                        is_same_as_definition=True,
                    ),
                    is_external=False,
                    is_stdlib=module_id in STDLIB_MODULES,
                )

                existing = [n for n in nodes if n.id == module_id]
                if not existing:
                    nodes.append(module_node)

                edge = Edge(
                    id=f"{file_id}__imports__{module_id}",
                    from_node=file_id,
                    to_node=module_id,
                    type=EdgeType.IMPORTS,
                    file=rel_file_path,
                    line=self._get_line(child, source),
                    confidence=0.99,
                    is_inferred=False,
                )
                edges.append(edge)

        return nodes, edges

    def _get_import_module_name(self, node: Any, source: bytes) -> str | None:
        if node.type == "import_statement":
            for child in node.children:
                if child.type == "dotted_name":
                    return self._get_text(child, source)
        elif node.type == "import_from_statement":
            for child in node.children:
                if child.type == "dotted_name":
                    return self._get_text(child, source)
                elif child.type == "relative_import":
                    return self._get_text(child, source)
        return None

    def _parse_classes(
        self, file_path: Path, rel_file_path: str, content: str, tree: Any, file_id: str
    ) -> tuple[list[Node], list[Edge]]:
        nodes: list[Node] = []
        edges: list[Edge] = []
        source = content.encode("utf-8")
        root = tree.root_node

        classes = self._find_nodes(root, "class_definition")

        for cls in classes:
            class_name = None
            base_classes: list[str] = []
            is_abstract = False

            for child in cls.children:
                if child.type == "identifier":
                    class_name = self._get_text(child, source)
                elif child.type == "argument_list":
                    for arg in child.children:
                        if arg.type == "attribute":
                            base_name = self._get_text(arg, source)
                            base_classes.append(base_name)
                        elif arg.type == "identifier":
                            base_name = self._get_text(arg, source)
                            if base_name == "ABC":
                                is_abstract = True
                            base_classes.append(base_name)

            if not class_name:
                continue

            class_id = f"{file_id}.{class_name}"

            class_node = Node(
                id=class_id,
                type=NodeType.CLASS,
                name=class_name,
                qualified_name=class_id,
                language=ModelLanguage.PYTHON,
                file=rel_file_path,
                line=self._get_line(cls, source),
                line_end=self._get_line_end(cls, source),
                origin=Origin(
                    file=rel_file_path,
                    line=self._get_line(cls, source),
                    is_same_as_definition=True,
                ),
                parent=file_id,
                base_classes=base_classes if base_classes else None,
                is_abstract=is_abstract if is_abstract else None,
                methods=[],
                properties=[],
            )

            nodes.append(class_node)

            for base in base_classes:
                edge = Edge(
                    id=f"{class_id}__inherits__{base}",
                    from_node=class_id,
                    to_node=base,
                    type=EdgeType.INHERITS,
                    file=rel_file_path,
                    line=self._get_line(cls, source),
                    confidence=0.99,
                    is_inferred=False,
                )
                edges.append(edge)

        return nodes, edges

    def _parse_functions(
        self, file_path: Path, rel_file_path: str, content: str, tree: Any, file_id: str, classes: list[Node]
    ) -> tuple[list[Node], list[Edge]]:
        nodes: list[Node] = []
        edges: list[Edge] = []
        source = content.encode("utf-8")
        root = tree.root_node

        functions = self._find_nodes(root, "function_definition")
        async_functions = self._find_nodes(root, "async_function_definition")

        all_functions = functions + async_functions

        for func in all_functions:
            func_name = None
            params: list[Parameter] = []
            return_type: str | None = None
            decorators: list[str] = []
            raises: list[str] = []
            is_async = func.type == "async_function_definition"

            for child in func.children:
                if child.type == "identifier":
                    func_name = self._get_text(child, source)
                elif child.type == "parameters":
                    params = self._parse_parameters(child, source)
                elif child.type == "type" or (child.type == "annotation" and child.parent.type == "function_definition"):
                    ann = child
                    if ann.type == "type":
                        return_type = self._get_text(ann, source)
                    else:
                        for c in ann.children:
                            if c.type == "type":
                                return_type = self._get_text(c, source)
                elif child.type == "decorator":
                    dec_name = self._get_text(child, source).lstrip("@")
                    decorators.append(dec_name)

            if not func_name:
                continue

            parent_class = self._find_parent_class(func, classes, source)
            if parent_class:
                func_id = f"{parent_class.id}.{func_name}"
                node_type = NodeType.METHOD
                parent_id = parent_class.id
            else:
                func_id = f"{file_id}.{func_name}"
                node_type = NodeType.FUNCTION
                parent_id = file_id

            func_node = Node(
                id=func_id,
                type=node_type,
                name=func_name,
                qualified_name=func_id,
                language=ModelLanguage.PYTHON,
                file=rel_file_path,
                line=self._get_line(func, source),
                line_end=self._get_line_end(func, source),
                origin=Origin(
                    file=rel_file_path,
                    line=self._get_line(func, source),
                    is_same_as_definition=True,
                ),
                parent=parent_id,
                parameters=params if params else None,
                return_type=return_type,
                is_async=is_async if is_async else None,
                decorators=decorators if decorators else None,
                raises=raises if raises else None,
            )

            nodes.append(func_node)

            if parent_class:
                if parent_class.methods is None:
                    parent_class.methods = []
                parent_class.methods.append(func_id)

        return nodes, edges

    def _parse_parameters(self, node: Any, source: bytes) -> list[Parameter]:
        params: list[Parameter] = []
        pos = 0

        for child in node.children:
            if child.type == "parameter":
                name = None
                type_annotation = None

                for c in child.children:
                    if c.type == "identifier":
                        name = self._get_text(c, source)
                    elif c.type == "type":
                        type_annotation = self._get_text(c, source)

                if name:
                    params.append(
                        Parameter(
                            name=name,
                            type_annotation=type_annotation,
                            position=pos,
                        )
                    )
                    pos += 1
            elif child.type == "typed_parameter":
                name = None
                type_annotation = None

                for c in child.children:
                    if c.type == "identifier":
                        name = self._get_text(c, source)
                    elif c.type == "type":
                        type_annotation = self._get_text(c, source)

                if name:
                    params.append(
                        Parameter(
                            name=name,
                            type_annotation=type_annotation,
                            position=pos,
                        )
                    )
                    pos += 1

        return params

    def _find_parent_class(self, node: Any, classes: list[Node], source: bytes) -> Node | None:
        current = node.parent
        while current:
            if current.type == "class_definition":
                for cls in classes:
                    cls_line = self._get_line(current, source)
                    if cls.line == cls_line:
                        return cls
            current = current.parent
        return None

    def _parse_variables(
        self, file_path: Path, rel_file_path: str, content: str, tree: Any, file_id: str, classes: list[Node]
    ) -> tuple[list[Node], list[Edge]]:
        nodes: list[Node] = []
        edges: list[Edge] = []
        source = content.encode("utf-8")
        root = tree.root_node

        assignments = self._find_nodes(root, "assignment")

        for assign in assignments:
            var_name = None
            value_type: str | None = None
            is_constant = False

            for child in assign.children:
                if child.type == "identifier":
                    var_name = self._get_text(child, source)
                elif child.type == "type":
                    value_type = self._get_text(child, source)

            if not var_name or var_name.startswith("_"):
                continue

            is_constant = var_name.isupper()

            parent_class = self._find_parent_class(assign, classes, source)
            if parent_class:
                var_id = f"{parent_class.id}.{var_name}"
                parent_id = parent_class.id
            else:
                var_id = f"{file_id}.{var_name}"
                parent_id = file_id

            var_node = Node(
                id=var_id,
                type=NodeType.VARIABLE,
                name=var_name,
                qualified_name=var_id,
                language=ModelLanguage.PYTHON,
                file=rel_file_path,
                line=self._get_line(assign, source),
                line_end=self._get_line_end(assign, source),
                origin=Origin(
                    file=rel_file_path,
                    line=self._get_line(assign, source),
                    is_same_as_definition=True,
                ),
                parent=parent_id,
                is_constant=is_constant if is_constant else None,
                is_global=True if not parent_class else None,
                value_type=value_type,
            )

            nodes.append(var_node)

            if parent_class:
                if parent_class.properties is None:
                    parent_class.properties = []
                parent_class.properties.append(var_id)

        return nodes, edges

    def _parse_calls(self, content: str, tree: Any, nodes: list[Node]) -> list[Edge]:
        edges: list[Edge] = []
        source = content.encode("utf-8")
        root = tree.root_node

        calls = self._find_nodes(root, "call")

        node_map = {n.id: n for n in nodes}

        for call in calls:
            func_node = None
            caller_node = None

            search_node = call.parent
            while search_node:
                if search_node.type in ("function_definition", "async_function_definition"):
                    for n in nodes:
                        if n.line == self._get_line(search_node, source):
                            caller_node = n
                            break
                    break
                search_node = search_node.parent

            if not caller_node:
                continue

            for child in call.children:
                if child.type == "attribute":
                    method_name = None
                    for c in child.children:
                        if c.type == "identifier":
                            method_name = self._get_text(c, source)
                            break

                    if method_name and caller_node.parent:
                        callee_id = f"{caller_node.parent}.{method_name}"
                        if callee_id in node_map:
                            func_node = node_map[callee_id]
                            break
                elif child.type == "identifier":
                    func_name = self._get_text(child, source)
                    for n in nodes:
                        if n.name == func_name and n.type in (NodeType.FUNCTION, NodeType.METHOD):
                            func_node = n
                            break

            if func_node and func_node.id != caller_node.id:
                confidence = 0.97
                is_inferred = False
                is_dynamic = False

                if confidence < 0.90:
                    is_inferred = True
                if confidence < 0.80:
                    is_dynamic = True

                edge = Edge(
                    id=f"{caller_node.id}__calls__{func_node.id}",
                    from_node=caller_node.id,
                    to_node=func_node.id,
                    type=EdgeType.CALLS,
                    file=caller_node.file,
                    line=self._get_line(call, source),
                    confidence=confidence,
                    is_inferred=is_inferred,
                    is_dynamic=is_dynamic,
                )
                edges.append(edge)

        return edges

    def _parse_decorators(
        self, content: str, tree: Any, nodes: list[Node]
    ) -> tuple[list[Node], list[Edge]]:
        dec_nodes: list[Node] = []
        edges: list[Edge] = []
        source = content.encode("utf-8")

        node_map = {n.id: n for n in nodes}

        for node in nodes:
            if node.decorators:
                for dec_name in node.decorators:
                    dec_id = f"decorator.{dec_name}"

                    existing = [d for d in dec_nodes if d.id == dec_id]
                    if not existing:
                        dec_node = Node(
                            id=dec_id,
                            type=NodeType.DECORATOR,
                            name=dec_name,
                            qualified_name=dec_id,
                            language=ModelLanguage.PYTHON,
                            file=node.file,
                            line=node.line,
                            line_end=node.line,
                            origin=Origin(
                                file=node.file,
                                line=node.line,
                                is_same_as_definition=True,
                            ),
                        )
                        dec_nodes.append(dec_node)

                    edge = Edge(
                        id=f"{dec_id}__decorates__{node.id}",
                        from_node=dec_id,
                        to_node=node.id,
                        type=EdgeType.DECORATES,
                        file=node.file,
                        line=node.line,
                        confidence=0.99,
                        is_inferred=False,
                    )
                    edges.append(edge)

        return dec_nodes, edges

    def _parse_control_flow(self, content: str, tree: Any, nodes: list[Node]) -> list[Edge]:
        edges: list[Edge] = []
        source = content.encode("utf-8")

        return edges

    def _parse_sinew_schema(
        self, content: str, tree: Any, nodes: list[Node], errors: list[str]
    ) -> None:
        lines = content.splitlines()
        source = content.encode("utf-8")

        for i, line in enumerate(lines):
            if "# @sinew:" not in line:
                continue

            annotation_str = line.split("# @sinew:")[1].strip()
            annotation = self._parse_annotation(annotation_str)

            if annotation.ignore:
                continue

            if annotation.frozen and not annotation.frozen_reason:
                errors.append(
                    f"Warning: Node at line {i+1} has sinew.frozen=True but no frozen_reason"
                )

            for node in nodes:
                if node.line == i + 1 or node.line == i + 2:
                    node.sinew = annotation
                    break

    def _parse_annotation(self, annotation_str: str) -> sinewAnnotation:
        kwargs: dict[str, Any] = {}

        parts = annotation_str.split()
        for part in parts:
            if "=" not in part:
                continue

            key, value = part.split("=", 1)
            key = key.strip()
            value = value.strip()

            if value == "true":
                kwargs[key] = True
            elif value == "false":
                kwargs[key] = False
            elif value.startswith('"') and value.endswith('"'):
                kwargs[key] = value[1:-1]
            elif value.startswith("'") and value.endswith("'"):
                kwargs[key] = value[1:-1]
            else:
                kwargs[key] = value

        return sinewAnnotation(**kwargs)

    def _parse_docstrings(self, content: str, tree: Any, nodes: list[Node]) -> None:
        lines = content.splitlines()
        source = content.encode("utf-8")

        for node in nodes:
            if node.line <= 0 or node.line > len(lines):
                continue

            line_idx = node.line - 1

            if line_idx > 0 and '"""' in lines[line_idx - 1] or "'''" in lines[line_idx - 1]:
                docstring_lines = []
                start_idx = line_idx - 1
                quote_char = '"""' if '"""' in lines[start_idx] else "'''"

                for j in range(start_idx + 1, len(lines)):
                    if quote_char in lines[j]:
                        docstring_lines.append(lines[j].split(quote_char)[0])
                        break
                    docstring_lines.append(lines[j])

                if docstring_lines:
                    node.notes = "\n".join(docstring_lines).strip()

    def _find_nodes(self, node: Any, node_type: str) -> list[Any]:
        result = []
        if node.type == node_type:
            result.append(node)
        for child in node.children:
            result.extend(self._find_nodes(child, node_type))
        return result
