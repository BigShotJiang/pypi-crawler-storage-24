"""
Base parser interface for all language-specific parsers.

This module defines the abstract base class that all language parsers must
implement, along with the ParsedFile dataclass that serves as the standard
return type for all parsing operations.

All parsers must inherit from BaseParser and implement:
- language property: Language enum value indicating the language this parser handles
- file_extensions property: List of supported file extensions (e.g., ['.py', '.pyi'])
- parse_file method: Parse a file and return ParsedFile with extracted nodes and edges

The ParsedFile dataclass is the standard return type for all parsers and contains:
- file_path: Path to the parsed file (relative to repo root)
- language: Language enum value (PYTHON, JAVASCRIPT, etc.)
- nodes: List of Node objects extracted from the file
- edges: List of Edge objects representing relationships
- errors: List of error messages encountered during parsing
- parse_time_ms: Time taken to parse the file in milliseconds

Example usage:
    parser = PythonParser()
    if parser.can_parse("auth/security.py"):
        result = parser.parse_file("auth/security.py")
        if result.errors:
            log_errors(result.errors)
        graph.add_nodes(result.nodes)
        graph.add_edges(result.edges)
"""

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import List

from sinew.schema.models import Node, Edge, Language


@dataclass
class ParsedFile:
    """
    Result of parsing a single source file.
    
    This dataclass encapsulates all information extracted from parsing a source
    file, including the nodes (code symbols), edges (relationships), any errors
    encountered, and performance metrics.
    
    Attributes:
        file_path: Path to the parsed file (relative to repo root)
        language: Language enum value (PYTHON, JAVASCRIPT, TYPESCRIPT, etc.)
        nodes: List of Node objects extracted from the file (functions, classes, etc.)
        edges: List of Edge objects representing relationships (calls, imports, etc.)
        errors: List of error messages encountered during parsing
        parse_time_ms: Time taken to parse the file in milliseconds
    """
    file_path: str
    language: Language
    nodes: List[Node] = field(default_factory=list)
    edges: List[Edge] = field(default_factory=list)
    errors: List[str] = field(default_factory=list)
    parse_time_ms: float = 0.0


class BaseParser(ABC):
    """
    Abstract base class for all language parsers.
    
    This class defines the contract that all language-specific parsers must
    implement. Subclasses must provide implementations for the language property,
    file_extensions property, and parse_file method.
    
    The can_parse method is provided as a convenience and checks if the file
    extension matches any of the parser's supported extensions.
    
    Subclasses must implement:
        - language: Return the Language enum value this parser handles
        - file_extensions: Return list of file extensions (e.g., ['.py', '.pyi'])
        - parse_file: Parse a file and return ParsedFile with nodes and edges
    
    Example implementation:
        class PythonParser(BaseParser):
            @property
            def language(self) -> Language:
                return Language.PYTHON
            
            @property
            def file_extensions(self) -> List[str]:
                return ['.py', '.pyi']
            
            def parse_file(self, file_path: str) -> ParsedFile:
                # Implementation here
                pass
    """
    
    @property
    @abstractmethod
    def language(self) -> Language:
        """
        Return the language this parser handles.
        
        Returns:
            Language enum value (e.g., Language.PYTHON, Language.JAVASCRIPT)
        """
        pass
    
    @property
    @abstractmethod
    def file_extensions(self) -> List[str]:
        """
        Return list of file extensions this parser handles.
        
        File extensions should include the leading dot and be lowercase.
        
        Returns:
            List of file extensions (e.g., ['.py', '.pyi'] for Python,
            ['.js', '.jsx'] for JavaScript, ['.ts', '.tsx'] for TypeScript)
        
        Examples:
            Python: ['.py', '.pyi']
            JavaScript: ['.js', '.jsx']
            TypeScript: ['.ts', '.tsx']
            Java: ['.java']
            Go: ['.go']
        """
        pass
    
    @abstractmethod
    def parse_file(self, file_path: str) -> ParsedFile:
        """
        Parse a single source file and return nodes, edges, and any errors.
        
        This method should read the file, parse its contents using the appropriate
        parser (e.g., tree-sitter), extract nodes (functions, classes, variables),
        extract edges (calls, imports, inheritance), and return all information
        in a ParsedFile object.
        
        Args:
            file_path: Absolute or relative path to the source file
            
        Returns:
            ParsedFile containing extracted nodes, edges, parse metadata, and any
            errors encountered during parsing
            
        Raises:
            FileNotFoundError: If the file does not exist
            PermissionError: If the file cannot be read
            
        Implementation notes:
            - Measure parse time and populate parse_time_ms
            - Catch and record parse errors in the errors list
            - Return partial results even if errors occur
            - Ensure all node IDs are fully qualified
            - Ensure all edge references point to valid node IDs
        """
        pass
    
    def can_parse(self, file_path: str) -> bool:
        """
        Check if this parser can handle the given file.
        
        This method checks if the file's extension matches any of the extensions
        supported by this parser. It is provided as a convenience method and does
        not need to be overridden in subclasses.
        
        Args:
            file_path: Path to check (can be absolute or relative)
            
        Returns:
            True if file extension matches this parser's supported extensions,
            False otherwise
            
        Example:
            parser = PythonParser()
            parser.can_parse("auth/security.py")  # Returns True
            parser.can_parse("config.json")       # Returns False
        """
        return any(file_path.endswith(ext) for ext in self.file_extensions)
