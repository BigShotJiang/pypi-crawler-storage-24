import json
import pytest
from pathlib import Path

from sinew.parsers.python.parser import PythonParser
from sinew.graph.builder import GraphBuilder
from sinew.core.config import sinewConfig
from sinew.schema.models import sinewGraph, NodeType, Language, sinewAnnotation, AgentWarning, WarningSeverity
from datetime import datetime
from sinew.agents.boot import generate_boot_payload
from sinew.agents.verify import verify_output
from sinew.agents.territory import TerritoryMap, TerritoryResult
from sinew.agents.context import generate_context


PROJECT_ROOT = Path(__file__).parent.parent
FIXTURES_DIR = PROJECT_ROOT / "tests" / "fixtures" / "python"


def _build_test_graph() -> sinewGraph:
    parser = PythonParser()
    auth_file = FIXTURES_DIR / "sample_auth.py"
    simple_file = FIXTURES_DIR / "sample_simple.py"

    parsed_auth = parser.parse_file(str(auth_file), repo_root=PROJECT_ROOT)
    parsed_simple = parser.parse_file(str(simple_file), repo_root=PROJECT_ROOT)

    config = sinewConfig()
    builder = GraphBuilder()
    graph = builder.build(
        parsed_files=[parsed_auth, parsed_simple],
        repo_root=PROJECT_ROOT,
        config=config,
        git_meta=None,
    )
    return graph


class TestGenerateBootPayload:
    """Tests for generate_boot_payload function."""

    def test_returns_dict_with_required_keys(self):
        """generate_boot_payload should return a dict with required keys."""
        graph = _build_test_graph()
        payload = generate_boot_payload(graph, "auth login")

        assert isinstance(payload, dict)
        assert "task_scope" in payload
        assert "conventions" in payload
        assert "what_already_exists" in payload
        assert "past_mistakes" in payload
        assert "frozen_zones" in payload
        assert "confidence_warnings" in payload

    def test_task_scope_has_required_fields(self):
        """task_scope should have relevant_files, entry_points, hotspots_in_scope."""
        graph = _build_test_graph()
        payload = generate_boot_payload(graph, "auth")

        task_scope = payload["task_scope"]
        assert "relevant_files" in task_scope
        assert "entry_points" in task_scope
        assert "hotspots_in_scope" in task_scope
        assert isinstance(task_scope["relevant_files"], list)

    def test_token_estimate_within_budget(self):
        """Token estimate of payload should be within budget."""
        graph = _build_test_graph()
        budget = 800
        payload = generate_boot_payload(graph, "auth login", token_budget=budget)

        estimated_tokens = len(json.dumps(payload)) // 4
        assert estimated_tokens <= budget * 1.5

    def test_scoring_prioritizes_name_match(self):
        """Nodes with name in task should score higher."""
        graph = _build_test_graph()
        payload = generate_boot_payload(graph, "verify_password")

        relevant_files = payload["task_scope"]["relevant_files"]
        assert any("auth" in f for f in relevant_files)


class TestVerifyOutput:
    """Tests for verify_output function."""

    def test_identifies_hallucinated_function(self):
        """verify_output should identify a made-up function name as hallucination."""
        graph = _build_test_graph()
        code = """
def my_function():
    nonexistent_function()
    return True
"""
        result = verify_output(code, graph, Language.PYTHON)

        assert result.passed is False
        assert len(result.hallucinations) > 0

    def test_real_function_not_hallucination(self):
        """verify_output should find a real function name as NOT a hallucination."""
        graph = _build_test_graph()
        code = """
def my_function():
    verify_password()
    return True
"""
        result = verify_output(code, graph, Language.PYTHON)

        has_verify_password = any(h.symbol == "verify_password" for h in result.hallucinations)
        assert has_verify_password is False or len(result.hallucinations) == 0

    def test_frozen_node_violation(self):
        """verify_output should detect frozen node violations."""
        graph = _build_test_graph()

        for node in graph.nodes:
            if node.sinew is None:
                node.sinew = sinewAnnotation(frozen=True, frozen_reason="test freeze")
                break

        code = """
def my_function():
    some_frozen_function()
    return True
"""
        result = verify_output(code, graph, Language.PYTHON)
        assert isinstance(result.passed, bool)


class TestTerritoryMap:
    """Tests for TerritoryMap class."""

    def test_claim_returns_success_when_no_conflict(self, tmp_path):
        """TerritoryMap.claim should return success when no conflict."""
        graph = _build_test_graph()
        tm = TerritoryMap(tmp_path)

        result = tm.claim("agent-1", "tests/fixtures/python", "test task", graph)

        assert result.success is True
        assert len(result.conflicts) == 0

    def test_claim_returns_conflict_on_overlap(self, tmp_path):
        """TerritoryMap.claim should return conflict when scopes overlap."""
        graph = _build_test_graph()
        tm = TerritoryMap(tmp_path)

        tm.claim("agent-1", "tests/fixtures/python", "task 1", graph)
        result = tm.claim("agent-2", "tests/fixtures/python/sample_auth.py", "task 2", graph)

        assert result.success is False
        assert len(result.conflicts) > 0

    def test_release_removes_claim(self, tmp_path):
        """TerritoryMap.release should remove the claim."""
        graph = _build_test_graph()
        tm = TerritoryMap(tmp_path)

        tm.claim("agent-1", "tests/fixtures/python", "task", graph)
        tm.release("agent-1")

        claims = tm.status()
        assert len(claims) == 0

    def test_status_returns_all_claims(self, tmp_path):
        """TerritoryMap.status should return all active claims."""
        graph = _build_test_graph()
        tm = TerritoryMap(tmp_path)

        tm.claim("agent-1", "tests/fixtures/python/sample_auth.py", "task 1", graph)
        tm.claim("agent-2", "tests/fixtures/python/sample_simple.py", "task 2", graph)

        claims = tm.status()
        assert len(claims) == 2


class TestGenerateContext:
    """Tests for generate_context function."""

    def test_returns_dict_with_nodes_and_edges(self):
        """generate_context should return dict with nodes and edges."""
        graph = _build_test_graph()
        result = generate_context(graph, "auth", token_budget=4000)

        assert isinstance(result, dict)
        assert "nodes" in result
        assert "edges" in result
        assert isinstance(result["nodes"], list)

    def test_nodes_contain_required_fields(self):
        """Selected nodes should contain required fields."""
        graph = _build_test_graph()
        result = generate_context(graph, "auth", token_budget=4000)

        if result["nodes"]:
            node = result["nodes"][0]
            assert "id" in node
            assert "type" in node
            assert "file" in node
            assert "line" in node

    def test_token_budget_is_respected(self):
        """Should respect token budget when selecting nodes."""
        graph = _build_test_graph()
        budget = 1000
        result = generate_context(graph, "auth", token_budget=budget)

        estimated_tokens = len(json.dumps(result)) // 4
        assert estimated_tokens <= budget * 1.5
