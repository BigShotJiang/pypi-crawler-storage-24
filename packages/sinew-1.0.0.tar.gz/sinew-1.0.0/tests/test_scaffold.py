"""
Smoke tests for Sinew project scaffold.

These tests verify the structural integrity of the scaffold without
requiring full implementation logic.
"""

import pytest
from pathlib import Path
from abc import ABC

import toml


PROJECT_ROOT = Path(__file__).parent.parent


class TestPackageStructure:
    """Test that all package directories contain __init__.py files."""

    def test_all_package_directories_have_init_files(self):
        """Property 1: Package Directory Invariant - Validates Requirements 2.1-2.14"""
        package_dirs = [
            "sinew",
            "sinew/schema",
            "sinew/core",
            "sinew/parsers",
            "sinew/parsers/python",
            "sinew/parsers/javascript",
            "sinew/parsers/typescript",
            "sinew/graph",
            "sinew/agents",
            "sinew/renderers",
            "sinew/exporters",
            "sinew/mcp",
            "sinew/cli",
            "tests",
        ]

        for package_dir in package_dirs:
            init_file = PROJECT_ROOT / package_dir / "__init__.py"
            assert init_file.exists(), f"Missing __init__.py in {package_dir}/"


class TestDirectoryStructure:
    """Test that all required directories exist."""

    def test_all_required_directories_exist(self):
        """Property 3: Directory Structure Completeness - Validates Requirements 8.1-8.12"""
        required_dirs = [
            "sinew/core",
            "sinew/parsers",
            "sinew/parsers/python",
            "sinew/parsers/javascript",
            "sinew/parsers/typescript",
            "sinew/graph",
            "sinew/agents",
            "sinew/renderers",
            "sinew/exporters",
            "sinew/mcp",
            "sinew/cli",
            "tests",
        ]

        for req_dir in required_dirs:
            dir_path = PROJECT_ROOT / req_dir
            assert dir_path.exists(), f"Missing required directory {req_dir}/"
            assert dir_path.is_dir(), f"{req_dir} is not a directory"


class TestStubModules:
    """Test that all stub modules exist with docstrings."""

    def test_all_stub_modules_exist_with_docstrings(self):
        """Property 2: Stub Module Completeness - Validates Requirements 4.1-4.8"""
        stub_modules = [
            "sinew/core/scanner.py",
            "sinew/core/detector.py",
            "sinew/core/config.py",
            "sinew/graph/builder.py",
            "sinew/graph/indexer.py",
            "sinew/graph/stats.py",
            "sinew/cli/main.py",
            "sinew/parsers/python/parser.py",
        ]

        for stub_module in stub_modules:
            module_path = PROJECT_ROOT / stub_module
            assert module_path.exists(), f"Missing stub module {stub_module}"

            content = module_path.read_text(encoding="utf-8")
            assert content.strip().startswith('"""'), f"{stub_module} missing module docstring"


class TestConfigurationFiles:
    """Test configuration files exist and are valid."""

    def test_pyproject_toml_exists_and_valid(self):
        """Validate pyproject.toml structure and project name."""
        pyproject_path = PROJECT_ROOT / "pyproject.toml"
        assert pyproject_path.exists(), "Missing pyproject.toml"

        config = toml.load(pyproject_path)

        assert config["project"]["name"] == "sinew"
        assert config["project"]["version"] == "0.1.0"
        assert config["project"]["requires-python"] == ">=3.11"
        assert "sinew.cli.main:app" in config["project"]["scripts"]["sinew"]
        assert config["tool"]["pytest"]["ini_options"]["testpaths"] == ["tests"]

    def test_sinewconfig_exists_and_valid(self):
        """Validate .sinewconfig has required sections."""
        config_path = PROJECT_ROOT / ".sinewconfig"
        assert config_path.exists(), "Missing .sinewconfig"

        config = toml.load(config_path)

        assert "sinew" in config
        assert config["sinew"]["version"] == "1.0"
        assert "ignore" in config
        assert "patterns" in config["ignore"]
        assert "agents" in config

    def test_sinewconstitution_exists_and_valid(self):
        """Validate .sinewconstitution has rules section."""
        constitution_path = PROJECT_ROOT / ".sinewconstitution"
        assert constitution_path.exists(), "Missing .sinewconstitution"

        config = toml.load(constitution_path)

        assert "rules" in config
        assert config["rules"]["version"] == "1.0"


class TestBaseParserInterface:
    """Test BaseParser abstract class."""

    def test_base_parser_cannot_be_instantiated(self):
        """Property 5: Abstract Class Enforcement - Validates Requirement 6.3"""
        from sinew.parsers.base import BaseParser

        with pytest.raises(TypeError):
            BaseParser()

    def test_parsed_file_can_be_initialized(self):
        """Validates Requirement 6.4 - ParsedFile can be initialized with empty lists."""
        from sinew.parsers.base import ParsedFile
        from sinew.schema.models import Language

        parsed = ParsedFile(
            file_path="test.py",
            language=Language.PYTHON,
            nodes=[],
            edges=[],
            errors=[],
            parse_time_ms=0.0,
        )

        assert parsed.file_path == "test.py"
        assert parsed.language == Language.PYTHON
        assert parsed.nodes == []
        assert parsed.edges == []
        assert parsed.errors == []
        assert parsed.parse_time_ms == 0.0

    def test_base_parser_has_required_abstract_methods(self):
        """Verify abstract method definitions."""
        from sinew.parsers.base import BaseParser

        assert hasattr(BaseParser, "language")
        assert hasattr(BaseParser, "file_extensions")
        assert hasattr(BaseParser, "parse_file")

    def test_base_parser_has_can_parse_method(self):
        """Verify can_parse method exists."""
        from sinew.parsers.base import BaseParser

        assert hasattr(BaseParser, "can_parse")
        assert callable(BaseParser.can_parse)


class TestSchemaImports:
    """Test that schema modules can be imported."""

    def test_schema_models_imports(self):
        """Validates Requirement 6.5 - sinew.schema.models imports without error."""
        from sinew.schema.models import Node, Edge, Language

        assert Node is not None
        assert Edge is not None
        assert Language is not None

    def test_schema_validator_imports(self):
        """Validates Requirement 6.6 - sinew.schema.validator imports without error."""
        from sinew.schema import validator

        assert validator is not None


class TestSchemaLayerPreservation:
    """Test that existing schema files remain unchanged."""

    def test_schema_files_unchanged(self):
        """Property 4: Schema Layer Preservation - Validates Requirements 7.1-7.4"""
        schema_models_path = PROJECT_ROOT / "schema" / "models.py"
        schema_validator_path = PROJECT_ROOT / "schema" / "validator.py"

        assert schema_models_path.exists(), "schema/models.py must exist"
        assert schema_validator_path.exists(), "schema/validator.py must exist"

        assert schema_models_path.read_text(encoding="utf-8"), "schema/models.py must not be empty"
        assert schema_validator_path.read_text(encoding="utf-8"), "schema/validator.py must not be empty"
