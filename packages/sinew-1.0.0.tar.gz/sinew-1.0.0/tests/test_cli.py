"""Integration tests for the Sinew CLI."""

from __future__ import annotations

import os
import tempfile
from pathlib import Path

import pytest
from typer.testing import CliRunner

from sinew.cli.main import app

runner = CliRunner()


class TestBuildCommand:
    def test_build_exits_zero(self):
        """Test sinew build ./tests/fixtures/python exits 0."""
        fixtures_dir = Path(__file__).parent / "fixtures" / "python"
        result = runner.invoke(app, ["build", str(fixtures_dir), "--output", "sinew.json"])
        if result.exit_code != 0:
            print(f"Build failed: {result.output}")
            if result.exception:
                print(f"Exception: {result.exception}")
        assert result.exit_code == 0, f"Expected exit code 0, got {result.exit_code}. Output: {result.output}"
        graph_path = fixtures_dir / "sinew.json"
        assert graph_path.exists(), f"sinew.json not created at {graph_path}"


class TestStatsCommand:
    def test_stats_exits_zero_and_prints_structural_score(self):
        """Test sinew stats exits 0 and prints 'Structural Score'."""
        fixtures_dir = Path(__file__).parent / "fixtures" / "python"
        graph_path = fixtures_dir / "sinew.json"
        result = runner.invoke(app, ["stats", "--graph", str(graph_path)])
        assert result.exit_code == 0, f"Expected exit code 0, got {result.exit_code}. Output: {result.output}"
        assert "Structural Score" in result.output, f"Expected 'Structural Score' in output. Got: {result.output}"


class TestTraceCommand:
    def test_trace_verify_password_exits_zero_and_prints_call_chain(self):
        """Test sinew trace verify_password exits 0 and prints call chain."""
        fixtures_dir = Path(__file__).parent / "fixtures" / "python"
        graph_path = fixtures_dir / "sinew.json"
        result = runner.invoke(app, ["trace", "verify_password", "--graph", str(graph_path)])
        assert result.exit_code == 0, f"Expected exit code 0, got {result.exit_code}. Output: {result.output}"
        assert "auth" in result.output, f"Expected 'auth' in output. Got: {result.output}"


class TestImpactCommand:
    def test_impact_verify_password_exits_zero(self):
        """Test sinew impact verify_password exits 0."""
        fixtures_dir = Path(__file__).parent / "fixtures" / "python"
        graph_path = fixtures_dir / "sinew.json"
        result = runner.invoke(app, ["impact", "verify_password", "--graph", str(graph_path)])
        assert result.exit_code == 0, f"Expected exit code 0, got {result.exit_code}. Output: {result.output}"


class TestSearchCommand:
    def test_search_login_exits_zero_and_prints_table(self):
        """Test sinew search login exits 0 and prints a table."""
        fixtures_dir = Path(__file__).parent / "fixtures" / "python"
        graph_path = fixtures_dir / "sinew.json"
        result = runner.invoke(app, ["search", "login", "--graph", str(graph_path)])
        assert result.exit_code == 0, f"Expected exit code 0, got {result.exit_code}. Output: {result.output}"
        assert "ID" in result.output or "login" in result.output.lower(), f"Expected table output. Got: {result.output}"


class TestDeadCommand:
    def test_dead_exits_zero(self):
        """Test sinew dead exits 0."""
        fixtures_dir = Path(__file__).parent / "fixtures" / "python"
        graph_path = fixtures_dir / "sinew.json"
        result = runner.invoke(app, ["dead", "--graph", str(graph_path)])
        assert result.exit_code == 0, f"Expected exit code 0, got {result.exit_code}. Output: {result.output}"


class TestValidateCommand:
    def test_validate_sinew_json_exits_zero(self):
        """Test sinew validate sinew.json exits 0."""
        fixtures_dir = Path(__file__).parent / "fixtures" / "python"
        graph_path = fixtures_dir / "sinew.json"
        result = runner.invoke(app, ["validate", str(graph_path)])
        assert result.exit_code == 0, f"Expected exit code 0, got {result.exit_code}. Output: {result.output}"
