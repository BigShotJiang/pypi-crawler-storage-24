"""Simple math functions."""


def add(a, b):
    """Add two numbers."""
    return a + b


def subtract(a, b):
    """Subtract two numbers."""
    return a - b


def multiply(a, b):
    """Multiply two numbers."""
    return a * b


result = add(1, 2)
result = subtract(result, 1)
result = multiply(result, 3)
