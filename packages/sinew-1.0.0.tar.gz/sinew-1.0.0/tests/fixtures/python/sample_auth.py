"""Sample authentication module for testing."""


import os
import database


class AuthService:
    """Authentication service class."""

    def login(self, user: str, password: str) -> bool:
        """Login user with credentials."""
        return True

    def logout(self):
        """Logout current user."""
        pass


MAX_RETRIES: int = 3  # @sinew: critical=true


def verify_password(user, password):
    """Verify user password."""
    auth = AuthService()
    return auth.login(user, password)
