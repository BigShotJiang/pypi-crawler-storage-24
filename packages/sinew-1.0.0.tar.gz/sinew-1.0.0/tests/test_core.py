from __future__ import annotations

import toml
from pathlib import Path

import pytest

from sinew.core.config import sinewConfig
from sinew.core.detector import LanguageDetector
from sinew.core.scanner import FileScanner, ScannedFile
from sinew.schema.models import Language


class TestSinewConfig:
    def test_loads_defaults_when_no_config_file_exists(self, tmp_path):
        config = sinewConfig.from_repo(tmp_path)

        assert config.languages == ["python"]
        assert config.output == "sinew.json"
        assert config.confidence_threshold == 0.75
        assert config.entry_points == []
        assert config.boot_token_budget == 800
        assert config.context_token_budget == 4000
        assert config.mistake_memory is True
        assert config.territory_map is True

    def test_loads_values_from_real_sinewconfig(self, tmp_path):
        config_content = """
[sinew]
languages = ["python", "javascript"]
output = "custom.json"
confidence_threshold = 0.8
entry_points = ["main.py", "app.py"]
boot_token_budget = 1000
context_token_budget = 5000
mistake_memory = false
territory_map = false

[sinew.ignore]
ignore_directories = ["custom_dir"]
ignore_files = ["custom_file.txt"]
"""
        config_file = tmp_path / ".sinewconfig"
        config_file.write_text(config_content)

        config = sinewConfig.from_repo(tmp_path)

        assert config.languages == ["python", "javascript"]
        assert config.output == "custom.json"
        assert config.confidence_threshold == 0.8
        assert config.entry_points == ["main.py", "app.py"]
        assert config.boot_token_budget == 1000
        assert config.context_token_budget == 5000
        assert config.mistake_memory is False
        assert config.territory_map is False

    def test_should_ignore_returns_true_for_pycache(self, tmp_path):
        config = sinewConfig.from_repo(tmp_path)

        pycache_dir = tmp_path / "__pycache__"
        pycache_dir.mkdir()

        assert config.should_ignore(pycache_dir, tmp_path) is True

    def test_should_ignore_returns_true_for_node_modules_at_any_depth(self, tmp_path):
        config = sinewConfig.from_repo(tmp_path)

        nested_node_modules = tmp_path / "src" / "deep" / "node_modules"
        nested_node_modules.mkdir(parents=True)

        assert config.should_ignore(nested_node_modules, tmp_path) is True

    def test_should_ignore_returns_false_for_normal_py_file(self, tmp_path):
        config = sinewConfig.from_repo(tmp_path)

        py_file = tmp_path / "main.py"
        py_file.write_text("print('hello')")

        assert config.should_ignore(py_file, tmp_path) is False

    def test_should_ignore_respects_custom_patterns_from_sinewignore(self, tmp_path):
        ignore_content = """
# Ignore all .log files
*.log
# Ignore specific directory
temp/
"""
        ignore_file = tmp_path / ".sinewignore"
        ignore_file.write_text(ignore_content)

        config = sinewConfig.from_repo(tmp_path)

        log_file = tmp_path / "debug.log"
        log_file.write_text("log data")

        temp_dir = tmp_path / "temp"
        temp_dir.mkdir()

        assert config.should_ignore(log_file, tmp_path) is True
        assert config.should_ignore(temp_dir, tmp_path) is True


class TestLanguageDetector:
    def test_py_maps_to_python(self):
        assert LanguageDetector.detect(Path("test.py")) == Language.PYTHON

    def test_ts_maps_to_typescript(self):
        assert LanguageDetector.detect(Path("test.ts")) == Language.TYPESCRIPT

    def test_unknown_returns_none(self):
        assert LanguageDetector.detect(Path("test.unknown")) is None

    def test_is_supported_returns_false_for_unsupported(self):
        assert LanguageDetector.is_supported(Path("test.unknown")) is False
        assert LanguageDetector.is_supported(Path("test.xyz")) is False

    def test_is_supported_returns_true_for_supported(self):
        assert LanguageDetector.is_supported(Path("test.py")) is True
        assert LanguageDetector.is_supported(Path("test.js")) is True
        assert LanguageDetector.is_supported(Path("test.ts")) is True

    def test_supported_extensions_returns_all(self):
        exts = LanguageDetector.supported_extensions()
        assert ".py" in exts
        assert ".js" in exts
        assert ".ts" in exts
        assert ".java" in exts
        assert ".go" in exts
        assert ".rs" in exts


class TestFileScanner:
    def test_scan_returns_only_configured_language_files(self, tmp_path):
        (tmp_path / "main.py").write_text("print('hello')")
        (tmp_path / "app.js").write_text("console.log('hello')")

        config = sinewConfig.from_repo(tmp_path)
        config.languages = ["python"]

        files = FileScanner.scan(tmp_path, config)

        assert len(files) == 1
        assert files[0].language == Language.PYTHON

    def test_scan_excludes_pycache_and_venv(self, tmp_path):
        (tmp_path / "main.py").write_text("print('hello')")

        pycache = tmp_path / "__pycache__"
        pycache.mkdir()
        (pycache / "main.pyc").write_text("")

        venv = tmp_path / ".venv"
        venv.mkdir()

        config = sinewConfig.from_repo(tmp_path)
        config.languages = ["python"]

        files = FileScanner.scan(tmp_path, config)

        assert len(files) == 1
        assert files[0].relative_path == "main.py"

    def test_relative_path_is_relative_to_repo_root(self, tmp_path):
        src_dir = tmp_path / "src"
        src_dir.mkdir()
        (src_dir / "main.py").write_text("print('hello')")

        config = sinewConfig.from_repo(tmp_path)

        files = FileScanner.scan(tmp_path, config)

        assert len(files) == 1
        assert files[0].relative_path == "src/main.py"

    def test_files_are_sorted_by_relative_path(self, tmp_path):
        (tmp_path / "z.py").write_text("")
        (tmp_path / "a.py").write_text("")
        (tmp_path / "m.py").write_text("")

        config = sinewConfig.from_repo(tmp_path)

        files = FileScanner.scan(tmp_path, config)

        assert len(files) == 3
        assert files[0].relative_path == "a.py"
        assert files[1].relative_path == "m.py"
        assert files[2].relative_path == "z.py"

    def test_scan_file_returns_none_for_ignored(self, tmp_path):
        pycache = tmp_path / "__pycache__"
        pycache.mkdir()
        (pycache / "main.pyc").write_text("")

        config = sinewConfig.from_repo(tmp_path)

        result = FileScanner.scan_file(pycache / "main.pyc", tmp_path, config)

        assert result is None

    def test_scan_file_returns_scanned_file_for_valid(self, tmp_path):
        (tmp_path / "main.py").write_text("print('hello')")

        config = sinewConfig.from_repo(tmp_path)

        result = FileScanner.scan_file(tmp_path / "main.py", tmp_path, config)

        assert result is not None
        assert result.relative_path == "main.py"
        assert result.language == Language.PYTHON
        assert result.size_bytes > 0
