"""
Tests for GraphBuilder, IndexBuilder, and StatsEngine.

These tests verify that the graph building pipeline correctly:
- Merges nodes and edges from multiple parsed files
- Builds all indexes correctly
- Computes accurate statistics
- Produces a valid sinewGraph that passes validation
"""

import pytest
from pathlib import Path

from sinew.parsers.python.parser import PythonParser
from sinew.graph.builder import GraphBuilder
from sinew.core.config import sinewConfig
from sinew.schema.validator import validate_file


PROJECT_ROOT = Path(__file__).parent.parent
FIXTURES_DIR = PROJECT_ROOT / "tests" / "fixtures" / "python"


class TestGraphBuilder:
    """Test GraphBuilder.build() and related functionality."""

    def test_build_returns_sinew_graph(self):
        """GraphBuilder.build() should return a sinewGraph object."""
        parser = PythonParser()
        
        auth_file = FIXTURES_DIR / "sample_auth.py"
        simple_file = FIXTURES_DIR / "sample_simple.py"
        
        parsed_auth = parser.parse_file(str(auth_file), repo_root=PROJECT_ROOT)
        parsed_simple = parser.parse_file(str(simple_file), repo_root=PROJECT_ROOT)
        
        config = sinewConfig()
        repo_root = PROJECT_ROOT
        
        builder = GraphBuilder()
        graph = builder.build(
            parsed_files=[parsed_auth, parsed_simple],
            repo_root=repo_root,
            config=config,
            git_meta=None,
        )
        
        assert graph is not None
        assert hasattr(graph, 'meta')
        assert hasattr(graph, 'nodes')
        assert hasattr(graph, 'edges')
        assert hasattr(graph, 'indexes')
        assert hasattr(graph, 'lists')
        assert hasattr(graph, 'stats')

    def test_graph_validates_json(self):
        """Serialized graph should pass validation."""
        parser = PythonParser()
        
        auth_file = FIXTURES_DIR / "sample_auth.py"
        simple_file = FIXTURES_DIR / "sample_simple.py"
        
        parsed_auth = parser.parse_file(str(auth_file), repo_root=PROJECT_ROOT)
        parsed_simple = parser.parse_file(str(simple_file), repo_root=PROJECT_ROOT)
        
        config = sinewConfig()
        repo_root = PROJECT_ROOT
        
        builder = GraphBuilder()
        graph = builder.build(
            parsed_files=[parsed_auth, parsed_simple],
            repo_root=repo_root,
            config=config,
            git_meta=None,
        )
        
        json_str = graph.to_json()
        assert json_str is not None
        assert len(json_str) > 0
        
        restored = type(graph).from_json(json_str)
        assert restored is not None

    def test_reverse_index_has_hotspot_entries(self):
        """Reverse index should have entries for all nodes, including potential hotspots."""
        parser = PythonParser()
        
        auth_file = FIXTURES_DIR / "sample_auth.py"
        simple_file = FIXTURES_DIR / "sample_simple.py"
        
        parsed_auth = parser.parse_file(str(auth_file), repo_root=PROJECT_ROOT)
        parsed_simple = parser.parse_file(str(simple_file), repo_root=PROJECT_ROOT)
        
        config = sinewConfig()
        repo_root = PROJECT_ROOT
        
        builder = GraphBuilder()
        graph = builder.build(
            parsed_files=[parsed_auth, parsed_simple],
            repo_root=repo_root,
            config=config,
            git_meta=None,
        )
        
        assert graph.indexes.reverse is not None
        assert len(graph.indexes.reverse) > 0
        
        for node in graph.nodes:
            assert node.id in graph.indexes.reverse

    def test_call_index_full_chain(self):
        """Call index should contain full_chain for functions."""
        parser = PythonParser()
        
        auth_file = FIXTURES_DIR / "sample_auth.py"
        
        parsed_auth = parser.parse_file(str(auth_file), repo_root=PROJECT_ROOT)
        
        config = sinewConfig()
        repo_root = PROJECT_ROOT
        
        builder = GraphBuilder()
        graph = builder.build(
            parsed_files=[parsed_auth],
            repo_root=repo_root,
            config=config,
            git_meta=None,
        )
        
        func_nodes = [n for n in graph.nodes if n.type.value in ('function', 'method')]
        
        for func in func_nodes:
            if func.id in graph.indexes.calls:
                call_entry = graph.indexes.calls[func.id]
                assert call_entry.full_chain is not None
                assert isinstance(call_entry.full_chain, list)

    def test_stats_symbols_functions_count(self):
        """Stats should show functions > 0."""
        parser = PythonParser()
        
        auth_file = FIXTURES_DIR / "sample_auth.py"
        simple_file = FIXTURES_DIR / "sample_simple.py"
        
        parsed_auth = parser.parse_file(str(auth_file), repo_root=PROJECT_ROOT)
        parsed_simple = parser.parse_file(str(simple_file), repo_root=PROJECT_ROOT)
        
        config = sinewConfig()
        repo_root = PROJECT_ROOT
        
        builder = GraphBuilder()
        graph = builder.build(
            parsed_files=[parsed_auth, parsed_simple],
            repo_root=repo_root,
            config=config,
            git_meta=None,
        )
        
        assert graph.stats.symbols.functions > 0

    def test_structural_score_total_range(self):
        """Structural score total should be between 0 and 100."""
        parser = PythonParser()
        
        auth_file = FIXTURES_DIR / "sample_auth.py"
        simple_file = FIXTURES_DIR / "sample_simple.py"
        
        parsed_auth = parser.parse_file(str(auth_file), repo_root=PROJECT_ROOT)
        parsed_simple = parser.parse_file(str(simple_file), repo_root=PROJECT_ROOT)
        
        config = sinewConfig()
        repo_root = PROJECT_ROOT
        
        builder = GraphBuilder()
        graph = builder.build(
            parsed_files=[parsed_auth, parsed_simple],
            repo_root=repo_root,
            config=config,
            git_meta=None,
        )
        
        score = graph.stats.structural_score.total
        assert 0 <= score <= 100

    def test_json_roundtrip(self):
        """Graph should survive JSON serialization/deserialization."""
        parser = PythonParser()
        
        auth_file = FIXTURES_DIR / "sample_auth.py"
        simple_file = FIXTURES_DIR / "sample_simple.py"
        
        parsed_auth = parser.parse_file(str(auth_file), repo_root=PROJECT_ROOT)
        parsed_simple = parser.parse_file(str(simple_file), repo_root=PROJECT_ROOT)
        
        config = sinewConfig()
        repo_root = PROJECT_ROOT
        
        builder = GraphBuilder()
        original = builder.build(
            parsed_files=[parsed_auth, parsed_simple],
            repo_root=repo_root,
            config=config,
            git_meta=None,
        )
        
        json_str = original.to_json()
        restored = type(original).from_json(json_str)
        
        assert restored.meta.repo_name == original.meta.repo_name
        assert len(restored.nodes) == len(original.nodes)
        assert len(restored.edges) == len(original.edges)
        assert restored.stats.symbols.total_nodes == original.stats.symbols.total_nodes


class TestIndexBuilder:
    """Test IndexBuilder.build() functionality."""

    def test_builds_all_five_indexes(self):
        """IndexBuilder should build reverse, origin, files, modules, and calls."""
        from sinew.graph.indexer import IndexBuilder
        
        parser = PythonParser()
        auth_file = FIXTURES_DIR / "sample_auth.py"
        parsed = parser.parse_file(str(auth_file), repo_root=PROJECT_ROOT)
        
        indexes = IndexBuilder.build(parsed.nodes, parsed.edges)
        
        assert hasattr(indexes, 'reverse')
        assert hasattr(indexes, 'origin')
        assert hasattr(indexes, 'files')
        assert hasattr(indexes, 'modules')
        assert hasattr(indexes, 'calls')


class TestStatsEngine:
    """Test StatsEngine.compute() functionality."""

    def test_computes_all_stats(self):
        """StatsEngine should compute all stat categories."""
        from sinew.graph.stats import StatsEngine
        
        parser = PythonParser()
        auth_file = FIXTURES_DIR / "sample_auth.py"
        simple_file = FIXTURES_DIR / "sample_simple.py"
        
        parsed_auth = parser.parse_file(str(auth_file), repo_root=PROJECT_ROOT)
        parsed_simple = parser.parse_file(str(simple_file), repo_root=PROJECT_ROOT)
        
        nodes = parsed_auth.nodes + parsed_simple.nodes
        edges = parsed_auth.edges + parsed_simple.edges
        
        builder = GraphBuilder()
        merged_nodes = builder._merge_nodes(nodes)
        merged_edges = builder._merge_edges(edges, merged_nodes)
        
        lists = builder._build_lists(merged_nodes, merged_edges)
        
        stats = StatsEngine.compute(merged_nodes, merged_edges, lists)
        
        assert stats.files is not None
        assert stats.symbols is not None
        assert stats.dead_code is not None
        assert stats.complexity is not None
        assert stats.hotspots is not None
        assert stats.coverage is not None
        assert stats.confidence is not None
        assert stats.sinew_schema is not None
        assert stats.structural_score is not None
        assert stats.bus_factor is not None
