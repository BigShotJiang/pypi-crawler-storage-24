import pytest
from pathlib import Path

from sinew.parsers.python.parser import PythonParser
from sinew.graph.builder import GraphBuilder
from sinew.core.config import sinewConfig
from sinew.schema.models import sinewGraph, NodeType, Language, sinewAnnotation, AgentWarning, WarningSeverity
from sinew.mcp.server import (
    get_server,
    get_boot,
    get_context,
    check_exists,
    get_impact,
    verify_output,
)


PROJECT_ROOT = Path(__file__).parent.parent
FIXTURES_DIR = PROJECT_ROOT / "tests" / "fixtures" / "python"


def _build_test_graph() -> sinewGraph:
    parser = PythonParser()
    auth_file = FIXTURES_DIR / "sample_auth.py"
    simple_file = FIXTURES_DIR / "sample_simple.py"

    parsed_auth = parser.parse_file(str(auth_file), repo_root=PROJECT_ROOT)
    parsed_simple = parser.parse_file(str(simple_file), repo_root=PROJECT_ROOT)

    config = sinewConfig()
    builder = GraphBuilder()
    graph = builder.build(
        parsed_files=[parsed_auth, parsed_simple],
        repo_root=PROJECT_ROOT,
        config=config,
        git_meta=None,
    )
    return graph


class TestMCPGetBoot:
    """Tests for get_boot MCP tool."""

    def test_returns_dict_with_task_scope(self):
        """get_boot should return a dict with task_scope key."""
        graph = _build_test_graph()
        server = get_server(graph=graph)

        result = get_boot(task="auth login", tokens=800)

        assert isinstance(result, dict)
        assert "task_scope" in result

    def test_task_scope_has_required_fields(self):
        """task_scope should have relevant_files, entry_points, hotspots_in_scope."""
        graph = _build_test_graph()
        server = get_server(graph=graph)

        result = get_boot(task="auth", tokens=800)

        task_scope = result["task_scope"]
        assert "relevant_files" in task_scope
        assert "entry_points" in task_scope
        assert "hotspots_in_scope" in task_scope


class TestMCPCheckExists:
    """Tests for check_exists MCP tool."""

    def test_returns_found_true_for_real_symbol(self):
        """check_exists should return found=True for a real symbol name."""
        graph = _build_test_graph()
        server = get_server(graph=graph)

        real_symbol = None
        for node in graph.nodes:
            if node.type in (NodeType.FUNCTION, NodeType.METHOD):
                real_symbol = node.name
                break

        assert real_symbol is not None, "Test graph should have functions"

        result = check_exists(symbol=real_symbol)

        assert result["found"] is True
        assert len(result["matches"]) > 0

    def test_returns_found_false_for_nonsense_symbol(self):
        """check_exists should return found=False for a nonsense symbol name."""
        graph = _build_test_graph()
        server = get_server(graph=graph)

        result = check_exists(symbol="xyzqwertyasdfgh")

        assert result["found"] is False
        assert result["matches"] == []


class TestMCPGetImpact:
    """Tests for get_impact MCP tool."""

    def test_returns_callers_affected_non_negative(self):
        """get_impact should return callers_affected >= 0."""
        graph = _build_test_graph()
        server = get_server(graph=graph)

        symbol = None
        for node in graph.nodes:
            if node.type in (NodeType.FUNCTION, NodeType.METHOD):
                symbol = node.name
                break

        assert symbol is not None

        result = get_impact(symbol=symbol)

        assert "callers_affected" in result
        assert result["callers_affected"] >= 0


class TestMCPVerifyOutput:
    """Tests for verify_output MCP tool."""

    def test_returns_passed_false_for_fake_function_names(self):
        """verify_output should return passed=False for code with fake function names."""
        graph = _build_test_graph()
        server = get_server(graph=graph)

        code = """
def my_function():
    nonexistent_function()
    fake_api_call()
    return True
"""
        result = verify_output(code=code, language="python")

        assert "passed" in result
        assert result["passed"] is False
        assert len(result["hallucinations"]) > 0

    def test_returns_passed_true_for_valid_code(self):
        """verify_output should return passed=True for valid code."""
        graph = _build_test_graph()
        server = get_server(graph=graph)

        real_symbol = None
        for node in graph.nodes:
            if node.type == NodeType.FUNCTION and not node.name.startswith("_"):
                real_symbol = node.name
                break

        if real_symbol:
            code = f"""
def my_function():
    {real_symbol}()
    return True
"""
            result = verify_output(code=code, language="python")
            assert "passed" in result
