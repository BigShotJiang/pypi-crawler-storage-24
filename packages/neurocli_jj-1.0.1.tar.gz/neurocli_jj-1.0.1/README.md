# ⚡ neurocli

> AI-powered terminal coding agent — free, fast, brutal.
> Like OpenCode but **100% free** using Gemini Flash + Groq.

```
 ███╗   ██╗███████╗██╗   ██╗██████╗  ██████╗  ██████╗██╗     ██╗
 ████╗  ██║██╔════╝██║   ██║██╔══██╗██╔═══██╗██╔════╝██║     ██║
 ██╔██╗ ██║█████╗  ██║   ██║██████╔╝██║   ██║██║     ██║     ██║
 ██║╚██╗██║██╔══╝  ██║   ██║██╔══██╗██║   ██║██║     ██║     ██║
 ██║ ╚████║███████╗╚██████╔╝██║  ██║╚██████╔╝╚██████╗███████╗██║
 ╚═╝  ╚═══╝╚══════╝ ╚═════╝ ╚═╝  ╚═╝ ╚═════╝  ╚═════╝╚══════╝╚═╝
```

---

## Project Structure

```
neurocli/              <- CLI agent (pip install)
├── neurocli/
│   ├── main.py        <- CLI + REPL
│   ├── agent.py       <- Agentic loop
│   ├── models.py      <- Gemini + Groq router
│   ├── tools.py       <- File/shell/git tools + undo
│   ├── tui.py         <- Rich cyberpunk TUI
│   ├── config.py      <- Settings + permission tiers
│   ├── session.py     <- SQLite history + stats
│   ├── memory.py      <- Persistent agent memory
│   ├── context.py     <- Git + file tree context
│   ├── bounty.py      <- Bug bounty scanner
│   ├── watch.py       <- File watcher
│   └── share.py       <- Session share client
├── pyproject.toml
├── install.sh
└── README.md

neurocli-server/       <- Share server (Render free deploy)
├── server.py          <- FastAPI + SSE live viewer
├── requirements.txt
└── render.yaml
```

---

## Quick Start

```bash
# Install
cd neurocli
pip install -e .

# Add free Gemini key (1000 req/day free)
# Get key at: https://aistudio.google.com/apikey
neurocli config --gemini-key YOUR_KEY

# Optional: Groq for ultra-fast responses (free)
# Get key at: https://console.groq.com
neurocli config --groq-key YOUR_GROQ_KEY

# Run inside any project
cd your-project
neurocli
```

---

## REPL Commands

| Command | What it does |
|---|---|
| `/undo` | Revert last AI file change |
| `/memory` | Show agent memory |
| `/stats` | Coding stats dashboard |
| `/bounty [file]` | Bug bounty scan |
| `/watch` | Live file watch mode |
| `/commit` | AI git commit |
| `/dry` | Toggle dry-run |
| `/tier read-only\|write-no-exec\|full-auto` | Change permissions |
| `/remember <note>` | Save to memory |
| `/quit` | Exit |

---

## Permission Tiers

| Tier | Read | Write | Execute |
|---|---|---|---|
| `read-only` | YES | NO | NO |
| `write-no-exec` | YES | YES | NO |
| `full-auto` | YES | YES | YES |

---

## Deploy Share Server (Free)

1. Push `neurocli-server/` to GitHub
2. Go to https://render.com → New Web Service
3. Connect repo → it reads `render.yaml` automatically
4. Deploy free
5. Set in `~/.neurocli/config.json`: `"share_server": "https://your-app.onrender.com"`

```bash
neurocli --share
# Sharing at: https://your-app.onrender.com/view/abc12345
```

---

## Publish to PyPI

```bash
pip install build twine
python -m build
twine upload dist/*
# pip install neurocli
```

---

MIT License — Janak Vasani — github.com/JnkVasani/neurocli
