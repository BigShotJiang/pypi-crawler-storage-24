"""
neurocli bounty — bug bounty mode: AI scans your codebase for issues
"""
import os
from pathlib import Path
from .context import SKIP_DIRS, is_sensitive

CODE_EXTENSIONS = {".py", ".js", ".ts", ".jsx", ".tsx", ".go", ".rs", ".java", ".c", ".cpp", ".rb", ".php", ".vue", ".svelte"}
MAX_FILES = 30
MAX_CHARS_PER_FILE = 3000


def collect_files(directory: str) -> list[dict]:
    """Collect all code files for review."""
    files = []
    for root, dirs, filenames in os.walk(directory):
        dirs[:] = [d for d in dirs if d not in SKIP_DIRS and not d.startswith(".")]
        for fname in filenames:
            if len(files) >= MAX_FILES:
                break
            fpath = os.path.join(root, fname)
            if Path(fpath).suffix not in CODE_EXTENSIONS:
                continue
            if is_sensitive(fpath):
                continue
            try:
                content = Path(fpath).read_text(errors="replace")[:MAX_CHARS_PER_FILE]
                rel = os.path.relpath(fpath, directory)
                files.append({"path": rel, "content": content})
            except Exception:
                pass
    return files


def build_bounty_prompt(files: list[dict], target: str = None) -> str:
    """Build the bug bounty analysis prompt."""
    if target:
        files = [f for f in files if target in f["path"]]

    file_blocks = []
    for f in files:
        file_blocks.append(f"### {f['path']}\n```\n{f['content']}\n```")

    files_str = "\n\n".join(file_blocks)

    return f"""You are a senior security engineer and code reviewer doing a bug bounty audit.

Analyze the following codebase thoroughly and find:
1. 🔴 Critical bugs (crashes, data loss, security holes)
2. 🟡 Logic errors and edge cases
3. 🔵 Performance issues
4. ⚠️  Security vulnerabilities (injection, auth bypass, exposed secrets, etc.)
5. 💡 Quick wins (simple improvements with high impact)

For each issue found:
- Cite the exact file and line/function
- Explain the problem clearly
- Suggest the fix

Be thorough. This is a full audit. Format with clear sections per file.

---

{files_str}
"""
