"""neurocli — AI-powered terminal coding agent"""
__version__ = "1.0.0"
