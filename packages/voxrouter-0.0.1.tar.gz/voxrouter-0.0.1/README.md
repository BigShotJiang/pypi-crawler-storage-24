# VoxRouter SDK for Python

Multi-provider router for real-time voice AI.

**Status:** Coming soon. This package reserves the name on PyPI.

- Website: [voxrouter.ai](https://voxrouter.ai)
- TypeScript SDK (available now): [npm](https://www.npmjs.com/package/voxrouter)
