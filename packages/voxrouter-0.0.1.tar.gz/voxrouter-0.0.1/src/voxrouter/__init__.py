"""VoxRouter SDK for Python — multi-provider voice AI router.

Website: https://voxrouter.ai
"""

__version__ = "0.0.1"
