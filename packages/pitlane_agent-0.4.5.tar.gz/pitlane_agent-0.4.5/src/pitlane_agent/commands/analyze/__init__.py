"""Analyze commands for generating F1 data visualizations.

This module provides commands for generating F1 visualizations including
lap times, tyre strategies, speed traces, position changes, and championship possibilities.
"""

from pitlane_agent.commands.analyze.championship_possibilities import generate_championship_possibilities_chart
from pitlane_agent.commands.analyze.driver_lap_compare import generate_multi_lap_chart, generate_year_compare_chart
from pitlane_agent.commands.analyze.driver_lap_list import generate_driver_lap_list
from pitlane_agent.commands.analyze.gear_shifts_map import generate_gear_shifts_map_chart
from pitlane_agent.commands.analyze.lap_times import generate_lap_times_chart
from pitlane_agent.commands.analyze.lap_times_distribution import generate_lap_times_distribution_chart
from pitlane_agent.commands.analyze.position_changes import generate_position_changes_chart
from pitlane_agent.commands.analyze.qualifying_results import generate_qualifying_results_chart
from pitlane_agent.commands.analyze.season_summary import generate_season_summary_chart
from pitlane_agent.commands.analyze.speed_trace import generate_speed_trace_chart
from pitlane_agent.commands.analyze.team_pace import generate_team_pace_chart
from pitlane_agent.commands.analyze.telemetry import generate_telemetry_chart
from pitlane_agent.commands.analyze.track_map import generate_track_map_chart
from pitlane_agent.commands.analyze.tyre_strategy import generate_tyre_strategy_chart

__all__ = [
    "generate_championship_possibilities_chart",
    "generate_driver_lap_list",
    "generate_gear_shifts_map_chart",
    "generate_lap_times_chart",
    "generate_lap_times_distribution_chart",
    "generate_multi_lap_chart",
    "generate_season_summary_chart",
    "generate_team_pace_chart",
    "generate_tyre_strategy_chart",
    "generate_speed_trace_chart",
    "generate_telemetry_chart",
    "generate_position_changes_chart",
    "generate_qualifying_results_chart",
    "generate_track_map_chart",
    "generate_year_compare_chart",
]
