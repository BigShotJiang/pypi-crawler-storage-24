"""OpenTelemetry tracing configuration for F1Agent tool calls.

This module provides simple console-based tracing to demonstrate what the agent
is doing during execution. Tracing is disabled by default and can be enabled via
environment variable or programmatically.

Thread Safety:
    This module uses module-level globals for tracer state and is designed for
    asyncio-based applications. It is async-safe (multiple coroutines can safely
    access the tracer concurrently) but NOT thread-safe. If you need to use this
    from multiple threads, you must add external synchronization.

    The lazy initialization in get_tracer() has a benign race condition: multiple
    concurrent calls may create multiple TracerProvider instances, but OpenTelemetry's
    global set_tracer_provider() handles this safely by using the last one set.
"""

import logging
import os
import sys
from contextlib import contextmanager
from typing import Any

from claude_agent_sdk.types import (
    HookContext,
    PostToolUseHookInput,
    SyncHookJSONOutput,
)
from opentelemetry import trace
from opentelemetry.sdk.resources import Resource
from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export import BatchSpanProcessor, ConsoleSpanExporter, SimpleSpanProcessor

# ANSI color codes
_RESET = "\033[0m"
_CYAN = "\033[36m"
_YELLOW = "\033[33m"


class _TraceFormatter(logging.Formatter):
    """Uvicorn-style colored formatter for trace output."""

    _LABEL_COLORS = {
        "TOOL": _CYAN,
        "DENIED": _YELLOW,
    }

    def format(self, record: logging.LogRecord) -> str:
        label = getattr(record, "trace_label", "TRACE")
        use_color = hasattr(sys.stderr, "isatty") and sys.stderr.isatty()
        if use_color:
            color = self._LABEL_COLORS.get(label, "")
            colored_label = f"{color}{label:<9}{_RESET}"
        else:
            colored_label = f"{label:<9}"
        return f"{colored_label}  {record.getMessage()}"


class _DynamicStderrHandler(logging.StreamHandler):
    """StreamHandler that re-evaluates sys.stderr on each emit (test-compatible)."""

    def emit(self, record: logging.LogRecord) -> None:
        self.stream = sys.stderr
        super().emit(record)


# Module-level trace logger — separate from app loggers, no propagation
_trace_logger = logging.getLogger("pitlane.trace")
_trace_logger.setLevel(logging.DEBUG)
_trace_logger.propagate = False
_trace_handler = _DynamicStderrHandler()
_trace_handler.setFormatter(_TraceFormatter())
_trace_logger.addHandler(_trace_handler)

# Global tracer instance
_tracer = None
_tracing_enabled = None  # None means use env var, True/False overrides env var
_provider_initialized = False


def is_tracing_enabled() -> bool:
    """Check if tracing is enabled via environment variable or programmatically.

    Returns:
        True if tracing is enabled, False otherwise.
        Programmatic setting (_tracing_enabled) overrides environment variable.
    """
    if _tracing_enabled is not None:
        # Programmatic setting overrides environment variable
        return _tracing_enabled
    # Fall back to environment variable
    return os.getenv("PITLANE_TRACING_ENABLED", "0") == "1"


def _initialize_tracer_provider() -> None:
    """Initialize the OpenTelemetry tracer provider with console exporter.

    This is called automatically when tracing is enabled. It sets up a console
    exporter that outputs to stderr to avoid mixing with agent responses.

    The span processor can be configured via PITLANE_SPAN_PROCESSOR environment
    variable:
    - "simple" (default): Uses SimpleSpanProcessor for synchronous export.
      Required for tests to ensure spans are flushed before assertions.
    - "batch": Uses BatchSpanProcessor for better production performance.
      Spans are exported asynchronously in batches.
    """
    global _provider_initialized

    if _provider_initialized:
        return

    # Create resource with service name
    resource = Resource.create({"service.name": "pitlane-f1-agent"})

    # Create tracer provider
    provider = TracerProvider(resource=resource)

    # Create console exporter (outputs to stderr)
    console_exporter = ConsoleSpanExporter(out=sys.stderr)

    # Create span processor based on configuration
    processor_type = os.getenv("PITLANE_SPAN_PROCESSOR", "simple").lower()
    if processor_type == "batch":
        span_processor = BatchSpanProcessor(console_exporter)
    else:
        # Default to SimpleSpanProcessor for test compatibility
        span_processor = SimpleSpanProcessor(console_exporter)

    provider.add_span_processor(span_processor)

    # Set as global tracer provider
    trace.set_tracer_provider(provider)

    _provider_initialized = True


def get_tracer() -> trace.Tracer:
    """Get the OpenTelemetry tracer instance.

    Lazily initializes the tracer provider if tracing is enabled.

    Note:
        This function has a benign race condition when called concurrently
        from multiple coroutines during initial startup. Multiple TracerProvider
        instances may be created, but this is harmless as OpenTelemetry's global
        tracer provider is set atomically.

    Returns:
        Tracer instance (may be a no-op tracer if tracing is disabled).
    """
    global _tracer

    if not is_tracing_enabled():
        # Return no-op tracer if tracing is disabled
        return trace.get_tracer(__name__)

    if _tracer is None:
        _initialize_tracer_provider()
        _tracer = trace.get_tracer(__name__, "0.1.0")

    return _tracer


def enable_tracing() -> None:
    """Programmatically enable tracing.

    This overrides the PITLANE_TRACING_ENABLED environment variable.
    """
    global _tracing_enabled
    _tracing_enabled = True


def disable_tracing() -> None:
    """Programmatically disable tracing."""
    global _tracing_enabled
    _tracing_enabled = False


@contextmanager
def tool_span(tool_name: str, **attributes: Any):
    """Create a span for a tool call with minimal console output.

    This context manager creates a span with the tool name and optional
    attributes. The console exporter will output a simple log line like:
    [TOOL] ToolName: key_parameter

    Args:
        tool_name: Name of the tool being called (e.g., "Bash", "Skill", "WebFetch").
        **attributes: Span attributes to record (e.g., tool.key_param, tool.permission).

    Example:
        with tool_span("Bash", **{"tool.key_param": "ls -la"}):
            # Execute tool
            pass
    """
    tracer = get_tracer()

    if not is_tracing_enabled():
        # If tracing is disabled, just yield without creating a span
        yield None
        return

    with tracer.start_as_current_span(f"tool.{tool_name}") as span:
        # Set tool name attribute
        span.set_attribute("tool.name", tool_name)

        # Set additional attributes
        for key, value in attributes.items():
            if value is not None:
                span.set_attribute(key, str(value))

        # Log minimal console output
        log_tool_call(tool_name, attributes)

        yield span


def log_tool_call(tool_name: str, attributes: dict[str, Any]) -> None:
    """Log a minimal tool call to stderr.

    Format: [TOOL] ToolName: key_parameter

    Args:
        tool_name: Name of the tool.
        attributes: Span attributes.
    """
    key_param = attributes.get("tool.key_param", "")
    permission = attributes.get("tool.permission", "")
    denial_reason = attributes.get("tool.denial_reason", "")

    # Build output message
    if permission == "denied":
        msg = f"{tool_name}: {key_param} → DENIED"
        if denial_reason:
            msg += f" ({denial_reason})"
        _trace_logger.warning(msg, extra={"trace_label": "DENIED"})
    else:
        msg = f"{tool_name}: {key_param}"
        _trace_logger.info(msg, extra={"trace_label": "TOOL"})


def log_permission_check(tool_name: str, allowed: bool, reason: str = "") -> None:
    """Log a permission check result.

    This is called from the permission callback to show when tools are
    denied access.

    Args:
        tool_name: Name of the tool.
        allowed: Whether the tool was allowed.
        reason: Reason for denial (if denied).
    """
    if not is_tracing_enabled():
        return

    if not allowed:
        msg = f"{tool_name} → DENIED"
        if reason:
            msg += f": {reason}"
        _trace_logger.warning(msg, extra={"trace_label": "DENIED"})


# Hook callbacks for Claude Agent SDK


async def post_tool_use_hook(
    hook_input: PostToolUseHookInput,
    block_reason: str | None,
    hook_context: HookContext,
) -> SyncHookJSONOutput:
    """Hook called after a tool is executed.

    Currently just continues execution. Could be extended to log results.

    Args:
        hook_input: Input data including tool_name, tool_input, and tool_response.
        block_reason: Reason if the tool was blocked (unused).
        hook_context: Hook context (unused).

    Returns:
        SyncHookJSONOutput to continue execution.
    """
    # For minimal output, we don't log post-tool results
    # This hook is here for potential future enhancements
    return SyncHookJSONOutput(continue_=True)


def _shorten_path(path: str) -> str:
    """Replace home and cwd prefixes in a path with ~ and . respectively."""
    if not path:
        return path
    home = os.path.expanduser("~")
    cwd = os.getcwd()
    if path.startswith(cwd + os.sep):
        return "." + path[len(cwd) :]
    if path.startswith(home + os.sep):
        return "~" + path[len(home) :]
    return path


def extract_key_param(tool_name: str, tool_input: dict[str, Any]) -> str:
    """Extract the most relevant parameter from tool input for logging.

    Args:
        tool_name: Name of the tool.
        tool_input: Tool input parameters.

    Returns:
        A string representing the key parameter for this tool.
    """
    if tool_name == "Bash":
        return tool_input.get("command", "")
    elif tool_name == "Skill":
        return tool_input.get("skill", "")
    elif tool_name == "WebFetch":
        return tool_input.get("url", "")
    elif tool_name == "Read" or tool_name == "Write" or tool_name == "Edit":
        return _shorten_path(tool_input.get("file_path", ""))
    else:
        # For unknown tools, try to get a reasonable representation
        if tool_input:
            # Get first non-empty value
            for value in tool_input.values():
                if value:
                    return str(value)[:100]
        return ""
