import base64
import requests
from pathlib import Path

BASE_URL = "https://api.geoaxis.ai"
ACCEPTED_FORMATS = {"png", "jpg", "jpeg", "heic", "bmp", "webp"}


class GeoAxisError(Exception):
    """Raised when the GeoAxis API returns a non-2xx response."""

    def __init__(self, status_code: int, message: str, data: dict = None):
        self.status_code = status_code
        self.data = data or {}
        super().__init__(f"[{status_code}] {message}")


def _raise_for_status(resp: requests.Response) -> requests.Response:
    if not resp.ok:
        try:
            data = resp.json()
            msg = data.get("error", resp.text)
        except Exception:
            data = {}
            msg = resp.text
        raise GeoAxisError(resp.status_code, msg, data)
    return resp


def _validate_image_path(path: Path) -> str:
    ext = path.suffix.lstrip(".").lower()
    if ext not in ACCEPTED_FORMATS:
        raise ValueError(f"Unsupported format '{ext}'. Accepted: {ACCEPTED_FORMATS}")
    return ext


# ---------------------------------------------------------------------------
# Auth-free helpers
# ---------------------------------------------------------------------------

def health() -> dict:
    """
    Check server health and model status.

    No authentication required.

    Returns:
        dict with keys: status, model_loaded, device, indexes_loaded,
        total_vectors, gemini_available, queue.
    """
    resp = requests.get(f"{BASE_URL}/api/health")
    _raise_for_status(resp)
    return resp.json()


def queue() -> dict:
    """
    Check the current request queue depth.

    No authentication required.

    Returns:
        dict with keys: queue_length, active, total_processed.
    """
    resp = requests.get(f"{BASE_URL}/api/queue")
    _raise_for_status(resp)
    return resp.json()


# ---------------------------------------------------------------------------
# Authenticated client
# ---------------------------------------------------------------------------

class GeoAxis:
    """
    Python client for the GeoAxis image geolocation API.

    Args:
        token: Your Firebase ID token (Bearer token).

    Example::

        import pygeoaxis

        client = pygeoaxis.GeoAxis(token="<your_firebase_id_token>")

        # List available cities
        cities = client.locations()

        # Search a specific city
        result = client.search_city("photo.jpg", city_path="US/Texas/Dallas", k=5)
        for r in result["results"]:
            print(r["lat"], r["lng"], r["score"])

        # Global search
        result = client.search_global("photo.jpg", context="somewhere in Europe")
        loc = result["location"]
        print(loc["location_name"], loc["country"], loc["confidence"])
    """

    def __init__(self, token: str):
        if not token:
            raise ValueError("A Firebase ID token is required.")
        self.session = requests.Session()
        self.session.headers["Authorization"] = f"Bearer {token}"

    # ------------------------------------------------------------------
    # Locations
    # ------------------------------------------------------------------

    def locations(self) -> list:
        """
        List all available indexed city paths.

        Returns:
            list of location dicts, each containing at least a 'path' key,
            e.g. [{"path": "US/Texas/Dallas"}, ...].
        """
        resp = self.session.get(f"{BASE_URL}/api/locations")
        _raise_for_status(resp)
        return resp.json()["locations"]

    # ------------------------------------------------------------------
    # Search — city-specific
    # ------------------------------------------------------------------

    def search_city(self, image, city_path: str, k: int = 10) -> dict:
        """
        Search a specific city index and return ranked GPS coordinates.

        Args:
            image:      File path (str or Path) **or** raw image bytes.
                        Accepted formats: PNG, JPG, JPEG, HEIC, BMP, WebP.
                        Max size: 16 MB.
            city_path:  City index path, e.g. ``"US/Texas/Dallas"``.
                        Use :meth:`locations` to see all available values.
            k:          Number of results to return (default: 10).

        Returns:
            dict with keys:

            - ``success`` (bool)
            - ``search_type`` (str) — ``"city"``
            - ``city_path`` (str)
            - ``results`` (list) — each item has ``lat``, ``lng``, ``score``
            - ``total`` (int)
            - ``timing`` (dict) — ``feature_extraction_ms``, ``index_search_ms``, ``total_ms``

        Raises:
            GeoAxisError: On any non-2xx API response.
            ValueError: If the image format is not supported.
            TypeError: If ``image`` is not a path or bytes.
        """
        if isinstance(image, (str, Path)):
            path = Path(image)
            ext = _validate_image_path(path)
            with open(path, "rb") as f:
                resp = self.session.post(
                    f"{BASE_URL}/api/search",
                    files={"image": (path.name, f, f"image/{ext}")},
                    data={"city_path": city_path, "k": str(k)},
                )
        elif isinstance(image, bytes):
            resp = self.session.post(
                f"{BASE_URL}/api/search",
                json={
                    "image_base64": base64.b64encode(image).decode(),
                    "city_path": city_path,
                    "k": k,
                },
            )
        else:
            raise TypeError("image must be a file path (str/Path) or bytes")

        _raise_for_status(resp)
        return resp.json()

    # ------------------------------------------------------------------
    # Search — global
    # ------------------------------------------------------------------

    def search_global(self, image, context: str = None) -> dict:
        """
        Search anywhere in the world using Gemini AI.

        Args:
            image:    File path (str or Path) **or** raw image bytes.
                      Accepted formats: PNG, JPG, JPEG, HEIC, BMP, WebP.
                      Max size: 16 MB.
            context:  Optional location hint to improve accuracy,
                      e.g. ``"somewhere in Europe"`` or ``"tropical coast"``.

        Returns:
            dict with a ``location`` key containing:

            - ``lat``, ``lng`` (float)
            - ``radius_km``, ``radius_meters`` (float)
            - ``confidence`` (float, 0–1)
            - ``location_name`` (str)
            - ``country`` (str)
            - ``analysis_summary`` (str)
            - ``key_indicators`` (list of str)

        Raises:
            GeoAxisError: On any non-2xx API response.
            ValueError: If the image format is not supported.
            TypeError: If ``image`` is not a path or bytes.
        """
        if isinstance(image, (str, Path)):
            path = Path(image)
            ext = _validate_image_path(path)
            data = {"global": "true"}
            if context:
                data["context"] = context
            with open(path, "rb") as f:
                resp = self.session.post(
                    f"{BASE_URL}/api/search",
                    files={"image": (path.name, f, f"image/{ext}")},
                    data=data,
                )
        elif isinstance(image, bytes):
            body = {
                "image_base64": base64.b64encode(image).decode(),
                "global": True,
            }
            if context:
                body["context"] = context
            resp = self.session.post(f"{BASE_URL}/api/search", json=body)
        else:
            raise TypeError("image must be a file path (str/Path) or bytes")

        _raise_for_status(resp)
        return resp.json()
