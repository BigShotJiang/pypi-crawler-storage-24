import sys
import threading
import socket
import time
import os
import ctypes
import json
import asyncio
import re
import datetime
import subprocess
import tkinter as tk
from tkinter import scrolledtext, filedialog, messagebox, ttk
from dnslib import DNSRecord, QTYPE, RR, A
from zeroconf import ServiceInfo, Zeroconf
from fastapi import FastAPI, Response, Request
from starlette.middleware.base import BaseHTTPMiddleware
import uvicorn
# --- ТВОЙ КРИТИЧЕСКИЙ БЛОК ДЛЯ PYINSTALLER ---
import uvicorn.logging
import uvicorn.loops.auto
import uvicorn.protocols.http.h11_impl
import uvicorn.lifespan.on
# ----------------------------------------------

# --- КОНСТАНТЫ ДИЗАЙНА ---
THEME = {
    "bg": "#0d1117",
    "fg": "#c9d1d9",
    "accent": "#58a6ff",
    "danger": "#f85149",
    "success": "#3fb950",
    "panel": "#161b22",
    "terminal": "#010409"
}

LOGO = r"""
 ██████╗██╗██████╗ ██████╗      ██╗  ██╗██╗     ██████╗ ███╗   ██╗███████╗
██╔════╝██║██╔══██╗╚════██╗     ██║  ██║██║     ██╔══██╗████╗  ██║██╔════╝
██║     ██║██████╔╝ █████╔╝     ███████║██║     ██║  ██║██╔██╗ ██║███████╗
██║     ██║██╔══██╗██╔═══╝      ██╔══██║██║     ██║  ██║██║╚██╗██║╚════██║
╚██████╗██║██║  ██║███████╗     ██║  ██║███████╗██████╔╝██║ ╚████║███████║
 ╚═════╝╚═╝╚═╝  ╚═╝╚══════╝     ╚═╝  ╚═╝╚══════╝╚═════╝ ╚═╝  ╚═══╝╚══════╝ v2.0.0
       >> ADVANCED NETWORK CONTROL SUITE | HioSW CIR2 GENERATION <<
"""

# =================================================================
# ⚙️ CIR2_CORE: АСИНХРОННЫЙ ДВИЖОК
# =================================================================
class CIR2_Core:
    def __init__(self, log_func=None):
        self.log_callback = log_func or print
        self.domains = {}
        self.html_content = self._default_html()
        self.dns_port, self.web_port = 53, 80
        self.rate_limit = 50
        self.ddos_protect = True
        self.request_history = []
        self.start_time = time.time()
        self.is_running = False
        self.my_ip = self.get_lan_ip()
        
        # Класс-обертка для портов
        class PortConfig:
            def __init__(self, outer): self.outer = outer
            def set(self, t1, p1, t2, p2):
                self.outer.dns_port, self.outer.web_port = p1, p2
                self.outer.log(f"CONFIG: Ports set to DNS:{p1}, WEB:{p2}")
        self.port = PortConfig(self)

    def log(self, msg):
        self.log_callback(msg)

    def _default_html(self):
        return """<html><body style='background:#0d1117;color:#58a6ff;font-family:sans-serif;text-align:center;padding-top:20%'>
                  <h1>CIR2 ENGINE ACTIVE</h1><p>Local Domain Server by HioSW</p></body></html>"""

    def get_lan_ip(self):
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        try:
            s.connect(('1.1.1.1', 80))
            ip = s.getsockname()[0]
        except: ip = '127.0.0.1'
        finally: s.close()
        return ip

    def patch_hosts(self, domain, ip, remove=False):
        path = r'C:\Windows\System32\drivers\etc\hosts'
        try:
            os.system(f'attrib -r {path}')
            with open(path, 'r', encoding='utf-8') as f: lines = f.readlines()
            # Фильтруем старые записи CIR
            new_lines = [l for l in lines if domain.strip() not in l]
            if not remove:
                new_lines.append(f"{ip} {domain} # [CIR2_ENTRY]\n")
            with open(path, 'w', encoding='utf-8') as f: f.writelines(new_lines)
            os.system('ipconfig /flushdns >nul')
            self.log(f"HOSTS: {'Dropped' if remove else 'Mapped'} {domain}")
        except PermissionError:
            self.log("⚠️ PERMISSION ERROR: Run as Administrator!")

    def hard_reset_adapter(self):
        self.log("NETWORK: Performing hard reset of DNS cache...")
        subprocess.run(["ipconfig", "/release"], capture_output=True)
        subprocess.run(["ipconfig", "/renew"], capture_output=True)
        subprocess.run(["ipconfig", "/flushdns"], capture_output=True)
        self.log("NETWORK: Adapter re-synced.")

    def clear_system(self):
        self.log("SMN: Full system rollback in progress...")
        for domain in list(self.domains.keys()):
            self.patch_hosts(domain, "", True)
        self.log("SMN: Cleanup complete. Terminal exit.")
        os._exit(0)

    def __call__(self, domain, ip):
        self.domains[domain] = ip
        self.patch_hosts(domain, ip)
        self.log(f"DNS_MAP: {domain} -> {ip}")

    def set(self, path):
        try:
            with open(path, "r", encoding="utf-8") as f:
                self.html_content = f.read()
            self.log(f"CONTENT: Injected {os.path.basename(path)}")
        except Exception as e:
            self.log(f"ERROR: Failed to load HTML: {e}")

    def updateset(self):
        self.log("CORE: Metadata updated.")

    def chldns(self, p, m):
        self.log(f"RECORD: Registered {p} as {m}")

    def lan_broadcast(self):
        self.log("BEACON: Sending UDP signals to LAN...")
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
        msg = f"CIR2_BEACON|{self.my_ip}|{self.web_port}".encode()
        sock.sendto(msg, ('255.255.255.255', 5555))

    def scan_network(self):
        self.log("SCANNER: Starting quick LAN scan...")
        # Упрощенный сканер для демонстрации CIR2
        def run_scan():
            for i in range(100, 110):
                target = f"192.168.1.{i}"
                self.log(f"SCAN: Probing {target}...")
                time.sleep(0.1)
            self.log("SCANNER: Completed.")
        threading.Thread(target=run_scan, daemon=True).start()

    def showme(self):
        self.log("MDNS: Publishing Zeroconf records...")
        zc = Zeroconf()
        for name in self.domains:
            info = ServiceInfo("_http._tcp.local.", f"{name}._http._tcp.local.",
                               addresses=[socket.inet_aton(self.my_ip)],
                               port=self.web_port, properties={'engine': 'CIR2'})
            zc.register_service(info)

    def run_all(self):
        if self.is_running: return
        self.is_running = True
        
        # 1. DNS SERVER (THREADED)
        def dns_service():
            sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            try:
                sock.bind(('0.0.0.0', self.dns_port))
                while True:
                    data, addr = sock.recvfrom(512)
                    packet = DNSRecord.parse(data)
                    qname = str(packet.q.qname).rstrip('.')
                    reply = packet.reply()
                    if qname in self.domains:
                        reply.add_answer(RR(qname, QTYPE.A, rdata=A(self.domains[qname])))
                        self.log(f"DNS: {qname} resolved for {addr[0]}")
                    sock.sendto(reply.pack(), addr)
            except Exception as e:
                self.log(f"DNS_CRITICAL: {e}")

        threading.Thread(target=dns_service, daemon=True).start()

        # 2. WEB SERVER (FASTAPI)
        app = FastAPI(title="CIR2_Web")
        
        @app.middleware("http")
        async def security_layer(request: Request, call_next):
            if self.ddos_protect:
                now = time.time()
                self.request_history = [t for t in self.request_history if now - t < 1]
                if len(self.request_history) > self.rate_limit:
                    self.log(f"FIREWALL: Blocked flood from {request.client.host}")
                    return Response("429 Too Many Requests", status_code=429)
                self.request_history.append(now)
            return await call_next(request)

        @app.get("/")
        async def entry():
            return Response(content=self.html_content, media_type="text/html")

        def web_service():
            self.log(f"HTTP: CIR2 Listener active on port {self.web_port}")
            uvicorn.run(app, host="0.0.0.0", port=self.web_port, log_level="error", reload=False)

        threading.Thread(target=web_service, daemon=True).start()

# =================================================================
# 💎 CIR2_GUI: СТЕКЛЯННЫЙ ДИЗАЙН (MODERN UI)
# =================================================================
class CIR2_GUI:
    def __init__(self, root):
        self.root = root
        self.root.title("CIR2: HLDNS COMMAND CENTER")
        self.root.geometry("900x750")
        self.root.configure(bg=THEME["bg"])
        
        self.core = CIR2_Core(self.write_log)
        self.apply_styles()
        self.build_ui()
        self.write_log(LOGO)
        self.monitor_loop()

    def apply_styles(self):
        style = ttk.Style()
        style.theme_use('clam')
        style.configure("TFrame", background=THEME["bg"])
        style.configure("Header.TLabel", background=THEME["bg"], foreground=THEME["accent"], font=("Segoe UI", 18, "bold"))
        style.configure("Stat.TLabel", background=THEME["panel"], foreground=THEME["fg"], font=("Consolas", 10))
        style.configure("Action.TButton", font=("Segoe UI", 10, "bold"), background=THEME["accent"], foreground="white")

    def build_ui(self):
        # --- TOP STATUS BAR ---
        self.top_bar = tk.Frame(self.root, bg=THEME["panel"], height=40)
        self.top_bar.pack(fill=tk.X)
        
        self.lbl_ip = tk.Label(self.top_bar, text=f"🌐 LAN IP: {self.core.my_ip}", bg=THEME["panel"], fg=THEME["success"], font=("Consolas", 10))
        self.lbl_ip.pack(side=tk.LEFT, padx=20)
        
        self.lbl_timer = tk.Label(self.top_bar, text="⏱ UPTIME: 0s", bg=THEME["panel"], fg=THEME["fg"], font=("Consolas", 10))
        self.lbl_timer.pack(side=tk.RIGHT, padx=20)

        # --- MAIN CONFIG PANEL ---
        config_p = tk.Frame(self.root, bg=THEME["bg"], pady=20)
        config_p.pack(fill=tk.X, padx=40)

        tk.Label(config_p, text="TARGET DOMAIN NAME:", bg=THEME["bg"], fg=THEME["accent"], font=("Segoe UI", 10)).pack(anchor="w")
        self.ent_domain = tk.Entry(config_p, bg=THEME["panel"], fg="#fff", font=("Consolas", 16), borderwidth=0, insertbackground="white")
        self.ent_domain.insert(0, "project.local")
        self.ent_domain.pack(fill=tk.X, pady=10, ipady=8)

        # --- BUTTONS ---
        btn_frame = tk.Frame(self.root, bg=THEME["bg"])
        btn_frame.pack(fill=tk.X, padx=40)

        tk.Button(btn_frame, text="📁 SELECT SOURCE", bg="#30363d", fg=THEME["fg"], bd=0, padx=15, pady=8, command=self.select_file).pack(side=tk.LEFT, padx=5)
        self.btn_launch = tk.Button(btn_frame, text="🚀 LAUNCH CIR2", bg=THEME["success"], fg="white", bd=0, padx=25, pady=8, font="bold", command=self.launch)
        self.btn_launch.pack(side=tk.LEFT, padx=5)
        tk.Button(btn_frame, text="🧹 DEEP CLEAN", bg=THEME["danger"], fg="white", bd=0, padx=15, pady=8, command=self.core.clear_system).pack(side=tk.RIGHT, padx=5)

        # --- TERMINAL ---
        tk.Label(self.root, text="ENGINE REAL-TIME LOGS:", bg=THEME["bg"], fg="#8b949e", font=("Segoe UI", 9)).pack(anchor="w", padx=40, pady=(20,0))
        self.log_area = scrolledtext.ScrolledText(self.root, bg=THEME["terminal"], fg=THEME["success"], font=("Consolas", 10), borderwidth=0, highlightthickness=1, highlightbackground="#30363d")
        self.log_area.pack(fill=tk.BOTH, expand=True, padx=40, pady=10)

        # --- FOOTER ---
        footer = tk.Label(self.root, text="HioSW CIR2 SUITE • VERSION 2.0.0 • STABLE ENGINE", bg=THEME["bg"], fg="#484f58", font=("Segoe UI", 8))
        footer.pack(pady=5)

    def write_log(self, msg):
        ts = datetime.datetime.now().strftime("%H:%M:%S")
        self.log_area.insert(tk.END, f"[{ts}] {msg}\n")
        self.log_area.see(tk.END)

    def monitor_loop(self):
        uptime = int(time.time() - self.core.start_time)
        self.lbl_timer.config(text=f"⏱ UPTIME: {uptime}s")
        # Динамическое обновление IP если сменился
        self.root.after(1000, self.monitor_loop)

    def select_file(self):
        path = filedialog.askopenfilename(filetypes=[("Web Content", "*.html")])
        if path: self.core.set(path)

    def launch(self):
        dom = self.ent_domain.get().strip()
        if not dom: return
        self.btn_launch.config(state="disabled", text="RUNNING...", bg="#21262d")
        
        def run_thread():
            self.core(dom, self.core.my_ip) # Каноничная регистрация
            self.core.lan_broadcast()      # Анонс в сеть
            self.core.showme()             # mDNS
            self.core.run_all()            # Старт серверов
            
        threading.Thread(target=run_thread, daemon=True).start()

def main_run():
    # Проверка прав администратора
    try:
        is_admin = ctypes.windll.shell32.IsUserAnAdmin()
    except:
        is_admin = False
        
    if not is_admin:
        ctypes.windll.shell32.ShellExecuteW(None, "runas", sys.executable, __file__, None, 1)
        return
        
    root = tk.Tk()
    app = CIR2_GUI(root)
    root.mainloop()

if __name__ == "__main__":
    main_run()
