from .CIR_HLDNS import CIR2_Core, CIR2_GUI
import sys

# Инициализация синглтона CIR2
_engine = CIR2_Core()

# Твой каноничный декоративный API v2.0
getip = lambda n, f: _engine.get_lan_ip()
localdomain = _engine
smn = type('obj', (object,), {
    'clear': _engine.clear_system,
    'reset_network': _engine.hard_reset_adapter,
    'history': lambda: _engine.log("HISTORY: Logs saved to disk")
})

server = type('obj', (object,), {
    'updateset': _engine.updateset,
    'start': _engine.run_all,
    'config': type('obj', (object,), {
        'port': _engine.port.set,
        'threads': lambda n: _engine.log(f"THREADS: Set to {n}")
    }),
    'max': type('obj', (object,), {
        'req': lambda n: setattr(_engine, 'rate_limit', n),
        'bandwidth': lambda n: _engine.log(f"NET: Speed limit {n}MB/s")
    }),
    'security': type('obj', (object,), {
        'antiddos': lambda b: setattr(_engine, 'ddos_protect', b),
        'stealth': lambda: _engine.log("SEC: Stealth mode ACTIVE")
    })
})

servers = type('obj', (object,), {
    'showme': _engine.showme,
    'broadcast': _engine.lan_broadcast,
    'scan': _engine.scan_network,
    'alert': lambda *a: _engine.log(f"⚠️ ALERT: {a}")
})
