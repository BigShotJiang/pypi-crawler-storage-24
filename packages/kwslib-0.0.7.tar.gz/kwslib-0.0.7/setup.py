from setuptools import setup

setup(
    packages=[
        "kwslib",
        "kwslib.api",
        "kwslib.standards",
        "kwslib.training",
        "kwslib.utils",
    ],
    include_package_data=False,
)
