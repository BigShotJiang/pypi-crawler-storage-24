"""
KWS High-Level API – Lớp trừu tượng cao, đa dụng, dễ dùng cho KWS_Lib.

3 class chính:
- KWSSession: Đăng nhập & giữ client API.
- DatasetPipeline: Chia tập, lấy dữ liệu, tải mảng đặc trưng từ split.
- ModelManager: Quản lý model, experiment run, metrics, artifact lên DB.

Luồng điển hình: Session → Pipeline (chia & load data) → ModelManager (đăng ký run, metrics, artifact).
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple, Union, cast
from io import BytesIO

import numpy as np
import pandas as pd
import requests

from . import KWSClient, build_metrics_payload
from .data_loading import SplitDataLoader
from .minio_client import SplitFilesClient

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# 1. KWSSession – Đăng nhập
# ---------------------------------------------------------------------------


class KWSSession:
    """
    Phiên làm việc KWS: kết nối API và đăng nhập.
    Dùng làm điểm vào duy nhất cho các class cao cấp (DatasetPipeline, ModelManager).
    """

    def __init__(
        self,
        base_url: str = "http://localhost:8000",
        username: Optional[str] = None,
        password: Optional[str] = None,
        *,
        token: Optional[str] = None,
        api_key: Optional[str] = None,
    ):
        """
        Args:
            base_url: URL backend KWS (vd: http://localhost:8000).
            username: Username đăng nhập (bỏ qua nếu dùng token/api_key).
            password: Password đăng nhập.
            token: JWT sẵn có (không cần login).
            api_key: API key thay JWT.
        """
        self._client = KWSClient(
            base_url=base_url,
            token=token,
            api_key=api_key,
        )
        if username and password:
            self._client.login(username=username, password=password)
            logger.info("Đăng nhập thành công.")
        self._files_client = SplitFilesClient(self._client)

    @property
    def api(self) -> KWSClient:
        """Client API đã đăng nhập."""
        return self._client

    @property
    def client(self) -> KWSClient:
        """Alias của api."""
        return self._client

    @property
    def files_client(self) -> SplitFilesClient:
        """Client tải file split (MinIO)."""
        return self._files_client

    def login(self, username: str, password: str) -> Dict[str, Any]:
        """Đăng nhập (hoặc đăng nhập lại)."""
        return self._client.login(username=username, password=password)


# ---------------------------------------------------------------------------
# 2. DatasetPipeline – Chia tập & lấy dữ liệu
# ---------------------------------------------------------------------------


class DatasetPipeline:
    """
    Pipeline chia tập và lấy dữ liệu: lấy raw data → lọc class → chia train/test → đẩy DB → tải mảng.
    """

    def __init__(self, session: KWSSession):
        self._session = session
        self._api = session.api
        self._data_loader = SplitDataLoader(self._api, session.files_client)

    def get_data(
        self,
        dataset_version_id: int,
        feature_type_id: Optional[int] = None,
        keyword_ids: Optional[List[int]] = None,
    ) -> pd.DataFrame:
        """
        Lấy toàn bộ dữ liệu feature (MFCC) từ API.
        Returns:
            DataFrame với cột: feature_id, sample_id, keyword_id, keyword_name, file_name, minio_path, feature_type_id.
        """
        df = self._api.dataset_splits.get_mfcc_files(
            dataset_version_id=dataset_version_id,
            feature_type_id=feature_type_id,
            keyword_ids=keyword_ids,
        )
        logger.info(f"Lấy dữ liệu: {len(df)} mẫu.")
        return df

    def filter_classes(
        self,
        df: pd.DataFrame,
        class_names: List[str],
        label_column: str = "derivative_label",
    ) -> pd.DataFrame:
        """
        Chỉ giữ các dòng có keyword_name nằm trong class_names.
        Tạo cột derivative_label = keyword_name (để dùng khi push split).
        """
        out = cast(pd.DataFrame, df[df["keyword_name"].isin(class_names)].copy())
        out[label_column] = out["keyword_name"]
        logger.info(f"Sau lọc {len(class_names)} class: {len(out)} mẫu.")
        return out

    def split_and_push(
        self,
        df: pd.DataFrame,
        config_name: str,
        dataset_version_id: int,
        train_size: float = 0.8,
        test_size: float = 0.2,
        val_size: float = 0.0,
        random_state: int = 42,
        stratify: bool = True,
        create_merged_keywords: Optional[Dict[str, List[int]]] = None,
        auto_detect_merged_keywords: bool = True,
    ) -> Dict[str, int]:
        """
        Chia df thành train/test (và val nếu val_size > 0), đẩy lên DB.
        Args:
            df: DataFrame có cột feature_id, keyword_id, derivative_label (và keyword_name để auto-detect merge).
            config_name: Tên cấu hình split (vd: config_10class_80_20).
            dataset_version_id: ID phiên bản dataset.
            train_size, test_size, val_size: Tỷ lệ (train_size + test_size + val_size = 1.0).
            random_state, stratify: Cho train_test_split.
        Returns:
            Dict split_name -> split_id, vd: {"train": 123, "test": 124} hoặc {"train": 123, "val": 124, "test": 125}.
        """
        if abs(train_size + test_size + val_size - 1.0) > 1e-6:
            raise ValueError("train_size + test_size + val_size phải bằng 1.0")

        stratify_col = df["derivative_label"] if stratify else None

        if val_size <= 0:
            from sklearn.model_selection import train_test_split  # type: ignore[import-untyped]
            train_df, test_df = train_test_split(
                df, train_size=train_size, test_size=test_size,
                random_state=random_state, stratify=stratify_col,
            )
            splits = {"train": train_df, "test": test_df}
        else:
            from sklearn.model_selection import train_test_split  # type: ignore[import-untyped]
            # train vs (val+test)
            train_df, rest_df = train_test_split(
                df, train_size=train_size, test_size=(val_size + test_size),
                random_state=random_state, stratify=stratify_col,
            )
            rest_stratify = rest_df["derivative_label"] if stratify else None
            val_ratio = val_size / (val_size + test_size) if (val_size + test_size) > 0 else 0
            val_df, test_df = train_test_split(
                rest_df, train_size=val_ratio, test_size=(1 - val_ratio),
                random_state=random_state, stratify=rest_stratify,
            )
            splits = {"train": train_df, "val": val_df, "test": test_df}

        created = self._push_splits(
            dataset_version_id=dataset_version_id,
            config_name=config_name,
            splits=splits,
            create_merged_keywords=create_merged_keywords,
            auto_detect_merged_keywords=auto_detect_merged_keywords,
        )
        return created

    def _push_splits(
        self,
        dataset_version_id: int,
        config_name: str,
        splits: Dict[str, pd.DataFrame],
        create_merged_keywords: Optional[Dict[str, List[int]]] = None,
        auto_detect_merged_keywords: bool = True,
    ) -> Dict[str, int]:
        """Đẩy các split lên DB (gọi create_split_from_list từng split)."""
        required = ["feature_id", "keyword_id", "derivative_label"]
        for name, frame in splits.items():
            if frame.empty:
                continue
            missing = [c for c in required if c not in frame.columns]
            if missing:
                raise ValueError(f"Split '{name}' thiếu cột: {missing}")

        merged = create_merged_keywords
        if auto_detect_merged_keywords and merged is None:
            first_name = next(iter(splits))
            first_df = splits[first_name]
            if not first_df.empty and "keyword_name" in first_df.columns:
                groups = first_df.groupby("keyword_name")["keyword_id"].unique()
                merged = {
                    str(k): [int(x) for x in sorted(v.tolist())]
                    for k, v in groups.items()
                    if len(v) > 1
                }
                if merged:
                    logger.info(f"Auto-detected merged keywords: {list(merged)}")

        first_split_name = next(iter(splits))
        created_splits: Dict[str, int] = {}
        for split_name, split_df in splits.items():
            if split_df.empty:
                continue
            files: List[Dict[str, Any]] = []
            for row in split_df[["feature_id", "keyword_id", "derivative_label"]].itertuples(index=False, name=None):
                feature_id, keyword_id, derivative_label = row
                item: Dict[str, Any] = {
                    "feature_id": int(feature_id),
                    "keyword_id": int(keyword_id),
                }
                if pd.notna(derivative_label) and str(derivative_label).strip():
                    item["derivative_label"] = str(derivative_label).strip()
                else:
                    item["derivative_label"] = None
                files.append(item)

            use_merged = merged if split_name == first_split_name else None
            resp = self._api.dataset_splits.create_split_from_list(
                dataset_version_id=dataset_version_id,
                split_name=split_name,
                config_name=config_name,
                files=files,
                create_merged_keywords=use_merged,
            )
            sid_raw = resp.get("dataset_splits_id") or resp.get("id")
            if sid_raw is None:
                raise ValueError(f"API did not return split id for '{split_name}'")
            sid = int(sid_raw)
            created_splits[split_name] = sid
            logger.info(f"Đã tạo split '{split_name}' (ID: {sid}).")
        return created_splits

    def load_arrays(
        self,
        train_split_id: int,
        test_split_id: int,
        base_dir: str = "data",
    ) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, Dict[str, int]]:
        """
        Tải dữ liệu train/test từ split đã tạo, trả về mảng và label_to_id.
        Returns:
            (X_train, y_train, X_test, y_test, label_to_id).
        """
        return self._data_loader.download_and_load_data(
            train_split_id=train_split_id,
            test_split_id=test_split_id,
            base_dir=base_dir,
        )

    def run(
        self,
        dataset_version_id: int,
        config_name: str,
        class_names: List[str],
        feature_type_id: Optional[int] = None,
        train_size: float = 0.8,
        test_size: float = 0.2,
        val_size: float = 0.0,
        random_state: int = 42,
        base_dir: str = "data",
        max_samples_per_class: Optional[int] = None,
        max_total_samples: Optional[int] = None,
        split_ids: Optional[Dict[str, int]] = None,
    ) -> Tuple[
        np.ndarray, np.ndarray, np.ndarray, np.ndarray,
        Dict[str, int],
        Dict[str, int],
    ]:
        """
        One-shot: (nếu chưa có split_ids) get_data → filter_classes → split_and_push;
        sau đó load arrays train/test.

        - Lần đầu: split_ids=None → tạo split mới, tải NPZ về base_dir.
        - Lần sau: truyền split_ids={"train": <id>, "test": <id>} → chỉ lấy dữ liệu từ DB,
          so với file đã có trong base_dir, thiếu thì tải thêm, rồi load.

        max_samples_per_class / max_total_samples: chỉ áp dụng khi split_ids=None.
        Returns:
            (X_train, y_train, X_test, y_test, label_to_id, split_ids).
        """
        if split_ids is not None:
            if "train" not in split_ids or "test" not in split_ids:
                raise ValueError("split_ids phải có key 'train' và 'test'")
            train_id = split_ids["train"]
            test_id = split_ids["test"]
            logger.info(f"Dùng split có sẵn: train={train_id}, test={test_id}. Chỉ tải file thiếu.")
        else:
            df = self.get_data(dataset_version_id, feature_type_id=feature_type_id)
            df = self.filter_classes(df, class_names)
            if max_samples_per_class is not None and max_samples_per_class > 0 and "derivative_label" in df.columns:
                df = df.groupby("derivative_label", group_keys=False).apply(
                    lambda g: g.sample(n=min(len(g), max_samples_per_class), random_state=random_state)
                ).reset_index(drop=True)
                logger.info(f"Giới hạn tối đa {max_samples_per_class} mẫu/class → {len(df)} mẫu.")
            if max_total_samples is not None and max_total_samples > 0 and len(df) > max_total_samples:
                df = df.sample(n=max_total_samples, random_state=random_state).reset_index(drop=True)
                logger.info(f"Giới hạn tổng {max_total_samples} mẫu → {len(df)} mẫu.")
            split_ids = self.split_and_push(
                df, config_name, dataset_version_id,
                train_size=train_size, test_size=test_size, val_size=val_size,
                random_state=random_state,
            )
            train_id = split_ids["train"]
            test_id = split_ids["test"]
        X_train, y_train, X_test, y_test, label_to_id = self.load_arrays(
            train_id, test_id, base_dir=base_dir,
        )
        if split_ids is None:
            raise ValueError("split_ids is missing after split creation")
        return X_train, y_train, X_test, y_test, label_to_id, split_ids

    # Clear naming aliases
    def fetch_feature_catalog(
        self,
        dataset_version_id: int,
        feature_type_id: Optional[int] = None,
        keyword_ids: Optional[List[int]] = None,
    ) -> pd.DataFrame:
        return self.get_data(
            dataset_version_id=dataset_version_id,
            feature_type_id=feature_type_id,
            keyword_ids=keyword_ids,
        )

    def select_classes(
        self,
        df: pd.DataFrame,
        class_names: List[str],
        label_column: str = "derivative_label",
    ) -> pd.DataFrame:
        return self.filter_classes(df=df, class_names=class_names, label_column=label_column)


# ---------------------------------------------------------------------------
# 3. ModelManager – Quản lý model, metrics, artifact
# ---------------------------------------------------------------------------


class ModelManager:
    """
    Quản lý model trên DB: get/create model init, model, experiment, run; đẩy metrics và artifact.
    """

    def __init__(self, session: KWSSession):
        self._session = session
        self._api = session.api

    def register_run(
        self,
        model_name: str,
        num_classes: int,
        experiment_name: str,
        train_split_id: int,
        config: Dict[str, Any],
        *,
        model_init_id: Optional[int] = None,
        model_init_type: Optional[str] = None,
        model_description: Optional[str] = None,
        experiment_description: Optional[str] = None,
        git_commit: str = "manual-run",
        wait_job_timeout: int = 120,
        label_to_id: Optional[Dict[str, int]] = None,
        run_mode: str = "sync",
    ) -> Tuple[int, int]:
        """
        Tạo model (và model_init nếu chưa có), experiment; tạo run và chờ job (nếu có).
        - label_to_id: mapping nhãn thực -> id (vd: {'one': 2, 'two': 4}); lưu vào run.config để downstream dùng nhãn thực.
        - Nếu truyền model_init_id: dùng luôn model_init đó, chỉ tạo model (không cần model_init_type).
        - Nếu không truyền model_init_id: cần model_init_type để tìm hoặc tạo model_init.
        - run_mode:
          - "sync" (default): tạo run đồng bộ, không phụ thuộc Celery.
          - "async": dùng job Celery và chờ hoàn thành (nếu có job_id).
          - "auto": thử sync trước, nếu endpoint sync không khả dụng thì fallback async.
        Returns:
            (model_id, experiment_run_id).
        """
        api = self._api
        if model_init_id is not None:
            try:
                model_init = api.models.get_model_init(model_init_id)
            except requests.HTTPError as e:
                if e.response is not None and e.response.status_code == 404:
                    # Backend chưa có GET /model-init/{id} hoặc 404 → lấy từ list và tìm theo id
                    inits = api.models.list_model_inits(page=1, page_size=500)
                    items = inits.get("items", [])
                    model_init = next((m for m in items if (m.get("model_init_id") or m.get("id")) == model_init_id), {})
                    if not model_init:
                        raise ValueError(f"model_init_id={model_init_id} không tồn tại trong danh sách.")
                else:
                    raise
            model_init_raw = model_init.get("model_init_id") or model_init.get("id")
            if model_init_raw is None:
                raise ValueError("Missing model_init_id in model-init response")
            model_init_id = int(model_init_raw)
        else:
            if not model_init_type:
                raise ValueError("Cần model_init_id hoặc model_init_type")
            inits = api.models.list_model_inits(page=1, page_size=100)
            items = inits.get("items", [])
            model_init = next((m for m in items if m.get("type") == model_init_type), {})
            if not model_init:
                model_init = api.models.create_model_init(
                    name=f"{model_init_type} Architecture",
                    type=model_init_type,
                )
            model_init_raw = model_init.get("model_init_id") or model_init.get("id")
            if model_init_raw is None:
                raise ValueError("Missing model_init_id in model-init response")
            model_init_id = int(model_init_raw)

        # Model
        models = api.models.list(page=1, page_size=100, name=model_name)
        model_items = models.get("items", [])
        model_obj = next((m for m in model_items if m.get("name") == model_name), None)
        if not model_obj:
            model_obj = api.models.create(
                name=model_name,
                model_init_id=model_init_id,
                num_classes=num_classes,
                description=model_description or f"{model_name}",
            )
        model_id_raw = model_obj.get("models_id") or model_obj.get("id")
        if model_id_raw is None:
            raise ValueError("Missing model_id in model response")
        model_id = int(model_id_raw)

        # Experiment
        exps = api.experiments.list(page=1, page_size=100)
        exp_items = exps.get("items", [])
        exp_obj = next((e for e in exp_items if e.get("name") == experiment_name), None)
        if not exp_obj:
            exp_obj = api.experiments.create(
                name=experiment_name,
                description=experiment_description or experiment_name,
            )
        experiment_id_raw = exp_obj.get("experiments_id") or exp_obj.get("id")
        if experiment_id_raw is None:
            raise ValueError("Missing experiment_id in experiment response")
        experiment_id = int(experiment_id_raw)

        # Run config: thêm label_to_id để downstream dùng nhãn thực (one, two,...) thay vì class_0, class_1
        run_config = {**config, "label_to_id": label_to_id} if label_to_id is not None else config

        def _create_run_sync_fallback() -> int:
            sync_run = api.experiments.create_run_sync(
                experiment_id=experiment_id,
                model_id=model_id,
                dataset_split_id=train_split_id,
                config=run_config,
                git_commit=git_commit,
            )
            sync_run_id_raw = sync_run.get("experiment_runs_id") or sync_run.get("id")
            if sync_run_id_raw is None:
                raise ValueError("Missing experiment_run_id in sync run response")
            sync_run_id = int(sync_run_id_raw)
            logger.info(f"Đã tạo run đồng bộ: experiment_run_id={sync_run_id}.")
            return sync_run_id

        run_mode_normalized = run_mode.strip().lower()
        if run_mode_normalized not in {"sync", "async", "auto"}:
            raise ValueError("run_mode must be one of: 'sync', 'async', 'auto'")

        experiment_run_id: Optional[int] = None
        job_id: Optional[str] = None

        if run_mode_normalized == "sync":
            experiment_run_id = _create_run_sync_fallback()
        elif run_mode_normalized == "auto":
            try:
                experiment_run_id = _create_run_sync_fallback()
            except requests.HTTPError as exc:
                status_code = exc.response.status_code if exc.response is not None else None
                if status_code in {404, 405}:
                    logger.warning(
                        "create_run_sync unavailable (HTTP %s). Fallback to async create_run.",
                        status_code,
                    )
                    run_resp = api.experiments.create_run(
                        experiment_id=experiment_id,
                        model_id=model_id,
                        dataset_split_id=train_split_id,
                        config=run_config,
                        git_commit=git_commit,
                    )
                    job_id = run_resp.get("job_id")
                    async_run_id = run_resp.get("experiment_run_id") or run_resp.get("id")
                    if async_run_id is not None:
                        experiment_run_id = int(async_run_id)
                else:
                    raise
        else:  # async
            run_resp = api.experiments.create_run(
                experiment_id=experiment_id,
                model_id=model_id,
                dataset_split_id=train_split_id,
                config=run_config,
                git_commit=git_commit,
            )
            job_id = run_resp.get("job_id")
            async_run_id = run_resp.get("experiment_run_id") or run_resp.get("id")
            if async_run_id is not None:
                experiment_run_id = int(async_run_id)

        if job_id:
            status = api.jobs.wait_for_completion(job_id, timeout=wait_job_timeout)
            if status.get("status") != "failed":
                status_run_id = (
                    status.get("experiment_run_id")
                    or status.get("run_id")
                    or (status.get("result") or {}).get("experiment_run_id")
                    or (status.get("result") or {}).get("id")
                )
                if status_run_id is not None:
                    experiment_run_id = int(status_run_id)

        if experiment_run_id is None:
            experiment_run_id = _create_run_sync_fallback()

        return model_id, experiment_run_id

    def push_metrics(
        self,
        model_id: int,
        dataset_split_id: int,
        experiment_run_id: int,
        metrics: Dict[str, Any],
        require_standard: bool = True,
        fill_missing_with_none: bool = True,
    ) -> int:
        """
        Đẩy metrics lên DB (chuẩn: accuracy, precision, recall, f1_score, confusion_matrix).
        Returns:
            metrics_id.
        """
        payload = build_metrics_payload(
            model_id=model_id,
            dataset_split_id=dataset_split_id,
            experiment_run_id=experiment_run_id,
            metrics=metrics,
            require_standard=require_standard,
            fill_missing_with_none=fill_missing_with_none,
        )
        resp = self._api.metrics.create(payload=payload)
        metric_id_raw = resp.get("metrics_id") or resp.get("id")
        if metric_id_raw is None:
            raise ValueError("Missing metrics_id in metrics response")
        return int(metric_id_raw)

    def push_artifact(
        self,
        model_id: int,
        run_id: int,
        file_path: Union[str, Path],
        artifact_type: str = "tflite",
        framework: str = "generic",
        target_device: str = "CPU",
        is_default: bool = True,
        storage_path: Optional[str] = None,
        prototypes_path: Optional[Union[str, Path]] = None,
    ) -> int:
        """
        Upload file artifact lên MinIO và tạo bản ghi artifact trên DB.
        - prototypes_path: optional .npz chứa embeddings + labels, sẽ được upload thành
          `model_{model_id}/run_{run_id}/prototypes.npz` để few-shot dùng tất cả class pretrained.
        storage_path: Đường dẫn object trên MinIO (vd: models/13/model.tflite). Nếu None thì dùng models/{model_id}/model.{artifact_type}.
        Returns:
            model_artifacts_id (hoặc id).
        """
        path = Path(file_path)
        if not path.exists():
            raise FileNotFoundError(f"File không tồn tại: {path}")
        if prototypes_path is not None and not Path(prototypes_path).exists():
            raise FileNotFoundError(f"File prototype không tồn tại: {prototypes_path}")
        art = self._api.artifacts.upload(
            file_path=path,
            model_id=model_id,
            run_id=run_id,
            artifact_type=artifact_type,
            framework=framework,
            target_device=target_device,
            is_default=is_default,
            storage_path=storage_path,
            prototypes_path=prototypes_path,
        )
        # Ensure prototypes are available via run.config["encoder_prototypes_path"].
        # This fallback is robust even if sidecar upload (model_{id}/run_{id}/prototypes.npz) fails silently.
        if prototypes_path is not None:
            try:
                proto_path = Path(prototypes_path)
                files = {
                    "file": (
                        proto_path.name,
                        BytesIO(proto_path.read_bytes()),
                        "application/octet-stream",
                    )
                }
                self._api._request(
                    "POST",
                    "predict/few-shot/prototypes/upload",
                    data={"model_id": model_id, "run_id": run_id},
                    files=files,
                )
                logger.info(
                    "Uploaded few-shot prototypes via /predict/few-shot/prototypes/upload for model_id=%s run_id=%s",
                    model_id,
                    run_id,
                )
            except Exception as exc:
                logger.warning(
                    "Could not upload prototypes via predict/few-shot/prototypes/upload: %s",
                    exc,
                    exc_info=True,
                )
        artifact_id_raw = art.get("model_artifacts_id") or art.get("id")
        if artifact_id_raw is None:
            raise ValueError("Missing artifact id in artifact response")
        return int(artifact_id_raw)

    def compare_metrics(
        self,
        model_ids: List[int],
        split_id: int,
    ) -> Any:
        """So sánh metrics giữa các model trên một split."""
        return self._api.metrics.compare_metrics(model_ids=model_ids, split_id=split_id)


__all__ = [
    "KWSSession",
    "DatasetPipeline",
    "ModelManager",
    "KWSApiSession",
    "DatasetSplitPipeline",
    "ArtifactMetricsManager",
]

# Backward-compatible naming aliases with clearer semantics.
KWSApiSession = KWSSession
DatasetSplitPipeline = DatasetPipeline
ArtifactMetricsManager = ModelManager
