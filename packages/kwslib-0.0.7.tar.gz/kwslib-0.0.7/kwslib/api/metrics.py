"""Metrics API wrappers for `/api/v1/metrics`."""

from __future__ import annotations

from typing import Any, Dict, List, Optional, Union

from .base import BaseAPI


class MetricsAPI(BaseAPI):
    """Metrics endpoints (table `metrics`)."""

    def list(
        self,
        model_id: Optional[int] = None,
        dataset_split_id: Optional[int] = None,
        page: int = 1,
        page_size: int = 20,
    ) -> Dict[str, Any]:
        params: Dict[str, Any] = {"page": page, "page_size": min(page_size, 100)}
        if model_id is not None:
            params["model_id"] = model_id
        if dataset_split_id is not None:
            params["dataset_split_id"] = dataset_split_id
        return self.client._request("GET", "metrics/", params=params)

    def get(self, metric_id: int) -> Dict[str, Any]:
        return self.client._request("GET", f"metrics/{metric_id}")

    def create(
        self,
        model_id: Optional[int] = None,
        dataset_split_id: Optional[int] = None,
        experiment_run_id: Optional[int] = None,
        accuracy: Optional[float] = None,
        precision: Optional[float] = None,
        recall: Optional[float] = None,
        f1_score: Optional[float] = None,
        confusion_matrix: Optional[Union[List[List[int]], Dict[str, Any]]] = None,
        auc_macro: Optional[float] = None,
        auc_micro: Optional[float] = None,
        ap_macro: Optional[float] = None,
        ap_micro: Optional[float] = None,
        roc_curve: Optional[Dict[str, Any]] = None,
        pr_curve: Optional[Dict[str, Any]] = None,
        *,
        payload: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """Create metrics record.

        Preferred form:
            `client.metrics.create(payload=payload)`
        """
        if payload is not None:
            return self.client._request("POST", "metrics/", json=payload)

        required_fields = {
            "model_id": model_id,
            "dataset_split_id": dataset_split_id,
            "experiment_run_id": experiment_run_id,
            "accuracy": accuracy,
            "precision": precision,
            "recall": recall,
            "f1_score": f1_score,
            "confusion_matrix": confusion_matrix,
        }
        missing = [name for name, value in required_fields.items() if value is None]
        if missing:
            missing_str = ", ".join(missing)
            raise ValueError(f"Missing required fields for metrics.create: {missing_str}")
        assert model_id is not None
        assert dataset_split_id is not None
        assert experiment_run_id is not None
        assert accuracy is not None
        assert precision is not None
        assert recall is not None
        assert f1_score is not None

        body: Dict[str, Any] = {
            "model_id": int(model_id),
            "dataset_split_id": int(dataset_split_id),
            "experiment_run_id": int(experiment_run_id),
            "accuracy": float(accuracy),
            "precision": float(precision),
            "recall": float(recall),
            "f1_score": float(f1_score),
            "confusion_matrix": confusion_matrix,
        }
        if auc_macro is not None:
            body["auc_macro"] = float(auc_macro)
        if auc_micro is not None:
            body["auc_micro"] = float(auc_micro)
        if ap_macro is not None:
            body["ap_macro"] = float(ap_macro)
        if ap_micro is not None:
            body["ap_micro"] = float(ap_micro)
        if roc_curve is not None:
            body["roc_curve"] = roc_curve
        if pr_curve is not None:
            body["pr_curve"] = pr_curve
        return self.client._request("POST", "metrics/", json=body)

    def compare_metrics(
        self,
        model_ids: Union[List[int], str],
        split_id: int,
    ) -> List[Dict[str, Any]]:
        if isinstance(model_ids, list):
            model_ids = ",".join(str(item) for item in model_ids)
        return self.client._request(
            "GET",
            "metrics/compare",
            params={"model_ids": model_ids, "split_id": split_id},
        )

    # Clear naming aliases
    def list_metrics(
        self,
        model_id: Optional[int] = None,
        dataset_split_id: Optional[int] = None,
        page: int = 1,
        page_size: int = 20,
    ) -> Dict[str, Any]:
        return self.list(
            model_id=model_id,
            dataset_split_id=dataset_split_id,
            page=page,
            page_size=page_size,
        )

    def get_metric(self, metric_id: int) -> Dict[str, Any]:
        return self.get(metric_id=metric_id)

    def create_metric(self, **kwargs: Any) -> Dict[str, Any]:
        return self.create(**kwargs)
