"""
Dataset split file client.

Despite historical naming, this module does not access MinIO directly.
All file operations go through KWS Server API endpoints.
"""

from __future__ import annotations

import logging
import tempfile
from pathlib import Path
from typing import Any, Dict, List, Optional

import requests

logger = logging.getLogger(__name__)


class SplitFilesClient:
    """Download and list split files through `dataset_splits` API endpoints."""

    def __init__(self, api_client: Any):
        self.api = api_client

    def list_files(self, split_id: int, file_type: Optional[str] = None) -> Dict[str, Any]:
        return self.api.dataset_splits.list_files(split_id=split_id, file_type=file_type)

    def download_wav(self, split_id: int, file_id: int, output_path: str) -> str:
        return self.api.dataset_splits.download_file(
            split_id=split_id,
            file_id=file_id,
            file_type="wav",
            output_path=output_path,
        )

    def download_npz(
        self,
        split_id: int,
        file_id: int,
        output_path: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Download one NPZ file and return all arrays as a dictionary."""
        import numpy as np
        if output_path:
            npz_path = self.api.dataset_splits.download_file(
                split_id=split_id,
                file_id=file_id,
                file_type="npz",
                output_path=output_path,
            )
            with np.load(npz_path) as data:
                return {key: data[key] for key in data.files}

        with tempfile.NamedTemporaryFile(delete=False, suffix=".npz") as tmp_file:
            npz_path = self.api.dataset_splits.download_file(
                split_id=split_id,
                file_id=file_id,
                file_type="npz",
                output_path=tmp_file.name,
            )

        try:
            with np.load(npz_path) as data:
                return {key: data[key] for key in data.files}
        finally:
            Path(npz_path).unlink(missing_ok=True)

    def download_all_wav(self, split_id: int, output_dir: str) -> List[str]:
        return self._download_all_by_type(split_id=split_id, file_type="wav", output_dir=output_dir)

    def download_all_npz(
        self,
        split_id: int,
        output_dir: str,
        skip_existing: bool = True,
    ) -> List[str]:
        return self._download_all_by_type(
            split_id=split_id,
            file_type="npz",
            output_dir=output_dir,
            skip_existing=skip_existing,
        )

    def download_all_files_zip(self, split_id: int, file_type: str, output_path: str) -> str:
        return self.api.dataset_splits.download_all_files(
            split_id=split_id,
            file_type=file_type,
            format="zip",
            output_path=output_path,
        )

    def get_file_urls(self, split_id: int, file_type: str) -> Dict[str, Any]:
        # Kept for backward compatibility. Returns metadata, not direct URLs.
        return self.list_files(split_id=split_id, file_type=file_type)

    def get_file_metadata(self, split_id: int, file_type: str) -> Dict[str, Any]:
        return self.list_files(split_id=split_id, file_type=file_type)

    def _download_all_by_type(
        self,
        split_id: int,
        file_type: str,
        output_dir: str,
        skip_existing: bool = True,
    ) -> List[str]:
        output_path = Path(output_dir)
        output_path.mkdir(parents=True, exist_ok=True)

        files_info = self.list_files(split_id=split_id, file_type=file_type)
        source_files = [item for item in files_info.get("files", []) if item.get("file_type") == file_type]

        downloaded: List[str] = []
        skipped_count = 0
        for item in source_files:
            file_name = item.get("file_name")
            if not file_name:
                continue

            local_file = output_path / file_name
            if skip_existing and local_file.exists():
                downloaded.append(str(local_file))
                skipped_count += 1
                continue

            file_id = self._resolve_file_id(item=item, file_type=file_type)
            if file_id is None:
                logger.warning("Skip %s: no file id in payload", file_name)
                continue

            try:
                self.api.dataset_splits.download_file(
                    split_id=split_id,
                    file_id=file_id,
                    file_type=file_type,
                    output_path=str(local_file),
                )
                downloaded.append(str(local_file))
            except requests.RequestException as exc:
                logger.error("Download failed for %s (split=%s): %s", file_name, split_id, exc)

        if skipped_count:
            logger.info(
                "Split %s (%s): downloaded=%s, skipped_existing=%s",
                split_id,
                file_type,
                len(downloaded) - skipped_count,
                skipped_count,
            )
        else:
            logger.info("Split %s (%s): downloaded=%s", split_id, file_type, len(downloaded))

        return downloaded

    @staticmethod
    def _resolve_file_id(item: Dict[str, Any], file_type: str) -> Optional[int]:
        candidates: List[Any]
        if file_type == "wav":
            candidates = [
                item.get("file_id"),
                item.get("id"),
                item.get("keyword_audio_sample_id"),
                item.get("sample_id"),
            ]
        else:
            candidates = [
                item.get("file_id"),
                item.get("id"),
                item.get("keyword_audio_feature_id"),
                item.get("feature_id"),
            ]

        for candidate in candidates:
            if candidate is None:
                continue
            try:
                return int(candidate)
            except (TypeError, ValueError):
                continue
        return None


# Backward-compatible alias
DatasetSplitFilesClient = SplitFilesClient
