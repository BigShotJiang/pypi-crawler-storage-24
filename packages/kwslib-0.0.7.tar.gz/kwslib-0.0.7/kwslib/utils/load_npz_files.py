from __future__ import annotations

import logging
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple

import numpy as np

logger = logging.getLogger(__name__)

_FEATURE_PRIORITY_KEYS = ("features", "feature", "data", "X")
_LABEL_PRIORITY_KEYS = ("label", "labels", "y", "keyword", "keyword_id", "keyword_name")
_NON_FEATURE_KEYS = {
    "label",
    "labels",
    "y",
    "keyword",
    "keyword_id",
    "keyword_name",
    "sample_id",
    "feature_type_id",
    "metadata",
}


def load_npz_files(
    data_dir: str,
    api_client: Optional[Any] = None,
    file_info_map: Optional[List[Dict[str, Any]]] = None,
    label_to_id: Optional[Dict[str, int]] = None,
) -> Tuple[np.ndarray, np.ndarray, Dict[str, int]]:
    """Load NPZ files from a directory and return `(X, y, label_to_id)`.

    If `file_info_map` is provided, only files listed in that split payload are loaded.
    """
    all_npz_files = list(Path(data_dir).glob("*.npz"))
    file_metadata = _build_file_metadata(file_info_map=file_info_map)

    if file_metadata:
        selected_files = [path for path in all_npz_files if path.name in file_metadata]
        ignored_count = len(all_npz_files) - len(selected_files)
        if ignored_count > 0:
            logger.info("Loading %s split files, ignored %s extra files", len(selected_files), ignored_count)
    else:
        selected_files = all_npz_files

    logger.info("Found %s NPZ files under %s", len(selected_files), data_dir)

    if label_to_id is None:
        label_to_id = {}

    next_label_id = max(label_to_id.values()) + 1 if label_to_id else 0
    keyword_cache: Dict[int, str] = {}

    features_list: List[np.ndarray] = []
    labels_list: List[int] = []

    for npz_path in selected_files:
        try:
            with np.load(npz_path, allow_pickle=True) as npz_obj:
                features = _extract_features(npz_obj=npz_obj)
                if features is None:
                    logger.warning("Skip %s: feature array not found", npz_path)
                    continue

                label = _extract_label(
                    npz_path=npz_path,
                    npz_obj=npz_obj,
                    file_metadata=file_metadata,
                    api_client=api_client,
                    keyword_cache=keyword_cache,
                )
                normalized_label = _normalize_label(label)

                if normalized_label not in label_to_id:
                    label_to_id[normalized_label] = next_label_id
                    next_label_id += 1

                labels_list.append(label_to_id[normalized_label])
                features_list.append(_normalize_feature_shape(features))
        except Exception as exc:
            logger.exception("Error loading %s: %s", npz_path, exc)

    if not features_list:
        raise ValueError("No features loaded from NPZ files")

    x = _stack_or_pad(features_list)
    y = np.asarray(labels_list)

    logger.info("Loaded %s samples, X shape=%s, classes=%s", len(x), x.shape, len(label_to_id))
    return x, y, label_to_id


def _build_file_metadata(file_info_map: Optional[List[Dict[str, Any]]]) -> Dict[str, Dict[str, Any]]:
    metadata_by_filename: Dict[str, Dict[str, Any]] = {}
    if not file_info_map:
        return metadata_by_filename

    for item in file_info_map:
        file_name = item.get("file_name")
        if not file_name:
            continue
        metadata_by_filename[file_name] = {
            "sample_id": item.get("sample_id"),
            "derivative_label": item.get("derivative_label"),
            "file_id": item.get("file_id"),
        }
    return metadata_by_filename


def _extract_features(npz_obj: Any) -> Optional[np.ndarray]:
    for key in _FEATURE_PRIORITY_KEYS:
        if key in npz_obj:
            return npz_obj[key]

    for key in npz_obj.keys():
        if key in _NON_FEATURE_KEYS:
            continue
        candidate = npz_obj[key]
        if isinstance(candidate, np.ndarray) and candidate.size > 0:
            return candidate
    return None


def _extract_label(
    npz_path: Path,
    npz_obj: Any,
    file_metadata: Dict[str, Dict[str, Any]],
    api_client: Optional[Any],
    keyword_cache: Dict[int, str],
) -> Any:
    metadata = file_metadata.get(npz_path.name, {})
    derivative_label = metadata.get("derivative_label")
    if derivative_label and str(derivative_label).strip():
        return derivative_label

    for key in _LABEL_PRIORITY_KEYS:
        if key in npz_obj:
            return npz_obj[key]

    sample_id = metadata.get("sample_id")
    if sample_id and api_client is not None:
        sample_id = int(sample_id)
        if sample_id not in keyword_cache:
            try:
                sample_info = api_client.audio.get_keyword_sample(sample_id)
                keyword_id = sample_info.get("keyword_id")
                if keyword_id is None:
                    keyword_cache[sample_id] = f"unknown_{sample_id}"
                else:
                    keyword_info = api_client.keywords.get(int(keyword_id))
                    keyword_cache[sample_id] = keyword_info.get("name", f"keyword_{keyword_id}")
            except Exception as exc:
                logger.warning("Cannot resolve keyword name for sample_id=%s: %s", sample_id, exc)
                keyword_cache[sample_id] = f"unknown_{sample_id}"
        return keyword_cache[sample_id]

    # Last resort
    stem = npz_path.stem
    return stem.split("_")[0] if "_" in stem else stem


def _normalize_label(label: Any) -> str:
    if isinstance(label, np.ndarray):
        if label.size == 1:
            label = label.item()
        else:
            label = str(label)
    elif not isinstance(label, str):
        label = str(label)
    return label.strip()


def _normalize_feature_shape(feature_array: np.ndarray) -> np.ndarray:
    if feature_array.ndim == 3:
        if feature_array.shape[0] == 1:
            return feature_array[0]
        return feature_array.flatten()
    if feature_array.ndim in (1, 2):
        return feature_array
    return feature_array.flatten()


def _stack_or_pad(features_list: List[np.ndarray]) -> np.ndarray:
    shapes = [arr.shape for arr in features_list]
    if len(set(shapes)) == 1:
        return np.asarray(features_list)

    if all(arr.ndim == 2 for arr in features_list):
        max_len = max(arr.shape[0] for arr in features_list)
        max_freq = max(arr.shape[1] for arr in features_list)
        stacked = np.zeros((len(features_list), max_len, max_freq))
        for idx, arr in enumerate(features_list):
            stacked[idx, : arr.shape[0], : arr.shape[1]] = arr
        return stacked

    if all(arr.ndim == 1 for arr in features_list):
        max_len = max(arr.shape[0] for arr in features_list)
        stacked = np.zeros((len(features_list), max_len))
        for idx, arr in enumerate(features_list):
            stacked[idx, : arr.shape[0]] = arr
        return stacked

    max_size = max(arr.size for arr in features_list)
    stacked = np.zeros((len(features_list), max_size))
    for idx, arr in enumerate(features_list):
        flat = arr.flatten()
        stacked[idx, : flat.size] = flat
    return stacked
