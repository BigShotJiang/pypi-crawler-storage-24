"""Backward-compatible exports for split data loading."""

from kwslib.data_loading import DataLoader, SplitDataLoader

__all__ = ["DataLoader", "SplitDataLoader"]
