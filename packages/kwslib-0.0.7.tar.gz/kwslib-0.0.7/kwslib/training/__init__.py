"""Backward-compatible entrypoints for split and data-loading utilities.

Training model code has been removed from kwslib.
"""

from .create_dataset_split import get_split_data, push_splits
from .data_loader import DataLoader, SplitDataLoader

__all__ = [
    "DataLoader",
    "SplitDataLoader",
    "get_split_data",
    "push_splits",
]
