import cv2
import numpy as np
import os
from ultralytics.utils import ASSETS
# 假设你已经安装了 pv-audit，直接导入
from pv_audit import PhysicalValidator, run_audit

def test_everything():
    print("--- 🚀 开始测试库核心功能 ---")
    
    # 1. 测试图片处理功能 (PhysicalValidator)
    # 我们用 YOLO 自带的 bus.jpg，确保不会报错
    test_img = cv2.imread(str(ASSETS / 'bus.jpg'))
    if test_img is None:
        print("❌ 错误：未找到测试图片，请检查 ultralytics 是否安装正常")
        return

    # 实例化并直接执行图片处理
    pv = PhysicalValidator(output_dir="data/test_results")
    pv.apply_stress(test_img)
    
    # 检查图片是否真的被“处理”了
    # 检查其中一个维度生成的图片是否存在
    lux_plus_path = os.path.join("data/test_results", "Lux+", "Lux+_001.jpg")
    if os.path.exists(lux_plus_path):
        print("✅ 图片处理功能测试通过：已生成物理应力样本")
    else:
        print("❌ 图片处理功能测试失败：未发现应力样本文件")
        return

    # 2. 测试审计逻辑 (run_audit)
    # 注意：运行此步骤需要你有对应的 yolo 模型权重
    print("--- ⚙️ 开始测试审计逻辑 ---")
    try:
        run_audit()
        if os.path.exists("data/final_audit_report.csv"):
            print("✅ 审计功能测试通过：已生成报告 CSV")
        else:
            print("❌ 审计功能测试失败：未生成报告")
    except Exception as e:
        print(f"⚠️ 审计过程遇到预料之内的提示: {e}")
        print("注意：如果这里报错，通常是因为模型权重未下载，你可以手动在目录下放一个 yolov8x.pt")

if __name__ == "__main__":
    test_everything()