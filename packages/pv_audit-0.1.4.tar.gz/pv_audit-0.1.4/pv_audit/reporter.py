import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

class AuditReporter:
    def __init__(self, raw_data):
        self.df = pd.DataFrame(raw_data)
    
    def save_report(self, csv_path):
        self.df.to_csv(csv_path, index=False)
    
    def generate_plots(self, output_path):
        sns.lineplot(data=self.df, x="level", y="result", hue="dimension")
        plt.savefig(output_path)