"""User management via SSM parameters."""

import typer

users_app = typer.Typer(context_settings={"help_option_names": ["-h", "--help"]})

SSM_PARAMS = {
    "allowed_emails": "/horizyn/{env}/auth/allowed_emails",
    "allowed_domains": "/horizyn/{env}/auth/allowed_domains",
    "admin_domains": "/horizyn/{env}/auth/admin_domains",
    "admin_emails": "/horizyn/{env}/auth/admin_emails",
    "alpha_emails": "/horizyn/{env}/auth/alpha_emails",
}


def _ssm_client():
    import boto3

    return boto3.client("ssm", region_name="us-east-1")


def _get_param(ssm, name: str) -> str:
    try:
        resp = ssm.get_parameter(Name=name)
        return resp["Parameter"]["Value"]
    except ssm.exceptions.ParameterNotFound:
        return ""


def _put_param(ssm, name: str, value: str) -> None:
    ssm.put_parameter(Name=name, Value=value, Type="String", Overwrite=True)
    typer.echo(f"Updated {name}")


def _parse_csv(raw: str) -> set[str]:
    return {e.strip().lower() for e in raw.split(",") if e.strip()}


def _format_csv(emails: set[str]) -> str:
    return ",".join(sorted(emails))


@users_app.command("list")
def list_users(
    env: str = typer.Option("prod", "--env", "-e", help="Environment: prod or dev."),
):
    """Show all authorized users and their tiers."""
    ssm = _ssm_client()

    admin_domains = _parse_csv(_get_param(ssm, SSM_PARAMS["admin_domains"].format(env=env)))
    admin_emails = _parse_csv(_get_param(ssm, SSM_PARAMS["admin_emails"].format(env=env)))
    alpha_emails = _parse_csv(_get_param(ssm, SSM_PARAMS["alpha_emails"].format(env=env)))
    allowed_domains = _parse_csv(_get_param(ssm, SSM_PARAMS["allowed_domains"].format(env=env)))
    allowed_emails = _parse_csv(_get_param(ssm, SSM_PARAMS["allowed_emails"].format(env=env)))

    typer.echo(f"\n  Horizyn users ({env})\n")

    typer.echo("  Admin domains:   " + (", ".join(sorted(admin_domains)) or "(none)"))
    typer.echo("  Admin emails:    " + (", ".join(sorted(admin_emails)) or "(none)"))
    typer.echo("  Alpha emails:    " + (", ".join(sorted(alpha_emails)) or "(none)"))
    typer.echo("  Allowed domains: " + (", ".join(sorted(allowed_domains)) or "(none)"))
    typer.echo("  Allowed emails:  " + (", ".join(sorted(allowed_emails)) or "(none)"))
    typer.echo()


@users_app.command("add")
def add_user(
    email: str = typer.Argument(help="Email address to add."),
    env: str = typer.Option("prod", "--env", "-e", help="Environment: prod or dev."),
    tier: str = typer.Option("beta", "--tier", "-t", help="Tier: beta or alpha."),
):
    """Add a user to the authorized emails list (and optionally set tier)."""
    email = email.strip().lower()
    ssm = _ssm_client()

    allowed = _parse_csv(_get_param(ssm, SSM_PARAMS["allowed_emails"].format(env=env)))
    if email in allowed:
        typer.echo(f"{email} is already in allowed_emails for {env}.")
    else:
        allowed.add(email)
        _put_param(ssm, SSM_PARAMS["allowed_emails"].format(env=env), _format_csv(allowed))

    if tier == "alpha":
        alphas = _parse_csv(_get_param(ssm, SSM_PARAMS["alpha_emails"].format(env=env)))
        if email in alphas:
            typer.echo(f"{email} is already in alpha_emails for {env}.")
        else:
            alphas.add(email)
            _put_param(ssm, SSM_PARAMS["alpha_emails"].format(env=env), _format_csv(alphas))


@users_app.command("remove")
def remove_user(
    email: str = typer.Argument(help="Email address to remove."),
    env: str = typer.Option("prod", "--env", "-e", help="Environment: prod or dev."),
):
    """Remove a user from all email lists for the given environment."""
    email = email.strip().lower()
    ssm = _ssm_client()

    for param_key in ("allowed_emails", "admin_emails", "alpha_emails"):
        param_name = SSM_PARAMS[param_key].format(env=env)
        current = _parse_csv(_get_param(ssm, param_name))
        if email in current:
            current.discard(email)
            _put_param(ssm, param_name, _format_csv(current))
            typer.echo(f"  Removed {email} from {param_key}")


@users_app.command("promote")
def promote_user(
    email: str = typer.Argument(help="Email address to promote."),
    tier: str = typer.Option(..., "--tier", "-t", help="Target tier: alpha."),
    env: str = typer.Option("prod", "--env", "-e", help="Environment: prod or dev."),
):
    """Promote a user to a higher tier."""
    email = email.strip().lower()

    if tier not in ("alpha",):
        typer.echo("Only --tier alpha is supported. Admin is domain-based.", err=True)
        raise typer.Exit(1)

    ssm = _ssm_client()

    allowed = _parse_csv(_get_param(ssm, SSM_PARAMS["allowed_emails"].format(env=env)))
    if email not in allowed:
        typer.echo(f"{email} is not in allowed_emails for {env}. Add them first.", err=True)
        raise typer.Exit(1)

    alphas = _parse_csv(_get_param(ssm, SSM_PARAMS["alpha_emails"].format(env=env)))
    if email in alphas:
        typer.echo(f"{email} is already alpha in {env}.")
    else:
        alphas.add(email)
        _put_param(ssm, SSM_PARAMS["alpha_emails"].format(env=env), _format_csv(alphas))
