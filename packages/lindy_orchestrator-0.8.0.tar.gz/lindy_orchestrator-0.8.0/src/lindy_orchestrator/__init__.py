"""lindy-orchestrator: Lightweight, git-native multi-agent orchestration framework."""

__version__ = "0.8.0"
