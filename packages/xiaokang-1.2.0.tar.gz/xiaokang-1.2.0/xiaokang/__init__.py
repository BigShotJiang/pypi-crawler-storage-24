from xiaokang.常用 import xk, 报错信息,  时间_文件_天, 时间_文件_时, 时间_文件_分, 时间_文件_秒, 时间_正常, 时间_日志
from xiaokang.sqlite import sqlite数据库操作
from xiaokang.d多线程 import 多线程
from xiaokang.shell import win1, win2, win3, linux1, linux2
from xiaokang.x小工具1 import 截图, 解析ip, 查归属, 获取title, 发送邮件, 批量发送邮件
from xiaokang.p批量docx import 批量docx

# 定义外部可访问的内容（非必须，但推荐）
__all__ = [
    'xk', '报错信息', '时间_文件_天', '时间_文件_时', '时间_文件_分', '时间_文件_秒', '时间_正常', '时间_日志',
    'sqlite数据库操作',
    '多线程',
    'win1', 'win2', 'win3', 'linux1', 'linux2',
    '截图', '解析ip', '查归属', '获取title', '发送邮件', '批量发送邮件'
    '批量docx'
]
