

import datetime
import inspect
import os
import sqlite3
from xiaokang import 常用


class sqlite数据库操作:
    # 2025年08月29日14时01分43秒
    def __init__(self, 数据库文件, 操作日志="", 报错日志=""):
        self.数据库文件 = 数据库文件
        self.操作日志 = 操作日志
        self.报错日志 = 报错日志
        # 如果要保留日志->创建目录，确保目录存在，exist_ok=True 表示如果目录已经存在，不会报错。
        if 操作日志:
            os.makedirs(os.path.split(操作日志)[0], exist_ok=True)
        if 报错日志:
            os.makedirs(os.path.split(报错日志)[0], exist_ok=True)

    # 2025年08月29日14时04分31秒
    def 写日志(self, 内容):
        if not self.操作日志:
            return
        时间戳 = datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")
        调用者 = inspect.stack()[1].function
        日志内容 = f"{时间戳}\t{调用者}\t{内容}\n"
        with open(self.操作日志, "a", encoding="utf-8") as f:
            f.write(日志内容)

    # 2025年08月29日14时04分54秒
    def 连接(self):
        # 判断是否连接
        if hasattr(self, "conn"):
            self.写日志("数据库已连接，跳过连接")
            self.连接情况 = True
            return True, "数据库已连接"
        self.写日志("准备连接……")
        try:
            self.conn = sqlite3.connect(self.数据库文件, check_same_thread=False)
            self.cursor = self.conn.cursor()
            self.写日志("数据库连接成功")
            self.连接情况 = True
            return True, "数据库连接成功"
        except Exception:
            self.写日志("数据库连接报错")
            错误 = 常用.报错信息(保存到文件=self.报错日志)
            self.连接情况 = False
            return False, 错误

    # 2025年08月29日14时09分03秒
    def 提交(self):
        # 判断是否连接
        if not hasattr(self, "conn"):
            self.写日志("未发现连接对象，无法提交")
            return False, "未发现连接对象，无法提交"
        self.写日志("准备提交……")
        try:
            self.conn.commit()
            self.写日志("事务提交成功")
            return True, "事务提交成功"
        except Exception:
            self.写日志("事务提交报错")
            错误 = 常用.报错信息(保存到文件=self.报错日志)
            return False, 错误

    # 2025年08月29日14时11分37秒
    def 断开(self):
        # 判断是否连接
        if not hasattr(self, "conn"):
            self.写日志("未发现连接对象，已跳过断开")
            return False, "未发现连接对象，已跳过断开"
        self.写日志("准备断开……")
        try:
            self.conn.commit()
            self.写日志("事务提交成功")
            self.conn.close()
            self.写日志("数据库连接断开")
            self.连接情况 = False
            del self.conn
            del self.cursor
            return True, "数据库连接断开"
        except Exception:
            self.写日志("数据库连接断开报错")
            错误 = 常用.报错信息(保存到文件=self.报错日志)
            return False, 错误

    # 2025年08月29日14时13分37秒
    def 执行SQL(self, sql):
        # 判断是否连接
        if not hasattr(self, "conn"):
            self.写日志("未发现连接对象，无法执行SQL")
            return False, "未发现连接对象，无法执行SQL"
        self.写日志("准备执行SQL……")
        try:
            self.写日志(f"执行SQL：{sql}")
            self.cursor.execute(sql)
            结果 = self.cursor.fetchall()
        except Exception:
            self.写日志("执行SQL报错")
            错误 = 常用.报错信息(保存到文件=self.报错日志)
            return False, 错误
        return True, 结果

    # 2026年2月28日
    def 创建表(self, 表名: str, 字段: list, 字段类型: dict = {}, 字段默认值="TEXT"):
        """
        创建表(表名='Information', 字段=['A', 'b', 'c', 'D'], 字段类型={'A': 'integer',  'c': 'real', 'D': 'bolo'}, 默认值="TEXT")
            表名：创建的数据库表名
            字段：需要创建的字段列表，['A', 'b', 'c', 'D']
            字段类型：字段类型字典，{'A': 'integer',  'c': 'real', 'D': 'bolo'}，默认值TEXT
            字段默认值：字段默认值，默认TEXT
        """
        # 判断是否连接
        if not hasattr(self, "conn"):
            self.写日志("未发现连接对象，无法创建表")
            return False, "未发现连接对象，无法创建表"
        self.写日志("准备创建表……")
        try:
            sql = f'CREATE TABLE "{表名}" ('
            for 字 in 字段:
                sql += f'"{字}" {字段类型.get(字, 字段默认值)},'
            sql = sql.rstrip(",") + ");"
            self.写日志(f"创建表：{sql}")
            self.cursor.execute(sql)
            self.提交()
        except Exception:
            错误 = 常用.报错信息(保存到文件=self.报错日志)
            return False, 错误
        return True, "创建成功"

    # 2026年2月28日
    def 读取数据(self, 表名: str, 查看字段: list = ["*"], 判断匹配: list = [], 显示行数: list = []):
        """
        读取数据(表名='Information', 查看字段=['A', 'b', 'c', 'D'], 判断匹配=['A=1', 'and', 'b="2b"'], 显示行数=[0, 1])
            表名：查询的数据库表名
            查看字段：需要查看的字段，默认['*']，表示全部字段，['A', 'b', 'c', 'D']，表示只查看A、b、c、D字段
            判断匹配：需要匹配的条件，默认[]，表示不匹配，['A=1', 'and', 'b="2b"']，表示匹配A=1且b="2b"，分隔是空格
            显示行数：需要显示的行数，默认[]，表示全部行，[0,10]，表示显示从第0行后显示10行
        """
        # 判断是否连接
        if not hasattr(self, "conn"):
            self.写日志("未发现连接对象，无法读取数据")
            return False, "未发现连接对象，无法读取数据"
        self.写日志("准备读取数据……")
        try:
            sql = (
                f'SELECT {"*" if 查看字段 == ["*"] else ",".join(查看字段)} '
                f'FROM "{表名.replace(".", "\".\"")}" '
            )
            if 判断匹配:
                sql += f'WHERE {" ".join(判断匹配)} '
            if 显示行数:
                sql += f'LIMIT {显示行数[0]},{显示行数[1]}'
            sql += ";"
            self.写日志(f"读取数据：{sql}")
            self.cursor.execute(sql)
            return True, self.cursor.fetchall()
        except Exception:
            错误 = 常用.报错信息(保存到文件=self.报错日志)
            return False, 错误

    # 2026年2月28日
    def 新增数据(self, 表名: str, 数据: dict):
        """
        新增数据(表名='Information', 数据={'A': 1, 'b': '3b', 'c': 3.1415926, 'D': True})
            表名：新增数据的数据库表名
            数据：新增的数据字典
        """
        # 判断是否连接
        if not hasattr(self, "conn"):
            self.写日志("未发现连接对象，无法新增数据")
            return False, "未发现连接对象，无法新增数据"
        self.写日志("准备新增数据……")
        try:
            段 = []
            值 = []
            for f1, f2 in 数据.items():
                段.append(f1)
                值.append(f2)
            字段串 = '"' + '","'.join(段) + '"'
            占位符 = ",".join(["?"] * len(段))
            sql = f'INSERT INTO "{表名.replace('.', '"."')}" ({字段串}) VALUES ({占位符})'
            self.写日志(f"新增数据：{sql}\nvalue：{值}")
            self.cursor.execute(sql, 值)
            序号 = self.cursor.lastrowid
            return True, 序号
        except Exception:
            错误 = 常用.报错信息(保存到文件=self.报错日志)
            return False, 错误

    # 2026年2月28日
    def 修改数据(self, 表名: str, 查数据: list, 写数据: dict):
        """
        修改数据(表名='Information', 查数据=[('A','=',1),'and',('b','=','2b')], 写数据={'c': 21.45116})
            表名：修改数据的数据库表名
            查数据：需要匹配的条件字典，{'A': 1, 'b': '2b'}，表示匹配A=1且b="2b"
            写数据：需要修改的字段字典，{'启动项': 2, '系统进程': 2, 'usb插拔记录': 2}
        """
        # 判断是否连接
        if not hasattr(self, "conn"):
            self.写日志("未发现连接对象，无法修改数据")
            return False, "未发现连接对象，无法修改数据"
        self.写日志("准备修改数据……")
        try:
            参数 = []

            写_语句 = []
            for f1, f2 in 写数据.items():
                写_语句.append(f'{f1} = ?')
                参数.append(f2)

            查_语句 = []
            for f1 in 查数据:
                if type(f1) == tuple:
                    查_语句.append(f'{f1[0]} {f1[1]} ?')
                    参数.append(f1[2])
                else:
                    查_语句.append(f1)

            sql = f'UPDATE "{表名.replace(".", "\".\"")}" SET {' , '.join(写_语句)} WHERE {' '.join(查_语句)}'
            self.写日志(f"修改数据：{sql}\nvalue：{参数}")
            self.cursor.execute(sql, 参数)
        except Exception:
            错误 = 常用.报错信息(保存到文件=self.报错日志)
            return False, 错误
        return True, "修改成功"

    # def update(self, 表名: str, 数据: dict, where=None):

    #     设置列表 = []
    #     参数列表 = []

    #     for 字段, 值 in 数据.items():

    #         设置列表.append(f'"{字段}" = ?')
    #         参数列表.append(值)

    #     设置语句 = ", ".join(设置列表)

    #     sql = (
    #         f"UPDATE {self._处理表名(表名)} "
    #         f"SET {设置语句}"
    #     )

    #     where_sql, where参数 = self._构建WHERE(where)

    #     sql += where_sql

    #     参数列表.extend(where参数)

    #     print("SQL:", sql)
    #     print("参数:", 参数列表)

    #     self.cursor.execute(sql, 参数列表)

    #     self.conn.commit()

    #     return self.cursor.rowcount


# if __name__ == "__main__":
#     a = sqlite数据库操作('xk.db')
#     b=a.连接()
#     print(b)
#     print(a.连接情况)
#     b=a.创建表(表名='Information', 字段=['A', 'b', 'c', 'D'], 字段类型={'A': 'integer',  'c': 'real', 'D': 'bolo'}, 字段默认值="TEXT")
#     print(b)
#     b=a.新增数据(表名='Information', 数据={'A': 1, 'b': 'b', 'c': 3.1415926, 'D': True})
#     b=a.提交()
#     print(b)
#     print(b)
#     b=a.新增数据(表名='Information', 数据={'A': 1, 'b': '2b', 'c': 3.1415926, 'D': True})
#     b=a.提交()
#     print(b)
#     print(b)
#     b=a.提交()
#     print(b)
#     b=a.读取数据(表名='Information', 查看字段=['A', 'b', 'c', 'D'], 判断匹配=['A=1', 'and', 'b="b"'], 显示行数=[0, 1])
#     print(b)
#     b=a.修改数据(表名='Information', 查数据=[('A', '=', 1), 'and', ('b', '=', 'b')], 写数据={'c': 21.45116, 'd': False})
#     print(b)
#     b=a.提交()
#     print(b)
#     b=a.执行SQL('SELECT *,rowid "NAVICAT_ROWID" FROM "main"."Information" LIMIT 0,1000')
#     print(b)
#     b=a.断开()
#     print(b)
#     print(1)
