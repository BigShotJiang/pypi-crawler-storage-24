"""CLI commands for local file operations (compile, disassemble, decompile, lsp)."""

import asyncio
import io
import json
import logging
import sys
import webbrowser
from pathlib import Path

import rich_click as click
import yaml
from kb_dashboard_core.dashboard.view import KbnDashboard
from kb_dashboard_core.dashboard_compiler import load, render
from kb_dashboard_core.shared.error_formatter import format_validation_error, format_yaml_error
from kb_dashboard_core.tools.disassemble import disassemble_dashboard, parse_ndjson
from kb_dashboard_core.yaml_roundtrip import dump_roundtrip
from kb_dashboard_tools.compare import compare_disassembled_dashboards
from kb_dashboard_tools.decompile import decompile_dashboard
from kb_dashboard_tools.kibana_client import KibanaClient
from pydantic import ValidationError

from dashboard_compiler.cli_context import CliContext
from dashboard_compiler.cli_options import kibana_options
from dashboard_compiler.cli_output import (
    ICON_ERROR,
    ICON_SUCCESS,
    console,
    create_error_table,
    create_progress,
    print_browser,
    print_bullet,
    print_dim_bullet,
    print_error,
    print_plain,
    print_success,
    print_upload,
    print_warning,
)

# Constants
PROJECT_ROOT = Path(__file__).parent.parent.parent
DEFAULT_INPUT_DIR = PROJECT_ROOT / 'inputs'
DEFAULT_OUTPUT_DIR = PROJECT_ROOT / 'output'
MAX_EXIT_CODE = 125


def _sanitize_filename(name: str, max_length: int = 200) -> str:
    """Convert a string to a filesystem-safe filename."""
    # Replace filesystem-unsafe characters with underscores
    unsafe_chars = ['/', '\\', ':', '*', '?', '"', '<', '>', '|']
    result = name
    for char in unsafe_chars:
        result = result.replace(char, '_')

    # Replace spaces with underscores and trim whitespace
    result = result.strip().replace(' ', '_')

    # Strip leading dots to avoid hidden files and reserved names
    result = result.lstrip('.')

    # Handle empty or reserved results
    if len(result) == 0 or result in ('.', '..'):
        result = 'untitled'

    # Truncate to max length
    if len(result) > max_length:
        result = result[:max_length]

    return result


def _file_content_changed(file_path: Path, new_content: str) -> bool:
    """Check if writing new content would change the filesystem."""
    if not file_path.exists():
        return True

    existing_content = file_path.read_text(encoding='utf-8')
    return existing_content != new_content


def _write_ndjson(output_path: Path, lines: list[str], overwrite: bool = True) -> None:
    """Write a list of JSON strings to an NDJSON file."""
    if overwrite is False and output_path.exists():
        return

    with output_path.open('w', encoding='utf-8') as f:
        for line in lines:
            _ = f.write(line + '\n')


def compile_yaml_to_json(yaml_path: Path, allow_deprecated: bool = False) -> tuple[list[str], list[KbnDashboard], str | None]:
    """Compile dashboard YAML to JSON strings for NDJSON.

    Args:
        yaml_path: Path to the dashboard YAML configuration file.
        allow_deprecated: Whether deprecated compatibility translations are enabled.

    Returns:
        Tuple of (list of JSON strings for NDJSON lines, list of dashboard models, error message or None).

    """
    try:
        dashboards = load(str(yaml_path), allow_deprecated=allow_deprecated)
        json_lines: list[str] = []
        kbn_dashboards: list[KbnDashboard] = []
        for dashboard in dashboards:
            dashboard_kbn_model = render(dashboard)
            json_lines.append(dashboard_kbn_model.model_dump_json(by_alias=True))
            kbn_dashboards.append(dashboard_kbn_model)
    except FileNotFoundError:
        return [], [], f'YAML file not found: {yaml_path}'
    except yaml.YAMLError as e:
        return [], [], format_yaml_error(e, yaml_path)
    except ValidationError as e:
        return [], [], format_validation_error(e, yaml_path)
    except (ValueError, TypeError, KeyError) as e:
        return [], [], f'Error compiling {yaml_path}: {e}'
    else:
        return json_lines, kbn_dashboards, None


def get_yaml_files(directory: Path) -> list[Path]:
    """Get all YAML files from a directory recursively.

    Args:
        directory: Directory to search for YAML files.

    Returns:
        List of Path objects pointing to YAML files.

    Raises:
        click.ClickException: If directory is not found.

    """
    if not directory.is_dir():
        msg = f'Directory not found: {directory}'
        raise click.ClickException(msg)

    yaml_files = sorted(directory.rglob('*.yaml'))

    if len(yaml_files) == 0:
        print_warning(f'No YAML files found in {directory}')

    return yaml_files


async def _upload_to_kibana(
    client: KibanaClient,
    ndjson_file: Path,
    overwrite: bool,
    open_browser: bool,
) -> None:
    """Upload NDJSON file to Kibana.

    Args:
        client: Pre-configured Kibana client
        ndjson_file: Path to NDJSON file to upload
        overwrite: Whether to overwrite existing objects
        open_browser: Whether to open browser after successful upload

    Raises:
        click.ClickException: If upload fails.

    """
    import aiohttp

    async with client:
        try:
            ndjson_content = ndjson_file.read_text(encoding='utf-8')
            result = await client.upload_ndjson(ndjson_content, overwrite=overwrite)

            if result.success is True:
                print_success(f'Successfully uploaded {result.success_count} object(s) to Kibana')

                dashboard_ids = [obj.destination_id or obj.id for obj in result.success_results if obj.type == 'dashboard']

                if len(dashboard_ids) > 0 and open_browser is True:
                    dashboard_url = client.get_dashboard_url(dashboard_ids[0])
                    print_browser(f'Opening dashboard: {dashboard_url}')
                    _ = webbrowser.open_new_tab(dashboard_url)

                if len(result.errors) > 0:
                    print_warning(f'Encountered {len(result.errors)} error(s):')
                    console.print(create_error_table(result.errors))
            else:
                print_error('Upload failed')
                if len(result.errors) > 0:
                    console.print(create_error_table(result.errors))
                msg = 'Upload to Kibana failed'
                raise click.ClickException(msg)

        except aiohttp.ClientError as e:
            msg = f'Error communicating with Kibana: {e}'
            raise click.ClickException(msg) from e
        except (OSError, ValueError) as e:
            msg = f'Error uploading to Kibana: {e}'
            raise click.ClickException(msg) from e


@click.command('compile')
@click.option(
    '--input-dir',
    type=click.Path(file_okay=False, path_type=Path),
    default=DEFAULT_INPUT_DIR,
    help='Directory containing YAML dashboard files to compile.',
)
@click.option(
    '--input-file',
    type=click.Path(exists=True, dir_okay=False, path_type=Path),
    default=None,
    help='Path to a single YAML dashboard file to compile. When provided, --input-dir is ignored.',
)
@click.option(
    '--output-dir',
    type=click.Path(file_okay=False, path_type=Path),
    default=DEFAULT_OUTPUT_DIR,
    help='Directory where compiled NDJSON files will be written.',
)
@click.option(
    '--output-file',
    type=str,
    default='compiled_dashboards.ndjson',
    help='Filename for the combined output NDJSON file containing all dashboards.',
)
@click.option(
    '--format',
    'output_format',
    type=click.Choice(['ndjson', 'json'], case_sensitive=False),
    default='ndjson',
    help='Output format: "ndjson" for combined files (default), "json" for individual pretty-printed files named by dashboard ID.',
)
@click.option(
    '--upload',
    is_flag=True,
    help='Upload compiled dashboards to Kibana immediately after compilation.',
)
@kibana_options
@click.option(
    '--no-browser',
    is_flag=True,
    help='Prevent browser from opening automatically after successful upload.',
)
@click.option(
    '--overwrite/--no-overwrite',
    default=True,
    help='Whether to overwrite existing dashboards in Kibana (default: overwrite).',
)
@click.option(
    '--exit-non-zero-on-change',
    is_flag=True,
    help='Exit with non-zero code when files change (useful for CI sync detection).',
)
@click.option(
    '--allow-deprecated',
    is_flag=True,
    default=False,
    help='Allow deprecated YAML field names (e.g. dimensions instead of breakdowns). Deprecated fields will compile with a warning.',
)
def compile_dashboards(  # noqa: PLR0913, PLR0912, PLR0915
    ctx: click.Context,
    input_dir: Path,
    input_file: Path | None,
    output_dir: Path,
    output_file: str,
    output_format: str,
    upload: bool,
    no_browser: bool,
    overwrite: bool,
    exit_non_zero_on_change: bool,
    allow_deprecated: bool,
) -> None:
    r"""Compile YAML dashboard configurations to NDJSON format.

    This command finds all YAML files in the input directory (or compiles a
    single file provided via --input-file), compiles them to Kibana's JSON
    format, and outputs them as NDJSON files.

    Optionally, you can upload the compiled dashboards directly to Kibana
    using the --upload flag.

    The --format option controls output format:
    - ndjson (default): Groups dashboards by directory into NDJSON files
    - json: Creates individual pretty-printed JSON files named by dashboard ID

    By default, the command exits with code 0 on success. Use --exit-non-zero-on-change
    to enable CI sync detection mode, where the exit code equals the number of files
    that changed (capped at 125).

    \b
    Examples:
        # Compile dashboards from default directory
        kb-dashboard compile

        # Compile a single dashboard file
        kb-dashboard compile --input-file ./dashboards/example.yaml

        # Compile with custom input and output directories
        kb-dashboard compile --input-dir ./dashboards --output-dir ./output

        # Compile to individual JSON files per dashboard
        kb-dashboard compile --format json --output-dir ./output

        # Compile and upload to Kibana using basic auth
        kb-dashboard compile --upload --kibana-url https://kibana.example.com \
            --kibana-username admin --kibana-password secret

        # Compile and upload using API key (recommended)
        kb-dashboard compile --upload --kibana-url https://kibana.example.com \
            --kibana-api-key "your-api-key-here"

        # Use environment variables for credentials
        export KIBANA_URL=https://kibana.example.com
        export KIBANA_API_KEY=your-api-key
        kb-dashboard compile --upload
    """
    # Context is already populated by @kibana_options decorator
    if not isinstance(ctx.obj, CliContext):  # pyright: ignore[reportAny]
        msg = 'Context object must be CliContext'
        raise TypeError(msg)
    cli_context = ctx.obj

    # Normalize output format once for consistent comparisons
    output_format_lower = output_format.lower()

    output_dir.mkdir(parents=True, exist_ok=True)

    if input_file is not None:
        if input_file.suffix != '.yaml':
            msg = f'Input file must have a .yaml extension: {input_file}'
            raise click.ClickException(msg)
        yaml_files = [input_file]
    else:
        yaml_files = get_yaml_files(input_dir)
    if len(yaml_files) == 0:
        print_plain('No YAML files to compile.', style='yellow')
        return

    ndjson_lines: list[str] = []
    errors: list[str] = []
    files_to_write: dict[Path, list[str]] = {}
    json_files_to_write: list[tuple[Path, str]] = []
    json_filenames_seen: set[str] = set()
    changed_files_count = 0

    with create_progress() as progress:
        task = progress.add_task('Compiling dashboards...', total=len(yaml_files))

        for yaml_file in yaml_files:
            try:
                display_path = yaml_file.relative_to(PROJECT_ROOT)
            except ValueError:
                display_path = yaml_file
            progress.update(task, description=f'Compiling: {display_path}')
            compiled_jsons, kbn_dashboards, error = compile_yaml_to_json(
                yaml_file,
                allow_deprecated=allow_deprecated,
            )

            if len(compiled_jsons) > 0:
                if output_format_lower == 'json':
                    for kbn_dashboard in kbn_dashboards:
                        if not kbn_dashboard.id:
                            msg = f'Dashboard ID is required for JSON output: {yaml_file}'
                            raise click.ClickException(msg)
                        safe_name = _sanitize_filename(kbn_dashboard.id)
                        if safe_name in json_filenames_seen:
                            msg = f'Duplicate dashboard ID after sanitization: {kbn_dashboard.id}'
                            raise click.ClickException(msg)
                        json_filenames_seen.add(safe_name)
                        json_file = output_dir / f'{safe_name}.json'
                        pretty_json = kbn_dashboard.model_dump_json(by_alias=True, indent=2)
                        json_files_to_write.append((json_file, pretty_json))
                else:
                    filename = yaml_file.parent.stem
                    individual_file = output_dir / f'{filename}.ndjson'
                    if individual_file not in files_to_write:
                        files_to_write[individual_file] = []
                    files_to_write[individual_file].extend(compiled_jsons)
                ndjson_lines.extend(compiled_jsons)
            elif error is not None:
                errors.append(error)

            progress.advance(task)

    if output_format_lower == 'json':
        for json_file, json_content in json_files_to_write:
            if _file_content_changed(json_file, json_content):
                changed_files_count += 1
            with json_file.open('w', encoding='utf-8') as f:
                _ = f.write(json_content)
    else:
        for individual_file, jsons in files_to_write.items():
            content = '\n'.join(jsons) + '\n'
            if _file_content_changed(individual_file, content):
                changed_files_count += 1
            _write_ndjson(individual_file, jsons, overwrite=True)

    if len(ndjson_lines) > 0:
        print_success(f'Successfully compiled {len(ndjson_lines)} dashboard(s)')

    if len(errors) > 0:
        print_warning(f'Encountered {len(errors)} error(s):')
        for error in errors:
            print_bullet(error)

    if len(ndjson_lines) == 0:
        print_error('No valid YAML configurations found or compiled.')
        ctx.exit(1)

    if output_format_lower == 'json':
        print_success(f'Wrote {len(json_files_to_write)} individual JSON file(s)')
    else:
        combined_file = output_dir / output_file
        combined_content = '\n'.join(ndjson_lines) + '\n'
        if _file_content_changed(combined_file, combined_content):
            changed_files_count += 1
        _write_ndjson(combined_file, ndjson_lines, overwrite=True)
        try:
            display_path = combined_file.relative_to(PROJECT_ROOT)
        except ValueError:
            display_path = combined_file
        print_success(f'Wrote combined file: {display_path}')

    if changed_files_count > 0:
        print_warning(f'{changed_files_count} file(s) changed')
    else:
        print_success('No files changed')

    if upload is True:
        if output_format_lower == 'json':
            print_warning('Upload is not supported with --format json')
        else:
            if cli_context.kibana_client is None:
                msg = 'Kibana client not configured'
                raise click.ClickException(msg)
            print_upload('Uploading to Kibana...')
            combined_file = output_dir / output_file
            asyncio.run(_upload_to_kibana(cli_context.kibana_client, combined_file, overwrite, not no_browser))

    if exit_non_zero_on_change is True:
        exit_code = min(changed_files_count, MAX_EXIT_CODE)
        ctx.exit(exit_code)


@click.command('disassemble')
@click.argument('input_file', type=click.Path(exists=True, path_type=Path), required=False)
@click.option(
    '-o',
    '--output',
    type=click.Path(path_type=Path),
    required=True,
    help='Output directory for component files.',
)
def disassemble(input_file: Path | None, output: Path) -> None:
    r"""Disassemble a Kibana dashboard NDJSON file into components.

    This command breaks down a Kibana dashboard JSON file (in NDJSON format)
    into separate files for easier processing by LLMs. This enables incremental
    conversion of large dashboards to YAML format.

    The dashboard is split into:
    - metadata.json: Dashboard metadata
    - options.json: Dashboard display options
    - controls.json: Dashboard control group configuration
    - filters.json: Dashboard-level filters
    - references.json: Data view and index pattern references
    - panels/: Directory containing individual panel JSON files

    \b
    Examples:
        # Disassemble a dashboard NDJSON file
        kb-dashboard disassemble dashboard.ndjson -o output_dir

        # Read from stdin
        cat dashboard.ndjson | kb-dashboard disassemble -o output_dir

        # Download and disassemble directly
        curl -u user:pass http://localhost:5601/api/saved_objects/dashboard/my-id | \
            kb-dashboard disassemble -o output_dir
    """
    try:
        if input_file is None:
            # Use TextIOWrapper to ensure UTF-8 encoding when reading from stdin
            # This avoids issues on Windows where the default encoding might not be UTF-8
            content = (
                io.TextIOWrapper(sys.stdin.buffer, encoding='utf-8').read()
                if hasattr(sys.stdin, 'buffer')
                else sys.stdin.read()  # Fallback for environments where stdin.buffer is not available
            )
        else:
            content = input_file.read_text(encoding='utf-8')

        dashboard = parse_ndjson(content)
        components = disassemble_dashboard(dashboard, output)

        print_success(f'Dashboard disassembled to: {output}')
        print_dim_bullet('metadata.json: Dashboard metadata')

        if components.get('options') is True:
            print_dim_bullet('options.json: Dashboard options')

        if components.get('controls') is True:
            print_dim_bullet('controls.json: Control group configuration')

        if components.get('filters') is True:
            print_dim_bullet('filters.json: Dashboard-level filters')

        if components.get('references') is True:
            print_dim_bullet('references.json: Data view references')

        panel_count = components.get('panels')
        if panel_count is not None and isinstance(panel_count, int):
            print_dim_bullet(f'panels/: {panel_count} panel files')

    except (ValueError, OSError) as e:
        msg = f'Error disassembling dashboard: {e}'
        raise click.ClickException(msg) from e


@click.command('decompile')
@click.argument('input_file', type=click.Path(exists=True, path_type=Path), required=False)
@click.option(
    '-o',
    '--output',
    type=click.Path(path_type=Path),
    required=True,
    help='Output YAML file path for decompiled dashboard stubs.',
)
def decompile(input_file: Path | None, output: Path) -> None:
    r"""Decompile a Kibana dashboard NDJSON file into YAML stubs.

    This command generates a YAML dashboard skeleton from a Kibana dashboard
    NDJSON export. It preserves panel structure (types, size, position, title)
    and adds TODO comments with original panel JSON where manual conversion is
    still required.

    \b
    Examples:
        # Decompile a dashboard NDJSON file to YAML
        kb-dashboard decompile dashboard.ndjson -o dashboard.yaml

        # Read from stdin
        cat dashboard.ndjson | kb-dashboard decompile -o dashboard.yaml
    """
    try:
        if input_file is None:
            # Use TextIOWrapper to ensure UTF-8 encoding when reading from stdin
            # This avoids issues on Windows where the default encoding might not be UTF-8
            content = (
                io.TextIOWrapper(sys.stdin.buffer, encoding='utf-8').read()
                if hasattr(sys.stdin, 'buffer')
                else sys.stdin.read()  # Fallback for environments where stdin.buffer is not available
            )
        else:
            content = input_file.read_text(encoding='utf-8')

        dashboard = parse_ndjson(content)
        decompiled_document = decompile_dashboard(dashboard)

        output.parent.mkdir(parents=True, exist_ok=True)
        dump_roundtrip(decompiled_document, str(output))

        print_success(f'Dashboard decompiled to: {output}')
        print_dim_bullet('Generated YAML stubs for dashboard panels')
        print_dim_bullet('Added TODO comments with original Kibana panel JSON')

    except (ValueError, OSError, TypeError) as e:
        msg = f'Error decompiling dashboard: {e}'
        raise click.ClickException(msg) from e


@click.command('compare')
@click.argument('original_dir', type=click.Path(exists=True, file_okay=False, path_type=Path))
@click.argument('compiled_dir', type=click.Path(exists=True, file_okay=False, path_type=Path))
def compare_disassembled(original_dir: Path, compiled_dir: Path) -> None:
    """Compare two disassembled dashboard directories for panel count/type mismatches.

    ORIGINAL_DIR and COMPILED_DIR should each be output from `kb-dashboard disassemble`.
    """
    try:
        comparison = compare_disassembled_dashboards(original_dir, compiled_dir)
    except (FileNotFoundError, json.JSONDecodeError, OSError) as e:
        msg = f'Error comparing disassembled dashboards: {e}'
        raise click.ClickException(msg) from e

    print_plain(f'Original panels: {comparison.original_count}')
    print_plain(f'Compiled panels: {comparison.compiled_count}')
    print_plain('')

    if comparison.original_count != comparison.compiled_count:
        print_warning(f'Panel count mismatch: {comparison.original_count} original vs {comparison.compiled_count} compiled')
        print_plain('')

    print_plain('Panel comparison:')
    for panel in comparison.panels:
        if panel.original is not None and panel.compiled is not None:
            marker = ICON_SUCCESS if panel.types_match else ICON_ERROR
            print_plain(f'  {marker} Panel {panel.index}: {panel.original.panel_type:15s} | {panel.original.title}')
            if not panel.types_match:
                print_dim_bullet(f'Original: {panel.original.panel_type}, Compiled: {panel.compiled.panel_type}')
        elif panel.original is not None:
            orig = panel.original
            print_plain(f'  {ICON_ERROR} Panel {panel.index}: {orig.panel_type:15s} | {orig.title} (MISSING in compiled)')
        elif panel.compiled is not None:
            comp = panel.compiled
            print_plain(f'  {ICON_ERROR} Panel {panel.index}: {comp.panel_type:15s} | {comp.title} (EXTRA in compiled)')

    print_plain('')
    if comparison.all_panels_match:
        print_success('All panels match!')
    else:
        total = max(comparison.original_count, comparison.compiled_count)
        print_warning(f'{comparison.matching_panel_types}/{total} panels match')


@click.command()
def lsp() -> None:
    """Start the Language Server Protocol (LSP) server for IDE integration.

    The LSP server provides real-time compilation, validation, and code
    completion for YAML dashboard files in supported IDEs like VS Code.

    This server communicates via stdin/stdout using the Language Server
    Protocol specification.
    """
    from dashboard_compiler.lsp.server import start_server as start_lsp_server

    # Force logging to stderr to prevent stdout contamination of JSON-RPC protocol
    logging.basicConfig(level=logging.INFO, format='%(message)s', stream=sys.stderr, force=True)
    start_lsp_server()
