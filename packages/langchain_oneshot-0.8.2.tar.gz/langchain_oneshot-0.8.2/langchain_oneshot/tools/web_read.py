"""OneShot web read tool."""

from __future__ import annotations

import json
from typing import Any, Type

from langchain_core.tools import BaseTool
from pydantic import BaseModel

from langchain_oneshot._types import WebReadInput
from oneshot import OneShotClient


class WebReadTool(BaseTool):
    """Read a web page and extract its content as markdown. Paid tool."""

    name: str = "oneshot_web_read"
    description: str = (
        "Read a web page and extract its content as clean markdown with a screenshot. "
        "Provide the URL to read. Paid tool."
    )
    args_schema: Type[BaseModel] = WebReadInput
    handle_tool_error: bool = True

    client: OneShotClient

    def _run(self, **kwargs: Any) -> str:
        result = self.client.call_tool("/v1/tools/web-read", kwargs)
        return json.dumps(result)

    async def _arun(self, **kwargs: Any) -> str:
        result = await self.client.acall_tool("/v1/tools/web-read", kwargs)
        return json.dumps(result)
