# Copyright (c) Microsoft. All rights reserved.

import json
import logging
import os
from typing import Annotated, Any
from unittest.mock import AsyncMock, MagicMock, patch

import pytest
from openai.types.beta.threads import (
    FileCitationAnnotation,
    FilePathAnnotation,
    MessageDeltaEvent,
    Run,
    TextDeltaBlock,
)
from openai.types.beta.threads import (
    Message as ThreadMessage,
)
from openai.types.beta.threads.file_citation_delta_annotation import FileCitationDeltaAnnotation
from openai.types.beta.threads.file_path_delta_annotation import FilePathDeltaAnnotation
from openai.types.beta.threads.runs import RunStep
from pydantic import Field

from agent_framework import (
    Agent,
    AgentResponse,
    AgentResponseUpdate,
    AgentSession,
    ChatResponse,
    ChatResponseUpdate,
    Content,
    Message,
    SupportsChatGetResponse,
    tool,
)
from agent_framework.openai import OpenAIAssistantsClient

skip_if_openai_integration_tests_disabled = pytest.mark.skipif(
    os.getenv("OPENAI_API_KEY", "") in ("", "test-dummy-key"),
    reason="No real OPENAI_API_KEY provided; skipping integration tests.",
)

INTEGRATION_TEST_MODEL = "gpt-4.1-nano"


def create_test_openai_assistants_client(
    mock_async_openai: MagicMock,
    model_id: str | None = None,
    assistant_id: str | None = None,
    assistant_name: str | None = None,
    thread_id: str | None = None,
    should_delete_assistant: bool = False,
) -> OpenAIAssistantsClient:
    """Helper function to create OpenAIAssistantsClient instances for testing."""
    client = OpenAIAssistantsClient(
        model_id=model_id or "gpt-4",
        assistant_id=assistant_id,
        assistant_name=assistant_name,
        thread_id=thread_id,
        api_key="test-api-key",
        org_id="test-org-id",
        async_client=mock_async_openai,
    )
    # Set the _should_delete_assistant flag directly if needed
    if should_delete_assistant:
        object.__setattr__(client, "_should_delete_assistant", True)
    return client


async def create_vector_store(client: OpenAIAssistantsClient) -> tuple[str, Content]:
    """Create a vector store with sample documents for testing."""
    file = await client.client.files.create(
        file=("todays_weather.txt", b"The weather today is sunny with a high of 25C."), purpose="user_data"
    )
    vector_store = await client.client.vector_stores.create(
        name="knowledge_base",
        expires_after={"anchor": "last_active_at", "days": 1},
    )
    result = await client.client.vector_stores.files.create_and_poll(vector_store_id=vector_store.id, file_id=file.id)
    if result.last_error is not None:
        raise Exception(f"Vector store file processing failed with status: {result.last_error.message}")

    return file.id, Content.from_hosted_vector_store(vector_store_id=vector_store.id)


async def delete_vector_store(client: OpenAIAssistantsClient, file_id: str, vector_store_id: str) -> None:
    """Delete the vector store after tests."""

    await client.client.vector_stores.delete(vector_store_id=vector_store_id)
    await client.client.files.delete(file_id=file_id)


@pytest.fixture
def mock_async_openai() -> MagicMock:
    """Mock AsyncOpenAI client."""
    mock_client = MagicMock()

    # Mock beta.assistants
    mock_client.beta.assistants.create = AsyncMock(return_value=MagicMock(id="test-assistant-id"))
    mock_client.beta.assistants.delete = AsyncMock()

    # Mock beta.threads
    mock_client.beta.threads.create = AsyncMock(return_value=MagicMock(id="test-thread-id"))
    mock_client.beta.threads.delete = AsyncMock()

    # Mock beta.threads.runs
    mock_client.beta.threads.runs.create = AsyncMock(return_value=MagicMock(id="test-run-id"))
    mock_client.beta.threads.runs.retrieve = AsyncMock()
    mock_client.beta.threads.runs.submit_tool_outputs = AsyncMock()
    mock_client.beta.threads.runs.cancel = AsyncMock()

    # Mock beta.threads.messages
    mock_client.beta.threads.messages.create = AsyncMock()
    mock_client.beta.threads.messages.list = AsyncMock(return_value=MagicMock(data=[]))

    return mock_client


def test_init_with_client(mock_async_openai: MagicMock) -> None:
    """Test OpenAIAssistantsClient initialization with existing client."""
    client = create_test_openai_assistants_client(
        mock_async_openai, model_id="gpt-4", assistant_id="existing-assistant-id", thread_id="test-thread-id"
    )

    assert client.client is mock_async_openai
    assert client.model_id == "gpt-4"
    assert client.assistant_id == "existing-assistant-id"
    assert client.thread_id == "test-thread-id"
    assert not client._should_delete_assistant  # type: ignore
    assert isinstance(client, SupportsChatGetResponse)


def test_init_auto_create_client(
    openai_unit_test_env: dict[str, str],
    mock_async_openai: MagicMock,
) -> None:
    """Test OpenAIAssistantsClient initialization with auto-created client."""
    client = OpenAIAssistantsClient(
        model_id=openai_unit_test_env["OPENAI_CHAT_MODEL_ID"],
        assistant_name="TestAssistant",
        api_key=openai_unit_test_env["OPENAI_API_KEY"],
        org_id=openai_unit_test_env["OPENAI_ORG_ID"],
        async_client=mock_async_openai,
    )

    assert client.client is mock_async_openai
    assert client.model_id == openai_unit_test_env["OPENAI_CHAT_MODEL_ID"]
    assert client.assistant_id is None
    assert client.assistant_name == "TestAssistant"
    assert not client._should_delete_assistant  # type: ignore


def test_init_validation_fail() -> None:
    """Test OpenAIAssistantsClient initialization with validation failure."""
    with pytest.raises(ValueError):
        # Force failure by providing invalid model ID type
        OpenAIAssistantsClient(model_id=123, api_key="valid-key")  # type: ignore


@pytest.mark.parametrize("exclude_list", [["OPENAI_CHAT_MODEL_ID"]], indirect=True)
def test_init_missing_model_id(openai_unit_test_env: dict[str, str]) -> None:
    """Test OpenAIAssistantsClient initialization with missing model ID."""
    with pytest.raises(ValueError):
        OpenAIAssistantsClient(api_key=openai_unit_test_env.get("OPENAI_API_KEY", "test-key"))


@pytest.mark.parametrize("exclude_list", [["OPENAI_API_KEY"]], indirect=True)
def test_init_missing_api_key(openai_unit_test_env: dict[str, str]) -> None:
    """Test OpenAIAssistantsClient initialization with missing API key."""
    with pytest.raises(ValueError):
        OpenAIAssistantsClient(model_id="gpt-4")


def test_init_with_default_headers(openai_unit_test_env: dict[str, str]) -> None:
    """Test OpenAIAssistantsClient initialization with default headers."""
    default_headers = {"X-Unit-Test": "test-guid"}

    client = OpenAIAssistantsClient(
        model_id="gpt-4",
        api_key=openai_unit_test_env["OPENAI_API_KEY"],
        default_headers=default_headers,
    )

    assert client.model_id == "gpt-4"
    assert isinstance(client, SupportsChatGetResponse)

    # Assert that the default header we added is present in the client's default headers
    for key, value in default_headers.items():
        assert key in client.client.default_headers
        assert client.client.default_headers[key] == value


async def test_get_assistant_id_or_create_existing_assistant(
    mock_async_openai: MagicMock,
) -> None:
    """Test _get_assistant_id_or_create when assistant_id is already provided."""
    client = create_test_openai_assistants_client(mock_async_openai, assistant_id="existing-assistant-id")

    assistant_id = await client._get_assistant_id_or_create()  # type: ignore

    assert assistant_id == "existing-assistant-id"
    assert not client._should_delete_assistant  # type: ignore
    mock_async_openai.beta.assistants.create.assert_not_called()


async def test_get_assistant_id_or_create_create_new(
    mock_async_openai: MagicMock,
) -> None:
    """Test _get_assistant_id_or_create when creating a new assistant."""
    client = create_test_openai_assistants_client(mock_async_openai, model_id="gpt-4", assistant_name="TestAssistant")

    assistant_id = await client._get_assistant_id_or_create()  # type: ignore

    assert assistant_id == "test-assistant-id"
    assert client._should_delete_assistant  # type: ignore
    mock_async_openai.beta.assistants.create.assert_called_once()


async def test_aclose_should_not_delete(
    mock_async_openai: MagicMock,
) -> None:
    """Test close when assistant should not be deleted."""
    client = create_test_openai_assistants_client(
        mock_async_openai, assistant_id="assistant-to-keep", should_delete_assistant=False
    )

    await client.close()  # type: ignore

    # Verify assistant deletion was not called
    mock_async_openai.beta.assistants.delete.assert_not_called()
    assert not client._should_delete_assistant  # type: ignore


async def test_aclose_should_delete(mock_async_openai: MagicMock) -> None:
    """Test close method calls cleanup."""
    client = create_test_openai_assistants_client(
        mock_async_openai, assistant_id="assistant-to-delete", should_delete_assistant=True
    )

    await client.close()

    # Verify assistant deletion was called
    mock_async_openai.beta.assistants.delete.assert_called_once_with("assistant-to-delete")
    assert not client._should_delete_assistant  # type: ignore


async def test_async_context_manager(mock_async_openai: MagicMock) -> None:
    """Test async context manager functionality."""
    client = create_test_openai_assistants_client(
        mock_async_openai, assistant_id="assistant-to-delete", should_delete_assistant=True
    )

    # Test context manager
    async with client:
        pass  # Just test that we can enter and exit

    # Verify cleanup was called on exit
    mock_async_openai.beta.assistants.delete.assert_called_once_with("assistant-to-delete")


def test_serialize(openai_unit_test_env: dict[str, str]) -> None:
    """Test serialization of OpenAIAssistantsClient."""
    default_headers = {"X-Unit-Test": "test-guid"}

    # Test basic initialization and to_dict
    client = OpenAIAssistantsClient(
        model_id="gpt-4",
        assistant_id="test-assistant-id",
        assistant_name="TestAssistant",
        thread_id="test-thread-id",
        api_key=openai_unit_test_env["OPENAI_API_KEY"],
        org_id=openai_unit_test_env["OPENAI_ORG_ID"],
        default_headers=default_headers,
    )

    dumped_settings = client.to_dict()

    assert dumped_settings["model_id"] == "gpt-4"
    assert dumped_settings["assistant_id"] == "test-assistant-id"
    assert dumped_settings["assistant_name"] == "TestAssistant"
    assert dumped_settings["thread_id"] == "test-thread-id"
    assert dumped_settings["org_id"] == openai_unit_test_env["OPENAI_ORG_ID"]

    # Assert that the default header we added is present in the dumped_settings default headers
    for key, value in default_headers.items():
        assert key in dumped_settings["default_headers"]
        assert dumped_settings["default_headers"][key] == value
    # Assert that the 'User-Agent' header is not present in the dumped_settings default headers
    assert "User-Agent" not in dumped_settings["default_headers"]


async def test_get_active_thread_run_none_thread_id(mock_async_openai: MagicMock) -> None:
    """Test _get_active_thread_run with None thread_id returns None."""
    client = create_test_openai_assistants_client(mock_async_openai)

    result = await client._get_active_thread_run(None)  # type: ignore

    assert result is None
    # Should not call the API when thread_id is None
    mock_async_openai.beta.threads.runs.list.assert_not_called()


async def test_get_active_thread_run_with_active_run(mock_async_openai: MagicMock) -> None:
    """Test _get_active_thread_run finds an active run."""

    client = create_test_openai_assistants_client(mock_async_openai)

    # Mock an active run (status not in completed states)
    mock_run = MagicMock()
    mock_run.status = "in_progress"  # Active status

    # Mock the async iterator for runs.list
    async def mock_runs_list(*args: Any, **kwargs: Any) -> Any:
        yield mock_run

    mock_async_openai.beta.threads.runs.list.return_value.__aiter__ = mock_runs_list

    result = await client._get_active_thread_run("thread-123")  # type: ignore

    assert result == mock_run
    mock_async_openai.beta.threads.runs.list.assert_called_once_with(thread_id="thread-123", limit=1, order="desc")


async def test_prepare_thread_create_new(mock_async_openai: MagicMock) -> None:
    """Test _prepare_thread creates new thread when thread_id is None."""
    client = create_test_openai_assistants_client(mock_async_openai)

    # Mock thread creation
    mock_thread = MagicMock()
    mock_thread.id = "new-thread-123"
    mock_async_openai.beta.threads.create.return_value = mock_thread

    # Prepare run options with additional messages
    run_options: dict[str, Any] = {
        "additional_messages": [{"role": "user", "content": "Hello"}],
        "tool_resources": {"code_interpreter": {}},
        "metadata": {"test": "true"},
    }

    result = await client._prepare_thread(None, None, run_options)  # type: ignore

    assert result == "new-thread-123"
    assert run_options["additional_messages"] == []  # Should be cleared
    mock_async_openai.beta.threads.create.assert_called_once_with(
        messages=[{"role": "user", "content": "Hello"}],
        tool_resources={"code_interpreter": {}},
        metadata={"test": "true"},
    )


async def test_prepare_thread_cancel_existing_run(mock_async_openai: MagicMock) -> None:
    """Test _prepare_thread cancels existing run when provided."""
    client = create_test_openai_assistants_client(mock_async_openai)

    # Mock an existing thread run
    mock_thread_run = MagicMock()
    mock_thread_run.id = "run-456"

    run_options: dict[str, Any] = {"additional_messages": []}

    result = await client._prepare_thread("thread-123", mock_thread_run, run_options)  # type: ignore

    assert result == "thread-123"
    mock_async_openai.beta.threads.runs.cancel.assert_called_once_with(run_id="run-456", thread_id="thread-123")


async def test_prepare_thread_existing_no_run(mock_async_openai: MagicMock) -> None:
    """Test _prepare_thread with existing thread_id but no active run."""
    client = create_test_openai_assistants_client(mock_async_openai)

    run_options: dict[str, list[dict[str, str]]] = {"additional_messages": []}

    result = await client._prepare_thread("thread-123", None, run_options)  # type: ignore

    assert result == "thread-123"
    # Should not call cancel since no thread_run provided
    mock_async_openai.beta.threads.runs.cancel.assert_not_called()


async def test_process_stream_events_thread_run_created(mock_async_openai: MagicMock) -> None:
    """Test _process_stream_events with thread.run.created event."""
    client = create_test_openai_assistants_client(mock_async_openai)

    # Create a mock stream response for thread.run.created
    mock_response = MagicMock()
    mock_response.event = "thread.run.created"
    mock_response.data = MagicMock()

    # Create a proper async iterator
    async def async_iterator() -> Any:
        yield mock_response

    # Create a mock stream that yields the response
    mock_stream = MagicMock()
    mock_stream.__aenter__ = AsyncMock(return_value=async_iterator())
    mock_stream.__aexit__ = AsyncMock(return_value=None)

    thread_id = "thread-123"
    updates: list[ChatResponseUpdate] = []
    async for update in client._process_stream_events(mock_stream, thread_id):  # type: ignore
        updates.append(update)

    # Should yield one ChatResponseUpdate for thread.run.created
    assert len(updates) == 1
    update = updates[0]
    assert isinstance(update, ChatResponseUpdate)
    assert update.conversation_id == thread_id
    assert update.role == "assistant"
    assert update.contents == []
    assert update.raw_representation == mock_response.data


async def test_process_stream_events_message_delta_text(mock_async_openai: MagicMock) -> None:
    """Test _process_stream_events with thread.message.delta event containing text."""
    client = create_test_openai_assistants_client(mock_async_openai)

    # Create a mock TextDeltaBlock with proper spec
    mock_delta_block = MagicMock(spec=TextDeltaBlock)
    mock_delta_block.text = MagicMock()
    mock_delta_block.text.value = "Hello from assistant"

    mock_delta = MagicMock()
    mock_delta.role = "assistant"
    mock_delta.content = [mock_delta_block]

    mock_message_delta = MagicMock(spec=MessageDeltaEvent)
    mock_message_delta.delta = mock_delta

    mock_response = MagicMock()
    mock_response.event = "thread.message.delta"
    mock_response.data = mock_message_delta

    # Create a proper async iterator
    async def async_iterator() -> Any:
        yield mock_response

    # Create a mock stream
    mock_stream = MagicMock()
    mock_stream.__aenter__ = AsyncMock(return_value=async_iterator())
    mock_stream.__aexit__ = AsyncMock(return_value=None)

    thread_id = "thread-456"
    updates: list[ChatResponseUpdate] = []
    async for update in client._process_stream_events(mock_stream, thread_id):  # type: ignore
        updates.append(update)

    # Should yield one text update
    assert len(updates) == 1
    update = updates[0]
    assert isinstance(update, ChatResponseUpdate)
    assert update.conversation_id == thread_id
    assert update.role == "assistant"
    assert update.text == "Hello from assistant"
    assert update.raw_representation == mock_message_delta


async def test_process_stream_events_message_delta_text_with_file_citation_annotations(
    mock_async_openai: MagicMock,
) -> None:
    """Test _process_stream_events maps file citation annotations from TextDeltaBlock."""
    client = create_test_openai_assistants_client(mock_async_openai)

    mock_annotation = FileCitationDeltaAnnotation(
        index=0,
        type="file_citation",
        file_citation={"file_id": "file-abc123"},
        start_index=10,
        end_index=24,
        text="【4:0†source】",
    )

    mock_delta_block = MagicMock(spec=TextDeltaBlock)
    mock_delta_block.text = MagicMock()
    mock_delta_block.text.value = "Some text 【4:0†source】 more text"
    mock_delta_block.text.annotations = [mock_annotation]

    mock_delta = MagicMock()
    mock_delta.role = "assistant"
    mock_delta.content = [mock_delta_block]

    mock_message_delta = MagicMock(spec=MessageDeltaEvent)
    mock_message_delta.delta = mock_delta

    mock_response = MagicMock()
    mock_response.event = "thread.message.delta"
    mock_response.data = mock_message_delta

    async def async_iterator() -> Any:
        yield mock_response

    mock_stream = MagicMock()
    mock_stream.__aenter__ = AsyncMock(return_value=async_iterator())
    mock_stream.__aexit__ = AsyncMock(return_value=None)

    thread_id = "thread-789"
    updates: list[ChatResponseUpdate] = []
    async for update in client._process_stream_events(mock_stream, thread_id):  # type: ignore
        updates.append(update)

    assert len(updates) == 1
    update = updates[0]
    assert update.text == "Some text 【4:0†source】 more text"
    assert update.contents is not None
    content = update.contents[0]
    assert content.annotations is not None
    assert len(content.annotations) == 1
    ann = content.annotations[0]
    assert ann["type"] == "citation"
    assert ann["file_id"] == "file-abc123"
    assert ann["annotated_regions"] is not None
    assert ann["annotated_regions"][0]["start_index"] == 10
    assert ann["annotated_regions"][0]["end_index"] == 24
    assert ann["additional_properties"]["text"] == "【4:0†source】"


async def test_process_stream_events_message_delta_text_with_file_path_annotations(
    mock_async_openai: MagicMock,
) -> None:
    """Test _process_stream_events maps file path annotations from TextDeltaBlock."""
    client = create_test_openai_assistants_client(mock_async_openai)

    mock_annotation = FilePathDeltaAnnotation(
        index=0,
        type="file_path",
        file_path={"file_id": "file-xyz789"},
        start_index=5,
        end_index=20,
        text="sandbox:/path/to/file",
    )

    mock_delta_block = MagicMock(spec=TextDeltaBlock)
    mock_delta_block.text = MagicMock()
    mock_delta_block.text.value = "Here sandbox:/path/to/file is the file"
    mock_delta_block.text.annotations = [mock_annotation]

    mock_delta = MagicMock()
    mock_delta.role = "assistant"
    mock_delta.content = [mock_delta_block]

    mock_message_delta = MagicMock(spec=MessageDeltaEvent)
    mock_message_delta.delta = mock_delta

    mock_response = MagicMock()
    mock_response.event = "thread.message.delta"
    mock_response.data = mock_message_delta

    async def async_iterator() -> Any:
        yield mock_response

    mock_stream = MagicMock()
    mock_stream.__aenter__ = AsyncMock(return_value=async_iterator())
    mock_stream.__aexit__ = AsyncMock(return_value=None)

    thread_id = "thread-annotation"
    updates: list[ChatResponseUpdate] = []
    async for update in client._process_stream_events(mock_stream, thread_id):  # type: ignore
        updates.append(update)

    assert len(updates) == 1
    content = updates[0].contents[0]
    assert content.annotations is not None
    assert len(content.annotations) == 1
    ann = content.annotations[0]
    assert ann["type"] == "citation"
    assert ann["file_id"] == "file-xyz789"
    assert ann["annotated_regions"] is not None
    assert ann["annotated_regions"][0]["start_index"] == 5
    assert ann["annotated_regions"][0]["end_index"] == 20


async def test_process_stream_events_requires_action(mock_async_openai: MagicMock) -> None:
    """Test _process_stream_events with thread.run.requires_action event."""
    client = create_test_openai_assistants_client(mock_async_openai)

    # Mock the _parse_function_calls_from_assistants method to return test content
    test_function_content = Content.from_function_call(call_id="call-123", name="test_func", arguments={"arg": "value"})
    client._parse_function_calls_from_assistants = MagicMock(return_value=[test_function_content])  # type: ignore

    # Create a mock Run object
    mock_run = MagicMock(spec=Run)

    mock_response = MagicMock()
    mock_response.event = "thread.run.requires_action"
    mock_response.data = mock_run

    # Create a proper async iterator
    async def async_iterator() -> Any:
        yield mock_response

    # Create a mock stream
    mock_stream = MagicMock()
    mock_stream.__aenter__ = AsyncMock(return_value=async_iterator())
    mock_stream.__aexit__ = AsyncMock(return_value=None)

    thread_id = "thread-789"
    updates: list[ChatResponseUpdate] = []
    async for update in client._process_stream_events(mock_stream, thread_id):  # type: ignore
        updates.append(update)

    # Should yield one function call update
    assert len(updates) == 1
    update = updates[0]
    assert isinstance(update, ChatResponseUpdate)
    assert update.conversation_id == thread_id
    assert update.role == "assistant"
    assert len(update.contents) == 1
    assert update.contents[0] == test_function_content
    assert update.raw_representation == mock_run

    # Verify _parse_function_calls_from_assistants was called correctly
    client._parse_function_calls_from_assistants.assert_called_once_with(mock_run, None)  # type: ignore


async def test_process_stream_events_run_step_created(mock_async_openai: MagicMock) -> None:
    """Test _process_stream_events with thread.run.step.created event."""

    client = create_test_openai_assistants_client(mock_async_openai)

    # Create a mock RunStep object
    mock_run_step = MagicMock(spec=RunStep)
    mock_run_step.run_id = "run-456"

    mock_response = MagicMock()
    mock_response.event = "thread.run.step.created"
    mock_response.data = mock_run_step

    # Create a proper async iterator
    async def async_iterator() -> Any:
        yield mock_response

    # Create a mock stream
    mock_stream = MagicMock()
    mock_stream.__aenter__ = AsyncMock(return_value=async_iterator())
    mock_stream.__aexit__ = AsyncMock(return_value=None)

    thread_id = "thread-789"
    updates: list[ChatResponseUpdate] = []
    async for update in client._process_stream_events(mock_stream, thread_id):  # type: ignore
        updates.append(update)

    # The run step creation itself doesn't yield an update,
    # but it should set the response_id for subsequent events
    assert len(updates) == 0


async def test_process_stream_events_run_completed_with_usage(
    mock_async_openai: MagicMock,
) -> None:
    """Test _process_stream_events with thread.run.completed event containing usage."""

    client = create_test_openai_assistants_client(mock_async_openai)

    # Create a mock Run object with usage information
    mock_usage = MagicMock()
    mock_usage.prompt_tokens = 100
    mock_usage.completion_tokens = 50
    mock_usage.total_tokens = 150

    mock_run = MagicMock(spec=Run)
    mock_run.usage = mock_usage

    mock_response = MagicMock()
    mock_response.event = "thread.run.completed"
    mock_response.data = mock_run

    # Create a proper async iterator
    async def async_iterator() -> Any:
        yield mock_response

    # Create a mock stream
    mock_stream = MagicMock()
    mock_stream.__aenter__ = AsyncMock(return_value=async_iterator())
    mock_stream.__aexit__ = AsyncMock(return_value=None)

    thread_id = "thread-999"
    updates: list[ChatResponseUpdate] = []
    async for update in client._process_stream_events(mock_stream, thread_id):  # type: ignore
        updates.append(update)

    # Should yield one usage update
    assert len(updates) == 1
    update = updates[0]
    assert isinstance(update, ChatResponseUpdate)
    assert update.conversation_id == thread_id
    assert update.role == "assistant"
    assert len(update.contents) == 1

    # Check the usage content
    usage_content = update.contents[0]
    assert usage_content.type == "usage"
    assert usage_content.usage_details["input_token_count"] == 100
    assert usage_content.usage_details["output_token_count"] == 50
    assert usage_content.usage_details["total_token_count"] == 150
    assert update.raw_representation == mock_run


def test_parse_function_calls_from_assistants_basic(mock_async_openai: MagicMock) -> None:
    """Test _parse_function_calls_from_assistants with a simple function call."""

    client = create_test_openai_assistants_client(mock_async_openai)

    # Create a mock Run event that requires action
    mock_run = MagicMock()
    mock_run.required_action = MagicMock()
    mock_run.required_action.submit_tool_outputs = MagicMock()

    # Create a mock tool call
    mock_tool_call = MagicMock()
    mock_tool_call.id = "call_abc123"
    mock_tool_call.function.name = "get_weather"
    mock_tool_call.function.arguments = '{"location": "Seattle"}'

    mock_run.required_action.submit_tool_outputs.tool_calls = [mock_tool_call]

    # Call the method
    response_id = "response_456"
    contents = client._parse_function_calls_from_assistants(mock_run, response_id)  # type: ignore

    # Test that one function call content was created
    assert len(contents) == 1
    assert contents[0].type == "function_call"
    assert contents[0].name == "get_weather"
    assert contents[0].arguments == {"location": "Seattle"}


def test_parse_run_step_with_code_interpreter_tool_call(mock_async_openai: MagicMock) -> None:
    """Test _parse_run_step_tool_call with code_interpreter type creates CodeInterpreterToolCallContent."""
    client = create_test_openai_assistants_client(
        mock_async_openai,
        model_id="test-model",
        assistant_id="test-assistant",
    )

    # Mock a run with required_action containing code_interpreter tool call
    mock_run = MagicMock()
    mock_run.id = "run_123"
    mock_run.status = "requires_action"

    mock_tool_call = MagicMock()
    mock_tool_call.id = "call_code_123"
    mock_tool_call.type = "code_interpreter"
    mock_code_interpreter = MagicMock()
    mock_code_interpreter.input = "print('Hello, World!')"
    mock_tool_call.code_interpreter = mock_code_interpreter

    mock_required_action = MagicMock()
    mock_required_action.submit_tool_outputs = MagicMock()
    mock_required_action.submit_tool_outputs.tool_calls = [mock_tool_call]
    mock_run.required_action = mock_required_action

    # Parse the run step
    contents = client._parse_function_calls_from_assistants(mock_run, "response_123")

    # Should have CodeInterpreterToolCallContent
    assert len(contents) == 1
    assert contents[0].type == "code_interpreter_tool_call"
    assert contents[0].call_id == '["response_123", "call_code_123"]'
    assert contents[0].inputs is not None
    assert len(contents[0].inputs) == 1
    assert contents[0].inputs[0].type == "text"
    assert contents[0].inputs[0].text == "print('Hello, World!')"


def test_parse_run_step_with_mcp_tool_call(mock_async_openai: MagicMock) -> None:
    """Test _parse_run_step_tool_call with mcp type creates MCPServerToolCallContent."""
    client = create_test_openai_assistants_client(
        mock_async_openai,
        model_id="test-model",
        assistant_id="test-assistant",
    )

    # Mock a run with required_action containing mcp tool call
    mock_run = MagicMock()
    mock_run.id = "run_456"
    mock_run.status = "requires_action"

    mock_tool_call = MagicMock()
    mock_tool_call.id = "call_mcp_456"
    mock_tool_call.type = "mcp"
    mock_tool_call.name = "fetch_data"
    mock_tool_call.server_label = "DataServer"
    mock_tool_call.args = {"key": "value"}

    mock_required_action = MagicMock()
    mock_required_action.submit_tool_outputs = MagicMock()
    mock_required_action.submit_tool_outputs.tool_calls = [mock_tool_call]
    mock_run.required_action = mock_required_action

    # Parse the run step
    contents = client._parse_function_calls_from_assistants(mock_run, "response_456")

    # Should have MCPServerToolCallContent
    assert len(contents) == 1
    assert contents[0].type == "mcp_server_tool_call"
    assert contents[0].call_id == '["response_456", "call_mcp_456"]'
    assert contents[0].tool_name == "fetch_data"
    assert contents[0].server_name == "DataServer"
    assert contents[0].arguments == {"key": "value"}


def test_prepare_options_basic(mock_async_openai: MagicMock) -> None:
    """Test _prepare_options with basic chat options."""
    client = create_test_openai_assistants_client(mock_async_openai)

    # Create basic chat options as a dict
    options = {
        "max_tokens": 100,
        "model_id": "gpt-4",
        "temperature": 0.7,
        "top_p": 0.9,
    }

    messages = [Message(role="user", text="Hello")]

    # Call the method
    run_options, tool_results = client._prepare_options(messages, options)  # type: ignore

    # Check basic options were set
    assert run_options["max_completion_tokens"] == 100
    assert run_options["model"] == "gpt-4"
    assert run_options["temperature"] == 0.7
    assert run_options["top_p"] == 0.9
    assert "tool_choice" not in run_options
    assert tool_results is None


def test_prepare_options_with_tool_tool(mock_async_openai: MagicMock) -> None:
    """Test _prepare_options with a FunctionTool."""

    client = create_test_openai_assistants_client(mock_async_openai)

    # Create a simple function for testing and decorate it
    @tool(approval_mode="never_require")
    def test_function(query: str) -> str:
        """A test function."""
        return f"Result for {query}"

    options = {
        "tools": [test_function],
        "tool_choice": "auto",
    }

    messages = [Message(role="user", text="Hello")]

    # Call the method
    run_options, tool_results = client._prepare_options(messages, options)  # type: ignore

    # Check tools were set correctly
    assert "tools" in run_options
    assert len(run_options["tools"]) == 1
    assert run_options["tools"][0]["type"] == "function"
    assert "function" in run_options["tools"][0]
    assert run_options["tool_choice"] == "auto"


def test_prepare_options_with_tools_without_tool_choice(mock_async_openai: MagicMock) -> None:
    """Test _prepare_options keeps tool_choice unset when not provided."""

    client = create_test_openai_assistants_client(mock_async_openai)

    @tool(approval_mode="never_require")
    def test_function(query: str) -> str:
        """A test function."""
        return f"Result for {query}"

    options = {
        "tools": [test_function],
    }

    messages = [Message(role="user", text="Hello")]
    run_options, _ = client._prepare_options(messages, options)  # type: ignore

    assert "tools" in run_options
    assert "tool_choice" not in run_options


def test_prepare_options_with_single_tool_tool(mock_async_openai: MagicMock) -> None:
    """Test _prepare_options with a single FunctionTool (non-sequence)."""
    client = create_test_openai_assistants_client(mock_async_openai)

    @tool(approval_mode="never_require")
    def test_function(query: str) -> str:
        """A test function."""
        return f"Result for {query}"

    options = {
        "tools": test_function,
        "tool_choice": "auto",
    }

    messages = [Message(role="user", text="Hello")]
    run_options, tool_results = client._prepare_options(messages, options)  # type: ignore

    assert "tools" in run_options
    assert len(run_options["tools"]) == 1
    assert run_options["tools"][0]["type"] == "function"
    assert "function" in run_options["tools"][0]
    assert run_options["tool_choice"] == "auto"
    assert tool_results is None


def test_prepare_options_with_code_interpreter(mock_async_openai: MagicMock) -> None:
    """Test _prepare_options with code interpreter tool."""
    client = create_test_openai_assistants_client(mock_async_openai)

    # Create a code interpreter tool dict
    code_tool = OpenAIAssistantsClient.get_code_interpreter_tool()

    options = {
        "tools": [code_tool],
        "tool_choice": "auto",
    }

    messages = [Message(role="user", text="Calculate something")]

    # Call the method
    run_options, tool_results = client._prepare_options(messages, options)  # type: ignore

    # Check code interpreter tool was set correctly
    assert "tools" in run_options
    assert len(run_options["tools"]) == 1
    assert run_options["tools"][0] == {"type": "code_interpreter"}
    assert run_options["tool_choice"] == "auto"


def test_prepare_options_tool_choice_none(mock_async_openai: MagicMock) -> None:
    """Test _prepare_options with tool_choice set to 'none' and no tools."""
    client = create_test_openai_assistants_client(mock_async_openai)

    options = {
        "tool_choice": "none",
    }

    messages = [Message(role="user", text="Hello")]

    # Call the method
    run_options, tool_results = client._prepare_options(messages, options)  # type: ignore

    # Should set tool_choice to none - no tools because none were provided
    assert run_options["tool_choice"] == "none"
    assert "tools" not in run_options


def test_prepare_options_tool_choice_none_with_tools(mock_async_openai: MagicMock) -> None:
    """Test _prepare_options with tool_choice='none' but tools provided.

    When tool_choice='none', the model won't call tools, but tools should still
    be sent to the API so they're available for future turns in the conversation.
    """
    client = create_test_openai_assistants_client(mock_async_openai)

    # Create a function tool
    @tool(approval_mode="never_require")
    def test_func(arg: str) -> str:
        return arg

    options = {
        "tool_choice": "none",
        "tools": [test_func],
    }

    messages = [Message(role="user", text="Hello")]

    # Call the method
    run_options, tool_results = client._prepare_options(messages, options)  # type: ignore

    # Should set tool_choice to none BUT still include tools
    assert run_options["tool_choice"] == "none"
    assert "tools" in run_options
    assert len(run_options["tools"]) == 1


def test_prepare_options_required_function(mock_async_openai: MagicMock) -> None:
    """Test _prepare_options with required function tool choice."""
    client = create_test_openai_assistants_client(mock_async_openai)

    # Create a required function tool choice as dict
    tool_choice = {"mode": "required", "required_function_name": "specific_function"}

    options = {
        "tool_choice": tool_choice,
    }

    messages = [Message(role="user", text="Hello")]

    # Call the method
    run_options, tool_results = client._prepare_options(messages, options)  # type: ignore

    # Check required function tool choice was set correctly
    expected_tool_choice = {
        "type": "function",
        "function": {"name": "specific_function"},
    }
    assert run_options["tool_choice"] == expected_tool_choice


def test_prepare_options_with_file_search_tool(mock_async_openai: MagicMock) -> None:
    """Test _prepare_options with file_search tool."""

    client = create_test_openai_assistants_client(mock_async_openai)

    # Create a file_search tool with max_results
    file_search_tool = OpenAIAssistantsClient.get_file_search_tool(max_num_results=10)

    options = {
        "tools": [file_search_tool],
        "tool_choice": "auto",
    }

    messages = [Message(role="user", text="Search for information")]

    # Call the method
    run_options, tool_results = client._prepare_options(messages, options)  # type: ignore

    # Check file search tool was set correctly
    assert "tools" in run_options
    assert len(run_options["tools"]) == 1
    expected_tool = {"type": "file_search", "file_search": {"max_num_results": 10}}
    assert run_options["tools"][0] == expected_tool
    assert run_options["tool_choice"] == "auto"


def test_prepare_options_with_mapping_tool(mock_async_openai: MagicMock) -> None:
    """Test _prepare_options with MutableMapping tool."""
    client = create_test_openai_assistants_client(mock_async_openai)

    # Create a tool as a MutableMapping (dict)
    mapping_tool = {"type": "custom_tool", "parameters": {"setting": "value"}}

    options = {
        "tools": [mapping_tool],  # type: ignore
        "tool_choice": "auto",
    }

    messages = [Message(role="user", text="Use custom tool")]

    # Call the method
    run_options, tool_results = client._prepare_options(messages, options)  # type: ignore

    # Check mapping tool was set correctly
    assert "tools" in run_options
    assert len(run_options["tools"]) == 1
    assert run_options["tools"][0] == mapping_tool
    assert run_options["tool_choice"] == "auto"


def test_prepare_options_with_pydantic_response_format(mock_async_openai: MagicMock) -> None:
    """Test _prepare_options sets strict=True for Pydantic response_format."""
    from pydantic import BaseModel, ConfigDict

    class TestResponse(BaseModel):
        name: str
        value: int
        model_config = ConfigDict(extra="forbid")

    client = create_test_openai_assistants_client(mock_async_openai)
    messages = [Message(role="user", text="Test")]
    options = {"response_format": TestResponse}

    run_options, _ = client._prepare_options(messages, options)  # type: ignore

    assert "response_format" in run_options
    assert run_options["response_format"]["type"] == "json_schema"
    assert run_options["response_format"]["json_schema"]["name"] == "TestResponse"
    assert run_options["response_format"]["json_schema"]["strict"] is True


def test_prepare_options_with_system_message(mock_async_openai: MagicMock) -> None:
    """Test _prepare_options with system message converted to instructions."""
    client = create_test_openai_assistants_client(mock_async_openai)

    messages = [
        Message(role="system", text="You are a helpful assistant."),
        Message(role="user", text="Hello"),
    ]

    # Call the method
    run_options, tool_results = client._prepare_options(messages, {})  # type: ignore

    # Check that additional_messages only contains the user message
    # System message should be converted to instructions (though this is handled internally)
    assert "additional_messages" in run_options
    assert len(run_options["additional_messages"]) == 1
    assert run_options["additional_messages"][0]["role"] == "user"


def test_prepare_options_with_image_content(mock_async_openai: MagicMock) -> None:
    """Test _prepare_options with image content."""

    client = create_test_openai_assistants_client(mock_async_openai)

    # Create message with image content
    image_content = Content.from_uri(uri="https://example.com/image.jpg", media_type="image/jpeg")
    messages = [Message(role="user", contents=[image_content])]

    # Call the method
    run_options, tool_results = client._prepare_options(messages, {})  # type: ignore

    # Check that image content was processed
    assert "additional_messages" in run_options
    assert len(run_options["additional_messages"]) == 1
    message = run_options["additional_messages"][0]
    assert message["role"] == "user"
    assert len(message["content"]) == 1
    assert message["content"][0]["type"] == "image_url"
    assert message["content"][0]["image_url"]["url"] == "https://example.com/image.jpg"


def test_prepare_tool_outputs_for_assistants_empty(mock_async_openai: MagicMock) -> None:
    """Test _prepare_tool_outputs_for_assistants with empty list."""
    client = create_test_openai_assistants_client(mock_async_openai)

    run_id, tool_outputs = client._prepare_tool_outputs_for_assistants([])  # type: ignore

    assert run_id is None
    assert tool_outputs is None


def test_prepare_tool_outputs_for_assistants_valid(mock_async_openai: MagicMock) -> None:
    """Test _prepare_tool_outputs_for_assistants with valid function results."""
    client = create_test_openai_assistants_client(mock_async_openai)

    call_id = json.dumps(["run-123", "call-456"])
    function_result = Content.from_function_result(call_id=call_id, result="Function executed successfully")

    run_id, tool_outputs = client._prepare_tool_outputs_for_assistants([function_result])  # type: ignore

    assert run_id == "run-123"
    assert tool_outputs is not None
    assert len(tool_outputs) == 1
    assert tool_outputs[0].get("tool_call_id") == "call-456"
    assert tool_outputs[0].get("output") == "Function executed successfully"


def test_prepare_tool_outputs_for_assistants_mismatched_run_ids(
    mock_async_openai: MagicMock,
) -> None:
    """Test _prepare_tool_outputs_for_assistants with mismatched run IDs."""
    client = create_test_openai_assistants_client(mock_async_openai)

    # Create function results with different run IDs
    call_id1 = json.dumps(["run-123", "call-456"])
    call_id2 = json.dumps(["run-789", "call-xyz"])  # Different run ID
    function_result1 = Content.from_function_result(call_id=call_id1, result="Result 1")
    function_result2 = Content.from_function_result(call_id=call_id2, result="Result 2")

    run_id, tool_outputs = client._prepare_tool_outputs_for_assistants([function_result1, function_result2])  # type: ignore

    # Should only process the first one since run IDs don't match
    assert run_id == "run-123"
    assert tool_outputs is not None
    assert len(tool_outputs) == 1
    assert tool_outputs[0].get("tool_call_id") == "call-456"


def test_update_agent_name_and_description(mock_async_openai: MagicMock) -> None:
    """Test _update_agent_name_and_description method updates assistant_name when not already set."""
    # Test updating agent name when assistant_name is None
    client = create_test_openai_assistants_client(mock_async_openai, assistant_name=None)

    # Call the private method to update agent name
    client._update_agent_name_and_description("New Assistant Name")  # type: ignore

    assert client.assistant_name == "New Assistant Name"


def test_update_agent_name_and_description_existing(mock_async_openai: MagicMock) -> None:
    """Test _update_agent_name_and_description method doesn't override existing assistant_name."""
    # Test that existing assistant_name is not overridden
    client = create_test_openai_assistants_client(mock_async_openai, assistant_name="Existing Assistant")

    # Call the private method to update agent name
    client._update_agent_name_and_description("New Assistant Name")  # type: ignore

    # Should keep the existing name
    assert client.assistant_name == "Existing Assistant"


def test_update_agent_name_and_description_none(mock_async_openai: MagicMock) -> None:
    """Test _update_agent_name_and_description method with None agent_name parameter."""
    # Test that None agent_name doesn't change anything
    client = create_test_openai_assistants_client(mock_async_openai, assistant_name=None)

    # Call the private method with None
    client._update_agent_name_and_description(None)  # type: ignore

    # Should remain None
    assert client.assistant_name is None


@tool(approval_mode="never_require")
def get_weather(
    location: Annotated[str, Field(description="The location to get the weather for.")],
) -> str:
    """Get the weather for a given location."""
    return f"The weather in {location} is sunny with a high of 25°C."


@pytest.mark.flaky
@pytest.mark.integration
@skip_if_openai_integration_tests_disabled
async def test_get_response() -> None:
    """Test OpenAI Assistants Client response."""
    async with OpenAIAssistantsClient(model_id=INTEGRATION_TEST_MODEL) as openai_assistants_client:
        assert isinstance(openai_assistants_client, SupportsChatGetResponse)

        messages: list[Message] = []
        messages.append(
            Message(
                role="user",
                text="The weather in Seattle is currently sunny with a high of 25°C. "
                "It's a beautiful day for outdoor activities.",
            )
        )
        messages.append(Message(role="user", text="What's the weather like today?"))

        # Test that the client can be used to get a response
        response = await openai_assistants_client.get_response(messages=messages)

        assert response is not None
        assert isinstance(response, ChatResponse)
        assert any(word in response.text.lower() for word in ["sunny", "25", "weather", "seattle"])


@pytest.mark.flaky
@pytest.mark.integration
@skip_if_openai_integration_tests_disabled
async def test_get_response_tools() -> None:
    """Test OpenAI Assistants Client response with tools."""
    async with OpenAIAssistantsClient(model_id=INTEGRATION_TEST_MODEL) as openai_assistants_client:
        assert isinstance(openai_assistants_client, SupportsChatGetResponse)

        messages: list[Message] = []
        messages.append(Message(role="user", text="What's the weather like in Seattle?"))

        # Test that the client can be used to get a response
        response = await openai_assistants_client.get_response(
            messages=messages,
            options={"tools": [get_weather], "tool_choice": "auto"},
        )

        assert response is not None
        assert isinstance(response, ChatResponse)
        assert any(word in response.text.lower() for word in ["sunny", "25", "weather"])


@pytest.mark.flaky
@pytest.mark.integration
@skip_if_openai_integration_tests_disabled
async def test_streaming() -> None:
    """Test OpenAI Assistants Client streaming response."""
    async with OpenAIAssistantsClient(model_id=INTEGRATION_TEST_MODEL) as openai_assistants_client:
        assert isinstance(openai_assistants_client, SupportsChatGetResponse)

        messages: list[Message] = []
        messages.append(
            Message(
                role="user",
                text="The weather in Seattle is currently sunny with a high of 25°C. "
                "It's a beautiful day for outdoor activities.",
            )
        )
        messages.append(Message(role="user", text="What's the weather like today?"))

        # Test that the client can be used to get a response
        response = openai_assistants_client.get_response(stream=True, messages=messages)

        full_message: str = ""
        async for chunk in response:
            assert chunk is not None
            assert isinstance(chunk, ChatResponseUpdate)
            for content in chunk.contents:
                if content.type == "text" and content.text:
                    full_message += content.text

        assert any(word in full_message.lower() for word in ["sunny", "25", "weather", "seattle"])


@pytest.mark.flaky
@pytest.mark.integration
@skip_if_openai_integration_tests_disabled
async def test_streaming_tools() -> None:
    """Test OpenAI Assistants Client streaming response with tools."""
    async with OpenAIAssistantsClient(model_id=INTEGRATION_TEST_MODEL) as openai_assistants_client:
        assert isinstance(openai_assistants_client, SupportsChatGetResponse)

        messages: list[Message] = []
        messages.append(Message(role="user", text="What's the weather like in Seattle?"))

        # Test that the client can be used to get a response
        response = openai_assistants_client.get_response(
            stream=True,
            messages=messages,
            options={
                "tools": [get_weather],
                "tool_choice": "auto",
            },
        )
        full_message: str = ""
        async for chunk in response:
            assert chunk is not None
            assert isinstance(chunk, ChatResponseUpdate)
            for content in chunk.contents:
                if content.type == "text" and content.text:
                    full_message += content.text

        assert any(word in full_message.lower() for word in ["sunny", "25", "weather"])


@pytest.mark.flaky
@pytest.mark.integration
@skip_if_openai_integration_tests_disabled
async def test_with_existing_assistant() -> None:
    """Test OpenAI Assistants Client with existing assistant ID."""
    # First create an assistant to use in the test
    async with OpenAIAssistantsClient(model_id=INTEGRATION_TEST_MODEL) as temp_client:
        # Get the assistant ID by triggering assistant creation
        messages = [Message(role="user", text="Hello")]
        await temp_client.get_response(messages=messages)
        assistant_id = temp_client.assistant_id

        # Now test using the existing assistant
        async with OpenAIAssistantsClient(
            model_id=INTEGRATION_TEST_MODEL, assistant_id=assistant_id
        ) as openai_assistants_client:
            assert isinstance(openai_assistants_client, SupportsChatGetResponse)
            assert openai_assistants_client.assistant_id == assistant_id

            messages = [Message(role="user", text="What can you do?")]

            # Test that the client can be used to get a response
            response = await openai_assistants_client.get_response(messages=messages)

            assert response is not None
            assert isinstance(response, ChatResponse)
            assert len(response.text) > 0


@pytest.mark.flaky
@pytest.mark.integration
@skip_if_openai_integration_tests_disabled
@pytest.mark.skip(reason="OpenAI file search functionality is currently broken - tracked in GitHub issue")
async def test_file_search() -> None:
    """Test OpenAI Assistants Client response."""
    async with OpenAIAssistantsClient(model_id=INTEGRATION_TEST_MODEL) as openai_assistants_client:
        assert isinstance(openai_assistants_client, SupportsChatGetResponse)

        messages: list[Message] = []
        messages.append(Message(role="user", text="What's the weather like today?"))

        file_id, vector_store = await create_vector_store(openai_assistants_client)
        response = await openai_assistants_client.get_response(
            messages=messages,
            options={
                "tools": [OpenAIAssistantsClient.get_file_search_tool()],
                "tool_resources": {"file_search": {"vector_store_ids": [vector_store.vector_store_id]}},
            },
        )
        await delete_vector_store(openai_assistants_client, file_id, vector_store.vector_store_id)

        assert response is not None
        assert isinstance(response, ChatResponse)
        assert any(word in response.text.lower() for word in ["sunny", "25", "weather"])


@pytest.mark.flaky
@pytest.mark.integration
@skip_if_openai_integration_tests_disabled
@pytest.mark.skip(reason="OpenAI file search functionality is currently broken - tracked in GitHub issue")
async def test_file_search_streaming() -> None:
    """Test OpenAI Assistants Client response."""
    async with OpenAIAssistantsClient(model_id=INTEGRATION_TEST_MODEL) as openai_assistants_client:
        assert isinstance(openai_assistants_client, SupportsChatGetResponse)

        messages: list[Message] = []
        messages.append(Message(role="user", text="What's the weather like today?"))

        file_id, vector_store = await create_vector_store(openai_assistants_client)
        response = openai_assistants_client.get_response(
            stream=True,
            messages=messages,
            options={
                "tools": [OpenAIAssistantsClient.get_file_search_tool()],
                "tool_resources": {"file_search": {"vector_store_ids": [vector_store.vector_store_id]}},
            },
        )

        assert response is not None
        full_message: str = ""
        async for chunk in response:
            assert chunk is not None
            assert isinstance(chunk, ChatResponseUpdate)
            for content in chunk.contents:
                if content.type == "text" and content.text:
                    full_message += content.text
        await delete_vector_store(openai_assistants_client, file_id, vector_store.vector_store_id)

        assert any(word in full_message.lower() for word in ["sunny", "25", "weather"])


@pytest.mark.flaky
@pytest.mark.integration
@skip_if_openai_integration_tests_disabled
async def test_openai_assistants_agent_basic_run():
    """Test Agent basic run functionality with OpenAIAssistantsClient."""
    async with Agent(
        client=OpenAIAssistantsClient(model_id=INTEGRATION_TEST_MODEL),
    ) as agent:
        # Run a simple query
        response = await agent.run("Hello! Please respond with 'Hello World' exactly.")

        # Validate response
        assert isinstance(response, AgentResponse)
        assert response.text is not None
        assert len(response.text) > 0
        assert "Hello World" in response.text


@pytest.mark.flaky
@pytest.mark.integration
@skip_if_openai_integration_tests_disabled
async def test_openai_assistants_agent_basic_run_streaming():
    """Test Agent basic streaming functionality with OpenAIAssistantsClient."""
    async with Agent(
        client=OpenAIAssistantsClient(model_id=INTEGRATION_TEST_MODEL),
    ) as agent:
        # Run streaming query
        full_message: str = ""
        async for chunk in agent.run("Please respond with exactly: 'This is a streaming response test.'", stream=True):
            assert chunk is not None
            assert isinstance(chunk, AgentResponseUpdate)
            if chunk.text:
                full_message += chunk.text

        # Validate streaming response
        assert len(full_message) > 0
        assert "streaming response test" in full_message.lower()


@pytest.mark.flaky
@pytest.mark.integration
@skip_if_openai_integration_tests_disabled
async def test_openai_assistants_agent_session_persistence():
    """Test Agent session persistence across runs with OpenAIAssistantsClient."""
    async with Agent(
        client=OpenAIAssistantsClient(model_id=INTEGRATION_TEST_MODEL),
        instructions="You are a helpful assistant with good memory.",
    ) as agent:
        # Create a new session that will be reused
        session = agent.create_session()

        # First message - establish context
        first_response = await agent.run(
            "Remember this number: 42. What number did I just tell you to remember?", session=session
        )
        assert isinstance(first_response, AgentResponse)
        assert "42" in first_response.text

        # Second message - test conversation memory
        second_response = await agent.run(
            "What number did I tell you to remember in my previous message?", session=session
        )
        assert isinstance(second_response, AgentResponse)
        assert "42" in second_response.text

        # Verify session has been populated with conversation ID
        assert session.service_session_id is not None


@pytest.mark.flaky
@pytest.mark.integration
@skip_if_openai_integration_tests_disabled
async def test_openai_assistants_agent_existing_session_id():
    """Test Agent with existing session ID to continue conversations across agent instances."""
    # First, create a conversation and capture the session ID
    existing_session_id = None

    async with Agent(
        client=OpenAIAssistantsClient(model_id=INTEGRATION_TEST_MODEL),
        instructions="You are a helpful weather agent.",
        tools=[get_weather],
    ) as agent:
        # Start a conversation and get the session ID
        session = agent.create_session()
        response1 = await agent.run("What's the weather in Paris?", session=session)

        # Validate first response
        assert isinstance(response1, AgentResponse)
        assert response1.text is not None
        assert any(word in response1.text.lower() for word in ["weather", "paris"])

        # The session ID is set after the first response
        existing_session_id = session.service_session_id
        assert existing_session_id is not None

    # Now continue with the same session ID in a new agent instance

    async with Agent(
        client=OpenAIAssistantsClient(thread_id=existing_session_id),
        instructions="You are a helpful weather agent.",
        tools=[get_weather],
    ) as agent:
        # Create a session with the existing ID
        session = AgentSession(service_session_id=existing_session_id)

        # Ask about the previous conversation
        response2 = await agent.run("What was the last city I asked about?", session=session)

        # Validate that the agent remembers the previous conversation
        assert isinstance(response2, AgentResponse)
        assert response2.text is not None
        # Should reference Paris from the previous conversation
        assert "paris" in response2.text.lower()


@pytest.mark.flaky
@pytest.mark.integration
@skip_if_openai_integration_tests_disabled
async def test_openai_assistants_agent_code_interpreter():
    """Test Agent with code interpreter through OpenAIAssistantsClient."""

    async with Agent(
        client=OpenAIAssistantsClient(model_id=INTEGRATION_TEST_MODEL),
        instructions="You are a helpful assistant that can write and execute Python code.",
        tools=[OpenAIAssistantsClient.get_code_interpreter_tool()],
    ) as agent:
        # Request code execution
        response = await agent.run("Write Python code to calculate the factorial of 5 and show the result.")

        # Validate response
        assert isinstance(response, AgentResponse)
        assert response.text is not None
        # Factorial of 5 is 120
        assert "120" in response.text or "factorial" in response.text.lower()


@pytest.mark.flaky
@pytest.mark.integration
@skip_if_openai_integration_tests_disabled
async def test_agent_level_tool_persistence():
    """Test that agent-level tools persist across multiple runs with OpenAI Assistants Client."""

    async with Agent(
        client=OpenAIAssistantsClient(model_id=INTEGRATION_TEST_MODEL),
        instructions="You are a helpful assistant that uses available tools.",
        tools=[get_weather],  # Agent-level tool
    ) as agent:
        # First run - agent-level tool should be available
        first_response = await agent.run("What's the weather like in Chicago?")

        assert isinstance(first_response, AgentResponse)
        assert first_response.text is not None
        # Should use the agent-level weather tool
        assert any(term in first_response.text.lower() for term in ["chicago", "sunny", "72"])

        # Second run - agent-level tool should still be available (persistence test)
        second_response = await agent.run("What's the weather in Miami?")

        assert isinstance(second_response, AgentResponse)
        assert second_response.text is not None
        # Should use the agent-level weather tool again
        assert any(term in second_response.text.lower() for term in ["miami", "sunny", "72"])


# Callable API Key Tests
def test_with_callable_api_key() -> None:
    """Test OpenAIAssistantsClient initialization with callable API key."""

    async def get_api_key() -> str:
        return "test-api-key-123"

    client = OpenAIAssistantsClient(model_id="gpt-4o", api_key=get_api_key)

    # Verify client was created successfully
    assert client.model_id == "gpt-4o"
    # OpenAI SDK now manages callable API keys internally
    assert client.client is not None


# region thread.message.completed helpers


def _make_stream_event(event: str, data: Any) -> MagicMock:
    """Create a mock stream event."""
    mock = MagicMock()
    mock.event = event
    mock.data = data
    return mock


def _make_text_block(text_value: str, annotations: list | None = None) -> MagicMock:
    """Create a mock TextContentBlock with optional annotations."""
    block = MagicMock()
    block.type = "text"
    block.text = MagicMock()
    block.text.value = text_value
    block.text.annotations = annotations or []
    return block


def _make_image_block() -> MagicMock:
    """Create a mock ImageContentBlock (non-text block)."""
    block = MagicMock()
    block.type = "image_file"
    return block


def _make_file_citation_annotation(
    text: str = "【4:0†source】",
    file_id: str = "file-abc123",
    start_index: int = 10,
    end_index: int = 24,
) -> MagicMock:
    """Create a mock FileCitationAnnotation."""
    annotation = MagicMock(spec=FileCitationAnnotation)
    annotation.text = text
    annotation.start_index = start_index
    annotation.end_index = end_index
    annotation.file_citation = MagicMock()
    annotation.file_citation.file_id = file_id
    return annotation


def _make_file_path_annotation(
    text: str = "sandbox:/file.csv",
    file_id: str = "file-xyz789",
    start_index: int = 5,
    end_index: int = 22,
) -> MagicMock:
    """Create a mock FilePathAnnotation."""
    annotation = MagicMock(spec=FilePathAnnotation)
    annotation.text = text
    annotation.start_index = start_index
    annotation.end_index = end_index
    annotation.file_path = MagicMock()
    annotation.file_path.file_id = file_id
    return annotation


def _make_unknown_annotation() -> MagicMock:
    """Create a mock annotation of an unrecognized type."""
    annotation = MagicMock()
    annotation.__class__.__name__ = "FutureAnnotationType"
    return annotation


def _make_thread_message(content_blocks: list) -> MagicMock:
    """Create a mock ThreadMessage."""
    msg = MagicMock(spec=ThreadMessage)
    msg.content = content_blocks
    return msg


async def _collect_updates(client, stream_events, thread_id="thread_123"):
    """Helper to collect ChatResponseUpdate objects from _process_stream_events."""

    class MockAsyncStream:
        def __init__(self, events):
            self._events = events

        async def __aenter__(self):
            return self

        async def __aexit__(self, *args):
            pass

        def __aiter__(self):
            return self

        async def __anext__(self):
            if not self._events:
                raise StopAsyncIteration
            return self._events.pop(0)

    mock_stream = MockAsyncStream(list(stream_events))
    results = []
    async for update in client._process_stream_events(mock_stream, thread_id):
        results.append(update)
    return results


# endregion


class TestMessageCompletedAnnotations:
    """Tests for thread.message.completed event handling."""

    @pytest.fixture
    def client(self):
        """Create a client instance for testing."""
        with patch.object(OpenAIAssistantsClient, "__init__", lambda self, **kw: None):
            return object.__new__(OpenAIAssistantsClient)

    @pytest.mark.asyncio
    async def test_message_completed_with_file_citation(self, client):
        """Verify file citation annotations are extracted from completed messages."""
        citation = _make_file_citation_annotation(
            text="【4:0†source】", file_id="file-abc123", start_index=10, end_index=24
        )
        text_block = _make_text_block("Some text with a citation【4:0†source】", [citation])
        msg = _make_thread_message([text_block])

        events = [_make_stream_event("thread.message.completed", msg)]
        updates = await _collect_updates(client, events)

        # Should yield exactly one update for the completed message
        assert len(updates) == 1
        update = updates[0]
        assert update.role == "assistant"
        assert len(update.contents) == 1

        content = update.contents[0]
        assert content.text == "Some text with a citation【4:0†source】"
        assert content.annotations is not None
        assert len(content.annotations) == 1

        ann = content.annotations[0]
        assert ann["type"] == "citation"
        assert ann["file_id"] == "file-abc123"
        assert ann["annotated_regions"][0]["start_index"] == 10
        assert ann["annotated_regions"][0]["end_index"] == 24

    @pytest.mark.asyncio
    async def test_message_completed_with_file_path(self, client):
        """Verify file path annotations are extracted from completed messages."""
        file_path = _make_file_path_annotation(
            text="sandbox:/output.csv", file_id="file-xyz789", start_index=0, end_index=19
        )
        text_block = _make_text_block("sandbox:/output.csv", [file_path])
        msg = _make_thread_message([text_block])

        events = [_make_stream_event("thread.message.completed", msg)]
        updates = await _collect_updates(client, events)

        assert len(updates) == 1
        content = updates[0].contents[0]
        assert content.annotations is not None
        assert len(content.annotations) == 1

        ann = content.annotations[0]
        assert ann["type"] == "citation"
        assert ann["file_id"] == "file-xyz789"
        assert ann["annotated_regions"][0]["start_index"] == 0
        assert ann["annotated_regions"][0]["end_index"] == 19

    @pytest.mark.asyncio
    async def test_message_completed_multiple_annotations(self, client):
        """Verify multiple annotations on a single text block are all captured."""
        cit1 = _make_file_citation_annotation(text="【1†src】", file_id="file-a", start_index=5, end_index=12)
        cit2 = _make_file_citation_annotation(text="【2†src】", file_id="file-b", start_index=20, end_index=27)
        text_block = _make_text_block("Hello【1†src】world【2†src】", [cit1, cit2])
        msg = _make_thread_message([text_block])

        events = [_make_stream_event("thread.message.completed", msg)]
        updates = await _collect_updates(client, events)

        assert len(updates) == 1
        assert len(updates[0].contents[0].annotations) == 2
        assert updates[0].contents[0].annotations[0]["file_id"] == "file-a"
        assert updates[0].contents[0].annotations[1]["file_id"] == "file-b"

    @pytest.mark.asyncio
    async def test_message_completed_no_annotations(self, client):
        """Verify text-only completed messages produce content without annotations."""
        text_block = _make_text_block("Plain text response")
        msg = _make_thread_message([text_block])

        events = [_make_stream_event("thread.message.completed", msg)]
        updates = await _collect_updates(client, events)

        assert len(updates) == 1
        content = updates[0].contents[0]
        assert content.text == "Plain text response"
        assert content.annotations is None or len(content.annotations) == 0

    @pytest.mark.asyncio
    async def test_message_completed_skips_non_text_blocks(self, client):
        """Verify non-text content blocks (e.g., image_file) are skipped."""
        image_block = _make_image_block()
        msg = _make_thread_message([image_block])

        events = [_make_stream_event("thread.message.completed", msg)]
        updates = await _collect_updates(client, events)

        # No text blocks → no update yielded
        assert len(updates) == 0

    @pytest.mark.asyncio
    async def test_message_completed_mixed_blocks(self, client):
        """Verify only text blocks are processed in mixed-content messages."""
        text_block = _make_text_block("Text content here")
        image_block = _make_image_block()
        msg = _make_thread_message([image_block, text_block])

        events = [_make_stream_event("thread.message.completed", msg)]
        updates = await _collect_updates(client, events)

        assert len(updates) == 1
        assert len(updates[0].contents) == 1
        assert updates[0].contents[0].text == "Text content here"

    @pytest.mark.asyncio
    async def test_message_completed_conversation_id_preserved(self, client):
        """Verify the thread_id is correctly propagated as conversation_id."""
        text_block = _make_text_block("Response text")
        msg = _make_thread_message([text_block])

        events = [_make_stream_event("thread.message.completed", msg)]
        updates = await _collect_updates(client, events, thread_id="thread_custom_456")

        assert len(updates) == 1
        assert updates[0].conversation_id == "thread_custom_456"

    @pytest.mark.asyncio
    async def test_message_completed_unrecognized_annotation_logged(self, client, caplog):
        """Verify unrecognized annotation types are logged at debug level and skipped."""
        unknown_ann = _make_unknown_annotation()
        citation = _make_file_citation_annotation(text="【1†src】", file_id="file-a", start_index=0, end_index=7)
        text_block = _make_text_block("Text【1†src】", [unknown_ann, citation])
        msg = _make_thread_message([text_block])

        events = [_make_stream_event("thread.message.completed", msg)]
        with caplog.at_level(logging.DEBUG, logger="agent_framework.openai"):
            updates = await _collect_updates(client, events)

        # The known citation should still be processed
        assert len(updates) == 1
        assert len(updates[0].contents[0].annotations) == 1
        assert updates[0].contents[0].annotations[0]["file_id"] == "file-a"

        # The unrecognized annotation should have been logged
        assert any("Unparsed annotation type" in record.message for record in caplog.records)
