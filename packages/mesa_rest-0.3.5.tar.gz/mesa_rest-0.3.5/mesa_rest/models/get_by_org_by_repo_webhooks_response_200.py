from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from typing import cast

if TYPE_CHECKING:
  from ..models.get_by_org_by_repo_webhooks_response_200_webhooks_item import GetByOrgByRepoWebhooksResponse200WebhooksItem





T = TypeVar("T", bound="GetByOrgByRepoWebhooksResponse200")



@_attrs_define
class GetByOrgByRepoWebhooksResponse200:
    """ 
        Attributes:
            webhooks (list[GetByOrgByRepoWebhooksResponse200WebhooksItem]):
     """

    webhooks: list[GetByOrgByRepoWebhooksResponse200WebhooksItem]
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.get_by_org_by_repo_webhooks_response_200_webhooks_item import GetByOrgByRepoWebhooksResponse200WebhooksItem
        webhooks = []
        for webhooks_item_data in self.webhooks:
            webhooks_item = webhooks_item_data.to_dict()
            webhooks.append(webhooks_item)




        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "webhooks": webhooks,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.get_by_org_by_repo_webhooks_response_200_webhooks_item import GetByOrgByRepoWebhooksResponse200WebhooksItem
        d = dict(src_dict)
        webhooks = []
        _webhooks = d.pop("webhooks")
        for webhooks_item_data in (_webhooks):
            webhooks_item = GetByOrgByRepoWebhooksResponse200WebhooksItem.from_dict(webhooks_item_data)



            webhooks.append(webhooks_item)


        get_by_org_by_repo_webhooks_response_200 = cls(
            webhooks=webhooks,
        )


        get_by_org_by_repo_webhooks_response_200.additional_properties = d
        return get_by_org_by_repo_webhooks_response_200

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
