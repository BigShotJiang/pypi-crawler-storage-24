from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset







T = TypeVar("T", bound="PostByOrgByRepoCommitsResponse201")



@_attrs_define
class PostByOrgByRepoCommitsResponse201:
    """ 
        Attributes:
            sha (str):
            branch (str):
            message (str):
     """

    sha: str
    branch: str
    message: str
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        sha = self.sha

        branch = self.branch

        message = self.message


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "sha": sha,
            "branch": branch,
            "message": message,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        sha = d.pop("sha")

        branch = d.pop("branch")

        message = d.pop("message")

        post_by_org_by_repo_commits_response_201 = cls(
            sha=sha,
            branch=branch,
            message=message,
        )


        post_by_org_by_repo_commits_response_201.additional_properties = d
        return post_by_org_by_repo_commits_response_201

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
