from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from typing import cast

if TYPE_CHECKING:
  from ..models.patch_by_org_by_repo_response_200_upstream_type_0 import PatchByOrgByRepoResponse200UpstreamType0





T = TypeVar("T", bound="PatchByOrgByRepoResponse200")



@_attrs_define
class PatchByOrgByRepoResponse200:
    """ 
        Attributes:
            id (str):
            org (str):
            name (str):
            default_branch (str):
            head_oid (None | str):
            size_bytes (float):
            created_at (str):
            upstream (None | PatchByOrgByRepoResponse200UpstreamType0): Optionally add an upstream repository. You can
                configure automatic syncing from the upstream repository.
     """

    id: str
    org: str
    name: str
    default_branch: str
    head_oid: None | str
    size_bytes: float
    created_at: str
    upstream: None | PatchByOrgByRepoResponse200UpstreamType0
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.patch_by_org_by_repo_response_200_upstream_type_0 import PatchByOrgByRepoResponse200UpstreamType0
        id = self.id

        org = self.org

        name = self.name

        default_branch = self.default_branch

        head_oid: None | str
        head_oid = self.head_oid

        size_bytes = self.size_bytes

        created_at = self.created_at

        upstream: dict[str, Any] | None
        if isinstance(self.upstream, PatchByOrgByRepoResponse200UpstreamType0):
            upstream = self.upstream.to_dict()
        else:
            upstream = self.upstream


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "id": id,
            "org": org,
            "name": name,
            "default_branch": default_branch,
            "head_oid": head_oid,
            "size_bytes": size_bytes,
            "created_at": created_at,
            "upstream": upstream,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.patch_by_org_by_repo_response_200_upstream_type_0 import PatchByOrgByRepoResponse200UpstreamType0
        d = dict(src_dict)
        id = d.pop("id")

        org = d.pop("org")

        name = d.pop("name")

        default_branch = d.pop("default_branch")

        def _parse_head_oid(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        head_oid = _parse_head_oid(d.pop("head_oid"))


        size_bytes = d.pop("size_bytes")

        created_at = d.pop("created_at")

        def _parse_upstream(data: object) -> None | PatchByOrgByRepoResponse200UpstreamType0:
            if data is None:
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                upstream_type_0 = PatchByOrgByRepoResponse200UpstreamType0.from_dict(data)



                return upstream_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | PatchByOrgByRepoResponse200UpstreamType0, data)

        upstream = _parse_upstream(d.pop("upstream"))


        patch_by_org_by_repo_response_200 = cls(
            id=id,
            org=org,
            name=name,
            default_branch=default_branch,
            head_oid=head_oid,
            size_bytes=size_bytes,
            created_at=created_at,
            upstream=upstream,
        )


        patch_by_org_by_repo_response_200.additional_properties = d
        return patch_by_org_by_repo_response_200

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
