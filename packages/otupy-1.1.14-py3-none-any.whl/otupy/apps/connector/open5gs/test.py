import yaml

#with open('data.yml') as f:
with open('amf.yaml') as f:
    docs = yaml.load_all(f, Loader=yaml.FullLoader)
    for x in docs:
        print("First doc: ")
        for k, v in x.items():
            print(k, ":", v)
