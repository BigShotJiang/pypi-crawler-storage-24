The procedure to push an image to the github docker registry (aka "packages") is the following:
- Change the docker file (docker/*/Dockerfile)
- commit the docker file
- add a tag to the commit (e.g., v1.0.2)
- push to the origin/main
This should automatically trigger the workflow for building containers, and an image should
be created with the same tag as the commit.

I didn't understand why, but this did not happen for ueransim (same file as mongodb, triggered,
image available but not tagged). After a lot of experiments, the only working workaround was:

(on abete)
- download latest build from the repository:
% sudo docker pull ghcr.io/mattereppe/ueransim:main
- create a new image (locally) with the  desired tag:
% sudo docker tag 6f0ce5a0dcdd ghcr.io/mattereppe/ueransim:v1.0.2
% sudo docker tag 6f0ce5a0dcdd ghcr.io/mattereppe/ueransim:latest
- authenticate to the repository with the pat "PAT-github-packages.txt"
	(in case this expires, generate a new PAT with write permission to packages)
% sudo docker login ghcr.io
Username: mattereppe
Password: <copy the PAT>
- upload the image with the new tag:
% sudo docker push ghcr.io/mattereppe/ueransim:v1.0.2
% sudo docker tag 6f0ce5a0dcdd ghcr.io/mattereppe/ueransim:latest

Now the new tags should be available in the registry.

