This is an unnecessary modification done when patching ueransim for additional routes towards data networks.
There is a place in the code where gnbSearchList is converted from strings to InetAddresses, and for some
reason I believed the same should have been done for dataNetworkList. Instead, this is not necessary, because
dataNetworkList is only used as strings when composing the cli command.

However, I kept this code as an example of how network addresses could be parsed to split the real address from the 
prefix indication.
