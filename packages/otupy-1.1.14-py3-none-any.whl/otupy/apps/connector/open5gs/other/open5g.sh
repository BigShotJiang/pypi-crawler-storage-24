#!/bin/bash

# Create the namespace
kubectl apply -f deploy/namespace.yaml

# Load the secret for pulling images from github
kubectl apply -f deploy/github-secret.yaml
# Secrets must be updated with the CLI command, then exported in yaml and copied to the above file.

# Create persistent volume for mongodb
kubectl -n open5gs apply -f storage/persistent-volume.yaml

# Load mongodb (likely "-n open5gs" is not necessary because already included in the yaml definition)
kubectl apply -f deploy/mongodb-configmap.yaml
kubectl -n open5gs apply -f deploy/mongodb.yaml 

# Load the control/user plane
kubectl apply -f deploy/nrf-configmap.yaml
kubectl apply -f deploy/nrf.yaml
kubectl apply -f deploy/scp-configmap.yaml
kubectl apply -f deploy/scp.yaml
kubectl apply -f deploy/udm-configmap.yaml
kubectl apply -f deploy/udm.yaml
kubectl apply -f deploy/amf-configmap.yaml
kubectl apply -f deploy/amf.yaml
kubectl apply -f deploy/pcf-configmap.yaml 
kubectl apply -f deploy/pcf.yaml
kubectl apply -f deploy/ausf-configmap.yaml
kubectl apply -f deploy/ausf.yaml
kubectl apply -f deploy/bsf-configmap.yaml 
kubectl apply -f deploy/bsf.yaml
kubectl apply -f deploy/nssf-configmap.yaml
kubectl apply -f  deploy/nssf.yaml
kubectl apply -f deploy/upf-configmap.yaml
kubectl apply -f deploy/upf.yaml
kubectl apply -f deploy/smf-configmap.yaml
kubectl apply -f deploy/smf.yaml
kubectl apply -f deploy/udr-configmap.yaml
kubectl apply -f deploy/udr.yaml
kubectl apply -f  deploy/webui-configmap.yaml 
kubectl apply -f  deploy/webui.yaml

# Load the RAN/UE (UERANSIM)
#kubectl apply -f deploy/gnb-configmap.yaml
#kubectl apply -f deploy/gnb.yaml
#kubectl apply -f deploy/ue-configmap.yaml
#kubectl apply -f deploy/ue.yaml
