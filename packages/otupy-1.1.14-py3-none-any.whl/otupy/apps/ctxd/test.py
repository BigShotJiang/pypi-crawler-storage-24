str="{'name': {'local': 'open5gs'}, 'id': '3297156c-89ab-4150-aa35-1493bfefc8a3', 'description': 'open5gs', 'image': 'baa89d5d-8166-4c43-8ee0-1ea72e7f3117'}"
str2=str.replace("'","\"")
import json
from otupy.profiles.ctxd import *
from otupy import *
vm=json.loads(str2)
Encoder.decode(VM, vm)
