This module allows to edit several records at the same time in any Odoo model.
