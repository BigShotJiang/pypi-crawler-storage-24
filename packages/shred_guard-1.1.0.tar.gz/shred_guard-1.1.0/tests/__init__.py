"""Tests for ShredGuard."""
