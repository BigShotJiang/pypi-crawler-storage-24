###############################################################################
# (c) Copyright 2025 CERN for the benefit of the LHCb Collaboration           #
#                                                                             #
# This software is distributed under the terms of the GNU General Public      #
# Licence version 3 (GPL Version 3), copied verbatim in the file "COPYING".   #
#                                                                             #
# In applying this licence, CERN does not waive the privileges and immunities #
# granted to it by virtue of its status as an Intergovernmental Organization  #
# or submit itself to any jurisdiction.                                       #
###############################################################################
"""Recipe schema definitions for AP YAML configurations.

These Pydantic models define the schema for recipe configurations. The actual
recipe expansion is handled by the JavaScript transform (yaml-transform.js).
These models are kept for JSON schema generation for the web UI.
"""

from typing import Literal

from pydantic import BaseModel, Field, model_validator


class SplittingRecipe(BaseModel):
    """Recipe for splitting ROOT files by tree name patterns."""

    name: Literal["split-trees"]
    env_version: str = "2026-02-04"

    class SplitHow(BaseModel):
        key: str = Field(
            title="Key pattern.",
            description="Any object inside the ROOT file matching this regular expression would be selected to be saved.",
            examples=["Tuple_SpruceSLB_(Bc).*?/DecayTree"],
        )
        into: str = Field(
            title="File to save matching keys into.",
            description=(
                "The output file type without an extension. Should be lowercase. "
                "For example: 'BC.ROOT' would save any key names matching the 'key' regular expression into 'BC.ROOT'."
            ),
            pattern=r"[A-Z][A-Z0-9]+\.ROOT",
            examples=["BC", "RIGHTSIGN"],
        )

    split: list[SplitHow]


class FilteringRecipe(BaseModel):
    """Recipe for filtering ROOT files using a custom entrypoint."""

    name: Literal["filter-trees"]
    env_version: str = "2026-02-05"
    entrypoint: str = Field(
        title="Entrypoint",
        description="Which filtering entrypoint to run.",
        examples=["MyAnalysis.filter_script:run_preselection"],
    )
    extra_args: list[str] = Field(
        title="Extra args",
        description="Arguments to pass to the filtering function.",
        default_factory=list,
    )


class PIDGenTrackConfig(BaseModel):
    """Per-track configuration for PIDGen2 resampling."""

    sample: str = Field(
        title="Calibration sample",
        description="Name of the calibration sample to use for resampling.",
        examples=["K_Dstar2Dpi", "pi_Dstar2Dpi"],
    )
    dataset: str = Field(
        title="Dataset",
        description="Dataset name (polarity_year or block-polarity-particle format).",
        examples=["MagUp_2016", "2024_WithUT_block5-MagUp-K"],
    )
    variable: str = Field(
        title="Variable to resample",
        description="Name of the variable to resample.",
        examples=["PID_K", "MC15TuneV1_ProbNNpi"],
    )
    branches: str = Field(
        default="pt:eta:ntr",
        title="Input branches",
        description="Colon-separated branch names used for resampling.",
        examples=["Km_PT:Km_ETA:nLongTracks"],
    )
    pidgen: str = Field(
        default="pidgen",
        title="Output PID variable name",
        description="Name of the resampled PID variable in the output tree.",
        examples=["Km_PID_K_pidgen"],
    )
    stat: str = Field(
        default="pidstat",
        title="Statistics variable name",
        description="Name of the PID resampling statistics variable.",
        examples=["Km_PID_K_pidstat"],
    )


class PIDGenResampleRecipe(BaseModel):
    """Recipe for PID resampling using PIDGen2.

    PID resampling adds new branches with resampled PID variables to ROOT files.

    Supports two modes:
    - Single-track: Use ``sample``, ``dataset``, ``variable`` directly.
    - Multi-track: Use ``tracks`` list for multiple particles processed in sequence.

    Kernels can be specified as simple names (``kernels``) or with per-kernel
    seed lists (``kernels_json``) for systematic variations.

    Example (multi-track with kernels_json)::

        recipe:
          name: "pidgen-resample"
          input_tree: "TupleName/DecayTree"
          resampling_seed: 10000
          kernels_json:
            - ["default", [0, 1, 2, 3]]
            - ["syst1", [0]]
            - ["2:2:2:2", [0]]
          tracks:
            - sample: "K_Dstar2Dpi"
              dataset: "2024_WithUT_block5-MagUp-K"
              variable: "PID_K"
              branches: "Km_PT:Km_ETA:nLongTracks"
              pidgen: "Km_PID_K_pidgen"
              stat: "Km_PID_K_pidstat"
            - sample: "pi_Dstar2Dpi"
              dataset: "2024_WithUT_block5-MagUp-Pi"
              variable: "PID_K"
              branches: "pip_PT:pip_ETA:nLongTracks"
              pidgen: "pip_PID_K_pidgen"
              stat: "pip_PID_K_pidstat"
    """

    name: Literal["pidgen-resample"]
    env_version: str = "2026-02-05"
    entrypoint: str = "LbExec.workflows.pidgen2:resample"

    # Single-track fields (optional when tracks is provided)
    sample: str | None = Field(
        default=None,
        title="Calibration sample",
        description=(
            "Name of the calibration sample to use for resampling. "
            "Required in single-track mode, ignored when 'tracks' is provided."
        ),
        examples=["pi_Dstar2Dpi", "K_Dstar2Dpi", "p_Lc2pKpi"],
    )
    dataset: str | None = Field(
        default=None,
        title="Dataset",
        description=(
            "Name of the dataset to use for resampling. "
            "Required in single-track mode, ignored when 'tracks' is provided."
        ),
        examples=["MagUp_2016", "MagDown_2017", "MagUp_2018"],
    )
    variable: str | None = Field(
        default=None,
        title="Variable to resample",
        description=(
            "Name of the variable to resample. "
            "Required in single-track mode, ignored when 'tracks' is provided."
        ),
        examples=["MC15TuneV1_ProbNNpi", "MC15TuneV1_ProbNNk", "MC15TuneV1_ProbNNp"],
    )
    branches: str = Field(
        default="pt:eta:ntr",
        title="Input branches",
        description=(
            "List of branches (two or three) used for resampling, divided by colon. "
            "Typically pT, pseudorapidity eta, and number of tracks ntr. "
            "For samples with '_PrEta' suffix, use 'pt:eta' (2 variables). "
            "If eta_from_p is True, use 'pt:p:ntr' or 'pt:p'."
        ),
        examples=["pt:eta:ntr", "pt:eta", "pt:p:ntr"],
    )
    pidgen: str = Field(
        default="pidgen",
        title="Output PID variable name",
        description=(
            "Name of the resampled PID variable in the output ROOT tree. "
            "If multiple kernels are provided, a suffix will be appended."
        ),
    )
    stat: str = Field(
        default="pidstat",
        title="Statistics variable name",
        description=(
            "Name of the PID resampling statistics variable in the output ROOT tree. "
            "A suffix is added if multiple kernels are used."
        ),
    )

    # Multi-track mode
    tracks: list[PIDGenTrackConfig] | None = Field(
        default=None,
        title="Track configurations",
        description=(
            "List of per-track configurations for multi-track resampling. "
            "When provided, single-track fields (sample, dataset, variable) are ignored."
        ),
    )

    # Tree discovery
    input_tree: str | None = Field(
        default=None,
        title="Input tree path",
        description=(
            "Specific input tree path. If not set, all DecayTrees are auto-discovered."
        ),
        examples=["TupleName/DecayTree"],
    )

    # Kernel configuration
    kernels: str | list[str] | None = Field(
        default=None,
        title="Smearing kernels",
        description=(
            "Name of the named kernel (e.g. 'default', 'syst1') or definition of custom kernel. "
            "Can be a list of strings for multiple alternative kernels. "
            "Custom kernels are defined as 3-4 numbers separated by colons (e.g. '2:2:4:5')."
        ),
        examples=["default", "syst1", "2:2:4:5", ["default", "syst1"]],
    )
    kernels_json: list[list] | None = Field(
        default=None,
        title="Kernels with seed lists",
        description=(
            "Kernels with per-kernel seed lists for systematic variations. "
            "Each entry is [kernel_spec, [seed_indices]]. "
            "Cannot be used together with 'kernels'."
        ),
        examples=[
            [["default", [0, 1, 2, 3]], ["syst1", [0]], ["2:2:2:2", [0]]],
        ],
    )

    resampling_seed: int = Field(
        default=1000,
        title="Random seed",
        description=(
            "Random seed used to resample PID response. Resampling uses strictly one random "
            "number per particle candidate. If several kernels are given, the PID responses "
            "for the same particle will use the same random number."
        ),
    )
    maxfiles: int = Field(
        default=0,
        title="Maximum calibration files",
        description=(
            "Maximum number of calibration files to read (0 for all). "
            "Note: if this doesn't match the number used to create a cached template, "
            "the template will be recalculated."
        ),
        ge=0,
    )
    usecache: bool = Field(
        default=False,
        title="Use cache",
        description="Use calibration files stored in local cache instead of reading from remote storage.",
    )
    eta_from_p: bool = Field(
        default=False,
        title="Calculate eta from p",
        description=(
            "If True, use momentum p instead of pseudorapidity as input, "
            "and calculate pseudorapidity from pT and p. "
            "branches should be 'pt:p:ntr' or 'pt:p'."
        ),
    )
    nan: int = Field(
        default=-1000,
        title="NaN replacement value",
        description="Integer value to substitute output NaN values (for events with missing calibration data).",
    )
    scale: str | list[float] | None = Field(
        default=None,
        title="Scale factors",
        description=(
            "Scale factors for each input branch (e.g. [1,1,1.15] to scale track multiplicity by 15%). "
            "Can be a string '1,1,1.15' or a list. Number of elements must match input variables."
        ),
        examples=["1,1,1.15", [1.0, 1.0, 1.15]],
    )
    global_storage: str = Field(
        default="root://eoslhcb.cern.ch//eos/lhcb/wg/PID/PIDGen2/templates/",
        title="Global template storage",
        description="Location of the global template storage.",
    )
    parabolic: bool = Field(
        default=False,
        title="Parabolic interpolation",
        description="Use parabolic interpolation for PID resampling.",
    )
    verbose: bool = Field(
        default=False,
        title="Verbose output",
        description="Enable verbose messages during resampling.",
    )

    @model_validator(mode="after")
    def _check_track_mode(self) -> "PIDGenResampleRecipe":
        has_tracks = self.tracks is not None
        has_single = any(
            f is not None for f in (self.sample, self.dataset, self.variable)
        )
        if has_tracks and has_single:
            raise ValueError(
                "Cannot specify both 'tracks' and single-track fields (sample, dataset, variable). "
                "Use either 'tracks' for multi-track mode or individual fields for single-track mode."
            )
        if not has_tracks and not all(
            f is not None for f in (self.sample, self.dataset, self.variable)
        ):
            raise ValueError(
                "Either 'tracks' or all of 'sample', 'dataset', 'variable' must be provided."
            )
        if self.kernels is not None and self.kernels_json is not None:
            raise ValueError("Cannot specify both 'kernels' and 'kernels_json'.")
        return self


class MCReweightTreeConfig(BaseModel):
    """Per-tree reweighting configuration.

    Overrides recipe-level defaults for a specific tree pattern.
    Any field not specified falls back to the recipe-level value.
    """

    vars: list[str] | None = Field(
        default=None,
        title="Reweighting variables",
        description="List of branch names used for reweighting. Overrides recipe-level vars.",
    )
    training_vars: list[str] | None = Field(
        default=None,
        title="Training variables",
        description="List of variable names used during training. Overrides recipe-level training_vars.",
    )
    mcweights_name: str | None = Field(
        default=None,
        title="MC weights branch",
        description="Name of existing MC weights branch (None for uniform weights).",
    )
    method: Literal["gbreweighter", "kfolding", "binning"] | None = Field(
        default=None,
        title="Reweighting method",
        description="Overrides recipe-level method for this tree pattern.",
    )
    training_sample: str | None = Field(
        default=None,
        title="Training sample",
        description="Overrides recipe-level training_sample for this tree pattern.",
    )
    weights_name: str | None = Field(
        default=None,
        title="Output weights branch",
        description="Overrides recipe-level weights_name for this tree pattern.",
    )
    output_tree: str | None = Field(
        default=None,
        title="Output tree name",
        description="Rename the tree in the output file. If None, preserves input tree name.",
    )


class MCReweightRecipe(BaseModel):
    """Recipe for MC reweighting using trained classifiers.

    Applies multiplicity and kinematic reweighting to MC samples using
    pre-trained models committed with the Analysis Production.

    Per-tree configuration is supported via ``trees``, a mapping of
    tree regex patterns to per-tree overrides. Example::

        recipe:
          name: "mc-reweight"
          training_sample: "bd_jpsikst_ee"
          method: "gbreweighter"
          vars: ["B_DTF_Jpsi_P", "B_DTF_Jpsi_PT", "nLongTracks", "nPVs"]
          training_vars: ["B_DTF_Jpsi_P", "B_DTF_Jpsi_PT", "nLongTracks", "nPVs"]
          trees:
            ".*Bs2JpsiPhi/DecayTree":
              training_sample: "bs_jpsiphi"
              vars: ["B_PT", "B_P", "nLongTracks"]
              training_vars: ["B_PT", "B_P", "nLongTracks"]
            ".*Bd2JpsiKst/DecayTree":
              method: "kfolding"
    """

    name: Literal["mc-reweight"]
    env_version: str = "2026-02-05"
    entrypoint: str = "LbExec.workflows.mcreweight:mcreweight"

    # All analysis-specific fields are required (no unsafe defaults)
    training_sample: str = Field(
        title="Training sample",
        description="Name of the training sample whose weights will be applied.",
        examples=["bd_jpsikst_ee", "bs_jpsiphi"],
    )
    application_sample: str = Field(
        title="Application sample",
        description="Sample name for the application of weights (used for output subdirectory).",
        examples=["bd_jpsikst_ee", "bs_jpsiphi"],
    )
    method: Literal["gbreweighter", "kfolding", "binning"] = Field(
        title="Reweighting method",
        description="Which trained classifier to load and apply.",
    )
    vars: list[str] = Field(
        title="Reweighting variables",
        description="List of branch names used for reweighting.",
        examples=[["B_DTF_Jpsi_P", "B_DTF_Jpsi_PT", "nLongTracks", "nPVs"]],
        min_length=1,
    )
    training_vars: list[str] = Field(
        title="Training variables",
        description=(
            "List of variable names used during training. Must have the same length as 'vars'. "
            "If different from 'vars', aliases are created to map training names to branch names."
        ),
        min_length=1,
    )
    weightsdir: str = Field(
        title="Weights directory",
        description="Directory where trained weights are stored, relative to ANALYSIS_PRODUCTIONS_BASE.",
        examples=["MyAnalysisName/weights"],
    )

    # Fields with safe, generic defaults
    mcweights_name: str | None = Field(
        default=None,
        title="MC weights branch",
        description="Name of existing MC weights branch in the input file (None for uniform weights).",
    )
    weights_name: str = Field(
        default="weights",
        title="Output weights branch",
        description="Name of the new weights branch added to the output ROOT file.",
    )
    trees: dict[str, MCReweightTreeConfig] | None = Field(
        default=None,
        title="Per-tree configuration",
        description=(
            "Mapping of tree regex patterns to per-tree overrides. "
            "Keys are regex patterns matched against tree paths (fullmatch). "
            "Unspecified fields fall back to the recipe-level values. "
            "When provided, all discovered trees must match at least one pattern."
        ),
    )
    verbose: bool = Field(
        default=False,
        title="Verbose output",
        description="Enable verbose messages during reweighting.",
    )

    @model_validator(mode="after")
    def _check_vars_lengths(self) -> "MCReweightRecipe":
        if len(self.vars) != len(self.training_vars):
            raise ValueError(
                f"'vars' ({len(self.vars)} items) and 'training_vars' "
                f"({len(self.training_vars)} items) must have the same length"
            )
        if self.trees is not None:
            if not self.trees:
                raise ValueError(
                    "'trees' must not be an empty dict (omit it or provide patterns)"
                )
            for pattern, cfg in self.trees.items():
                if cfg.vars is not None and cfg.training_vars is not None:
                    if len(cfg.vars) != len(cfg.training_vars):
                        raise ValueError(
                            f"In tree pattern '{pattern}': 'vars' ({len(cfg.vars)} items) and "
                            f"'training_vars' ({len(cfg.training_vars)} items) must have the same length"
                        )
        return self


class ExpandBKPath(BaseModel):
    """Recipe to expand BK path elements into multiple jobs.

    Use format strings in the path to mark where substitutions should go.

    Example::

        recipe:
          name: "expand"
          path: "/LHCb/Collision24/Beam6800GeV-VeloClosed-{polarity}/Real Data/Sprucing{sprucing}/{stream}/CHARM.DST"
          substitute:
            polarity: ["MagUp", "MagDown"]
            sprucing: ["24c3", "24c2"]
            stream: "94000000"

    This generates 4 jobs with different BK paths.
    """

    name: Literal["expand"]

    path: str = Field(
        title="BK path",
        description="The BK path to expand.",
        examples=[
            "/LHCb/Collision24/Beam6800GeV-VeloClosed-{polarity}/Real Data/Sprucing{sprucing}/{stream}/CHARM.DST"
        ],
    )
    substitute: dict[str, list[str] | str]


AllRecipes = (
    SplittingRecipe
    | FilteringRecipe
    | PIDGenResampleRecipe
    | MCReweightRecipe
    | ExpandBKPath
)
