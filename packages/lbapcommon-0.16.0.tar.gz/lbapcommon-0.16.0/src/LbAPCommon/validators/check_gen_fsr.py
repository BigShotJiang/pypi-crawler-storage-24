###############################################################################
# (c) Copyright 2026 CERN for the benefit of the LHCb Collaboration           #
#                                                                             #
# This software is distributed under the terms of the GNU General Public      #
# Licence version 3 (GPL Version 3), copied verbatim in the file "COPYING".   #
#                                                                             #
# In applying this licence, CERN does not waive the privileges and immunities #
# granted to it by virtue of its status as an Intergovernmental Organization  #
# or submit itself to any jurisdiction.                                       #
###############################################################################
import json
import sys

import uproot


def check_streamers(root_file):
    """
    Yield the names of all streamers found in branches of the ROOT file.

    Args:
        root_file: An uproot file object

    Yields:
        str: Streamer names
    """
    for key in root_file.keys():
        obj = root_file[key]
        if hasattr(obj, "branches"):
            for branch in obj.branches:
                if branch.streamer:
                    yield branch.streamer.name


def _check_for_fsr_recursive(node):
    """
    Recursively search for 'genfsr' in the node tree.

    Args:
        node: A dictionary representing a node in the tree

    Returns:
        bool: True if 'genfsr' is found anywhere in the tree
    """
    if "genfsr" in node:
        return True
    return any(_check_for_fsr_recursive(child) for child in node.get("inputs", []))


def check_fsr(root_file):
    """
    Check if the ROOT file contains File Summary Record (FSR) information.

    Checks for either:
    - JSON blob: FileSummaryRecord with 'genfsr' in the tree
    - Legacy: LHCb::GenFSR streamer

    Args:
        root_file: An uproot file object

    Returns:
        tuple: (has_fsr: bool, fsr_type: dict or str or None)
            - has_fsr: True if FSR information is present
            - fsr_type: dict with {"type": "json_blob", "version": <version>} for JSON blob,
                       "legacy" for LHCb::GenFSR streamer, or None if not found
    """
    # JSON blob case: Check FileSummaryRecord for genfsr
    if "FileSummaryRecord" in root_file:
        fsr_data = json.loads(root_file["FileSummaryRecord"])
        if _check_for_fsr_recursive(fsr_data):
            # Extract version information if available
            version = fsr_data.get("version", "unknown")
            return True, {"type": "json_blob", "version": version}

    # Legacy case: Look for LHCb::GenFSR streamer
    if "LHCb::GenFSR" in check_streamers(root_file):
        return True, "legacy"

    return False, None


def main():
    """
    CLI entry point for checking GenFSR in ROOT files.

    Outputs JSON to stdout with the following format:
    {
        "has_genfsr": bool,
        "genfsr_type": {
            "type": "json_blob",
            "version": <version>
        } | "streamer" | null
    }

    Usage:
        lhcb-check-genfsr <root_file_path>

    Exit codes:
        0: Success
        1: Error (file not found, invalid ROOT file, etc.)
    """
    if len(sys.argv) != 2:
        result = {
            "error": "Usage: lhcb-check-genfsr <root_file_path>",
            "has_genfsr": False,
            "genfsr_type": None,
        }
        print(json.dumps(result, indent=2))
        sys.exit(1)

    file_path = sys.argv[1]

    try:
        with uproot.open(file_path) as root_file:
            has_fsr, fsr_type = check_fsr(root_file)
            result = {"has_genfsr": has_fsr, "genfsr_type": fsr_type}
            print(json.dumps(result, indent=2))
            sys.exit(0)
    except FileNotFoundError:
        result = {
            "error": f"File not found: {file_path}",
            "has_genfsr": False,
            "genfsr_type": None,
        }
        print(json.dumps(result, indent=2))
        sys.exit(1)
    except Exception as e:
        result = {
            "error": f"Error reading ROOT file: {str(e)}",
            "has_genfsr": False,
            "genfsr_type": None,
        }
        print(json.dumps(result, indent=2))
        sys.exit(1)


if __name__ == "__main__":
    main()
