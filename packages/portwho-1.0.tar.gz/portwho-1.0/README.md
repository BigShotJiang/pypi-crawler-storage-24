# portwho

Small CLI utility to find which process is using a port and optionally stop it.

## What it does

`portwho` helps you:

- inspect a TCP or UDP port
- see which process is bound to that port
- view basic process information
- optionally terminate that process
- optionally force kill it if graceful termination does not work

This is useful when a local server fails to start because a port is already occupied.

## Features

- supports TCP and UDP
- shows PID, process name, executable path, command line, and status
- groups listeners by process
- can terminate processes on the target port
- supports graceful stop with optional force kill fallback
- simple terminal output

## Installation

Clone the repository and install it in a virtual environment.

```bash
git clone <your-repo-url>
cd portwho
pip install -e .
```

## Requirements

- Python 3.10+
- `psutil`

## Usage

Basic form:

```bash
portwho <port>
```

Examples:

```bash
portwho 8000
portwho 8000 --protocol tcp
portwho 53 --protocol udp
portwho 8000 --kill
portwho 8000 --force
```

## Command line arguments

### `port`

Target port number.

Example:

```bash
portwho 8000
```

### `--protocol {tcp,udp}`

Choose which protocol to inspect.

Default:

```text
tcp
```

Examples:

```bash
portwho 8000 --protocol tcp
portwho 53 --protocol udp
```

### `--kill`

Try to stop processes using the port.

Example:

```bash
portwho 8000 --kill
```

### `--force`

If normal termination times out, force kill the process.

Example:

```bash
portwho 8000 --force
```

## Notes

- process termination may fail due to insufficient permissions
- some system or protected processes may not expose full metadata

## License

MIT License.