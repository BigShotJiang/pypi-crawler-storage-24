from dataclasses import dataclass
from typing import Literal


@dataclass(frozen=True)
class Arguments:
    port: int
    kill: bool
    force: bool
    protocol: Literal["tcp", "udp"] | None


@dataclass
class Listener:
    host: str
    port: int
    pid: int
    family: Literal[4, 6]
    protocol: Literal["tcp", "udp"]


Listeners = dict[int, list[Listener]]


@dataclass
class ProcessInfo:
    pid: int
    name: str | None
    cmdline: str | None
    exe: str | None
    cwd: str | None
