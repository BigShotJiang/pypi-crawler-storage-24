import socket
from collections import defaultdict
from collections.abc import Callable
from typing import Literal, TypeVar

import psutil

from portwho import models


def find_listeners(port: int, protocol: Literal["tcp", "udp"] | None = None) -> models.Listeners:
    listeners: dict[int, list[models.Listener]] = defaultdict(list)
    for connection in psutil.net_connections(kind="inet"):
        if connection.status not in (psutil.CONN_LISTEN, psutil.CONN_NONE):
            continue
        if not connection.laddr or connection.pid is None or connection.laddr.port != port:
            continue

        connection_protocol = "tcp" if connection.type == socket.SOCK_STREAM else "udp"
        if protocol and connection_protocol != protocol:
            continue

        listeners[connection.pid].append(
            models.Listener(
                host=connection.laddr.ip,
                port=connection.laddr.port,
                pid=connection.pid,
                family=6 if connection.family == socket.AF_INET6 else 4,
                protocol=connection_protocol,
            )
        )

    return listeners


def get_process_info(pid: int) -> models.ProcessInfo | None:
    R = TypeVar("R")

    def safe(getter: Callable[[], R]) -> R | None:
        try:
            return getter()
        except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
            return None

    try:
        process = psutil.Process(pid)
    except (psutil.NoSuchProcess, psutil.AccessDenied):
        return None

    cmdline = safe(process.cmdline)
    return models.ProcessInfo(
        pid=pid,
        name=safe(process.name),
        cmdline=" ".join(cmdline) if cmdline else None,
        exe=safe(process.exe),
        cwd=safe(process.cwd),
    )


def stop_process(pid: int, /, *, force: bool = False) -> bool:
    try:
        process = psutil.Process(pid)
        process.terminate()

        try:
            _ = process.wait(timeout=3)
            return True
        except psutil.TimeoutExpired:
            if not force:
                return False

        process.kill()
        _ = process.wait(timeout=3)
        return True

    except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.TimeoutExpired):
        return False
