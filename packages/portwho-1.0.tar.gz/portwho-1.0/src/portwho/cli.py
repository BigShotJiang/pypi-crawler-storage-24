import argparse

from portwho import backend, models


def parse_args() -> models.Arguments:
    parser = argparse.ArgumentParser(description="Look what takes your port")
    _ = parser.add_argument("port", type=int, help="port number")
    _ = parser.add_argument("-k", "--kill", action="store_true", help="kill process using this port")
    _ = parser.add_argument("-f", "--force", action="store_true", help="force kill (implies --kill)")
    _ = parser.add_argument("--protocol", choices=["tcp", "udp"], default=None, help="filter by protocol")

    args = parser.parse_args()
    return models.Arguments(port=args.port, kill=args.kill, force=args.force, protocol=args.protocol)


ACCESS_DENIED_TEXT = "<access denied>"


def generate_report(args: models.Arguments) -> tuple[list[str], models.Listeners]:
    listeners = backend.find_listeners(args.port, args.protocol)
    report: list[str] = []

    if not listeners:
        report.append("No processes found bound to this port")
        return report, listeners

    report.append("Listeners:")
    for pid in listeners:
        process_info = backend.get_process_info(pid)
        if process_info is None:
            report.append("A process is listening on this port, but details are restricted.")
            report.append("Try running with elevated privileges")
        else:
            report.extend(
                [
                    f"  PID:      {pid}",
                    f"  Name:     {process_info.name or ACCESS_DENIED_TEXT}",
                    f"  Command:  {process_info.cmdline or ACCESS_DENIED_TEXT}",
                    f"  Exe:      {process_info.exe or ACCESS_DENIED_TEXT}",
                    f"  CWD:      {process_info.cwd or ACCESS_DENIED_TEXT}",
                    "  Binds:",
                ]
            )
        for listener in listeners[pid]:
            address = f"{'[' if listener.family == 6 else ''}{listener.host}{']' if listener.family == 6 else ''}:{listener.port}"
            report.append(f"    {listener.protocol}V{listener.family} - {address}")
    return report, listeners


def kill_port_processes(listeners: models.Listeners, args: models.Arguments) -> list[str]:
    pids = listeners.keys()
    report: list[str] = []
    if not pids:
        report.append("Nothing to kill")
        return report

    if not args.kill and not args.force:
        report.append("To stop:")
        if args.protocol:
            report.append(f"  run portwho {args.port} --protocol {args.protocol} --kill")
        else:
            report.append(f"  run portwho {args.port} --kill")
        return report

    if args.protocol is None:
        report.append(f"Trying to free port {args.port}:")
    else:
        report.append(f"Trying to free port {args.port} ({args.protocol.upper()}):")

    for pid in pids:
        success = backend.stop_process(pid, force=args.force)
        report.append(f"  {pid} - {'success' if success else 'fail'}")
    return report
