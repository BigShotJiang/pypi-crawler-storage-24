from portwho import cli


def main() -> None:
    args = cli.parse_args()
    report, listeners = cli.generate_report(args)
    report = "\n".join(report)
    print(report)
    print()
    report = cli.kill_port_processes(listeners, args)
    report = "\n".join(report)
    print(report)
