# Release-Prozess

## Vor dem Tag

1. **Changelog finalisieren**: `[Unreleased]` in `CHANGELOG.md` prüfen, umbenennen zu `[X.Y.Z] - YYYY-MM-DD`,
   neuen leeren `[Unreleased]`-Abschnitt darüber anlegen.
2. **Version bumpen** (3 Stellen):
   - `pyproject.toml` → `version = "X.Y.Z"`
   - `src/brinkhaustools/__init__.py` → `__version__ = "X.Y.Z"`
   - `docs/index.md` → Project Status
3. **Commit**: `git commit -m "Release X.Y.Z vorbereiten"`
4. **Tests**: `pytest tests/ -v --timeout=30`

## Tag erstellen und pushen

```bash
git tag X.Y.Z
git push origin master X.Y.Z
```

## Was passiert automatisch (CI)

| Stage | Job | Beschreibung |
|-------|-----|-------------|
| test | test | pytest + JUnit XML |
| test | typecheck | mypy (allow_failure) |
| build | build | Wheel bauen |
| publish | publish | Upload zu PyPI |
| pages | pages | MkDocs → GitLab Pages (nur master) |

## Changelog-Format

[Keep a Changelog](https://keepachangelog.com/de/1.1.0/) mit Kategorien:
Hinzugefügt, Geändert, Veraltet, Entfernt, Behoben, Sicherheit.
