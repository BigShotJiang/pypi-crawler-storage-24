"""The package root."""

import os

from fuse_augmentations.__about__ import *  # noqa: F403

_PATH_PACKAGE = os.path.realpath(os.path.dirname(__file__))
_PATH_PROJECT = os.path.dirname(_PATH_PACKAGE)
