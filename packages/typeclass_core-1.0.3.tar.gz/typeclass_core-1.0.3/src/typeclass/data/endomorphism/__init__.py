from .core import Endomorphism
