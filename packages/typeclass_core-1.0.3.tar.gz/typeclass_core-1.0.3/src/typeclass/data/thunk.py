from __future__ import annotations
from typing import Callable, Generic, TypeVar

from typeclass.typeclasses.force import Force

T = TypeVar("T")

class Thunk(Force[T], Generic[T]):
    def __init__(self, thunk: Callable[[], T]):
        self._thunk = thunk
        self._evaluated = False
        self._value: T | None = None

    def force(self) -> T:
        if not self._evaluated:
            self._value = self._thunk()
            self._evaluated = True
        return self._value

    def __repr__(self):
        return f"Thunk({self._value!r})" if self._evaluated else "Thunk(<unevaluated>)"


def delay(value: T) -> Thunk[T]:
    return Thunk(lambda: value)


def suspend(fn, *args, **kwargs):
    return Thunk(lambda: fn(*args, **kwargs))

def resume(fn, *args, **kwargs):
    return Thunk(lambda: fn(*args, **kwargs).force())
