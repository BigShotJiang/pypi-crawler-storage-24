from .core import Morphism
