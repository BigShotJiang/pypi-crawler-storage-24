"""Compatibility shim for the former utils module.

.. deprecated::
    Import directly from :mod:`voyant_api.pandas_utils` instead::

        from voyant_api.pandas_utils import frame_to_dataframe
"""

import warnings

warnings.warn(
    "voyant_api.utils is deprecated and will be removed in a future release. "
    "Import from voyant_api.pandas_utils instead.",
    DeprecationWarning,
    stacklevel=2,
)

from .pandas_utils import (  # noqa: F401, E402
    frame_to_xyz_dataframe,
    frame_to_xyzv_dataframe,
    frame_to_spherical_dataframe,
    frame_to_spherical_v_dataframe,
    frame_to_dataframe,
    frame_to_extended_dataframe,
    frame_to_special_test_dataframe,
)
