"""Utilities for converting VoyantFrame data to PCD (Point Cloud Data) format."""

import numpy as np
from pypcd4 import PointCloud

from .voyant_api import VoyantFrame


def frame_to_xyz_pcd(frame: VoyantFrame, valid_only: bool = False) -> PointCloud:
    """Convert VoyantFrame XYZ data to a pypcd4 PointCloud.

    Args:
        frame: VoyantFrame instance
        valid_only: If True, only include valid points

    Returns:
        pypcd4 PointCloud with x, y, z fields
    """
    if valid_only:
        data = frame.valid_xyz()
    else:
        data = frame.xyz()

    fields = tuple(frame.xyz_columns())
    types = (np.float32,) * len(fields)
    return PointCloud.from_points(data, fields, types)


def frame_to_xyzv_pcd(frame: VoyantFrame, valid_only: bool = False) -> PointCloud:
    """Convert VoyantFrame XYZV data to a pypcd4 PointCloud.

    Args:
        frame: VoyantFrame instance
        valid_only: If True, only include valid points

    Returns:
        pypcd4 PointCloud with x, y, z, radial_vel fields
    """
    if valid_only:
        data = frame.valid_xyzv()
    else:
        data = frame.xyzv()

    fields = tuple(frame.xyzv_columns())
    types = (np.float32,) * len(fields)
    return PointCloud.from_points(data, fields, types)


def frame_to_spherical_pcd(
    frame: VoyantFrame, valid_only: bool = False, degrees: bool = False
) -> PointCloud:
    """Convert VoyantFrame spherical data to a pypcd4 PointCloud.

    Args:
        frame: VoyantFrame instance
        valid_only: If True, only include valid points
        degrees: If True, angles in degrees; if False, angles in radians

    Returns:
        pypcd4 PointCloud with range, azimuth, elevation fields
    """
    if valid_only:
        data = frame.valid_spherical(degrees=degrees)
    else:
        data = frame.spherical(degrees=degrees)

    fields = tuple(frame.spherical_columns())
    types = (np.float32,) * len(fields)
    return PointCloud.from_points(data, fields, types)


def frame_to_spherical_v_pcd(
    frame: VoyantFrame, valid_only: bool = False, degrees: bool = False
) -> PointCloud:
    """Convert VoyantFrame spherical + velocity data to a pypcd4 PointCloud.

    Args:
        frame: VoyantFrame instance
        valid_only: If True, only include valid points
        degrees: If True, angles in degrees; if False, angles in radians

    Returns:
        pypcd4 PointCloud with range, azimuth, elevation, radial_vel fields
    """
    if valid_only:
        data = frame.valid_spherical_v(degrees=degrees)
    else:
        data = frame.spherical_v(degrees=degrees)

    fields = tuple(frame.spherical_v_columns())
    types = (np.float32,) * len(fields)
    return PointCloud.from_points(data, fields, types)


def frame_to_pcd(frame: VoyantFrame, valid_only: bool = False) -> PointCloud:
    """Convert VoyantFrame to a pypcd4 PointCloud.

    Args:
        frame: VoyantFrame instance
        valid_only: If True, only include valid points

    Returns:
        pypcd4 PointCloud with x, y, z, radial_vel, snr_linear,
        nanosecs_since_frame, drop_reason fields
    """
    if valid_only:
        data = frame.valid_points()
    else:
        data = frame.points()

    fields = tuple(frame.points_columns())
    types = (np.float32,) * len(fields)
    return PointCloud.from_points(data, fields, types)


def frame_to_extended_pcd(frame: VoyantFrame, valid_only: bool = False) -> PointCloud:
    """Convert VoyantFrame extended data to a pypcd4 PointCloud.

    Args:
        frame: VoyantFrame instance
        valid_only: If True, only include valid points

    Returns:
        pypcd4 PointCloud with all extended point data fields
    """
    if valid_only:
        data = frame.valid_points_extended()
    else:
        data = frame.points_extended()

    fields = tuple(frame.points_extended_columns())
    types = (np.float32,) * len(fields)
    return PointCloud.from_points(data, fields, types)


def frame_to_special_test_pcd(
    frame: VoyantFrame, valid_only: bool = False
) -> PointCloud:
    """Convert VoyantFrame special test data to a pypcd4 PointCloud.

    Args:
        frame: VoyantFrame instance
        valid_only: If True, only include valid points

    Returns:
        pypcd4 PointCloud with special test fields (for internal systems test usage)
    """
    if valid_only:
        data = frame.valid_special_test()
    else:
        data = frame.special_test()

    fields = tuple(frame.special_test_columns())
    types = (np.float32,) * len(fields)
    return PointCloud.from_points(data, fields, types)


def save_frame_to_pcd(
    frame: VoyantFrame,
    path: str,
    valid_only: bool = False,
    extended: bool = False,
) -> None:
    """Save a VoyantFrame to a .pcd file.

    By default writes the standard 7-field format:
    x, y, z, radial_vel, snr_linear, nanosecs_since_frame, drop_reason.
    Pass extended=True to include all 11 fields (adds calibrated_reflectance,
    noise_mean_estimate, min_ramp_snr, point_index).

    Args:
        frame: VoyantFrame instance
        path: Output file path (should end in .pcd)
        valid_only: If True, only include valid points
        extended: If True, write all extended fields (default: False)
    """
    if extended:
        pc = frame_to_extended_pcd(frame, valid_only=valid_only)
    else:
        pc = frame_to_pcd(frame, valid_only=valid_only)

    pc.save(path)
