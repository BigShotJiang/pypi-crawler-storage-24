# rho-tts Launch Plan

## Pre-posting checklist

- [X] **Screenshots in README** — Add 2-3 Gradio UI screenshots (Generate tab, Voices tab, Training tab). Embed them at the top of the README after the description, before "Installation."
- [X] **Fix version mismatch** — `__init__.py` says 1.0.4, `pyproject.toml` says 1.0.5.
- [X] **Remove "(once published)" comment** on README line 229.
- [X] **Publish to PyPI** — `pip install rho-tts` should work before you tell people to run it. Build with `python -m build` and upload with `twine upload dist/*`.

---

## 1. r/LocalLLaMA

**Format:** Link post to GitHub repo with a text body.

**Title:** `rho-tts: Multi-provider TTS library with voice cloning, accent drift detection, and auto-sort (Qwen3-TTS + Chatterbox)`

**Post body:**

```
What it does:
- Swap between Qwen3-TTS and Chatterbox with one parameter
- Voice cloning from a short reference clip
- ML classifier detects when your model's accent drifts and auto-sorts bad generations
- Whisper-based validation ensures the model said what you asked
- Gradio web UI for interactive use

Why I built it:
I was using voice cloning for audiobook generation and kept running into the same problem, accent drift and garbled output on random segments. I'd generate 
a batch, manually listen through to find the bad ones, regenerate, and repeat. So I built a validation loop that auto detects drift and bad transcriptions and 
regenerates failed segments automatically. Then I added a classifier you can retrain on your own good/bad samples so it gets better over time for each voice. I
also wanted something model agnostic since new TTS models keep dropping.

Install: pip install rho-tts[all]
GitHub: https://github.com/rhofield/rho-tts

[screenshots inline]
```

**Timing:** Weekday morning US time (9-11am ET). Avoid weekends.

**Engagement:** Reply to every comment in the first 2 hours. Answer questions about VRAM usage, generation speed, and quality comparisons — these are the three things LocalLLaMA always asks.

---

## 2. r/MachineLearning

**Format:** Use the `[P]` (Project) tag in the title.

**Title:** `[P] rho-tts: TTS library with ML-based accent drift detection and automatic quality sorting`

**Key difference from LocalLLaMA:** This audience cares about *techniques*, not just "I can run it locally." Lead with the accent drift classifier and validation pipeline.

**Post body:**

```
Built a TTS library that wraps multiple providers (Qwen3-TTS, Chatterbox) and adds
a validation pipeline on top:

1. Accent drift detection — trained a classifier on good/bad audio samples that
   predicts drift probability. Generations exceeding the threshold are auto-regenerated
   or sorted into reject bins.

2. STT validation — Whisper transcribes output and fuzzy matches against input text
   (with number normalization) to catch hallucinated or dropped words.

3. Speaker similarity — cosine similarity on speaker embeddings (resemblyzer) to
   verify voice consistency across a batch.

The library handles subprocess isolation for providers with conflicting deps
(different torch versions etc.) via JSON line IPC, so you can run multiple
providers in one process without dependency hell.

GitHub: https://github.com/rhofield/rho-tts
```

**Timing:** Any weekday. Posts take 6-12 hours to gain traction (moderated sub).

---

## 3. Hugging Face

### A) Create a HF Space

- Create a new Space at huggingface.co/spaces with the Gradio SDK
- Point it at your repo since you already use Gradio
- Add an `app.py` at the root that calls `launch_ui()` with `share=False`
- Add a `requirements.txt` targeting `rho-tts[ui,qwen]`
- Pick a free GPU tier (T4 should work for Qwen 0.6B)
- This gives people a live demo they can try without installing anything

### B) Post on HF community

- Go to huggingface.co/posts and create a post linking to your Space
- Title: something like "rho-tts — TTS library with accent drift detection and multi-provider support"
- Include a link to the Space so people can try it immediately
- Tag it with `tts`, `voice-cloning`, `qwen`, `gradio`

The Space is the main draw here. HF users expect to click and try, not clone and install.

---

## 4. Hacker News (Show HN)

**Format:** "Show HN" post. Title links directly to GitHub.

**Title:** `Show HN: Rho-TTS – Multi-provider TTS with accent drift detection and voice cloning`

(HN titles are max ~80 chars. Keep it factual, no hype.)

**First comment** (post immediately after submitting — HN convention for Show HN):

```
I built this because I was generating audiobooks with local TTS models and kept getting
batches where the accent would drift mid generation. Sorting through hundreds of
clips manually was painful, so I trained a classifier to detect drift and auto-sort.

Interesting technical bits:
- Providers run in subprocess isolation with JSON-line IPC so conflicting torch
  versions don't collide
- The accent drift classifier is a lightweight sklearn model trained on
  resemblyzer speaker embeddings
- Validation pipeline chains drift detection → Whisper STT matching → speaker
  similarity scoring

Would love feedback on the API design and whether the isolation approach
(venv per provider via subprocess) is something others have needed.
```

**What HN cares about:** Engineering decisions, not features. The subprocess isolation layer and the validation pipeline architecture are your hooks. The "why I built it" story matters more here than anywhere else.

**Timing:** 8-10am ET on a Tuesday or Wednesday.

**Engagement:** HN comments tend to be critical. Don't be defensive. Answer technical questions directly. If someone asks "why not just use X," give an honest answer about what X doesn't do.
