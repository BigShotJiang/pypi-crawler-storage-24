from enum import Enum
from pathlib import Path
from typing import TYPE_CHECKING, Callable, List, Optional

from trilogy.core.models.environment import Environment

if TYPE_CHECKING:
    from trilogy import Executor
    from trilogy.hooks.base_hook import BaseHook

from trilogy.constants import Rendering, logger
from trilogy.dialect.config import DialectConfig, DuckDBConfig


def default_factory(conf: DialectConfig, config_type):
    from sqlalchemy import create_engine
    from sqlalchemy.pool import NullPool

    engine_args = {
        "poolclass": NullPool,
    }
    # the DuckDB IdentifierPreparer uses a global connection that is not thread safe
    if isinstance(conf, DuckDBConfig):
        # we monkey patch to parent to avoid this
        from duckdb_engine import DuckDBIdentifierPreparer, PGIdentifierPreparer

        DuckDBIdentifierPreparer.__init__ = PGIdentifierPreparer.__init__  # type: ignore

    if not isinstance(conf, config_type):
        raise TypeError(
            f"Invalid dialect configuration for type {type(config_type).__name__}, is {type(conf)}"
        )
    connect_args = conf.create_connect_args()
    if connect_args:
        engine_args["connect_args"] = connect_args
    return create_engine(conf.connection_string(), **engine_args)


class Dialects(Enum):
    BIGQUERY = "bigquery"
    SQL_SERVER = "sql_server"
    DUCK_DB = "duck_db"
    SQLITE = "sqlite"
    PRESTO = "presto"
    TRINO = "trino"
    POSTGRES = "postgres"
    SNOWFLAKE = "snowflake"
    DATAFRAME = "dataframe"

    @classmethod
    def _missing_(cls, value):
        if value == "duckdb":
            return cls.DUCK_DB
        if value == "sqlite3" or value == "sqllite":
            return cls.SQLITE
        return super()._missing_(value)

    def default_renderer(self, conf=None, _engine_factory: Callable = default_factory):
        from trilogy.render import get_dialect_generator

        return get_dialect_generator(self)

    def default_engine(self, conf=None, _engine_factory: Callable = default_factory):
        if self == Dialects.BIGQUERY:
            from google.auth import default
            from google.cloud import bigquery

            from trilogy.dialect.config import BigQueryConfig

            credentials, project = default()
            client = bigquery.Client(credentials=credentials, project=project)
            conf = conf or BigQueryConfig(project=project, client=client)
            return _engine_factory(
                conf,
                BigQueryConfig,
            )
        elif self == Dialects.SQL_SERVER:
            raise NotImplementedError()
        elif self == Dialects.DUCK_DB:
            from trilogy.dialect.config import DuckDBConfig

            if not conf:
                conf = DuckDBConfig()
            return _engine_factory(conf, DuckDBConfig)
        elif self == Dialects.SQLITE:
            from trilogy.dialect.config import SQLiteConfig

            if not conf:
                conf = SQLiteConfig()
            return _engine_factory(conf, SQLiteConfig)
        elif self == Dialects.SNOWFLAKE:
            from trilogy.dialect.config import SnowflakeConfig

            if not conf:
                raise ValueError(
                    "SnowflakeConfig must be provided for Snowflake dialect"
                )
            return _engine_factory(conf, SnowflakeConfig)
        elif self == Dialects.POSTGRES:
            logger.warn(
                "WARN: Using experimental postgres dialect. Most functionality will not work."
            )
            import importlib

            spec = importlib.util.find_spec("psycopg2")
            if spec is None:
                raise ImportError(
                    "postgres driver not installed. python -m pip install pypreql[postgres]"
                )
            from trilogy.dialect.config import PostgresConfig

            return _engine_factory(conf, PostgresConfig)
        elif self == Dialects.PRESTO:
            from trilogy.dialect.config import PrestoConfig

            if not conf:
                raise ValueError("Presto Config must be provided for Presto dialect")
            return _engine_factory(conf, PrestoConfig)
        elif self == Dialects.TRINO:
            from trilogy.dialect.config import TrinoConfig

            if not conf:
                raise ValueError("Trino Config must be provided for Trino dialect")
            return _engine_factory(conf, TrinoConfig)
        elif self == Dialects.DATAFRAME:
            from trilogy.dialect.config import DataFrameConfig
            from trilogy.dialect.dataframe import DataframeConnectionWrapper

            if not conf:
                conf = DataFrameConfig(dataframes={})

            base = _engine_factory(conf, DataFrameConfig)

            return DataframeConnectionWrapper(base, dataframes=conf.dataframes)
        else:
            raise ValueError(
                f"Unsupported dialect {self} for default engine creation; create one explicitly."
            )

    def default_executor(
        self,
        environment: Optional["Environment"] = None,
        working_path: Optional[Path] = None,
        hooks: List["BaseHook"] | None = None,
        conf: DialectConfig | None = None,
        rendering: Rendering | None = None,
        _engine_factory: Callable | None = None,
    ) -> "Executor":
        from trilogy import Executor

        environment = environment or Environment()
        if working_path:
            environment.working_path = working_path
        if _engine_factory is not None:
            return Executor(
                engine=self.default_engine(conf=conf, _engine_factory=_engine_factory),
                environment=environment,
                dialect=self,
                rendering=rendering,
                hooks=hooks,
                config=conf,
            )

        return Executor(
            engine=self.default_engine(conf=conf),
            environment=environment,
            dialect=self,
            rendering=rendering,
            hooks=hooks,
            config=conf,
        )
