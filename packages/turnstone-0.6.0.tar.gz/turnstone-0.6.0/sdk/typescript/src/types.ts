// ---------------------------------------------------------------------------
// Shared types
// ---------------------------------------------------------------------------

export interface ErrorResponse {
  error: string;
}

export interface StatusResponse {
  status: string;
}

export interface AuthLoginRequest {
  token: string;
}

export interface AuthLoginResponse {
  status: string;
  role: string;
  scopes?: string;
  jwt?: string;
  user_id?: string;
}

export interface AuthStatusResponse {
  auth_enabled: boolean;
  has_users: boolean;
  setup_required: boolean;
}

export interface AuthSetupResponse {
  status: string;
  user_id: string;
  username: string;
  role: string;
  scopes: string;
  jwt?: string;
}

// ---------------------------------------------------------------------------
// Server API — Workstream management
// ---------------------------------------------------------------------------

export interface SendRequest {
  message: string;
  ws_id: string;
}

export interface SendResponse {
  status: string;
}

export interface ApproveRequest {
  approved: boolean;
  feedback?: string | null;
  always?: boolean;
  ws_id: string;
}

export interface PlanFeedbackRequest {
  feedback: string;
  ws_id: string;
}

export interface CommandRequest {
  command: string;
  ws_id: string;
}

export interface CreateWorkstreamRequest {
  name?: string;
  model?: string;
  auto_approve?: boolean;
  resume_ws?: string;
  template?: string;
  ws_template?: string;
}

export interface CreateWorkstreamResponse {
  ws_id: string;
  name: string;
  resumed?: boolean;
  message_count?: number;
}

export interface CloseWorkstreamRequest {
  ws_id: string;
}

export interface WorkstreamInfo {
  id: string;
  name: string;
  state: string;
}

export interface ListWorkstreamsResponse {
  workstreams: WorkstreamInfo[];
}

export interface DashboardWorkstream {
  id: string;
  name: string;
  state: string;
  title?: string;
  tokens?: number;
  context_ratio?: number;
  activity?: string;
  activity_state?: string;
  tool_calls?: number;
  node?: string;
  model?: string;
  model_alias?: string;
}

export interface DashboardAggregate {
  total_tokens: number;
  total_tool_calls: number;
  active_count: number;
  total_count: number;
  uptime_seconds?: number;
  node?: string;
}

export interface DashboardResponse {
  workstreams: DashboardWorkstream[];
  aggregate: DashboardAggregate;
}

// ---------------------------------------------------------------------------
// Server API — Saved workstreams
// ---------------------------------------------------------------------------

export interface SavedWorkstreamInfo {
  ws_id: string;
  alias?: string | null;
  title?: string | null;
  created: string;
  updated: string;
  message_count: number;
}

export interface ListSavedWorkstreamsResponse {
  workstreams: SavedWorkstreamInfo[];
}

// ---------------------------------------------------------------------------
// Server API — Health
// ---------------------------------------------------------------------------

export interface BackendStatus {
  status: string;
  circuit_state: string;
}

export interface WorkstreamCounts {
  total: number;
  idle?: number;
  thinking?: number;
  running?: number;
  attention?: number;
  error?: number;
}

export interface McpStatus {
  servers: number;
  resources: number;
  prompts: number;
}

export interface HealthResponse {
  status: string;
  version?: string;
  uptime_seconds?: number;
  model?: string;
  workstreams?: WorkstreamCounts;
  backend?: BackendStatus | null;
  mcp?: McpStatus | null;
}

// ---------------------------------------------------------------------------
// Console API
// ---------------------------------------------------------------------------

export interface StateCounts {
  running?: number;
  thinking?: number;
  attention?: number;
  idle?: number;
  error?: number;
}

export interface ClusterAggregate {
  total_tokens: number;
  total_tool_calls: number;
}

export interface ClusterOverviewResponse {
  nodes: number;
  workstreams: number;
  states: StateCounts;
  aggregate: ClusterAggregate;
  version_drift: boolean;
  versions: string[];
}

export interface ClusterNodeInfo {
  node_id: string;
  server_url: string;
  ws_total: number;
  ws_running: number;
  ws_thinking: number;
  ws_attention: number;
  ws_idle: number;
  ws_error: number;
  total_tokens: number;
  started: number;
  reachable: boolean;
  health: Record<string, string>;
  version: string;
}

export interface ClusterNodesResponse {
  nodes: ClusterNodeInfo[];
  total: number;
}

export interface ClusterWorkstreamInfo {
  id: string;
  name: string;
  state: string;
  node: string;
  title?: string;
  tokens?: number;
  context_ratio?: number;
  activity?: string;
  activity_state?: string;
  tool_calls?: number;
}

export interface ClusterWorkstreamsResponse {
  workstreams: ClusterWorkstreamInfo[];
  total: number;
  page: number;
  per_page: number;
  pages: number;
}

export interface NodeDetailResponse {
  node_id: string;
  server_url: string;
  health: Record<string, string>;
  workstreams: ClusterWorkstreamInfo[];
  aggregate: ClusterAggregate;
}

export interface ClusterSnapshotNode {
  node_id: string;
  server_url: string;
  max_ws: number;
  reachable: boolean;
  version: string;
  health: Record<string, string>;
  aggregate: Record<string, number>;
  workstreams: ClusterWorkstreamInfo[];
}

export interface ClusterSnapshotResponse {
  nodes: ClusterSnapshotNode[];
  overview: ClusterOverviewResponse;
  timestamp: number;
}

export interface ConsoleCreateWsRequest {
  node_id?: string;
  name?: string;
  model?: string;
  initial_message?: string;
  template?: string;
  ws_template?: string;
}

export interface ConsoleCreateWsResponse {
  status: string;
  correlation_id: string;
  target_node: string;
}

export interface ConsoleHealthResponse {
  status: string;
  service: string;
  nodes: number;
  workstreams: number;
  version_drift: boolean;
  versions: string[];
}

// ---------------------------------------------------------------------------
// Console API — Schedules
// ---------------------------------------------------------------------------

export interface CreateScheduleRequest {
  name: string;
  schedule_type: string;
  initial_message: string;
  description?: string;
  cron_expr?: string;
  at_time?: string;
  target_mode?: string;
  model?: string;
  auto_approve?: boolean;
  auto_approve_tools?: string[];
  enabled?: boolean;
}

export interface UpdateScheduleRequest {
  name?: string;
  description?: string;
  schedule_type?: string;
  cron_expr?: string;
  at_time?: string;
  target_mode?: string;
  model?: string;
  initial_message?: string;
  auto_approve?: boolean;
  auto_approve_tools?: string[];
  enabled?: boolean;
}

export interface ScheduleInfo {
  task_id: string;
  name: string;
  description: string;
  schedule_type: string;
  cron_expr: string;
  at_time: string;
  target_mode: string;
  model: string;
  initial_message: string;
  auto_approve: boolean;
  auto_approve_tools: string[];
  enabled: boolean;
  created_by: string;
  last_run: string | null;
  next_run: string | null;
  created: string;
  updated: string;
}

export interface ListSchedulesResponse {
  schedules: ScheduleInfo[];
}

export interface ScheduleRunInfo {
  run_id: string;
  task_id: string;
  node_id: string;
  ws_id: string;
  correlation_id: string;
  started: string;
  status: string;
  error: string;
}

export interface ListScheduleRunsResponse {
  runs: ScheduleRunInfo[];
}

// ---------------------------------------------------------------------------
// Console API — Governance: Roles
// ---------------------------------------------------------------------------

export interface RoleInfo {
  role_id: string;
  name: string;
  display_name: string;
  permissions: string;
  builtin: boolean;
  org_id: string;
  created: string;
  updated: string;
}

export interface CreateRoleOptions {
  name: string;
  display_name?: string;
  permissions?: string;
}

export interface UpdateRoleOptions {
  display_name?: string;
  permissions?: string;
}

export interface UserRoleInfo extends RoleInfo {
  assigned_by: string;
  assignment_created: string;
}

// ---------------------------------------------------------------------------
// Console API — Governance: Orgs
// ---------------------------------------------------------------------------

export interface OrgInfo {
  org_id: string;
  name: string;
  display_name: string;
  settings: string;
  created: string;
  updated: string;
}

export interface UpdateOrgOptions {
  display_name?: string;
  settings?: string;
}

// ---------------------------------------------------------------------------
// Console API — Governance: Tool Policies
// ---------------------------------------------------------------------------

export interface ToolPolicyInfo {
  policy_id: string;
  name: string;
  tool_pattern: string;
  action: string;
  priority: number;
  org_id: string;
  enabled: boolean;
  created_by: string;
  created: string;
  updated: string;
}

export interface CreatePolicyOptions {
  name: string;
  tool_pattern: string;
  action: string;
  priority?: number;
  org_id?: string;
  enabled?: boolean;
}

export interface UpdatePolicyOptions {
  name?: string;
  tool_pattern?: string;
  action?: string;
  priority?: number;
  enabled?: boolean;
}

// ---------------------------------------------------------------------------
// Console API — Governance: Prompt Templates
// ---------------------------------------------------------------------------

export interface PromptTemplateInfo {
  template_id: string;
  name: string;
  category: string;
  content: string;
  variables: string;
  is_default: boolean;
  org_id: string;
  created_by: string;
  created: string;
  updated: string;
  origin: string;
  mcp_server: string;
  readonly: boolean;
}

export interface CreateTemplateOptions {
  name: string;
  content: string;
  category?: string;
  variables?: string;
  is_default?: boolean;
  org_id?: string;
}

export interface UpdateTemplateOptions {
  name?: string;
  content?: string;
  category?: string;
  variables?: string;
  is_default?: boolean;
}

// ---------------------------------------------------------------------------
// Console API — Governance: Workstream Templates
// ---------------------------------------------------------------------------

export interface WsTemplateInfo {
  ws_template_id: string;
  name: string;
  description: string;
  system_prompt: string;
  prompt_template: string;
  prompt_template_hash: string;
  model: string;
  auto_approve: boolean;
  auto_approve_tools: string;
  temperature: number | null;
  reasoning_effort: string;
  max_tokens: number | null;
  token_budget: number;
  agent_max_turns: number | null;
  notify_on_complete: string;
  org_id: string;
  created_by: string;
  enabled: boolean;
  version: number;
  created: string;
  updated: string;
}

export interface CreateWsTemplateOptions {
  name: string;
  description?: string;
  system_prompt?: string;
  prompt_template?: string;
  model?: string;
  auto_approve?: boolean;
  auto_approve_tools?: string;
  temperature?: number | null;
  reasoning_effort?: string;
  max_tokens?: number | null;
  token_budget?: number;
  agent_max_turns?: number | null;
  notify_on_complete?: string;
  org_id?: string;
  enabled?: boolean;
}

export interface UpdateWsTemplateOptions {
  name?: string;
  description?: string;
  system_prompt?: string;
  prompt_template?: string;
  model?: string;
  auto_approve?: boolean;
  auto_approve_tools?: string;
  temperature?: number | null;
  reasoning_effort?: string;
  max_tokens?: number | null;
  token_budget?: number;
  agent_max_turns?: number | null;
  notify_on_complete?: string;
  enabled?: boolean;
}

export interface WsTemplateVersionInfo {
  id: number;
  ws_template_id: string;
  version: number;
  snapshot: string;
  changed_by: string;
  created: string;
}

// ---------------------------------------------------------------------------
// Console API — Governance: Usage & Audit
// ---------------------------------------------------------------------------

export interface UsageBreakdownItem {
  key?: string;
  prompt_tokens: number;
  completion_tokens: number;
  tool_calls_count: number;
}

export interface UsageResponse {
  summary: UsageBreakdownItem[];
  breakdown: UsageBreakdownItem[];
}

export interface UsageQueryOptions {
  since: string;
  until?: string;
  user_id?: string;
  model?: string;
  group_by?: string;
}

export interface AuditEventInfo {
  event_id: string;
  timestamp: string;
  user_id: string;
  action: string;
  resource_type: string;
  resource_id: string;
  detail: string;
  ip_address: string;
  created: string;
}

export interface AuditQueryOptions {
  action?: string;
  user_id?: string;
  since?: string;
  until?: string;
  limit?: number;
  offset?: number;
}

export interface AuditResponse {
  events: AuditEventInfo[];
  total: number;
}

// ---------------------------------------------------------------------------
// SDK-specific types
// ---------------------------------------------------------------------------

export interface TurnResult {
  wsId: string;
  contentParts: string[];
  reasoningParts: string[];
  toolResults: Array<{ name: string; output: string }>;
  errors: string[];
  timedOut: boolean;
  content: string;
  reasoning: string;
  ok: boolean;
}

export interface SendAndWaitOptions {
  /** Timeout in milliseconds (default: 600000 = 10 minutes). */
  timeout?: number;
  onEvent?: (event: import("./events.js").ServerEvent) => void;
}

export interface NodesOptions {
  sort?: string;
  limit?: number;
  offset?: number;
}

export interface WorkstreamsOptions {
  state?: string;
  node?: string;
  search?: string;
  sort?: string;
  page?: number;
  per_page?: number;
}

// Re-export event types for convenience
export type { ServerEvent, ClusterEvent } from "./events.js";
