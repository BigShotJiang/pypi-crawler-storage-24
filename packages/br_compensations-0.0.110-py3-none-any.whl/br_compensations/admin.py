from django.contrib import admin
from .models.settings import Settings
from django.utils.translation import gettext as _

@admin.register(Settings)
class SettingsAdmin(admin.ModelAdmin):
    """
    Админ-интерфейс для настроек плагина br_compensations
    """
    list_display = ('id',  'http_proxy', 'https_proxy', 'socks5_proxy')
    list_display_links = ('id',)
    fieldsets = (
        (_('Proxy Settings'), {
            'fields': ('http_proxy', 'https_proxy', 'socks5_proxy'),
            'classes': ('collapse',),
            'description': _('Configure proxy settings for API requests. Leave empty if not needed. Only one proxy type should be configured at a time.')
        }),
    )
    
    def has_add_permission(self, request):
        # Разрешаем только одну запись настроек
        if self.model.objects.count() >= 1:
            return False
        return super().has_add_permission(request)
    
    def has_delete_permission(self, request, obj=None):
        # Запрещаем удаление настроек
        return False
