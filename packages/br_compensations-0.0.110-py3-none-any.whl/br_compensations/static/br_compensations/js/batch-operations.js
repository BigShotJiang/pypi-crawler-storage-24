/**
 * Batch Operations for Killmails
 * Позволяет выполнять массовые операции с выбранными киллмэйлами
 */

document.addEventListener('DOMContentLoaded', function () {
    // Выбор всех чекбоксов
    const selectAllCheckbox = document.getElementById('selectAll');
    if (selectAllCheckbox) {
        selectAllCheckbox.addEventListener('change', function() {
            const checkboxes = document.querySelectorAll('.killmail-checkbox');
            checkboxes.forEach(cb => cb.checked = this.checked);
            updateSelectedCount();
            toggleBatchPanel();
        });
    }

    // Отслеживание изменения отдельных чекбоксов
    document.querySelectorAll('.killmail-checkbox').forEach(checkbox => {
        checkbox.addEventListener('change', function() {
            updateSelectedCount();
            toggleBatchPanel();
            
            // Обновляем состояние "выбрать все"
            const allCheckboxes = document.querySelectorAll('.killmail-checkbox');
            const checkedCheckboxes = document.querySelectorAll('.killmail-checkbox:checked');
            selectAllCheckbox.checked = allCheckboxes.length === checkedCheckboxes.length;
        });
    });

    // Кнопка "Снять выделение"
    const clearSelectionBtn = document.getElementById('clearSelection');
    if (clearSelectionBtn) {
        clearSelectionBtn.addEventListener('click', clearSelection);
    }

    // Кнопки массовых операций
    const batchApproveBtn = document.getElementById('batchApprove');
    if (batchApproveBtn) {
        batchApproveBtn.addEventListener('click', function() {
            performBatchAction('approve', 'Вы уверены, что хотите одобрить выбранные киллмэйлы?');
        });
    }

    const batchRejectBtn = document.getElementById('batchReject');
    if (batchRejectBtn) {
        batchRejectBtn.addEventListener('click', function() {
            performBatchAction('reject', 'Вы уверены, что хотите отклонить выбранные киллмэйлы?');
        });
    }

    const batchRestoreBtn = document.getElementById('batchRestore');
    if (batchRestoreBtn) {
        batchRestoreBtn.addEventListener('click', function() {
            performBatchAction('restore', 'Вы уверены, что хотите восстановить выбранные киллмэйлы?');
        });
    }

    const batchDeleteBtn = document.getElementById('batchDelete');
    if (batchDeleteBtn) {
        batchDeleteBtn.addEventListener('click', function() {
            performBatchAction('delete', 'Вы уверены, что хотите удалить выбранные киллмэйлы?\nЭто действие невозможно отменить.');
        });
    }
});

/**
 * Получить список ID выбранных киллмэйлов
 */
function getSelectedIds() {
    const checkboxes = document.querySelectorAll('.killmail-checkbox:checked');
    return Array.from(checkboxes).map(cb => cb.dataset.id);
}

/**
 * Обновить счетчик выбранных элементов
 */
function updateSelectedCount() {
    const selectedCount = document.querySelectorAll('.killmail-checkbox:checked').length;
    const countElement = document.getElementById('selectedCount');
    if (countElement) {
        countElement.textContent = selectedCount;
    }
}

/**
 * Показать/скрыть панель массовых операций
 */
function toggleBatchPanel() {
    const selectedCount = document.querySelectorAll('.killmail-checkbox:checked').length;
    const batchPanel = document.getElementById('batchActionsPanel');
    if (batchPanel) {
        batchPanel.style.display = selectedCount > 0 ? 'block' : 'none';
    }
}

/**
 * Снять выделение со всех чекбоксов
 */
function clearSelection() {
    const checkboxes = document.querySelectorAll('.killmail-checkbox');
    checkboxes.forEach(cb => cb.checked = false);
    
    const selectAllCheckbox = document.getElementById('selectAll');
    if (selectAllCheckbox) {
        selectAllCheckbox.checked = false;
    }
    
    updateSelectedCount();
    toggleBatchPanel();
}

/**
 * Выполнить массовую операцию
 * @param {string} action - Тип операции: 'approve', 'reject', 'delete', 'restore'
 * @param {string} confirmMessage - Сообщение подтверждения
 */
async function performBatchAction(action, confirmMessage) {
    const selectedIds = getSelectedIds();
    
    if (selectedIds.length === 0) {
        showAlert('Выберите киллмэйлы для выполнения операции');
        return;
    }

    if (!await showConfirm(confirmMessage)) {
        return;
    }

    showProgress();
    setProgress(0, `Подготовка к обработке ${selectedIds.length} записей...`);

    try {
        const response = await fetch(`/br_compensations/batch/${action}/`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRFToken': csrfToken,
            },
            body: JSON.stringify({ killmail_ids: selectedIds })
        });

        if (!response.ok) {
            throw new Error(`Ошибка HTTP: ${response.status}`);
        }
 
        const data = await response.json();
        
        if (data.success) {
            // Операция завершена синхронно, обновляем UI
            setProgress(100, 'Операция завершена');
            setTimeout(() => {
                hideProgress();
                window.location.reload();
            }, 1000);
        } else {
            showAlert(data.message || 'Произошла ошибка');
            hideProgress();
        }
    } catch (error) {
        console.error('Batch action error:', error);
        showAlert(`Ошибка: ${error.message}`);
        hideProgress();
    }
}


/**
 * Показать прогресс-бар
 */
function showProgress() {
    const progressDiv = document.getElementById('batchProgress');
    if (progressDiv) {
        progressDiv.style.display = 'block';
    }
}

/**
 * Скрыть прогресс-бар
 */
function hideProgress() {
    const progressDiv = document.getElementById('batchProgress');
    if (progressDiv) {
        progressDiv.style.display = 'none';
    }
    resetProgressBar();
}

/**
 * Установить значение прогресс-бара
 * @param {number} percent - Процент выполнения
 * @param {string} text - Текст статуса
 */
function setProgress(percent, text) {
    const progressBar = document.getElementById('progressBar');
    const progressText = document.getElementById('progressText');
    
    if (progressBar) {
        progressBar.style.width = `${percent}%`;
    }
    
    if (progressText) {
        progressText.textContent = text;
    }
}

/**
 * Сбросить прогресс-бар
 */
function resetProgressBar() {
    const progressBar = document.getElementById('progressBar');
    const progressText = document.getElementById('progressText');
    
    if (progressBar) {
        progressBar.style.width = '0%';
    }
    
    if (progressText) {
        progressText.textContent = 'Обработка...';
    }
}
