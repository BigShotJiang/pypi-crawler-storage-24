from eveuniverse.models import EveSolarSystem
from django.db import models
from django.utils.translation import gettext_lazy as _

class ReportTiming(models.Model):
    
    id = models.AutoField(primary_key=True)
    system = models.ForeignKey(EveSolarSystem, on_delete=models.DO_NOTHING)
    start = models.DateTimeField(null=False,blank=False)
    end = models.DateTimeField(null=False,blank=False)
    
    class Meta:
        indexes = [
            models.Index(fields=['id'])
        ]