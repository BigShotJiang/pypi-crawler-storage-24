from django.db import models
from django.core.validators import RegexValidator
from django.utils.translation import gettext_lazy as _


class ProxyURLValidator(RegexValidator):
    """
    Custom validator for proxy URLs that supports http://, https://, socks5://, and socks5h:// protocols.
    Format: protocol://host:port
    """
    regex = r'^(https?|socks5h?)://[a-zA-Z0-9.-]+:\d{1,5}$'
    message = _(
        'Enter a valid proxy URL. '
        'Supported formats: http://host:port, https://host:port, '
        'socks5://host:port, socks5h://host:port'
    )
    flags = 0


class Settings(models.Model):
    '''
        Таблица для хранения настроек
    '''
    http_proxy = models.URLField(
        null=True,
        blank=True,
        max_length=500,
        verbose_name=_('HTTP Proxy'),
        help_text=_('HTTP proxy URL (e.g., http://proxy.example.com:8080)')
    )
    https_proxy = models.URLField(
        null=True,
        blank=True,
        max_length=500,
        verbose_name=_('HTTPS Proxy'),
        help_text=_('HTTPS proxy URL (e.g., http://proxy.example.com:8080)')
    )
    socks5_proxy = models.CharField(
        null=True,
        blank=True,
        max_length=500,
        validators=[ProxyURLValidator()],
        verbose_name=_('SOCKS5 Proxy'),
        help_text=_('SOCKS5 proxy URL (e.g., socks5://proxy.example.com:1080 or socks5h://proxy.example.com:1080 for DNS resolution through proxy)')
    )
    
    class Meta:
        verbose_name = _('Settings')
        verbose_name_plural = _('Settings')