# Generated migration for proxy settings

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ("br_compensations", "0011_killcompensation_source"),
    ]

    operations = [
        migrations.AddField(
            model_name='settings',
            name='http_proxy',
            field=models.URLField(
                blank=True,
                help_text='HTTP proxy URL (e.g., http://proxy.example.com:8080)',
                max_length=500,
                null=True,
                verbose_name='HTTP Proxy'
            ),
        ),
        migrations.AddField(
            model_name='settings',
            name='https_proxy',
            field=models.URLField(
                blank=True,
                help_text='HTTPS proxy URL (e.g., http://proxy.example.com:8080)',
                max_length=500,
                null=True,
                verbose_name='HTTPS Proxy'
            ),
        ),
    ]
