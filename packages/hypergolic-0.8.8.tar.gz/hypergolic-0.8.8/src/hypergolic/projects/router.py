import subprocess

from fastapi import APIRouter, HTTPException
from sqlalchemy import select, delete as sa_delete, func

from hypergolic.db.engine import get_db
from hypergolic.db.models import DBProject, DBSession, DBMessage
from hypergolic.projects.schemas import CreateProjectRequest, ProjectResponse

router = APIRouter(prefix="/api/projects", tags=["projects"])


def _validate_git_root(path: str) -> None:
    try:
        result = subprocess.run(
            ["git", "rev-parse", "--show-toplevel"],
            capture_output=True,
            text=True,
            cwd=path,
            check=True,
        )
        actual_root = result.stdout.strip()
        if actual_root != path:
            raise HTTPException(
                status_code=400,
                detail=f"Path is not a git root. The git root is: {actual_root}",
            )
    except (subprocess.CalledProcessError, FileNotFoundError, OSError):
        raise HTTPException(
            status_code=400,
            detail=f"Path is not a valid git repository: {path}",
        )


def _build_response(project: DBProject, last_session_at: str | None = None) -> ProjectResponse:
    return ProjectResponse(
        id=project.id,
        name=project.name,
        path=project.path,
        created_at=project.created_at.isoformat(),
        last_session_at=last_session_at,
    )


@router.get("", response_model=list[ProjectResponse])
def list_projects():
    with get_db() as db:
        latest_session = (
            select(
                DBSession.project_id,
                func.max(DBSession.created_at).label("last_session_at"),
            )
            .group_by(DBSession.project_id)
            .subquery()
        )
        rows = db.execute(
            select(DBProject, latest_session.c.last_session_at)
            .outerjoin(latest_session, DBProject.id == latest_session.c.project_id)
            .order_by(latest_session.c.last_session_at.desc().nullslast(), DBProject.name)
        ).all()
        return [
            _build_response(
                project,
                last_session_at.isoformat() if last_session_at else None,
            )
            for project, last_session_at in rows
        ]


@router.post("", response_model=ProjectResponse)
def create_project(req: CreateProjectRequest):
    _validate_git_root(req.path)
    with get_db() as db:
        existing = db.execute(
            select(DBProject).where(DBProject.path == req.path)
        ).scalar_one_or_none()
        if existing:
            raise HTTPException(
                status_code=409,
                detail=f"A project already exists for path: {req.path}",
            )
        project = DBProject(name=req.name, path=req.path)
        db.add(project)
        db.flush()
        return _build_response(project)


@router.delete("/{project_id}")
def delete_project(project_id: str):
    with get_db() as db:
        project = db.execute(
            select(DBProject).where(DBProject.id == project_id)
        ).scalar_one_or_none()
        if not project:
            raise HTTPException(status_code=404, detail="Project not found")
        sessions = db.execute(
            select(DBSession.id).where(DBSession.project_id == project_id)
        ).scalars().all()
        if sessions:
            db.execute(
                sa_delete(DBMessage).where(DBMessage.session_id.in_(sessions))
            )
            db.execute(
                sa_delete(DBSession).where(DBSession.project_id == project_id)
            )
        db.delete(project)
    return {"status": "deleted"}
