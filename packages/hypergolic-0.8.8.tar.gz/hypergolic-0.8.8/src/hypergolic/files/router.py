import asyncio
import json
import logging
from pathlib import Path

from fastapi import APIRouter, HTTPException
from fastapi.responses import StreamingResponse
from pydantic import BaseModel
from sqlalchemy import select

from hypergolic.db.engine import get_db
from hypergolic.db.models import DBProject
from hypergolic.files.operations import build_file_tree, get_repo_root
from hypergolic.files.schemas import FileNode

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/files", tags=["files"])


def _resolve_project_path(project_id: str | None) -> Path | None:
    if not project_id:
        return None
    with get_db() as db:
        project = db.execute(
            select(DBProject).where(DBProject.id == project_id)
        ).scalar_one_or_none()
        if not project:
            raise HTTPException(status_code=404, detail="Project not found")
        return Path(project.path)


class FileTreeResponse(BaseModel):
    root: str
    tree: list[FileNode]


class FileContentResponse(BaseModel):
    path: str
    content: str
    language: str


EXT_TO_LANGUAGE: dict[str, str] = {
    ".py": "python",
    ".ts": "typescript",
    ".tsx": "tsx",
    ".js": "javascript",
    ".jsx": "jsx",
    ".json": "json",
    ".css": "css",
    ".html": "html",
    ".md": "markdown",
    ".yaml": "yaml",
    ".yml": "yaml",
    ".toml": "toml",
    ".sh": "bash",
    ".bash": "bash",
    ".rs": "rust",
    ".go": "go",
    ".sql": "sql",
    ".xml": "xml",
    ".ini": "ini",
    ".cfg": "ini",
    ".dockerfile": "docker",
    ".makefile": "makefile",
}


def _detect_language(path: str) -> str:
    p = Path(path)
    if p.name == "Dockerfile":
        return "docker"
    if p.name == "Makefile":
        return "makefile"
    return EXT_TO_LANGUAGE.get(p.suffix.lower(), "text")


@router.get("/tree", response_model=FileTreeResponse)
def get_file_tree(project_id: str | None = None):
    repo = _resolve_project_path(project_id)
    return FileTreeResponse(root=get_repo_root(repo), tree=build_file_tree(repo))


@router.get("/read", response_model=FileContentResponse)
def read_file_content(path: str, project_id: str | None = None):
    repo = _resolve_project_path(project_id)
    repo_root = Path(get_repo_root(repo))
    file_path = (repo_root / path).resolve()
    if not str(file_path).startswith(str(repo_root)):
        raise HTTPException(status_code=403, detail="Access denied")
    if not file_path.is_file():
        raise HTTPException(status_code=404, detail="File not found")
    try:
        content = file_path.read_text(errors="replace")
    except Exception as e:
        logger.error("Error reading file %s", path, exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))
    return FileContentResponse(
        path=path,
        content=content,
        language=_detect_language(path),
    )


@router.get("/watch")
async def watch_files_sse(project_id: str | None = None):
    repo = _resolve_project_path(project_id)

    async def event_stream():
        from watchfiles import awatch, Change

        repo_root = get_repo_root(repo)
        yield f"data: {json.dumps({'type': 'connected', 'root': repo_root})}\n\n"

        try:
            async for changes in awatch(repo_root):
                changed_paths = [
                    {
                        "change": "added" if c == Change.added else "modified" if c == Change.modified else "deleted",
                        "path": str(Path(p).relative_to(repo_root)),
                    }
                    for c, p in changes
                ]
                yield f"data: {json.dumps({'type': 'changes', 'changes': changed_paths})}\n\n"
        except asyncio.CancelledError:
            return

    return StreamingResponse(
        event_stream(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "X-Accel-Buffering": "no",
        },
    )
