from pydantic import BaseModel


class FileNode(BaseModel):
    name: str
    path: str
    is_dir: bool
    git_status: str | None = None
    children: list["FileNode"] | None = None
