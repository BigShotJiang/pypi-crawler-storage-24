import uuid
from pathlib import Path

from sqlalchemy import select

from hypergolic.db.engine import get_db
from hypergolic.db.models import DBProject, DBSession, DBSessionSkill
from hypergolic.enums import ModelTier
from hypergolic.schemas import Session
from hypergolic.skills.resolver import resolve_roles


def _get_role_skills(project_path: str, role_id: str) -> list[str]:

    roles = resolve_roles(Path(project_path))
    for role in roles:
        if role["id"] == role_id:
            return role.get("skills", [])
    return []


def create_session(
    project_id: str,
    model_tier: ModelTier = ModelTier.HIGH,
    role: str = "default",
) -> Session:
    session_id = str(uuid.uuid7())
    system_prompt = [{"type": "text", "text": "placeholder"}]

    with get_db() as db:
        project = db.execute(
            select(DBProject).where(DBProject.id == project_id)
        ).scalar_one()

        db_session = DBSession(
            id=session_id,
            model_tier=model_tier,
            system_prompt=system_prompt,
            role=role,
            project_id=project_id,
        )
        db.add(db_session)

        role_skill_ids = _get_role_skills(project.path, role)
        for skill_id in role_skill_ids:
            db.add(DBSessionSkill(
                session_id=session_id,
                skill_id=skill_id,
            ))

        return Session(
            id=session_id,
            model_tier=model_tier,
            project_id=project_id,
            project_path=project.path,
            role=role,
        )
