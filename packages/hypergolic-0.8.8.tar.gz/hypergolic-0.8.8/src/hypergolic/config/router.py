import json
from pathlib import Path
from typing import Any

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from sqlalchemy import select

from hypergolic.config.settings import (
    USER_CONFIG_PATH,
    _load_user_config,
    load_user_project_config,
)
from hypergolic.db.engine import get_db
from hypergolic.db.models import DBProject

router = APIRouter(prefix="/api/config", tags=["config"])


class ConfigLayerResponse(BaseModel):
    label: str
    path: str
    exists: bool
    data: dict[str, Any] | None = None


class ConfigResponse(BaseModel):
    layers: list[ConfigLayerResponse]


def _resolve_project_path(project_id: str | None) -> Path | None:
    if not project_id:
        return None
    with get_db() as db:
        project = db.execute(
            select(DBProject).where(DBProject.id == project_id)
        ).scalar_one_or_none()
        if not project:
            raise HTTPException(status_code=404, detail="Project not found")
        return Path(project.path)


@router.get("", response_model=ConfigResponse)
def get_config(project_id: str | None = None):
    layers: list[ConfigLayerResponse] = []
    project_path = _resolve_project_path(project_id)

    user_path = USER_CONFIG_PATH
    user_data = None
    if user_path.exists():
        try:
            raw = json.loads(user_path.read_text())
            display = {k: v for k, v in raw.items() if k != "projects"}
            user_data = display
        except Exception:
            pass
    layers.append(ConfigLayerResponse(
        label="User",
        path=str(user_path),
        exists=user_path.exists(),
        data=user_data,
    ))

    if project_path:
        project_config_path = project_path / ".agents" / "config.json"
        project_data = None
        if project_config_path.exists():
            try:
                project_data = json.loads(project_config_path.read_text())
            except Exception:
                pass
        layers.append(ConfigLayerResponse(
            label="Project",
            path=str(project_config_path),
            exists=project_config_path.exists(),
            data=project_data,
        ))

        user_project_config = load_user_project_config(project_path)
        if user_project_config:
            user_config = _load_user_config()
            for p in user_config.projects:
                if str(Path(p.git_root).resolve()) == str(project_path.resolve()):
                    layers.append(ConfigLayerResponse(
                        label="User-Project",
                        path=str(USER_CONFIG_PATH) + f" (projects[{p.name}])",
                        exists=True,
                        data=p.model_dump(mode="json"),
                    ))
                    break

    return ConfigResponse(layers=layers)
