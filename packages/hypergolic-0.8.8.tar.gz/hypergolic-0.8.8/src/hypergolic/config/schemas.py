from pathlib import Path
from typing import Any, Literal

from pydantic import BaseModel, Field


class MCPAuthConfig(BaseModel):
    type: Literal["none", "token", "oauth"] = "none"
    token_env_var: str | None = None
    token_header: str = "Authorization"
    token_prefix: str = "Bearer"


class MCPServerConfig(BaseModel):
    transport: Literal["stdio", "streamable_http", "sse"] = "stdio"
    command: str | None = None
    args: list[str] = Field(default_factory=list)
    env: dict[str, str] = Field(default_factory=dict)
    url: str | None = None
    auth: MCPAuthConfig = Field(default_factory=MCPAuthConfig)


class CustomToolParam(BaseModel):
    name: str
    type: Literal["string", "integer", "boolean"] = "string"
    description: str = ""
    required: bool = True
    default: Any = None


class CustomToolConfig(BaseModel):
    id: str
    name: str
    description: str
    command: str
    working_directory: str | None = None
    timeout: int = 30
    requires_approval: bool = False
    parameters: list[CustomToolParam] = Field(default_factory=list)


class SkillConfig(BaseModel):
    id: str
    name: str
    description: str
    prompt_path: str


class RoleConfig(BaseModel):
    id: str
    name: str
    prompt_path: str
    skills: list[str] = Field(default_factory=list)


class UserProjectConfig(BaseModel):
    git_root: str
    name: str
    prompt_path: str | None = None
    mcp_servers: dict[str, MCPServerConfig] = Field(default_factory=dict)
    tools: list[CustomToolConfig] = Field(default_factory=list)
    skills: list[SkillConfig] = Field(default_factory=list)
    roles: list[RoleConfig] = Field(default_factory=list)


class UserConfig(BaseModel):
    db_path: Path = Path.home() / ".agents" / "hypergolicV4.db"
    prompt_path: Path = Path.home() / ".agents" / "PROMPT.md"
    mcp_servers: dict[str, MCPServerConfig] = Field(default_factory=dict)
    tools: list[CustomToolConfig] = Field(default_factory=list)
    skills: list[SkillConfig] = Field(default_factory=list)
    roles: list[RoleConfig] = Field(default_factory=list)
    projects: list[UserProjectConfig] = Field(default_factory=list)


class ProjectConfig(BaseModel):
    name: str = ""
    prompt_path: str = ".agents/PROMPT.md"
    mcp_servers: dict[str, MCPServerConfig] = Field(default_factory=dict)
    tools: list[CustomToolConfig] = Field(default_factory=list)
    skills: list[SkillConfig] = Field(default_factory=list)
    roles: list[RoleConfig] = Field(default_factory=list)
