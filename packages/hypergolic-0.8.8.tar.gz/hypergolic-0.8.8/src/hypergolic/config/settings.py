import json
import logging
import os
from pathlib import Path

from pydantic_settings import BaseSettings

from hypergolic.config.schemas import ProjectConfig, UserConfig, UserProjectConfig

logger = logging.getLogger(__name__)

USER_CONFIG_PATH = Path.home() / ".agents" / "config.json"


def _load_user_config() -> UserConfig:
    if USER_CONFIG_PATH.exists():
        try:
            data = json.loads(USER_CONFIG_PATH.read_text())
            return UserConfig.model_validate(data)
        except Exception:
            logger.warning("Failed to parse user config at %s", USER_CONFIG_PATH, exc_info=True)
    return UserConfig()


def load_user_project_config(project_path: Path | None = None) -> UserProjectConfig | None:
    if project_path is None:
        return None
    user_config = _load_user_config()
    resolved = str(project_path.resolve())
    for config in user_config.projects:
        if str(Path(config.git_root).resolve()) == resolved:
            return config
    return None


def load_project_config(project_path: Path | None = None) -> ProjectConfig:
    if project_path is None:
        return ProjectConfig()
    project_config_path = project_path / ".agents" / "config.json"
    if project_config_path.exists():
        try:
            data = json.loads(project_config_path.read_text())
            return ProjectConfig.model_validate(data)
        except Exception:
            logger.warning("Failed to parse project config at %s", project_config_path, exc_info=True)
    return ProjectConfig()


def _default_database_url(user_config: UserConfig) -> str:
    db_path = user_config.db_path
    db_path.parent.mkdir(parents=True, exist_ok=True)
    return f"sqlite:///{db_path}"


class Settings(BaseSettings):
    HYPERGOLIC_API_KEY: str
    HYPERGOLIC_BASE_URL: str
    DATABASE_URL: str
    user_config: UserConfig
    project_config: ProjectConfig


def build_settings() -> Settings:
    user_config = _load_user_config()
    project_config = load_project_config()
    return Settings(
        DATABASE_URL=os.environ.get("DATABASE_URL", _default_database_url(user_config)),
        HYPERGOLIC_API_KEY=os.environ["HYPERGOLIC_API_KEY"],
        HYPERGOLIC_BASE_URL=os.environ["HYPERGOLIC_BASE_URL"],
        user_config=user_config,
        project_config=project_config,
    )


settings = build_settings()
