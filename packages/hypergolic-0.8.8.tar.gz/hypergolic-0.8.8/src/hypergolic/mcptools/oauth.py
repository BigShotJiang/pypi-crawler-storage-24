import asyncio
import json
import logging
import threading
import webbrowser
from http.server import HTTPServer, BaseHTTPRequestHandler
from pathlib import Path
from urllib.parse import urlparse, parse_qs

from mcp.client.auth import TokenStorage
from mcp.shared.auth import OAuthClientInformationFull, OAuthToken

logger = logging.getLogger(__name__)

TOKEN_DIR = Path.home() / ".agents" / "mcp_tokens"
OAUTH_CALLBACK_PORT = 19836
OAUTH_REDIRECT_URI = f"http://localhost:{OAUTH_CALLBACK_PORT}/oauth/callback"


class FileTokenStorage(TokenStorage):
    def __init__(self, server_name: str) -> None:
        self._dir = TOKEN_DIR / server_name
        self._dir.mkdir(parents=True, exist_ok=True)
        self._tokens_path = self._dir / "tokens.json"
        self._client_info_path = self._dir / "client_info.json"

    async def get_tokens(self) -> OAuthToken | None:
        if not self._tokens_path.exists():
            return None
        try:
            data = json.loads(self._tokens_path.read_text())
            return OAuthToken.model_validate(data)
        except Exception:
            logger.warning("Failed to read tokens for MCP server", exc_info=True)
            return None

    async def set_tokens(self, tokens: OAuthToken) -> None:
        self._tokens_path.write_text(tokens.model_dump_json(indent=2))

    async def get_client_info(self) -> OAuthClientInformationFull | None:
        if not self._client_info_path.exists():
            return None
        try:
            data = json.loads(self._client_info_path.read_text())
            return OAuthClientInformationFull.model_validate(data)
        except Exception:
            logger.warning("Failed to read client info for MCP server", exc_info=True)
            return None

    async def set_client_info(self, client_info: OAuthClientInformationFull) -> None:
        self._client_info_path.write_text(client_info.model_dump_json(indent=2))


class _OAuthCallbackHandler(BaseHTTPRequestHandler):
    auth_code: str | None = None
    state: str | None = None

    def do_GET(self) -> None:
        parsed = urlparse(self.path)
        if parsed.path == "/oauth/callback":
            params = parse_qs(parsed.query)
            code = params.get("code", [None])[0]
            state = params.get("state", [None])[0]
            self.server._auth_code = code  # type: ignore[attr-defined]
            self.server._auth_state = state  # type: ignore[attr-defined]
            self.send_response(200)
            self.send_header("Content-Type", "text/html")
            self.end_headers()
            self.wfile.write(
                b"<html><body><h2>Authorization successful!</h2>"
                b"<p>You can close this tab and return to Hypergolic.</p>"
                b"</body></html>"
            )
        else:
            self.send_response(404)
            self.end_headers()

    def log_message(self, format: str, *args: object) -> None:
        pass


async def open_browser_for_oauth(authorization_url: str) -> None:
    logger.info("Opening browser for OAuth: %s", authorization_url)
    webbrowser.open(authorization_url)


async def wait_for_oauth_callback() -> tuple[str, str | None]:
    server = HTTPServer(("localhost", OAUTH_CALLBACK_PORT), _OAuthCallbackHandler)
    server._auth_code = None  # type: ignore[attr-defined]
    server._auth_state = None  # type: ignore[attr-defined]

    thread = threading.Thread(target=server.handle_request, daemon=True)
    thread.start()

    code: str | None = None
    for _ in range(600):  # 5 minute timeout
        await asyncio.sleep(0.5)
        if server._auth_code is not None:  # type: ignore[attr-defined]
            code = server._auth_code
            break

    state = server._auth_state  # type: ignore[attr-defined]
    server.server_close()

    if code is None:
        raise TimeoutError("OAuth callback timed out")

    return code, state
