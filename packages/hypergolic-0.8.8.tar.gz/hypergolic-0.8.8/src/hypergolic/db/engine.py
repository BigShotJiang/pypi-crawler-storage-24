from contextlib import contextmanager
from typing import Iterator

from sqlalchemy import create_engine
from sqlalchemy.orm import Session

from hypergolic.config.settings import settings

engine = create_engine(settings.DATABASE_URL)


@contextmanager
def get_db() -> Iterator[Session]:
    with Session(engine) as session:
        with session.begin():
            yield session
