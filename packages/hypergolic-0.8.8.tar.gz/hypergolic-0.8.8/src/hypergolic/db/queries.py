from sqlalchemy import select
from sqlalchemy.orm import Session

from hypergolic.db.models import DBKnowledgeTag, DBTag


def get_tags_for_knowledge(db: Session, knowledge_id: str) -> list[str]:
    rows = db.execute(
        select(DBTag.name)
        .join(DBKnowledgeTag, DBKnowledgeTag.tag_id == DBTag.id)
        .where(DBKnowledgeTag.knowledge_id == knowledge_id)
    ).scalars().all()
    return list(rows)
