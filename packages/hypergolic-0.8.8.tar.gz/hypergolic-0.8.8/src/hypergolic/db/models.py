from datetime import datetime
import uuid
from typing import Any

from anthropic.types.tool_result_block_param import Content
from sqlalchemy import JSON, ForeignKey, func
from sqlalchemy import DateTime, String, Integer
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column

from hypergolic.enums import KnowledgeRelationType, KnowledgeScope, ModelTier, SessionStatus


class Base(DeclarativeBase):

    id: Mapped[str] = mapped_column(
        String,
        primary_key=True,
        nullable=False,
        default=lambda: str(uuid.uuid7()),
    )
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        default=func.now(),
        nullable=False,
        index=True,
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=func.now(), onupdate=func.now(), nullable=False
    )


class DBSession(Base):
    __tablename__ = "sessions"

    model_tier: Mapped[ModelTier] = mapped_column(String, nullable=False)
    system_prompt: Mapped[list[Content]] = mapped_column(JSON, nullable=False)
    role: Mapped[str] = mapped_column(String, nullable=False, default="default")
    status: Mapped[SessionStatus] = mapped_column(
        String, nullable=False, default=SessionStatus.IDLE
    )
    project_id: Mapped[str] = mapped_column(
        String,
        ForeignKey("projects.id", name="fk_sessions_projects"),
        nullable=False,
        index=True,
    )


class DBMessage(Base):
    __tablename__ = "messages"

    content: Mapped[list[Content]] = mapped_column(JSON, nullable=False)
    session_id: Mapped[str] = mapped_column(
        String,
        ForeignKey("sessions.id", name="fk_messages_sessions"),
        nullable=False,
        index=True,
    )
    model: Mapped[str] = mapped_column(String, nullable=True)
    role: Mapped[str] = mapped_column(String, nullable=False)
    stop_reason: Mapped[str | None] = mapped_column(String, nullable=True)
    stop_sequence: Mapped[str | None] = mapped_column(String, nullable=True)
    usage: Mapped[dict[str, Any] | None] = mapped_column(JSON, nullable=True)
    truncated: Mapped[bool] = mapped_column(default=False, nullable=False)


class DBProject(Base):
    __tablename__ = "projects"

    name: Mapped[str] = mapped_column(String, nullable=False)
    path: Mapped[str] = mapped_column(String, nullable=False, unique=True)


class DBTag(Base):
    __tablename__ = "tags"

    name: Mapped[str] = mapped_column(String, nullable=False, unique=True)


class DBKnowledge(Base):
    __tablename__ = "knowledge"

    content: Mapped[str] = mapped_column(String, nullable=False)
    scope: Mapped[KnowledgeScope] = mapped_column(String, nullable=False, default=KnowledgeScope.UNIVERSAL)
    source: Mapped[str | None] = mapped_column(String, nullable=True)
    project_id: Mapped[str | None] = mapped_column(
        String,
        ForeignKey("projects.id", name="fk_knowledge_projects"),
        nullable=True,
        index=True,
    )
    session_id: Mapped[str | None] = mapped_column(
        String,
        ForeignKey("sessions.id", name="fk_knowledge_sessions"),
        nullable=True,
        index=True,
    )


class DBKnowledgeTag(Base):
    __tablename__ = "knowledge_tags"

    knowledge_id: Mapped[str] = mapped_column(
        String,
        ForeignKey("knowledge.id", name="fk_knowledge_tags_knowledge"),
        nullable=False,
        index=True,
    )
    tag_id: Mapped[str] = mapped_column(
        String,
        ForeignKey("tags.id", name="fk_knowledge_tags_tags"),
        nullable=False,
        index=True,
    )


class DBToolApprovalRule(Base):
    __tablename__ = "tool_approval_rules"

    tool_name: Mapped[str] = mapped_column(String, nullable=False, index=True)
    action: Mapped[str] = mapped_column(String, nullable=False)  # allow, deny, require_approval
    conditions: Mapped[list[dict[str, Any]]] = mapped_column(JSON, nullable=False, default=list)
    priority: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    project_id: Mapped[str | None] = mapped_column(
        String,
        ForeignKey("projects.id", name="fk_tool_approval_rules_projects"),
        nullable=True,
        index=True,
    )
    session_id: Mapped[str | None] = mapped_column(
        String,
        ForeignKey("sessions.id", name="fk_tool_approval_rules_sessions"),
        nullable=True,
        index=True,
    )


class DBSessionSkill(Base):
    __tablename__ = "session_skills"

    session_id: Mapped[str] = mapped_column(
        String,
        ForeignKey("sessions.id", name="fk_session_skills_sessions", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )
    skill_id: Mapped[str] = mapped_column(String, nullable=False)


class DBKnowledgeRelationship(Base):
    __tablename__ = "knowledge_relationships"

    source_id: Mapped[str] = mapped_column(
        String,
        ForeignKey("knowledge.id", name="fk_knowledge_rel_source"),
        nullable=False,
        index=True,
    )
    target_id: Mapped[str] = mapped_column(
        String,
        ForeignKey("knowledge.id", name="fk_knowledge_rel_target"),
        nullable=False,
        index=True,
    )
    relation_type: Mapped[KnowledgeRelationType] = mapped_column(
        String,
        nullable=False,
    )
