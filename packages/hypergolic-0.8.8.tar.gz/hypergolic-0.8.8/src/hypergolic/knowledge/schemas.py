from pydantic import BaseModel


class TagResponse(BaseModel):
    id: str
    name: str
    count: int
    created_at: str


class KnowledgeItemResponse(BaseModel):
    id: str
    content: str
    scope: str
    source: str | None
    project_id: str | None
    session_id: str | None
    tags: list[str]
    created_at: str
    updated_at: str


class CreateKnowledgeRequest(BaseModel):
    content: str
    scope: str = "universal"
    source: str | None = None
    tags: list[str] = []
    project_id: str | None = None
    session_id: str | None = None


class CreateTagRequest(BaseModel):
    name: str


class KnowledgeRelationshipResponse(BaseModel):
    id: str
    source_id: str
    target_id: str
    relation_type: str
    target_content: str
    target_scope: str
    target_tags: list[str]
    created_at: str


class CreateRelationshipRequest(BaseModel):
    source_id: str
    target_id: str
    relation_type: str
