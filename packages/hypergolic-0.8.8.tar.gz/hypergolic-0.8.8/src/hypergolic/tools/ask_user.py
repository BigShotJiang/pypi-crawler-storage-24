from typing import Optional

from pydantic import BaseModel, Field

from hypergolic.schemas import Session
from hypergolic.tools.schemas import Tool, ToolOutput


class AskUserInput(BaseModel):
    question: str = Field(
        description="The question to ask the user.",
    )
    options: Optional[list[str]] = Field(
        default=None,
        description="Predefined answer options for the user to choose from.",
    )


async def run_ask_user(input: AskUserInput, session: Session) -> ToolOutput:
    return ToolOutput(
        content=[{"type": "text", "text": "Error: ask_user requires an interactive callback."}],
        is_error=True,
    )


AskUserTool = Tool(
    id="ask_user",
    name="Ask User",
    description="Ask the user a question and wait for their response.",
    strict=False,
    input=AskUserInput,
    call_tool=run_ask_user,
)
