import re
import shlex
import subprocess
from typing import Any

from pydantic import BaseModel, Field, create_model

from hypergolic.config.schemas import CustomToolConfig
from hypergolic.schemas import Session
from hypergolic.tools.schemas import Tool, ToolOutput

PARAM_TYPE_MAP: dict[str, type] = {
    "string": str,
    "integer": int,
    "boolean": bool,
}


def _build_input_model(config: CustomToolConfig) -> type[BaseModel]:
    if not config.parameters:
        return create_model(f"{config.id}_Input")

    field_definitions: dict[str, Any] = {}
    for param in config.parameters:
        python_type = PARAM_TYPE_MAP[param.type]
        if param.required:
            field_definitions[param.name] = (
                python_type,
                Field(description=param.description) if param.description else ...,
            )
        else:
            field_definitions[param.name] = (
                python_type | None,
                Field(default=param.default, description=param.description),
            )

    return create_model(f"{config.id}_Input", **field_definitions)


def _interpolate_command(command: str, params: BaseModel) -> str:
    result = command
    for key, value in params.model_dump(exclude_none=True).items():
        str_value = str(value)
        if str_value:
            result = result.replace("{{" + key + "}}", shlex.quote(str_value))
    result = re.sub(r"\{\{\w+\}\}", "", result)
    return result.strip()


def _make_call_tool(config: CustomToolConfig):
    async def call_tool(input: BaseModel, session: Session) -> ToolOutput:
        command = _interpolate_command(config.command, input)
        cwd = config.working_directory or str(session.working_directory())

        try:
            result = subprocess.run(
                command,
                shell=True,
                capture_output=True,
                text=True,
                timeout=config.timeout,
                cwd=cwd,
            )

            output_parts = []
            if result.stdout:
                output_parts.append(f"STDOUT:\n{result.stdout}")
            if result.stderr:
                output_parts.append(f"STDERR:\n{result.stderr}")
            output_parts.append(f"Exit code: {result.returncode}")

            return ToolOutput(
                content=[{"type": "text", "text": "\n\n".join(output_parts)}],
                is_error=result.returncode != 0,
            )
        except subprocess.TimeoutExpired:
            return ToolOutput(
                content=[{"type": "text", "text": f"Command timed out after {config.timeout} seconds."}],
                is_error=True,
            )
        except FileNotFoundError:
            return ToolOutput(
                content=[{"type": "text", "text": f"Working directory not found: {cwd}"}],
                is_error=True,
            )
        except Exception as e:
            return ToolOutput(
                content=[{"type": "text", "text": f"Error executing custom tool: {e}"}],
                is_error=True,
            )

    return call_tool


def build_custom_tool(config: CustomToolConfig) -> Tool:
    input_model = _build_input_model(config)
    return Tool(
        id=config.id,
        name=config.name,
        description=config.description,
        strict=True,
        input=input_model,
        call_tool=_make_call_tool(config),
    )
