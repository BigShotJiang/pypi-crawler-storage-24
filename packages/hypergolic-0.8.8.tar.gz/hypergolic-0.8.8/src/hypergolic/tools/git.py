from typing import Literal, Optional

from pydantic import BaseModel, Field

from hypergolic.git.operations import (
    get_git_status,
    get_git_diff,
    get_git_log,
    get_git_commit_detail,
    git_push,
    git_pull,
    _run_git,
)
from hypergolic.schemas import Session
from hypergolic.tools.schemas import Tool, ToolOutput

GIT_COMMANDS = Literal[
    "status",
    "diff",
    "log",
    "show",
    "branch_list",
    "stash_list",
    "checkout",
    "create_branch",
    "reset",
    "push",
    "pull",
    "merge",
    "rebase",
]

READ_ONLY_COMMANDS = {"status", "diff", "log", "show", "branch_list", "stash_list"}


class GitInput(BaseModel):
    command: GIT_COMMANDS = Field(
        description="The git operation. Read-only commands run without approval; mutating commands require approval.",
    )
    path: Optional[str] = Field(
        default=None,
        description="File path or branch/ref name, depending on command.",
    )
    staged: bool = Field(
        default=False,
        description="Show staged diff (for 'diff').",
    )
    commit_hash: Optional[str] = Field(
        default=None,
        description="Commit hash (for 'show').",
    )
    count: int = Field(
        default=50,
        description="Number of entries (for 'log').",
    )
    hard: bool = Field(
        default=False,
        description="Use --hard (for 'reset').",
    )


def _format_status(status) -> str:
    lines = [f"Branch: {status.branch}"]
    if status.ahead:
        lines.append(f"Ahead: {status.ahead}")
    if status.behind:
        lines.append(f"Behind: {status.behind}")
    if status.staged:
        lines.append("\nStaged:")
        for f in status.staged:
            lines.append(f"  {f.status} {f.path} (+{f.additions}/-{f.deletions})")
    if status.unstaged:
        lines.append("\nUnstaged:")
        for f in status.unstaged:
            lines.append(f"  {f.status} {f.path} (+{f.additions}/-{f.deletions})")
    if status.untracked:
        lines.append("\nUntracked:")
        for f in status.untracked:
            lines.append(f"  {f}")
    if not status.staged and not status.unstaged and not status.untracked:
        lines.append("\nWorking tree clean.")
    return "\n".join(lines)


def _format_log(log_response) -> str:
    lines = []
    for entry in log_response.entries:
        refs = f" ({entry.refs})" if entry.refs else ""
        lines.append(f"{entry.short_hash} {entry.message} — {entry.author}, {entry.date}{refs}")
    return "\n".join(lines) if lines else "No commits found."


def _format_show(detail) -> str:
    lines = [
        f"Commit: {detail.hash}",
        f"Author: {detail.author}",
        f"Date:   {detail.date}",
        f"\n    {detail.message}",
    ]
    if detail.diff:
        lines.append(f"\n{detail.diff}")
    return "\n".join(lines)


def _run_git_tool_command(inp: GitInput, session: Session) -> ToolOutput:
    repo_path = session.working_directory()

    match inp.command:
        case "status":
            status = get_git_status(repo=repo_path)
            return ToolOutput(content=[{"type": "text", "text": _format_status(status)}])

        case "diff":
            diff = get_git_diff(inp.path, inp.staged, repo=repo_path)
            text = diff.diff if diff.diff else "No diff output."
            return ToolOutput(content=[{"type": "text", "text": text}])

        case "log":
            log = get_git_log(inp.count, repo=repo_path)
            return ToolOutput(content=[{"type": "text", "text": _format_log(log)}])

        case "show":
            if not inp.commit_hash:
                return ToolOutput(
                    content=[{"type": "text", "text": "Error: 'commit_hash' is required for show."}],
                    is_error=True,
                )
            detail = get_git_commit_detail(inp.commit_hash, repo=repo_path)
            return ToolOutput(content=[{"type": "text", "text": _format_show(detail)}])

        case "branch_list":
            result = _run_git("branch", "-a", cwd=repo_path)
            text = result.stdout.strip() if result.stdout.strip() else "No branches found."
            return ToolOutput(
                content=[{"type": "text", "text": text}],
                is_error=result.returncode != 0,
            )

        case "stash_list":
            result = _run_git("stash", "list", cwd=repo_path)
            text = result.stdout.strip() if result.stdout.strip() else "No stashes."
            return ToolOutput(content=[{"type": "text", "text": text}])

        case "checkout":
            if not inp.path:
                return ToolOutput(
                    content=[{"type": "text", "text": "Error: 'path' (branch/ref name) is required for checkout."}],
                    is_error=True,
                )
            result = _run_git("checkout", inp.path, cwd=repo_path)
            text = result.stdout.strip() or result.stderr.strip() or "Checkout complete."
            return ToolOutput(
                content=[{"type": "text", "text": text}],
                is_error=result.returncode != 0,
            )

        case "create_branch":
            if not inp.path:
                return ToolOutput(
                    content=[{"type": "text", "text": "Error: 'path' (branch name) is required for create_branch."}],
                    is_error=True,
                )
            result = _run_git("checkout", "-b", inp.path, cwd=repo_path)
            text = result.stdout.strip() or result.stderr.strip() or f"Created and switched to branch '{inp.path}'."
            return ToolOutput(
                content=[{"type": "text", "text": text}],
                is_error=result.returncode != 0,
            )

        case "reset":
            if not inp.path:
                return ToolOutput(
                    content=[{"type": "text", "text": "Error: 'path' (ref/commit) is required for reset."}],
                    is_error=True,
                )
            args = ["reset"]
            if inp.hard:
                args.append("--hard")
            args.append(inp.path)
            result = _run_git(*args, cwd=repo_path)
            text = result.stdout.strip() or result.stderr.strip() or "Reset complete."
            return ToolOutput(
                content=[{"type": "text", "text": text}],
                is_error=result.returncode != 0,
            )

        case "push":
            output = git_push(repo=repo_path)
            return ToolOutput(content=[{"type": "text", "text": output}])

        case "pull":
            output = git_pull(repo=repo_path)
            return ToolOutput(content=[{"type": "text", "text": output}])

        case "merge":
            if not inp.path:
                return ToolOutput(
                    content=[{"type": "text", "text": "Error: 'path' (branch name) is required for merge."}],
                    is_error=True,
                )
            result = _run_git("merge", inp.path, cwd=repo_path)
            text = result.stdout.strip() or result.stderr.strip() or "Merge complete."
            return ToolOutput(
                content=[{"type": "text", "text": text}],
                is_error=result.returncode != 0,
            )

        case "rebase":
            if not inp.path:
                return ToolOutput(
                    content=[{"type": "text", "text": "Error: 'path' (branch/ref) is required for rebase."}],
                    is_error=True,
                )
            result = _run_git("rebase", inp.path, cwd=repo_path)
            text = result.stdout.strip() or result.stderr.strip() or "Rebase complete."
            return ToolOutput(
                content=[{"type": "text", "text": text}],
                is_error=result.returncode != 0,
            )


async def run_git(inp: GitInput, session: Session) -> ToolOutput:
    try:
        return _run_git_tool_command(inp, session)
    except Exception as e:
        return ToolOutput(
            content=[{"type": "text", "text": f"Git error: {e}"}],
            is_error=True,
        )


GitTool = Tool(
    id="git",
    name="Git",
    description="Interact with the git repository. Read-only commands run without approval; mutating commands require approval.",
    strict=False,
    input=GitInput,
    call_tool=run_git,
)
