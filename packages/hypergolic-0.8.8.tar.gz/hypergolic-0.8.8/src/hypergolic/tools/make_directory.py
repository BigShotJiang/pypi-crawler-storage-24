from pathlib import Path

from pydantic import BaseModel, Field

from hypergolic.schemas import Session
from hypergolic.tools.schemas import Tool, ToolOutput


class MakeDirectoryInput(BaseModel):
    path: str | None = Field(
        default=None,
        description="Directory path to create (single).",
    )
    paths: list[str] | None = Field(
        default=None,
        description="Directory paths to create (batch).",
    )


def _make_single_directory(dir_path: str, session: Session) -> tuple[str, bool]:
    p = Path(dir_path).expanduser()
    if not p.is_absolute():
        p = session.working_directory() / p
    try:
        already_exists = p.is_dir()
        p.mkdir(parents=True, exist_ok=True)
        if already_exists:
            return f"Directory already exists: {dir_path}", False
        return f"Created directory: {dir_path}", False
    except PermissionError:
        return f"Permission denied: {dir_path}", True
    except Exception as e:
        return f"Error creating directory {dir_path}: {e}", True


async def make_directory(input: MakeDirectoryInput, session: Session) -> ToolOutput:
    dir_paths: list[str] = []
    if input.paths:
        dir_paths = input.paths
    elif input.path:
        dir_paths = [input.path]
    else:
        return ToolOutput(
            content=[{"type": "text", "text": "Error: 'path' or 'paths' is required."}],
            is_error=True,
        )

    results = []
    has_error = False
    for dir_path in dir_paths:
        msg, is_err = _make_single_directory(dir_path, session)
        results.append({"type": "text", "text": msg})
        if is_err:
            has_error = True

    return ToolOutput(content=results, is_error=has_error)


MakeDirectoryTool = Tool(
    id="make_directory",
    name="Make Directory",
    description="Create one or more directories, including parent directories.",
    strict=False,
    input=MakeDirectoryInput,
    call_tool=make_directory,
)
