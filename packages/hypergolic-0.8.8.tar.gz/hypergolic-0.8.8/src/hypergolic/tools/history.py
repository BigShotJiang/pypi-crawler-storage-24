import json
from typing import Any, Literal

from pydantic import BaseModel, Field
from sqlalchemy import String as SAString, func, select
from sqlalchemy.sql.expression import cast

from hypergolic.db.engine import get_db
from hypergolic.db.models import DBMessage, DBSession
from hypergolic.schemas import Session
from hypergolic.tools.schemas import Tool, ToolOutput

MAX_SESSIONS = 50
MAX_MESSAGES = 100
MAX_CONTENT_PREVIEW = 500


class HistoryInput(BaseModel):
    command: Literal["list_sessions", "get_messages", "search_messages"] = Field(
        description="The history operation to perform.",
    )
    query: str | None = Field(
        default=None,
        description="Text to search for in messages.",
    )
    session_id: str | None = Field(
        default=None,
        description="Session ID (for 'get_messages').",
    )
    role: Literal["user", "assistant"] | None = Field(
        default=None,
        description="Filter by role.",
    )
    limit: int | None = Field(
        default=None,
        description="Max results to return.",
    )
    offset: int | None = Field(
        default=None,
        description="Pagination offset.",
    )


def _extract_text(content: list[Any]) -> str:
    parts: list[str] = []
    for block in content:
        if isinstance(block, dict):
            if block.get("type") == "text":
                parts.append(block.get("text", ""))
            elif block.get("type") == "tool_use":
                parts.append(f"[tool_use: {block.get('name', '?')}]")
            elif block.get("type") == "tool_result":
                parts.append("[tool_result]")
        elif isinstance(block, str):
            parts.append(block)
    return "\n".join(parts)


def _serialize_session(
    session: DBSession,
    message_count: int | None = None,
    first_message_preview: str | None = None,
) -> dict:
    result: dict[str, Any] = {
        "id": session.id,
        "model_tier": session.model_tier,
        "created_at": session.created_at.isoformat(),
        "updated_at": session.updated_at.isoformat(),
    }
    if message_count is not None:
        result["message_count"] = message_count
    if first_message_preview is not None:
        result["first_message"] = first_message_preview
    return result


def _serialize_message(msg: DBMessage, truncate: int | None = None) -> dict:
    text = _extract_text(msg.content)
    if truncate and len(text) > truncate:
        text = text[:truncate] + "..."
    result: dict[str, Any] = {
        "id": msg.id,
        "session_id": msg.session_id,
        "role": msg.role,
        "text": text,
        "model": msg.model,
        "created_at": msg.created_at.isoformat(),
    }
    if msg.truncated:
        result["truncated"] = True
    if msg.stop_reason:
        result["stop_reason"] = msg.stop_reason
    if msg.usage:
        result["usage"] = msg.usage
    return result


def _content_contains(query: str):
    return cast(DBMessage.content, SAString).contains(query)


def _handle_list_sessions(input: HistoryInput) -> ToolOutput:
    limit = min(input.limit or 20, MAX_SESSIONS)
    offset = input.offset or 0

    with get_db() as db:
        msg_count_subq = (
            select(
                DBMessage.session_id,
                func.count(DBMessage.id).label("msg_count"),
            )
            .group_by(DBMessage.session_id)
            .subquery()
        )

        query = (
            select(DBSession, msg_count_subq.c.msg_count)
            .outerjoin(msg_count_subq, DBSession.id == msg_count_subq.c.session_id)
            .order_by(DBSession.created_at.desc())
            .limit(limit)
            .offset(offset)
        )

        if input.query:
            matching_session_ids = (
                select(DBMessage.session_id)
                .where(DBMessage.role == "user")
                .where(_content_contains(input.query))
                .distinct()
            )
            query = query.where(DBSession.id.in_(matching_session_ids))

        rows = db.execute(query).all()

        results = []
        for row in rows:
            session = row[0]
            msg_count = row[1] or 0

            preview = None
            first_msg = db.execute(
                select(DBMessage)
                .where(DBMessage.session_id == session.id, DBMessage.role == "user")
                .order_by(DBMessage.created_at)
                .limit(1)
            ).scalar_one_or_none()
            if first_msg:
                text = _extract_text(first_msg.content)
                preview = text[:MAX_CONTENT_PREVIEW] if len(text) > MAX_CONTENT_PREVIEW else text

            results.append(_serialize_session(session, msg_count, preview))

    return ToolOutput(
        content=[{"type": "text", "text": json.dumps(results, indent=2)}],
    )


def _handle_get_messages(input: HistoryInput) -> ToolOutput:
    if not input.session_id:
        return ToolOutput(
            content=[{"type": "text", "text": "Error: 'session_id' is required for get_messages."}],
            is_error=True,
        )

    limit = min(input.limit or 50, MAX_MESSAGES)
    offset = input.offset or 0

    with get_db() as db:
        session = db.execute(
            select(DBSession).where(DBSession.id == input.session_id)
        ).scalar_one_or_none()
        if not session:
            return ToolOutput(
                content=[{"type": "text", "text": f"Error: Session '{input.session_id}' not found."}],
                is_error=True,
            )

        query = (
            select(DBMessage)
            .where(DBMessage.session_id == input.session_id)
            .order_by(DBMessage.created_at)
            .limit(limit)
            .offset(offset)
        )
        if input.role:
            query = query.where(DBMessage.role == input.role)

        msgs = db.execute(query).scalars().all()
        results = [_serialize_message(msg) for msg in msgs]

    return ToolOutput(
        content=[{"type": "text", "text": json.dumps(results, indent=2)}],
    )


def _handle_search_messages(input: HistoryInput) -> ToolOutput:
    if not input.query:
        return ToolOutput(
            content=[{"type": "text", "text": "Error: 'query' is required for search_messages."}],
            is_error=True,
        )

    limit = min(input.limit or 20, MAX_MESSAGES)
    offset = input.offset or 0

    with get_db() as db:
        query = (
            select(DBMessage)
            .where(_content_contains(input.query))
            .order_by(DBMessage.created_at.desc())
            .limit(limit)
            .offset(offset)
        )

        if input.role:
            query = query.where(DBMessage.role == input.role)

        msgs = db.execute(query).scalars().all()
        results = [_serialize_message(msg, truncate=MAX_CONTENT_PREVIEW) for msg in msgs]

    return ToolOutput(
        content=[{"type": "text", "text": json.dumps(results, indent=2)}],
    )


async def run_history(input: HistoryInput, session: Session) -> ToolOutput:
    match input.command:
        case "list_sessions":
            return _handle_list_sessions(input)
        case "get_messages":
            return _handle_get_messages(input)
        case "search_messages":
            return _handle_search_messages(input)


HistoryTool = Tool(
    id="history",
    name="History",
    description="Search and query past conversation sessions and messages.",
    strict=False,
    input=HistoryInput,
    call_tool=run_history,
)
