import asyncio
import logging
from pathlib import Path

from anthropic import APIConnectionError, APIStatusError
from anthropic.types import MessageParam, TextBlockParam
from pydantic import BaseModel, Field
from sqlalchemy import select

from hypergolic.db.engine import get_db
from hypergolic.db.models import DBProject, DBSession
from hypergolic.messages.persistence import load_session_messages
from hypergolic.providers import create_client, tier_to_model_id
from hypergolic.schemas import Session
from hypergolic.tools.schemas import Tool, ToolOutput

logger = logging.getLogger(__name__)

RETRY_BASE_DELAY = 1.0
MAX_RETRIES = 1
SUMMARIZE_PROMPT_PATH = Path(__file__).parent.parent / "prompts" / "summarize_prompt.md"


class SummarizeInput(BaseModel):
    session_id: str | None = Field(
        default=None,
        description="Session ID to summarize. Defaults to the current session.",
    )


def _flatten_messages_for_summary(messages: list[MessageParam]) -> list[MessageParam]:
    """Convert tool_use/tool_result messages into plain text for the summarization model."""
    result: list[MessageParam] = []
    for msg in messages:
        role = msg.get("role", "user")
        content = msg.get("content", [])

        if isinstance(content, str):
            result.append({"role": role, "content": content})
            continue

        text_parts: list[str] = []
        for block in content:
            if not isinstance(block, dict):
                continue
            btype = block.get("type")
            if btype == "text":
                text = block.get("text", "")
                if text.strip():
                    text_parts.append(text)
            elif btype == "tool_use":
                name = block.get("name", "unknown")
                inp = block.get("input", {})
                text_parts.append(f"[Tool call: {name}({inp})]")
            elif btype == "tool_result":
                tool_content = block.get("content", [])
                is_error = block.get("is_error", False)
                prefix = "Tool error" if is_error else "Tool result"
                if isinstance(tool_content, str):
                    text_parts.append(f"[{prefix}: {tool_content}]")
                elif isinstance(tool_content, list):
                    for sub in tool_content:
                        if isinstance(sub, dict) and sub.get("type") == "text":
                            text_parts.append(f"[{prefix}: {sub.get('text', '')}]")

        if text_parts:
            combined = "\n".join(text_parts)
            result.append({"role": role, "content": [{"type": "text", "text": combined}]})

    # Merge consecutive same-role messages
    merged: list[MessageParam] = []
    for msg in result:
        if merged and merged[-1].get("role") == msg.get("role"):
            prev_content = merged[-1].get("content", [])
            curr_content = msg.get("content", [])
            if isinstance(prev_content, str):
                prev_content = [{"type": "text", "text": prev_content}]
            if isinstance(curr_content, str):
                curr_content = [{"type": "text", "text": curr_content}]
            merged[-1] = {"role": msg["role"], "content": list(prev_content) + list(curr_content)}
        else:
            merged.append(msg)

    return merged


def _build_system_prompt(session: Session) -> list[TextBlockParam]:
    blocks: list[TextBlockParam] = []

    if SUMMARIZE_PROMPT_PATH.exists():
        blocks.append({"type": "text", "text": SUMMARIZE_PROMPT_PATH.read_text()})

    user_prompt_path = Path.home() / ".agents" / "SUMMARIZE_PROMPT.md"
    if user_prompt_path.exists():
        blocks.append({
            "type": "text",
            "text": f"# User Summarization Guidance\n\n{user_prompt_path.read_text()}",
        })

    project_path = session.working_directory()
    project_prompt_path = project_path / ".agents" / "SUMMARIZE_PROMPT.md"
    if project_prompt_path.exists():
        blocks.append({
            "type": "text",
            "text": f"# Project Summarization Guidance\n\n{project_prompt_path.read_text()}",
        })

    return blocks


async def _call_summarization_model(
    session: Session,
    messages: list[MessageParam],
) -> str:
    client = create_client()
    model_id = tier_to_model_id(session.model_tier)
    system_prompt = _build_system_prompt(session)

    flat_messages = _flatten_messages_for_summary(messages)
    if not flat_messages:
        raise ValueError("No message content to summarize after flattening.")

    if flat_messages[-1]["role"] == "assistant":
        flat_messages.append({
            "role": "user",
            "content": [{"type": "text", "text": "Please summarize this conversation now."}],
        })

    max_attempts = 1 + MAX_RETRIES
    for attempt in range(max_attempts):
        try:
            response = await client.messages.create(
                max_tokens=8192,
                model=model_id,
                messages=flat_messages,
                system=system_prompt,
            )

            summary_text = ""
            for block in response.content:
                if getattr(block, "type", None) == "text":
                    summary_text += getattr(block, "text", "")

            if not summary_text.strip():
                raise ValueError("Summarization model returned empty response.")

            return summary_text

        except (APIConnectionError, APIStatusError) as exc:
            if attempt < max_attempts - 1:
                delay = RETRY_BASE_DELAY * (2 ** attempt)
                logger.warning(
                    "Summarization attempt %d failed (%s), retrying in %.1fs",
                    attempt + 1, exc, delay,
                )
                await asyncio.sleep(delay)
            else:
                raise

    raise RuntimeError("Unreachable: all summarization attempts exhausted")


async def run_summarize(input: SummarizeInput, session: Session) -> ToolOutput:
    target_id = input.session_id or session.id

    target_session = session
    if target_id != session.id:
        with get_db() as db:
            row = db.execute(
                select(DBSession, DBProject.path)
                .join(DBProject, DBSession.project_id == DBProject.id)
                .where(DBSession.id == target_id)
            ).one()
            db_session, project_path = row
            target_session = Session(
                id=db_session.id,
                model_tier=db_session.model_tier,
                project_id=db_session.project_id,
                project_path=project_path,
                role=db_session.role,
            )

    messages = load_session_messages(target_id)
    if not messages:
        return ToolOutput(
            content=[{"type": "text", "text": "No messages to summarize."}],
            is_error=True,
        )

    try:
        summary = await _call_summarization_model(
            session=target_session,
            messages=messages,
        )
    except Exception as exc:
        return ToolOutput(
            content=[{"type": "text", "text": f"Summarization failed: {exc}"}],
            is_error=True,
        )

    return ToolOutput(
        content=[{"type": "text", "text": summary}],
        is_error=False,
    )


SummarizeTool = Tool(
    id="summarize",
    name="Summarize",
    description="Summarize the current session's conversation history",
    strict=False,
    input=SummarizeInput,
    call_tool=run_summarize,
)
