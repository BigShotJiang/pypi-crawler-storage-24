from pathlib import Path

from anthropic.types.tool_result_block_param import Content
from pydantic import BaseModel, Field

from hypergolic.schemas import Session
from hypergolic.tools.schemas import Tool, ToolOutput


class EditFileEntry(BaseModel):
    path: str = Field(
        description="File path to edit.",
    )
    old_string: str = Field(
        description="Exact string to find. Must appear exactly once.",
    )
    new_string: str = Field(
        description="Replacement string. Empty to delete.",
    )


class EditFilesInput(BaseModel):
    files: list[EditFileEntry] = Field(
        description="Edits to make.",
    )


def _edit_single_file(entry: EditFileEntry, session: Session) -> Content:
    p = Path(entry.path).expanduser()
    if not p.is_absolute():
        p = session.working_directory() / p
    path = p

    if not path.exists():
        return {"type": "text", "text": f"Error: {entry.path} does not exist"}

    if not path.is_file():
        return {"type": "text", "text": f"Error: {entry.path} is not a file"}

    try:
        content = path.read_text(encoding="utf-8")
    except UnicodeDecodeError:
        return {
            "type": "text",
            "text": f"Error reading {entry.path}: File is not valid UTF-8 text",
        }
    except PermissionError:
        return {
            "type": "text",
            "text": f"Error reading {entry.path}: Permission denied",
        }

    occurrences = content.count(entry.old_string)
    if occurrences == 0:
        return {
            "type": "text",
            "text": f"Error: old_string not found in {entry.path}. Make sure it matches exactly, including whitespace and indentation.",
        }
    if occurrences > 1:
        return {
            "type": "text",
            "text": f"Error: old_string appears {occurrences} times in {entry.path}. It must appear exactly once. Include more surrounding context to make the match unique.",
        }

    new_content = content.replace(entry.old_string, entry.new_string, 1)

    try:
        path.write_text(new_content, encoding="utf-8")
        return {"type": "text", "text": f"Edited {entry.path}"}
    except PermissionError:
        return {
            "type": "text",
            "text": f"Error writing {entry.path}: Permission denied",
        }
    except Exception as e:
        return {"type": "text", "text": f"Error writing {entry.path}: {str(e)}"}


async def edit_files(input: EditFilesInput, session: Session) -> ToolOutput:
    if not input.files:
        return ToolOutput(content=[{"type": "text", "text": "No edits provided."}])

    results = [_edit_single_file(entry, session) for entry in input.files]
    has_error = any(
        block.get("text", "").startswith("Error") for block in results if isinstance(block, dict)
    )
    return ToolOutput(content=results, is_error=has_error)


EditFilesTool = Tool(
    id="edit_files",
    name="Edit Files",
    description="Replace exact string matches in files. Each old_string must appear exactly once.",
    strict=True,
    input=EditFilesInput,
    call_tool=edit_files,
)
