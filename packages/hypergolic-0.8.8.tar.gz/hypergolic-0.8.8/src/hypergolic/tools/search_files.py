import subprocess
from pathlib import Path
from typing import Optional

from pydantic import BaseModel, Field

from hypergolic.schemas import Session
from hypergolic.tools.schemas import Tool, ToolOutput


class SearchFilesInput(BaseModel):
    pattern: str = Field(
        description="Search pattern. Regex by default.",
    )
    directory: Optional[str] = Field(
        default=".",
        description="Directory to search within.",
    )
    file_glob: Optional[str] = Field(
        default=None,
        description="Glob pattern to filter files (e.g., '*.py').",
    )
    case_sensitive: bool = Field(
        default=True,
        description="Case-sensitive matching.",
    )
    fixed_string: bool = Field(
        default=False,
        description="Treat pattern as literal string, not regex.",
    )
    include_hidden: bool = Field(
        default=False,
        description="Include hidden files/directories.",
    )
    context_lines: Optional[int] = Field(
        default=0,
        description="Context lines before/after each match.",
    )
    max_results: Optional[int] = Field(
        default=100,
        description="Max matching lines to return.",
    )
    max_depth: Optional[int] = Field(
        default=None,
        description="Max directory depth to search.",
    )
    invert_match: bool = Field(
        default=False,
        description="Return non-matching lines.",
    )
    files_only: bool = Field(
        default=False,
        description="Return only file paths, not matched lines.",
    )
    multiline: bool = Field(
        default=False,
        description="Match across multiple lines.",
    )


async def search_files(input: SearchFilesInput, session: Session) -> ToolOutput:
    cmd = ["rg"]

    # Core search options
    if input.fixed_string:
        cmd.append("--fixed-strings")

    if not input.case_sensitive:
        cmd.append("--ignore-case")

    if input.invert_match:
        cmd.append("--invert-match")

    if input.files_only:
        cmd.append("--files-with-matches")

    if input.multiline:
        cmd.append("--multiline")

    # Scope and filtering
    if input.file_glob:
        cmd.extend(["-g", input.file_glob])

    if input.include_hidden:
        cmd.append("--hidden")

    if input.max_depth is not None:
        cmd.extend(["--max-depth", str(input.max_depth)])

    # Output formatting
    if input.context_lines is not None and input.context_lines > 0 and not input.files_only:
        cmd.extend(["-C", str(input.context_lines)])

    if input.max_results is not None:
        cmd.extend(["--max-count", str(input.max_results)])

    # Always show line numbers and file paths for context
    if not input.files_only:
        cmd.append("--line-number")

    cmd.append("--color=never")

    # The pattern and directory
    cmd.append(input.pattern)
    directory = input.directory or "."
    dir_path = Path(directory).expanduser()
    if not dir_path.is_absolute():
        dir_path = session.working_directory() / dir_path
    cmd.append(str(dir_path))

    try:
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=30,
        )

        # rg returns exit code 1 when no matches are found (not an error)
        if result.returncode == 1 and not result.stderr:
            return ToolOutput(
                content=[{"type": "text", "text": f"No matches found for pattern: {input.pattern}"}],
            )

        if result.returncode > 1 and result.stderr:
            return ToolOutput(
                content=[{"type": "text", "text": f"Search error: {result.stderr.strip()}"}],
                is_error=True,
            )

        output = result.stdout.strip()
        if not output:
            return ToolOutput(
                content=[{"type": "text", "text": f"No matches found for pattern: {input.pattern}"}],
            )

        # Count matches for a helpful summary
        lines = output.split("\n")
        non_context_lines = [line for line in lines if line and not line.startswith("--")]
        match_count = len(non_context_lines)

        summary = f"Found {match_count} matching {'files' if input.files_only else 'lines'}:\n\n"
        return ToolOutput(content=[{"type": "text", "text": summary + output}])

    except subprocess.TimeoutExpired:
        return ToolOutput(
            content=[{"type": "text", "text": "Search timed out after 30 seconds. Try narrowing the search with a more specific pattern, file_glob, or directory."}],
            is_error=True,
        )
    except FileNotFoundError:
        return ToolOutput(
            content=[{"type": "text", "text": "ripgrep (rg) is not installed or not found in PATH. Please install it to use the search tool."}],
            is_error=True,
        )
    except Exception as e:
        return ToolOutput(
            content=[{"type": "text", "text": f"Error during search: {str(e)}"}],
            is_error=True,
        )


SearchFilesTool = Tool(
    id="search_files",
    name="Search Files",
    description="Search file contents with ripgrep. Regex by default.",
    strict=True,
    input=SearchFilesInput,
    call_tool=search_files,
)
