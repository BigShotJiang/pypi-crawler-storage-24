from fastapi import APIRouter, HTTPException
from sqlalchemy import select

from hypergolic.db.engine import get_db
from hypergolic.db.models import DBToolApprovalRule
from hypergolic.tools.approval import (
    RuleAction,
    ConditionOperator,
    ApprovalRule,
    load_all_rules,
    save_rule,
    update_rule_priority,
    delete_rule,
)

from pydantic import BaseModel

router = APIRouter(prefix="/api/tools", tags=["tools"])


class ConditionResponse(BaseModel):
    field: str
    operator: str
    value: str


class ApprovalRuleResponse(BaseModel):
    id: str | None
    tool_name: str
    action: str
    conditions: list[ConditionResponse]
    priority: int
    project_id: str | None
    session_id: str | None
    is_builtin: bool
    created_at: str | None


class ConditionRequest(BaseModel):
    field: str
    operator: str
    value: str


class CreateApprovalRuleRequest(BaseModel):
    tool_name: str
    action: str
    conditions: list[ConditionRequest] = []
    priority: int = 0
    project_id: str | None = None
    session_id: str | None = None


class UpdateRulePriorityRequest(BaseModel):
    priority: int


class ReorderRulesRequest(BaseModel):
    rule_ids: list[str]


def _rule_to_response(rule: ApprovalRule) -> ApprovalRuleResponse:
    return ApprovalRuleResponse(
        id=rule.id,
        tool_name=rule.tool_name,
        action=rule.action.value,
        conditions=[
            ConditionResponse(field=c.field, operator=c.operator.value, value=c.value)
            for c in rule.conditions
        ],
        priority=rule.priority,
        project_id=rule.project_id,
        session_id=rule.session_id,
        is_builtin=rule.is_builtin,
        created_at=None,
    )


def _db_rule_to_response(row: DBToolApprovalRule) -> ApprovalRuleResponse:
    return ApprovalRuleResponse(
        id=row.id,
        tool_name=row.tool_name,
        action=row.action,
        conditions=[
            ConditionResponse(field=c["field"], operator=c["operator"], value=c["value"])
            for c in (row.conditions or [])
        ],
        priority=row.priority,
        project_id=row.project_id,
        session_id=row.session_id,
        is_builtin=False,
        created_at=row.created_at.isoformat(),
    )


@router.get("/approval-rules", response_model=list[ApprovalRuleResponse])
def list_approval_rules(tool_name: str | None = None, include_builtin: bool = True):
    all_rules = load_all_rules()
    if tool_name:
        all_rules = [r for r in all_rules if r.tool_name == tool_name or r.tool_name == "*"]
    if not include_builtin:
        all_rules = [r for r in all_rules if not r.is_builtin]
    return [_rule_to_response(r) for r in all_rules]


@router.post("/approval-rules", response_model=ApprovalRuleResponse)
def create_approval_rule(req: CreateApprovalRuleRequest):
    try:
        action = RuleAction(req.action)
    except ValueError:
        raise HTTPException(status_code=400, detail=f"Invalid action: {req.action}")

    for cond in req.conditions:
        try:
            ConditionOperator(cond.operator)
        except ValueError:
            raise HTTPException(status_code=400, detail=f"Invalid operator: {cond.operator}")

    conditions = [{"field": c.field, "operator": c.operator, "value": c.value} for c in req.conditions]
    row = save_rule(
        tool_name=req.tool_name,
        action=action,
        conditions=conditions,
        priority=req.priority,
        project_id=req.project_id,
        session_id=req.session_id,
    )
    return _db_rule_to_response(row)


@router.put("/approval-rules/{rule_id}/priority", response_model=ApprovalRuleResponse)
def update_approval_rule_priority(rule_id: str, req: UpdateRulePriorityRequest):
    update_rule_priority(rule_id, req.priority)
    with get_db() as db:
        row = db.execute(
            select(DBToolApprovalRule).where(DBToolApprovalRule.id == rule_id)
        ).scalar_one_or_none()
        if not row:
            raise HTTPException(status_code=404, detail="Rule not found")
        return _db_rule_to_response(row)


@router.post("/approval-rules/reorder")
def reorder_approval_rules(req: ReorderRulesRequest):
    with get_db() as db:
        for i, rule_id in enumerate(req.rule_ids):
            row = db.execute(
                select(DBToolApprovalRule).where(DBToolApprovalRule.id == rule_id)
            ).scalar_one_or_none()
            if row:
                row.priority = len(req.rule_ids) - i
    return {"status": "reordered"}


@router.delete("/approval-rules/{rule_id}")
def delete_approval_rule(rule_id: str):
    delete_rule(rule_id)
    return {"status": "deleted"}
