from pathlib import Path

from pydantic import BaseModel, Field

from hypergolic.schemas import Session
from hypergolic.tools.schemas import Tool, ToolOutput


class ReadFilesInput(BaseModel):
    paths: list[str] = Field(
        description="File paths to read.",
    )


def _resolve_path(file_path: str, session: Session) -> Path:
    p = Path(file_path).expanduser()
    if not p.is_absolute():
        p = session.working_directory() / p
    return p


async def read_files(input: ReadFilesInput, session: Session) -> ToolOutput:
    results = []
    has_error = False

    for file_path in input.paths:
        path = _resolve_path(file_path, session)

        if not path.exists():
            results.append(
                {"type": "text", "text": f"Error reading {file_path}: File not found"}
            )
            has_error = True
            continue

        if not path.is_file():
            results.append(
                {"type": "text", "text": f"Error reading {file_path}: Not a file"}
            )
            has_error = True
            continue

        try:
            content = path.read_text(encoding="utf-8")
            results.append({"type": "text", "text": f"=== {file_path} ===\n{content}"})
        except UnicodeDecodeError:
            results.append(
                {
                    "type": "text",
                    "text": f"Error reading {file_path}: File is not valid UTF-8 text",
                }
            )
            has_error = True
        except PermissionError:
            results.append(
                {
                    "type": "text",
                    "text": f"Error reading {file_path}: Permission denied",
                }
            )
            has_error = True
        except Exception as e:
            results.append(
                {"type": "text", "text": f"Error reading {file_path}: {str(e)}"}
            )
            has_error = True

    if not results:
        return ToolOutput(content=[{"type": "text", "text": "No files provided to read."}])

    return ToolOutput(content=results, is_error=has_error)


ReadFilesTool = Tool(
    id="read_files",
    name="Read Files",
    description="Read the contents of one or more files.",
    strict=True,
    input=ReadFilesInput,
    call_tool=read_files,
)
