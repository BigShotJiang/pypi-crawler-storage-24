import logging
import platform
import subprocess
from dataclasses import dataclass
from pathlib import Path

from anthropic.types import TextBlockParam

from hypergolic.config.settings import load_user_project_config
from hypergolic.schemas import Session
from hypergolic.skills.resolver import get_active_skill_prompts, resolve_roles

logger = logging.getLogger(__name__)


@dataclass
class PromptBlock:
    source: str
    text: str

    def to_text_block(self) -> TextBlockParam:
        return {"type": "text", "text": self.text}


def _git_branch(cwd: Path) -> str | None:
    try:
        result = subprocess.run(
            ["git", "rev-parse", "--abbrev-ref", "HEAD"],
            capture_output=True,
            text=True,
            check=True,
            cwd=cwd,
        )
        return result.stdout.strip() or None
    except (subprocess.CalledProcessError, FileNotFoundError):
        return None




def _build_session_context(session: Session) -> str:
    project_path = session.working_directory()
    lines = [
        "# Session Context",
        "",
        f"- **Session ID:** `{session.id}`",
        f"- **Working Directory:** `{project_path}`",
        f"- **OS:** {platform.system()} {platform.release()} ({platform.machine()})",
    ]

    branch = _git_branch(project_path)
    if branch:
        lines.append(f"- **Git Branch:** `{branch}`")

    config_paths = _get_config_paths(project_path)
    if config_paths:
        lines.append("- **Config Files** (read these with file tools when you need config details):")
        for label, path in config_paths:
            lines.append(f"  - {label}: `{path}`")

    return "\n".join(lines) + "\n"


def _get_config_paths(project_path: Path) -> list[tuple[str, str]]:
    paths: list[tuple[str, str]] = []

    user_config_path = Path.home() / ".agents" / "config.json"
    if user_config_path.exists():
        paths.append(("User config", str(user_config_path)))

    project_config_path = project_path / ".agents" / "config.json"
    if project_config_path.exists():
        paths.append(("Project config", str(project_config_path)))

    user_project_config = load_user_project_config(project_path)
    if user_project_config and user_project_config.prompt_path:
        user_project_prompt = Path(user_project_config.prompt_path).expanduser()
        if user_project_prompt.exists():
            paths.append(("User-project prompt", str(user_project_prompt)))

    return paths



def _get_role_prompt_path(session: Session) -> Path:
    roles = resolve_roles(session.working_directory())
    for role in roles:
        if role["id"] == session.role:
            return Path(role["prompt_path"])
    return Path(__file__).parent / "base_prompt.md"


def build_prompt_blocks(session: Session) -> list[PromptBlock]:
    blocks: list[PromptBlock] = []
    project_path = session.working_directory()

    role_prompt_path = _get_role_prompt_path(session)
    if role_prompt_path.exists():
        source = "Base prompt" if session.role == "default" else f"Role prompt ({session.role})"
        blocks.append(PromptBlock(source=source, text=role_prompt_path.read_text()))

    user_prompt_path = Path.home() / ".agents" / "PROMPT.md"
    if user_prompt_path.exists():
        blocks.append(PromptBlock(source="User preferences", text=user_prompt_path.read_text()))

    project_prompt_path = project_path / ".agents" / "PROMPT.md"
    if project_prompt_path.exists():
        blocks.append(PromptBlock(source="Project guidance", text=project_prompt_path.read_text()))

    upc = load_user_project_config(project_path)
    if upc and upc.prompt_path:
        user_project_prompt_path = Path(upc.prompt_path).expanduser()
        if user_project_prompt_path.exists():
            blocks.append(PromptBlock(
                source="User-project guidance",
                text=user_project_prompt_path.read_text(),
            ))

    blocks.append(PromptBlock(source="Session context", text=_build_session_context(session)))

    active_skills = get_active_skill_prompts(session.id, project_path)
    for skill_name, skill_content in active_skills:
        blocks.append(PromptBlock(
            source=f"Skill: {skill_name}",
            text=f"# Skill: {skill_name}\n\n{skill_content}",
        ))

    return blocks


def build_session_prompt(session: Session) -> list[TextBlockParam]:
    return [block.to_text_block() for block in build_prompt_blocks(session)]
