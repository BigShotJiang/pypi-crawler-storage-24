from anthropic import AsyncAnthropic
from anthropic.types import ModelParam

from hypergolic.config.settings import settings
from hypergolic.enums import ModelTier


def create_client():
    return AsyncAnthropic(
        api_key=settings.HYPERGOLIC_API_KEY,
        base_url=settings.HYPERGOLIC_BASE_URL,
    )


def tier_to_model_id(tier: ModelTier) -> ModelParam:
    match tier:
        case ModelTier.LOW:
            return "claude-haiku-4-5"
        case ModelTier.MEDIUM:
            return "claude-sonnet-4-6"
        case ModelTier.HIGH:
            return "claude-opus-4-6"
