from typing import Any, Literal

from pydantic import BaseModel, Field

from hypergolic.enums import ModelTier


class ConnectMessage(BaseModel):
    type: Literal["chat"] = "chat"
    message: str = Field(..., min_length=1)
    model_tier: ModelTier = Field(default=ModelTier.HIGH)
    session_id: str | None = None
    project_id: str | None = None
    content_blocks: list[dict[str, Any]] | None = None


class ApprovalResponseMessage(BaseModel):
    type: Literal["tool_approval_response"] = "tool_approval_response"
    tool_use_id: str
    approved: bool
    denial_reason: str | None = None


class UserQuestionResponseMessage(BaseModel):
    type: Literal["user_question_response"] = "user_question_response"
    tool_use_id: str
    response: str


WsClientMessage = ConnectMessage | ApprovalResponseMessage | UserQuestionResponseMessage


def parse_client_message(raw: dict[str, Any]) -> WsClientMessage:
    msg_type = raw.get("type", "chat")
    if msg_type == "tool_approval_response":
        return ApprovalResponseMessage.model_validate(raw)
    if msg_type == "user_question_response":
        return UserQuestionResponseMessage.model_validate(raw)
    return ConnectMessage.model_validate(raw)
