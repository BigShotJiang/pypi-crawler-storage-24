# Tools

Hypergolic gives the assistant access to a set of tools it can invoke during conversation. The assistant decides which tools to use based on the task.

## Built-in Tools

| Tool | Description | Requires Approval |
|------|-------------|-------------------|
| `read_files` | Read contents of one or more files | No |
| `write_files` | Create or overwrite files | Yes |
| `edit_files` | Find-and-replace exact strings in files | Yes |
| `delete_files` | Delete files by path | Yes |
| `list_files` | List directory contents with glob filtering | No |
| `search_files` | Ripgrep-powered search across files (regex or literal) | No |
| `make_directory` | Create directories | No |
| `command` | Execute a shell command | Yes |
| `git` | Git operations (status, diff, log, show, branch, checkout, etc.) | Read-only: No; Mutating: Yes |
| `browser` | Control a headless Chrome browser via [rodney](https://github.com/nichochar/rodney) | Varies |
| `knowledge` | Create, search, delete, tag, and link knowledge graph items | No |
| `history` | Search and query past sessions and messages | No |
| `summarize` | Summarize the current session's conversation | No |
| `ask_user` | Ask the user a question and wait for their response | No |
| `skills` | Activate a specialized skill for the session | No |
| `manage_mcp` | List, enable, or disable MCP servers | No |
| `validate` | Run the project's full validation suite (if configured) | Yes |
| `bump-version` | Bump the project version across config files (if configured) | Yes |

## How Tool Approval Works

Tools that modify your filesystem or execute arbitrary commands require explicit approval. When the assistant wants to use one, you'll see an approval prompt with the full details of what it wants to do.

You can:
- **Approve** (`Y`) — Let the tool run
- **Deny** (`N`) — Block the tool silently
- **Deny with message** (`D`) — Block and explain why
- **Configure** (`C`) — Set up an auto-approval rule for similar calls

### Auto-Approval Rules

You can configure rules to automatically approve certain tool calls without prompting. Rules match on tool name and optionally on command patterns. This is useful for commands you trust, like `ruff check` or `pnpm test`.

## Custom Tools

You can define your own tools that wrap shell commands. See [Advanced Usage](advanced-usage.md#custom-tools).

## MCP Tools

Tools from connected MCP servers appear alongside built-in tools. See [Advanced Usage](advanced-usage.md#mcp-servers).
