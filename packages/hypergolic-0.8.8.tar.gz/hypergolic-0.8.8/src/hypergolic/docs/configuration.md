# Configuration

Hypergolic uses a layered configuration system. Settings come from JSON config files and Markdown prompt files at two levels: **user** and **project**.

## File Locations

| Path | Scope | Purpose |
|------|-------|---------|
| `~/.agents/config.json` | User | Database path, MCP servers, custom tools, skills, roles, projects |
| `~/.agents/PROMPT.md` | User | Personal preferences and global instructions |
| `<repo>/.agents/config.json` | Project | Project name, MCP servers, custom tools, skills, roles |
| `<repo>/.agents/PROMPT.md` | Project | Project-specific guidance |

## User Config

The user config at `~/.agents/config.json` is the primary configuration file. All fields are optional.

```json
{
  "db_path": "~/.agents/hypergolicV4.db",
  "prompt_path": "~/.agents/PROMPT.md",
  "mcp_servers": {},
  "tools": [],
  "skills": [],
  "roles": [],
  "projects": []
}
```

| Field | Type | Default | Description |
|-------|------|---------|-------------|
| `db_path` | string | `~/.agents/hypergolicV4.db` | Path to the SQLite database |
| `prompt_path` | string | `~/.agents/PROMPT.md` | Path to user-level system prompt |
| `mcp_servers` | object | `{}` | MCP server configurations (see [Advanced Usage](advanced-usage.md)) |
| `tools` | array | `[]` | Custom tool definitions (see [Advanced Usage](advanced-usage.md)) |
| `skills` | array | `[]` | Custom skill definitions |
| `roles` | array | `[]` | Custom role definitions |
| `projects` | array | `[]` | Per-project overrides |

## Project Config

The project config at `<repo>/.agents/config.json` applies only when working in that repository. It supports the same `mcp_servers`, `tools`, `skills`, and `roles` fields as the user config.

```json
{
  "name": "My Project",
  "mcp_servers": {},
  "tools": [],
  "skills": [],
  "roles": []
}
```

## Per-Project User Config

You can define project-specific settings in your user config that you don't want to commit to the repo. Add entries to the `projects` array:

```json
{
  "projects": [
    {
      "git_root": "~/Projects/my-project",
      "name": "My Project",
      "prompt_path": "~/.agents/projects/my-project.md",
      "mcp_servers": {},
      "tools": [],
      "skills": []
    }
  ]
}
```

The `prompt_path` here lets you inject project-specific instructions without putting them in the repo's `.agents/PROMPT.md`.

## System Prompt Assembly

The system prompt is assembled from multiple sources, concatenated in order:

1. **Role prompt** — The active role's prompt file. Defaults to the built-in base prompt.
2. **User prompt** — `~/.agents/PROMPT.md`. Personal preferences and background.
3. **Project prompt** — `<repo>/.agents/PROMPT.md`. Project-specific guidance.
4. **User-project prompt** — From `projects[].prompt_path` in user config. Per-project guidance you don't commit.
5. **Session context** — Auto-generated: session ID, working directory, OS, git branch.
6. **Active skills** — Prompt content from any skills activated during the session.

### Example User Prompt (`~/.agents/PROMPT.md`)

```markdown
# User Preferences

I prefer uv over poetry for Python projects.
Always use pnpm, never npm or yarn.
I work primarily in Python and TypeScript.
```

### Example Project Prompt (`<repo>/.agents/PROMPT.md`)

```markdown
# Project Guidance

This is a Django 5.1 project using PostgreSQL.
Run `./bin/validate` after making changes to verify the build.
Never modify files in the `generated/` directory.
```

## Viewing Config

From the CLI:

```bash
h config
```

This displays your current version, database path, MCP servers, custom tools, skills, roles, and projects.

From the UI, use the **Config** panel in the left sidebar (`⌘/Ctrl + 7`).
