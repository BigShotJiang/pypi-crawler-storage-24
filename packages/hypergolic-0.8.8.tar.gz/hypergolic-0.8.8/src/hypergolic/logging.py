import logging
from logging.handlers import RotatingFileHandler
from pathlib import Path

ERROR_LOG_PATH = Path.home() / ".hypergolic" / "errors.log"
MAX_LOG_BYTES = 5 * 1024 * 1024  # 5 MB
BACKUP_COUNT = 3

_initialized = False


def setup_error_logging() -> None:
    global _initialized
    if _initialized:
        return
    _initialized = True

    ERROR_LOG_PATH.parent.mkdir(parents=True, exist_ok=True)

    file_handler = RotatingFileHandler(
        ERROR_LOG_PATH,
        maxBytes=MAX_LOG_BYTES,
        backupCount=BACKUP_COUNT,
    )
    file_handler.setLevel(logging.WARNING)
    file_handler.setFormatter(
        logging.Formatter("%(asctime)s [%(levelname)s] %(name)s: %(message)s")
    )

    root_logger = logging.getLogger("hypergolic")
    root_logger.addHandler(file_handler)
    root_logger.setLevel(logging.DEBUG)
