from enum import Enum


class ModelTier(str, Enum):
    LOW = "Low"
    MEDIUM = "Medium"
    HIGH = "High"


class SessionStatus(str, Enum):
    IDLE = "idle"
    THINKING = "thinking"
    STREAMING = "streaming"
    TOOL_USE = "tool_use"
    AWAITING_APPROVAL = "awaiting_approval"
    AWAITING_USER = "awaiting_user"
    ERROR = "error"


class KnowledgeScope(str, Enum):
    UNIVERSAL = "universal"
    USER = "user"
    PROJECT = "project"
    SESSION = "session"


class KnowledgeRelationType(str, Enum):
    RELATES_TO = "relates_to"
    DEPENDS_ON = "depends_on"
    CONTRADICTS = "contradicts"
    SUPERSEDES = "supersedes"
    REFINES = "refines"
    EXAMPLE_OF = "example_of"
