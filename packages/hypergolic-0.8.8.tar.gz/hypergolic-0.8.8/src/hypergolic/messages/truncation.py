import logging

from anthropic.types import MessageParam, TextBlockParam
from sqlalchemy import select, update

from hypergolic.db.engine import get_db
from hypergolic.db.models import DBMessage
from hypergolic.messages.persistence import load_session_messages, persist_user_message
from hypergolic.schemas import Session
from hypergolic.tools.summarize import _call_summarization_model

logger = logging.getLogger(__name__)

TRUNCATE_TOKEN_THRESHOLD = 100_000


def should_truncate(session_id: str) -> bool:
    with get_db() as db:
        row = db.execute(
            select(DBMessage)
            .where(DBMessage.session_id == session_id)
            .where(DBMessage.truncated == False)  # noqa: E712
            .where(DBMessage.role == "assistant")
            .order_by(DBMessage.created_at.desc())
            .limit(1)
        ).scalar_one_or_none()

        if row is None or row.usage is None:
            return False

        input_tokens = (
            row.usage.get("input_tokens", 0)
            + row.usage.get("cache_read_input_tokens", 0)
            + row.usage.get("cache_creation_input_tokens", 0)
        )
        return input_tokens > TRUNCATE_TOKEN_THRESHOLD


async def truncate_conversation(session: Session) -> None:
    logger.info("Truncating conversation for session %s", session.id)

    messages = load_session_messages(session.id)
    if not messages:
        return

    summary = await _call_summarization_model(session=session, messages=messages)

    summary_message = MessageParam(
        role="user",
        content=[
            TextBlockParam(
                type="text",
                text=f"[Conversation Summary]\n\n{summary}",
            )
        ],
    )
    await persist_user_message(session_id=session.id, message=summary_message)

    with get_db() as db:
        latest = db.execute(
            select(DBMessage.id)
            .where(DBMessage.session_id == session.id)
            .where(DBMessage.truncated == False)  # noqa: E712
            .order_by(DBMessage.created_at.desc())
            .limit(1)
        ).scalar_one()

        db.execute(
            update(DBMessage)
            .where(DBMessage.session_id == session.id)
            .where(DBMessage.truncated == False)  # noqa: E712
            .where(DBMessage.id != latest)
            .values(truncated=True)
        )

    logger.info("Conversation truncated for session %s", session.id)
