import asyncio
import logging
from typing import Any

from anthropic import AsyncAnthropic, APIConnectionError, APIStatusError
from anthropic.types import (
    Message,
    MessageParam,
    RawContentBlockStartEvent,
    StopReason,
    TextBlockParam,
    ToolResultBlockParam,
    ToolUseBlock,
)

from hypergolic.db.engine import get_db
from hypergolic.db.models import DBMessage
from hypergolic.messages.caching import set_message_cache_breakpoint
from hypergolic.messages.persistence import (
    load_session_messages,
    persist_agent_message,
    persist_user_message,
)
from hypergolic.messages.truncation import should_truncate, truncate_conversation
from hypergolic.messages.streaming import handle_streaming_event
from hypergolic.messages.types import (
    INTERRUPTED_SUFFIX,
    MAX_STREAM_RETRIES,
    RETRY_BASE_DELAY,
    BroadcastEvent,
    BroadcastFn,
    UserInterrupt,
)
from hypergolic.enums import SessionStatus
from hypergolic.prompts.builder import build_session_prompt
from hypergolic.providers import tier_to_model_id
from hypergolic.schemas import Session
from hypergolic.sessions.status import set_session_status_and_broadcast
from hypergolic.tools.handlers import (
    ApprovalCallback,
    UserQuestionCallback,
    handle_tool_use,
)
from hypergolic.tools.tool_list import (
    build_tools,
    get_tool_schemas,
    set_tools_cache_breakpoint,
)

logger = logging.getLogger(__name__)

RETRYABLE_EXCEPTIONS = (APIConnectionError,)


def _is_retryable_status(exc: APIStatusError) -> bool:
    return exc.status_code in (429, 500, 502, 503, 529)


def _extract_partial_text(stream: Any) -> str | None:
    try:
        snapshot = stream.current_message_snapshot
    except Exception:
        return None
    if not snapshot or not snapshot.content:
        return None
    text_parts = [
        block.text
        for block in snapshot.content
        if getattr(block, "type", None) == "text" and getattr(block, "text", None)
    ]
    return "\n\n".join(text_parts) if text_parts else None


async def _persist_partial_assistant_message(session_id: str, text: str) -> None:
    with get_db() as db:
        db_message = DBMessage(
            session_id=session_id,
            content=[{"type": "text", "text": text + INTERRUPTED_SUFFIX}],
            model=None,
            role="assistant",
            stop_reason="interrupted",
            stop_sequence=None,
            usage=None,
        )
        db.add(db_message)


def _build_interrupt_tool_results(response: Message) -> MessageParam | None:
    tool_blocks = [b for b in response.content if isinstance(b, ToolUseBlock)]
    if not tool_blocks:
        return None
    result_blocks: list[ToolResultBlockParam] = [
        ToolResultBlockParam(
            tool_use_id=b.id,
            type="tool_result",
            content=[TextBlockParam(type="text", text="Interrupted by user")],
            is_error=True,
        )
        for b in tool_blocks
    ]
    return MessageParam(role="user", content=result_blocks)


async def _persist_interrupt_tool_results(session_id: str, response: Message) -> None:
    interrupt_result = _build_interrupt_tool_results(response)
    if interrupt_result:
        await persist_user_message(session_id=session_id, message=interrupt_result)


async def create_message(
    client: AsyncAnthropic,
    session: Session,
    message: MessageParam,
    broadcast: BroadcastFn,
    cancel_event: asyncio.Event | None = None,
    approval_callback: ApprovalCallback | None = None,
    user_question_callback: UserQuestionCallback | None = None,
) -> Message:
    response: Message | None = None
    stop_reason: StopReason | None = None

    prompt = list(build_session_prompt(session))
    tools = build_tools(session=session)
    tool_schemas = set_tools_cache_breakpoint(get_tool_schemas(tools))

    await persist_user_message(session_id=session.id, message=message)

    if should_truncate(session.id):
        await truncate_conversation(session)

    def _check_cancelled() -> None:
        if cancel_event and cancel_event.is_set():
            raise UserInterrupt()

    while stop_reason != "end_turn":
        _check_cancelled()

        await set_session_status_and_broadcast(
            session.id, SessionStatus.THINKING, broadcast
        )

        messages = load_session_messages(session.id)
        cached_messages = set_message_cache_breakpoint(messages)

        streaming_started = False
        last_stream_error: Exception | None = None
        for attempt in range(MAX_STREAM_RETRIES + 1):
            try:
                async with client.messages.stream(
                    max_tokens=8192,
                    model=tier_to_model_id(session.model_tier),
                    messages=cached_messages,
                    system=prompt,
                    tools=tool_schemas,
                ) as stream:
                    async for event in stream:
                        _check_cancelled()
                        if not streaming_started and isinstance(
                            event, RawContentBlockStartEvent
                        ):
                            streaming_started = True
                            await set_session_status_and_broadcast(
                                session.id, SessionStatus.STREAMING, broadcast
                            )
                        await handle_streaming_event(event, broadcast, session.id)
                    response = await stream.get_final_message()
                last_stream_error = None
                break
            except UserInterrupt:
                partial_text = _extract_partial_text(stream)
                if partial_text:
                    await _persist_partial_assistant_message(
                        session_id=session.id, text=partial_text
                    )
                raise UserInterrupt(partial_text=partial_text)
            except RETRYABLE_EXCEPTIONS as exc:
                last_stream_error = exc
                if attempt < MAX_STREAM_RETRIES:
                    delay = RETRY_BASE_DELAY * (2**attempt)
                    logger.warning(
                        "Stream attempt %d failed (%s), retrying in %.1fs",
                        attempt + 1,
                        exc,
                        delay,
                    )
                    await asyncio.sleep(delay)
                    continue
            except APIStatusError as exc:
                if _is_retryable_status(exc) and attempt < MAX_STREAM_RETRIES:
                    last_stream_error = exc
                    delay = RETRY_BASE_DELAY * (2**attempt)
                    logger.warning(
                        "Stream attempt %d failed (HTTP %d), retrying in %.1fs",
                        attempt + 1,
                        exc.status_code,
                        delay,
                    )
                    await asyncio.sleep(delay)
                    continue
                raise

        if last_stream_error is not None:
            raise last_stream_error

        assert response is not None
        stop_reason = response.stop_reason
        await persist_agent_message(session_id=session.id, message=response)

        try:
            await broadcast(
                BroadcastEvent(
                    type="assistant_message",
                    role="assistant",
                    content=response.content,
                    session_id=session.id,
                    model=response.model,
                    stop_reason=response.stop_reason,
                    message_id=response.id,
                    usage=(
                        response.usage.model_dump(mode="json")
                        if response.usage
                        else None
                    ),
                )
            )

            match stop_reason:
                case "end_turn":
                    pass
                case "tool_use":
                    _check_cancelled()
                    await set_session_status_and_broadcast(
                        session.id, SessionStatus.TOOL_USE, broadcast
                    )
                    tool_use_result = await handle_tool_use(
                        agent_message=response,
                        tools=tools,
                        session=session,
                        approval_callback=approval_callback,
                        user_question_callback=user_question_callback,
                    )
                    _check_cancelled()

                    await persist_user_message(
                        session_id=session.id, message=tool_use_result.message
                    )
                    await broadcast(
                        BroadcastEvent(
                            type="tool_result",
                            role="user",
                            content=tool_use_result.message.get("content", []),
                            session_id=session.id,
                        )
                    )
                case _:
                    raise Exception(f"Unhandled stop reason: {stop_reason}")
        except UserInterrupt, asyncio.CancelledError:
            if stop_reason == "tool_use":
                await _persist_interrupt_tool_results(session.id, response)
            raise UserInterrupt()

    if not response:
        raise Exception("Turn ended without response")
    return response
