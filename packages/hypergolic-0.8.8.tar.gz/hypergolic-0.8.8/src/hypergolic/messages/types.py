from dataclasses import dataclass
from typing import Any, Awaitable, Callable


MAX_STREAM_RETRIES = 2
RETRY_BASE_DELAY = 1.0

EXCLUDED_CONTENT_FIELDS = {"parsed_output", "caller"}
EXCLUDED_FIELDS = {"parsed_output", "caller"}

INTERRUPTED_SUFFIX = "\n\n---\n*[Response interrupted by user]*"


class UserInterrupt(Exception):
    def __init__(self, partial_text: str | None = None):
        super().__init__()
        self.partial_text = partial_text


@dataclass
class BroadcastEvent:
    type: str
    role: str
    content: Any
    session_id: str | None = None
    model: str | None = None
    stop_reason: str | None = None
    message_id: str | None = None
    usage: dict | None = None


BroadcastFn = Callable[[BroadcastEvent], Awaitable[None]]
