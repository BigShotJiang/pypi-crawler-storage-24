from typing import Any, Literal, cast

from anthropic.types import Message, MessageParam
from pydantic import BaseModel
from sqlalchemy import select

from hypergolic.db.engine import get_db
from hypergolic.db.models import DBMessage
from hypergolic.messages.types import EXCLUDED_CONTENT_FIELDS, EXCLUDED_FIELDS


def strip_excluded_fields(content: list[Any]) -> list[Any]:
    cleaned = []
    for block in content:
        if isinstance(block, dict):
            cleaned.append(
                {k: v for k, v in block.items() if k not in EXCLUDED_CONTENT_FIELDS}
            )
        else:
            cleaned.append(block)
    return cleaned


def load_session_messages(session_id: str) -> list[MessageParam]:
    with get_db() as db:
        rows = (
            db.execute(
                select(DBMessage)
                .where(DBMessage.session_id == session_id)
                .where(DBMessage.truncated == False)  # noqa: E712
                .order_by(DBMessage.created_at)
            )
            .scalars()
            .all()
        )
        return [
            MessageParam(
                role=cast(Literal["user", "assistant"], row.role),
                content=strip_excluded_fields(row.content),
            )
            for row in rows
        ]


async def persist_agent_message(session_id: str, message: Message):
    content = []
    for block in message.content:
        if isinstance(block, BaseModel):
            content.append(block.model_dump(mode="json", exclude=EXCLUDED_FIELDS))
        else:
            content.append(block)

    usage = message.usage.model_dump(mode="json") if message.usage else None

    with get_db() as db:
        db_message = DBMessage(
            id=message.id,
            session_id=session_id,
            content=content,
            model=message.model,
            role=message.role,
            stop_reason=message.stop_reason,
            stop_sequence=message.stop_sequence,
            usage=usage,
        )
        db.add(db_message)


async def persist_user_message(session_id: str, message: MessageParam):
    content = message.get("content", [])

    if isinstance(content, str):
        content = [{"type": "text", "text": content}]
    else:
        normalized_content = []
        for block in content:
            if isinstance(block, BaseModel):
                normalized_content.append(block.model_dump(mode="json"))
            else:
                normalized_content.append(block)
        content = normalized_content

    with get_db() as db:
        db_message = DBMessage(
            session_id=session_id,
            content=content,
            model=None,
            role=message.get("role", "user"),
            stop_reason=None,
            stop_sequence=None,
            usage=None,
        )
        db.add(db_message)


def parse_agent_message(message: Message) -> MessageParam:
    content = []
    for c in message.content:
        if isinstance(c, BaseModel):
            content.append(c.model_dump(mode="json", exclude=EXCLUDED_FIELDS))
        else:
            content.append(c)
    return {
        "content": content,
        "role": "assistant",
    }
