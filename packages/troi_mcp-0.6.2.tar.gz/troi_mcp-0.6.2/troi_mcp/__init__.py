"""Troi MCP Server - connects Claude Desktop to Troi project management."""

__version__ = "0.6.2"
