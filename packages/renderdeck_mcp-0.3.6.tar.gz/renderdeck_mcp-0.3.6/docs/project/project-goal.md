# Project Goal — RenderDeck MCP Server

[Addresses: PRD v1.0 — docs/renderdeck_mcp_server_prd.md]

## Vision

Wrap RenderDeck as an MCP server that enables any MCP-compatible LLM to learn the slide prompt format, submit prompt files, and receive finished `.pptx` presentations — with cache-based incremental updates for iterative workflows.

## Success Criteria

| ID | Category | Description | Verification | Priority |
|----|----------|-------------|--------------|----------|
| G-1 | Functional | MCP server parses slide prompt files matching `renderdeck.py` §4.1 rules | Gartner fixture parsed correctly; content hashes match `renderdeck.py` output | Must Have |
| G-2 | Functional | `generate_deck` produces `.pptx` with background images + speaker notes for all slides | 15-slide deck → `.pptx` with all slides, images, notes; opens in PowerPoint/LibreOffice | Must Have |
| G-3 | Functional | Cache-based incremental updates: unchanged slides reuse cached images | Resubmit same prompt → 0 Gemini calls; change 2 slides → only 2 regenerated | Must Have |
| G-4 | Functional | Concurrent image generation with configurable parallelism (default: 3) | 15-slide deck generates images via 3 concurrent Gemini calls | Must Have |
| G-5 | Functional | `renderdeck://reference` resource enables LLM to produce valid prompt files | LLM given only the resource produces a prompt file passing `validate_prompt_file` with 0 errors | Must Have |
| G-6 | Functional | Setup tools (`setup_gemini_key`, `get_setup_status`, `update_settings`) enable LLM-guided config | No config → `ready: false` with guidance; valid key → encrypted → `ready: true` | Must Have |
| G-7 | Quality | Format validation reports all errors with line numbers (not fail-on-first) | Malformed file with 3 errors → all 3 reported with line numbers | Must Have |
| G-8 | Quality | Partial failure resilience: image error → text-only fallback, other slides unaffected | Slide 7 fails → text-only fallback, slides 1-6 and 8+ have images, `.pptx` produced | Must Have |
| G-9 | Performance | 15-slide deck completes in reasonable time with concurrent generation | Timed end-to-end run; target aspirational (depends on Gemini API latency) | Nice to Have |
| G-10 | Performance | Warm cache resubmit (2 changed slides): < 30s | Timed resubmit with 2 modified slides | Should Have |
| G-11 | Operational | Standalone Python package installable via `pip install` or `uvx` | `uvx renderdeck-mcp serve` starts server; MCP Inspector connects | Must Have |
| G-12 | Operational | stdio transport compatible with Claude Desktop, Claude Code, Cursor | MCP config examples work on macOS | Must Have |
| G-13 | Security | Gemini API key encrypted at rest in `~/.renderdeck/config.json` | Key not stored in plaintext; Fernet encryption verified | Must Have |

## Cross-Reference Protocol

Every downstream artifact (epics, designs, tests, implementations) must reference which goal(s) it addresses using the format: `[Addresses: G-1, G-3]` in artifact headers.

## Sources

- PRD: `docs/renderdeck_mcp_server_prd.md` §8 (FR-001–FR-018), §9 (NFR-001–NFR-008), §14 (Success Metrics)
- Existing script spec: `docs/RenderDeck_Script_Spec_v1.0.md`
