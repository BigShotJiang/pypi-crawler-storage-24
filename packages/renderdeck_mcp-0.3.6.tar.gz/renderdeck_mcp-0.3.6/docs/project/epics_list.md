# Project Epics — RenderDeck MCP Server

[Source: docs/renderdeck_mcp_server_prd.md §10]

1. **Epic-1: Parser and Validation Module**
   - Goal: Extract and adapt the slide prompt file parser from `renderdeck.py` into a testable, importable module with line-number validation.
   - Addresses: G-1, G-7
   - Scope: Parser extraction, validation with collected errors, content hash computation, General context prepend, test suite with fixtures.

2. **Epic-2: MCP Server, Concurrent Image Generation, and .pptx Assembly**
   - Goal: Core MCP server with `generate_deck` tool producing `.pptx` via concurrent image generation and content-hash caching.
   - Addresses: G-2, G-3, G-4, G-8, G-9, G-10, G-11
   - Scope: Project setup (pyproject.toml), MCP server (FastMCP/stdio), Gemini client with retry, concurrent image gen (asyncio), cache manifest, python-pptx assembly, image compression, progress notifications, `generate_deck` tool.

3. **Epic-3: MCP Resource and Reference Document**
   - Goal: Single bundled reference document served as MCP resource enabling LLM self-sufficiency.
   - Addresses: G-5
   - Scope: Compile reference doc (format spec + brand guidelines + structure instructions + craft knowledge + example), MCP resource handler, `renderdeck://reference` registration, configurable resource path.

4. **Epic-4: Setup Tools, Supporting Tools, and Client Integration**
   - Goal: LLM-guided setup, validation tool, force-regenerate tool, settings management, and client configuration examples.
   - Addresses: G-6, G-12, G-13
   - Scope: `setup_gemini_key` with Fernet encryption, config persistence (`~/.renderdeck/config.json`), env var override, `get_setup_status`, `update_settings`, `validate_prompt_file`, `regenerate_slide`, MCP prompt templates, client config examples (Claude Desktop, Claude Code, Cursor).

## Epic Dependencies

```
Epic-1 (Parser) ──┐
                   ├──► Epic-2 (Server + Generation + Assembly)
Epic-3 (Resource) ─┘         │
                             ▼
                     Epic-4 (Setup + Tools + Integration)
```

- Epic-1 and Epic-3 can be developed in parallel (no dependency)
- Epic-2 depends on Epic-1 (parser module)
- Epic-4 depends on Epic-2 (server must exist for tools)

## Cycle Verification

| Phase | Coverage |
|-------|----------|
| Design | Design doc per epic with data models, API contracts, edge cases |
| Implementation | Python modules under `src/renderdeck_mcp/` |
| Testing | Unit tests (parser, cache, validation) + Integration tests (MCP tool endpoints, pptx assembly) |
| Documentation | README, client config examples, reference doc |
| Review | Code review per epic, security review on key encryption (Epic-4) |
