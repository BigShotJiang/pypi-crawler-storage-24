# Tasks for Epic-1: Parser and Validation Module

[Addresses: G-1, G-7]

---

## Task: project-scaffold

**Type:** Technical Task
**Summary:** Set up Python project structure with pyproject.toml, src layout, and dev dependencies.
**Risk:** HOTL — reversibility: high, consequence: isolated
**Depends on:** none

### Description

Create the `renderdeck-mcp` project scaffold with `src/renderdeck_mcp/` layout, `pyproject.toml` (PEP 621), and install dev dependencies (pytest, pytest-cov, pytest-asyncio, ruff, mypy). This is the foundation all other tasks build on.

### Acceptance Criteria

#### Functional Criteria

- [ ] VERIFY: `src/renderdeck_mcp/__init__.py` exists with package version
- [ ] VERIFY: `pyproject.toml` defines project metadata, dependencies, and dev extras
- [ ] VERIFY: `pip install -e ".[dev]"` succeeds without errors
- [ ] VERIFY: `pytest --version` runs from installed dev deps
- [ ] VERIFY: `ruff check src/` runs without import errors
- [ ] VERIFY: `mypy src/` runs without configuration errors

#### Boundary Criteria

- [ ] VERIFY: No runtime dependencies beyond those listed in PRD §13.2
- [ ] VERIFY: `renderdeck.py` (existing CLI) is NOT modified

#### Verification Gates

- [ ] All existing tests pass (`pytest`)
- [ ] Lint passes with zero errors (`ruff check .`)
- [ ] Type check passes (`mypy .`)

#### Definition of Done

- [ ] Code is on a feature branch
- [ ] PR created referencing this task
- [ ] All verification gates green
- [ ] Design doc at `docs/sdd/epic-parser-validation/project-scaffold/design.md`

---

## Task: prompt-file-parser

**Type:** Technical Task
**Summary:** Extract and adapt the slide prompt file parser from renderdeck.py into an importable module.
**Risk:** HIC — reversibility: high, consequence: team
**Depends on:** project-scaffold

### Description

Extract the parsing logic from `renderdeck.py` (lines 200-319) into `src/renderdeck_mcp/parser/prompt_file.py`. The parser splits markdown on `---` separators, extracts H1 title, optional H2 subtitle, General context, Global Rules, slide blocks (`## Slide NN — Title` + body), and Speaker Notes (`### Slide NN` with Say/Time lines). Output is a structured `ParsedDeck` dataclass. Must preserve exact parsing behavior from `renderdeck.py` §4.1.

### Acceptance Criteria

#### Functional Criteria

- [ ] VERIFY: `parse_prompt_file(content: str) -> ParsedDeck` returns a dataclass with title, subtitle, general, global_rules, slides (list), speaker_notes (dict by slide number)
- [ ] VERIFY: Each slide has: number (int), title (str), image_prompt (str)
- [ ] VERIFY: General context block extracted correctly (text between `## General` and next `##` or `---`)
- [ ] VERIFY: Global Rules block extracted correctly (text between `## Global Rules` and first `---`)
- [ ] VERIFY: Speaker notes matched by slide number NN, not by title
- [ ] VERIFY: Slide block with only H2 heading and no body → `image_prompt` is empty string
- [ ] VERIFY: Missing Speaker Notes section → slides have empty notes (no error)

#### Boundary Criteria

- [ ] VERIFY: Parser does not import or depend on Google API libraries
- [ ] VERIFY: Parser is a pure function (no side effects, no file I/O, no env vars)

#### Verification Gates

- [ ] All existing tests pass (`pytest`)
- [ ] New unit tests cover all functional criteria
- [ ] Lint passes (`ruff check .`)
- [ ] Type check passes (`mypy .`)

#### Definition of Done

- [ ] Code on feature branch
- [ ] PR created referencing this task
- [ ] All verification gates green
- [ ] Design doc at `docs/sdd/epic-parser-validation/prompt-file-parser/design.md`

---

## Task: format-validator

**Type:** Technical Task
**Summary:** Implement format validation with line-number error reporting, collecting all errors (not fail-on-first).
**Risk:** HOTL — reversibility: high, consequence: isolated
**Depends on:** prompt-file-parser

### Description

Implement `validate_prompt_file(content: str) -> ValidationResult` in `src/renderdeck_mcp/parser/validator.py`. Validates per PRD §6.1 rules: single H1, zero-padded slide numbers, no duplicates, heading format, slide count > 30 warning, orphan speaker notes warning. All errors collected with line numbers before returning.

### Acceptance Criteria

#### Functional Criteria

- [ ] VERIFY: Missing H1 → error with line number
- [ ] VERIFY: Multiple H1s → error with line numbers of both
- [ ] VERIFY: Non-zero-padded slide number (e.g., `## Slide 3`) → error with line number
- [ ] VERIFY: Duplicate slide numbers → error listing both line numbers
- [ ] VERIFY: Heading not matching `## Slide NN — Title` → warning (block skipped)
- [ ] VERIFY: File with 31 slides → warning (not error), processing continues
- [ ] VERIFY: Orphan speaker notes (no matching slide) → warning
- [ ] VERIFY: File with 3 errors → all 3 reported (not fail-on-first)

#### Boundary Criteria

- [ ] VERIFY: Valid file with 15 slides → `valid: true`, zero errors, zero warnings
- [ ] VERIFY: Missing Speaker Notes section → no error (matches renderdeck.py behavior)

#### Verification Gates

- [ ] All existing tests pass (`pytest`)
- [ ] New unit tests cover all 8 functional criteria
- [ ] Lint passes (`ruff check .`)
- [ ] Type check passes (`mypy .`)

#### Definition of Done

- [ ] Code on feature branch
- [ ] PR created referencing this task
- [ ] All verification gates green
- [ ] Design doc at `docs/sdd/epic-parser-validation/format-validator/design.md`

---

## Task: content-hash

**Type:** Technical Task
**Summary:** Implement content hash computation compatible with renderdeck.py cache manifest format.
**Risk:** HOTL — reversibility: high, consequence: isolated
**Depends on:** prompt-file-parser

### Description

Implement content hash and options hash computation in `src/renderdeck_mcp/parser/` (or `generation/cache.py`). Content hash = SHA-256 of normalized (General + Global Rules + slide prompt). Options hash = SHA-256 of (aspect ratio + model name). Must produce identical hashes to `renderdeck.py` for the same inputs (lines 367-391).

### Acceptance Criteria

#### Functional Criteria

- [ ] VERIFY: `content_hash_for_slide(general, global_rules, image_prompt) -> str` returns hex SHA-256
- [ ] VERIFY: `options_hash(aspect_ratio, model) -> str` returns hex SHA-256
- [ ] VERIFY: Whitespace normalization matches `renderdeck.py` `_normalize_for_hash()` (strip + collapse whitespace)
- [ ] VERIFY: Hash for same inputs matches hash produced by `renderdeck.py`
- [ ] VERIFY: Changing one character in slide prompt → different content hash

#### Boundary Criteria

- [ ] VERIFY: Empty image prompt → valid hash (not an error)
- [ ] VERIFY: Empty General and Global Rules → valid hash

#### Verification Gates

- [ ] All existing tests pass (`pytest`)
- [ ] New unit tests with fixture data from renderdeck.py
- [ ] Lint passes (`ruff check .`)
- [ ] Type check passes (`mypy .`)

#### Definition of Done

- [ ] Code on feature branch
- [ ] PR created referencing this task
- [ ] All verification gates green
