# Tasks for Epic-3: MCP Resource and Reference Document

[Addresses: G-5]

---

## Task: compile-reference-doc

**Type:** Technical Task
**Summary:** Compile the bundled reference document from format spec, brand guidelines, structure instructions, craft knowledge, and example.
**Risk:** HOTL — reversibility: high, consequence: isolated
**Depends on:** none

### Description

Create `resources/renderdeck_reference.md` — the single combined document that teaches an LLM everything it needs to produce a valid slide prompt file. Compile from: (1) slide prompt file format specification (from `docs/RenderDeck_Script_Spec_v1.0.md` §2), (2) brand guidelines, (3) structure instructions (placeholder handling), (4) presentation craft (11-point image prompt checklist, style anchor, speaker notes as stage directions), (5) annotated example excerpt.

### Acceptance Criteria

#### Functional Criteria

- [ ] VERIFY: `resources/renderdeck_reference.md` exists and is valid markdown
- [ ] VERIFY: Document contains sections for: format spec, brand guidelines, structure instructions, craft knowledge, annotated example
- [ ] VERIFY: Format spec section covers: H1 title, General block, Global Rules, slide blocks (`## Slide NN — Title`), Speaker Notes with Say/Time labels
- [ ] VERIFY: Example section contains at least 3 annotated slide blocks
- [ ] CONFIRM: An LLM reading only this document can produce a prompt file passing `validate_prompt_file` with 0 errors

#### Boundary Criteria

- [ ] VERIFY: Document size < 30KB (within LLM context limits)
- [ ] VERIFY: No external URLs or links that could break

#### Verification Gates

- [ ] Lint passes (`ruff check .`)

#### Definition of Done

- [ ] Document reviewed by human
- [ ] Code on feature branch
- [ ] PR created referencing this task

---

## Task: mcp-resource-handler

**Type:** Technical Task
**Summary:** Implement MCP resource handler serving renderdeck://reference from bundled or custom path.
**Risk:** HOTL — reversibility: high, consequence: isolated
**Depends on:** compile-reference-doc

### Description

Create `src/renderdeck_mcp/resources/handler.py`. Register `renderdeck://reference` as an MCP resource. By default, load from the bundled `resources/renderdeck_reference.md` (packaged via `pyproject.toml` data files). Support configurable resource path via `config.json` for organizations with custom brand guidelines.

### Acceptance Criteria

#### Functional Criteria

- [ ] VERIFY: MCP Inspector shows `renderdeck://reference` in resource list
- [ ] VERIFY: Reading the resource returns the full reference document content
- [ ] VERIFY: Custom resource path in config → loads from that path instead of bundled file
- [ ] VERIFY: Updated file on disk → server restart → updated content served

#### Boundary Criteria

- [ ] VERIFY: Missing bundled file → clear error message at server startup
- [ ] VERIFY: Custom path pointing to non-existent file → clear error at startup, fallback to bundled

#### Verification Gates

- [ ] All existing tests pass (`pytest`)
- [ ] New unit tests cover all functional criteria
- [ ] Lint passes (`ruff check .`)
- [ ] Type check passes (`mypy .`)

#### Definition of Done

- [ ] Code on feature branch
- [ ] PR created referencing this task
- [ ] All verification gates green
- [ ] Design doc at `docs/sdd/epic-mcp-resource-reference/mcp-resource-handler/design.md`
