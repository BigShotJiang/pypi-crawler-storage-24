# Tasks for Epic-4: Setup Tools, Supporting Tools, and Client Integration

[Addresses: G-6, G-12, G-13]

---

## Task: config-and-key-management

**Type:** Technical Task
**Summary:** Implement config persistence and Gemini API key setup with Fernet encryption.
**Risk:** HITL — reversibility: low, consequence: isolated
**Depends on:** none

### Description

Create `src/renderdeck_mcp/config.py`. Manages `~/.renderdeck/config.json` with Fernet-encrypted Gemini API key storage. Implements `setup_gemini_key` MCP tool (validate key via lightweight API call, encrypt, store) and `get_setup_status` MCP tool (report readiness). Supports `GOOGLE_GEMINI_API_KEY` env var override.

### Acceptance Criteria

#### Functional Criteria

- [ ] VERIFY: `setup_gemini_key(api_key)` validates key via Gemini API call, encrypts with Fernet, stores in `~/.renderdeck/config.json`
- [ ] VERIFY: Invalid API key → error returned, key not stored
- [ ] VERIFY: `get_setup_status()` returns `{gemini_key_configured, gemini_model, aspect_ratio, ready, issues}`
- [ ] VERIFY: No config → `ready: false` with setup guidance in `issues`
- [ ] VERIFY: Valid key stored → `ready: true`
- [ ] VERIFY: `GOOGLE_GEMINI_API_KEY` env var overrides stored key
- [ ] VERIFY: Config file created at `~/.renderdeck/config.json` with 600 permissions

#### Boundary Criteria

- [ ] VERIFY: API key is NOT stored in plaintext in config.json
- [ ] VERIFY: API key is NOT logged or included in error messages
- [ ] VERIFY: Corrupted config.json → treated as empty, user prompted to re-setup

#### Verification Gates

- [ ] All existing tests pass (`pytest`)
- [ ] New unit tests with mocked Gemini API for key validation
- [ ] Lint passes (`ruff check .`)
- [ ] Type check passes (`mypy .`)

#### Definition of Done

- [ ] Code on feature branch
- [ ] PR created referencing this task
- [ ] All verification gates green
- [ ] Design doc at `docs/sdd/epic-setup-tools-integration/config-and-key-management/design.md`

---

## Task: update-settings-tool

**Type:** Technical Task
**Summary:** Implement update_settings MCP tool for model, aspect ratio, concurrency, and output dir.
**Risk:** HOTL — reversibility: high, consequence: isolated
**Depends on:** config-and-key-management

### Description

Create `src/renderdeck_mcp/tools/setup.py` with `update_settings` MCP tool. Updates optional config: `gemini_image_model`, `aspect_ratio` (WIDE/STANDARD), `default_output_dir`, `gemini_max_retries`, `max_concurrent_images`, `verbose`.

### Acceptance Criteria

#### Functional Criteria

- [ ] VERIFY: `update_settings(gemini_image_model?, aspect_ratio?, ...)` updates config.json
- [ ] VERIFY: Only provided fields are updated (others preserved)
- [ ] VERIFY: Invalid `aspect_ratio` value → error returned, config unchanged
- [ ] VERIFY: Updated settings reflected in next `get_setup_status` call

#### Boundary Criteria

- [ ] VERIFY: Config file write is atomic (tmp + rename)

#### Verification Gates

- [ ] All existing tests pass (`pytest`)
- [ ] New unit tests cover update and validation logic
- [ ] Lint passes (`ruff check .`)
- [ ] Type check passes (`mypy .`)

#### Definition of Done

- [ ] Code on feature branch
- [ ] PR created referencing this task
- [ ] All verification gates green

---

## Task: validate-prompt-tool

**Type:** Technical Task
**Summary:** Implement validate_prompt_file MCP tool for dry-run validation.
**Risk:** HOTL — reversibility: high, consequence: isolated
**Depends on:** none

### Description

Create `src/renderdeck_mcp/tools/validate.py`. Wraps the parser validator (Epic-1) as an MCP tool. Returns `{valid, slide_count, slides: [{number, title}], errors: [{slide_number, line_number, message}], warnings}`.

### Acceptance Criteria

#### Functional Criteria

- [ ] VERIFY: `validate_prompt_file(slide_prompt_content)` returns structured validation result
- [ ] VERIFY: Valid file → `valid: true`, errors empty, slides list populated
- [ ] VERIFY: File with 3 errors → `valid: false`, all 3 errors with line numbers
- [ ] VERIFY: MCP Inspector shows `validate_prompt_file` tool with correct schema

#### Boundary Criteria

- [ ] VERIFY: Empty input → error (not crash)
- [ ] VERIFY: No Gemini key needed for validation (dry-run only)

#### Verification Gates

- [ ] All existing tests pass (`pytest`)
- [ ] New unit tests cover valid and invalid inputs
- [ ] Lint passes (`ruff check .`)
- [ ] Type check passes (`mypy .`)

#### Definition of Done

- [ ] Code on feature branch
- [ ] PR created referencing this task
- [ ] All verification gates green

---

## Task: regenerate-slide-tool

**Type:** Technical Task
**Summary:** Implement regenerate_slide MCP tool to force-regenerate specific slides and reassemble .pptx.
**Risk:** HIC — reversibility: medium, consequence: isolated
**Depends on:** none

### Description

Create `src/renderdeck_mcp/tools/regenerate.py`. Accepts project_name and slide_numbers list. Forces Gemini API calls for specified slides (bypasses cache), updates cache manifest, reassembles .pptx. Equivalent to `renderdeck.py --regenerate-slide`.

### Acceptance Criteria

#### Functional Criteria

- [ ] VERIFY: `regenerate_slide(project_name, slide_numbers, output_path?)` regenerates specified slides
- [ ] VERIFY: Non-specified slides remain cached (not regenerated)
- [ ] VERIFY: Cache manifest updated with new hashes for regenerated slides
- [ ] VERIFY: Updated .pptx written to output path

#### Boundary Criteria

- [ ] VERIFY: Non-existent project_name → clear error
- [ ] VERIFY: Slide number not in deck → warning, other slides still processed

#### Verification Gates

- [ ] All existing tests pass (`pytest`)
- [ ] New integration tests with mocked Gemini
- [ ] Lint passes (`ruff check .`)
- [ ] Type check passes (`mypy .`)

#### Definition of Done

- [ ] Code on feature branch
- [ ] PR created referencing this task
- [ ] All verification gates green

---

## Task: prompt-templates

**Type:** Technical Task
**Summary:** Implement create_deck and check_and_fix MCP prompt templates.
**Risk:** HOTL — reversibility: high, consequence: isolated
**Depends on:** none

### Description

Register MCP prompt templates: `create_deck` (guided workflow: read reference → validate → generate → return path) and `check_and_fix` (validate and describe errors with suggested fixes). These are prompt templates that guide LLM interactions.

### Acceptance Criteria

#### Functional Criteria

- [ ] VERIFY: MCP Inspector lists `create_deck` and `check_and_fix` prompts
- [ ] VERIFY: `create_deck` prompt includes reference to `renderdeck://reference` resource
- [ ] VERIFY: `check_and_fix` prompt instructs validation then error-by-error fix suggestions

#### Boundary Criteria

- [ ] VERIFY: Prompts do not hardcode model-specific instructions

#### Verification Gates

- [ ] All existing tests pass (`pytest`)
- [ ] Lint passes (`ruff check .`)
- [ ] Type check passes (`mypy .`)

#### Definition of Done

- [ ] Code on feature branch
- [ ] PR created referencing this task
- [ ] All verification gates green

---

## Task: client-integration-docs

**Type:** Technical Task
**Summary:** Create client configuration examples for Claude Desktop, Claude Code, and Cursor.
**Risk:** HOTL — reversibility: high, consequence: isolated
**Depends on:** none

### Description

Create client configuration documentation with working examples for Claude Desktop (`claude_desktop_config.json`), Claude Code (`.claude/settings.json`), and Cursor. Include end-to-end example conversation flow showing resource read → prompt creation → deck generation → iteration.

### Acceptance Criteria

#### Functional Criteria

- [ ] VERIFY: README includes Claude Desktop config JSON example
- [ ] VERIFY: README includes Claude Code MCP config example
- [ ] VERIFY: README includes Cursor config example
- [ ] CONFIRM: Config examples work on a standard macOS dev machine with `uvx`

#### Boundary Criteria

- [ ] VERIFY: Examples use `uvx renderdeck-mcp serve` (not hardcoded paths)

#### Verification Gates

- [ ] Lint passes (`ruff check .`)

#### Definition of Done

- [ ] Documentation reviewed by human
- [ ] Code on feature branch
- [ ] PR created referencing this task
