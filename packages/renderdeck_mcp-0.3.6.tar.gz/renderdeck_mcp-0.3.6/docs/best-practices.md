# Best Practices — RenderDeck

## 1. Language & Framework Conventions

### Do
- Use `from __future__ import annotations` for modern type hint syntax
- Use `Path` objects (not raw strings) for all file system paths
- Use `|` union syntax for type hints (e.g., `str | None`) — Python 3.12+
- Prefix private/internal functions with `_` (e.g., `_err`, `_verbose`)
- Group imports: stdlib → third-party → local, separated by blank lines
- Use f-strings for string formatting
- Use `dataclass` or `TypedDict` for structured data (not plain dicts) in new code

### Don't
- Don't use `google-generativeai` (deprecated) — use `google-genai`
- Don't use `os.path` — use `pathlib.Path`
- Don't use bare `except:` — always catch specific exceptions
- Don't use mutable default arguments (`def f(x=[])`)
- Don't use `print()` for user output — use `_err()`, `_warn()`, `_verbose()` helpers or stderr

### Why
RenderDeck targets Python 3.12+ and follows a helper-function pattern for output. Consistent use of Path objects and modern type syntax keeps the codebase readable and refactor-friendly.

## 2. Quality Standards

### Do
- Write pytest tests for all pure functions (parsers, hashers, formatters)
- Mock external APIs (Gemini, Google Slides, Drive) in unit tests — never call real APIs
- Use `responses` or `unittest.mock` for HTTP mocking
- Target 80% coverage on non-API-call code
- Use `ruff check` for linting and `ruff format` for formatting
- Use `mypy` for type checking (strict mode on new modules)
- Log errors to stderr with `[ERROR] <phase>: <message>` format
- Use `[WARN]` prefix for non-fatal warnings

### Don't
- Don't write tests that require Google API credentials
- Don't skip error handling — every API call must have retry or clear failure
- Don't log sensitive data (API keys, OAuth tokens, file contents)

### Why
RenderDeck interacts with paid APIs (Gemini charges per image). Tests must never make real API calls. The `[ERROR] phase:` format is established in the codebase and consumed by users for debugging.

## 3. Architecture & Design Patterns

### Do
- Follow the sequential phase architecture: startup → parse → auth → generate → build → output
- Keep image caching content-hash-based (General + Global Rules + prompt + options)
- Use atomic file writes (write to `.tmp`, then rename) for cache manifests and state
- Keep the CLI script (`renderdeck.py`) as the entry point; MCP server as a separate module
- Extract reusable logic (parsing, caching, image gen) into importable modules for MCP server
- Use environment variables via `.env` for all credentials and configuration
- Return structured data from functions (dicts or dataclasses), not tuples of many values

### Don't
- Don't create partial presentations — complete deck or nothing (cleanup on failure)
- Don't hardcode API keys, model names, or file paths
- Don't add framework dependencies (click, rich, pydantic) to the CLI script
- Don't bypass the cache system — always check content hash before regenerating

### Why
The atomic/idempotent design prevents billing for duplicate API calls and avoids leaving broken state. The MCP server wraps the same logic, so extracting modules enables code reuse.

## 4. Development Workflow

### Do
- Branch from `main` using `feature/` prefix for epics, task-specific branches underneath
- Use `[SDD]` prefix for pipeline-generated commits
- Run `ruff check . && ruff format --check . && mypy .` before committing
- Keep PRs focused on a single task/feature
- Reference Jira ticket (EXE-*) in PR titles and commit messages

### Don't
- Don't commit `.env`, `.secrets/`, `credentials.json`, or `token.json`
- Don't force-push to `main`
- Don't merge without passing lint and type checks

### Why
Trunk-based development with feature branches keeps the history clean. Jira references enable traceability from code to requirements.
