# Tech Stack — RenderDeck

## Language

| Language | Version | Notes |
|----------|---------|-------|
| Python | 3.12+ | Single-script CLI, evolving to MCP server |

## Core Dependencies

| Library | Version | Purpose |
|---------|---------|---------|
| google-genai | >=1.0 | Gemini image generation (Nano Banana / Nano Banana Pro) |
| google-api-python-client | >=2.100 | Google Slides API for presentation assembly |
| google-auth-oauthlib | >=1.0 | OAuth 2.0 authentication flow |
| google-auth-httplib2 | >=0.2 | HTTP transport for Google auth |
| python-dotenv | >=1.0 | .env file loading |
| Pillow | >=10.0 | Image processing and manipulation |

## Planned Dependencies (MCP Server)

| Library | Purpose |
|---------|---------|
| python-pptx | .pptx assembly (replacing Google Slides output) |
| MCP SDK (Python) | MCP server protocol implementation |

## Build & Package

| Tool | Command |
|------|---------|
| pip | `pip install -r requirements.txt` |

## Testing

No test framework currently configured. To be established during project setup.

## Lint / Format

No linter or formatter currently configured. To be established during project setup.

## CI/CD

None configured.

## Deployment

- **Target:** Local execution (CLI script)
- **Invocation:** `python renderdeck.py <presentation.md>`

## External Services

| Service | Purpose | Auth |
|---------|---------|------|
| Google Gemini API | Image generation | API key (`GOOGLE_GEMINI_API_KEY`) |
| Google Slides API | Presentation assembly | OAuth 2.0 (`GOOGLE_SLIDES_CREDENTIALS_FILE`) |
| Google Drive API | File placement | OAuth 2.0 (shared token) |
