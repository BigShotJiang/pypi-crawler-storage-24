# RenderDeck Script Specification
## `renderdeck.py` — Markdown to Google Slides via Gemini + Google Slides API

| Field | Value |
|---|---|
| Version | 1.0 |
| Date | February 2026 |
| Runtime | Python 3.12+ |
| Invocation | `python renderdeck.py <presentation.md>` |
| Output | Google Slides presentation URL printed to stdout |

This document defines the complete behaviour, structure, parsing rules, API integration logic, error handling, and configuration contract for `renderdeck.py` — a single Python script that parses a structured presentation markdown file, generates slide images using the Gemini image API (Nano Banana / Nano Banana Pro, configurable via `.env`), and assembles the result as a Google Slides presentation via the Google Slides API v1.

---

## 1. Overview and Design Principles

`renderdeck.py` takes one argument: a path to a markdown file following the format established in the Exalate AI Agent Economy deck (see Section 2). It produces one Google Slides presentation in the authenticated user's Google Drive and prints the presentation URL to stdout when done.

The script is self-contained. No web server, no database, no background jobs, no intermediate files persisted to disk beyond a temporary directory for image staging. Everything runs in a single synchronous Python process in order: parse → generate images → create presentation → populate slides → print URL.

### Design constraints

- **Single file.** `renderdeck.py` contains all logic. No internal modules, no sub-packages.
- **No framework dependencies.** Standard library plus `google-generativeai`, `google-api-python-client`, `python-dotenv`, `Pillow` (image format validation), and `Requests`. No click, no rich, no httpx, no pydantic.
- **All credentials from `.env`.** No credential is hardcoded or accepted as a CLI argument.
- **Fail loudly.** Any unrecoverable error prints a clear message to stderr and exits with code 1. No silent fallbacks.
- **Idempotent image generation.** Cached slide images are associated with a version of the slide prompt file and options. The script keeps a `cache_manifest.json` in each deck’s cache dir. An image is reused only when the slide’s prompt content (including General and Global Rules) and the current options (aspect ratio, Gemini model) match the version recorded in the manifest. If you change a single slide’s description, only that slide is regenerated; if you change General/Global Rules or options, the affected slides are regenerated. This avoids re-billing on retries and when content is unchanged.
- **No partial presentations.** If the Google Slides export fails mid-way, the partially created presentation is deleted before exit. The user either gets a complete deck or nothing.

---

## 2. Markdown Format Specification

The format is defined by the structure of the Exalate AI Agent Economy deck. The parser must handle this exact structure.

### 2.1 File structure

The file has four distinct sections in order:

1. **H1 — Presentation title** (exactly one, first line of the file)
2. **H2 — Optional deck subtitle** (directly below H1)
3. **Global Rules block** — introduced by `## Global Rules`, terminated by the first `---` separator. Contains freeform text describing visual rules that apply to all slides. Stored verbatim and prepended to every image prompt.
4. **Slide blocks** — each slide delimited by `---` separators. Each starts with an H2 heading: `## Slide NN — Title text` where NN is a zero-padded two-digit number.
5. **Speaker Notes block** — a single `## Speaker Notes` section at the end. Contains H3 sub-sections per slide: `### Slide NN — Title`.

### 2.2 Slide block structure

Each slide block (between `---` separators) contains:

- An H2 heading `## Slide NN — Title text` (required). NN and title are extracted from this.
- The image prompt: the entire body text of the slide block, excluding the H2 heading line. This is the verbatim Nano Banana prompt for that slide. It may span multiple paragraphs and contain markdown formatting.

If a slide block contains only an H2 heading and no body text, the slide has no image prompt. The script creates the slide with title and speaker notes only — image generation is skipped. No error is raised.

### 2.3 Speaker Notes block

The `## Speaker Notes` section contains one H3 sub-section per slide:

```
### Slide NN — Title
**Time:** ~NN seconds. Optional timing note.
**Say:** The verbatim speaker notes text.
```

The parser extracts the full text of each H3 sub-section and stores it as the speaker notes for the corresponding slide number NN. Association is by slide number, not by title.

### 2.4 Global Rules

The Global Rules block is stored as a single string and prepended verbatim to every image prompt sent to the Gemini API:

```
GLOBAL VISUAL RULES (apply to all slides):
{global_rules_text}

SLIDE-SPECIFIC PROMPT:
{slide_prompt_text}
```

### 2.5 Parsed slide object fields

| Field | Source | Example |
|---|---|---|
| `slide_number` | H2 heading NN | `'03'` |
| `slide_title` | H2 heading after em-dash | `'The Numbers That Matter'` |
| `image_prompt` | Entire H2 body text | `'Create a wide-format...'` |
| `has_prompt` | Derived: body text exists | `True` |
| `speaker_notes` | Matching H3 in Speaker Notes | `'**Time:** ~60 seconds...'` |
| `has_notes` | Derived: matching H3 found | `True` |

---

## 3. Configuration — `.env` File

`renderdeck.py` loads configuration exclusively from a `.env` file in the same directory as the script. `python-dotenv` is used to load it.

### 3.1 Required variables

| Variable | Description |
|---|---|
| `GOOGLE_GEMINI_API_KEY` | API key for the Google Gemini API. Required if any slide has an image prompt. If absent, image generation is skipped for all slides with a warning — not an exit condition. |
| `GOOGLE_SLIDES_CREDENTIALS_FILE` | Path to a Google OAuth 2.0 client credentials JSON file downloaded from Google Cloud Console. Script exits 1 if this file does not exist. |
| `GOOGLE_SLIDES_TOKEN_FILE` | Path where the OAuth token is stored after first authorization. Created automatically on first run. Reused on subsequent runs. |

### 3.2 Optional variables

| Variable | Default | Description |
|---|---|---|
| `GEMINI_IMAGE_MODEL` | `gemini-2.5-flash-image` | Gemini image model. Set to `gemini-3-pro-image-preview` for Nano Banana Pro (4K quality, ~$0.12/image). Default is Nano Banana (~$0.039/image). |
| `IMAGE_TEMP_DIR` | `./.renderdeck_tmp` | Directory for temporary image files. Created if absent. Persists between runs for idempotent image reuse. User is responsible for cleanup. |
| `SLIDES_ASPECT_RATIO` | `WIDE` | `WIDE` = 16:9. `STANDARD` = 4:3. |
| `GEMINI_MAX_RETRIES` | `3` | Max retries for Gemini image API on transient failures. Exponential backoff: 2s, 4s, 8s. |
| `SLIDES_MAX_RETRIES` | `5` | Max retries per slide batchUpdate on 429 or 503. Exponential backoff: 1s, 2s, 4s, 8s, 16s. |
| `VERBOSE` | `false` | Set to `true` to print per-step progress to stderr. When false, only the final URL is printed to stdout. |

### 3.3 Startup validation

Before parsing the markdown, the script validates:

- `GOOGLE_GEMINI_API_KEY` is set. If absent and slides have prompts: warn to stderr, continue with text-only fallback for all slides.
- `GOOGLE_SLIDES_CREDENTIALS_FILE` exists and is readable. If not: exit 1.
- `GEMINI_IMAGE_MODEL` is one of the two known values. If not: warn to stderr, proceed with the value as-is.
- `IMAGE_TEMP_DIR` is writable. If not: exit 1.

---

## 4. Execution Flow

The script executes in six sequential phases. Each must complete before the next begins.

| Phase | Name | Description | Failure behaviour |
|---|---|---|---|
| 1 | Startup | Load `.env`, validate config, validate CLI argument | Exit 1 |
| 2 | Parse | Parse markdown into slide objects and global rules | Exit 1 on parse error |
| 3 | Authenticate | OAuth 2.0 flow or cached token. Scopes: `slides.v1`, `drive.file` | Exit 1 |
| 4 | Generate images | Call Gemini per slide with prompt. Skip if cached PNG exists. | Per-slide retry; text-only fallback on exhaustion |
| 5 | Build presentation | Create presentation, populate slides via batchUpdate, insert images, add speaker notes | Delete partial presentation; exit 1 |
| 6 | Output | Print URL to stdout | n/a |

### 4.1 Phase 2 — Markdown parsing

The parser uses Python's standard `re` module. No markdown parsing library.

1. Read file as UTF-8. Fail loudly on encoding errors.
2. Split on `---` separators (three or more hyphens on a line by themselves).
3. First segment: extract H1 as presentation title, H2 as subtitle, text under `## Global Rules` as `global_rules` string.
4. Middle segments: each is a slide block. Extract `slide_number` and `slide_title` from the H2 heading. Store remaining text as `image_prompt`. Set `has_prompt = bool(image_prompt.strip())`.
5. Last segment (if it begins with `## Speaker Notes`): split on H3 headings `### Slide NN`. For each H3, extract slide number and store body as `speaker_notes`. Associate with the matching slide by `slide_number`.
6. Return: `{title, subtitle, global_rules, slides: [SlideData, ...]}`

### 4.2 Phase 4 — Image generation

The script maintains a **cache manifest** (`cache_manifest.json`) in each deck’s cache dir. It records an **options hash** (aspect ratio and Gemini model) and a **content hash** per slide (derived from General, Global Rules, and that slide’s image prompt). Cached images are reused only when both the options and the slide’s content match the hashes in the manifest.

For each slide where `has_prompt` is `true`:

1. Construct full prompt: prepend General (if present) and Global Rules block (Section 2.4 format) to the slide's `image_prompt`.
2. Compute the current **options hash** (once per run) and the current **content hash** for this slide. Load the cache manifest if present.
3. **Reuse** the cached image only if: not forced via `--regenerate-slide`, the manifest exists, the manifest’s `options_hash` equals the current options hash, the manifest’s entry for this slide equals the current content hash, and `slide_{NN}.png` exists. If so: log `'slide NN: reusing cached image'` (if VERBOSE), skip API call, and continue.
4. Otherwise **regenerate**: call the Gemini image API (see below), write PNG bytes to `{deck_cache_dir}/slide_{NN}.png`, and update the manifest for this slide. If no manifest existed (e.g. first run or old cache), one is created and then saved after all slides are processed.
5. On API error: retry up to `GEMINI_MAX_RETRIES` with exponential backoff. On exhaustion: warn to stderr, set `has_prompt = false`, continue with text-only slide.
6. After the loop: restrict the manifest’s slide entries to the current deck (drop removed slides), set `options_hash` to the current value, and save `cache_manifest.json`.

**When slides are regenerated:** Editing a single slide’s image prompt changes only that slide’s content hash, so only that slide is regenerated. Editing the General or Global Rules block changes every slide’s content hash, so all slides with prompts are regenerated. Changing options (e.g. `--pro` or `SLIDES_ASPECT_RATIO`) changes the options hash, so all slide images are regenerated. The `-r` / `--regenerate-slide` flag forces regeneration for the given slide(s) even if the manifest matches.

Gemini image API call:

```python
model = genai.GenerativeModel(os.getenv('GEMINI_IMAGE_MODEL', 'gemini-2.5-flash-image'))
response = model.generate_content(full_prompt)
image_bytes = response.candidates[0].content.parts[0].inline_data.data
```

> **SynthID note.** All Nano Banana and Nano Banana Pro images carry Google's SynthID invisible watermark. It does not affect visual quality or image bytes in any way detectable by the script. No handling required.

### 4.3 Phase 5 — Build presentation

#### 4.3.1 Create presentation and set dimensions

- Call `presentations.create()` with the presentation title.
- Call `presentations.batchUpdate()` with `updatePresentationProperties` to set page size: WIDE = 9144000 × 5143500 EMU (16:9) or STANDARD = 9144000 × 6858000 EMU (4:3).
- Delete the default blank slide created by `presentations.create()` using a `deleteObject` request.

#### 4.3.2 Populate slides — one batchUpdate per slide

For each slide in order, build a list of subrequests:

- `createSlide`: `insertionIndex` = slide position (0-indexed), `objectId` = `'slide_{NN}'`
- `createShape` (title text box): `objectId` = `'title_{NN}'`, `shapeType` = `TEXT_BOX`, positioned at top of slide
- `insertText` into `title_{NN}`: the slide title
- `createShape` (notes): `objectId` = `'notes_{NN}'`, in the notes page
- `insertText` into `notes_{NN}`: the speaker notes (if `has_notes`)
- If `has_prompt` is `true` and `slide_{NN}.png` exists: add `createImage` subrequest with the image as a base64 data URI (`data:image/png;base64,...`), positioned at 0,0, sized to full slide dimensions, sent as the first subrequest so it is placed behind text.

Execute `presentations.batchUpdate()` with all subrequests for this slide as a single atomic call. On 429 or 503: retry up to `SLIDES_MAX_RETRIES`. On exhaustion: trigger cleanup and exit 1.

> **2MB image upload limit.** The Google Slides API `createImage` data URI is subject to a 2MB size limit. Nano Banana Pro 4K images may exceed this. If the encoded image exceeds 2MB, compress the PNG using Pillow before encoding and log a warning to stderr: `'slide NN: image compressed from XMB to YMB for upload'`.

#### 4.3.3 Cleanup on failure

If any `batchUpdate` call exhausts retries:

- Call `drive.files.delete()` on the presentation file ID to remove the partial presentation.
- Print to stderr: `'Export failed on slide NN. Partial presentation deleted. Temp images preserved in {IMAGE_TEMP_DIR} for reuse on retry.'`
- Exit 1.

If `drive.files.delete()` itself fails: warn `'Could not delete partial presentation {ID} — delete it manually.'` and exit 1.

---

## 5. Google Authentication

The script uses OAuth 2.0 authorization code flow via `google-auth-oauthlib`.

1. Load `GOOGLE_SLIDES_CREDENTIALS_FILE`.
2. Check if `GOOGLE_SLIDES_TOKEN_FILE` exists and contains a valid unexpired token. If yes: load and use it.
3. If no valid token: run `InstalledAppFlow.from_client_secrets_file()` with scopes `['https://www.googleapis.com/auth/presentations', 'https://www.googleapis.com/auth/drive.file']`. This opens a browser for the user to authorize.
4. Save the token to `GOOGLE_SLIDES_TOKEN_FILE` for future runs.
5. Build Slides API service: `build('slides', 'v1', credentials=creds)`.
6. Build Drive API service: `build('drive', 'v3', credentials=creds)`. Used only for cleanup on failure.

> **Required Google Cloud setup (not automated by the script).** Create a project in Google Cloud Console. Enable the Google Slides API and Google Drive API. Create OAuth 2.0 credentials (Desktop application type). Download the credentials JSON and set `GOOGLE_SLIDES_CREDENTIALS_FILE` to its path. Document this in the README.

---

## 6. Output and Exit Behaviour

### 6.1 Success

- Print to stdout: `https://docs.google.com/presentation/d/{presentationId}/edit`
- Nothing else printed to stdout.
- Exit code 0.

### 6.2 VERBOSE=true additional output (stderr)

- Parsing summary: `'Parsed NN slides, NN with image prompts, NN with speaker notes'`
- Per image: `'slide NN: generating image (Nano Banana / Nano Banana Pro)...'` or `'slide NN: reusing cached image'`
- Per slide: `'slide NN: populated (with image / text only)'`
- Completion: `'Presentation created: NN slides, NN images. Estimated image cost: $X.XX'`

### 6.3 Cost estimate (VERBOSE only, stderr)

Count slides where image generation was actually called (not reused from cache).

- `gemini-2.5-flash-image`: cost = count × $0.039
- `gemini-3-pro-image-preview`: cost = count × $0.12

Print: `'Estimated image generation cost: $X.XX (N images @ $Y.YYY each)'`
Print: `'Estimate only. Actual billing depends on output token count and Google pricing at time of call.'`

### 6.4 Error exit

- All error messages to stderr.
- Format: `'[ERROR] <phase>: <message>'`
- Exit code 1.
- No stack traces unless `VERBOSE=true`.

---

## 7. Error Handling Reference

| Error condition | Phase | Behaviour |
|---|---|---|
| No CLI argument or file not found | 1 — Startup | Print usage to stderr. Exit 1. |
| File is not a `.md` file | 1 — Startup | Warn to stderr, proceed. |
| `GOOGLE_SLIDES_CREDENTIALS_FILE` missing | 1 — Startup | Exit 1. |
| Markdown has no H1 title | 2 — Parse | Exit 1. |
| Slide heading does not match `## Slide NN — ...` | 2 — Parse | Warn to stderr, skip that block, continue. |
| Slide count exceeds 30 | 2 — Parse | Warn to stderr: `'NN slides found — Google Slides API performance may degrade above 30 slides.'` Proceed. |
| Speaker Notes block missing | 2 — Parse | No error. All slides get empty speaker notes. |
| Speaker notes NN has no matching slide NN | 2 — Parse | Warn to stderr. Skip. |
| Google OAuth authorization denied | 3 — Auth | Exit 1. |
| Gemini API returns 400 (invalid prompt) | 4 — Images | Log per-slide error. Text-only fallback. Continue. |
| Gemini API returns 5xx or timeout | 4 — Images | Retry up to `GEMINI_MAX_RETRIES`. Text-only fallback on exhaustion. |
| Gemini content policy block | 4 — Images | Warn: `'slide NN: image blocked by content policy — text-only slide.'` Continue. |
| Gemini response has no image part | 4 — Images | Warn. Text-only fallback. |
| Image file cannot be written to temp dir | 4 — Images | Exit 1. |
| `presentations.create()` fails | 5 — Build | Exit 1. Nothing to clean up. |
| `batchUpdate` fails after retries | 5 — Build | Delete partial presentation. Exit 1. Temp images preserved. |
| `drive.files.delete()` fails during cleanup | 5 — Build | Warn: `'Could not delete partial presentation {ID} — delete manually.'` Exit 1. |

---

## 8. Dependencies

| Package | Min version | Purpose |
|---|---|---|
| `google-generativeai` | 0.8 | Gemini image API (Nano Banana / Nano Banana Pro) |
| `google-api-python-client` | 2.100 | Google Slides API v1 and Drive API v3 |
| `google-auth-oauthlib` | 1.0 | OAuth 2.0 flow |
| `google-auth-httplib2` | 0.2 | HTTP transport for google-auth |
| `python-dotenv` | 1.0 | `.env` file loading |
| `Pillow` | 10.0 | PNG validation and compression before upload |

```
pip install google-generativeai google-api-python-client google-auth-oauthlib google-auth-httplib2 python-dotenv Pillow
```

Standard library used: `re`, `os`, `sys`, `base64`, `pathlib`, `time`, `json`, `logging`.

---

## 9. Deliverable File Structure

| File | Description |
|---|---|
| `renderdeck.py` | The script. Single file, all logic self-contained. |
| `.env.example` | Template `.env` with all variables listed, values blank, inline comments. |
| `requirements.txt` | Pinned versions for all dependencies from Section 8. |
| `README.md` | Setup: Google Cloud Console steps, credential download, `.env` population, first-run OAuth flow, usage examples, cost guidance, markdown format reference with a complete example slide. |

The script creates no additional files beyond the token file at `GOOGLE_SLIDES_TOKEN_FILE`, image files in `IMAGE_TEMP_DIR` (per-deck subdir), and a `cache_manifest.json` in each deck’s cache dir (see Section 4.2).

---

## 10. Known Limitations

**Text layout is title-only per slide.** The script creates one title text box per slide. All visual content is the responsibility of the image prompt. The script does not parse body bullets from the markdown and does not create body text boxes. This matches the format of the example deck where all content is baked into the Nano Banana prompt.

**No branding injection beyond the prompt.** Brand colors, fonts, and logo placement are the responsibility of the prompt author. The script does not apply branding programmatically beyond what the generated image contains.

**2MB Google Slides image upload limit.** The `createImage` data URI path is limited to 2MB per image. Nano Banana Pro 4K output may exceed this. The script compresses via Pillow when this occurs (see Section 4.3.2).

**Sequential image generation.** Images are generated one at a time. For a 16-slide deck with Nano Banana, this takes approximately 4–8 minutes. Parallel generation is not in v1.0.

**One presentation per run.** The script always creates a new presentation. It does not update or overwrite an existing one.

**OAuth requires browser on first run.** The first run opens a browser for Google authorization. After that, the token file enables headless execution.

**Temp images not automatically cleaned up.** `IMAGE_TEMP_DIR` is preserved between runs. Each deck has a subdir containing `slide_{NN}.png` and `cache_manifest.json`; the manifest ties cached images to the version of the slide prompt and options they were built from. The user must delete the temp dir manually when no longer needed. Document prominently in the README.

---

## 11. Revision History

| Version | Changes |
|---|---|
| 1.0 — February 2026 | Initial specification. Derived from RenderDeck PRD v2.0 and the Exalate AI Agent Economy presentation markdown format. |
