# RenderDeck slide prompt file format

Use this format when creating or regenerating a presentation markdown file for **renderdeck**. The file is the single source for slide titles, image prompts (for Gemini), and speaker notes.

---

## 1. Front matter (first block, before any `---`)

- **One `# H1`** — the presentation title.
- Optional **`## General`** — audience, tone, and context that apply to the whole deck. This is included in every slide’s image prompt.
- Optional **`## Global Rules`** — visual/brand rules (colors, fonts, layout) that apply to every slide.

Do not put `---` inside this block. Only the first segment may contain the H1 and these sections.

---

## 2. Slide blocks (one per segment, separated by `---`)

Each segment between `---` is **one slide**.

- **First line of each segment:**  
  `## Slide NN — Title`  
  - `NN` = exactly **two digits** (01, 02, 03, …).
  - One space after `Slide`, then the two-digit number, then space, then **em dash `—` or hyphen `-`**, then the slide title (plain text, no `Title:` prefix, no quotes).
- **Rest of the segment:** the **image prompt** for that slide only. This is the prompt sent to Gemini to generate the slide image. No speaker notes in this block.

---

## 3. Speaker notes (last segment, after the final `---`)

- **First line of the segment:** `## Speaker Notes`
- Then one subsection per slide:  
  `### Slide NN —` (two-digit `NN`; you may add the slide title after the dash for readability).
- The **notes body** for that slide is everything after the `###` line until the next `### Slide …` or the end of the segment.

**Required in each slide’s notes:** a **Say:** line.

- Put the **exact words the speaker should say** (the script) under **Say:**. RenderDeck uses only the text after **Say:** when `--say-only` is passed (e.g. for video generation).
- You may also include **Timing**, **Transition**, **Defensive note**, or other labels before or after **Say:**; those are for presenter reference. The “say” content is what goes after **Say:**.

Do not put `---` inside the Speaker Notes segment.

---

## File structure summary

```
# Presentation Title

## General
... audience, tone, context ...

## Global Rules
... visual rules ...

---

## Slide 01 — First slide title

... image prompt for slide 01 ...

---

## Slide 02 — Second slide title

... image prompt for slide 02 ...

---

...

---

## Speaker Notes

### Slide 01 — First slide title

**Say:** The exact words the speaker says for this slide. ...

**Timing:** ...
**Transition:** ...

### Slide 02 — Second slide title

**Say:** ...

---
```

---

## Checklist

- [ ] Single H1; optional `## General` and/or `## Global Rules` in the first block.
- [ ] Each slide in its own segment; first line is `## Slide NN — Title` with two-digit `NN`.
- [ ] Each slide segment contains only the image prompt (no speaker notes).
- [ ] Last segment starts with `## Speaker Notes`; each slide has `### Slide NN — …` and a notes body.
- [ ] Each slide’s notes include a **Say:** line with the speaker script (the “say” content).

---

## Example (snippet)

**Slide block:**
```markdown
## Slide 01 — Migrations Without Disruption

Create a wide-format presentation slide (16:9) with a Deep Purple background...
```

**Speaker notes segment:**
```markdown
## Speaker Notes

### Slide 01 — Migrations Without Disruption

**Say:** Thanks for having us. I'm [name], this is Majid. We're from Exalate. Today we want to walk you through how Exalate handles migrations — specifically the cases where your existing tools hit their limits. We'll keep it practical: real constraints, real customer examples, and a live demo.

**Timing:** ~30 seconds. Title slide — don't linger.
**Transition:** Advance immediately after the intro.
```

Use this format whenever you create or regenerate a slide prompt file for renderdeck.
