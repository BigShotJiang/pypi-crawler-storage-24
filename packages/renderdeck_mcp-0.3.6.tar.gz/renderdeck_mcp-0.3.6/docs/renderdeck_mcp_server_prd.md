# RenderDeck MCP Server — Product Requirements Document

## General

**Version:** 1.0 — DRAFT
**Date:** March 16, 2026
**Status:** For Review
**Classification:** Internal / Confidential
**Development Methodology:** Exalate SDD (Specification Driven Development)

---

## 1. What This Document Covers

This PRD defines the requirements for wrapping RenderDeck — currently a single-file Python CLI script (`renderdeck.py`) that parses a slide prompt file, generates images via Nano Banana, and assembles a presentation — as an MCP server. The MCP server enables external LLMs to:

1. **Learn** how to produce a valid slide prompt file by reading RenderDeck's format spec, brand guidelines, structure instructions, and presentation craft knowledge — all served as MCP resources from a single bundled reference document.
2. **Submit** that slide prompt file and receive a finished `.pptx` presentation written to a local file path.

**In scope:** MCP resource serving, slide prompt file parsing, image generation via Nano Banana / Nano Banana Pro, `.pptx` assembly via python-pptx (replacing the current Google Slides output), local file delivery, concurrent image generation, prompt-level caching for incremental slide updates.

**Out of scope (for now):** Storyline generation, Google Slides export, editable text layers in `.pptx` (image-only backgrounds for v1.0).

---

## 2. Context — RenderDeck As It Exists Today

RenderDeck is a **single Python script** (`renderdeck.py`). No web UI, no database, no web server. It runs as:

```
python renderdeck.py <presentation.md>
```

It executes six sequential phases: startup → parse markdown → authenticate Google → generate images (Nano Banana) → build Google Slides presentation → print URL. All credentials come from a `.env` file. Image caching uses a `cache_manifest.json` per deck that tracks content hashes and options hashes — only changed slides are regenerated.

Key architectural facts from the script spec:
- Single file, self-contained, no framework dependencies
- Idempotent: cached images reused when prompt content + options are unchanged
- Content hash per slide (derived from General + Global Rules + slide prompt)
- Options hash per run (aspect ratio + Gemini model)
- `--regenerate-slide` flag forces regeneration even if cache matches
- Text-only fallback per slide on image generation failure
- No partial presentations: complete deck or nothing (cleanup on failure)

The MCP server wraps this logic, replacing the Google Slides output with `.pptx` and adding concurrent image generation.

---

## 3. Problem Statement

### 3.1 Current Workflow

```
LLM (Claude, GPT, etc.)
    │  Reference material (format spec, brand guidelines, craft knowledge)
    │  provided manually via project knowledge or paste
    │
    │  Conversation: storyline elaboration, narrative structure,
    │  slide-by-slide refinement with human
    │
    │  Produces slide prompt file (.md)
    ▼
Human runs: python renderdeck.py presentation.md
    │  Waits for image generation + Google Slides assembly
    ▼
Google Slides URL
```

Two bottlenecks: the LLM depends on manually-provided reference material, and a human must run the CLI and manage the Google Slides output.

### 3.2 Target Workflow

```
LLM connects to RenderDeck MCP Server
    │
    │  Reads renderdeck://reference (format spec, brand guidelines,
    │  structure instructions, presentation craft, example)
    │
    │  Conversation with human: storyline elaboration, narrative
    │  structure, slide-by-slide refinement
    │  (this creative phase happens in the LLM, not in RenderDeck)
    │
    │  Once storyline is agreed:
    │  MCP tool call: generate_deck(slide_prompt_content, output_path)
    ▼
RenderDeck MCP Server
    │  Parses → generates images (concurrent) → assembles .pptx → writes file
    ▼
/path/to/presentation.pptx (returned as tool result)
    │
    │  Human reviews .pptx
    │  Requests changes → LLM updates prompt file → re-submits
    │  (only changed slides regenerated — cache handles this)
    ▼
Final .pptx
```

The creative work (storyline, narrative, prompt writing) stays in the LLM conversation. RenderDeck handles the production work (image generation, deck assembly). The human reviews and iterates — caching ensures only changed slides are regenerated on each iteration.

### 3.3 Why MCP

**RenderDeck was designed for MCP.** The PRD v2.0 imposed MCP readiness as a hard architectural constraint. Typed service interfaces, no HTTP coupling.

**Resources solve the knowledge problem.** The LLM reads format spec, brand guidelines, and craft knowledge from a single MCP resource — no manual paste, no stale project knowledge copies.

**Client universality.** Claude Desktop, Claude Code, Cursor, VS Code, ChatGPT — one server serves all.

**Caching enables iterative workflows.** The LLM submits, the human reviews, the LLM revises specific slides, resubmits. Only changed slides are regenerated. This iterative loop is natural in MCP's persistent session model.

---

## 4. System Architecture

### 4.1 Component Overview

```
┌────────────────────────────────────────────────────────────┐
│                    MCP Clients                             │
│  Claude Desktop · Claude Code · Cursor · ChatGPT          │
└───────────────────────┬────────────────────────────────────┘
                        │ JSON-RPC 2.0 (stdio)
                        ▼
┌────────────────────────────────────────────────────────────┐
│               RenderDeck MCP Server                        │
│                                                            │
│  RESOURCE                                                  │
│  └── renderdeck://reference (single bundled doc)           │
│                                                            │
│  TOOLS                                                     │
│  ├── generate_deck         (prompt file → .pptx)           │
│  ├── validate_prompt_file  (dry-run validation)            │
│  ├── regenerate_slide      (retry/revise one slide)        │
│  ├── setup_gemini_key      (store + validate API key)      │
│  ├── get_setup_status      (config readiness check)        │
│  └── update_settings       (model, aspect ratio, etc.)     │
│                                                            │
│  PROMPTS                                                   │
│  ├── create_deck                                           │
│  └── check_and_fix                                         │
└──────┬─────────────────────────────┬───────────────────────┘
       │                             │
       ▼                             ▼
┌────────────────────┐   ┌──────────────────────────────────┐
│  Nano Banana / Pro │   │  python-pptx                     │
│  (concurrent calls)│   │  (.pptx assembly, local file)    │
└────────────────────┘   └──────────────────────────────────┘
```

### 4.2 Deployment

Standalone Python process. Local. stdio transport. No Docker, no database, no web server.

```json
{
  "mcpServers": {
    "renderdeck": {
      "command": "uvx",
      "args": ["renderdeck-mcp", "serve"]
    }
  }
}
```

### 4.3 Configuration

Single required secret: Google Gemini API key. Provided via `setup_gemini_key` MCP tool or `GOOGLE_GEMINI_API_KEY` environment variable.

Config persisted to `~/.renderdeck/config.json`. Gemini API key encrypted at rest (Fernet).

### 4.4 Relationship to Existing `renderdeck.py`

The MCP server reuses the core logic from `renderdeck.py` but with these changes:

| Aspect | `renderdeck.py` (current) | MCP server (new) |
|---|---|---|
| Invocation | CLI: `python renderdeck.py deck.md` | MCP: `generate_deck` tool call |
| Output format | Google Slides (via API) | `.pptx` (via python-pptx) |
| Image generation | Sequential | Concurrent (configurable parallelism) |
| Credentials | `.env` file | MCP setup tool + `~/.renderdeck/config.json` |
| Google OAuth | Required (Slides API) | Not required (no Google Slides) |
| Caching | `cache_manifest.json` per deck | Same mechanism, same manifest format |
| Progress | stderr (VERBOSE=true) | MCP progress notifications |
| Reference docs | External (README, manual paste) | MCP resource (`renderdeck://reference`) |

The parser, cache manifest logic, Gemini API client, and image compression can be extracted from `renderdeck.py` and reused. The Google Slides build phase is replaced with python-pptx assembly.

---

## 5. MCP Interface Definitions

### 5.1 Resource

A single bundled reference document that contains everything an LLM needs to produce a valid, brand-compliant slide prompt file:

| Resource URI | Description |
|---|---|
| `renderdeck://reference` | Combined document containing: (1) slide prompt file format specification — markdown structure, H1/General/Global Rules front matter, slide blocks, speaker notes with Say/Timing/Transition/Defensive labels; (2) brand guidelines — color palette, typography, approved patterns, slide furniture, punctuation conventions; (3) structure instructions — placeholder handling for transparent-background images; (4) presentation craft — the 11-point image prompt checklist, style anchor concept, speaker notes as stage directions, visual hierarchy, slide density categories, pacing; (5) annotated example — a representative slide prompt excerpt demonstrating all conventions |

**Single file for easy distribution.** The reference document is one markdown file bundled with the package. It can also be loaded from a custom path for organizations with their own brand guidelines.

**Updatable without code changes.** Replace the file, restart the server.

### 5.2 Tools

#### `generate_deck`

Primary tool. Accepts slide prompt file content, generates images, assembles `.pptx`, writes to disk.

| Parameter | Type | Required | Description |
|---|---|---|---|
| `slide_prompt_content` | string | Yes | Full slide prompt file (markdown) |
| `output_path` | string | No | File path for `.pptx`. Default: `~/Documents/RenderDeck/{title}_{timestamp}.pptx` |
| `image_quality` | enum: `draft` \| `final` | No | `draft` = Nano Banana. `final` = Nano Banana Pro. Default: `final` |
| `project_name` | string | No | Identifier for caching. Slides are cached per project. Resubmitting with the same project_name reuses images for unchanged slides. Default: derived from H1 title |

**Caching behavior:** Images are cached per project in `~/.renderdeck/cache/{project_name}/`. A `cache_manifest.json` tracks per-slide content hashes (General + Global Rules + slide prompt) and an options hash (aspect ratio + model). On resubmission:
- Unchanged slides → cached image reused, no Gemini call
- Changed slides → regenerated
- Changed General/Global Rules → all slides regenerated (content hash changes for all)
- Changed model or aspect ratio → all slides regenerated (options hash changes)

This enables the iterative workflow: human reviews, requests changes to 3 slides, LLM updates those 3 prompts, resubmits — only 3 images regenerated.

**Progress notifications:**
- `{"phase": "parsing", "slide_count": N}`
- `{"phase": "image_generation", "slide": N, "total": T, "title": "...", "cached": bool}` (per slide)
- `{"phase": "assembly", "status": "building_pptx"}`
- `{"phase": "complete", "output_path": "...", "slides_generated": N, "slides_cached": N}`

**Output:**
```json
{
  "output_path": "/absolute/path/to/deck.pptx",
  "slide_count": 15,
  "slides_generated": 3,
  "slides_cached": 12,
  "image_results": [
    {"slide_number": 1, "title": "...", "status": "cached"},
    {"slide_number": 2, "title": "...", "status": "generated"},
    {"slide_number": 3, "title": "...", "status": "error", "error": "content policy block"}
  ],
  "warnings": [],
  "cost_estimate": "$0.36 (3 images @ $0.12 each)"
}
```

#### `validate_prompt_file`

Dry run. Validates format without generating.

| Parameter | Type | Required | Description |
|---|---|---|---|
| `slide_prompt_content` | string | Yes | Slide prompt file content |

**Output:** `{valid, slide_count, slides: [{number, title}], errors: [{slide_number, line_number, message}], warnings}`.

#### `regenerate_slide`

Force-regenerate specific slides regardless of cache state. Reassembles `.pptx`.

| Parameter | Type | Required | Description |
|---|---|---|---|
| `project_name` | string | Yes | Project identifier (matches previous `generate_deck` call) |
| `slide_numbers` | array of int | Yes | Slides to regenerate (e.g., [3, 7, 12]) |
| `output_path` | string | No | Path for updated `.pptx` |

Equivalent to `renderdeck.py --regenerate-slide 03 07 12`. Forces Gemini API calls for those slides, updates cache manifest, reassembles `.pptx`.

#### `setup_gemini_key`

Validates and stores Gemini API key.

| Parameter | Type | Required | Description |
|---|---|---|---|
| `api_key` | string | Yes | Google Gemini API key |

Validates via lightweight API call. Encrypts and stores. Returns error if invalid.

#### `get_setup_status`

Reports configuration readiness.

**Output:** `{gemini_key_configured, gemini_model, aspect_ratio, default_output_dir, config_path, ready, issues}`.

#### `update_settings`

Updates optional configuration.

| Parameter | Type | Required | Description |
|---|---|---|---|
| `gemini_image_model` | string | No | Model name |
| `aspect_ratio` | string | No | `WIDE` or `STANDARD` |
| `default_output_dir` | string | No | Output directory |
| `gemini_max_retries` | int | No | Max Gemini retries (default: 3) |
| `max_concurrent_images` | int | No | Concurrent Gemini calls (default: 3) |
| `verbose` | boolean | No | Detailed logging |

### 5.3 Prompts

| Prompt Name | Description | Arguments |
|---|---|---|
| `create_deck` | Guided workflow: read reference, validate, generate, return path | `slide_prompt_content`, `image_quality?` |
| `check_and_fix` | Validate and describe errors with fixes | `slide_prompt_content` |

---

## 6. Slide Prompt File Parser

Reuses parsing logic from `renderdeck.py` §4.1. The parser splits the markdown on `---` separators, extracts H1 title, optional H2 subtitle, Global Rules, slide blocks (`## Slide NN — Title` + body as image prompt), and Speaker Notes (`### Slide NN` sections with `Say:` lines).

### 6.1 Validation

All errors include line numbers. Collected together (not fail-on-first).

| Rule | Error |
|---|---|
| Single `# H1` | "No H1 found" or "Multiple H1" |
| Zero-padded two-digit slide numbers | "Slide number not zero-padded" |
| No duplicate slide numbers | "Duplicate at lines X and Y" |
| Heading format `## Slide NN — Title` | Warning: "Heading does not match pattern — block skipped" (matches `renderdeck.py` behavior) |
| Slide count > 30 | Warning (not error — matches `renderdeck.py` behavior) |
| Missing Speaker Notes section | No error — slides get empty notes (matches `renderdeck.py`) |
| Orphan speaker notes (no matching slide) | Warning |
| `Say:` line per slide | Warning (not blocking) |

Note: validation behavior matches `renderdeck.py` §7 — speaker notes missing is a warning, not a fatal error. Slide count > 30 is a warning. This preserves compatibility.

### 6.2 .pptx Assembly

Each slide in the `.pptx`:
1. **Full-slide background image** — PNG from Nano Banana, set as slide background covering full 16:9 (or 4:3) area
2. **Speaker notes** — full notes body attached to the slide's notes page

**v1.0: Image-only backgrounds.** No editable text layers, no branding applied to `.pptx` structure. All visual content (text, layout, colors, furniture) is baked into the Nano Banana image. Editable text layers deferred to v2.0.

---

## 7. Concurrent Image Generation

`renderdeck.py` generates images sequentially. The MCP server adds concurrent generation using Python's `asyncio` with a configurable concurrency limit (default: 3 simultaneous Gemini calls).

Concurrency is bounded to avoid Gemini rate limits. Each call retains the existing retry logic (exponential backoff on 429/503). The progress notification stream reports slides as they complete, not in order.

If a slide fails after retries, it falls back to text-only (no background image) — same as `renderdeck.py` behavior. Other slides are unaffected.

---

## 8. Functional Requirements

| ID | Requirement | Detail | Priority |
|---|---|---|---|
| FR-001 | Prompt file parsing | Parse per `renderdeck.py` §4.1 rules | Must Have |
| FR-002 | Format validation | Validate with line numbers, collect all errors/warnings | Must Have |
| FR-003 | Concurrent image generation | Configurable parallelism (default: 3) | Must Have |
| FR-004 | Cache manifest | Per-project `cache_manifest.json` with content + options hashes. Reuse unchanged slides | Must Have |
| FR-005 | .pptx assembly | Background images + speaker notes via python-pptx | Must Have |
| FR-006 | Local file output | Write `.pptx` to specified or default path, return absolute path | Must Have |
| FR-007 | Progress streaming | Per-slide notifications including cache status | Must Have |
| FR-008 | Partial failure handling | Text-only fallback per slide, continue on errors | Must Have |
| FR-009 | stdio transport | stdin/stdout for local MCP clients | Must Have |
| FR-010 | Gemini key setup via MCP | `setup_gemini_key` + `get_setup_status` | Must Have |
| FR-011 | Config persistence | `~/.renderdeck/config.json`, encrypted key | Must Have |
| FR-012 | Env var override | `GOOGLE_GEMINI_API_KEY` overrides stored key | Must Have |
| FR-013 | Reference resource | `renderdeck://reference` — single combined document | Must Have |
| FR-014 | Dry-run validation | `validate_prompt_file` tool | Should Have |
| FR-015 | Force-regenerate | `regenerate_slide` tool with slide number list | Should Have |
| FR-016 | Cost estimate | In `generate_deck` result | Should Have |
| FR-017 | Configurable resource path | Load reference doc from custom path | Should Have |
| FR-018 | Image compression | Compress large PNGs (Pillow) before embedding in .pptx | Should Have |

---

## 9. Non-Functional Requirements

| ID | Requirement | Detail | Priority |
|---|---|---|---|
| NFR-001 | Standalone process | No Docker, database, or web server | Must Have |
| NFR-002 | Python package | `pip install` or `uvx` | Must Have |
| NFR-003 | Throughput | 15 slides: < 60s draft, < 3min final (with concurrency) | Should Have |
| NFR-004 | Python MCP SDK | FastMCP 1.x | Must Have |
| NFR-005 | Only Gemini external | Everything else local | Must Have |
| NFR-006 | Logging | stderr, configurable verbosity | Must Have |
| NFR-007 | Cross-platform | macOS, Linux, Windows. Python 3.12+ | Should Have |
| NFR-008 | Cache compatibility | Cache manifest format compatible with `renderdeck.py` | Should Have |

---

## 10. Implementation Plan — Epic Breakdown

### Epic 1: Slide Prompt File Parser and Validation

**Goal:** Extract and adapt the parser from `renderdeck.py` into a testable module.

Tasks:
- Extract parsing logic from `renderdeck.py` §4.1 into `parser/prompt_file.py`
- Extract validation logic with line-number error reporting
- Implement General context prepend (§2.4 format)
- Implement content hash computation (matching `renderdeck.py` cache manifest format)
- Test suite: Gartner prompts fixture, malformed files, edge cases

**Acceptance Criteria:**
- VERIFY: Gartner prompt file parsed into correct slides with titles, prompts (General prepended), notes
- VERIFY: Duplicate slide numbers → error with line numbers
- VERIFY: File with 31 slides → warning (not error), processing continues
- VERIFY: Missing Speaker Notes → no error, slides get empty notes
- VERIFY: Content hashes match those produced by `renderdeck.py` for the same input

### Epic 2: MCP Server, Concurrent Image Generation, and .pptx Assembly

**Goal:** MCP server with `generate_deck` producing `.pptx` with concurrent image generation and caching.

Tasks:
- Python project setup (pyproject.toml, dependencies)
- MCP server with FastMCP (stdio transport)
- Gemini API client with retry logic, adapted from `renderdeck.py` §4.2
- Concurrent image generation (asyncio, configurable limit)
- Cache manifest implementation (compatible with `renderdeck.py` format)
- .pptx assembly via python-pptx (background images + speaker notes)
- Image compression for large PNGs (Pillow, matching `renderdeck.py` §4.3.2)
- Progress notifications (per-slide, with cache status)
- `generate_deck` tool with full pipeline

**Acceptance Criteria:**
- VERIFY: MCP Inspector lists `generate_deck` with correct schema
- VERIFY: Gartner prompt file → `.pptx` with all slides, images, speaker notes
- VERIFY: Resubmitting same prompt file → all slides cached, zero Gemini calls
- VERIFY: Changing 2 slides and resubmitting → only 2 images regenerated, rest cached
- VERIFY: Changing Global Rules → all slides regenerated
- VERIFY: Concurrent generation: 15-slide deck completes in < 60s (draft) with 3 concurrent calls
- VERIFY: Image error on slide 7 → text-only fallback, other slides unaffected, `.pptx` produced

### Epic 3: MCP Resource and Reference Document

**Goal:** Single bundled reference document served as MCP resource. LLM self-sufficient.

Tasks:
- Compile reference document from: format spec, brand guidelines, structure instructions, presentation craft knowledge, annotated example excerpt
- Implement MCP resource handler
- Register `renderdeck://reference`
- Implement configurable resource path (FR-017)
- Test: LLM given only the resource produces a valid prompt file

**Acceptance Criteria:**
- VERIFY: `renderdeck://reference` returns the complete combined document
- VERIFY: LLM reading only this resource (no other context) produces a prompt file passing `validate_prompt_file` with zero errors
- VERIFY: Custom resource path → server loads from that path instead of bundled file
- VERIFY: Updated file on disk → server restart → updated content served

### Epic 4: Setup Tools, Supporting Tools, and Client Integration

**Goal:** LLM-guided setup. Validation, force-regenerate, settings. Client docs.

Tasks:
- `setup_gemini_key` with validation and encrypted storage
- Config persistence (`~/.renderdeck/config.json`)
- `GOOGLE_GEMINI_API_KEY` env var override
- `get_setup_status`, `update_settings` tools
- `validate_prompt_file` tool
- `regenerate_slide` tool (force-regenerate + reassemble)
- MCP prompt templates (`create_deck`, `check_and_fix`)
- Claude Desktop, Claude Code, Cursor configuration examples
- Integration guide with example conversation flow

**Acceptance Criteria:**
- VERIFY: No config → `get_setup_status` returns `ready: false` with guidance
- VERIFY: Valid key → encrypted storage → `ready: true`
- VERIFY: `validate_prompt_file` with 3 errors → all 3 with line numbers
- VERIFY: `regenerate_slide` for slides [3, 7] → those 2 regenerated, rest untouched, updated `.pptx`
- VERIFY: Config examples work on standard macOS dev machine

---

## 11. Risk Register

| Risk | Likelihood | Impact | Mitigation |
|---|---|---|---|
| Gemini rate limits with concurrent calls | Medium | High | Configurable concurrency (default 3). Exponential backoff per call. Reduce concurrency on repeated 429s |
| Large PNGs exceed reasonable .pptx size | Medium | Medium | Pillow compression (matching `renderdeck.py`). Default 1920×1080 |
| Reference doc too large for LLM context | Low | Medium | Single file, estimated ~20KB. Well within context limits. Monitor and trim if needed |
| Cache manifest format drift from `renderdeck.py` | Low | Medium | Same hash algorithm and manifest schema. Shared test fixtures |
| Gemini key in chat history | Medium | Medium | Tool description warns LLM. Encrypted at rest. Env var available |

---

## 12. Open Questions

1. **General context injection.** Should the parser prepend General to each slide's prompt (stored prompt is complete) or keep it separate (prepended at generation time)? Keeping separate means changing General doesn't require re-parsing. But `renderdeck.py` computes the hash from the combined prompt, so the cache manifest needs the full prompt regardless. **Recommendation:** Follow `renderdeck.py` — prepend at hash-computation time, not at storage time.

2. **Prompt file format versioning.** Should the format carry a version identifier (e.g., `<!-- renderdeck-format: v1 -->`)? Useful for forward compatibility. Low effort to add.

---

## 13. SDD Project Configuration

### 13.1 Recommended sdd-config.yaml

```yaml
commands:
  lint:
    full: "ruff check src/ tests/"
    single_file: "ruff check {file}"
  format:
    full: "ruff format src/ tests/"
    single_file: "ruff format {file}"
  typecheck: "mypy src/ --strict"
  test:
    full: "pytest tests/ -v --tb=short"
    single_file: "pytest {file} -v --tb=short"
    coverage: "pytest tests/ --cov=renderdeck_mcp --cov-report=json:coverage.json"
    coverage_report_path: "coverage.json"
  build: "python -m build"

protected_files:
  - "pyproject.toml"
  - ".env"
  - "~/.renderdeck/config.json"

validation:
  design:
    required_sections:
      - "Data Model"
      - "API"
      - "Edge Cases"
      - "Error"
      - "Acceptance Criteria"
  test:
    coverage_threshold: 80
    enforce_coverage: true
  implementation:
    max_file_lines: 400

orchestrator:
  max_retries_per_phase: 3
  max_code_review_loops: 2
  max_validation_cycles: 5
  auto_commit: true
  commit_prefix: "[SDD]"
  turbo_mode: false
  design_review: true
  security_review: false
  test_phases: ["unit"]
  auto_pr: true
  base_branch: "main"
  pr_default_reviewers: []

  auto_challenge_phases:
    best_practices: true
    project_goal: true
    pm_epics: true
    pm_tasks: false
    design: true

  challenger_perspectives:
    best_practices: ["technical"]
    project_goal: ["business", "technical"]
    pm_epics: ["business", "technical"]
    design: ["technical", "security"]

jira:
  enabled: true
  project_key: "TBD"
  issue_prefix: "TBD"
  epic_issue_type: ""
  task_issue_type: ""
  transitions:
    design_started: ""
    pr_created: ""
    pr_merged: ""

bitbucket:
  repo_url: ""
  default_branch: "main"

lessons:
  max_entries: 50
  escalation_threshold: 3
  archive_policy: "rotate"
```

### 13.2 Technology Stack

| Component | Technology |
|---|---|
| Language | Python 3.12+ |
| MCP SDK | `mcp` (FastMCP) 1.x |
| Image generation | `google-generativeai` |
| .pptx assembly | `python-pptx` |
| Image processing | `Pillow` (compression, validation) |
| Secret encryption | `cryptography` (Fernet) |
| Async | `asyncio` (concurrent image generation) |
| Testing | `pytest` + `pytest-cov` + `pytest-asyncio` |
| Linting | `ruff` |
| Type checking | `mypy` (strict) |
| Package format | `pyproject.toml` (PEP 621) |

### 13.3 Project Structure

```
renderdeck-mcp/
├── src/
│   └── renderdeck_mcp/
│       ├── __init__.py
│       ├── __main__.py              # python -m renderdeck_mcp serve
│       ├── server.py                # MCP server, tool + resource registration
│       ├── parser/
│       │   ├── __init__.py
│       │   ├── prompt_file.py       # Adapted from renderdeck.py §4.1
│       │   └── validator.py
│       ├── generation/
│       │   ├── __init__.py
│       │   ├── gemini.py            # Adapted from renderdeck.py §4.2
│       │   └── cache.py             # Cache manifest (compatible with renderdeck.py)
│       ├── assembly/
│       │   ├── __init__.py
│       │   └── pptx_builder.py
│       ├── tools/
│       │   ├── __init__.py
│       │   ├── generate_deck.py
│       │   ├── validate.py
│       │   ├── regenerate.py
│       │   └── setup.py
│       ├── resources/
│       │   ├── __init__.py
│       │   └── handler.py
│       └── config.py
├── resources/
│   └── renderdeck_reference.md      # Single bundled reference document
├── tests/
│   ├── fixtures/
│   │   ├── gartner_prompts.md
│   │   ├── minimal_valid.md
│   │   └── malformed/
│   ├── test_parser.py
│   ├── test_validator.py
│   ├── test_cache.py
│   ├── test_gemini.py
│   ├── test_pptx_builder.py
│   ├── test_resources.py
│   └── test_generate_deck.py
├── pyproject.toml
├── sdd-config.yaml
├── CLAUDE.md
└── README.md
```

---

## 14. Success Metrics

| Metric | Target |
|---|---|
| End-to-end (15 slides, Pro, cold cache) | < 3 min |
| End-to-end (15 slides, 2 changed, warm cache) | < 30s |
| Image success rate | ≥ 95% per slide |
| Validation accuracy | 100% known errors caught |
| LLM self-sufficiency | Valid prompt from `renderdeck://reference` alone |
| Client compatibility | Claude Desktop, Claude Code, MCP Inspector |
| Setup time | < 2 min install-to-first-deck |

---

## 15. Revision History

| Version / Date | Changes |
|---|---|
| v1.0 — 2026-03-16 | Initial draft. Based on `renderdeck.py` script spec v1.0. pptx output, concurrent generation, cache-based incremental updates, single reference resource, SDD config |

---

**END OF DOCUMENT**
