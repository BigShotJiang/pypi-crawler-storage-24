"""Tests for MCP prompt templates (create_deck and check_and_fix)."""

from __future__ import annotations

from renderdeck_mcp.prompts.templates import check_and_fix, create_deck


class TestCreateDeck:
    """Tests for the create_deck prompt template."""

    def test_returns_list_of_messages(self) -> None:
        result = create_deck(topic="AI in Healthcare")
        assert isinstance(result, list)
        assert len(result) == 1

    def test_message_has_role_and_content(self) -> None:
        result = create_deck(topic="AI in Healthcare")
        msg = result[0]
        assert msg["role"] == "user"
        assert isinstance(msg["content"], str)

    def test_includes_topic(self) -> None:
        result = create_deck(topic="Quarterly Review")
        assert "Quarterly Review" in result[0]["content"]

    def test_references_renderdeck_resource(self) -> None:
        result = create_deck(topic="test")
        assert "renderdeck://reference" in result[0]["content"]

    def test_references_validate_tool(self) -> None:
        result = create_deck(topic="test")
        assert "validate_prompt_file" in result[0]["content"]

    def test_references_generate_tool(self) -> None:
        result = create_deck(topic="test")
        assert "generate_deck" in result[0]["content"]

    def test_no_model_specific_instructions(self) -> None:
        result = create_deck(topic="test")
        content = result[0]["content"].lower()
        assert "gpt" not in content
        assert "claude" not in content
        assert "gemini" not in content


class TestCheckAndFix:
    """Tests for the check_and_fix prompt template."""

    def test_returns_list_of_messages(self) -> None:
        result = check_and_fix(content="# Test\n## Slide 01 — Intro\n")
        assert isinstance(result, list)
        assert len(result) == 1

    def test_message_has_role_and_content(self) -> None:
        result = check_and_fix(content="some content")
        msg = result[0]
        assert msg["role"] == "user"
        assert isinstance(msg["content"], str)

    def test_includes_content(self) -> None:
        result = check_and_fix(content="# My Deck\n## Slide 01 — First")
        assert "# My Deck" in result[0]["content"]

    def test_references_validate_tool(self) -> None:
        result = check_and_fix(content="test")
        assert "validate_prompt_file" in result[0]["content"]

    def test_instructs_error_by_error_fix(self) -> None:
        result = check_and_fix(content="test")
        content = result[0]["content"]
        assert "error" in content.lower()
        assert "fix" in content.lower()

    def test_no_model_specific_instructions(self) -> None:
        result = check_and_fix(content="test")
        content = result[0]["content"].lower()
        assert "gpt" not in content
        assert "claude" not in content
        assert "gemini" not in content
