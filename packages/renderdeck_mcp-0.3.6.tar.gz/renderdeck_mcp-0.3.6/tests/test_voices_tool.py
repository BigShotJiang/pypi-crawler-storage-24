"""Unit tests for renderdeck_mcp.tools.voices and renderdeck_mcp.voices."""

from __future__ import annotations

# ---------------------------------------------------------------------------
# TC-01: list_voices returns all voices with correct structure
# ---------------------------------------------------------------------------


def test_tc01_list_voices_returns_all_voices() -> None:
    """run_list_voices returns a list of all 30 voices with correct fields."""
    from renderdeck_mcp.tools.voices import run_list_voices

    result = run_list_voices()
    assert "voices" in result
    voices = result["voices"]
    assert isinstance(voices, list)
    assert result["total_count"] == len(voices)
    assert len(voices) == 30

    # Check structure of each voice entry
    for v in voices:
        assert "alias" in v
        assert "full_name" in v
        assert "locale" in v
        assert "gender" in v
        assert v["gender"] in ("Male", "Female")
        assert v["locale"] in ("en-US", "en-GB")


# ---------------------------------------------------------------------------
# TC-02: list_voices includes default voice info
# ---------------------------------------------------------------------------


def test_tc02_list_voices_includes_default() -> None:
    """Result includes default voice info and usage hint."""
    from renderdeck_mcp.tools.voices import run_list_voices

    result = run_list_voices()
    assert "default_voice" in result
    assert "aria" in str(result["default_voice"])
    assert "usage_hint" in result
    assert "samples_hint" in result


# ---------------------------------------------------------------------------
# TC-03: resolve_voice resolves aliases
# ---------------------------------------------------------------------------


def test_tc03_resolve_voice_aliases() -> None:
    """resolve_voice maps short aliases to full edge-tts names."""
    from renderdeck_mcp.voices import resolve_voice

    assert resolve_voice("aria") == "en-US-AriaNeural"
    assert resolve_voice("roger") == "en-US-RogerNeural"
    assert resolve_voice("sonia") == "en-GB-SoniaNeural"
    assert resolve_voice("ARIA") == "en-US-AriaNeural"  # case-insensitive


# ---------------------------------------------------------------------------
# TC-04: resolve_voice passes through full names
# ---------------------------------------------------------------------------


def test_tc04_resolve_voice_passthrough() -> None:
    """Unknown aliases are treated as full voice names and passed through."""
    from renderdeck_mcp.voices import resolve_voice

    assert resolve_voice("en-US-AriaNeural") == "en-US-AriaNeural"
    assert resolve_voice("custom-voice") == "custom-voice"


# ---------------------------------------------------------------------------
# TC-05: DEFAULT_VOICES has expected structure
# ---------------------------------------------------------------------------


def test_tc05_default_voices_structure() -> None:
    """DEFAULT_VOICES dict has correct structure for all entries."""
    from renderdeck_mcp.voices import DEFAULT_VOICES

    assert len(DEFAULT_VOICES) == 30
    for alias, info in DEFAULT_VOICES.items():
        assert isinstance(alias, str)
        assert alias == alias.lower(), f"Alias {alias!r} should be lowercase"
        assert "full_name" in info
        assert "locale" in info
        assert "gender" in info
        assert info["full_name"].endswith("Neural")


# ---------------------------------------------------------------------------
# TC-06: British voices are included
# ---------------------------------------------------------------------------


def test_tc06_british_voices_included() -> None:
    """At least 5 en-GB voices are in the catalogue."""
    from renderdeck_mcp.voices import DEFAULT_VOICES

    gb_voices = [a for a, v in DEFAULT_VOICES.items() if v["locale"] == "en-GB"]
    assert len(gb_voices) >= 5
    assert "sonia" in gb_voices
    assert "ryan" in gb_voices
    assert "thomas" in gb_voices


# ---------------------------------------------------------------------------
# TC-07: Voices are sorted in list_voices output
# ---------------------------------------------------------------------------


def test_tc07_voices_sorted_alphabetically() -> None:
    """Voices in list_voices output are sorted by alias."""
    from renderdeck_mcp.tools.voices import run_list_voices

    result = run_list_voices()
    aliases = [v["alias"] for v in result["voices"]]
    assert aliases == sorted(aliases)


# ---------------------------------------------------------------------------
# TC-08: server.py list_voices wrapper calls implementation
# ---------------------------------------------------------------------------


def test_tc08_server_wrapper() -> None:
    """server.list_voices calls run_list_voices and returns its result."""
    from renderdeck_mcp.server import list_voices

    result = list_voices()
    assert "voices" in result
    assert result["total_count"] == 30
