"""Tests for the MCP resource handler (renderdeck://reference)."""

from __future__ import annotations

import logging
from pathlib import Path
from unittest.mock import patch

import pytest

from renderdeck_mcp.resources.handler import _BUNDLED_PATH, _load_reference, get_reference


class TestLoadReference:
    """Tests for _load_reference resolution logic."""

    def test_returns_bundled_content(self) -> None:
        """Default: returns the bundled reference document."""
        content = _load_reference()
        assert len(content) > 0
        assert "RenderDeck" in content

    def test_bundled_path_points_to_existing_file(self) -> None:
        """The _BUNDLED_PATH constant resolves to the actual file."""
        assert _BUNDLED_PATH.is_file(), f"Bundled path not found: {_BUNDLED_PATH}"

    def test_custom_path_overrides_bundled(self, tmp_path: Path) -> None:
        """RENDERDECK_REFERENCE_PATH env var overrides the bundled file."""
        custom_file = tmp_path / "custom_reference.md"
        custom_file.write_text("# Custom Reference\n\nCustom content.", encoding="utf-8")

        with patch.dict("os.environ", {"RENDERDECK_REFERENCE_PATH": str(custom_file)}):
            content = _load_reference()

        assert content == "# Custom Reference\n\nCustom content."

    def test_custom_path_missing_falls_back_to_bundled(
        self, tmp_path: Path, caplog: pytest.LogCaptureFixture
    ) -> None:
        """Missing custom path logs warning and falls back to bundled."""
        missing = str(tmp_path / "nonexistent.md")

        with (
            patch.dict("os.environ", {"RENDERDECK_REFERENCE_PATH": missing}),
            caplog.at_level(logging.WARNING),
        ):
            content = _load_reference()

        assert len(content) > 0  # got bundled content
        assert "not found, falling back" in caplog.text

    def test_bundled_missing_raises(self, tmp_path: Path) -> None:
        """Missing bundled file raises FileNotFoundError."""
        fake_path = tmp_path / "nope.md"

        with (
            patch("renderdeck_mcp.resources.handler._BUNDLED_PATH", fake_path),
            patch.dict("os.environ", {}, clear=True),
        ):
            # Ensure RENDERDECK_REFERENCE_PATH is not set
            with pytest.raises(FileNotFoundError, match="Bundled reference document not found"):
                _load_reference()

    def test_custom_missing_and_bundled_missing_raises(self, tmp_path: Path) -> None:
        """Both custom and bundled missing raises FileNotFoundError."""
        with (
            patch.dict("os.environ", {"RENDERDECK_REFERENCE_PATH": str(tmp_path / "nope.md")}),
            patch("renderdeck_mcp.resources.handler._BUNDLED_PATH", tmp_path / "also_nope.md"),
        ):
            with pytest.raises(FileNotFoundError):
                _load_reference()


class TestGetReference:
    """Tests for the @mcp.resource decorated function."""

    def test_get_reference_returns_content(self) -> None:
        """get_reference() delegates to _load_reference()."""
        content = get_reference()
        assert "RenderDeck" in content
        assert len(content) > 100

    def test_reads_fresh_content_each_call(self, tmp_path: Path) -> None:
        """Each call reads from disk (no caching)."""
        custom_file = tmp_path / "ref.md"
        custom_file.write_text("version 1", encoding="utf-8")

        with patch.dict("os.environ", {"RENDERDECK_REFERENCE_PATH": str(custom_file)}):
            assert _load_reference() == "version 1"

            custom_file.write_text("version 2", encoding="utf-8")
            assert _load_reference() == "version 2"
