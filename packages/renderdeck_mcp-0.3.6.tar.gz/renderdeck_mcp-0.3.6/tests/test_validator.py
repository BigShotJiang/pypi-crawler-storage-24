"""Unit tests for the format-validator task.

Verifies validate_prompt_file(content: str) -> ValidationResult behaviour per
design.md rules V-1 through V-6 and all test cases in test-handoff.md.

Run with:
    pytest tests/test_validator.py --cov=renderdeck_mcp.parser.validator --cov-report=term-missing

All tests are pure Python — no I/O, no mocking, no network access. Test
fixtures are inline string constants defined at module level.
"""

from __future__ import annotations

import pytest

from renderdeck_mcp.parser.validator import (
    SlideInfo,
    ValidationError,
    ValidationResult,
    validate_prompt_file,
)

# ---------------------------------------------------------------------------
# Fixture helpers
# ---------------------------------------------------------------------------


def _make_valid_file(n: int) -> str:
    """Build a syntactically valid prompt file with *n* slides.

    Produces the canonical structure used in TC-01 and TC-08:
      - One H1 heading
      - A Global Rules section
      - *n* well-formed ``## Slide NN — Slide Title N`` blocks, each preceded
        by a ``---`` separator
    """
    lines = ["# Valid Deck\n\n## Global Rules\nRules.\n"]
    for i in range(1, n + 1):
        lines.append(f"---\n\n## Slide {i:02d} — Slide Title {i}\n\nPrompt text.\n")
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Module-level fixtures as string constants
# ---------------------------------------------------------------------------

MINIMAL_VALID = """\
# My Presentation

## Global Rules
Use dark backgrounds.

---

## Slide 01 — Introduction

This is the image prompt for slide one.
"""

VALID_15_SLIDES = _make_valid_file(15)
VALID_31_SLIDES = _make_valid_file(31)

# TC-10: a single file that triggers three distinct errors simultaneously:
#   1. No H1 (missing H1)
#   2. "## Slide 5 — Bad Number" — non-zero-padded single digit
#   3. "## Slide 02" appears twice — duplicate slide number
COLLECT_ALL = (
    "## Global Rules\nRules.\n\n"  # no H1
    "---\n\n"
    "## Slide 5 — Bad Number\n\nPrompt.\n\n"  # non-zero-padded (V-2)
    "---\n\n"
    "## Slide 02 — First\n\nPrompt.\n\n"
    "---\n\n"
    "## Slide 02 — Duplicate\n\nPrompt.\n"  # duplicate slide 02 (V-3)
)


# ---------------------------------------------------------------------------
# TC-01  test_valid_15_slides
# ---------------------------------------------------------------------------


def test_valid_15_slides() -> None:
    """A well-formed 15-slide file produces valid=True with zero errors and warnings.

    Covers: boundary criterion — valid file, 15 slides, no issues.
    Design rule: all V-1 through V-6 pass cleanly; result.valid derives from
    len(errors) == 0.
    """
    result: ValidationResult = validate_prompt_file(VALID_15_SLIDES)

    assert result.valid is True
    assert result.slide_count == 15
    assert len(result.errors) == 0
    assert len(result.warnings) == 0
    assert len(result.slides) == 15

    first: SlideInfo = result.slides[0]
    assert first.number == 1
    assert first.title == "Slide Title 1"
    assert isinstance(first.line_number, int)
    assert first.line_number >= 1


# ---------------------------------------------------------------------------
# TC-02  test_missing_h1
# ---------------------------------------------------------------------------


def test_missing_h1() -> None:
    """A file with no H1 heading produces one error at line 1 with message 'No H1'.

    Covers: functional criterion — Missing H1 → error with line number (V-1).
    Design rule: when h1_lines is empty, add ValidationError(line_number=1,
    slide_number=None, message='No H1 title found').
    """
    content = "## Global Rules\nRules.\n\n---\n\n## Slide 01 — Title\n\nPrompt.\n"
    result = validate_prompt_file(content)

    assert result.valid is False
    assert len(result.errors) == 1

    err: ValidationError = result.errors[0]
    assert err.slide_number is None
    assert "No H1" in err.message
    assert err.line_number == 1


# ---------------------------------------------------------------------------
# TC-03  test_multiple_h1
# ---------------------------------------------------------------------------


def test_multiple_h1() -> None:
    """A file with two H1 headings produces an error referencing both line numbers.

    Covers: functional criterion — Multiple H1s → error with line numbers of both (V-1).
    Design rule: for each H1 beyond the first, emit one ValidationError whose
    line_number equals the first H1's line and whose message contains the
    duplicate's line number.
    """
    # Line 1: "# First Title", Line 9: "# Second Title" (0-indexed: line 9)
    content = "# First Title\n\n---\n\n## Slide 01 — Title\n\nPrompt.\n\n# Second Title\n"
    result = validate_prompt_file(content)

    assert result.valid is False

    # At least one error must reference both H1 headings
    h1_errors = [e for e in result.errors if "Multiple H1" in e.message or "H1" in e.message]
    assert h1_errors, f"No H1-related error found in: {result.errors}"

    combined_messages = " ".join(e.message for e in h1_errors)
    # The message must reference two different lines; both line 1 and line 9
    # are expected to appear in the error output in some form.
    assert "1" in combined_messages  # first H1 at line 1
    assert "9" in combined_messages  # second H1 at line 9


# ---------------------------------------------------------------------------
# TC-04 / TC-05  test_nonzero_padded  (parametrized)
# ---------------------------------------------------------------------------


@pytest.mark.parametrize(
    "bad_num,label",
    [
        ("3", "single digit"),
        ("003", "three digits"),
        ("00", "zero value"),
    ],
)
def test_nonzero_padded(bad_num: str, label: str) -> None:
    """Slide numbers that are not exactly two digits produce a 'not zero-padded' error.

    Covers: functional criterion — Non-zero-padded slide number → error with
    line number (V-2); also TC-05 boundary: three-digit number is similarly
    rejected.
    Design rule: heading matches RE_SLIDE_ANY_NUMBER but len(num_str) != 2 →
    ValidationError with 'not zero-padded' in message.
    """
    content = f"# Deck\n\n---\n\n## Slide {bad_num} — Title\n\nPrompt.\n"
    result = validate_prompt_file(content)

    assert not result.valid, f"Expected invalid result for {label} ({bad_num!r})"
    assert any("not zero-padded" in e.message for e in result.errors), (
        f"No 'not zero-padded' error for {label} ({bad_num!r}): {result.errors}"
    )


def test_nonzero_padded_slide_single_digit_line_number() -> None:
    """The 'not zero-padded' error line_number points to the malformed heading line.

    Covers: functional criterion — error carries the correct line number.
    Content layout: line 1='# Deck', line 2='', line 3='---', line 4='',
    line 5='## Slide 3 — Introduction' → expected line_number == 5.
    """
    content = "# Deck\n\n---\n\n## Slide 3 — Introduction\n\nPrompt.\n"
    result = validate_prompt_file(content)

    assert result.valid is False
    assert len(result.errors) == 1

    err = result.errors[0]
    assert "not zero-padded" in err.message
    assert "Slide 3" in err.message
    assert err.line_number == 5


def test_nonzero_padded_slide_three_digits() -> None:
    """A three-digit slide number (## Slide 003) is also rejected as not zero-padded.

    Covers: TC-05 — boundary of rule V-2 (len(num_str) != 2 rejects 3+ digits).
    """
    content = "# Deck\n\n---\n\n## Slide 003 — Introduction\n\nPrompt.\n"
    result = validate_prompt_file(content)

    assert result.valid is False
    assert len(result.errors) == 1
    assert "not zero-padded" in result.errors[0].message


# ---------------------------------------------------------------------------
# TC-06  test_duplicate_slide_numbers
# ---------------------------------------------------------------------------


def test_duplicate_slide_numbers() -> None:
    """Two well-formed headings with the same slide number produce one duplicate error.

    Covers: functional criterion — Duplicate slide numbers → error listing both
    line numbers (V-3).
    Design rule: build dict of slide_number → [line_numbers]; emit one
    ValidationError per duplicated number.
    """
    content = (
        "# Deck\n\n---\n\n"
        "## Slide 03 — First\n\nPrompt.\n\n---\n\n"
        "## Slide 03 — Second\n\nPrompt.\n"
    )
    result = validate_prompt_file(content)

    assert result.valid is False
    assert len(result.errors) == 1

    err = result.errors[0]
    assert err.slide_number == 3
    assert "Duplicate" in err.message or "duplicate" in err.message.lower()

    # Both line numbers must appear in the error message as substrings
    # Line 5: first "## Slide 03 — First", Line 11: second "## Slide 03 — Second"
    assert "5" in err.message
    assert "11" in err.message


# ---------------------------------------------------------------------------
# TC-07  test_malformed_heading_warning
# ---------------------------------------------------------------------------


def test_malformed_heading_warning() -> None:
    """A '## Slide' heading without a valid number/separator produces a warning and is skipped.

    Covers: functional criterion — Heading not matching '## Slide NN — Title'
    → warning (block skipped) (V-2 warning branch).
    Design rule: heading matches RE_SLIDE_CANDIDATE but neither RE_SLIDE_VALID
    nor RE_SLIDE_ANY_NUMBER → add warning "does not match ... block skipped".
    Warnings do not affect result.valid.
    """
    content = "# Deck\n\n---\n\n## Slide Intro\n\nPrompt.\n"
    result = validate_prompt_file(content)

    assert result.valid is True
    assert len(result.errors) == 0
    assert len(result.warnings) == 1
    assert "does not match" in result.warnings[0]
    assert result.slide_count == 0  # block was skipped, not counted


# ---------------------------------------------------------------------------
# TC-08  test_31_slides_warning
# ---------------------------------------------------------------------------


def test_31_slides_warning() -> None:
    """A file with 31 well-formed slides produces exactly one warning and remains valid.

    Covers: functional criterion — File with 31 slides → warning (not error),
    processing continues (V-4).
    Design rule: count of well-formed slide headings > 30 → add warning
    containing the count and 'performance'.
    """
    result = validate_prompt_file(VALID_31_SLIDES)

    assert result.valid is True
    assert len(result.errors) == 0
    assert len(result.warnings) == 1
    assert "31" in result.warnings[0]
    assert result.slide_count == 31


# ---------------------------------------------------------------------------
# TC-09  test_orphan_speaker_notes
# ---------------------------------------------------------------------------


def test_orphan_speaker_notes() -> None:
    """A '### Slide NN' with no matching slide body produces a warning.

    Covers: functional criterion — Orphan speaker notes (no matching slide) →
    warning (V-5).
    Design rule: for each ### Slide NN, if NN not in well-formed slide numbers
    → add warning containing the orphan number and 'no matching slide'.
    """
    content = (
        "# Deck\n\n---\n\n"
        "## Slide 01 — Title\n\nPrompt.\n\n"
        "## Speaker Notes\n\n"
        "### Slide 07 — Missing\n\n**Say:** Something.\n"
    )
    result = validate_prompt_file(content)

    assert result.valid is True
    assert len(result.errors) == 0
    assert len(result.warnings) == 1
    assert "07" in result.warnings[0]
    assert "no matching slide" in result.warnings[0]


# ---------------------------------------------------------------------------
# TC-10  test_collect_all_errors
# ---------------------------------------------------------------------------


def test_collect_all_errors() -> None:
    """A file with three distinct errors collects all three before returning.

    Covers: functional criterion — File with 3 errors → all 3 reported
    (not fail-on-first); design collect-all semantics (§1 and §4.2).
    The COLLECT_ALL fixture contains:
      - No H1 (V-1)
      - Non-zero-padded '## Slide 5' (V-2 error)
      - Duplicate '## Slide 02' (V-3)
    """
    result = validate_prompt_file(COLLECT_ALL)

    assert result.valid is False
    assert len(result.errors) == 3, f"Expected 3 errors but got {len(result.errors)}: " + "; ".join(
        e.message for e in result.errors
    )

    messages = [e.message for e in result.errors]
    # Each error category must be represented
    assert any("No H1" in m or "H1" in m for m in messages), "Missing H1 error not found"
    assert any("not zero-padded" in m for m in messages), "Non-zero-padded error not found"
    assert any("Duplicate" in m or "duplicate" in m.lower() for m in messages), (
        "Duplicate slide error not found"
    )


# ---------------------------------------------------------------------------
# TC-11  test_missing_speaker_notes_no_error
# ---------------------------------------------------------------------------


def test_missing_speaker_notes_no_error() -> None:
    """A file with no Speaker Notes section at all produces no error and no warning.

    Covers: boundary criterion — Missing Speaker Notes section → no error
    (matches renderdeck.py behaviour) (V-6).
    MINIMAL_VALID contains no '## Speaker Notes' block.
    """
    result = validate_prompt_file(MINIMAL_VALID)

    assert result.valid is True
    assert len(result.errors) == 0
    # No warning should reference speaker notes
    speaker_note_warnings = [w for w in result.warnings if "speaker notes" in w.lower()]
    assert not speaker_note_warnings, f"Unexpected speaker-notes warnings: {speaker_note_warnings}"


# ---------------------------------------------------------------------------
# TC-12  test_empty_string
# ---------------------------------------------------------------------------


def test_empty_string() -> None:
    """An empty string input returns a ValidationResult with at least one error.

    Covers: edge case — empty input → valid=False, 'No H1' error at line 1,
    slide_count == 0 (design §6 edge cases).
    The function must not raise; it always returns ValidationResult.
    """
    result = validate_prompt_file("")

    assert result.valid is False
    assert len(result.errors) >= 1
    assert "No H1" in result.errors[0].message
    assert result.slide_count == 0


# ---------------------------------------------------------------------------
# TC-13  test_line_numbers_are_accurate
# ---------------------------------------------------------------------------


def test_line_numbers_are_accurate() -> None:
    """Line numbers in errors precisely match the source line of the offending heading.

    Covers: line-number accuracy — integration of pass 1 (line-index scan) and
    pass 2 (rule evaluation).

    Source layout (1-based):
      Line 1: ""              (blank)
      Line 2: ""              (blank)
      Line 3: "# Real Title"
      Line 4: ""
      Line 5: ""
      Line 6: ""
      Line 7: "## Slide 3 — Bad"   ← non-zero-padded; error must report line 7
    """
    content = "\n\n# Real Title\n\n\n\n## Slide 3 — Bad\n\nPrompt.\n"
    result = validate_prompt_file(content)

    # Locate the non-zero-padded error
    padded_errors = [e for e in result.errors if "not zero-padded" in e.message]
    assert padded_errors, f"No 'not zero-padded' error found: {result.errors}"

    err = padded_errors[0]
    assert err.line_number == 7, (
        f"Expected line_number=7 for '## Slide 3 — Bad' but got {err.line_number}"
    )


# ---------------------------------------------------------------------------
# TC-14  test_h1_only_no_slides
# ---------------------------------------------------------------------------


def test_h1_only_no_slides() -> None:
    """A file with only an H1 heading and no slide blocks is valid with slide_count == 0.

    Covers: edge case — H1 only, no slides → valid=True, slide_count=0
    (design §6 edge cases).
    """
    result = validate_prompt_file("# Just a Title\n")

    assert result.valid is True
    assert result.slide_count == 0
    assert len(result.errors) == 0


# ---------------------------------------------------------------------------
# TC-15  test_valid_speaker_notes_matched
# ---------------------------------------------------------------------------


def test_valid_speaker_notes_matched() -> None:
    """Speaker notes that match an existing slide produce no warning.

    Covers: V-5 non-triggering path — well-formed '### Slide NN' whose NN
    matches a '## Slide NN' heading is not orphaned; no warning emitted.
    """
    content = (
        "# Deck\n\n---\n\n"
        "## Slide 01 — Title\n\nPrompt.\n\n"
        "## Speaker Notes\n\n"
        "### Slide 01 — Title\n\n**Say:** Words.\n"
    )
    result = validate_prompt_file(content)

    assert result.valid is True
    assert len(result.warnings) == 0


# ---------------------------------------------------------------------------
# TC-16  test_valid_30_slides_no_warning  (boundary: exactly 30 slides)
# ---------------------------------------------------------------------------


def test_valid_30_slides_no_warning() -> None:
    """A file with exactly 30 slides must NOT trigger the slide-count warning.

    Covers: boundary criterion for V-4 — warning fires only when count EXCEEDS
    30, not at 30 exactly.
    """
    result = validate_prompt_file(_make_valid_file(30))

    assert result.valid is True
    assert result.slide_count == 30
    assert len(result.errors) == 0
    # V-4 warning must not appear
    count_warnings = [w for w in result.warnings if "performance" in w.lower()]
    assert not count_warnings, (
        f"Unexpected slide-count warning for exactly 30 slides: {count_warnings}"
    )


# ---------------------------------------------------------------------------
# Additional structural / type-contract tests
# ---------------------------------------------------------------------------


def test_validate_prompt_file_never_raises() -> None:
    """validate_prompt_file must not raise for any string input, including edge cases.

    Covers: design §3 — 'The function never raises. It always returns a
    ValidationResult'.
    """
    edge_cases = [
        "",
        "   ",
        "\n\n\n",
        "# Title only",
        "## Slide 01 — No H1\nPrompt.\n",
        "# A\n## Slide 99 — High\nPrompt.\n",
    ]
    for content in edge_cases:
        result = validate_prompt_file(content)
        assert isinstance(result, ValidationResult), (
            f"Expected ValidationResult for input {content!r}, got {type(result)}"
        )


def test_result_valid_derived_from_errors() -> None:
    """result.valid must equal (len(result.errors) == 0) for any input.

    Covers: design §2 — 'valid is derived at construction time:
    valid = len(errors) == 0'.
    """
    inputs = [
        "",
        MINIMAL_VALID,
        VALID_15_SLIDES,
        COLLECT_ALL,
        "# Deck\n\n## Slide 01 — Title\n\nPrompt.\n",
    ]
    for content in inputs:
        result = validate_prompt_file(content)
        expected_valid = len(result.errors) == 0
        assert result.valid == expected_valid, (
            f"valid={result.valid} but len(errors)={len(result.errors)} for input {content[:40]!r}"
        )


def test_slideinfo_fields() -> None:
    """SlideInfo objects in result.slides carry integer number, str title, int line_number.

    Covers: design §2 data model — SlideInfo.number (int), SlideInfo.title (str),
    SlideInfo.line_number (int, 1-based).
    """
    result = validate_prompt_file(MINIMAL_VALID)

    assert result.slide_count == 1
    assert len(result.slides) == 1

    slide = result.slides[0]
    assert isinstance(slide.number, int)
    assert isinstance(slide.title, str)
    assert isinstance(slide.line_number, int)
    assert slide.line_number >= 1
    assert slide.number == 1
    assert slide.title == "Introduction"


def test_validation_error_fields() -> None:
    """ValidationError objects carry int line_number, str message, and int|None slide_number.

    Covers: design §2 data model field types for ValidationError.
    """
    result = validate_prompt_file("# Deck\n\n---\n\n## Slide 3 — Bad\n\nPrompt.\n")

    assert len(result.errors) == 1
    err = result.errors[0]
    assert isinstance(err.line_number, int)
    assert isinstance(err.message, str)
    # slide_number is int or None
    assert err.slide_number is None or isinstance(err.slide_number, int)
