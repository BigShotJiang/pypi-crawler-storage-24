"""Unit tests for renderdeck_mcp.generation.gemini.

All tests are pure unit tests: no real network calls, no real Gemini API.
The google-genai SDK's synchronous client.models.generate_content is wrapped
in asyncio.to_thread in the implementation; mocks must be regular MagicMock
(not AsyncMock) since to_thread executes sync functions.

Run with:
    uv run pytest tests/test_gemini_client.py -v
"""

from __future__ import annotations

import asyncio
import base64
import logging
import sys
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from renderdeck_mcp.generation.gemini import (
    _STYLE_PREAMBLE,
    AspectRatio,
    GeminiConfig,
    ImageResult,
    SlideImageRequest,
    _build_prompt,
    _extract_image_bytes,
    _is_content_policy_block,
    _is_retryable,
    generate_image,
    generate_images_concurrent,
)

# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def config() -> GeminiConfig:
    """Standard test config with zero retry delays for fast tests."""
    return GeminiConfig(
        api_key="test-key",
        model="gemini-2.5-flash-image",
        max_retries=3,
        max_concurrent_images=3,
        retry_delays=(0.0, 0.0, 0.0),
    )


@pytest.fixture
def wide_request() -> SlideImageRequest:
    """A slide image request with all optional fields populated."""
    return SlideImageRequest(
        slide_index=0,
        prompt="A futuristic cityscape",
        aspect_ratio=AspectRatio.WIDE,
        general_context="Tech startup pitch deck",
        visual_rules="Vibrant colors, clean lines",
    )


@pytest.fixture
def mock_png_bytes() -> bytes:
    """Minimal valid PNG header bytes."""
    return b"\x89PNG\r\n\x1a\n" + b"\x00" * 20


@pytest.fixture
def mock_genai_response(mock_png_bytes: bytes) -> MagicMock:
    """A mock Gemini response with one image part containing PNG bytes."""
    part = MagicMock()
    part.inline_data.data = mock_png_bytes
    response = MagicMock()
    response.parts = [part]
    return response


@pytest.fixture
def mock_client(mock_genai_response: MagicMock) -> MagicMock:
    """A mock genai.Client with generate_content returning a valid response by default."""
    client = MagicMock()
    client.models.generate_content.return_value = mock_genai_response
    return client


# ---------------------------------------------------------------------------
# TC-01: Successful image generation returns PNG bytes
# ---------------------------------------------------------------------------


async def test_tc01_successful_image_generation_returns_png_bytes(
    mock_client: MagicMock,
    wide_request: SlideImageRequest,
    config: GeminiConfig,
    mock_png_bytes: bytes,
) -> None:
    """generate_image returns PNG bytes when the Gemini API responds with a valid image part."""
    with patch("asyncio.sleep", new_callable=AsyncMock):
        result = await generate_image(mock_client, wide_request, config)

    assert result == mock_png_bytes
    assert isinstance(result, bytes)


# ---------------------------------------------------------------------------
# TC-02: Successful image generation via candidates path
# ---------------------------------------------------------------------------


async def test_tc02_candidates_path_fallback(
    mock_client: MagicMock,
    wide_request: SlideImageRequest,
    config: GeminiConfig,
    mock_png_bytes: bytes,
) -> None:
    """_extract_image_bytes falls back to response.candidates[0].content.parts."""
    candidate_part = MagicMock()
    candidate_part.inline_data.data = mock_png_bytes

    response = MagicMock()
    response.parts = []
    response.candidates[0].content.parts = [candidate_part]
    mock_client.models.generate_content.return_value = response

    with patch("asyncio.sleep", new_callable=AsyncMock):
        result = await generate_image(mock_client, wide_request, config)

    assert result == mock_png_bytes


# ---------------------------------------------------------------------------
# TC-03: Base64-encoded inline_data is decoded to bytes
# ---------------------------------------------------------------------------


async def test_tc03_base64_inline_data_decoded(
    mock_client: MagicMock,
    wide_request: SlideImageRequest,
    config: GeminiConfig,
    mock_png_bytes: bytes,
) -> None:
    """When inline_data.data is a base64 string, the image bytes are correctly decoded."""
    part = MagicMock()
    part.inline_data.data = base64.b64encode(mock_png_bytes).decode("ascii")

    response = MagicMock()
    response.parts = [part]
    mock_client.models.generate_content.return_value = response

    with patch("asyncio.sleep", new_callable=AsyncMock):
        result = await generate_image(mock_client, wide_request, config)

    assert result == mock_png_bytes


# ---------------------------------------------------------------------------
# TC-04: as_image() fallback when inline_data is absent
# ---------------------------------------------------------------------------


async def test_tc04_as_image_fallback(
    mock_client: MagicMock,
    wide_request: SlideImageRequest,
    config: GeminiConfig,
    mock_png_bytes: bytes,
) -> None:
    """When inline_data raises AttributeError, as_image() is used to extract bytes."""
    import io

    part = MagicMock()
    # Make inline_data raise AttributeError when accessed
    type(part).inline_data = property(
        lambda self: (_ for _ in ()).throw(AttributeError("no inline_data"))
    )

    mock_pil = MagicMock()

    def fake_save(buf: object, format: str) -> None:
        if isinstance(buf, io.BytesIO):
            buf.write(mock_png_bytes)

    mock_pil.save.side_effect = fake_save
    part.as_image.return_value = mock_pil

    response = MagicMock()
    response.parts = [part]
    mock_client.models.generate_content.return_value = response

    with patch("asyncio.sleep", new_callable=AsyncMock):
        result = await generate_image(mock_client, wide_request, config)

    assert result == mock_png_bytes


# ---------------------------------------------------------------------------
# TC-05: Returns None when all response parts yield no image
# ---------------------------------------------------------------------------


async def test_tc05_no_image_parts_returns_none(
    mock_client: MagicMock,
    wide_request: SlideImageRequest,
) -> None:
    """When no part yields image bytes, generate_image exhausts retries and returns None."""
    single_retry_config = GeminiConfig(
        api_key="test-key",
        model="gemini-2.5-flash-image",
        max_retries=1,
        max_concurrent_images=3,
        retry_delays=(0.0,),
    )

    part = MagicMock()
    part.inline_data.data = None
    part.as_image.side_effect = Exception("no image")

    response = MagicMock()
    response.parts = [part]
    response.candidates = []
    mock_client.models.generate_content.return_value = response

    with patch("asyncio.sleep", new_callable=AsyncMock):
        result = await generate_image(mock_client, wide_request, single_retry_config)

    assert result is None


# ---------------------------------------------------------------------------
# TC-06: Retry on HTTP 429, success on second attempt
# ---------------------------------------------------------------------------


async def test_tc06_retry_429_success_on_second_attempt(
    mock_client: MagicMock,
    wide_request: SlideImageRequest,
    config: GeminiConfig,
    mock_genai_response: MagicMock,
    mock_png_bytes: bytes,
) -> None:
    """generate_image retries after a 429-like exception and succeeds on the second attempt."""
    mock_client.models.generate_content.side_effect = [
        Exception("HTTP 429: quota exceeded"),
        mock_genai_response,
    ]

    with patch("asyncio.sleep", new_callable=AsyncMock) as mock_sleep:
        result = await generate_image(mock_client, wide_request, config)

    assert result == mock_png_bytes
    assert mock_client.models.generate_content.call_count == 2
    # asyncio.sleep called once with the first retry delay (0.0)
    mock_sleep.assert_called_once_with(0.0)


# ---------------------------------------------------------------------------
# TC-07: Retry on HTTP 503, success on third attempt
# ---------------------------------------------------------------------------


async def test_tc07_retry_503_success_on_third_attempt(
    mock_client: MagicMock,
    wide_request: SlideImageRequest,
    config: GeminiConfig,
    mock_genai_response: MagicMock,
    mock_png_bytes: bytes,
) -> None:
    """generate_image retries twice after 503 errors and succeeds on the third attempt."""
    mock_client.models.generate_content.side_effect = [
        Exception("HTTP 503 service unavailable"),
        Exception("HTTP 503 service unavailable"),
        mock_genai_response,
    ]

    with patch("asyncio.sleep", new_callable=AsyncMock):
        result = await generate_image(mock_client, wide_request, config)

    assert result == mock_png_bytes
    assert mock_client.models.generate_content.call_count == 3


# ---------------------------------------------------------------------------
# TC-08: Retry exhaustion returns None, does not raise
# ---------------------------------------------------------------------------


async def test_tc08_retry_exhaustion_returns_none(
    mock_client: MagicMock,
    wide_request: SlideImageRequest,
    config: GeminiConfig,
) -> None:
    """After all retry attempts fail with retryable errors, generate_image returns None."""
    mock_client.models.generate_content.side_effect = Exception("HTTP 429")

    with patch("asyncio.sleep", new_callable=AsyncMock):
        result = await generate_image(mock_client, wide_request, config)

    assert result is None
    # 3 retries → 3 calls total
    assert mock_client.models.generate_content.call_count == 3


# ---------------------------------------------------------------------------
# TC-09: Content policy block returns None immediately without retrying
# ---------------------------------------------------------------------------


async def test_tc09_content_policy_block_no_retry(
    mock_client: MagicMock,
    wide_request: SlideImageRequest,
    config: GeminiConfig,
) -> None:
    """Content policy exception causes immediate None return with no retries."""
    mock_client.models.generate_content.side_effect = Exception(
        "Content blocked: PROHIBITED_CONTENT policy violation"
    )

    with patch("asyncio.sleep", new_callable=AsyncMock) as mock_sleep:
        result = await generate_image(mock_client, wide_request, config)

    assert result is None
    assert mock_client.models.generate_content.call_count == 1
    mock_sleep.assert_not_called()


# ---------------------------------------------------------------------------
# TC-10: HTTP 400 (bad request) is non-retryable
# ---------------------------------------------------------------------------


async def test_tc10_http_400_non_retryable(
    mock_client: MagicMock,
    wide_request: SlideImageRequest,
    config: GeminiConfig,
) -> None:
    """A 400 error causes immediate return of None without retrying."""
    mock_client.models.generate_content.side_effect = Exception("HTTP 400: bad request")

    with patch("asyncio.sleep", new_callable=AsyncMock) as mock_sleep:
        result = await generate_image(mock_client, wide_request, config)

    assert result is None
    assert mock_client.models.generate_content.call_count == 1
    mock_sleep.assert_not_called()


# ---------------------------------------------------------------------------
# TC-11: generate_images_concurrent returns list in input order
# ---------------------------------------------------------------------------


async def test_tc11_concurrent_results_in_input_order(config: GeminiConfig) -> None:
    """Results are returned in the same order as the input requests list."""
    requests = [SlideImageRequest(slide_index=i, prompt=f"slide_{i}") for i in range(3)]

    def make_response(n: int) -> MagicMock:
        part = MagicMock()
        part.inline_data.data = bytes([n]) * 8
        r = MagicMock()
        r.parts = [part]
        return r

    with (
        patch("renderdeck_mcp.generation.gemini.genai.Client") as mock_client_cls,
        patch("asyncio.sleep", new_callable=AsyncMock),
    ):
        mock_client_instance = MagicMock()
        mock_client_cls.return_value = mock_client_instance
        mock_client_instance.models.generate_content.side_effect = [
            make_response(0),
            make_response(1),
            make_response(2),
        ]

        results = await generate_images_concurrent(requests, config)

    assert len(results) == 3
    for i, result in enumerate(results):
        assert result.slide_index == i
        assert result.image_bytes == bytes([i]) * 8
        assert result.fallback is False


# ---------------------------------------------------------------------------
# TC-12: Concurrency limited to max_concurrent_images
# ---------------------------------------------------------------------------


async def test_tc12_concurrency_limited_by_semaphore() -> None:
    """At no point do more than max_concurrent_images calls execute simultaneously."""
    config = GeminiConfig(
        api_key="test-key",
        model="gemini-2.5-flash-image",
        max_retries=1,
        max_concurrent_images=2,
        retry_delays=(0.0,),
    )
    requests = [SlideImageRequest(slide_index=i, prompt=f"slide_{i}") for i in range(5)]

    concurrency_counter: dict[str, int] = {"current": 0, "peak": 0}

    part = MagicMock()
    part.inline_data.data = b"\x89PNG\r\n\x1a\n" + b"\x00" * 20
    mock_response = MagicMock()
    mock_response.parts = [part]

    async def slow_generate(*args: object, **kwargs: object) -> MagicMock:
        concurrency_counter["current"] += 1
        concurrency_counter["peak"] = max(
            concurrency_counter["peak"], concurrency_counter["current"]
        )
        await asyncio.sleep(0.01)
        concurrency_counter["current"] -= 1
        return mock_response

    with (
        patch("renderdeck_mcp.generation.gemini.genai.Client") as mock_client_cls,
        patch("renderdeck_mcp.generation.gemini.asyncio.to_thread", side_effect=slow_generate),
    ):
        mock_client_cls.return_value = MagicMock()
        results = await generate_images_concurrent(requests, config)

    assert len(results) == 5
    assert concurrency_counter["peak"] <= 2


# ---------------------------------------------------------------------------
# TC-13: One failing slide does not abort other slides
# ---------------------------------------------------------------------------


async def test_tc13_one_failure_does_not_abort_batch(
    config: GeminiConfig,
    mock_png_bytes: bytes,
) -> None:
    """A failure on slide 1 does not prevent slides 0 and 2 from succeeding."""
    requests = [
        SlideImageRequest(slide_index=0, prompt="slide_0_prompt"),
        SlideImageRequest(slide_index=1, prompt="slide_1_FAIL"),
        SlideImageRequest(slide_index=2, prompt="slide_2_prompt"),
    ]

    def side_effect(model: str, contents: str, config: object) -> MagicMock:
        if "FAIL" in contents:
            raise Exception("HTTP 429")
        part = MagicMock()
        part.inline_data.data = mock_png_bytes
        r = MagicMock()
        r.parts = [part]
        return r

    with (
        patch("renderdeck_mcp.generation.gemini.genai.Client") as mock_client_cls,
        patch("asyncio.sleep", new_callable=AsyncMock),
    ):
        mock_instance = MagicMock()
        mock_client_cls.return_value = mock_instance
        mock_instance.models.generate_content.side_effect = side_effect

        results = await generate_images_concurrent(requests, config)

    assert results[0].fallback is False
    assert results[0].image_bytes == mock_png_bytes
    assert results[1].fallback is True
    assert results[1].image_bytes is None
    assert results[2].fallback is False
    assert results[2].image_bytes == mock_png_bytes


# ---------------------------------------------------------------------------
# TC-14: ImageResult.fallback is True when image_bytes is None
# ---------------------------------------------------------------------------


async def test_tc14_fallback_true_when_all_fail() -> None:
    """All ImageResult objects have fallback=True when generate_content always raises."""
    config = GeminiConfig(
        api_key="test-key",
        model="gemini-2.5-flash-image",
        max_retries=1,
        max_concurrent_images=3,
        retry_delays=(0.0,),
    )
    requests = [SlideImageRequest(slide_index=i, prompt=f"slide_{i}") for i in range(3)]

    with (
        patch("renderdeck_mcp.generation.gemini.genai.Client") as mock_client_cls,
        patch("asyncio.sleep", new_callable=AsyncMock),
    ):
        mock_instance = MagicMock()
        mock_client_cls.return_value = mock_instance
        mock_instance.models.generate_content.side_effect = Exception("HTTP 429")

        results = await generate_images_concurrent(requests, config)

    assert all(r.fallback is True for r in results)
    assert all(r.image_bytes is None for r in results)


# ---------------------------------------------------------------------------
# TC-15: API key is not present in log output
# ---------------------------------------------------------------------------


async def test_tc15_api_key_not_logged(caplog: pytest.LogCaptureFixture) -> None:
    """Captured log records must not contain the API key string."""
    secret_key = "super-secret-key-12345"
    config = GeminiConfig(
        api_key=secret_key,
        model="gemini-2.5-flash-image",
        max_retries=3,
        max_concurrent_images=3,
        retry_delays=(0.0, 0.0, 0.0),
    )
    request = SlideImageRequest(slide_index=0, prompt="A test slide")
    mock_client = MagicMock()
    mock_client.models.generate_content.side_effect = Exception(
        f"HTTP 429: quota for key {secret_key}"
    )

    with (
        patch("asyncio.sleep", new_callable=AsyncMock),
        caplog.at_level(logging.DEBUG, logger="renderdeck_mcp.generation.gemini"),
    ):
        await generate_image(mock_client, request, config)

    for record in caplog.records:
        assert secret_key not in record.getMessage(), (
            f"API key found in log record: {record.getMessage()!r}"
        )


# ---------------------------------------------------------------------------
# TC-16: _build_prompt assembles three sections in order
# ---------------------------------------------------------------------------


def test_tc16_build_prompt_all_sections() -> None:
    """_build_prompt assembles GENERAL CONTEXT, GLOBAL VISUAL RULES, and SLIDE IMAGE PROMPT."""
    request = SlideImageRequest(
        slide_index=0,
        prompt="A mountain landscape",
        general_context="Nature documentary",
        visual_rules="Realistic photography style",
    )

    result = _build_prompt(request)

    expected = (
        f"{_STYLE_PREAMBLE}\n\n"
        "GENERAL CONTEXT:\nNature documentary\n\n"
        "GLOBAL VISUAL RULES:\nRealistic photography style\n\n"
        "SLIDE IMAGE PROMPT:\nA mountain landscape"
    )
    assert result == expected


# ---------------------------------------------------------------------------
# TC-17: _build_prompt with empty context and rules
# ---------------------------------------------------------------------------


def test_tc17_build_prompt_slide_only() -> None:
    """When general_context and visual_rules are empty, prompt contains only the slide section."""
    request = SlideImageRequest(slide_index=0, prompt="A cat")

    result = _build_prompt(request)

    assert result == f"{_STYLE_PREAMBLE}\n\nSLIDE IMAGE PROMPT:\nA cat"
    assert "GENERAL CONTEXT" not in result
    assert "GLOBAL VISUAL RULES" not in result


# ---------------------------------------------------------------------------
# TC-18: AspectRatio WIDE maps to "16:9"
# ---------------------------------------------------------------------------


def test_tc18_aspect_ratio_wide_value() -> None:
    """AspectRatio.WIDE.value must equal '16:9'."""
    assert AspectRatio.WIDE.value == "16:9"


# ---------------------------------------------------------------------------
# TC-19: AspectRatio STANDARD maps to "4:3"
# ---------------------------------------------------------------------------


def test_tc19_aspect_ratio_standard_value() -> None:
    """AspectRatio.STANDARD.value must equal '4:3'."""
    assert AspectRatio.STANDARD.value == "4:3"


# ---------------------------------------------------------------------------
# TC-20: generate_content called with correct model from config
# ---------------------------------------------------------------------------


async def test_tc20_correct_model_passed_to_sdk(
    mock_client: MagicMock,
    wide_request: SlideImageRequest,
    config: GeminiConfig,
) -> None:
    """The model name from GeminiConfig is forwarded to client.models.generate_content."""
    with patch("asyncio.sleep", new_callable=AsyncMock):
        await generate_image(mock_client, wide_request, config)

    call_kwargs = mock_client.models.generate_content.call_args
    assert call_kwargs is not None
    args, kwargs = call_kwargs
    model_value = kwargs.get("model") or (args[0] if args else None)
    assert model_value == config.model


# ---------------------------------------------------------------------------
# TC-21: google-generativeai is not imported
# ---------------------------------------------------------------------------


def test_tc21_deprecated_sdk_not_imported() -> None:
    """sys.modules must not contain 'google.generativeai' after importing the module."""
    import renderdeck_mcp.generation.gemini  # noqa: F401

    assert "google.generativeai" not in sys.modules, (
        "Deprecated 'google.generativeai' package was imported. Use 'google.genai' instead."
    )


# ---------------------------------------------------------------------------
# TC-22: GeminiConfig default values
# ---------------------------------------------------------------------------


def test_tc22_gemini_config_defaults() -> None:
    """GeminiConfig must have correct default field values."""
    cfg = GeminiConfig(api_key="k")

    assert cfg.model == "gemini-3-pro-image-preview"
    assert cfg.max_retries == 3
    assert cfg.max_concurrent_images == 5
    assert cfg.retry_delays == (1.0, 2.0, 4.0)


# ---------------------------------------------------------------------------
# TC-23: max_retries=0 returns None immediately
# ---------------------------------------------------------------------------


async def test_tc23_max_retries_zero_returns_none_immediately(
    wide_request: SlideImageRequest,
    mock_genai_response: MagicMock,
) -> None:
    """When max_retries=0, no API calls are made and None is returned."""
    config = GeminiConfig(
        api_key="test-key",
        model="gemini-2.5-flash-image",
        max_retries=0,
        max_concurrent_images=3,
        retry_delays=(),
    )
    mock_client = MagicMock()
    mock_client.models.generate_content.return_value = mock_genai_response

    with patch("asyncio.sleep", new_callable=AsyncMock):
        result = await generate_image(mock_client, wide_request, config)

    assert result is None
    mock_client.models.generate_content.assert_not_called()


# ---------------------------------------------------------------------------
# TC-24: max_concurrent_images=1 serialises all calls
# ---------------------------------------------------------------------------


async def test_tc24_max_concurrent_one_serialises_calls(
    mock_png_bytes: bytes,
) -> None:
    """With max_concurrent_images=1, all calls are serialised and correct results returned."""
    config = GeminiConfig(
        api_key="test-key",
        model="gemini-2.5-flash-image",
        max_retries=1,
        max_concurrent_images=1,
        retry_delays=(0.0,),
    )
    requests = [SlideImageRequest(slide_index=i, prompt=f"slide_{i}") for i in range(3)]

    part = MagicMock()
    part.inline_data.data = mock_png_bytes
    mock_response = MagicMock()
    mock_response.parts = [part]

    with (
        patch("renderdeck_mcp.generation.gemini.genai.Client") as mock_client_cls,
        patch("asyncio.sleep", new_callable=AsyncMock),
    ):
        mock_instance = MagicMock()
        mock_client_cls.return_value = mock_instance
        mock_instance.models.generate_content.return_value = mock_response

        results = await generate_images_concurrent(requests, config)

    assert len(results) == 3
    assert all(r.fallback is False for r in results)
    assert mock_instance.models.generate_content.call_count == 3


# ---------------------------------------------------------------------------
# Additional: Empty requests list returns empty results
# ---------------------------------------------------------------------------


async def test_empty_requests_returns_empty_list(config: GeminiConfig) -> None:
    """generate_images_concurrent with an empty list returns an empty list."""
    with patch("renderdeck_mcp.generation.gemini.genai.Client") as mock_client_cls:
        mock_client_cls.return_value = MagicMock()
        results = await generate_images_concurrent([], config)

    assert results == []


# ---------------------------------------------------------------------------
# Additional: _is_retryable classification
# ---------------------------------------------------------------------------


def test_is_retryable_returns_true_for_429() -> None:
    """_is_retryable returns True for HTTP 429 exceptions."""
    assert _is_retryable(Exception("HTTP 429: quota exceeded")) is True


def test_is_retryable_returns_true_for_503() -> None:
    """_is_retryable returns True for HTTP 503 exceptions."""
    assert _is_retryable(Exception("HTTP 503 service unavailable")) is True


def test_is_retryable_returns_false_for_400() -> None:
    """_is_retryable returns False for HTTP 400 exceptions."""
    assert _is_retryable(Exception("HTTP 400: bad request")) is False


def test_is_retryable_returns_false_for_policy_block() -> None:
    """_is_retryable returns False for content policy blocks."""
    assert _is_retryable(Exception("PROHIBITED_CONTENT policy violation")) is False


def test_is_retryable_returns_false_for_blocked() -> None:
    """_is_retryable returns False when 'blocked' appears in the exception message."""
    assert _is_retryable(Exception("Content blocked")) is False


# ---------------------------------------------------------------------------
# Additional: _is_content_policy_block classification
# ---------------------------------------------------------------------------


def test_is_content_policy_block_prohibited_content() -> None:
    """_is_content_policy_block returns True for PROHIBITED_CONTENT."""
    assert _is_content_policy_block(Exception("PROHIBITED_CONTENT")) is True


def test_is_content_policy_block_blocked() -> None:
    """_is_content_policy_block returns True when 'blocked' in message."""
    assert _is_content_policy_block(Exception("Content blocked")) is True


def test_is_content_policy_block_policy() -> None:
    """_is_content_policy_block returns True when 'policy' in message."""
    assert _is_content_policy_block(Exception("policy violation detected")) is True


def test_is_content_policy_block_false_for_429() -> None:
    """_is_content_policy_block returns False for ordinary quota errors."""
    assert _is_content_policy_block(Exception("HTTP 429: quota exceeded")) is False


# ---------------------------------------------------------------------------
# Additional: _extract_image_bytes with various edge cases
# ---------------------------------------------------------------------------


def test_extract_image_bytes_returns_none_for_null_data() -> None:
    """_extract_image_bytes returns None when inline_data.data is None."""
    part = MagicMock()
    part.inline_data.data = None
    part.as_image.side_effect = Exception("no image")

    response = MagicMock()
    response.parts = [part]
    response.candidates = []

    result = _extract_image_bytes(response)
    assert result is None


def test_extract_image_bytes_returns_none_for_empty_parts() -> None:
    """_extract_image_bytes returns None when both parts lists are empty."""
    response = MagicMock()
    response.parts = []
    response.candidates = []

    result = _extract_image_bytes(response)
    assert result is None


def test_extract_image_bytes_direct_bytes(mock_png_bytes: bytes) -> None:
    """_extract_image_bytes returns bytes when inline_data.data is already bytes."""
    part = MagicMock()
    part.inline_data.data = mock_png_bytes

    response = MagicMock()
    response.parts = [part]

    result = _extract_image_bytes(response)
    assert result == mock_png_bytes


def test_extract_image_bytes_base64_string(mock_png_bytes: bytes) -> None:
    """_extract_image_bytes decodes base64 string inline_data.data correctly."""
    part = MagicMock()
    part.inline_data.data = base64.b64encode(mock_png_bytes).decode("ascii")

    response = MagicMock()
    response.parts = [part]

    result = _extract_image_bytes(response)
    assert result == mock_png_bytes


# ---------------------------------------------------------------------------
# Additional: generate_image uses externally provided client (no re-creation)
# ---------------------------------------------------------------------------


async def test_generate_image_uses_provided_client_not_recreated(
    mock_client: MagicMock,
    wide_request: SlideImageRequest,
    config: GeminiConfig,
    mock_png_bytes: bytes,
) -> None:
    """generate_image uses the client passed as argument without creating a new one."""
    with (
        patch("renderdeck_mcp.generation.gemini.genai.Client") as mock_client_cls,
        patch("asyncio.sleep", new_callable=AsyncMock),
    ):
        result = await generate_image(mock_client, wide_request, config)

    # The externally-provided client should have been used
    assert mock_client.models.generate_content.called
    # genai.Client constructor should NOT have been called since we passed a client
    mock_client_cls.assert_not_called()
    assert result == mock_png_bytes


# ---------------------------------------------------------------------------
# Additional: Exponential backoff delay values are forwarded to asyncio.sleep
# ---------------------------------------------------------------------------


async def test_exponential_backoff_delay_values_forwarded(
    mock_client: MagicMock,
    wide_request: SlideImageRequest,
    mock_genai_response: MagicMock,
) -> None:
    """Retry delay values from config.retry_delays are passed to asyncio.sleep."""
    config = GeminiConfig(
        api_key="test-key",
        model="gemini-2.5-flash-image",
        max_retries=3,
        max_concurrent_images=3,
        retry_delays=(2.0, 4.0, 8.0),
    )
    mock_client.models.generate_content.side_effect = [
        Exception("HTTP 429"),
        Exception("HTTP 429"),
        mock_genai_response,
    ]

    with patch("asyncio.sleep", new_callable=AsyncMock) as mock_sleep:
        result = await generate_image(mock_client, wide_request, config)

    assert result is not None
    # Two retries → two sleep calls with the configured delays
    assert mock_sleep.call_count == 2
    mock_sleep.assert_any_call(2.0)
    mock_sleep.assert_any_call(4.0)


# ---------------------------------------------------------------------------
# Additional: ImageResult dataclass fields
# ---------------------------------------------------------------------------


def test_image_result_fallback_false_when_bytes_provided(mock_png_bytes: bytes) -> None:
    """ImageResult.fallback=False when image_bytes is present."""
    result = ImageResult(slide_index=0, image_bytes=mock_png_bytes, fallback=False)
    assert result.fallback is False
    assert result.image_bytes == mock_png_bytes
    assert result.error is None


def test_image_result_fallback_true_when_no_bytes() -> None:
    """ImageResult.fallback=True when image_bytes is None."""
    result = ImageResult(slide_index=1, image_bytes=None, fallback=True, error="quota exceeded")
    assert result.fallback is True
    assert result.image_bytes is None
    assert result.error == "quota exceeded"


# ---------------------------------------------------------------------------
# Additional: AspectRatio.STANDARD forwarded to SDK config
# ---------------------------------------------------------------------------


async def test_aspect_ratio_standard_forwarded_to_sdk(
    mock_client: MagicMock,
    config: GeminiConfig,
    mock_genai_response: MagicMock,
) -> None:
    """AspectRatio.STANDARD ('4:3') is forwarded through to the SDK config call."""
    request = SlideImageRequest(
        slide_index=0,
        prompt="A standard slide",
        aspect_ratio=AspectRatio.STANDARD,
    )

    with patch("asyncio.sleep", new_callable=AsyncMock):
        result = await generate_image(mock_client, request, config)

    assert result is not None
    assert mock_client.models.generate_content.called
    _, kwargs = mock_client.models.generate_content.call_args
    sdk_config = kwargs.get("config")
    assert sdk_config is not None


# ---------------------------------------------------------------------------
# Additional: _build_prompt includes only general_context when visual_rules empty
# ---------------------------------------------------------------------------


def test_build_prompt_context_only_no_rules() -> None:
    """_build_prompt includes GENERAL CONTEXT but not GLOBAL VISUAL RULES when rules is empty."""
    request = SlideImageRequest(
        slide_index=0,
        prompt="A forest",
        general_context="Wildlife series",
        visual_rules="",
    )

    result = _build_prompt(request)

    assert "GENERAL CONTEXT:\nWildlife series" in result
    assert "GLOBAL VISUAL RULES" not in result
    assert "SLIDE IMAGE PROMPT:\nA forest" in result


def test_build_prompt_rules_only_no_context() -> None:
    """_build_prompt includes GLOBAL VISUAL RULES but not GENERAL CONTEXT when context is empty."""
    request = SlideImageRequest(
        slide_index=0,
        prompt="A desert",
        general_context="",
        visual_rules="Muted earthy tones",
    )

    result = _build_prompt(request)

    assert "GENERAL CONTEXT" not in result
    assert "GLOBAL VISUAL RULES:\nMuted earthy tones" in result
    assert "SLIDE IMAGE PROMPT:\nA desert" in result
