"""Tests for the update_settings MCP tool."""

from __future__ import annotations

from pathlib import Path

import pytest

from renderdeck_mcp import config as cfg
from renderdeck_mcp.server import update_settings


@pytest.fixture(autouse=True)
def _isolated_config(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    """Redirect config dir to a temp directory."""
    config_dir = tmp_path / ".renderdeck"
    monkeypatch.setattr(cfg, "CONFIG_DIR", config_dir)
    monkeypatch.setattr(cfg, "CONFIG_FILE", config_dir / "config.json")
    monkeypatch.setattr(cfg, "_KEY_FILE", config_dir / ".fernet_key")


class TestUpdateSettings:
    """Tests for the update_settings MCP tool."""

    def test_update_single_field(self) -> None:
        result = update_settings(aspect_ratio="STANDARD")
        assert result["status"] == "success"
        assert result["settings"]["aspect_ratio"] == "STANDARD"

    def test_preserves_other_fields(self) -> None:
        update_settings(verbose=True)
        result = update_settings(aspect_ratio="STANDARD")
        assert result["settings"]["verbose"] is True
        assert result["settings"]["aspect_ratio"] == "STANDARD"

    def test_invalid_aspect_ratio_returns_error(self) -> None:
        result = update_settings(aspect_ratio="SQUARE")
        assert result["status"] == "error"
        assert "aspect_ratio" in result["message"]

    def test_no_updates_returns_success(self) -> None:
        result = update_settings()
        assert result["status"] == "success"
        assert "No settings" in result["message"]

    def test_reflected_in_get_setup_status(self) -> None:
        update_settings(aspect_ratio="STANDARD")
        status = cfg.get_setup_status()
        assert status["aspect_ratio"] == "STANDARD"

    def test_update_multiple_fields(self) -> None:
        result = update_settings(
            gemini_image_model="gemini-3-pro",
            gemini_max_retries=5,
        )
        assert result["status"] == "success"
        assert result["settings"]["gemini_image_model"] == "gemini-3-pro"
        assert result["settings"]["gemini_max_retries"] == 5
