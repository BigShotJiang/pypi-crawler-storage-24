"""Unit tests for renderdeck_mcp.tools.generate_video.

All external dependencies are mocked — no real filesystem, ffmpeg, or edge-tts calls.
"""

from __future__ import annotations

from pathlib import Path
from unittest.mock import AsyncMock, patch

import pytest

# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

PROMPT_WITH_NARRATION = """\
# Test Deck

## General
Test context.

---

## Slide 01 — Introduction
A test image prompt.

### Speaker Notes
**Say:** Welcome to the test presentation.
**Time:** 30 seconds

---

## Slide 02 — Main Point
Another image prompt.

### Speaker Notes
**Say:** This is the main point of the talk.
**Say:** Let me elaborate on this further.
"""

PROMPT_NO_NARRATION = """\
# Test Deck

## General
Test context.

---

## Slide 01 — No Say Lines
A test image prompt.

### Speaker Notes
Just regular notes, no Say lines.
"""

FAKE_PNG = b"\x89PNG\r\n\x1a\n" + b"\x00" * 100


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

_TARGET_CHECK_FFMPEG = "renderdeck_mcp.tools.generate_video.check_ffmpeg"
_TARGET_GENERATE_TTS = "renderdeck_mcp.tools.generate_video._generate_tts"
_TARGET_MAKE_SEGMENT = "renderdeck_mcp.tools.generate_video._make_segment"
_TARGET_CONCAT = "renderdeck_mcp.tools.generate_video._concat_segments"
_TARGET_CACHE_BASE = "renderdeck_mcp.tools.generate_video._CACHE_BASE_DIR"
_TARGET_SHUTIL_COPY2 = "renderdeck_mcp.tools.generate_video.shutil.copy2"


def _setup_cache_dir(tmp_path: Path, project_name: str, slide_count: int) -> Path:
    """Create a fake cache directory with slide PNGs.

    Uses zero-padded slide numbers (slide_01.png) to match parser output.
    """
    cache_dir = tmp_path / project_name
    cache_dir.mkdir(parents=True)
    for i in range(1, slide_count + 1):
        # Parser returns zero-padded slide numbers like "01", "02"
        (cache_dir / f"slide_{i:02d}.png").write_bytes(FAKE_PNG)
    return tmp_path


# ---------------------------------------------------------------------------
# TC-01: Successful 2-slide video generation
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_tc01_successful_video_generation(tmp_path: Path) -> None:
    """Full pipeline: 2 slides with narration produce a video."""
    from renderdeck_mcp.tools.generate_video import run_generate_video

    cache_base = _setup_cache_dir(tmp_path, "test_project", 2)
    output_mp4 = tmp_path / "output.mp4"

    # Create a fake output file so stat() works
    def _fake_concat(segments: list[Path], out: Path) -> None:
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_bytes(b"\x00" * 1024 * 1024)  # 1 MB fake
        return None

    with (
        patch(_TARGET_CHECK_FFMPEG, return_value=None),
        patch(_TARGET_GENERATE_TTS, new_callable=AsyncMock),
        patch(_TARGET_MAKE_SEGMENT, return_value=None),
        patch(_TARGET_CONCAT, side_effect=_fake_concat),
        patch(_TARGET_CACHE_BASE, cache_base),
    ):
        result = await run_generate_video(
            project_name="test_project",
            slide_prompt_content=PROMPT_WITH_NARRATION,
            output_path=str(output_mp4),
            voice="aria",
        )

    assert result["status"] == "ok"
    assert result["slide_count"] == 2
    assert result["voice_used"] == "en-US-AriaNeural"
    assert "output_path" in result
    assert "video_size_mb" in result


# ---------------------------------------------------------------------------
# TC-02: Missing ffmpeg returns error
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_tc02_missing_ffmpeg_returns_error() -> None:
    """If ffmpeg is not available, return clear error."""
    from renderdeck_mcp.tools.generate_video import run_generate_video

    with patch(
        _TARGET_CHECK_FFMPEG, return_value="ffmpeg not found. Install with: brew install ffmpeg"
    ):
        result = await run_generate_video(
            project_name="test",
            slide_prompt_content=PROMPT_WITH_NARRATION,
        )

    assert result["status"] == "error"
    assert "ffmpeg" in str(result["message"]).lower()


# ---------------------------------------------------------------------------
# TC-03: Missing cache directory returns error
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_tc03_missing_cache_dir_returns_error(tmp_path: Path) -> None:
    """Non-existent cache directory produces error with guidance."""
    from renderdeck_mcp.tools.generate_video import run_generate_video

    with (
        patch(_TARGET_CHECK_FFMPEG, return_value=None),
        patch(_TARGET_CACHE_BASE, tmp_path),
    ):
        result = await run_generate_video(
            project_name="nonexistent_project",
            slide_prompt_content=PROMPT_WITH_NARRATION,
        )

    assert result["status"] == "error"
    assert "cache" in str(result["message"]).lower()


# ---------------------------------------------------------------------------
# TC-04: No narration in slides returns error
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_tc04_no_narration_returns_error(tmp_path: Path) -> None:
    """Slides without **Say:** lines produce error."""
    from renderdeck_mcp.tools.generate_video import run_generate_video

    cache_base = _setup_cache_dir(tmp_path, "test_project", 1)

    with (
        patch(_TARGET_CHECK_FFMPEG, return_value=None),
        patch(_TARGET_CACHE_BASE, cache_base),
    ):
        result = await run_generate_video(
            project_name="test_project",
            slide_prompt_content=PROMPT_NO_NARRATION,
        )

    assert result["status"] == "error"
    assert "narration" in str(result["message"]).lower()


# ---------------------------------------------------------------------------
# TC-05: Empty prompt returns error
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_tc05_empty_prompt_returns_error() -> None:
    """Empty prompt content produces error."""
    from renderdeck_mcp.tools.generate_video import run_generate_video

    with patch(_TARGET_CHECK_FFMPEG, return_value=None):
        result = await run_generate_video(
            project_name="test",
            slide_prompt_content="",
        )

    assert result["status"] == "error"
    assert "no slides" in str(result["message"]).lower()


# ---------------------------------------------------------------------------
# TC-06: Voice alias resolution
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_tc06_voice_alias_resolved(tmp_path: Path) -> None:
    """Voice alias 'roger' resolves to 'en-US-RogerNeural'."""
    from renderdeck_mcp.tools.generate_video import run_generate_video

    cache_base = _setup_cache_dir(tmp_path, "test_project", 2)
    output_mp4 = tmp_path / "output.mp4"

    def _fake_concat(segments: list[Path], out: Path) -> None:
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_bytes(b"\x00" * 1024)
        return None

    with (
        patch(_TARGET_CHECK_FFMPEG, return_value=None),
        patch(_TARGET_GENERATE_TTS, new_callable=AsyncMock) as mock_tts,
        patch(_TARGET_MAKE_SEGMENT, return_value=None),
        patch(_TARGET_CONCAT, side_effect=_fake_concat),
        patch(_TARGET_CACHE_BASE, cache_base),
    ):
        result = await run_generate_video(
            project_name="test_project",
            slide_prompt_content=PROMPT_WITH_NARRATION,
            output_path=str(output_mp4),
            voice="roger",
        )

    assert result["status"] == "ok"
    assert result["voice_used"] == "en-US-RogerNeural"
    # Verify TTS was called with the resolved voice
    for call in mock_tts.call_args_list:
        assert call[0][1] == "en-US-RogerNeural"


# ---------------------------------------------------------------------------
# TC-07: Slide range filtering
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_tc07_slide_range_filtering(tmp_path: Path) -> None:
    """Slide range '1' processes only slide 1."""
    from renderdeck_mcp.tools.generate_video import run_generate_video

    cache_base = _setup_cache_dir(tmp_path, "test_project", 2)
    output_mp4 = tmp_path / "output.mp4"

    def _fake_concat(segments: list[Path], out: Path) -> None:
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_bytes(b"\x00" * 1024)
        return None

    def _fake_copy2(src: str, dst: str) -> None:
        Path(dst).parent.mkdir(parents=True, exist_ok=True)
        Path(dst).write_bytes(b"\x00" * 1024)

    with (
        patch(_TARGET_CHECK_FFMPEG, return_value=None),
        patch(_TARGET_GENERATE_TTS, new_callable=AsyncMock),
        patch(_TARGET_MAKE_SEGMENT, return_value=None),
        patch(_TARGET_SHUTIL_COPY2, side_effect=_fake_copy2),
        patch(_TARGET_CACHE_BASE, cache_base),
    ):
        result = await run_generate_video(
            project_name="test_project",
            slide_prompt_content=PROMPT_WITH_NARRATION,
            output_path=str(output_mp4),
            slides="1",
        )

    assert result["status"] == "ok"
    assert result["slide_count"] == 1


# ---------------------------------------------------------------------------
# TC-08: Invalid slide range returns error
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_tc08_invalid_slide_range_returns_error(tmp_path: Path) -> None:
    """Slide range outside deck bounds produces error."""
    from renderdeck_mcp.tools.generate_video import run_generate_video

    cache_base = _setup_cache_dir(tmp_path, "test_project", 2)

    with (
        patch(_TARGET_CHECK_FFMPEG, return_value=None),
        patch(_TARGET_CACHE_BASE, cache_base),
    ):
        result = await run_generate_video(
            project_name="test_project",
            slide_prompt_content=PROMPT_WITH_NARRATION,
            slides="99-100",
        )

    assert result["status"] == "error"
    assert "range" in str(result["message"]).lower()


# ---------------------------------------------------------------------------
# TC-09: parse_slide_range unit tests
# ---------------------------------------------------------------------------


def test_tc09_parse_slide_range() -> None:
    """parse_slide_range handles ranges, lists, and combinations."""
    from renderdeck_mcp.tools.generate_video import parse_slide_range

    assert parse_slide_range("1-3", 5) == [1, 2, 3]
    assert parse_slide_range("2,5,7", 10) == [2, 5, 7]
    assert parse_slide_range("1-3,7", 10) == [1, 2, 3, 7]
    # Out of range filtered
    assert parse_slide_range("1-3", 2) == [1, 2]
    assert parse_slide_range("99", 5) == []


# ---------------------------------------------------------------------------
# TC-10: FFmpeg segment error propagates
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_tc10_ffmpeg_segment_error_propagates(tmp_path: Path) -> None:
    """FFmpeg failure during segment creation returns error."""
    from renderdeck_mcp.tools.generate_video import run_generate_video

    cache_base = _setup_cache_dir(tmp_path, "test_project", 2)
    output_mp4 = tmp_path / "output.mp4"

    with (
        patch(_TARGET_CHECK_FFMPEG, return_value=None),
        patch(_TARGET_GENERATE_TTS, new_callable=AsyncMock),
        patch(_TARGET_MAKE_SEGMENT, return_value="FFmpeg segment error: encoding failed"),
        patch(_TARGET_CACHE_BASE, cache_base),
    ):
        result = await run_generate_video(
            project_name="test_project",
            slide_prompt_content=PROMPT_WITH_NARRATION,
            output_path=str(output_mp4),
        )

    assert result["status"] == "error"
    assert "ffmpeg" in str(result["message"]).lower()
