"""Tests for the generate_slide MCP tool."""

from __future__ import annotations

import io
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch

import pytest
from PIL import Image

from renderdeck_mcp.tools.generate_slide import run_generate_slide


def _make_png() -> bytes:
    buf = io.BytesIO()
    Image.new("RGB", (100, 100), "red").save(buf, format="PNG")
    return buf.getvalue()


# ---------------------------------------------------------------------------
# No API key
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_no_api_key(monkeypatch: pytest.MonkeyPatch) -> None:
    """Returns error when GOOGLE_GEMINI_API_KEY is not set."""
    monkeypatch.delenv("GOOGLE_GEMINI_API_KEY", raising=False)

    result = await run_generate_slide(
        project_name="test",
        slide_number=1,
        image_prompt="A blue slide",
    )

    assert result["status"] == "error"
    assert "API key" in str(result["message"])


# ---------------------------------------------------------------------------
# Cache hit
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_cache_hit(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    """Returns cached result when content hash matches."""
    monkeypatch.setenv("GOOGLE_GEMINI_API_KEY", "fake-key")
    monkeypatch.setattr(
        "renderdeck_mcp.tools.generate_slide._CACHE_BASE_DIR",
        tmp_path / "cache",
    )
    # Patch cache module BEFORE saving manifest so it writes to tmp_path
    monkeypatch.setattr(
        "renderdeck_mcp.generation.cache.CACHE_BASE_DIR",
        tmp_path / "cache",
    )

    # Set up cache directory with an image
    cache_dir = tmp_path / "cache" / "test-proj"
    cache_dir.mkdir(parents=True)
    png = _make_png()
    (cache_dir / "slide_01.png").write_bytes(png)

    # Create a manifest that matches the content hash
    from renderdeck_mcp.generation.cache import (
        CacheManifest,
        content_hash_for_slide,
        options_hash,
        save_cache_manifest,
    )

    opts = options_hash(aspect_ratio="WIDE", model="gemini-3-pro-image-preview")
    c_hash = content_hash_for_slide(general="", global_rules="", image_prompt="A blue slide")
    manifest = CacheManifest(version=1, options_hash=opts, slides={1: c_hash})
    save_cache_manifest("test-proj", manifest)

    result = await run_generate_slide(
        project_name="test-proj",
        slide_number=1,
        image_prompt="A blue slide",
    )

    assert result["status"] == "ok"
    assert result["cached"] is True
    assert result["slide_number"] == 1
    assert "image_size_kb" in result


# ---------------------------------------------------------------------------
# Successful generation
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_successful_generation(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    """Generates image, writes cache, and returns success."""
    monkeypatch.setenv("GOOGLE_GEMINI_API_KEY", "fake-key")
    monkeypatch.setattr(
        "renderdeck_mcp.tools.generate_slide._CACHE_BASE_DIR",
        tmp_path / "cache",
    )
    monkeypatch.setattr(
        "renderdeck_mcp.generation.cache.CACHE_BASE_DIR",
        tmp_path / "cache",
    )

    png = _make_png()
    mock_client = MagicMock()

    with (
        patch(
            "renderdeck_mcp.tools.generate_slide.generate_image",
            new_callable=AsyncMock,
            return_value=png,
        ),
        patch("google.genai.Client", return_value=mock_client),
    ):
        result = await run_generate_slide(
            project_name="test-proj",
            slide_number=1,
            image_prompt="A blue slide",
        )

    assert result["status"] == "ok"
    assert result["cached"] is False
    assert result["slide_number"] == 1
    assert result["image_size_kb"] > 0

    # Verify image was cached
    cached_img = tmp_path / "cache" / "test-proj" / "slide_01.png"
    assert cached_img.is_file()
    assert cached_img.read_bytes() == png


# ---------------------------------------------------------------------------
# Generation failure (returns None)
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_generation_failure(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    """Returns error when image generation fails."""
    monkeypatch.setenv("GOOGLE_GEMINI_API_KEY", "fake-key")
    monkeypatch.setattr(
        "renderdeck_mcp.tools.generate_slide._CACHE_BASE_DIR",
        tmp_path / "cache",
    )
    monkeypatch.setattr(
        "renderdeck_mcp.generation.cache.CACHE_BASE_DIR",
        tmp_path / "cache",
    )

    mock_client = MagicMock()

    with (
        patch(
            "renderdeck_mcp.tools.generate_slide.generate_image",
            new_callable=AsyncMock,
            return_value=None,
        ),
        patch("google.genai.Client", return_value=mock_client),
    ):
        result = await run_generate_slide(
            project_name="test-proj",
            slide_number=2,
            image_prompt="blocked content",
        )

    assert result["status"] == "error"
    assert result["slide_number"] == 2
    assert "failed" in str(result["message"]).lower()


# ---------------------------------------------------------------------------
# Draft quality uses different model
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_draft_quality(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    """Draft quality resolves to flash model."""
    monkeypatch.setenv("GOOGLE_GEMINI_API_KEY", "fake-key")
    monkeypatch.setattr(
        "renderdeck_mcp.tools.generate_slide._CACHE_BASE_DIR",
        tmp_path / "cache",
    )
    monkeypatch.setattr(
        "renderdeck_mcp.generation.cache.CACHE_BASE_DIR",
        tmp_path / "cache",
    )

    png = _make_png()
    captured_config: dict[str, str] = {}

    async def _capture_gen(client: object, request: object, config: object) -> bytes:
        captured_config["model"] = config.model  # type: ignore[union-attr]
        return png

    mock_client = MagicMock()

    with (
        patch(
            "renderdeck_mcp.tools.generate_slide.generate_image",
            side_effect=_capture_gen,
        ),
        patch("google.genai.Client", return_value=mock_client),
    ):
        result = await run_generate_slide(
            project_name="test-proj",
            slide_number=1,
            image_prompt="A slide",
            image_quality="draft",
        )

    assert result["status"] == "ok"
    assert captured_config["model"] == "gemini-3.1-flash-image-preview"


# ---------------------------------------------------------------------------
# Updates existing manifest
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_updates_existing_manifest(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    """Updates manifest with new slide hash after generation."""
    monkeypatch.setenv("GOOGLE_GEMINI_API_KEY", "fake-key")
    monkeypatch.setattr(
        "renderdeck_mcp.tools.generate_slide._CACHE_BASE_DIR",
        tmp_path / "cache",
    )
    monkeypatch.setattr(
        "renderdeck_mcp.generation.cache.CACHE_BASE_DIR",
        tmp_path / "cache",
    )

    # Create an existing manifest with slide 1
    from renderdeck_mcp.generation.cache import (
        CacheManifest,
        load_cache_manifest,
        save_cache_manifest,
    )

    manifest = CacheManifest(version=1, options_hash="old-hash", slides={1: "old-slide-hash"})
    save_cache_manifest("test-proj", manifest)

    png = _make_png()
    mock_client = MagicMock()

    with (
        patch(
            "renderdeck_mcp.tools.generate_slide.generate_image",
            new_callable=AsyncMock,
            return_value=png,
        ),
        patch("google.genai.Client", return_value=mock_client),
    ):
        result = await run_generate_slide(
            project_name="test-proj",
            slide_number=2,
            image_prompt="New slide",
        )

    assert result["status"] == "ok"

    # Verify manifest was updated with slide 2
    updated = load_cache_manifest("test-proj")
    assert updated is not None
    assert 2 in updated.slides
