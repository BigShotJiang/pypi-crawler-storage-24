"""Unit tests for content-hash functions in generation/cache.py.

Tests cover:
- normalize_for_hash: whitespace/line-ending normalization
- content_hash_for_slide: 16-char hex, determinism, sensitivity, edge cases
- options_hash: 16-char hex, determinism, sensitivity, aspect normalization
- Compatibility: hashes match renderdeck.py algorithm for identical inputs
"""

from __future__ import annotations

import hashlib

from renderdeck_mcp.generation.cache import (
    content_hash_for_slide,
    normalize_for_hash,
    options_hash,
)

# ---------------------------------------------------------------------------
# Helpers — inline reference implementation mirroring renderdeck.py exactly
# ---------------------------------------------------------------------------

_HASH_HEX_LEN = 16


def _ref_normalize(text: str) -> str:
    """Reference: renderdeck.py _normalize_for_hash (lines 367-372)."""
    if not text:
        return ""
    s = (text or "").strip().replace("\r\n", "\n").replace("\r", "\n")
    return s.rstrip("\n")


def _ref_content_hash(general: str, global_rules: str, image_prompt: str) -> str:
    """Reference: renderdeck.py _content_hash_for_slide (lines 375-381)."""
    g = _ref_normalize(general)
    r = _ref_normalize(global_rules)
    p = _ref_normalize(image_prompt)
    combined = f"{g}\n\n{r}\n\n{p}"
    return hashlib.sha256(combined.encode("utf-8")).hexdigest()[:_HASH_HEX_LEN]


def _ref_options_hash(aspect_ratio: str, model: str) -> str:
    """Reference: renderdeck.py _options_hash (lines 384-389)."""
    aspect = (aspect_ratio or "WIDE").upper()
    mod = model or "gemini-2.5-flash-image"
    combined = f"{aspect}\n{mod}"
    return hashlib.sha256(combined.encode("utf-8")).hexdigest()[:_HASH_HEX_LEN]


def _is_hex16(value: str) -> bool:
    """Return True if value is exactly 16 lowercase hex characters."""
    return len(value) == 16 and all(c in "0123456789abcdef" for c in value)


# ---------------------------------------------------------------------------
# Group A: normalize_for_hash
# ---------------------------------------------------------------------------


class TestNormalizeForHash:
    def test_empty_string(self) -> None:
        """A-1: empty string returns empty string."""
        assert normalize_for_hash("") == ""

    def test_strips_leading_trailing_whitespace(self) -> None:
        """A-2: leading/trailing whitespace stripped."""
        assert normalize_for_hash("  hello  ") == "hello"

    def test_normalizes_crlf(self) -> None:
        """A-3: CRLF normalized to LF."""
        assert normalize_for_hash("hello\r\nworld") == "hello\nworld"

    def test_normalizes_cr(self) -> None:
        """A-4: bare CR normalized to LF."""
        assert normalize_for_hash("hello\rworld") == "hello\nworld"

    def test_strips_trailing_newline(self) -> None:
        """A-5: trailing newline stripped."""
        assert normalize_for_hash("hello\n") == "hello"

    def test_strips_multiple_trailing_newlines(self) -> None:
        """A-6: multiple trailing newlines stripped."""
        assert normalize_for_hash("hello\n\n\n") == "hello"

    def test_preserves_internal_newlines(self) -> None:
        """A-7: internal newlines are preserved."""
        assert normalize_for_hash("hello\nworld") == "hello\nworld"

    def test_whitespace_only_becomes_empty(self) -> None:
        """A-8: whitespace-only string normalizes to empty string."""
        assert normalize_for_hash("  \n  ") == ""

    def test_matches_reference_for_various_inputs(self) -> None:
        """Normalization matches reference implementation for a variety of inputs."""
        samples = [
            "  leading",
            "trailing  ",
            "mid\r\nnewline",
            "mid\rnewline",
            "multi\n\nline",
            "",
            "clean text",
            "\r\n",
        ]
        for s in samples:
            assert normalize_for_hash(s) == _ref_normalize(s), f"Mismatch for input {s!r}"


# ---------------------------------------------------------------------------
# Group B: content_hash_for_slide
# ---------------------------------------------------------------------------


class TestContentHashForSlide:
    def test_returns_16_char_hex(self) -> None:
        """B-1: result is exactly 16 lowercase hex characters."""
        result = content_hash_for_slide("general", "rules", "prompt")
        assert _is_hex16(result)

    def test_deterministic(self) -> None:
        """B-2: same inputs always produce same hash."""
        h1 = content_hash_for_slide("gen", "rules", "prompt")
        h2 = content_hash_for_slide("gen", "rules", "prompt")
        assert h1 == h2

    def test_different_general_different_hash(self) -> None:
        """B-3: changing general changes the hash."""
        h1 = content_hash_for_slide("general A", "rules", "prompt")
        h2 = content_hash_for_slide("general B", "rules", "prompt")
        assert h1 != h2

    def test_different_global_rules_different_hash(self) -> None:
        """B-4: changing global_rules changes the hash."""
        h1 = content_hash_for_slide("general", "rules A", "prompt")
        h2 = content_hash_for_slide("general", "rules B", "prompt")
        assert h1 != h2

    def test_different_image_prompt_different_hash(self) -> None:
        """B-5: changing image_prompt changes the hash."""
        h1 = content_hash_for_slide("general", "rules", "prompt A")
        h2 = content_hash_for_slide("general", "rules", "prompt B")
        assert h1 != h2

    def test_one_char_change_different_hash(self) -> None:
        """B-6: a single character change in any field produces a different hash."""
        base = content_hash_for_slide("A spaceship launching", "Blue tones", "Starfield")
        changed = content_hash_for_slide("A spaceship launchingX", "Blue tones", "Starfield")
        assert base != changed

    def test_all_empty_inputs_valid_hash(self) -> None:
        """B-7: all empty strings produce a valid 16-char hex hash."""
        result = content_hash_for_slide("", "", "")
        assert _is_hex16(result)

    def test_empty_image_prompt_valid_hash(self) -> None:
        """B-8: empty image_prompt with non-empty others produces a valid hash."""
        result = content_hash_for_slide("some general", "some rules", "")
        assert _is_hex16(result)

    def test_whitespace_only_same_as_empty(self) -> None:
        """B-9: whitespace-only inputs normalize to the same hash as all-empty."""
        h_empty = content_hash_for_slide("", "", "")
        h_ws = content_hash_for_slide("   ", "\n\n", "\t")
        assert h_empty == h_ws

    def test_compatibility_with_renderdeck(self) -> None:
        """B-10: produces identical hash to renderdeck.py for known inputs."""
        general = "A dark sci-fi presentation about the future of AI"
        global_rules = "Use blue tones and cinematic lighting"
        image_prompt = "A spaceship launching from a distant planet"

        expected = _ref_content_hash(general, global_rules, image_prompt)
        actual = content_hash_for_slide(general, global_rules, image_prompt)
        assert actual == expected

    def test_compatibility_multiline_input(self) -> None:
        """Compatibility: multiline inputs hash identically to reference."""
        general = "Line one\nLine two\nLine three"
        global_rules = "Rule A\nRule B"
        image_prompt = "A mountain\nAt dawn"

        expected = _ref_content_hash(general, global_rules, image_prompt)
        actual = content_hash_for_slide(general, global_rules, image_prompt)
        assert actual == expected

    def test_compatibility_crlf_input(self) -> None:
        """Compatibility: CRLF line endings hash identically to reference."""
        general = "Intro\r\nContext"
        global_rules = "Bold\r\nItalic"
        image_prompt = "Scene\r\nDescription"

        expected = _ref_content_hash(general, global_rules, image_prompt)
        actual = content_hash_for_slide(general, global_rules, image_prompt)
        assert actual == expected

    def test_trailing_whitespace_normalization(self) -> None:
        """Inputs with trailing newlines hash same as stripped versions."""
        h1 = content_hash_for_slide("gen\n", "rules\n", "prompt\n")
        h2 = content_hash_for_slide("gen", "rules", "prompt")
        assert h1 == h2


# ---------------------------------------------------------------------------
# Group C: options_hash
# ---------------------------------------------------------------------------


class TestOptionsHash:
    def test_returns_16_char_hex(self) -> None:
        """C-1: result is exactly 16 lowercase hex characters."""
        result = options_hash("WIDE", "gemini-2.5-flash-image")
        assert _is_hex16(result)

    def test_deterministic(self) -> None:
        """C-2: same inputs always produce same hash."""
        h1 = options_hash("WIDE", "gemini-2.5-flash-image")
        h2 = options_hash("WIDE", "gemini-2.5-flash-image")
        assert h1 == h2

    def test_different_aspect_ratio_different_hash(self) -> None:
        """C-3: different aspect_ratio produces different hash."""
        h1 = options_hash("WIDE", "gemini-2.5-flash-image")
        h2 = options_hash("TALL", "gemini-2.5-flash-image")
        assert h1 != h2

    def test_different_model_different_hash(self) -> None:
        """C-4: different model produces different hash."""
        h1 = options_hash("WIDE", "gemini-2.5-flash-image")
        h2 = options_hash("WIDE", "gemini-2.0-flash-image")
        assert h1 != h2

    def test_lowercase_aspect_same_as_uppercase(self) -> None:
        """C-5: lowercase aspect_ratio normalized to uppercase — hashes match."""
        h_lower = options_hash("wide", "gemini-2.5-flash-image")
        h_upper = options_hash("WIDE", "gemini-2.5-flash-image")
        assert h_lower == h_upper

    def test_mixed_case_aspect_normalized(self) -> None:
        """C-5b: mixed-case aspect_ratio normalized to uppercase."""
        h_mixed = options_hash("Wide", "gemini-2.5-flash-image")
        h_upper = options_hash("WIDE", "gemini-2.5-flash-image")
        assert h_mixed == h_upper

    def test_compatibility_with_renderdeck(self) -> None:
        """C-6: produces identical hash to renderdeck.py for known inputs."""
        aspect = "WIDE"
        model = "gemini-2.5-flash-image"

        expected = _ref_options_hash(aspect, model)
        actual = options_hash(aspect, model)
        assert actual == expected

    def test_compatibility_square_aspect(self) -> None:
        """Compatibility: SQUARE aspect ratio hashes identically to reference."""
        expected = _ref_options_hash("SQUARE", "gemini-2.0-flash-image")
        actual = options_hash("SQUARE", "gemini-2.0-flash-image")
        assert actual == expected

    def test_compatibility_tall_aspect(self) -> None:
        """Compatibility: TALL aspect ratio hashes identically to reference."""
        expected = _ref_options_hash("TALL", "gemini-2.5-flash-image")
        actual = options_hash("TALL", "gemini-2.5-flash-image")
        assert actual == expected
