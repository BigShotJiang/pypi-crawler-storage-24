"""Tests for config management (config.py and tools/setup.py)."""

from __future__ import annotations

import json
import stat
from pathlib import Path
from unittest.mock import patch

import pytest

from renderdeck_mcp import config as cfg
from renderdeck_mcp.tools.setup import run_get_setup_status, run_setup_gemini_key


@pytest.fixture(autouse=True)
def _isolated_config(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    """Redirect config dir to a temp directory for every test."""
    config_dir = tmp_path / ".renderdeck"
    monkeypatch.setattr(cfg, "CONFIG_DIR", config_dir)
    monkeypatch.setattr(cfg, "CONFIG_FILE", config_dir / "config.json")
    monkeypatch.setattr(cfg, "_KEY_FILE", config_dir / ".fernet_key")
    # Clear any env var override
    monkeypatch.delenv("GOOGLE_GEMINI_API_KEY", raising=False)


class TestConfigBasics:
    """Tests for low-level config read/write."""

    def test_ensure_config_dir_creates_dir(self) -> None:
        cfg._ensure_config_dir()
        assert cfg.CONFIG_DIR.is_dir()

    def test_read_config_empty_when_no_file(self) -> None:
        assert cfg._read_config() == {}

    def test_write_and_read_config(self) -> None:
        data = {"key": "value", "nested": {"a": 1}}
        cfg._write_config(data)
        assert cfg._read_config() == data

    def test_config_file_permissions(self) -> None:
        cfg._write_config({"test": True})
        mode = cfg.CONFIG_FILE.stat().st_mode
        assert mode & stat.S_IRWXG == 0  # no group access
        assert mode & stat.S_IRWXO == 0  # no other access

    def test_corrupted_config_returns_empty(self) -> None:
        cfg._ensure_config_dir()
        cfg.CONFIG_FILE.write_text("not json", encoding="utf-8")
        assert cfg._read_config() == {}


class TestEncryption:
    """Tests for Fernet encrypt/decrypt of API keys."""

    def test_encrypt_decrypt_roundtrip(self) -> None:
        encrypted = cfg.encrypt_api_key("test-key-12345")
        assert encrypted != "test-key-12345"  # not plaintext
        decrypted = cfg.decrypt_api_key(encrypted)
        assert decrypted == "test-key-12345"

    def test_encrypted_key_not_plaintext_in_config(self) -> None:
        cfg.store_api_key("my-secret-key")
        raw = cfg.CONFIG_FILE.read_text(encoding="utf-8")
        assert "my-secret-key" not in raw

    def test_decrypt_invalid_token_returns_none(self) -> None:
        assert cfg.decrypt_api_key("not-valid-fernet-token") is None


class TestGetApiKey:
    """Tests for API key resolution."""

    def test_env_var_takes_priority(self, monkeypatch: pytest.MonkeyPatch) -> None:
        cfg.store_api_key("stored-key")
        monkeypatch.setenv("GOOGLE_GEMINI_API_KEY", "env-key")
        assert cfg.get_api_key() == "env-key"

    def test_stored_key_used_when_no_env(self) -> None:
        cfg.store_api_key("stored-key")
        assert cfg.get_api_key() == "stored-key"

    def test_no_key_returns_none(self) -> None:
        assert cfg.get_api_key() is None


class TestSettings:
    """Tests for settings management."""

    def test_get_setting_returns_default(self) -> None:
        assert cfg.get_setting("aspect_ratio") == "WIDE"

    def test_update_settings_persists(self) -> None:
        cfg.update_settings({"aspect_ratio": "STANDARD"})
        assert cfg.get_setting("aspect_ratio") == "STANDARD"

    def test_update_preserves_other_settings(self) -> None:
        cfg.update_settings({"aspect_ratio": "STANDARD", "verbose": True})
        cfg.update_settings({"verbose": False})
        assert cfg.get_setting("aspect_ratio") == "STANDARD"
        assert cfg.get_setting("verbose") is False

    def test_update_returns_merged(self) -> None:
        result = cfg.update_settings({"verbose": True})
        assert result["verbose"] is True
        assert "aspect_ratio" in result  # default still present


class TestGetSetupStatus:
    """Tests for get_setup_status."""

    def test_no_key_not_ready(self) -> None:
        status = cfg.get_setup_status()
        assert status["ready"] is False
        assert status["gemini_key_configured"] is False
        assert len(status["issues"]) > 0

    def test_with_key_ready(self) -> None:
        cfg.store_api_key("test-key")
        status = cfg.get_setup_status()
        assert status["ready"] is True
        assert status["gemini_key_configured"] is True
        assert status["issues"] == []

    def test_status_includes_settings(self) -> None:
        status = cfg.get_setup_status()
        assert "gemini_model" in status
        assert "aspect_ratio" in status


class TestSetupGeminiKeyTool:
    """Tests for run_setup_gemini_key (MCP tool logic)."""

    def test_empty_key_returns_error(self) -> None:
        result = run_setup_gemini_key("")
        assert result["status"] == "error"
        assert "empty" in result["message"].lower()

    def test_invalid_key_returns_error(self) -> None:
        with patch(
            "renderdeck_mcp.tools.setup._validate_api_key",
            return_value=False,
        ):
            result = run_setup_gemini_key("bad-key")
        assert result["status"] == "error"
        assert "invalid" in result["message"].lower()

    def test_valid_key_stores_and_succeeds(self) -> None:
        with patch(
            "renderdeck_mcp.tools.setup._validate_api_key",
            return_value=True,
        ):
            result = run_setup_gemini_key("valid-key-123")
        assert result["status"] == "success"
        # Verify key is actually stored
        assert cfg.get_api_key() == "valid-key-123"

    def test_key_not_in_response(self) -> None:
        with patch(
            "renderdeck_mcp.tools.setup._validate_api_key",
            return_value=True,
        ):
            result = run_setup_gemini_key("secret-key-xyz")
        # Key must never appear in response
        response_str = json.dumps(result)
        assert "secret-key-xyz" not in response_str

    def test_key_not_in_error_response(self) -> None:
        with patch(
            "renderdeck_mcp.tools.setup._validate_api_key",
            return_value=False,
        ):
            result = run_setup_gemini_key("secret-key-xyz")
        response_str = json.dumps(result)
        assert "secret-key-xyz" not in response_str


class TestGetSetupStatusTool:
    """Tests for run_get_setup_status (MCP tool wrapper)."""

    def test_returns_dict(self) -> None:
        result = run_get_setup_status()
        assert isinstance(result, dict)
        assert "ready" in result
        assert "gemini_key_configured" in result

    def test_env_var_override_shows_ready(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setenv("GOOGLE_GEMINI_API_KEY", "env-key")
        result = run_get_setup_status()
        assert result["ready"] is True
        assert result["gemini_key_configured"] is True
