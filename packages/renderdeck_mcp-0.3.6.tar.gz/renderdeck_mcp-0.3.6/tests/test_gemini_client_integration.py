"""Integration tests for renderdeck_mcp.generation.gemini.

TC-25: Module importability — the module and all public symbols import cleanly.
TC-26: End-to-end batch with mocked SDK — full generate_images_concurrent call
       with multiple slides, mixed success/failure, verifying the complete data
       flow from SlideImageRequest through to ImageResult list.

Unlike the unit tests (test_gemini_client.py) which test individual functions
in isolation, these tests exercise the full call chain end-to-end with the
google.genai.Client mocked at the module boundary.

Run with:
    uv run pytest tests/test_gemini_client_integration.py -v -m integration
"""

from __future__ import annotations

import sys
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

# ---------------------------------------------------------------------------
# TC-25: Module importability
# ---------------------------------------------------------------------------


@pytest.mark.integration
class TestModuleImportability:
    """TC-25: Verify the module and all public symbols import cleanly."""

    def test_tc25_module_imports_without_error(self) -> None:
        """import renderdeck_mcp.generation.gemini completes without error."""
        # If this fails the module has a syntax error or a broken top-level import.
        import renderdeck_mcp.generation.gemini  # noqa: F401

        assert "renderdeck_mcp.generation.gemini" in sys.modules

    def test_tc25_public_classes_exported(self) -> None:
        """All public dataclasses and the enum are accessible on the module."""
        from renderdeck_mcp.generation.gemini import (
            AspectRatio,
            GeminiConfig,
            ImageResult,
            SlideImageRequest,
        )

        assert AspectRatio is not None
        assert GeminiConfig is not None
        assert ImageResult is not None
        assert SlideImageRequest is not None

    def test_tc25_public_functions_exported(self) -> None:
        """Both public async functions are accessible on the module."""
        import inspect

        from renderdeck_mcp.generation.gemini import (
            generate_image,
            generate_images_concurrent,
        )

        assert inspect.iscoroutinefunction(generate_image)
        assert inspect.iscoroutinefunction(generate_images_concurrent)

    def test_tc25_internal_helpers_accessible(self) -> None:
        """Internal helpers used by unit tests are importable (not part of public API contract
        but must remain accessible for white-box testing)."""
        from renderdeck_mcp.generation.gemini import (
            _build_prompt,
            _extract_image_bytes,
            _is_content_policy_block,
            _is_retryable,
        )

        assert callable(_build_prompt)
        assert callable(_extract_image_bytes)
        assert callable(_is_content_policy_block)
        assert callable(_is_retryable)

    def test_tc25_deprecated_sdk_absent_after_import(self) -> None:
        """sys.modules must not contain google.generativeai after importing the module.

        The implementation must use google.genai exclusively. This check fails if the
        deprecated google-generativeai package is imported anywhere in the module's
        import chain.
        """
        import renderdeck_mcp.generation.gemini  # noqa: F401

        assert "google.generativeai" not in sys.modules, (
            "Deprecated 'google.generativeai' package was imported. Use 'google.genai' only."
        )

    def test_tc25_aspect_ratio_values_present(self) -> None:
        """AspectRatio enum has WIDE and STANDARD members with correct string values."""
        from renderdeck_mcp.generation.gemini import AspectRatio

        assert AspectRatio.WIDE.value == "16:9"
        assert AspectRatio.STANDARD.value == "4:3"

    def test_tc25_gemini_config_is_frozen_dataclass(self) -> None:
        """GeminiConfig is a frozen dataclass — mutation raises FrozenInstanceError."""
        import dataclasses

        from renderdeck_mcp.generation.gemini import GeminiConfig

        cfg = GeminiConfig(api_key="k")
        assert dataclasses.is_dataclass(cfg)
        with pytest.raises(dataclasses.FrozenInstanceError):
            cfg.api_key = "other"  # type: ignore[misc]

    def test_tc25_slide_image_request_is_frozen_dataclass(self) -> None:
        """SlideImageRequest is a frozen dataclass — mutation raises FrozenInstanceError."""
        import dataclasses

        from renderdeck_mcp.generation.gemini import AspectRatio, SlideImageRequest

        req = SlideImageRequest(slide_index=0, prompt="test")
        assert dataclasses.is_dataclass(req)
        assert req.aspect_ratio == AspectRatio.WIDE
        with pytest.raises(dataclasses.FrozenInstanceError):
            req.slide_index = 99  # type: ignore[misc]

    def test_tc25_image_result_is_mutable_dataclass(self) -> None:
        """ImageResult is a regular (non-frozen) dataclass."""
        import dataclasses

        from renderdeck_mcp.generation.gemini import ImageResult

        result = ImageResult(slide_index=0, image_bytes=None, fallback=True)
        assert dataclasses.is_dataclass(result)
        # Mutable: assignment must not raise
        result.error = "some error"
        assert result.error == "some error"

    def test_tc25_gemini_config_default_values(self) -> None:
        """GeminiConfig default field values match the design specification."""
        from renderdeck_mcp.generation.gemini import GeminiConfig

        cfg = GeminiConfig(api_key="k")
        assert cfg.model == "gemini-3-pro-image-preview"
        assert cfg.max_retries == 3
        assert cfg.max_concurrent_images == 5
        assert cfg.retry_delays == (1.0, 2.0, 4.0)


# ---------------------------------------------------------------------------
# Shared fixtures for TC-26
# ---------------------------------------------------------------------------


@pytest.fixture
def png_bytes() -> bytes:
    """Minimal valid PNG header bytes."""
    return b"\x89PNG\r\n\x1a\n" + b"\x00" * 20


@pytest.fixture
def fast_config():  # type: ignore[no-untyped-def]
    """GeminiConfig with zero retry delays and concurrency=3 for fast tests."""
    from renderdeck_mcp.generation.gemini import GeminiConfig

    return GeminiConfig(
        api_key="integration-test-key",
        model="gemini-2.5-flash-image",
        max_retries=3,
        max_concurrent_images=3,
        retry_delays=(0.0, 0.0, 0.0),
    )


def _make_success_response(data: bytes) -> MagicMock:
    """Build a mock Gemini response that yields the given image bytes via inline_data."""
    part = MagicMock()
    part.inline_data.data = data
    response = MagicMock()
    response.parts = [part]
    return response


def _make_empty_response() -> MagicMock:
    """Build a mock Gemini response with no image parts (simulates empty/text-only reply)."""
    response = MagicMock()
    response.parts = []
    response.candidates = []
    return response


# ---------------------------------------------------------------------------
# TC-26: End-to-end batch — full call chain through generate_images_concurrent
# ---------------------------------------------------------------------------


@pytest.mark.integration
class TestEndToEndBatch:
    """TC-26: Full generate_images_concurrent call with mocked SDK at the module boundary.

    These tests verify the complete data flow: SlideImageRequest list in,
    ImageResult list out, with the google.genai.Client patched at the module
    boundary so no real network calls are made.
    """

    async def test_tc26_all_slides_succeed(
        self,
        fast_config: object,
        png_bytes: bytes,
    ) -> None:
        """All three slides return valid PNG bytes; no fallbacks."""
        from renderdeck_mcp.generation.gemini import SlideImageRequest, generate_images_concurrent

        requests = [
            SlideImageRequest(
                slide_index=0,
                prompt="Opening slide: company logo on dark background",
                general_context="Tech startup pitch deck",
                visual_rules="Vibrant colors, clean lines",
            ),
            SlideImageRequest(
                slide_index=1,
                prompt="Problem statement: fragmented data landscape",
                general_context="Tech startup pitch deck",
                visual_rules="Vibrant colors, clean lines",
            ),
            SlideImageRequest(
                slide_index=2,
                prompt="Solution overview: unified data platform",
                general_context="Tech startup pitch deck",
                visual_rules="Vibrant colors, clean lines",
            ),
        ]

        # Each slide gets a distinct byte sequence to verify order preservation.
        slide_bytes = [bytes([i]) * 28 + png_bytes for i in range(3)]

        with (
            patch("renderdeck_mcp.generation.gemini.genai.Client") as mock_cls,
            patch("asyncio.sleep", new_callable=AsyncMock),
        ):
            mock_instance = MagicMock()
            mock_cls.return_value = mock_instance
            mock_instance.models.generate_content.side_effect = [
                _make_success_response(slide_bytes[0]),
                _make_success_response(slide_bytes[1]),
                _make_success_response(slide_bytes[2]),
            ]

            results = await generate_images_concurrent(requests, fast_config)  # type: ignore[arg-type]

        assert len(results) == 3

        for i, result in enumerate(results):
            assert result.slide_index == i, f"Expected slide_index={i}, got {result.slide_index}"
            assert result.fallback is False, f"Slide {i} should not be a fallback"
            assert result.image_bytes == slide_bytes[i], f"Slide {i} image_bytes mismatch"
            assert result.error is None

        # Client must have been constructed with the api_key from config.
        mock_cls.assert_called_once_with(api_key="integration-test-key")

    async def test_tc26_mixed_success_and_failure(
        self,
        fast_config: object,
        png_bytes: bytes,
    ) -> None:
        """Slides 0 and 2 succeed; slide 1 fails on all retries → fallback=True.

        Verifies that a single slide failure is contained and does not abort the batch.
        The failing slide receives fallback=True and image_bytes=None in its result,
        while the other slides complete normally.
        """
        from renderdeck_mcp.generation.gemini import SlideImageRequest, generate_images_concurrent

        requests = [
            SlideImageRequest(slide_index=0, prompt="slide_zero_ok"),
            SlideImageRequest(slide_index=1, prompt="slide_one_FAIL"),
            SlideImageRequest(slide_index=2, prompt="slide_two_ok"),
        ]

        def _side_effect(model: str, contents: str, config: object) -> MagicMock:
            if "FAIL" in contents:
                raise Exception("HTTP 429: quota exceeded")
            return _make_success_response(png_bytes)

        with (
            patch("renderdeck_mcp.generation.gemini.genai.Client") as mock_cls,
            patch("asyncio.sleep", new_callable=AsyncMock),
        ):
            mock_instance = MagicMock()
            mock_cls.return_value = mock_instance
            mock_instance.models.generate_content.side_effect = _side_effect

            results = await generate_images_concurrent(requests, fast_config)  # type: ignore[arg-type]

        assert len(results) == 3

        # Slide 0 — success
        assert results[0].slide_index == 0
        assert results[0].fallback is False
        assert results[0].image_bytes == png_bytes

        # Slide 1 — all retries exhausted; must be fallback
        assert results[1].slide_index == 1
        assert results[1].fallback is True
        assert results[1].image_bytes is None

        # Slide 2 — success despite slide 1 failure
        assert results[2].slide_index == 2
        assert results[2].fallback is False
        assert results[2].image_bytes == png_bytes

    async def test_tc26_all_slides_fail(self, fast_config: object) -> None:
        """When every slide fails on all retries, all results have fallback=True.

        The function must not raise even when every single slide fails.
        """
        from renderdeck_mcp.generation.gemini import SlideImageRequest, generate_images_concurrent

        requests = [SlideImageRequest(slide_index=i, prompt=f"slide_{i}") for i in range(4)]

        with (
            patch("renderdeck_mcp.generation.gemini.genai.Client") as mock_cls,
            patch("asyncio.sleep", new_callable=AsyncMock),
        ):
            mock_instance = MagicMock()
            mock_cls.return_value = mock_instance
            mock_instance.models.generate_content.side_effect = Exception(
                "HTTP 503: service unavailable"
            )

            # Must not raise — all failures are contained
            results = await generate_images_concurrent(requests, fast_config)  # type: ignore[arg-type]

        assert len(results) == 4
        for i, result in enumerate(results):
            assert result.slide_index == i
            assert result.fallback is True
            assert result.image_bytes is None

    async def test_tc26_output_order_matches_input_order(
        self,
        fast_config: object,
        png_bytes: bytes,
    ) -> None:
        """Results are returned in input order even when tasks complete out of order.

        Uses asyncio.to_thread mock with staggered delays: slide 2 completes first,
        slide 0 last. The result list must still be ordered [0, 1, 2].
        """
        import asyncio

        from renderdeck_mcp.generation.gemini import SlideImageRequest, generate_images_concurrent

        requests = [
            SlideImageRequest(slide_index=0, prompt="slow_slide"),
            SlideImageRequest(slide_index=1, prompt="medium_slide"),
            SlideImageRequest(slide_index=2, prompt="fast_slide"),
        ]

        # Completion order: slide 2, slide 1, slide 0 (reversed).
        # We simulate this by giving each slide a different delay in the to_thread mock.
        call_count = {"n": 0}
        delays = [0.03, 0.02, 0.01]  # slide 0 slowest, slide 2 fastest
        slide_bytes = [bytes([i + 10]) * 8 + png_bytes for i in range(3)]

        async def _ordered_generate(*args: object, **kwargs: object) -> MagicMock:
            idx = call_count["n"]
            call_count["n"] += 1
            await asyncio.sleep(delays[idx])
            return _make_success_response(slide_bytes[idx])

        with (
            patch("renderdeck_mcp.generation.gemini.genai.Client") as mock_cls,
            patch(
                "renderdeck_mcp.generation.gemini.asyncio.to_thread",
                side_effect=_ordered_generate,
            ),
        ):
            mock_cls.return_value = MagicMock()
            results = await generate_images_concurrent(requests, fast_config)  # type: ignore[arg-type]

        assert len(results) == 3
        for i, result in enumerate(results):
            assert result.slide_index == i, (
                f"Position {i} has slide_index={result.slide_index}; expected {i}"
            )
            assert result.image_bytes == slide_bytes[i]
            assert result.fallback is False

    async def test_tc26_client_constructed_once_per_batch(
        self,
        fast_config: object,
        png_bytes: bytes,
    ) -> None:
        """genai.Client is constructed exactly once for the entire batch.

        Constructing a client per slide would be expensive. The implementation
        must share one client instance across all concurrent tasks.
        """
        from renderdeck_mcp.generation.gemini import SlideImageRequest, generate_images_concurrent

        requests = [SlideImageRequest(slide_index=i, prompt=f"slide_{i}") for i in range(5)]

        with (
            patch("renderdeck_mcp.generation.gemini.genai.Client") as mock_cls,
            patch("asyncio.sleep", new_callable=AsyncMock),
        ):
            mock_instance = MagicMock()
            mock_cls.return_value = mock_instance
            mock_instance.models.generate_content.return_value = _make_success_response(png_bytes)

            results = await generate_images_concurrent(requests, fast_config)  # type: ignore[arg-type]

        # Exactly one client construction for the whole batch
        assert mock_cls.call_count == 1, (
            f"Expected genai.Client to be constructed once; was called {mock_cls.call_count} times"
        )
        # Five slides → five generate_content calls
        assert mock_instance.models.generate_content.call_count == 5
        assert len(results) == 5

    async def test_tc26_prompt_data_flows_through_to_sdk_call(
        self,
        fast_config: object,
        png_bytes: bytes,
    ) -> None:
        """The prompt, general_context, and visual_rules in SlideImageRequest reach the SDK.

        Verifies that _build_prompt output is forwarded to client.models.generate_content
        and that all three sections appear in the call's contents argument.
        """
        from renderdeck_mcp.generation.gemini import (
            AspectRatio,
            SlideImageRequest,
            generate_images_concurrent,
        )

        requests = [
            SlideImageRequest(
                slide_index=0,
                prompt="A distinctive slide prompt marker",
                general_context="A distinctive context marker",
                visual_rules="A distinctive rules marker",
                aspect_ratio=AspectRatio.WIDE,
            ),
        ]

        captured_contents: list[str] = []

        def _capture(model: str, contents: str, config: object) -> MagicMock:
            captured_contents.append(contents)
            return _make_success_response(png_bytes)

        with (
            patch("renderdeck_mcp.generation.gemini.genai.Client") as mock_cls,
            patch("asyncio.sleep", new_callable=AsyncMock),
        ):
            mock_instance = MagicMock()
            mock_cls.return_value = mock_instance
            mock_instance.models.generate_content.side_effect = _capture

            await generate_images_concurrent(requests, fast_config)  # type: ignore[arg-type]

        assert len(captured_contents) == 1
        prompt_text = captured_contents[0]
        assert "A distinctive slide prompt marker" in prompt_text
        assert "A distinctive context marker" in prompt_text
        assert "A distinctive rules marker" in prompt_text
        assert "SLIDE IMAGE PROMPT:" in prompt_text
        assert "GENERAL CONTEXT:" in prompt_text
        assert "GLOBAL VISUAL RULES:" in prompt_text

    async def test_tc26_content_policy_block_produces_fallback(
        self,
        fast_config: object,
        png_bytes: bytes,
    ) -> None:
        """A content policy exception on one slide produces fallback=True for that slide only.

        The policy-blocked slide must not be retried (only one SDK call for that slide),
        and the other slides must still succeed.
        """
        from renderdeck_mcp.generation.gemini import SlideImageRequest, generate_images_concurrent

        requests = [
            SlideImageRequest(slide_index=0, prompt="safe_prompt"),
            SlideImageRequest(slide_index=1, prompt="blocked_PROHIBITED_CONTENT_prompt"),
            SlideImageRequest(slide_index=2, prompt="also_safe_prompt"),
        ]

        call_counts: dict[str, int] = {}

        def _side_effect(model: str, contents: str, config: object) -> MagicMock:
            # Track how many times each slide's prompt was sent to the SDK
            for prompt in ["safe_prompt", "blocked_PROHIBITED_CONTENT_prompt", "also_safe_prompt"]:
                if prompt in contents:
                    call_counts[prompt] = call_counts.get(prompt, 0) + 1
            if "PROHIBITED_CONTENT" in contents:
                raise Exception("Content blocked: PROHIBITED_CONTENT policy violation")
            return _make_success_response(png_bytes)

        with (
            patch("renderdeck_mcp.generation.gemini.genai.Client") as mock_cls,
            patch("asyncio.sleep", new_callable=AsyncMock),
        ):
            mock_instance = MagicMock()
            mock_cls.return_value = mock_instance
            mock_instance.models.generate_content.side_effect = _side_effect

            results = await generate_images_concurrent(requests, fast_config)  # type: ignore[arg-type]

        # Slide 0 and 2 succeed
        assert results[0].fallback is False
        assert results[0].image_bytes == png_bytes
        assert results[2].fallback is False
        assert results[2].image_bytes == png_bytes

        # Slide 1 is a fallback (policy block)
        assert results[1].fallback is True
        assert results[1].image_bytes is None

        # Policy-blocked slide must not have been retried (exactly 1 SDK call)
        assert call_counts.get("blocked_PROHIBITED_CONTENT_prompt", 0) == 1, (
            "Policy-blocked slide should not be retried"
        )

    async def test_tc26_empty_batch_returns_empty_list(
        self,
        fast_config: object,
    ) -> None:
        """generate_images_concurrent with an empty requests list returns []."""
        from renderdeck_mcp.generation.gemini import generate_images_concurrent

        with patch("renderdeck_mcp.generation.gemini.genai.Client") as mock_cls:
            mock_cls.return_value = MagicMock()
            results = await generate_images_concurrent([], fast_config)  # type: ignore[arg-type]

        assert results == []

    async def test_tc26_single_slide_batch(
        self,
        fast_config: object,
        png_bytes: bytes,
    ) -> None:
        """A batch with a single slide returns a single-element ImageResult list."""
        from renderdeck_mcp.generation.gemini import SlideImageRequest, generate_images_concurrent

        requests = [SlideImageRequest(slide_index=0, prompt="solo slide")]

        with (
            patch("renderdeck_mcp.generation.gemini.genai.Client") as mock_cls,
            patch("asyncio.sleep", new_callable=AsyncMock),
        ):
            mock_instance = MagicMock()
            mock_cls.return_value = mock_instance
            mock_instance.models.generate_content.return_value = _make_success_response(png_bytes)

            results = await generate_images_concurrent(requests, fast_config)  # type: ignore[arg-type]

        assert len(results) == 1
        assert results[0].slide_index == 0
        assert results[0].fallback is False
        assert results[0].image_bytes == png_bytes

    async def test_tc26_retry_then_success_counted_in_result(
        self,
        png_bytes: bytes,
    ) -> None:
        """A slide that fails twice then succeeds on the third attempt returns fallback=False.

        Verifies that retry logic is correctly wired through the full call chain:
        generate_images_concurrent -> _bounded -> generate_image -> retry loop.
        """
        from renderdeck_mcp.generation.gemini import (
            GeminiConfig,
            SlideImageRequest,
            generate_images_concurrent,
        )

        config = GeminiConfig(
            api_key="test-key",
            model="gemini-2.5-flash-image",
            max_retries=3,
            max_concurrent_images=1,
            retry_delays=(0.0, 0.0, 0.0),
        )

        requests = [SlideImageRequest(slide_index=0, prompt="eventually_ok")]

        with (
            patch("renderdeck_mcp.generation.gemini.genai.Client") as mock_cls,
            patch("asyncio.sleep", new_callable=AsyncMock),
        ):
            mock_instance = MagicMock()
            mock_cls.return_value = mock_instance
            mock_instance.models.generate_content.side_effect = [
                Exception("HTTP 503: service unavailable"),
                Exception("HTTP 503: service unavailable"),
                _make_success_response(png_bytes),
            ]

            results = await generate_images_concurrent(requests, config)

        assert len(results) == 1
        assert results[0].slide_index == 0
        assert results[0].fallback is False
        assert results[0].image_bytes == png_bytes
        # Two failures + one success = 3 SDK calls total
        assert mock_instance.models.generate_content.call_count == 3
