"""Unit tests for cache manifest load/save/should_regenerate functions.

Tests use tmp_path to avoid any writes to the real ~/.renderdeck directory.
CACHE_BASE_DIR is monkey-patched in each test that does I/O.
"""

from __future__ import annotations

import json
from pathlib import Path

import pytest

from renderdeck_mcp.generation import cache

# ---------------------------------------------------------------------------
# TC-01: load returns None for missing manifest file
# ---------------------------------------------------------------------------


def test_load_missing_file_returns_none(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(cache, "CACHE_BASE_DIR", tmp_path)
    project_dir = tmp_path / "myproject"
    project_dir.mkdir(parents=True)
    result = cache.load_cache_manifest("myproject")
    assert result is None


# ---------------------------------------------------------------------------
# TC-02: load returns None when the cache directory itself is absent
# ---------------------------------------------------------------------------


def test_load_missing_dir_returns_none(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(cache, "CACHE_BASE_DIR", tmp_path / "nonexistent")
    result = cache.load_cache_manifest("myproject")
    assert result is None


# ---------------------------------------------------------------------------
# TC-03: load returns None for corrupted JSON
# ---------------------------------------------------------------------------


def test_load_corrupted_json_returns_none(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(cache, "CACHE_BASE_DIR", tmp_path)
    cache_dir = tmp_path / "myproject"
    cache_dir.mkdir(parents=True)
    (cache_dir / cache.CACHE_MANIFEST_FILE).write_text("not json {{{{", encoding="utf-8")
    result = cache.load_cache_manifest("myproject")
    assert result is None


# ---------------------------------------------------------------------------
# TC-04: load returns None for wrong version number
# ---------------------------------------------------------------------------


def test_load_wrong_version_returns_none(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(cache, "CACHE_BASE_DIR", tmp_path)
    cache_dir = tmp_path / "myproject"
    cache_dir.mkdir(parents=True)
    data = {"version": 99, "options_hash": "aaaa", "slides": {}}
    (cache_dir / cache.CACHE_MANIFEST_FILE).write_text(json.dumps(data), encoding="utf-8")
    result = cache.load_cache_manifest("myproject")
    assert result is None


# ---------------------------------------------------------------------------
# TC-05: load returns valid CacheManifest for well-formed file
# ---------------------------------------------------------------------------


def test_load_valid_manifest(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(cache, "CACHE_BASE_DIR", tmp_path)
    cache_dir = tmp_path / "myproject"
    cache_dir.mkdir(parents=True)
    data = {
        "version": 1,
        "options_hash": "abc123",
        "slides": {"1": "hash1", "2": "hash2"},
    }
    (cache_dir / cache.CACHE_MANIFEST_FILE).write_text(json.dumps(data), encoding="utf-8")
    result = cache.load_cache_manifest("myproject")
    assert result is not None
    assert result.version == 1
    assert result.options_hash == "abc123"
    assert result.slides == {1: "hash1", 2: "hash2"}


# ---------------------------------------------------------------------------
# TC-06: save creates the cache directory when it does not exist
# ---------------------------------------------------------------------------


def test_save_creates_directory(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(cache, "CACHE_BASE_DIR", tmp_path)
    manifest = cache.CacheManifest(version=1, options_hash="opt1", slides={})
    cache.save_cache_manifest("newproject", manifest)
    assert (tmp_path / "newproject" / cache.CACHE_MANIFEST_FILE).exists()


# ---------------------------------------------------------------------------
# TC-07: save writes valid JSON with string slide keys
# ---------------------------------------------------------------------------


def test_save_writes_valid_json(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(cache, "CACHE_BASE_DIR", tmp_path)
    manifest = cache.CacheManifest(version=1, options_hash="opt123", slides={1: "h1", 3: "h3"})
    cache.save_cache_manifest("proj", manifest)
    path = tmp_path / "proj" / cache.CACHE_MANIFEST_FILE
    data = json.loads(path.read_text(encoding="utf-8"))
    assert data["version"] == 1
    assert data["options_hash"] == "opt123"
    assert data["slides"] == {"1": "h1", "3": "h3"}


# ---------------------------------------------------------------------------
# TC-08: save does not leave a .tmp file after success
# ---------------------------------------------------------------------------


def test_save_no_tmp_file_after_success(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(cache, "CACHE_BASE_DIR", tmp_path)
    manifest = cache.CacheManifest(version=1, options_hash="o", slides={})
    cache.save_cache_manifest("proj", manifest)
    tmp_file = tmp_path / "proj" / (cache.CACHE_MANIFEST_FILE + ".tmp")
    assert not tmp_file.exists()


# ---------------------------------------------------------------------------
# TC-09: round-trip save then load returns identical data
# ---------------------------------------------------------------------------


def test_round_trip(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(cache, "CACHE_BASE_DIR", tmp_path)
    original = cache.CacheManifest(
        version=1,
        options_hash="deadbeef12345678",
        slides={1: "aaaaaaaaaaaaaaa1", 5: "bbbbbbbbbbbbbbb5"},
    )
    cache.save_cache_manifest("roundtrip", original)
    loaded = cache.load_cache_manifest("roundtrip")
    assert loaded is not None
    assert loaded.version == original.version
    assert loaded.options_hash == original.options_hash
    assert loaded.slides == original.slides


# ---------------------------------------------------------------------------
# TC-10: should_regenerate returns False when all hashes match
# ---------------------------------------------------------------------------


def test_should_regenerate_false_when_hashes_match() -> None:
    manifest = cache.CacheManifest(version=1, options_hash="opt1", slides={2: "ch1"})
    assert cache.should_regenerate(2, "ch1", manifest, "opt1") is False


# ---------------------------------------------------------------------------
# TC-11: should_regenerate returns True when content hash differs
# ---------------------------------------------------------------------------


def test_should_regenerate_true_content_hash_changed() -> None:
    manifest = cache.CacheManifest(version=1, options_hash="opt1", slides={2: "old_hash"})
    assert cache.should_regenerate(2, "new_hash", manifest, "opt1") is True


# ---------------------------------------------------------------------------
# TC-12: should_regenerate returns True when options hash differs
# ---------------------------------------------------------------------------


def test_should_regenerate_true_options_hash_changed() -> None:
    manifest = cache.CacheManifest(version=1, options_hash="old_opt", slides={2: "ch1"})
    assert cache.should_regenerate(2, "ch1", manifest, "new_opt") is True


# ---------------------------------------------------------------------------
# TC-13: should_regenerate returns True for slide not in manifest
# ---------------------------------------------------------------------------


def test_should_regenerate_true_slide_missing() -> None:
    manifest = cache.CacheManifest(version=1, options_hash="opt1", slides={1: "ch1"})
    assert cache.should_regenerate(99, "ch1", manifest, "opt1") is True


# ---------------------------------------------------------------------------
# TC-14: should_regenerate returns True when manifest is None
# ---------------------------------------------------------------------------


def test_should_regenerate_true_when_manifest_none() -> None:
    assert cache.should_regenerate(1, "ch1", None, "opt1") is True


# ---------------------------------------------------------------------------
# TC-15: should_regenerate returns True when slides dict is empty
# ---------------------------------------------------------------------------


def test_should_regenerate_true_empty_slides() -> None:
    manifest = cache.CacheManifest(version=1, options_hash="opt1", slides={})
    assert cache.should_regenerate(1, "ch1", manifest, "opt1") is True


# ---------------------------------------------------------------------------
# TC-16: round-trip with empty slides dict
# ---------------------------------------------------------------------------


def test_round_trip_empty_slides(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(cache, "CACHE_BASE_DIR", tmp_path)
    original = cache.CacheManifest(version=1, options_hash="opt", slides={})
    cache.save_cache_manifest("emptyproj", original)
    loaded = cache.load_cache_manifest("emptyproj")
    assert loaded is not None
    assert loaded.slides == {}


# ---------------------------------------------------------------------------
# TC-17: project name with spaces and hyphens
# ---------------------------------------------------------------------------


def test_project_name_with_special_chars(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(cache, "CACHE_BASE_DIR", tmp_path)
    manifest = cache.CacheManifest(version=1, options_hash="opt", slides={1: "h1"})
    project = "my project-v2"
    cache.save_cache_manifest(project, manifest)
    loaded = cache.load_cache_manifest(project)
    assert loaded is not None
    assert loaded.slides == {1: "h1"}


# ---------------------------------------------------------------------------
# TC-18: changed General/Global Rules causes all slides to need regeneration
# ---------------------------------------------------------------------------


def test_changed_general_causes_all_slides_regenerate() -> None:
    old_hash_s1 = cache.content_hash_for_slide("Old General", "Rules", "Slide 1 prompt")
    old_hash_s2 = cache.content_hash_for_slide("Old General", "Rules", "Slide 2 prompt")
    new_hash_s1 = cache.content_hash_for_slide("New General", "Rules", "Slide 1 prompt")
    new_hash_s2 = cache.content_hash_for_slide("New General", "Rules", "Slide 2 prompt")

    manifest = cache.CacheManifest(
        version=1,
        options_hash="opt1",
        slides={1: old_hash_s1, 2: old_hash_s2},
    )

    assert cache.should_regenerate(1, new_hash_s1, manifest, "opt1") is True
    assert cache.should_regenerate(2, new_hash_s2, manifest, "opt1") is True


# ---------------------------------------------------------------------------
# Additional: overwrite existing manifest preserves new data
# ---------------------------------------------------------------------------


def test_save_overwrites_existing_manifest(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(cache, "CACHE_BASE_DIR", tmp_path)
    first = cache.CacheManifest(version=1, options_hash="v1opt", slides={1: "first_hash"})
    cache.save_cache_manifest("proj", first)
    second = cache.CacheManifest(
        version=1, options_hash="v2opt", slides={1: "second_hash", 2: "new_hash"}
    )
    cache.save_cache_manifest("proj", second)
    loaded = cache.load_cache_manifest("proj")
    assert loaded is not None
    assert loaded.options_hash == "v2opt"
    assert loaded.slides == {1: "second_hash", 2: "new_hash"}


# ---------------------------------------------------------------------------
# Additional: CACHE_BASE_DIR constant is a Path instance
# ---------------------------------------------------------------------------


def test_cache_base_dir_is_path() -> None:
    assert isinstance(cache.CACHE_BASE_DIR, Path)


# ---------------------------------------------------------------------------
# Additional: constants have correct values
# ---------------------------------------------------------------------------


def test_constants() -> None:
    assert cache.CACHE_MANIFEST_FILE == "cache_manifest.json"
    assert cache.MANIFEST_VERSION == 1
