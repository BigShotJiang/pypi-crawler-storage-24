"""Unit tests for renderdeck_mcp.assembly.pptx_builder."""

from __future__ import annotations

import io
import random
from pathlib import Path
from unittest.mock import patch

import pytest
from PIL import Image
from pptx import Presentation
from pptx.util import Emu

from renderdeck_mcp.assembly.pptx_builder import (
    IMAGE_COMPRESS_THRESHOLD,
    DeckData,
    SlideData,
    build_pptx,
    compress_png,
)

# ---------------------------------------------------------------------------
# Helper factories
# ---------------------------------------------------------------------------


def _make_png(width: int = 100, height: int = 100) -> bytes:
    """Create a minimal valid PNG in memory."""
    img = Image.new("RGB", (width, height), color="blue")
    buf = io.BytesIO()
    img.save(buf, format="PNG")
    return buf.getvalue()


def _make_large_png() -> bytes:
    """Create PNG bytes that exceed IMAGE_COMPRESS_THRESHOLD (5 MB).

    Strategy: generate a real noisy PNG image at compress_level=0 so it is large.
    A 2000x2000 uncompressed RGB PNG is ~12 MB raw pixel data, which translates to
    a large PNG file at compress_level=0.
    """
    rng = random.Random(42)
    img = Image.new("RGB", (2000, 2000), color=(128, 64, 32))
    pixels = img.load()
    assert pixels is not None
    for x in range(0, 2000, 2):
        for y in range(0, 2000, 2):
            pixels[x, y] = (rng.randint(0, 255), rng.randint(0, 255), rng.randint(0, 255))
    buf = io.BytesIO()
    img.save(buf, format="PNG", compress_level=0)  # no compression -> large file
    return buf.getvalue()


def _make_deck(n_slides: int = 1, with_image: bool = True) -> DeckData:
    """Build a DeckData with n_slides slides."""
    image: bytes | None = _make_png() if with_image else None
    slides = [
        SlideData(
            slide_number=i + 1,
            title=f"Slide {i + 1}",
            speaker_notes=f"Notes for slide {i + 1}",
            image_bytes=image,
        )
        for i in range(n_slides)
    ]
    return DeckData(title="Test Deck", slides=slides)


# ---------------------------------------------------------------------------
# TC-01: build_pptx creates valid .pptx file
# ---------------------------------------------------------------------------


def test_build_pptx_creates_file(tmp_path: Path) -> None:
    """TC-01: build_pptx writes a file at the given output_path."""
    deck = _make_deck(n_slides=1)
    output = tmp_path / "out.pptx"
    result = build_pptx(deck, output)
    assert result == output
    assert output.exists()
    assert output.stat().st_size > 0


# ---------------------------------------------------------------------------
# TC-02: Correct number of slides created
# ---------------------------------------------------------------------------


def test_build_pptx_slide_count(tmp_path: Path) -> None:
    """TC-02: Deck with 3 slides produces .pptx with exactly 3 slides."""
    deck = _make_deck(n_slides=3)
    output = tmp_path / "out.pptx"
    build_pptx(deck, output)
    prs = Presentation(str(output))
    assert len(prs.slides) == 3


# ---------------------------------------------------------------------------
# TC-03: Speaker notes attached to each slide
# ---------------------------------------------------------------------------


def test_speaker_notes_attached(tmp_path: Path) -> None:
    """TC-03: Each slide has the correct speaker notes text."""
    n = 3
    deck = _make_deck(n_slides=n)
    output = tmp_path / "out.pptx"
    build_pptx(deck, output)
    prs = Presentation(str(output))
    for i, slide in enumerate(prs.slides):
        notes_text = slide.notes_slide.notes_text_frame.text
        assert f"Notes for slide {i + 1}" in notes_text


# ---------------------------------------------------------------------------
# TC-04: WIDE aspect ratio -> 16:9 dimensions
# ---------------------------------------------------------------------------


def test_wide_aspect_ratio(tmp_path: Path) -> None:
    """TC-04: WIDE aspect ratio sets 9144000 x 5143500 EMU dimensions."""
    deck = _make_deck()
    output = tmp_path / "wide.pptx"
    build_pptx(deck, output, aspect_ratio="WIDE")
    prs = Presentation(str(output))
    assert prs.slide_width == Emu(9144000)
    assert prs.slide_height == Emu(5143500)


# ---------------------------------------------------------------------------
# TC-05: STANDARD aspect ratio -> 4:3 dimensions
# ---------------------------------------------------------------------------


def test_standard_aspect_ratio(tmp_path: Path) -> None:
    """TC-05: STANDARD aspect ratio sets 9144000 x 6858000 EMU dimensions."""
    deck = _make_deck()
    output = tmp_path / "standard.pptx"
    build_pptx(deck, output, aspect_ratio="STANDARD")
    prs = Presentation(str(output))
    assert prs.slide_width == Emu(9144000)
    assert prs.slide_height == Emu(6858000)


# ---------------------------------------------------------------------------
# TC-06: Slide with image has picture shape at full-slide size
# ---------------------------------------------------------------------------


def test_slide_with_image_has_picture_shape(tmp_path: Path) -> None:
    """TC-06: Slide with image_bytes has a picture shape covering the full slide."""
    from pptx.enum.shapes import MSO_SHAPE_TYPE

    deck = _make_deck(n_slides=1, with_image=True)
    output = tmp_path / "out.pptx"
    build_pptx(deck, output)
    prs = Presentation(str(output))
    slide = prs.slides[0]
    pictures = [s for s in slide.shapes if s.shape_type == MSO_SHAPE_TYPE.PICTURE]
    assert len(pictures) >= 1
    pic = pictures[0]
    assert pic.width == prs.slide_width
    assert pic.height == prs.slide_height


# ---------------------------------------------------------------------------
# TC-07: Slide without image has no picture shape
# ---------------------------------------------------------------------------


def test_slide_without_image_has_no_picture(tmp_path: Path) -> None:
    """TC-07: Slide with image_bytes=None has no picture shape."""
    from pptx.enum.shapes import MSO_SHAPE_TYPE

    deck = _make_deck(n_slides=1, with_image=False)
    output = tmp_path / "out.pptx"
    build_pptx(deck, output)
    prs = Presentation(str(output))
    slide = prs.slides[0]
    pictures = [s for s in slide.shapes if s.shape_type == MSO_SHAPE_TYPE.PICTURE]
    assert len(pictures) == 0


# ---------------------------------------------------------------------------
# TC-08: Large PNG compressed before embedding
# ---------------------------------------------------------------------------


def test_large_png_compressed(tmp_path: Path) -> None:
    """TC-08: build_pptx calls compress_png when image_bytes exceeds threshold."""
    png = _make_png()  # small PNG -- we spy on compress_png to verify it is always called

    deck = DeckData(
        title="Compress Test",
        slides=[
            SlideData(
                slide_number=1,
                title="Slide 1",
                speaker_notes="Notes",
                image_bytes=png,
            )
        ],
    )
    output = tmp_path / "out.pptx"

    # Patch compress_png inside pptx_builder to track it was called
    with patch(
        "renderdeck_mcp.assembly.pptx_builder.compress_png",
        wraps=compress_png,
    ) as mock_compress:
        build_pptx(deck, output)
        mock_compress.assert_called_once_with(png)


# ---------------------------------------------------------------------------
# TC-09: Empty slides list -> .pptx with no slides
# ---------------------------------------------------------------------------


def test_empty_deck_produces_zero_slides(tmp_path: Path) -> None:
    """TC-09: DeckData with empty slides list produces valid .pptx with 0 slides."""
    deck = DeckData(title="Empty", slides=[])
    output = tmp_path / "empty.pptx"
    build_pptx(deck, output)
    prs = Presentation(str(output))
    assert len(prs.slides) == 0


# ---------------------------------------------------------------------------
# TC-10: Round-trip: can open .pptx with python-pptx and read slide count
# ---------------------------------------------------------------------------


def test_round_trip_open(tmp_path: Path) -> None:
    """TC-10: Generated .pptx is valid OOXML that python-pptx can reopen."""
    deck = _make_deck(n_slides=2)
    output = tmp_path / "roundtrip.pptx"
    build_pptx(deck, output)
    prs = Presentation(str(output))  # must not raise
    assert prs is not None
    assert len(prs.slides) == 2


# ---------------------------------------------------------------------------
# TC-11: Output path parent dir created if missing
# ---------------------------------------------------------------------------


def test_output_parent_dir_created(tmp_path: Path) -> None:
    """TC-11: build_pptx creates missing parent directories."""
    nested = tmp_path / "subdir" / "nested"
    output = nested / "out.pptx"
    assert not nested.exists()
    deck = _make_deck()
    build_pptx(deck, output)
    assert output.exists()


# ---------------------------------------------------------------------------
# TC-12: compress_png returns input unchanged if under threshold
# ---------------------------------------------------------------------------


def test_compress_png_identity_for_small_input() -> None:
    """TC-12: compress_png returns identical bytes when input is below threshold."""
    small = _make_png(10, 10)
    assert len(small) < IMAGE_COMPRESS_THRESHOLD
    result = compress_png(small)
    assert result == small


# ---------------------------------------------------------------------------
# TC-13: compress_png converts large PNG to JPEG
# ---------------------------------------------------------------------------


def test_compress_png_converts_large_to_jpeg() -> None:
    """TC-13: compress_png returns JPEG bytes (FF D8 FF) for oversized input."""
    large_png = _make_large_png()
    # Verify our test data is actually larger than the threshold
    if len(large_png) <= IMAGE_COMPRESS_THRESHOLD:
        pytest.skip(
            f"Generated PNG ({len(large_png)} bytes) did not exceed threshold "
            f"({IMAGE_COMPRESS_THRESHOLD} bytes); skipping TC-13"
        )
    result = compress_png(large_png)
    # JPEG magic bytes
    assert result[:3] == b"\xff\xd8\xff", f"Expected JPEG magic bytes, got {result[:3]!r}"
    assert len(result) < len(large_png), "Compressed output should be smaller than input"
