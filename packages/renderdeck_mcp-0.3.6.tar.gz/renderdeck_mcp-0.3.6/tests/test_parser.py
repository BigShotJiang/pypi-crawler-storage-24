"""Tests for src/renderdeck_mcp/parser/prompt_file.py

Behavior spec: renderdeck.py lines 200-308.
Design doc: docs/sdd/epic-parser-validation/prompt-file-parser/design.md
Test handoff: docs/sdd/epic-parser-validation/prompt-file-parser/test-handoff.md

All tests pass a string to parse_prompt_file() and assert on the returned
ParsedDeck. No file I/O, no mocking, no external dependencies.

Tests are written BEFORE the implementation (test-first). They will fail
until the implementer creates the parser in:
    src/renderdeck_mcp/parser/prompt_file.py
"""

from __future__ import annotations

from renderdeck_mcp.parser.prompt_file import ParsedDeck, ParsedSlide, parse_prompt_file

# ---------------------------------------------------------------------------
# Fixture strings
# All fixture content is defined here as module-level string constants.
# No fixture reads from disk.
# ---------------------------------------------------------------------------

# Fixture 1 — Minimum content that parses without errors or warnings.
# Line numbers (1-based) for assertions:
#   line 1: "# My Test Presentation"   → title_line_number = 1
#   line 8: "## Slide 01 — First Slide" → slides[0].line_number = 8
MINIMAL_VALID_DECK = """\
# My Test Presentation

## Global Rules
Keep it simple.

---

## Slide 01 — First Slide

A single slide with a prompt.

---

## Speaker Notes

### Slide 01 — First Slide
**Time:** ~30 seconds.
**Say:** Welcome everyone.\
"""

# Fixture 2 — Front matter with subtitle before General / Global Rules sections.
DECK_WITH_SUBTITLE = """\
# AI Strategy Deck

## Shaping the Future

## General
This deck covers AI transformation.

## Global Rules
Dark background. White text.

---

## Slide 01 — Introduction

Opening image prompt here.\
"""

# Fixture 3 — No ## Speaker Notes segment at all.
DECK_NO_SPEAKER_NOTES_SECTION = """\
# Deck Without Notes

## Global Rules
Standard rules.

---

## Slide 01 — Slide One

Image prompt for slide one.

---

## Slide 02 — Slide Two

Image prompt for slide two.\
"""

# Fixture 4 — One slide has no body text (only the H2 heading).
DECK_SLIDE_NO_BODY = """\
# Title-Only Slides

---

## Slide 01 — Slide With Body

Full image prompt here.

---

## Slide 02 — Slide Without Body\
"""

# Fixture 6 — One slide block whose H2 heading does not match the pattern.
DECK_MALFORMED_SLIDE_HEADING = """\
# Malformed Headings Test

---

## Slide 01 — Good Slide

Good prompt.

---

## Slide Three — Bad Number

This block has a non-numeric slide number.

---

## Slide 03 — Another Good Slide

Another prompt.\
"""

# Fixture 7 — Speaker notes reference slide 99 which has no corresponding slide.
DECK_ORPHAN_SPEAKER_NOTES = """\
# Orphan Notes Test

---

## Slide 01 — Only Slide

Prompt for slide one.

---

## Speaker Notes

### Slide 01 — Only Slide
**Say:** Notes for slide one.

### Slide 99 — Ghost Slide
**Say:** Notes for a slide that does not exist.\
"""

# Fixture 8 — No H1 heading present.
DECK_NO_H1 = """\
## Global Rules
Some rules.

---

## Slide 01 — A Slide

Prompt here.\
"""

# Fixture 10 — Slide with a multi-paragraph, multi-line body.
DECK_MULTILINE_PROMPT = """\
# Multi-paragraph Prompts

---

## Slide 01 — Complex Slide

First paragraph of the prompt with detailed instructions.

Second paragraph with more details.

- Bullet point one
- Bullet point two

Final sentence.\
"""

# Fixture 11 — Em-dash and ASCII hyphen both used as separators in headings.
DECK_BOTH_DASH_TYPES = """\
# Dash Variants Test

---

## Slide 01 — Em Dash Slide

Prompt one.

---

## Slide 02 - Hyphen Dash Slide

Prompt two.\
"""

# Fixture 12 — Speaker notes title text differs from slide title to confirm
# association is by number, not by title.
DECK_NOTES_BY_NUMBER = """\
# Notes By Number Test

---

## Slide 01 — Original Title

Prompt here.

---

## Speaker Notes

### Slide 01 — Completely Different Title Text
**Say:** These notes should match slide 01 regardless of title mismatch.\
"""

# Fixture 13 — Front matter with both ## General and ## Global Rules sections.
DECK_GENERAL_AND_GLOBAL_RULES = """\
# Full Front Matter Test

## General
This is the general context describing the deck's audience and purpose.

## Global Rules
Use dark backgrounds. Avoid clipart.
Always use the brand color #1A2B3C.

---

## Slide 01 — Test Slide

Prompt.\
"""

# Fixture 14 — 4-hyphen and 5-hyphen separators (regex -\{3,\} must accept them).
DECK_SEPARATOR_FOUR_PLUS_HYPHENS = """\
# Long Separator Test

----

## Slide 01 — Four Hyphens

Prompt one.

-----

## Slide 02 — Five Hyphens

Prompt two.\
"""

# ---------------------------------------------------------------------------
# Fixture generator: 31 slides (programmatic — inline string would be unwieldy)
# ---------------------------------------------------------------------------


def _make_31_slide_deck() -> str:
    """Build a valid deck string that contains exactly 31 slide blocks."""
    slides_text = "\n\n---\n\n".join(
        f"## Slide {i:02d} — Slide {i}\n\nPrompt for slide {i}." for i in range(1, 32)
    )
    return f"# Big Deck\n\n## Global Rules\nRules here.\n\n---\n\n{slides_text}"


def _make_30_slide_deck() -> str:
    """Build a valid deck string that contains exactly 30 slide blocks."""
    slides_text = "\n\n---\n\n".join(
        f"## Slide {i:02d} — Slide {i}\n\nPrompt for slide {i}." for i in range(1, 31)
    )
    return f"# Thirty Slide Deck\n\n## Global Rules\nRules here.\n\n---\n\n{slides_text}"


# ===========================================================================
# TestMinimalValidDeck
# Covers: AC-1 (all fields populated), AC-6 (speaker notes matched by number),
#         test-handoff Fixture 1, design.md §Data Model.
# ===========================================================================


class TestMinimalValidDeck:
    """Happy-path: minimal well-formed deck parses without errors or warnings."""

    def test_returns_parsed_deck_type(self) -> None:
        """Return type must be ParsedDeck (not a dict or None)."""
        result = parse_prompt_file(MINIMAL_VALID_DECK)
        assert isinstance(result, ParsedDeck)

    def test_title(self) -> None:
        """H1 text becomes deck.title."""
        result = parse_prompt_file(MINIMAL_VALID_DECK)
        assert result.title == "My Test Presentation"

    def test_subtitle_empty(self) -> None:
        """No non-reserved H2 in front matter → subtitle is empty string."""
        result = parse_prompt_file(MINIMAL_VALID_DECK)
        assert result.subtitle == ""

    def test_general_empty(self) -> None:
        """No ## General section present → general is empty string."""
        result = parse_prompt_file(MINIMAL_VALID_DECK)
        assert result.general == ""

    def test_global_rules_extracted(self) -> None:
        """## Global Rules body becomes deck.global_rules."""
        result = parse_prompt_file(MINIMAL_VALID_DECK)
        assert result.global_rules == "Keep it simple."

    def test_slide_count(self) -> None:
        """Exactly one slide block → one ParsedSlide in deck.slides."""
        result = parse_prompt_file(MINIMAL_VALID_DECK)
        assert len(result.slides) == 1

    def test_slide_is_parsed_slide_type(self) -> None:
        """Each element of deck.slides must be a ParsedSlide instance."""
        result = parse_prompt_file(MINIMAL_VALID_DECK)
        assert isinstance(result.slides[0], ParsedSlide)

    def test_slide_number(self) -> None:
        """Slide number is the raw two-character string from the H2 heading."""
        result = parse_prompt_file(MINIMAL_VALID_DECK)
        assert result.slides[0].number == "01"

    def test_slide_title(self) -> None:
        """Slide title is the text after the dash in the H2 heading, stripped."""
        result = parse_prompt_file(MINIMAL_VALID_DECK)
        assert result.slides[0].title == "First Slide"

    def test_slide_image_prompt(self) -> None:
        """Slide body text (excluding H2 heading) becomes image_prompt."""
        result = parse_prompt_file(MINIMAL_VALID_DECK)
        assert result.slides[0].image_prompt == "A single slide with a prompt."

    def test_slide_has_prompt_true(self) -> None:
        """has_prompt is True when image_prompt is non-empty."""
        result = parse_prompt_file(MINIMAL_VALID_DECK)
        assert result.slides[0].has_prompt is True

    def test_slide_speaker_notes(self) -> None:
        """Speaker notes body is assigned to the matching slide by number."""
        result = parse_prompt_file(MINIMAL_VALID_DECK)
        assert (
            result.slides[0].speaker_notes == "**Time:** ~30 seconds.\n**Say:** Welcome everyone."
        )

    def test_slide_has_notes_true(self) -> None:
        """has_notes is True when a matching speaker notes H3 is found."""
        result = parse_prompt_file(MINIMAL_VALID_DECK)
        assert result.slides[0].has_notes is True

    def test_no_warnings(self) -> None:
        """A fully valid deck produces an empty warnings list."""
        result = parse_prompt_file(MINIMAL_VALID_DECK)
        assert result.warnings == []

    def test_title_line_number_is_positive(self) -> None:
        """title_line_number must be >= 1 when H1 is present (first line = 1)."""
        result = parse_prompt_file(MINIMAL_VALID_DECK)
        assert result.title_line_number == 1

    def test_slide_line_number_is_positive(self) -> None:
        """line_number on ParsedSlide must be a positive integer."""
        result = parse_prompt_file(MINIMAL_VALID_DECK)
        assert result.slides[0].line_number >= 1

    def test_slide_line_number_value(self) -> None:
        """Slide 01 heading is on line 8 of MINIMAL_VALID_DECK (1-based)."""
        # Verify by counting: lines 1-6 are front matter + blank + Global Rules +
        # body + blank; line 7 is '---'; line 8 is '## Slide 01 — First Slide'.
        result = parse_prompt_file(MINIMAL_VALID_DECK)
        assert result.slides[0].line_number == 8


# ===========================================================================
# TestSubtitleExtraction
# Covers: design.md §Step 2 subtitle logic, renderdeck.py lines 239-245,
#         test-handoff Fixture 2, Fixture 13.
# ===========================================================================


class TestSubtitleExtraction:
    """Subtitle is extracted from the first non-reserved H2 in front matter."""

    def test_subtitle_present(self) -> None:
        """A non-reserved H2 before sections becomes deck.subtitle."""
        result = parse_prompt_file(DECK_WITH_SUBTITLE)
        assert result.subtitle == "Shaping the Future"

    def test_general_not_treated_as_subtitle(self) -> None:
        """'## General' heading is never treated as a subtitle (case-insensitive)."""
        result = parse_prompt_file(DECK_GENERAL_AND_GLOBAL_RULES)
        assert result.subtitle == ""

    def test_global_rules_not_treated_as_subtitle(self) -> None:
        """'## Global Rules' heading is never treated as a subtitle."""
        result = parse_prompt_file(MINIMAL_VALID_DECK)
        assert result.subtitle == ""

    def test_general_lowercase_excluded_as_subtitle(self) -> None:
        """Lowercase '## general' heading must also be excluded from subtitle."""
        content = "# Title\n\n## general\nContext text.\n\n---\n\n## Slide 01 — Slide\n\nPrompt."
        result = parse_prompt_file(content)
        assert result.subtitle == ""

    def test_global_rules_uppercase_excluded_as_subtitle(self) -> None:
        """All-uppercase '## GLOBAL RULES' must also be excluded from subtitle."""
        content = "# Title\n\n## GLOBAL RULES\nRules.\n\n---\n\n## Slide 01 — Slide\n\nPrompt."
        result = parse_prompt_file(content)
        assert result.subtitle == ""

    def test_subtitle_search_restricted_to_pre_section_text(self) -> None:
        """Subtitle candidate must come from text before the first '##' section."""
        # The subtitle "Shaping the Future" appears before "## General" in front matter.
        result = parse_prompt_file(DECK_WITH_SUBTITLE)
        assert result.subtitle == "Shaping the Future"
        # "General" and "Global Rules" sections exist but are not the subtitle.
        assert result.subtitle not in ("General", "Global Rules")


# ===========================================================================
# TestBlockExtraction
# Covers: AC-3 (General), AC-4 (Global Rules), renderdeck.py lines 226-237,
#         test-handoff Fixture 13.
# ===========================================================================


class TestBlockExtraction:
    """## General and ## Global Rules blocks are extracted correctly."""

    def test_general_extracted(self) -> None:
        """Text under ## General is captured in deck.general."""
        result = parse_prompt_file(DECK_WITH_SUBTITLE)
        assert result.general == "This deck covers AI transformation."

    def test_global_rules_extracted(self) -> None:
        """Text under ## Global Rules is captured in deck.global_rules."""
        result = parse_prompt_file(DECK_WITH_SUBTITLE)
        assert result.global_rules == "Dark background. White text."

    def test_both_sections_extracted_simultaneously(self) -> None:
        """When both General and Global Rules are present, both are extracted."""
        result = parse_prompt_file(DECK_GENERAL_AND_GLOBAL_RULES)
        assert (
            result.general
            == "This is the general context describing the deck's audience and purpose."
        )
        assert "Use dark backgrounds." in result.global_rules
        assert "Always use the brand color #1A2B3C." in result.global_rules

    def test_neither_section_yields_empty_strings(self) -> None:
        """When neither ## General nor ## Global Rules is present, both fields are ''."""
        content = "# Title\n\n---\n\n## Slide 01 — Slide\n\nPrompt."
        result = parse_prompt_file(content)
        assert result.general == ""
        assert result.global_rules == ""

    def test_general_not_included_in_global_rules(self) -> None:
        """General block text must not leak into global_rules field."""
        result = parse_prompt_file(DECK_GENERAL_AND_GLOBAL_RULES)
        assert "general context" not in result.global_rules

    def test_global_rules_not_included_in_general(self) -> None:
        """Global Rules block text must not leak into general field."""
        result = parse_prompt_file(DECK_GENERAL_AND_GLOBAL_RULES)
        assert "Use dark backgrounds" not in result.general

    def test_global_rules_extraction_case_insensitive(self) -> None:
        """'## GLOBAL RULES' (uppercase) must populate deck.global_rules."""
        content = (
            "# Title\n\n## GLOBAL RULES\nUppercase rules.\n\n---\n\n## Slide 01 — Slide\n\nPrompt."
        )
        result = parse_prompt_file(content)
        assert result.global_rules == "Uppercase rules."


# ===========================================================================
# TestSlideBlocks
# Covers: AC-1 (slides list), AC-5 (no body), renderdeck.py lines 256-274,
#         test-handoff Fixtures 4, 6, 10, 11.
# ===========================================================================


class TestSlideBlocks:
    """Slide block parsing: headings, bodies, has_prompt, dash variants."""

    def test_slide_body_extracted(self) -> None:
        """Full body text (excluding H2 heading) populates image_prompt."""
        result = parse_prompt_file(DECK_SLIDE_NO_BODY)
        assert result.slides[0].image_prompt == "Full image prompt here."

    def test_empty_body_yields_empty_image_prompt(self) -> None:
        """A slide block with only an H2 heading → image_prompt == ''."""
        result = parse_prompt_file(DECK_SLIDE_NO_BODY)
        assert result.slides[1].image_prompt == ""

    def test_empty_body_has_prompt_false(self) -> None:
        """has_prompt is False when image_prompt is empty."""
        result = parse_prompt_file(DECK_SLIDE_NO_BODY)
        assert result.slides[1].has_prompt is False

    def test_non_empty_body_has_prompt_true(self) -> None:
        """has_prompt is True when image_prompt is non-empty."""
        result = parse_prompt_file(DECK_SLIDE_NO_BODY)
        assert result.slides[0].has_prompt is True

    def test_empty_body_no_warning(self) -> None:
        """A slide with no body text does NOT generate a warning."""
        result = parse_prompt_file(DECK_SLIDE_NO_BODY)
        assert result.warnings == []

    def test_whitespace_only_body_treated_as_empty(self) -> None:
        """A body consisting only of whitespace is treated as empty (has_prompt=False)."""
        content = "# Title\n\n---\n\n## Slide 01 — Slide\n\n   \n\n"
        result = parse_prompt_file(content)
        assert result.slides[0].image_prompt == ""
        assert result.slides[0].has_prompt is False

    def test_multiline_body_preserved_verbatim(self) -> None:
        """Multi-paragraph body text is preserved in full, including all paragraphs."""
        result = parse_prompt_file(DECK_MULTILINE_PROMPT)
        prompt = result.slides[0].image_prompt
        assert "First paragraph" in prompt
        assert "Second paragraph" in prompt
        assert "Bullet point one" in prompt
        assert "Bullet point two" in prompt
        assert "Final sentence." in prompt

    def test_multiline_body_has_prompt_true(self) -> None:
        """has_prompt is True for a multi-paragraph body."""
        result = parse_prompt_file(DECK_MULTILINE_PROMPT)
        assert result.slides[0].has_prompt is True

    def test_em_dash_accepted_in_heading(self) -> None:
        """H2 heading using em-dash '—' is parsed correctly."""
        result = parse_prompt_file(DECK_BOTH_DASH_TYPES)
        assert result.slides[0].number == "01"
        assert result.slides[0].title == "Em Dash Slide"

    def test_hyphen_accepted_in_heading(self) -> None:
        """H2 heading using ASCII hyphen '-' is parsed correctly."""
        result = parse_prompt_file(DECK_BOTH_DASH_TYPES)
        assert result.slides[1].number == "02"
        assert result.slides[1].title == "Hyphen Dash Slide"

    def test_both_dash_types_yield_two_slides(self) -> None:
        """Both em-dash and hyphen slides are parsed (total: 2)."""
        result = parse_prompt_file(DECK_BOTH_DASH_TYPES)
        assert len(result.slides) == 2

    def test_malformed_heading_block_skipped(self) -> None:
        """A block whose H2 does not match the pattern is skipped; others parsed."""
        result = parse_prompt_file(DECK_MALFORMED_SLIDE_HEADING)
        assert len(result.slides) == 2
        assert result.slides[0].number == "01"
        assert result.slides[1].number == "03"

    def test_malformed_heading_produces_warning(self) -> None:
        """Skipping a malformed slide block appends a warning."""
        result = parse_prompt_file(DECK_MALFORMED_SLIDE_HEADING)
        assert len(result.warnings) == 1

    def test_malformed_heading_warning_mentions_pattern(self) -> None:
        """Warning for a malformed block references the expected format."""
        result = parse_prompt_file(DECK_MALFORMED_SLIDE_HEADING)
        assert "does not match" in result.warnings[0]

    def test_single_digit_slide_number_skipped(self) -> None:
        """'## Slide 3 — Title' (one digit) is skipped — regex requires exactly two."""
        content = (
            "# Title\n\n---\n\n## Slide 3 — One Digit\n\nPrompt.\n\n---\n\n"
            "## Slide 01 — Valid\n\nPrompt."
        )
        result = parse_prompt_file(content)
        # Only the two-digit slide should be parsed.
        numbers = [s.number for s in result.slides]
        assert "01" in numbers
        assert all(n != "3" for n in numbers)

    def test_single_digit_slide_number_warning(self) -> None:
        """Skipping a single-digit numbered block appends a warning."""
        content = "# Title\n\n---\n\n## Slide 3 — One Digit\n\nPrompt."
        result = parse_prompt_file(content)
        assert len(result.warnings) >= 1

    def test_three_digit_slide_number_skipped(self) -> None:
        """'## Slide 003 — Title' (three digits) is skipped — regex requires exactly two."""
        content = (
            "# Title\n\n---\n\n## Slide 003 — Three Digits\n\nPrompt.\n\n---\n\n"
            "## Slide 01 — Valid\n\nPrompt."
        )
        result = parse_prompt_file(content)
        numbers = [s.number for s in result.slides]
        assert "01" in numbers
        assert all(n != "003" for n in numbers)

    def test_three_digit_slide_number_warning(self) -> None:
        """Skipping a three-digit numbered block appends a warning."""
        content = "# Title\n\n---\n\n## Slide 003 — Three Digits\n\nPrompt."
        result = parse_prompt_file(content)
        assert len(result.warnings) >= 1

    def test_slide_number_is_string_not_int(self) -> None:
        """ParsedSlide.number is a raw string (e.g. '03'), not an integer."""
        result = parse_prompt_file(MINIMAL_VALID_DECK)
        assert isinstance(result.slides[0].number, str)

    def test_slides_ordered_as_in_file(self) -> None:
        """Slides are returned in the order they appear in the file."""
        result = parse_prompt_file(DECK_NO_SPEAKER_NOTES_SECTION)
        assert result.slides[0].number == "01"
        assert result.slides[1].number == "02"


# ===========================================================================
# TestSlideCount
# Covers: AC-boundary (31 slides), renderdeck.py lines 276-277,
#         test-handoff Fixture 5.
# ===========================================================================


class TestSlideCount:
    """Slide count warning triggered only when > 30 slides."""

    def test_31_slides_all_parsed(self) -> None:
        """All 31 slides are still present in deck.slides despite the warning."""
        content = _make_31_slide_deck()
        result = parse_prompt_file(content)
        assert len(result.slides) == 31

    def test_31_slides_warning_added(self) -> None:
        """Exactly one warning is appended for a 31-slide deck."""
        content = _make_31_slide_deck()
        result = parse_prompt_file(content)
        assert len(result.warnings) == 1

    def test_31_slides_warning_mentions_count(self) -> None:
        """The warning text contains the slide count '31'."""
        content = _make_31_slide_deck()
        result = parse_prompt_file(content)
        assert "31 slides found" in result.warnings[0]

    def test_30_slides_no_warning(self) -> None:
        """Exactly 30 slides does NOT trigger the performance warning."""
        content = _make_30_slide_deck()
        result = parse_prompt_file(content)
        assert result.warnings == []

    def test_30_slides_all_parsed(self) -> None:
        """All 30 slides are present in deck.slides."""
        content = _make_30_slide_deck()
        result = parse_prompt_file(content)
        assert len(result.slides) == 30


# ===========================================================================
# TestSpeakerNotes
# Covers: AC-5 (missing notes section), AC-6 (notes by number), AC-7,
#         renderdeck.py lines 280-300, test-handoff Fixtures 3, 7, 12.
# ===========================================================================


class TestSpeakerNotes:
    """Speaker notes: missing section, orphan notes, number-based matching."""

    def test_missing_notes_section_all_slides_empty_notes(self) -> None:
        """When ## Speaker Notes is absent, all slides have speaker_notes == ''."""
        result = parse_prompt_file(DECK_NO_SPEAKER_NOTES_SECTION)
        for slide in result.slides:
            assert slide.speaker_notes == ""

    def test_missing_notes_section_all_has_notes_false(self) -> None:
        """When ## Speaker Notes is absent, all slides have has_notes == False."""
        result = parse_prompt_file(DECK_NO_SPEAKER_NOTES_SECTION)
        for slide in result.slides:
            assert slide.has_notes is False

    def test_missing_notes_section_no_warning(self) -> None:
        """A missing ## Speaker Notes section does NOT produce any warning."""
        result = parse_prompt_file(DECK_NO_SPEAKER_NOTES_SECTION)
        assert result.warnings == []

    def test_notes_assigned_to_correct_slide_by_number(self) -> None:
        """Notes are matched to the slide with the same number string, not by title."""
        result = parse_prompt_file(DECK_NOTES_BY_NUMBER)
        # Slide is "## Slide 01 — Original Title" but notes H3 says a different title.
        assert result.slides[0].speaker_notes != ""
        assert result.slides[0].has_notes is True

    def test_notes_content_correct_when_title_differs(self) -> None:
        """Notes body is assigned even when the H3 title text differs from slide title."""
        result = parse_prompt_file(DECK_NOTES_BY_NUMBER)
        assert "These notes should match slide 01" in result.slides[0].speaker_notes

    def test_notes_number_mismatch_no_warning_when_matched(self) -> None:
        """No warning is produced when notes match by number (title difference is fine)."""
        result = parse_prompt_file(DECK_NOTES_BY_NUMBER)
        assert result.warnings == []

    def test_orphan_notes_produce_warning(self) -> None:
        """Speaker notes for a non-existent slide number produce exactly one warning."""
        result = parse_prompt_file(DECK_ORPHAN_SPEAKER_NOTES)
        assert len(result.warnings) == 1

    def test_orphan_notes_warning_mentions_slide_number(self) -> None:
        """The orphan-notes warning references the missing slide number."""
        result = parse_prompt_file(DECK_ORPHAN_SPEAKER_NOTES)
        warning = result.warnings[0].lower()
        assert "99" in warning

    def test_orphan_notes_warning_describes_problem(self) -> None:
        """The orphan-notes warning text indicates the mismatch."""
        result = parse_prompt_file(DECK_ORPHAN_SPEAKER_NOTES)
        warning = result.warnings[0].lower()
        assert (
            "no matching slide" in warning or "does not exist" in warning or "skipping" in warning
        )

    def test_orphan_notes_do_not_affect_existing_slide(self) -> None:
        """The valid slide is not affected by the orphan speaker notes entry."""
        result = parse_prompt_file(DECK_ORPHAN_SPEAKER_NOTES)
        assert len(result.slides) == 1
        assert result.slides[0].number == "01"
        assert result.slides[0].has_notes is True

    def test_has_notes_false_when_no_notes_for_slide(self) -> None:
        """has_notes is False for slides that have no matching H3 in Speaker Notes."""
        # Use the orphan notes fixture: slide 01 HAS notes, slide 99 doesn't exist.
        # Separately test a deck where the notes section exists but has no matching H3.
        content = (
            "# Title\n\n---\n\n## Slide 01 — Slide\n\nPrompt.\n\n---\n\n"
            "## Speaker Notes\n\n### Slide 02 — Other Slide\nNotes for slide 02."
        )
        result = parse_prompt_file(content)
        assert result.slides[0].has_notes is False
        assert result.slides[0].speaker_notes == ""

    def test_notes_section_with_no_h3_sub_sections(self) -> None:
        """Speaker Notes with no H3 sub-sections assigns no notes and no warning."""
        content = (
            "# Title\n\n---\n\n## Slide 01 — Slide\n\nPrompt.\n\n---\n\n"
            "## Speaker Notes\n\nSome introductory text without H3 sections."
        )
        result = parse_prompt_file(content)
        assert result.slides[0].speaker_notes == ""
        assert result.slides[0].has_notes is False
        assert result.warnings == []

    def test_em_dash_accepted_in_speaker_notes_h3(self) -> None:
        """### Slide NN — Title (em-dash) in Speaker Notes is parsed correctly."""
        content = (
            "# Title\n\n---\n\n## Slide 01 — Slide\n\nPrompt.\n\n---\n\n"
            "## Speaker Notes\n\n### Slide 01 — Slide\nNotes body here."
        )
        result = parse_prompt_file(content)
        assert result.slides[0].speaker_notes == "Notes body here."

    def test_hyphen_accepted_in_speaker_notes_h3(self) -> None:
        """### Slide NN - Title (ASCII hyphen) in Speaker Notes is parsed correctly."""
        content = (
            "# Title\n\n---\n\n## Slide 01 — Slide\n\nPrompt.\n\n---\n\n"
            "## Speaker Notes\n\n### Slide 01 - Slide\nNotes with hyphen."
        )
        result = parse_prompt_file(content)
        assert result.slides[0].speaker_notes == "Notes with hyphen."


# ===========================================================================
# TestPureFunctionContract
# Covers: design.md §Error Handling, AC-boundary (no raise, no sys.exit),
#         test-handoff Fixtures 8, 9.
# ===========================================================================


class TestPureFunctionContract:
    """parse_prompt_file never raises; all errors/warnings returned in ParsedDeck."""

    def test_empty_string_does_not_raise(self) -> None:
        """parse_prompt_file('') must return without raising any exception."""
        result = parse_prompt_file("")
        assert isinstance(result, ParsedDeck)

    def test_empty_string_title_is_empty(self) -> None:
        """Empty input → deck.title == ''."""
        result = parse_prompt_file("")
        assert result.title == ""

    def test_empty_string_slides_empty(self) -> None:
        """Empty input → deck.slides == []."""
        result = parse_prompt_file("")
        assert result.slides == []

    def test_empty_string_has_warning(self) -> None:
        """Empty input → at least one warning in deck.warnings."""
        result = parse_prompt_file("")
        assert len(result.warnings) >= 1

    def test_no_h1_does_not_raise(self) -> None:
        """Content without an H1 must return without raising."""
        result = parse_prompt_file(DECK_NO_H1)
        assert isinstance(result, ParsedDeck)

    def test_no_h1_title_empty_string(self) -> None:
        """Missing H1 → deck.title == ''."""
        result = parse_prompt_file(DECK_NO_H1)
        assert result.title == ""

    def test_no_h1_title_line_number_is_zero(self) -> None:
        """Missing H1 → deck.title_line_number == 0."""
        result = parse_prompt_file(DECK_NO_H1)
        assert result.title_line_number == 0

    def test_no_h1_warning_added(self) -> None:
        """Missing H1 → at least one warning in deck.warnings."""
        result = parse_prompt_file(DECK_NO_H1)
        assert len(result.warnings) >= 1

    def test_no_h1_warning_mentions_h1_or_title(self) -> None:
        """The no-H1 warning must reference 'H1' or 'title' (case-insensitive)."""
        result = parse_prompt_file(DECK_NO_H1)
        warning_text = " ".join(result.warnings).lower()
        assert "h1" in warning_text or "title" in warning_text

    def test_warnings_field_is_list(self) -> None:
        """deck.warnings must always be a list (even when empty)."""
        result = parse_prompt_file(MINIMAL_VALID_DECK)
        assert isinstance(result.warnings, list)

    def test_slides_field_is_list(self) -> None:
        """deck.slides must always be a list."""
        result = parse_prompt_file(MINIMAL_VALID_DECK)
        assert isinstance(result.slides, list)

    def test_content_only_h1_no_separators(self) -> None:
        """Content with only an H1 and no '---' separators → no slides, no crash."""
        result = parse_prompt_file("# My Deck\n\nSome front matter text with no separators.")
        assert isinstance(result, ParsedDeck)
        assert result.title == "My Deck"
        assert result.slides == []


# ===========================================================================
# TestBoundaryConditions
# Covers: design.md §Edge Cases, test-handoff §Boundary Conditions.
# ===========================================================================


class TestBoundaryConditions:
    """Separator variants, unicode, line numbers, and other boundary cases."""

    def test_four_hyphen_separator_recognized(self) -> None:
        """A '----' (four hyphens) line is recognized as a segment separator."""
        result = parse_prompt_file(DECK_SEPARATOR_FOUR_PLUS_HYPHENS)
        assert len(result.slides) == 2

    def test_five_hyphen_separator_recognized(self) -> None:
        """A '-----' (five hyphens) line is also recognized as a separator."""
        result = parse_prompt_file(DECK_SEPARATOR_FOUR_PLUS_HYPHENS)
        assert result.slides[1].number == "02"

    def test_separator_variants_slide_titles_correct(self) -> None:
        """Slide titles are extracted correctly regardless of separator length."""
        result = parse_prompt_file(DECK_SEPARATOR_FOUR_PLUS_HYPHENS)
        assert result.slides[0].title == "Four Hyphens"
        assert result.slides[1].title == "Five Hyphens"

    def test_unicode_body_preserved_verbatim(self) -> None:
        """Unicode characters in slide body are preserved exactly in image_prompt."""
        content = (
            "# Unicode Test\n\n---\n\n## Slide 01 — Unicode Slide\n\n"
            "日本語テキスト with 中文 and Ärger über Ü."
        )
        result = parse_prompt_file(content)
        assert result.slides[0].image_prompt == "日本語テキスト with 中文 and Ärger über Ü."

    def test_very_long_body_preserved(self) -> None:
        """A 1000+ character body is preserved verbatim (no truncation)."""
        long_prompt = "A" * 1200
        content = f"# Title\n\n---\n\n## Slide 01 — Long Slide\n\n{long_prompt}"
        result = parse_prompt_file(content)
        assert result.slides[0].image_prompt == long_prompt
        assert len(result.slides[0].image_prompt) == 1200

    def test_notes_title_mismatch_still_matched_by_number(self) -> None:
        """Notes H3 whose title differs from slide title still maps by slide number."""
        result = parse_prompt_file(DECK_NOTES_BY_NUMBER)
        assert result.slides[0].has_notes is True

    def test_empty_segments_between_separators_discarded(self) -> None:
        """Two consecutive '---' lines (empty segment between them) are handled gracefully."""
        content = "# Title\n\n---\n\n---\n\n## Slide 01 — Valid Slide\n\nPrompt here."
        result = parse_prompt_file(content)
        # The empty segment between the two '---' lines is discarded.
        # "Slide 01" may or may not be found depending on how the empty segment
        # interacts with slide block detection — but the function must not raise.
        assert isinstance(result, ParsedDeck)

    def test_multiple_slides_correct_prompt_association(self) -> None:
        """Each slide's image_prompt is its own body, not a neighbor's."""
        result = parse_prompt_file(DECK_NO_SPEAKER_NOTES_SECTION)
        assert result.slides[0].image_prompt == "Image prompt for slide one."
        assert result.slides[1].image_prompt == "Image prompt for slide two."

    def test_multiple_slides_correct_notes_association(self) -> None:
        """Each slide receives only its own speaker notes, not a neighbor's."""
        content = (
            "# Multi-notes Test\n\n---\n\n"
            "## Slide 01 — First\n\nPrompt one.\n\n---\n\n"
            "## Slide 02 — Second\n\nPrompt two.\n\n---\n\n"
            "## Speaker Notes\n\n"
            "### Slide 01 — First\nNotes for one.\n\n"
            "### Slide 02 — Second\nNotes for two."
        )
        result = parse_prompt_file(content)
        assert result.slides[0].speaker_notes == "Notes for one."
        assert result.slides[1].speaker_notes == "Notes for two."

    def test_title_stripped_of_whitespace(self) -> None:
        """H1 capture group is stripped of leading/trailing whitespace."""
        content = "#   Spaced Title   \n\n---\n\n## Slide 01 — Slide\n\nPrompt."
        result = parse_prompt_file(content)
        assert result.title == "Spaced Title"

    def test_slide_title_stripped_of_whitespace(self) -> None:
        """Slide title (capture group 2 of heading regex) is stripped."""
        content = "# Title\n\n---\n\n## Slide 01 —   Padded Title   \n\nPrompt."
        result = parse_prompt_file(content)
        assert result.slides[0].title == "Padded Title"

    def test_front_matter_only_no_slides(self) -> None:
        """A file with front matter but no slide blocks yields an empty slides list."""
        content = "# Title\n\n## General\nContext.\n\n## Global Rules\nRules."
        result = parse_prompt_file(content)
        assert result.slides == []
        assert result.warnings == []

    def test_speaker_notes_detected_by_starts_with(self) -> None:
        """Last segment starting with '## Speaker Notes' is treated as notes block."""
        # Confirm the last segment is excluded from slide_blocks when it starts with
        # '## Speaker Notes' (case-insensitive).
        content = (
            "# Title\n\n---\n\n## Slide 01 — Slide\n\nPrompt.\n\n---\n\n"
            "## speaker notes\n\n### Slide 01 — Slide\nNotes body."
        )
        result = parse_prompt_file(content)
        # Slide 01 should get its notes; the Speaker Notes segment is not a slide block.
        assert len(result.slides) == 1
        assert result.slides[0].speaker_notes == "Notes body."

    def test_no_import_of_google_api_libraries(self) -> None:
        """The parser module must not import google, googleapiclient, or dotenv."""
        import sys

        # Import and verify that the presence of the parser module does not drag in
        # Google API or dotenv packages. These modules should not appear in sys.modules
        # as a direct result of importing the parser.
        import renderdeck_mcp.parser.prompt_file  # noqa: F401

        forbidden_prefixes = (
            "googleapiclient",
            "google.auth",
            "google_auth",
            "dotenv",
            "python_dotenv",
        )
        for prefix in forbidden_prefixes:
            offenders = [k for k in sys.modules if k.startswith(prefix)]
            assert not offenders, (
                f"Parser module must not import '{prefix}'; found in sys.modules: {offenders}"
            )
