"""Tests for the project-scaffold task.

Verifies the structural integrity of the renderdeck_mcp package after the
implementer creates the scaffold. All tests are pure Python — no network
calls, no external credentials, and no subprocess invocations.

Run with:
    pytest tests/test_scaffold.py --cov=renderdeck_mcp --cov-report=term-missing
"""

import importlib
import re
import tomllib
from pathlib import Path

import pytest

# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture(scope="session")
def pyproject_data() -> dict:  # type: ignore[type-arg]
    """Parse pyproject.toml once for the entire test session."""
    repo_root = Path(__file__).parent.parent
    pyproject_path = repo_root / "pyproject.toml"
    with pyproject_path.open("rb") as f:
        return tomllib.load(f)


@pytest.fixture(scope="session")
def runtime_deps(pyproject_data: dict) -> list[str]:  # type: ignore[type-arg]
    """Return the runtime dependency list from pyproject.toml."""
    return pyproject_data["project"]["dependencies"]  # type: ignore[no-any-return]


@pytest.fixture(scope="session")
def dev_deps(pyproject_data: dict) -> list[str]:  # type: ignore[type-arg]
    """Return the dev dependency list from pyproject.toml."""
    return pyproject_data["project"]["optional-dependencies"]["dev"]  # type: ignore[no-any-return]


# ---------------------------------------------------------------------------
# 1. Package importability
# ---------------------------------------------------------------------------


@pytest.mark.parametrize(
    "module_name",
    [
        "renderdeck_mcp",
        "renderdeck_mcp.parser",
        "renderdeck_mcp.generation",
        "renderdeck_mcp.assembly",
        "renderdeck_mcp.tools",
        "renderdeck_mcp.resources",
    ],
)
def test_all_subpackages_importable(module_name: str) -> None:
    """All top-level subpackages must be importable without error.

    Covers acceptance criteria: subpackage structure (design.md §Data Model).
    """
    try:
        importlib.import_module(module_name)
    except ImportError as exc:
        pytest.fail(f"Failed to import '{module_name}': {exc}")


# ---------------------------------------------------------------------------
# 2. __version__ attribute
# ---------------------------------------------------------------------------


def test_version_attribute_exists() -> None:
    """renderdeck_mcp.__version__ must exist as a module-level attribute.

    Covers acceptance criteria: G-11, design.md §Key Constants.
    """
    import renderdeck_mcp

    assert hasattr(renderdeck_mcp, "__version__"), "renderdeck_mcp.__version__ is not defined"


def test_version_is_string() -> None:
    """renderdeck_mcp.__version__ must be a str, not None or some other type."""
    import renderdeck_mcp

    assert isinstance(renderdeck_mcp.__version__, str), (
        f"Expected __version__ to be str, got {type(renderdeck_mcp.__version__)!r}"
    )


def test_version_is_semver() -> None:
    """__version__ must match the MAJOR.MINOR.PATCH semver pattern.

    Covers acceptance criteria: test-handoff.md §1, boundary conditions.
    """
    import renderdeck_mcp

    semver_pattern = re.compile(r"^\d+\.\d+\.\d+$")
    assert semver_pattern.match(renderdeck_mcp.__version__), (
        f"__version__ '{renderdeck_mcp.__version__}' does not match "
        "expected semver pattern MAJOR.MINOR.PATCH"
    )


def test_version_is_expected_value() -> None:
    """__version__ must match the installed package version."""
    import renderdeck_mcp

    assert renderdeck_mcp.__version__ == "0.2.15", (
        f"Expected __version__ == '0.2.15', got '{renderdeck_mcp.__version__}'"
    )


# ---------------------------------------------------------------------------
# 3. Entry point stub: __main__.main()
# ---------------------------------------------------------------------------


def test_main_raises_not_implemented() -> None:
    """renderdeck_mcp.__main__.main() must be callable.

    After MCP server implementation, main() starts the server which exits
    cleanly (returns None) or raises SystemExit when stdin is closed.
    """
    from renderdeck_mcp import __main__

    try:
        __main__.main()
    except (SystemExit, Exception):
        pass  # Server may exit or raise when stdin is not readable


def test_main_function_exists() -> None:
    """renderdeck_mcp.__main__ must expose a callable named 'main'."""
    from renderdeck_mcp import __main__

    assert callable(getattr(__main__, "main", None)), "renderdeck_mcp.__main__.main is not callable"


# ---------------------------------------------------------------------------
# 4. pyproject.toml metadata
# ---------------------------------------------------------------------------


def test_pyproject_exists() -> None:
    """pyproject.toml must exist at the repository root."""
    repo_root = Path(__file__).parent.parent
    assert (repo_root / "pyproject.toml").is_file(), "pyproject.toml not found at repository root"


def test_pyproject_package_name(pyproject_data: dict) -> None:  # type: ignore[type-arg]
    """pyproject.toml [project].name must be 'renderdeck-mcp'.

    Covers acceptance criteria: design.md §pyproject.toml Sections.
    """
    assert pyproject_data["project"]["name"] == "renderdeck-mcp", (
        f"Expected package name 'renderdeck-mcp', got '{pyproject_data['project']['name']}'"
    )


def test_pyproject_python_version_constraint(pyproject_data: dict) -> None:  # type: ignore[type-arg]
    """pyproject.toml requires-python must be '>=3.12'.

    Covers acceptance criteria: design.md §pyproject.toml Sections, G-11.
    """
    requires_python = pyproject_data["project"]["requires-python"]
    assert requires_python.startswith(">=3.12"), (
        f"Expected requires-python to start with '>=3.12', got '{requires_python}'"
    )


def test_pyproject_console_script_entry_point(pyproject_data: dict) -> None:  # type: ignore[type-arg]
    """The 'renderdeck-mcp' console script must point to renderdeck_mcp.__main__:main.

    Covers acceptance criteria: design.md §pyproject.toml Sections.
    """
    scripts = pyproject_data["project"]["scripts"]
    assert "renderdeck-mcp" in scripts, "No 'renderdeck-mcp' entry in [project.scripts]"
    assert scripts["renderdeck-mcp"] == "renderdeck_mcp.__main__:main", (
        f"Expected 'renderdeck_mcp.__main__:main', got '{scripts['renderdeck-mcp']}'"
    )


def test_pyproject_version_field(pyproject_data: dict) -> None:  # type: ignore[type-arg]
    """pyproject.toml [project].version must match current version."""
    assert pyproject_data["project"]["version"] == "0.2.15", (
        f"Expected pyproject version '0.2.15', got '{pyproject_data['project']['version']}'"
    )


# ---------------------------------------------------------------------------
# 5. Runtime dependencies
# ---------------------------------------------------------------------------


@pytest.mark.parametrize(
    "expected_prefix",
    ["mcp", "google-genai", "python-pptx", "Pillow", "cryptography"],
)
def test_pyproject_runtime_dependencies(
    runtime_deps: list[str],
    expected_prefix: str,
) -> None:
    """All required runtime packages must be declared in [project.dependencies].

    Covers acceptance criteria: design.md §Runtime Dependencies, test-handoff.md §7.
    """
    # Normalise to lowercase for case-insensitive comparison (PEP 503)
    normalised = [d.lower() for d in runtime_deps]
    prefix_lower = expected_prefix.lower()
    matching = [
        dep
        for dep in normalised
        if dep.startswith(prefix_lower) or dep.startswith(prefix_lower.replace("-", "_"))
    ]
    assert matching, (
        f"Runtime dependency starting with '{expected_prefix}' not found in "
        f"[project.dependencies]: {runtime_deps}"
    )


# ---------------------------------------------------------------------------
# 6. google-generativeai (deprecated) must NOT be present
# ---------------------------------------------------------------------------


def test_pyproject_no_deprecated_google_package(
    runtime_deps: list[str],
    dev_deps: list[str],
) -> None:
    """google-generativeai (deprecated) must NOT appear in any dependency list.

    Covers acceptance criteria: design.md §Boundary Criteria, AGENTS.md forbidden patterns.
    The correct package is 'google-genai'.
    """
    all_deps = runtime_deps + dev_deps
    forbidden = [
        dep
        for dep in all_deps
        if dep.lower().startswith("google-generativeai")
        or dep.lower().startswith("google_generativeai")
    ]
    assert not forbidden, (
        f"Deprecated package 'google-generativeai' found in dependencies: {forbidden}. "
        "Use 'google-genai' instead (see AGENTS.md forbidden patterns)."
    )


# ---------------------------------------------------------------------------
# 7. Dev dependencies
# ---------------------------------------------------------------------------


@pytest.mark.parametrize(
    "expected_prefix",
    ["pytest", "pytest-cov", "pytest-asyncio", "ruff", "mypy"],
)
def test_pyproject_dev_dependencies(
    dev_deps: list[str],
    expected_prefix: str,
) -> None:
    """All required dev packages must be declared in [project.optional-dependencies.dev].

    Covers acceptance criteria: design.md §Dev Dependencies, test-handoff.md §9.
    """
    normalised = [d.lower() for d in dev_deps]
    prefix_lower = expected_prefix.lower()
    matching = [
        dep
        for dep in normalised
        if dep.startswith(prefix_lower) or dep.startswith(prefix_lower.replace("-", "_"))
    ]
    assert matching, (
        f"Dev dependency starting with '{expected_prefix}' not found in "
        f"[project.optional-dependencies.dev]: {dev_deps}"
    )


# ---------------------------------------------------------------------------
# 8. Version consistency: __init__.py vs pyproject.toml
# ---------------------------------------------------------------------------


def test_version_consistent_with_pyproject(pyproject_data: dict) -> None:  # type: ignore[type-arg]
    """Runtime __version__ must equal pyproject.toml [project].version.

    Covers acceptance criteria: design.md §Edge Cases (version drift prevention),
    test-handoff.md §10.
    """
    import renderdeck_mcp

    pyproject_version = pyproject_data["project"]["version"]
    assert renderdeck_mcp.__version__ == pyproject_version, (
        f"Version mismatch: renderdeck_mcp.__version__='{renderdeck_mcp.__version__}' "
        f"but pyproject.toml version='{pyproject_version}'. "
        "Both must be updated together."
    )


# ---------------------------------------------------------------------------
# 9. pyproject.toml required sections presence
# ---------------------------------------------------------------------------


def test_pyproject_has_build_system_section(pyproject_data: dict) -> None:  # type: ignore[type-arg]
    """pyproject.toml must define a [build-system] section with hatchling."""
    assert "build-system" in pyproject_data, "Missing [build-system] section"
    build_system = pyproject_data["build-system"]
    assert "hatchling" in build_system.get("requires", []), (
        "hatchling must be listed in [build-system].requires"
    )
    assert build_system.get("build-backend") == "hatchling.build", (
        f"Expected build-backend 'hatchling.build', got '{build_system.get('build-backend')}'"
    )


def test_pyproject_has_pytest_section(pyproject_data: dict) -> None:  # type: ignore[type-arg]
    """pyproject.toml must define [tool.pytest.ini_options] with testpaths."""
    pytest_opts = pyproject_data.get("tool", {}).get("pytest", {}).get("ini_options", {})
    assert pytest_opts, "Missing [tool.pytest.ini_options] section"
    assert "tests" in pytest_opts.get("testpaths", []), "testpaths must include 'tests'"
    assert pytest_opts.get("asyncio_mode") == "auto", (
        f"Expected asyncio_mode='auto', got '{pytest_opts.get('asyncio_mode')}'"
    )


def test_pyproject_has_mypy_section(pyproject_data: dict) -> None:  # type: ignore[type-arg]
    """pyproject.toml must define [tool.mypy] with strict=true and python_version=3.12."""
    mypy_opts = pyproject_data.get("tool", {}).get("mypy", {})
    assert mypy_opts, "Missing [tool.mypy] section"
    assert mypy_opts.get("strict") is True, "mypy strict mode must be enabled: strict = true"
    assert mypy_opts.get("python_version") == "3.12", (
        f"Expected mypy python_version='3.12', got '{mypy_opts.get('python_version')}'"
    )


def test_pyproject_has_ruff_section(pyproject_data: dict) -> None:  # type: ignore[type-arg]
    """pyproject.toml must define [tool.ruff] with line-length and target-version."""
    ruff_opts = pyproject_data.get("tool", {}).get("ruff", {})
    assert ruff_opts, "Missing [tool.ruff] section"
    assert ruff_opts.get("line-length") == 100, (
        f"Expected ruff line-length=100, got '{ruff_opts.get('line-length')}'"
    )
    assert ruff_opts.get("target-version") == "py312", (
        f"Expected ruff target-version='py312', got '{ruff_opts.get('target-version')}'"
    )


def test_pyproject_ruff_lint_selectors(pyproject_data: dict) -> None:  # type: ignore[type-arg]
    """[tool.ruff.lint] select must include E, F, I, UP rule sets."""
    ruff_lint = pyproject_data.get("tool", {}).get("ruff", {}).get("lint", {})
    assert ruff_lint, "Missing [tool.ruff.lint] section"
    selected = ruff_lint.get("select", [])
    for rule_code in ("E", "F", "I", "UP"):
        assert rule_code in selected, (
            f"ruff lint rule '{rule_code}' missing from [tool.ruff.lint].select: {selected}"
        )
