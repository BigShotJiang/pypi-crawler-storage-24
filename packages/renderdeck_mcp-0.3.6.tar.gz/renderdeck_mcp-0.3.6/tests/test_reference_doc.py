"""Tests for resources/renderdeck_reference.md (Task 3.1: compile-reference-doc).

Validates that the reference document is well-formed, self-contained, covers all
validator rules V-1 through V-6, and includes a valid annotated example.
"""

from __future__ import annotations

import re
from pathlib import Path

import pytest

from renderdeck_mcp.parser.validator import validate_prompt_file

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

REFERENCE_DOC_PATH = (
    Path(__file__).parent.parent
    / "src"
    / "renderdeck_mcp"
    / "resources"
    / "renderdeck_reference.md"
)
MAX_SIZE_BYTES = 30_720  # 30KB


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture(scope="module")
def reference_content() -> str:
    """Load the reference document once for all tests."""
    return REFERENCE_DOC_PATH.read_text(encoding="utf-8")


@pytest.fixture(scope="module")
def example_section(reference_content: str) -> str:
    """Extract the annotated example section from the reference doc."""
    match = re.search(r"^## \d+\.\s+.*[Ee]xample", reference_content, re.MULTILINE)
    if not match:
        pytest.fail("Could not find example section heading in reference doc")
    return reference_content[match.start() :]


@pytest.fixture(scope="module")
def example_prompt_file(example_section: str) -> str:
    """Extract the complete example prompt file from the example section.

    Looks for the largest fenced code block containing slide content.
    Strips HTML comment annotations.
    """
    blocks = re.findall(r"```(?:markdown)?\n(.*?)```", example_section, re.DOTALL)
    for block in blocks:
        if "# " in block and "## Slide" in block:
            cleaned = re.sub(r"<!--.*?-->", "", block, flags=re.DOTALL)
            return cleaned.strip()
    pytest.fail("Could not find a complete example prompt file in the example section")


# ---------------------------------------------------------------------------
# TC-01: File exists and is valid UTF-8
# ---------------------------------------------------------------------------


class TestFileBasics:
    """TC-01: File exists and is valid UTF-8."""

    def test_file_exists(self) -> None:
        assert REFERENCE_DOC_PATH.exists(), f"Reference doc not found at {REFERENCE_DOC_PATH}"

    def test_valid_utf8(self) -> None:
        content = REFERENCE_DOC_PATH.read_text(encoding="utf-8")
        assert len(content) > 0, "Reference doc is empty"


# ---------------------------------------------------------------------------
# TC-02: All required section headings present
# ---------------------------------------------------------------------------


class TestSectionHeadings:
    """TC-02: All five required section headings are present."""

    _REQUIRED_SECTIONS = [
        ("Format or Specification", r"^## .*(?:Format|Specification)", "format specification"),
        ("Brand or Guidelines", r"^## .*(?:Brand|Guideline)", "brand guidelines"),
        ("Structure", r"^## .*Structure", "structure instructions"),
        ("Craft", r"^## .*Craft", "presentation craft"),
        ("Example", r"^## .*Example", "annotated example"),
    ]

    @pytest.mark.parametrize(
        ("label", "pattern", "topic"),
        _REQUIRED_SECTIONS,
        ids=[s[2] for s in _REQUIRED_SECTIONS],
    )
    def test_section_present(
        self, reference_content: str, label: str, pattern: str, topic: str
    ) -> None:
        assert re.search(pattern, reference_content, re.MULTILINE | re.IGNORECASE), (
            f"Missing required section for {topic} (looked for {label})"
        )


# ---------------------------------------------------------------------------
# TC-03: Document size under 30KB
# ---------------------------------------------------------------------------


def test_document_size_under_30kb() -> None:
    """TC-03: File size must be under 30KB."""
    size = REFERENCE_DOC_PATH.stat().st_size
    assert size < MAX_SIZE_BYTES, (
        f"Reference doc is {size} bytes, exceeds {MAX_SIZE_BYTES} byte limit"
    )


# ---------------------------------------------------------------------------
# TC-04: No external URLs
# ---------------------------------------------------------------------------


def test_no_external_urls(reference_content: str) -> None:
    """TC-04: No http:// or https:// URLs in the document."""
    urls = re.findall(r"https?://", reference_content)
    assert urls == [], (
        f"Found {len(urls)} external URL(s) in reference doc — document must be self-contained"
    )


# ---------------------------------------------------------------------------
# TC-05: Format spec covers H1 title rule (V-1)
# ---------------------------------------------------------------------------


def test_covers_h1_title_rule(reference_content: str) -> None:
    """TC-05: Document mentions H1 heading requirement and exactly-one constraint."""
    lower = reference_content.lower()
    assert "h1" in lower, "Reference doc does not mention H1 headings"
    assert re.search(r"exactly one|single.*h1|one.*h1", lower), (
        "Reference doc does not mention the exactly-one-H1 requirement"
    )


# ---------------------------------------------------------------------------
# TC-06: Format spec covers slide heading format (V-2)
# ---------------------------------------------------------------------------


def test_covers_slide_heading_format(reference_content: str) -> None:
    """TC-06: Document describes slide heading format with zero-padded numbers."""
    assert re.search(r"## Slide\s+NN|## Slide\s+\d{2}", reference_content, re.IGNORECASE), (
        "Reference doc does not show the '## Slide NN' heading pattern"
    )
    lower = reference_content.lower()
    assert re.search(r"zero.?pad|two.?digit|two digits", lower), (
        "Reference doc does not mention zero-padded / two-digit requirement"
    )
    assert re.search(r"em[\s-]?dash|\u2014", reference_content), (
        "Reference doc does not mention em dash separator"
    )


# ---------------------------------------------------------------------------
# TC-07: Format spec covers Global Rules
# ---------------------------------------------------------------------------


def test_covers_global_rules(reference_content: str) -> None:
    """TC-07: Document describes Global Rules and their prepend behavior."""
    assert "Global Rules" in reference_content, "Reference doc does not mention '## Global Rules'"
    lower = reference_content.lower()
    assert re.search(r"prepend|prefix|added to.*prompt|applied to.*prompt", lower), (
        "Reference doc does not explain that Global Rules are prepended to prompts"
    )


# ---------------------------------------------------------------------------
# TC-08: Format spec covers General block
# ---------------------------------------------------------------------------


def test_covers_general_block(reference_content: str) -> None:
    """TC-08: Document describes the General section."""
    assert "## General" in reference_content, "Reference doc does not mention '## General' section"
    lower = reference_content.lower()
    assert re.search(r"audience|tone|context|purpose", lower), (
        "Reference doc does not describe the role of the General section"
    )


# ---------------------------------------------------------------------------
# TC-09: Format spec covers Speaker Notes with Say/Time labels
# ---------------------------------------------------------------------------


def test_covers_speaker_notes(reference_content: str) -> None:
    """TC-09: Document describes Speaker Notes structure and labels."""
    assert "## Speaker Notes" in reference_content, (
        "Reference doc does not mention '## Speaker Notes'"
    )
    assert re.search(r"###\s+Slide\s+\d{2}|###\s+Slide\s+NN", reference_content), (
        "Reference doc does not show '### Slide NN' sub-section pattern"
    )
    assert "**Say:**" in reference_content, "Reference doc does not mention the **Say:** label"
    assert re.search(r"\*\*Tim(?:e|ing):\*\*", reference_content), (
        "Reference doc does not mention the **Time:** or **Timing:** label"
    )


# ---------------------------------------------------------------------------
# TC-10: Format spec covers duplicate slide number rule (V-3)
# ---------------------------------------------------------------------------


def test_covers_duplicate_slide_numbers(reference_content: str) -> None:
    """TC-10: Document mentions that duplicate slide numbers are forbidden."""
    lower = reference_content.lower()
    assert re.search(r"duplicate.*slide|unique.*slide|no.*repeated.*slide", lower), (
        "Reference doc does not mention the duplicate slide number rule"
    )


# ---------------------------------------------------------------------------
# TC-11: Format spec covers slide count guidance (V-4)
# ---------------------------------------------------------------------------


def test_covers_slide_count_guidance(reference_content: str) -> None:
    """TC-11: Document mentions the 30-slide limit or guidance."""
    assert re.search(r"30\s*slide|30\s*or fewer|above\s*30", reference_content, re.IGNORECASE), (
        "Reference doc does not mention the 30-slide guidance"
    )


# ---------------------------------------------------------------------------
# TC-12: Example section contains at least 3 slide blocks
# ---------------------------------------------------------------------------


def test_example_has_at_least_3_slides(example_section: str) -> None:
    """TC-12: The annotated example contains at least 3 slide blocks."""
    slide_matches = re.findall(r"## Slide \d{2}", example_section)
    assert len(slide_matches) >= 3, (
        f"Example section has {len(slide_matches)} slide blocks, expected >= 3"
    )


# ---------------------------------------------------------------------------
# TC-13: Example excerpt passes validate_prompt_file with 0 errors
# ---------------------------------------------------------------------------


def test_example_passes_validation(example_prompt_file: str) -> None:
    """TC-13: Extracted example passes validate_prompt_file with zero errors."""
    result = validate_prompt_file(example_prompt_file)
    assert result.valid is True, (
        f"Example validation failed with errors: {[e.message for e in result.errors]}"
    )
    assert len(result.errors) == 0, (
        f"Example has {len(result.errors)} errors: {[e.message for e in result.errors]}"
    )
    assert result.slide_count >= 3, f"Example has {result.slide_count} slides, expected >= 3"


# ---------------------------------------------------------------------------
# TC-14: No orphan speaker notes in example
# ---------------------------------------------------------------------------


def test_no_orphan_speaker_notes_in_example(example_prompt_file: str) -> None:
    """TC-14: Example speaker notes all reference existing slides."""
    result = validate_prompt_file(example_prompt_file)
    orphan_warnings = [w for w in result.warnings if "no matching slide" in w]
    assert len(orphan_warnings) == 0, f"Example has orphan speaker notes: {orphan_warnings}"


# ---------------------------------------------------------------------------
# TC-15: Format spec covers separator rules
# ---------------------------------------------------------------------------


def test_covers_separator_rules(reference_content: str) -> None:
    """TC-15: Document describes --- separator rules."""
    assert "---" in reference_content, "Reference doc does not mention the --- separator"
    lower = reference_content.lower()
    assert re.search(r"three.*hyphen|three.*dash|---.*separat|separat.*---", lower), (
        "Reference doc does not explain the three-hyphen separator rule"
    )
    assert re.search(r"delimit|separat.*slide|between.*slide", lower), (
        "Reference doc does not explain that separators delimit slide blocks"
    )
