#!/usr/bin/env python3
"""
renderdeck.py — Markdown to Google Slides via Gemini + Google Slides API.
Parses structured presentation markdown, generates slide images with Gemini,
assembles a Google Slides presentation. Single file, config from .env.
"""

from __future__ import annotations

import base64
import hashlib
import json
import os
import re
import shutil
import sys
import time
from pathlib import Path

# Load .env before any other optional deps that might use env
SCRIPT_DIR = Path(__file__).resolve().parent
_env_path = SCRIPT_DIR / ".env"
if _env_path.exists():
    import dotenv
    dotenv.load_dotenv(_env_path)

# Optional / heavy imports after env is loaded
# (google-genai, google-api-python-client, google-auth-oauthlib, Pillow used in later phases)
import warnings
warnings.filterwarnings("ignore", message=".*google.generativeai.*", category=FutureWarning)


def _err(phase: str, message: str) -> None:
    sys.stderr.write(f"[ERROR] {phase}: {message}\n")
    sys.exit(1)


def _warn(message: str) -> None:
    sys.stderr.write(f"{message}\n")


def _verbose(message: str) -> None:
    if os.getenv("VERBOSE", "false").lower() in ("true", "1", "yes"):
        sys.stderr.write(f"{message}\n")


def _getenv(key: str, default: str | None = None) -> str:
    v = os.getenv(key, default)
    return v.strip() if isinstance(v, str) else (default or "")


def _speaker_notes_for_output(notes_text: str, say_only: bool) -> str:
    """Return notes as-is, or only the content after **Say:** when say_only is True."""
    if not say_only or not notes_text:
        return notes_text
    m = re.search(r"\*\*[Ss]ay:\*\*\s*", notes_text)
    if m:
        return notes_text[m.end() :].strip()
    return notes_text


def _parse_speaker_notes_markdown(md: str) -> tuple[str, list[tuple[int, int, str]]]:
    """Parse markdown in speaker notes into plain text and style runs.
    Returns (plain_text, [(start_index, end_index, 'bold'|'italic'), ...]).
    Handles **bold** and *italic*. Indices are in plain_text (for Google Slides API).
    """
    if not md:
        return "", []
    plain: list[str] = []
    runs: list[tuple[int, int, str]] = []
    i = 0
    while i < len(md):
        if i + 2 <= len(md) and md[i : i + 2] == "**":
            start = len(plain)
            i += 2
            while i < len(md) and (i + 2 > len(md) or md[i : i + 2] != "**"):
                plain.append(md[i])
                i += 1
            if i + 2 <= len(md):
                i += 2
            end = len(plain)
            if end > start:
                runs.append((start, end, "bold"))
            continue
        if md[i] == "*" and (i + 1 >= len(md) or md[i + 1] != "*"):
            start = len(plain)
            i += 1
            while i < len(md) and md[i] != "*":
                plain.append(md[i])
                i += 1
            if i < len(md):
                i += 1
            end = len(plain)
            if end > start:
                runs.append((start, end, "italic"))
            continue
        plain.append(md[i])
        i += 1
    return "".join(plain), runs


def _resolve_drive_folder_id(value: str) -> str:
    """Return a Drive folder ID from either a raw ID or a Drive folder URL."""
    value = (value or "").strip()
    if not value:
        return ""
    m = re.search(r"/folders/([a-zA-Z0-9_-]+)", value)
    if m:
        return m.group(1)
    m = re.search(r"[?&]id=([a-zA-Z0-9_-]+)", value)
    if m:
        return m.group(1)
    return value


# ---------- Phase 1: Startup ----------


def clear_deck_cache(config: dict) -> None:
    """Remove the deck cache directory and recreate it empty for a full restart."""
    cache_dir = config.get("deck_cache_dir") or config.get("image_temp_dir")
    if not cache_dir or not isinstance(cache_dir, Path):
        return
    if cache_dir.exists():
        shutil.rmtree(cache_dir)
        _verbose(f"Removed deck cache: {cache_dir}")
    cache_dir.mkdir(parents=True, exist_ok=True)


def validate_config(md_path: str) -> dict:
    """Validate CLI and config. Returns config dict for use in later phases. Exits on hard failure."""
    # CLI: exactly one argument
    if not md_path or not md_path.strip():
        _err("Startup", "Usage: python renderdeck.py <presentation.md>")
    path = Path(md_path).resolve()
    if not path.exists():
        _err("Startup", f"File not found: {path}")
    if path.suffix.lower() != ".md":
        _warn("[WARN] File is not a .md file; proceeding anyway.")

    # Required: credentials file must exist
    creds_file = _getenv("GOOGLE_SLIDES_CREDENTIALS_FILE")
    if not creds_file:
        _err("Startup", "GOOGLE_SLIDES_CREDENTIALS_FILE is not set.")
    creds_path = Path(creds_file).expanduser()
    if not creds_path.is_absolute():
        creds_path = (SCRIPT_DIR / creds_file).resolve()
    if not creds_path.exists() or not creds_path.is_file():
        _err("Startup", f"GOOGLE_SLIDES_CREDENTIALS_FILE not found or not readable: {creds_path}")

    token_file = _getenv("GOOGLE_SLIDES_TOKEN_FILE")
    if not token_file:
        _err("Startup", "GOOGLE_SLIDES_TOKEN_FILE is not set.")

    # Optional: Gemini API key — warn later if missing and slides have prompts
    gemini_key = _getenv("GOOGLE_GEMINI_API_KEY")
    model = _getenv("GEMINI_IMAGE_MODEL", "gemini-2.5-flash-image")
    if model not in ("gemini-2.5-flash-image", "gemini-3-pro-image-preview"):
        _warn(f"[WARN] GEMINI_IMAGE_MODEL '{model}' is not a known value; using as-is.")

    # IMAGE_TEMP_DIR: must be writable, create if absent
    temp_dir = _getenv("IMAGE_TEMP_DIR", "./.renderdeck_tmp")
    temp_path = Path(temp_dir).expanduser()
    if not temp_path.is_absolute():
        temp_path = (SCRIPT_DIR / temp_dir).resolve()
    try:
        temp_path.mkdir(parents=True, exist_ok=True)
        if not os.access(temp_path, os.W_OK):
            raise OSError("Not writable")
    except OSError as e:
        _err("Startup", f"IMAGE_TEMP_DIR is not writable: {temp_path} — {e}")

    # Per-deck cache: one subdir per markdown file so multiple decks don't share images
    deck_id = re.sub(r"[^\w\-]", "_", path.stem) or "deck"
    deck_cache_dir = temp_path / deck_id
    try:
        deck_cache_dir.mkdir(parents=True, exist_ok=True)
        if not os.access(deck_cache_dir, os.W_OK):
            raise OSError("Not writable")
    except OSError as e:
        _err("Startup", f"Deck cache dir is not writable: {deck_cache_dir} — {e}")

    return {
        "md_path": path,
        "creds_path": creds_path,
        "token_path": Path(token_file).expanduser() if Path(token_file).is_absolute() else SCRIPT_DIR / token_file,
        "gemini_key": gemini_key,
        "gemini_model": model,
        "image_temp_dir": temp_path,
        "deck_cache_dir": deck_cache_dir,
        "aspect_ratio": _getenv("SLIDES_ASPECT_RATIO", "WIDE").upper(),
        "gemini_max_retries": int(_getenv("GEMINI_MAX_RETRIES", "3")) or 3,
        "slides_max_retries": int(_getenv("SLIDES_MAX_RETRIES", "5")) or 5,
    }


# ---------- Phase 2: Parse ----------


def parse_markdown(md_path: Path) -> dict:
    """Parse markdown into {title, subtitle, general, global_rules, slides}. Exits on parse error."""
    try:
        content = md_path.read_text(encoding="utf-8")
    except UnicodeDecodeError as e:
        _err("Parse", f"File is not valid UTF-8: {e}")

    # Split on --- (three or more hyphens on a line by themselves)
    segments = re.split(r"(?m)^-{3,}\s*$", content)
    segments = [s.strip() for s in segments if s.strip()]

    if not segments:
        _err("Parse", "No content found.")

    # First segment: H1 title, H2 subtitle, ## Global Rules block
    first = segments[0]
    h1_match = re.search(r"^#\s+(.+)$", first, re.MULTILINE)
    if not h1_match:
        _err("Parse", "Markdown has no H1 title.")
    title = h1_match.group(1).strip()

    subtitle = ""
    general = ""
    global_rules = ""
    after_h1 = first[h1_match.end() :].lstrip()

    def _block_after_header(text: str, header_name: str) -> str:
        """Extract block content after ## Header Name until next ## or end."""
        pattern = rf"^##\s+{re.escape(header_name)}\s*$"
        m = re.search(pattern, text, re.MULTILINE | re.IGNORECASE)
        if not m:
            return ""
        rest = text[m.end() :]
        next_sec = re.search(r"\n##\s+", rest)
        return (rest[: next_sec.start()] if next_sec else rest).strip()

    general = _block_after_header(after_h1, "General")
    global_rules = _block_after_header(after_h1, "Global Rules")

    # Subtitle is the first H2 that is not "General" or "Global Rules"
    before_first_section = re.split(r"\n##\s+", after_h1, maxsplit=1)[0].strip()
    h2_subtitle_match = re.search(r"^##\s+(.+)$", before_first_section, re.MULTILINE)
    if h2_subtitle_match:
        sub_candidate = h2_subtitle_match.group(1).strip()
        if sub_candidate.lower() not in ("general", "global rules"):
            subtitle = sub_candidate

    # Slide block pattern: ## Slide NN — Title (NN = two digits, em dash)
    slide_heading_re = re.compile(r"^##\s+Slide\s+(\d{2})\s+[—\-]\s*(.*)$", re.MULTILINE)
    slides: list[dict] = []
    last_segment = segments[-1] if len(segments) > 1 else ""
    if last_segment.strip().lower().startswith("## speaker notes"):
        slide_blocks = segments[1:-1]
    else:
        slide_blocks = segments[1:]

    for block in slide_blocks:
        block = block.strip()
        if not block:
            continue
        m = slide_heading_re.match(block)
        if not m:
            _warn("[WARN] Slide heading does not match ## Slide NN — ...; skipping block.")
            continue
        slide_number = m.group(1)
        slide_title = m.group(2).strip()
        body = block[m.end() :].strip()
        slides.append({
            "slide_number": slide_number,
            "slide_title": slide_title,
            "image_prompt": body,
            "has_prompt": bool(body),
            "speaker_notes": "",
            "has_notes": False,
        })

    if len(slides) > 30:
        _warn(f"[WARN] {len(slides)} slides found — Google Slides API performance may degrade above 30 slides.")

    # Speaker Notes: last segment
    if segments and last_segment.strip().lower().startswith("## speaker notes"):
        notes_content = last_segment.split("\n", 1)[-1].strip() if "\n" in last_segment else ""
        # Split by ### Slide NN — ...
        h3_re = re.compile(r"^###\s+Slide\s+(\d{2})\s+[—\-].*$", re.MULTILINE)
        parts = h3_re.split(notes_content)
        if len(parts) >= 2:
            # parts[0] is before first H3, then [num, body, num, body, ...]
            for i in range(1, len(parts) - 1, 2):
                notes_slide_num = parts[i].strip()
                notes_body = parts[i + 1].strip()
                # notes_body runs until the next ### or end; strip trailing
                next_h3 = re.search(r"\n###\s+", notes_body)
                if next_h3:
                    notes_body = notes_body[: next_h3.start()].strip()
                matching = [s for s in slides if s["slide_number"] == notes_slide_num]
                if not matching:
                    _warn(f"[WARN] Speaker notes for slide {notes_slide_num} have no matching slide; skipping.")
                    continue
                for s in matching:
                    s["speaker_notes"] = notes_body
                    s["has_notes"] = True

    return {
        "title": title,
        "subtitle": subtitle,
        "general": general,
        "global_rules": global_rules,
        "slides": slides,
    }


# ---------- Phase 3: Auth ----------

SCOPES = [
    "https://www.googleapis.com/auth/presentations",
    "https://www.googleapis.com/auth/drive.file",
    "https://www.googleapis.com/auth/drive",
]


def get_google_clients(config: dict):
    """Return (slides_service, drive_service, credentials). Exits on auth failure."""
    from google.auth.transport.requests import Request
    from google.oauth2.credentials import Credentials
    from google_auth_oauthlib.flow import InstalledAppFlow
    from googleapiclient.discovery import build

    creds_path = config["creds_path"]
    token_path = config["token_path"]
    creds = None
    if token_path.exists():
        try:
            creds = Credentials.from_authorized_user_file(str(token_path), SCOPES)
        except Exception:
            pass
    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            try:
                creds.refresh(Request())
            except Exception:
                creds = None
        if not creds:
            try:
                flow = InstalledAppFlow.from_client_secrets_file(str(creds_path), SCOPES)
                creds = flow.run_local_server(port=0)
            except Exception as e:
                _err("Auth", f"OAuth authorization failed: {e}")
            try:
                token_path.parent.mkdir(parents=True, exist_ok=True)
                with open(token_path, "w") as f:
                    f.write(creds.to_json())
            except OSError as e:
                _err("Auth", f"Could not save token to {token_path}: {e}")
    slides_service = build("slides", "v1", credentials=creds)
    drive_service = build("drive", "v3", credentials=creds)
    return slides_service, drive_service, creds


# ---------- Phase 4: Images ----------

# cache_manifest.json in deck_cache_dir records which prompt/option version each slide image was built from.
# Schema: { "version": 1, "options_hash": "<16-char hex>", "slides": { "01": "<16-char hex>", ... } }
CACHE_MANIFEST_FILE = "cache_manifest.json"
MANIFEST_VERSION = 1
HASH_HEX_LEN = 16


def _normalize_for_hash(text: str) -> str:
    """Normalize text for stable hashing: strip, unify line endings to \\n, no trailing newline."""
    if not text:
        return ""
    s = (text or "").strip().replace("\r\n", "\n").replace("\r", "\n")
    return s.rstrip("\n")


def _content_hash_for_slide(general: str, global_rules: str, image_prompt: str) -> str:
    """Content hash for one slide: same order as full_prompt in generate_images (general, global_rules, slide prompt)."""
    g = _normalize_for_hash(general)
    r = _normalize_for_hash(global_rules)
    p = _normalize_for_hash(image_prompt)
    combined = f"{g}\n\n{r}\n\n{p}"
    return hashlib.sha256(combined.encode("utf-8")).hexdigest()[:HASH_HEX_LEN]


def _options_hash(config: dict) -> str:
    """Hash of options that affect image generation: aspect_ratio and gemini_model."""
    aspect = (config.get("aspect_ratio") or "WIDE").upper()
    model = config.get("gemini_model") or "gemini-2.5-flash-image"
    combined = f"{aspect}\n{model}"
    return hashlib.sha256(combined.encode("utf-8")).hexdigest()[:HASH_HEX_LEN]


def _load_cache_manifest(cache_dir: Path) -> dict | None:
    """Load cache manifest from deck cache dir. Returns None if missing or invalid."""
    if not cache_dir or not isinstance(cache_dir, Path):
        return None
    path = cache_dir / CACHE_MANIFEST_FILE
    if not path.exists() or not path.is_file():
        return None
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        if not isinstance(data, dict) or data.get("version") != MANIFEST_VERSION:
            return None
        return data
    except (OSError, json.JSONDecodeError):
        return None


def _save_cache_manifest(cache_dir: Path, manifest: dict) -> None:
    """Write cache manifest to deck cache dir. Ensures cache_dir exists."""
    if not cache_dir or not isinstance(cache_dir, Path):
        return
    cache_dir.mkdir(parents=True, exist_ok=True)
    path = cache_dir / CACHE_MANIFEST_FILE
    path.write_text(json.dumps(manifest, indent=2), encoding="utf-8")


def generate_images(parsed: dict, config: dict) -> int:
    """Generate slide images via Gemini; return count of images actually generated (for cost estimate)."""
    from google import genai
    from google.genai import types
    import io

    api_key = config.get("gemini_key") or ""
    if not api_key and any(s.get("has_prompt") for s in parsed["slides"]):
        _warn("[WARN] GOOGLE_GEMINI_API_KEY is not set; skipping image generation for all slides.")
        for s in parsed["slides"]:
            s["has_prompt"] = False
        return 0

    if not any(s.get("has_prompt") for s in parsed["slides"]):
        return 0

    client = genai.Client(api_key=api_key)
    model_id = config.get("gemini_model", "gemini-2.5-flash-image")
    cache_dir = config.get("deck_cache_dir") or config["image_temp_dir"]
    max_retries = config.get("gemini_max_retries", 3)
    backoff = [2, 4, 8]
    general = parsed.get("general", "") or ""
    global_rules = parsed.get("global_rules", "") or ""
    aspect = config.get("aspect_ratio", "WIDE")
    aspect_ratio = "16:9" if aspect == "WIDE" else "4:3"
    generated_count = 0

    options_hash = _options_hash(config)
    manifest = _load_cache_manifest(cache_dir)
    if manifest is None:
        manifest = {"version": MANIFEST_VERSION, "options_hash": "", "slides": {}}

    for slide in parsed["slides"]:
        if not slide.get("has_prompt"):
            continue
        nn = slide["slide_number"]
        slide_prompt = slide.get("image_prompt", "").strip()
        content_hash = _content_hash_for_slide(general, global_rules, slide_prompt)
        parts = []
        if general:
            parts.append("GENERAL (presentation context — apply to all slides):\n" + general)
        if global_rules:
            parts.append("GLOBAL VISUAL RULES (apply to all slides):\n" + global_rules)
        parts.append("SLIDE-SPECIFIC PROMPT:\n" + slide_prompt)
        full_prompt = "\n\n".join(parts)
        cache_path = cache_dir / f"slide_{nn}.png"
        force_regenerate = nn in config.get("regenerate_slides") or set()
        can_reuse = (
            not force_regenerate
            and manifest.get("options_hash") == options_hash
            and manifest.get("slides", {}).get(nn) == content_hash
            and cache_path.exists()
        )
        if can_reuse:
            _verbose(f"slide {nn}: reusing cached image")
            manifest.setdefault("slides", {})[nn] = content_hash
            continue
        if force_regenerate and cache_path.exists():
            _verbose(f"slide {nn}: regenerating (--regenerate-slide)")
        _verbose(f"slide {nn}: generating image (Nano Banana / Nano Banana Pro)...")
        last_error = None
        for attempt in range(max_retries + 1):
            try:
                response = client.models.generate_content(
                    model=model_id,
                    contents=full_prompt,
                    config=types.GenerateContentConfig(
                        response_modalities=["IMAGE"],
                        image_config=types.ImageConfig(aspect_ratio=aspect_ratio),
                    ),
                )
                # Support both response.parts and response.candidates[0].content.parts
                parts = response.parts if hasattr(response, "parts") and response.parts else []
                if not parts and getattr(response, "candidates", None):
                    c0 = response.candidates[0] if response.candidates else None
                    if c0 and getattr(c0, "content", None) and getattr(c0.content, "parts", None):
                        parts = c0.content.parts
                raw_bytes = None
                for part in (parts or []):
                    if not getattr(part, "inline_data", None):
                        continue
                    # Prefer raw data from inline_data (bytes or base64)
                    if hasattr(part.inline_data, "data") and part.inline_data.data:
                        d = part.inline_data.data
                        raw_bytes = base64.b64decode(d) if isinstance(d, str) else d
                        break
                    # Fallback: as_image() then save to bytes
                    try:
                        img = part.as_image()
                        buf = io.BytesIO()
                        if hasattr(img, "save"):
                            img.save(buf, format="PNG")
                            raw_bytes = buf.getvalue()
                        elif hasattr(img, "image_bytes"):
                            raw_bytes = img.image_bytes
                        if raw_bytes:
                            break
                    except Exception:
                        continue
                if not raw_bytes:
                    last_error = "Response has no image part"
                    continue
                if aspect == "WIDE":
                    raw_bytes = _resize_image_to_wide(raw_bytes)
                try:
                    cache_path.write_bytes(raw_bytes)
                except OSError as e:
                    _err("Images", f"Could not write image to {cache_path}: {e}")
                manifest.setdefault("slides", {})[nn] = content_hash
                manifest["options_hash"] = options_hash
                generated_count += 1
                break
            except Exception as e:
                err_str = str(e).lower()
                if "policy" in err_str or "blocked" in err_str or "400" in err_str:
                    _warn(f"slide {nn}: image blocked by content policy — text-only slide.")
                    slide["has_prompt"] = False
                    last_error = None
                    break
                last_error = e
                if attempt < max_retries:
                    delay = backoff[min(attempt, len(backoff) - 1)]
                    time.sleep(delay)
        if last_error is not None:
            _warn(f"slide {nn}: image generation failed after retries — text-only slide. ({last_error})")
            slide["has_prompt"] = False

    # Restrict manifest slides to current deck (drop removed slides)
    slide_numbers_with_prompt = {s["slide_number"] for s in parsed["slides"] if s.get("has_prompt")}
    manifest["slides"] = {
        nn: manifest["slides"][nn]
        for nn in slide_numbers_with_prompt
        if nn in manifest.get("slides", {})
    }
    manifest["options_hash"] = options_hash
    _save_cache_manifest(cache_dir, manifest)

    return generated_count


# ---------- Phase 5: Build ----------

# Cache file in deck_cache_dir storing the Google Slides presentation ID (one line).
PRESENTATION_ID_FILE = "presentation_id.txt"

# Page size in EMU (English Metric Units). Spec: WIDE = 16:9, STANDARD = 4:3.
PAGE_SIZE_EMU = {
    "WIDE": {"width": 9144000, "height": 5143500},
    "STANDARD": {"width": 9144000, "height": 6858000},
}
MAX_IMAGE_DATA_URI_BYTES = 2 * 1024 * 1024  # 2MB
# Slides API createImage URL must be publicly accessible and <= 2KB; data URIs exceed that.
# We upload images to Drive and use a short download URL for createImage.

# Target 16:9 dimensions for WIDE so the image fills the slide (Gemini may return 4:3 otherwise).
WIDE_IMAGE_WIDTH = 1920
WIDE_IMAGE_HEIGHT = 1080


def _resize_image_to_wide(png_bytes: bytes) -> bytes:
    """Resize/crop image to 16:9 so it fills the slide. Returns PNG bytes."""
    import io
    try:
        from PIL import Image
        img = Image.open(io.BytesIO(png_bytes)).convert("RGB")
        w, h = img.size
        target_r = WIDE_IMAGE_WIDTH / WIDE_IMAGE_HEIGHT
        current_r = w / h if h else 0
        if abs(current_r - target_r) < 0.01:
            out = io.BytesIO()
            img.save(out, "PNG")
            return out.getvalue()
        if current_r > target_r:
            new_w = int(h * target_r)
            left = (w - new_w) // 2
            img = img.crop((left, 0, left + new_w, h))
        else:
            new_h = int(w / target_r)
            top = (h - new_h) // 2
            img = img.crop((0, top, w, top + new_h))
        img = img.resize((WIDE_IMAGE_WIDTH, WIDE_IMAGE_HEIGHT), Image.Resampling.LANCZOS)
        out = io.BytesIO()
        img.save(out, "PNG")
        return out.getvalue()
    except Exception:
        return png_bytes


def _upload_image_to_drive(drive_service, png_bytes: bytes, slide_nn: str, parent_folder_id: str | None = None) -> str:
    """Upload PNG bytes to Drive, set anyone can view (when allowed), return a short URL for createImage.
    If parent_folder_id is set, the file is created in that folder.
    If the file is in a Shared Drive with domain-only sharing, we skip the public permission and still return the URL."""
    from googleapiclient.http import MediaIoBaseUpload
    from googleapiclient.errors import HttpError
    import io
    body = {"name": f"renderdeck_slide_{slide_nn}.png", "mimeType": "image/png"}
    if parent_folder_id:
        body["parents"] = [parent_folder_id]
    media = MediaIoBaseUpload(io.BytesIO(png_bytes), mimetype="image/png", resumable=False)
    create_kw: dict = {"body": body, "media_body": media, "fields": "id"}
    if parent_folder_id:
        create_kw["supportsAllDrives"] = True
    created = drive_service.files().create(**create_kw).execute()
    file_id = created.get("id")
    if not file_id:
        raise RuntimeError("Drive upload did not return id")
    try:
        drive_service.permissions().create(
            fileId=file_id,
            body={"type": "anyone", "role": "reader"},
            supportsAllDrives=bool(parent_folder_id),
        ).execute()
    except HttpError as e:
        if getattr(e, "resp", None) and e.resp.status == 400:
            err_str = str(e)
            if "teamDriveDomainUsersOnlyRestriction" in err_str or ("domain" in err_str and "restriction" in err_str):
                _verbose(f"slide {slide_nn}: skipping public link (Shared Drive / domain restriction); image URL may work for same domain")
            else:
                raise
        else:
            raise
    return f"https://drive.google.com/uc?export=download&id={file_id}"


def _compress_image_if_needed(cache_path: Path, nn: str) -> bytes:
    """Return PNG bytes; compress with Pillow if over 2MB and log warning."""
    raw = cache_path.read_bytes()
    if len(raw) <= MAX_IMAGE_DATA_URI_BYTES:
        return raw
    try:
        from PIL import Image
        import io
        img = Image.open(cache_path).convert("RGB")
        out = io.BytesIO()
        img.save(out, "PNG", optimize=True, quality=85)
        out.seek(0)
        compressed = out.read()
        if len(compressed) < len(raw):
            _warn(
                f"slide {nn}: image compressed from {len(raw) / (1024*1024):.2f}MB to "
                f"{len(compressed) / (1024*1024):.2f}MB for upload"
            )
            return compressed
    except Exception:
        pass
    return raw


def _load_cached_presentation_id(config: dict) -> str | None:
    """Return the cached Google Slides presentation ID for this deck, or None if not present."""
    cache_dir = config.get("deck_cache_dir") or config.get("image_temp_dir")
    if not cache_dir:
        return None
    path = cache_dir / PRESENTATION_ID_FILE
    if not path.exists() or not path.is_file():
        return None
    try:
        raw = path.read_text(encoding="utf-8").strip()
        return raw if raw else None
    except Exception:
        return None


def _save_presentation_id_to_cache(presentation_id: str, config: dict) -> None:
    """Write the presentation ID to the deck cache so future --regenerate-slide runs can update the same deck."""
    cache_dir = config.get("deck_cache_dir") or config.get("image_temp_dir")
    if not cache_dir:
        return
    path = cache_dir / PRESENTATION_ID_FILE
    try:
        path.write_text(presentation_id.strip(), encoding="utf-8")
        _verbose(f"Cached presentation ID to {path}")
    except OSError as e:
        _warn(f"Could not cache presentation ID to {path}: {e}")


def build_presentation(parsed: dict, config: dict, slides_service, drive_service) -> str:
    """Create presentation, populate slides; return presentationId. On failure, delete partial and exit."""
    title = parsed.get("title") or "Presentation"
    slides_list = parsed.get("slides") or []
    cache_dir = config.get("deck_cache_dir") or config["image_temp_dir"]
    aspect = config.get("aspect_ratio", "WIDE")
    if aspect not in PAGE_SIZE_EMU:
        aspect = "WIDE"
    size_emu = PAGE_SIZE_EMU[aspect]
    max_retries = config.get("slides_max_retries", 5)
    backoff = [1, 2, 4, 8, 16]

    try:
        create_body = {
            "title": title,
            "pageSize": {
                "width": {"magnitude": size_emu["width"], "unit": "EMU"},
                "height": {"magnitude": size_emu["height"], "unit": "EMU"},
            },
        }
        body = slides_service.presentations().create(body=create_body).execute()
    except Exception as e:
        _err("Build", f"presentations.create failed: {e}")
    presentation_id = body.get("presentationId")
    if not presentation_id:
        _err("Build", "presentations.create did not return presentationId")
    slides_in_resp = body.get("slides") or []
    default_slide_id = slides_in_resp[0].get("objectId") if slides_in_resp else None

    requests = []
    if default_slide_id:
        requests.append({"deleteObject": {"objectId": default_slide_id}})
    if requests:
        try:
            slides_service.presentations().batchUpdate(
                presentationId=presentation_id,
                body={"requests": requests},
            ).execute()
        except Exception as e:
            _err("Build", f"batchUpdate (delete default slide) failed: {e}")

    for idx, slide in enumerate(slides_list):
        nn = slide["slide_number"]
        slide_id = f"slide_{nn}"
        slide_requests = [
            {
                "createSlide": {
                    "objectId": slide_id,
                    "insertionIndex": idx,
                }
            },
        ]
        if slide.get("has_prompt"):
            cache_path = cache_dir / f"slide_{nn}.png"
            if cache_path.exists():
                png_bytes = _compress_image_if_needed(cache_path, nn)
                if aspect == "WIDE":
                    png_bytes = _resize_image_to_wide(png_bytes)
                try:
                    image_url = _upload_image_to_drive(
                        drive_service, png_bytes, nn,
                        parent_folder_id=config.get("drive_folder_id"),
                    )
                except Exception as e:
                    _warn(f"slide {nn}: Drive upload failed, skipping image — {e}")
                else:
                    slide_requests.append({
                        "createImage": {
                            "objectId": f"img_{nn}",
                            "url": image_url,
                            "elementProperties": {
                                "pageObjectId": slide_id,
                                "size": {
                                    "width": {"magnitude": size_emu["width"], "unit": "EMU"},
                                    "height": {"magnitude": size_emu["height"], "unit": "EMU"},
                                },
                                "transform": {
                                    "scaleX": 1,
                                    "scaleY": 1,
                                    "translateX": 0,
                                    "translateY": 0,
                                    "unit": "EMU",
                                },
                            },
                        }
                    })
        # No title text box: slide is fully generated by Nano Banana (image only).
        last_exc = None
        for attempt in range(max_retries + 1):
            try:
                slides_service.presentations().batchUpdate(
                    presentationId=presentation_id,
                    body={"requests": slide_requests},
                ).execute()
                _verbose(f"slide {nn}: populated (with image / text only)")
                break
            except Exception as e:
                last_exc = e
                code = getattr(getattr(e, "resp", None), "status", None) or getattr(e, "status_code", None)
                if code not in (429, 503) and attempt == 0:
                    break
                if attempt < max_retries:
                    time.sleep(backoff[min(attempt, len(backoff) - 1)])
        else:
            try:
                drive_service.files().delete(fileId=presentation_id).execute()
            except Exception:
                _warn(f"Could not delete partial presentation {presentation_id} — delete it manually.")
            _warn(
                f"Export failed on slide {nn}. Partial presentation deleted. "
                f"Temp images preserved in {cache_dir} for reuse on retry."
            )
            _err("Build", f"batchUpdate failed after retries: {last_exc}")
        notes_page_id = None
        if slide.get("has_notes") and slide.get("speaker_notes"):
            pres = slides_service.presentations().get(presentationId=presentation_id).execute()
            for s in (pres.get("slides") or []):
                if s.get("objectId") == slide_id:
                    notes_page_ref = (s.get("slideProperties") or {}).get("notesPage")
                    if notes_page_ref:
                        notes_page_id = notes_page_ref.get("objectId") if isinstance(notes_page_ref, dict) else notes_page_ref
                    break
            if notes_page_id:
                try:
                    notes_page = slides_service.presentations().pages().get(
                        presentationId=presentation_id,
                        pageObjectId=notes_page_id,
                    ).execute()
                    notes_props = notes_page.get("notesProperties") or {}
                    speaker_notes_shape_id = notes_props.get("speakerNotesObjectId")
                    if speaker_notes_shape_id:
                        raw_notes = _speaker_notes_for_output(
                            slide.get("speaker_notes") or "",
                            config.get("speaker_notes_say_only", False),
                        )
                        plain_text, style_runs = _parse_speaker_notes_markdown(raw_notes)
                        insert_and_style_requests = [
                            {
                                "insertText": {
                                    "objectId": speaker_notes_shape_id,
                                    "insertionIndex": 0,
                                    "text": plain_text,
                                }
                            },
                        ]
                        for start_idx, end_idx, style in style_runs:
                            if style == "bold":
                                insert_and_style_requests.append({
                                    "updateTextStyle": {
                                        "objectId": speaker_notes_shape_id,
                                        "textRange": {
                                            "type": "FIXED_RANGE",
                                            "startIndex": start_idx,
                                            "endIndex": end_idx,
                                        },
                                        "style": {"bold": True},
                                        "fields": "bold",
                                    }
                                })
                            elif style == "italic":
                                insert_and_style_requests.append({
                                    "updateTextStyle": {
                                        "objectId": speaker_notes_shape_id,
                                        "textRange": {
                                            "type": "FIXED_RANGE",
                                            "startIndex": start_idx,
                                            "endIndex": end_idx,
                                        },
                                        "style": {"italic": True},
                                        "fields": "italic",
                                    }
                                })
                        requests_list = [
                            {
                                "deleteText": {
                                    "objectId": speaker_notes_shape_id,
                                    "textRange": {"type": "ALL"},
                                }
                            },
                        ] + insert_and_style_requests
                        try:
                            slides_service.presentations().batchUpdate(
                                presentationId=presentation_id,
                                body={"requests": requests_list},
                            ).execute()
                        except Exception as del_err:
                            err_msg = str(del_err)
                            if "startIndex" in err_msg and "endIndex" in err_msg and "must be less than" in err_msg:
                                slides_service.presentations().batchUpdate(
                                    presentationId=presentation_id,
                                    body={"requests": insert_and_style_requests},
                                ).execute()
                            else:
                                raise
                    else:
                        _verbose(f"slide {nn}: no speakerNotesObjectId on notes page, skipping notes")
                except Exception as e:
                    _warn(f"slide {nn}: could not add speaker notes — {e}")
    # Move presentation to the specified Drive folder if requested
    drive_folder_id = config.get("drive_folder_id")
    if drive_folder_id:
        try:
            file_meta = drive_service.files().get(
                fileId=presentation_id,
                fields="parents",
                supportsAllDrives=True,
            ).execute()
            parents = file_meta.get("parents") or []
            if parents:
                drive_service.files().update(
                    fileId=presentation_id,
                    addParents=drive_folder_id,
                    removeParents=",".join(parents),
                    supportsAllDrives=True,
                ).execute()
            else:
                drive_service.files().update(
                    fileId=presentation_id,
                    addParents=drive_folder_id,
                    supportsAllDrives=True,
                ).execute()
            _verbose(f"Presentation moved to Drive folder {drive_folder_id}")
        except Exception as e:
            _warn(f"Could not move presentation to Drive folder — {e}")
    return presentation_id


def update_presentation_slides(
    presentation_id: str,
    parsed: dict,
    config: dict,
    slides_service,
    drive_service,
    slide_numbers: set[str],
) -> None:
    """Replace images on the given slides in an existing presentation. slide_numbers are e.g. {'01', '03'}."""
    cache_dir = config.get("deck_cache_dir") or config["image_temp_dir"]
    aspect = config.get("aspect_ratio", "WIDE")
    if aspect not in PAGE_SIZE_EMU:
        aspect = "WIDE"
    size_emu = PAGE_SIZE_EMU[aspect]
    max_retries = config.get("slides_max_retries", 5)
    backoff = [1, 2, 4, 8, 16]
    slides_list = parsed.get("slides") or []

    for nn in sorted(slide_numbers):
        slide = next((s for s in slides_list if s.get("slide_number") == nn), None)
        if not slide or not slide.get("has_prompt"):
            _warn(f"slide {nn}: skip update (no prompt or not in deck)")
            continue
        cache_path = cache_dir / f"slide_{nn}.png"
        if not cache_path.exists():
            _warn(f"slide {nn}: no cached image to update")
            continue
        png_bytes = _compress_image_if_needed(cache_path, nn)
        if aspect == "WIDE":
            png_bytes = _resize_image_to_wide(png_bytes)
        try:
            image_url = _upload_image_to_drive(
                drive_service, png_bytes, nn,
                parent_folder_id=config.get("drive_folder_id"),
            )
        except Exception as e:
            _warn(f"slide {nn}: Drive upload failed — {e}")
            continue
        slide_id = f"slide_{nn}"
        img_id = f"img_{nn}"
        requests = [
            {"deleteObject": {"objectId": img_id}},
            {
                "createImage": {
                    "objectId": img_id,
                    "url": image_url,
                    "elementProperties": {
                        "pageObjectId": slide_id,
                        "size": {
                            "width": {"magnitude": size_emu["width"], "unit": "EMU"},
                            "height": {"magnitude": size_emu["height"], "unit": "EMU"},
                        },
                        "transform": {
                            "scaleX": 1,
                            "scaleY": 1,
                            "translateX": 0,
                            "translateY": 0,
                            "unit": "EMU",
                        },
                    },
                }
            },
        ]
        last_exc = None
        for attempt in range(max_retries + 1):
            try:
                slides_service.presentations().batchUpdate(
                    presentationId=presentation_id,
                    body={"requests": requests},
                ).execute()
                _verbose(f"slide {nn}: image updated in existing presentation")
                break
            except Exception as e:
                last_exc = e
                code = getattr(getattr(e, "resp", None), "status", None) or getattr(e, "status_code", None)
                if code not in (429, 503) and attempt == 0:
                    break
                if attempt < max_retries:
                    time.sleep(backoff[min(attempt, len(backoff) - 1)])
        else:
            _err(
                "Update",
                f"Failed to update slide {nn} in presentation after retries: {last_exc}",
            )


# ---------- Phase 6: Output ----------


def print_result(
    presentation_id: str,
    images_generated: int,
    config: dict,
    parsed: dict | None = None,
) -> None:
    """Print URL to stdout; if VERBOSE, summary and cost to stderr."""
    url = f"https://docs.google.com/presentation/d/{presentation_id}/edit"
    # OSC 8 hyperlink: makes the URL clickable in supported terminals (iTerm2, VS Code, etc.)
    clickable = f"\033]8;;{url}\033\\{url}\033]8;;\033\\"
    print(clickable)
    if not (os.getenv("VERBOSE", "false").lower() in ("true", "1", "yes")):
        return
    slides_list = (parsed or {}).get("slides") or []
    n_slides = len(slides_list)
    n_images = sum(1 for s in slides_list if s.get("has_prompt"))
    _verbose(f"Presentation created: {n_slides} slides, {n_images} images. Estimated image cost: see below.")
    model = config.get("gemini_model", "gemini-2.5-flash-image")
    if "gemini-3-pro" in model:
        cost_per = 0.12
    else:
        cost_per = 0.039
    total = images_generated * cost_per
    sys.stderr.write(
        f"Estimated image generation cost: ${total:.2f} ({images_generated} images @ ${cost_per:.3f} each)\n"
    )
    sys.stderr.write(
        "Estimate only. Actual billing depends on output token count and Google pricing at time of call.\n"
    )


def main() -> None:
    import argparse
    parser = argparse.ArgumentParser(
        description="Build a Google Slides presentation from structured markdown (Gemini images + Slides API).",
        epilog="Output: presentation URL on stdout. Use VERBOSE=true or -v for progress and cost estimate on stderr.",
    )
    parser.add_argument(
        "presentation",
        metavar="presentation.md",
        help="Path to the presentation markdown file",
    )
    parser.add_argument(
        "-v", "--verbose",
        action="store_true",
        help="Print progress and cost estimate to stderr (overrides VERBOSE env)",
    )
    parser.add_argument(
        "--pro",
        action="store_true",
        help="Use Nano Banana Pro for image generation (gemini-3-pro-image-preview).",
    )
    parser.add_argument(
        "--say-only",
        action="store_true",
        dest="say_only",
        help="Use only the **Say:** part of each slide's speaker notes (for video generation, e.g. Pictory).",
    )
    group = parser.add_mutually_exclusive_group()
    group.add_argument(
        "--test",
        action="store_true",
        help="Test run: process at most 2 slides only",
    )
    group.add_argument(
        "--max-slides",
        type=int,
        metavar="N",
        default=None,
        help="Process at most N slides (for test runs)",
    )
    parser.add_argument(
        "--drive-folder",
        type=str,
        metavar="ID_OR_URL",
        default=None,
        help="Google Drive folder ID or folder URL where the presentation will be placed (default: Drive root)",
    )
    parser.add_argument(
        "-r", "--regenerate-slide",
        type=str,
        action="append",
        metavar="N[,N,...]",
        dest="regenerate_slides",
        default=None,
        help="Regenerate image for slide N even if cached (e.g. -r 3,4,9 or -r 03). Can be repeated.",
    )
    parser.add_argument(
        "--restart",
        action="store_true",
        help="Remove this deck's cache and generated files, then run a full generation from scratch.",
    )
    args = parser.parse_args()
    if args.verbose:
        os.environ["VERBOSE"] = "true"
    md_path_arg = args.presentation
    try:
        config = validate_config(md_path_arg)
        if getattr(args, "restart", False):
            clear_deck_cache(config)
        if args.pro:
            config["gemini_model"] = "gemini-3-pro-image-preview"
        config["speaker_notes_say_only"] = getattr(args, "say_only", False)
        folder_arg = getattr(args, "drive_folder", None)
        config["drive_folder_id"] = _resolve_drive_folder_id(folder_arg) if folder_arg else None
        # Normalize regenerate_slides to set of 2-digit strings e.g. {"01", "03", "09"}
        regen_raw = getattr(args, "regenerate_slides", None) or []
        config["regenerate_slides"] = set()
        for s in regen_raw:
            for part in (s or "").split(","):
                part = part.strip()
                if part.isdigit():
                    config["regenerate_slides"].add(part.zfill(2))
        if args.test:
            config["max_slides"] = 2
        elif args.max_slides is not None:
            config["max_slides"] = args.max_slides
        else:
            config["max_slides"] = None
        parsed = parse_markdown(config["md_path"])
        slides_list = parsed.get("slides") or []
        max_slides = config.get("max_slides")
        regenerate_slides = config.get("regenerate_slides") or set()
        if max_slides is not None and not (config.get("regenerate_slides") or set()):
            if len(slides_list) > max_slides:
                parsed["slides"] = slides_list[:max_slides]
                _verbose(f"Test run: limiting to {max_slides} slide(s)")
        slides_list = parsed.get("slides") or []
        _verbose(
            f"Parsed {len(slides_list)} slides, {sum(1 for s in slides_list if s.get('has_prompt'))} with image prompts, "
            f"{sum(1 for s in slides_list if s.get('has_notes'))} with speaker notes"
        )
        slides_service, drive_service, _creds = get_google_clients(config)
        regenerate_slides = config.get("regenerate_slides") or set()
        cached_presentation_id = _load_cached_presentation_id(config)

        if regenerate_slides and not cached_presentation_id:
            _warn(
                "[WARN] No cached presentation found; will create a new deck and use cached slide images "
                "except for the slide(s) being regenerated."
            )

        if regenerate_slides:
            images_generated = generate_images(parsed, config)
            if cached_presentation_id:
                update_presentation_slides(
                    cached_presentation_id,
                    parsed,
                    config,
                    slides_service,
                    drive_service,
                    regenerate_slides,
                )
                presentation_id = cached_presentation_id
            else:
                presentation_id = build_presentation(parsed, config, slides_service, drive_service)
                _save_presentation_id_to_cache(presentation_id, config)
        else:
            images_generated = generate_images(parsed, config)
            presentation_id = build_presentation(parsed, config, slides_service, drive_service)
            _save_presentation_id_to_cache(presentation_id, config)

        print_result(presentation_id, images_generated, config, parsed)
        sys.exit(0)
    except KeyboardInterrupt:
        sys.stderr.write("\nInterrupted. Exiting gracefully.\n")
        sys.exit(130)


if __name__ == "__main__":
    main()
