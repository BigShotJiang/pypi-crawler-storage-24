# AGENTS.md
<!-- This file orients AI agents working in this repository. Keep it under 200 lines. -->

## Project Overview

RenderDeck is a Python CLI tool that converts structured Markdown presentation files into Google Slides decks via Gemini image generation.
It is being wrapped as an MCP server to enable external LLMs to submit slide prompt files and receive `.pptx` presentations.
See `docs/renderdeck_mcp_server_prd.md` for the MCP server requirements.

## Architecture

- **renderdeck.py** — Single-file CLI script: parse markdown → generate images (Gemini) → assemble Google Slides → print URL
- **Gemini API** — Image generation via google-genai (Nano Banana / Nano Banana Pro models)
- **Google Slides API** — Presentation assembly via google-api-python-client + OAuth 2.0
- **Cache system** — Per-deck image cache with content+options hashing in `.slide_cache/`

Data flow: Markdown file → parse → Gemini image gen (cached) → Google Slides assembly → presentation URL

Deployment: Local CLI execution (`python renderdeck.py <deck.md>`)

## Key Directories

| Directory | Contains |
|-----------|----------|
| `.` (root) | `renderdeck.py` (main script), `requirements.txt`, config files |
| `docs/` | Spec (`RenderDeck_Script_Spec_v1.0.md`), PRD, format docs |
| `decks/` | Example presentation markdown files (gitignored) |
| `.slide_cache/` | Per-deck cached slide images (gitignored) |
| `.secrets/` | OAuth credentials and tokens (gitignored) |
| `.claude/` | SDD framework files (DO NOT MODIFY) |

## Build, Test, Run

| Action | Command |
|--------|---------|
| Install deps | `pip install -r requirements.txt` |
| Test (all) | `pytest` |
| Test (single) | `pytest {file}` |
| Lint | `ruff check .` |
| Lint (single) | `ruff check {file}` |
| Format | `ruff format .` |
| Type check | `mypy .` |
| Run | `python renderdeck.py <presentation.md>` |
| Run (verbose) | `python renderdeck.py -v <presentation.md>` |
| Run (test, 2 slides) | `python renderdeck.py --test <presentation.md>` |

## Tech Stack

- **Language:** Python 3.12+
- **Build tool:** pip + requirements.txt
- **Test framework:** pytest (to be configured)
- **Lint/Format:** ruff
- **Type checking:** mypy
- **Image gen:** google-genai (Gemini API)
- **Slides API:** google-api-python-client
- **Auth:** google-auth-oauthlib (OAuth 2.0)
- **Image processing:** Pillow

## Coding Conventions

- Single-file architecture for CLI (`renderdeck.py`) — MCP server will be a separate module
- All errors to stderr as `[ERROR] <phase>: <message>`, exit code 1
- Verbose output to stderr, only final result to stdout
- Environment config from `.env` via python-dotenv
- Content-aware caching: hash slide prompt + General + Global Rules + options

## Forbidden Patterns

- NEVER commit `.env`, `.secrets/`, `credentials.json`, or `token.json`
- NEVER modify files listed in `sdd-config.yaml → protected_files`
- NEVER hardcode API keys or OAuth tokens in source code
- NEVER use the deprecated `google-generativeai` package (use `google-genai`)

## Agent-Specific Guidance

- When modifying `renderdeck.py`, match the existing style (functions prefixed with `_` for internal helpers)
- Read `docs/RenderDeck_Script_Spec_v1.0.md` for the full behavior contract
- Read `docs/renderdeck_mcp_server_prd.md` for MCP server requirements
- Read `docs/best-practices.md` before making any design decisions
- All SDD pipeline artifacts go under `docs/sdd/{epic}/{task}/`
- If a task is ambiguous, flag it as an escalate-level gap — do not guess

## External Dependencies and APIs

- **Google Gemini API** — Image generation; auth via API key (`GOOGLE_GEMINI_API_KEY`); ~$0.039/image (flash) or ~$0.12/image (pro)
- **Google Slides API** — Presentation CRUD; auth via OAuth 2.0; scopes: `presentations`, `drive.file`
- **Google Drive API** — Optional folder placement; shared OAuth token

## Known Gotchas

- First run requires interactive OAuth browser flow; subsequent runs reuse token
- `.slide_cache/` uses content hashing — changing General/Global Rules regenerates all slides
- The script deletes partial presentations on failure (atomic: complete deck or nothing)
- `__pycache__/` is gitignored but may exist locally
- Decks directory is gitignored — example decks won't be in the repo
