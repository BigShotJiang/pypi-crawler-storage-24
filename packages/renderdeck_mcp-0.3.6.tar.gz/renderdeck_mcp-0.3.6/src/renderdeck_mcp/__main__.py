"""Entry point for `python -m renderdeck_mcp` and the `renderdeck-mcp` console script.

Usage:
    python -m renderdeck_mcp serve
    renderdeck-mcp serve

The `serve` subcommand starts the MCP server on stdio using FastMCP.
The server import is deferred to inside main() to avoid loading google libs at startup.
"""

from __future__ import annotations

import sys


def main() -> None:
    """Entry point for `python -m renderdeck_mcp` and `uvx renderdeck-mcp serve`."""
    if len(sys.argv) >= 2 and sys.argv[1] not in ("serve",):
        print("Usage: renderdeck-mcp [serve]", file=sys.stderr)
        sys.exit(1)
    from renderdeck_mcp.server import run

    run()


if __name__ == "__main__":
    main()
