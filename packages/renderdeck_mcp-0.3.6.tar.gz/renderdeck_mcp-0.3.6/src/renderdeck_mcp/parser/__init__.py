"""parser subpackage — slide prompt file parsing and format validation.

Public API:
    ParsedDeck        — structured result of parsing a prompt file
    ParsedSlide       — structured representation of a single slide block
    parse_prompt_file — pure-function parser entry point
    validate_prompt_file — format validation with line-number error reporting
    ValidationResult  — structured validation result
    ValidationError   — single validation error with line number
    SlideInfo         — slide number + title pair from validation
"""

from __future__ import annotations

from renderdeck_mcp.parser.prompt_file import ParsedDeck, ParsedSlide, parse_prompt_file
from renderdeck_mcp.parser.validator import (
    SlideInfo,
    ValidationError,
    ValidationResult,
    validate_prompt_file,
)

__all__ = [
    "ParsedDeck",
    "ParsedSlide",
    "SlideInfo",
    "ValidationError",
    "ValidationResult",
    "parse_prompt_file",
    "validate_prompt_file",
]
