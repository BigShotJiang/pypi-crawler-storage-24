"""Format validator for slide prompt files.

Validates prompt file structure and reports all errors with line numbers.
Implemented by the format-validator task in epic-parser-validation.

Public API: validate_prompt_file, ValidationResult, ValidationError, SlideInfo.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field

# ---------------------------------------------------------------------------
# Compiled regex constants (module-private)
# ---------------------------------------------------------------------------

_RE_H1 = re.compile(r"^#\s+(.+)$", re.MULTILINE)
_RE_SLIDE_CANDIDATE = re.compile(r"^##\s+Slide\s+", re.MULTILINE)
_RE_SLIDE_VALID = re.compile(r"^##\s+Slide\s+(\d{2})\s+[—\-]\s*(.+)$", re.MULTILINE)
_RE_SLIDE_ANY_NUMBER = re.compile(r"^##\s+Slide\s+(\d+)\s+[—\-]", re.MULTILINE)
_RE_NOTES_H3 = re.compile(r"^###\s+Slide\s+(\d+)", re.MULTILINE)

# ---------------------------------------------------------------------------
# Data model
# ---------------------------------------------------------------------------


@dataclass
class ValidationError:
    """A single validation error with a 1-based line number and optional slide number."""

    line_number: int
    message: str
    slide_number: int | None = None


@dataclass
class SlideInfo:
    """Metadata for a well-formed slide heading."""

    number: int
    title: str
    line_number: int


@dataclass
class ValidationResult:
    """Aggregated result of validating a prompt file."""

    valid: bool
    slide_count: int
    slides: list[SlideInfo] = field(default_factory=list)
    errors: list[ValidationError] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


@dataclass
class _ScanResult:
    """Raw data collected by the line-index scan (pass 1)."""

    h1_lines: list[tuple[int, str]]
    # (line_number, raw_heading_text) for all ## Slide … candidates
    slide_headings: list[tuple[int, str]]
    # (line_number, raw_number_str) for all ### Slide NN headings
    note_headings: list[tuple[int, str]]


def _scan_lines(lines: list[str]) -> _ScanResult:
    """Pass 1: iterate lines once and collect positions of H1, slide, and note headings."""
    h1_lines: list[tuple[int, str]] = []
    slide_headings: list[tuple[int, str]] = []
    note_headings: list[tuple[int, str]] = []

    for idx, line in enumerate(lines):
        lineno = idx + 1  # 1-based

        # Note: ### must be checked before ## to avoid false matches.
        if line.startswith("###"):
            m = re.match(r"^###\s+Slide\s+(\d+)", line)
            if m:
                note_headings.append((lineno, m.group(1)))
        elif line.startswith("##"):
            m_cand = re.match(r"^##\s+Slide\s+", line)
            if m_cand:
                slide_headings.append((lineno, line.rstrip()))
        elif line.startswith("#"):
            m_h1 = re.match(r"^#\s+(.+)$", line)
            if m_h1:
                h1_lines.append((lineno, m_h1.group(1)))

    return _ScanResult(
        h1_lines=h1_lines,
        slide_headings=slide_headings,
        note_headings=note_headings,
    )


def _apply_rules(
    scan: _ScanResult,
) -> tuple[list[ValidationError], list[str], list[SlideInfo]]:
    """Pass 2: evaluate all validation rules and return (errors, warnings, slides)."""
    errors: list[ValidationError] = []
    warnings: list[str] = []

    # ------------------------------------------------------------------
    # V-1: Exactly one H1
    # ------------------------------------------------------------------
    if len(scan.h1_lines) == 0:
        errors.append(
            ValidationError(line_number=1, message="No H1 title found", slide_number=None)
        )
    elif len(scan.h1_lines) > 1:
        first_line = scan.h1_lines[0][0]
        for dup_line, _ in scan.h1_lines[1:]:
            errors.append(
                ValidationError(
                    line_number=first_line,
                    message=(
                        f"Multiple H1 headings found — first at line {first_line},"
                        f" duplicate at line {dup_line}"
                    ),
                    slide_number=None,
                )
            )

    # ------------------------------------------------------------------
    # V-2: Slide heading format — collect valid slides and emit errors/warnings
    # ------------------------------------------------------------------
    valid_slides: list[SlideInfo] = []

    for lineno, raw in scan.slide_headings:
        # Try the full valid pattern first — also reject slide 00 (zero value)
        m_valid = re.match(r"^##\s+Slide\s+(\d{2})\s+[—\-]\s*(.+)$", raw)
        if m_valid:
            num_str = m_valid.group(1)
            num_int_valid = int(num_str)
            if num_int_valid == 0:
                # "00" is two digits but slide zero is not a valid slide number
                errors.append(
                    ValidationError(
                        line_number=lineno,
                        message=(
                            f"Slide number not zero-padded at line {lineno}:"
                            f" '## Slide {num_str}'"
                            f" — expected '## Slide {num_int_valid:02d}'"
                        ),
                        slide_number=num_int_valid,
                    )
                )
                continue
            title = m_valid.group(2).strip()
            valid_slides.append(SlideInfo(number=num_int_valid, title=title, line_number=lineno))
            continue

        # Try pattern with any number of digits + separator
        m_any = re.match(r"^##\s+Slide\s+(\d+)\s+[—\-]", raw)
        if m_any:
            num_str = m_any.group(1)
            # Non-zero-padded: digit string present but not exactly two digits
            try:
                num_int: int | None = int(num_str)
            except ValueError:
                num_int = None
            errors.append(
                ValidationError(
                    line_number=lineno,
                    message=(
                        f"Slide number not zero-padded at line {lineno}:"
                        f" '## Slide {num_str}'"
                        f" — expected '## Slide {int(num_str):02d}'"
                    ),
                    slide_number=num_int,
                )
            )
            continue

        # Candidate heading that matches no number pattern at all → warning
        warnings.append(
            f"Line {lineno}: heading does not match '## Slide NN — Title' — block skipped"
        )

    # ------------------------------------------------------------------
    # V-3: Duplicate slide numbers
    # ------------------------------------------------------------------
    number_to_lines: dict[int, list[int]] = {}
    for slide in valid_slides:
        number_to_lines.setdefault(slide.number, []).append(slide.line_number)

    deduplicated_slides: list[SlideInfo] = []
    seen_numbers: set[int] = set()
    for num, line_list in number_to_lines.items():
        if len(line_list) > 1:
            line_a, line_b = line_list[0], line_list[1]
            errors.append(
                ValidationError(
                    line_number=line_a,
                    message=f"Duplicate slide number {num:02d} at lines {line_a} and {line_b}",
                    slide_number=num,
                )
            )
        else:
            seen_numbers.add(num)

    # Keep only non-duplicate slides in original order
    for slide in valid_slides:
        if slide.number in seen_numbers:
            deduplicated_slides.append(slide)

    # ------------------------------------------------------------------
    # V-4: Slide count > 30
    # ------------------------------------------------------------------
    total_well_formed = len(valid_slides)
    if total_well_formed > 30:
        warnings.append(
            f"{total_well_formed} slides found — performance may degrade above 30 slides"
        )

    # ------------------------------------------------------------------
    # V-5: Orphan speaker notes
    # ------------------------------------------------------------------
    well_formed_numbers = {s.number for s in valid_slides}
    for note_lineno, raw_num_str in scan.note_headings:
        try:
            note_num = int(raw_num_str)
        except ValueError:
            continue
        if note_num not in well_formed_numbers:
            warnings.append(
                f"Speaker notes for slide {note_num:02d} (line {note_lineno})"
                f" have no matching slide"
            )

    # V-6: Missing Speaker Notes — no error, no warning (by design)

    return errors, warnings, deduplicated_slides


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def validate_prompt_file(content: str) -> ValidationResult:
    """Validate a raw prompt file string and return a full ValidationResult.

    Two-pass analysis:
      Pass 1 — scan raw lines for H1s, slide headings, and note headings.
      Pass 2 — apply rules V-1 through V-6, collecting all errors and warnings.

    The function never raises. Returns ValidationResult for any input.

    Args:
        content: Raw string content of a prompt file.

    Returns:
        ValidationResult with valid, slide_count, slides, errors, warnings.
    """
    lines = content.splitlines()
    scan = _scan_lines(lines)
    errors, warnings, slides = _apply_rules(scan)

    return ValidationResult(
        valid=len(errors) == 0,
        slide_count=len(slides),
        slides=slides,
        errors=errors,
        warnings=warnings,
    )
