"""renderdeck_mcp — MCP server for generating PowerPoint presentations via Gemini."""

from __future__ import annotations

from importlib.metadata import version as _v

__version__ = _v("renderdeck-mcp")
