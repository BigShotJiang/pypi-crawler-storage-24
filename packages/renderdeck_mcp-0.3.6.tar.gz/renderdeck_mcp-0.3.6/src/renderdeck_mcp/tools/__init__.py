from __future__ import annotations

"""tools subpackage — MCP tool handlers exposed to the MCP client."""
