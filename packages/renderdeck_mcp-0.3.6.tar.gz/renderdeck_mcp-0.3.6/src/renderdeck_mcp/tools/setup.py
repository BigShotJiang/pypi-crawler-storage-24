"""MCP tools: setup_gemini_key and get_setup_status.

Validates and stores the Gemini API key, and reports configuration readiness.
"""

from __future__ import annotations

import logging
from typing import Any

logger = logging.getLogger(__name__)


def _validate_api_key(api_key: str) -> bool:
    """Validate the API key with a lightweight Gemini API call.

    Returns True if the key is valid.
    """
    try:
        from google import genai

        client = genai.Client(api_key=api_key)
        # List models is a lightweight call to validate the key
        models = client.models.list()
        # Consume at least one result to confirm the key works
        next(iter(models))
        return True
    except Exception:
        logger.debug("API key validation failed", exc_info=True)
        return False


def run_setup_gemini_key(api_key: str) -> dict[str, Any]:
    """Validate and store a Gemini API key.

    Returns a status dict with success/failure info.
    The API key is never included in the return value.
    """
    if not api_key or not api_key.strip():
        return {
            "status": "error",
            "message": "API key cannot be empty",
        }

    api_key = api_key.strip()

    if not _validate_api_key(api_key):
        return {
            "status": "error",
            "message": "Invalid API key — validation call to Gemini API failed",
        }

    from renderdeck_mcp.config import store_api_key

    store_api_key(api_key)

    return {
        "status": "success",
        "message": "Gemini API key validated and stored securely",
    }


def run_get_setup_status() -> dict[str, Any]:
    """Return the current configuration and setup status."""
    from renderdeck_mcp.config import get_setup_status

    return get_setup_status()
