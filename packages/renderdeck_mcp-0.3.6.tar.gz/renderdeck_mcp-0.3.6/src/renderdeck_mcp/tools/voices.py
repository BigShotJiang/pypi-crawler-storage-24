"""List available TTS voices for video narration."""

from __future__ import annotations

import tempfile
import webbrowser
from pathlib import Path


def _build_html(voices: list[dict[str, str]]) -> str:
    """Build a self-contained HTML page with inline audio players."""
    us_rows: list[str] = []
    gb_rows: list[str] = []

    for v in voices:
        sample = v.get("sample_url", "")
        if not sample:
            continue

        player = f'<audio controls preload="none" src="{sample}"></audio>'
        gender_cls = "gender-f" if v["gender"] == "Female" else "gender-m"
        row = (
            f'<tr><td class="alias">{v["alias"]}</td>'
            f'<td class="full-name">{v["full_name"]}</td>'
            f'<td class="{gender_cls}">{v["gender"]}</td>'
            f"<td>{player}</td></tr>"
        )

        if v["locale"] == "en-GB":
            gb_rows.append(row)
        else:
            us_rows.append(row)

    def _table(rows: list[str]) -> str:
        body = "\n".join(rows)
        return f"""<table>
<thead><tr><th>Alias</th><th>Full Name</th><th>Gender</th><th>Play Sample</th></tr></thead>
<tbody>{body}</tbody>
</table>"""

    return f"""<!DOCTYPE html>
<html lang="en"><head><meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>RenderDeck \u2014 Voice Samples</title>
<style>
*{{box-sizing:border-box;margin:0;padding:0}}
body{{font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif;background:#f8f9fa;color:#1a1a2e;padding:2rem;line-height:1.6}}
h1{{margin-bottom:.5rem;font-size:1.8rem}}
.subtitle{{color:#666;margin-bottom:2rem}}
.usage{{background:#e8f4fd;border-left:4px solid #2196F3;padding:1rem 1.2rem;margin-bottom:2rem;border-radius:0 6px 6px 0}}
.usage code{{background:#d4e9f7;padding:2px 6px;border-radius:3px;font-size:.9em}}
table{{width:100%;border-collapse:collapse;background:#fff;border-radius:8px;overflow:hidden;box-shadow:0 1px 3px rgba(0,0,0,.1)}}
th{{background:#1a1a2e;color:#fff;text-align:left;padding:12px 16px;font-weight:600}}
td{{padding:10px 16px;border-bottom:1px solid #eee}}
tr:last-child td{{border-bottom:none}}
tr:hover{{background:#f0f4ff}}
.alias{{font-family:monospace;font-weight:600;font-size:1.05em}}
.full-name{{font-family:monospace;color:#555;font-size:.9em}}
.gender-f{{color:#7B1FA2}}.gender-m{{color:#1565C0}}
.section{{margin-top:2rem}}.section h2{{font-size:1.3rem;margin-bottom:.8rem;border-bottom:2px solid #e0e0e0;padding-bottom:.4rem}}
audio{{height:32px;vertical-align:middle}}
footer{{margin-top:2rem;color:#888;font-size:.85em}}
</style></head><body>
<h1>RenderDeck Voice Samples</h1>
<p class="subtitle">Click play to preview each voice \u2014 use the alias in <code>generate_video(voice="...")</code></p>
<div class="usage"><strong>Usage:</strong> Pass the alias as the <code>voice</code> parameter.<br>
Example: <code>generate_video(project_name="my_deck", ..., voice="roger")</code></div>
<div class="section"><h2>US English (en-US)</h2>{_table(us_rows)}</div>
<div class="section"><h2>British English (en-GB)</h2>{_table(gb_rows)}</div>
<footer>Samples from <a href="https://github.com/yaph/tts-samples">tts-samples</a>. Only voices with available samples are shown.</footer>
</body></html>"""


def run_list_voices() -> dict[str, object]:
    """Return all supported TTS voices with aliases and metadata.

    Also opens a local HTML page with inline audio players in the
    user's default browser so they can audition voices immediately.
    """
    from renderdeck_mcp.voices import DEFAULT_VOICES

    voices: list[dict[str, str]] = []
    for alias, info in sorted(DEFAULT_VOICES.items()):
        voices.append(
            {
                "alias": alias,
                "full_name": info["full_name"],
                "locale": info["locale"],
                "gender": info["gender"],
            }
        )

    # Build HTML from full voice data (includes sample_url for audio players).
    full_voices = [{"alias": a, **v} for a, v in sorted(DEFAULT_VOICES.items())]
    html = _build_html(full_voices)
    tmp = Path(tempfile.gettempdir()) / "renderdeck_voice_samples.html"
    tmp.write_text(html, encoding="utf-8")
    webbrowser.open(tmp.as_uri())

    return {
        "voices": voices,
        "default_voice": "aria (en-US-AriaNeural)",
        "total_count": len(voices),
        "samples_page": str(tmp),
        "samples_hint": (
            "A voice samples page with play buttons has been opened in the browser. "
            "Click play next to any voice to hear it."
        ),
        "usage_hint": (
            "Use the alias (e.g. 'roger') or full name (e.g. 'en-US-RogerNeural') "
            "as the voice parameter in generate_video."
        ),
    }
