"""MCP tool: generate_slide.

Generates a single slide image via Gemini and caches it.
Designed for per-slide invocation so the MCP client (e.g. Claude Desktop)
controls the loop and never hits a tool-call timeout.
"""

from __future__ import annotations

import logging
import os
from pathlib import Path

from renderdeck_mcp.generation.cache import (
    CacheManifest,
    content_hash_for_slide,
    load_cache_manifest,
    options_hash,
    save_cache_manifest,
)
from renderdeck_mcp.generation.gemini import (
    AspectRatio,
    GeminiConfig,
    SlideImageRequest,
    generate_image,
)

logger = logging.getLogger(__name__)

_CACHE_BASE_DIR: Path = Path.home() / ".renderdeck" / "cache"
_MANIFEST_VERSION: int = 1


async def run_generate_slide(
    project_name: str,
    slide_number: int,
    image_prompt: str,
    general_context: str = "",
    visual_rules: str = "",
    image_quality: str = "final",
) -> dict[str, object]:
    """Generate a single slide image and cache the result.

    Args:
        project_name: Cache project name (e.g. "my-deck").
        slide_number: 1-based slide number.
        image_prompt: The image generation prompt for this slide.
        general_context: Optional general/audience context from the prompt file.
        visual_rules: Optional global visual rules from the prompt file.
        image_quality: "draft" or "final".

    Returns:
        Dict with status, slide_number, cached (bool), image_size_kb or error.
    """
    from google import genai

    # Resolve API key
    api_key = os.environ.get("GOOGLE_GEMINI_API_KEY")
    if not api_key:
        return {
            "status": "error",
            "message": "Gemini API key not configured. Set GOOGLE_GEMINI_API_KEY.",
        }

    models = {
        "draft": "gemini-3.1-flash-image-preview",
        "final": "gemini-3-pro-image-preview",
    }
    model = models.get(image_quality, models["final"])

    # Check cache
    cache_dir = _CACHE_BASE_DIR / project_name
    current_opts_hash = options_hash(aspect_ratio="WIDE", model=model)
    c_hash = content_hash_for_slide(
        general=general_context,
        global_rules=visual_rules,
        image_prompt=image_prompt,
    )

    manifest = load_cache_manifest(project_name)
    if manifest and manifest.options_hash == current_opts_hash:
        cached_hash = manifest.slides.get(slide_number)
        if cached_hash == c_hash:
            img_path = cache_dir / f"slide_{slide_number:02d}.png"
            if img_path.is_file():
                size_kb = img_path.stat().st_size / 1024
                return {
                    "status": "ok",
                    "slide_number": slide_number,
                    "cached": True,
                    "image_size_kb": round(size_kb, 1),
                }

    # Generate
    config = GeminiConfig(api_key=api_key, model=model)
    client = genai.Client(api_key=api_key)
    request = SlideImageRequest(
        slide_index=slide_number - 1,
        prompt=image_prompt,
        aspect_ratio=AspectRatio.WIDE,
        general_context=general_context,
        visual_rules=visual_rules,
    )

    image_bytes = await generate_image(client, request, config)

    if image_bytes is None:
        return {
            "status": "error",
            "slide_number": slide_number,
            "message": "Image generation failed (content policy or transient error). Retry later.",
        }

    # Write to cache
    cache_dir.mkdir(parents=True, exist_ok=True)
    img_path = cache_dir / f"slide_{slide_number:02d}.png"
    try:
        img_path.write_bytes(image_bytes)
    except OSError:
        pass

    # Update manifest
    if manifest is None:
        manifest = CacheManifest(
            version=_MANIFEST_VERSION,
            options_hash=current_opts_hash,
            slides={},
        )
    manifest.slides[slide_number] = c_hash
    manifest.options_hash = current_opts_hash
    save_cache_manifest(project_name, manifest)

    size_kb = len(image_bytes) / 1024
    return {
        "status": "ok",
        "slide_number": slide_number,
        "cached": False,
        "image_size_kb": round(size_kb, 1),
    }
