"""MCP tool: assemble_deck.

Assembles a .pptx from cached slide images. Designed to be called after
generate_slide has been run for each slide.
"""

from __future__ import annotations

import logging
import re
from datetime import datetime
from pathlib import Path

from renderdeck_mcp.assembly.pptx_builder import DeckData, NotesMode, SlideData, build_pptx
from renderdeck_mcp.parser import parse_prompt_file

logger = logging.getLogger(__name__)

_CACHE_BASE_DIR: Path = Path.home() / ".renderdeck" / "cache"
_DEFAULT_OUTPUT_BASE: Path = Path.home() / "Documents" / "RenderDeck"


def _slugify(text: str) -> str:
    s = text.lower().strip()
    s = re.sub(r"[^a-z0-9\s-]", "", s)
    s = re.sub(r"[\s]+", "-", s)
    s = re.sub(r"-+", "-", s).strip("-")
    return s or "untitled"


def run_assemble_deck(
    project_name: str,
    slide_prompt_content: str,
    output_path: str | None = None,
    notes_mode: NotesMode = "full",
) -> dict[str, object]:
    """Assemble a .pptx from cached slide images.

    Args:
        project_name: Cache project name matching generate_slide calls.
        slide_prompt_content: Full prompt file content (for titles/notes).
        output_path: Optional output path. Defaults to ~/Documents/RenderDeck/.

    Returns:
        Dict with status, output_path, slide_count, slides_with_images.
    """
    deck = parse_prompt_file(slide_prompt_content)
    if not deck.slides:
        return {"status": "error", "message": "Prompt file contains no slides."}

    cache_dir = _CACHE_BASE_DIR / project_name
    slides_with_images = 0

    slide_data_list: list[SlideData] = []
    for idx, slide in enumerate(deck.slides):
        slide_number = idx + 1
        image_bytes: bytes | None = None
        img_path = cache_dir / f"slide_{slide_number:02d}.png"
        if img_path.is_file():
            try:
                image_bytes = img_path.read_bytes()
                slides_with_images += 1
            except OSError:
                pass

        slide_data_list.append(
            SlideData(
                slide_number=slide_number,
                title=slide.title,
                speaker_notes=slide.speaker_notes,
                image_bytes=image_bytes,
            )
        )

    deck_data = DeckData(title=deck.title, slides=slide_data_list)

    if output_path:
        resolved_output = output_path
    else:
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        slug = _slugify(deck.title)
        resolved_output = str(_DEFAULT_OUTPUT_BASE / f"{slug}_{timestamp}.pptx")

    written_path = build_pptx(deck_data, resolved_output, notes_mode=notes_mode)

    return {
        "status": "ok",
        "output_path": str(written_path),
        "slide_count": len(deck.slides),
        "slides_with_images": slides_with_images,
        "slides_text_only": len(deck.slides) - slides_with_images,
    }
