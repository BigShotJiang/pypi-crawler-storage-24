"""MCP tool: generate_deck.

Orchestrates the full pipeline: parse prompt file, check cache, generate images
via Gemini for uncached slides, assemble .pptx, update cache manifest.

Design doc: docs/sdd/epic-mcp-server-generation-assembly/generate-deck-tool/design.md
"""

from __future__ import annotations

import logging
import os
import re
from collections.abc import Awaitable, Callable
from datetime import datetime
from pathlib import Path
from typing import Literal

from renderdeck_mcp.assembly.pptx_builder import DeckData, NotesMode, SlideData, build_pptx
from renderdeck_mcp.generation.cache import (
    CacheManifest,
    content_hash_for_slide,
    load_cache_manifest,
    options_hash,
    save_cache_manifest,
    should_regenerate,
)
from renderdeck_mcp.generation.gemini import (
    AspectRatio,
    GeminiConfig,
    SlideImageRequest,
    generate_images_concurrent,
)
from renderdeck_mcp.parser import ParsedDeck, parse_prompt_file

ProgressCallback = Callable[[float, float, str], Awaitable[None]]

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

_GEMINI_MODELS: dict[str, str] = {
    "draft": "gemini-3.1-flash-image-preview",
    "final": "gemini-3-pro-image-preview",
}
_CACHE_BASE_DIR: Path = Path.home() / ".renderdeck" / "cache"
_DEFAULT_OUTPUT_BASE: Path = Path.home() / "Documents" / "RenderDeck"
_MANIFEST_VERSION: int = 1

# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _slugify(text: str) -> str:
    """Convert a title string to a URL/filesystem-safe slug.

    Args:
        text: Raw title text (e.g. "My Great Deck").

    Returns:
        Lowercase hyphenated slug (e.g. "my-great-deck"), or "untitled"
        if the result would be empty.
    """
    s = text.lower().strip()
    s = re.sub(r"[^a-z0-9\s-]", "", s)
    s = re.sub(r"[\s]+", "-", s)
    s = re.sub(r"-+", "-", s).strip("-")
    return s or "untitled"


def _read_cached_image(cache_dir: Path, slide_index: int) -> bytes | None:
    """Read a cached slide image from disk.

    Args:
        cache_dir: The project cache directory.
        slide_index: 1-based slide index.

    Returns:
        PNG bytes if the file exists and is readable, otherwise None.
    """
    image_path = cache_dir / f"slide_{slide_index:02d}.png"
    if image_path.exists() and image_path.is_file():
        try:
            return image_path.read_bytes()
        except OSError:
            return None
    return None


def _write_cached_image(cache_dir: Path, slide_index: int, image_bytes: bytes) -> None:
    """Write a generated slide image to the cache directory.

    Args:
        cache_dir: The project cache directory (must already exist).
        slide_index: 1-based slide index.
        image_bytes: Raw PNG bytes to write.
    """
    image_path = cache_dir / f"slide_{slide_index:02d}.png"
    try:
        image_path.write_bytes(image_bytes)
    except OSError:
        pass  # Cache write failure is non-fatal


def _cost_estimate(slides_generated: int) -> str:
    """Build a human-readable cost estimate string.

    Args:
        slides_generated: Number of images sent to Gemini.

    Returns:
        Human-readable estimate string.
    """
    cost = slides_generated * 0.001
    return f"~{slides_generated} image(s) generated (est. ${cost:.3f} USD)"


# ---------------------------------------------------------------------------
# Public async orchestration function
# ---------------------------------------------------------------------------


async def run_generate_deck(
    slide_prompt_content: str,
    output_path: str | None = None,
    image_quality: Literal["draft", "final"] = "final",
    project_name: str | None = None,
    progress_cb: ProgressCallback | None = None,
    notes_mode: NotesMode = "full",
) -> dict[str, object]:
    """Run the full generate_deck pipeline.

    Parses the prompt content, checks the cache, generates images for uncached
    slides, assembles a .pptx file, updates the cache manifest, and returns a
    result dict.

    Args:
        slide_prompt_content: Full text of the slide prompt file.
        output_path: Optional explicit output path for the .pptx.
            Default: ~/Documents/RenderDeck/{slug}_{timestamp}.pptx
        image_quality: "draft" or "final". Currently both use the same model;
            reserved for future differentiation.
        project_name: Optional project name for the cache. Defaults to
            the slugified deck title.

    Returns:
        On success: dict with status="ok", output_path, slide_count,
            slides_generated, slides_cached, cost_estimate.
        On error: dict with status="error", message.
    """

    # Helper to report progress without awaiting if callback is None.
    async def _progress(current: float, total: float, message: str) -> None:
        if progress_cb is not None:
            await progress_cb(current, total, message)

    # ------------------------------------------------------------------
    # Step 1 — Parse
    # ------------------------------------------------------------------
    logger.info("Parsing slide prompt file...")
    deck: ParsedDeck = parse_prompt_file(slide_prompt_content)
    logger.info("Parsed deck: %r — %d slide(s)", deck.title, len(deck.slides))

    # ------------------------------------------------------------------
    # Step 2 — Validate: require at least one slide
    # ------------------------------------------------------------------
    if not deck.slides:
        return {
            "status": "error",
            "message": (
                "Prompt file contains no slides. Add at least one ## Slide NN — Title block."
            ),
        }

    # ------------------------------------------------------------------
    # Step 3 — Resolve API key
    # ------------------------------------------------------------------
    api_key: str | None = os.environ.get("GOOGLE_GEMINI_API_KEY")
    if not api_key:
        return {
            "status": "error",
            "message": (
                "Gemini API key not configured. "
                "Set the GOOGLE_GEMINI_API_KEY environment variable. "
                "See: https://aistudio.google.com/app/apikey"
            ),
        }

    # ------------------------------------------------------------------
    # Step 4 — Resolve model from image_quality
    # ------------------------------------------------------------------
    model: str = _GEMINI_MODELS.get(image_quality, _GEMINI_MODELS["final"])
    logger.info("Image quality: %s → model: %s", image_quality, model)

    # ------------------------------------------------------------------
    # Step 5 — Resolve project_name
    # ------------------------------------------------------------------
    resolved_project: str = project_name if project_name else _slugify(deck.title)

    # ------------------------------------------------------------------
    # Step 6 — Resolve output path
    # ------------------------------------------------------------------
    if output_path:
        resolved_output = output_path
    else:
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        slug = _slugify(deck.title)
        resolved_output = str(_DEFAULT_OUTPUT_BASE / f"{slug}_{timestamp}.pptx")

    # ------------------------------------------------------------------
    # Step 7 — Load cache manifest
    # ------------------------------------------------------------------
    logger.info("Loading cache manifest for project %r...", resolved_project)
    manifest: CacheManifest | None = load_cache_manifest(resolved_project)
    if manifest:
        logger.info("Cache manifest found: %d slide(s) cached", len(manifest.slides))
    else:
        logger.info("No existing cache manifest — cold start")

    # ------------------------------------------------------------------
    # Step 8 — Compute hashes
    # ------------------------------------------------------------------
    current_opts_hash = options_hash(aspect_ratio="WIDE", model=model)
    content_hashes: dict[int, str] = {}
    for idx, slide in enumerate(deck.slides):
        slide_number = idx + 1
        content_hashes[slide_number] = content_hash_for_slide(
            general=deck.general,
            global_rules=deck.global_rules,
            image_prompt=slide.image_prompt,
        )

    # ------------------------------------------------------------------
    # Step 9 — Filter: determine which slides need generation
    # ------------------------------------------------------------------
    cache_dir = _CACHE_BASE_DIR / resolved_project
    to_generate_indices: list[int] = []  # 0-based slide loop indices
    cached_slide_numbers: list[int] = []  # 1-based slide numbers

    for idx, slide in enumerate(deck.slides):
        slide_number = idx + 1
        # Slides without prompts never need image generation
        if not slide.has_prompt:
            continue
        if should_regenerate(
            slide_number=slide_number,
            content_hash=content_hashes[slide_number],
            manifest=manifest,
            current_options_hash=current_opts_hash,
        ):
            to_generate_indices.append(idx)
        else:
            cached_slide_numbers.append(slide_number)

    # ------------------------------------------------------------------
    # Step 10 — Load cached images from disk
    # ------------------------------------------------------------------
    total = len(deck.slides)
    logger.info(
        "Cache check: %d/%d slide(s) cached, %d to generate",
        len(cached_slide_numbers),
        total,
        len(to_generate_indices),
    )
    cached_images: dict[int, bytes | None] = {}
    for slide_number in cached_slide_numbers:
        cached_images[slide_number] = _read_cached_image(cache_dir, slide_number)

    # ------------------------------------------------------------------
    # Step 11 — Generate new images via Gemini
    # ------------------------------------------------------------------
    generated_images: dict[int, bytes | None] = {}
    gen_count = len(to_generate_indices)
    # Progress total: gen_count images + 1 assembly step
    progress_total = float(gen_count + 1)

    if to_generate_indices:
        config = GeminiConfig(
            api_key=api_key,
            model=model,
        )
        requests: list[SlideImageRequest] = []
        for loop_idx in to_generate_indices:
            slide = deck.slides[loop_idx]
            requests.append(
                SlideImageRequest(
                    slide_index=loop_idx,
                    prompt=slide.image_prompt,
                    aspect_ratio=AspectRatio.WIDE,
                    general_context=deck.general,
                    visual_rules=deck.global_rules,
                )
            )

        logger.info(
            "Generating %d image(s) via Gemini (%s)...",
            gen_count,
            model,
        )
        await _progress(0, progress_total, f"Generating {gen_count} images via Gemini...")
        results = await generate_images_concurrent(requests, config, progress_cb=progress_cb)

        # Ensure cache directory exists before writing
        cache_dir.mkdir(parents=True, exist_ok=True)

        for i, result in enumerate(results):
            slide_number = result.slide_index + 1
            generated_images[slide_number] = result.image_bytes
            if result.image_bytes is not None:
                size_kb = len(result.image_bytes) / 1024
                logger.info(
                    "  [%d/%d] Slide %d — OK (%.0f KB)",
                    i + 1,
                    gen_count,
                    slide_number,
                    size_kb,
                )
                _write_cached_image(cache_dir, slide_number, result.image_bytes)
            else:
                logger.warning(
                    "  [%d/%d] Slide %d — FAILED (fallback, no image)",
                    i + 1,
                    gen_count,
                    slide_number,
                )

    # ------------------------------------------------------------------
    # Step 12 — Build DeckData merging all image sources
    # ------------------------------------------------------------------
    slide_data_list: list[SlideData] = []
    for idx, slide in enumerate(deck.slides):
        slide_number = idx + 1
        image_bytes: bytes | None = None
        if slide_number in generated_images:
            image_bytes = generated_images[slide_number]
        elif slide_number in cached_images:
            image_bytes = cached_images[slide_number]

        slide_data_list.append(
            SlideData(
                slide_number=slide_number,
                title=slide.title,
                speaker_notes=slide.speaker_notes,
                image_bytes=image_bytes,
            )
        )

    deck_data = DeckData(title=deck.title, slides=slide_data_list)

    # ------------------------------------------------------------------
    # Step 13 — Assemble .pptx
    # ------------------------------------------------------------------
    await _progress(float(gen_count), progress_total, "Assembling .pptx...")
    logger.info("Assembling .pptx (%d slides) → %s", len(slide_data_list), resolved_output)
    written_path: Path = build_pptx(deck_data, resolved_output, notes_mode=notes_mode)
    await _progress(progress_total, progress_total, "Done")

    # ------------------------------------------------------------------
    # Step 14 — Update and save cache manifest
    # ------------------------------------------------------------------
    new_slides: dict[int, str] = {}
    for slide_number, content_hash in content_hashes.items():
        new_slides[slide_number] = content_hash

    new_manifest = CacheManifest(
        version=_MANIFEST_VERSION,
        options_hash=current_opts_hash,
        slides=new_slides,
    )
    save_cache_manifest(resolved_project, new_manifest)
    logger.info("Cache manifest saved for project %r", resolved_project)

    # ------------------------------------------------------------------
    # Step 15 — Return result
    # ------------------------------------------------------------------
    slides_generated = len(to_generate_indices)
    slides_cached = len(cached_slide_numbers)

    return {
        "status": "ok",
        "output_path": str(written_path),
        "slide_count": len(deck.slides),
        "slides_generated": slides_generated,
        "slides_cached": slides_cached,
        "cost_estimate": _cost_estimate(slides_generated),
    }
