"""Generate narrated MP4 video from cached slide images.

Reads cached slide PNGs from a project cache directory, generates TTS audio
via edge-tts, and composes them into a single MP4 using FFmpeg.
"""

from __future__ import annotations

import logging
import os
import re
import shutil
import subprocess
import tempfile
from datetime import datetime
from pathlib import Path

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Slide range parsing
# ---------------------------------------------------------------------------


def parse_slide_range(range_str: str, max_slides: int) -> list[int]:
    """Parse '1-3' or '2,5,7' or '1-3,7' into a list of 1-based slide numbers."""
    result: list[int] = []
    for part in range_str.split(","):
        part = part.strip()
        if "-" in part:
            start, end = part.split("-", 1)
            result.extend(range(int(start), int(end) + 1))
        else:
            result.append(int(part))
    return [n for n in result if 1 <= n <= max_slides]


# ---------------------------------------------------------------------------
# FFmpeg helpers
# ---------------------------------------------------------------------------


def check_ffmpeg() -> str | None:
    """Check if ffmpeg is available. Returns error message or None."""
    try:
        subprocess.run(["ffmpeg", "-version"], capture_output=True, check=True)
    except FileNotFoundError:
        return (
            "ffmpeg not found. Install with: brew install ffmpeg (macOS) "
            "or apt install ffmpeg (Linux)"
        )
    return None


def _make_segment(image_path: Path, audio_path: Path, out_path: Path) -> str | None:
    """Create a video segment from a static image + audio. Returns error or None."""
    cmd = [
        "ffmpeg",
        "-y",
        "-loop",
        "1",
        "-i",
        str(image_path),
        "-i",
        str(audio_path),
        "-c:v",
        "libx264",
        "-tune",
        "stillimage",
        "-c:a",
        "aac",
        "-b:a",
        "192k",
        "-shortest",
        "-pix_fmt",
        "yuv420p",
        "-vf",
        "scale=trunc(iw/2)*2:trunc(ih/2)*2",
        str(out_path),
    ]
    result = subprocess.run(cmd, capture_output=True, text=True)
    if result.returncode != 0:
        return f"FFmpeg segment error: {result.stderr[:500]}"
    return None


def _concat_segments(segment_paths: list[Path], output_path: Path) -> str | None:
    """Concatenate video segments into final MP4. Returns error or None."""
    output_path.parent.mkdir(parents=True, exist_ok=True)

    with tempfile.NamedTemporaryFile(mode="w", suffix=".txt", delete=False) as f:
        for seg in segment_paths:
            f.write(f"file '{seg}'\n")
        list_path = f.name

    try:
        cmd = [
            "ffmpeg",
            "-y",
            "-f",
            "concat",
            "-safe",
            "0",
            "-i",
            list_path,
            "-c",
            "copy",
            str(output_path),
        ]
        result = subprocess.run(cmd, capture_output=True, text=True)
        if result.returncode != 0:
            return f"FFmpeg concat error: {result.stderr[:500]}"
    finally:
        os.unlink(list_path)
    return None


# ---------------------------------------------------------------------------
# TTS generation
# ---------------------------------------------------------------------------


async def _generate_tts(narration: str, voice: str, output_path: Path) -> None:
    """Generate TTS audio using edge-tts and save as MP3."""
    import edge_tts

    communicate = edge_tts.Communicate(narration, voice)
    await communicate.save(str(output_path))


# ---------------------------------------------------------------------------
# Slug helper
# ---------------------------------------------------------------------------

_SLUG_RE = re.compile(r"[^a-z0-9]+")


def _slugify(title: str) -> str:
    return _SLUG_RE.sub("_", title.lower()).strip("_")[:50]


# ---------------------------------------------------------------------------
# Main tool implementation
# ---------------------------------------------------------------------------

_CACHE_BASE_DIR = Path.home() / ".renderdeck" / "cache"


async def run_generate_video(
    project_name: str,
    slide_prompt_content: str,
    output_path: str | None = None,
    voice: str = "aria",
    slides: str | None = None,
) -> dict[str, object]:
    """Generate a narrated MP4 video from cached slide images.

    Args:
        project_name: Cache project name (matches generate_slide/assemble_deck calls).
        slide_prompt_content: Full prompt file content (narration extracted from **Say:** lines).
        output_path: Output MP4 path. Defaults to ~/Documents/RenderDeck/{slug}_{timestamp}.mp4.
        voice: Voice name or alias (default: "aria").
        slides: Optional slide range e.g. "1-3" or "2,5,7".

    Returns:
        Dict with status, output_path, slide_count, video_size_mb, voice_used.
    """
    from renderdeck_mcp.assembly.pptx_builder import extract_narration
    from renderdeck_mcp.parser.prompt_file import parse_prompt_file
    from renderdeck_mcp.voices import resolve_voice

    # Check ffmpeg
    ffmpeg_err = check_ffmpeg()
    if ffmpeg_err:
        return {"status": "error", "message": ffmpeg_err}

    # Parse prompt file
    deck = parse_prompt_file(slide_prompt_content)
    if not deck.slides:
        return {"status": "error", "message": "No slides found in prompt content."}

    # Resolve voice
    resolved_voice = resolve_voice(voice)

    # Determine slide range
    if slides:
        slide_numbers = parse_slide_range(slides, len(deck.slides))
        if not slide_numbers:
            return {
                "status": "error",
                "message": (
                    f"No valid slides in range '{slides}' (deck has {len(deck.slides)} slides)."
                ),
            }
    else:
        slide_numbers = list(range(1, len(deck.slides) + 1))

    # Locate cache directory
    cache_dir = _CACHE_BASE_DIR / project_name
    if not cache_dir.is_dir():
        return {
            "status": "error",
            "message": (
                f"Cache directory not found: {cache_dir}. "
                "Run generate_slide/generate_deck first to generate slide images."
            ),
        }

    # Collect slide data (image + narration)
    slide_data: list[dict[str, object]] = []
    skipped: list[str] = []
    for num in slide_numbers:
        slide = deck.slides[num - 1]
        narration = extract_narration(slide.speaker_notes)
        image_path = cache_dir / f"slide_{slide.number}.png"

        if not image_path.exists():
            skipped.append(f"Slide {num}: no cached image")
            continue
        if not narration:
            skipped.append(f"Slide {num}: no **Say:** narration in speaker notes")
            continue

        slide_data.append(
            {
                "number": slide.number,
                "title": slide.title,
                "narration": narration,
                "image_path": image_path,
            }
        )

    if not slide_data:
        return {
            "status": "error",
            "message": (
                "No slides with both cached images and narration found. "
                + (f"Skipped: {'; '.join(skipped)}" if skipped else "")
            ),
        }

    # Determine output path
    if output_path:
        out = Path(output_path).expanduser().resolve()
    else:
        slug = _slugify(deck.title or project_name)
        ts = datetime.now(tz=datetime.UTC).strftime("%Y%m%d_%H%M%S")
        out_dir = Path.home() / "Documents" / "RenderDeck"
        out_dir.mkdir(parents=True, exist_ok=True)
        out = out_dir / f"{slug}_{ts}.mp4"

    # Set up TTS cache directory within project cache
    tts_dir = cache_dir / "tts_cache"
    tts_dir.mkdir(parents=True, exist_ok=True)

    # Generate TTS audio for each slide
    audio_paths: list[Path] = []
    for sd in slide_data:
        audio_path = tts_dir / f"slide_{sd['number']}.mp3"
        audio_paths.append(audio_path)

        if audio_path.exists():
            logger.info("Reusing cached TTS for slide %s", sd["number"])
            continue

        logger.info("Generating TTS for slide %s...", sd["number"])
        await _generate_tts(str(sd["narration"]), resolved_voice, audio_path)

    # Compose video segments
    with tempfile.TemporaryDirectory(prefix="renderdeck_video_") as tmp_dir:
        segment_paths: list[Path] = []
        for sd, audio_path in zip(slide_data, audio_paths):
            seg_path = Path(tmp_dir) / f"segment_{sd['number']}.mp4"
            segment_paths.append(seg_path)

            err = _make_segment(Path(str(sd["image_path"])), audio_path, seg_path)
            if err:
                return {"status": "error", "message": err}

        # Concatenate into final video
        if len(segment_paths) == 1:
            # Single segment — just copy it
            out.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(str(segment_paths[0]), str(out))
        else:
            err = _concat_segments(segment_paths, out)
            if err:
                return {"status": "error", "message": err}

    video_size_mb = round(out.stat().st_size / 1024 / 1024, 1)

    result: dict[str, object] = {
        "status": "ok",
        "output_path": str(out),
        "slide_count": len(slide_data),
        "video_size_mb": video_size_mb,
        "voice_used": resolved_voice,
    }
    if skipped:
        result["skipped"] = skipped

    return result
