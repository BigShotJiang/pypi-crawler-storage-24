"""Shared voice constants and resolution for TTS narration.

Used by both the ``generate_video`` and ``list_voices`` tools.
Voice aliases map friendly short names to full edge-tts neural voice identifiers.
"""

from __future__ import annotations

# ---------------------------------------------------------------------------
# Voice catalogue — alias → full edge-tts name
# ---------------------------------------------------------------------------

_SAMPLE_BASE = "https://github.com/yaph/tts-samples/raw/main/mp3/English"

DEFAULT_VOICES: dict[str, dict[str, str]] = {
    # US English
    "aria": {
        "full_name": "en-US-AriaNeural",
        "locale": "en-US",
        "gender": "Female",
        "sample_url": f"{_SAMPLE_BASE}/en-US-AriaNeural.mp3",
    },
    "guy": {
        "full_name": "en-US-GuyNeural",
        "locale": "en-US",
        "gender": "Male",
        "sample_url": f"{_SAMPLE_BASE}/en-US-GuyNeural.mp3",
    },
    "jenny": {
        "full_name": "en-US-JennyNeural",
        "locale": "en-US",
        "gender": "Female",
        "sample_url": f"{_SAMPLE_BASE}/en-US-JennyNeural.mp3",
    },
    "davis": {"full_name": "en-US-DavisNeural", "locale": "en-US", "gender": "Male"},
    "amber": {"full_name": "en-US-AmberNeural", "locale": "en-US", "gender": "Female"},
    "ana": {
        "full_name": "en-US-AnaNeural",
        "locale": "en-US",
        "gender": "Female",
        "sample_url": f"{_SAMPLE_BASE}/en-US-AnaNeural.mp3",
    },
    "andrew": {
        "full_name": "en-US-AndrewNeural",
        "locale": "en-US",
        "gender": "Male",
        "sample_url": f"{_SAMPLE_BASE}/en-US-AndrewNeural.mp3",
    },
    "ashley": {"full_name": "en-US-AshleyNeural", "locale": "en-US", "gender": "Female"},
    "brandon": {"full_name": "en-US-BrandonNeural", "locale": "en-US", "gender": "Male"},
    "brian": {
        "full_name": "en-US-BrianNeural",
        "locale": "en-US",
        "gender": "Male",
        "sample_url": f"{_SAMPLE_BASE}/en-US-BrianNeural.mp3",
    },
    "christopher": {
        "full_name": "en-US-ChristopherNeural",
        "locale": "en-US",
        "gender": "Male",
        "sample_url": f"{_SAMPLE_BASE}/en-US-ChristopherNeural.mp3",
    },
    "cora": {"full_name": "en-US-CoraNeural", "locale": "en-US", "gender": "Female"},
    "elizabeth": {"full_name": "en-US-ElizabethNeural", "locale": "en-US", "gender": "Female"},
    "emma": {
        "full_name": "en-US-EmmaNeural",
        "locale": "en-US",
        "gender": "Female",
        "sample_url": f"{_SAMPLE_BASE}/en-US-EmmaNeural.mp3",
    },
    "eric": {
        "full_name": "en-US-EricNeural",
        "locale": "en-US",
        "gender": "Male",
        "sample_url": f"{_SAMPLE_BASE}/en-US-EricNeural.mp3",
    },
    "jacob": {"full_name": "en-US-JacobNeural", "locale": "en-US", "gender": "Male"},
    "jane": {"full_name": "en-US-JaneNeural", "locale": "en-US", "gender": "Female"},
    "jason": {"full_name": "en-US-JasonNeural", "locale": "en-US", "gender": "Male"},
    "michelle": {
        "full_name": "en-US-MichelleNeural",
        "locale": "en-US",
        "gender": "Female",
        "sample_url": f"{_SAMPLE_BASE}/en-US-MichelleNeural.mp3",
    },
    "monica": {"full_name": "en-US-MonicaNeural", "locale": "en-US", "gender": "Female"},
    "nancy": {"full_name": "en-US-NancyNeural", "locale": "en-US", "gender": "Female"},
    "roger": {
        "full_name": "en-US-RogerNeural",
        "locale": "en-US",
        "gender": "Male",
        "sample_url": f"{_SAMPLE_BASE}/en-US-RogerNeural.mp3",
    },
    "sara": {"full_name": "en-US-SaraNeural", "locale": "en-US", "gender": "Female"},
    "steffan": {
        "full_name": "en-US-SteffanNeural",
        "locale": "en-US",
        "gender": "Male",
        "sample_url": f"{_SAMPLE_BASE}/en-US-SteffanNeural.mp3",
    },
    "tony": {"full_name": "en-US-TonyNeural", "locale": "en-US", "gender": "Male"},
    # British English
    "sonia": {
        "full_name": "en-GB-SoniaNeural",
        "locale": "en-GB",
        "gender": "Female",
        "sample_url": f"{_SAMPLE_BASE}/en-GB-SoniaNeural.mp3",
    },
    "ryan": {
        "full_name": "en-GB-RyanNeural",
        "locale": "en-GB",
        "gender": "Male",
        "sample_url": f"{_SAMPLE_BASE}/en-GB-RyanNeural.mp3",
    },
    "libby": {
        "full_name": "en-GB-LibbyNeural",
        "locale": "en-GB",
        "gender": "Female",
        "sample_url": f"{_SAMPLE_BASE}/en-GB-LibbyNeural.mp3",
    },
    "maisie": {
        "full_name": "en-GB-MaisieNeural",
        "locale": "en-GB",
        "gender": "Female",
        "sample_url": f"{_SAMPLE_BASE}/en-GB-MaisieNeural.mp3",
    },
    "thomas": {
        "full_name": "en-GB-ThomasNeural",
        "locale": "en-GB",
        "gender": "Male",
        "sample_url": f"{_SAMPLE_BASE}/en-GB-ThomasNeural.mp3",
    },
}

DEFAULT_VOICE = "en-US-AriaNeural"


def resolve_voice(voice: str) -> str:
    """Resolve a short alias to a full edge-tts voice name, or pass through as-is.

    Args:
        voice: Short alias (e.g. "aria") or full name (e.g. "en-US-AriaNeural").

    Returns:
        Full edge-tts voice identifier.
    """
    lower = voice.lower()
    if lower in DEFAULT_VOICES:
        return DEFAULT_VOICES[lower]["full_name"]
    return voice
