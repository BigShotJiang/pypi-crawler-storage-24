"""Gemini image generation client.

Wraps the google-genai SDK to generate slide images from text prompts.
Supports configurable concurrency, exponential backoff retry,
time-budgeted generation, and text-only fallback on failure.

Implemented by task 2.2 gemini-client.
"""

from __future__ import annotations

import asyncio
import base64
import io
import logging
import time
from collections.abc import Awaitable, Callable
from dataclasses import dataclass
from enum import StrEnum
from typing import Any

from google import genai
from google.genai import types

ProgressCallback = Callable[[float, float, str], Awaitable[None]]

logger = logging.getLogger(__name__)

# Capture the real asyncio.sleep at module load time so that test mocks on
# asyncio.sleep do not prevent the event-loop yields inside
# generate_images_concurrent.
_real_sleep = asyncio.sleep

# Maximum wall-clock seconds for the entire image generation phase.
# Claude Desktop enforces a ~240s MCP tool timeout; we leave headroom for
# parsing, cache checks, and .pptx assembly.
_GENERATION_BUDGET_SECONDS: float = 180.0


class AspectRatio(StrEnum):
    """Aspect ratio for generated images."""

    WIDE = "16:9"
    STANDARD = "4:3"


@dataclass(frozen=True)
class GeminiConfig:
    """Runtime configuration for the Gemini image generation client."""

    api_key: str
    model: str = "gemini-3-pro-image-preview"
    max_retries: int = 3
    max_concurrent_images: int = 5
    retry_delays: tuple[float, ...] = (1.0, 2.0, 4.0)
    generation_budget: float = _GENERATION_BUDGET_SECONDS


@dataclass(frozen=True)
class SlideImageRequest:
    """Input descriptor for a single slide image generation request."""

    slide_index: int
    prompt: str
    aspect_ratio: AspectRatio = AspectRatio.WIDE
    general_context: str = ""
    visual_rules: str = ""


@dataclass
class ImageResult:
    """Output of a single image generation attempt."""

    slide_index: int
    image_bytes: bytes | None
    fallback: bool
    error: str | None = None


# ---------------------------------------------------------------------------
# Internal constants
# ---------------------------------------------------------------------------

_STYLE_PREAMBLE = (
    "STYLE DIRECTIVE: You are a world-class presentation designer. "
    "Create visually striking, dynamic slides with bold compositions, "
    "rich depth and dimension, and confident use of color. "
    "Embrace contrast, visual hierarchy, and engaging layouts. "
    "Make every slide feel polished and energetic — "
    "not clip-art, not stock-photo generic, not flat or lifeless."
)

_POLICY_KEYWORDS = ("blocked", "policy", "PROHIBITED_CONTENT")
_RETRYABLE_CODES = ("429", "500", "502", "503")


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _build_prompt(request: SlideImageRequest) -> str:
    """Assemble full prompt from general context, visual rules, slide prompt."""
    parts: list[str] = [_STYLE_PREAMBLE]
    if request.general_context:
        parts.append(f"GENERAL CONTEXT:\n{request.general_context}")
    if request.visual_rules:
        parts.append(f"GLOBAL VISUAL RULES:\n{request.visual_rules}")
    parts.append(f"SLIDE IMAGE PROMPT:\n{request.prompt}")
    return "\n\n".join(parts)


def _is_content_policy_block(exc: Exception) -> bool:
    """Return True if the exception is a content policy violation."""
    msg = str(exc).lower()
    return any(kw.lower() in msg for kw in _POLICY_KEYWORDS)


def _is_retryable(exc: Exception) -> bool:
    """Return True if the exception indicates a transient failure."""
    if _is_content_policy_block(exc):
        return False
    msg = str(exc)
    return any(code in msg for code in _RETRYABLE_CODES)


def _extract_bytes_from_part(part: Any) -> bytes | None:
    """Extract image bytes from a single response part using three strategies."""
    # Strategy 1 & 2: inline_data.data — bytes or base64 string
    try:
        data = part.inline_data.data
        if isinstance(data, bytes):
            return data
        if isinstance(data, str):
            return base64.b64decode(data)
    except (AttributeError, ValueError):
        pass

    # Strategy 3: as_image() -> PIL Image -> BytesIO
    try:
        pil_image = part.as_image()
        buf = io.BytesIO()
        pil_image.save(buf, format="PNG")
        return buf.getvalue()
    except Exception:
        pass

    return None


def _extract_image_bytes(response: Any) -> bytes | None:
    """Parse Gemini response to extract raw PNG bytes.

    Checks response.parts first, then response.candidates[0].content.parts.
    Handles both bytes and base64-encoded inline_data, and as_image() fallback.
    Returns None if no image part is found.
    """
    parts: list[Any] = []
    try:
        if response.parts:
            parts = list(response.parts)
    except Exception:
        pass

    if not parts:
        try:
            parts = list(response.candidates[0].content.parts)
        except Exception:
            pass

    for part in parts:
        result = _extract_bytes_from_part(part)
        if result is not None:
            return result

    return None


# ---------------------------------------------------------------------------
# Public async functions
# ---------------------------------------------------------------------------


async def generate_image(
    client: genai.Client,
    request: SlideImageRequest,
    config: GeminiConfig,
) -> bytes | None:
    """Generate a single PNG image for one slide.

    Attempts up to config.max_retries calls with exponential backoff on
    HTTP 429 (quota) and 503 (service unavailable). Returns PNG bytes on
    success, or None if all attempts fail or the content is policy-blocked.

    Args:
        client: Authenticated google-genai Client instance.
        request: Slide descriptor including prompt and aspect ratio.
        config: Runtime tuning parameters (retries, delays).

    Returns:
        PNG bytes, or None on failure (caller treats as text-only slide).

    Raises:
        Nothing. All exceptions are caught internally and converted to None.
    """
    for attempt, delay in enumerate(config.retry_delays[: config.max_retries]):
        try:
            response = await asyncio.to_thread(
                client.models.generate_content,
                model=config.model,
                contents=_build_prompt(request),
                config=types.GenerateContentConfig(
                    response_modalities=["IMAGE"],
                    image_config=types.ImageConfig(
                        aspect_ratio=request.aspect_ratio.value,
                    ),
                ),
            )
            image_bytes = _extract_image_bytes(response)
            if image_bytes is not None:
                return image_bytes
            # Empty response — treat as transient, retry
        except Exception as exc:
            if _is_content_policy_block(exc):
                logger.warning("Content policy block on slide %d", request.slide_index)
                return None
            if not _is_retryable(exc):
                logger.warning(
                    "Non-retryable error on slide %d: %s",
                    request.slide_index,
                    type(exc).__name__,
                )
                return None
            if attempt < config.max_retries - 1:
                logger.info(
                    "Retrying slide %d after %.0fs (attempt %d)",
                    request.slide_index,
                    delay,
                    attempt + 1,
                )
                await asyncio.sleep(delay)

    return None


async def generate_images_concurrent(
    requests: list[SlideImageRequest],
    config: GeminiConfig,
    progress_cb: ProgressCallback | None = None,
) -> list[ImageResult]:
    """Generate images for all slides with bounded concurrency and a time budget.

    Uses an asyncio.Semaphore(config.max_concurrent_images) to cap
    simultaneous Gemini API calls. A wall-clock budget (config.generation_budget,
    default 180s) ensures the function returns before the MCP client timeout.
    Tasks still running when the budget expires are cancelled and treated as
    text-only fallback slides.

    Args:
        requests: One SlideImageRequest per slide.
        config: Includes api_key, model, concurrency, retry, and budget settings.
        progress_cb: Optional async callback(current, total, message) for
            reporting per-image progress to the MCP client.

    Returns:
        List of ImageResult, one per input request, in the same order.
        Slides that fail or are cancelled produce ImageResult(fallback=True).

    Raises:
        Nothing. Per-slide failures are isolated; one failure never
        prevents other slides from being attempted.
    """
    client = genai.Client(api_key=config.api_key)
    semaphore = asyncio.Semaphore(config.max_concurrent_images)
    total = float(len(requests) + 1)  # +1 for assembly step in caller
    completed = 0
    deadline = time.monotonic() + config.generation_budget

    async def _bounded(request: SlideImageRequest) -> ImageResult:
        nonlocal completed
        async with semaphore:
            image_bytes = await generate_image(client, request, config)
            completed += 1
            if progress_cb is not None:
                slide_num = request.slide_index + 1
                await progress_cb(
                    float(completed),
                    total,
                    f"Image {completed}/{len(requests)} done (slide {slide_num})",
                )
            return ImageResult(
                slide_index=request.slide_index,
                image_bytes=image_bytes,
                fallback=image_bytes is None,
            )

    # Create tasks one at a time, yielding between each so that tasks start
    # (and submit to the thread pool) in input order. Use the real asyncio.sleep
    # so that test mocks on asyncio.sleep do not suppress the event-loop yield.
    tasks: list[asyncio.Task[ImageResult]] = []
    for req in requests:
        tasks.append(asyncio.create_task(_bounded(req)))
        await _real_sleep(0)

    if not tasks:
        return []

    # Wait with a time budget — collect whatever finishes in time.
    remaining = max(0.0, deadline - time.monotonic())
    done, pending = await asyncio.wait(tasks, timeout=remaining)

    # Cancel stragglers and build results indexed by slide_index.
    if pending:
        timed_out_indices = []
        for t in pending:
            t.cancel()
            timed_out_indices.append(t)
        # Let cancellations propagate.
        await asyncio.gather(*pending, return_exceptions=True)
        logger.warning(
            "Time budget exhausted: %d/%d images completed, %d cancelled",
            len(done),
            len(requests),
            len(pending),
        )
        if progress_cb is not None:
            await progress_cb(
                float(completed),
                total,
                f"Time budget — {len(done)}/{len(requests)} images, partial deck",
            )

    # Collect completed results and fill in fallbacks for cancelled tasks.
    results_by_index: dict[int, ImageResult] = {}
    for t in done:
        exc = t.exception()
        if exc is None:
            result = t.result()
            results_by_index[result.slide_index] = result
        # Exceptions should not happen (generate_image catches all), but guard.

    ordered: list[ImageResult] = []
    for req in requests:
        if req.slide_index in results_by_index:
            ordered.append(results_by_index[req.slide_index])
        else:
            ordered.append(
                ImageResult(
                    slide_index=req.slide_index,
                    image_bytes=None,
                    fallback=True,
                    error="cancelled (time budget exceeded)",
                )
            )

    return ordered
