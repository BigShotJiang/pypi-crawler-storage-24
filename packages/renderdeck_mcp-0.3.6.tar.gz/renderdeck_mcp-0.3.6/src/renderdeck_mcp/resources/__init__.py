from __future__ import annotations

"""resources subpackage — MCP resource handlers for serving reference files."""
