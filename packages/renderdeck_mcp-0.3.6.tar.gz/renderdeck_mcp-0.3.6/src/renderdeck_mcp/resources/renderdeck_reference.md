# RenderDeck Reference Document

> This document teaches everything needed to write a valid slide prompt file
> for RenderDeck. It is self-contained — no other documents are required.

## 1. Slide Prompt File Format

This section covers every rule enforced by the RenderDeck validator. A prompt file that follows these rules will pass validation with zero errors.

### 1.1 File Structure Overview

A slide prompt file is a single UTF-8 markdown file with four regions in fixed order:

1. **Front matter** — the first segment (before any `---` separator). Contains the H1 title and optional metadata blocks.
2. **Slide blocks** — one per segment, separated by `---`. Each describes one slide.
3. **Speaker Notes** — the final segment (after the last `---`). Contains delivery notes for each slide.

Regions are delimited by horizontal rule separators (`---`). The separator is three or more hyphens on a line by themselves. Separators delimit slide blocks and separate the front matter from slide content and slide content from speaker notes.

### 1.2 Front Matter

The front matter occupies the first segment (everything before the first `---` separator).

**H1 Title (required).** The file must contain exactly one H1 heading (`# Title`). This is the presentation title. Having zero H1 headings is an error. Having more than one H1 heading is an error. There must be a single H1 in the entire file.

**`## General` block (optional).** Provides audience, tone, context, and purpose information that applies to the whole deck. The General section content is prepended to every slide's image prompt when sent to the image generation API.

Example:

```
## General

Audience: Enterprise architects and technical leads.
Tone: Confident, data-driven, not salesy.
Purpose: Demonstrate platform capabilities with real-world examples.
```

**`## Global Rules` block (optional).** Contains visual and brand rules (colors, fonts, layout directives) that apply to every slide. The Global Rules content is prepended to every image prompt sent to the generation API. This is how you enforce brand consistency across all slides without repeating rules in each slide block.

**`## Subtitle` (optional).** A non-reserved H2 heading appearing before `## General` or `## Global Rules` is treated as the deck subtitle.

**Important:** Do not place `---` separators inside the front matter segment. The front matter is a single block.

### 1.3 Slide Blocks

Each slide occupies its own segment between `---` separators. The first line of each segment must be a slide heading.

**Slide heading format:** `## Slide NN — Title`

- `NN` must be exactly two zero-padded digits: 01, 02, 03, ... up to 99.
- Slide numbers start at 01, not 00. Slide 00 is rejected by the validator.
- The separator between the number and title is an em dash (`—`) or a regular hyphen (`-`).
- Each slide number must be unique across the file. Duplicate slide numbers produce a validation error.
- The title is plain text (no `Title:` prefix, no quotes).

**Slide body (image prompt).** Everything after the heading line within the segment is the image prompt for that slide. This text is sent verbatim (with General and Global Rules prepended) to the image generation API.

If a slide block contains only the heading and no body text, the slide has no image — it will be created with only a title and speaker notes.

**Slide count guidance.** Keep decks to 30 slides or fewer. Performance may degrade above 30 slides and the validator emits a warning.

### 1.4 Speaker Notes

Speaker notes can be provided in **either** of two formats:

**Format A — Inline (preferred).** Place a `### Speaker Notes` sub-heading inside each slide block, after the image prompt. The text below that heading becomes the slide's speaker notes.

**Format B — Consolidated.** Place a `## Speaker Notes` section as the last section in the file (after the final `---`). Each slide's notes are introduced by `### Slide NN — Title` where NN is the two-digit zero-padded slide number matching the corresponding slide block. Place all `### Slide NN` sub-sections consecutively with **no `---` separators between them**.

If both formats are present for the same slide, the consolidated section takes precedence.

Every `### Slide NN` entry in a consolidated Speaker Notes section must have a matching `## Slide NN` block in the slide section. Notes referencing a non-existent slide produce a warning (orphan speaker notes).

Speaker notes are optional. If absent, no error is produced — slides simply have no delivery notes.

**Required labels in each slide's notes:**

- **`**Say:**`** — The exact words the speaker should say. This is the core script content.
- **`**Time:**`** or **`**Timing:**`** — Delivery duration and pacing guidance.

**Optional labels:**

- **`**Transition:**`** — How to advance to the next slide.
- **`**Defensive note:**`** — How to handle audience objections.
- **`**Delivery note:**`** — How to present the material (emphasis, pauses, gestures).

### 1.5 Separator Rules

- The `---` separator (three or more hyphens on a line by themselves) delimits segments.
- Separators separate the front matter from slide blocks, separate individual slide blocks from each other, and separate the last slide block from the Speaker Notes section.
- Do not place `---` inside the front matter segment.
- Do not place `---` between `### Slide NN` entries inside the Speaker Notes segment. The parser tolerates it, but it is unnecessary — simply place each `### Slide NN` sub-section one after another with no separator.

### 1.6 Validation Rules Summary

| Rule | Description |
|------|-------------|
| V-1 | Exactly one H1 title required |
| V-2 | Slide headings must follow `## Slide NN — Title` with zero-padded two-digit numbers (01-99) |
| V-2b | Slide 00 is rejected — numbering starts at 01 |
| V-3 | No duplicate slide numbers allowed |
| V-4 | 30 slides or fewer recommended (warning above 30) |
| V-5 | Speaker note sub-sections must reference existing slides (no orphan notes) |
| V-6 | Speaker Notes section is optional (no error if absent) |

## 2. Brand Guidelines Template

Use the `## Global Rules` block in the front matter to establish brand consistency. Below is a reusable template covering the key categories. Replace the placeholder values with your brand's specifics.

### FORMAT

Declare the slide aspect ratio.

```
FORMAT: Wide-format 16:9.
```

### COLORS

Define primary, secondary, accent, and neutral palettes with hex codes. Specify how colors are used for backgrounds, text, and accents.

```
COLORS:
- Primary palette: Deep Purple #383689, Green #24ce84, Purple #8f64f9
- Secondary/accent: Blue #4080ff, Magenta #e812dd
- Neutrals: White #ffffff, Gray #f7f7f7
- Dark backgrounds: Deep Purple with gradient toward accent colors
- Light backgrounds: Neutral gray with subtle accent gradients at edges
- Color is information, not decoration
```

### TYPOGRAPHY

Specify headline and body fonts. Restrict to exactly two font families for consistency.

```
TYPOGRAPHY:
- Headlines: Poppins (bold, large)
- Body text: Inter (regular weight)
- No other fonts. Consistent sizes across all slides.
```

### LOGO

Define logo placement rules. Since AI generates flat raster images, leave space for manual logo overlay.

```
LOGO:
- Leave top-left corner empty for manual logo overlay
- Do not edit, distort, recolor, or recreate the logo
```

### PATTERNS

List approved decorative elements. Restrict usage to avoid visual noise.

```
PATTERNS:
- Approved: compact triangle arrangement, intersecting triangle lines
- Use sparingly as faint texture overlays only
```

### SLIDE FURNITURE

Define recurring elements that appear on every slide.

```
SLIDE FURNITURE — IDENTICAL ON EVERY SLIDE:
- Slide number: bottom-left, small light gray text, zero-padded ("01", "02")
- Footer: bottom-right, "Company 2026 | company.com"
- Logo position: top-left corner, kept empty for manual overlay
```

### PUNCTUATION

```
PUNCTUATION:
- No trailing periods on titles, labels, card titles, or short text
- Periods only on full sentences or rhetorical questions
- Em dashes for rhetorical pauses
```

### LAYOUT CONSISTENCY

```
LAYOUT CONSISTENCY:
- Cards use rounded corners and subtle border glow
- Visual vocabulary is grammar — elements treated identically across the deck
- Whitespace is deliberate: statement slides get generous space, dense slides get breathing room
```

## 3. Structure Instructions

### 3.1 Section Ordering

A valid prompt file follows this fixed order:

1. **H1 title** — exactly one, required
2. **`## General`** — optional, audience/tone/context/purpose metadata
3. **`## Global Rules`** — optional, brand and visual directives
4. **Slide blocks** — `## Slide 01 — Title` through `## Slide NN — Title`, each in its own `---`-delimited segment. Each slide block may contain an inline `### Speaker Notes` sub-section after the image prompt.
5. **`## Speaker Notes`** — optional, final segment (alternative to inline notes)

### 3.2 Placeholder Handling

Use `{variable_name}` syntax for values the presenter fills in at delivery time:

```
Large white bold Poppins text: **"{company_name} Platform Overview"**
```

Placeholders appear in image prompts and speaker notes. They are passed through as-is to the generated image (the image will contain the literal text including braces). Replace them with real values before final production if needed.

### 3.3 Required vs. Optional Sections

| Section | Required? | Notes |
|---------|-----------|-------|
| H1 title | Yes | Exactly one. Validation error if missing or duplicated. |
| `## General` | No | If present, prepended to every image prompt. |
| `## Global Rules` | No | If present, prepended to every image prompt. |
| Slide blocks | Yes | At least one slide expected. |
| `## Speaker Notes` | No | If absent, slides have no delivery notes. No error. |

### 3.4 How General and Global Rules Affect Prompts

When the image generation API receives a slide's prompt, it is constructed as:

```
{general_text}

GLOBAL VISUAL RULES (apply to all slides):
{global_rules_text}

SLIDE-SPECIFIC PROMPT:
{slide_image_prompt}
```

This means rules declared once in the front matter propagate automatically to every slide without repetition.

### 3.5 Separator Placement

Place a `---` separator:
- After the front matter (before the first slide block)
- Between each slide block
- After the last slide block (before Speaker Notes, if present)

Do not place separators inside the front matter. Do not place separators between `### Slide NN` entries inside the Speaker Notes section — the parser tolerates it, but it is unnecessary noise.

## 4. Presentation Craft

### 4.1 The 11-Point Image Prompt Checklist

Every slide image prompt should address these eleven elements in order. Not every element applies to every slide — skip what is irrelevant, but consider each one.

1. **Slide format declaration.** State the format: "Create a wide-format presentation slide (16:9)." This anchors the aspect ratio for the image generator.

2. **Background specification.** Define the background color, gradient direction, and atmospheric effects. Example: "Deep Purple (#383689) background with a subtle tint gradient shifting toward Green (#24ce84) light accents — soft atmospheric glow from the right side, no hard edges."

3. **Brand pattern usage.** Reference only approved patterns from your Global Rules. Use them as faint overlays that add depth without clutter. Example: "Approved brand pattern (compact triangle arrangement) as a faint texture overlay."

4. **Title text.** Specify font, size, weight, color, and position. Example: "Large bold white Poppins text top-center: 'Slide Title Here'."

5. **Subtitle or subtext.** Smaller supporting text below the title. Specify font, size, color, and position relative to the title. Example: "Below the title, a single line in smaller light gray Inter text: 'Supporting context line'."

6. **Main visual composition.** Describe the layout: containers, icons, diagrams, flowcharts, data elements. Be specific about spatial arrangement. Example: "Three rounded cards arranged horizontally in the center, each with a colored icon at top and two lines of text below."

7. **Data presentation.** For slides with statistics, metrics, or comparisons: specify card styles, number formatting, color coding, and spatial arrangement. Example: "Four stat cards in a row — large number in Green (#24ce84), label below in white Inter text."

8. **Accent and emphasis elements.** Glowing borders, color-coded highlights, connection lines, arrows. Example: "Soft Green (#24ce84) glowing border around the active card."

9. **Whitespace management.** Statement slides should have generous empty space. Dense content slides need breathing room between sections. Explicitly instruct: "Leave generous whitespace above and below the centered text."

10. **Slide furniture.** Slide number, footer, logo placeholder — these must appear on every slide per Global Rules. Example: "Slide number '03' in small light gray text, bottom-left. Footer bottom-right. Top-left corner empty for logo."

11. **Closing instruction.** State what NOT to include to keep the slide clean. Example: "Nothing else on the slide. No extra icons, no decorative borders, no text outside the defined areas."

### 4.2 Style Anchor

Establish visual consistency by writing one canonical slide description (typically the title slide or a representative content slide) with full detail. Subsequent slides can reference this anchor:

"Use the same background treatment, typography hierarchy, and slide furniture as Slide 01."

This reduces prompt length while maintaining consistency. The canonical slide sets the visual grammar; subsequent slides inherit it.

### 4.3 Speaker Notes as Stage Directions

Speaker notes are not a script dump. They are structured stage directions.

**`**Say:**`** contains the exact words. Write in natural spoken language, not bullet points. Include rhetorical questions, pauses (indicated by em dashes), and emphasis markers.

Example:
```
**Say:** Thanks for joining. Today we want to walk you through how the platform
handles migrations — specifically the cases where your existing tools hit their
limits. We will keep it practical: real constraints, real examples, and a live demo.
```

**`**Time:**`** or **`**Timing:**`** sets the pace. Include the target duration and a pacing note.

Example:
```
**Time:** ~30 seconds. Title slide — do not linger.
```

**`**Transition:**`** tells the speaker how to move to the next slide. This is the bridge between slides.

Example:
```
**Transition:** Advance immediately after the intro line.
```

**`**Defensive note:**`** prepares for objections.

Example:
```
**Defensive note:** If asked about pricing, defer to the dedicated pricing slide later in the deck.
```

**`**Delivery note:**`** provides presentation coaching.

Example:
```
**Delivery note:** Pause after the key statistic. Let the number land before continuing.
```

### 4.4 Slide Types and Their Craft

**Title slide.** Minimal content, atmospheric background, statement text. Generous whitespace. Sets the visual tone for the entire deck. Keep to a title and a single subtitle line.

**Content slide.** Visual composition with data elements, cards, icons, diagrams. Follow the 11-point checklist closely. Use containers and spatial grouping to organize information.

**Statement or rhetorical slide.** Centered text with generous whitespace. Dramatic pause moment. One key phrase or question, no supporting visuals. The whitespace itself is the design element.

**Data slide.** Statistics, comparisons, metrics. Use color-coded cards or containers. Large numbers with small labels. Let the data breathe — do not crowd.

**Closing slide.** Mirror the title slide style. Minimal content, atmospheric background, call to action or contact information.

## 5. Annotated Example

Below is a complete mini-deck demonstrating three slide types: a title slide, a content slide, and a statement slide. Annotations appear as HTML comments explaining format rules and craft decisions.

```markdown
# Cloud Migration Platform Overview
<!-- ANNOTATION: Exactly one H1 required. This is the presentation title (V-1). -->

## General
<!-- ANNOTATION: Optional General block — sets audience, tone, context for all slides. -->

Audience: Enterprise architects and IT directors evaluating migration tooling.
Tone: Confident, data-driven, practical. Problem-first, not product-first.
Purpose: Demonstrate platform value with concrete migration scenarios.

## Global Rules
<!-- ANNOTATION: Optional Global Rules block — these rules are prepended to every image prompt. -->

FORMAT: Wide-format 16:9.

COLORS:
- Primary: Dark Navy #1a1a3e, Teal #00b4d8, Soft Blue #90e0ef
- Accent: Coral #ff6b6b, Amber #ffd166
- Neutrals: White #ffffff, Light Gray #f0f0f5
- Dark backgrounds: Dark Navy with atmospheric teal glow
- Light backgrounds: Light Gray with subtle teal accents at edges

TYPOGRAPHY:
- Headlines: Poppins (bold)
- Body: Inter (regular)
- No other fonts

SLIDE FURNITURE — IDENTICAL ON EVERY SLIDE:
- Slide number: bottom-left, small light gray Inter text, zero-padded
- Footer: bottom-right, "MigrateCo 2026"
- Top-left corner empty for logo overlay

LAYOUT CONSISTENCY:
- Cards use rounded corners and subtle teal border glow
- Whitespace is deliberate
<!-- ANNOTATION: End of front matter. The --- separator below starts the slide blocks. -->

---

## Slide 01 — Cloud Migration Platform
<!-- ANNOTATION: Slide heading uses two-digit zero-padded number (01) and em dash separator (V-2). -->

Create a wide-format presentation slide (16:9) with a Dark Navy (#1a1a3e) background. Use a subtle atmospheric glow of Teal (#00b4d8) emanating from the lower-right corner — soft gradient, no hard edges.
<!-- ANNOTATION: Point 1 (format) and Point 2 (background) from the 11-point checklist. -->

Leave generous empty space in the upper half of the slide.
<!-- ANNOTATION: Point 9 — whitespace management for a title slide. -->

Large bold white Poppins text centered in the lower-center area: **"Cloud Migration Platform"**
<!-- ANNOTATION: Point 4 — title text specification. -->

Below that, a single line in Light Gray (#f0f0f5) Inter text: **"Zero Downtime. Full Fidelity. Any Scale."**
<!-- ANNOTATION: Point 5 — subtitle/subtext. -->

Nothing else on the slide body. Clean, confident, no clutter.
<!-- ANNOTATION: Point 11 — closing instruction stating what NOT to include. -->

Slide number "01" in small light gray Inter text, bottom-left corner. Top-left corner empty for logo overlay. Footer bottom-right: MigrateCo 2026
<!-- ANNOTATION: Point 10 — slide furniture matching Global Rules. -->

### Speaker Notes
<!-- ANNOTATION: Inline speaker notes — placed inside the slide block after the image prompt. -->

**Say:** Thank you for joining us today. I want to walk you through our migration platform — specifically how it handles the scenarios where traditional migration tools fall short. We will keep this practical: real constraints, real numbers, and a clear picture of what is possible.

**Time:** ~30 seconds. Title slide — set the tone and move on.

**Transition:** Advance after the opening line. Do not linger on the title.

---

## Slide 02 — Why Migrations Stall
<!-- ANNOTATION: Second slide — a content slide with data elements. Unique number 02 (V-3: no duplicates). -->

Create a wide-format presentation slide (16:9) with a Dark Navy (#1a1a3e) background. Subtle teal atmospheric glow from the right side.

Title top-center in large bold white Poppins text: **"Why Migrations Stall"**

Below the title, three rounded cards arranged horizontally in the center of the slide, each with a subtle Teal (#00b4d8) glowing border:
<!-- ANNOTATION: Point 6 — main visual composition with containers. Point 8 — accent elements (glow). -->

Card 1: A small Coral (#ff6b6b) warning icon at top. Below it, bold white text: **"Data Loss"** and smaller Light Gray text: **"67% of migrations lose custom field data"**

Card 2: A small Amber (#ffd166) clock icon at top. Below it, bold white text: **"Downtime"** and smaller Light Gray text: **"Average 14-day sync gap during cutover"**

Card 3: A small Teal (#00b4d8) link icon at top. Below it, bold white text: **"Broken Links"** and smaller Light Gray text: **"Cross-project references severed permanently"**
<!-- ANNOTATION: Point 7 — data presentation with color-coded statistics. -->

Slide number "02" in small light gray Inter text, bottom-left. Top-left empty for logo. Footer bottom-right: MigrateCo 2026

Nothing else on the slide. No extra decorative elements.

### Speaker Notes

**Say:** Before we show you the solution, let us look at the problem. These three issues come up in almost every enterprise migration we see. Data loss — sixty-seven percent of migrations lose custom field data because the migration tool cannot map complex field types. Downtime — the average sync gap during cutover is fourteen days where teams are working in two systems. And broken links — cross-project references get severed permanently because the tools treat each project as an island.

**Time:** ~90 seconds. Spend equal time on each card. Let the statistics land.

**Delivery note:** Point to each card as you discuss it. Pause after each statistic.

---

## Slide 03 — The Real Question
<!-- ANNOTATION: Third slide — a statement/rhetorical slide. Generous whitespace, dramatic pause. -->

Create a wide-format presentation slide (16:9) with a Dark Navy (#1a1a3e) background. Teal (#00b4d8) atmospheric glow centered behind the text — subtle halo effect.

Large bold white Poppins text centered vertically and horizontally: **"Can you migrate without stopping work?"**
<!-- ANNOTATION: Statement slide — one key phrase, centered, generous whitespace all around (Point 9). -->

Leave generous whitespace above and below the text. No subtitle, no cards, no icons, no additional visual elements.

Slide number "03" in small light gray Inter text, bottom-left. Top-left empty for logo. Footer bottom-right: MigrateCo 2026

### Speaker Notes

**Say:** So here is the real question. Can you migrate without stopping work? Can you keep both systems running in sync during the transition so that no team has to pause, no data gets lost, and no links break? That is what we built this platform to do.

**Time:** ~20 seconds. Rhetorical pause — let the question sit for two beats before answering.

**Transition:** Advance to the solution overview after the pause.
```
