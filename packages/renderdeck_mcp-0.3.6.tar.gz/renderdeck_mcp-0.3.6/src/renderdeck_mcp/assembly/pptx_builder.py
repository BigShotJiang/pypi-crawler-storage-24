"""PowerPoint deck builder.

Assembles generated slide images into a .pptx file using python-pptx.
Each slide receives a full-slide PNG background image and speaker notes on the
notes page. Slides without images get speaker notes only. Large PNGs (>5 MB)
are compressed to JPEG before embedding via Pillow.
"""

from __future__ import annotations

import io
import logging
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Literal

from PIL import Image
from pptx import Presentation
from pptx.util import Emu

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

IMAGE_COMPRESS_THRESHOLD: int = 5 * 1024 * 1024  # 5 MB

# Matches **bold**, *italic*, and ***bold-italic*** inline markdown.
# Order matters: bold-italic (***) must be matched before bold (**) and italic (*).
_MD_INLINE_RE = re.compile(
    r"(\*\*\*(.+?)\*\*\*"  # ***bold-italic***
    r"|\*\*(.+?)\*\*"  # **bold**
    r"|\*(.+?)\*)"  # *italic*
)

PAGE_SIZE_EMU: dict[str, dict[str, int]] = {
    "WIDE": {"width": 9144000, "height": 5143500},  # 16:9
    "STANDARD": {"width": 9144000, "height": 6858000},  # 4:3
}

# ---------------------------------------------------------------------------
# Data model
# ---------------------------------------------------------------------------


@dataclass
class SlideData:
    """Data for a single slide to be assembled into the .pptx."""

    slide_number: int
    title: str
    speaker_notes: str
    image_bytes: bytes | None


@dataclass
class DeckData:
    """Complete parsed deck ready for .pptx assembly."""

    title: str
    slides: list[SlideData]


# ---------------------------------------------------------------------------
# Image compression
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class _TextSpan:
    """A span of text with optional bold/italic formatting."""

    text: str
    bold: bool = False
    italic: bool = False


def _parse_markdown_line(line: str) -> list[_TextSpan]:
    """Parse a single line of markdown into formatted text spans.

    Recognises ``***bold-italic***``, ``**bold**``, and ``*italic*``.
    Everything else is returned as plain text spans.
    """
    spans: list[_TextSpan] = []
    pos = 0
    for m in _MD_INLINE_RE.finditer(line):
        # Plain text before this match
        if m.start() > pos:
            spans.append(_TextSpan(text=line[pos : m.start()]))
        if m.group(2) is not None:
            # ***bold-italic***
            spans.append(_TextSpan(text=m.group(2), bold=True, italic=True))
        elif m.group(3) is not None:
            # **bold**
            spans.append(_TextSpan(text=m.group(3), bold=True))
        elif m.group(4) is not None:
            # *italic*
            spans.append(_TextSpan(text=m.group(4), italic=True))
        pos = m.end()
    # Trailing plain text
    if pos < len(line):
        spans.append(_TextSpan(text=line[pos:]))
    if not spans:
        spans.append(_TextSpan(text=""))
    return spans


_SAY_LABEL_RE = re.compile(r"^\*\*[Ss]ay:\*\*\s*(.*)")

_NOTES_LABEL_RE = re.compile(r"^\*\*.+?:\*\*")

_SEPARATOR_LINE_RE = re.compile(r"^-{3,}\s*$")


def extract_narration(notes: str) -> str:
    """Extract narration text from speaker notes.

    Finds all lines matching ``**Say:** <text>`` (case-insensitive label)
    and returns the concatenated text portions joined by newlines.
    Lines where **Say:** has no trailing text are skipped.

    Args:
        notes: Raw speaker notes string (may contain multiple lines).

    Returns:
        Joined narration text, or empty string if no Say lines found.
    """
    parts: list[str] = []
    for line in notes.split("\n"):
        m = _SAY_LABEL_RE.match(line.strip())
        if m:
            text = m.group(1).strip()
            if text:
                parts.append(text)
    return "\n".join(parts)


def _set_rich_notes(notes_text_frame: Any, markdown_text: str) -> None:
    """Populate a notes text frame with markdown-formatted rich text.

    Formats speaker notes for at-a-glance readability during presentation:
    - Bold labels (**Say:**, **Time:**, etc.) get 12pt with space above
    - Body text gets 10pt
    - Separator lines (---) and blank lines are stripped
    """
    from pptx.util import Pt

    tf = notes_text_frame

    # Clean up: strip trailing --- artifacts and collapse excessive blank lines
    lines = markdown_text.split("\n")
    cleaned: list[str] = []
    for line in lines:
        if _SEPARATOR_LINE_RE.match(line.strip()):
            continue
        cleaned.append(line)

    # Strip trailing blank lines
    while cleaned and not cleaned[-1].strip():
        cleaned.pop()

    first_para = True
    for line in cleaned:
        if first_para:
            para = tf.paragraphs[0]
            para.clear()
            first_para = False
        else:
            para = tf.add_paragraph()

        # Empty line → blank paragraph for visual spacing
        if not line.strip():
            run = para.add_run()
            run.text = ""
            run.font.size = Pt(6)
            continue

        is_label = bool(_NOTES_LABEL_RE.match(line))

        # Add space above label paragraphs (except the first)
        if is_label:
            para.space_before = Pt(6)

        spans = _parse_markdown_line(line)
        for span in spans:
            run = para.add_run()
            run.text = span.text
            run.font.size = Pt(12) if (is_label and span.bold) else Pt(10)
            run.font.bold = span.bold
            run.font.italic = span.italic


def compress_png(
    png_bytes: bytes,
    max_bytes: int = IMAGE_COMPRESS_THRESHOLD,
) -> bytes:
    """Return png_bytes unchanged if under max_bytes; otherwise JPEG-compress it.

    Args:
        png_bytes: Raw image bytes (PNG expected, but any Pillow-readable format works).
        max_bytes: Byte threshold above which JPEG compression is applied.

    Returns:
        Original bytes if under threshold, otherwise JPEG bytes at quality=85.
    """
    if len(png_bytes) <= max_bytes:
        return png_bytes
    logger.debug("compress_png: %d bytes exceeds threshold, converting to JPEG", len(png_bytes))
    img = Image.open(io.BytesIO(png_bytes))
    buf = io.BytesIO()
    img.convert("RGB").save(buf, format="JPEG", quality=85)
    return buf.getvalue()


# ---------------------------------------------------------------------------
# Main builder
# ---------------------------------------------------------------------------


NotesMode = Literal["full", "narration"]


def build_pptx(
    deck: DeckData,
    output_path: str | Path,
    aspect_ratio: Literal["WIDE", "STANDARD"] = "WIDE",
    notes_mode: NotesMode = "full",
) -> Path:
    """Assemble a .pptx presentation from DeckData and write it to output_path.

    Args:
        deck: The parsed deck data containing slides with images and notes.
        output_path: Destination path for the .pptx file. Parent directories
            are created automatically if they do not exist.
        aspect_ratio: Slide dimensions. "WIDE" = 16:9, "STANDARD" = 4:3.

    Returns:
        Resolved Path to the written .pptx file.

    Raises:
        KeyError: If aspect_ratio is not "WIDE" or "STANDARD".
        OSError: If the file cannot be written.
    """
    out = Path(output_path)
    out.parent.mkdir(parents=True, exist_ok=True)

    dims = PAGE_SIZE_EMU[aspect_ratio]
    prs = Presentation()
    prs.slide_width = Emu(dims["width"])
    prs.slide_height = Emu(dims["height"])

    blank_layout = prs.slide_layouts[6]  # index 6 = blank layout

    logger.info(
        "Building .pptx: %d slides, aspect_ratio=%s",
        len(deck.slides),
        aspect_ratio,
    )

    for slide_data in deck.slides:
        slide = prs.slides.add_slide(blank_layout)

        if slide_data.image_bytes is not None:
            compressed = compress_png(slide_data.image_bytes)
            logger.debug(
                "Slide %d: adding picture (%d bytes)",
                slide_data.slide_number,
                len(compressed),
            )
            slide.shapes.add_picture(
                io.BytesIO(compressed),
                0,
                0,
                prs.slide_width,
                prs.slide_height,
            )
        else:
            logger.debug("Slide %d: no image, notes-only slide", slide_data.slide_number)

        notes_slide = slide.notes_slide
        notes_text = (
            extract_narration(slide_data.speaker_notes)
            if notes_mode == "narration"
            else slide_data.speaker_notes
        )
        _set_rich_notes(notes_slide.notes_text_frame, notes_text)

    prs.save(str(out))
    logger.info("Saved .pptx to %s", out)
    return out
