"""assembly subpackage -- PowerPoint (.pptx) deck assembly."""

from __future__ import annotations

from renderdeck_mcp.assembly.pptx_builder import (
    IMAGE_COMPRESS_THRESHOLD,
    DeckData,
    SlideData,
    build_pptx,
    compress_png,
)

__all__ = [
    "IMAGE_COMPRESS_THRESHOLD",
    "DeckData",
    "SlideData",
    "build_pptx",
    "compress_png",
]
