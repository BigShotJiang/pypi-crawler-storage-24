"""Configuration management for renderdeck_mcp.

Manages ``~/.renderdeck/config.json`` with Fernet-encrypted Gemini API key
storage and runtime settings.  Supports ``GOOGLE_GEMINI_API_KEY`` env var
override.
"""

from __future__ import annotations

import json
import logging
import os
import stat
from pathlib import Path
from typing import Any

from cryptography.fernet import Fernet, InvalidToken

logger = logging.getLogger(__name__)

CONFIG_DIR = Path.home() / ".renderdeck"
CONFIG_FILE = CONFIG_DIR / "config.json"
_KEY_FILE = CONFIG_DIR / ".fernet_key"

# Default settings
DEFAULTS: dict[str, Any] = {
    "gemini_image_model": "gemini-2.0-flash-exp",
    "aspect_ratio": "WIDE",
    "default_output_dir": str(Path.home() / "Documents" / "RenderDeck"),
    "gemini_max_retries": 3,
    "max_concurrent_images": 5,
    "verbose": False,
}


def _ensure_config_dir() -> None:
    """Create ~/.renderdeck/ with 700 permissions if it doesn't exist."""
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    CONFIG_DIR.chmod(stat.S_IRWXU)


def _get_or_create_fernet_key() -> bytes:
    """Load or generate the Fernet encryption key."""
    _ensure_config_dir()
    if _KEY_FILE.is_file():
        return _KEY_FILE.read_bytes()
    key = Fernet.generate_key()
    _KEY_FILE.write_bytes(key)
    _KEY_FILE.chmod(stat.S_IRUSR | stat.S_IWUSR)
    return key


def _fernet() -> Fernet:
    return Fernet(_get_or_create_fernet_key())


def _read_config() -> dict[str, Any]:
    """Read config.json, returning empty dict on missing/corrupt file."""
    if not CONFIG_FILE.is_file():
        return {}
    try:
        return dict(json.loads(CONFIG_FILE.read_text(encoding="utf-8")))
    except (json.JSONDecodeError, OSError):
        logger.warning("Corrupted config.json, treating as empty")
        return {}


def _write_config(data: dict[str, Any]) -> None:
    """Atomically write config.json with 600 permissions."""
    _ensure_config_dir()
    tmp = CONFIG_FILE.with_suffix(".tmp")
    tmp.write_text(json.dumps(data, indent=2), encoding="utf-8")
    tmp.chmod(stat.S_IRUSR | stat.S_IWUSR)
    tmp.rename(CONFIG_FILE)


def encrypt_api_key(api_key: str) -> str:
    """Encrypt an API key with Fernet, returning a base64 token string."""
    return _fernet().encrypt(api_key.encode()).decode()


def decrypt_api_key(encrypted: str) -> str | None:
    """Decrypt an API key. Returns None if decryption fails."""
    try:
        return _fernet().decrypt(encrypted.encode()).decode()
    except (InvalidToken, Exception):
        logger.warning("Failed to decrypt API key")
        return None


def get_api_key() -> str | None:
    """Resolve the Gemini API key: env var takes priority over stored key."""
    env_key = os.environ.get("GOOGLE_GEMINI_API_KEY")
    if env_key:
        return env_key

    config = _read_config()
    encrypted = config.get("gemini_api_key_encrypted")
    if encrypted:
        return decrypt_api_key(encrypted)

    return None


def store_api_key(api_key: str) -> None:
    """Encrypt and store an API key in config.json."""
    config = _read_config()
    config["gemini_api_key_encrypted"] = encrypt_api_key(api_key)
    _write_config(config)


def get_setting(key: str) -> Any:
    """Get a config setting, falling back to defaults."""
    config = _read_config()
    settings = config.get("settings", {})
    return settings.get(key, DEFAULTS.get(key))


def update_settings(updates: dict[str, Any]) -> dict[str, Any]:
    """Update settings in config.json. Returns the full settings dict."""
    config = _read_config()
    settings = config.setdefault("settings", {})
    for k, v in updates.items():
        if v is not None:
            settings[k] = v
    _write_config(config)
    # Return merged with defaults
    merged = dict(DEFAULTS)
    merged.update(settings)
    return merged


def get_setup_status() -> dict[str, Any]:
    """Return current setup status for the get_setup_status MCP tool."""
    api_key = get_api_key()
    config = _read_config()
    settings = config.get("settings", {})

    merged = dict(DEFAULTS)
    merged.update(settings)

    issues: list[str] = []
    if not api_key:
        issues.append(
            "Gemini API key not configured. "
            "Use setup_gemini_key tool or set GOOGLE_GEMINI_API_KEY env var."
        )

    return {
        "gemini_key_configured": api_key is not None,
        "gemini_model": merged.get("gemini_image_model"),
        "aspect_ratio": merged.get("aspect_ratio"),
        "default_output_dir": merged.get("default_output_dir"),
        "ready": len(issues) == 0,
        "issues": issues,
    }
