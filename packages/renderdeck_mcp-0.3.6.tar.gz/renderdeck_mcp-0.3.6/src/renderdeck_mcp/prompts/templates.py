"""MCP prompt templates for RenderDeck guided workflows.

Registers ``create_deck`` and ``check_and_fix`` prompts with the FastMCP server.
"""

from __future__ import annotations

from renderdeck_mcp.server import mcp

_CREATE_DECK_TEMPLATE = """\
You are creating a RenderDeck presentation. Follow these steps:

1. Read the reference document from the renderdeck://reference resource.
   This contains everything you need to write a valid slide prompt file.

2. Based on the user's topic and requirements, write a complete slide prompt file
   following the format specification in the reference document. Include:
   - An H1 title
   - A General section with audience and context
   - Global Rules with brand guidelines
   - Slide blocks (## Slide NN — Title) with image prompts
   - Speaker notes for each slide using inline ### Speaker Notes within each slide block

3. Validate your prompt file using the validate_prompt_file tool.
   Fix any errors until validation passes with zero errors.

4. Once valid, generate the presentation using the generate_deck tool.

5. Return the output file path to the user.

Topic: {topic}
"""

_CHECK_AND_FIX_TEMPLATE = """\
You are validating and fixing a RenderDeck slide prompt file.

1. Run validate_prompt_file on the provided content.

2. If validation passes (valid: true, no errors), report success
   and summarise the deck (slide count, titles).

3. If validation fails, for each error:
   - Quote the error message and line number
   - Explain what is wrong
   - Suggest the specific fix needed

4. Apply all fixes to the content and re-validate.
   Repeat until validation passes with zero errors.

5. Return the corrected content to the user.

Content to validate:
{content}
"""


@mcp.prompt(
    name="create_deck",
    description="Guided workflow: read reference, write prompt file, validate, and generate",
)
def create_deck(topic: str) -> list[dict[str, str]]:
    """Create a presentation on the given topic."""
    return [{"role": "user", "content": _CREATE_DECK_TEMPLATE.format(topic=topic)}]


@mcp.prompt(
    name="check_and_fix",
    description="Validate a slide prompt file and provide error-by-error fix suggestions",
)
def check_and_fix(content: str) -> list[dict[str, str]]:
    """Validate and fix a slide prompt file."""
    return [{"role": "user", "content": _CHECK_AND_FIX_TEMPLATE.format(content=content)}]
