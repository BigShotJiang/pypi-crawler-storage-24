"""Prompts subpackage — MCP prompt templates for guided workflows."""

from __future__ import annotations
