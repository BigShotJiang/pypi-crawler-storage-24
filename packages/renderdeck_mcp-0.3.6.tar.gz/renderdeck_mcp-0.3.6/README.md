# RenderDeck

**Markdown to Google Slides via Gemini + Google Slides API.**  
A single Python script that parses a structured presentation markdown file, generates slide images using the Gemini image API (Nano Banana / Nano Banana Pro), and assembles a Google Slides presentation.

- **Runtime:** Python 3.12+
- **Invocation:** `python renderdeck.py <presentation.md>`
- **Output:** Google Slides presentation URL printed to stdout

## Setup

### 1. Google Cloud Console

1. Create a project in [Google Cloud Console](https://console.cloud.google.com/).
2. Enable **Google Slides API** and **Google Drive API** (APIs & Services → Enable APIs).
3. Create **OAuth 2.0 credentials** (APIs & Services → Credentials → Create Credentials → OAuth client ID).
   - Application type: **Desktop application**.
   - Download the JSON credentials file and save it somewhere safe (e.g. `credentials.json` in this directory).
4. Set `GOOGLE_SLIDES_CREDENTIALS_FILE` in `.env` to the path of that file (see below).

### 2. Environment and dependencies

```bash
pip install -r requirements.txt
cp .env.example .env
# Edit .env and set required variables.
```

This project uses the **`google-genai`** Python package for the Gemini image API (the legacy `google-generativeai` package is deprecated and no longer supported).

**Required in `.env`:**

| Variable | Description |
|----------|-------------|
| `GOOGLE_GEMINI_API_KEY` | API key for Gemini (get from [Google AI Studio](https://aistudio.google.com/apikey)). If missing, image generation is skipped with a warning. |
| `GOOGLE_SLIDES_CREDENTIALS_FILE` | Path to the OAuth 2.0 client credentials JSON (e.g. `./credentials.json`). Script exits if this file is missing. |
| `GOOGLE_SLIDES_TOKEN_FILE` | Path where the OAuth token will be stored after first authorization (e.g. `./token.json`). Created automatically on first run. |

**Optional (with defaults):**

- `GEMINI_IMAGE_MODEL` — `gemini-2.5-flash-image` (Nano Banana) or `gemini-3-pro-image-preview` (Nano Banana Pro).
- `IMAGE_TEMP_DIR` — `./.renderdeck_tmp` (base directory for cached slide images; one subdirectory per deck, named after the .md file).
- `SLIDES_ASPECT_RATIO` — `WIDE` (16:9) or `STANDARD` (4:3).
- `GEMINI_MAX_RETRIES`, `SLIDES_MAX_RETRIES` — retry counts for API calls.
- `VERBOSE` — `false`; set to `true` for per-step progress on stderr (or use `-v` on the command line).

### 3. First run (OAuth)

The first time you run the script, it will open a browser for you to sign in with your Google account and authorize access to Slides and Drive (scopes: `presentations`, `drive.file`). The token is saved to `GOOGLE_SLIDES_TOKEN_FILE` and reused on later runs, so you can run headless after that.

## Usage

```bash
python renderdeck.py presentation.md
```

**Options:**

- **`-v` / `--verbose`** — Print progress and cost estimate to stderr (overrides the `VERBOSE` env var).
- **`--test`** — Test run: process at most **2 slides** only (useful to validate setup and API calls without building the full deck).
- **`--max-slides N`** — Process at most **N** slides (e.g. `--max-slides 1` for a single-slide run).
- **`--pro`** — Use Nano Banana Pro (`gemini-3-pro-image-preview`) for image generation (overrides `GEMINI_IMAGE_MODEL` for that run).
- **`-r` / `--regenerate-slide N[,N,...]`** — Force regeneration of the given slide(s) even if cache would reuse (e.g. `-r 3,5` or `-r 03`).
- **`--say-only`** — Write only the **Say:** part of each slide’s speaker notes into the deck (useful for video generation, e.g. [Pictory](https://pictory.ai)).
- **`--drive-folder ID_OR_URL`** — Google Drive folder where the presentation will be placed. Use a folder ID or a Drive folder URL (e.g. `https://drive.google.com/drive/folders/1ABC...`). Default: presentation is created in your Drive root.

Examples:

```bash
python renderdeck.py deck.md              # Full run
python renderdeck.py -v deck.md          # Verbose output
python renderdeck.py --test deck.md      # First 2 slides only
python renderdeck.py --max-slides 1 deck.md   # First slide only
```

On success, the script prints a single line to stdout: the presentation URL, e.g.  
`https://docs.google.com/presentation/d/PRESENTATION_ID/edit`

With `VERBOSE=true` or `-v`, additional progress and a cost estimate are printed to stderr.

## Markdown format

The input file must follow this structure:

1. **H1** — Presentation title (first line).
2. **H2** — Optional subtitle (directly under H1).
3. **General** — Optional. Block introduced by `## General`, ending at the next `##` or the first `---`. Describes presentation context (audience, theme, tone); prepended to every Nano Banana prompt so all slides stay on-message.
4. **Global Rules** — Block introduced by `## Global Rules`, ending at the next `##` or the first `---`. Prepended to every image prompt.
5. **Slide blocks** — Each between `---` separators, starting with `## Slide NN — Title` (NN = two-digit number). The rest of the block is the image prompt for that slide.
6. **Speaker Notes** — A final section `## Speaker Notes` with one `### Slide NN — Title` per slide; the body is used as speaker notes for that slide number.

### Example

```markdown
# My Deck Title
## Optional Subtitle

## General
This deck is for the Q4 product launch. Audience: executives. Keep tone professional and visuals on-brand.

## Global Rules
Use a clean, minimal style. Sans-serif fonts only.

---

## Slide 01 — Introduction
Create a wide-format slide with the title "Introduction" and a short subtitle "Welcome to the session". Use a soft blue gradient background.

---

## Slide 02 — Key Points
Create a slide titled "Key Points" with three bullet placeholders. Corporate style, light background.

---

## Speaker Notes

### Slide 01 — Introduction
**Time:** ~30 seconds.
**Say:** Welcome everyone. Today we'll cover the key points and next steps.

### Slide 02 — Key Points
**Time:** ~60 seconds.
**Say:** The three main takeaways are cost, quality, and speed.
```

- If a slide block has only the H2 heading and no body, that slide has no image (title and notes only).
- Slide numbers in Speaker Notes are matched by NN, not by title.

## Cost guidance

- **Nano Banana** (`gemini-2.5-flash-image`): about **$0.039 per image** generated.
- **Nano Banana Pro** (`gemini-3-pro-image-preview`): about **$0.12 per image**.
- Images **reused from the temp directory** (e.g. after a retry) are not regenerated and are not billed again.
- With `VERBOSE=true`, the script prints an estimated image cost to stderr. Actual billing depends on Google’s pricing and usage.

## Temp images and cleanup

- Slide images are written to `IMAGE_TEMP_DIR` (default `./.renderdeck_tmp`) in a **per-deck subdirectory** named after the markdown file (e.g. `./.renderdeck_tmp/my_presentation/slide_01.png`), so multiple decks do not share cached images.
- The script keeps a **cache manifest** (`cache_manifest.json`) in each deck’s cache dir. It records which version of the slide prompt file (and options) each image was built from. **Reuse is content- and option-aware:** a cached image is reused only when the slide’s description (and General/Global Rules, and options like `--pro` or aspect ratio) have not changed.
- **When slides are regenerated:** If you edit a single slide’s image prompt, only that slide is regenerated; others are reused. If you change the **General** or **Global Rules** block, all slides with image prompts are regenerated. If you change options (e.g. `--pro` or `SLIDES_ASPECT_RATIO`), all slide images are regenerated for the new options. You can still force specific slides with **`-r` / `--regenerate-slide`** (e.g. `-r 3,5`).
- The script **does not delete** the cache directory. You are responsible for cleaning it up when you no longer need cached images (e.g. `rm -rf .renderdeck_tmp`).

## Errors

- All error messages go to **stderr** in the form `[ERROR] <phase>: <message>`.
- On unrecoverable errors the script exits with code **1**.
- If the Google Slides export fails partway through, the **partial presentation is deleted** and temp images are left in place for reuse on retry.

## MCP Server

RenderDeck is also available as an MCP (Model Context Protocol) server, allowing LLM clients to generate presentations directly.

### Installation

```bash
pip install renderdeck-mcp
# or with uvx (recommended):
uvx renderdeck-mcp serve
```

### Client Configuration

#### Claude Desktop

Add to `~/Library/Application Support/Claude/claude_desktop_config.json`:

```json
{
  "mcpServers": {
    "renderdeck": {
      "command": "uvx",
      "args": ["renderdeck-mcp", "serve"],
      "env": {
        "GOOGLE_GEMINI_API_KEY": "your-api-key-here"
      }
    }
  }
}
```

#### Claude Code

Add to `.claude/settings.json` or `~/.claude/settings.json`:

```json
{
  "mcpServers": {
    "renderdeck": {
      "command": "uvx",
      "args": ["renderdeck-mcp", "serve"],
      "env": {
        "GOOGLE_GEMINI_API_KEY": "your-api-key-here"
      }
    }
  }
}
```

#### Cursor

Add to `.cursor/mcp.json`:

```json
{
  "mcpServers": {
    "renderdeck": {
      "command": "uvx",
      "args": ["renderdeck-mcp", "serve"],
      "env": {
        "GOOGLE_GEMINI_API_KEY": "your-api-key-here"
      }
    }
  }
}
```

### MCP Tools

| Tool | Description |
|------|-------------|
| `generate_deck` | Generate a .pptx from a slide prompt file |
| `validate_prompt_file` | Validate a prompt file (dry-run, no API key needed) |
| `regenerate_slide` | Regenerate specific slides (bypasses cache) |
| `setup_gemini_key` | Store Gemini API key securely (Fernet-encrypted) |
| `get_setup_status` | Check configuration readiness |
| `update_settings` | Update model, aspect ratio, and other settings |
| `generate_video` | Convert a presentation to a narrated MP4 video |
| `list_voices` | List available TTS voices for video narration (see `renderdeck://voice-samples` resource) |

### MCP Resources

| Resource | Description |
|----------|-------------|
| `renderdeck://reference` | Complete reference document for writing slide prompt files |
| `renderdeck://voice-samples` | Interactive page listing all supported TTS voices with audio previews |

### MCP Prompts

| Prompt | Description |
|--------|-------------|
| `create_deck` | Guided workflow: read reference, write prompt, validate, generate |
| `check_and_fix` | Validate a prompt file and get error-by-error fix suggestions |

### Example Workflow

1. The LLM reads `renderdeck://reference` to learn the prompt file format
2. User describes the presentation topic
3. LLM writes a slide prompt file following the reference
4. `validate_prompt_file` checks for errors
5. `generate_deck` produces the .pptx with Gemini-generated images
6. User reviews and iterates with `regenerate_slide` for specific slides

## Specification

See `RenderDeck_Script_Spec_v1.0.md` for the full behaviour, parsing rules, and configuration contract.
