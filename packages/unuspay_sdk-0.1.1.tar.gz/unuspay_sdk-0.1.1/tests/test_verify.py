import pytest
import hmac
import hashlib
import time
from unuspay_sdk import Webhook, WebhookConfig, WebhookVerificationError

TEST_SECRET = "whsec_testsecret123456789012345678901234"


def create_signature(payload: str, timestamp: int, secret: str) -> str:
    signed_payload = f"{timestamp}.{payload}"
    return hmac.new(
        secret.encode("utf-8"),
        signed_payload.encode("utf-8"),
        hashlib.sha256,
    ).hexdigest()


class TestWebhookClass:
    """Tests for the class-based API."""
    
    def test_verifies_valid_signature(self):
        payload = '{"type":"test","data":{"message":"hello"}}'
        timestamp = int(time.time())
        signature = create_signature(payload, timestamp, TEST_SECRET)
        
        webhook = Webhook(secret=TEST_SECRET)
        event = webhook.verify(
            payload=payload,
            signature=signature,
            timestamp=timestamp,
        )
        
        assert event == {"type": "test", "data": {"message": "hello"}}
    
    def test_throws_on_invalid_signature(self):
        payload = '{"type":"test"}'
        timestamp = int(time.time())
        
        webhook = Webhook(secret=TEST_SECRET)
        
        with pytest.raises(WebhookVerificationError) as exc_info:
            webhook.verify(
                payload=payload,
                signature="invalid_signature",
                timestamp=timestamp,
            )
        
        assert exc_info.value.code == "INVALID_SIGNATURE"
    
    def test_throws_on_expired_timestamp(self):
        payload = '{"type":"test"}'
        timestamp = int(time.time()) - 600  # 10 minutes ago
        signature = create_signature(payload, timestamp, TEST_SECRET)
        
        webhook = Webhook(secret=TEST_SECRET)
        
        with pytest.raises(WebhookVerificationError) as exc_info:
            webhook.verify(
                payload=payload,
                signature=signature,
                timestamp=timestamp,
            )
        
        assert exc_info.value.code == "TIMESTAMP_EXPIRED"
    
    def test_throws_on_empty_payload(self):
        timestamp = int(time.time())
        
        webhook = Webhook(secret=TEST_SECRET)
        
        with pytest.raises(WebhookVerificationError) as exc_info:
            webhook.verify(
                payload="",
                signature="sig",
                timestamp=timestamp,
            )
        
        assert exc_info.value.code == "MISSING_HEADERS"
    
    def test_throws_on_empty_signature(self):
        payload = '{"type":"test"}'
        timestamp = int(time.time())
        
        webhook = Webhook(secret=TEST_SECRET)
        
        with pytest.raises(WebhookVerificationError) as exc_info:
            webhook.verify(
                payload=payload,
                signature="",
                timestamp=timestamp,
            )
        
        assert exc_info.value.code == "MISSING_HEADERS"
    
    def test_accepts_string_timestamp(self):
        payload = '{"type":"test"}'
        timestamp = int(time.time())
        signature = create_signature(payload, timestamp, TEST_SECRET)
        
        webhook = Webhook(secret=TEST_SECRET)
        
        event = webhook.verify(
            payload=payload,
            signature=signature,
            timestamp=str(timestamp),
        )
        
        assert event == {"type": "test"}
    
    def test_accepts_bytes_payload(self):
        payload = '{"type":"test"}'
        timestamp = int(time.time())
        signature = create_signature(payload, timestamp, TEST_SECRET)
        
        webhook = Webhook(secret=TEST_SECRET)
        
        event = webhook.verify(
            payload=payload.encode("utf-8"),
            signature=signature,
            timestamp=timestamp,
        )
        
        assert event == {"type": "test"}
    
    def test_custom_config_max_age_seconds(self):
        payload = '{"type":"test"}'
        timestamp = int(time.time()) - 400  # 6.6 minutes ago
        signature = create_signature(payload, timestamp, TEST_SECRET)
        
        # Default config should fail
        webhook_default = Webhook(secret=TEST_SECRET)
        
        with pytest.raises(WebhookVerificationError):
            webhook_default.verify(
                payload=payload,
                signature=signature,
                timestamp=timestamp,
            )
        
        # Custom config should pass
        webhook_custom = Webhook(
            secret=TEST_SECRET,
            config=WebhookConfig(max_age_seconds=600),
        )
        
        event = webhook_custom.verify(
            payload=payload,
            signature=signature,
            timestamp=timestamp,
        )
        assert event == {"type": "test"}
    
    def test_throws_on_invalid_config_max_age(self):
        """Test that max_age_seconds must be positive."""
        with pytest.raises(ValueError):
            WebhookConfig(max_age_seconds=0)
        
        with pytest.raises(ValueError):
            WebhookConfig(max_age_seconds=-100)
    
    def test_throws_on_empty_secret(self):
        """Test that empty secret is rejected at construction."""
        with pytest.raises(WebhookVerificationError) as exc_info:
            Webhook(secret="")
        
        assert exc_info.value.code == "MISSING_HEADERS"
    
    def test_reusable_instance(self):
        """Test that Webhook instance can be reused for multiple verifications."""
        webhook = Webhook(secret=TEST_SECRET)
        
        # First verification
        payload1 = '{"type":"test1"}'
        timestamp1 = int(time.time())
        signature1 = create_signature(payload1, timestamp1, TEST_SECRET)
        
        event1 = webhook.verify(
            payload=payload1,
            signature=signature1,
            timestamp=timestamp1,
        )
        assert event1 == {"type": "test1"}
        
        # Second verification with different payload
        payload2 = '{"type":"test2"}'
        timestamp2 = int(time.time())
        signature2 = create_signature(payload2, timestamp2, TEST_SECRET)
        
        event2 = webhook.verify(
            payload=payload2,
            signature=signature2,
            timestamp=timestamp2,
        )
        assert event2 == {"type": "test2"}
    
    def test_invalid_timestamp_format(self):
        """Test that invalid timestamp format is rejected."""
        webhook = Webhook(secret=TEST_SECRET)
        
        with pytest.raises(WebhookVerificationError) as exc_info:
            webhook.verify(
                payload='{"type":"test"}',
                signature="sig",
                timestamp="not_a_number",
            )
        
        assert exc_info.value.code == "MISSING_HEADERS"
    
    def test_invalid_json_payload(self):
        """Test that invalid JSON in payload is rejected after signature check."""
        payload = "not valid json"
        timestamp = int(time.time())
        signature = create_signature(payload, timestamp, TEST_SECRET)
        
        webhook = Webhook(secret=TEST_SECRET)
        
        with pytest.raises(WebhookVerificationError) as exc_info:
            webhook.verify(
                payload=payload,
                signature=signature,
                timestamp=timestamp,
            )
        
        assert exc_info.value.code == "INVALID_SIGNATURE"
