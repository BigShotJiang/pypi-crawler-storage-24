"""
Webhook verification class with Pydantic validation.

This module provides a class-based API for webhook signature verification,
matching the TypeScript SDK pattern.
"""

import hmac
import hashlib
import json
import time
from typing import Optional, Union, Any

from pydantic import BaseModel, Field, ValidationError


class WebhookConfig(BaseModel):
    """
    Configuration options for Webhook class.
    
    Attributes:
        max_age_seconds: Max age in seconds for timestamp validation (default: 300)
    """
    max_age_seconds: int = Field(default=300, gt=0, description="Max age in seconds for timestamp validation")


class _SecretModel(BaseModel):
    """Pydantic model for secret validation."""
    secret: str = Field(..., min_length=1, description="Secret must be a non-empty string")


class _PayloadModel(BaseModel):
    """Pydantic model for payload validation."""
    payload: str = Field(..., min_length=1, description="Payload must be a non-empty string")


class _SignatureModel(BaseModel):
    """Pydantic model for signature validation."""
    signature: str = Field(..., min_length=1, description="Signature must be a non-empty string")


class _TimestampModel(BaseModel):
    """Pydantic model for timestamp validation."""
    timestamp: Union[str, int] = Field(..., description="Timestamp must be a string or integer")


class Webhook:
    """
    Webhook verification class with Pydantic validation.
    
    This class provides a reusable webhook verifier with configurable options.
    It validates all inputs using Pydantic before performing cryptographic verification.
    
    Example:
        >>> from unuspay_sdk import Webhook
        >>> 
        >>> webhook = Webhook(os.environ['WEBHOOK_SECRET'])
        >>> 
        >>> # In your webhook handler
        >>> event = webhook.verify(
        ...     payload=request.body,
        ...     signature=request.headers['X-Webhook-Signature'],
        ...     timestamp=request.headers['X-Webhook-Timestamp']
        ... )
        >>> print(event['type'])  # e.g., 'order.completed'
    """
    
    def __init__(self, secret: str, config: Optional[WebhookConfig] = None):
        """
        Create a new Webhook verifier.
        
        Args:
            secret: Your webhook secret (starts with whsec_)
            config: Optional configuration
            
        Raises:
            WebhookVerificationError: If secret is invalid
        """
        # Import here to avoid circular dependency
        from . import WebhookVerificationError
        
        # Validate secret at construction time using Pydantic
        try:
            secret_model = _SecretModel(secret=secret)
        except ValidationError as e:
            raise WebhookVerificationError(
                f"Invalid secret: {e.errors()[0]['msg']}",
                "MISSING_HEADERS"
            )
        
        self._secret = secret
        self._config = config or WebhookConfig()
    
    def verify(self, payload: Union[str, bytes], signature: str, timestamp: Union[str, int]) -> Any:
        """
        Verify a webhook signature and return the parsed payload.
        
        Args:
            payload: Raw request body as string or bytes (NOT parsed JSON)
            signature: Value of X-Webhook-Signature header
            timestamp: Value of X-Webhook-Timestamp header (string or int)
            
        Returns:
            Parsed event dictionary
            
        Raises:
            WebhookVerificationError: If verification fails
            
        Example:
            >>> webhook = Webhook(secret='whsec_...')
            >>> event = webhook.verify(
            ...     payload=request.body,
            ...     signature=request.headers['X-Webhook-Signature'],
            ...     timestamp=request.headers['X-Webhook-Timestamp']
            ... )
        """
        # Import here to avoid circular dependency
        from . import WebhookVerificationError
        
        # Convert payload to string if bytes
        if isinstance(payload, bytes):
            payload_str = payload.decode("utf-8")
        else:
            payload_str = payload
        
        # Validate inputs with Pydantic
        try:
            payload_model = _PayloadModel(payload=payload_str)
        except ValidationError as e:
            raise WebhookVerificationError(
                f"Invalid payload: {e.errors()[0]['msg']}",
                "MISSING_HEADERS"
            )
        
        try:
            signature_model = _SignatureModel(signature=signature)
        except ValidationError as e:
            raise WebhookVerificationError(
                f"Invalid signature: {e.errors()[0]['msg']}",
                "MISSING_HEADERS"
            )
        
        try:
            timestamp_model = _TimestampModel(timestamp=timestamp)
        except ValidationError as e:
            raise WebhookVerificationError(
                f"Invalid timestamp: {e.errors()[0]['msg']}",
                "MISSING_HEADERS"
            )
        
        # Parse timestamp to integer
        if isinstance(timestamp, str):
            try:
                ts = int(timestamp)
            except (ValueError, TypeError):
                raise WebhookVerificationError(
                    "Invalid timestamp: must be a valid unix timestamp",
                    "MISSING_HEADERS"
                )
        else:
            ts = timestamp
        
        # Check timestamp freshness (replay protection)
        now = int(time.time())
        if now - ts > self._config.max_age_seconds:
            raise WebhookVerificationError(
                f"Timestamp expired: event is {now - ts} seconds old (max: {self._config.max_age_seconds})",
                "TIMESTAMP_EXPIRED"
            )
        
        # Compute expected signature
        signed_payload = f"{ts}.{payload_str}"
        expected_signature = hmac.new(
            self._secret.encode("utf-8"),
            signed_payload.encode("utf-8"),
            hashlib.sha256,
        ).hexdigest()
        
        # Constant-time comparison
        if not hmac.compare_digest(expected_signature, signature):
            raise WebhookVerificationError(
                "Invalid signature: the signature does not match the payload",
                "INVALID_SIGNATURE"
            )
        
        # Parse and return payload
        try:
            return json.loads(payload_str)
        except json.JSONDecodeError:
            raise WebhookVerificationError(
                "Invalid payload: could not parse JSON",
                "INVALID_SIGNATURE"
            )
