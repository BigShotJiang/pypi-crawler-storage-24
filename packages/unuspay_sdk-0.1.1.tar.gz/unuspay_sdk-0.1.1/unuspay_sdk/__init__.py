"""
UnusPay SDK - Official webhook signature verification

Usage:
    from unuspay_sdk import Webhook, WebhookVerificationError

    # Class-based API
    webhook = Webhook(secret='whsec_...')
    event = webhook.verify(
        payload=request.body,
        signature=request.headers['X-Webhook-Signature'],
        timestamp=request.headers['X-Webhook-Timestamp']
    )
    print(f"Received event: {event['type']}")
"""

__version__ = "0.1.1"
__all__ = ["Webhook", "WebhookVerificationError", "WebhookConfig"]

# Import class-based API
from .webhook import Webhook, WebhookConfig


class WebhookVerificationError(Exception):
    """Raised when webhook signature verification fails."""

    def __init__(self, message: str, code: str):
        super().__init__(message)
        self.code = code
