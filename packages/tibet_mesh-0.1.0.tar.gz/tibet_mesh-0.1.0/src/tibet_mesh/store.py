"""
Store-and-Forward — messages for offline peers.

When a target peer is unreachable, messages are stored locally
and forwarded when the peer comes back online.
Every stored message retains its TIBET provenance.
"""

import json
import os
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

from .message import MeshMessage, MessageType


@dataclass
class StoredMessage:
    """A message waiting to be delivered."""
    message: MeshMessage
    stored_at: float
    attempts: int = 0
    max_attempts: int = 10
    last_attempt: float = 0.0

    def can_retry(self) -> bool:
        """Can we try delivering again?"""
        if self.attempts >= self.max_attempts:
            return False
        # Exponential backoff: 2, 4, 8, 16, 32... seconds
        if self.last_attempt > 0:
            backoff = min(300.0, 2.0 ** self.attempts)
            return (time.time() - self.last_attempt) >= backoff
        return True

    def record_attempt(self) -> None:
        self.attempts += 1
        self.last_attempt = time.time()

    def is_expired(self, max_age: float = 3600.0) -> bool:
        """Message expired (default: 1 hour)."""
        return (time.time() - self.stored_at) > max_age


class MessageStore:
    """
    Store-and-forward queue for offline peers.

    Messages are queued per target DID and delivered when
    the peer becomes reachable again. Optional persistence
    to disk so messages survive restarts.
    """

    def __init__(self, persist_dir: str | None = None):
        self._queues: dict[str, list[StoredMessage]] = {}
        self._persist_dir = persist_dir
        if persist_dir:
            Path(persist_dir).mkdir(parents=True, exist_ok=True)

    def store(self, message: MeshMessage, max_attempts: int = 10) -> StoredMessage:
        """Store a message for later delivery."""
        stored = StoredMessage(
            message=message,
            stored_at=time.time(),
            max_attempts=max_attempts,
        )

        target = message.target_did
        if target not in self._queues:
            self._queues[target] = []
        self._queues[target].append(stored)

        if self._persist_dir:
            self._persist_message(stored)

        return stored

    def pending_for(self, target_did: str) -> list[StoredMessage]:
        """Get all pending messages for a target DID."""
        if target_did not in self._queues:
            return []
        return [m for m in self._queues[target_did] if m.can_retry() and not m.is_expired()]

    def drain(self, target_did: str) -> list[MeshMessage]:
        """
        Get and remove all deliverable messages for a target.

        Called when a peer comes back online.
        """
        pending = self.pending_for(target_did)
        messages = [s.message for s in pending]

        # Remove delivered messages from queue
        if target_did in self._queues:
            self._queues[target_did] = [
                m for m in self._queues[target_did]
                if m not in pending
            ]
            if not self._queues[target_did]:
                del self._queues[target_did]

        if self._persist_dir:
            self._remove_persisted(target_did)

        return messages

    def mark_attempt(self, target_did: str, message_id: str) -> None:
        """Record a delivery attempt for a specific message."""
        if target_did in self._queues:
            for stored in self._queues[target_did]:
                if stored.message.message_id == message_id:
                    stored.record_attempt()
                    break

    def prune_expired(self, max_age: float = 3600.0) -> int:
        """Remove expired messages. Returns count removed."""
        pruned = 0
        to_delete = []
        for did, queue in self._queues.items():
            before = len(queue)
            self._queues[did] = [
                m for m in queue
                if not m.is_expired(max_age) and m.can_retry()
            ]
            pruned += before - len(self._queues[did])
            if not self._queues[did]:
                to_delete.append(did)
        for did in to_delete:
            del self._queues[did]
        return pruned

    def queue_sizes(self) -> dict[str, int]:
        """Get queue size per target DID."""
        return {did: len(queue) for did, queue in self._queues.items()}

    def total_pending(self) -> int:
        """Total number of pending messages."""
        return sum(len(q) for q in self._queues.values())

    def stats(self) -> dict:
        total = self.total_pending()
        targets = len(self._queues)
        return {
            "total_pending": total,
            "target_queues": targets,
            "persist_enabled": self._persist_dir is not None,
        }

    def _persist_message(self, stored: StoredMessage) -> None:
        """Write message to disk for persistence."""
        if not self._persist_dir:
            return
        target_dir = Path(self._persist_dir) / stored.message.target_did.replace(":", "_")
        target_dir.mkdir(parents=True, exist_ok=True)
        path = target_dir / f"{stored.message.message_id}.json"
        path.write_text(json.dumps(stored.message.to_dict(), indent=2))

    def _remove_persisted(self, target_did: str) -> None:
        """Remove persisted messages for a target."""
        if not self._persist_dir:
            return
        target_dir = Path(self._persist_dir) / target_did.replace(":", "_")
        if target_dir.exists():
            for f in target_dir.iterdir():
                f.unlink()
            target_dir.rmdir()
