"""
tibet-mesh CLI — interact with the mesh from the command line.

Usage::

    tibet-mesh start sensor-42
    tibet-mesh status
    tibet-mesh peers
    tibet-mesh send jis:gateway-1 '{"temp": 22.5}'
    tibet-mesh demo
"""

import argparse
import json
import sys
import time

from .node import MeshNode
from .message import MessageType


def cmd_demo(args: argparse.Namespace) -> int:
    """Run an interactive demo of the mesh network."""
    print()
    print("  tibet-mesh demo — Decentralized AI Mesh Network")
    print("  ================================================")
    print()

    # Create nodes
    print("  [1] Creating mesh nodes...")
    gateway = MeshNode(device_id="gateway-1", capabilities=["routing", "mqtt"])
    sensor1 = MeshNode(device_id="sensor-42", capabilities=["temperature", "humidity"])
    sensor2 = MeshNode(device_id="sensor-77", capabilities=["motion", "camera"])
    agent = MeshNode(device_id="ai-agent-1", capabilities=["inference", "nlp"])

    print(f"      Gateway:  {gateway.did}")
    print(f"      Sensor 1: {sensor1.did}")
    print(f"      Sensor 2: {sensor2.did}")
    print(f"      AI Agent: {agent.did}")
    print()

    # Connect peers
    print("  [2] Connecting peers (no central server)...")
    gateway.add_peer(sensor1.did, endpoint="10.0.0.42:9000", device_id="sensor-42")
    gateway.add_peer(sensor2.did, endpoint="10.0.0.77:9000", device_id="sensor-77")
    gateway.add_peer(agent.did, endpoint="10.0.0.100:9000", device_id="ai-agent-1")
    sensor1.add_peer(gateway.did, endpoint="10.0.0.1:9000", device_id="gateway-1")
    sensor2.add_peer(gateway.did, endpoint="10.0.0.1:9000", device_id="gateway-1")
    agent.add_peer(gateway.did, endpoint="10.0.0.1:9000", device_id="gateway-1")
    print(f"      Gateway peers: {len(gateway.discovery.alive_peers())}")
    print(f"      Sensor-42 peers: {len(sensor1.discovery.alive_peers())}")
    print()

    # Share peer lists (decentralized discovery)
    print("  [3] Peer discovery (forwarded through gateway)...")
    gw_peers = gateway.share_peers()
    added_s1 = sensor1.merge_peers(gw_peers, gateway.did)
    added_s2 = sensor2.merge_peers(gw_peers, gateway.did)
    added_agent = agent.merge_peers(gw_peers, gateway.did)
    print(f"      Sensor-42 discovered {added_s1} new peers via gateway")
    print(f"      Sensor-77 discovered {added_s2} new peers via gateway")
    print(f"      AI-Agent discovered {added_agent} new peers via gateway")
    print()

    # Send messages (TIBET tokens)
    print("  [4] Sending messages (each = TIBET token)...")
    result1 = sensor1.send(
        gateway.did,
        payload={"temperature": 22.5, "humidity": 65},
        intent="Report sensor reading to gateway",
    )
    print(f"      Sensor → Gateway: delivered={result1.delivered}, id={result1.message_id}")

    result2 = agent.send(
        sensor1.did,
        payload={"command": "increase_sample_rate", "hz": 10},
        intent="AI agent adjusts sensor sampling rate",
    )
    print(f"      Agent → Sensor:   delivered={result2.delivered}, reason={result2.reason}")

    # Agent sends to sensor2 through gateway
    result3 = agent.send(
        sensor2.did,
        payload={"command": "start_recording"},
        intent="AI agent triggers camera recording",
    )
    print(f"      Agent → Sensor2:  delivered={result3.delivered}, reason={result3.reason}")
    print()

    # Verify identities (FIR/A trust)
    print("  [5] Verifying identities (FIR/A trust scoring)...")
    proof = gateway.verify_peer(sensor1.did)
    print(f"      Sensor-42 verified: {proof.verified}")
    print(f"      Trust score: {proof.trust_score:.4f}")
    fira = proof.fira
    print(f"      FIR/A: F={fira.get('frequency', 0):.2f} I={fira.get('integrity', 0):.2f} "
          f"R={fira.get('recency', 0):.2f} A={fira.get('anomaly', 0):.2f}")
    print()

    # Store-and-forward demo
    print("  [6] Store-and-forward (offline peer)...")
    offline_did = "jis:sensor-offline"
    result_offline = sensor1.send(
        offline_did,
        payload={"alert": "motion_detected"},
        intent="Alert offline sensor about motion",
    )
    print(f"      Send to offline peer: delivered={result_offline.delivered}, stored={result_offline.stored}")
    print(f"      Store queue: {sensor1.store.total_pending()} messages pending")
    print()

    # Routing table
    print("  [7] Routing table (identity-based, not IP)...")
    stats = gateway.routing.stats()
    print(f"      Gateway routes: {stats['total_routes']} total, {stats['direct_peers']} direct")
    reachable = gateway.routing.reachable_dids()
    for did in reachable:
        route = gateway.routing.best_route(did)
        if route:
            print(f"      → {did}: {route.hops} hop(s), trust={route.trust_score:.4f}, direct={route.direct}")
    print()

    # Audit trail
    print("  [8] TIBET audit trail...")
    audit = gateway.audit_trail()
    print(f"      Gateway TIBET tokens: {len(audit)}")
    if audit:
        last = audit[-1]
        print(f"      Latest: {last['action']} for {last['did']}")
        print(f"      Intent: {last['erachter']['intent']}")
    print()

    # Full status
    print("  [9] Node status...")
    status = gateway.status()
    print(f"      DID: {status['node']['did']}")
    print(f"      Peers: {status['mesh']['peers']['alive_peers']} alive")
    print(f"      Messages: {status['messages']['sent']} sent, {status['messages']['received']} received")
    print(f"      TIBET tokens: {status['overlay']['tibet_tokens']}")
    print()

    print("  ✓ Demo complete — no central server was used!")
    print()
    return 0


def cmd_start(args: argparse.Namespace) -> int:
    """Start a mesh node."""
    node = MeshNode(
        device_id=args.device_id,
        endpoint=args.endpoint or "",
        capabilities=args.capabilities.split(",") if args.capabilities else [],
    )
    print(f"\n  Mesh node started")
    print(f"  DID: {node.did}")
    print(f"  Endpoint: {args.endpoint or '(none)'}")
    print(f"  Capabilities: {node.identity.capabilities}")
    print()

    status = node.status()
    print(f"  Trust: {status['node']['trust_score']:.4f}")
    print(f"  FIRA: F={status['node']['fira'].get('frequency', 0):.2f} "
          f"I={status['node']['fira'].get('integrity', 0):.2f} "
          f"R={status['node']['fira'].get('recency', 0):.2f} "
          f"A={status['node']['fira'].get('anomaly', 0):.2f}")
    print()
    return 0


def cmd_info(args: argparse.Namespace) -> int:
    """Show mesh node info."""
    node = MeshNode(device_id=args.device_id or "cli-node")
    if args.json:
        print(json.dumps(node.status(), indent=2))
    else:
        status = node.status()
        print(f"\n  tibet-mesh node: {status['node']['did']}")
        print(f"  Trust: {status['node']['trust_score']:.4f}")
        print(f"  Capabilities: {status['node']['capabilities']}")
        print()
    return 0


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="tibet-mesh",
        description="Decentralized AI Mesh Network — identity-routed, TIBET-audited",
    )
    parser.add_argument("--version", action="version", version=f"%(prog)s 0.1.0")

    sub = parser.add_subparsers(dest="command", help="Available commands")

    # demo
    sub.add_parser("demo", help="Run interactive mesh demo")

    # start
    p_start = sub.add_parser("start", help="Start a mesh node")
    p_start.add_argument("device_id", help="Device ID for this node")
    p_start.add_argument("-e", "--endpoint", help="Listen endpoint (host:port)")
    p_start.add_argument("-c", "--capabilities", help="Comma-separated capabilities")

    # info
    p_info = sub.add_parser("info", help="Show node info")
    p_info.add_argument("device_id", nargs="?", help="Device ID")
    p_info.add_argument("-j", "--json", action="store_true", help="JSON output")

    args = parser.parse_args(argv)

    if args.command == "demo":
        return cmd_demo(args)
    elif args.command == "start":
        return cmd_start(args)
    elif args.command == "info":
        return cmd_info(args)
    else:
        parser.print_help()
        return 0


if __name__ == "__main__":
    sys.exit(main())
