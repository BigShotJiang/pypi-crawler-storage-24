"""
tibet-mesh — Decentralized AI Mesh Network
===========================================

Identity-routed, TIBET-audited, zero central server.

Each device is a JIS identity (cryptographic).
Each message is a TIBET token (audit trail).
Routing is on identity — not on IP.

Built on tibet-overlay for identity, trust, and provenance.

Usage::

    from tibet_mesh import MeshNode

    node = MeshNode(device_id="sensor-42")
    node.add_peer("jis:gateway-1", endpoint="192.168.1.10:9000")
    result = node.send("jis:gateway-1", {"temperature": 22.5})
    print(result.delivered)  # True

Authors: J. van de Meent & R. AI (Root AI)
License: MIT — Humotica AI Lab 2025-2026
"""

from .node import MeshNode, DeliveryResult
from .message import MeshMessage, MessageFactory, MessageType
from .routing import RoutingTable, RoutingEntry
from .discovery import PeerDiscovery, PeerInfo
from .store import MessageStore, StoredMessage

__version__ = "0.1.0"

__all__ = [
    "MeshNode",
    "DeliveryResult",
    "MeshMessage",
    "MessageFactory",
    "MessageType",
    "RoutingTable",
    "RoutingEntry",
    "PeerDiscovery",
    "PeerInfo",
    "MessageStore",
    "StoredMessage",
]
