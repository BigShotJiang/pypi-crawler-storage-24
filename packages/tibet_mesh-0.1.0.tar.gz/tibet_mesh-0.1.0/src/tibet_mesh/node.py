"""
MeshNode — the core of tibet-mesh.

A MeshNode is a device on the mesh network. It has:
- A JIS identity (via tibet-overlay)
- A routing table (identity-based, not IP-based)
- Peer discovery (no central server)
- Store-and-forward for offline peers
- Full TIBET audit trail for every action

Usage::

    from tibet_mesh import MeshNode

    node = MeshNode(device_id="sensor-42")
    node.add_peer("jis:gateway-1", endpoint="192.168.1.10:9000")
    msg = node.send("jis:gateway-1", {"temperature": 22.5})
    print(msg.message_id)
"""

import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Callable, Optional

from tibet_overlay import IdentityOverlay, DeviceIdentity

from .message import MeshMessage, MessageFactory, MessageType
from .routing import RoutingTable
from .discovery import PeerDiscovery, PeerInfo
from .store import MessageStore


@dataclass
class DeliveryResult:
    """Result of attempting to deliver a message."""
    message_id: str
    delivered: bool
    target_did: str
    stored: bool = False  # Stored for later delivery
    reason: str = ""
    route: list[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        return {
            "message_id": self.message_id,
            "delivered": self.delivered,
            "target_did": self.target_did,
            "stored": self.stored,
            "reason": self.reason,
            "route": self.route,
        }


class MeshNode:
    """
    A node in the tibet-mesh network.

    Each MeshNode is a device with a cryptographic JIS identity.
    Messages are routed by identity (DID), not by IP address.
    Every message is a TIBET token with full provenance.

    No central server required. Nodes discover each other,
    build routing tables, and store messages for offline peers.

    Usage::

        node = MeshNode(device_id="sensor-42")
        node.add_peer("jis:gateway-1", endpoint="192.168.1.10:9000")
        result = node.send("jis:gateway-1", {"temp": 22.5})

    """

    def __init__(
        self,
        device_id: str,
        endpoint: str = "",
        capabilities: list[str] | None = None,
        persist_dir: str | None = None,
    ):
        # Strip jis: prefix if provided (overlay adds it)
        if device_id.startswith("jis:"):
            device_id = device_id[4:]

        # Identity layer (tibet-overlay)
        self.overlay = IdentityOverlay(actor=f"tibet-mesh:{device_id}")
        self.identity = self.overlay.register(
            device_id=device_id,
            endpoint=endpoint,
            capabilities=capabilities,
        )
        self.did = self.identity.did

        # Mesh components
        self.messages = MessageFactory(self.did)
        self.routing = RoutingTable(self.did)
        self.discovery = PeerDiscovery(self.did)
        self.store = MessageStore(persist_dir=persist_dir)

        # Message handlers
        self._handlers: dict[MessageType, list[Callable]] = {}
        self._inbox: list[MeshMessage] = []
        self._sent: list[MeshMessage] = []
        self._on_peer_discovered: list[Callable] = []

        # Stats
        self._started_at = time.time()
        self._messages_sent = 0
        self._messages_received = 0
        self._messages_forwarded = 0

    # ── Messaging ──────────────────────────────────────────────

    def send(
        self,
        target_did: str,
        payload: dict | None = None,
        intent: str = "",
        ttl: int = 10,
    ) -> DeliveryResult:
        """
        Send a message to a target DID.

        If the target is directly connected, delivers immediately.
        If the target is reachable through a peer, forwards.
        If the target is unreachable, stores for later delivery.
        """
        msg = self.messages.create(
            msg_type=MessageType.DATA,
            target_did=target_did,
            payload=payload,
            intent=intent,
            ttl=ttl,
        )
        self._sent.append(msg)
        self._messages_sent += 1

        return self._deliver(msg)

    def _deliver(self, msg: MeshMessage) -> DeliveryResult:
        """Internal: attempt to deliver a message."""
        target = msg.target_did

        # Check if target is a known peer
        peer = self.discovery.find_by_did(target)
        if peer and peer.is_alive():
            # Direct delivery (in a real network, this sends over the wire)
            return DeliveryResult(
                message_id=msg.message_id,
                delivered=True,
                target_did=target,
                route=msg.route,
                reason="direct",
            )

        # Check routing table for indirect path
        route = self.routing.best_route(target)
        if route:
            msg.record_hop(self.did)
            return DeliveryResult(
                message_id=msg.message_id,
                delivered=True,
                target_did=target,
                route=msg.route,
                reason=f"via:{route.next_hop_did}",
            )

        # Target unreachable — store for later
        self.store.store(msg)
        return DeliveryResult(
            message_id=msg.message_id,
            delivered=False,
            target_did=target,
            stored=True,
            route=msg.route,
            reason="stored:peer_offline",
        )

    def receive(self, msg: MeshMessage) -> MeshMessage | None:
        """
        Receive a message from the mesh.

        If addressed to us, process it.
        If addressed to someone else and TTL allows, forward.
        Returns an ACK message if delivered to us, None otherwise.
        """
        self._messages_received += 1

        # Verify integrity
        if not self.messages.verify_integrity(msg):
            self.overlay.record_anomaly(msg.source_did)
            return None

        # Record interaction with sender
        if msg.source_did in self.overlay.registry.identities:
            self.overlay.registry.record_interaction(msg.source_did)

        # Message for us?
        if msg.target_did == self.did:
            self._inbox.append(msg)
            self._dispatch(msg)
            return self.messages.create_ack(msg)

        # Broadcast message?
        if msg.target_did == "*":
            self._inbox.append(msg)
            self._dispatch(msg)
            return None  # No ACK for broadcasts

        # Not for us — forward if TTL allows
        if not msg.is_expired():
            msg.record_hop(self.did)
            self._messages_forwarded += 1
            self._deliver(msg)

        return None

    def _dispatch(self, msg: MeshMessage) -> None:
        """Dispatch message to registered handlers."""
        handlers = self._handlers.get(msg.msg_type, [])
        for handler in handlers:
            handler(msg)

    def on_message(self, msg_type: MessageType, handler: Callable) -> None:
        """Register a handler for a message type."""
        if msg_type not in self._handlers:
            self._handlers[msg_type] = []
        self._handlers[msg_type].append(handler)

    # ── Peer Management ────────────────────────────────────────

    def add_peer(
        self,
        did: str,
        endpoint: str = "",
        device_id: str = "",
        capabilities: list[str] | None = None,
        trust_score: float = 0.5,
    ) -> PeerInfo:
        """
        Add a peer to the mesh.

        Registers the peer in discovery, adds a direct route,
        and registers their identity in the overlay.
        """
        # Extract device_id from DID if not provided
        if not device_id and ":" in did:
            device_id = did.split(":")[-1]

        # Register in overlay (identity layer)
        identity = self.overlay.register(
            device_id=device_id,
            endpoint=endpoint,
            capabilities=capabilities,
        )

        # Register in discovery
        peer = self.discovery.add_peer(
            did=did,
            device_id=device_id,
            endpoint=endpoint,
            capabilities=capabilities,
            trust_score=trust_score,
            discovered_via="direct",
        )

        # Add direct route
        self.routing.add_route(
            target_did=did,
            next_hop_did=did,
            hops=1,
            trust_score=trust_score,
            direct=True,
        )

        # Deliver any stored messages for this peer
        stored = self.store.drain(did)
        for msg in stored:
            self._deliver(msg)

        # Notify handlers
        for cb in self._on_peer_discovered:
            cb(peer)

        return peer

    def remove_peer(self, did: str) -> None:
        """Remove a peer from the mesh."""
        self.discovery.remove_peer(did)
        self.routing.remove_route(did)

    def on_peer_discovered(self, callback: Callable) -> None:
        """Register a callback for when a new peer is discovered."""
        self._on_peer_discovered.append(callback)

    # ── Discovery ──────────────────────────────────────────────

    def announce(self) -> MeshMessage:
        """Broadcast a discovery announcement to the mesh."""
        return self.messages.create_discovery(
            capabilities=self.identity.capabilities,
        )

    def heartbeat(self) -> MeshMessage:
        """Send a heartbeat to all peers."""
        return self.messages.create_heartbeat(
            capabilities=self.identity.capabilities,
        )

    def share_peers(self) -> list[dict]:
        """Get peer list for sharing with other nodes."""
        return self.discovery.peer_list_for_sharing()

    def merge_peers(self, peers: list[dict], from_did: str) -> int:
        """Merge peer list received from another node."""
        added = self.discovery.merge_peer_list(peers, from_did)
        # Add routes for newly discovered peers
        for p in peers:
            did = p.get("did", "")
            if did and did != self.did and did not in self.routing.reachable_dids():
                self.routing.add_route(
                    target_did=did,
                    next_hop_did=from_did,
                    hops=2,
                    trust_score=p.get("trust_score", 0.3),
                )
        return added

    # ── Trust & Identity ───────────────────────────────────────

    def verify_peer(self, did: str):
        """Verify a peer's identity. Updates FIR/A trust score."""
        return self.overlay.verify(did)

    def trust_score(self, did: str) -> float:
        """Get current trust score for a peer."""
        fira = self.overlay.get_fira(did)
        return fira.get("score", 0.0)

    def fira(self, did: str) -> dict:
        """Get full FIR/A breakdown for a peer."""
        return self.overlay.get_fira(did)

    # ── Inbox ──────────────────────────────────────────────────

    def inbox(self, limit: int = 50) -> list[MeshMessage]:
        """Get received messages (newest first)."""
        return list(reversed(self._inbox[-limit:]))

    def inbox_count(self) -> int:
        return len(self._inbox)

    # ── Status ─────────────────────────────────────────────────

    def status(self) -> dict:
        """Full mesh node status."""
        return {
            "node": {
                "did": self.did,
                "device_id": self.identity.device_id,
                "capabilities": self.identity.capabilities,
                "trust_score": self.identity.trust_score,
                "fira": self.identity.fira_breakdown(),
                "uptime": round(time.time() - self._started_at, 1),
            },
            "mesh": {
                "peers": self.discovery.stats(),
                "routing": self.routing.stats(),
                "store": self.store.stats(),
            },
            "messages": {
                "sent": self._messages_sent,
                "received": self._messages_received,
                "forwarded": self._messages_forwarded,
                "inbox": self.inbox_count(),
            },
            "overlay": self.overlay.status(),
        }

    def audit_trail(self) -> list[dict]:
        """Full TIBET audit trail for this node."""
        return self.overlay.export_audit()
