"""
Identity-Based Routing — route on DID, not IP.

The routing table maps JIS DIDs to peers, not IP addresses to next-hops.
This means a device can change IP, move to another network, go through
CGNAT, and still be reachable by its identity.

Every routing decision is TIBET-audited.
"""

import time
from dataclasses import dataclass, field
from typing import Optional


@dataclass
class RoutingEntry:
    """A routing table entry — maps a DID to a reachable peer."""
    target_did: str
    next_hop_did: str    # Which peer to forward to
    hops: int = 1        # Distance in hops
    trust_score: float = 0.5
    last_seen: float = 0.0
    direct: bool = False  # Directly connected?

    def is_stale(self, max_age: float = 300.0) -> bool:
        """Entry is stale if not seen for max_age seconds."""
        return (time.time() - self.last_seen) > max_age

    def to_dict(self) -> dict:
        return {
            "target_did": self.target_did,
            "next_hop_did": self.next_hop_did,
            "hops": self.hops,
            "trust_score": self.trust_score,
            "direct": self.direct,
            "stale": self.is_stale(),
        }


class RoutingTable:
    """
    Identity-based routing table.

    Routes are based on JIS DIDs. When multiple paths exist to a target,
    the route with the highest trust score is preferred (not shortest path).
    Trust-weighted routing means untrusted peers don't become transit nodes.
    """

    def __init__(self, local_did: str):
        self.local_did = local_did
        self._routes: dict[str, list[RoutingEntry]] = {}

    def add_route(
        self,
        target_did: str,
        next_hop_did: str,
        hops: int = 1,
        trust_score: float = 0.5,
        direct: bool = False,
    ) -> RoutingEntry:
        """Add or update a route to a target DID."""
        entry = RoutingEntry(
            target_did=target_did,
            next_hop_did=next_hop_did,
            hops=hops,
            trust_score=trust_score,
            last_seen=time.time(),
            direct=direct,
        )

        if target_did not in self._routes:
            self._routes[target_did] = []

        # Update existing route via same next_hop, or add new
        existing = [r for r in self._routes[target_did] if r.next_hop_did == next_hop_did]
        if existing:
            existing[0].hops = hops
            existing[0].trust_score = trust_score
            existing[0].last_seen = time.time()
            existing[0].direct = direct
            return existing[0]

        self._routes[target_did].append(entry)
        return entry

    def remove_route(self, target_did: str, next_hop_did: str | None = None) -> None:
        """Remove routes to a target. If next_hop given, only that route."""
        if target_did not in self._routes:
            return
        if next_hop_did:
            self._routes[target_did] = [
                r for r in self._routes[target_did]
                if r.next_hop_did != next_hop_did
            ]
            if not self._routes[target_did]:
                del self._routes[target_did]
        else:
            del self._routes[target_did]

    def best_route(self, target_did: str) -> Optional[RoutingEntry]:
        """
        Find the best route to a target DID.

        Prefers: direct > high trust > fewer hops.
        Skips stale routes.
        """
        if target_did not in self._routes:
            return None

        # Filter non-stale routes
        active = [r for r in self._routes[target_did] if not r.is_stale()]
        if not active:
            return None

        # Sort: direct first, then by trust (desc), then by hops (asc)
        active.sort(key=lambda r: (not r.direct, -r.trust_score, r.hops))
        return active[0]

    def all_routes(self, target_did: str) -> list[RoutingEntry]:
        """Get all known routes to a target (including stale)."""
        return self._routes.get(target_did, [])

    def reachable_dids(self) -> list[str]:
        """List all DIDs we can currently reach (non-stale routes)."""
        result = []
        for did, routes in self._routes.items():
            if any(not r.is_stale() for r in routes):
                result.append(did)
        return result

    def direct_peers(self) -> list[str]:
        """List DIDs of directly connected peers."""
        result = []
        for did, routes in self._routes.items():
            if any(r.direct and not r.is_stale() for r in routes):
                result.append(did)
        return result

    def update_trust(self, did: str, trust_score: float) -> None:
        """Update trust score for all routes through a DID."""
        for routes in self._routes.values():
            for route in routes:
                if route.next_hop_did == did or route.target_did == did:
                    route.trust_score = trust_score

    def prune_stale(self, max_age: float = 300.0) -> int:
        """Remove stale routes. Returns number of routes pruned."""
        pruned = 0
        to_delete = []
        for did, routes in self._routes.items():
            before = len(routes)
            self._routes[did] = [r for r in routes if not r.is_stale(max_age)]
            pruned += before - len(self._routes[did])
            if not self._routes[did]:
                to_delete.append(did)
        for did in to_delete:
            del self._routes[did]
        return pruned

    def stats(self) -> dict:
        total_routes = sum(len(r) for r in self._routes.values())
        direct = len(self.direct_peers())
        reachable = len(self.reachable_dids())
        return {
            "total_routes": total_routes,
            "reachable_dids": reachable,
            "direct_peers": direct,
            "local_did": self.local_did,
        }

    def to_dict(self) -> dict:
        result = {}
        for did, routes in self._routes.items():
            result[did] = [r.to_dict() for r in routes]
        return result
