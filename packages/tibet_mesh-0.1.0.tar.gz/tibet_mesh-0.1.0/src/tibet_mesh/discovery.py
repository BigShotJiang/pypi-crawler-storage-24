"""
Peer Discovery — find other nodes without a central server.

Nodes announce themselves and discover peers through:
1. Direct connection (known endpoint)
2. Broadcast to local network
3. Forwarded discovery (peers share their peers)

Every discovery event is TIBET-tracked.
"""

import time
from dataclasses import dataclass, field
from typing import Optional


@dataclass
class PeerInfo:
    """Information about a discovered peer."""
    did: str
    device_id: str
    endpoint: str
    capabilities: list[str] = field(default_factory=list)
    trust_score: float = 0.5
    discovered_at: float = 0.0
    last_heartbeat: float = 0.0
    discovered_via: str = ""  # How we found this peer

    def is_alive(self, timeout: float = 120.0) -> bool:
        """Peer is alive if heartbeat received within timeout."""
        if self.last_heartbeat == 0:
            return (time.time() - self.discovered_at) < timeout
        return (time.time() - self.last_heartbeat) < timeout

    def to_dict(self) -> dict:
        return {
            "did": self.did,
            "device_id": self.device_id,
            "endpoint": self.endpoint,
            "capabilities": self.capabilities,
            "trust_score": self.trust_score,
            "alive": self.is_alive(),
            "discovered_via": self.discovered_via,
        }


class PeerDiscovery:
    """
    Decentralized peer discovery.

    No central server. Nodes find each other through:
    - Direct endpoint connection
    - Discovery announcements
    - Forwarded peer info from existing peers
    """

    def __init__(self, local_did: str):
        self.local_did = local_did
        self.peers: dict[str, PeerInfo] = {}
        self._bootstrap_endpoints: list[str] = []

    def add_bootstrap(self, endpoint: str) -> None:
        """Add a bootstrap endpoint for initial peer discovery."""
        if endpoint not in self._bootstrap_endpoints:
            self._bootstrap_endpoints.append(endpoint)

    def add_peer(
        self,
        did: str,
        device_id: str,
        endpoint: str,
        capabilities: list[str] | None = None,
        trust_score: float = 0.5,
        discovered_via: str = "direct",
    ) -> PeerInfo:
        """Register a discovered peer."""
        now = time.time()

        if did in self.peers:
            # Update existing peer
            peer = self.peers[did]
            peer.endpoint = endpoint
            peer.last_heartbeat = now
            if capabilities:
                peer.capabilities = capabilities
            peer.trust_score = trust_score
            return peer

        peer = PeerInfo(
            did=did,
            device_id=device_id,
            endpoint=endpoint,
            capabilities=capabilities or [],
            trust_score=trust_score,
            discovered_at=now,
            last_heartbeat=now,
            discovered_via=discovered_via,
        )
        self.peers[did] = peer
        return peer

    def remove_peer(self, did: str) -> None:
        """Remove a peer from the discovery table."""
        self.peers.pop(did, None)

    def heartbeat(self, did: str) -> None:
        """Record a heartbeat from a peer."""
        if did in self.peers:
            self.peers[did].last_heartbeat = time.time()

    def alive_peers(self, timeout: float = 120.0) -> list[PeerInfo]:
        """Get all alive peers."""
        return [p for p in self.peers.values() if p.is_alive(timeout)]

    def dead_peers(self, timeout: float = 120.0) -> list[PeerInfo]:
        """Get all dead/unresponsive peers."""
        return [p for p in self.peers.values() if not p.is_alive(timeout)]

    def find_by_capability(self, capability: str) -> list[PeerInfo]:
        """Find alive peers with a specific capability."""
        return [
            p for p in self.peers.values()
            if p.is_alive() and capability in p.capabilities
        ]

    def find_by_did(self, did: str) -> Optional[PeerInfo]:
        """Find a specific peer by DID."""
        return self.peers.get(did)

    def prune_dead(self, timeout: float = 300.0) -> int:
        """Remove dead peers. Returns number removed."""
        dead = [did for did, p in self.peers.items() if not p.is_alive(timeout)]
        for did in dead:
            del self.peers[did]
        return len(dead)

    def peer_list_for_sharing(self) -> list[dict]:
        """
        Get peer list suitable for sharing with other nodes.

        Only shares alive peers with trust > 0.3 (don't propagate
        untrusted peers through the network).
        """
        return [
            {
                "did": p.did,
                "device_id": p.device_id,
                "endpoint": p.endpoint,
                "capabilities": p.capabilities,
                "trust_score": p.trust_score,
            }
            for p in self.peers.values()
            if p.is_alive() and p.trust_score > 0.3
        ]

    def merge_peer_list(self, peers: list[dict], from_did: str) -> int:
        """
        Merge a peer list received from another node.

        Returns number of new peers discovered.
        """
        added = 0
        for p in peers:
            did = p.get("did", "")
            if not did or did == self.local_did:
                continue
            if did not in self.peers:
                self.add_peer(
                    did=did,
                    device_id=p.get("device_id", ""),
                    endpoint=p.get("endpoint", ""),
                    capabilities=p.get("capabilities", []),
                    trust_score=p.get("trust_score", 0.3),
                    discovered_via=f"forwarded:{from_did}",
                )
                added += 1
        return added

    def stats(self) -> dict:
        total = len(self.peers)
        alive = len(self.alive_peers())
        return {
            "total_peers": total,
            "alive_peers": alive,
            "dead_peers": total - alive,
            "bootstrap_endpoints": len(self._bootstrap_endpoints),
        }
