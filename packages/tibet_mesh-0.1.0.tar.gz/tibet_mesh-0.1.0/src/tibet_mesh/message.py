"""
Mesh Messages — every message is a TIBET token.

Messages travel through the mesh with full provenance:
who sent it, to whom, when, what's in it, and why.
No message exists without an audit trail.
"""

import hashlib
import json
import os
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Optional


class MessageType(Enum):
    """Types of messages that can travel through the mesh."""
    DATA = "data"              # Regular data message
    DISCOVERY = "discovery"    # Peer discovery announcement
    HEARTBEAT = "heartbeat"    # Alive signal
    ROUTE = "route"            # Routing update
    ACK = "ack"                # Acknowledgement
    STORE = "store"            # Store-and-forward request


@dataclass
class MeshMessage:
    """
    A message in the mesh network — always a TIBET token.

    Every message carries:
    - ERIN:     What's IN the message (payload)
    - ERAAN:    What's attached (references, parent messages)
    - EROMHEEN: Context around it (sender, receiver, network state)
    - ERACHTER: Intent behind it (why was this sent)
    """
    message_id: str
    msg_type: MessageType
    source_did: str
    target_did: str
    payload: dict = field(default_factory=dict)
    timestamp: str = ""
    ttl: int = 10           # Max hops before message dies
    hops: int = 0           # Current hop count
    content_hash: str = ""
    parent_id: Optional[str] = None
    route: list[str] = field(default_factory=list)  # DIDs this message passed through

    # TIBET token fields
    erin: dict = field(default_factory=dict)
    eraan: dict = field(default_factory=dict)
    eromheen: dict = field(default_factory=dict)
    erachter: dict = field(default_factory=dict)

    def to_dict(self) -> dict:
        return {
            "message_id": self.message_id,
            "type": self.msg_type.value,
            "source_did": self.source_did,
            "target_did": self.target_did,
            "payload": self.payload,
            "timestamp": self.timestamp,
            "ttl": self.ttl,
            "hops": self.hops,
            "content_hash": self.content_hash,
            "parent_id": self.parent_id,
            "route": self.route,
            "erin": self.erin,
            "eraan": self.eraan,
            "eromheen": self.eromheen,
            "erachter": self.erachter,
        }

    def is_expired(self) -> bool:
        """Message exceeded its TTL."""
        return self.hops >= self.ttl

    def record_hop(self, via_did: str) -> None:
        """Record a hop through a node."""
        self.hops += 1
        self.route.append(via_did)


class MessageFactory:
    """
    Creates TIBET-wrapped mesh messages.

    Every message gets a unique ID, content hash, and full
    TIBET provenance (ERIN, ERAAN, EROMHEEN, ERACHTER).
    """

    def __init__(self, local_did: str):
        self.local_did = local_did
        self._seq = 0

    def create(
        self,
        msg_type: MessageType,
        target_did: str,
        payload: dict | None = None,
        intent: str = "",
        ttl: int = 10,
        parent_id: str | None = None,
    ) -> MeshMessage:
        """Create a new TIBET-wrapped mesh message."""
        now = datetime.now(timezone.utc).isoformat()
        self._seq += 1

        # Generate unique message ID
        raw = f"{self.local_did}:{self._seq}:{now}:{os.urandom(8).hex()}"
        message_id = hashlib.sha256(raw.encode()).hexdigest()[:16]

        # Build payload
        payload = payload or {}

        # Content hash for integrity verification
        content = json.dumps(payload, sort_keys=True)
        content_hash = hashlib.sha256(content.encode()).hexdigest()[:32]

        # TIBET token fields
        erin = {
            "type": msg_type.value,
            "payload": payload,
            "content_hash": content_hash,
        }
        eraan = {
            "parent_message": parent_id,
            "sequence": self._seq,
        }
        eromheen = {
            "source": self.local_did,
            "target": target_did,
            "node": os.uname().nodename,
            "timestamp": now,
        }
        erachter = {
            "intent": intent or f"Mesh {msg_type.value} from {self.local_did} to {target_did}",
            "protocol": "tibet-mesh/0.1",
        }

        return MeshMessage(
            message_id=message_id,
            msg_type=msg_type,
            source_did=self.local_did,
            target_did=target_did,
            payload=payload,
            timestamp=now,
            ttl=ttl,
            hops=0,
            content_hash=content_hash,
            parent_id=parent_id,
            route=[self.local_did],
            erin=erin,
            eraan=eraan,
            eromheen=eromheen,
            erachter=erachter,
        )

    def create_ack(self, original: MeshMessage) -> MeshMessage:
        """Create an acknowledgement for a received message."""
        return self.create(
            msg_type=MessageType.ACK,
            target_did=original.source_did,
            payload={"ack_for": original.message_id},
            intent=f"Acknowledge receipt of {original.message_id}",
            parent_id=original.message_id,
        )

    def create_heartbeat(self, capabilities: list[str] | None = None) -> MeshMessage:
        """Create a heartbeat/alive signal for peer discovery."""
        return self.create(
            msg_type=MessageType.HEARTBEAT,
            target_did="*",  # Broadcast
            payload={
                "alive": True,
                "capabilities": capabilities or [],
                "uptime": time.monotonic(),
            },
            intent="Heartbeat broadcast to mesh peers",
        )

    def create_discovery(self, capabilities: list[str] | None = None) -> MeshMessage:
        """Create a discovery announcement."""
        return self.create(
            msg_type=MessageType.DISCOVERY,
            target_did="*",  # Broadcast
            payload={
                "announce": True,
                "did": self.local_did,
                "capabilities": capabilities or [],
            },
            intent="Announce presence to mesh network",
        )

    def verify_integrity(self, msg: MeshMessage) -> bool:
        """Verify message content hash hasn't been tampered with."""
        content = json.dumps(msg.payload, sort_keys=True)
        expected = hashlib.sha256(content.encode()).hexdigest()[:32]
        return expected == msg.content_hash
