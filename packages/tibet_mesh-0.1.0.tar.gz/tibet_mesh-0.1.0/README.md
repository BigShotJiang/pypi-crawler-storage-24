# tibet-mesh

**Decentralized AI Mesh Network — identity-routed, TIBET-audited, zero central server.**

Part of the [TIBET protocol suite](https://pypi.org/project/tibet-core/) by [Humotica AI Lab](https://humotica.com).

## Concept

- **No central server** — nodes discover each other and route directly
- **Each device = JIS identity** — cryptographic, not IP-based
- **Each message = TIBET token** — full audit trail (who, what, when, why)
- **Routing on identity** — not on IP address (works behind CGNAT/NAT)
- **FIR/A trust scoring** — behavioral trust, not static configuration

## Install

```bash
pip install tibet-mesh
```

## Quick Start

```python
from tibet_mesh import MeshNode

# Create nodes
gateway = MeshNode(device_id="gateway-1", capabilities=["routing"])
sensor = MeshNode(device_id="sensor-42", capabilities=["temperature"])

# Connect (no central server)
gateway.add_peer(sensor.did, endpoint="10.0.0.42:9000")
sensor.add_peer(gateway.did, endpoint="10.0.0.1:9000")

# Send a message (= TIBET token with full provenance)
result = sensor.send(
    gateway.did,
    payload={"temperature": 22.5, "humidity": 65},
    intent="Report sensor reading",
)
print(result.delivered)  # True

# Verify identity (FIR/A trust)
proof = gateway.verify_peer(sensor.did)
print(proof.trust_score)  # 0.6+ (increases with interactions)
```

## CLI

```bash
# Interactive demo
tibet-mesh demo

# Start a node
tibet-mesh start sensor-42 -e 0.0.0.0:9000 -c temperature,humidity

# Node info
tibet-mesh info sensor-42 -j
```

## Architecture

```
┌─────────────────────────────────────────────┐
│              tibet-mesh                      │
│                                             │
│  MeshNode ──── MessageFactory               │
│     │              │                        │
│     ├── RoutingTable (DID → next hop)       │
│     ├── PeerDiscovery (no central server)   │
│     ├── MessageStore (store & forward)      │
│     │                                       │
│  ┌──┴───────────────────────────────┐       │
│  │  tibet-overlay (identity layer)  │       │
│  │  • JIS DID per device            │       │
│  │  • FIR/A trust scoring           │       │
│  │  • TIBET provenance              │       │
│  └──────────────────────────────────┘       │
└─────────────────────────────────────────────┘
```

## Features

### Identity-Based Routing
Routes by JIS DID, not IP. A device can change IP, move networks, go through CGNAT — still reachable by identity.

### TIBET Audit Trail
Every message is a TIBET token with ERIN (what), ERAAN (references), EROMHEEN (context), ERACHTER (intent).

### Store-and-Forward
Messages for offline peers are queued with exponential backoff and delivered when the peer reconnects.

### Trust-Weighted Routing
When multiple paths exist, the route with highest FIR/A trust score is preferred — not shortest path.

### Peer Discovery
Nodes share peer lists. No central directory needed. Trust propagates through the network.

## IETF Drafts

- [TIBET Provenance](https://datatracker.ietf.org/doc/draft-vandemeent-tibet-provenance/) — Token-based provenance
- [JIS Identity](https://datatracker.ietf.org/doc/draft-vandemeent-jis-identity/) — Device identity standard

## License

MIT — Humotica AI Lab 2025-2026
