from .anonymizer import Anonymizer, AnonymizationResult
from .audit import AuditLogger
from .client import (
    BaseLLMClient,
    LiteLLMPrivacyClient,
    OpenAIPrivacyClient,
    PrivacyClient,
    PrivacyOpenAI,
)
from .formats import CsvAnonymizer, CsvRowResult, JsonAnonymizer, JsonRecordResult
from .session import PrivacySession
from ._types import (
    FieldConfig,
    LLMClient,
    ModelNotFoundError,
    RedacitError,
    SidecarConfig,
    UnsupportedProviderError,
)

__all__ = [
    # Core
    "Anonymizer",
    "AnonymizationResult",
    # Convenience — module-level wrappers around a shared Anonymizer instance
    "configure",
    "anonymize",
    "deanonymize",
    # Clients
    "BaseLLMClient",
    "PrivacyClient",
    "OpenAIPrivacyClient",
    "PrivacyOpenAI",
    "LiteLLMPrivacyClient",
    # Session & audit
    "PrivacySession",
    "AuditLogger",
    # Format handlers
    "CsvAnonymizer",
    "CsvRowResult",
    "JsonAnonymizer",
    "JsonRecordResult",
    # Types
    "FieldConfig",
    "SidecarConfig",
    "LLMClient",
    # Exceptions
    "RedacitError",
    "UnsupportedProviderError",
    "ModelNotFoundError",
]

_default_anonymizer: Anonymizer | None = None
_default_model: str = "auto"


def configure(model: str = "auto") -> None:
    """Configure the shared module-level Anonymizer.

    Must be called **before** the first ``anonymize()`` call to have effect.

    Args:
        model: spaCy model name, ``"auto"`` for auto-detect, or ``None``
               for regex-only mode.
    """
    global _default_anonymizer, _default_model
    _default_model = model
    _default_anonymizer = None  # force re-creation on next use
    # Also reset the config cache so a fresh Anonymizer picks up any
    # changes to pyproject.toml (relevant in interactive/notebook use).
    from .anonymizer import reset_config_cache
    reset_config_cache()


def _get_default() -> Anonymizer:
    global _default_anonymizer
    if _default_anonymizer is None:
        _default_anonymizer = Anonymizer(model=_default_model)
    return _default_anonymizer


def anonymize(
    text: str,
    entities: list[str] | None = None,
    score_threshold: float | None = None,
) -> AnonymizationResult:
    """Anonymize *text* using a shared module-level Anonymizer instance.

    Call :func:`configure` first if you need to change the NLP model.
    """
    return _get_default().anonymize(text, entities=entities, score_threshold=score_threshold)


def deanonymize(text: str, mapping: dict[str, str]) -> str:
    """Restore original values in *text* using *mapping*."""
    return _get_default().deanonymize(text, mapping)
