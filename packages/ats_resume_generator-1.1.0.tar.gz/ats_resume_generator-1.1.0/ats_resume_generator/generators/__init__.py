"""Resume generators (PDF, DOCX, Markdown, HTML, Text)."""
