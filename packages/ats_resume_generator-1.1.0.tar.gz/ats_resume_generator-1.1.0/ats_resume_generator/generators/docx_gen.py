"""Word Document (DOCX) Resume Generator."""

from __future__ import annotations

from pathlib import Path

from docx import Document
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.shared import Inches, Pt, RGBColor

from ..models import ResumeData


def generate_docx(resume: ResumeData, output_path: str) -> str:
    """Generate an ATS-optimized Word document resume."""
    path = Path(output_path)
    path.parent.mkdir(parents=True, exist_ok=True)

    doc = Document()

    # Set narrow margins
    for section in doc.sections:
        section.left_margin = Inches(0.6)
        section.right_margin = Inches(0.6)
        section.top_margin = Inches(0.5)
        section.bottom_margin = Inches(0.5)

    # Set default font
    style = doc.styles["Normal"]
    font = style.font
    font.name = "Calibri"
    font.size = Pt(10)
    font.color.rgb = RGBColor(0x29, 0x29, 0x29)

    # Header — Name
    name_para = doc.add_paragraph()
    name_para.alignment = WD_ALIGN_PARAGRAPH.LEFT
    name_run = name_para.add_run(resume.contact.name)
    name_run.font.size = Pt(20)
    name_run.font.bold = True
    name_run.font.color.rgb = RGBColor(0x1A, 0x1A, 0x1A)

    # Contact line
    contact_parts = []
    if resume.contact.email:
        contact_parts.append(resume.contact.email)
    if resume.contact.phone:
        contact_parts.append(resume.contact.phone)
    if resume.contact.location:
        contact_parts.append(resume.contact.location)

    if contact_parts:
        contact_para = doc.add_paragraph(" | ".join(contact_parts))
        contact_para.paragraph_format.space_after = Pt(0)
        for run in contact_para.runs:
            run.font.size = Pt(9)
            run.font.color.rgb = RGBColor(0x55, 0x55, 0x55)

    # Links line
    link_parts = []
    if resume.contact.linkedin:
        link_parts.append(resume.contact.linkedin)
    if resume.contact.github:
        link_parts.append(resume.contact.github)
    if resume.contact.website:
        link_parts.append(resume.contact.website)

    if link_parts:
        links_para = doc.add_paragraph(" | ".join(link_parts))
        links_para.paragraph_format.space_after = Pt(4)
        for run in links_para.runs:
            run.font.size = Pt(9)
            run.font.color.rgb = RGBColor(0x55, 0x55, 0x55)

    # Professional Summary
    if resume.summary:
        _add_section_header(doc, "PROFESSIONAL SUMMARY")
        summary_para = doc.add_paragraph(resume.summary)
        summary_para.paragraph_format.space_after = Pt(6)
        for run in summary_para.runs:
            run.font.size = Pt(10)

    # Work Experience
    if resume.experience:
        _add_section_header(doc, "WORK EXPERIENCE")
        for exp in resume.experience:
            # Title and company
            title_para = doc.add_paragraph()
            title_para.paragraph_format.space_after = Pt(0)
            title_run = title_para.add_run(f"{exp.title}")
            title_run.bold = True
            title_run.font.size = Pt(10.5)
            title_para.add_run(f" | {exp.company}").font.size = Pt(10.5)

            # Date and location
            meta_parts = []
            if exp.location:
                meta_parts.append(exp.location)
            date_str = exp.start_date
            if exp.end_date:
                date_str += f" – {exp.end_date}"
            meta_parts.append(date_str)

            meta_para = doc.add_paragraph(" | ".join(meta_parts))
            meta_para.paragraph_format.space_after = Pt(2)
            for run in meta_para.runs:
                run.font.size = Pt(9)
                run.font.color.rgb = RGBColor(0x55, 0x55, 0x55)

            # Bullets
            for bullet in exp.bullets:
                bullet_para = doc.add_paragraph(bullet, style="List Bullet")
                bullet_para.paragraph_format.space_after = Pt(1)
                for run in bullet_para.runs:
                    run.font.size = Pt(9.5)

            # Technologies
            if exp.technologies:
                tech_para = doc.add_paragraph()
                tech_para.paragraph_format.space_after = Pt(6)
                tech_run = tech_para.add_run(
                    f"Technologies: {', '.join(exp.technologies)}"
                )
                tech_run.font.size = Pt(8.5)
                tech_run.font.italic = True
                tech_run.font.color.rgb = RGBColor(0x55, 0x55, 0x55)

    # Skills
    if resume.skills:
        _add_section_header(doc, "TECHNICAL SKILLS")
        for group in resume.skills:
            skill_para = doc.add_paragraph()
            skill_para.paragraph_format.space_after = Pt(2)
            cat_run = skill_para.add_run(f"{group.category}: ")
            cat_run.bold = True
            cat_run.font.size = Pt(9.5)
            list_run = skill_para.add_run(", ".join(group.skills))
            list_run.font.size = Pt(9.5)

    # Certifications
    if resume.certifications:
        _add_section_header(doc, "CERTIFICATIONS")
        for cert in resume.certifications:
            cert_para = doc.add_paragraph()
            cert_para.paragraph_format.space_after = Pt(2)
            cert_run = cert_para.add_run(cert.name)
            cert_run.bold = True
            cert_run.font.size = Pt(9.5)
            if cert.issuer:
                cert_para.add_run(f" — {cert.issuer}").font.size = Pt(9.5)
            if cert.date:
                date_run = cert_para.add_run(f" ({cert.date})")
                date_run.font.size = Pt(9)
                date_run.font.color.rgb = RGBColor(0x55, 0x55, 0x55)

    # Projects
    if resume.projects:
        _add_section_header(doc, "PROJECTS")
        for proj in resume.projects:
            proj_para = doc.add_paragraph()
            proj_para.paragraph_format.space_after = Pt(1)
            proj_run = proj_para.add_run(proj.name)
            proj_run.bold = True
            proj_run.font.size = Pt(10)
            if proj.url:
                proj_para.add_run(f" | {proj.url}").font.size = Pt(9)

            if proj.description:
                desc_para = doc.add_paragraph(proj.description)
                desc_para.paragraph_format.space_after = Pt(1)
                for run in desc_para.runs:
                    run.font.size = Pt(9.5)

            for highlight in proj.highlights:
                h_para = doc.add_paragraph(highlight, style="List Bullet")
                h_para.paragraph_format.space_after = Pt(1)
                for run in h_para.runs:
                    run.font.size = Pt(9)

    # Education
    if resume.education:
        _add_section_header(doc, "EDUCATION")
        for edu in resume.education:
            edu_para = doc.add_paragraph()
            edu_para.paragraph_format.space_after = Pt(2)
            degree_text = edu.degree
            if edu.field_of_study:
                degree_text += f" in {edu.field_of_study}"
            edu_run = edu_para.add_run(degree_text)
            edu_run.bold = True
            edu_run.font.size = Pt(10)
            edu_para.add_run(f" — {edu.institution}").font.size = Pt(10)
            if edu.graduation_date:
                date_run = edu_para.add_run(f" ({edu.graduation_date})")
                date_run.font.size = Pt(9)
                date_run.font.color.rgb = RGBColor(0x55, 0x55, 0x55)
            if edu.gpa:
                edu_para.add_run(f" | GPA: {edu.gpa}").font.size = Pt(9)

    # Languages
    if resume.languages:
        _add_section_header(doc, "LANGUAGES")
        lang_para = doc.add_paragraph(" | ".join(resume.languages))
        for run in lang_para.runs:
            run.font.size = Pt(9.5)

    doc.save(str(path))
    return str(path)


def _add_section_header(doc: Document, title: str) -> None:
    """Add a section header with a horizontal line."""
    para = doc.add_paragraph()
    para.paragraph_format.space_before = Pt(8)
    para.paragraph_format.space_after = Pt(2)

    # Add bottom border for section separation
    run = para.add_run(title)
    run.font.size = Pt(11)
    run.font.bold = True
    run.font.color.rgb = RGBColor(0x1A, 0x1A, 0x1A)

    # Add thin line under the header using paragraph border
    from docx.oxml.ns import qn
    pPr = para._element.get_or_add_pPr()
    pBdr = pPr.makeelement(qn("w:pBdr"), {})
    bottom = pBdr.makeelement(qn("w:bottom"), {
        qn("w:val"): "single",
        qn("w:sz"): "4",
        qn("w:space"): "1",
        qn("w:color"): "CCCCCC",
    })
    pBdr.append(bottom)
    pPr.append(pBdr)
