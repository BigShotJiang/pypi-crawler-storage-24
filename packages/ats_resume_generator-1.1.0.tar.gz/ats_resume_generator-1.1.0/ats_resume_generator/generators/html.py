"""HTML Resume Generator — clean, ATS-friendly HTML."""

from __future__ import annotations

from pathlib import Path

from ..models import ResumeData


def generate_html(resume: ResumeData, output_path: str) -> str:
    """Generate an ATS-optimized HTML resume."""
    path = Path(output_path)
    path.parent.mkdir(parents=True, exist_ok=True)

    html = _build_html(resume)
    path.write_text(html, encoding="utf-8")
    return str(path)


def _build_html(resume: ResumeData) -> str:
    """Build complete HTML document."""
    sections: list[str] = []

    # Header
    sections.append(f'<h1>{_esc(resume.contact.name)}</h1>')

    contact_parts = []
    if resume.contact.email:
        contact_parts.append(resume.contact.email)
    if resume.contact.phone:
        contact_parts.append(resume.contact.phone)
    if resume.contact.location:
        contact_parts.append(resume.contact.location)
    if contact_parts:
        sections.append(
            f'<p class="contact">{" | ".join(_esc(p) for p in contact_parts)}</p>'
        )

    link_parts = []
    if resume.contact.linkedin:
        link_parts.append(resume.contact.linkedin)
    if resume.contact.github:
        link_parts.append(resume.contact.github)
    if resume.contact.website:
        link_parts.append(resume.contact.website)
    if link_parts:
        sections.append(
            f'<p class="contact">{" | ".join(_esc(p) for p in link_parts)}</p>'
        )

    # Summary
    if resume.summary:
        sections.append('<h2>Professional Summary</h2>')
        sections.append(f'<p>{_esc(resume.summary)}</p>')

    # Experience
    if resume.experience:
        sections.append('<h2>Work Experience</h2>')
        for exp in resume.experience:
            sections.append(
                f'<div class="exp"><h3>{_esc(exp.title)} | {_esc(exp.company)}</h3>'
            )
            meta_parts = []
            if exp.location:
                meta_parts.append(exp.location)
            date_str = f"{exp.start_date} – {exp.end_date}"
            meta_parts.append(date_str)
            sections.append(
                f'<p class="meta">{" | ".join(_esc(p) for p in meta_parts)}</p>'
            )
            sections.append('<ul>')
            for bullet in exp.bullets:
                sections.append(f'  <li>{_esc(bullet)}</li>')
            sections.append('</ul>')
            if exp.technologies:
                sections.append(
                    f'<p class="tech"><em>Technologies: '
                    f'{", ".join(_esc(t) for t in exp.technologies)}</em></p>'
                )
            sections.append('</div>')

    # Skills
    if resume.skills:
        sections.append('<h2>Technical Skills</h2>')
        for group in resume.skills:
            sections.append(
                f'<p><strong>{_esc(group.category)}:</strong> '
                f'{", ".join(_esc(s) for s in group.skills)}</p>'
            )

    # Certifications
    if resume.certifications:
        sections.append('<h2>Certifications</h2>')
        sections.append('<ul>')
        for cert in resume.certifications:
            cert_html = f'<strong>{_esc(cert.name)}</strong>'
            if cert.issuer:
                cert_html += f' — {_esc(cert.issuer)}'
            if cert.date:
                cert_html += f' ({_esc(cert.date)})'
            sections.append(f'  <li>{cert_html}</li>')
        sections.append('</ul>')

    # Projects
    if resume.projects:
        sections.append('<h2>Projects</h2>')
        for proj in resume.projects:
            proj_html = f'<strong>{_esc(proj.name)}</strong>'
            if proj.url:
                proj_html += f' | {_esc(proj.url)}'
            sections.append(f'<h3>{proj_html}</h3>')
            if proj.description:
                sections.append(f'<p>{_esc(proj.description)}</p>')
            if proj.highlights:
                sections.append('<ul>')
                for h in proj.highlights:
                    sections.append(f'  <li>{_esc(h)}</li>')
                sections.append('</ul>')

    # Education
    if resume.education:
        sections.append('<h2>Education</h2>')
        for edu in resume.education:
            edu_html = f'<strong>{_esc(edu.degree)}'
            if edu.field_of_study:
                edu_html += f' in {_esc(edu.field_of_study)}'
            edu_html += f'</strong> — {_esc(edu.institution)}'
            if edu.graduation_date:
                edu_html += f' ({_esc(edu.graduation_date)})'
            if edu.gpa:
                edu_html += f' | GPA: {_esc(edu.gpa)}'
            sections.append(f'<p>{edu_html}</p>')
            if edu.honors:
                sections.append(
                    f'<p class="meta">Honors: {", ".join(_esc(h) for h in edu.honors)}</p>'
                )

    # Languages
    if resume.languages:
        sections.append('<h2>Languages</h2>')
        sections.append(
            f'<p>{" | ".join(_esc(lang) for lang in resume.languages)}</p>'
        )

    body = "\n".join(sections)

    return f"""<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>{_esc(resume.contact.name)} — Resume</title>
  <style>
    body {{ max-width: 800px; margin: 30px auto; padding: 0 20px; font-family: Calibri, Arial, Helvetica, sans-serif; line-height: 1.5; color: #292929; font-size: 10.5pt; }}
    h1 {{ font-size: 22pt; margin-bottom: 2px; color: #1a1a1a; }}
    h2 {{ font-size: 12pt; margin-top: 16px; margin-bottom: 4px; border-bottom: 1px solid #ccc; padding-bottom: 2px; color: #1a1a1a; text-transform: uppercase; }}
    h3 {{ font-size: 11pt; margin-top: 8px; margin-bottom: 2px; }}
    p {{ margin: 4px 0; }}
    .contact {{ color: #555; font-size: 9.5pt; }}
    .meta {{ color: #555; font-size: 9pt; }}
    .tech {{ color: #555; font-size: 9pt; font-style: italic; }}
    ul {{ margin: 4px 0; padding-left: 20px; }}
    li {{ margin: 2px 0; font-size: 10pt; }}
    .exp {{ margin-bottom: 12px; }}
  </style>
</head>
<body>
{body}
</body>
</html>"""


def _esc(text: str) -> str:
    """Escape HTML special characters."""
    return (
        text.replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
        .replace('"', "&quot;")
    )
