"""Markdown Resume Generator."""

from __future__ import annotations

from pathlib import Path

from ..models import ResumeData


def generate_markdown(resume: ResumeData, output_path: str) -> str:
    """Generate an ATS-friendly Markdown resume."""
    path = Path(output_path)
    path.parent.mkdir(parents=True, exist_ok=True)

    lines: list[str] = []

    # Header
    lines.append(f"# {resume.contact.name}")
    lines.append("")

    contact_parts = []
    if resume.contact.email:
        contact_parts.append(f"📧 {resume.contact.email}")
    if resume.contact.phone:
        contact_parts.append(f"📱 {resume.contact.phone}")
    if resume.contact.location:
        contact_parts.append(f"📍 {resume.contact.location}")
    if contact_parts:
        lines.append(" | ".join(contact_parts))
        lines.append("")

    link_parts = []
    if resume.contact.linkedin:
        link_parts.append(f"[LinkedIn]({resume.contact.linkedin})")
    if resume.contact.github:
        link_parts.append(f"[GitHub]({resume.contact.github})")
    if resume.contact.website:
        link_parts.append(f"[Website]({resume.contact.website})")
    if resume.contact.portfolio:
        link_parts.append(f"[Portfolio]({resume.contact.portfolio})")
    if link_parts:
        lines.append(" | ".join(link_parts))
        lines.append("")

    lines.append("---")
    lines.append("")

    # Professional Summary
    if resume.summary:
        lines.append("## Professional Summary")
        lines.append("")
        lines.append(resume.summary)
        lines.append("")

    # Work Experience
    if resume.experience:
        lines.append("## Work Experience")
        lines.append("")
        for exp in resume.experience:
            date_str = f"{exp.start_date} – {exp.end_date}"
            lines.append(f"### {exp.title} | {exp.company}")
            meta_parts = []
            if exp.location:
                meta_parts.append(exp.location)
            meta_parts.append(date_str)
            lines.append(f"*{' | '.join(meta_parts)}*")
            lines.append("")

            for bullet in exp.bullets:
                lines.append(f"- {bullet}")
            lines.append("")

            if exp.technologies:
                lines.append(
                    f"**Technologies:** {', '.join(exp.technologies)}"
                )
                lines.append("")

    # Technical Skills
    if resume.skills:
        lines.append("## Technical Skills")
        lines.append("")
        for group in resume.skills:
            lines.append(
                f"- **{group.category}:** {', '.join(group.skills)}"
            )
        lines.append("")

    # Certifications
    if resume.certifications:
        lines.append("## Certifications")
        lines.append("")
        for cert in resume.certifications:
            cert_text = f"- **{cert.name}**"
            if cert.issuer:
                cert_text += f" — {cert.issuer}"
            if cert.date:
                cert_text += f" ({cert.date})"
            lines.append(cert_text)
        lines.append("")

    # Projects
    if resume.projects:
        lines.append("## Projects")
        lines.append("")
        for proj in resume.projects:
            proj_title = f"### {proj.name}"
            if proj.url:
                proj_title += f" | [{proj.url}]({proj.url})"
            lines.append(proj_title)
            lines.append("")
            if proj.description:
                lines.append(proj.description)
                lines.append("")
            for highlight in proj.highlights:
                lines.append(f"- {highlight}")
            lines.append("")

    # Education
    if resume.education:
        lines.append("## Education")
        lines.append("")
        for edu in resume.education:
            edu_text = f"**{edu.degree}"
            if edu.field_of_study:
                edu_text += f" in {edu.field_of_study}"
            edu_text += f"** — {edu.institution}"
            if edu.graduation_date:
                edu_text += f" ({edu.graduation_date})"
            if edu.gpa:
                edu_text += f" | GPA: {edu.gpa}"
            lines.append(edu_text)
            if edu.honors:
                lines.append(f"*Honors: {', '.join(edu.honors)}*")
            lines.append("")

    # Languages
    if resume.languages:
        lines.append("## Languages")
        lines.append("")
        lines.append(" | ".join(resume.languages))
        lines.append("")

    content = "\n".join(lines)
    path.write_text(content, encoding="utf-8")
    return str(path)
