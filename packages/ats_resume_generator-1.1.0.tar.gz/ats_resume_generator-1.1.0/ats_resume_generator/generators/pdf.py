"""Professional PDF Resume Generator — clean, modern, ATS-optimized."""

from __future__ import annotations

from pathlib import Path

from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER, TA_RIGHT
from reportlab.lib.pagesizes import letter
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import inch
from reportlab.platypus import (
    HRFlowable,
    Paragraph,
    SimpleDocTemplate,
    Spacer,
    Table,
    TableStyle,
)

from ..models import ResumeData

# ── Color palette ─────────────────────────────────────────────────────────
_NAVY = colors.HexColor("#1B2A4A")
_ACCENT = colors.HexColor("#2563EB")
_DARK = colors.HexColor("#1a1a1a")
_MID = colors.HexColor("#374151")
_LIGHT = colors.HexColor("#6B7280")
_RULE = colors.HexColor("#D1D5DB")
_BG_ACCENT = colors.HexColor("#EFF6FF")


def generate_pdf(resume: ResumeData, output_path: str) -> str:
    """Generate a professional, ATS-optimized PDF resume."""
    path = Path(output_path)
    path.parent.mkdir(parents=True, exist_ok=True)

    doc = SimpleDocTemplate(
        str(path),
        pagesize=letter,
        leftMargin=0.65 * inch,
        rightMargin=0.65 * inch,
        topMargin=0.45 * inch,
        bottomMargin=0.45 * inch,
    )

    styles = _create_styles()
    story: list = []

    # ── Header ────────────────────────────────────────────────────────
    _add_header(story, resume, styles)

    # ── Professional Summary ──────────────────────────────────────────
    if resume.summary:
        _add_section_title(story, "PROFESSIONAL SUMMARY", styles)
        story.append(Paragraph(resume.summary, styles["summary_body"]))
        story.append(Spacer(1, 6))

    # ── Work Experience ───────────────────────────────────────────────
    if resume.experience:
        _add_section_title(story, "PROFESSIONAL EXPERIENCE", styles)
        for i, exp in enumerate(resume.experience):
            _add_experience(story, exp, styles)
            if i < len(resume.experience) - 1:
                story.append(Spacer(1, 5))

    # ── Technical Skills ──────────────────────────────────────────────
    if resume.skills:
        _add_section_title(story, "TECHNICAL SKILLS", styles)
        _add_skills_table(story, resume, styles)

    # ── Certifications ────────────────────────────────────────────────
    if resume.certifications:
        _add_section_title(story, "CERTIFICATIONS", styles)
        for cert in resume.certifications:
            _add_certification(story, cert, styles)

    # ── Projects ──────────────────────────────────────────────────────
    if resume.projects:
        _add_section_title(story, "PROJECTS", styles)
        for proj in resume.projects:
            _add_project(story, proj, styles)

    # ── Education ─────────────────────────────────────────────────────
    if resume.education:
        _add_section_title(story, "EDUCATION", styles)
        for edu in resume.education:
            _add_education(story, edu, styles)

    # ── Languages ─────────────────────────────────────────────────────
    if resume.languages:
        _add_section_title(story, "LANGUAGES", styles)
        story.append(
            Paragraph(" · ".join(resume.languages), styles["body"])
        )

    doc.build(story)
    return str(path)


# ── Styles ────────────────────────────────────────────────────────────────

def _create_styles() -> dict[str, ParagraphStyle]:
    """Create professional paragraph styles."""
    base = getSampleStyleSheet()
    s: dict[str, ParagraphStyle] = {}
    font = "Helvetica"
    bold = "Helvetica-Bold"
    oblique = "Helvetica-Oblique"

    s["name"] = ParagraphStyle(
        "Name", parent=base["Normal"],
        fontName=bold, fontSize=22, leading=26,
        alignment=TA_CENTER, textColor=_NAVY,
        spaceAfter=2,
    )
    s["contact_line"] = ParagraphStyle(
        "ContactLine", parent=base["Normal"],
        fontName=font, fontSize=9.5, leading=13,
        alignment=TA_CENTER, textColor=_LIGHT,
    )
    s["links_line"] = ParagraphStyle(
        "LinksLine", parent=base["Normal"],
        fontName=font, fontSize=9, leading=12,
        alignment=TA_CENTER, textColor=_ACCENT,
    )
    s["section_title"] = ParagraphStyle(
        "SectionTitle", parent=base["Normal"],
        fontName=bold, fontSize=11, leading=14,
        spaceBefore=10, spaceAfter=3,
        textColor=_NAVY, letterSpacing=1.5,
    )
    s["summary_body"] = ParagraphStyle(
        "SummaryBody", parent=base["Normal"],
        fontName=font, fontSize=10, leading=14,
        textColor=_MID, spaceAfter=2,
    )
    s["exp_title_left"] = ParagraphStyle(
        "ExpTitleLeft", parent=base["Normal"],
        fontName=bold, fontSize=10.5, leading=13,
        textColor=_DARK,
    )
    s["exp_title_right"] = ParagraphStyle(
        "ExpTitleRight", parent=base["Normal"],
        fontName=font, fontSize=9.5, leading=13,
        alignment=TA_RIGHT, textColor=_LIGHT,
    )
    s["exp_company"] = ParagraphStyle(
        "ExpCompany", parent=base["Normal"],
        fontName=oblique, fontSize=9.5, leading=12,
        textColor=_MID, spaceAfter=3,
    )
    s["bullet"] = ParagraphStyle(
        "Bullet", parent=base["Normal"],
        fontName=font, fontSize=9.5, leading=13,
        leftIndent=14, spaceAfter=2,
        textColor=_DARK,
    )
    s["tech_line"] = ParagraphStyle(
        "TechLine", parent=base["Normal"],
        fontName=oblique, fontSize=8.5, leading=11,
        leftIndent=14, textColor=_LIGHT,
        spaceBefore=1, spaceAfter=1,
    )
    s["body"] = ParagraphStyle(
        "Body", parent=base["Normal"],
        fontName=font, fontSize=9.5, leading=13,
        textColor=_DARK, spaceAfter=2,
    )
    s["body_bold"] = ParagraphStyle(
        "BodyBold", parent=base["Normal"],
        fontName=bold, fontSize=9.5, leading=13,
        textColor=_DARK,
    )
    s["body_small"] = ParagraphStyle(
        "BodySmall", parent=base["Normal"],
        fontName=font, fontSize=8.5, leading=11,
        textColor=_LIGHT,
    )
    s["skill_cat"] = ParagraphStyle(
        "SkillCat", parent=base["Normal"],
        fontName=bold, fontSize=9, leading=12,
        textColor=_NAVY,
    )
    s["skill_items"] = ParagraphStyle(
        "SkillItems", parent=base["Normal"],
        fontName=font, fontSize=9, leading=12,
        textColor=_MID,
    )
    return s


# ── Component builders ───────────────────────────────────────────────────

def _add_header(
    story: list, resume: ResumeData, styles: dict[str, ParagraphStyle]
) -> None:
    """Add a centered, professional header."""
    if resume.contact.name:
        story.append(Paragraph(resume.contact.name.upper(), styles["name"]))

    # Contact line: email | phone | location
    parts: list[str] = []
    if resume.contact.email:
        parts.append(resume.contact.email)
    if resume.contact.phone:
        parts.append(resume.contact.phone)
    if resume.contact.location:
        parts.append(resume.contact.location)
    if parts:
        story.append(
            Paragraph("  ·  ".join(parts), styles["contact_line"])
        )

    # Links line: LinkedIn | GitHub | website
    links: list[str] = []
    if resume.contact.linkedin:
        links.append(resume.contact.linkedin)
    if resume.contact.github:
        links.append(resume.contact.github)
    if resume.contact.website:
        links.append(resume.contact.website)
    if resume.contact.portfolio:
        links.append(resume.contact.portfolio)
    if links:
        story.append(
            Paragraph("  |  ".join(links), styles["links_line"])
        )

    story.append(Spacer(1, 4))
    story.append(
        HRFlowable(
            width="100%", thickness=1.5, color=_NAVY,
            spaceAfter=2, spaceBefore=2,
        )
    )


def _add_section_title(
    story: list, title: str, styles: dict[str, ParagraphStyle]
) -> None:
    """Add a section title with a clean underline."""
    story.append(Spacer(1, 4))
    story.append(Paragraph(title, styles["section_title"]))
    story.append(
        HRFlowable(
            width="100%", thickness=0.75, color=_RULE,
            spaceAfter=4, spaceBefore=0,
        )
    )


def _add_experience(
    story: list, exp, styles: dict[str, ParagraphStyle]
) -> None:
    """Add a work experience entry with aligned title/date row."""
    # Title row: Title — Company  |  Date range (right-aligned)
    date_str = ""
    if exp.start_date:
        date_str = exp.start_date
        if exp.end_date:
            date_str += f" – {exp.end_date}"

    # Two-column table for title + date alignment
    title_text = Paragraph(
        f"<b>{_esc(exp.title)}</b>", styles["exp_title_left"]
    )
    date_text = Paragraph(date_str, styles["exp_title_right"])
    col_w = [4.5 * inch, 2.4 * inch]
    title_tbl = Table([[title_text, date_text]], colWidths=col_w)
    title_tbl.setStyle(TableStyle([
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("LEFTPADDING", (0, 0), (-1, -1), 0),
        ("RIGHTPADDING", (0, 0), (-1, -1), 0),
        ("TOPPADDING", (0, 0), (-1, -1), 0),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 0),
    ]))
    story.append(title_tbl)

    # Company + location
    company_parts: list[str] = []
    if exp.company:
        company_parts.append(exp.company)
    if exp.location:
        company_parts.append(exp.location)
    if company_parts:
        story.append(
            Paragraph(
                " · ".join(company_parts), styles["exp_company"]
            )
        )

    # Bullet points
    for bullet in exp.bullets:
        story.append(
            Paragraph(f"▪  {_esc(bullet)}", styles["bullet"])
        )

    # Technologies
    if exp.technologies:
        story.append(
            Paragraph(
                f"Tech Stack: {', '.join(exp.technologies)}",
                styles["tech_line"],
            )
        )


def _add_skills_table(
    story: list, resume: ResumeData, styles: dict[str, ParagraphStyle]
) -> None:
    """Add skills in a clean two-column table layout."""
    if not resume.skills:
        return

    rows: list[list] = []
    for group in resume.skills:
        cat = Paragraph(
            f"<b>{_esc(group.category)}</b>", styles["skill_cat"]
        )
        items = Paragraph(
            ", ".join(group.skills), styles["skill_items"]
        )
        rows.append([cat, items])

    if not rows:
        return

    tbl = Table(rows, colWidths=[2.0 * inch, 4.9 * inch])
    tbl.setStyle(TableStyle([
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("LEFTPADDING", (0, 0), (0, -1), 0),
        ("LEFTPADDING", (1, 0), (1, -1), 8),
        ("RIGHTPADDING", (0, 0), (-1, -1), 0),
        ("TOPPADDING", (0, 0), (-1, -1), 2),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 2),
        ("LINEBELOW", (0, 0), (-1, -2), 0.25, _RULE),
    ]))
    story.append(tbl)
    story.append(Spacer(1, 2))


def _add_certification(story: list, cert, styles) -> None:
    """Add a certification entry."""
    parts = [f"<b>{_esc(cert.name)}</b>"]
    if cert.issuer:
        parts.append(f" — {_esc(cert.issuer)}")
    if cert.date:
        parts.append(f"  ({cert.date})")
    story.append(Paragraph("".join(parts), styles["body"]))


def _add_project(story: list, proj, styles) -> None:
    """Add a project entry."""
    title = f"<b>{_esc(proj.name)}</b>"
    if proj.url:
        title += f"  |  <font color='#2563EB'>{_esc(proj.url)}</font>"
    story.append(Paragraph(title, styles["body_bold"]))

    if proj.description:
        story.append(Paragraph(_esc(proj.description), styles["body_small"]))

    for h in proj.highlights:
        story.append(Paragraph(f"▪  {_esc(h)}", styles["bullet"]))

    story.append(Spacer(1, 3))


def _add_education(story: list, edu, styles) -> None:
    """Add an education entry."""
    line = f"<b>{_esc(edu.degree)}"
    if edu.field_of_study:
        line += f" in {_esc(edu.field_of_study)}"
    line += "</b>"
    if edu.institution:
        line += f" — {_esc(edu.institution)}"
    if edu.graduation_date:
        line += f"  ({edu.graduation_date})"
    if edu.gpa:
        line += f"  |  GPA: {edu.gpa}"
    story.append(Paragraph(line, styles["body"]))

    if edu.honors:
        story.append(
            Paragraph(
                f"Honors: {', '.join(edu.honors)}",
                styles["body_small"],
            )
        )


def _esc(text: str) -> str:
    """Escape XML special characters for ReportLab."""
    return (
        text.replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
    )
