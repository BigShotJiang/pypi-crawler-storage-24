"""Plain Text Resume Generator."""

from __future__ import annotations

from pathlib import Path

from ..models import ResumeData


def generate_text(resume: ResumeData, output_path: str) -> str:
    """Generate a plain text resume."""
    path = Path(output_path)
    path.parent.mkdir(parents=True, exist_ok=True)

    lines: list[str] = []
    separator = "=" * 60

    # Header
    lines.append(resume.contact.name.upper())
    lines.append(separator)

    contact_parts = []
    if resume.contact.email:
        contact_parts.append(f"Email: {resume.contact.email}")
    if resume.contact.phone:
        contact_parts.append(f"Phone: {resume.contact.phone}")
    if resume.contact.location:
        contact_parts.append(f"Location: {resume.contact.location}")
    lines.extend(contact_parts)

    link_parts = []
    if resume.contact.linkedin:
        link_parts.append(f"LinkedIn: {resume.contact.linkedin}")
    if resume.contact.github:
        link_parts.append(f"GitHub: {resume.contact.github}")
    if resume.contact.website:
        link_parts.append(f"Website: {resume.contact.website}")
    lines.extend(link_parts)
    lines.append("")

    # Summary
    if resume.summary:
        lines.append("PROFESSIONAL SUMMARY")
        lines.append("-" * 40)
        lines.append(resume.summary)
        lines.append("")

    # Experience
    if resume.experience:
        lines.append("WORK EXPERIENCE")
        lines.append("-" * 40)
        for exp in resume.experience:
            lines.append(f"{exp.title} | {exp.company}")
            meta_parts = []
            if exp.location:
                meta_parts.append(exp.location)
            date_str = f"{exp.start_date} - {exp.end_date}"
            meta_parts.append(date_str)
            lines.append(" | ".join(meta_parts))
            lines.append("")
            for bullet in exp.bullets:
                # Wrap long bullets
                wrapped = _wrap_text(f"  * {bullet}", 72)
                lines.append(wrapped)
            if exp.technologies:
                lines.append(
                    f"  Technologies: {', '.join(exp.technologies)}"
                )
            lines.append("")

    # Skills
    if resume.skills:
        lines.append("TECHNICAL SKILLS")
        lines.append("-" * 40)
        for group in resume.skills:
            lines.append(f"  {group.category}: {', '.join(group.skills)}")
        lines.append("")

    # Certifications
    if resume.certifications:
        lines.append("CERTIFICATIONS")
        lines.append("-" * 40)
        for cert in resume.certifications:
            cert_text = f"  * {cert.name}"
            if cert.issuer:
                cert_text += f" - {cert.issuer}"
            if cert.date:
                cert_text += f" ({cert.date})"
            lines.append(cert_text)
        lines.append("")

    # Projects
    if resume.projects:
        lines.append("PROJECTS")
        lines.append("-" * 40)
        for proj in resume.projects:
            proj_text = f"  {proj.name}"
            if proj.url:
                proj_text += f" | {proj.url}"
            lines.append(proj_text)
            if proj.description:
                lines.append(f"    {proj.description}")
            for h in proj.highlights:
                lines.append(f"    * {h}")
            lines.append("")

    # Education
    if resume.education:
        lines.append("EDUCATION")
        lines.append("-" * 40)
        for edu in resume.education:
            edu_text = f"  {edu.degree}"
            if edu.field_of_study:
                edu_text += f" in {edu.field_of_study}"
            edu_text += f" - {edu.institution}"
            if edu.graduation_date:
                edu_text += f" ({edu.graduation_date})"
            if edu.gpa:
                edu_text += f" | GPA: {edu.gpa}"
            lines.append(edu_text)
            if edu.honors:
                lines.append(f"    Honors: {', '.join(edu.honors)}")
        lines.append("")

    # Languages
    if resume.languages:
        lines.append("LANGUAGES")
        lines.append("-" * 40)
        lines.append(f"  {' | '.join(resume.languages)}")
        lines.append("")

    content = "\n".join(lines)
    path.write_text(content, encoding="utf-8")
    return str(path)


def _wrap_text(text: str, width: int) -> str:
    """Simple text wrapping."""
    if len(text) <= width:
        return text
    # Find last space before width
    words = text.split()
    current_line = ""
    result_lines = []
    indent = "    "

    for word in words:
        if current_line and len(current_line) + len(word) + 1 > width:
            result_lines.append(current_line)
            current_line = indent + word
        else:
            if current_line:
                current_line += " " + word
            else:
                current_line = word

    if current_line:
        result_lines.append(current_line)

    return "\n".join(result_lines)
