"""Multi-format resume parser — YAML, JSON, PDF, DOCX, TXT, MD, HTML."""

from __future__ import annotations

import re
from pathlib import Path
from typing import Any

import yaml

from .models import (
    Certification,
    ContactInfo,
    Education,
    Experience,
    Project,
    ResumeData,
    SkillGroup,
)

# Supported input file extensions
_YAML_EXTS = {".yaml", ".yml", ".json"}
_TEXT_EXTS = {".txt", ".md", ".markdown"}
_HTML_EXTS = {".html", ".htm"}
_PDF_EXT = ".pdf"
_DOCX_EXT = ".docx"


def parse_resume_file(file_path: str) -> ResumeData:
    """Parse a resume from YAML, JSON, PDF, DOCX, TXT, MD, or HTML."""
    path = Path(file_path)
    if not path.exists():
        raise FileNotFoundError(f"Resume file not found: {file_path}")

    ext = path.suffix.lower()

    if ext in _YAML_EXTS:
        return _parse_yaml_file(path)
    elif ext == _PDF_EXT:
        return _parse_pdf_file(path)
    elif ext == _DOCX_EXT:
        return _parse_docx_file(path)
    elif ext in _HTML_EXTS:
        return _parse_html_file(path)
    elif ext in _TEXT_EXTS:
        return _parse_text_file(path)
    else:
        # Try YAML first, then text
        try:
            return _parse_yaml_file(path)
        except (ValueError, yaml.YAMLError):
            return _parse_text_file(path)


# ── YAML / JSON ──────────────────────────────────────────────────────────

def _parse_yaml_file(path: Path) -> ResumeData:
    """Parse YAML/JSON resume."""
    with open(path, encoding="utf-8") as f:
        data = yaml.safe_load(f)
    if not isinstance(data, dict):
        raise ValueError(
            "Resume file must contain a YAML/JSON object at the top level."
        )
    return parse_resume_dict(data)


# ── PDF ───────────────────────────────────────────────────────────────────

def _parse_pdf_file(path: Path) -> ResumeData:
    """Extract text from PDF and parse into ResumeData."""
    try:
        import fitz  # PyMuPDF
    except ImportError:
        raise ImportError(
            "PDF parsing requires PyMuPDF. Install with: "
            "pip install pymupdf"
        )

    doc = fitz.open(str(path))
    lines: list[str] = []
    for page in doc:
        text = page.get_text("text")
        lines.extend(text.splitlines())
    doc.close()
    return _parse_lines(lines)


# ── DOCX ──────────────────────────────────────────────────────────────────

def _parse_docx_file(path: Path) -> ResumeData:
    """Extract text from DOCX and parse into ResumeData."""
    try:
        from docx import Document
    except ImportError:
        raise ImportError(
            "DOCX parsing requires python-docx. Install with: "
            "pip install python-docx"
        )

    doc = Document(str(path))
    lines = [p.text for p in doc.paragraphs if p.text.strip()]
    return _parse_lines(lines)


# ── HTML ──────────────────────────────────────────────────────────────────

def _parse_html_file(path: Path) -> ResumeData:
    """Strip HTML tags and parse as text."""
    raw = path.read_text(encoding="utf-8")
    text = re.sub(r"<[^>]+>", "\n", raw)
    text = re.sub(r"&[a-zA-Z]+;", " ", text)
    lines = [ln.strip() for ln in text.splitlines() if ln.strip()]
    return _parse_lines(lines)


# ── TXT / MD ─────────────────────────────────────────────────────────────

def _parse_text_file(path: Path) -> ResumeData:
    """Parse plain text or Markdown resume."""
    raw = path.read_text(encoding="utf-8")
    lines = [ln.strip() for ln in raw.splitlines() if ln.strip()]
    # Strip markdown headers
    cleaned: list[str] = []
    for line in lines:
        line = re.sub(r"^#{1,6}\s*", "", line)
        line = re.sub(r"\*\*(.+?)\*\*", r"\1", line)  # bold
        line = re.sub(r"\*(.+?)\*", r"\1", line)  # italic
        line = re.sub(r"^[-*•]\s*", "", line)  # bullets
        if line.strip():
            cleaned.append(line.strip())
    return _parse_lines(cleaned)


# ── Intelligent line-based parser ─────────────────────────────────────────

# Section header patterns
_SECTION_PATTERNS = {
    "summary": re.compile(
        r"^(?:professional\s+)?summary|^(?:career\s+)?objective|^profile|^about",
        re.IGNORECASE,
    ),
    "experience": re.compile(
        r"^(?:work\s+|professional\s+)?experience|^employment|^career\s+history|^work\s+history",
        re.IGNORECASE,
    ),
    "education": re.compile(
        r"^education|^academic|^qualifications", re.IGNORECASE
    ),
    "skills": re.compile(
        r"^(?:technical\s+)?skills|^competencies|^technologies|^core\s+competencies",
        re.IGNORECASE,
    ),
    "certifications": re.compile(
        r"^certifications?|^professional\s+certifications?|^licenses?",
        re.IGNORECASE,
    ),
    "projects": re.compile(
        r"^projects?|^personal\s+projects?|^open\s+source", re.IGNORECASE
    ),
    "languages": re.compile(
        r"^languages?|^spoken\s+languages?", re.IGNORECASE
    ),
}

_EMAIL_RE = re.compile(r"[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}")
_PHONE_RE = re.compile(
    r"(?:\+?\d{1,3}[-.\s]?)?\(?\d{2,4}\)?[-.\s]?\d{3,4}[-.\s]?\d{3,4}"
)
_LINKEDIN_RE = re.compile(r"linkedin\.com/in/[\w-]+", re.IGNORECASE)
_GITHUB_RE = re.compile(r"github\.com/[\w-]+", re.IGNORECASE)
_URL_RE = re.compile(r"https?://[^\s,]+|[\w-]+\.(?:com|dev|io|org)/[\w/-]+")
_DATE_RE = re.compile(
    r"(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]*"
    r"\.?\s+\d{4}|"
    r"\d{4}\s*[-\u2013\u2014\u00fb\u2012]\s*(?:\d{4}|Present|Current|Now)",
    re.IGNORECASE,
)
_DATE_RANGE_RE = re.compile(
    r"((?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]*\.?\s+\d{4})"
    r"\s*[-\u2013\u2014\u00fb\u2012\u00ad]\s*"
    r"((?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]*\.?\s+\d{4}|Present|Current|Now)",
    re.IGNORECASE,
)
_DEGREE_RE = re.compile(
    r"(?:Bachelor|Master|Doctor|PhD|B\.?S\.?|B\.?E\.?|B\.?A\.?|"
    r"M\.?S\.?|M\.?A\.?|M\.?B\.?A\.?|Associate)",
    re.IGNORECASE,
)
_CERT_ISSUERS = [
    "AWS", "Amazon", "Microsoft", "Google", "Azure", "CNCF",
    "Hashicorp", "Red Hat", "Oracle", "Cisco", "CompTIA", "Linux Foundation",
    "Kubernetes", "Certified", "PMI", "PMP", "Scrum", "ITIL",
]
_JOB_TITLE_RE = re.compile(
    r"(?:Senior|Lead|Principal|Staff|Junior|Mid|Sr\.?|Jr\.?)?\s*"
    r"(?:Software|DevOps|Cloud|Data|ML|Full\s*Stack|Backend|Frontend|"
    r"Site\s+Reliability|Platform|Infrastructure|Systems|Solutions|"
    r"Security|Product)\s*"
    r"(?:Engineer|Developer|Architect|Manager|Analyst|Administrator|"
    r"Specialist|Consultant|SRE|Ops)",
    re.IGNORECASE,
)


def _parse_lines(lines: list[str]) -> ResumeData:
    """Parse resume text lines into structured ResumeData."""
    resume = ResumeData()
    if not lines:
        return resume

    # Extract contact info from top lines (usually first 5-10 lines)
    resume.contact = _extract_contact(lines[:15])

    # Split into sections
    sections = _split_sections(lines)

    # Parse each section
    if "summary" in sections:
        resume.summary = " ".join(sections["summary"])

    if "experience" in sections:
        resume.experience = _extract_experience(sections["experience"])

    if "education" in sections:
        resume.education = _extract_education(sections["education"])

    if "skills" in sections:
        resume.skills = _extract_skills(sections["skills"])

    if "certifications" in sections:
        resume.certifications = _extract_certifications(
            sections["certifications"]
        )

    if "projects" in sections:
        resume.projects = _extract_projects(sections["projects"])

    if "languages" in sections:
        langs_text = " ".join(sections["languages"])
        resume.languages = [
            ln.strip() for ln in re.split(r"[|,;]", langs_text)
            if ln.strip() and len(ln.strip()) < 30
        ]

    # Infer years of experience
    if resume.experience:
        resume.years_of_experience = _estimate_years(resume.experience)

    return resume


def _extract_contact(lines: list[str]) -> ContactInfo:
    """Extract contact details from the top of the resume."""
    block = "\n".join(lines)
    contact = ContactInfo()

    # Name is usually the first non-empty, non-contact line
    for line in lines:
        clean = line.strip().strip("=").strip("-").strip("#").strip()
        if not clean:
            continue
        # Skip lines that are clearly contact info
        if _EMAIL_RE.search(clean) or _PHONE_RE.search(clean):
            continue
        if "linkedin" in clean.lower() or "github" in clean.lower():
            continue
        if len(clean) < 50 and not any(c.isdigit() for c in clean[:5]):
            contact.name = clean
            break

    email = _EMAIL_RE.search(block)
    if email:
        contact.email = email.group()

    phone = _PHONE_RE.search(block)
    if phone:
        contact.phone = phone.group().strip()

    linkedin = _LINKEDIN_RE.search(block)
    if linkedin:
        contact.linkedin = linkedin.group()

    github = _GITHUB_RE.search(block)
    if github:
        contact.github = github.group()

    # Location: look for City, ST pattern
    loc_re = re.compile(
        r"([A-Z][a-z]+(?:\s[A-Z][a-z]+)*,\s*[A-Z]{2}(?:\s\d{5})?)"
    )
    loc = loc_re.search(block)
    if loc:
        contact.location = loc.group(1)

    return contact


def _split_sections(lines: list[str]) -> dict[str, list[str]]:
    """Split lines into named sections."""
    sections: dict[str, list[str]] = {}
    current: str | None = None
    buffer: list[str] = []

    for line in lines:
        clean = line.strip().strip("=").strip("-").strip("#").strip()
        if not clean:
            continue

        # Check if this line is a section header
        matched_section = None
        for name, pattern in _SECTION_PATTERNS.items():
            if pattern.match(clean):
                matched_section = name
                break

        if matched_section:
            if current and buffer:
                sections[current] = buffer
            current = matched_section
            buffer = []
        elif current:
            buffer.append(clean)

    if current and buffer:
        sections[current] = buffer

    return sections


def _extract_experience(lines: list[str]) -> list[Experience]:
    """Extract work experience from section lines."""
    experiences: list[Experience] = []
    current: Experience | None = None

    i = 0
    while i < len(lines):
        line = lines[i]

        # Skip separators
        if all(c in "-=_·" for c in line.replace(" ", "")):
            i += 1
            continue

        # Check for date range
        date_match = _DATE_RANGE_RE.search(line)
        title_match = _JOB_TITLE_RE.search(line)

        # If this is a standalone date line, attach to current exp
        if date_match and current and not current.start_date:
            current.start_date = date_match.group(1)
            current.end_date = date_match.group(2)
            # Remaining text after date might be company/location
            leftover = (
                line[:date_match.start()] + line[date_match.end():]
            ).strip().strip("|·").strip()
            if leftover and not current.company:
                current.company = leftover
            i += 1
            continue

        # New experience: job title line or date line starting a block
        is_title_line = (
            title_match
            and not line.startswith("•")
            and not line.startswith("▪")
            and not line.startswith("I ")
        )
        is_new_block = (
            date_match
            and not (current and not current.start_date)
        )

        if is_title_line or is_new_block:
            if current and (current.title or current.company):
                experiences.append(current)
            current = Experience()

            if date_match:
                current.start_date = date_match.group(1)
                current.end_date = date_match.group(2)
                no_date = (
                    line[:date_match.start()] + line[date_match.end():]
                ).strip().strip("|·").strip()
            else:
                no_date = line

            # Parse title and company
            parts = re.split(r"\s*[|–—·]\s*", no_date)
            if parts:
                current.title = parts[0].strip()
                if len(parts) > 1:
                    current.company = parts[1].strip()

            i += 1
            continue

        if current:
            # Company/location line (contains city, state pattern)
            loc_m = re.search(
                r"^(.+?)\s*[·|\u2561\u00b7\u2022]\s*([A-Z][a-z]+(?:\s[A-Z][a-z]+)*"
                r",\s*[A-Z]{2})$",
                line,
            )
            if loc_m and not current.company:
                current.company = loc_m.group(1).strip()
                current.location = loc_m.group(2).strip()
                i += 1
                continue

            # Bullet point
            bullet = line.lstrip("•▪-–*I ").strip()
            if not bullet:
                i += 1
                continue

            # Tech stack line
            tech_lower = bullet.lower()
            if tech_lower.startswith("tech"):
                # "Technologies:" or "Tech Stack:"
                colon_pos = bullet.find(":")
                if colon_pos >= 0:
                    techs = bullet[colon_pos + 1:]
                    current.technologies = [
                        t.strip()
                        for t in techs.split(",")
                        if t.strip()
                    ]
                    i += 1
                    continue

            if len(bullet) > 15:
                current.bullets.append(bullet)

        i += 1

    if current and (current.title or current.company):
        experiences.append(current)

    return experiences


def _extract_education(lines: list[str]) -> list[Education]:
    """Extract education entries."""
    entries: list[Education] = []
    for line in lines:
        if _DEGREE_RE.search(line):
            edu = Education()
            deg = _DEGREE_RE.search(line)
            if deg:
                # Try to split degree and institution
                parts = re.split(r"\s*[-–—]\s*", line)
                edu.degree = parts[0].strip()
                if len(parts) > 1:
                    edu.institution = parts[1].strip()
                # GPA
                gpa_m = re.search(r"GPA[:\s]*(\d+\.\d+)", line, re.IGNORECASE)
                if gpa_m:
                    edu.gpa = gpa_m.group(1)
                # Date
                date_m = re.search(
                    r"((?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)"
                    r"[a-z]*\.?\s+\d{4}|\d{4})",
                    line,
                )
                if date_m:
                    edu.graduation_date = date_m.group(1)
            entries.append(edu)
    return entries


def _extract_skills(lines: list[str]) -> list[SkillGroup]:
    """Extract categorized skills."""
    groups: list[SkillGroup] = []
    i = 0
    while i < len(lines):
        line = lines[i]
        if ":" in line:
            parts = line.split(":", 1)
            category = parts[0].strip()
            skills_str = parts[1].strip()
            skills = [
                s.strip() for s in re.split(r"[,|;]", skills_str)
                if s.strip()
            ]
            if skills:
                groups.append(SkillGroup(category=category, skills=skills))
        else:
            # Check if next line has comma-separated items (category/skills pair)
            comma_count = line.count(",")
            next_line = lines[i + 1] if i + 1 < len(lines) else ""
            next_commas = next_line.count(",")

            if comma_count == 0 and next_commas >= 1 and len(line) < 50:
                # This line is a category header, next is the skills
                skills = [
                    s.strip() for s in re.split(r"[,|;]", next_line)
                    if s.strip()
                ]
                if skills:
                    groups.append(SkillGroup(category=line.strip(), skills=skills))
                i += 2
                continue
            elif comma_count >= 1:
                # Single line of comma-separated skills
                skills = [
                    s.strip() for s in re.split(r"[,|;]", line)
                    if s.strip() and len(s.strip()) < 40
                ]
                if len(skills) >= 2:
                    groups.append(SkillGroup(category="Skills", skills=skills))
        i += 1
    return groups


def _extract_certifications(lines: list[str]) -> list[Certification]:
    """Extract certification entries."""
    certs: list[Certification] = []
    for line in lines:
        cert = Certification()
        # Try to split name and issuer
        parts = re.split(r"\s*[-–—]\s*", line)
        cert.name = parts[0].strip()
        if len(parts) > 1:
            cert.issuer = parts[1].strip()
        # Try to find issuer by known names
        if not cert.issuer:
            for issuer in _CERT_ISSUERS:
                if issuer.lower() in line.lower():
                    cert.issuer = issuer
                    break
        # Date
        date_m = re.search(r"\((\d{4})\)", line)
        if date_m:
            cert.date = date_m.group(1)
        if cert.name:
            certs.append(cert)
    return certs


def _extract_projects(lines: list[str]) -> list[Project]:
    """Extract project entries."""
    projects: list[Project] = []
    current: Project | None = None

    for line in lines:
        url = _URL_RE.search(line)
        has_pipe = "|" in line

        # New project if line has a URL or pipe separator
        if url or (has_pipe and len(line.split("|")[0].strip()) < 50):
            if current and current.name:
                projects.append(current)
            current = Project()
            parts = re.split(r"\s*\|\s*", line)
            current.name = parts[0].strip()
            if url:
                current.url = url.group()
        elif current:
            bullet = line.lstrip("•-–* ").strip()
            if bullet:
                current.highlights.append(bullet)
        else:
            # First project without URL
            if not current:
                current = Project()
                current.name = line.strip()

    if current and current.name:
        projects.append(current)

    return projects


def _estimate_years(experiences: list[Experience]) -> int:
    """Estimate total years of experience from date ranges."""
    total_months = 0

    month_map = {
        "jan": 1, "feb": 2, "mar": 3, "apr": 4, "may": 5, "jun": 6,
        "jul": 7, "aug": 8, "sep": 9, "oct": 10, "nov": 11, "dec": 12,
    }

    for exp in experiences:
        start = _parse_date_to_months(exp.start_date, month_map)
        if exp.end_date.lower() in ("present", "current", "now", ""):
            from datetime import datetime
            now = datetime.now()
            end = now.year * 12 + now.month
        else:
            end = _parse_date_to_months(exp.end_date, month_map)

        if start and end and end > start:
            total_months += end - start

    return max(1, total_months // 12)


def _parse_date_to_months(
    date_str: str, month_map: dict[str, int]
) -> int | None:
    """Convert date string to absolute months."""
    if not date_str:
        return None
    m = re.search(
        r"(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]*\.?\s+(\d{4})",
        date_str, re.IGNORECASE,
    )
    if m:
        month = month_map.get(m.group(1).lower()[:3], 1)
        year = int(m.group(2))
        return year * 12 + month
    # Try just year
    y = re.search(r"(\d{4})", date_str)
    if y:
        return int(y.group(1)) * 12 + 6  # assume mid-year
    return None


def parse_resume_dict(data: dict[str, Any]) -> ResumeData:
    """Parse a dictionary into ResumeData."""
    resume = ResumeData()

    # Contact info
    contact_data = data.get("contact", {})
    resume.contact = ContactInfo(
        name=contact_data.get("name", ""),
        email=contact_data.get("email", ""),
        phone=contact_data.get("phone", ""),
        location=contact_data.get("location", ""),
        linkedin=contact_data.get("linkedin", ""),
        github=contact_data.get("github", ""),
        website=contact_data.get("website", ""),
        portfolio=contact_data.get("portfolio", ""),
    )

    # Summary
    resume.summary = data.get("summary", "")

    # Target role
    resume.target_role = data.get("target_role", "")
    resume.years_of_experience = data.get("years_of_experience", 0)

    # Experience
    for exp_data in data.get("experience", []):
        exp = Experience(
            company=exp_data.get("company", ""),
            title=exp_data.get("title", ""),
            location=exp_data.get("location", ""),
            start_date=exp_data.get("start_date", ""),
            end_date=exp_data.get("end_date", "Present"),
            bullets=exp_data.get("bullets", []),
            technologies=exp_data.get("technologies", []),
        )
        resume.experience.append(exp)

    # Education
    for edu_data in data.get("education", []):
        edu = Education(
            institution=edu_data.get("institution", ""),
            degree=edu_data.get("degree", ""),
            field_of_study=edu_data.get("field_of_study", ""),
            graduation_date=edu_data.get("graduation_date", ""),
            gpa=edu_data.get("gpa", ""),
            honors=edu_data.get("honors", []),
        )
        resume.education.append(edu)

    # Skills
    for skill_data in data.get("skills", []):
        group = SkillGroup(
            category=skill_data.get("category", "Other"),
            skills=skill_data.get("skills", []),
        )
        resume.skills.append(group)

    # Certifications
    for cert_data in data.get("certifications", []):
        cert = Certification(
            name=cert_data.get("name", ""),
            issuer=cert_data.get("issuer", ""),
            date=cert_data.get("date", ""),
            credential_id=cert_data.get("credential_id", ""),
            url=cert_data.get("url", ""),
        )
        resume.certifications.append(cert)

    # Projects
    for proj_data in data.get("projects", []):
        proj = Project(
            name=proj_data.get("name", ""),
            description=proj_data.get("description", ""),
            url=proj_data.get("url", ""),
            technologies=proj_data.get("technologies", []),
            highlights=proj_data.get("highlights", []),
        )
        resume.projects.append(proj)

    # Languages
    resume.languages = data.get("languages", [])

    return resume


def resume_to_dict(resume: ResumeData) -> dict[str, Any]:
    """Convert ResumeData back to a dictionary for YAML export."""
    data: dict[str, Any] = {}

    data["contact"] = {
        "name": resume.contact.name,
        "email": resume.contact.email,
        "phone": resume.contact.phone,
        "location": resume.contact.location,
        "linkedin": resume.contact.linkedin,
        "github": resume.contact.github,
        "website": resume.contact.website,
        "portfolio": resume.contact.portfolio,
    }

    data["summary"] = resume.summary
    data["target_role"] = resume.target_role
    data["years_of_experience"] = resume.years_of_experience

    data["experience"] = []
    for exp in resume.experience:
        data["experience"].append({
            "company": exp.company,
            "title": exp.title,
            "location": exp.location,
            "start_date": exp.start_date,
            "end_date": exp.end_date,
            "bullets": exp.bullets,
            "technologies": exp.technologies,
        })

    data["education"] = []
    for edu in resume.education:
        data["education"].append({
            "institution": edu.institution,
            "degree": edu.degree,
            "field_of_study": edu.field_of_study,
            "graduation_date": edu.graduation_date,
            "gpa": edu.gpa,
            "honors": edu.honors,
        })

    data["skills"] = []
    for group in resume.skills:
        data["skills"].append({
            "category": group.category,
            "skills": group.skills,
        })

    data["certifications"] = []
    for cert in resume.certifications:
        data["certifications"].append({
            "name": cert.name,
            "issuer": cert.issuer,
            "date": cert.date,
            "credential_id": cert.credential_id,
            "url": cert.url,
        })

    data["projects"] = []
    for proj in resume.projects:
        data["projects"].append({
            "name": proj.name,
            "description": proj.description,
            "url": proj.url,
            "technologies": proj.technologies,
            "highlights": proj.highlights,
        })

    data["languages"] = resume.languages

    return data


def export_resume_yaml(resume: ResumeData, output_path: str) -> str:
    """Export ResumeData as YAML file."""
    data = resume_to_dict(resume)
    path = Path(output_path)
    with open(path, "w", encoding="utf-8") as f:
        yaml.dump(
            data,
            f,
            default_flow_style=False,
            allow_unicode=True,
            sort_keys=False,
            width=120,
        )
    return str(path)
