"""ATS Scoring Engine — the brain behind resume scoring."""

from __future__ import annotations

import re

from ..models import ResumeData, ScoreFinding, ScoreGrade, ScoreResult, Severity
from ..optimizer.action_verbs import (
    ALL_STRONG_VERBS,
    find_weak_verbs,
    has_quantification,
)
from .keywords import get_role_keywords


def score_resume(resume: ResumeData) -> ScoreResult:
    """Score a resume for ATS compatibility. Returns 0-100 score."""
    findings: list[ScoreFinding] = []
    section_scores: dict[str, int] = {}

    # Run all scoring checks
    section_scores["Contact Info"] = _score_contact(resume, findings)
    section_scores["Professional Summary"] = _score_summary(resume, findings)
    section_scores["Work Experience"] = _score_experience(resume, findings)
    section_scores["Skills"] = _score_skills(resume, findings)
    section_scores["Education"] = _score_education(resume, findings)
    section_scores["Certifications"] = _score_certifications(resume, findings)
    section_scores["Projects"] = _score_projects(resume, findings)
    section_scores["Action Verbs"] = _score_action_verbs(resume, findings)
    section_scores["Quantification"] = _score_quantification(resume, findings)
    section_scores["Formatting"] = _score_formatting(resume, findings)
    section_scores["Keyword Relevance"] = _score_keywords(resume, findings)
    section_scores["Overall Structure"] = _score_structure(resume, findings)

    # Calculate total score (weighted average)
    weights = {
        "Contact Info": 10,
        "Professional Summary": 10,
        "Work Experience": 20,
        "Skills": 12,
        "Education": 5,
        "Certifications": 5,
        "Projects": 5,
        "Action Verbs": 10,
        "Quantification": 10,
        "Formatting": 5,
        "Keyword Relevance": 5,
        "Overall Structure": 3,
    }

    weighted_sum = 0
    total_weight = 0
    for section, weight in weights.items():
        score = section_scores.get(section, 0)
        weighted_sum += score * weight
        total_weight += weight

    total_score = round(weighted_sum / total_weight) if total_weight > 0 else 0
    total_score = max(0, min(100, total_score))

    grade = ScoreGrade.from_score(total_score)

    return ScoreResult(
        total_score=total_score,
        max_score=100,
        grade=grade,
        findings=findings,
        section_scores=section_scores,
    )


def _score_contact(resume: ResumeData, findings: list[ScoreFinding]) -> int:
    """Score contact information completeness."""
    score = 0
    contact = resume.contact

    if contact.name:
        score += 25
        findings.append(ScoreFinding(
            category="Contact Info", message="Name present",
            severity=Severity.PASS,
        ))
    else:
        findings.append(ScoreFinding(
            category="Contact Info", message="Missing name",
            severity=Severity.CRITICAL,
            suggestion="Add your full name at the top of your resume.",
            points_impact=-25,
        ))

    if contact.email:
        score += 25
        findings.append(ScoreFinding(
            category="Contact Info", message="Email present",
            severity=Severity.PASS,
        ))
        # Check for professional email
        if any(d in contact.email.lower() for d in ["gmail.com", "outlook.com", "yahoo.com"]):
            findings.append(ScoreFinding(
                category="Contact Info",
                message="Using personal email domain",
                severity=Severity.INFO,
                suggestion="Consider using a professional or custom domain email for applications.",
            ))
    else:
        findings.append(ScoreFinding(
            category="Contact Info", message="Missing email address",
            severity=Severity.CRITICAL,
            suggestion="Add a professional email address.",
            points_impact=-25,
        ))

    if contact.phone:
        score += 20
        findings.append(ScoreFinding(
            category="Contact Info", message="Phone number present",
            severity=Severity.PASS,
        ))
    else:
        findings.append(ScoreFinding(
            category="Contact Info", message="Missing phone number",
            severity=Severity.WARNING,
            suggestion="Add a phone number for recruiter callbacks.",
            points_impact=-15,
        ))

    if contact.linkedin:
        score += 15
        findings.append(ScoreFinding(
            category="Contact Info", message="LinkedIn profile included",
            severity=Severity.PASS,
        ))
    else:
        findings.append(ScoreFinding(
            category="Contact Info", message="No LinkedIn profile",
            severity=Severity.WARNING,
            suggestion="Add your LinkedIn URL. 87% of recruiters use LinkedIn.",
            points_impact=-10,
        ))

    if contact.location:
        score += 10
        findings.append(ScoreFinding(
            category="Contact Info", message="Location specified",
            severity=Severity.PASS,
        ))
    else:
        findings.append(ScoreFinding(
            category="Contact Info", message="No location specified",
            severity=Severity.INFO,
            suggestion="Add city/state. Helps with location-based job matching.",
            points_impact=-5,
        ))

    if contact.github:
        score += 5
        findings.append(ScoreFinding(
            category="Contact Info", message="GitHub profile included",
            severity=Severity.PASS,
        ))

    return min(100, score)


def _score_summary(resume: ResumeData, findings: list[ScoreFinding]) -> int:
    """Score the professional summary."""
    if not resume.summary:
        findings.append(ScoreFinding(
            category="Summary", message="Missing professional summary",
            severity=Severity.CRITICAL,
            suggestion=(
                "Add a 2-4 sentence professional summary highlighting "
                "years of experience, key skills, and notable achievements."
            ),
            points_impact=-30,
        ))
        return 0

    word_count = len(resume.summary.split())
    score = 50  # Has summary

    # Length check
    if 30 <= word_count <= 80:
        score += 25
        findings.append(ScoreFinding(
            category="Summary",
            message=f"Good summary length ({word_count} words)",
            severity=Severity.PASS,
        ))
    elif word_count < 30:
        findings.append(ScoreFinding(
            category="Summary",
            message=f"Summary too short ({word_count} words)",
            severity=Severity.WARNING,
            suggestion="Expand to 30-80 words. Include years of experience and key specialties.",
            points_impact=-10,
        ))
    else:
        findings.append(ScoreFinding(
            category="Summary",
            message=f"Summary too long ({word_count} words)",
            severity=Severity.WARNING,
            suggestion="Shorten to 30-80 words. Keep it concise and impactful.",
            points_impact=-10,
        ))

    # Check for numbers/metrics in summary
    if re.search(r"\d+", resume.summary):
        score += 15
        findings.append(ScoreFinding(
            category="Summary", message="Summary includes quantified metrics",
            severity=Severity.PASS,
        ))
    else:
        findings.append(ScoreFinding(
            category="Summary",
            message="No numbers or metrics in summary",
            severity=Severity.WARNING,
            suggestion=(
                'Add quantified achievements: "8+ years", '
                '"managed 100+ services", "$2M saved".'
            ),
            points_impact=-10,
        ))

    # Check for years of experience mention
    if re.search(r"\d+\+?\s*years?", resume.summary, re.IGNORECASE):
        score += 10
        findings.append(ScoreFinding(
            category="Summary", message="Years of experience mentioned",
            severity=Severity.PASS,
        ))

    return min(100, score)


def _score_experience(resume: ResumeData, findings: list[ScoreFinding]) -> int:
    """Score work experience section."""
    if not resume.experience:
        findings.append(ScoreFinding(
            category="Experience", message="No work experience listed",
            severity=Severity.CRITICAL,
            suggestion="Add at least 2-3 relevant work experiences with bullet points.",
            points_impact=-40,
        ))
        return 0

    score = 30  # Has experience section
    total_bullets = resume.total_bullets()

    # Number of experiences
    exp_count = len(resume.experience)
    if exp_count >= 2:
        score += 15
        findings.append(ScoreFinding(
            category="Experience",
            message=f"{exp_count} work experiences listed",
            severity=Severity.PASS,
        ))
    else:
        findings.append(ScoreFinding(
            category="Experience",
            message="Only 1 work experience. Add more if available.",
            severity=Severity.WARNING,
            suggestion="Include at least 2 relevant positions for a stronger profile.",
            points_impact=-10,
        ))

    # Bullet count per experience
    well_structured = 0
    for exp in resume.experience:
        bullet_count = len(exp.bullets)
        if 3 <= bullet_count <= 8:
            well_structured += 1
        elif bullet_count < 3:
            findings.append(ScoreFinding(
                category="Experience",
                message=f"{exp.company}: Only {bullet_count} bullet points",
                severity=Severity.WARNING,
                suggestion=f"Add more achievements for {exp.company}. Aim for 3-8 bullets.",
                points_impact=-5,
            ))
        elif bullet_count > 8:
            findings.append(ScoreFinding(
                category="Experience",
                message=f"{exp.company}: Too many bullets ({bullet_count})",
                severity=Severity.INFO,
                suggestion=f"Trim to top 5-8 achievements for {exp.company}.",
                points_impact=-3,
            ))

    if well_structured == exp_count:
        score += 15
        findings.append(ScoreFinding(
            category="Experience",
            message="All positions have good bullet count (3-8)",
            severity=Severity.PASS,
        ))

    # Date completeness
    has_dates = all(exp.start_date for exp in resume.experience)
    if has_dates:
        score += 10
        findings.append(ScoreFinding(
            category="Experience", message="All positions have dates",
            severity=Severity.PASS,
        ))
    else:
        findings.append(ScoreFinding(
            category="Experience",
            message="Some positions missing dates",
            severity=Severity.WARNING,
            suggestion="Add start/end dates for all positions. ATS systems require dates.",
            points_impact=-10,
        ))

    # Title completeness
    has_titles = all(exp.title for exp in resume.experience)
    if has_titles:
        score += 10
        findings.append(ScoreFinding(
            category="Experience", message="All positions have job titles",
            severity=Severity.PASS,
        ))

    # Total bullets check
    if total_bullets >= 8:
        score += 10
        findings.append(ScoreFinding(
            category="Experience",
            message=f"Good total bullet count ({total_bullets})",
            severity=Severity.PASS,
        ))
    else:
        findings.append(ScoreFinding(
            category="Experience",
            message=f"Low bullet count ({total_bullets}). Expand achievements.",
            severity=Severity.WARNING,
            points_impact=-10,
        ))

    # Technologies listed
    has_tech = any(exp.technologies for exp in resume.experience)
    if has_tech:
        score += 10
        findings.append(ScoreFinding(
            category="Experience", message="Technologies mentioned per role",
            severity=Severity.PASS,
        ))

    return min(100, score)


def _score_skills(resume: ResumeData, findings: list[ScoreFinding]) -> int:
    """Score skills section."""
    if not resume.skills:
        findings.append(ScoreFinding(
            category="Skills", message="No skills section",
            severity=Severity.CRITICAL,
            suggestion="Add categorized skills. ATS systems match keywords from this section.",
            points_impact=-25,
        ))
        return 0

    all_skills = resume.all_skills_flat()
    skill_count = len(all_skills)
    score = 30  # Has skills

    # Skill count
    if skill_count >= 15:
        score += 25
        findings.append(ScoreFinding(
            category="Skills",
            message=f"Strong skill count ({skill_count} skills)",
            severity=Severity.PASS,
        ))
    elif skill_count >= 8:
        score += 15
        findings.append(ScoreFinding(
            category="Skills",
            message=f"Adequate skills ({skill_count}). Consider adding more.",
            severity=Severity.INFO,
        ))
    else:
        findings.append(ScoreFinding(
            category="Skills",
            message=f"Too few skills ({skill_count}). ATS needs more keywords.",
            severity=Severity.WARNING,
            suggestion="List 15-25 relevant skills for best ATS coverage.",
            points_impact=-15,
        ))

    # Categorization
    if len(resume.skills) >= 3:
        score += 20
        findings.append(ScoreFinding(
            category="Skills",
            message=f"Well-categorized ({len(resume.skills)} categories)",
            severity=Severity.PASS,
        ))
    elif len(resume.skills) >= 2:
        score += 10
        findings.append(ScoreFinding(
            category="Skills",
            message="Consider organizing into more categories.",
            severity=Severity.INFO,
        ))

    # Check for common missing categories
    categories_lower = [g.category.lower() for g in resume.skills]
    has_cloud = any("cloud" in c or "infra" in c for c in categories_lower)
    has_lang = any(
        "programming" in c or "language" in c or "scripting" in c
        for c in categories_lower
    )
    has_tools = any("tool" in c or "platform" in c for c in categories_lower)

    if has_cloud and has_lang and has_tools:
        score += 15

    # Bonus for comprehensive coverage
    if skill_count >= 20:
        score += 10
        findings.append(ScoreFinding(
            category="Skills",
            message="Comprehensive skill coverage",
            severity=Severity.PASS,
        ))

    return min(100, score)


def _score_education(resume: ResumeData, findings: list[ScoreFinding]) -> int:
    """Score education section."""
    if not resume.education:
        findings.append(ScoreFinding(
            category="Education", message="No education listed",
            severity=Severity.WARNING,
            suggestion="Add education. Most ATS systems require this section.",
            points_impact=-15,
        ))
        return 30  # Not critical for experienced professionals

    score = 60  # Has education
    edu = resume.education[0]

    if edu.degree:
        score += 20
        findings.append(ScoreFinding(
            category="Education", message="Degree specified",
            severity=Severity.PASS,
        ))
    if edu.institution:
        score += 10
    if edu.graduation_date:
        score += 10

    return min(100, score)


def _score_certifications(resume: ResumeData, findings: list[ScoreFinding]) -> int:
    """Score certifications section."""
    if not resume.certifications:
        findings.append(ScoreFinding(
            category="Certifications",
            message="No certifications listed",
            severity=Severity.INFO,
            suggestion="Industry certifications strengthen ATS scores significantly.",
            points_impact=-5,
        ))
        return 40  # Not required but beneficial

    cert_count = len(resume.certifications)
    score = 60

    if cert_count >= 3:
        score += 30
        findings.append(ScoreFinding(
            category="Certifications",
            message=f"Strong certification portfolio ({cert_count})",
            severity=Severity.PASS,
        ))
    elif cert_count >= 1:
        score += 15
        findings.append(ScoreFinding(
            category="Certifications",
            message=f"{cert_count} certification(s) listed",
            severity=Severity.PASS,
        ))

    # Check for issuer
    has_issuer = all(c.issuer for c in resume.certifications)
    if has_issuer:
        score += 10

    return min(100, score)


def _score_projects(resume: ResumeData, findings: list[ScoreFinding]) -> int:
    """Score projects section."""
    if not resume.projects:
        findings.append(ScoreFinding(
            category="Projects",
            message="No projects listed",
            severity=Severity.INFO,
            suggestion="Open source projects demonstrate practical skills. Consider adding.",
            points_impact=-3,
        ))
        return 50  # Not required

    proj_count = len(resume.projects)
    score = 60

    if proj_count >= 3:
        score += 25
    elif proj_count >= 1:
        score += 15

    # Check for URLs
    has_urls = any(p.url for p in resume.projects)
    if has_urls:
        score += 15
        findings.append(ScoreFinding(
            category="Projects", message="Project links included",
            severity=Severity.PASS,
        ))

    return min(100, score)


def _score_action_verbs(resume: ResumeData, findings: list[ScoreFinding]) -> int:
    """Score use of action verbs in bullet points."""
    all_bullets = []
    for exp in resume.experience:
        all_bullets.extend(exp.bullets)

    if not all_bullets:
        return 0

    strong_count = 0
    weak_found = []

    for bullet in all_bullets:
        # Check first word
        words = bullet.strip().lstrip("•-– ").split()
        if words:
            first_word = words[0].lower()
            # Check against strong verbs
            is_strong = False
            for verb in ALL_STRONG_VERBS:
                if first_word == verb or first_word.rstrip("ed") == verb.rstrip("ed"):
                    is_strong = True
                    break
            if is_strong:
                strong_count += 1

        # Check for weak verbs
        weak_in_bullet = find_weak_verbs(bullet)
        weak_found.extend(weak_in_bullet)

    total = len(all_bullets)
    strong_pct = (strong_count / total * 100) if total > 0 else 0

    score = 0
    if strong_pct >= 80:
        score = 100
        findings.append(ScoreFinding(
            category="Action Verbs",
            message=f"Excellent — {strong_pct:.0f}% bullets start with strong verbs",
            severity=Severity.PASS,
        ))
    elif strong_pct >= 60:
        score = 75
        findings.append(ScoreFinding(
            category="Action Verbs",
            message=f"Good — {strong_pct:.0f}% bullets start with strong verbs",
            severity=Severity.PASS,
        ))
    elif strong_pct >= 40:
        score = 50
        findings.append(ScoreFinding(
            category="Action Verbs",
            message=f"Fair — only {strong_pct:.0f}% bullets start with strong verbs",
            severity=Severity.WARNING,
            suggestion=(
                "Start each bullet with a strong action verb: "
                "Led, Engineered, Delivered, Optimized, Architected."
            ),
        ))
    else:
        score = 25
        findings.append(ScoreFinding(
            category="Action Verbs",
            message=f"Weak — only {strong_pct:.0f}% bullets start with action verbs",
            severity=Severity.CRITICAL,
            suggestion=(
                "Rewrite bullets to start with action verbs. "
                "Replace 'Responsible for...' with 'Led...' or 'Managed...'"
            ),
            points_impact=-15,
        ))

    # Report weak verbs
    if weak_found:
        unique_weak = set(w[0] for w in weak_found)
        for weak_verb in list(unique_weak)[:3]:
            suggestions = dict(weak_found).get(weak_verb, [])
            if suggestions:
                findings.append(ScoreFinding(
                    category="Action Verbs",
                    message=f'Found weak phrase: "{weak_verb}"',
                    severity=Severity.WARNING,
                    suggestion=f"Replace with: {', '.join(suggestions[:3])}",
                    points_impact=-3,
                ))

    return score


def _score_quantification(resume: ResumeData, findings: list[ScoreFinding]) -> int:
    """Score quantification of achievements."""
    all_bullets = []
    for exp in resume.experience:
        all_bullets.extend(exp.bullets)

    if not all_bullets:
        return 0

    quantified_count = 0
    for bullet in all_bullets:
        if has_quantification(bullet):
            quantified_count += 1

    total = len(all_bullets)
    quant_pct = (quantified_count / total * 100) if total > 0 else 0

    if quant_pct >= 60:
        findings.append(ScoreFinding(
            category="Quantification",
            message=(
                f"Excellent — {quantified_count}/{total} bullets"
                f" have metrics ({quant_pct:.0f}%)"
            ),
            severity=Severity.PASS,
        ))
        return 100
    elif quant_pct >= 40:
        findings.append(ScoreFinding(
            category="Quantification",
            message=f"Good — {quantified_count}/{total} bullets quantified ({quant_pct:.0f}%)",
            severity=Severity.PASS,
        ))
        return 75
    elif quant_pct >= 20:
        findings.append(ScoreFinding(
            category="Quantification",
            message=f"Fair — only {quantified_count}/{total} bullets quantified ({quant_pct:.0f}%)",
            severity=Severity.WARNING,
            suggestion=(
                "Add numbers: deployed to X servers, reduced costs by Y%, "
                "improved performance by Z%, managed team of N."
            ),
            points_impact=-10,
        ))
        return 50
    else:
        findings.append(ScoreFinding(
            category="Quantification",
            message=f"Weak — only {quantified_count}/{total} bullets have metrics",
            severity=Severity.CRITICAL,
            suggestion=(
                "Quantify your achievements! Use numbers, percentages, dollar amounts. "
                '"Reduced deployment time by 70%", "Managed 100+ microservices", '
                '"Saved $50K annually".'
            ),
            points_impact=-20,
        ))
        return 20


def _score_formatting(resume: ResumeData, findings: list[ScoreFinding]) -> int:
    """Score resume formatting for ATS compatibility."""
    score = 50  # Base score

    # Check bullet length (not too long, not too short)
    all_bullets = []
    for exp in resume.experience:
        all_bullets.extend(exp.bullets)

    if all_bullets:
        long_bullets = [b for b in all_bullets if len(b) > 200]
        short_bullets = [b for b in all_bullets if len(b) < 20]

        if not long_bullets:
            score += 15
            findings.append(ScoreFinding(
                category="Formatting",
                message="Bullet lengths are appropriate",
                severity=Severity.PASS,
            ))
        else:
            findings.append(ScoreFinding(
                category="Formatting",
                message=f"{len(long_bullets)} bullets are too long (>200 chars)",
                severity=Severity.WARNING,
                suggestion="Keep bullets under 200 characters for readability.",
                points_impact=-5,
            ))

        if not short_bullets:
            score += 10
        else:
            findings.append(ScoreFinding(
                category="Formatting",
                message=f"{len(short_bullets)} bullets are too short (<20 chars)",
                severity=Severity.INFO,
                suggestion="Expand short bullets with more detail and context.",
            ))

    # Check summary length
    if resume.summary:
        summary_words = len(resume.summary.split())
        if 30 <= summary_words <= 80:
            score += 15

    # Check for consistent structure
    if resume.contact.name and resume.summary and resume.experience and resume.skills:
        score += 10
        findings.append(ScoreFinding(
            category="Formatting",
            message="All core sections present in correct order",
            severity=Severity.PASS,
        ))

    return min(100, score)


def _score_keywords(resume: ResumeData, findings: list[ScoreFinding]) -> int:
    """Score keyword relevance based on target role."""
    if not resume.target_role:
        findings.append(ScoreFinding(
            category="Keywords",
            message="No target role specified",
            severity=Severity.INFO,
            suggestion="Set target_role in your resume to get keyword recommendations.",
        ))
        return 60  # Can't fully evaluate without target role

    role_keywords = get_role_keywords(resume.target_role)
    if not role_keywords:
        return 60

    # Collect all text from resume
    all_text = _get_full_resume_text(resume).lower()

    matched = [kw for kw in role_keywords if kw.lower() in all_text]
    missing = [kw for kw in role_keywords if kw.lower() not in all_text]

    match_pct = (len(matched) / len(role_keywords) * 100) if role_keywords else 0

    if match_pct >= 70:
        findings.append(ScoreFinding(
            category="Keywords",
            message=f"Strong keyword match ({match_pct:.0f}% of role keywords found)",
            severity=Severity.PASS,
        ))
        score = 100
    elif match_pct >= 50:
        findings.append(ScoreFinding(
            category="Keywords",
            message=f"Good keyword match ({match_pct:.0f}%)",
            severity=Severity.PASS,
        ))
        score = 75
    elif match_pct >= 30:
        findings.append(ScoreFinding(
            category="Keywords",
            message=f"Fair keyword match ({match_pct:.0f}%)",
            severity=Severity.WARNING,
            suggestion=f"Consider adding: {', '.join(missing[:5])}",
            points_impact=-10,
        ))
        score = 50
    else:
        findings.append(ScoreFinding(
            category="Keywords",
            message=f"Low keyword match ({match_pct:.0f}%)",
            severity=Severity.CRITICAL,
            suggestion=f"Missing key skills: {', '.join(missing[:8])}",
            points_impact=-15,
        ))
        score = 25

    return score


def _score_structure(resume: ResumeData, findings: list[ScoreFinding]) -> int:
    """Score overall resume structure."""
    score = 0
    sections_present = 0

    # Check required sections
    if resume.contact.name:
        sections_present += 1
    if resume.summary:
        sections_present += 1
    if resume.experience:
        sections_present += 1
    if resume.skills:
        sections_present += 1
    if resume.education:
        sections_present += 1

    # Optional but valuable sections
    optional = 0
    if resume.certifications:
        optional += 1
    if resume.projects:
        optional += 1
    if resume.languages:
        optional += 1

    if sections_present >= 5:
        score = 70
        findings.append(ScoreFinding(
            category="Structure",
            message="All required sections present",
            severity=Severity.PASS,
        ))
    elif sections_present >= 4:
        score = 50
        findings.append(ScoreFinding(
            category="Structure",
            message=f"Missing {5 - sections_present} required section(s)",
            severity=Severity.WARNING,
        ))
    else:
        score = 25
        findings.append(ScoreFinding(
            category="Structure",
            message=f"Missing {5 - sections_present} required sections",
            severity=Severity.CRITICAL,
            suggestion="Include: Contact, Summary, Experience, Skills, and Education.",
            points_impact=-20,
        ))

    if optional >= 2:
        score += 20
        findings.append(ScoreFinding(
            category="Structure",
            message=f"{optional} optional sections included (certs/projects/languages)",
            severity=Severity.PASS,
        ))
    elif optional >= 1:
        score += 10

    return min(100, score)


def _get_full_resume_text(resume: ResumeData) -> str:
    """Get all text content from resume as a single string."""
    parts = [
        resume.summary,
        resume.contact.name,
        resume.target_role,
    ]

    for exp in resume.experience:
        parts.append(exp.title)
        parts.append(exp.company)
        parts.extend(exp.bullets)
        parts.extend(exp.technologies)

    for edu in resume.education:
        parts.append(edu.degree)
        parts.append(edu.field_of_study)

    for group in resume.skills:
        parts.append(group.category)
        parts.extend(group.skills)

    for cert in resume.certifications:
        parts.append(cert.name)
        parts.append(cert.issuer)

    for proj in resume.projects:
        parts.append(proj.name)
        parts.append(proj.description)
        parts.extend(proj.technologies)
        parts.extend(proj.highlights)

    return " ".join(p for p in parts if p)
