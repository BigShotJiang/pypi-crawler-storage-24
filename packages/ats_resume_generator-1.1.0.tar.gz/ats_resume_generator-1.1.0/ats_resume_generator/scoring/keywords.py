"""Industry keyword databases for resume optimization."""

from __future__ import annotations

# Role-specific keywords that ATS systems scan for
ROLE_KEYWORDS: dict[str, list[str]] = {
    "devops-engineer": [
        "kubernetes", "docker", "ci/cd", "jenkins", "terraform", "ansible",
        "aws", "azure", "gcp", "linux", "git", "monitoring", "prometheus",
        "grafana", "helm", "argocd", "infrastructure as code", "iac",
        "microservices", "containerization", "cloud", "deployment", "pipeline",
        "automation", "scripting", "python", "bash", "yaml", "json",
        "networking", "security", "load balancing", "high availability",
        "disaster recovery", "incident response", "sre", "observability",
        "configuration management", "release management", "continuous integration",
        "continuous deployment", "agile", "scrum", "jira", "confluence",
    ],
    "software-engineer": [
        "algorithms", "data structures", "design patterns", "oop", "rest api",
        "microservices", "testing", "unit testing", "integration testing",
        "git", "agile", "scrum", "code review", "debugging", "architecture",
        "scalability", "performance", "database", "sql", "nosql", "caching",
        "distributed systems", "api design", "clean code", "solid principles",
        "ci/cd", "tdd", "bdd", "documentation", "mentoring", "collaboration",
    ],
    "data-engineer": [
        "etl", "elt", "data pipeline", "spark", "hadoop", "kafka", "airflow",
        "sql", "python", "scala", "data warehouse", "data lake", "snowflake",
        "databricks", "redshift", "bigquery", "data modeling", "data quality",
        "data governance", "streaming", "batch processing", "parquet", "avro",
        "dbt", "orchestration", "schema design", "data catalog", "metadata",
    ],
    "cloud-architect": [
        "aws", "azure", "gcp", "multi-cloud", "hybrid cloud", "architecture",
        "well-architected", "security", "networking", "vpc", "load balancing",
        "auto-scaling", "disaster recovery", "high availability", "cost optimization",
        "governance", "compliance", "landing zone", "migration", "modernization",
        "serverless", "microservices", "containers", "kubernetes", "terraform",
        "infrastructure as code", "design patterns", "enterprise architecture",
    ],
    "sre": [
        "sli", "slo", "sla", "error budget", "reliability", "availability",
        "latency", "throughput", "monitoring", "alerting", "incident response",
        "post-mortem", "blameless", "toil reduction", "automation", "capacity planning",
        "performance", "chaos engineering", "observability", "distributed systems",
        "kubernetes", "docker", "prometheus", "grafana", "pagerduty", "on-call",
        "linux", "networking", "troubleshooting", "root cause analysis",
    ],
    "fullstack-developer": [
        "react", "angular", "vue", "javascript", "typescript", "html", "css",
        "node.js", "python", "java", "rest api", "graphql", "database", "sql",
        "nosql", "mongodb", "postgresql", "redis", "docker", "git",
        "ci/cd", "testing", "responsive design", "accessibility", "performance",
        "security", "authentication", "authorization", "deployment", "agile",
    ],
    "backend-developer": [
        "python", "java", "go", "rust", "node.js", "c#", "rest api", "graphql",
        "microservices", "database", "sql", "nosql", "postgresql", "mongodb",
        "redis", "caching", "message queue", "rabbitmq", "kafka", "docker",
        "kubernetes", "testing", "api design", "authentication", "authorization",
        "scalability", "performance", "distributed systems", "event-driven",
    ],
    "frontend-developer": [
        "react", "angular", "vue", "svelte", "javascript", "typescript",
        "html", "css", "sass", "tailwind", "responsive design", "accessibility",
        "wcag", "performance", "webpack", "vite", "testing", "jest", "cypress",
        "state management", "redux", "pwa", "seo", "web vitals", "ux",
        "component library", "design system", "figma", "storybook",
    ],
    "ml-engineer": [
        "machine learning", "deep learning", "neural networks", "tensorflow",
        "pytorch", "scikit-learn", "python", "nlp", "computer vision", "mlops",
        "model training", "model serving", "feature engineering", "data preprocessing",
        "a/b testing", "experiment tracking", "mlflow", "kubernetes", "docker",
        "distributed training", "gpu", "hyperparameter tuning", "model monitoring",
    ],
    "product-manager": [
        "product strategy", "roadmap", "user research", "a/b testing", "analytics",
        "stakeholder management", "agile", "scrum", "jira", "user stories",
        "prioritization", "market research", "competitive analysis", "kpi",
        "okr", "metrics", "data-driven", "customer discovery", "mvp",
        "go-to-market", "cross-functional", "collaboration", "presentation",
    ],
}

# Common technical skills by category
SKILL_DATABASES: dict[str, list[str]] = {
    "Cloud & Infrastructure": [
        "AWS", "Azure", "GCP", "DigitalOcean", "Heroku", "Vercel",
        "EC2", "S3", "Lambda", "EKS", "RDS", "CloudFront",
        "AKS", "App Service", "Azure Functions", "Cosmos DB",
        "GKE", "Cloud Run", "Cloud Functions", "BigQuery",
    ],
    "Containers & Orchestration": [
        "Docker", "Kubernetes", "Helm", "Istio", "Linkerd",
        "Docker Compose", "Podman", "containerd", "CRI-O",
        "ECS", "EKS", "AKS", "GKE", "OpenShift", "Rancher",
    ],
    "CI/CD & Automation": [
        "GitHub Actions", "Azure DevOps", "GitLab CI", "Jenkins",
        "CircleCI", "Travis CI", "ArgoCD", "FluxCD", "Tekton",
        "Bamboo", "TeamCity", "Drone CI", "Buildkite",
    ],
    "Infrastructure as Code": [
        "Terraform", "Pulumi", "CloudFormation", "ARM Templates",
        "Ansible", "Chef", "Puppet", "SaltStack", "Bicep",
        "CDK", "Crossplane", "Vagrant",
    ],
    "Monitoring & Observability": [
        "Prometheus", "Grafana", "Datadog", "New Relic", "Splunk",
        "ELK Stack", "Elasticsearch", "Logstash", "Kibana", "Fluentd",
        "Jaeger", "Zipkin", "OpenTelemetry", "PagerDuty", "OpsGenie",
        "CloudWatch", "Azure Monitor", "Loki", "Thanos",
    ],
    "Programming & Scripting": [
        "Python", "JavaScript", "TypeScript", "Go", "Rust", "Java",
        "C#", "C++", "Ruby", "PHP", "Bash", "PowerShell",
        "Scala", "Kotlin", "Swift", "R", "Perl",
    ],
    "Databases": [
        "PostgreSQL", "MySQL", "MongoDB", "Redis", "DynamoDB",
        "Cassandra", "Elasticsearch", "SQL Server", "Oracle",
        "SQLite", "CouchDB", "Neo4j", "InfluxDB", "TimescaleDB",
    ],
}

# ATS buzz phrases that score well
ATS_POWER_PHRASES = [
    "cross-functional collaboration",
    "data-driven decision making",
    "continuous improvement",
    "best practices",
    "industry standards",
    "cost optimization",
    "performance optimization",
    "security best practices",
    "high availability",
    "disaster recovery",
    "scalable architecture",
    "production environment",
    "enterprise-grade",
    "mission-critical",
    "zero-downtime deployment",
    "automated testing",
    "infrastructure as code",
    "shift-left security",
    "agile methodology",
    "stakeholder communication",
]


def get_role_keywords(role: str) -> list[str]:
    """Get keywords for a specific role."""
    role_key = role.lower().replace(" ", "-")
    return ROLE_KEYWORDS.get(role_key, [])


def get_all_role_names() -> list[str]:
    """Get all available role names."""
    return list(ROLE_KEYWORDS.keys())


def extract_keywords_from_text(text: str) -> list[str]:
    """Extract meaningful keywords from job description text."""
    import re

    # Clean the text
    text_lower = text.lower()

    # Collect all known keywords
    all_keywords = set()
    for role_kws in ROLE_KEYWORDS.values():
        all_keywords.update(kw.lower() for kw in role_kws)
    for cat_skills in SKILL_DATABASES.values():
        all_keywords.update(s.lower() for s in cat_skills)

    # Find matches
    found = []
    for keyword in sorted(all_keywords):
        # Use word boundary for short keywords, contains for longer ones
        if len(keyword) <= 3:
            pattern = r"\b" + re.escape(keyword) + r"\b"
            if re.search(pattern, text_lower):
                found.append(keyword)
        else:
            if keyword in text_lower:
                found.append(keyword)

    return sorted(set(found))
