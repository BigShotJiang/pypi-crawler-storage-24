"""ATS scoring engine."""
