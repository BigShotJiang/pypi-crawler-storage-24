"""Role-specific resume templates."""
