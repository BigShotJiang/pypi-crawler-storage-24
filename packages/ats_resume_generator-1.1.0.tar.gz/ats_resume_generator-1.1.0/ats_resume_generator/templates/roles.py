"""Role-specific resume templates with pre-filled content."""

from __future__ import annotations

from ..models import (
    Certification,
    ContactInfo,
    Education,
    Experience,
    Project,
    ResumeData,
    SkillGroup,
)

# Template registry
_ROLE_TEMPLATES: dict[str, dict] = {}


def get_template(role: str) -> ResumeData:
    """Get a pre-filled template for a specific role."""
    role_key = role.lower().replace(" ", "-")
    builder = _ROLE_TEMPLATES.get(role_key)
    if not builder:
        return _blank_template()
    return builder()


def get_available_templates() -> list[tuple[str, str]]:
    """Return list of (role_key, display_name) for all templates."""
    return [
        ("devops-engineer", "DevOps Engineer"),
        ("software-engineer", "Software Engineer"),
        ("data-engineer", "Data Engineer"),
        ("cloud-architect", "Cloud Architect"),
        ("sre", "Site Reliability Engineer (SRE)"),
        ("fullstack-developer", "Full Stack Developer"),
        ("backend-developer", "Backend Developer"),
        ("frontend-developer", "Frontend Developer"),
        ("ml-engineer", "Machine Learning Engineer"),
        ("product-manager", "Product Manager"),
        ("blank", "Blank Template"),
    ]


def _blank_template() -> ResumeData:
    """Return a blank template with section placeholders."""
    return ResumeData(
        contact=ContactInfo(
            name="Your Full Name",
            email="your.email@example.com",
            phone="+1-555-123-4567",
            location="City, State",
            linkedin="linkedin.com/in/your-profile",
            github="github.com/your-username",
        ),
        summary="A concise 2-4 sentence summary of your professional experience, key skills, and notable achievements. Include years of experience and your specialization.",
        target_role="",
        years_of_experience=0,
        experience=[
            Experience(
                company="Company Name",
                title="Your Job Title",
                location="City, State",
                start_date="Jan 2022",
                end_date="Present",
                bullets=[
                    "Led/Built/Designed [what] using [technologies], resulting in [measurable outcome]",
                    "Reduced/Improved/Optimized [metric] by [X%] through [specific action]",
                    "Managed/Mentored [team size] engineers, delivering [project] on time and under budget",
                ],
                technologies=["Technology 1", "Technology 2", "Technology 3"],
            ),
        ],
        education=[
            Education(
                institution="University Name",
                degree="Bachelor of Science",
                field_of_study="Computer Science",
                graduation_date="2020",
            ),
        ],
        skills=[
            SkillGroup(category="Category 1", skills=["Skill 1", "Skill 2"]),
            SkillGroup(category="Category 2", skills=["Skill 3", "Skill 4"]),
        ],
        certifications=[],
        projects=[],
    )


def _devops_engineer_template() -> ResumeData:
    return ResumeData(
        contact=ContactInfo(name="Your Full Name", email="your.email@example.com", phone="+1-555-123-4567", location="City, State", linkedin="linkedin.com/in/your-profile", github="github.com/your-username"),
        summary="DevOps Engineer with X+ years of experience designing and managing CI/CD pipelines, cloud infrastructure, and container orchestration platforms. Proven track record of reducing deployment times by Y%, managing Z+ microservices, and driving infrastructure automation initiatives saving $XK annually.",
        target_role="devops-engineer",
        years_of_experience=5,
        experience=[
            Experience(company="Current Company", title="Senior DevOps Engineer", location="City, State", start_date="Jan 2022", end_date="Present", bullets=[
                "Architected and managed Kubernetes clusters hosting 100+ microservices with 99.9% uptime across production environments",
                "Designed and implemented CI/CD pipelines using GitHub Actions and Azure DevOps, reducing deployment time from 45 minutes to 8 minutes (82% reduction)",
                "Led infrastructure-as-code initiative using Terraform, managing 200+ cloud resources across 3 Azure subscriptions",
                "Implemented GitOps workflow with ArgoCD, enabling 50+ deployments per week with zero-downtime releases",
                "Reduced cloud infrastructure costs by 40% ($47K to $27K/month) through right-sizing, reserved instances, and automated scaling policies",
                "Built comprehensive monitoring stack with Prometheus and Grafana, tracking 500+ metrics and reducing MTTR from 4 hours to 30 minutes",
            ], technologies=["Kubernetes", "Docker", "Terraform", "Azure", "GitHub Actions", "ArgoCD", "Prometheus", "Grafana"]),
            Experience(company="Previous Company", title="DevOps Engineer", location="City, State", start_date="Jun 2019", end_date="Dec 2021", bullets=[
                "Automated infrastructure provisioning using Ansible and Terraform, reducing server setup time from 2 days to 30 minutes",
                "Containerized 25 legacy applications and migrated them to Kubernetes, improving resource utilization by 60%",
                "Implemented centralized logging with ELK Stack, processing 2TB of logs daily across 150 servers",
                "Designed disaster recovery strategy achieving RPO of 15 minutes and RTO of 1 hour",
            ], technologies=["Docker", "Kubernetes", "Ansible", "Terraform", "Jenkins", "ELK Stack", "AWS"]),
        ],
        education=[Education(institution="University Name", degree="Bachelor of Engineering", field_of_study="Computer Science", graduation_date="2019")],
        skills=[
            SkillGroup(category="Cloud & Infrastructure", skills=["AWS", "Azure", "GCP", "Linux", "Networking"]),
            SkillGroup(category="Containers & Orchestration", skills=["Docker", "Kubernetes", "Helm", "Istio", "Docker Compose"]),
            SkillGroup(category="CI/CD & Automation", skills=["GitHub Actions", "Azure DevOps", "Jenkins", "ArgoCD", "GitLab CI"]),
            SkillGroup(category="Infrastructure as Code", skills=["Terraform", "Ansible", "Pulumi", "CloudFormation", "Bicep"]),
            SkillGroup(category="Monitoring & Observability", skills=["Prometheus", "Grafana", "ELK Stack", "Datadog", "PagerDuty"]),
            SkillGroup(category="Programming & Scripting", skills=["Python", "Bash", "Go", "PowerShell", "YAML"]),
        ],
        certifications=[
            Certification(name="Azure Administrator Associate", issuer="Microsoft", date="2023", credential_id="AZ-104"),
            Certification(name="Azure DevOps Engineer Expert", issuer="Microsoft", date="2023", credential_id="AZ-400"),
            Certification(name="Certified Kubernetes Administrator", issuer="CNCF", date="2022", credential_id="CKA"),
        ],
        projects=[
            Project(name="k8s-health-checker", description="CLI tool to scan Kubernetes clusters for health issues and security risks", url="github.com/username/k8s-health-checker", technologies=["Python", "Click", "Rich", "Kubernetes API"], highlights=["Published on PyPI", "22 automated tests"]),
            Project(name="pipeline-generator", description="Generate CI/CD pipeline configs for multiple platforms from a YAML spec", url="github.com/username/pipeline-generator", technologies=["Python", "Click", "Rich", "YAML"], highlights=["Supports GitHub Actions, Azure DevOps, GitLab CI"]),
        ],
        languages=["English", "Hindi"],
    )


def _software_engineer_template() -> ResumeData:
    return ResumeData(
        contact=ContactInfo(name="Your Full Name", email="your.email@example.com", phone="+1-555-123-4567", location="City, State", linkedin="linkedin.com/in/your-profile", github="github.com/your-username"),
        summary="Software Engineer with X+ years of experience building scalable backend services and APIs. Expertise in distributed systems, microservices architecture, and data-intensive applications. Delivered features used by Y+ users and reduced system latency by Z%.",
        target_role="software-engineer",
        years_of_experience=5,
        experience=[
            Experience(company="Current Company", title="Senior Software Engineer", location="City, State", start_date="Jan 2022", end_date="Present", bullets=[
                "Designed and built microservices architecture serving 10M+ daily requests with p99 latency under 50ms",
                "Led migration from monolithic application to event-driven microservices, improving deployment frequency by 300%",
                "Implemented caching layer using Redis, reducing database load by 60% and API response time by 45%",
                "Mentored 4 junior engineers through code reviews, pair programming, and technical design sessions",
                "Designed and implemented REST APIs consumed by 3 frontend applications and 5 third-party integrations",
            ], technologies=["Python", "Java", "PostgreSQL", "Redis", "Kafka", "Docker", "Kubernetes"]),
            Experience(company="Previous Company", title="Software Engineer", location="City, State", start_date="Jun 2019", end_date="Dec 2021", bullets=[
                "Built real-time data processing pipeline handling 500K events/second using Apache Kafka and Spark",
                "Developed automated testing framework achieving 92% code coverage across 15 microservices",
                "Optimized critical database queries reducing execution time from 12 seconds to 200 milliseconds",
                "Contributed to open-source projects with 500+ GitHub stars in the distributed systems space",
            ], technologies=["Java", "Spring Boot", "PostgreSQL", "Kafka", "Spark", "Docker"]),
        ],
        education=[Education(institution="University Name", degree="Bachelor of Science", field_of_study="Computer Science", graduation_date="2019", gpa="3.8/4.0")],
        skills=[
            SkillGroup(category="Programming Languages", skills=["Python", "Java", "Go", "TypeScript", "SQL"]),
            SkillGroup(category="Frameworks & Libraries", skills=["Spring Boot", "FastAPI", "Django", "React", "Node.js"]),
            SkillGroup(category="Databases", skills=["PostgreSQL", "MongoDB", "Redis", "DynamoDB", "Elasticsearch"]),
            SkillGroup(category="Tools & Infrastructure", skills=["Docker", "Kubernetes", "Git", "CI/CD", "AWS", "Kafka"]),
        ],
        certifications=[
            Certification(name="AWS Solutions Architect Associate", issuer="Amazon", date="2023"),
        ],
        projects=[],
        languages=["English"],
    )


def _data_engineer_template() -> ResumeData:
    return ResumeData(
        contact=ContactInfo(name="Your Full Name", email="your.email@example.com", phone="+1-555-123-4567", location="City, State", linkedin="linkedin.com/in/your-profile", github="github.com/your-username"),
        summary="Data Engineer with X+ years of experience building scalable data pipelines, data warehouses, and analytics platforms. Processed Y+ TB of data daily and reduced ETL pipeline runtime by Z% through optimization and modern tooling.",
        target_role="data-engineer",
        years_of_experience=5,
        experience=[
            Experience(company="Current Company", title="Senior Data Engineer", location="City, State", start_date="Jan 2022", end_date="Present", bullets=[
                "Architected real-time data pipeline processing 5TB daily using Apache Spark and Kafka on Kubernetes",
                "Designed star schema data warehouse on Snowflake, reducing query time by 75% for analytics team",
                "Built data quality framework catching 99.5% of data anomalies before they reached production dashboards",
                "Implemented dbt transformation layer with 200+ models, enabling self-service analytics for 50+ analysts",
                "Reduced data pipeline costs by 45% through partition pruning, caching, and compute optimization",
            ], technologies=["Spark", "Kafka", "Snowflake", "dbt", "Airflow", "Python", "SQL"]),
        ],
        education=[Education(institution="University Name", degree="Master of Science", field_of_study="Data Science", graduation_date="2020")],
        skills=[
            SkillGroup(category="Data Processing", skills=["Apache Spark", "Apache Kafka", "Apache Flink", "Apache Beam"]),
            SkillGroup(category="Data Warehousing", skills=["Snowflake", "BigQuery", "Redshift", "Databricks"]),
            SkillGroup(category="Orchestration", skills=["Apache Airflow", "dbt", "Prefect", "Dagster"]),
            SkillGroup(category="Programming", skills=["Python", "SQL", "Scala", "Java", "Bash"]),
            SkillGroup(category="Cloud & Tools", skills=["AWS", "GCP", "Docker", "Kubernetes", "Git", "Terraform"]),
        ],
        certifications=[
            Certification(name="Google Cloud Professional Data Engineer", issuer="Google", date="2023"),
            Certification(name="Databricks Certified Data Engineer", issuer="Databricks", date="2022"),
        ],
        projects=[],
        languages=["English"],
    )


def _cloud_architect_template() -> ResumeData:
    return ResumeData(
        contact=ContactInfo(name="Your Full Name", email="your.email@example.com", phone="+1-555-123-4567", location="City, State", linkedin="linkedin.com/in/your-profile", github="github.com/your-username"),
        summary="Cloud Architect with X+ years of experience designing enterprise-grade cloud solutions across AWS, Azure, and GCP. Led cloud migrations for Y+ applications, achieving Z% cost reduction and 99.99% availability. Expert in Well-Architected Framework, security, and multi-cloud strategies.",
        target_role="cloud-architect",
        years_of_experience=8,
        experience=[
            Experience(company="Current Company", title="Principal Cloud Architect", location="City, State", start_date="Jan 2021", end_date="Present", bullets=[
                "Designed multi-cloud architecture spanning AWS and Azure, supporting 500+ microservices with 99.99% uptime",
                "Led cloud migration of 150+ on-premises applications to Azure, reducing infrastructure costs by $2.5M annually",
                "Established Azure Landing Zone architecture with governance, compliance, and security guardrails for 20+ teams",
                "Architected disaster recovery solution achieving RPO of 5 minutes and RTO of 15 minutes across 3 regions",
                "Created cost optimization framework identifying $800K in annual savings through right-sizing and reserved capacity",
            ], technologies=["AWS", "Azure", "Terraform", "Kubernetes", "Networking", "Security"]),
        ],
        education=[Education(institution="University Name", degree="Master of Science", field_of_study="Computer Science", graduation_date="2016")],
        skills=[
            SkillGroup(category="Cloud Platforms", skills=["AWS", "Azure", "GCP", "Multi-Cloud", "Hybrid Cloud"]),
            SkillGroup(category="Architecture", skills=["Well-Architected Framework", "Microservices", "Serverless", "Event-Driven"]),
            SkillGroup(category="Security & Compliance", skills=["IAM", "Zero Trust", "RBAC", "Encryption", "SOC 2", "HIPAA", "PCI-DSS"]),
            SkillGroup(category="Infrastructure as Code", skills=["Terraform", "CloudFormation", "Pulumi", "Bicep", "ARM Templates"]),
            SkillGroup(category="Networking", skills=["VPC/VNet", "Load Balancing", "CDN", "DNS", "VPN", "ExpressRoute"]),
        ],
        certifications=[
            Certification(name="AWS Solutions Architect Professional", issuer="Amazon", date="2023"),
            Certification(name="Azure Solutions Architect Expert", issuer="Microsoft", date="2022", credential_id="AZ-305"),
            Certification(name="Google Cloud Professional Cloud Architect", issuer="Google", date="2022"),
        ],
        projects=[],
        languages=["English"],
    )


def _sre_template() -> ResumeData:
    return ResumeData(
        contact=ContactInfo(name="Your Full Name", email="your.email@example.com", phone="+1-555-123-4567", location="City, State", linkedin="linkedin.com/in/your-profile", github="github.com/your-username"),
        summary="Site Reliability Engineer with X+ years ensuring the reliability, scalability, and performance of production systems. Achieved Y% uptime SLA across Z+ services. Expertise in observability, incident response, chaos engineering, and toil reduction.",
        target_role="sre",
        years_of_experience=5,
        experience=[
            Experience(company="Current Company", title="Senior SRE", location="City, State", start_date="Jan 2022", end_date="Present", bullets=[
                "Maintained 99.99% uptime SLA across 200+ production services handling 50M daily requests",
                "Designed SLI/SLO framework adopted by 15 engineering teams, improving reliability tracking by 80%",
                "Reduced Mean Time to Recovery (MTTR) from 2 hours to 15 minutes through automated runbooks and alerting",
                "Led chaos engineering program running 100+ experiments, identifying 25 critical failure modes before production impact",
                "Eliminated 60% of operational toil through automation, saving 20 hours/week of engineer time",
                "Built capacity planning models predicting infrastructure needs 6 months ahead with 95% accuracy",
            ], technologies=["Kubernetes", "Prometheus", "Grafana", "PagerDuty", "Terraform", "Python", "Go"]),
        ],
        education=[Education(institution="University Name", degree="Bachelor of Science", field_of_study="Computer Science", graduation_date="2019")],
        skills=[
            SkillGroup(category="Reliability", skills=["SLI/SLO/SLA", "Error Budgets", "Chaos Engineering", "Capacity Planning"]),
            SkillGroup(category="Observability", skills=["Prometheus", "Grafana", "Datadog", "OpenTelemetry", "ELK Stack", "Jaeger"]),
            SkillGroup(category="Incident Response", skills=["PagerDuty", "On-Call", "Post-Mortems", "Runbooks", "Escalation"]),
            SkillGroup(category="Infrastructure", skills=["Kubernetes", "Docker", "Terraform", "AWS", "Azure", "Linux"]),
            SkillGroup(category="Programming", skills=["Python", "Go", "Bash", "SQL"]),
        ],
        certifications=[
            Certification(name="Certified Kubernetes Administrator", issuer="CNCF", date="2023"),
            Certification(name="Google Cloud Professional SRE", issuer="Google", date="2022"),
        ],
        projects=[],
        languages=["English"],
    )


def _fullstack_developer_template() -> ResumeData:
    return ResumeData(
        contact=ContactInfo(name="Your Full Name", email="your.email@example.com", phone="+1-555-123-4567", location="City, State", linkedin="linkedin.com/in/your-profile", github="github.com/your-username"),
        summary="Full Stack Developer with X+ years building responsive web applications from frontend to backend. Delivered features used by Y+ users with focus on performance, accessibility, and clean code. Expert in React, Node.js, and cloud-native architectures.",
        target_role="fullstack-developer",
        years_of_experience=5,
        experience=[
            Experience(company="Current Company", title="Senior Full Stack Developer", location="City, State", start_date="Jan 2022", end_date="Present", bullets=[
                "Built and maintained customer-facing SaaS platform serving 100K+ monthly active users using React and Node.js",
                "Improved page load time by 60% through code splitting, lazy loading, and CDN optimization (LCP: 1.2s)",
                "Designed RESTful API architecture with 50+ endpoints, achieving 99.95% uptime and <100ms p95 latency",
                "Implemented real-time collaboration features using WebSockets, supporting 5K concurrent connections",
                "Led frontend architecture migration from class components to React Hooks, reducing bundle size by 35%",
            ], technologies=["React", "TypeScript", "Node.js", "PostgreSQL", "Redis", "Docker", "AWS"]),
        ],
        education=[Education(institution="University Name", degree="Bachelor of Science", field_of_study="Computer Science", graduation_date="2019")],
        skills=[
            SkillGroup(category="Frontend", skills=["React", "TypeScript", "Next.js", "Tailwind CSS", "Redux", "HTML5", "CSS3"]),
            SkillGroup(category="Backend", skills=["Node.js", "Express", "Python", "Django", "GraphQL", "REST APIs"]),
            SkillGroup(category="Databases", skills=["PostgreSQL", "MongoDB", "Redis", "DynamoDB"]),
            SkillGroup(category="Tools & Cloud", skills=["Docker", "AWS", "Git", "CI/CD", "Vercel", "Webpack", "Vite"]),
            SkillGroup(category="Testing", skills=["Jest", "React Testing Library", "Cypress", "Playwright"]),
        ],
        certifications=[
            Certification(name="AWS Cloud Practitioner", issuer="Amazon", date="2023"),
        ],
        projects=[],
        languages=["English"],
    )


def _backend_developer_template() -> ResumeData:
    return ResumeData(
        contact=ContactInfo(name="Your Full Name", email="your.email@example.com", phone="+1-555-123-4567", location="City, State", linkedin="linkedin.com/in/your-profile", github="github.com/your-username"),
        summary="Backend Developer with X+ years building high-performance APIs, distributed systems, and data-intensive services. Processed Y+ requests/second with sub-millisecond latency. Expert in Python, Go, and event-driven architectures.",
        target_role="backend-developer",
        years_of_experience=5,
        experience=[
            Experience(company="Current Company", title="Senior Backend Developer", location="City, State", start_date="Jan 2022", end_date="Present", bullets=[
                "Designed and built payment processing API handling $50M in monthly transactions with zero data loss",
                "Implemented event-driven architecture using Kafka, processing 2M events/hour across 15 microservices",
                "Optimized database queries reducing p99 latency from 800ms to 50ms, improving user experience for 500K users",
                "Built rate limiting and circuit breaker patterns preventing cascade failures during 10x traffic spikes",
                "Led API versioning strategy enabling backward-compatible evolution across 30+ consumer applications",
            ], technologies=["Python", "Go", "PostgreSQL", "Kafka", "Redis", "Docker", "Kubernetes"]),
        ],
        education=[Education(institution="University Name", degree="Bachelor of Science", field_of_study="Computer Science", graduation_date="2019")],
        skills=[
            SkillGroup(category="Programming Languages", skills=["Python", "Go", "Java", "TypeScript", "SQL"]),
            SkillGroup(category="Frameworks", skills=["FastAPI", "Django", "Spring Boot", "gRPC", "GraphQL"]),
            SkillGroup(category="Databases & Caching", skills=["PostgreSQL", "MongoDB", "Redis", "Elasticsearch", "DynamoDB"]),
            SkillGroup(category="Messaging & Streaming", skills=["Apache Kafka", "RabbitMQ", "SQS", "Event-Driven Architecture"]),
            SkillGroup(category="Infrastructure", skills=["Docker", "Kubernetes", "AWS", "CI/CD", "Terraform"]),
        ],
        certifications=[],
        projects=[],
        languages=["English"],
    )


def _frontend_developer_template() -> ResumeData:
    return ResumeData(
        contact=ContactInfo(name="Your Full Name", email="your.email@example.com", phone="+1-555-123-4567", location="City, State", linkedin="linkedin.com/in/your-profile", github="github.com/your-username"),
        summary="Frontend Developer with X+ years crafting performant, accessible web applications. Built interfaces used by Y+ users with Lighthouse scores of 95+. Expert in React ecosystem, design systems, and Web Core Vitals optimization.",
        target_role="frontend-developer",
        years_of_experience=5,
        experience=[
            Experience(company="Current Company", title="Senior Frontend Developer", location="City, State", start_date="Jan 2022", end_date="Present", bullets=[
                "Led development of component library with 80+ reusable components, adopted by 6 product teams",
                "Improved Core Web Vitals achieving LCP < 1s, FID < 50ms, CLS < 0.05 across all product pages",
                "Built micro-frontend architecture enabling independent deployments for 4 teams, reducing release cycles by 70%",
                "Implemented comprehensive accessibility (WCAG 2.1 AA), enabling product use by 15% more customers",
                "Reduced JavaScript bundle size by 45% through tree-shaking, code splitting, and dynamic imports",
            ], technologies=["React", "TypeScript", "Next.js", "Tailwind CSS", "Storybook", "Jest", "Cypress"]),
        ],
        education=[Education(institution="University Name", degree="Bachelor of Science", field_of_study="Computer Science", graduation_date="2019")],
        skills=[
            SkillGroup(category="Core", skills=["JavaScript", "TypeScript", "HTML5", "CSS3", "React", "Next.js"]),
            SkillGroup(category="Styling", skills=["Tailwind CSS", "Sass", "CSS Modules", "Styled Components", "Design Systems"]),
            SkillGroup(category="State & Data", skills=["Redux", "React Query", "GraphQL", "REST APIs", "WebSockets"]),
            SkillGroup(category="Testing", skills=["Jest", "React Testing Library", "Cypress", "Playwright", "Storybook"]),
            SkillGroup(category="Build & Tools", skills=["Webpack", "Vite", "ESLint", "Git", "Docker", "CI/CD", "Figma"]),
        ],
        certifications=[],
        projects=[],
        languages=["English"],
    )


def _ml_engineer_template() -> ResumeData:
    return ResumeData(
        contact=ContactInfo(name="Your Full Name", email="your.email@example.com", phone="+1-555-123-4567", location="City, State", linkedin="linkedin.com/in/your-profile", github="github.com/your-username"),
        summary="Machine Learning Engineer with X+ years building production ML systems from research to deployment. Deployed Y+ models serving Z+ predictions daily. Expert in deep learning, NLP, MLOps, and scalable ML infrastructure.",
        target_role="ml-engineer",
        years_of_experience=5,
        experience=[
            Experience(company="Current Company", title="Senior ML Engineer", location="City, State", start_date="Jan 2022", end_date="Present", bullets=[
                "Designed and deployed recommendation system generating $15M incremental revenue with 23% CTR improvement",
                "Built end-to-end MLOps pipeline reducing model training to production time from 2 weeks to 4 hours",
                "Implemented real-time inference serving 50K predictions/second with p99 latency under 20ms using TensorRT",
                "Led NLP team building sentiment analysis model achieving 94% accuracy on domain-specific data (15% above baseline)",
                "Created A/B testing framework enabling 100+ ML experiments per quarter with statistical rigor",
            ], technologies=["PyTorch", "TensorFlow", "Kubernetes", "MLflow", "Python", "Spark", "AWS SageMaker"]),
        ],
        education=[Education(institution="University Name", degree="Master of Science", field_of_study="Machine Learning", graduation_date="2020", gpa="3.9/4.0")],
        skills=[
            SkillGroup(category="ML Frameworks", skills=["PyTorch", "TensorFlow", "scikit-learn", "Hugging Face", "XGBoost"]),
            SkillGroup(category="MLOps", skills=["MLflow", "Kubeflow", "SageMaker", "Weights & Biases", "DVC"]),
            SkillGroup(category="Data Processing", skills=["Spark", "Pandas", "NumPy", "Dask", "Apache Beam"]),
            SkillGroup(category="Programming", skills=["Python", "SQL", "Scala", "C++", "Bash"]),
            SkillGroup(category="Infrastructure", skills=["Kubernetes", "Docker", "AWS", "GPU Computing", "Terraform"]),
        ],
        certifications=[
            Certification(name="AWS Machine Learning Specialty", issuer="Amazon", date="2023"),
            Certification(name="TensorFlow Developer Certificate", issuer="Google", date="2022"),
        ],
        projects=[],
        languages=["English"],
    )


def _product_manager_template() -> ResumeData:
    return ResumeData(
        contact=ContactInfo(name="Your Full Name", email="your.email@example.com", phone="+1-555-123-4567", location="City, State", linkedin="linkedin.com/in/your-profile"),
        summary="Product Manager with X+ years driving product strategy and execution for B2B/B2C SaaS platforms. Launched Y+ features generating $ZM in revenue. Expert in data-driven decision making, user research, and cross-functional team leadership.",
        target_role="product-manager",
        years_of_experience=5,
        experience=[
            Experience(company="Current Company", title="Senior Product Manager", location="City, State", start_date="Jan 2022", end_date="Present", bullets=[
                "Led product strategy for platform serving 500K+ users, driving 35% YoY revenue growth ($20M ARR)",
                "Launched 12 major features through discovery, design, development, and GTM, with 85% adoption rate",
                "Established OKR framework across 4 engineering teams, improving sprint velocity by 40%",
                "Conducted 200+ user interviews and A/B tests, increasing conversion rate by 28% quarter-over-quarter",
                "Managed product roadmap prioritization using RICE framework, aligning 6 stakeholder groups",
            ], technologies=["Jira", "Figma", "Amplitude", "SQL", "Mixpanel"]),
        ],
        education=[Education(institution="University Name", degree="MBA", field_of_study="Technology Management", graduation_date="2019")],
        skills=[
            SkillGroup(category="Product Management", skills=["Product Strategy", "Roadmapping", "User Research", "A/B Testing"]),
            SkillGroup(category="Frameworks", skills=["OKRs", "RICE", "Jobs-to-be-Done", "Design Thinking", "Lean Startup"]),
            SkillGroup(category="Analytics", skills=["SQL", "Amplitude", "Mixpanel", "Google Analytics", "Tableau"]),
            SkillGroup(category="Tools", skills=["Jira", "Confluence", "Figma", "Miro", "Notion"]),
            SkillGroup(category="Leadership", skills=["Stakeholder Management", "Cross-functional Leadership", "Agile/Scrum"]),
        ],
        certifications=[
            Certification(name="Product Management Certificate", issuer="Product School", date="2021"),
        ],
        projects=[],
        languages=["English"],
    )


# Register all templates
_ROLE_TEMPLATES["devops-engineer"] = _devops_engineer_template
_ROLE_TEMPLATES["software-engineer"] = _software_engineer_template
_ROLE_TEMPLATES["data-engineer"] = _data_engineer_template
_ROLE_TEMPLATES["cloud-architect"] = _cloud_architect_template
_ROLE_TEMPLATES["sre"] = _sre_template
_ROLE_TEMPLATES["fullstack-developer"] = _fullstack_developer_template
_ROLE_TEMPLATES["backend-developer"] = _backend_developer_template
_ROLE_TEMPLATES["frontend-developer"] = _frontend_developer_template
_ROLE_TEMPLATES["ml-engineer"] = _ml_engineer_template
_ROLE_TEMPLATES["product-manager"] = _product_manager_template
_ROLE_TEMPLATES["blank"] = _blank_template
