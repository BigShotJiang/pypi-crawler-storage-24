"""Demo resume data for instant showcase."""

from __future__ import annotations

from .models import (
    Certification,
    ContactInfo,
    Education,
    Experience,
    Project,
    ResumeData,
    SkillGroup,
)


def get_demo_resume() -> ResumeData:
    """Return a fully populated demo resume for showcase."""
    return ResumeData(
        contact=ContactInfo(
            name="Alex Morgan",
            email="alex.morgan@techmail.com",
            phone="+1-555-867-5309",
            location="San Francisco, CA",
            linkedin="linkedin.com/in/alexmorgan-devops",
            github="github.com/alexmorgan",
            website="alexmorgan.dev",
            portfolio="alexmorgan.dev/portfolio",
        ),
        summary=(
            "Senior DevOps Engineer with 7+ years of experience designing scalable cloud "
            "infrastructure, CI/CD pipelines, and container orchestration platforms. "
            "Managed 200+ microservices on Kubernetes with 99.99% uptime. "
            "Reduced infrastructure costs by 42% ($1.2M annually) and deployment time "
            "by 85% through automation and GitOps practices. "
            "Published 4 open-source CLI tools on PyPI."
        ),
        target_role="devops-engineer",
        years_of_experience=7,
        experience=[
            Experience(
                company="Nexus Technologies",
                title="Senior DevOps Engineer",
                location="San Francisco, CA",
                start_date="Mar 2022",
                end_date="Present",
                bullets=[
                    "Architected multi-region Kubernetes platform hosting 200+ microservices with 99.99% uptime serving 50M daily requests across 3 AWS regions",
                    "Designed and implemented GitOps-based deployment pipeline using ArgoCD, enabling 150+ zero-downtime deployments per week with automated canary analysis",
                    "Reduced cloud infrastructure costs by 42% ($1.2M annually) through right-sizing, spot instances, reserved capacity, and automated scaling policies",
                    "Built comprehensive observability stack with Prometheus, Grafana, and OpenTelemetry tracking 2,000+ metrics, reducing MTTR from 4 hours to 12 minutes",
                    "Led infrastructure-as-code initiative managing 500+ resources across 8 AWS accounts using Terraform with automated drift detection and compliance checks",
                    "Implemented shift-left security program integrating Trivy, OPA, and Falco, catching 95% of vulnerabilities before production deployment",
                ],
                technologies=[
                    "Kubernetes", "Docker", "Terraform", "AWS", "ArgoCD",
                    "Prometheus", "Grafana", "Python", "Go",
                ],
            ),
            Experience(
                company="CloudScale Inc.",
                title="DevOps Engineer",
                location="Austin, TX",
                start_date="Jun 2019",
                end_date="Feb 2022",
                bullets=[
                    "Containerized 45 legacy Java applications and migrated to Kubernetes, improving resource utilization by 65% and reducing hosting costs by $400K annually",
                    "Designed CI/CD pipelines using Jenkins and GitHub Actions for 30+ repositories, reducing build times from 45 minutes to 8 minutes (82% improvement)",
                    "Implemented centralized logging with ELK Stack processing 3TB of logs daily across 200+ servers with automated anomaly detection",
                    "Built disaster recovery solution achieving RPO of 5 minutes and RTO of 15 minutes across 2 regions using Terraform and automated failover",
                    "Automated infrastructure provisioning with Ansible playbooks, reducing server setup time from 2 days to 25 minutes",
                ],
                technologies=[
                    "Docker", "Kubernetes", "Jenkins", "GitHub Actions",
                    "Terraform", "Ansible", "ELK Stack", "AWS",
                ],
            ),
            Experience(
                company="DataFlow Systems",
                title="Junior DevOps Engineer",
                location="Austin, TX",
                start_date="Jul 2017",
                end_date="May 2019",
                bullets=[
                    "Managed Linux server fleet of 150+ machines using Ansible configuration management with 99.5% uptime",
                    "Built monitoring dashboards with Nagios and Grafana, reducing unplanned downtime by 60%",
                    "Wrote Python automation scripts eliminating 15 hours/week of manual deployment tasks",
                    "Supported migration of on-premises workloads to AWS, moving 25 applications in 6 months",
                ],
                technologies=[
                    "Linux", "Ansible", "Python", "Bash", "AWS",
                    "Nagios", "Grafana", "Docker",
                ],
            ),
        ],
        education=[
            Education(
                institution="University of Texas at Austin",
                degree="Bachelor of Science",
                field_of_study="Computer Science",
                graduation_date="2017",
                gpa="3.7/4.0",
                honors=["Dean's List", "Cum Laude"],
            ),
        ],
        skills=[
            SkillGroup(
                category="Cloud & Infrastructure",
                skills=["AWS", "Azure", "GCP", "Linux", "Networking", "Load Balancing"],
            ),
            SkillGroup(
                category="Containers & Orchestration",
                skills=["Docker", "Kubernetes", "Helm", "Istio", "ECS", "Docker Compose"],
            ),
            SkillGroup(
                category="CI/CD & GitOps",
                skills=[
                    "GitHub Actions", "Jenkins", "GitLab CI", "ArgoCD",
                    "FluxCD", "Azure DevOps", "Tekton",
                ],
            ),
            SkillGroup(
                category="Infrastructure as Code",
                skills=["Terraform", "Ansible", "Pulumi", "CloudFormation", "Crossplane"],
            ),
            SkillGroup(
                category="Monitoring & Observability",
                skills=[
                    "Prometheus", "Grafana", "Datadog", "ELK Stack",
                    "OpenTelemetry", "PagerDuty", "Jaeger",
                ],
            ),
            SkillGroup(
                category="Programming & Scripting",
                skills=["Python", "Go", "Bash", "PowerShell", "YAML", "HCL"],
            ),
            SkillGroup(
                category="Security",
                skills=["Trivy", "OPA", "Falco", "Vault", "RBAC", "mTLS"],
            ),
        ],
        certifications=[
            Certification(
                name="AWS Solutions Architect Professional",
                issuer="Amazon Web Services",
                date="2023",
                credential_id="SAP-C02",
            ),
            Certification(
                name="Certified Kubernetes Administrator (CKA)",
                issuer="Cloud Native Computing Foundation",
                date="2022",
                credential_id="CKA-2200-1234",
            ),
            Certification(
                name="Azure DevOps Engineer Expert",
                issuer="Microsoft",
                date="2022",
                credential_id="AZ-400",
            ),
            Certification(
                name="HashiCorp Certified Terraform Associate",
                issuer="HashiCorp",
                date="2021",
            ),
        ],
        projects=[
            Project(
                name="k8s-health-checker",
                description="CLI tool to scan Kubernetes clusters for health issues, misconfigurations, and security risks",
                url="github.com/alexmorgan/k8s-health-checker",
                technologies=["Python", "Click", "Rich", "Kubernetes API"],
                highlights=["Published on PyPI (pip install k8s-health-checker)", "22 automated tests, 100% pass rate"],
            ),
            Project(
                name="azure-cost-optimizer",
                description="Analyze Azure resources and generate cost optimization reports with projected savings",
                url="github.com/alexmorgan/azure-cost-optimizer",
                technologies=["Python", "Click", "Rich", "Azure SDK"],
                highlights=["Finds $83K+/year in savings across 5 categories", "67 automated tests"],
            ),
            Project(
                name="tf-module-scaffolder",
                description="Generate production-ready Terraform modules with best practices from 16 templates",
                url="github.com/alexmorgan/tf-module-scaffolder",
                technologies=["Python", "Click", "Rich", "Jinja2"],
                highlights=["16 templates across AWS/Azure/GCP", "94 automated tests"],
            ),
        ],
        languages=["English (Native)", "Spanish (Conversational)"],
    )
