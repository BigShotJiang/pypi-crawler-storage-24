"""Interactive resume building wizard."""

from __future__ import annotations

from rich.console import Console
from rich.panel import Panel
from rich.prompt import Confirm, IntPrompt, Prompt

from ..models import (
    Certification,
    ContactInfo,
    Education,
    Experience,
    Project,
    ResumeData,
    SkillGroup,
)
from ..templates.roles import get_available_templates, get_template

console = Console()


def run_wizard() -> ResumeData:
    """Run the interactive resume building wizard."""
    console.print(Panel(
        "[bold cyan]📄 ATS Resume Builder Wizard[/bold cyan]\n\n"
        "Answer the following questions to build your ATS-optimized resume.\n"
        "Press [bold]Enter[/bold] to skip optional fields.",
        border_style="cyan",
    ))

    # Step 1: Choose template or start from scratch
    resume = _choose_template()

    # Step 2: Contact Information
    resume.contact = _gather_contact()

    # Step 3: Professional Summary
    resume.summary = _gather_summary()

    # Step 4: Target Role
    resume.target_role = Prompt.ask(
        "\n[bold]Target role[/bold] (e.g., devops-engineer)", default=""
    )
    resume.years_of_experience = IntPrompt.ask(
        "[bold]Years of experience[/bold]", default=0
    )

    # Step 5: Work Experience
    resume.experience = _gather_experience()

    # Step 6: Skills
    resume.skills = _gather_skills()

    # Step 7: Education
    resume.education = _gather_education()

    # Step 8: Certifications
    resume.certifications = _gather_certifications()

    # Step 9: Projects
    resume.projects = _gather_projects()

    # Step 10: Languages
    languages_str = Prompt.ask(
        "\n[bold]Languages[/bold] (comma-separated)", default=""
    )
    if languages_str:
        resume.languages = [
            lang.strip() for lang in languages_str.split(",") if lang.strip()
        ]

    console.print("\n[bold green]✅ Resume data collected successfully![/bold green]")
    return resume


def _choose_template() -> ResumeData:
    """Let user choose a starting template."""
    console.print("\n[bold]📋 Choose a starting template:[/bold]\n")
    templates = get_available_templates()
    for i, (key, name) in enumerate(templates, 1):
        console.print(f"  [cyan]{i:2d}.[/cyan] {name}")

    choice = IntPrompt.ask(
        "\n[bold]Template number[/bold]",
        default=len(templates),  # Blank template
    )

    if 1 <= choice <= len(templates):
        key = templates[choice - 1][0]
        resume = get_template(key)
        console.print(
            f"\n[green]✓ Loaded template: {templates[choice - 1][1]}[/green]"
        )
    else:
        resume = ResumeData()

    return resume


def _gather_contact() -> ContactInfo:
    """Gather contact information."""
    console.print("\n[bold]📇 Contact Information[/bold]\n")
    return ContactInfo(
        name=Prompt.ask("  Full name", default=""),
        email=Prompt.ask("  Email", default=""),
        phone=Prompt.ask("  Phone", default=""),
        location=Prompt.ask("  Location (City, State)", default=""),
        linkedin=Prompt.ask("  LinkedIn URL", default=""),
        github=Prompt.ask("  GitHub URL", default=""),
        website=Prompt.ask("  Website/Portfolio URL", default=""),
    )


def _gather_summary() -> str:
    """Gather professional summary."""
    console.print("\n[bold]📝 Professional Summary[/bold]")
    console.print(
        "  [dim]2-4 sentences with years of experience,"
        " key skills, and achievements[/dim]"
    )
    return Prompt.ask("  Summary", default="")


def _gather_experience() -> list[Experience]:
    """Gather work experience."""
    console.print("\n[bold]💼 Work Experience[/bold]")
    experiences = []

    while True:
        if experiences:
            if not Confirm.ask(
                f"\n  Add another position? ({len(experiences)} added)", default=False
            ):
                break
        else:
            console.print("")

        console.print(f"  [cyan]Position {len(experiences) + 1}:[/cyan]")
        company = Prompt.ask("    Company", default="")
        if not company:
            break

        title = Prompt.ask("    Job Title", default="")
        location = Prompt.ask("    Location", default="")
        start = Prompt.ask("    Start Date (e.g., Jan 2022)", default="")
        end = Prompt.ask("    End Date (or 'Present')", default="Present")

        console.print("    [dim]Enter bullet points (empty line to finish):[/dim]")
        bullets = []
        while True:
            bullet = Prompt.ask(f"    Bullet {len(bullets) + 1}", default="")
            if not bullet:
                break
            bullets.append(bullet)

        tech_str = Prompt.ask("    Technologies (comma-separated)", default="")
        technologies = [
            t.strip() for t in tech_str.split(",") if t.strip()
        ] if tech_str else []

        experiences.append(Experience(
            company=company, title=title, location=location,
            start_date=start, end_date=end, bullets=bullets,
            technologies=technologies,
        ))

    return experiences


def _gather_skills() -> list[SkillGroup]:
    """Gather skills by category."""
    console.print("\n[bold]🛠️ Technical Skills[/bold]")
    console.print("  [dim]Enter skills by category[/dim]")
    groups = []

    while True:
        if groups:
            if not Confirm.ask(
                f"\n  Add another category? ({len(groups)} added)", default=False
            ):
                break
        else:
            console.print("")

        category = Prompt.ask("  Category name (e.g., 'Cloud & Infrastructure')", default="")
        if not category:
            break

        skills_str = Prompt.ask("  Skills (comma-separated)", default="")
        skills = [s.strip() for s in skills_str.split(",") if s.strip()]

        if skills:
            groups.append(SkillGroup(category=category, skills=skills))

    return groups


def _gather_education() -> list[Education]:
    """Gather education."""
    console.print("\n[bold]🎓 Education[/bold]\n")
    education = []

    institution = Prompt.ask("  Institution", default="")
    if institution:
        degree = Prompt.ask("  Degree (e.g., Bachelor of Science)", default="")
        field = Prompt.ask("  Field of Study", default="")
        grad_date = Prompt.ask("  Graduation Date", default="")
        gpa = Prompt.ask("  GPA (optional)", default="")

        education.append(Education(
            institution=institution, degree=degree,
            field_of_study=field, graduation_date=grad_date, gpa=gpa,
        ))

    return education


def _gather_certifications() -> list[Certification]:
    """Gather certifications."""
    console.print("\n[bold]📜 Certifications[/bold]")
    certs = []

    while True:
        if certs:
            if not Confirm.ask(
                f"\n  Add another certification? ({len(certs)} added)",
                default=False,
            ):
                break
        else:
            console.print("")

        name = Prompt.ask("  Certification name", default="")
        if not name:
            break

        issuer = Prompt.ask("  Issuer", default="")
        date = Prompt.ask("  Date", default="")

        certs.append(Certification(name=name, issuer=issuer, date=date))

    return certs


def _gather_projects() -> list[Project]:
    """Gather projects."""
    console.print("\n[bold]🚀 Projects[/bold]")
    projects = []

    while True:
        if projects:
            if not Confirm.ask(
                f"\n  Add another project? ({len(projects)} added)",
                default=False,
            ):
                break
        else:
            console.print("")

        name = Prompt.ask("  Project name", default="")
        if not name:
            break

        desc = Prompt.ask("  Description", default="")
        url = Prompt.ask("  URL", default="")

        tech_str = Prompt.ask("  Technologies (comma-separated)", default="")
        technologies = [
            t.strip() for t in tech_str.split(",") if t.strip()
        ] if tech_str else []

        console.print("  [dim]Enter highlights (empty line to finish):[/dim]")
        highlights = []
        while True:
            h = Prompt.ask(f"  Highlight {len(highlights) + 1}", default="")
            if not h:
                break
            highlights.append(h)

        projects.append(Project(
            name=name, description=desc, url=url,
            technologies=technologies, highlights=highlights,
        ))

    return projects
