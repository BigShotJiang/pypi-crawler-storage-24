"""Interactive resume building wizard."""
