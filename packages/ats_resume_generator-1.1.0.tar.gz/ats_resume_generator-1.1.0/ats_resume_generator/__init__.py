"""ATS Resume Generator — Generate ATS-optimized resumes that land jobs."""

__version__ = "1.1.0"
