"""CLI interface for ATS Resume Generator."""

from __future__ import annotations

from pathlib import Path

import click
from rich.console import Console

from .demo import get_demo_resume
from .models import GenerationResult, OutputFormat
from .output.console import (
    render_banner,
    render_generation_result,
    render_job_match,
    render_score_result,
    render_template_list,
)
from .parser import export_resume_yaml, parse_resume_file
from .scoring.engine import score_resume
from .templates.roles import get_available_templates, get_template

console = Console()


@click.group()
@click.version_option(version="1.1.0", prog_name="ats-resume")
def cli():
    """📄 ATS Resume Generator — Generate resumes that land jobs."""
    pass


@cli.command()
@click.option("--template", "-t", default="blank", help="Role template (e.g., devops-engineer)")
@click.option("--output", "-o", default="resume.yaml", help="Output YAML file path")
def init(template: str, output: str):
    """Create a resume YAML template to fill in."""
    render_banner()

    resume = get_template(template)
    out_path = export_resume_yaml(resume, output)

    console.print(f"\n[green]✅ Created resume template:[/green] {out_path}")
    console.print(f"[dim]   Template: {template}[/dim]")
    console.print("\n[bold]Next steps:[/bold]")
    console.print(f"  1. Edit [cyan]{output}[/cyan] with your details")
    console.print(f"  2. Run [cyan]ats-resume generate -i {output}[/cyan]")
    console.print(f"  3. Run [cyan]ats-resume score -i {output}[/cyan]")


@cli.command()
@click.option("--input", "-i", "input_file", default=None,
              help="Resume file (YAML, PDF, DOCX, TXT, MD, HTML)")
@click.option("--format", "-f", "formats", multiple=True,
              type=click.Choice(["pdf", "docx", "md", "html", "txt", "all"]),
              default=["pdf"], help="Output format(s)")
@click.option("--output-dir", "-o", default=".", help="Output directory")
@click.option("--demo", is_flag=True, help="Generate using demo data")
@click.option("--score", is_flag=True, help="Also run ATS scoring")
def generate(input_file: str | None, formats: tuple[str, ...], output_dir: str,
             demo: bool, score: bool):
    """Generate resume in multiple formats."""
    render_banner()

    # Load resume data
    if demo:
        resume = get_demo_resume()
        console.print("\n[yellow]📋 Using demo resume data[/yellow]")
    elif input_file:
        try:
            resume = parse_resume_file(input_file)
            console.print(f"\n[green]📋 Loaded:[/green] {input_file}")
        except (FileNotFoundError, ValueError) as e:
            console.print(f"\n[red]Error:[/red] {e}")
            raise SystemExit(1)
    else:
        console.print("\n[red]Error:[/red] Specify --input or --demo")
        console.print("[dim]  ats-resume generate --demo[/dim]")
        console.print("[dim]  ats-resume generate -i resume.yaml[/dim]")
        raise SystemExit(1)

    # Expand "all" format
    if "all" in formats:
        format_list = list(OutputFormat)
    else:
        format_list = [OutputFormat(f) for f in formats]

    # Generate name slug
    name_slug = resume.contact.name.lower().replace(" ", "-")
    if not name_slug or name_slug == "your-full-name":
        name_slug = "resume"

    # Generate files
    out_dir = Path(output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    results: list[GenerationResult] = []
    for fmt in format_list:
        out_path = str(out_dir / f"{name_slug}-resume.{fmt.value}")
        result = _generate_format(resume, fmt, out_path)
        results.append(result)

    render_generation_result(results)

    # Run scoring if requested
    if score:
        score_result = score_resume(resume)
        render_score_result(score_result)


@cli.command()
@click.option("--input", "-i", "input_file", default=None,
              help="Resume file (YAML, PDF, DOCX, TXT, MD, HTML)")
@click.option("--demo", is_flag=True, help="Score demo resume")
def score(input_file: str | None, demo: bool):
    """Score your resume for ATS compatibility (0-100)."""
    render_banner()

    if demo:
        resume = get_demo_resume()
        console.print("\n[yellow]📋 Scoring demo resume[/yellow]")
    elif input_file:
        try:
            resume = parse_resume_file(input_file)
            console.print(f"\n[green]📋 Loaded:[/green] {input_file}")
        except (FileNotFoundError, ValueError, ImportError) as e:
            console.print(f"\n[red]Error:[/red] {e}")
            raise SystemExit(1)
    else:
        console.print("\n[red]Error:[/red] Specify --input or --demo")
        console.print("[dim]  Supports: YAML, PDF, DOCX, TXT, MD, HTML[/dim]")
        raise SystemExit(1)

    result = score_resume(resume)
    render_score_result(result)


@cli.command(name="match")
@click.option("--input", "-i", "input_file", required=True,
              help="Resume file (YAML, PDF, DOCX, TXT, MD, HTML)")
@click.option("--job", "-j", "job_file", required=True, help="Job description text file")
def match_cmd(input_file: str, job_file: str):
    """Match your resume against a job description."""
    render_banner()

    from .optimizer.job_matcher import match_job_file

    try:
        resume = parse_resume_file(input_file)
    except (FileNotFoundError, ValueError, ImportError) as e:
        console.print(f"\n[red]Error:[/red] {e}")
        raise SystemExit(1)

    try:
        result = match_job_file(resume, job_file)
    except FileNotFoundError as e:
        console.print(f"\n[red]Error:[/red] {e}")
        raise SystemExit(1)

    render_job_match(result)


@cli.command()
def wizard():
    """Build your resume interactively step by step."""
    render_banner()

    from .wizard.interactive import run_wizard

    resume = run_wizard()

    # Ask where to save
    output = click.prompt(
        "\nSave resume YAML to", default="resume.yaml", type=str
    )
    out_path = export_resume_yaml(resume, output)
    console.print(f"\n[green]✅ Saved to:[/green] {out_path}")

    # Ask if user wants to generate
    if click.confirm("\nGenerate PDF now?", default=True):
        name_slug = resume.contact.name.lower().replace(" ", "-")
        if not name_slug:
            name_slug = "resume"
        pdf_path = f"{name_slug}-resume.pdf"
        result = _generate_format(resume, OutputFormat.PDF, pdf_path)
        render_generation_result([result])

    # Run scoring
    if click.confirm("Run ATS score analysis?", default=True):
        score_result = score_resume(resume)
        render_score_result(score_result)


@cli.command(name="templates")
def list_templates():
    """List all available resume templates."""
    render_banner()
    templates = get_available_templates()
    render_template_list(templates)

    console.print("\n[bold]Usage:[/bold]")
    console.print("  [cyan]ats-resume init --template devops-engineer[/cyan]")
    console.print("  [cyan]ats-resume init --template sre[/cyan]")
    console.print("  [cyan]ats-resume init --template software-engineer[/cyan]")


@cli.command()
def demo():
    """Generate a complete demo resume to see the tool in action."""
    render_banner()
    console.print("\n[yellow]🎯 Generating demo resume in all formats...[/yellow]\n")

    resume = get_demo_resume()
    name_slug = resume.contact.name.lower().replace(" ", "-")

    results: list[GenerationResult] = []
    for fmt in OutputFormat:
        out_path = f"{name_slug}-resume.{fmt.value}"
        result = _generate_format(resume, fmt, out_path)
        results.append(result)

    render_generation_result(results)

    # Also show score
    score_result = score_resume(resume)
    render_score_result(score_result)


def _generate_format(
    resume, fmt: OutputFormat, output_path: str
) -> GenerationResult:
    """Generate a single format."""
    try:
        if fmt == OutputFormat.PDF:
            from .generators.pdf import generate_pdf
            path = generate_pdf(resume, output_path)
        elif fmt == OutputFormat.DOCX:
            from .generators.docx_gen import generate_docx
            path = generate_docx(resume, output_path)
        elif fmt == OutputFormat.MARKDOWN:
            from .generators.markdown import generate_markdown
            path = generate_markdown(resume, output_path)
        elif fmt == OutputFormat.HTML:
            from .generators.html import generate_html
            path = generate_html(resume, output_path)
        elif fmt == OutputFormat.TEXT:
            from .generators.text import generate_text
            path = generate_text(resume, output_path)
        else:
            return GenerationResult(
                format=fmt, success=False, error=f"Unknown format: {fmt}"
            )

        return GenerationResult(
            output_path=path, format=fmt, success=True
        )
    except Exception as e:
        return GenerationResult(
            format=fmt, success=False, error=str(e)
        )
