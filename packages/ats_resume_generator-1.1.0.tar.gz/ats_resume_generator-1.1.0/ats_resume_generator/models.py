"""Data models for ATS Resume Generator."""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Optional


class SkillCategory(str, Enum):
    """Skill categories for organized display."""
    CLOUD = "Cloud & Infrastructure"
    CONTAINERS = "Containers & Orchestration"
    CICD = "CI/CD & Automation"
    IAC = "Infrastructure as Code"
    MONITORING = "Monitoring & Observability"
    SECURITY = "Security & Compliance"
    PROGRAMMING = "Programming & Scripting"
    DATABASES = "Databases"
    NETWORKING = "Networking"
    OS = "Operating Systems"
    TOOLS = "Tools & Platforms"
    FRAMEWORKS = "Frameworks & Libraries"
    SOFT = "Soft Skills"
    OTHER = "Other"


class ScoreGrade(str, Enum):
    """ATS score letter grade."""
    A_PLUS = "A+"
    A = "A"
    B = "B"
    C = "C"
    D = "D"
    F = "F"

    @classmethod
    def from_score(cls, score: int) -> "ScoreGrade":
        if score >= 95:
            return cls.A_PLUS
        if score >= 85:
            return cls.A
        if score >= 75:
            return cls.B
        if score >= 60:
            return cls.C
        if score >= 40:
            return cls.D
        return cls.F


class Severity(str, Enum):
    """Severity level for scoring findings."""
    CRITICAL = "critical"
    WARNING = "warning"
    INFO = "info"
    PASS = "pass"


class OutputFormat(str, Enum):
    """Supported output formats."""
    PDF = "pdf"
    DOCX = "docx"
    MARKDOWN = "md"
    HTML = "html"
    TEXT = "txt"


@dataclass
class ContactInfo:
    """Contact information."""
    name: str = ""
    email: str = ""
    phone: str = ""
    location: str = ""
    linkedin: str = ""
    github: str = ""
    website: str = ""
    portfolio: str = ""


@dataclass
class Experience:
    """Work experience entry."""
    company: str = ""
    title: str = ""
    location: str = ""
    start_date: str = ""
    end_date: str = "Present"
    bullets: list[str] = field(default_factory=list)
    technologies: list[str] = field(default_factory=list)


@dataclass
class Education:
    """Education entry."""
    institution: str = ""
    degree: str = ""
    field_of_study: str = ""
    graduation_date: str = ""
    gpa: str = ""
    honors: list[str] = field(default_factory=list)


@dataclass
class Certification:
    """Professional certification."""
    name: str = ""
    issuer: str = ""
    date: str = ""
    credential_id: str = ""
    url: str = ""


@dataclass
class Project:
    """Personal or open source project."""
    name: str = ""
    description: str = ""
    url: str = ""
    technologies: list[str] = field(default_factory=list)
    highlights: list[str] = field(default_factory=list)


@dataclass
class SkillGroup:
    """A group of related skills."""
    category: str = ""
    skills: list[str] = field(default_factory=list)


@dataclass
class ResumeData:
    """Complete resume data model."""
    contact: ContactInfo = field(default_factory=ContactInfo)
    summary: str = ""
    experience: list[Experience] = field(default_factory=list)
    education: list[Education] = field(default_factory=list)
    skills: list[SkillGroup] = field(default_factory=list)
    certifications: list[Certification] = field(default_factory=list)
    projects: list[Project] = field(default_factory=list)
    languages: list[str] = field(default_factory=list)
    target_role: str = ""
    years_of_experience: int = 0

    def all_skills_flat(self) -> list[str]:
        """Return all skills as a flat list."""
        result = []
        for group in self.skills:
            result.extend(group.skills)
        return result

    def total_bullets(self) -> int:
        """Count total bullet points across all experience."""
        return sum(len(exp.bullets) for exp in self.experience)


@dataclass
class ScoreFinding:
    """A single finding from the ATS scoring engine."""
    category: str
    message: str
    severity: Severity
    suggestion: str = ""
    points_impact: int = 0


@dataclass
class ScoreResult:
    """Complete ATS score result."""
    total_score: int = 0
    max_score: int = 100
    grade: ScoreGrade = ScoreGrade.F
    findings: list[ScoreFinding] = field(default_factory=list)
    section_scores: dict[str, int] = field(default_factory=dict)

    @property
    def pass_count(self) -> int:
        return sum(1 for f in self.findings if f.severity == Severity.PASS)

    @property
    def warning_count(self) -> int:
        return sum(1 for f in self.findings if f.severity == Severity.WARNING)

    @property
    def critical_count(self) -> int:
        return sum(1 for f in self.findings if f.severity == Severity.CRITICAL)

    @property
    def info_count(self) -> int:
        return sum(1 for f in self.findings if f.severity == Severity.INFO)


@dataclass
class JobMatch:
    """Result of matching resume against a job description."""
    match_percentage: int = 0
    matched_keywords: list[str] = field(default_factory=list)
    missing_keywords: list[str] = field(default_factory=list)
    matched_skills: list[str] = field(default_factory=list)
    missing_skills: list[str] = field(default_factory=list)
    suggestions: list[str] = field(default_factory=list)
    experience_match: bool = False
    education_match: bool = False


@dataclass
class GenerationResult:
    """Result of resume generation."""
    output_path: str = ""
    format: OutputFormat = OutputFormat.PDF
    score: Optional[ScoreResult] = None
    success: bool = False
    error: str = ""
