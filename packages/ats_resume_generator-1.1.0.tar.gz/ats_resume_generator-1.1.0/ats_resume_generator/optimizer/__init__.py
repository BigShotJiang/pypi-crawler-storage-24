"""Resume optimizer — job matching and keyword optimization."""
