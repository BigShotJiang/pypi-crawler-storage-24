"""Action verb library for resume optimization."""

from __future__ import annotations

# Strong action verbs categorized by impact type
LEADERSHIP_VERBS = [
    "spearheaded", "orchestrated", "directed", "championed", "pioneered",
    "led", "managed", "oversaw", "supervised", "mentored", "coached",
    "established", "founded", "launched", "initiated", "drove",
    "influenced", "guided", "shaped", "transformed", "mobilized",
]

TECHNICAL_VERBS = [
    "engineered", "architected", "implemented", "developed", "designed",
    "built", "created", "configured", "deployed", "automated",
    "integrated", "optimized", "refactored", "migrated", "provisioned",
    "containerized", "orchestrated", "instrumented", "debugged", "resolved",
    "programmed", "coded", "scripted", "compiled", "maintained",
]

ACHIEVEMENT_VERBS = [
    "delivered", "achieved", "exceeded", "surpassed", "accomplished",
    "completed", "attained", "earned", "secured", "won",
    "generated", "increased", "improved", "boosted", "maximized",
    "accelerated", "expanded", "elevated", "strengthened", "enhanced",
]

EFFICIENCY_VERBS = [
    "optimized", "streamlined", "simplified", "consolidated", "eliminated",
    "reduced", "decreased", "minimized", "cut", "saved",
    "accelerated", "expedited", "fast-tracked", "modernized", "upgraded",
    "standardized", "centralized", "unified", "systematized", "reorganized",
]

ANALYSIS_VERBS = [
    "analyzed", "evaluated", "assessed", "diagnosed", "investigated",
    "researched", "identified", "discovered", "examined", "audited",
    "monitored", "tracked", "measured", "quantified", "benchmarked",
    "reviewed", "validated", "verified", "tested", "inspected",
]

COLLABORATION_VERBS = [
    "collaborated", "partnered", "coordinated", "facilitated", "aligned",
    "negotiated", "presented", "communicated", "advocated", "represented",
    "liaised", "consulted", "advised", "supported", "trained",
    "onboarded", "educated", "documented", "briefed", "reported",
]

ALL_STRONG_VERBS = sorted(set(
    LEADERSHIP_VERBS + TECHNICAL_VERBS + ACHIEVEMENT_VERBS
    + EFFICIENCY_VERBS + ANALYSIS_VERBS + COLLABORATION_VERBS
))

# Weak verbs and phrases to avoid — with suggested replacements
WEAK_VERBS: dict[str, list[str]] = {
    "responsible for": ["led", "managed", "oversaw", "directed", "spearheaded"],
    "helped": ["collaborated on", "contributed to", "supported", "facilitated"],
    "worked on": ["developed", "engineered", "built", "implemented", "delivered"],
    "assisted": ["supported", "facilitated", "contributed to", "enabled"],
    "involved in": ["contributed to", "participated in", "drove", "led"],
    "handled": ["managed", "directed", "administered", "executed", "resolved"],
    "did": ["executed", "performed", "completed", "delivered", "accomplished"],
    "made": ["created", "developed", "designed", "produced", "built"],
    "got": ["achieved", "secured", "obtained", "earned", "attained"],
    "used": ["leveraged", "utilized", "applied", "employed", "implemented"],
    "worked with": ["collaborated with", "partnered with", "coordinated with"],
    "was part of": ["contributed to", "participated in", "played a key role in"],
    "in charge of": ["led", "managed", "directed", "oversaw", "headed"],
    "duties included": ["delivered", "executed", "managed", "drove"],
    "participated in": ["contributed to", "collaborated on", "drove"],
    "tasked with": ["led", "managed", "executed", "delivered", "drove"],
}

# Quantification patterns — what makes a bullet point measurable
QUANTIFICATION_PATTERNS = [
    r"\d+%",           # percentages
    r"\$[\d,]+",       # dollar amounts
    r"\d+x",           # multipliers
    r"\d+\+",          # numbers with plus
    r"\d+k\b",         # thousands
    r"\d+M\b",         # millions
    r"\d+ (?:team|teams|engineers|developers|members)",  # team sizes
    r"\d+ (?:services|microservices|applications|servers|nodes|clusters)",  # scale
    r"\d+ (?:minutes|hours|days|weeks|months)",  # time savings
    r"(?:reduced|decreased|cut|saved).*\d+",     # reductions with numbers
    r"(?:increased|improved|grew|boosted).*\d+", # improvements with numbers
    r"\d+/\d+",        # ratios or uptime (99.9/100)
    r"\d+\.\d+%",      # decimal percentages
]

# Impact keywords that indicate measurable results
IMPACT_KEYWORDS = [
    "reduced", "increased", "improved", "saved", "generated",
    "grew", "decreased", "cut", "boosted", "accelerated",
    "eliminated", "doubled", "tripled", "halved", "achieved",
    "delivered", "exceeded", "surpassed", "maximized", "minimized",
]


def find_weak_verbs(text: str) -> list[tuple[str, list[str]]]:
    """Find weak verbs in text and return (weak_verb, suggestions) pairs."""
    text_lower = text.lower()
    found = []
    for weak, suggestions in WEAK_VERBS.items():
        if weak in text_lower:
            found.append((weak, suggestions))
    return found


def starts_with_action_verb(bullet: str) -> bool:
    """Check if a bullet point starts with a strong action verb."""
    words = bullet.strip().lstrip("•-– ").split()
    if not words:
        return False
    # Check the actual first word against all strong verbs
    first_actual = words[0].lower()
    for verb in ALL_STRONG_VERBS:
        if first_actual == verb or first_actual.startswith(verb[:4]):
            return True
    # Also accept capitalized verbs
    return first_actual in {v for v in ALL_STRONG_VERBS}


def has_quantification(bullet: str) -> bool:
    """Check if a bullet point contains quantified results."""
    import re
    for pattern in QUANTIFICATION_PATTERNS:
        if re.search(pattern, bullet, re.IGNORECASE):
            return True
    return False


def suggest_stronger_verb(verb: str) -> list[str]:
    """Suggest stronger alternatives for a given verb."""
    verb_lower = verb.lower()
    # Check weak verbs first
    for weak, suggestions in WEAK_VERBS.items():
        if verb_lower in weak or weak.startswith(verb_lower):
            return suggestions
    return []
