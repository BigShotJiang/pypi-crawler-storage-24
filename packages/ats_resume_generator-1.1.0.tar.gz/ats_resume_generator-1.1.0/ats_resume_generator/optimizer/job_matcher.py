"""Job Description Matcher — match resume against job postings."""

from __future__ import annotations

import re
from pathlib import Path

from ..models import JobMatch, ResumeData
from ..scoring.keywords import SKILL_DATABASES, extract_keywords_from_text


def match_job_description(resume: ResumeData, job_text: str) -> JobMatch:
    """Match a resume against a job description text."""
    # Extract keywords from job description
    jd_keywords = extract_keywords_from_text(job_text)

    # Get all resume text
    resume_text = _get_resume_text(resume).lower()

    # Match keywords
    matched_keywords = []
    missing_keywords = []
    for kw in jd_keywords:
        if kw.lower() in resume_text:
            matched_keywords.append(kw)
        else:
            missing_keywords.append(kw)

    # Match skills specifically
    jd_skills = _extract_skills_from_jd(job_text)
    matched_skills = [s for s in jd_skills if s.lower() in resume_text]
    missing_skills = [s for s in jd_skills if s.lower() not in resume_text]

    # Calculate overall match
    total_keywords = len(jd_keywords) if jd_keywords else 1
    match_pct = round(len(matched_keywords) / total_keywords * 100)

    # Check experience match
    exp_match = _check_experience_match(resume, job_text)

    # Check education match
    edu_match = _check_education_match(resume, job_text)

    # Generate suggestions
    suggestions = _generate_suggestions(
        missing_keywords, missing_skills, exp_match, edu_match, match_pct
    )

    return JobMatch(
        match_percentage=min(100, match_pct),
        matched_keywords=matched_keywords,
        missing_keywords=missing_keywords,
        matched_skills=matched_skills,
        missing_skills=missing_skills,
        suggestions=suggestions,
        experience_match=exp_match,
        education_match=edu_match,
    )


def match_job_file(resume: ResumeData, job_file: str) -> JobMatch:
    """Match resume against a job description from a file."""
    path = Path(job_file)
    if not path.exists():
        raise FileNotFoundError(f"Job description file not found: {job_file}")

    job_text = path.read_text(encoding="utf-8")
    return match_job_description(resume, job_text)


def _get_resume_text(resume: ResumeData) -> str:
    """Get all text from resume."""
    parts = [resume.summary, resume.contact.name, resume.target_role]
    for exp in resume.experience:
        parts.extend([exp.title, exp.company])
        parts.extend(exp.bullets)
        parts.extend(exp.technologies)
    for edu in resume.education:
        parts.extend([edu.degree, edu.field_of_study, edu.institution])
    for group in resume.skills:
        parts.extend(group.skills)
    for cert in resume.certifications:
        parts.extend([cert.name, cert.issuer])
    for proj in resume.projects:
        parts.extend([proj.name, proj.description])
        parts.extend(proj.technologies)
        parts.extend(proj.highlights)
    return " ".join(p for p in parts if p)


def _extract_skills_from_jd(job_text: str) -> list[str]:
    """Extract specific skills mentioned in a job description."""
    text_lower = job_text.lower()
    found_skills = []

    for category, skills in SKILL_DATABASES.items():
        for skill in skills:
            if skill.lower() in text_lower:
                found_skills.append(skill)

    return sorted(set(found_skills))


def _check_experience_match(resume: ResumeData, job_text: str) -> bool:
    """Check if resume experience matches job requirements."""
    # Look for years requirement in JD
    years_patterns = [
        r"(\d+)\+?\s*years?\s*(?:of\s+)?experience",
        r"(\d+)\+?\s*years?\s*(?:of\s+)?(?:relevant|professional)",
        r"minimum\s+(\d+)\s*years?",
        r"at\s+least\s+(\d+)\s*years?",
    ]

    required_years = 0
    for pattern in years_patterns:
        match = re.search(pattern, job_text, re.IGNORECASE)
        if match:
            required_years = int(match.group(1))
            break

    if required_years == 0:
        return True  # No requirement found

    return resume.years_of_experience >= required_years


def _check_education_match(resume: ResumeData, job_text: str) -> bool:
    """Check if resume education matches job requirements."""
    text_lower = job_text.lower()

    # Check if degree is required
    degree_required = any(
        term in text_lower
        for term in ["bachelor", "master", "degree", "b.s.", "b.e.", "m.s."]
    )

    if not degree_required:
        return True

    return len(resume.education) > 0


def _generate_suggestions(
    missing_keywords: list[str],
    missing_skills: list[str],
    exp_match: bool,
    edu_match: bool,
    match_pct: int,
) -> list[str]:
    """Generate actionable suggestions to improve match."""
    suggestions = []

    if match_pct < 50:
        suggestions.append(
            "Your resume matches less than 50% of keywords. "
            "Consider tailoring it significantly for this role."
        )

    if missing_skills:
        top_missing = missing_skills[:5]
        suggestions.append(
            f"Add these missing skills if applicable: {', '.join(top_missing)}"
        )

    if missing_keywords:
        top_kws = missing_keywords[:5]
        suggestions.append(
            f"Consider incorporating these keywords: {', '.join(top_kws)}"
        )

    if not exp_match:
        suggestions.append(
            "Your years of experience may not meet the requirement. "
            "Highlight relevant experience and transferable skills."
        )

    if not edu_match:
        suggestions.append(
            "Education requirement detected but no education listed. "
            "Add your educational background."
        )

    if match_pct >= 70:
        suggestions.append(
            "Good keyword match! Focus on quantifying your achievements "
            "to stand out among other qualified candidates."
        )

    return suggestions
