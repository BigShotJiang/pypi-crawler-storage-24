"""Console output with Rich."""
