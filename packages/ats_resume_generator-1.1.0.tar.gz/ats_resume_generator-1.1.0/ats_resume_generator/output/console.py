"""Rich console output for beautiful terminal display."""

from __future__ import annotations

import sys

from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.tree import Tree

from ..models import (
    GenerationResult,
    JobMatch,
    ScoreResult,
    Severity,
)


def _ensure_utf8() -> None:
    """Ensure stdout supports UTF-8."""
    if hasattr(sys.stdout, "reconfigure"):
        try:
            sys.stdout.reconfigure(encoding="utf-8")
        except Exception:
            pass


_ensure_utf8()

console = Console()


def render_score_result(result: ScoreResult) -> None:
    """Render the ATS score result with beautiful formatting."""
    # Grade color
    grade_colors = {
        "A+": "bold green", "A": "green", "B": "yellow",
        "C": "dark_orange", "D": "red", "F": "bold red",
    }
    grade_style = grade_colors.get(result.grade.value, "white")

    # Score bar
    filled = result.total_score // 5
    empty = 20 - filled
    bar_color = "green" if result.total_score >= 75 else (
        "yellow" if result.total_score >= 50 else "red"
    )
    score_bar = (
        f"[{bar_color}]{'█' * filled}[/{bar_color}]"
        f"[dim]{'░' * empty}[/dim]"
    )

    # Header panel
    console.print(Panel(
        f"[bold]ATS Resume Score[/bold]\n\n"
        f"  Score:  {score_bar}  [bold]{result.total_score}[/bold]/100\n"
        f"  Grade:  [{grade_style}]{result.grade.value}[/{grade_style}]\n\n"
        f"  ✅ Passed: {result.pass_count}  "
        f"⚠️  Warnings: {result.warning_count}  "
        f"❌ Critical: {result.critical_count}  "
        f"ℹ️  Info: {result.info_count}",
        title="📊 ATS Score Report",
        border_style="cyan",
        padding=(1, 2),
    ))

    # Section scores table
    section_table = Table(
        title="Section Scores",
        show_header=True,
        header_style="bold",
        padding=(0, 1),
    )
    section_table.add_column("Section", style="cyan", min_width=20)
    section_table.add_column("Score", justify="right", min_width=8)
    section_table.add_column("Bar", min_width=15)

    for section, score in result.section_scores.items():
        bar_len = score // 10
        color = "green" if score >= 75 else ("yellow" if score >= 50 else "red")
        bar = f"[{color}]{'█' * bar_len}[/{color}][dim]{'░' * (10 - bar_len)}[/dim]"
        section_table.add_row(section, f"{score}/100", bar)

    console.print(section_table)

    # Findings
    findings_table = Table(
        title="Detailed Findings",
        show_header=True,
        header_style="bold",
        padding=(0, 1),
    )
    findings_table.add_column("", min_width=3)
    findings_table.add_column("Category", style="cyan", min_width=16)
    findings_table.add_column("Finding", min_width=40)
    findings_table.add_column("Suggestion", min_width=30)

    severity_icons = {
        Severity.PASS: "[green]✅[/green]",
        Severity.INFO: "[blue]ℹ️[/blue]",
        Severity.WARNING: "[yellow]⚠️[/yellow]",
        Severity.CRITICAL: "[red]❌[/red]",
    }

    for finding in result.findings:
        icon = severity_icons.get(finding.severity, "")
        suggestion = finding.suggestion or ""
        findings_table.add_row(
            icon, finding.category, finding.message,
            f"[dim]{suggestion}[/dim]" if suggestion else "",
        )

    console.print(findings_table)


def render_job_match(match: JobMatch) -> None:
    """Render job description match results."""
    # Match percentage color
    if match.match_percentage >= 70:
        pct_style = "bold green"
        verdict = "Strong Match"
    elif match.match_percentage >= 50:
        pct_style = "bold yellow"
        verdict = "Moderate Match"
    else:
        pct_style = "bold red"
        verdict = "Weak Match"

    # Header
    filled = match.match_percentage // 5
    empty = 20 - filled
    bar_color = "green" if match.match_percentage >= 70 else (
        "yellow" if match.match_percentage >= 50 else "red"
    )
    match_bar = (
        f"[{bar_color}]{'█' * filled}[/{bar_color}]"
        f"[dim]{'░' * empty}[/dim]"
    )

    console.print(Panel(
        f"[bold]Job Match Analysis[/bold]\n\n"
        f"  Match:  {match_bar}  [{pct_style}]{match.match_percentage}%[/{pct_style}]\n"
        f"  Verdict: [{pct_style}]{verdict}[/{pct_style}]\n\n"
        f"  ✅ Matched Keywords: {len(match.matched_keywords)}\n"
        f"  ❌ Missing Keywords: {len(match.missing_keywords)}\n"
        f"  🛠️  Matched Skills: {len(match.matched_skills)}\n"
        f"  📋 Missing Skills: {len(match.missing_skills)}",
        title="🎯 Job Match Report",
        border_style="magenta",
        padding=(1, 2),
    ))

    # Matched keywords
    if match.matched_keywords:
        kw_table = Table(title="Matched Keywords", show_header=False)
        kw_table.add_column("Keywords", style="green")
        # Show in rows of 5
        for i in range(0, len(match.matched_keywords), 5):
            chunk = match.matched_keywords[i:i + 5]
            kw_table.add_row(", ".join(chunk))
        console.print(kw_table)

    # Missing keywords
    if match.missing_keywords:
        missing_table = Table(title="Missing Keywords (Add to Resume)", show_header=False)
        missing_table.add_column("Keywords", style="red")
        for i in range(0, len(match.missing_keywords), 5):
            chunk = match.missing_keywords[i:i + 5]
            missing_table.add_row(", ".join(chunk))
        console.print(missing_table)

    # Suggestions
    if match.suggestions:
        console.print(Panel(
            "\n".join(f"  💡 {s}" for s in match.suggestions),
            title="💡 Suggestions",
            border_style="yellow",
        ))


def render_generation_result(results: list[GenerationResult]) -> None:
    """Render resume generation results."""
    tree = Tree("📄 [bold]Generated Resume Files[/bold]")

    for result in results:
        if result.success:
            icon = "✅"
            fmt = result.format.value.upper()
            tree.add(f"{icon} [green]{fmt}[/green] → {result.output_path}")
        else:
            icon = "❌"
            tree.add(f"{icon} [red]{result.format.value.upper()}: {result.error}[/red]")

    console.print(Panel(tree, border_style="green"))


def render_template_list(templates: list[tuple[str, str]]) -> None:
    """Render available resume templates."""
    table = Table(
        title="📋 Available Resume Templates",
        show_header=True,
        header_style="bold cyan",
    )
    table.add_column("#", justify="right", style="dim", width=4)
    table.add_column("Template Key", style="cyan", min_width=20)
    table.add_column("Role Name", min_width=30)

    for i, (key, name) in enumerate(templates, 1):
        table.add_row(str(i), key, name)

    console.print(table)


def render_banner() -> None:
    """Render the ATS Resume Generator banner."""
    from ats_resume_generator import __version__
    console.print(Panel(
        f"[bold cyan]📄 ATS Resume Generator[/bold cyan] v{__version__}\n"
        "[dim]Generate ATS-optimized resumes that land interviews[/dim]",
        border_style="cyan",
        padding=(0, 2),
    ))
