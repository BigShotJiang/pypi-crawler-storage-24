# 📄 ATS Resume Generator

[![PyPI version](https://badge.fury.io/py/ats-resume-generator.svg)](https://pypi.org/project/ats-resume-generator/)
[![Python](https://img.shields.io/pypi/pyversions/ats-resume-generator.svg)](https://pypi.org/project/ats-resume-generator/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Tests](https://github.com/SanjaySundarMurthy/ats-resume-generator/actions/workflows/ci.yml/badge.svg)](https://github.com/SanjaySundarMurthy/ats-resume-generator/actions)

> **Generate ATS-optimized resumes that land interviews.** Intelligent scoring engine, job description matching, multi-format export (PDF/DOCX/MD/HTML/TXT), and 10 role-specific templates — all from the command line.

---

## 🚀 Why ATS Resume Generator?

**75% of resumes are rejected by ATS before a human ever sees them.** This tool ensures yours gets through.

| Feature | Description |
|---------|-------------|
| 🎯 **ATS Scoring Engine** | 12-point analysis with weighted scoring across Contact, Summary, Experience, Skills, Action Verbs, Quantification, Keywords, and more |
| 📊 **Job Description Matcher** | Match your resume against any job posting — see matched/missing keywords and get actionable suggestions |
| 📝 **5 Output Formats** | PDF, DOCX, Markdown, HTML, and Plain Text — all ATS-friendly with clean formatting |
| 🏗️ **10 Role Templates** | Pre-built templates for DevOps, Software Engineer, Cloud Architect, SRE, Data Engineer, ML Engineer, and more |
| 🧙 **Interactive Wizard** | Step-by-step resume building with guided prompts |
| ⚡ **Action Verb Optimizer** | Detects weak phrases ("responsible for", "worked on") and suggests power verbs |
| 📈 **Quantification Checker** | Ensures your bullets have measurable achievements ($, %, numbers) |
| 🔑 **Keyword Analysis** | Role-specific keyword databases for 10+ job titles |

---

## 📦 Installation

```bash
pip install ats-resume-generator
```

**Requirements:** Python 3.9+

---

## ⚡ Quick Start

### 1. Generate a Demo Resume (See It in Action)

```bash
ats-resume demo
```

Generates a complete demo resume in **all 5 formats** and shows the ATS score report.

### 2. Create Your Resume from a Template

```bash
# List available templates
ats-resume templates

# Create a DevOps Engineer resume template
ats-resume init --template devops-engineer

# Or use the interactive wizard
ats-resume wizard
```

### 3. Edit Your YAML File

```yaml
contact:
  name: Jane Doe
  email: jane.doe@example.com
  phone: "+1 (555) 123-4567"
  location: San Francisco, CA
  linkedin: linkedin.com/in/janedoe
  github: github.com/janedoe

summary: >
  Senior DevOps Engineer with 8+ years of experience building
  cloud infrastructure and CI/CD pipelines. Managed 200+ microservices
  with 99.99% uptime, reduced cloud costs by $1.2M annually.

target_role: devops-engineer
years_of_experience: 8

experience:
  - company: Acme Corp
    title: Senior DevOps Engineer
    location: San Francisco, CA
    start_date: Jan 2021
    end_date: Present
    bullets:
      - "Architected Kubernetes platform hosting 200+ microservices with 99.99% uptime"
      - "Reduced cloud costs by $1.2M annually through right-sizing and spot instances"
      - "Implemented GitOps pipeline enabling 150+ zero-downtime deployments weekly"
    technologies: [Kubernetes, AWS, Terraform, ArgoCD]

skills:
  - category: Cloud & Infrastructure
    skills: [AWS, Azure, GCP, EC2, EKS, S3]
  - category: Containers & Orchestration
    skills: [Docker, Kubernetes, Helm, Istio]
  - category: CI/CD & Automation
    skills: [Jenkins, GitHub Actions, ArgoCD, Ansible]

certifications:
  - name: AWS Solutions Architect Professional
    issuer: Amazon Web Services
    date: "2023"

education:
  - institution: MIT
    degree: Bachelor of Science
    field_of_study: Computer Science
    graduation_date: May 2016

projects:
  - name: k8s-health-checker
    description: CLI tool to scan Kubernetes clusters for health issues
    url: github.com/janedoe/k8s-health-checker
    technologies: [Python, Click, Rich]
    highlights: ["Published on PyPI", "22 automated tests"]

languages: [English, Spanish]
```

### 4. Generate & Score

```bash
# Generate PDF
ats-resume generate -i resume.yaml -f pdf

# Generate all formats
ats-resume generate -i resume.yaml -f all

# Score your resume
ats-resume score -i resume.yaml

# Match against a job description
ats-resume match -i resume.yaml -j job-description.txt
```

---

## 🎯 ATS Scoring Engine

The scoring engine analyzes **12 weighted categories**:

| Category | Weight | What It Checks |
|----------|--------|---------------|
| Contact Info | 10% | Name, email, phone, LinkedIn, location, GitHub |
| Professional Summary | 10% | Length (30-80 words), metrics, years mention |
| Work Experience | 20% | Count, bullets per role (3-8), dates, technologies |
| Skills | 12% | Count (15+), categorization (3+), coverage |
| Education | 5% | Degree, institution, graduation date |
| Certifications | 5% | Count, issuer presence |
| Projects | 5% | Count, URLs, descriptions |
| Action Verbs | 10% | Strong verb percentage, weak verb detection |
| Quantification | 10% | Bullets with numbers/metrics (target: 60%+) |
| Formatting | 5% | Bullet length, section order, length |
| Keyword Relevance | 5% | Match against role-specific keyword database |
| Overall Structure | 3% | Required sections, optional sections |

### Score Grades

| Grade | Score Range | Meaning |
|-------|------------|---------|
| A+ | 95-100 | Exceptional — top ATS compatibility |
| A | 85-94 | Excellent — very strong resume |
| B | 75-84 | Good — minor improvements possible |
| C | 60-74 | Fair — needs significant work |
| D | 40-59 | Poor — major gaps identified |
| F | 0-39 | Critical — resume needs complete overhaul |

### Example Score Output

```
╭──────────────────────────── 📊 ATS Score Report ─────────────────────────────╮
│                                                                              │
│  ATS Resume Score                                                            │
│                                                                              │
│    Score:  ███████████████████░  98/100                                      │
│    Grade:  A+                                                                │
│                                                                              │
│    ✅ Passed: 28  ⚠️  Warnings: 0  ❌ Critical: 0  ℹ️  Info: 0               │
│                                                                              │
╰──────────────────────────────────────────────────────────────────────────────╯
```

---

## 🏗️ Available Templates

| Template | Role |
|----------|------|
| `devops-engineer` | DevOps Engineer |
| `software-engineer` | Software Engineer |
| `data-engineer` | Data Engineer |
| `cloud-architect` | Cloud Architect |
| `sre` | Site Reliability Engineer |
| `fullstack-developer` | Full Stack Developer |
| `backend-developer` | Backend Developer |
| `frontend-developer` | Frontend Developer |
| `ml-engineer` | Machine Learning Engineer |
| `product-manager` | Product Manager |
| `blank` | Blank Template |

Each template includes realistic experience bullets with quantified achievements, categorized skills, and role-appropriate certifications.

---

## 📊 Job Description Matching

Match your resume against any job posting:

```bash
ats-resume match -i resume.yaml -j job-posting.txt
```

The matcher:
- Extracts keywords from the job description
- Compares against your resume content
- Identifies matched and missing skills
- Checks experience years requirement
- Checks education requirements
- Generates actionable improvement suggestions

---

## 🧙 Interactive Wizard

Build your resume step-by-step with guided prompts:

```bash
ats-resume wizard
```

The wizard walks you through:
1. Choose a role template
2. Contact information
3. Professional summary
4. Work experience (with bullet points)
5. Skills by category
6. Education
7. Certifications
8. Projects
9. Languages

---

## 📋 All Commands

| Command | Description |
|---------|-------------|
| `ats-resume demo` | Generate demo resume in all formats + show score |
| `ats-resume init` | Create a resume YAML template |
| `ats-resume generate` | Generate resume in PDF/DOCX/MD/HTML/TXT |
| `ats-resume score` | Run ATS score analysis (0-100) |
| `ats-resume match` | Match resume against job description |
| `ats-resume wizard` | Interactive step-by-step builder |
| `ats-resume templates` | List available role templates |

### Common Options

```bash
# Generate with scoring
ats-resume generate -i resume.yaml -f pdf --score

# Use a specific output directory
ats-resume generate -i resume.yaml -f all -o ./output/

# Initialize from a specific template
ats-resume init -t cloud-architect -o my-resume.yaml
```

---

## 🏛️ Architecture

```
ats_resume_generator/
├── cli.py                    # Click CLI with 7 commands
├── models.py                 # Dataclass models (ResumeData, ScoreResult, etc.)
├── parser.py                 # YAML/JSON parser with round-trip support
├── demo.py                   # Demo resume data
├── scoring/
│   ├── engine.py             # 12-category ATS scoring engine
│   └── keywords.py           # Role-specific keyword databases
├── generators/
│   ├── pdf.py                # ReportLab PDF (ATS-friendly Helvetica)
│   ├── docx_gen.py           # python-docx Word documents
│   ├── markdown.py           # Clean Markdown
│   ├── html.py               # HTML with inline CSS
│   └── text.py               # Plain text with wrapping
├── optimizer/
│   ├── action_verbs.py       # 126 strong verbs, weak verb detection
│   └── job_matcher.py        # JD matching with keyword extraction
├── templates/
│   └── roles.py              # 10 role templates + blank
├── output/
│   └── console.py            # Rich terminal rendering
└── wizard/
    └── interactive.py        # Step-by-step resume builder
```

---

## 🧪 Testing

```bash
# Run all tests
pytest

# Run with coverage
pytest --cov=ats_resume_generator

# Run specific test file
pytest tests/test_scoring.py -v
```

**205 tests** covering models, parser, scoring engine, all generators, job matcher, templates, CLI commands, and demo data.

---

## 🛠️ Development

```bash
# Clone and install in dev mode
git clone https://github.com/SanjaySundarMurthy/ats-resume-generator.git
cd ats-resume-generator
pip install -e ".[dev]"

# Run linter
ruff check .

# Run tests
pytest -v
```

---

## 📄 License

MIT License — see [LICENSE](LICENSE) for details.

---

## 👤 Author

**Sanjay S** — Senior DevOps Engineer

- GitHub: [@SanjaySundarMurthy](https://github.com/SanjaySundarMurthy)
- Portfolio: [sanjaysundarmurthy-portfolio.vercel.app](https://sanjaysundarmurthy-portfolio.vercel.app/)
- LinkedIn: [sanjaysundarmurthy](https://linkedin.com/in/sanjaysundarmurthy)

---

<p align="center">
  <b>⭐ Star this repo if it helped you land an interview!</b>
</p>
