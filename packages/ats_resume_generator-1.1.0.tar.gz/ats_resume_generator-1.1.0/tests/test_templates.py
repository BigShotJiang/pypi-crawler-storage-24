"""Tests for role templates."""

from __future__ import annotations

import pytest

from ats_resume_generator.models import ResumeData
from ats_resume_generator.templates.roles import (
    get_available_templates,
    get_template,
)


class TestGetAvailableTemplates:
    def test_returns_list(self):
        templates = get_available_templates()
        assert isinstance(templates, list)
        assert len(templates) >= 10  # 10 roles + blank

    def test_each_tuple(self):
        templates = get_available_templates()
        for key, name in templates:
            assert isinstance(key, str)
            assert isinstance(name, str)
            assert len(key) > 0
            assert len(name) > 0

    def test_has_blank(self):
        templates = get_available_templates()
        keys = [k for k, _ in templates]
        assert "blank" in keys


class TestGetTemplate:
    @pytest.mark.parametrize("role", [
        "devops-engineer",
        "software-engineer",
        "data-engineer",
        "cloud-architect",
        "sre",
        "fullstack-developer",
        "backend-developer",
        "frontend-developer",
        "ml-engineer",
        "product-manager",
        "blank",
    ])
    def test_template_returns_resume(self, role: str):
        resume = get_template(role)
        assert isinstance(resume, ResumeData)

    @pytest.mark.parametrize("role", [
        "devops-engineer",
        "software-engineer",
        "data-engineer",
        "cloud-architect",
        "sre",
        "fullstack-developer",
        "backend-developer",
        "frontend-developer",
        "ml-engineer",
        "product-manager",
    ])
    def test_template_has_content(self, role: str):
        resume = get_template(role)
        assert resume.target_role != ""
        assert len(resume.experience) >= 1
        assert len(resume.skills) >= 2
        assert resume.summary != ""

    @pytest.mark.parametrize("role", [
        "devops-engineer",
        "software-engineer",
        "data-engineer",
        "cloud-architect",
        "sre",
    ])
    def test_template_has_bullets(self, role: str):
        resume = get_template(role)
        for exp in resume.experience:
            assert len(exp.bullets) >= 2, (
                f"{role} template: experience "
                f"'{exp.title}' has < 2 bullets"
            )

    def test_unknown_role_returns_blank(self):
        resume = get_template("nonexistent-role")
        assert isinstance(resume, ResumeData)
        # Blank template has placeholder name
        assert "Your" in resume.contact.name or resume.contact.name == ""

    def test_templates_are_independent(self):
        """Each call should return a new object."""
        r1 = get_template("devops-engineer")
        r2 = get_template("devops-engineer")
        r1.contact.name = "Modified"
        assert r2.contact.name != "Modified"
