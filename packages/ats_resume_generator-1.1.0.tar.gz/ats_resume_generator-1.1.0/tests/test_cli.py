"""Tests for CLI commands."""

from __future__ import annotations

from pathlib import Path

import pytest
from click.testing import CliRunner

from ats_resume_generator.cli import cli


@pytest.fixture
def runner() -> CliRunner:
    return CliRunner()


# ---------------------------------------------------------------------------
# Version & help
# ---------------------------------------------------------------------------
class TestCLIBasic:
    def test_version(self, runner: CliRunner):
        result = runner.invoke(cli, ["--version"])
        assert result.exit_code == 0
        assert "1.1.0" in result.output

    def test_help(self, runner: CliRunner):
        result = runner.invoke(cli, ["--help"])
        assert result.exit_code == 0
        assert "ATS Resume Generator" in result.output

    def test_all_commands_listed(self, runner: CliRunner):
        result = runner.invoke(cli, ["--help"])
        for cmd in ["init", "generate", "score", "match", "templates", "demo", "wizard"]:
            assert cmd in result.output


# ---------------------------------------------------------------------------
# init command
# ---------------------------------------------------------------------------
class TestInitCommand:
    def test_init_default(self, runner: CliRunner, tmp_path: Path):
        out = str(tmp_path / "resume.yaml")
        result = runner.invoke(cli, ["init", "--output", out])
        assert result.exit_code == 0
        assert Path(out).exists()

    def test_init_with_template(self, runner: CliRunner, tmp_path: Path):
        out = str(tmp_path / "devops.yaml")
        result = runner.invoke(
            cli, ["init", "--template", "devops-engineer", "--output", out]
        )
        assert result.exit_code == 0
        assert Path(out).exists()


# ---------------------------------------------------------------------------
# templates command
# ---------------------------------------------------------------------------
class TestTemplatesCommand:
    def test_lists_templates(self, runner: CliRunner):
        result = runner.invoke(cli, ["templates"])
        assert result.exit_code == 0
        assert "devops" in result.output.lower()


# ---------------------------------------------------------------------------
# score command
# ---------------------------------------------------------------------------
class TestScoreCommand:
    def test_score_demo(self, runner: CliRunner):
        result = runner.invoke(cli, ["score", "--demo"])
        assert result.exit_code == 0
        assert "Score" in result.output or "score" in result.output

    def test_score_no_input(self, runner: CliRunner):
        result = runner.invoke(cli, ["score"])
        assert result.exit_code != 0

    def test_score_from_file(self, runner: CliRunner, tmp_path: Path):
        # Create a YAML resume file
        yaml_content = """
contact:
  name: Test User
  email: test@test.com
summary: An experienced software engineer with 5+ years.
experience:
  - company: Acme
    title: Engineer
    start_date: Jan 2020
    end_date: Present
    bullets:
      - Built microservices handling 1M requests daily
      - Reduced deployment time by 60%
skills:
  - category: Programming
    skills: [Python, Go, JavaScript]
"""
        yaml_path = tmp_path / "resume.yaml"
        yaml_path.write_text(yaml_content, encoding="utf-8")

        result = runner.invoke(cli, ["score", "--input", str(yaml_path)])
        assert result.exit_code == 0


# ---------------------------------------------------------------------------
# generate command
# ---------------------------------------------------------------------------
class TestGenerateCommand:
    def test_generate_demo_pdf(self, runner: CliRunner, tmp_path: Path):
        result = runner.invoke(
            cli,
            ["generate", "--demo", "-f", "pdf", "-o", str(tmp_path)],
        )
        assert result.exit_code == 0
        pdf_files = list(tmp_path.glob("*.pdf"))
        assert len(pdf_files) == 1

    def test_generate_demo_all(self, runner: CliRunner, tmp_path: Path):
        result = runner.invoke(
            cli,
            ["generate", "--demo", "-f", "all", "-o", str(tmp_path)],
        )
        assert result.exit_code == 0
        # Should generate PDF, DOCX, MD, HTML, TXT
        assert len(list(tmp_path.glob("*.*"))) >= 5

    def test_generate_no_input(self, runner: CliRunner):
        result = runner.invoke(cli, ["generate"])
        assert result.exit_code != 0

    def test_generate_demo_md(self, runner: CliRunner, tmp_path: Path):
        result = runner.invoke(
            cli,
            ["generate", "--demo", "-f", "md", "-o", str(tmp_path)],
        )
        assert result.exit_code == 0
        md_files = list(tmp_path.glob("*.md"))
        assert len(md_files) == 1


# ---------------------------------------------------------------------------
# demo command
# ---------------------------------------------------------------------------
class TestDemoCommand:
    def test_demo_generates_all(self, runner: CliRunner, tmp_path: Path):
        with runner.isolated_filesystem(temp_dir=tmp_path):
            result = runner.invoke(cli, ["demo"])
            assert result.exit_code == 0
            assert "Score" in result.output or "score" in result.output


# ---------------------------------------------------------------------------
# match command
# ---------------------------------------------------------------------------
class TestMatchCommand:
    def test_match_missing_args(self, runner: CliRunner):
        result = runner.invoke(cli, ["match"])
        assert result.exit_code != 0

    def test_match_with_files(self, runner: CliRunner, tmp_path: Path):
        resume_yaml = tmp_path / "resume.yaml"
        resume_yaml.write_text(
            """
contact:
  name: Test User
  email: test@test.com
summary: Senior DevOps Engineer with 8+ years.
experience:
  - company: Acme
    title: DevOps Engineer
    bullets:
      - Managed Kubernetes clusters
skills:
  - category: Cloud
    skills: [AWS, Docker, Kubernetes]
""",
            encoding="utf-8",
        )

        jd_file = tmp_path / "jd.txt"
        jd_file.write_text(
            "Looking for a DevOps Engineer with Kubernetes and AWS experience.",
            encoding="utf-8",
        )

        result = runner.invoke(
            cli,
            ["match", "--input", str(resume_yaml), "--job", str(jd_file)],
        )
        assert result.exit_code == 0
