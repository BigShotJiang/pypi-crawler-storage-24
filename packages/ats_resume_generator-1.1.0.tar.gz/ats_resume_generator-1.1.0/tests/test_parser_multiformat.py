"""Tests for multi-format resume parser (PDF, DOCX, TXT, MD, HTML)."""

from __future__ import annotations

from pathlib import Path

import pytest

from ats_resume_generator.models import ResumeData
from ats_resume_generator.parser import (
    _extract_contact,
    _extract_experience,
    _extract_skills,
    _extract_certifications,
    _extract_education,
    _extract_projects,
    _parse_lines,
    _split_sections,
    parse_resume_file,
)


# ---------------------------------------------------------------------------
# _extract_contact tests
# ---------------------------------------------------------------------------
class TestExtractContact:
    def test_name_extraction(self):
        lines = ["ALEX MORGAN", "alex@test.com · 555-1234 · San Francisco, CA"]
        contact = _extract_contact(lines)
        assert contact.name == "ALEX MORGAN"

    def test_email_extraction(self):
        lines = ["Jane Doe", "jane.doe@example.com · 555-123-4567"]
        contact = _extract_contact(lines)
        assert contact.email == "jane.doe@example.com"

    def test_phone_extraction(self):
        lines = ["Jane Doe", "+1-555-867-5309 · jane@test.com"]
        contact = _extract_contact(lines)
        assert "+1-555-867-5309" in contact.phone

    def test_linkedin_extraction(self):
        lines = [
            "Jane Doe",
            "jane@test.com",
            "linkedin.com/in/janedoe | github.com/janedoe",
        ]
        contact = _extract_contact(lines)
        assert contact.linkedin == "linkedin.com/in/janedoe"

    def test_github_extraction(self):
        lines = [
            "Jane Doe",
            "jane@test.com",
            "github.com/janedoe",
        ]
        contact = _extract_contact(lines)
        assert contact.github == "github.com/janedoe"

    def test_location_extraction(self):
        lines = ["Jane Doe", "jane@test.com · San Francisco, CA"]
        contact = _extract_contact(lines)
        assert contact.location == "San Francisco, CA"

    def test_skips_email_as_name(self):
        lines = ["jane@test.com", "Jane Doe"]
        contact = _extract_contact(lines)
        assert contact.name == "Jane Doe"


# ---------------------------------------------------------------------------
# _split_sections tests
# ---------------------------------------------------------------------------
class TestSplitSections:
    def test_basic_sections(self):
        lines = [
            "Jane Doe",
            "Professional Summary",
            "An experienced engineer.",
            "Experience",
            "Senior Engineer at Acme",
            "Skills",
            "Python, Go, Bash",
        ]
        sections = _split_sections(lines)
        assert "summary" in sections
        assert "experience" in sections
        assert "skills" in sections

    def test_professional_experience_header(self):
        """PROFESSIONAL EXPERIENCE should match experience section."""
        lines = [
            "PROFESSIONAL EXPERIENCE",
            "Senior DevOps Engineer",
            "Mar 2022 – Present",
        ]
        sections = _split_sections(lines)
        assert "experience" in sections
        assert len(sections["experience"]) >= 1

    def test_technical_skills_header(self):
        lines = [
            "TECHNICAL SKILLS",
            "Cloud & Infrastructure",
            "AWS, Azure, GCP",
        ]
        sections = _split_sections(lines)
        assert "skills" in sections

    def test_certifications_header(self):
        lines = [
            "CERTIFICATIONS",
            "AWS Solutions Architect – Amazon Web Services (2023)",
        ]
        sections = _split_sections(lines)
        assert "certifications" in sections

    def test_projects_header(self):
        lines = [
            "PROJECTS",
            "k8s-health-checker | github.com/user/tool",
            "CLI tool for scanning clusters",
        ]
        sections = _split_sections(lines)
        assert "projects" in sections

    def test_education_header(self):
        lines = [
            "EDUCATION",
            "Bachelor of Science in Computer Science",
        ]
        sections = _split_sections(lines)
        assert "education" in sections


# ---------------------------------------------------------------------------
# _extract_experience tests
# ---------------------------------------------------------------------------
class TestExtractExperience:
    def test_basic_experience(self):
        lines = [
            "Senior DevOps Engineer",
            "Mar 2022 – Present",
            "Acme Corp · San Francisco, CA",
            "I Architected multi-region Kubernetes platform with 99.99% uptime",
            "I Reduced cloud costs by 42% ($1.2M annually)",
        ]
        exps = _extract_experience(lines)
        assert len(exps) == 1
        assert exps[0].title == "Senior DevOps Engineer"
        assert exps[0].start_date == "Mar 2022"
        assert exps[0].end_date == "Present"
        assert exps[0].company == "Acme Corp"
        assert len(exps[0].bullets) >= 2

    def test_multiple_experiences(self):
        lines = [
            "Senior DevOps Engineer",
            "Mar 2022 – Present",
            "Acme Corp · San Francisco, CA",
            "I Built infrastructure",
            "DevOps Engineer",
            "Jun 2019 – Feb 2022",
            "Beta Inc · Austin, TX",
            "I Designed CI/CD pipelines",
        ]
        exps = _extract_experience(lines)
        assert len(exps) == 2
        assert exps[0].title == "Senior DevOps Engineer"
        assert exps[1].title == "DevOps Engineer"

    def test_tech_stack_parsing(self):
        lines = [
            "Senior DevOps Engineer",
            "Mar 2022 – Present",
            "Acme Corp · San Francisco, CA",
            "I Built infrastructure",
            "Tech Stack: Kubernetes, Docker, Terraform, AWS",
        ]
        exps = _extract_experience(lines)
        assert len(exps) == 1
        assert "Kubernetes" in exps[0].technologies
        assert "Docker" in exps[0].technologies

    def test_bullet_with_I_prefix(self):
        """Bullets starting with 'I ' (from PDF ▪ extraction) should be parsed."""
        lines = [
            "Software Engineer",
            "Jan 2020 – Present",
            "TechCo · NYC, NY",
            "I Implemented scalable microservices architecture serving 10M users",
        ]
        exps = _extract_experience(lines)
        assert len(exps) == 1
        assert any("microservices" in b for b in exps[0].bullets)

    def test_empty_lines(self):
        exps = _extract_experience([])
        assert exps == []


# ---------------------------------------------------------------------------
# _extract_skills tests
# ---------------------------------------------------------------------------
class TestExtractSkills:
    def test_colon_format(self):
        lines = [
            "Cloud: AWS, Azure, GCP",
            "Programming: Python, Go, Bash",
        ]
        skills = _extract_skills(lines)
        assert len(skills) == 2
        assert skills[0].category == "Cloud"
        assert "AWS" in skills[0].skills

    def test_alternating_category_skills(self):
        """PDF format: category on one line, skills on next."""
        lines = [
            "Cloud & Infrastructure",
            "AWS, Azure, GCP, Linux",
            "Containers & Orchestration",
            "Docker, Kubernetes, Helm",
        ]
        skills = _extract_skills(lines)
        assert len(skills) == 2
        assert skills[0].category == "Cloud & Infrastructure"
        assert "AWS" in skills[0].skills
        assert skills[1].category == "Containers & Orchestration"
        assert "Docker" in skills[1].skills

    def test_comma_separated_only(self):
        lines = ["Python, Go, Bash, JavaScript, TypeScript"]
        skills = _extract_skills(lines)
        assert len(skills) == 1
        assert len(skills[0].skills) == 5

    def test_empty_skills(self):
        skills = _extract_skills([])
        assert skills == []


# ---------------------------------------------------------------------------
# _extract_education tests
# ---------------------------------------------------------------------------
class TestExtractEducation:
    def test_degree_parsing(self):
        lines = [
            "Bachelor of Science in Computer Science – MIT",
        ]
        edu = _extract_education(lines)
        assert len(edu) == 1
        assert "Bachelor" in edu[0].degree

    def test_gpa_extraction(self):
        lines = [
            "Bachelor of Science - MIT GPA: 3.8",
        ]
        edu = _extract_education(lines)
        assert len(edu) == 1
        assert edu[0].gpa == "3.8"

    def test_date_extraction(self):
        lines = [
            "Bachelor of Science in Computer Science – MIT (2017)",
        ]
        edu = _extract_education(lines)
        assert len(edu) == 1
        assert "2017" in edu[0].graduation_date


# ---------------------------------------------------------------------------
# _extract_certifications tests
# ---------------------------------------------------------------------------
class TestExtractCertifications:
    def test_cert_with_issuer(self):
        lines = [
            "AWS Solutions Architect – Amazon Web Services (2023)",
        ]
        certs = _extract_certifications(lines)
        assert len(certs) == 1
        assert "AWS" in certs[0].name
        assert certs[0].date == "2023"

    def test_multiple_certs(self):
        lines = [
            "CKA – CNCF (2022)",
            "Azure DevOps Expert – Microsoft (2022)",
        ]
        certs = _extract_certifications(lines)
        assert len(certs) == 2


# ---------------------------------------------------------------------------
# _extract_projects tests
# ---------------------------------------------------------------------------
class TestExtractProjects:
    def test_project_with_url(self):
        lines = [
            "k8s-health-checker | github.com/user/tool",
            "CLI tool for scanning Kubernetes clusters",
            "I Published on PyPI",
            "I 22 automated tests",
        ]
        projects = _extract_projects(lines)
        assert len(projects) == 1
        assert projects[0].name == "k8s-health-checker"
        assert "github.com" in projects[0].url


# ---------------------------------------------------------------------------
# _parse_lines integration tests
# ---------------------------------------------------------------------------
class TestParseLines:
    def test_full_resume_lines(self):
        """Parse a complete resume from text lines."""
        lines = [
            "ALEX MORGAN",
            "alex@test.com · +1-555-1234 · San Francisco, CA",
            "linkedin.com/in/alexmorgan | github.com/alexmorgan",
            "PROFESSIONAL SUMMARY",
            "Senior DevOps Engineer with 7+ years of experience.",
            "PROFESSIONAL EXPERIENCE",
            "Senior DevOps Engineer",
            "Mar 2022 – Present",
            "Acme Corp · San Francisco, CA",
            "I Architected Kubernetes platform with 99.99% uptime",
            "I Reduced cloud costs by 42% ($1.2M annually)",
            "Tech Stack: Kubernetes, Docker, Terraform",
            "TECHNICAL SKILLS",
            "Cloud & Infrastructure",
            "AWS, Azure, GCP",
            "Containers",
            "Docker, Kubernetes, Helm",
            "CERTIFICATIONS",
            "AWS Solutions Architect – Amazon (2023)",
            "CKA – CNCF (2022)",
            "EDUCATION",
            "Bachelor of Science in Computer Science – MIT (2017)",
            "PROJECTS",
            "my-tool | github.com/alexmorgan/my-tool",
            "A CLI tool for DevOps",
        ]
        resume = _parse_lines(lines)
        assert resume.contact.name == "ALEX MORGAN"
        assert resume.contact.email == "alex@test.com"
        assert "7+ years" in resume.summary
        assert len(resume.experience) >= 1
        assert len(resume.skills) >= 2
        assert len(resume.certifications) == 2
        assert len(resume.education) == 1
        assert len(resume.projects) >= 1

    def test_empty_lines(self):
        resume = _parse_lines([])
        assert isinstance(resume, ResumeData)
        assert resume.contact.name == ""


# ---------------------------------------------------------------------------
# parse_resume_file tests for text formats
# ---------------------------------------------------------------------------
class TestParseResumeFileText:
    def test_parse_txt_file(self, tmp_path: Path):
        content = (
            "Jane Doe\n"
            "jane@test.com\n\n"
            "Summary\n"
            "An experienced DevOps engineer.\n\n"
            "Experience\n"
            "Senior DevOps Engineer\n"
            "Jan 2020 – Present\n"
            "Acme · SF, CA\n"
            "Built scalable infrastructure for 100+ services\n\n"
            "Skills\n"
            "Python, Go, Bash, AWS, Docker\n"
        )
        txt_path = tmp_path / "resume.txt"
        txt_path.write_text(content, encoding="utf-8")
        resume = parse_resume_file(str(txt_path))
        assert resume.contact.name == "Jane Doe"
        assert resume.contact.email == "jane@test.com"

    def test_parse_md_file(self, tmp_path: Path):
        content = (
            "# Jane Doe\n"
            "jane@test.com\n\n"
            "## Summary\n"
            "An experienced engineer.\n\n"
            "## Experience\n"
            "**Senior DevOps Engineer**\n"
            "Jan 2020 – Present\n"
            "Acme · SF, CA\n"
            "- Built scalable infrastructure for 100+ services\n\n"
            "## Skills\n"
            "Python, Go, Bash, AWS\n"
        )
        md_path = tmp_path / "resume.md"
        md_path.write_text(content, encoding="utf-8")
        resume = parse_resume_file(str(md_path))
        assert resume.contact.name == "Jane Doe"
        assert resume.contact.email == "jane@test.com"

    def test_parse_html_file(self, tmp_path: Path):
        content = (
            "<html><body>"
            "<h1>Jane Doe</h1>"
            "<p>jane@test.com</p>"
            "<h2>Summary</h2>"
            "<p>An experienced engineer.</p>"
            "<h2>Experience</h2>"
            "<p>Senior DevOps Engineer</p>"
            "<p>Jan 2020 – Present</p>"
            "<p>Acme · SF, CA</p>"
            "<ul><li>Built scalable infrastructure for 100+ services</li></ul>"
            "<h2>Skills</h2>"
            "<p>Python, Go, Bash, AWS</p>"
            "</body></html>"
        )
        html_path = tmp_path / "resume.html"
        html_path.write_text(content, encoding="utf-8")
        resume = parse_resume_file(str(html_path))
        assert resume.contact.name == "Jane Doe"
        assert resume.contact.email == "jane@test.com"

    def test_unsupported_extension_fallback(self, tmp_path: Path):
        """Unknown extensions should try YAML first, then text."""
        content = (
            "Jane Doe\n"
            "jane@test.com\n\n"
            "Summary\n"
            "An engineer.\n"
        )
        file_path = tmp_path / "resume.xyz"
        file_path.write_text(content, encoding="utf-8")
        resume = parse_resume_file(str(file_path))
        assert isinstance(resume, ResumeData)


# ---------------------------------------------------------------------------
# Date range regex tests
# ---------------------------------------------------------------------------
class TestDateRangeMatching:
    def test_standard_en_dash(self):
        """Standard en-dash separator should work."""
        from ats_resume_generator.parser import _DATE_RANGE_RE
        match = _DATE_RANGE_RE.search("Mar 2022 – Present")
        assert match is not None
        assert match.group(1) == "Mar 2022"
        assert match.group(2) == "Present"

    def test_hyphen(self):
        from ats_resume_generator.parser import _DATE_RANGE_RE
        match = _DATE_RANGE_RE.search("Jun 2019 - Feb 2022")
        assert match is not None

    def test_current_keyword(self):
        from ats_resume_generator.parser import _DATE_RANGE_RE
        match = _DATE_RANGE_RE.search("Jan 2020 – Current")
        assert match is not None
        assert match.group(2) == "Current"

    def test_now_keyword(self):
        from ats_resume_generator.parser import _DATE_RANGE_RE
        match = _DATE_RANGE_RE.search("Jan 2020 – Now")
        assert match is not None
        assert match.group(2) == "Now"
