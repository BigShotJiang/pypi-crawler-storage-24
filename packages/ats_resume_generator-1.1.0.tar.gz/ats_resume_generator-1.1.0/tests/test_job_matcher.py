"""Tests for job description matcher."""

from __future__ import annotations

from pathlib import Path

import pytest

from ats_resume_generator.models import (
    ContactInfo,
    Experience,
    ResumeData,
)
from ats_resume_generator.optimizer.job_matcher import (
    match_job_description,
    match_job_file,
)

SAMPLE_JD = """
Senior DevOps Engineer

Requirements:
- 5+ years of experience in DevOps or SRE roles
- Strong experience with Kubernetes, Docker, and container orchestration
- Proficiency with AWS cloud services (EC2, EKS, S3, IAM)
- Experience with Infrastructure as Code (Terraform, CloudFormation)
- CI/CD pipeline design and implementation (Jenkins, GitHub Actions)
- Monitoring and observability (Prometheus, Grafana, Datadog)
- Strong scripting skills (Python, Bash)
- Bachelor's degree in Computer Science or equivalent

Nice to have:
- Experience with ArgoCD and GitOps workflows
- Hashicorp Vault, Consul experience
- Managed Kubernetes platforms (EKS, GKE, AKS)
"""


class TestMatchJobDescription:
    def test_high_match(self, full_resume: ResumeData):
        result = match_job_description(full_resume, SAMPLE_JD)
        assert result.match_percentage >= 50
        assert len(result.matched_keywords) > 0

    def test_matched_skills(self, full_resume: ResumeData):
        result = match_job_description(full_resume, SAMPLE_JD)
        matched_lower = [s.lower() for s in result.matched_skills]
        assert "kubernetes" in matched_lower
        assert "docker" in matched_lower

    def test_experience_match(self, full_resume: ResumeData):
        result = match_job_description(full_resume, SAMPLE_JD)
        # full_resume has 8 years, JD requires 5+
        assert result.experience_match is True

    def test_education_match(self, full_resume: ResumeData):
        result = match_job_description(full_resume, SAMPLE_JD)
        assert result.education_match is True

    def test_suggestions_generated(self, full_resume: ResumeData):
        result = match_job_description(full_resume, SAMPLE_JD)
        # Should have at least one suggestion
        assert isinstance(result.suggestions, list)

    def test_low_experience_mismatch(self):
        resume = ResumeData(
            contact=ContactInfo(name="Junior"),
            years_of_experience=2,
            experience=[
                Experience(
                    company="X",
                    title="Eng",
                    bullets=["Deployed apps"],
                )
            ],
        )
        result = match_job_description(resume, SAMPLE_JD)
        assert result.experience_match is False

    def test_no_education_mismatch(self):
        resume = ResumeData(
            contact=ContactInfo(name="Test"),
            education=[],  # no education
        )
        result = match_job_description(resume, SAMPLE_JD)
        assert result.education_match is False

    def test_empty_jd(self, full_resume: ResumeData):
        result = match_job_description(full_resume, "")
        assert result.match_percentage >= 0
        assert isinstance(result.matched_keywords, list)

    def test_missing_keywords_populated(self):
        resume = ResumeData(
            contact=ContactInfo(name="Test"),
            summary="A software engineer",
        )
        result = match_job_description(resume, SAMPLE_JD)
        assert len(result.missing_keywords) > 0

    def test_match_percentage_bounded(self, full_resume: ResumeData):
        result = match_job_description(full_resume, SAMPLE_JD)
        assert 0 <= result.match_percentage <= 100


class TestMatchJobFile:
    def test_file_not_found(self, full_resume: ResumeData):
        with pytest.raises(FileNotFoundError):
            match_job_file(full_resume, "/nonexistent/jd.txt")

    def test_reads_from_file(
        self, full_resume: ResumeData, tmp_path: Path
    ):
        jd_path = tmp_path / "jd.txt"
        jd_path.write_text(SAMPLE_JD, encoding="utf-8")

        result = match_job_file(full_resume, str(jd_path))
        assert result.match_percentage >= 50
        assert len(result.matched_keywords) > 0
