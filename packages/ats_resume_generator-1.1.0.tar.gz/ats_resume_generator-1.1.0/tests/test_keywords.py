"""Tests for keyword analysis."""

from __future__ import annotations

from ats_resume_generator.scoring.keywords import (
    ATS_POWER_PHRASES,
    ROLE_KEYWORDS,
    SKILL_DATABASES,
    extract_keywords_from_text,
    get_role_keywords,
)


class TestRoleKeywords:
    def test_has_all_roles(self):
        expected_roles = [
            "devops-engineer",
            "software-engineer",
            "data-engineer",
            "cloud-architect",
            "sre",
        ]
        for role in expected_roles:
            assert role in ROLE_KEYWORDS, f"Missing role: {role}"

    def test_each_role_has_keywords(self):
        for role, keywords in ROLE_KEYWORDS.items():
            assert len(keywords) >= 10, (
                f"{role} has only {len(keywords)} keywords"
            )


class TestGetRoleKeywords:
    def test_known_role(self):
        keywords = get_role_keywords("devops-engineer")
        assert len(keywords) > 0
        assert "kubernetes" in [k.lower() for k in keywords]

    def test_unknown_role_returns_empty(self):
        keywords = get_role_keywords("nonexistent-role")
        assert keywords == []


class TestSkillDatabases:
    def test_has_categories(self):
        assert len(SKILL_DATABASES) >= 5

    def test_categories_have_skills(self):
        for cat, skills in SKILL_DATABASES.items():
            assert len(skills) >= 3, f"Category {cat} has too few skills"


class TestExtractKeywords:
    def test_extracts_from_job_description(self):
        jd = (
            "We are looking for a DevOps Engineer with experience in "
            "Kubernetes, Docker, AWS, Terraform, and CI/CD pipelines. "
            "Experience with Python and monitoring tools like Prometheus "
            "is a plus."
        )
        keywords = extract_keywords_from_text(jd)
        assert len(keywords) > 0
        kw_lower = [k.lower() for k in keywords]
        assert "kubernetes" in kw_lower
        assert "docker" in kw_lower
        assert "aws" in kw_lower

    def test_empty_text(self):
        keywords = extract_keywords_from_text("")
        assert keywords == []

    def test_no_duplicates(self):
        text = "Python Python Python Docker Docker AWS"
        keywords = extract_keywords_from_text(text)
        # Should deduplicate
        assert len(keywords) == len(set(k.lower() for k in keywords))


class TestAtsPowerPhrases:
    def test_not_empty(self):
        assert len(ATS_POWER_PHRASES) > 5

    def test_contains_common_phrases(self):
        phrases_lower = [p.lower() for p in ATS_POWER_PHRASES]
        # Check at least some action-oriented phrases exist
        assert any("results" in p or "driven" in p for p in phrases_lower)
