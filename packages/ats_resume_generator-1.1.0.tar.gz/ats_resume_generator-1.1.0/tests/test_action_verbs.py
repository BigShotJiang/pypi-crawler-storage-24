"""Tests for action verbs optimizer."""

from __future__ import annotations

import pytest

from ats_resume_generator.optimizer.action_verbs import (
    ALL_STRONG_VERBS,
    IMPACT_KEYWORDS,
    QUANTIFICATION_PATTERNS,
    WEAK_VERBS,
    find_weak_verbs,
    has_quantification,
    starts_with_action_verb,
    suggest_stronger_verb,
)


class TestAllStrongVerbs:
    def test_not_empty(self):
        assert len(ALL_STRONG_VERBS) > 50

    def test_contains_common_verbs(self):
        for verb in ["architected", "implemented", "designed", "managed"]:
            assert verb in ALL_STRONG_VERBS


class TestWeakVerbs:
    def test_weak_verbs_have_suggestions(self):
        for weak, suggestions in WEAK_VERBS.items():
            assert len(suggestions) > 0, f"{weak} has no suggestions"


class TestFindWeakVerbs:
    def test_finds_weak_verb(self):
        result = find_weak_verbs("Responsible for managing servers")
        weak_found = [w for w, _ in result]
        assert "responsible for" in weak_found

    def test_finds_multiple(self):
        text = "Helped with tasks and worked on features"
        result = find_weak_verbs(text)
        weak_found = [w for w, _ in result]
        assert "helped" in weak_found
        assert "worked on" in weak_found

    def test_no_weak_verbs(self):
        result = find_weak_verbs("Architected cloud infrastructure")
        assert result == []


class TestStartsWithActionVerb:
    @pytest.mark.parametrize("bullet", [
        "Architected microservices platform",
        "Implemented CI/CD pipeline",
        "Designed monitoring solution",
        "Managed 200+ servers",
        "Automated deployment process",
        "Led team of 5 engineers",
        "Optimized database performance",
        "Deployed applications to production",
        "Built real-time analytics pipeline",
        "Reduced cloud costs by 40%",
    ])
    def test_strong_verb_bullets(self, bullet: str):
        assert starts_with_action_verb(bullet) is True

    @pytest.mark.parametrize("bullet", [
        "The server was configured",
        "Was responsible for deployments",
        "Various tasks performed",
    ])
    def test_non_action_verb_bullets(self, bullet: str):
        assert starts_with_action_verb(bullet) is False

    def test_empty_bullet(self):
        assert starts_with_action_verb("") is False

    def test_bullet_with_marker(self):
        assert starts_with_action_verb("• Implemented CI/CD") is True
        assert starts_with_action_verb("- Designed system") is True


class TestHasQuantification:
    @pytest.mark.parametrize("bullet", [
        "Reduced costs by $1.2M annually",
        "Managed 200+ microservices",
        "Improved performance by 45%",
        "Led team of 5 engineers",
        "Processed data across 50 servers daily",
        "Reduced MTTR from 4 hours to 12 minutes",
        "Achieved 99.99% uptime",
    ])
    def test_quantified_bullets(self, bullet: str):
        assert has_quantification(bullet) is True

    @pytest.mark.parametrize("bullet", [
        "Managed servers",
        "Deployed applications",
        "Monitored systems",
        "Collaborated with teams",
    ])
    def test_non_quantified_bullets(self, bullet: str):
        assert has_quantification(bullet) is False


class TestSuggestStrongerVerb:
    def test_suggests_for_weak(self):
        suggestions = suggest_stronger_verb("helped")
        assert len(suggestions) > 0

    def test_suggests_for_responsible(self):
        suggestions = suggest_stronger_verb("responsible for")
        assert len(suggestions) > 0

    def test_no_suggestion_for_strong(self):
        suggestions = suggest_stronger_verb("architected")
        assert suggestions == []


class TestImpactKeywords:
    def test_not_empty(self):
        assert len(IMPACT_KEYWORDS) > 10

    def test_contains_common(self):
        assert "reduced" in IMPACT_KEYWORDS
        assert "increased" in IMPACT_KEYWORDS
        assert "improved" in IMPACT_KEYWORDS


class TestQuantificationPatterns:
    def test_not_empty(self):
        assert len(QUANTIFICATION_PATTERNS) > 5
