"""Tests for demo resume data."""

from __future__ import annotations

from ats_resume_generator.demo import get_demo_resume
from ats_resume_generator.models import ResumeData


class TestDemoResume:
    def test_returns_resume(self):
        resume = get_demo_resume()
        assert isinstance(resume, ResumeData)

    def test_has_contact(self):
        resume = get_demo_resume()
        assert resume.contact.name != ""
        assert resume.contact.email != ""
        assert resume.contact.phone != ""

    def test_has_experience(self):
        resume = get_demo_resume()
        assert len(resume.experience) >= 2
        for exp in resume.experience:
            assert exp.company != ""
            assert exp.title != ""
            assert len(exp.bullets) >= 3

    def test_has_skills(self):
        resume = get_demo_resume()
        assert len(resume.skills) >= 5
        total = len(resume.all_skills_flat())
        assert total >= 20

    def test_has_certifications(self):
        resume = get_demo_resume()
        assert len(resume.certifications) >= 2

    def test_has_education(self):
        resume = get_demo_resume()
        assert len(resume.education) >= 1

    def test_has_projects(self):
        resume = get_demo_resume()
        assert len(resume.projects) >= 2

    def test_has_summary(self):
        resume = get_demo_resume()
        assert len(resume.summary.split()) >= 20

    def test_independent_instances(self):
        r1 = get_demo_resume()
        r2 = get_demo_resume()
        r1.contact.name = "Modified"
        assert r2.contact.name != "Modified"
