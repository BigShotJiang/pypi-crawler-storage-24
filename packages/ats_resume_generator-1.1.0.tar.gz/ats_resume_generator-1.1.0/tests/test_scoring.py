"""Tests for ATS scoring engine."""

from __future__ import annotations

from ats_resume_generator.models import (
    ContactInfo,
    Experience,
    ResumeData,
    ScoreGrade,
    Severity,
)
from ats_resume_generator.scoring.engine import score_resume


class TestScoreResumeFullResume:
    """Test scoring with a complete, well-formed resume."""

    def test_high_score(self, full_resume: ResumeData):
        result = score_resume(full_resume)
        assert result.total_score >= 80
        assert result.grade in (ScoreGrade.A_PLUS, ScoreGrade.A)

    def test_section_scores_present(self, full_resume: ResumeData):
        result = score_resume(full_resume)
        expected_sections = [
            "Contact Info",
            "Professional Summary",
            "Work Experience",
            "Skills",
            "Education",
            "Action Verbs",
            "Quantification",
        ]
        for section in expected_sections:
            assert section in result.section_scores

    def test_no_critical_findings(self, full_resume: ResumeData):
        result = score_resume(full_resume)
        assert result.critical_count == 0


class TestScoreResumeEmptyResume:
    """Test scoring with an empty resume."""

    def test_low_score(self, empty_resume: ResumeData):
        result = score_resume(empty_resume)
        assert result.total_score <= 30
        assert result.grade in (ScoreGrade.D, ScoreGrade.F)

    def test_has_critical_findings(self, empty_resume: ResumeData):
        result = score_resume(empty_resume)
        assert result.critical_count > 0

    def test_missing_contact_info(self, empty_resume: ResumeData):
        result = score_resume(empty_resume)
        contact_findings = [
            f for f in result.findings if f.category == "Contact Info"
        ]
        critical = [
            f for f in contact_findings if f.severity == Severity.CRITICAL
        ]
        assert len(critical) >= 1  # at least name missing


class TestScoreResumeMinimalResume:
    """Test scoring with minimal resume."""

    def test_mid_range_score(self, minimal_resume: ResumeData):
        result = score_resume(minimal_resume)
        # Minimal resume should score between 15 and 65
        assert 10 <= result.total_score <= 65


class TestScoreResumeContactInfo:
    """Test contact info scoring specifically."""

    def test_full_contact_scores_high(self):
        resume = ResumeData(
            contact=ContactInfo(
                name="Alice",
                email="a@b.com",
                phone="555-1234",
                location="NYC",
                linkedin="linkedin.com/in/alice",
                github="github.com/alice",
            ),
            summary="Engineer with 5+ years of experience in cloud.",
        )
        result = score_resume(resume)
        assert result.section_scores.get("Contact Info", 0) >= 90

    def test_missing_name_is_critical(self):
        resume = ResumeData(
            contact=ContactInfo(email="a@b.com"),
        )
        result = score_resume(resume)
        name_findings = [
            f for f in result.findings
            if f.category == "Contact Info" and "name" in f.message.lower()
        ]
        assert any(f.severity == Severity.CRITICAL for f in name_findings)


class TestScoreResumeSummary:
    """Test summary scoring."""

    def test_good_summary(self):
        resume = ResumeData(
            contact=ContactInfo(name="Test"),
            summary=(
                "Senior DevOps Engineer with 8+ years of experience "
                "managing cloud infrastructure and CI/CD pipelines. "
                "Reduced costs by $1.2M and achieved 99.99% uptime "
                "across 200+ microservices."
            ),
            target_role="devops-engineer",
        )
        result = score_resume(resume)
        assert result.section_scores.get("Professional Summary", 0) >= 70

    def test_no_summary_is_critical(self):
        resume = ResumeData(
            contact=ContactInfo(name="Test"),
            summary="",
        )
        result = score_resume(resume)
        summary_findings = [
            f for f in result.findings if f.category == "Summary"
        ]
        assert any(f.severity == Severity.CRITICAL for f in summary_findings)


class TestScoreResumeExperience:
    """Test experience scoring."""

    def test_no_experience_critical(self):
        resume = ResumeData(
            contact=ContactInfo(name="Test"),
            experience=[],
        )
        result = score_resume(resume)
        exp_findings = [
            f for f in result.findings if f.category == "Experience"
        ]
        assert any(f.severity == Severity.CRITICAL for f in exp_findings)

    def test_good_experience(self, full_resume: ResumeData):
        result = score_resume(full_resume)
        assert result.section_scores.get("Work Experience", 0) >= 80


class TestScoreResumeSkills:
    """Test skills section scoring."""

    def test_well_categorized_skills(self, full_resume: ResumeData):
        result = score_resume(full_resume)
        assert result.section_scores.get("Skills", 0) >= 70

    def test_no_skills(self, empty_resume: ResumeData):
        result = score_resume(empty_resume)
        skills_findings = [
            f for f in result.findings if f.category == "Skills"
        ]
        assert any(
            f.severity in (Severity.CRITICAL, Severity.WARNING)
            for f in skills_findings
        )


class TestScoreResumeActionVerbs:
    """Test action verb scoring."""

    def test_strong_verbs(self):
        resume = ResumeData(
            contact=ContactInfo(name="Test"),
            experience=[
                Experience(
                    company="X",
                    title="Eng",
                    bullets=[
                        "Architected microservices platform",
                        "Implemented CI/CD pipeline",
                        "Designed monitoring solution",
                        "Automated infrastructure provisioning",
                    ],
                ),
            ],
        )
        result = score_resume(resume)
        assert result.section_scores.get("Action Verbs", 0) >= 60

    def test_weak_verbs(self):
        resume = ResumeData(
            contact=ContactInfo(name="Test"),
            experience=[
                Experience(
                    company="X",
                    title="Eng",
                    bullets=[
                        "Helped with the deployment process",
                        "Responsible for server maintenance",
                        "Worked on the migration project",
                        "Assisted team with monitoring",
                    ],
                ),
            ],
        )
        result = score_resume(resume)
        assert result.section_scores.get("Action Verbs", 0) <= 60


class TestScoreResumeQuantification:
    """Test quantification scoring."""

    def test_quantified_bullets(self):
        resume = ResumeData(
            contact=ContactInfo(name="Test"),
            experience=[
                Experience(
                    company="X",
                    title="Eng",
                    bullets=[
                        "Reduced costs by $1.2M annually",
                        "Managed 200+ microservices with 99.99% uptime",
                        "Improved deployment frequency by 300%",
                    ],
                ),
            ],
        )
        result = score_resume(resume)
        assert result.section_scores.get("Quantification", 0) >= 80

    def test_no_quantification(self):
        resume = ResumeData(
            contact=ContactInfo(name="Test"),
            experience=[
                Experience(
                    company="X",
                    title="Eng",
                    bullets=[
                        "Managed servers",
                        "Deployed applications",
                        "Monitored systems",
                    ],
                ),
            ],
        )
        result = score_resume(resume)
        assert result.section_scores.get("Quantification", 0) <= 40


class TestScoreResumeGrading:
    """Test overall grading."""

    def test_grade_matches_score(self, full_resume: ResumeData):
        result = score_resume(full_resume)
        expected = ScoreGrade.from_score(result.total_score)
        assert result.grade == expected

    def test_score_bounded(self, full_resume: ResumeData):
        result = score_resume(full_resume)
        assert 0 <= result.total_score <= 100

    def test_max_score_is_100(self, full_resume: ResumeData):
        result = score_resume(full_resume)
        assert result.max_score == 100
