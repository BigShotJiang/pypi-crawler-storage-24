"""Shared test fixtures for ATS Resume Generator."""

from __future__ import annotations

import pytest

from ats_resume_generator.models import (
    Certification,
    ContactInfo,
    Education,
    Experience,
    Project,
    ResumeData,
    SkillGroup,
)


@pytest.fixture
def full_resume() -> ResumeData:
    """A complete, well-filled resume for testing."""
    return ResumeData(
        contact=ContactInfo(
            name="Jane Doe",
            email="jane.doe@example.com",
            phone="+1 (555) 123-4567",
            location="San Francisco, CA",
            linkedin="linkedin.com/in/janedoe",
            github="github.com/janedoe",
            website="janedoe.dev",
        ),
        summary=(
            "Senior DevOps Engineer with 8+ years of experience "
            "building cloud infrastructure, CI/CD pipelines, and "
            "container orchestration. Managed 200+ microservices with "
            "99.99% uptime, reduced cloud costs by $1.2M annually, "
            "and led a team of 5 engineers."
        ),
        target_role="devops-engineer",
        years_of_experience=8,
        experience=[
            Experience(
                company="Acme Corp",
                title="Senior DevOps Engineer",
                location="San Francisco, CA",
                start_date="Jan 2021",
                end_date="Present",
                bullets=[
                    "Architected Kubernetes platform hosting 200+ microservices with 99.99% uptime",
                    "Implemented GitOps deployment pipeline using ArgoCD enabling 150+ zero-downtime deployments weekly",
                    "Reduced cloud costs by $1.2M annually through right-sizing and spot instances",
                    "Designed observability stack with Prometheus and Grafana tracking 2,000+ metrics",
                    "Managed IaC for 500+ resources across 8 AWS accounts using Terraform",
                ],
                technologies=["Kubernetes", "AWS", "Terraform", "ArgoCD", "Prometheus"],
            ),
            Experience(
                company="Beta Inc",
                title="DevOps Engineer",
                location="New York, NY",
                start_date="Jun 2018",
                end_date="Dec 2020",
                bullets=[
                    "Built CI/CD pipelines with Jenkins and GitHub Actions for 30+ repositories",
                    "Migrated legacy applications to Docker containers reducing hosting costs by 40%",
                    "Automated infrastructure provisioning with Ansible reducing setup time from 2 days to 25 minutes",
                ],
                technologies=["Docker", "Jenkins", "Ansible", "GitHub Actions"],
            ),
        ],
        education=[
            Education(
                institution="MIT",
                degree="Bachelor of Science",
                field_of_study="Computer Science",
                graduation_date="May 2016",
                gpa="3.8",
            ),
        ],
        skills=[
            SkillGroup(category="Cloud", skills=["AWS", "Azure", "GCP"]),
            SkillGroup(category="Containers", skills=["Docker", "Kubernetes", "Helm"]),
            SkillGroup(category="CI/CD", skills=["Jenkins", "GitHub Actions", "ArgoCD"]),
            SkillGroup(category="IaC", skills=["Terraform", "Ansible", "CloudFormation"]),
            SkillGroup(category="Monitoring", skills=["Prometheus", "Grafana", "Datadog"]),
            SkillGroup(category="Programming", skills=["Python", "Bash", "Go"]),
        ],
        certifications=[
            Certification(
                name="AWS Solutions Architect Professional",
                issuer="Amazon Web Services",
                date="2023",
            ),
            Certification(
                name="CKA: Certified Kubernetes Administrator",
                issuer="CNCF",
                date="2022",
            ),
        ],
        projects=[
            Project(
                name="k8s-health-checker",
                description="CLI tool to scan Kubernetes clusters for health issues",
                url="github.com/janedoe/k8s-health-checker",
                technologies=["Python", "Click", "Rich"],
                highlights=["Published on PyPI", "22 tests"],
            ),
        ],
        languages=["English", "Spanish"],
    )


@pytest.fixture
def minimal_resume() -> ResumeData:
    """A bare-minimum resume for testing edge cases."""
    return ResumeData(
        contact=ContactInfo(name="John Smith", email="john@test.com"),
        summary="Software engineer.",
        experience=[
            Experience(
                company="Startup",
                title="Developer",
                bullets=["Worked on features"],
            ),
        ],
    )


@pytest.fixture
def empty_resume() -> ResumeData:
    """An empty resume with only defaults."""
    return ResumeData()
