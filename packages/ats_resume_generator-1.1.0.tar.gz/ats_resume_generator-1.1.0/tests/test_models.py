"""Tests for data models."""

from __future__ import annotations

import pytest

from ats_resume_generator.models import (
    ContactInfo,
    Education,
    Experience,
    GenerationResult,
    JobMatch,
    OutputFormat,
    ResumeData,
    ScoreFinding,
    ScoreGrade,
    ScoreResult,
    Severity,
    SkillCategory,
)


# ---------------------------------------------------------------------------
# Enum tests
# ---------------------------------------------------------------------------
class TestScoreGrade:
    """Test ScoreGrade enum and from_score classmethod."""

    @pytest.mark.parametrize("score, expected", [
        (100, ScoreGrade.A_PLUS),
        (95, ScoreGrade.A_PLUS),
        (94, ScoreGrade.A),
        (85, ScoreGrade.A),
        (84, ScoreGrade.B),
        (75, ScoreGrade.B),
        (74, ScoreGrade.C),
        (60, ScoreGrade.C),
        (59, ScoreGrade.D),
        (40, ScoreGrade.D),
        (39, ScoreGrade.F),
        (0, ScoreGrade.F),
    ])
    def test_from_score(self, score: int, expected: ScoreGrade):
        assert ScoreGrade.from_score(score) == expected

    def test_grade_values(self):
        assert ScoreGrade.A_PLUS.value == "A+"
        assert ScoreGrade.F.value == "F"


class TestSeverity:
    def test_values(self):
        assert Severity.CRITICAL.value == "critical"
        assert Severity.WARNING.value == "warning"
        assert Severity.INFO.value == "info"
        assert Severity.PASS.value == "pass"


class TestOutputFormat:
    def test_values(self):
        assert OutputFormat.PDF.value == "pdf"
        assert OutputFormat.DOCX.value == "docx"
        assert OutputFormat.MARKDOWN.value == "md"
        assert OutputFormat.HTML.value == "html"
        assert OutputFormat.TEXT.value == "txt"

    def test_all_formats(self):
        assert len(list(OutputFormat)) == 5


class TestSkillCategory:
    def test_all_categories(self):
        assert len(SkillCategory) >= 10


# ---------------------------------------------------------------------------
# Dataclass tests
# ---------------------------------------------------------------------------
class TestContactInfo:
    def test_defaults(self):
        c = ContactInfo()
        assert c.name == ""
        assert c.email == ""
        assert c.phone == ""

    def test_with_values(self):
        c = ContactInfo(name="Alice", email="a@b.com", phone="555-1234")
        assert c.name == "Alice"
        assert c.email == "a@b.com"


class TestExperience:
    def test_defaults(self):
        e = Experience()
        assert e.end_date == "Present"
        assert e.bullets == []
        assert e.technologies == []

    def test_with_bullets(self):
        e = Experience(bullets=["Built CI/CD", "Managed K8s"])
        assert len(e.bullets) == 2


class TestEducation:
    def test_defaults(self):
        edu = Education()
        assert edu.gpa == ""
        assert edu.honors == []


class TestResumeData:
    def test_all_skills_flat(self, full_resume: ResumeData):
        skills = full_resume.all_skills_flat()
        assert "AWS" in skills
        assert "Docker" in skills
        assert len(skills) >= 15

    def test_all_skills_flat_empty(self, empty_resume: ResumeData):
        assert empty_resume.all_skills_flat() == []

    def test_total_bullets(self, full_resume: ResumeData):
        assert full_resume.total_bullets() == 8  # 5 + 3

    def test_total_bullets_empty(self, empty_resume: ResumeData):
        assert empty_resume.total_bullets() == 0


# ---------------------------------------------------------------------------
# ScoreResult tests
# ---------------------------------------------------------------------------
class TestScoreResult:
    def test_counts(self):
        result = ScoreResult(
            findings=[
                ScoreFinding("A", "pass1", Severity.PASS),
                ScoreFinding("A", "pass2", Severity.PASS),
                ScoreFinding("B", "warn1", Severity.WARNING),
                ScoreFinding("C", "crit1", Severity.CRITICAL),
                ScoreFinding("D", "info1", Severity.INFO),
            ]
        )
        assert result.pass_count == 2
        assert result.warning_count == 1
        assert result.critical_count == 1
        assert result.info_count == 1


class TestJobMatch:
    def test_defaults(self):
        jm = JobMatch()
        assert jm.match_percentage == 0
        assert jm.matched_keywords == []
        assert jm.experience_match is False


class TestGenerationResult:
    def test_defaults(self):
        gr = GenerationResult()
        assert gr.success is False
        assert gr.format == OutputFormat.PDF
