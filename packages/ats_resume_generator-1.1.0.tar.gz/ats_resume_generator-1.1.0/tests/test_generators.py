"""Tests for resume generators (PDF, DOCX, Markdown, HTML, TXT)."""

from __future__ import annotations

from pathlib import Path

import pytest

from ats_resume_generator.demo import get_demo_resume
from ats_resume_generator.generators.docx_gen import generate_docx
from ats_resume_generator.generators.html import generate_html
from ats_resume_generator.generators.markdown import generate_markdown
from ats_resume_generator.generators.pdf import generate_pdf
from ats_resume_generator.generators.text import generate_text
from ats_resume_generator.models import ResumeData


# ---------------------------------------------------------------------------
# PDF Generator
# ---------------------------------------------------------------------------
class TestPDFGenerator:
    def test_generates_pdf(self, full_resume: ResumeData, tmp_path: Path):
        out = str(tmp_path / "resume.pdf")
        path = generate_pdf(full_resume, out)
        assert Path(path).exists()
        assert Path(path).suffix == ".pdf"
        assert Path(path).stat().st_size > 0

    def test_demo_pdf(self, tmp_path: Path):
        resume = get_demo_resume()
        out = str(tmp_path / "demo.pdf")
        path = generate_pdf(resume, out)
        assert Path(path).exists()
        assert Path(path).stat().st_size > 1000  # Should be substantial

    def test_minimal_resume_pdf(
        self, minimal_resume: ResumeData, tmp_path: Path
    ):
        out = str(tmp_path / "minimal.pdf")
        path = generate_pdf(minimal_resume, out)
        assert Path(path).exists()

    def test_empty_resume_pdf(
        self, empty_resume: ResumeData, tmp_path: Path
    ):
        out = str(tmp_path / "empty.pdf")
        path = generate_pdf(empty_resume, out)
        assert Path(path).exists()


# ---------------------------------------------------------------------------
# DOCX Generator
# ---------------------------------------------------------------------------
class TestDOCXGenerator:
    def test_generates_docx(self, full_resume: ResumeData, tmp_path: Path):
        out = str(tmp_path / "resume.docx")
        path = generate_docx(full_resume, out)
        assert Path(path).exists()
        assert Path(path).suffix == ".docx"
        assert Path(path).stat().st_size > 0

    def test_demo_docx(self, tmp_path: Path):
        resume = get_demo_resume()
        out = str(tmp_path / "demo.docx")
        path = generate_docx(resume, out)
        assert Path(path).exists()

    def test_empty_resume_docx(
        self, empty_resume: ResumeData, tmp_path: Path
    ):
        out = str(tmp_path / "empty.docx")
        path = generate_docx(empty_resume, out)
        assert Path(path).exists()


# ---------------------------------------------------------------------------
# Markdown Generator
# ---------------------------------------------------------------------------
class TestMarkdownGenerator:
    def test_generates_md(self, full_resume: ResumeData, tmp_path: Path):
        out = str(tmp_path / "resume.md")
        path = generate_markdown(full_resume, out)
        assert Path(path).exists()
        content = Path(path).read_text(encoding="utf-8")
        assert "# Jane Doe" in content
        assert "Senior DevOps Engineer" in content

    def test_contains_sections(self, full_resume: ResumeData, tmp_path: Path):
        out = str(tmp_path / "resume.md")
        generate_markdown(full_resume, out)
        content = Path(out).read_text(encoding="utf-8")
        assert "## Professional Summary" in content
        assert "## Work Experience" in content
        assert "## Technical Skills" in content
        assert "## Education" in content

    def test_contains_skills(self, full_resume: ResumeData, tmp_path: Path):
        out = str(tmp_path / "resume.md")
        generate_markdown(full_resume, out)
        content = Path(out).read_text(encoding="utf-8")
        assert "AWS" in content
        assert "Docker" in content

    def test_empty_resume_md(
        self, empty_resume: ResumeData, tmp_path: Path
    ):
        out = str(tmp_path / "empty.md")
        path = generate_markdown(empty_resume, out)
        assert Path(path).exists()


# ---------------------------------------------------------------------------
# HTML Generator
# ---------------------------------------------------------------------------
class TestHTMLGenerator:
    def test_generates_html(self, full_resume: ResumeData, tmp_path: Path):
        out = str(tmp_path / "resume.html")
        path = generate_html(full_resume, out)
        assert Path(path).exists()
        content = Path(path).read_text(encoding="utf-8")
        assert "<html" in content
        assert "Jane Doe" in content

    def test_has_inline_css(self, full_resume: ResumeData, tmp_path: Path):
        out = str(tmp_path / "resume.html")
        generate_html(full_resume, out)
        content = Path(out).read_text(encoding="utf-8")
        assert "<style" in content or "style=" in content

    def test_empty_resume_html(
        self, empty_resume: ResumeData, tmp_path: Path
    ):
        out = str(tmp_path / "empty.html")
        path = generate_html(empty_resume, out)
        assert Path(path).exists()


# ---------------------------------------------------------------------------
# Text Generator
# ---------------------------------------------------------------------------
class TestTextGenerator:
    def test_generates_txt(self, full_resume: ResumeData, tmp_path: Path):
        out = str(tmp_path / "resume.txt")
        path = generate_text(full_resume, out)
        assert Path(path).exists()
        content = Path(path).read_text(encoding="utf-8")
        assert "JANE DOE" in content  # text generator uppercases name

    def test_contains_contact(self, full_resume: ResumeData, tmp_path: Path):
        out = str(tmp_path / "resume.txt")
        generate_text(full_resume, out)
        content = Path(out).read_text(encoding="utf-8")
        assert "jane.doe@example.com" in content

    def test_empty_resume_txt(
        self, empty_resume: ResumeData, tmp_path: Path
    ):
        out = str(tmp_path / "empty.txt")
        path = generate_text(empty_resume, out)
        assert Path(path).exists()


# ---------------------------------------------------------------------------
# All generators with demo data
# ---------------------------------------------------------------------------
class TestAllGeneratorsDemoData:
    """Ensure every generator works with the full demo resume."""

    @pytest.mark.parametrize(
        "gen_func, ext",
        [
            (generate_pdf, "pdf"),
            (generate_docx, "docx"),
            (generate_markdown, "md"),
            (generate_html, "html"),
            (generate_text, "txt"),
        ],
    )
    def test_demo_generates(self, gen_func, ext, tmp_path: Path):
        resume = get_demo_resume()
        out = str(tmp_path / f"demo.{ext}")
        path = gen_func(resume, out)
        assert Path(path).exists()
        assert Path(path).stat().st_size > 0
