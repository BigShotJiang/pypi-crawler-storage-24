"""Tests for YAML/JSON resume parser."""

from __future__ import annotations

from pathlib import Path

import pytest
import yaml

from ats_resume_generator.models import ResumeData
from ats_resume_generator.parser import (
    export_resume_yaml,
    parse_resume_dict,
    parse_resume_file,
    resume_to_dict,
)


# ---------------------------------------------------------------------------
# parse_resume_dict tests
# ---------------------------------------------------------------------------
class TestParseResumeDict:
    def test_empty_dict(self):
        resume = parse_resume_dict({})
        assert isinstance(resume, ResumeData)
        assert resume.contact.name == ""
        assert resume.summary == ""

    def test_contact_info(self):
        data = {
            "contact": {
                "name": "Alice",
                "email": "alice@test.com",
                "phone": "555-1234",
                "linkedin": "linkedin.com/in/alice",
                "github": "github.com/alice",
            }
        }
        resume = parse_resume_dict(data)
        assert resume.contact.name == "Alice"
        assert resume.contact.email == "alice@test.com"
        assert resume.contact.linkedin == "linkedin.com/in/alice"

    def test_experience(self):
        data = {
            "experience": [
                {
                    "company": "Acme",
                    "title": "Engineer",
                    "start_date": "Jan 2020",
                    "end_date": "Present",
                    "bullets": ["Built things", "Fixed things"],
                    "technologies": ["Python", "Go"],
                }
            ]
        }
        resume = parse_resume_dict(data)
        assert len(resume.experience) == 1
        assert resume.experience[0].company == "Acme"
        assert len(resume.experience[0].bullets) == 2
        assert resume.experience[0].technologies == ["Python", "Go"]

    def test_education(self):
        data = {
            "education": [
                {
                    "institution": "MIT",
                    "degree": "BS",
                    "field_of_study": "CS",
                    "graduation_date": "2020",
                    "gpa": "3.9",
                }
            ]
        }
        resume = parse_resume_dict(data)
        assert len(resume.education) == 1
        assert resume.education[0].institution == "MIT"

    def test_skills(self):
        data = {
            "skills": [
                {"category": "Cloud", "skills": ["AWS", "Azure"]},
                {"category": "Programming", "skills": ["Python"]},
            ]
        }
        resume = parse_resume_dict(data)
        assert len(resume.skills) == 2
        assert resume.skills[0].skills == ["AWS", "Azure"]

    def test_certifications(self):
        data = {
            "certifications": [
                {"name": "CKA", "issuer": "CNCF", "date": "2023"}
            ]
        }
        resume = parse_resume_dict(data)
        assert len(resume.certifications) == 1
        assert resume.certifications[0].name == "CKA"

    def test_projects(self):
        data = {
            "projects": [
                {
                    "name": "my-tool",
                    "description": "A CLI tool",
                    "url": "github.com/user/tool",
                    "technologies": ["Python"],
                    "highlights": ["100 stars"],
                }
            ]
        }
        resume = parse_resume_dict(data)
        assert len(resume.projects) == 1
        assert resume.projects[0].name == "my-tool"

    def test_languages_and_target(self):
        data = {
            "languages": ["English", "French"],
            "target_role": "devops-engineer",
            "years_of_experience": 5,
        }
        resume = parse_resume_dict(data)
        assert resume.languages == ["English", "French"]
        assert resume.target_role == "devops-engineer"
        assert resume.years_of_experience == 5

    def test_full_round_trip(self, full_resume: ResumeData):
        """Convert to dict and back — data should survive."""
        d = resume_to_dict(full_resume)
        rebuilt = parse_resume_dict(d)
        assert rebuilt.contact.name == full_resume.contact.name
        assert rebuilt.contact.email == full_resume.contact.email
        assert len(rebuilt.experience) == len(full_resume.experience)
        assert len(rebuilt.skills) == len(full_resume.skills)
        assert rebuilt.target_role == full_resume.target_role


# ---------------------------------------------------------------------------
# parse_resume_file tests
# ---------------------------------------------------------------------------
class TestParseResumeFile:
    def test_file_not_found(self):
        with pytest.raises(FileNotFoundError):
            parse_resume_file("/nonexistent/path.yaml")

    def test_parse_yaml_file(self, tmp_path: Path):
        data = {
            "contact": {"name": "Bob", "email": "bob@test.com"},
            "summary": "An engineer",
        }
        yaml_path = tmp_path / "resume.yaml"
        yaml_path.write_text(yaml.dump(data), encoding="utf-8")

        resume = parse_resume_file(str(yaml_path))
        assert resume.contact.name == "Bob"
        assert resume.summary == "An engineer"

    def test_parse_invalid_yaml(self, tmp_path: Path):
        yaml_path = tmp_path / "bad.yaml"
        yaml_path.write_text("just a string", encoding="utf-8")

        with pytest.raises(ValueError, match="YAML/JSON object"):
            parse_resume_file(str(yaml_path))


# ---------------------------------------------------------------------------
# resume_to_dict tests
# ---------------------------------------------------------------------------
class TestResumeToDict:
    def test_basic(self, full_resume: ResumeData):
        d = resume_to_dict(full_resume)
        assert d["contact"]["name"] == "Jane Doe"
        assert d["summary"].startswith("Senior DevOps")
        assert len(d["experience"]) == 2
        assert len(d["skills"]) == 6
        assert d["languages"] == ["English", "Spanish"]

    def test_empty(self, empty_resume: ResumeData):
        d = resume_to_dict(empty_resume)
        assert d["contact"]["name"] == ""
        assert d["experience"] == []


# ---------------------------------------------------------------------------
# export_resume_yaml tests
# ---------------------------------------------------------------------------
class TestExportResumeYaml:
    def test_creates_file(self, full_resume: ResumeData, tmp_path: Path):
        out = tmp_path / "out.yaml"
        path = export_resume_yaml(full_resume, str(out))
        assert Path(path).exists()

        loaded = yaml.safe_load(out.read_text(encoding="utf-8"))
        assert loaded["contact"]["name"] == "Jane Doe"
