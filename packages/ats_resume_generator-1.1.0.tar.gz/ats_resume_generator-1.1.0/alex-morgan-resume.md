# Alex Morgan

📧 alex.morgan@techmail.com | 📱 +1-555-867-5309 | 📍 San Francisco, CA

[LinkedIn](linkedin.com/in/alexmorgan-devops) | [GitHub](github.com/alexmorgan) | [Website](alexmorgan.dev) | [Portfolio](alexmorgan.dev/portfolio)

---

## Professional Summary

Senior DevOps Engineer with 7+ years of experience designing scalable cloud infrastructure, CI/CD pipelines, and container orchestration platforms. Managed 200+ microservices on Kubernetes with 99.99% uptime. Reduced infrastructure costs by 42% ($1.2M annually) and deployment time by 85% through automation and GitOps practices. Published 4 open-source CLI tools on PyPI.

## Work Experience

### Senior DevOps Engineer | Nexus Technologies
*San Francisco, CA | Mar 2022 – Present*

- Architected multi-region Kubernetes platform hosting 200+ microservices with 99.99% uptime serving 50M daily requests across 3 AWS regions
- Designed and implemented GitOps-based deployment pipeline using ArgoCD, enabling 150+ zero-downtime deployments per week with automated canary analysis
- Reduced cloud infrastructure costs by 42% ($1.2M annually) through right-sizing, spot instances, reserved capacity, and automated scaling policies
- Built comprehensive observability stack with Prometheus, Grafana, and OpenTelemetry tracking 2,000+ metrics, reducing MTTR from 4 hours to 12 minutes
- Led infrastructure-as-code initiative managing 500+ resources across 8 AWS accounts using Terraform with automated drift detection and compliance checks
- Implemented shift-left security program integrating Trivy, OPA, and Falco, catching 95% of vulnerabilities before production deployment

**Technologies:** Kubernetes, Docker, Terraform, AWS, ArgoCD, Prometheus, Grafana, Python, Go

### DevOps Engineer | CloudScale Inc.
*Austin, TX | Jun 2019 – Feb 2022*

- Containerized 45 legacy Java applications and migrated to Kubernetes, improving resource utilization by 65% and reducing hosting costs by $400K annually
- Designed CI/CD pipelines using Jenkins and GitHub Actions for 30+ repositories, reducing build times from 45 minutes to 8 minutes (82% improvement)
- Implemented centralized logging with ELK Stack processing 3TB of logs daily across 200+ servers with automated anomaly detection
- Built disaster recovery solution achieving RPO of 5 minutes and RTO of 15 minutes across 2 regions using Terraform and automated failover
- Automated infrastructure provisioning with Ansible playbooks, reducing server setup time from 2 days to 25 minutes

**Technologies:** Docker, Kubernetes, Jenkins, GitHub Actions, Terraform, Ansible, ELK Stack, AWS

### Junior DevOps Engineer | DataFlow Systems
*Austin, TX | Jul 2017 – May 2019*

- Managed Linux server fleet of 150+ machines using Ansible configuration management with 99.5% uptime
- Built monitoring dashboards with Nagios and Grafana, reducing unplanned downtime by 60%
- Wrote Python automation scripts eliminating 15 hours/week of manual deployment tasks
- Supported migration of on-premises workloads to AWS, moving 25 applications in 6 months

**Technologies:** Linux, Ansible, Python, Bash, AWS, Nagios, Grafana, Docker

## Technical Skills

- **Cloud & Infrastructure:** AWS, Azure, GCP, Linux, Networking, Load Balancing
- **Containers & Orchestration:** Docker, Kubernetes, Helm, Istio, ECS, Docker Compose
- **CI/CD & GitOps:** GitHub Actions, Jenkins, GitLab CI, ArgoCD, FluxCD, Azure DevOps, Tekton
- **Infrastructure as Code:** Terraform, Ansible, Pulumi, CloudFormation, Crossplane
- **Monitoring & Observability:** Prometheus, Grafana, Datadog, ELK Stack, OpenTelemetry, PagerDuty, Jaeger
- **Programming & Scripting:** Python, Go, Bash, PowerShell, YAML, HCL
- **Security:** Trivy, OPA, Falco, Vault, RBAC, mTLS

## Certifications

- **AWS Solutions Architect Professional** — Amazon Web Services (2023)
- **Certified Kubernetes Administrator (CKA)** — Cloud Native Computing Foundation (2022)
- **Azure DevOps Engineer Expert** — Microsoft (2022)
- **HashiCorp Certified Terraform Associate** — HashiCorp (2021)

## Projects

### k8s-health-checker | [github.com/alexmorgan/k8s-health-checker](github.com/alexmorgan/k8s-health-checker)

CLI tool to scan Kubernetes clusters for health issues, misconfigurations, and security risks

- Published on PyPI (pip install k8s-health-checker)
- 22 automated tests, 100% pass rate

### azure-cost-optimizer | [github.com/alexmorgan/azure-cost-optimizer](github.com/alexmorgan/azure-cost-optimizer)

Analyze Azure resources and generate cost optimization reports with projected savings

- Finds $83K+/year in savings across 5 categories
- 67 automated tests

### tf-module-scaffolder | [github.com/alexmorgan/tf-module-scaffolder](github.com/alexmorgan/tf-module-scaffolder)

Generate production-ready Terraform modules with best practices from 16 templates

- 16 templates across AWS/Azure/GCP
- 94 automated tests

## Education

**Bachelor of Science in Computer Science** — University of Texas at Austin (2017) | GPA: 3.7/4.0
*Honors: Dean's List, Cum Laude*

## Languages

English (Native) | Spanish (Conversational)
