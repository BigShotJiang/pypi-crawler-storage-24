# pmtvs

Rust-accelerated signal analysis primitives.

**numpy in, number out.**

This is the umbrella package that re-exports all 260 functions from the 17 pmtvs micro-packages as a single flat API.

## Installation

```bash
pip install pmtvs
```

## Usage

```python
import numpy as np
from pmtvs import sample_entropy, hurst_exponent, eigendecomposition

signal = np.random.randn(5000)
print(sample_entropy(signal))
print(hurst_exponent(signal))
```

All functions are available directly from `pmtvs` — no submodule imports needed.

## Packages

| Package | Functions | Rust | Description |
|---------|-----------|------|-------------|
| pmtvs-entropy | 6 | 2 | Sample entropy, permutation entropy |
| pmtvs-fractal | 7 | 3 | Hurst exponent, DFA, rescaled range |
| pmtvs-statistics | 34 | 14 | Statistics, calculus, derivatives, normalization |
| pmtvs-correlation | 15 | 4 | Correlation, autocorrelation, Spearman |
| pmtvs-distance | 6 | 3 | Distance metrics, cosine similarity |
| pmtvs-embedding | 5 | 1 | Time delay embedding |
| pmtvs-coupling | 2 | 2 | Rolling Spearman correlation |
| pmtvs-rt-geometry | 3 | 3 | Run-time geometry, stable baseline |
| pmtvs-dynamics | 54 | 6 | Lyapunov, FTLE, RQA, sensitivity |
| pmtvs-spectral | 17 | 0 | FFT, PSD, wavelets |
| pmtvs-matrix | 23 | 0 | SVD, covariance, DMD, geometry |
| pmtvs-topology | 11 | 11 | Persistent homology |
| pmtvs-network | 11 | 0 | Graph analysis, community detection |
| pmtvs-information | 28 | 5 | Information theory, causality |
| pmtvs-tests | 27 | 0 | Statistical & hypothesis tests |
| pmtvs-regression | 5 | 0 | Linear regression, signal arithmetic |
| pmtvs-triangle | 6 | 0 | Compositional geometry, Aitchison distance |

## License

PolyForm Strict 1.0.0 with Additional Terms.

- **Students & individual researchers:** Free. Cite us.
- **Funded research labs (grants > $100K):** Academic Research License required. [Contact us](mailto:licensing@pmtvs.dev).
- **Commercial use:** Commercial License required. [Contact us](mailto:licensing@pmtvs.dev).

See [LICENSE](LICENSE) for full terms.
