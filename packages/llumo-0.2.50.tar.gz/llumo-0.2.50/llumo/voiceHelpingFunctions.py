import requests
import os
import json
import tempfile
import mimetypes
from mutagen import File





def downloadIfUrl(audioSource):
    """
    Downloads audio if the input is a URL.

    Returns
    -------
    tuple
        (localFilePath, fileName)
    """
    try:
        if audioSource.startswith("http"):
            response = requests.get(audioSource, timeout=30)
            response.raise_for_status()

            fileName = audioSource.split("/")[-1]

            tempFile = tempfile.NamedTemporaryFile(delete=False)
            tempFile.write(response.content)
            tempFile.close()

            return tempFile.name, fileName

        if not os.path.exists(audioSource):
            raise FileNotFoundError(f"Audio file not found at path: {audioSource}")

        return audioSource, os.path.basename(audioSource)

    except requests.exceptions.RequestException as error:
        raise RuntimeError(f"Failed to download audio from URL: {error}")


def getAudioMetadata(filePath):
    """
    Extracts duration and file size of the audio file.
    """
    try:
        fileSizeBytes = os.path.getsize(filePath)

        audioFile = File(filePath)

        if audioFile is None or not hasattr(audioFile, "info"):
            raise ValueError("Unable to determine audio duration. Unsupported audio format.")

        durationSec = int(audioFile.info.length)

        return durationSec, fileSizeBytes

    except Exception as error:
        raise RuntimeError(f"Failed to read audio metadata: {error}")


def uploadAudio(filePath, fileName, workspaceID):
    """
    Uploads audio file to the upload API.
    """
    url = "https://app.llumo.ai/api/audio/upload-file"

    try:
        mimeType = mimetypes.guess_type(fileName)[0] or "audio/mpeg"

        with open(filePath, "rb") as audioFile:

            files = {
                "file": (fileName, audioFile, mimeType)
            }

            data = {
                "fileName": fileName,
                "fileType": mimeType,
                "userId": workspaceID
            }

            response = requests.post(url, files=files, data=data, timeout=60)

        response.raise_for_status()

        result = response.json()

        if "fileUrl" not in result:
            raise ValueError("Upload API did not return fileUrl.")

        return result

    except requests.exceptions.RequestException as error:
        raise RuntimeError(f"Audio upload request failed: {error}")

    except ValueError as error:
        raise RuntimeError(f"Invalid upload response: {error}")


def loadTranscript(transcript):
    """
    Loads transcript from JSON file or Python list.
    """
    try:
        if isinstance(transcript, str):

            if not os.path.exists(transcript):
                raise FileNotFoundError(f"Transcript file not found: {transcript}")

            if not transcript.endswith(".json"):
                raise ValueError("Transcript file must have .json extension")

            with open(transcript, "r", encoding="utf-8") as file:
                transcriptJson = json.load(file)

        elif isinstance(transcript, list):
            transcriptJson = transcript

        else:
            raise ValueError("Transcript must be a JSON file path or a list of objects")

        for index, item in enumerate(transcriptJson):

            if not isinstance(item, dict):
                raise ValueError(f"Transcript entry at index {index} must be an object")

            if "query" not in item or "output" not in item:
                raise ValueError(
                    f"Transcript entry at index {index} must contain 'query' and 'output'"
                )

        return transcriptJson

    except Exception as error:
        raise RuntimeError(f"Failed to load transcript: {error}")


def processAudio(audioUrl, durationSec, fileSizeBytes, transcriptJson,workspaceID):
    """
    Calls the audio processing API.
    """
    url = "https://app.llumo.ai/api/audio/process-audio"

    payload = {
        "audio": {
            "audioUrl": audioUrl,
            "durationSec": durationSec,
            "fileSizeBytes": fileSizeBytes,
            "language": "en"
        },
        "inputLogs": transcriptJson,
        "workspaceID": workspaceID
    }

    try:
        response = requests.post(url, json=payload, timeout=60)

        response.raise_for_status()

        return response.json()

    except requests.exceptions.RequestException as error:
        raise RuntimeError(f"Audio processing request failed: {error}")


