import task_pb2 as _task_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class Request(_message.Message):
    __slots__ = ("task", "next", "send", "throw")
    TASK_FIELD_NUMBER: _ClassVar[int]
    NEXT_FIELD_NUMBER: _ClassVar[int]
    SEND_FIELD_NUMBER: _ClassVar[int]
    THROW_FIELD_NUMBER: _ClassVar[int]
    task: _task_pb2.Task
    next: Void
    send: _task_pb2.Message
    throw: _task_pb2.Message
    def __init__(self, task: _Optional[_Union[_task_pb2.Task, _Mapping]] = ..., next: _Optional[_Union[Void, _Mapping]] = ..., send: _Optional[_Union[_task_pb2.Message, _Mapping]] = ..., throw: _Optional[_Union[_task_pb2.Message, _Mapping]] = ...) -> None: ...

class Response(_message.Message):
    __slots__ = ("ack", "nack", "result", "exception")
    ACK_FIELD_NUMBER: _ClassVar[int]
    NACK_FIELD_NUMBER: _ClassVar[int]
    RESULT_FIELD_NUMBER: _ClassVar[int]
    EXCEPTION_FIELD_NUMBER: _ClassVar[int]
    ack: _task_pb2.Ack
    nack: _task_pb2.Nack
    result: _task_pb2.Message
    exception: _task_pb2.Message
    def __init__(self, ack: _Optional[_Union[_task_pb2.Ack, _Mapping]] = ..., nack: _Optional[_Union[_task_pb2.Nack, _Mapping]] = ..., result: _Optional[_Union[_task_pb2.Message, _Mapping]] = ..., exception: _Optional[_Union[_task_pb2.Message, _Mapping]] = ...) -> None: ...

class StopRequest(_message.Message):
    __slots__ = ("timeout",)
    TIMEOUT_FIELD_NUMBER: _ClassVar[int]
    timeout: float
    def __init__(self, timeout: _Optional[float] = ...) -> None: ...

class WorkerMetadata(_message.Message):
    __slots__ = ("uid", "address", "pid", "version", "tags", "extra", "secure")
    class ExtraEntry(_message.Message):
        __slots__ = ("key", "value")
        KEY_FIELD_NUMBER: _ClassVar[int]
        VALUE_FIELD_NUMBER: _ClassVar[int]
        key: str
        value: str
        def __init__(self, key: _Optional[str] = ..., value: _Optional[str] = ...) -> None: ...
    UID_FIELD_NUMBER: _ClassVar[int]
    ADDRESS_FIELD_NUMBER: _ClassVar[int]
    PID_FIELD_NUMBER: _ClassVar[int]
    VERSION_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    EXTRA_FIELD_NUMBER: _ClassVar[int]
    SECURE_FIELD_NUMBER: _ClassVar[int]
    uid: str
    address: str
    pid: int
    version: str
    tags: _containers.RepeatedScalarFieldContainer[str]
    extra: _containers.ScalarMap[str, str]
    secure: bool
    def __init__(self, uid: _Optional[str] = ..., address: _Optional[str] = ..., pid: _Optional[int] = ..., version: _Optional[str] = ..., tags: _Optional[_Iterable[str]] = ..., extra: _Optional[_Mapping[str, str]] = ..., secure: bool = ...) -> None: ...

class Void(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...
