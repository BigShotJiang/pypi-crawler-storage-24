from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar as _ClassVar, Optional as _Optional

DESCRIPTOR: _descriptor.FileDescriptor

class Task(_message.Message):
    __slots__ = ("version", "id", "caller", "tag", "proxy_id", "proxy", "callable", "args", "kwargs", "timeout")
    VERSION_FIELD_NUMBER: _ClassVar[int]
    ID_FIELD_NUMBER: _ClassVar[int]
    CALLER_FIELD_NUMBER: _ClassVar[int]
    TAG_FIELD_NUMBER: _ClassVar[int]
    PROXY_ID_FIELD_NUMBER: _ClassVar[int]
    PROXY_FIELD_NUMBER: _ClassVar[int]
    CALLABLE_FIELD_NUMBER: _ClassVar[int]
    ARGS_FIELD_NUMBER: _ClassVar[int]
    KWARGS_FIELD_NUMBER: _ClassVar[int]
    TIMEOUT_FIELD_NUMBER: _ClassVar[int]
    version: str
    id: str
    caller: str
    tag: str
    proxy_id: str
    proxy: bytes
    callable: bytes
    args: bytes
    kwargs: bytes
    timeout: int
    def __init__(self, version: _Optional[str] = ..., id: _Optional[str] = ..., caller: _Optional[str] = ..., tag: _Optional[str] = ..., proxy_id: _Optional[str] = ..., proxy: _Optional[bytes] = ..., callable: _Optional[bytes] = ..., args: _Optional[bytes] = ..., kwargs: _Optional[bytes] = ..., timeout: _Optional[int] = ...) -> None: ...

class TaskEnvelope(_message.Message):
    __slots__ = ("version", "id", "caller", "tag")
    VERSION_FIELD_NUMBER: _ClassVar[int]
    ID_FIELD_NUMBER: _ClassVar[int]
    CALLER_FIELD_NUMBER: _ClassVar[int]
    TAG_FIELD_NUMBER: _ClassVar[int]
    version: str
    id: str
    caller: str
    tag: str
    def __init__(self, version: _Optional[str] = ..., id: _Optional[str] = ..., caller: _Optional[str] = ..., tag: _Optional[str] = ...) -> None: ...

class Message(_message.Message):
    __slots__ = ("dump",)
    DUMP_FIELD_NUMBER: _ClassVar[int]
    dump: bytes
    def __init__(self, dump: _Optional[bytes] = ...) -> None: ...

class Worker(_message.Message):
    __slots__ = ("id", "address")
    ID_FIELD_NUMBER: _ClassVar[int]
    ADDRESS_FIELD_NUMBER: _ClassVar[int]
    id: str
    address: str
    def __init__(self, id: _Optional[str] = ..., address: _Optional[str] = ...) -> None: ...

class Ack(_message.Message):
    __slots__ = ("version",)
    VERSION_FIELD_NUMBER: _ClassVar[int]
    version: str
    def __init__(self, version: _Optional[str] = ...) -> None: ...

class Nack(_message.Message):
    __slots__ = ("reason",)
    REASON_FIELD_NUMBER: _ClassVar[int]
    reason: str
    def __init__(self, reason: _Optional[str] = ...) -> None: ...
