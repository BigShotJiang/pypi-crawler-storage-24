from __future__ import annotations

import asyncio
import logging
import traceback
from collections.abc import Callable
from contextlib import contextmanager
from contextvars import Context
from contextvars import ContextVar
from dataclasses import dataclass
from functools import wraps
from inspect import isasyncgenfunction
from inspect import iscoroutinefunction
from types import TracebackType
from typing import Any
from typing import AsyncGenerator
from typing import ContextManager
from typing import Coroutine
from typing import Dict
from typing import Generic
from typing import Literal
from typing import Protocol
from typing import SupportsInt
from typing import Tuple
from typing import TypeAlias
from typing import TypeVar
from typing import cast
from typing import overload
from uuid import UUID

import cloudpickle

import wool
from wool import protocol
from wool.runtime.event import Event

Args = Tuple
Kwargs = Dict
Timeout = SupportsInt
Timestamp = SupportsInt
Routine: TypeAlias = Coroutine | AsyncGenerator
W = TypeVar("W", bound=Routine)


_do_dispatch: ContextVar[bool] = ContextVar("_do_dispatch", default=True)


@contextmanager
def _do_dispatch_context_manager(flag: bool, /):
    token = _do_dispatch.set(flag)
    try:
        yield
    finally:
        _do_dispatch.reset(token)


@overload
def do_dispatch() -> bool: ...


@overload
def do_dispatch(flag: bool, /) -> ContextManager[None]: ...


def do_dispatch(flag: bool | None = None, /) -> bool | ContextManager[None]:
    if flag is None:
        return _do_dispatch.get()
    else:
        return _do_dispatch_context_manager(flag)


# public
class WorkerProxyLike(Protocol):
    """Protocol defining the interface required by Task for proxy objects.

    This allows both the actual WorkerProxy and test doubles to be used
    with Task without requiring inheritance.
    """

    @property
    def id(self) -> UUID: ...

    async def dispatch(
        self, task: Task, *, timeout: float | None = None
    ) -> AsyncGenerator: ...


# public
@dataclass
class Task(Generic[W]):
    """
    Represents a distributed task to be executed in the worker pool.

    Each task encapsulates a function call along with its arguments and
    execution context. Tasks are created when decorated functions are
    invoked and contain all necessary information for remote execution
    including serialization, routing, and result handling.

    :param id:
        Unique identifier for this task instance.
    :param callable:
        The asynchronous function to execute.
    :param args:
        Positional arguments for the function.
    :param kwargs:
        Keyword arguments for the function.
    :param proxy:
        Proxy object for task dispatch and routing (satisfies WorkerProxyLike).
    :param timeout:
        Task timeout in seconds (0 means no timeout).
    :param caller:
        UUID of the calling task if this is a nested task.
    :param exception:
        Exception information if task execution failed.
    :param filename:
        Source filename where the task was defined.
    :param function:
        Name of the function being executed.
    :param line_no:
        Line number where the task was defined.
    :param tag:
        Optional descriptive tag for the task.
    """

    id: UUID
    callable: Callable[..., W]
    args: Args
    kwargs: Kwargs
    proxy: WorkerProxyLike
    timeout: Timeout = 0
    caller: UUID | None = None
    exception: TaskException | None = None
    filename: str | None = None
    function: str | None = None
    line_no: int | None = None
    tag: str | None = None

    def __post_init__(self, **kwargs):
        """
        Initialize the task and emit a "task-created" event.

        Sets up the task context including caller tracking and event emission
        for monitoring and debugging purposes.

        :param kwargs:
            Additional keyword arguments (unused).
        """
        if caller := _current_task.get():
            self.caller = caller.id
        TaskEvent("task-created", task=self).emit()

    def __enter__(self) -> Callable[[], Coroutine | AsyncGenerator]:
        """
        Enter the task context for execution.

        :returns:
            The task's run method as a callable coroutine.
        """
        logging.debug(f"Entering {self.__class__.__name__} with ID {self.id}")
        self._task_token = _current_task.set(self)
        if iscoroutinefunction(self.callable):
            return self._run
        elif isasyncgenfunction(self.callable):
            return self._stream
        else:
            raise ValueError("Expected coroutine function or async generator function")

    def __exit__(
        self,
        exception_type: type[BaseException] | None,
        exception_value: BaseException | None,
        exception_traceback: TracebackType | None,
    ):
        """Exit the task context and handle any exceptions.

        Captures exception information for later processing and allows
        exceptions to propagate normally for proper error handling.

        :param exception_type:
            Type of exception that occurred, if any.
        :param exception_value:
            Exception instance that occurred, if any.
        :param exception_traceback:
            Traceback of the exception, if any.
        :returns:
            False to allow exceptions to propagate.
        """
        logging.debug(f"Exiting {self.__class__.__name__} with ID {self.id}")
        this = asyncio.current_task()
        assert this
        if exception_value:
            self.exception = TaskException(
                exception_type.__qualname__,
                traceback=[
                    y
                    for x in traceback.format_exception(
                        exception_type, exception_value, exception_traceback
                    )
                    for y in x.split("\n")
                ],
            )
        this.add_done_callback(self._finish, context=Context())
        _current_task.reset(self._task_token)
        # Return False to allow exceptions to propagate
        return False

    @classmethod
    def from_protobuf(cls, task: protocol.task.Task) -> Task:
        return cls(
            id=UUID(task.id),
            callable=cloudpickle.loads(task.callable),
            args=cloudpickle.loads(task.args),
            kwargs=cloudpickle.loads(task.kwargs),
            caller=UUID(task.caller) if task.caller else None,
            proxy=cloudpickle.loads(task.proxy),
            timeout=task.timeout if task.timeout else 0,
            tag=task.tag if task.tag else None,
        )

    def to_protobuf(self) -> protocol.task.Task:
        return protocol.task.Task(
            version=protocol.__version__,
            id=str(self.id),
            callable=cloudpickle.dumps(self.callable),
            args=cloudpickle.dumps(self.args),
            kwargs=cloudpickle.dumps(self.kwargs),
            caller=str(self.caller) if self.caller else "",
            proxy=cloudpickle.dumps(self.proxy),
            proxy_id=str(self.proxy.id),
            timeout=int(self.timeout) if self.timeout else 0,
            tag=self.tag if self.tag else "",
        )

    def dispatch(self) -> W:
        if isasyncgenfunction(self.callable):
            return cast(W, self._stream())
        elif iscoroutinefunction(self.callable):
            return cast(W, self._run())
        else:
            raise ValueError("Expected routine to be coroutine or async generator")

    async def _run(self):
        """
        Execute the task's callable with its arguments in proxy context.

        :returns:
            The result of executing the callable.
        :raises RuntimeError:
            If no proxy pool is available for task execution.
        """
        assert iscoroutinefunction(self.callable), "Expected coroutine function"
        proxy_pool = wool.__proxy_pool__.get()
        if not proxy_pool:
            raise RuntimeError("No proxy pool available for task execution")
        async with proxy_pool.get(self.proxy) as proxy:
            # Set the proxy in context variable for nested task dispatch
            token = wool.__proxy__.set(proxy)
            try:
                with self:
                    with do_dispatch(False):
                        await asyncio.sleep(0)
                        return await self.callable(*self.args, **self.kwargs)
            finally:
                wool.__proxy__.reset(token)

    async def _stream(self):
        """
        Execute the task's callable with its arguments in proxy context.

        :returns:
            An async generator that yields values from the callable.
        :raises RuntimeError:
            If no proxy pool is available for task execution.
        """
        assert isasyncgenfunction(self.callable), "Expected async generator function"
        proxy_pool = wool.__proxy_pool__.get()
        if not proxy_pool:
            raise RuntimeError("No proxy pool available for task execution")
        async with proxy_pool.get(self.proxy) as proxy:
            await asyncio.sleep(0)
            gen = self.callable(*self.args, **self.kwargs)
            try:
                while True:
                    # Set the proxy in context variable for nested task dispatch
                    token = wool.__proxy__.set(proxy)
                    try:
                        with self:
                            with do_dispatch(False):
                                try:
                                    result = await anext(gen)
                                except StopAsyncIteration:
                                    break
                    finally:
                        wool.__proxy__.reset(token)

                    yield result
            finally:
                await gen.aclose()

    def _finish(self, _):
        TaskEvent("task-completed", task=self).emit()


# public
@dataclass
class TaskException:
    """
    Represents an exception that occurred during distributed task execution.

    Captures exception information from remote task execution for proper
    error reporting and debugging. The exception details are serialized
    and transmitted back to the calling context.

    :param type:
        Qualified name of the exception class.
    :param traceback:
        List of formatted traceback lines from the exception.
    """

    type: str
    traceback: list[str]


# public
class TaskEvent(Event):
    """
    Represents a lifecycle event for a distributed task.

    Events are emitted at key points during task execution and can be used
    for monitoring, debugging, and performance analysis. Event handlers can
    be registered to respond to specific event types.

    :param type:
        The type of task event (e.g., "task-created", "task-scheduled").
    :param task:
        The :class:`Task` instance associated with this event.
    """

    task: Task

    def __init__(self, type: TaskEventType, /, task: Task) -> None:
        super().__init__(type)
        self.task = task

    def emit(self, context=None):
        """
        Emit the task event, invoking all registered handlers for the
        event type.

        Handlers are called with the event instance, timestamp, and
        optional context metadata.

        :param context:
            Optional metadata passed to handlers (e.g., emitter
            identification).
        """
        logging.debug(
            f"Emitting {self.type} event for "
            f"task {self.task.id} "
            f"({self.task.callable.__qualname__})"
        )
        # Delegate to base class Event.emit()
        super().emit(context)


# public
IterationEventKind = Literal["next", "send", "throw"]
"""
Identifies the operation that drove an iteration of a streaming
dispatch.

- ``"next"``: The client called ``__anext__()`` or the server
  received a ``next`` frame.
- ``"send"``: The client called ``asend(value)`` or the server
  received a ``send`` frame.
- ``"throw"``: The client called ``athrow(exc)`` or the server
  received a ``throw`` frame.
"""


# public
class IterationEvent(TaskEvent):
    """Lifecycle event for a single iteration of a streaming dispatch.

    Emitted at three points during each iteration round-trip:

    * ``"task-iteration-initiated"`` — on the client, before writing
      the request to the gRPC stream.
    * ``"task-iteration-started"`` — on the server, after forwarding
      the command to the worker loop.
    * ``"task-iteration-completed"`` — on the server, after receiving
      the result from the worker loop.

    :param type:
        One of the ``task-iteration-*`` event types.
    :param task:
        The :class:`Task` associated with this iteration.
    :param kind:
        The operation kind (``"next"``, ``"send"``, or
        ``"throw"``).
    :param step:
        Zero-based step index of this iteration within the
        stream.
    """

    kind: IterationEventKind
    step: int

    def __init__(
        self,
        type: TaskEventType,
        /,
        task: Task,
        kind: IterationEventKind,
        step: int,
    ) -> None:
        super().__init__(type, task=task)
        self.kind = kind
        self.step = step


# public
TaskEventType = Literal[
    "task-created",
    "task-scheduled",
    "task-started",
    "task-stopped",
    "task-completed",
    "task-iteration-initiated",
    "task-iteration-started",
    "task-iteration-completed",
]
"""
Defines the types of events that can occur during the lifecycle of a Wool
task.

- "task-created":
    Emitted when a task is created.
- "task-scheduled":
    Emitted when a task is scheduled for execution in a worker's event
    loop.
- "task-started":
    Emitted when a task starts execution.
- "task-stopped":
    Emitted when a task stops execution.
- "task-completed":
    Emitted when a task completes execution.
- "task-iteration-initiated":
    Emitted on the client before writing an iteration request to the
    gRPC stream.
- "task-iteration-started":
    Emitted on the server after forwarding the iteration command to
    the worker loop.
- "task-iteration-completed":
    Emitted on the server after receiving the iteration result from
    the worker loop.
"""


# public
class TaskEventHandler(Protocol):
    """
    Protocol for :py:class:`TaskEvent` callback functions.
    """

    def __call__(self, event: TaskEvent, timestamp: Timestamp, context=None) -> None: ...


_current_task: ContextVar[Task | None] = ContextVar("_current_task", default=None)


# public
def current_task() -> Task | None:
    """
    Get the current task from the context variable if we are inside a task
    context, otherwise return None.

    :returns:
        The current task or None if no task is active.
    """
    return _current_task.get()


def _run(fn):
    @wraps(fn)
    def wrapper(self, *args, **kwargs):
        if current_task := self._context.get(_current_task):
            TaskEvent("task-started", task=current_task).emit()
            try:
                result = fn(self, *args, **kwargs)
            finally:
                TaskEvent("task-stopped", task=current_task).emit()
            return result
        else:
            return fn(self, *args, **kwargs)

    return wrapper


asyncio.Handle._run = _run(asyncio.Handle._run)
