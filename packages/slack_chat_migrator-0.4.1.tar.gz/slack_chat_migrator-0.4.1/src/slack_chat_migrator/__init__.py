#!/usr/bin/env python3
"""Slack to Google Chat migration tool."""

__version__ = "0.4.1"

__all__ = ["__version__"]
