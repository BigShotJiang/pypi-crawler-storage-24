from setuptools import setup, find_packages
import os

# Read the contents of your README file for the long description
with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="mtrader", 
    version="0.1.0",
    author="Manjur Alam",
    author_email="your.email@example.com", # Added for completeness
    description="A high-performance algorithmic trading and data inspection library.",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/yourusername/mtrader", # Replace with your actual repo
    packages=find_packages(),
    install_requires=[
        "numpy>=1.21.0",
        "pandas>=1.3.0",
        "numba>=0.54.0",
        "openpyxl>=3.0.0", # Required for the Excel inspection feature
    ],
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License", # Assuming MIT, change if needed
        "Operating System :: OS Independent",
        "Topic :: Office/Business :: Financial :: Investment",
    ],
    python_requires='>=3.9', # Modern standard for trading libs
)