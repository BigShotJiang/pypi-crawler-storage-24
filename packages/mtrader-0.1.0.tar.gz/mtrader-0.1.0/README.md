# 📈 mtrader

**mtrader** is a professional-grade Python library for **quantitative
traders and data scientists**.\
It works like a **Swiss Army Knife for data inspection**, letting you
debug complex financial datasets with a single command.

------------------------------------------------------------------------

# 🛠 Feature: `inspect()`

`inspect()` is a **Universal Data Explorer**.

Instead of multiple debugging calls like:

-   `print()`
-   `type()`
-   `.info()`
-   `.describe()`

You run:

``` python
mt.inspect(data)
```

and get a **high-density statistical report**.

------------------------------------------------------------------------

# 💎 Key Capabilities

**Deep Statistics**\
For each column:

-   Count, Max, Min
-   Mean, Std
-   Median, Mode
-   NaN count

**Intelligent Headers**

Displays:

-   Exact Python `<class>`
-   Data shape
-   Object structure

**Auto-Flattening for Tensors**

3D tensors like:

    (Tickers, Time, Features)

are flattened automatically for **global statistical analysis**.

**Smart Dictionary Pivot**

Dictionaries with equal-length lists are automatically converted into
**column tables**.

Perfect for:

-   Exchange APIs
-   JSON feeds
-   Trading signals

**Auto Loader**

Inspect files directly:

-   CSV
-   Excel
-   JSON strings

Example:

``` python
mt.inspect("historical_prices.csv")
```

**Stress‑Proof Logic**

Safe statistical handling prevents crashes when:

-   Data types are mixed
-   Columns are empty
-   Strings appear with numbers

------------------------------------------------------------------------

# 📊 Example Output

Running:

``` python
mt.inspect(df)
```

Produces:

    Data type: <class 'pandas.DataFrame'>
    It is a pandas DataFrame. Total rows: 5. Total columns: 2. Summary:

    column:      price      volume
     dtype:    float64       int64
         -      -----       -----
     Row 0:      100.5        1000
     Row 1:      101.2        1500
     Row 2:      100.8        1200
    ----------  -----       -----
     count:          5           5
       max:      102.1      2000.0
       min:      100.5      1000.0
      mean:     101.22      1500.0
       std:   0.622093  412.310563
    median:      101.2      1500.0
      mode:      100.5      1000.0
       nan:          0           0

------------------------------------------------------------------------

# 🚀 Usage Examples

## 1. Pandas DataFrame

``` python
import mtrader as mt
import pandas as pd

df = pd.DataFrame({
    'price': [100.5, 101.2, 100.8, 102.1, 101.5],
    'volume': [1000, 1500, 1200, 1800, 2000]
})

mt.inspect(df)
```

------------------------------------------------------------------------

## 2. Pandas Series

``` python
series = pd.Series([10, 20, 30, 40, 50], name="RSI_Indicator")
mt.inspect(series)
```

------------------------------------------------------------------------

## 3. Smart Dictionary Pivot

``` python
data = {
    "Ticker": ["BTC", "ETH", "SOL"],
    "Price": [62000.5, 3400.2, 145.1],
    "Signal": ["Buy", "Hold", "Buy"]
}

mt.inspect(data)
```

------------------------------------------------------------------------

## 4. 3D NumPy Tensor

``` python
import numpy as np

# Shape: (2 Tickers, 100 Days, 5 Features)
tensor_data = np.random.randn(2, 100, 5)

mt.inspect(tensor_data)
```

------------------------------------------------------------------------

## 5. Auto‑Loading Files

``` python
mt.inspect("historical_prices.csv")
```

------------------------------------------------------------------------

## 6. JSON API Responses

``` python
json_response = '{"Symbol": ["AAPL", "TSLA"], "Price": [150.2, 700.5]}'

mt.inspect(json_response)
```

------------------------------------------------------------------------

# ⚙️ Parameters

  Parameter   Type   Default    Description
  ----------- ------ ---------- ----------------------------------------
  df          Any    Required   Data object, file path, or JSON string
  count       int    3          Rows shown from top & bottom
  silent      bool   False      Hide headers and show only table

------------------------------------------------------------------------

# 📦 Installation

Clone:

``` bash
git clone https://github.com/yourusername/mtrader_lib.git
```

Install dependencies:

``` bash
pip install pandas numpy openpyxl
```

------------------------------------------------------------------------

# ⭐ Why mtrader

Financial datasets are often:

-   Large
-   Messy
-   Multi‑dimensional

`mtrader` provides **instant visibility** so you can:

-   Debug faster
-   Validate datasets
-   Build trading models quicker

------------------------------------------------------------------------

# 📜 License

MIT License
