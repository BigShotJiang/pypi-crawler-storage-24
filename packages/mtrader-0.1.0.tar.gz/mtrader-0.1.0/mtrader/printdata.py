import numpy as np
import pandas as pd
import os
import json
import sys
import subprocess
import platform
import shutil
import importlib.metadata
from pandas.api.types import is_numeric_dtype

# ============================================================
# ENVIRONMENT INSPECTION (Silent Mode Enabled)
# ============================================================
def _inspect_all_info():
    # Setup for silent subprocess execution on Windows (prevents CMD flicker)
    startupinfo = None
    if platform.system() == "Windows":
        startupinfo = subprocess.STARTUPINFO()
        startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW
        startupinfo.wShowWindow = subprocess.SW_HIDE

    print("\n========== SYSTEM ==========")
    print("OS:          ", platform.system(), platform.release())
    print("Architecture:", platform.machine())
    print("Processor:   ", platform.processor())

    # --- LIGHTWEIGHT GPU & CUDA DETECTION ---
    print("\n========== GPU & CUDA ==========")
    try:
        gpu_raw = subprocess.check_output(
            ["nvidia-smi", "--query-gpu=gpu_name,memory.total,driver_version", "--format=csv,noheader,nounits"],
            text=True, 
            startupinfo=startupinfo
        ).strip()
        
        if gpu_raw:
            name, mem, driver = gpu_raw.split(',')
            print(f"Hardware:       {name.strip()}")
            print(f"Total Memory:   {mem.strip()} MB")
            print(f"Driver Version: {driver.strip()}")
            
            cuda_info = subprocess.check_output(["nvidia-smi"], text=True, startupinfo=startupinfo)
            for line in cuda_info.split('\n'):
                if "CUDA Version:" in line:
                    v_part = line.split("CUDA Version:")[1].strip()
                    print(f"CUDA Version:   {v_part.split(' ')[0]}")
                    break
    except:
        print("Status:         No NVIDIA GPU or Driver detected via nvidia-smi.")

    print("\n========== SCRIPT ==========")
    print("Current Working Directory:", os.getcwd())
    try:
        print("Script Path:              ", os.path.abspath(sys.argv[0]))
    except: pass

    # --- UPDATED ENVIRONMENT LOGIC (ml_env detection) ---
    print("\n========== CURRENT ENVIRONMENT ==========")
    is_venv = (hasattr(sys, 'real_prefix') or 
               (getattr(sys, 'base_prefix', sys.prefix) != sys.prefix))
    
    if is_venv:
        env_name = os.path.basename(sys.prefix)
    else:
        env_name = "Global System"

    print("Name:             ", env_name)
    print("Path:             ", sys.prefix)
    print("Python:           ", sys.version.split()[0])
    print("Python Executable:", sys.executable)

    try:
        pip_info = subprocess.check_output(
            [sys.executable, "-m", "pip", "--version"],
            text=True, startupinfo=startupinfo
        ).strip()
        print("\nPip:              ", pip_info)
    except:
        print("\nPip:               Not detected")

    print("\nInstalled Packages:")
    try:
        packages = sorted(
            [(d.metadata["Name"], d.version) for d in importlib.metadata.distributions()],
            key=lambda x: x[0].lower()
        )
        line = []
        for name, ver in packages:
            line.append(f"{name} {ver}")
            if len(line) == 4:
                print(" | ".join(line))
                line = []
        if line:
            print(" | ".join(line))
    except:
        print("Could not read installed packages")

    print("\n========== DEFAULT PYTHON (CMD) ==========")
    try:
        default_python = shutil.which("python")
        if default_python:
            print("python command ->", default_python)
            try:
                v = subprocess.check_output(
                    [default_python, "--version"],
                    text=True, startupinfo=startupinfo
                ).strip()
                print("Version:         ", v)
            except: pass
        else:
            print("python command not found in PATH")
    except: pass

    print("\n========== OTHER PYTHON INSTALLATIONS ==========")
    versions = set()
    try:
        result = subprocess.run(
            ["where", "python"],
            capture_output=True, text=True, startupinfo=startupinfo
        )
        python_paths = list(set(result.stdout.splitlines()))
        current_exe = os.path.abspath(sys.executable)
        idx = 1

        for path in python_paths:
            if os.path.abspath(path) == current_exe:
                continue

            print(f"\nEnvironment #{idx}")
            print("Python Path:", path)
            try:
                v = subprocess.check_output(
                    [path, "--version"],
                    text=True, startupinfo=startupinfo
                ).strip()
                print("Python:     ", v)
                versions.add(v)
            except: pass

            try:
                pipv = subprocess.check_output(
                    [path, "-m", "pip", "--version"],
                    text=True, startupinfo=startupinfo
                ).strip()
                print("pip:        ", pipv)
            except:
                print("pip:         not installed")

            # RESTORED PACKAGE LISTING FOR OTHER ENVIRONMENTS
            print("\nInstalled Packages:")
            try:
                pkg_output = subprocess.check_output(
                    [path, "-m", "pip", "list", "--format=freeze"],
                    text=True, startupinfo=startupinfo
                )
                pkg_lines = sorted(pkg_output.strip().splitlines())
                line = []
                for p in pkg_lines:
                    name_ver = p.replace("==", " ")
                    line.append(name_ver)
                    if len(line) == 4:
                        print(" | ".join(line))
                        line = []
                if line:
                    print(" | ".join(line))
            except:
                print("Could not read installed packages")
            
            idx += 1
    except:
        print("Could not detect other python installations")

    print("\n========== WARNINGS ==========")
    if len(versions) > 1:
        print("WARNING: multiple Python versions detected")
        for v in versions:
            print(" ", v)

    print("\n========== TOOL ==========")
    tool = "Terminal"
    if "VSCODE_PID" in os.environ: tool = "VS Code"
    elif "PYCHARM_HOSTED" in os.environ: tool = "PyCharm"
    elif "ipykernel" in sys.modules: tool = "Jupyter"
    elif "idlelib" in sys.modules: tool = "IDLE"
    print("Running in:", tool)

# ============================================================
# ORIGINAL INSPECT FUNCTION
# ============================================================
def inspect(df, count=None, silent=False):
    if isinstance(df, str) and df.lower() == "all_info":
        _inspect_all_info()
        return

    if not silent:
        print(f"\nData type: {type(df)}")

    is_native_type = False
    if isinstance(df, str):
        if df.lower().endswith(('.csv', '.xlsx')):
            if os.path.exists(df):
                if not silent: print(f"File detected: '{df}'. Loading for inspection...")
                try:
                    df = pd.read_csv(df) if df.lower().endswith('.csv') else pd.read_excel(df)
                except Exception as e:
                    if not silent: print(f"Error loading file: {e}")
            else:
                if not silent: print(f"Path string detected, but file not found at: {df}")
        elif (df.strip().startswith('{') and df.strip().endswith('}')) or \
             (df.strip().startswith('[') and df.strip().endswith(']')):
            try:
                df = json.loads(df)
                if not silent: print("JSON string detected. Parsed for inspection.")
            except: pass

    if isinstance(df, dict):
        is_native_type = True
        lengths = [len(v) for v in df.values() if isinstance(v, (list, tuple))]
        all_lists = all(isinstance(v, (list, tuple)) for v in df.values())
        if all_lists and len(set(lengths)) == 1 and len(lengths) > 0:
            df = pd.DataFrame(df)
            if not silent: print("Dictionary detected with equal-length lists. Dictionary keys used as Columns.")
        else:
            df = pd.Series(df).to_frame(name="value")
            if not silent: print("Input is a dictionary. Keys moved to Index for inspection.")
    elif isinstance(df, (list, tuple, set)):
        is_native_type = True
        original_type_name = type(df).__name__ 
        df = pd.Series(list(df))
        if not silent: print(f"Input is a {original_type_name}. Converted for inspection.")

    if isinstance(df, (pd.DataFrame, pd.Series, np.ndarray)):   
        if isinstance(df, pd.Series): 
            series_name = df.name if df.name else "it_is_series"
            new_df = df.to_frame(name=series_name)
            if not silent:
                prefix = "" if is_native_type else "It is a pandas Series. "
                print(f"{prefix}Total items: {len(new_df)}. Summary:")
        elif isinstance(df, np.ndarray): 
            numpy_new = df.copy()
            if numpy_new.ndim == 1:        
                new_df = pd.DataFrame(numpy_new, columns=["numpy_array"])
                if not silent: print(f"Input is a 1D numpy array (Shape: {numpy_new.shape}). Total items: {len(new_df)}. Summary:")
            elif numpy_new.ndim == 2:
                col_names = [f"col_{i}" for i in range(numpy_new.shape[1])]
                new_df = pd.DataFrame(numpy_new, columns=col_names)
                if not silent: print(f"Input is a 2D numpy array (Shape: {numpy_new.shape}). Total rows: {len(new_df)}. Total columns: {len(new_df.columns)}. Summary:")
            elif numpy_new.ndim == 3:
                depth, rows, cols = numpy_new.shape
                new_df = pd.DataFrame(numpy_new.reshape(-1, cols), columns=[f"feature_{i}" for i in range(cols)])
                if not silent: print(f"Input is a 3D numpy array (Shape: {numpy_new.shape}). Total items (flattened): {depth*rows}. Total columns: {cols}. Summary:")
            else:
                if not silent: print(f"Array is {numpy_new.ndim}D (Shape: {numpy_new.shape}). Default print:")
                print(numpy_new); return
        elif isinstance(df, pd.DataFrame):
            new_df = df.copy()
            if not silent:
                prefix = "" if is_native_type else "It is a pandas DataFrame. "
                print(f"{prefix}Total rows: {len(new_df)}. Total columns: {len(new_df.columns)}. Summary:")

        def safe_stat(col, func_name):
            try:
                if func_name == 'max':
                    val = col.max()
                    return val.strftime('%Y-%m-%d %H:%M:%S') if pd.api.types.is_datetime64_any_dtype(col) else val
                if func_name == 'min':
                    val = col.min()
                    return val.strftime('%Y-%m-%d %H:%M:%S') if pd.api.types.is_datetime64_any_dtype(col) else val
                if func_name == 'mean': return col.mean() if is_numeric_dtype(col) else "-"
                if func_name == 'std': return col.std() if is_numeric_dtype(col) else "-"
                if func_name == 'median': return col.median() if is_numeric_dtype(col) else "-"
                if func_name == 'mode':
                    m = col.mode()
                    return m.iloc[0] if not m.empty else "-"
            except: return "-"
            return "-"

        row_to_print = count if count else 3
        if new_df.empty: print("The DataFrame is empty."); return
        if not is_numeric_dtype(new_df.index) or (len(new_df) > 0 and new_df.index[-1] != (len(new_df) - 1)):
            new_df.reset_index(drop=False, inplace=True)

        headers = new_df.columns
        dashs = ['-----'] * len(headers)
        summary_rows = [["dtype:", *new_df.dtypes.astype(str)], ["-", *dashs]]
        
        first_rows = new_df.head(min(row_to_print, len(new_df)))
        for i, (_, row) in enumerate(first_rows.iterrows()):
            summary_rows.append([f"Row {i}:", *row.tolist()])
        
        if len(new_df) > (row_to_print * 2):
            summary_rows.append(["--", *dashs])
            last_rows = new_df.tail(row_to_print)
            for i, (_, row) in enumerate(last_rows.iterrows()):
                summary_rows.append([f"Row {len(new_df)-row_to_print+i}:", *row.tolist()])
                
        summary_rows.append(["----------", *dashs])
        summary_rows.append(["count:", *new_df.count().tolist()])
        summary_rows.append(["max:", *new_df.apply(lambda c: safe_stat(c, 'max')).tolist()])
        summary_rows.append(["min:", *new_df.apply(lambda c: safe_stat(c, 'min')).tolist()])
        summary_rows.append(["mean:", *new_df.apply(lambda c: safe_stat(c, 'mean')).tolist()])
        summary_rows.append(["std:", *new_df.apply(lambda c: safe_stat(c, 'std')).tolist()])
        summary_rows.append(["median:", *new_df.apply(lambda c: safe_stat(c, 'median')).tolist()])
        summary_rows.append(["mode:", *new_df.apply(lambda c: safe_stat(c, 'mode')).tolist()])
        summary_rows.append(["nan:", *new_df.isna().sum().tolist()])
        
        print(pd.DataFrame(summary_rows, columns=["column:", *headers]).to_string(index=False))
    else:
        print(df)