# Add this import at the top
from .printdata import inspect

# Add "inspect" and "printo" to your __all__ list
__all__ = [
    "inspect",
#    "printo",
#    "add_indicators",
 #   "clean_data",
    # ... rest of your exposed functions ...
]