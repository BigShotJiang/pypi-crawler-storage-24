"""Core framework APIs."""
