"""Agent internals."""
