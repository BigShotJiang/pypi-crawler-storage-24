import asyncio
from functools import wraps, partial


async def async_parallel(func, args):
    """Run async function calls in parallel using asyncio.gather."""
    return await asyncio.gather(*[func(arg) for arg in args])


async def async_serial(func, args):
    """Run async function calls sequentially, awaiting each before the next."""
    return [await func(arg) for arg in args]


def async_wrap(func):
    """Decorator to wrap a synchronous function for async execution via executor."""
    @wraps(func)
    async def run(*args, loop=None, executor=None, sem=None, **kwargs):
        if loop is None:
            loop = asyncio.get_running_loop()
        pfunc = partial(func, *args, **kwargs)
        if sem is not None:
            async with sem:
                return await loop.run_in_executor(executor, pfunc)
        else:
            return await loop.run_in_executor(executor, pfunc)
    return run
