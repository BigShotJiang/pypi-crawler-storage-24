import logging
from typing import Optional

logger = logging.getLogger(__name__)


class InstanceService:
    """
    MDS instance-scoped reads via session auth.

    All methods send instance context via HTTP headers (Dwinstancename /
    Tenantname).  Call ``client.working_instance`` to set the target instance,
    or pass *instance_name* to each method.

    Endpoints covered:
      GET /mds/api/v1/configuration        (Redshift DB config)
      GET /mds/api/v1/rules                (data quality rules)
      GET /mds/api/v1/rule/groups          (rule groups)
      GET /mds/api/v1/jobs                 (job definitions)
      GET /mds/api/v1/connectors           (data connectors)
      GET /mds/api/v1/workspaces           (user workspaces)
      GET /mds/api/v1/process-steps        (ETL process steps)
      GET /mds/api/v1/outbound-connectors  (outbound connector configs)
      GET /mds/api/v1/scheduled-jobs       (MDS scheduled jobs)
      GET /mds/api/v1/file-triggers        (MDS file triggers)
      GET /mds/api/v1/orchestrations       (MDS orchestrations)
    """

    def __init__(self, client):
        self.client = client

    # ------------------------------------------------------------------
    # Configuration
    # ------------------------------------------------------------------

    def get_configuration(self, instance_name: Optional[str] = None) -> dict:
        """
        GET /mds/api/v1/configuration?view=condensed

        Returns Redshift DB config, including ``instanceDatabase.database``
        and ``clusterEndpoint``.
        """
        self._set_instance(instance_name)
        return self.client.api_call(
            "/mds/api/v1/configuration",
            params={"view": "condensed"},
            headers=self._instance_headers(),
        )

    # ------------------------------------------------------------------
    # Rules
    # ------------------------------------------------------------------

    def get_rules(self, instance_name: Optional[str] = None) -> dict:
        """GET /mds/api/v1/rules — data quality rules."""
        self._set_instance(instance_name)
        return self.client.api_call(
            "/mds/api/v1/rules",
            headers=self._instance_headers(),
        )

    def get_rule_groups(self, instance_name: Optional[str] = None) -> dict:
        """GET /mds/api/v1/rule/groups — rule groups."""
        self._set_instance(instance_name)
        return self.client.api_call(
            "/mds/api/v1/rule/groups",
            headers=self._instance_headers(),
        )

    # ------------------------------------------------------------------
    # Jobs
    # ------------------------------------------------------------------

    def get_jobs(
        self, instance_name: Optional[str] = None, view: str = "condensed"
    ) -> dict:
        """GET /mds/api/v1/jobs — job definitions."""
        self._set_instance(instance_name)
        return self.client.api_call(
            "/mds/api/v1/jobs",
            params={"view": view},
            headers=self._instance_headers(),
        )

    # ------------------------------------------------------------------
    # Connectors
    # ------------------------------------------------------------------

    def get_connectors(
        self, instance_name: Optional[str] = None, internal_only: bool = False
    ) -> dict:
        """GET /mds/api/v1/connectors — data connectors."""
        self._set_instance(instance_name)
        return self.client.api_call(
            "/mds/api/v1/connectors",
            params={"internalOnly": str(internal_only).lower()},
            headers=self._instance_headers(),
        )

    # ------------------------------------------------------------------
    # Workspaces
    # ------------------------------------------------------------------

    def get_workspaces(self, instance_name: Optional[str] = None) -> dict:
        """GET /mds/api/v1/workspaces — user workspaces for this instance."""
        self._set_instance(instance_name)
        return self.client.api_call(
            "/mds/api/v1/workspaces",
            headers=self._instance_headers(connector=True),
        )

    # ------------------------------------------------------------------
    # Process steps
    # ------------------------------------------------------------------

    def get_process_steps(self, instance_name: Optional[str] = None) -> dict:
        """GET /mds/api/v1/process-steps — ETL process step definitions."""
        self._set_instance(instance_name)
        return self.client.api_call(
            "/mds/api/v1/process-steps",
            headers=self._instance_headers(),
        )

    # ------------------------------------------------------------------
    # Outbound connectors
    # ------------------------------------------------------------------

    def get_outbound_connectors(self, instance_name: Optional[str] = None) -> dict:
        """GET /mds/api/v1/outbound-connectors — outbound connector configurations."""
        self._set_instance(instance_name)
        return self.client.api_call(
            "/mds/api/v1/outbound-connectors",
            headers=self._instance_headers(),
        )

    # ------------------------------------------------------------------
    # Scheduled jobs & triggers
    # ------------------------------------------------------------------

    def get_scheduled_jobs(self, instance_name: Optional[str] = None) -> dict:
        """GET /mds/api/v1/scheduled-jobs — scheduled job definitions for this instance."""
        self._set_instance(instance_name)
        return self.client.api_call(
            "/mds/api/v1/scheduled-jobs",
            headers=self._instance_headers(),
        )

    def get_file_triggers(self, instance_name: Optional[str] = None) -> dict:
        """GET /mds/api/v1/file-triggers — file-based job triggers for this instance."""
        self._set_instance(instance_name)
        return self.client.api_call(
            "/mds/api/v1/file-triggers",
            headers=self._instance_headers(),
        )

    # ------------------------------------------------------------------
    # Orchestrations
    # ------------------------------------------------------------------

    def get_orchestrations(self, instance_name: Optional[str] = None) -> dict:
        """GET /mds/api/v1/orchestrations — orchestration definitions for this instance."""
        self._set_instance(instance_name)
        return self.client.api_call(
            "/mds/api/v1/orchestrations",
            headers=self._instance_headers(),
        )

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    def _set_instance(self, instance_name: Optional[str]) -> None:
        if instance_name:
            self.client.working_instance = instance_name

    def _instance_headers(self, connector: bool = False) -> dict:
        h = {
            "Authorization": self.client.access_token or "",
            "Dwinstancename": self.client.working_instance or "",
            "Tenantname": self.client.tenant_name or "",
        }
        if connector:
            h["Connectorname"] = self.client.connector_name
        return h
