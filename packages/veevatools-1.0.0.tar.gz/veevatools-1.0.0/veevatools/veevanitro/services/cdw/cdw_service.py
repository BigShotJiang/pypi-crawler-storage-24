import logging
from typing import Optional
from urllib.parse import quote_plus

logger = logging.getLogger(__name__)


class CDWService:
    """
    CDW (Cloud Data Warehouse) — Redshift database and workspace connections.

    Wraps the Nitro workspace API and provides helpers for connecting to
    Redshift via psycopg2 or SQLAlchemy.  Heavy dependencies are imported
    lazily so the library can be used without them.

    Typical flow::

        n.cdw.initialize()                  # fetch cluster config
        n.cdw.get_redshift_connection(       # connect to Redshift
            redshift_user="...",
            redshift_password="...",
        )
    """

    def __init__(self, client):
        self.client = client

        self.cluster_config: Optional[dict] = None
        self.working_db: Optional[str] = None
        self.redshift_port: str = "5439"

        self.working_redshift_user: Optional[str] = None
        self.working_redshift_pwd: Optional[str] = None
        self.working_db_connection = None     # psycopg2 connection
        self.working_db_cursor = None         # psycopg2 cursor
        self.working_sqlalchemy_engine = None

    # ------------------------------------------------------------------
    # Initialize — fetch cluster config
    # ------------------------------------------------------------------

    def initialize(
        self,
        instance_name: Optional[str] = None,
        redshift_password: Optional[str] = None,
    ) -> dict:
        """
        Fetch cluster configuration for the working instance.

        Makes two calls:
        - ``GET /mds/api/v1/configuration`` → database name
        - ``GET /api/v1/admin/cluster/configuration`` → clusterEndpoint

        Populates ``cluster_config`` (merged from both), ``working_db``.
        Should be called once after login before attempting DB connections.

        Args:
            instance_name: Override working instance.
            redshift_password: Redshift password.  Defaults to
                ``client.password`` (the Nitro login password, which is
                also the Redshift password for most setups).
        """
        if instance_name:
            self.client.working_instance = instance_name

        instance_headers = {
            "Authorization": self.client.access_token or "",
            "Dwinstancename": self.client.working_instance or "",
            "Tenantname": self.client.tenant_name or "",
        }

        # 1. MDS instance config → database name
        mds_resp = self.client.api_call(
            "/mds/api/v1/configuration",
            params={"view": "condensed"},
            headers=instance_headers,
        )

        self.cluster_config = mds_resp.get("content", {})
        db_info = self.cluster_config.get("instanceDatabase", {})
        self.working_db = db_info.get("database")

        # 2. Admin cluster config → clusterEndpoint (different endpoint)
        try:
            cluster_resp = self.client.api_call("/api/v1/admin/cluster/configuration")
            cluster_content = cluster_resp.get("content", {})
            if "clusterEndpoint" in cluster_content:
                self.cluster_config["clusterEndpoint"] = cluster_content["clusterEndpoint"]
            # Preserve any other useful fields
            for key in ("clusterId", "platform", "port"):
                if key in cluster_content:
                    self.cluster_config[key] = cluster_content[key]
        except Exception as exc:
            logger.warning("Could not fetch cluster/configuration: %s", exc)

        self.working_redshift_pwd = redshift_password or self.client.password
        logger.info(
            "CDW initialized | instance=%s | db=%s | endpoint=%s",
            self.client.working_instance,
            self.working_db,
            self.cluster_config.get("clusterEndpoint", "N/A"),
        )
        return mds_resp

    # ------------------------------------------------------------------
    # Redshift — psycopg2
    # ------------------------------------------------------------------

    def get_db_connection(
        self,
        redshift_user: Optional[str] = None,
        redshift_password: Optional[str] = None,
    ):
        """
        Establish and return a psycopg2 connection to Redshift.

        Requires ``initialize()`` to have been called (needs ``cluster_config``
        and ``working_db``).

        Args:
            redshift_user: Redshift username (the ``redshiftUserName`` field
                from the users list).
            redshift_password: Redshift password.
        """
        try:
            import psycopg2
        except ImportError as exc:
            raise ImportError(
                "psycopg2 is required for Redshift connections. "
                "Install with: pip install psycopg2-binary"
            ) from exc

        if redshift_user:
            self.working_redshift_user = redshift_user
        if redshift_password:
            self.working_redshift_pwd = redshift_password

        self._require_cluster_config()

        conn = psycopg2.connect(
            dbname=self.working_db,
            host=self.cluster_config["clusterEndpoint"],
            port=self.redshift_port,
            user=self.working_redshift_user,
            password=self.working_redshift_pwd,
        )
        conn.autocommit = True
        self.working_db_connection = conn
        logger.info("Redshift connection established to %s", self.working_db)
        return conn

    def get_db_cursor(self, connection=None):
        """Return a RealDictCursor from the given (or working) connection."""
        try:
            from psycopg2.extras import RealDictCursor
        except ImportError as exc:
            raise ImportError("psycopg2 is required.") from exc

        conn = connection or self.working_db_connection
        if conn is None:
            raise ValueError("No connection. Call get_db_connection() first.")

        cursor = conn.cursor(cursor_factory=RealDictCursor)
        self.working_db_cursor = cursor
        return cursor

    def close_db_connection(self, connection=None) -> None:
        """Close the given (or working) psycopg2 connection."""
        conn = connection or self.working_db_connection
        if conn is None:
            raise ValueError("No connection to close.")
        conn.close()
        if conn is self.working_db_connection:
            self.working_db_connection = None

    # ------------------------------------------------------------------
    # Redshift — SQLAlchemy
    # ------------------------------------------------------------------

    def get_sqlalchemy_engine(
        self,
        redshift_user: Optional[str] = None,
        redshift_password: Optional[str] = None,
    ):
        """
        Create and return a SQLAlchemy engine for Redshift.

        Requires ``initialize()`` to have been called.
        """
        try:
            from sqlalchemy import create_engine
        except ImportError as exc:
            raise ImportError(
                "sqlalchemy is required. Install with: pip install sqlalchemy"
            ) from exc

        if redshift_user:
            self.working_redshift_user = redshift_user
        if redshift_password:
            self.working_redshift_pwd = redshift_password

        self._require_cluster_config()

        url = "postgresql+psycopg2://{user}:{pwd}@{host}:{port}/{db}".format(
            user=quote_plus(self.working_redshift_user or ""),
            pwd=quote_plus(self.working_redshift_pwd or ""),
            host=self.cluster_config["clusterEndpoint"],
            port=self.redshift_port,
            db=self.working_db,
        )
        engine = create_engine(url, echo=False)
        self.working_sqlalchemy_engine = engine
        return engine

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    def _require_cluster_config(self) -> None:
        if not self.cluster_config or "clusterEndpoint" not in self.cluster_config:
            raise ValueError(
                "cluster_config missing or incomplete. "
                "Call cdw.initialize() first."
            )
