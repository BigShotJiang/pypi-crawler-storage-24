import os
import logging
import requests
from typing import Optional

logger = logging.getLogger(__name__)


class AuthService:
    """
    Authentication and token management for the Veeva Nitro API.

    Endpoints covered:
      POST /api/v1/auth/login
      POST /api/v1/users/tokens/renew
      POST /api/v1/users/tokens/issue
      GET  /api/v1/download/cli
      GET  /api/v1/download/sdk
    """

    def __init__(self, client):
        self.client = client

    # ------------------------------------------------------------------
    # Login
    # ------------------------------------------------------------------

    def login(
        self,
        server_url: Optional[str] = None,
        username: Optional[str] = None,
        password: Optional[str] = None,
        access_token: Optional[str] = None,
    ) -> dict:
        """
        Authenticate with the Nitro API.

        If *access_token* is supplied the token is validated via
        ``GET /api/v1/admin/tenant`` (no password needed).
        Otherwise performs ``POST /api/v1/auth/login`` with username/password.

        On success, populates the following client attributes:
          ``access_token``, ``refresh_token``, ``tenant_name``,
          ``tenant_instances``, ``tenant_roles``, ``instance_roles``,
          ``instance_permissions``, ``app_server_url``.

        Sets ``working_instance`` to the first available instance if not
        already set.
        """
        if server_url:
            self.client.server_url = server_url.rstrip("/")
        if username:
            self.client.username = username
        if password:
            self.client.password = password
        if access_token:
            self.client.access_token = access_token

        if not self.client.server_url:
            raise ValueError("server_url is required")

        if self.client.access_token:
            # Validate existing token
            response = requests.get(
                f"{self.client.server_url}/api/v1/admin/tenant",
                headers={"Authorization": self.client.access_token},
            )
        else:
            if not (self.client.username and self.client.password):
                raise ValueError(
                    "username and password are required when no access_token is provided"
                )
            response = requests.post(
                f"{self.client.server_url}/api/v1/auth/login",
                json={
                    "username": self.client.username,
                    "password": self.client.password,
                },
            )

        response.raise_for_status()
        data = response.json()

        self.client.access_token = data.get("accessToken", self.client.access_token)
        self.client.refresh_token = data.get("refreshToken")
        self.client.app_server_url = data.get("appServerUrl")
        self.client.tenant_name = data.get("tenantName")
        self.client.tenant_instances = data.get("instances", [])
        self.client.tenant_roles = data.get("tenantRoles", [])
        self.client.instance_roles = data.get("instanceRoles", [])
        self.client.instance_permissions = data.get("instancePermissions")

        if self.client.tenant_instances and not self.client.working_instance:
            self.client.working_instance = self.client.tenant_instances[0].get(
                "instanceName"
            )

        logger.info(
            "Logged in as %s | tenant=%s | instance=%s",
            self.client.username,
            self.client.tenant_name,
            self.client.working_instance,
        )
        return data

    # ------------------------------------------------------------------
    # Token management
    # ------------------------------------------------------------------

    def renew_token(self) -> dict:
        """
        Renew the session token.  POST /api/v1/users/tokens/renew.

        Uses ``refreshToken`` header.  Updates ``client.access_token``
        on success.
        """
        if not self.client.refresh_token:
            raise RuntimeError("No refresh token. Call login() first.")

        response = requests.post(
            f"{self.client.server_url}/api/v1/users/tokens/renew",
            headers={"refreshToken": self.client.refresh_token},
        )
        response.raise_for_status()
        data = response.json()

        new_token = data.get("accessToken")
        if new_token:
            self.client.access_token = new_token
            logger.debug("Access token renewed")

        return data

    def issue_cdw_token(self) -> dict:
        """
        Issue a CDW API key token.  POST /api/v1/users/tokens/issue.

        Stores the token on ``client.cdw_api_token``.  Must be called
        before any ``cdw_call()``-backed service methods (ETL, MDS write ops).
        """
        data = self.client.api_call("/api/v1/users/tokens/issue", method="POST")

        token = (
            data.get("content", {}).get("token")
            or data.get("token")
        )
        if token:
            self.client.cdw_api_token = token
            logger.debug("CDW API token issued")
        else:
            logger.warning(
                "issue_cdw_token: could not extract token from response: %s", data
            )

        return data

    # ------------------------------------------------------------------
    # Downloads
    # ------------------------------------------------------------------

    def download_cli(self, save_path: str = "cdw-cli") -> bytes:
        """Download the Nitro CLI zip.  GET /api/v1/download/cli."""
        response = self.client.api_call("/api/v1/download/cli", raw_response=True)
        response.raise_for_status()
        with open(save_path, "wb") as f:
            f.write(response.content)
        logger.info("CLI downloaded to %s", os.path.abspath(save_path))
        return response.content

    def download_sdk(self, save_path: str = "nitro_sdk_latest.whl") -> bytes:
        """Download the Nitro SDK wheel.  GET /api/v1/download/sdk."""
        response = self.client.api_call("/api/v1/download/sdk", raw_response=True)
        response.raise_for_status()
        with open(save_path, "wb") as f:
            f.write(response.content)
        logger.info("SDK downloaded to %s", os.path.abspath(save_path))
        return response.content
