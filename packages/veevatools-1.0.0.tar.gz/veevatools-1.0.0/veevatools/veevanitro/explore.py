"""
Live endpoint exploration script for veevanitro.

Reads credentials from credentials.json and tests each known endpoint
against the live Nitro instance.

Usage (from the veevatools/ project root):
    python -m veevanitro.explore

Write-op tests (ETL run, MDS upload) are OFF by default.
Set TEST_WRITE_OPS=True to enable them (use with care).
"""
import json
import logging
import sys
from pathlib import Path

# ── Allow running as: python veevanitro/explore.py ────────────────────
sys.path.insert(0, str(Path(__file__).parent.parent))

from veevatools.veevanitro import Nitro

logging.basicConfig(level=logging.INFO, format="%(levelname)s %(name)s: %(message)s")
log = logging.getLogger("explore")

# Set True to test write operations (ETL job execution, MDS package ops)
TEST_WRITE_OPS = False

CREDS_FILE = Path(__file__).parent / "credentials.json"


def section(title: str) -> None:
    print(f"\n{'='*60}")
    print(f"  {title}")
    print(f"{'='*60}")


def ok(label: str, data) -> None:
    preview = json.dumps(data, indent=2) if isinstance(data, dict) else str(data)
    if len(preview) > 400:
        preview = preview[:400] + "\n  ...(truncated)"
    print(f"  [OK] {label}\n{preview}")


def fail(label: str, exc: Exception) -> None:
    print(f"  [FAIL] {label}: {exc}")


def main():
    creds = json.loads(CREDS_FILE.read_text())
    n = Nitro()

    # ------------------------------------------------------------------
    # AUTH
    # ------------------------------------------------------------------
    section("AUTH: login")
    try:
        resp = n.auth.login(creds["url"], creds["username"], creds["password"])
        print(f"  tenant_name     : {n.client.tenant_name}")
        print(f"  working_instance: {n.client.working_instance}")
        print(f"  instances       : {[i.get('instanceName') for i in n.client.tenant_instances]}")
        print(f"  access_token    : {(n.client.access_token or '')[:30]}...")
    except Exception as e:
        fail("login", e)
        sys.exit(1)

    section("AUTH: issue_cdw_token")
    try:
        resp = n.auth.issue_cdw_token()
        cdw_preview = (n.client.cdw_api_token or "")[:30]
        print(f"  cdw_api_token: {cdw_preview}...")
        print(f"  raw response keys: {list(resp.keys())}")
    except Exception as e:
        fail("issue_cdw_token", e)

    # ------------------------------------------------------------------
    # ADMIN
    # ------------------------------------------------------------------
    section("ADMIN: get_tenant")
    try:
        ok("get_tenant", n.admin.get_tenant())
    except Exception as e:
        fail("get_tenant", e)

    section("ADMIN: get_cluster_configuration")
    try:
        ok("get_cluster_configuration", n.admin.get_cluster_configuration())
    except Exception as e:
        fail("get_cluster_configuration", e)

    section("ADMIN: get_cluster_details")
    try:
        ok("get_cluster_details", n.admin.get_cluster_details())
    except Exception as e:
        fail("get_cluster_details", e)

    section("ADMIN: get_users")
    try:
        resp = n.admin.get_users()
        users = resp.get("content", resp)
        count = len(users) if isinstance(users, list) else "?"
        print(f"  [OK] get_users: {count} users")
        if isinstance(users, list) and users:
            print(f"  First user keys: {list(users[0].keys())}")
    except Exception as e:
        fail("get_users", e)

    section("ADMIN: get_application_roles")
    try:
        ok("get_application_roles", n.admin.get_application_roles())
    except Exception as e:
        fail("get_application_roles", e)

    section("ADMIN: get_job_results")
    try:
        ok("get_job_results", n.admin.get_job_results(size=5))
    except Exception as e:
        fail("get_job_results", e)

    section("ADMIN: get_identity_providers")
    try:
        ok("get_identity_providers", n.admin.get_identity_providers())
    except Exception as e:
        fail("get_identity_providers", e)

    section("ADMIN: get_user_pools")
    try:
        ok("get_user_pools", n.admin.get_user_pools())
    except Exception as e:
        fail("get_user_pools", e)

    section("ADMIN: get_ftp_users")
    try:
        ok("get_ftp_users", n.admin.get_ftp_users())
    except Exception as e:
        fail("get_ftp_users", e)

    section("ADMIN: get_application_users")
    try:
        ok("get_application_users", n.admin.get_application_users())
    except Exception as e:
        fail("get_application_users", e)

    section("ADMIN: get_security_report")
    try:
        ok("get_security_report", n.admin.get_security_report())
    except Exception as e:
        fail("get_security_report", e)

    section("ADMIN: get_scheduler")
    try:
        ok("get_scheduler", n.admin.get_scheduler())
    except Exception as e:
        fail("get_scheduler", e)

    section("ADMIN: get_scheduled_jobs (admin)")
    try:
        ok("get_scheduled_jobs", n.admin.get_scheduled_jobs())
    except Exception as e:
        fail("get_scheduled_jobs", e)

    section("ADMIN: get_file_triggers (admin)")
    try:
        ok("get_file_triggers", n.admin.get_file_triggers())
    except Exception as e:
        fail("get_file_triggers", e)

    section("ADMIN: get_orchestrations (admin)")
    try:
        ok("get_orchestrations", n.admin.get_orchestrations())
    except Exception as e:
        fail("get_orchestrations", e)

    section("ADMIN: get_files")
    try:
        ok("get_files", n.admin.get_files())
    except Exception as e:
        fail("get_files", e)

    section("ADMIN: get_schemas")
    try:
        ok("get_schemas", n.admin.get_schemas())
    except Exception as e:
        fail("get_schemas", e)

    section("ADMIN: get_usage_metrics")
    try:
        ok("get_usage_metrics", n.admin.get_usage_metrics())
    except Exception as e:
        fail("get_usage_metrics", e)

    # ------------------------------------------------------------------
    # INSTANCE (MDS reads)
    # ------------------------------------------------------------------
    section("INSTANCE: get_configuration")
    try:
        ok("get_configuration", n.instance.get_configuration())
    except Exception as e:
        fail("get_configuration", e)

    section("INSTANCE: get_rules")
    try:
        resp = n.instance.get_rules()
        items = resp.get("content", resp)
        print(f"  [OK] get_rules: {len(items) if isinstance(items, list) else '?'} rules")
    except Exception as e:
        fail("get_rules", e)

    section("INSTANCE: get_rule_groups")
    try:
        ok("get_rule_groups", n.instance.get_rule_groups())
    except Exception as e:
        fail("get_rule_groups", e)

    section("INSTANCE: get_jobs")
    try:
        resp = n.instance.get_jobs()
        items = resp.get("content", resp)
        count = len(items) if isinstance(items, list) else "?"
        print(f"  [OK] get_jobs: {count} jobs")
        if isinstance(items, list) and items:
            print(f"  First job keys: {list(items[0].keys())}")
    except Exception as e:
        fail("get_jobs", e)

    section("INSTANCE: get_connectors")
    try:
        ok("get_connectors", n.instance.get_connectors())
    except Exception as e:
        fail("get_connectors", e)

    section("INSTANCE: get_workspaces")
    try:
        ok("get_workspaces", n.instance.get_workspaces())
    except Exception as e:
        fail("get_workspaces", e)

    section("INSTANCE: get_process_steps")
    try:
        ok("get_process_steps", n.instance.get_process_steps())
    except Exception as e:
        fail("get_process_steps", e)

    section("INSTANCE: get_outbound_connectors")
    try:
        ok("get_outbound_connectors", n.instance.get_outbound_connectors())
    except Exception as e:
        fail("get_outbound_connectors", e)

    section("INSTANCE: get_scheduled_jobs (MDS)")
    try:
        ok("get_scheduled_jobs", n.instance.get_scheduled_jobs())
    except Exception as e:
        fail("get_scheduled_jobs", e)

    section("INSTANCE: get_file_triggers (MDS)")
    try:
        ok("get_file_triggers", n.instance.get_file_triggers())
    except Exception as e:
        fail("get_file_triggers", e)

    section("INSTANCE: get_orchestrations (MDS)")
    try:
        ok("get_orchestrations", n.instance.get_orchestrations())
    except Exception as e:
        fail("get_orchestrations", e)

    # ------------------------------------------------------------------
    # CDW — initialize (reads cluster config)
    # ------------------------------------------------------------------
    section("CDW: initialize")
    try:
        resp = n.cdw.initialize()
        print(f"  working_db      : {n.cdw.working_db}")
        print(f"  clusterEndpoint : {(n.cdw.cluster_config or {}).get('clusterEndpoint', 'N/A')}")
    except Exception as e:
        fail("cdw.initialize", e)

    # ------------------------------------------------------------------
    # MDS downloads (read-only — safe to run)
    # ------------------------------------------------------------------
    section("MDS: download_package")
    try:
        n.mds.download_package("/tmp/nitro_package.zip")
        size = Path("/tmp/nitro_package.zip").stat().st_size
        print(f"  [OK] package downloaded to /tmp/nitro_package.zip ({size:,} bytes)")
    except Exception as e:
        fail("download_package", e)

    section("MDS: download_translations")
    try:
        n.mds.download_translations("/tmp/nitro_translations.csv")
        size = Path("/tmp/nitro_translations.csv").stat().st_size
        print(f"  [OK] translations downloaded to /tmp/nitro_translations.csv ({size:,} bytes)")
    except Exception as e:
        fail("download_translations", e)

    # ------------------------------------------------------------------
    # TRUE WRITE OPS (disabled by default — modify data)
    # ------------------------------------------------------------------
    if TEST_WRITE_OPS:
        section("ETL: run_job  [WRITE OP — triggers job execution]")
        try:
            # Replace with a real job name from get_jobs() output above
            job_name = "YOUR_JOB_NAME_HERE"
            ok("run_job", n.etl.run_job(job_name))
        except Exception as e:
            fail("run_job", e)

        section("ETL: run_task_sequence  [WRITE OP — triggers execution]")
        try:
            seq_name = "YOUR_TASK_SEQUENCE_NAME_HERE"
            ok("run_task_sequence", n.etl.run_task_sequence(seq_name))
        except Exception as e:
            fail("run_task_sequence", e)
    else:
        print("\n  [INFO] ETL trigger tests skipped (set TEST_WRITE_OPS=True to enable).")

    section("DONE")


if __name__ == "__main__":
    main()
