"""Veeva Network v37 API client library."""

from .client import NetworkClient
from .exceptions import AuthenticationError, NetworkAPIError

__all__ = [
    "NetworkClient",
    "NetworkAPIError",
    "AuthenticationError",
    "Vn",
]


class Vn:
    """Deprecated legacy class. Use :class:`NetworkClient` instead."""

    def __init__(self, *args, **kwargs):
        import warnings

        warnings.warn(
            "Vn is deprecated, use NetworkClient + services instead. "
            "See: from veevanetwork import NetworkClient",
            DeprecationWarning,
            stacklevel=2,
        )
