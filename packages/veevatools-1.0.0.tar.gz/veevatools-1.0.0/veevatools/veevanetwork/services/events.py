"""Veeva Network events service."""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from ..client import NetworkClient


class EventsService:
    """Retrieve merge and unmerge events from the Network instance."""

    def __init__(self, client: NetworkClient):
        self.client = client

    def retrieve_merge_events(
        self,
        *,
        since_date: str | None = None,
        offset: int | None = None,
        limit: int | None = None,
    ) -> dict:
        """Retrieve merge events.

        ``GET /api/{v}/event/merge``
        """
        params = {}
        if since_date is not None:
            params["sinceDate"] = since_date
        if offset is not None:
            params["offset"] = str(offset)
        if limit is not None:
            params["limit"] = str(limit)
        return self.client.api_call("event/merge", params=params or None)

    def retrieve_unmerge_events(
        self,
        *,
        since_date: str | None = None,
        offset: int | None = None,
        limit: int | None = None,
    ) -> dict:
        """Retrieve unmerge events.

        ``GET /api/{v}/event/unmerge``
        """
        params = {}
        if since_date is not None:
            params["sinceDate"] = since_date
        if offset is not None:
            params["offset"] = str(offset)
        if limit is not None:
            params["limit"] = str(limit)
        return self.client.api_call("event/unmerge", params=params or None)
