"""Veeva Network subscription service."""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from ..client import NetworkClient


class SubscriptionService:
    """Subscription job management for all four types: general, compliance,
    source, and target subscriptions."""

    def __init__(self, client: NetworkClient):
        self.client = client

    # ------------------------------------------------------------------
    # General subscriptions
    # ------------------------------------------------------------------

    def create_job(
        self,
        subscription_name: str,
        *,
        data_revision_first: str | None = None,
        data_revision_last: str | None = None,
        apply_data_revisions_for_delta_export_only: bool | None = None,
        export_archive: bool | None = None,
        mode: str | None = None,
    ) -> dict:
        """Create a subscription job.

        ``POST /api/{v}/subscription/{subscription_name}/job``
        """
        params = {}
        if data_revision_first is not None:
            params["data_revision_first"] = data_revision_first
        if data_revision_last is not None:
            params["data_revision_last"] = data_revision_last
        if apply_data_revisions_for_delta_export_only is not None:
            params["apply_data_revisions_for_delta_export_only"] = str(
                apply_data_revisions_for_delta_export_only
            ).lower()
        if export_archive is not None:
            params["export_archive"] = str(export_archive).lower()
        if mode is not None:
            params["mode"] = mode
        return self.client.api_call(
            f"subscription/{subscription_name}/job",
            method="POST",
            params=params or None,
        )

    def retrieve_job(self, job_id: str) -> dict:
        """Retrieve subscription job status.

        ``GET /api/{v}/job/{job_id}``
        """
        return self.client.api_call(f"job/{job_id}")

    def cancel_job(self, job_id: str) -> dict:
        """Cancel a subscription job.

        ``DELETE /api/{v}/job/{job_id}``
        """
        return self.client.api_call(f"job/{job_id}", method="DELETE")

    def retrieve_export_file(
        self,
        job_id: str,
        file_name: str,
    ) -> bytes:
        """Retrieve export job file contents.

        ``GET /api/{v}/artifact/job/{job_id}/{file_name}``

        Returns:
            Raw file bytes.
        """
        response = self.client.api_call(
            f"artifact/job/{job_id}/{file_name}", raw_response=True
        )
        return response.content

    # ------------------------------------------------------------------
    # Compliance subscriptions
    # ------------------------------------------------------------------

    def compliance_create_job(self, subscription_name: str) -> dict:
        """Create a compliance subscription job.

        ``POST /api/{v}/systems/compliance_subscriptions/{subscription_name}/job``
        """
        return self.client.api_call(
            f"systems/compliance_subscriptions/{subscription_name}/job", method="POST"
        )

    def compliance_retrieve_job(
        self, subscription_name: str, job_id: str
    ) -> dict:
        """Retrieve compliance subscription job status.

        ``GET /api/{v}/systems/compliance_subscriptions/{subscription_name}/job/{job_id}``
        """
        return self.client.api_call(
            f"systems/compliance_subscriptions/{subscription_name}/job/{job_id}"
        )

    def compliance_cancel_job(
        self, subscription_name: str, job_id: str
    ) -> dict:
        """Cancel a compliance subscription job.

        ``DELETE /api/{v}/systems/compliance_subscriptions/{subscription_name}/job/{job_id}``
        """
        return self.client.api_call(
            f"systems/compliance_subscriptions/{subscription_name}/job/{job_id}",
            method="DELETE",
        )

    # ------------------------------------------------------------------
    # Source subscriptions
    # ------------------------------------------------------------------

    def source_create_job(
        self,
        system_name: str,
        subscription_name: str,
        *,
        mode: str | None = None,
    ) -> dict:
        """Create a source subscription job.

        ``POST /api/{v}/systems/{system_name}/source_subscriptions/{subscription_name}/job``
        """
        params = {}
        if mode is not None:
            params["mode"] = mode
        return self.client.api_call(
            f"systems/{system_name}/source_subscriptions/{subscription_name}/job",
            method="POST",
            params=params or None,
        )

    def source_retrieve_job(
        self, system_name: str, subscription_name: str, job_id: str
    ) -> dict:
        """Retrieve source subscription job status.

        ``GET /api/{v}/systems/{system_name}/source_subscriptions/{subscription_name}/job/{job_id}``
        """
        return self.client.api_call(
            f"systems/{system_name}/source_subscriptions/{subscription_name}/job/{job_id}"
        )

    def source_cancel_job(
        self, system_name: str, subscription_name: str, job_id: str
    ) -> dict:
        """Cancel a source subscription job.

        ``DELETE /api/{v}/systems/{system_name}/source_subscriptions/{subscription_name}/job/{job_id}``
        """
        return self.client.api_call(
            f"systems/{system_name}/source_subscriptions/{subscription_name}/job/{job_id}",
            method="DELETE",
        )

    # ------------------------------------------------------------------
    # Target subscriptions
    # ------------------------------------------------------------------

    def target_create_job(
        self,
        system_name: str,
        subscription_name: str,
        *,
        data_revision_first: str | None = None,
        data_revision_last: str | None = None,
        apply_data_revisions_for_delta_export_only: bool | None = None,
        export_archive: bool | None = None,
    ) -> dict:
        """Create a target subscription job.

        ``POST /api/{v}/systems/{system_name}/target_subscriptions/{subscription_name}/job``
        """
        params = {}
        if data_revision_first is not None:
            params["data_revision_first"] = data_revision_first
        if data_revision_last is not None:
            params["data_revision_last"] = data_revision_last
        if apply_data_revisions_for_delta_export_only is not None:
            params["apply_data_revisions_for_delta_export_only"] = str(
                apply_data_revisions_for_delta_export_only
            ).lower()
        if export_archive is not None:
            params["export_archive"] = str(export_archive).lower()
        return self.client.api_call(
            f"systems/{system_name}/target_subscriptions/{subscription_name}/job",
            method="POST",
            params=params or None,
        )

    def target_retrieve_job(
        self, system_name: str, subscription_name: str, job_id: str
    ) -> dict:
        """Retrieve target subscription job status.

        ``GET /api/{v}/systems/{system_name}/target_subscriptions/{subscription_name}/job/{job_id}``
        """
        return self.client.api_call(
            f"systems/{system_name}/target_subscriptions/{subscription_name}/job/{job_id}"
        )

    def target_cancel_job(
        self, system_name: str, subscription_name: str, job_id: str
    ) -> dict:
        """Cancel a target subscription job.

        ``DELETE /api/{v}/systems/{system_name}/target_subscriptions/{subscription_name}/job/{job_id}``
        """
        return self.client.api_call(
            f"systems/{system_name}/target_subscriptions/{subscription_name}/job/{job_id}",
            method="DELETE",
        )
