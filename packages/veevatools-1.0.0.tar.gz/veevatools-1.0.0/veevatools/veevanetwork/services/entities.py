"""Veeva Network entity service."""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from ..client import NetworkClient


class EntityService:
    """Generic entity retrieval — works for any entity type (HCP, HCO, etc.)
    without requiring the caller to know the entity type in advance."""

    def __init__(self, client: NetworkClient):
        self.client = client

    def retrieve(
        self,
        vid_key: str,
        *,
        system_name: str | None = None,
        enriched_results: bool | None = None,
        result_language: str | None = None,
        return_hashtags_for_type: str | None = None,
    ) -> dict:
        """Retrieve any entity by VID or custom key.

        ``GET /api/{v}/entity/{vid_key}``
        """
        params = {}
        if system_name is not None:
            params["systemName"] = system_name
        if enriched_results is not None:
            params["enrichedResults"] = str(enriched_results).lower()
        if result_language is not None:
            params["resultLanguage"] = result_language
        if return_hashtags_for_type is not None:
            params["returnHashtagsForType"] = return_hashtags_for_type
        return self.client.api_call(f"entity/{vid_key}", params=params or None)

    def retrieve_child(
        self,
        vid_key: str,
        *,
        system_name: str | None = None,
        enriched_results: bool | None = None,
        result_language: str | None = None,
    ) -> dict:
        """Retrieve a child entity (address, license, etc.) by VID.

        ``GET /api/{v}/child/{vid_key}``
        """
        params = {}
        if system_name is not None:
            params["systemName"] = system_name
        if enriched_results is not None:
            params["enrichedResults"] = str(enriched_results).lower()
        if result_language is not None:
            params["resultLanguage"] = result_language
        return self.client.api_call(f"child/{vid_key}", params=params or None)

    def batch_retrieve(self, body: dict) -> dict:
        """Retrieve multiple entities.

        ``POST /api/{v}/entities/batch``
        """
        return self.client.api_call("entities/batch", method="POST", json_body=body)

    def batch_retrieve_children(self, body: dict) -> dict:
        """Retrieve multiple child entities.

        ``POST /api/{v}/children/batch``
        """
        return self.client.api_call("children/batch", method="POST", json_body=body)
