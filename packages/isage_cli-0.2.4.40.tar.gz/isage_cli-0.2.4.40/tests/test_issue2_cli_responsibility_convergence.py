"""Regression tests for issue #2: CLI layer responsibility convergence.

Verifies that:
1. Module-level compatibility fallbacks (try/except ImportError → None) are absent
   from CLI command modules and utility modules.
2. Stale refactoring artifacts are absent from the package tree.
3. check_environment_status() no longer carries a dotenv availability flag (python-dotenv
   is now a hard dependency, not optional).
"""

from __future__ import annotations

import ast
from pathlib import Path

SAGE_CLI_SRC = Path(__file__).parent.parent / "src" / "sage" / "cli"


def _source(rel: str) -> str:
    return (SAGE_CLI_SRC / rel).read_text(encoding="utf-8")


# ---------------------------------------------------------------------------
# 1. No module-level compat shims in llm.py
# ---------------------------------------------------------------------------


def test_issue2_llm_no_module_level_sagellm_fallback() -> None:
    """llm.py must not assign ControlPlaneManager/EngineInfo/EngineState to None."""
    src = _source("commands/apps/llm.py")
    # None-assignment compatibility shim pattern must be gone
    assert "ControlPlaneManager = None" not in src
    assert "EngineInfo = None" not in src
    assert "EngineState = None" not in src
    assert "_gateway_create_app = None" not in src
    assert "_SAGELLM_GATEWAY_AVAILABLE" not in src
    assert "_check_sagellm_available" not in src


def test_issue2_llm_no_migration_note() -> None:
    """llm.py must not carry stale MIGRATION NOTE comments in its docstring."""
    src = _source("commands/apps/llm.py")
    assert "MIGRATION NOTE" not in src


# ---------------------------------------------------------------------------
# 2. No module-level compat shims in pipeline.py
# ---------------------------------------------------------------------------


def test_issue2_pipeline_no_module_level_openai_fallback() -> None:
    """pipeline.py must not define OPENAI_AVAILABLE or OPENAI_IMPORT_ERROR globals."""
    src = _source("commands/apps/pipeline.py")
    assert "OPENAI_AVAILABLE" not in src
    assert "OPENAI_IMPORT_ERROR" not in src
    # The fallback sentinel assignment must be gone
    assert "UnifiedInferenceClient = object" not in src


def test_issue2_pipeline_unified_client_imported_at_call_site() -> None:
    """UnifiedInferenceClient import must appear inside methods, not at module level."""
    src = _source("commands/apps/pipeline.py")
    tree = ast.parse(src)
    for node in ast.walk(tree):
        if isinstance(node, ast.ImportFrom) and node.module == "isagellm":
            # Any isagellm import must be nested inside a function/method body,
            # not at the module level (col_offset == 0 signals a top-level statement).
            assert node.col_offset > 0, (
                "isagellm import must be inside a function, not at module level (col_offset=0)"
            )


# ---------------------------------------------------------------------------
# 3. env.py: direct dotenv import, no None guard
# ---------------------------------------------------------------------------


def test_issue2_env_dotenv_direct_import() -> None:
    """env.py must import load_dotenv directly (no try/except ImportError)."""
    src = _source("utils/env.py")
    assert "from dotenv import load_dotenv" in src
    assert "load_dotenv = None" not in src
    assert "dotenv_available" not in src


def test_issue2_env_no_dotenv_none_guard() -> None:
    """env.py must not contain a runtime None-guard for load_dotenv."""
    src = _source("utils/env.py")
    assert "if load_dotenv is None" not in src


# ---------------------------------------------------------------------------
# 4. Stale artifact files deleted
# ---------------------------------------------------------------------------


def test_issue2_config_refactored_deleted() -> None:
    """core/config_refactored.py must not exist (stale refactoring artifact)."""
    assert not (SAGE_CLI_SRC / "core" / "config_refactored.py").exists()


def test_issue2_refactor_example_deleted() -> None:
    """core/refactor_example.py must not exist (stale example artifact)."""
    assert not (SAGE_CLI_SRC / "core" / "refactor_example.py").exists()


# ---------------------------------------------------------------------------
# 5. platform/env.py: dotenv availability status line removed from renderer
# ---------------------------------------------------------------------------


def test_issue2_platform_env_renderer_no_dotenv_status() -> None:
    """platform/env.py _render_status must not check 'dotenv_available'."""
    src = _source("commands/platform/env.py")
    assert "dotenv_available" not in src
