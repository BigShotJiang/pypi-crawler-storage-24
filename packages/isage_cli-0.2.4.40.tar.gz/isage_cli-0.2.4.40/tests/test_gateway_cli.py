"""Contract tests for the gateway CLI command error semantics.

Covers the key failure paths to ensure UX stability:
- start: already-running, port-busy, missing-module
- stop: not-running
- status: not-running
"""

from __future__ import annotations

from unittest.mock import MagicMock, patch

from typer.testing import CliRunner

from sage.cli.commands.apps.gateway import app
from sage.common.config.ports import SagePorts

runner = CliRunner(env={"NO_COLOR": "1"})


# =============================================================================
# Help / registration contracts
# =============================================================================


class TestHelpContracts:
    """Help text stability contracts."""

    def test_root_help(self) -> None:
        result = runner.invoke(app, ["--help"])
        assert result.exit_code == 0
        assert "start" in result.stdout
        assert "stop" in result.stdout
        assert "status" in result.stdout

    def test_start_help(self) -> None:
        result = runner.invoke(app, ["start", "--help"])
        assert result.exit_code == 0
        assert "--port" in result.stdout
        assert "--log-level" in result.stdout
        assert str(SagePorts.GATEWAY_DEFAULT) in result.stdout

    def test_stop_help(self) -> None:
        result = runner.invoke(app, ["stop", "--help"])
        assert result.exit_code == 0
        assert "--force" in result.stdout

    def test_status_help(self) -> None:
        result = runner.invoke(app, ["status", "--help"])
        assert result.exit_code == 0
        assert "--port" in result.stdout


# =============================================================================
# start command error-path contracts
# =============================================================================


class TestStartErrorPaths:
    """Error-path contracts for `gateway start`."""

    @patch("sage.cli.commands.apps.gateway._get_gateway_pid")
    @patch("sage.cli.commands.apps.gateway._check_gateway_health")
    def test_start_already_running_healthy_returns_zero(
        self,
        mock_health: MagicMock,
        mock_pid: MagicMock,
    ) -> None:
        """When server is running and healthy, start warns and returns normally."""
        mock_pid.return_value = 12345
        mock_health.return_value = True  # healthy

        result = runner.invoke(app, ["start"])
        # gateway start returns (not exits with 1) when already running + healthy
        assert result.exit_code == 0
        assert "Gateway 已在运行中" in result.stdout

    @patch("sage.cli.commands.apps.gateway.SagePorts")
    @patch("sage.cli.commands.apps.gateway._get_gateway_pid")
    @patch("sage.cli.commands.apps.gateway._check_gateway_health")
    def test_start_port_busy_exits_one(
        self,
        mock_health: MagicMock,
        mock_pid: MagicMock,
        mock_ports: MagicMock,
    ) -> None:
        """When port is busy, start should exit 1 with an informative message."""
        mock_pid.return_value = None
        mock_health.return_value = False
        mock_ports.is_available.return_value = False  # port occupied
        mock_ports.GATEWAY_DEFAULT = SagePorts.GATEWAY_DEFAULT

        result = runner.invoke(app, ["start", "--port", "9000", "--foreground"])
        assert result.exit_code == 1
        assert "端口" in result.stdout
        assert "占用" in result.stdout

    @patch("sage.cli.commands.apps.gateway.module_available")
    @patch("sage.cli.commands.apps.gateway.SagePorts")
    @patch("sage.cli.commands.apps.gateway._get_gateway_pid")
    @patch("sage.cli.commands.apps.gateway._check_gateway_health")
    def test_start_missing_module_exits_one(
        self,
        mock_health: MagicMock,
        mock_pid: MagicMock,
        mock_ports: MagicMock,
        mock_module_available: MagicMock,
    ) -> None:
        """When sagellm_gateway is missing, start should exit 1 with install hint."""
        mock_pid.return_value = None
        mock_health.return_value = False
        mock_ports.is_available.return_value = True  # port free
        mock_ports.GATEWAY_DEFAULT = SagePorts.GATEWAY_DEFAULT
        mock_module_available.return_value = False

        result = runner.invoke(app, ["start"])
        assert result.exit_code == 1
        assert "缺少 sagellm_gateway 模块" in result.stdout
        assert "pip install" in result.stdout


# =============================================================================
# stop command error-path contracts
# =============================================================================


class TestStopErrorPaths:
    """Error-path contracts for `gateway stop`."""

    @patch("sage.cli.commands.apps.gateway._get_gateway_pid")
    def test_stop_not_running_returns_zero(self, mock_pid: MagicMock) -> None:
        """When gateway is not running, stop should succeed with informative message."""
        mock_pid.return_value = None

        result = runner.invoke(app, ["stop"])
        assert result.exit_code == 0
        assert "Gateway 未运行" in result.stdout


# =============================================================================
# status command error-path contracts
# =============================================================================


class TestStatusErrorPaths:
    """Error-path contracts for `gateway status`."""

    @patch("sage.cli.commands.apps.gateway._get_gateway_pid")
    @patch("sage.cli.commands.apps.gateway._check_gateway_health")
    def test_status_not_running_returns_zero(
        self,
        mock_health: MagicMock,
        mock_pid: MagicMock,
    ) -> None:
        """When gateway is not running, status should exit 0 with clear message."""
        mock_pid.return_value = None
        mock_health.return_value = False

        result = runner.invoke(app, ["status"])
        assert result.exit_code == 0
        assert "Gateway 未运行" in result.stdout

    @patch("sage.cli.commands.apps.gateway._fetch_gateway_status")
    @patch("sage.cli.commands.apps.gateway._get_gateway_pid")
    @patch("sage.cli.commands.apps.gateway._check_gateway_health")
    def test_status_running_reports_pid(
        self,
        mock_health: MagicMock,
        mock_pid: MagicMock,
        mock_fetch: MagicMock,
    ) -> None:
        """When gateway is running and healthy, status shows PID."""
        mock_pid.return_value = 99999
        mock_health.return_value = True
        mock_fetch.return_value = None  # no detailed status available

        result = runner.invoke(app, ["status", "--no-engines", "--no-backends"])
        assert result.exit_code == 0
        assert "99999" in result.stdout
        assert "Gateway 运行中" in result.stdout
