"""Regression tests for issue #3: 清理向后兼容命令别名与隐式行为.

Verifies that:
1. The deprecated _setup_auto_backend() method is removed from chat.py.
2. backend='auto' raises ValueError (no silent fallback).
3. DEFAULT_BACKEND is no longer 'auto'.
4. core/utils.py find_project_root no longer carries a local fallback for sage-common.
5. pipeline_knowledge.py no longer silently falls back to hash embedding.
6. core/__init__.py no longer carries a hardcoded version fallback.
7. refactor_example.py and config_refactored.py are deleted from the package.
"""

from __future__ import annotations

from pathlib import Path

SAGE_CLI_SRC = Path(__file__).parent.parent / "src" / "sage" / "cli"


def _source(rel: str) -> str:
    return (SAGE_CLI_SRC / rel).read_text(encoding="utf-8")


# ---------------------------------------------------------------------------
# 1. chat.py: no _setup_auto_backend method
# ---------------------------------------------------------------------------


def test_issue3_chat_no_setup_auto_backend_method() -> None:
    """chat.py must not define the deprecated _setup_auto_backend method."""
    src = _source("commands/apps/chat.py")
    assert "_setup_auto_backend" not in src


def test_issue3_chat_auto_backend_raises() -> None:
    """chat.py backend='auto' branch must raise ValueError, not silently detect."""
    src = _source("commands/apps/chat.py")
    assert "raise ValueError" in src
    assert "backend='auto'" in src or "backend=\\'auto\\'" in src or "auto" in src


def test_issue3_chat_default_backend_not_auto() -> None:
    """DEFAULT_BACKEND must no longer be 'auto'."""
    src = _source("commands/apps/chat.py")
    assert 'DEFAULT_BACKEND = "auto"' not in src
    assert "DEFAULT_BACKEND = 'auto'" not in src


def test_issue3_chat_help_no_auto_recommended() -> None:
    """The --backend help text must not recommend 'auto'."""
    src = _source("commands/apps/chat.py")
    assert "auto (\u63a8\u8350)" not in src


# ---------------------------------------------------------------------------
# 2. core/utils.py: no local fallback for sage-common
# ---------------------------------------------------------------------------


def test_issue3_utils_no_import_fallback_for_find_sage_project_root() -> None:
    """find_project_root must not carry a local fallback when sage-common is absent."""
    src = _source("core/utils.py")
    # The except ImportError block with local markers list must be gone
    assert "Fallback to local implementation if sage-common not available" not in src
    assert "SAGE_API_REFACTOR_SUMMARY.md" not in src


# ---------------------------------------------------------------------------
# 3. pipeline_knowledge.py: no hash embedding fallback
# ---------------------------------------------------------------------------


def test_issue3_pipeline_knowledge_no_hash_fallback() -> None:
    """KnowledgeBase must not silently fall back to hash embedding."""
    src = _source("commands/apps/pipeline_knowledge.py")
    assert "Fallback to hash embedding if the requested method fails" not in src
    assert 'EmbeddingFactory.create("hash"' not in src


# ---------------------------------------------------------------------------
# 4. core/__init__.py: no hardcoded version fallback
# ---------------------------------------------------------------------------


def test_issue3_core_init_no_hardcoded_version_fallback() -> None:
    """core/__init__.py must not carry a hardcoded version as ImportError fallback."""
    src = _source("core/__init__.py")
    assert '__version__ = "0.1.4"' not in src
    assert "# \u5907\u7528\u786c\u7f16\u7801\u7248\u672c" not in src


# ---------------------------------------------------------------------------
# 5. Deleted stale demo files must not exist on disk
# ---------------------------------------------------------------------------


def test_issue3_refactor_example_deleted() -> None:
    """refactor_example.py must be absent from the package tree."""
    assert not (SAGE_CLI_SRC / "core" / "refactor_example.py").exists()


def test_issue3_config_refactored_deleted() -> None:
    """config_refactored.py must be absent from the package tree."""
    assert not (SAGE_CLI_SRC / "core" / "config_refactored.py").exists()
