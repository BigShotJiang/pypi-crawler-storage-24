"""sage list — 列出可用应用、Pipeline 模板和已配置模型。"""

from __future__ import annotations

from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from sage.cli.core.setup_state import PIPELINES_DIR, is_setup_done, load_config

console = Console()


def list_all() -> None:
    """列出所有可用 app、pipeline 和模型。"""
    _list_apps()
    _list_pipelines()
    _list_models()


def _list_apps() -> None:
    """打印内置 app 列表（带分类）。"""
    table = Table(
        "App",
        "描述",
        "快速启动",
        box=None,
        padding=(0, 2),
        show_header=True,
        header_style="bold",
    )
    # 对话 & 助手
    table.add_row("[bold]── 对话 & 助手 ──[/bold]", "", "")
    table.add_row("  chat", "AI 对话（多轮文字交互）", "sage run chat")
    table.add_row("  demo hello", "Hello World 快速体验（无需 LLM）", "sage run demo hello")

    # 知识 & 检索
    table.add_row("[bold]── 知识 & 检索 ──[/bold]", "", "")
    table.add_row("  rag", "RAG 检索增强问答", "sage run rag --docs ./docs")

    # 服务 & 集成
    table.add_row("[bold]── 服务 & 集成 ──[/bold]", "", "")
    table.add_row("  gateway", "OpenAI 兼容 REST API 网关", "sage run gateway")
    table.add_row("  pipeline", "自定义 sage.yaml 工作流", "sage run pipeline ./flow.yaml")

    # 可视化
    table.add_row("[bold]── 可视化 ──[/bold]", "", "")
    table.add_row("  studio", "Web 看板（类 Flink UI）", "sage run studio")

    console.print(Panel(table, title="🚀 内置 App", border_style="cyan"))


def _list_pipelines() -> None:
    """打印用户已保存的 pipeline 列表。"""
    if not PIPELINES_DIR.exists() or not list(PIPELINES_DIR.glob("*.yaml")):
        console.print(
            Panel(
                "[dim]暂无自定义 Pipeline。\n\n"
                "  拉取模板：[bold cyan]sage pull rag-basic[/bold cyan]\n"
                "  或将 .yaml 文件放入 ~/.sage/pipelines/ 目录[/dim]",
                title="🔧 My Pipelines",
                border_style="dim",
            )
        )
        return
    yamls = list(PIPELINES_DIR.glob("*.yaml"))
    table = Table("名称", "路径", box=None, padding=(0, 2), show_header=True, header_style="bold")
    for y in sorted(yamls):
        table.add_row(y.stem, str(y))
    console.print(Panel(table, title="🔧 My Pipelines", border_style="magenta"))


def _list_models() -> None:
    """打印已配置的模型信息。"""
    if not is_setup_done():
        console.print(
            Panel(
                "[dim]尚未 setup，运行 sage setup 配置 LLM 后端[/dim]",
                title="🤖 LLM 配置",
                border_style="dim",
            )
        )
        return
    cfg = load_config()
    table = Table(show_header=False, box=None, padding=(0, 2))
    table.add_row("[dim]后端[/dim]", cfg.llm.backend)
    table.add_row("[dim]默认模型[/dim]", cfg.llm.default_model)
    table.add_row("[dim]端口[/dim]", str(cfg.llm.port) if cfg.llm.port else "—")
    table.add_row("[dim]API 地址[/dim]", cfg.llm.api_base or "（本地）")
    console.print(Panel(table, title="🤖 LLM 配置", border_style="yellow"))

    table.add_row("[dim]Embedding[/dim]", cfg.llm.embedding_model)
    console.print(Panel(table, title="🤖 LLM 配置", border_style="green"))
