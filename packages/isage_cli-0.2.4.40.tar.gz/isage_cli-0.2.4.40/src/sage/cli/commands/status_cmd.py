"""sage status — 全局 Dashboard（类 Flink Web UI 的终端版）。

显示：
- 所有运行中的 SAGE 服务（sageLLM、Studio、Gateway、...）
- Setup 状态
- 配置摘要
- Studio Web 链接

首次安装（setup 未完成）时显示漂亮的欢迎 + Getting-Started 向导。
"""

from __future__ import annotations

import time

from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from sage.cli.core.setup_state import (
    alive_services,
    load_config,
    sage_home_info,
)

console = Console()


def status_dashboard(watch: bool = False, interval: int = 3) -> None:
    """打印全局状态看板。"""
    if watch:
        try:
            while True:
                console.clear()
                _render_dashboard()
                console.print(f"[dim]每 {interval}s 刷新，Ctrl-C 退出[/dim]")
                time.sleep(interval)
        except KeyboardInterrupt:
            pass
    else:
        _render_dashboard()


def _render_dashboard() -> None:
    """渲染状态面板；首次安装时显示欢迎向导。"""
    info = sage_home_info()
    setup_ok = info["setup_done"]

    if not setup_ok:
        _render_welcome()
        return

    cfg = load_config()
    services = alive_services()

    # ── 配置摘要 ────────────────────────────────────────────────────────
    cfg_table = Table(show_header=False, box=None, padding=(0, 2))
    cfg_table.add_row("[dim]工作目录[/dim]", str(info["home"]))
    cfg_table.add_row("[dim]LLM 后端[/dim]", info["llm_backend"])
    cfg_table.add_row("[dim]默认模型[/dim]", info["llm_model"])
    console.print(Panel(cfg_table, title="📋 SAGE 配置", border_style="cyan"))

    # ── 服务状态 ────────────────────────────────────────────────────────
    svc_table = Table(
        "服务",
        "状态",
        "PID",
        "端口 / URL",
        show_header=True,
        header_style="bold",
        box=None,
        padding=(0, 2),
    )

    known = {
        "sagellm": ("🤖 sageLLM", cfg.llm.port),
        "studio": ("🖥️  Studio", cfg.studio.port),
        "gateway": ("🌐 Gateway", None),
    }

    shown_names: set[str] = set()
    for name, entry in services.items():
        label, _ = known.get(name, (f"⚙️  {name}", None))
        pid = entry.get("pid", "?")
        url = entry.get("url") or (f":{entry['port']}" if entry.get("port") else "—")
        svc_table.add_row(label, "[green]● 运行中[/green]", str(pid), url)
        shown_names.add(name)

    for name, (label, port) in known.items():
        if name not in shown_names:
            url = f":{port}" if port else "—"
            svc_table.add_row(label, "[dim]○ 未运行[/dim]", "—", url)

    if svc_table.row_count == 0:
        console.print(Panel("[dim]暂无运行中的服务[/dim]", title="⚡ 服务状态", border_style="dim"))
    else:
        console.print(Panel(svc_table, title="⚡ 服务状态", border_style="green"))

    # ── Studio 链接 ─────────────────────────────────────────────────────
    if cfg.studio.enabled:
        studio_url = f"http://{cfg.studio.host}:{cfg.studio.port}"
        alive = "studio" in services
        link_line = (
            f"[green]● 运行中[/green]  {studio_url}  [dim](Ctrl+Click 在浏览器中打开)[/dim]"
            if alive
            else "[dim]○ 未运行  运行: [bold]sage run studio[/bold][/dim]"
        )
        console.print(Panel(link_line, title="📊 SAGE Studio Web 看板", border_style="blue"))

    # ── 快速提示（仅在没有服务运行时显示） ─────────────────────────────
    if not services:
        console.print(
            "[dim]💡 "
            "[bold cyan]sage run chat[/bold cyan] 开始对话  │  "
            "[bold cyan]sage run rag --docs ./docs[/bold cyan] 构建 RAG  │  "
            "[bold cyan]sage run studio[/bold cyan] 打开 Web 看板[/dim]"
        )


def _render_welcome() -> None:
    """首次安装时展示的欢迎 + Getting-Started 向导。"""
    body = (
        "[bold white]SAGE[/bold white] 是开箱即用的多模态 AI 系统框架：\n"
        "  • 本地 LLM 推理（sageLLM / Ollama / OpenAI 兼容 API）\n"
        "  • RAG 检索增强问答（PDF / Markdown / 代码库）\n"
        "  • Agent 自主任务执行 & 工具调用\n"
        "  • 可视化 Web 看板（SAGE Studio）\n\n"
        "[bold]━━━  三步快速开始  ━━━[/bold]\n\n"
        "  [bold cyan]1.[/bold cyan]  pip install isage"
        "          [green]✅ 已完成（你在这里）[/green]\n"
        "  [bold cyan]2.[/bold cyan]  [bold yellow]sage setup[/bold yellow]"
        "               ← 立即运行（约 30 秒完成）\n"
        "  [bold cyan]3.[/bold cyan]  sage run chat"
        "           开始 AI 对话\n\n"
        "[dim]💡 不想配置 LLM？先体验框架本身：  [bold]sage run demo hello[/bold][/dim]"
    )
    console.print(
        Panel(
            body,
            title="[bold]🚀 欢迎使用 SAGE[/bold]",
            border_style="bright_blue",
            padding=(1, 3),
        )
    )
    console.print(
        "[dim]运行 [bold cyan]sage setup[/bold cyan] 完成初始化，"
        "或用 [bold cyan]sage setup --yes[/bold cyan] 一键静默初始化[/dim]\n"
    )
