#!/usr/bin/env python3
"""SAGE CLI Doctor Command — diagnose the local environment."""

from __future__ import annotations

import importlib
import importlib.metadata
import subprocess
import sys
from dataclasses import dataclass, field

import typer
from rich.console import Console
from rich.table import Table

from sage.cli.utils.diagnostics import check_dependency_versions

console = Console()
app = typer.Typer(name="doctor", help="🔍 系统诊断")


# ---------------------------------------------------------------------------
# Package registry: each entry is (display_name, pypi_name, import_path, layer)
# ---------------------------------------------------------------------------
_REQUIRED_PACKAGES: list[tuple[str, str, str, str]] = [
    ("isage-common", "isage-common", "sage.common", "L1 基础 + 平台"),
    ("isage-kernel", "isage-kernel", "sage.kernel", "L2 内核"),
    ("isage-libs", "isage-libs", "sage.libs", "L2 算法库"),
    ("isage-middleware", "isage-middleware", "sage.middleware", "L3 中间件"),
    ("isage-cli", "isage-cli", "sage.cli", "L4 CLI"),
]

_OPTIONAL_PACKAGES: list[tuple[str, str, str, str]] = [
    ("isagellm", "isagellm", "sagellm", "LLM 推理引擎"),
    ("isage-neuromem", "isage-neuromem", "neuromem", "L4 记忆管理"),
    ("isage-anns", "isage-anns", "sage_anns", "L3 向量检索"),
    ("isage-dev-tools", "isage-dev-tools", "sage_dev_tools", "开发工具"),
]


@dataclass
class _PkgResult:
    name: str
    layer: str
    version: str | None
    ok: bool
    optional: bool
    fix_cmd: str = field(default="")


def _check_pkg(display: str, pypi: str, import_path: str, layer: str, optional: bool) -> _PkgResult:
    """Try to import a package and retrieve its installed version."""
    # Try importlib.metadata first (fast, no side-effects)
    version: str | None = None
    try:
        version = importlib.metadata.version(pypi)
    except importlib.metadata.PackageNotFoundError:
        pass

    if version is None:
        # Fallback: try direct import to get __version__
        try:
            mod = importlib.import_module(import_path)
            version = getattr(mod, "__version__", "installed")
        except Exception:
            pass

    ok = version is not None
    return _PkgResult(
        name=display,
        layer=layer,
        version=version,
        ok=ok,
        optional=optional,
        fix_cmd=f"pip install --upgrade {pypi}" if not ok else "",
    )


def _check_hardware() -> dict[str, str]:
    """Return hardware/runtime info dict."""
    info: dict[str, str] = {}
    info["Python"] = sys.version.split()[0]
    # GPU
    try:
        import torch  # noqa: F401 — optional

        cuda_ok = torch.cuda.is_available()
        if cuda_ok:
            gpu_name = torch.cuda.get_device_name(0)
            info["GPU (CUDA)"] = f"✅ {gpu_name}"
        else:
            info["GPU (CUDA)"] = "⚠️  不可用 (CPU 模式)"
    except ImportError:
        info["GPU (CUDA)"] = "— torch 未安装"
    return info


@app.command()
def check(
    show_optional: bool = typer.Option(False, "--optional", "-o", help="同时检查可选包"),
) -> None:
    """全面诊断 SAGE 安装状态（层级 L1-L5 + 可选组件 + 硬件）。"""
    console.rule("[bold cyan]SAGE 系统诊断[/bold cyan]")

    # ── 环境信息 ──────────────────────────────────────────────────────────
    hw = _check_hardware()
    for k, v in hw.items():
        console.print(f"  🖥  {k}: [bold]{v}[/bold]")
    console.print()

    # ── 核心包检查 ────────────────────────────────────────────────────────
    results: list[_PkgResult] = []
    for display, pypi, imp, layer in _REQUIRED_PACKAGES:
        results.append(_check_pkg(display, pypi, imp, layer, optional=False))

    if show_optional:
        for display, pypi, imp, layer in _OPTIONAL_PACKAGES:
            results.append(_check_pkg(display, pypi, imp, layer, optional=True))

    table = Table(show_header=True, header_style="bold magenta", box=None, pad_edge=False)
    table.add_column("状态", width=4)
    table.add_column("包名", style="cyan", no_wrap=True, min_width=22)
    table.add_column("层级", style="dim", min_width=10)
    table.add_column("版本", style="green", min_width=14)

    passed = 0
    failed_req: list[_PkgResult] = []
    for r in results:
        if r.ok:
            icon = "✅"
            ver_str = r.version or "—"
            passed += 1
        elif r.optional:
            icon = "💤"
            ver_str = "[dim]未安装[/dim]"
        else:
            icon = "❌"
            ver_str = "[red]未安装[/red]"
            failed_req.append(r)
        table.add_row(icon, r.name, r.layer, ver_str)

    console.print(table)
    console.print()

    # ── 汇总 ──────────────────────────────────────────────────────────────
    req_total = sum(1 for r in results if not r.optional)
    if not failed_req:
        console.print(
            f"[bold green]✅ 全部 {req_total} 个核心包正常[/bold green]"
            "  — 运行 [bold]sage run demo hello[/bold] 快速验证"
        )
    else:
        console.print(f"[bold red]❌ {len(failed_req)}/{req_total} 个核心包缺失[/bold red]")
        console.print()
        console.print("[bold yellow]🔧 一键修复:[/bold yellow]")
        console.print("   [bold]sage doctor fix[/bold]")
        console.print()
        console.print("[dim]或手动安装:[/dim]")
        for r in failed_req:
            console.print(f"   pip install --upgrade {r.name}")

    if not show_optional:
        console.print("[dim]💡 可选包检查: [bold]sage doctor check --optional[/bold][/dim]")


@app.command()
def fix(
    yes: bool = typer.Option(False, "--yes", "-y", help="跳过确认直接安装"),
) -> None:
    """自动安装所有缺失的 SAGE 核心包。"""
    console.rule("[bold cyan]SAGE 自动修复[/bold cyan]")

    missing: list[str] = []
    for _display, pypi, _imp, _layer in _REQUIRED_PACKAGES:
        try:
            importlib.metadata.version(pypi)
        except importlib.metadata.PackageNotFoundError:
            missing.append(pypi)

    if not missing:
        console.print("[bold green]✅ 所有核心包已安装，无需修复。[/bold green]")
        return

    console.print(f"[yellow]缺失的包 ({len(missing)}):[/yellow]")
    for p in missing:
        console.print(f"  • {p}")
    console.print()

    if not yes:
        confirmed = typer.confirm("是否立即安装以上包？")
        if not confirmed:
            console.print("[dim]已取消。[/dim]")
            raise typer.Exit()

    cmd = [sys.executable, "-m", "pip", "install", "--upgrade", *missing]
    console.print(f"[cyan]运行: {' '.join(cmd)}[/cyan]")
    result = subprocess.run(cmd)
    if result.returncode == 0:
        console.print("[bold green]✅ 修复完成！运行 sage doctor 验证。[/bold green]")
    else:
        console.print("[bold red]❌ 部分包安装失败，请查看上方错误信息。[/bold red]")
        raise typer.Exit(1)


@app.command()
def compat():
    """检查闭源依赖的兼容性。"""
    success = check_dependency_versions(console=console)
    if not success:
        raise typer.Exit(1)


# 为了向后兼容，也提供一个直接的 doctor 命令
@app.callback(invoke_without_command=True)
def doctor_callback(ctx: typer.Context):
    """诊断 SAGE 安装和配置"""
    if ctx.invoked_subcommand is None:
        ctx.invoke(check, show_optional=False)
