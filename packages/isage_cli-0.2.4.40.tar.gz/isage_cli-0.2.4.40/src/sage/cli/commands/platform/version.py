#!/usr/bin/env python3
"""
SAGE CLI Version Command
显示版本信息
"""

from __future__ import annotations

import importlib.metadata

import typer
from rich.console import Console
from rich.table import Table

app = typer.Typer(name="version", help="📋 版本信息")
console = Console()

# (display_name, pypi_name)
_PACKAGES = [
    ("isage", "isage"),
    ("isage-common", "isage-common"),
    ("isage-kernel", "isage-kernel"),
    ("isage-libs", "isage-libs"),
    ("isage-middleware", "isage-middleware"),
    ("isage-cli", "isage-cli"),
    ("isagellm", "isagellm"),
]


def _meta_version() -> str:
    """Return the installed meta-package version (isage or sage.common fallback)."""
    for pkg in ("isage", "isage-common"):
        try:
            return importlib.metadata.version(pkg)
        except importlib.metadata.PackageNotFoundError:
            pass
    try:
        from sage.common._version import __version__

        return __version__
    except ImportError:
        return "unknown"


@app.callback(invoke_without_command=True)
def show(ctx: typer.Context) -> None:
    """显示 SAGE 及所有子包的版本信息"""
    if ctx.invoked_subcommand is not None:
        return

    meta = _meta_version()
    console.print(
        f"[bold cyan]SAGE[/bold cyan] [bold]{meta}[/bold]  —  "
        "Streaming-Augmented Generative Execution"
    )
    console.print("[dim]IntelliStream  ·  https://github.com/intellistream/SAGE[/dim]")
    console.print()

    table = Table(show_header=True, header_style="bold magenta", box=None, pad_edge=False)
    table.add_column("包名", style="cyan", min_width=22)
    table.add_column("版本", style="green", min_width=14)
    for display, pypi in _PACKAGES:
        try:
            ver = importlib.metadata.version(pypi)
            table.add_row(display, ver)
        except importlib.metadata.PackageNotFoundError:
            table.add_row(display, "[dim]未安装[/dim]")
    console.print(table)

    console.print()
    console.print("[dim]常用命令:[/dim]")
    console.print("  [cyan]sage doctor[/cyan]        — 诊断 SAGE 安装")
    console.print("  [cyan]sage demo hello[/cyan]    — Hello World 快速验证")
    console.print("  [cyan]sage run chat[/cyan]      — 启动 AI 对话")
    console.print("  [cyan]sage-dev --help[/cyan]    — 开发工具")
