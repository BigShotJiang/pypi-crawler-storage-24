"""sage stop — 停止运行中的 SAGE 服务。"""

from __future__ import annotations

import os
import signal

from rich.console import Console

from sage.cli.core.setup_state import alive_services, unregister_service

console = Console()


def stop_service(name: str | None) -> None:
    """停止一个或所有 SAGE 服务。"""
    services = alive_services()

    if not services:
        console.print("[dim]没有正在运行的 SAGE 服务。[/dim]")
        return

    targets: list[str] = list(services.keys()) if name is None else [name]

    for svc in targets:
        entry = services.get(svc)
        if entry is None:
            console.print(f"[yellow]服务 '{svc}' 未在运行。[/yellow]")
            continue
        pid = entry.get("pid")
        if not pid:
            unregister_service(svc)
            continue
        try:
            os.kill(int(pid), signal.SIGTERM)
            console.print(f"[green]✅ 已停止 {svc} (PID {pid})[/green]")
        except ProcessLookupError:
            console.print(f"[dim]{svc} 进程已退出[/dim]")
        except PermissionError:
            console.print(f"[red]无权限停止 {svc} (PID {pid})[/red]")
        unregister_service(svc)
