"""sage setup — 一次性初始化向导。

类比 Ollama 的首次启动体验：
  sage setup              # 交互式向导
  sage setup --defaults   # 全用默认值（CI 友好）
  sage setup --reset      # 重置并重新初始化

向导完成后写入 ~/.sage/config.json，后续命令无需重复配置。
"""

from __future__ import annotations

import shutil
import sys

import typer
from rich.console import Console
from rich.panel import Panel
from rich.prompt import Confirm, Prompt
from rich.table import Table

from sage.cli.core.setup_state import (
    CLUSTER_CONFIG_FILE,
    LLMBackendConfig,
    SageConfig,
    StudioConfig,
    detect_gpu,
    generate_cluster_yaml,
    is_conda_env,
    load_config,
    mark_setup_done,
)

app = typer.Typer(name="setup", help="🔧 SAGE 一次性初始化向导", invoke_without_command=True)
console = Console()


# ══════════════════════════════════════════════════════════════════════════
# 主命令
# ══════════════════════════════════════════════════════════════════════════


@app.callback(invoke_without_command=True)
def setup(
    ctx: typer.Context,
    defaults: bool = typer.Option(
        False, "--defaults", "-d", help="使用所有默认值（跳过交互式问答）"
    ),
    yes: bool = typer.Option(False, "--yes", "-y", help="等同于 --defaults（Linux 用户习惯风格）"),
    reset: bool = typer.Option(False, "--reset", help="清除现有配置并重新初始化"),
    check: bool = typer.Option(False, "--check", help="仅检查 setup 状态，不执行初始化"),
) -> None:
    """🔧 SAGE 一次性初始化向导。

    \b
    类比 Ollama 的首次启动体验：
      sage setup              # 交互式向导
      sage setup --defaults   # 全用默认值（CI 友好）
      sage setup --reset      # 重置并重新初始化

    初始化完成后，~/.sage/config.json 会记录你的配置，
    之后直接用 sage run 即可，无需再次 setup。
    """
    if ctx.invoked_subcommand is not None:
        return

    if check:
        _cmd_check()
        return

    # --yes is a friendly alias for --defaults
    if yes:
        defaults = True

    cfg = load_config()

    if cfg.setup_completed and not reset:
        console.print(
            Panel(
                "[bold green]✅ SAGE 已初始化完成！[/bold green]\n\n"
                f"工作目录: [cyan]{cfg.workspace}[/cyan]\n"
                f"LLM 后端:  [cyan]{cfg.llm.backend}[/cyan]  "
                f"({cfg.llm.default_model})\n\n"
                "重新初始化请运行: [bold]sage setup --reset[/bold]\n"
                "下一步:           [bold]sage run chat[/bold]",
                title="SAGE Setup",
                border_style="green",
            )
        )
        return

    _print_banner()
    _run_setup(cfg, use_defaults=defaults)


# ══════════════════════════════════════════════════════════════════════════
# 子命令
# ══════════════════════════════════════════════════════════════════════════


@app.command("check")
def _cmd_check() -> None:
    """显示当前 setup 状态。"""
    cfg = load_config()
    status = "✅ 已完成" if cfg.setup_completed else "⚠️  未完成"
    table = Table(show_header=False, box=None, padding=(0, 2))
    table.add_row("[dim]Setup 状态[/dim]", f"[bold]{status}[/bold]")
    table.add_row("[dim]工作目录[/dim]", str(cfg.workspace))
    table.add_row("[dim]LLM 后端[/dim]", cfg.llm.backend)
    table.add_row("[dim]默认模型[/dim]", cfg.llm.default_model)
    table.add_row("[dim]Studio 端口[/dim]", str(cfg.studio.port))
    console.print(Panel(table, title="SAGE Setup 状态", border_style="cyan"))


# ══════════════════════════════════════════════════════════════════════════
# 核心逻辑
# ══════════════════════════════════════════════════════════════════════════


def _print_banner() -> None:
    console.print(
        Panel(
            "[bold cyan]欢迎使用 SAGE — Streaming-Augmented Generative Execution[/bold cyan]\n\n"
            "本向导将帮助你完成一次性初始化。\n"
            "完成后，无需再次运行，直接 [bold]sage run <app>[/bold] 即可。\n\n"
            "[dim]（按 Ctrl-C 随时中断，已保存的配置不受影响）[/dim]",
            title="🚀 SAGE Setup",
            border_style="cyan",
        )
    )


def _run_setup(cfg: SageConfig, *, use_defaults: bool) -> None:
    """执行完整 setup 流程：环境探测 → 后端配置 → 验证 → 完成。"""

    # ── 阶段 1：环境探测 ─────────────────────────────────────────────────
    console.print("\n[bold]▸ 第 1 步：探测运行环境[/bold]")
    env_info = _detect_environment()
    _print_env_table(env_info)

    # ── 阶段 2：LLM 后端选择 ─────────────────────────────────────────────
    console.print("\n[bold]▸ 第 2 步：配置 LLM 后端[/bold]")
    llm_cfg = _configure_llm(use_defaults=use_defaults)
    cfg.llm = llm_cfg

    # ── 阶段 3：Studio Web UI ────────────────────────────────────────────
    console.print("\n[bold]▸ 第 3 步：配置 Web 看板（SAGE Studio）[/bold]")
    studio_cfg = _configure_studio(use_defaults=use_defaults)
    cfg.studio = studio_cfg

    # ── 阶段 4：写入并完成 ────────────────────────────────────────────────
    console.print("\n[bold]▸ 写入配置...[/bold]")
    mark_setup_done(cfg)

    # 生成 cluster.yaml 模板（以便用户日后开启分布式）
    generate_cluster_yaml()

    console.print(
        Panel(
            "[bold green]🎉 SAGE 初始化完成！[/bold green]\n\n"
            f"  工作目录: [cyan]{cfg.workspace}[/cyan]\n"
            f"  LLM 后端: [cyan]{cfg.llm.backend}[/cyan]  ({cfg.llm.default_model})\n"
            f"  Studio:   [cyan]http://{cfg.studio.host}:{cfg.studio.port}[/cyan]\n\n"
            "[bold]快速开始：[/bold]\n"
            "  [bold]sage run chat[/bold]              — 开始对话\n"
            "  [bold]sage run rag --docs ./docs[/bold]  — 构建 RAG\n"
            "  [bold]sage run gateway[/bold]           — 启动 API 网关\n"
            "  [bold]sage status[/bold]               — 查看运行状态\n\n"
            "[dim]─────────────────────────────────────────────────[/dim]\n"
            "[bold yellow]🌐 想要分布式运行？[/bold yellow]\n"
            f"  编辑 [cyan]{CLUSTER_CONFIG_FILE}[/cyan]\n"
            "  将  [bold]mode: local[/bold]  改为  [bold]mode: distributed[/bold]\n"
            "  填写 workers 节点 IP，配置好 passwordless SSH，\n"
            "  之后 [bold]sage run[/bold] 命令本身不需要任何改变。\n"
            f"  [dim]（文件中有完整说明和示例，可直接照着改）[/dim]",
            title="✅ Setup 完成",
            border_style="green",
        )
    )


# ══════════════════════════════════════════════════════════════════════════
# 环境探测
# ══════════════════════════════════════════════════════════════════════════


def _detect_environment() -> dict:
    """探测 Python / GPU / Ollama / sageLLM 等信息。"""
    import platform

    gpu = detect_gpu()
    ollama_available = bool(shutil.which("ollama"))
    sagellm_available = False
    try:
        import sagellm  # noqa: F401

        sagellm_available = True
    except ImportError:
        pass

    try:
        mem_gb = _get_mem_gb()
    except Exception:
        mem_gb = None

    return {
        "python": f"{platform.python_version()} ({sys.executable.split('/')[-3] if is_conda_env() else 'system'})",
        "conda": is_conda_env(),
        "os": f"{platform.system()} {platform.machine()}",
        "memory": f"{mem_gb:.0f} GB" if mem_gb else "未知",
        "gpu": gpu["device"].upper() if gpu["cuda"] or gpu["rocm"] else "未检测到",
        "ollama": "✅ 已安装" if ollama_available else "❌ 未安装",
        "sagellm": "✅ 已安装" if sagellm_available else "❌ 未安装",
    }


def _get_mem_gb() -> float:
    import psutil  # type: ignore

    return psutil.virtual_memory().total / (1024**3)


def _print_env_table(env: dict) -> None:
    table = Table(show_header=False, box=None, padding=(0, 2))
    icons = {
        "python": "🐍",
        "conda": "🐍",
        "os": "💻",
        "memory": "🧠",
        "gpu": "🎮",
        "ollama": "🦙",
        "sagellm": "🤖",
    }
    labels = {
        "python": "Python",
        "conda": "Conda 环境",
        "os": "操作系统",
        "memory": "内存",
        "gpu": "GPU",
        "ollama": "Ollama",
        "sagellm": "sageLLM",
    }
    for key, val in env.items():
        if key == "conda":
            continue
        table.add_row(f"  {icons.get(key, '•')} {labels.get(key, key)}", str(val))
    console.print(Panel(table, border_style="dim"))


# ══════════════════════════════════════════════════════════════════════════
# LLM 后端配置
# ══════════════════════════════════════════════════════════════════════════


def _configure_llm(*, use_defaults: bool) -> LLMBackendConfig:
    """引导用户选择 LLM 后端。"""
    ollama_ok = bool(shutil.which("ollama"))

    # 默认使用 sageLLM
    default_choice = "1"

    console.print(
        "\n  SAGE 支持多种 LLM 后端：\n"
        "  [bold][1][/bold] sageLLM  — SAGE 自带推理引擎（[cyan]推荐[/cyan]，无需外部服务）\n"
        "  [bold][2][/bold] Ollama   — 本地 GPU 推理（需要已安装 ollama）"
        + (" [green]✅[/green]" if ollama_ok else " [dim]未检测到[/dim]")
        + "\n"
        "  [bold][3][/bold] 云 API   — 月之暗面 / 通义千问 / OpenAI 等"
    )

    if use_defaults:
        choice = default_choice
        console.print("  [dim]（--defaults 模式，自动选择: sageLLM）[/dim]")
    else:
        choice = Prompt.ask("  选择后端", choices=["1", "2", "3"], default=default_choice)

    if choice == "1":
        return _configure_sagellm(use_defaults=use_defaults)
    elif choice == "2":
        return _configure_ollama(use_defaults=use_defaults)
    else:
        return _configure_api(use_defaults=use_defaults)


def _configure_sagellm(*, use_defaults: bool) -> LLMBackendConfig:
    """配置 sageLLM 本地推理。"""
    default_model = "Qwen/Qwen2.5-0.5B-Instruct"

    if use_defaults:
        model = default_model
    else:
        console.print(
            "\n  常用模型：\n"
            "  • Qwen/Qwen2.5-0.5B-Instruct  [dim](轻量，CPU 可用)[/dim]\n"
            "  • Qwen/Qwen2.5-7B-Instruct    [dim](平衡，推荐 8GB VRAM)[/dim]\n"
            "  • Qwen/Qwen2.5-72B-Instruct   [dim](高质量，推荐 24GB+ VRAM)[/dim]"
        )
        model = Prompt.ask("  默认模型", default=default_model)

    return LLMBackendConfig(
        backend="sagellm",
        host="localhost",
        port=8000,
        default_model=model,
        embedding_model="BAAI/bge-small-zh-v1.5",
    )


def _configure_ollama(*, use_defaults: bool) -> LLMBackendConfig:
    """配置 Ollama 后端。"""
    default_model = "qwen2.5:7b"

    if use_defaults:
        model = default_model
    else:
        model = Prompt.ask("  Ollama 模型", default=default_model)

    return LLMBackendConfig(
        backend="ollama",
        host="localhost",
        port=11434,
        default_model=model,
        api_base="http://localhost:11434/v1",
    )


def _configure_api(*, use_defaults: bool) -> LLMBackendConfig:
    """配置云 API 后端。"""
    providers = {
        "1": ("月之暗面 (Kimi)", "https://api.moonshot.cn/v1", "moonshot-v1-8k"),
        "2": ("通义千问", "https://dashscope.aliyuncs.com/compatible-mode/v1", "qwen-plus"),
        "3": ("OpenAI", "https://api.openai.com/v1", "gpt-4o-mini"),
        "4": ("自定义 API", "", ""),
    }

    if use_defaults:
        choice = "1"
    else:
        for k, (name, _, _) in providers.items():
            console.print(f"  [bold][{k}][/bold] {name}")
        choice = Prompt.ask("  选择提供商", choices=list(providers.keys()), default="1")

    name, api_base, default_model = providers[choice]

    if not use_defaults and choice == "4":
        api_base = Prompt.ask("  API Base URL")
        default_model = Prompt.ask("  默认模型名")

    if use_defaults:
        api_key = ""
    else:
        api_key = Prompt.ask(f"  {name} API Key", password=True, default="")

    return LLMBackendConfig(
        backend="openai",
        api_base=api_base,
        api_key=api_key,
        default_model=default_model,
    )


# ══════════════════════════════════════════════════════════════════════════
# Studio 配置
# ══════════════════════════════════════════════════════════════════════════


def _configure_studio(*, use_defaults: bool) -> StudioConfig:
    """配置 SAGE Studio Web 看板。"""
    studio_available = False
    try:
        import sage.studio  # noqa: F401

        studio_available = True
    except ImportError:
        pass

    if not studio_available:
        console.print("  [dim]SAGE Studio 未安装。如需 Web 看板，:  pip install isage-studio[/dim]")
        return StudioConfig(enabled=False, auto_start=False)

    if use_defaults:
        auto_start = True
        port = 7860
    else:
        console.print(
            "  SAGE Studio 提供类似 Flink Web UI 的 Job 可视化看板。\n"
            "  运行 sage run 时可自动在后台启动 Studio。"
        )
        auto_start = Confirm.ask("  自动启动 Studio Web 看板？", default=True)
        port_str = Prompt.ask("  Studio 端口", default="7860")
        try:
            port = int(port_str)
        except ValueError:
            port = 7860

    return StudioConfig(enabled=True, auto_start=auto_start, port=port)


# ══════════════════════════════════════════════════════════════════════════
# 首次运行检测（供 run 命令调用）
# ══════════════════════════════════════════════════════════════════════════


def ensure_setup_or_prompt() -> bool:
    """如果尚未 setup，提示用户执行。返回 True 表示可以继续。"""
    from sage.cli.core.setup_state import is_setup_done

    if is_setup_done():
        return True

    console.print(
        Panel(
            "[bold yellow]⚠️  SAGE 尚未初始化。[/bold yellow]\n\n"
            "首次使用前请运行:\n"
            "  [bold cyan]sage setup[/bold cyan]            # 交互式向导\n"
            "  [bold cyan]sage setup --defaults[/bold cyan]  # 快速默认配置\n",
            title="需要 Setup",
            border_style="yellow",
        )
    )
    run_now = Confirm.ask("现在立即运行 sage setup --defaults?", default=True)
    if run_now:
        cfg = load_config()
        _run_setup(cfg, use_defaults=True)
        return True
    return False
