"""commands/setup — sage setup 命令包。"""

from __future__ import annotations

from .setup_cmd import app as setup_app

__all__ = ["setup_app"]
