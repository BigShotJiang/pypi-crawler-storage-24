"""sage pull — 拉取 pipeline 模板或应用配置（类比 docker pull / ollama pull）。

示例：
  sage pull rag-basic          # 拉取 RAG 基础模板
  sage pull chat-with-tools    # 拉取带工具调用的对话模板
  sage pull --list             # 列出可用模板
"""

from __future__ import annotations

import typer
from rich.console import Console
from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, TextColumn
from rich.table import Table

from sage.cli.core.setup_state import PIPELINES_DIR

console = Console()

# 内置模板仓库（未来可替换为 SAGE Catalog API）
BUILTIN_TEMPLATES: dict[str, dict] = {
    "rag-basic": {
        "description": "基础 RAG pipeline（文档问答）",
        "template": {
            "name": "rag-basic",
            "version": "1.0",
            "type": "rag",
            "llm": {"backend": "sagellm", "model": "${LLM_MODEL}"},
            "retriever": {"type": "vector", "top_k": 5},
            "steps": [
                {"name": "ingest", "op": "document_loader"},
                {"name": "chunk", "op": "text_splitter", "chunk_size": 512},
                {"name": "embed", "op": "embed_documents"},
                {"name": "index", "op": "build_vector_index"},
                {"name": "retrieve", "op": "retrieve", "top_k": 5},
                {"name": "generate", "op": "llm_generate"},
            ],
        },
    },
    "chat-simple": {
        "description": "简单对话 pipeline",
        "template": {
            "name": "chat-simple",
            "version": "1.0",
            "type": "chat",
            "llm": {"backend": "sagellm", "model": "${LLM_MODEL}"},
            "steps": [{"name": "chat", "op": "llm_chat"}],
        },
    },
    "streaming-etl": {
        "description": "流式 ETL + LLM 增强 pipeline",
        "template": {
            "name": "streaming-etl",
            "version": "1.0",
            "type": "streaming",
            "source": {"type": "kafka", "topic": "${TOPIC}"},
            "filter": {"llm": True, "prompt": "提取关键信息"},
            "sink": {"type": "database", "table": "results"},
        },
    },
    "agentic-tools": {
        "description": "Agent + 工具调用 pipeline",
        "template": {
            "name": "agentic-tools",
            "version": "1.0",
            "type": "agentic",
            "llm": {"backend": "sagellm", "model": "${LLM_MODEL}"},
            "tools": ["web_search", "code_executor", "file_reader"],
            "max_steps": 10,
        },
    },
}


def pull_template(name: str | None, list_only: bool = False) -> None:
    """拉取或列出 pipeline 模板。"""
    if list_only or name is None:
        _list_templates()
        if name is None:
            return

    if name not in BUILTIN_TEMPLATES:
        console.print(f"[red]未找到模板: {name}[/red]")
        console.print("[dim]运行 sage pull --list 查看可用模板[/dim]")
        raise typer.Exit(1)

    _pull_builtin(name)


def _list_templates() -> None:
    table = Table(
        "模板名称",
        "描述",
        "使用方式",
        box=None,
        padding=(0, 2),
        show_header=True,
        header_style="bold",
    )
    for name, info in BUILTIN_TEMPLATES.items():
        table.add_row(name, info["description"], f"sage pull {name}")
    console.print(Panel(table, title="📦 SAGE Pipeline 模板库", border_style="cyan"))


def _pull_builtin(name: str) -> None:
    info = BUILTIN_TEMPLATES[name]
    PIPELINES_DIR.mkdir(parents=True, exist_ok=True)
    dest = PIPELINES_DIR / f"{name}.yaml"

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        console=console,
        transient=True,
    ) as prog:
        prog.add_task(f"拉取 {name}...", total=None)

        import yaml  # type: ignore

        yaml_content = yaml.dump(info["template"], allow_unicode=True, default_flow_style=False)
        dest.write_text(yaml_content, encoding="utf-8")

    console.print(
        Panel(
            f"[green]✅ {name}[/green] 已保存到 [cyan]{dest}[/cyan]\n\n"
            f"  运行: [bold]sage run pipeline {name}[/bold]\n"
            f"  编辑: [dim]{dest}[/dim]",
            title=f"📦 {name}",
            border_style="green",
        )
    )
