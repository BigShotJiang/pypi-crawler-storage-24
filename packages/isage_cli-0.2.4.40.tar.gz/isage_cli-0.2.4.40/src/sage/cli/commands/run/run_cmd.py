"""sage run — 统一运行入口（类比 ollama run）。

支持的 app：
  chat             — 对话（接 sageLLM / Ollama / API）
  rag              — RAG pipeline（--docs 指定文档目录）
  gateway          — 启动 OpenAI 兼容 API 网关
  pipeline         — 执行自定义 sage.yaml 流水线
  studio           — 单独启动 SAGE Studio Web 看板
  demo             — 快速体验示例

示例：
  sage run chat
  sage run chat --model qwen2.5:7b
  sage run rag --docs ./papers/
  sage run rag --docs ./papers/ --query "流式处理是什么"
  sage run gateway --port 8080
  sage run pipeline ./my_flow.yaml
  sage run demo hello
"""

from __future__ import annotations

import os
import shutil
import subprocess
import sys
import threading
import time
from pathlib import Path

import typer
from rich.console import Console
from rich.panel import Panel

from sage.cli.core.setup_state import (
    CLUSTER_CONFIG_FILE,
    is_service_alive,
    load_cluster_config,
    load_config,
    register_service,
)

app = typer.Typer(
    name="run",
    help="▶️   运行 SAGE 应用（支持 chat / rag / gateway / pipeline / demo）",
    no_args_is_help=True,
)
console = Console()

# ── 已知 app 名称（用于提示和自动补全）────────────────────────────────────
KNOWN_APPS = ["chat", "rag", "gateway", "pipeline", "studio", "demo"]


# ══════════════════════════════════════════════════════════════════════════
# 主命令：sage run <app> [OPTIONS]
# ══════════════════════════════════════════════════════════════════════════


@app.command("chat", help="💬 启动 AI 对话（连接 sageLLM / Ollama / 云 API）")
def run_chat(
    model: str | None = typer.Option(
        None, "--model", "-m", help="模型名称，默认使用配置中的默认模型"
    ),
    host: str = typer.Option("localhost", "--host", help="LLM 服务地址"),
    port: int | None = typer.Option(None, "--port", "-p", help="LLM 服务端口"),
    no_studio: bool = typer.Option(False, "--no-studio", help="不自动启动 Studio"),
    system_prompt: str | None = typer.Option(None, "--system", "-s", help="系统提示词"),
) -> None:
    """💬 启动 AI 对话。

    \b
    使用示例：
      sage run chat                          # 使用默认配置
      sage run chat --model qwen2.5:7b       # 指定模型
      sage run chat --model gpt-4o           # 使用 OpenAI 模型
    """
    _ensure_setup()
    cfg = load_config()

    resolved_model = model or cfg.llm.default_model
    resolved_port = port or cfg.llm.port

    if not no_studio:
        _maybe_start_studio(cfg)

    console.print(
        Panel(
            f"[bold cyan]💬 SAGE Chat[/bold cyan]\n\n"
            f"  模型: [green]{resolved_model}[/green]\n"
            f"  后端: [green]{cfg.llm.backend}[/green]  ({cfg.llm.host}:{resolved_port})\n"
            + (_studio_status_line(cfg) if not no_studio else "")
            + "\n[dim]输入 /exit 或 Ctrl-D 退出[/dim]",
            title="sage run chat",
            border_style="cyan",
        )
    )

    # ── 尝试启动 LLM 服务（如果尚未运行）───────────────────────────────
    if cfg.llm.backend == "sagellm":
        _ensure_sagellm_running(cfg)
    elif cfg.llm.backend == "ollama":
        _ensure_ollama_running(cfg)

    # ── 进入对话循环 ──────────────────────────────────────────────────
    _run_interactive_chat(cfg, model=resolved_model, system_prompt=system_prompt)


@app.command("rag", help="📚 构建并运行 RAG pipeline（--docs 指定文档目录）")
def run_rag(
    docs: Path | None = typer.Option(None, "--docs", "-d", help="文档目录路径"),
    query: str | None = typer.Option(None, "--query", "-q", help="直接执行一次查询（非交互模式）"),
    model: str | None = typer.Option(None, "--model", "-m", help="LLM 模型名称"),
    rebuild: bool = typer.Option(False, "--rebuild", help="强制重建向量索引"),
    no_studio: bool = typer.Option(False, "--no-studio", help="不自动启动 Studio"),
    top_k: int = typer.Option(5, "--top-k", "-k", help="检索 Top-K 个文档片段"),
) -> None:
    """📚 构建并运行 RAG pipeline。

    \b
    使用示例：
      sage run rag --docs ./papers/
      sage run rag --docs ./papers/ --query "什么是流式处理"
      sage run rag --docs ./papers/ --rebuild   # 重建索引
    """
    _ensure_setup()
    cfg = load_config()

    if docs is None:
        docs = Path(".")
        console.print(f"[dim]未指定 --docs，使用当前目录: {docs.resolve()}[/dim]")

    if not docs.exists():
        console.print(f"[red]错误：文档目录不存在：{docs}[/red]")
        raise typer.Exit(1)

    if not no_studio:
        _maybe_start_studio(cfg)

    console.print(
        Panel(
            f"[bold green]📚 SAGE RAG[/bold green]\n\n"
            f"  文档目录: [cyan]{docs.resolve()}[/cyan]\n"
            f"  模型:     [cyan]{model or cfg.llm.default_model}[/cyan]\n"
            f"  Top-K:    [cyan]{top_k}[/cyan]\n"
            + (_studio_status_line(cfg) if not no_studio else ""),
            title="sage run rag",
            border_style="green",
        )
    )

    try:
        from sage.cli.commands.apps.pipeline import build_rag_pipeline  # type: ignore  # noqa: F401

        _run_rag_pipeline(
            docs=docs, query=query, cfg=cfg, model=model, rebuild=rebuild, top_k=top_k
        )
    except ImportError:
        console.print("[yellow]RAG pipeline 模块加载中，请稍候...[/yellow]")
        _run_rag_fallback(docs=docs, query=query, cfg=cfg, model=model, top_k=top_k)


@app.command("gateway", help="🌐 启动 OpenAI 兼容 API 网关")
def run_gateway(
    port: int = typer.Option(8080, "--port", "-p", help="监听端口"),
    host: str = typer.Option("0.0.0.0", "--host", help="监听地址"),
    no_studio: bool = typer.Option(False, "--no-studio", help="不自动启动 Studio"),
    workers: int = typer.Option(1, "--workers", "-w", help="工作进程数"),
) -> None:
    """🌐 启动 OpenAI 兼容 API 网关。

    \b
    启动后可通过标准 OpenAI SDK 访问 SAGE 的所有能力：
      from openai import OpenAI
      client = OpenAI(base_url="http://localhost:8080/v1", api_key="sage")
    """
    _ensure_setup()
    cfg = load_config()

    if not no_studio:
        _maybe_start_studio(cfg)

    console.print(
        Panel(
            f"[bold blue]🌐 SAGE API Gateway[/bold blue]\n\n"
            f"  监听: [cyan]http://{host}:{port}[/cyan]\n"
            f"  后端: [cyan]{cfg.llm.backend}[/cyan]\n"
            f"  兼容: OpenAI API v1\n\n"
            f"  接口示例:\n"
            f'  [dim]curl http://localhost:{port}/v1/chat/completions -d \'{{"model":"sage","messages":[{{"role":"user","content":"你好"}}]}}\'[/dim]\n'
            + (_studio_status_line(cfg) if not no_studio else ""),
            title="sage run gateway",
            border_style="blue",
        )
    )

    try:
        from sage.cli.commands.apps.gateway import _start_gateway  # type: ignore

        _start_gateway(host=host, port=port, workers=workers)
    except (ImportError, AttributeError):
        _run_gateway_fallback(host=host, port=port, cfg=cfg)


@app.command("pipeline", help="🔧 执行自定义 sage.yaml 流水线")
def run_pipeline(
    pipeline_path: str = typer.Argument(
        ..., help="流水线文件路径（.yaml）或流水线名称（~/.sage/pipelines/）"
    ),
    no_studio: bool = typer.Option(False, "--no-studio", help="不自动启动 Studio"),
    dry_run: bool = typer.Option(False, "--dry-run", help="仅验证，不执行"),
    params: str | None = typer.Option(None, "--params", help="额外参数（JSON 格式）"),
) -> None:
    """🔧 执行自定义 sage.yaml 流水线。

    \b
    使用示例：
      sage run pipeline ./my_flow.yaml
      sage run pipeline my_named_pipeline      # 从 ~/.sage/pipelines/ 读取
      sage run pipeline ./flow.yaml --dry-run  # 仅验证
    """
    _ensure_setup()
    cfg = load_config()

    from sage.cli.core.setup_state import PIPELINES_DIR

    # 解析路径
    path = Path(pipeline_path)
    if not path.exists():
        named = PIPELINES_DIR / f"{pipeline_path}.yaml"
        if named.exists():
            path = named
        else:
            console.print(f"[red]错误：找不到流水线: {pipeline_path}[/red]")
            console.print(f"[dim]已搜索: {pipeline_path}  以及  {named}[/dim]")
            raise typer.Exit(1)

    if not no_studio:
        _maybe_start_studio(cfg)

    console.print(
        Panel(
            f"[bold magenta]🔧 SAGE Pipeline[/bold magenta]\n\n"
            f"  文件: [cyan]{path.resolve()}[/cyan]\n"
            f"  模式: {'[yellow]dry-run[/yellow]' if dry_run else '[green]执行[/green]'}\n"
            + (_studio_status_line(cfg) if not no_studio else ""),
            title="sage run pipeline",
            border_style="magenta",
        )
    )

    _run_yaml_pipeline(path=path, dry_run=dry_run, params_str=params, cfg=cfg)


@app.command("studio", help="🖥️  单独启动 SAGE Studio Web 看板")
def run_studio(
    port: int = typer.Option(7860, "--port", "-p", help="Studio 端口"),
    host: str = typer.Option("localhost", "--host", help="Studio 地址"),
    background: bool = typer.Option(False, "--background", "-b", help="后台运行"),
) -> None:
    """🖥️  启动 SAGE Studio Web 看板（类比 Flink Web UI）。

    \b
    Studio 提供：
      • Job / Pipeline 实时可视化
      • 资源使用监控
      • 日志查看
      • 配置管理
    """
    _start_studio(host=host, port=port, background=background)


@app.command("demo", help="🎮 快速体验 SAGE 示例")
def run_demo(
    name: str = typer.Argument("hello", help="示例名称（hello / rag / streaming / agentic）"),
) -> None:
    """🎮 运行快速体验示例。

    \b
    可用示例：
      hello       — Hello World（验证安装）
      rag         — RAG pipeline 体验
      streaming   — 流式处理演示
      agentic     — Agent 工具调用演示
    """
    _ensure_setup()

    try:
        from sage.cli.commands.demo import run_demo_by_name  # type: ignore

        run_demo_by_name(name)
    except (ImportError, AttributeError):
        _run_demo_fallback(name)


# ══════════════════════════════════════════════════════════════════════════
# Studio 集成（类 Flink Web UI）
# ══════════════════════════════════════════════════════════════════════════


def _maybe_start_studio(cfg) -> None:
    """如果 Studio 启用且配置了自动启动，在后台启动它。"""
    if not cfg.studio.enabled or not cfg.studio.auto_start:
        return

    if is_service_alive("studio"):
        url = f"http://{cfg.studio.host}:{cfg.studio.port}"
        console.print(f"[dim]📊 Studio 已运行: {url}[/dim]")
        return

    try:
        import sage.studio  # noqa: F401 — 检查是否安装
    except ImportError:
        return  # 未安装则跳过

    _start_studio(host=cfg.studio.host, port=cfg.studio.port, background=True, silent=True)


def _start_studio(
    host: str = "localhost",
    port: int = 7860,
    background: bool = False,
    silent: bool = False,
) -> None:
    """启动 SAGE Studio。"""
    try:
        import sage.studio  # noqa: F401
    except ImportError:
        if not silent:
            console.print(
                "[yellow]SAGE Studio 未安装。\n安装方式: pip install isage-studio[/yellow]"
            )
        return

    url = f"http://{host}:{port}"

    if not silent:
        console.print(f"[cyan]🖥️  启动 Studio: {url}[/cyan]")

    def _launch() -> None:
        try:
            proc = subprocess.Popen(
                [sys.executable, "-m", "sage.studio", "--host", host, "--port", str(port)],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                start_new_session=True,
            )
            register_service("studio", proc.pid, port=port, url=url)
            # 等待启动，最多 8 秒
            for _ in range(8):
                time.sleep(1)
                try:
                    import httpx

                    r = httpx.get(f"{url}/health", timeout=1.0)
                    if r.status_code == 200:
                        break
                except Exception:
                    pass
        except Exception:
            pass

    if background:
        t = threading.Thread(target=_launch, daemon=True)
        t.start()
        time.sleep(0.5)  # 短暂等待，确认进程已启动
        if not silent:
            console.print(f"  [dim]📊 Web 看板: {url}[/dim]")
    else:
        # 前台运行 — 等待进程结束
        _launch()


def _studio_status_line(cfg) -> str:
    """生成 Studio 地址行（用于 Panel 文本）。"""
    url = f"http://{cfg.studio.host}:{cfg.studio.port}"
    alive = is_service_alive("studio")
    status = "[green]运行中[/green]" if alive else "[dim]启动中...[/dim]"
    return f"\n  📊 Studio:  {url}  ({status})"


# ══════════════════════════════════════════════════════════════════════════
# 集群模式感知
# ══════════════════════════════════════════════════════════════════════════


def _cluster_mode_line() -> str:
    """返回一行集群模式描述（嵌入到 Panel 文本）。"""
    cluster = load_cluster_config()
    if cluster.is_distributed:
        n = len(cluster.workers)
        return f"  运行模式: [bold green]分布式集群[/bold green] ({n} workers)  [dim]master={cluster.master_host}:{cluster.master_port}[/dim]\n"
    return "  运行模式: [dim]本地单机[/dim]  [dim](编辑 ~/.sage/cluster.yaml 可启用分布式)[/dim]\n"


def _announce_cluster_mode() -> None:
    """在命令执行前打印集群模式提示，分布式时额外验证 SSH。"""
    cluster = load_cluster_config()

    if not cluster.is_distributed:
        console.print(f"[dim]运行模式：本地单机  (如需分布式，编辑 {CLUSTER_CONFIG_FILE})[/dim]")
        return

    n = len(cluster.workers)
    console.print(
        f"[bold green]🌐 分布式模式[/bold green]  "
        f"{n} workers  master=[cyan]{cluster.master_host}:{cluster.master_port}[/cyan]"
    )

    # 快速 SSH 可达性检测（非阻塞，仅给出警告）
    _verify_cluster_ssh(cluster)


def _verify_cluster_ssh(cluster) -> None:
    """对所有 worker 做一次快速 SSH 连通性检测，失败时打印可操作的提示。"""
    import socket

    ssh_user = cluster.ssh_user or os.environ.get("USER", "")
    ssh_port = cluster.ssh_port or 22

    failed: list[str] = []
    for w in cluster.workers:
        host = w.get("host", "") if isinstance(w, dict) else str(w)
        if not host:
            continue
        user = (w.get("user") if isinstance(w, dict) else None) or ssh_user
        port = (w.get("port") if isinstance(w, dict) else None) or ssh_port

        # TCP 层先探测（比完整 SSH 握手快）
        try:
            with socket.create_connection((host, int(port)), timeout=3):
                pass
        except OSError:
            failed.append(f"{user}@{host}:{port}")

    if failed:
        console.print(
            f"[yellow]⚠️  以下 {len(failed)} 个 worker 节点 SSH 端口不可达："
            f" {', '.join(failed)}[/yellow]"
        )
        console.print(
            "[dim]  将以本地降级模式继续运行。"
            f"\n  检查节点网络或参考 {CLUSTER_CONFIG_FILE} 中的 SSH 配置说明。[/dim]"
        )
    else:
        console.print(f"[dim]  ✅ 所有 {len(cluster.workers)} 个 worker 节点 SSH 端口可达[/dim]")


# ══════════════════════════════════════════════════════════════════════════
# LLM 后端启动辅助
# ══════════════════════════════════════════════════════════════════════════


def _ensure_sagellm_running(cfg) -> None:
    """如果 sageLLM 未运行则尝试在后台启动。"""
    if is_service_alive("sagellm"):
        return

    try:
        import sagellm  # noqa: F401
    except ImportError:
        console.print("[yellow]sageLLM 未安装，尝试连接现有服务...[/yellow]")
        return

    console.print(f"[dim]正在启动 sageLLM ({cfg.llm.default_model})...[/dim]")
    try:
        proc = subprocess.Popen(
            [
                sys.executable,
                "-m",
                "sagellm.server",
                "--model",
                cfg.llm.default_model,
                "--port",
                str(cfg.llm.port),
            ],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            start_new_session=True,
        )
        register_service("sagellm", proc.pid, port=cfg.llm.port)
        # 等待最多 30 秒
        for i in range(30):
            time.sleep(1)
            try:
                import httpx

                r = httpx.get(f"http://{cfg.llm.host}:{cfg.llm.port}/health", timeout=1.0)
                if r.status_code == 200:
                    console.print("[green]✅ sageLLM 已就绪[/green]")
                    return
            except Exception:
                if i % 5 == 0:
                    console.print(f"[dim]  等待 sageLLM 启动... ({i + 1}s)[/dim]")
        console.print("[yellow]sageLLM 启动超时，继续尝试连接...[/yellow]")
    except Exception as e:
        console.print(f"[yellow]无法自动启动 sageLLM: {e}[/yellow]")


def _ensure_ollama_running(cfg) -> None:
    """确认 Ollama 是否可访问。"""
    try:
        import httpx

        r = httpx.get(f"http://{cfg.llm.host}:{cfg.llm.port}/api/tags", timeout=2.0)
        if r.status_code == 200:
            return
    except Exception:
        pass

    if shutil.which("ollama"):
        console.print("[dim]正在启动 Ollama...[/dim]")
        subprocess.Popen(["ollama", "serve"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        time.sleep(3)
    else:
        console.print("[yellow]未找到 ollama 命令。请先安装: https://ollama.com[/yellow]")


# ══════════════════════════════════════════════════════════════════════════
# 对话循环（轻量实现，无重型依赖）
# ══════════════════════════════════════════════════════════════════════════


def _run_interactive_chat(cfg, *, model: str, system_prompt: str | None = None) -> None:
    """简单的终端对话循环（支持流式输出）。"""

    api_base = cfg.llm.api_base or f"http://{cfg.llm.host}:{cfg.llm.port}/v1"
    api_key = cfg.llm.api_key or "sage"

    try:
        from openai import OpenAI  # type: ignore

        client = OpenAI(base_url=api_base, api_key=api_key)
        messages = []
        if system_prompt:
            messages.append({"role": "system", "content": system_prompt})

        console.print("[dim]── 对话开始 ─────────────────────────────────────────────────[/dim]")
        while True:
            try:
                user_input = input("\n[你] ").strip()
            except (EOFError, KeyboardInterrupt):
                console.print("\n[dim]对话结束。[/dim]")
                break

            if not user_input:
                continue
            if user_input.lower() in ("/exit", "/quit", "/q"):
                console.print("[dim]再见！[/dim]")
                break

            messages.append({"role": "user", "content": user_input})
            console.print("\n[SAGE] ", end="", highlight=False)

            try:
                stream = client.chat.completions.create(
                    model=model,
                    messages=messages,
                    stream=True,
                )
                reply_parts = []
                for chunk in stream:
                    delta = chunk.choices[0].delta.content or ""
                    console.print(delta, end="", highlight=False)
                    reply_parts.append(delta)
                console.print("")
                messages.append({"role": "assistant", "content": "".join(reply_parts)})
            except Exception as e:
                console.print(f"\n[red]请求错误: {e}[/red]")
                console.print(
                    f"[dim]检查 LLM 服务是否运行: http://{cfg.llm.host}:{cfg.llm.port}[/dim]"
                )

    except ImportError:
        console.print(
            "[yellow]openai 库未安装，使用基础 HTTP 模式。\n"
            "可选：pip install openai  以启用更好的流式体验[/yellow]"
        )
        _run_basic_chat(cfg, model=model)


def _run_basic_chat(cfg, *, model: str) -> None:
    """不依赖 openai 库的基础对话（使用 httpx）。"""
    import json as _json

    import httpx

    api_base = cfg.llm.api_base or f"http://{cfg.llm.host}:{cfg.llm.port}/v1"
    api_key = cfg.llm.api_key or "sage"
    messages: list = []

    console.print("[dim]── 对话开始 ─────────────────────────────────────────────────[/dim]")
    while True:
        try:
            user_input = input("\n[你] ").strip()
        except (EOFError, KeyboardInterrupt):
            console.print("\n[dim]对话结束。[/dim]")
            break

        if not user_input or user_input.lower() in ("/exit", "/quit", "/q"):
            break

        messages.append({"role": "user", "content": user_input})
        console.print("\n[SAGE] ", end="", highlight=False)

        try:
            with httpx.stream(
                "POST",
                f"{api_base}/chat/completions",
                headers={"Authorization": f"Bearer {api_key}"},
                json={"model": model, "messages": messages, "stream": True},
                timeout=60.0,
            ) as r:
                reply = ""
                for line in r.iter_lines():
                    if line.startswith("data: ") and line != "data: [DONE]":
                        try:
                            data = _json.loads(line[6:])
                            delta = data["choices"][0]["delta"].get("content", "")
                            console.print(delta, end="", highlight=False)
                            reply += delta
                        except Exception:
                            pass
                console.print("")
                messages.append({"role": "assistant", "content": reply})
        except Exception as e:
            console.print(f"\n[red]请求错误: {e}[/red]")


# ══════════════════════════════════════════════════════════════════════════
# RAG 辅助
# ══════════════════════════════════════════════════════════════════════════


def _run_rag_pipeline(
    *, docs: Path, query: str | None, cfg, model: str | None, rebuild: bool, top_k: int
) -> None:
    """通过 sage-rag 包运行 RAG pipeline。"""
    try:
        from sage_rag.pipeline import SimpleRAGPipeline  # type: ignore

        pipeline = SimpleRAGPipeline(
            docs_dir=str(docs),
            llm_base_url=cfg.llm.api_base or f"http://{cfg.llm.host}:{cfg.llm.port}/v1",
            llm_api_key=cfg.llm.api_key or "sage",
            llm_model=model or cfg.llm.default_model,
            top_k=top_k,
        )
        if rebuild or not pipeline.index_exists():
            console.print("[dim]构建向量索引...[/dim]")
            pipeline.build_index()

        if query:
            result = pipeline.query(query)
            console.print(f"\n[bold]答案:[/bold] {result['answer']}")
        else:
            _run_rag_interactive(pipeline)
    except ImportError:
        _run_rag_fallback(docs=docs, query=query, cfg=cfg, model=model, top_k=top_k)


def _run_rag_fallback(*, docs: Path, query: str | None, cfg, model: str | None, top_k: int) -> None:
    """RAG 回退实现（不依赖 sage-rag）。"""
    console.print(
        f"[yellow]提示：安装 isage-rag 可获得完整 RAG 体验: pip install isage-rag[/yellow]\n"
        f"[dim]当前文档目录: {docs.resolve()}[/dim]"
    )
    if query:
        console.print(f"\n[dim]查询: {query}[/dim]")
        console.print("[yellow]RAG pipeline 尚未完全初始化，请先安装 isage-rag。[/yellow]")


def _run_rag_interactive(pipeline) -> None:  # type: ignore
    """RAG 交互式查询循环。"""
    console.print("[dim]── RAG 查询开始（输入 /exit 退出）────────────────────────[/dim]")
    while True:
        try:
            q = input("\n[问题] ").strip()
        except (EOFError, KeyboardInterrupt):
            break
        if not q or q.lower() in ("/exit", "/quit", "/q"):
            break
        result = pipeline.query(q)
        console.print(f"\n[bold]答案:[/bold] {result.get('answer', '无结果')}")
        if result.get("sources"):
            console.print(f"[dim]来源: {', '.join(result['sources'][:3])}[/dim]")


# ══════════════════════════════════════════════════════════════════════════
# Gateway 辅助
# ══════════════════════════════════════════════════════════════════════════


def _run_gateway_fallback(*, host: str, port: int, cfg) -> None:
    """网关回退：尝试通过 sagellm-gateway 启动。"""
    try:
        cmd = [
            sys.executable,
            "-m",
            "sagellm_gateway",
            "--host",
            host,
            "--port",
            str(port),
        ]
        proc = subprocess.run(cmd, check=False)
        if proc.returncode != 0:
            console.print(
                "[yellow]sagellm-gateway 启动失败。请安装: pip install isagellm-gateway[/yellow]"
            )
    except FileNotFoundError:
        console.print("[yellow]未找到网关模块。请安装: pip install isagellm-gateway[/yellow]")


# ══════════════════════════════════════════════════════════════════════════
# Pipeline 辅助
# ══════════════════════════════════════════════════════════════════════════


def _run_yaml_pipeline(*, path: Path, dry_run: bool, params_str: str | None, cfg) -> None:
    """执行 sage.yaml 流水线。"""
    import yaml  # type: ignore

    with open(path) as f:
        definition = yaml.safe_load(f)

    extra_params: dict = {}
    if params_str:
        import json as _json

        try:
            extra_params = _json.loads(params_str)
        except Exception:
            console.print(f"[yellow]警告：无法解析 --params JSON: {params_str}[/yellow]")

    if dry_run:
        console.print("[bold]── Pipeline 定义（dry-run）────────────────────────────[/bold]")
        import json as _json

        console.print(_json.dumps(definition, indent=2, ensure_ascii=False))
        console.print("[green]✅ 验证通过[/green]")
        return

    try:
        from sage.kernel.flow.pipeline import execute_pipeline  # type: ignore

        execute_pipeline(definition, extra_params=extra_params)
    except ImportError:
        console.print(
            "[yellow]提示：isage-kernel 未安装，无法执行 pipeline。\n"
            "安装: pip install isage-kernel[/yellow]"
        )


# ══════════════════════════════════════════════════════════════════════════
# Demo 辅助
# ══════════════════════════════════════════════════════════════════════════


def _run_demo_fallback(name: str) -> None:
    """Demo 回退实现。"""
    demos = {
        "hello": _demo_hello,
        "rag": lambda: console.print("[dim]用 sage run rag --docs ./docs 体验 RAG[/dim]"),
    }
    fn = demos.get(name)
    if fn:
        fn()
    else:
        console.print(f"[yellow]未知示例: {name}。可用: {list(demos.keys())}[/yellow]")


def _demo_hello() -> None:
    """Hello World 演示。"""
    console.print(
        Panel(
            "[bold green]🎉 Hello from SAGE![/bold green]\n\n"
            "SAGE (Streaming-Augmented Generative Execution) 安装成功！\n\n"
            "下一步：\n"
            "  [bold]sage run chat[/bold]              — 开始对话\n"
            "  [bold]sage run rag --docs ./docs[/bold]  — 构建 RAG\n"
            "  [bold]sage status[/bold]                — 查看服务状态\n"
            "  [bold]sage --help[/bold]                — 查看所有命令\n",
            title="sage run demo hello",
            border_style="green",
        )
    )


# ══════════════════════════════════════════════════════════════════════════
# Setup 检测
# ══════════════════════════════════════════════════════════════════════════


def _ensure_setup() -> None:
    """如果尚未 setup，提示用户并可选择立即执行；然后打印集群模式。"""
    from sage.cli.commands.setup.setup_cmd import ensure_setup_or_prompt

    if not ensure_setup_or_prompt():
        raise typer.Abort()
    _announce_cluster_mode()
