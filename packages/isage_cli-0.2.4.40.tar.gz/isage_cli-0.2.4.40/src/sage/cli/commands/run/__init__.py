"""commands/run — sage run 命令包。"""

from __future__ import annotations

from .run_cmd import app as run_app

__all__ = ["run_app"]
