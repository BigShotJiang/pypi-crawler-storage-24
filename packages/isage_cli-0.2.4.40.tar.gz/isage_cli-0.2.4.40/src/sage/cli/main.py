#!/usr/bin/env python3
"""SAGE CLI 主入口 — Ollama 风格的简洁体验。

快速开始（三步，类比 Ollama）：
  pip install isage           # 安装
  sage setup                  # 一次性初始化
  sage run chat               # 开始使用

常用命令：
  sage run chat               # 启动对话
  sage run rag --docs ./docs  # 构建 RAG
  sage run gateway            # 启动 API 网关
  sage status                 # 查看运行状态
  sage stop                   # 停止所有服务
  sage list                   # 列出可用 App
  sage pull <template>        # 拉取 pipeline 模板

进阶命令（含集群管理、作业调度等）：
  请使用  sage advanced --help  查看
"""

from __future__ import annotations

import logging
import os

# Suppress noisy INFO logs during CLI startup unless SAGE_CLI_VERBOSE is set
if not os.environ.get("SAGE_CLI_VERBOSE"):
    logging.basicConfig(level=logging.WARNING, format="%(message)s")
    for _logger in [
        "sage.platform",
        "sage.middleware",
        "sage.kernel",
        "sage.common",
        "faiss",
        "httpx",
        "httpcore",
    ]:
        logging.getLogger(_logger).setLevel(logging.WARNING)


import typer
from rich.console import Console

console = Console()

# ============================================================================
# 顶层应用（Ollama 风格：首屏展示 status dashboard）
# ============================================================================

app = typer.Typer(
    name="sage",
    help="""🚀 SAGE — Streaming-Augmented Generative Execution

    \b
    快速开始（三步）：
      pip install isage           ①  安装
      sage setup                  ②  一次性初始化（首次必须）
      sage run chat               ③  开始使用

    \b
    常用命令：
      sage run chat               — 启动 AI 对话
      sage run rag --docs ./docs  — 构建 RAG 问答
      sage run gateway            — 启动 OpenAI 兼容 API 网关
      sage run demo hello         — Hello World 快速体验
      sage status                 — 查看所有服务状态
      sage stop                   — 停止所有服务
      sage list                   — 列出可用 App
      sage pull rag-basic         — 拉取 Pipeline 模板

    \b
    开发工具（由独立的 sage-dev 提供）：
      sage-dev quality check      — 代码质量检查
      sage-dev project test       — 运行测试

    \b
    文档：https://intellistream.github.io/SAGE
    """,
    no_args_is_help=False,  # no-args → status dashboard
    invoke_without_command=True,
)


# ============================================================================
# 版本回调
# ============================================================================


def _version_callback(value: bool) -> None:
    if value:
        try:
            from sage.common._version import __version__

            typer.echo(f"SAGE version {__version__}")
        except ImportError:
            typer.echo("SAGE version unknown")
        raise typer.Exit()


# ============================================================================
# ① sage setup — 一次性初始化向导
# ============================================================================

try:
    from .commands.setup import setup_app

    app.add_typer(
        setup_app,
        name="setup",
        help="🔧 一次性初始化向导  (首次必须执行)",
    )
except ImportError as _e:
    console.print(f"[yellow]警告: 无法加载 setup 命令: {_e}[/yellow]")


# ============================================================================
# ② sage run — 统一运行入口
# ============================================================================

try:
    from .commands.run import run_app

    app.add_typer(
        run_app,
        name="run",
        help="▶️   运行 SAGE App（chat / rag / gateway / pipeline / demo）",
    )
except ImportError as _e:
    console.print(f"[yellow]警告: 无法加载 run 命令: {_e}[/yellow]")


# ============================================================================
# ③ sage status — 全局看板
# ============================================================================


@app.command("status", help="📊 查看所有 SAGE 服务状态（Web 看板: sage run studio）")
def status_cmd(
    watch: bool = typer.Option(False, "--watch", "-w", help="持续刷新（类 watch 命令）"),
    interval: int = typer.Option(3, "--interval", "-i", help="刷新间隔（秒）"),
) -> None:
    """📊 查看所有运行中的 SAGE 服务状态。"""
    from .commands.status_cmd import status_dashboard

    status_dashboard(watch=watch, interval=interval)


# ============================================================================
# ④ sage stop — 停止服务
# ============================================================================


@app.command("stop", help="⏹️  停止 SAGE 服务")
def stop_cmd(
    service: str | None = typer.Argument(
        None, help="服务名称（sagellm / studio / gateway / all），留空则停止全部"
    ),
) -> None:
    """⏹️  停止运行中的 SAGE 服务。

    \b
    示例：
      sage stop               # 停止所有服务
      sage stop studio        # 只停止 Studio
      sage stop sagellm       # 只停止 LLM 服务
    """
    from .commands.stop_cmd import stop_service

    name = None if (service is None or service == "all") else service
    stop_service(name)


# ============================================================================
# ⑤ sage list — 列出 App / Pipeline / 模型
# ============================================================================


@app.command("list", help="📋 列出可用 App、Pipeline 模板和 LLM 配置")
def list_cmd() -> None:
    """📋 列出所有可用的 SAGE App 和 Pipeline 模板。"""
    from .commands.list_cmd import list_all

    list_all()


# ============================================================================
# ⑥ sage pull — 拉取 Pipeline 模板
# ============================================================================


@app.command("pull", help="📦 拉取 Pipeline 模板到 ~/.sage/pipelines/")
def pull_cmd(
    name: str | None = typer.Argument(None, help="模板名称（留空则列出所有模板）"),
    list_only: bool = typer.Option(False, "--list", "-l", help="只列出可用模板"),
) -> None:
    """📦 拉取 Pipeline 模板（类比 docker pull）。

    \b
    示例：
      sage pull                  # 列出所有模板
      sage pull rag-basic        # 拉取 RAG 基础模板
      sage pull agentic-tools    # 拉取 Agent 工具调用模板
    """
    from .commands.pull_cmd import pull_template

    pull_template(name, list_only=list_only or name is None)


# ============================================================================
# ⑦ sage doctor — 系统诊断 (sub-commands: check, fix, compat)
# ============================================================================

try:
    from .commands.platform import doctor_app

    if doctor_app:
        app.add_typer(doctor_app, name="doctor", help="🔍 系统诊断 (check / fix / compat)")
except ImportError:
    pass


# ============================================================================
# ⑧ sage config — 配置管理
# ============================================================================

try:
    from .commands.platform import config_app

    if config_app:
        app.add_typer(config_app, name="config", help="⚙️  配置管理 (show / set / reset)")
except ImportError:
    pass


# ============================================================================
# ⑨ sage logs — 查看服务日志
# ============================================================================


@app.command("logs", help="📜 查看服务日志")
def logs_cmd(
    service: str = typer.Argument("sagellm", help="服务名称（sagellm / studio / gateway）"),
    follow: bool = typer.Option(False, "--follow", "-f", help="持续追踪（tail -f）"),
    lines: int = typer.Option(50, "--lines", "-n", help="显示最近 N 行"),
) -> None:
    """📜 查看 SAGE 服务日志。"""
    from sage.cli.core.setup_state import LOGS_DIR

    log_file = LOGS_DIR / f"{service}.log"
    if not log_file.exists():
        console.print(f"[dim]日志文件不存在: {log_file}[/dim]")
        return

    if follow:
        import subprocess

        subprocess.run(["tail", "-f", "-n", str(lines), str(log_file)])
    else:
        lines_text = log_file.read_text(encoding="utf-8").splitlines()[-lines:]
        console.print("\n".join(lines_text))


# ============================================================================
# ⑩ sage demo — 快速体验（别名，保持向后兼容）
# ============================================================================

try:
    from .commands.demo import app as demo_app

    app.add_typer(
        demo_app,
        name="demo",
        help="🎮 快速体验示例（等同于 sage run demo）",
    )
except ImportError:
    pass


# ============================================================================
# ⑪ sage advanced — 高级/专家命令组（集群管理、作业调度等）
# ============================================================================

advanced_app = typer.Typer(
    name="advanced",
    help="🔬 高级命令（集群管理、作业调度、运行时诊断等）",
    no_args_is_help=True,
)
app.add_typer(advanced_app, name="advanced", help="🔬 高级命令（集群、作业、运行时管理）")

_DEPRECATED_HELP = {
    "cluster": ("🌐 集群管理", "sage advanced cluster"),
    "head": ("🎯 头节点管理", "sage advanced head"),
    "worker": ("🔧 工作节点管理", "sage advanced worker"),
    "job": ("📋 作业管理", "sage advanced job"),
    "jobmanager": ("⚡ JobManager", "sage advanced jobmanager"),
    "runtime": ("⚙️  运行时诊断", "sage advanced runtime"),
    "extensions": ("🧩 扩展管理", "sage advanced extensions"),
    "docs": ("📚 文档管理", "sage advanced docs"),
    "version": ("📋 版本信息", "sage advanced version"),
    "llm": ("🤖 LLM 服务管理", "sage advanced llm"),
    "chat": ("🧭 编程助手(legacy)", "sage run chat"),
    "gateway": ("🌐 API Gateway", "sage run gateway"),
    "pipeline": ("🧱 Pipeline Builder", "sage run pipeline"),
    "embedding": ("🎯 Embedding 管理", "sage advanced embedding"),
    "inference": ("🔮 统一推理服务", "sage advanced inference"),
}


def _register_platform_in_advanced() -> None:
    """将所有 Platform / Apps 命令注册到 sage advanced，并在顶层保留（带废弃警告）。"""
    try:
        from .commands.platform import (
            cluster_app,
            docs_app,
            extensions_app,
            head_app,
            job_app,
            jobmanager_app,
            runtime_app,
            version_app,
            worker_app,
        )

        _map = {
            "cluster": cluster_app,
            "head": head_app,
            "worker": worker_app,
            "job": job_app,
            "jobmanager": jobmanager_app,
            "runtime": runtime_app,
            "extensions": extensions_app,
            "docs": docs_app,
            "version": version_app,
        }
        for name, sub_app in _map.items():
            if sub_app:
                label, new_cmd = _DEPRECATED_HELP.get(name, (name, f"sage advanced {name}"))
                advanced_app.add_typer(sub_app, name=name, help=label)
                # 顶层保留（带 deprecated 提示）
                _add_deprecated_alias(name, sub_app, new_cmd)
    except ImportError:
        pass

    try:
        from .commands.apps import (
            chat_app,
            embedding_app,
            gateway_app,
            inference_app,
            llm_app,
            pipeline_app,
        )

        _app_map = {
            "llm": llm_app,
            "chat": chat_app,
            "embedding": embedding_app,
            "pipeline": pipeline_app,
            "inference": inference_app,
            "gateway": gateway_app,
        }
        for name, sub_app in _app_map.items():
            if sub_app:
                label, new_cmd = _DEPRECATED_HELP.get(name, (name, f"sage run {name}"))
                advanced_app.add_typer(sub_app, name=name, help=label)
                _add_deprecated_alias(name, sub_app, new_cmd)
    except ImportError:
        pass


def _add_deprecated_alias(name: str, sub_app: typer.Typer, new_cmd: str) -> None:
    """在顶层注册旧命令（加废弃提示）。"""
    warn_help = f"[已迁移] 请使用: {new_cmd}"
    # 直接注册（仍可用），但 help 文字提示迁移
    app.add_typer(sub_app, name=name, help=f"⚠️  {warn_help}", hidden=False)


_register_platform_in_advanced()


# ============================================================================
# 插件加载（sage-studio 等通过 entry points 注册）
# ============================================================================


def _load_cli_plugins() -> None:
    try:
        from importlib.metadata import entry_points

        for ep in entry_points(group="sage.cli.plugins"):
            try:
                ep.load()(app)
            except Exception:
                pass
    except Exception:
        pass


_load_cli_plugins()


# ============================================================================
# 顶层回调：no-args → status dashboard
# ============================================================================


@app.callback(invoke_without_command=True)
def main(
    ctx: typer.Context,
    version: bool | None = typer.Option(
        None, "--version", "-v", help="显示版本信息", callback=_version_callback, is_eager=True
    ),
) -> None:
    """🚀 SAGE — Streaming-Augmented Generative Execution"""
    if ctx.invoked_subcommand is None:
        # No subcommand → show status dashboard
        from .commands.status_cmd import status_dashboard

        status_dashboard()


if __name__ == "__main__":
    app()
