"""Version information for sage-cli."""

__version__ = "0.2.4.40"
__author__ = "IntelliStream Team"
__email__ = "shuhao_zhang@hust.edu.cn"
