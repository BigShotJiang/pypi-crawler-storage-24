"""SAGE 安装状态管理 — 负责 ~/.sage/ 目录的读写与版本化。

记录一次性 setup 结果，支持：
- setup 完成标记（避免重复执行）
- LLM 后端配置（sageLLM / ollama / API key）
- 工作目录路径
- Studio 地址
- 集群配置（本地单机 / 分布式集群）

运行模式：
  本地模式（默认）— 开箱即用，无需额外配置
  分布式模式      — 编辑 ~/.sage/cluster.yaml 后自动生效，命令不变
"""

from __future__ import annotations

import json
import os
import shutil
import sys
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any

# ── 工作目录 ──────────────────────────────────────────────────────────────
SAGE_HOME = Path(os.environ.get("SAGE_HOME", Path.home() / ".sage"))
CONFIG_FILE = SAGE_HOME / "config.json"
CLUSTER_CONFIG_FILE = SAGE_HOME / "cluster.yaml"
STATE_FILE = SAGE_HOME / "state.json"
PIPELINES_DIR = SAGE_HOME / "pipelines"
MODELS_DIR = SAGE_HOME / "models"
LOGS_DIR = SAGE_HOME / "logs"
PIDS_FILE = SAGE_HOME / "pids.json"


# ── 数据模型 ───────────────────────────────────────────────────────────────


@dataclass
class LLMBackendConfig:
    """LLM 后端配置（支持 sageLLM / ollama / openai-compatible API）。"""

    backend: str = "sagellm"  # sagellm | ollama | openai | custom
    host: str = "localhost"
    port: int = 8000
    api_key: str = ""
    api_base: str = ""
    default_model: str = "Qwen/Qwen2.5-0.5B-Instruct"
    embedding_model: str = "BAAI/bge-small-zh-v1.5"


@dataclass
class StudioConfig:
    """SAGE Studio Web UI 配置。"""

    enabled: bool = True
    host: str = "localhost"
    port: int = 7860
    auto_start: bool = True  # 执行 sage run 时自动启动 Studio


@dataclass
class ClusterNodeConfig:
    """集群单节点配置。"""

    host: str = "localhost"
    port: int = 22  # SSH 端口
    user: str = ""  # SSH 用户名，空则使用当前用户
    role: str = "worker"  # master | worker


@dataclass
class ClusterConfig:
    """SAGE 集群配置。

    默认为本地单机模式（mode="local"），无需任何额外配置即可运行。
    分布式模式通过编辑 ~/.sage/cluster.yaml 开启，命令本身不变。
    """

    mode: str = "local"  # local | distributed
    # 当 mode=distributed 时有效的字段：
    master_host: str = "localhost"
    master_port: int = 7077  # Flownet master 端口（类比 Spark master）
    dashboard_port: int = 8088  # 集群 dashboard 端口
    ssh_user: str = ""  # 空 = 当前用户
    ssh_key_path: str = ""  # 空 = 使用 ssh-agent / 默认 key
    ssh_port: int = 22
    workers: list[dict[str, Any]] = field(default_factory=list)
    # 示例 workers:
    # - host: 192.168.1.101
    #   user: ubuntu           # 可选，覆盖 ssh_user
    #   port: 22               # 可选，覆盖 ssh_port
    # - host: 192.168.1.102

    @property
    def is_distributed(self) -> bool:
        return self.mode == "distributed" and bool(self.workers)


@dataclass
class SageConfig:
    """SAGE 全局配置（写入 ~/.sage/config.json）。"""

    version: int = 2
    setup_completed: bool = False
    install_mode: str = "local"  # local | api | advanced
    workspace: str = str(SAGE_HOME)
    llm: LLMBackendConfig = field(default_factory=LLMBackendConfig)
    studio: StudioConfig = field(default_factory=StudioConfig)
    cluster: ClusterConfig = field(default_factory=ClusterConfig)
    extra: dict[str, Any] = field(default_factory=dict)

    def dict(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> SageConfig:
        llm_data = data.pop("llm", {})
        studio_data = data.pop("studio", {})
        cluster_data = data.pop("cluster", {})
        cfg = cls(**{k: v for k, v in data.items() if k in cls.__dataclass_fields__})
        cfg.llm = LLMBackendConfig(
            **{k: v for k, v in llm_data.items() if k in LLMBackendConfig.__dataclass_fields__}
        )
        cfg.studio = StudioConfig(
            **{k: v for k, v in studio_data.items() if k in StudioConfig.__dataclass_fields__}
        )
        # ClusterConfig.workers 是 list，需要特殊处理
        workers = cluster_data.pop("workers", [])
        cfg.cluster = ClusterConfig(
            **{
                k: v
                for k, v in cluster_data.items()
                if k in ClusterConfig.__dataclass_fields__ and k != "workers"
            },
            workers=workers,
        )
        return cfg


# ── 读 / 写 ────────────────────────────────────────────────────────────────


def ensure_sage_home() -> None:
    """确保 ~/.sage/ 目录及子目录存在。"""
    for d in (SAGE_HOME, PIPELINES_DIR, MODELS_DIR, LOGS_DIR):
        d.mkdir(parents=True, exist_ok=True)


def load_config() -> SageConfig:
    """读取配置文件，不存在则返回默认配置。"""
    ensure_sage_home()
    if not CONFIG_FILE.exists():
        return SageConfig()
    try:
        data = json.loads(CONFIG_FILE.read_text(encoding="utf-8"))
        return SageConfig.from_dict(data)
    except Exception:
        return SageConfig()


def save_config(cfg: SageConfig) -> None:
    """持久化配置到 ~/.sage/config.json。"""
    ensure_sage_home()
    CONFIG_FILE.write_text(
        json.dumps(cfg.dict(), indent=2, ensure_ascii=False),
        encoding="utf-8",
    )


def is_setup_done() -> bool:
    """检查 sage setup 是否已完成。"""
    return load_config().setup_completed


def mark_setup_done(cfg: SageConfig | None = None) -> None:
    """标记 setup 完成。"""
    config = cfg or load_config()
    config.setup_completed = True
    save_config(config)


# ── cluster.yaml 模板 ──────────────────────────────────────────────────────

_CLUSTER_YAML_TEMPLATE = """\
# SAGE 集群配置 — ~/.sage/cluster.yaml
#
# 默认为本地单机模式：开箱即用，无需任何修改。
# 要启用分布式集群，只需：
#   1. 将 mode 改为 distributed
#   2. 填写 workers 节点 IP 列表
#   3. 确保所有节点已配置 passwordless SSH（见下方说明）
#   4. 重新运行 sage run <app>  — 命令本身不变
#
# ─────────────────────────────────────────────────────
# ✅ 本地单机模式（默认）
# ─────────────────────────────────────────────────────
mode: local   # local | distributed

# ─────────────────────────────────────────────────────
# 以下配置仅在 mode: distributed 时生效
# ─────────────────────────────────────────────────────

# Master 节点（通常是运行 sage 命令的当前机器）
master:
  host: localhost
  port: 7077          # Flownet master 端口
  dashboard_port: 8088  # 集群 Web 看板端口

# SSH 配置（无密码 SSH 是分布式运行的前提）
ssh:
  user: ""            # SSH 用户名，空 = 使用当前用户
  key_path: ""        # SSH 私钥路径，空 = 使用默认 (~/.ssh/id_rsa)
  port: 22            # SSH 端口

# Worker 节点列表
# 每行一个节点，只需填写 host 即可，其余字段可覆盖全局 SSH 配置
workers: []
# 示例（取消注释后修改 IP 地址）：
# workers:
#   - host: 192.168.1.101        # Worker 节点 1
#   - host: 192.168.1.102        # Worker 节点 2
#   - host: 192.168.1.103
#     user: ubuntu               # 覆盖 ssh.user（可选）
#     key_path: ~/.ssh/server_key  # 覆盖 ssh.key_path（可选）

# ─────────────────────────────────────────────────────
# 💡 快速设置 Passwordless SSH 说明
# ─────────────────────────────────────────────────────
# 在 master 节点执行：
#   ssh-keygen -t rsa -b 4096 -N "" -f ~/.ssh/id_rsa   # 生成密钥（如已有可跳过）
#   ssh-copy-id -i ~/.ssh/id_rsa.pub user@192.168.1.101
#   ssh-copy-id -i ~/.ssh/id_rsa.pub user@192.168.1.102
# 验证：
#   ssh user@192.168.1.101 "hostname"  # 应无密码提示直接返回
# 或者一键部署（需要 sage cluster 命令）：
#   sage cluster setup-ssh             # 交互式引导完成所有节点的密钥分发
"""


def generate_cluster_yaml() -> None:
    """生成 ~/.sage/cluster.yaml 模板（如已存在则跳过）。"""
    ensure_sage_home()
    if not CLUSTER_CONFIG_FILE.exists():
        CLUSTER_CONFIG_FILE.write_text(_CLUSTER_YAML_TEMPLATE, encoding="utf-8")


def load_cluster_config() -> ClusterConfig:
    """从 ~/.sage/cluster.yaml 读取集群配置。

    - 文件不存在或 mode=local → 返回默认本地配置
    - mode=distributed → 解析 workers 列表
    """
    ensure_sage_home()
    if not CLUSTER_CONFIG_FILE.exists():
        return ClusterConfig()

    try:
        # 使用 PyYAML 解析；PyYAML 是 SAGE 常用依赖，不额外引入
        import yaml  # type: ignore
    except ImportError:
        # 降级：仅支持本地模式
        return ClusterConfig()

    try:
        data = yaml.safe_load(CLUSTER_CONFIG_FILE.read_text(encoding="utf-8")) or {}
    except Exception:
        return ClusterConfig()

    mode = data.get("mode", "local")
    master_data = data.get("master", {})
    ssh_data = data.get("ssh", {})
    workers_raw = data.get("workers") or []

    workers = []
    for w in workers_raw:
        if isinstance(w, str):
            workers.append({"host": w})
        elif isinstance(w, dict):
            workers.append(w)

    return ClusterConfig(
        mode=mode,
        master_host=master_data.get("host", "localhost"),
        master_port=master_data.get("port", 7077),
        dashboard_port=master_data.get("dashboard_port", 8088),
        ssh_user=ssh_data.get("user", ""),
        ssh_key_path=ssh_data.get("key_path", ""),
        ssh_port=ssh_data.get("port", 22),
        workers=workers,
    )


# ── 运行时 PID 状态 ────────────────────────────────────────────────────────


def load_pids() -> dict[str, Any]:
    """读取运行中的服务 PID 表。"""
    ensure_sage_home()
    if not PIDS_FILE.exists():
        return {}
    try:
        return json.loads(PIDS_FILE.read_text(encoding="utf-8"))
    except Exception:
        return {}


def save_pids(pids: dict[str, Any]) -> None:
    """写入 PID 表。"""
    ensure_sage_home()
    PIDS_FILE.write_text(json.dumps(pids, indent=2), encoding="utf-8")


def register_service(name: str, pid: int, port: int | None = None, url: str | None = None) -> None:
    """注册一个正在运行的服务。"""
    pids = load_pids()
    pids[name] = {"pid": pid, "port": port, "url": url}
    save_pids(pids)


def unregister_service(name: str) -> None:
    """注销服务记录。"""
    pids = load_pids()
    pids.pop(name, None)
    save_pids(pids)


def is_service_alive(name: str) -> bool:
    """检查已注册的服务是否仍在运行（通过 PID）。"""
    pids = load_pids()
    entry = pids.get(name)
    if not entry:
        return False
    pid = entry.get("pid")
    if not pid:
        return False
    try:
        os.kill(int(pid), 0)
        return True
    except (ProcessLookupError, PermissionError, OSError):
        return False


def alive_services() -> dict[str, Any]:
    """返回所有存活服务的字典。"""
    pids = load_pids()
    return {name: info for name, info in pids.items() if is_service_alive(name)}


# ── 工具 ───────────────────────────────────────────────────────────────────


def sage_home_info() -> dict[str, Any]:
    """返回工作目录的摘要信息（用于 sage status）。"""
    cfg = load_config()
    return {
        "home": str(SAGE_HOME),
        "setup_done": cfg.setup_completed,
        "llm_backend": cfg.llm.backend,
        "llm_model": cfg.llm.default_model,
        "studio_port": cfg.studio.port,
        "studio_auto_start": cfg.studio.auto_start,
    }


def detect_python() -> str:
    """返回当前 Python 可执行路径。"""
    return sys.executable


def is_conda_env() -> bool:
    """检测是否在 conda 环境中。"""
    return "conda" in sys.executable or bool(os.environ.get("CONDA_DEFAULT_ENV"))


def detect_gpu() -> dict[str, Any]:
    """简单探测 CUDA / ROCm 可用性（不导入 torch）。"""
    result: dict[str, Any] = {"cuda": False, "rocm": False, "device": "cpu"}
    if shutil.which("nvidia-smi"):
        result["cuda"] = True
        result["device"] = "cuda"
    elif shutil.which("rocm-smi"):
        result["rocm"] = True
        result["device"] = "rocm"
    return result
