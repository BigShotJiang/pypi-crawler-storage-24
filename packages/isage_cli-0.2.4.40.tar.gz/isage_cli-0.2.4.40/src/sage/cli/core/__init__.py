"""
SAGE - Streaming-Augmented Generative Execution
"""

# 直接从本包的_version模块加载版本信息
from sage.cli._version import (  # type: ignore[import-not-found]
    __author__ as __author__,
)
from sage.cli._version import (
    __email__ as __email__,
)
from sage.cli._version import (
    __version__ as __version__,
)
