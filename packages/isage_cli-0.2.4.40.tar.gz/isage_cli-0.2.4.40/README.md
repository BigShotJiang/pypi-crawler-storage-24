# SAGE CLI — isage-cli

[![PyPI version](https://badge.fury.io/py/isage-cli.svg)](https://badge.fury.io/py/isage-cli)
[![Python 3.11+](https://img.shields.io/badge/python-3.11+-blue.svg)](https://www.python.org/downloads/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](LICENSE)

**SAGE CLI** is the unified command-line interface for the SAGE platform (L5 Interface Layer).

## Layer Info

| Property | Value |
|---|---|
| Layer | **L5** (Interface Layer — top of the stack) |
| PyPI | `isage-cli` |
| Import | `sage.cli` |
| Depends on | `isage-common` (L1), `isage-kernel` (L3), `isage-middleware` (L4) |

## Features

- **App management** — run, stop, status for SAGE apps
- **LLM service control** — start, stop, status for LLM services
- **Cluster management** — head/worker node management
- **Pipeline management** — pipeline lifecycle commands
- **Platform utilities** — env, config, logs, extensions, doctor

## Installation

```bash
pip install isage-cli
```

## Quick Start

```bash
# Show all commands
sage --help

# Check environment
sage platform doctor

# Start LLM service
sage app llm start --model llama3
```

## Development Setup

```bash
git clone https://github.com/intellistream/sage-cli.git
cd sage-cli
./quickstart.sh --dev --yes
```

## Architecture

```
sage.cli (L5)
├── commands/
│   ├── apps/        — App-level commands (chat, embedding, gateway, inference, llm, pipeline)
│   └── platform/    — Platform commands (cluster, config, docs, doctor, env, job, logs, ...)
└── core/            — Base classes, config, exceptions, output utilities
```

## Related Repositories

| Package | Layer | Purpose |
|---|---|---|
| [isage-common](https://github.com/intellistream/sage-common) | L1 | Core utilities, config, logging |
| [isage-kernel](https://github.com/intellistream/sage-kernel) | L3 | Streaming runtime, scheduler, flow DSL |
| [isage-middleware](https://github.com/intellistream/sage-middleware) | L4 | Domain operators, service components |

## License

MIT — see [LICENSE](LICENSE).
