"""
Custom exceptions with helpful error messages and suggestions.

These exceptions provide PyTorch-style error messages with:
- Clear explanations of what went wrong
- Concrete suggestions for fixes
- Relevant context (parameter names, types, etc.)
"""

from __future__ import annotations

from typing import Any, Dict


class SelectoolsError(Exception):
    """Base exception for all selectools errors."""

    pass


class ToolValidationError(SelectoolsError):
    """Raised when tool parameters are invalid."""

    def __init__(self, tool_name: str, param_name: str, issue: str, suggestion: str = ""):
        self.tool_name = tool_name
        self.param_name = param_name
        self.issue = issue
        self.suggestion = suggestion

        message = f"\n{'='*60}\n"
        message += f"❌ Tool Validation Error: '{tool_name}'\n"
        message += f"{'='*60}\n\n"
        message += f"Parameter: {param_name}\n"
        message += f"Issue: {issue}\n"
        if suggestion:
            message += f"\n💡 Suggestion: {suggestion}\n"
        message += f"\n{'='*60}\n"

        super().__init__(message)


class ToolExecutionError(SelectoolsError):
    """Raised when tool execution fails."""

    def __init__(self, tool_name: str, error: Exception, params: Dict[str, Any]):
        self.tool_name = tool_name
        self.error = error
        self.params = params

        message = f"\n{'='*60}\n"
        message += f"❌ Tool Execution Failed: '{tool_name}'\n"
        message += f"{'='*60}\n\n"
        message += f"Error: {type(error).__name__}: {str(error)}\n"
        message += f"Parameters: {params}\n"
        message += f"\n💡 Check that:\n"
        message += f"  - All required parameters are provided\n"
        message += f"  - Parameter types match the tool's schema\n"
        message += f"  - The tool function is correctly implemented\n"
        message += f"\n{'='*60}\n"

        super().__init__(message)


class ProviderConfigurationError(SelectoolsError):
    """Raised when provider configuration is incorrect."""

    def __init__(self, provider_name: str, missing_config: str, env_var: str = ""):
        self.provider_name = provider_name
        self.missing_config = missing_config
        self.env_var = env_var

        message = f"\n{'='*60}\n"
        message += f"❌ Provider Configuration Error: '{provider_name}'\n"
        message += f"{'='*60}\n\n"
        message += f"Missing: {missing_config}\n"
        if env_var:
            message += f"\n💡 How to fix:\n"
            message += f"  1. Set the environment variable:\n"
            message += f"     export {env_var}='your-api-key'\n"
            message += f"  2. Or pass it directly:\n"
            message += f"     provider = {provider_name}Provider(api_key='your-api-key')\n"
        message += f"\n{'='*60}\n"

        super().__init__(message)


class MemoryLimitExceededError(SelectoolsError):
    """Raised when memory limits are exceeded."""

    def __init__(self, current: int, limit: int, limit_type: str):
        self.current = current
        self.limit = limit
        self.limit_type = limit_type

        message = f"\n{'='*60}\n"
        message += f"⚠️  Memory Limit Exceeded\n"
        message += f"{'='*60}\n\n"
        message += f"Limit Type: {limit_type}\n"
        message += f"Current: {current}\n"
        message += f"Limit: {limit}\n"
        message += f"\n💡 Suggestions:\n"
        if limit_type == "messages":
            message += f"  - Increase max_messages: ConversationMemory(max_messages={limit * 2})\n"
            message += f"  - Clear older messages manually: memory.clear()\n"
        elif limit_type == "tokens":
            message += f"  - Increase max_tokens: ConversationMemory(max_tokens={limit * 2})\n"
            message += f"  - Use shorter messages\n"
            message += f"  - Enable conversation summarization (coming in v0.6.0)\n"
        message += f"\n{'='*60}\n"

        super().__init__(message)


class GraphExecutionError(SelectoolsError):
    """Raised when a graph execution node fails."""

    def __init__(
        self,
        graph_name: str,
        node_name: str,
        error: Exception,
        step: int = 0,
    ):
        self.graph_name = graph_name
        self.node_name = node_name
        self.error = error
        self.step = step

        message = f"\n{'='*60}\n"
        message += f"❌ Graph Execution Failed: '{graph_name}'\n"
        message += f"{'='*60}\n\n"
        message += f"Node: {node_name} (step {step})\n"
        message += f"Error: {type(error).__name__}: {str(error)}\n"
        message += f"\n💡 Check that:\n"
        message += f"  - The node '{node_name}' is correctly configured\n"
        message += f"  - All required inputs are available at step {step}\n"
        message += f"  - The node's agent or function is working correctly\n"
        message += f"\n{'='*60}\n"

        super().__init__(message)


class BudgetExceededError(SelectoolsError):
    """Raised when an agent run exceeds its token or cost budget."""

    def __init__(self, reason: str, tokens_used: int = 0, cost_used: float = 0.0):
        self.reason = reason
        self.tokens_used = tokens_used
        self.cost_used = cost_used
        super().__init__(reason)


class CancellationError(SelectoolsError):
    """Raised when an agent run is cancelled via a CancellationToken."""

    def __init__(self, reason: str = "Agent run was cancelled"):
        self.reason = reason
        super().__init__(reason)


class MCPError(SelectoolsError):
    """Base class for MCP-related errors."""


class MCPConnectionError(MCPError):
    """Raised when an MCP server connection fails."""


class MCPToolError(MCPError):
    """Raised when an MCP tool call fails."""


__all__ = [
    "SelectoolsError",
    "ToolValidationError",
    "ToolExecutionError",
    "ProviderConfigurationError",
    "MemoryLimitExceededError",
    "GraphExecutionError",
    "BudgetExceededError",
    "CancellationError",
    "MCPError",
    "MCPConnectionError",
    "MCPToolError",
]
