#
# Copyright (C) 2025 Bruce Ashfield <bruce.ashfield@gmail.com>
#
# SPDX-License-Identifier: GPL-2.0-only
#
"""Web server for bit — ThreadingHTTPServer with routing and static file serving."""

import importlib.resources
import json
import mimetypes
import os
import queue
import re
import socket
import ssl
import sys
import tempfile
import time
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from typing import Any, Callable, Dict, List, Optional, Tuple
from urllib.parse import parse_qs, unquote, urlparse

from .sse import SSEManager, format_sse

# Static file directory — works both from filesystem installs and zipapps
STATIC_DIR = os.path.join(os.path.dirname(__file__), "static")
_static_extracted_dir: Optional[str] = None  # lazily populated for zipapps

# Cache-busting version string — changes on every server startup so browsers
# fetch fresh CSS/JS.  Injected into index.html as ?v=<stamp>.
_STARTUP_VERSION = str(int(time.time()))
_CACHEBUST_RE = re.compile(rb'((?:href|src)="[^"]+\.(?:css|js))(">)', re.IGNORECASE)


def _get_static_dir() -> str:
    """Return path to static files, extracting from package if needed (zipapp)."""
    global _static_extracted_dir
    if os.path.isdir(STATIC_DIR):
        return STATIC_DIR
    # Running from zipapp — extract static files to a temp directory
    if _static_extracted_dir and os.path.isdir(_static_extracted_dir):
        return _static_extracted_dir
    _static_extracted_dir = tempfile.mkdtemp(prefix="bit-web-static-")
    _extract_package_static(_static_extracted_dir)
    return _static_extracted_dir


def _extract_package_static(dest: str) -> None:
    """Extract static/ tree from the package data into *dest*.

    Tries importlib.resources first (works for installed packages), then
    falls back to zipfile extraction (works for zipapps).
    """
    # Try importlib.resources (installed packages, eggs)
    try:
        static_pkg = importlib.resources.files("bitbake_project.web").joinpath("static")
        _copy_resource_tree(static_pkg, dest)
        if os.listdir(dest):
            return
    except Exception:
        pass

    # Fallback: extract from the zipapp archive directly
    _extract_from_zipapp(dest)


def _copy_resource_tree(resource, dest: str) -> None:
    """Recursively copy an importlib.resources Traversable tree to disk."""
    os.makedirs(dest, exist_ok=True)
    for item in resource.iterdir():
        target = os.path.join(dest, item.name)
        if item.is_file():
            with open(target, "wb") as f:
                f.write(item.read_bytes())
        elif item.is_dir():
            _copy_resource_tree(item, target)


def _extract_from_zipapp(dest: str) -> None:
    """Extract static files from the zipapp archive."""
    import zipfile
    # Find the zipapp archive — walk sys.path for zip files containing our package
    for p in sys.path:
        if not zipfile.is_zipfile(p):
            continue
        try:
            with zipfile.ZipFile(p, "r") as zf:
                prefix = "bitbake_project/web/static/"
                members = [n for n in zf.namelist() if n.startswith(prefix)]
                if not members:
                    continue
                for member in members:
                    rel = member[len(prefix):]
                    if not rel:
                        continue
                    target = os.path.join(dest, rel)
                    if member.endswith("/"):
                        os.makedirs(target, exist_ok=True)
                    else:
                        os.makedirs(os.path.dirname(target), exist_ok=True)
                        with zf.open(member) as src, open(target, "wb") as dst:
                            dst.write(src.read())
                return
        except Exception:
            continue

# Route table: (method, compiled_regex, handler_name)
_routes: List[Tuple[str, "re.Pattern", str]] = []


def route(method: str, pattern: str):
    """Decorator to register a route handler."""
    compiled = re.compile(f"^{pattern}$")
    def decorator(func):
        _routes.append((method, compiled, func))
        return func
    return decorator


class BitWebHandler(BaseHTTPRequestHandler):
    """HTTP request handler with routing, JSON helpers, and static serving."""

    # HTTP/1.1 required for WebSocket upgrade and keep-alive
    protocol_version = "HTTP/1.1"

    # Suppress default logging
    def log_message(self, format, *args):
        pass

    @property
    def sse(self) -> SSEManager:
        return self.server.sse_manager

    def _parse_url(self):
        parsed = urlparse(self.path)
        self._url_path = unquote(parsed.path).rstrip("/") or "/"
        self._query = parse_qs(parsed.query)
        return self._url_path

    def _query_param(self, name: str, default: str = "") -> str:
        return self._query.get(name, [default])[0]

    def _send_json(self, data: Any, status: int = 200) -> None:
        body = json.dumps(data).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(body)

    def _send_error_json(self, status: int, message: str) -> None:
        self._send_json({"error": message}, status)

    def _read_json(self) -> Optional[dict]:
        length = int(self.headers.get("Content-Length", 0))
        if length == 0:
            return {}
        try:
            body = self.rfile.read(length)
            return json.loads(body)
        except (json.JSONDecodeError, ValueError):
            return None

    def _send_text(self, text: str, content_type: str = "text/plain", status: int = 200) -> None:
        body = text.encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _serve_static(self, path: str) -> None:
        """Serve a static file from the static/ directory."""
        # Normalize and guard against path traversal
        if path == "/" or path == "":
            path = "/index.html"
        # Remove leading slash
        rel = path.lstrip("/")
        static_dir = _get_static_dir()
        filepath = os.path.normpath(os.path.join(static_dir, rel))
        if not filepath.startswith(os.path.normpath(static_dir)):
            self._send_error_json(403, "Forbidden")
            return
        if not os.path.isfile(filepath):
            self._send_error_json(404, f"Not found: {path}")
            return
        content_type, _ = mimetypes.guess_type(filepath)
        if content_type is None:
            content_type = "application/octet-stream"
        try:
            with open(filepath, "rb") as f:
                data = f.read()
            # Inject cache-busting version into index.html so browsers
            # always fetch fresh CSS/JS after a server restart.
            if rel == "index.html":
                v = _STARTUP_VERSION.encode()
                data = _CACHEBUST_RE.sub(rb'\1?v=' + v + rb'">', data)
            self.send_response(200)
            self.send_header("Content-Type", content_type)
            self.send_header("Content-Length", str(len(data)))
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            self.wfile.write(data)
        except OSError:
            self._send_error_json(500, "Error reading file")

    def _handle_sse(self) -> None:
        """Handle SSE event stream."""
        self.send_response(200)
        self.send_header("Content-Type", "text/event-stream")
        self.send_header("Cache-Control", "no-cache")
        self.send_header("Connection", "keep-alive")
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()

        q = self.sse.subscribe()
        try:
            while True:
                try:
                    event_type, data = q.get(timeout=15)
                    self.wfile.write(format_sse(event_type, data))
                    self.wfile.flush()
                except queue.Empty:
                    # Send keepalive on timeout
                    try:
                        self.wfile.write(b": keepalive\n\n")
                        self.wfile.flush()
                    except (BrokenPipeError, ConnectionResetError, OSError):
                        break
                except (BrokenPipeError, ConnectionResetError, OSError):
                    break
        finally:
            self.sse.unsubscribe(q)

    def _dispatch(self, method: str) -> None:
        path = self._parse_url()

        # SSE endpoint
        if method == "GET" and path == "/api/events":
            self._handle_sse()
            return

        # API routes
        for route_method, pattern, handler in _routes:
            if route_method != method:
                continue
            m = pattern.match(path)
            if m:
                try:
                    handler(self, *m.groups())
                except Exception as e:
                    self._send_error_json(500, str(e))
                return

        # Static files (GET only)
        if method == "GET":
            self._serve_static(path)
            return

        self._send_error_json(404, "Not found")

    def do_GET(self):
        # WebSocket upgrade for terminal
        if (self.path.startswith("/ws/terminal") and
                self.headers.get("Upgrade", "").lower() == "websocket"):
            from .websocket import do_websocket_handshake
            from .terminal import handle_terminal_websocket
            if do_websocket_handshake(self):
                handle_terminal_websocket(self)
            return

        # Minimal WebSocket echo for diagnostics (no PTY)
        if (self.path.startswith("/ws/echo") and
                self.headers.get("Upgrade", "").lower() == "websocket"):
            from .websocket import (do_websocket_handshake, read_frame,
                                    send_text, send_close, OP_TEXT, OP_CLOSE)
            if do_websocket_handshake(self):
                from . import web_log
                from .terminal import _SockReader, _SockWriter
                rfile = _SockReader(self.request)
                wfile = _SockWriter(self.request)
                web_log("[ws/echo] connected")
                try:
                    while True:
                        opcode, payload = read_frame(rfile)
                        web_log(f"[ws/echo] frame: op={opcode} "
                                f"len={len(payload) if payload else 0}")
                        if opcode is None or opcode == OP_CLOSE:
                            break
                        if opcode == OP_TEXT:
                            send_text(wfile,
                                      payload.decode("utf-8", errors="replace"))
                except Exception as e:
                    web_log(f"[ws/echo] error: {e}")
                finally:
                    web_log("[ws/echo] done")
            return

        self._dispatch("GET")

    def do_POST(self):
        self._dispatch("POST")

    def do_OPTIONS(self):
        self.send_response(200)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.send_header("Content-Length", "0")
        self.end_headers()


def _web_pid_file() -> str:
    """Return path to the web server PID file."""
    config_dir = os.path.expanduser("~/.config/bit")
    os.makedirs(config_dir, exist_ok=True)
    return os.path.join(config_dir, "web.pid")


def _web_cert_paths():
    """Return (cert_path, key_path) for HTTPS."""
    config_dir = os.path.expanduser("~/.config/bit")
    return (os.path.join(config_dir, "cert.pem"),
            os.path.join(config_dir, "key.pem"))


def _web_ca_cert_path():
    """Return path to rootCA.pem if it exists, else None."""
    p = os.path.join(os.path.expanduser("~/.config/bit"), "rootCA.pem")
    return p if os.path.isfile(p) else None


def _stop_running_server() -> bool:
    """Stop a running web server via PID file.  Returns True if stopped."""
    import signal as _sig
    import json as _json
    import time as _time

    pid_file = _web_pid_file()
    try:
        with open(pid_file) as f:
            data = _json.load(f)
        pid = data["pid"]
    except (OSError, KeyError, _json.JSONDecodeError):
        return False

    try:
        os.kill(pid, 0)  # Check if alive
    except (OSError, ProcessLookupError):
        try:
            os.unlink(pid_file)
        except OSError:
            pass
        return False

    print(f"Stopping web server (pid {pid})...")
    try:
        os.kill(pid, _sig.SIGTERM)
    except (OSError, ProcessLookupError):
        pass

    # Wait up to 3 seconds for exit
    for _ in range(30):
        try:
            os.kill(pid, 0)
            _time.sleep(0.1)
        except (OSError, ProcessLookupError):
            break

    try:
        os.unlink(pid_file)
    except OSError:
        pass
    print("Stopped.")
    return True


def run_serve(args) -> int:
    """Start the web dashboard server."""
    import signal
    import json as _json

    host = getattr(args, "host", "127.0.0.1")
    port = getattr(args, "port", 8123)
    no_browser = getattr(args, "no_browser", False)
    stop = getattr(args, "stop", False)
    restart = getattr(args, "restart", False)

    if stop:
        if _stop_running_server():
            return 0
        print("No running web server found.", file=sys.stderr)
        return 1

    if restart:
        _stop_running_server()

    # Import API modules to register routes
    from . import api  # noqa: F401
    from . import api_commands  # noqa: F401

    class _ReuseServer(ThreadingHTTPServer):
        allow_reuse_address = True
        ssl_context = None
        ssl_enabled = False
        ca_cert_path = None

        def get_request(self):
            conn, addr = super().get_request()
            if self.ssl_context:
                conn.settimeout(1)
                try:
                    first_byte = conn.recv(1, socket.MSG_PEEK)
                except OSError:
                    first_byte = b""
                finally:
                    conn.settimeout(None)
                if first_byte and first_byte[0] == 0x16:
                    conn = self.ssl_context.wrap_socket(conn, server_side=True)
            return conn, addr

    try:
        server = _ReuseServer((host, port), BitWebHandler)
    except OSError as e:
        if e.errno == 98:  # Address already in use
            print(f"Error: port {port} is already in use", file=sys.stderr)
            print(f"  Use: bit serve --restart  (stop and start)", file=sys.stderr)
            print(f"  Or:  bit serve --stop", file=sys.stderr)
            return 1
        raise

    # SIGTERM handler — convert to KeyboardInterrupt for clean shutdown
    def _sigterm_handler(signum, frame):
        raise KeyboardInterrupt
    signal.signal(signal.SIGTERM, _sigterm_handler)

    server.sse_manager = SSEManager()

    # Start SSE change monitor
    try:
        from ..commands.projects import _get_projects_file, get_current_project
        server.sse_manager.start_monitor(_get_projects_file, get_current_project)
    except Exception:
        pass

    # Write PID file after successful port bind
    pid_file = _web_pid_file()
    try:
        with open(pid_file, "w") as f:
            _json.dump({"pid": os.getpid(), "host": host, "port": port}, f)
    except OSError:
        pass

    # SSL setup — enable HTTPS if certs are present (unless --no-ssl)
    no_ssl = getattr(args, "no_ssl", False)
    cert_file, key_file = _web_cert_paths()
    if not no_ssl and os.path.isfile(cert_file) and os.path.isfile(key_file):
        try:
            ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
            ctx.load_cert_chain(cert_file, key_file)
            server.ssl_context = ctx
            server.ssl_enabled = True
            server.ca_cert_path = _web_ca_cert_path()
        except (OSError, ValueError) as e:
            print(f"Warning: SSL setup failed ({e}), falling back to HTTP",
                  file=sys.stderr)

    scheme = "https" if server.ssl_enabled else "http"
    url = f"{scheme}://{host}:{port}"
    print(f"bit web dashboard: {url}")
    print("Press Ctrl+C to stop")

    if not no_browser:
        from ..commands.projects import get_web_open_browser
        if get_web_open_browser():
            try:
                webbrowser.open(url)
            except Exception:
                pass

    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nShutting down...")
        server.sse_manager.stop_monitor()
        from .terminal import shutdown_all_sessions
        shutdown_all_sessions()
        server.shutdown()
    finally:
        # Clean up PID file
        try:
            os.unlink(pid_file)
        except OSError:
            pass

    return 0
