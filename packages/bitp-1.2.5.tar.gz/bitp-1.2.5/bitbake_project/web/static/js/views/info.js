/* Info view — build variables + layer status */
const InfoView = {
  _nav: KeyboardNav({ skipHidden: true }),

  keyBindings: [
    {key: 'j/k', desc: 'Navigate rows'},
    {key: '/', desc: 'Filter', action: '/'},
  ],

  handleKeyboard(e) {
    if (this._nav.handleBasicKeys(e)) return;
    if (e.key === '/') {
      e.preventDefault();
      var input = document.getElementById('info-filter');
      if (input) input.focus();
    }
  },

  async render(container, state) {
    container.innerHTML = `
      <div class="view-header">
        <h2>Build Info</h2>
      </div>
      <div class="search-bar">
        <input type="text" id="info-filter" placeholder="Filter variables...">
      </div>
      <div id="info-tabs" style="margin-bottom:16px">
        <button class="btn btn-primary" data-tab="vars">Variables</button>
        <button class="btn" data-tab="layers">Layers</button>
      </div>
      <div id="info-content" class="loading">Loading</div>
    `;

    document.getElementById('info-filter').addEventListener('input', () => this._filterVars());
    document.querySelectorAll('#info-tabs button').forEach(btn => {
      btn.addEventListener('click', () => {
        document.querySelectorAll('#info-tabs button').forEach(b => b.classList.remove('btn-primary'));
        btn.classList.add('btn-primary');
        if (btn.dataset.tab === 'vars') this._loadVars();
        else this._loadLayers();
      });
    });

    this._loadVars();
  },

  async _loadVars() {
    const el = document.getElementById('info-content');
    el.className = 'loading';
    el.textContent = 'Loading variables...';
    try {
      const vars = await API.getInfoVars();
      this._allVars = vars;
      this._renderVars(vars);
    } catch (e) {
      el.className = '';
      el.innerHTML = `<div class="empty-state"><h3>Error</h3><p>${e.message}</p></div>`;
    }
  },

  _renderVars(vars) {
    const el = document.getElementById('info-content');
    el.className = '';
    if (!vars || typeof vars !== 'object' || !Object.keys(vars).length) {
      el.innerHTML = '<div class="empty-state"><h3>No variables</h3></div>';
      return;
    }

    const entries = Object.entries(vars).sort((a, b) => a[0].localeCompare(b[0]));
    el.innerHTML = `<table class="data-table" id="info-table">
      <thead><tr><th style="width:2ch"></th><th>Variable</th><th>Value</th></tr></thead>
      <tbody>${entries.map(([k, v]) => `<tr data-var="${esc(k.toLowerCase())}">
        <td><span class="drag-handle">&#9776;</span></td>
        <td style="color:var(--cyan);white-space:nowrap">${esc(k)}</td>
        <td style="word-break:break-all">${esc(String(v))}</td>
      </tr>`).join('')}</tbody>
    </table>`;

    // Drag-and-drop reordering
    const tbody = el.querySelector('tbody');
    if (tbody) initViewSortable(tbody, 'bit-info-order', 'tr[data-var]');

    // Reset order button
    let resetBtn = document.getElementById('view-reset-order');
    if (!resetBtn) {
      resetBtn = document.createElement('button');
      resetBtn.id = 'view-reset-order';
      resetBtn.className = 'btn dash-reset-order-fixed';
      resetBtn.title = 'Reset row order to default';
      resetBtn.textContent = 'Reset Order';
      document.body.appendChild(resetBtn);
    }
    resetBtn.style.display = '';
    resetBtn.onclick = () => {
      resetViewOrder('bit-info-order');
      this._renderVars(this._allVars);
    };

    // Keyboard nav
    this._nav.setRows(el.querySelectorAll('tbody tr'));
  },

  _filterVars() {
    const filter = (document.getElementById('info-filter').value || '').toLowerCase();
    document.querySelectorAll('#info-content tr[data-var]').forEach(tr => {
      tr.style.display = !filter || tr.dataset.var.includes(filter) ? '' : 'none';
    });
  },

  async _loadLayers() {
    const el = document.getElementById('info-content');
    el.className = 'loading';
    el.textContent = 'Loading layers...';
    try {
      const layers = await API.getInfoLayers();
      this._renderLayers(layers);
    } catch (e) {
      el.className = '';
      el.innerHTML = `<div class="empty-state"><h3>Error</h3><p>${e.message}</p></div>`;
    }
  },

  _renderLayers(layers) {
    const el = document.getElementById('info-content');
    el.className = '';
    if (!layers || !layers.length) {
      el.innerHTML = '<div class="empty-state"><h3>No layer info</h3></div>';
      return;
    }

    el.innerHTML = `<table class="data-table">
      <thead><tr><th>Layer</th><th>Branch</th><th>Commit</th><th>Status</th></tr></thead>
      <tbody>${layers.map(l => {
        const isDirty = l.dirty || l.is_dirty;
        return `<tr>
          <td>${esc(l.name || l.layer || '')}</td>
          <td style="color:var(--accent)">${esc(l.branch || '')}</td>
          <td><span class="commit-sha">${esc((l.commit || l.head || '').slice(0, 8))}</span></td>
          <td>${isDirty
            ? '<span class="badge badge-dirty">dirty</span>'
            : '<span class="badge badge-clean">clean</span>'}</td>
        </tr>`;
      }).join('')}</tbody>
    </table>`;
  },

};
