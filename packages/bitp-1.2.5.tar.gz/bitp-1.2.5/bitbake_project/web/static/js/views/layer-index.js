/* Layer Index view — browse OpenEmbedded Layer Index with local status
 * Split-pane layout: left list + right detail/deps preview
 * Search footer, keyboard navigation, branch selector
 */
const LayerIndexView = {
  _nav: KeyboardNav(),
  _layers: [],
  _branch: 'scarthgap',
  _searchTerm: '',
  _previewLayer: null,

  keyBindings: [
    {key: 'j/k', desc: 'Navigate rows'},
    {key: 'Enter', desc: 'Preview details', action: 'Enter'},
    {key: '/', desc: 'Search', action: '/'},
    {key: 'a', desc: 'Add layer to build', action: 'a'},
    {key: 'c', desc: 'Clone layer', action: 'c'},
    {key: 'Esc', desc: 'Close preview'},
  ],

  _project() { return App.state.selectedProject || ''; },

  async render(container) {
    container.innerHTML = `
      <div class="recipes-split">
        <div class="recipes-left" id="li-left">
          <div class="view-header">
            <h2>Layer Index</h2>
            <div class="btn-group" style="margin-left:auto">
              <label style="color:var(--text-muted);font-size:var(--font-size-sm)">Branch:</label>
              <select id="li-branch" class="btn btn-sm" style="min-width:100px">
                <option value="scarthgap">scarthgap</option>
                <option value="styhead">styhead</option>
                <option value="walnascar">walnascar</option>
                <option value="nanbield">nanbield</option>
                <option value="mickledore">mickledore</option>
                <option value="kirkstone">kirkstone</option>
                <option value="dunfell">dunfell</option>
                <option value="master">master</option>
              </select>
            </div>
          </div>
          <div id="li-list" class="loading">Loading layer index</div>
        </div>
        <div class="recipes-resizer" id="li-resizer" style="display:none"></div>
        <div id="li-preview" class="recipes-preview-panel" style="display:none">
          <div class="recipes-preview-header">
            <span id="li-preview-title"></span>
            <button class="btn" id="li-preview-close" title="Close preview">\u00d7</button>
          </div>
          <div id="li-preview-body">
            <div class="recipes-preview-placeholder">Select a layer to preview</div>
          </div>
        </div>
      </div>
      <div class="recipes-footer">
        <div class="recipes-footer-left">
          <input type="text" id="li-search" placeholder="Search layers...">
          <button class="btn" id="li-reset" style="display:none" title="Clear search">Reset</button>
        </div>
        <div class="recipes-footer-right" id="li-actions">
          <button class="btn btn-sm" id="li-act-clone" disabled title="Clone layer repo (c)">Clone</button>
          <button class="btn btn-sm" id="li-act-add" disabled title="Add layer to build (a)">Add to build</button>
        </div>
      </div>
    `;

    // Branch selector
    const branchSelect = document.getElementById('li-branch');
    branchSelect.value = this._branch;
    branchSelect.addEventListener('change', () => {
      this._branch = branchSelect.value;
      this._fetchAndRender();
    });

    // Search
    const searchInput = document.getElementById('li-search');
    searchInput.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') { e.preventDefault(); this._applyFilter(); }
      else if (e.key === 'Escape') { searchInput.blur(); e.preventDefault(); }
    });
    document.getElementById('li-reset').addEventListener('click', () => {
      searchInput.value = '';
      this._searchTerm = '';
      document.getElementById('li-reset').style.display = 'none';
      this._applyFilter();
    });

    // Footer action buttons
    document.getElementById('li-act-clone').addEventListener('click', () => {
      const row = this._nav.activeRow();
      if (row) this._cloneLayerFromIndex(row);
    });
    document.getElementById('li-act-add').addEventListener('click', () => {
      const row = this._nav.activeRow();
      if (row) this._addLayerFromIndex(row);
    });

    // Preview close
    document.getElementById('li-preview-close').addEventListener('click', () => this._hidePreview());

    // Resizable divider
    const resizer = document.getElementById('li-resizer');
    const leftPanel = document.getElementById('li-left');
    if (resizer && leftPanel) {
      const saved = localStorage.getItem('bit-li-left-width');
      if (saved) leftPanel.style.flex = '0 0 ' + saved + 'px';
      let startX, startW;
      const onMouseMove = (e) => {
        const newW = startW + (e.clientX - startX);
        const clamped = Math.max(200, Math.min(newW, window.innerWidth - 300));
        leftPanel.style.flex = '0 0 ' + clamped + 'px';
      };
      const onMouseUp = () => {
        document.removeEventListener('mousemove', onMouseMove);
        document.removeEventListener('mouseup', onMouseUp);
        document.body.style.cursor = '';
        document.body.style.userSelect = '';
        const w = leftPanel.getBoundingClientRect().width;
        localStorage.setItem('bit-li-left-width', Math.round(w));
      };
      resizer.addEventListener('mousedown', (e) => {
        e.preventDefault();
        startX = e.clientX;
        startW = leftPanel.getBoundingClientRect().width;
        document.body.style.cursor = 'col-resize';
        document.body.style.userSelect = 'none';
        document.addEventListener('mousemove', onMouseMove);
        document.addEventListener('mouseup', onMouseUp);
      });
    }

    await this._fetchAndRender();
  },

  async _fetchAndRender() {
    const el = document.getElementById('li-list');
    if (el) { el.className = 'loading'; el.textContent = 'Loading layer index'; }
    try {
      const data = await API.getLayerIndex(this._branch, this._project());
      this._layers = data.layers || [];
      this._applyFilter();
    } catch (e) {
      if (el) {
        el.className = '';
        el.innerHTML = `<div class="empty-state"><h3>Error</h3><p>${esc(e.message)}</p></div>`;
      }
    }
  },

  _applyFilter() {
    const input = document.getElementById('li-search');
    const search = input ? input.value.trim().toLowerCase() : '';
    this._searchTerm = search;
    const resetBtn = document.getElementById('li-reset');
    if (resetBtn) resetBtn.style.display = search ? '' : 'none';

    let filtered = this._layers;
    if (search) {
      filtered = this._layers.filter(l =>
        l.name.toLowerCase().includes(search) ||
        (l.summary || '').toLowerCase().includes(search) ||
        (l.description || '').toLowerCase().includes(search)
      );
    }
    this._renderList(filtered);
  },

  _renderList(layers) {
    const el = document.getElementById('li-list');
    el.className = '';
    if (!layers.length) {
      el.innerHTML = this._searchTerm
        ? '<div class="empty-state"><h3>No matching layers</h3></div>'
        : '<div class="empty-state"><h3>No layers found</h3></div>';
      this._nav.setRows([]);
      return;
    }

    let html = `<table class="data-table" id="li-table">
      <thead><tr><th>Name</th><th>Summary</th><th>Status</th></tr></thead>
      <tbody>`;

    for (const l of layers) {
      const statusDot = l.status === 'configured'
        ? '<span style="color:var(--green)" title="Configured">\u25cf</span>'
        : l.status === 'cloned'
        ? '<span style="color:var(--yellow)" title="Cloned">\u25cf</span>'
        : '<span style="color:var(--text-muted)" title="Not local">\u25cb</span>';
      html += `<tr role="row" tabindex="-1" data-layer="${esc(l.name)}">
        <td style="color:var(--accent)">${esc(l.name)}</td>
        <td style="color:var(--text-muted)">${esc((l.summary || '').substring(0, 80))}</td>
        <td style="text-align:center">${statusDot}</td>
      </tr>`;
    }

    html += '</tbody></table>';
    el.innerHTML = html;

    // Click handler
    el.querySelectorAll('tr[role="row"]').forEach(row => {
      row.addEventListener('click', () => {
        this._nav.activateElement(row);
        this._showPreviewForRow(row);
        this._updateFooterButtons(row);
      });
    });

    this._nav.setRows(el.querySelectorAll('tr[role="row"]'));
    this._updateFooterButtons(null);

    const table = document.getElementById('li-table');
    if (table) initColumnResizer(table, 'layer-index');
  },

  handleKeyboard(e) {
    if (e.key === 'Escape') {
      const panel = document.getElementById('li-preview');
      if (panel && panel.style.display !== 'none') {
        e.preventDefault();
        this._hidePreview();
        return;
      }
    }
    if (this._nav.handleBasicKeys(e)) {
      this._updateFooterButtons(this._nav.activeRow());
      return;
    }
    const row = this._nav.activeRow();
    if (e.key === 'Enter' && row) {
      e.preventDefault();
      this._showPreviewForRow(row);
    } else if (e.key === '/') {
      e.preventDefault();
      const input = document.getElementById('li-search');
      if (input) input.focus();
    } else if (e.key === 'a' && row) {
      e.preventDefault();
      this._addLayerFromIndex(row);
    } else if (e.key === 'c' && row) {
      e.preventDefault();
      this._cloneLayerFromIndex(row);
    }
  },

  _showPreviewForRow(row) {
    const name = row.dataset.layer;
    if (!name) return;
    const layer = this._layers.find(l => l.name === name);
    if (layer) this._showPreview(layer);
  },

  async _showPreview(layer) {
    const panel = document.getElementById('li-preview');
    const resizer = document.getElementById('li-resizer');
    const title = document.getElementById('li-preview-title');
    const body = document.getElementById('li-preview-body');
    const leftPanel = document.getElementById('li-left');
    if (!panel || !body) return;

    this._previewLayer = layer;
    panel.style.display = '';
    if (resizer) resizer.style.display = '';

    if (leftPanel && !leftPanel.style.flex) {
      const saved = localStorage.getItem('bit-li-left-width');
      if (saved) leftPanel.style.flex = '0 0 ' + saved + 'px';
    }

    if (title) title.textContent = layer.name;

    // Build metadata
    let html = '<div class="recipes-preview-meta">';
    html += `<div class="recipes-detail-field"><span class="recipes-detail-label">Name</span><span class="recipes-detail-value" style="font-weight:600;color:var(--accent)">${esc(layer.name)}</span></div>`;
    if (layer.summary) {
      html += `<div class="recipes-detail-field"><span class="recipes-detail-label">Summary</span><span class="recipes-detail-value">${esc(layer.summary)}</span></div>`;
    }
    if (layer.description) {
      html += `<div class="recipes-detail-field"><span class="recipes-detail-label">Description</span><span class="recipes-detail-value" style="white-space:pre-wrap">${esc(layer.description)}</span></div>`;
    }
    if (layer.vcs_url) {
      html += `<div class="recipes-detail-field"><span class="recipes-detail-label">Repository</span><span class="recipes-detail-value"><a href="${esc(layer.vcs_url)}" target="_blank" rel="noopener" style="color:var(--accent)">${esc(layer.vcs_url)}</a></span></div>`;
    }
    if (layer.vcs_subdir) {
      html += `<div class="recipes-detail-field"><span class="recipes-detail-label">Subdirectory</span><span class="recipes-detail-value">${esc(layer.vcs_subdir)}</span></div>`;
    }

    const statusLabel = layer.status === 'configured' ? 'Configured'
      : layer.status === 'cloned' ? 'Cloned (not configured)'
      : 'Not cloned';
    const statusColor = layer.status === 'configured' ? 'var(--green)'
      : layer.status === 'cloned' ? 'var(--yellow)'
      : 'var(--text-muted)';
    html += `<div class="recipes-detail-field"><span class="recipes-detail-label">Status</span><span class="recipes-detail-value" style="color:${statusColor}">${statusLabel}</span></div>`;

    if (layer.local_path) {
      html += `<div class="recipes-detail-field"><span class="recipes-detail-label">Local Path</span><span class="recipes-detail-value" style="color:var(--text-muted);font-size:var(--font-size-xs)">${esc(layer.local_path)}</span></div>`;
    }

    // Action buttons based on status
    if (layer.status !== 'configured') {
      html += '<div class="recipes-detail-field" style="margin-top:8px">';
      if (!layer.local_path) {
        html += `<button class="btn btn-sm" id="li-btn-clone" style="margin-right:6px">Clone</button>`;
        html += `<button class="btn btn-sm" id="li-btn-clone-add">Clone &amp; Add</button>`;
      } else {
        html += `<button class="btn btn-sm" id="li-btn-add">Add to build</button>`;
      }
      html += '</div>';
    }
    html += '</div>';

    // Show loading for deps
    html += '<div class="recipes-preview-meta" style="margin-top:8px"><div class="recipes-detail-field"><span class="recipes-detail-label">Dependencies</span><span class="recipes-detail-value loading">Loading</span></div></div>';
    body.innerHTML = html;

    // Wire up action buttons
    const btnClone = document.getElementById('li-btn-clone');
    const btnCloneAdd = document.getElementById('li-btn-clone-add');
    const btnAdd = document.getElementById('li-btn-add');
    if (btnClone) btnClone.addEventListener('click', () => this._doClone(layer));
    if (btnCloneAdd) btnCloneAdd.addEventListener('click', () => {
      // Clone first; the SSE done event will refresh, user can then add
      this._doClone(layer);
    });
    if (btnAdd) btnAdd.addEventListener('click', async () => {
      try {
        await API.addLayer(layer.local_path, this._project());
        App.showToast(`Added layer: ${layer.name}`, 'success');
        await this._fetchAndRender();
      } catch (e) {
        App.showToast(e.message, 'error');
      }
    });

    // Fetch deps
    try {
      const depsData = await API.getLayerDeps(layer.name, this._branch);
      const deps = depsData.deps || [];
      let depsHtml;
      if (deps.length === 0) {
        depsHtml = '<span style="color:var(--text-muted)">None</span>';
      } else {
        depsHtml = deps.map(d => {
          const req = d.required ? '' : ' <span style="color:var(--text-muted)">(optional)</span>';
          return `<div style="padding:2px 0">${esc(d.name)}${req}</div>`;
        }).join('');
      }
      // Replace the loading deps section
      const metaSections = body.querySelectorAll('.recipes-preview-meta');
      if (metaSections.length > 1) {
        metaSections[1].innerHTML = `<div class="recipes-detail-field"><span class="recipes-detail-label">Dependencies</span><span class="recipes-detail-value">${depsHtml}</span></div>`;
      }
    } catch (e) {
      const metaSections = body.querySelectorAll('.recipes-preview-meta');
      if (metaSections.length > 1) {
        metaSections[1].innerHTML = `<div class="recipes-detail-field"><span class="recipes-detail-label">Dependencies</span><span class="recipes-detail-value" style="color:var(--red)">Error: ${esc(e.message)}</span></div>`;
      }
    }
  },

  _hidePreview() {
    const panel = document.getElementById('li-preview');
    const resizer = document.getElementById('li-resizer');
    const leftPanel = document.getElementById('li-left');
    this._previewLayer = null;
    if (panel) panel.style.display = 'none';
    if (resizer) resizer.style.display = 'none';
    if (leftPanel) leftPanel.style.flex = '';
  },

  _updateFooterButtons(row) {
    const btnClone = document.getElementById('li-act-clone');
    const btnAdd = document.getElementById('li-act-add');
    if (!btnClone || !btnAdd) return;
    if (!row) {
      btnClone.disabled = true;
      btnAdd.disabled = true;
      return;
    }
    const name = row.dataset.layer;
    const layer = this._layers.find(l => l.name === name);
    if (!layer) {
      btnClone.disabled = true;
      btnAdd.disabled = true;
      return;
    }
    if (layer.status === 'configured') {
      btnClone.disabled = true;
      btnAdd.disabled = true;
    } else if (!layer.local_path) {
      // Not cloned — both actions available
      btnClone.disabled = false;
      btnAdd.disabled = false;
    } else {
      // Cloned but not configured — only add available
      btnClone.disabled = true;
      btnAdd.disabled = false;
    }
  },

  async _addLayerFromIndex(row) {
    const name = row.dataset.layer;
    const layer = this._layers.find(l => l.name === name);
    if (!layer) return;
    if (layer.status === 'configured') {
      App.showToast('Layer already configured', 'success');
      return;
    }
    if (!layer.local_path) {
      // Clone first, then SSE layer_clone_done will refresh the view
      this._doClone(layer);
      return;
    }
    // Cloned but not configured — add it
    try {
      await API.addLayer(layer.local_path, this._project());
      App.showToast(`Added layer: ${name}`, 'success');
      await this._fetchAndRender();
    } catch (e) {
      App.showToast(e.message, 'error');
    }
  },

  async _cloneLayerFromIndex(row) {
    const name = row.dataset.layer;
    const layer = this._layers.find(l => l.name === name);
    if (!layer) return;
    if (layer.local_path) {
      App.showToast('Layer already cloned', 'success');
      return;
    }
    this._doClone(layer);
  },

  async _doClone(layer) {
    const target = 'layers/' + layer.name;
    try {
      await API.cloneLayer({
        url: layer.vcs_url,
        branch: this._branch,
        target: target,
        layer_name: layer.name,
      }, this._project());
      App.showToast(`Cloning ${layer.name}...`);
    } catch (e) {
      App.showToast(e.message, 'error');
    }
  },
};
