/* Patches view — searchable/filterable patch browser grouped by repo */
const PatchesView = {
  _nav: KeyboardNav(),
  _expandedRepos: {},
  _allExpanded: true,
  _previewPath: null,
  _groupMode: 'repo',
  _activeStatuses: [],
  _statusValuesCache: null,
  _lastPatches: null,

  keyBindings: [
    {key: 'j/k', desc: 'Navigate rows'},
    {key: 'Enter', desc: 'Preview / toggle group', action: 'Enter'},
    {key: 'v', desc: 'Full view', action: 'v'},
    {key: 'e', desc: 'Edit patch', action: 'e'},
    {key: 'u', desc: 'Update status', action: 'u'},
    {key: 'c', desc: 'Copy path', action: 'c'},
    {key: 's', desc: 'Search lore', action: 's'},
    {key: '/', desc: 'Search', action: '/'},
    {key: 'x', desc: 'Expand/collapse all', action: 'x'},
  ],

  handleKeyboard(e) {
    if (e.key === 'Escape') {
      const dropdown = document.getElementById('patches-filter-dropdown');
      if (dropdown && dropdown.style.display !== 'none') {
        e.preventDefault();
        dropdown.style.display = 'none';
        return;
      }
      const panel = document.getElementById('patches-preview-panel');
      if (panel && panel.style.display !== 'none') {
        e.preventDefault();
        this._hidePreview();
        return;
      }
    }
    if (this._nav.handleBasicKeys(e)) return;
    const row = this._nav.activeRow();
    if (e.key === 'Enter' && row) {
      e.preventDefault();
      if (row.classList.contains('expandable')) {
        this._toggleRepo(row.dataset.group);
      } else {
        const path = row.dataset.path;
        if (path) this._showPreview(path);
      }
    } else if (e.key === 'v' && row) {
      e.preventDefault();
      if (!row.classList.contains('expandable')) {
        const path = row.dataset.path;
        if (path) this._viewPatch(path);
      }
    } else if (e.key === 'e' && row) {
      e.preventDefault();
      if (!row.classList.contains('expandable')) {
        const path = row.dataset.path;
        if (path) this._editPatch(path);
      }
    } else if (e.key === 'u' && row) {
      e.preventDefault();
      if (!row.classList.contains('expandable')) {
        const path = row.dataset.path;
        if (path) this._editStatus(path);
      }
    } else if (e.key === 'c' && row) {
      e.preventDefault();
      if (!row.classList.contains('expandable')) {
        const path = row.dataset.path;
        if (path) this._copyPath(path);
      }
    } else if (e.key === 's' && row) {
      e.preventDefault();
      if (!row.classList.contains('expandable')) {
        this._searchLore(row);
      }
    } else if (e.key === '/') {
      e.preventDefault();
      const input = document.getElementById('patch-search');
      if (input) input.focus();
    } else if (e.key === 'x') {
      e.preventDefault();
      this._toggleAll();
    }
  },

  async render(container, state) {
    container.innerHTML = `
      <div class="patches-split">
        <div class="patches-left" id="patches-left">
          <div class="patches-left-header">
            <h2>Patches</h2>
          </div>
          <div id="patches-list" class="loading">Loading patches</div>
        </div>
        <div class="patches-resizer" id="patches-resizer" style="display:none"></div>
        <div id="patches-preview-panel" class="patches-preview-panel" style="display:none">
          <div class="patches-preview-header">
            <span id="patches-preview-title"></span>
            <div class="btn-group">
              <button class="btn" id="patches-preview-popout" title="Open in modal (v)">\u2197</button>
              <button class="btn" id="patches-preview-close" title="Close preview">\u00d7</button>
            </div>
          </div>
          <div id="patches-preview-body">
            <div class="patches-preview-placeholder">Select a patch to preview</div>
          </div>
        </div>
      </div>
      <div class="patches-footer">
        <div class="patches-footer-left">
          <input type="text" id="patch-search" placeholder="Search patches...">
          <label class="patches-body-toggle" title="Search patch content instead of name">
            <input type="checkbox" id="patch-body-toggle"> Body
          </label>
          <div class="patches-filter-wrap">
            <button class="btn" id="patch-filter-btn">Status \u25be</button>
            <div class="patches-filter-dropdown" id="patches-filter-dropdown" style="display:none"></div>
          </div>
          <button class="btn" id="patch-go">Search</button>
          <button class="btn" id="patch-reset" style="display:none" title="Clear all filters">Reset</button>
        </div>
        <div class="patches-footer-right">
          <button class="btn patches-group-btn" id="patches-group-btn" title="Cycle grouping mode">Group: repo</button>
          <button class="btn" id="patches-toggle-all" title="Expand/collapse all groups">Collapse all</button>
        </div>
      </div>
    `;

    const doSearch = () => this._search();
    document.getElementById('patch-go').addEventListener('click', doSearch);
    document.getElementById('patch-search').addEventListener('keydown', e => { if (e.key === 'Enter') doSearch(); });
    document.getElementById('patches-toggle-all').addEventListener('click', () => this._toggleAll());
    document.getElementById('patches-preview-close').addEventListener('click', () => this._hidePreview());
    document.getElementById('patches-preview-popout').addEventListener('click', () => {
      if (this._previewPath) this._viewPatch(this._previewPath);
    });
    document.getElementById('patch-reset').addEventListener('click', () => this._resetFilters());
    document.getElementById('patches-group-btn').addEventListener('click', () => this._cycleGroupMode());

    // Filter dropdown
    const filterBtn = document.getElementById('patch-filter-btn');
    filterBtn.addEventListener('click', () => this._toggleFilterDropdown());

    // Body toggle triggers search
    document.getElementById('patch-body-toggle').addEventListener('change', doSearch);

    // Resizable divider between patch list and preview panel
    const resizer = document.getElementById('patches-resizer');
    const leftPanel = document.getElementById('patches-left');
    if (resizer && leftPanel) {
      const saved = localStorage.getItem('bit-patches-left-width');
      if (saved) leftPanel.style.flex = '0 0 ' + saved + 'px';

      let startX, startW;
      const onMouseMove = (e) => {
        const newW = startW + (e.clientX - startX);
        const clamped = Math.max(200, Math.min(newW, window.innerWidth - 300));
        leftPanel.style.flex = '0 0 ' + clamped + 'px';
      };
      const onMouseUp = () => {
        document.removeEventListener('mousemove', onMouseMove);
        document.removeEventListener('mouseup', onMouseUp);
        document.body.style.cursor = '';
        document.body.style.userSelect = '';
        const w = leftPanel.getBoundingClientRect().width;
        localStorage.setItem('bit-patches-left-width', Math.round(w));
      };
      resizer.addEventListener('mousedown', (e) => {
        e.preventDefault();
        startX = e.clientX;
        startW = leftPanel.getBoundingClientRect().width;
        document.body.style.cursor = 'col-resize';
        document.body.style.userSelect = 'none';
        document.addEventListener('mousemove', onMouseMove);
        document.addEventListener('mouseup', onMouseUp);
      });
    }

    // Close filter dropdown on outside click
    document.addEventListener('click', (e) => {
      const dropdown = document.getElementById('patches-filter-dropdown');
      const btn = document.getElementById('patch-filter-btn');
      if (dropdown && dropdown.style.display !== 'none' && !dropdown.contains(e.target) && e.target !== btn) {
        dropdown.style.display = 'none';
      }
    });

    // Load status values for the filter dropdown
    this._loadStatusValues();

    this._search();
  },

  async _loadStatusValues() {
    if (this._statusValuesCache) {
      this._buildFilterDropdown();
      return;
    }
    try {
      this._statusValuesCache = await API.getStatusValues();
      this._buildFilterDropdown();
    } catch (e) {
      // Fallback to hardcoded list
      this._statusValuesCache = {
        statuses: {
          'Pending': {requires_detail: false}, 'Submitted': {requires_detail: false},
          'Accepted': {requires_detail: true}, 'Backport': {requires_detail: true},
          'Denied': {requires_detail: true}, 'Inactive-Upstream': {requires_detail: true},
          'Inappropriate': {requires_detail: true},
        },
        inappropriate_reasons: [],
      };
      this._buildFilterDropdown();
    }
  },

  _buildFilterDropdown() {
    const dropdown = document.getElementById('patches-filter-dropdown');
    if (!dropdown || !this._statusValuesCache) return;
    const statuses = Object.keys(this._statusValuesCache.statuses);
    const allItems = ['Missing', ...statuses];
    let html = '';
    for (const s of allItems) {
      const checked = this._activeStatuses.includes(s) ? 'checked' : '';
      html += `<label class="patches-filter-item"><input type="checkbox" value="${esc(s)}" ${checked}> ${esc(s)}</label>`;
    }
    dropdown.innerHTML = html;
    dropdown.querySelectorAll('input[type="checkbox"]').forEach(cb => {
      cb.addEventListener('change', () => this._onFilterChange());
    });
  },

  _toggleFilterDropdown() {
    const dropdown = document.getElementById('patches-filter-dropdown');
    if (!dropdown) return;
    dropdown.style.display = dropdown.style.display === 'none' ? '' : 'none';
  },

  _onFilterChange() {
    const dropdown = document.getElementById('patches-filter-dropdown');
    if (!dropdown) return;
    this._activeStatuses = [];
    dropdown.querySelectorAll('input[type="checkbox"]:checked').forEach(cb => {
      this._activeStatuses.push(cb.value);
    });
    this._updateFilterBadge();
    this._search();
  },

  _updateFilterBadge() {
    const btn = document.getElementById('patch-filter-btn');
    if (!btn) return;
    if (this._activeStatuses.length > 0) {
      btn.innerHTML = 'Status <span class="patches-filter-badge">' + this._activeStatuses.length + '</span> \u25be';
    } else {
      btn.textContent = 'Status \u25be';
    }
    this._updateResetBtn();
  },

  _updateResetBtn() {
    const resetBtn = document.getElementById('patch-reset');
    if (!resetBtn) return;
    const search = document.getElementById('patch-search');
    const bodyToggle = document.getElementById('patch-body-toggle');
    const hasFilters = this._activeStatuses.length > 0 || (search && search.value) || (bodyToggle && bodyToggle.checked);
    resetBtn.style.display = hasFilters ? '' : 'none';
  },

  _resetFilters() {
    const search = document.getElementById('patch-search');
    const bodyToggle = document.getElementById('patch-body-toggle');
    if (search) search.value = '';
    if (bodyToggle) bodyToggle.checked = false;
    this._activeStatuses = [];
    this._buildFilterDropdown();
    this._updateFilterBadge();
    this._search();
  },

  _cycleGroupMode() {
    const modes = ['repo', 'recipe', 'layer-recipe'];
    const idx = modes.indexOf(this._groupMode);
    this._groupMode = modes[(idx + 1) % modes.length];
    const btn = document.getElementById('patches-group-btn');
    if (btn) btn.textContent = 'Group: ' + this._groupMode;
    // Re-render with cached patches
    if (this._lastPatches) this._renderGrouped(this._lastPatches);
  },

  async _search() {
    const search = document.getElementById('patch-search').value;
    const bodyToggle = document.getElementById('patch-body-toggle');
    const body = bodyToggle && bodyToggle.checked;
    const status = this._activeStatuses.join(',');
    const el = document.getElementById('patches-list');
    el.className = 'loading';
    el.textContent = 'Searching...';

    this._updateResetBtn();

    try {
      const patches = await API.getPatches(search, status, body);
      this._lastPatches = patches;
      this._renderGrouped(patches);
    } catch (e) {
      el.innerHTML = `<div class="empty-state"><h3>Error</h3><p>${e.message}</p></div>`;
    }
  },

  _statusBadgeClass(status) {
    if (!status) return 'badge-behind';
    const s = status.toLowerCase();
    if (s === 'accepted' || s === 'backport') return 'badge-clean';
    if (s === 'denied' || s === 'inappropriate') return 'badge-dirty';
    if (s === 'submitted') return 'badge-ahead';
    return 'badge-behind';
  },

  _renderGrouped(patches) {
    if (this._groupMode === 'recipe') {
      this._renderPatchesByRecipe(patches);
    } else if (this._groupMode === 'layer-recipe') {
      this._renderPatchesByLayerRecipe(patches);
    } else {
      this._renderPatches(patches);
    }
  },

  _groupPatchesBy(patches, keyFn) {
    const groups = {};
    for (const p of patches) {
      const key = keyFn(p) || 'unknown';
      if (!groups[key]) groups[key] = [];
      groups[key].push(p);
    }
    return groups;
  },

  _renderPatchesByRecipe(patches) {
    const grouped = this._groupPatchesBy(patches, p => p.recipe_name || p.recipe || 'unknown');
    this._renderPatchTable(patches, grouped);
  },

  _renderPatchesByLayerRecipe(patches) {
    const grouped = this._groupPatchesBy(patches, p => {
      const layer = p.layer_name || p.layer || '';
      const recipe = p.recipe_name || p.recipe || 'unknown';
      return layer ? layer + ' / ' + recipe : recipe;
    });
    this._renderPatchTable(patches, grouped);
  },

  _renderPatches(patches) {
    const grouped = this._groupPatchesBy(patches, p => p.repo_name || p.repo || 'unknown');
    this._renderPatchTable(patches, grouped);
  },

  _renderPatchTable(patches, grouped) {
    const el = document.getElementById('patches-list');
    if (!patches || !patches.length) {
      el.className = '';
      el.innerHTML = '<div class="empty-state"><h3>No patches found</h3></div>';
      return;
    }

    const groups = Object.keys(grouped).sort();

    el.className = '';
    let html = `<table class="data-table" id="patches-table">
      <thead><tr><th style="width:2ch"></th><th>Patch</th><th>Status</th><th>Recipe</th><th>Subject</th><th class="row-actions-col"></th></tr></thead>
      <tbody>`;

    for (const group of groups) {
      const rp = grouped[group];
      const isExpanded = this._expandedRepos[group] !== false;
      const chevron = isExpanded ? '\u25be' : '\u25b8';
      html += `<tr class="expandable" data-group="${esc(group)}" role="row" tabindex="-1">
        <td><span class="dash-row-toggle">${chevron}</span></td>
        <td colspan="5" style="font-weight:600;color:var(--text-primary)">
          ${esc(group)} <span style="color:var(--text-muted);font-weight:400">(${rp.length})</span>
        </td>
      </tr>`;

      if (isExpanded) {
        for (let i = 0; i < rp.length; i++) {
          const p = rp[i];
          const name = p.name || p.filename || p.path || 'unknown';
          const status = p.upstream_status || p.status || '';
          const recipe = p.recipe_name || p.recipe || '';
          const subject = p.subject || '';
          const isLast = i === rp.length - 1;
          const badgeClass = this._statusBadgeClass(status);
          html += `<tr class="explore-layer-row${isLast ? ' tree-last' : ''}" data-path="${esc(p.path || '')}" data-group="${esc(group)}" data-subject="${esc(subject)}" role="row" tabindex="-1">
            <td class="tree-line"></td>
            <td>${esc(name)}</td>
            <td>${status ? `<span class="badge ${badgeClass}">${esc(status)}</span>` : ''}</td>
            <td style="color:var(--cyan)">${esc(recipe)}</td>
            <td style="color:var(--text-muted)">${esc(subject.substring(0, 60))}</td>
            <td class="row-actions">
              <button class="btn-icon" data-action="preview" title="Preview (Enter)">\u2299</button>
              <button class="btn-icon" data-action="view" title="View (v)">\u2630</button>
              <button class="btn-icon" data-action="edit" title="Edit (e)">\u270e</button>
              <button class="btn-icon" data-action="lore" title="Lore search (s)">\u2315</button>
              <button class="btn-icon" data-action="copy" title="Copy path (c)">\u29c9</button>
            </td>
          </tr>`;
        }
      }
    }

    html += '</tbody></table>';
    el.innerHTML = html;

    // Update toggle-all button text
    const toggleBtn = document.getElementById('patches-toggle-all');
    if (toggleBtn) toggleBtn.textContent = this._allExpanded ? 'Collapse all' : 'Expand all';

    // Click group header to select + toggle
    el.querySelectorAll('tr.expandable').forEach(row => {
      row.addEventListener('click', () => {
        this._nav.activateElement(row);
        this._toggleRepo(row.dataset.group);
      });
    });

    // Click patch row to select + preview
    el.querySelectorAll('tr.explore-layer-row[data-path]').forEach(row => {
      row.addEventListener('click', () => {
        this._nav.activateElement(row);
        this._showPreview(row.dataset.path);
      });
    });

    // Icon button handlers
    el.querySelectorAll('.row-actions .btn-icon').forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        const row = btn.closest('tr');
        const path = row.dataset.path;
        const act = btn.dataset.action;
        if (act === 'preview' && path) { this._nav.activateElement(row); this._showPreview(path); }
        else if (act === 'view' && path) this._viewPatch(path);
        else if (act === 'edit' && path) this._editPatch(path);
        else if (act === 'lore') this._searchLore(row);
        else if (act === 'copy' && path) this._copyPath(path);
      });
    });

    // Right-click context menu
    el.querySelectorAll('tr.explore-layer-row[data-path]').forEach(row => {
      row.addEventListener('contextmenu', (e) => {
        e.preventDefault();
        this._showContextMenu(e, row);
      });
    });

    // Keyboard nav on all rows
    this._nav.setRows(el.querySelectorAll('tr[role="row"]'));
  },

  async _showContextMenu(e, row) {
    this._nav.activateElement(row);
    const path = row.dataset.path;
    const action = await contextMenu(e.clientX, e.clientY, [
      { label: 'Preview', icon: '\u2299', key: 'Enter', action: 'preview' },
      { label: 'View', icon: '\u2630', key: 'v', action: 'view' },
      { label: 'Edit', icon: '\u270e', key: 'e', action: 'edit' },
      { label: 'Update status', icon: '\u2191', key: 'u', action: 'status' },
      { sep: true },
      { label: 'Search lore', icon: '\u2315', key: 's', action: 'lore' },
      { label: 'Copy path', icon: '\u29c9', key: 'c', action: 'copy' },
    ]);
    if (!action) return;
    if (action === 'preview' && path) this._showPreview(path);
    else if (action === 'view' && path) this._viewPatch(path);
    else if (action === 'edit' && path) this._editPatch(path);
    else if (action === 'status' && path) this._editStatus(path);
    else if (action === 'lore') this._searchLore(row);
    else if (action === 'copy' && path) this._copyPath(path);
  },

  _toggleRepo(group) {
    this._expandedRepos[group] = this._expandedRepos[group] === false;
    if (this._lastPatches) this._renderGrouped(this._lastPatches);
  },

  _toggleAll() {
    this._allExpanded = !this._allExpanded;
    this._expandedRepos = {};
    if (!this._allExpanded) {
      const rows = document.querySelectorAll('tr.expandable[data-group]');
      rows.forEach(r => { this._expandedRepos[r.dataset.group] = false; });
    }
    if (this._lastPatches) this._renderGrouped(this._lastPatches);
  },

  async _showPreview(path) {
    if (!path) return;
    const panel = document.getElementById('patches-preview-panel');
    const resizer = document.getElementById('patches-resizer');
    const title = document.getElementById('patches-preview-title');
    const body = document.getElementById('patches-preview-body');
    const leftPanel = document.getElementById('patches-left');
    if (!panel || !body) return;

    // Track current preview path for popout
    this._previewPath = path;

    // Show panel and resizer
    panel.style.display = '';
    if (resizer) resizer.style.display = '';

    // Apply saved width if no explicit flex set yet
    if (leftPanel && !leftPanel.style.flex) {
      const saved = localStorage.getItem('bit-patches-left-width');
      if (saved) leftPanel.style.flex = '0 0 ' + saved + 'px';
    }

    const fileName = path.split('/').pop();
    if (title) title.textContent = fileName;
    body.innerHTML = '<div class="loading">Loading file</div>';

    try {
      const data = await API.readFile(path);
      const content = data.content || '';
      const lines = content.split('\n');
      const gutterHTML = lines.map((_, i) => (i + 1)).join('\n');

      body.innerHTML =
        '<div class="patches-preview-content">' +
        '<pre class="patches-preview-gutter">' + esc(gutterHTML) + '</pre>' +
        '<pre class="patches-preview-code">' + esc(content) + '</pre>' +
        '</div>';
    } catch (e) {
      body.innerHTML = `<div style="color:var(--red);padding:12px">Error: ${esc(e.message)}</div>`;
    }
  },

  _hidePreview() {
    const panel = document.getElementById('patches-preview-panel');
    const resizer = document.getElementById('patches-resizer');
    const leftPanel = document.getElementById('patches-left');
    this._previewPath = null;
    if (panel) panel.style.display = 'none';
    if (resizer) resizer.style.display = 'none';
    if (leftPanel) leftPanel.style.flex = '';
  },

  async _viewPatch(path) {
    if (!path) return;
    fileEditor(path, {readOnly: true});
  },

  async _editPatch(path) {
    if (!path) return;
    await fileEditor(path, {readOnly: false});
    this._search();
  },

  _copyPath(path) {
    if (!path) return;
    navigator.clipboard.writeText(path).then(() => {
      App.showToast('Path copied', 'success');
    }).catch(() => {
      App.showToast('Copy failed', 'error');
    });
  },

  _searchLore(row) {
    const subject = row.dataset.subject || '';
    if (!subject) return;
    App.state.b4SearchQuery = subject;
    location.hash = '#b4';
  },

  async _editStatus(path) {
    if (!path) return;
    if (!this._statusValuesCache) {
      try { this._statusValuesCache = await API.getStatusValues(); } catch (e) { return; }
    }
    const sv = this._statusValuesCache;
    const statuses = Object.keys(sv.statuses);
    const reasons = sv.inappropriate_reasons || [];

    let bodyHTML = '<div class="patches-status-editor">';
    for (const s of statuses) {
      const info = sv.statuses[s];
      bodyHTML += `<label class="patches-status-radio">
        <input type="radio" name="patch-status" value="${esc(s)}"> ${esc(s)}
        <span style="color:var(--text-muted);font-size:var(--font-size-xs)"> \u2014 ${esc(info.description || '')}</span>
      </label>`;
    }
    bodyHTML += '<div id="patch-status-detail-wrap" style="display:none;margin-top:8px">';
    bodyHTML += '<input type="text" id="patch-status-detail" placeholder="Detail..." style="width:100%">';
    bodyHTML += '</div>';
    bodyHTML += '<div id="patch-status-reason-wrap" style="display:none;margin-top:8px">';
    bodyHTML += '<select id="patch-status-reason" class="form-select" style="width:100%">';
    bodyHTML += '<option value="">Select reason...</option>';
    for (const r of reasons) {
      bodyHTML += `<option value="${esc(r)}">${esc(r)}</option>`;
    }
    bodyHTML += '</select></div>';
    bodyHTML += '</div>';

    const promise = modal('Update Upstream-Status', bodyHTML, [
      {label: 'Cancel', value: 'cancel'},
      {label: 'Save', value: 'save', primary: true},
    ]);

    // Attach radio-button listeners while modal is open
    document.querySelectorAll('input[name="patch-status"]').forEach(radio => {
      radio.addEventListener('change', () => {
        const val = radio.value;
        const info = sv.statuses[val] || {};
        const detailWrap = document.getElementById('patch-status-detail-wrap');
        const reasonWrap = document.getElementById('patch-status-reason-wrap');
        if (val === 'Inappropriate') {
          if (detailWrap) detailWrap.style.display = 'none';
          if (reasonWrap) reasonWrap.style.display = '';
        } else if (info.requires_detail) {
          if (detailWrap) detailWrap.style.display = '';
          if (reasonWrap) reasonWrap.style.display = 'none';
        } else {
          if (detailWrap) detailWrap.style.display = 'none';
          if (reasonWrap) reasonWrap.style.display = 'none';
        }
      });
    });

    const result = await promise;

    if (result !== 'save') return;

    const checked = document.querySelector('input[name="patch-status"]:checked');
    if (!checked) { App.showToast('No status selected', 'error'); return; }
    const status = checked.value;
    let detail = '';
    if (status === 'Inappropriate') {
      const sel = document.getElementById('patch-status-reason');
      detail = sel ? '[' + sel.value + ']' : '';
    } else {
      const inp = document.getElementById('patch-status-detail');
      detail = inp ? inp.value : '';
    }

    try {
      await API.updatePatchStatus(path, status, detail);
      App.showToast('Status updated', 'success');
      this._search();
    } catch (e) {
      App.showToast('Error: ' + e.message, 'error');
    }
  },
};
