/* Terminal view — interactive xterm.js terminal (managed by terminal-ws.js) */
const TerminalView = {
  keyBindings: [
    {key: '`', desc: 'Toggle terminal'},
  ],

  handleKeyboard(e) {},

  render(container) {
    container.innerHTML = '<div class="empty-state"><h3>Interactive Terminal</h3>' +
      '<p>Press <kbd>`</kbd> to toggle the terminal panel</p></div>';
    if (window.TerminalManager) TerminalManager.show();
  },
};
