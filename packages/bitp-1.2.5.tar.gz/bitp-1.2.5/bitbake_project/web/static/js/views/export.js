/* Export view — Pull Request wizard
 * Multi-step: overview → select → insertion → confirm → execute → results
 *
 * Reads App.state.selectedProject for project context.
 */
const ExportView = {
  _nav: KeyboardNav(),
  _step: 'overview',       // overview | select | insertion | confirm | executing | results
  _repos: [],              // export preview data
  _repoSelections: {},     // {display_name: {selected: [sha], insertion_point: ''}}
  _repoQueue: [],          // repos to walk through during sequential select
  _repoQueueIdx: 0,
  _currentRepo: null,      // current repo being selected
  _commitRows: [],         // DOM rows in select/insertion step
  _activeRow: -1,
  _selected: new Set(),
  _rangeAnchor: null,
  _commitData: null,       // cached commit data
  _branchName: '',
  _backup: true,
  _forceReplace: false,
  _results: null,
  _prepState: null,
  _diffMode: 'stat',       // 'stat' or 'diff' for preview panel
  _lastShowData: null,      // cached commit show data
  _numbering: 'global',
  _subjectPrefix: '',
  _seriesVersion: 0,
  _targetDir: '',
  _layout: 'flat',
  _coverLetter: true,
  _saveBrowser: false,

  keyBindings: [
    {key: 'j/k', desc: 'Navigate'},
    {key: 'Enter', desc: 'Select / confirm'},
    {key: 'Tab', desc: 'Toggle commit', action: 'Tab'},
    {key: 'Space', desc: 'Range select', action: ' '},
    {key: 'a', desc: 'Select all', action: 'a'},
    {key: 'n', desc: 'Select none', action: 'n'},
    {key: 'd', desc: 'Toggle stat/diff'},
    {key: 'Esc', desc: 'Back'},
  ],

  handleKeyboard(e) {
    if (this._step === 'overview') {
      if (this._nav.handleBasicKeys(e)) return;
      if (e.key === 'Enter') {
        e.preventDefault();
        const row = this._nav.activeRow();
        if (row) {
          const name = row.dataset.repo;
          if (name) this._enterSelectForRepo(name);
        }
      }
      return;
    }

    if (this._step === 'select') {
      if (e.key === 'Escape') { e.preventDefault(); this._goToOverview(); return; }
      if (e.key === 'j' || e.key === 'ArrowDown') { e.preventDefault(); this._moveSelect(1); return; }
      if (e.key === 'k' || e.key === 'ArrowUp') { e.preventDefault(); this._moveSelect(-1); return; }
      if (e.key === 'Tab') { e.preventDefault(); this._toggleCommit(); return; }
      if (e.key === ' ') { e.preventDefault(); this._rangeSelectCommit(); return; }
      if (e.key === 'a') { e.preventDefault(); this._selectAll(); return; }
      if (e.key === 'n') { e.preventDefault(); this._selectNone(); return; }
      if (e.key === 'd') { e.preventDefault(); this._toggleDiffMode(); return; }
      if (e.key === 'Enter') { e.preventDefault(); this._nextRepo(); return; }
      return;
    }

    if (this._step === 'insertion') {
      if (e.key === 'Escape') { e.preventDefault(); this._enterSelectForRepo(this._currentRepo); return; }
      if (e.key === 'j' || e.key === 'ArrowDown') { e.preventDefault(); this._moveSelect(1); return; }
      if (e.key === 'k' || e.key === 'ArrowUp') { e.preventDefault(); this._moveSelect(-1); return; }
      if (e.key === 'Enter') { e.preventDefault(); this._confirmInsertion(); return; }
      return;
    }

    if (this._step === 'confirm') {
      if (e.key === 'Escape') { e.preventDefault(); this._goToOverview(); return; }
      if (e.key === 'Enter') { e.preventDefault(); this._executePrep(); return; }
      return;
    }

    if (this._step === 'results') {
      if (e.key === 'Escape') { e.preventDefault(); this._goToOverview(); return; }
      return;
    }
  },

  async render(container, state) {
    this._step = 'overview';
    this._repoSelections = {};
    this._results = null;
    this._prepState = null;
    const projName = (App.state.selectedProjectName || App.state.selectedProject || App.state.currentProject || '').split('/').pop();
    const titlePrefix = projName ? projName + ': ' : '';
    container.innerHTML = `
      <div class="view-header">
        <h2>${esc(titlePrefix)}Pull Request</h2>
      </div>
      <div id="export-content" class="loading">Loading export preview</div>
    `;

    try {
      const [preview, prepState] = await Promise.all([
        API.getExportPreview(state.selectedProject),
        API.getPrepState(state.selectedProject).catch(() => null),
      ]);
      this._repos = preview || [];
      this._prepState = prepState;
      this._renderOverview();
    } catch (e) {
      document.getElementById('export-content').innerHTML =
        `<div class="empty-state"><h3>Error</h3><p>${esc(e.message)}</p></div>`;
    }
  },

  // ── Overview step ──────────────────────────────────────

  _renderOverview() {
    const el = document.getElementById('export-content');
    if (!this._repos.length) {
      el.className = '';
      el.innerHTML = '<div class="empty-state"><h3>No commits to export</h3><p>All repos are clean.</p></div>';
      return;
    }

    let html = '';

    // Prep state banner
    if (this._prepState && this._prepState.repos && Object.keys(this._prepState.repos).length) {
      html += `<div class="card" style="margin-bottom:12px;border-left:3px solid var(--yellow)">
        <div style="display:flex;align-items:center;gap:8px">
          <span style="color:var(--yellow);font-weight:600">Previous prep state found</span>
          <span style="color:var(--text-muted);font-size:var(--font-size-sm)">${esc(this._prepState.timestamp || '')}</span>
        </div>
      </div>`;
    }

    // Repo cards (commits are already newest-first from API)
    html += this._repos.map(repo => {
      const commits = repo.commits || [];
      const sel = this._repoSelections[repo.display_name];
      const selCount = sel ? sel.selected.length : 0;
      const selBadge = selCount ? ` <span class="badge" style="background:var(--green);color:var(--bg)">${selCount} selected</span>` : '';
      return `<div class="card export-repo-card" data-repo="${esc(repo.display_name)}" style="margin-bottom:12px;cursor:pointer" tabindex="-1">
        <div class="card-title" style="display:flex;align-items:center;gap:8px">
          <span style="font-weight:600">${esc(repo.display_name)}</span>
          <span class="badge badge-ahead">${repo.local_count} commit${repo.local_count !== 1 ? 's' : ''}</span>${selBadge}
          <span style="color:var(--text-muted)">${esc(repo.branch)}</span>
        </div>
        <ul class="commit-list" style="margin:4px 0 0">
          ${commits.map(c => {
            const sha = Array.isArray(c) ? c[0] : '';
            const subject = Array.isArray(c) ? c[1] : (typeof c === 'string' ? c : '');
            return `<li><code style="color:var(--text-muted);font-size:var(--font-size-sm)">${esc(sha.slice(0, 8))}</code> <span class="commit-subject">${esc(subject.slice(0, 100))}</span></li>`;
          }).join('')}
        </ul>
      </div>`;
    }).join('');

    // Action buttons
    const hasSelections = Object.values(this._repoSelections).some(s => s.selected.length > 0);
    html += `<div style="display:flex;gap:8px;margin-top:12px">
      <button class="btn btn-primary" id="export-start-btn">Start Selection</button>
      ${hasSelections ? '<button class="btn btn-primary" id="export-confirm-btn">Review &amp; Execute</button>' : ''}
    </div>`;

    el.className = '';
    el.innerHTML = html;

    const cards = el.querySelectorAll('.export-repo-card');
    this._nav.setRows(cards);

    cards.forEach(card => {
      card.addEventListener('click', () => {
        this._enterSelectForRepo(card.dataset.repo);
      });
    });

    const startBtn = document.getElementById('export-start-btn');
    if (startBtn) {
      startBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        this._startSequentialSelect();
      });
    }

    const confirmBtn = document.getElementById('export-confirm-btn');
    if (confirmBtn) {
      confirmBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        this._goToConfirm();
      });
    }
  },

  _startSequentialSelect() {
    this._repoQueue = this._repos.map(r => r.display_name);
    this._repoQueueIdx = 0;
    if (this._repoQueue.length) {
      this._enterSelectForRepo(this._repoQueue[0]);
    }
  },

  /** Get raw commits (newest-first) for current repo from preview data. */
  _getRawCommits() {
    const repo = this._repos.find(r => r.display_name === this._currentRepo);
    return repo ? repo.commits || [] : [];
  },

  // ── Per-repo commit selection step ─────────────────────

  _setFullHeightLayout() {
    const el = document.getElementById('export-content');
    el.style.display = 'flex';
    el.style.flexDirection = 'column';
    el.style.flex = '1';
    el.style.minHeight = '0';
    el.style.overflow = 'hidden';
    el.className = '';
  },

  async _enterSelectForRepo(repoName) {
    this._step = 'select';
    this._currentRepo = repoName;
    this._selected = new Set();
    this._rangeAnchor = null;
    this._activeRow = -1;
    this._commitRows = [];
    this._commitData = null;
    this._lastShowData = null;

    // Pre-populate from previous selection
    const prev = this._repoSelections[repoName];
    if (prev) {
      prev.selected.forEach(s => this._selected.add(s));
    }

    const el = document.getElementById('export-content');
    const queueInfo = this._repoQueue.length
      ? ` (${this._repoQueueIdx + 1} of ${this._repoQueue.length})`
      : '';

    this._setFullHeightLayout();
    el.innerHTML = `
      <div style="flex-shrink:0;padding:8px 12px">
        <h2 id="export-select-header" style="margin:0;font-size:var(--font-size-md)">Select commits: ${esc(repoName)}${esc(queueInfo)}</h2>
        <div style="color:var(--text-muted);font-size:var(--font-size-sm);margin-top:4px">
          Tab=toggle  Space=range  a=all  n=none  d=stat/diff  Enter=next  Esc=back
        </div>
      </div>
      <div class="commits-split">
        <div class="commits-left" id="export-left-panel">
          <div id="export-select-list" style="flex:1;overflow-y:auto;min-height:0"></div>
        </div>
        <div class="commits-resizer" id="export-resizer"></div>
        <div class="commits-diff-panel">
          <div class="commits-diff-header">
            <span id="export-diff-title"></span>
            <span id="export-diff-mode-label" class="diff-mode-label">stat</span>
          </div>
          <div id="export-diff-body" style="flex:1;overflow-y:auto;min-height:0">
            <div class="commits-diff-placeholder">Navigate to a commit to preview</div>
          </div>
        </div>
      </div>
      <div style="flex-shrink:0;display:flex;gap:8px;padding:8px 12px;border-top:1px solid var(--border)">
        <button class="btn" id="export-skip-btn">Skip</button>
        <button class="btn btn-primary" id="export-next-btn">Next</button>
      </div>
    `;

    // Commits are already newest-first from the API.
    const commits = this._getRawCommits();
    const localLines = commits.map(c => {
      const sha = Array.isArray(c) ? c[0] : '';
      const subject = Array.isArray(c) ? c[1] : (typeof c === 'string' ? c : '');
      return sha + ' ' + subject;
    });
    this._commitData = { local: localLines, context: [] };
    this._initResizer();
    this._renderSelectList(this._commitData);
  },

  _initResizer() {
    const resizer = document.getElementById('export-resizer');
    const leftPanel = document.getElementById('export-left-panel');
    if (!resizer || !leftPanel) return;

    const saved = localStorage.getItem('bit-export-left-width');
    if (saved) {
      leftPanel.style.flex = '0 0 ' + saved + 'px';
    } else {
      leftPanel.style.flex = '0 0 40%';
    }

    let startX, startW;
    const onMouseMove = (e) => {
      const newW = startW + (e.clientX - startX);
      const clamped = Math.max(200, Math.min(newW, window.innerWidth - 300));
      leftPanel.style.flex = '0 0 ' + clamped + 'px';
    };
    const onMouseUp = () => {
      document.removeEventListener('mousemove', onMouseMove);
      document.removeEventListener('mouseup', onMouseUp);
      document.body.style.cursor = '';
      document.body.style.userSelect = '';
      const w = leftPanel.getBoundingClientRect().width;
      localStorage.setItem('bit-export-left-width', Math.round(w));
    };
    resizer.addEventListener('mousedown', (e) => {
      e.preventDefault();
      startX = e.clientX;
      startW = leftPanel.getBoundingClientRect().width;
      document.body.style.cursor = 'col-resize';
      document.body.style.userSelect = 'none';
      document.addEventListener('mousemove', onMouseMove);
      document.addEventListener('mouseup', onMouseUp);
    });
  },

  _renderSelectList(data) {
    const el = document.getElementById('export-select-list');
    const local = data.local || [];

    if (!local.length) {
      el.innerHTML = '<div style="color:var(--text-muted)">No local commits</div>';
      return;
    }

    let html = '';
    local.forEach(c => {
      let sha = '', fullSha = '', subject = '';
      if (typeof c === 'string') {
        const match = c.match(/^([0-9a-f]{7,40})\s+(.*)$/);
        if (match) { fullSha = match[1]; sha = match[1].slice(0, 7); subject = match[2]; }
        else { subject = c; }
      } else if (c && typeof c === 'object') {
        fullSha = c.sha || c.hash || '';
        sha = fullSha.slice(0, 7);
        subject = c.subject || c.message || '';
      }
      const sel = this._selected.has(fullSha) ? ' commit-row-selected' : '';
      html += `<div class="commit-row${sel}" data-sha="${esc(fullSha)}" tabindex="-1">`;
      html += `<span class="commit-sha-col" style="min-width:60px">${esc(sha)}</span>`;
      html += `<span class="commit-subject-col">${esc(subject)}</span>`;
      html += '</div>';
    });

    el.innerHTML = html;

    this._commitRows = Array.from(el.querySelectorAll('.commit-row[data-sha]'));

    this._commitRows.forEach((row, idx) => {
      row.addEventListener('click', () => {
        this._selectRowByIndex(idx);
        this._showPreview(row.dataset.sha);
      });
    });

    if (this._commitRows.length) {
      this._activeRow = 0;
      this._commitRows[0].classList.add('active');
      this._showPreview(this._commitRows[0].dataset.sha);
    }

    const skipBtn = document.getElementById('export-skip-btn');
    const nextBtn = document.getElementById('export-next-btn');
    if (skipBtn) skipBtn.addEventListener('click', () => this._skipRepo());
    if (nextBtn) nextBtn.addEventListener('click', () => this._nextRepo());

    this._updateSelectBadge();
  },

  _selectRowByIndex(idx) {
    if (idx < 0 || idx >= this._commitRows.length) return;
    if (this._activeRow >= 0 && this._commitRows[this._activeRow]) {
      this._commitRows[this._activeRow].classList.remove('active');
    }
    this._activeRow = idx;
    this._commitRows[idx].classList.add('active');
    this._commitRows[idx].scrollIntoView({ block: 'nearest' });
  },

  _moveSelect(delta) {
    if (!this._commitRows.length) return;
    const prev = this._activeRow;
    let next = prev + delta;
    if (next < 0) next = 0;
    if (next >= this._commitRows.length) next = this._commitRows.length - 1;
    if (next === prev) return;
    this._selectRowByIndex(next);
    const sha = this._commitRows[next].dataset.sha;
    if (sha) this._showPreview(sha);
  },

  // ── Diff preview ───────────────────────────────────────

  async _showPreview(sha) {
    if (!sha) return;
    const title = document.getElementById('export-diff-title');
    const body = document.getElementById('export-diff-body');
    if (!title || !body) return;

    title.textContent = sha.slice(0, 7) + ' \u2014 loading...';
    body.innerHTML = '<div class="loading">Loading commit details</div>';

    try {
      const project = App.state.selectedProject || '';
      const data = await API.getCommitShow(this._currentRepo, sha, project);
      this._lastShowData = data;
      this._renderPreviewBody(data);
      title.textContent = sha.slice(0, 7) + ' \u2014 ' + (data.subject || '');
    } catch (e) {
      this._lastShowData = null;
      body.innerHTML = `<div style="color:var(--red);padding:12px">Error: ${esc(e.message)}</div>`;
      title.textContent = sha.slice(0, 7);
    }
  },

  _renderPreviewBody(data) {
    const body = document.getElementById('export-diff-body');
    const modeLabel = document.getElementById('export-diff-mode-label');
    if (!body || !data) return;

    let html = '';
    html += '<div class="commit-info-header">';
    html += `<div class="commit-info-subject">${esc(data.subject || '')}</div>`;
    if (data.body) {
      html += `<div class="commit-info-body">${esc(data.body)}</div>`;
    }
    html += '<div class="commit-info-meta">';
    html += `<span class="commit-info-sha">${esc((data.sha || '').slice(0, 12))}</span>`;
    if (data.author) html += ` <span class="commit-info-author">${esc(data.author)}</span>`;
    if (data.date) html += ` <span class="commit-info-date">${esc(data.date)}</span>`;
    html += '</div></div>';

    if (this._diffMode === 'stat') {
      html += data.stat ? `<pre class="commits-diff-stat">${esc(data.stat)}</pre>` : '<div style="color:var(--text-muted);padding:12px">No changes</div>';
      if (modeLabel) modeLabel.textContent = 'stat';
    } else {
      if (data.stat) html += `<pre class="commits-diff-stat">${esc(data.stat)}</pre>`;
      html += data.diff ? '<pre class="diff-panel">' + (typeof formatDiff === 'function' ? formatDiff(data.diff) : esc(data.diff)) + '</pre>' : '<div style="color:var(--text-muted);padding:12px">No diff</div>';
      if (modeLabel) modeLabel.textContent = 'diff';
    }
    body.innerHTML = html;
  },

  _toggleDiffMode() {
    this._diffMode = this._diffMode === 'stat' ? 'diff' : 'stat';
    if (this._lastShowData) this._renderPreviewBody(this._lastShowData);
  },

  _toggleCommit() {
    if (this._activeRow < 0 || !this._commitRows[this._activeRow]) return;
    const row = this._commitRows[this._activeRow];
    const sha = row.dataset.sha;
    if (!sha) return;
    if (this._selected.has(sha)) {
      this._selected.delete(sha);
      row.classList.remove('commit-row-selected');
    } else {
      this._selected.add(sha);
      row.classList.add('commit-row-selected');
    }
    this._updateSelectBadge();
  },

  _rangeSelectCommit() {
    if (this._activeRow < 0) return;
    if (this._rangeAnchor === null) {
      this._rangeAnchor = this._activeRow;
      const row = this._commitRows[this._activeRow];
      if (row && row.dataset.sha) {
        this._selected.add(row.dataset.sha);
        row.classList.add('commit-row-selected');
      }
      this._updateSelectBadge();
      return;
    }
    const from = Math.min(this._rangeAnchor, this._activeRow);
    const to = Math.max(this._rangeAnchor, this._activeRow);
    for (let i = from; i <= to; i++) {
      const row = this._commitRows[i];
      if (row && row.dataset.sha) {
        this._selected.add(row.dataset.sha);
        row.classList.add('commit-row-selected');
      }
    }
    this._rangeAnchor = null;
    this._updateSelectBadge();
  },

  _selectAll() {
    this._commitRows.forEach(row => {
      if (row.dataset.sha) {
        this._selected.add(row.dataset.sha);
        row.classList.add('commit-row-selected');
      }
    });
    this._updateSelectBadge();
  },

  _selectNone() {
    this._selected.clear();
    this._rangeAnchor = null;
    this._commitRows.forEach(row => row.classList.remove('commit-row-selected'));
    this._updateSelectBadge();
  },

  _updateSelectBadge() {
    const header = document.getElementById('export-select-header');
    if (!header) return;
    const queueInfo = this._repoQueue.length
      ? ` (${this._repoQueueIdx + 1} of ${this._repoQueue.length})`
      : '';
    header.textContent = `Select commits: ${this._currentRepo}${queueInfo} \u2014 ${this._selected.size} selected`;
  },

  _saveCurrentSelection(insertionPoint) {
    if (!this._currentRepo) return;
    // Raw commits are newest-first from API; collect selected in
    // oldest-first order (reverse of raw) for the backend's cherry-pick.
    const rawCommits = this._getRawCommits();
    const ordered = [];
    for (let i = rawCommits.length - 1; i >= 0; i--) {
      const sha = Array.isArray(rawCommits[i]) ? rawCommits[i][0] : '';
      if (sha && this._selected.has(sha)) ordered.push(sha);
    }
    this._repoSelections[this._currentRepo] = {
      selected: ordered,
      insertion_point: insertionPoint || '',
    };
  },

  _skipRepo() {
    if (this._currentRepo) {
      delete this._repoSelections[this._currentRepo];
    }
    this._advanceQueue();
  },

  _nextRepo() {
    if (!this._selected.size) {
      this._skipRepo();
      return;
    }
    // If all commits selected, no insertion point needed — save and advance
    const rawCommits = this._getRawCommits();
    if (this._selected.size >= rawCommits.length) {
      this._saveCurrentSelection('');
      this._advanceQueue();
      return;
    }
    // Some commits not selected — show insertion point picker
    this._enterInsertionPoint();
  },

  _advanceQueue() {
    if (this._repoQueue.length && this._repoQueueIdx < this._repoQueue.length - 1) {
      this._repoQueueIdx++;
      this._enterSelectForRepo(this._repoQueue[this._repoQueueIdx]);
    } else {
      const hasSelections = Object.values(this._repoSelections).some(s => s.selected.length > 0);
      if (hasSelections) {
        this._goToConfirm();
      } else {
        this._goToOverview();
      }
    }
  },

  // ── Insertion point step ───────────────────────────────

  _enterInsertionPoint() {
    this._step = 'insertion';
    this._activeRow = -1;
    this._commitRows = [];

    // Raw commits are newest-first from preview data.
    // Remaining = not selected (preserves newest-first order).
    const rawCommits = this._getRawCommits();
    const remaining = rawCommits.filter(c => {
      const sha = Array.isArray(c) ? c[0] : '';
      return !this._selected.has(sha);
    });
    // Also build selected list for context display
    const selectedList = rawCommits.filter(c => {
      const sha = Array.isArray(c) ? c[0] : '';
      return this._selected.has(sha);
    });

    const el = document.getElementById('export-content');
    this._setFullHeightLayout();
    el.innerHTML = `
      <div style="flex-shrink:0;padding:8px 12px">
        <h2 style="margin:0;font-size:var(--font-size-md)">Insertion point: ${esc(this._currentRepo)}</h2>
        <div style="color:var(--text-muted);font-size:var(--font-size-sm);margin-top:4px">
          Select where the ${this._selected.size} chosen commit${this._selected.size !== 1 ? 's' : ''} should be inserted.
          j/k=navigate  Enter=confirm  Esc=back to selection
        </div>
      </div>
      <div id="export-insertion-list" style="flex:1;overflow-y:auto;min-height:0;padding:0 12px"></div>
      <div style="flex-shrink:0;display:flex;gap:8px;padding:8px 12px;border-top:1px solid var(--border)">
        <button class="btn" id="export-insert-back">Back</button>
        <button class="btn btn-primary" id="export-insert-confirm">Confirm</button>
      </div>
    `;

    const listEl = document.getElementById('export-insertion-list');
    let html = '';

    // Show remaining commits newest-first (already in that order from API).
    // "Insert after this commit" = selected commits land below this one in the stack.
    remaining.forEach(c => {
      const sha = Array.isArray(c) ? c[0] : '';
      const subject = Array.isArray(c) ? c[1] : (typeof c === 'string' ? c : '');
      html += `<div class="commit-row" data-sha="${esc(sha)}" data-insert="commit" tabindex="-1">`;
      html += `<span class="commit-sha-col" style="min-width:60px">${esc(sha.slice(0, 7))}</span>`;
      html += `<span class="commit-subject-col">${esc(subject)}</span>`;
      html += '</div>';
    });

    // Selected commits shown in green for context (not selectable)
    html += '<div style="border-top:2px solid var(--green);margin:6px 0;padding-top:4px;color:var(--green);font-size:var(--font-size-sm);font-weight:600">';
    html += `\u2193 ${this._selected.size} selected commit${this._selected.size !== 1 ? 's' : ''} inserted here \u2193</div>`;
    selectedList.forEach(c => {
      const sha = Array.isArray(c) ? c[0] : '';
      const subject = Array.isArray(c) ? c[1] : (typeof c === 'string' ? c : '');
      html += `<div class="commit-row" style="opacity:0.6;color:var(--green)" tabindex="-1">`;
      html += `<span class="commit-sha-col" style="min-width:60px">${esc(sha.slice(0, 7))}</span>`;
      html += `<span class="commit-subject-col">${esc(subject)}</span>`;
      html += '</div>';
    });

    // Default insertion point: at the base (selected commits go first, before remaining)
    html += '<div style="border-top:1px solid var(--border);margin:6px 0"></div>';
    html += `<div class="commit-row" data-sha="" data-insert="base" tabindex="-1" style="color:var(--text-muted)">`;
    html += `<span class="commit-sha-col" style="min-width:60px">\u2500\u2500\u2500</span>`;
    html += `<span class="commit-subject-col">Base (default \u2014 selected commits go first)</span>`;
    html += '</div>';

    listEl.innerHTML = html;

    // Only insertion-point rows are navigable
    this._commitRows = Array.from(listEl.querySelectorAll('.commit-row[data-insert]'));
    this._commitRows.forEach((row, idx) => {
      row.addEventListener('click', () => {
        this._selectRowByIndex(idx);
      });
    });

    // Default: select the "base" row (last one)
    if (this._commitRows.length) {
      this._activeRow = this._commitRows.length - 1;
      this._commitRows[this._activeRow].classList.add('active');
    }

    document.getElementById('export-insert-back').addEventListener('click', () => {
      this._enterSelectForRepo(this._currentRepo);
    });
    document.getElementById('export-insert-confirm').addEventListener('click', () => {
      this._confirmInsertion();
    });
  },

  _confirmInsertion() {
    // Read the selected insertion point
    let insertionPoint = '';
    if (this._activeRow >= 0 && this._commitRows[this._activeRow]) {
      const row = this._commitRows[this._activeRow];
      if (row.dataset.insert === 'commit') {
        insertionPoint = row.dataset.sha;
      }
      // else 'base' → empty string → backend uses base_ref
    }
    this._saveCurrentSelection(insertionPoint);
    this._advanceQueue();
  },

  _resetContentStyle() {
    const el = document.getElementById('export-content');
    if (el) {
      el.style.display = '';
      el.style.flexDirection = '';
      el.style.flex = '';
      el.style.minHeight = '';
      el.style.overflow = '';
    }
  },

  _goToOverview() {
    this._step = 'overview';
    this._repoQueue = [];
    this._repoQueueIdx = 0;
    this._resetContentStyle();
    this._renderOverview();
  },

  // ── Confirm step ───────────────────────────────────────

  _goToConfirm() {
    this._step = 'confirm';
    this._resetContentStyle();
    const el = document.getElementById('export-content');
    const entries = Object.entries(this._repoSelections).filter(([, v]) => v.selected.length > 0);

    if (!entries.length) {
      this._goToOverview();
      return;
    }

    let html = `<div class="view-header" style="margin-bottom:12px"><h2>Confirm Preparation</h2></div>`;

    html += '<table style="width:100%;border-collapse:collapse;margin-bottom:16px">';
    html += '<thead><tr style="border-bottom:1px solid var(--border)">';
    html += '<th style="text-align:left;padding:4px 8px">Repo</th>';
    html += '<th style="text-align:right;padding:4px 8px">Selected</th>';
    html += '<th style="text-align:right;padding:4px 8px">Total</th>';
    html += '<th style="text-align:left;padding:4px 8px">Insertion</th>';
    html += '</tr></thead><tbody>';
    for (const [name, sel] of entries) {
      const repo = this._repos.find(r => r.display_name === name);
      const total = repo ? repo.local_count : '?';
      const ins = sel.insertion_point ? sel.insertion_point.slice(0, 8) : 'base';
      html += `<tr style="border-bottom:1px solid var(--border)">`;
      html += `<td style="padding:4px 8px">${esc(name)}</td>`;
      html += `<td style="text-align:right;padding:4px 8px">${sel.selected.length}</td>`;
      html += `<td style="text-align:right;padding:4px 8px">${total}</td>`;
      html += `<td style="padding:4px 8px"><code style="color:var(--text-muted)">${esc(ins)}</code></td>`;
      html += '</tr>';
    }
    html += '</tbody></table>';

    html += `<div style="margin-bottom:12px">
      <label style="display:block;margin-bottom:4px;color:var(--text-muted)">Pull branch name (optional)</label>
      <input type="text" id="export-branch-name" value="${esc(this._branchName)}"
             placeholder="e.g. pull-request" style="width:300px;padding:4px 8px;background:var(--bg);color:var(--fg);border:1px solid var(--border);border-radius:4px">
    </div>`;

    html += `<div style="margin-bottom:16px;display:flex;gap:16px;align-items:center">
      <label style="display:flex;align-items:center;gap:4px;cursor:pointer">
        <input type="checkbox" id="export-backup" ${this._backup ? 'checked' : ''}> Create backup branches
      </label>
      <label style="display:flex;align-items:center;gap:4px;cursor:pointer">
        <input type="checkbox" id="export-force-replace" ${this._forceReplace ? 'checked' : ''}> Force replace existing branch
      </label>
    </div>`;

    html += `<div style="display:flex;gap:8px">
      <button class="btn" id="export-back-btn">Back</button>
      <button class="btn btn-primary" id="export-execute-btn">Execute Preparation</button>
    </div>`;

    el.innerHTML = html;

    document.getElementById('export-back-btn').addEventListener('click', () => this._goToOverview());
    document.getElementById('export-execute-btn').addEventListener('click', () => this._executePrep());
  },

  // ── Execute step ───────────────────────────────────────

  async _executePrep() {
    const branchInput = document.getElementById('export-branch-name');
    const backupInput = document.getElementById('export-backup');
    const forceInput = document.getElementById('export-force-replace');
    this._branchName = branchInput ? branchInput.value.trim() : '';
    this._backup = backupInput ? backupInput.checked : true;
    this._forceReplace = forceInput ? forceInput.checked : false;

    this._step = 'executing';
    this._resetContentStyle();
    const el = document.getElementById('export-content');
    el.innerHTML = `
      <div class="view-header" style="margin-bottom:12px"><h2>Preparing Export...</h2></div>
      <div class="loading">Reordering commits and creating branches</div>
    `;

    const repoConfigs = [];
    for (const [name, sel] of Object.entries(this._repoSelections)) {
      if (sel.selected.length) {
        repoConfigs.push({
          repo_name: name,
          selected_commits: sel.selected,
          insertion_point: sel.insertion_point || '',
        });
      }
    }

    try {
      const project = App.state.selectedProject || '';
      const result = await API.exportPrepare({
        repos: repoConfigs,
        branch_name: this._branchName,
        force_replace: this._forceReplace,
        backup: this._backup,
      }, project);
      this._results = result;
      this._renderResults();
    } catch (e) {
      el.innerHTML = `
        <div class="view-header" style="margin-bottom:12px"><h2>Preparation Failed</h2></div>
        <div style="color:var(--red)">${esc(e.message)}</div>
        <button class="btn" id="export-results-back" style="margin-top:12px">Back</button>
      `;
      document.getElementById('export-results-back').addEventListener('click', () => this._goToOverview());
    }
  },

  // ── Results step ───────────────────────────────────────

  _renderResults() {
    this._step = 'results';
    const el = document.getElementById('export-content');
    const results = this._results?.results || [];

    let html = `<div class="view-header" style="margin-bottom:12px"><h2>Preparation Results</h2></div>`;

    if (this._results?.prep_state_saved) {
      html += '<div style="color:var(--green);margin-bottom:12px">Prep state saved.</div>';
    }

    results.forEach(r => {
      const icon = r.status === 'ok' ? '\u2713' : '\u2717';
      const color = r.status === 'ok' ? 'var(--green)' : 'var(--red)';
      html += `<div class="card" style="margin-bottom:8px">
        <div style="display:flex;align-items:center;gap:8px">
          <span style="color:${color};font-weight:bold">${icon}</span>
          <span style="font-weight:600">${esc(r.repo)}</span>
          <span style="color:var(--text-muted)">${esc(r.message || '')}</span>
        </div>`;
      if (r.branch_message) {
        const bColor = r.branch_ok ? 'var(--green)' : 'var(--yellow)';
        html += `<div style="margin-top:4px;color:${bColor};font-size:var(--font-size-sm)">${esc(r.branch_message)}</div>`;
      }
      if (r.cut_point) {
        html += `<div style="margin-top:4px;font-size:var(--font-size-sm);color:var(--text-muted)">Cut point: <code>${esc(r.cut_point.slice(0, 12))}</code></div>`;
      }
      if (r.status === 'ok') {
        html += `<button class="btn" style="margin-top:8px" data-export-repo="${esc(r.repo)}">Export Patches</button>`;
      }
      html += '</div>';
    });

    // Export options card (only if any repos succeeded)
    const hasSuccess = results.some(r => r.status === 'ok');
    if (hasSuccess) {
      html += `<div class="card" style="margin-top:12px;margin-bottom:8px">
        <div style="font-weight:600;margin-bottom:8px">Export Options</div>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;align-items:center">
          <label>Layout</label>
          <select id="export-opt-layout">
            <option value="flat"${this._layout === 'flat' ? ' selected' : ''}>Flat</option>
            <option value="per-repo"${this._layout === 'per-repo' ? ' selected' : ''}>Per-repo</option>
          </select>
          <label>Numbering</label>
          <select id="export-opt-numbering">
            <option value="global"${this._numbering === 'global' ? ' selected' : ''}>Global</option>
            <option value="per-repo"${this._numbering === 'per-repo' ? ' selected' : ''}>Per-repo</option>
          </select>
          <label>Subject prefix</label>
          <input type="text" id="export-opt-prefix" value="${esc(this._subjectPrefix)}" placeholder="e.g. RFC">
          <label>Series version</label>
          <input type="number" id="export-opt-version" value="${this._seriesVersion}" min="0" style="width:80px">
          <label>Cover letter</label>
          <input type="checkbox" id="export-opt-cover"${this._coverLetter ? ' checked' : ''} style="justify-self:start">
        </div>
        <div style="font-weight:600;margin-top:12px;margin-bottom:6px">Save to</div>
        <div style="display:flex;flex-direction:column;gap:6px">
          <label style="display:flex;align-items:center;gap:6px">
            <input type="checkbox" id="export-opt-save-remote" checked>
            Project host <span style="color:var(--text-muted);font-size:var(--font-size-sm)">(where the repos are)</span>
          </label>
          <div style="margin-left:24px">
            <input type="text" id="export-opt-targetdir" value="${esc(this._targetDir || '~/patches')}" placeholder="~/patches" style="width:100%">
          </div>
          <label style="display:flex;align-items:center;gap:6px">
            <input type="checkbox" id="export-opt-save-browser"${this._saveBrowser ? ' checked' : ''}>
            Browser download <span style="color:var(--text-muted);font-size:var(--font-size-sm)">(to this machine)</span>
          </label>
        </div>
        <button class="btn btn-primary" style="margin-top:12px" id="export-all-patches">Export All Patches</button>
      </div>`;
    }

    html += `<div style="display:flex;gap:8px;margin-top:16px">
      <button class="btn" id="export-results-done">Done</button>
    </div>`;

    el.innerHTML = html;

    // ── Helper: read current export options from DOM ──
    const _readOpts = () => {
      this._layout = document.getElementById('export-opt-layout')?.value || 'flat';
      this._numbering = document.getElementById('export-opt-numbering')?.value || 'global';
      this._subjectPrefix = document.getElementById('export-opt-prefix')?.value || '';
      this._seriesVersion = parseInt(document.getElementById('export-opt-version')?.value, 10) || 0;
      this._coverLetter = document.getElementById('export-opt-cover')?.checked ?? true;
      const saveRemote = document.getElementById('export-opt-save-remote')?.checked ?? true;
      this._targetDir = saveRemote ? (document.getElementById('export-opt-targetdir')?.value || '') : '';
      this._saveBrowser = document.getElementById('export-opt-save-browser')?.checked ?? false;
    };

    // ── Helper: build batch request body from selections ──
    const _buildRequest = (repoNames) => {
      _readOpts();
      const repos = [];
      for (const name of repoNames) {
        const sel = this._repoSelections[name];
        if (sel && sel.selected.length) {
          repos.push({ repo_name: name, commits: sel.selected });
        }
      }
      return {
        repos,
        numbering: this._numbering,
        subject_prefix: this._subjectPrefix,
        series_version: this._seriesVersion,
        cover_letter: this._coverLetter,
        target_dir: this._targetDir,
        layout: this._layout,
        keep_content: this._saveBrowser,
      };
    };

    // ── Helper: trigger browser downloads for patches ──
    const _downloadPatches = (patches) => {
      for (const patch of patches) {
        if (patch.error) { App.showToast(patch.error, 'error'); continue; }
        if (!patch.content) continue;
        const blob = new Blob([patch.content], { type: 'text/plain' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = patch.filename;
        document.body.appendChild(a);
        a.click();
        a.remove();
        URL.revokeObjectURL(url);
      }
    };

    // ── Helper: handle export response (save toast / browser download) ──
    const _handleExportResult = (data) => {
      const patches = data.patches || [];
      if (data.save_error) {
        App.showToast('Save error: ' + data.save_error, 'error');
      }
      if (data.saved_to) {
        const host = data.saved_host ? ` on ${data.saved_host}` : '';
        App.showToast(`Saved ${data.saved_count} file(s) to ${data.saved_to}${host}`, 'success');
      }
      // Browser download: explicitly requested or no remote save was attempted
      if (this._saveBrowser || !this._targetDir) {
        const downloadable = patches.filter(p => !p.error && p.content);
        if (downloadable.length) {
          _downloadPatches(downloadable);
          App.showToast('Downloaded ' + downloadable.length + ' patch(es)', 'success');
        }
      }
    };

    // ── Per-repo "Export Patches" buttons ──
    el.querySelectorAll('[data-export-repo]').forEach(btn => {
      btn.addEventListener('click', async () => {
        const repoName = btn.dataset.exportRepo;
        const sel = this._repoSelections[repoName];
        if (!sel || !sel.selected.length) {
          App.showToast('No commits selected for ' + repoName, 'error');
          return;
        }
        btn.disabled = true;
        btn.textContent = 'Exporting...';
        try {
          const project = App.state.selectedProject || '';
          const req = _buildRequest([repoName]);
          const data = await API.exportBatchPatches(req, project);
          _handleExportResult(data);
        } catch (e) {
          App.showToast('Export failed: ' + e.message, 'error');
        }
        btn.disabled = false;
        btn.textContent = 'Export Patches';
      });
    });

    // ── "Export All Patches" button ──
    const allBtn = document.getElementById('export-all-patches');
    if (allBtn) {
      allBtn.addEventListener('click', async () => {
        const repoNames = results.filter(r => r.status === 'ok').map(r => r.repo);
        const req = _buildRequest(repoNames);
        if (!req.repos.length) {
          App.showToast('No commits selected', 'error');
          return;
        }
        allBtn.disabled = true;
        allBtn.textContent = 'Exporting...';
        try {
          const project = App.state.selectedProject || '';
          const data = await API.exportBatchPatches(req, project);
          _handleExportResult(data);
        } catch (e) {
          App.showToast('Export failed: ' + e.message, 'error');
        }
        allBtn.disabled = false;
        allBtn.textContent = 'Export All Patches';
      });
    }

    document.getElementById('export-results-done').addEventListener('click', () => this._goToOverview());
  },
};
