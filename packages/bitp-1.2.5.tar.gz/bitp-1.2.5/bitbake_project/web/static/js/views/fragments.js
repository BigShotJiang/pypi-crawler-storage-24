/* Fragments view — fragment browser with split-pane preview, search, keybindings */
const FragmentsView = {
  _nav: KeyboardNav(),
  _expandedDomains: {},
  _allExpanded: true,
  _previewFrag: null,
  _lastFragments: null,
  _toolcfgPath: null,
  _searchTerm: '',

  keyBindings: [
    {key: 'j/k', desc: 'Navigate rows'},
    {key: 'Enter', desc: 'Preview / toggle group', action: 'Enter'},
    {key: 'Space', desc: 'Toggle enabled', action: ' '},
    {key: 'v', desc: 'View .conf file', action: 'v'},
    {key: 'c', desc: 'Edit toolcfg.conf', action: 'c'},
    {key: 'b', desc: 'Set builtin value', action: 'b'},
    {key: 'y', desc: 'Copy name', action: 'y'},
    {key: '/', desc: 'Search', action: '/'},
    {key: 'x', desc: 'Expand/collapse all', action: 'x'},
  ],

  handleKeyboard(e) {
    if (e.key === 'Escape') {
      const panel = document.getElementById('fragments-preview-panel');
      if (panel && panel.style.display !== 'none') {
        e.preventDefault();
        this._hidePreview();
        return;
      }
    }
    if (this._nav.handleBasicKeys(e)) return;
    const row = this._nav.activeRow();
    if (e.key === 'Enter' && row) {
      e.preventDefault();
      if (row.dataset.toolcfg) {
        this._showToolcfgPreview();
      } else if (row.classList.contains('expandable')) {
        this._toggleDomain(row.dataset.domain);
      } else {
        this._showPreviewForRow(row);
      }
    } else if (e.key === ' ' && row) {
      e.preventDefault();
      const cb = row.querySelector('input[data-frag]');
      if (cb) { cb.checked = !cb.checked; cb.dispatchEvent(new Event('change')); }
    } else if (e.key === 'v' && row) {
      e.preventDefault();
      this._viewConfFile(row);
    } else if (e.key === 'c') {
      e.preventDefault();
      this._editToolcfg();
    } else if (e.key === 'b' && row) {
      e.preventDefault();
      this._setBuiltinValue(row);
    } else if (e.key === 'y' && row) {
      e.preventDefault();
      this._copyName(row);
    } else if (e.key === '/') {
      e.preventDefault();
      const input = document.getElementById('fragment-search');
      if (input) input.focus();
    } else if (e.key === 'x') {
      e.preventDefault();
      this._toggleAll();
    }
  },

  async render(container, state) {
    container.innerHTML = `
      <div class="fragments-split">
        <div class="fragments-left" id="fragments-left">
          <div class="fragments-left-header">
            <h2>Fragments</h2>
          </div>
          <div id="fragments-list" class="loading">Loading fragments</div>
        </div>
        <div class="fragments-resizer" id="fragments-resizer" style="display:none"></div>
        <div id="fragments-preview-panel" class="fragments-preview-panel" style="display:none">
          <div class="fragments-preview-header">
            <span id="fragments-preview-title"></span>
            <div class="btn-group">
              <button class="btn" id="fragments-preview-popout" title="Open in modal (v)">\u2197</button>
              <button class="btn" id="fragments-preview-close" title="Close preview">\u00d7</button>
            </div>
          </div>
          <div id="fragments-preview-body">
            <div class="fragments-preview-placeholder">Select a fragment to preview</div>
          </div>
        </div>
      </div>
      <div class="fragments-footer">
        <div class="fragments-footer-left">
          <input type="text" id="fragment-search" placeholder="Search fragments...">
          <button class="btn" id="fragment-reset" style="display:none" title="Clear search">Reset</button>
        </div>
        <div class="fragments-footer-right">
          <button class="btn" id="fragments-toggle-all" title="Expand/collapse all groups">Collapse all</button>
        </div>
      </div>
    `;

    // Search handlers
    const searchInput = document.getElementById('fragment-search');
    searchInput.addEventListener('input', () => this._onSearchInput());
    searchInput.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') { searchInput.blur(); e.preventDefault(); }
    });
    document.getElementById('fragment-reset').addEventListener('click', () => {
      searchInput.value = '';
      this._searchTerm = '';
      document.getElementById('fragment-reset').style.display = 'none';
      if (this._lastFragments) this._renderFragments(this._lastFragments);
    });
    document.getElementById('fragments-toggle-all').addEventListener('click', () => this._toggleAll());
    document.getElementById('fragments-preview-close').addEventListener('click', () => this._hidePreview());
    document.getElementById('fragments-preview-popout').addEventListener('click', async () => {
      if (this._previewFrag && this._previewFrag.path) {
        const isToolcfg = this._previewFrag.is_toolcfg;
        await fileEditor(this._previewFrag.path, {readOnly: !isToolcfg});
        if (isToolcfg) {
          const fragments = await API.getFragments();
          this._lastFragments = fragments;
          this._renderFragments(fragments);
          this._showToolcfgPreview();
        }
      }
    });

    // Resizable divider
    const resizer = document.getElementById('fragments-resizer');
    const leftPanel = document.getElementById('fragments-left');
    if (resizer && leftPanel) {
      const saved = localStorage.getItem('bit-fragments-left-width');
      if (saved) leftPanel.style.flex = '0 0 ' + saved + 'px';

      let startX, startW;
      const onMouseMove = (e) => {
        const newW = startW + (e.clientX - startX);
        const clamped = Math.max(200, Math.min(newW, window.innerWidth - 300));
        leftPanel.style.flex = '0 0 ' + clamped + 'px';
      };
      const onMouseUp = () => {
        document.removeEventListener('mousemove', onMouseMove);
        document.removeEventListener('mouseup', onMouseUp);
        document.body.style.cursor = '';
        document.body.style.userSelect = '';
        const w = leftPanel.getBoundingClientRect().width;
        localStorage.setItem('bit-fragments-left-width', Math.round(w));
      };
      resizer.addEventListener('mousedown', (e) => {
        e.preventDefault();
        startX = e.clientX;
        startW = leftPanel.getBoundingClientRect().width;
        document.body.style.cursor = 'col-resize';
        document.body.style.userSelect = 'none';
        document.addEventListener('mousemove', onMouseMove);
        document.addEventListener('mouseup', onMouseUp);
      });
    }

    try {
      const [fragments, tcfg] = await Promise.all([
        API.getFragments(),
        API.getToolcfgPath().catch(() => null),
      ]);
      if (fragments && fragments.error) {
        document.getElementById('fragments-list').innerHTML =
          `<div class="empty-state"><h3>Error</h3><p>${fragments.error}</p></div>`;
        return;
      }
      this._lastFragments = fragments;
      this._toolcfgPath = tcfg ? tcfg.path : null;
      this._renderFragments(fragments);
      // Show toolcfg.conf preview on load so the split pane is visible from the start
      if (this._toolcfgPath) {
        this._showToolcfgPreview();
      }
    } catch (e) {
      document.getElementById('fragments-list').innerHTML =
        `<div class="empty-state"><h3>Error</h3><p>${e.message}</p></div>`;
    }
  },

  _onSearchInput() {
    const input = document.getElementById('fragment-search');
    this._searchTerm = (input ? input.value : '').toLowerCase();
    const resetBtn = document.getElementById('fragment-reset');
    if (resetBtn) resetBtn.style.display = this._searchTerm ? '' : 'none';
    if (this._lastFragments) this._renderFragments(this._lastFragments);
  },

  _filterFragments(fragments) {
    if (!this._searchTerm) return fragments;
    const q = this._searchTerm;
    return fragments.filter(f => {
      const hay = (f.name + ' ' + (f.summary || '') + ' ' + (f.description || '')).toLowerCase();
      return hay.includes(q);
    });
  },

  _renderFragments(fragments) {
    const el = document.getElementById('fragments-list');
    const filtered = this._filterFragments(fragments);
    if (!filtered || !filtered.length) {
      el.className = '';
      el.innerHTML = this._searchTerm
        ? '<div class="empty-state"><h3>No matching fragments</h3></div>'
        : '<div class="empty-state"><h3>No fragments found</h3></div>';
      this._nav.setRows([]);
      return;
    }

    // Separate builtins from regular fragments
    const builtins = filtered.filter(f => f.domain === 'builtin');
    const regular = filtered.filter(f => f.domain !== 'builtin');

    // Group regular fragments by layer/domain
    const byGroup = {};
    for (const f of regular) {
      const group = f.layer ? `${f.layer}/${f.domain}` : (f.domain || 'other');
      if (!byGroup[group]) byGroup[group] = [];
      byGroup[group].push(f);
    }
    const groups = Object.keys(byGroup).sort();

    el.className = '';
    let html = `<table class="data-table" id="fragments-table">
      <thead><tr><th style="width:2ch"></th><th>Fragment</th><th>Summary</th><th style="width:4ch">Enabled</th><th class="row-actions-col"></th></tr></thead>
      <tbody>`;

    // toolcfg.conf entry at top (like TUI)
    if (this._toolcfgPath) {
      html += `<tr class="explore-layer-row" data-toolcfg="1" role="row" tabindex="-1">
        <td></td>
        <td><span style="color:var(--cyan)">\u2699 toolcfg.conf</span></td>
        <td style="color:var(--text-muted)">${esc(this._toolcfgPath)}</td>
        <td></td>
        <td><button class="btn-xs toolcfg-edit-btn" title="Edit toolcfg.conf" style="cursor:pointer">&#9998;</button></td>
      </tr>`;
    }

    // Builtin entries first (machine, distro)
    if (builtins.length) {
      html += `<tr class="expandable" data-domain="builtin" role="row" tabindex="-1">
        <td><span class="dash-row-toggle">\u25be</span></td>
        <td colspan="4" style="font-weight:600;color:var(--text-primary)">
          Built-in <span style="color:var(--text-muted);font-weight:400">(${builtins.length})</span>
        </td>
      </tr>`;
      for (let i = 0; i < builtins.length; i++) {
        const b = builtins[i];
        const isLast = i === builtins.length - 1;
        const valText = b.builtin_value || '(not set)';
        const valColor = b.builtin_value ? 'var(--green)' : 'var(--text-muted)';
        html += `<tr class="explore-layer-row${isLast ? ' tree-last' : ''}" data-frag-name="${esc(b.name)}" data-is-builtin="1" data-builtin-prefix="${esc(b.builtin_prefix || '')}" role="row" tabindex="-1">
          <td class="tree-line"></td>
          <td><span style="color:var(--accent)">${esc(b.name)}</span></td>
          <td style="color:${valColor}">${esc(valText)}</td>
          <td></td>
          <td class="row-actions">
            <button class="btn-icon" data-action="preview" title="Preview (Enter)">\u2299</button>
            <button class="btn-icon" data-action="setvalue" title="Set value (b)">\u2699</button>
            <button class="btn-icon" data-action="copy" title="Copy name (y)">\u29c9</button>
          </td>
        </tr>`;
      }
    }

    // Regular fragment groups
    for (const group of groups) {
      const frags = byGroup[group];
      const isExpanded = this._expandedDomains[group] !== false;
      const chevron = isExpanded ? '\u25be' : '\u25b8';
      const enabledCount = frags.filter(f => f.enabled).length;
      const countBadge = enabledCount > 0
        ? `<span style="color:var(--green);font-weight:400">${enabledCount} enabled</span>`
        : '';

      html += `<tr class="expandable" data-domain="${esc(group)}" role="row" tabindex="-1">
        <td><span class="dash-row-toggle">${chevron}</span></td>
        <td colspan="4" style="font-weight:600;color:var(--text-primary)">
          ${esc(group)} <span style="color:var(--text-muted);font-weight:400">(${frags.length})</span> ${countBadge}
        </td>
      </tr>`;

      if (isExpanded) {
        for (let i = 0; i < frags.length; i++) {
          const f = frags[i];
          const isLast = i === frags.length - 1;
          const shortName = f.name.split('/').pop();
          html += `<tr class="explore-layer-row${isLast ? ' tree-last' : ''}" data-frag-name="${esc(f.name)}" data-frag-path="${esc(f.path || '')}" role="row" tabindex="-1">
            <td class="tree-line"></td>
            <td>${esc(shortName)}</td>
            <td style="color:var(--text-muted)">${esc(f.summary || '')}</td>
            <td>
              <label class="toggle-switch">
                <input type="checkbox" data-frag="${esc(f.name)}" ${f.enabled ? 'checked' : ''}>
                <span class="toggle-slider"></span>
              </label>
            </td>
            <td class="row-actions">
              <button class="btn-icon" data-action="preview" title="Preview (Enter)">\u2299</button>
              <button class="btn-icon" data-action="viewconf" title="View .conf (v)">\u2630</button>
              <button class="btn-icon" data-action="copy" title="Copy name (y)">\u29c9</button>
            </td>
          </tr>`;
        }
      }
    }

    html += '</tbody></table>';
    el.innerHTML = html;

    // Update toggle-all button text
    const toggleBtn = document.getElementById('fragments-toggle-all');
    if (toggleBtn) toggleBtn.textContent = this._allExpanded ? 'Collapse all' : 'Expand all';

    // Click group header to select + toggle
    el.querySelectorAll('tr.expandable').forEach(row => {
      row.addEventListener('click', () => {
        this._nav.activateElement(row);
        this._toggleDomain(row.dataset.domain);
      });
    });

    // Click toolcfg row to select + preview toolcfg.conf
    el.querySelectorAll('tr[data-toolcfg]').forEach(row => {
      row.addEventListener('click', () => {
        this._nav.activateElement(row);
        this._showToolcfgPreview();
      });
    });

    // Edit button on toolcfg row
    el.querySelectorAll('.toolcfg-edit-btn').forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        this._editToolcfg();
      });
    });

    // Click fragment row to select + preview
    el.querySelectorAll('tr.explore-layer-row[data-frag-name]').forEach(row => {
      row.addEventListener('click', () => {
        this._nav.activateElement(row);
        this._showPreviewForRow(row);
      });
    });

    // Toggle checkboxes
    el.querySelectorAll('input[data-frag]').forEach(cb => {
      cb.addEventListener('change', async (e) => {
        e.stopPropagation();
        const name = cb.dataset.frag;
        try {
          if (cb.checked) await API.enableFragment(name);
          else await API.disableFragment(name);
          App.showToast(`Fragment ${cb.checked ? 'enabled' : 'disabled'}: ${name}`, 'success');
          // Refresh fragment list to keep UI in sync
          const fragments = await API.getFragments();
          this._lastFragments = fragments;
          this._renderFragments(fragments);
          // Refresh toolcfg.conf preview to reflect the change
          if (this._previewFrag && this._previewFrag.is_toolcfg) {
            this._showToolcfgPreview();
          }
        } catch (err) {
          cb.checked = !cb.checked;
          App.showToast(err.message, 'error');
        }
      });
      // Prevent row click from triggering when clicking checkbox
      cb.closest('td').addEventListener('click', e => e.stopPropagation());
    });

    // Icon button handlers
    el.querySelectorAll('.row-actions .btn-icon').forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        const row = btn.closest('tr');
        const act = btn.dataset.action;
        if (act === 'preview') { this._nav.activateElement(row); this._showPreviewForRow(row); }
        else if (act === 'viewconf') this._viewConfFile(row);
        else if (act === 'setvalue') this._setBuiltinValue(row);
        else if (act === 'copy') this._copyName(row);
      });
    });

    // Right-click context menu
    el.querySelectorAll('tr.explore-layer-row[data-frag-name]').forEach(row => {
      row.addEventListener('contextmenu', (e) => {
        e.preventDefault();
        this._showContextMenu(e, row);
      });
    });

    // Keyboard nav on all rows
    this._nav.setRows(el.querySelectorAll('tr[role="row"]'));
  },

  _findFragByName(name) {
    if (!this._lastFragments) return null;
    return this._lastFragments.find(f => f.name === name) || null;
  },

  _showPreviewForRow(row) {
    if (row.dataset.toolcfg) { this._showToolcfgPreview(); return; }
    const name = row.dataset.fragName;
    if (!name) return;
    const frag = this._findFragByName(name);
    if (frag) this._showPreview(frag);
  },

  async _showToolcfgPreview() {
    if (!this._toolcfgPath) return;
    const panel = document.getElementById('fragments-preview-panel');
    const resizer = document.getElementById('fragments-resizer');
    const title = document.getElementById('fragments-preview-title');
    const body = document.getElementById('fragments-preview-body');
    const leftPanel = document.getElementById('fragments-left');
    if (!panel || !body) return;

    this._previewFrag = {name: 'toolcfg.conf', path: this._toolcfgPath, is_toolcfg: true};
    panel.style.display = '';
    if (resizer) resizer.style.display = '';
    if (leftPanel && !leftPanel.style.flex) {
      const saved = localStorage.getItem('bit-fragments-left-width');
      if (saved) leftPanel.style.flex = '0 0 ' + saved + 'px';
    }
    if (title) title.textContent = 'toolcfg.conf';

    body.innerHTML = '<div class="loading" style="padding:12px">Loading file</div>';
    try {
      const data = await API.readFile(this._toolcfgPath);
      const content = data.content || '';
      const lines = content.split('\n');
      const gutterHTML = lines.map((_, i) => (i + 1)).join('\n');
      const fileLabel = `<div style="padding:8px 12px 0;font-size:var(--font-size-xs);color:var(--text-muted)">${esc(this._toolcfgPath)}</div>`;

      body.innerHTML = fileLabel +
        '<div class="fragments-preview-content">' +
        '<pre class="fragments-preview-gutter">' + esc(gutterHTML) + '</pre>' +
        '<pre class="fragments-preview-code">' + esc(content) + '</pre>' +
        '</div>';
    } catch (e) {
      body.innerHTML = `<div style="color:var(--text-muted);padding:12px">toolcfg.conf not yet created (will be created when you enable a fragment)</div>`;
    }
  },

  async _showPreview(frag) {
    const panel = document.getElementById('fragments-preview-panel');
    const resizer = document.getElementById('fragments-resizer');
    const title = document.getElementById('fragments-preview-title');
    const body = document.getElementById('fragments-preview-body');
    const leftPanel = document.getElementById('fragments-left');
    if (!panel || !body) return;

    this._previewFrag = frag;

    // Show panel and resizer
    panel.style.display = '';
    if (resizer) resizer.style.display = '';

    // Apply saved width
    if (leftPanel && !leftPanel.style.flex) {
      const saved = localStorage.getItem('bit-fragments-left-width');
      if (saved) leftPanel.style.flex = '0 0 ' + saved + 'px';
    }

    const shortName = frag.name.split('/').pop();
    if (title) title.textContent = shortName;

    // Build metadata section
    const statusColor = frag.enabled ? 'var(--green)' : 'var(--text-muted)';
    const statusText = frag.enabled ? 'Enabled' : 'Disabled';

    let metaHTML = '<div class="fragments-preview-meta">';
    metaHTML += `<div class="fragments-detail-field"><span class="fragments-detail-label">Name</span><span class="fragments-detail-value" style="font-weight:600">${esc(frag.name)}</span></div>`;
    metaHTML += `<div class="fragments-detail-field"><span class="fragments-detail-label">Status</span><span class="fragments-detail-value" style="color:${statusColor}" id="fragment-preview-status">${esc(statusText)}</span></div>`;
    if (frag.layer) {
      metaHTML += `<div class="fragments-detail-field"><span class="fragments-detail-label">Layer</span><span class="fragments-detail-value" style="color:var(--cyan)">${esc(frag.layer)}</span></div>`;
    }
    if (frag.domain) {
      metaHTML += `<div class="fragments-detail-field"><span class="fragments-detail-label">Domain</span><span class="fragments-detail-value">${esc(frag.domain)}</span></div>`;
    }
    if (frag.path) {
      metaHTML += `<div class="fragments-detail-field"><span class="fragments-detail-label">Path</span><span class="fragments-detail-value" style="color:var(--text-muted);font-size:var(--font-size-xs)">${esc(frag.path)}</span></div>`;
    }
    if (frag.summary) {
      metaHTML += `<div class="fragments-detail-field"><span class="fragments-detail-label">Summary</span><span class="fragments-detail-value">${esc(frag.summary)}</span></div>`;
    }
    if (frag.description) {
      metaHTML += `<div class="fragments-detail-field"><span class="fragments-detail-label">Description</span><span class="fragments-detail-value" style="white-space:pre-wrap">${esc(frag.description)}</span></div>`;
    }
    if (frag.domain === 'builtin' && frag.builtin_prefix) {
      const val = frag.builtin_value || '(not set)';
      metaHTML += `<div class="fragments-detail-field"><span class="fragments-detail-label">Value</span><span class="fragments-detail-value" style="color:${frag.builtin_value ? 'var(--green)' : 'var(--text-muted)'}">${esc(val)}</span></div>`;
    }
    metaHTML += '</div>';

    // Load .conf file content for non-builtin fragments
    if (frag.path && !frag.is_builtin) {
      body.innerHTML = metaHTML + '<div class="loading" style="padding:12px">Loading file</div>';
      try {
        const data = await API.readFile(frag.path);
        const content = data.content || '';
        const lines = content.split('\n');
        const gutterHTML = lines.map((_, i) => (i + 1)).join('\n');

        body.innerHTML = metaHTML +
          '<div class="fragments-preview-content">' +
          '<pre class="fragments-preview-gutter">' + esc(gutterHTML) + '</pre>' +
          '<pre class="fragments-preview-code">' + esc(content) + '</pre>' +
          '</div>';
      } catch (e) {
        body.innerHTML = metaHTML +
          `<div style="color:var(--red);padding:12px">Error: ${esc(e.message)}</div>`;
      }
    } else {
      body.innerHTML = metaHTML;
    }
  },

  _updatePreviewBadge() {
    const el = document.getElementById('fragment-preview-status');
    if (!el || !this._previewFrag) return;
    el.textContent = this._previewFrag.enabled ? 'Enabled' : 'Disabled';
    el.style.color = this._previewFrag.enabled ? 'var(--green)' : 'var(--text-muted)';
  },

  _hidePreview() {
    const panel = document.getElementById('fragments-preview-panel');
    const resizer = document.getElementById('fragments-resizer');
    const leftPanel = document.getElementById('fragments-left');
    this._previewFrag = null;
    if (panel) panel.style.display = 'none';
    if (resizer) resizer.style.display = 'none';
    if (leftPanel) leftPanel.style.flex = '';
  },

  async _showContextMenu(e, row) {
    this._nav.activateElement(row);
    const isBuiltin = row.dataset.isBuiltin === '1';
    const items = isBuiltin
      ? [
          { label: 'Preview', icon: '\u2299', key: 'Enter', action: 'preview' },
          { label: 'Set value', icon: '\u2699', key: 'b', action: 'setvalue' },
          { sep: true },
          { label: 'Copy name', icon: '\u29c9', key: 'y', action: 'copy' },
        ]
      : [
          { label: 'Preview', icon: '\u2299', key: 'Enter', action: 'preview' },
          { label: 'Toggle enabled', icon: '\u2610', key: 'Space', action: 'toggle' },
          { label: 'View .conf', icon: '\u2630', key: 'v', action: 'viewconf' },
          { sep: true },
          { label: 'Copy name', icon: '\u29c9', key: 'y', action: 'copy' },
        ];
    const action = await contextMenu(e.clientX, e.clientY, items);
    if (!action) return;
    if (action === 'preview') this._showPreviewForRow(row);
    else if (action === 'viewconf') this._viewConfFile(row);
    else if (action === 'setvalue') this._setBuiltinValue(row);
    else if (action === 'copy') this._copyName(row);
    else if (action === 'toggle') {
      const cb = row.querySelector('input[data-frag]');
      if (cb) { cb.checked = !cb.checked; cb.dispatchEvent(new Event('change')); }
    }
  },

  _viewConfFile(row) {
    if (row.classList.contains('expandable')) return;
    const path = row.dataset.fragPath;
    if (path) fileEditor(path, {readOnly: true});
  },

  async _editToolcfg() {
    try {
      const data = await API.getToolcfgPath();
      if (data.path) {
        await fileEditor(data.path, {readOnly: false});
        // Refresh fragments after editing toolcfg
        const fragments = await API.getFragments();
        this._lastFragments = fragments;
        this._renderFragments(fragments);
      }
    } catch (e) {
      App.showToast('Error: ' + e.message, 'error');
    }
  },

  async _setBuiltinValue(row) {
    if (row.dataset.isBuiltin !== '1') return;
    const prefix = row.dataset.builtinPrefix;
    if (!prefix) return;
    const value = await promptModal(`Set ${prefix} value`, '');
    if (!value) return;
    try {
      await API.setBuiltinValue(prefix, value);
      App.showToast(`${prefix} set to: ${value}`, 'success');
      const fragments = await API.getFragments();
      this._lastFragments = fragments;
      this._renderFragments(fragments);
    } catch (e) {
      App.showToast('Error: ' + e.message, 'error');
    }
  },

  _copyName(row) {
    const name = row.dataset.fragName;
    if (!name) return;
    navigator.clipboard.writeText(name).then(() => {
      App.showToast('Name copied', 'success');
    }).catch(() => {
      App.showToast('Copy failed', 'error');
    });
  },

  _toggleDomain(domain) {
    this._expandedDomains[domain] = this._expandedDomains[domain] === false;
    if (this._lastFragments) this._renderFragments(this._lastFragments);
  },

  _toggleAll() {
    this._allExpanded = !this._allExpanded;
    this._expandedDomains = {};
    if (!this._allExpanded) {
      // Collapse all — mark all current groups as collapsed
      if (this._lastFragments) {
        const filtered = this._filterFragments(this._lastFragments);
        const builtins = filtered.filter(f => f.domain === 'builtin');
        if (builtins.length) this._expandedDomains['builtin'] = false;
        const regular = filtered.filter(f => f.domain !== 'builtin');
        for (const f of regular) {
          const group = f.layer ? `${f.layer}/${f.domain}` : (f.domain || 'other');
          this._expandedDomains[group] = false;
        }
      }
    }
    if (this._lastFragments) this._renderFragments(this._lastFragments);
  },
};
