/* Messages panel — bottom pane (same position as terminal) */
const MessagesPanel = (() => {
  const panel = () => document.getElementById('messages-panel');
  const body = () => document.getElementById('messages-panel-body');

  function _syncContentHeight() {
    const p = panel();
    if (p && p.style.display !== 'none') {
      document.documentElement.style.setProperty(
        '--messages-actual-height', p.offsetHeight + 'px');
    } else {
      document.documentElement.style.removeProperty('--messages-actual-height');
    }
  }

  async function _load() {
    const el = body();
    if (!el) return;
    el.innerHTML = '<div class="messages-panel-empty">Loading...</div>';
    try {
      const project = App.state.selectedProject || undefined;
      const data = await API.getMessages(project);
      const messages = data.messages || [];
      _render(messages);
    } catch (e) {
      el.innerHTML = `<div class="messages-panel-empty">Error: ${e.message}</div>`;
    }
  }

  function _render(messages) {
    const el = body();
    if (!el) return;
    if (!messages || !messages.length) {
      el.innerHTML = '<div class="messages-panel-empty">No messages yet</div>';
      return;
    }
    el.innerHTML = `<table><tbody>${messages.map(m => {
      const d = new Date(m.ts * 1000);
      const time = d.toLocaleTimeString();
      const type = m.type || 'info';
      let icon, color;
      if (type === 'success') { icon = '\u2713'; color = 'var(--green)'; }
      else if (type === 'error') { icon = '\u2717'; color = 'var(--red)'; }
      else if (type === 'warn') { icon = '!'; color = 'var(--yellow)'; }
      else { icon = '\u00b7'; color = 'var(--text-muted)'; }
      return `<tr data-text="${esc((m.text || '').toLowerCase())}">
        <td style="color:var(--text-muted);white-space:nowrap;width:80px">${esc(time)}</td>
        <td style="color:${color};width:2ch;text-align:center">${icon}</td>
        <td>${esc(m.text || '')}</td>
      </tr>`;
    }).join('')}</tbody></table>`;
  }

  function _filter() {
    const input = document.getElementById('messages-panel-filter');
    const filter = (input ? input.value : '').toLowerCase();
    const el = body();
    if (!el) return;
    el.querySelectorAll('tr').forEach(tr => {
      tr.style.display = !filter || (tr.dataset.text || '').includes(filter) ? '' : 'none';
    });
  }

  function show() {
    const p = panel();
    if (!p) return;
    // Close terminal if open (mutual exclusion)
    if (window.TerminalManager) TerminalManager.hide();
    p.style.display = 'flex';
    document.body.classList.add('messages-open');
    requestAnimationFrame(() => _syncContentHeight());
    _load();
    const input = document.getElementById('messages-panel-filter');
    if (input) { input.value = ''; input.focus(); }
  }

  function hide() {
    const p = panel();
    if (p) p.style.display = 'none';
    document.body.classList.remove('messages-open');
    _syncContentHeight();
  }

  function toggle() {
    const p = panel();
    if (!p) return;
    if (p.style.display === 'none' || !p.style.display) {
      show();
    } else {
      hide();
    }
  }

  function init() {
    const closeBtn = document.getElementById('messages-panel-close');
    if (closeBtn) closeBtn.addEventListener('click', hide);
    const filterInput = document.getElementById('messages-panel-filter');
    if (filterInput) filterInput.addEventListener('input', _filter);
  }

  window.MessagesPanel = { show, hide, toggle, init };
  return { show, hide, toggle, init };
})();
