/* bit web dashboard — shared utilities (IIFE module pattern) */
(function() {
  'use strict';

  /**
   * HTML-escape a string to prevent XSS.
   * Replaces the per-view _esc() methods.
   */
  function esc(s) {
    if (!s) return '';
    var d = document.createElement('div');
    d.textContent = s;
    return d.innerHTML;
  }

  /**
   * Show a modal dialog. Returns a Promise that resolves with the button value clicked.
   * @param {string} title - Modal title
   * @param {string} bodyHTML - HTML content for the modal body
   * @param {Array<{label:string, value:*, primary?:boolean, danger?:boolean}>} buttons
   * @returns {Promise<*>} resolves with the clicked button's value, or null if dismissed
   */
  function modal(title, bodyHTML, buttons) {
    return new Promise(function(resolve) {
      var overlay = document.createElement('div');
      overlay.className = 'modal-overlay';

      var dialog = document.createElement('div');
      dialog.className = 'modal';

      var header = document.createElement('div');
      header.className = 'modal-header';
      header.innerHTML = '<span>' + esc(title) + '</span><button class="modal-close btn-icon">&times;</button>';

      var body = document.createElement('div');
      body.className = 'modal-body';
      body.innerHTML = bodyHTML;

      var footer = document.createElement('div');
      footer.className = 'modal-footer';

      function dismiss(value) {
        overlay.remove();
        resolve(value);
      }

      // Close button
      header.querySelector('.modal-close').addEventListener('click', function() { dismiss(null); });

      // Overlay click dismisses
      overlay.addEventListener('click', function(e) {
        if (e.target === overlay) dismiss(null);
      });

      // Escape key dismisses
      function onKey(e) {
        if (e.key === 'Escape') {
          document.removeEventListener('keydown', onKey);
          dismiss(null);
        }
      }
      document.addEventListener('keydown', onKey);

      // Build buttons
      buttons.forEach(function(btn) {
        var el = document.createElement('button');
        el.className = 'btn' + (btn.primary ? ' btn-primary' : '') + (btn.danger ? ' btn-danger' : '');
        el.textContent = btn.label;
        el.addEventListener('click', function() {
          document.removeEventListener('keydown', onKey);
          dismiss(btn.value);
        });
        footer.appendChild(el);
      });

      dialog.appendChild(header);
      dialog.appendChild(body);
      dialog.appendChild(footer);
      overlay.appendChild(dialog);
      document.body.appendChild(overlay);

      // Focus first button
      var firstBtn = footer.querySelector('.btn');
      if (firstBtn) firstBtn.focus();
    });
  }

  /**
   * Styled replacement for window.confirm().
   * @param {string} message
   * @returns {Promise<boolean>}
   */
  function confirmModal(message) {
    return modal('Confirm', '<p>' + esc(message) + '</p>', [
      { label: 'Cancel', value: false },
      { label: 'OK', value: true, primary: true },
    ]);
  }

  /**
   * Styled replacement for window.prompt().
   * @param {string} label
   * @param {string} [defaultValue='']
   * @returns {Promise<string|null>} the entered text, or null if cancelled
   */
  function promptModal(label, defaultValue) {
    var inputId = 'modal-prompt-' + Date.now();
    var bodyHTML = '<label for="' + inputId + '" style="display:block;margin-bottom:8px">' + esc(label) + '</label>' +
      '<input type="text" id="' + inputId + '" class="form-input" value="' + esc(defaultValue || '') + '">';

    return modal('Input', bodyHTML, [
      { label: 'Cancel', value: '__cancel__' },
      { label: 'OK', value: '__ok__', primary: true },
    ]).then(function(btnValue) {
      if (btnValue === '__ok__') {
        var input = document.getElementById(inputId);
        return input ? input.value : defaultValue || '';
      }
      return null;
    });
  }

  /**
   * Colorize unified diff output using existing CSS classes.
   * @param {string} diffText - Raw diff text
   * @returns {string} HTML with .diff-add/.diff-del/.diff-hunk/.diff-meta spans
   */
  function formatDiff(diffText) {
    if (!diffText) return '<span style="color:var(--text-muted)">No diff</span>';
    return diffText.split('\n').map(function(line) {
      var escaped = esc(line);
      if (line.startsWith('+++') || line.startsWith('---')) {
        return '<span class="diff-meta">' + escaped + '</span>';
      } else if (line.startsWith('+')) {
        return '<span class="diff-add">' + escaped + '</span>';
      } else if (line.startsWith('-')) {
        return '<span class="diff-del">' + escaped + '</span>';
      } else if (line.startsWith('@@')) {
        return '<span class="diff-hunk">' + escaped + '</span>';
      } else if (line.startsWith('diff ') || line.startsWith('index ')) {
        return '<span class="diff-meta">' + escaped + '</span>';
      }
      return escaped;
    }).join('\n');
  }

  /**
   * Debounce a function.
   * @param {Function} fn
   * @param {number} ms - Delay in milliseconds
   * @returns {Function}
   */
  function debounce(fn, ms) {
    var timer;
    return function() {
      var args = arguments;
      var ctx = this;
      clearTimeout(timer);
      timer = setTimeout(function() { fn.apply(ctx, args); }, ms);
    };
  }

  /**
   * Format a date string as a human-friendly relative time.
   * @param {string} dateStr - ISO date string or similar
   * @returns {string}
   */
  function relativeTime(dateStr) {
    if (!dateStr) return '';
    try {
      var d = new Date(dateStr);
      var now = Date.now();
      var diff = now - d.getTime();
      if (diff < 0) return 'just now';
      var secs = Math.floor(diff / 1000);
      if (secs < 60) return secs + 's ago';
      var mins = Math.floor(secs / 60);
      if (mins < 60) return mins + 'm ago';
      var hours = Math.floor(mins / 60);
      if (hours < 24) return hours + 'h ago';
      var days = Math.floor(hours / 24);
      if (days < 30) return days + 'd ago';
      var months = Math.floor(days / 30);
      if (months < 12) return months + 'mo ago';
      return Math.floor(months / 12) + 'y ago';
    } catch (e) {
      return dateStr;
    }
  }

  /**
   * Save a user preference to localStorage (with try-catch).
   * Pattern from zeddweb block-visibility.js.
   * @param {string} key
   * @param {*} value
   */
  function savePreference(key, value) {
    try {
      localStorage.setItem('bit-' + key, JSON.stringify(value));
    } catch (e) {
      // localStorage unavailable or full
    }
  }

  /**
   * Load a user preference from localStorage (with try-catch).
   * @param {string} key
   * @param {*} fallback
   * @returns {*}
   */
  function loadPreference(key, fallback) {
    try {
      var stored = localStorage.getItem('bit-' + key);
      if (stored !== null) return JSON.parse(stored);
    } catch (e) {
      // parse error or localStorage unavailable
    }
    return fallback;
  }

  /**
   * Render a unified diff into an element using diff2html if available,
   * falling back to formatDiff().
   * @param {HTMLElement} el - Container element
   * @param {string} diffText - Raw unified diff text
   * @param {boolean} [sideBySide=false] - Use side-by-side mode
   */
  function renderDiff(el, diffText, sideBySide) {
    // Store for re-render on mode toggle
    el._lastDiffText = diffText;

    if (window.Diff2HtmlUI) {
      el.innerHTML = '';
      var config = {
        drawFileList: false,
        matching: 'lines',
        outputFormat: sideBySide ? 'side-by-side' : 'line-by-line',
        highlight: true,
        colorScheme: document.documentElement.dataset.theme === 'light' ? 'auto' : 'dark',
      };
      var ui = new Diff2HtmlUI(el, diffText, config);
      ui.draw();
      if (typeof ui.highlightCode === 'function') {
        ui.highlightCode();
      }
    } else {
      el.innerHTML = '<pre class="diff-panel">' + formatDiff(diffText) + '</pre>';
    }
  }

  /**
   * Keyboard navigation factory for list/table views.
   * Replaces duplicated _moveActive/_moveToIndex code.
   * @param {Object} [opts]
   * @param {string} [opts.activeClass='keyboard-active']
   * @param {boolean} [opts.wrap=true]
   * @param {boolean} [opts.skipHidden=false]
   * @returns {Object} nav helper with setRows, moveActive, moveToIndex, handleBasicKeys, activeRow, activeIndex
   */
  function KeyboardNav(opts) {
    opts = opts || {};
    var activeClass = opts.activeClass || 'keyboard-active';
    var wrap = opts.wrap !== false;
    var skipHidden = opts.skipHidden || false;
    var rows = [];
    var idx = -1;

    function _deactivate() {
      if (idx >= 0 && rows[idx]) {
        rows[idx].classList.remove(activeClass);
        rows[idx].setAttribute('tabindex', '-1');
        rows[idx].removeAttribute('aria-selected');
      }
    }

    function _activate(i) {
      idx = i;
      var row = rows[idx];
      if (row) {
        row.classList.add(activeClass);
        row.setAttribute('tabindex', '0');
        row.setAttribute('aria-selected', 'true');
        row.focus();
        row.scrollIntoView({ block: 'nearest' });
      }
    }

    function setRows(r) {
      rows = r ? Array.from(r) : [];
      idx = -1;
    }

    function moveToIndex(i) {
      if (i < 0 || i >= rows.length) return;
      _deactivate();
      _activate(i);
    }

    function moveActive(delta) {
      _deactivate();
      var next = idx + delta;
      if (skipHidden) {
        for (var attempts = 0; attempts < rows.length; attempts++) {
          if (wrap) {
            if (next < 0) next = rows.length - 1;
            if (next >= rows.length) next = 0;
          } else {
            if (next < 0) { next = 0; break; }
            if (next >= rows.length) { next = rows.length - 1; break; }
          }
          if (rows[next].style.display !== 'none') break;
          next += delta > 0 ? 1 : -1;
        }
      } else {
        if (wrap) {
          if (next < 0) next = rows.length - 1;
          if (next >= rows.length) next = 0;
        } else {
          if (next < 0) next = 0;
          if (next >= rows.length) next = rows.length - 1;
        }
      }
      _activate(next);
    }

    function handleBasicKeys(e) {
      if (!rows.length) return false;
      if (e.key === 'j' || e.key === 'ArrowDown') {
        e.preventDefault();
        moveActive(1);
        return true;
      }
      if (e.key === 'k' || e.key === 'ArrowUp') {
        e.preventDefault();
        moveActive(-1);
        return true;
      }
      if (e.key === 'Home') {
        e.preventDefault();
        moveToIndex(0);
        return true;
      }
      if (e.key === 'End') {
        e.preventDefault();
        moveToIndex(rows.length - 1);
        return true;
      }
      return false;
    }

    function activateElement(el) {
      var i = rows.indexOf(el);
      if (i < 0) return false;
      _deactivate();
      _activate(i);
      return true;
    }

    function activeRow() {
      return idx >= 0 && rows[idx] ? rows[idx] : null;
    }

    function activeIndex() {
      return idx;
    }

    return {
      setRows: setRows,
      moveActive: moveActive,
      moveToIndex: moveToIndex,
      activateElement: activateElement,
      handleBasicKeys: handleBasicKeys,
      activeRow: activeRow,
      activeIndex: activeIndex,
    };
  }

  /**
   * Open a file editor modal.
   * @param {string} path - File path to edit
   * @param {Object} [opts]
   * @param {boolean} [opts.readOnly=false]
   * @returns {Promise<void>}
   */
  function fileEditor(path, opts) {
    opts = opts || {};
    var readOnly = opts.readOnly || false;

    return API.readFile(path).then(function(data) {
      // Temporarily widen the modal for file editing
      var styleTag = document.createElement('style');
      styleTag.textContent = '.modal-overlay .modal { max-width: 80vw; width: 80vw; }';
      document.head.appendChild(styleTag);
      var content = data.content || '';
      var lines = content.split('\n');
      var gutterHTML = lines.map(function(_, i) { return (i + 1); }).join('\n');

      var bodyHTML = '<div style="display:flex;gap:0;border:1px solid var(--border);border-radius:4px;overflow:hidden;max-height:60vh">' +
        '<pre style="padding:8px 6px;background:var(--bg-tertiary);color:var(--text-muted);text-align:right;user-select:none;font-size:var(--font-size-sm);line-height:1.6;margin:0;overflow:hidden" id="file-editor-gutter">' + esc(gutterHTML) + '</pre>' +
        (readOnly
          ? '<pre style="flex:1;padding:8px 12px;margin:0;overflow:auto;font-size:var(--font-size-sm);line-height:1.6;white-space:pre;background:var(--bg-primary);color:var(--text-primary)">' + esc(content) + '</pre>'
          : '<textarea id="file-editor-textarea" style="flex:1;padding:8px 12px;border:none;resize:none;font-family:var(--font-mono);font-size:var(--font-size-sm);line-height:1.6;background:var(--bg-primary);color:var(--text-primary);outline:none;white-space:pre;tab-size:4">' + esc(content) + '</textarea>'
        ) +
        '</div>';

      var fileName = path.split('/').pop();
      var buttons = readOnly
        ? [{ label: 'Close', value: 'close' }]
        : [{ label: 'Close', value: 'close' }, { label: 'Save', value: 'save', primary: true }];

      var modalPromise = modal(fileName, bodyHTML, buttons);

      // Capture textarea content before modal dismiss destroys the DOM
      var saveContent = content;
      if (!readOnly) {
        var textarea = document.getElementById('file-editor-textarea');
        if (textarea) {
          textarea.addEventListener('input', function() { saveContent = textarea.value; });
        }
      }

      return modalPromise.then(function(action) {
        styleTag.remove();
        if (action === 'save' && !readOnly) {
          return API.writeFile(path, saveContent).then(function() {
            App.showToast('File saved', 'success');
          }).catch(function(e) {
            App.showToast('Save error: ' + e.message, 'error');
          });
        }
      });
    }).catch(function(e) {
      App.showToast('Error reading file: ' + e.message, 'error');
    });
  }

  /**
   * Show a context menu at (x, y).  Returns a Promise that resolves with the
   * chosen item's `action` string, or null if dismissed.
   *
   * @param {number} x - clientX
   * @param {number} y - clientY
   * @param {Array<{label:string, icon?:string, key?:string, action:string, danger?:boolean}|{sep:true}>} items
   * @returns {Promise<string|null>}
   */
  function contextMenu(x, y, items) {
    return new Promise(function(resolve) {
      // Remove any existing context menu
      var prev = document.querySelector('.context-menu');
      if (prev) prev.remove();

      var menu = document.createElement('div');
      menu.className = 'context-menu';

      items.forEach(function(item) {
        if (item.sep) {
          var sep = document.createElement('div');
          sep.className = 'ctx-sep';
          menu.appendChild(sep);
          return;
        }
        var row = document.createElement('div');
        row.className = 'ctx-item' + (item.danger ? ' ctx-danger' : '');
        row.dataset.action = item.action;

        var left = document.createElement('span');
        left.className = 'ctx-label';
        left.textContent = (item.icon ? item.icon + ' ' : '') + item.label;

        row.appendChild(left);

        if (item.key) {
          var hint = document.createElement('span');
          hint.className = 'ctx-key';
          hint.textContent = item.key;
          row.appendChild(hint);
        }

        row.addEventListener('click', function(e) {
          e.stopPropagation();
          dismiss(item.action);
        });

        menu.appendChild(row);
      });

      document.body.appendChild(menu);

      // Position: flip if near viewport edge
      var rect = menu.getBoundingClientRect();
      var left = x;
      var top = y;
      if (left + rect.width > window.innerWidth) left = x - rect.width;
      if (top + rect.height > window.innerHeight) top = y - rect.height;
      if (left < 0) left = 0;
      if (top < 0) top = 0;
      menu.style.left = left + 'px';
      menu.style.top = top + 'px';

      function dismiss(value) {
        menu.remove();
        document.removeEventListener('keydown', onKey, true);
        document.removeEventListener('click', onClickOutside, true);
        window.removeEventListener('scroll', onDismiss, true);
        window.removeEventListener('resize', onDismiss);
        resolve(value != null ? value : null);
      }

      function onKey(e) {
        if (e.key === 'Escape') {
          e.preventDefault();
          e.stopPropagation();
          dismiss(null);
        }
      }

      function onClickOutside(e) {
        if (!menu.contains(e.target)) {
          dismiss(null);
        }
      }

      function onDismiss() {
        dismiss(null);
      }

      // Delay listener registration so the opening right-click doesn't
      // immediately dismiss (click event fires after contextmenu).
      requestAnimationFrame(function() {
        document.addEventListener('keydown', onKey, true);
        document.addEventListener('click', onClickOutside, true);
        window.addEventListener('scroll', onDismiss, true);
        window.addEventListener('resize', onDismiss);
      });
    });
  }

  /**
   * Directory browser modal.
   * @param {string} startPath - Initial directory to show
   * @param {Object} [opts]
   * @param {string} [opts.host] - SSH host (user@host) for remote browsing
   * @param {string} [opts.title='Select Directory']
   * @param {boolean} [opts.allowNew=false] - Show "New folder" input
   * @returns {Promise<string|null>} selected path, or null if cancelled
   */
  function pathBrowser(startPath, opts) {
    opts = opts || {};
    var title = opts.title || 'Select Directory';
    var host = opts.host || '';
    var allowNew = opts.allowNew || false;

    return new Promise(function(resolve) {
      var overlay = document.createElement('div');
      overlay.className = 'modal-overlay';

      var dialog = document.createElement('div');
      dialog.className = 'modal';
      dialog.style.maxWidth = '560px';
      dialog.style.width = '560px';

      // Header
      var header = document.createElement('div');
      header.className = 'modal-header';
      header.innerHTML = '<span>' + esc(title) + '</span><button class="modal-close btn-icon">&times;</button>';

      // Path bar
      var pathBar = document.createElement('div');
      pathBar.style.cssText = 'display:flex;gap:6px;padding:8px 16px;border-bottom:1px solid var(--border)';
      pathBar.innerHTML = '<input type="text" class="form-input" style="flex:1" value="' + esc(startPath || '~') + '">' +
        '<button class="btn btn-sm">Go</button>';
      var pathInput = pathBar.querySelector('input');
      var goBtn = pathBar.querySelector('button');

      // Listing area
      var listing = document.createElement('div');
      listing.style.cssText = 'max-height:300px;overflow-y:auto;padding:0';

      // New folder row
      var newRow = null;
      if (allowNew) {
        newRow = document.createElement('div');
        newRow.style.cssText = 'padding:8px 16px;border-top:1px solid var(--border);display:flex;gap:6px;align-items:center';
        newRow.innerHTML = '<span style="color:var(--text-muted);font-size:var(--font-size-sm);white-space:nowrap">New folder:</span>' +
          '<input type="text" class="form-input" style="flex:1" placeholder="folder name">';
      }

      // Footer
      var footer = document.createElement('div');
      footer.className = 'modal-footer';
      footer.innerHTML = '<button class="btn pb-cancel">Cancel</button><button class="btn btn-primary pb-select">Select</button>';

      var currentPath = startPath || '~';

      function dismiss(value) {
        overlay.remove();
        resolve(value);
      }

      function renderEntries(data) {
        currentPath = data.path;
        pathInput.value = data.path;
        var html = '';
        // Parent directory
        if (data.parent && data.parent !== data.path) {
          html += '<div class="dash-action-item pb-entry" data-path="' + esc(data.parent) + '" style="padding:6px 16px;cursor:pointer;border-bottom:1px solid var(--border)">' +
            '<span style="margin-right:6px">&#x1f4c1;</span> ..</div>';
        }
        if (!data.entries || !data.entries.length) {
          html += '<div style="padding:12px 16px;color:var(--text-muted)">Empty directory</div>';
        } else {
          for (var i = 0; i < data.entries.length; i++) {
            var e = data.entries[i];
            html += '<div class="dash-action-item pb-entry" data-path="' + esc(data.path + '/' + e.name) + '" style="padding:6px 16px;cursor:pointer;border-bottom:1px solid var(--border)">' +
              '<span style="margin-right:6px">&#x1f4c1;</span> ' + esc(e.name) + '</div>';
          }
        }
        listing.innerHTML = html;
        listing.querySelectorAll('.pb-entry').forEach(function(el) {
          el.addEventListener('click', function() {
            navigate(el.dataset.path);
          });
        });
      }

      function navigate(path) {
        listing.innerHTML = '<div style="padding:12px 16px;color:var(--text-muted)">Loading...</div>';
        API.listDirectory(path, host).then(function(data) {
          renderEntries(data);
        }).catch(function(err) {
          if (allowNew) {
            currentPath = path;
            pathInput.value = path;
            listing.innerHTML = '<div style="padding:12px 16px;color:var(--text-muted)">New directory — will be created</div>';
          } else {
            listing.innerHTML = '<div style="padding:12px 16px;color:var(--red)">' + esc(err.message) + '</div>';
          }
        });
      }

      // Wire events
      header.querySelector('.modal-close').addEventListener('click', function() { dismiss(null); });
      overlay.addEventListener('click', function(e) { if (e.target === overlay) dismiss(null); });
      footer.querySelector('.pb-cancel').addEventListener('click', function() { dismiss(null); });
      footer.querySelector('.pb-select').addEventListener('click', function() {
        // Use the path bar value (what user typed/sees), not just last successful ls
        var result = pathInput.value.trim() || currentPath;
        if (allowNew && newRow) {
          var newName = newRow.querySelector('input').value.trim();
          if (newName) {
            result = result + '/' + newName;
          }
        }
        dismiss(result);
      });
      goBtn.addEventListener('click', function() { navigate(pathInput.value.trim()); });
      pathInput.addEventListener('keydown', function(e) {
        if (e.key === 'Enter') { e.preventDefault(); navigate(pathInput.value.trim()); }
      });

      function onKey(e) {
        if (e.key === 'Escape') { document.removeEventListener('keydown', onKey); dismiss(null); }
      }
      document.addEventListener('keydown', onKey);

      // Assemble
      dialog.appendChild(header);
      dialog.appendChild(pathBar);
      dialog.appendChild(listing);
      if (newRow) dialog.appendChild(newRow);
      dialog.appendChild(footer);
      overlay.appendChild(dialog);
      document.body.appendChild(overlay);

      // Initial load
      navigate(startPath || '~');
    });
  }

  /**
   * Show a command menu modal (command picker).
   * @param {boolean} isYocto - Whether to show Yocto-specific commands
   * @returns {Promise<string|null>} resolves with view name or null if dismissed
   */
  function commandMenu(isYocto) {
    var commands = [
      { section: 'Git' },
      { name: 'explore',      icon: '\ud83d\udd0d', desc: 'Browse commits and repos',       view: 'explore' },
      { name: 'branch',       icon: '\u2442',       desc: 'View and switch branches',       view: 'branch' },
      { name: 'update',       icon: '\u2191',       desc: 'Update git repos',               view: 'update' },
      { name: 'export',       icon: '\ud83d\udce6', desc: 'Export patches from repos',       view: 'export' },
      { name: 'pull request', icon: '\u2699',       desc: 'Prepare commits for upstream',    view: 'export' },
      { section: 'Patches' },
      { name: 'patches',      icon: '\ud83e\ude84', desc: 'Explore patches across layers',   view: 'patches' },
      { name: 'b4 / lore',    icon: '\u2709',       desc: 'Mail-based patch management',     view: 'b4' },
      { section: 'Project' },
      { name: 'settings',     icon: '\u2699',       desc: 'View and configure settings',     view: 'config' },
      { name: 'configs',      icon: '\ud83d\udce5', desc: 'Browse and export configurations', view: 'configs' },
      { name: 'terminal',     icon: '>_',           desc: 'Open terminal',                   view: 'terminal' },
    ];
    if (isYocto) {
      commands.push(
        { section: 'Yocto' },
        { name: 'recipes',     icon: '\ud83d\udcd6', desc: 'Search and browse recipes',      view: 'recipes' },
        { name: 'fragments',   icon: '\ud83e\udde9', desc: 'Browse OE config fragments',     view: 'fragments' },
        { name: 'deps',        icon: '\ud83d\udd17', desc: 'Layer and recipe dependencies',   view: 'deps' },
        { name: 'info',        icon: '\u2139',       desc: 'Build configuration and layers',  view: 'info' },
        { name: 'layer-index', icon: '\ud83c\udf10', desc: 'Browse OE Layer Index',           view: 'layer-index' }
      );
    }

    return new Promise(function(resolve) {
      var overlay = document.createElement('div');
      overlay.className = 'modal-overlay';

      var menu = document.createElement('div');
      menu.className = 'command-menu';

      var header = document.createElement('div');
      header.className = 'modal-header';
      header.innerHTML = '<span>Commands</span><button class="modal-close btn-icon">&times;</button>';

      var body = document.createElement('div');
      body.className = 'command-menu-body';

      var selectableItems = [];

      commands.forEach(function(cmd) {
        if (cmd.section) {
          var title = document.createElement('div');
          title.className = 'cmd-section-title';
          title.textContent = cmd.section;
          body.appendChild(title);
          return;
        }
        var item = document.createElement('div');
        item.className = 'cmd-item';
        item.dataset.view = cmd.view;
        item.innerHTML = '<span class="cmd-icon">' + esc(cmd.icon) + '</span>' +
          '<span class="cmd-name">' + esc(cmd.name) + '</span>' +
          '<span class="cmd-desc">' + esc(cmd.desc) + '</span>';
        item.addEventListener('click', function() { dismiss(cmd.view); });
        body.appendChild(item);
        selectableItems.push(item);
      });

      menu.appendChild(header);
      menu.appendChild(body);
      overlay.appendChild(menu);
      document.body.appendChild(overlay);

      // Highlight first item
      var activeIdx = 0;
      if (selectableItems.length) selectableItems[0].classList.add('cmd-active');

      function dismiss(value) {
        overlay.remove();
        document.removeEventListener('keydown', onKey, true);
        resolve(value != null ? value : null);
      }

      function moveHighlight(delta) {
        if (!selectableItems.length) return;
        selectableItems[activeIdx].classList.remove('cmd-active');
        activeIdx += delta;
        if (activeIdx < 0) activeIdx = selectableItems.length - 1;
        if (activeIdx >= selectableItems.length) activeIdx = 0;
        selectableItems[activeIdx].classList.add('cmd-active');
        selectableItems[activeIdx].scrollIntoView({ block: 'nearest' });
      }

      function onKey(e) {
        if (e.key === 'Escape') {
          e.preventDefault();
          e.stopPropagation();
          dismiss(null);
        } else if (e.key === 'j' || e.key === 'ArrowDown') {
          e.preventDefault();
          e.stopPropagation();
          moveHighlight(1);
        } else if (e.key === 'k' || e.key === 'ArrowUp') {
          e.preventDefault();
          e.stopPropagation();
          moveHighlight(-1);
        } else if (e.key === 'Enter') {
          e.preventDefault();
          e.stopPropagation();
          if (selectableItems.length) dismiss(selectableItems[activeIdx].dataset.view);
        }
      }

      header.querySelector('.modal-close').addEventListener('click', function() { dismiss(null); });
      overlay.addEventListener('click', function(e) { if (e.target === overlay) dismiss(null); });
      document.addEventListener('keydown', onKey, true);
    });
  }

  // Expose as globals
  window.esc = esc;
  window.modal = modal;
  window.confirmModal = confirmModal;
  window.promptModal = promptModal;
  window.contextMenu = contextMenu;
  window.formatDiff = formatDiff;
  window.debounce = debounce;
  window.relativeTime = relativeTime;
  window.savePreference = savePreference;
  window.loadPreference = loadPreference;
  window.renderDiff = renderDiff;
  window.KeyboardNav = KeyboardNav;
  window.fileEditor = fileEditor;
  window.pathBrowser = pathBrowser;
  window.commandMenu = commandMenu;

})();
