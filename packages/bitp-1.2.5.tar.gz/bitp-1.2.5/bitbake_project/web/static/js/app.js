/* bit web dashboard — app bootstrap, router, SSE client, state */
const App = (() => {
  const state = {
    currentView: null,
    currentProject: null,
    repos: [],
    projects: [],
  };

  const views = {
    dashboard: DashboardView,
    explore: ExploreView,
    commits: CommitsView,
    branch: BranchView,
    update: UpdateView,
    config: ConfigView,
    patches: PatchesView,
    b4: B4View,
    recipes: RecipesView,
    fragments: FragmentsView,
    deps: DepsView,
    info: InfoView,
    export: ExportView,
    configs: SetupView,
    'layer-index': LayerIndexView,
    terminal: TerminalView,
    hosts: HostsView,
    https: HttpsView,
  };

  let sseSource = null;
  let sseReconnectTimer = null;
  let _sseNavTimer = null;

  /** Debounced navigate for SSE events — coalesces rapid events into one re-render. */
  function sseNavigate(viewName) {
    if (_sseNavTimer) clearTimeout(_sseNavTimer);
    _sseNavTimer = setTimeout(() => {
      _sseNavTimer = null;
      navigate(viewName, true);
    }, 300);
  }

  // Host metrics auto-refresh timer
  let _metricsTimer = null;
  let _metricsIntervalMs = 0;

  // Message bar state
  const _messages = [];
  let _messageTimer = null;
  let _messageExpanded = false;

  function showMessage(text, type) {
    type = type || 'info';
    _messages.push({ time: new Date(), text, type });
    const bar = document.getElementById('message-bar');
    const textEl = document.getElementById('message-bar-text');
    const countEl = document.getElementById('message-bar-count');
    if (!bar || !textEl) return;
    textEl.textContent = text;
    textEl.className = 'message-' + type;
    countEl.textContent = _messages.length > 1 ? _messages.length : '';
    bar.style.display = '';
    // Auto-hide after 5s if not expanded
    if (_messageTimer) clearTimeout(_messageTimer);
    _messageTimer = setTimeout(() => {
      if (!_messageExpanded) _dismissMessageBar();
    }, 5000);
  }

  function _toggleMessageHistory() {
    const history = document.getElementById('message-bar-history');
    const toggle = document.getElementById('message-bar-toggle');
    if (!history) return;
    _messageExpanded = !_messageExpanded;
    history.style.display = _messageExpanded ? '' : 'none';
    if (toggle) toggle.textContent = _messageExpanded ? '\u25b4' : '\u25be';
    if (_messageExpanded) {
      // Render newest first
      history.innerHTML = _messages.slice().reverse().map(m => {
        const t = m.time.toLocaleTimeString();
        return `<div><span class="msg-time">${t}</span><span class="message-${m.type}">${esc(m.text)}</span></div>`;
      }).join('');
      // Cancel auto-hide while expanded
      if (_messageTimer) { clearTimeout(_messageTimer); _messageTimer = null; }
    }
  }

  function _dismissMessageBar() {
    const bar = document.getElementById('message-bar');
    const history = document.getElementById('message-bar-history');
    const toggle = document.getElementById('message-bar-toggle');
    if (bar) bar.style.display = 'none';
    if (history) history.style.display = 'none';
    if (toggle) toggle.textContent = '\u25be';
    _messageExpanded = false;
    if (_messageTimer) { clearTimeout(_messageTimer); _messageTimer = null; }
  }

  function getViewFromHash() {
    const hash = location.hash.slice(1) || 'dashboard';
    return hash;
  }

  function navigate(viewName, force) {
    if (state.currentView === viewName && !force) return;
    // Cancel any pending SSE-debounced re-render — this navigate supersedes it
    if (_sseNavTimer) { clearTimeout(_sseNavTimer); _sseNavTimer = null; }
    // Abort in-flight API requests from the previous view so they release
    // HTTP connection slots immediately (HTTP/1.1 browsers limit to 6).
    if (window._navAbortController) window._navAbortController.abort();
    window._navAbortController = new AbortController();
    window._navAbortSignal = window._navAbortController.signal;
    state.currentView = viewName;

    // Update nav
    document.querySelectorAll('.nav-item').forEach(el => {
      el.classList.toggle('active', el.dataset.view === viewName);
    });

    // Hide view-specific fixed elements
    const dashReset = document.getElementById('dash-reset-order');
    if (dashReset) dashReset.style.display = 'none';
    const viewReset = document.getElementById('view-reset-order');
    if (viewReset) viewReset.style.display = 'none';

    // Show/hide dashboard sidebar actions
    document.querySelectorAll('.dash-sidebar-action').forEach(el => {
      el.style.display = viewName === 'dashboard' ? '' : 'none';
    });

    // Render view
    const container = document.getElementById('view-container');
    container.dataset.view = viewName;
    // Mirror view name onto #content for full-width layout rules
    // (avoids reliance on CSS :has() which some browsers lack)
    document.getElementById('content').dataset.activeView = viewName;
    // Destroy previous view if it has cleanup
    if (state._activeView && state._activeView.destroy) {
      state._activeView.destroy();
    }
    const view = views[viewName];
    state._activeView = view || null;
    if (view) {
      container.innerHTML = '';
      view.render(container, state);
    } else {
      container.innerHTML = `<div class="empty-state"><h3>Unknown view: ${viewName}</h3></div>`;
    }

    // Update keys panel
    updateKeysPanel(view);
  }

  function showToast(message, type = '') {
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    toast.textContent = message;
    document.body.appendChild(toast);
    const ms = type === 'error' ? 8000 : 3000;
    setTimeout(() => toast.remove(), ms);
  }

  function showTerminal(text) {
    if (window.TerminalManager) {
      TerminalManager.show();
      return;
    }
    const panel = document.getElementById('terminal-panel');
    const output = document.getElementById('terminal-output');
    if (!panel || !output) return;
    panel.style.display = 'flex';
    if (text !== undefined) {
      output.textContent += text + '\n';
      output.scrollTop = output.scrollHeight;
    }
  }

  function clearTerminal() {
    document.getElementById('terminal-output').textContent = '';
  }

  function hideTerminal() {
    document.getElementById('terminal-panel').style.display = 'none';
  }

  // SSE
  function connectSSE() {
    if (sseSource) {
      sseSource.close();
    }
    sseSource = new EventSource('/api/events');

    sseSource.addEventListener('connected', () => {
      console.log('SSE connected');
    });

    sseSource.addEventListener('project_changed', (e) => {
      const data = JSON.parse(e.data);
      state.currentProject = data.path;
      updateProjectBadge();
      // Re-render current view (debounced to avoid racing in-flight renders)
      if (state.currentView) sseNavigate(state.currentView);
    });

    sseSource.addEventListener('projects_list_changed', () => {
      if (state.currentView === 'dashboard') sseNavigate('dashboard');
    });

    sseSource.addEventListener('repo_updated', (e) => {
      const data = JSON.parse(e.data);
      if (state.currentView === 'explore' || state.currentView === 'update' || state.currentView === 'commits') {
        sseNavigate(state.currentView);
      }
      showToast(`Repo updated: ${data.repo}`, 'success');
    });

    sseSource.addEventListener('refresh_complete', () => {
      if (state.currentView === 'explore' || state.currentView === 'update' || state.currentView === 'commits') {
        sseNavigate(state.currentView);
      }
      showToast('Refresh complete', 'success');
    });

    sseSource.addEventListener('layer_clone_done', (e) => {
      const data = JSON.parse(e.data);
      showToast('Clone complete: ' + (data.layer_name || ''), 'success');
      if (state.currentView === 'layer-index') navigate('layer-index', true);
    });

    sseSource.addEventListener('layer_clone_error', (e) => {
      const data = JSON.parse(e.data);
      showToast('Clone failed: ' + (data.error || 'unknown error'), 'error');
    });

    sseSource.addEventListener('setup_clone_done', (e) => {
      const data = JSON.parse(e.data);
      showToast('Clone complete: ' + (data.config_name || data.project_dir || ''), 'success');
      if (state.currentView === 'dashboard') navigate('dashboard', true);
    });

    sseSource.addEventListener('setup_clone_error', (e) => {
      const data = JSON.parse(e.data);
      showToast('Clone failed: ' + (data.error || 'unknown error'), 'error');
    });

    sseSource.addEventListener('setup_clone_progress', (e) => {
      const data = JSON.parse(e.data);
      showToast(`Cloning ${data.repo} (${data.current}/${data.total})...`);
    });

    sseSource.addEventListener('host_metrics_updated', () => {
      if (state.currentView === 'hosts') navigate('hosts', true);
      // Also refresh inline metrics on the dashboard
      if (state.currentView === 'dashboard' && views.dashboard._fetchHostMetrics) {
        views.dashboard._fetchHostMetrics();
      }
    });

    sseSource.addEventListener('command_output', (e) => {
      const data = JSON.parse(e.data);
      showTerminal(data.line);
      if (data.done) {
        showTerminal('--- done ---');
      }
    });

    sseSource.onerror = () => {
      sseSource.close();
      sseSource = null;
      // Reconnect after delay
      if (sseReconnectTimer) clearTimeout(sseReconnectTimer);
      sseReconnectTimer = setTimeout(connectSSE, 3000);
    };
  }

  async function updateProjectBadge() {
    try {
      const resp = await API.getCurrentProject();
      state.currentProject = resp.path;
      const el = document.getElementById('project-name');
      const sectionTitle = document.getElementById('project-section-title');
      if (resp.path) {
        const name = resp.path.split('/').pop();
        el.textContent = name;
        el.title = resp.path;
        if (sectionTitle) sectionTitle.textContent = name;
      } else {
        el.textContent = 'No project';
        if (sectionTitle) sectionTitle.textContent = 'Project';
      }
      updateYoctoSection();
    } catch (e) {
      // ignore
    }
  }

  async function updateYoctoSection() {
    const section = document.querySelector('.yocto-section');
    if (!section) return;
    try {
      const repos = await API.getRepos(state.currentProject);
      const hasYocto = Array.isArray(repos) && repos.some(r => r.layers && r.layers.length > 0);
      section.style.display = hasYocto ? '' : 'none';
    } catch (e) {
      section.style.display = 'none';
    }
  }

  function updateKeysPanel(view) {
    const el = document.getElementById('keys-content');
    if (!el) return;
    const bindings = (view && view.keyBindings) || [];
    if (!bindings.length) {
      el.innerHTML = '<div class="keys-none">No shortcuts</div>';
      return;
    }
    el.innerHTML = bindings.map(b => {
      if (b.sep) return '<div class="keys-sep"></div>';
      const cls = b.action ? 'keys-row keys-row-action' : 'keys-row';
      const actionAttr = b.action ? ` data-action-key="${esc(b.action)}"` : '';
      return `<div class="${cls}"${actionAttr}><span class="keys-key">${esc(b.key)}</span><span class="keys-desc">${esc(b.desc)}</span></div>`;
    }).join('');
    el.querySelectorAll('[data-action-key]').forEach(row => {
      row.addEventListener('click', () => {
        const key = row.dataset.actionKey;
        const v = views[state.currentView];
        if (v && typeof v.handleKeyboard === 'function') {
          v.handleKeyboard({ key, preventDefault() {} });
        }
      });
    });
  }

  function startMetricsRefresh(intervalMs) {
    stopMetricsRefresh();
    _metricsIntervalMs = intervalMs;
    if (!intervalMs || intervalMs <= 0) return;
    _metricsTimer = setInterval(async () => {
      try {
        const data = await API.getHostMetrics();
        if (state.currentView === 'hosts' && views.hosts._renderCards) {
          views.hosts._renderCards(data.hosts || []);
        }
        if (state.currentView === 'dashboard' && views.dashboard._fetchHostMetrics) {
          views.dashboard._fetchHostMetrics(data);
        }
      } catch (e) {
        // Silently ignore — metrics are supplementary
      }
    }, intervalMs);
  }

  function stopMetricsRefresh() {
    if (_metricsTimer) {
      clearInterval(_metricsTimer);
      _metricsTimer = null;
    }
    _metricsIntervalMs = 0;
  }

  function init() {
    // SSE
    connectSSE();

    // Start host metrics auto-refresh from saved config
    API.getConfig().then(cfg => {
      const secs = cfg && cfg.settings && cfg.settings.host_metrics_refresh;
      if (secs && secs > 0) startMetricsRefresh(secs * 1000);
    }).catch(() => {});

    // Project badge
    updateProjectBadge();

    // Hash routing
    window.addEventListener('hashchange', () => {
      state.currentView = null; // Force re-render on hash change
      navigate(getViewFromHash());
    });

    // Terminal close button
    document.getElementById('terminal-close').addEventListener('click', hideTerminal);

    // Message bar controls
    const msgToggle = document.getElementById('message-bar-toggle');
    const msgClose = document.getElementById('message-bar-close');
    if (msgToggle) msgToggle.addEventListener('click', _toggleMessageHistory);
    if (msgClose) msgClose.addEventListener('click', _dismissMessageBar);

    // Sidebar reset order button
    const sidebarReset = document.getElementById('sidebar-reset-order');
    if (sidebarReset) sidebarReset.addEventListener('click', () => {
      if (typeof resetSidebarOrder === 'function') resetSidebarOrder();
    });

    // Init terminal manager and messages panel
    if (window.TerminalManager) TerminalManager.init();
    if (window.MessagesPanel) {
      MessagesPanel.init();
      const navMsg = document.getElementById('nav-messages');
      if (navMsg) navMsg.addEventListener('click', () => MessagesPanel.toggle());
    }

    // Sidebar commands link
    const navCommands = document.getElementById('nav-commands');
    if (navCommands) {
      navCommands.addEventListener('click', () => {
        const persona = state.selectedProjectPersona || 'yocto';
        commandMenu(persona === 'yocto').then((view) => {
          if (view) location.hash = view;
        });
      });
    }

    // Keyboard event delegation to active view
    document.addEventListener('keydown', (e) => {
      // Skip if user is typing in an input/select/textarea or a modal is open
      if (e.target.tagName === 'INPUT' || e.target.tagName === 'SELECT' || e.target.tagName === 'TEXTAREA') return;
      if (document.querySelector('.modal-overlay')) return;

      // Backtick toggles terminal panel (unless typing in terminal)
      if (e.key === '`') {
        if (e.target.closest('.terminal-container')) return;
        e.preventDefault();
        if (window.MessagesPanel) MessagesPanel.hide();
        if (window.TerminalManager) TerminalManager.toggle();
        return;
      }

      // ? key: on dashboard, open command menu; elsewhere, toggle keys section
      if (e.key === '?') {
        if (state.currentView === 'dashboard') {
          const view = views[state.currentView];
          if (view && typeof view.handleKeyboard === 'function') {
            view.handleKeyboard(e);
          }
        } else {
          const keysSection = document.getElementById('keys-section');
          if (keysSection) {
            keysSection.classList.toggle('collapsed');
            savePreference('sidebar-keys', keysSection.classList.contains('collapsed'));
          }
        }
        return;
      }

      const view = views[state.currentView];
      if (view && typeof view.handleKeyboard === 'function') {
        view.handleKeyboard(e);
      }
    });

    // Collapsible sidebar sections (block-visibility pattern from zeddweb)
    document.querySelectorAll('.nav-section-title').forEach(title => {
      const section = title.parentElement;
      const sectionKey = section.dataset.section;
      if (sectionKey) {
        // Restore collapsed state
        const collapsed = loadPreference('sidebar-' + sectionKey, false);
        if (collapsed) section.classList.add('collapsed');

        title.addEventListener('click', () => {
          section.classList.toggle('collapsed');
          savePreference('sidebar-' + sectionKey, section.classList.contains('collapsed'));
        });
      }
    });

    // Theme selector
    const themeSelect = document.getElementById('theme-select');
    if (themeSelect) {
      const savedTheme = loadPreference('theme', '');
      themeSelect.value = savedTheme;
      document.documentElement.dataset.theme = savedTheme;
      themeSelect.addEventListener('change', () => {
        document.documentElement.dataset.theme = themeSelect.value;
        savePreference('theme', themeSelect.value);
      });
    }

    // Font settings (adapted from zeddweb preferences pattern)
    const fontSelect = document.getElementById('font-family-select');
    const fontSlider = document.getElementById('font-size-slider');
    const fontSizeDisplay = document.getElementById('font-size-display');

    if (fontSelect && fontSlider) {
      // Restore saved preferences
      const savedFont = loadPreference('font-family', null);
      const savedSize = loadPreference('font-size', 13);

      if (savedFont) {
        fontSelect.value = savedFont;
        document.documentElement.style.setProperty('--font-mono', savedFont);
      }
      fontSlider.value = savedSize;
      fontSizeDisplay.textContent = savedSize + 'px';
      if (savedSize !== 13) {
        document.documentElement.style.setProperty('--font-size-base', savedSize + 'px');
      }

      fontSelect.addEventListener('change', () => {
        const val = fontSelect.value;
        document.documentElement.style.setProperty('--font-mono', val);
        savePreference('font-family', val);
      });

      fontSlider.addEventListener('input', () => {
        const size = parseInt(fontSlider.value, 10);
        document.documentElement.style.setProperty('--font-size-base', size + 'px');
        fontSizeDisplay.textContent = size + 'px';
        savePreference('font-size', size);
      });
    }

    // Icon scale slider
    const iconSlider = document.getElementById('icon-size-slider');
    const iconSizeDisplay = document.getElementById('icon-size-display');
    if (iconSlider) {
      const savedIconScale = loadPreference('icon-scale', 100);
      iconSlider.value = savedIconScale;
      iconSizeDisplay.textContent = savedIconScale + '%';
      if (savedIconScale !== 100) {
        document.documentElement.style.setProperty('--icon-scale', savedIconScale / 100);
      }
      iconSlider.addEventListener('input', () => {
        const val = parseInt(iconSlider.value, 10);
        document.documentElement.style.setProperty('--icon-scale', val / 100);
        iconSizeDisplay.textContent = val + '%';
        savePreference('icon-scale', val);
      });
    }

    // Sidebar resize handle
    const sidebarHandle = document.getElementById('sidebar-resize-handle');
    const sidebar = document.getElementById('sidebar');
    if (sidebarHandle && sidebar) {
      const savedSidebarWidth = loadPreference('sidebar-width', null);
      if (savedSidebarWidth) {
        document.documentElement.style.setProperty('--sidebar-width', savedSidebarWidth + 'px');
      }
      let dragging = false, startX, startW;
      sidebarHandle.addEventListener('mousedown', (e) => {
        e.preventDefault();
        dragging = true;
        startX = e.clientX;
        startW = sidebar.getBoundingClientRect().width;
        document.body.style.cursor = 'ew-resize';
        document.body.style.userSelect = 'none';
      });
      document.addEventListener('mousemove', (e) => {
        if (!dragging) return;
        const w = Math.min(400, Math.max(120, startW + (e.clientX - startX)));
        document.documentElement.style.setProperty('--sidebar-width', w + 'px');
      });
      document.addEventListener('mouseup', () => {
        if (!dragging) return;
        dragging = false;
        document.body.style.cursor = '';
        document.body.style.userSelect = '';
        const w = sidebar.getBoundingClientRect().width;
        savePreference('sidebar-width', Math.round(w));
      });
      sidebarHandle.addEventListener('dblclick', () => {
        document.documentElement.style.setProperty('--sidebar-width', '200px');
        savePreference('sidebar-width', null);
      });
    }

    // Navigate to initial view
    navigate(getViewFromHash());
  }

  // Expose for views
  window.App = {
    state,
    navigate,
    showToast,
    showMessage,
    showTerminal,
    clearTerminal,
    hideTerminal,
    updateKeysPanel,
    startMetricsRefresh,
    stopMetricsRefresh,
  };

  // Boot
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }

  return { state, navigate, showToast };
})();
