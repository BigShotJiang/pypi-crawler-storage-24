/* bit web dashboard — drag-and-drop reordering
 * Adapted from zeddweb zii/scripts/left-blocks.js and stock-selector.js.
 * Uses SortableJS for drag functionality and localStorage for persistence.
 *
 * Two sortable areas:
 *  - Sidebar sections: reorder nav-section blocks within #sidebar-sections
 *  - Dashboard table: reorder groups (tbody) and rows within each group
 */
(function() {
  'use strict';

  var SIDEBAR_KEY = 'bit-sidebar-order';
  var DASHBOARD_GROUP_KEY = 'bit-dashboard-group-order';
  var DASHBOARD_ROW_KEY = 'bit-dashboard-row-order';

  // Default sidebar order (matches HTML source order)
  var DEFAULT_SIDEBAR = ['git', 'config', 'patches', 'yocto', 'system', 'keys'];

  // ---- Sidebar section reordering ----

  function initSidebarSortable() {
    var container = document.getElementById('sidebar-sections');
    if (!container || typeof Sortable === 'undefined') return;

    restoreSidebarOrder(container);

    Sortable.create(container, {
      animation: 150,
      handle: '.drag-handle',
      draggable: '.nav-section',
      ghostClass: 'nav-section-ghost',
      onEnd: function() {
        saveSidebarOrder(container);
      }
    });
  }

  function restoreSidebarOrder(container) {
    var saved = localStorage.getItem(SIDEBAR_KEY);
    if (!saved) return;

    try {
      var order = JSON.parse(saved);
      var sections = container.querySelectorAll('.nav-section');
      var sectionMap = {};

      for (var i = 0; i < sections.length; i++) {
        var id = sections[i].getAttribute('data-section');
        if (id) sectionMap[id] = sections[i];
      }

      for (var j = 0; j < order.length; j++) {
        if (sectionMap[order[j]]) {
          container.appendChild(sectionMap[order[j]]);
        }
      }
    } catch (e) {
      // ignore
    }
  }

  function saveSidebarOrder(container) {
    var sections = container.querySelectorAll('.nav-section');
    var order = [];
    for (var i = 0; i < sections.length; i++) {
      var id = sections[i].getAttribute('data-section');
      if (id) order.push(id);
    }
    localStorage.setItem(SIDEBAR_KEY, JSON.stringify(order));
  }

  function resetSidebarOrder() {
    localStorage.removeItem(SIDEBAR_KEY);
    var container = document.getElementById('sidebar-sections');
    if (!container) return;
    var sectionMap = {};
    container.querySelectorAll('.nav-section').forEach(function(s) {
      var id = s.getAttribute('data-section');
      if (id) sectionMap[id] = s;
    });
    DEFAULT_SIDEBAR.forEach(function(id) {
      if (sectionMap[id]) container.appendChild(sectionMap[id]);
    });
  }

  // ---- Dashboard two-level reordering ----
  // Level 1: reorder groups (tbody elements) within the table
  // Level 2: reorder rows within each group (tbody)

  function initDashboardSortable(table) {
    if (!table || typeof Sortable === 'undefined') return;

    // Restore saved order
    restoreDashboardGroupOrder(table);
    restoreDashboardRowOrder(table);

    // Group-level: reorder tbody elements by dragging group headers
    Sortable.create(table, {
      animation: 150,
      handle: '.dash-group-header .drag-handle',
      draggable: 'tbody[data-group]',
      ghostClass: 'dash-group-ghost',
      filter: 'thead',
      onEnd: function() {
        saveDashboardGroupOrder(table);
      }
    });

    // Row-level: one Sortable per group tbody
    table.querySelectorAll('tbody[data-group]').forEach(function(tbody) {
      Sortable.create(tbody, {
        animation: 150,
        handle: '.drag-handle',
        draggable: 'tr[data-path]',
        ghostClass: 'dash-row-ghost',
        onEnd: function() {
          saveDashboardRowOrder(table);
        }
      });
    });
  }

  function restoreDashboardGroupOrder(table) {
    var saved = localStorage.getItem(DASHBOARD_GROUP_KEY);
    if (!saved) return;
    try {
      var order = JSON.parse(saved);
      var tbodyMap = {};
      table.querySelectorAll('tbody[data-group]').forEach(function(tb) {
        tbodyMap[tb.getAttribute('data-group')] = tb;
      });
      for (var i = 0; i < order.length; i++) {
        if (tbodyMap[order[i]]) table.appendChild(tbodyMap[order[i]]);
      }
    } catch (e) { /* ignore */ }
  }

  function saveDashboardGroupOrder(table) {
    var order = [];
    table.querySelectorAll('tbody[data-group]').forEach(function(tb) {
      order.push(tb.getAttribute('data-group'));
    });
    localStorage.setItem(DASHBOARD_GROUP_KEY, JSON.stringify(order));
  }

  function restoreDashboardRowOrder(table) {
    var saved = localStorage.getItem(DASHBOARD_ROW_KEY);
    if (!saved) return;
    try {
      var orderByGroup = JSON.parse(saved);
      table.querySelectorAll('tbody[data-group]').forEach(function(tbody) {
        var group = tbody.getAttribute('data-group');
        var groupOrder = orderByGroup[group];
        if (!groupOrder) return;
        var rowMap = {};
        tbody.querySelectorAll('tr[data-path]').forEach(function(row) {
          rowMap[row.getAttribute('data-path')] = row;
        });
        for (var i = 0; i < groupOrder.length; i++) {
          if (rowMap[groupOrder[i]]) tbody.appendChild(rowMap[groupOrder[i]]);
        }
      });
    } catch (e) { /* ignore */ }
  }

  function saveDashboardRowOrder(table) {
    var orderByGroup = {};
    table.querySelectorAll('tbody[data-group]').forEach(function(tbody) {
      var group = tbody.getAttribute('data-group');
      var rows = [];
      tbody.querySelectorAll('tr[data-path]').forEach(function(row) {
        rows.push(row.getAttribute('data-path'));
      });
      orderByGroup[group] = rows;
    });
    localStorage.setItem(DASHBOARD_ROW_KEY, JSON.stringify(orderByGroup));
  }

  function resetDashboardOrder() {
    localStorage.removeItem(DASHBOARD_GROUP_KEY);
    localStorage.removeItem(DASHBOARD_ROW_KEY);
  }

  // ---- Generic view sortable (for explore, update, branch, etc.) ----

  function initViewSortable(tbody, storageKey, rowSelector) {
    if (!tbody || typeof Sortable === 'undefined') return;

    // Restore saved order
    var saved = localStorage.getItem(storageKey);
    if (saved) {
      try {
        var order = JSON.parse(saved);
        var attr = rowSelector.match(/\[([^\]]+)\]/);
        if (attr) {
          attr = attr[1];
          var rowMap = {};
          tbody.querySelectorAll(rowSelector).forEach(function(row) {
            rowMap[row.getAttribute(attr)] = row;
          });
          for (var i = 0; i < order.length; i++) {
            if (rowMap[order[i]]) tbody.appendChild(rowMap[order[i]]);
          }
        }
      } catch (e) { /* ignore */ }
    }

    // Create sortable
    var attr = rowSelector.match(/\[([^\]]+)\]/);
    var dataAttr = attr ? attr[1] : '';
    Sortable.create(tbody, {
      animation: 150,
      handle: '.drag-handle',
      draggable: rowSelector,
      ghostClass: 'view-row-ghost',
      onEnd: function() {
        var order = [];
        tbody.querySelectorAll(rowSelector).forEach(function(row) {
          order.push(row.getAttribute(dataAttr));
        });
        localStorage.setItem(storageKey, JSON.stringify(order));
      }
    });
  }

  function resetViewOrder(storageKey) {
    localStorage.removeItem(storageKey);
  }

  // ---- Init sidebar on load ----

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initSidebarSortable);
  } else {
    initSidebarSortable();
  }

  // Expose for dynamic rendering and reset
  window.initDashboardSortable = initDashboardSortable;
  window.resetDashboardOrder = resetDashboardOrder;
  window.resetSidebarOrder = resetSidebarOrder;
  window.initViewSortable = initViewSortable;
  window.resetViewOrder = resetViewOrder;

})();
