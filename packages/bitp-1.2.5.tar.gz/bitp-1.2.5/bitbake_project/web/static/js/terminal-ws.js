/* xterm.js WebSocket terminal manager — tabbed bottom panel with PTY sessions */
const TerminalManager = (() => {
  let tabs = [];          // Array of { id, term, fitAddon, ws, wsParams, title, containerEl, tabEl }
  let activeTabId = null;
  let nextTabId = 1;
  let resizeObserver = null;
  let _resizing = false;

  const panel = () => document.getElementById('terminal-panel');
  const tabBar = () => document.getElementById('terminal-tab-bar');
  const tabContent = () => document.getElementById('terminal-tab-content');

  /** Sync --terminal-actual-height so #content shrinks to fit. */
  function _syncContentHeight() {
    const p = panel();
    if (p && p.style.display !== 'none') {
      document.documentElement.style.setProperty(
        '--terminal-actual-height', p.offsetHeight + 'px');
    } else {
      document.documentElement.style.removeProperty('--terminal-actual-height');
    }
  }

  function _getThemeColors() {
    const s = getComputedStyle(document.documentElement);
    const v = (name) => s.getPropertyValue(name).trim();
    return {
      background: v('--bg-primary') || '#1a1b26',
      foreground: v('--text-primary') || '#c0caf5',
      cursor: v('--accent') || '#7aa2f7',
      cursorAccent: v('--bg-primary') || '#1a1b26',
      selectionBackground: v('--bg-hover') || '#3b3f5c',
      black: v('--bg-secondary') || '#24283b',
      red: v('--red') || '#f7768e',
      green: v('--green') || '#9ece6a',
      yellow: v('--yellow') || '#e0af68',
      blue: v('--accent') || '#7aa2f7',
      magenta: v('--purple') || '#bb9af7',
      cyan: v('--cyan') || '#7dcfff',
      white: v('--text-primary') || '#c0caf5',
      brightBlack: v('--text-muted') || '#565f89',
      brightRed: v('--red') || '#f7768e',
      brightGreen: v('--green') || '#9ece6a',
      brightYellow: v('--yellow') || '#e0af68',
      brightBlue: v('--accent') || '#7aa2f7',
      brightMagenta: v('--purple') || '#bb9af7',
      brightCyan: v('--cyan') || '#7dcfff',
      brightWhite: v('--text-primary') || '#c0caf5',
    };
  }

  function _getFontSize() {
    const saved = localStorage.getItem('terminal-font-size');
    return saved ? parseInt(saved, 10) : 14;
  }

  function _getFontFamily() {
    return localStorage.getItem('terminal-font-family') || "'JetBrains Mono', monospace";
  }

  function _getTab(id) {
    return tabs.find(t => t.id === id);
  }

  function _activeTab() {
    return activeTabId != null ? _getTab(activeTabId) : null;
  }

  function _fitTab(tab) {
    if (tab && tab.fitAddon) {
      try { tab.fitAddon.fit(); } catch (e) { /* ignore */ }
    }
  }

  function _sendSize(tab) {
    if (tab && tab.ws && tab.ws.readyState === WebSocket.OPEN && tab.term) {
      const cols = tab.term.cols || 80;
      const rows = tab.term.rows || 24;
      tab.ws.send(JSON.stringify({ type: 'resize', cols: cols, rows: rows }));
    }
  }

  function _cleanupTab(tab) {
    if (tab.ws) { tab.ws.close(); tab.ws = null; }
    if (tab.term) { tab.term.dispose(); tab.term = null; tab.fitAddon = null; }
    tab.tabEl.remove();
    tab.containerEl.remove();
  }

  function _connectTab(tab) {
    if (tab.ws && (tab.ws.readyState === WebSocket.OPEN ||
                   tab.ws.readyState === WebSocket.CONNECTING)) {
      return;
    }

    const proto = location.protocol === 'https:' ? 'wss:' : 'ws:';
    const qp = tab.wsParams ? '?' + tab.wsParams : '';
    tab.ws = new WebSocket(proto + '//' + location.host + '/ws/terminal' + qp);
    tab.ws.binaryType = 'arraybuffer';

    tab.ws.onopen = () => {
      _fitTab(tab);
      _sendSize(tab);
      if (tab.term) tab.term.write('\x1b[90m[connected]\x1b[0m\r\n');
    };

    tab.ws.onmessage = (e) => {
      if (tab.term) {
        if (e.data instanceof ArrayBuffer) {
          tab.term.write(new Uint8Array(e.data));
        } else {
          tab.term.write(e.data);
        }
      }
    };

    tab.ws.onclose = (e) => {
      if (tab.term) {
        if (e.code === 1006) {
          tab.term.write('\r\n\x1b[31m[connection lost]\x1b[0m\r\n');
        } else if (e.reason) {
          tab.term.write(`\r\n\x1b[90m[${e.reason.toLowerCase()}]\x1b[0m\r\n`);
        } else {
          tab.term.write('\r\n\x1b[90m[disconnected]\x1b[0m\r\n');
        }
      }
      tab.ws = null;
    };

    tab.ws.onerror = (e) => {
      console.error('[terminal] WebSocket error:', e);
      if (tab.term) tab.term.write('\r\n\x1b[31m[connection error]\x1b[0m\r\n');
      tab.ws = null;
    };

    if (tab.term) {
      tab.term.onData((data) => {
        if (tab.ws && tab.ws.readyState === WebSocket.OPEN) {
          tab.ws.send(JSON.stringify({ type: 'input', data: data }));
        }
      });
    }
  }

  function _createTab(wsParams, title) {
    const id = nextTabId++;
    const tc = tabContent();
    const tb = tabBar();
    if (!tc || !tb) return null;

    // Create container
    const containerEl = document.createElement('div');
    containerEl.className = 'terminal-container';
    containerEl.dataset.tabId = id;
    tc.appendChild(containerEl);

    // Create terminal
    const term = new Terminal({
      theme: _getThemeColors(),
      fontFamily: _getFontFamily(),
      fontSize: _getFontSize(),
      cursorBlink: true,
      allowProposedApi: true,
    });
    const fitAddon = new FitAddon.FitAddon();
    term.loadAddon(fitAddon);
    term.open(containerEl);

    // Create tab element
    const tabEl = document.createElement('div');
    tabEl.className = 'terminal-tab';
    tabEl.dataset.tabId = id;
    const titleSpan = document.createElement('span');
    titleSpan.className = 'terminal-tab-title';
    titleSpan.textContent = title || 'Terminal';
    tabEl.appendChild(titleSpan);
    const closeBtn = document.createElement('button');
    closeBtn.className = 'terminal-tab-close';
    closeBtn.innerHTML = '&times;';
    closeBtn.title = 'Close tab';
    tabEl.appendChild(closeBtn);
    tb.appendChild(tabEl);

    // Tab click handlers
    tabEl.addEventListener('click', (e) => {
      if (e.target === closeBtn || closeBtn.contains(e.target)) return;
      _activateTab(id);
    });
    closeBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      _closeTab(id);
    });

    // Middle-click to close
    tabEl.addEventListener('auxclick', (e) => {
      if (e.button === 1) {
        e.preventDefault();
        _closeTab(id);
      }
    });

    const tab = { id, term, fitAddon, ws: null, wsParams: wsParams || '', title: title || 'Terminal', containerEl, tabEl };
    tabs.push(tab);

    // Sync font dropdowns
    const sizeSel = document.getElementById('terminal-font-size');
    if (sizeSel) sizeSel.value = String(_getFontSize());
    const familySel = document.getElementById('terminal-font-family');
    if (familySel) familySel.value = _getFontFamily();

    return tab;
  }

  function _activateTab(id) {
    // Deactivate all
    tabs.forEach(t => {
      t.containerEl.classList.remove('active');
      t.tabEl.classList.remove('active');
    });

    const tab = _getTab(id);
    if (!tab) return;

    tab.containerEl.classList.add('active');
    tab.tabEl.classList.add('active');
    activeTabId = id;

    // Scroll tab into view
    tab.tabEl.scrollIntoView({ inline: 'nearest', block: 'nearest' });

    requestAnimationFrame(() => {
      _fitTab(tab);
      _sendSize(tab);
      if (tab.term) tab.term.focus();
    });
  }

  function _closeTab(id) {
    const idx = tabs.findIndex(t => t.id === id);
    if (idx === -1) return;
    const tab = tabs[idx];

    _cleanupTab(tab);
    tabs.splice(idx, 1);

    if (activeTabId === id) {
      if (tabs.length > 0) {
        const newIdx = Math.min(idx, tabs.length - 1);
        requestAnimationFrame(() => _activateTab(tabs[newIdx].id));
      } else {
        activeTabId = null;
        hide();
      }
    }
  }

  function _setupResize() {
    if (resizeObserver) resizeObserver.disconnect();
    const el = tabContent();
    if (!el) return;

    let _resizeTimer = null;
    resizeObserver = new ResizeObserver(() => {
      if (_resizeTimer) clearTimeout(_resizeTimer);
      _resizeTimer = setTimeout(() => {
        const tab = _activeTab();
        if (tab && tab.term) {
          _fitTab(tab);
          _sendSize(tab);
        }
      }, _resizing ? 50 : 0);
    });
    resizeObserver.observe(el);
  }

  function _setupDragResize() {
    const p = panel();
    if (!p) return;

    let handle = p.querySelector('.terminal-resize-handle');
    if (!handle) {
      handle = document.createElement('div');
      handle.className = 'terminal-resize-handle';
      p.insertBefore(handle, p.firstChild);
    }

    handle.addEventListener('mousedown', (e) => {
      e.preventDefault();
      _resizing = true;
      const startY = e.clientY;
      const startHeight = p.offsetHeight;

      const onMouseMove = (me) => {
        const delta = startY - me.clientY;
        const newHeight = Math.max(100, Math.min(window.innerHeight - 60, startHeight + delta));
        p.style.height = newHeight + 'px';
        _syncContentHeight();
      };

      const onMouseUp = () => {
        _resizing = false;
        document.removeEventListener('mousemove', onMouseMove);
        document.removeEventListener('mouseup', onMouseUp);
        document.body.style.cursor = '';
        document.body.style.userSelect = '';
        _syncContentHeight();
        const tab = _activeTab();
        if (tab && tab.term) {
          _fitTab(tab);
          _sendSize(tab);
        }
      };

      document.body.style.cursor = 'ns-resize';
      document.body.style.userSelect = 'none';
      document.addEventListener('mousemove', onMouseMove);
      document.addEventListener('mouseup', onMouseUp);
    });
  }

  /**
   * Show the terminal panel and connect.
   * @param {object} [opts] - Optional session parameters.
   * @param {string} [opts.cwd]  - Working directory for local shell.
   * @param {string} [opts.ssh]  - SSH target (user@host) for remote shell.
   * @param {string} [opts.path] - Remote path (used with opts.ssh).
   * @param {string} [opts.session] - Tmux session name (e.g. 'bit-poky').
   * @param {string} [opts.title] - Tab title override.
   * @param {string} [opts.cmd]  - Direct command to run (tig, lazygit, etc).
   */
  function show(opts) {
    const p = panel();
    if (!p) return;

    // Close messages panel if open (mutual exclusion)
    if (window.MessagesPanel) MessagesPanel.hide();

    // Show panel
    p.style.display = 'flex';
    document.body.classList.add('terminal-open');

    // Set up resize/drag once
    if (!resizeObserver) {
      _setupResize();
      _setupDragResize();
    }

    if (opts && (opts.cwd || opts.ssh || opts.cmd)) {
      // Build WebSocket params
      const params = new URLSearchParams();
      if (opts.ssh) {
        params.set('ssh', opts.ssh);
        if (opts.path) params.set('path', opts.path);
      } else if (opts.cwd) {
        params.set('cwd', opts.cwd);
      }
      if (opts.session) params.set('session', opts.session);
      if (opts.cmd) params.set('cmd', opts.cmd);
      const wsParams = params.toString();

      const title = opts.title ||
        (opts.ssh ? 'Shell: ' + opts.ssh :
         opts.cmd ? opts.cmd.split(/\s+/)[0] :
         'Shell: ' + (opts.cwd || '').split('/').pop());

      // Create a new tab for this session
      const tab = _createTab(wsParams, title);
      if (tab) {
        _activateTab(tab.id);
        requestAnimationFrame(() => {
          _syncContentHeight();
          _connectTab(tab);
        });
      }
    } else if (tabs.length === 0) {
      // No tabs — create a default local terminal
      const tab = _createTab('', 'Terminal');
      if (tab) {
        _activateTab(tab.id);
        requestAnimationFrame(() => {
          _syncContentHeight();
          _connectTab(tab);
        });
      }
    } else {
      // Panel already has tabs — just show and focus active
      requestAnimationFrame(() => {
        _syncContentHeight();
        const tab = _activeTab();
        if (tab) {
          _fitTab(tab);
          _sendSize(tab);
          if (tab.term) tab.term.focus();
        }
      });
    }
  }

  function hide() {
    const p = panel();
    if (p) p.style.display = 'none';
    document.body.classList.remove('terminal-open');
    _syncContentHeight();
  }

  function toggle() {
    const p = panel();
    if (!p) return;
    if (p.style.display === 'none' || !p.style.display) {
      show();
    } else {
      hide();
    }
  }

  function destroy() {
    // Close all tabs
    while (tabs.length > 0) {
      _cleanupTab(tabs[0]);
      tabs.shift();
    }
    activeTabId = null;
    document.body.classList.remove('terminal-open');
    _syncContentHeight();
    if (resizeObserver) {
      resizeObserver.disconnect();
      resizeObserver = null;
    }
  }

  function newSession() {
    const p = panel();
    if (!p) return;

    // Ensure panel is visible and resize is set up
    p.style.display = 'flex';
    document.body.classList.add('terminal-open');
    if (!resizeObserver) {
      _setupResize();
      _setupDragResize();
    }

    // Always create a new tab
    const tab = _createTab('', 'Terminal');
    if (tab) {
      _activateTab(tab.id);
      requestAnimationFrame(() => {
        _syncContentHeight();
        _connectTab(tab);
      });
    }
  }

  function init() {
    const closeBtn = document.getElementById('terminal-close');
    if (closeBtn) closeBtn.addEventListener('click', hide);

    const newBtn = document.getElementById('terminal-new');
    if (newBtn) newBtn.addEventListener('click', newSession);

    const killBtn = document.getElementById('terminal-killall');
    if (killBtn) {
      killBtn.addEventListener('click', async () => {
        if (!confirm('Kill all bit-* tmux sessions?')) return;
        try {
          const resp = await fetch('/api/terminal/killall', { method: 'POST' });
          const data = await resp.json();
          const n = data.killed ? data.killed.length : 0;
          const tab = _activeTab();
          if (tab && tab.term) {
            tab.term.write(`\r\n\x1b[33m[killed ${n} tmux session${n !== 1 ? 's' : ''}]\x1b[0m\r\n`);
          }
        } catch (e) {
          const tab = _activeTab();
          if (tab && tab.term) tab.term.write('\r\n\x1b[31m[killall failed]\x1b[0m\r\n');
        }
      });
    }

    const popoutBtn = document.getElementById('terminal-popout');
    if (popoutBtn) {
      popoutBtn.addEventListener('click', () => {
        const tab = _activeTab();
        const title = tab ? tab.title : 'Terminal';
        const popParams = new URLSearchParams();
        if (tab && tab.wsParams) popParams.set('ws', tab.wsParams);
        popParams.set('title', title);
        const url = '/terminal.html?' + popParams.toString();
        window.open(url, '_blank', 'width=900,height=600');
        // Close just this tab — the popout has its own session
        if (tab) _closeTab(tab.id);
      });
    }

    const fontSel = document.getElementById('terminal-font-size');
    if (fontSel) {
      const saved = localStorage.getItem('terminal-font-size');
      if (saved) fontSel.value = saved;
      fontSel.addEventListener('change', () => {
        const size = parseInt(fontSel.value, 10);
        localStorage.setItem('terminal-font-size', String(size));
        tabs.forEach(t => {
          if (t.term) {
            t.term.options.fontSize = size;
            _fitTab(t);
            _sendSize(t);
          }
        });
      });
    }

    const familySel = document.getElementById('terminal-font-family');
    if (familySel) {
      const saved = localStorage.getItem('terminal-font-family');
      if (saved) familySel.value = saved;
      familySel.addEventListener('change', () => {
        localStorage.setItem('terminal-font-family', familySel.value);
        tabs.forEach(t => {
          if (t.term) {
            t.term.options.fontFamily = familySel.value;
            _fitTab(t);
            _sendSize(t);
          }
        });
      });
    }
  }

  return { show, hide, toggle, destroy, init };
})();

window.TerminalManager = TerminalManager;
