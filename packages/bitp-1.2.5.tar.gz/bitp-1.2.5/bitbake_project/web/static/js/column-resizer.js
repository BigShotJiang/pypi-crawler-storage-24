/* bit web dashboard — draggable column resizer
 * Adapted from zeddweb zii/scripts/column-resizer.js.
 * Adds drag handles to .data-table columns. Widths persist in localStorage.
 * Double-click a handle to reset all columns to defaults.
 */
(function() {
  'use strict';

  var STORAGE_KEY = 'bit-column-widths';
  var MIN_WIDTH = 60;

  function loadWidths() {
    try {
      var stored = localStorage.getItem(STORAGE_KEY);
      if (stored) return JSON.parse(stored);
    } catch (e) { /* ignore */ }
    return {};
  }

  function saveWidths(widths) {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(widths));
    } catch (e) { /* ignore */ }
  }

  /**
   * Initialize column resizing on a table.
   * @param {HTMLTableElement} table - The table element
   * @param {string} [tableId] - Optional ID for localStorage persistence
   */
  function initColumnResizer(table, tableId) {
    if (!table || window.innerWidth <= 768) return;

    var thead = table.querySelector('thead');
    if (!thead) return;
    var headerRow = thead.querySelector('tr');
    if (!headerRow) return;
    var ths = headerRow.querySelectorAll('th');
    if (ths.length < 2) return;

    var id = tableId || table.id || table.className || 'table';
    var allWidths = loadWidths();
    var savedWidths = allWidths[id] || null;

    // Apply saved widths
    if (savedWidths) {
      ths.forEach(function(th, i) {
        if (savedWidths[i]) {
          th.style.width = savedWidths[i] + 'px';
        }
      });
    }

    // Add resize handles between columns
    ths.forEach(function(th, i) {
      if (i === ths.length - 1) return; // No handle on last column

      // Skip if already has a handle
      if (th.querySelector('.col-resize-handle')) return;

      var handle = document.createElement('div');
      handle.className = 'col-resize-handle';
      handle.style.cssText = 'position:absolute;right:-3px;top:0;bottom:0;width:6px;cursor:col-resize;z-index:10';
      th.style.position = 'relative';
      th.appendChild(handle);

      var startX, startWidth, nextTh, nextStartWidth;

      handle.addEventListener('mousedown', function(e) {
        e.preventDefault();
        e.stopPropagation();
        startX = e.clientX;
        startWidth = th.offsetWidth;
        nextTh = ths[i + 1];
        nextStartWidth = nextTh ? nextTh.offsetWidth : 0;

        document.addEventListener('mousemove', onMouseMove);
        document.addEventListener('mouseup', onMouseUp);
        document.body.style.cursor = 'col-resize';
        document.body.style.userSelect = 'none';
      });

      // Double-click resets all columns
      handle.addEventListener('dblclick', function(e) {
        e.preventDefault();
        e.stopPropagation();
        ths.forEach(function(t) { t.style.width = ''; });
        var all = loadWidths();
        delete all[id];
        saveWidths(all);
      });

      function onMouseMove(e) {
        var dx = e.clientX - startX;
        var newWidth = Math.max(MIN_WIDTH, startWidth + dx);
        th.style.width = newWidth + 'px';
        if (nextTh) {
          var nextNew = Math.max(MIN_WIDTH, nextStartWidth - dx);
          nextTh.style.width = nextNew + 'px';
        }
      }

      function onMouseUp() {
        document.removeEventListener('mousemove', onMouseMove);
        document.removeEventListener('mouseup', onMouseUp);
        document.body.style.cursor = '';
        document.body.style.userSelect = '';

        // Persist widths
        var currentWidths = {};
        ths.forEach(function(t, j) {
          currentWidths[j] = t.offsetWidth;
        });
        var all = loadWidths();
        all[id] = currentWidths;
        saveWidths(all);
      }
    });
  }

  // Expose globally
  window.initColumnResizer = initColumnResizer;

})();
