"""
Lynara SDK — Python client for the Lynara ERP platform.

Usage:
    from lynara import Lynara

    client = Lynara(
        url="https://api.lynara.ai",
        api_key="lnr_live_xxx",
        company_id="your-company-uuid",
    )

    # List CRM leads
    leads = client.crm.leads.list(limit=50)

    # Create an employee
    client.rh.employees.create({
        "first_name": "Ali",
        "last_name": "Ben Salah",
        "email": "ali@company.tn",
        "phone": "+216 XX XXX XXX",
        "hire_date": "2026-03-01",
    })

    # Export customers to CSV
    csv_data = client.catalog.customers.export(format="csv")
"""

from .client import Lynara, LynaraClient
from .exceptions import (
    LynaraError,
    AuthenticationError,
    PermissionError as LynaraPermissionError,
    NotFoundError,
    RateLimitError,
    ValidationError,
    ServerError,
)

__version__ = "0.1.0"
__all__ = [
    "Lynara",
    "LynaraClient",
    "LynaraError",
    "AuthenticationError",
    "LynaraPermissionError",
    "NotFoundError",
    "RateLimitError",
    "ValidationError",
    "ServerError",
]
