"""Module Banque — Relevés, transactions, rapprochements bancaires."""

from ..resource import Resource


class Banking:
    """Accès aux ressources du module Banque (schema banking.*)."""

    def __init__(self, http):
        self._http = http

    @property
    def statements(self) -> Resource:
        return Resource(self._http, "banking", "statements")

    @property
    def transactions(self) -> Resource:
        return Resource(self._http, "banking", "transactions")

    @property
    def reconciliations(self) -> Resource:
        return Resource(self._http, "banking", "reconciliations")
