"""Module Ventes — Devis, commandes, factures, livraisons, avoirs, paiements."""

from ..resource import Resource


class Sales:
    """Accès aux ressources du module Ventes (schema sales.*)."""

    def __init__(self, http):
        self._http = http

    # Devis
    @property
    def quotes(self) -> Resource:
        return Resource(self._http, "sales", "quotes")

    @property
    def quote_lines(self) -> Resource:
        return Resource(self._http, "sales", "quote_lines")

    # Bons de commande
    @property
    def orders(self) -> Resource:
        return Resource(self._http, "sales", "orders")

    @property
    def order_lines(self) -> Resource:
        return Resource(self._http, "sales", "order_lines")

    # Factures
    @property
    def invoices(self) -> Resource:
        return Resource(self._http, "sales", "invoices")

    @property
    def invoice_lines(self) -> Resource:
        return Resource(self._http, "sales", "invoice_lines")

    # Bons de livraison
    @property
    def delivery_notes(self) -> Resource:
        return Resource(self._http, "sales", "delivery_notes")

    @property
    def delivery_note_lines(self) -> Resource:
        return Resource(self._http, "sales", "delivery_note_lines")

    # Bons de sortie
    @property
    def exit_vouchers(self) -> Resource:
        return Resource(self._http, "sales", "exit_vouchers")

    @property
    def exit_voucher_lines(self) -> Resource:
        return Resource(self._http, "sales", "exit_voucher_lines")

    # Avoirs
    @property
    def credit_notes(self) -> Resource:
        return Resource(self._http, "sales", "credit_notes")

    @property
    def credit_note_lines(self) -> Resource:
        return Resource(self._http, "sales", "credit_note_lines")

    # Allocations
    @property
    def allocations(self) -> Resource:
        return Resource(self._http, "sales", "allocations")

    # Encaissements
    @property
    def receipts(self) -> Resource:
        return Resource(self._http, "sales", "receipts")
