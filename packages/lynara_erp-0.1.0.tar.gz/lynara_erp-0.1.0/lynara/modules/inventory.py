"""Module Inventaire — Stockage, niveaux, lots, mouvements, séries, comptages."""

from ..resource import Resource


class Inventory:
    """Accès aux ressources du module Inventaire (schema inventory.*)."""

    def __init__(self, http):
        self._http = http

    @property
    def storage_units(self) -> Resource:
        return Resource(self._http, "inventory", "storage_units")

    @property
    def product_settings(self) -> Resource:
        return Resource(self._http, "inventory", "product_settings")

    @property
    def stock_levels(self) -> Resource:
        return Resource(self._http, "inventory", "stock_levels")

    @property
    def lots(self) -> Resource:
        return Resource(self._http, "inventory", "lots")

    @property
    def movements(self) -> Resource:
        return Resource(self._http, "inventory", "movements")

    @property
    def serial_numbers(self) -> Resource:
        return Resource(self._http, "inventory", "serial_numbers")

    @property
    def stock_counts(self) -> Resource:
        return Resource(self._http, "inventory", "stock_counts")
