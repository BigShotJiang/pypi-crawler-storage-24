"""
Compta module — journal entries, chart of accounts.
"""

from ..http import HttpClient
from ..resource import Resource


class Compta:
    """
    Compta (Accounting) module accessor.

    Usage:
        client.compta.journals.list(limit=100)
        client.compta.accounts.get("uuid-123")
    """

    def __init__(self, http: HttpClient):
        self.journals = Resource(http, "compta", "journals")
        self.accounts = Resource(http, "compta", "accounts")

    def __repr__(self) -> str:
        return "Compta(journals, accounts)"
