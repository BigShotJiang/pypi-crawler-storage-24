"""
Trésorerie module — invoices, payments, charges.
"""

from ..http import HttpClient
from ..resource import Resource


class Tresorerie:
    """
    Trésorerie (Treasury) module accessor.

    Usage:
        client.tresorerie.invoices.list(status="pending")
        client.tresorerie.payments.create({"invoice_id": "...", "amount": 1500})
        client.tresorerie.charges.iterate()
    """

    def __init__(self, http: HttpClient):
        self.invoices = Resource(http, "tresorerie", "invoices")
        self.payments = Resource(http, "tresorerie", "payments")
        self.charges = Resource(http, "tresorerie", "charges")

    def __repr__(self) -> str:
        return "Tresorerie(invoices, payments, charges)"
