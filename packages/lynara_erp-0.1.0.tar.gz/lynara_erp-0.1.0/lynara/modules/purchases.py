"""Module Achats — Factures fournisseurs, paiements, devis fournisseurs."""

from ..resource import Resource


class Purchases:
    """Accès aux ressources du module Achats (schema purchase.*)."""

    def __init__(self, http):
        self._http = http

    @property
    def invoices(self) -> Resource:
        return Resource(self._http, "purchases", "invoices")

    @property
    def invoice_lines(self) -> Resource:
        return Resource(self._http, "purchases", "invoice_lines")

    @property
    def payments(self) -> Resource:
        return Resource(self._http, "purchases", "payments")

    @property
    def allocations(self) -> Resource:
        return Resource(self._http, "purchases", "allocations")

    @property
    def quotes(self) -> Resource:
        return Resource(self._http, "purchases", "quotes")

    @property
    def quote_lines(self) -> Resource:
        return Resource(self._http, "purchases", "quote_lines")
