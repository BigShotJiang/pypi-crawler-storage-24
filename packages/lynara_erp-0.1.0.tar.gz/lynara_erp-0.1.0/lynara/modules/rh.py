"""Module RH — Employés, contrats, congés, paie, formations, compétences."""

from ..resource import Resource


class RH:
    """
    RH (Ressources Humaines) module accessor.

    Usage:
        client.rh.employees.list(limit=100)
        client.rh.contracts.create({"employee_id": "...", "type": "CDI"})
        client.rh.leave_requests.iterate(status="approved")
    """

    def __init__(self, http):
        # Employés
        self.employees = Resource(http, "rh", "employees")
        self.addresses = Resource(http, "rh", "addresses")
        self.bank_accounts = Resource(http, "rh", "bank_accounts")
        self.employee_roles = Resource(http, "rh", "employee_roles")
        self.employee_dependents = Resource(http, "rh", "employee_dependents")
        self.employee_history = Resource(http, "rh", "employee_history")
        self.employee_documents = Resource(http, "rh", "employee_documents")

        # Contrats
        self.contracts = Resource(http, "rh", "contracts")
        self.contract_history = Resource(http, "rh", "contract_history")

        # Organisation
        self.departments = Resource(http, "rh", "departments")

        # Rémunération
        self.salary_history = Resource(http, "rh", "salary_history")
        self.bonuses = Resource(http, "rh", "bonuses")
        self.bonuses_history = Resource(http, "rh", "bonuses_history")
        self.indemnities = Resource(http, "rh", "indemnities")
        self.indemnities_history = Resource(http, "rh", "indemnities_history")
        self.benefits_in_kind = Resource(http, "rh", "benefits_in_kind")
        self.benefits_in_kind_history = Resource(http, "rh", "benefits_in_kind_history")

        # Congés & Absences
        self.employee_leaves = Resource(http, "rh", "employee_leaves")
        self.leave_requests = Resource(http, "rh", "leave_requests")
        self.leave_balances = Resource(http, "rh", "leave_balances")
        self.absences = Resource(http, "rh", "absences")

        # Temps & Dépenses
        self.time_entries = Resource(http, "rh", "time_entries")
        self.expense_reports = Resource(http, "rh", "expense_reports")
        self.expense_lines = Resource(http, "rh", "expense_lines")

        # Formations & Compétences
        self.trainings = Resource(http, "rh", "trainings")
        self.employee_trainings = Resource(http, "rh", "employee_trainings")
        self.training_notes = Resource(http, "rh", "training_notes")
        self.skills = Resource(http, "rh", "skills")
        self.employee_education = Resource(http, "rh", "employee_education")
        self.employee_certifications = Resource(http, "rh", "employee_certifications")
        self.employee_work_experience = Resource(http, "rh", "employee_work_experience")

    def __repr__(self) -> str:
        return "RH(employees, contracts, departments, leave_requests, trainings, ...)"
