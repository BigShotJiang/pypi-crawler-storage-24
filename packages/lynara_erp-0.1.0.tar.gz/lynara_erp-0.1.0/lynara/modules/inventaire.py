"""
Inventaire module — products, stock, movements, warehouses, categories.
"""

from ..http import HttpClient
from ..resource import Resource


class Inventaire:
    """
    Inventaire (Inventory) module accessor.

    Usage:
        client.inventaire.products.list(limit=200)
        client.inventaire.stock.get("uuid-123")
        client.inventaire.movements.create({"product_id": "...", "quantity": 10})
    """

    def __init__(self, http: HttpClient):
        self.products = Resource(http, "inventaire", "products")
        self.stock = Resource(http, "inventaire", "stock")
        self.movements = Resource(http, "inventaire", "movements")
        self.warehouses = Resource(http, "inventaire", "warehouses")
        self.categories = Resource(http, "inventaire", "categories")

    def __repr__(self) -> str:
        return "Inventaire(products, stock, movements, warehouses, categories)"
