"""Module CRM — Leads, opportunités, activités, notes, pipeline."""

from ..resource import Resource


class CRM:
    """
    CRM module accessor.

    Usage:
        client.crm.leads.list(limit=50)
        client.crm.opportunities.create({"name": "Deal X", "amount": 50000})
        client.crm.activities.iterate()
    """

    def __init__(self, http):
        self.leads = Resource(http, "crm", "leads")
        self.opportunities = Resource(http, "crm", "opportunities")
        self.activities = Resource(http, "crm", "activities")
        self.notes = Resource(http, "crm", "notes")
        self.pipeline_stages = Resource(http, "crm", "pipeline_stages")

    def __repr__(self) -> str:
        return "CRM(leads, opportunities, activities, notes, pipeline_stages)"
