"""Module Catalogue — Clients, fournisseurs, produits, catégories, listes de prix."""

from ..resource import Resource


class Catalog:
    """Accès aux ressources du module Catalogue (schema catalog.*)."""

    def __init__(self, http):
        self._http = http

    @property
    def customers(self) -> Resource:
        return Resource(self._http, "catalog", "customers")

    @property
    def suppliers(self) -> Resource:
        return Resource(self._http, "catalog", "suppliers")

    @property
    def product_categories(self) -> Resource:
        return Resource(self._http, "catalog", "product_categories")

    @property
    def product_subcategories(self) -> Resource:
        return Resource(self._http, "catalog", "product_subcategories")

    @property
    def products(self) -> Resource:
        return Resource(self._http, "catalog", "products")

    @property
    def price_lists(self) -> Resource:
        return Resource(self._http, "catalog", "price_lists")

    @property
    def price_list_items(self) -> Resource:
        return Resource(self._http, "catalog", "price_list_items")
