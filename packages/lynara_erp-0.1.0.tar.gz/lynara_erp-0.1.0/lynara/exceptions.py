"""
Exceptions for the Lynara SDK.
"""


class LynaraError(Exception):
    """Base exception for all Lynara SDK errors."""

    def __init__(self, message: str, status_code: int = 0, detail: str = ""):
        self.message = message
        self.status_code = status_code
        self.detail = detail
        super().__init__(message)


class AuthenticationError(LynaraError):
    """API key is invalid, expired, or revoked."""
    pass


class PermissionError(LynaraError):
    """API key does not have the required permission or module access."""
    pass


class NotFoundError(LynaraError):
    """Resource or record not found."""
    pass


class RateLimitError(LynaraError):
    """Rate limit exceeded. Retry after the specified delay."""

    def __init__(self, message: str, retry_after: int = 60):
        self.retry_after = retry_after
        super().__init__(message, status_code=429)


class ValidationError(LynaraError):
    """Request data is invalid."""
    pass


class ServerError(LynaraError):
    """Internal server error on the Lynara API."""
    pass
