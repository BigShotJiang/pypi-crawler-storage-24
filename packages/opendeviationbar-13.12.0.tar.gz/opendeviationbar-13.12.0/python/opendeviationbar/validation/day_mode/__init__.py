"""Day-mode invariant validation module (#264).

Enforces: every bar belongs to exactly one UTC day.
Three layers: pre-write gate, oracle verification, CLI observation.
"""

from .guards import (
    split_trades_by_day,
    validate_bar_day_mode,
    validate_bars_day_mode,
)
from .oracle import cross_midnight_count, stathera_day_classification

__all__ = [
    "cross_midnight_count",
    "split_trades_by_day",
    "stathera_day_classification",
    "validate_bar_day_mode",
    "validate_bars_day_mode",
]
