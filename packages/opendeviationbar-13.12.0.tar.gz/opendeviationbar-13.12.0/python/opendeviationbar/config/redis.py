# Issue #158 Phase 7: Redis configuration for distributed write locks.
"""Redis configuration for cache write locks.

Env vars (prefix OPENDEVIATIONBAR_REDIS_):
    HOST             Redis host (default: localhost)
    PORT             Redis port (default: 6379)
    DB               Redis database number (default: 0)
    LOCK_TIMEOUT     Lock TTL in seconds — auto-expire if holder crashes (default: 120)
    LOCK_BLOCKING_TIMEOUT   Max seconds to wait for lock acquisition (default: 60)
    ENABLED          Enable/disable Redis locking (default: true)
"""

from __future__ import annotations

import os


class RedisConfig:
    """Redis configuration loaded from environment variables.

    All values have sensible defaults. Redis is optional — if disabled or
    unavailable, the write lock degrades to a no-op and L2 (schema dedup)
    catches overlaps.
    """

    def __init__(self) -> None:
        prefix = "OPENDEVIATIONBAR_REDIS_"
        self.host: str = os.environ.get(f"{prefix}HOST", "localhost")
        self.port: int = int(os.environ.get(f"{prefix}PORT", "6379"))
        self.db: int = int(os.environ.get(f"{prefix}DB", "0"))
        self.lock_timeout: int = int(os.environ.get(f"{prefix}LOCK_TIMEOUT", "120"))
        self.lock_blocking_timeout: int = int(
            os.environ.get(f"{prefix}LOCK_BLOCKING_TIMEOUT", "60")
        )
        self.enabled: bool = os.environ.get(f"{prefix}ENABLED", "true").lower() in (
            "true",
            "1",
            "yes",
        )
