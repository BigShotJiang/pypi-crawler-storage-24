# [13.12.0](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.11.2...v13.12.0) (2026-03-11)


### Features

* **kintsugi:** multi-day batch processing per shard repair ([#264](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/264)) ([2340338](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/23403389334dc95b72a0bd79c9030d53223aac40))

## [13.11.2](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.11.1...v13.11.2) (2026-03-11)


### Bug Fixes

* improve sidecar_api log clarity — no more exc_info tracebacks for expected fallbacks ([9bb64c2](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/9bb64c2feeb108a07dc03b72ee59ab66f86de318))
* invert cross_midnight health logic — healthy when kintsugi IS healing ([db591d3](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/db591d32d099e4eac30264e3303ebf10fe4bf8b5))
* pre-filter disabled symbols in sidecar gap-fill ([857659f](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/857659fa75bf6f1b1e316c9b86b485c6eb9a84cd))

## [13.11.1](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.11.0...v13.11.1) (2026-03-11)


### Bug Fixes

* make symbol registry tests work with disabled symbols ([cb553d7](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/cb553d79d51b0658403054980a8c82499cf5126b))

# [13.11.0](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.10.0...v13.11.0) (2026-03-11)


### Bug Fixes

* cross-midnight bars no longer clobber stathera_gaps health check ([5d05a14](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/5d05a14a2b312ff410cb6ca06b006421ea553c09))
* day_boundary_exclusion() was hiding 172 real gaps from kintsugi ([#264](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/264)) ([96c5c76](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/96c5c76a55a3df638b8c61773c6b2e77ded9023c))
* enforce symbol registry enabled gate in kintsugi, backfill, detect_gaps ([#264](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/264)) ([a83689a](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/a83689a75bafd09cc51bf58e1eb4da2834334edc))
* heartbeat Telegram respects symbol registry + reduce lock noise ([0512827](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/05128276cb95beba7c8c8c4ffaa916cb5278a6d1))


### Features

* adaptive sleep in kintsugi daemon — skip idle time when shards remain ([441e7c6](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/441e7c6c60057056f2077f5c6f2db7232460099f))

# [13.10.0](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.9.0...v13.10.0) (2026-03-11)


### Bug Fixes

* filter cross-midnight bars in streaming + dead-letter replay ([#264](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/264)) ([ba02338](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/ba023386c8e46e26b9c133bedca48f7db2b082f8)), closes [hi#threshold](https://github.com-terrylica/hi/issues/threshold) [264/#263](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/263)


### Features

* add odb-telemetry skill for production monitoring and diagnostics ([264fed3](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/264fed3a64fbfa13d5b5ccc0922b7880d473c366))

# [13.9.0](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.8.0...v13.9.0) (2026-03-11)


### Bug Fixes

* eliminate cross-midnight bar sources causing Sisyphean kintsugi cascade ([#264](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/264), [#263](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/263)) ([7bf3721](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/7bf3721a521701b4fe37f4e1d1b41269e59462c6))


### Features

* **skill:** add auto-healing guards to odb-deploy-verification ([#261](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/261)) ([7469d31](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/7469d31dd1036cb0b1011ce0385798d3bc7d73c2))

# [13.8.0](https://github.com/terrylica/opendeviationbar-py/compare/v13.7.0...v13.8.0) (2026-03-10)


### Bug Fixes

* allow kintsugi to repair interior intra-day gaps ([#261](https://github.com/terrylica/opendeviationbar-py/issues/261), [#202](https://github.com/terrylica/opendeviationbar-py/issues/202)) ([b26c343](https://github.com/terrylica/opendeviationbar-py/commit/b26c3433df3c7632a1f6baf7682e6a3c63d9fa27))
* **skill:** correct kintsugi_log column names in deploy verification ([df83aee](https://github.com/terrylica/opendeviationbar-py/commit/df83aeef6ce20bb4c08740d41f0ea14b9fc9d041))


### Features

* gap repair acceleration with Puck + Niffler (Issue [#257](https://github.com/terrylica/opendeviationbar-py/issues/257), [#158](https://github.com/terrylica/opendeviationbar-py/issues/158)) ([bf5b2e8](https://github.com/terrylica/opendeviationbar-py/commit/bf5b2e8b49316562fc8acdfa96dbab9b4bec5ac6))

# [13.7.0](https://github.com/terrylica/opendeviationbar-py/compare/v13.6.6...v13.7.0) (2026-03-10)


### Bug Fixes

* prevent sidecar state loss on brief CH blips ([#261](https://github.com/terrylica/opendeviationbar-py/issues/261), [#202](https://github.com/terrylica/opendeviationbar-py/issues/202)) ([bbb53b1](https://github.com/terrylica/opendeviationbar-py/commit/bbb53b14c87f178b043195bd190e837a02f94ac8)), closes [#198](https://github.com/terrylica/opendeviationbar-py/issues/198)


### Features

* add odb-deploy-verification skill (58-point checklist) ([848e46a](https://github.com/terrylica/opendeviationbar-py/commit/848e46afd1710c0b34934569284e45286564c47e))

## [13.6.6](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.6.5...v13.6.6) (2026-03-10)


### Bug Fixes

* resolve circular import in CLICKHOUSE_TRANSIENT_ERRORS ([25368b9](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/25368b914c05ea484d2dfdfc64d3c79ffe42e1df))

## [13.6.5](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.6.4...v13.6.5) (2026-03-10)


### Bug Fixes

* sync workspace dep versions in semantic-release prepareCmd ([6998d47](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/6998d470eab55810463322ecb4e8685335683440))

## [13.6.4](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.6.3...v13.6.4) (2026-03-10)


### Bug Fixes

* wire internal crate deps to workspace SSoT via inheritance ([c46d8bd](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/c46d8bd327044e9ac70fee3c7a01e8117ecfba1f))

## [13.6.3](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.6.2...v13.6.3) (2026-03-10)


### Bug Fixes

* add take_gap_event_watcher mock to all sidecar watchdog tests ([32580cd](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/32580cdea482f69d1a000a22d9bedd616bee6000))

## [13.6.2](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.6.1...v13.6.2) (2026-03-10)


### Bug Fixes

* mock take_gap_event_watcher in watchdog test to prevent JSON serialization error ([a89d488](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/a89d4882c72864d9f70a40d1daffd99905ae8fcc))

## [13.6.1](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.6.0...v13.6.1) (2026-03-10)


### Bug Fixes

* test default watchdog timeout (600s, not 300s) ([cb47d6c](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/cb47d6c9ebb2f37b6784c85d3946709a2073790e))

# [13.6.0](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.5.1...v13.6.0) (2026-03-10)


### Bug Fixes

* **#257 phase 0a:** rate limiter CAS loop, fetch_max, Spot weight=4 for aggTrades ([abac1f8](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/abac1f8dc7abaa9d64f804a6acc25fd4fe4c0492)), closes [#257](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/257)
* **#259:** critical row-index bug in kintsugi, dangling forex test imports ([c9972a5](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/c9972a5cdca5204a958e1cbe61de55380ba6ec76)), closes [#259](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/259)
* **heartbeat+kintsugi:** day-boundary gap classification, today-guard sentinel, human-readable Telegram ([1294131](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/12941312b36e2aca9d3e10c311c87969e9849898))
* pre-release formatting and config test fixes ([95ff444](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/95ff444b62f03e8fa47a09f6356786fb68ee2d37))
* use loguru instead of warnings.warn for invalid TELEGRAM_LOG_LEVEL ([5b25f8e](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/5b25f8e554b13a7571cb6e087300912abe4de0fa))
* validate FLUSH_THRESHOLD env var + add bounded flush tests ([#253](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/253)) ([a06e086](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/a06e08649f5a082046be3dc8732e97f8c86eccf2))


### Features

* **#257 phase 1:** SSE gap_detected event broadcast in sidecar ([acb0d0d](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/acb0d0d787d07fa08248080c52ac83aafd02b5e6)), closes [#257](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/257)
* **#257 phase 2a:** parallel aggTrades fetcher with JoinSet+Semaphore ([78bb30d](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/78bb30dd9776db370dcdd611a79c3f8d79ddb9fb)), closes [#257](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/257)
* **#257 phases 1-2a:** gap detection submodule (event, command, detector) ([f8404a7](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/f8404a7f65778ade75f1fb7bc3d42f522deabf29)), closes [#257](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/257)
* **#257 phases 1,2c:** PyO3 gap bindings (PyGapEventWatcher, fill_gap) ([7080d2a](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/7080d2ad808af2f7223da132e97e21ab849d6b71)), closes [#257](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/257)
* **#257 phases 2-2c:** live engine gap detection + command channel fill_gap() ([b4f9041](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/b4f9041c8d0de1728a01a00ee72876b9c8cd4951)), closes [#257](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/257)
* bounded ClickHouse INSERT — flush every 10K bars during day processing ([#253](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/253)) ([44f4f54](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/44f4f54cb1a8ad99db71705d20b853c6ddfa97c6)), closes [hi#volume](https://github.com-terrylica/hi/issues/volume)

## [13.5.1](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.5.0...v13.5.1) (2026-03-09)


### Bug Fixes

* **release:** fetch and reconcile with remote in preflight ([04aedeb](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/04aedeb7ea8284c482914bb21813353b11da4c5b))

# [13.5.0](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.4.0...v13.5.0) (2026-03-09)


### Features

* add ClickHouse password auth support ([#201](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/201)) ([8a70953](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/8a70953ddff20f8b2e52bef5493f3d283debbd42))
* add OPENDEVIATIONBAR_TELEGRAM_LOG_LEVEL env var ([#243](https://github.com-terrylica/terrylica/opendeviationbar-py/issues/243)) ([9595fa4](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/9595fa433b6c7663a284fca3bea2f48c98e7aa22))
* **monit:** detailed Telegram health reports with UUID and LOUD failure alerts ([87e20e0](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/87e20e0e9e16de4b127a3675c88deede6bfd4509))

# [13.4.0](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.3.0...v13.4.0) (2026-03-09)


### Bug Fixes

* **clickhouse:** crash-safe replace with overlapping DELETE predicate ([9b343b4](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/9b343b493c808623953eb46fb6f4340e98194c20))
* **kintsugi:** cap day-recompute to one day per pass in day-mode Ouroboros ([be30451](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/be304519217e81e39e61c9a4cf86826f6b0c639f))
* **vision:** cache ALL failures in Redis negative cache, not just 404s ([51d2d84](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/51d2d847c4db37a938103d9b6e8f9e1e7b6d2a67))


### Features

* **heartbeat:** deterministic hotfix detection via mtime comparison ([31984ae](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/31984aedb606e41eb0c6d40291541449ce17bce9))
* **kintsugi:** Vision-first data source priority for day-recompute ([d4eaae0](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/d4eaae01e42788030ae7cb27e09bf0767872e973))

# [13.3.0](https://github.com-terrylica/terrylica/opendeviationbar-py/compare/v13.2.0...v13.3.0) (2026-03-09)


### Features

* **issue-256:** add write-time registry gate to ClickHouse layer ([969af12](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/969af12f4c367981eecbd140f834e12faa6d4445))
* **monitoring:** add delta tracking to heartbeat for repair progress visibility ([3457e89](https://github.com-terrylica/terrylica/opendeviationbar-py/commit/3457e89ebc33f98efb98f125fc8fea7a202a85c0))
