# Changelog

## 1.12.3 (2026-03-20)

Full Changelog: [v1.12.2...v1.12.3](https://github.com/moderation-api/sdk-python/compare/v1.12.2...v1.12.3)

### Bug Fixes

* sanitize endpoint path params ([82ab871](https://github.com/moderation-api/sdk-python/commit/82ab8719733bad759fc3e7dc199da0eaa76aca47))


### Chores

* **internal:** tweak CI branches ([405d710](https://github.com/moderation-api/sdk-python/commit/405d7101d6e0490e1a101d185450a2fa46ebd0d6))

## 1.12.2 (2026-03-17)

Full Changelog: [v1.12.1...v1.12.2](https://github.com/moderation-api/sdk-python/compare/v1.12.1...v1.12.2)

### Bug Fixes

* **deps:** bump minimum typing-extensions version ([e38b349](https://github.com/moderation-api/sdk-python/commit/e38b349ffa696a9cf939a7a9ca9d8faf2a82ff89))

## 1.12.1 (2026-03-17)

Full Changelog: [v1.12.0...v1.12.1](https://github.com/moderation-api/sdk-python/compare/v1.12.0...v1.12.1)

### Bug Fixes

* **pydantic:** do not pass `by_alias` unless set ([1cadcd9](https://github.com/moderation-api/sdk-python/commit/1cadcd9418281d551a5285454256c87601826354))

## 1.12.0 (2026-03-16)

Full Changelog: [v1.11.0...v1.12.0](https://github.com/moderation-api/sdk-python/compare/v1.11.0...v1.12.0)

### Features

* **api:** api update ([6907711](https://github.com/moderation-api/sdk-python/commit/6907711c4c3e30391b867862e55fc349a3c2fb09))


### Chores

* **ci:** skip uploading artifacts on stainless-internal branches ([e610021](https://github.com/moderation-api/sdk-python/commit/e6100213a30c4915355288c031b412f945479bc8))


### Refactors

* **types:** use `extra_items` from PEP 728 ([430bfe0](https://github.com/moderation-api/sdk-python/commit/430bfe06ab9314f3f3013bf6928d47a9a450109e))

## 1.11.0 (2026-03-03)

Full Changelog: [v1.10.0...v1.11.0](https://github.com/moderation-api/sdk-python/compare/v1.10.0...v1.11.0)

### Features

* **api:** api update ([bf7013d](https://github.com/moderation-api/sdk-python/commit/bf7013d41dd8bd6fcd346164c751ce25f55f48a8))


### Chores

* **ci:** bump uv version ([c3a8d9d](https://github.com/moderation-api/sdk-python/commit/c3a8d9da2923fc83b47193fa421fa5f377843869))
* **internal:** add request options to SSE classes ([ca09e91](https://github.com/moderation-api/sdk-python/commit/ca09e915f0d2ae9ba8852514563fd9ff76cd2afe))
* **internal:** make `test_proxy_environment_variables` more resilient ([f75a80e](https://github.com/moderation-api/sdk-python/commit/f75a80efb34c4845c555dd883211805b7a4ebe16))
* **internal:** make `test_proxy_environment_variables` more resilient to env ([2b5aaa4](https://github.com/moderation-api/sdk-python/commit/2b5aaa4f2c2a33bf102344d0e843ffa770d8faff))

## 1.10.0 (2026-02-23)

Full Changelog: [v1.9.1...v1.10.0](https://github.com/moderation-api/sdk-python/compare/v1.9.1...v1.10.0)

### Features

* **api:** api update ([cb8b6ab](https://github.com/moderation-api/sdk-python/commit/cb8b6ab428c44825924ae368c8cfea983357b785))

## 1.9.1 (2026-02-20)

Full Changelog: [v1.9.0...v1.9.1](https://github.com/moderation-api/sdk-python/compare/v1.9.0...v1.9.1)

### Chores

* update mock server docs ([1967778](https://github.com/moderation-api/sdk-python/commit/1967778c317634f98c29d59b547fd530d347340d))

## 1.9.0 (2026-02-20)

Full Changelog: [v1.8.0...v1.9.0](https://github.com/moderation-api/sdk-python/compare/v1.8.0...v1.9.0)

### Features

* **api:** api update ([3e62dda](https://github.com/moderation-api/sdk-python/commit/3e62dda30d79c73a9b4fa3b7a202f2d2a518a260))


### Chores

* format all `api.md` files ([5a7c325](https://github.com/moderation-api/sdk-python/commit/5a7c325071957fec9830ac78ca74942fc869ec58))
* **internal:** bump dependencies ([1f203f8](https://github.com/moderation-api/sdk-python/commit/1f203f8daf18535d007d7c3f1246672ab8fea1a9))
* **internal:** fix lint error on Python 3.14 ([784cacf](https://github.com/moderation-api/sdk-python/commit/784cacf3ebe73f8e83bc3e091d1d5ba385a907a7))
* **internal:** remove mock server code ([4e8ce8c](https://github.com/moderation-api/sdk-python/commit/4e8ce8c633cefb04e03fd11e9705517556d00398))

## 1.8.0 (2026-02-06)

Full Changelog: [v1.7.0...v1.8.0](https://github.com/moderation-api/sdk-python/compare/v1.7.0...v1.8.0)

### Features

* **api:** api update ([75cdb26](https://github.com/moderation-api/sdk-python/commit/75cdb2662e2bd833ef4edad65da9d4f06c8e2473))

## 1.7.0 (2026-01-30)

Full Changelog: [v1.6.0...v1.7.0](https://github.com/moderation-api/sdk-python/compare/v1.6.0...v1.7.0)

### Features

* **client:** add custom JSON encoder for extended type support ([1e50ad0](https://github.com/moderation-api/sdk-python/commit/1e50ad07fe7df9764d1718fcec4daea811ccf45e))

## 1.6.0 (2026-01-28)

Full Changelog: [v1.5.0...v1.6.0](https://github.com/moderation-api/sdk-python/compare/v1.5.0...v1.6.0)

### Features

* **api:** api update ([5a4b3f8](https://github.com/moderation-api/sdk-python/commit/5a4b3f8e67363ef200fd2013f49b655a0ba6a864))

## 1.5.0 (2026-01-28)

Full Changelog: [v1.4.0...v1.5.0](https://github.com/moderation-api/sdk-python/compare/v1.4.0...v1.5.0)

### Features

* **api:** api update ([f169692](https://github.com/moderation-api/sdk-python/commit/f1696924142a6c6ab846a6d2186986000e767f16))


### Chores

* **ci:** upgrade `actions/github-script` ([2b6a3c8](https://github.com/moderation-api/sdk-python/commit/2b6a3c800e24d79e9e33856f7c30131d7c6b43f6))
* **internal:** update `actions/checkout` version ([bb501b1](https://github.com/moderation-api/sdk-python/commit/bb501b1f60a8a374c8357993e67251e436c161fa))

## 1.4.0 (2026-01-14)

Full Changelog: [v1.3.0...v1.4.0](https://github.com/moderation-api/sdk-python/compare/v1.3.0...v1.4.0)

### Features

* **client:** add support for binary request streaming ([38dd553](https://github.com/moderation-api/sdk-python/commit/38dd55321d26a3cdb65918e3eb56dbeeafbe5dde))

## 1.3.0 (2026-01-10)

Full Changelog: [v1.2.0...v1.3.0](https://github.com/moderation-api/sdk-python/compare/v1.2.0...v1.3.0)

### Features

* **api:** api update ([d5460a2](https://github.com/moderation-api/sdk-python/commit/d5460a20acbde158441a86bd68d89816f11ae30b))

## 1.2.0 (2026-01-02)

Full Changelog: [v1.1.0...v1.2.0](https://github.com/moderation-api/sdk-python/compare/v1.1.0...v1.2.0)

### Features

* **api:** api update ([15074fd](https://github.com/moderation-api/sdk-python/commit/15074fd461baf06418a47910229566c2064c7e11))


### Chores

* **internal:** add `--fix` argument to lint script ([893326c](https://github.com/moderation-api/sdk-python/commit/893326cd41958716559755c3da9a967a453db4b9))

## 1.1.0 (2025-12-18)

Full Changelog: [v1.0.2...v1.1.0](https://github.com/moderation-api/sdk-python/compare/v1.0.2...v1.1.0)

### Features

* **api:** api update ([6c44a32](https://github.com/moderation-api/sdk-python/commit/6c44a32976994920a0caceca0c77e59b8aca5219))


### Bug Fixes

* use async_to_httpx_files in patch method ([e533ec4](https://github.com/moderation-api/sdk-python/commit/e533ec49c12007c031a7660997d6b23658dd6cc5))


### Chores

* **internal:** add missing files argument to base client ([0b9d250](https://github.com/moderation-api/sdk-python/commit/0b9d250739e8d607cc70e1aba126f46ef830d23b))
* speedup initial import ([5ff9c69](https://github.com/moderation-api/sdk-python/commit/5ff9c698d4acb2c3c312711ef11632bc3ad754d7))


### Refactors

* **internal:** switch from rye to uv ([4f4101f](https://github.com/moderation-api/sdk-python/commit/4f4101fd1680a9e9929821fa50242bfe871b6bd9))

## 1.0.2 (2025-12-09)

Full Changelog: [v1.0.1...v1.0.2](https://github.com/moderation-api/sdk-python/compare/v1.0.1...v1.0.2)

### Chores

* add missing docstrings ([02bdf8f](https://github.com/moderation-api/sdk-python/commit/02bdf8ffdef877fdb38df5c8215f241c0af2936e))

## 1.0.1 (2025-12-09)

Full Changelog: [v1.0.0...v1.0.1](https://github.com/moderation-api/sdk-python/compare/v1.0.0...v1.0.1)

### Bug Fixes

* **types:** allow pyright to infer TypedDict types within SequenceNotStr ([36ea40a](https://github.com/moderation-api/sdk-python/commit/36ea40ac2b242cd53c8cd915befe809b65a13215))


### Chores

* update SDK settings ([1876999](https://github.com/moderation-api/sdk-python/commit/18769999773649b22146674569e8ba3ddf88f876))

## 1.0.0 (2025-12-06)

Full Changelog: [v0.0.1...v1.0.0](https://github.com/moderation-api/sdk-python/compare/v0.0.1...v1.0.0)

### Features

* **api:** api update ([bc91d96](https://github.com/moderation-api/sdk-python/commit/bc91d96e25700bf7c01fa62b7f22fa11880313dc))
* **api:** api update ([a9968a7](https://github.com/moderation-api/sdk-python/commit/a9968a7a8e5ff58d2fd87633b4afff658523cf5a))
* **api:** api update ([4823b5e](https://github.com/moderation-api/sdk-python/commit/4823b5e2fbd811e2f4eb08e3181d4674d03a59b3))
* **api:** api update ([ad12a65](https://github.com/moderation-api/sdk-python/commit/ad12a65a09be5b7eaf14f770c1c4edb321db6640))
* **api:** manual updates ([50ee715](https://github.com/moderation-api/sdk-python/commit/50ee7151e5ae1e22a2d8017e3f32a7816145a1ac))
* **api:** manual updates ([c8e371a](https://github.com/moderation-api/sdk-python/commit/c8e371ae1be439008fbfb10cfe65d7798aef5eb6))
* **api:** manual updates ([f017cbc](https://github.com/moderation-api/sdk-python/commit/f017cbcec45065e9e6a2f2bfa66cd1e5fa22b851))
* **api:** manual updates ([c49725c](https://github.com/moderation-api/sdk-python/commit/c49725cb034edec7411733f2f63a688940573cac))
* **api:** manual updates ([fa2efc8](https://github.com/moderation-api/sdk-python/commit/fa2efc8b09c8da26be5ec99c97f6ed11bdfc727b))
* **api:** manual updates ([2957153](https://github.com/moderation-api/sdk-python/commit/29571536bb27811f9bd573829884bc36beb8a61b))
* **api:** manual updates ([3ad868f](https://github.com/moderation-api/sdk-python/commit/3ad868f45c737db62e7486299e07027b608047d1))
* **api:** manual updates ([75eae97](https://github.com/moderation-api/sdk-python/commit/75eae9712e59c4a7e8554f83f3ec2a4a55b10e46))
* **api:** manual updates ([2ea195a](https://github.com/moderation-api/sdk-python/commit/2ea195a89e76808ba1957802a6394ea4bf20b039))
* **api:** removed deprecated moderate endpoints ([6c5dd93](https://github.com/moderation-api/sdk-python/commit/6c5dd93fbe80619e6e4b270dfd4624b713ba9c15))


### Bug Fixes

* ensure streams are always closed ([b4d4449](https://github.com/moderation-api/sdk-python/commit/b4d44494343f4925353071967649a414c05ae369))


### Chores

* configure new SDK language ([74c5185](https://github.com/moderation-api/sdk-python/commit/74c5185ae751945b7b24839e406f7c371c8d0b34))
* **deps:** mypy 1.18.1 has a regression, pin to 1.17 ([bbf694f](https://github.com/moderation-api/sdk-python/commit/bbf694f626644c1349960516a152a46bd8af1489))
* **docs:** use environment variables for authentication in code snippets ([166f1cf](https://github.com/moderation-api/sdk-python/commit/166f1cf82be98f8fe92607b3983144af07788da9))
* update lockfile ([ba4d9b9](https://github.com/moderation-api/sdk-python/commit/ba4d9b97fdc0d4a6a34058edc9d0b8dde4c8d5ba))
* update SDK settings ([60af1e1](https://github.com/moderation-api/sdk-python/commit/60af1e123350c2cbacd9f05320048539d28b2cc4))
