"""Amazon Product Advertising API wrapper for Python.

A simple Python wrapper for the last version of the Amazon Product Advertising API.
"""

from __future__ import annotations

import time
from typing import TYPE_CHECKING, Any

from . import models
from .errors import InvalidArgument
from .helpers import arguments, requests
from .helpers.generators import get_list_chunks
from .helpers.items import sort_items
from .sdk.api.default_api import DefaultApi

if TYPE_CHECKING:
    from .models.regions import CountryCode


class AmazonApi:
    """Provides methods to get information from Amazon using your API credentials.

    Args:
        key (``str``): Your API key.
        secret (``str``): Your API secret.
        tag (``str``): Your affiliate tracking id, used to create the affiliate link.
        country (``CountryCode``): Country code for your affiliate account.
            Use values from ``models.Country``, e.g. ``Country.ES``.
        throttling (``float``, optional): Wait time in seconds between API calls. Use it
            to avoid reaching Amazon limits. Defaults to 1 second.

    Raises:
        ``InvalidArgumentException``

    """

    def __init__(
        self,
        key: str,
        secret: str,
        tag: str,
        country: CountryCode,
        throttling: float = 1,
    ) -> None:
        """Initialize the Amazon API client with the provided credentials."""
        self._key = key
        self._secret = secret
        self._last_query_time = time.time() - throttling
        self.tag = tag
        self.country = country
        self.throttling = float(throttling)

        try:
            self._host = "webservices.amazon." + models.regions.DOMAINS[country]
            self.region = models.regions.REGIONS[country]
            self.marketplace = "www.amazon." + models.regions.DOMAINS[country]
        except KeyError as error:
            msg = "Country code is not correct"
            raise InvalidArgument(msg) from error

        self.api = DefaultApi(key, secret, self._host, self.region)

    def get_items(
        self,
        items: str | list[str],
        condition: models.Condition = None,
        merchant: models.Merchant = None,
        currency_of_preference: str | None = None,
        languages_of_preference: list[str] | None = None,
        include_unavailable: bool = False,
        **kwargs: Any,
    ) -> list[models.Item]:
        """Get items information from Amazon.

        Args:
            items (``str`` | ``list[str]``): One or more items, using ASIN or product
                URL. Items in string format should be separated by commas.
            condition (``models.Condition``, optional): Filters offers by condition
                type. Defaults to Any.
            merchant (``models.Merchant``, optional): Filters search results to return
                items having at least an offer sold by target merchant. Defaults to All.
            currency_of_preference (``str``, optional): Currency of preference in which
                the prices information should be returned. Expected currency code format
                is ISO 4217.
            languages_of_preference (``list[str]``, optional): Languages in order of
                preference in which the item information should be returned.
            include_unavailable (``bool``, optional): The returned list includes not
                available items. Not available items have the ASIN and item_info equals
                None. Defaults to False.
            kwargs (``dict``, optional): Other arguments to be passed to the Amazon API.

        Returns:
            ``list[models.Item]``: A list of items with Amazon information.

        Raises:
            ``InvalidArgumentException``
            ``MalformedRequestException``
            ``ApiRequestException``
            ``ItemsNotFoundException``

        """
        kwargs.update(
            {
                "condition": condition,
                "merchant": merchant,
                "currency_of_preference": currency_of_preference,
                "languages_of_preference": languages_of_preference,
            }
        )

        items_ids = arguments.get_items_ids(items)
        results = []

        for asin_chunk in get_list_chunks(list(set(items_ids)), chunk_size=10):
            request = requests.get_items_request(self, asin_chunk, **kwargs)
            self._throttle()
            items_response = requests.get_items_response(self, request)
            results.extend(items_response)

        return sort_items(results, items_ids, include_unavailable=include_unavailable)

    def search_items(
        self,  # NOSONAR
        item_count: int | None = None,
        item_page: int | None = None,
        actor: str | None = None,
        artist: str | None = None,
        author: str | None = None,
        brand: str | None = None,
        keywords: str | None = None,
        title: str | None = None,
        availability: models.Availability = None,
        browse_node_id: str | None = None,
        condition: models.Condition = None,
        currency_of_preference: str | None = None,
        delivery_flags: list[str] | None = None,
        languages_of_preference: list[str] | None = None,
        merchant: models.Merchant = None,
        max_price: int | None = None,
        min_price: int | None = None,
        min_saving_percent: int | None = None,
        min_reviews_rating: int | None = None,
        search_index: str | None = None,
        sort_by: models.SortBy = None,
        **kwargs: Any,
    ) -> models.SearchResult:
        """Search for items on Amazon based on a search query.

        At least one of the following parameters should be specified: ``keywords``,
        ``actor``, ``artist``, ``author``, ``brand``, ``title``, ``browse_node_id``
        or ``search_index``.

        Args:
            item_count (``int``, optional): Number of items returned. Should be between
                1 and 10. Defaults to 10.
            item_page (``int``, optional): The specific page of items to be returned
                from the available results. Should be between 1 and 10. Defaults to 1.
            actor (``str``, optional): Actor name associated with the item.
            artist (``str``, optional): Artist name associated with the item.
            author (``str``, optional): Author name associated with the item.
            brand (``str``, optional): Brand name associated with the item.
            keywords (``str``, optional): A word or phrase that describes an item.
            title (``str``, optional): Title associated with the item.
            availability (``models.Availability``, optional): Filters available items on
                Amazon. Defaults to Available.
            browse_node_id (``str``, optional): A unique ID assigned by Amazon that
                identifies a product category or subcategory.
            condition (``models.Condition``, optional): Filters offers by condition
                type. Defaults to Any.
            currency_of_preference (``str``, optional): Currency of preference in which
                the prices information should be returned. Expected currency code format
                is ISO 4217.
            delivery_flags (``list[str]``): Filters items which satisfy a certain
                delivery program.
            languages_of_preference (``list[str]``, optional): Languages in order of
                preference in which the item information should be returned.
            merchant (``models.Merchant``, optional): Filters search results to return
                items having at least an offer sold by target merchant. Defaults to All.
            max_price (``int``, optional): Filters search results to items with at least
                one offer price below the specified value. Prices appear in lowest
                currency denomination. For example, $31.41 should be passed as 3141 or
                28.00€ should be 2800.
            min_price (``int``, optional): Filters search results to items with at least
                one offer price above the specified value. Prices appear in lowest
                currency denomination. For example, $31.41 should be passed as 3141 or
                28.00€ should be 2800.
            min_saving_percent (``int``, optional): Filters search results to items with
                at least one offer having saving percentage above the specified value.
                Value should be positive integer less than 100.
            min_reviews_rating (``int``, optional): Filters search results to items with
                customer review ratings above specified value. Value should be positive
                integer less than 5.
            search_index (``str``, optional): Indicates the product category to search.
                Defaults to All.
            sort_by (``models.SortBy``, optional): The way in which items are sorted.
            kwargs (``dict``, optional): Other arguments to be passed to the Amazon API.

        Returns:
            ``models.SearchResult``: The search result containing the list of items.

        Raises:
            ``InvalidArgumentException``
            ``MalformedRequestException``
            ``ApiRequestException``
            ``ItemsNotFoundException``

        """
        kwargs.update(
            {
                "item_count": item_count,
                "item_page": item_page,
                "actor": actor,
                "artist": artist,
                "author": author,
                "brand": brand,
                "keywords": keywords,
                "title": title,
                "availability": availability,
                "browse_node_id": browse_node_id,
                "condition": condition,
                "currency_of_preference": currency_of_preference,
                "delivery_flags": delivery_flags,
                "languages_of_preference": languages_of_preference,
                "max_price": max_price,
                "merchant": merchant,
                "min_price": min_price,
                "min_reviews_rating": min_reviews_rating,
                "min_saving_percent": min_saving_percent,
                "search_index": search_index,
                "sort_by": sort_by,
            }
        )

        arguments.check_search_args(**kwargs)
        request = requests.get_search_items_request(self, **kwargs)
        self._throttle()
        return requests.get_search_items_response(self, request)

    def get_variations(
        self,
        asin: str,
        variation_count: int | None = None,
        variation_page: int | None = None,
        condition: models.Condition = None,
        currency_of_preference: str | None = None,
        languages_of_preference: list[str] | None = None,
        merchant: models.Merchant = None,
        **kwargs: Any,
    ) -> models.VariationsResult:
        """Return a set of items that are the same product but differ by theme.

        Items can differ by size, color, or other variation attributes.
        A variation is a child ASIN.

        Args:
            asin (``str``): One item, using ASIN or product URL.
            variation_count (``int``, optional): Number of items returned. Should be
                between 1 and 10. Defaults to 10.
            variation_page (``int``, optional): The specific page of items to be
                returned from the available results. Should be between 1 and 10.
                Defaults to 1.
            condition (``models.Condition``, optional): Filters offers by condition
                type. Defaults to Any.
            currency_of_preference (``str``, optional): Currency of preference in which
                the prices information should be returned. Expected currency code format
                is ISO 4217.
            languages_of_preference (``list[str]``, optional): Languages in order of
                preference in which the item information should be returned.
            merchant (``models.Merchant``, optional): Filters search results to return
                items having at least an offer sold by target merchant. Defaults to All.
            kwargs (``dict``, optional): Other arguments to be passed to the Amazon API.

        Returns:
            ``models.VariationsResult``: Variations result containing the items list.

        Raises:
            ``InvalidArgumentException``
            ``MalformedRequestException``
            ``ApiRequestException``
            ``ItemsNotFoundException``

        """
        asin = arguments.get_items_ids(asin)[0]

        kwargs.update(
            {
                "asin": asin,
                "variation_count": variation_count,
                "variation_page": variation_page,
                "condition": condition,
                "currency_of_preference": currency_of_preference,
                "languages_of_preference": languages_of_preference,
                "merchant": merchant,
            }
        )

        arguments.check_variations_args(**kwargs)
        request = requests.get_variations_request(self, **kwargs)
        self._throttle()
        return requests.get_variations_response(self, request)

    def get_browse_nodes(
        self,
        browse_node_ids: list[str],
        languages_of_preference: list[str] | None = None,
        **kwargs: Any,
    ) -> list[models.BrowseNode]:
        """Return the specified browse node's information.

        Information includes name, children, and ancestors.

        Args:
            browse_node_ids (``list[str]``): List of browse node ids. A browse node id
                is a unique ID assigned by Amazon that identifies a product
                category/sub-category.
            languages_of_preference (``list[str]``, optional): Languages in order of
                preference in which the item information should be returned.
            kwargs (``dict``, optional): Other arguments to be passed to the Amazon API.

        Returns:
            ``list[models.BrowseNode]``: A list of browse nodes.

        Raises:
            ``InvalidArgumentException``
            ``MalformedRequestException``
            ``ApiRequestException``
            ``ItemsNotFoundException``

        """
        kwargs.update(
            {
                "browse_node_ids": browse_node_ids,
                "languages_of_preference": languages_of_preference,
            }
        )

        arguments.check_browse_nodes_args(**kwargs)
        request = requests.get_browse_nodes_request(self, **kwargs)
        self._throttle()
        return requests.get_browse_nodes_response(self, request)

    def _throttle(self) -> None:
        """Wait for the throttling interval to elapse since the last API call."""
        wait_time = self.throttling - (time.time() - self._last_query_time)
        if wait_time > 0:
            time.sleep(wait_time)
        self._last_query_time = time.time()
