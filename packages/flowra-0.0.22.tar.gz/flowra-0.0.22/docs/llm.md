# Working with LLMs

Flowra provides a provider-agnostic LLM interface. This guide covers provider
setup, streaming, structured output, extended thinking, prompt caching, and
tool search.

For the basics (making a call, using ChatAgent), see
[Getting Started](getting-started.md).

## Providers

Flowra ships three providers. Each lives in its own module to avoid pulling in
unnecessary dependencies.

### AnthropicVertexProvider (Claude via Vertex AI)

```bash
pip install flowra[anthropic]
```

```python
from flowra.llm.providers.anthropic_vertex import AnthropicVertexProvider

# From credentials:
async with AnthropicVertexProvider(
    project="my-gcp-project",
    location="us-east5",
    credentials="<base64-encoded service account JSON>",
) as provider:
    ...

# Or with a pre-configured client:
from anthropic import AsyncAnthropicVertex
async with AnthropicVertexProvider(client=my_client) as provider:
    ...
```

### OpenAIProvider (OpenAI and compatible APIs)

```bash
pip install flowra[openai]
```

```python
from flowra.llm.providers.openai import OpenAIProvider

async with OpenAIProvider(api_key="sk-...") as provider:
    ...

# Custom base URL (e.g. Inception AI, local LLM servers):
async with OpenAIProvider(
    api_key="sk-...",
    base_url="https://api.inceptionlabs.ai/v1",
) as provider:
    ...
```

### GoogleVertexProvider (Gemini via Vertex AI)

```bash
pip install flowra[google]
```

```python
from flowra.llm.providers.google_vertex import GoogleVertexProvider

async with GoogleVertexProvider(
    project="my-gcp-project",
    location="us-east5",
    credentials="<base64-encoded service account JSON>",
) as provider:
    ...
```

## Making calls

All providers implement the same interface:

```python
from flowra.llm import LLMRequest, TextBlock, UserMessage

request = LLMRequest(
    model="claude-sonnet-4-5@20250929",
    messages=[UserMessage(blocks=[TextBlock(text="Hello!")])],
    max_tokens=256,
)

response = await provider.call(request)
print(response.message.blocks[0].text)
print(response.usage.input_tokens, response.usage.output_tokens)
print(response.usage.cost_usd)  # estimated cost
```

## Streaming

Stream text token by token. `ContentComplete` at the end carries the full
response:

```python
from flowra.llm import TextDelta, ThinkingDelta, ContentComplete

async for event in provider.stream(request):
    match event:
        case TextDelta(text=text):
            print(text, end="", flush=True)
        case ThinkingDelta(text=text):
            print(f"[thinking] {text}", end="")
        case ContentComplete(response=response):
            print()
            # response.usage, response.stop_reason, etc.
```

When using `ChatAgent` or `ToolLoopAgent`, you don't call `stream()` directly —
register a `TextDeltaEvent` handler and the agent switches to streaming
automatically (see [Getting Started — Streaming](getting-started.md#streaming)).

## Structured output (JSON schema)

Force the LLM to return JSON matching a schema:

```python
response = await provider.call(
    LLMRequest(
        model="claude-sonnet-4-5@20250929",
        messages=[UserMessage(blocks=[TextBlock(text="Three European capitals")])],
        json_schema={
            "type": "object",
            "properties": {"cities": {"type": "array", "items": {"type": "string"}}},
            "required": ["cities"],
        },
        max_tokens=256,
    )
)
```

How each provider handles it:

- **Anthropic** — prompt injection + validation + retries (up to `max_schema_retries`).
  Returns `StopReason.SCHEMA_VALIDATION_FAILED` if all retries fail.
- **OpenAI** — native `response_format` with strict mode.
- **Google** — native `response_schema` with JSON mime type.

## Extended thinking

Enable the model's reasoning/thinking mode for complex tasks.

### Anthropic (Claude)

```python
response = await provider.call(
    LLMRequest(
        model="claude-sonnet-4-5@20250929",
        messages=[UserMessage(blocks=[TextBlock(text="Solve step by step...")])],
        max_tokens=8192,
        additional_config={"thinking_budget_tokens": 4000},
    )
)

for block in response.message.blocks:
    if isinstance(block, ThinkingBlock):
        print(f"[thinking] {block.text}")
    elif isinstance(block, TextBlock):
        print(block.text)
```

### Google (Gemini)

```python
# Gemini 3 — thinking level
additional_config={"thinking_level": "medium"}

# Gemini 2.5 — thinking budget
additional_config={"thinking_budget": 4096}
```

When using `ChatAgent`/`ToolLoopAgent`, pass `additional_config` through
`LLMConfig`:

```python
from flowra.lib import LLMConfig

config = LLMConfig(
    model="claude-sonnet-4-5@20250929",
    max_tokens=8192,
    additional_config={"thinking_budget_tokens": 4000},
)
```

## Prompt caching (Anthropic)

Anthropic supports caching parts of the prompt to reduce cost and latency on
repeated calls. Flowra provides composable hook bundles that set cache
breakpoints automatically.

### Quick setup

```python
from flowra.agent import HookSubscription
from flowra.lib.anthropic import ANTHROPIC_CACHE_ALL

hooks = HookSubscription()
ANTHROPIC_CACHE_ALL.install(hooks)
# pass hooks to AgentRuntime via services={HookSubscription: hooks, ...}
```

`ANTHROPIC_CACHE_ALL` caches system messages, tools, and the last conversation
message — covers the most common case.

### Available presets

| Preset                    | Caches                                                                                       |
|---------------------------|----------------------------------------------------------------------------------------------|
| `ANTHROPIC_CACHE_ALL`     | System messages + tools + last message                                                       |
| `ANTHROPIC_CACHE_SESSION` | System messages + tools + last history message (excludes current turn). Requires `ChatAgent` |

### Individual bundles

For fine-grained control, install individual bundles:

| Bundle                                     | What it caches                             |
|--------------------------------------------|--------------------------------------------|
| `AnthropicCacheAllSystemMessages`          | Last block of the last system message      |
| `AnthropicCacheNonTransientSystemMessages` | Last non-transient system block            |
| `AnthropicCacheAllTools`                   | Last tool definition                       |
| `AnthropicCacheAllMessages`                | Last block of the last message             |
| `AnthropicCacheNonTransientMessages`       | Last non-transient message block           |
| `AnthropicCacheHistoryMessages`            | Last history message (before current turn) |

### The `transient` hint

Blocks and messages can be marked `transient=True` to indicate non-permanent
content. This affects two things:

1. **Caching** — "NonTransient" bundles skip transient blocks when placing cache
   breakpoints, preventing cache invalidation from injected context that changes
   on every call.
2. **Session history** — `ChatAgent` automatically strips transient messages when
   saving conversation history. Transient content (e.g. injected context,
   ephemeral reminders) won't accumulate across turns.

```python
from flowra.llm import TextBlock, UserMessage

# Transient block — won't be cached by NonTransient bundles:
TextBlock(text="Current time: 12:00", transient=True)

# Transient message — won't be saved to session history:
UserMessage(blocks=[TextBlock(text="[system reminder]")], transient=True)
```

### Custom caching logic

Subscribe to `PrepareLLMRequestEvent` and modify the request directly:

```python
from flowra.lib.tool_loop import PrepareLLMRequestEvent

def my_cache_hook(event):
    request = event.data.request
    # Set cache_control on specific blocks via extra:
    # block.extra = {"cache_control": {"type": "ephemeral"}}
    event.data.request = modified_request

hooks.on(PrepareLLMRequestEvent, my_cache_hook)
```

## Tool search (Anthropic)

When an agent has many tools (50+), tool definitions consume a large chunk of
the context, and the LLM's ability to pick the right tool degrades.
`AnthropicToolSearch` solves this with deferred tool loading — tools are sent
with only names and descriptions, and a server-side search tool discovers full
definitions on demand.

```python
from flowra.lib.anthropic import AnthropicToolSearch

ext = AnthropicToolSearch()
ext.install(hooks)
```

This reduces token usage by ~85% while maintaining tool selection accuracy.

### Parameters

| Parameter   | Default                  | Description                                           |
|-------------|--------------------------|-------------------------------------------------------|
| `variant`   | `ToolSearchVariant.BM25` | `BM25` (natural language) or `REGEX` (regex patterns) |
| `predicate` | `None`                   | Optional `(Tool) -> bool` — only defer matching tools |

```python
from flowra.lib.anthropic import AnthropicToolSearch, ToolSearchVariant

# Defer only admin tools:
AnthropicToolSearch(predicate=lambda t: t.name.startswith("admin_")).install(hooks)

# Use regex variant:
AnthropicToolSearch(variant=ToolSearchVariant.REGEX).install(hooks)
```

### How it works

1. Before each LLM call, selected tools are marked with `defer_loading: true`
   and a search tool is added to the request
2. Claude receives only tool names and descriptions — no full schemas
3. When Claude needs a tool, it calls the search tool with a query
4. The Anthropic API returns full definitions of matching tools
5. Claude invokes the discovered tools normally — transparent to the agent

## Cost tracking

Every `LLMResponse` includes token usage and estimated cost:

```python
response = await provider.call(request)

usage = response.usage
print(usage.input_tokens)                  # input tokens (excludes cached)
print(usage.output_tokens)                 # output tokens
print(usage.cache_read_input_tokens)       # tokens read from cache
print(usage.cache_creation_input_tokens)   # tokens written to cache
print(usage.cost_usd)                      # total estimated cost in USD
```

`Usage` supports addition — accumulate across multiple calls:

```python
total_usage = response1.usage + response2.usage
print(total_usage.cost_usd)
```
