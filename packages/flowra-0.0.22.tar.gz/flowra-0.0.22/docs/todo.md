# TODO


## Interrupted reason

- **Rethink `Interrupted.reason` design.** The `reason` field was removed in 0.0.22
  because it was never populated by the engine (always `None`). The original idea —
  letting agents know *why* they were interrupted (timeout, user cancel, escalation) —
  is sound, but needs a proper design: should the engine set it? Should
  `InterruptToken` carry a reason? How does it propagate through the tree?
  Revisit when there's a concrete use case that needs it.


## Capabilities (dynamic modes)

- **Capability packs — dynamically loadable modes.** A `Capability` bundles a system prompt
  fragment, a set of tools, and optionally an LLM config override. Capabilities can be
  activated/deactivated during the agent's tool loop (by the agent itself via a special tool,
  or programmatically via `ToolLoopAgentContext`). On each iteration, `ToolLoopAgent` assembles
  the active set: merges system prompts from all active capabilities, unions their tool sets,
  applies LLM config overrides. Similar to how Claude Code switches between planning/coding/etc.
  Building blocks already exist (`ConfigValue` callables, `allowed_tools`/`denied_tools`,
  `on_start_iteration`, `ToolLoopAgentContext`), but there's no unified abstraction tying
  them together. A capability could also carry hooks (e.g. a "verbose" capability that adds
  logging hooks when activated). Pairs well with composable hooks.



## Documentation benchmark suite

- A series of tasks given to a coding agent that has access only to documentation
  (no source code). Each task is a self-contained challenge: write a race agent
  (two LLMs, first wins via WhenAny + timeout), build a fan-out/fan-in pipeline,
  create a tool with service injection, wire up hooks with ExecutionContext, etc.
  For each task we define: the prompt, the documentation provided, and the expected
  outcome (working code that passes a test or matches a reference implementation).
  Run the suite, compare results against reference, identify where the agent
  struggles — those are doc gaps or API ergonomics issues. Fix docs/API, re-run,
  track improvement.


## Voice

- **Voice demo (streaming pipeline).** Example `voice_chat.py` — STT (microphone) → agent →
  `on_text_delta` → TTS (speaker). Leverages existing streaming infrastructure. Start with
  simple pipeline, explore STT options: Google Cloud Speech-to-Text (available in GCP),
  OpenAI Whisper API, or local `faster-whisper` for free experimentation.

- **Smart voice pipeline with context-aware re-recognition.** For domain-specific scenarios
  (e.g. payments in Anna Money): STT produces multiple hypotheses with confidence scores.
  Agent receives all variants as structured input ("user said via voice, variants: ...").
  Agent uses domain context (frequent recipients, recent transactions) to select the best
  variant. If uncertain — requests re-recognition with hints (e.g. "typical recipients:
  Маша, Петя, Сбербанк"), STT re-processes the same audio with boosted vocabulary.
  Ties into capabilities (recognize topic → load relevant capability with context),
  agent-as-tool (STT as a callable sub-agent), and hooks (`on_user_message` enriches
  voice input with domain context).


---

# Someday


- **Lazy fork / copy-on-write scope.** Currently `RuntimeScope.fork()` copies all scalars
  and append-only lists eagerly. Make it lazy: child reads from parent until first write,
  copies only the specific field on `set()`/`append()`.

- **Frozen list.** Immutable list in state (like Scalar, but for lists). Can be created
  cheaply from `append_only` (slice without copying) or from another frozen list.

- **Guardrails hooks package.** Ready-made hook set for content filtering and PII protection.
  Input guardrail (`UserMessageEvent`) checks/blocks user messages, output guardrail
  (`ResultMessageEvent`) checks/redacts LLM responses. Need integration with a moderation
  backend (Bedrock Guardrails, OpenAI Moderation API, or custom).

- **Local LLM usage guide.** Document how to use `OpenAIProvider` with local LLM servers
  (Ollama, LM Studio, vLLM). Show `base_url` configuration, recommend models for tool calling.

- **A2A (Agent-to-Agent) protocol support.** Thin adapter exposing any Flowra agent as an
  A2A-compatible HTTP server with Agent Card and SSE streaming.

- **Accurate cost estimation with full context.** Context length tiers, per-provider pricing,
  thinking tokens, cache creation TTL tiers. See `docs/research/pricing_complexity.md`.

- **Anna LLM Proxy provider.** Separate private repository (`anna-flowra` or similar)
  with `LLMProxyProvider` for Anna's internal LLM Proxy service.

- **Custom string tags for serialized types.** Allow explicit string tags via decorator
  or class attribute, falling back to `__qualname__` if not set. Decouples persistence
  format from Python naming.
