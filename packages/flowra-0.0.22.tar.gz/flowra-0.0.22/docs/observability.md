# Observability

Flowra provides two observability mechanisms: **events** (point-in-time
notifications) and **spans** (start/end pairs for operations). Both are
delivered via `HookSubscription`. On top of these primitives, Flowra ships
integrations with MLflow and OpenTelemetry.

## Events

Events are point-in-time notifications emitted during agent execution. Register
handlers via `HookSubscription.on()`:

```python
from flowra.agent import HookSubscription
from flowra.lib.observability import TextDeltaEvent

hooks = HookSubscription()
hooks.on(TextDeltaEvent, lambda e: print(e.data.text, end="", flush=True))
```

Some events are **mutable** — your handler can modify the event data to influence
execution. For example, `UserMessageEvent` lets you rewrite messages before the
LLM sees them.

### Pre-built events

Events from `ToolLoopAgent` (and `ChatAgent`, which uses it internally):

| Event                    | When                     | Mutable?                                      |
|--------------------------|--------------------------|-----------------------------------------------|
| `UserMessageEvent`       | User message received    | `messages`                                    |
| `MessageAcceptedEvent`   | After message accepted   | —                                             |
| `StartIterationEvent`    | Each tool loop iteration | `additional_messages`                         |
| `PrepareLLMRequestEvent` | Before LLM call          | `request`                                     |
| `BeforeToolCallEvent`    | Before tool execution    | `tool_use`                                    |
| `AfterToolCallEvent`     | After tool execution     | `result`, `error_kind`, `additional_messages` |
| `ResultMessageEvent`     | LLM finished (END_TURN)  | `continue_messages`                           |

Streaming events (from `flowra.lib.observability`):

| Event                | When                         |
|----------------------|------------------------------|
| `TextDeltaEvent`     | Each streamed text chunk     |
| `ThinkingDeltaEvent` | Each streamed thinking chunk |

Import lifecycle events from `flowra.lib.tool_loop`, streaming events from
`flowra.lib.observability`.

### Event context

Every event is wrapped in `Event[T]` with a `context` field — the execution
path from root to the agent that emitted the event:

```python
from flowra.agent import Event
from flowra.lib.tool_loop import BeforeToolCallEvent

def on_before_tool(event: Event[BeforeToolCallEvent]) -> None:
    agent_path = event.context.frame.agent.path
    tool_name = event.data.tool_use.name
    print(f"[{agent_path}] calling {tool_name}")

hooks.on(BeforeToolCallEvent, on_before_tool)
```

Use `event.context.find_spec(SpecType)` to walk the execution stack and find
the spec of a parent agent — useful for identifying which model or session is
active.

## Spans

Spans track operations with a start and end. Register handlers via
`HookSubscription.on_span()`. The handler receives the span at open time and
returns a callback that's invoked at close time:

```python
from flowra.agent import AgentSpan, HookSubscription

hooks = HookSubscription()

def on_agent(span: AgentSpan):
    print(f"▶ agent started: {span.agent_info.path}")
    def on_end(error: BaseException | None = None):
        print(f"◀ agent ended: {span.agent_info.path} result={span.result}")
    return on_end

hooks.on_span(AgentSpan, on_agent)
```

### Span types

Engine-level spans (from `flowra.agent`):

| Span        | When            | Fields                                 |
|-------------|-----------------|----------------------------------------|
| `AgentSpan` | Agent lifecycle | `agent_info`, `spec`, `result`         |
| `StepSpan`  | Step invocation | `agent_info`, `step`, `spec`, `result` |

LLM/tool spans (from `flowra.lib.observability`):

| Span           | When           | Fields                             |
|----------------|----------------|------------------------------------|
| `LLMCallSpan`  | LLM call       | `request`, `response`              |
| `ToolCallSpan` | Tool execution | `tool_use`, `result`, `error_kind` |

Spans are mutable — fields like `response` and `result` are `None` at open time
and populated before close.

### Example: console span tree

```python
from flowra.agent import AgentSpan, StepSpan, HookSubscription
from flowra.lib.observability import LLMCallSpan, ToolCallSpan

hooks = HookSubscription()
indent = 0

def on_agent(span: AgentSpan):
    global indent
    print("  " * indent + f"▶ agent:{span.agent_info.path}")
    indent += 1
    def on_end(error=None):
        global indent
        indent -= 1
        print("  " * indent + f"◀ agent:{span.agent_info.path}")
    return on_end

def on_llm(span: LLMCallSpan):
    print("  " * indent + f"🤖 llm_call ({span.request.model})")
    def on_end(error=None):
        if span.response:
            u = span.response.usage
            print("  " * indent + f"   → {u.input_tokens}in/{u.output_tokens}out")
    return on_end

def on_tool(span: ToolCallSpan):
    print("  " * indent + f"🔧 tool:{span.tool_use.name}")
    def on_end(error=None):
        if span.result:
            print("  " * indent + f"   → {span.result.content[:80]}")
    return on_end

hooks.on_span(AgentSpan, on_agent)
hooks.on_span(LLMCallSpan, on_llm)
hooks.on_span(ToolCallSpan, on_tool)
```

## MLflow integration

Maps spans to MLflow traces for a visual UI with token usage, cost tracking,
and session grouping.

**Install:** `pip install flowra[mlflow]`

```python
from flowra.agent import HookSubscription
from flowra.ext.mlflow import install_mlflow_tracing

hooks = HookSubscription()
install_mlflow_tracing(
    hooks,
    experiment_name="my-experiment",
    session_id="chat-session-123",   # groups multi-turn traces together
)

# pass hooks to AgentRuntime via services={HookSubscription: hooks, ...}
```

### What gets traced

| Span           | MLflow type | Default           |
|----------------|-------------|-------------------|
| `AgentSpan`    | AGENT       | on                |
| `StepSpan`     | CHAIN       | **off** (verbose) |
| `LLMCallSpan`  | CHAT_MODEL  | on                |
| `ToolCallSpan` | TOOL        | on                |

LLM spans use OpenAI-compatible message format — MLflow renders them with the
structured chat UI.

### Viewing traces

```bash
uv run mlflow ui --port 5050
# Open http://localhost:5050
```

### Parameters

```python
install_mlflow_tracing(
    hooks,
    experiment_name="flowra",
    session_id="chat-123",       # or a callable: lambda: current_session_id
    trace_agents=True,
    trace_steps=False,           # usually too verbose
    trace_llm_calls=True,
    trace_tool_calls=True,
)
```

## OpenTelemetry integration

Maps spans to OTel spans with [GenAI semantic conventions](https://opentelemetry.io/docs/specs/semconv/gen-ai/).
Works with any OTel backend — Jaeger, Grafana Tempo, Datadog, Honeycomb, etc.

**Install:** `pip install flowra[otel]`

```python
from flowra.agent import HookSubscription
from flowra.ext.otel import install_otel_tracing

hooks = HookSubscription()
install_otel_tracing(hooks)
```

You configure your own `TracerProvider` and exporter — Flowra just creates spans.

### Setup example (Jaeger)

```bash
docker run -d --name jaeger -p 16686:16686 -p 4317:4317 jaegertracing/all-in-one
```

```python
from opentelemetry import trace
from opentelemetry.sdk.resources import Resource
from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export import BatchSpanProcessor
from opentelemetry.exporter.otlp.proto.grpc.trace_exporter import OTLPSpanExporter

provider = TracerProvider(resource=Resource.create({"service.name": "my-service"}))
provider.add_span_processor(BatchSpanProcessor(OTLPSpanExporter(endpoint="http://localhost:4317")))
trace.set_tracer_provider(provider)
```

### GenAI attributes

OTel spans include standard GenAI attributes:

- `gen_ai.request.model`, `gen_ai.request.temperature`, `gen_ai.request.max_tokens`
- `gen_ai.usage.input_tokens`, `gen_ai.usage.output_tokens`
- `gen_ai.usage.cost` — total cost in USD
- `gen_ai.agent.name` — agent path (e.g. `app/chat/tool_loop`)
- `gen_ai.tool.name`, `gen_ai.tool.call.id`
- `flowra.tool.error_kind` — error classification

### Parameters

```python
install_otel_tracing(
    hooks,
    tracer_name="flowra",
    trace_agents=True,
    trace_steps=True,
    trace_llm_calls=True,
    trace_tool_calls=True,
    capture_content=False,       # tool arguments/results (off for privacy)
    session_id="my-session",     # gen_ai.conversation.id
)
```

## Choosing the right tracing setup

| Setup                   | Best for                                         | What you get                                          |
|-------------------------|--------------------------------------------------|-------------------------------------------------------|
| MLflow only             | ML experiments, prompt debugging                 | Rich LLM UI, chat preview, cost tracking, sessions    |
| OTel only               | Production services with existing OTel           | Standard GenAI spans in Jaeger/Grafana/Datadog        |
| Both independently      | Full picture, two UIs                            | MLflow for LLM details + OTel for distributed tracing |
| MLflow with OTel export | MLflow UI + OTel backend, single instrumentation | MLflow spans forwarded to OTel collector              |

Decision tree:

```
Do you use OTel in your service already?
├── No → MLflow only (simplest, best LLM UI)
└── Yes
    ├── Do you need MLflow's LLM-specific UI?
    │   ├── No → OTel only (standard, lightweight)
    │   └── Yes
    │       ├── Do you want one trace ID across both?
    │       │   ├── Yes → MLflow with OTel export
    │       │   └── No → Both independently
    │       └── Do you need standard GenAI semconv attributes?
    │           ├── Yes → Both independently (OTel uses gen_ai.*)
    │           └── No → MLflow with OTel export (simpler)
```

### Both independently

Two independent span trees — MLflow for LLM-specific analysis, OTel for
distributed tracing. Traces are not linked (different trace IDs).

```python
hooks = HookSubscription()
install_mlflow_tracing(hooks, experiment_name="my-experiment")
install_otel_tracing(hooks)
```

### MLflow with OTel export

MLflow is built on OTel internally. With dual export enabled, MLflow sends
spans to both backends — no `install_otel_tracing` needed. Single trace ID
shared between both.

Trade-off: MLflow uses its own attribute names (`mlflow.chat.tokenUsage`, etc.)
rather than `gen_ai.*`, so OTel backends won't recognize them as standard GenAI
spans.

```python
hooks = HookSubscription()
install_mlflow_tracing(hooks, experiment_name="my-experiment")
```

```bash
pip install flowra[mlflow] opentelemetry-exporter-otlp

# Enable dual export:
export OTEL_EXPORTER_OTLP_TRACES_ENDPOINT="http://localhost:4317"
export MLFLOW_TRACE_ENABLE_OTLP_DUAL_EXPORT="true"
export OTEL_SERVICE_NAME="my-service"

# Optional: merge into your service's trace tree (e.g. FastAPI → flowra → LLM):
export MLFLOW_USE_DEFAULT_TRACER_PROVIDER="false"
```
