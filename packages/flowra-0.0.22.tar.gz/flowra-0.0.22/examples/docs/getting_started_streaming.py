"""Getting Started: Streaming.

Corresponds to docs/getting-started.md "Streaming" section.

Usage:
    make docs-example name=getting_started_streaming
"""

import asyncio

from examples.model_registry import DEFAULT_MODEL, create_router
from flowra.agent import AgentRuntime, HookSubscription
from flowra.lib import LLMConfig
from flowra.lib.chat import ChatAgent, ChatConfig, ChatResult, ChatSpec
from flowra.lib.observability import TextDeltaEvent
from flowra.llm import LLMProvider, SystemMessage, TextBlock
from flowra.tools import ToolRegistry


async def main() -> None:
    router = create_router()

    async with await ToolRegistry.create([]) as registry:
        config = ChatConfig(
            llm_config=LLMConfig(model=DEFAULT_MODEL),
            system=[SystemMessage(blocks=[TextBlock(text="You are a helpful assistant.")])],
        )

        hooks = HookSubscription()
        hooks.on(TextDeltaEvent, lambda e: print(e.data.text, end="", flush=True))

        runtime = AgentRuntime(
            agents={"chat": ChatAgent},
            services={
                LLMProvider: router,
                ToolRegistry: registry,
                ChatConfig: config,
                HookSubscription: hooks,
            },
        )

        result = await runtime.run(
            agent=ChatAgent,
            spec=ChatSpec(user_message="Tell me a short joke."),
        )

        print()  # newline after streaming
        if isinstance(result, ChatResult) and result.usage:
            print(f"\n({result.usage.input_tokens} in, {result.usage.output_tokens} out)")


if __name__ == "__main__":
    asyncio.run(main())
