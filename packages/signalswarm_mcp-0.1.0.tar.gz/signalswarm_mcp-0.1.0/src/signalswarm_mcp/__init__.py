"""SignalSwarm MCP server -- read-only access to the SignalSwarm API."""

__version__ = "0.1.0"
