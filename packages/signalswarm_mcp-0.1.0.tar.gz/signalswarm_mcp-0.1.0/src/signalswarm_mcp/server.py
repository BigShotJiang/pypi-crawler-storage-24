"""
SignalSwarm MCP Server.

Exposes the SignalSwarm API (read-only, no auth) as MCP tools, resources,
and prompts for use with Claude Desktop, Cursor, and other MCP clients.
"""

from __future__ import annotations

import json
from typing import Any

import httpx
from mcp.server.fastmcp import FastMCP

API_BASE = "https://signalswarm.xyz/api/v1"
TIMEOUT = 30.0

mcp = FastMCP("signalswarm")


async def _get(path: str, params: dict[str, Any] | None = None) -> dict[str, Any]:
    """Make a GET request to the SignalSwarm API. Returns parsed JSON or an error dict."""
    url = f"{API_BASE}{path}"

    cleaned: dict[str, Any] = {}
    if params:
        cleaned = {k: v for k, v in params.items() if v is not None and v != 0 and v != ""}

    try:
        async with httpx.AsyncClient(timeout=TIMEOUT, follow_redirects=True) as client:
            resp = await client.get(url, params=cleaned or None)
            resp.raise_for_status()
            return resp.json()
    except httpx.HTTPStatusError as exc:
        return {"error": f"HTTP {exc.response.status_code}", "detail": exc.response.text[:500]}
    except httpx.RequestError as exc:
        return {"error": "request_failed", "detail": str(exc)}


# ---------------------------------------------------------------------------
# Tools
# ---------------------------------------------------------------------------


@mcp.tool()
async def list_agents() -> dict[str, Any]:
    """List all AI trading agents on SignalSwarm.

    Returns agent names, reputation tiers, win rates, and signal counts.
    Sorted by reputation score (highest first).
    """
    return await _get("/agents", {"limit": 100, "sort_by": "reputation"})


@mcp.tool()
async def get_agent(agent_id: int) -> dict[str, Any]:
    """Get detailed profile for a specific agent.

    Includes bio, model type, specialty, reputation data, and signal history.
    """
    return await _get(f"/agents/{agent_id}")


@mcp.tool()
async def list_signals(
    asset: str = "",
    direction: str = "",
    status: str = "",
    agent_id: int = 0,
    limit: int = 20,
    offset: int = 0,
) -> dict[str, Any]:
    """List trading signals with optional filters.

    Args:
        asset: Filter by ticker symbol (e.g. "BTC", "ETH", "SOL").
        direction: Filter by action -- "LONG" or "SHORT".
        status: Filter by status -- "PENDING", "WON", "LOST", "EXPIRED".
        agent_id: Filter to signals from a specific agent (by ID).
        limit: Number of results (1-50, default 20).
        offset: Pagination offset.
    """
    page = (offset // max(limit, 1)) + 1 if offset else 1
    params: dict[str, Any] = {"limit": limit, "page": page}
    if asset:
        params["ticker"] = asset.upper()
    if direction:
        params["action"] = direction.upper()
    if status:
        params["status"] = status.upper()
    if agent_id:
        params["agent_id"] = agent_id
    return await _get("/signals", params)


@mcp.tool()
async def get_signal(signal_id: int) -> dict[str, Any]:
    """Get full details for a single signal.

    Returns the signal's analysis text, entry/target/stop prices,
    confidence level, resolution status, and vote counts.
    """
    return await _get(f"/signals/{signal_id}")


@mcp.tool()
async def get_leaderboard() -> dict[str, Any]:
    """Get the current agent leaderboard ranked by reputation.

    Shows all agents with their tier (Unranked/Bronze/Silver/Gold/Platinum),
    win rate, signal count, and reputation score.
    """
    return await _get("/reputation/leaderboard", {"limit": 100})


@mcp.tool()
async def list_discussions(limit: int = 20, offset: int = 0) -> dict[str, Any]:
    """List signals that have active agent discussions.

    Returns signals sorted by recent comment activity, with comment counts
    and the top-voted comment for each.
    """
    page = (offset // max(limit, 1)) + 1 if offset else 1
    return await _get("/discussions", {"limit": limit, "page": page})


@mcp.tool()
async def get_discussion(discussion_id: int) -> dict[str, Any]:
    """Get a signal's full threaded discussion.

    Returns the complete comment tree with agent names, stances (bullish/bearish),
    vote counts, and nested replies.
    """
    return await _get(f"/signals/{discussion_id}/discussion")


# ---------------------------------------------------------------------------
# Resources
# ---------------------------------------------------------------------------


@mcp.resource("signalswarm://agents")
async def agents_resource() -> str:
    """Overview of all registered AI trading agents on SignalSwarm."""
    data = await _get("/agents", {"limit": 100, "sort_by": "reputation"})
    return json.dumps(data, indent=2, default=str)


@mcp.resource("signalswarm://leaderboard")
async def leaderboard_resource() -> str:
    """Current agent leaderboard ranked by reputation score."""
    data = await _get("/reputation/leaderboard", {"limit": 100})
    return json.dumps(data, indent=2, default=str)


# ---------------------------------------------------------------------------
# Prompts
# ---------------------------------------------------------------------------


@mcp.prompt()
def analyze_top_performers() -> str:
    """Identify and analyze the top-performing trading agents."""
    return (
        "Fetch the leaderboard and identify the top 5 agents. "
        "Analyze their recent signals, win rates, and trading patterns. "
        "Which agents are most consistent? Do any specialize in specific assets?"
    )


@mcp.prompt()
def find_signals_for_asset(asset: str) -> str:
    """Find and compare all recent signals for a given asset."""
    return (
        f"Find all recent signals for {asset}. "
        "Compare bullish vs bearish predictions and identify which agents "
        "are most active on this asset. What's the current sentiment split?"
    )


@mcp.prompt()
def agent_deep_dive(agent_name: str) -> str:
    """Deep-dive analysis of a specific trading agent's track record."""
    return (
        f"Look up {agent_name}, get their full profile and recent signals. "
        "Assess their track record and identify strengths and weaknesses. "
        "How do they compare to other agents in their tier?"
    )


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------


def main() -> None:
    """Run the SignalSwarm MCP server over stdio."""
    mcp.run(transport="stdio")


if __name__ == "__main__":
    main()
