# ============================
# sqlite.py — SQLite (pickle BLOB) backend
# ============================
from __future__ import annotations

import os
import sqlite3
import pickle
from typing import Any, Dict, Iterator, List, Optional

from .backend import StorageBackend

# -----------------------------
# SQLite (pickle BLOB) backend
# -----------------------------
class SQLiteStorage(StorageBackend):
    """SQLite-based storage, pickling objects into a BLOB."""

    def __init__(self, db_path: str):
        dir_path = os.path.dirname(db_path)
        if dir_path:
            os.makedirs(dir_path, exist_ok=True)
        self.conn = sqlite3.connect(db_path, check_same_thread=False)
        self._init_schema()

    def close(self):
        self.conn.close()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()

    def _init_schema(self) -> None:
        cur = self.conn.cursor()
        cur.execute(
            """
            CREATE TABLE IF NOT EXISTS containers (
                id   INTEGER PRIMARY KEY AUTOINCREMENT,
                data BLOB NOT NULL
            );
            """
        )
        self.conn.commit()

    def add(self, obj: Any, metadata: Optional[Dict[str, Any]] = None) -> int:
        blob = pickle.dumps(obj)
        cur = self.conn.cursor()
        cur.execute("INSERT INTO containers (data) VALUES (?);", (blob,))
        self.conn.commit()
        return int(cur.lastrowid)

    def get(self, obj_id: Optional[int] = None):
        if obj_id is None:
            # Return a lightweight proxy of all objects (loads on iteration)
            return _LazySQLiteView(self)
        cur = self.conn.cursor()
        cur.execute("SELECT data FROM containers WHERE id = ?;", (obj_id,))
        row = cur.fetchone()
        if row is None:
            raise KeyError(f"No container with id {obj_id}")
        return pickle.loads(row[0])

    def remove(self, obj_id: int | Sequence[int]) -> None:
        if isinstance(obj_id, (int, np.integer)):
            ids = [int(obj_id)]
        else:
            ids = [int(x) for x in obj_id]
            
        if not ids:
            return

        cur = self.conn.cursor()
        with self.conn:  # Single transaction
            if len(ids) == 1:
                cur.execute("DELETE FROM containers WHERE id = ?;", (ids[0],))
            else:
                # Chunk to avoid SQLite parameter limits (~999)
                for i in range(0, len(ids), 900):
                    chunk = ids[i:i+900]
                    q = "DELETE FROM containers WHERE id IN (%s);" % ",".join("?" for _ in chunk)
                    cur.execute(q, chunk)

    def list_ids(self) -> List[int]:
        cur = self.conn.cursor()
        cur.execute("SELECT id FROM containers ORDER BY id ASC;")
        return [int(row[0]) for row in cur.fetchall()]

    def count(self) -> int:
        cur = self.conn.cursor()
        cur.execute("SELECT COUNT(*) FROM containers;")
        return int(cur.fetchone()[0])

    def clear(self) -> None:
        cur = self.conn.cursor()
        cur.execute("DELETE FROM containers;")
        self.conn.commit()

    def iter_ids(self, batch_size: Optional[int] = 1000) -> Iterator[int]:
        cur = self.conn.cursor()
        last = 0
        while True:
            if batch_size:
                cur.execute(
                    "SELECT id FROM containers WHERE id > ? ORDER BY id ASC LIMIT ?;",
                    (last, batch_size),
                )
            else:
                cur.execute(
                    "SELECT id FROM containers WHERE id > ? ORDER BY id ASC;",
                    (last,),
                )
            rows = cur.fetchall()
            if not rows:
                break
            for (cid,) in rows:
                yield int(cid)
            last = int(rows[-1][0])

    def add_many(self, objs: List[Any], metadata: Optional[List[Dict[str, Any]]] = None) -> List[int]:
        """
        Add multiple objects in a single transaction.
        """
        if not objs:
            return []
        
        ids = []
        cur = self.conn.cursor()
        
        # Use simple iteration inside a transaction.
        # This is strictly slower than executemany but reliably returns IDs
        # and is still orders of magnitude faster than commit-per-insert.
        try:
            # We can use the connection context manager if isolation_level is not autocommit, 
            # or explicit BEGIN/COMMIT. 
            # To be safe with existing code logic:
            self.conn.execute("BEGIN")
            
            for obj in objs:
                blob = pickle.dumps(obj)
                cur.execute("INSERT INTO containers (data) VALUES (?);", (blob,))
                ids.append(cur.lastrowid)
                
            self.conn.commit()
        except:
            self.conn.rollback()
            raise

        return ids
    
    def get_all_natoms(self) -> np.ndarray:
        """Return a 1D array of atom counts for all objects, ordered by ID. (Slower as it unpickles objects)"""
        import numpy as np
        counts = []
        for cid in self.iter_ids():
            obj = self.get(cid)
            try:
                apm = getattr(obj, "AtomPositionManager", None)
                counts.append(int(apm.atomCount) if apm is not None else 0)
            except Exception:
                counts.append(0)
        return np.array(counts, dtype=float)

class _LazySQLiteView:
    """Lazy sequence-like view over all objects in SQLiteStorage."""

    def __init__(self, store: SQLiteStorage):
        self._s = store

    def __len__(self) -> int:
        return self._s.count()

    def __iter__(self):
        for cid in self._s.iter_ids():
            yield self._s.get(cid)

    def __getitem__(self, i):
        if isinstance(i, slice):
            ids = self._s.list_ids()[i]
            return [self._s.get(cid) for cid in ids]
        else:
            cid = self._s.list_ids()[i]
            return self._s.get(cid)

