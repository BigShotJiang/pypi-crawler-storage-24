"""Domain ontology registrations."""
