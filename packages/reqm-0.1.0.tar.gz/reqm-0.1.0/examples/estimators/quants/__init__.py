# Estimator Quant subclasses.
