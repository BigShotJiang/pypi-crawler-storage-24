from setuptools import setup, find_packages

setup(
     name="pynorch",
     version="0.4",
     packages=find_packages(),
     install_requires=[],
     entry_points={
          "console_scripts":[
               "pynorch-hello = pynorch:hello"
          ]
     }
)