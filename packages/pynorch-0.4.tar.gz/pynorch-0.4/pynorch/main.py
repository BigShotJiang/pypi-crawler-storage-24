def hello():
    print("Hello user what are you doing every thing is ok !!!")

def prac1():
    print("""
     import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

df = sns.load_dataset('iris')

print(df.head())
print(df.tail())

print(help(df))
print("Information:")
df.info()

print("Description")
df.describe()

print("Null values: \n", df.isnull().sum())
df.hist(figsize=(10,6))
plt.show()


#Hisogram:
df.hist(figsize=(10,6))
plt.show()

#Boxplot
sns.boxplot(data=df)
plt.show()


#Countplot
sns.countplot(x='species', data=df)
plt.show()


#Scatter Plot
plt.scatter(df['sepal_length'], df['sepal_width'])
plt.xlabel('Sepal Length')
plt.ylabel('Sepal Width')
plt.show()

#Pairplot
sns.pairplot(df, hue='species')
plt.show()

#Scatter Multiple
plt.figure(figsize=(10,6))
plt.scatter(df['petal_length'], df['sepal_length'], label='Sepal Length')
plt.scatter(df['petal_length'], df['sepal_width'], label='Sepal Width')
plt.scatter(df['petal_length'], df['petal_width'], label='Petal Width')

plt.xlabel('Petal Length')
plt.ylabel('Values of Other Attributes')
plt.title('Scatter Multiple Plot (Iris Dataset)')
plt.legend()
plt.show()

#Scatter Matrix
from pandas.plotting import scatter_matrix
plt.figure(figsize=(10,8))
scatter_matrix(df.iloc[:, :4], figsize=(10,8), diagonal='hist')
plt.show()

#Parallel Coordinates plot
from pandas.plotting import parallel_coordinates

plt.figure(figsize=(10,6))
parallel_coordinates(df, 'species')
plt.title('Parallel Coordinates Plot - Iris Dataset')
plt.show()

#Deviation Chart (from mean)
mean_vals = df.iloc[:, :4].mean()

plt.figure(figsize=(10,6))
plt.plot(df.iloc[:, :4] - mean_vals)
plt.title('Deviation Chart - Deviation from Mean')
plt.xlabel('Record Index')
plt.ylabel('Deviation')
plt.show()


#Andrews Curve
from pandas.plotting import andrews_curves

plt.figure(figsize=(10,6))
andrews_curves(df, 'species')
plt.title('Andrews Curves - Iris Dataset')
plt.show()""")
    
def decision_tree_using_iris_dataset():
    print("""
     import pandas as pd
import numpy as np
from sklearn.tree import DecisionTreeClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, classification_report

from sklearn.datasets import load_iris

iris = load_iris()
X = iris.data
y = iris.target

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42)
dt_model = DecisionTreeClassifier(criterion="gini", max_depth=3)
dt_model.fit(X_train, y_train)
y_pred = dt_model.predict(X_test)
print(y_pred)

accuracy = accuracy_score(y_test, y_pred)
print("Accuracy:", accuracy)

print(classification_report(y_test, y_pred))

from sklearn.tree import plot_tree
import matplotlib.pyplot as plt

plt.figure(figsize=(12,8))
plot_tree(dt_model, feature_names=iris.feature_names,
          class_names=iris.target_names, filled=True)
plt.show()

# Create decision tree model on mtcars dataset
import pandas as pd
import numpy as np
from sklearn.tree import DecisionTreeClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, classification_report

mtcars = pd.read_csv("mtcars.csv")
mtcars.head()

mtcars = mtcars.drop(columns=['model'])
X = mtcars.drop('am', axis=1)
y = mtcars['am']


X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42)
dt_model = DecisionTreeClassifier(criterion="gini",max_depth=3)
dt_model.fit(X_train, y_train)
y_pred = dt_model.predict(X_test)

accuracy = accuracy_score(y_test, y_pred)
print("Accuracy:", accuracy)

print(classification_report(y_test, y_pred))


from sklearn.tree import plot_tree
import matplotlib.pyplot as plt

plt.figure(figsize=(14,8))
plot_tree(
    dt_model,
    feature_names=X.columns,
    class_names=["Automatic", "Manual"],
    filled=True
)
plt.show()""")
    
def KMeans_Clustering_on_Iris_Dataset():
    print("""
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.datasets import load_iris
from sklearn.cluster import KMeans

iris = load_iris()
X = iris.data

k = 3

kmeans = KMeans(n_clusters=3, random_state=0)
kmeans.fit(X)

labels = kmeans.labels_
centroids = kmeans.cluster_centers_
print(labels)
print(centroids)

plt.scatter(X[:,2], X[:,3], c=labels)
plt.scatter(centroids[:,2], centroids[:,3], marker='X')
plt.xlabel("Petal Length")
plt.ylabel("Petal Width")
plt.title("K-Means Clustering on Iris Dataset")
plt.show()

# DBSCAN using Iris Dataset
import numpy as np
import matplotlib.pyplot as plt
from sklearn.datasets import load_iris
from sklearn.cluster import DBSCAN
from sklearn.preprocessing import StandardScaler

iris = load_iris()
X = iris.data

scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

dbscan = DBSCAN(eps=0.6, min_samples=5)

labels = dbscan.fit_predict(X_scaled)

print(np.unique(labels))

plt.scatter(X_scaled[:, 0], X_scaled[:, 1], c=labels)
plt.xlabel("Sepal Length")
plt.ylabel("Sepal Width")
plt.title("DBSCAN Clustering on Iris Dataset")
plt.show()""")
    
