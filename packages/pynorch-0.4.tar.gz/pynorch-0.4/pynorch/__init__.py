from .main import hello
from .main import prac1
from .main import decision_tree_using_iris_dataset
from .main import KMeans_Clustering_on_Iris_Dataset
