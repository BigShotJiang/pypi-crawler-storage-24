# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class TopPathSummary:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'path': 'str',
        'value': 'int'
    }

    attribute_map = {
        'path': 'path',
        'value': 'value'
    }

    def __init__(self, path=None, value=None):
        r"""TopPathSummary

        The model defined in huaweicloud sdk

        :param path: top100 path访问路径
        :type path: str
        :param value: top100path访问次数
        :type value: int
        """
        
        

        self._path = None
        self._value = None
        self.discriminator = None

        if path is not None:
            self.path = path
        if value is not None:
            self.value = value

    @property
    def path(self):
        r"""Gets the path of this TopPathSummary.

        top100 path访问路径

        :return: The path of this TopPathSummary.
        :rtype: str
        """
        return self._path

    @path.setter
    def path(self, path):
        r"""Sets the path of this TopPathSummary.

        top100 path访问路径

        :param path: The path of this TopPathSummary.
        :type path: str
        """
        self._path = path

    @property
    def value(self):
        r"""Gets the value of this TopPathSummary.

        top100path访问次数

        :return: The value of this TopPathSummary.
        :rtype: int
        """
        return self._value

    @value.setter
    def value(self, value):
        r"""Sets the value of this TopPathSummary.

        top100path访问次数

        :param value: The value of this TopPathSummary.
        :type value: int
        """
        self._value = value

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, TopPathSummary):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
