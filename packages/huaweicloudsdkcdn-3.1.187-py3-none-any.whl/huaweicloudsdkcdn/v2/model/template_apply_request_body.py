# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class TemplateApplyRequestBody:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'resources': 'str'
    }

    attribute_map = {
        'resources': 'resources'
    }

    def __init__(self, resources=None):
        r"""TemplateApplyRequestBody

        The model defined in huaweicloud sdk

        :param resources: **参数解释：** 域名列表，多个域名使用逗号分隔 **约束限制：** 不涉及 **取值范围：** 单次最多应用50个域名 **默认取值：** 不涉及
        :type resources: str
        """
        
        

        self._resources = None
        self.discriminator = None

        if resources is not None:
            self.resources = resources

    @property
    def resources(self):
        r"""Gets the resources of this TemplateApplyRequestBody.

        **参数解释：** 域名列表，多个域名使用逗号分隔 **约束限制：** 不涉及 **取值范围：** 单次最多应用50个域名 **默认取值：** 不涉及

        :return: The resources of this TemplateApplyRequestBody.
        :rtype: str
        """
        return self._resources

    @resources.setter
    def resources(self, resources):
        r"""Sets the resources of this TemplateApplyRequestBody.

        **参数解释：** 域名列表，多个域名使用逗号分隔 **约束限制：** 不涉及 **取值范围：** 单次最多应用50个域名 **默认取值：** 不涉及

        :param resources: The resources of this TemplateApplyRequestBody.
        :type resources: str
        """
        self._resources = resources

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, TemplateApplyRequestBody):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
