# coding: utf-8

from huaweicloudsdkcore.sdk_response import SdkResponse
from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class ShowDomainItemLocationDetailsResponse(SdkResponse):

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'domain_item_location_details': 'DomainItemLocationDetails'
    }

    attribute_map = {
        'domain_item_location_details': 'domain_item_location_details'
    }

    def __init__(self, domain_item_location_details=None):
        r"""ShowDomainItemLocationDetailsResponse

        The model defined in huaweicloud sdk

        :param domain_item_location_details: 
        :type domain_item_location_details: :class:`huaweicloudsdkcdn.v1.DomainItemLocationDetails`
        """
        
        super().__init__()

        self._domain_item_location_details = None
        self.discriminator = None

        if domain_item_location_details is not None:
            self.domain_item_location_details = domain_item_location_details

    @property
    def domain_item_location_details(self):
        r"""Gets the domain_item_location_details of this ShowDomainItemLocationDetailsResponse.

        :return: The domain_item_location_details of this ShowDomainItemLocationDetailsResponse.
        :rtype: :class:`huaweicloudsdkcdn.v1.DomainItemLocationDetails`
        """
        return self._domain_item_location_details

    @domain_item_location_details.setter
    def domain_item_location_details(self, domain_item_location_details):
        r"""Sets the domain_item_location_details of this ShowDomainItemLocationDetailsResponse.

        :param domain_item_location_details: The domain_item_location_details of this ShowDomainItemLocationDetailsResponse.
        :type domain_item_location_details: :class:`huaweicloudsdkcdn.v1.DomainItemLocationDetails`
        """
        self._domain_item_location_details = domain_item_location_details

    def to_dict(self):
        import warnings
        warnings.warn("ShowDomainItemLocationDetailsResponse.to_dict() is deprecated and no longer maintained, "
                      "use to_json_object() to get the response content.", DeprecationWarning)
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, ShowDomainItemLocationDetailsResponse):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
