"""Paper CLI command group."""
