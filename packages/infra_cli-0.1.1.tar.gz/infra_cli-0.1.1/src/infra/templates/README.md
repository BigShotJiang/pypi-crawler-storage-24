# Configuration Templates

This directory contains example configuration snippets and starter templates for various plugins.

## 📂 Available Templates

- **Ansible**: `ansible/` contains `ansible.cfg` and `inventory.ini`.
- **AWS SSO**: `aws_sso/config.ini` contains sample profile blocks.
- **Packer**: `packer/packer.pkrvars.hcl` contains example build variables.
- **Pulumi**: `pulumi/pulumi.env` shows recommended environment variables.
- **Terragrunt**: `terragrunt/terragrunt.hcl` provides a starter remote-state pattern.
- **Setup**: `setup/setup.conf` is a helper configuration for the `setup` plugin.

## 🛠 How to Use

1. **Manual Copy**: Copy individual files to your `~/.infra/` directory.
2. **Merging**: Merge relevant values into your existing configuration files.
3. **AWS Profiles**: For AWS SSO, copy the profile blocks into `~/.aws/config`.

> [!IMPORTANT]
> **Security First**: Never commit secrets (API keys, passwords, tokens) to these files. Use environment variables, OS keychains, or a dedicated secret manager.
