# Terragrunt configuration example
# Official docs: https://terragrunt.gruntwork.io/docs/
# Best practice: use a root-level terragrunt.hcl to configure remote state + common settings.

include {
  path = find_in_parent_folders()
}

locals {
  region = "us-west-2"
}

remote_state {
  backend = "s3"
  config = {
    bucket = "my-terraform-state-bucket"
    key    = "envs/${get_env("TG_ENV", "dev")}/terraform.tfstate"
    region = local.region
    encrypt = true
  }
}
