# Packer variable file example (.pkrvars.hcl)
# Official docs: https://www.packer.io/docs
# Best practice: keep provider/region/ami vars in a separate vars file and reference via `-var-file`.

aws_region   = "us-west-2"
source_ami   = "ami-0abcdef1234567890"
instance_type = "t3.micro"
ssh_username = "ec2-user"
ssh_key_name = "my-ssh-key"
vpc_id       = "vpc-0123456789abcdef0"
subnet_id    = "subnet-0123456789abcdef0"

# Optional metadata tags applied to the built AMI / instance used during build
tags = {
	Name = "packer-build-example"
	Owner = "devops-team"
}

# Recommended: template-driven AMI name (packer can expand timestamp)
ami_name = "my-image-{{timestamp}}"
