# Ansible Role: Common

This role handles the baseline setup for development environments on macOS and Ubuntu. It installs essential CLI tools, GUI applications (casks), and configures the shell environment.

## Setup with ansible

```bash
    ansible-playbook -i inventory.ini setup.yml
```

## Setup Manully

### ~~Install [Development Tools](https://developer.apple.com/download/) (Optional)~~

Please **skip this** if you will install Homebrew as it will install Development Tools.

```bash
    xcode-select --install

# OR (if you prefer command line install)

    sudo touch /tmp/.com.apple.dt.CommandLineTools.installondemand.in-progress
    PROD=$(softwareupdate -l | grep "\\*.*Command Line" | tail -n 1 | sed 's/^[^C]* //')
    sudo softwareupdate -i "$PROD" --verbose --agree-to-license
```


### Install [Homebrew](https://brew.sh/) (Required)

```bash
    /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
```

### Install [google-chrome](https://formulae.brew.sh/cask/google-chrome) (Recommended)

```bash
    brew install --cask google-chrome
```

### Install [Iterm2](https://iterm2.com/) (Recommended)

```bash
    brew install --cask iterm2
```

### Install useful tools (Recommended)

```bash
    brew install tree tldr wget mtr tcpdump jq yq dig dog zoxide direnv shellcheck mtux
```

### Install & Setup [ohmyzsh](https://ohmyz.sh/)  (Recommended)

```bash
# Install ohmyzsh
    sh -c "$(curl -fsSL https://raw.githubusercontent.com/ohmyzsh/ohmyzsh/master/tools/install.sh)"

# Clone Theme powerlevel10k & setup via p10k
    git clone --depth=1 https://github.com/romkatv/powerlevel10k.git ${ZSH_CUSTOM:-~/.oh-my-zsh/custom}/themes/powerlevel10k
    git clone --depth=1 https://github.com/romkatv/powerlevel10k.git ${ZSH_CUSTOM:-$HOME/.oh-my-zsh/custom}/themes/powerlevel10k
    ln -s ${ZSH_CUSTOM:-~/.oh-my-zsh/custom}/themes/powerlevel10k/powerlevel10k.zsh-theme ${ZSH_CUSTOM:-~/.oh-my-zsh/custom}/themes/powerlevel10k.zsh-theme

    sed -i '' 's#^ZSH_THEME#\#&#' ~/.zshrc
    sed -i '' '/^#ZSH_THEME/a\
ZSH_THEME="powerlevel10k"\
' ~/.zshrc
    source ~/.zshrc
    p10k configure

# Install & Setup ohmyzsh Plugins
    brew install zsh-autosuggestions
    brew install zsh-syntax-highlighting
    brew install autojump

    [ -f ~/.zshrc.default ] || cp -pv ~/.zshrc.default
    cat >> ~/.zshrc <<EOF
$(echo '' || echo 'insert a new blank line')
## ohyzsh Plugins | Added at \$(date +%F_%F%z)
source \$(brew --prefix)/share/zsh-autosuggestions/zsh-autosuggestions.zsh
source \$(brew --prefix)/share/zsh-syntax-highlighting/zsh-syntax-highlighting.zsh
source  /usr/local/etc/profile.d/autojump.sh
EOF

    sed -i '' 's#^\plugins#\#&#g' ~/.zshrc
    sed -i '' '/^#plugins/a\
plugins=(\
    macos\
    sudo\
    git\
    fzf\
    autojump\
    docker\
    kubectl\
    helm\
    aws\
    ansible\
    terraform\
    direnv\
)\
' ~/.zshrc
```

### Install [Fzf](https://github.com/junegunn/fzf) (Recommended)

```bash
    brew install fzf

    grep '^## fzf' ~/.zshrc || cat >> ~/.zshrc <<EOF
$(echo '' || echo 'Insert blank line')
## fzf | Added at '$(date +%F_%T%z)'
source <(fzf --zsh)
EOF
```

### Install [GPG](https://gpgtools.org/)

```bash
    brew install gpg                       # GPG CLI only
    brew install --cask gpg-suite-no-mail  # GPG GUI + CLI, alias  gpg-gui='open /Applications/GPG\ Key
chain.app'

    brew install pinentry-mac               # GPG GUI Configuration
    mkdir -pv ~/.gnupg/
    echo "pinentry-program $(which pinentry-mac)" > ~/.gnupg/gpg-agent.conf

    # Passphrase: Your Strong Passphrase
    gpg --batch --full-generate-key <<EOF
Key-Type: RSA
Key-Usage: sign,cert
Key-Length: 4096
Subkey-Type: RSA
Subkey-Usage: encrypt
Subkey-Length: 4096
Name-Real: $(whoami)
Name-Email: $(whoami)@pdomain.com
Expire-Date: 1y
%commit
EOF

    gpgconf –-kill gpg-agent                    # Restart gpg-agent
    gpg --armor --export $(whoami)@pdomain.com # export public key
    gpg --armor --export-secret-keys $(whoami)@pdomain.com # export private key

    gpg --list-public-keys
    gpg --list-secret-keys
    gpg --list-secret-keys --keyid-format LONG

    gpg --list-secret-keys --keyid-format LONG|awk '/^ / {print $NF}'                    # Private Key
ID
    gpg --list-secret-keys --keyid-format LONG|awk '/sec/ {sub(/.*\//,"",$2); print $2}' # Pub Key ID

    # gpg --delete-secret-keys KEY_ID
    # gpg --delete-keys KEY_ID
    # gpg --delete-secret-and-public-keys $(whoami)@pdomain.com
```

### Install [awscli](https://aws.amazon.com/cli/) (Required)

```bash
    brew install awscli
```

### Install [Terraform](https://developer.hashicorp.com/terraform/install)

> We use [tfenv](https://github.com/tfutils/tfenv) here for terraform version management.

```bash
	brew install tfenv
	tfenv install 1.14.4
	tfenv use 1.14.4
	echo 1.14.4 > ~/.terraform-version

    terraform -install-autocomplete
    mkdir -pv ${HOME}/.terraform.d/plugin-cache
	mkdir -pv ${HOME}/.terraform.d/mirror
	terraform providers mirror ${HOME}/.terraform.d/mirror

    cat >> ~/.zshrc <<EOF
$(echo '' || echo 'Insert blank line')
## Terraform | Added at '$(date +%F_%T%z)'
#   https://developer.hashicorp.com/terraform/cli/config/config-file
export TF_IGNORE="trace"
export TF_LOG="info"        # off|info|debug|trace
export TF_LOG_PATH="\$HOME/.terraform.d/\${TF_LOG}.log"
export TF_CLI_CONFIG_FILE="\$HOME/.terraformrc"
export TF_PLUGIN_CACHE_DIR="\$HOME/.terraform.d/plugin-cache"
# export TF_DATA_DIR="\$HOME/.terraform.d"
# export TF_APPEND_USER_AGENT=""
# export TF_INPUT="0"
# export TF_IN_AUTOMATION=1
# export TF_CLI_ARGS=""
# export TF_CLI_ARGS_plan="-refresh=false -input=false"
# export TF_CLI_ARGS_apply="-auto-approve"
# export TF_REGISTRY_DISCOVERY_RETRY="3"
# export TF_REGISTRY_CLIENT_TIMEOUT="3600"
EOF

    cat > ~/.terraformrc <<EOF
$(echo '' || echo 'Insert blank line')
## Terraform configuration | Added at '$(date +%F_%T%z)'
#   https://www.terraform.io/cli/config/config-file
plugin_cache_dir             = "$HOME/.terraform.d/plugin-cache"
disable_checkpoint           = false
disable_checkpoint_signature = false

provider_installation {
  "filesystem_mirror" {
    include = ["hashicorp/*"]
    exclude = ["registry.terraform.io/*/*", "registry.opentofu.org/*/*"]
    path    = "$HOME/.terraform.d/mirror"
  }
  "filesystem_mirror" {
    include = ["registry.terraform.io/*/*", "registry.opentofu.org/*/*"]
    path    = "$HOME/.terraform.d/mirror"
  }
  "direct" {
    exclude = ["registry.terraform.io/*/*", "registry.opentofu.org/*/*"]
  }
}

#credentials "app.terraform.io" {
#  token = "xxxxxx.atlasv1.zzzzzzzzzzzzz"
#}
EOF
```

### Install [Terragrunt](https://docs.terragrunt.com/getting-started/install)

> > We use [warrensbox/tgswitch](https://github.com/warrensbox/tgswitch) here for terragrunt version management.

```bash
	brew install terragrunt
	brew postinstall terragrunt
# OR
	brew install warrensbox/tap/tgswitch
	tgswitch 0.76.6
	echo 0.76.6 > ~/.terragrunt-version

    terragrunt --install-autocomplete
    mkdir -pv ${HOME}/.terragrunt-cache
    mkdir -pv ${HOME}/.terragrunt-cache/terragrunt/providers

    cat >> ~/.zshrc <<EOF
$(echo '' || echo 'Insert blank line')
## Terragrunt | Added at '$(date +%F_%T%z)'
#   https://terragrunt.gruntwork.io/docs/reference/terragrunt-cache/
#   https://terragrunt.gruntwork.io/docs/features/provider-cache-server/
export TG_DOWNLOAD_DIR="\$HOME/.terragrunt-cache"
export TG_PROVIDER_CACHE_DIR="\$TG_DOWNLOAD_DIR/terragrunt/providers"
export TG_PROVIDER_CACHE=1
export TG_PROVIDER_CACHE_REGISTRY_NAMES=
# export TG_PROVIDER_CACHE_HOST=
# export TG_PROVIDER_CACHE_PORT=
# export TG_PROVIDER_CACHE_TOKEN=
EOF
```

### Install [Docker](https://hub.docker.com/editions/community/docker-ce-desktop-mac)

```bash
    brew install docker             # Docker CLI Only
    brew install --cask docker      # Docker Desktop GUI + Engine + CLI
    brew install docker-credential-helper-ecr
    grep AWS_SDK_LOAD_CONFIG ~/.zshrc || echo 'AWS_SDK_LOAD_CONFIG=true' >> ~/.zshrc
    test -f ~/.docker/config.json.default && cp -prfv ~/.docker/config.json{,.default}
    cat > ~/.docker/config.json <<EOF
{
    "auths": {
        "*.dkr.ecr.*.amazonaws.com": {}
    },
    "HttpHeaders": {
        "User-Agent": "Docker-Client/19.03.5 (darwin)"
    },
    "credsStore": "desktop",
    "credHelpers": {
        "*.dkr.ecr.*.amazonaws.com": "ecr-login"
    },
    "currentContext": "desktop-linux"
}
EOF
```

### Install [kubectl](), [helm](), [kustomize]()

```bash
	brew install minikube
	brew install kubectl
	brew install helm
```

Setup kubectl

```bash

```

Setup helm

```bash

```

Setup Kustomize

```bash

```

### [Git Config](https://git-scm.com/docs/git-config)

```bash
    git config --global user.name "${GIT_USER}"
    git config --global user.email "${GIT_EMAIL}"

    # Git Alias
    git config --global alias.prq '!sh -c "git fetch upstream refs/pull/$1/head:pr-$1 && git checkout pr-$1" -'

    # checkout PRs locally for review, git prq <PR-Number>
    git config --global alias.dpr '!sh -c “git branch | grep pr- | xargs git branch -D” -'
     # delete all local branches that where created with git prq
    git config --global alias.sync '!sh -c "git checkout master && git pull upstream master && git push origin HEAD --no-verify" -'

    # GPG Key  https://docs.github.com/en/authentication/managing-commit-signature-verification/telling-git-about-your-signing-key#telling-git-about-your-gpg-key
    git config --global commit.gpgsign true
    git config --global gpg.program /usr/local/bin/gpg
    git config --global user.signingkey $(gpg --list-secret-keys --keyid-format LONG  | awk '/^ / {print $NF}')

```

### SSH Config

```bash
    ssh-keygen -t ed25519 -f ~/.ssh/github -C "${GIT_EMAIL}"
    mkdir -pv ~/.ssh/conf.d
        cat > ~/.ssh/conf.d/github.conf <<EOF
# SSH configuration file (~/.ssh/config)
# Documentation: man ssh_config
Host *
    IgnoreUnknown UseKeychain
    UseKeychain yes
    AddKeysToAgent yes
    # ForwardAgent yes

    ServerAliveInterval 60
    ServerAliveCountMax 10

    ControlMaster auto
    ControlPath ~/.ssh/sockets/%r@%h-%p
    ControlPersist 10m

    PasswordAuthentication no
    PubkeyAuthentication yes

Host github.com
  IdentityFile ~/.ssh/github
EOF
```

### Set Env & Alias

> Please remember to update `domain.com`

```bash
    name="$(whoami|tr '.' ' ')"
    cat >> ~/.zshrc <<EOF
$(echo '' || echo 'Insert blank line')
## Env & Alias | Added at $(date +%F_%T%z)
export GIT_USE="${(C)name}"
export GIT_EMAIL="$(whoami)@domain.com"
#
export LANG=en_US.UTF-8
export LANGUAGE=en_US.UTF-8
export LC_ALL=en_US.UTF-8
#
## Alias | Added at $(date +%F_%T%z)
alias github="cd ~/github.com/"
alias work="cd ~/github.com/work"
EOF

    source ~/.zshrc
```

### Install [VSCode](https://code.visualstudio.com/)

```bash
    brew install --cask visual-studio-code

    code --install-extension ms-kubernetes-tools.vscode-kubernetes-tools
    code --install-extension hashicorp.terraform
    code --install-extension amazonwebservices.aws-toolkit-vscode
    code --install-extension ms-azuretools.vscode-docker
    code --install-extension eamodio.gitlens
    code --install-extension mhutchie.git-graph
    code --install-extension redhat.vscode-yaml
    code --install-extension ms-python.python
    code --install-extension ms-python.vscode-pylance
    code --install-extension golang.go
    code --install-extension redhat.vscode-yaml
    code --install-extension mikestead.dotenv
    code --install-extension rangav.vscode-thunder-client
    code --install-extension ms-vsliveshare.vsliveshare
    code --install-extension usernamehw.errorlens
    code --install-extension streetsidesoftware.code-spell-checker
    code --install-extension dracula-theme.theme-dracula

    cat <<EOF > ~/Library/Application\ Support/Code/User/settings.json
{
  "editor.tabSize": 4,
  "files.trimTrailingWhitespace": true,
  "terminal.integrated.fontFamily": "MesloLGS NF",
  "terminal.integrated.fontLigatures": true,
  "terminal.integrated.minimumContrastRatio": 1,
  "editor.renderWhitespace": "boundary",
  "telemetry.telemetryLevel": "off",
  "explorer.decorations.colors": false,
  "problems.decorations.enabled": false,
  "editor.codeActionsOnSave": {
      "source.fixAll.eslint": true
  },
  "gitlens.advanced.telemetry.enabled": false,
  "chat.mcp.discovery.enabled": true,
  "gitlens.blame.highlight.locations": [
      "gutter"
  ],
  "gitlens.codeLens.authors.enabled": false,
  "gitlens.currentLine.enabled": false,
  "gitlens.currentLine.scrollable": false,
  "gitlens.blame.heatmap.enabled": false,
  "gitlens.codeLens.recentChange.enabled": false,
}
EOF
```

### Install [Python](https://www.python.org/)

- [micromamba](https://github.com/mamba-org/mamba) for python env/version management.
- [chpwd](https://gist.github.com/hanyouqing/a3ef634c66dd9bbb6c5c6fd1339594ad) for change env/version for python automatically.
- [pipx](https://pipx.pypa.io/stable/installation/)

```bash
    brew install micromamba

    # initialize the shell
    micromamba shell init --shell zsh --root-prefix=~/.mamba/
    source ~/.zshrc
    micromamba shell reinit

    # list env
    micromamba env list

    # create & active env
    micromamba create -n test python=3.14 -y
    micromamba create -n test python=3.14 -c conda-forge -y
    micromamba activate test

    # remove env
    micromamba env remove -n test -y
    micromamba env remove -p ~/.mamba/envs/test
    micromamba clean --all

    # Install pipx
    brew install pipx
```

### Install [Java](https://www.oracle.com/java/technologies/javase/javase-jdk8-downloads.html)

> [SDKman](https://get.sdkman.io), [Maven](https://maven.apache.org/download.cgi)

```bash
    # Maven
    brew install maven

    # sdkman
    curl -s "https://get.sdkman.io" | bash
    source "/Users/youqing.han/.sdkman/bin/sdkman-init.sh"
    # sdk list java
    sdk install java 25.0.2-oracle
    sdk default java 25.0.2-oracle
    java -version

    grep JAVA_HOME ~/.zshrc || echo 'export JAVA_HOME=$(/usr/libexec/java_home -v 11)' >> ~/.zshrc
```

### Install [Node](https://nodejs.org/en)

> [nvm](https://github.com/nvm-sh/nvm), [yarn](https://yarnpkg.com/)

```bash
    curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.40.4/install.sh | bash
    nvm_lts_latest=$(nvm ls-remote --lts | tail -1 | awk '{print $NF}' | tr -d ')' | tr 'A-Z' 'a-z')
    nvm install --lts=${nvm_lts_latest}
    node --version

    brew install yarn
    yarn --version
```

### Install [Maven](https://maven.apache.org/download.cgi)

```bash
    brew install maven
```

### Install [1Password](https://1password.com/)

```bash
    brew install --cask 1password
    brew install --cask 1password-cli
    op --version
```

### Install [Insomnia](https://insomnia.rest/)

```bash
    brew install --cask insomnia
```

### Install AI Coding cli

```bash
    brew install gemini-cli
    brew install codex
    brew install claudcode
```



## 🚀 Quick Reference: Tools & Commands

### Infrastructure & Cloud
| Tool | Description | Useful Commands | Documentation |
| :--- | :--- | :--- | :--- |
| **AWS CLI** | Amazon Web Services CLI | `aws configure`, `aws s3 ls` | [Docs](https://aws.amazon.com/cli/) |
| **tfenv** | Terraform version manager | `tfenv install latest`, `tfenv use 1.5.0` | [GitHub](https://github.com/tfutils/tfenv) |
| **Terragrunt** | Terraform wrapper | `terragrunt plan`, `terragrunt apply` | [Docs](https://terragrunt.gruntwork.io/) |
| **Kubectl** | Kubernetes cluster CLI | `kubectl get pods`, `kubectl logs -f` | [Docs](https://kubernetes.io/docs/reference/kubectl/) |
| **Helm** | Kubernetes package manager | `helm install`, `helm list` | [Docs](https://helm.sh/) |
| **Minikube** | Local Kubernetes | `minikube start`, `minikube dashboard` | [Docs](https://minikube.sigs.k8s.io/) |

### Development & Runtimes
| Tool | Description | Useful Commands | Documentation |
| :--- | :--- | :--- | :--- |
| **SDKMAN!** | Java/JVM version manager | `sdk install java 21.0.2-tem`, `sdk list java` | [Docs](https://sdkman.io/) |
| **Python 3** | Python programming language | `python3 --version`, `pip3 install` | [Docs](https://docs.python.org/3/) |
| **Micromamba** | Fast conda package manager | `micromamba create -n dev`, `micromamba activate` | [Docs](https://mamba.readthedocs.io/en/latest/user_guide/micromamba.html) |
| **Maven** | Java build tool | `mvn clean install`, `mvn compile` | [Docs](https://maven.apache.org/) |
| **Yarn** | JS package manager | `yarn install`, `yarn start` | [Docs](https://yarnpkg.com/) |

### Shell & Productivity
| Tool | Description | Useful Commands | Documentation |
| :--- | :--- | :--- | :--- |
| **fzf** | Command-line fuzzy finder | `CTRL-R` (history), `CTRL-T` (files) | [GitHub](https://github.com/junegunn/fzf) |
| **zoxide** | Smarter `cd` command | `z path/to/dir`, `zi` (interactive) | [GitHub](https://github.com/ajeetdsouza/zoxide) |
| **direnv** | Per-directory env vars | `direnv allow`, `direnv edit .` | [Docs](https://direnv.net/) |
| **jq / yq** | JSON/YAML processors | `jq '.' file.json`, `yq eval` | [jq](https://stedolan.github.io/jq/) / [yq](https://mikefarah.gitbook.io/yq/) |
| **tldr** | Simplified man pages | `tldr tar`, `tldr docker` | [Docs](https://tldr.sh/) |
| **ShellCheck** | Shell script linter | `shellcheck script.sh` | [Docs](https://www.shellcheck.net/) |

### Containers & Services
| Tool | Description | Useful Commands | Documentation |
| :--- | :--- | :--- | :--- |
| **Docker** | Container platform | `docker ps`, `docker-compose up` | [Docs](https://docs.docker.com/) |
| **Redis** | In-memory data store | `redis-cli ping`, `redis-server` | [Docs](https://redis.io/documentation) |

## 🛠 macOS Casks (GUI)
*   **iTerm2**: Terminal emulator replacement.
*   **Visual Studio Code**: Extensible code editor.
*   **1Password / CLI**: Password management.
*   **GPG Suite**: OpenPGP for macOS (Email & File encryption).
*   **IINA**: Modern media player.

## ⚙️ Configuration
The environment is centralized in `~/.infra/env.sh`, which is automatically sourced by your `.zshrc` or `.bash_profile`.

*   **Customization**: Edit `templates/ansible/vars.yml` to add or remove packages from the installation list.
