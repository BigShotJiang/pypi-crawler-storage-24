# infra/cli.py - Main CLI entry point for Infra CLI tool
import os
import subprocess
from typing import Optional, List

import typer
from typing_extensions import Annotated

# Import plugins
from .plugins.terragrunt import TerragruntPlugin, build_tg_aws_path
from .plugins.config import ConfigPlugin
from .plugins.aws_sso import AwsSsoPlugin
from .plugins.packer import PackerPlugin
from .plugins.ansible import AnsiblePlugin
from .plugins.setup import SetupPlugin
from .plugins.pulumi import PulumiPlugin
from .plugins.github import GithubPlugin
from .plugins.slack import SlackPlugin
from .plugins.raw import RawPlugin
from .plugins.terraform import TerraformPlugin
from .plugins.python_plugin import PythonPlugin

# Import utils
from .utils.ui import (
    print_header,
    print_stat,
    print_env,
    print_error,
    print_warning,
    print_success,
    print_aws,
)
from .utils.config import load_plugin_config, ensure_config_exists
from .utils.aws import get_aws_identity
from .utils.exceptions import InfraError, DependencyError


app = typer.Typer(

    help="Infra CLI - A wrapper for infrastructure tools.", add_completion=False
)

# Initialize plugin instances
PLUGINS = {
    "terragrunt": TerragruntPlugin(),
    "tg": TerragruntPlugin(),
    "config": ConfigPlugin(),
    "pulumi": PulumiPlugin(),
    "packer": PackerPlugin(),
    "ansible": AnsiblePlugin(),
    "setup": SetupPlugin(),
    "aws": AwsSsoPlugin(),
    "github": GithubPlugin(),
    "slack": SlackPlugin(),
    "raw": RawPlugin(),
    "terraform": TerraformPlugin(),
    "python": PythonPlugin(),
}


class InfraContext:
    def __init__(self):
        self.env = "test"
        self.project = None
        self.region = "ap-northeast-1"
        self.service = None
        self.profile = None
        self.sync = False
        self.no_browser = False
        self.init = False
        self.apply = False
        self.create = False
        self.list = False
        self.dry_run = False
        self.verbose = False
        self.tg_args = []
        self.subcommand = None
        self.json_output = False


def _print_execution_summary(cmd_name: str, aws_identity: Optional[dict], state: InfraContext):
    """Prints a standardized execution summary using UI utils."""
    plugin = PLUGINS.get(cmd_name)
    if not plugin or plugin.name in ("config", "setup", "github", "slack", "raw", "python"):
        return

    print_header(f"{cmd_name} Execution Summary")

    if aws_identity:
        account_id = aws_identity.get("Account", "Unknown")
        profile_name = state.profile or os.environ.get("AWS_PROFILE", "default")
        print_aws(account_id, profile_name)

    if plugin.name == "terragrunt":
        print_env("Environment", state.env)
        print_stat("Project", state.project)
        print_stat("Region", state.region)
        print_stat("Service", state.service)

        rel_path = build_tg_aws_path(
            account=state.project or "",
            region=state.region or "",
            env=state.env or "",
            name=state.service or "",
        )
        print_stat("Target DIR", rel_path, color=typer.colors.YELLOW)
    elif plugin.name == "terraform":
        print_stat("Project", state.project)
        print_stat("Region", state.region)
        if state.env or state.project or state.region or state.service:
            rel_path = build_tg_aws_path(
                account=state.project or "",
                region=state.region or "",
                env=state.env or "",
                name=state.service or "",
            )
            print_stat("Target DIR", rel_path, color=typer.colors.YELLOW)
    else:
        print_stat("Project", state.project)
        print_stat("Region", state.region)


def _handle_aws_auth(plugin_name: str, state: InfraContext) -> Optional[dict]:
    """Handles AWS authentication check and optional automatic login."""
    if plugin_name not in ("terragrunt", "terraform", "pulumi", "packer", "aws"):
        return None

    if state.dry_run:
        return None

    identity, error_msg = get_aws_identity(state.profile)
    if not identity:
        if plugin_name == "aws":
            return None

        print_error("NOT AUTHENTICATED")
        if state.profile:
            print_stat("Profile", state.profile, color=typer.colors.YELLOW)

        if error_msg and (
            "expired" in error_msg.lower() or "token" in error_msg.lower()
        ):
            print_warning("Reason: SSO session expired or invalid")
            if typer.confirm(
                typer.style("Would you like to login to AWS SSO now?", bold=True),
                default=True,
            ):
                sso_plugin = PLUGINS.get("aws")
                if sso_plugin:
                    sso_plugin.run(state, None)
                    identity, _ = get_aws_identity(state.profile)
                if not identity:
                    print_error("Still not authenticated after login. Exiting.")
                    raise typer.Exit(code=1)
                return identity
            else:
                raise typer.Exit(code=1)
        else:
            if error_msg:
                print_error(f"Error: {error_msg.strip()}")
            raise typer.Exit(code=1)
    return identity


def execute_plugin(cmd_name: str, state: InfraContext, extra_args: Optional[List[str]] = None, **kwargs):
    plugin = PLUGINS.get(cmd_name)
    if not plugin:
        print_error(f"Plugin for command '{cmd_name}' not found")
        raise typer.Exit(code=1)

    plugin_name = plugin.name
    defaults = load_plugin_config(plugin_name)

    if not defaults.get("enabled", True) and plugin_name != "config":
        print_warning(f"Plugin '{plugin_name}' is disabled in configuration.")
        return

    for key, val in defaults.items():
        if hasattr(state, key) and getattr(state, key) is None:
            setattr(state, key, val)
    for k, v in kwargs.items():
        if v is not None:
            setattr(state, k, v)

    try:
        deps = plugin.check_dependencies(state)
        missing = [name for name, path in deps.items() if path is None or path == ""]
        if missing:
            if plugin_name == "aws":
                print_error(f"Missing required dependencies for '{plugin_name}': {', '.join(missing)}")
                print_warning("Install: pip install boto3; ensure 'aws' CLI is installed.")
                raise typer.Exit(code=1)
            else:
                raise DependencyError(plugin_name, missing)

        if extra_args:
            state.tg_args = list(extra_args)
        else:
            state.tg_args = []

        if plugin_name == "terragrunt" and not state.service:
            print_error("Error: --service is required for terragrunt")
            raise typer.Exit(code=1)

        abs_path = None
        if plugin_name == "terragrunt":
            rel_path = build_tg_aws_path(
                account=state.project or "",
                region=state.region or "",
                env=state.env or "",
                name=state.service or "",
            )
            abs_path = os.path.abspath(rel_path)
        elif plugin_name == "terraform" and (
            state.env or state.project or state.region or state.service
        ):
            rel_path = build_tg_aws_path(
                account=state.project or "",
                region=state.region or "",
                env=state.env or "",
                name=state.service or "",
            )
            abs_path = os.path.abspath(rel_path)

        aws_identity = _handle_aws_auth(plugin_name, state)
        _print_execution_summary(cmd_name, aws_identity, state)

        plugin.run(state, abs_path)
        if (
            plugin.should_print_success(state)
            and not state.dry_run
        ):
            print_success("Operation completed successfully.")
    except subprocess.CalledProcessError as e:
        raise typer.Exit(code=e.returncode)
    except InfraError as e:
        print_error(f"Error: {e.message}")
        raise typer.Exit(code=e.exit_code)
    except KeyboardInterrupt:
        print_warning("Execution cancelled by user.")
        raise typer.Exit(code=130)


# Shared Options
EnvOpt = Annotated[Optional[str], typer.Option("-e", "--env", help="Environment name")]
ProjOpt = Annotated[Optional[str], typer.Option("-p", "--project", help="Project name")]
RegOpt = Annotated[Optional[str], typer.Option("-r", "--region", help="AWS region")]
SvcOpt = Annotated[Optional[str], typer.Option("-s", "--service", help="Service path")]
ProfileOpt = Annotated[
    Optional[str], typer.Option("--profile", help="AWS profile name")
]
DryRunOpt = Annotated[
    bool, typer.Option("--dry-run", help="Show commands without executing")
]
VerboseOpt = Annotated[bool, typer.Option("--verbose", help="Enable verbose output")]


@app.callback()
def main(
    ctx: typer.Context,
    dry_run: DryRunOpt = False,
    verbose: VerboseOpt = False,
):
    """Infrastructure management CLI."""
    ensure_config_exists()
    state = InfraContext()
    state.dry_run = dry_run
    state.verbose = verbose
    ctx.obj = state


@app.command("terragrunt")
@app.command("tg")
def terragrunt(
    ctx: typer.Context,
    env: EnvOpt = None,
    project: ProjOpt = None,
    region: RegOpt = None,
    service: SvcOpt = None,
    profile: ProfileOpt = None,
    init: bool = False,
    apply: bool = False,
    create: bool = False,
    args: Annotated[
        Optional[List[str]], typer.Argument(help="Remaining arguments")
    ] = None,
):
    """Run Terragrunt commands."""
    execute_plugin(
        "terragrunt",
        ctx.obj,
        extra_args=args,
        env=env,
        project=project,
        region=region,
        service=service,
        profile=profile,
        init=init,
        apply=apply,
        create=create,
    )


@app.command()
def packer(
    ctx: typer.Context,
    project: ProjOpt = None,
    region: RegOpt = None,
    profile: ProfileOpt = None,
    init: bool = False,
    apply: bool = False,
    args: Annotated[Optional[List[str]], typer.Argument()] = None,
):
    """Run Packer commands."""
    execute_plugin(
        "packer",
        ctx.obj,
        extra_args=args,
        project=project,
        region=region,
        profile=profile,
        init=init,
        apply=apply,
    )


@app.command()
def ansible(
    ctx: typer.Context,
    project: ProjOpt = None,
    create: bool = False,
    args: Annotated[Optional[List[str]], typer.Argument()] = None,
):
    """Run Ansible commands."""
    execute_plugin("ansible", ctx.obj, extra_args=args, project=project, create=create)


@app.command()
def pulumi(
    ctx: typer.Context,
    project: ProjOpt = None,
    region: RegOpt = None,
    profile: ProfileOpt = None,
    args: Annotated[Optional[List[str]], typer.Argument()] = None,
):
    """Run Pulumi commands."""
    execute_plugin(
        "pulumi", ctx.obj, extra_args=args, project=project, region=region, profile=profile
    )


@app.command()
def terraform(
    ctx: typer.Context,
    env: EnvOpt = None,
    project: ProjOpt = None,
    region: RegOpt = None,
    service: SvcOpt = None,
    profile: ProfileOpt = None,
    args: Annotated[
        Optional[List[str]],
        typer.Argument(help="Terraform subcommand and arguments (e.g. plan, apply -auto-approve)"),
    ] = None,
):
    """Run Terraform commands with infra context (AWS profile, optional path)."""
    execute_plugin(
        "terraform",
        ctx.obj,
        extra_args=args,
        env=env,
        project=project,
        region=region,
        service=service,
        profile=profile,
    )


@app.command()
def python(
    ctx: typer.Context,
    project: ProjOpt = None,
):
    """Scaffold a best-practice Python learning project (src layout, pyproject.toml, README with docs & learning path)."""
    execute_plugin("python", ctx.obj, project=project)


@app.command()
def setup(
    ctx: typer.Context,
    create: bool = False,
    list_all: Annotated[bool, typer.Option("--list")] = False,
    args: Annotated[Optional[List[str]], typer.Argument()] = None,
):
    """Run Local environment setup via Ansible."""
    execute_plugin("setup", ctx.obj, extra_args=args, create=create, list=list_all)


@app.command()
def github(ctx: typer.Context, create: bool = False):
    """Manage GitHub repository settings and scaffolding."""
    execute_plugin("github", ctx.obj, create=create)


@app.command()
def slack(ctx: typer.Context, args: Annotated[Optional[List[str]], typer.Argument()] = None):
    """Slack notifications plugin."""
    execute_plugin("slack", ctx.obj, extra_args=args)


aws_app = typer.Typer(
    help="AWS: SSO login, sync profiles, whoami, exec CLI, env export.",
    no_args_is_help=False,
)


@aws_app.callback(invoke_without_command=True)
def _aws_cb(
    ctx: typer.Context,
    profile: ProfileOpt = None,
    sync: bool = False,
    no_browser: bool = False,
):
    if ctx.invoked_subcommand is not None:
        return
    ctx.invoke(aws_login, profile=profile, sync=sync, no_browser=no_browser)


@aws_app.command("login")
def aws_login(
    ctx: typer.Context,
    profile: ProfileOpt = None,
    sync: bool = False,
    no_browser: bool = False,
):
    """SSO login (default when running 'infra aws'). Use --sync to sync account/role profiles after login."""
    # Find the state from the parent context
    state = ctx.parent.obj if ctx.parent else InfraContext()
    execute_plugin("aws", state, subcommand="login", profile=profile, sync=sync, no_browser=no_browser)


@aws_app.command("sync")
def aws_sync(ctx: typer.Context, profile: ProfileOpt = None):
    """Sync SSO account/role profiles to ~/.aws/config (login first if needed)."""
    state = ctx.parent.obj if ctx.parent else InfraContext()
    execute_plugin("aws", state, subcommand="sync", profile=profile)


@aws_app.command("whoami")
def aws_whoami(
    ctx: typer.Context,
    profile: ProfileOpt = None,
    json_output: Annotated[bool, typer.Option("--json")] = False,
):
    """Show current caller identity (account, user/role, ARN)."""
    state = ctx.parent.obj if ctx.parent else InfraContext()
    execute_plugin("aws", state, subcommand="whoami", profile=profile, json_output=json_output)


@aws_app.command("exec")
def aws_exec(
    ctx: typer.Context,
    profile: ProfileOpt = None,
    args: Annotated[
        Optional[List[str]],
        typer.Argument(help="AWS CLI command and arguments (e.g. s3 ls, sts get-caller-identity)"),
    ] = None,
):
    """Run arbitrary AWS CLI command with profile (e.g. infra aws exec s3 ls)."""
    state = ctx.parent.obj if ctx.parent else InfraContext()
    execute_plugin("aws", state, subcommand="exec", profile=profile, extra_args=args or [])


@aws_app.command("env")
def aws_env(
    ctx: typer.Context,
    profile: ProfileOpt = None,
    json_output: Annotated[bool, typer.Option("--json")] = False,
):
    """Print export AWS_PROFILE=... for eval (e.g. eval $(infra aws env))."""
    state = ctx.parent.obj if ctx.parent else InfraContext()
    execute_plugin("aws", state, subcommand="env", profile=profile, json_output=json_output)


app.add_typer(aws_app, name="aws")


@app.command()
def config(ctx: typer.Context, args: Annotated[Optional[List[str]], typer.Argument()] = None):
    """Manage configuration."""
    execute_plugin("config", ctx.obj, extra_args=args)


@app.command()
def raw(
    ctx: typer.Context,
    profile: ProfileOpt = None,
    args: Annotated[Optional[List[str]], typer.Argument(help="Command and arguments to run")] = None,
):
    """Run arbitrary commands with infra context (AWS profile, etc.)."""
    execute_plugin("raw", ctx.obj, extra_args=args, profile=profile)


def run():
    app()


if __name__ == "__main__":
    run()
