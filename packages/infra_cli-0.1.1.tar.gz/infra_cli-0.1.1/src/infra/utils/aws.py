import json
import subprocess
import shutil


def get_aws_identity(profile=None):
    """
    Returns (identity_dict, error_message).

    Checks for AWS CLI availability and attempts to get caller identity
    for the specified profile.
    """
    try:
        if not shutil.which("aws"):
            return None, "AWS CLI not found"

        cmd = ["aws", "sts", "get-caller-identity", "--output", "json"]
        if profile:
            cmd.extend(["--profile", profile])

        res = subprocess.run(cmd, capture_output=True, text=True)
        if res.returncode != 0:
            return None, res.stderr
        return json.loads(res.stdout), None
    except Exception as e:
        return None, str(e)
