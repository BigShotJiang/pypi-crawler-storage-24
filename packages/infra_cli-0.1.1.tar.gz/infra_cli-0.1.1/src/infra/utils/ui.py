import typer
import os

# --- Logical Logging / Output Helpers ---


def print_info(message: str):
    """Informational message (Cyan)."""
    typer.secho(f"ℹ️ {message}", fg=typer.colors.CYAN)


def print_success(message: str):
    """Success message (Green)."""
    typer.secho(f"✅ {message}", fg=typer.colors.GREEN)


def print_warning(message: str):
    """Warning message (Yellow)."""
    typer.secho(f"⚠️ {message}", fg=typer.colors.YELLOW)


def print_error(message: str):
    """Error message (Red)."""
    typer.secho(f"❌ {message}", fg=typer.colors.RED, err=True)


# --- Standardized Component Helpers ---


def print_header(title: str):
    """Major section header."""
    typer.echo()
    typer.secho(title, bold=True, fg=typer.colors.CYAN)


def print_stat(label: str, value: str, color=typer.colors.YELLOW):
    """Key-value pair display. Defaults to white."""
    typer.echo(f"  {label:<6}: ", nl=False)
    typer.secho(str(value), fg=color)


def print_cmd(command: str):
    """Standardized 'Running command' message (Green allowed)."""
    typer.echo("🔧 Running: ", nl=False)
    typer.secho(command, fg=typer.colors.GREEN)


def print_path(path: str, label: str = "Switching to"):
    """Standardized 'Switching to directory' or path message."""
    typer.echo(f"🚀 {label}: ", nl=False)
    typer.secho(path, fg=typer.colors.YELLOW)


def print_aws(account_id: str, profile_name: str):
    """Prints AWS Account ID (Cyan) and Profile Name (Yellow)."""
    typer.echo("  AWS(Profile): ", nl=False)
    typer.secho(account_id, fg=typer.colors.CYAN, nl=False)
    typer.echo(" (", nl=False)
    typer.secho(profile_name, fg=typer.colors.YELLOW, nl=False)
    typer.echo(")")


# --- Environment Formatting ---

ENV_COLOR_MAP = {
    "dev": typer.colors.CYAN,
    "test": typer.colors.YELLOW,
    "staging": typer.colors.GREEN,
    "qa": typer.colors.MAGENTA,
    "preprod": typer.colors.BLUE,
    "prod": typer.colors.RED,
}


def format_env(env_name: str) -> str:
    """Return colored environment name."""
    if not env_name:
        return "N/A"
    color = ENV_COLOR_MAP.get(env_name.lower(), typer.colors.WHITE)
    return typer.style(env_name, fg=color)


def print_env(label: str, env_name: str):
    """Convenience to print a labeled environment value."""
    print_stat(
        label, env_name, color=ENV_COLOR_MAP.get(env_name.lower(), typer.colors.WHITE)
    )


# Legacy constants for compatibility during transition
BOLD = True
GREEN = typer.colors.GREEN
CYAN = typer.colors.CYAN
YELLOW = typer.colors.YELLOW
RED = typer.colors.RED
RESET = typer.colors.WHITE
