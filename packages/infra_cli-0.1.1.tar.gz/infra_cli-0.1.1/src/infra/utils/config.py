import os
import yaml  # type: ignore
from pathlib import Path
from .ui import print_success, print_info

# --- Centralized Paths (XDG Compliant) ---

# Config Home: ~/.config/infra
XDG_CONFIG_HOME = Path(os.environ.get("XDG_CONFIG_HOME", Path.home() / ".config"))
INFRA_CONFIG_DIR = XDG_CONFIG_HOME / "infra"

# Data Home: ~/.local/share/infra
XDG_DATA_HOME = Path(os.environ.get("XDG_DATA_HOME", Path.home() / ".local" / "share"))
INFRA_DATA_DIR = XDG_DATA_HOME / "infra"

# Legacy Home: ~/.infra
LEGACY_INFRA_HOME = Path.home() / ".infra"


def _get_infra_home():
    """Returns the config directory, prioritizing legacy if it exists."""
    if LEGACY_INFRA_HOME.exists():
        return LEGACY_INFRA_HOME
    return INFRA_CONFIG_DIR


INFRA_HOME = _get_infra_home()


def _get_templates_dir():
    """Returns the templates directory, prioritizing legacy location."""
    legacy_templates = LEGACY_INFRA_HOME / "templates"
    if legacy_templates.exists():
        return legacy_templates
    return INFRA_DATA_DIR / "templates"


INFRA_TEMPLATES_DIR = _get_templates_dir()
INFRA_ANSIBLE_DIR = INFRA_TEMPLATES_DIR / "ansible"
INFRA_ANSIBLE_VARS = INFRA_ANSIBLE_DIR / "vars.yml"

# Infra Config file names
INFRA_CONFIG_YAML = INFRA_HOME / "config.yaml"
INFRA_CONFIG_YML = INFRA_HOME / "config.yml"

# AWS Standard Paths
AWS_HOME = Path.home() / ".aws"
AWS_CONFIG_PATH = AWS_HOME / "config"
AWS_CREDENTIALS_PATH = AWS_HOME / "credentials"
AWS_SSO_CACHE_DIR = AWS_HOME / "sso" / "cache"


def _get_config_path():
    if INFRA_CONFIG_YAML.exists():
        return INFRA_CONFIG_YAML
    return INFRA_CONFIG_YML


def get_config_path():
    """Return the current config file path (recomputed so new files are visible)."""
    return _get_config_path()

DEFAULT_CONFIG_TEMPLATE = {
    "terragrunt": {
        "enabled": True,
        "env": "test",
        "project": "demo-project",
        "region": "ap-northeast-1",
        "service": "s3/example",
        "extra_args": [],
        "parallelism": 10,
        "auto_init": True,
    },
    "ansible": {
        "enabled": True,
        "remote_user": "ubuntu",
        "inventory": "inventory.ini",
        "become": True,
        "forks": 5,
        "ssh_pipelining": True,
    },
    "pulumi": {
        "enabled": True,
        "stack_suffix": "test",
        "auto_approve": False,
        "backend_url": "s3://infra-cli-state-pulumi",
    },
    "packer": {
        "enabled": True,
        "headless": True,
        "on_error": "cleanup",
        "extra_args": [],
    },
    "setup": {"enabled": True, "auto_update": True, "preferred_shell": "zsh"},
    "aws": {"enabled": True},
    "terraform": {"enabled": True},
    "python": {"enabled": True},
    "github": {"enabled": True},
    "slack": {"enabled": True, "webhook_url": ""},
}

DEFAULT_CONFIG_TEMPLATE["subcommand"] = {"command": "", "args": []}


def ensure_config_exists():
    """Creates a default config file if it doesn't exist."""
    created = False
    p = _get_config_path()

    if not p.exists():
        if LEGACY_INFRA_HOME.exists():
            p = INFRA_CONFIG_YAML
        else:
            p = INFRA_CONFIG_YAML

        p.parent.mkdir(parents=True, exist_ok=True)
        with open(p, "w") as f:
            f.write("# Infra CLI Configuration File\n")
            f.write("# You can set default values for each plugin here.\n\n")
            yaml.dump(DEFAULT_CONFIG_TEMPLATE, f, default_flow_style=False)
        print_success(f"Initialized default config at {p}")
        created = True
    return created


def load_plugin_config(plugin_name):
    full_config = load_full_config()
    return full_config.get(plugin_name, {})


def validate_config(full_config):
    """Simple validation to ensure required top-level keys exist."""
    missing = [k for k in DEFAULT_CONFIG_TEMPLATE if k not in full_config and k != "subcommand"]
    if missing:
        # Just warn for now, or we could automatically add them
        pass
    return full_config


def load_full_config():
    """Return the entire configuration dict from the config file."""
    ensure_config_exists()
    p = _get_config_path()
    with open(p, "r") as f:
        config = yaml.safe_load(f) or {}
        return validate_config(config)


def _parse_config_value(value: str):
    """Convert string to bool/int/float when appropriate."""
    if value.lower() in ("true", "yes", "on"):
        return True
    if value.lower() in ("false", "no", "off"):
        return False
    try:
        return int(value)
    except ValueError:
        pass
    try:
        return float(value)
    except ValueError:
        pass
    return value


def update_config(plugin_name, kv_pairs):
    """Updates the config file with key=value pairs."""
    ensure_config_exists()
    p = _get_config_path()
    with open(p, "r") as f:
        full_config = yaml.safe_load(f) or {}

    if plugin_name not in full_config:
        full_config[plugin_name] = {}

    for item in kv_pairs:
        if "=" in item:
            key, value_str = item.split("=", 1)
            value = _parse_config_value(value_str)
            full_config[plugin_name][key] = value
            print_success(f"Set {plugin_name}.{key} = {value}")

    with open(p, "w") as f:
        yaml.dump(full_config, f, default_flow_style=False)
