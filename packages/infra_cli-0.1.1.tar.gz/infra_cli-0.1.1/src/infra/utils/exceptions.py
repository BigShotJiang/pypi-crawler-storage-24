class InfraError(Exception):
    """Base exception for all infra-cli errors."""
    def __init__(self, message: str, exit_code: int = 1):
        super().__init__(message)
        self.message = message
        self.exit_code = exit_code

class PluginError(InfraError):
    """Raised when a plugin execution fails."""
    pass

class DependencyError(PluginError):
    """Raised when a required dependency is missing."""
    def __init__(self, plugin_name: str, missing_deps: list[str]):
        msg = f"Missing required dependencies for '{plugin_name}': {', '.join(missing_deps)}"
        super().__init__(msg, exit_code=127)

class ConfigError(InfraError):
    """Raised when there is an issue with the configuration."""
    pass
