import subprocess
import shutil
import os
import typer
from .base import BasePlugin
from ..utils.ui import print_cmd, print_path, print_error, print_info


class TerraformPlugin(BasePlugin):
    """Run native Terraform commands with infra context (AWS profile, optional path)."""

    name = "terraform"

    def check_dependencies(self, state=None):
        tools = ["terraform", "aws"]
        return {t: shutil.which(t) for t in tools}

    def run(self, args, abs_path=None):
        extra = list(args.tg_args) if hasattr(args, "tg_args") and args.tg_args else []
        if not extra:
            print_info("Usage: infra terraform [options] <terraform_subcommand> [args...]")
            print_info("Example: infra terraform plan | infra terraform apply -auto-approve")
            return

        cmd = ["terraform"] + extra
        env = self._prepare_env(args)
        aws_profile = env.get("AWS_PROFILE")
        cwd = abs_path if abs_path and os.path.exists(abs_path) else os.getcwd()

        if getattr(args, "dry_run", False):
            print_info(f"[DRY-RUN] Would run: {' '.join(cmd)}")
            return

        if getattr(args, "verbose", False):
            print_path(cwd, label="Working Directory")
            if aws_profile:
                print_info(f"AWS Profile: {aws_profile}")

        prefix = f"AWS_PROFILE={aws_profile} " if aws_profile else ""
        print_cmd(f"{prefix}{' '.join(cmd)}")

        try:
            subprocess.run(cmd, cwd=cwd, check=True, env=env)
        except subprocess.CalledProcessError as e:
            print_error(f"Terraform failed with exit code {e.returncode}")
            raise typer.Exit(code=e.returncode)
        except FileNotFoundError:
            print_error("terraform not found")
            raise typer.Exit(code=127)
