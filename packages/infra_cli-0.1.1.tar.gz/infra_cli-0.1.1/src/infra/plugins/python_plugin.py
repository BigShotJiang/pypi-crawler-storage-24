import os
import re
import shutil
from pathlib import Path

from .base import BasePlugin
from ..utils.ui import (
    print_success,
    print_error,
    print_warning,
    print_info,
    print_header,
)


def _project_to_slug(project: str) -> str:
    """Convert project name to Python package slug (e.g. learn-python -> learn_python)."""
    s = re.sub(r"[^a-z0-9]+", "_", project.lower()).strip("_")
    return s or "app"


def _make_pyproject(project_name: str, slug: str) -> str:
    return f'''[build-system]
requires = ["setuptools>=61.0", "wheel"]
build-backend = "setuptools.build_meta"

[project]
name = "{project_name}"
version = "0.1.0"
description = "Learning project: {project_name}"
readme = "README.md"
requires-python = ">=3.11"
dependencies = []

[project.optional-dependencies]
dev = [
    "pytest>=7.0",
    "ruff>=0.1.0",
]

[tool.setuptools.packages.find]
where = ["src"]

[tool.ruff]
line-length = 88
target-version = "py311"

[tool.pytest.ini_options]
testpaths = ["tests"]
'''


def _make_readme(project_name: str, slug: str) -> str:
    return f'''# {project_name}

Learning project created by `infra python -p {project_name}`. This structure follows Python packaging and tooling best practices.

## Official & Best Practice Docs

- [Python Documentation](https://docs.python.org/3/)
- [Packaging Python Projects (PyPA)](https://packaging.python.org/en/latest/tutorials/packaging-projects/)
- [PEP 517 – Build system](https://peps.python.org/pep-0517/)
- [PEP 621 – pyproject.toml](https://peps.python.org/pep-0621/)
- [Testing: pytest](https://docs.pytest.org/)
- [Ruff (lint/format)](https://docs.astral.sh/ruff/)

## Project Layout (Best Practice)

- `src/{slug}/` – package code (src layout avoids accidental imports from cwd)
- `tests/` – tests; `conftest.py` for shared fixtures
- `pyproject.toml` – build, metadata, and tool config (single source of truth)

## Learning Path: From Zero to Advanced

1. **Basics**: Run and edit `src/{slug}/__init__.py`, run `python -c "import {slug}"` from project root.
2. **Packaging**: `pip install -e .` (editable install), then use the package in scripts.
3. **Testing**: Add tests in `tests/`, run `pytest`.
4. **Linting**: Run `ruff check .` and `ruff format .`.
5. **CLI**: Add a `[project.scripts]` entry in `pyproject.toml` and a `main()` in your package.
6. **Automation**: Use this Python base for scripts that call Ansible/Terraform/AWS APIs.

For the **overall DevOps learning order** (Python → Ansible → Terraform → Terragrunt → Packer → Pulumi → K8s), see the repo [Learning Path](https://github.com/hanyouqing/infra-cli/blob/main/docs/LEARNING_PATH.md).
'''


def _make_gitignore() -> str:
    return """# Bytecode
__pycache__/
*.py[cod]
*.pyo
.Python
*.so

# Virtual env
.venv/
venv/
.env

# IDE
.idea/
.vscode/
*.swp

# Build
build/
dist/
*.egg-info/
.eggs/

# Test / coverage
.pytest_cache/
.coverage
htmlcov/
"""


class PythonPlugin(BasePlugin):
    """Scaffold a best-practice Python project for learning (layout, config, learning README)."""

    name = "python"

    def check_dependencies(self, state=None):
        return {"python3": shutil.which("python3") or shutil.which("python")}

    def should_print_success(self, state):
        return False

    def run(self, args, abs_path=None):
        project = getattr(args, "project", None) or ""
        project = project.strip()
        if not project:
            print_header("Python: Learning project scaffold")
            print_info("Usage: infra python -p <project-name>")
            print_info("Example: infra python -p learn-python")
            print_info("Creates a directory with src layout, pyproject.toml, tests, and a README with official docs and learning path.")
            return

        cwd = os.getcwd()
        target_dir = os.path.join(cwd, project)
        if os.path.exists(target_dir) and os.listdir(target_dir):
            print_warning(f"Directory {target_dir} already exists and is not empty. Skipping scaffold.")
            print_info("Use a different project name with -p, or run from another directory.")
            return

        slug = _project_to_slug(project)
        src_pkg = os.path.join(target_dir, "src", slug)
        tests_dir = os.path.join(target_dir, "tests")

        try:
            os.makedirs(src_pkg, exist_ok=True)
            os.makedirs(tests_dir, exist_ok=True)
        except OSError as e:
            print_error(f"Failed to create directories: {e}")
            return

        files = [
            (os.path.join(src_pkg, "__init__.py"), "# " + project + "\n"),
            (os.path.join(tests_dir, "conftest.py"), "# Shared pytest fixtures\n"),
            (
                os.path.join(tests_dir, "test_example.py"),
                f'''"""Example test."""
import pytest


def test_import_package():
    import {slug}
    assert {slug}.__name__ == "{slug}"
''',
            ),
            (os.path.join(target_dir, "pyproject.toml"), _make_pyproject(project, slug)),
            (os.path.join(target_dir, "README.md"), _make_readme(project, slug)),
            (os.path.join(target_dir, ".gitignore"), _make_gitignore()),
        ]
        for path, content in files:
            try:
                Path(path).parent.mkdir(parents=True, exist_ok=True)
                with open(path, "w", encoding="utf-8") as f:
                    f.write(content)
            except OSError as e:
                print_error(f"Failed to write {path}: {e}")
                return

        print_success(f"Created Python project: {target_dir}")
        print_info(f"  src/{slug}/  – package (src layout)")
        print_info("  tests/      – pytest")
        print_info("  pyproject.toml, README.md, .gitignore")
        print_info("Next: cd " + project + " && pip install -e '.[dev]' && pytest")
        print_info("Read README.md for official docs and learning path.")
