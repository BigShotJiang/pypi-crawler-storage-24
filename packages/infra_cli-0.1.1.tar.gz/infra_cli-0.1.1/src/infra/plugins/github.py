import os
import shutil
from .base import BasePlugin
from ..utils.ui import (
    print_success,
    print_error,
    print_warning,
    print_header,
    print_info,
)


class GithubPlugin(BasePlugin):
    name = "github"

    def check_dependencies(self, state=None):
        """GitHub plugin primarily uses file operations for scaffolding."""
        return {}

    def run(self, args, abs_path=None):
        if getattr(args, "create", False):
            self._scaffold(abs_path or os.getcwd())
        else:
            print_info("Use --create to scaffold GitHub community files and templates.")

    def _scaffold(self, target_dir):
        """Copies GitHub templates to the target directory."""
        src = self._get_resource_path("github")

        if not os.path.exists(src):
            print_error(f"GitHub templates not found at {src}")
            return

        print_header("Scaffolding GitHub community files")

        try:
            # List files in the github template dir
            files = os.listdir(src)
            for f in files:
                src_file = os.path.join(src, f)
                dest_file = os.path.join(target_dir, f)

                if os.path.isdir(src_file):
                    if os.path.exists(dest_file):
                        print_warning(f"Directory {f} already exists. Skipping.")
                    else:
                        shutil.copytree(src_file, dest_file)
                        print_success(f"Created {f}/ directory")
                else:
                    if os.path.exists(dest_file):
                        print_warning(f"File {f} already exists. Skipping.")
                    else:
                        shutil.copy2(src_file, dest_file)
                        print_success(f"Created {f}")

            print_success("GitHub scaffolding complete.")
        except Exception as e:
            print_error(f"Failed to scaffold GitHub files: {e}")
