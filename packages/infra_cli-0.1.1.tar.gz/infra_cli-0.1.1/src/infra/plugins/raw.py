import subprocess
import os
import typer
from .base import BasePlugin
from ..utils.ui import print_cmd, print_error, print_info


class RawPlugin(BasePlugin):
    """Generic plugin to run arbitrary commands within the infra context."""

    name = "raw"

    def check_dependencies(self, state=None):
        return {}

    def should_print_success(self, state):
        return False

    def run(self, args, abs_path=None):
        if not hasattr(args, "tg_args") or not args.tg_args:
            print_error("No command provided. Usage: infra raw <command> [args...]")
            raise typer.Exit(code=1)

        cmd = list(args.tg_args)

        # Prepare environment
        env = self._prepare_env(args)
        aws_profile = env.get("AWS_PROFILE")

        # Set working directory to abs_path if provided (terragrunt context)
        cwd = abs_path if abs_path and os.path.exists(abs_path) else os.getcwd()

        if getattr(args, "dry_run", False):
            print_info(f"[DRY-RUN] Would run: {' '.join(cmd)}")
            return

        if getattr(args, "verbose", False):
            print_info(f"CWD: {cwd}")
            if aws_profile:
                print_info(f"AWS_PROFILE: {aws_profile}")

        prefix = f"AWS_PROFILE={aws_profile} " if aws_profile else ""
        print_cmd(f"{prefix}{' '.join(cmd)}")

        try:
            subprocess.run(cmd, cwd=cwd, check=True, env=env)
        except subprocess.CalledProcessError as e:
            print_error(f"Command failed with exit code {e.returncode}")
            raise typer.Exit(code=e.returncode)
        except FileNotFoundError:
            print_error(f"Command not found: {cmd[0]}")
            raise typer.Exit(code=127)
