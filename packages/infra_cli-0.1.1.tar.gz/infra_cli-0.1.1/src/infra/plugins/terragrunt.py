import subprocess
import shutil
import os
from .base import BasePlugin
from ..utils.ui import print_cmd, print_path, print_error, print_warning, print_success
from ..utils.config import load_plugin_config

# AWS-style path template: account -> region -> env -> name (Terragrunt/Gruntwork best practice)
# Use build_tg_aws_path() to resolve with parameters when creating the directory tree.
TG_AWS_INFRA_PATH_TEMPLATE = "{account}/{region}/{env}/{name}"


def build_tg_aws_path(
    account: str = "",
    region: str = "",
    env: str = "",
    name: str = "",
) -> str:
    """Build Terragrunt infra path from template. Empty segments are omitted."""
    raw = TG_AWS_INFRA_PATH_TEMPLATE.format(
        account=account or "",
        region=region or "",
        env=env or "",
        name=name or "",
    )
    parts = [p for p in raw.split("/") if p]
    return os.path.join(*parts) if parts else "."


class TerragruntPlugin(BasePlugin):
    name = "terragrunt"

    def check_dependencies(self, state=None):
        tools = ["terraform", "terragrunt", "aws"]
        return {tool: shutil.which(tool) for tool in tools}

    def run(self, args, abs_path):
        if getattr(args, "create", False):
            self._handle_scaffolding(args, abs_path)
            return

        config = load_plugin_config(self.name)
        extra_args = config.get("extra_args", [])
        if isinstance(extra_args, str):
            extra_args = [extra_args]

        if args.init:
            self._run_tg(["init"] + extra_args, abs_path, args)

        # Handle explicit apply/plan via flags or positional args
        elif args.apply:
            cmd = ["apply"] + extra_args + list(args.tg_args)
            self._run_tg(cmd, abs_path, args)
        else:
            # If no tg_args, default to plan
            tg_command = list(args.tg_args) if args.tg_args else ["plan"]
            self._run_tg(tg_command + extra_args, abs_path, args)

    def _handle_scaffolding(self, args, abs_path):
        """Handles Terragrunt boilerplate creation using TG_AWS_INFRA_PATH_TEMPLATE."""
        if os.path.isdir(abs_path):
            print_warning(f"Scaffold target {abs_path} already exists. Skipping.")
            return

        rel_path = build_tg_aws_path(
            account=args.project or "",
            region=args.region or "",
            env=args.env or "",
            name=args.service or "",
        )
        os.makedirs(abs_path, exist_ok=True)

        # 1. Root
        root_tg = "terragrunt.hcl"
        if not os.path.exists(root_tg):
            with open(root_tg, "w") as f:
                f.write(
                    '# Root terragrunt.hcl\n# Configures remote state and global provider settings\n\nlocals {\n  # Global variables\n}\n\nremote_state {\n  backend = "s3"\n  config = {\n    bucket = "infra-cli-state-${get_aws_account_id()}"\n    key    = "${path_relative_to_include()}/terraform.tfstate"\n    region = "ap-northeast-1"\n    encrypt = true\n  }\n}\n'
                )
            print_success("Created root-level terragrunt.hcl")

        # 2. Region (account/region/region.hcl)
        reg_dir = os.path.join(
            args.project or "", args.region or ""
        ).rstrip(os.sep)
        if reg_dir:
            reg_hcl = os.path.join(reg_dir, "region.hcl")
            if not os.path.exists(reg_hcl):
                os.makedirs(reg_dir, exist_ok=True)
                with open(reg_hcl, "w") as f:
                    f.write(f'locals {{\n  aws_region = "{args.region or ""}"\n}}\n')
                print_success(f"Created {reg_hcl}")

        # 3. Env (account/region/env/env.hcl)
        env_dir = os.path.join(
            args.project or "", args.region or "", args.env or ""
        ).rstrip(os.sep)
        if env_dir:
            env_hcl = os.path.join(env_dir, "env.hcl")
            if not os.path.exists(env_hcl):
                os.makedirs(env_dir, exist_ok=True)
                with open(env_hcl, "w") as f:
                    f.write(f'locals {{\n  environment = "{args.env or ""}"\n}}\n')
                print_success(f"Created {env_hcl}")

        # 4. Leaf (account/region/env/name/terragrunt.hcl)
        with open(os.path.join(abs_path, "terragrunt.hcl"), "w") as f:
            f.write('include "root" {\n  path = find_in_parent_folders()\n}\n\n')
            f.write(
                'include "env" {\n  path   = find_in_parent_folders("env.hcl")\n  expose = true\n  merge_strategy = "no_merge"\n}\n\n'
            )
            f.write(
                'include "region" {\n  path   = find_in_parent_folders("region.hcl")\n  expose = true\n  merge_strategy = "no_merge"\n}\n\n'
            )
            f.write(
                'terraform {\n  source = "tfr:///terraform-aws-modules/vpc/aws?version=5.0.0"\n}\n\ninputs = {\n  # name = "my-vpc"\n}\n'
            )

        print_success(f"Created standard multi-level boilerplate at {rel_path}")

    def _run_tg(self, cmd_list, cwd, args):
        config = load_plugin_config(self.name)
        full_cmd = ["terragrunt"] + cmd_list

        # Add parallelism if not already specified (using modern --parallelism flag)
        if "--parallelism" not in full_cmd:
            parallelism = config.get("parallelism")
            if parallelism:
                full_cmd += ["--parallelism", str(parallelism)]

        # Respect dry-run
        if getattr(args, "dry_run", False):
            import click

            click.secho(
                f"[DRY-RUN] Would run: terragrunt {' '.join(cmd_list)}", fg="yellow"
            )
            return

        # Prepare environment
        env = self._prepare_env(args)
        aws_profile = env.get("AWS_PROFILE")

        if getattr(args, "verbose", False):
            print_path(cwd, label="Working Directory")
            if aws_profile:
                import click

                click.secho(f"AWS Profile: {aws_profile}", fg="yellow", bold=True)

        prefix = f"AWS_PROFILE={aws_profile} " if aws_profile else ""
        print_cmd(f"{prefix}{' '.join(full_cmd)}")
        print()  # New line after the command print

        try:
            subprocess.run(full_cmd, cwd=cwd, check=True, env=env)
        except subprocess.CalledProcessError as e:
            print_error(f"Terragrunt failed with exit code {e.returncode}")
            raise
