import subprocess
import shutil
import os
from .base import BasePlugin
from ..utils.ui import GREEN, RESET, YELLOW, BOLD, print_cmd
from ..utils.config import load_plugin_config


class PulumiPlugin(BasePlugin):
    name = "pulumi"

    def check_dependencies(self, state=None):
        tools = ["pulumi", "aws"]
        return {t: shutil.which(t) for t in tools}

    def run(self, args, abs_path=None):
        config = load_plugin_config(self.name)
        extra = list(args.tg_args) if hasattr(args, "tg_args") else []

        if args.init:
            cmd = ["pulumi", "login"]
            if config.get("backend_url"):
                cmd.append(config.get("backend_url"))
        elif args.apply:
            cmd = ["pulumi", "up"]
            if config.get("auto_approve") and "--yes" not in extra:
                cmd.append("--yes")
            cmd += extra
        else:
            cmd = ["pulumi", "preview"] + extra

        # Respect dry-run
        if getattr(args, "dry_run", False):
            print(f"{YELLOW}[DRY-RUN] Would run: {GREEN}{' '.join(cmd)}{RESET}")
            return

        # Prepare environment
        env = self._prepare_env(args)
        aws_profile = env.get("AWS_PROFILE")

        if getattr(args, "verbose", False):
            if aws_profile:
                print(f"{BOLD}AWS Profile: {YELLOW}{aws_profile}{RESET}")
            if config.get("backend_url"):
                print(
                    f"{BOLD}Pulumi Backend: {YELLOW}{config.get('backend_url')}{RESET}"
                )

        prefix = f"AWS_PROFILE={aws_profile} " if aws_profile else ""
        print_cmd(f"{prefix}{' '.join(cmd)}")

        subprocess.run(cmd, check=True, env=env)
