import subprocess
import shutil
import os
from .base import BasePlugin
from ..utils.ui import print_cmd, print_info, print_warning
from ..utils.config import load_plugin_config


class PackerPlugin(BasePlugin):
    name = "packer"

    def check_dependencies(self, state=None):
        tools = ["packer", "aws"]
        return {t: shutil.which(t) for t in tools}

    def run(self, args, abs_path=None):
        config = load_plugin_config(self.name)
        # Use remaining args (tg_args) as passthrough to packer commands
        extra = list(args.tg_args) if hasattr(args, "tg_args") else []

        # Add extra args from config if not provided on CLI
        if not extra and config.get("extra_args"):
            cfg_extra = config.get("extra_args")
            extra = [cfg_extra] if isinstance(cfg_extra, str) else cfg_extra

        if getattr(args, "init", False):
            cmd = ["packer", "init"] + extra
        elif getattr(args, "apply", False):
            cmd = ["packer", "build"]
            if config.get("headless"):
                cmd += ["-force"]
            if config.get("on_error"):
                cmd += [f"-on-error={config.get('on_error')}"]
            cmd += extra
        else:
            # default to validate
            cmd = ["packer", "validate"] + extra

        # Respect dry-run
        if getattr(args, "dry_run", False):
            print_warning(f"[DRY-RUN] Would run: {' '.join(cmd)}")
            return

        # Prepare environment
        env = self._prepare_env(args)
        aws_profile = env.get("AWS_PROFILE")

        if getattr(args, "verbose", False):
            if aws_profile:
                print_info(f"AWS Profile: {aws_profile}")
            print_info(
                f"Packer Config: headless={config.get('headless')}, on_error={config.get('on_error')}"
            )

        prefix = f"AWS_PROFILE={aws_profile} " if aws_profile else ""
        print_cmd(f"{prefix}{' '.join(cmd)}")

        subprocess.run(cmd, check=True, env=env)
