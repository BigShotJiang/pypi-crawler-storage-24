import subprocess
import shutil
import os
from .base import BasePlugin
from ..utils.ui import (
    print_success,
    print_error,
    print_warning,
    print_info,
    print_cmd,
    print_path,
)
from ..utils.config import load_plugin_config


class AnsiblePlugin(BasePlugin):
    name = "ansible"

    def check_dependencies(self, state=None):
        tools = ["ansible-playbook"]
        return {t: shutil.which(t) for t in tools}

    def run(self, args, abs_path=None):
        extra = list(args.tg_args) if hasattr(args, "tg_args") else []
        config = load_plugin_config(self.name)

        # If user requests scaffolding
        if getattr(args, "create", False):
            target_dir = abs_path or os.getcwd()
            ansible_dir = os.path.join(target_dir, "ansible")
            if os.path.exists(ansible_dir):
                print_warning(
                    f"Ansible directory {ansible_dir} already exists. Skipping."
                )
                return

            src = self._get_resource_path("ansible")
            try:
                shutil.copytree(src, ansible_dir)
                print_success(f"Created standard Ansible structure at {ansible_dir}/")
            except Exception as e:
                print_error(f"Failed to create scaffolding: {e}")
            return

        # Run playbook by default
        cmd = ["ansible-playbook"]

        # Apply config defaults if not in extra args
        if "--user" not in extra and "-u" not in extra:
            user = config.get("remote_user") or config.get("user")
            if user:
                cmd += ["--user", user]

        if "--become" not in extra and "-b" not in extra and config.get("become"):
            cmd += ["--become"]

        if "--forks" not in extra and "-f" not in extra:
            forks = config.get("forks")
            if forks:
                cmd += ["--forks", str(forks)]

        # Look for site.yml in current dir or ansible/ dir
        playbook = "site.yml"
        inventory = config.get("inventory", "inventory.ini")
        cwd = os.getcwd()

        if not os.path.exists(playbook) and os.path.exists("ansible/site.yml"):
            cwd = os.path.join(cwd, "ansible")
            playbook = "site.yml"
            inventory = (
                inventory if os.path.exists(os.path.join(cwd, inventory)) else inventory
            )

        if extra:
            cmd += extra
        else:
            if os.path.exists(os.path.join(cwd, playbook)):
                cmd += ["-i", inventory, playbook]
            else:
                print_warning(
                    "No site.yml found. Use --create to scaffold a new project."
                )
                return

        if getattr(args, "dry_run", False):
            print_info(f"[DRY-RUN] Would run: {' '.join(cmd)}")
            return

        # Prepare environment
        env = self._prepare_env(args)
        aws_profile = env.get("AWS_PROFILE")

        if getattr(args, "verbose", False):
            if aws_profile:
                print_info(f"AWS Profile: {aws_profile}")

        prefix = f"AWS_PROFILE={aws_profile} " if aws_profile else ""
        print_path(cwd)
        print_cmd(f"{prefix}{' '.join(cmd)}")
        subprocess.run(cmd, cwd=cwd, check=True, env=env)
