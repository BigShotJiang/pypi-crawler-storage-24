import subprocess
import shutil
import json
import typer
import os
import time
import glob
import re
import webbrowser
from .base import BasePlugin
from ..utils.ui import (
    print_success,
    print_error,
    print_info,
    print_header,
    print_cmd,
    print_path,
    print_stat,
)
from ..utils.config import AWS_CONFIG_PATH, AWS_SSO_CACHE_DIR
from ..utils.aws import get_aws_identity


class AwsSsoPlugin(BasePlugin):
    name = "aws"

    def check_dependencies(self, state=None):
        sub = getattr(state, "subcommand", None) or "login"
        required = ["aws"] if sub in ("whoami", "exec", "env") else ["aws", "boto3"]
        deps = {}
        if "aws" in required:
            deps["aws"] = shutil.which("aws")
        if "boto3" in required:
            try:
                import boto3  # type: ignore
                deps["boto3"] = "Installed"
            except ImportError:
                deps["boto3"] = None
        return deps

    def should_print_success(self, state):
        return False

    def run(self, args, abs_path=None):
        subcommand = getattr(args, "subcommand", None) or "login"
        profile = (
            getattr(args, "profile", None)
            or os.environ.get("AWS_PROFILE")
            or "sso"
        )

        if subcommand in ("login", "sync"):
            if not self.check_dependencies().get("boto3"):
                print_error("boto3 required for login/sync. Install: pip install boto3")
                raise typer.Exit(code=1)
            if subcommand == "login":
                self._run_login(args, profile)
            else:
                self._run_sync(args, profile)
        elif subcommand == "whoami":
            self._run_whoami(profile, args)
        elif subcommand == "exec":
            self._run_exec(args, profile)
        elif subcommand == "env":
            self._run_env(profile, args)
        else:
            print_error(f"Unknown subcommand: {subcommand}")
            self._print_aws_help()

    def _print_aws_help(self):
        print_header("AWS plugin usage")
        print_info("  infra aws login     SSO login (default)")
        print_info("  infra aws sync     Sync SSO account/role profiles to ~/.aws/config")
        print_info("  infra aws whoami   Show current caller identity")
        print_info("  infra aws exec     Run arbitrary AWS CLI command (e.g. infra aws exec s3 ls)")
        print_info("  infra aws env      Print export AWS_PROFILE=... for eval")

    def _run_env(self, profile: str, args):
        """Print shell export for AWS_PROFILE so user can eval $(infra aws env)."""
        if getattr(args, "json_output", False):
            typer.echo(json.dumps({"AWS_PROFILE": profile}))
        else:
            typer.echo(f"export AWS_PROFILE={profile}")

    def _run_whoami(self, profile: str, args):
        """Show current caller identity (account, ARN, user/role)."""
        identity, err = get_aws_identity(profile)
        if not identity:
            print_error("Not authenticated or AWS CLI failed")
            if err:
                print_error(err.strip())
            raise typer.Exit(code=1)
        if getattr(args, "json_output", False):
            typer.echo(json.dumps(identity, indent=2))
            return
        print_header("Caller Identity")
        print_stat("Account", identity.get("Account", "—"))
        print_stat("UserId", identity.get("UserId", "—"))
        print_stat("Arn", identity.get("Arn", "—"))
        print_stat("Profile", profile)

    def _run_exec(self, args, profile: str):
        """Run aws <args...> with profile in env."""
        extra = list(getattr(args, "tg_args", []) or [])
        if not extra:
            print_error("Usage: infra aws exec <aws subcommand> [options]")
            print_info("Example: infra aws exec s3 ls | infra aws exec sts get-caller-identity")
            raise typer.Exit(code=1)
        cmd = ["aws"] + extra
        env = self._prepare_env(args)
        if getattr(args, "dry_run", False):
            print_info(f"[DRY-RUN] Would run: {' '.join(cmd)}")
            return
        if getattr(args, "verbose", False):
            print_cmd(" ".join(cmd))
        try:
            subprocess.run(cmd, env=env, check=True)
        except subprocess.CalledProcessError as e:
            raise typer.Exit(code=e.returncode)

    def _run_sync(self, args, profile: str):
        """Ensure logged in then sync SSO profiles to ~/.aws/config."""
        self._ensure_minimal_config(profile)
        if getattr(args, "dry_run", False):
            print_info(f"[DRY-RUN] Would sync SSO profiles for: {profile}")
            return
        self._run_login(args, profile, sync_after=True)

    def _run_login(self, args, profile: str, sync_after: bool = False):
        """SSO login; optionally open portal and sync profiles."""
        self._ensure_minimal_config(profile)

        if getattr(args, "dry_run", False):
            print_info(f"[DRY-RUN] Would login to AWS SSO profile: {profile}")
            return

        print_info(f"Initiating AWS SSO Login for profile: {profile}")

        try:
            cmd = ["aws", "sso", "login", "--profile", profile]
            if getattr(args, "no_browser", False):
                cmd.append("--no-browser")

            if getattr(args, "verbose", False):
                print_cmd(" ".join(cmd))

            if getattr(args, "no_browser", False):
                login_process = subprocess.Popen(
                    cmd,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.STDOUT,
                    text=True,
                    bufsize=1,
                )
                url_opened = False
                for line in login_process.stdout:
                    print(line, end="", flush=True)
                    if not url_opened:
                        match = re.search(
                            r"(https://device\.sso\.[a-z0-9-]+\.amazonaws\.com/\?user_code=[A-Z0-9-]+|https://device\.sso\.[a-z0-9-]+\.amazonaws\.com/|https://[a-z0-9-]+\.awsapps\.com/start/#/help/client)",
                            line,
                        )
                        if match:
                            auth_url = match.group(0)
                            if "?user_code=" not in auth_url:
                                code_match = re.search(
                                    r"([A-Z0-9]{4}-[A-Z0-9]{4})", line
                                )
                                if code_match:
                                    auth_url = f"{auth_url.rstrip('/')}/?user_code={code_match.group(0)}"
                            webbrowser.open(auth_url)
                            url_opened = True
                login_process.wait()
                if login_process.returncode != 0:
                    raise typer.Exit(code=login_process.returncode)
            else:
                subprocess.run(cmd, check=True)

            sso_data = self._get_sso_info(profile)
            token = self._get_sso_token(sso_data["start_url"])

            if token:
                print_success("Login Successful!")
                if sso_data["start_url"]:
                    print_path(sso_data["start_url"], label="Opening Access Portal")
                    webbrowser.open(sso_data["start_url"])
                do_sync = sync_after or getattr(args, "sync", False)
                if do_sync:
                    self._sync_profiles_boto3(profile, sso_data, token)
            else:
                subprocess.run(
                    ["aws", "sts", "get-caller-identity", "--profile", profile],
                    check=True,
                    capture_output=True,
                )
                print_success("Login Successful!")
                if sync_after or getattr(args, "sync", False):
                    sso_data = self._get_sso_info(profile)
                    token = self._get_sso_token(sso_data["start_url"])
                    if token:
                        self._sync_profiles_boto3(profile, sso_data, token)

        except typer.Exit:
            raise
        except Exception as e:
            print_error(f"AWS SSO Login failed: {e}")
            raise typer.Exit(code=1)

    def _ensure_minimal_config(self, profile):
        required = {
            "sso_start_url": "AWS SSO Start URL (e.g. https://d-1234567890.awsapps.com/start)",
            "sso_region": "AWS SSO Region (e.g. ap-northeast-1)",
        }
        print_header(f"Validating AWS Profile: {profile}")
        for field, desc in required.items():
            try:
                res = subprocess.run(
                    ["aws", "configure", "get", field, "--profile", profile],
                    capture_output=True,
                    text=True,
                    check=True,
                )
                if not res.stdout.strip():
                    raise subprocess.CalledProcessError(1, "Empty")
                print_stat(field, res.stdout.strip())
            except subprocess.CalledProcessError:
                new_val = typer.prompt(f"Enter {desc}")
                subprocess.run(
                    ["aws", "configure", "set", f"profile.{profile}.{field}", new_val],
                    check=True,
                )

    def _get_sso_info(self, profile):
        info = {"start_url": None, "region": None, "session": None}
        try:
            res = subprocess.run(
                ["aws", "configure", "get", "sso_start_url", "--profile", profile],
                capture_output=True,
                text=True,
            )
            info["start_url"] = res.stdout.strip()
            res = subprocess.run(
                ["aws", "configure", "get", "sso_region", "--profile", profile],
                capture_output=True,
                text=True,
            )
            info["region"] = res.stdout.strip()
            res = subprocess.run(
                ["aws", "configure", "get", "sso_session", "--profile", profile],
                capture_output=True,
                text=True,
            )
            info["session"] = res.stdout.strip()
        except Exception:
            pass
        return info

    def _get_sso_token(self, start_url):
        if not start_url:
            return None
        for cache_file in glob.glob(str(AWS_SSO_CACHE_DIR / "*.json")):
            try:
                with open(cache_file, "r") as f:
                    data = json.load(f)
                    if data.get("startUrl") == start_url:
                        expires_at = data.get("expiresAt")
                        if expires_at and expires_at > time.strftime(
                            "%Y-%m-%dT%H:%M:%SZ", time.gmtime()
                        ):
                            return data.get("accessToken")
            except Exception:
                continue
        return None

    def _sync_profiles_boto3(self, profile, sso_data, token):
        import boto3  # type: ignore

        print_info("Syncing SSO profiles to ~/.aws/config")
        try:
            session = boto3.Session(profile_name=profile)
        except Exception:
            session = boto3.Session()
        client = session.client("sso", region_name=sso_data["region"])
        try:
            accounts = []
            paginator = client.get_paginator("list_accounts")
            for page in paginator.paginate(accessToken=token):
                accounts.extend(page.get("accountList", []))
            new_profiles = []
            for acc in accounts:
                acc_id = acc["accountId"]
                acc_name = acc["accountName"].replace(" ", "-").lower()
                for page in client.get_paginator("list_account_roles").paginate(
                    accessToken=token, accountId=acc_id
                ):
                    for role in page.get("roleList", []):
                        new_profiles.append(
                            {
                                "name": f"{acc_name}-{role['roleName'].lower()}",
                                "account_id": acc_id,
                                "role_name": role["roleName"],
                                "region": sso_data["region"],
                            }
                        )
            if new_profiles:
                new_profiles.sort(key=lambda x: x["name"])
                self._update_aws_config(
                    new_profiles, sso_data["start_url"], sso_data["region"]
                )
                print_success(f"Synced {len(new_profiles)} profiles.")
        except Exception as e:
            print_error(f"Sync failed: {e}")

    def _update_aws_config(self, profiles, start_url, sso_region):
        content = ""
        header_marker = "# --- Generated by infra-cli ---"
        ts = time.strftime("%Y-%m-%d %H:%M:%S%z", time.localtime(time.time()))
        header_comment = (
            f"{header_marker}\n"
            f"# @generated: {ts}\n"
            "# This file contains AWS profiles managed by infra-cli.\n"
            "# @reference:\n"
            "#      https://docs.aws.amazon.com/cli/latest/userguide/cli-configure-sso.html\n"
            "#      https://docs.aws.amazon.com/cli/latest/userguide/sso-using-profile.html\n\n"
        )
        if AWS_CONFIG_PATH.exists():
            with open(AWS_CONFIG_PATH, "r") as f:
                content = f.read()
                if header_marker in content:
                    content = re.sub(
                        rf"{header_marker}\n# @generated:.*?\n",
                        f"{header_marker}\n# @generated: {ts}\n",
                        content,
                    )
                else:
                    content = header_comment + content
        else:
            content = header_comment

        for p in profiles:
            header = f"[profile {p['name']}]"
            if header in content:
                continue
            content += f"\n{header}\nsso_start_url = {start_url}\nsso_region = {sso_region}\nsso_account_id = {p['account_id']}\nsso_role_name = {p['role_name']}\nregion = {p['region']}\noutput = json\n"
        with open(AWS_CONFIG_PATH, "w") as f:
            f.write(content)
