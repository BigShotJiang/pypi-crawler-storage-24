import os
import infra


class BasePlugin:
    name: str = ""

    def check_dependencies(self, state=None):
        """Returns a dict of {tool_name: path_or_None} for required external tools."""
        raise NotImplementedError

    def run(self, args, abs_path):
        """Main execution logic for the plugin."""
        raise NotImplementedError

    def should_print_success(self, state):
        """Returns True if a success message should be printed after execution."""
        return True

    def _prepare_env(self, args):
        """Prepares the environment dictionary for subprocess calls."""
        env = os.environ.copy()
        profile = getattr(args, "profile", None)
        if profile:
            env["AWS_PROFILE"] = profile
            # Clear explicit keys if profile is used to avoid conflicts
            env.pop("AWS_ACCESS_KEY_ID", None)
            env.pop("AWS_SECRET_ACCESS_KEY", None)
            env.pop("AWS_SESSION_TOKEN", None)
        return env

    def _get_resource_path(self, *parts):
        """Locates project-wide resource files (like templates)."""
        try:
            from importlib import resources
            return str(resources.files("infra").joinpath("templates", *parts))
        except (ImportError, AttributeError):
            # Fallback to legacy path resolution
            pkg_dir = os.path.dirname(infra.__file__)
            path = os.path.join(pkg_dir, "templates", *parts)
            if not os.path.exists(path):
                src_dir = os.path.dirname(pkg_dir)
                path = os.path.join(src_dir, "templates", *parts)
            if not os.path.exists(path):
                repo_root = os.path.abspath(os.path.join(pkg_dir, "..", ".."))
                path = os.path.join(repo_root, "src", "infra", "templates", *parts)
            return path
