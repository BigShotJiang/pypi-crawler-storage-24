import os
import sys
import shutil
import subprocess
import platform
import typer
import getpass
from pathlib import Path
from .base import BasePlugin
from ..utils.ui import (
    print_success,
    print_error,
    print_warning,
    print_info,
    print_header,
    print_cmd,
    print_path,
    print_stat,
)
from ..utils.config import (
    load_plugin_config,
    update_config,
    get_config_path,
    INFRA_HOME,
    INFRA_TEMPLATES_DIR,
    INFRA_ANSIBLE_DIR,
    INFRA_ANSIBLE_VARS,
)


class SetupPlugin(BasePlugin):
    """Plugin to scaffold and run local environment setup via Ansible.

    Behavior:
    - `infra setup` refreshes templates in `~/.infra/templates/`, then runs the
      `setup.yml` playbook using the inventory at `~/.infra/templates/ansible/inventory.ini`.
    - `--create` copies these templates into the current working directory.
    - `--list` shows all supported components (tags) that can be individually installed.
    - Specifying arguments (e.g., `infra setup java`) runs only tagged tasks.
    """

    name = "setup"

    def check_dependencies(self, state=None):
        sys_platform = platform.system().lower()
        tools = ["ansible-playbook"]
        if sys_platform == "darwin":
            tools.append("brew")
        elif sys_platform == "linux":
            tools.append("apt-get")
        return {t: shutil.which(t) for t in tools}

    def should_print_success(self, state):
        return False

    def _scaffold(self, target_dir):
        """Copies the standard Ansible templates to the target directory."""
        src = self._get_resource_path("ansible")
        dest = os.path.join(target_dir, "ansible")
        if os.path.exists(dest):
            print_warning(f"Scaffold target {dest} already exists. Skipping.")
            return
        try:
            shutil.copytree(src, dest)
            print_success(f"Scaffolding created at {dest}/")
        except Exception as e:
            print_error(f"Failed to create scaffolding: {e}")

    def _install_user_templates(self):
        """Copy repository `templates/` into the user's `~/.infra/templates` directory."""
        src = self._get_resource_path()
        dest = INFRA_TEMPLATES_DIR

        # Ensure ~/.infra exists
        INFRA_HOME.mkdir(parents=True, exist_ok=True)

        if not os.path.exists(src):
            print_warning(f"Source templates not found at {src}.")
            return

        # Refresh only the templates directory
        if dest.exists():
            try:
                shutil.rmtree(dest)
            except Exception as e:
                print_error(f"Failed to update {dest}: {e}")
                return
        try:
            print_info(f"Updating templates {dest}")
            shutil.copytree(src, dest)
        except Exception as e:
            print_error(f"Failed to copy templates: {e}")
            raise typer.Exit(code=1)

    def _ensure_platform_prereqs(self):
        """Ensure package manager, python3 and ansible are installed for the local platform."""
        sys_platform = platform.system().lower()
        if sys_platform == "darwin":
            self._ensure_darwin()
        elif sys_platform == "linux":
            self._ensure_linux()

    def _ensure_darwin(self):
        brew = shutil.which("brew")
        if not brew:
            print_info("Installing Homebrew...")
            subprocess.run(
                [
                    "/bin/bash",
                    "-c",
                    "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)",
                ],
                check=True,
            )
            brew = shutil.which("brew")
        for pkg in ["python", "ansible"]:
            if not shutil.which(pkg if pkg != "python" else "python3"):
                print_info(f"Installing {pkg} via brew...")
                subprocess.run([brew, "install", pkg], check=True)

    def _ensure_linux(self):
        apt = shutil.which("apt-get")
        if not apt:
            print_warning("apt-get not found; skipping package installation.")
            return
        for pkg in ["python3", "ansible"]:
            if not shutil.which(pkg if pkg != "python3" else "python3"):
                print_info(f"Installing {pkg} via apt-get...")
                subprocess.run(["sudo", "apt-get", "update"], check=True)
                subprocess.run(["sudo", "apt-get", "install", "-y", pkg], check=True)

    def _get_user_vars(self):
        """Read variables from ~/.infra/templates/ansible/vars.yml if it exists."""
        if not INFRA_ANSIBLE_VARS.exists():
            return {}
        try:
            import yaml  # type: ignore

            with open(INFRA_ANSIBLE_VARS, "r") as f:
                return yaml.safe_load(f) or {}
        except Exception:
            return {}

    def _list_components(self):
        """Displays all supported setup components (tags)."""
        components = {
            "os_setup": "Base OS packages and prerequisites",
            "git": "Git configuration, global ignore, and commit templates",
            "gpg": "GPG installation and key generation",
            "aws": "AWS CLI configuration and Identity Center session setup",
            "ssh": "SSH client configuration and multiplexing setup",
            "terraform": "Terraform and Terragrunt installation and config",
            "docker": "Docker Desktop CLI and ECR credential helper setup",
            "vim": "Standard development .vimrc configuration",
            "neovim": "Standard development init.lua configuration",
            "micromamba": "Micromamba package manager and 'dev' environment",
            "java": "SDKMAN! and Java runtime installation",
            "zsh": "Oh My Zsh and Powerlevel10k theme setup",
        }

        print_header("Supported Setup Components")
        print_info("Use 'infra setup <component>' to install individual parts.")
        print()
        for tag, desc in components.items():
            typer.echo(f"  {typer.style(tag, fg=typer.colors.YELLOW):<15} : {desc}")
        typer.echo()

    def _has_gpg_keys(self):
        """Check if any GPG secret keys exist."""
        gpg = shutil.which("gpg")
        if not gpg:
            return False
        try:
            result = subprocess.run(
                [gpg, "--list-secret-keys"], capture_output=True, text=True
            )
            return result.returncode == 0 and "sec" in result.stdout
        except Exception:
            return False

    def _has_ssh_keys(self):
        """Check if any SSH private keys exist in ~/.ssh."""
        ssh_dir = Path.home() / ".ssh"
        if not ssh_dir.exists():
            return False
        # Check for typical private key files
        for item in ssh_dir.glob("id_*"):
            if not item.name.endswith(".pub"):
                return True
        return False

    def run(self, args, abs_path=None):
        # Handle --list option
        if getattr(args, "list", False):
            self._list_components()
            return

        # Remaining positional arguments are treated as tags for the setup playbook
        tags = list(args.tg_args) if hasattr(args, "tg_args") else []
        target_dir = abs_path or os.getcwd()

        if getattr(args, "create", False):
            self._scaffold(target_dir)
            return

        # Load existing config and vars
        setup_config = load_plugin_config(self.name)
        user_vars = self._get_user_vars()

        # Priority: CLI > Persistent Config > vars.yml
        user_name = setup_config.get("user_name") or user_vars.get("user_name", "")
        user_email = setup_config.get("user_email") or user_vars.get("user_email", "")

        # Customization Reminder
        print_header("Setup Customization")
        print_info(
            f"TIP: You can customize installed packages and settings in:\n\t{INFRA_ANSIBLE_VARS}"
        )

        default_user = getpass.getuser()
        if not user_name:
            user_name = typer.prompt(
                "Git user.name not set. Enter name", default=default_user
            )
            update_config(self.name, [f"user_name={user_name}"])

        if not user_email:
            user_email = typer.prompt(
                "Git user.email not set. Enter email", default=f"{default_user}@local"
            )
            update_config(self.name, [f"user_email={user_email}"])

        gpg_passphrase = ""
        # Prompt for passphrase if GPG or SSH is requested (or all) and keys are missing
        needs_gpg = not tags or "gpg" in tags
        needs_ssh = not tags or "ssh" in tags

        if (needs_gpg and not self._has_gpg_keys()) or (
            needs_ssh and not self._has_ssh_keys()
        ):
            print_info("New GPG or SSH keys may be generated.")
            gpg_passphrase = typer.prompt(
                "Enter Passphrase for new keys (leave empty for none)",
                hide_input=True,
                default="",
            )

        print_success(
            f"Using Git User info ({typer.style(str(get_config_path()), fg=typer.colors.YELLOW)}):"
        )
        print_stat("Name", user_name)
        print_stat("Email", user_email)
        print()

        if not typer.confirm(
            typer.style(
                "Do you want to proceed with the environment setup?", bold=True
            ),
            default=True,
        ):
            print_warning("Operation cancelled by user.")
            return

        print_header("Preparing environment")
        with typer.progressbar(length=3, label="[1/3] Syncing templates") as bar:
            self._install_user_templates()
            bar.update(1)

        with typer.progressbar(
            length=3, label="[2/3] Verifying platform prerequisites"
        ) as bar:
            self._ensure_platform_prereqs()
            bar.update(2)

        # Simplified logic: Always use setup.yml from ~/.infra/templates/ansible
        user_ansible_dir = INFRA_ANSIBLE_DIR
        playbook_rel = "setup.yml"
        inventory_rel = "inventory.ini"

        abs_playbook = user_ansible_dir / playbook_rel

        if not abs_playbook.exists():
            print_error(f"setup.yml not found in {user_ansible_dir}")
            return

        import json
        import tempfile

        ansible_args = [
            "-e",
            f"user_name='{user_name}'",
            "-e",
            f"user_email='{user_email}'",
        ]

        with tempfile.NamedTemporaryFile(mode="w", suffix=".json", delete=False) as tf:
            temp_vars_path = tf.name
            if gpg_passphrase:
                json.dump({"gpg_passphrase": gpg_passphrase}, tf)
            else:
                json.dump({}, tf)

        try:
            if gpg_passphrase:
                ansible_args += ["-e", f"@{temp_vars_path}"]

            # If specific components were requested, use them as tags
            if tags:
                ansible_args += ["--tags", ",".join(tags)]

            ansible_bin = shutil.which("ansible-playbook")
            cmd = [ansible_bin, "-i", inventory_rel, playbook_rel] + ansible_args

            if getattr(args, "dry_run", False):
                print_info(f"[DRY-RUN] Would run: {' '.join(cmd)}")
                return

            print_header("[3/3] Executing setup playbook")
            if tags:
                print_info(f"Running tasks tagged with: {', '.join(tags)}")
            print_path(str(user_ansible_dir))
            print_cmd(" ".join(cmd))
            subprocess.run(cmd, cwd=user_ansible_dir, check=True, stdin=sys.stdin)
        finally:
            if os.path.exists(temp_vars_path):
                os.remove(temp_vars_path)
