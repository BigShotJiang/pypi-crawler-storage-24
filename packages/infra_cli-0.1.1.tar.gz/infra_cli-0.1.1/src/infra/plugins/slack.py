import json
import urllib.request
import typer
from .base import BasePlugin
from ..utils.ui import (
    print_success,
    print_error,
    print_header,
    print_info,
    print_stat,
)
from ..utils.config import load_plugin_config, update_config


class SlackPlugin(BasePlugin):
    name = "slack"

    def check_dependencies(self, state=None):
        """Slack plugin uses standard library urllib."""
        return {}

    def should_print_success(self, state):
        return False

    def run(self, args, abs_path=None):
        config = load_plugin_config(self.name)
        webhook_url = config.get("webhook_url")

        # Subcommand logic based on extra_args (args.tg_args)
        extra = list(args.tg_args) if hasattr(args, "tg_args") else []

        if not extra:
            self._show_help()
            return

        command = extra[0]

        if command == "post":
            if len(extra) < 2:
                print_error('No message provided. Usage: infra slack post "message"')
                return
            message = extra[1]
            self._post_message(webhook_url, message)
        elif command == "config":
            if len(extra) < 2:
                print_stat(
                    "Webhook URL",
                    webhook_url or "<not set>",
                    color=typer.colors.YELLOW,
                )
                print_info(
                    "Usage: infra slack config webhook_url=https://hooks.slack.com/... "
                )
                return
            # Allow setting config via CLI: infra slack config webhook_url=...
            update_config(self.name, extra[1:])
        else:
            print_error(f"Unknown slack command: {command}")
            self._show_help()

    def _show_help(self):
        print_header("Slack Plugin Usage")
        print_info(
            '  infra slack post "text"    - Send a message to the configured webhook'
        )
        print_info(
            "  infra slack config key=val  - Configure slack settings (e.g. webhook_url)"
        )

    def _post_message(self, webhook_url, text):
        if not webhook_url:
            print_error("Slack webhook_url not configured.")
            print_info("Run: infra slack config webhook_url=YOUR_URL")
            return

        print_info("Sending message to Slack...")

        payload = {"text": text, "username": "infra-cli", "icon_emoji": ":rocket:"}

        try:
            data = json.dumps(payload).encode("utf-8")
            req = urllib.request.Request(
                webhook_url, data=data, headers={"Content-Type": "application/json"}
            )
            with urllib.request.urlopen(req) as response:
                if response.status == 200:
                    print_success("Message posted successfully!")
                else:
                    print_error(f"Failed to post message. Status: {response.status}")
        except Exception as e:
            print_error(f"Error posting to Slack: {e}")
