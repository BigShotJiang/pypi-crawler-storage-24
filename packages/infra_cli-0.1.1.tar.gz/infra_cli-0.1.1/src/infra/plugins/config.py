import typer
from .base import BasePlugin
from ..utils.config import load_full_config, get_config_path, update_config
from ..utils.ui import print_info, print_warning


def _mask_sensitive(obj, sensitive_keys, show_chars=4):
    """Return a copy of obj with sensitive string values masked."""
    if isinstance(obj, dict):
        return {
            k: _mask_sensitive(v, sensitive_keys, show_chars)
            if k.lower() not in sensitive_keys
            else _redact(v, show_chars)
            for k, v in obj.items()
        }
    if isinstance(obj, list):
        return [_mask_sensitive(i, sensitive_keys, show_chars) for i in obj]
    return obj


def _redact(value, show_chars):
    if not isinstance(value, str):
        return "***" if value else value
    if not value or len(value) <= show_chars * 2:
        return "***" if value else ""
    return value[:show_chars] + "..." + value[-show_chars:]


class ConfigPlugin(BasePlugin):
    """Simple config plugin that shows the current config and help.

    This plugin is intended to be run automatically on first-run (when the
    CLI created a default config file) to surface the location and contents
    of the config file and brief instructions for users.
    """

    name = "config"

    def check_dependencies(self, state=None):
        return {}

    def should_print_success(self, state):
        return False

    def run(self, args, abs_path=None):
        # Determine raw items to process. When invoked from CLI, `args.tg_args`
        # will contain the remainder (e.g. ['terragrunt.project=onboarding']).
        items = []
        if args and hasattr(args, "tg_args") and args.tg_args:
            items = args.tg_args
        else:
            # When run manually (first-run), just show the config
            items = []

        if not items:
            cfg = load_full_config() or {}
            print_info(f"Configuration initialized at: {get_config_path()}")
            typer.echo()
            print_info("Current configuration (JSON-style):")
            import json

            _SENSITIVE_KEYS = {"webhook_url", "password", "secret", "token", "api_key"}
            cfg_display = _mask_sensitive(cfg, _SENSITIVE_KEYS)
            try:
                typer.echo(json.dumps(cfg_display, indent=2))
            except Exception:
                typer.echo(str(cfg_display))

            typer.echo()
            print_info(
                "Edit the file to change defaults, or use `infra config plugin.key=value` to update values."
            )
            print_info("Get a value: `infra config plugin.key`. See README for examples.")
            return

        # Parse items for get/set operations
        per_plugin_sets = {}
        per_plugin_gets = {}
        for item in items:
            if "." not in item:
                print_warning(
                    f"Invalid config entry: '{item}'. Expected format: plugin.key or plugin.key=value"
                )
                continue
            if "=" in item:
                plugin_and_key, val = item.split("=", 1)
                plugin, key = plugin_and_key.split(".", 1)
                per_plugin_sets.setdefault(plugin, []).append(f"{key}={val}")
            else:
                plugin, key = item.split(".", 1)
                per_plugin_gets.setdefault(plugin, []).append(key)

        # Handle gets first
        if per_plugin_gets:
            for plugin, keys in per_plugin_gets.items():
                cfg = load_full_config().get(plugin, {}) if load_full_config() else {}
                for key in keys:
                    if key in cfg:
                        typer.echo(f"{plugin}.{key} = {cfg.get(key)}")
                    else:
                        typer.echo(f"{plugin}.{key} = <not set>")

        # Then handle sets
        if per_plugin_sets:
            for plugin, kvs in per_plugin_sets.items():
                update_config(plugin, kvs)
