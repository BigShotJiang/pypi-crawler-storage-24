from unittest.mock import MagicMock, patch
from infra.utils.aws import get_aws_identity


@patch("shutil.which", return_value="/usr/bin/aws")
@patch("subprocess.run")
def test_get_aws_identity_success(mock_run, mock_which):
    mock_run.return_value = MagicMock(
        returncode=0,
        stdout='{"Account": "123456789012", "Arn": "arn:aws:sts::123456789012:caller-identity"}',
    )

    identity, error = get_aws_identity()
    assert identity["Account"] == "123456789012"
    assert error is None


@patch("shutil.which", return_value=None)
def test_get_aws_identity_no_cli(mock_which):
    identity, error = get_aws_identity()
    assert identity is None
    assert "not found" in error


@patch("shutil.which", return_value="/usr/bin/aws")
@patch("subprocess.run")
def test_get_aws_identity_failure(mock_run, mock_which):
    mock_run.return_value = MagicMock(returncode=1, stderr="Error message from AWS")

    identity, error = get_aws_identity()
    assert identity is None
    assert "Error message from AWS" in error
