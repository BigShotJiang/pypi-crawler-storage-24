import pytest
import os
from unittest.mock import MagicMock, patch
from infra.plugins.github import GithubPlugin


@pytest.fixture
def github_plugin():
    return GithubPlugin()


@pytest.fixture
def mock_args():
    args = MagicMock()
    args.create = False
    return args


def test_check_dependencies(github_plugin):
    deps = github_plugin.check_dependencies()
    assert deps == {}


@patch("shutil.copy2")
@patch("shutil.copytree")
@patch("os.listdir")
@patch("os.path.exists")
def test_run_github_create(
    mock_exists, mock_listdir, mock_copytree, mock_copy2, github_plugin, mock_args
):
    mock_args.create = True
    mock_listdir.return_value = ["README.md", ".github"]

    # Mocking that the source exists and destinations don't
    mock_exists.side_effect = lambda path: (
        "templates/github" in path or not os.path.basename(path)
    )

    with patch.object(
        GithubPlugin, "_get_resource_path", return_value="/src/templates/github"
    ):
        github_plugin.run(mock_args, abs_path="/tmp/repo")

        # Check if listdir was called on source
        mock_listdir.assert_called_with("/src/templates/github")

        # Check if files/dirs were copied
        assert mock_copy2.called or mock_copytree.called
