import pytest
from unittest.mock import MagicMock, patch
from infra.plugins.config import ConfigPlugin


@pytest.fixture
def config_plugin():
    return ConfigPlugin()


@pytest.fixture
def mock_args():
    args = MagicMock()
    args.tg_args = []
    return args


def test_check_dependencies(config_plugin):
    assert config_plugin.check_dependencies() == {}


@patch("infra.plugins.config.load_full_config")
def test_run_config_show_all(mock_load, config_plugin, mock_args):
    mock_load.return_value = {"test_plugin": {"key": "value"}}

    from io import StringIO
    import sys

    saved_stdout = sys.stdout
    try:
        sys.stdout = out = StringIO()
        config_plugin.run(mock_args)
        output = out.getvalue()
        assert "Configuration initialized" in output
        assert '"test_plugin": {' in output
    finally:
        sys.stdout = saved_stdout


@patch("infra.plugins.config.load_full_config")
def test_run_config_get_value(mock_load, config_plugin, mock_args):
    mock_load.return_value = {"test_plugin": {"key": "value"}}
    mock_args.tg_args = ["test_plugin.key"]

    from io import StringIO
    import sys

    saved_stdout = sys.stdout
    try:
        sys.stdout = out = StringIO()
        config_plugin.run(mock_args)
        output = out.getvalue()
        assert "test_plugin.key = value" in output
    finally:
        sys.stdout = saved_stdout


@patch("infra.plugins.config.update_config")
def test_run_config_set_value(mock_update, config_plugin, mock_args):
    mock_args.tg_args = ["test_plugin.key=new_value"]
    config_plugin.run(mock_args)
    mock_update.assert_called_with("test_plugin", ["key=new_value"])


def test_run_config_invalid_format(config_plugin, mock_args):
    mock_args.tg_args = ["invalid_format"]

    from io import StringIO
    import sys

    saved_stdout = sys.stdout
    try:
        sys.stdout = out = StringIO()
        with patch("infra.plugins.config.load_full_config"):
            config_plugin.run(mock_args)
        output = out.getvalue()
        assert "Invalid config entry" in output
    finally:
        sys.stdout = saved_stdout
