import pytest
from unittest.mock import MagicMock, patch
from infra.plugins.packer import PackerPlugin


@pytest.fixture
def packer_plugin():
    return PackerPlugin()


@pytest.fixture
def mock_args():
    args = MagicMock()
    args.init = False
    args.apply = False
    args.tg_args = []
    args.dry_run = False
    args.profile = None
    args.verbose = False
    return args


def test_check_dependencies(packer_plugin):
    with patch("shutil.which", side_effect=["/usr/bin/packer", "/usr/bin/aws"]):
        deps = packer_plugin.check_dependencies()
        assert deps["packer"] == "/usr/bin/packer"
        assert deps["aws"] == "/usr/bin/aws"


@patch("subprocess.run")
@patch("infra.plugins.packer.load_plugin_config")
def test_run_packer_validate(mock_config, mock_run, packer_plugin, mock_args):
    mock_config.return_value = {"headless": True}
    packer_plugin.run(mock_args)

    args, kwargs = mock_run.call_args
    assert "packer" in args[0]
    assert "validate" in args[0]


@patch("subprocess.run")
@patch("infra.plugins.packer.load_plugin_config")
def test_run_packer_build(mock_config, mock_run, packer_plugin, mock_args):
    mock_args.apply = True
    mock_config.return_value = {"headless": True, "on_error": "cleanup"}
    packer_plugin.run(mock_args)

    args, kwargs = mock_run.call_args
    assert "packer" in args[0]
    assert "build" in args[0]
    assert "-force" in args[0]
    assert "-on-error=cleanup" in args[0]


@patch("subprocess.run")
@patch("infra.plugins.packer.load_plugin_config")
def test_run_packer_init(mock_config, mock_run, packer_plugin, mock_args):
    mock_config.return_value = {"headless": True}
    mock_args.init = True
    packer_plugin.run(mock_args)

    args, kwargs = mock_run.call_args
    assert "packer" in args[0]
    assert "init" in args[0]
