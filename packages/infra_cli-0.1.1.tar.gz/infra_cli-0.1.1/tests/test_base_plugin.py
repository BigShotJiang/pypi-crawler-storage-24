import pytest
from infra.plugins.base import BasePlugin


class MockPlugin(BasePlugin):
    name = "mock"

    def check_dependencies(self):
        return {}

    def run(self, args, abs_path):
        pass


@pytest.fixture
def base_plugin():
    return MockPlugin()


def test_get_resource_path(base_plugin):
    # Test that it returns a path containing 'templates'
    path = base_plugin._get_resource_path("ansible")
    assert "templates" in str(path)
    assert "ansible" in str(path)


def test_base_plugin_abstract():
    # BasePlugin cannot be instantiated directly if we use ABC (optional but good practice)
    # Here we check that inheriting without implementing raises Error
    class IncompletePlugin(BasePlugin):
        pass

    plugin = IncompletePlugin()
    with pytest.raises(NotImplementedError):
        plugin.check_dependencies()
    with pytest.raises(NotImplementedError):
        plugin.run(None, None)
