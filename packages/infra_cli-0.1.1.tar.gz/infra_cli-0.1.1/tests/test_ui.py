import typer
from unittest.mock import patch
from infra.utils.ui import (
    print_info,
    print_success,
    print_warning,
    print_error,
    print_header,
    print_stat,
    format_env,
)


@patch("typer.secho")
def test_print_info(mock_secho):
    print_info("test message")
    mock_secho.assert_called_with("ℹ️ test message", fg=typer.colors.CYAN)


@patch("typer.secho")
def test_print_success(mock_secho):
    print_success("test message")
    mock_secho.assert_called_with("✅ test message", fg=typer.colors.GREEN)


@patch("typer.secho")
def test_print_warning(mock_secho):
    print_warning("test message")
    mock_secho.assert_called_with("⚠️ test message", fg=typer.colors.YELLOW)


@patch("typer.secho")
def test_print_error(mock_secho):
    print_error("test message")
    mock_secho.assert_called_with("❌ test message", fg=typer.colors.RED, err=True)


@patch("typer.secho")
def test_print_header(mock_secho):
    print_header("test title")
    mock_secho.assert_called_with("test title", bold=True, fg=typer.colors.CYAN)


@patch("typer.secho")
@patch("typer.echo")
def test_print_stat(mock_echo, mock_secho):
    print_stat("label", "value", color=typer.colors.BLUE)
    mock_secho.assert_called_with("value", fg=typer.colors.BLUE)


def test_format_env():
    formatted = format_env("dev")
    assert "dev" in formatted

    formatted_none = format_env(None)
    assert "N/A" in formatted_none
