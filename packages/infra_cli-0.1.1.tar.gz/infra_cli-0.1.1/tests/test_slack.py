import pytest
from unittest.mock import MagicMock, patch
from infra.plugins.slack import SlackPlugin


@pytest.fixture
def slack_plugin():
    return SlackPlugin()


@pytest.fixture
def mock_args():
    args = MagicMock()
    args.tg_args = []
    return args


def test_check_dependencies(slack_plugin):
    assert slack_plugin.check_dependencies() == {}


@patch("infra.plugins.slack.load_plugin_config")
def test_run_slack_no_args(mock_config, slack_plugin, mock_args):
    mock_config.return_value = {}
    with patch("typer.secho") as mock_secho, patch("typer.echo") as mock_echo:
        slack_plugin.run(mock_args)
        # Should show help via print_header and print_info (which use secho/echo)
        output = str(mock_secho.call_args_list) + str(mock_echo.call_args_list)
        assert "Slack Plugin Usage" in output
        assert "infra slack post" in output


@patch("urllib.request.urlopen")
@patch("infra.plugins.slack.load_plugin_config")
def test_slack_post_success(mock_config, mock_urlopen, slack_plugin, mock_args):
    mock_config.return_value = {"webhook_url": "http://hooks.slack.com/test"}
    mock_args.tg_args = ["post", "hello world"]

    # Mock successful response
    mock_response = MagicMock()
    mock_response.status = 200
    mock_urlopen.return_value.__enter__.return_value = mock_response

    with patch("typer.secho") as mock_secho:
        slack_plugin.run(mock_args)
        assert any(
            "posted successfully" in str(call) for call in mock_secho.call_args_list
        )

    # Verify urlopen was called with correct data
    args, kwargs = mock_urlopen.call_args
    req = args[0]
    assert req.full_url == "http://hooks.slack.com/test"
    assert b"hello world" in req.data


@patch("infra.plugins.slack.load_plugin_config")
def test_slack_post_no_config(mock_config, slack_plugin, mock_args):
    mock_config.return_value = {}  # No webhook
    mock_args.tg_args = ["post", "test"]

    with patch("typer.secho") as mock_secho:
        slack_plugin.run(mock_args)
        assert any("not configured" in str(call) for call in mock_secho.call_args_list)
