import os
import tempfile
from pathlib import Path

import pytest
from infra.plugins.python_plugin import (
    PythonPlugin,
    _project_to_slug,
    _make_pyproject,
    _make_readme,
)


def test_project_to_slug():
    assert _project_to_slug("learn-python") == "learn_python"
    assert _project_to_slug("Learn Python") == "learn_python"
    assert _project_to_slug("my_app") == "my_app"
    assert _project_to_slug("a") == "a"


def test_make_pyproject():
    content = _make_pyproject("learn-python", "learn_python")
    assert "name = \"learn-python\"" in content
    assert "where = [\"src\"]" in content
    assert "learn_python" not in content or "learn_python" in content  # slug may appear in description


def test_make_readme():
    content = _make_readme("learn-python", "learn_python")
    assert "learn-python" in content
    assert "learn_python" in content
    assert "Official" in content or "Docs" in content
    assert "LEARNING_PATH" in content or "learning path" in content.lower()


@pytest.fixture
def python_plugin():
    return PythonPlugin()


def test_check_dependencies(python_plugin):
    deps = python_plugin.check_dependencies()
    assert "python3" in deps


def test_run_creates_scaffold(python_plugin):
    args = type("Args", (), {"project": "learn-python", "tg_args": []})()
    with tempfile.TemporaryDirectory() as tmp:
        prev = os.getcwd()
        try:
            os.chdir(tmp)
            python_plugin.run(args, None)
            base = Path(tmp) / "learn-python"
            assert base.exists()
            assert (base / "src" / "learn_python" / "__init__.py").exists()
            assert (base / "tests" / "test_example.py").exists()
            assert (base / "pyproject.toml").exists()
            assert (base / "README.md").exists()
            assert (base / ".gitignore").exists()
        finally:
            os.chdir(prev)
