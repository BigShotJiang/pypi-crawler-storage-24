import pytest
from unittest.mock import MagicMock, patch
from infra.plugins.terragrunt import TerragruntPlugin


@pytest.fixture
def tg_plugin():
    return TerragruntPlugin()


@pytest.fixture
def mock_args():
    args = MagicMock()
    args.env = "test"
    args.project = "my-project"
    args.region = "ap-northeast-1"
    args.service = "s3/test"
    args.create = True
    return args


@patch("os.makedirs")
@patch("os.path.isdir", return_value=False)
@patch("os.path.exists", return_value=False)
@patch("builtins.open")
def test_handle_scaffolding(
    mock_open, mock_exists, mock_isdir, mock_makedirs, tg_plugin, mock_args
):
    abs_path = "/tmp/test/my-project/ap-northeast-1/s3/test"

    tg_plugin._handle_scaffolding(mock_args, abs_path)

    # Verify directories created
    assert mock_makedirs.called
    # Verify files opened for writing (root tg, env.hcl, region.hcl, leaf tg)
    assert mock_open.call_count >= 4

    # Verify root-level creation attempt
    mock_exists.assert_any_call("terragrunt.hcl")
