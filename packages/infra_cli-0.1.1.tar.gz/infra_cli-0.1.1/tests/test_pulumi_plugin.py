import pytest
from unittest.mock import MagicMock, patch
from infra.plugins.pulumi import PulumiPlugin


@pytest.fixture
def pulumi_plugin():
    return PulumiPlugin()


@pytest.fixture
def mock_args():
    args = MagicMock()
    args.init = False
    args.apply = False
    args.tg_args = []
    args.dry_run = False
    args.profile = None
    args.verbose = False
    return args


def test_check_dependencies(pulumi_plugin):
    with patch("shutil.which", side_effect=["/usr/bin/pulumi", "/usr/bin/aws"]):
        deps = pulumi_plugin.check_dependencies()
        assert deps["pulumi"] == "/usr/bin/pulumi"
        assert deps["aws"] == "/usr/bin/aws"


@patch("subprocess.run")
@patch("infra.plugins.pulumi.load_plugin_config")
def test_run_pulumi_preview(mock_config, mock_run, pulumi_plugin, mock_args):
    mock_config.return_value = {}
    pulumi_plugin.run(mock_args)

    args, kwargs = mock_run.call_args
    assert "pulumi" in args[0]
    assert "preview" in args[0]


@patch("subprocess.run")
@patch("infra.plugins.pulumi.load_plugin_config")
def test_run_pulumi_up(mock_config, mock_run, pulumi_plugin, mock_args):
    mock_args.apply = True
    mock_config.return_value = {"auto_approve": True}
    pulumi_plugin.run(mock_args)

    args, kwargs = mock_run.call_args
    assert "pulumi" in args[0]
    assert "up" in args[0]
    assert "--yes" in args[0]


@patch("subprocess.run")
@patch("infra.plugins.pulumi.load_plugin_config")
def test_run_pulumi_login(mock_config, mock_run, pulumi_plugin, mock_args):
    mock_args.init = True
    mock_config.return_value = {"backend_url": "s3://my-bucket"}
    pulumi_plugin.run(mock_args)

    args, kwargs = mock_run.call_args
    assert "pulumi" in args[0]
    assert "login" in args[0]
    assert "s3://my-bucket" in args[0]
