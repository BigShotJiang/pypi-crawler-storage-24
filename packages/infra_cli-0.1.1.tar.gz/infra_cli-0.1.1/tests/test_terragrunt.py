import os
import pytest
from unittest.mock import MagicMock, patch
from infra.plugins.terragrunt import (
    TerragruntPlugin,
    TG_AWS_INFRA_PATH_TEMPLATE,
    build_tg_aws_path,
)


@pytest.fixture
def tg_plugin():
    return TerragruntPlugin()


@pytest.fixture
def mock_args():
    args = MagicMock()
    args.init = False
    args.apply = False
    args.tg_args = []
    args.dry_run = False
    args.profile = None
    args.verbose = False
    return args


def test_tg_aws_infra_path_template():
    assert "account" in TG_AWS_INFRA_PATH_TEMPLATE
    assert "region" in TG_AWS_INFRA_PATH_TEMPLATE
    assert "env" in TG_AWS_INFRA_PATH_TEMPLATE
    assert "name" in TG_AWS_INFRA_PATH_TEMPLATE


def test_build_tg_aws_path():
    p = build_tg_aws_path(
        account="123456789012",
        region="ap-northeast-1",
        env="prod",
        name="vpc",
    )
    assert p == os.path.join("123456789012", "ap-northeast-1", "prod", "vpc")

    p2 = build_tg_aws_path(account="demo", region="us-east-1", env="test", name="s3/example")
    assert "demo" in p2 and "us-east-1" in p2 and "test" in p2 and "s3" in p2

    p3 = build_tg_aws_path(env="dev", name="web")
    assert p3 == os.path.join("dev", "web")

    assert build_tg_aws_path() == "."


def test_check_dependencies(tg_plugin):
    with patch(
        "shutil.which", side_effect=["/usr/bin/tf", "/usr/bin/tg", "/usr/bin/aws"]
    ):
        deps = tg_plugin.check_dependencies()
        assert deps["terraform"] == "/usr/bin/tf"
        assert deps["terragrunt"] == "/usr/bin/tg"
        assert deps["aws"] == "/usr/bin/aws"


@patch("subprocess.run")
@patch("infra.plugins.terragrunt.load_plugin_config")
def test_run_tg_basic(mock_config, mock_run, tg_plugin, mock_args):
    mock_config.return_value = {"parallelism": 10}

    tg_plugin._run_tg(["plan"], "/tmp/test", mock_args)

    # Check if subprocess.run was called with correct command
    args, kwargs = mock_run.call_args
    assert "terragrunt" in args[0]
    assert "plan" in args[0]
    assert "--parallelism" in args[0]
    assert kwargs["cwd"] == "/tmp/test"
