import importlib


def _reload_config_module():
    import infra.utils.config as cfg

    importlib.reload(cfg)
    return cfg


def test_ensure_creates_yaml_by_default(tmp_path, monkeypatch):
    monkeypatch.setenv("HOME", str(tmp_path))
    # Ensure XDG_CONFIG_HOME is NOT set to avoid interference
    monkeypatch.delenv("XDG_CONFIG_HOME", raising=False)

    cfg = _reload_config_module()

    # Modern path: ~/.config/infra/config.yaml
    p_yaml = tmp_path / ".config" / "infra" / "config.yaml"
    # Legacy path (should not be created if .infra doesn't exist)
    p_legacy = tmp_path / ".infra" / "config.yaml"

    assert not p_yaml.exists()
    assert not p_legacy.exists()

    created = cfg.ensure_config_exists()
    assert created
    assert p_yaml.exists()

    full = cfg.load_full_config()
    assert "terragrunt" in full
    assert full["terragrunt"].get("project") == "demo-project"

def test_existing_yml_preserved(tmp_path, monkeypatch):
    monkeypatch.setenv("HOME", str(tmp_path))
    monkeypatch.delenv("XDG_CONFIG_HOME", raising=False)

    cfg = _reload_config_module()

    # Create legacy directory and file
    p_dir = tmp_path / ".infra"
    p_dir.mkdir()
    p_yml = p_dir / "config.yml"
    p_yml.write_text("terragrunt:\n  project: preserved\n")

    # Re-reload to pick up existence of .infra
    cfg = _reload_config_module()

    created = cfg.ensure_config_exists()
    assert not created

    p_yaml = p_dir / "config.yaml"
    assert not p_yaml.exists()

    full = cfg.load_full_config()
    assert full.get("terragrunt", {}).get("project") == "preserved"
