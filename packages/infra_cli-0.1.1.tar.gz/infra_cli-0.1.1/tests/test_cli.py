from unittest.mock import patch
from typer.testing import CliRunner
from infra.cli import app

runner = CliRunner()


def test_cli_help():
    result = runner.invoke(app, ["--help"])
    assert result.exit_code == 0
    assert "Infra CLI - A wrapper for infrastructure tools" in result.output


@patch("infra.cli.load_plugin_config")
@patch("infra.cli.ensure_config_exists")
def test_cli_tg_help(mock_ensure, mock_config):
    result = runner.invoke(app, ["tg", "--help"])
    assert result.exit_code == 0
    assert "Run Terragrunt commands" in result.output

@patch("infra.cli.load_plugin_config")
@patch("infra.cli.ensure_config_exists")
@patch("infra.plugins.terragrunt.TerragruntPlugin.check_dependencies")
def test_cli_missing_dependencies(mock_deps, mock_ensure, mock_load_config):
    mock_load_config.return_value = {"enabled": True}
    mock_deps.return_value = {"terragrunt": None, "aws": "/usr/bin/aws"}
    result = runner.invoke(app, ["tg", "-s", "test"])
    assert result.exit_code == 127
    assert "Missing required dependencies for 'terragrunt'" in result.output

@patch("infra.cli.load_plugin_config")
@patch("infra.cli.ensure_config_exists")
def test_cli_disabled_plugin(mock_ensure, mock_load_config):
    mock_load_config.return_value = {"enabled": False}
    # Attempt to run a plugin that is disabled
    result = runner.invoke(app, ["tg", "-s", "test"])
    assert result.exit_code == 0
    assert "is disabled in configuration" in result.output
