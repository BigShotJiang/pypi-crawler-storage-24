import pytest
from unittest.mock import MagicMock, patch
from infra.plugins.aws_sso import AwsSsoPlugin


@pytest.fixture
def sso_plugin():
    return AwsSsoPlugin()


@pytest.fixture
def mock_args():
    args = MagicMock()
    args.profile = "test-profile"
    args.sync = False
    args.credentials = False
    args.use_device_code = False
    args.verbose = False
    args.dry_run = False
    return args


def test_check_dependencies(sso_plugin):
    with patch("shutil.which", return_value="/usr/local/bin/aws"):
        deps = sso_plugin.check_dependencies()
        assert deps["aws"] == "/usr/local/bin/aws"
        assert "boto3" in deps


@patch("subprocess.run")
def test_get_sso_info(mock_run, sso_plugin):
    mock_run.side_effect = [
        MagicMock(stdout="https://portal.awsapps.com/start", returncode=0),
        MagicMock(stdout="us-east-1", returncode=0),
        MagicMock(stdout="main-session", returncode=0),
    ]

    info = sso_plugin._get_sso_info("test-profile")
    assert info["start_url"] == "https://portal.awsapps.com/start"
    assert info["region"] == "us-east-1"
    assert info["session"] == "main-session"


def test_get_sso_token_no_files(sso_plugin):
    with patch("glob.glob", return_value=[]):
        token = sso_plugin._get_sso_token("https://portal.awsapps.com/start")
        assert token is None
