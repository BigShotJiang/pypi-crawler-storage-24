import pytest
from unittest.mock import MagicMock, patch
from infra.plugins.ansible import AnsiblePlugin


@pytest.fixture
def ansible_plugin():
    return AnsiblePlugin()


@pytest.fixture
def mock_args():
    args = MagicMock()
    args.create = False
    args.dry_run = False
    args.profile = None
    args.verbose = False
    args.tg_args = []
    return args


def test_check_dependencies(ansible_plugin):
    with patch("shutil.which", side_effect=["/usr/bin/ansible-playbook"]):
        deps = ansible_plugin.check_dependencies()
        assert deps["ansible-playbook"] == "/usr/bin/ansible-playbook"


@patch("subprocess.run")
@patch("infra.plugins.ansible.load_plugin_config")
def test_run_ansible_basic(mock_config, mock_run, ansible_plugin, mock_args):
    mock_config.return_value = {"inventory": "inventory.ini"}

    with patch("os.path.exists", return_value=True):
        ansible_plugin.run(mock_args)

        args, kwargs = mock_run.call_args
        assert "ansible-playbook" in args[0]
        assert "-i" in args[0]
        assert "inventory.ini" in args[0]
        assert "site.yml" in args[0]


@patch("shutil.copytree")
@patch("infra.plugins.ansible.load_plugin_config")
def test_ansible_scaffolding(mock_config, mock_copy, ansible_plugin, mock_args):
    mock_config.return_value = {}
    mock_args.create = True
    with (
        patch("os.path.exists", return_value=False),
        patch.object(
            AnsiblePlugin, "_get_resource_path", return_value="/src/templates/ansible"
        ),
    ):
        ansible_plugin.run(mock_args, abs_path="/tmp/test")
        mock_copy.assert_called_once()
        assert "/tmp/test/ansible" in mock_copy.call_args[0]


def test_run_ansible_dry_run(ansible_plugin, mock_args):
    mock_args.dry_run = True
    with (
        patch("infra.plugins.ansible.load_plugin_config", return_value={}),
        patch("os.path.exists", return_value=True),
        patch("subprocess.run") as mock_run,
    ):
        ansible_plugin.run(mock_args)
        # subprocess.run should NOT be called in dry-run
        mock_run.assert_not_called()


@patch("subprocess.run")
@patch("infra.plugins.ansible.load_plugin_config", return_value={})
def test_run_ansible_with_extra_args(mock_config, mock_run, ansible_plugin, mock_args):
    mock_args.tg_args = ["--tags", "test", "-v"]

    with patch("os.path.exists", return_value=True):
        ansible_plugin.run(mock_args)

        args, _ = mock_run.call_args
        assert "--tags" in args[0]
        assert "test" in args[0]
        assert "-v" in args[0]
