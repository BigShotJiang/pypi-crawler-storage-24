import pytest
from unittest.mock import MagicMock, patch
from infra.plugins.setup import SetupPlugin


@pytest.fixture
def setup_plugin():
    return SetupPlugin()


@pytest.fixture
def mock_args():
    args = MagicMock()
    args.create = False
    args.dry_run = False
    args.list = False
    args.tg_args = []
    return args


def test_check_dependencies(setup_plugin):
    with (
        patch("platform.system", return_value="Darwin"),
        patch(
            "shutil.which", side_effect=["/usr/bin/ansible-playbook", "/usr/bin/brew"]
        ),
    ):
        deps = setup_plugin.check_dependencies()
        assert deps["ansible-playbook"] == "/usr/bin/ansible-playbook"
        assert deps["brew"] == "/usr/bin/brew"


@patch("subprocess.run")
@patch("infra.plugins.setup.load_plugin_config")
@patch("typer.confirm", return_value=True)
@patch("infra.plugins.setup.SetupPlugin._install_user_templates")
@patch("infra.plugins.setup.SetupPlugin._ensure_platform_prereqs")
@patch("infra.plugins.setup.SetupPlugin._has_gpg_keys", return_value=True)
@patch("infra.plugins.setup.SetupPlugin._has_ssh_keys", return_value=True)
def test_run_setup_basic(
    mock_ssh,
    mock_gpg,
    mock_prereqs,
    mock_templates,
    mock_confirm,
    mock_config,
    mock_run,
    setup_plugin,
    mock_args,
):
    mock_config.return_value = {"user_name": "test", "user_email": "test@local"}

    with patch("os.path.exists", return_value=True):
        setup_plugin.run(mock_args)

        # Check if subprocess.run was called for ansible-playbook
        assert mock_run.called
        args, kwargs = mock_run.call_args
        cmd = args[0]
        assert "ansible-playbook" in cmd[0]
        assert "setup.yml" in cmd
        assert "user_name='test'" in str(cmd)


@patch("shutil.copytree")
def test_run_setup_create(mock_copy, setup_plugin, mock_args):
    mock_args.create = True
    with (
        patch.object(
            SetupPlugin, "_get_resource_path", return_value="/src/templates/ansible"
        ),
        patch("os.path.exists", return_value=False),
    ):
        setup_plugin.run(mock_args, abs_path="/tmp/target")
        mock_copy.assert_called_once()
        assert "/tmp/target/ansible" in mock_copy.call_args[0]


@patch("typer.prompt")
@patch("infra.plugins.setup.update_config")
@patch("infra.plugins.setup.load_plugin_config", return_value={})
@patch("infra.plugins.setup.SetupPlugin._get_user_vars", return_value={})
@patch("typer.confirm", return_value=True)
@patch("infra.plugins.setup.SetupPlugin._install_user_templates")
@patch("infra.plugins.setup.SetupPlugin._ensure_platform_prereqs")
@patch("infra.plugins.setup.SetupPlugin._has_gpg_keys", return_value=True)
@patch("infra.plugins.setup.SetupPlugin._has_ssh_keys", return_value=True)
@patch("subprocess.run")
def test_run_setup_prompts(
    mock_run,
    mock_ssh,
    mock_gpg,
    mock_prereqs,
    mock_templates,
    mock_confirm,
    mock_vars,
    mock_config,
    mock_update,
    mock_prompt,
    setup_plugin,
    mock_args,
):
    # Mocking user input for name and email
    mock_prompt.side_effect = ["John Doe", "john@example.com"]

    with patch("os.path.exists", return_value=True):
        setup_plugin.run(mock_args)

        # Should prompt twice (name and email)
        assert mock_prompt.call_count == 2
        # Should update config twice
        assert mock_update.call_count == 2

        # Check if subprocess.run used the prompted values
        assert mock_run.called
        args, _ = mock_run.call_args
        cmd = args[0]
        assert "user_name='John Doe'" in str(cmd)
        assert "user_email='john@example.com'" in str(cmd)


@patch("typer.prompt")
@patch("infra.plugins.setup.load_plugin_config")
@patch("typer.confirm", return_value=True)
@patch("infra.plugins.setup.SetupPlugin._install_user_templates")
@patch("infra.plugins.setup.SetupPlugin._ensure_platform_prereqs")
@patch("infra.plugins.setup.SetupPlugin._has_gpg_keys", return_value=False)
@patch("infra.plugins.setup.SetupPlugin._has_ssh_keys", return_value=True)
@patch("subprocess.run")
def test_run_setup_passphrase_prompt(
    mock_run,
    mock_ssh,
    mock_gpg,
    mock_prereqs,
    mock_templates,
    mock_confirm,
    mock_config,
    mock_prompt,
    setup_plugin,
    mock_args,
):
    mock_config.return_value = {"user_name": "test", "user_email": "test@local"}
    mock_prompt.return_value = "secret"

    with patch("os.path.exists", return_value=True):
        setup_plugin.run(mock_args)

        # Prompt should be called once for passphrase
        mock_prompt.assert_called_with(
            "Enter Passphrase for new keys (leave empty for none)",
            hide_input=True,
            default="",
        )

        # Check if passphrase was passed via a temporary file to ansible
        args, _ = mock_run.call_args
        assert any("-e" == arg for arg in args[0])
        assert any(arg.startswith("@") and arg.endswith(".json") for arg in args[0])
        assert "gpg_passphrase='secret'" not in str(args[0])
