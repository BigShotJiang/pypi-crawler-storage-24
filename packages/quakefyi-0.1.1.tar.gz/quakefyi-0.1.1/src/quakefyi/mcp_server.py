"""MCP server for quakefyi — AI assistant tools for quakefyi.com.

Run: uvx --from "quakefyi[mcp]" python -m quakefyi.mcp_server
"""
from __future__ import annotations

from mcp.server.fastmcp import FastMCP

mcp = FastMCP("QuakeFYI")


@mcp.tool()
def list_earthquakes(limit: int = 20, offset: int = 0) -> str:
    """List earthquakes from quakefyi.com.

    Args:
        limit: Maximum number of results. Default 20.
        offset: Number of results to skip. Default 0.
    """
    from quakefyi.api import QuakeFYI

    with QuakeFYI() as api:
        data = api.list_earthquakes(limit=limit, offset=offset)
        results = data.get("results", data) if isinstance(data, dict) else data
        if not results:
            return "No earthquakes found."
        items = results[:limit] if isinstance(results, list) else []
        return "\n".join(f"- {item.get('name', item.get('slug', '?'))}" for item in items)


@mcp.tool()
def get_earthquake(slug: str) -> str:
    """Get detailed information about a specific earthquake.

    Args:
        slug: URL slug identifier for the earthquake.
    """
    from quakefyi.api import QuakeFYI

    with QuakeFYI() as api:
        data = api.get_earthquake(slug)
        return str(data)


@mcp.tool()
def list_plates(limit: int = 20, offset: int = 0) -> str:
    """List plates from quakefyi.com.

    Args:
        limit: Maximum number of results. Default 20.
        offset: Number of results to skip. Default 0.
    """
    from quakefyi.api import QuakeFYI

    with QuakeFYI() as api:
        data = api.list_plates(limit=limit, offset=offset)
        results = data.get("results", data) if isinstance(data, dict) else data
        if not results:
            return "No plates found."
        items = results[:limit] if isinstance(results, list) else []
        return "\n".join(f"- {item.get('name', item.get('slug', '?'))}" for item in items)


@mcp.tool()
def search_quake(query: str) -> str:
    """Search quakefyi.com for earthquakes, tectonic plates, and seismic data.

    Args:
        query: Search query string.
    """
    from quakefyi.api import QuakeFYI

    with QuakeFYI() as api:
        data = api.search(query)
        results = data.get("results", data) if isinstance(data, dict) else data
        if not results:
            return f"No results found for \"{query}\"."
        items = results[:10] if isinstance(results, list) else []
        return "\n".join(f"- {item.get('name', item.get('slug', '?'))}" for item in items)


def main() -> None:
    """Run the MCP server."""
    mcp.run()


if __name__ == "__main__":
    main()
