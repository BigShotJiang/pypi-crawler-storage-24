"""Python API client for quakefyi.com."""

__version__ = "0.1.0"
