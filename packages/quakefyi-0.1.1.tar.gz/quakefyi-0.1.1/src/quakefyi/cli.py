"""Command-line interface for quakefyi."""

from __future__ import annotations

import json

import typer

from quakefyi.api import QuakeFYI

app = typer.Typer(help="QuakeFYI — Earthquake seismic data and tectonic plates API client.")


@app.command()
def search(query: str) -> None:
    """Search quakefyi.com."""
    with QuakeFYI() as api:
        result = api.search(query)
        typer.echo(json.dumps(result, indent=2))
