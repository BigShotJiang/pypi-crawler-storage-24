"""HTTP API client for quakefyi.com REST endpoints.

Requires the ``api`` extra: ``pip install quakefyi[api]``

Usage::

    from quakefyi.api import QuakeFYI

    with QuakeFYI() as api:
        items = api.list_case_studies()
        detail = api.get_case_study("example-slug")
        results = api.search("query")
"""

from __future__ import annotations

from typing import Any

import httpx


class QuakeFYI:
    """API client for the quakefyi.com REST API.

    Provides typed access to all quakefyi.com endpoints including
    list, detail, and search operations.

    Args:
        base_url: API base URL. Defaults to ``https://quakefyi.com``.
        timeout: Request timeout in seconds. Defaults to ``10.0``.
    """

    def __init__(
        self,
        base_url: str = "https://quakefyi.com",
        timeout: float = 10.0,
    ) -> None:
        self._client = httpx.Client(base_url=base_url, timeout=timeout)

    def _get(self, path: str, **params: Any) -> dict[str, Any]:
        resp = self._client.get(
            path,
            params={k: v for k, v in params.items() if v is not None},
        )
        resp.raise_for_status()
        result: dict[str, Any] = resp.json()
        return result

    # -- Endpoints -----------------------------------------------------------

    def list_case_studies(self, **params: Any) -> dict[str, Any]:
        """List all case studies."""
        return self._get("/api/v1/case-studies/", **params)

    def get_case_study(self, slug: str) -> dict[str, Any]:
        """Get case study by slug."""
        return self._get(f"/api/v1/case-studies/" + slug + "/")

    def list_countries(self, **params: Any) -> dict[str, Any]:
        """List all countries."""
        return self._get("/api/v1/countries/", **params)

    def get_country(self, slug: str) -> dict[str, Any]:
        """Get country by slug."""
        return self._get(f"/api/v1/countries/" + slug + "/")

    def list_earthquakes(self, **params: Any) -> dict[str, Any]:
        """List all earthquakes."""
        return self._get("/api/v1/earthquakes/", **params)

    def get_earthquake(self, slug: str) -> dict[str, Any]:
        """Get earthquake by slug."""
        return self._get(f"/api/v1/earthquakes/" + slug + "/")

    def list_faqs(self, **params: Any) -> dict[str, Any]:
        """List all faqs."""
        return self._get("/api/v1/faqs/", **params)

    def get_faq(self, slug: str) -> dict[str, Any]:
        """Get faq by slug."""
        return self._get(f"/api/v1/faqs/" + slug + "/")

    def list_faults(self, **params: Any) -> dict[str, Any]:
        """List all faults."""
        return self._get("/api/v1/faults/", **params)

    def get_fault(self, slug: str) -> dict[str, Any]:
        """Get fault by slug."""
        return self._get(f"/api/v1/faults/" + slug + "/")

    def list_glossary(self, **params: Any) -> dict[str, Any]:
        """List all glossary."""
        return self._get("/api/v1/glossary/", **params)

    def get_term(self, slug: str) -> dict[str, Any]:
        """Get term by slug."""
        return self._get(f"/api/v1/glossary/" + slug + "/")

    def list_guides(self, **params: Any) -> dict[str, Any]:
        """List all guides."""
        return self._get("/api/v1/guides/", **params)

    def get_guide(self, slug: str) -> dict[str, Any]:
        """Get guide by slug."""
        return self._get(f"/api/v1/guides/" + slug + "/")

    def list_historical(self, **params: Any) -> dict[str, Any]:
        """List all historical."""
        return self._get("/api/v1/historical/", **params)

    def get_historical(self, slug: str) -> dict[str, Any]:
        """Get historical by slug."""
        return self._get(f"/api/v1/historical/" + slug + "/")

    def list_plates(self, **params: Any) -> dict[str, Any]:
        """List all plates."""
        return self._get("/api/v1/plates/", **params)

    def get_plate(self, slug: str) -> dict[str, Any]:
        """Get plate by slug."""
        return self._get(f"/api/v1/plates/" + slug + "/")

    def list_yearly_summaries(self, **params: Any) -> dict[str, Any]:
        """List all yearly summaries."""
        return self._get("/api/v1/yearly-summaries/", **params)

    def get_yearly_summary(self, slug: str) -> dict[str, Any]:
        """Get yearly summary by slug."""
        return self._get(f"/api/v1/yearly-summaries/" + slug + "/")

    def search(self, query: str, **params: Any) -> dict[str, Any]:
        """Search across all content."""
        return self._get(f"/api/v1/search/", q=query, **params)

    # -- Lifecycle -----------------------------------------------------------

    def close(self) -> None:
        """Close the underlying HTTP client."""
        self._client.close()

    def __enter__(self) -> QuakeFYI:
        return self

    def __exit__(self, *_: object) -> None:
        self.close()
