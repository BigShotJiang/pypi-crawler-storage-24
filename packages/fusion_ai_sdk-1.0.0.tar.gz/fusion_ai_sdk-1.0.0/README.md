## install all dependencies

```bash
uv sync --dev
```
Tool definitions format:
# ==================== TOOL DEFINITION ====================
# Tools are defined in OpenAI format as plain dictionaries.
# This format is compatible across all providers (OpenAI, Gemini, Ollama).
#
# Example tool definition:
# {
#     "type": "function",
#     "function": {
#         "name": "get_weather",
#         "description": "Get the current weather for a location",
#         "parameters": {
#             "type": "object",
#             "properties": {
#                 "location": {"type": "string", "description": "City name"},
#                 "unit": {"type": "string", "enum": ["celsius", "fahrenheit"]}
#             },
#             "required": ["location"],
#             "additionalProperties": False
#         },
#         "strict": True  # Optional: Enable strict schema adherence (OpenAI only)
#     }
# }

## Publishing to PyPI

This project uses `uv` for dependency management and packaging.

### 1. Build the Package
To build the distribution bundles (`.tar.gz` and `.whl`):
```bash
uv build
```
This generates the package files inside the `dist/` directory.

### 2. Publish to PyPI
To upload the built package to the Python Package Index, run:
```bash
uv publish
```
*(You will be prompted to supply your PyPI API token).*
