//! Real-valued field storage for FDTD simulations.
//!
//! Unlike the frequency-domain solver which uses complex fields, FDTD works
//! with real-valued electric and magnetic fields that evolve in time.
//!
//! # Field Components
//!
//! In 2D, we have 3 field components depending on polarization:
//!
//! - **TM**: Ez (scalar), Hx, Hy (vector)
//! - **TE**: Hz (scalar), Ex, Ey (vector)
//!
//! The `YeeFields2D` struct holds all components for a simulation.

use serde::{Deserialize, Serialize};

use crate::grid::Grid2D;
use crate::polarization::Polarization;

use super::yee_grid::YeeGrid2D;

/// Single real-valued field component on a 2D grid.
#[derive(Debug, Clone)]
pub struct RealField2D {
    grid: Grid2D,
    data: Vec<f32>,
}

impl RealField2D {
    /// Create a zero-initialized field.
    pub fn zeros(grid: Grid2D) -> Self {
        Self {
            data: vec![0.0; grid.len()],
            grid,
        }
    }

    /// Create from existing data.
    pub fn from_vec(grid: Grid2D, data: Vec<f32>) -> Self {
        assert_eq!(data.len(), grid.len(), "data length must match grid size");
        Self { grid, data }
    }

    /// Fill with a constant value.
    pub fn fill(&mut self, value: f64) {
        self.data.fill(value as f32);
    }

    /// Number of elements.
    #[inline]
    pub fn len(&self) -> usize {
        self.data.len()
    }

    /// Check if empty.
    #[inline]
    pub fn is_empty(&self) -> bool {
        self.data.is_empty()
    }

    /// Get the grid.
    #[inline]
    pub fn grid(&self) -> &Grid2D {
        &self.grid
    }

    /// Linear index from 2D indices.
    #[inline]
    pub fn idx(&self, ix: usize, iy: usize) -> usize {
        self.grid.idx(ix, iy)
    }

    /// Get value at indices.
    #[inline]
    pub fn get(&self, ix: usize, iy: usize) -> f64 {
        let idx = self.idx(ix, iy);
        self.data[idx] as f64
    }

    /// Set value at indices.
    #[inline]
    pub fn set(&mut self, ix: usize, iy: usize, value: f64) {
        let idx = self.idx(ix, iy);
        self.data[idx] = value as f32;
    }

    /// Add to value at indices.
    #[inline]
    pub fn add(&mut self, ix: usize, iy: usize, value: f64) {
        let idx = self.idx(ix, iy);
        self.data[idx] += value as f32;
    }

    /// Get underlying slice.
    #[inline]
    pub fn as_slice(&self) -> &[f32] {
        &self.data
    }

    /// Get mutable slice.
    #[inline]
    pub fn as_mut_slice(&mut self) -> &mut [f32] {
        &mut self.data
    }

    /// Access the internal data vector directly.
    #[inline]
    pub fn data(&self) -> &Vec<f32> {
        &self.data
    }

    /// Access the internal data vector mutable.
    #[inline]
    pub fn data_mut(&mut self) -> &mut Vec<f32> {
        &mut self.data
    }

    /// Maximum absolute value (useful for stability checks).
    pub fn max_abs(&self) -> f64 {
        self.data
            .iter()
            .map(|x| x.abs() as f64)
            .fold(0.0_f64, f64::max)
    }

    /// L2 norm of the field.
    pub fn norm(&self) -> f64 {
        self.data.iter().map(|x| (*x as f64) * (*x as f64)).sum::<f64>().sqrt()
    }

    /// Total energy (sum of squares).
    pub fn energy(&self) -> f64 {
        self.data.iter().map(|x| (*x as f64) * (*x as f64)).sum()
    }

    /// Scale all values by a factor.
    pub fn scale(&mut self, factor: f64) {
        let factor = factor as f32;
        for x in &mut self.data {
            *x *= factor;
        }
    }

    /// Add another field scaled by a factor: self += factor * other
    pub fn axpy(&mut self, factor: f64, other: &RealField2D) {
        assert_eq!(self.len(), other.len(), "field sizes must match");
        let factor = factor as f32;
        for (a, b) in self.data.iter_mut().zip(other.data.iter()) {
            *a += factor * b;
        }
    }
}

/// Identifier for field components.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize)]
pub enum FieldComponent {
    /// Electric field z-component (TM mode)
    Ez,
    /// Magnetic field x-component (TM mode)
    Hx,
    /// Magnetic field y-component (TM mode)
    Hy,
    /// Magnetic field z-component (TE mode)
    Hz,
    /// Electric field x-component (TE mode)
    Ex,
    /// Electric field y-component (TE mode)
    Ey,
}

impl FieldComponent {
    /// Get the polarization this component belongs to.
    pub fn polarization(&self) -> Polarization {
        match self {
            FieldComponent::Ez | FieldComponent::Hx | FieldComponent::Hy => Polarization::TM,
            FieldComponent::Hz | FieldComponent::Ex | FieldComponent::Ey => Polarization::TE,
        }
    }

    /// Check if this is an electric field component.
    pub fn is_electric(&self) -> bool {
        matches!(
            self,
            FieldComponent::Ez | FieldComponent::Ex | FieldComponent::Ey
        )
    }

    /// Check if this is a magnetic field component.
    pub fn is_magnetic(&self) -> bool {
        !self.is_electric()
    }

    /// Get the name of this component.
    pub fn name(&self) -> &'static str {
        match self {
            FieldComponent::Ez => "Ez",
            FieldComponent::Hx => "Hx",
            FieldComponent::Hy => "Hy",
            FieldComponent::Hz => "Hz",
            FieldComponent::Ex => "Ex",
            FieldComponent::Ey => "Ey",
        }
    }
}

/// All field components for a 2D FDTD simulation.
///
/// This struct holds the complete electromagnetic field state, organized
/// by polarization mode. The fields are stored on a Yee grid with the
/// appropriate staggering.
#[derive(Debug, Clone)]
pub struct YeeFields2D {
    /// Polarization mode
    polarization: Polarization,
    /// Yee grid specification
    grid: YeeGrid2D,
    /// Primary field (Ez for TM, Hz for TE) - at integer grid points
    primary: RealField2D,
    /// Secondary x-component (Hx for TM, Ex for TE) - at half-y positions
    secondary_x: RealField2D,
    /// Secondary y-component (Hy for TM, Ey for TE) - at half-x positions
    secondary_y: RealField2D,
}

impl YeeFields2D {
    /// Create zero-initialized fields for a given polarization.
    pub fn zeros(grid: YeeGrid2D, polarization: Polarization) -> Self {
        let base_grid = *grid.grid();
        Self {
            polarization,
            grid,
            primary: RealField2D::zeros(base_grid),
            secondary_x: RealField2D::zeros(base_grid),
            secondary_y: RealField2D::zeros(base_grid),
        }
    }

    /// Get the polarization mode.
    #[inline]
    pub fn polarization(&self) -> Polarization {
        self.polarization
    }

    /// Get the Yee grid.
    #[inline]
    pub fn grid(&self) -> &YeeGrid2D {
        &self.grid
    }

    // ========================================================================
    // Primary field accessors (Ez for TM, Hz for TE)
    // ========================================================================

    /// Get primary field (Ez for TM, Hz for TE).
    #[inline]
    pub fn primary(&self) -> &RealField2D {
        &self.primary
    }

    /// Get mutable primary field.
    #[inline]
    pub fn primary_mut(&mut self) -> &mut RealField2D {
        &mut self.primary
    }

    /// Get Ez (TM) or Hz (TE) at integer grid point.
    #[inline]
    pub fn get_primary(&self, ix: usize, iy: usize) -> f64 {
        self.primary.get(ix, iy)
    }

    /// Set Ez (TM) or Hz (TE) at integer grid point.
    #[inline]
    pub fn set_primary(&mut self, ix: usize, iy: usize, value: f64) {
        self.primary.set(ix, iy, value);
    }

    // ========================================================================
    // Secondary x-component accessors (Hx for TM, Ex for TE)
    // ========================================================================

    /// Get secondary x-field (Hx for TM, Ex for TE).
    #[inline]
    pub fn secondary_x(&self) -> &RealField2D {
        &self.secondary_x
    }

    /// Get mutable secondary x-field.
    #[inline]
    pub fn secondary_x_mut(&mut self) -> &mut RealField2D {
        &mut self.secondary_x
    }

    /// Get Hx (TM) or Ex (TE) at (i, j+½).
    #[inline]
    pub fn get_secondary_x(&self, ix: usize, iy: usize) -> f64 {
        self.secondary_x.get(ix, iy)
    }

    /// Set Hx (TM) or Ex (TE) at (i, j+½).
    #[inline]
    pub fn set_secondary_x(&mut self, ix: usize, iy: usize, value: f64) {
        self.secondary_x.set(ix, iy, value);
    }

    // ========================================================================
    // Secondary y-component accessors (Hy for TM, Ey for TE)
    // ========================================================================

    /// Get secondary y-field (Hy for TM, Ey for TE).
    #[inline]
    pub fn secondary_y(&self) -> &RealField2D {
        &self.secondary_y
    }

    /// Get mutable secondary y-field.
    #[inline]
    pub fn secondary_y_mut(&mut self) -> &mut RealField2D {
        &mut self.secondary_y
    }

    /// Get Hy (TM) or Ey (TE) at (i+½, j).
    #[inline]
    pub fn get_secondary_y(&self, ix: usize, iy: usize) -> f64 {
        self.secondary_y.get(ix, iy)
    }

    /// Set Hy (TM) or Ey (TE) at (i+½, j).
    #[inline]
    pub fn set_secondary_y(&mut self, ix: usize, iy: usize, value: f64) {
        self.secondary_y.set(ix, iy, value);
    }

    /// Split the fields into mutable references to components.
    /// This allows simultaneous mutable access to all three fields which
    /// avoids borrow checker issues and cloning during updates.
    /// Returns (primary, secondary_x, secondary_y).
    pub fn split_all_mut(&mut self) -> (&mut RealField2D, &mut RealField2D, &mut RealField2D) {
        (&mut self.primary, &mut self.secondary_x, &mut self.secondary_y)
    }

    // ========================================================================
    // Named accessors for clarity
    // ========================================================================

    /// Get Ez field (TM mode only).
    ///
    /// # Panics
    /// Panics if not in TM mode.
    pub fn ez(&self) -> &RealField2D {
        assert!(
            self.polarization == Polarization::TM,
            "Ez only exists in TM mode"
        );
        &self.primary
    }

    /// Get mutable Ez field (TM mode only).
    pub fn ez_mut(&mut self) -> &mut RealField2D {
        assert!(
            self.polarization == Polarization::TM,
            "Ez only exists in TM mode"
        );
        &mut self.primary
    }

    /// Get Hz field (TE mode only).
    ///
    /// # Panics
    /// Panics if not in TE mode.
    pub fn hz(&self) -> &RealField2D {
        assert!(
            self.polarization == Polarization::TE,
            "Hz only exists in TE mode"
        );
        &self.primary
    }

    /// Get mutable Hz field (TE mode only).
    pub fn hz_mut(&mut self) -> &mut RealField2D {
        assert!(
            self.polarization == Polarization::TE,
            "Hz only exists in TE mode"
        );
        &mut self.primary
    }

    /// Get Hx field (TM mode only).
    pub fn hx(&self) -> &RealField2D {
        assert!(
            self.polarization == Polarization::TM,
            "Hx only exists in TM mode"
        );
        &self.secondary_x
    }

    /// Get Hy field (TM mode only).
    pub fn hy(&self) -> &RealField2D {
        assert!(
            self.polarization == Polarization::TM,
            "Hy only exists in TM mode"
        );
        &self.secondary_y
    }

    /// Get Ex field (TE mode only).
    pub fn ex(&self) -> &RealField2D {
        assert!(
            self.polarization == Polarization::TE,
            "Ex only exists in TE mode"
        );
        &self.secondary_x
    }

    /// Get Ey field (TE mode only).
    pub fn ey(&self) -> &RealField2D {
        assert!(
            self.polarization == Polarization::TE,
            "Ey only exists in TE mode"
        );
        &self.secondary_y
    }

    // ========================================================================
    // Field statistics
    // ========================================================================

    /// Total electromagnetic energy (proportional to ∫(ε|E|² + μ|H|²) dV).
    ///
    /// Note: This is a simplified energy that doesn't account for the
    /// dielectric distribution or proper integration weights.
    pub fn total_energy(&self) -> f64 {
        self.primary.energy() + self.secondary_x.energy() + self.secondary_y.energy()
    }

    /// Maximum field amplitude across all components.
    pub fn max_amplitude(&self) -> f64 {
        self.primary
            .max_abs()
            .max(self.secondary_x.max_abs())
            .max(self.secondary_y.max_abs())
    }

    /// Check if fields have diverged (NaN or very large values).
    pub fn is_stable(&self) -> bool {
        let max = self.max_amplitude();
        max.is_finite() && max < 1e10
    }

    /// Reset all fields to zero.
    pub fn reset(&mut self) {
        self.primary.fill(0.0);
        self.secondary_x.fill(0.0);
        self.secondary_y.fill(0.0);
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_real_field_creation() {
        let grid = Grid2D::new(10, 10, 1.0, 1.0);
        let field = RealField2D::zeros(grid);
        assert_eq!(field.len(), 100);
        assert_eq!(field.max_abs(), 0.0);
    }

    #[test]
    fn test_real_field_operations() {
        let grid = Grid2D::new(4, 4, 1.0, 1.0);
        let mut field = RealField2D::zeros(grid);

        field.set(2, 3, 5.0);
        assert_eq!(field.get(2, 3), 5.0);

        field.add(2, 3, 3.0);
        assert_eq!(field.get(2, 3), 8.0);

        assert_eq!(field.max_abs(), 8.0);
    }

    #[test]
    fn test_yee_fields_tm() {
        let grid = YeeGrid2D::new(1.0, 1.0, 10.0);
        let fields = YeeFields2D::zeros(grid, Polarization::TM);

        assert_eq!(fields.polarization(), Polarization::TM);
        assert_eq!(fields.total_energy(), 0.0);
        assert!(fields.is_stable());
    }

    #[test]
    fn test_yee_fields_te() {
        let grid = YeeGrid2D::new(1.0, 1.0, 10.0);
        let fields = YeeFields2D::zeros(grid, Polarization::TE);

        assert_eq!(fields.polarization(), Polarization::TE);
        // These should work in TE mode
        let _ = fields.hz();
        let _ = fields.ex();
        let _ = fields.ey();
    }

    #[test]
    #[should_panic(expected = "Ez only exists in TM mode")]
    fn test_ez_panics_in_te_mode() {
        let grid = YeeGrid2D::new(1.0, 1.0, 10.0);
        let fields = YeeFields2D::zeros(grid, Polarization::TE);
        let _ = fields.ez(); // Should panic
    }
}
