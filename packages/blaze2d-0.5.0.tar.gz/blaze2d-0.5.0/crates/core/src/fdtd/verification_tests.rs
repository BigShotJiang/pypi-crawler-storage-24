#[cfg(test)]
mod tests {
    // Independent FDTD implementation for verification
    
    /// Basic FDTD stability check
    /// Runs a simulation in free space and checks that energy doesn't explode
    #[test]
    fn test_fdtd_stability() {
        let nx = 50;
        let ny = 50;
        let resolution = 10.0;
        let total_size = nx as f64 / resolution;
        
        // Setup simple grid
        let dx = 1.0 / resolution;
        let courant = 0.5;
        let dt = courant * dx / 2.0_f64.sqrt();
        
        let mut hz = vec![0.0; nx * ny];
        let mut ex = vec![0.0; nx * ny];
        let mut ey = vec![0.0; nx * ny];
        
        // Single point impulse source
        hz[ny/2 * nx + nx/2] = 1.0;
        
        // Run for 100 steps
        for _step in 0..100 {
            // H->E
            // Ex update
            for iy in 1..ny {
                for ix in 0..nx {
                    let idx = iy * nx + ix;
                    let dhz_dy = (hz[idx] - hz[idx - nx]) / dx;
                    ex[idx] += dt * dhz_dy;
                }
            }
            // Ey update
            for iy in 0..ny {
                for ix in 1..nx {
                    let idx = iy * nx + ix;
                    let dhz_dx = (hz[idx] - hz[idx - 1]) / dx;
                    ey[idx] -= dt * dhz_dx;
                }
            }
            
            // E->H
            for iy in 0..ny-1 {
                for ix in 0..nx-1 {
                    let idx = iy * nx + ix;
                    let dey_dx = (ey[idx+1] - ey[idx]) / dx;
                    let dex_dy = (ex[idx+nx] - ex[idx]) / dx;
                    hz[idx] += dt * (dex_dy - dey_dx); // Sign check: curl E = dEy/dx - dEx/dy. dH/dt = -curl E. So -(dEy/dx - dEx/dy) = dEx/dy - dEy/dx. Correct.
                }
            }
        }
        
        // Check bounds
        let max_hz = hz.iter().fold(0.0f64, |a, &b| a.max(b.abs()));
        assert!(max_hz < 2.0, "Instability detected, max_hz = {}", max_hz);
        assert!(max_hz > 0.0, "Field vanished");
    }

    /// Test dispersion / propagation speed
    /// Launch a gaussian pulse and measure distance traveled
    #[test]
    fn test_propagation_speed() {
        let nx = 200;
        let ny = 200; // Wide domain to simulate free space
        let resolution = 20.0;
        let dx = 1.0 / resolution;
        let courant = 0.5;
        let dt = courant * dx / 2.0_f64.sqrt();
        
        let mut hz = vec![0.0; nx * ny];
        let mut ex = vec![0.0; nx * ny];
        let mut ey = vec![0.0; nx * ny];
        
        // Source pulse parameters
        let t0 = 20.0 * dt;
        let width = 10.0 * dt;
        let src_x = nx / 4;
        let src_y = ny / 2;
        
        let run_steps = 200;
        
        for step in 0..run_steps {
            let t = step as f64 * dt;
            
            // Update E
            for iy in 1..ny {
                for ix in 0..nx {
                    let idx = iy * nx + ix;
                    let dhz_dy = (hz[idx] - hz[idx - nx]) / dx;
                    ex[idx] += dt * dhz_dy;
                }
            }
            for iy in 0..ny {
                for ix in 1..nx {
                    let idx = iy * nx + ix;
                    let dhz_dx = (hz[idx] - hz[idx - 1]) / dx;
                    ey[idx] -= dt * dhz_dx;
                }
            }
            
            // Soft source injection (magnetic current)
            let src_val = (-0.5 * ((t - t0) / width).powi(2)).exp();
            // Use deriv of gaussian to excite symmetric wave? No, just gaussian Jm
            
            // Update H
            for iy in 0..ny-1 {
                for ix in 0..nx-1 {
                    let idx = iy * nx + ix;
                    let dey_dx = (ey[idx+1] - ey[idx]) / dx;
                    let dex_dy = (ex[idx+nx] - ex[idx]) / dx;
                    hz[idx] += dt * (dex_dy - dey_dx);
                }
            }
            
            // Inject source
            hz[src_y * nx + src_x] += src_val * dt;
        }
        
        // Find peak position
        let center_row_start = src_y * nx;
        let center_row = &hz[center_row_start..center_row_start + nx];
        
        // Find max peak index
        let (max_idx, _max_val) = center_row.iter().enumerate()
            .fold((0, 0.0), |(imax, vmax), (i, &v)| if v.abs() > vmax { (i, v.abs()) } else { (imax, vmax) });
            
        let dist_grid = (max_idx as f64 - src_x as f64).abs();
        let dist_phys = dist_grid * dx;
        let time_elapsed = run_steps as f64 * dt - t0; // Approximate flight time from peak
        
        let speed = dist_phys / time_elapsed;
        
        println!("Measured speed: {}", speed);
        // Numerical speed is usually slightly less than c=1 due to dispersion
        assert!((speed - 1.0).abs() < 0.05, "Propagation speed error: c_meas = {}", speed);
    }
}
