//! Perfectly Matched Layer (PML) absorbing boundary conditions.
//!
//! This module implements Convolutional PML (CPML), which is the modern standard
//! for absorbing boundaries in FDTD. CPML uses auxiliary differential equations
//! and recursive convolution to achieve broadband absorption.
//!
//! # Theory
//!
//! PML works by introducing a complex coordinate stretching that causes waves
//! to decay exponentially. The stretched coordinate is:
//!
//!   s_x = κ_x + σ_x / (α_x + iω)
//!
//! where:
//! - κ_x ≥ 1 is the coordinate stretching factor
//! - σ_x is the conductivity (absorption strength)
//! - α_x is the CFS (Complex Frequency Shifted) parameter for stability
//!
//! # CPML Implementation
//!
//! CPML reformulates the stretched coordinate as a time-domain convolution,
//! which is implemented recursively using auxiliary fields:
//!
//!   Ψ(n+1) = b * Ψ(n) + a * (∂F/∂x)
//!
//! where a, b are derived from σ, κ, α and the time step dt.
//!
//! # References
//!
//! - J. A. Roden and S. D. Gedney, "Convolution PML (CPML): An efficient FDTD
//!   implementation of the CFS-PML for arbitrary media," Microwave and Optical
//!   Technology Letters, vol. 27, pp. 334-339, 2000.

use serde::{Deserialize, Serialize};

use super::fields::RealField2D;
use super::yee_grid::YeeGrid2D;

/// Parameters for PML configuration.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct PmlParams {
    /// PML thickness in grid cells
    pub thickness: usize,
    /// Maximum conductivity (σ_max)
    #[serde(default = "default_sigma_max")]
    pub sigma_max: f64,
    /// Polynomial grading order for conductivity profile
    #[serde(default = "default_order")]
    pub order: f64,
    /// Coordinate stretching factor (κ_max)
    #[serde(default = "default_kappa_max")]
    pub kappa_max: f64,
    /// CFS alpha parameter for improved absorption at low frequencies
    #[serde(default = "default_alpha_max")]
    pub alpha_max: f64,
}

fn default_sigma_max() -> f64 {
    // Optimal σ_max ≈ 0.8 * (order + 1) / (η * dx) where η = √(μ/ε)
    // For normalized units with dx ≈ 0.03 and order = 3: σ_max ≈ 1.0
    1.0
}

fn default_order() -> f64 {
    3.0
}

fn default_kappa_max() -> f64 {
    1.0
}

fn default_alpha_max() -> f64 {
    0.0
}

impl Default for PmlParams {
    fn default() -> Self {
        Self {
            thickness: 10,
            sigma_max: default_sigma_max(),
            order: default_order(),
            kappa_max: default_kappa_max(),
            alpha_max: default_alpha_max(),
        }
    }
}

impl PmlParams {
    /// Create PML with specified thickness.
    pub fn with_thickness(thickness: usize) -> Self {
        Self {
            thickness,
            ..Default::default()
        }
    }

    /// Set the polynomial grading order.
    pub fn order(mut self, order: f64) -> Self {
        self.order = order;
        self
    }

    /// Set the maximum conductivity.
    pub fn sigma_max(mut self, sigma_max: f64) -> Self {
        self.sigma_max = sigma_max;
        self
    }

    /// Set coordinate stretching.
    pub fn kappa_max(mut self, kappa_max: f64) -> Self {
        self.kappa_max = kappa_max;
        self
    }

    /// Compute optimal σ_max based on grid spacing.
    ///
    /// Uses the empirical formula: σ_opt ≈ 0.8 * (m + 1) / (η * d)
    /// where η = 377Ω in free space (normalized to 1), m is the order.
    pub fn compute_optimal_sigma(&self, d: f64) -> f64 {
        0.8 * (self.order + 1.0) / d
    }

    /// Create PML with optimal σ_max for given grid spacing.
    pub fn with_optimal_sigma(mut self, d: f64) -> Self {
        self.sigma_max = self.compute_optimal_sigma(d);
        self
    }
}

/// CPML coefficients for update equations.
///
/// These are precomputed from PML parameters and stored per-cell.
#[derive(Debug, Clone, Copy, Default)]
pub struct CpmlCoefficients {
    /// Recursive update coefficient: Ψ(n+1) = b * Ψ(n) + a * (∂F/∂x)
    pub b: f64,
    /// Source coefficient for new derivative contribution
    pub a: f64,
    /// Inverse of coordinate stretching factor (1/κ)
    pub inv_kappa: f64,
}

impl CpmlCoefficients {
    /// Compute CPML coefficients from PML parameters at a given position.
    ///
    /// # Arguments
    /// - `sigma`: Conductivity at this position
    /// - `kappa`: Coordinate stretching at this position
    /// - `alpha`: CFS parameter at this position
    /// - `dt`: Time step
    pub fn new(sigma: f64, kappa: f64, alpha: f64, dt: f64) -> Self {
        // b = exp(-(σ/κ + α) * dt)
        let b = (-(sigma / kappa + alpha) * dt).exp();

        // a = (σ / (σ*κ + κ²*α)) * (b - 1)
        // Handle σ = 0 case to avoid division by zero
        let a = if sigma.abs() < 1e-12 {
            0.0
        } else {
            let denom = sigma * kappa + kappa * kappa * alpha;
            if denom.abs() < 1e-12 {
                0.0
            } else {
                (sigma / denom) * (b - 1.0)
            }
        };

        Self {
            b,
            a,
            inv_kappa: 1.0 / kappa,
        }
    }
}

/// PML region holding auxiliary fields and coefficients.
///
/// Stores the Ψ fields and precomputed coefficients for each PML boundary.
#[derive(Debug, Clone)]
pub struct PmlRegion {
    /// Grid dimensions
    nx: usize,
    ny: usize,
    /// PML thickness on each side
    thickness: usize,
    /// Time step (needed for coefficient computation)
    dt: f64,

    // CPML coefficients for x-direction (at Ex/Hy positions)
    /// Coefficients for -x boundary (left)
    pub coeffs_x_lo: Vec<CpmlCoefficients>,
    /// Coefficients for +x boundary (right)
    pub coeffs_x_hi: Vec<CpmlCoefficients>,

    // CPML coefficients for y-direction (at Ey/Hx positions)
    /// Coefficients for -y boundary (bottom)
    pub coeffs_y_lo: Vec<CpmlCoefficients>,
    /// Coefficients for +y boundary (top)
    pub coeffs_y_hi: Vec<CpmlCoefficients>,

    // Auxiliary Ψ fields for CPML
    // For E-field updates (using H derivatives)
    /// Ψ_ex_y: for updating Ex with ∂Hz/∂y (TE) or ∂Hy/∂y (TM)
    pub psi_ex_y: RealField2D,
    /// Ψ_ey_x: for updating Ey with ∂Hz/∂x (TE) or ∂Hx/∂x (TM)
    pub psi_ey_x: RealField2D,

    // For H-field updates (using E derivatives)
    /// Ψ_hx_y: for updating Hx with ∂Ez/∂y (TM) or ∂Ey/∂y (TE)
    pub psi_hx_y: RealField2D,
    /// Ψ_hy_x: for updating Hy with ∂Ez/∂x (TM) or ∂Ex/∂x (TE)
    pub psi_hy_x: RealField2D,

    /// Which boundaries have PML enabled
    pub enabled: [bool; 4], // [x_lo, x_hi, y_lo, y_hi]
}

impl PmlRegion {
    /// Create a PML region for all boundaries.
    ///
    /// # Arguments
    /// - `grid`: The Yee grid specification
    /// - `params`: PML parameters
    /// - `dt`: Time step
    pub fn new(grid: &YeeGrid2D, params: &PmlParams, dt: f64) -> Self {
        let nx = grid.nx();
        let ny = grid.ny();
        let thickness = params.thickness;
        let base_grid = *grid.grid();

        // Compute coefficients for each boundary
        let dx = grid.dx();
        let dy = grid.dy();

        let coeffs_x_lo = Self::compute_coefficients_1d(thickness, dx, params, dt);
        let coeffs_x_hi = Self::compute_coefficients_1d(thickness, dx, params, dt);
        let coeffs_y_lo = Self::compute_coefficients_1d(thickness, dy, params, dt);
        let coeffs_y_hi = Self::compute_coefficients_1d(thickness, dy, params, dt);

        Self {
            nx,
            ny,
            thickness,
            dt,
            coeffs_x_lo,
            coeffs_x_hi,
            coeffs_y_lo,
            coeffs_y_hi,
            psi_ex_y: RealField2D::zeros(base_grid),
            psi_ey_x: RealField2D::zeros(base_grid),
            psi_hx_y: RealField2D::zeros(base_grid),
            psi_hy_x: RealField2D::zeros(base_grid),
            enabled: [true, true, true, true],
        }
    }

    /// Create PML with selective boundaries.
    ///
    /// # Arguments
    /// - `enabled`: Array of [x_lo, x_hi, y_lo, y_hi] enabling each boundary
    pub fn with_boundaries(mut self, enabled: [bool; 4]) -> Self {
        self.enabled = enabled;
        self
    }

    /// Disable PML on specific boundaries (for periodic conditions).
    pub fn disable_x(&mut self) {
        self.enabled[0] = false;
        self.enabled[1] = false;
    }

    pub fn disable_y(&mut self) {
        self.enabled[2] = false;
        self.enabled[3] = false;
    }

    /// Compute 1D CPML coefficient profile.
    ///
    /// The profile is polynomial graded: σ(d) = σ_max * (d/L)^m
    /// where d is distance into PML and L is PML thickness.
    fn compute_coefficients_1d(
        thickness: usize,
        _cell_size: f64,
        params: &PmlParams,
        dt: f64,
    ) -> Vec<CpmlCoefficients> {
        let mut coeffs = Vec::with_capacity(thickness);

        for i in 0..thickness {
            // Distance into PML (from outer edge, so deepest = thickness-1)
            let depth = (thickness - 1 - i) as f64 + 0.5;
            let normalized_depth = depth / thickness as f64;

            // Polynomial grading
            let sigma = params.sigma_max * normalized_depth.powf(params.order);
            let kappa = 1.0 + (params.kappa_max - 1.0) * normalized_depth.powf(params.order);
            let alpha = params.alpha_max * (1.0 - normalized_depth); // α decreases into PML

            coeffs.push(CpmlCoefficients::new(sigma, kappa, alpha, dt));
        }

        coeffs
    }

    /// Check if a point is inside a PML region.
    pub fn in_pml(&self, ix: usize, iy: usize) -> bool {
        let in_x_lo = self.enabled[0] && ix < self.thickness;
        let in_x_hi = self.enabled[1] && ix >= self.nx - self.thickness;
        let in_y_lo = self.enabled[2] && iy < self.thickness;
        let in_y_hi = self.enabled[3] && iy >= self.ny - self.thickness;
        in_x_lo || in_x_hi || in_y_lo || in_y_hi
    }

    /// Get the PML thickness.
    pub fn thickness(&self) -> usize {
        self.thickness
    }

    /// Get the interior region (excluding PML).
    pub fn interior_bounds(&self) -> (usize, usize, usize, usize) {
        let x_lo = if self.enabled[0] { self.thickness } else { 0 };
        let x_hi = if self.enabled[1] {
            self.nx - self.thickness
        } else {
            self.nx
        };
        let y_lo = if self.enabled[2] { self.thickness } else { 0 };
        let y_hi = if self.enabled[3] {
            self.ny - self.thickness
        } else {
            self.ny
        };
        (x_lo, x_hi, y_lo, y_hi)
    }

    /// Reset all auxiliary fields to zero.
    pub fn reset(&mut self) {
        self.psi_ex_y.fill(0.0);
        self.psi_ey_x.fill(0.0);
        self.psi_hx_y.fill(0.0);
        self.psi_hy_x.fill(0.0);
    }

    // ========================================================================
    // CPML update methods
    // ========================================================================

    /// Update Ψ field for E-field x-component in y-direction PML.
    ///
    /// This is used when updating Ex with ∂H/∂y in the PML region.
    pub fn update_psi_e_y(
        &mut self,
        iy: usize,
        dh_dy: &[f64], // Derivative values along x for this y
    ) {
        // y-low PML
        if self.enabled[2] && iy < self.thickness {
            let coeff = &self.coeffs_y_lo[iy];
            for ix in 0..self.nx {
                let idx = iy * self.nx + ix;
                let psi = self.psi_ex_y.as_mut_slice();
                psi[idx] = (coeff.b * psi[idx] as f64 + coeff.a * dh_dy[ix]) as f32;
            }
        }
        // y-high PML
        if self.enabled[3] && iy >= self.ny - self.thickness {
            let pml_idx = iy - (self.ny - self.thickness);
            let coeff = &self.coeffs_y_hi[self.thickness - 1 - pml_idx];
            for ix in 0..self.nx {
                let idx = iy * self.nx + ix;
                let psi = self.psi_ex_y.as_mut_slice();
                psi[idx] = (coeff.b * psi[idx] as f64 + coeff.a * dh_dy[ix]) as f32;
            }
        }
    }

    /// Update Ψ field for E-field y-component in x-direction PML.
    pub fn update_psi_e_x(
        &mut self,
        ix: usize,
        dh_dx: &[f64], // Derivative values along y for this x
    ) {
        // x-low PML
        if self.enabled[0] && ix < self.thickness {
            let coeff = &self.coeffs_x_lo[ix];
            for iy in 0..self.ny {
                let idx = iy * self.nx + ix;
                let psi = self.psi_ey_x.as_mut_slice();
                psi[idx] = (coeff.b * psi[idx] as f64 + coeff.a * dh_dx[iy]) as f32;
            }
        }
        // x-high PML
        if self.enabled[1] && ix >= self.nx - self.thickness {
            let pml_idx = ix - (self.nx - self.thickness);
            let coeff = &self.coeffs_x_hi[self.thickness - 1 - pml_idx];
            for iy in 0..self.ny {
                let idx = iy * self.nx + ix;
                let psi = self.psi_ey_x.as_mut_slice();
                psi[idx] = (coeff.b * psi[idx] as f64 + coeff.a * dh_dx[iy]) as f32;
            }
        }
    }

    /// Get the CPML correction for E-update at a given position.
    ///
    /// Returns (correction_x, correction_y) to be added to the standard update.
    pub fn get_e_correction(&self, ix: usize, iy: usize) -> (f64, f64) {
        let idx = iy * self.nx + ix;
        let corr_x = self.psi_ex_y.as_slice()[idx] as f64;
        let corr_y = self.psi_ey_x.as_slice()[idx] as f64;
        (corr_x, corr_y)
    }

    /// Get the CPML correction for H-update at a given position.
    pub fn get_h_correction(&self, ix: usize, iy: usize) -> (f64, f64) {
        let idx = iy * self.nx + ix;
        let corr_x = self.psi_hx_y.as_slice()[idx] as f64;
        let corr_y = self.psi_hy_x.as_slice()[idx] as f64;
        (corr_x, corr_y)
    }

    /// Get coefficient for x-direction PML at position ix.
    pub fn get_coeff_x(&self, ix: usize) -> Option<&CpmlCoefficients> {
        if self.enabled[0] && ix < self.thickness {
            Some(&self.coeffs_x_lo[ix])
        } else if self.enabled[1] && ix >= self.nx - self.thickness {
            let pml_idx = ix - (self.nx - self.thickness);
            Some(&self.coeffs_x_hi[self.thickness - 1 - pml_idx])
        } else {
            None
        }
    }

    /// Get coefficient for y-direction PML at position iy.
    pub fn get_coeff_y(&self, iy: usize) -> Option<&CpmlCoefficients> {
        if self.enabled[2] && iy < self.thickness {
            Some(&self.coeffs_y_lo[iy])
        } else if self.enabled[3] && iy >= self.ny - self.thickness {
            let pml_idx = iy - (self.ny - self.thickness);
            Some(&self.coeffs_y_hi[self.thickness - 1 - pml_idx])
        } else {
            None
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::grid::Grid2D;

    #[test]
    fn test_pml_params_default() {
        let params = PmlParams::default();
        assert_eq!(params.thickness, 10);
        assert!(params.sigma_max > 0.0);
        assert!(params.order > 0.0);
    }

    #[test]
    fn test_cpml_coefficients() {
        let dt = 0.5;
        let sigma = 1.0;
        let kappa = 1.0;
        let alpha = 0.0;

        let coeff = CpmlCoefficients::new(sigma, kappa, alpha, dt);

        // b should be exp(-σ * dt) for κ=1, α=0
        let expected_b = (-sigma * dt).exp();
        assert!((coeff.b - expected_b).abs() < 1e-10);

        // inv_kappa should be 1.0 for κ=1
        assert!((coeff.inv_kappa - 1.0).abs() < 1e-10);
    }

    #[test]
    fn test_pml_region_creation() {
        let grid = YeeGrid2D::new(1.0, 1.0, 20.0);
        let params = PmlParams::with_thickness(5);
        let pml = PmlRegion::new(&grid, &params, 0.5);

        assert_eq!(pml.thickness(), 5);
        assert!(pml.in_pml(0, 0)); // Corner - in PML
        assert!(pml.in_pml(2, 10)); // Left edge - in PML
        assert!(!pml.in_pml(10, 10)); // Center - not in PML
    }

    #[test]
    fn test_interior_bounds() {
        let grid = YeeGrid2D::new(1.0, 1.0, 20.0);
        let params = PmlParams::with_thickness(3);
        let pml = PmlRegion::new(&grid, &params, 0.5);

        let (x_lo, x_hi, y_lo, y_hi) = pml.interior_bounds();
        assert_eq!(x_lo, 3);
        assert_eq!(x_hi, 17);
        assert_eq!(y_lo, 3);
        assert_eq!(y_hi, 17);
    }
}
